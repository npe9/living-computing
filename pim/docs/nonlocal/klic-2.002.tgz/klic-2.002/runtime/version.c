char *runtime_version = "2.002";
char *runtime_date = "Tue May 23 13:27:38 JST 1995";
