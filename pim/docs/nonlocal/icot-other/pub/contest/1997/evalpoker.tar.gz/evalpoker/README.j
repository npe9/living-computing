	$B!Z0l?MM7$S%]!<%+!<E@?tI>2A%W%m%0%i%`![(B

			by Eiji Sugino (sugino@jaist.ac.jp) at Jul.17.1997

$B!&5!G=(B

	$B0l?MM7$S%]!<%+!<$N2r!J#5!_#5Kg$N;%$NJB$S!K$KBP$7$F!"(B
	$BAm9gE@?t$rI>2A$9$k!#(B
	
	$B%F%9%HMQ$KDL>o$N%]!<%+!<5!G=$b4^$`!#(B

$B!&%U%!%$%k(B

	$B$3$N%Q%C%1!<%8$K$O!"0J2<$N%U%!%$%k$,4^$^$l$k(B

	README.j	$BK\%U%!%$%k(B
	README.e 	$B1Q8lHG(B README
	Makefile	make$B%U%!%$%k(B
	main.kl1	$B%I%i%$%P!<(B
	dealer.kl1	$B%+!<%I$rMp?t$K$h$C$F@8@.$9$k(B
	eval.kl1	$BE@?tI>2A%W%m%0%i%`(B

$B!&%$%s%9%H!<%k(B

	% make 

	$B$K$h$C$F(B $B%U%!%$%k(B pk $B$,@8@.$5$l$k!#(B

$B!&;HMQJ}K!(B

	% ./pk [Seed]

	$B$K$h$C$F%W%m%0%i%`$,5/F0$5$l$k!#(B 
	Seed$B$O=i4|Mp?t$N%?%M$G$"$j!">JN,2DG=$G$"$k!#(B

	$B5/F0$5$l$k$H%W%m%s%W%H(B '>' $B$KBP$7$F!"%3%^%s%IF~NO$r<u$1IU$1$k!#(B
	$B$J$*!"%3%^%s%IF~NO(B $B$O(B'.' $B$G=*$i$M$P$J$i$J$$!#(B
	
	$B%3%^%s%I$H$7$F<!$,MQ0U$5$l$F$$$k!#(B

	quit  or  exit   : $B%W%m%0%i%`$r=*N;$9$k!#(B
	open(N)		 : $B%?%M$r(BN$B$H$7$?Mp?t$G!"?7$7$$%+!<%I$rMQ0U$9$k!#(B
	5		 : $B%+!<%I$r(B5$BKgG[$k!JDL>o$N%]!<%+!<$H$7$F<B9T!K!#(B
	25		 : $B%+!<%I$r(B25$BKgG[$k!#(B
	[card(..),...]   : $BL@<(E*$KG$0U$N%+!<%I$r@_Dj$9$k!#(B
				$BMM<0$O2]Bj$K$"$kDL$j!#(B
	show		 : $B8=:_J];}$7$F$$$k%+!<%I$r:FI=<($9$k!#(B
	ch(List)	 : $B%+!<%I$rJQ$($k!#JQ$($k%+!<%I$O!"(BList$B$G;XDj$9$k!#(B
			    List$B$O=g$K!"8=:_$N<j;%$N@hF,$r(B0,$B<!$r(B1,... $B$G;XDj(B
			    $B$9$k!#(B
$B!&I=<((B

	1. $BDL>o$N(B5$BKg%]!<%+!<$NI=<(Nc(B

		C6 C2 C3 S4 H5   ... 10787 / straight(20)

		$B<j;%$HF@E@!"Lr$rI=<($9$k!#(B
		$B<j;%$NAH$O!"(Bspades,hearts,diamonds,clubs $B$r$=$l$>$l(BS,H,D,C$B$G!"(B
		$B$^$?0L$O!"(B10,jack,queen,king,ace $B$r$=$l$>$l(B T,J,Q,K,A $B$GI=$9!#(B
		$BLr$N(B()$BCf$N?t;z$O!"2CE@$N7W;;$KMQ$$$F$$$kFbIt$NCM$G$"$k!#(B

	2.  25$BKg0l?MM7$S$NI=<(Nc(B

		104  0  0  118  112  				*1
		ST CA C6 H9 HA  ... 128				*2
		S4 SJ H7 DT D5  ... 0				
		D2 DQ SQ S9 H6  ... 124				
		S2 S8 H8 S7 DK  ... 116				
		C8 D7 H3 C3 S6  ... 106				
		  21546 / 116					*3
		 --------------------------- TOTAL=22470	*4

		(*1) $B=DNs$NJB$S$KBP$9$kE@?t$rI=<($9$k!#(B
		(*2) $B3F9T$rI=<($7$?8e$m$K!"$=$N9T$KBP$9$kE@?t$rI=<($9$k!#(B
		(*3) $B:8<P$aBP3Q@~$NE@?t(B / $B1&<P$aBP3Q@~$NE@?t$rI=<($9$k!#(B
		(*4) $BAmF@E@$rI=<($9$k!#(B

$B!&;HMQNc(B

	% ./pk						$B%W%m%0%i%`5/F0(B
	> 5.						5$BKgG[$k(B
	CK C2 C3 S4 H5   ... 0 / no_pair
	TIME=0
	> ch([0]).					1$BKg(B(CK)$B$r8r49(B
	D9 C2 C3 S4 H5   ... 0 / no_pair
	TIME=0
	.......
	> ch([0]).					
	C6 C2 C3 S4 H5   ... 10787 / straight(20)
	TIME=0
	=-=-=-=-=-=-=-=-=-
	> open(17).					$BJL$N%Q%C%/$r3+$/(B
	TIME=0
	> 5.						5$BKgG[$k(B
	SQ D8 SA HA HT   ... 128 / one_pair(14)
	TIME=0
	> ch([0,1,4]).					3$BKg(B(SQ,D8,HT)$B$r8r49(B
	D2 D6 SA HA S9   ... 128 / one_pair(14)
	TIME=0
	> ch([0,1,4]).
	H5 DT SA HA D5   ... 926 / two_pairs(5,14)
	TIME=0
	> ch([1]).
	H5 H4 SA HA D5   ... 926 / two_pairs(5,14)
	TIME=0
	........
	> ch([1]).
	H5 C5 SA HA D5   ... 29376 / full_house(5,14)
	TIME=0
	=-=-=-=-=-=-=-=-=-

	> open(7).					$BJL$N%Q%C%/$r3+$/(B
	TIME=0
	> 25.						25$BKgG[$k(B
	104  0  0  0  112  
	HT CA S5 D8 HA  ... 128
	S4 SJ H7 DT D5  ... 0
	D2 CT SQ S9 H6  ... 0
	S2 S8 H8 S7 DK  ... 116
	C8 CQ DJ C3 S6  ... 0
	  0 / 116
	 --------------------------- TOTAL=576
	TIME=0
	>  ch([0,2,3]). 				3$BKg(B(HT,S5,D8)$B8r49(B
	104  0  0  118  112  
	ST CA C6 H9 HA  ... 128
	S4 SJ H7 DT D5  ... 0
	D2 CT SQ S9 H6  ... 0
	S2 S8 H8 S7 DK  ... 116
	C8 CQ DJ C3 S6  ... 0
	  21546 / 116
	 --------------------------- TOTAL=22240
	TIME=0
	> ch([11,21]).					2$BKg(B(CT,CQ)$B8r49(B
	104  0  0  118  112  
	ST CA C6 H9 HA  ... 128
	S4 SJ H7 DT D5  ... 0
	D2 DQ SQ S9 H6  ... 124
	S2 S8 H8 S7 DK  ... 116
	C8 H4 DJ C3 S6  ... 0
	  21546 / 116
	 --------------------------- TOTAL=22364
	TIME=16


