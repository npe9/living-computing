#! /bin/sh
#			by Eiji Sugino (sugino@jaist.ac.jp) at [Sep.4.1997]

VERSION="Versin 0.1 Sep 4 1997 / by Eiji Sugino <sugino@jaist.ac.jp> "
USAGE="Usage: Command [-seed Seed | -data File] [-time Sec] [-clean] Directory"

SEED=7
CLEAN=""
TIME=20

while :
do
	case $1 in
		-seed)  shift
	                SEED=$1
		  	shift;;
		-data)	shift
			SEED=$1
			shift;;
		-time)	shift
			TIME=$1
			shift;;
		-clean) CLEAN="make destclean"
			shift;;
		-*)	echo $VERSION >&2
			echo $USAGE >&2
			exit 1;;
		*)	  break;;
	esac
done

cd $1
echo $CLEAN
$CLEAN
make 

./go $SEED $TIME 

cd ..
