	$B0l?M%]!<%+!<%W%m%0%i%`(B $BI>2AMQ(B $B%W%m%0%i%`%;%C%H(B $BBh(B1$BHG(B
					Sep. 11 1997 
					by  Eiji Sugino <sugino@jaist.ac.jp>

$B#1(B $B%G%#%l%/%H%j9=B$(B

   $B$3$N%;%C%H$N%G%#%l%/%H%j9=B$$O!"<!$N$h$&$K$J$C$F$$$k(B

	% ls
	Makefile	README.j	test/		test.sh*
	README.e	dummy/		test.dat	

   (0) README.j $B$OK\%U%!%$%k!"(BREADME.e $B$O1Q8lHG$G$"$k!#(B
   (1) $B%G%#%l%/%H%j(B dummy $B$O!"%@%_!<%W%m%0%i%`$,F~$C$F$$$k!#(B 
   (2) $B%G%#%l%/%H%j(B test $B$O!"%F%9%HMQ%W%m%0%i%`%;%C%H(B1$B<0$r<}$a$F$"$k!#(B
   (3) Makefile$B$O!";22C<T$N%W%m%0%i%`$r(Bmake$B$9$k$?$a$N%5%s%W%k$G$"$k!#(B
   (4) test.sh $B$O!";22C<T$N%W%m%0%i%`$r%3%s%Q%$%k!"<B9T$9$k$?$a$N%3%^%s%I(B
	$B$G$"$k!#(B
   (5) test.dat $B$O!"%F%9%HMQ$N%+!<%I%G!<%?$G$"$k!#(B

$B#2(B $BI>2ABP>]%W%m%0%i%`$NCV$-J}(B

	$B$3$3$G$O(B $B%@%_!<$rNc$K$7$F!"%W%m%0%i%`$NCV$-J}$r@bL@$9$k!#(B

   (1) $B%G%#%l%/%H%j$r:n$k!#(B 
	$B%G%#%l%/%H%jL>$O!"2?$G$b$+$^$o$J$$!#$3$3$G$O(B dummy $B$H$9$k!#(B

	% mkdir dummy; cd dummy

   (2) (1)$B$G:n$C$?%G%#%l%/%H%j$K%f!<%6%W%m%0%i%`$rCV$/!#(B
	$B$3$3$KCV$+$l$?(B *.kl1 $B$N7A$N$9$Y$F$N%U%!%$%k$,%3%s%Q%$%k$5$l$k!#(B

	% cp ~myself/*.kl1  .

   (3) (1)$B$G:n$C$?%G%#%l%/%H%j$K(BMakefile$B$rCV$/!#(B
	$B#1$N(B(3)$B$GMQ0U$7$?(B Makefile $B$r%3%T!<$9$k$+%j%s%/$rD%$l$P$h$$!#(B

	% ln -s ../Makefile Makefile
	% ls 
	Makefile@	solitaire.kl1
                     
$B#3(B $BI>2A%W%m%0%i%`$N<B9TJ}K!(B

	$B%H%C%W%G%#%l%/%H%j$G!"(Btest.sh $B$r8F$S=P$;$P!"(B 
	$B%W%m%0%i%`$r%3%s%Q%$%k$7$F!"<B9T$9$k!#(B
	$B%Q%i%a!<%?$H$7$F!"I>2ABP>]%W%m%0%i%`$N%G%#%l%/%H%j$r;XDj$9$k!#(B

	test.sh$B$K$O!"Mp?t$N%?%M(B7$B!"%?%$%`%"%&%H(B20(sec)$BMQ$$$k$h$&$K(B
	$B%G%U%)%k%H$H$7$F@_Dj$7$F$"$k$,!"%*%W%7%g%s;XDj$G(B
	
		% test.sh -seed 7 -time 60 dummy

	$B$N$h$&$KL@$K;XDj$7$F<B9T$9$k$3$H$b2DG=$G$"$k!#(B
	
    (1)	$B<B9TNc$H2r@b(B

	$B%@%_!<%W%m%0%i%`$KBP$7$F!JNc$($P0J2<$N$h$&$K!K5/F0$9$k$H!"(B

	% ./test.sh dummy

	$B%3%s%Q%$%k$N8e!"<!$N$h$&$J=PNO$,F@$i$l$k!#(B
	  $BCm!KI8=`%(%i!<=PNO$K=P$7$F$$$k$b$N$b$"$k!#(B

	% ./test.sh dummy

	klic -v -o ./go  -x . ../test/main.kl1 ../test/dealer.kl1 ....
	KLIC compiler driver version 2.004 (Mon Nov 27 15:50:11 JST 1995)
	/usr/lang/klic-2.004/lib/klic/kl1cmp ../test/main.kl1 </dev/null
	.....
	gcc -o ./go  ./atom.o ./funct.o ./predicates.o ../test/main.o ....
	104  0  0  0  112  
	HT CA S5 D8 HA  ... 128
	S4 SJ H7 DT D5  ... 0
	D2 CT SQ S9 H6  ... 0
	S2 S8 H8 S7 DK  ... 116
	C8 CQ DJ C3 S6  ... 0
	  0 / 116
	 --------------------------- TOTAL=576 TIME=17
	......
	104  0  10812  124  916  
	S5 CA HT HA D8  ... 128
	S4 SJ H7 DT D5  ... 0
	D2 CT S9 SQ H6  ... 0
	S2 S8 H8 S7 C8  ... 2024
	DK C3 DJ CQ S6  ... 0
	  21538 / 116
	 --------------------------- TOTAL=35762 TIME=13484
	=-=-= Time out.
	% 

$B#4(B test.sh $B$N%*%W%7%g%s(B

	test.sh $B$O!"<!$N$h$&$J%*%W%7%g%s$r<u$1IU$1$k!#(B

	[-seed Seed] 		$B5?;wMp?t$N%?%M$r(BSeed$B$H$9$k(B
	[-data File] 		File$B$KCV$$$?%+!<%I$rF~NO$H$9$k(B
	[-time Second] 		$B%?%$%`%"%&%H;~4V(B(sec)$B$r;XDj$9$k(B
	[-clean] 		$B%3%s%Q%$%k$7$J$*$7$F<B9T$9$k(B

	$BCm#1!K(B-time $B$G?tCM0J30$r;XDj$9$k$H!"%?%$%`%"%&%HL5$7$GF0:n$9$k!#(B

	$BCm#2!K#1(B(5) $B$G<($7$?(B test.dat $B$r;XDj$7$FF0:n$5$;$k$H$-$K$O!"(B

		./test.sh -data ../test.dat dummy

		$B$N$h$&$K;XDj$9$l$PNI$$!#(B
