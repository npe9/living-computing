life_set -24 -28
life_set -22 -27
life_set -20 -26
life_set -21 -26
life_set -19 -26
life_set -24 -26
life_set -25 -26
