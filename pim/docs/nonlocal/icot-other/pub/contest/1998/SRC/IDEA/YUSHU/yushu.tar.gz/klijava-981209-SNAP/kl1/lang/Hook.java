/*
 * Hook.java -- hook record
 *
 * (C)1993, 1994, 1995 Institute for New Generation Computer Technology
 *	(Read COPYRIGHT for detailed information.) 
 *
 * (C)1996, 1997 Japan Information Processing Development Center
 *      (Read COPYRIGHT-JIPDEC for detailed information.)
 *
 * Copyright (C) 1998 Satoshi KURAMOCHI <satoshi@ueda.info.waseda.ac.jp>
 *
 */

package kl1.lang;

public final class Hook {
  Hook next;		/* next suspension structure */
  KL1Object u;		/* pointer to a goal record */
			/* pointer to a consumer object */
  public Hook() {
    next = null;
    u = null;
  }
}
