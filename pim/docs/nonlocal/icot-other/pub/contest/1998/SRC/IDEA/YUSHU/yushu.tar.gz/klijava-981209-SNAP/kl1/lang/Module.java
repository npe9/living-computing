/*
 * Module.java -- module
 *
 * (C)1993, 1994, 1995 Institute for New Generation Computer Technology
 *	(Read COPYRIGHT for detailed information.) 
 *
 * (C)1996, 1997 Japan Information Processing Development Center
 *      (Read COPYRIGHT-JIPDEC for detailed information.)
 *
 * Copyright (C) 1998 Satoshi KURAMOCHI <satoshi@ueda.info.waseda.ac.jp>
 *
 */

package kl1.lang;

public abstract class Module {
  public Modinfo info;
  public Predinfo preds[];

  public void init(KL1Machine mach) {}

  public abstract Module exec(KL1Machine mach, Goalrec qp, Predicate toppred);

  public Predicate get_pred(String predname, int arity) {
    Predicate pred = null;
    for(int i = 0; i < preds.length; i++)
      if(preds[i].predstruct.arity == arity && preds[i].name.equals(predname))
	pred = preds[i].predstruct;
    return pred;
  }

  public String toString() {
    return info.name;
  }

  public String print(int pred) {
    return preds[pred].name;
  }

  public final static void main(String argv[]) {
    (new Thread((new KL1Machine(argv)))).start();
  }
}

