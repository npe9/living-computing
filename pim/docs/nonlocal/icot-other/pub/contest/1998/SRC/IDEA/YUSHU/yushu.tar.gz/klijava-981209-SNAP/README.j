
	   KLIJava: KL1 to Java Compiler based on KLIC 3.002

			    981209-SNAPSHOT

  (C)1993, 1994, 1995 Institute for New Generation Computer Technology
	       (Read COPYRIGHT for detailed information.)

     (C)1996, 1997 Japan Information Processing Development Center
	   (Read COPYRIGHT-JIPDEC for detailed information.)

		  Copyright(C) 1998 Satoshi KURAMOCHI



$B!&35MW(B

KLIC-3.002 $B$N%3%s%Q%$%i$r2~B$$7$F(B Java $B$N%3!<%I$r=PNO$9$k%3%s%Q%$%i$r:n(B
$B@.$7$^$7$?!#%i%s%?%$%`%i%$%V%i%j$O(B Java $B$G=q$-D>$7$F$"$j$^$9!#(B

$B$H$j$"$($:%3%s%Q%$%i$N%;%k%U%3%s%Q%$%k$rL\I8$K<BAu$r?J$a$F$$$^$9$,!"$^$@(B
$B%G%P%C%0$,=*N;$7$F$$$^$;$s!#%F%9%H%W%m%0%i%`$NCf$K$b<B9T;~%(%i!<$K$J$k$b(B
$B$N$,$$$/$D$+;D$C$F$$$^$9!#(B

$B!&%3%s%Q%$%i$N%=!<%9$H%5%s%W%k$O!"0J2<$N>l=j$KCV$$$F$"$j$^$9!#(B

    compiler/		$B%3%s%Q%$%i(B
    kl1/lang/		$B%i%s%?%$%`%i%$%V%i%j(B
    test/		$B%F%9%H%W%m%0%i%`(B

$B!&F0:n4D6-(B

    $B%3%s%Q%$%i!'(B        klic-3.002 $B$NF0:n$9$k4D6-(B
    $B=PNO%W%m%0%i%`!'(B    JDK 1.1 $B0J>e(B

$B!&8=:_!"F0:n$r3NG'$7$F$$$k%W%m%0%i%`(B

  append.kl1, cmac.kl1, fact.kl1, fiblazy.kl1, hanoi.kl1, iotest.kl1,
  kkqueen.kl1, life.kl1, mastermind.kl1, pascal.kl1, pp.kl1, primes.kl1,
  primesp.kl1, prio.kl1, qlay.kl1, qsort.kl1

$B!&$^$@<BAu$5$l$F$$$J$$5!G=(B

  - $BAH9~$_=R8l$N0lIt!J(BUNIX $B%$%s%?%U%'!<%9(B, $B%?%$%^(B, postmortem $B$J$I!K(B
  - $B%8%'%M%j%C%/%*%V%8%'%/%H!J(BI/O $B$J$I!K(B
  - Java$B$H$N%$%s%?%U%'!<%9!J(BGUI$B!"%"%W%l%C%H!K(B
  - $B%H%l!<%5(B
  - $BJ,;6=hM}(B
  $B$J$I(B

$B!&?75!G=(B

  - $B%$%s%i%$%s(B Java :-)

$B!&%3%s%Q%$%k<j=g(B

  $B%3%s%Q%$%i$N:n@.(B
  % cd compiler
  % make

  $B%i%s%?%$%`%i%$%V%i%j$N:n@.(B
  % cd ../kl1/lang
  % make symlinks
  % make

$B!&%F%9%H%W%m%0%i%`$r<B9T$9$k$K$O!"0J2<$N$h$&$K$7$^$9!#(B

  % setenv CLASSPATH $CLASSPATH:$B%H%C%W%G%#%l%/%H%j(B
  % ./compiler/kl1cmp foo.java
  % cp foo.java Module_main.java
  % javac Module_main.java
  % java Module_main

$B!&%Y%s%A%^!<%/7k2L!J;29M!K(B

  compiler             KLIC      KLIJava (sec)
  -----------------------------------------------------
  primes(10000)        0.37      15.32        (x 41.40)
  kkqueen(10)          0.33      15.34        (x 46.48)
  life(120,38,38,4,4)  1.22      22.06        (x 18.08)
  mastermind(3,3)      0.77      27.34        (x 35.51)

  MMX-Pentium 266MHz, 64MB, Linux
    KLIJava: JDK 1.1.5, w/o JIT
             -ms32m -mx32m -noasyncgc -noclassgc -noverify
    KLIC: 3.002, gcc -O2

$B!&G[I[(B

$B:G?7HG$N8x3+$O!"(B

  http://www.ueda.info.waseda.ac.jp/~satoshi/klijava/

$B$G9T$J$C$F$$$^$9!#(B

$B8f0U8+!"8f46A[$J$I$O$*5$7Z$K(B

  satoshi@ueda.info.waseda.ac.jp

$B$^$G$*4s$;2<$5$$!#(B

$B!&;29MJ88%(B

  [1] $B4XED(B $BBg8c(B. Inside KLIC Version 1.0, 1998

  [2] jProlog  <http://www.cs.kuleuven.ac.be/~bmd/PrologInJava/>

--
$BAR;}(B $BAo(B / Satoshi Kuramochi 
satoshi@ueda.info.waseda.ac.jp
http://www.ueda.info.waseda.ac.jp/~satoshi/index-j.html
