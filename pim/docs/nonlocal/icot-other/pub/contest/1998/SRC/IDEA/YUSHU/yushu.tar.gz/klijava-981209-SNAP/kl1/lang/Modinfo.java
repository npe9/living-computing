/*
 * Modinfo.java -- module information
 *
 * (C)1993, 1994, 1995 Institute for New Generation Computer Technology
 *	(Read COPYRIGHT for detailed information.) 
 *
 * (C)1996, 1997 Japan Information Processing Development Center
 *      (Read COPYRIGHT-JIPDEC for detailed information.)
 *
 * Copyright (C) 1998 Satoshi KURAMOCHI <satoshi@ueda.info.waseda.ac.jp>
 *
 */

package kl1.lang;

public class Modinfo {
  public String name;
  public Predinfo preds[];

  public Modinfo(String name, Predinfo preds[]) {
    this.name = name;
    if(preds != null) {
      this.preds = new Predinfo[preds.length];
      for(int i = 0; i < preds.length; i++)
	this.preds[i] = preds[i];
    } else
      this.preds = null;
  }
}
