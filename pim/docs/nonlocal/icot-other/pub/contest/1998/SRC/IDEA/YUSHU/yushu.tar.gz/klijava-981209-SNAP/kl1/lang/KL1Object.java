/*
 * KL1Object.java -- 
 *
 * (C)1993, 1994, 1995 Institute for New Generation Computer Technology
 *	(Read COPYRIGHT for detailed information.) 
 *
 * (C)1996, 1997 Japan Information Processing Development Center
 *      (Read COPYRIGHT-JIPDEC for detailed information.)
 *
 * Copyright (C) 1998 Satoshi KURAMOCHI <satoshi@ueda.info.waseda.ac.jp>
 *
 */

package kl1.lang;

public abstract class KL1Object {
/*
  public KL1Object deref() {
    mach.fatal("general deref on objects not available.");
    return null;
  }
*/

  public KL1Object gunify(KL1Object that) {
    System.out.println("general guard unify on " + this.getClass().getName()
		       + " not available.");
    return GDObj.FAILURE;
  }

  public void unify(KL1Machine mach, KL1Object that) {
    mach.fatal("general unify on " + this.getClass().getName()
	       + " not available.");
  }

  public void shallow_unify(KL1Machine mach, KL1Object that) {
    mach.fatal("general shallow unify on " + this.getClass().getName()
	       + " not available.");
  }

  public boolean equals(KL1Object that) {
    System.out.println("general equals on " + this.getClass().getName()
		       + " not available.");
    return false;
  }

  public String toString() {
    System.out.println("general toString on " + this.getClass().getName()
		       + " not available.");
    return null;
  }

  public String print() {
    System.out.println("general print on " + this.getClass().getName()
		       + " not available.");
    return null;
  }


  public static KL1Object _new(KL1Machine mach, KL1Object argv[]) {
    mach.fatal("general new on objects not available.");
    return null;
  }


  public void generic(KL1Machine mach, String method, KL1Object argv[]) {
    mach.print("### method " + method + " issued to " + print() + " ###\\n");
    mach.fatal("Generic method issued to a non-object");
  }


  public KL1Object deref() {
    KL1Object t = this;
    while(t instanceof Var) {
      KL1Object temp = ((Var)t).refers;
      if(temp instanceof Var && t == ((Var)temp).refers)
	return t;
      else
	t = temp;
    }
    return t;
  }
}
