/*
 * Predinfo.java -- predicate information
 *
 * (C)1993, 1994, 1995 Institute for New Generation Computer Technology
 *	(Read COPYRIGHT for detailed information.) 
 *
 * (C)1996, 1997 Japan Information Processing Development Center
 *      (Read COPYRIGHT-JIPDEC for detailed information.)
 *
 * Copyright (C) 1998 Satoshi KURAMOCHI <satoshi@ueda.info.waseda.ac.jp>
 *
 */

package kl1.lang;

public class Predinfo {
  public String name;
  public Predicate predstruct;

  public Predinfo(String name, Predicate predstruct) {
    this.name = name;
    this.predstruct = predstruct;
  }

  public String toString() {
    return name + predstruct;
  }
}
