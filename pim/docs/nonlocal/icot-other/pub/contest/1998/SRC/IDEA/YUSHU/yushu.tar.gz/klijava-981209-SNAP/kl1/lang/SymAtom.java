/*
 * SymAtom.java -- symbolic atom
 *
 * (C)1993, 1994, 1995 Institute for New Generation Computer Technology
 *	(Read COPYRIGHT for detailed information.) 
 *
 * (C)1996, 1997 Japan Information Processing Development Center
 *      (Read COPYRIGHT-JIPDEC for detailed information.)
 *
 * Copyright (C) 1998 Satoshi KURAMOCHI <satoshi@ueda.info.waseda.ac.jp>
 *
 */

package kl1.lang;

public class SymAtom extends KL1Object {
  public String name;	// must be intern()'ed

  public SymAtom(String name) { this.name = name; }

  public SymAtom(GString name) { this.name = name.toString(); }

  public KL1Object gunify(KL1Object that) {
    if((that = that.deref()) instanceof SymAtom)
      return (name == ((SymAtom)that).name) ? GDObj.SUCCESS : GDObj.FAILURE;
    else
      return (that instanceof Var) ? that : GDObj.FAILURE;
  }


  public void unify(KL1Machine mach, KL1Object that) {
    if(mach.UNIFYDEBUG)
      mach.print("Unify with " + this.print() + "," + that.print());
    while (that instanceof Var) {
      KL1Object temp = ((Var)that).refers;
      if (temp == that) { // that is undef cell
	((Var)that).refers = this;
	return;
      } else {
	if(temp instanceof Var && ((Var)temp).refers == that) {
	  mach.resume_goals(temp, this);
	  return;
	}
      }
      that = temp;
    }
    // that is bound
    if (!(that instanceof SymAtom) || this.name != ((SymAtom)that).name)
      mach.enqueue_unify_terms(this, that);

/*
    if(this.getClass() == that.getClass())
      return (this.name == ((SymAtom)that).name);
    else
      return that.unify(this);
*/
  }


  public void shallow_unify(KL1Machine mach, KL1Object that) {
    if(mach.UNIFYDEBUG)
      mach.print("Unify with " + this.print() + "," + that.print());
    while (that instanceof Var) {
      KL1Object temp = ((Var)that).refers;
      if (temp == that) { // that is undef cell
	((Var)that).refers = this;
	return;
      } else {
	if(temp instanceof Var && ((Var)temp).refers == that) {
	  mach.enqueue_unify_goal(this, that);
	  return;
	}
      }
      that = temp;
    }
    // that is bound
    if (!(that instanceof SymAtom) || this.name != ((SymAtom)that).name)
      mach.enqueue_unify_goal(this, that);

/*
    if(this.getClass() == that.getClass())
      return (this.name == ((SymAtom)that).name);
    else
      return that.unify(this);
*/
  }


  public boolean equals(KL1Object that) {
    if(that instanceof SymAtom)
      return (this.name == ((SymAtom)that).name);
    else
      return false;
  }

  public String toString() {
    return name;
  }

  public String print() { return toString(); }

  public final static SymAtom nil = new SymAtom("[]".intern());
  public final static SymAtom period = new SymAtom(".".intern());

  public final boolean isnil() { return name == nil.name; }
}

