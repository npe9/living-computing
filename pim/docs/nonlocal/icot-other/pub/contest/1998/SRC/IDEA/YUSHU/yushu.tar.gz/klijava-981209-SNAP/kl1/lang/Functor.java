/*
 * Functor.java -- functor
 *
 * (C)1993, 1994, 1995 Institute for New Generation Computer Technology
 *	(Read COPYRIGHT for detailed information.) 
 *
 * (C)1996, 1997 Japan Information Processing Development Center
 *      (Read COPYRIGHT-JIPDEC for detailed information.)
 *
 * Copyright (C) 1998 Satoshi KURAMOCHI <satoshi@ueda.info.waseda.ac.jp>
 *
 */

package kl1.lang;

public class Functor extends KL1Object {
  public String functor;	/* principal functor as atomic q object */
  public KL1Object args[];	/* arguments */

  public Functor(String functor, KL1Object args[]) {
    this.functor = functor;
    this.args = new KL1Object[args.length];
    for(int i = 0; i < args.length; i++)
      this.args[i] = args[i];
  }

//  KL1Object deref() { return this; }
//  boolean isfunctor() { return true; }


  public KL1Object gunify(KL1Object that) {
    if((that = that.deref()) instanceof Functor) {
      if(functor != ((Functor)that).functor)
	return GDObj.FAILURE;
      for(int i = 0; i < args.length; i++) {
	KL1Object retval;
	if((retval = args[i].gunify(((Functor)that).args[i])) != GDObj.SUCCESS)
	  return retval;
      }
      return GDObj.SUCCESS;
    } else
      return (that instanceof Var) ? that : GDObj.FAILURE;
  }


  public void unify(KL1Machine mach, KL1Object that) {
    if(mach.UNIFYDEBUG)
      mach.print("Functor.unify with " + this.print() + "," + that.print());
    while (that instanceof Var) {
      KL1Object temp = ((Var)that).refers;
      if (temp == that) { // that is undef cell
	((Var)that).refers = this;
	return;
      } else {
	if(temp instanceof Var && ((Var)temp).refers == that) {
	  mach.resume_goals(temp, this);
	  return;
	}
      }
      that = temp;
    }
    // that is bound
    if (this != that)
      mach.enqueue_unify_terms(this, that);

/*
    if(!(that instanceof Functor))
      return that.unify(this);
    if(functor != ((Functor)that).functor)
      return false;
    if(args.length != ((Functor)that).args.length)
      return false;
    for(int i = 0; i < args.length; i++) {
      if(!(args[i].unify(((Functor)that).args[i])))
	return false;
    }
*/
  }


  public void shallow_unify(KL1Machine mach, KL1Object that) {
    if(mach.UNIFYDEBUG)
      mach.print("Functor.unify with " + this.print() + "," + that.print());
    while (that instanceof Var) {
      KL1Object temp = ((Var)that).refers;
      if (temp == that) { // that is undef cell
	((Var)that).refers = this;
	return;
      } else {
	if(temp instanceof Var && ((Var)temp).refers == that) {
	  mach.enqueue_unify_goal(this, that);
	  return;
	}
      }
      that = temp;
    }
    // that is bound
    if (this != that)
      mach.enqueue_unify_goal(this, that);

/*
    if(!(that instanceof Functor))
      return that.unify(this);
    if(functor != ((Functor)that).functor)
      return false;
    if(args.length != ((Functor)that).args.length)
      return false;
    for(int i = 0; i < args.length; i++) {
      if(!(args[i].unify(((Functor)that).args[i])))
	return false;
    }
*/
  }


  public String toString() {
    String s = functor + "(";
    int i;
    for(i = 0; i < args.length-1; i++) {
      s += args[i].toString();
      s += ",";
    }
    if(i < args.length)
      s += args[i].toString();
    return s + ")";
  }

  public String print() {
    String s = functor + "(";
    int i;
    for(i = 0; i < args.length-1; i++) {
      s += args[i].print();
      s += ",";
    }
    if(i < args.length)
      s += args[i].print();
    return s + ")";
  }
}
