/*
 * GCObj.java -- generic consumer object
 *
 * (C)1993, 1994, 1995 Institute for New Generation Computer Technology
 *	(Read COPYRIGHT for detailed information.) 
 *
 * (C)1996, 1997 Japan Information Processing Development Center
 *      (Read COPYRIGHT-JIPDEC for detailed information.)
 *
 * Copyright (C) 1998 Satoshi KURAMOCHI <satoshi@ueda.info.waseda.ac.jp>
 *
 */

package kl1.lang;

public abstract class GCObj extends KL1Object {
  public static String name = "gcobj";

  public KL1Object active_unify(KL1Machine mach, KL1Object that) {
    return GDObj.FAILURE;
  }


//public int regist();
//public int deallocate();
//public KL1Object close();
//public KL1Object encode(int node);


  protected static Var suspend_new(KL1Machine mach, Var reason,
				   Class class_, KL1Object argv[]) {
    Var newvar = new Var();
    Var var = new Var(newvar);
    GObject newobj = new GObject(class_);
    GTermarray term = new GTermarray(argv);
    KL1Object args[] = { newvar, newobj, term };
    Predicate pred = mach.module_generic.predicate_new_3;
    Goalrec goal = new Goalrec(null, pred, args);
    mach.suspend_goal(goal, reason);
    return var;
  }


  // gc_macro.h
  protected static void error_in_new(KL1Machine mach, String errmsg) {
    mach.fatal(errmsg + "\n\t(in creation of consumer object of class \""
	       + name + "\")");
  }


  protected static void kl1_unify(KL1Machine mach, KL1Object x, KL1Object y) {
    KL1Object args[] = { x, y };
    Goalrec gp =
      new Goalrec(null, mach.module_uterms.predicate_unify__goal_2, args);
    mach.resume_same_prio(gp);
  }


  protected static void unify_value(KL1Machine mach,
				    KL1Object x, KL1Object y) {
    if (!(x instanceof Var) || ((Var)x).refers != x)
      y.shallow_unify(mach, x);
    else
      ((Var)x).refers = y;
  }


  // generic.c
  protected static Var make_hook_var(GCObj obj) {
    Susprec susp = new Susprec();
    Var newvar = new Var(susp);
    susp.refers = newvar;
    susp.first_hook.next = susp.first_hook;
    susp.first_hook.u = obj;
    return newvar;
  }
}
