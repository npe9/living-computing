/*
 * KL1Machine.java -- 
 *
 * (C)1993, 1994, 1995 Institute for New Generation Computer Technology
 *	(Read COPYRIGHT for detailed information.) 
 *
 * (C)1996, 1997 Japan Information Processing Development Center
 *      (Read COPYRIGHT-JIPDEC for detailed information.)
 *
 * Copyright (C) 1998 Satoshi KURAMOCHI <satoshi@ueda.info.waseda.ac.jp>
 *
 */

package kl1.lang;

import java.io.*;
import java.util.*;

public class KL1Machine implements Runnable {
  // compile switch
  final static boolean DIST = false;
  final static boolean UNIFYDEBUG = false;

  private final static String package_name = "kl1.lang.";

  // Global Variables
  public int heaplimit = 1;	// copy of real_heaplimit or 0
  public Goalrec current_queue;	// queue for current priority
  Goalrec resumed_goals;	// spontaneous goals during reduction
  public int current_prio = 0;	// current priority	// 0 ???
  int top_prio;			// highest priority with ready goal
  Prioqrec prioq = new Prioqrec(null, 0, null);
				// priority queue head
  final int real_heaplimit = 1;	// limit of normal heap use
  double maxactiveratio;
  int interrupt_off;
  Goalrec interrupt_qp;
  String command_argv[];
  int suspensions, resumes, copied_susp, cum_susps, cum_resumps;
  public Var reasons[] = new Var[MAXSUSPENSION];  // suspension reasons ???

  boolean higher_priority_goal = false;
  KL1Object suspension_reason;
  KL1Object rest_of_stream = null;

  // param.h
  static final int MAXSUSPENSION = 1024;
				/* how many suspension reasons can exist */
  static final int MAXSTDARGS = 64;
				/* maximum number of arguments handled by
				   tracer or suspension for priority value */
  static final int MAXGENERICARGS = 64;
  				/* maximum number of arguments for
				   generic methods*/
  static final int MAXKLICINT = 2147483647;
				/* maximum KLIC integer */
  static final int MINKLICINT = -2147483648;
				/* minimum KLIC integer */
  static final int HIGHESTPRIO	= MAXKLICINT;
				/* highest priority */
  static final int PRIOQRECBULK = 64;
				/* how many priority queue records to */
				/* allocate at a time */
  //
  boolean finished = false;
  // built-in predicates
  public final Module_builtin module_builtin = new Module_builtin();
  public final Module_generic module_generic = new Module_generic();
  public final Module_integer__arithmetics module_iarith
    = new Module_integer__arithmetics();
  public final Module_unify__term__dcode module_uterms
    = new Module_unify__term__dcode();
  public final Module_floating__arithmetics module_farith =
    new Module_floating__arithmetics();

  public KL1Machine() {}

  public KL1Machine(String argv[]) {
    command_argv = argv;
  }

  public void run() {
    Module module_main = load_module("main");
    Predicate predicate_main_0 = new Predicate(module_main, 0, 0);	// ???

    initiate_prioq();
    Goalrec qp = new Goalrec(null, predicate_main_0, null);
    enqueue_goal(null, HIGHESTPRIO-1, qp);
    current_queue = get_top_priority_queue();
    resumed_goals = null;
    interrupt_off = -1;
//  postmortem_pred = 0;
//  postmortem_args = 0;
    heaplimit = 1;	// ???
    toploop();
  }


  public Module load_module(String name) {
    return load_module(name, false);
  }


  private Hashtable module_table = new Hashtable();

  public Module load_module(String name, boolean quiet) {
    Module module = (Module)module_table.get(name);
    if(module != null)
      return module;
    Class loaded_class;
    int reason = 0 ;
    String s1 = "Module_" + name;
    String s2 = s1 + ".class";
    try {
      if(!quiet)
	System.out.println("Loading " + s2 + ".");
      try {
	// at first, try built-in module
	loaded_class = Class.forName(package_name + s1);
	module = (Module)(loaded_class.newInstance());
      }
      catch(ClassNotFoundException e) {}
      if(module == null) {
	// then try user module
	loaded_class = Class.forName(s1);
	module = (Module)(loaded_class.newInstance());
      }
    }
    catch(ClassNotFoundException e) { reason = 1; }
    catch(IllegalAccessException e) { reason = 2; }
    catch(InstantiationException e) { reason = 3; }
    catch(ExceptionInInitializerError e) { reason = 4; }
    if(!quiet) {
      switch(reason) {	// ???
      case 1:
	fatal(s2 + " not found.");
	break;
      case 2:
	fatal("illegal access");
	break;
      case 3:
	fatal("instantiation error");
	break;
      case 4:
	fatal("exception in initializer");
	break;
      }
    }
    if(module != null) {
      module_table.put(name, module);
      module.init(this);
    }
    return module;
  }


  private void toploop() {
    Goalrec qp = current_queue;
    Predicate toppred = qp.pred;
    Module func = toppred.func;
    while(!finished) {
      func = func.exec(this, qp, toppred);
      qp = current_queue;
      toppred = qp.pred;
    }
  }


  void topmost() {
/*  if (postmortem_pred == 0 || postmortem_args == 0) break;
    klic_fprintf(stderr, "Starting postmortem processing...\n");
    allocp = initiate_prioq(heapp+incrementsize/2); // dirty patch
    qp = (struct goalrec *) allocp;
    qp->pred = postmortem_pred;
    allocp += 2;
    if (isfunctor(postmortem_args)) {
      int arity = arityof(functor_of(postmortem_args));
      int k;
      for (k=0; k<arity; k++) {
	*allocp++ = arg(postmortem_args, k);
      }
    }
    heapp = allocp;
    */
    finished = true;
  }


  // sched.c
  private Prioqrec new_prioqrec() {
    Prioqrec temp;
    while ((temp = prioqrec_free) == null) {
      prioqrec_free = more_prioqrec();
    }
    prioqrec_free = temp.next;
    return temp;
  }


  private void free_prioqrec(Prioqrec pqr) {
    pqr.next = prioqrec_free;
    prioqrec_free = pqr;
  }


  private Prioqrec prioqrec_free = null;

  private Prioqrec more_prioqrec() {
    int k;
    Prioqrec bulk[] = new Prioqrec[PRIOQRECBULK];
    bulk[PRIOQRECBULK-1] = new Prioqrec(null, 0, null);
    for (k = PRIOQRECBULK-1; k != 0; k--) {
      bulk[k-1] = new Prioqrec(bulk[k], 0, null);
    }
    return bulk[0];
  }


  final Predicate queue_empty_pred = new Predicate(new queue_empty(), 0, 0);
  final Predicate topsucceed_pred = new Predicate(new topsucceed(), 0, 0);
//IntAtom t0[] = new IntAtom(0);
  Goalrec goal_queue_tail = new Goalrec(null, queue_empty_pred, null);	// ???
  private static Predicate wait_prio_preds[] = new Predicate[MAXSTDARGS+1];
  Predicate wait_penum_preds[]
    = new Predicate[MAXSTDARGS+1]; /* for inter nodes */

  private Prioqrec pq;
  private static final Prioqrec tail_sentinel = new Prioqrec(null, -1, null);


  private void reinitiate_prioq() {
    pq = new_prioqrec();
    /*
       The tail of the lowest priority level is top level succeed goal.
     */
    pq.next = tail_sentinel;
    pq.prio = 0;
    pq.q = new Goalrec(goal_queue_tail, topsucceed_pred, null);
    prioq.next = pq;
  }


  private void initiate_prioq() {
    Module wait_prio = new wait_prio_routine();
    Module wait_penum = new wait_penum_routine();
    /* Prepare for creating goals that wait for priority value */
    for (int k=0; k<=MAXSTDARGS; k++)
      wait_prio_preds[k] = new Predicate(wait_prio, k, k+3);
    /* Prepare for creating goals that wait for node value */
    for (int k=0; k<=MAXSTDARGS; k++)
      wait_penum_preds[k] = new Predicate(wait_penum, k, k+2);
    reinitiate_prioq();
  }


  public Goalrec enqueue_goal(Goalrec qp, int prio, Goalrec gp) {
//System.out.println("*enqueue_goal()");
    if (prio<0) prio = 0;
    if (current_prio == prio) {
      gp.next = qp;
      qp = gp;
    } else {
      Prioqrec pq = prioq;
      while (pq.next.prio > prio) {
	pq = pq.next;
      }
      if (pq.next.prio == prio) {
	/* there already are some active goals with the same priority */
	pq = pq.next;
	gp.next = pq.q;
	pq.q = gp;
      } else {
	/* there are no active goals with the same priority */
	/* must allocate a new prioqrec entry */
	Prioqrec newpq;
	newpq = new_prioqrec();
	newpq.next = pq.next;
	pq.next = newpq;
	newpq.prio = prio;
	newpq.q = gp;
	gp.next = goal_queue_tail;
      }
      /* interrupt for higher priority goal */
      if (current_prio < prio){
	higher_priority_goal = true;
	heaplimit = 0;
      }
    }
    return qp;
  }


  private void priority_type_error(Goalrec gp) {
    fatal("Non-integer priority specified");
  }


  public Goalrec enqueue_after_waiting(Goalrec qp, KL1Object prio, Goalrec gp,
				       boolean is_relative) {
    while(true) {
      if (prio instanceof IntAtom) {
	int prio_ = ((IntAtom)prio).value;
	return enqueue_goal(qp, (is_relative ? current_prio-prio_ : prio_),
			    gp);
      }
      if (!(prio instanceof Var))
	priority_type_error(qp);
      KL1Object value = ((Var)prio).refers;
      if (value != prio
	  && (!(value instanceof Var) || ((Var)value).refers != prio)) {
	prio = value;
	continue;
      }
      break;
    }
    KL1Object args[] = new KL1Object[gp.pred.arity+(2+3)];
    int k;
    for (k=0; k!=gp.pred.arity; k++) {
      args[k] = gp.args[k];
    }
//  args[k] = makecons(gp.pred);	// cons ???
    args[k] = gp.pred;
    args[k+1] = prio;
    args[k+2] = new IntAtom(is_relative ? 1 : 0);
    Goalrec ng = new Goalrec(null, wait_prio_preds[gp.pred.arity], args);

    Goalrec rsmg = resumed_goals;
    if (rsmg == null) {
      rsmg = ng;
      ng.next = ng;
    } else {
      ng.next = rsmg.next;
      rsmg.next = ng;
    }
    resumed_goals = rsmg;
    heaplimit = 0;
    return qp;
  }


  Goalrec get_top_priority_queue() {
    Goalrec newqp = prioq.next.q;
    current_prio = prioq.next.prio;
    Prioqrec newprioq = prioq.next.next;
    free_prioqrec(prioq.next);
    prioq.next = newprioq;
    return newqp;
  }


  void put_priority_queue(Goalrec qp, int prio) {
    Prioqrec pq = prioq;

    while(pq.next.prio >= prio) {
      pq = pq.next;
    }
    if (pq.next.prio == prio) {
      /* there are some active goals with the same priority */
      pq = pq.next;
      qp.next = pq.q;
      pq.q = qp;
    } else {
      /* there a no goals with the same priority */
      Prioqrec newpq = new_prioqrec();
      newpq.next = pq.next;
      pq.next = newpq;
      newpq.prio = prio;
      newpq.q = qp;
    }
  }


  // intrpt.c
  Goalrec enqueue_resumed_goals(Goalrec qp) {

//    String s = "*enqueue_resumed_goals():  ";

    Goalrec rsmg = resumed_goals;
    if (rsmg != null) {
      Goalrec newqp = rsmg.next;
      rsmg.next = qp;
      qp = newqp;
      resumed_goals = null;
      if (interrupt_off != 0) heaplimit = real_heaplimit;
    }

/*
    for(Goalrec g = qp; g != null; g = g.next)
      s += g.print() + "  ";
    System.out.println(s);
*/
    return qp;
  }


  public void klic_interrupt(Goalrec qp) {
    boolean retry;

//System.out.println("*klic_interrupt()");
    qp = enqueue_resumed_goals(qp);

    do {
      retry = false;

      /* signal handling */

      /* priority support */
      if (higher_priority_goal) {
	higher_priority_goal = false;
	put_priority_queue(qp, current_prio);
	qp = get_top_priority_queue();
	if (interrupt_off != 0) heaplimit = real_heaplimit;
      }
    } while (retry);
    current_queue = qp;
  }


  // susp.h
  final void makenewsusp(Var var, Susprec srec) {
    var.refers = srec;
    srec.refers = var;
    srec.first_hook.next = srec.first_hook;
  }


  final void addhook(Hook oldhook, Hook newhook) {
    newhook.next = oldhook.next;
    oldhook.next = newhook;
  }


  // faisus.c
  private final void do_fail(Goalrec goal) {
    fatal("Reduction Failure");
  }


  public void suspend_goal(Goalrec goal, Var reason) {
    boolean suspended = false;
    Susprec susp;
    goal.prio = current_prio;
    goal.next = null;
    if (reason.refers == reason) {
      /* no goals suspended yet on this variable */
      susp = new Susprec();
      Var newvar = new Var();
      makenewsusp(newvar, susp);
      susp.first_hook.u = goal;
      reason.refers = newvar;
      suspended = true;
    } else {
      /* some goals already has suspended */
      susp = (Susprec)reason.refers;  /* for shm implementation */
      Hook newhook;
      /* generator object ? */
      if (susp.ggobj == null) {
	/* then allocate new hook */
	newhook = new Hook();
	newhook.next = susp.first_hook.next;
	susp.first_hook.next = newhook;
	newhook.u = goal;
	suspended = true;
      } else {
	Susprec gsusp = susp;
	Var ref = (Var)gsusp.refers;
	GGObj gobj = gsusp.ggobj;
	KL1Object tmp = gobj.generate();
	if (tmp != GDObj.SUCCESS) {
	  if ( tmp == GDObj.FAILURE ) {
	    KL1Object retval = gobj.suspend(ref, goal);
	    if(retval != null) {	// ???
	      resume_same_prio(goal);
	    } else {
	      suspended = true;
	    }
	  } else {
	    ref.refers = tmp;
	    resume_same_prio(goal);
	  }
	} else {
	  /* This case, the instantiation by generator object must
	     postponed. Thus:
	     1. ``goal'' is hooked on new variable ``newvar''.
	     2. enqueue unification goal between ``newvar'' and ``ref'' */
	  susp = new Susprec();
	  Var newvar = new Var();
	  makenewsusp(newvar,susp);
	  KL1Object args[] = { reason, newvar };
	  Goalrec newgp =
	    new Goalrec(current_prio,
			module_uterms.predicate_unify__goal_2, args);
	  susp.first_hook.u = goal;
	  suspended = true;
	  resume_same_prio(newgp);
	}
      }
    }
    if (suspended)
      suspensions++;
  }


  public final void interrupt_goal(KL1Object[] args, Predicate pred,
				   int reasonp) {
    Goalrec goal = new Goalrec(null, pred, args);

//System.out.println("*interrupt_goal()");

    if (reasonp == -1) {
      /* Interrupt by some external event, such as: */
      /*   - A higher priority goal got ready for execution */
      /*   - Garbage collection required */
      /* In such cases, the interrupted goal is pushed down to the queue. */
      Goalrec rsmg = resumed_goals;
      if (rsmg == null) {
	goal.next = goal;
      } else {
	goal.next = rsmg.next;
	rsmg.next = goal;
      }
      resumed_goals = goal;
//System.out.println("*interrupt_goal():  a higher priority goal got ready");
      return;
    } else if (reasonp == 0) {
      do_fail(goal);
    } else {
      /* First, try dereference */
      /* Compiled out code won't dereference more than one level */
      for (int rp = 0; rp < reasonp; rp++) {
	Var v = reasons[rp], iv = v, ov;
	do {
	  KL1Object tmp = v.refers;
	  if (!(tmp instanceof Var)) {
	    iv.refers = tmp;
	    resume_same_prio(goal);
	    return;
	  }
	  ov = v;
	  v = (Var)tmp;
	} while (v.refers != ov);
      }
      /* OK, the goal should really be suspended */
//System.out.println("*suspended");
      goal.prio = current_prio;
      goal.next = null;
      {
	boolean redo_request = false;
	do {
	  Var tmp;
	  KL1Object tmp1;
	  tmp = reasons[--reasonp];
	  while (true) {
	    tmp1 = tmp.refers;
	    if (!(tmp1 instanceof Var)) {
	      resume_same_prio(goal);
	      return;
	    }
	    if (((Var)tmp1).refers == tmp) break;
	    tmp = (Var)tmp1;
	  }

	  if (tmp == tmp1) {
	    /* no goals suspended yet on this variable */
	    Susprec susp = new Susprec();
	    Var newvar = new Var();
	    makenewsusp(newvar, susp);
	    susp.first_hook.u = goal;
	    tmp.refers = newvar;
	  } else {
	    /* some goals already has suspended */
	    Susprec susp = (Susprec)tmp1;
	    /* generator object ? */
	    if(susp.ggobj == null) {
	      if (susp.first_hook.next.u == goal) {
		/* If the second hook is for the same goal, do nothing.
		   This includes the case where there's only one hook,
		   because of the loop structure of the hook chain. */
	      } else {
		Hook newhook = new Hook();
		addhook(susp.first_hook, newhook);
		newhook.u = goal;
	      }
	    } else {
	      /* generator object */
	      Susprec gsusp = susp;
	      Var ref = (Var)gsusp.refers;
	      GGObj gobj = gsusp.ggobj;
	      KL1Object tmp2 = gobj.generate();

	      if(tmp2 == GDObj.FAILURE) {
		if(gobj.suspend(ref, goal) != GDObj.SUCCESS)
		  redo_request = true;
	      } else {
		redo_request = true;
		if(tmp2 != GDObj.SUCCESS) {
		  ref.refers = tmp2;
		} /* else GC request */
	      }
	    }
	  }
	} while (reasonp > 0);
	if (redo_request) {
	  resume_same_prio(goal);
	} else {
	  suspensions++;
	}
      }
    }
  }


  public final boolean check_stack_for_alternatively(int reasonp) {
    while (reasonp > 0) {
      /* suspension stack is not empty */
      KL1Object tmp, tmp1;
      Var var = reasons[--reasonp];
      Susprec susp;
      tmp = var;
      if (tmp instanceof Var) {
	while (true) {
	  tmp1 = ((Var)tmp).refers;
	  if (tmp == tmp1)
	    return false;
	  if (!(tmp1 instanceof Var)) {
	    var.refers = tmp1;
	    return true;
	  }
	  if (tmp == ((Var)tmp1).refers) break;
	  tmp = tmp1;
	}
	susp = (Susprec)tmp1;
	/* generator object ? */
	if (susp.ggobj != null) {
	  Var ref = (Var)susp.refers;
	  tmp = susp.ggobj.generate();
	  if (tmp == GDObj.SUCCESS)
	    return false;
	  ref.refers = tmp;
	  var.refers = tmp;
	  return true;
	}
      } else {
	var.refers = tmp;
	return true;
      }
    }
    return false;
  }


  // unify.c
  public final void enqueue_unify_terms(KL1Object x, KL1Object y) {
    KL1Object args[] = { x, y };
    Goalrec gp =
      new Goalrec(current_prio, module_uterms.predicate_unify_2, args);
    resume_same_prio(gp);
  }


  final void enqueue_unify_goal(KL1Object x, KL1Object y) {
    KL1Object[] args = { x, y };
    Goalrec gp =
      new Goalrec(current_prio, module_uterms.predicate_unify__goal_2, args);
    resume_same_prio(gp);
  }


  // Resume a goal with the same priority as current
  final void resume_same_prio(Goalrec gp) {

//System.out.println("*resume_same_prio()");

    if (resumed_goals == null) {
      resumed_goals = gp;
      gp.next = gp;
    } else {
      gp.next = resumed_goals.next;
      resumed_goals.next = gp;
    }
    heaplimit = 0;
  }


  // resume the goals which has been hooked to variable `x'.
  // by the unification with `y'
  final void resume_goals(KL1Object x, KL1Object y) {
    /* Variable x with suspended goals is instantiated here */
    /* x points suspension record directly. */
    Susprec susprecord = (Susprec)x;

//System.out.println("*resume_goals()");

    if(susprecord.ggobj != null) {
      /* generator_object */
      Susprec gsusp = susprecord;
      GGObj gobj = gsusp.ggobj;
      KL1Object tempallocp;
      if(!gobj.active_unify(this, y)) {
	/* failed */
	KL1Object tmp = gobj.generate();
	if(tmp == null)
	  /* x is a reference to suspension record. thus
	     derefone is needed for enqueue */
	  enqueue_unify_goal(((Susprec)x).refers, y);
	else if(tmp == GDObj.FAILURE)
	  fatal("illegal situation in generator unification");
	else {
	  ((Var)gsusp.refers).refers =  tmp;
	  if(tmp instanceof Var && tmp == ((Var)tmp).refers) {
	    ((Var)tmp).refers = y;
	  } else {
	    tmp.unify(this, y);
	  }
	}
      }
    } else {
      Hook top = susprecord.first_hook.next;
      Hook loopp = top;
  
      ((Var)susprecord.refers).refers = y;
  
      do {
	KL1Object u = loopp.u;
	if (u != null) {
	  if (u instanceof GCObj) {
	    GCObj obj = (GCObj)u;
	    KL1Object tmpval = null;
	    KL1Object keepp = loopp.u;
	    loopp.u = null;
	    KL1Object result = obj.active_unify(this, y);
	    if(result == GDObj.FAILURE)
	      fatal("Unification failure on a consumer object");
	    else if(result == GDObj.SUCCESS) {
	      if(rest_of_stream == null) {
		loopp = loopp.next;
		continue;
	      }
	      tmpval = rest_of_stream;
	    }
	    /*else if(result == GDObj.GCREQUEST) {	// ???
	      // This case, make the hook chain which contains
	      // rest of consumer objects and goals.
	      Var newvar = new Var();
	      susprecord.first_hook.next = loopp;
	      loopp.u = keepp;
	      susprecord.refers = newvar;
	      newvar.refers = susprecord;
	      enqueue_unify_goal(y, newvar);
	      // exit the loop
	      return;
	    }*/
	    else
	      tmpval = result;
	    Susprec susp = new Susprec();
	    Var newvar = new Var();
	    makenewsusp(newvar, susp);
	    susp.first_hook.u = obj;
	    if (((Var)tmpval).refers == tmpval)
	      ((Var)tmpval).refers = newvar;
	    else
	      enqueue_unify_goal(tmpval, newvar);
	  } else {
	    Goalrec g = (Goalrec)loopp.u;
	    if (g.next == null) {
	      int gp = g.prio;
	      if (gp != current_prio) {
		enqueue_goal(null, gp, g);
	      } else {
		resume_same_prio(g);
	      }
	      resumes++;
	    }
	  }
	}
	loopp = loopp.next;
      } while (loopp != top);
    }
  }


  // print.c
  public final static void print(String s) {
    System.out.println(s);	// ???
  }


  public final static void printl(KL1Object x) {
    System.out.println(x.print());
  }


  // debug.c
  public final static void debug_print(String s) {
    System.out.print(s);
  }


  public final void fatal(String s) {
    System.out.println("Fatal Error: " + s);
    finished = true;	// ???
//  longjmp(klic_topmost, 1);	// ???
  }


  // gunix.kl1
  public GObject fopen(GString path_, String mode) {
    String path = path_.toString();
    try {
      File file = new File(path);
      Object f;
      if(mode.equals("r"))
	f = new FileInputStream(file);
      else if(mode.equals("w"))
	f = new FileOutputStream(file);
      else if(mode.equals("a"))
	f = new FileOutputStream(file);
      else if(mode.equals("r+"))
	f = new FileInputStream(file);
      else
	return null;
      return new GObject(f);
    }
    catch(FileNotFoundException e) { return null; }
    catch(IOException e) { return null; }
  }


  // xio.c
  public void klic_putc(int c, PrintStream out) {
    out.write(c);	// ???
  }


  public int klic_getc(InputStream in) {
    int c = -1;
    try {
      c = in.read();	// ???
    } catch(IOException e) {}
    return c;
  }


  public int klic_fread(byte b[], InputStream in) {
    int n = -1;
    try {
      n = in.read(b);	// ???
    } catch(IOException e) {}
    return n;
  }


/*public int klic_fread(byte pt[], int size, int items, InputStream in) {
    return in.read(pt, 0, size*items);	// ???
  }*/


/*public void klic_fwrite(byte pt[], int size, int items, PrintStream out) {
    try {
      out.write(pt, 0, size*items);
    } catch(IOException e) {}
  }*/


  public int klic_fwrite(String s, PrintStream out) {
    out.print(s);
    return s.length();
  }


  public boolean feof(Object s) {
    if(s instanceof InputStream) {
      try {
	if(((InputStream)s).available() > 0)
	  return false;
	else
	  return true;	// ???
      }
      catch(EOFException e) { return true; }
      catch(IOException e) { return false; }
    } else
      return false;
  }


  // cmphsh.c
  public KL1Object builtin_compare_terms(KL1Object x, KL1Object y) {
    final IntAtom lt = new IntAtom(-1);
    final IntAtom eq = new IntAtom(0);
    final IntAtom gt = new IntAtom(1);

    while(true) {
      y = y.deref();
      if(y instanceof Var)
	return y;
      x = x.deref();
      if(x instanceof Var)
	return x;
      else if (x instanceof IntAtom) {
	if (!(y instanceof IntAtom)) return lt;
	if (((IntAtom)x).value < ((IntAtom)y).value) return lt;
	if (((IntAtom)x).value > ((IntAtom)y).value) return gt;
	return eq;
      } else if(x instanceof SymAtom) {
	if (y instanceof IntAtom) return gt;
	return new IntAtom(((SymAtom)x).name.compareTo(((SymAtom)y).name));// ???
      } else if(x instanceof Cons) {
	if (y instanceof IntAtom || y instanceof SymAtom) return gt;
	if (!(y instanceof Cons)) return lt;
	KL1Object tmp = builtin_compare_terms(((Cons)x).car, ((Cons)y).car);
	if (!(tmp instanceof IntAtom) || ((IntAtom)tmp).value != 0) return tmp;
	x = ((Cons)x).cdr;
	y = ((Cons)y).cdr;
	continue;
      } else if(x instanceof Functor) {
	if (!(y instanceof Functor)) return gt;
	if (!(x instanceof GDObj)) {	// ???
	  if (y instanceof GDObj) return lt;	// ???
	  int t = ((Functor)x).functor.compareTo(((Functor)y).functor);	// ???
	  if(t != 0) return new IntAtom(t);
	  int arity = ((Functor)x).args.length;
	  int k;
	  for (k = 0; k < arity-1; k++) {
	    KL1Object tmp =
	      builtin_compare_terms(((Functor)x).args[k], ((Functor)y).args[k]);
	    if (!(tmp instanceof IntAtom) || ((IntAtom)tmp).value != 0)
	      return tmp;
	  }
	  x = ((Functor)x).args[k];
	  y = ((Functor)y).args[k];
	  continue;
	} else {
	  if (!(y instanceof GDObj)) return gt;	// ???
	  int t = ((Functor)x).functor.compareTo(((Functor)y).functor);	// ???
	  if(t != 0) return new IntAtom(t);
	  return ((GDObj)x).compare((GDObj)y);	// ???
	}
      }
    }
  }


  // bb.c
  // built-in body predicates
  private static final int bblt_add = 0;	// binary
  private static final int bblt_sub = 1;
  private static final int bblt_mult = 2;
  private static final int bblt_div = 3;
  private static final int bblt_mod = 4;
  private static final int bblt_and = 5;
  private static final int bblt_or = 6;
  private static final int bblt_xor = 7;
  private static final int bblt_rshift = 8;
  private static final int bblt_lshift = 9;
  private static final int bblt_plus = 10;	// unary
  private static final int bblt_minus = 11;
  private static final int bblt_complement = 12;


  private KL1Object builtin_body_3(KL1Object x, KL1Object y, int body,
				   Predicate pred, String name) {
    while(true) {
//  deref_x:
      if (x instanceof IntAtom) {
//    x_ok:
//    deref_y:
	if (y instanceof IntAtom) {
//	ok:
	  int z = 0;
	  switch(body) {
	  case bblt_add:
	    z = ((IntAtom)x).value + ((IntAtom)y).value;
	    break;
          case bblt_sub:
	    z = ((IntAtom)x).value - ((IntAtom)y).value;
	    break;
          case bblt_mult:
	    z = ((IntAtom)x).value * ((IntAtom)y).value;
	    break;
          case bblt_div:
	    z = ((IntAtom)x).value / ((IntAtom)y).value;
	    break;
          case bblt_mod:
	    z = ((IntAtom)x).value % ((IntAtom)y).value;
	    break;
          case bblt_and:
	    z = ((IntAtom)x).value & ((IntAtom)y).value;
	    break;
          case bblt_or:
	    z = ((IntAtom)x).value | ((IntAtom)y).value;
	    break;
          case bblt_xor:
	    z = ((IntAtom)x).value ^ ((IntAtom)y).value;
	    break;
          case bblt_rshift:
	    z = ((IntAtom)x).value >> ((IntAtom)y).value;
	    break;
          case bblt_lshift:
	    z = ((IntAtom)x).value << ((IntAtom)y).value;
	    break;
	  }
	  return new IntAtom(z);
	} else if (y instanceof Var) {
	  KL1Object yy;
	  yy = ((Var)y).deref();
	  if (yy instanceof IntAtom) {
	    y = yy;
//	    goto ok;
	    continue;
	  } else if (yy instanceof Var) {
	    if (yy == y) {
	      return suspend_builtin_3(y, x, y, pred);
	    } else {
	      KL1Object yyy = ((Var)yy).deref();
	      if (yyy == y) {
		return suspend_builtin_3(y, x, y, pred);
	      } else {
		y = yy;
//		goto deref_y;
		continue;
	      }
	    }
	  }
	}
      } else if (x instanceof Var) {
	KL1Object xx;
	xx = ((Var)x).deref();
	if (xx instanceof IntAtom) {
	  x = xx;
//	  goto x_ok;
	  continue;
	} else if (xx instanceof Var) {
	  if (xx == x) {
	    return suspend_builtin_3(x, x, y, pred);
	  } else {
	    KL1Object xxx = ((Var)xx).deref();
	    if (xxx == x) {
	      return suspend_builtin_3(x, x, y, pred);
	    } else {
	      x = xx;
//	      goto deref_x;
	      continue;
	    }
	  }
	}
      }
      builtin_3_type_error(x, y, pred, name);
      break;		// never reached
    }
    return null;	// never reached
  }


  private KL1Object builtin_body_2(KL1Object x, int body, Predicate pred,
				   String name) {
    while(true) {
//  deref_x:
      if (x instanceof IntAtom) {
//    ok:
	int z = 0;
	switch(body) {
	case bblt_plus:
	  z = +((IntAtom)x).value;
	  break;
	case bblt_minus:
	  z = -((IntAtom)x).value;
	  break;
	case bblt_complement:
	  z = ~((IntAtom)x).value;
	  break;
	}
	return new IntAtom(z);
      } else if (x instanceof Var) {
	KL1Object xx = ((Var)x).refers;
	if (xx instanceof IntAtom) {
	  x = xx;
//  	  goto ok;
	  continue;
	} else if (xx instanceof IntAtom) {
	  if (xx == x) {
	    return suspend_builtin_2(x, pred);
	  } else {
	    KL1Object xxx = ((Var)xx).refers;
	    if (xxx == x) {
	      return suspend_builtin_2(x, pred);
	    } else {
	      x = xx;
//	      goto deref_x;
	      continue;
	    }
	  }
	}
      }
      builtin_2_type_error(x, pred, name);
      break;		// never reached
    }
    return null;	// never reached
  }


  private void enqueue_as_resumed(Goalrec goal) {
    Goalrec rsmg = resumed_goals;
    if (rsmg == null) {
      rsmg = goal;
      goal.next = goal;
    } else {
      goal.next = rsmg.next;
      rsmg.next = goal;
    }
    resumed_goals = rsmg;
    heaplimit = 0;
  }


  private KL1Object suspend_builtin_3(KL1Object v, KL1Object x, KL1Object y,
				      Predicate pred) {
    KL1Object z = new Var();
    KL1Object args[] = { x, y, z };
    Goalrec goal = new Goalrec(null, pred, args);
    enqueue_as_resumed(goal);
    return z;
  }


  private KL1Object suspend_builtin_2(KL1Object v, Predicate pred) {
    KL1Object z = new Var();
    KL1Object args[] = { v, z };
    Goalrec goal = new Goalrec(null, pred, args);
    enqueue_as_resumed(goal);
    return z;
  }


  private void builtin_3_type_error(KL1Object x, KL1Object y, Predicate pred,
				    String name) {
    fatal("Argument type error in builtin predicate: " + name);
  }

  private void builtin_2_type_error(KL1Object x, Predicate pred, String name) {
    fatal("Argument type error in builtin predicate: " + name);
  }


  public KL1Object add_3(KL1Object x, KL1Object y) {
    return builtin_body_3(x, y, bblt_add, module_iarith.predicate_add_3,
			  "add/3");
  }

  public KL1Object subtract_3(KL1Object x, KL1Object y) {
    return builtin_body_3(x, y, bblt_sub, module_iarith.predicate_subtract_3,
			  "subtract/3");
  }

  public KL1Object multiply_3(KL1Object x, KL1Object y) {
    return builtin_body_3(x, y, bblt_mult, module_iarith.predicate_multiply_3,
			  "multiply/3");
  }

  public KL1Object divide_3(KL1Object x, KL1Object y) {
    return builtin_body_3(x, y, bblt_div, module_iarith.predicate_divide_3,
			  "divide/3");
  }

  public KL1Object modulo_3(KL1Object x, KL1Object y) {
    return builtin_body_3(x, y, bblt_mod, module_iarith.predicate_modulo_3,
			  "modulo/3");
  }

  public KL1Object and_3(KL1Object x, KL1Object y) {
    return builtin_body_3(x, y, bblt_and, module_iarith.predicate_and_3,
			  "and/3");
  }

  public KL1Object or_3(KL1Object x, KL1Object y) {
    return builtin_body_3(x, y, bblt_or, module_iarith.predicate_or_3, "or/3");
  }

  public KL1Object exclusive_or_3(KL1Object x, KL1Object y) {
    return builtin_body_3(x, y, bblt_xor,
			  module_iarith.predicate_exclusive__or_3,
			  "exclusive_or/3");
  }

  public KL1Object shift_right_3(KL1Object x, KL1Object y) {
    return builtin_body_3(x, y, bblt_rshift,
			  module_iarith.predicate_shift__right_3,
			  "shift_right/3");
  }

  public KL1Object shift_left_3(KL1Object x, KL1Object y) {
    return builtin_body_3(x, y, bblt_lshift,
			  module_iarith.predicate_shift__left_3,
			  "shift_left/3");
  }

  public KL1Object plus_2(KL1Object x) {
    return builtin_body_2(x, bblt_plus, module_iarith.predicate_plus_2,
			  "plus/2");
  }

  public KL1Object minus_2(KL1Object x) {
    return builtin_body_2(x, bblt_minus, module_iarith.predicate_minus_2,
			  "minus/2");
  }

  public KL1Object complement_2(KL1Object x) {
    return builtin_body_2(x, bblt_complement,
			  module_iarith.predicate_complement_2,
			  "complement/2");
  }

/*public KL1Object fix_2(KL1Object x) {
  }*/


  // gcode.c
  Predicate locate_predicate_in_module(String mname, String pname,
				       int arity) {
    Module module = load_module(mname);
    if(module == null)
      return null;
    else
      return module.get_pred(pname, arity);
  }
}


// sched.c
final class queue_empty extends Module {
  public final Predicate predicate_queue_empty_0;

  public queue_empty() {
    predicate_queue_empty_0 = new Predicate(this, 0, 0);
    preds = new Predinfo[1];
    preds[0] = new Predinfo("queue_empty", predicate_queue_empty_0);
    info = new Modinfo("queue_empty", preds);
  }

  public Module exec(KL1Machine mach, Goalrec qp, Predicate toppred) {
//    System.out.println("queue_empty");

    qp = mach.get_top_priority_queue();
    mach.current_queue = qp;
    return qp.pred.func;
  }
}


final class wait_prio_routine extends Module {
  public Module exec(KL1Machine mach, Goalrec qp, Predicate toppred) {
    int arity = toppred.pred;
    KL1Object prio = qp.args[arity+1];
    boolean is_relative = ((IntAtom)qp.args[arity+2]).value == 1;

    qp.pred = (Predicate)qp.args[arity];
//  qp.pred = (Predicate)consp(qp.args[arity]);		// cons ???
    qp = mach.enqueue_after_waiting(qp.next, prio, qp, is_relative);
    mach.current_queue = qp;
    return qp.pred.func;
  }
}


final class wait_penum_routine extends Module {
  public Module exec(KL1Machine mach, Goalrec qp, Predicate toppred) {
/*
    int arity = toppred.pred;
    q penum = qp.args[arity+1];

    qp.pred = (struct predicate *)consp(qp.args[arity]);
    qp = enqueue_throw_goal(penum, qp, qp.next, allocp);
    heapp = allocp;
    current_queue = qp;
*/
    return qp.pred.func;
  }
}


// kmain.c
final class topsucceed extends Module {
  public final Predicate predicate_topsucceed_0;

  public topsucceed() {
    predicate_topsucceed_0 = new Predicate(this, 0, 0);
    preds = new Predinfo[1];
    preds[0] = new Predinfo("topsucceed", predicate_topsucceed_0);
    info = new Modinfo("topsucceed", preds);
  }

  public Module exec(KL1Machine mach, Goalrec qp, Predicate toppred) {
//    System.out.println("topsucceed");

    if (mach.suspensions == mach.resumes) {
      mach.topmost();
    }
    if(mach.suspensions-mach.resumes > 0) {	// ???
      mach.fatal("" + (mach.suspensions-mach.resumes)
		 + " perpetually suspending goals found");
    }
    return null;
  }
}

