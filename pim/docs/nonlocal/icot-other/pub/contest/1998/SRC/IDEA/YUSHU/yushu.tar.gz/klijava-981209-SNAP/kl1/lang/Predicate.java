/*
 * Predicate.java -- predicate
 *
 * (C)1993, 1994, 1995 Institute for New Generation Computer Technology
 *	(Read COPYRIGHT for detailed information.) 
 *
 * (C)1996, 1997 Japan Information Processing Development Center
 *      (Read COPYRIGHT-JIPDEC for detailed information.)
 *
 * Copyright (C) 1998 Satoshi KURAMOCHI <satoshi@ueda.info.waseda.ac.jp>
 *
 */

package kl1.lang;

public class Predicate extends KL1Object {
  public Module func;		// pointer to function
  public int pred;		// predicate number
  public int arity;		// number of args

  public Predicate(Module func, int pred, int arity) {
    this.func = func;
    this.pred = pred;
    this.arity = arity;
  }

  public String toString() {
    return "{" + func + ", " + pred + ", " + arity + "}";
  }

  public boolean equals(Predicate that) {
    return (func == that.func && pred == that.pred && arity == that.arity);
  }
}
