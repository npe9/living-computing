/*
 * Prioqrec.java -- priority queue record
 *
 * (C)1993, 1994, 1995 Institute for New Generation Computer Technology
 *	(Read COPYRIGHT for detailed information.) 
 *
 * (C)1996, 1997 Japan Information Processing Development Center
 *      (Read COPYRIGHT-JIPDEC for detailed information.)
 *
 * Copyright (C) 1998 Satoshi KURAMOCHI <satoshi@ueda.info.waseda.ac.jp>
 *
 */

package kl1.lang;

class Prioqrec {
  Prioqrec next;
  int prio;			/* signed, to use -1 as sentinel */
  Goalrec q;

  Prioqrec() {
    next = null;
    prio = 0;
    q = null;
  }

  Prioqrec(Prioqrec next, int prio, Goalrec q) {
    this.next = next;
    this.prio = prio;
    this.q = q;
  }
}
