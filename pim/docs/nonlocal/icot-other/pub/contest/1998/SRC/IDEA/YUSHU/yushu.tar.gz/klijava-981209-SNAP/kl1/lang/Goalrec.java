/*
 * Goalrec.java -- goal record
 *
 * (C)1993, 1994, 1995 Institute for New Generation Computer Technology
 *	(Read COPYRIGHT for detailed information.) 
 *
 * (C)1996, 1997 Japan Information Processing Development Center
 *      (Read COPYRIGHT-JIPDEC for detailed information.)
 *
 * Copyright (C) 1998 Satoshi KURAMOCHI <satoshi@ueda.info.waseda.ac.jp>
 *
 */

package kl1.lang;

public class Goalrec extends KL1Object {
  public Goalrec next;		/* pointer to next goal */
  public int prio;		// priority (suspended) ???
  public Predicate pred;	/* predicate descriptor of the goal */
  public KL1Object args[];	/* arguments */

  public Goalrec(Goalrec next, Predicate pred, KL1Object args[]) {
    this.next = next;
    this.prio = 0;
    this.pred = pred;
    if(args != null) {
      this.args = new KL1Object[args.length];
      for(int i = 0; i < args.length; i++)
	this.args[i] = args[i];
    } else
      this.args = null;
  }


  public Goalrec(int prio, Predicate pred, KL1Object args[]) {
    this.next = null;
    this.prio = prio;
    this.pred = pred;
    if(args != null) {
      this.args = new KL1Object[args.length];
      for(int i = 0; i < args.length; i++)
	this.args[i] = args[i];
    } else
      this.args = null;
  }


  public String toString() {
    return("{" + ((next != null) ? "next" : "null") + ", " + pred + ", " +
	   ((args != null) ? "args[" + args.length + "]" : "null") + "}");
  }


  public String print() {	// ???
    if(pred.func == null)
      return "pred.func == null";
    if(pred.func.preds == null)
      return "pred.func.preds == null";
//  return pred.func.toString() + ":" + pred.func.info.preds[pred.pred].name;
    return pred.func.toString() + ":" + pred.func.print(pred.pred);
  }
}

