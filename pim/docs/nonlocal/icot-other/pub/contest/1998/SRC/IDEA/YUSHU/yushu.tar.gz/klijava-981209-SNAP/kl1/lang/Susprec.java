/*
 * Susprec.java -- suspension record
 *
 * (C)1993, 1994, 1995 Institute for New Generation Computer Technology
 *	(Read COPYRIGHT for detailed information.) 
 *
 * (C)1996, 1997 Japan Information Processing Development Center
 *      (Read COPYRIGHT-JIPDEC for detailed information.)
 *
 * Copyright (C) 1998 Satoshi KURAMOCHI <satoshi@ueda.info.waseda.ac.jp>
 *
 */

package kl1.lang;

public final class Susprec extends Var {
//KL1Object backpt;
  Hook first_hook;
  GGObj ggobj;

  public Susprec() {
    refers = null;
    first_hook = new Hook();
    ggobj = null;
  }

  public String toString() {
    return "susp_" + Integer.toHexString(hashCode());
  }

  public String print() {
    if(refers == this)
      return toString();
    else
      return refers.print();
  }
}
