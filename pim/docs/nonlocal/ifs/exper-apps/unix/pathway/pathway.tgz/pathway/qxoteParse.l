%{
/**
 ** qXote parser (lex program)
 **/
#define STRSIZE 64
int strcnt = 0;
char string[STRSIZE+1] = {0};
%}
%p 5000
%a 5000
%start STR
%%
<INITIAL>"from"         return(FROM);
<INITIAL>"now"          return(NOW);
<INITIAL>"next"         return(NEXT);
<INITIAL>"stage"        return(STAGE);
<INITIAL>"next_stage"   return(NEXT_STAGE);
<INITIAL>"name"         {yylval = (int)yytext; return(NAME);}
<INITIAL>"names"        {yylval = (int)yytext; return(NAMES);}
<INITIAL>"element1"     {yylval = (int)yytext; return(ELEMENT1);}
<INITIAL>"element2"     {yylval = (int)yytext; return(ELEMENT2);}
<INITIAL>"to"           return(TO);
<INITIAL>"with"         return(WITH);
<INITIAL>"result"       return(RESULT);
<INITIAL>"result1"      return(RESULT1);
<INITIAL>"result2"      return(RESULT2);
<INITIAL>"path"         return(PATH);
<INITIAL>"path1"        return(PATH1);
<INITIAL>"path2"        return(PATH2);
<INITIAL>"place"        return(PLACE);
<INITIAL>"input"        return(INPUT);
<INITIAL>"location"     return(LOCATION);
<INITIAL>"time"         return(TIME);
<INITIAL>"status"       return(STATUS);
<INITIAL>"enzyme"       return(ENZYME);
<INITIAL>"long_name"    {yylval = (int)yytext; return(LONG_NAME);}
<INITIAL>"="            return(EQ);
<INITIAL>"["            return(START);
<INITIAL>"]"            return(END);
<INITIAL>","            return(COMMA);
<INITIAL>"\n"           return(NL);
<INITIAL>"state"        return(STATE);
<INITIAL>"pathway"      return(PATHWAY);
<INITIAL>"begin"        {yylval = (int)yytext; return(TYPE_A);}
<INITIAL>"duplicate"    {yylval = (int)yytext; return(TYPE_A);}
<INITIAL>"express"      {yylval = (int)yytext; return(TYPE_A);}
<INITIAL>"receive"      {yylval = (int)yytext; return(TYPE_C);}
<INITIAL>"activate"     {yylval = (int)yytext; return(ACTIVATE);}
<INITIAL>"increase"     {yylval = (int)yytext; return(TYPE_C);}
<INITIAL>"phosphorylate" {yylval = (int)yytext; return(TYPE_C);}
<INITIAL>"intake"       {yylval = (int)yytext; return(TYPE_C);}
<INITIAL>"suppress"     {yylval = (int)yytext; return(TYPE_C);}
<INITIAL>"depolarize"   {yylval = (int)yytext; return(TYPE_C);}
<INITIAL>"secrete"      {yylval = (int)yytext; return(TYPE_C);}
<INITIAL>"decrease"     {yylval = (int)yytext; return(TYPE_C);}
<INITIAL>"translocate"  {yylval = (int)yytext; return(TYPE_C);}
<INITIAL>"inactivate"   {yylval = (int)yytext; return(TYPE_C);}
<INITIAL>"unbind"       {yylval = (int)yytext; return(TYPE_C);}
<INITIAL>"hydrolyze"    {yylval = (int)yytext; return(TYPE_C);}
<INITIAL>"produce"      {yylval = (int)yytext; return(TYPE_C);}
<INITIAL>"bind_element" {yylval = (int)yytext; return(BIND_ELEMENT);}
<INITIAL>"results"      {yylval = (int)yytext; return(RESULTS);}
<INITIAL>"list"         {yylval = (int)yytext; return(LIST);}
<INITIAL>"infect"       {yylval = (int)yytext; return(INFECT);}
<INITIAL>"bind"         {yylval = (int)yytext; return(BIND);}
<INITIAL>"form"         {yylval = (int)yytext; return(FORM);}
<INITIAL>"compound"     {yylval = (int)yytext; return(COMPOUND);}
<INITIAL>"become"       {yylval = (int)yytext; return(BECOME);}
<INITIAL>"signal"       {yylval = (int)yytext; return(SIGNAL);}
<INITIAL>"release"      {yylval = (int)yytext; return(RELEASE);}
<INITIAL>"infiltrate"   {yylval = (int)yytext; return(INFILTRATE);}
<INITIAL>"cross_link"   {yylval = (int)yytext; return(CROSS_LINK);}
<INITIAL>"exocytosis"   {yylval = (int)yytext; return(EXOCYTOSIS);}
<INITIAL>"develope"     {yylval = (int)yytext; return(DEVELOPE);}
<INITIAL>"involute"     {yylval = (int)yytext; return(INVOLUTE);}
<INITIAL>"differentiate" {yylval = (int)yytext;return(DIFFERENTIATE);}
<INITIAL>"blood_glucose" {yylval = (int)yytext;return(BLOOD_GLUCOSE);}
<INITIAL>"synthesize"   {yylval = (int)yytext; return(SYNTHESIZE);}
<INITIAL>"energize"     {yylval = (int)yytext; return(ENERGIZE);}
<INITIAL>"accept"       {yylval = (int)yytext; return(ACCEPT);}
<INITIAL>"arrive"       {yylval = (int)yytext; return(ARRIVE);}
<INITIAL>[A-Z]+[a-zA-Z0-9_]*         {yylval = (int)yytext; return(UPPER);}
<INITIAL>[a-z]+[a-zA-Z0-9_]*         {yylval = (int)yytext; return(LOWER);}
<INITIAL>\"             {
                        strcnt = 0;
                        BEGIN STR;
                        }
<STR>[^\"\n]*           {yylval = (int)yytext; return(Q_STRING);}
<STR>\"                 {BEGIN INITIAL;}
%%
