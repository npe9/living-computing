/* $Id: api_example.c,v 1.1 1994/11/14 07:28:52 m-gniibe Exp $ */

#include <stdio.h>
#include "mq.h"

int
main (argc, argv)
     int argc;
     char *argv[];
{
  int r;

  /* $B=i4|2=(B */
  initialize (TRUE);

  /* $B%W%m%0%i%`$N%m!<%I(B */
  if (load_program ("pathwayDemo.qxt") < 0)
    {			/* ^-- MQ $B$N(B program $B$N%U%!%$%kL>(B */
      /* $BIi$NCM$O<:GT(B (parse error, fail $B$,(B open $B$G$-$J$$$J$I$J$I(B */
      fprintf (stderr, "Failed: %s\n", result);
      exit (1);
    }

  /* Query $B$rH/9T(B. */
  r =
    start_query ("?- arrive[name=\"EGF\",place=epidermis]/[path=P,result=R].");
  if (r < 0) /* $BIi$NCM$O<:GT(B (parse error $B$J$I$J$I(B) */
    {
      fprintf (stderr, "Failed: %s\n", result);
      exit (1);
    }

  /* $BEz$N3MF@(B */
  while (get_answer ())
    {
      printf ("answer:%s\n", result);
    }

  /* $B8e=hM}(B */
  end_query ();
}
