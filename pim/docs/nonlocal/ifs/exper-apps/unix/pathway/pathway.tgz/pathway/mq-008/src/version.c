/* Micro Quixote                 */
/* Copyright (C) 1993, 1994 ICOT */
/* Written by gniibe             */
/* $Id: version.c.template,v 1.1 1994/09/19 01:55:42 m-gniibe Exp $ */

/* version of Micro Quixote */
char *mq_version = "008 1994/11/13";
