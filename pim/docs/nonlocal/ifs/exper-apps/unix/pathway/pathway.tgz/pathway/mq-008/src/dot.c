/* Micro Quixote           */
/* Copyright (C) 1993 ICOT */
/* Written by gniibe       */
/* $Id: dot.c,v 1.2 1994/09/19 02:06:10 m-gniibe Exp $ */

/* dot handling routines */

#include <stdio.h>
#include "mq.h"
#include "internal.h"
#include "extern.h"

MQ_VTerm *eval_dot (dot)
     MQ_Dot dot;
{
  MQ_Obj obj;
  int i;

  if (dot->vterm->type != TT_Obj)
    return NULL;
  obj = (MQ_Obj)dot->vterm;
  for (i=0; i<obj->arity; i++)
    if (obj->attr[i].label == dot->label)
      return &(obj->attr[i].vterm);
  return NULL;
}
