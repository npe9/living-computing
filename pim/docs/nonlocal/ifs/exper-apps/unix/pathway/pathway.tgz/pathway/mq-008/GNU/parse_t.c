
/*  A Bison parser, made from parse.y with Bison version GNU Bison version 1.21
  */

#define YYBISON 1  /* Identify Bison output.  */

#define	ERROR_TOKEN	258
#define	CLEAR	259
#define	LOAD	260
#define	QUERY	261
#define	QUIT	262
#define	SET	263
#define	SHOW	264
#define	LEX_TRUE	265
#define	PROGRAM	266
#define	RULE	267
#define	SUBSUMPTION	268
#define	END	269
#define	PROGRAM_MODE	270
#define	QUERY_ONCE_MODE	271
#define	QUERY_MODE	272
#define	ATOM	273
#define	VARIABLE	274
#define	DOT	275
#define	TERMINATER	276
#define	SOLVE	277
#define	COMMITS	278
#define	CONSTRAINED	279
#define	SUBREL	280
#define	ATTRREL	281

#line 8 "parse.y"

#include <stdio.h>
#include "obstack.h"
#include "mq.h"
#include "internal.h"
#include "tree.h"
#include "extern.h"
#include "emit.h"

static MQT_Constraints head_cnstrs;
MQ_Query query;
int mq_as_library;
int end_of_file;
int error_recovering;
int reading_object;
MQT_Obj input_object;

#line 27 "parse.y"
typedef union { 
  int i;
  AttrRel       ar;
  Rel           sr;
  MQ_Atom       atom;
  MQT_AtomList  atom_list;

  MQT_Obj       obj;
  MQT_Dot       dot;
  MQT_Var       variable;

  MQT_Term      term;
  MQT_VTerm     vterm;

  MQT_VTermList	vterm_list;

  MQT_AttrList    attr_list;
  MQT_Constraints cnstrs;
} YYSTYPE;
#line 73 "parse.y"

extern int yylex _P((YYSTYPE *));

#ifndef YYLTYPE
typedef
  struct yyltype
    {
      int timestamp;
      int first_line;
      int first_column;
      int last_line;
      int last_column;
      char *text;
   }
  yyltype;

#define YYLTYPE yyltype
#endif

#include <stdio.h>

#ifndef __cplusplus
#ifndef __STDC__
#define const
#endif
#endif



#define	YYFINAL		127
#define	YYFLAG		-32768
#define	YYNTBASE	35

#define YYTRANSLATE(x) ((unsigned)(x) <= 281 ? yytranslate[x] : 59)

static const char yytranslate[] = {     0,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,    30,     2,    27,    31,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
    32,     2,    33,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,    28,    34,    29,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     1,     2,     3,     4,     5,
     6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
    16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
    26
};

#if YYDEBUG != 0
static const short yyprhs[] = {     0,
     0,     1,     3,     5,     7,     9,    12,    15,    19,    23,
    26,    29,    30,    35,    39,    44,    51,    53,    56,    57,
    63,    65,    71,    73,    77,    79,    85,    91,   101,   105,
   111,   115,   121,   123,   125,   127,   129,   131,   133,   138,
   140,   144,   146,   150,   152,   156,   160,   163,   167,   171,
   175,   177,   179,   181,   183,   185,   188,   192,   197,   201,
   204,   208,   211,   215
};

static const short yyrhs[] = {    -1,
    53,     0,    36,     0,    52,     0,    49,     0,     1,    27,
     0,    11,    21,     0,    15,    13,    21,     0,    15,    12,
    21,     0,    15,    39,     0,    15,    38,     0,     0,    15,
    14,    37,    27,     0,    15,     1,    21,     0,    18,    25,
    18,    21,     0,    18,    25,    28,    51,    29,    21,     0,
    40,     0,    44,    21,     0,     0,    44,    23,    41,    42,
    21,     0,    43,     0,    43,    24,    28,    46,    29,     0,
    44,     0,    43,    30,    44,     0,    47,     0,    47,    31,
    32,    45,    33,     0,    47,    34,    28,    46,    29,     0,
    47,    31,    32,    45,    33,    34,    28,    46,    29,     0,
    18,    26,    48,     0,    45,    30,    18,    26,    48,     0,
    48,    25,    48,     0,    46,    30,    48,    25,    48,     0,
    49,     0,    19,     0,    49,     0,    50,     0,    19,     0,
    18,     0,    18,    32,    45,    33,     0,    10,     0,    48,
    20,    18,     0,    18,     0,    51,    30,    18,     0,    22,
     0,    16,    42,    27,     0,    16,     1,    27,     0,     6,
    21,     0,    17,    42,    27,     0,    17,    14,    27,     0,
    17,     1,    27,     0,    54,     0,    55,     0,    56,     0,
    57,     0,    58,     0,     8,    21,     0,     8,    18,    21,
     0,     8,    18,    18,    21,     0,     5,    18,    21,     0,
     4,    21,     0,     4,    18,    21,     0,     9,    21,     0,
     9,    18,    21,     0,     7,    21,     0
};

#endif

#if YYDEBUG != 0
static const short yyrline[] = { 0,
    78,    81,    86,    88,    90,    97,   107,   113,   115,   118,
   124,   130,   136,   137,   146,   149,   158,   161,   163,   165,
   169,   171,   174,   177,   181,   184,   200,   202,   220,   223,
   226,   238,   251,   254,   258,   261,   263,   267,   270,   272,
   276,   281,   284,   288,   294,   305,   316,   321,   330,   334,
   346,   348,   349,   350,   351,   354,   357,   359,   363,   368,
   371,   375,   378,   382
};

static const char * const yytname[] = {   "$","error","$illegal.","ERROR_TOKEN",
"CLEAR","LOAD","QUERY","QUIT","SET","SHOW","LEX_TRUE","PROGRAM","RULE","SUBSUMPTION",
"END","PROGRAM_MODE","QUERY_ONCE_MODE","QUERY_MODE","ATOM","VARIABLE","DOT",
"TERMINATER","SOLVE","COMMITS","CONSTRAINED","SUBREL","ATTRREL","'.'","'{'",
"'}'","','","'/'","'['","']'","'|'","quixote","program","@1","subsumption","rule",
"clause","@2","body","a_term_list","a_term","attribute_list","constraint_list",
"vterm","term","object","dot_term","atom_list","query","command","set_command",
"load_command","clear_command","show_command","quit_command",""
};
#endif

static const short yyr1[] = {     0,
    35,    35,    35,    35,    35,    35,    36,    36,    36,    36,
    36,    37,    36,    36,    38,    38,    39,    40,    41,    40,
    42,    42,    43,    43,    44,    44,    44,    44,    45,    45,
    46,    46,    47,    47,    48,    48,    48,    49,    49,    49,
    50,    51,    51,    52,    52,    52,    52,    52,    52,    52,
    53,    53,    53,    53,    53,    54,    54,    54,    55,    56,
    56,    57,    57,    58
};

static const short yyr2[] = {     0,
     0,     1,     1,     1,     1,     2,     2,     3,     3,     2,
     2,     0,     4,     3,     4,     6,     1,     2,     0,     5,
     1,     5,     1,     3,     1,     5,     5,     9,     3,     5,
     3,     5,     1,     1,     1,     1,     1,     1,     4,     1,
     3,     1,     3,     1,     3,     3,     2,     3,     3,     3,
     1,     1,     1,     1,     1,     2,     3,     4,     3,     2,
     3,     2,     3,     2
};

static const short yydefact[] = {     0,
     0,     0,     0,     0,     0,     0,     0,    40,     0,     0,
     0,     0,    38,    44,     3,     5,     4,     2,    51,    52,
    53,    54,    55,     6,     0,    60,     0,    47,    64,     0,
    56,     0,    62,     7,     0,     0,     0,    12,    38,    34,
    11,    10,    17,     0,    25,    33,     0,     0,    21,    23,
     0,     0,     0,     0,    61,    59,     0,    57,    63,    14,
     9,     8,     0,     0,    18,    19,     0,     0,    46,    45,
     0,     0,    50,    49,    48,     0,     0,    58,    13,     0,
     0,     0,     0,     0,     0,    24,     0,     0,    39,    15,
    42,     0,     0,     0,    37,     0,     0,    35,    36,     0,
    29,     0,     0,     0,    20,    26,    27,     0,     0,     0,
    22,     0,    16,    43,     0,     0,    41,    31,    30,     0,
     0,     0,    32,    28,     0,     0,     0
};

static const short yydefgoto[] = {   125,
    15,    63,    41,    42,    43,    82,    48,    49,    50,    77,
    96,    45,    97,    98,    99,    92,    17,    18,    19,    20,
    21,    22,    23
};

static const short yypact[] = {    41,
   -22,     2,    -9,     9,    34,    56,    57,-32768,    46,     3,
    25,    18,     7,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,    75,-32768,    76,-32768,-32768,    58,
-32768,    77,-32768,-32768,    78,    79,    80,-32768,   -18,-32768,
-32768,-32768,-32768,    64,    35,-32768,    -3,    81,    30,-32768,
    82,    83,    84,    68,-32768,-32768,    85,-32768,-32768,-32768,
-32768,-32768,    86,   -10,-32768,-32768,    70,    87,-32768,-32768,
    88,    15,-32768,-32768,-32768,    91,    50,-32768,-32768,    93,
    89,    15,    68,    43,    43,-32768,    43,    94,-32768,-32768,
-32768,    59,    97,    51,-32768,    61,    45,-32768,-32768,    63,
    99,    95,   101,   102,-32768,    69,-32768,    43,   105,    43,
-32768,    43,-32768,-32768,    96,    48,-32768,    99,    99,    43,
    43,    65,    99,-32768,   104,   125,-32768
};

static const short yypgoto[] = {-32768,
-32768,-32768,-32768,-32768,-32768,-32768,   -11,-32768,    -8,    22,
   -82,-32768,   -81,     0,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768
};


#define	YYLAST		125


static const short yytable[] = {    16,
    53,    44,   100,    35,    24,   101,    64,    80,    27,    46,
    46,    46,     8,    54,    36,    37,    38,    81,    51,    25,
    39,    40,    26,    69,     8,    47,   116,     8,   118,    28,
   119,    52,    13,    40,     8,    13,    40,   122,    54,   123,
    -1,     1,    13,    40,     2,     3,     4,     5,     6,     7,
     8,     9,     8,    71,    29,    10,    11,    12,    13,    72,
    13,    95,    14,    86,   109,    67,    34,   109,    68,   110,
    93,    46,   121,    30,    32,    57,    31,    33,    58,    88,
    88,    46,    89,   106,    65,    76,    66,   103,   104,   107,
   108,   111,   108,   124,   108,    55,    56,    59,    60,    61,
    62,    83,   115,   126,    94,    78,    91,    70,    73,    74,
    75,   102,    79,    90,    84,    85,    87,   105,   109,   114,
   112,   113,   117,   120,   127
};

static const short yycheck[] = {     0,
    12,    10,    85,     1,    27,    87,    25,    18,    18,    10,
    11,    12,    10,    32,    12,    13,    14,    28,     1,    18,
    18,    19,    21,    27,    10,     1,   108,    10,   110,    21,
   112,    14,    18,    19,    10,    18,    19,   120,    32,   121,
     0,     1,    18,    19,     4,     5,     6,     7,     8,     9,
    10,    11,    10,    24,    21,    15,    16,    17,    18,    30,
    18,    19,    22,    72,    20,    31,    21,    20,    34,    25,
    82,    72,    25,    18,    18,    18,    21,    21,    21,    30,
    30,    82,    33,    33,    21,    18,    23,    29,    30,    29,
    30,    29,    30,    29,    30,    21,    21,    21,    21,    21,
    21,    32,    34,     0,    83,    21,    18,    27,    27,    27,
    27,    18,    27,    21,    28,    28,    26,    21,    20,    18,
    26,    21,    18,    28,     0
};
#define YYPURE 1

/* -*-C-*-  Note some compilers choke on comments on `#line' lines.  */
#line 3 "/usr/local/share//lib/bison.simple"

/* Skeleton output parser for bison,
   Copyright (C) 1984, 1989, 1990 Bob Corbett and Richard Stallman

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 1, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  */


#ifndef alloca
#ifdef __GNUC__
#define alloca __builtin_alloca
#else /* not GNU C.  */
#if (!defined (__STDC__) && defined (sparc)) || defined (__sparc__) || defined (__sparc) || defined (__sgi)
#include <alloca.h>
#else /* not sparc */
#if defined (MSDOS) && !defined (__TURBOC__)
#include <malloc.h>
#else /* not MSDOS, or __TURBOC__ */
#if defined(_AIX)
#include <malloc.h>
 #pragma alloca
#else /* not MSDOS, __TURBOC__, or _AIX */
#ifdef __hpux
#ifdef __cplusplus
extern "C" {
void *alloca (unsigned int);
};
#else /* not __cplusplus */
void *alloca (unsigned int);
#endif /* not __cplusplus */
#endif /* __hpux */
#endif /* not _AIX */
#endif /* not MSDOS, or __TURBOC__ */
#endif /* not sparc.  */
#endif /* not GNU C.  */
#endif /* alloca not defined.  */

/* This is the parser code that is written into each bison parser
  when the %semantic_parser declaration is not specified in the grammar.
  It was written by Richard Stallman by simplifying the hairy parser
  used when %semantic_parser is specified.  */

/* Note: there must be only one dollar sign in this file.
   It is replaced by the list of actions, each action
   as one case of the switch.  */

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		-2
#define YYEOF		0
#define YYACCEPT	return(0)
#define YYABORT 	return(1)
#define YYERROR		goto yyerrlab1
/* Like YYERROR except do call yyerror.
   This remains here temporarily to ease the
   transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */
#define YYFAIL		goto yyerrlab
#define YYRECOVERING()  (!!yyerrstatus)
#define YYBACKUP(token, value) \
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    { yychar = (token), yylval = (value);			\
      yychar1 = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { yyerror ("syntax error: cannot back up"); YYERROR; }	\
while (0)

#define YYTERROR	1
#define YYERRCODE	256

#ifndef YYPURE
#define YYLEX		yylex()
#endif

#ifdef YYPURE
#ifdef YYLSP_NEEDED
#define YYLEX		yylex(&yylval, &yylloc)
#else
#define YYLEX		yylex(&yylval)
#endif
#endif

/* If nonreentrant, generate the variables here */

#ifndef YYPURE

int	yychar;			/*  the lookahead symbol		*/
YYSTYPE	yylval;			/*  the semantic value of the		*/
				/*  lookahead symbol			*/

#ifdef YYLSP_NEEDED
YYLTYPE yylloc;			/*  location data for the lookahead	*/
				/*  symbol				*/
#endif

int yynerrs;			/*  number of parse errors so far       */
#endif  /* not YYPURE */

#if YYDEBUG != 0
int yydebug;			/*  nonzero means print parse trace	*/
/* Since this is uninitialized, it does not stop multiple parsers
   from coexisting.  */
#endif

/*  YYINITDEPTH indicates the initial size of the parser's stacks	*/

#ifndef	YYINITDEPTH
#define YYINITDEPTH 200
#endif

/*  YYMAXDEPTH is the maximum size the stacks can grow to
    (effective only if the built-in stack extension method is used).  */

#if YYMAXDEPTH == 0
#undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
#define YYMAXDEPTH 10000
#endif

/* Prevent warning if -Wstrict-prototypes.  */
#ifdef __GNUC__
int yyparse (void);
#endif

#if __GNUC__ > 1		/* GNU C and GNU C++ define this.  */
#define __yy_bcopy(FROM,TO,COUNT)	__builtin_memcpy(TO,FROM,COUNT)
#else				/* not GNU C or C++ */
#ifndef __cplusplus

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_bcopy (from, to, count)
     char *from;
     char *to;
     int count;
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#else /* __cplusplus */

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_bcopy (char *from, char *to, int count)
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#endif
#endif

#line 184 "/usr/local/share//lib/bison.simple"
int
yyparse()
{
  register int yystate;
  register int yyn;
  register short *yyssp;
  register YYSTYPE *yyvsp;
  int yyerrstatus;	/*  number of tokens to shift before error messages enabled */
  int yychar1;		/*  lookahead token as an internal (translated) token number */

  short	yyssa[YYINITDEPTH];	/*  the state stack			*/
  YYSTYPE yyvsa[YYINITDEPTH];	/*  the semantic value stack		*/

  short *yyss = yyssa;		/*  refer to the stacks thru separate pointers */
  YYSTYPE *yyvs = yyvsa;	/*  to allow yyoverflow to reallocate them elsewhere */

#ifdef YYLSP_NEEDED
  YYLTYPE yylsa[YYINITDEPTH];	/*  the location stack			*/
  YYLTYPE *yyls = yylsa;
  YYLTYPE *yylsp;

#define YYPOPSTACK   (yyvsp--, yyssp--, yylsp--)
#else
#define YYPOPSTACK   (yyvsp--, yyssp--)
#endif

  int yystacksize = YYINITDEPTH;

#ifdef YYPURE
  int yychar;
  YYSTYPE yylval;
  int yynerrs;
#ifdef YYLSP_NEEDED
  YYLTYPE yylloc;
#endif
#endif

  YYSTYPE yyval;		/*  the variable used to return		*/
				/*  semantic values from the action	*/
				/*  routines				*/

  int yylen;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Starting parse\n");
#endif

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss - 1;
  yyvsp = yyvs;
#ifdef YYLSP_NEEDED
  yylsp = yyls;
#endif

/* Push a new state, which is found in  yystate  .  */
/* In all cases, when you get here, the value and location stacks
   have just been pushed. so pushing a state here evens the stacks.  */
yynewstate:

  *++yyssp = yystate;

  if (yyssp >= yyss + yystacksize - 1)
    {
      /* Give user a chance to reallocate the stack */
      /* Use copies of these so that the &'s don't force the real ones into memory. */
      YYSTYPE *yyvs1 = yyvs;
      short *yyss1 = yyss;
#ifdef YYLSP_NEEDED
      YYLTYPE *yyls1 = yyls;
#endif

      /* Get the current used size of the three stacks, in elements.  */
      int size = yyssp - yyss + 1;

#ifdef yyoverflow
      /* Each stack pointer address is followed by the size of
	 the data in use in that stack, in bytes.  */
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
#ifdef YYLSP_NEEDED
		 &yyls1, size * sizeof (*yylsp),
#endif
		 &yystacksize);

      yyss = yyss1; yyvs = yyvs1;
#ifdef YYLSP_NEEDED
      yyls = yyls1;
#endif
#else /* no yyoverflow */
      /* Extend the stack our own way.  */
      if (yystacksize >= YYMAXDEPTH)
	{
	  yyerror("parser stack overflow");
	  return 2;
	}
      yystacksize *= 2;
      if (yystacksize > YYMAXDEPTH)
	yystacksize = YYMAXDEPTH;
      yyss = (short *) alloca (yystacksize * sizeof (*yyssp));
      __yy_bcopy ((char *)yyss1, (char *)yyss, size * sizeof (*yyssp));
      yyvs = (YYSTYPE *) alloca (yystacksize * sizeof (*yyvsp));
      __yy_bcopy ((char *)yyvs1, (char *)yyvs, size * sizeof (*yyvsp));
#ifdef YYLSP_NEEDED
      yyls = (YYLTYPE *) alloca (yystacksize * sizeof (*yylsp));
      __yy_bcopy ((char *)yyls1, (char *)yyls, size * sizeof (*yylsp));
#endif
#endif /* no yyoverflow */

      yyssp = yyss + size - 1;
      yyvsp = yyvs + size - 1;
#ifdef YYLSP_NEEDED
      yylsp = yyls + size - 1;
#endif

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Stack size increased to %d\n", yystacksize);
#endif

      if (yyssp >= yyss + yystacksize - 1)
	YYABORT;
    }

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Entering state %d\n", yystate);
#endif

  goto yybackup;
 yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* yychar is either YYEMPTY or YYEOF
     or a valid token in external form.  */

  if (yychar == YYEMPTY)
    {
#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Reading a token: ");
#endif
      yychar = YYLEX;
    }

  /* Convert token to internal form (in yychar1) for indexing tables with */

  if (yychar <= 0)		/* This means end of input. */
    {
      yychar1 = 0;
      yychar = YYEOF;		/* Don't call YYLEX any more */

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Now at end of input.\n");
#endif
    }
  else
    {
      yychar1 = YYTRANSLATE(yychar);

#if YYDEBUG != 0
      if (yydebug)
	{
	  fprintf (stderr, "Next token is %d (%s", yychar, yytname[yychar1]);
	  /* Give the individual parser a way to print the precise meaning
	     of a token, for further debugging info.  */
#ifdef YYPRINT
	  YYPRINT (stderr, yychar, yylval);
#endif
	  fprintf (stderr, ")\n");
	}
#endif
    }

  yyn += yychar1;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != yychar1)
    goto yydefault;

  yyn = yytable[yyn];

  /* yyn is what to do for this token type in this state.
     Negative => reduce, -yyn is rule number.
     Positive => shift, yyn is new state.
       New state is final state => don't bother to shift,
       just return success.
     0, or most negative number => error.  */

  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrlab;

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting token %d (%s), ", yychar, yytname[yychar1]);
#endif

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  /* count tokens shifted since error; after three, turn off error status.  */
  if (yyerrstatus) yyerrstatus--;

  yystate = yyn;
  goto yynewstate;

/* Do the default action for the current state.  */
yydefault:

  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;

/* Do a reduction.  yyn is the number of a rule to reduce with.  */
yyreduce:
  yylen = yyr2[yyn];
  yyval = yyvsp[1-yylen]; /* implement default value of the action */

#if YYDEBUG != 0
  if (yydebug)
    {
      int i;

      fprintf (stderr, "Reducing via rule %d (line %d), ",
	       yyn, yyrline[yyn]);

      /* Print the symbols being reduced, and their result.  */
      for (i = yyprhs[yyn]; yyrhs[i] > 0; i++)
	fprintf (stderr, "%s ", yytname[yyrhs[i]]);
      fprintf (stderr, " -> %s\n", yytname[yyr1[yyn]]);
    }
#endif


  switch (yyn) {

case 1:
#line 80 "parse.y"
{ end_of_file = TRUE; YYACCEPT; ;
    break;}
case 2:
#line 82 "parse.y"
{
		  set_mode_for_lex (MODE_COMMAND);
		  YYACCEPT;
		;
    break;}
case 3:
#line 87 "parse.y"
{ YYACCEPT; ;
    break;}
case 4:
#line 89 "parse.y"
{ YYACCEPT; ;
    break;}
case 5:
#line 91 "parse.y"
{
		  if (!reading_object)
		    YYABORT;
		  input_object = yyvsp[0].obj;
		  YYACCEPT;
		;
    break;}
case 6:
#line 98 "parse.y"
{
		  free_parse_tree ();
		  yyerrok;
		  error_recovering = 0;
		  set_mode_for_lex (MODE_COMMAND);
		  YYABORT;
		;
    break;}
case 7:
#line 109 "parse.y"
{
		  current_cnstrs = NULL;
		  set_mode_for_lex (MODE_PROGRAM);
		;
    break;}
case 8:
#line 114 "parse.y"
{ set_mode_for_lex (MODE_PROGRAM); ;
    break;}
case 9:
#line 117 "parse.y"
{ set_mode_for_lex (MODE_PROGRAM); ;
    break;}
case 10:
#line 119 "parse.y"
{
		  free_parse_tree ();
		  current_cnstrs = NULL;
		  set_mode_for_lex (MODE_PROGRAM);
		;
    break;}
case 11:
#line 125 "parse.y"
{
		  free_parse_tree ();
		  current_cnstrs = NULL;
		  set_mode_for_lex (MODE_PROGRAM);
		;
    break;}
case 12:
#line 131 "parse.y"
{
		  generate_lattice ();
		  set_mode_for_lex (MODE_EXPECT_PRD);
		;
    break;}
case 13:
#line 136 "parse.y"
{ set_mode_for_lex (MODE_COMMAND); ;
    break;}
case 14:
#line 138 "parse.y"
{
		  yyerrok;
		  error_recovering = 0;
		  current_cnstrs = NULL;
		  set_mode_for_lex (MODE_PROGRAM);
		  YYABORT;
		;
    break;}
case 15:
#line 148 "parse.y"
{ emit_subrel (yyvsp[-2].sr, yyvsp[-3].atom, yyvsp[-1].atom); ;
    break;}
case 16:
#line 150 "parse.y"
{
		  MQT_AtomList al;

		  for (al = yyvsp[-2].atom_list; al; al = al->next)
		    emit_subrel (yyvsp[-4].sr, yyvsp[-5].atom, al->atom);
		;
    break;}
case 18:
#line 162 "parse.y"
{ emit_rule (yyvsp[-1].vterm, current_cnstrs, NULL, NULL); ;
    break;}
case 19:
#line 164 "parse.y"
{ head_cnstrs = current_cnstrs; current_cnstrs = NULL; ;
    break;}
case 20:
#line 166 "parse.y"
{ emit_rule (yyvsp[-4].vterm, head_cnstrs, yyvsp[-1].vterm_list, current_cnstrs); ;
    break;}
case 23:
#line 176 "parse.y"
{ yyval.vterm_list = makeT_vterm_list (yyvsp[0].vterm, NULL); ;
    break;}
case 24:
#line 178 "parse.y"
{ yyval.vterm_list = makeT_vterm_list (yyvsp[0].vterm, yyvsp[-2].vterm_list); ;
    break;}
case 25:
#line 183 "parse.y"
{ yyval.vterm = yyvsp[0].vterm; ;
    break;}
case 26:
#line 185 "parse.y"
{
		  MQT_AttrList atl;

		  for (atl = yyvsp[-1].attr_list; atl; atl = atl->next)
		    {
		      MQT_Dot dot;

		      dot = makeT_dot ((MQT_Term)yyvsp[-4].vterm, atl->label);
		      current_cnstrs
			= makeT_constraints (Congruent, (MQT_Term)dot,
					     (MQT_Term)atl->vterm, NULL,
					     current_cnstrs);
		    }
		  yyval.vterm = yyvsp[-4].vterm;
		;
    break;}
case 27:
#line 201 "parse.y"
{ yyval.vterm = yyvsp[-4].vterm; ;
    break;}
case 28:
#line 203 "parse.y"
{
		  MQT_AttrList atl;

		  for (atl = yyvsp[-5].attr_list; atl; atl = atl->next)
		    {
		      MQT_Dot dot;

		      dot = makeT_dot ((MQT_Term)yyvsp[-8].vterm, atl->label);
		      current_cnstrs
			= makeT_constraints (Congruent, (MQT_Term)dot,
					     (MQT_Term)atl->vterm, NULL,
					     current_cnstrs);
		    }
		  yyval.vterm = yyvsp[-8].vterm;
		;
    break;}
case 29:
#line 222 "parse.y"
{ yyval.attr_list = makeT_attr_list (yyvsp[-1].ar, yyvsp[-2].atom, (MQT_VTerm)yyvsp[0].term, NULL); ;
    break;}
case 30:
#line 224 "parse.y"
{ yyval.attr_list = makeT_attr_list (yyvsp[-1].ar, yyvsp[-2].atom, (MQT_VTerm)yyvsp[0].term, yyvsp[-4].attr_list); ;
    break;}
case 31:
#line 228 "parse.y"
{
		  MQ_Atom op;

		  if (yyvsp[-1].sr == ExternalCnstr)
		    op = external_cnstr_op;
		  else
		    op = NULL;
		  current_cnstrs
		    = makeT_constraints (yyvsp[-1].sr, yyvsp[-2].term, yyvsp[0].term, op, current_cnstrs);
		;
    break;}
case 32:
#line 239 "parse.y"
{
		  MQ_Atom op;

		  if (yyvsp[-1].sr == ExternalCnstr)
		    op = external_cnstr_op;
		  else
		    op = NULL;
		  current_cnstrs =
		    makeT_constraints (yyvsp[-1].sr, yyvsp[-2].term, yyvsp[0].term, op, current_cnstrs);
		;
    break;}
case 33:
#line 253 "parse.y"
{ yyval.vterm = (MQT_VTerm) yyvsp[0].obj; ;
    break;}
case 34:
#line 255 "parse.y"
{ yyval.vterm = (MQT_VTerm) yyvsp[0].variable; ;
    break;}
case 35:
#line 260 "parse.y"
{ yyval.term = (MQT_Term) yyvsp[0].obj; ;
    break;}
case 36:
#line 262 "parse.y"
{ yyval.term = (MQT_Term) yyvsp[0].dot; ;
    break;}
case 37:
#line 264 "parse.y"
{ yyval.term = (MQT_Term) yyvsp[0].variable; ;
    break;}
case 38:
#line 269 "parse.y"
{ yyval.obj = makeT_object (yyvsp[0].atom, NULL); ;
    break;}
case 39:
#line 271 "parse.y"
{ yyval.obj = makeT_object (yyvsp[-3].atom, yyvsp[-1].attr_list); ;
    break;}
case 40:
#line 273 "parse.y"
{ yyval.obj = mqTO_True; ;
    break;}
case 41:
#line 278 "parse.y"
{ yyval.dot = makeT_dot (yyvsp[-2].term, yyvsp[0].atom); ;
    break;}
case 42:
#line 283 "parse.y"
{ yyval.atom_list = makeT_atom_list (yyvsp[0].atom, NULL); ;
    break;}
case 43:
#line 285 "parse.y"
{ yyval.atom_list = makeT_atom_list (yyvsp[0].atom, yyvsp[-2].atom_list); ;
    break;}
case 44:
#line 290 "parse.y"
{
		  current_cnstrs = NULL;
		  set_mode_for_lex (MODE_QUERY_ONCE);
		;
    break;}
case 45:
#line 295 "parse.y"
{
		  begin_exec ();
		  emit_body (yyvsp[-1].vterm_list, current_cnstrs, &query);
		  free_parse_tree ();
		  if (mq_as_library)
		    YYACCEPT;
		  do_query ();
		  end_exec ();
		  set_mode_for_lex (MODE_COMMAND);
		;
    break;}
case 46:
#line 306 "parse.y"
{
		  free_parse_tree ();
		  yyerrok;
		  error_recovering = 0;
		  end_exec ();
		  if (temporary)
		    end_tmp ();
		  set_mode_for_lex (MODE_COMMAND);
		  YYABORT;
		;
    break;}
case 47:
#line 317 "parse.y"
{
		  current_cnstrs = NULL;
		  set_mode_for_lex (MODE_QUERY);
		;
    break;}
case 48:
#line 322 "parse.y"
{
		  begin_exec ();
		  emit_body (yyvsp[-1].vterm_list, current_cnstrs, &query);
		  free_parse_tree ();
		  do_query ();
		  end_exec ();
		  set_mode_for_lex (MODE_QUERY);
		;
    break;}
case 49:
#line 331 "parse.y"
{
		  set_mode_for_lex (MODE_COMMAND);
		;
    break;}
case 50:
#line 335 "parse.y"
{
		  free_parse_tree ();
		  yyerrok;
		  error_recovering = 0;
		  end_exec ();
		  if (temporary)
		    end_tmp ();
		  set_mode_for_lex (MODE_QUERY);
		  YYABORT;
		;
    break;}
case 56:
#line 356 "parse.y"
{ cmd_set (NULL, NULL); ;
    break;}
case 57:
#line 358 "parse.y"
{ cmd_set (yyvsp[-1].atom, NULL); ;
    break;}
case 58:
#line 360 "parse.y"
{ cmd_set (yyvsp[-2].atom, yyvsp[-1].atom); ;
    break;}
case 59:
#line 365 "parse.y"
{ cmd_load (yyvsp[-1].atom); ;
    break;}
case 60:
#line 370 "parse.y"
{ cmd_clear (NULL); ;
    break;}
case 61:
#line 372 "parse.y"
{ cmd_clear (yyvsp[-1].atom); ;
    break;}
case 62:
#line 377 "parse.y"
{ cmd_show (NULL); ;
    break;}
case 63:
#line 379 "parse.y"
{ cmd_show (yyvsp[-1].atom); ;
    break;}
case 64:
#line 384 "parse.y"
{ cmd_quit (); ;
    break;}
}
   /* the action file gets copied in in place of this dollarsign */
#line 457 "/usr/local/share//lib/bison.simple"

  yyvsp -= yylen;
  yyssp -= yylen;
#ifdef YYLSP_NEEDED
  yylsp -= yylen;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

  *++yyvsp = yyval;

#ifdef YYLSP_NEEDED
  yylsp++;
  if (yylen == 0)
    {
      yylsp->first_line = yylloc.first_line;
      yylsp->first_column = yylloc.first_column;
      yylsp->last_line = (yylsp-1)->last_line;
      yylsp->last_column = (yylsp-1)->last_column;
      yylsp->text = 0;
    }
  else
    {
      yylsp->last_line = (yylsp+yylen-1)->last_line;
      yylsp->last_column = (yylsp+yylen-1)->last_column;
    }
#endif

  /* Now "shift" the result of the reduction.
     Determine what state that goes to,
     based on the state we popped back to
     and the rule number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTBASE] + *yyssp;
  if (yystate >= 0 && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTBASE];

  goto yynewstate;

yyerrlab:   /* here on detecting error */

  if (! yyerrstatus)
    /* If not already recovering from an error, report this error.  */
    {
      ++yynerrs;

#ifdef YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (yyn > YYFLAG && yyn < YYLAST)
	{
	  int size = 0;
	  char *msg;
	  int x, count;

	  count = 0;
	  /* Start X at -yyn if nec to avoid negative indexes in yycheck.  */
	  for (x = (yyn < 0 ? -yyn : 0);
	       x < (sizeof(yytname) / sizeof(char *)); x++)
	    if (yycheck[x + yyn] == x)
	      size += strlen(yytname[x]) + 15, count++;
	  msg = (char *) malloc(size + 15);
	  if (msg != 0)
	    {
	      strcpy(msg, "parse error");

	      if (count < 5)
		{
		  count = 0;
		  for (x = (yyn < 0 ? -yyn : 0);
		       x < (sizeof(yytname) / sizeof(char *)); x++)
		    if (yycheck[x + yyn] == x)
		      {
			strcat(msg, count == 0 ? ", expecting `" : " or `");
			strcat(msg, yytname[x]);
			strcat(msg, "'");
			count++;
		      }
		}
	      yyerror(msg);
	      free(msg);
	    }
	  else
	    yyerror ("parse error; also virtual memory exceeded");
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror("parse error");
    }

  goto yyerrlab1;
yyerrlab1:   /* here on error raised explicitly by an action */

  if (yyerrstatus == 3)
    {
      /* if just tried and failed to reuse lookahead token after an error, discard it.  */

      /* return failure if at end of input */
      if (yychar == YYEOF)
	YYABORT;

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Discarding token %d (%s).\n", yychar, yytname[yychar1]);
#endif

      yychar = YYEMPTY;
    }

  /* Else will try to reuse lookahead token
     after shifting the error token.  */

  yyerrstatus = 3;		/* Each real token shifted decrements this */

  goto yyerrhandle;

yyerrdefault:  /* current state does not do anything special for the error token. */

#if 0
  /* This is wrong; only states that explicitly want error tokens
     should shift them.  */
  yyn = yydefact[yystate];  /* If its default is to accept any token, ok.  Otherwise pop it.*/
  if (yyn) goto yydefault;
#endif

yyerrpop:   /* pop the current state because it cannot handle the error token */

  if (yyssp == yyss) YYABORT;
  yyvsp--;
  yystate = *--yyssp;
#ifdef YYLSP_NEEDED
  yylsp--;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "Error: state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

yyerrhandle:

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yyerrdefault;

  yyn += YYTERROR;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != YYTERROR)
    goto yyerrdefault;

  yyn = yytable[yyn];
  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrpop;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrpop;

  if (yyn == YYFINAL)
    YYACCEPT;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting error token, ");
#endif

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  yystate = yyn;
  goto yynewstate;
}
#line 386 "parse.y"

int
yyerror (message)
     char *message;
{
  error_recovering = 1;
  if (interactive)
    fprintf (stderr, " %s\n", message);
  else
    fprintf (stderr, "%d: %s\n", lineno, message);
  return 0;
}
