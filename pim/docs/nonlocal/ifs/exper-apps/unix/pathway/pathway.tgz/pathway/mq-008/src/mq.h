/* Micro Quixote           */
/* Copyright (C) 1993 ICOT */
/* Written by gniibe       */
/* $Id: mq.h,v 1.3 1994/11/14 07:33:35 m-gniibe Exp $ */

/* common definition / constant definition */

#ifdef __STDC__
#define _P(x) x
#else
#define _P(x) ()
#define volatile
#endif

#define obstack_chunk_alloc xmalloc
#define obstack_chunk_free  xfree

#define FAILURE     0
#define SUCCESS     1
#define DONE        2

#define FALSE       0
#define TRUE        1

#define EXEC_SIZE         32752
#define CONSTRAINTS_SIZE   8176

#define INHERIT_NO	    0
#define INHERIT_DOWNWARD    1
#define INHERIT_UPWARD	    2
#define INHERIT_BOTH	    3

#define PROC_SINGLE 0
#define PROC_MULTI  1

#define EXCEPT_ABORT 1

extern char *result;
extern int initialize _P((int));
extern int get_answer _P((void));
extern int start_query _P((char *q));
extern int load_program _P((char *));
extern void end_query _P((void));
