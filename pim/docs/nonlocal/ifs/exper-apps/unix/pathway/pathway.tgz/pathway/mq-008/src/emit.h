/* Micro Quixote           */
/* Copyright (C) 1993 ICOT */
/* Written by gniibe       */
/* $Id: emit.h,v 1.2 1994/09/19 02:06:33 m-gniibe Exp $ */

/* declarations of `emit' routines */

extern void emit_obj _P((MQT_Obj, MQ_Obj *, MQ_VarList *));
extern void emit_rule _P((MQT_VTerm, MQT_Constraints, MQT_VTermList, MQT_Constraints));
extern void emit_body _P((MQT_VTermList, MQT_Constraints, MQ_Query *));
extern void emit_subrel _P((Rel, MQ_Atom, MQ_Atom));
