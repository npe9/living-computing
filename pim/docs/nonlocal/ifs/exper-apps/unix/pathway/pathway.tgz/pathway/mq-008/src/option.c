/* Micro Quixote                 */
/* Copyright (C) 1993, 1994 ICOT */
/* Written by gniibe             */
/* $Id: option.c,v 1.2 1994/09/19 02:09:18 m-gniibe Exp $ */

#include "mq.h"

/* handling options */

int mq_opt_constrain;
int mq_opt_lookup;
int mq_opt_trace;
int mq_opt_inheritance;
int mq_opt_proc_mode;
int mq_opt_answer_print;
int debug=0;
int debug_memory=0;

void
init_options ()
{
  mq_opt_lookup = 1;       /* do lookup */
  mq_opt_trace = debug;    /* do trace if debug */
  mq_opt_constrain = 1;    /* solve constraints */
  mq_opt_inheritance = 3;  /* attribute inheritance all(downward and upward) */
  mq_opt_proc_mode = PROC_MULTI; /* generate assumptions */
  mq_opt_answer_print = 0;	/* normal print (don't print constraints)  */
}
