/* -*-C++-*- */
///////////////////////////////////////////////////////////////
// MotifHead.c : define protcols for all widgets
// '94.6.3 Fri
///////////////////////////////////////////////////////////////

#include <assert.h>
#include <stdio.h>
#include "motifhead.h"

MotifHead::MotifHead(const char* name)
{
  _w = NULL;
  assert( name != NULL);    // Check value of name
  _name = strdup(name);
}

MotifHead::~MotifHead()
{
  if(_w) XtDestroyWidget(_w);
  delete _name;
}

void MotifHead::manage()
{
  assert(_w != NULL);      // Check widget existing
  XtManageChild(_w);
}

void MotifHead::unmanage()
{
  assert(_w != NULL);
  XtUnmanageChild(_w);
}
