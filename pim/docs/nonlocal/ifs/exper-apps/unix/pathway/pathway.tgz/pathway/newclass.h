/* -*-C++-*- */
///////////////////////////////////////////////////////////////
// newclass.h : define protcols for new class
// '94.6.16 Thr
///////////////////////////////////////////////////////////////

#ifndef NEWCLASS_H
#define NEWCLASS_H
#include <Xm/Xm.h>
#include "motifhead.h"

class from : public MotifHead{
  int command;
  char* name;
  char* with;

  Widget row, allowB, labelRight, labelLeft;
  Widget nodeB, nodeDB;

protected:

public:
  from(char*, Widget);
  ~from();
  void  Label(char*, int);
  char* Label(void);
  void ID(int);
  void Name(char*);
  char* Name(void);
  void With(char*);
  inline int  ID(void){return command;};
  inline char*  With(void){return with;};
  inline Widget Row(void)    {return row;}
  inline Widget AllowB(void){return allowB;}
  inline Widget LabelRight(void){return labelRight;}
  inline Widget LabelLeft(void) {return labelLeft;}
  inline Widget NodeB(void){return nodeB;}
//  inline Widget NodeDB(void){return nodeDB;}
  inline void ManageButton(Widget A){XtManageChild(A);}
  inline void UnmanageButton(Widget A){XtUnmanageChild(A);}
};

extern void ClickCB(Widget w,XtPointer cliant_data,
		   XmPushButtonCallbackStruct *cbs);
class line{
protected:
  int counter;
  from* node;
  line* head;
  line* tail;
  line* parent;
  line* next;


public:
  line();                   // Constructer
  virtual ~line();
  inline void Counter(int A){counter = A;}
  inline int  Counter(void) {return counter;}
  inline line* Head(void){return head;}
  inline line* Tail(void){return tail;}
  inline void Head(line* A){head = A;}
  inline void Tail(line* A){tail = A;}
  virtual line* Parent();
  virtual line* Next();
  virtual void Parent(line*);
  virtual void Next(line*);
  from* Node();
  void Node(from*);
  void append(from*);
  void clear(void);
  void print(void);
};

class bindExpress : public line{

  Widget bindBox;
  Widget bind, allowLeft, name1;
  Widget allowRight, express, box, name2, sepa;

public:
  bindExpress(Widget,unsigned short,unsigned short);
  void Name1(char*);
  void Name2(char*);
  void Box(char*);
  char* Name1(void);
  void Position(unsigned short,unsigned short);
};

#endif
