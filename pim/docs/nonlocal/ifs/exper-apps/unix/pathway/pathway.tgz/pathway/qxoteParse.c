/**
 ** qXote parse test program
 **/

#include <stdio.h>
extern int yyparse();

void main(int argc, char **argv)
{
  yyparse();
}
