/* -*-C++-*- */
///////////////////////////////////////////////////////////////
// MotifHead.h : define protcols for all widgets
// '94.6.3 Fri
///////////////////////////////////////////////////////////////

#ifndef MOTIFHEAD_H
#define MOTIFHEAD_H

#include <Xm/Xm.h>

class MotifHead{
protected:
  char *_name;
  Widget _w;

  MotifHead(const char *);  // Constructer

public:
  virtual ~MotifHead();
  virtual void manage();    // Widget tree mange/unmage
  virtual void unmanage();
  virtual const Widget headWidget() {return _w;}
};

#endif
