break init_options
command 1
echo set debug\n
set debug=1
cont
end
break fatal
handle SIGINT nostop pass
