/* -*-C++-*- */
#include <Xm/Xm.h>
#include <Xm/Label.h>
#include <Xm/Form.h>
#include <Xm/PushB.h>
#include <Xm/Separator.h>
#include "newclass.h"

#define expressAllow_width 48
#define expressAllow_height 32
static char expressAllow_bits[] = {
   0x00, 0x00, 0x00, 0x00, 0x00, 0xe0, 0x00, 0x00, 0x00, 0x00, 0x00, 0xfe,
   0x00, 0x00, 0x00, 0x00, 0xf0, 0xff, 0x00, 0x00, 0x00, 0x00, 0xf8, 0x7f,
   0x00, 0x00, 0x00, 0x00, 0xf0, 0x3f, 0x00, 0x00, 0x00, 0x00, 0xc0, 0x3f,
   0x00, 0x00, 0x00, 0x00, 0xe0, 0x1f, 0x00, 0x00, 0x00, 0x00, 0x78, 0x0f,
   0x00, 0x00, 0x00, 0x00, 0x3e, 0x0f, 0x00, 0x00, 0x00, 0x00, 0x0f, 0x07,
   0x00, 0x00, 0x00, 0xc0, 0x03, 0x02, 0x00, 0x00, 0x00, 0xe0, 0x01, 0x00,
   0x00, 0x00, 0x00, 0x78, 0x00, 0x00, 0x00, 0x00, 0x00, 0x3c, 0x00, 0x00,
   0x00, 0x00, 0x00, 0x0f, 0x00, 0x00, 0x00, 0x00, 0x80, 0x07, 0x00, 0x00,
   0x00, 0x00, 0xe0, 0x01, 0x00, 0x00, 0x00, 0x00, 0xf0, 0x00, 0x00, 0x00,
   0x00, 0x00, 0x3c, 0x00, 0x00, 0x00, 0x00, 0x00, 0x1e, 0x00, 0x00, 0x00,
   0x00, 0x80, 0x07, 0x00, 0x00, 0x00, 0x00, 0xc0, 0x03, 0x00, 0x00, 0x00,
   0x00, 0xf0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x7c, 0x00, 0x00, 0x00, 0x00,
   0x00, 0x1e, 0x00, 0x00, 0x00, 0x00, 0x80, 0x07, 0x00, 0x00, 0x00, 0x00,
   0xc0, 0x03, 0x00, 0x00, 0x00, 0x00, 0xf0, 0x00, 0x00, 0x00, 0x00, 0x00,
   0x78, 0x00, 0x00, 0x00, 0x00, 0x00, 0x1e, 0x00, 0x00, 0x00, 0x00, 0x00,
   0x0f, 0x00, 0x00, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00};

#define bindAllow_width 8
#define bindAllow_height 64
static char bindAllow_bits[] = {
   0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18,
   0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18,
   0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18,
   0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18,
   0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x99, 0xdb, 0x7e, 0x7e,
   0x3c, 0x3c, 0x18, 0x18};


static XImage ximage, ximage1;

bindExpress::bindExpress(Widget toplevel, unsigned short X, unsigned short Y)
{
  Pixel fg, bg;

  bindBox = XtVaCreateWidget("bindBox",xmFormWidgetClass, toplevel,
			     XmNx, X, XmNy, Y, NULL);
  
  ximage.width  = expressAllow_width;
  ximage.height = expressAllow_height;
  ximage.data   = expressAllow_bits;
  ximage.xoffset = 0;
  ximage.format = (int)XYBitmap;
  ximage.byte_order = (int)MSBFirst;
  ximage.bitmap_pad = 8;
  ximage.bitmap_bit_order = (int)LSBFirst;
  ximage.bitmap_unit = 8;
  ximage.depth = 1;
  ximage.bytes_per_line = 6;
  ximage.obdata = NULL;
  XmInstallImage(&ximage, "express");

  ximage1.width  = bindAllow_width;
  ximage1.height = bindAllow_height;
  ximage1.data   = bindAllow_bits;
  ximage1.xoffset = 0;
  ximage1.format = (int)XYBitmap;
  ximage1.byte_order = (int)MSBFirst;
  ximage1.bitmap_pad = 8;
  ximage1.bitmap_bit_order = (int)LSBFirst;
  ximage1.bitmap_unit = 8;
  ximage1.depth = 1;
  ximage1.bytes_per_line = 1;
  ximage1.obdata = NULL;
  XmInstallImage(&ximage1, "element");


  XtVaGetValues(toplevel, XmNforeground, &fg, XmNbackground, &bg, NULL);
  Pixmap pixmap1, pixmap2;
  pixmap1 = XmGetPixmap(XtScreen(toplevel), "express", fg, bg);
  pixmap2 = XmGetPixmap(XtScreen(toplevel), "element", fg, bg);


  bind = XtVaCreateManagedWidget("bind_element", xmLabelWidgetClass, bindBox,
				 XmNtopAttachment, XmATTACH_FORM,
				 XmNleftAttachment, XmATTACH_FORM,
				 NULL);
  allowLeft = XtVaCreateManagedWidget("element", xmLabelWidgetClass, bindBox,
				      XmNtopAttachment, XmATTACH_FORM,
				      XmNleftAttachment, XmATTACH_WIDGET,
				      XmNleftWidget, bind,
				      XmNlabelType, XmPIXMAP,
				      XmNlabelPixmap, pixmap2,
				      NULL);
  box = XtVaCreateManagedWidget("BOOOOX", xmPushButtonWidgetClass, bindBox, 
				XmNtopAttachment, XmATTACH_FORM,
				XmNrightAttachment, XmATTACH_FORM,
				XmNrightOffset, 20,
				XmNshadowThickness, 1,
				NULL);


  allowRight = XtVaCreateManagedWidget("express", xmLabelWidgetClass, bindBox,
				       XmNtopAttachment, XmATTACH_WIDGET,
				       XmNtopWidget, box,
				       XmNleftAttachment, XmATTACH_WIDGET,
				       XmNleftWidget, allowLeft,
				       XmNleftOffset, 70,
				       XmNlabelType, XmPIXMAP,
				       XmNlabelPixmap, pixmap1,
				       NULL);
  express = XtVaCreateManagedWidget("express", xmLabelWidgetClass, bindBox,
				    XmNtopAttachment, XmATTACH_WIDGET,
				    XmNtopWidget, box,
				    XmNleftAttachment, XmATTACH_WIDGET,
				    XmNleftWidget, allowRight,
				    NULL);


  name1 = XtVaCreateManagedWidget("name1", xmPushButtonWidgetClass, bindBox,
				  XmNshadowThickness, 1,
				  XmNtopAttachment, XmATTACH_WIDGET,
				  XmNtopWidget, allowLeft,
				  XmNrightAttachment, XmATTACH_OPPOSITE_WIDGET,
				  XmNrightWidget, allowLeft,
				  XmNrightOffset, -20,
				  XmNbottomAttachment, XmATTACH_FORM,
				  XmNbottomOffset, 10,
				  NULL);

  name2 = XtVaCreateManagedWidget("     ", xmPushButtonWidgetClass, bindBox,
				  XmNtopAttachment, XmATTACH_WIDGET,
				  XmNtopWidget, allowRight,
				  XmNleftAttachment, XmATTACH_WIDGET,
				  XmNleftWidget, name1,
				  XmNleftOffset, 30,
				  XmNbottomAttachment, XmATTACH_FORM,
				  XmNbottomOffset, 10,
				  XmNshadowThickness, 1,
				  NULL);

  sepa = XtVaCreateManagedWidget("sepa", xmSeparatorWidgetClass, bindBox,
				 XmNleftAttachment, XmATTACH_FORM,
				 XmNrightAttachment, XmATTACH_FORM,
				 XmNbottomAttachment, XmATTACH_FORM,
				 XmNbottomOffset, 10,
				 XmNseparatorType, XmSINGLE_LINE,
				 NULL);

  XtManageChild(bindBox);
}

void bindExpress::Name1(char* name)
{
  XmString nameX = XmStringCreateLtoR(name, "charset");
  XtVaSetValues(name1, XmNlabelString, nameX, NULL);
  XmStringFree(nameX);
}

void bindExpress::Name2(char* name)
{
  XmString nameX = XmStringCreateLtoR(name, "charset");
  XtVaSetValues(name2, XmNlabelString, nameX, NULL);
  XmStringFree(nameX);
}

void bindExpress::Box(char* name)
{
  XmString nameX = XmStringCreateLtoR(name, "charset");
  XtVaSetValues(box, XmNlabelString, nameX, NULL);
  XmStringFree(nameX);
}

char* bindExpress::Name1(void)
{
  XmString nameX;
  XtVaGetValues(name1, XmNlabelString, &nameX, NULL);
  char *name;
  XmStringGetLtoR(nameX, "charset", &name);
  XmStringFree(nameX);
  return name;
}

void bindExpress::Position(unsigned short X, unsigned short Y)
{
  XtVaSetValues(bindBox,XmNx, X, XmNy, Y, NULL);
}
