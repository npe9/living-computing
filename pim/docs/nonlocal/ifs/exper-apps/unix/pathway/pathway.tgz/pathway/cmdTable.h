/* -*-C++-*- */
///////////////////////////////////////////////////////////////
// cmdTable.h : define command table
// '94.7.15 Fri
///////////////////////////////////////////////////////////////

#ifndef CMD_TABLE_H
#define CMD_TABLE_H

#define NUMBER_OF_CMD 24

const char *cmdTable[NUMBER_OF_CMD] = {
  "begin", "duplicate",                                // Type A 0-1
  "activate",                                          // Type B 2
  "receive", "increase", "phosphorylate", "intake",      // Type C 3-15
  "suppress", "depolarize", "secrete", "decrease", 
  "produce", "transelocate", "inactivate", "unbind", "hydrolyze",
  "form", "compound",                                  // Type D 16-17
  "produce", "activate",                               // Type E 18-19
  "bind_element", "express",                           // Type F 20-21
  "results",                                           // Type G 22
  "bind"                                               // Type H 23
};

#endif
