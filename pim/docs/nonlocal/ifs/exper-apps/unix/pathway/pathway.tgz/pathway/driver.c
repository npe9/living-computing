#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <X11/Xutil.h>
#include <Xm/Xm.h>
#include <Xm/BulletinB.h>
#include <Xm/PushB.h>
#include <Xm/RowColumn.h>
#include <Xm/Label.h>
#include <Xm/LabelG.h>
#include <Xm/SeparatoG.h>
#include <Xm/PushBG.h>
#include <Xm/Form.h>
#include <Xm/DrawingA.h>

#include <stdio.h>
#include <string.h>
#include <math.h>

/* Window CallBack Definitions */

/* Callback for the PushButton */
void quitCB(); 

unsigned long MyColor();
Widget top1,top2,bb,bb2,buttonquit;
XtAppContext app_context;
Display *dp1;
XmString tempLabel;
XmString stateLabel;

/* ====================================================================== */
void main (argc, argv)
int argc;
char **argv;
{
    Arg args[20];
    int n;

  /* -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= */
  /*      Window Initialize                                             */
  /* -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= */

    XtToolkitInitialize();
    app_context=XtCreateApplicationContext();
    dp1= XtOpenDisplay(app_context, (char *)getenv("DISPLAY"), 
		       "TJQKA", "TJQKA",
		       NULL, 0, &argc, argv);
    top1 = XtAppCreateShell("TJQKA", "TJQKA", 
				topLevelShellWidgetClass, 
				dp1, NULL,0);

   /* Base Window */
   questionBox(top1);

   /* Base No.2 */
   n=0;
   XtSetArg(args[n], XmNwidth, 420);n++;
   XtSetArg(args[n], XmNheight,420);n++;
   bb2 = XmCreateBulletinBoard(top1, "bb2", args, n);
   XtManageChild(bb2);

   /* Quit Button */
   n=0;
   XtSetArg(args[n], XmNy, 10);n++;
   XtSetArg(args[n], XmNheight, 30);n++;
   buttonquit = XtCreateManagedWidget ("buttonquit", xmPushButtonWidgetClass,
				   bb2, args, n); 
   XtManageChild(buttonquit);
   XtAddCallback(buttonquit, XmNactivateCallback, quitCB, NULL);

  /* -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= */
  /*       Loop to wait for buttons                                     */
  /* -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= */
   /* === Window Activate === */

   XtRealizeWidget(top1);

   XtAppMainLoop(app_context);
}

/* ====================================================================== */
void quitCB (w, client_data, call_data) 
Widget      w;    /*  widget id*/ 
caddr_t     client_data;/*  data from application  */ 
caddr_t     call_data;/*  data from widget class  */
{ 
/*  print message, free compound string memory, and terminate program */ 
      printf ("Quit\n");
      exit (0); 
} 

/* end of file */
