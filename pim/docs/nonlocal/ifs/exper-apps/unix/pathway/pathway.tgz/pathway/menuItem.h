/* -*-C++-*- */
#ifndef MOTIFHEAD_H
#define MOTIFHEAD_H

#include <Xm/Xm.h>

class MenuItem{
  char *label;             // the label for item
  WidgetClass *class;      // pushbutton, label, separator...
  char mnemonic;           // mnemonic; NULL if none
  char *accelerator;       // accelerator; NULL if none
  char *accel_text;        // to be converted to compound string
  void (*callback)();      // routine to call; NULL if none
  XtPointer callback_data; // cliant_data for callback()

public:
  MenuItem();
  ~MenuItem();

};
#endif
