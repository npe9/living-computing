/* -*-C++-*- */
#include <Xm/Xm.h>

class bindExpress {

  Widget bindBox;
  Widget bind, allowLeft, name1;
  Widget allowRight, express, box, name2, sepa;

public:
  bindExpress(Widget,unsigned short,unsigned short);
  void Name1(char*);
  void Name2(char*);
  void Box(char*);
  char* Name1(void);
  void Position(unsigned short,unsigned short);
};
