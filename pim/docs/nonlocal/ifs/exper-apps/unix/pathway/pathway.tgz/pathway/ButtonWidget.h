/* -*-C++-*- */
///////////////////////////////////////////////////////////////
// ButtonWidget.h : using PushButton Widget
// '94.6.3 Fri
///////////////////////////////////////////////////////////////

#ifndef BUTTONWIDGET_H
#define BUTTONWIDGET_H

#include "motifhead.h"

class CircleButton : public MotifHead{
private:
  static void SelectItemCB(Widget w, caddr_t *cliant_data, caddr_t *callData);

protected:
  Widget label;
  Widget button;

public:
  CircleButton(Widget, char*);
  virtual void LabelChange(char *);
  virtual inline void horizontal(void)
    {XtVaSetValues(row, XmNorientation, XmHORIZONTAL, NULL);}
};

#endif
