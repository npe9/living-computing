typedef union { 
  int i;
  AttrRel       ar;
  Rel           sr;
  MQ_Atom       atom;
  MQT_AtomList  atom_list;

  MQT_Obj       obj;
  MQT_Dot       dot;
  MQT_Var       variable;

  MQT_Term      term;
  MQT_VTerm     vterm;

  MQT_VTermList	vterm_list;

  MQT_AttrList    attr_list;
  MQT_Constraints cnstrs;
} YYSTYPE;
#define	ERROR_TOKEN	258
#define	CLEAR	259
#define	LOAD	260
#define	QUERY	261
#define	QUIT	262
#define	SET	263
#define	SHOW	264
#define	LEX_TRUE	265
#define	PROGRAM	266
#define	RULE	267
#define	SUBSUMPTION	268
#define	END	269
#define	PROGRAM_MODE	270
#define	QUERY_ONCE_MODE	271
#define	QUERY_MODE	272
#define	ATOM	273
#define	VARIABLE	274
#define	DOT	275
#define	TERMINATER	276
#define	SOLVE	277
#define	COMMITS	278
#define	CONSTRAINED	279
#define	SUBREL	280
#define	ATTRREL	281

