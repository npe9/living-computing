/* ---------------------------------------------------------- 
%   (C)1994 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
#define FOUR 4
#define EPS 1.0e-6

typedef struct data_set
{
    char *source;
    char *position;
    char *sequence;
    float score;
} DATA_SET;

