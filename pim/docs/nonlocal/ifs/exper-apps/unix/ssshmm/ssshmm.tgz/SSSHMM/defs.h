/* ---------------------------------------------------------- 
%   (C)1995 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
/*
      Header for DHMM
                         Ver 1.2  1993. 8. 9 SSS [Manual Splitting]
			     2.0        3.15 SSS TERMINAL STATE
*/

#define NODEMAX 50  /* Upper Limit of the Node Number */
#define TIMEMAX 600
#define PATHMAX 3000
#define AMINOS 26  /* Caution! */
#define SAMPLEMAX 200
#define SAMPLE_LENGTH 1000
#define READBUFSIZE ((SAMPLEMAX * SAMPLE_LENGTH)*2)

#define TERMINALSTATE 0

#define PI 3.141592653589793
#define EU 2.718281828459045

#define mRANGE         -1900000000  /* Lower Limit:
				      log_near1((MIN_A*MIN_B)^NMAX)*/
#define pRANGE          2000000000  /* Upper Limit */
#define TableMAX         100000  /* $BBP?t4X?tI=$N%W%i%9HO0O(B  */
#define NEAR1            1.0001  /* $BBP?t4X?t$NDl(B            */

#define LINK 1       /* Value of the hmNetArcs */
#define NOLINK 0
#define ALIVE 1      /* Value of the hmNetNodes */
#define DEAD 0
#define ON 1
#define OFF 0
#define NORMAL 0
#define ABNORMAL 1
#define NOASSIGNED -1
#define SERIAL12 1
#define SERIAL21 2
#define PARALLEL 3

#define INITIAL_MU (log_near1(5.0))
#define INITIAL_SIGMA1 (log_near1(0.5))
#define INITIAL_SIGMA2 (log_near1(0.5))

#define SIGMA_FLOOR (log_near1(0.005))
#define OUTPUT_FLOOR (log_near1(0.0001))
#define TRANS_FLOOR (log_near1(0.001))

#define X_PILESIZE 50  /* for Pile Graph */
#define WDHEIGHT 200

#define SQ_SIZE 36     /* 3D Graph Space for 3D Talk */
#define FORE 0
#define BACK 1
#define PRIMARY 0
#define SECONDARY 1
#define END -1
#define V_END -1
#define V_CONTINUE 0
#define BARWIDTH 200

/*-----------------------------------------
/usr/local/share/lib/gcc-lib/sparc-sun-sunos4.1.1/2.3.3/include/float.h
-----------------------------------------*/

/* Minimum normalised double */
/* #undef DBL_MIN */
/* #define DBL_MIN 2.2250738585072014e-308 */

/* Maximum double */
/* #undef DBL_MAX */
/* #define DBL_MAX 1.7976931348623157e+308 */
