/* ---------------------------------------------------------- 
%   (C)1995 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <X11/Xutil.h>
#include <Xm/Xm.h>
#include <Xm/BulletinB.h>
#include <Xm/PushB.h>
#include <Xm/Label.h>
#include <Xm/LabelG.h>
#include <Xm/SeparatoG.h>
#include <Xm/PushBG.h>
#include <Xm/DrawingA.h>

#include <stdio.h>
#include <string.h>
#include <math.h>

#include "defs.h"
#include "struct.h"

#define SAMPLE_FN "protein.sample"
#define CONFFILE "hmn.conf"

Widget top1,top2;

/* ====================================================================== */
void main (argc, argv)
int argc;
char **argv;
{
    XtAppContext app_context;
    Display *dp1;
    Arg args[20];

    log_of_near1 = log(NEAR1); /* base constant */
/*    init_rnd(3); */

  /* -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= */
  /*      Window Initialize                                             */
  /* -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= */

    XtToolkitInitialize();
    app_context=XtCreateApplicationContext();
    XtSetLanguageProc(NULL,NULL,NULL);
    dp1= XtOpenDisplay(app_context, (char *)getenv("DISPLAY"), "DHMM", "DHMM",
		       NULL, 0, &argc, argv);
    top1 = XtAppCreateShell("Network", "DHMM", 
			    applicationShellWidgetClass, 
			    dp1, NULL,0);
    top2 = XtAppCreateShell("Probabilities", "DHMMG", 
			    applicationShellWidgetClass, 
			    dp1, NULL,0);

  /* -------------------------------------- */
  /*      Get Sample Data                   */
  /* -------------------------------------- */
    strcpy(samplefilename,SAMPLE_FN);
    getsample(samplefilename);

  /* -------------------------------------- */
  /*      Get HMM Configuration from file   */
  /* -------------------------------------- */
    strcpy(hmnfilename,CONFFILE);
    gethmn_file(hmnfilename); /* .nodenum .arc[][].link */

  /* -------------------------------------- */
  /*      Display Configuration             */
  /* -------------------------------------- */
    hmmdisplay(top1);

  /* -------------------------------------- */
  /*      Display Output Distribution       */
  /* -------------------------------------- */
    outputdisplay(top2);

  /* -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= */
  /*       Loop to wait for buttons                                     */
  /* -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= */
   /* === Window Activate === */
   XtAppMainLoop(app_context);

}

/* ====================================================================== */
/* end of file */

