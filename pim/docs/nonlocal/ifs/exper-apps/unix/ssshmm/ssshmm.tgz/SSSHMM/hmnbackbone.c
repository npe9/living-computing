/* ---------------------------------------------------------- 
%   (C)1995 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
main(argc,argv)
int argc;
char *argv[];
{
  int size,i,j;

  if(argc < 2 || argc > 3) {
    printf("[Usage:] HmnALC size\n");
    exit(0);
  }
  sscanf(argv[1],"%d",&size);

  printf("## hmnet auto linear configuration %d\n",size);
  printf("S 0.0 1.0");
  for(i=0;i<size-1;i++)
    printf(" 0.0");
  printf("\n");

  for(i=1;i<=size;i++){
    printf("M");
    for(j=0;j<size+1;j++){
      if(i==j || i+1==j || (i==size && j==0))
	printf("   1");
      else 
	printf("   0");
    }
    printf("\n");
  }
}
