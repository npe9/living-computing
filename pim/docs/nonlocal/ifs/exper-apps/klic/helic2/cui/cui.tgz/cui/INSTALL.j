	                CUI $B%$%s%9%H!<%k!&%^%K%e%"%k(B
                                                                		
1. $B35MW(B
                                                                
CUI(Character-based User Interface)$B$N<B9T4D6-$H%$%s%9%H!<%kJ}K!$K4X$7$F@bL@$7$F(B
$B$$$^$9!#%$%s%9%H!<%k$9$k$K$"$?$j!"$^$:!V(B2. $B<B9T4D6-!W$rFI$s$G;vA03NG'$r9T$J$C$F(B
$B2<$5$$!#$=$N8e$N%$%s%9%H!<%k<j=g$O!V(B3. $B%$%s%9%H!<%kJ}K!!W$K5-:\$5$l$F$$$^$9!#(B

2. $B<B9T4D6-(B

$B0J2<$N4D6-$G%$%s%9%H!<%k$dF0:n$9$k$3$H$O3NG'$r$7$^$7$?!#(B

(1) $B%O!<%I(B
        (a) $B%^%7%s(B
                Sun SparcStation 10 
        (b) $B%a%b%j(B
                32MB$B0J>e(B
        (c) $B%O!<%I%G%#%9%/(B
                40MB

(2) $B%=%U%H(B
        (a) OS
                SunOS 4.1.3
        (b) C$B%3%s%Q%$%i(B 
                gcc-2.6.2
        (c) KLIC(KLIC$B$b(BIFS$B%W%m%0%i%`$G$"$k(B)
                1.7$B0J>e(B
        (d) $BF|K\8l4D6-(B
                $BF|K\8l$J$I$N(B2byte$B%-%c%i%/%?$r;H$($k(BCUI$B$r%$%s%9%H!<%k$9$k$K$O0J2<(B
		$B$N(Bgcc$B$N%i%$%V%i%j$+%X%C%@%U%!%$%k$N$I$A$i$+$,I,MW$G$9!#(B

                $B!&(B $B%i%$%V%i%j(B
                        libfl.a
                $B!&(B $B%X%C%@%U%!%$%k(B
                        euc.h

3. $B%$%s%9%H!<%kJ}K!(B

(0) KLIC$B$N%$%s%9%H!<%k(B
    CUI$B$r%$%s%9%H!<%k$9$kA0$KI,$:(BKLIC$B$,%$%s%9%H!<%k$5$l$F$$$J$1$l$P$J$i$J$$!#(B

(1) Makefile$B$N=$@5(B
    cui/src$B$N2<$K$"$k(BMakefile$B$N4D6-JQ?t$r0J2<$K=>$C$F=$@5$7$F$/$@$5$$!#(B
   

 (a) Flex$B$N=$@5(B

        (i) flex Library(libfl.a)$B$,B8:_$9$k>l9g$O0J2<$N$h$&$K$7$F$/$@$5$$!#(B

                Flex = exist

        (ii) flex Library(libfl.a)$B$,B8:_$7$J$$>l9g$O0J2<$N$h$&$K$7$F$/$@$5$$!#(B

                Flex = nothing

 (b) LANG$B$N=$@5(B
     flex Library(libfl.a)$B$,B8:_$9$k>l9g$O$3$N=$@5$OI,MW$"$j$^$;$s!#(B

        (i) $B%k!<%k$d35G0L>$K(B2byte$B%-%c%i%/%?(B($BF|K\8l$J$I(B)$B$r;H$$$?$$>l9g$O!"0J2<$N(B
	    $B$h$&$K$7$F$/$@$5$$!#(B

                LANG = japanese

            $B$3$N>l9g$O!"0J2<$N(Bgcc$B$N%X%C%@%U%!%$%k$,(Bmake$B<B9T;~$KI,MW$K$J$k$3$H$r(B
	    $BCm0U$7$F2<$5$$!#(B

                euc.h

        (ii) $B%k!<%k$d35G0L>$K(B2byte$B%-%c%i%/%?(B($BF|K\8l$J$I(B)$B$r;H$o$J$$>l9g$O!"0J2<$N(B
	     $B$h$&$K$7$F$/$@$5$$!#(B

                LANG = english

(2) make$B$N<B9T(B
    $B%+%l%s%H!&%G%#%l%/%H%j$r(Bcui/src$B$K$7$F0J2<$r<B9T$7$F$/$@$5$$!#(B
    $B%W%m%0%i%`$,%3%s%Q%$%k$5$l!"(Bcui/bin$B$K(BCUI$B$d%H%i%s%9%l!<%?$N<B9T%U%!%$%k$,:n@.(B
    $B$5$l$^$9!#(B


        make 

(3) $B4D6-JQ?t(Bpath$B$N=$@5(B
    CUI$B$d%H%i%s%9%l!<%?$G$O!"%k!<%k$d%4!<%k$rJQ49$9$k:]$KJQ49%W%m%0%i%`$r8F$S=P(B
    $B$7$F$$$^$9!#(B

    $B$3$NJQ49%W%m%0%i%`$O(Bmake$B$,<B9T$5$l$k$H(Bcui/bin$B$K:n@.$5$l$^$9!#(B

    $B$=$N$?$a!"$3$NJQ49%W%m%0%i%`$N<B9T%U%!%$%k$,$I$3$K$"$k$+$r(B.cshrc$B$J$I$GDj5A$5(B
    $B$l$F$$$k4D6-JQ?t(Bpath$B$K@_Dj$7$F$*$+$J$1$l$P$$$1$^$;$s!#(B

    $BNc$($P$3$NJQ49%W%m%0%i%`$,(B~/cui/bin$B$K$"$k>l9g!"(B.cshrc$B$N(Bpath$B$K$3$N%Q%9$r0J2<(B
    $B$N$h$&$KDI2C$7$^$9!#(B

        $B=$@5A0(B:
                set path=(~/)

        $B=$@58e(B:
                set path=(~/ ~/cui/bin)

4.$BF0:n%F%9%H(B

$B4JC1$JF0:n%F%9%H$NNc$r0J2<$K<($9!#(B

"+"$B$O>e$NJ8;z$,%f!<%6$NF~NO$G$"$k$3$H$rI=$9!#(B

$B$^$?!"$3$N<B9T$O%+%l%s%H!&%G%#%l%/%H%j$,(B"cui/data"$B$N;~$N$b$N$G$"$k!#(B

!cd cui/data
 +++++++++++
!cui
 +++
HELIC-II>run cntrct.c
	 ++++++++++++

<<<<<$B>JN,(B>>>>>

ok
HELIC-II>start
	 +++++
History : start

<<<<<$B>JN,(B>>>>>

Status : defendant finish p0
Status : defendant finished p0
ok
HELIC-II>quit
         ++++

