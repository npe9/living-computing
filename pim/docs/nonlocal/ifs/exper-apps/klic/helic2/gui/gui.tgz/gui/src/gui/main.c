/*
	(C)1994 Institute for New Generation Computer Technology	
	(Read COPYRIGHT for detailed information.)			
*/

#include <Xm/Form.h>

#define MAIN
#include "gui.h"
#include "messages.h"

void main(int argc, char **argv)
{
  Widget tmp;

  XtSetLanguageProc(NULL, NULL, NULL);
  XtToolkitInitialize();
  application1 = XtCreateApplicationContext();
  display1 = XtOpenDisplay(application1, (String)getenv("DISPLAY"),
			   "helicII", "HelicII", 
			   NULL, 0, 
			   &argc, argv);
  toplevel = XtAppCreateShell("helicII", "HelicII", 
			      applicationShellWidgetClass, display1, NULL, 0);

/* Application$B$r;H$o$J$$>l9g$N=i4|=hM}(B
  toplevel = XtInitialize(argv[0], "HelicII", NULL, (int)NULL, &argc, argv);
*/

  GuiComInit(argc, argv); /* $BDL?.It$N=i4|2=(B */

  GuiFontCreate();

  GuiCreateInitWindow();
  GuiCreateLoadWindow();
  GuiCreateRoleWindow();

  XtRealizeWidget(toplevel);
  GuiMainLoop();
}

void GuiMainLoop()
{
/*  XtAppMainLoop(application1);*/
/* $B%a%$%s%k!<%W(B */
  while(True) {
    XEvent event;
    if(XtAppPending(application1)) {
      XtAppNextEvent(application1,&event);
      XtDispatchEvent(&event);
    } 
    if (GuiPending()) {
      GuiRunData();
    }
  }
}



