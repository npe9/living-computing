/*
	(C)1994 Institute for New Generation Computer Technology	
	(Read COPYRIGHT for detailed information.)			
*/

/* $B%(%i!<%a%C%;!<%8(B */
/* $B8e$G1Q8l$KK]Lu(B */

#define NO_SET_GOAL "No goal is set." /*"$B%4!<%k$,@_Dj$5$l$F$$$^$;$s(B"*/
#define DEBATE_ENDING "Debate will end.\nAre you sure?" /*$BO@Ah$r=*N;$7$^$9!#(B\n $B$$$$$G$9$+!)(B"*/
#define DEBATE_ENDED "Prosecutor ends debate." /* "$BO@Ah$,=*N;$7$^$7$?(B" */
#define DEPTH_INPUT_ERROR "Please set depth with integer upper than -1 or -1"
#define BUG_FINDED "A bug is finded. Please report it to ifs."
#define NO_PATH "gtrans is not on your command path.\nPlease check your path."
#define UNKNOWN_ERROR "Unknown error occured !! errno = "

/* $B%a%C%;!<%8(B */

#define NOTICE_DRAW_MESSAGE "Do you claim Reasonable Doubt" /* $B9gM}E*$J5?$$$,;D$k$3$H$r(B\n$BAj<j$K<gD%$7$^$9$+!)(B"*/
#define SET_FORM "Please select display form"
#define SET_DEPTH "Please set depth of planing ahead\n  Current level = "
#define EXPLANATION_LABEL "'s explanation"

/* $B$=$NB>(B */
#define GOAL_TRANSLATE "gtrans goal "

