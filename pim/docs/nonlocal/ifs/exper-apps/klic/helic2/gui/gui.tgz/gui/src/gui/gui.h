/*
	(C)1994 Institute for New Generation Computer Technology	
	(Read COPYRIGHT for detailed information.)			
*/

/**************/
/* $B%^%/%mDj5A(B */
/**************/

#ifdef MAIN
#define EXTERN
#else
#define EXTERN extern
#endif MAIN

/* $BL58B%k!<%W$rHr$1$k$?$a$N:GBg?t(B */
#define INFINITE 10000

/* GuiXmAttachWidget$B$N@\?(J}<0$N;XDj(B */
#define GuiREG 1 /* GuiXmAttachWidget$B$G(BXmATTACH_WIDGET$B$r;XDj$9$k>l9g(B */
#define GuiOPP 2 /* GuiXmAttachWidget$B$G(BXmATTACH_OPPOSITE_WIDGET$B$r;XDj$9$k>l9g(B*/

/* GuiXm$B%f!<%F%#%j%F%#$N%j%=!<%9@_Dj$N$?$a$N%^%/%m(B */
#define GuiSa(n, d) \
    ((void)( (GuiXArg[GuiXArgNum]).name = \
	    (n), (GuiXArg[GuiXArgNum]).value = (XtArgVal)(d), GuiXArgNum++ ))
#define GuiSt() (GuiXArgNum = 0)
#define GuiSv(w) XtSetValues(w,GuiXArg,GuiXArgNum)
#define GuiSg(w) XtGetValues(w,GuiXArg,GuiXArgNum)

/* callback$B%k!<%A%sDj5A$N$?$a$N%^%/%m(B */
#define GuiCallback(fname) \
  void fname(Widget w, XtPointer client_data, XtPointer call_data)

/* $B%(%i!<%]%C%W%"%C%W%&%$%s%I%&I=<($N$?$a$N%^%/%m(B */
#define GuiErrSp \
  GuiErrorStopPopup( ComErrorMessage )
#define GuiErrCt \
  GuiErrorPopup( ComErrorMessage )
#define GuiWarn \
  GuiWarningPopup( ComErrorMessage )
#define GuiErrOn \
  switch( (int)ComErrorType ) {\
    case 0: GuiErrSp;return;\
    case 1: GuiErrCt;return;\
    case 2: GuiWarn;return;}

/* $B%(%i!<%]%C%W%"%C%W%&%$%s%I%&I=<($N$?$a$N%^%/%m(B $B!JM-0z?t!K(B*/
#define GuiErrSpA(x) \
  GuiErrorStopPopup( x )
#define GuiErrCtA(x) \
  GuiErrorPopup( x )
#define GuiWarnA(x) \
  GuiWarningPopup( x )

/* $B%(%i!<=hM}$N$?$a$N%^%/%m(B */
#define GuiMacro(x) \
  if( (x == COM_NG) ) \
   switch( (int)ComErrorType ) {\
    case 0: GuiErrSp;return;\
    case 1: GuiErrCt;return;\
    case 2: GuiWarn;return;}


#define GuiMacroP(w,x) \
  GuiWait(w); \
  if( (x == COM_NG) ) {\
   GuiWaitClose();\
   switch( (int)ComErrorType ) {\
    case 0: GuiErrSp;return;\
    case 1: GuiErrCt;return;\
    case 2: GuiWarn;return;}}\
  GuiWaitClose();

/* $BDL?.It$N%G!<%?$K%"%/%;%9$9$k$?$a$N%^%/%m(B */
#define GuiCm(c) ((c *)(ComMessageInfo.message))
#define GuiCt ComMessageInfo.type

/* String$B$r%3%T!<$9$k$?$a$N%^%/%m(B */
#define GuiStrCp(x,y) x=strcpy(XtMalloc(strlen(y)+1),y)

/* COMSTRING$B$r%3%T!<$9$k$?$a$N%^%/%m(B */
#define ComStringCp(x,t,r) \
  {\
    x = XtMalloc((strlen(GuiCm(t)->r)+1));\
    strcpy(x,GuiCm(t)->r);\
  }

/* COMLIST$B$N:GBg?t$r5a$a$k%^%/%m(B */
#define ComListMax(t,r,m) \
 {\
    int n = 0;\
    while(GuiCm(t)->r[n] != (char *)NULL)\
      n++;\
    m = n;\
  }

/* COMLIST$B$r%3%T!<$9$k$?$a$N%^%/%m(B */
#define ComListCp(x,m,t,r) \
{\
  int i;\
  x = (char **)XtCalloc(m,sizeof(char *));\
  for(i = 0; i < m; i++) {\
    (x)[i] = XtMalloc((strlen((GuiCm(t)->r)[i])+1));\
    strcpy((x)[i],(GuiCm(t)->r)[i]);\
  }\
}

/* $B%U%)%s%H@_Dj$N$?$a$N<1JL;R(B */
#define GUI_F_BOLD24 "bold24"
#define GUI_F_BOLD24_B "-adobe-helvetica-bold-r-normal-*-24-*-*-*-*-*-*-*"
#define GUI_F_BOLD18 "bold18"
#define GUI_F_BOLD18_B "-adobe-helvetica-bold-r-normal-*-18-*-*-*-*-*-*-*"
#define GUI_F_ITAL14 "ital14"
#define GUI_F_ITAL14_B "-adobe-times-medium-i-normal-*-14-*-*-*-*-*-*-*"
#define GUI_F_ITAL18 "ital18"
#define GUI_F_ITAL18_B "-adobe-times-medium-i-normal-*-18-*-*-*-*-*-*-*"
#define GUI_F_ITAL34 "ital34"
#define GUI_F_ITAL34_B "-adobe-times-medium-i-normal-*-34-*-*-*-*-*-*-*"
#define GUI_F_MEDI18 "medi18"
#define GUI_F_MEDI18_B "-adobe-times-medium-r-normal-*-18-*-*-*-*-*-*-*"

/* $BCN<1%Y!<%9%U%!%$%k$N@\Hx;R$NDj5A(B */
#define TYPE_SUFFIX "*.t"
#define RULE_SUFFIX "*.r"
#define VIEW_SUFFIX "*.v"
#define QUERY_SUFFIX "*.g*"
#define COMMAND_SUFFIX "*.c"

/* $BCN<1%Y!<%9%U%!%$%k$N<oN`$NDj5A(B */
#define FILE_TYPE_NUM 5
#define TYPE_FILE 0
#define RULE_FILE 1
#define VIEW_FILE 2
#define QUERRY_FILE 3
#define COMMAND_FILE 4

/* $BO@Ah$NLr3d!&Ev;v<T$NDj5A(B */
#define POS_NUM 2  /* $BO@Ah$NEv;v<T$N?t(B */
#define PROSECUTOR 0
#define DEFENDANT 1
#define DRS 0 /* DRS$B$r8!;!C1BN$GF0$/O@Ah$H$7$F07$&(B */
#define SYSTEM 0
#define USER 1

/* 95.2.25 Add for showing current level */
/* $B@hFI$_$NCJ?t$N%G%U%)%k%HCM(B */
#define P_AHEAD 1  /* $B8!;!(B(DNR) */
#define D_AHEAD 1  /* $BHo9p(B */

/* $BDL?.It$+$i$N5"$jCM(B */
#define COM_OK 0
#define COM_NG -1

/* $B0z?t$N=$>~;R(B */
#define HELIC_ARG_DEBUG "-netdebug" /* $BDL?.It$X%G%P%C%0$r;XDj$9$k0z?t$NJ8;z(B */
#define HELIC_ARG_HOST "-host" /* $B%5!<%P!<$N%[%9%HL>(B */
#define HELIC_ARG_PORT "-port" /* $B%5!<%P!<$N%]!<%HHV9f(B */

/******************/
/* $B30ItDj?t$NDj5A(B */
/******************/

/* GUI$B$K$F=hM}$9$Y$-%G!<%?$,$"$k$+$I$&$+$N%U%i%0(B
   X$B$N%a%$%s%k!<%W$K$F;2>H$9$k!#(B */
#ifdef MAIN
Boolean guiPending = False;
#else
extern Boolean guiPending;
#endif MAIN

/* $B%m!<%I%&%$%s%I%&$N(Btoggle$B$NL>A0$NDj5A(B */
#ifdef MAIN
char *fileType[FILE_TYPE_NUM] = 
               { "Type", "Rule", "View", "Goal", "Command" }; /* 95.2.3 */
char loadFlag;
#else
extern char *fileType[];
extern char loadFlag;
#endif MAIN

/* $B%m!<%I>u67$r<($9JQ?t(B */
#ifdef MAIN
char loadFlag = 0x00;
/* (Goal)(View)(Rule)(Type) */
#else
extern char loadFlag;
#endif MAIN

/* $B=i4|%&%$%s%I%&$K$*$1$k%m!<%I>u67$NI=<(J8;zNs(B */
#ifdef MAIN
char *loadingStatusString[5] = 
{ "Type file hasn't been loaded yet.",
    "Rule file hasn't been loaded yet.",
    "View file hasn't been loaded yet.",
    "Query file hasn't been loaded yet.",
    "We can run a debate."};
int loadingStatus = 0;
#else
extern char *loadingStatusString[];
extern int loadingStatus;
#endif MAIN

/* $B=i4|%&%$%s%I%&$K$*$1$kLr3d@_Dj>u67$NI=<(J8;zNs$HLr3d@_Dj>u67JQ?t(B */
#ifdef MAIN
char *roleStatusString[5] = 
{ "Nothing Assigned\n",
    "Prosecutor is roled by System\nDefendant is roled by System.",
    "Prosecutor is roled by System\nDefendant is roled by User.",
    "Prosecutor is roled by User\nDefendant is roled by System.",
    "Prosecutor is roled by User\nDefendant is roled by User."};
int roleStatus = 0;
#else
extern char *roleStatusString[];
extern int roleStatus;
#endif MAIN

/* $BLr3d@_Dj$N%U%i%0(B */
#ifdef MAIN
int roleAssign[2] = { -1, -1 };
/* roleAssign[PROSECUTOR] == USER $B$H$$$&;H$$J}(B */
#else
extern int roleAssign[];
#endif MAIN

/******************/
/* $B30ItJQ?t$NDj5A(B */
/******************/

/* $B4pK\OH$NDj5A(B */
EXTERN XtAppContext application1;
EXTERN Display *display1;
EXTERN Widget toplevel;

Widget init_form;

/* $BO@Ah%&%$%s%I%&(B */
Widget dbtform[POS_NUM];
Widget dbtHis[POS_NUM], dbtView[POS_NUM], dbtGoal[POS_NUM];
Widget dbtStat[POS_NUM], dbtIss[POS_NUM], dbtArg[POS_NUM];

/* Font List$B$NDj5A(B */

XmFontList GuiFontList;

/* XArg$B$NDj5A(B */

#define MAX_XARG 50
EXTERN Arg GuiXArg[MAX_XARG];
EXTERN int GuiXArgNum;
EXTERN Widget GuiXmW;

/**************/
/* $B4X?t$NDj5A(B */
/**************/

EXTERN void GuiMainLoop();

/* UTIL$B4X?t$NDj5A(B */

#ifndef UTIL
extern void GuiXmAttachForm();
extern void GuiXmAttachPos();
extern void GuiXmAttachWidget();
extern Widget GuiXmCreateForm();
extern Widget GuiXmCreateSeparatorHorizontal();
extern Widget GuiXmCreateFrame();
extern Widget GuiXmCreateLabel();
extern Widget GuiXmCreateCheckBox();
extern Widget GuiXmCreateRadioBox();
extern Widget GuiXmCreateRowColumn();
extern Widget GuiXmCreateToggleButtonGadget();
extern Widget GuiXmCreateButton();
extern void GuiFontCreate();
extern Widget GuiXmCreateFormDialog();
extern void GuiMakeAndSetLabel();
extern Widget GuiXmCreateText();
extern void GuiXmTextAddString();
extern Widget GuiXmCreateTextField();
extern Widget GuiXmCreateScrolledList();
extern void GuiErrorStopPopup();
extern void GuiErrorPopup();
extern void GuiWarningPopup();
extern void GuiXmListAddItem();
extern Widget GuiXmCreateButtonGadget();
extern Widget GuiBuildPopupMenu();
extern Widget GuiXmCreateSelectionDialog();
extern void GuiShortLoop();
extern void GuiWait();
extern void GuiWaitClose();
#endif UTIL

/****************/
/* $B%G!<%?%Y!<%9(B */
/****************/

#define DB_INIT -1 /* $B%G!<%?%Y!<%9$N=i4|CM(B */

#ifdef MAIN
/* $BA4$F$NH=CG4p=`(B */
char **allStandPoint; /* $BA4$F$NH=CG4p=`$NL>A0$N%j%9%H(B */
int allStandPoint_num = DB_INIT; /* $BA4$F$NH=CG4p=`$N?t(B */

/* $BA4$F$N(BView$B8uJd(B */
char **allViewCList; /* $BA4$F$NH=CG4p=`$NL>A0$N%j%9%H(B */
int allViewCList_num = DB_INIT; /* $BA4$F$NH=CG4p=`$N?t(B */

/* $B8=:_@_Dj$7$F$$$k%f%K%C%HL>(B */
char **currentUnitList[POS_NUM];
int currentUnitList_num[POS_NUM] = { DB_INIT, DB_INIT };

/* $B8=:_@_Dj$7$F$$$k%4!<%k(B */ 
short currentGoal[POS_NUM] = { DB_INIT, DB_INIT };

/* $BA4$F$N%4!<%k8uJd(B */
char **goalCandidateList;
int goalCandidateList_num = DB_INIT;

/* $B8=:_@_Dj$5$l$F$$$k2ACM46(B */
char **currentView[POS_NUM];
int currentView_num[POS_NUM] = { DB_INIT, DB_INIT };

/* $BI=<(O@>Z!"I=<(O@>Z$N?FO@>Z!"%U%)!<%+%9O@>Z(B */
char *displayedArgId[POS_NUM] = {(char *)NULL, (char *)NULL};
char *parentArgId[POS_NUM] = {(char *)NULL, (char *)NULL};
char *focusArgId[POS_NUM] = {(char *)NULL, (char *)NULL};

/* 95.2.25 Add for showing current level */
/* $B8=:_@_Dj$5$l$F$$$k@hFI$_$NCJ?t(B */
int d_ahead[2] = {P_AHEAD, D_AHEAD};  /* $B8!;!(B(DNR) + $BHo9p(B */

#else
extern char **allStandPoint;
extern int allStandPoint_num;
extern char **allViewCList;
extern int allViewCList_num;
extern char **currentUnitList[];
extern int currentUnitList_num[];
extern short currentGoal[];
extern char **goalCandidateList;
extern int goalCandidateList_num;
extern char **currentView[];
extern int currentView_num[];
extern char *displayedArgId[]; 
extern char *parentArgId[];
extern char *focusArgId[];
extern int d_ahead[];
#endif MAIN
