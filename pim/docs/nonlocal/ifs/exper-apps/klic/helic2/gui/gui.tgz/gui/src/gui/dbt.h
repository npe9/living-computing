/*
	(C)1994 Institute for New Generation Computer Technology	
	(Read COPYRIGHT for detailed information.)			
*/

#ifdef DBTMAIN
#define DBTEXTERN
#else
#define DBTEXTERN extern
#endif DBTMAIN

/* $B%\%?%s$N?t$N@_Dj(B */
#define TOP_NUM 6 /* $B>eItA`:n%(%j%"$N%\%?%s$N?t(B */ /* 95.2.20 Add for Depth */
#define MID_NUM 6 /* $BCfItA`:n%(%j%"$N%\%?%s$N?t(B */ 
#define BOT_NUM 9 /* $B2<ItA`:n%(%j%"$N%\%?%s$N?t(B */ /* 95.1.17 Add for Form */

/* $B%&%$%s%I%&$NBg$-$5(B */
#define DBT_CLM 60 /* DBT$B$NO@>Z$NI}(B 70 */ 
#define DBT_LINE 18 /* DBT$B$NO@>Z$N9T(B 18 */ 
#define DBT_STAT_ROW 3 /* Status$B>pJs$N9T$N?t(B 5 */
#define DBT_HIST_ROW 2 /* History$B>pJs$N9T$N?t(B 3 */
#define DBT_WIDTH 350
#define JST_WIDTH 200
#define NTS_WIDTH 200

/* $B%\%?%s(BWidget */
DBTEXTERN Widget topB[POS_NUM][TOP_NUM];
DBTEXTERN Widget midB[POS_NUM][MID_NUM];
DBTEXTERN Widget botB[POS_NUM][BOT_NUM];

DBTEXTERN Widget argSlct;

/* $BO@>Z@bL@%&%$%s%I%&$N%F%-%9%H$NBg$-$5(B */
#define EXP_WIDTH 400
#define EXP_HEIGHT 400

/* $BO@>Z@bL@I=<(%&%$%s%I%&(B */
DBTEXTERN Widget expW;

/* CB$B$N@k8@(B */
void viewCB();
void unitCB();
void goalCB();
void startCB();
void quitCB();
void argSlctEndCB1();
void argSlctEndCB2();
void slctArgCB();
void poseCB();
void noticeCB();
void cancelCB();
void finishCB();
void justifyCB();
void endCB();
void endCB2();
void argLineCB();
void ctrLineCB();
void ctrCancelCB();
void spDoneCB();
void spCancelCB();
void spLineCB();
void noticeLineCB();
void noticeCancelCB();
void noticeOkCB();
void backwardCB();
void forwardCB();
void previousCB();
void nextCB();
void focusCB();
void jumpDoneCB();
void jumpCB();
void claimCB();
void explainCB();
void formCB();
void depthCB();

/* $BO@Ah%&%$%s%I%&$N%\%?%s$N%;%s%7%F%#%S%F%#@_Dj$N$?$a$NG[Ns(B */
#define SENS_NUM 14
Widget sensBut[POS_NUM][SENS_NUM];

