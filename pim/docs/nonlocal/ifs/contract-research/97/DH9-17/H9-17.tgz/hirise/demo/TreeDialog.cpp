//
// HiRiseDemo: a Demo Application of the HiRise Constraint Solver
//
// Copyright (C) 1998 Hiroshi HOSOBE
//
////////////////////////////////////////////////////////////////

// TreeDialog.cpp : �C���v�������e�[�V���� �t�@�C��
//

#include "stdafx.h"
#include "HiRiseDemo.h"
#include "TreeDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTreeDialog �_�C�A���O


CTreeDialog::CTreeDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CTreeDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTreeDialog)
	m_height = 0;
	m_nChildren = 0;
	m_lineWidth = 0;
	m_nodeSize = 0;
	m_seed = 0;
	//}}AFX_DATA_INIT

	m_height = 4;
	m_nChildren = 2;
	m_lineWidth = 2;
	m_nodeSize = 20;
	m_seed = 57014;
}


void CTreeDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTreeDialog)
	DDX_Text(pDX, IDC_TREE_HEIGHT, m_height);
	DDV_MinMaxInt(pDX, m_height, 1, 32);
	DDX_Text(pDX, IDC_TREE_N_CHILDREN, m_nChildren);
	DDV_MinMaxInt(pDX, m_nodeSize, 4, 100);
	DDX_Text(pDX, IDC_TREE_SEED, m_seed);
	//}}AFX_DATA_MAP
#if 0
	DDV_MinMaxInt(pDX, m_nChildren, 1, 32);
	DDX_Text(pDX, IDC_TREE_LINE_WIDTH, m_lineWidth);
	DDV_MinMaxInt(pDX, m_lineWidth, 1, 9);
	DDX_Text(pDX, IDC_TREE_NODE_SIZE, m_nodeSize);
#endif
}


BEGIN_MESSAGE_MAP(CTreeDialog, CDialog)
	//{{AFX_MSG_MAP(CTreeDialog)
		// ���� - ClassWizard �͂��̈ʒu�Ƀ}�b�s���O�p�̃}�N����ǉ��܂��͍폜���܂��B
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTreeDialog ���b�Z�[�W �n���h��
