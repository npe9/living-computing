; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CGraphView
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "hirisedemo.h"
LastPage=0

ClassCount=15
Class1=CBinTreeDialog
Class2=CBinTreeDoc
Class3=CBinTreeView
Class4=CGraphDialog
Class5=CGraphDoc
Class6=CGraphView
Class7=CHiRiseDemoApp
Class8=CAboutDlg
Class9=CKochDialog
Class10=CKochDoc
Class11=CKochView
Class12=CMainFrame
Class13=CTreeDialog
Class14=CTreeDoc
Class15=CTreeView

ResourceCount=14
Resource1=IDR_TREE
Resource2=IDR_GRAPH_TYPE (�p�� (��ض))
Resource3=IDD_GRAPH
Resource4=IDD_BIN_TREE
Resource5=IDR_BIN_TREE
Resource6=IDD_KOCH
Resource7=IDD_TREE
Resource8=IDR_MAINFRAME (�p�� (��ض))
Resource9=IDD_ABOUTBOX (�p�� (��ض))
Resource10=IDR_HIRISETYPE (�p�� (��ض))
Resource11=IDR_BIN_TREE_TYPE (�p�� (��ض))
Resource12=IDR_TREE_TYPE (�p�� (��ض))
Resource13=IDR_KOCH_TYPE (�p�� (��ض))
Resource14=IDR_GRAPH

[CLS:CBinTreeDialog]
Type=0
BaseClass=CDialog
HeaderFile=BinTreeDialog.h
ImplementationFile=BinTreeDialog.cpp

[CLS:CBinTreeDoc]
Type=0
BaseClass=CDocument
HeaderFile=BinTreeDoc.h
ImplementationFile=BinTreeDoc.cpp

[CLS:CBinTreeView]
Type=0
BaseClass=CView
HeaderFile=BinTreeView.h
ImplementationFile=BinTreeView.cpp
Filter=C
VirtualFilter=VWC
LastObject=ID_TREE_ADD

[CLS:CGraphDialog]
Type=0
BaseClass=CDialog
HeaderFile=GraphDialog.h
ImplementationFile=GraphDialog.cpp

[CLS:CGraphDoc]
Type=0
BaseClass=CDocument
HeaderFile=GraphDoc.h
ImplementationFile=GraphDoc.cpp

[CLS:CGraphView]
Type=0
BaseClass=CView
HeaderFile=GraphView.h
ImplementationFile=GraphView.cpp
Filter=C
VirtualFilter=VWC
LastObject=ID_GRAPH_DIRECT

[CLS:CHiRiseDemoApp]
Type=0
BaseClass=CWinApp
HeaderFile=HiRiseDemo.h
ImplementationFile=HiRiseDemo.cpp

[CLS:CAboutDlg]
Type=0
BaseClass=CDialog
HeaderFile=HiRiseDemo.cpp
ImplementationFile=HiRiseDemo.cpp
LastObject=CAboutDlg

[CLS:CKochDialog]
Type=0
BaseClass=CDialog
HeaderFile=KochDialog.h
ImplementationFile=KochDialog.cpp

[CLS:CKochDoc]
Type=0
BaseClass=CDocument
HeaderFile=KochDoc.h
ImplementationFile=KochDoc.cpp

[CLS:CKochView]
Type=0
BaseClass=CView
HeaderFile=KochView.h
ImplementationFile=KochView.cpp

[CLS:CMainFrame]
Type=0
BaseClass=CMDIFrameWnd
HeaderFile=MainFrm.h
ImplementationFile=MainFrm.cpp

[CLS:CTreeDialog]
Type=0
BaseClass=CDialog
HeaderFile=TreeDialog.h
ImplementationFile=TreeDialog.cpp

[CLS:CTreeDoc]
Type=0
BaseClass=CDocument
HeaderFile=TreeDoc.h
ImplementationFile=TreeDoc.cpp

[CLS:CTreeView]
Type=0
BaseClass=CView
HeaderFile=TreeView.h
ImplementationFile=TreeView.cpp
Filter=C
VirtualFilter=VWC
LastObject=CTreeView

[DLG:IDD_BIN_TREE]
Type=1
Class=CBinTreeDialog
ControlCount=4
Control1=IDC_STATIC,static,1342308352
Control2=IDC_BIN_TREE_HEIGHT,edit,1350639744
Control3=IDOK,button,1342242817
Control4=IDCANCEL,button,1342242816

[DLG:IDD_ABOUTBOX]
Type=1
Class=CAboutDlg

[DLG:IDD_TREE]
Type=1
Class=CTreeDialog
ControlCount=8
Control1=IDC_STATIC,static,1342308352
Control2=IDC_TREE_HEIGHT,edit,1350639744
Control3=IDC_STATIC,static,1342308352
Control4=IDC_TREE_N_CHILDREN,edit,1350639744
Control5=IDC_STATIC,static,1342308352
Control6=IDC_TREE_SEED,edit,1350639744
Control7=IDOK,button,1342242817
Control8=IDCANCEL,button,1342242816

[MNU:IDR_MAINFRAME (�p�� (��ض))]
Type=1
Class=?
Command1=ID_FILE_NEW_BIN_TREE
Command2=ID_FILE_NEW_TREE
Command3=ID_FILE_NEW_KOCH
Command4=ID_FILE_NEW_GRAPH
Command5=ID_APP_EXIT
Command6=ID_VIEW_TOOLBAR
Command7=ID_VIEW_STATUS_BAR
Command8=ID_APP_ABOUT
CommandCount=8

[MNU:IDR_BIN_TREE_TYPE (�p�� (��ض))]
Type=1
Class=?
Command1=ID_FILE_NEW_BIN_TREE
Command2=ID_FILE_NEW_TREE
Command3=ID_FILE_NEW_KOCH
Command4=ID_FILE_NEW_GRAPH
Command5=ID_APP_EXIT
Command6=ID_EDIT_UNDO
Command7=ID_EDIT_CUT
Command8=ID_EDIT_COPY
Command9=ID_EDIT_PASTE
Command10=ID_VIEW_TOOLBAR
Command11=ID_VIEW_STATUS_BAR
Command12=ID_WINDOW_CASCADE
Command13=ID_WINDOW_TILE_HORZ
Command14=ID_WINDOW_ARRANGE
Command15=ID_APP_ABOUT
CommandCount=15

[MNU:IDR_BIN_TREE]
Type=1
Class=CBinTreeView
Command1=ID_BIN_TREE_ADD
Command2=ID_BIN_TREE_REMOVE
Command3=ID_BIN_TREE_STAY
Command4=ID_BIN_TREE_LINE
CommandCount=4

[MNU:IDR_TREE]
Type=1
Class=CTreeView
Command1=ID_TREE_ADD
Command2=ID_TREE_REMOVE
Command3=ID_TREE_STAY
Command4=ID_TREE_LINE
CommandCount=4

[MNU:IDR_GRAPH]
Type=1
Class=CGraphView
Command1=ID_GRAPH_NODE
Command2=ID_GRAPH_EDGE
Command3=ID_GRAPH_STAY
Command4=ID_GRAPH_DIRECT
CommandCount=4

[MNU:IDR_HIRISETYPE (�p�� (��ض))]
Type=1
Class=?
Command1=ID_FILE_NEW_BIN_TREE
Command2=ID_FILE_NEW_TREE
Command3=ID_FILE_NEW_KOCH
Command4=ID_FILE_NEW_GRAPH
Command5=ID_APP_EXIT
Command6=ID_EDIT_UNDO
Command7=ID_EDIT_CUT
Command8=ID_EDIT_COPY
Command9=ID_EDIT_PASTE
Command10=ID_VIEW_TOOLBAR
Command11=ID_VIEW_STATUS_BAR
Command12=ID_WINDOW_CASCADE
Command13=ID_WINDOW_TILE_HORZ
Command14=ID_WINDOW_ARRANGE
Command15=ID_APP_ABOUT
CommandCount=15

[MNU:IDR_TREE_TYPE (�p�� (��ض))]
Type=1
Class=?
Command1=ID_FILE_NEW_BIN_TREE
Command2=ID_FILE_NEW_TREE
Command3=ID_FILE_NEW_KOCH
Command4=ID_FILE_NEW_GRAPH
Command5=ID_APP_EXIT
Command6=ID_EDIT_UNDO
Command7=ID_EDIT_CUT
Command8=ID_EDIT_COPY
Command9=ID_EDIT_PASTE
Command10=ID_VIEW_TOOLBAR
Command11=ID_VIEW_STATUS_BAR
Command12=ID_WINDOW_CASCADE
Command13=ID_WINDOW_TILE_HORZ
Command14=ID_WINDOW_ARRANGE
Command15=ID_APP_ABOUT
CommandCount=15

[MNU:IDR_KOCH_TYPE (�p�� (��ض))]
Type=1
Class=?
Command1=ID_FILE_NEW_BIN_TREE
Command2=ID_FILE_NEW_TREE
Command3=ID_FILE_NEW_KOCH
Command4=ID_FILE_NEW_GRAPH
Command5=ID_APP_EXIT
Command6=ID_EDIT_UNDO
Command7=ID_EDIT_CUT
Command8=ID_EDIT_COPY
Command9=ID_EDIT_PASTE
Command10=ID_VIEW_TOOLBAR
Command11=ID_VIEW_STATUS_BAR
Command12=ID_WINDOW_CASCADE
Command13=ID_WINDOW_TILE_HORZ
Command14=ID_WINDOW_ARRANGE
Command15=ID_APP_ABOUT
CommandCount=15

[MNU:IDR_GRAPH_TYPE (�p�� (��ض))]
Type=1
Class=?
Command1=ID_FILE_NEW_BIN_TREE
Command2=ID_FILE_NEW_TREE
Command3=ID_FILE_NEW_KOCH
Command4=ID_FILE_NEW_GRAPH
Command5=ID_APP_EXIT
Command6=ID_EDIT_UNDO
Command7=ID_EDIT_CUT
Command8=ID_EDIT_COPY
Command9=ID_EDIT_PASTE
Command10=ID_VIEW_TOOLBAR
Command11=ID_VIEW_STATUS_BAR
Command12=ID_WINDOW_CASCADE
Command13=ID_WINDOW_TILE_HORZ
Command14=ID_WINDOW_ARRANGE
Command15=ID_APP_ABOUT
CommandCount=15

[DLG:IDD_ABOUTBOX (�p�� (��ض))]
Type=1
Class=?
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889

[TB:IDR_MAINFRAME (�p�� (��ض))]
Type=1
Class=?
Command1=ID_FILE_NEW
Command2=ID_FILE_OPEN
Command3=ID_FILE_SAVE
Command4=ID_EDIT_CUT
Command5=ID_EDIT_COPY
Command6=ID_EDIT_PASTE
Command7=ID_FILE_PRINT
Command8=ID_APP_ABOUT
CommandCount=8

[ACL:IDR_MAINFRAME (�p�� (��ض))]
Type=1
Class=?
Command1=ID_FILE_NEW
Command2=ID_FILE_OPEN
Command3=ID_FILE_SAVE
Command4=ID_FILE_PRINT
Command5=ID_EDIT_UNDO
Command6=ID_EDIT_CUT
Command7=ID_EDIT_COPY
Command8=ID_EDIT_PASTE
Command9=ID_EDIT_UNDO
Command10=ID_EDIT_CUT
Command11=ID_EDIT_COPY
Command12=ID_EDIT_PASTE
Command13=ID_NEXT_PANE
Command14=ID_PREV_PANE
CommandCount=14

[DLG:IDD_GRAPH]
Type=1
Class=CGraphDialog
ControlCount=4
Control1=IDC_STATIC,static,1342308352
Control2=IDC_GRAPH_N_OUTSIDE_NODES,edit,1350631552
Control3=IDOK,button,1342242817
Control4=IDCANCEL,button,1342242816

[DLG:IDD_KOCH]
Type=1
Class=CKochDialog
ControlCount=4
Control1=IDC_STATIC,static,1342308352
Control2=IDC_KOCH_LEVEL,edit,1350631552
Control3=IDOK,button,1342242817
Control4=IDCANCEL,button,1342242816

