//
// HiRiseDemo: a Demo Application of the HiRise Constraint Solver
//
// Copyright (C) 1998 Hiroshi HOSOBE
//
////////////////////////////////////////////////////////////////

// BinTreeDialog.cpp : �C���v�������e�[�V���� �t�@�C��
//

#include "stdafx.h"
#include "HiRiseDemo.h"
#include "BinTreeDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CBinTreeDialog �_�C�A���O


CBinTreeDialog::CBinTreeDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CBinTreeDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CBinTreeDialog)
	m_binTreeHeight = 0;
	m_lineWidth = 0;
	m_nodeSize = 0;
	//}}AFX_DATA_INIT

	m_binTreeHeight = 4;
	m_lineWidth = 2;
	m_nodeSize = 20;
}


void CBinTreeDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CBinTreeDialog)
	DDX_Text(pDX, IDC_BIN_TREE_HEIGHT, m_binTreeHeight);
	DDV_MinMaxInt(pDX, m_binTreeHeight, 1, 32);
	//}}AFX_DATA_MAP
#if 0
	DDX_Text(pDX, IDC_BIN_TREE_LINE_WIDTH, m_lineWidth);
	DDV_MinMaxInt(pDX, m_lineWidth, 1, 9);
	DDX_Text(pDX, IDC_BIN_TREE_NODE_SIZE, m_nodeSize);
	DDV_MinMaxInt(pDX, m_nodeSize, 4, 100);
#endif
}


BEGIN_MESSAGE_MAP(CBinTreeDialog, CDialog)
	//{{AFX_MSG_MAP(CBinTreeDialog)
		// ���� - ClassWizard �͂��̈ʒu�Ƀ}�b�s���O�p�̃}�N����ǉ��܂��͍폜���܂��B
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBinTreeDialog ���b�Z�[�W �n���h��
