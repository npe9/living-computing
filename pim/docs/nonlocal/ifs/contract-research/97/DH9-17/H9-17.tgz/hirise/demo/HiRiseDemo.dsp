# Microsoft Developer Studio Project File - Name="HiRiseDemo" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 5.00
# ** �ҏW���Ȃ��ł������� **

# TARGTYPE "Win32 (x86) Application" 0x0101

CFG=HiRiseDemo - Win32 Debug
!MESSAGE ����͗L����Ҳ�̧�قł͂���܂���B ������ۼު�Ă�����ނ��邽�߂ɂ� NMAKE ���g�p���Ă��������B
!MESSAGE [Ҳ�̧�ق̴���߰�] ����ނ��g�p���Ď��s���Ă�������
!MESSAGE 
!MESSAGE NMAKE /f "HiRiseDemo.mak".
!MESSAGE 
!MESSAGE NMAKE �̎��s���ɍ\�����w��ł��܂�
!MESSAGE ����� ײݏ��ϸۂ̐ݒ���`���܂��B��:
!MESSAGE 
!MESSAGE NMAKE /f "HiRiseDemo.mak" CFG="HiRiseDemo - Win32 Debug"
!MESSAGE 
!MESSAGE �I���\������� Ӱ��:
!MESSAGE 
!MESSAGE "HiRiseDemo - Win32 Release" ("Win32 (x86) Application" �p)
!MESSAGE "HiRiseDemo - Win32 Debug" ("Win32 (x86) Application" �p)
!MESSAGE 

# Begin Project
# PROP Scc_ProjName ""
# PROP Scc_LocalPath ""
CPP=cl.exe
MTL=midl.exe
RSC=rc.exe

!IF  "$(CFG)" == "HiRiseDemo - Win32 Release"

# PROP BASE Use_MFC 6
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "Release"
# PROP BASE Intermediate_Dir "Release"
# PROP BASE Target_Dir ""
# PROP Use_MFC 6
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "Release"
# PROP Intermediate_Dir "Release"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_AFXDLL" /Yu"stdafx.h" /FD /c
# ADD CPP /nologo /MD /W3 /GX /O2 /I ".." /D "NDEBUG" /D "WIN32" /D "_WINDOWS" /D "_AFXDLL" /D "WEAKER" /Yu"stdafx.h" /FD /c
# ADD BASE MTL /nologo /D "NDEBUG" /mktyplib203 /o NUL /win32
# ADD MTL /nologo /D "NDEBUG" /mktyplib203 /o NUL /win32
# ADD BASE RSC /l 0x411 /d "NDEBUG" /d "_AFXDLL"
# ADD RSC /l 0x411 /d "NDEBUG" /d "_AFXDLL"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 /nologo /subsystem:windows /machine:I386
# ADD LINK32 /nologo /subsystem:windows /machine:I386

!ELSEIF  "$(CFG)" == "HiRiseDemo - Win32 Debug"

# PROP BASE Use_MFC 6
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "Debug"
# PROP BASE Intermediate_Dir "Debug"
# PROP BASE Target_Dir ""
# PROP Use_MFC 6
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "Debug"
# PROP Intermediate_Dir "Debug"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MDd /W3 /Gm /GX /Zi /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_AFXDLL" /Yu"stdafx.h" /FD /c
# ADD CPP /nologo /MDd /W3 /Gm /GX /Zi /Od /I ".." /D "_DEBUG" /D "WIN32" /D "_WINDOWS" /D "_AFXDLL" /D "WEAKER" /Yu"stdafx.h" /FD /c
# ADD BASE MTL /nologo /D "_DEBUG" /mktyplib203 /o NUL /win32
# ADD MTL /nologo /D "_DEBUG" /mktyplib203 /o NUL /win32
# ADD BASE RSC /l 0x411 /d "_DEBUG" /d "_AFXDLL"
# ADD RSC /l 0x411 /d "_DEBUG" /d "_AFXDLL"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 /nologo /subsystem:windows /debug /machine:I386 /pdbtype:sept
# ADD LINK32 /nologo /subsystem:windows /debug /machine:I386 /pdbtype:sept

!ENDIF 

# Begin Target

# Name "HiRiseDemo - Win32 Release"
# Name "HiRiseDemo - Win32 Debug"
# Begin Group "Source Files"

# PROP Default_Filter "cpp;c;cxx;rc;def;r;odl;idl;hpj;bat"
# Begin Source File

SOURCE=.\BinTreeDialog.cpp
# End Source File
# Begin Source File

SOURCE=.\BinTreeDoc.cpp
# End Source File
# Begin Source File

SOURCE=.\BinTreeNode.cpp
# End Source File
# Begin Source File

SOURCE=.\BinTreeView.cpp
# End Source File
# Begin Source File

SOURCE=.\GraphDialog.cpp
# End Source File
# Begin Source File

SOURCE=.\GraphDoc.cpp
# End Source File
# Begin Source File

SOURCE=.\GraphNode.cpp
# End Source File
# Begin Source File

SOURCE=.\GraphView.cpp
# End Source File
# Begin Source File

SOURCE=.\HiRiseDemo.cpp
# End Source File
# Begin Source File

SOURCE=.\HiRiseDemo.rc
# End Source File
# Begin Source File

SOURCE=..\HRBase.cpp

!IF  "$(CFG)" == "HiRiseDemo - Win32 Release"

# SUBTRACT CPP /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "HiRiseDemo - Win32 Debug"

# SUBTRACT CPP /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\HRCon.cpp

!IF  "$(CFG)" == "HiRiseDemo - Win32 Release"

# SUBTRACT CPP /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "HiRiseDemo - Win32 Debug"

# SUBTRACT CPP /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\HREdit.cpp

!IF  "$(CFG)" == "HiRiseDemo - Win32 Release"

# SUBTRACT CPP /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "HiRiseDemo - Win32 Debug"

# SUBTRACT CPP /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\HRLinear.cpp

!IF  "$(CFG)" == "HiRiseDemo - Win32 Release"

# SUBTRACT CPP /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "HiRiseDemo - Win32 Debug"

# SUBTRACT CPP /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\HRList.cpp

!IF  "$(CFG)" == "HiRiseDemo - Win32 Release"

# SUBTRACT CPP /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "HiRiseDemo - Win32 Debug"

# SUBTRACT CPP /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\HRParser.cpp

!IF  "$(CFG)" == "HiRiseDemo - Win32 Release"

# SUBTRACT CPP /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "HiRiseDemo - Win32 Debug"

# SUBTRACT CPP /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\HRSolver.cpp

!IF  "$(CFG)" == "HiRiseDemo - Win32 Release"

# SUBTRACT CPP /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "HiRiseDemo - Win32 Debug"

# SUBTRACT CPP /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\HRStay.cpp

!IF  "$(CFG)" == "HiRiseDemo - Win32 Release"

# SUBTRACT CPP /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "HiRiseDemo - Win32 Debug"

# SUBTRACT CPP /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\HRVar.cpp

!IF  "$(CFG)" == "HiRiseDemo - Win32 Release"

# SUBTRACT CPP /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "HiRiseDemo - Win32 Debug"

# SUBTRACT CPP /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\KochDialog.cpp
# End Source File
# Begin Source File

SOURCE=.\KochDoc.cpp
# End Source File
# Begin Source File

SOURCE=.\KochElem.cpp
# End Source File
# Begin Source File

SOURCE=.\KochView.cpp
# End Source File
# Begin Source File

SOURCE=.\MainFrm.cpp
# End Source File
# Begin Source File

SOURCE=.\mystdio.cpp
# End Source File
# Begin Source File

SOURCE=.\StdAfx.cpp
# ADD CPP /Yc"stdafx.h"
# End Source File
# Begin Source File

SOURCE=.\TreeDialog.cpp
# End Source File
# Begin Source File

SOURCE=.\TreeDoc.cpp
# End Source File
# Begin Source File

SOURCE=.\TreeNode.cpp
# End Source File
# Begin Source File

SOURCE=.\TreeView.cpp
# End Source File
# End Group
# Begin Group "Header Files"

# PROP Default_Filter "h;hpp;hxx;hm;inl"
# Begin Source File

SOURCE=.\BinTreeDialog.h
# End Source File
# Begin Source File

SOURCE=.\BinTreeDoc.h
# End Source File
# Begin Source File

SOURCE=.\BinTreeNode.h
# End Source File
# Begin Source File

SOURCE=.\BinTreeView.h
# End Source File
# Begin Source File

SOURCE=.\GraphDialog.h
# End Source File
# Begin Source File

SOURCE=.\GraphDoc.h
# End Source File
# Begin Source File

SOURCE=.\GraphNode.h
# End Source File
# Begin Source File

SOURCE=.\GraphView.h
# End Source File
# Begin Source File

SOURCE=.\HiRiseDemo.h
# End Source File
# Begin Source File

SOURCE=..\HRBase.h
# End Source File
# Begin Source File

SOURCE=..\HRCon.h
# End Source File
# Begin Source File

SOURCE=..\HREdit.h
# End Source File
# Begin Source File

SOURCE=..\HRLinear.h
# End Source File
# Begin Source File

SOURCE=..\HRList.h
# End Source File
# Begin Source File

SOURCE=..\HRParser.h
# End Source File
# Begin Source File

SOURCE=..\HRSolver.h
# End Source File
# Begin Source File

SOURCE=..\HRStay.h
# End Source File
# Begin Source File

SOURCE=..\HRVar.h
# End Source File
# Begin Source File

SOURCE=.\KochDialog.h
# End Source File
# Begin Source File

SOURCE=.\KochDoc.h
# End Source File
# Begin Source File

SOURCE=.\KochElem.h
# End Source File
# Begin Source File

SOURCE=.\KochView.h
# End Source File
# Begin Source File

SOURCE=.\MainFrm.h
# End Source File
# Begin Source File

SOURCE=.\mystdio.h
# End Source File
# Begin Source File

SOURCE=.\Resource.h
# End Source File
# Begin Source File

SOURCE=.\StdAfx.h
# End Source File
# Begin Source File

SOURCE=.\TreeDialog.h
# End Source File
# Begin Source File

SOURCE=.\TreeDoc.h
# End Source File
# Begin Source File

SOURCE=.\TreeNode.h
# End Source File
# Begin Source File

SOURCE=.\TreeView.h
# End Source File
# End Group
# Begin Group "Resource Files"

# PROP Default_Filter "ico;cur;bmp;dlg;rc2;rct;bin;cnt;rtf;gif;jpg;jpeg;jpe"
# Begin Source File

SOURCE=.\res\HiRiseDemo.ico
# End Source File
# Begin Source File

SOURCE=.\res\HiRiseDemo.rc2
# End Source File
# Begin Source File

SOURCE=.\res\HiRiseDemoDoc.ico
# End Source File
# Begin Source File

SOURCE=.\res\Toolbar.bmp
# End Source File
# End Group
# Begin Source File

SOURCE=.\ReadMe.txt
# End Source File
# End Target
# End Project
