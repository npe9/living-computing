//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by HiRiseDemo.rc
//
#define IDR_BIN_TREE                    4
#define IDR_TREE                        5
#define IDR_GRAPH                       6
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_HIRISETYPE                  129
#define IDR_BIN_TREE_TYPE               130
#define IDR_TREE_TYPE                   131
#define IDR_KOCH_TYPE                   132
#define IDR_GRAPH_TYPE                  133
#define IDD_BIN_TREE                    134
#define IDD_TREE                        135
#define IDD_KOCH                        136
#define IDD_GRAPH                       138
#define IDC_BIN_TREE_HEIGHT             1000
#define IDC_BIN_TREE_LINE_WIDTH         1001
#define IDC_BIN_TREE_NODE_SIZE          1002
#define IDC_TREE_HEIGHT                 1003
#define IDC_TREE_LINE_WIDTH             1004
#define IDC_TREE_NODE_SIZE              1005
#define IDC_TREE_N_CHILDREN             1006
#define IDC_KOCH_LEVEL                  1007
#define IDC_TREE_SEED                   1007
#define IDC_GRAPH_N_OUTSIDE_NODES       1008
#define ID_BIN_TREE_STAY                32772
#define ID_BIN_TREE_ADD                 32774
#define ID_BIN_TREE_REMOVE              32776
#define ID_BIN_TREE_LINE                32778
#define ID_FILE_NEW_BIN_TREE            32779
#define ID_FILE_NEW_TREE                32786
#define ID_FILE_NEW_KOCH                32787
#define ID_FILE_NEW_GRAPH               32788
#define ID_TREE_ADD                     32791
#define ID_TREE_REMOVE                  32792
#define ID_TREE_STAY                    32793
#define ID_TREE_LINE                    32794
#define ID_GRAPH_NODE                   32795
#define ID_GRAPH_EDGE                   32796
#define ID_GRAPH_STAY                   32797
#define ID_GRAPH_DIRECT                 32798

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32799
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
