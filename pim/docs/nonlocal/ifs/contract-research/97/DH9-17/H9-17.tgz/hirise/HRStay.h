//
// The HiRise Constraint Solver
//
// Copyright (C) 1998 Hiroshi HOSOBE
//
////////////////////////////////////////////////////////////////

#ifndef _HR_STAY_H
#define _HR_STAY_H

#include "HRCon.h"

class HRStay: public HRCon {

    void init();
	void destroy();

private:

public:
    virtual const HRString getClass() const { return "HRStay"; }

    virtual const HRConType getType() const { return HR_STAY; }

    HRStay(int str);
	HRStay(int str, HRVar& var);
#ifdef DEBUG
    HRStay(const HRString name, int str);
    HRStay(const HRString name, int str, HRVar& var);
#endif // DEBUG
    virtual ~HRStay();
	virtual void clear();
    
    virtual HRCon& add(HRVar& var);

};

#endif // _HR_STAY_H
