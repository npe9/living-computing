The HiRise Constraint Solver
Hiroshi HOSOBE

Copyright (C) 1998 Hiroshi HOSOBE

HiRise is a constraint solver that performs incremental satisfaction
of constraint systems.  It provides stay, edit, and linear
constraints, and also allows programmers to specify constraints with
hierarchical preferences (i.e. constraint hierarchies) like the
DeltaBlue constraint solver developed by Borning et al.

The characteristics of HiRise are scalability and reliability: it
efficiently solves up to thousands of simultaneously satisfied
constraints; theoretically, it correctly solves any constraint
hierarchies described as combination of stay, edit, and linear
constraints.

The HiRise constraint solver is written in ANSI C++.  However,
compiling HiRise may need a little effort since it adopts templates.
So far, we have successfully compiled it with GNU C++ 2.6.3 and
Microsoft Visual C++ 5.0.

File `sample.cpp' is a sample program that presents how to program an
application with HiRise.  Using `makefile,' you will be able to
compile it with GNU C++ 2.6.3 or later.

Directory `demo' contains the source code of a demo application called
HiRiseDemo that runs on Microsoft Windows 95 or NT 4.0.  To build it,
you need Microsoft Visual C++ 5.0 (the Japanese version may be
preferable).  Also, the binary code of HiRiseDemo is available as
HiRiseDemo.exe.  It provides four kinds of examples, which you can use
as follows:

The first example is to edit a binary tree.  You can drag any node of
the tree by pressing the left mouse button.  Also, with a pop-up menu
that appears by pushing the right button, you can add a new child to a
node, remove an existing node (together with its descendant nodes),
stay a node, and constrain a node to be on an arbitrary straight line.

The next example is to edit a general tree.  You can edit the tree in
the same way as the first example.  The difference is that it
automatically generates a random tree when started, and that you can
add an arbitrary number of children to any node.

The third example is to manipulate Koch's curve.  When invoked, it
displays a polyline that is an approximation of Koch's curve at a
given level.  You can resize it by dragging a vertex, move it by
dragging its top vertex, and add a detail locally by clicking a
segment with the right mouse button.

The final example is to edit a graph.  When started, it prompts the
user to input the number of nodes that are located circularly.  You
can drag a node, create a node, connect two nodes, stay a node, and
constrain a node to follow a straight line.  The position of each node
that you created is determined so that it will be the center of
gravity of the adjacent nodes.

To obtain further information or the latest version, please contact:

	detail@is.s.u-tokyo.ac.jp
