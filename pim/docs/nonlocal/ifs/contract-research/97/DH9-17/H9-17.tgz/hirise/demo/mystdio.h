//
// HiRiseDemo: a Demo Application of the HiRise Constraint Solver
//
// Copyright (C) 1998 Hiroshi HOSOBE
//
////////////////////////////////////////////////////////////////

#ifndef _MYSTDIO_H
#define _MYSTDIO_H

#ifdef _DEBUG

#ifdef _MYSTDIO_C
int dprintf(const char *format, ...);
int dfprintf(FILE *stream, const char *format, ...);
#else // !MYSTDIO_C
extern int dprintf(const char *format, ...);
extern int dfprintf(FILE *stream, const char *format, ...);
#endif _MYSTDIO_C

#define printf dprintf
#define fprintf dfprintf

#endif // _DEBUG

#endif // !_MYSTDIO_H
