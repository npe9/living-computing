//Copyright (C) 1998 Takeo Igarashi

#include <jni.h>

    extern "C" /* specify the C calling convention */ 
    jint Java_Dll_inc (
         JNIEnv *env,        /* interface pointer */
         jobject obj,        /* "this" pointer */
         jint i,             /* argument #1 */
         )         
    {
         return i +1;
    }