//Copyright (C) 1998 Takeo Igarashi
// �������̎�舵��

const max_candidates = 100;

class Candidates : public int_List{
  public:
    int_List Explanation[max_candidates];
	void clear(){
	  for ( int i = 0 ; i < 64; i++)
	    Explanation[i].clear();
  	  if ((size > 0) && alive) delete content;
	  alive = false;
	  size = 0;};
	void swap(int a, int b){
	  if ((a>size)||(b>size)) return;
	  int tmp = *(content+a);
	  *(content+a) = *(content+b);
	  *(content+b) = tmp;
	  int_List tmp2 = Explanation[a];
	  Explanation[a] = Explanation[b];
	  Explanation[b] = tmp2;
	}
} candidates;	  // candidate segments (SegmentArray num)


class ConstraintStrength {
    float content[MAXconstraint];
  public:
    void save(){
	  for ( int i = 0 ; i < constraintArray.size() ; i++)
	    content[i] = constraintArray.get(i)->Strength;
	  };
    void load(){
	  for ( int i = 0 ; i < constraintArray.size() ; i++)
	    constraintArray.get(i)->Strength = content[i];
	  }
}  ConstraintStrength;

void RefreshConstraint();
void ReOrderConstraint(int j);  // Refrash ������ɌĂ΂��B
  //  �����������ɂ����Ă���B		  j...  0-14
void ReOrderConstraint2(int j);
  // ����̏��������ւ���B	 ������@j �@�����グ��
void RemoveDuplicate(int segment_num, int_List* candidates);
  // ���S�ɓ����Ȃ��菜��
void setExplanations(Candidates* candidates);
  // ��₪�ǉ������x�ɌĂ΂��B
extern "C" void _export WINAPI candidates_clear ();
extern "C" void _export WINAPI candidates_explain ( int n);








extern "C" void _export WINAPI candidates_clear (){
  for (int i = 0 ; i < candidates.size ; i++){
    SegmentArray.remove(candidates.get(i)); 
  }
  candidates.clear();
}


extern "C" void _export WINAPI candidates_explain ( int n){
  int_List *explanation;

  console.clear();
  explanation = candidates.Explanation + n;
  for (int i = 0 ; i < explanation->size; i++)
    console.add(explanation->get(i));
}

// �����񓙕����Ƃ̌�_
extern "C" void _export WINAPI pallalel_explain (int m,int n, float *x, float *y, float *x1, float *y1){
 
  float mx, my,mx1,my1;
  Segment_Data new_segment;		   
  new_segment = *(SegmentArray.get(candidates.get(m)));
  mx = NodeArray.get(new_segment.start)->X;
  my = NodeArray.get(new_segment.start)->Y;
  mx1 = NodeArray.get(new_segment.end)->X;
  my1 = NodeArray.get(new_segment.end)->Y;

  Node_Data StartNode, EndNode;
  StartNode.X = (mx + mx1) / 2;
  StartNode.Y = (my + my1) / 2;
  EndNode.X = StartNode.X + (my1 - my );
  EndNode.Y = StartNode.Y - (mx1 - mx );
  Segment_Data segment;		   
  segment.start = NodeArray.add(StartNode);
  segment.end =   NodeArray.add(EndNode);

  Segment_Data old_segment;		   
  if ((n < 0) || (n >= SegmentArray.size())) return;
  old_segment = *(SegmentArray.get(n));
 
  Node_Data cross_node;
  get_cross_node( &segment, &old_segment, &cross_node);

  NodeArray.remove(segment.start);
  NodeArray.remove(segment.end);

  *x = StartNode.X;
  *y = StartNode.Y;
  *x1 = cross_node.X;
  *y1 = cross_node.Y;
				 
  return;
}


void pool::generate_candidates(){
  Node_Data StartNode, EndNode;
  Segment_Data *segment;
  int segment_num;

  float max_confidence = 0;
  float confidence;
  int primal_candidate = 0;			

  int_List *Explanation ;
  int j,k;
  constraint_Data *constraint;



//  candidates.clear();
  for (int i = 0; ((i < max_element) && (candidates.size < max_candidates)); i++)
	if ((element[i].variables[0] != -1) &&
		(element[i].variables[1] != -1) &&
		(element[i].variables[2] != -1) &&
		(element[i].variables[3] != -1) &&
		// �ߌ��ȕω��h�~�B�{����solver ���ŉ����̂͂��c
	    ((confidence = element[i].confidence()) > 8800) ){


      segment_num = SegmentArray.create();
      segment = SegmentArray.get(segment_num);
      segment->start = NodeArray.add(StartNode);
      segment->end =   NodeArray.add(EndNode);
      segment->type =  Straight;
      NodeArray.add_owner(segment->start, segment_num);
      NodeArray.add_owner(segment->end,   segment_num);


      NodeArray.get(segment->start)->X = element[i].variables[0];
      NodeArray.get(segment->start)->Y = element[i].variables[1];
      NodeArray.get(segment->end)->X   = element[i].variables[2];
      NodeArray.get(segment->end)->Y   = element[i].variables[3];

      candidates.add(segment_num); // ���


      //  ����  explain
    Explanation = candidates.Explanation + 
                  candidates.size - 1;
    Explanation->clear();

	for ( j = 0; j <  element[i].history.size; j++){
	  constraint = constraintArray
	  				.get(element[i].history.get(j));
	  if (constraint->Explain.Ref != -1){
  	    Explanation->add(constraint->Explain.Type);
	    Explanation->add(constraint->Explain.Ref);
	  }
	  else
	    for (k=0; k<constraint->Explain.Reference->size; k++){
          if (k > 2) break;
	      Explanation->add(constraint->Explain.Type);
	      Explanation->add(constraint->Explain.Reference->get(k));
	    }
	}



	  //  �m�M�x�v�Z	  �����͂��ׂĂƂ��Ƃ��c
	  if (max_confidence < confidence){
		max_confidence = confidence;
		primal_candidate = candidates.size - 1;}
  }
  // �����΂�� 0 �ɂ���
  candidates.swap(primal_candidate, 0);	
  return; //primal_candidate;
}

//  ��ԋ߂��Z�O�����g��Ԃ�
extern "C" int _export WINAPI get_candidate (float x, float y){
  int num = -1;
  float min = 500, tmp;
  Node_Data node;
  node.X = x;
  node.Y = y;

  for (int i = 0;  i <= candidates.size - 1; i++)
  	 if (min > (tmp = node_line_distance(&node, SegmentArray.get(candidates.get(i))))) {
	   min = tmp;
	   num = i;
	 }
   return num;

}
