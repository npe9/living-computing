//Copyright (C) 1998 Takeo Igarashi
//
//    Turning Points -> Segment     -> Object
//

const float   threshold_ratio = 0.05; //Beautify_Setting.threshold_ratio
const float   max_tangent = 0.15; //Beautify_Setting.max_tangent
const float   smoothing = -0.98; //- 0.8; //Beautify_Setting.smoothing
								// ������ cos ������������ �}�[�W�i�P�{�ɂ܂Ƃ߂�j

Front_Object_Data object;
Hidden_Object_Data       previous_object;


#include"Relation.cpp"
#include"OvStrike.cpp"
#include"Adjust.cpp"     // Web �ɂ��������Ĉʒu���킹�B
#include"ReArrang.cpp"
#include"Candidat.cpp"


void AddOneLineToObject (Front_Object_Data*, Node_Data , Node_Data , int );
//void GenerateCandidates (Front_Object_Data *object);
void GenerateCandidates (Front_Object_Data *object, 
						float x0, float y0, float x1, float y1);
void AddLinesToObject (Front_Object_Data*);
  // TurnigPoints ���畡����␶��
void MergeNode (int, int);

extern "C" void _export WINAPI new_object_get (int , float*,  float*,  float* , float* );
extern "C" int _export WINAPI add_segments_to_object ();
extern "C" void _export WINAPI segment_selected (int selected);
void segment_selected_main(int selected, Front_Object_Data *object);
extern "C" int _export WINAPI object_size ();
extern "C" void _export WINAPI clear_object2 ();
extern "C" void _export WINAPI candidates_get (int n, float *x, float *y, float *x1, float *y1);


void MergeNode (int node1_num, int  node2_num){

    // Owner  ���@copy ����B  node1 ���c��B���W��node1�ɂȂ�B
    // Owner �̕��́@node reference ������������B

   Node_Data *node1, *node2;
   int i, Owner;

  if ( node1_num == node2_num ) {
    return;
  }

   node1 = NodeArray.get(node1_num);
   node2 = NodeArray.get(node2_num);
   
   for (i = 0; i<= node2->owner.size - 1	; i++){
     Owner = node2->owner.get(i);
     node1->owner.add(Owner);

     // Owner
     if ( SegmentArray.get(Owner)->start == node2_num ) {
        SegmentArray.get(Owner)->start = node1_num;
	 }
     else if ( SegmentArray.get(Owner)->end == node2_num ) {
        SegmentArray.get(Owner)->end = node1_num;
     }		// else error!!!

   } 
   
   NodeArray.remove(node2_num);
    
}


void AddOneLineToObject (Front_Object_Data *object, Node_Data StartNode, Node_Data EndNode, int Fixed, float speed){
  //���̓X�g���[�N���琧�����肾���A���𐶐�����B
  int            segment_num = SegmentArray.create();
  Segment_Data*  segment = SegmentArray.get(segment_num);

  segment->start = NodeArray.add(StartNode);
  segment->end =   NodeArray.add(EndNode);
  segment->type =  Straight;

  NodeArray.add_owner(segment->start, segment_num);
  NodeArray.add_owner(segment->end,   segment_num);


//  segment->start_vec.set_norm (StartNode, EndNode);
//  segment->end_vec.set_norm (EndNode, StartNode);


  RemoveOverstrike(segment, object , speed);

  // �m�M�x�v�Z�p
  OriginalLocation[0] = NodeArray.get(segment->start)->X;
  OriginalLocation[1] = NodeArray.get(segment->start)->Y;
  OriginalLocation[2] = NodeArray.get(segment->end)->X;
  OriginalLocation[3] = NodeArray.get(segment->end)->Y;
  OriginalLength = segment->length();

  candidates.clear();


    // ���~���ɂȂ��� segment ����菜���B
//  InitConstraint(segment, speed);
  constraintArray.clear();

  SegmentAdjust(segment, object, speed);
    //  Web �ɂ��������Ĉʒu�����킹��B(constraint - set)

  //console.clear();
  pool.Solve();
  //pool.print();
  pool.generate_candidates();

  if (candidates.size == 0) 
    candidates.add(segment_num); // ���͂��̂܂ܑ����
}


void GenerateCandidates (Front_Object_Data *object, 
						float x0, float y0, float x1, float y1){
  Node_Data StartNode, 
            EndNode;
      StartNode.X = x0;
      StartNode.Y = y0;
      
      EndNode.X = x1;
      EndNode.Y = y1;

float      speed = 200;

  if (Abs(x0 -x1)+Abs(y0-y1) > 50){
      AddOneLineToObject(object, StartNode, EndNode, false, speed);
  }
}








//  add_segments_to_object �̌�� rearrange & object->add �̂ݍs��
// candidates �̏����B
void segment_selected_main(int selected, Front_Object_Data *object){
  // �܂� ���݂�j��
  if ((selected <0) || (selected >= candidates.size )) return;

  if (selected < candidates.size){
    int segment_num = candidates.get(selected);
    SegmentRearrange0(segment_num, object);   // �꒼����Ȃ瓝��
    SegmentRearrange1(segment_num, object);   // ��_��ړ_�ŕ���	
//    object->add(segment_num); //�����B
  
    candidates.remove_by_index(selected);   // Array ����̂����Ȃ��悤�ɂ���
  }
  candidates_clear();
}
