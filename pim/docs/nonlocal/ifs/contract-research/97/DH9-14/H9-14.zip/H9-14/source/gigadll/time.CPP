//Copyright (C) 1998 Takeo Igarashi
#include <sys\timeb.h>

int get_time(){
  static struct _timeb prev;
  struct _timeb tstruct;
  int result;
  _ftime( &tstruct );

  result = (tstruct.time - prev.time) * 1000
          + tstruct.millitm - prev.millitm;
  prev = tstruct;
          
  return( result );
};

