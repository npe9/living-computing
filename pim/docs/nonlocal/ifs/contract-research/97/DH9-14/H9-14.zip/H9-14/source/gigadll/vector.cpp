//Copyright (C) 1998 Takeo Igarashi
//
//   ��{�I�Ȓ�`�W
//

// length distrane angle .....	 
					   
class Point_Data {
  public:
  float X;
  float Y;
  float length();
};
float Point_Data::length(){
  return sqrt(X * X + Y * Y);
}

class Node_Data;

class Vector_Data : public Point_Data{
  public:
//    Vector_Data(Node_Data *, Node_Data *);
    void set(Point_Data p1, Point_Data p2);
    void set_norm(Node_Data n1, Node_Data n2);	
    void set(Node_Data *n1, Node_Data *n2);	
    float length(); 
};
void   Vector_Data::set(Point_Data p1, Point_Data p2){
  X = p2.X - p1.X;
  Y = p2.Y - p1.Y;
};

float Vector_Data::length(){
  return sqrt(X * X + Y * Y);
};

float get_cos (Vector_Data *v1, Vector_Data *v2){
  float inner_Product, length;

  inner_Product = v1->X * v2->X + v1->Y * v2->Y;
  length = sqrt((v1->X * v1->X + v1->Y * v1->Y) * (v2->X * v2->X + v2->Y * v2->Y));

  if (length > 0)
     {return(inner_Product / length);}
  else
     {return(1);};
}

float get_cos (Vector_Data v1, Vector_Data v2){
  float inner_Product, length;

  inner_Product = v1.X * v2.X + v1.Y * v2.Y;
  length = sqrt((v1.X * v1.X + v1.Y * v1.Y) * (v2.X * v2.X + v2.Y * v2.Y));

  if (length > 0)
     {return(inner_Product / length);}
  else
     {return(1);};
}








extern "C" float _export WINAPI get_length (Point_Data *v){
  return v->length();}


extern "C" float _export WINAPI get_cos (Point_Data *v1, Point_Data *v2){
  float inner_Product, length;

  inner_Product = v1->X * v2->X + v1->Y * v2->Y;
  length = sqrt((v1->X * v1->X + v1->Y * v1->Y) * (v2->X * v2->X + v2->Y * v2->Y));

  if (length > 0)
     {return(inner_Product / length);}
  else
     {return(1);};
}


  
extern "C" float _export WINAPI get_sin (Point_Data *v1, Point_Data *v2){
  float outer_Product, length;

  outer_Product = v1->X * v2->Y - v1->Y * v2->X;
  length = sqrt((v1->X * v1->X + v1->Y * v1->Y) * (v2->X * v2->X + v2->Y * v2->Y));

  if (length > 0){
       return(outer_Product / length);}
  else{
       return(0);};
}

extern "C" float _export WINAPI get_distance (Point_Data *p1, Point_Data *p2){
  float x, y;
  x = p1->X - p2->X;
  y = p1->Y - p2->Y;
  return(sqrt(x * x + y * y));
}
float get_distance (Point_Data p1, Point_Data p2){
  float x, y;
  x = p1.X - p2.X;
  y = p1.Y - p2.Y;
  return(sqrt(x * x + y * y));
}

float get_angle(float X, float Y){   // 0-90
  if ( X == 0 ) return 90;
  if ( Y == 0 ) return 0;
//  return atan( Abs(Y) / Abs(X) ) * 180 / pi;
  float tmp = atan( Abs(Y) / Abs(X) ) * 180 / pi;
  if (X*Y < 0) 
    return 180-tmp;
  else 
    return tmp;

}
float get_round_angle(float X, float Y){   // 0-360
  if (( X == 0 ) && ( Y > 0)) return 90;
  if (( X == 0 ) && ( Y < 0)) return 270;
  if (( Y == 0 ) && ( X >= 0)) return 0;
  if (( Y == 0 ) && ( X < 0)) return 180;

  // atan -> 0 ... pi
  float tmp = atan( Abs(Y) / Abs(X) ) * 180 / pi;
  if (Y < 0) 
    return 180+tmp;
  else 
    return tmp;

}
float get_relative_angle(float X, float Y, float X0, float Y0){   // 0-360
  float angle = get_round_angle(X,Y);
  float angle0 = get_round_angle(X0,Y0);

  float result = angle - angle0;
  
  while(result >=360) result -=360;
  while(result <0) result+=0;
      
  return result;

}




