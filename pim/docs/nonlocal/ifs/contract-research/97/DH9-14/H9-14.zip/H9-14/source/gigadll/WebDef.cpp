//Copyright (C) 1998 Takeo Igarashi
//
//    ���łɕ`����Ă���}�`�̐D�萬������Q�̊Ǘ�
//
//	   new delete ����
//
/*
#include <windows.h>
#include"List.cpp"
#include"console.cpp"
*/
void WebArray_add(int segment_num);


float get_angle(float X, float Y);   // 0-90

void WebArray_clear();
void WebArray_add(int segment_num);
void WebArray_remove(int segment_num);


class Web_Data {
  public:
    float Val;
	float Strength;
	int_List Owner;
	void clear() {Owner.clear();};
}; 
 
class WebArray {
    int alive;
  public:
    Web_Data* content;
//    Web_Data content[100];
	int         size;
	WebArray(void)  {size = 0; alive = false;};
	~WebArray(void) {if ((size > 0) && alive) 
	                    delete content;};

    void add(float Val, int segment_num);
    int remove(float Val, int segment_num);

	void clear() { for (int i = 0; i < size; i++)
	                 content[i].clear();
			       if ((size > 0) && alive) delete content;
//				   if (alive) delete content;
				   alive = false;
				   size = 0;
				 };

	int get(int num){     // out of range �̊Ǘ�
      if ((num < 0) || (num >= size)) return -1;
      else return num;
      };
	void get_nearest(float Val, float *res1, float *res2, 
	//						   int *n1, int *n2){
						   int_List **nn1, int_List **nn2);

	                        // -10000 
} WebArray_Xcoord,
  WebArray_Ycoord,
  WebArray_Diff,
  WebArray_slope;


void WebArray::add(float Val, int segment_num){
  int n;                    //�}�����ׂ� �ꏊ (0 - size)
  for (n = 0;  (n < size)  && (content[n].Val < Val); n++ );
  if ((n < size) && (Abs(content[n].Val - Val) < 1) ){
//  if ((n < size) && (Abs(content[n].Val == Val)) {
    
    content[n].Owner.add(segment_num);
	content[n].Strength++;
  }
  else{
    Web_Data* tmp = new Web_Data[size + 1];
	for (int i = 0; i < n ; i++){
	  *(tmp + i) = *(content + i);};
	for (int j = n; j < size; j++){
	  *(tmp + j + 1) = *(content + j);};
	if ( size > 0 ) delete content;
	content = tmp;

//	for (int  j = size - 1; j >= n; j--){
//	  *(content + j + 1) = *(content + j);};
  

	content[n].Owner.clear();
	content[n].Val      = Val;
	content[n].Strength = 1;
	content[n].Owner.add(segment_num);
	size++;
	alive = true;
  }
};
int WebArray::remove(float Val, int segment_num){
  int n;                    //�폜���ׂ� �ꏊ (0 - size)
  for (n = 0;  n < size ; n++ ){
//    if (Abs(content[n].Val - Val) == 0){
      if (content[n].Owner.remove_by_content(segment_num)){ //���s���邩��
        content[n].Strength--;
        if (content[n].Owner.size == 0){     //����ۂȂ̂ŋl�߂�
   	      for (int i = n; i < size - 1; i++){
	        *(content + i ) = *(content + i + 1);}
		  content[size - 1].Owner.clear();
	      size--;
		}
	  return true; // success!!
	  }
//    }
  }
  return false;               // Not found
};

void WebArray::get_nearest(float Val, float *res1, float *res2, 
						   int_List **nn1, int_List **nn2){
  // Val �ɋ߂�����Ԃ��B
  int t;



  if (size == 0) {          // Error
     *res1 = -10000;
     *res2 = -10000;
	 return;
  }
  int n;                    //�}�����ׂ� �ꏊ (0 - size)
  for (n = 0;  (n < size)  && (content[n].Val < Val); n++ );
  if (n == 0) {
    *res1 = content[0].Val;
	*nn1 = &content[0].Owner;

	if ((t = get(1)) == -1)  
	  *res2 = -10000;
	else{
	  *res2 = content[t].Val;
	  *nn2 = &content[t].Owner;
	    }
	return;
  }
  if (n == size) {
    *res1 = content[size - 1].Val;
	*nn1 = &content[size - 1].Owner;

	if ((t = get(size -2)) == -1)  
	  *res2 = -10000;
	else{
	  *res2 = content[t].Val;
	  *nn2 = &content[t].Owner;
		}
	return;
  }
  if ((Val - content[n-1].Val) < (content[n].Val - Val)){
     *res1 = content[n-1].Val;
   	 *nn1 = &content[n-1].Owner;
     if ((n-2 >= 0) && 
         ((Val - content[n-2].Val) 
         <(content[n].Val - Val))){
        *res2 = content[n-2].Val;
        *nn2 = &content[n-2].Owner;
		}
	 else{ 
        *res2 = content[ n].Val;
        *nn2 = &content[n].Owner;
        }
  }
  else{
     *res1 = content[ n].Val;
     *nn1 = &content[n].Owner;

     if ((n + 1 < size) && 
         ((Val - content[n-1].Val) 
         >(content[n+1].Val - Val)))
       {*res2 = content[n+1].Val;
        *nn2 = &content[n+1].Owner;
		}
	 else 
       {*res2 = content[n-1].Val;
        *nn2 = &content[n-1].Owner;
        } 
  }
}










class PairWeb_Data {
  public:
    float Val;
	float Strength;
	int_List Owner1;
	int_List Owner2;
	void clear() {Owner1.clear();
	              Owner2.clear();};
	int remove_owner(int segment_num){
	  for (int i = 0 ; i < Owner1.size ; i++){
	    if ((Owner1.get(i) == segment_num) ||
			(Owner2.get(i) == segment_num)){
			Owner1.remove_by_index(i);
			Owner2.remove_by_index(i);
			return true;
		 }
	  }
	  return false;
    };
}; 
 
class PairWebArray {
    int alive;
  public:
//    PairWeb_Data* content;
    PairWeb_Data content[1000];
	int         size;
	PairWebArray(void)  {size = 0; alive = false;};
//	~PairWebArray(void) {if ((size > 0) && alive) 
//	                    delete content;};

    void add(float Val, int segment_num1, int segment_num2);
    int remove(int segment_num);

	void clear() { for (int i = 0; i < size; i++)
	                 content[i].clear();
				   // if ((size > 0) && alive) delete content;
//				   if (alive) delete content;
				   alive = false;
				   size = 0;
				 };

	float get(int num){     // out of range �̊Ǘ�
      if ((num < 0) || (num >= size)) {return -10000;}
      else {return content[num].Val;}
      };
	void get_nearest(float Val, float *res1, float *res2);
	                        // -10000 
} PairWebArray_Diff;
//  PairWebArray_slope;


void PairWebArray::add(float Val, int segment_num1, int segment_num2){
  if (Val > 2000) return;

  int n;                    //�}�����ׂ� �ꏊ (0 - size)
  for (n = 0;  (n < size)  && (content[n].Val < Val); n++ );
  if ((n < size) && (Abs(content[n].Val - Val) < 10)) {
    
    content[n].Owner1.add(segment_num1);
    content[n].Owner2.add(segment_num2);
	content[n].Strength++;
  }
  else{
//    PairWeb_Data* tmp = new PairWeb_Data[size + 1];
//	for (int i = 0; i < n ; i++){
//	  *(tmp + i) = *(content + i);};
//	for (int j = n; j < size; j++){
//	  *(tmp + j + 1) = *(content + j);};
//	if ( size > 0 ) delete content;
//	content = tmp;

	for (int j = size - 1; j >= n; j--){
	  *(content + j + 1) = *(content + j);};
  

	content[n].Owner1.clear();
	content[n].Owner2.clear();
	content[n].Val      = Val;
	content[n].Strength = 1;
	content[n].Owner1.add(segment_num1);
	content[n].Owner2.add(segment_num2);
	size++;
	alive = true;
  }
};
int PairWebArray::remove(int segment_num){
  int n;                    //�폜���ׂ� �ꏊ (0 - size)
  for (n = 0;  n < size ; n++ ){
//    if (Abs(content[n].Val - Val) == 0){
      if (content[n].remove_owner(segment_num)){ //���s���邩��
        content[n].Strength--;
        if (content[n].Owner1.size == 0){     //����ۂȂ̂ŋl�߂�
   	      for (int i = n; i < size - 1; i++){
	        *(content + i ) = *(content + i + 1);}
		  content[size - 1].Owner1.clear();
		  content[size - 1].Owner2.clear();
	      size--;
		}
	  return true; // success!!
	  }
//    }
  }
  return false;               // Not found
};

void PairWebArray::get_nearest(float Val, float *res1, float *res2){
  // Val �ɋ߂�����Ԃ��B
  if (size == 0) {          // Error
     *res1 = -10000;
     *res2 = -10000;
	 return;
  }
  int n;                    //�}�����ׂ� �ꏊ (0 - size)
  for (n = 0;  (n < size)  && (content[n].Val < Val); n++ );
  if (n == 0) {
    *res1 = content[0].Val;
	*res2 = get(1);
	return;
  }
  if (n == size) {
    *res1 = content[size - 1].Val;
	*res2 = get(size - 2);
	return;
  }
  if ((Val - content[n-1].Val) < (content[n].Val - Val)){
     *res1 = content[n-1].Val;
     if ((n-2 >= 0) && 
         ((Val - content[n-2].Val) 
         <(content[n].Val - Val)))
       {*res2 = content[n-2].Val;}
	 else 
       {*res2 = content[n].Val;}
  }
  else{
     *res1 = content[n].Val;
     if ((n + 1 < size) && 
         ((Val - content[n-1].Val) 
         >(content[n+1].Val - Val)))
       {*res2 = content[n+1].Val;}
	 else 
       {*res2 = content[n-1].Val;}
  }
}











void WebArray_display(){
  Web_Data *tmp;
  for ( int i = 0 ; i < WebArray_Xcoord.size ; i++){
    tmp	= WebArray_Xcoord.content + i;
    //console.add(tmp->Val);
    //console.print(&(tmp->Owner));
    //console.print(&(tmp->Owner2));
  }   
}	 
void WebArray_clear(){  //�{���s�v �o�O�B��	  //dammy
  WebArray_Xcoord.clear();
  WebArray_Ycoord.clear();
  WebArray_Diff.clear();
  WebArray_slope.clear();

  WebArray_slope.add(0, -1);
  WebArray_slope.add(90, -1);
  WebArray_slope.add(45, -1);
  WebArray_slope.add(135, -1);
  WebArray_slope.add(180, -1);	   

  PairWebArray_Diff.clear();
}
float parallel(int, int);
void PairWebArray_add(Object_Data *object, int segment_num){
  // �V�����̂͂܂������Ă��Ȃ��B
  float width;
  for (int i = 0; i < object->size() ; i++){
    if (width = parallel(object->get(i), segment_num)){
	  if (width < 2000)
	  PairWebArray_Diff.add(width, object->get(i), segment_num);
//	  PairWebArray_Diff.add(width / 2, object->get(i), segment_num);
//	  PairWebArray_Diff.add(width * 2, object->get(i), segment_num);
	}
  }
}
void PairWebArray_remove(int segment_num){
  // �����̂͂����̂����Ă���B
	  PairWebArray_Diff.remove(segment_num);
//	  PairWebArray_Diff.remove(segment_num);	  //  /2
//	  PairWebArray_Diff.remove(segment_num);	  //  *2
}


void WebArray_add(int segment_num){
  Segment_Data* segment = SegmentArray.get(segment_num);
  WebArray_Xcoord.add(
    NodeArray.get(segment->start)->X, 
    segment_num);
  WebArray_Xcoord.add(
    NodeArray.get(segment->end)->X, 
    segment_num);

//  ���_�͗]���Ȃ̂ŐڐG���Ƀ`�F�b�N����̂݁B
//                  �������Ɛ������̂�
  if ((NodeArray.get(segment->start)->Y ==
       NodeArray.get(segment->end)->Y)  &&
	  (Abs(NodeArray.get(segment->start)->X -
           NodeArray.get(segment->end)->X) > 200))
    WebArray_Xcoord.add(
      (NodeArray.get(segment->end)->X + 
       NodeArray.get(segment->start)->X ) / 2, 
       segment_num);
  WebArray_Ycoord.add(
    NodeArray.get(segment->start)->Y, 
    segment_num);
  WebArray_Ycoord.add(
    NodeArray.get(segment->end)->Y, 
    segment_num);
  if ((NodeArray.get(segment->start)->X ==
       NodeArray.get(segment->end)->X) &&
	  (Abs(NodeArray.get(segment->start)->Y -
           NodeArray.get(segment->end)->Y) > 200))
     WebArray_Ycoord.add(
       (NodeArray.get(segment->end)->Y + 
        NodeArray.get(segment->start)->Y ) / 2, 
        segment_num);
  //  �]���Ȑ������Ȃ��B
  if ((  NodeArray.get(segment->end)->Y
       - NodeArray.get(segment->start)->Y) == 0) 
  WebArray_Diff.add(
    Abs(  NodeArray.get(segment->end)->X
        - NodeArray.get(segment->start)->X ),
    segment_num);
//  WebArray_Diff.add(
//    Abs(  NodeArray.get(segment->end)->X
//        - NodeArray.get(segment->start)->X ) / 2,
//    segment_num);
//  WebArray_Diff.add(
//    Abs(  NodeArray.get(segment->end)->X
//        - NodeArray.get(segment->start)->X ) * 2,
//    segment_num);
//  }
  //  �]���Ȑ������Ȃ��B
  if ((  NodeArray.get(segment->end)->X
       - NodeArray.get(segment->start)->X) == 0)
   
  WebArray_Diff.add(
    Abs(  NodeArray.get(segment->end)->Y
        - NodeArray.get(segment->start)->Y ),
    segment_num);
//  WebArray_Diff.add(
//    Abs(  NodeArray.get(segment->end)->Y
//        - NodeArray.get(segment->start)->Y ) / 2,
//    segment_num);
//  WebArray_Diff.add(
//    Abs(  NodeArray.get(segment->end)->Y
//        - NodeArray.get(segment->start)->Y ) * 2,
//    segment_num);
//  }
  float slope = 
    get_angle(( NodeArray.get(segment->end)->X
              - NodeArray.get(segment->start)->X ),
              ( NodeArray.get(segment->end)->Y
              - NodeArray.get(segment->start)->Y ));   // 0-90
  WebArray_slope.add(
    slope,
    segment_num);
  if (slope < 90)
  WebArray_slope.add(
    slope + 90,
    segment_num);
  else
  WebArray_slope.add(
    slope - 90,
    segment_num);


}

void WebArray_remove(int segment_num){
  Segment_Data* segment = SegmentArray.get(segment_num);
  WebArray_Xcoord.remove(
    NodeArray.get(segment->start)->X, 
    segment_num);
  WebArray_Xcoord.remove(
    NodeArray.get(segment->end)->X, 
    segment_num);
  WebArray_Xcoord.remove(
    (NodeArray.get(segment->end)->X + 
     NodeArray.get(segment->start)->X ) / 2, 
    segment_num);
  WebArray_Ycoord.remove(
    NodeArray.get(segment->start)->Y, 
    segment_num);
  WebArray_Ycoord.remove(
    NodeArray.get(segment->end)->Y, 
    segment_num);
  WebArray_Ycoord.remove(
    (NodeArray.get(segment->end)->Y + 
     NodeArray.get(segment->start)->Y ) / 2, 
    segment_num);
  WebArray_Diff.remove(
    Abs(  NodeArray.get(segment->end)->X
        - NodeArray.get(segment->start)->X ),
    segment_num);
//  WebArray_Diff.remove(
//    Abs(  NodeArray.get(segment->end)->X
//        - NodeArray.get(segment->start)->X )/2,
//    segment_num);
  WebArray_Diff.remove(
    Abs(  NodeArray.get(segment->end)->X
        - NodeArray.get(segment->start)->X )*2,
    segment_num);
  WebArray_Diff.remove(
    Abs(  NodeArray.get(segment->end)->Y
        - NodeArray.get(segment->start)->Y ),
    segment_num);
  WebArray_Diff.remove(
    Abs(  NodeArray.get(segment->end)->Y
        - NodeArray.get(segment->start)->Y )/2,
    segment_num);
  WebArray_Diff.remove(
    Abs(  NodeArray.get(segment->end)->Y
        - NodeArray.get(segment->start)->Y )*2,
    segment_num);
  float slope = 
    get_angle(( NodeArray.get(segment->end)->X
              - NodeArray.get(segment->start)->X ),
              ( NodeArray.get(segment->end)->Y
              - NodeArray.get(segment->start)->Y ));
  WebArray_slope.remove(
	slope,
    segment_num);
  if (slope < 90)
  WebArray_slope.remove(
    slope + 90,
    segment_num);
  else
  WebArray_slope.remove(
    slope - 90,
    segment_num);

}


class init_dammy{  //��������45�x�̂��߂̃_�~�[
  public:
    init_dammy() {
	             WebArray_clear();
  		  	     };
} init_dammy;

    

/*
extern "C" void _export WINAPI SolverTest(){

  console.clear();
  
  WebArray_Xcoord.add(10 , 0);
  WebArray_Xcoord.add(30 , 1);
  WebArray_Xcoord.add(50 , 2);
  WebArray_Xcoord.add(50 , 3);		 
  WebArray_Xcoord.add(70 , 4);		 

  console.add(WebArray_Xcoord.size);


  console.add(WebArray_Xcoord.get_nearest(25));
  console.add(WebArray_Xcoord.get_nearest(45));
  console.add(WebArray_Xcoord.get_nearest(55));

  WebArray_Xcoord.remove(50 , 3);
  WebArray_Xcoord.remove(50 , 2);

  console.add(WebArray_Xcoord.get_nearest(55));
}
*/