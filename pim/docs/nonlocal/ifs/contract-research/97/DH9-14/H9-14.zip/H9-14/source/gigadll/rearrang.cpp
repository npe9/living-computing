//Copyright (C) 1998 Takeo Igarashi
//
//	�ʒu�̒������I�������� �Z�O�����g�̐���
//		������ڐG�_�ł������� �꒼����Ȃ瓝��
//

#include "NodeList.cpp"       

void SegmentRearrange(int new_segment_num, Front_Object_Data *object);
int  node_on_segment(Node_Data *cross_node, Segment_Data* new_segment);
void devide_old_segment(int old_segment_num, int cross_node_num, Front_Object_Data *object);


const on_edge = 1,
	  on_middle = 2,
	  out_of_segment  = 0;

void SegmentRearrange0(int new_segment_num, Front_Object_Data *object){
  //	�꒼����Ȃ瓝��
 
  List_Index i;
  int old_segment_num;
  Segment_Data *old_segment, *new_segment;
  int relation1, relation2;  // cross_node �̈ʒu
  int relation3, relation4;  //

  int_List garbage_list;
  garbage_list.clear();

  Node_List tmp_node_list;  // �꒼����ɂ��������̏���
  int tmp0, tmp1;
  
  new_segment = SegmentArray.get(new_segment_num);

  int init_size = object->size();
  for ( i = 0 ;  i < init_size; i++){
        old_segment_num = object->get(i);
        old_segment = SegmentArray.get(old_segment_num);  //old


    if (same_line(old_segment, new_segment)){ // ���s  �꒼����
      relation1 = node_on_segment(NodeArray.get(old_segment->start), new_segment); // 0,1,2,3
  	  relation2 = node_on_segment(NodeArray.get(old_segment->end), new_segment); // 0,1,2,3
  	  relation3 = node_on_segment(NodeArray.get(new_segment->start), old_segment); // 0,1,2,3
  	  relation4 = node_on_segment(NodeArray.get(new_segment->end), old_segment); // 0,1,2,3

	  if ((relation1 == out_of_segment) &&
		  (relation2 == out_of_segment) &&
		  (relation3 == out_of_segment) &&
		  (relation4 == out_of_segment)){}
	  else {			   //  �Ȃ����Ă���!
        tmp_node_list.clear();
		tmp_node_list.add(old_segment->start);
		tmp_node_list.add(old_segment->end);
		tmp_node_list.add(new_segment->start);
		tmp_node_list.add(new_segment->end);
		tmp_node_list.sort();

		tmp0 = new_segment->start;
		tmp1 = new_segment->end;
		new_segment->start = tmp_node_list.get(0);
		new_segment->end = tmp_node_list.get(3);
		NodeArray.add_owner(new_segment->start, new_segment_num);
		NodeArray.add_owner(new_segment->end, new_segment_num);
		NodeArray.remove_owner(tmp0, new_segment_num);
		NodeArray.remove_owner(tmp1, new_segment_num);

	    garbage_list.add(old_segment_num);
		}
	}
  }

  // �������� old_segment �̏���  �Ō�ɂ��Ȃ��Ƃ��������Ȃ�B
  for ( i = 0 ; i < garbage_list.size ; i++){
    object->remove_by_content(garbage_list.get(i));
  }


}


void SegmentRearrange1(int new_segment_num, Front_Object_Data *object){
  //	������ڐG�_�Ő؂�
 
  List_Index i;
  int old_segment_num;
  Segment_Data *old_segment, *new_segment;
  Node_Data cross_node;
  int cross_node_num;
  int relation1, relation2;  // cross_node �̈ʒu
  int relation3, relation4;  //

  Node_List cross_node_list;  // new_segment �̕����_
  cross_node_list.clear();
  int_List garbage_list;
  garbage_list.clear();

  Node_List tmp_node_list;  // �꒼����ɂ��������̏���
  int tmp0, tmp1;
  
  new_segment = SegmentArray.get(new_segment_num);

  int init_size = object->size();
  for ( i = 0 ;  i < init_size; i++){
        old_segment_num = object->get(i);
        old_segment = SegmentArray.get(old_segment_num);  //old

    if (get_cross_node(old_segment, new_segment, &cross_node)
	    == 0){   // ��_����

  	relation1 = node_on_segment(&cross_node, new_segment); // 0,1,2,3
	relation2 = node_on_segment(&cross_node, old_segment);
	  // ��_���Z�O�����g��ɂ���̂��`�F�b�N�B

    cross_node_num = -1;

	if ((relation1 == on_edge) && (relation2 == on_edge)) {
	  //�[�_�ڑ��Ȃ̂� �m�[�h���}�[�W
	  if (same_node(NodeArray.get(new_segment->start),
                    NodeArray.get(old_segment->start))){
		  MergeNode(new_segment->start, old_segment->start);}
	  else if (same_node(NodeArray.get(new_segment->start),
                         NodeArray.get(old_segment->end))){
		  MergeNode(new_segment->start, old_segment->end);}
	  else if  (same_node(NodeArray.get(new_segment->end),
                          NodeArray.get(old_segment->start))){
		  MergeNode(new_segment->end, old_segment->start);}
	  else if  (same_node(NodeArray.get(new_segment->end),
                          NodeArray.get(old_segment->end))){
		  MergeNode(new_segment->end, old_segment->end);}
	}
		   
	// old_segment �𕪊�����
	if ((relation2 == on_middle) && (relation1 != out_of_segment)){
	  // on_edge 
  	  if (same_node(&cross_node, NodeArray.get(new_segment->start))){
		  cross_node_num = new_segment->start;
	  }
	  else if (same_node(&cross_node, NodeArray.get(new_segment->end))){
		  cross_node_num = new_segment->end;
  	  } 
	  // on_middle
	  else {
	      cross_node_num = NodeArray.add(cross_node);
	  }
	  devide_old_segment(i, cross_node_num, object);
	  garbage_list.add(old_segment_num);
	    // �Q�ɂ킯��B
	}	 

	// new_segment �̕����B�������񂠂邩������Ȃ��̂ł��߂Ă����B
 	if ((relation1 == on_middle) && (relation2 != out_of_segment)){
	  // on_edge 
  	  if (same_node(&cross_node, NodeArray.get(old_segment->start))){
		  cross_node_num = old_segment->start;
	  }
	  else if (same_node(&cross_node, NodeArray.get(old_segment->end))){
		  cross_node_num = old_segment->end;
  	  }
	  if (cross_node_num != -1)  // middle �̏ꍇ�͂����ς� -> ���₵��
	    cross_node_list.add(cross_node_num);
	  //���߂Ă���
    }
    		
	}             // end if 
  }				  // ���[�v�I��


  // �������� old_segment �̏���  �Ō�ɂ��Ȃ��Ƃ��������Ȃ�B
  for ( i = 0 ; i < garbage_list.size ; i++){
    object->remove_by_content(garbage_list.get(i));
  }


  //  new_segment�̕�������
  if (cross_node_list.size == 0){
    object->add(new_segment_num);  // �����Ȃ�
  }
  else {
	Segment_Data*  segment;
	int segment_num;

    cross_node_list.add(new_segment->start);
    cross_node_list.add(new_segment->end);
	cross_node_list.sort();			// X�̏�����������B

    for (i = 0; i < cross_node_list.size - 1; i++){

	  if (cross_node_list.get(i) !=	cross_node_list.get(i+1)) {
	    // �����m�[�h�����Ă���ꍇ������̂Œ���

  	    segment_num = SegmentArray.create();
        segment = SegmentArray.get(segment_num);

        segment->start = cross_node_list.get(i);
        segment->end =   cross_node_list.get(i+1);
        segment->type =  Straight;

        NodeArray.add_owner(segment->start, segment_num);
        NodeArray.add_owner(segment->end,   segment_num);

        object->add(segment_num);    
      }
    }
  SegmentArray.remove(new_segment_num);	 
    //�ォ����Ȃ��� Owner �����Ȃ��Ȃ��Ă܂���...
 
       
  }
}



int  node_on_segment(Node_Data *cross_node, Segment_Data* segment){
  // cross_node �� ������ɂ��邩���ׂ�B
  Node_Data *StartNode = NodeArray.get(segment->start);
  Node_Data *EndNode = NodeArray.get(segment->end);
  float tmp;

  if (Abs(StartNode->X - EndNode->X) > 50){
    tmp = (cross_node->X - StartNode->X) *
	      (cross_node->X - EndNode->X);
  }
  else {
    tmp = (cross_node->Y - StartNode->Y) *
	      (cross_node->Y - EndNode->Y);
  }

	if (Abs(tmp) < 2500) return on_edge;
	if (tmp < 0) return on_middle;
	return out_of_segment;	// tmp > 0

}


void devide_old_segment(int old_segment_num_index, int cross_node_num, Front_Object_Data *object){
  //  old_segment �� cross_node �� �Q�ɐ؂�B
  //  old start          cross               old end
  //  old start	------- old end
  //                    new start --------- new end

  int  old_segment_num = object->get(old_segment_num_index);
  Segment_Data* old_segment	= SegmentArray.get(old_segment_num);

  int	         segment1_num = SegmentArray.create();
  Segment_Data*  segment1 = SegmentArray.get(segment1_num);
  segment1->start = old_segment->start;
  segment1->end =   cross_node_num;
  segment1->type =  Straight;
  NodeArray.add_owner(segment1->start, segment1_num);
  NodeArray.add_owner(segment1->end,   segment1_num);
  object->add(segment1_num);    


  int	         segment2_num = SegmentArray.create();
  Segment_Data*  segment2 = SegmentArray.get(segment2_num);
  segment2->start = cross_node_num;
  segment2->end =   old_segment->end;
  segment2->type =  Straight;
  NodeArray.add_owner(segment2->start, segment2_num);
  NodeArray.add_owner(segment2->end,   segment2_num);
  object->add(segment2_num);    

  // object->remove(old_segment_num_index); �Ō�ɂ܂Ƃ߂Ă�� ���[�v�̓r���ł��ƍ���..
    
}  