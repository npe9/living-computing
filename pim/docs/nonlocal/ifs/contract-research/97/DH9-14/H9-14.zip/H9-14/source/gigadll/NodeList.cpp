//Copyright (C) 1998 Takeo Igarashi

// Rearrange �ł� new_segment ���� node �p

class Node_List : public int_List{
  public:
	void sort(),
	      quicksort(int,int);
	int bigger(int, int);
};
void Node_List::sort(){
  // X �̏��������ɂȂ�ׂ�B
  int last = size - 1;
  int first = 0;

  quicksort(first, last);
}


void Node_List::quicksort(int first, int last){
  int i,j;
  int half;
  int tmp;

  half = (first + last) / 2 ;
  i = first; 
  j = last;

  while (1){
    while (bigger(half, i)) i++;    //content[i] < half
	while (bigger(j, half)) j--; //content[j] > half
	if ( i >= j )  break;
	tmp = content[i]; content[i] = content[j]; content[j] = tmp;
	i++;  j--;
  }
  if (first < i - 1) quicksort(first, i - 1);
  if (j + 1 < last)  quicksort(j + 1, last);
}

int Node_List::bigger(int a, int b){
  //��{�I��X�Ŕ�r���� ��������Y�Ŕ�r�B   a>b ?
  if ((NodeArray.get(content[a]))->X != 
      (NodeArray.get(content[b]))->X){
    return ((NodeArray.get(content[a]))->X > 
            (NodeArray.get(content[b]))->X);
  }
  else {
    return ((NodeArray.get(content[a]))->Y > 
            (NodeArray.get(content[b]))->Y);
  }
}