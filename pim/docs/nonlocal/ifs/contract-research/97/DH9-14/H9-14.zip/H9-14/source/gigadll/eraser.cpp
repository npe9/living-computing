//Copyright (C) 1998 Takeo Igarashi
//
//   �����S��
//

void remove_interim_node(int node_num, int segment_num, Front_Object_Data *object);

//  ��ԋ߂��Z�O�����g��Ԃ�
extern "C" int _export WINAPI get_segment (float x, float y){
  int num = -1;
  float min = 1000000, tmp;
  Node_Data node;
  node.X = x;
  node.Y = y;

  for (int i = 0;  i <= object.size() - 1; i++){

	 tmp = node_line_distance(&node, SegmentArray.get(object.get(i)));
	 if (min > tmp) {
	   min = tmp;
	   num = i;
	 }
  }
  if (min > 10000) {
   return (-1);
  }
  else{
   return num;
  }

}

// ���ۂɃZ�O�����g����������
extern "C" void _export WINAPI remove_segment (int n){
  copy_object(&object, &previous_object);

  int segment_num = object.get(n);
  Segment_Data *segment = SegmentArray.get(segment_num);
  remove_interim_node(segment->start, segment_num, &object);
  remove_interim_node(segment->end  , segment_num, &object);
  object.remove_by_content(segment_num);

//  console.clear();
//  console.add(NodeArray.size());
//  console.add(SegmentArray.size());

console.clear();
WebArray_display();
}

void remove_interim_node(int node_num, int segment_num, Front_Object_Data *object){
  // �m�[�h��A���_�Ƃ��� �꒼����� 2 segment �Ȃ� ��������B

  Node_Data *node = NodeArray.get(node_num);

  if (node->owner.size != 3) return;

  int segment1_num, segment2_num;
  Segment_Data *segment1, *segment2;
  int first = true;

  for (int i = 0; i < 3 ; i++){
    if (node->owner.get(i) != segment_num) {
	  if (first) {
	     segment1_num = node->owner.get(i);
	     first = false;}
	  else {  
	     segment2_num = node->owner.get(i);}
	}
  }



  segment1 = SegmentArray.get(segment1_num);
  segment2 = SegmentArray.get(segment2_num);
  if (same_line(segment1, segment2)) {
	int start, end;
	if (segment1->start == node_num){ start = segment1->end;}
	  else {                          start = segment1->start;}
	if (segment2->start == node_num){ end = segment2->end;}
	  else {                    	  end = segment2->start;}

    int  new_segment_num = SegmentArray.create(start, end);
    object->add(new_segment_num);    
    object->remove_by_content(segment1_num);
    object->remove_by_content(segment2_num);
  }
}