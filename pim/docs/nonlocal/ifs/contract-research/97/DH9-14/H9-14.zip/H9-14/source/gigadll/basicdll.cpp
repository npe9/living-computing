//Copyright (C) 1998 Takeo Igarashi

#include <windows.h>



class Point_Data {
  public:
  float X;
  float Y;
};

/*
extern "C" int _export WINAPI  adddata(int p1, int p2){
			return (p1 + p2);
			}
*/




int WINAPI LibMain(HINSTANCE hinst, WORD wDataSeg ,WORD cbHeapSize, LPSTR lpszcmdLine)
{
	if (cbHeapSize != 0)
		UnlockData(0);
	return 1;
}

int WINAPI WEP(int nParameter)
{	
			return 1;
}
