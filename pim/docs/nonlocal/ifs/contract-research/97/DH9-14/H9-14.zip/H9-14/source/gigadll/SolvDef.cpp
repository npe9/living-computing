//Copyright (C) 1998 Takeo Igarashi


// ����̎��  constraint_Data. Type
const specify = 1;   // ���     x = 12
const liner   = 2;	 //	�ꎟ��	  x = a * 2 + b * 3 + 1
const on_line = 3;   // ������   x1 = x0 + (x - x0) * (y1 -y0) / (y - y0)
                     //               Variablr     x0, y0, y1 ���̏��I
					 //               Coefficient  x,  y      ���̏��I

class constraint_explanation{
  public:
    int Type;
	int Ref;			  // -1 �Ȃ� Reference ����
	int_List *Reference;  // �������񂠂�ꍇ�@�@Web ����̐���    1-5
};
int_List explain_list;				  //�\���h�~�p�_�~�[
const explain_specifyX = 1;
const explain_specifyY = 2;
const explain_diffX = 3;
const explain_diffY = 4;
const explain_angle = 5;
const explain_touch_start = 6;
const explain_touch_end = 7;
const explain_copy = 8;    // ����
const explain_pallalel = 9;

class constraint_Data{        // In constraintArray

  public:
    int      Type;
    float    Strength;     // constraint Hierachy
    int_List Variable;     // NVariable
    float_List Coefficient;  // NVariable 
    float      Constant;
//    int      NSatisfied;   // Number Of Satisfed Variables
                           // NVariable = NSatisfed then  Fire!!
	constraint_explanation
	         Explain;

//	float    calcurate(int);
	void     clear() {
	           Variable.clear();
			   Coefficient.clear();
			   Constant   = 0;
//			   NSatisfied = 0;

			   Explain.Type = 0;
			   };
	void     refresh(){
//			   NSatisfied = 0;
//			   satisfied = 0;
			   };

//	int        check_satisfied();  // �ォ��`�F�b�N���邽�߁B
//	int        satisfied;  // �ォ��`�F�b�N���邽�߁B
						   // 1	 satisfy by myself
						   // 2	 satisfy by aother
						   // 3  failed  by limit
						   // 0  failed
//	float set_strength(float); //����̋����� ���ʂƃX�e�C�Ƃ̋����Ō���
};						  // -1000 �ȉ��Ȃ����
/*
class Variable_Data{
  public:
    float    Value;           // Value
    int      Specified;
    int_List constraint;
	void     clear() {
	           Value = 0; 
	           Specified = false;
			   constraint.clear();
			   };
};
*/
const MAXconstraint = 200;
class  constraintArray{
    constraint_Data  content[MAXconstraint];
    int _size;

//    int index[MAXconstraint];
 //   int current;
//    void quicksort(int,int);
  public:

    int size()                  {return _size;};
	constraint_Data* get(int n) {return content + n;}
	constraint_Data* create(){
	     content[_size].clear();
	     return content + (_size++);};
	constraint_Data* create(int *n){
	     content[_size].clear();
		 *n = _size;
	     return content + (_size++);};
    void remove()               {content[--_size].clear();}	 // �Ō�̂�����
	void clear()                {for(int i = 0; i < _size; i++)
	                                content[i].clear();
	                             _size = 0;};
	void refresh()   {						 // �ė��p
	  for ( int i = 0 ; i< _size ; i++) content[i].refresh();};
	int dual()   {		 // �������񂪂Ȃ����`�F�b�N
	  for ( int i = 0 ; i< _size-1 ; i++) 
	    if ((content[i].Strength == content[_size-1].Strength)  &&
		   (content[i].Constant == content[i].Constant) &&
		   (content[i].Variable.get(0) == content[i].Variable.get(0)))
		   return true;
	  return  false;  
	  };
//	void sort();
//	int get_next()	{return index[current++];};
//	void init_index()	{current = 0;};

} constraintArray;

/*
const MAXVariable = 4;
class  VariableArray{
    Variable_Data  content[MAXVariable];
    int _size;
  public:
    int NSatisfied;
    int size()                  {return _size;};
	Variable_Data* get(int n)   {return content + n;};
	int create(){
	     content[_size].clear();
		 return _size++;};
	void clear()                 {for(int i = 0; i < _size; i++)
	                                content[i].clear();
	                             _size = 0;};
	void refresh()   {
	  for ( int i = 0 ; i< _size ; i++) content[i].clear();}
} VariableArray; 
*/

float OriginalLocation[4];
float OriginalLength;




/*

void constraintArray::sort(){
  int last = _size - 1;
  int first = 0;

  for (int i = 0; i < _size; i++) index[i] = i;  // ������
  current = 0;

  quicksort(first, last);
}


void constraintArray::quicksort(int first, int last){
  int i,j;
  float half;
  int tmp;

  half = content[index[ (first + last) / 2]].Strength;
  i = first; 
  j = last;

  while (1){
    while (content[index[i]].Strength > half) i++;
	while (content[index[j]].Strength < half) j--;
	if ( i >= j )  break;
	tmp = index[i]; index[i] = index[j]; index[j] = tmp;
	i++;  j--;
  }
  if (first < i - 1) quicksort(first, i - 1);
  if (j + 1 < last)  quicksort(j + 1, last);
}





float constraint_Data::calcurate(int destination_num){	
                                 // VariableArray number
	int i, n;
    float Value, tmp;
	int destination = Variable.get(destination_num);

    switch ( Type )
    {
    case  specify:
      Value = Constant;
	  break;
    case  liner:
      //    a0 * v0 + a1 * v1 +    ... + A(n-1) *V(n-1)  = constant
	  //	vk = (Constant - a0 * v0 - ... - An *Vn) / ak

      Value = Constant;
      for (i = 0; i < Variable.size ; i++){
	    if (destination_num == i){
		  tmp =	Coefficient.get(i);  //����
		}
		else{
 	      n = Variable.get(i);
          Value = Value - Coefficient.get(i) 
		                  * VariableArray.get(n)->Value;
        }
	  }
	  Value /= tmp;
	  break;
    case  on_line:   // ������   x1 = x0 + (x - x0) * (y1 -y0) / (y - y0)
                     //               Variablr     x0, y0, x1, y1 ���̏��I
					 //               Coefficient  x,  y      ���̏��I
	  int x0_ = Variable.get(0);
	  int y0_ = Variable.get(1);
	  int x1_ = Variable.get(2);
	  int y1_ = Variable.get(3);
      float x0 = VariableArray.get(x0_)->Value;
      float y0 = VariableArray.get(y0_)->Value;
      float x1 = VariableArray.get(x1_)->Value;
      float y1 = VariableArray.get(y1_)->Value;
      float x  = Coefficient.get(0);
      float y  = Coefficient.get(1);

	  if (destination_num == 0){
  	      if ((y - y1) == 0){
	        Value = x0;}
	      else{
	        Value =  x1 + (x - x1) * (y0 -y1) / (y - y1);
		  }
	  }
	  else if (destination_num == 1){
  	      if ((x - x1) == 0){
	        Value = y0;}
	      else{
	        Value =  y1 + (y - y1) * (x0 - x1) / (x - x1);
		  }
	  }
      else if (destination_num == 2){
  	      if ((y - y0) == 0){
	        Value = x1;}
	      else{
	        Value =  x0 + (x - x0) * (y1 -y0) / (y - y0);
		  }
	  }
	  else if (destination_num == 3){
  	      if ((x - x0) == 0){
	        Value = y1;}
	      else{
	        Value =  y0 + (y - y0) * (x1 - x0) / (x - x0);
  	      }
	  }
//    default:
//      console.Print "Unkown Constraint Type"
    }

  return Value;
}

int constraint_Data::check_satisfied(){
  return (Abs(calcurate(0) - 
              VariableArray.get(Variable.get(0))->Value) 
          < 10 );      // �덷
}
float constraint_Data::set_strength(float strength){
  //  ����̋����� ���ʂƃX�e�C�Ƃ̋����Ō���
  float min = 10000;
  for ( int i = 0 ; i < Variable.size; i++){
    min =  get_smaller(min, 
              (Abs(calcurate(i) - 
                   VariableArray.get(
                     Variable.get(i))->Value)));
  }
  return (Strength = 800 - min + strength);
}
*/