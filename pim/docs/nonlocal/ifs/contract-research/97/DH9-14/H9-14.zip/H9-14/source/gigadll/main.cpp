//Copyright (C) 1998 Takeo Igarashi
#include <windows.h>
#include <math.h>
const float pi = 3.141592;
const false = 0,
      true =  -1;
float Abs(float a){
      if (a<0) {return -a;}
	  else {return a;}};
float Sqr(float a){
      return a*a;}
float get_smaller(float a, float b){
  if (a < b) return a;
  else return b;
}
int sign(float x){
  if (x < 0) return -1;
  return +1;
}
void swap(float* a, float* b){
	float t = *a;
	*a = *b;
	*b = t;	 
}
	



#include "List.cpp"		 // list basics
#include "Console.cpp"	 // Basic - C++ interface
#include "Time.cpp"      // get_timer


#include "Vector.cpp" //   ��{�I�Ȓ�` length distrane angle .....	 
					   



#include "Object.cpp"	 // Object basics
#include "WebDef.cpp"
#include "Solver.cpp"
  // NewSolv.cpp
  //SolvDef.cpp    �\��
  //  //SolvMain.cpp
  //  //SolvFace.cpp

#include "NewSeg.cpp"    // TurningPoint -> Object
  // Relation.cpp
    //relatio~.cpp
  // OvStrile.cpp
  // Adjust.cpp
  // ReArrang.cpp 
       // NodeList.cpp
  // Candidat.cpp		  explanation
#include "ObjFace.cpp"

#include "Eraser.cpp"

#include "predict.cpp"



// java

//#include "java.cpp"

