# Microsoft Visual C++ generated build script - Do not modify

PROJ = GIGADLL
DEBUG = 1
PROGTYPE = 1
CALLER = 
ARGS = 
DLLS = 
D_RCDEFINES = /d_DEBUG 
R_RCDEFINES = /dNDEBUG 
ORIGIN = MSVC
ORIGIN_VER = 1.00
PROJPATH = D:\HOME\TAKEO\CPP\GIGADLL\
USEMFC = 0
CC = cl
CPP = cl
CXX = cl
CCREATEPCHFLAG = 
CPPCREATEPCHFLAG = 
CUSEPCHFLAG = 
CPPUSEPCHFLAG = 
FIRSTC =             
FIRSTCPP = BASICDLL.CPP
RC = rc
CFLAGS_D_WDLL = /nologo /G2 /W2 /ALw /Od /D "_DEBUG" /FR /GD
CFLAGS_R_WDLL = /nologo /FPi87 /W3 /ALw /O1 /D "NDEBUG" /FR /GD
LFLAGS_D_WDLL = /NOLOGO /NOD /NOE /PACKC:65500 /ALIGN:16 /ONERROR:NOEXE /MAP:FULL
LFLAGS_R_WDLL = /NOLOGO /NOD /NOE /PACKC:61440 /ALIGN:16 /ONERROR:NOEXE /MAP:FULL
LIBS_D_WDLL = oldnames libw ldllcew commdlg.lib olecli.lib olesvr.lib winnls.lib shell.lib 
LIBS_R_WDLL = oldnames libw ldllcew commdlg.lib olecli.lib olesvr.lib winnls.lib shell.lib 
RCFLAGS = /nologo 
RESFLAGS = /nologo /k
RUNFLAGS = 
DEFFILE = GIGADLL.DEF
OBJS_EXT = 
LIBS_EXT = 
!if "$(DEBUG)" == "1"
CFLAGS = $(CFLAGS_D_WDLL)
LFLAGS = $(LFLAGS_D_WDLL)
LIBS = $(LIBS_D_WDLL)
MAPFILE = nul
RCDEFINES = $(D_RCDEFINES)
!else
CFLAGS = $(CFLAGS_R_WDLL)
LFLAGS = $(LFLAGS_R_WDLL)
LIBS = $(LIBS_R_WDLL)
MAPFILE = nul
RCDEFINES = $(R_RCDEFINES)
!endif
!if [if exist MSVC.BND del MSVC.BND]
!endif
SBRS = BASICDLL.SBR \
		MAIN.SBR


BASICDLL_DEP = 

MAIN_DEP = d:\home\takeo\cpp\gigadll\list.cpp \
	d:\home\takeo\cpp\gigadll\console.cpp \
	d:\home\takeo\cpp\gigadll\time.cpp \
	d:\home\takeo\cpp\gigadll\vector.cpp \
	d:\home\takeo\cpp\gigadll\object.cpp \
	d:\home\takeo\cpp\gigadll\webdef.cpp \
	d:\home\takeo\cpp\gigadll\solver.cpp \
	d:\home\takeo\cpp\gigadll\solvdef.cpp \
	d:\home\takeo\cpp\gigadll\stack.cpp \
	d:\home\takeo\cpp\gigadll\newsolv.cpp \
	d:\home\takeo\cpp\gigadll\newseg.cpp \
	d:\home\takeo\cpp\gigadll\relation.cpp \
	d:\home\takeo\cpp\gigadll\relatio~.cpp \
	d:\home\takeo\cpp\gigadll\ovstrike.cpp \
	d:\home\takeo\cpp\gigadll\adjust.cpp \
	d:\home\takeo\cpp\gigadll\rearrang.cpp \
	d:\home\takeo\cpp\gigadll\nodelist.cpp \
	d:\home\takeo\cpp\gigadll\candidat.cpp \
	d:\home\takeo\cpp\gigadll\objface.cpp \
	d:\home\takeo\cpp\gigadll\eraser.cpp \
	d:\home\takeo\cpp\gigadll\predict.cpp


all:	$(PROJ).DLL $(PROJ).BSC

BASICDLL.OBJ:	BASICDLL.CPP $(BASICDLL_DEP)
	$(CPP) $(CFLAGS) $(CPPCREATEPCHFLAG) /c BASICDLL.CPP

MAIN.OBJ:	MAIN.CPP $(MAIN_DEP)
	$(CPP) $(CFLAGS) $(CPPUSEPCHFLAG) /c MAIN.CPP


$(PROJ).DLL::	BASICDLL.OBJ MAIN.OBJ $(OBJS_EXT) $(DEFFILE)
	echo >NUL @<<$(PROJ).CRF
BASICDLL.OBJ +
MAIN.OBJ +
$(OBJS_EXT)
$(PROJ).DLL
$(MAPFILE)
d:\msvc\lib\+
$(LIBS)
$(DEFFILE);
<<
	link $(LFLAGS) @$(PROJ).CRF
	$(RC) $(RESFLAGS) $@
	implib /nowep $(PROJ).LIB $(PROJ).DLL


run: $(PROJ).DLL
	$(PROJ) $(RUNFLAGS)


$(PROJ).BSC: $(SBRS)
	bscmake @<<
/o$@ $(SBRS)
<<
