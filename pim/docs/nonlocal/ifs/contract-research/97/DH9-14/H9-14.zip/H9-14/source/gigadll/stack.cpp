//Copyright (C) 1998 Takeo Igarashi

class Stack_element {
  public: 
    int node_num, child_num;
};

class Stack {
  int  current; 
  Stack_element content[40];  // ����̐��̍ő�l   
  public:
    void clear(){ current = 0;}
	void push(Stack_element element){
	  content[current++] = element;}
	Stack_element pop(){
	  return content[--current];}
};

