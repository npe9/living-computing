//Copyright (C) 1998 Takeo Igarashi
void solve_display(){
  // ��������n�̒��g�̕\��
  int n;

  console.clear();
  constraint_Data *constraint;

//  constraintArray.sort();  
  constraintArray.init_index();

  for (int i = 0; i < constraintArray.size(); i++){
    n = constraintArray.get_next();
	constraint = constraintArray.get(n);
    switch (constraint->Type )
    {
    case  specify:
	console.add(1000);				//    0 .. specify
	  break;
    case  liner:
	  if (constraint->Variable.size ==2) {
	    console.add(1001);}	   //     1 .. equal length
	  else{
	    console.add(1002);}	  //      2 .. new_node on old_segment
	  break;
    case  on_line:   // ������   x1 = x0 + (x - x0) * (y1 -y0) / (y - y0)
	console.add(1003);			  //      3 .. old_node on new_segment
	  break;
    }  
	for (int j = 0; j < constraint->Variable.size; j++){
      console.add(constraint->Variable.get(j));}
    console.add(int(constraint->Constant));
    console.add(int(constraint->Strength));
    console.add(constraint->satisfied);
	console.add(constraint->Explain.Type);
	console.add(0); //constraint->Explain.Reference);
	console.add(-1);
  }
}
