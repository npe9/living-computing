//Copyright (C) 1998 Takeo Igarashi

class Console : public float_List{
  public: 
    void  print(int_List *l){
	     for (int i = 0 ; i < l->size; i ++)
	                 add(l->get(i));
					 add(-1);}

    void  newline();
} console;
void Console::newline(){
  add(-1);
}

List_Index console_current;

extern "C" int _export WINAPI console_init (){
  console_current = 0;
  return console.size;
}
extern "C" float _export WINAPI console_get (){
  if (console_current > console.size) return 0;
  return console.get(console_current++);}
