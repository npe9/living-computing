//Copyright (C) 1998 Takeo Igarashi
/*
	Prediction Mechanism
*/

// ���Έʒu�L�^
const max_connected = 10;
class Connected {
  public:
    
// 	float angle;
//	float length;
	float x;
	float y;
//	int start_or_end;	// base  start=1   end= -1
	Connected(){}
	Connected(Segment_Data* base, Segment_Data* connected, int direction){
		create(base, connected, direction);
	}
	void create(Segment_Data* base, Segment_Data* connected, int direction){
		//		result.length = connected->length();
		//		result.angle = connected->angle(base);
	 	Node_Data* line1s = NodeArray.get(connected->start); 
 	 	Node_Data* line1e = NodeArray.get(connected->end); 
 	 	Node_Data* line2s = NodeArray.get(base->start); 
 	 	Node_Data* line2e = NodeArray.get(base->end);

	 	if (same_node(line1e, line2e)){
		    x = -(line1s->X - line1e->X);
			y = -(line1s->Y - line1e->Y);
		}
	 	else if (same_node(line1s, line2e)){
		    x = -(line1e->X - line1s->X);
			y = -(line1e->Y - line1s->Y);
		}
	 	else if (same_node(line1e, line2s)){
		    x = line1s->X - line1e->X;
			y = line1s->Y - line1e->Y;
		}
		else {	  // 1s == 2s
		    x = line1e->X - line1s->X;
			y = line1e->Y - line1s->Y;
		}

		// 90�x��]
		if (direction >4){
			swap(&x,&y);
			direction -=4;
		}

		if (direction == 2)
			x = -x;
		else if (direction == 3)
			y = -y;
		else if (direction == 4){
			x = -x;
			y = -y;
		}
						
		console.add(x);
		console.add(y);
	}
    friend int operator ==(Connected node1, Connected node2){
  		return ((Abs(node1.x - node2.x) < 10) &&		//�덷���l��
				(Abs(node1.y - node2.y) < 10));
	}
} ;

class ConnectedArray{
    Connected content[max_connected];
  public:
	int size;
    ConnectedArray(){
		size = 0;};
    void add(Connected connected){
		if (size<max_connected)
		   content[size++] = connected;};
	void add(Segment_Data* base, Segment_Data* connected_segment, int direction){
		if (size<max_connected){
			Connected connected(base, connected_segment, direction);
			for (int i=0; i<size; i++)
				if ((content[i] == connected)) return;
			content[size++]=connected;
//			(content+size++)->create(base, connected_segment, direction);
		}
	};
	Connected* get(int n){
		if (n >= size) n = size -1;
		return content+n;};
	void clear(){
		size = 0;};
}	 ;

//  �V�K�����̂܂��ɗ\����␶��
void add_predicted(Segment_Data* new_segment, Connected* connected);
void add_predicted_sub(Node_Data* base_node, float x, float y);
//�\���̂��߂�reference �ɂ����邩�`�F�b�N
int congruent(Segment_Data* s1, Segment_Data* s2);
//  reference �ɂȂ����������̃��X�g������B
void get_connected(int base_num,int direction, ConnectedArray* connectedarray); 




// n == object number
extern "C" int _export WINAPI generate_predictions (int n){

    int similar_num;
    Segment_Data* similar;
    Segment_Data* new_segment;

    ConnectedArray connecteds;

	int direction;  	// 1..+  -1..-  0..dif

    candidates.clear();
	console.clear();

	new_segment = SegmentArray.get(object.get(n));

	connecteds.clear();
    
	for (int i=0;  i<object.size(); i++){
		similar_num = object.get(i);
		similar = SegmentArray.get(similar_num);

		if (direction = congruent(new_segment, similar)){
			console.add(-1);
		    console.add(i);
		    get_connected(i, direction, &connecteds);

		}	
	}
	for ( i=0; i<connecteds.size;i++)
			add_predicted(new_segment, connecteds.get(i));

	return NodeArray.size(); //candidates.size;
}

//�\���̂��߂�reference �ɂ����邩�`�F�b�N
int congruent(Segment_Data* segment0, Segment_Data* segment1){

  Node_Data *line1s, 
            *line1e, 
            *line2s,
            *line2e;
  int direction;
  line1s = NodeArray.get(segment0->start); 
  line1e = NodeArray.get(segment0->end); 
  line2s = NodeArray.get(segment1->start); 
  line2e = NodeArray.get(segment1->end);
 
  float lx1 = -(line1s->X - line1e->X);
  float ly1 = -(line1s->Y - line1e->Y);

  float lx2 = -(line2s->X - line2e->X);
  float ly2 = -(line2s->Y - line2e->Y);

  if ((lx1 == lx2) && (ly1 == ly2)) direction = 1;
  else if ((lx1 == -lx2) && (ly1 == ly2)) direction = 2;
  else if ((lx1 == lx2) && (ly1 == -ly2)) direction = 3;
  else if ((lx1 == -lx2) && (ly1 == -ly2)) direction = 4;
  // 90�x��]
  else if ((lx1 == ly2) && (ly1 == lx2)) direction = 5;
  else if ((lx1 == -ly2) && (ly1 == lx2)) direction = 6;
  else if ((lx1 == ly2) && (ly1 == -lx2)) direction = 7;
  else if ((lx1 == -ly2) && (ly1 == -lx2)) direction = 8;
  else direction = 0;

  return direction;
}



// �Ȃ����Ă邩�`�F�b�N
int check_connected(Segment_Data* segment0, Segment_Data* segment1){

  Node_Data* line1s = NodeArray.get(segment0->start); 
  Node_Data* line1e = NodeArray.get(segment0->end); 
  Node_Data* line2s = NodeArray.get(segment1->start); 
  Node_Data* line2e = NodeArray.get(segment1->end);

  return (same_node(line1s,line2s)
  	   || same_node(line1s,line2e)
  	   || same_node(line1e,line2s)
  	   || same_node(line1e,line2e)); 		    	 
}

//  reference �ɂȂ����������̃��X�g������B
// n == objecdt number != segment_number
void get_connected(int n, int direction, ConnectedArray* connectedarray ){

    Segment_Data* base;
	int connected_num;
    Segment_Data* connected;

//	connectedarray->clear();

	base = SegmentArray.get(object.get(n));

	for (int i=0;  i<object.size(); i++){
	  if (i!=n){
		connected_num = object.get(i);
		connected = SegmentArray.get(connected_num);

		if (check_connected(base, connected)){
			connectedarray->add(base, connected, direction);
		} 
	  }
	}
	return;
}


//  �V�K�����̂܂��ɗ\����␶��
void add_predicted(Segment_Data* base, Connected* connected){


	float x = connected->x;
	float y = connected->y;

	add_predicted_sub(NodeArray.get(base->start), x, y);
	add_predicted_sub(NodeArray.get(base->end), -x, -y);

	// ���������̎���4�{!
	Node_Data* start = NodeArray.get(base->start); 
 	Node_Data* end = NodeArray.get(base->end);
 	if (start->X == end->X){
		add_predicted_sub(NodeArray.get(base->start), -x, y);
		add_predicted_sub(NodeArray.get(base->end), x, -y);
	}
	else if (start->Y == end->Y){
		add_predicted_sub(NodeArray.get(base->start), x, -y);
		add_predicted_sub(NodeArray.get(base->end), -x, y);
 	}
 	 
	
}
void add_predicted_sub(Node_Data* base_node, float x, float y){

    Node_Data StartNode, EndNode;
    Segment_Data *segment;
    int segment_num;

      segment_num = SegmentArray.create();
      segment = SegmentArray.get(segment_num);
      segment->start = NodeArray.add(StartNode);
      segment->end =   NodeArray.add(EndNode);
      segment->type =  Straight;
      NodeArray.add_owner(segment->start, segment_num);
      NodeArray.add_owner(segment->end,   segment_num);

      NodeArray.get(segment->start)->X = base_node->X;
      NodeArray.get(segment->start)->Y = base_node->Y;
      NodeArray.get(segment->end)->X   = base_node->X + x;
      NodeArray.get(segment->end)->Y   = base_node->Y + y;

	  console.add(11);
	  console.add(x);
	  console.add(y);

	  if (object.exist(segment_num))
	  	SegmentArray.remove(segment_num);
	  else
        candidates.add(segment_num); // ���
}
			