//Copyright (C) 1998 Takeo Igarashi
//
//  Meta Constraint	   �������̌��o�̂��߂�
//                     ����̏[���󋵂�����ׂ�
//

const equal = 0;
const diff  = 1;
const slope = 2;
const on_segment = 3;

class meta_constraint{        // In constraintArray

  public:
    int      Type;
    float    Strength;     // constraint Hierachy
    int_List constraints;     // NVariable
	int      Satisfied;
	void     clear() {
	           constraints.clear();
			   Satisfied = false;
			   };

};

const MAXmeta_constraint = 1000;
class  meta_constraintArray{
    meta_constraint  content[MAXmeta_constraint];
    int _size;
  public:

    int size()                  {return _size;};
	meta_constraint* get(int n) {return content + n;}
	meta_constraint* create(){
	     content[_size].clear();
	     return content + (_size++);};
	void clear()                {_size = 0;};
	void check();
} meta_constraintArray;




void meta_display(){

  meta_constraintArray.check();

  meta_constraint *m;
  for (int i= 0; i< meta_constraintArray.size(); i++){
    m = meta_constraintArray.get(i);
    console.add(m->Type);
	console.add(- m->Satisfied );
	console.add(-1);
  }
}

void meta_constraintArray::check(){
  meta_constraint *m;
  constraint_Data *constraint;
  for (int i= 0; i< meta_constraintArray.size(); i++){
    m = meta_constraintArray.get(i);
	m->Satisfied = false;
    for (int j = 0;  j < m->constraints.size; j++){
	  constraint =  constraintArray.get(m->constraints.get(j));
	  if ((VariableArray.get(constraint->Value))->Value
	      == constraint->calcurate())
    	m->Satisfied = true;
	}
  }
}
  
      
  
