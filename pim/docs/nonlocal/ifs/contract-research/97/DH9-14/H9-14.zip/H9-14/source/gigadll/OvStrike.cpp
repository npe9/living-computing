//Copyright (C) 1998 Takeo Igarashi
//
//   OverStrike �̏����B
//

void remove_interim_node(int node_num, int segment_num, Front_Object_Data *object);

void RemoveOverstrike(Segment_Data* new_segment, Front_Object_Data *object, float speed);
int SegmentMerge (Front_Object_Data *object, 
                  Segment_Data *segment1, 
                  Segment_Data *segment2, int flag);
 
void MergeNode (int, int);

void MoveNode(int node1, int node2){
  NodeArray.get(node1)->X = NodeArray.get(node2)->X;
  NodeArray.get(node1)->Y = NodeArray.get(node2)->Y;
}

int SegmentMerge (Front_Object_Data *object, 
                  Segment_Data *segment1, 
                  Segment_Data *segment2, int flag){
  //
  //  Segment �̐ڑ�
  //        RmeoveOverstrike �̃T�u���[�`��
  //
  //		�����������Ȃ����� true ��Ԃ��B
  //  2�{���P�{�ɂ���
  //   j will survive
  // �������A�Ȑ��̏ꍇ�� �Ȃ��邾��


//  if ( segment1.Type == straight ) {  �@�@�@// �{���͏ꍇ�킯
//    if ( segment2.Type == straight ) {

    //  both straight  -> use num1   delete num2
 
      if ( flag == _merge1s2s ) {
//         MergeNode(segment1->end, segment2->start);
		 MoveNode(segment2->start, segment1->end);
      	 }
      else if ( flag == _merge1s2e ) {
//         MergeNode(segment1->end, segment2->end);
		 MoveNode(segment2->end, segment1->end);
      	 }
      else if ( flag == _merge1e2s ) {
//         MergeNode(segment1->start, segment2->start);
		 MoveNode(segment2->start, segment1->start);
		 }
      else if ( flag == _merge1e2e ) {
//         MergeNode(segment1->start, segment2->end);
		 MoveNode(segment2->end, segment1->start);
      	 }
      return true;   // Remove old One!!
}






void RemoveOverstrike(Segment_Data* new_segment, Front_Object_Data *object, float speed){

  // Over Strike �̏���
  // �������������ɍs��
  //
  List_Index i;
  Segment_Data* old_segment;
  int relation;
  
  float parallel_width;

  int_List garbage_list;
  garbage_list.clear();

  // speed  80 - 120 - 200 - 400  
  speed = 100;


  i = 0;
  while( i <= object->size() - 1){
         old_segment = SegmentArray.get(object->get(i));  //old
//         if (!(new_segment->fixed) || (new_segment->type == Curve)){ 
         relation = SegmentRelation(old_segment, new_segment, speed, &parallel_width);


      // ���ʏ��������Ă����B
      if (relation == _part2in1not1e) {
         float distance1 = get_distance(NodeArray.get(new_segment->start), NodeArray.get(old_segment->end));
         float distance2 = get_distance(NodeArray.get(new_segment->end), NodeArray.get(old_segment->end));
         if (distance1 < distance2) {
            relation = _merge1s2s;}
         else{
            relation = _merge1s2e;}
      }
      else if (relation == _part2in1not1s) {
         float distance1 = get_distance(NodeArray.get(new_segment->start), NodeArray.get(old_segment->start));
         float distance2 = get_distance(NodeArray.get(new_segment->end), NodeArray.get(old_segment->start));
         if (distance1 < distance2){ 
            relation = _merge1e2s;}
         else{
            relation = _merge1e2e;}
      }
      else if (relation == _part1in2not2e) {
         float distance1 = get_distance(NodeArray.get(old_segment->start), NodeArray.get(new_segment->end));
         float distance2 = get_distance(NodeArray.get(old_segment->end), NodeArray.get(new_segment->end));
         float distance3 = get_distance(NodeArray.get(new_segment->start), NodeArray.get(new_segment->end));
         if (distance1 < distance2){
           if (distance2 <distance3) {
             relation = _part1in2;}
           else { 
             relation = _merge1s2s;}
	     }
         else{
		   if (distance1< distance3) {
		     relation = _part1in2;}
		   else {
            relation = _merge1e2s;}
		 }
      }
      else if (relation == _part1in2not2s) {
         float distance1 = get_distance(NodeArray.get(old_segment->start), NodeArray.get(new_segment->start));
         float distance2 = get_distance(NodeArray.get(old_segment->end), NodeArray.get(new_segment->start));
         if (distance1 < distance2) {
            relation = _merge1s2e;
         }
         else{
            relation = _merge1e2e;
         }
      }
      




            // �������炪�{��
            if (relation == _identical) {
				garbage_list.add(object->get(i));
			}
            else if (relation == _part1in2) {
                     //Left$(relation, 11) = _part 1 in 2 {
				garbage_list.add(object->get(i));
            }
            else if ((relation == _part2in1) &&
                     (new_segment->length() > old_segment->length() * 0.5)){
				garbage_list.add(object->get(i));
	      	}

            else if ((relation == _merge1s2s) || (relation == _merge1s2e) ||
                     (relation == _merge1e2s) || (relation == _merge1e2e)){
               //   �����Ȃ�Ȃ��� �Е��������B	 �Ȑ��Ȃ�Ȃ��邾���B
                   if (SegmentMerge(object, old_segment, new_segment, relation)) {
                
		  		garbage_list.add(object->get(i));
                   }
			}
       
     i++;
	
   }	// loop

  // �������� old_segment �̏���  �Ō�ɂ��Ȃ��Ƃ��������Ȃ�B
  int segment_num;
  Segment_Data *segment;
  for ( i = 0 ; i < garbage_list.size ; i++){
    segment_num = garbage_list.get(i);
    segment = SegmentArray.get(segment_num);
    remove_interim_node(segment->start, segment_num, object);
    remove_interim_node(segment->end  , segment_num, object);
    object->remove_by_content(segment_num);
  }


}





