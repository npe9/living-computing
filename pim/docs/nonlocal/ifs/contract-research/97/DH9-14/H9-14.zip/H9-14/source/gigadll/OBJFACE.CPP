//Copyright (C) 1998 Takeo Igarashi
// VB �Ƃ̃C���^�t�F�[�X

extern "C" int _export WINAPI generate_candidates (float x0, float y0, float x1, float y1){
  unsigned short t;

  // get_time();
  copy_object(&object, &previous_object);
  GenerateCandidates(&object, x0,y0,x1,y1);  
  // console.clear();
  // console.add(get_time());
  return object.size();
  } 

extern "C" void _export WINAPI add_segment_to_object (float x0, float y0, float x1, float y1){
  Node_Data StartNode, 
            EndNode;
  float speed;

      StartNode.X = x0;
      StartNode.Y = y0;
      EndNode.X = x1;
      EndNode.Y = y1;

//	  speed = TurningPoint_speed(0);
speed = 200;
      AddOneLineToObject(&object, StartNode, EndNode, false, speed);
}

//  add_segments_to_object �̌�� rearrange & object->add �̂ݍs���B
extern "C" void _export WINAPI segment_selected (int selected){

  // console.clear();
  segment_selected_main(selected, &object);

  //console.add(NodeArray.size());
  //console.add(SegmentArray.size());

  WebArray_display();
}

extern "C" void _export WINAPI undo (){
  Hidden_Object_Data tmp;
  copy_object(&object, &tmp);
  copy_object(&previous_object, &object);
  copy_object(&tmp, &previous_object);
  tmp.clear();
}
extern "C" void _export WINAPI object_clear (){
  copy_object(&object, &previous_object);
  object.clear();

  //console.clear();
  //console.add(NodeArray.size());
  //console.add(SegmentArray.size());

}


// Draw_candidates
extern "C" int _export WINAPI candidates_size (){
  return candidates.size;
  } 
extern "C" void _export WINAPI candidates_get (int n, float *x, float *y, float *x1, float *y1){
  Segment_Data segment;
     
  segment = *(SegmentArray.get(candidates.get(n)));
 
  *x = NodeArray.get(segment.start)->X;
  *y = NodeArray.get(segment.start)->Y;
  *x1 = NodeArray.get(segment.end)->X;
  *y1 = NodeArray.get(segment.end)->Y;
 
  return;
} 



extern "C" int _export WINAPI object_size (){
  console.clear();
  console.add(SegmentArray.size());
  return object.size();
  } 
extern "C" void _export WINAPI clear_object2 (){
  object.clear();
  previous_object.clear();
  NodeArray.clear();
  SegmentArray.clear();
  } 
// Draw Object �p    	 object ���ł̔ԍ�
extern "C" void _export WINAPI object_get (int n, float *x, float *y, float *x1, float *y1){
  Segment_Data segment;			  			  
  segment = *(SegmentArray.get(object.get(n)));
  *x = NodeArray.get(segment.start)->X;
  *y = NodeArray.get(segment.start)->Y;
  *x1 = NodeArray.get(segment.end)->X;
  *y1 = NodeArray.get(segment.end)->Y;
  return;
  }
// load �p   
extern "C" void _export WINAPI object_add(float *x, float *y, float *x1, float *y1){
  Node_Data StartNode, EndNode;
  Segment_Data *segment;
  int segment_num;

      segment_num = SegmentArray.create();
      segment = SegmentArray.get(segment_num);
      segment->start = NodeArray.add(*x,*y);
      segment->end =   NodeArray.add(*x1,*y1);
      segment->type =  Straight;
      NodeArray.add_owner(segment->start, segment_num);
      NodeArray.add_owner(segment->end,   segment_num);

	  object.add(segment_num);
}

// Draw Object �p       segment_array �ł̔ԍ�
extern "C" void _export WINAPI segment_get (int n, float *x, float *y, float *x1, float *y1){
  Segment_Data segment;		   
  if ((n < 0) || (n >= SegmentArray.size())) return;
  segment = *(SegmentArray.get(n));
  *x = NodeArray.get(segment.start)->X;
  *y = NodeArray.get(segment.start)->Y;
  *x1 = NodeArray.get(segment.end)->X;
  *y1 = NodeArray.get(segment.end)->Y;
 
  return;
  } 

extern "C" int _export WINAPI web0 (){
  return WebArray_Xcoord.size;
}
extern "C" float _export WINAPI web1 (int num){
  return WebArray_Xcoord.get(num);
}

void print_owner(int node_num){
  Node_Data *node = NodeArray.get(node_num);
  console.add(-111*NodeArray.usedd(node_num));
  for (int i = 0; i < node->owner.size; i++){
    console.add(node->owner.get(i));
  }
}


extern "C" void _export WINAPI check (){
  Segment_Data *segment;
  console.clear();
  for (int i = 0; i < object.size() ; i++){
    segment = SegmentArray.get(object.get(i));
	console.add(object.get(i));
	console.add(-1);
	print_owner(segment->start);
	console.add(-1);
	print_owner(segment->end);
	console.add(-1);
  }
  for (i = 0; i < previous_object.size() ; i++){
    segment = SegmentArray.get(previous_object.get(i));
	console.add(previous_object.get(i));
	console.add(-1);
	print_owner(segment->start);
	console.add(-1);
	print_owner(segment->end);
	console.add(-1);
  }
}