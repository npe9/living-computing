New polynomial 4@0 =
((+3:29 * (2@1 * 1@0)) = +00)
New polynomial 5@0 =
(sqr(1@0) = +00)
