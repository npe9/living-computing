/* Compiled by KLIC compiler version 3.001 (Thu Jun  5 20:19:10 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_util();
Const struct predicate predicate_util_xlosToLst_2 =
   { module_util, 0, 2 };
Const struct predicate predicate_util_xstrToLst_3 =
   { module_util, 1, 3 };
Const struct predicate predicate_util_xstrToLst1_5 =
   { module_util, 2, 5 };
Const struct predicate predicate_util_xstrToLst_2 =
   { module_util, 3, 2 };
Const struct predicate predicate_util_xskipSP_2 =
   { module_util, 4, 2 };
Const struct predicate predicate_util_xtoLower_2 =
   { module_util, 5, 2 };
Const struct predicate predicate_util_xlstToAtom_2 =
   { module_util, 6, 2 };
Const struct predicate predicate_util_xcrlfToSP_2 =
   { module_util, 7, 2 };
Const struct predicate predicate_util_xtabToSP_2 =
   { module_util, 8, 2 };
Const struct predicate predicate_util_xisMember_3 =
   { module_util, 9, 3 };
Const struct predicate predicate_util_xgetCarCdr_3 =
   { module_util, 10, 3 };
Const struct predicate predicate_util_xappend_3 =
   { module_util, 11, 3 };
Const struct predicate predicate_util_xrmRedundantSP_2 =
   { module_util, 12, 2 };
Const struct predicate predicate_util_xrmFirstSP_2 =
   { module_util, 13, 2 };
Const struct predicate predicate_util_xrmFirstLf_2 =
   { module_util, 14, 2 };
Const struct predicate predicate_util_xrmLastLf_2 =
   { module_util, 15, 2 };
Const struct predicate predicate_util_xcrlfToLf_2 =
   { module_util, 16, 2 };
Const struct predicate predicate_util_xatoi_2 =
   { module_util, 17, 2 };
Const struct predicate predicate_util_xatoi1_3 =
   { module_util, 18, 3 };
Const struct predicate predicate_util_xstringJoin_2 =
   { module_util, 19, 2 };
Const struct predicate predicate_util_xstringJoin_3 =
   { module_util, 20, 3 };
Const struct predicate predicate_util_xshowReached_1 =
   { module_util, 21, 1 };
Const struct predicate predicate_util_xshowCommand_1 =
   { module_util, 22, 1 };
Const struct predicate predicate_util_xshowCommand1_2 =
   { module_util, 23, 2 };
Const struct predicate predicate_util_xgetSuffix_2 =
   { module_util, 24, 2 };
Const struct predicate predicate_util_xgetSuffix_2F2_240_3 =
   { module_util, 25, 3 };
Const struct predicate predicate_util_xgetSuffix_2F2_240_2F3_240_3 =
   { module_util, 26, 3 };
Const struct predicate predicate_util_xrev_2 =
   { module_util, 27, 2 };
Const struct predicate predicate_util_xrev_3 =
   { module_util, 28, 3 };
Const struct predicate predicate_util_xmerge_3 =
   { module_util, 29, 3 };
Const struct predicate predicate_util_xmin_3 =
   { module_util, 30, 3 };
Const struct predicate predicate_util_xlstToStrs_2 =
   { module_util, 31, 2 };
extern q string_g_new();
extern Const struct predicate predicate_atom__table_xmake__atom_2;
extern Const struct predicate predicate_klicio_xklicio_1;

module module_util(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_0 =
      declare_string_constant_8(0,0);
  static Const unsigned char strconst_body_1[8] =
    {'r','e','a','c','h','e','d',':',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_1 =
      declare_string_constant_8(strconst_body_1,8);
  static Const q funct_const_2[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_1),
  };
  q a0, a1, a2, a3, a4;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  switch_on_pred() {
    case_pred(0, losToLst_2_top);
    case_pred(1, strToLst_3_top);
    case_pred(2, strToLst1_5_top);
    case_pred(3, strToLst_2_top);
    case_pred(4, skipSP_2_top);
    case_pred(5, toLower_2_top);
    case_pred(6, lstToAtom_2_top);
    case_pred(7, crlfToSP_2_top);
    case_pred(8, tabToSP_2_top);
    case_pred(9, isMember_3_top);
    case_pred(10, getCarCdr_3_top);
    case_pred(11, append_3_top);
    case_pred(12, rmRedundantSP_2_top);
    case_pred(13, rmFirstSP_2_top);
    case_pred(14, rmFirstLf_2_top);
    case_pred(15, rmLastLf_2_top);
    case_pred(16, crlfToLf_2_top);
    case_pred(17, atoi_2_top);
    case_pred(18, atoi1_3_top);
    case_pred(19, stringJoin_2_top);
    case_pred(20, stringJoin_3_top);
    case_pred(21, showReached_1_top);
    case_pred(22, showCommand_1_top);
    case_pred(23, showCommand1_2_top);
    case_pred(24, getSuffix_2_top);
    case_pred(25, getSuffix_2F2_240_3_top);
    case_pred(26, getSuffix_2F2_240_2F3_240_3_top);
    case_pred(27, rev_2_top);
    case_pred(28, rev_3_top);
    case_pred(29, merge_3_top);
    case_pred(30, min_3_top);
    last_case_pred(31, lstToStrs_2_top);
  }

 losToLst_2_top: {
  q x0, x1;
  a1 = qp->args[1];
  qp = qp->next;
 losToLst_2_clear_reason:
  reasonp = reasons;
 losToLst_2_0:
 losToLst_2_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_util_xlosToLst_2);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  a0 = car_of(a0);
  a2 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  execute(strToLst_3_0);
  goto strToLst_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto losToLst_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,losToLst_2_1);
  *reasonp++ =  a0;
  goto losToLst_2_interrupt;
  };
  goto losToLst_2_interrupt;
 losToLst_2_ext_interrupt:
  reasonp = 0l;
 losToLst_2_interrupt:
  goto interrupt_2;
 }

 strToLst_3_top: {
  q x0;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 strToLst_3_clear_reason:
  reasonp = reasons;
 strToLst_3_0:
  allocp[0] = x0 = makeref(&allocp[0]);
  generic_arg[0] = x0;
  call_generic(a0, functor_size_1, 1);
  a3 = a1;
  a4 = a2;
  a2 = x0;
  a1 = makeint(0L);
  execute(strToLst1_5_0);
  goto strToLst1_5_ext_interrupt;
 strToLst_3_ext_interrupt:
  reasonp = 0l;
 strToLst_3_interrupt:
  toppred = &predicate_util_xstrToLst_3;
  goto interrupt_3;
 }

 strToLst1_5_top: {
  q x0, x1, x2, x3, x4;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 strToLst1_5_clear_reason:
  reasonp = reasons;
 strToLst1_5_0:
 strToLst1_5_1:
  if (!isint(a1)) goto strToLst1_5_4;
 strToLst1_5_2:
  if (!isint(a2)) goto strToLst1_5_3;
  gblt_less(a1,a2,strToLst1_5_5);
  generic_arg[0] = a1;
  allocp[0] = x0 = makeref(&allocp[0]);
  generic_arg[1] = x0;
  call_generic(a0, functor_element_2, 1);
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = x0;
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a3, x1);
  x3 = makeint(1L);
  bblt_add_no_check(a1,x3,x4);
  a1 = x4;
  a3 = x2;
  execute(strToLst1_5_0);
  goto strToLst1_5_ext_interrupt;
 strToLst1_5_3:
  if (!isref(a2)) goto strToLst1_5_5;
  deref_and_jump(a2,strToLst1_5_2);
  *reasonp++ =  a2;
  goto strToLst1_5_5;
 strToLst1_5_4:
  if (!isref(a1)) goto strToLst1_5_5;
  deref_and_jump(a1,strToLst1_5_1);
  *reasonp++ =  a1;
  goto strToLst1_5_5;
 strToLst1_5_5:
  otherwise(strToLst1_5_interrupt);
  unify(a4, a3);
  proceed();
 strToLst1_5_ext_interrupt:
  reasonp = 0l;
 strToLst1_5_interrupt:
  toppred = &predicate_util_xstrToLst1_5;
  goto interrupt_5;
 }

 strToLst_2_top: {
  a1 = qp->args[1];
  qp = qp->next;
 strToLst_2_clear_reason:
  reasonp = reasons;
 strToLst_2_0:
  a2 = NILATOM;
  execute(strToLst_3_0);
  goto strToLst_3_ext_interrupt;
 strToLst_2_ext_interrupt:
  reasonp = 0l;
 strToLst_2_interrupt:
  goto interrupt_2;
 }

 skipSP_2_top: {
  q x0;
  a1 = qp->args[1];
  qp = qp->next;
 skipSP_2_clear_reason:
  reasonp = reasons;
 skipSP_2_0:
 skipSP_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 skipSP_2_2:
  switch (ptagof(x0)) {
 case ATOMIC:
 skipSP_2_3:
  if (x0 != makeint(32L)) goto skipSP_2_4;
  a0 = cdr_of(a0);
  execute(skipSP_2_0);
  goto skipSP_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,skipSP_2_2);
  *reasonp++ =  x0;
  goto skipSP_2_4;
  };
  goto skipSP_2_4;
 case VARREF:
  deref_and_jump(a0,skipSP_2_1);
  *reasonp++ =  a0;
  goto skipSP_2_4;
  };
  goto skipSP_2_4;
 skipSP_2_4:
  otherwise(skipSP_2_interrupt);
  unify(a1, a0);
  proceed();
 skipSP_2_ext_interrupt:
  reasonp = 0l;
 skipSP_2_interrupt:
  toppred = &predicate_util_xskipSP_2;
  goto interrupt_2;
 }

 toLower_2_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a1 = qp->args[1];
  qp = qp->next;
 toLower_2_clear_reason:
  reasonp = reasons;
 toLower_2_0:
 toLower_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 toLower_2_2:
  if (!isint(x0)) goto toLower_2_3;
  x1 = makeint(65L);
  gblt_less_or_eq(x1,x0,toLower_2_4);
  x2 = makeint(90L);
  gblt_less_or_eq(x0,x2,toLower_2_4);
  x3 = makeint(32L);
  bblt_add_no_check(x0,x3,x4);
  allocp[0] = x6 = makeref(&allocp[0]);
  allocp[1] = x4;
  x5 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x5);
  a0 = cdr_of(a0);
  a1 = x6;
  execute(toLower_2_0);
  goto toLower_2_ext_interrupt;
 toLower_2_3:
  if (!isref(x0)) goto toLower_2_4;
  deref_and_jump(x0,toLower_2_2);
  *reasonp++ =  x0;
  goto toLower_2_4;
 case VARREF:
  deref_and_jump(a0,toLower_2_1);
  *reasonp++ =  a0;
  goto toLower_2_4;
  };
  goto toLower_2_4;
 toLower_2_4:
  otherwise(toLower_2_interrupt);
 toLower_2_5:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(toLower_2_0);
  goto toLower_2_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto toLower_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,toLower_2_5);
  *reasonp++ =  a0;
  goto toLower_2_interrupt;
  };
  goto toLower_2_interrupt;
 toLower_2_ext_interrupt:
  reasonp = 0l;
 toLower_2_interrupt:
  goto interrupt_2;
 }

 lstToAtom_2_top: {
  q x0, x1;
  a1 = qp->args[1];
  qp = qp->next;
 lstToAtom_2_clear_reason:
  reasonp = reasons;
 lstToAtom_2_0:
  generic_arg[0] = a0;
  x0 = makeint(8L);
  generic_arg[1] = x0;
  new_generic(string_g_new, 2, x1, 0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_atom__table_xmake__atom_2);
  allocp[2] = x1;
  allocp[3] = a1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  proceed();
 lstToAtom_2_ext_interrupt:
  reasonp = 0l;
 lstToAtom_2_interrupt:
  goto interrupt_2;
 }

 crlfToSP_2_top: {
  q x0, x1, x2, x3, x4;
  a1 = qp->args[1];
  qp = qp->next;
 crlfToSP_2_clear_reason:
  reasonp = reasons;
 crlfToSP_2_0:
 crlfToSP_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 crlfToSP_2_2:
  switch (ptagof(x0)) {
 case ATOMIC:
 crlfToSP_2_3:
  if (x0 != makeint(13L)) goto crlfToSP_2_7;
  x1 = cdr_of(a0);
 crlfToSP_2_4:
  switch (ptagof(x1)) {
 case CONS:
  x2 = car_of(x1);
 crlfToSP_2_5:
  switch (ptagof(x2)) {
 case ATOMIC:
 crlfToSP_2_6:
  if (x2 != makeint(10L)) goto crlfToSP_2_7;
  allocp[0] = x4 = makeref(&allocp[0]);
  allocp[1] = makeint(32L);
  x3 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x3);
  a0 = cdr_of(x1);
  a1 = x4;
  execute(crlfToSP_2_0);
  goto crlfToSP_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x2,crlfToSP_2_5);
  *reasonp++ =  x2;
  goto crlfToSP_2_7;
  };
  goto crlfToSP_2_7;
 case VARREF:
  deref_and_jump(x1,crlfToSP_2_4);
  *reasonp++ =  x1;
  goto crlfToSP_2_7;
  };
  goto crlfToSP_2_7;
 case VARREF:
  deref_and_jump(x0,crlfToSP_2_2);
  *reasonp++ =  x0;
  goto crlfToSP_2_7;
  };
  goto crlfToSP_2_7;
 case VARREF:
  deref_and_jump(a0,crlfToSP_2_1);
  *reasonp++ =  a0;
  goto crlfToSP_2_7;
  };
  goto crlfToSP_2_7;
 crlfToSP_2_7:
  otherwise(crlfToSP_2_interrupt);
 crlfToSP_2_8:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 crlfToSP_2_9:
  switch (ptagof(x0)) {
 case ATOMIC:
 crlfToSP_2_10:
  switch ((unsigned long)x0) {
 case (unsigned long) makeint(13L):
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = makeint(32L);
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x1);
  a0 = cdr_of(a0);
  a1 = x2;
  execute(crlfToSP_2_0);
  goto crlfToSP_2_ext_interrupt;
 case (unsigned long) makeint(10L):
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = makeint(32L);
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x1);
  a0 = cdr_of(a0);
  a1 = x2;
  execute(crlfToSP_2_0);
  goto crlfToSP_2_ext_interrupt;
  };
  goto crlfToSP_2_11;
 case VARREF:
  deref_and_jump(x0,crlfToSP_2_9);
  *reasonp++ =  x0;
  goto crlfToSP_2_11;
  };
  goto crlfToSP_2_11;
 case VARREF:
  deref_and_jump(a0,crlfToSP_2_8);
  *reasonp++ =  a0;
  goto crlfToSP_2_11;
  };
  goto crlfToSP_2_11;
 crlfToSP_2_11:
  otherwise(crlfToSP_2_interrupt);
 crlfToSP_2_12:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(crlfToSP_2_0);
  goto crlfToSP_2_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto crlfToSP_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,crlfToSP_2_12);
  *reasonp++ =  a0;
  goto crlfToSP_2_interrupt;
  };
  goto crlfToSP_2_interrupt;
 crlfToSP_2_ext_interrupt:
  reasonp = 0l;
 crlfToSP_2_interrupt:
  goto interrupt_2;
 }

 tabToSP_2_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  qp = qp->next;
 tabToSP_2_clear_reason:
  reasonp = reasons;
 tabToSP_2_0:
 tabToSP_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 tabToSP_2_2:
  switch (ptagof(x0)) {
 case ATOMIC:
 tabToSP_2_3:
  if (x0 != makeint(9L)) goto tabToSP_2_4;
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = makeint(32L);
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x1);
  a0 = cdr_of(a0);
  a1 = x2;
  execute(tabToSP_2_0);
  goto tabToSP_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,tabToSP_2_2);
  *reasonp++ =  x0;
  goto tabToSP_2_4;
  };
  goto tabToSP_2_4;
 case VARREF:
  deref_and_jump(a0,tabToSP_2_1);
  *reasonp++ =  a0;
  goto tabToSP_2_4;
  };
  goto tabToSP_2_4;
 tabToSP_2_4:
  otherwise(tabToSP_2_interrupt);
 tabToSP_2_5:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(tabToSP_2_0);
  goto tabToSP_2_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto tabToSP_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,tabToSP_2_5);
  *reasonp++ =  a0;
  goto tabToSP_2_interrupt;
  };
  goto tabToSP_2_interrupt;
 tabToSP_2_ext_interrupt:
  reasonp = 0l;
 tabToSP_2_interrupt:
  goto interrupt_2;
 }

 isMember_3_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 isMember_3_clear_reason:
  reasonp = reasons;
 isMember_3_0:
 isMember_3_1:
  switch (ptagof(a1)) {
 case CONS:
 isMember_3_2:
  if (isref(a0)) goto isMember_3_5;
 isMember_3_3:
  if (isref(a0)) goto isMember_3_4;
  x0 = car_of(a1);
  if_not_equal(a0, x0, isMember_3_6);
  x1 = makesym(atom_true);
  unify_value(a2, x1);
  proceed();
 isMember_3_4:
  deref_and_jump(a0,isMember_3_3);
  *reasonp++ =  a0;
  goto isMember_3_6;
 isMember_3_5:
  deref_and_jump(a0,isMember_3_2);
  *reasonp++ =  a0;
  goto isMember_3_6;
 case ATOMIC:
  if (a1 != NILATOM) goto isMember_3_6;
  x0 = makesym(atom_false);
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,isMember_3_1);
  *reasonp++ =  a1;
  goto isMember_3_6;
  };
  goto isMember_3_6;
 isMember_3_6:
  otherwise(isMember_3_interrupt);
 isMember_3_7:
  switch (ptagof(a1)) {
 case CONS:
  a1 = cdr_of(a1);
  execute(isMember_3_0);
  goto isMember_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,isMember_3_7);
  *reasonp++ =  a1;
  goto isMember_3_interrupt;
  };
  goto isMember_3_interrupt;
 isMember_3_ext_interrupt:
  reasonp = 0l;
 isMember_3_interrupt:
  goto interrupt_3;
 }

 getCarCdr_3_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 getCarCdr_3_clear_reason:
  reasonp = reasons;
 getCarCdr_3_0:
 getCarCdr_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
  unify(a1, x0);
  x1 = cdr_of(a0);
  unify(a2, x1);
  proceed();
 case VARREF:
  deref_and_jump(a0,getCarCdr_3_1);
  *reasonp++ =  a0;
  goto getCarCdr_3_interrupt;
  };
  goto getCarCdr_3_interrupt;
 getCarCdr_3_ext_interrupt:
  reasonp = 0l;
 getCarCdr_3_interrupt:
  goto interrupt_3;
 }

 append_3_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 append_3_clear_reason:
  reasonp = reasons;
 append_3_0:
 append_3_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  a0 = cdr_of(a0);
  a2 = x1;
  execute(append_3_0);
  goto append_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto append_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,append_3_1);
  *reasonp++ =  a0;
  goto append_3_interrupt;
  };
  goto append_3_interrupt;
 append_3_ext_interrupt:
  reasonp = 0l;
 append_3_interrupt:
  goto interrupt_3;
 }

 rmRedundantSP_2_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  qp = qp->next;
 rmRedundantSP_2_clear_reason:
  reasonp = reasons;
 rmRedundantSP_2_0:
 rmRedundantSP_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 rmRedundantSP_2_2:
  switch (ptagof(x0)) {
 case ATOMIC:
 rmRedundantSP_2_3:
  if (x0 != makeint(32L)) goto rmRedundantSP_2_4;
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = makeint(32L);
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_util_xrmRedundantSP_2);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = x2;
  a0 = cdr_of(a0);
  a1 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  execute(skipSP_2_0);
  goto skipSP_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,rmRedundantSP_2_2);
  *reasonp++ =  x0;
  goto rmRedundantSP_2_4;
  };
  goto rmRedundantSP_2_4;
 case VARREF:
  deref_and_jump(a0,rmRedundantSP_2_1);
  *reasonp++ =  a0;
  goto rmRedundantSP_2_4;
  };
  goto rmRedundantSP_2_4;
 rmRedundantSP_2_4:
  otherwise(rmRedundantSP_2_interrupt);
 rmRedundantSP_2_5:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(rmRedundantSP_2_0);
  goto rmRedundantSP_2_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto rmRedundantSP_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,rmRedundantSP_2_5);
  *reasonp++ =  a0;
  goto rmRedundantSP_2_interrupt;
  };
  goto rmRedundantSP_2_interrupt;
 rmRedundantSP_2_ext_interrupt:
  reasonp = 0l;
 rmRedundantSP_2_interrupt:
  goto interrupt_2;
 }

 rmFirstSP_2_top: {
  q x0, x1;
  a1 = qp->args[1];
  qp = qp->next;
 rmFirstSP_2_clear_reason:
  reasonp = reasons;
 rmFirstSP_2_0:
 rmFirstSP_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 rmFirstSP_2_2:
  switch (ptagof(x0)) {
 case ATOMIC:
 rmFirstSP_2_3:
  if (x0 != makeint(32L)) goto rmFirstSP_2_4;
  x1 = cdr_of(a0);
  unify(a1, x1);
  proceed();
 case VARREF:
  deref_and_jump(x0,rmFirstSP_2_2);
  *reasonp++ =  x0;
  goto rmFirstSP_2_4;
  };
  goto rmFirstSP_2_4;
 case VARREF:
  deref_and_jump(a0,rmFirstSP_2_1);
  *reasonp++ =  a0;
  goto rmFirstSP_2_4;
  };
  goto rmFirstSP_2_4;
 rmFirstSP_2_4:
  otherwise(rmFirstSP_2_interrupt);
  unify(a1, a0);
  proceed();
 rmFirstSP_2_ext_interrupt:
  reasonp = 0l;
 rmFirstSP_2_interrupt:
  goto interrupt_2;
 }

 rmFirstLf_2_top: {
  q x0, x1;
  a1 = qp->args[1];
  qp = qp->next;
 rmFirstLf_2_clear_reason:
  reasonp = reasons;
 rmFirstLf_2_0:
 rmFirstLf_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 rmFirstLf_2_2:
  switch (ptagof(x0)) {
 case ATOMIC:
 rmFirstLf_2_3:
  if (x0 != makeint(10L)) goto rmFirstLf_2_4;
  x1 = cdr_of(a0);
  unify(a1, x1);
  proceed();
 case VARREF:
  deref_and_jump(x0,rmFirstLf_2_2);
  *reasonp++ =  x0;
  goto rmFirstLf_2_4;
  };
  goto rmFirstLf_2_4;
 case VARREF:
  deref_and_jump(a0,rmFirstLf_2_1);
  *reasonp++ =  a0;
  goto rmFirstLf_2_4;
  };
  goto rmFirstLf_2_4;
 rmFirstLf_2_4:
  otherwise(rmFirstLf_2_interrupt);
  unify(a1, a0);
  proceed();
 rmFirstLf_2_ext_interrupt:
  reasonp = 0l;
 rmFirstLf_2_interrupt:
  goto interrupt_2;
 }

 rmLastLf_2_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  qp = qp->next;
 rmLastLf_2_clear_reason:
  reasonp = reasons;
 rmLastLf_2_0:
 rmLastLf_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 rmLastLf_2_2:
  switch (ptagof(x0)) {
 case ATOMIC:
 rmLastLf_2_3:
  if (x0 != makeint(10L)) goto rmLastLf_2_5;
  x1 = cdr_of(a0);
 rmLastLf_2_4:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto rmLastLf_2_5;
  x2 = NILATOM;
  unify_value(a1, x2);
  proceed();
 case VARREF:
  deref_and_jump(x1,rmLastLf_2_4);
  *reasonp++ =  x1;
  goto rmLastLf_2_5;
  };
  goto rmLastLf_2_5;
 case VARREF:
  deref_and_jump(x0,rmLastLf_2_2);
  *reasonp++ =  x0;
  goto rmLastLf_2_5;
  };
  goto rmLastLf_2_5;
 case VARREF:
  deref_and_jump(a0,rmLastLf_2_1);
  *reasonp++ =  a0;
  goto rmLastLf_2_5;
  };
  goto rmLastLf_2_5;
 rmLastLf_2_5:
  otherwise(rmLastLf_2_interrupt);
 rmLastLf_2_6:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(rmLastLf_2_0);
  goto rmLastLf_2_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto rmLastLf_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,rmLastLf_2_6);
  *reasonp++ =  a0;
  goto rmLastLf_2_interrupt;
  };
  goto rmLastLf_2_interrupt;
 rmLastLf_2_ext_interrupt:
  reasonp = 0l;
 rmLastLf_2_interrupt:
  goto interrupt_2;
 }

 crlfToLf_2_top: {
  q x0, x1, x2, x3, x4;
  a1 = qp->args[1];
  qp = qp->next;
 crlfToLf_2_clear_reason:
  reasonp = reasons;
 crlfToLf_2_0:
 crlfToLf_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 crlfToLf_2_2:
  switch (ptagof(x0)) {
 case ATOMIC:
 crlfToLf_2_3:
  if (x0 != makeint(13L)) goto crlfToLf_2_7;
  x1 = cdr_of(a0);
 crlfToLf_2_4:
  switch (ptagof(x1)) {
 case CONS:
  x2 = car_of(x1);
 crlfToLf_2_5:
  switch (ptagof(x2)) {
 case ATOMIC:
 crlfToLf_2_6:
  if (x2 != makeint(10L)) goto crlfToLf_2_7;
  allocp[0] = x4 = makeref(&allocp[0]);
  allocp[1] = makeint(10L);
  x3 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x3);
  a0 = cdr_of(x1);
  a1 = x4;
  execute(crlfToLf_2_0);
  goto crlfToLf_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x2,crlfToLf_2_5);
  *reasonp++ =  x2;
  goto crlfToLf_2_7;
  };
  goto crlfToLf_2_7;
 case VARREF:
  deref_and_jump(x1,crlfToLf_2_4);
  *reasonp++ =  x1;
  goto crlfToLf_2_7;
  };
  goto crlfToLf_2_7;
 case VARREF:
  deref_and_jump(x0,crlfToLf_2_2);
  *reasonp++ =  x0;
  goto crlfToLf_2_7;
  };
  goto crlfToLf_2_7;
 case VARREF:
  deref_and_jump(a0,crlfToLf_2_1);
  *reasonp++ =  a0;
  goto crlfToLf_2_7;
  };
  goto crlfToLf_2_7;
 crlfToLf_2_7:
  otherwise(crlfToLf_2_interrupt);
 crlfToLf_2_8:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 crlfToLf_2_9:
  switch (ptagof(x0)) {
 case ATOMIC:
 crlfToLf_2_10:
  if (x0 != makeint(13L)) goto crlfToLf_2_11;
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = makeint(10L);
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x1);
  a0 = cdr_of(a0);
  a1 = x2;
  execute(crlfToLf_2_0);
  goto crlfToLf_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,crlfToLf_2_9);
  *reasonp++ =  x0;
  goto crlfToLf_2_11;
  };
  goto crlfToLf_2_11;
 case VARREF:
  deref_and_jump(a0,crlfToLf_2_8);
  *reasonp++ =  a0;
  goto crlfToLf_2_11;
  };
  goto crlfToLf_2_11;
 crlfToLf_2_11:
  otherwise(crlfToLf_2_interrupt);
 crlfToLf_2_12:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(crlfToLf_2_0);
  goto crlfToLf_2_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto crlfToLf_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,crlfToLf_2_12);
  *reasonp++ =  a0;
  goto crlfToLf_2_interrupt;
  };
  goto crlfToLf_2_interrupt;
 crlfToLf_2_ext_interrupt:
  reasonp = 0l;
 crlfToLf_2_interrupt:
  goto interrupt_2;
 }

 atoi_2_top: {
  a1 = qp->args[1];
  qp = qp->next;
 atoi_2_clear_reason:
  reasonp = reasons;
 atoi_2_0:
  a2 = a1;
  a1 = makeint(0L);
  execute(atoi1_3_0);
  goto atoi1_3_ext_interrupt;
 atoi_2_ext_interrupt:
  reasonp = 0l;
 atoi_2_interrupt:
  goto interrupt_2;
 }

 atoi1_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 atoi1_3_clear_reason:
  reasonp = reasons;
 atoi1_3_0:
 atoi1_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 atoi1_3_2:
  if (!isint(x0)) goto atoi1_3_3;
  x1 = makeint(48L);
  gblt_less_or_eq(x1,x0,atoi1_3_interrupt);
  x2 = makeint(57L);
  gblt_less_or_eq(x0,x2,atoi1_3_interrupt);
  x3 = makeint(10L);
  bblt_mult_no_check_y(a1,x3,x4);
  bblt_add_no_check_y(x4,x0,x5);
  x6 = makeint(48L);
  bblt_sub_no_check_y(x5,x6,x7);
  a0 = cdr_of(a0);
  a1 = x7;
  execute(atoi1_3_0);
  goto atoi1_3_ext_interrupt;
 atoi1_3_3:
  if (!isref(x0)) goto atoi1_3_interrupt;
  deref_and_jump(x0,atoi1_3_2);
  *reasonp++ =  x0;
  goto atoi1_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto atoi1_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,atoi1_3_1);
  *reasonp++ =  a0;
  goto atoi1_3_interrupt;
  };
  goto atoi1_3_interrupt;
 atoi1_3_ext_interrupt:
  reasonp = 0l;
 atoi1_3_interrupt:
  toppred = &predicate_util_xatoi1_3;
  goto interrupt_3;
 }

 stringJoin_2_top: {
  a1 = qp->args[1];
  qp = qp->next;
 stringJoin_2_clear_reason:
  reasonp = reasons;
 stringJoin_2_0:
  a2 = a1;
  a1 = makefunctor(&string_const_0);
  execute(stringJoin_3_0);
  goto stringJoin_3_ext_interrupt;
 stringJoin_2_ext_interrupt:
  reasonp = 0l;
 stringJoin_2_interrupt:
  goto interrupt_2;
 }

 stringJoin_3_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 stringJoin_3_clear_reason:
  reasonp = reasons;
 stringJoin_3_0:
 stringJoin_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 stringJoin_3_2:
  if (isref(x0)) goto stringJoin_3_5;
  gblt_wait(x0,stringJoin_3_interrupt);
 stringJoin_3_3:
  if (isref(a1)) goto stringJoin_3_4;
  gblt_wait(a1,stringJoin_3_interrupt);
  generic_arg[0] = x0;
  allocp[0] = x1 = makeref(&allocp[0]);
  generic_arg[1] = x1;
  call_generic(a1, functor_join_2, 1);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(stringJoin_3_0);
  goto stringJoin_3_ext_interrupt;
 stringJoin_3_4:
  deref_and_jump(a1,stringJoin_3_3);
  *reasonp++ =  a1;
  goto stringJoin_3_interrupt;
 stringJoin_3_5:
  deref_and_jump(x0,stringJoin_3_2);
  *reasonp++ =  x0;
  goto stringJoin_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto stringJoin_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,stringJoin_3_1);
  *reasonp++ =  a0;
  goto stringJoin_3_interrupt;
  };
  goto stringJoin_3_interrupt;
 stringJoin_3_ext_interrupt:
  reasonp = 0l;
 stringJoin_3_interrupt:
  toppred = &predicate_util_xstringJoin_3;
  goto interrupt_3;
 }

 showReached_1_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  qp = qp->next;
 showReached_1_clear_reason:
  reasonp = reasons;
 showReached_1_0:
 showReached_1_1:
  if (isref(a0)) goto showReached_1_2;
  gblt_wait(a0,showReached_1_interrupt);
  allocp[0] = makesym(functor_putt_1);
  allocp[1] = a0;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_fflush_1);
  allocp[3] = x2 = makeref(&allocp[3]);
  x1 = makefunctor(&allocp[2]);
  allocp[4] = NILATOM;
  allocp[5] = x1;
  x3 = makecons(&allocp[4]);
  allocp[6] = x3;
  allocp[7] = makesym(atom_nl);
  x4 = makecons(&allocp[6]);
  allocp[8] = x4;
  allocp[9] = x0;
  x5 = makecons(&allocp[8]);
  allocp[10] = x5;
  allocp[11] = makefunctor(funct_const_2);
  x6 = makecons(&allocp[10]);
  allocp[12] = makesym(functor_normal_1);
  allocp[13] = x6;
  x7 = makefunctor(&allocp[12]);
  allocp[14] = makesym(functor_stdout_1);
  allocp[15] = x7;
  x8 = makefunctor(&allocp[14]);
  allocp[16] = NILATOM;
  allocp[17] = x8;
  x9 = makecons(&allocp[16]);
  allocp[18] = (q)qp;
  allocp[19] = (q)(&predicate_klicio_xklicio_1);
  allocp[20] = x9;
  qp = (struct goalrec*)&allocp[18];
  allocp += 21;
  proceed();
 showReached_1_2:
  deref_and_jump(a0,showReached_1_1);
  *reasonp++ =  a0;
  goto showReached_1_interrupt;
 showReached_1_ext_interrupt:
  reasonp = 0l;
 showReached_1_interrupt:
  goto interrupt_1;
 }

 showCommand_1_top: {
  q x0, x1, x2, x3;
  qp = qp->next;
 showCommand_1_clear_reason:
  reasonp = reasons;
 showCommand_1_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_util_xshowCommand1_2);
  allocp[2] = a0;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = makesym(functor_normal_1);
  allocp[5] = x0;
  x1 = makefunctor(&allocp[4]);
  allocp[6] = makesym(functor_stdout_1);
  allocp[7] = x1;
  x2 = makefunctor(&allocp[6]);
  allocp[8] = NILATOM;
  allocp[9] = x2;
  x3 = makecons(&allocp[8]);
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_klicio_xklicio_1);
  allocp[12] = x3;
  qp = (struct goalrec*)&allocp[10];
  allocp += 13;
  proceed();
 showCommand_1_ext_interrupt:
  reasonp = 0l;
 showCommand_1_interrupt:
  goto interrupt_1;
 }

 showCommand1_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a1 = qp->args[1];
  qp = qp->next;
 showCommand1_2_clear_reason:
  reasonp = reasons;
 showCommand1_2_0:
 showCommand1_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 showCommand1_2_2:
  if (isref(x0)) goto showCommand1_2_3;
  gblt_wait(x0,showCommand1_2_interrupt);
  allocp[0] = makesym(functor_fwrite_1);
  allocp[1] = x0;
  x1 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_fflush_1);
  allocp[3] = x3 = makeref(&allocp[3]);
  x2 = makefunctor(&allocp[2]);
  allocp[4] = x5 = makeref(&allocp[4]);
  allocp[5] = x2;
  x4 = makecons(&allocp[4]);
  allocp[6] = x4;
  allocp[7] = makesym(atom_nl);
  x6 = makecons(&allocp[6]);
  allocp[8] = x6;
  allocp[9] = x1;
  x7 = makecons(&allocp[8]);
  allocp += 10;
  unify_value(a1, x7);
  a0 = cdr_of(a0);
  a1 = x5;
  execute(showCommand1_2_0);
  goto showCommand1_2_ext_interrupt;
 showCommand1_2_3:
  deref_and_jump(x0,showCommand1_2_2);
  *reasonp++ =  x0;
  goto showCommand1_2_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto showCommand1_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,showCommand1_2_1);
  *reasonp++ =  a0;
  goto showCommand1_2_interrupt;
  };
  goto showCommand1_2_interrupt;
 showCommand1_2_ext_interrupt:
  reasonp = 0l;
 showCommand1_2_interrupt:
  goto interrupt_2;
 }

 getSuffix_2_top: {
  q x0, x1, x2, x3, x4, x5;
  a1 = qp->args[1];
  qp = qp->next;
 getSuffix_2_clear_reason:
  reasonp = reasons;
 getSuffix_2_0:
 getSuffix_2_1:
  if (isref(a0)) goto getSuffix_2_4;
 getSuffix_2_2:
  if (isref(a0)) goto getSuffix_2_3;
  x0 = makefunctor(&string_const_0);
  if_not_equal(a0, x0, getSuffix_2_5);
  x1 = makefunctor(&string_const_0);
  unify_value(a1, x1);
  proceed();
 getSuffix_2_3:
  deref_and_jump(a0,getSuffix_2_2);
  *reasonp++ =  a0;
  goto getSuffix_2_5;
 getSuffix_2_4:
  deref_and_jump(a0,getSuffix_2_1);
  *reasonp++ =  a0;
  goto getSuffix_2_5;
 getSuffix_2_5:
  otherwise(getSuffix_2_interrupt);
  allocp[0] = x0 = makeref(&allocp[0]);
  generic_arg[0] = x0;
  call_generic(a0, functor_size_1, 1);
  x1 = makeint(1L);
  bblt_sub_no_check_y(x0,x1,x2);
  x3 = makeint(0L);
  generic_arg[0] = x3;
  generic_arg[1] = x2;
  x4 = makeint(46L);
  generic_arg[2] = x4;
  allocp[0] = x5 = makeref(&allocp[0]);
  generic_arg[3] = x5;
  call_generic(a0, functor_search__character_4, 1);
  a2 = a0;
  a0 = x5;
  execute(getSuffix_2F2_240_3_0);
  goto getSuffix_2F2_240_3_ext_interrupt;
 getSuffix_2_ext_interrupt:
  reasonp = 0l;
 getSuffix_2_interrupt:
  toppred = &predicate_util_xgetSuffix_2;
  goto interrupt_2;
 }

 getSuffix_2F2_240_3_top: {
  q x0, x1, x2, x3, x4;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 getSuffix_2F2_240_3_clear_reason:
  reasonp = reasons;
 getSuffix_2F2_240_3_0:
 getSuffix_2F2_240_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 getSuffix_2F2_240_3_2:
  if (a0 != makeint(-1L)) goto getSuffix_2F2_240_3_3;
  x0 = makefunctor(&string_const_0);
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,getSuffix_2F2_240_3_1);
  *reasonp++ =  a0;
  goto getSuffix_2F2_240_3_3;
  };
  goto getSuffix_2F2_240_3_3;
 getSuffix_2F2_240_3_3:
  otherwise(getSuffix_2F2_240_3_interrupt);
  x0 = makeint(1L);
  bblt_add_no_check_y(a0,x0,x1);
  generic_arg[0] = x1;
  allocp[0] = x2 = makeref(&allocp[0]);
  generic_arg[1] = x2;
  allocp[1] = x3 = makeref(&allocp[1]);
  generic_arg[2] = x3;
  call_generic(a2, functor_split_3, 2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_util_xgetSuffix_2F2_240_2F3_240_3);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x3;
  a0 = x3;
  a1 = x4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(getSuffix_2_0);
  goto getSuffix_2_ext_interrupt;
 getSuffix_2F2_240_3_ext_interrupt:
  reasonp = 0l;
 getSuffix_2F2_240_3_interrupt:
  toppred = &predicate_util_xgetSuffix_2F2_240_3;
  goto interrupt_3;
 }

 getSuffix_2F2_240_2F3_240_3_top: {
  q x0;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 getSuffix_2F2_240_2F3_240_3_clear_reason:
  reasonp = reasons;
 getSuffix_2F2_240_2F3_240_3_0:
 getSuffix_2F2_240_2F3_240_3_1:
  if (isref(a0)) goto getSuffix_2F2_240_2F3_240_3_4;
 getSuffix_2F2_240_2F3_240_3_2:
  if (isref(a0)) goto getSuffix_2F2_240_2F3_240_3_3;
  x0 = makefunctor(&string_const_0);
  if_not_equal(a0, x0, getSuffix_2F2_240_2F3_240_3_5);
  unify(a1, a2);
  proceed();
 getSuffix_2F2_240_2F3_240_3_3:
  deref_and_jump(a0,getSuffix_2F2_240_2F3_240_3_2);
  *reasonp++ =  a0;
  goto getSuffix_2F2_240_2F3_240_3_5;
 getSuffix_2F2_240_2F3_240_3_4:
  deref_and_jump(a0,getSuffix_2F2_240_2F3_240_3_1);
  *reasonp++ =  a0;
  goto getSuffix_2F2_240_2F3_240_3_5;
 getSuffix_2F2_240_2F3_240_3_5:
  otherwise(getSuffix_2F2_240_2F3_240_3_interrupt);
  unify(a1, a0);
  proceed();
 getSuffix_2F2_240_2F3_240_3_ext_interrupt:
  reasonp = 0l;
 getSuffix_2F2_240_2F3_240_3_interrupt:
  goto interrupt_3;
 }

 rev_2_top: {
  a1 = qp->args[1];
  qp = qp->next;
 rev_2_clear_reason:
  reasonp = reasons;
 rev_2_0:
  a2 = a1;
  a1 = NILATOM;
  execute(rev_3_0);
  goto rev_3_ext_interrupt;
 rev_2_ext_interrupt:
  reasonp = 0l;
 rev_2_interrupt:
  goto interrupt_2;
 }

 rev_3_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 rev_3_clear_reason:
  reasonp = reasons;
 rev_3_0:
 rev_3_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = a1;
  x1 = car_of(a0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  a0 = cdr_of(a0);
  a1 = x0;
  allocp += 2;
  execute(rev_3_0);
  goto rev_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto rev_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,rev_3_1);
  *reasonp++ =  a0;
  goto rev_3_interrupt;
  };
  goto rev_3_interrupt;
 rev_3_ext_interrupt:
  reasonp = 0l;
 rev_3_interrupt:
  toppred = &predicate_util_xrev_3;
  goto interrupt_3;
 }

 merge_3_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 merge_3_clear_reason:
  reasonp = reasons;
 merge_3_0:
 merge_3_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  a0 = cdr_of(a0);
  a2 = x1;
  execute(merge_3_0);
  goto merge_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,merge_3_1);
  *reasonp++ =  a0;
  goto merge_3_2;
  };
  goto merge_3_2;
 merge_3_2:
  alternative(merge_3_clear_reason);
 merge_3_3:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a1);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  a1 = cdr_of(a1);
  a2 = x1;
  execute(merge_3_clear_reason);
  goto merge_3_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto merge_3_4;
  unify(a2, a0);
  proceed();
 case VARREF:
  deref_and_jump(a1,merge_3_3);
  *reasonp++ =  a1;
  goto merge_3_4;
  };
  goto merge_3_4;
 merge_3_4:
 merge_3_5:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != NILATOM) goto merge_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,merge_3_5);
  *reasonp++ =  a0;
  goto merge_3_interrupt;
  };
  goto merge_3_interrupt;
 merge_3_ext_interrupt:
  reasonp = 0l;
 merge_3_interrupt:
  goto interrupt_3;
 }

 min_3_top: {
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 min_3_clear_reason:
  reasonp = reasons;
 min_3_0:
 min_3_1:
  if (!isint(a0)) goto min_3_5;
 min_3_2:
  if (!isint(a1)) goto min_3_4;
  gblt_less_or_eq(a0,a1,min_3_3);
  unify_value(a2, a0);
  proceed();
 min_3_3:
  gblt_greater(a0,a1,min_3_interrupt);
  unify_value(a2, a1);
  proceed();
 min_3_4:
  if (!isref(a1)) goto min_3_interrupt;
  deref_and_jump(a1,min_3_2);
  *reasonp++ =  a1;
  goto min_3_interrupt;
 min_3_5:
  if (!isref(a0)) goto min_3_interrupt;
  deref_and_jump(a0,min_3_1);
  *reasonp++ =  a0;
  goto min_3_interrupt;
 min_3_ext_interrupt:
  reasonp = 0l;
 min_3_interrupt:
  goto interrupt_3;
 }

 lstToStrs_2_top: {
  q x0, x1, x2, x3, x4;
  a1 = qp->args[1];
  qp = qp->next;
 lstToStrs_2_clear_reason:
  reasonp = reasons;
 lstToStrs_2_0:
 lstToStrs_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
  generic_arg[0] = x0;
  x1 = makeint(8L);
  generic_arg[1] = x1;
  new_generic(string_g_new, 2, x2, 0);
  allocp[0] = x4 = makeref(&allocp[0]);
  allocp[1] = x2;
  x3 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x3);
  a0 = cdr_of(a0);
  a1 = x4;
  execute(lstToStrs_2_0);
  goto lstToStrs_2_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto lstToStrs_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,lstToStrs_2_1);
  *reasonp++ =  a0;
  goto lstToStrs_2_interrupt;
  };
  goto lstToStrs_2_interrupt;
 lstToStrs_2_ext_interrupt:
  reasonp = 0l;
 lstToStrs_2_interrupt:
  goto interrupt_2;
 }
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_util);
}
