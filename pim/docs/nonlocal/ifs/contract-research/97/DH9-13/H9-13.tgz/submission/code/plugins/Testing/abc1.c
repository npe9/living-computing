/* Compiled by KLIC compiler version 3.001 (Thu Jun  5 20:19:10 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_main();
Const struct predicate predicate_main_xmain_0 =
   { module_main, 0, 0 };
Const struct predicate predicate_main_xwrite__out_2 =
   { module_main, 1, 2 };
extern Const struct predicate predicate_unix_xunix_1;
extern Const struct predicate predicate_generic_xgeneric_2;
extern Const struct predicate predicate_util_xlosToLst_2;
extern Const struct predicate predicate_ping_xping__select_2;
extern Const struct predicate predicate_tohtml_xtohtml_2;

module module_main(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  static Const unsigned char strconst_body_0[4] =
    "\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_0 =
      declare_string_constant_8(strconst_body_0,1);
  static Const unsigned char strconst_body_1[8] =
    "http://";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_1 =
      declare_string_constant_8(strconst_body_1,7);
  static Const unsigned char strconst_body_2[40] =
    "CLICK HERE TO CONNECT TO FASTEST SERVER";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_2 =
      declare_string_constant_8(strconst_body_2,39);
  static Const q cons_const_3[] = {
    NILATOM,
    makefunctor(&string_const_2),
  };
  static Const unsigned char strconst_body_4[12] =
    "KLIC CODE";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_4 =
      declare_string_constant_8(strconst_body_4,9);
  static Const q cons_const_5[] = {
    NILATOM,
    makefunctor(&string_const_4),
  };
  static Const unsigned char strconst_body_6[28] =
    "www.altavista.digital.com";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_6 =
      declare_string_constant_8(strconst_body_6,25);
  static Const q cons_const_7[] = {
    NILATOM,
    makefunctor(&string_const_6),
  };
  static Const unsigned char strconst_body_8[12] =
    {'w','w','w','.','n','m','s','u','.','e','d','u',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_8 =
      declare_string_constant_8(strconst_body_8,12);
  static Const q cons_const_9[] = {
    makecons(cons_const_7),
    makefunctor(&string_const_8),
  };
  static Const unsigned char strconst_body_10[16] =
    "www.cs.nmsu.edu";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_10 =
      declare_string_constant_8(strconst_body_10,15);
  static Const q cons_const_11[] = {
    makecons(cons_const_9),
    makefunctor(&string_const_10),
  };
  static Const unsigned char strconst_body_12[16] =
    "www.yahoo.com";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_12 =
      declare_string_constant_8(strconst_body_12,13);
  static Const q cons_const_13[] = {
    makecons(cons_const_11),
    makefunctor(&string_const_12),
  };
  static Const q funct_const_14[] = {
    makesym(functor_align_1),
    makesym(atom_center),
  };
  static Const q cons_const_15[] = {
    NILATOM,
    makefunctor(funct_const_14),
  };
  q a0, a1;

  q *reasonp;
 module_top:
  switch_on_pred() {
    case_pred(0, main_0_top);
    last_case_pred(1, write__out_2_top);
  }

 main_0_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20, x21;
  qp = qp->next;
 main_0_clear_reason:
  reasonp = reasons;
 main_0_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_main_xwrite__out_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = makesym(functor_join_2);
  allocp[5] = makefunctor(&string_const_0);
  allocp[6] = x1;
  x2 = makefunctor(&allocp[4]);
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_generic_xgeneric_2);
  allocp[9] = x2;
  allocp[10] = x3 = makeref(&allocp[10]);
  allocp[11] = (q)(struct goalrec*)&allocp[7];
  allocp[12] = (q)(&predicate_tohtml_xtohtml_2);
  allocp[13] = x4 = makeref(&allocp[13]);
  allocp[14] = x3;
  allocp[15] = makesym(functor_text_1);
  allocp[16] = x6 = makeref(&allocp[16]);
  x5 = makefunctor(&allocp[15]);
  allocp[17] = makesym(functor_title_2);
  allocp[18] = NILATOM;
  allocp[19] = x5;
  x7 = makefunctor(&allocp[17]);
  allocp[20] = makesym(functor_head_2);
  allocp[21] = NILATOM;
  allocp[22] = x7;
  x8 = makefunctor(&allocp[20]);
  allocp[23] = makesym(functor_href_1);
  allocp[24] = x10 = makeref(&allocp[24]);
  x9 = makefunctor(&allocp[23]);
  allocp[25] = NILATOM;
  allocp[26] = x9;
  x11 = makecons(&allocp[25]);
  allocp[27] = makesym(functor_text_1);
  allocp[28] = x13 = makeref(&allocp[28]);
  x12 = makefunctor(&allocp[27]);
  allocp[29] = makesym(functor_a_2);
  allocp[30] = x11;
  allocp[31] = x12;
  x14 = makefunctor(&allocp[29]);
  allocp[32] = makesym(functor_h1_2);
  allocp[33] = makecons(cons_const_15);
  allocp[34] = x14;
  x15 = makefunctor(&allocp[32]);
  allocp[35] = makesym(functor_body_2);
  allocp[36] = NILATOM;
  allocp[37] = x15;
  x16 = makefunctor(&allocp[35]);
  allocp[38] = makesym(functor_html_3);
  allocp[39] = NILATOM;
  allocp[40] = x8;
  allocp[41] = x16;
  x17 = makefunctor(&allocp[38]);
  qp = (struct goalrec*)&allocp[11];
  allocp += 42;
  unify_value(x4, x17);
  allocp[0] = makesym(functor_join_2);
  allocp[1] = x19 = makeref(&allocp[1]);
  allocp[2] = x10;
  x18 = makefunctor(&allocp[0]);
  allocp[3] = (q)qp;
  allocp[4] = (q)(&predicate_generic_xgeneric_2);
  allocp[5] = x18;
  allocp[6] = makefunctor(&string_const_1);
  allocp[7] = (q)(struct goalrec*)&allocp[3];
  allocp[8] = (q)(&predicate_ping_xping__select_2);
  allocp[9] = makecons(cons_const_13);
  allocp[10] = x19;
  allocp[11] = (q)(struct goalrec*)&allocp[7];
  allocp[12] = (q)(&predicate_util_xlosToLst_2);
  allocp[13] = makecons(cons_const_3);
  allocp[14] = x13;
  allocp[15] = (q)(struct goalrec*)&allocp[11];
  allocp[16] = (q)(&predicate_util_xlosToLst_2);
  allocp[17] = makecons(cons_const_5);
  allocp[18] = x6;
  allocp[19] = makesym(functor_stdout_1);
  allocp[20] = x0;
  x20 = makefunctor(&allocp[19]);
  allocp[21] = NILATOM;
  allocp[22] = x20;
  x21 = makecons(&allocp[21]);
  allocp[23] = (q)(struct goalrec*)&allocp[15];
  allocp[24] = (q)(&predicate_unix_xunix_1);
  allocp[25] = x21;
  qp = (struct goalrec*)&allocp[23];
  allocp += 26;
  proceed();
 main_0_ext_interrupt:
  reasonp = 0l;
 main_0_interrupt:
  goto interrupt_0;
 }

 write__out_2_top: {
  q x0, x1, x2;
  a0 = qp->args[0];
  a1 = qp->args[1];
  qp = qp->next;
 write__out_2_clear_reason:
  reasonp = reasons;
 write__out_2_0:
 write__out_2_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_normal_1)) goto write__out_2_interrupt;
 write__out_2_2:
  if (isref(a1)) goto write__out_2_3;
  gblt_wait(a1,write__out_2_interrupt);
  allocp[0] = makesym(functor_fwrite_1);
  allocp[1] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = NILATOM;
  allocp[3] = x0;
  x1 = makecons(&allocp[2]);
  x2 = arg(a0, 0);
  allocp += 4;
  unify_value(x2, x1);
  proceed();
 write__out_2_3:
  deref_and_jump(a1,write__out_2_2);
  *reasonp++ =  a1;
  goto write__out_2_interrupt;
 case VARREF:
  deref_and_jump(a0,write__out_2_1);
  *reasonp++ =  a0;
  goto write__out_2_interrupt;
  };
  goto write__out_2_interrupt;
 write__out_2_ext_interrupt:
  reasonp = 0l;
 write__out_2_interrupt:
  goto interrupt_2;
 }
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_main);
}
