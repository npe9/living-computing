/* Compiled by KLIC compiler version 3.001 (Thu Jun  5 20:19:10 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_html();
Const struct predicate predicate_html_xparseHTML_2 =
   { module_html, 0, 2 };
Const struct predicate predicate_html_xparseBrac_3 =
   { module_html, 1, 3 };
Const struct predicate predicate_html_xparseBracInText_4 =
   { module_html, 2, 4 };
Const struct predicate predicate_html_xparseBracInComment_3 =
   { module_html, 3, 3 };
Const struct predicate predicate_html_xparseBracInComment1_3 =
   { module_html, 4, 3 };
Const struct predicate predicate_html_xparseBracInTag_4 =
   { module_html, 5, 4 };
Const struct predicate predicate_html_xrmNullElm_2 =
   { module_html, 6, 2 };
Const struct predicate predicate_html_xcheckTag_2 =
   { module_html, 7, 2 };
Const struct predicate predicate_html_xpartNameAttr_2 =
   { module_html, 8, 2 };
Const struct predicate predicate_html_xpartNameAttr1_3 =
   { module_html, 9, 3 };
Const struct predicate predicate_html_xpartAttr_4 =
   { module_html, 10, 4 };
Const struct predicate predicate_html_xpartAttr1_3 =
   { module_html, 11, 3 };
Const struct predicate predicate_html_xpartAttr2_3 =
   { module_html, 12, 3 };
Const struct predicate predicate_html_xpartAttr2DQ_3 =
   { module_html, 13, 3 };
Const struct predicate predicate_html_xpartAttr2SQ_3 =
   { module_html, 14, 3 };
Const struct predicate predicate_html_xpartAttr2NT_3 =
   { module_html, 15, 3 };
Const struct predicate predicate_html_xrmNullAttr_2 =
   { module_html, 16, 2 };
Const struct predicate predicate_html_xnormTag_2 =
   { module_html, 17, 2 };
Const struct predicate predicate_html_xnormAttr_2 =
   { module_html, 18, 2 };
Const struct predicate predicate_html_xnormAttrValue_2 =
   { module_html, 19, 2 };
Const struct predicate predicate_html_xnormAttrValueDQ_2 =
   { module_html, 20, 2 };
Const struct predicate predicate_html_xnormAttrValueSQ_2 =
   { module_html, 21, 2 };
Const struct predicate predicate_html_xknownTag_1 =
   { module_html, 22, 1 };
Const struct predicate predicate_html_xnoEndtag_1 =
   { module_html, 23, 1 };
Const struct predicate predicate_html_xclosePtag_1 =
   { module_html, 24, 1 };
Const struct predicate predicate_html_xparseTag_2 =
   { module_html, 25, 2 };
Const struct predicate predicate_html_xparseTag_3 =
   { module_html, 26, 3 };
Const struct predicate predicate_html_xparseTag_2F3_246_4 =
   { module_html, 27, 4 };
Const struct predicate predicate_html_xparseTag_2F3_245_4 =
   { module_html, 28, 4 };
Const struct predicate predicate_html_xparseTag_2F3_244_6 =
   { module_html, 29, 6 };
Const struct predicate predicate_html_xparseTag_2F3_244_2F6_240_6 =
   { module_html, 30, 6 };
Const struct predicate predicate_html_xparseTag_2F3_244_2F6_240_2F6_240_5 =
   { module_html, 31, 5 };
Const struct predicate predicate_html_xparseTag_2F3_244_2F6_240_2F6_240_2F5_240_4 =
   { module_html, 32, 4 };
Const struct predicate predicate_html_xparseTag_2F3_243_4 =
   { module_html, 33, 4 };
Const struct predicate predicate_html_xparseTag_2F3_243_2F4_240_7 =
   { module_html, 34, 7 };
Const struct predicate predicate_html_xparseTag_2F3_242_4 =
   { module_html, 35, 4 };
Const struct predicate predicate_html_xparseTag_2F3_241_4 =
   { module_html, 36, 4 };
Const struct predicate predicate_html_xparseTag_2F3_240_6 =
   { module_html, 37, 6 };
Const struct predicate predicate_html_xparseTag_2F3_240_2F6_241_4 =
   { module_html, 38, 4 };
Const struct predicate predicate_html_xparseTag_2F3_240_2F6_241_2F4_240_7 =
   { module_html, 39, 7 };
Const struct predicate predicate_html_xparseTag_2F3_240_2F6_240_5 =
   { module_html, 40, 5 };
Const struct predicate predicate_html_xparseTag_2F3_240_2F6_240_2F5_240_4 =
   { module_html, 41, 4 };
Const struct predicate predicate_html_xnormalizeHTML_2 =
   { module_html, 42, 2 };
Const struct predicate predicate_html_xcatText_2 =
   { module_html, 43, 2 };
Const struct predicate predicate_html_xcatText1_4 =
   { module_html, 44, 4 };
Const struct predicate predicate_html_xunescapeText_2 =
   { module_html, 45, 2 };
Const struct predicate predicate_html_xnormalizeText_2 =
   { module_html, 46, 2 };
Const struct predicate predicate_html_xnormalizeText_2F2_240_4 =
   { module_html, 47, 4 };
Const struct predicate predicate_html_xnormalizeTextInPre_2 =
   { module_html, 48, 2 };
Const struct predicate predicate_html_xnormalizeTextInPreFirst_2 =
   { module_html, 49, 2 };
Const struct predicate predicate_html_xnormalizeTextInPre1_2 =
   { module_html, 50, 2 };
Const struct predicate predicate_html_xrmNullText_2 =
   { module_html, 51, 2 };
Const struct predicate predicate_html_xrmNullP_2 =
   { module_html, 52, 2 };
Const struct predicate predicate_html_xgetAttr_3 =
   { module_html, 53, 3 };
Const struct predicate predicate_html_xhasAttr_3 =
   { module_html, 54, 3 };
Const struct predicate predicate_html_xunescape_2 =
   { module_html, 55, 2 };
extern q string_g_new();
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_x_3D_2E_2E_2;
extern Const struct predicate predicate_util_xcrlfToSP_2;
extern Const struct predicate predicate_util_xskipSP_2;
extern Const struct predicate predicate_util_xtoLower_2;
extern Const struct predicate predicate_util_xlstToAtom_2;
extern Const struct predicate predicate_util_xisMember_3;
extern Const struct predicate predicate_util_xappend_3;
extern Const struct predicate predicate_util_xtabToSP_2;
extern Const struct predicate predicate_util_xrmRedundantSP_2;
extern Const struct predicate predicate_util_xrmFirstSP_2;
extern Const struct predicate predicate_util_xcrlfToLf_2;
extern Const struct predicate predicate_util_xrmFirstLf_2;
extern Const struct predicate predicate_util_xrmLastLf_2;
extern Const struct predicate predicate_util_xatoi_2;
declare_method_table_of(vector);

module module_html(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_0 =
      declare_string_constant_8(0,0);
  static Const q cons_const_1[] = {
    NILATOM,
    makeint(34),
  };
  static Const q cons_const_2[] = {
    NILATOM,
    makeint(39),
  };
  static Const q cons_const_3[] = {
    NILATOM,
    makesym(atom_div),
  };
  static Const q cons_const_4[] = {
    makecons(cons_const_3),
    makesym(atom_center),
  };
  static Const q cons_const_5[] = {
    makecons(cons_const_4),
    makesym(atom_td),
  };
  static Const q cons_const_6[] = {
    makecons(cons_const_5),
    makesym(atom_tr),
  };
  static Const q cons_const_7[] = {
    makecons(cons_const_6),
    makesym(atom_table),
  };
  static Const q cons_const_8[] = {
    makecons(cons_const_7),
    makesym(atom_font),
  };
  static Const q cons_const_9[] = {
    makecons(cons_const_8),
    makesym(atom_textarea),
  };
  static Const q cons_const_10[] = {
    makecons(cons_const_9),
    makesym(atom_option),
  };
  static Const q cons_const_11[] = {
    makecons(cons_const_10),
    makesym(atom_select),
  };
  static Const q cons_const_12[] = {
    makecons(cons_const_11),
    makesym(atom_input),
  };
  static Const q cons_const_13[] = {
    makecons(cons_const_12),
    makesym(atom_form),
  };
  static Const q cons_const_14[] = {
    makecons(cons_const_13),
    makesym(atom_loadimagebtname),
  };
  static Const q cons_const_15[] = {
    makecons(cons_const_14),
    makesym(atom_img),
  };
  static Const q cons_const_16[] = {
    makecons(cons_const_15),
    makesym(atom_hr),
  };
  static Const q cons_const_17[] = {
    makecons(cons_const_16),
    makesym(atom_br),
  };
  static Const q cons_const_18[] = {
    makecons(cons_const_17),
    makesym(atom_a),
  };
  static Const q cons_const_19[] = {
    makecons(cons_const_18),
    makesym(atom_tt),
  };
  static Const q cons_const_20[] = {
    makecons(cons_const_19),
    makesym(atom_i),
  };
  static Const q cons_const_21[] = {
    makecons(cons_const_20),
    makesym(atom_b),
  };
  static Const q cons_const_22[] = {
    makecons(cons_const_21),
    makesym(atom_var),
  };
  static Const q cons_const_23[] = {
    makecons(cons_const_22),
    makesym(atom_strong),
  };
  static Const q cons_const_24[] = {
    makecons(cons_const_23),
    makesym(atom_samp),
  };
  static Const q cons_const_25[] = {
    makecons(cons_const_24),
    makesym(atom_kbd),
  };
  static Const q cons_const_26[] = {
    makecons(cons_const_25),
    makesym(atom_em),
  };
  static Const q cons_const_27[] = {
    makecons(cons_const_26),
    makesym(atom_code),
  };
  static Const q cons_const_28[] = {
    makecons(cons_const_27),
    makesym(atom_cite),
  };
  static Const q cons_const_29[] = {
    makecons(cons_const_28),
    makesym(atom_dd),
  };
  static Const q cons_const_30[] = {
    makecons(cons_const_29),
    makesym(atom_dt),
  };
  static Const q cons_const_31[] = {
    makecons(cons_const_30),
    makesym(atom_dl),
  };
  static Const q cons_const_32[] = {
    makecons(cons_const_31),
    makesym(atom_menu),
  };
  static Const q cons_const_33[] = {
    makecons(cons_const_32),
    makesym(atom_dir),
  };
  static Const q cons_const_34[] = {
    makecons(cons_const_33),
    makesym(atom_ol),
  };
  static Const q cons_const_35[] = {
    makecons(cons_const_34),
    makesym(atom_li),
  };
  static Const q cons_const_36[] = {
    makecons(cons_const_35),
    makesym(atom_ul),
  };
  static Const q cons_const_37[] = {
    makecons(cons_const_36),
    makesym(atom_blockquote),
  };
  static Const q cons_const_38[] = {
    makecons(cons_const_37),
    makesym(atom_address),
  };
  static Const q cons_const_39[] = {
    makecons(cons_const_38),
    makesym(atom_listing),
  };
  static Const q cons_const_40[] = {
    makecons(cons_const_39),
    makesym(atom_xmp),
  };
  static Const q cons_const_41[] = {
    makecons(cons_const_40),
    makesym(atom_pre),
  };
  static Const q cons_const_42[] = {
    makecons(cons_const_41),
    makesym(atom_p),
  };
  static Const q cons_const_43[] = {
    makecons(cons_const_42),
    makesym(atom_h6),
  };
  static Const q cons_const_44[] = {
    makecons(cons_const_43),
    makesym(atom_h5),
  };
  static Const q cons_const_45[] = {
    makecons(cons_const_44),
    makesym(atom_h4),
  };
  static Const q cons_const_46[] = {
    makecons(cons_const_45),
    makesym(atom_h3),
  };
  static Const q cons_const_47[] = {
    makecons(cons_const_46),
    makesym(atom_h2),
  };
  static Const q cons_const_48[] = {
    makecons(cons_const_47),
    makesym(atom_h1),
  };
  static Const q cons_const_49[] = {
    makecons(cons_const_48),
    makesym(atom_body),
  };
  static Const q cons_const_50[] = {
    makecons(cons_const_49),
    makesym(atom_nextid),
  };
  static Const q cons_const_51[] = {
    makecons(cons_const_50),
    makesym(atom_meta),
  };
  static Const q cons_const_52[] = {
    makecons(cons_const_51),
    makesym(atom_link),
  };
  static Const q cons_const_53[] = {
    makecons(cons_const_52),
    makesym(atom_isindex),
  };
  static Const q cons_const_54[] = {
    makecons(cons_const_53),
    makesym(atom_base),
  };
  static Const q cons_const_55[] = {
    makecons(cons_const_54),
    makesym(atom_title),
  };
  static Const q cons_const_56[] = {
    makecons(cons_const_55),
    makesym(atom_head),
  };
  static Const q cons_const_57[] = {
    makecons(cons_const_56),
    makesym(atom_html),
  };
  static Const q cons_const_58[] = {
    NILATOM,
    makesym(atom_img),
  };
  static Const q cons_const_59[] = {
    makecons(cons_const_58),
    makesym(atom_option),
  };
  static Const q cons_const_60[] = {
    makecons(cons_const_59),
    makesym(atom_input),
  };
  static Const q cons_const_61[] = {
    makecons(cons_const_60),
    makesym(atom_hr),
  };
  static Const q cons_const_62[] = {
    makecons(cons_const_61),
    makesym(atom_br),
  };
  static Const q cons_const_63[] = {
    makecons(cons_const_62),
    makesym(atom_nextid),
  };
  static Const q cons_const_64[] = {
    makecons(cons_const_63),
    makesym(atom_meta),
  };
  static Const q cons_const_65[] = {
    makecons(cons_const_64),
    makesym(atom_link),
  };
  static Const q cons_const_66[] = {
    makecons(cons_const_65),
    makesym(atom_isindex),
  };
  static Const q cons_const_67[] = {
    makecons(cons_const_66),
    makesym(atom_base),
  };
  static Const q cons_const_68[] = {
    NILATOM,
    makesym(atom_div),
  };
  static Const q cons_const_69[] = {
    makecons(cons_const_68),
    makesym(atom_center),
  };
  static Const q cons_const_70[] = {
    makecons(cons_const_69),
    makesym(atom_hr),
  };
  static Const q cons_const_71[] = {
    makecons(cons_const_70),
    makesym(atom_dd),
  };
  static Const q cons_const_72[] = {
    makecons(cons_const_71),
    makesym(atom_dt),
  };
  static Const q cons_const_73[] = {
    makecons(cons_const_72),
    makesym(atom_dl),
  };
  static Const q cons_const_74[] = {
    makecons(cons_const_73),
    makesym(atom_menu),
  };
  static Const q cons_const_75[] = {
    makecons(cons_const_74),
    makesym(atom_dir),
  };
  static Const q cons_const_76[] = {
    makecons(cons_const_75),
    makesym(atom_ol),
  };
  static Const q cons_const_77[] = {
    makecons(cons_const_76),
    makesym(atom_li),
  };
  static Const q cons_const_78[] = {
    makecons(cons_const_77),
    makesym(atom_ul),
  };
  static Const q cons_const_79[] = {
    makecons(cons_const_78),
    makesym(atom_blockquote),
  };
  static Const q cons_const_80[] = {
    makecons(cons_const_79),
    makesym(atom_address),
  };
  static Const q cons_const_81[] = {
    makecons(cons_const_80),
    makesym(atom_listing),
  };
  static Const q cons_const_82[] = {
    makecons(cons_const_81),
    makesym(atom_xmp),
  };
  static Const q cons_const_83[] = {
    makecons(cons_const_82),
    makesym(atom_pre),
  };
  static Const q cons_const_84[] = {
    makecons(cons_const_83),
    makesym(atom_dl),
  };
  static Const q cons_const_85[] = {
    makecons(cons_const_84),
    makesym(atom_menu),
  };
  static Const q cons_const_86[] = {
    makecons(cons_const_85),
    makesym(atom_dir),
  };
  static Const q cons_const_87[] = {
    makecons(cons_const_86),
    makesym(atom_ol),
  };
  static Const q cons_const_88[] = {
    makecons(cons_const_87),
    makesym(atom_ul),
  };
  static Const q cons_const_89[] = {
    makecons(cons_const_88),
    makesym(atom_h6),
  };
  static Const q cons_const_90[] = {
    makecons(cons_const_89),
    makesym(atom_h5),
  };
  static Const q cons_const_91[] = {
    makecons(cons_const_90),
    makesym(atom_h4),
  };
  static Const q cons_const_92[] = {
    makecons(cons_const_91),
    makesym(atom_h3),
  };
  static Const q cons_const_93[] = {
    makecons(cons_const_92),
    makesym(atom_h2),
  };
  static Const q cons_const_94[] = {
    makecons(cons_const_93),
    makesym(atom_h1),
  };
  static Const q cons_const_95[] = {
    makecons(cons_const_94),
    makesym(atom_p),
  };
  q a0, a1, a2, a3, a4, a5, a6;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  switch_on_pred() {
    case_pred(0, parseHTML_2_top);
    case_pred(1, parseBrac_3_top);
    case_pred(2, parseBracInText_4_top);
    case_pred(3, parseBracInComment_3_top);
    case_pred(4, parseBracInComment1_3_top);
    case_pred(5, parseBracInTag_4_top);
    case_pred(6, rmNullElm_2_top);
    case_pred(7, checkTag_2_top);
    case_pred(8, partNameAttr_2_top);
    case_pred(9, partNameAttr1_3_top);
    case_pred(10, partAttr_4_top);
    case_pred(11, partAttr1_3_top);
    case_pred(12, partAttr2_3_top);
    case_pred(13, partAttr2DQ_3_top);
    case_pred(14, partAttr2SQ_3_top);
    case_pred(15, partAttr2NT_3_top);
    case_pred(16, rmNullAttr_2_top);
    case_pred(17, normTag_2_top);
    case_pred(18, normAttr_2_top);
    case_pred(19, normAttrValue_2_top);
    case_pred(20, normAttrValueDQ_2_top);
    case_pred(21, normAttrValueSQ_2_top);
    case_pred(22, knownTag_1_top);
    case_pred(23, noEndtag_1_top);
    case_pred(24, closePtag_1_top);
    case_pred(25, parseTag_2_top);
    case_pred(26, parseTag_3_top);
    case_pred(27, parseTag_2F3_246_4_top);
    case_pred(28, parseTag_2F3_245_4_top);
    case_pred(29, parseTag_2F3_244_6_top);
    case_pred(30, parseTag_2F3_244_2F6_240_6_top);
    case_pred(31, parseTag_2F3_244_2F6_240_2F6_240_5_top);
    case_pred(32, parseTag_2F3_244_2F6_240_2F6_240_2F5_240_4_top);
    case_pred(33, parseTag_2F3_243_4_top);
    case_pred(34, parseTag_2F3_243_2F4_240_7_top);
    case_pred(35, parseTag_2F3_242_4_top);
    case_pred(36, parseTag_2F3_241_4_top);
    case_pred(37, parseTag_2F3_240_6_top);
    case_pred(38, parseTag_2F3_240_2F6_241_4_top);
    case_pred(39, parseTag_2F3_240_2F6_241_2F4_240_7_top);
    case_pred(40, parseTag_2F3_240_2F6_240_5_top);
    case_pred(41, parseTag_2F3_240_2F6_240_2F5_240_4_top);
    case_pred(42, normalizeHTML_2_top);
    case_pred(43, catText_2_top);
    case_pred(44, catText1_4_top);
    case_pred(45, unescapeText_2_top);
    case_pred(46, normalizeText_2_top);
    case_pred(47, normalizeText_2F2_240_4_top);
    case_pred(48, normalizeTextInPre_2_top);
    case_pred(49, normalizeTextInPreFirst_2_top);
    case_pred(50, normalizeTextInPre1_2_top);
    case_pred(51, rmNullText_2_top);
    case_pred(52, rmNullP_2_top);
    case_pred(53, getAttr_3_top);
    case_pred(54, hasAttr_3_top);
    last_case_pred(55, unescape_2_top);
  }

 parseHTML_2_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  qp = qp->next;
 parseHTML_2_clear_reason:
  reasonp = reasons;
 parseHTML_2_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xnormalizeHTML_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_html_xparseTag_2);
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = x0;
  allocp[8] = (q)(struct goalrec*)&allocp[4];
  allocp[9] = (q)(&predicate_html_xcheckTag_2);
  allocp[10] = x2 = makeref(&allocp[10]);
  allocp[11] = x1;
  a1 = x2;
  allocp[12] = x3 = makeref(&allocp[12]);
  a2 = x3;
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  execute(parseBrac_3_0);
  goto parseBrac_3_ext_interrupt;
 parseHTML_2_ext_interrupt:
  reasonp = 0l;
 parseHTML_2_interrupt:
  goto interrupt_2;
 }

 parseBrac_3_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 parseBrac_3_clear_reason:
  reasonp = reasons;
 parseBrac_3_0:
  allocp[0] = makesym(functor_text_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = x0;
  x2 = makecons(&allocp[2]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_html_xrmNullElm_2);
  allocp[6] = x2;
  allocp[7] = a1;
  a1 = x1;
  a3 = a2;
  a2 = x3;
  qp = (struct goalrec*)&allocp[4];
  allocp += 8;
  execute(parseBracInText_4_0);
  goto parseBracInText_4_ext_interrupt;
 parseBrac_3_ext_interrupt:
  reasonp = 0l;
 parseBrac_3_interrupt:
  toppred = &predicate_html_xparseBrac_3;
  goto interrupt_3;
 }

 parseBracInText_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 parseBracInText_4_clear_reason:
  reasonp = reasons;
 parseBracInText_4_0:
 parseBracInText_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 parseBracInText_4_2:
  switch (ptagof(x0)) {
 case ATOMIC:
 parseBracInText_4_3:
  if (x0 != makeint(60L)) goto parseBracInText_4_13;
  x1 = cdr_of(a0);
 parseBracInText_4_4:
  switch (ptagof(x1)) {
 case CONS:
  x2 = car_of(x1);
 parseBracInText_4_5:
  switch (ptagof(x2)) {
 case ATOMIC:
 parseBracInText_4_6:
  if (x2 != makeint(33L)) goto parseBracInText_4_13;
  x3 = cdr_of(x1);
 parseBracInText_4_7:
  switch (ptagof(x3)) {
 case CONS:
  x4 = car_of(x3);
 parseBracInText_4_8:
  switch (ptagof(x4)) {
 case ATOMIC:
 parseBracInText_4_9:
  switch ((unsigned long)x4) {
 case (unsigned long) makeint(45L):
  x5 = cdr_of(x3);
 parseBracInText_4_10:
  switch (ptagof(x5)) {
 case CONS:
  x6 = car_of(x5);
 parseBracInText_4_11:
  switch (ptagof(x6)) {
 case ATOMIC:
 parseBracInText_4_12:
  if (x6 != makeint(45L)) goto parseBracInText_4_13;
  x7 = NILATOM;
  unify_value(a1, x7);
  a0 = cdr_of(x5);
  a1 = a2;
  a2 = a3;
  execute(parseBracInComment_3_0);
  goto parseBracInComment_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x6,parseBracInText_4_11);
  *reasonp++ =  x6;
  goto parseBracInText_4_13;
  };
  goto parseBracInText_4_13;
 case VARREF:
  deref_and_jump(x5,parseBracInText_4_10);
  *reasonp++ =  x5;
  goto parseBracInText_4_13;
  };
  goto parseBracInText_4_13;
 case (unsigned long) makeint(62L):
  a0 = cdr_of(x3);
  execute(parseBracInText_4_0);
  goto parseBracInText_4_ext_interrupt;
  };
  goto parseBracInText_4_13;
 case VARREF:
  deref_and_jump(x4,parseBracInText_4_8);
  *reasonp++ =  x4;
  goto parseBracInText_4_13;
  };
  goto parseBracInText_4_13;
 case VARREF:
  deref_and_jump(x3,parseBracInText_4_7);
  *reasonp++ =  x3;
  goto parseBracInText_4_13;
  };
  goto parseBracInText_4_13;
 case VARREF:
  deref_and_jump(x2,parseBracInText_4_5);
  *reasonp++ =  x2;
  goto parseBracInText_4_13;
  };
  goto parseBracInText_4_13;
 case VARREF:
  deref_and_jump(x1,parseBracInText_4_4);
  *reasonp++ =  x1;
  goto parseBracInText_4_13;
  };
  goto parseBracInText_4_13;
 case VARREF:
  deref_and_jump(x0,parseBracInText_4_2);
  *reasonp++ =  x0;
  goto parseBracInText_4_13;
  };
  goto parseBracInText_4_13;
 case VARREF:
  deref_and_jump(a0,parseBracInText_4_1);
  *reasonp++ =  a0;
  goto parseBracInText_4_13;
  };
  goto parseBracInText_4_13;
 parseBracInText_4_13:
  otherwise(parseBracInText_4_interrupt);
 parseBracInText_4_14:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 parseBracInText_4_15:
  switch (ptagof(x0)) {
 case ATOMIC:
 parseBracInText_4_16:
  switch ((unsigned long)x0) {
 case (unsigned long) makeint(60L):
  x1 = NILATOM;
  unify_value(a1, x1);
  allocp[0] = makesym(functor_tag_1);
  allocp[1] = x3 = makeref(&allocp[1]);
  x2 = makefunctor(&allocp[0]);
  allocp[2] = x5 = makeref(&allocp[2]);
  allocp[3] = x2;
  x4 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a2, x4);
  a0 = cdr_of(a0);
  a1 = x3;
  a2 = x5;
  execute(parseBracInTag_4_0);
  goto parseBracInTag_4_ext_interrupt;
 case (unsigned long) makeint(62L):
  x1 = makesym(atom_error);
  unify_value(a3, x1);
  a0 = cdr_of(a0);
  allocp[0] = x2 = makeref(&allocp[0]);
  a3 = x2;
  allocp += 1;
  execute(parseBracInText_4_0);
  goto parseBracInText_4_ext_interrupt;
  };
  goto parseBracInText_4_17;
 case VARREF:
  deref_and_jump(x0,parseBracInText_4_15);
  *reasonp++ =  x0;
  goto parseBracInText_4_17;
  };
  goto parseBracInText_4_17;
 case VARREF:
  deref_and_jump(a0,parseBracInText_4_14);
  *reasonp++ =  a0;
  goto parseBracInText_4_17;
  };
  goto parseBracInText_4_17;
 parseBracInText_4_17:
  otherwise(parseBracInText_4_interrupt);
 parseBracInText_4_18:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(parseBracInText_4_0);
  goto parseBracInText_4_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto parseBracInText_4_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  x1 = NILATOM;
  unify_value(a2, x1);
  x2 = makesym(atom_ok);
  unify_value(a3, x2);
  proceed();
 case VARREF:
  deref_and_jump(a0,parseBracInText_4_18);
  *reasonp++ =  a0;
  goto parseBracInText_4_interrupt;
  };
  goto parseBracInText_4_interrupt;
 parseBracInText_4_ext_interrupt:
  reasonp = 0l;
 parseBracInText_4_interrupt:
  toppred = &predicate_html_xparseBracInText_4;
  goto interrupt_4;
 }

 parseBracInComment_3_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 parseBracInComment_3_clear_reason:
  reasonp = reasons;
 parseBracInComment_3_0:
 parseBracInComment_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 parseBracInComment_3_2:
  switch (ptagof(x0)) {
 case ATOMIC:
 parseBracInComment_3_3:
  if (x0 != makeint(45L)) goto parseBracInComment_3_7;
  x1 = cdr_of(a0);
 parseBracInComment_3_4:
  switch (ptagof(x1)) {
 case CONS:
  x2 = car_of(x1);
 parseBracInComment_3_5:
  switch (ptagof(x2)) {
 case ATOMIC:
 parseBracInComment_3_6:
  if (x2 != makeint(45L)) goto parseBracInComment_3_7;
  a0 = cdr_of(x1);
  execute(parseBracInComment1_3_0);
  goto parseBracInComment1_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x2,parseBracInComment_3_5);
  *reasonp++ =  x2;
  goto parseBracInComment_3_7;
  };
  goto parseBracInComment_3_7;
 case VARREF:
  deref_and_jump(x1,parseBracInComment_3_4);
  *reasonp++ =  x1;
  goto parseBracInComment_3_7;
  };
  goto parseBracInComment_3_7;
 case VARREF:
  deref_and_jump(x0,parseBracInComment_3_2);
  *reasonp++ =  x0;
  goto parseBracInComment_3_7;
  };
  goto parseBracInComment_3_7;
 case VARREF:
  deref_and_jump(a0,parseBracInComment_3_1);
  *reasonp++ =  a0;
  goto parseBracInComment_3_7;
  };
  goto parseBracInComment_3_7;
 parseBracInComment_3_7:
  otherwise(parseBracInComment_3_interrupt);
 parseBracInComment_3_8:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(parseBracInComment_3_0);
  goto parseBracInComment_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto parseBracInComment_3_interrupt;
  x0 = makesym(atom_error);
  unify_value(a2, x0);
  x1 = NILATOM;
  unify_value(a1, x1);
  proceed();
 case VARREF:
  deref_and_jump(a0,parseBracInComment_3_8);
  *reasonp++ =  a0;
  goto parseBracInComment_3_interrupt;
  };
  goto parseBracInComment_3_interrupt;
 parseBracInComment_3_ext_interrupt:
  reasonp = 0l;
 parseBracInComment_3_interrupt:
  toppred = &predicate_html_xparseBracInComment_3;
  goto interrupt_3;
 }

 parseBracInComment1_3_top: {
  q x0, x1, x2, x3, x4;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 parseBracInComment1_3_clear_reason:
  reasonp = reasons;
 parseBracInComment1_3_0:
 parseBracInComment1_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 parseBracInComment1_3_2:
  switch (ptagof(x0)) {
 case ATOMIC:
 parseBracInComment1_3_3:
  switch ((unsigned long)x0) {
 case (unsigned long) makeint(32L):
  a0 = cdr_of(a0);
  execute(parseBracInComment1_3_0);
  goto parseBracInComment1_3_ext_interrupt;
 case (unsigned long) makeint(45L):
  x1 = cdr_of(a0);
 parseBracInComment1_3_4:
  switch (ptagof(x1)) {
 case CONS:
  x2 = car_of(x1);
 parseBracInComment1_3_5:
  switch (ptagof(x2)) {
 case ATOMIC:
 parseBracInComment1_3_6:
  if (x2 != makeint(45L)) goto parseBracInComment1_3_7;
  a0 = cdr_of(x1);
  execute(parseBracInComment_3_0);
  goto parseBracInComment_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x2,parseBracInComment1_3_5);
  *reasonp++ =  x2;
  goto parseBracInComment1_3_7;
  };
  goto parseBracInComment1_3_7;
 case VARREF:
  deref_and_jump(x1,parseBracInComment1_3_4);
  *reasonp++ =  x1;
  goto parseBracInComment1_3_7;
  };
  goto parseBracInComment1_3_7;
 case (unsigned long) makeint(62L):
  allocp[0] = makesym(functor_text_1);
  allocp[1] = x2 = makeref(&allocp[1]);
  x1 = makefunctor(&allocp[0]);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = x1;
  x3 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a1, x3);
  a0 = cdr_of(a0);
  a1 = x2;
  a3 = a2;
  a2 = x4;
  execute(parseBracInText_4_0);
  goto parseBracInText_4_ext_interrupt;
  };
  goto parseBracInComment1_3_7;
 case VARREF:
  deref_and_jump(x0,parseBracInComment1_3_2);
  *reasonp++ =  x0;
  goto parseBracInComment1_3_7;
  };
  goto parseBracInComment1_3_7;
 case ATOMIC:
  if (a0 != NILATOM) goto parseBracInComment1_3_7;
  x0 = makesym(atom_error);
  unify_value(a2, x0);
  x1 = NILATOM;
  unify_value(a1, x1);
  proceed();
 case VARREF:
  deref_and_jump(a0,parseBracInComment1_3_1);
  *reasonp++ =  a0;
  goto parseBracInComment1_3_7;
  };
  goto parseBracInComment1_3_7;
 parseBracInComment1_3_7:
  otherwise(parseBracInComment1_3_interrupt);
  execute(parseBracInComment_3_0);
  goto parseBracInComment_3_ext_interrupt;
 parseBracInComment1_3_ext_interrupt:
  reasonp = 0l;
 parseBracInComment1_3_interrupt:
  toppred = &predicate_html_xparseBracInComment1_3;
  goto interrupt_3;
 }

 parseBracInTag_4_top: {
  q x0, x1, x2, x3, x4, x5;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 parseBracInTag_4_clear_reason:
  reasonp = reasons;
 parseBracInTag_4_0:
 parseBracInTag_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 parseBracInTag_4_2:
  switch (ptagof(x0)) {
 case ATOMIC:
 parseBracInTag_4_3:
  if (x0 != makeint(62L)) goto parseBracInTag_4_4;
  x1 = NILATOM;
  unify_value(a1, x1);
  allocp[0] = makesym(functor_text_1);
  allocp[1] = x3 = makeref(&allocp[1]);
  x2 = makefunctor(&allocp[0]);
  allocp[2] = x5 = makeref(&allocp[2]);
  allocp[3] = x2;
  x4 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a2, x4);
  a0 = cdr_of(a0);
  a1 = x3;
  a2 = x5;
  execute(parseBracInText_4_0);
  goto parseBracInText_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,parseBracInTag_4_2);
  *reasonp++ =  x0;
  goto parseBracInTag_4_4;
  };
  goto parseBracInTag_4_4;
 case VARREF:
  deref_and_jump(a0,parseBracInTag_4_1);
  *reasonp++ =  a0;
  goto parseBracInTag_4_4;
  };
  goto parseBracInTag_4_4;
 parseBracInTag_4_4:
  otherwise(parseBracInTag_4_interrupt);
 parseBracInTag_4_5:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(parseBracInTag_4_0);
  goto parseBracInTag_4_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto parseBracInTag_4_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  x1 = NILATOM;
  unify_value(a2, x1);
  x2 = makesym(atom_error);
  unify_value(a3, x2);
  proceed();
 case VARREF:
  deref_and_jump(a0,parseBracInTag_4_5);
  *reasonp++ =  a0;
  goto parseBracInTag_4_interrupt;
  };
  goto parseBracInTag_4_interrupt;
 parseBracInTag_4_ext_interrupt:
  reasonp = 0l;
 parseBracInTag_4_interrupt:
  toppred = &predicate_html_xparseBracInTag_4;
  goto interrupt_4;
 }

 rmNullElm_2_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  qp = qp->next;
 rmNullElm_2_clear_reason:
  reasonp = reasons;
 rmNullElm_2_0:
 rmNullElm_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 rmNullElm_2_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_text_1:
  x1 = arg(x0, 0);
 rmNullElm_2_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto rmNullElm_2_5;
  a0 = cdr_of(a0);
  execute(rmNullElm_2_0);
  goto rmNullElm_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,rmNullElm_2_3);
  *reasonp++ =  x1;
  goto rmNullElm_2_5;
  };
  goto rmNullElm_2_5;
 case functor_tag_1:
  x1 = arg(x0, 0);
 rmNullElm_2_4:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto rmNullElm_2_5;
  a0 = cdr_of(a0);
  execute(rmNullElm_2_0);
  goto rmNullElm_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,rmNullElm_2_4);
  *reasonp++ =  x1;
  goto rmNullElm_2_5;
  };
  goto rmNullElm_2_5;
  };
  goto rmNullElm_2_5;
 case VARREF:
  deref_and_jump(x0,rmNullElm_2_2);
  *reasonp++ =  x0;
  goto rmNullElm_2_5;
  };
  goto rmNullElm_2_5;
 case ATOMIC:
  if (a0 != NILATOM) goto rmNullElm_2_5;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,rmNullElm_2_1);
  *reasonp++ =  a0;
  goto rmNullElm_2_5;
  };
  goto rmNullElm_2_5;
 rmNullElm_2_5:
  otherwise(rmNullElm_2_interrupt);
 rmNullElm_2_6:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(rmNullElm_2_0);
  goto rmNullElm_2_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,rmNullElm_2_6);
  *reasonp++ =  a0;
  goto rmNullElm_2_interrupt;
  };
  goto rmNullElm_2_interrupt;
 rmNullElm_2_ext_interrupt:
  reasonp = 0l;
 rmNullElm_2_interrupt:
  goto interrupt_2;
 }

 checkTag_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16;
  a1 = qp->args[1];
  qp = qp->next;
 checkTag_2_clear_reason:
  reasonp = reasons;
 checkTag_2_0:
 checkTag_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 checkTag_2_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_tag_1)) goto checkTag_2_27;
  x1 = arg(x0, 0);
 checkTag_2_3:
  switch (ptagof(x1)) {
 case CONS:
  x2 = car_of(x1);
 checkTag_2_4:
  switch (ptagof(x2)) {
 case ATOMIC:
 checkTag_2_5:
  if (x2 != makeint(33L)) goto checkTag_2_27;
  x3 = cdr_of(x1);
 checkTag_2_6:
  switch (ptagof(x3)) {
 case CONS:
  x4 = car_of(x3);
 checkTag_2_7:
  switch (ptagof(x4)) {
 case ATOMIC:
 checkTag_2_8:
  if (x4 != makeint(68L)) goto checkTag_2_27;
  x5 = cdr_of(x3);
 checkTag_2_9:
  switch (ptagof(x5)) {
 case CONS:
  x6 = car_of(x5);
 checkTag_2_10:
  switch (ptagof(x6)) {
 case ATOMIC:
 checkTag_2_11:
  if (x6 != makeint(79L)) goto checkTag_2_27;
  x7 = cdr_of(x5);
 checkTag_2_12:
  switch (ptagof(x7)) {
 case CONS:
  x8 = car_of(x7);
 checkTag_2_13:
  switch (ptagof(x8)) {
 case ATOMIC:
 checkTag_2_14:
  if (x8 != makeint(67L)) goto checkTag_2_27;
  x9 = cdr_of(x7);
 checkTag_2_15:
  switch (ptagof(x9)) {
 case CONS:
  x10 = car_of(x9);
 checkTag_2_16:
  switch (ptagof(x10)) {
 case ATOMIC:
 checkTag_2_17:
  if (x10 != makeint(84L)) goto checkTag_2_27;
  x11 = cdr_of(x9);
 checkTag_2_18:
  switch (ptagof(x11)) {
 case CONS:
  x12 = car_of(x11);
 checkTag_2_19:
  switch (ptagof(x12)) {
 case ATOMIC:
 checkTag_2_20:
  if (x12 != makeint(89L)) goto checkTag_2_27;
  x13 = cdr_of(x11);
 checkTag_2_21:
  switch (ptagof(x13)) {
 case CONS:
  x14 = car_of(x13);
 checkTag_2_22:
  switch (ptagof(x14)) {
 case ATOMIC:
 checkTag_2_23:
  if (x14 != makeint(80L)) goto checkTag_2_27;
  x15 = cdr_of(x13);
 checkTag_2_24:
  switch (ptagof(x15)) {
 case CONS:
  x16 = car_of(x15);
 checkTag_2_25:
  switch (ptagof(x16)) {
 case ATOMIC:
 checkTag_2_26:
  if (x16 != makeint(69L)) goto checkTag_2_27;
  a0 = cdr_of(a0);
  execute(checkTag_2_0);
  goto checkTag_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x16,checkTag_2_25);
  *reasonp++ =  x16;
  goto checkTag_2_27;
  };
  goto checkTag_2_27;
 case VARREF:
  deref_and_jump(x15,checkTag_2_24);
  *reasonp++ =  x15;
  goto checkTag_2_27;
  };
  goto checkTag_2_27;
 case VARREF:
  deref_and_jump(x14,checkTag_2_22);
  *reasonp++ =  x14;
  goto checkTag_2_27;
  };
  goto checkTag_2_27;
 case VARREF:
  deref_and_jump(x13,checkTag_2_21);
  *reasonp++ =  x13;
  goto checkTag_2_27;
  };
  goto checkTag_2_27;
 case VARREF:
  deref_and_jump(x12,checkTag_2_19);
  *reasonp++ =  x12;
  goto checkTag_2_27;
  };
  goto checkTag_2_27;
 case VARREF:
  deref_and_jump(x11,checkTag_2_18);
  *reasonp++ =  x11;
  goto checkTag_2_27;
  };
  goto checkTag_2_27;
 case VARREF:
  deref_and_jump(x10,checkTag_2_16);
  *reasonp++ =  x10;
  goto checkTag_2_27;
  };
  goto checkTag_2_27;
 case VARREF:
  deref_and_jump(x9,checkTag_2_15);
  *reasonp++ =  x9;
  goto checkTag_2_27;
  };
  goto checkTag_2_27;
 case VARREF:
  deref_and_jump(x8,checkTag_2_13);
  *reasonp++ =  x8;
  goto checkTag_2_27;
  };
  goto checkTag_2_27;
 case VARREF:
  deref_and_jump(x7,checkTag_2_12);
  *reasonp++ =  x7;
  goto checkTag_2_27;
  };
  goto checkTag_2_27;
 case VARREF:
  deref_and_jump(x6,checkTag_2_10);
  *reasonp++ =  x6;
  goto checkTag_2_27;
  };
  goto checkTag_2_27;
 case VARREF:
  deref_and_jump(x5,checkTag_2_9);
  *reasonp++ =  x5;
  goto checkTag_2_27;
  };
  goto checkTag_2_27;
 case VARREF:
  deref_and_jump(x4,checkTag_2_7);
  *reasonp++ =  x4;
  goto checkTag_2_27;
  };
  goto checkTag_2_27;
 case VARREF:
  deref_and_jump(x3,checkTag_2_6);
  *reasonp++ =  x3;
  goto checkTag_2_27;
  };
  goto checkTag_2_27;
 case VARREF:
  deref_and_jump(x2,checkTag_2_4);
  *reasonp++ =  x2;
  goto checkTag_2_27;
  };
  goto checkTag_2_27;
 case VARREF:
  deref_and_jump(x1,checkTag_2_3);
  *reasonp++ =  x1;
  goto checkTag_2_27;
  };
  goto checkTag_2_27;
 case VARREF:
  deref_and_jump(x0,checkTag_2_2);
  *reasonp++ =  x0;
  goto checkTag_2_27;
  };
  goto checkTag_2_27;
 case VARREF:
  deref_and_jump(a0,checkTag_2_1);
  *reasonp++ =  a0;
  goto checkTag_2_27;
  };
  goto checkTag_2_27;
 checkTag_2_27:
  otherwise(checkTag_2_interrupt);
 checkTag_2_28:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 checkTag_2_29:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_text_1:
  allocp[0] = makesym(functor_text_1);
  x2 = arg(x0, 0);
  allocp[1] = x2;
  x1 = makefunctor(&allocp[0]);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = x1;
  x3 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a1, x3);
  a0 = cdr_of(a0);
  a1 = x4;
  execute(checkTag_2_0);
  goto checkTag_2_ext_interrupt;
 case functor_tag_1:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xcheckTag_2);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = x2;
  allocp[5] = x4 = makeref(&allocp[5]);
  x3 = makecons(&allocp[4]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  unify_value(a1, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xnormTag_2);
  allocp[2] = x5 = makeref(&allocp[2]);
  allocp[3] = x4;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_html_xpartNameAttr_2);
  allocp[6] = x6 = makeref(&allocp[6]);
  allocp[7] = x5;
  allocp[8] = (q)(struct goalrec*)&allocp[4];
  allocp[9] = (q)(&predicate_util_xcrlfToSP_2);
  x7 = arg(x0, 0);
  allocp[10] = x7;
  allocp[11] = x6;
  qp = (struct goalrec*)&allocp[8];
  allocp += 12;
  proceed();
  };
  goto checkTag_2_interrupt;
 case VARREF:
  deref_and_jump(x0,checkTag_2_29);
  *reasonp++ =  x0;
  goto checkTag_2_interrupt;
  };
  goto checkTag_2_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto checkTag_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,checkTag_2_28);
  *reasonp++ =  a0;
  goto checkTag_2_interrupt;
  };
  goto checkTag_2_interrupt;
 checkTag_2_ext_interrupt:
  reasonp = 0l;
 checkTag_2_interrupt:
  goto interrupt_2;
 }

 partNameAttr_2_top: {
  q x0, x1, x2, x3, x4;
  a1 = qp->args[1];
  qp = qp->next;
 partNameAttr_2_clear_reason:
  reasonp = reasons;
 partNameAttr_2_0:
  allocp[0] = makesym(functor_name_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = x0;
  x2 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a1, x2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xrmNullAttr_2);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = x3;
  a1 = x1;
  a2 = x4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  execute(partNameAttr1_3_0);
  goto partNameAttr1_3_ext_interrupt;
 partNameAttr_2_ext_interrupt:
  reasonp = 0l;
 partNameAttr_2_interrupt:
  goto interrupt_2;
 }

 partNameAttr1_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 partNameAttr1_3_clear_reason:
  reasonp = reasons;
 partNameAttr1_3_0:
 partNameAttr1_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 partNameAttr1_3_2:
  switch (ptagof(x0)) {
 case ATOMIC:
 partNameAttr1_3_3:
  if (x0 != makeint(32L)) goto partNameAttr1_3_4;
  x1 = NILATOM;
  unify_value(a1, x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xpartAttr_4);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = x5 = makeref(&allocp[5]);
  allocp[6] = makesym(functor_attr_2);
  allocp[7] = x3;
  allocp[8] = x4;
  x6 = makefunctor(&allocp[6]);
  allocp[9] = x5;
  allocp[10] = x6;
  x7 = makecons(&allocp[9]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 11;
  unify_value(a2, x7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_util_xskipSP_2);
  x8 = cdr_of(a0);
  allocp[2] = x8;
  allocp[3] = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  proceed();
 case VARREF:
  deref_and_jump(x0,partNameAttr1_3_2);
  *reasonp++ =  x0;
  goto partNameAttr1_3_4;
  };
  goto partNameAttr1_3_4;
 case VARREF:
  deref_and_jump(a0,partNameAttr1_3_1);
  *reasonp++ =  a0;
  goto partNameAttr1_3_4;
  };
  goto partNameAttr1_3_4;
 partNameAttr1_3_4:
  otherwise(partNameAttr1_3_interrupt);
 partNameAttr1_3_5:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(partNameAttr1_3_0);
  goto partNameAttr1_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto partNameAttr1_3_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  x1 = NILATOM;
  unify_value(a2, x1);
  proceed();
 case VARREF:
  deref_and_jump(a0,partNameAttr1_3_5);
  *reasonp++ =  a0;
  goto partNameAttr1_3_interrupt;
  };
  goto partNameAttr1_3_interrupt;
 partNameAttr1_3_ext_interrupt:
  reasonp = 0l;
 partNameAttr1_3_interrupt:
  toppred = &predicate_html_xpartNameAttr1_3;
  goto interrupt_3;
 }

 partAttr_4_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 partAttr_4_clear_reason:
  reasonp = reasons;
 partAttr_4_0:
 partAttr_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 partAttr_4_2:
  switch (ptagof(x0)) {
 case ATOMIC:
 partAttr_4_3:
  switch ((unsigned long)x0) {
 case (unsigned long) makeint(32L):
  x1 = NILATOM;
  unify_value(a1, x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xpartAttr1_3);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = a2;
  allocp[4] = a3;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_util_xskipSP_2);
  x3 = cdr_of(a0);
  allocp[7] = x3;
  allocp[8] = x2;
  qp = (struct goalrec*)&allocp[5];
  allocp += 9;
  proceed();
 case (unsigned long) makeint(61L):
  x1 = NILATOM;
  unify_value(a1, x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xpartAttr2_3);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = a2;
  allocp[4] = a3;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_util_xskipSP_2);
  x3 = cdr_of(a0);
  allocp[7] = x3;
  allocp[8] = x2;
  qp = (struct goalrec*)&allocp[5];
  allocp += 9;
  proceed();
  };
  goto partAttr_4_4;
 case VARREF:
  deref_and_jump(x0,partAttr_4_2);
  *reasonp++ =  x0;
  goto partAttr_4_4;
  };
  goto partAttr_4_4;
 case VARREF:
  deref_and_jump(a0,partAttr_4_1);
  *reasonp++ =  a0;
  goto partAttr_4_4;
  };
  goto partAttr_4_4;
 partAttr_4_4:
  otherwise(partAttr_4_interrupt);
 partAttr_4_5:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(partAttr_4_0);
  goto partAttr_4_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto partAttr_4_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  x1 = NILATOM;
  unify_value(a2, x1);
  x2 = NILATOM;
  unify_value(a3, x2);
  proceed();
 case VARREF:
  deref_and_jump(a0,partAttr_4_5);
  *reasonp++ =  a0;
  goto partAttr_4_interrupt;
  };
  goto partAttr_4_interrupt;
 partAttr_4_ext_interrupt:
  reasonp = 0l;
 partAttr_4_interrupt:
  toppred = &predicate_html_xpartAttr_4;
  goto interrupt_4;
 }

 partAttr1_3_top: {
  q x0, x1, x2, x3, x4, x5;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 partAttr1_3_clear_reason:
  reasonp = reasons;
 partAttr1_3_0:
 partAttr1_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 partAttr1_3_2:
  switch (ptagof(x0)) {
 case ATOMIC:
 partAttr1_3_3:
  if (x0 != makeint(61L)) goto partAttr1_3_4;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xpartAttr2_3);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_util_xskipSP_2);
  x2 = cdr_of(a0);
  allocp[7] = x2;
  allocp[8] = x1;
  qp = (struct goalrec*)&allocp[5];
  allocp += 9;
  proceed();
 case VARREF:
  deref_and_jump(x0,partAttr1_3_2);
  *reasonp++ =  x0;
  goto partAttr1_3_4;
  };
  goto partAttr1_3_4;
 case VARREF:
  deref_and_jump(a0,partAttr1_3_1);
  *reasonp++ =  a0;
  goto partAttr1_3_4;
  };
  goto partAttr1_3_4;
 partAttr1_3_4:
  otherwise(partAttr1_3_interrupt);
  x0 = NILATOM;
  unify_value(a1, x0);
  allocp[0] = makesym(functor_attr_2);
  allocp[1] = x2 = makeref(&allocp[1]);
  allocp[2] = x3 = makeref(&allocp[2]);
  x1 = makefunctor(&allocp[0]);
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = x1;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a2, x4);
  a1 = x2;
  a2 = x3;
  a3 = x5;
  execute(partAttr_4_0);
  goto partAttr_4_ext_interrupt;
 partAttr1_3_ext_interrupt:
  reasonp = 0l;
 partAttr1_3_interrupt:
  goto interrupt_3;
 }

 partAttr2_3_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 partAttr2_3_clear_reason:
  reasonp = reasons;
 partAttr2_3_0:
 partAttr2_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 partAttr2_3_2:
  switch (ptagof(x0)) {
 case ATOMIC:
 partAttr2_3_3:
  switch ((unsigned long)x0) {
 case (unsigned long) makeint(34L):
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = makeint(34L);
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x1);
  a0 = cdr_of(a0);
  a1 = x2;
  execute(partAttr2DQ_3_0);
  goto partAttr2DQ_3_ext_interrupt;
 case (unsigned long) makeint(39L):
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = makeint(39L);
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x1);
  a0 = cdr_of(a0);
  a1 = x2;
  execute(partAttr2SQ_3_0);
  goto partAttr2SQ_3_ext_interrupt;
  };
  goto partAttr2_3_4;
 case VARREF:
  deref_and_jump(x0,partAttr2_3_2);
  *reasonp++ =  x0;
  goto partAttr2_3_4;
  };
  goto partAttr2_3_4;
 case VARREF:
  deref_and_jump(a0,partAttr2_3_1);
  *reasonp++ =  a0;
  goto partAttr2_3_4;
  };
  goto partAttr2_3_4;
 partAttr2_3_4:
  otherwise(partAttr2_3_interrupt);
 partAttr2_3_5:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(partAttr2NT_3_0);
  goto partAttr2NT_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto partAttr2_3_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  x1 = NILATOM;
  unify_value(a2, x1);
  proceed();
 case VARREF:
  deref_and_jump(a0,partAttr2_3_5);
  *reasonp++ =  a0;
  goto partAttr2_3_interrupt;
  };
  goto partAttr2_3_interrupt;
 partAttr2_3_ext_interrupt:
  reasonp = 0l;
 partAttr2_3_interrupt:
  goto interrupt_3;
 }

 partAttr2DQ_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 partAttr2DQ_3_clear_reason:
  reasonp = reasons;
 partAttr2DQ_3_0:
 partAttr2DQ_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 partAttr2DQ_3_2:
  switch (ptagof(x0)) {
 case ATOMIC:
 partAttr2DQ_3_3:
  if (x0 != makeint(34L)) goto partAttr2DQ_3_4;
  x1 = makecons(cons_const_1);
  unify_value(a1, x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xpartAttr_4);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = x5 = makeref(&allocp[5]);
  allocp[6] = makesym(functor_attr_2);
  allocp[7] = x3;
  allocp[8] = x4;
  x6 = makefunctor(&allocp[6]);
  allocp[9] = x5;
  allocp[10] = x6;
  x7 = makecons(&allocp[9]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 11;
  unify_value(a2, x7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_util_xskipSP_2);
  x8 = cdr_of(a0);
  allocp[2] = x8;
  allocp[3] = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  proceed();
 case VARREF:
  deref_and_jump(x0,partAttr2DQ_3_2);
  *reasonp++ =  x0;
  goto partAttr2DQ_3_4;
  };
  goto partAttr2DQ_3_4;
 case VARREF:
  deref_and_jump(a0,partAttr2DQ_3_1);
  *reasonp++ =  a0;
  goto partAttr2DQ_3_4;
  };
  goto partAttr2DQ_3_4;
 partAttr2DQ_3_4:
  otherwise(partAttr2DQ_3_interrupt);
 partAttr2DQ_3_5:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(partAttr2DQ_3_0);
  goto partAttr2DQ_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto partAttr2DQ_3_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  x1 = NILATOM;
  unify_value(a2, x1);
  proceed();
 case VARREF:
  deref_and_jump(a0,partAttr2DQ_3_5);
  *reasonp++ =  a0;
  goto partAttr2DQ_3_interrupt;
  };
  goto partAttr2DQ_3_interrupt;
 partAttr2DQ_3_ext_interrupt:
  reasonp = 0l;
 partAttr2DQ_3_interrupt:
  toppred = &predicate_html_xpartAttr2DQ_3;
  goto interrupt_3;
 }

 partAttr2SQ_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 partAttr2SQ_3_clear_reason:
  reasonp = reasons;
 partAttr2SQ_3_0:
 partAttr2SQ_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 partAttr2SQ_3_2:
  switch (ptagof(x0)) {
 case ATOMIC:
 partAttr2SQ_3_3:
  if (x0 != makeint(39L)) goto partAttr2SQ_3_4;
  x1 = makecons(cons_const_2);
  unify_value(a1, x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xpartAttr_4);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = x5 = makeref(&allocp[5]);
  allocp[6] = makesym(functor_attr_2);
  allocp[7] = x3;
  allocp[8] = x4;
  x6 = makefunctor(&allocp[6]);
  allocp[9] = x5;
  allocp[10] = x6;
  x7 = makecons(&allocp[9]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 11;
  unify_value(a2, x7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_util_xskipSP_2);
  x8 = cdr_of(a0);
  allocp[2] = x8;
  allocp[3] = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  proceed();
 case VARREF:
  deref_and_jump(x0,partAttr2SQ_3_2);
  *reasonp++ =  x0;
  goto partAttr2SQ_3_4;
  };
  goto partAttr2SQ_3_4;
 case VARREF:
  deref_and_jump(a0,partAttr2SQ_3_1);
  *reasonp++ =  a0;
  goto partAttr2SQ_3_4;
  };
  goto partAttr2SQ_3_4;
 partAttr2SQ_3_4:
  otherwise(partAttr2SQ_3_interrupt);
 partAttr2SQ_3_5:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(partAttr2SQ_3_0);
  goto partAttr2SQ_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto partAttr2SQ_3_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  x1 = NILATOM;
  unify_value(a2, x1);
  proceed();
 case VARREF:
  deref_and_jump(a0,partAttr2SQ_3_5);
  *reasonp++ =  a0;
  goto partAttr2SQ_3_interrupt;
  };
  goto partAttr2SQ_3_interrupt;
 partAttr2SQ_3_ext_interrupt:
  reasonp = 0l;
 partAttr2SQ_3_interrupt:
  toppred = &predicate_html_xpartAttr2SQ_3;
  goto interrupt_3;
 }

 partAttr2NT_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 partAttr2NT_3_clear_reason:
  reasonp = reasons;
 partAttr2NT_3_0:
 partAttr2NT_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 partAttr2NT_3_2:
  switch (ptagof(x0)) {
 case ATOMIC:
 partAttr2NT_3_3:
  if (x0 != makeint(32L)) goto partAttr2NT_3_4;
  x1 = NILATOM;
  unify_value(a1, x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xpartAttr_4);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = x5 = makeref(&allocp[5]);
  allocp[6] = makesym(functor_attr_2);
  allocp[7] = x3;
  allocp[8] = x4;
  x6 = makefunctor(&allocp[6]);
  allocp[9] = x5;
  allocp[10] = x6;
  x7 = makecons(&allocp[9]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 11;
  unify_value(a2, x7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_util_xskipSP_2);
  x8 = cdr_of(a0);
  allocp[2] = x8;
  allocp[3] = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  proceed();
 case VARREF:
  deref_and_jump(x0,partAttr2NT_3_2);
  *reasonp++ =  x0;
  goto partAttr2NT_3_4;
  };
  goto partAttr2NT_3_4;
 case VARREF:
  deref_and_jump(a0,partAttr2NT_3_1);
  *reasonp++ =  a0;
  goto partAttr2NT_3_4;
  };
  goto partAttr2NT_3_4;
 partAttr2NT_3_4:
  otherwise(partAttr2NT_3_interrupt);
 partAttr2NT_3_5:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(partAttr2NT_3_0);
  goto partAttr2NT_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto partAttr2NT_3_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  x1 = NILATOM;
  unify_value(a2, x1);
  proceed();
 case VARREF:
  deref_and_jump(a0,partAttr2NT_3_5);
  *reasonp++ =  a0;
  goto partAttr2NT_3_interrupt;
  };
  goto partAttr2NT_3_interrupt;
 partAttr2NT_3_ext_interrupt:
  reasonp = 0l;
 partAttr2NT_3_interrupt:
  toppred = &predicate_html_xpartAttr2NT_3;
  goto interrupt_3;
 }

 rmNullAttr_2_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  qp = qp->next;
 rmNullAttr_2_clear_reason:
  reasonp = reasons;
 rmNullAttr_2_0:
 rmNullAttr_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 rmNullAttr_2_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_attr_2)) goto rmNullAttr_2_4;
  x1 = arg(x0, 0);
 rmNullAttr_2_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto rmNullAttr_2_4;
  a0 = cdr_of(a0);
  execute(rmNullAttr_2_0);
  goto rmNullAttr_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,rmNullAttr_2_3);
  *reasonp++ =  x1;
  goto rmNullAttr_2_4;
  };
  goto rmNullAttr_2_4;
 case VARREF:
  deref_and_jump(x0,rmNullAttr_2_2);
  *reasonp++ =  x0;
  goto rmNullAttr_2_4;
  };
  goto rmNullAttr_2_4;
 case VARREF:
  deref_and_jump(a0,rmNullAttr_2_1);
  *reasonp++ =  a0;
  goto rmNullAttr_2_4;
  };
  goto rmNullAttr_2_4;
 rmNullAttr_2_4:
  otherwise(rmNullAttr_2_interrupt);
 rmNullAttr_2_5:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(rmNullAttr_2_0);
  goto rmNullAttr_2_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto rmNullAttr_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,rmNullAttr_2_5);
  *reasonp++ =  a0;
  goto rmNullAttr_2_interrupt;
  };
  goto rmNullAttr_2_interrupt;
 rmNullAttr_2_ext_interrupt:
  reasonp = 0l;
 rmNullAttr_2_interrupt:
  goto interrupt_2;
 }

 normTag_2_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a1 = qp->args[1];
  qp = qp->next;
 normTag_2_clear_reason:
  reasonp = reasons;
 normTag_2_0:
 normTag_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 normTag_2_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_name_1)) goto normTag_2_6;
  x1 = arg(x0, 0);
 normTag_2_3:
  switch (ptagof(x1)) {
 case CONS:
  x2 = car_of(x1);
 normTag_2_4:
  switch (ptagof(x2)) {
 case ATOMIC:
 normTag_2_5:
  if (x2 != makeint(47L)) goto normTag_2_6;
  allocp[0] = makesym(functor_end_1);
  allocp[1] = x4 = makeref(&allocp[1]);
  x3 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_util_xlstToAtom_2);
  allocp[2] = x5 = makeref(&allocp[2]);
  allocp[3] = x4;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_util_xtoLower_2);
  x6 = cdr_of(x1);
  allocp[6] = x6;
  allocp[7] = x5;
  qp = (struct goalrec*)&allocp[4];
  allocp += 8;
  proceed();
 case VARREF:
  deref_and_jump(x2,normTag_2_4);
  *reasonp++ =  x2;
  goto normTag_2_6;
  };
  goto normTag_2_6;
 case VARREF:
  deref_and_jump(x1,normTag_2_3);
  *reasonp++ =  x1;
  goto normTag_2_6;
  };
  goto normTag_2_6;
 case VARREF:
  deref_and_jump(x0,normTag_2_2);
  *reasonp++ =  x0;
  goto normTag_2_6;
  };
  goto normTag_2_6;
 case VARREF:
  deref_and_jump(a0,normTag_2_1);
  *reasonp++ =  a0;
  goto normTag_2_6;
  };
  goto normTag_2_6;
 normTag_2_6:
  otherwise(normTag_2_interrupt);
 normTag_2_7:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 normTag_2_8:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_name_1)) goto normTag_2_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xnormAttr_2);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = makesym(functor_begin_2);
  allocp[5] = x4 = makeref(&allocp[5]);
  allocp[6] = x2;
  x3 = makefunctor(&allocp[4]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  unify_value(a1, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_util_xlstToAtom_2);
  allocp[2] = x5 = makeref(&allocp[2]);
  allocp[3] = x4;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_util_xtoLower_2);
  x6 = arg(x0, 0);
  allocp[6] = x6;
  allocp[7] = x5;
  qp = (struct goalrec*)&allocp[4];
  allocp += 8;
  proceed();
 case VARREF:
  deref_and_jump(x0,normTag_2_8);
  *reasonp++ =  x0;
  goto normTag_2_interrupt;
  };
  goto normTag_2_interrupt;
 case VARREF:
  deref_and_jump(a0,normTag_2_7);
  *reasonp++ =  a0;
  goto normTag_2_interrupt;
  };
  goto normTag_2_interrupt;
 normTag_2_ext_interrupt:
  reasonp = 0l;
 normTag_2_interrupt:
  goto interrupt_2;
 }

 normAttr_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14;
  a1 = qp->args[1];
  qp = qp->next;
 normAttr_2_clear_reason:
  reasonp = reasons;
 normAttr_2_0:
 normAttr_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 normAttr_2_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_attr_2)) goto normAttr_2_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xnormAttr_2);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = x2;
  allocp[5] = x4 = makeref(&allocp[5]);
  x3 = makecons(&allocp[4]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  unify_value(a1, x3);
  allocp[0] = NILATOM;
  allocp[1] = x6 = makeref(&allocp[1]);
  x5 = makecons(&allocp[0]);
  allocp[2] = x5;
  allocp[3] = x8 = makeref(&allocp[3]);
  x7 = makecons(&allocp[2]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[6] = x4;
  allocp[7] = x7;
  allocp[8] = x9 = makeref(&allocp[8]);
  generic_arg[0] = x9;
  x10 = makeint(8L);
  generic_arg[1] = x10;
  qp = (struct goalrec*)&allocp[4];
  new_generic(string_g_new, 2, x11, 9);
  unify(x6, x11);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xnormAttrValue_2);
  x12 = arg(x0, 1);
  allocp[2] = x12;
  allocp[3] = x9;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_util_xlstToAtom_2);
  allocp[6] = x13 = makeref(&allocp[6]);
  allocp[7] = x8;
  allocp[8] = (q)(struct goalrec*)&allocp[4];
  allocp[9] = (q)(&predicate_util_xtoLower_2);
  x14 = arg(x0, 0);
  allocp[10] = x14;
  allocp[11] = x13;
  qp = (struct goalrec*)&allocp[8];
  allocp += 12;
  proceed();
 case VARREF:
  deref_and_jump(x0,normAttr_2_2);
  *reasonp++ =  x0;
  goto normAttr_2_interrupt;
  };
  goto normAttr_2_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto normAttr_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,normAttr_2_1);
  *reasonp++ =  a0;
  goto normAttr_2_interrupt;
  };
  goto normAttr_2_interrupt;
 normAttr_2_ext_interrupt:
  reasonp = 0l;
 normAttr_2_interrupt:
  goto interrupt_2;
 }

 normAttrValue_2_top: {
  q x0, x1;
  a1 = qp->args[1];
  qp = qp->next;
 normAttrValue_2_clear_reason:
  reasonp = reasons;
 normAttrValue_2_0:
 normAttrValue_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 normAttrValue_2_2:
  switch (ptagof(x0)) {
 case ATOMIC:
 normAttrValue_2_3:
  switch ((unsigned long)x0) {
 case (unsigned long) makeint(34L):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xunescape_2);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  a0 = cdr_of(a0);
  a1 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  execute(normAttrValueDQ_2_0);
  goto normAttrValueDQ_2_ext_interrupt;
 case (unsigned long) makeint(39L):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xunescape_2);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  a0 = cdr_of(a0);
  a1 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  execute(normAttrValueSQ_2_0);
  goto normAttrValueSQ_2_ext_interrupt;
  };
  goto normAttrValue_2_4;
 case VARREF:
  deref_and_jump(x0,normAttrValue_2_2);
  *reasonp++ =  x0;
  goto normAttrValue_2_4;
  };
  goto normAttrValue_2_4;
 case VARREF:
  deref_and_jump(a0,normAttrValue_2_1);
  *reasonp++ =  a0;
  goto normAttrValue_2_4;
  };
  goto normAttrValue_2_4;
 normAttrValue_2_4:
  otherwise(normAttrValue_2_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_util_xtoLower_2);
  allocp[2] = a0;
  allocp[3] = a1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  proceed();
 normAttrValue_2_ext_interrupt:
  reasonp = 0l;
 normAttrValue_2_interrupt:
  goto interrupt_2;
 }

 normAttrValueDQ_2_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  qp = qp->next;
 normAttrValueDQ_2_clear_reason:
  reasonp = reasons;
 normAttrValueDQ_2_0:
 normAttrValueDQ_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 normAttrValueDQ_2_2:
  switch (ptagof(x0)) {
 case ATOMIC:
 normAttrValueDQ_2_3:
  if (x0 != makeint(34L)) goto normAttrValueDQ_2_5;
  x1 = cdr_of(a0);
 normAttrValueDQ_2_4:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto normAttrValueDQ_2_5;
  x2 = NILATOM;
  unify_value(a1, x2);
  proceed();
 case VARREF:
  deref_and_jump(x1,normAttrValueDQ_2_4);
  *reasonp++ =  x1;
  goto normAttrValueDQ_2_5;
  };
  goto normAttrValueDQ_2_5;
 case VARREF:
  deref_and_jump(x0,normAttrValueDQ_2_2);
  *reasonp++ =  x0;
  goto normAttrValueDQ_2_5;
  };
  goto normAttrValueDQ_2_5;
 case VARREF:
  deref_and_jump(a0,normAttrValueDQ_2_1);
  *reasonp++ =  a0;
  goto normAttrValueDQ_2_5;
  };
  goto normAttrValueDQ_2_5;
 normAttrValueDQ_2_5:
  otherwise(normAttrValueDQ_2_interrupt);
 normAttrValueDQ_2_6:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(normAttrValueDQ_2_0);
  goto normAttrValueDQ_2_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto normAttrValueDQ_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,normAttrValueDQ_2_6);
  *reasonp++ =  a0;
  goto normAttrValueDQ_2_interrupt;
  };
  goto normAttrValueDQ_2_interrupt;
 normAttrValueDQ_2_ext_interrupt:
  reasonp = 0l;
 normAttrValueDQ_2_interrupt:
  toppred = &predicate_html_xnormAttrValueDQ_2;
  goto interrupt_2;
 }

 normAttrValueSQ_2_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  qp = qp->next;
 normAttrValueSQ_2_clear_reason:
  reasonp = reasons;
 normAttrValueSQ_2_0:
 normAttrValueSQ_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 normAttrValueSQ_2_2:
  switch (ptagof(x0)) {
 case ATOMIC:
 normAttrValueSQ_2_3:
  if (x0 != makeint(39L)) goto normAttrValueSQ_2_5;
  x1 = cdr_of(a0);
 normAttrValueSQ_2_4:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto normAttrValueSQ_2_5;
  x2 = NILATOM;
  unify_value(a1, x2);
  proceed();
 case VARREF:
  deref_and_jump(x1,normAttrValueSQ_2_4);
  *reasonp++ =  x1;
  goto normAttrValueSQ_2_5;
  };
  goto normAttrValueSQ_2_5;
 case VARREF:
  deref_and_jump(x0,normAttrValueSQ_2_2);
  *reasonp++ =  x0;
  goto normAttrValueSQ_2_5;
  };
  goto normAttrValueSQ_2_5;
 case VARREF:
  deref_and_jump(a0,normAttrValueSQ_2_1);
  *reasonp++ =  a0;
  goto normAttrValueSQ_2_5;
  };
  goto normAttrValueSQ_2_5;
 normAttrValueSQ_2_5:
  otherwise(normAttrValueSQ_2_interrupt);
 normAttrValueSQ_2_6:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(normAttrValueSQ_2_0);
  goto normAttrValueSQ_2_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto normAttrValueSQ_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,normAttrValueSQ_2_6);
  *reasonp++ =  a0;
  goto normAttrValueSQ_2_interrupt;
  };
  goto normAttrValueSQ_2_interrupt;
 normAttrValueSQ_2_ext_interrupt:
  reasonp = 0l;
 normAttrValueSQ_2_interrupt:
  toppred = &predicate_html_xnormAttrValueSQ_2;
  goto interrupt_2;
 }

 knownTag_1_top: {
  q x0;
  qp = qp->next;
 knownTag_1_clear_reason:
  reasonp = reasons;
 knownTag_1_0:
  x0 = makecons(cons_const_57);
  unify_value(a0, x0);
  proceed();
 knownTag_1_ext_interrupt:
  reasonp = 0l;
 knownTag_1_interrupt:
  toppred = &predicate_html_xknownTag_1;
  goto interrupt_1;
 }

 noEndtag_1_top: {
  q x0;
  qp = qp->next;
 noEndtag_1_clear_reason:
  reasonp = reasons;
 noEndtag_1_0:
  x0 = makecons(cons_const_67);
  unify_value(a0, x0);
  proceed();
 noEndtag_1_ext_interrupt:
  reasonp = 0l;
 noEndtag_1_interrupt:
  toppred = &predicate_html_xnoEndtag_1;
  goto interrupt_1;
 }

 closePtag_1_top: {
  q x0;
  qp = qp->next;
 closePtag_1_clear_reason:
  reasonp = reasons;
 closePtag_1_0:
  x0 = makecons(cons_const_95);
  unify_value(a0, x0);
  proceed();
 closePtag_1_ext_interrupt:
  reasonp = 0l;
 closePtag_1_interrupt:
  toppred = &predicate_html_xclosePtag_1;
  goto interrupt_1;
 }

 parseTag_2_top: {
  a1 = qp->args[1];
  qp = qp->next;
 parseTag_2_clear_reason:
  reasonp = reasons;
 parseTag_2_0:
  a2 = a1;
  a1 = NILATOM;
  execute(parseTag_3_0);
  goto parseTag_3_ext_interrupt;
 parseTag_2_ext_interrupt:
  reasonp = 0l;
 parseTag_2_interrupt:
  goto interrupt_2;
 }

 parseTag_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 parseTag_3_clear_reason:
  reasonp = reasons;
 parseTag_3_0:
 parseTag_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 parseTag_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_text_1:
  allocp[0] = makesym(functor_text_1);
  x2 = arg(x0, 0);
  allocp[1] = x2;
  x1 = makefunctor(&allocp[0]);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = x1;
  x3 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a2, x3);
  a0 = cdr_of(a0);
  a2 = x4;
  execute(parseTag_3_0);
  goto parseTag_3_ext_interrupt;
 case functor_begin_2:
  x1 = arg(x0, 0);
 parseTag_3_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (isint(x1)) goto parseTag_3_4;
  switch (symval(x1)) {
 case symval(makesym(atom_li)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xparseTag_3);
  x2 = cdr_of(a0);
  allocp[2] = x2;
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = x6 = makeref(&allocp[5]);
  allocp[6] = x7 = makeref(&allocp[6]);
  x5 = makecons(&allocp[5]);
  allocp[7] = x1;
  allocp[8] = x6;
  x8 = create_vector(&allocp[7], 2, allocp);
  allocp[9] = x10 = makeref(&allocp[9]);
  allocp[10] = x8;
  x9 = makecons(&allocp[9]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 11;
  unify_value(x3, x9);
  allocp[0] = NILATOM;
  allocp[1] = x4;
  x11 = makecons(&allocp[0]);
  allocp[2] = x11;
  x13 = arg(x0, 1);
  allocp[3] = x13;
  x12 = makecons(&allocp[2]);
  allocp[4] = x12;
  allocp[5] = x1;
  x14 = makecons(&allocp[4]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[8] = x7;
  allocp[9] = x14;
  allocp[10] = (q)(struct goalrec*)&allocp[6];
  allocp[11] = (q)(&predicate_html_xparseTag_2F3_246_4);
  allocp[12] = x15 = makeref(&allocp[12]);
  allocp[13] = x16 = makeref(&allocp[13]);
  allocp[14] = x10;
  allocp[15] = x5;
  a0 = a1;
  a1 = a2;
  a2 = x15;
  a3 = x16;
  qp = (struct goalrec*)&allocp[10];
  allocp += 16;
  execute(parseTag_2F3_245_4_0);
  goto parseTag_2F3_245_4_ext_interrupt;
 case symval(makesym(atom_dt)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xparseTag_3);
  x2 = cdr_of(a0);
  allocp[2] = x2;
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = x6 = makeref(&allocp[5]);
  allocp[6] = x7 = makeref(&allocp[6]);
  x5 = makecons(&allocp[5]);
  allocp[7] = x1;
  allocp[8] = x6;
  x8 = create_vector(&allocp[7], 2, allocp);
  allocp[9] = x10 = makeref(&allocp[9]);
  allocp[10] = x8;
  x9 = makecons(&allocp[9]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 11;
  unify_value(x3, x9);
  allocp[0] = NILATOM;
  allocp[1] = x4;
  x11 = makecons(&allocp[0]);
  allocp[2] = x11;
  x13 = arg(x0, 1);
  allocp[3] = x13;
  x12 = makecons(&allocp[2]);
  allocp[4] = x12;
  allocp[5] = x1;
  x14 = makecons(&allocp[4]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[8] = x7;
  allocp[9] = x14;
  allocp[10] = (q)(struct goalrec*)&allocp[6];
  allocp[11] = (q)(&predicate_html_xparseTag_2F3_246_4);
  allocp[12] = x15 = makeref(&allocp[12]);
  allocp[13] = x16 = makeref(&allocp[13]);
  allocp[14] = x10;
  allocp[15] = x5;
  a0 = a1;
  a1 = a2;
  a2 = x15;
  a3 = x16;
  qp = (struct goalrec*)&allocp[10];
  allocp += 16;
  execute(parseTag_2F3_245_4_0);
  goto parseTag_2F3_245_4_ext_interrupt;
 case symval(makesym(atom_dd)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xparseTag_3);
  x2 = cdr_of(a0);
  allocp[2] = x2;
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = x6 = makeref(&allocp[5]);
  allocp[6] = x7 = makeref(&allocp[6]);
  x5 = makecons(&allocp[5]);
  allocp[7] = x1;
  allocp[8] = x6;
  x8 = create_vector(&allocp[7], 2, allocp);
  allocp[9] = x10 = makeref(&allocp[9]);
  allocp[10] = x8;
  x9 = makecons(&allocp[9]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 11;
  unify_value(x3, x9);
  allocp[0] = NILATOM;
  allocp[1] = x4;
  x11 = makecons(&allocp[0]);
  allocp[2] = x11;
  x13 = arg(x0, 1);
  allocp[3] = x13;
  x12 = makecons(&allocp[2]);
  allocp[4] = x12;
  allocp[5] = x1;
  x14 = makecons(&allocp[4]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[8] = x7;
  allocp[9] = x14;
  allocp[10] = (q)(struct goalrec*)&allocp[6];
  allocp[11] = (q)(&predicate_html_xparseTag_2F3_246_4);
  allocp[12] = x15 = makeref(&allocp[12]);
  allocp[13] = x16 = makeref(&allocp[13]);
  allocp[14] = x10;
  allocp[15] = x5;
  a0 = a1;
  a1 = a2;
  a2 = x15;
  a3 = x16;
  qp = (struct goalrec*)&allocp[10];
  allocp += 16;
  execute(parseTag_2F3_245_4_0);
  goto parseTag_2F3_245_4_ext_interrupt;
  };
  goto parseTag_3_4;
 case VARREF:
  deref_and_jump(x1,parseTag_3_3);
  *reasonp++ =  x1;
  goto parseTag_3_4;
  };
  goto parseTag_3_4;
  };
  goto parseTag_3_4;
 case VARREF:
  deref_and_jump(x0,parseTag_3_2);
  *reasonp++ =  x0;
  goto parseTag_3_4;
  };
  goto parseTag_3_4;
 case VARREF:
  deref_and_jump(a0,parseTag_3_1);
  *reasonp++ =  a0;
  goto parseTag_3_4;
  };
  goto parseTag_3_4;
 parseTag_3_4:
  otherwise(parseTag_3_interrupt);
 parseTag_3_5:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 parseTag_3_6:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_begin_2)) goto parseTag_3_7;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xparseTag_2F3_244_6);
  allocp[2] = x1 = makeref(&allocp[2]);
  x2 = arg(x0, 0);
  allocp[3] = x2;
  x3 = arg(x0, 1);
  allocp[4] = x3;
  allocp[5] = a2;
  x4 = cdr_of(a0);
  allocp[6] = x4;
  allocp[7] = a1;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_util_xisMember_3);
  allocp[10] = x2;
  allocp[11] = x5 = makeref(&allocp[11]);
  allocp[12] = x1;
  a0 = x5;
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  execute(knownTag_1_0);
  goto knownTag_1_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,parseTag_3_6);
  *reasonp++ =  x0;
  goto parseTag_3_7;
  };
  goto parseTag_3_7;
 case VARREF:
  deref_and_jump(a0,parseTag_3_5);
  *reasonp++ =  a0;
  goto parseTag_3_7;
  };
  goto parseTag_3_7;
 parseTag_3_7:
  otherwise(parseTag_3_interrupt);
 parseTag_3_8:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 parseTag_3_9:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_end_1)) goto parseTag_3_11;
  x1 = arg(x0, 0);
 parseTag_3_10:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (isint(x1)) goto parseTag_3_11;
  switch (symval(x1)) {
 case symval(makesym(atom_ul)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xparseTag_2F3_243_4);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x1;
  allocp[4] = x3 = makeref(&allocp[4]);
  x4 = cdr_of(a0);
  allocp[5] = x4;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_html_xparseTag_2F3_242_4);
  allocp[8] = x5 = makeref(&allocp[8]);
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = x2;
  allocp[11] = x3;
  a0 = a1;
  a1 = a2;
  a2 = x5;
  a3 = x6;
  qp = (struct goalrec*)&allocp[6];
  allocp += 12;
  execute(parseTag_2F3_241_4_0);
  goto parseTag_2F3_241_4_ext_interrupt;
 case symval(makesym(atom_ol)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xparseTag_2F3_243_4);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x1;
  allocp[4] = x3 = makeref(&allocp[4]);
  x4 = cdr_of(a0);
  allocp[5] = x4;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_html_xparseTag_2F3_242_4);
  allocp[8] = x5 = makeref(&allocp[8]);
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = x2;
  allocp[11] = x3;
  a0 = a1;
  a1 = a2;
  a2 = x5;
  a3 = x6;
  qp = (struct goalrec*)&allocp[6];
  allocp += 12;
  execute(parseTag_2F3_241_4_0);
  goto parseTag_2F3_241_4_ext_interrupt;
 case symval(makesym(atom_dir)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xparseTag_2F3_243_4);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x1;
  allocp[4] = x3 = makeref(&allocp[4]);
  x4 = cdr_of(a0);
  allocp[5] = x4;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_html_xparseTag_2F3_242_4);
  allocp[8] = x5 = makeref(&allocp[8]);
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = x2;
  allocp[11] = x3;
  a0 = a1;
  a1 = a2;
  a2 = x5;
  a3 = x6;
  qp = (struct goalrec*)&allocp[6];
  allocp += 12;
  execute(parseTag_2F3_241_4_0);
  goto parseTag_2F3_241_4_ext_interrupt;
 case symval(makesym(atom_menu)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xparseTag_2F3_243_4);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x1;
  allocp[4] = x3 = makeref(&allocp[4]);
  x4 = cdr_of(a0);
  allocp[5] = x4;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_html_xparseTag_2F3_242_4);
  allocp[8] = x5 = makeref(&allocp[8]);
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = x2;
  allocp[11] = x3;
  a0 = a1;
  a1 = a2;
  a2 = x5;
  a3 = x6;
  qp = (struct goalrec*)&allocp[6];
  allocp += 12;
  execute(parseTag_2F3_241_4_0);
  goto parseTag_2F3_241_4_ext_interrupt;
 case symval(makesym(atom_dl)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xparseTag_2F3_243_4);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x1;
  allocp[4] = x3 = makeref(&allocp[4]);
  x4 = cdr_of(a0);
  allocp[5] = x4;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_html_xparseTag_2F3_242_4);
  allocp[8] = x5 = makeref(&allocp[8]);
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = x2;
  allocp[11] = x3;
  a0 = a1;
  a1 = a2;
  a2 = x5;
  a3 = x6;
  qp = (struct goalrec*)&allocp[6];
  allocp += 12;
  execute(parseTag_2F3_241_4_0);
  goto parseTag_2F3_241_4_ext_interrupt;
  };
  goto parseTag_3_11;
 case VARREF:
  deref_and_jump(x1,parseTag_3_10);
  *reasonp++ =  x1;
  goto parseTag_3_11;
  };
  goto parseTag_3_11;
 case VARREF:
  deref_and_jump(x0,parseTag_3_9);
  *reasonp++ =  x0;
  goto parseTag_3_11;
  };
  goto parseTag_3_11;
 case VARREF:
  deref_and_jump(a0,parseTag_3_8);
  *reasonp++ =  a0;
  goto parseTag_3_11;
  };
  goto parseTag_3_11;
 parseTag_3_11:
  otherwise(parseTag_3_interrupt);
 parseTag_3_12:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 parseTag_3_13:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_end_1)) goto parseTag_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xparseTag_2F3_240_6);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = x2 = makeref(&allocp[3]);
  x3 = cdr_of(a0);
  allocp[4] = x3;
  allocp[5] = a1;
  allocp[6] = a2;
  x4 = arg(x0, 0);
  allocp[7] = x4;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_util_xisMember_3);
  allocp[10] = x4;
  allocp[11] = x5 = makeref(&allocp[11]);
  allocp[12] = x2;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_html_xnoEndtag_1);
  allocp[15] = x5;
  allocp[16] = (q)(struct goalrec*)&allocp[13];
  allocp[17] = (q)(&predicate_util_xisMember_3);
  allocp[18] = x4;
  allocp[19] = x6 = makeref(&allocp[19]);
  allocp[20] = x1;
  a0 = x6;
  qp = (struct goalrec*)&allocp[16];
  allocp += 21;
  execute(knownTag_1_0);
  goto knownTag_1_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,parseTag_3_13);
  *reasonp++ =  x0;
  goto parseTag_3_interrupt;
  };
  goto parseTag_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto parseTag_3_interrupt;
 parseTag_3_14:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 parseTag_3_15:
  switch (ptagof(x0)) {
 case FUNCTOR:
 parseTag_3_16:
  if (!isgobj(x0)) goto parseTag_3_interrupt;
  if (!isclass(x0,vector)) goto parseTag_3_interrupt;
  gblt_size_of_vector(x0,x1,parseTag_3_interrupt);
 parseTag_3_17:
  if (x1 != makeint(2L)) goto parseTag_3_interrupt;
  x3 = makeint(0L);
  gblt_element_of_vector(x0,x3,x2,parseTag_3_interrupt);
  x5 = makeint(1L);
  gblt_element_of_vector(x0,x5,x4,parseTag_3_interrupt);
  x6 = NILATOM;
  unify_value(x4, x6);
  a0 = NILATOM;
  a1 = cdr_of(a1);
  execute(parseTag_3_0);
  goto parseTag_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,parseTag_3_15);
  *reasonp++ =  x0;
  goto parseTag_3_interrupt;
  };
  goto parseTag_3_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto parseTag_3_interrupt;
  x0 = NILATOM;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,parseTag_3_14);
  *reasonp++ =  a1;
  goto parseTag_3_interrupt;
  };
  goto parseTag_3_interrupt;
 case VARREF:
  deref_and_jump(a0,parseTag_3_12);
  *reasonp++ =  a0;
  goto parseTag_3_interrupt;
  };
  goto parseTag_3_interrupt;
 parseTag_3_ext_interrupt:
  reasonp = 0l;
 parseTag_3_interrupt:
  toppred = &predicate_html_xparseTag_3;
  goto interrupt_3;
 }

 parseTag_2F3_246_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 parseTag_2F3_246_4_clear_reason:
  reasonp = reasons;
 parseTag_2F3_246_4_0:
 parseTag_2F3_246_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 parseTag_2F3_246_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
 parseTag_2F3_246_4_3:
  if (!isgobj(x0)) goto parseTag_2F3_246_4_6;
  if (!isclass(x0,vector)) goto parseTag_2F3_246_4_6;
  gblt_size_of_vector(x0,x1,parseTag_2F3_246_4_6);
 parseTag_2F3_246_4_4:
  if (x1 != makeint(2L)) goto parseTag_2F3_246_4_6;
  x3 = makeint(0L);
  gblt_element_of_vector(x0,x3,x2,parseTag_2F3_246_4_6);
 parseTag_2F3_246_4_5:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (isint(x2)) goto parseTag_2F3_246_4_6;
  switch (symval(x2)) {
 case symval(makesym(atom_li)):
  x5 = makeint(1L);
  gblt_element_of_vector(x0,x5,x4,parseTag_2F3_246_4_6);
  x6 = NILATOM;
  unify_value(a1, x6);
  x7 = cdr_of(a0);
  unify2(a2, x7, a3, x4);
  proceed();
 case symval(makesym(atom_dt)):
  x5 = makeint(1L);
  gblt_element_of_vector(x0,x5,x4,parseTag_2F3_246_4_6);
  x6 = NILATOM;
  unify_value(a1, x6);
  x7 = cdr_of(a0);
  unify2(a2, x7, a3, x4);
  proceed();
 case symval(makesym(atom_dd)):
  x5 = makeint(1L);
  gblt_element_of_vector(x0,x5,x4,parseTag_2F3_246_4_6);
  x6 = NILATOM;
  unify_value(a1, x6);
  x7 = cdr_of(a0);
  unify2(a2, x7, a3, x4);
  proceed();
  };
  goto parseTag_2F3_246_4_6;
 case VARREF:
  deref_and_jump(x2,parseTag_2F3_246_4_5);
  *reasonp++ =  x2;
  goto parseTag_2F3_246_4_6;
  };
  goto parseTag_2F3_246_4_6;
 case VARREF:
  deref_and_jump(x0,parseTag_2F3_246_4_2);
  *reasonp++ =  x0;
  goto parseTag_2F3_246_4_6;
  };
  goto parseTag_2F3_246_4_6;
 case VARREF:
  deref_and_jump(a0,parseTag_2F3_246_4_1);
  *reasonp++ =  a0;
  goto parseTag_2F3_246_4_6;
  };
  goto parseTag_2F3_246_4_6;
 parseTag_2F3_246_4_6:
  otherwise(parseTag_2F3_246_4_interrupt);
  unify2(a2, a0, a3, a1);
  proceed();
 parseTag_2F3_246_4_ext_interrupt:
  reasonp = 0l;
 parseTag_2F3_246_4_interrupt:
  goto interrupt_4;
 }

 parseTag_2F3_245_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 parseTag_2F3_245_4_clear_reason:
  reasonp = reasons;
 parseTag_2F3_245_4_0:
 parseTag_2F3_245_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 parseTag_2F3_245_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
 parseTag_2F3_245_4_3:
  if (!isgobj(x0)) goto parseTag_2F3_245_4_6;
  if (!isclass(x0,vector)) goto parseTag_2F3_245_4_6;
  gblt_size_of_vector(x0,x1,parseTag_2F3_245_4_6);
 parseTag_2F3_245_4_4:
  if (x1 != makeint(2L)) goto parseTag_2F3_245_4_6;
  x3 = makeint(0L);
  gblt_element_of_vector(x0,x3,x2,parseTag_2F3_245_4_6);
 parseTag_2F3_245_4_5:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != makesym(atom_p)) goto parseTag_2F3_245_4_6;
  x5 = makeint(1L);
  gblt_element_of_vector(x0,x5,x4,parseTag_2F3_245_4_6);
  x6 = NILATOM;
  unify_value(a1, x6);
  x7 = cdr_of(a0);
  unify2(a2, x7, a3, x4);
  proceed();
 case VARREF:
  deref_and_jump(x2,parseTag_2F3_245_4_5);
  *reasonp++ =  x2;
  goto parseTag_2F3_245_4_6;
  };
  goto parseTag_2F3_245_4_6;
 case VARREF:
  deref_and_jump(x0,parseTag_2F3_245_4_2);
  *reasonp++ =  x0;
  goto parseTag_2F3_245_4_6;
  };
  goto parseTag_2F3_245_4_6;
 case VARREF:
  deref_and_jump(a0,parseTag_2F3_245_4_1);
  *reasonp++ =  a0;
  goto parseTag_2F3_245_4_6;
  };
  goto parseTag_2F3_245_4_6;
 parseTag_2F3_245_4_6:
  otherwise(parseTag_2F3_245_4_interrupt);
  unify2(a2, a0, a3, a1);
  proceed();
 parseTag_2F3_245_4_ext_interrupt:
  reasonp = 0l;
 parseTag_2F3_245_4_interrupt:
  toppred = &predicate_html_xparseTag_2F3_245_4;
  goto interrupt_4;
 }

 parseTag_2F3_244_6_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 parseTag_2F3_244_6_clear_reason:
  reasonp = reasons;
 parseTag_2F3_244_6_0:
 parseTag_2F3_244_6_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto parseTag_2F3_244_6_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_true)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xparseTag_2F3_244_2F6_240_6);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_util_xisMember_3);
  allocp[10] = a1;
  allocp[11] = x1 = makeref(&allocp[11]);
  allocp[12] = x0;
  a0 = x1;
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  execute(noEndtag_1_0);
  goto noEndtag_1_ext_interrupt;
 case symval(makesym(atom_false)):
  a0 = a4;
  a1 = a5;
  a2 = a3;
  execute(parseTag_3_0);
  goto parseTag_3_ext_interrupt;
  };
  goto parseTag_2F3_244_6_interrupt;
 case VARREF:
  deref_and_jump(a0,parseTag_2F3_244_6_1);
  *reasonp++ =  a0;
  goto parseTag_2F3_244_6_interrupt;
  };
  goto parseTag_2F3_244_6_interrupt;
 parseTag_2F3_244_6_ext_interrupt:
  reasonp = 0l;
 parseTag_2F3_244_6_interrupt:
  goto interrupt_6;
 }

 parseTag_2F3_244_2F6_240_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 parseTag_2F3_244_2F6_240_6_clear_reason:
  reasonp = reasons;
 parseTag_2F3_244_2F6_240_6_0:
 parseTag_2F3_244_2F6_240_6_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto parseTag_2F3_244_2F6_240_6_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_true)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xparseTag_3);
  allocp[2] = a4;
  allocp[3] = a5;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = x0;
  allocp[6] = x2 = makeref(&allocp[6]);
  x1 = makecons(&allocp[5]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  unify_value(a3, x1);
  allocp[0] = NILATOM;
  allocp[1] = a2;
  x3 = makecons(&allocp[0]);
  allocp[2] = x3;
  allocp[3] = a1;
  x4 = makecons(&allocp[2]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[6] = x2;
  allocp[7] = x4;
  qp = (struct goalrec*)&allocp[4];
  allocp += 8;
  proceed();
 case symval(makesym(atom_false)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xparseTag_3);
  allocp[2] = a4;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = x4 = makeref(&allocp[6]);
  x2 = makecons(&allocp[5]);
  allocp[7] = a1;
  allocp[8] = x3;
  x5 = create_vector(&allocp[7], 2, allocp);
  allocp[9] = x7 = makeref(&allocp[9]);
  allocp[10] = x5;
  x6 = makecons(&allocp[9]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 11;
  unify_value(x0, x6);
  allocp[0] = NILATOM;
  allocp[1] = x1;
  x8 = makecons(&allocp[0]);
  allocp[2] = x8;
  allocp[3] = a2;
  x9 = makecons(&allocp[2]);
  allocp[4] = x9;
  allocp[5] = a1;
  x10 = makecons(&allocp[4]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[8] = x4;
  allocp[9] = x10;
  allocp[10] = (q)(struct goalrec*)&allocp[6];
  allocp[11] = (q)(&predicate_html_xparseTag_2F3_244_2F6_240_2F6_240_5);
  allocp[12] = x11 = makeref(&allocp[12]);
  allocp[13] = a5;
  allocp[14] = a3;
  allocp[15] = x7;
  allocp[16] = x2;
  allocp[17] = (q)(struct goalrec*)&allocp[10];
  allocp[18] = (q)(&predicate_util_xisMember_3);
  allocp[19] = a1;
  allocp[20] = x12 = makeref(&allocp[20]);
  allocp[21] = x11;
  a0 = x12;
  qp = (struct goalrec*)&allocp[17];
  allocp += 22;
  execute(closePtag_1_0);
  goto closePtag_1_ext_interrupt;
  };
  goto parseTag_2F3_244_2F6_240_6_interrupt;
 case VARREF:
  deref_and_jump(a0,parseTag_2F3_244_2F6_240_6_1);
  *reasonp++ =  a0;
  goto parseTag_2F3_244_2F6_240_6_interrupt;
  };
  goto parseTag_2F3_244_2F6_240_6_interrupt;
 parseTag_2F3_244_2F6_240_6_ext_interrupt:
  reasonp = 0l;
 parseTag_2F3_244_2F6_240_6_interrupt:
  goto interrupt_6;
 }

 parseTag_2F3_244_2F6_240_2F6_240_5_top: {
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 parseTag_2F3_244_2F6_240_2F6_240_5_clear_reason:
  reasonp = reasons;
 parseTag_2F3_244_2F6_240_2F6_240_5_0:
 parseTag_2F3_244_2F6_240_2F6_240_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_true)) goto parseTag_2F3_244_2F6_240_2F6_240_5_2;
  a0 = a1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  execute(parseTag_2F3_244_2F6_240_2F6_240_2F5_240_4_0);
  goto parseTag_2F3_244_2F6_240_2F6_240_2F5_240_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,parseTag_2F3_244_2F6_240_2F6_240_5_1);
  *reasonp++ =  a0;
  goto parseTag_2F3_244_2F6_240_2F6_240_5_2;
  };
  goto parseTag_2F3_244_2F6_240_2F6_240_5_2;
 parseTag_2F3_244_2F6_240_2F6_240_5_2:
  otherwise(parseTag_2F3_244_2F6_240_2F6_240_5_interrupt);
  unify2(a3, a1, a4, a2);
  proceed();
 parseTag_2F3_244_2F6_240_2F6_240_5_ext_interrupt:
  reasonp = 0l;
 parseTag_2F3_244_2F6_240_2F6_240_5_interrupt:
  goto interrupt_5;
 }

 parseTag_2F3_244_2F6_240_2F6_240_2F5_240_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 parseTag_2F3_244_2F6_240_2F6_240_2F5_240_4_clear_reason:
  reasonp = reasons;
 parseTag_2F3_244_2F6_240_2F6_240_2F5_240_4_0:
 parseTag_2F3_244_2F6_240_2F6_240_2F5_240_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 parseTag_2F3_244_2F6_240_2F6_240_2F5_240_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
 parseTag_2F3_244_2F6_240_2F6_240_2F5_240_4_3:
  if (!isgobj(x0)) goto parseTag_2F3_244_2F6_240_2F6_240_2F5_240_4_6;
  if (!isclass(x0,vector)) goto parseTag_2F3_244_2F6_240_2F6_240_2F5_240_4_6;
  gblt_size_of_vector(x0,x1,parseTag_2F3_244_2F6_240_2F6_240_2F5_240_4_6);
 parseTag_2F3_244_2F6_240_2F6_240_2F5_240_4_4:
  if (x1 != makeint(2L)) goto parseTag_2F3_244_2F6_240_2F6_240_2F5_240_4_6;
  x3 = makeint(0L);
  gblt_element_of_vector(x0,x3,x2,parseTag_2F3_244_2F6_240_2F6_240_2F5_240_4_6);
 parseTag_2F3_244_2F6_240_2F6_240_2F5_240_4_5:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != makesym(atom_p)) goto parseTag_2F3_244_2F6_240_2F6_240_2F5_240_4_6;
  x5 = makeint(1L);
  gblt_element_of_vector(x0,x5,x4,parseTag_2F3_244_2F6_240_2F6_240_2F5_240_4_6);
  x6 = NILATOM;
  unify_value(a1, x6);
  x7 = cdr_of(a0);
  unify2(a2, x7, a3, x4);
  proceed();
 case VARREF:
  deref_and_jump(x2,parseTag_2F3_244_2F6_240_2F6_240_2F5_240_4_5);
  *reasonp++ =  x2;
  goto parseTag_2F3_244_2F6_240_2F6_240_2F5_240_4_6;
  };
  goto parseTag_2F3_244_2F6_240_2F6_240_2F5_240_4_6;
 case VARREF:
  deref_and_jump(x0,parseTag_2F3_244_2F6_240_2F6_240_2F5_240_4_2);
  *reasonp++ =  x0;
  goto parseTag_2F3_244_2F6_240_2F6_240_2F5_240_4_6;
  };
  goto parseTag_2F3_244_2F6_240_2F6_240_2F5_240_4_6;
 case VARREF:
  deref_and_jump(a0,parseTag_2F3_244_2F6_240_2F6_240_2F5_240_4_1);
  *reasonp++ =  a0;
  goto parseTag_2F3_244_2F6_240_2F6_240_2F5_240_4_6;
  };
  goto parseTag_2F3_244_2F6_240_2F6_240_2F5_240_4_6;
 parseTag_2F3_244_2F6_240_2F6_240_2F5_240_4_6:
  otherwise(parseTag_2F3_244_2F6_240_2F6_240_2F5_240_4_interrupt);
  unify2(a2, a0, a3, a1);
  proceed();
 parseTag_2F3_244_2F6_240_2F6_240_2F5_240_4_ext_interrupt:
  reasonp = 0l;
 parseTag_2F3_244_2F6_240_2F6_240_2F5_240_4_interrupt:
  toppred = &predicate_html_xparseTag_2F3_244_2F6_240_2F6_240_2F5_240_4;
  goto interrupt_4;
 }

 parseTag_2F3_243_4_top: {
  q x0, x1, x2, x3, x4, x5;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 parseTag_2F3_243_4_clear_reason:
  reasonp = reasons;
 parseTag_2F3_243_4_0:
 parseTag_2F3_243_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 parseTag_2F3_243_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
 parseTag_2F3_243_4_3:
  if (!isgobj(x0)) goto parseTag_2F3_243_4_5;
  if (!isclass(x0,vector)) goto parseTag_2F3_243_4_5;
  gblt_size_of_vector(x0,x1,parseTag_2F3_243_4_5);
 parseTag_2F3_243_4_4:
  if (x1 != makeint(2L)) goto parseTag_2F3_243_4_5;
  x3 = makeint(0L);
  gblt_element_of_vector(x0,x3,x2,parseTag_2F3_243_4_5);
  x5 = makeint(1L);
  gblt_element_of_vector(x0,x5,x4,parseTag_2F3_243_4_5);
  a4 = cdr_of(a0);
  a5 = x4;
  a6 = a0;
  a0 = x2;
  execute(parseTag_2F3_243_2F4_240_7_0);
  goto parseTag_2F3_243_2F4_240_7_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,parseTag_2F3_243_4_2);
  *reasonp++ =  x0;
  goto parseTag_2F3_243_4_5;
  };
  goto parseTag_2F3_243_4_5;
 case VARREF:
  deref_and_jump(a0,parseTag_2F3_243_4_1);
  *reasonp++ =  a0;
  goto parseTag_2F3_243_4_5;
  };
  goto parseTag_2F3_243_4_5;
 parseTag_2F3_243_4_5:
  otherwise(parseTag_2F3_243_4_interrupt);
  x0 = a3;
  a1 = a0;
  a0 = x0;
  execute(parseTag_3_0);
  goto parseTag_3_ext_interrupt;
 parseTag_2F3_243_4_ext_interrupt:
  reasonp = 0l;
 parseTag_2F3_243_4_interrupt:
  goto interrupt_4;
 }

 parseTag_2F3_243_2F4_240_7_top: {
  q x0;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 parseTag_2F3_243_2F4_240_7_clear_reason:
  reasonp = reasons;
 parseTag_2F3_243_2F4_240_7_0:
 parseTag_2F3_243_2F4_240_7_1:
  if (isref(a0)) goto parseTag_2F3_243_2F4_240_7_4;
 parseTag_2F3_243_2F4_240_7_2:
  if (isref(a0)) goto parseTag_2F3_243_2F4_240_7_3;
  if_not_equal(a0, a1, parseTag_2F3_243_2F4_240_7_5);
  x0 = NILATOM;
  unify_value(a2, x0);
  a0 = a3;
  a1 = a4;
  a2 = a5;
  execute(parseTag_3_clear_reason);
  goto parseTag_3_ext_interrupt;
 parseTag_2F3_243_2F4_240_7_3:
  deref_and_jump(a0,parseTag_2F3_243_2F4_240_7_2);
  *reasonp++ =  a0;
  goto parseTag_2F3_243_2F4_240_7_5;
 parseTag_2F3_243_2F4_240_7_4:
  deref_and_jump(a0,parseTag_2F3_243_2F4_240_7_1);
  *reasonp++ =  a0;
  goto parseTag_2F3_243_2F4_240_7_5;
 parseTag_2F3_243_2F4_240_7_5:
  otherwise(parseTag_2F3_243_2F4_240_7_interrupt);
  a0 = a3;
  a1 = a6;
  execute(parseTag_3_0);
  goto parseTag_3_ext_interrupt;
 parseTag_2F3_243_2F4_240_7_ext_interrupt:
  reasonp = 0l;
 parseTag_2F3_243_2F4_240_7_interrupt:
  toppred = &predicate_html_xparseTag_2F3_243_2F4_240_7;
  goto interrupt_7;
 }

 parseTag_2F3_242_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 parseTag_2F3_242_4_clear_reason:
  reasonp = reasons;
 parseTag_2F3_242_4_0:
 parseTag_2F3_242_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 parseTag_2F3_242_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
 parseTag_2F3_242_4_3:
  if (!isgobj(x0)) goto parseTag_2F3_242_4_6;
  if (!isclass(x0,vector)) goto parseTag_2F3_242_4_6;
  gblt_size_of_vector(x0,x1,parseTag_2F3_242_4_6);
 parseTag_2F3_242_4_4:
  if (x1 != makeint(2L)) goto parseTag_2F3_242_4_6;
  x3 = makeint(0L);
  gblt_element_of_vector(x0,x3,x2,parseTag_2F3_242_4_6);
 parseTag_2F3_242_4_5:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (isint(x2)) goto parseTag_2F3_242_4_6;
  switch (symval(x2)) {
 case symval(makesym(atom_li)):
  x5 = makeint(1L);
  gblt_element_of_vector(x0,x5,x4,parseTag_2F3_242_4_6);
  x6 = NILATOM;
  unify_value(a1, x6);
  x7 = cdr_of(a0);
  unify2(a2, x7, a3, x4);
  proceed();
 case symval(makesym(atom_dt)):
  x5 = makeint(1L);
  gblt_element_of_vector(x0,x5,x4,parseTag_2F3_242_4_6);
  x6 = NILATOM;
  unify_value(a1, x6);
  x7 = cdr_of(a0);
  unify2(a2, x7, a3, x4);
  proceed();
 case symval(makesym(atom_dd)):
  x5 = makeint(1L);
  gblt_element_of_vector(x0,x5,x4,parseTag_2F3_242_4_6);
  x6 = NILATOM;
  unify_value(a1, x6);
  x7 = cdr_of(a0);
  unify2(a2, x7, a3, x4);
  proceed();
  };
  goto parseTag_2F3_242_4_6;
 case VARREF:
  deref_and_jump(x2,parseTag_2F3_242_4_5);
  *reasonp++ =  x2;
  goto parseTag_2F3_242_4_6;
  };
  goto parseTag_2F3_242_4_6;
 case VARREF:
  deref_and_jump(x0,parseTag_2F3_242_4_2);
  *reasonp++ =  x0;
  goto parseTag_2F3_242_4_6;
  };
  goto parseTag_2F3_242_4_6;
 case VARREF:
  deref_and_jump(a0,parseTag_2F3_242_4_1);
  *reasonp++ =  a0;
  goto parseTag_2F3_242_4_6;
  };
  goto parseTag_2F3_242_4_6;
 parseTag_2F3_242_4_6:
  otherwise(parseTag_2F3_242_4_interrupt);
  unify2(a2, a0, a3, a1);
  proceed();
 parseTag_2F3_242_4_ext_interrupt:
  reasonp = 0l;
 parseTag_2F3_242_4_interrupt:
  goto interrupt_4;
 }

 parseTag_2F3_241_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 parseTag_2F3_241_4_clear_reason:
  reasonp = reasons;
 parseTag_2F3_241_4_0:
 parseTag_2F3_241_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 parseTag_2F3_241_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
 parseTag_2F3_241_4_3:
  if (!isgobj(x0)) goto parseTag_2F3_241_4_6;
  if (!isclass(x0,vector)) goto parseTag_2F3_241_4_6;
  gblt_size_of_vector(x0,x1,parseTag_2F3_241_4_6);
 parseTag_2F3_241_4_4:
  if (x1 != makeint(2L)) goto parseTag_2F3_241_4_6;
  x3 = makeint(0L);
  gblt_element_of_vector(x0,x3,x2,parseTag_2F3_241_4_6);
 parseTag_2F3_241_4_5:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != makesym(atom_p)) goto parseTag_2F3_241_4_6;
  x5 = makeint(1L);
  gblt_element_of_vector(x0,x5,x4,parseTag_2F3_241_4_6);
  x6 = NILATOM;
  unify_value(a1, x6);
  x7 = cdr_of(a0);
  unify2(a2, x7, a3, x4);
  proceed();
 case VARREF:
  deref_and_jump(x2,parseTag_2F3_241_4_5);
  *reasonp++ =  x2;
  goto parseTag_2F3_241_4_6;
  };
  goto parseTag_2F3_241_4_6;
 case VARREF:
  deref_and_jump(x0,parseTag_2F3_241_4_2);
  *reasonp++ =  x0;
  goto parseTag_2F3_241_4_6;
  };
  goto parseTag_2F3_241_4_6;
 case VARREF:
  deref_and_jump(a0,parseTag_2F3_241_4_1);
  *reasonp++ =  a0;
  goto parseTag_2F3_241_4_6;
  };
  goto parseTag_2F3_241_4_6;
 parseTag_2F3_241_4_6:
  otherwise(parseTag_2F3_241_4_interrupt);
  unify2(a2, a0, a3, a1);
  proceed();
 parseTag_2F3_241_4_ext_interrupt:
  reasonp = 0l;
 parseTag_2F3_241_4_interrupt:
  toppred = &predicate_html_xparseTag_2F3_241_4;
  goto interrupt_4;
 }

 parseTag_2F3_240_6_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 parseTag_2F3_240_6_clear_reason:
  reasonp = reasons;
 parseTag_2F3_240_6_0:
 parseTag_2F3_240_6_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto parseTag_2F3_240_6_3;
  switch (symval(a0)) {
 case symval(makesym(atom_false)):
  a0 = a2;
  a1 = a3;
  a2 = a4;
  execute(parseTag_3_0);
  goto parseTag_3_ext_interrupt;
 case symval(makesym(atom_true)):
 parseTag_2F3_240_6_2:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_false)) goto parseTag_2F3_240_6_3;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xparseTag_2F3_240_2F6_241_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a5;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a2;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_html_xparseTag_2F3_240_2F6_240_5);
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = a3;
  allocp[10] = a4;
  allocp[11] = x0;
  allocp[12] = x1;
  allocp[13] = (q)(struct goalrec*)&allocp[6];
  allocp[14] = (q)(&predicate_util_xisMember_3);
  allocp[15] = a5;
  allocp[16] = x3 = makeref(&allocp[16]);
  allocp[17] = x2;
  a0 = x3;
  qp = (struct goalrec*)&allocp[13];
  allocp += 18;
  execute(closePtag_1_0);
  goto closePtag_1_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,parseTag_2F3_240_6_2);
  *reasonp++ =  a1;
  goto parseTag_2F3_240_6_3;
  };
  goto parseTag_2F3_240_6_3;
  };
  goto parseTag_2F3_240_6_3;
 case VARREF:
  deref_and_jump(a0,parseTag_2F3_240_6_1);
  *reasonp++ =  a0;
  goto parseTag_2F3_240_6_3;
  };
  goto parseTag_2F3_240_6_3;
 parseTag_2F3_240_6_3:
 parseTag_2F3_240_6_4:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_true)) goto parseTag_2F3_240_6_interrupt;
  a0 = a2;
  a1 = a3;
  a2 = a4;
  execute(parseTag_3_clear_reason);
  goto parseTag_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,parseTag_2F3_240_6_4);
  *reasonp++ =  a1;
  goto parseTag_2F3_240_6_interrupt;
  };
  goto parseTag_2F3_240_6_interrupt;
 parseTag_2F3_240_6_ext_interrupt:
  reasonp = 0l;
 parseTag_2F3_240_6_interrupt:
  goto interrupt_6;
 }

 parseTag_2F3_240_2F6_241_4_top: {
  q x0, x1, x2, x3, x4, x5;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 parseTag_2F3_240_2F6_241_4_clear_reason:
  reasonp = reasons;
 parseTag_2F3_240_2F6_241_4_0:
 parseTag_2F3_240_2F6_241_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 parseTag_2F3_240_2F6_241_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
 parseTag_2F3_240_2F6_241_4_3:
  if (!isgobj(x0)) goto parseTag_2F3_240_2F6_241_4_5;
  if (!isclass(x0,vector)) goto parseTag_2F3_240_2F6_241_4_5;
  gblt_size_of_vector(x0,x1,parseTag_2F3_240_2F6_241_4_5);
 parseTag_2F3_240_2F6_241_4_4:
  if (x1 != makeint(2L)) goto parseTag_2F3_240_2F6_241_4_5;
  x3 = makeint(0L);
  gblt_element_of_vector(x0,x3,x2,parseTag_2F3_240_2F6_241_4_5);
  x5 = makeint(1L);
  gblt_element_of_vector(x0,x5,x4,parseTag_2F3_240_2F6_241_4_5);
  a4 = cdr_of(a0);
  a5 = x4;
  a6 = a0;
  a0 = x2;
  execute(parseTag_2F3_240_2F6_241_2F4_240_7_0);
  goto parseTag_2F3_240_2F6_241_2F4_240_7_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,parseTag_2F3_240_2F6_241_4_2);
  *reasonp++ =  x0;
  goto parseTag_2F3_240_2F6_241_4_5;
  };
  goto parseTag_2F3_240_2F6_241_4_5;
 case VARREF:
  deref_and_jump(a0,parseTag_2F3_240_2F6_241_4_1);
  *reasonp++ =  a0;
  goto parseTag_2F3_240_2F6_241_4_5;
  };
  goto parseTag_2F3_240_2F6_241_4_5;
 parseTag_2F3_240_2F6_241_4_5:
  otherwise(parseTag_2F3_240_2F6_241_4_interrupt);
  x0 = a3;
  a1 = a0;
  a0 = x0;
  execute(parseTag_3_0);
  goto parseTag_3_ext_interrupt;
 parseTag_2F3_240_2F6_241_4_ext_interrupt:
  reasonp = 0l;
 parseTag_2F3_240_2F6_241_4_interrupt:
  goto interrupt_4;
 }

 parseTag_2F3_240_2F6_241_2F4_240_7_top: {
  q x0;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 parseTag_2F3_240_2F6_241_2F4_240_7_clear_reason:
  reasonp = reasons;
 parseTag_2F3_240_2F6_241_2F4_240_7_0:
 parseTag_2F3_240_2F6_241_2F4_240_7_1:
  if (isref(a0)) goto parseTag_2F3_240_2F6_241_2F4_240_7_4;
 parseTag_2F3_240_2F6_241_2F4_240_7_2:
  if (isref(a0)) goto parseTag_2F3_240_2F6_241_2F4_240_7_3;
  if_not_equal(a0, a1, parseTag_2F3_240_2F6_241_2F4_240_7_5);
  x0 = NILATOM;
  unify_value(a2, x0);
  a0 = a3;
  a1 = a4;
  a2 = a5;
  execute(parseTag_3_clear_reason);
  goto parseTag_3_ext_interrupt;
 parseTag_2F3_240_2F6_241_2F4_240_7_3:
  deref_and_jump(a0,parseTag_2F3_240_2F6_241_2F4_240_7_2);
  *reasonp++ =  a0;
  goto parseTag_2F3_240_2F6_241_2F4_240_7_5;
 parseTag_2F3_240_2F6_241_2F4_240_7_4:
  deref_and_jump(a0,parseTag_2F3_240_2F6_241_2F4_240_7_1);
  *reasonp++ =  a0;
  goto parseTag_2F3_240_2F6_241_2F4_240_7_5;
 parseTag_2F3_240_2F6_241_2F4_240_7_5:
  otherwise(parseTag_2F3_240_2F6_241_2F4_240_7_interrupt);
  a0 = a3;
  a1 = a6;
  execute(parseTag_3_0);
  goto parseTag_3_ext_interrupt;
 parseTag_2F3_240_2F6_241_2F4_240_7_ext_interrupt:
  reasonp = 0l;
 parseTag_2F3_240_2F6_241_2F4_240_7_interrupt:
  toppred = &predicate_html_xparseTag_2F3_240_2F6_241_2F4_240_7;
  goto interrupt_7;
 }

 parseTag_2F3_240_2F6_240_5_top: {
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 parseTag_2F3_240_2F6_240_5_clear_reason:
  reasonp = reasons;
 parseTag_2F3_240_2F6_240_5_0:
 parseTag_2F3_240_2F6_240_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto parseTag_2F3_240_2F6_240_5_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_true)):
  a0 = a1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  execute(parseTag_2F3_240_2F6_240_2F5_240_4_0);
  goto parseTag_2F3_240_2F6_240_2F5_240_4_ext_interrupt;
 case symval(makesym(atom_false)):
  unify2(a3, a1, a4, a2);
  proceed();
  };
  goto parseTag_2F3_240_2F6_240_5_interrupt;
 case VARREF:
  deref_and_jump(a0,parseTag_2F3_240_2F6_240_5_1);
  *reasonp++ =  a0;
  goto parseTag_2F3_240_2F6_240_5_interrupt;
  };
  goto parseTag_2F3_240_2F6_240_5_interrupt;
 parseTag_2F3_240_2F6_240_5_ext_interrupt:
  reasonp = 0l;
 parseTag_2F3_240_2F6_240_5_interrupt:
  goto interrupt_5;
 }

 parseTag_2F3_240_2F6_240_2F5_240_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 parseTag_2F3_240_2F6_240_2F5_240_4_clear_reason:
  reasonp = reasons;
 parseTag_2F3_240_2F6_240_2F5_240_4_0:
 parseTag_2F3_240_2F6_240_2F5_240_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 parseTag_2F3_240_2F6_240_2F5_240_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
 parseTag_2F3_240_2F6_240_2F5_240_4_3:
  if (!isgobj(x0)) goto parseTag_2F3_240_2F6_240_2F5_240_4_6;
  if (!isclass(x0,vector)) goto parseTag_2F3_240_2F6_240_2F5_240_4_6;
  gblt_size_of_vector(x0,x1,parseTag_2F3_240_2F6_240_2F5_240_4_6);
 parseTag_2F3_240_2F6_240_2F5_240_4_4:
  if (x1 != makeint(2L)) goto parseTag_2F3_240_2F6_240_2F5_240_4_6;
  x3 = makeint(0L);
  gblt_element_of_vector(x0,x3,x2,parseTag_2F3_240_2F6_240_2F5_240_4_6);
 parseTag_2F3_240_2F6_240_2F5_240_4_5:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != makesym(atom_p)) goto parseTag_2F3_240_2F6_240_2F5_240_4_6;
  x5 = makeint(1L);
  gblt_element_of_vector(x0,x5,x4,parseTag_2F3_240_2F6_240_2F5_240_4_6);
  x6 = NILATOM;
  unify_value(a1, x6);
  x7 = cdr_of(a0);
  unify2(a2, x7, a3, x4);
  proceed();
 case VARREF:
  deref_and_jump(x2,parseTag_2F3_240_2F6_240_2F5_240_4_5);
  *reasonp++ =  x2;
  goto parseTag_2F3_240_2F6_240_2F5_240_4_6;
  };
  goto parseTag_2F3_240_2F6_240_2F5_240_4_6;
 case VARREF:
  deref_and_jump(x0,parseTag_2F3_240_2F6_240_2F5_240_4_2);
  *reasonp++ =  x0;
  goto parseTag_2F3_240_2F6_240_2F5_240_4_6;
  };
  goto parseTag_2F3_240_2F6_240_2F5_240_4_6;
 case VARREF:
  deref_and_jump(a0,parseTag_2F3_240_2F6_240_2F5_240_4_1);
  *reasonp++ =  a0;
  goto parseTag_2F3_240_2F6_240_2F5_240_4_6;
  };
  goto parseTag_2F3_240_2F6_240_2F5_240_4_6;
 parseTag_2F3_240_2F6_240_2F5_240_4_6:
  otherwise(parseTag_2F3_240_2F6_240_2F5_240_4_interrupt);
  unify2(a2, a0, a3, a1);
  proceed();
 parseTag_2F3_240_2F6_240_2F5_240_4_ext_interrupt:
  reasonp = 0l;
 parseTag_2F3_240_2F6_240_2F5_240_4_interrupt:
  toppred = &predicate_html_xparseTag_2F3_240_2F6_240_2F5_240_4;
  goto interrupt_4;
 }

 normalizeHTML_2_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  qp = qp->next;
 normalizeHTML_2_clear_reason:
  reasonp = reasons;
 normalizeHTML_2_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xrmNullP_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_html_xrmNullText_2);
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = x0;
  allocp[8] = (q)(struct goalrec*)&allocp[4];
  allocp[9] = (q)(&predicate_html_xnormalizeText_2);
  allocp[10] = x2 = makeref(&allocp[10]);
  allocp[11] = x1;
  allocp[12] = (q)(struct goalrec*)&allocp[8];
  allocp[13] = (q)(&predicate_html_xunescapeText_2);
  allocp[14] = x3 = makeref(&allocp[14]);
  allocp[15] = x2;
  a1 = x3;
  qp = (struct goalrec*)&allocp[12];
  allocp += 16;
  execute(catText_2_0);
  goto catText_2_ext_interrupt;
 normalizeHTML_2_ext_interrupt:
  reasonp = 0l;
 normalizeHTML_2_interrupt:
  goto interrupt_2;
 }

 catText_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  a1 = qp->args[1];
  qp = qp->next;
 catText_2_clear_reason:
  reasonp = reasons;
 catText_2_0:
 catText_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 catText_2_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_text_1)) goto catText_2_3;
  allocp[0] = makesym(functor_text_1);
  allocp[1] = x2 = makeref(&allocp[1]);
  x1 = makefunctor(&allocp[0]);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = x1;
  x3 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a1, x3);
  a0 = cdr_of(a0);
  a1 = arg(x0, 0);
  a2 = x2;
  a3 = x4;
  execute(catText1_4_0);
  goto catText1_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,catText_2_2);
  *reasonp++ =  x0;
  goto catText_2_3;
  };
  goto catText_2_3;
 case VARREF:
  deref_and_jump(a0,catText_2_1);
  *reasonp++ =  a0;
  goto catText_2_3;
  };
  goto catText_2_3;
 catText_2_3:
  otherwise(catText_2_interrupt);
 catText_2_4:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 catText_2_5:
  if (isref(x0)) goto catText_2_7;
  gblt_pfunctor(x0,x1,catText_2_8);
  gblt_arity(x0,x2,catText_2_8);
 catText_2_6:
  if (x2 != makeint(2L)) goto catText_2_8;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xcatText_2);
  x3 = cdr_of(a0);
  allocp[2] = x3;
  allocp[3] = x4 = makeref(&allocp[3]);
  allocp[4] = x4;
  allocp[5] = x6 = makeref(&allocp[5]);
  x5 = makecons(&allocp[4]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  unify_value(a1, x5);
  allocp[0] = NILATOM;
  allocp[1] = x8 = makeref(&allocp[1]);
  x7 = makecons(&allocp[0]);
  allocp[2] = x7;
  allocp[3] = x10 = makeref(&allocp[3]);
  x9 = makecons(&allocp[2]);
  allocp[4] = x9;
  allocp[5] = x1;
  x11 = makecons(&allocp[4]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[8] = x6;
  allocp[9] = x11;
  allocp[10] = (q)(struct goalrec*)&allocp[6];
  allocp[11] = (q)(&predicate_html_xcatText_2);
  allocp[12] = x12 = makeref(&allocp[12]);
  allocp[13] = x8;
  allocp[14] = (q)(struct goalrec*)&allocp[10];
  allocp[15] = (q)(&predicate_functor__table_xarg_3);
  allocp[16] = makeint(2L);
  allocp[17] = x0;
  allocp[18] = x12;
  allocp[19] = (q)(struct goalrec*)&allocp[14];
  allocp[20] = (q)(&predicate_functor__table_xarg_3);
  allocp[21] = makeint(1L);
  allocp[22] = x0;
  allocp[23] = x10;
  qp = (struct goalrec*)&allocp[19];
  allocp += 24;
  proceed();
 catText_2_7:
  deref_and_jump(x0,catText_2_5);
  *reasonp++ =  x0;
  goto catText_2_8;
 case VARREF:
  deref_and_jump(a0,catText_2_4);
  *reasonp++ =  a0;
  goto catText_2_8;
  };
  goto catText_2_8;
 catText_2_8:
  otherwise(catText_2_interrupt);
 catText_2_9:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(catText_2_0);
  goto catText_2_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto catText_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,catText_2_9);
  *reasonp++ =  a0;
  goto catText_2_interrupt;
  };
  goto catText_2_interrupt;
 catText_2_ext_interrupt:
  reasonp = 0l;
 catText_2_interrupt:
  toppred = &predicate_html_xcatText_2;
  goto interrupt_2;
 }

 catText1_4_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 catText1_4_clear_reason:
  reasonp = reasons;
 catText1_4_0:
 catText1_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 catText1_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_text_1)) goto catText1_4_3;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xcatText1_4);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_util_xappend_3);
  allocp[8] = a1;
  x3 = arg(x0, 0);
  allocp[9] = x3;
  allocp[10] = x2;
  qp = (struct goalrec*)&allocp[6];
  allocp += 11;
  proceed();
 case VARREF:
  deref_and_jump(x0,catText1_4_2);
  *reasonp++ =  x0;
  goto catText1_4_3;
  };
  goto catText1_4_3;
 case VARREF:
  deref_and_jump(a0,catText1_4_1);
  *reasonp++ =  a0;
  goto catText1_4_3;
  };
  goto catText1_4_3;
 catText1_4_3:
  otherwise(catText1_4_interrupt);
  unify(a2, a1);
  a1 = a3;
  execute(catText_2_0);
  goto catText_2_ext_interrupt;
 catText1_4_ext_interrupt:
  reasonp = 0l;
 catText1_4_interrupt:
  toppred = &predicate_html_xcatText1_4;
  goto interrupt_4;
 }

 unescapeText_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  a1 = qp->args[1];
  qp = qp->next;
 unescapeText_2_clear_reason:
  reasonp = reasons;
 unescapeText_2_0:
 unescapeText_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 unescapeText_2_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_text_1)) goto unescapeText_2_3;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xunescapeText_2);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = makesym(functor_text_1);
  allocp[5] = x4 = makeref(&allocp[5]);
  x3 = makefunctor(&allocp[4]);
  allocp[6] = x2;
  allocp[7] = x3;
  x5 = makecons(&allocp[6]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  unify_value(a1, x5);
  a0 = arg(x0, 0);
  a1 = x4;
  execute(unescape_2_0);
  goto unescape_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,unescapeText_2_2);
  *reasonp++ =  x0;
  goto unescapeText_2_3;
  };
  goto unescapeText_2_3;
 case VARREF:
  deref_and_jump(a0,unescapeText_2_1);
  *reasonp++ =  a0;
  goto unescapeText_2_3;
  };
  goto unescapeText_2_3;
 unescapeText_2_3:
  otherwise(unescapeText_2_interrupt);
 unescapeText_2_4:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 unescapeText_2_5:
  if (isref(x0)) goto unescapeText_2_7;
  gblt_pfunctor(x0,x1,unescapeText_2_8);
  gblt_arity(x0,x2,unescapeText_2_8);
 unescapeText_2_6:
  if (x2 != makeint(2L)) goto unescapeText_2_8;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xunescapeText_2);
  x3 = cdr_of(a0);
  allocp[2] = x3;
  allocp[3] = x4 = makeref(&allocp[3]);
  allocp[4] = x4;
  allocp[5] = x6 = makeref(&allocp[5]);
  x5 = makecons(&allocp[4]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  unify_value(a1, x5);
  allocp[0] = NILATOM;
  allocp[1] = x8 = makeref(&allocp[1]);
  x7 = makecons(&allocp[0]);
  allocp[2] = x7;
  allocp[3] = x10 = makeref(&allocp[3]);
  x9 = makecons(&allocp[2]);
  allocp[4] = x9;
  allocp[5] = x1;
  x11 = makecons(&allocp[4]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[8] = x6;
  allocp[9] = x11;
  allocp[10] = (q)(struct goalrec*)&allocp[6];
  allocp[11] = (q)(&predicate_html_xunescapeText_2);
  allocp[12] = x12 = makeref(&allocp[12]);
  allocp[13] = x8;
  allocp[14] = (q)(struct goalrec*)&allocp[10];
  allocp[15] = (q)(&predicate_functor__table_xarg_3);
  allocp[16] = makeint(2L);
  allocp[17] = x0;
  allocp[18] = x12;
  allocp[19] = (q)(struct goalrec*)&allocp[14];
  allocp[20] = (q)(&predicate_functor__table_xarg_3);
  allocp[21] = makeint(1L);
  allocp[22] = x0;
  allocp[23] = x10;
  qp = (struct goalrec*)&allocp[19];
  allocp += 24;
  proceed();
 unescapeText_2_7:
  deref_and_jump(x0,unescapeText_2_5);
  *reasonp++ =  x0;
  goto unescapeText_2_8;
 case VARREF:
  deref_and_jump(a0,unescapeText_2_4);
  *reasonp++ =  a0;
  goto unescapeText_2_8;
  };
  goto unescapeText_2_8;
 unescapeText_2_8:
  otherwise(unescapeText_2_interrupt);
 unescapeText_2_9:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(unescapeText_2_0);
  goto unescapeText_2_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto unescapeText_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,unescapeText_2_9);
  *reasonp++ =  a0;
  goto unescapeText_2_interrupt;
  };
  goto unescapeText_2_interrupt;
 unescapeText_2_ext_interrupt:
  reasonp = 0l;
 unescapeText_2_interrupt:
  goto interrupt_2;
 }

 normalizeText_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a1 = qp->args[1];
  qp = qp->next;
 normalizeText_2_clear_reason:
  reasonp = reasons;
 normalizeText_2_0:
 normalizeText_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 normalizeText_2_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_text_1)) goto normalizeText_2_3;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xnormalizeText_2);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = makesym(functor_text_1);
  allocp[5] = x4 = makeref(&allocp[5]);
  x3 = makefunctor(&allocp[4]);
  allocp[6] = x2;
  allocp[7] = x3;
  x5 = makecons(&allocp[6]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  unify_value(a1, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_util_xrmFirstSP_2);
  allocp[2] = x6 = makeref(&allocp[2]);
  allocp[3] = x4;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_util_xrmRedundantSP_2);
  allocp[6] = x7 = makeref(&allocp[6]);
  allocp[7] = x6;
  allocp[8] = (q)(struct goalrec*)&allocp[4];
  allocp[9] = (q)(&predicate_util_xtabToSP_2);
  allocp[10] = x8 = makeref(&allocp[10]);
  allocp[11] = x7;
  allocp[12] = (q)(struct goalrec*)&allocp[8];
  allocp[13] = (q)(&predicate_util_xcrlfToSP_2);
  x9 = arg(x0, 0);
  allocp[14] = x9;
  allocp[15] = x8;
  qp = (struct goalrec*)&allocp[12];
  allocp += 16;
  proceed();
 case VARREF:
  deref_and_jump(x0,normalizeText_2_2);
  *reasonp++ =  x0;
  goto normalizeText_2_3;
  };
  goto normalizeText_2_3;
 case VARREF:
  deref_and_jump(a0,normalizeText_2_1);
  *reasonp++ =  a0;
  goto normalizeText_2_3;
  };
  goto normalizeText_2_3;
 normalizeText_2_3:
  otherwise(normalizeText_2_interrupt);
 normalizeText_2_4:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 normalizeText_2_5:
  if (isref(x0)) goto normalizeText_2_7;
  gblt_pfunctor(x0,x1,normalizeText_2_interrupt);
  gblt_arity(x0,x2,normalizeText_2_interrupt);
 normalizeText_2_6:
  switch ((unsigned long)x2) {
 case (unsigned long) makeint(1L):
  allocp[0] = x4 = makeref(&allocp[0]);
  allocp[1] = x0;
  x3 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x3);
  a0 = cdr_of(a0);
  a1 = x4;
  execute(normalizeText_2_0);
  goto normalizeText_2_ext_interrupt;
 case (unsigned long) makeint(2L):
  a2 = a1;
  a3 = cdr_of(a0);
  a1 = x0;
  a0 = x1;
  execute(normalizeText_2F2_240_4_0);
  goto normalizeText_2F2_240_4_ext_interrupt;
  };
  goto normalizeText_2_interrupt;
 normalizeText_2_7:
  deref_and_jump(x0,normalizeText_2_5);
  *reasonp++ =  x0;
  goto normalizeText_2_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto normalizeText_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,normalizeText_2_4);
  *reasonp++ =  a0;
  goto normalizeText_2_interrupt;
  };
  goto normalizeText_2_interrupt;
 normalizeText_2_ext_interrupt:
  reasonp = 0l;
 normalizeText_2_interrupt:
  goto interrupt_2;
 }

 normalizeText_2F2_240_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 normalizeText_2F2_240_4_clear_reason:
  reasonp = reasons;
 normalizeText_2F2_240_4_0:
 normalizeText_2F2_240_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto normalizeText_2F2_240_4_2;
  switch (symval(a0)) {
 case symval(makesym(atom_pre)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xnormalizeText_2);
  allocp[2] = a3;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = x0;
  allocp[5] = x2 = makeref(&allocp[5]);
  x1 = makecons(&allocp[4]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  unify_value(a2, x1);
  allocp[0] = NILATOM;
  allocp[1] = x4 = makeref(&allocp[1]);
  x3 = makecons(&allocp[0]);
  allocp[2] = x3;
  allocp[3] = x6 = makeref(&allocp[3]);
  x5 = makecons(&allocp[2]);
  allocp[4] = x5;
  allocp[5] = a0;
  x7 = makecons(&allocp[4]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[8] = x2;
  allocp[9] = x7;
  allocp[10] = (q)(struct goalrec*)&allocp[6];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a1;
  allocp[14] = x6;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_html_xnormalizeTextInPre_2);
  allocp[17] = x8 = makeref(&allocp[17]);
  allocp[18] = x4;
  allocp[19] = (q)(struct goalrec*)&allocp[15];
  allocp[20] = (q)(&predicate_functor__table_xarg_3);
  allocp[21] = makeint(2L);
  allocp[22] = a1;
  allocp[23] = x8;
  qp = (struct goalrec*)&allocp[19];
  allocp += 24;
  proceed();
 case symval(makesym(atom_xmp)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xnormalizeText_2);
  allocp[2] = a3;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = x0;
  allocp[5] = x2 = makeref(&allocp[5]);
  x1 = makecons(&allocp[4]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  unify_value(a2, x1);
  allocp[0] = NILATOM;
  allocp[1] = x4 = makeref(&allocp[1]);
  x3 = makecons(&allocp[0]);
  allocp[2] = x3;
  allocp[3] = x6 = makeref(&allocp[3]);
  x5 = makecons(&allocp[2]);
  allocp[4] = x5;
  allocp[5] = a0;
  x7 = makecons(&allocp[4]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[8] = x2;
  allocp[9] = x7;
  allocp[10] = (q)(struct goalrec*)&allocp[6];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a1;
  allocp[14] = x6;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_html_xnormalizeTextInPre_2);
  allocp[17] = x8 = makeref(&allocp[17]);
  allocp[18] = x4;
  allocp[19] = (q)(struct goalrec*)&allocp[15];
  allocp[20] = (q)(&predicate_functor__table_xarg_3);
  allocp[21] = makeint(2L);
  allocp[22] = a1;
  allocp[23] = x8;
  qp = (struct goalrec*)&allocp[19];
  allocp += 24;
  proceed();
 case symval(makesym(atom_listing)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xnormalizeText_2);
  allocp[2] = a3;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = x0;
  allocp[5] = x2 = makeref(&allocp[5]);
  x1 = makecons(&allocp[4]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  unify_value(a2, x1);
  allocp[0] = NILATOM;
  allocp[1] = x4 = makeref(&allocp[1]);
  x3 = makecons(&allocp[0]);
  allocp[2] = x3;
  allocp[3] = x6 = makeref(&allocp[3]);
  x5 = makecons(&allocp[2]);
  allocp[4] = x5;
  allocp[5] = a0;
  x7 = makecons(&allocp[4]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[8] = x2;
  allocp[9] = x7;
  allocp[10] = (q)(struct goalrec*)&allocp[6];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a1;
  allocp[14] = x6;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_html_xnormalizeTextInPre_2);
  allocp[17] = x8 = makeref(&allocp[17]);
  allocp[18] = x4;
  allocp[19] = (q)(struct goalrec*)&allocp[15];
  allocp[20] = (q)(&predicate_functor__table_xarg_3);
  allocp[21] = makeint(2L);
  allocp[22] = a1;
  allocp[23] = x8;
  qp = (struct goalrec*)&allocp[19];
  allocp += 24;
  proceed();
  };
  goto normalizeText_2F2_240_4_2;
 case VARREF:
  deref_and_jump(a0,normalizeText_2F2_240_4_1);
  *reasonp++ =  a0;
  goto normalizeText_2F2_240_4_2;
  };
  goto normalizeText_2F2_240_4_2;
 normalizeText_2F2_240_4_2:
  otherwise(normalizeText_2F2_240_4_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xnormalizeText_2);
  allocp[2] = a3;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = x0;
  allocp[5] = x2 = makeref(&allocp[5]);
  x1 = makecons(&allocp[4]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  unify_value(a2, x1);
  allocp[0] = NILATOM;
  allocp[1] = x4 = makeref(&allocp[1]);
  x3 = makecons(&allocp[0]);
  allocp[2] = x3;
  allocp[3] = x6 = makeref(&allocp[3]);
  x5 = makecons(&allocp[2]);
  allocp[4] = x5;
  allocp[5] = a0;
  x7 = makecons(&allocp[4]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[8] = x2;
  allocp[9] = x7;
  allocp[10] = (q)(struct goalrec*)&allocp[6];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a1;
  allocp[14] = x6;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_html_xnormalizeText_2);
  allocp[17] = x8 = makeref(&allocp[17]);
  allocp[18] = x4;
  allocp[19] = (q)(struct goalrec*)&allocp[15];
  allocp[20] = (q)(&predicate_functor__table_xarg_3);
  allocp[21] = makeint(2L);
  allocp[22] = a1;
  allocp[23] = x8;
  qp = (struct goalrec*)&allocp[19];
  allocp += 24;
  proceed();
 normalizeText_2F2_240_4_ext_interrupt:
  reasonp = 0l;
 normalizeText_2F2_240_4_interrupt:
  toppred = &predicate_html_xnormalizeText_2F2_240_4;
  goto interrupt_4;
 }

 normalizeTextInPre_2_top: {
  q x0;
  a1 = qp->args[1];
  qp = qp->next;
 normalizeTextInPre_2_clear_reason:
  reasonp = reasons;
 normalizeTextInPre_2_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xnormalizeTextInPreFirst_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  a1 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  execute(catText_2_0);
  goto catText_2_ext_interrupt;
 normalizeTextInPre_2_ext_interrupt:
  reasonp = 0l;
 normalizeTextInPre_2_interrupt:
  goto interrupt_2;
 }

 normalizeTextInPreFirst_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  a1 = qp->args[1];
  qp = qp->next;
 normalizeTextInPreFirst_2_clear_reason:
  reasonp = reasons;
 normalizeTextInPreFirst_2_0:
 normalizeTextInPreFirst_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 normalizeTextInPreFirst_2_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_text_1)) goto normalizeTextInPreFirst_2_4;
  x1 = cdr_of(a0);
 normalizeTextInPreFirst_2_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto normalizeTextInPreFirst_2_4;
  allocp[0] = makesym(functor_text_1);
  allocp[1] = x3 = makeref(&allocp[1]);
  x2 = makefunctor(&allocp[0]);
  allocp[2] = NILATOM;
  allocp[3] = x2;
  x4 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a1, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_util_xrmLastLf_2);
  allocp[2] = x5 = makeref(&allocp[2]);
  allocp[3] = x3;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_util_xrmFirstLf_2);
  allocp[6] = x6 = makeref(&allocp[6]);
  allocp[7] = x5;
  allocp[8] = (q)(struct goalrec*)&allocp[4];
  allocp[9] = (q)(&predicate_util_xcrlfToLf_2);
  x7 = arg(x0, 0);
  allocp[10] = x7;
  allocp[11] = x6;
  qp = (struct goalrec*)&allocp[8];
  allocp += 12;
  proceed();
 case VARREF:
  deref_and_jump(x1,normalizeTextInPreFirst_2_3);
  *reasonp++ =  x1;
  goto normalizeTextInPreFirst_2_4;
  };
  goto normalizeTextInPreFirst_2_4;
 case VARREF:
  deref_and_jump(x0,normalizeTextInPreFirst_2_2);
  *reasonp++ =  x0;
  goto normalizeTextInPreFirst_2_4;
  };
  goto normalizeTextInPreFirst_2_4;
 case VARREF:
  deref_and_jump(a0,normalizeTextInPreFirst_2_1);
  *reasonp++ =  a0;
  goto normalizeTextInPreFirst_2_4;
  };
  goto normalizeTextInPreFirst_2_4;
 normalizeTextInPreFirst_2_4:
  otherwise(normalizeTextInPreFirst_2_interrupt);
 normalizeTextInPreFirst_2_5:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 normalizeTextInPreFirst_2_6:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_text_1)) goto normalizeTextInPreFirst_2_7;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xnormalizeTextInPre1_2);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = makesym(functor_text_1);
  allocp[5] = x4 = makeref(&allocp[5]);
  x3 = makefunctor(&allocp[4]);
  allocp[6] = x2;
  allocp[7] = x3;
  x5 = makecons(&allocp[6]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  unify_value(a1, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_util_xrmFirstLf_2);
  allocp[2] = x6 = makeref(&allocp[2]);
  allocp[3] = x4;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_util_xcrlfToLf_2);
  x7 = arg(x0, 0);
  allocp[6] = x7;
  allocp[7] = x6;
  qp = (struct goalrec*)&allocp[4];
  allocp += 8;
  proceed();
 case VARREF:
  deref_and_jump(x0,normalizeTextInPreFirst_2_6);
  *reasonp++ =  x0;
  goto normalizeTextInPreFirst_2_7;
  };
  goto normalizeTextInPreFirst_2_7;
 case VARREF:
  deref_and_jump(a0,normalizeTextInPreFirst_2_5);
  *reasonp++ =  a0;
  goto normalizeTextInPreFirst_2_7;
  };
  goto normalizeTextInPreFirst_2_7;
 normalizeTextInPreFirst_2_7:
  otherwise(normalizeTextInPreFirst_2_interrupt);
 normalizeTextInPreFirst_2_8:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 normalizeTextInPreFirst_2_9:
  if (isref(x0)) goto normalizeTextInPreFirst_2_11;
  gblt_pfunctor(x0,x1,normalizeTextInPreFirst_2_interrupt);
  gblt_arity(x0,x2,normalizeTextInPreFirst_2_interrupt);
 normalizeTextInPreFirst_2_10:
  switch ((unsigned long)x2) {
 case (unsigned long) makeint(1L):
  allocp[0] = x4 = makeref(&allocp[0]);
  allocp[1] = x0;
  x3 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x3);
  a0 = cdr_of(a0);
  a1 = x4;
  execute(normalizeTextInPre1_2_0);
  goto normalizeTextInPre1_2_ext_interrupt;
 case (unsigned long) makeint(2L):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xnormalizeTextInPre1_2);
  x3 = cdr_of(a0);
  allocp[2] = x3;
  allocp[3] = x4 = makeref(&allocp[3]);
  allocp[4] = x4;
  allocp[5] = x6 = makeref(&allocp[5]);
  x5 = makecons(&allocp[4]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  unify_value(a1, x5);
  allocp[0] = NILATOM;
  allocp[1] = x8 = makeref(&allocp[1]);
  x7 = makecons(&allocp[0]);
  allocp[2] = x7;
  allocp[3] = x10 = makeref(&allocp[3]);
  x9 = makecons(&allocp[2]);
  allocp[4] = x9;
  allocp[5] = x1;
  x11 = makecons(&allocp[4]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[8] = x6;
  allocp[9] = x11;
  allocp[10] = (q)(struct goalrec*)&allocp[6];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = x0;
  allocp[14] = x10;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_html_xnormalizeTextInPre_2);
  allocp[17] = x12 = makeref(&allocp[17]);
  allocp[18] = x8;
  allocp[19] = (q)(struct goalrec*)&allocp[15];
  allocp[20] = (q)(&predicate_functor__table_xarg_3);
  allocp[21] = makeint(2L);
  allocp[22] = x0;
  allocp[23] = x12;
  qp = (struct goalrec*)&allocp[19];
  allocp += 24;
  proceed();
  };
  goto normalizeTextInPreFirst_2_interrupt;
 normalizeTextInPreFirst_2_11:
  deref_and_jump(x0,normalizeTextInPreFirst_2_9);
  *reasonp++ =  x0;
  goto normalizeTextInPreFirst_2_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto normalizeTextInPreFirst_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,normalizeTextInPreFirst_2_8);
  *reasonp++ =  a0;
  goto normalizeTextInPreFirst_2_interrupt;
  };
  goto normalizeTextInPreFirst_2_interrupt;
 normalizeTextInPreFirst_2_ext_interrupt:
  reasonp = 0l;
 normalizeTextInPreFirst_2_interrupt:
  goto interrupt_2;
 }

 normalizeTextInPre1_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  a1 = qp->args[1];
  qp = qp->next;
 normalizeTextInPre1_2_clear_reason:
  reasonp = reasons;
 normalizeTextInPre1_2_0:
 normalizeTextInPre1_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 normalizeTextInPre1_2_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_text_1)) goto normalizeTextInPre1_2_4;
  x1 = cdr_of(a0);
 normalizeTextInPre1_2_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto normalizeTextInPre1_2_4;
  allocp[0] = makesym(functor_text_1);
  allocp[1] = x3 = makeref(&allocp[1]);
  x2 = makefunctor(&allocp[0]);
  allocp[2] = NILATOM;
  allocp[3] = x2;
  x4 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a1, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_util_xrmLastLf_2);
  allocp[2] = x5 = makeref(&allocp[2]);
  allocp[3] = x3;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_util_xcrlfToLf_2);
  x6 = arg(x0, 0);
  allocp[6] = x6;
  allocp[7] = x5;
  qp = (struct goalrec*)&allocp[4];
  allocp += 8;
  proceed();
 case VARREF:
  deref_and_jump(x1,normalizeTextInPre1_2_3);
  *reasonp++ =  x1;
  goto normalizeTextInPre1_2_4;
  };
  goto normalizeTextInPre1_2_4;
 case VARREF:
  deref_and_jump(x0,normalizeTextInPre1_2_2);
  *reasonp++ =  x0;
  goto normalizeTextInPre1_2_4;
  };
  goto normalizeTextInPre1_2_4;
 case VARREF:
  deref_and_jump(a0,normalizeTextInPre1_2_1);
  *reasonp++ =  a0;
  goto normalizeTextInPre1_2_4;
  };
  goto normalizeTextInPre1_2_4;
 normalizeTextInPre1_2_4:
  otherwise(normalizeTextInPre1_2_interrupt);
 normalizeTextInPre1_2_5:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 normalizeTextInPre1_2_6:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_text_1)) goto normalizeTextInPre1_2_7;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xnormalizeTextInPre1_2);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = makesym(functor_text_1);
  allocp[5] = x4 = makeref(&allocp[5]);
  x3 = makefunctor(&allocp[4]);
  allocp[6] = x2;
  allocp[7] = x3;
  x5 = makecons(&allocp[6]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  unify_value(a1, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_util_xcrlfToLf_2);
  x6 = arg(x0, 0);
  allocp[2] = x6;
  allocp[3] = x4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  proceed();
 case VARREF:
  deref_and_jump(x0,normalizeTextInPre1_2_6);
  *reasonp++ =  x0;
  goto normalizeTextInPre1_2_7;
  };
  goto normalizeTextInPre1_2_7;
 case VARREF:
  deref_and_jump(a0,normalizeTextInPre1_2_5);
  *reasonp++ =  a0;
  goto normalizeTextInPre1_2_7;
  };
  goto normalizeTextInPre1_2_7;
 normalizeTextInPre1_2_7:
  otherwise(normalizeTextInPre1_2_interrupt);
 normalizeTextInPre1_2_8:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 normalizeTextInPre1_2_9:
  if (isref(x0)) goto normalizeTextInPre1_2_11;
  gblt_pfunctor(x0,x1,normalizeTextInPre1_2_interrupt);
  gblt_arity(x0,x2,normalizeTextInPre1_2_interrupt);
 normalizeTextInPre1_2_10:
  switch ((unsigned long)x2) {
 case (unsigned long) makeint(1L):
  allocp[0] = x4 = makeref(&allocp[0]);
  allocp[1] = x0;
  x3 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x3);
  a0 = cdr_of(a0);
  a1 = x4;
  execute(normalizeTextInPre1_2_0);
  goto normalizeTextInPre1_2_ext_interrupt;
 case (unsigned long) makeint(2L):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xnormalizeTextInPre1_2);
  x3 = cdr_of(a0);
  allocp[2] = x3;
  allocp[3] = x4 = makeref(&allocp[3]);
  allocp[4] = x4;
  allocp[5] = x6 = makeref(&allocp[5]);
  x5 = makecons(&allocp[4]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  unify_value(a1, x5);
  allocp[0] = NILATOM;
  allocp[1] = x8 = makeref(&allocp[1]);
  x7 = makecons(&allocp[0]);
  allocp[2] = x7;
  allocp[3] = x10 = makeref(&allocp[3]);
  x9 = makecons(&allocp[2]);
  allocp[4] = x9;
  allocp[5] = x1;
  x11 = makecons(&allocp[4]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[8] = x6;
  allocp[9] = x11;
  allocp[10] = (q)(struct goalrec*)&allocp[6];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = x0;
  allocp[14] = x10;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_html_xnormalizeTextInPre_2);
  allocp[17] = x12 = makeref(&allocp[17]);
  allocp[18] = x8;
  allocp[19] = (q)(struct goalrec*)&allocp[15];
  allocp[20] = (q)(&predicate_functor__table_xarg_3);
  allocp[21] = makeint(2L);
  allocp[22] = x0;
  allocp[23] = x12;
  qp = (struct goalrec*)&allocp[19];
  allocp += 24;
  proceed();
  };
  goto normalizeTextInPre1_2_interrupt;
 normalizeTextInPre1_2_11:
  deref_and_jump(x0,normalizeTextInPre1_2_9);
  *reasonp++ =  x0;
  goto normalizeTextInPre1_2_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto normalizeTextInPre1_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,normalizeTextInPre1_2_8);
  *reasonp++ =  a0;
  goto normalizeTextInPre1_2_interrupt;
  };
  goto normalizeTextInPre1_2_interrupt;
 normalizeTextInPre1_2_ext_interrupt:
  reasonp = 0l;
 normalizeTextInPre1_2_interrupt:
  toppred = &predicate_html_xnormalizeTextInPre1_2;
  goto interrupt_2;
 }

 rmNullText_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  a1 = qp->args[1];
  qp = qp->next;
 rmNullText_2_clear_reason:
  reasonp = reasons;
 rmNullText_2_0:
 rmNullText_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 rmNullText_2_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_text_1)) goto rmNullText_2_4;
  x1 = arg(x0, 0);
 rmNullText_2_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto rmNullText_2_4;
  a0 = cdr_of(a0);
  execute(rmNullText_2_0);
  goto rmNullText_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,rmNullText_2_3);
  *reasonp++ =  x1;
  goto rmNullText_2_4;
  };
  goto rmNullText_2_4;
 case VARREF:
  deref_and_jump(x0,rmNullText_2_2);
  *reasonp++ =  x0;
  goto rmNullText_2_6;
  };
  goto rmNullText_2_4;
 rmNullText_2_4:
  gblt_pfunctor(x0,x1,rmNullText_2_6);
  gblt_arity(x0,x2,rmNullText_2_6);
 rmNullText_2_5:
  if (x2 != makeint(2L)) goto rmNullText_2_6;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xrmNullText_2);
  x3 = cdr_of(a0);
  allocp[2] = x3;
  allocp[3] = x4 = makeref(&allocp[3]);
  allocp[4] = x4;
  allocp[5] = x6 = makeref(&allocp[5]);
  x5 = makecons(&allocp[4]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  unify_value(a1, x5);
  allocp[0] = NILATOM;
  allocp[1] = x8 = makeref(&allocp[1]);
  x7 = makecons(&allocp[0]);
  allocp[2] = x7;
  allocp[3] = x10 = makeref(&allocp[3]);
  x9 = makecons(&allocp[2]);
  allocp[4] = x9;
  allocp[5] = x1;
  x11 = makecons(&allocp[4]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[8] = x6;
  allocp[9] = x11;
  allocp[10] = (q)(struct goalrec*)&allocp[6];
  allocp[11] = (q)(&predicate_html_xrmNullText_2);
  allocp[12] = x12 = makeref(&allocp[12]);
  allocp[13] = x8;
  allocp[14] = (q)(struct goalrec*)&allocp[10];
  allocp[15] = (q)(&predicate_functor__table_xarg_3);
  allocp[16] = makeint(2L);
  allocp[17] = x0;
  allocp[18] = x12;
  allocp[19] = (q)(struct goalrec*)&allocp[14];
  allocp[20] = (q)(&predicate_functor__table_xarg_3);
  allocp[21] = makeint(1L);
  allocp[22] = x0;
  allocp[23] = x10;
  qp = (struct goalrec*)&allocp[19];
  allocp += 24;
  proceed();
 case VARREF:
  deref_and_jump(a0,rmNullText_2_1);
  *reasonp++ =  a0;
  goto rmNullText_2_6;
  };
  goto rmNullText_2_6;
 rmNullText_2_6:
  otherwise(rmNullText_2_interrupt);
 rmNullText_2_7:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(rmNullText_2_0);
  goto rmNullText_2_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto rmNullText_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,rmNullText_2_7);
  *reasonp++ =  a0;
  goto rmNullText_2_interrupt;
  };
  goto rmNullText_2_interrupt;
 rmNullText_2_ext_interrupt:
  reasonp = 0l;
 rmNullText_2_interrupt:
  toppred = &predicate_html_xrmNullText_2;
  goto interrupt_2;
 }

 rmNullP_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  a1 = qp->args[1];
  qp = qp->next;
 rmNullP_2_clear_reason:
  reasonp = reasons;
 rmNullP_2_0:
 rmNullP_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 rmNullP_2_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_p_2)) goto rmNullP_2_4;
  x1 = arg(x0, 1);
 rmNullP_2_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto rmNullP_2_4;
  a0 = cdr_of(a0);
  execute(rmNullP_2_0);
  goto rmNullP_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,rmNullP_2_3);
  *reasonp++ =  x1;
  goto rmNullP_2_4;
  };
  goto rmNullP_2_4;
 case VARREF:
  deref_and_jump(x0,rmNullP_2_2);
  *reasonp++ =  x0;
  goto rmNullP_2_4;
  };
  goto rmNullP_2_4;
 case VARREF:
  deref_and_jump(a0,rmNullP_2_1);
  *reasonp++ =  a0;
  goto rmNullP_2_4;
  };
  goto rmNullP_2_4;
 rmNullP_2_4:
  otherwise(rmNullP_2_interrupt);
 rmNullP_2_5:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 rmNullP_2_6:
  if (isref(x0)) goto rmNullP_2_8;
  gblt_pfunctor(x0,x1,rmNullP_2_9);
  gblt_arity(x0,x2,rmNullP_2_9);
 rmNullP_2_7:
  if (x2 != makeint(2L)) goto rmNullP_2_9;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xrmNullP_2);
  x3 = cdr_of(a0);
  allocp[2] = x3;
  allocp[3] = x4 = makeref(&allocp[3]);
  allocp[4] = x4;
  allocp[5] = x6 = makeref(&allocp[5]);
  x5 = makecons(&allocp[4]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  unify_value(a1, x5);
  allocp[0] = NILATOM;
  allocp[1] = x8 = makeref(&allocp[1]);
  x7 = makecons(&allocp[0]);
  allocp[2] = x7;
  allocp[3] = x10 = makeref(&allocp[3]);
  x9 = makecons(&allocp[2]);
  allocp[4] = x9;
  allocp[5] = x1;
  x11 = makecons(&allocp[4]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[8] = x6;
  allocp[9] = x11;
  allocp[10] = (q)(struct goalrec*)&allocp[6];
  allocp[11] = (q)(&predicate_html_xrmNullP_2);
  allocp[12] = x12 = makeref(&allocp[12]);
  allocp[13] = x8;
  allocp[14] = (q)(struct goalrec*)&allocp[10];
  allocp[15] = (q)(&predicate_functor__table_xarg_3);
  allocp[16] = makeint(2L);
  allocp[17] = x0;
  allocp[18] = x12;
  allocp[19] = (q)(struct goalrec*)&allocp[14];
  allocp[20] = (q)(&predicate_functor__table_xarg_3);
  allocp[21] = makeint(1L);
  allocp[22] = x0;
  allocp[23] = x10;
  qp = (struct goalrec*)&allocp[19];
  allocp += 24;
  proceed();
 rmNullP_2_8:
  deref_and_jump(x0,rmNullP_2_6);
  *reasonp++ =  x0;
  goto rmNullP_2_9;
 case VARREF:
  deref_and_jump(a0,rmNullP_2_5);
  *reasonp++ =  a0;
  goto rmNullP_2_9;
  };
  goto rmNullP_2_9;
 rmNullP_2_9:
  otherwise(rmNullP_2_interrupt);
 rmNullP_2_10:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(rmNullText_2_0);
  goto rmNullText_2_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto rmNullP_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,rmNullP_2_10);
  *reasonp++ =  a0;
  goto rmNullP_2_interrupt;
  };
  goto rmNullP_2_interrupt;
 rmNullP_2_ext_interrupt:
  reasonp = 0l;
 rmNullP_2_interrupt:
  goto interrupt_2;
 }

 getAttr_3_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 getAttr_3_clear_reason:
  reasonp = reasons;
 getAttr_3_0:
 getAttr_3_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 getAttr_3_2:
  if (isref(x0)) goto getAttr_3_8;
  gblt_pfunctor(x0,x1,getAttr_3_9);
 getAttr_3_3:
  if (isref(x1)) goto getAttr_3_7;
 getAttr_3_4:
  if (isref(x1)) goto getAttr_3_6;
  if_not_equal(x1, a0, getAttr_3_9);
  gblt_arity(x0,x2,getAttr_3_9);
 getAttr_3_5:
  if (x2 != makeint(1L)) goto getAttr_3_9;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(1L);
  allocp[3] = x0;
  allocp[4] = a2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 getAttr_3_6:
  deref_and_jump(x1,getAttr_3_4);
  *reasonp++ =  x1;
  goto getAttr_3_9;
 getAttr_3_7:
  deref_and_jump(x1,getAttr_3_3);
  *reasonp++ =  x1;
  goto getAttr_3_9;
 getAttr_3_8:
  deref_and_jump(x0,getAttr_3_2);
  *reasonp++ =  x0;
  goto getAttr_3_9;
 case VARREF:
  deref_and_jump(a1,getAttr_3_1);
  *reasonp++ =  a1;
  goto getAttr_3_9;
  };
  goto getAttr_3_9;
 getAttr_3_9:
  otherwise(getAttr_3_interrupt);
 getAttr_3_10:
  switch (ptagof(a1)) {
 case CONS:
  a1 = cdr_of(a1);
  execute(getAttr_3_0);
  goto getAttr_3_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto getAttr_3_interrupt;
  x0 = makefunctor(&string_const_0);
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,getAttr_3_10);
  *reasonp++ =  a1;
  goto getAttr_3_interrupt;
  };
  goto getAttr_3_interrupt;
 getAttr_3_ext_interrupt:
  reasonp = 0l;
 getAttr_3_interrupt:
  goto interrupt_3;
 }

 hasAttr_3_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 hasAttr_3_clear_reason:
  reasonp = reasons;
 hasAttr_3_0:
 hasAttr_3_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 hasAttr_3_2:
  if (isref(x0)) goto hasAttr_3_8;
  gblt_pfunctor(x0,x1,hasAttr_3_9);
 hasAttr_3_3:
  if (isref(x1)) goto hasAttr_3_7;
 hasAttr_3_4:
  if (isref(x1)) goto hasAttr_3_6;
  if_not_equal(x1, a0, hasAttr_3_9);
  gblt_arity(x0,x2,hasAttr_3_9);
 hasAttr_3_5:
  if (x2 != makeint(1L)) goto hasAttr_3_9;
  x3 = makesym(atom_true);
  unify_value(a2, x3);
  proceed();
 hasAttr_3_6:
  deref_and_jump(x1,hasAttr_3_4);
  *reasonp++ =  x1;
  goto hasAttr_3_9;
 hasAttr_3_7:
  deref_and_jump(x1,hasAttr_3_3);
  *reasonp++ =  x1;
  goto hasAttr_3_9;
 hasAttr_3_8:
  deref_and_jump(x0,hasAttr_3_2);
  *reasonp++ =  x0;
  goto hasAttr_3_9;
 case VARREF:
  deref_and_jump(a1,hasAttr_3_1);
  *reasonp++ =  a1;
  goto hasAttr_3_9;
  };
  goto hasAttr_3_9;
 hasAttr_3_9:
  otherwise(hasAttr_3_interrupt);
 hasAttr_3_10:
  switch (ptagof(a1)) {
 case CONS:
  a1 = cdr_of(a1);
  execute(hasAttr_3_0);
  goto hasAttr_3_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto hasAttr_3_interrupt;
  x0 = makesym(atom_false);
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,hasAttr_3_10);
  *reasonp++ =  a1;
  goto hasAttr_3_interrupt;
  };
  goto hasAttr_3_interrupt;
 hasAttr_3_ext_interrupt:
  reasonp = 0l;
 hasAttr_3_interrupt:
  goto interrupt_3;
 }

 unescape_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20, x21, x22, x23;
  a1 = qp->args[1];
  qp = qp->next;
 unescape_2_clear_reason:
  reasonp = reasons;
 unescape_2_0:
 unescape_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 unescape_2_2:
  switch (ptagof(x0)) {
 case ATOMIC:
 unescape_2_3:
  if (x0 != makeint(38L)) goto unescape_2_64;
  x1 = cdr_of(a0);
 unescape_2_4:
  switch (ptagof(x1)) {
 case CONS:
  x2 = car_of(x1);
 unescape_2_5:
  switch (ptagof(x2)) {
 case ATOMIC:
 unescape_2_6:
  switch ((unsigned long)x2) {
 case (unsigned long) makeint(108L):
  x3 = cdr_of(x1);
 unescape_2_7:
  switch (ptagof(x3)) {
 case CONS:
  x4 = car_of(x3);
 unescape_2_8:
  switch (ptagof(x4)) {
 case ATOMIC:
 unescape_2_9:
  if (x4 != makeint(116L)) goto unescape_2_64;
  x5 = cdr_of(x3);
 unescape_2_10:
  switch (ptagof(x5)) {
 case CONS:
  x6 = car_of(x5);
 unescape_2_11:
  switch (ptagof(x6)) {
 case ATOMIC:
 unescape_2_12:
  if (x6 != makeint(59L)) goto unescape_2_64;
  allocp[0] = x8 = makeref(&allocp[0]);
  allocp[1] = makeint(60L);
  x7 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x7);
  a0 = cdr_of(x5);
  a1 = x8;
  execute(unescape_2_0);
  goto unescape_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x6,unescape_2_11);
  *reasonp++ =  x6;
  goto unescape_2_64;
  };
  goto unescape_2_64;
 case VARREF:
  deref_and_jump(x5,unescape_2_10);
  *reasonp++ =  x5;
  goto unescape_2_64;
  };
  goto unescape_2_64;
 case VARREF:
  deref_and_jump(x4,unescape_2_8);
  *reasonp++ =  x4;
  goto unescape_2_64;
  };
  goto unescape_2_64;
 case VARREF:
  deref_and_jump(x3,unescape_2_7);
  *reasonp++ =  x3;
  goto unescape_2_64;
  };
  goto unescape_2_64;
 case (unsigned long) makeint(103L):
  x3 = cdr_of(x1);
 unescape_2_13:
  switch (ptagof(x3)) {
 case CONS:
  x4 = car_of(x3);
 unescape_2_14:
  switch (ptagof(x4)) {
 case ATOMIC:
 unescape_2_15:
  if (x4 != makeint(116L)) goto unescape_2_64;
  x5 = cdr_of(x3);
 unescape_2_16:
  switch (ptagof(x5)) {
 case CONS:
  x6 = car_of(x5);
 unescape_2_17:
  switch (ptagof(x6)) {
 case ATOMIC:
 unescape_2_18:
  if (x6 != makeint(59L)) goto unescape_2_64;
  allocp[0] = x8 = makeref(&allocp[0]);
  allocp[1] = makeint(62L);
  x7 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x7);
  a0 = cdr_of(x5);
  a1 = x8;
  execute(unescape_2_0);
  goto unescape_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x6,unescape_2_17);
  *reasonp++ =  x6;
  goto unescape_2_64;
  };
  goto unescape_2_64;
 case VARREF:
  deref_and_jump(x5,unescape_2_16);
  *reasonp++ =  x5;
  goto unescape_2_64;
  };
  goto unescape_2_64;
 case VARREF:
  deref_and_jump(x4,unescape_2_14);
  *reasonp++ =  x4;
  goto unescape_2_64;
  };
  goto unescape_2_64;
 case VARREF:
  deref_and_jump(x3,unescape_2_13);
  *reasonp++ =  x3;
  goto unescape_2_64;
  };
  goto unescape_2_64;
 case (unsigned long) makeint(97L):
  x3 = cdr_of(x1);
 unescape_2_19:
  switch (ptagof(x3)) {
 case CONS:
  x4 = car_of(x3);
 unescape_2_20:
  switch (ptagof(x4)) {
 case ATOMIC:
 unescape_2_21:
  if (x4 != makeint(109L)) goto unescape_2_64;
  x5 = cdr_of(x3);
 unescape_2_22:
  switch (ptagof(x5)) {
 case CONS:
  x6 = car_of(x5);
 unescape_2_23:
  switch (ptagof(x6)) {
 case ATOMIC:
 unescape_2_24:
  if (x6 != makeint(112L)) goto unescape_2_64;
  x7 = cdr_of(x5);
 unescape_2_25:
  switch (ptagof(x7)) {
 case CONS:
  x8 = car_of(x7);
 unescape_2_26:
  switch (ptagof(x8)) {
 case ATOMIC:
 unescape_2_27:
  if (x8 != makeint(59L)) goto unescape_2_64;
  allocp[0] = x10 = makeref(&allocp[0]);
  allocp[1] = makeint(38L);
  x9 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x9);
  a0 = cdr_of(x7);
  a1 = x10;
  execute(unescape_2_0);
  goto unescape_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x8,unescape_2_26);
  *reasonp++ =  x8;
  goto unescape_2_64;
  };
  goto unescape_2_64;
 case VARREF:
  deref_and_jump(x7,unescape_2_25);
  *reasonp++ =  x7;
  goto unescape_2_64;
  };
  goto unescape_2_64;
 case VARREF:
  deref_and_jump(x6,unescape_2_23);
  *reasonp++ =  x6;
  goto unescape_2_64;
  };
  goto unescape_2_64;
 case VARREF:
  deref_and_jump(x5,unescape_2_22);
  *reasonp++ =  x5;
  goto unescape_2_64;
  };
  goto unescape_2_64;
 case VARREF:
  deref_and_jump(x4,unescape_2_20);
  *reasonp++ =  x4;
  goto unescape_2_64;
  };
  goto unescape_2_64;
 case VARREF:
  deref_and_jump(x3,unescape_2_19);
  *reasonp++ =  x3;
  goto unescape_2_64;
  };
  goto unescape_2_64;
 case (unsigned long) makeint(113L):
  x3 = cdr_of(x1);
 unescape_2_28:
  switch (ptagof(x3)) {
 case CONS:
  x4 = car_of(x3);
 unescape_2_29:
  switch (ptagof(x4)) {
 case ATOMIC:
 unescape_2_30:
  if (x4 != makeint(117L)) goto unescape_2_64;
  x5 = cdr_of(x3);
 unescape_2_31:
  switch (ptagof(x5)) {
 case CONS:
  x6 = car_of(x5);
 unescape_2_32:
  switch (ptagof(x6)) {
 case ATOMIC:
 unescape_2_33:
  if (x6 != makeint(111L)) goto unescape_2_64;
  x7 = cdr_of(x5);
 unescape_2_34:
  switch (ptagof(x7)) {
 case CONS:
  x8 = car_of(x7);
 unescape_2_35:
  switch (ptagof(x8)) {
 case ATOMIC:
 unescape_2_36:
  if (x8 != makeint(116L)) goto unescape_2_64;
  x9 = cdr_of(x7);
 unescape_2_37:
  switch (ptagof(x9)) {
 case CONS:
  x10 = car_of(x9);
 unescape_2_38:
  switch (ptagof(x10)) {
 case ATOMIC:
 unescape_2_39:
  if (x10 != makeint(59L)) goto unescape_2_64;
  allocp[0] = x12 = makeref(&allocp[0]);
  allocp[1] = makeint(34L);
  x11 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x11);
  a0 = cdr_of(x9);
  a1 = x12;
  execute(unescape_2_0);
  goto unescape_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x10,unescape_2_38);
  *reasonp++ =  x10;
  goto unescape_2_64;
  };
  goto unescape_2_64;
 case VARREF:
  deref_and_jump(x9,unescape_2_37);
  *reasonp++ =  x9;
  goto unescape_2_64;
  };
  goto unescape_2_64;
 case VARREF:
  deref_and_jump(x8,unescape_2_35);
  *reasonp++ =  x8;
  goto unescape_2_64;
  };
  goto unescape_2_64;
 case VARREF:
  deref_and_jump(x7,unescape_2_34);
  *reasonp++ =  x7;
  goto unescape_2_64;
  };
  goto unescape_2_64;
 case VARREF:
  deref_and_jump(x6,unescape_2_32);
  *reasonp++ =  x6;
  goto unescape_2_64;
  };
  goto unescape_2_64;
 case VARREF:
  deref_and_jump(x5,unescape_2_31);
  *reasonp++ =  x5;
  goto unescape_2_64;
  };
  goto unescape_2_64;
 case VARREF:
  deref_and_jump(x4,unescape_2_29);
  *reasonp++ =  x4;
  goto unescape_2_64;
  };
  goto unescape_2_64;
 case VARREF:
  deref_and_jump(x3,unescape_2_28);
  *reasonp++ =  x3;
  goto unescape_2_64;
  };
  goto unescape_2_64;
 case (unsigned long) makeint(35L):
  x3 = cdr_of(x1);
 unescape_2_40:
  switch (ptagof(x3)) {
 case CONS:
  x4 = cdr_of(x3);
 unescape_2_41:
  switch (ptagof(x4)) {
 case CONS:
  x5 = car_of(x4);
 unescape_2_42:
  switch (ptagof(x5)) {
 case ATOMIC:
 unescape_2_43:
  if (x5 != makeint(59L)) goto unescape_2_46;
  x6 = car_of(x3);
 unescape_2_44:
  if (!isint(x6)) goto unescape_2_45;
  x7 = makeint(48L);
  gblt_less_or_eq(x7,x6,unescape_2_46);
  x8 = makeint(57L);
  gblt_less_or_eq(x6,x8,unescape_2_46);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xunescape_2);
  x9 = cdr_of(x4);
  allocp[2] = x9;
  allocp[3] = x10 = makeref(&allocp[3]);
  allocp[4] = x10;
  allocp[5] = x12 = makeref(&allocp[5]);
  x11 = makecons(&allocp[4]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  unify_value(a1, x11);
  allocp[0] = NILATOM;
  allocp[1] = x6;
  x13 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_util_xatoi_2);
  allocp[4] = x13;
  allocp[5] = x12;
  qp = (struct goalrec*)&allocp[2];
  allocp += 6;
  proceed();
 unescape_2_45:
  if (!isref(x6)) goto unescape_2_46;
  deref_and_jump(x6,unescape_2_44);
  *reasonp++ =  x6;
  goto unescape_2_46;
 case VARREF:
  deref_and_jump(x5,unescape_2_42);
  *reasonp++ =  x5;
  goto unescape_2_46;
  };
  goto unescape_2_46;
 unescape_2_46:
  x6 = cdr_of(x4);
 unescape_2_47:
  switch (ptagof(x6)) {
 case CONS:
  x7 = car_of(x6);
 unescape_2_48:
  switch (ptagof(x7)) {
 case ATOMIC:
 unescape_2_49:
  if (x7 != makeint(59L)) goto unescape_2_54;
  x8 = car_of(x3);
 unescape_2_50:
  if (!isint(x8)) goto unescape_2_53;
  x9 = makeint(48L);
  gblt_less_or_eq(x9,x8,unescape_2_54);
  x10 = makeint(57L);
  gblt_less_or_eq(x8,x10,unescape_2_54);
 unescape_2_51:
  if (!isint(x5)) goto unescape_2_52;
  x11 = makeint(48L);
  gblt_less_or_eq(x11,x5,unescape_2_54);
  x12 = makeint(57L);
  gblt_less_or_eq(x5,x12,unescape_2_54);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xunescape_2);
  x13 = cdr_of(x6);
  allocp[2] = x13;
  allocp[3] = x14 = makeref(&allocp[3]);
  allocp[4] = x14;
  allocp[5] = x16 = makeref(&allocp[5]);
  x15 = makecons(&allocp[4]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  unify_value(a1, x15);
  allocp[0] = NILATOM;
  allocp[1] = x5;
  x17 = makecons(&allocp[0]);
  allocp[2] = x17;
  allocp[3] = x8;
  x18 = makecons(&allocp[2]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_util_xatoi_2);
  allocp[6] = x18;
  allocp[7] = x16;
  qp = (struct goalrec*)&allocp[4];
  allocp += 8;
  proceed();
 unescape_2_52:
  if (!isref(x5)) goto unescape_2_54;
  deref_and_jump(x5,unescape_2_51);
  *reasonp++ =  x5;
  goto unescape_2_54;
 unescape_2_53:
  if (!isref(x8)) goto unescape_2_54;
  deref_and_jump(x8,unescape_2_50);
  *reasonp++ =  x8;
  goto unescape_2_54;
 case VARREF:
  deref_and_jump(x7,unescape_2_48);
  *reasonp++ =  x7;
  goto unescape_2_54;
  };
  goto unescape_2_54;
 unescape_2_54:
  x8 = cdr_of(x6);
 unescape_2_55:
  switch (ptagof(x8)) {
 case CONS:
  x9 = car_of(x8);
 unescape_2_56:
  switch (ptagof(x9)) {
 case ATOMIC:
 unescape_2_57:
  if (x9 != makeint(59L)) goto unescape_2_64;
  x10 = car_of(x3);
 unescape_2_58:
  if (!isint(x10)) goto unescape_2_63;
  x11 = makeint(48L);
  gblt_less_or_eq(x11,x10,unescape_2_64);
  x12 = makeint(57L);
  gblt_less_or_eq(x10,x12,unescape_2_64);
 unescape_2_59:
  if (!isint(x5)) goto unescape_2_62;
  x13 = makeint(48L);
  gblt_less_or_eq(x13,x5,unescape_2_64);
  x14 = makeint(57L);
  gblt_less_or_eq(x5,x14,unescape_2_64);
 unescape_2_60:
  if (!isint(x7)) goto unescape_2_61;
  x15 = makeint(48L);
  gblt_less_or_eq(x15,x7,unescape_2_64);
  x16 = makeint(57L);
  gblt_less_or_eq(x7,x16,unescape_2_64);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_html_xunescape_2);
  x17 = cdr_of(x8);
  allocp[2] = x17;
  allocp[3] = x18 = makeref(&allocp[3]);
  allocp[4] = x18;
  allocp[5] = x20 = makeref(&allocp[5]);
  x19 = makecons(&allocp[4]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  unify_value(a1, x19);
  allocp[0] = NILATOM;
  allocp[1] = x7;
  x21 = makecons(&allocp[0]);
  allocp[2] = x21;
  allocp[3] = x5;
  x22 = makecons(&allocp[2]);
  allocp[4] = x22;
  allocp[5] = x10;
  x23 = makecons(&allocp[4]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_util_xatoi_2);
  allocp[8] = x23;
  allocp[9] = x20;
  qp = (struct goalrec*)&allocp[6];
  allocp += 10;
  proceed();
 unescape_2_61:
  if (!isref(x7)) goto unescape_2_64;
  deref_and_jump(x7,unescape_2_60);
  *reasonp++ =  x7;
  goto unescape_2_64;
 unescape_2_62:
  if (!isref(x5)) goto unescape_2_64;
  deref_and_jump(x5,unescape_2_59);
  *reasonp++ =  x5;
  goto unescape_2_64;
 unescape_2_63:
  if (!isref(x10)) goto unescape_2_64;
  deref_and_jump(x10,unescape_2_58);
  *reasonp++ =  x10;
  goto unescape_2_64;
 case VARREF:
  deref_and_jump(x9,unescape_2_56);
  *reasonp++ =  x9;
  goto unescape_2_64;
  };
  goto unescape_2_64;
 case VARREF:
  deref_and_jump(x8,unescape_2_55);
  *reasonp++ =  x8;
  goto unescape_2_64;
  };
  goto unescape_2_64;
 case VARREF:
  deref_and_jump(x6,unescape_2_47);
  *reasonp++ =  x6;
  goto unescape_2_64;
  };
  goto unescape_2_64;
 case VARREF:
  deref_and_jump(x4,unescape_2_41);
  *reasonp++ =  x4;
  goto unescape_2_64;
  };
  goto unescape_2_64;
 case VARREF:
  deref_and_jump(x3,unescape_2_40);
  *reasonp++ =  x3;
  goto unescape_2_64;
  };
  goto unescape_2_64;
  };
  goto unescape_2_64;
 case VARREF:
  deref_and_jump(x2,unescape_2_5);
  *reasonp++ =  x2;
  goto unescape_2_64;
  };
  goto unescape_2_64;
 case VARREF:
  deref_and_jump(x1,unescape_2_4);
  *reasonp++ =  x1;
  goto unescape_2_64;
  };
  goto unescape_2_64;
 case VARREF:
  deref_and_jump(x0,unescape_2_2);
  *reasonp++ =  x0;
  goto unescape_2_64;
  };
  goto unescape_2_64;
 case VARREF:
  deref_and_jump(a0,unescape_2_1);
  *reasonp++ =  a0;
  goto unescape_2_64;
  };
  goto unescape_2_64;
 unescape_2_64:
  otherwise(unescape_2_interrupt);
 unescape_2_65:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(unescape_2_0);
  goto unescape_2_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto unescape_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,unescape_2_65);
  *reasonp++ =  a0;
  goto unescape_2_interrupt;
  };
  goto unescape_2_interrupt;
 unescape_2_ext_interrupt:
  reasonp = 0l;
 unescape_2_interrupt:
  toppred = &predicate_html_xunescape_2;
  goto interrupt_2;
 }
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_html);
}
