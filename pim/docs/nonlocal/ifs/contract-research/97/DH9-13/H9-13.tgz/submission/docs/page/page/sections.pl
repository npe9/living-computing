# LaTeX2HTML 96.1 (Feb 5, 1996)
# Associate sections original text with physical files.

$key = q/0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$section_info{$key} = '0%:%page.html%:%W-KLIC: A Logic Language for Internet Programming' unless ($section_info{$key}); 
$done{"page.html"} = 1;

1;

