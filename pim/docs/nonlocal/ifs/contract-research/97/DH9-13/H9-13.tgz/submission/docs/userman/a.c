main()
{
	if ((1>2) && (2>3) && (3<4))
		printf("hi\n");
	else
		printf("no\n");
}
