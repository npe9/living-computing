extern PortDescriptor *NetClientConnect();
extern int NetWrite();
extern int NetIsThereInput();
extern int NetRead();
extern void NetCloseConnection();
extern char *NetReturnAddress();
