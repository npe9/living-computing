#include <stdio.h>
main(){
		char buf[200];
		char *cmd = "klic abc1.kl1 tohtml.kl1 util.kl1 html.kl1 inttostr.kl1 ping.kl1 ; a.out";
		FILE *ptr, *fptr;

		
		if((ptr = popen(cmd, "r")) != NULL){
			fptr = fopen("dump", "w");

			while(fgets(buf, 200, ptr) != NULL){

				fprintf(fptr , "%s", buf);
				
			}
		fclose(fptr);
		}

}

