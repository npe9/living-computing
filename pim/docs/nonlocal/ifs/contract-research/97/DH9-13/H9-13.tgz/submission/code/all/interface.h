#include "cci.h"

/*--------------------------------------------------*/
/*               Prototypes                         */
/*--------------------------------------------------*/

int MosaicInitialize();
int MosaicIsConnected(MCCIPort);
MCCIPort MosaicConnect(char *,int);
int MosaicDisconnect(MCCIPort);
int MosaicIsThereInput(MCCIPort);
char *MosaicGetResponse(MCCIPort);
int MosaicActivateAnchorTransmission(MCCIPort,int);
int MosaicDeactivateAnchorTransmission(MCCIPort);
int MosaicGet(MCCIPort,char *,int,int,char *);
int MosaicActivateFilter(MCCIPort,char *);
int MosaicDeactivateFilter(MCCIPort,char *);

static char *MosaicHandleAddOutput(MCCIPort,char *);
char *MosaicReadBrowserViewOutput(MCCIPort,char *);
static void MosaicReadSendDataOutput(MCCIPort);
static int MosaicWrite(MCCIPort,char *,int);

char *get_machine_name();

