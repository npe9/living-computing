/* Compiled by KLIC compiler version 3.001 (Thu Jun  5 20:19:10 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"
#include <stdio.h>
#include <stdlib.h>
#define BUFSIZE 100

module module_ping();
Const struct predicate predicate_ping_xping__select_2 =
   { module_ping, 0, 2 };
Const struct predicate predicate_ping_xping__select_3 =
   { module_ping, 1, 3 };
Const struct predicate predicate_ping_xping__select_2F3_240_6 =
   { module_ping, 2, 6 };
Const struct predicate predicate_ping_xping_2 =
   { module_ping, 3, 2 };
extern Const struct predicate predicate_util_xlosToLst_2;
extern Const struct predicate predicate_util_xatoi_2;
declare_method_table_of(byte__string);

module module_ping(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_0 =
      declare_string_constant_8(0,0);
  q a0, a1, a2, a3, a4, a5;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, ping__select_2_top);
    case_pred(1, ping__select_3_top);
    case_pred(2, ping__select_2F3_240_6_top);
    last_case_pred(3, ping_2_top);
  }

 ping__select_2_top: {
  q x0, x1, x2, x3;
  qp = qp->next;
 ping__select_2_clear_reason:
  reasonp = reasons;
 ping__select_2_0:
 ping__select_2_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != NILATOM) goto ping__select_2_2;
  x0 = makefunctor(&string_const_0);
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,ping__select_2_1);
  *reasonp++ =  a0;
  goto ping__select_2_2;
  };
  goto ping__select_2_2;
 ping__select_2_2:
  otherwise(ping__select_2_interrupt);
 ping__select_2_3:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = makesym(functor_server_2);
  x1 = car_of(a0);
  allocp[1] = x1;
  allocp[2] = x2 = makeref(&allocp[2]);
  x0 = makefunctor(&allocp[0]);
  allocp[3] = (q)qp;
  allocp[4] = (q)(&predicate_ping_xping__select_3);
  x3 = cdr_of(a0);
  allocp[5] = x3;
  allocp[6] = x0;
  allocp[7] = a1;
  a0 = car_of(a0);
  a1 = x2;
  qp = (struct goalrec*)&allocp[3];
  allocp += 8;
  execute(ping_2_0);
  goto ping_2_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,ping__select_2_3);
  *reasonp++ =  a0;
  goto ping__select_2_interrupt;
  };
  goto ping__select_2_interrupt;
 ping__select_2_ext_interrupt:
  reasonp = 0l;
 ping__select_2_interrupt:
  goto interrupt_2;
 }

 ping__select_3_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  qp = qp->next;
 ping__select_3_clear_reason:
  reasonp = reasons;
 ping__select_3_0:
 ping__select_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != NILATOM) goto ping__select_3_3;
 ping__select_3_2:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_server_2)) goto ping__select_3_3;
  x0 = arg(a1, 0);
  unify(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,ping__select_3_2);
  *reasonp++ =  a1;
  goto ping__select_3_3;
  };
  goto ping__select_3_3;
 case VARREF:
  deref_and_jump(a0,ping__select_3_1);
  *reasonp++ =  a0;
  goto ping__select_3_3;
  };
  goto ping__select_3_3;
 ping__select_3_3:
  otherwise(ping__select_3_interrupt);
 ping__select_3_4:
  switch (ptagof(a0)) {
 case CONS:
 ping__select_3_5:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_server_2)) goto ping__select_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ping_xping__select_2F3_240_6);
  allocp[2] = x0 = makeref(&allocp[2]);
  x1 = arg(a1, 1);
  allocp[3] = x1;
  x2 = cdr_of(a0);
  allocp[4] = x2;
  x3 = car_of(a0);
  allocp[5] = x3;
  allocp[6] = a2;
  x4 = arg(a1, 0);
  allocp[7] = x4;
  a0 = x3;
  a1 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  execute(ping_2_0);
  goto ping_2_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,ping__select_3_5);
  *reasonp++ =  a1;
  goto ping__select_3_interrupt;
  };
  goto ping__select_3_interrupt;
 case VARREF:
  deref_and_jump(a0,ping__select_3_4);
  *reasonp++ =  a0;
  goto ping__select_3_interrupt;
  };
  goto ping__select_3_interrupt;
 ping__select_3_ext_interrupt:
  reasonp = 0l;
 ping__select_3_interrupt:
  toppred = &predicate_ping_xping__select_3;
  goto interrupt_3;
 }

 ping__select_2F3_240_6_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 ping__select_2F3_240_6_clear_reason:
  reasonp = reasons;
 ping__select_2F3_240_6_0:
 ping__select_2F3_240_6_1:
  if (!isint(a0)) goto ping__select_2F3_240_6_4;
 ping__select_2F3_240_6_2:
  if (!isint(a1)) goto ping__select_2F3_240_6_3;
  gblt_less(a0,a1,ping__select_2F3_240_6_5);
  allocp[0] = makesym(functor_server_2);
  allocp[1] = a3;
  allocp[2] = a0;
  x0 = makefunctor(&allocp[0]);
  a0 = a2;
  a1 = x0;
  a2 = a4;
  allocp += 3;
  execute(ping__select_3_0);
  goto ping__select_3_ext_interrupt;
 ping__select_2F3_240_6_3:
  if (!isref(a1)) goto ping__select_2F3_240_6_5;
  deref_and_jump(a1,ping__select_2F3_240_6_2);
  *reasonp++ =  a1;
  goto ping__select_2F3_240_6_5;
 ping__select_2F3_240_6_4:
  if (!isref(a0)) goto ping__select_2F3_240_6_5;
  deref_and_jump(a0,ping__select_2F3_240_6_1);
  *reasonp++ =  a0;
  goto ping__select_2F3_240_6_5;
 ping__select_2F3_240_6_5:
  otherwise(ping__select_2F3_240_6_interrupt);
  allocp[0] = makesym(functor_server_2);
  allocp[1] = a5;
  allocp[2] = a1;
  x0 = makefunctor(&allocp[0]);
  a0 = a2;
  a1 = x0;
  a2 = a4;
  allocp += 3;
  execute(ping__select_3_0);
  goto ping__select_3_ext_interrupt;
 ping__select_2F3_240_6_ext_interrupt:
  reasonp = 0l;
 ping__select_2F3_240_6_interrupt:
  goto interrupt_6;
 }

 ping_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20, x21, x22, x23, x24, x25, x26, x27, x28, x29, x30;
  qp = qp->next;
 ping_2_clear_reason:
  reasonp = reasons;
 ping_2_0:
 ping_2_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
 ping_2_2:
  if (!isgobj(a0)) goto ping_2_interrupt;
  if (!isclass(a0,byte__string)) goto ping_2_interrupt;
  
	{
		char *host = (char *)convert_klic_string_to_c_string(a0);
		char *command = "ping -s %s 64 5";
		char *ptr;
		char buf[BUFSIZE];
		FILE *fptr;

		ptr = (char *)malloc(strlen(host)+strlen(command)+1);
		sprintf(ptr, command, host);

		if((fptr = popen(ptr, "r")) != NULL)
			while(fgets(buf, BUFSIZE, fptr));

		x0 = (q)convert_c_string_to_klic_string(buf, allocp);
		allocp = (q*)heapp;
	}
  allocp[0] = x1 = makeref(&allocp[0]);
  generic_arg[0] = x1;
  call_generic(x0, functor_size_1, 1);
  x2 = makeint(1L);
  bblt_sub_no_check_y(x1,x2,x3);
  x4 = makeint(0L);
  generic_arg[0] = x4;
  generic_arg[1] = x3;
  x5 = makeint(61L);
  generic_arg[2] = x5;
  allocp[0] = x6 = makeref(&allocp[0]);
  generic_arg[3] = x6;
  call_generic(x0, functor_search__character_4, 1);
  x7 = makeint(1L);
  bblt_add_no_check_y(x6,x7,x8);
  generic_arg[0] = x8;
  allocp[0] = x9 = makeref(&allocp[0]);
  generic_arg[1] = x9;
  allocp[1] = x10 = makeref(&allocp[1]);
  generic_arg[2] = x10;
  call_generic(x0, functor_split_3, 2);
  allocp[0] = x11 = makeref(&allocp[0]);
  generic_arg[0] = x11;
  call_generic(x10, functor_size_1, 1);
  x12 = makeint(1L);
  bblt_sub_no_check_y(x11,x12,x13);
  x14 = makeint(0L);
  generic_arg[0] = x14;
  generic_arg[1] = x13;
  x15 = makeint(47L);
  generic_arg[2] = x15;
  allocp[0] = x16 = makeref(&allocp[0]);
  generic_arg[3] = x16;
  call_generic(x10, functor_search__character_4, 1);
  x17 = makeint(1L);
  bblt_add_no_check_y(x16,x17,x18);
  generic_arg[0] = x18;
  allocp[0] = x19 = makeref(&allocp[0]);
  generic_arg[1] = x19;
  allocp[1] = x20 = makeref(&allocp[1]);
  generic_arg[2] = x20;
  call_generic(x10, functor_split_3, 2);
  allocp[0] = x21 = makeref(&allocp[0]);
  generic_arg[0] = x21;
  call_generic(x20, functor_size_1, 1);
  x22 = makeint(1L);
  bblt_sub_no_check_y(x21,x22,x23);
  x24 = makeint(0L);
  generic_arg[0] = x24;
  generic_arg[1] = x23;
  x25 = makeint(47L);
  generic_arg[2] = x25;
  allocp[0] = x26 = makeref(&allocp[0]);
  generic_arg[3] = x26;
  call_generic(x20, functor_search__character_4, 1);
  generic_arg[0] = x26;
  allocp[0] = x27 = makeref(&allocp[0]);
  generic_arg[1] = x27;
  allocp[1] = x28 = makeref(&allocp[1]);
  generic_arg[2] = x28;
  call_generic(x20, functor_split_3, 2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_util_xatoi_2);
  allocp[2] = x29 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = NILATOM;
  allocp[5] = x27;
  x30 = makecons(&allocp[4]);
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_util_xlosToLst_2);
  allocp[8] = x30;
  allocp[9] = x29;
  qp = (struct goalrec*)&allocp[6];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a0,ping_2_1);
  *reasonp++ =  a0;
  goto ping_2_interrupt;
  };
  goto ping_2_interrupt;
 ping_2_ext_interrupt:
  reasonp = 0l;
 ping_2_interrupt:
  toppred = &predicate_ping_xping_2;
  goto interrupt_2;
 }
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_ping);
}
