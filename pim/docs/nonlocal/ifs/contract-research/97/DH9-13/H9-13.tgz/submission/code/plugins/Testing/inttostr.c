/* Compiled by KLIC compiler version 3.001 (Thu Jun  5 20:19:10 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_inttostr();
Const struct predicate predicate_inttostr_xintegertostring_2 =
   { module_inttostr, 0, 2 };
Const struct predicate predicate_inttostr_xinttostr_3 =
   { module_inttostr, 1, 3 };
Const struct predicate predicate_inttostr_xinttostr_2F3_240_3 =
   { module_inttostr, 2, 3 };
extern q string_g_new();

module module_inttostr(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  static Const unsigned char strconst_body_0[4] =
    "0";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_0 =
      declare_string_constant_8(strconst_body_0,1);
  static Const unsigned char strconst_body_1[4] =
    "1";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_1 =
      declare_string_constant_8(strconst_body_1,1);
  static Const unsigned char strconst_body_2[4] =
    "2";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_2 =
      declare_string_constant_8(strconst_body_2,1);
  static Const unsigned char strconst_body_3[4] =
    "3";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_3 =
      declare_string_constant_8(strconst_body_3,1);
  static Const unsigned char strconst_body_4[4] =
    "4";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_4 =
      declare_string_constant_8(strconst_body_4,1);
  static Const unsigned char strconst_body_5[4] =
    "5";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_5 =
      declare_string_constant_8(strconst_body_5,1);
  static Const unsigned char strconst_body_6[4] =
    "6";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_6 =
      declare_string_constant_8(strconst_body_6,1);
  static Const unsigned char strconst_body_7[4] =
    "7";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_7 =
      declare_string_constant_8(strconst_body_7,1);
  static Const unsigned char strconst_body_8[4] =
    "8";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_8 =
      declare_string_constant_8(strconst_body_8,1);
  static Const unsigned char strconst_body_9[4] =
    "9";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_9 =
      declare_string_constant_8(strconst_body_9,1);
  q a0, a1, a2;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, integertostring_2_top);
    case_pred(1, inttostr_3_top);
    last_case_pred(2, inttostr_2F3_240_3_top);
  }

 integertostring_2_top: {
  q x0, x1, x2;
  qp = qp->next;
 integertostring_2_clear_reason:
  reasonp = reasons;
 integertostring_2_0:
  x0 = makeint(0L);
  generic_arg[0] = x0;
  x1 = makeint(8L);
  generic_arg[1] = x1;
  new_generic(string_g_new, 2, x2, 0);
  a2 = a1;
  a1 = x2;
  execute(inttostr_3_0);
  goto inttostr_3_ext_interrupt;
 integertostring_2_ext_interrupt:
  reasonp = 0l;
 integertostring_2_interrupt:
  goto interrupt_2;
 }

 inttostr_3_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  qp = qp->next;
 inttostr_3_clear_reason:
  reasonp = reasons;
 inttostr_3_0:
 inttostr_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 inttostr_3_2:
  if (a0 != makeint(0L)) goto inttostr_3_7;
 inttostr_3_3:
  switch (ptagof(a1)) {
 case FUNCTOR:
 inttostr_3_4:
  if (!isgobj(a1)) goto inttostr_3_7;
 inttostr_3_5:
  gblt_is_string(a1,inttostr_3_7);
  gblt_size_of_string(a1,x0,inttostr_3_7);
 inttostr_3_6:
  if (x0 != makeint(0L)) goto inttostr_3_7;
  gblt_element_size_of_string(a1,x1,inttostr_3_7);
  x2 = makefunctor(&string_const_0);
  unify_value(a2, x2);
  proceed();
 case VARREF:
  deref_and_jump(a1,inttostr_3_3);
  *reasonp++ =  a1;
  goto inttostr_3_7;
  };
  goto inttostr_3_7;
 case VARREF:
  deref_and_jump(a0,inttostr_3_1);
  *reasonp++ =  a0;
  goto inttostr_3_7;
  };
  goto inttostr_3_7;
 inttostr_3_7:
  otherwise(inttostr_3_interrupt);
 inttostr_3_8:
  switch (ptagof(a0)) {
 case ATOMIC:
 inttostr_3_9:
  if (a0 != makeint(0L)) goto inttostr_3_10;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,inttostr_3_8);
  *reasonp++ =  a0;
  goto inttostr_3_10;
  };
  goto inttostr_3_10;
 inttostr_3_10:
  otherwise(inttostr_3_interrupt);
  x0 = makeint(10L);
  bblt_mod_no_check_y(a0,x0,x1);
  x2 = makeint(10L);
  bblt_div_no_check_y(a0,x2,x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_inttostr_xinttostr_3);
  allocp[2] = x3;
  allocp[3] = x4 = makeref(&allocp[3]);
  allocp[4] = a2;
  a0 = x1;
  a2 = x4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(inttostr_2F3_240_3_0);
  goto inttostr_2F3_240_3_ext_interrupt;
 inttostr_3_ext_interrupt:
  reasonp = 0l;
 inttostr_3_interrupt:
  toppred = &predicate_inttostr_xinttostr_3;
  goto interrupt_3;
 }

 inttostr_2F3_240_3_top: {
  q x0;
  a2 = qp->args[2];
  qp = qp->next;
 inttostr_2F3_240_3_clear_reason:
  reasonp = reasons;
 inttostr_2F3_240_3_0:
 inttostr_2F3_240_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 inttostr_2F3_240_3_2:
  switch ((unsigned long)a0) {
 case (unsigned long) makeint(0L):
  generic_arg[0] = a1;
  generic_arg[1] = a2;
  x0 = makefunctor(&string_const_0);
  call_generic(x0, functor_join_2, 0);
  proceed();
 case (unsigned long) makeint(1L):
  generic_arg[0] = a1;
  generic_arg[1] = a2;
  x0 = makefunctor(&string_const_1);
  call_generic(x0, functor_join_2, 0);
  proceed();
 case (unsigned long) makeint(2L):
  generic_arg[0] = a1;
  generic_arg[1] = a2;
  x0 = makefunctor(&string_const_2);
  call_generic(x0, functor_join_2, 0);
  proceed();
 case (unsigned long) makeint(3L):
  generic_arg[0] = a1;
  generic_arg[1] = a2;
  x0 = makefunctor(&string_const_3);
  call_generic(x0, functor_join_2, 0);
  proceed();
 case (unsigned long) makeint(4L):
  generic_arg[0] = a1;
  generic_arg[1] = a2;
  x0 = makefunctor(&string_const_4);
  call_generic(x0, functor_join_2, 0);
  proceed();
 case (unsigned long) makeint(5L):
  generic_arg[0] = a1;
  generic_arg[1] = a2;
  x0 = makefunctor(&string_const_5);
  call_generic(x0, functor_join_2, 0);
  proceed();
 case (unsigned long) makeint(6L):
  generic_arg[0] = a1;
  generic_arg[1] = a2;
  x0 = makefunctor(&string_const_6);
  call_generic(x0, functor_join_2, 0);
  proceed();
 case (unsigned long) makeint(7L):
  generic_arg[0] = a1;
  generic_arg[1] = a2;
  x0 = makefunctor(&string_const_7);
  call_generic(x0, functor_join_2, 0);
  proceed();
 case (unsigned long) makeint(8L):
  generic_arg[0] = a1;
  generic_arg[1] = a2;
  x0 = makefunctor(&string_const_8);
  call_generic(x0, functor_join_2, 0);
  proceed();
 case (unsigned long) makeint(9L):
  generic_arg[0] = a1;
  generic_arg[1] = a2;
  x0 = makefunctor(&string_const_9);
  call_generic(x0, functor_join_2, 0);
  proceed();
  };
  goto inttostr_2F3_240_3_interrupt;
 case VARREF:
  deref_and_jump(a0,inttostr_2F3_240_3_1);
  *reasonp++ =  a0;
  goto inttostr_2F3_240_3_interrupt;
  };
  goto inttostr_2F3_240_3_interrupt;
 inttostr_2F3_240_3_ext_interrupt:
  reasonp = 0l;
 inttostr_2F3_240_3_interrupt:
  toppred = &predicate_inttostr_xinttostr_2F3_240_3;
  goto interrupt_3;
 }
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_inttostr);
}
