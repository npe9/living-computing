/************************************************************************
 *									*
 * FILE		:	cio.h						*
 *									*
 * FUNCTION	: 	convert_to_klic_string(char *string,    	*
 *					       q **allocp_ptr)		*
 *			char *string :- 'C' string to be converted      *
 *									*
 *			char **allocp_ptr :- Is always &allocp when     *
 *				called as a 'C' inline function		*
 *									*
 * PURPOSE	:	This function returns the type q which is a     *
 *			string in KLIC. It suitably increments allocp	*
 *			to keep it alligned, and prevent overlapping    *
 *									*
 * AUTHOR	:	Koustubh Deopura				*
 *									*
 * DATE LAST MODIFIED	:	10/03/97				*
 *									*
 * MODIFICATION SUMMARY	:						*
 ***********************************************************************/
/* q convert_to_klic_string(char*, q**); */

q convert_to_klic_string(char *ptr, q **allocp_ptr){
	q klicstring;
        klicstring = (q)convert_c_string_to_klic_string(ptr, *allocp_ptr); 
        *allocp_ptr+=(strlen(ptr)+2);
	return klicstring;
}
