/*
Copyright (C) 1997 $B9b66(B $B?-(B (TAKAHASHI Shin)
*/

/* Cone class */

#include "Shape.h"
#include <Inventor/nodes/SoCone.h>
#include <Inventor/engines/SoCalculator.h>
#include <Inventor/engines/SoCompose.h>

class Cone : public Shape {
	SoCone	*ensui;
public:
	Cone(void);
	void setRadius(float radius);
	void setHeight(float height);
	void setVariable(int type, int val);
	void setTransition(int type, int val1, int val2);
	void endTransition(void);
};
