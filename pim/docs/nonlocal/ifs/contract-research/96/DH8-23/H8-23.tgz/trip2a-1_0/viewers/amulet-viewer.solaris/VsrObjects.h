/*
Copyright (C) 1997 $B9b66(B $B?-(B (TAKAHASHI Shin)
*/

#define	SPHERE		0
#define	CYLINDER	1
#define	BOX		2
#define	LINE		3
#define	WORD		4
#define	CONE		5
