tree*speedoScrollbar.orientation:	HORIZONTAL
tree*speedoScrollbar.paneMinimum:	30
tree*speedoScrollbar.paneMaximum:	30
