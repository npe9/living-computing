/*
Copyright (C) 1997 TAKAHASHI Shin
*/

/* Sphere class */

#include "Shape.h"

class Sphere : public Shape {
public:
	void draw(float time);
};
