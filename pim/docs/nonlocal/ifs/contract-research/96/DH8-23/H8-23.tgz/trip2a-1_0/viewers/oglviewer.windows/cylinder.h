/*
Copyright (C) 1997 TAKAHASHI Shin
*/

/* Cylinder class */

#include "Shape.h"

class Cylinder : public Shape {
public:
	void draw(float time);
};
