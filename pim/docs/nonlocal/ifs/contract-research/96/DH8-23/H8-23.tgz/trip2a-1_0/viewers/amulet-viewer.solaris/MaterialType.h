/*
Copyright (C) 1997 $B9b66(B $B?-(B (TAKAHASHI Shin)
*/

typedef enum {
	AMBIENT, 
	DIFFUSE, 
	SPECULAR,
	EMISSIVE,
	SHININESS,
	TRANSPARENCY
}MaterialType;
