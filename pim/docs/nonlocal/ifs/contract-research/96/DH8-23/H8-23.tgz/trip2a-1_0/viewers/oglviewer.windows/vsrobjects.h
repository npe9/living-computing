/*
Copyright (C) 1997 TAKAHASHI Shin
*/

#define	SPHERE		0
#define	CYLINDER	1
#define	BOX		2
#define	LINE		3
#define	WORD		4
#define	CONE		5
