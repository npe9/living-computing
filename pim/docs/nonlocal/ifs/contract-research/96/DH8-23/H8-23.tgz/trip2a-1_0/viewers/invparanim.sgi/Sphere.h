/*
Copyright (C) 1997 $B9b66(B $B?-(B (TAKAHASHI Shin)
*/

/* Sphere class */

#include "Shape.h"
#include <Inventor/nodes/SoSphere.h>

class Sphere : public Shape {
	SoSphere	*maru;
public:
	Sphere(void);
	Sphere(SoSphere *obj);
	void setRadius(float radius);
	void setVariable(int type, int val);
	void setTransition(int type, int val1, int val2);
	void endTransition(void);
};
