/*
Copyright (C) 1997 $B9b66(B $B?-(B (TAKAHASHI Shin)
*/


extern Node	*mknode(int op, Node *lp, Node *rp);
extern Node	*mkleaf(int f, int number, int type);
extern Node	*cpnode(Node *p);
extern int	hash(char *s);
extern int	findvar(char *name);
extern int	searchvar(char *name);
extern Term	*mkterm(int var, double cof, Term *next);
extern Pict	*mkpict(char *name,Pict *f);
extern int     error(int n);
