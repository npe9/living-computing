/*
Copyright (C) 1997 TAKAHASHI Shin
*/


typedef struct _ShapeObject {
        int	name;
        int	type;
	Shape 	*object;
	int  	empty;   /* TRUE if empty */
	int  	deleted;
}ShapeObject;

#define TABLESIZE 1024
#define TABLEMASK 1023
