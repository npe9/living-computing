/*
Copyright (C) 1997 $B9b66(B $B?-(B (TAKAHASHI Shin)
*/

/* TransitionType.h */
typedef enum { box, sphere, cylinder, line} ShapeType;

typedef enum {
	straight,
	circuitous,
	lazy,
	immediate,
	creation,
	deletion,
	multipath
}TransType;

typedef struct _Transition {
	ShapeType	figure;
	TransType	path;
	SbVec3f		v1;
	SbVec3f		v2;
	union _attr {
		struct _box {
			TransType width;
			TransType depth;
			TransType height;
		}box;
		struct _sphere {
			TransType radius;
		}sphere;
		struct _cylinder {
			TransType radius;
			TransType height;
		}cylinder;
		struct _line {
			TransType radius;
		}line;
	} attr;
} Transition;
