/*
Copyright (C) 1997 $B9b66(B $B?-(B (TAKAHASHI Shin)
*/

/* Shape class */

#include "Shape.h"
#include <Inventor/nodes/SoCube.h>

class Box : public Shape {
	SoCube		*hako;
public:
	Box(void);
	void setWidth(float width);
	void setHeight(float height);
	void setDepth(float depth);
	void setSize(float width, float height, float depth);
	void setVariable(int type, int val);
	void setTransition(int type, int val1, int val2);
	void endTransition(void);
};
