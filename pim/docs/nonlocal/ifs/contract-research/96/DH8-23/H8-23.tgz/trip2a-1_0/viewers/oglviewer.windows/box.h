/*
Copyright (C) 1997 TAKAHASHI Shin
*/

/* Box class */

#include "Shape.h"

class Box : public Shape {
public:
	void draw(float time);
};
