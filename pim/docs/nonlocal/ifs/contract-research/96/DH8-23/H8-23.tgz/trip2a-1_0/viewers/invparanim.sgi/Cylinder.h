/*
Copyright (C) 1997 $B9b66(B $B?-(B (TAKAHASHI Shin)
*/

/* Cylinder class */

#include "Shape.h"
#include <Inventor/nodes/SoCylinder.h>
#include <Inventor/engines/SoCalculator.h>
#include <Inventor/engines/SoCompose.h>

class Cylinder : public Shape {
	SoCylinder	*enchu;
	SoCalculator	*connection;
	SoComposeRotation	*kaiten;
public:
	Cylinder(void);
	~Cylinder(void);
	void setRadius(float radius);
	void setHeight(float height);
	void setVariable(int type, int val);
	void setTransition(int type, int val1, int val2);
	void endTransition(void);
	void setupConnection(Shape *end1, Shape *end2);
};
