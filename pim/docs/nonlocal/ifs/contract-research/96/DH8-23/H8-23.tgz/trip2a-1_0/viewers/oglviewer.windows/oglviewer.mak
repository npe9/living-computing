# Microsoft Developer Studio Generated NMAKE File, Format Version 40001
# ** �ҏW���Ȃ��ł������� **

# TARGTYPE "Win32 (x86) Console Application" 0x0103

!IF "$(CFG)" == ""
CFG=oglviewer - Win32 Debug
!MESSAGE �\�����w�肳��Ă��܂���B��̫�Ă� oglviewer - Win32 Debug ��ݒ肵�܂��B
!ENDIF 

!IF "$(CFG)" != "oglviewer - Win32 Release" && "$(CFG)" !=\
 "oglviewer - Win32 Debug"
!MESSAGE �w�肳�ꂽ ����� Ӱ�� "$(CFG)" �͐���������܂���B
!MESSAGE ����� ײݏ��ϸ� 'CFG' ���`���邱�Ƃɂ����
!MESSAGE NMAKE ���s��������� Ӱ�ނ��w��ł��܂��B�Ⴆ��:
!MESSAGE 
!MESSAGE NMAKE /f "oglviewer.mak" CFG="oglviewer - Win32 Debug"
!MESSAGE 
!MESSAGE �I���\������� Ӱ��:
!MESSAGE 
!MESSAGE "oglviewer - Win32 Release" ("Win32 (x86) Console Application" �p)
!MESSAGE "oglviewer - Win32 Debug" ("Win32 (x86) Console Application" �p)
!MESSAGE 
!ERROR �����ȍ\�����w�肳��Ă��܂��B
!ENDIF 

!IF "$(OS)" == "Windows_NT"
NULL=
!ELSE 
NULL=nul
!ENDIF 
################################################################################
# Begin Project
# PROP Target_Last_Scanned "oglviewer - Win32 Debug"
CPP=cl.exe
RSC=rc.exe

!IF  "$(CFG)" == "oglviewer - Win32 Release"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "Release"
# PROP BASE Intermediate_Dir "Release"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "Release"
# PROP Intermediate_Dir "Release"
# PROP Target_Dir ""
OUTDIR=.\Release
INTDIR=.\Release

ALL : "$(OUTDIR)\oglviewer.exe"

CLEAN : 
	-@erase ".\Release\oglviewer.exe"
	-@erase ".\Release\Sphere.obj"
	-@erase ".\Release\ogl-animator.obj"
	-@erase ".\Release\Box.obj"
	-@erase ".\Release\Shape.obj"
	-@erase ".\Release\Cylinder.obj"
	-@erase ".\Release\Line.obj"
	-@erase ".\Release\Script1.res"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

# ADD BASE CPP /nologo /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_CONSOLE" /YX /c
# ADD CPP /nologo /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_CONSOLE" /YX /c
CPP_PROJ=/nologo /ML /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_CONSOLE"\
 /Fp"$(INTDIR)/oglviewer.pch" /YX /Fo"$(INTDIR)/" /c 
CPP_OBJS=.\Release/
CPP_SBRS=
# ADD BASE RSC /l 0x411 /d "NDEBUG"
# ADD RSC /l 0x411 /d "NDEBUG"
RSC_PROJ=/l 0x411 /fo"$(INTDIR)/Script1.res" /d "NDEBUG" 
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
BSC32_FLAGS=/nologo /o"$(OUTDIR)/oglviewer.bsc" 
BSC32_SBRS=
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /machine:I386
# ADD LINK32 opengl32.lib glaux.lib glu32.lib kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /machine:I386
LINK32_FLAGS=opengl32.lib glaux.lib glu32.lib kernel32.lib user32.lib gdi32.lib\
 winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib\
 uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /incremental:no\
 /pdb:"$(OUTDIR)/oglviewer.pdb" /machine:I386 /out:"$(OUTDIR)/oglviewer.exe" 
LINK32_OBJS= \
	"$(INTDIR)/Sphere.obj" \
	"$(INTDIR)/ogl-animator.obj" \
	"$(INTDIR)/Box.obj" \
	"$(INTDIR)/Shape.obj" \
	"$(INTDIR)/Cylinder.obj" \
	"$(INTDIR)/Line.obj" \
	"$(INTDIR)/Script1.res"

"$(OUTDIR)\oglviewer.exe" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ELSEIF  "$(CFG)" == "oglviewer - Win32 Debug"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "oglviewe"
# PROP BASE Intermediate_Dir "oglviewe"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "oglviewe"
# PROP Intermediate_Dir "oglviewe"
# PROP Target_Dir ""
OUTDIR=.\oglviewe
INTDIR=.\oglviewe

ALL : "$(OUTDIR)\oglviewer.exe"

CLEAN : 
	-@erase ".\oglviewe\vc40.pdb"
	-@erase ".\oglviewe\vc40.idb"
	-@erase ".\oglviewe\oglviewer.exe"
	-@erase ".\oglviewe\Box.obj"
	-@erase ".\oglviewe\Sphere.obj"
	-@erase ".\oglviewe\Cylinder.obj"
	-@erase ".\oglviewe\Line.obj"
	-@erase ".\oglviewe\ogl-animator.obj"
	-@erase ".\oglviewe\Shape.obj"
	-@erase ".\oglviewe\Script1.res"
	-@erase ".\oglviewe\oglviewer.ilk"
	-@erase ".\oglviewe\oglviewer.pdb"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

# ADD BASE CPP /nologo /W3 /Gm /GX /Zi /Od /D "WIN32" /D "_DEBUG" /D "_CONSOLE" /YX /c
# ADD CPP /nologo /W3 /Gm /GX /Zi /Od /D "WIN32" /D "_DEBUG" /D "_CONSOLE" /YX /c
CPP_PROJ=/nologo /MLd /W3 /Gm /GX /Zi /Od /D "WIN32" /D "_DEBUG" /D "_CONSOLE"\
 /Fp"$(INTDIR)/oglviewer.pch" /YX /Fo"$(INTDIR)/" /Fd"$(INTDIR)/" /c 
CPP_OBJS=.\oglviewe/
CPP_SBRS=
# ADD BASE RSC /l 0x411 /d "_DEBUG"
# ADD RSC /l 0x411 /d "_DEBUG"
RSC_PROJ=/l 0x411 /fo"$(INTDIR)/Script1.res" /d "_DEBUG" 
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
BSC32_FLAGS=/nologo /o"$(OUTDIR)/oglviewer.bsc" 
BSC32_SBRS=
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /debug /machine:I386
# ADD LINK32 opengl32.lib glaux.lib glu32.lib kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /debug /machine:I386
LINK32_FLAGS=opengl32.lib glaux.lib glu32.lib kernel32.lib user32.lib gdi32.lib\
 winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib\
 uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /incremental:yes\
 /pdb:"$(OUTDIR)/oglviewer.pdb" /debug /machine:I386\
 /out:"$(OUTDIR)/oglviewer.exe" 
LINK32_OBJS= \
	"$(INTDIR)/Box.obj" \
	"$(INTDIR)/Sphere.obj" \
	"$(INTDIR)/Cylinder.obj" \
	"$(INTDIR)/Line.obj" \
	"$(INTDIR)/ogl-animator.obj" \
	"$(INTDIR)/Shape.obj" \
	"$(INTDIR)/Script1.res"

"$(OUTDIR)\oglviewer.exe" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ENDIF 

.c{$(CPP_OBJS)}.obj:
   $(CPP) $(CPP_PROJ) $<  

.cpp{$(CPP_OBJS)}.obj:
   $(CPP) $(CPP_PROJ) $<  

.cxx{$(CPP_OBJS)}.obj:
   $(CPP) $(CPP_PROJ) $<  

.c{$(CPP_SBRS)}.sbr:
   $(CPP) $(CPP_PROJ) $<  

.cpp{$(CPP_SBRS)}.sbr:
   $(CPP) $(CPP_PROJ) $<  

.cxx{$(CPP_SBRS)}.sbr:
   $(CPP) $(CPP_PROJ) $<  

################################################################################
# Begin Target

# Name "oglviewer - Win32 Release"
# Name "oglviewer - Win32 Debug"

!IF  "$(CFG)" == "oglviewer - Win32 Release"

!ELSEIF  "$(CFG)" == "oglviewer - Win32 Debug"

!ENDIF 

################################################################################
# Begin Source File

SOURCE=.\VsrObjects.h

!IF  "$(CFG)" == "oglviewer - Win32 Release"

!ELSEIF  "$(CFG)" == "oglviewer - Win32 Debug"

!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\VarType.h

!IF  "$(CFG)" == "oglviewer - Win32 Release"

!ELSEIF  "$(CFG)" == "oglviewer - Win32 Debug"

!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\TransitionType.h

!IF  "$(CFG)" == "oglviewer - Win32 Release"

!ELSEIF  "$(CFG)" == "oglviewer - Win32 Debug"

!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\Sphere.h

!IF  "$(CFG)" == "oglviewer - Win32 Release"

!ELSEIF  "$(CFG)" == "oglviewer - Win32 Debug"

!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\Sphere.cpp
DEP_CPP_SPHER=\
	".\Sphere.h"\
	".\Shape.h"\
	".\glos.h"\
	{$(INCLUDE)}"\gl\GL.H"\
	{$(INCLUDE)}"\gl\GLU.H"\
	{$(INCLUDE)}"\gl\GLAUX.H"\
	".\TransitionType.h"\
	".\VarType.h"\
	".\MaterialType.h"\
	
NODEP_CPP_SPHER=\
	".\glaux.h"\
	

"$(INTDIR)\Sphere.obj" : $(SOURCE) $(DEP_CPP_SPHER) "$(INTDIR)"


# End Source File
################################################################################
# Begin Source File

SOURCE=.\ShapeTable.h

!IF  "$(CFG)" == "oglviewer - Win32 Release"

!ELSEIF  "$(CFG)" == "oglviewer - Win32 Debug"

!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\Shape.h

!IF  "$(CFG)" == "oglviewer - Win32 Release"

!ELSEIF  "$(CFG)" == "oglviewer - Win32 Debug"

!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\Shape.cpp
DEP_CPP_SHAPE=\
	".\Shape.h"\
	".\glos.h"\
	{$(INCLUDE)}"\gl\GL.H"\
	{$(INCLUDE)}"\gl\GLU.H"\
	{$(INCLUDE)}"\gl\GLAUX.H"\
	".\TransitionType.h"\
	".\VarType.h"\
	".\MaterialType.h"\
	
NODEP_CPP_SHAPE=\
	".\glaux.h"\
	

"$(INTDIR)\Shape.obj" : $(SOURCE) $(DEP_CPP_SHAPE) "$(INTDIR)"


# End Source File
################################################################################
# Begin Source File

SOURCE=".\ogl-animator.cpp"
DEP_CPP_OGL_A=\
	".\glos.h"\
	{$(INCLUDE)}"\gl\GL.H"\
	{$(INCLUDE)}"\gl\GLU.H"\
	{$(INCLUDE)}"\gl\GLAUX.H"\
	".\Box.h"\
	".\Line.h"\
	".\Sphere.h"\
	".\Cylinder.h"\
	".\ShapeTable.h"\
	".\VsrObjects.h"\
	".\TransitionType.h"\
	".\Shape.h"\
	".\VarType.h"\
	".\MaterialType.h"\
	
NODEP_CPP_OGL_A=\
	".\glaux.h"\
	

"$(INTDIR)\ogl-animator.obj" : $(SOURCE) $(DEP_CPP_OGL_A) "$(INTDIR)"


# End Source File
################################################################################
# Begin Source File

SOURCE=.\MaterialType.h

!IF  "$(CFG)" == "oglviewer - Win32 Release"

!ELSEIF  "$(CFG)" == "oglviewer - Win32 Debug"

!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\Line.h

!IF  "$(CFG)" == "oglviewer - Win32 Release"

!ELSEIF  "$(CFG)" == "oglviewer - Win32 Debug"

!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\Line.cpp
DEP_CPP_LINE_=\
	".\Line.h"\
	".\Shape.h"\
	".\glos.h"\
	{$(INCLUDE)}"\gl\GL.H"\
	{$(INCLUDE)}"\gl\GLU.H"\
	{$(INCLUDE)}"\gl\GLAUX.H"\
	".\TransitionType.h"\
	".\VarType.h"\
	".\MaterialType.h"\
	
NODEP_CPP_LINE_=\
	".\glaux.h"\
	

"$(INTDIR)\Line.obj" : $(SOURCE) $(DEP_CPP_LINE_) "$(INTDIR)"


# End Source File
################################################################################
# Begin Source File

SOURCE=.\glos.h

!IF  "$(CFG)" == "oglviewer - Win32 Release"

!ELSEIF  "$(CFG)" == "oglviewer - Win32 Debug"

!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\Cylinder.h

!IF  "$(CFG)" == "oglviewer - Win32 Release"

!ELSEIF  "$(CFG)" == "oglviewer - Win32 Debug"

!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\Cylinder.cpp
DEP_CPP_CYLIN=\
	".\Cylinder.h"\
	".\Shape.h"\
	".\glos.h"\
	{$(INCLUDE)}"\gl\GL.H"\
	{$(INCLUDE)}"\gl\GLU.H"\
	{$(INCLUDE)}"\gl\GLAUX.H"\
	".\TransitionType.h"\
	".\VarType.h"\
	".\MaterialType.h"\
	
NODEP_CPP_CYLIN=\
	".\glaux.h"\
	

"$(INTDIR)\Cylinder.obj" : $(SOURCE) $(DEP_CPP_CYLIN) "$(INTDIR)"


# End Source File
################################################################################
# Begin Source File

SOURCE=.\Box.h

!IF  "$(CFG)" == "oglviewer - Win32 Release"

!ELSEIF  "$(CFG)" == "oglviewer - Win32 Debug"

!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\Box.cpp
DEP_CPP_BOX_C=\
	".\Box.h"\
	".\Shape.h"\
	".\glos.h"\
	{$(INCLUDE)}"\gl\GL.H"\
	{$(INCLUDE)}"\gl\GLU.H"\
	{$(INCLUDE)}"\gl\GLAUX.H"\
	".\TransitionType.h"\
	".\VarType.h"\
	".\MaterialType.h"\
	
NODEP_CPP_BOX_C=\
	".\glaux.h"\
	

"$(INTDIR)\Box.obj" : $(SOURCE) $(DEP_CPP_BOX_C) "$(INTDIR)"


# End Source File
################################################################################
# Begin Source File

SOURCE=.\oglviewe\Script1.rc

!IF  "$(CFG)" == "oglviewer - Win32 Release"


"$(INTDIR)\Script1.res" : $(SOURCE) "$(INTDIR)"
   $(RSC) /l 0x411 /fo"$(INTDIR)/Script1.res" /i "oglviewe" /d "NDEBUG"\
 $(SOURCE)


!ELSEIF  "$(CFG)" == "oglviewer - Win32 Debug"


"$(INTDIR)\Script1.res" : $(SOURCE) "$(INTDIR)"
   $(RSC) /l 0x411 /fo"$(INTDIR)/Script1.res" /i "oglviewe" /d "_DEBUG"\
 $(SOURCE)


!ENDIF 

# End Source File
# End Target
# End Project
################################################################################
