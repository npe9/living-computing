/*
Copyright (C) 1997 TAKAHASHI Shin
*/

typedef enum {
	AMBIENT, 
	DIFFUSE, 
	SPECULAR,
	EMISSIVE,
	SHININESS,
	TRANSPARENCY
}MaterialType;
