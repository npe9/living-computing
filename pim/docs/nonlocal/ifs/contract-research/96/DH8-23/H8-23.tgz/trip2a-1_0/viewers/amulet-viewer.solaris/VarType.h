/*
Copyright (C) 1997 $B9b66(B $B?-(B (TAKAHASHI Shin)
*/

#define VAR_D	0
#define VAR_H	1
#define VAR_R	2
#define VAR_W	3
#define VAR_X	4
#define VAR_Y	5
#define VAR_Z	6
