/*
Copyright (C) 1997 $B9b66(B $B?-(B (TAKAHASHI Shin)
*/

/* Word class */

#include "Shape.h"
#include <Inventor/nodes/SoText2.h>

class Word : public Shape {
	char	mytext[64];
	SoText2		*moji;
public:
	Word(void);
	void setString(char *text, char *mode);
	void setVariable(int type, int val);
	void setTransition(int type, int val1, int val2);
	void endTransition(void);

	void deleteAfterTransition(void);
};
