/*
Copyright (C) 1997 TAKAHASHI Shin
*/

/* Line class */

#include "Shape.h"

class Line : public Shape {
	Shape	*end1;
	Shape	*end2;
public:
	void draw(float time);
	void setupConnection(Shape *e1, Shape *e2);
};
