/* 
 *  $B%m%\%C%H%3%s%H%m!<%k%*%V%8%'%/%H(B
 *  Copyright (c) 1997  Fumio Mizoguchi
 */

import java.applet.Applet;
import java.net.URL;
import java.io.*;
import java.net.*;
import java.awt.*;

 
/***   $B2>A[%m%\%C%H@)8f%b%8%e!<%k(B  ***/
class V3D implements Runnable{
    Thread thread = null;
    Model3D md;
    V_World wd;
    boolean painted = true;
    boolean Robot = true;
    boolean grip = false;
    float xtheta, ytheta;
    String mdname = null;
    String message = null;
    VERT vert;
    MP_MJ mp_mj = new MP_MJ();
    double mpj_w = mp_mj.w, mpj_s = mp_mj.s, mpj_e = mp_mj.e, mpj_p = mp_mj.p, mpj_r = mp_mj.r; 
    int fr_num;
    public boolean hold=false;
    int block_num = 0 ,in_block = 0;
    double point[] = new double[5];
    double old_point[] = new double[5];
    double return_point[] = new double[5];
    String SS;
    Thread movingThread;
    public boolean running = false;
    public boolean success = true;
    public int crash = 0;
    double loc[] = new double[3];
    boolean emagencyStop = false;

/* speed_set Please number
   speed_set = 1 <- slow
   speed_set = 10 <- fast */
    int speed_set = 7;

/* drop_speed Please number
   drop_speed = 30 <- slow
   drop_speed = 5 <- fast */
    int drop_speed = 5;

/* koma suu Please number */
    int flame_per_sec = 4;

    double Rx,Ry,Rz;

    int push_rec = 0;

    /* $B%m%\%C%H:BI8$N@_Dj(B */
    V3D(double Rx, double Ry, double Rz, V_World wd) {
	this.wd = wd;
	this.Rx = Rx;
	this.Ry = Ry;
	this.Rz = Rz;
	vert = new VERT(Rx/10,Ry/10,Rz);
        Model3D m = new Model3D(vert,Robot);
        md = m;
        m.findBB();
        m.compress();
	double old_point[] = {0,160,371,-90,0};
	this.old_point = old_point;
	SS = "home";
    }
    
    /* $B%m%\%C%H:BI8$NJQ99(B */
    public void C_Locate(double x, double y, double z){
	vert.Change_L(x/10,y/10,z);
	this.Rx = x;
	this.Ry = y;
	this.Rz = z;
        Model3D m = new Model3D(vert,Robot);
        md = m;
        m.findBB();
        m.compress();
    }

    public boolean GripClose(){
	int i;
	double rw_obj[] = new double[4];
	if(grip == false){
	    point[2] = old_point[2];
	    old_point = point;
	    grip = true;
	    int num_b = 0;
		    
	    for(i=0; i<wd.block_num; i++){
		int go = 1;
		if (wd.block_data[i][0] > 0) go = 40;
		rw_obj = RW_change(wd.block_data[i]);
		if(gosa(rw_obj,point,go) == true){

		    block_num = i;
		    hold = true;
		    wd.block_data[i][0] ++;
		    i = wd.block_num;
		}
	    }
	    try{wait(1000/flame_per_sec);}
	    catch(InterruptedException e){}
	    return true;
	}
	else  {
	    point[2] = old_point[2];
	    old_point = point;
	    return true;
	}
    }

    public boolean GripOpen(){
	if(grip){
	    point[2] = old_point[2];
	    old_point = point;

	    grip = false;
	    if(hold == true) {  
		wd.block_data[block_num][0] --;
		if (wd.block_data[block_num][0] == 0){
		    double rw_po[] = W_change2(point);
		    

		    for(int l=1;l<(drop_speed*flame_per_sec)
			/(2000/point[2]);l++){
			if(l+1<(drop_speed*flame_per_sec)
			   /(2000/point[2]))
			  wd.vert.db((point[2]/10
				      -(in_block)*40)
				     /((drop_speed*flame_per_sec)/
				     (2000/point[2])), 
				     block_num,
				     vert, rw_po);
			else
			  wd.vert.db(0, block_num, vert, rw_po);
			
			/*wd.vert.db((point[2])/drop_speed/
			  flame_per_sec, block_num);*/

			Model3D m = new Model3D (wd.vert,false);
			wd.md = m;
			m.findBB();
			m.compress();
			try{wait(1000/flame_per_sec);}
			catch(InterruptedException e){}
		    }
		    wd.blockDrop(block_num);
		}
		hold = false;
		try{wait(1000/flame_per_sec);}
		catch(InterruptedException e){}
	    }
	    return true;
	}
	else {
	    point[2] = old_point[2];
	    old_point = point;
	    return true;
	}
    }
    
    public boolean MoveRobot(boolean anima){
	double w_fr, s_fr, e_fr, p_fr, r_fr;
	double lw = 0,  ls = 0, le = 0, lp = 0, lr = 0;
	crash = 0;
	int i,j;
	int fr_num;

	if(anima)
	  emagencyStop = false;

	mp_mj.change(point[0],point[1],
		     point[2],point[3],point[4]);
	loc = Location(mp_mj.w,mp_mj.s,mp_mj.e,mp_mj.p,mp_mj.r);
	double xxx;
	if((xxx = Math.abs(point[0]-loc[0]) +
	    Math.abs(point[1]-loc[1]) +
	    Math.abs(point[2]-loc[2])) > 9) {
	    
	    mp_mj.change(old_point[0],old_point[1],
			 old_point[2],old_point[3],old_point[4]);
	    point = old_point;
	    return false;
	}
	else {
	    if(anima)
	      fr_num = speed(speed_set,point);
	    else fr_num = 1;

	    w_fr = (mp_mj.w-mpj_w)/fr_num;
	    s_fr = (mp_mj.s-mpj_s)/fr_num;
	    e_fr = (mp_mj.e-mpj_e)/fr_num;
	    p_fr = (mp_mj.p-mpj_p)/fr_num;
	    r_fr = (mp_mj.r-mpj_r)/fr_num;
	    
	    for(i=1;i<=fr_num;i++){
		if(emagencyStop && anima) {
		    i=fr_num;
		    break;
		}
		try {
		    
		    vert.change1(mpj_w+i*w_fr);
		    vert.change2(mpj_s+i*s_fr);
		    vert.change3(mpj_e+i*e_fr);
		    vert.change4(mpj_p+i*p_fr);
		    vert.change5(mpj_r+i*r_fr);
		    
		    lw = (mpj_w+i*w_fr);
		    ls = (mpj_s+i*s_fr);
		    le = (mpj_e+i*e_fr);
		    lp = (mpj_p+i*p_fr);
		    lr = (mpj_r+i*r_fr);
		    
		    loc = Location(lw,ls,le,lp,lr);
		    
		    /*			
		       int lx = (int)Math.rint(loc[0]);
		       int ly = (int)Math.rint(loc[1]);
		       int lz = (int)Math.rint(loc[2]);
		       
		       double hl = ( lr-lw ) ;
		       double ww = ( lw ) * 180/3.141592;
		       
		       double hx1,hx2;
		       double hy1,hy2;
		       
		       hx1 = lx + 25*Math.cos(hl);
		       hx2 = lx - 25*Math.cos(hl);
		       
		       hy1 = ly + 25*Math.sin(hl);
		       hy2 = ly - 25*Math.sin(hl);
		       
		       for(int li=0; li<bl_obj; li++){
		       if(lz <= 40 && gr[li] == 0 &&
		       (bl_po[li].inside((int)hx1,(int)hy1) ||
		       bl_po[li].inside((int)hx2,(int)hy2))){
		       crash = 1;
		       i = fr_num +1;
		       }
		       }
		       for(int li=0; li<box_obj; li++){
		       if(lz <= 60 && 
		       (box_po[li].inside((int)hx1,(int)hy1) ||
		       box_po[li].inside((int)hx2,(int)hy2))){
		       crash = 2;
		       i = fr_num +1;
		       }
		       }
		       */
		    
		    if(hold==true){
			wd.vert.block(block_num,vert);
			Model3D mm = new Model3D (wd.vert,false);
			wd.md = mm;
			mm.findBB();
			mm.compress();
			double W_block[] = W_point(loc);
			wd.block_data[block_num][1] = W_block[0];
			wd.block_data[block_num][2] = W_block[1];
			wd.block_data[block_num][3] = point[2];
			//System.out.println(W_block[0]+","+W_block[1]);
		    }
		    Model3D m = new Model3D (vert,Robot);
		    md = m;
		    m.findBB();
		    m.compress();
		} catch(Exception e) {
		    md = null;
		    message = e.toString();
		}
		if(fr_num != 1 && emagencyStop == false) {
		    try{wait(1000/flame_per_sec);}
		    catch(InterruptedException e){}
		}
	    }
	    if(crash == 0){
		mpj_w = mp_mj.w;
		mpj_s = mp_mj.s;
		mpj_e = mp_mj.e;
		mpj_p = mp_mj.p;
		mpj_r = mp_mj.r;
		old_point = point;
	    }
	    else {
		for (int ix = 0; ix<5; ix++)
		  return_point[ix] = old_point[ix];
		
		mpj_w = lw;
		mpj_s = ls;
		mpj_e = le;
		mpj_p = lp;
		mpj_r = lr;
		old_point[0] = loc[0];
		old_point[1] = loc[1];
		old_point[2] = loc[2];
		old_point[3] = (lp+ls+le)*180/3.141592;
		old_point[4] = lr*180/3.131592;
		return false;
	    }
	}
	return true;
    }

    /* $B%m%\%C%H%"%K%a!<%7%g%s%G!<%?$N99?7%9%l%C%I(B */
    public synchronized void run() {
	Thread.currentThread().
	  setPriority(Thread.MIN_PRIORITY);

	running = true;

	/* Grip Close $B%3%^%s%I$N<B9T(B */
	if(point[2]==-20) success = GripClose();

	/* Grip Open $B%3%^%s%I$N<B9T(B */
	else if(point[2]==-200) success = GripOpen();
	    
	/* Move $B%3%^%s%I$N<B9T(B */
	else success = MoveRobot(true);
	    
	running = false;
	thread = null;
    }

    public void nextAnima(){
	emagencyStop = true;
    }

    /* $B%3%^%s%I$N<u$1$H$j(B */
    public void moving(String S) {
	this.SS = S;
	this.point = Change.change(SS,old_point,this);
	start();
    }
    public void moving(double p[]) {
	this.point = p;
	start();
    }
    public void moving(String S, double gosa) {
	this.SS = S;
	this.point = Change.change(SS,old_point,this, gosa);
	start();
    }

    public void start(){
	if(thread == null) {
            thread = new Thread(this);
            thread.start();
        }
	//else thread.resume();
    }
    public void stop() {
        if(thread != null) {
            thread.stop();
            thread = null;
        }
    }

    
    /* $B:BI83NG'(B */
    public double[] Location(double w, double s, double e, double p, double r){
	double B = 300, S = 250, A = 160, H = 179;
	double locate[] = new double[3];
	e = e + s;
	p = p + e;
	locate[0] = (-(-S*Math.cos(s)
		      -A*Math.cos(e)
		      -H*Math.cos(p))
	  * Math.sin(w));
	locate[1] = (-(-S*Math.cos(s)
		      -A*Math.cos(e)
		      -H*Math.cos(p))
	  * Math.cos(w));
	locate[2] = (B+S*Math.sin(s)
	  + A*Math.sin(e) + H*Math.sin(p));

	return locate;
    }

    /* $B%"%K%a!<%7%g%s%9%T!<%I@_Dj(B */
    int speed(int sp, double point[]){
	int fr_num;
	double dist = 0;
	if(old_point[2]<0){
	    fr_num = 1;
	    dist = 10;
	}else{
	    for(int i=0;i<3;i++){
		dist += Math.pow(old_point[i]-point[i],2);
	    }
	    fr_num = (int)Math.sqrt(dist) * flame_per_sec / (sp*20);
	}
	if(dist<1){
	    if((dist = Math.abs(old_point[3]-point[3]))> 10){
		fr_num = (int)(dist/10);
	    }
	    else  if((dist = Math.abs(old_point[4]-point[4])) > 10){
		fr_num = (int)(dist/10);
	    }
	    else  fr_num=1;
	}
	else if(fr_num==0)fr_num=1;
	return fr_num;
    }

    /* $B%o!<%k%I:BI8$+$i%m%\%C%H:BI8$X$NJQ49(B */
    public double[] RW_change(double obj[]){
	double rw_obj[] = new double[4];
	double Rkr = -Rz*0.017453292;
	double Rrx = obj[1] - Rx;
	double Rry = obj[2] - Ry;
	double Rr = Math.sqrt(Rrx*Rrx+Rry*Rry);
	double S = Math.asin(Rry/Rr);
	if(Rrx < 0.0 && Rry >= 0.0) S = 3.141592 - S;
	else if(Rrx < 0.0 && Rry < 0.0) S = -3.141592 - S;
	rw_obj[0] = Rr*Math.cos(S-Rkr);
	rw_obj[1] = Rr*Math.sin(S-Rkr);
	rw_obj[2] = obj[3];
	rw_obj[3] = obj[4] - Rz;
	return rw_obj;
    }
    public double[] RW_change2(double rob[]){
	double rw_rob[] = new double[5];
	double Rkr = -Rz*0.017453292;
	double Rrx = rob[0] - Rx;
	double Rry = rob[1] - Ry;
	double Rr = Math.sqrt(Rrx*Rrx+Rry*Rry);
	double S = Math.asin(Rry/Rr);
	if(Rrx < 0.0 && Rry >= 0.0) S = 3.141592 - S;
	else if(Rrx < 0.0 && Rry < 0.0) S = -3.141592 - S;
	rw_rob[0] = Rr*Math.cos(S-Rkr);
	rw_rob[1] = Rr*Math.sin(S-Rkr);
	rw_rob[2] = rob[2];
	rw_rob[3] = rob[3];

	double w;
	double x = rw_rob[0], y = rw_rob[1];
	if(x < 0) w= (Math.asin(y/Math.sqrt(x*x+y*y))-1.57)*57.29577951;
	else w= (1.57 - Math.asin(y/Math.sqrt(x*x+y*y)))*57.29577951;

	rw_rob[4] = rob[4] - Rz - w;
	while(rw_rob[4] < -90 || 90 < rw_rob[4]){
	    if(rw_rob[4] < -90) rw_rob[4] = rw_rob[4] +90;
	    else rw_rob[4] = rw_rob[4] - 90;
	}

	return rw_rob;
    }


    /* $B%m%\%C%H:BI8$+$i%o!<%k%I:BI8$X$NJQ49(B */
    public double[] W_point(double p[]) {
	double w_p[] = new double[2];
	double w;
	if(p[0] < 0) {
	    w = (Math.asin(p[1]/Math.sqrt(p[0]*p[0]+p[1]*p[1]))
			-1.57)*57.29577951;
	}
	else {
	    w = (1.57 - Math.asin(p[1]/Math.sqrt(p[0]*p[0]+p[1]*p[1]))
			)*57.29577951;
	}
	double Rr = (-Rz+90-w)*0.017453292;
	w_p[0] = Math.cos(Rr)*Math.sqrt(p[0]*p[0]+p[1]*p[1])+Rx;
	w_p[1] = Math.sin(Rr)*Math.sqrt(p[0]*p[0]+p[1]*p[1])+Ry;
	return w_p;
    }
    public double[] W_change2(double p[]) {
	double w_p[] = new double[5];
	double w;
	if(p[0] < 0) {
	    w = (Math.asin(p[1]/Math.sqrt(p[0]*p[0]+p[1]*p[1]))
			-1.57)*57.29577951;
	}
	else {
	    w = (1.57 - Math.asin(p[1]/Math.sqrt(p[0]*p[0]+p[1]*p[1]))
			)*57.29577951;
	}
	double Rr = (-Rz+90-w)*0.017453292;
	w_p[0] = Math.cos(Rr)*Math.sqrt(p[0]*p[0]+p[1]*p[1])+Rx;
	w_p[1] = Math.sin(Rr)*Math.sqrt(p[0]*p[0]+p[1]*p[1])+Ry;
	w_p[2] = p[2];
	w_p[3] = p[3];
	w_p[4] = p[4]-Rz;
	return w_p;
    }
	

    /* $B8m:9H=Dj(B */
    public boolean gosa(double obj[], double robot[], int go){
	double dx = obj[0]-robot[0];
	double dy = obj[1]-robot[1];
	double dz = obj[2]-robot[2];

	if (dx*dx + dy*dy  < 25*go && dz*dz < 700) {
	    return true;
	}
	else return false;
    }
}




