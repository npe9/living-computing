/* 
 *  $B%G!<%?7A<0JQ49%b%8%e!<%k(B 
 *  Copyright (c) 1997  Fumio Mizoguchi
 */

public class Change{

    public static double[] change(String s, double old[], V3D v3d) {
	return change(s, old, v3d, 1);
    }

    public static double[] change(String s, double old[], 
				  V3D v3d, double gosa){
        String ds;
	double pp[] = new double[5];
        int i;

        ds = s.substring(0,2);

	if("ho".equals(ds)){
	    pp[0] = 0;
	    pp[1] = 160;
	    pp[2] = 371;
	    pp[3] = -90;
	    pp[4] = 0;
	}
	else  if("gc".equals(ds)){
            pp[0] = old[0];
            pp[1] = old[1];
            pp[2] = -20;
            pp[3] = old[3];
	    pp[4] = old[4];
        }
        else if("go".equals(ds)){
            pp[0] = old[0];
            pp[1] = old[1];
            pp[2] = -200;
            pp[3] = old[3];
	    pp[4] = old[4];
        }
	else if("rs".equals(ds)){
            pp[0] = old[0];
            pp[1] = old[1];
            pp[2] = old[2];
            pp[3] = old[3];
	    pp[4] = old[4];
        }
	else if("mj".equals(ds) || "MJ".equals(ds)){
	    double mj[] = new double[5];
	    double mp[] = new double[3];
	    int l = get_position(s,3,mp);
            pp[3] = (old[3] + mj[3]);
	    pp[4] = (old[4] + mj[4]);
	    mp = v3d.Location(v3d.mp_mj.w + mj[0]*0.017453292, 
			 v3d.mp_mj.s + mj[1]*0.017453292,
			 v3d.mp_mj.e + mj[2]*0.017453292,
			 pp[3] * 0.017453292,
			 pp[4] * 0.017453292);

	    pp[0] = mp[0];
            pp[1] = mp[1];
            pp[2] = mp[2];
	    for(int ix=0; ix<5; ix++) System.out.print(pp[ix]+"  ");
	    System.out.println();
        }

        else if("mp".equals(ds)){
	    //pp = old;
	    int l = get_position(s,3,pp);
	    if(pp[3] != 0 && pp[2] < 300){
		pp[0] = pp[0] / gosa;
		pp[1] = pp[1] / gosa;
	    }
	    for(i = l; i<5; i++){
		pp[i] = old[i];
	    }
	}
	else if("wm".equals(ds)){
	    double sub_pp[] = new double[5];
	    int l = get_position(s,3,sub_pp);
	    for(i = l; i<5; i++){
		sub_pp[i] = old[i];
	    }
	    pp = v3d.RW_change2(sub_pp);
	}
        else{
            System.out.println("ERROR data");
	    pp = old;
        }
	return pp;
    }

    public static int obj(String s, double obj[][]){
	int k = 0;
	int l;
	double data[] = new double[1000];

	l = get_position(s,0,data);
	data[0] = -data[0];
	for(int i=0; i<l ; i=i+4){
	    for(int j=0; j<4; j++){
		obj[k][j] = data[i+j];
		if(j == 1) obj[k][j] = -obj[k][j];
	    }
	    k++;
	}
	return(k);
    }
    public static int get_position(String s, int ov, double data[]){
        int k = 0;
        int l = 0;
        String ds;
	String str_num = "";
	
	try{
	    for(k = ov; k<s.length(); k++){
		ds = s.substring(k,k+1);
		if (",".equals(ds) ){
		    data[l] = Double.valueOf(str_num).doubleValue();
		    if(l==0) data[l] = -data[l];
		    str_num = "";
		    l++;
		}
		else if("\0".equals(ds) || ":".equals(ds))  {
		    data[l] = Double.valueOf(str_num).doubleValue();
		    if(l==0) data[l] = -data[l];
		    str_num = "";
		    l++;
		}
		else if( k == s.length()-1)  {
		    str_num = str_num + ds;
		    data[l] = Double.valueOf(str_num).doubleValue();
		    if(l==0) data[l] = -data[l];
		    str_num = "";
		    l++;
		}
		else str_num = str_num + ds;
	    }
	}
	catch(NumberFormatException e ){
	    System.out.println("NumberFornatException !!");
	    System.out.println("DATA : "+s);
	    System.out.println("ov = "+ov+"  ,  "+s.length());
	    System.out.println("k = "+k+"  ,  "+str_num+","+str_num.length());
	    l = 0;
	}
	return(l);
    }
}

