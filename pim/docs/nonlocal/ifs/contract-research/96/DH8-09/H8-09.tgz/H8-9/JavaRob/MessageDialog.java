/* 
 *  $B%a%C%;!<%8%&%$%s%I%&(B 
 *  Copyright (c) 1997  Fumio Mizoguchi
 */

import java.awt.*;

public class MessageDialog extends Dialog {
    Label mess;
    
    public MessageDialog(Frame parent) {
        super(parent, "Message", true);

	parent.setResizable(false);
        parent.setBackground(Color.lightGray);
        parent.setFont(new Font("TimesRoman", Font.PLAIN, 18));
        parent.setLayout(new BorderLayout());
        parent.setResizable(false);
        parent.pack();

        mess = new Label("", Label.CENTER);
        add("Center",mess);

        Panel btnp;
        btnp = new Panel();
        btnp.add(new Button("OK"));
        add("South",btnp);
        setSize(300,150);
    }

    public void message(String msg) {
	Thread.currentThread().
	  setPriority(Thread.MAX_PRIORITY);
	setFont(new Font("TimesRoman", Font.PLAIN, 18));
        mess.setText(msg);
        setVisible(true);
    }
    public boolean action(Event e, Object o) {
        if(e.target instanceof Button) {
            String s = (String)o;
            if(s.equals("OK")) {
                setVisible(false);
                return true;
            }
        }
        return false;
    }
}
