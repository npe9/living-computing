/* 
 *  $BDL?.MQJd=u%W%m%0%i%`(B
 *  Copyright (c) 1997  Fumio Mizoguchi
 */

import java.awt.*;
import java.applet.*;
import java.net.*;
import java.io.*;

/*** $B%=%1%C%HDL?.%b%8%e!<%k(B ***/
public class Socket_command implements Runnable{
    DataInputStream datainput;
    DataOutputStream dataoutput;
    Socket socket = null;
    public boolean ret = true;

    Socket_command(DataOutputStream dataoutput, DataInputStream datainput){
	this.datainput = datainput;
	this.dataoutput = dataoutput;
    }
    Socket_command() {
    }	

    public boolean socket_client(String host,int port_number){
        try{
            try{
                socket = new Socket(host, port_number);
            }
            catch(IOException e){
                System.out.println("Can not open socket");
                return false;
            }
            
            datainput = new DataInputStream( 
                    new BufferedInputStream(socket.getInputStream()));
            
            dataoutput = new DataOutputStream(
                    new BufferedOutputStream(socket.getOutputStream()));
        }
        catch(Exception e) // catch any exception
          {
              System.out.println("Exception caught:" + e.getMessage() );
              e.printStackTrace();
          }
        return true;
    }


    /* $B>pJs$NAw?.(B */
    public void send(String Message) {

	try{
	    /*$B%5!<%P$KAw$k%G!<%?$NF~NOMQ(B */
	    String OutMessage = null; 

	    OutMessage = Message;

	    /* $B%G!<%?Aw?.(B */
	    dataoutput.writeBytes(OutMessage + "\0");
	    dataoutput.flush();
	}
	catch(Exception e) {}
    }


    /* $B>pJs$N<u?.(B */
    public String receive() {

	/*$B%5!<%P$+$i<u$1$H$k%G!<%?MQ(B */
	String sendstring = null;
	try{

	    /* $B%G!<%?<u?.(B */
            sendstring = datainput.readLine();
	}
        catch(Exception e) /* catch any exception */
          {
              try{
                  sendstring = datainput.readLine();
              }
              catch(Exception ex){
                  sendstring = "Can't send message !!!";
              }
          }
        return (sendstring);
    }


    public String ReadKLIC() {
        String readstring = null;
        byte b[] = new byte[1024];
        try{
            int num = datainput.read(b);
            String S = new String(b,0,0,num);
            readstring = S;
        }
        catch(Exception e) {
            System.out.println("Can't read message !!!");
            return null;
        }
        return (readstring);

    }

    public void sendEnd(){
	send("");
	socket_close();
    }

    public void socket_close() {
	try{
	    socket.close();
	    System.out.println("connect close");
	}
	catch(Exception e){
	    System.out.println("Close MISS");
	}
    }

    /* $BF0:n=*N;3NG'%9%l%C%I(B */
    public synchronized void run() {
	Thread.currentThread().
                  setPriority(Thread.MIN_PRIORITY);
	String S = null;
	ret = false;
	while( ret == false){
	    /* $B>pJs$N<u$1$H$j(B */
	    S = receive();
	    // System.out.println(S);
	    // System.out.println(S.substring(0,2));
	    /* $B>pJs$N>H9g(B */
	    if ("o".equals(S.substring(0,1))) ret = true; 
	    /* if (S != null) ret = true; */
	    else S = null;
	}
	System.out.println("Move END!!");
    }
}

