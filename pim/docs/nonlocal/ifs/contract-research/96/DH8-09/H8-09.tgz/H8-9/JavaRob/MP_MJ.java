/* 
 *  $B4V@\3QEYJQ49%W%m%0%i%`(B
 *  Copyright (c) 1997  Fumio Mizoguchi
 */

class MP_MJ{

    double w,s,e,p,r;

/* home position */
    MP_MJ(){
	w = 0;
	s = 1.5707963;
	e = -1.5707963;
	p = -1.5707963;
	r = 0;
    }
/* mp(x,y,z,p,r) -> mj(w,s,e,p,r) */
    void change(double x, double y, double z, double p, double r){
	double pr = p*0.017453292;
	double prs = Math.sin(pr);
	double prc = Math.cos(pr);

	double s1 = Math.sqrt(x*x+y*y);
	double s2 = Math.asin(y/s1);
	if(x<0.0){
	    w = s2 - 1.5707963;
	}else {
	    w = 1.5707963 - s2;
	}
	
	double ws = Math.sin(w);
	double wc = Math.cos(w);

	double y1 = x*ws + y*wc - 179.0*prc;
	double z1 = z - 179.0*prs - 300.0;

	double pow = y1*y1 + z1*z1;

	double powsq = Math.sqrt(pow);
	double alpha = Math.asin( z1 / powsq );

	double jj3 = Math.acos((y1*y1+z1*z1-36900.0)/(powsq*320.0));

	double s3 = Math.sin(alpha-jj3);
	double s4 = (z1-s3*160.0)/250.0;
	s = Math.asin(s4);

	e = alpha - jj3 - s;

	this.r = -r*0.017453292;
	this.p = pr - s - e;

    }
}
    
