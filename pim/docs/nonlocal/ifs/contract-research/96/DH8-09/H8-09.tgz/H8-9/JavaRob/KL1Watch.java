/* 
 *  KLIC$B$+$i$N;k3PG'<1%W%m%0%i%`(B
 *  Copyright (c) 1997  Fumio Mizoguchi
 */

import java.net.URL;
import java.io.*;
import java.net.*;
import java.awt.*;

public class KL1Watch implements Runnable{
    PVS1 pvs;
    MessageDialog message;
    Thread thread = null;
    SocketConnect klic;
    int klicP;
    
    KL1Watch(PVS1 pvs, int port, MessageDialog message) {
	this.pvs = pvs;
	klicP = port;
        this.message = message;
	thread_start();
    }

    public void thread_start() {
        if(thread == null) {
            thread = new Thread(this);
            thread.start();
        }
    }

    public void stop() {
        if(thread != null) {
            thread.stop();
            thread = null;
        }
    }

    public void thread_stop() {
        if(thread != null){
            thread = null;
        }
    }

    public synchronized void run(){
	int mode;
        Thread.currentThread().
              setPriority(Thread.MIN_PRIORITY);

        klic = new SocketConnect();
        // System.out.println("Connect Wait : Insight");

        boolean count = false;
        while(thread != null){
	    mode = pvs.mode;
            boolean a = klic.ServerConnect(klicP);
            if(a == false) {
                String m = "Insight : can't open socket "+ klicP;
                message.message(m);
                thread_stop();
            }
            pvs.wd[mode].kl1WatcherStart(klic);
            // System.out.println("");
            // System.out.println("Connect Success : Insight");
            // System.out.println("");
            count = true;
        }
    }
}
