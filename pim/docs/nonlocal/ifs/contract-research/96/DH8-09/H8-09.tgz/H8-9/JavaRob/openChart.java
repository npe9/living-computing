/* 
 *  $B%m%\%C%HF0:n%A%c!<%HI=I=<(MQ%W%m%0%i%`(B
 *  Copyright (c) 1997  Fumio Mizoguchi
 */

import java.awt.*;
import java.io.*;
import java.applet.*;

public class openChart {
    public static void main(String args[]){
	String sR = "robotChart";
	String sB = "blockChart";
	String fileRobot[] = new String[4];
	String fileBlock;
	for(int i=0; i<4; i++){
	    int num = i+1;
	    if(args.length > 0){
		fileRobot[i] = args[0] + "/" + sR + num;
	    }
	    else fileRobot[i] = sR + num;
	}
	if(args.length > 0) fileBlock = args[0] + "/" + sB;
	else fileBlock = sB;

	String robotChart[] = {"","","","","","","","","",""};
        String blockChart = "";

        for(int i=0; i<4; i++){
            robotChart[i+1] = openData(fileRobot[i]);
        }
        blockChart = openData(fileBlock);
	Frame f = new Frame("Chart");
	KL1Chart kc = new KL1Chart(4, null, f);
	kc.showOpen(robotChart);
	kc.ChartBlockChange(blockChart);
    }

    static String openData(String file){
	try {
            FileInputStream fin;
            fin = new FileInputStream(file);

            StringBuffer sb = new StringBuffer();
            int ch;
            while((ch = fin.read()) >= 0) {
                sb.append((char)ch);
            }
            fin.close();
            return sb.toString();
        } catch(FileNotFoundException e){
            System.out.println("File not found.");
        } catch(IOException e) {
            System.out.println("Cannot access file.");
        }
	return null;
    }
}
