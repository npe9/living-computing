/* 
 *  $B;kE@JQ99%W%m%0%i%`(B
 *  Copyright (c) 1997  Fumio Mizoguchi
 */

import java.net.URL;
import java.io.*;
import java.net.*;
import java.awt.*;
import java.lang.*;

class Viewwin extends Dialog {
    PVS1 pvs;
    TextField tx,ty,tz;
    Panel p0 ;
    Panel p1 ;

    /* $B=i4|@_Dj(B */
    public Viewwin(PVS1 pvs, Frame parent) {
        super(parent, "Addrob", false);
        setLayout(new BorderLayout());

        parent.setResizable(false);
        parent.setBackground(Color.lightGray);
        parent.setFont(new Font("TimesRoman", Font.PLAIN, 18));
        parent.setLayout(new BorderLayout());
        parent.setResizable(false);
        parent.pack();

        this.pvs = pvs;

        p1 = new Panel();

	p1.setFont(new Font("TimesRoman", Font.PLAIN, 14));
        p1.setLayout(new BorderLayout());
	p1.add("North",new Button("UP"));
	p1.add("South",new Button("DOWN"));
	p1.add("East",new Button("RIGHT"));
	p1.add("West",new Button("LEFT"));

        add("Center",p1);

	Panel south = new Panel();
        south.add(new Button("Quit"));
        add("South",south);

        resize(320, 144);
    }

    /* $B%$%Y%s%H=hM}(B */
    public boolean action(Event e, Object arg) {
        String label = (String)arg;
        if(label.equals("Quit")){
            hide();
            return true;
        }
	else if(label.equals("UP")) {
	    pvs.change_view(-15,0,0);
	    return true;
	}
	else if(label.equals("DOWN")) {
	    pvs.change_view(15,0,0);
	    return true;
	}
	else if(label.equals("RIGHT")) {
	    pvs.change_view(0,-15,0);
	    return true;
	}
	else if(label.equals("LEFT")) {
	    pvs.change_view(0,15,0);
	    return true;
	}
	else   return false;
    }
}
