/* 
 *  $B%"%K%a!<%7%g%sMQ%W%m%0%i%`(B
 *  Copyright (c) 1997  Fumio Mizoguchi
 */

import java.applet.Applet;
import java.net.URL;
import java.io.*;
import java.net.*;
import java.awt.*;

/****** $B%"%K%a!<%7%g%s%b%8%e!<%k(B ******/

public class PVS1 extends Applet implements Runnable {
    public static final int VIRTUAL = 0;
    public static final int TRAINING = 1;
    public static final int REAL = 2;
    public static final int MONITOR = 3;
    int mode = VIRTUAL;
    Thread nowMove[] = new Thread[10];
    RS1 rs;
    Panel p0,p1,p2;
    float Xmin=0,Ymin=0,Zmin=0,Xmax=0,Ymax=0,Zmax=0;
    int prevx, prevy;
    float scalefudge = 1;
    float xfac ;
    public int crashpaint = 0;
    int layout = 0;
    int count = 0;
    Matrix3D amat = new Matrix3D(), tmat = new Matrix3D();
    Socket_command so_com[][] = new Socket_command[4][10];

    Graphics gr = null;
    Image sheet = null;

    boolean success[] = {true,true,true,true,true,true,true,true};

    Socket socket[] = {null,null,null,null,null,null,null,null,null};
    DataInputStream datainput[] = new DataInputStream[10];
    DataOutputStream dataoutput[] = new DataOutputStream[10];

    /* shokisettei */
    int robot_num[] = {0,0,0,0};
    V3D n[][] = new V3D[4][10];
    double LR[][][] = new double[4][10][4];

    V_World wd[] = new V_World[4];

    double x_rot,y_rot,z_rot;
    

    public PVS1(RS1 rs){
	setSize(450,500);
	this.rs = rs;
	x_rot = -15;
	y_rot = 35;
	z_rot = 0;
	amat.yrot(35);
	amat.xrot(-15);
	
	for (int i=0; i<4; i++){
	    wd[i] = new V_World(this);
	    for (int j=0; j<10; j++) {
		n[i][j] = null;
	    }
	}
    }

    /*** $B2>A[%m%\%C%HBf?t$NA}2C=hM}(B ***/
    public void AddRobot(int robot, double x, double y, double z){
	AddRobot(robot, x, y, z, 1);
    }
    public void AddRobot(int robot, double x, double y, double z, double g){
	if(robot == 0) {
	    robot_num[mode] ++;
	    LR[mode][robot_num[mode]][0] = -x;
	    LR[mode][robot_num[mode]][1] = y;
	    LR[mode][robot_num[mode]][2] = z;
	    LR[mode][robot_num[mode]][3] = g;
	    n[mode][robot_num[mode]] = 
	      new V3D(-x,y,z,wd[mode]);
	    try {
		scalefudge = 
		  Float.valueOf(getParameter("scale")).floatValue();
	    }
	    catch(Exception e){};
	    n[mode][robot_num[mode]].moving("home");
	    layout = 0;
	}
	else {
	  LR[mode][robot][0] = -x;
	  LR[mode][robot][1] = y;
	  LR[mode][robot][2] = z;  
	  LR[mode][robot][3] = g;  
	  n[mode][robot].C_Locate(-x,y,z);
	  n[mode][robot].point = n[mode][robot].old_point;
	  n[mode][robot].old_point[2] = -100;
	  n[mode][robot].moving("home");
	  layout = 0;
	}
    }


    /*** $B8=<B%m%\%C%HBf?t$NA}2C=hM}(B ***/
    public int AddRobot(int robot, String Mashin, int port){
	if(robot == 0) {
	    robot_num[mode] ++;

	    /* $B%m%\%C%H@)8f%7%9%F%`$H$N%=%1%C%H@\B3(B */
	    boolean success = socket_client(Mashin,port,robot_num[mode]);
	    if(success) {
		so_com[mode][robot_num[mode]] 
		  = new Socket_command(dataoutput[robot_num[mode]],
				       datainput[robot_num[mode]]);

		/* $B%m%\%C%H@)8f%7%9%F%`$h$j(B $B%m%\%C%H:BI8$r<u$1$H$k(B */
		String RD_S = so_com[mode][robot_num[mode]].receive();
		double rd[] = get_locate(RD_S);
		System.out.println("Robot:"+rd[0]+","+rd[1]+","+rd[2]+
				   ", gosa ="+rd[3]);
		LR[mode][robot_num[mode]][0] = -rd[0];
		LR[mode][robot_num[mode]][1] = rd[1];
		LR[mode][robot_num[mode]][2] = rd[2];
		LR[mode][robot_num[mode]][3] = 500/rd[3];
		n[mode][robot_num[mode]] =
		  new V3D(-rd[0],rd[1],rd[2],wd[mode]);
		try {
		    scalefudge = 
		      Float.valueOf(getParameter("scale")).floatValue();
		}
		catch(Exception e){};
		n[mode][robot_num[mode]].moving("home");
		layout = 0;
		return robot_num[mode];
	    }
	    else {
		robot_num[mode] --;
		return 0;
	    }
	}
	return 0;
    }

    /*** $B8=<B%m%\%C%HBf?t$NA}2C=hM}(B ***/
    public int AddRobot(int robot, String Mashin, int port, double data[]){
	if(robot == 0) {
	    robot_num[mode] ++;
	    int rob = robot_num[mode];

	    /* $B%m%\%C%H@)8f%7%9%F%`$H$N%=%1%C%H@\B3(B */
	    boolean success = socket_client(Mashin,port,rob);
	    if(true) {
		so_com[mode][rob] 
		  = new Socket_command(dataoutput[rob],
				       datainput[rob]);

		/* $B%m%\%C%H@)8f%7%9%F%`$h$j(B $B%m%\%C%H:BI8$r<u$1$H$k(B */
		double rd[] = data;
		System.out.println("Robot:"+rd[0]+","+rd[1]+","+rd[2]+
				   ", gosa ="+rd[3]);
		LR[mode][rob][0] = -rd[0];
		LR[mode][rob][1] = rd[1];
		LR[mode][rob][2] = rd[2];
		LR[mode][rob][3] = 500/rd[3];
		n[mode][rob] =
		  new V3D(-rd[0],rd[1],rd[2],wd[mode]);
		try {
		    scalefudge = 
		      Float.valueOf(getParameter("scale")).floatValue();
		}
		catch(Exception e){};
		n[mode][rob].moving("home");
		layout = 0;
		return robot_num[mode];
	    }
	    else {
		robot_num[mode] --;
		return 0;
	    }
	}
	return 0;
    }

    /* $B%=%1%C%H%5!<%P$X$N@\B3(B */
    public boolean socket_client(String host,int port_number,int n){
        try{
            try{
                socket[n] = new Socket(host, port_number);
            }
            catch(IOException e){
                System.out.println("Can not open socket");
                return false;
            }
            
            datainput[n] = new DataInputStream( 
                    new BufferedInputStream(socket[n].getInputStream()));
            
            dataoutput[n] = new DataOutputStream(
                    new BufferedOutputStream(socket[n].getOutputStream()));
        }
        catch(Exception e) // catch any exception
          {
              System.out.println("Exception caught:" + e.getMessage() );
              e.printStackTrace();
          }
        return true;
    }

    public void deleteRobot(int m){
	for(int i=1; i<= robot_num[m]; i++){
	    so_com[m][i].sendEnd();
	    so_com[m][i] = null;
	    n[m][i] = null;
	}
	wd[m].vert = new VERT();
	wd[m].block_num = 0;
	wd[m].box_num = 0;
	wd[m].md = null;
	layout = 0;
	robot_num[m] = 0;
	System.out.println("Delete OK");
    }
    
    public boolean ConnectSocket(String Mashin, int port){
	boolean success = socket_client(Mashin,port,robot_num[mode]);
	if(success) {
	    so_com[mode][robot_num[mode]] 
	      = new Socket_command(dataoutput[robot_num[mode]],
				   datainput[robot_num[mode]]);
	    return true;
	}
	return false;
    }
    
    /* $B%9%H%j%s%0>pJs$r?tCM%G!<%?$XJQ49(B */
    public double[] get_locate(String s){
	double rd[] = new double[4];
	int l = 0;
	String ds;
	String str_num = "";

	for(int k = 0; k<s.length(); k++){
            ds = s.substring(k,k+1);
            if (",".equals(ds) ){
                rd[l] = Double.valueOf(str_num).doubleValue();
                str_num = "";
                l++;
		if(l==4) k=s.length();
            }
            else if( k == s.length()-1)  {
                str_num = str_num + ds;
                rd[l] = Double.valueOf(str_num).doubleValue();
                str_num = "";
                l++;
            }
            else str_num = str_num + ds;
	}
	return rd;
    }


    public void robotAnimaStop(int rob, int mode){
	n[mode][rob].nextAnima();
	synchronized(n[mode][rob]) {n[mode][rob].notify();}
	try{Thread.sleep(20);}
	catch(InterruptedException e){}
	n[mode][rob].MoveRobot(false);
    }

    /* $B%P!<%A%c%k%m%\%C%H$KBP$9$k%3%^%s%IAw?.(B */
    public void sendCommand(int r_num, int mode, String S, double gosa) {
	if(n[mode][r_num].running) robotAnimaStop(r_num, mode);
	n[mode][r_num].moving(S, gosa);
    }

    public void sendCommand(int r_num, int mode, String S) {
	if(n[mode][r_num].running) robotAnimaStop(r_num, mode);
	n[mode][r_num].moving(S);
    }

    /* $B8=<B%m%\%C%H$KBP$9$k%3%^%s%IAw?.(B */
    public void realCommand(int r_num, String S){
	realCommand(false, r_num, S);
    }
    public void realCommand(boolean outSys, int r_num, String S) {
	if(outSys == false){
	    String SS = "";
	    double point[] = 
	      Change.change(S,n[mode][r_num].old_point,n[mode][r_num]);

	    if(S != "ho" && S != "nt" && point[2] < 300) {
		System.out.println("No gosa");
		point[0] = point[0]*LR[mode][r_num][3];
		point[1] = point[1]*LR[mode][r_num][3];
	    }

	    double lw = 0, ls = 0, le = 0, lp = 0, lr = 0;

	    n[mode][r_num].mp_mj.change(point[0],point[1],
					point[2],point[3],point[4]);

	    double loc[] = n[mode][r_num].Location(n[mode][r_num].mp_mj.w,
						   n[mode][r_num].mp_mj.s,
						   n[mode][r_num].mp_mj.e,
						   n[mode][r_num].mp_mj.p,
						   n[mode][r_num].mp_mj.r);

	    double ppp ;
	    if(point[3] != 0)
	      ppp=  -point[4] - n[mode][r_num].mp_mj.w*180/3.141592 ;
	    else ppp = point[4];

	    while(ppp < -90 || 90 < ppp){
		if(ppp < -90) ppp = ppp +90;
		else ppp = ppp - 90;
	    }
	    double xxx;
	    if((xxx = Math.abs(point[0]-loc[0]) +
		Math.abs(point[1]-loc[1]) +
		Math.abs(point[2]-loc[2])) > 9) {
		success[r_num] = false;
	    }
	    else {
		success[r_num] = true;
		SS = "mp "+-Math.rint(point[0])
		  +","+Math.rint(point[1])+
		    ","+Math.rint(point[2])+","+Math.rint(point[3])+","+
		      Math.rint(point[4]);
	    }
	    n[mode][r_num].mp_mj.change(n[mode][r_num].old_point[0],
					n[mode][r_num].old_point[1],
					n[mode][r_num].old_point[2],
					n[mode][r_num].old_point[3],
					n[mode][r_num].old_point[4]);

	    if("gc".equals(S) || "go".equals(S) || "rs".equals(S) ||
	       "sp".equals(S.substring(0,2))){
		success[r_num] = true;
		so_com[mode][r_num].send(S+";");
	    }
	    else if(success[r_num] == true) 
	      so_com[mode][r_num].send(SS+";");
	}
	else{
	    so_com[mode][r_num].send(S+";");
	}
    }

    
    /* $B%m%\%C%HF0:n=*N;3NG'%9%l%C%I$N%9%?!<%H(B */
    public void returnCommandstart(int r_num) {
	Thread returncomThread;
	returncomThread = new Thread(so_com[mode][r_num]);
	returncomThread.start();
    }

    /* $B%m%\%C%H$NF0:nF0:n=*N;3NG'(B */
    public boolean returncommand(int r_num) {
	if(socket[r_num] == null) return true;
	else if(so_com[mode][r_num].ret == true) {
	    return true;
	}
	else return false;
    }

    public void ReLayout(){
	layout = 0;
    }

    /* $B%"%K%a!<%7%g%s%9%l%C%I(B */
    public void run() {
	Thread.currentThread().
	  setPriority(Thread.MIN_PRIORITY);
	int time = 0;
	try{Thread.sleep(10);}	catch(InterruptedException e){}
	while(robot_num[mode] >= 0) {
	    Thread.currentThread().
	      setPriority(Thread.MIN_PRIORITY);
	    boolean running = false;
	    if(robot_num[mode] > 0){
		for(int i = 1; i <= robot_num[mode]; i++) {
		    if(n[mode][i] != null ) {
			running = true;
			time = 0;
		    }
		}
		if(running == false) time ++;
		if(layout == 0 || running || time < 5) {
		    repaint();
		    try{Thread.sleep(1000/n[mode][robot_num[mode]].flame_per_sec);}
		    catch(InterruptedException e){}
		    catch(NullPointerException e){
			System.out.println("Light Null Except!");
			try{Thread.sleep(200);}
			catch(InterruptedException ex){}
		    }
		}
		else {
		    try{Thread.sleep(1000/n[mode][robot_num[mode]].flame_per_sec);}
		    catch(InterruptedException e){}
		}
	    }
	    else {
		try{Thread.sleep(1000);}
		catch(InterruptedException e){}
	    }
	}
    }


    public void paint(Graphics g) {
	g.setColor(Color.lightGray);
        g.fillRect(0,0,getSize().width,getSize().height);
	repaint();
    }


    public double[][] getRobotData(int m){
	double pp[][] = new double[5][4];
	for(int i=1; i <= robot_num[m]; i++){
	    pp[i] = getRobotData(m, i);
	}
	return pp;
    }

    public double[] getRobotData(int m, int n){
	double p[] = new double[4];
	p[0] = - LR[m][n][0];
	p[1] =   LR[m][n][1];
	p[2] =   LR[m][n][2];
	p[3] =   LR[m][n][3];
	return p;
    }


    /* $B%0%i%U%#%C%/$N>e=q$-(B */
    public void update(Graphics g) {
	double data[][] = new double[100][4];
	
	if(sheet == null) {
	    sheet = createImage( getSize().width, getSize().height );
	    gr = sheet.getGraphics();
	    gr.setColor( Color.black );
	    gr.fillRect( 0, 0, getSize().width, getSize().height );
	}

	gr.setColor(Color.lightGray);
	gr.fillRect(0,0,getSize().width,getSize().height);

	if(layout == 0){
	    g.drawImage(sheet, 0, 0, null);
	}
	
	if (crashpaint != 0 && n[mode][crashpaint].crash == 0){
	    crashpaint = 0;
	}

	try{
	    if (robot_num[mode] > 0 &&
		n[mode][robot_num[mode]].md != null ) {

		/* $B4D6-JQ2=$K$h$k%l%$%"%&%H$NJQ99(B */
		if(layout == 0 || wd[mode].newobj == true){
		    if(wd[mode].md != null){
			Xmin = wd[mode].md.xmin;
			Ymin = wd[mode].md.ymin;
			Zmin = wd[mode].md.zmin;
			Xmax = wd[mode].md.xmax;
			Ymax = wd[mode].md.ymax;
			Zmax = wd[mode].md.zmax;
		    }
		    else {
			Xmin = 9999;
			Ymin = 9999;
			Zmin = 9999;
			Xmax = -9999;
			Ymax = -9999;
			Zmax = -9999;
		    }
		    //		System.out.println("aa"+n[mode][robot_num[mode]].md.xmax);
		    for(int rob=1; rob<=robot_num[mode]; rob++){
			float xmin = n[mode][rob].md.xmin;
			float ymin = n[mode][rob].md.ymin;
			float zmin = n[mode][rob].md.zmin;
			float xmax = n[mode][rob].md.xmax;
			float ymax = n[mode][rob].md.ymax;
			float zmax = n[mode][rob].md.zmax;
			
			if(Xmin > xmin) Xmin = xmin;
			if(Ymin > ymin) Ymin = ymin;
			if(Zmin > zmin) Zmin = zmin;
			if(Xmax < xmax) Xmax = xmax;
			if(Ymax < ymax) Ymax = ymax;
			if(Zmax < zmax) Zmax = zmax;
		    }
		    
		    float xw = Xmax - Xmin;
		    float yw = Ymax - Ymin;
		    float zw = Zmax - Zmin;
		    if (yw > xw)
		      xw = yw;
		    if (zw > xw)
		      xw = zw;
		    float f1 = getSize().width / xw;
		    float f2 = getSize().height / xw;
		    if(robot_num[mode] < 2){
			xfac = 0.7f * (f1 < f2 ? f1 : f2) * scalefudge;
			// System.out.println("xfac = "+xfac);
		    }
		    else {
			xfac = 0.9f * (f1 < f2 ? f1 : f2) * scalefudge;
			// System.out.println("xfac = "+xfac);
		    }
		    layout = 1;
		    wd[mode].newobj = false;
		}

		if(wd[mode].md != null && crashpaint == 0) {
		    wd[mode].md.mat.unit();
		    // kaiten chuusin
		      wd[mode].md.mat.translate(-(Xmin + Xmax) / 2,
						-(Ymin + Ymax) / 2,
						-(Zmin + Zmax) / 2); 
		    // 3jigen 
		      wd[mode].md.mat.mult(amat);
		    
		    // ookisa awase
		      wd[mode].md.mat.scale(xfac,-xfac, 
					    16 * xfac / getSize().width);
		    // chuuou yose
		      wd[mode].md.mat.translate(getSize().width / 2, 
						getSize().height / 2, 8);
		    wd[mode].md.transformed = false;
		    
		    wd[mode].md.paint(gr, wd[mode].push_obj);
		    setPainted(wd[mode]);
		}
	    
	    
		// Robot animation
		  for(int rob=1; rob<=robot_num[mode] && crashpaint == 0; rob++){
		      
		      n[mode][rob].md.mat.unit();
		      // kaiten chuusin
			n[mode][rob].md.mat.translate(-(Xmin + Xmax) / 2,
						      -(Ymin + Ymax) / 2,
						      -(Zmin + Zmax) / 2); 
		      // 3jigen 
			n[mode][rob].md.mat.mult(amat);
		      
		      // ookisa awase
			n[mode][rob].md.mat.scale(xfac,-xfac, 
						  16 * xfac / getSize().width);
		      // chuuou yose
			n[mode][rob].md.mat.translate(getSize().width / 2, 
						      getSize().height / 2, 8);
		      n[mode][rob].md.transformed = false;
		      
		      n[mode][rob].md.paint(gr,n[mode][rob].push_rec);
		      setPainted(rob);
		  }
		g.drawImage( sheet, 0, 0, null );

	    } else if (robot_num[mode] > 0 &&
		       n[mode][robot_num[mode]].message != null) {
		g.drawString("Error in model:", 3, 20);
		g.drawString(n[mode][robot_num[mode]].message, 10, 40);
	    }
	}
	catch(NullPointerException e){
	    System.out.println("Robot = "+robot_num[mode]);
	    System.out.println("Emagency Null Except!");
	    //System.exit(0);
	    try{Thread.sleep(1000);}
	    catch(InterruptedException es){}
	}
    }
    private synchronized void setPainted(int rob) {
	n[mode][rob].painted = true;
	notifyAll();
    }
    private synchronized void setPainted(V_World wd) {
	wd.painted = true;
	notifyAll();
    }

    public void change_view(double x, double y, double z) {
	amat.xrot(-x_rot);
	amat.yrot(y);
	amat.xrot(x+x_rot);
	/* amat.zrot(zz);*/
	x_rot = x+x_rot;
	y_rot = y+y_rot;
	z_rot = z+z_rot;
	layout = 0;
    }

    /*
    public boolean mouseDown(Event e, int x, int y) {
	prevx = x;
	prevy = y;
	return true;
    }
    public boolean mouseDrag(Event e, int x, int y) {
	tmat.unit();
	float xtheta = (prevy - y) * 360.0f / getSize().width;
	float ytheta = (x - prevx) * 360.0f / getSize().height;
	tmat.xrot(xtheta);
	tmat.yrot(ytheta);
	amat.mult(tmat);

	//if (painted) {
	//painted = false;
	//repaint();
	//}

	prevx = x;
	prevy = y;
	layout = 0;
	return true;
    } 
    */
}
