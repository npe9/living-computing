/*      
 *      Robot mover proglam($Tty).
 *      Copyright (c) 1997  Fumio Mizoguchi
 *      gcc file -lnsl -lsocket
 */

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/termio.h>
#include <fcntl.h>

struct sockaddr_in   soin; 
struct servent       *sp; 
struct hostent       *hp; 
int   fromlen;
int   s = -1;
struct sockaddr_in   soin,from;
struct servent *sp;

char   buf[256], rob_buf[1024];
main(argc,argv)
int   argc;
char  *argv[];
{
    int  sn;
    int   c,cc;
    int   fd1,fd;
    int   port = $RW_port;

    fd1 = open("/dev/$Tty",O_RDWR);

    for(;;){
	sn = socketServer(port);
	c = 1;
	while(c){
	    printf ("read wait\n");
	    buf[0] = '\0';
	    read(sn,buf,sizeof(buf));
	    if(buf[0] == '\0') {
		c = 0;
		break;
	    }
	    sendCommand(buf, fd1);
	    sleep(1);
	    checkCommand(fd1);

	    if(write(sn, "ok\n\0", 3) < 1) {
		fprintf(stderr,"rwrite: write\n");
		exit(1);
	    }
	    printf("complete \n");
	}
	sleep(1);
	close(sn);
    }
}


/* $B%5!<%P$H$7$F%=%1%C%H$r3+$/(B */
int socketServer(port)
int port;
{
    int   sn;
    int   s_port = port;
    
    if(s < 0){
        s = socket(AF_INET, SOCK_STREAM, 0);
        if(s < 0){
            fprintf(stderr, "rwriteed: socket\n");
            exit(1);
        }
        soin.sin_family = AF_INET;
        soin.sin_port = s_port;
        soin.sin_addr.s_addr = INADDR_ANY;/*{133.31.108.183};*/
        while(bind(s, (caddr_t)&soin, sizeof(soin)) < 0){
            fprintf(stderr, "rwrited: bind\n");
            sleep(5);
        }
        if(listen(s,5) < 0){
            fprintf(stderr, "rwrited: listen\n");
            exit(1);
        }
    }
    
    printf("accept wait\n");
    fromlen = sizeof(from);
    sn = accept(s, &from, &fromlen);
    if(sn < 0){
        fprintf(stderr, "rwrited: accept\n"); 
    }
    printf("socket connect !!\n");
    return sn;
}

/* RS-232C$B2s@~$h$j%m%\%C%H$X%3%^%s%IAw?.(B */ 
sendCommand(com, fd)
char com[];
int fd;
{
    char sendCom[256];
    get_one_mail(com,sendCom,0);
    strcat(sendCom,"\015");
    write(fd,sendCom,strlen(sendCom));
    printf("%s \n",sendCom);
}

/* $B%m%\%C%H$NF0:n$,=*N;$7$?$+$I$&$+$r%A%'%C%/$9$k(B */
checkCommand(fd)
int fd;
{
    int x, mode;
    x = 1;
    while(x){
	ioctl(fd,TIOCMGET,&mode);
	if(mode == 0x026) x = 0;
    }
    printf ("end\n");
}

int get_one_mail(mailbox, one_mail,n)
char mailbox[],one_mail[];
int n;
{
    int c,p;
    p = 0;
    c = 1;
    while(c) {
        switch(mailbox[n]){
        case ':':
            one_mail[p] = '\0';
            c = 0;
            break;
        case ';': 
            one_mail[p] = '\0';
            c = 0;
            n ++;
            break;
        case '\n':
            n++;
            break;
        default:
            one_mail[p] = mailbox[n];
            n ++;
            p ++;
            break;
        }
    }
    return n;
}
