/* 
 *  $B%m%\%C%H@)8f%7%9%F%`@\B3%W%m%0%i%`(B  
 *  Copyright (c) 1997  Fumio Mizoguchi
 */

import java.applet.Applet;
import java.net.URL;
import java.io.*;
import java.net.*;
import java.awt.*;

/* $B<B%m%\%C%H@\B3%&%$%s%I%&(B */
public class ConnectKL1 extends Dialog {
    public static final int NO[] = {0,1,2,3,4,5,6,7,8,9};
    int r_mode = NO[0];
    int Num = $Num ;
    MessageDialog message;
    PVS1 pvs;
    TextField kl1Port[][] = new TextField[Num][2];
    TextField robPort[] = new TextField[Num];
    TextField robMashin[] = new TextField[Num];
    int rre[][] = {$KLICPort};
    int rP[] = {$RobotPort};
    String rM[] = {$MachineName};

    String dataFile = "../SOURCE/robot_data.kl1";
    double rData[][] = new double[Num+1][4];

    Choice rnum;
    Button aorm;
    Panel p0 ;
    Panel p1 ;
    int robotnum = 0;
    boolean set = false;
    KL1Robot kl1Robot;

    Frame parent;

    public ConnectKL1(PVS1 pvs, MessageDialog message, Frame parent) {
        super(parent, "ConnectKL1", false);
        setLayout(new BorderLayout());

        parent.setResizable(false);
        parent.setBackground(Color.lightGray);
        parent.setFont(new Font("TimesRoman", Font.PLAIN, 18));
        parent.setLayout(new BorderLayout());
        parent.setResizable(false);
        parent.pack();
	
        this.pvs = pvs;
	this.message = message;
	this.parent = parent;

        p0 = new Panel();
        p1 = new Panel();

        p0.setFont(new Font("TimesRoman", Font.PLAIN, 18));
        p0.add(new Label("Robot Connect from KL1"));

        add("North",p0);

	p1.setLayout(new GridLayout(Num,1,20,20));

	Panel pp[] = new Panel[Num];
	for(int i=0; i<Num; i++){
	    pp[i] = new Panel();
	    pp[i].setLayout(new BorderLayout());
	    int rrr = i+1;
	    pp[i].add("North",new Label("Robot "+rrr,Label.LEFT));
	    Panel px = new Panel();
	    px.setLayout(new GridLayout(2,3,5,10));
	    px.add(new Label("KL1"));
	    px.add(kl1Port[i][0] = new TextField(""+rre[i][0],8));
	    px.add(kl1Port[i][1] = new TextField(""+rre[i][1],8));
	    
	    px.add(new Label("Robot"));
	    px.add(robMashin[i] = new TextField(""+rM[i],8));
	    px.add(robPort[i] = new TextField(""+rP[i],8));
	    pp[i].add("Center", px);
	    p1.add(pp[i]);
	}
	add("Center",p1);
	
	Panel south = new Panel();
	south.add(new Button("Set "));
        south.add(new Button("Quit"));
        add("South",south);
	
	rData = getRobotData(dataFile, Num);

        resize(300, 600);
    }

    public void show_open() {
	show();
    }

    public boolean action(Event e, Object arg) {
        String label = (String)arg;
        if(label.equals("Quit")){
            hide();
            return true;
        }

        if(label.equals("Set ") && set == false){
	    //set = true;
	    int kP[][] = new int[Num][2];
	    int rP[] = new int[Num];
	    String rM[] = new String[Num];
	    for(int i=0; i<Num; i++){
		kP[i][0] = Integer.valueOf(kl1Port[i][0].getText()).intValue();
		kP[i][1] = Integer.valueOf(kl1Port[i][1].getText()).intValue();
		rP[i] = Integer.valueOf(robPort[i].getText()).intValue();
		rM[i] = robMashin[i].getText();
	    }
	    this.rre = kP;
	    this.rP = rP;
	    this.rM = rM;
	    kl1Robot = new KL1Robot(pvs, message, this, parent);
	    hide();
            return true;
        }
        else   return false;
    }

    public double[][] getRobotData(String file, int num){
	String text = getTextData(file);
	String textLine[] = getTextLine(text);
	return getInsightData(textLine, num);
    }

    public String[] getTextLine(String text){
	String Command[] = new String[100];
	String line = null;
	int num = 0;	
	StringBufferInputStream str = 
          new StringBufferInputStream(text);
        DataInputStream inp = new DataInputStream(str);

        try{
            while((line = inp.readLine()) != null){
                if("".equals(line) || line.length() < 2){}
                else {
                    Command[num] = line;
                    num ++;
                }
            }
        }
        catch(IOException abc){  } catch(Exception e) {}
	return Command;
    }

    public String getTextData(String file){
	String text = null;
	try{
	    FileInputStream fin;
	    fin = new FileInputStream(file);

	    StringBuffer sb = new StringBuffer();
	    int ch;
	    while((ch = fin.read()) >= 0) {
                sb.append((char)ch);
            }
            text = sb.toString();
            fin.close();
        } catch(FileNotFoundException e){
            System.out.println("Err");
        } catch(IOException e) {
            System.out.println("Err");
        }
	return text;
    }
    public double[][] getInsightData(String text[], int num){
	double data[][] = new double[num+1][4];
	int line = 0;
	while(text[line] != null){
	    if(checkText(text[line])){
		int nowNum = getRobotName(text[line]);
		double d[] = getLocData(text[line+1], text[line+2]);
		data[nowNum] = d;
		line += 2;
	    }
	    line ++;
	}
	return data;
    }

    public int getRobotName(String s){
	int max = s.length();
	String ds=null;
	for(int i=0; i<max; i++){
	    ds = s.substring(i, i+1);
	    if("(".equals(ds)) {
		String os[] = getAllData(s, i+1);
		String oo = os[0].substring(1, os[0].length());
		return Integer.valueOf(oo).intValue();
	    }
	}
	System.out.println("Miss getRobotName");
	return -1;
    }
    

    public double[] getLocData(String s1, String s2){
	double data[] = new double[4];
	int s1max = s1.length();
	int s2max = s2.length();
	String ds=null;
	for(int i=0; i<s1max; i++){
	    ds = s1.substring(i, i+1);
	    if("[".equals(ds)) {
		String os[] = getAllData(s1, i+1);
		data[0] = Double.valueOf(os[0]).doubleValue();
		data[1] = Double.valueOf(os[1]).doubleValue();
		data[2] = Double.valueOf(os[2]).doubleValue();
		i = s1max;
	    }
	}
	for(int i=0; i<s2max; i++){
	    ds = s2.substring(i, i+1);
	    if("=".equals(ds)) {
		String os[] = getAllData(s2, i+1);
		data[3] = Double.valueOf(os[0].substring(0,os[0].length()-1)).doubleValue();
		i = s2max;
	    }
	}
	return data;
    }

    public boolean checkText(String text){
	int max = text.length();
	String ds=null;
	for(int i=0; i<max; i++){
	    ds = text.substring(i, i+1);
	    if("(".equals(ds)) return true;
	}
	return false;
    }

    public String[] getAllData(String s, int ov){
	String data[] = new String[5];
	int k = 0;
        int l = 0;
        String ds;
        String str_num = "";

        try{
            for(k = ov; k<s.length(); k++){
                ds = s.substring(k,k+1);
                if (",".equals(ds) ){
                    data[l] = str_num;
                    str_num = "";
                    l++;
                }
                else if("\0".equals(ds) || "]".equals(ds) ||")".equals(ds) )  {
                    data[l] = str_num;
                    str_num = "";
                    l++;
		    k = s.length();
                }
                else if( k == s.length()-1)  {
                    str_num = str_num + ds;
                    data[l] = str_num;
                    str_num = "";
                    l++;
		    k = s.length();
                }
                else str_num = str_num + ds;
            }
        }
        catch(NumberFormatException e ){
            System.out.println("NumberFornatException !!");
            System.out.println("DATA : "+s);
            System.out.println("ov = "+ov+"  ,  "+s.length());
            System.out.println("k = "+k+"  ,  "+str_num+","+str_num.length());
            l = 0;
        }
        return data;
    }
}

