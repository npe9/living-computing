/*********************************************************************/
/*								     */
/* run.pl 							     */
/*								     */
/* Copyright (C) 1997 Thanaruk Theeramunkong (ping@jaist.ac.jp)      */ 
/*                    Manabu Okumura         (oku@jaist.ac.jp)       */
/*                    Susumu Kunifuji        (kuni@jaist.ac.jp)      */
/*                    Hiroki Imai            (imai@cs.titech.ac.jp)  */
/*								     */
/*					     	9 May 1997	     */
/*								     */
/*								     */
/*********************************************************************/

%
%
% run.pl
%
% $Header: /home/fs017/ping/work/project/icot/ICOT_FREE_SOFTWARE/LR_prolog/new/depthfirst/RCS/run.pl,v 1.3 1997/02/12 11:58:49 ping Exp ping $
% $Log: run.pl,v $
% Revision 1.3  1997/02/12 11:58:49  ping
% Beta Version.
%
% Revision 1.2  1997/02/06 05:48:30  ping
% Add header
%
% $Id: run.pl,v 1.3 1997/02/12 11:58:49 ping Exp ping $
%

:- compile('util_lr').

:- consult(parser).
%:- consult('../gram/gramsmallclause').
:- consult('../gram/gram260clause').
:- consult(error_handle).

:- consult('parser_interface').
:- format('\n\n\
****************************************\n\
*  Type \"start.\" to start the process  *\n\
****************************************\n\n',[]).
