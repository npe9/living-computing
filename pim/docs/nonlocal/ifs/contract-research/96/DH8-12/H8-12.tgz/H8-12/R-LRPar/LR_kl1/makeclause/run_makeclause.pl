/*********************************************************************/
/*								     */
/* run_makeclause.pl 						     */
/*								     */
/* Copyright (C) 1997 Thanaruk Theeramunkong (ping@jaist.ac.jp)      */ 
/*                    Manabu Okumura         (oku@jaist.ac.jp)       */
/*                    Susumu Kunifuji        (kuni@jaist.ac.jp)      */
/*                    Hiroki Imai            (imai@cs.titech.ac.jp)  */
/*								     */
/*					     	9 May 1997	     */
/*								     */
/*								     */
/*********************************************************************/

% For interpret a unknown predicate as failing in SICStus prolog
:- unknown(_,fail).

:- ensure_loaded(['find_term_nonterm','../util/util_list']).

%
% For making a prolog clause corresponding to each state 
% in an LR table "gram.tbl.sort".
%

:- consult(makeclausekl1).

:- abolish(state,4).
:- abolish(grammar,4).
:- abolish(is_term,1).
:- abolish(is_non_term,1).

%:- consult('../gram/gramsmall.tbl.sort').
%:- makeclause('../gram/gramsmall.mod',0,'../gram/gramsmall.tbl.sort','gram_main.kl1','gram','../gram/gramsmallkl1/').

:- consult('../gram/gram260.tbl.sort').
:- makeclause('../gram/gram260.mod',34,'../gram/gram260.tbl.sort','gram_main.kl1','gram','../gram/gram260kl1/').
