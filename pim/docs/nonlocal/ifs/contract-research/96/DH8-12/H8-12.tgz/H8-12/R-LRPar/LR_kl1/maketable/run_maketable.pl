/*********************************************************************/
/*								     */
/* run_maketable.pl 						     */
/*								     */
/* Copyright (C) 1997 Thanaruk Theeramunkong (ping@jaist.ac.jp)      */ 
/*                    Manabu Okumura         (oku@jaist.ac.jp)       */
/*                    Susumu Kunifuji        (kuni@jaist.ac.jp)      */
/*                    Hiroki Imai            (imai@cs.titech.ac.jp)  */
/*								     */
/*					     	9 May 1997	     */
/*								     */
/*								     */
/*********************************************************************/

%
% Header: Including Module, List Utility and
%         a program for covering CFG to Modified form.
%

% For interpret a unknown predicate as failing in SICStus prolog
:- unknown(_,fail).

:- use_module(library(system)).
:- compile('../util/util_list').

%
% For change grammar which you want to use. 
%   cfg2mod(INFILE,OUTFILE).
% Please indicate INFILE and OUTFILE.
% Ex:
:- compile('cfg2mod').
% :- cfg2mod('../gram/gramsmall','../gramsmall.mod').

%
% For making a LR table 
%         gram -> gram.tbl.sort
%

:- compile(find_term_nonterm).
:- compile(maketable).
:- maketable('../gram/gramsmall','../gram/gramsmall.mod','../gram/gramsmall.tbl',sentence).
:- system('cat ../gram/gramsmall.tbl | sort -t\\( +1 -n > ../gram/gramsmall.tbl.sort').

