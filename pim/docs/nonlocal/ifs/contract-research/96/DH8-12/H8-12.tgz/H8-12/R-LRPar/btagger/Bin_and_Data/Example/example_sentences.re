Hello/UH 
the/DT Secretariat/NNP for/IN the/DT first/JJ international/JJ conference/NN of/IN interpreting/VBG telephony/NN 
Yes/UH that/DT 's/VBZ me/PRP 
Just/RB a/DT moment/NN 
I/PRP would/MD like/VB to/TO ask/VB something/NN about/IN registration/NN to/TO the/DT conference/NN 
Sure/RB go/VB ahead/RB please/VB 
I/PRP have/VBP the/DT registration/NN form/NN here/RB at/IN hand/NN 
Yes/UH 
in/IN the/DT registration/NN form/NN there/EX is/VBZ an/DT item/NN for/IN the/DT name/NN of/IN the/DT credit/NN card/NN and/CC the/DT credit/NN card/NN number/NN 
there/EX 's/VBZ someone/NN who/WP does/VBZ n't/RB have/VB any/DT credit/NN cards/NNS 
