/*********************************************************************/
/*								     */
/* gramsmall.mod 						     */
/*								     */
/* Copyright (C) 1997 Thanaruk Theeramunkong (ping@jaist.ac.jp)      */ 
/*                    Manabu Okumura         (oku@jaist.ac.jp)       */
/*                    Susumu Kunifuji        (kuni@jaist.ac.jp)      */
/*                    Hiroki Imai            (imai@cs.titech.ac.jp)  */
/*								     */
/*					     	9 May 1997	     */
/*								     */
/*								     */
/*********************************************************************/

grammar(1,sentence,[s],1).                        %1
grammar(2,s,[np,vp],2).                           %2
grammar(3,np,[det,n],2).                          %3
grammar(4,np,[n],1).                              %4
grammar(5,np,[np,pp],2).                          %5
grammar(6,pp,[p,np],2).                           %6
grammar(7,vp,[v,np],2).                           %7
grammar(8,vp,[vp,pp],2).                          %8
