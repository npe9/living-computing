/*********************************************************************/
/*								     */
/* sentences20.re 						     */
/*								     */
/* Copyright (C) 1997 Thanaruk Theeramunkong (ping@jaist.ac.jp)      */ 
/*                    Manabu Okumura         (oku@jaist.ac.jp)       */
/*                    Susumu Kunifuji        (kuni@jaist.ac.jp)      */
/*                    Hiroki Imai            (imai@cs.titech.ac.jp)  */
/*								     */
/*					     	9 May 1997	     */
/*								     */
/*								     */
/*********************************************************************/

input_sentence(  1,[[uh,hello]]).
input_sentence(  2,[[dt,the],[nnp,secretariat],[in,for],[dt,the],[jj,first],[jj,international],[nn,conference],[in,of],[vbg,interpreting],[nn,telephony]]).
input_sentence(  3,[[uh,yes],[dt,that],[vbz,"'s"],[prp,me]]).
input_sentence(  4,[[rb,just],[dt,a],[nn,moment]]).
input_sentence(  5,[[prp,i],[md,would],[vb,like],[to,to],[vb,ask],[nn,something],[in,about],[nn,registration],[to,to],[dt,the],[nn,conference]]).
input_sentence(  6,[[rb,sure],[vb,go],[rb,ahead],[vb,please]]).
input_sentence(  7,[[prp,i],[vbp,have],[dt,the],[nn,registration],[nn,form],[rb,here],[in,at],[nn,hand]]).
input_sentence(  8,[[uh,yes]]).
input_sentence(  9,[[in,in],[dt,the],[nn,registration],[nn,form],[ex,there],[vbz,is],[dt,an],[nn,item],[in,for],[dt,the],[nn,name],[in,of],[dt,the],[nn,credit],[nn,card],[cc,and],[dt,the],[nn,credit],[nn,card],[nn,number]]).
input_sentence( 10,[[ex,there],[vbz,"'s"],[nn,someone],[wp,who],[vbz,does],[rb,"n't"],[vb,have],[dt,any],[nn,credit],[nns,cards]]).
input_sentence( 11,[[wp,what],[vbz,happens],[in,in],[dt,that],[nn,case]]).
input_sentence( 12,[[uh,well],[dt,the],[nn,credit],[nn,card],[nn,name],[cc,and],[nn,number],[prp,we],[vbp,hope],[in,that],[prp,it],[md,would],[vb,be],[vbn,used],[in,by],[jj,foreign],[nns,guests],[cc,and],[jj,foreign],[nns,speakers],[to,to],[dt,the],[nn,conference]]).
input_sentence( 13,[[prp,it],[vbz,"'s"],[rb,much],[jjr,easier],[to,to],[vb,pay],[in,by],[nn,credit],[nn,card]]).
input_sentence( 14,[[in,if],[prp,you],[vbp,do],[rb,"n't"],[vb,have],[dt,a],[nn,credit],[nn,card],[prp,you],[md,can],[vb,pay],[in,by],[nn,cash],[cc,or],[in,by],[nn,check]]).
input_sentence( 15,[[uh,yes],[vb,thank],[prp,you]]).
input_sentence( 16,[[cc,and],[prp,i],[md,would],[vb,like],[to,to],[vb,know],[nn,something],[rb,else],[in,about],[dt,that],[rb,too]]).
input_sentence( 17,[[in,about],[dt,the],[nn,registration],[nn,fee],[prp,you],[vbd,mentioned],[cd,100],[jj,american],[nns,dollars],[md,should],[prp,it],[vb,be],[vbn,payed],[in,in],[jj,american],[nns,dollars]]).
input_sentence( 18,[[jj,null]]).
input_sentence( 19,[[rb,not],[jj,necessary],[dt,no]]).
input_sentence( 20,[[in,at],[dt,the],[jj,current],[nn,exchange],[nn,rate],[cd,100],[nn,dollar],[vbz,is],[rb,roughly],[cd,16000],[nn,yen],[rb,so],[in,for],[jj,japanese],[nns,people],[in,of],[nn,course],[prp,they],[md,may],[vb,pay],[in,in],[nnp,yen]]).
input_sentence( 21,[[prp,i],[md,would],[vb,like],[to,to],[vb,ask],[nn,something],[in,about],[nn,registration]]).
