/*********************************************************************/
/*								     */
/* run_makeclause.pl 						     */
/*								     */
/* Copyright (C) 1997 Thanaruk Theeramunkong (ping@jaist.ac.jp)      */ 
/*                    Manabu Okumura         (oku@jaist.ac.jp)       */
/*                    Susumu Kunifuji        (kuni@jaist.ac.jp)      */
/*                    Hiroki Imai            (imai@cs.titech.ac.jp)  */
/*								     */
/*					     	9 May 1997	     */
/*								     */
/*								     */
/*********************************************************************/

% For interpret a unknown predicate as failing in SICStus prolog
:- unknown(_,fail).

:- ensure_loaded(['find_term_nonterm','../util/util_list']).

%
% For making a prolog clause corresponding to each state 
% in an LR table "gram.tbl.sort".
%

:- consult(makeclause).

:- abolish(state,4).
:- makeclause('../gram/gramsmall.mod','../gram/gramsmall.tbl.sort','../gram/gramsmallclause.pl').
%:- makeclause('../gram/gram260.mod','../gram/gram260.tbl.sort','../gram/gram260clause.pl').