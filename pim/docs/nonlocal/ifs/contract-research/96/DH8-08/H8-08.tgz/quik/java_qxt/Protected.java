/* Copyright (C) 1998 Kazumasa Yokota */
/*                                    */
package java_qxt;

public class Protected extends MQ_VTerm {

boolean flag;

}
