set terminal postscript eps 20
set output 'parallel2.eps'
set xlabel 'Number of Processes'
set ylabel 'Speed Up'
plot [0:10][0:10] 'p0.dat' title 'ideal' with lines, 'p1.dat' title 'problem(1)' with linespoints, 'p3.dat' title '(pipeline only)' with linespoints, 'p4.dat' title '(parallel-cjm only)' with linespoints
pause -1
