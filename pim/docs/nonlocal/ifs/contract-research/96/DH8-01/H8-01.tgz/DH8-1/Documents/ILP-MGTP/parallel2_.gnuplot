set output 'parallel2_.eps'
set xlabel 'Number of Processes'
set ylabel 'Speed Up'
plot [0:10] x title 'ideal', 'p1_.dat' title 'problem(1)' with linespoints, 'p3_.dat' title '(pipeline only)' with linespoints, 'p4_.dat' title '(parallel-cjm only)' with linespoints
pause -1
set terminal postscript eps 20
