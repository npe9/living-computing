set terminal postscript eps 20
set output 'parallel_.eps'
set xlabel 'Number of Processes'
set ylabel 'Speed Up'
plot [0:10] x title 'ideal', 'p1_.dat' title 'problem(1)' with linespoints, 'p2.dat' title 'problem(2)' with linespoints
pause -1
