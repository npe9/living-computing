set terminal postscript eps 20
set output 'parallel.eps'
set xlabel 'Number of Processes'
set ylabel 'Speed Up'
plot [0:10][0:10] 'p0.dat' title 'ideal' with lines, 'p1.dat' title 'problem(1)' with linespoints, 'p2.dat' title 'problem(2)' with linespoints
pause -1
