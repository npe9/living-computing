%  Shaky v1.0      Copyright (C) 1997, Masanori Ohmori (oomori@jaist.ac.jp) 
/* ��˥ե���������󡦥⥸�塼�� */
unify([S1,I1,St1],[S2,I2,St2]):-
	St1==St2,
	var(S2),S2=S1,
	unify_inf(I1,I2).
unify([S1,I1,St1],[S2,I2,St2]):-
	St1==St2,
	ground(S1),ground(S2),
	S1==S2,
	unify_inf(I1,I2).
unify_val(V1,V2):-
	atom(V1),atom(V2),V1==V2.
unify_val(V1,V2):-
	var(V2),V2=V1.
unify_val(V1,V2):-
	var(V1),V1=V2.
unify_val([S1,I1,P1],[S2,I2,P2]):-
	P1==P2,
	var(S2),S2=S1,
	unify_inf(I1,I2).
unify_inf(X,Y):-
	var(X),ground(Y),X=Y.
unify_inf(X,Y):-
	var(Y),ground(X),Y=X.
unify_inf([R1,A1,P1],[R2,A2,P2]):-
	P1==P2,atom(R1),atom(R2),R1==R2,
	unify_args(A1,A2).
unify_args([],[]):-!.
unify_args(_,[]):-!.
unify_args([],_):-!.
unify_args(Args_s,Args_t):-
        u:assoc(Key,Args_s,Val_s),
        u:assoc(Key,Args_t,Val_t),
        S=[Key,Val_s],T=[Key,Val_t],
        u:delete(Args_s,S,Res_s),u:delete(Args_t,T,Res_t),
        unify_val(Val_s,Val_t),
        unify_args(Res_s,Res_t).
/*
unify([S1,T1],[S2,T2]):-
	sit_unify(S1,S2),
	term_unify(T1,T2).

sit_unify(S1,S2):-
	var(S1),S1=S2.
sit_unify(S1,S2):-
	atom(S1),var(S2),S2=S1.
sit_unify(S1,S2):-
	atom(S1),atom(S2),S1==S2.

term_unify(T1,T2):-
	var(T2),T2=T1.
term_unify(T1,T2):-
	var(T1),T1=T2.
term_unify(T1,T2):-
	compound(T1),compound(T2),term_unify1(T1,T2).

term_unify1([R2,P1,Args1],[R2,P2,Args2]):-
	P1 \== P2, !, fail.
term_unify1([R,P,Args1],[R,P,Args2]):-
	unify_args(Args1,Args2).

unify_args([],[]):-!.
unify_args(_,[]):-!.
unify_args([],_):-!.
unify_args(Args_s,Args_t):-
        assoc(Key,Args_s,Val_s),
        assoc(Key,Args_t,Val_t),
        S=[Key,Val_s],T=[Key,Val_t],
        delete(Args_s,S,Res_s),delete(Args_t,T,Res_t),
        unify(Val_s,Val_t),
        unify_args(Res_s,Res_t).
*/
