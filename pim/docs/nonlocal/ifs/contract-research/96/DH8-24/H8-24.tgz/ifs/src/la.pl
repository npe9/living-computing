%  Shaky v1.0      Copyright (C) 1997, Masanori Ohmori (oomori@jaist.ac.jp) 
:- ['main','system','transfer','grammar','io','db','inference','utility','cs','cs_out'].
