%  Shaky v1.0      Copyright (C) 1997, Masanori Ohmori (oomori@jaist.ac.jp) 
/* �ǡ��������ϥ⥸�塼�� */
:- module(io,[]).

/* getn(Stream,N,Data)
 Stream����N�Ĥ�Data���ɤ߹��� */
getn(_,0,[]).
getn(Stream,N,[C|List]):-
	get0(Stream,C),
	N1 is N-1,
	getn(Stream,N1,List).

/* getline(Stream,String):-
	Stream����1sentence�ɤ߹��� */
getline(Stream,List):-
	get0(Stream,C),!,
	getline(Stream,List,C).
getline(_,[-1],-1).
getline(Stream,[46|List],46):-
	get0(Stream,C),!,
	getline1(Stream,List,C).
getline(Stream,[C|List],C):-
	getline(Stream,List).
getline1(_,[-1],-1).
getline1(_,[10],10).
getline1(Stream,[C|List],C):-
	getline(Stream,List).

/* getline(List) :- user_input����1sentence�ɤߤȤ� */
getline(List):- getline(user,List).

/* promptɽ�� : "'����'> "*/
printprompt(Sit):-
	printprompt1(Sit),
	print('> ').
printprompt1([X]):-
	format("~a",X).
printprompt1([X|SL]):-
	format("~a,",X),
	printprompt1(SL).

/* �ǡ����Υ����� */
load_data(File):-
	open(File, read, Stream),
	load_loop(Stream),
	close(Stream).
load_loop(Stream):-
	getline(Stream, Data),!,
	user:last(Data,Flag),
	load_loop1(Stream,Data,Flag).
load_loop1(_,_,-1).
load_loop1(Stream,Data,_):-
	tr:transfer_etoi(Data,In_data),
	db:store_data(In_data),
	load_loop(Stream).

/* output_data1(Ex) :- ����ɽ����ɽ������*/
output_data1(Ex):-
	name(X,Ex),
	print(X).
output_data([]).
output_data([Ex|List]):-
	output_data1(Ex),nl,
	output_data(List).
/* �������ܴط��Υ����� */
load_sr_data(File):-
	open(File, read, Stream),
	load_sr_loop(Stream),
	close(Stream).
load_sr_loop(Stream):-
	getline(Stream, Data),!,
	user:last(Data,Flag),
	load_sr_loop1(Stream,Data,Flag).
load_sr_loop1(_,_,-1).
load_sr_loop1(Stream,Data,_):-
	tr:transfer_etoi(Data,In_data),
	db:store_sr_data(In_data),
	load_sr_loop(Stream).
