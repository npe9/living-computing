/*
  Makefile.pl for Shaky v1.0
  Copyright (C) 1997, Masanori Ohmori (oomori@jaist.ac.jp)
*/

:- fcompile('main').
:- fcompile('system').
:- fcompile('transfer').
:- fcompile('grammar').
:- fcompile('io').
:- fcompile('db').
:- fcompile('solve').
:- fcompile('unify').
:- fcompile('utility').
:- fcompile('cs').
:- fcompile('cs_out').

:- save('shaky').
