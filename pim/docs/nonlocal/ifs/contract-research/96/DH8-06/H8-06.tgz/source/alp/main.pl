% Copyright (C) 1997  Katsumi Inoue 
%
%%% main.pl %%%
%
%
% ALP system ---- Main Module ----
%
alp_module([
	alp,
	alputy,
	pr2mgtp,
	pr2uty,
	mgtp2pl,
	mgtp2uty,
%	model1,
%	model2,
	model3,
	stable,
	au]).

% ---- Initialize ----
?- alp_module(Source), compile(Source).
%	main.

