% Copyright (C) 1997  Katsumi Inoue 
%
%%% main2.pl %%%
%
%
% Action MGTP system ---- Main Module ----
%
action_module([
	'../alp/alp',
	'../alp/alputy',
%	pr2mgtp,
	pr2action,
	pr2uty,
	'../alp/mgtp2pl',
	'../alp/mgtp2uty',
%	model1,
%	model2,
	'../alp/model3',
	'../alp/stable',
	'../alp/au',
	actmgtp,
	actuty,
        act_alp,
	query]).

% ---- Initialize ----
?- action_module(Source), compile(Source).


