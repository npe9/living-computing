% Copyright (C) 1997  Katsumi Inoue 
%
%%% pr2action.pl %%%
%
%**********************%
%   for Action MGTP.   %
%**********************%
%  translator
%        translation of Abductive Extended Disjunctive programs
%
% disjunction transter
% program form check
%   head cycle check
% schema1, schema2
% no schema

% �黻�����
:- current_op(X,Y,(:-)),op(X,xfx,(<-)),op(X,fy,(<-)).
:- current_op(X,Y,(-)),op(X,fy,'not').

% <<<< translator >>>>
pr2mgtp :- !,
	pr2mgtp(_,_).

pr2mgtp(Mname) :- !,
	pr2mgtp(Mname,_).

pr2mgtp(Mname,Pname) :-
	var(Mname),!,
	repeat,
	printf('file name >> '),
	read(Mname),
	(Mname = exit;
	    pr2mgtp(Mname,Pname),fail).

pr2mgtp(Mname,Pname) :-
	var(Pname),!,
	filename_to_name_ext(Mname,Pname,_),
	pr2mgtp(Mname,Pname).

pr2mgtp(Mname,Pname) :-
	/* filename check */
        
        time(_),

	can_file_open_msg(read,Mname,[pr],MF),
	can_file_open_msg(write,Pname,[mgtp],PF),
	pr2mgtp_initialize,
%%	printf(['reading ',MF,' file',{nl}]),
%%        nl(user),
	pr2mgtp_in(MF),
%%        nl(user),
%%	printf(['transformation of Disjunction']),
	('clause'(yes) -> pr2mgtp_disjunction(1,_);true),
	/* make clause list */
	pr2mgtp_clause_list(1),
%%	printf([' ... ok !!',{nl}]),
	pr2mgtp_out(PF),

        time(T),

	printf(['alpcompile ... ']),

        print_time(T),
%	printf(['[ translate program saved in "',PF,'". ]',{nl}]),
	!.


% <<<< initialize >>>>
pr2mgtp_initialize :-
	pr2mgtp_initialize_data(Pred,Arity),
	abolish(Pred,Arity),
	fail.
pr2mgtp_initialize :- !,
	counter(init,clause),
	assertz('clause'(no)),
	assertz('form'(nodis)).

pr2mgtp_initialize_data('Predicate',1).   /* Prolog �Ҹ� */
pr2mgtp_initialize_data('head',1).        /* �إåɥꥹ�� */
pr2mgtp_initialize_data('dis',1).         /* Disjunct �ꥹ�� */
pr2mgtp_initialize_data('cl',1).          /* ����ǡ��� */
pr2mgtp_initialize_data('form',1).        /* Disjunction ��̵ͭ */
pr2mgtp_initialize_data('Clause',3).      /* natural clause �ǡ��� */
pr2mgtp_initialize_data('clause',1).      /* natural clause ��̵ͭ */
pr2mgtp_initialize_data('Negative',1).    /* negative clause �ǡ��� */
pr2mgtp_initialize_data('Assume',1).      /* ���� �ꥹ�� */
pr2mgtp_initialize_data('Observation',1). /* ��¬ �ꥹ�� */


% <<<< format read date >>>>
pr2mgtp_in(File) :-
	see(File),
	repeat,
	read(In),
%	numbervars(In,0,_),
	pr2mgtp_in_loop(In),
	seen,!.


pr2mgtp_in_loop('end_of_file') :- !.
pr2mgtp_in_loop(P) :-
	pr2mgtp_in_case(P),
	fail.


/* ���� */
pr2mgtp_in_case(('<-' Ant)) :- !,
	pr2mgtp_in_clause(fail,Ant),!.

/* ������ */
pr2mgtp_in_case((Suc '<-' Ant)) :- !,
	pr2mgtp_in_clause(Suc,Ant),!.

/* ����,����,��¬ */
pr2mgtp_in_case(Pre) :- !,
	pr2mgtp_in_predicate(Pre),!.


/* Pre ������,����,��¬�Τɤξ������Ĥ�������å����� */
pr2mgtp_in_predicate(Pre) :-
	(pr2mgtp_in_check_assume(Pre,AbdList)->assertz('Assume'(AbdList));
	    (pr2mgtp_in_check_observe(Pre,Ob)->assertz('Observation'(Ob));
		(pr2mgtp_in_check_predicate(Pre,NP)->assertz('Predicate'(NP));
		    pr2mgtp_in_clause(Pre,true)))).

%
% pr2mgtp_in_check_assume(Pre,AbdList)
%   Pre : �롼��
%   AbdList : ����Υꥹ��
%
/* �����ɽ�����Ƥ��뤫�����å� */
pr2mgtp_in_check_assume(Pre,AbdList) :-
	(Pre =.. [Pred|Rem] -> 
	 Pred = 'assume',
	 (retract('Assume'(X)) -> true;X = []),
	 append(X,Rem,List),
	 pr2mgtp_in_check_element(List,AbdList);
	    fail).

%
% pr2mgtp_in_check_observe(Pre,Ob)
%   Pre : �롼��
%   Ob : ��¬���줿���
%
/* ��¬��ɽ�����Ƥ��뤫�����å� */
pr2mgtp_in_check_observe(Pre,Ob) :-
	(Pre =.. [Pred|Rem] ->
	 Pred = 'observation', Ob = Rem).

%
% pr2mgtp_in_check_element(X,Y)
%   X : �ꥹ��
%   Y : Ʊ�����Ǥ�����ʤ��ꥹ��
%
/* Ʊ�����Ǥ���Ĥ������å�*/
pr2mgtp_in_check_element([],[]).
pr2mgtp_in_check_element([X|L1],[X|L]) :-
	(member(X,L1) ->
	 delete_list(strong,X,L1,L2), pr2mgtp_in_check_element(L2,L);
	    pr2mgtp_in_check_element(L1,L)).
%
% pr2mgtp_in_check_predicate(Pre,NewPre)
%   Pre : ��ǡ���
%   NewPre : Prolog�νҸ�ꥹ��
% Prolog �νҸ� �ꥹ�Ȥκ���
%
pr2mgtp_in_check_predicate(Pre,NewPre) :-
	Pre =.. [X|_],
	X = ':-',
	numbervars(Pre,0,_),
	(retract('Predicate'(P)) -> append(P,[Pre],NewPre);
	    NewPre = [Pre]).

%
% pr2mgtp_in_clause(Suc,Ant)
%   Suc : ��θ��
%   Ant : �������
%
/* ��ǡ����κ��� */
pr2mgtp_in_clause(Suc,Ant) :-
	pr2mgtp_in_SucList(Suc,SucList),
	/* Disjunctive literal �Υꥹ�Ȥκ��� */
	(SucList = [_,_|_] ->
	 (retract('dis'(Dis)) ->
	  asserta('dis'([SucList|Dis]));asserta('dis'([SucList])));
	    true),
	pr2mgtp_in_AntList(Ant,AntList),
	/* �ܥǥ��� Objective literal �� Negative literal ��ʬ���� */
	pr2mgtp_in_inclause(AntList,ONlist),

%        print(user,'ONlist = '),
%        print(user,ONlist),
%        nl(user),

        
        /* ��ǡ�������¸ */
	pr2mgtp_in_clause_assert(SucList,ONlist).


%
% pr2mgtp_in_SucList(Suc,SucList)
%   Suc : ���
%   SucList : ���Υꥹ��
% SucList �ϥꥹ�ȤΥꥹ��
% a,b,c;d,e;f  -->  [[a,b,c],[d,e],[f]]
%
/* ���Υꥹ�Ȥ���� */
pr2mgtp_in_SucList(Suc,SucList) :-
	(Suc = fail ->
	 SucList = [];to_OrList(Suc,SucList)),
	 pr2mgtp_in_head_list(SucList).

%
% pr2mgtp_in_head_list(X)
%   X : ���Υꥹ�ȡʥץ���������Ρ�
% 
/* �ץ���������Τθ��Υꥹ�Ȥκ��� */
pr2mgtp_in_head_list([]).
pr2mgtp_in_head_list([Head|L]) :-
	(retract(head(X)) ->
	 append(Head,X,H),assertz(head(H));
	    assertz(head(Head))),

%        print(user,'Head(Suc) = '),
%        print(user,Head),
%        nl(user),


        pr2mgtp_in_head_list(L).

%
% pr2mgtp_in_AntList(Ant,AntList)
%   Ant : ����
%   AntList : ����Υꥹ��
% AntList �ι���
%   <- a,b,not c;d,not e;not f  -->  [[[a,b],[c]],[[d],[e]],[[],[f]]]
%
/* ����Τꤹ�Ȥ���� */
pr2mgtp_in_AntList(Ant,AntList) :-
	(Ant = true ->
	 AntList = [];to_OrList(Ant,AntList)).
         

%         print(user,'AntList = '),
%         print(user,AntList),
%         nl(user).



%
% pr2mgtp_in_clause_assert(Head,Body)
%   Head : ���Υǡ���
%   body : ����Υǡ���
% ��ǡ�������¸
%
/* ���� ��NAF ��ޤޤʤ�����*/
pr2mgtp_in_clause_assert([],ONlist) :-
	/* NAF ��ޤफ�����å� */
	pr2mgtp_in_clause_assert1(ONlist),
	assertz('Negative'(ONlist)).
/* ���Υ�ƥ�뤬 Negative literal �˴ޤޤ���� */
pr2mgtp_in_clause_assert([H],[[Obj,Neg]]) :-

%
%       /* �����Ǥ��륢�ȥ����Ф� */ 
%%        print(user,'Obj = '),
%%        print(user,Obj),
%%        nl(user),        
%        put_functor(Obj,[]),

%%        print(user,'Neg = '),
%%        print(user,Neg),
%%        nl(user),
%        put_functor(Neg,[]),

	copy_term([H,Obj,Neg],[H1,Obj1,Neg1]),
	numbervars([H1,Obj1,Neg1],0,_),
	/* ������Ф� */
	pr2mgtp_in_take_condition(Obj1,Con),

        /* �ޤޤ�뤫�����å� */
	pr2mgtp_in_check_negation(H1,Neg1,Con),
	counter(get,clause,C),
	assertz('Clause'(C,[],[[Obj,Neg]])).
/* ����ʳ� */
pr2mgtp_in_clause_assert(Suc,ONlist) :-
	counter(get,clause,C),
	('clause'(no) -> retract('clause'(no)),assertz('clause'(yes));true),
	assertz('Clause'(C,Suc,ONlist)).

%
% pr2mgtp_in_clause_assert1(X)
%   X : ���Υǡ���
% NAF ��ޤޤʤ����,����
%
/* NAF ��ޤफ�����å� */
pr2mgtp_in_clause_assert1([]).
pr2mgtp_in_clause_assert1([[_,[]]|L]) :-
	pr2mgtp_in_clause_assert1(L).

%
% pr2mgtp_in_take_condition(Obj,Con)
%   Obj : Objective literal list
%   Con : condition list
%
/* �ܥǥ����������Ф� */
pr2mgtp_in_take_condition([],[]).
pr2mgtp_in_take_condition([{X}|O],[{X}|C]) :- !,
	pr2mgtp_in_take_condition(O,C).
pr2mgtp_in_take_condition([_|O],C) :- !,
	pr2mgtp_in_take_condition(O,C).

%
% pr2mgtp_in_check_negation(Head,Neg,Con)
%   Head : ���� list
%   Neg : negative literal list
%   Con : condition list
% ���Υ�ƥ�뤬 Negative literal �˴ޤޤ�뤫�����å�
% �ޤޤ�Ƥ����,����
%
pr2mgtp_in_check_negation([],_,_).
pr2mgtp_in_check_negation([Head|H],Neg,Con) :- !,
	/* ������Υ�ƥ��ˤĤ��ƥ����å� */
	pr2mgtp_in_check_negation1(Head,Neg,Con),!,
	pr2mgtp_in_check_negation(H,Neg,Con).

%
% pr2mgtp_in_check_negation1(Head,Neg,Con)
%   Head : ���� literal
%   Neg : negative literal list
%   Con : condition list
% ������Υ�ƥ��ˤĤ��ƥ����å�
% �ޤޤ�Ƥ����,����
%
pr2mgtp_in_check_negation1(H,[H|_],_).
pr2mgtp_in_check_negation1(H,[N|_],Con) :-
	H =.. [F1|P1],N =.. [F2|P2],
	F1 == F2,
	(in_var_hold(H);in_var_hold(N)),!,
	/* �Ҹ�̾�Υ����å� */
	(pr2mgtp_in_check_condition(H,N,Con) -> true;
	    /* �ʽҸ�̾��Ʊ�����˰����Υ����å� */
	    pr2mgtp_in_check_negation_para(P1,P2,Con)).
pr2mgtp_in_check_negation1(H,[_|L],Con) :-
	pr2mgtp_in_check_negation1(H,L,Con).

%
% pr2mgtp_in_check_negation_para(P1,P2,Con)
%   P1 : ������
%   P2 : ������
%   Con : condition list
% �����Υ����å�
%   ������Ʊ���ʤ��,����
%
pr2mgtp_in_check_negation_para([],[],_).
pr2mgtp_in_check_negation_para(X,X,_).
pr2mgtp_in_check_negation_para([P1|_],[P2|_],Con) :-
	/* �ѿ����ޤޤ�뤫�����å� */
	(in_var_hold(P1);in_var_hold(P2)),!,
	/* ���ΰ����ˤĤ��Ƥ����Ĵ�٤� */
	pr2mgtp_in_check_negation_para_variable(P1,P2,Con).
pr2mgtp_in_check_negation_para([P1|L1],[P2|L2],Con) :- !,
	/* �ѿ����դ��ޤ줺,���ΰ�����Ʊ���ʤ��,���ΰ����� */
	P1 = P2,
	pr2mgtp_in_check_negation_para(L1,L2,Con).

/* ������Ʊ�����Υ����å� */
%pr2mgtp_in_check_negation_para_variable(_,_,[]).
pr2mgtp_in_check_negation_para_variable(X,Y,Con) :-
	/* �ѿ��ɤ����ʤ�,��������å� */
	(var_original(X);var_original(Y)),!,
	 pr2mgtp_in_check_condition(X,Y,Con).
/* �����Ǥʤ��ʤ��,����˽Ҹ�̾�Υ����å� */
pr2mgtp_in_check_negation_para_variable(X,Y,Con) :-
	X =.. [F1|P1],Y =.. [F2|P2],
	F1 == F2,!,
	pr2mgtp_in_check_negation_para(P1,P2,Con).

/* �������å� */
pr2mgtp_in_check_condition(_,_,[]).
pr2mgtp_in_check_condition(X,Y,[Con|_]) :-
	(Con = {X == Y};Con = {Y == X};Con = {X = Y};Con = {Y = X}).
pr2mgtp_in_check_condition(X,Y,[Con|_]) :-
	(Con = {X \== Y};Con = {Y \== X}),!,fail.
pr2mgtp_in_check_condition(X,Y,[_|Con]) :-
	\+(Con = []),
	pr2mgtp_in_check_condition(X,Y,Con).

%
% pr2mgtp_in_inclause(Body,BodyList)
%   Body : ����Υǡ���
%   BodyList : ʬ����줿����Υǡ���
% ����� Negative literal �� Objective literal ��ʬ����
%
pr2mgtp_in_inclause([],[[[],[]]]).
pr2mgtp_in_inclause([X],[[O1,N1]]) :-
	pr2mgtp_in_inclause1(X,O1,N1).
pr2mgtp_in_inclause([X|Y],[[O1,N1]|L]) :-
	pr2mgtp_in_inclause1(X,O1,N1),
	pr2mgtp_in_inclause(Y,L).

pr2mgtp_in_inclause1([],[],[]).
pr2mgtp_in_inclause1([not P],[],[P]).
pr2mgtp_in_inclause1([P],[P],[]).
pr2mgtp_in_inclause1([not P|L],T,[P|L1]) :- pr2mgtp_in_inclause1(L,T,L1).
pr2mgtp_in_inclause1([P|L],[P|L1],N) :- pr2mgtp_in_inclause1(L,L1,N).


%
% <<<< check Disjunction >>>>
%   Disjunction ���Ѥ���ɽ����ǽ���᤬������Ѵ�
%
pr2mgtp_disjunction(Int,C_num) :-
	'Clause'(Int,[_],[[P,_]]),
	Next is Int +1,
	/* �������Ʊ�� Objective literal ��������õ�� */
	pr2mgtp_check_positive([Int],Next,P,C_num),
	/* ���� Negative literal �� append ���� */
	pr2mgtp_head_append_negative(C_num,[],HN_list),
	/* Disjunction ���Ѵ���ǽ�������å� */
	pr2mgtp_test_disjunction(HN_list),
	pr2mgtp_disjunction(Next,_).
/* ¾���᤬¸�ߤ��뤫�����å� */
pr2mgtp_disjunction(Int,C_num) :-
	'COUNT'(clause,N),
	Int < N,
	Nint is Int + 1,
	pr2mgtp_disjunction(Nint,C_num).
pr2mgtp_disjunction(_,[]).

%
% pr2mgtp_check_positive(C,Num,P,C_num)
%   C : work variable
%   Num : �ǽ��õ���������ֹ�
%   P : objective literal
%   C_num : P �� objective literal �˻���������ֹ�
% P �� objective literal �ˤ�����õ��
%
pr2mgtp_check_positive(C,Num,Pd,C_num) :-
	'Clause'(Num,[_],[[P,_]]),
	Next is Num +1,!,
	/* Ʊ�� objective literal ����Ĥ������å� */
	(each_holds_equal_list(Pd,P) ->
	 pr2mgtp_check_positive([Num|C],Next,Pd,C_num);
	    pr2mgtp_check_positive(C,Next,Pd,C_num)).
pr2mgtp_check_positive(C,Num,Pd,C_num) :-
	'COUNT'(clause,N),
	Num < N,
	N1 is Num +1,!,
	pr2mgtp_check_positive(C,N1,Pd,C_num).
pr2mgtp_check_positive(C,_,_,C).

%
% pr2mgtp_head_append_negative(N,X,List)
%   N : ���ֹ�
%   X : work variable
%   List : append �����ꥹ�Ȥ����ֹ����ĥꥹ��
% ����negative literal �� append �����ꥹ�Ȥκ���
%
pr2mgtp_head_append_negative([],X,X).
pr2mgtp_head_append_negative([Num|C],D,HN_list) :-
	'Clause'(Num,[H],[[P,N]]),
	append(H,N,HN),
	pr2mgtp_check_variable(HN),!,
	pr2mgtp_head_append_negative(C,[[Num,P,HN]|D],HN_list).
pr2mgtp_head_append_negative([Num|C],D,HN_list) :-
	'Clause'(Num,[H],[[P,N]]),
	append(H,N,HN),
	pr2mgtp_check_literal(HN),!,
	pr2mgtp_head_append_negative(C,[[Num,P,HN]|D],HN_list).
pr2mgtp_head_append_negative([_|C],D,HN_list) :- !,
	pr2mgtp_head_append_negative(C,D,HN_list).

%
% pr2mgtp_test_disjunction(List)
%   List : ���� Negative literal �� append ������Τ����ֹ����ĥꥹ��
% Disjunction ��ɽ����ǽ�������å�
%
pr2mgtp_test_disjunction([]).
pr2mgtp_test_disjunction([[Num,P,HN]|L]) :-
	/* append �����ꥹ�Ȥ�Ʊ�����õ�� */
	pr2mgtp_eq_HN(HN,L,[Num],Nlist),
	pr2mgtp_check_disjunction(HN,Nlist,S,Hlist),
%	(pr2mgtp_check_variable(Hlist) -> true;pr2mgtp_check_literal(Hlist)),
	(S = yes -> pr2mgtp_make_disjunction(Nlist,P,HN,Hlist);true).

%
% pr2mgtp_eq_HN(L,List,N,Nlist)
%   L : ���Ȥʤ�ꥹ��
%   List : ��Υǡ���
%   N : work variable
%   Nlist : Ʊ�� append �����ꥹ�Ȥ�������ֹ�Υꥹ��
% ���� append �����ꥹ�Ȥ�Ʊ���ꥹ�Ȥ�������õ��
%
pr2mgtp_eq_HN(_,[],N,N).
pr2mgtp_eq_HN(HNd,[[Num,_,HN]|L],N,Nlist) :-
	equal_list(HNd,HN),
	pr2mgtp_eq_HN(HNd,L,[Num|N],Nlist).
pr2mgtp_eq_HN(HNd,[_|L],N,Nlist) :-
	pr2mgtp_eq_HN(HNd,L,N,Nlist).

%
% pr2mgtp_check_disjunction(L,Nlist,S,Hlist)
%   L : append �����ꥹ��
%   Nlist : ���ֹ�Υꥹ��
%   S : ɽ����ǽ����Ƚ���̡�yes,no��
%   Hlist : ���ˤ����ƥ��Υꥹ��
% Disjunction ��ɽ����ǽ�������å�
pr2mgtp_check_disjunction(_,[_],no,_).
pr2mgtp_check_disjunction(HN,Nlist,S,Hlist) :-
	/* ��ο�������å� */
	length(Nlist,N1),length(HN,N2),
	N1 =< N2,
	pr2mgtp_check_disjunction1(Nlist,HN,[],Hlist),
	pr2mgtp_check_head(Hlist),
	S = yes.
pr2mgtp_check_disjunction(_,_,no,_).

/* ���ˤ����ƥ��Υꥹ�Ȥ���� */
pr2mgtp_check_disjunction1([],_,H,H) :- !.
pr2mgtp_check_disjunction1([Num|N],HN,H,Hlist) :-
	'Clause'(Num,[[Head]],_),
	pr2mgtp_check_disjunction1(N,HN,[Head|H],Hlist).

/* Disjunct �˽�ʣ���ʤ��������å� */
pr2mgtp_check_head(Hlist) :-
	'head'(H),
	pr2mgtp_out_check_head2(Hlist,H).

%
% pr2mgtp_check_variable(List)
%   List : append ���줿�ꥹ��
% �ꥹ�Ȥ����Ǥ��ѿ����ޤޤ�Ƥ��뤫�Υ����å�
pr2mgtp_check_variable([]).
pr2mgtp_check_variable([X|_]) :-
	in_var(X),!,fail.
pr2mgtp_check_variable([_|L]) :- !,
	pr2mgtp_check_variable(L).

%
% pr2mgtp_check_literal(List)
%   List : append ���줿�ꥹ��
% List �����ǤνҸ�̾�����٤Ƥ��Ȥʤ�,�ѿ���Ʊ����Τʤ��,����
%
pr2mgtp_check_literal([X|List]) :-
	copy_term([X|List],L),copy_term(X,X1),
	numbervars(L,0,N),numbervars(X1,0,N1),!,
	N1 >= N,
	pr2mgtp_check_literal1(List).

pr2mgtp_check_literal1([]).
pr2mgtp_check_literal1([X|L]) :-
	/* X ����Ȥ��� */
	X =.. [F|_],
	copy_term(X,X1),numbervars(X1,0,An),!,
	pr2mgtp_check_predicate1(F,An,L),
	pr2mgtp_check_literal1(L).

pr2mgtp_check_predicate1(_,_,[]).
pr2mgtp_check_predicate1(F,N,[X|L]) :-
	/* �Ҹ�̾���ѿ��Υ����å� */
	X =.. [F1|_],
	\+(F = F1),
	copy_term(X,X1),!,numbervars(X1,0,N),
	pr2mgtp_check_predicate1(F,N,L).

%
% pr2mgtp_make_disjunction
% Disjunction �κ���
%
pr2mgtp_make_disjunction([Num],P,HN,Hlist) :-
	retract('Clause'(Num,_,_)),
	subtraction(HN,Hlist,NewN),
	pr2mgtp_disjunction_head(Hlist,Head),
	counter(get,clause,C),
	assertz('Clause'(C,Head,[[P,NewN]])),
	(retract('dis'(X)) -> asserta('dis'([Head|X]));
	    asserta('dis'([Head]))).
pr2mgtp_make_disjunction([Num|L],P,HN,Hlist) :-
	retract('Clause'(Num,_,_)),
	pr2mgtp_make_disjunction(L,P,HN,Hlist).

pr2mgtp_disjunction_head([],[]).
pr2mgtp_disjunction_head([H|L],[[H]|L1]) :-
	pr2mgtp_disjunction_head(L,L1).

%
% pr2mgtp_clause_list
% �ץ���������Τ���ꥹ�Ȥ����
%
pr2mgtp_clause_list(Int) :-
	pr2mgtp_clause_list1(Int,CL),
	assertz('cl'(CL)).

pr2mgtp_clause_list1(N,[[Head,Body]|CL]) :-
	'Clause'(N,Head,Body),
	((Head = [_,_|_],form(nodis)) -> pr2mgtp_out_check_disjunct(Head,Body);
	    true),
	N1 is N +1,
	pr2mgtp_clause_list1(N1,CL).
pr2mgtp_clause_list1(N,CL) :-
	'COUNT'(clause,Num),
	N < Num,
	N1 is N +1,
	pr2mgtp_clause_list1(N1,CL).
pr2mgtp_clause_list1(_,_).

%
% pr2mgtp_out_check_disjunct(D,Body)
%   D : Disjunct
%   Body : �������
% Disjunct ��Ʊ���ѿ����Ѥ����Ƥ��뤫�����å�����
%
pr2mgtp_out_check_disjunct(D,Body) :-
	pr2mgtp_out_take_condition1(Body,[],Con),
	pr2mgtp_check_disjunct_variable(D,Con).
pr2mgtp_out_check_disjunct(_,_) :- assertz('form'(dis)).

% take up condition from clause's body
pr2mgtp_out_take_condition1([],X,X) :- !.
pr2mgtp_out_take_condition1([[Obj,_]|L],X,Con) :-
	pr2mgtp_in_take_condition(Obj,C1),
	append(X,C1,Y),
	pr2mgtp_out_take_condition1(L,Y,Con).

% check variable of disjunct
pr2mgtp_check_disjunct_variable(D,Con) :-
	copy_term(D,D1),numbervars(D1,0,X),
	\+(X = 0),
	pr2mgtp_take_variable(D1,V),!,
	pr2mgtp_check_condition(V,Con).
pr2mgtp_check_disjunct_variable(_,_).

% make a variable list from Disjunction
pr2mgtp_take_variable([],_).
pr2mgtp_take_variable([D|L],V) :-
	pr2mgtp_take_variable1(D,[],X),
	(X = [] -> true;pr2mgtp_var_list(X,V)),
	pr2mgtp_take_variable(L,V).

% make a variable from each Disjunct
pr2mgtp_take_variable1([],X,Y) :- remove_same_element(X,Y).
pr2mgtp_take_variable1([L|R],X,Y) :-
	in_var_take(L,V),
	append(X,V,Z),
	pr2mgtp_take_variable1(R,Z,Y).

% variable list
pr2mgtp_var_list(New,[M1|M2]) :-
	(var(M1) -> M1 = New;
	    holds_equal_list(M1,New) ->true;pr2mgtp_var_list(New,M2)).

pr2mgtp_check_condition(V,Con) :-
	\+length(V,1),
	pr2mgtp_list_append(V,[],V1),!,
	pr2mgtp_check_condition1(V1,Con).
pr2mgtp_check_condition(_,_).

% append of list's element
pr2mgtp_list_append([],X,Y) :- remove_same_element(X,Y),!.
pr2mgtp_list_append([X|L],Y,Z) :-
	append(X,Y,A),
	pr2mgtp_list_append(L,A,Z).

% condition check
pr2mgtp_check_condition1(V,Con) :-
	length(V,N),
	pr2mgtp_count_equal(Con,0,Ceq),!,
	pr2mgtp_count_notequal(Con,0,0),
	Ceq >= N-1.

% return number of equal condition
pr2mgtp_count_equal([],N,N) :- !.
pr2mgtp_count_equal([X|L],N,Num) :-
	((X = {_ = _};X = {_ == _}) -> N1 is N +1;N1 = N),
	pr2mgtp_count_equal(L,N1,Num).

% return number of not equal condition
pr2mgtp_count_notequal([],N,N) :- !.
pr2mgtp_count_notequal([X|L],N,Num) :-
	(X = {_ \== _} -> N1 is N +1;N1 = N),
	pr2mgtp_count_notequal(L,N1,Num).

%
% <<<< write to a file >>>>
%
pr2mgtp_out(File) :-
	% there is a Abducible ?
%%	printf(['check programs form ... ']),
	tell(File),
	/* check program form */
	(retract('Assume'(AbdList)) -> pr2mgtp_out_program_form(AbdList),
            assert(p(abductive));
	    pr2mgtp_out_program_form([]),AbdList=[],assert(p(extended))),
%%	print(user,'ok !!'),nl(user),
%%	print(user,'generating negative clause by Negation as Failure ... '),
%%	nl(user),nl(user),
        pr2mgtp_out_generate_nclause(AbdList,S1,S2),
	/* ��negative clause �ν��� */
	pr2mgtp_out_each_nclause(S1,S2),
%%	nl(user),
%%        print(user,'ok !!'),nl(user),
	print(user,'saving program in '),print(user,File),
	print(user,' ... '),
	/* ��ν��� */
	pr2mgtp_out_clause(AbdList),
	/* ����ν��� */
	pr2mgtp_out_negative(AbdList),
	/* ��¬�ν��� */
	pr2mgtp_out_observation,
	/* Prolog �����ν���*/
	pr2mgtp_out_predicate,
	told,
	printf(['done !!',{nl}]),
	!.

%
% pr2mgtp_out_program_form(Abd)
%   Abd : abducible list
% check program form
%
pr2mgtp_out_program_form([]) :-
	pr2mgtp_out_check_disjunction(Loop),
	(('form'(dis);Loop = yes) -> printf(['program(edp).',{nl}]);
	    printf(['program(nredp).',{nl}])).
pr2mgtp_out_program_form([]) :-
	printf(['program(elp).',{nl}]).
pr2mgtp_out_program_form(_) :-
	pr2mgtp_out_check_disjunction(Loop),
	(('form'(dis);Loop = yes) -> printf(['program(aedp).',{nl}]);
	    printf(['program(nralp).',{nl}])).
pr2mgtp_out_program_form(_) :-
	printf(['program(aelp).',{nl}]).

%
% pr2mgtp_out_check_disjunction(Loop)
%   Loop :
% head cycle ��¸�ߤ��뤫�����å�
%
pr2mgtp_out_check_disjunction(Loop) :-
	retract('head'(H)),
	retract('dis'(Dis)),
	/* disjunctive ��Ʊ����ƥ�뤬¸�ߤ��뤫�����å� */
	(pr2mgtp_out_check_head(Dis,H) -> true;Loop = yes).

%
% pr2mgtp_out_check_head(Dis,Head)
%   Dis : Disjunct �Υꥹ��
%   Head : Head �ˤ����ƥ��Υꥹ��
% Disjunct ��Ƴ���롼�뤬ʣ��¸�ߤ��뤫
%   ¸�ߤ���ʤ��,����
%
pr2mgtp_out_check_head([],_).
pr2mgtp_out_check_head([Dis|L],H) :- !,
	pr2mgtp_out_check_head1(Dis,H),
	pr2mgtp_out_check_head(L,H).

pr2mgtp_out_check_head1([],_).
pr2mgtp_out_check_head1([Dis|L],H) :- !,
	pr2mgtp_out_check_head2(Dis,H),
	pr2mgtp_out_check_head1(L,H).

pr2mgtp_out_check_head2([],_).
pr2mgtp_out_check_head2([Dis|L],H) :- !,
	pr2mgtp_out_mem2(Dis,H,0),
	pr2mgtp_out_check_head2(L,H).

pr2mgtp_out_mem2(_,[],_).
pr2mgtp_out_mem2(X,[X|_],1) :- !,fail.
pr2mgtp_out_mem2(X,[X|L],0) :- !,
	pr2mgtp_out_mem2(X,L,1).
pr2mgtp_out_mem2(X,[_|L],S) :- !,
	pr2mgtp_out_mem2(X,L,S).


%
% pr2mgtp_out_check_loop(Dis,CL)
%   Dis : Disjunctive list
%   CL : �ץ���������Τ���ǡ���
% head cycle ��¸�ߤ��뤫�����å�
%   ¸�ߤ��ʤ��ʤ��,����
%
pr2mgtp_out_check_loop([],_).
pr2mgtp_out_check_loop([Dish|L],CL) :-
	pr2mgtp_out_check_loop1(Dish,Dish,CL),!,
	pr2mgtp_out_check_loop(L,CL).

% take up disjunction
pr2mgtp_out_check_loop1([],_,_).
pr2mgtp_out_check_loop1([Dis|L],Dish,CL) :-
	pr2mgtp_out_check_loop2(Dis,Dish,CL),!,
	pr2mgtp_out_check_loop1(L,Dish,CL).

% take up conjunction
pr2mgtp_out_check_loop2([],_,_).
pr2mgtp_out_check_loop2([Con|L],Dish,CL) :-
	pr2mgtp_out_loop(Con,Dish,CL,[Con]),!,
	pr2mgtp_out_check_loop2(L,Dish,CL).

pr2mgtp_out_loop(Con,Dish,CL,His) :-
	pr2mgtp_out_match_body(Con,CL,Head),!,
	pr2mgtp_out_loop1(Dish,CL,Head,His).
pr2mgtp_out_loop(_,_,_,_).

pr2mgtp_out_loop1(Dish,CL,[Head|L],His) :-
	\+(Head = []),!,
	pr2mgtp_out_loop2(Dish,CL,Head,His),
	pr2mgtp_out_loop1(Dish,CL,L,His).
pr2mgtp_out_loop1(_,_,_,_).

pr2mgtp_out_loop2(_,_,[],_).
pr2mgtp_out_loop2(Dish,CL,[H|L],His) :-
	\+(member(H,His)),!,
	pr2mgtp_out_disjunction_literal(H,Dish,His),
	pr2mgtp_out_loop(H,Dish,CL,[H|His]),
	pr2mgtp_out_loop(Dish,CL,L,His).

%
% pr2mgtp_out_match_body(Con,CL,Head)
%   Con : literal
%   CL : ��ǡ���
%   Head : �ޥå��󥰤�����θ��
% Con �ȥܥǥ��Υޥå���
%   �ޥå��󥰤�����θ����֤�
%
pr2mgtp_out_match_body(_,[],_).
pr2mgtp_out_match_body(Con,[[Head,[[Obj,_]|_]]|_],Head) :-
	subsume_list(Con,Obj);subsume1_list(Con,Obj).
pr2mgtp_out_match_body(Con,[[Head,[_|L]]|CL],H) :-
	\+(L = []),
	pr2mgtp_out_match_body(Con,[[Head,L]|CL],H).
pr2mgtp_out_match_body(Con,[_|L],H) :-
	pr2mgtp_out_match_body(Con,L,H).

%
% pr2mgtp_out_disjunction_literal(Con,Dis,His)
%   Con : literal
%   Dis : disjunctive list
%   His : history
% Con �� ����disjunctive �ʳ��� disjunctive �������å�
%
pr2mgtp_out_disjunction_literal(Con1,Dish,His) :-
	last_list(His,D),
	pr2mgtp_out_other_disjunction(Dish,D,Disl),!,
	pr2mgtp_out_not_member_literal(Con1,Disl).

%
% pr2mgtp_out_other_disjunction(Dis,D,Disj)
%   Dis : disjunctive list
%   D : ����disjunctive
%   Disj : D �������disjunctive list
% D ������� disjunctive list �κ���
%
pr2mgtp_out_other_disjunction([Dis|L],D,L) :- member(D,Dis).
pr2mgtp_out_other_disjunction([Dis|L],D,[Dis|L1]) :-
	pr2mgtp_out_other_disjunction(L,D,L1).

pr2mgtp_out_not_member_literal(_,[]).
pr2mgtp_out_not_member_literal(Con,[Dis|_]) :-
	subsume_list(Con,Dis),
	!,fail.
pr2mgtp_out_not_member_literal(Con,[_|L]) :-
	pr2mgtp_out_not_member_literal(Con,L).


%
% generate negative clause from program
%
pr2mgtp_out_generate_nclause(Abd,S1,_) :-
	make_situation(1),
        pr2mgtp_out_generate_nclause1(Abd,1,X),
	pr2mgtp_out_check_nclause1(X,S1).
%%	pr2mgtp_out_generate_nclause2(Abd,1,S1,Y),
%%	pr2mgtp_out_check_nclause2(S1,Y,S2).

%
% pr2mgtp_out_generate_nclause1(Abd,Int,S)
%   Abd : ����ν���
%   Int : ���ֹ�
%   S : negative clause1 ����
% NAF �� negative clause1 �θ���Ȥ��ƥꥹ�Ȥ����
%
pr2mgtp_out_generate_nclause1(Abd,Int,S) :-
	'Clause'(Int,_,Body),

%%        print(user,'Body ='),
%%        print(user,Body),
%%        nl(user),

	pr2mgtp_out_nclause1_list(Abd,Body,S),
        Next is Int + 1,
	pr2mgtp_out_generate_nclause1(Abd,Next,S).
pr2mgtp_out_generate_nclause1(Abd,Int,S) :-
	'COUNT'(clause,N),
	Int < N,
	Next is Int +1,
	pr2mgtp_out_generate_nclause1(Abd,Next,S).
pr2mgtp_out_generate_nclause1(_,_,_).

/* �ܥǥ����� NAF ����Ф� */
pr2mgtp_out_nclause1_list(_,[],_).
pr2mgtp_out_nclause1_list(Abd,[[_,Neg]|L],S) :-
	pr2mgtp_out_nclause1_list1(Abd,Neg,S),
	pr2mgtp_out_nclause1_list(Abd,L,S).

/* NAF �ꥹ�Ȥκ��� */
pr2mgtp_out_nclause1_list1(_,[],_).
pr2mgtp_out_nclause1_list1(Abd,[Neg|L],S) :-
	/* Neg ����������ᤵ��ʤ��ʤ��,����Ȥ��� */
	(subsume_list(Neg,Abd) -> pr2mgtp_out_nclause1_list1(Abd,L,S);
	    nclause1_list(Neg,S),
	    pr2mgtp_out_nclause1_list1(Abd,L,S)).

%
% check generated schema1
%
pr2mgtp_out_check_nclause1(S,S1) :-
	pr2mgtp_out_check_naf(S,X),
	pr2mgtp_out_check_same_nclause1(X,S1).

%
% pr2mgtp_out_check_naf(X,Y)
%   X : negative clause ����
%   Y : negative clause
% resolution check of each Negative literal
%
pr2mgtp_out_check_naf([],[]).
pr2mgtp_out_check_naf([S|L],S1) :-
	pr2mgtp_out_check_trans(S,[],[], nbk, _),
	pr2mgtp_out_check_naf(L,S1).
pr2mgtp_out_check_naf([S|L],[S|L1]) :-
	pr2mgtp_out_check_naf(L,L1).

%
% pr2mgtp_out_check_trans(S, His,N, Mode, Type)
%   S : Ƴ�Ф��ߤ� literal
%   His : history
%   N : negative literal
%   Mode : backtrack����,�ʤ���bk,nbk��
%   Type : P-literal�Υ����å�(obj)
% resolution check
%
/* ���ξ�� */
pr2mgtp_out_check_trans({X}, _,_, _, _) :- !,X.
/* �롼�פˤʤ��� */
pr2mgtp_out_check_trans(S, His,_, _, _) :- hold_member(S,His),!.
%pr2mgtp_out_check_trans(S, His,_, _) :- subsume_list(S,His),!.
pr2mgtp_out_check_trans(S, His,N, Mode, Type) :-
	pr2mgtp_out_head_matching(1,S,His,N,Mode,Type).

%
% pr2mgtp_out_head_matching(N,S,His,Neg,Mode,Type)
%   N : ���ֹ�
%   S : literal
%   His : History
% Head matching
%
pr2mgtp_out_head_matching(N,S,His,Neg,Mode,Type) :-
	functor(S,Sit,_),
        Sit == situation,
	'COUNT'(clause,Num),
	(Num == N -> 	S = situation(X),situation(X);
	N1 is N +1,!,
	pr2mgtp_out_head_matching(N1,S,His,Neg,Mode,Type)).
pr2mgtp_out_head_matching(N,S,His,Neg,Mode,Type) :-
	functor(S,Sit,_),
        Sit == reachable,
	'COUNT'(clause,Num),
	(Num == N -> 	S = reachable(X),situation(X);
	N1 is N +1,!,
	pr2mgtp_out_head_matching(N1,S,His,Neg,Mode,Type)).
pr2mgtp_out_head_matching(N,S,His,Neg,Mode,Type) :-
	copy_term(S,S1),
        'Clause'(N,H,B),

        pr2mgtp_out_head_matching1(H,B,S,Body),
        (S \== S1 -> pr2mgtp_out_check_body(Body,[S|His],Neg, Mode,Loop),
             ((Type == 'obj' ; Type == 'neg') -> true ;        
                     S3 = [S|His],
                     last_list(S3,Fun),
                     functor(Fun,Name,_),
                     (Name == '-' -> Fun =.. [_|[X1]],
                                     functor(X1,Name1,_),
                                     S4 = ['-'Name1|S3] ; S4 = [Name|S3]),
                     
%%                     nl(user),
%%                     print(user,'Loop = '),
%%                     print(user,Loop),
%%                     nl(user),

                     (Loop == 'yes' -> S5 = ['yes'|S4] 
                                       ; S5 = ['no'|S4]
                     ),

%%                     print(user,'History = '),
%%                     print(user,S5),
%%                     nl(user),

                     (retract('History'(S5)) ->  assertz('History'(S5));
                                                 assertz('History'(S5))
                     ),
      
                     fail
             )
                   ; pr2mgtp_out_check_body(Body,[S|His],Neg, Mode,Loop)
        ).


pr2mgtp_out_head_matching(N,S,His,Neg,Mode,Type) :-
	'COUNT'(clause,Num),
	Num > N,
	N1 is N +1,!,
	pr2mgtp_out_head_matching(N1,S,His,Neg,Mode,Type).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%% begin for Ation MGTP %%%%%%%%%%%%%%
/*----------------------------*/
/*  ����̾������§�Υ�������  */
/* �ΰ�̾��§�Υ������Ȥ�ޤ� */
/*----------------------------*/
/*------------------------------------------------
ex. (1)situation([A2,A1]) :- action(A1),action(A2).
       situaiton([A1]) :- action(A1).
       situation([]).
         �⤷����
    (2)situation([a2,a1]).
       situation([a1]).
       situation([]).  �򥢥����� 
--------------------------------------------------*/
make_situation(N):-
	'Clause'(N,H,B),
	H=[[H1]],functor(H1,H2,_),
	H2 = situation,H1=situation(X),
	length(X,L),
	(L == 0 -> assert(situation([]));
	X=[X1|_],
	(var(X1)->
	    B=[[B1,[]]],
	    body_make(B1,Bout),
	    B2 = [','|Bout],
	    assert_sit_law(L,X,B2);
            assert_sit(X))),!,
	    assert_action_fluent(1).
make_situation(N):-
	'COUNT'(clause,Num),
	Num > N,
	N1 is N +1,!,
	make_situation(N1).

/* ����̾������§(1)�Υܥǥ������ */
/*  [action(A1),...,action(An)]
	����  [action(A1)]   �ޤǤ����    */
body_make(B,B):-
	length(B,L),
	L < 3,!.
body_make(B,Bout):-
	body_make1(B,Btmp),
	body_make(Btmp,Bout).

body_make1([Bodyh|Bodyt],[Bodyh,Bout]):-
	length(Bodyt,2),
	Bout =.. [','|Bodyt].
body_make1([Bodyh|Bodyt],[Bodyh|X]):-
	body_make1(Bodyt,X).

/* ����̾������§(1)�򥢥����� */
assert_sit_law(0,_,_):- assert(situation([])),!.
assert_sit_law(1,_,_):- 
	assert((situation([A1]):-action(A1))),
	assert_sit_law(0,_,_).
assert_sit_law(L,Head,Body):-
 	B1 =.. Body,
	assert((situation(Head):- B1)),
	L1 is L-1,
	Head=[_|Headt],
	Body =[_,_|Bodyt],
	Bodyt = [Btin],
	Btin =.. BB,
	assert_sit_law(L1,Headt,BB).

/* ����̾������§(2)�򥢥����� */
assert_sit([]):- asserta(situation([])),!.	
assert_sit(X):-
	asserta((situation(X))),
	X=[_|Xt],
	assert_sit(Xt).

/* �ΰ�̾��§�򥢥����� */
assert_action_fluent(N):-
	'COUNT'(clause,Num),
	Num == N,!.
assert_action_fluent(N):-
	'Clause'(N,[[H]],B),
	(functor(H,fluent,_);functor(H,action,_)),
        B=[[B1,[]]],
	(B1 == [] -> assert(H);
	body_make(B1,Bout),
	length(Bout,L),
	B2 = [','|Bout],
	assert_domain_law(L,H,B2)),
	N1 is N+1,
	assert_action_fluent(N1).
assert_action_fluent(N):-
	N1 is N+1,
	assert_action_fluent(N1).


assert_domain_law(1,Head,[','|Body]):- 
	Body = [Body1],
	assert((Head:-Body1)),!.
assert_domain_law(_,Head,Body):-
 	Body1 =.. Body,
	assert((Head:-Body1)).


%%%%%%%%%%%%% end for Action MGTP %%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%
% check of list case 
%

sub_head_matching([[S1|_]|_],S) :-
        functor(S1,Sname1,_),
        functor(S,Sname,_),
        Sname1 == Sname,

        copy_term(S1,Y1),
        copy_term(S,Y),
        copy_term(S1,X1),
        copy_term(S,X),
        numbervars(X1,0,Var1),
        numbervars(X,0,Var),
        nl(user),
        print(user,'S1 = '),
        print(user,X1),
        nl(user),
        print(user,'Var1 = '),
        print(user,Var1),
        nl(user),
        print(user,'S = '),
        print(user,X),
        nl(user),
        print(user,'Var = '),
        print(user,Var),
        nl(user),

        sub_check_head_list(Y,Y1).

sub_head_matching([[_|L]|L1],S) :- !,
	sub_head_matching([L|L1],S).
sub_head_matching([[]|L],S) :- !,
	sub_head_matching(L,S).

sub_check_head_list(Y,Y1) :-
	(((check_list(Y1),\+check_list(Y)) 
	 ; (check_list(Y),\+check_list(Y1))) 
               -> fail ; true).

/* ����ˤ����ƥޥå���A��Ԥʤ� */
pr2mgtp_out_head_matching1([[S|_]|_],Body,S,Body).

%pr2mgtp_out_head_matching1([[H|_]|_],Body,S,Body) :-
%	subsume(S,H).
pr2mgtp_out_head_matching1([[_|L]|L1],B,S,Body) :- !,
	pr2mgtp_out_head_matching1([L|L1],B,S,Body).
pr2mgtp_out_head_matching1([[]|L],B,S,Body) :- !,
	pr2mgtp_out_head_matching1(L,B,S,Body).

%
% list check
%
check_list(S) :- 
	S =.. X,
        X = [Xh|[Xt]],
        (Xh == '-' -> Xt =.. X1,sub_check_var(X1) 
                      ; sub_check_var(X)
        ).

sub_check_var([H|_]) :- \+var(H),
        sub_check_list(H).
sub_check_var([_|T]) :- !,
        sub_check_var(T).

sub_check_list([]).
sub_check_list([_|_]).

%
% pr2mgtp_out_check_body(S,His,N, Mode)
%   S : reasoning literal
%   Body : �������ǡ���
%   His : history
%   N : negative literal
%   Mode : backtrack mode
% check body
%
/* Ƴ�Ф���� */
pr2mgtp_out_check_body([[[],[]]|_],_,_, _,_) :- !.
/* Ƴ�Ф򤳤����ߤ�literal��NAF��¸�ߤ��� */
pr2mgtp_out_check_body([[_,Neg]|L],His,N, Mode,Loop) :-
	hold_intersection(N,Neg,In),
	\+(In = []),!,
	\+(L = []),
	 pr2mgtp_out_check_body(L,His,N, Mode,Loop).
pr2mgtp_out_check_body([[Obj,Neg]|_],His,N, nbk,Loop) :- 
	pr2mgtp_out_check_obj(Obj,His,N, nbk,Loop),
      	pr2mgtp_out_check_neg(Neg,His,N,nbk,Loop).
pr2mgtp_out_check_body([[Obj,Neg]|_],His,N, bk,Loop) :-
	pr2mgtp_out_check_obj(Obj,His,N, bk,Loop),
        pr2mgtp_out_check_neg(Neg,His,N,bk,Loop).
pr2mgtp_out_check_body([_|L],His,N, Mode,Loop) :- !,
	\+(L = []),
       	pr2mgtp_out_check_body(L,His,N, Mode,Loop).
       

% resolusion of objective literal
pr2mgtp_out_check_obj([],_,_, _,_).
pr2mgtp_out_check_obj([_|L],His,N, Mode,Loop) :-
	(last_list(His,X),component_check(X);
	    His = [X|_],component_check(X)),!,Loop = 'yes',
  	pr2mgtp_out_check_obj(L,His,N, Mode,Loop).
pr2mgtp_out_check_obj([Obj|L],His,N, Mode,Loop) :-
        Type = 'obj',
      	pr2mgtp_out_check_trans(Obj,His,N, Mode,Type),
      	hold_intersection(N,L,In),
	In = [],
	pr2mgtp_out_check_obj(L,His,[Obj|N], Mode,Loop).


% head matching of negative literal
pr2mgtp_out_check_neg([],_,_,_,_).
pr2mgtp_out_check_neg(Neg,N,_,_,_) :-
%	hold_intersection(Neg,N,In),
        hold_intersection(N,Neg,In),
	\+(In = []),!,fail.

pr2mgtp_out_check_neg([Neg|L],His,N,_,_) :-
        Type = 'neg',
        \+pr2mgtp_out_check_trans(Neg,His,N, _,Type),
        pr2mgtp_out_check_neg(L,N,His,_,_).

%
% pr2mgtp_out_check_fact(N,X)
%   N : ���ֹ�
%   X : ��ƥ��
% X�����¤�Ĵ�٤�
% 
pr2mgtp_out_check_fact(N,X,His) :-
	'Clause'(N,H,B),
        
	pr2mgtp_out_head_matching1(H,B,X,Body),
        pr2mgtp_out_check_body(Body,[X|His],_,_,_).

pr2mgtp_out_check_fact(N,X,His) :-
	'COUNT'(clause,Num),
	Num > N,
	N1 is N +1,!,
	pr2mgtp_out_check_fact(N1,X,His).


% delete same negative clause1
pr2mgtp_out_check_same_nclause1([],[]).
pr2mgtp_out_check_same_nclause1([X|L],L1) :-
	member(X,L),
	pr2mgtp_out_check_same_nclause1(L,L1).
pr2mgtp_out_check_same_nclause1([X|L],[X|L1]) :-
	pr2mgtp_out_check_same_nclause1(L,L1).


%
% generate Negative clause2
%    These are Negative clause2 by Head and Negation as Failure
%
pr2mgtp_out_generate_nclause2(Abd,Int,S1,S) :-
	'Clause'(Int,Head,Body),
	pr2mgtp_out_nclause2_list(Abd,Head,Body,S1,S),
	Next is Int +1,
	pr2mgtp_out_generate_nclause2(Abd,Next,S1,S).
pr2mgtp_out_generate_nclause2(Abd,Int,S1,S) :-
	'COUNT'(clause,N),
	Int < N,
	Next is Int +1,
	pr2mgtp_out_generate_nclause2(Abd,Next,S1,S).
pr2mgtp_out_generate_nclause2(_,_,_,_).

%
% pr2mgtp_out_nclause2_list(Abd,Head,Body,S1,S)
%   Abd : ���⽸��
%   Head : ������θ��
%   Body : �����������
%   S1 : negative clause1 list
%   S : negative clause2 ����
% ������ˤ����Ƹ���NAF�Υڥ��ꥹ�Ȥ����
%
pr2mgtp_out_nclause2_list(_,[],_,_,_).
pr2mgtp_out_nclause2_list(Abd,[Head|H],Body,S1,S) :-
	pr2mgtp_out_nclause2_list1(Abd,Head,Body,S1,S),
	pr2mgtp_out_nclause2_list(Abd,H,Body,S1,S).

% make negative clause2 by Head and Negation as Failure
pr2mgtp_out_nclause2_list1(_,_,[],_,_).
pr2mgtp_out_nclause2_list1(Abd,Head,[[_,[]]|B],S1,S) :-
	pr2mgtp_out_nclause2_list1(Abd,Head,B,S1,S).
pr2mgtp_out_nclause2_list1(Abd,Head,[[_,Neg]|B],S1,S) :-
	pr2mgtp_out_nclause2_list2(Abd,Head,Neg,S1,S),
	pr2mgtp_out_nclause2_list1(Abd,Head,B,S1,S).

pr2mgtp_out_nclause2_list2(_,[],_,_,_).
pr2mgtp_out_nclause2_list2(Abd,[X|L],Neg,S1,S) :-
	pr2mgtp_out_nclause2_list3(Abd,X,Neg,S1,S),
	pr2mgtp_out_nclause2_list2(Abd,L,Neg,S1,S).

/* �ڥ��Υꥹ�Ȥˤ�,negative clause1 �ꥹ�Ȥ����Ǥ�ޤޤʤ� */
pr2mgtp_out_nclause2_list3(_,_,[],_,_).
pr2mgtp_out_nclause2_list3(Abd,X,[Y|L],S1,S) :-
	X == Y,
	pr2mgtp_out_nclause2_list3(Abd,X,L,S1,S).
pr2mgtp_out_nclause2_list3(Abd,Head,[Neg|L],S1,S) :-
	\+member(Neg,S1),
	\+subsume_list(Neg,Abd),
	nclause2_list([Neg,Head],S),
	pr2mgtp_out_nclause2_list3(Abd,Head,L,S1,S).
pr2mgtp_out_nclause2_list3(Abd,Head,[_|L],S1,S) :-
	pr2mgtp_out_nclause2_list3(Abd,Head,L,S1,S).

%
% check generated Negative clause2
%
pr2mgtp_out_check_nclause2(S1,S,S2) :-
	pr2mgtp_out_check_td(S,N,S1),
	pr2mgtp_out_check_same_nclause2(N,S2).

%
% pr2mgtp_out_check_td(S,S2,S1)
%   S : negative clause2 ����
%   S2 : negative clause2
%   S1 : negative clause1
% transfer check of each schema2
%
pr2mgtp_out_check_td([],[],_).
pr2mgtp_out_check_td([[_,H]|L],X,S1) :-
	subsume_list(H,S1),
	pr2mgtp_out_check_td(L,X,S1).
pr2mgtp_out_check_td([[N,H]|L],X,S1) :-
	copy_term([N,H],[N1,H1]),
	N1 =.. [Nf|_],H1 =.. [Hf|_],
	((Nf == Hf,(in_var(N1);in_var(H1))) ->
	  pr2mgtp_out_check_trans(H1,[],[], bk,Type),
	  pr2mgtp_out_check_trans(N1,[],[H1], bk,Type),
	  \+(H1 = N1);
	    pr2mgtp_out_check_trans(H1,[],[N1], nbk,Type),
	    pr2mgtp_out_check_trans(N,[],[H1], nbk,Type)),
	pr2mgtp_out_check_td(L,X,S1).
pr2mgtp_out_check_td([[N,H]|L],[[N,H]|X],S1) :-
	pr2mgtp_out_check_td(L,X,S1).

%
% pr2mgtp_out_check_same_nclause2(X,Y)
%   X : negative clause2
%   Y : Ʊ���ڥ���ޤޤʤ� negative clause2
% check same schema2
%
pr2mgtp_out_check_same_nclause2([],[]).
pr2mgtp_out_check_same_nclause2([X|L],[X|N]) :-
	pr2mgtp_out_check_same_nclause22(X,L),!,
	pr2mgtp_out_check_same_nclause2(L,N).
pr2mgtp_out_check_same_nclause2([_|L],N) :- !,
	pr2mgtp_out_check_same_nclause2(L,N).

pr2mgtp_out_check_same_nclause22(_,[]).
pr2mgtp_out_check_same_nclause22(X,[Y|L]) :-
	\+equal_list(X,Y),
	pr2mgtp_out_check_same_nclause22(X,L).


%
% Positive clauses and Negative clauses containing Negation As Failure
%
% <<<< take up clause date>>>>
%
pr2mgtp_out_clause(AbdList) :-
	retract('Clause'(_,Suc,ONlist)),
	pr2mgtp_out_clause1(AbdList,Suc,ONlist),
	pr2mgtp_out_clause(AbdList).
pr2mgtp_out_clause(_).

%
% clause contained abducition is skiped or skiped and original work
%
pr2mgtp_out_clause1(AL,Suc,[[O,N]]) :-
	/* skip�����Τߤ��Υ����å� */
	check_not_only_skip(AL,O,N,Skip),
	set_product(Skip,S2),
	pr2mgtp_out_clause2(AL,Suc,[[O,N]],S2).
pr2mgtp_out_clause1(AL,Suc,ONlist) :-
	pr2mgtp_out_clause2(AL,Suc,ONlist,[]).

pr2mgtp_out_clause2(AL,Suc,ONlist,[]) :-
	copy_term(AL,AL1),
	/* ����Υ�ƥ�����Ȥ����Ǥʤ���Τ�ʬ���� */
	pr2mgtp_out_divide_abducible(AL1,ONlist,Plist),
	/* ��ν��� */
	pr2mgtp_out_mgtp_rule(AL1,Suc,Plist).
pr2mgtp_out_clause2(AL,Suc,ONlist,[Skip|Rem]) :-
	copy_term(AL,AL1),
	copy_term(AL,AL2),
	/* �����Ѥ�����Ѵ� */
	pr2mgtp_out_change_literal(Skip,Suc,ONlist,S1,Clist),
	/* ����Υ�ƥ�����Ȥ����Ǥʤ���Τ�ʬ���� */
	pr2mgtp_out_divide_abducible(AL1,Clist,Plist),
	/* ��ν��� */
	pr2mgtp_out_mgtp_rule(AL2,S1,Plist),
	pr2mgtp_out_clause2(AL,Suc,ONlist,Rem).


%
% pr2mgtp_out_change_literal(L,S,B,S1,B1)
%   L : ����ν���
%   S : ���θ��
%   B : ��������
%   S1 : �Ѵ���θ��
%   B1 : �Ѵ��������
% original work
%
pr2mgtp_out_change_literal(L,S,[[O,N]],S1,[[O1,N1]]) :-
	append(S,O,X),append(X,N,Y),
	copy_term(Y,Y1),
	pr2mgtp_out_hold_literal(L,Y1),
	divide(Y1,S,S1,Y2),
	divide(Y2,O,O1,Y3),
	divide(Y3,N,N1,_).

pr2mgtp_out_hold_literal([],_).
pr2mgtp_out_hold_literal([L|R],Y1) :-
	member2(L,Y1),
	pr2mgtp_out_hold_literal(R,Y1).

%
% pr2mgtp_out_divide_abducible(AL,O,N,Obj,Abd,Nge,NgeAbd)
% divide abducible for each Objective Literal and Negative Literal
%
pr2mgtp_out_divide_abducible(_,[],[]).
pr2mgtp_out_divide_abducible(AL,[[O,N]|L],[[Obj,Abd,Neg,NA]|L1]) :-
	pr2mgtp_out_divide_abducible1(AL,O,N,Obj,Abd,Neg,NA),
	pr2mgtp_out_divide_abducible(AL,L,L1).

pr2mgtp_out_divide_abducible1(AL,O,N,Obj,Abd,Neg,NegAbd) :-
% intersection of AbdList and O is Objective Abducible
	intersection(O,AL,Abd),
% subtraction Abducible from O is Objective Literal
	subtraction(O,Abd,Obj),
% intersection of AbdList and N is Negative Abducible
	intersection(N,AL,NegAbd),
% subtraction Negative Abducible from N is Negative Literal
	subtraction(N,NegAbd,Neg).


% <<<< make a MGTP rule >>>>
pr2mgtp_out_mgtp_rule(AL,Suc,Plist) :-
	hold_numbervars(Suc,Plist,S,Holdlist),
	pr2mgtp_out_mgtp_antecedent(Holdlist),
	printf(' --> '),
	pr2mgtp_out_mgtp_consequent(AL,S,Holdlist),
	printf(['.',{nl}]).

%
% hold numbervars to all parameter
%
hold_numbervars(_,[],_,[]).
hold_numbervars(Suc,[[Obj,Abd,Neg,NegAbd]|L],S,[[O,A,N,NA]|R]) :-
	append(Suc,Obj,X1),append(X1,Abd,X2),
	append(X2,Neg,X3),append(X3,NegAbd,X),
	numbervars(X,0,_),
	divide(X,Suc,S,Y1),divide(Y1,Obj,O,Y2),divide(Y2,Abd,A,Y3),
	divide(Y3,Neg,N,Y4),divide(Y4,NegAbd,NA,_),
	hold_numbervars(Suc,L,S,R).


%
% pr2mgtp_out_mgtp_antecedent(X)
%   X : ����Υꥹ��
% print antecedent of clause on output file
%
pr2mgtp_out_mgtp_antecedent([]) :- printf('true').
pr2mgtp_out_mgtp_antecedent([[[],_,_,_]|R]) :-
	pr2mgtp_out_mgtp_antecedent(R).

% a part of Disjunction
pr2mgtp_out_mgtp_antecedent([[Con,_,_,_]]) :-
	pr2mgtp_out_antecedent(Con).
pr2mgtp_out_mgtp_antecedent([[Con,_,_,_]|L]) :-
	pr2mgtp_out_antecedent(Con),
	printf(' ; '),
	pr2mgtp_out_mgtp_antecedent(L).

% a part of Conjunction
pr2mgtp_out_antecedent([{Obj}]) :- printf(['{',Obj,'}']).
pr2mgtp_out_antecedent([Obj]) :- printf(Obj).

pr2mgtp_out_antecedent([{Obj}|Rem]) :-
	printf(['{',Obj,'}, ']),
	pr2mgtp_out_antecedent(Rem).
pr2mgtp_out_antecedent([Obj|Rem]) :-
	printf([Obj,', ']),
	pr2mgtp_out_antecedent(Rem).

%
% pr2mgtp_out_mgtp_consequent(Abd,S,Body)
%   Abd : ����ν���
%   S,Body : ���Υǡ����ꥹ��
% print consequent of clause on output file
%
pr2mgtp_out_mgtp_consequent(_,[],[]).
pr2mgtp_out_mgtp_consequent(_,[],[_,[],[],[]]) :-
	printf([' --> false.',{nl}]).
pr2mgtp_out_mgtp_consequent(AL,[],[[_,[],[],[]]|R]) :-
	pr2mgtp_out_mgtp_consequent(AL,[],R).
pr2mgtp_out_mgtp_consequent(_,_,[]).
pr2mgtp_out_mgtp_consequent(AL,Suc,[[_,[],[],[]]]) :-
	pr2mgtp_out_consequent_disjunction(AL,Suc,[],[],[]).
pr2mgtp_out_mgtp_consequent(AL,Suc,[[_,[],[],[]]|R]) :-
	pr2mgtp_out_mgtp_consequent(AL,Suc,R).
pr2mgtp_out_mgtp_consequent(AL,Suc,[[_,Abd,Neg,NegAbd]|R]) :- 
	pr2mgtp_out_consequent_disjunction(AL,Suc,Abd,Neg,NegAbd),
	pr2mgtp_out_not_abducible(Abd),
	pr2mgtp_out_connect_or(Abd,[Neg,NegAbd]),
	pr2mgtp_out_k_literal(Neg),
	pr2mgtp_out_connect_or(Neg,[NegAbd]),
	pr2mgtp_out_abducible(NegAbd),
	pr2mgtp_out_mgtp_consequent(AL,Suc,R).

%
% pr2mgtp_out_consequent_disjunction(Abd,B1,B2,B3,B4)
%   Abd : ����ν���
%   B1,B2,B3,B4 : ���Υǡ����ꥹ��
% print conjuction of consequent
pr2mgtp_out_consequent_disjunction(_,[],_,_,_).
pr2mgtp_out_consequent_disjunction(AL,[Suc|Rem],Abd,Neg,NegAbd) :-
	pr2mgtp_out_objective_literal(AL,Suc),
	  pr2mgtp_out_connect_and(Suc,[Abd,Neg,NegAbd]),
	pr2mgtp_out_abducible_disjunction(Abd),
	  pr2mgtp_out_connect_and(Abd,[Neg,NegAbd]),
	pr2mgtp_out_not_k_literal_disjunction(Neg),
	  pr2mgtp_out_connect_and(Neg,[NegAbd]),
	pr2mgtp_out_not_abducible_disjunction(NegAbd),
	  pr2mgtp_out_connect_or([Rem,Abd,Neg,NegAbd]),
	pr2mgtp_out_consequent_disjunction(AL,Rem,Abd,Neg,NegAbd).


% print K-Literal as Classical Negation at disjunction
pr2mgtp_out_not_k_literal_disjunction([]).
pr2mgtp_out_not_k_literal_disjunction([X]) :-
	printf(['-k(',X,')']).
pr2mgtp_out_not_k_literal_disjunction([X|L]) :-
	printf(['-k(',X,'), ']),
	pr2mgtp_out_not_k_literal_disjunction(L).


% print Abducible Literal at disjunction
pr2mgtp_out_abducible_disjunction([]).
pr2mgtp_out_abducible_disjunction([X]) :-
	printf(['h(',X,')']).
pr2mgtp_out_abducible_disjunction([X|L]) :-
	printf(['h(',X,'), ']),
	pr2mgtp_out_abducible_disjunction(L).


% print Abducible Literal as Classical Negation at disjunction
pr2mgtp_out_not_abducible_disjunction([]).
pr2mgtp_out_not_abducible_disjunction([X]) :-
	printf(['-h(',X,')']).
pr2mgtp_out_not_abducible_disjunction([X|L]) :-
	printf(['-h(',X,'), ']),
	pr2mgtp_out_not_abducible_disjunction(L).


% print Objective Literal
pr2mgtp_out_objective_literal(_,[]).
pr2mgtp_out_objective_literal(AL,[X]) :-
	copy_term(AL,AL1),
	(member(X,AL1) -> printf(['h(',X,')']);
	    printf(X)).
pr2mgtp_out_objective_literal(AL,[X|L]) :-
	copy_term(AL,AL1),
	(member(X,AL1) -> printf(['h(',X,'), ']);
	    printf([X,', '])),
	pr2mgtp_out_objective_literal(AL,L).


% print K-Literal
pr2mgtp_out_k_literal([]).
pr2mgtp_out_k_literal([X]) :-
	printf(['k(',X,')']).
pr2mgtp_out_k_literal([X|L]) :-
	printf(['k(',X,') ; ']),
	pr2mgtp_out_k_literal(L).


% print K-Literal as Classical Negation
pr2mgtp_out_not_k_literal([]).
pr2mgtp_out_not_k_literal([X]) :-
	printf(['-k(',X,')']).
pr2mgtp_out_not_k_literal([X|L]) :-
	printf(['-k(',X,') ; ']),
	pr2mgtp_out_not_k_literal(L).


% print Abducible Literal
pr2mgtp_out_abducible([]).
pr2mgtp_out_abducible([X]) :-
	printf(['h(',X,')']).
pr2mgtp_out_abducible([X|L]) :-
	printf(['h(',X,') ; ']),
	pr2mgtp_out_abducible(L).


% print Abducible Literal as Classical Negation
pr2mgtp_out_not_abducible([]).
pr2mgtp_out_not_abducible([X]) :-
	printf(['-h(',X,')']).
pr2mgtp_out_not_abducible([X|L]) :-
	printf(['-h(',X,') ; ']),
	pr2mgtp_out_not_abducible(L).


%
% pr2mgtp_out_negative(AL)
%   AL : ����ν���
% Negative clause without containing Negation As Failure
%
pr2mgtp_out_negative(AL) :-
	retract('Negative'([[Obj,_]])),
	numbervars(Obj,0,_),
	pr2mgtp_out_negative_clause_objective(AL,Obj),
	printf(' --> false'),
	printf(['.',{nl}]),
	pr2mgtp_out_negative(AL).
pr2mgtp_out_negative(_).

% print Objective Literal of Negative clause
pr2mgtp_out_negative_clause_objective(_,[]).
pr2mgtp_out_negative_clause_objective(_,[{X}]) :- printf(['{',X,'}']).
pr2mgtp_out_negative_clause_objective(AL,[X]) :-
	copy_term(AL,AL1),
	(member(X,AL1) -> printf(['h(',X,')']);
	    printf(X)).
pr2mgtp_out_negative_clause_objective(AL,[X|L]) :-
	copy_term(AL,AL1),
	(member(X,AL1) -> printf(['h(',X,'), ']);
	    printf([X,', '])),
	pr2mgtp_out_negative_clause_objective(AL,L).
pr2mgtp_out_negative_clause_objective(AL,[{X}|L]) :-
	printf(['{',X,'}, ']),
	pr2mgtp_out_negative_clause_objective(AL,L).

%
% pr2mgtp_out_each_nclause(S1,S2)
%   S1 : Negative clause1 list
%   S2 : Negative clause2 list
% print each Negative clause
%
pr2mgtp_out_each_nclause(S1,S2) :-
	pr2mgtp_out_nclause1(S1),
	pr2mgtp_out_nclause2(S2),
	pr2mgtp_out_schema.

% print Negative clause1
pr2mgtp_out_nclause1([]).
pr2mgtp_out_nclause1([S|L]) :-
	pr2mgtp_out_take_head(1,S,S1), 
        numbervars(S,0,N),

        (\+(N = 0) -> pr2mgtp_out_check_subsume(S1,S2),
                      (S2 == [] -> pr2mgtp_out_condition(S,_,0) ; true)
                      ; true),
        
        pr2mgtp_out_condition(S,S2,N), 
 	pr2mgtp_out_nclause1(L).

pr2mgtp_out_take_head(N,X,Y) :-
	'Clause'(N,Head,_),
	pr2mgtp_out_take_head1(Head,X,Y),
	N1 is N+1,
	pr2mgtp_out_take_head(N1,X,Y).
pr2mgtp_out_take_head(N,X,Y) :-
	'COUNT'(clause,Num),
	N < Num,
	N1 is N +1,
	pr2mgtp_out_take_head(N1,X,Y).
pr2mgtp_out_take_head(_,_,_).

pr2mgtp_out_take_head1([],_,_).
pr2mgtp_out_take_head1([[H|L]|L1],S,R) :-
	copy_term(S,S1),
	H = S1,
	pr2mgtp_out_head(S1,R),
	pr2mgtp_out_take_head1([L|L1],S,R).
pr2mgtp_out_take_head1([[_|L]|L1],S,R) :- !,
	pr2mgtp_out_take_head1([L|L1],S,R).
pr2mgtp_out_take_head1([[]|L],S,R) :- !,
	pr2mgtp_out_take_head1(L,S,R).

pr2mgtp_out_head(S1,[X|Y]) :-
	(var(X) -> X = S1;
	    (subsume(S1,X) -> true;pr2mgtp_out_head(S1,Y))).

% subsume check of list
pr2mgtp_out_check_subsume([],[]).
pr2mgtp_out_check_subsume([X|L],[X|L1]) :-
	pr2mgtp_out_check_subsume1(X,L),
	pr2mgtp_out_check_subsume(L,L1).
pr2mgtp_out_check_subsume([_|L],L1) :-
	pr2mgtp_out_check_subsume(L,L1).

pr2mgtp_out_check_subsume1(_,[]).
pr2mgtp_out_check_subsume1(X,[Y|L]) :- !,
	\+subsume(X,Y),
	pr2mgtp_out_check_subsume1(X,L).

% atom condition
pr2mgtp_out_condition(S,_,0) :- 
	printf(['k(',S,')']),
        printf([' --> false.',{nl}]). 
pr2mgtp_out_condition(_,[],_).
% head-match variable condition
pr2mgtp_out_condition(S,[_|L],N) :-

        functor(S,Sname,_),
        copy_term(S,C),
        functor(C,Fun,_),
                
        (Sname == '-' -> S =.. [_|[Y]],
                         functor(Y,Sname1,_),
                         Name = '-'Sname1 
                       ; copy_term(Fun,Name)
        ),
        
%%        nl(user),
%%        print(user,'Name = '),
%%        print(user,Name),
%%        nl(user),

        ('History'([_,Name|_]) -> printf(['k(',S,')']) 
                                     ; sub_condition_retract(S,Name),
                                       fail
        ),
         
        ('History'([_,Name|_]) -> sub_condition_print(S,Name) 
                                     ; fail
        ),
 

        printf([' --> false.',{nl}]),
        pr2mgtp_out_condition(S,L,N).

	
pr2mgtp_out_condition(S,[_|L],N) :-
	pr2mgtp_out_condition(S,L,N).


%
% sub condition check
%
sub_condition_print(S,Name) :-
        retract('History'([_,Name|His])),
        last_list(His,Con),
        printf([{nl},'   ,{\+(',S,' = ',Con,')}']),
%        printf([{nl},'   ,{',S,' \== ',Con,'}']),
        fail.
sub_condition_print(_,_).

sub_condition_retract(_,Name):-
        retract('History'([_,Name|_])),
        fail.
sub_condition_retract(_,_).

% print Negative clause2
pr2mgtp_out_nclause2([]).
pr2mgtp_out_nclause2([[X,Y]|L]) :-
	copy_term([X,Y],[A,B]),
	numbervars([A,B],0,_),
	printf(['k(',A,'), k(',B,')']),
	pr2mgtp_out_print_nclause2([X,Y]),
	numbervars(A,0,Nx),
	pr2mgtp_out_check_condition(X,Nx),
	numbervars(B,0,Ny),
	pr2mgtp_out_check_condition(X,Ny),
	printf([' --> false.',{nl}]),
	pr2mgtp_out_nclause2(L).

pr2mgtp_out_print_nclause2([X,Y]) :-
	X =.. [X1|P1],
	Y =.. [Y1|P2],
	X1 == Y1,
	length(P1,N),length(P2,N),
	((in_var_hold(X);in_var_hold(Y)) ->
            printf([', {',X,' \== ',Y,'}']);true).
pr2mgtp_out_print_nclause2([_,_]).

pr2mgtp_out_check_condition(_,0).
pr2mgtp_out_check_condition(X,_) :-
	copy_term(X,Y),
	pr2mgtp_out_take_head(1,X,X1),
	numbervars(X,0,Nx),
	(\+(Nx = 0) ->
	 pr2mgtp_out_check_subsume(X1,X2),
	 pr2mgtp_out_condition(Y,X2,Nx);
	    true).

% print scheme
%pr2mgtp_out_schema :-
%	printf(['-(A), (A) --> false.',{nl}]),
%	printf(['-k(A), (A) --> false.',{nl}]),
%	printf(['-h(A), (A) --> false.',{nl(2)}]).

pr2mgtp_out_schema :-
	printf(['-(A), (A) --> false.',{nl}]),
	printf(['-k(A), (A) --> false.',{nl}]),
        printf(['k(-(A)), (A) --> false.',{nl}]),
        printf(['k(A), -(A) --> false.',{nl}]),
	printf(['k(A), k(-(A)) --> false.',{nl(2)}]),
        (p(abductive)->
             printf(['-h(A), (A) --> false.',{nl}]),
             printf(['-h(A), h(A) --> false.',{nl}]),
	     printf(['h(A), -(A) --> false.',{nl}]),
	     printf(['h(A), h(-(A)) --> false.',{nl(2)}])
	     ;nl),
	retractall(p(_)).

% print Observation
pr2mgtp_out_observation :-
	(retract('Observation'([Observation])) ->
	 numbervars(Observation,0,_),
	 printf(['true --> k(',Observation,').',{nl}]),
	 pr2mgtp_out_observation;
	    true).

% print Prolog predicate	
pr2mgtp_out_predicate :-
	retract('Predicate'(Predicate)),!,
	printf({nl}),
	pr2mgtp_out_predicate_loop(Predicate).
pr2mgtp_out_predicate :- !.

pr2mgtp_out_predicate_loop([]) :- !.
pr2mgtp_out_predicate_loop([One|Rem]) :-
	pr2mgtp_out_predicate_one(One),!,
	pr2mgtp_out_predicate_loop(Rem).

pr2mgtp_out_predicate_one((Head :- Body)) :- !,
	printf([{quote(Head)},' :- ']),
	pr2mgtp_out_predicate_body(Body,''),
	printf(['.',{nl}]).
pr2mgtp_out_predicate_one(Head) :-
	printf([{quote(Head)},'.',{nl}]).

pr2mgtp_out_predicate_body('!',C) :- !,
	printf([C,'!']).
pr2mgtp_out_predicate_body((One,Rem),C) :- !,
	pr2mgtp_out_predicate_body(One,C),
	pr2mgtp_out_predicate_body(Rem,',').
pr2mgtp_out_predicate_body((O1;O2),C) :- !,
	printf([C,{nl},{tab},'(',{quote(O1)},';',{quote(O2)},')']).
pr2mgtp_out_predicate_body(One,C) :- !,
	printf([C,{nl},{tab},{quote(One)}]).

% <<<< connect symbol or ,and >>>>
pr2mgtp_out_connect_and([],_).
pr2mgtp_out_connect_and(_,[]).
pr2mgtp_out_connect_and(X,[L|R]) :-
	L = [_|_] -> printf(', ');pr2mgtp_out_connect_and(X,R).

pr2mgtp_out_connect_or([]).
pr2mgtp_out_connect_or([X|L]) :-
	X = [_|_] -> printf(' ; ');pr2mgtp_out_connect_or(L).

pr2mgtp_out_connect_or([],_).
pr2mgtp_out_connect_or(_,[]).
pr2mgtp_out_connect_or(X,[L|R]) :-
	L = [_|_] -> printf(' ; ');pr2mgtp_out_connect_or(X,R).










