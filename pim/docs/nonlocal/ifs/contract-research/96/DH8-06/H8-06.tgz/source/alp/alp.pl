% Copyright (C) 1997  Katsumi Inoue 
%
%%% alp.pl %%%
%
%
% reads programs from file-Mname.pr,
%       translates them into MGTP code in the file-Mname.pl
%                                       (the file-Pname.pl)
%
alptrans(Mname) :-
	pr2mgtp(Mname),
	mgtp2pl(Mname).

alptrans(Mname,Pname) :-
	pr2mgtp(Mname),
	mgtp2pl(Mname,Pname).


%
% reads programs from file-Mname.pr,
%       translates them into MGTP code in the file-Mname.pl(Pname.pl)
%       and then compiles this file
%
alpcompile(Mname) :-
	abolish(program,1),
	pr2mgtp(Mname),
	mgtp2pl(Mname,Pname),
	compile(Pname).


alpcompile(Mname,Pname) :-
	abolish(program,1),
	pr2mgtp(Mname),
	mgtp2pl(Mname,Pname),
	compile(Pname).
