% Copyright (C) 1997  Katsumi Inoue 
%
%%% actmgtp.pl %%%
%
/**************************************************************/
/**                                                          **/
/** $@NN0h5-=R%U%!%$%k$+$i!"<ALd1~Ez2DG=$J>uBV$^$G$N%3%s%Q%$%k(J **/
/**                                                          **/ 
/**************************************************************/
/* $@>u67L>@8@.5,B'(J
	situation([A2,A1])<- action(A1),action(A2).
        situation(S) <- situation([A|S]).
 $@$N>l9g(J */

actionmgtp(File) :- 
	clear,
	actcompile(File),
	alpcompile(File).

/* $@>u67L>@8@.5,B'(J
	situation([An,...,A1])<- action(A1),...,action(An).
        situation(S) <- situation([A|S]).
 $@$N>l9g(J */

actionmgtp1(File,N) :-
	clear,
	actcompile1(File,N),
	alpcompile(File).

/* $@>u67L>@8@.5,B'(J
	situation([String]).
        situation(S) <- situation([A|S]).
 $@$N>l9g(J */

actionmgtp2(File,String) :-
	clear,
	actcompile2(File,String),
	alpcompile(File).

/**************************************/
/**                                  **/
/** $@$9$Y$F$N%"%5!<%HFbMF$N%j%H%i%/%H(J **/
/**                                  **/
/**************************************/
clear :- 
	assert(filename(*)),retractall(filename(_)),
	assert(sit(*)),retractall(sit(_)),
	assert(string(*)),retractall(string(_)),
	assert(f(*)),retractall(f(_)),
	assert(a(*)),retractall(a(_)),
	assert(reachable(*)),retractall(reachable(_)),
	assert(var_list(*,*)),retractall(var_list(_,_)),

	assert(fluent(*)),retractall(fluent(_)),
	assert(situation(*)),retractall(situation(_)),
	assert(action(*)),retractall(action(_)).
