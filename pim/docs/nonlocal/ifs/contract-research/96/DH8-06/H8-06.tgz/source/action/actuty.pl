% Copyright (C) 1997  Katsumi Inoue 
%
%%% actuty.pl %%%
%
/*-----  $@0lHLE*$J%f!<%F%#%j%F%#!<(J  -----*/

/* $@%j%9%H$rH?E>$5$;$k4X?t(J */
reverse(A,B):- reverse(A,B,[]).
reverse([],C,C).
reverse([Ax|Ay],B,C):- reverse(Ay,B,[Ax|C]).

/* $@%j%9%H$+$iMWAG$r:o=|$9$k4X?t(J */
delete(_,[],[]).
delete(X,[X|L],M) :- delete(X,L,M).
delete(X,[Y|L1],[Y|L2]):- delete(X,L1,L2).

/* $@%j%9%H$H%j%9%H$r9g@.$9$k4X?t(J */
append([],A,A).
append([Ax|Ay],B,[Ax|Cy]):- append(Ay,B,Cy).

/* $@%j%9%H$N%a%s%P!<$+$I$&$+D4$Y$k(J */
member1(X,[X|_]).
member1(X,[_|Tail]):- member1(X,Tail).
member(X,[X|_]):- !.
member(X,[_|Tail]):- member(X,Tail).

/* $@%j%9%H$NO"7k(J */
conc([],L,L).
conc([X|L1],L2,[X|L3]):- conc(L1,L2,L3).

/* $@%5%V%j%9%H(J */
sublist([X|L],[X|M]) :- prefix(L,M),!.
sublist(L,[_|M]) :- sublist(L,M).
prefix([],_).
prefix([X|L],[X|M]) :- prefix(L,M).

/* $@%j%9%H$N:G8e$NMWAG$r<h$j=P$9(J */
last(X,[X]).
last(X,[_|Y]):- last(X,Y).

/* $@%j%9%H$N$"$kMWAG$r:o=|(J */
delete(_,[],[]).
delete(X,[X|L],M) :- delete(X,L,M).
delete(X,[Y|L1],[Y|L2]):- delete(X,L1,L2).

/* $@%j%9%H$NCf$N$"$kMWAG$N?t$r%+%&%s%H(J */
count(_,[],0).
count(Term,[Head|L],N):-
	copy_term(Term,Term1),
        Term1 = Head,!,
	count(Term,L,N1),
	N is N1 + 1;
	count(Term,L,N).


/*  Runtime function */
time(T) :-
        statistics(runtime,[_,T]),!.
/* print Run time */
print_time(T) :-
	write('* Time: '),
	T1 is T /1000,
	write(T1),
	write(' sec. *'),nl,!.




