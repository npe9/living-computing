/* -*-  PARCAR/KP Parallel Abductive Reasoning System on KILC+PVM -*- */
/* -*-  Copyright (C) 1997    Shohey Kato                         -*- */

#define BUFFSIZE 128000
#define TERMSIZE 4096


typedef struct term_list
{
    char car[TERMSIZE];
    struct term_list *cdr;
}LIST;

LIST *current,*root;
