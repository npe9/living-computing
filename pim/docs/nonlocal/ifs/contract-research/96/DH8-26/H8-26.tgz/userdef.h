/* PARCAR/KP Parallel Abductive Reasoning System on KILC+PVM */
/* Copyright (C) 1997   Shohey Kato
                        Dept. of AI and Comp. Sci., Nagoya Inst. of Tech  */

/* Default Slave Program */
#define DEFAULT_SLAVE   "/slave"

/* Default Setting File for PVM */
#define HOSTSDATAFILE "/parcarhosts"

/* Interval of Communication */
#define INTERVAL_TIME   2.0

/* Path for UNIX system call <uptime> utilized for estimating load-average on each processor */
#define UPTIME  "/usr/ucb/uptime"
