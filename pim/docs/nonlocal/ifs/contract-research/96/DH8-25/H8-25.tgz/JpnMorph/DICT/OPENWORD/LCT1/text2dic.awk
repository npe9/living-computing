#
# $B%l%3!<%I7?%F%-%9%H7A<0$N<-=q%G!<%?$r(BJUMAN$B7A<0$KJQ49$9$k%W%m%0%i%`(B
BEGIN { now=0; outof=0; }
/^#/ { next; }
/^\;/ { print $0; next; }
NF==4 {
  printf("(%s\n",$4);
  printf("  (($B8+=P$78l(B %s)\n",$2);
  printf("   ($BFI$_(B     %s))\n",$3);
  print ")";
  ++now;
  next;
}
NF==5 && $5~/\*/ {
  printf("(%s\n",$4);
  printf("  (($B8+=P$78l(B %s)\n",$2);
  printf("   ($BFI$_(B     %s))\n",$3);
  print ")";
  ++now;
  next;
}
NF==5 && $5!~/\*/ {
  printf("(%s\n",$4);
  printf(" (%s\n",$5);
  printf("  (($B8+=P$78l(B %s)\n",$2);
  printf("   ($BFI$_(B     %s))\n",$3);
  print "))";
  ++now;
  next;
}
NF==6 && $5~/\*/ && $6~/kana/ {
  printf("(%s\n",$4);
  printf("  (($B8+=P$78l(B (%s) (%s))\n",$2,$3);
  printf("   ($BFI$_(B     %s))\n",$3);
  print ")";
  ++now;
  next;
}
NF==6 && $5!~/\*/ && $6~/kana/ {
  printf("(%s\n",$4);
  printf(" (%s\n",$5);
  printf("  (($B8+=P$78l(B (%s) (%s))\n",$2,$3);
  printf("   ($BFI$_(B     %s))\n",$3);
  print "))";
  ++now;
  next;
}
{ ++outof; print "; "$0 }
END { printf( "; %d word(s) (%d)\n",now,outof) }
#
