#! /bin/csh
#
# ��뤵��Ƥ���ƥ����Ȥ���ष�Ʋ��Ϥ��륷����
#
set dir=/a/logos/usr1/textbase/Srcfiles/Editorial/FolderAsahi
#
zcat $dir/asahi0041.src.Z | $MORPHPATH/COMMAND/kaiseki1 >! $HOME/tmp/edt3
zcat $dir/asahi0042.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt3
zcat $dir/asahi0043.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt3
zcat $dir/asahi0044.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt3
zcat $dir/asahi0045.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt3
zcat $dir/asahi0046.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt3
zcat $dir/asahi0047.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt3
zcat $dir/asahi0048.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt3
zcat $dir/asahi0049.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt3
zcat $dir/asahi0050.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt3
zcat $dir/asahi0051.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt3
zcat $dir/asahi0052.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt3
zcat $dir/asahi0053.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt3
zcat $dir/asahi0054.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt3
zcat $dir/asahi0055.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt3
zcat $dir/asahi0056.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt3
zcat $dir/asahi0057.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt3
zcat $dir/asahi0058.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt3
zcat $dir/asahi0059.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt3
zcat $dir/asahi0060.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt3
#
# End of File
