#!/bin/csh
#
# ��뤵��Ƥ���ƥ����Ȥ���ष�Ʋ��Ϥ��륷����
#
set dir=/a/logos/usr1/textbase/Srcfiles/Editorial/FolderAsahi
#
zcat $dir/asahi0021.src.Z | $MORPHPATH/COMMAND/kaiseki1 >! $HOME/tmp/edt2
zcat $dir/asahi0022.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt2
zcat $dir/asahi0023.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt2
zcat $dir/asahi0024.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt2
zcat $dir/asahi0025.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt2
zcat $dir/asahi0026.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt2
zcat $dir/asahi0027.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt2
zcat $dir/asahi0028.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt2
zcat $dir/asahi0029.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt2
zcat $dir/asahi0030.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt2
zcat $dir/asahi0031.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt2
zcat $dir/asahi0032.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt2
zcat $dir/asahi0033.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt2
zcat $dir/asahi0034.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt2
zcat $dir/asahi0035.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt2
zcat $dir/asahi0036.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt2
zcat $dir/asahi0037.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt2
zcat $dir/asahi0038.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt2
zcat $dir/asahi0039.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt2
zcat $dir/asahi0040.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt2
#
# End of File
