#! /bin/csh
#
# ��뤵��Ƥ���ƥ����Ȥ���ष�Ʋ��Ϥ��륷����
#
set dir=/a/logos/usr1/textbase/Srcfiles/Editorial/FolderAsahi
#
zcat $dir/asahi0061.src.Z | $MORPHPATH/COMMAND/kaiseki1 >! $HOME/tmp/edt4
zcat $dir/asahi0062.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt4
zcat $dir/asahi0063.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt4
zcat $dir/asahi0064.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt4
zcat $dir/asahi0065.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt4
zcat $dir/asahi0066.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt4
zcat $dir/asahi0067.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt4
zcat $dir/asahi0068.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt4
zcat $dir/asahi0069.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt4
zcat $dir/asahi0070.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt4
zcat $dir/asahi0071.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt4
zcat $dir/asahi0072.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt4
zcat $dir/asahi0073.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt4
zcat $dir/asahi0074.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt4
zcat $dir/asahi0075.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt4
zcat $dir/asahi0076.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt4
zcat $dir/asahi0077.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt4
zcat $dir/asahi0078.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt4
zcat $dir/asahi0079.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt4
zcat $dir/asahi0080.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt4
#
# End of File
