#
BEGIN { fukusi=""; prev=""; sentence=""; flag=0; }
#
/EOS/ { if(flag==1) { printf("\nsentence\n%s\n",sentence); flag=0; }
	sentence=""; next;
      }
/���Ѹ�\(Ϣ��/ { fukusi=$0; sentence=sentence $1; next; }
{
  if(fukusi!="" && ($1 ~ /��/ || $1 ~ /��/ || $1 ~ /��/ || $1 ~ /��/ || $1 ~ /��/)) {
    print ">>"; print prev; print fukusi; print $0; fukusi=""; flag=1;
  }
  if(fukusi!="") { fukusi=""; }
  prev=$0;
  sentence=sentence $1;
}
#
