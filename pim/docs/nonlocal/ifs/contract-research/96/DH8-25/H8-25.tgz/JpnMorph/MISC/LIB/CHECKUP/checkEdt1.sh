#! /bin/csh
#
# ��뤵��Ƥ���ƥ����Ȥ���ष�Ʋ��Ϥ��륷����
#
set dir=/a/logos/usr1/textbase/Srcfiles/Editorial/FolderAsahi
#
zcat $dir/asahi0001.src.Z | $MORPHPATH/COMMAND/kaiseki1 >! $HOME/tmp/edt1
zcat $dir/asahi0002.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt1
zcat $dir/asahi0003.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt1
zcat $dir/asahi0004.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt1
zcat $dir/asahi0005.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt1
zcat $dir/asahi0006.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt1
zcat $dir/asahi0007.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt1
zcat $dir/asahi0008.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt1
zcat $dir/asahi0009.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt1
zcat $dir/asahi0010.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt1
zcat $dir/asahi0011.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt1
zcat $dir/asahi0012.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt1
zcat $dir/asahi0013.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt1
zcat $dir/asahi0014.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt1
zcat $dir/asahi0015.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt1
zcat $dir/asahi0016.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt1
zcat $dir/asahi0017.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt1
zcat $dir/asahi0018.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt1
zcat $dir/asahi0019.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/edt1
zcat $dir/asahi0020.src.Z | $MORPHPATH/COMMAND/kaiseki1  >> $HOME/tmp/edt1
#
# End of File
