#!/bin/csh
#
# ��뤵��Ƥ���ƥ����Ȥ���ष�Ʋ��Ϥ��륷����
#
#set dir=/a/logos/usr1/textbase/Srcfiles/Column/FolderTenjin
set dir=/home/sano/NFSE/Morph/CORPUS/TNJI
#
zcat  $dir/tenjin1.src.Z | $MORPHPATH/COMMAND/kaiseki1 >! $HOME/tmp/tnj1
zcat  $dir/tenjin2.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/tnj1
zcat  $dir/tenjin3.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/tnj1
zcat  $dir/tenjin4.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/tnj1
zcat  $dir/tenjin5.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/tnj1
zcat  $dir/tenjin6.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/tnj1
zcat  $dir/tenjin7.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/tnj1
zcat  $dir/tenjin8.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/tnj1
zcat  $dir/tenjin9.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/tnj1
zcat $dir/tenjin10.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/tnj1
zcat $dir/tenjin11.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/tnj1
zcat $dir/tenjin12.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/tnj1
zcat $dir/tenjin13.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/tnj1
zcat $dir/tenjin14.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/tnj1
zcat $dir/tenjin15.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/tnj1
zcat $dir/tenjin16.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/tnj1
zcat $dir/tenjin17.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/tnj1
zcat $dir/tenjin18.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/tnj1
zcat $dir/tenjin19.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/tnj1
zcat $dir/tenjin20.src.Z | $MORPHPATH/COMMAND/kaiseki1 >> $HOME/tmp/tnj1
#
# End of File
