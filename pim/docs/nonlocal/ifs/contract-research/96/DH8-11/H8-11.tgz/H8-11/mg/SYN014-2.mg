true -->
equalish(X,X)
.

equalish(X,Y)
-->
equalish(Y,X)
.

equalish(X,Y), equalish(Y,Z)
-->
equalish(X,Z)
.

equalish(A,B), element(C,A)
-->
element(C,B)
.

element(A,B), equalish(A,C)
-->
element(C,B)
.

element(A,a)
-->
equalish(A,k); equalish(A,a)
.

equalish(A,k)
-->
element(A,a); equalish(A,a)
.

equalish(f(A),m), element(A,m)
-->
equalish(A,m)
.

equalish(f(A),A), element(A,m)
-->
equalish(A,m)
.

element(A,m)
-->
element(A,f(A)); equalish(A,m)
.

element(A,m)
-->
element(f(A),A); equalish(A,m)
.

element(A,B), element(B,A)
-->
equalish(A,B); equalish(A,m); element(B,m); equalish(B,m)
.

equalish(g(A),n)
-->
element(A,n); equalish(A,n)
.

equalish(g(A),A)
-->
element(A,n); equalish(A,n)
.

true -->
element(A,g(A)); element(A,n); equalish(A,n)
.

true -->
element(g(A),A); element(A,n); equalish(A,n)
.

element(A,B), element(B,A), element(B,n)
-->
equalish(A,B); equalish(A,n); equalish(B,n)
.

equalish(A,m)
-->
element(A,k); equalish(A,k)
.

equalish(A,n)
-->
element(A,k); equalish(A,k)
.

element(A,k)
-->
equalish(A,n); equalish(A,m); equalish(A,k)
.

equalish(n,a)
--> false.

equalish(m,n)
--> false.

true -->
equalish(n,k)
.

equalish(m,a)
--> false.

equalish(k,a)
--> false.

true -->
equalish(m,k)
.

