true -->
equal(X,X)
.

equal(X,Y)
-->
equal(Y,X)
.

equal(X,Y), equal(Y,Z)
-->
equal(X,Z)
.

equal(A,B)
-->
equal(f(A,C),f(B,C))
.

equal(D,E)
-->
equal(f(F,D),f(F,E))
.

true -->
equal(f(X,f(Y,Z)),f(f(X,Y),Z))
.

equal(f(a,f(b,f(c,d))),f(f(f(a,b),c),d))
--> false.

