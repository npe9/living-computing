p_1(X1,X2), p_2(X2,X3), p_3(X3,X4), p_4(X4,X5), p_5(X5,X6), p_6(X6,X7), p_7(X7,X8), p_8(X8,X9), p_9(X9,X10), p_10(X10,X1)
--> false.

true -->
p_1(a,a)
.

true -->
p_2(a,a)
.

true -->
p_3(a,a)
.

true -->
p_4(a,a)
.

true -->
p_5(a,a)
.

true -->
p_6(a,a)
.

true -->
p_7(a,a)
.

true -->
p_8(a,a)
.

true -->
p_9(a,a)
.

true -->
p_10(a,a)
.

