%--------------------------------------------------------------------------
% File     : SYN009=Relev2-1 : TPTP v1.2.1. Released v1.0.0.
% Domain   : Syntactic
% Problem  : A problem to demonstrate the usefulness of relevancy testing
% Version  : 
% English  : 

% Refs     : Wilson D.S., Loveland D.W. (1989), Incorporating Relevancy 
%            Testing in SATCHMO, CS-1989-24, Department of Computer 
%            Science, Duke University.
% Source   : [Wilson & Loveland, 1989]
% Names    : Figure 8 [Wilson & Loveland, 1989]

% Status   : unsatisfiable
% Syntax   : Number of clauses    :    7 (   1 non-Horn;   6 unit;   7 RR)
%            Number of literals   :   12 (   0 equality)
%            Maximal clause size  :    6
%            Number of predicates :    4 (   0 propositional; 1-3 arity)
%            Number of functors   :    3 (   3 constant; 0-0 arity)
%            Number of variables  :    9 (   6 singleton)
%            Maximal term depth   :    1

% Comments : 
%--------------------------------------------------------------------------
input_clause(clause_1,conjecture,
    [--p(c,X,Y)]).

input_clause(clause_2,conjecture,
    [--q(X,c,Y)]).

input_clause(clause_3,conjecture,
    [--r(X,Y,c)]).

input_clause(clause_4,conjecture,
    [++s(a)]).

input_clause(clause_5,conjecture,
    [++s(b)]).

input_clause(clause_6,conjecture,
    [++s(c)]).

input_clause(clause_7,conjecture,
    [--s(X),
     --s(Y),
     --s(Z),
     ++p(X,Y,Z),
     ++q(X,Y,Z),
     ++r(X,Y,Z)]).
%--------------------------------------------------------------------------
