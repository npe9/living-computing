true --> dom(1),dom(2),dom(3),dom(4),dom(5).
%true --> p(1,1,1),p(2,2,2),p(3,3,3),p(4,4,4),p(5,5,5).
dom(M) --> p(M,M,M).
%
dom(M),dom(N),{M =\= N} --> p(M,N,1);p(M,N,2);p(M,N,3);p(M,N,4);p(M,N,5).
%dom(M),dom(N) --> p(M,N,1);p(M,N,2);p(M,N,3);p(M,N,4);p(M,N,5).
%

p(Y,X,V1),p(V1,Y,V2),p(V2,Y,V), {V =\= X} --> false.
%p(X,X,V), {V =\= X} --> false.
p(X,Y1,V), p(X,Y2,V), {Y1 =\= Y2} --> false.
p(X1,Y,V), p(X2,Y,V), {X1 =\= X2} --> false.

