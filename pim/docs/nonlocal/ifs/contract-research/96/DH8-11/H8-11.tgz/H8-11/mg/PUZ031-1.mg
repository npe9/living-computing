wolf(X)
-->
animal(X)
.

fox(X)
-->
animal(X)
.

bird(X)
-->
animal(X)
.

caterpillar(X)
-->
animal(X)
.

snail(X)
-->
animal(X)
.

true -->
wolf(a_wolf)
.

true -->
fox(a_fox)
.

true -->
bird(a_bird)
.

true -->
caterpillar(a_caterpillar)
.

true -->
snail(a_snail)
.

true -->
grain(a_grain)
.

grain(X)
-->
plant(X)
.

animal(Animal), plant(Plant), animal(Small_animal), plant(Other_plant), much_smaller(Small_animal,Animal), eats(Small_animal,Other_plant)
-->
eats(Animal,Plant); eats(Animal,Small_animal)
.

caterpillar(Catapillar), bird(Bird)
-->
much_smaller(Catapillar,Bird)
.

snail(Snail), bird(Bird)
-->
much_smaller(Snail,Bird)
.

bird(Bird), fox(Fox)
-->
much_smaller(Bird,Fox)
.

fox(Fox), wolf(Wolf)
-->
much_smaller(Fox,Wolf)
.

wolf(Wolf), fox(Fox), eats(Wolf,Fox)
--> false.

wolf(Wolf), grain(Grain), eats(Wolf,Grain)
--> false.

bird(Bird), caterpillar(Catapillar)
-->
eats(Bird,Catapillar)
.

bird(Bird), snail(Snail), eats(Bird,Snail)
--> false.

caterpillar(Catapillar)
-->
plant(caterpillar_food_of(Catapillar))
.

caterpillar(Catapillar)
-->
eats(Catapillar,caterpillar_food_of(Catapillar))
.

snail(Snail)
-->
plant(snail_food_of(Snail))
.

snail(Snail)
-->
eats(Snail,snail_food_of(Snail))
.

animal(Animal), animal(Grain_eater), grain(Grain), eats(Animal,Grain_eater), eats(Grain_eater,Grain)
--> false.

