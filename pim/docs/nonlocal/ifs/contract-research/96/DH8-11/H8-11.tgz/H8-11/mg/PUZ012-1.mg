true -->
equal_fruits(X,X)
.

true -->
equal_boxes(X,X)
.

label(X,Y), contains(X,Y)
--> false.

true -->
contains(boxa,X); contains(boxb,X); contains(boxc,X)
.

true -->
contains(X,apples); contains(X,bananas); contains(X,oranges)
.

contains(X,Y), contains(X,Z)
-->
equal_fruits(Y,Z)
.

contains(X,Y), contains(Z,Y)
-->
equal_boxes(X,Z)
.

equal_boxes(boxa,boxb)
--> false.

equal_boxes(boxb,boxc)
--> false.

equal_boxes(boxa,boxc)
--> false.

equal_fruits(apples,bananas)
--> false.

equal_fruits(bananas,oranges)
--> false.

equal_fruits(apples,oranges)
--> false.

true -->
label(boxa,apples)
.

true -->
label(boxb,oranges)
.

true -->
label(boxc,bananas)
.

true -->
contains(boxb,apples)
.

contains(boxa,bananas), contains(boxc,oranges)
--> false.

