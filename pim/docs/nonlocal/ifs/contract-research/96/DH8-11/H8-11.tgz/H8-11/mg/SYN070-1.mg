big_f(X)
-->
big_f(f(X)); big_g(X)
.

big_f(X)
-->
big_h(f(X),X); big_g(X)
.

big_f(X), big_g(f(X))
-->
big_g(X)
.

big_f(X)
-->
big_g(X); big_f(a)
.

big_f(X), big_g(a)
-->
big_g(X)
.

big_f(X), big_f(Y)
-->
big_g(X); big_g(Y); big_j(a,Y)
.

big_f(X), big_f(Y), big_h(X,Y), big_j(Y,X)
--> false.

true -->
big_f(b)
.

big_g(b)
--> false.

