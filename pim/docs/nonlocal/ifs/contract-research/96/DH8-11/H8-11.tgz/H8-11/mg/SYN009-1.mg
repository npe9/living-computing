p(c,X,Y)
--> false.

q(X,c,Y)
--> false.

r(X,Y,c)
--> false.

true -->
s(a)
.

true -->
s(b)
.

true -->
s(c)
.

s(X), s(Y), s(Z)
-->
p(X,Y,Z); q(X,Y,Z); r(X,Y,Z)
.

