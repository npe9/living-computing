p
--> false.

q
--> false.

true -->
r
.

r
-->
a; b
.

r
-->
p; c; d
.

r
-->
p; q
.

