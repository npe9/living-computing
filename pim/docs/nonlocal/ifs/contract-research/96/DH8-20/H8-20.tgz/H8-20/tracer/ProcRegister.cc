// Copyright (C) 1996,1997 Buntarou Shizuki(shizuki@is.titech.ac.jp)

#include <stdio.h>
#include <string.h>
#include "ProcRegister.h"

static ProcRegister* R;

void
initProcRegister()
{
  R = new ProcRegister();
}

void
procRegister(Proc *p)
{
  R->Register(p);
}

void
dumpProcs()
{
  R->Dump();
}

Proc *
getProc(char *module, char *name, int arity)
{
  return R->GetProc(module, name, arity);
}

//
// member functions
//
Proc *
ProcRegister::GetProc(char *module, char *name, int arity)
{
  for (Pix i = ProcList.first(); i != 0; ProcList.next(i)) {
    if (ProcList(i)->Arity() == arity
	&& name == ProcList(i)->Name()
	&& module == ProcList(i)->Module()) {
      return ProcList(i);
    }
  }
  return NULL;
}

void
ProcRegister::Check()
{
  // main/0 have one rule

  // etc...
}

void
ProcRegister::Dump()
{
  for (Pix i = ProcList.first(); i != 0; ProcList.next(i)) {
    ProcList(i)->Dump();
  }
}

/* eof */
