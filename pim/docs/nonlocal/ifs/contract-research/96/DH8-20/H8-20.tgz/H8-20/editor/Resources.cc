// Copyright (C) 1997  Toyoda Masashi (toyoda@is.titech.ac.jp)

#include <amulet.h>
#include FORMULA_ADVANCED__H

#include "ToyWidgets.h"

// ------------------------------------------------------------
// Global Resources
// ------------------------------------------------------------

// Global Resources Object
Am_Object PovlResources = 0;

// Resource Slots
DEFINE_SLOT(ModuleFill);
DEFINE_SLOT(PortNewFill);
DEFINE_SLOT(PortOldFill);
DEFINE_SLOT(PortNewTextFill);
DEFINE_SLOT(PortOldTextFill);
DEFINE_SLOT(PortArrowFill);
DEFINE_SLOT(PortWidthMargin);
DEFINE_SLOT(PortHeightMargin);
DEFINE_SLOT(ProcessMargin);
DEFINE_SLOT(ProcessFill);
DEFINE_SLOT(TransitionRuleFill);
DEFINE_SLOT(AtomWidthMargin);
DEFINE_SLOT(AtomHeightMargin);
DEFINE_SLOT(StructWidthMargin);
DEFINE_SLOT(StructHeightMargin);
DEFINE_SLOT(GuardWidthMargin);
DEFINE_SLOT(GuardHeightMargin);
DEFINE_SLOT(BindMargin);

void InitializeResources(void)
{
  PovlResources = Am_Root_Object.Create()
    .Set(ModuleFill,		Am_Amulet_Purple)
    .Set(PortNewFill,		Am_Motif_Light_Gray)
    .Set(PortOldFill,		Am_Motif_Light_Orange)
    .Set(PortNewTextFill,	Am_Black)
    .Set(PortOldTextFill,	Am_White)
    .Set(PortArrowFill,		Am_Black)
    .Set(PortWidthMargin,	2)
    .Set(PortHeightMargin,	2)
    .Set(ProcessMargin,		4)
    .Set(ProcessFill,		Am_Motif_Light_Gray)
    .Set(TransitionRuleFill,	Am_Motif_Light_Orange)
    .Set(AtomWidthMargin,	8)
    .Set(AtomHeightMargin,	1)
    .Set(StructWidthMargin,	4)
    .Set(StructHeightMargin,	4)
    .Set(GuardWidthMargin,	4)
    .Set(GuardHeightMargin,	6)
    .Set(BindMargin,		2)
    ;

  Am_Screen.Add_Part(PovlResources);
}

