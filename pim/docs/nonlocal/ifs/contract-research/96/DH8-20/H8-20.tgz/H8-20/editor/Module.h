// Copyright (C) 1997  Toyoda Masashi (toyoda@is.titech.ac.jp)

// ------------------------------------------------------------
// Objects
// ------------------------------------------------------------

extern Am_Object ModuleModel;

extern Am_Object ModuleProto;
extern Am_Object TopModule;
extern Am_Object MainRuleProto;

// ------------------------------------------------------------
// Methods
// ------------------------------------------------------------

extern Am_Object_Method New_Module_Do;

// ------------------------------------------------------------
// Initialize
// ------------------------------------------------------------

void InitializeModule(void);
