// global variables for controlling debug messages
// Copyright (C) 1996,1997 Buntarou Shizuki(shizuki@is.titech.ac.jp)

#include "parse.h"

int debug_czoom_action = 0;
int debug_czoom_section = 0;
int debug_czoom_resection = 0;
int debug_gstore = 0;
int debug_link = 0;
int debug_port_coordinate = 0;
int debug_process_definition = 0;
int debug_process_main_draw = 0;
int debug_rule = 0;
int debug_stream_monitor = 0;
int debug_update_call = 0;
int debug_variable = 0;
int debug_trace = 0;
int debug_rproc = 0;

// eof
