// Copyright (C) 1997  Toyoda Masashi (toyoda@is.titech.ac.jp)

// ------------------------------------------------------------
// Utility Functions
// ------------------------------------------------------------

void Get_Correct_Modes(Am_Object src_port, Am_Object des_port, int& src_mode, int& des_mode);
Am_Object Binder_Which_Rule(Am_Object src_port, Am_Object des_port);
Am_Object Single_Binding_Line_Create(Am_Object src_port, Am_Object des_port);


// ------------------------------------------------------------
// Objects
// ------------------------------------------------------------

extern Am_Object BinderProto;

// ------------------------------------------------------------
// Initialize
// ------------------------------------------------------------

void InitializeBinder(void);



