// Copyright (C) 1997  Toyoda Masashi (toyoda@is.titech.ac.jp)

int save_module(Am_Object window, ofstream& ofile);
int load_module(Am_Object window, ifstream& ifile);

int Save_module(Am_Object module);
int Load_module(Am_Object module, ifstream& ifile);
