// Copyright (C) 1997  Toyoda Masashi (toyoda@is.titech.ac.jp)

#ifndef _INTERNAL_

// ------------------------------------------------------------
// Objects
// ------------------------------------------------------------

extern Am_Object ProcessModel;
extern Am_Object ProcessProto;
extern Am_Object HoleModel;
extern Am_Object HoleProto;
extern Am_Object ReplHolesProto;

// ------------------------------------------------------------
// Functions
// ------------------------------------------------------------

Am_Object Process_Goal_Create(Am_Object proc);
Am_Object Process_Inter_Module_Goal_Create(Am_Object proc);
Am_Object Process_Inter_Module_Goal_New(Am_String name, Am_String mname);
bool Single_Hole_Replace(Am_Object hole, Am_Object proc);

// ------------------------------------------------------------
// Initialize
// ------------------------------------------------------------

void InitializeProcess(void);
#endif

enum ProcessType { ProcessInterface = 0, ProcessGoal = 1, ProcessInterGoal = 2 };
