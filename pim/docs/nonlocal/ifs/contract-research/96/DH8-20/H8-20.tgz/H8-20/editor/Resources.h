// Copyright (C) 1997  Toyoda Masashi (toyoda@is.titech.ac.jp)

// ------------------------------------------------------------
// Objects
// ------------------------------------------------------------

extern Am_Object PovlResources;

// ------------------------------------------------------------
// Resource Slots
// ------------------------------------------------------------

EXPORT_SLOT(ModuleFill);
EXPORT_SLOT(PortNewFill);
EXPORT_SLOT(PortOldFill);
EXPORT_SLOT(PortNewTextFill);
EXPORT_SLOT(PortOldTextFill);
EXPORT_SLOT(PortArrowFill);
EXPORT_SLOT(PortWidthMargin);
EXPORT_SLOT(PortHeightMargin);
EXPORT_SLOT(ProcessMargin);
EXPORT_SLOT(ProcessFill);
EXPORT_SLOT(TransitionRuleFill);
EXPORT_SLOT(AtomWidthMargin);
EXPORT_SLOT(AtomHeightMargin);
EXPORT_SLOT(StructWidthMargin);
EXPORT_SLOT(StructHeightMargin);
EXPORT_SLOT(GuardWidthMargin);
EXPORT_SLOT(GuardHeightMargin);
EXPORT_SLOT(BindMargin);

// ------------------------------------------------------------
// Initialize
// ------------------------------------------------------------

void InitializeResources(void);
