// Copyright (C) 1997  Toyoda Masashi (toyoda@is.titech.ac.jp)

// ------------------------------------------------------------
// Objects
// ------------------------------------------------------------

extern Am_Object RuleProto;
extern Am_Object NetworkRuleProto;
extern Am_Object TransitionRuleProto;
extern Am_Object RuleGroupProto;

// ------------------------------------------------------------
// Operations
// ------------------------------------------------------------

Am_Object Rule_Create(Am_Object process, Am_Object rule_proto);

extern Am_Formula InnerPortListForm;


// ------------------------------------------------------------
// Initialize
// ------------------------------------------------------------

void InitializeRule(void);
