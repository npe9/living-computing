#ifndef YYSTYPE
#define YYSTYPE int
#endif
typedef
  union
    {
      struct {
	char	state;
      } rrtr_sub_state;

      struct {
	RSUBGTYPE	g;
      } rrtr_subgoal, rrtr_subgoals;

      struct {
	RSUBGTYPE	sg;
      } rrtr_subgoal_part;

      struct {
	RCONSTYPE	tt;
	RCONSTYPE	th;
      } rrtr_list_elements, rrtr_list_contents;

      struct {
	int	num;
	RTERMTYPE	ts;
      } rrtr_args, rrtr_arg, rrtr_argument;

      struct {
	int	arity;
	NAMETYPE	name;
	NAMETYPE	module;
	RTERMTYPE	t;
      } rrtr_head, rrtr_list, rrtr_functor, rrtr_term;

      struct {
	ActType	act;
      } rrtr_action;

      struct {
	SUBPROCTYPE	sps;
	PORTTYPE	ps;
	int	num;
      } rrt_merge, rrt_assign, rrt_unify, rrt_structure, rrt_vector_elements
      , rrt_vector_contents, rrt_vector, rrt_list_elements, rrt_list_contents, rrt_list
      , rrt_arg, rrt_term_info, rrt_term_body, rrt_term, rrt_args
      , rrt_argument, rrargs, rrargument;

      struct {
	SUBPROCTYPE	sps;
	PORTTYPE	ps;
	int	arity;
	NAMETYPE	name;
	NAMETYPE	module;
      } rrt_functor, rrsubproc_info;

      struct {
	SUBPROCTYPE	sp;
      } rrsubproc;

      struct {
	int	arity;
	NAMETYPE	name;
      } rrfunctor, rrhead;

      struct {
	RuleType	rt;
      } rrrule_type;

      struct {
	RULETYPE	rule;
      } rrruledef;

      struct {
	ExpandMethod	arrange;
      } rrarrange_info;

      struct {
	int	h;
	int	w;
	int	t;
	int	l;
	int	lr;
	PortType	type;
	int	id;
	NAMETYPE	name;
      } rrtr_goalid, rrleft_or_right, rrport_type, rrport_info, rrpoint_size
      , rrproc_type;

      struct {
	PROCTYPE	proc;
      } rrprocdef, rrprocess;

      struct {
	NAMETYPE	str;
      } rrString;

      struct {
	NAMETYPE	name;
	NAMETYPE	module;
      } rrOpt_VARIABLE, rrOpt_SYMBOL, rrVariable, rrSymbol;

      struct {
	int	value;
      } rrInteger;

    }
  rrsastype;

extern rrsastype rrlval;

#define	Imply	258
#define	Assign	259
#define	Mod	260
#define	Land	261
#define	Lor	262
#define	Integer	263
#define	Symbol	264
#define	Variable	265
#define	String	266
#define	Opt_define	267
#define	Opt_port	268
#define	Opt_size	269
#define	Opt_point	270
#define	Opt_type	271
#define	Opt_guard	272
#define	Opt_rule	273
#define	Opt_rule_id	274
#define	Opt_mesg	275
#define	Opt_atom	276
#define	Opt_merge	277
#define	Opt_from	278
#define	Opt_into	279
#define	Opt_link	280
#define	Opt_unify	281
#define	Opt_assign	282
#define	Opt_list	283
#define	Opt_proc	284
#define	Opt_begin	285
#define	Opt_proc_part	286
#define	Opt_other_part	287
#define	Opt_end	288
#define	Opt_comment	289
#define	Opt_creator	290
#define	Opt_normal	291
#define	Opt_network	292
#define	Opt_vanishing	293
#define	Opt_continuous	294
#define	Opt_transition	295
#define	Opt_stream	296
#define	Opt_single	297
#define	Opt_left	298
#define	Opt_right	299
#define	Opt_arrange	300
#define	Opt_rightward	301
#define	Opt_downward	302
#define	Opt_SYMBOL	303
#define	Opt_VARIABLE	304


extern YYSTYPE yylval;
