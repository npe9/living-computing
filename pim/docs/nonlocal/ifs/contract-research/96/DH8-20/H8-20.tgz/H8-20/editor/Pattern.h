// Copyright (C) 1997  Toyoda Masashi (toyoda@is.titech.ac.jp)

// ------------------------------------------------------------
// Objects
// ------------------------------------------------------------

extern Am_Object PatternProto;
extern Am_Object ReplPatternProto;

// ------------------------------------------------------------
// Utility Functions
// ------------------------------------------------------------

Am_Value_List Change_Propagate_List(Am_Object obj);

// ------------------------------------------------------------
// Initialize
// ------------------------------------------------------------

void InitializePattern(void);
