// Copyright (C) 1996,1997  Toyoda Masashi (toyoda@is.titech.ac.jp)

/* Inline functions */

inline int imin(int i1, int i2) {if (i1<i2) return i1; else return i2;}
inline int imax(int i1, int i2) {if (i1>i2) return i1; else return i2;}
inline int iabs(int i1) {if (i1<0) return -i1; else return i1;}

/* Useful functions */

void Am_Center_Of_Object(Am_Object obj, int& cx, int& cy);

/* Opal */
//extern Am_Constraint* Am_Horizontal_Rev_Layout;
extern Am_Formula Am_Horizontal_Rev_Layout;
extern Am_Object Am_Arrow;
extern Am_Slot_Key Am_ARROW_LENGTH;
extern Am_Slot_Key Am_ARROW_WIDTH;

/* Interactors */
void Grid_Positive(Am_Object inter, int x, int y, int &out_x, int &out_y);

extern Am_Object Raise_Move_Grow_Command;
extern Am_Object Raise_Move_Grow_Interactor;
extern Am_Object My_Move_Grow_Interactor;

/* Widgets */
extern Am_Object Am_Border_Roundtangle;

/* Popup Menu */
extern Am_Object Popup_Menu;
extern Am_Object Popup_Button_Command;

extern Am_Slot_Key TARGET_OBJECT;

Am_Object Popup_Menu_and_Return_First_Item(Am_Object inter, Am_Object dest_obj, int x, int y);

/* Initialize */
void My_Amulet_Initialize(void);
