// Copyright (C) 1997  Toyoda Masashi (toyoda@is.titech.ac.jp)

void Initialize_ZoomingText();

#ifndef _INTERNAL_

#define NofFontFamilies	3
#define NofFontSizes	8
#define FontFixed	0
#define FontSerif	1
#define FontSansSerif	2
#define FontSizes	{60, 46, 34, 24, 18, 12, 10, 8}

extern Am_Object ZoomingText;

EXPORT_SLOT(TextPart);
EXPORT_SLOT(FontFamily);
EXPORT_SLOT(FontIsBold);
EXPORT_SLOT(FontIsItalic);
EXPORT_SLOT(FontIsUnderline);

EXPORT_SLOT(FontFamily);
EXPORT_SLOT(MenuWindow);
EXPORT_SLOT(MenuBody);
EXPORT_SLOT(TargetObj);
EXPORT_SLOT(XinTarget);
EXPORT_SLOT(YinTarget);
EXPORT_SLOT(ReturnValue);

#endif
