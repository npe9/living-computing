// Copyright (C) 1997  Toyoda Masashi (toyoda@is.titech.ac.jp)

// Initialize
void Initialize_Rectangle_Widgets(void);

#ifndef _INTERNAL_

// Slots
EXPORT_SLOT(Am_RAISED);
EXPORT_SLOT(Am_THICKNESS);

// Objects
extern Am_Object Am_Border_Roundtangle;

#endif
