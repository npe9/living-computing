// -*- C++ -*-
// Copyright (C) 1996,1997 Buntarou Shizuki(shizuki@is.titech.ac.jp)

#ifndef _Term_h
#define _Term_h

class Term {
 public:
  virtual Am_Object	Image() = 0;
  //
  // for debugging
  //
  virtual void		Dump() = 0;
};

class T_Variable : public Term {
 public:
  Am_Object		Image() { return NULL; }

  //
  // for debugging
  //
  void			Dump() {}
};

class T_List : public Term {
 public:
  Am_Object		Image() { return NULL; }

  //
  // for debugging
  //
  void			Dump() {};
};

#endif

/* eof */
