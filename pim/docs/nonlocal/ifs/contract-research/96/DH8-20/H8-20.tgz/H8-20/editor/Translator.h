// Copyright (C) 1997  Toyoda Masashi (toyoda@is.titech.ac.jp)

// ------------------------------------------------------------
// Formulas
// ------------------------------------------------------------

int Execute_Module(Am_Object top_module, Am_Object module);

// ------------------------------------------------------------
// Initialize
// ------------------------------------------------------------

void InitializeTranslator(void);
