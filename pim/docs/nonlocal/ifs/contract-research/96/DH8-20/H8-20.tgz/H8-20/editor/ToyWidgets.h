// Copyright (C) 1997  Toyoda Masashi (toyoda@is.titech.ac.jp)

#define DEFINE_SLOT(x) Am_Slot_Key x = Am_Register_Slot_Name(#x)
#define EXPORT_SLOT(x) extern Am_Slot_Key x

#include "RectangleWidgets.h"
#include "ZoomWidgets.h"
#include "Formulas.h"
#include "PopUpMenu.h"
#include "Arrow.h"

inline int imin(int i1, int i2) {if (i1<i2) return i1; else return i2;}
inline int imax(int i1, int i2) {if (i1>i2) return i1; else return i2;}
inline int iabs(int i1) {if (i1<0) return -i1; else return i1;}
