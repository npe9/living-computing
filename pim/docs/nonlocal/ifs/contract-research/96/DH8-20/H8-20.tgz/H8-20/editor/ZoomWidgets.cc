// Copyright (C) 1997  Toyoda Masashi (toyoda@is.titech.ac.jp)

#include <amulet.h>
#include OBJECT_ADVANCED__H
#include INTER_ADVANCED__H

extern "C" void bzero(void *, int);
#include <strstream.h>
#include <string.h>
#include <stdlib.h>
#include <limits.h>
#include <math.h>

#define _INTERNAL_
#include "ToyWidgets.h"
#undef _INTERNAL_

#include "Arrow.h"
#include "Formulas.h"
#include "PopUpMenu.h"

// ------------------------------------------------------------
// Align and Zoom Group
// ------------------------------------------------------------

// Global Objects

Am_Object AlignZoomGroup = 0;
Am_Object SequenceAlignZoomGroup = 0;
Am_Object AlignZoomSelectionWidget = 0;

Am_Object UndoZoomCmd = 0;
Am_Object RedoZoomCmd = 0;
Am_Object SelectiveUndoZoomCmd = 0;
Am_Object ZoomUndoDialog = 0;

Am_Object ZoomMenuCmd = 0;

int denom = 100000;

int number_threshold = 30;

// public
DEFINE_SLOT(alignThreshold);
DEFINE_SLOT(minimumSpace);
DEFINE_SLOT(minimumSize);
DEFINE_SLOT(maximumPercentage);
DEFINE_SLOT(allowGrowing);
DEFINE_SLOT(detailThreshold);
DEFINE_SLOT(propagateParent);
DEFINE_SLOT(isShrunken);
DEFINE_SLOT(seqDir);
DEFINE_SLOT(partMoved);
DEFINE_SLOT(numberThreshold);

// private
DEFINE_SLOT(xScaleFactor);
DEFINE_SLOT(yScaleFactor);
DEFINE_SLOT(origWidth);
DEFINE_SLOT(origHeight);
DEFINE_SLOT(gridObject);
DEFINE_SLOT(cellObject);
DEFINE_SLOT(sizeHistory);
DEFINE_SLOT(lastPointer);
DEFINE_SLOT(undoPointer);
DEFINE_SLOT(grown);


#define PartGrowing	0
#define PartMoving	1
#define NoChangeInside	2

// Utility Function

int index(Am_Value_List list, int value)
{
  int idx = 0;
  for (list.Start(); !list.Last(); list.Next(), ++idx)
    if ((int)list.Get() == value) return idx;
  return -1;
}

// grid, cell, interval objects in C++
//
// Am_Group --> [obj1,  obj2,  obj3]
//   ^            ^      ^      ^
//   |            |      |      |
//   v            v      v      v
// grid     --> [cell1, cell2, cell3]
//          --> [wall,  wall,  wall,  wall]
//              [wall,  cell1, cell2, wall]
//              [wall,  cell3, wall,  wall]
//              [wall,  wall,  wall,  wall]
//          -->     [intx1, intx2, intx3]
//          -->     [inty1, inty2, inty3]


class cell {
public:
  Am_Object obj;
  int x;
  int y;
  int w;
  int h;
  int origX;
  int origY;
  int origW;
  int origH;
  int origMaxW; // part$B$,0l$D$N$H$-MQ(B
  int origMaxH; //
  bool isMoved;
  bool isGrown;
  bool visible;
  bool origVisible;

  cell() : obj(Am_No_Object),
    x(0), y(0), w(0), h(0),
    origX(0), origY(0), origW(0), origH(0),
    origMaxW(0), origMaxH(0), isMoved(false), isGrown(false), visible(true), origVisible(true) {}  

  cell(Am_Object object, Am_Object group)
  {
    obj = object;

    int xscale = group.Get(xScaleFactor);
    int yscale = group.Get(yScaleFactor);

    int ox = object.Get(Am_LEFT);
    int oy = object.Get(Am_TOP);
    int ow = object.Get(Am_WIDTH);
    int oh = object.Get(Am_HEIGHT);

    x = ox * denom / xscale;
    y = oy * denom / yscale;
    w = ow;
    h = oh;
    origX = x * denom / xscale;
    origY = y * denom / yscale;
    origW = ow;
    origH = oh;
    origMaxW = ow;
    origMaxH = oh;
    isMoved = true;
    isGrown = false;
    visible = (bool)object.Get(Am_VISIBLE);
    origVisible = visible;
  }

  void show()
  {
    cout << "[" << origW << "," << origH << "]";
  }
};


class interval {
public:
  int  index;
  int  dir;	// 0: x,  1: y
  bool shrinkable;
  bool shrink;
  int  required;
  int  shrinked;
  int  realspace;

  interval() : index(0), dir(0), shrinkable(false), shrink(false),
               required(0), shrinked(0), realspace(0) {}

  bool operator>(interval& x)
  {
    return (this->required - this->shrinked) > (x.required - x.shrinked);
  }
};


class space_distributer {
public:
  void distribute_required_space(interval* intvls, int size)
  {
    for (int i = 0; i < size - 1; ++i) {
      if (intvls[i].shrink)
	intvls[i].realspace = intvls[i].shrinked;
      else
	intvls[i].realspace = intvls[i].required;
    }
  }

  virtual void distribute_space(interval* intvls, int size, int req_length, int length) = 0;
};

class equal_distributer : public space_distributer {
public:
  void distribute_space(interval* intvls, int size, int req_length, int length)
  {
    int space = length - req_length;
    int average = length;
    if (size > 2) average = length / (size - 2);
    int shortage = 0;
    for (int i = 0; i < size - 1; ++i) {
      int required = (intvls[i].shrink) ? intvls[i].shrinked : intvls[i].required;
      if (i == 0 || i == size - 2) {
	if ((average / 2) - required > 0)
	  shortage += (average / 2) - required;
      } else {
	if (average - required > 0)
	  shortage += average - required;
      }
    }
    if (shortage == 0) return;
    for (int i = 0; i < size - 1; ++i) {
      int local_shortage = 0;
      int required = (intvls[i].shrink) ? intvls[i].shrinked : intvls[i].required;
      if (i == 0 || i == size - 2) {
	if ((average / 2) - required > 0)
	local_shortage = (average / 2) - required;
      } else {
	if (average - required > 0)
	  local_shortage = average - required;
      }
      int sp = (space * local_shortage) / shortage;
      intvls[i].realspace += sp;
    }
  }
};

class ratio_distributer : public space_distributer {
public:
  void distribute_space(interval* intvls, int size, int req_length, int length)
  {
    int space = length - req_length;
    //    cout << "space:" << space << " length:" << length << " req:" << req_length << endl;
    for (int i = 0; i < size - 1; ++i) {
      int required = (intvls[i].shrink) ? intvls[i].shrinked : intvls[i].required;
      int sp = 0;
      if (req_length > 0) sp = space * required / req_length;
      intvls[i].realspace += sp;
      //      cout << "<" << required << "," << sp << ">";
    }
    //    cout << endl;
  }
};

class average_distributer : public space_distributer {
public:
  void distribute_space(interval* intvls, int size, int req_length, int length)
  {
    int space = length - req_length;
    //    cout << "space:" << space << " length:" << length << " req:" << req_length << endl;
    int sp = space / (size - 1);
    for (int i = 0; i < size - 1; ++i) {
      intvls[i].realspace += sp;
      //      cout << sp << " ";
    }
    //    cout << endl;
  }
};


class grid {
private:
  space_distributer* _sdist;

  Am_Object _group;

  int _width;
  int _height;
  int _xscale;
  int _yscale;
  int _orig_width; // allowGrowing$B$,(Btrue$B$N$H$-;H$&M=Dj!%(B
  int _orig_height;

  // parameters
  int _minspace; 
  int _minsize;
  int _maxpercent;
  bool _allow_growing;

public: 
  int _req_width;
  int _req_height;

private: 
  // grid
  int _xsize;
  int _ysize;
  int _psize;
  cell*** _grid;
  cell** _parts;
  cell* _wall;

  // intervals
  interval* _xintervals;
  interval* _yintervals;

public:

  grid(Am_Object group)
  {
    _sdist = new equal_distributer();

    _group = group;
    
    _wall = new cell;

    _width = group.Get(Am_WIDTH);
    _height = group.Get(Am_HEIGHT);
    _xscale = group.Get(xScaleFactor);
    _yscale = group.Get(yScaleFactor);
    _orig_width = group.Get(origWidth);
    _orig_height = group.Get(origHeight);

    _minspace = group.Get(minimumSpace);
    _minsize = group.Get(minimumSize);
    _maxpercent = group.Get(maximumPercentage);
    _allow_growing = group.Get(allowGrowing);

    // initialize grid
    if (group.Is_Instance_Of(SequenceAlignZoomGroup)) {
      init_sequence_grid();
    } else {
      init_grid();
    }

    // initialize interval
    _xintervals = new interval[_xsize - 1];
    _yintervals = new interval[_ysize - 1];
  }

  ~grid()
  {
    for (int i = 0; i < _xsize; ++i) {
      delete[] _grid[i];
    }
    delete _sdist;
    delete[] _grid;
    delete[] _parts;
    delete _wall;
    delete[] _xintervals;
    delete[] _yintervals;
  } 
    
private: 
  void init_grid()
  {
    Am_Value_List x_list = Am_Value_List();
    Am_Value_List y_list = Am_Value_List();

    Am_Value_List parts = _group.Get(Am_GRAPHICAL_PARTS);
    _psize = parts.Length();
    _parts = new cell*[_psize];

    int p = 0;
    for (parts.Start(); !parts.Last(); parts.Next(), ++p) {
      Am_Object obj = parts.Get();
      cell* c = (cell*)(Am_Ptr)obj.Get(cellObject);
      _parts[p] = c;
      int xcenter = c->x + c->w / 2;
      for (x_list.Start(); ; x_list.Next()) {
	if (x_list.Last()) { x_list.Add(xcenter);  break; }
	int val = x_list.Get();
	if (xcenter == val) break;
	if (xcenter < val) { x_list.Insert(xcenter, Am_BEFORE);  break; }
      }
      int ycenter = c->y + c->h / 2;
      for (y_list.Start(); ; y_list.Next()) {
	if (y_list.Last()) { y_list.Add(ycenter);  break; }
	int val = y_list.Get();
	if (ycenter == val) break;
	if (ycenter < val) { y_list.Insert(ycenter, Am_BEFORE);  break; }
      }
    }
    _xsize = x_list.Length() + 2;
    _ysize = y_list.Length() + 2;

    _grid = new cell**[_xsize];
    for (int i = 0; i < _xsize; ++i) {
      _grid[i] = new cell*[_ysize];
      for (int j = 0; j < _ysize; ++j) {
	if (i == 0 || i == _xsize -1 || j == 0 || j == _ysize -1)
	  _grid[i][j] = _wall;
	else
	  _grid[i][j] = 0;
      }
    }
    
    for(int i = 0; i < _psize; ++i) {
      cell* c = _parts[i];
      int xidx = index(x_list, c->x + c->w / 2);
      int yidx = index(y_list, c->y + c->h / 2);
      _grid[xidx+1][yidx+1] = c;
    }
  }

  void init_sequence_grid()
  {
    int dir = _group.Get(seqDir);
    
    Am_Value_List parts = _group.Get(Am_GRAPHICAL_PARTS);
    _psize = parts.Length();
    _parts = new cell*[_psize];

    int p = 0;
    for (parts.Start(); !parts.Last(); parts.Next(), ++p) {
      Am_Object obj = parts.Get();
      cell* c = (cell*)(Am_Ptr)obj.Get(cellObject);
      _parts[p] = c;
    }

    if (dir == RightLeft || dir == LeftRight) {
      _xsize = 6;
      _ysize = 3;
    } else {
      _xsize = 3;
      _ysize = 6;
    }

    _grid = new cell**[_xsize];
    for (int i = 0; i < _xsize; ++i) {
      _grid[i] = new cell*[_ysize];
      for (int j = 0; j < _ysize; ++j) {
	if (i == 0 || i == _xsize -1 || j == 0 || j == _ysize -1)
	  _grid[i][j] = _wall;
	else
	  _grid[i][j] = 0;
      }
    }
    
    int start = 0;
    int diff = 1;
    if (dir == RightLeft || dir == BottomTop) {
      start = _psize - 1;
      diff = -1;
    }
    for(int i = 0; i < _psize; ++i) {
      cell* c = _parts[i];
      if (dir == LeftRight || dir == RightLeft) {
	_grid[start + 1][1] = c;
      } else {
	_grid[1][start + 1] = c;
      }
      start += diff;
    }
  }

  bool greater_interval(interval* int1, interval* int2)
  {
    int xshrink = _req_width  - _width;
    int yshrink = _req_height - _height;

    if (int1->dir == int2->dir || (xshrink <= 0 && yshrink <= 0)) {
      return int1->required - int1->shrinked > int2->required - int2->shrinked;
    }
    if (int1->dir == 0) {
      if (xshrink > 0 && yshrink <= 0) return true;
      if (xshrink <= 0 && yshrink > 0) return false;
      return (int1->required - int1->shrinked) * _req_width / _width >
	(int2->required - int2->shrinked) * _req_height / _height;
    }
    if (int1->dir == 1) {
      if (xshrink > 0 && yshrink <= 0) return false;
      if (xshrink <= 0 && yshrink > 0) return true;
      return (int1->required - int1->shrinked) * _req_height / _height >
	(int2->required - int2->shrinked) * _req_width / _width;
    }
    return false;
  }
    

public: 
  void show() {
    cout << "==================================================" << endl;
    cout << _xscale << " " << _yscale << " " << _width << " " << _height << endl;
    cout << "--------------------------------------------------" << endl;
    cout << "\t\t";
    for (int x = 0; x < _xsize - 1; ++x) {
      cout << _xintervals[x].required << "\t";
    }
    cout << endl << "\t\t";
    for (int x = 0; x < _xsize - 1; ++x) {
      cout << _xintervals[x].shrinked << ((_xintervals[x].shrink) ? "o" : "x") << "\t";
    }
    cout << endl;

    for (int y = 0; y < _ysize; ++y) {
      if (y < _ysize - 1) {
	cout << _yintervals[y].required << "\t" << _yintervals[y].shrinked
	     << ((_yintervals[y].shrink) ? "o" : "x") << "\t";
      } else cout << "\t\t";
      for (int x = 0; x < _xsize; ++x) {
	if (_grid[x][y] != 0) { _grid[x][y]->show();  cout << "\t"; }
	else cout << ".\t";
      }
      cout << endl;
    }

    cout << "--------------------------------------------------" << endl;
    for (int i = 0; i < _xsize - 1; ++i) {
      interval first = _xintervals[i];
      cout << "[(" << first.dir << "," << first.index << ")" << first.realspace << "," << first.required << "," << first.shrinked << "," << first.shrink << "]";
      cout << endl;
    }
    for (int i = 0; i < _ysize - 1; ++i) {
      interval first = _yintervals[i];
      cout << "[(" << first.dir << "," << first.index << ")" << first.realspace << "," << first.required << "," << first.shrinked << "," << first.shrink << "]";
      cout << endl;
    }
    cout << "==================================================" << endl;

  }

public:
  void update() {
    _width = _group.Get(Am_WIDTH);
    _height = _group.Get(Am_HEIGHT);
  }

public:
  void calc_intervals()
  {
    calc_x_intervals();
    calc_y_intervals();
  }

private:
  void calc_x_intervals()
  {
    _req_width = 0;
    for (int x = 0; x < _xsize - 1; ++x) {
      int lmax = 0;
      int rmax = 0;
      int shmax = 0;
      for (int y = 1; y < _ysize - 1; ++y) {
	int left = 0;
	int right = 0;
	if (_grid[x][y] != 0) {
	  //	  if (_grid[x][y]->visible == true) {
	    left = _grid[x][y]->w / 2;
	    lmax = imax(lmax, left);
	    //	  }
	}
	if (_grid[x+1][y] != 0) {
	  //	  if (_grid[x+1][y]->visible == true) {
	    right = _grid[x+1][y]->w / 2;
	    rmax = imax(rmax, right);
	    //	  }
	}
	shmax = imax(shmax, left + right);
      }
      _xintervals[x].index = x;
      _xintervals[x].dir = 0;
      _xintervals[x].required = lmax + rmax + ((lmax + rmax > 0) ? _minspace : 0);
      _xintervals[x].shrinked = shmax + ((shmax > 0) ? (_minspace / 2) : 0);
      _req_width += _xintervals[x].required;
    }
  }

  void calc_y_intervals()
  {
    _req_height = 0;
    for (int y = 0; y < _ysize - 1; ++y) {
      int lmax = 0;
      int rmax = 0;
      int shmax = 0;
      for (int x = 1; x < _xsize - 1; ++x) {
	int left = 0;
	int right = 0;
	if (_grid[x][y] != 0) {
	  //	  if (_grid[x][y]->visible == true) {
	    left  = (_grid[x][y]->h) / 2;
	    lmax = imax(lmax, left);
	    //	  }
	}
	if (_grid[x][y+1] != 0) {
	  //	  if (_grid[x][y+1]->visible == true) {
	    right = (_grid[x][y+1]->h) / 2;
	    rmax = imax(rmax, right);
	    //	  }
	}
	shmax = imax(shmax, left + right);
      }
      _yintervals[y].index = y;
      _yintervals[y].dir = 1;
      _yintervals[y].required = lmax + rmax + ((lmax + rmax > 0) ? _minspace : 0);
      _yintervals[y].shrinked = shmax + ((shmax > 0) ? (_minspace / 2) : 0);
      _req_height += _yintervals[y].required;
    }
  }

public:
  void shrink(int type)
  {
    int req_w = calc_required(Am_LEFT);
    int req_h = calc_required(Am_TOP);

    if ((req_w > _width && /* || */  req_h > _height) && type != PartMoving) return;

    for (int y = 1; y < _ysize - 2; ++y) _yintervals[y].shrink = false;
    for (int x = 1; x < _xsize - 2; ++x) _xintervals[x].shrink = false;
      
    Am_Value_List sorted_intervals = Am_Value_List();

    for (int y = 1; y < _ysize - 2; ++y) {
      for (sorted_intervals.Start(); !sorted_intervals.Last()
	     && greater_interval((interval*)(Am_Ptr)sorted_intervals.Get(), &_yintervals[y]);
	   sorted_intervals.Next());
      sorted_intervals.Insert(&_yintervals[y], Am_BEFORE);
    }
    for (int x = 1; x < _xsize - 2; ++x) {
      for (sorted_intervals.Start(); !sorted_intervals.Last()
	     && greater_interval((interval*)(Am_Ptr)sorted_intervals.Get(), &_xintervals[x]);
	   sorted_intervals.Next());
      sorted_intervals.Insert(&_xintervals[x], Am_BEFORE);
    }
    for (sorted_intervals.Start(); !sorted_intervals.Last(); sorted_intervals.Next()) {
      bool shrinkable = false;
      interval* i = (interval*)(Am_Ptr)sorted_intervals.Get();
      if (i->dir == 0) shrinkable = is_x_shrinkable(i->index);
      if (i->dir == 1) shrinkable = is_y_shrinkable(i->index);
      //      cout << "(" << (*first)->dir << "," << (*first)->index << "," << shrinkable << ")";
      if (shrinkable) i->shrink = true;
    }
    //    cout << endl;
  }

  void arrange(int type)
  {
    _req_width = calc_shrinked_required(Am_LEFT);
    _req_height = calc_shrinked_required(Am_TOP);

    _sdist->distribute_required_space(_xintervals, _xsize);
    _sdist->distribute_required_space(_yintervals, _ysize);

    _xscale = denom;
    _yscale = denom;

    //    if (_req_width * 3 / 2 <= _width) { // && _xsize > 3) {
    //      if (_req_width > 0) _xscale = denom * (_width * 2) / (_req_width * 3);
    //      _sdist->distribute_space(_xintervals, _xsize, _width * 2 / 3, _width);
    //    } else
    if (_req_width <= _width) {
      _sdist->distribute_space(_xintervals, _xsize, _req_width, _width);
    } else {
      _xscale = (denom * _width) / _req_width;
    }
    //    if (_req_height * 3 / 2 <= _height) { // && _ysize > 3) {
    //      if (_req_height > 0) _yscale = denom * (_height * 2) / (_req_height * 3);
    //      _sdist->distribute_space(_yintervals, _ysize, _height * 2 / 3, _height);
    //    } else
    if (_req_height <= _height) {
      _sdist->distribute_space(_yintervals, _ysize, _req_height, _height);
    } else {
      _yscale = (denom * _height) / _req_height;
    }

//     if (_req_width > 0 && _xsize > 3) _xscale = (denom * _width) / _req_width;
//     else distribute_space(_xintervals, _xsize, _req_width, _width);
//     if (_req_height > 0 && _ysize > 3) _yscale = (denom * _height) / _req_height;
//     else distribute_space(_yintervals, _ysize, _req_height, _height);
    //    cout << "w: " << _width << " h: " << _height << " rw: " << _req_width << " rh: " << _req_height << endl;
    //    cout << "xscale: " << _xscale << " yscale: " << _yscale << endl;
    //    show();

    if (_xscale <= 1 || _yscale <= 1) {
      cout << "scale(s) too small. aborting..." << endl;
      abort();
      return;
    }
    //      scale = imin(xscale, yscale);
    //    bool local1 = check_local();
    //    bool local1 = check_local();
    bool local2 = check_local2(type);
    if ( local2) {
      _group.Set(xScaleFactor, _xscale);
      _group.Set(yScaleFactor, _yscale);
      set_lefts(_xscale);
      set_tops(_yscale);
      set_nums();
    } else {
      calc_intervals();
      arrange(PartMoving);
    }

    /*
    if (check_local(xscale, yscale)) {
      group.Set(xScaleFactor, xscale);
      group.Set(yScaleFactor, yscale);
      set_lefts(xscale);
      set_tops(yscale);
    } else if ((bool)group.Get(allowGrowing)) {
      grow(group, xscale, yscale); // $B%O%$%V%j%C%I$OFq$7$$!%$9$0%k!<%W$9$k!%(B
      group.Set(xScaleFactor, xscale);
      group.Set(yScaleFactor, yscale);
      set_lefts(xscale);
      set_tops(yscale);
    } else {
      abort(group);
    }
    */
  }

  // For shrink()

  bool is_x_shrinkable(int x)
  {
    for (int y = 1; y < _ysize-1; ++y) {
      //      if (_grid[x][y].Valid() && _grid[x+1][y].Valid())	return false;
      if (_grid[x][y] != 0)
	if((_grid[x+1][y-1] != 0 && _yintervals[y-1].shrink) ||
	   (_grid[x+1][y+1] != 0 && _yintervals[y].shrink))
	  return false;
      if (_grid[x+1][y] != 0)
	if((_grid[x][y-1] != 0 && _yintervals[y-1].shrink) ||
	   (_grid[x][y+1] != 0 && _yintervals[y].shrink))
	  return false;
    }
    return true;
  }

  bool is_y_shrinkable(int y)
  {
    for (int x = 1; x < _xsize-1; ++x) {
      //      if (_grid[x][y].Valid() && _grid[x][y+1].Valid())	return false;
      if (_grid[x][y] != 0)
	if((_grid[x-1][y+1] != 0 && _xintervals[x-1].shrink) ||
	   (_grid[x+1][y+1] != 0 && _xintervals[x].shrink))
	  return false;
      if (_grid[x][y+1] != 0)
	if((_grid[x-1][y] != 0 && _xintervals[x-1].shrink) ||
	   (_grid[x+1][y] != 0 && _xintervals[x].shrink))
	  return false;
    }
    return true;
  }

  // For arrange()

  bool check_local()
  {
    bool local = true;
    for (int i = 0; i < _psize; ++i) {
      cell* c = _parts[i];
      c->isMoved = false;
      //      if (!c->visible) continue;
      int ow = c->w;
      int oh = c->h;
      int w = ow * _xscale / denom;
      int h = oh * _yscale / denom;
      //	  if (w < _minsize) local = false;
      //	  if (h < _minsize) local = false;
      if ((w > _width * _maxpercent / 100) && _xsize > 3) {
	if ((_req_width - ow) < _width * (100 - _maxpercent) / 100) {
	  c->w = _width * _maxpercent / 100;
	} else {
	  c->w = (_req_width - ow) * _maxpercent / (100 - _maxpercent);
	}
	local = false;
      } 
      if ((h > _height * _maxpercent / 100) && _ysize > 3) {
	if ((_req_height - oh) < _height * (100 - _maxpercent) / 100) {
	  c->h = _height * _maxpercent / 100;
	} else {
	  c->h = (_req_height - oh) * _maxpercent / (100 - _maxpercent);
	}
	local = false;
      } 
    }
    return local;
  }

  bool check_local2(int type)
  {
    if (type == NoChangeInside) return true;
    bool local = true;
    Am_Object parent = _group.Get(propagateParent);

    for (int i = 0; i < _psize; ++i) {
      cell* c = _parts[i];
      c->isMoved = false;
      //      if (!c->visible) continue;
      int ow = c->w;
      int oh = c->h;
      int w = ow * _xscale / denom;
      int h = oh * _yscale / denom;

      if ((w > _width - _minspace * 2) && _xsize == 3 && type == PartGrowing) {
	if (parent.Valid()) {
	  _width = w + _minspace * 2;
	  parent.Set(Am_WIDTH, _width)
	    .Set(grown, true);
	} else {
	  c->w = _width - _minspace * 2;
	}
	local = false;
      }
      if ((w > _width * _maxpercent / 100) && _xsize > 3) {
	c->w = (_req_width - ow) * _maxpercent / (100 - _maxpercent);
	if (parent.Valid()) {
	  int diff = w * (100 - _maxpercent) / _maxpercent;
	  _width += diff;
	  parent.Set(Am_WIDTH, (int)parent.Get(Am_WIDTH) + diff)
	    .Set(grown, true);
	  //	  _width = w * 100 / _maxpercent;
	  //	  _group.Set(Am_WIDTH, _width);
	}
	local = false;
      } 
      if ((h > _height - _minspace * 2) && _ysize == 3 && type == PartGrowing) {
	if (parent.Valid()) {
	  _height = h + _minspace * 2;
	  parent.Set(Am_HEIGHT, _height)
	    .Set(grown, true);
	} else {
	  c->h = _height - _minspace * 2;
	}
	local = false;
      }
      if ((h > _height * _maxpercent / 100) && _ysize > 3) {
	c->h = (_req_height - oh) * _maxpercent / (100 - _maxpercent);
	if (parent.Valid()) {
 	  int diff = h * (100 - _maxpercent) / _maxpercent;
 	  _height += diff;
 	  parent.Set(Am_HEIGHT, (int)parent.Get(Am_HEIGHT) + diff)
	    .Set(grown, true);
	  //	  _height = h * 100 / _maxpercent;
	  //	  _group.Set(Am_HEIGHT, _height);
	}
	// cout << endl;
	local = false;
      } 
    }
    return local;
  }

  /*
  void grow(Am_Object group, int xscale, int yscale)
  {
    while (check_local(xscale, yscale) == false) {
      _width = _width + 1;
      _height = _height + 1;
    }
    group.Set(Am_WIDTH, _width);
    group.Set(Am_HEIGHT, _height);
  }
  */




  bool check_local3(int type)
  {
    bool local = true;

    bool xcheck = (_xsize == 3 && _req_width > _width && type == PartGrowing);
    bool ycheck = (_ysize == 3 && _req_height > _height && type == PartGrowing);

    for (int i = 0; i < _psize; ++i) {
      cell* c = _parts[i];
      //      if (!c->visible) continue;
      int maxw = c->origMaxW;
      int maxh = c->origMaxH;
	  
      if (xcheck) {
	if (_width < maxw  && maxw < c->origW) {
	  c->origW = maxw;
	  local = false;
	} else if (maxw <= _width && _width < c->origW) {
	  c->origW = _width - _minspace * 2;
	  local = false;
	}
      }
      if (ycheck) {
	if (_height < maxh && maxh < c->origH) {
	  c->origH = maxh;
	  local = false;
	} else if (maxh <= _height && _height < c->origH) {
	  c->origH = _height - _minspace * 2;
	  local = false;
	}
      }
    }
    return local;
  }

  void abort()
  {
    for (int i = 0; i < _psize; ++i) {
      cell* c = _parts[i];
      //      if (!c->visible) continue;
      c->x = c->origX;
      c->y = c->origY;
      c->w = c->origW;
      c->h = c->origH;
    }
  }

  void set_lefts(int scale)
  {
    int left = 0;
    for (int x = 0; x < _xsize - 2; ++x) {
      left += _xintervals[x].realspace;
      for (int y = 1; y < _ysize - 1; ++y) {
	cell* c = _grid[x+1][y];
	if (c != 0) {
	  c->origX = left - c->w / 2;
	  c->x = c->origX * scale / denom;
	  c->obj.Set(Am_LEFT, c->x);
	  if (c->isGrown) c->origW = c->w;
	  //	  if (c->visible)
	    c->w = imax(2, c->w * scale / denom);
	  c->obj.Set(Am_WIDTH, c->w);
	}
      }
    }
  }

  void set_tops(int scale)
  {
    int top = 0;
    for (int y = 0; y < _ysize - 2; ++y) {
      top += _yintervals[y].realspace;
      for (int x = 1; x < _xsize - 1; ++x) {
	cell* c = _grid[x][y+1];
	if (c != 0) {
	  c->origY = top - c->h / 2;
	  c->y = c->origY * scale / denom;
	  c->obj.Set(Am_TOP, c->y);
	  if (c->isGrown) {c->origH = c->h; c->isGrown = false;}
	  //	  if (c->visible)
	    c->h = imax(2, c->h * scale / denom);
	  c->obj.Set(Am_HEIGHT, c->h);
	}
      }
    }
  }

  void set_nums()
  {
    if (_group.Get_Slot_Type(numberThreshold) == Am_UNINIT) return;
    int number = (int)_group.Get(numberThreshold) - 1;
    int total_area = 0;
    int max_area = 0;
    int max_index = 0;
    for (int i = 0; i < _psize; ++i) {
      cell* c = _parts[i];
      if (!c->visible) continue;
      int area = (int)floor(sqrt(c->w * c->h));
      total_area += area;
      if (area > max_area) {
	max_area = area;
	max_index = i;
      }
    }
    int counter = number;
    for (int i = 0; i < _psize; ++i) {
      cell* c = _parts[i];
      if (!c->visible) continue;
      int num = (int)floor(sqrt(c->w * c->h)) * number / total_area;
      c->obj.Set(numberThreshold, num);
      counter -= num;
    }
    if (counter > 0 && _psize > 0) {
      Am_Object object = _parts[max_index]->obj;
      object.Set(numberThreshold, (int)object.Get(numberThreshold) + counter);
    }    
  }

  int calc_shrinked_required(Am_Slot_Key key)
  {
    interval* intervals = 0; 
    int size;
    if (key == Am_LEFT) { intervals = _xintervals;  size = _xsize - 1; }
    else                { intervals = _yintervals;  size = _ysize - 1; }   

    int length = 0;
    for (int i = 0; i < size; ++i) {
      if (intervals[i].shrink)
	length += intervals[i].shrinked;
      else 
	length += intervals[i].required;
    }
    return length;
  }

  int calc_required(Am_Slot_Key key)
  {
    interval* intervals = 0; 
    int size;
    if (key == Am_LEFT) { intervals = _xintervals;  size = _xsize - 1; }
    else                { intervals = _yintervals;  size = _ysize - 1; }   

    int length = 0;
    for (int i = 0; i < size; ++i) {
      length += intervals[i].required;
    }
    return length;
  }
};

// ------------------------------------------------------------
// Public Functions
// ------------------------------------------------------------

// get required width and height
// -----------------------------
int Get_Required_Width(Am_Object group)
{
  if (!group.Is_Instance_Of(AlignZoomGroup)) return group.Get(Am_WIDTH);
  if (group.Get(gridObject).Valid()) {
    grid* g = (grid*)(Am_Ptr)group.Get(gridObject);
    return g->_req_width;
  }
  else group.Get(Am_WIDTH);
}

int Get_Required_Height(Am_Object group)
{
  if (!group.Is_Instance_Of(AlignZoomGroup)) return group.Get(Am_HEIGHT);
  if (group.Get(gridObject).Valid()) {
    grid* g = (grid*)(Am_Ptr)group.Get(gridObject);
    return g->_req_height;
  }
  else group.Get(Am_HEIGHT);
}

// get original x, y, width, height
// --------------------------------
int origX(Am_Object obj)
{
  if (obj.Get_Slot_Type(cellObject) == Am_NONE) return obj.Get(Am_LEFT);
  cell* c = (cell*)(Am_Ptr)obj.Get(cellObject);
  return c->origX;
}

int origY(Am_Object obj)
{
  if (obj.Get_Slot_Type(cellObject) == Am_NONE) return obj.Get(Am_TOP);
  cell* c = (cell*)(Am_Ptr)obj.Get(cellObject);
  return c->origY;
}

int origW(Am_Object obj)
{
  if (obj.Get_Slot_Type(cellObject) == Am_NONE) return obj.Get(Am_WIDTH);
  cell* c = (cell*)(Am_Ptr)obj.Get(cellObject);
  return c->origW;
}

int origH(Am_Object obj)
{
  if (obj.Get_Slot_Type(cellObject) == Am_NONE) return obj.Get(Am_HEIGHT);
  cell* c = (cell*)(Am_Ptr)obj.Get(cellObject);
  return c->origH;
}

// for create and copy parts of AlignZoomGroup

Am_Object Align_Zoom_Create_Part(Am_Object part)
{
  cell* c = (cell*)(Am_Ptr)part.Get(cellObject);
  Am_Object new_part = part.Create()
    .Set(Am_LEFT,   c->origX)
    .Set(Am_TOP,    c->origY)
    .Set(Am_WIDTH,  c->origW)
    .Set(Am_HEIGHT, c->origH)
    ;
  new_part.Remove_Slot(cellObject);
  new_part.Remove_Slot(sizeHistory);
  new_part.Remove_Slot(lastPointer);
  new_part.Remove_Slot(undoPointer);
  new_part.Remove_Slot(grown);
      
  return new_part;
}

Am_Object Align_Zoom_Copy_Part(Am_Object part)
{
  Am_Object new_part = part.Copy();
  if (new_part.Get_Slot_Type(cellObject) != Am_NONE) {
    cell* c = (cell*)(Am_Ptr)part.Get(cellObject);
    new_part
      .Set(Am_LEFT,   c->origX)
      .Set(Am_TOP,    c->origY)
      .Set(Am_WIDTH,  c->origW)
      .Set(Am_HEIGHT, c->origH)
      ;
    new_part.Remove_Slot(cellObject);
    new_part.Remove_Slot(sizeHistory);
    new_part.Remove_Slot(lastPointer);
    new_part.Remove_Slot(undoPointer);
    new_part.Remove_Slot(grown);
  }
  return new_part;
}


// create copy demon procedures for AlignZoomGroup

void alignzoom_create_copy_demon_proc(Am_Object self)
{
  // grid $B$O%3%T!<$7$J$$!#(B
  self.Set(gridObject, 0);
  // $B3F%Q!<%H$N(Bcell$B$r%3%T!<(B
  Am_Value_List parts = self.Get(Am_GRAPHICAL_PARTS);
  for (parts.Start(); !parts.Last(); parts.Next()) {
    Am_Object p = parts.Get();
    cell* orig_cell = (cell*)(Am_Ptr)p.Get(cellObject);
    cell* new_cell = new cell(*orig_cell);
    new_cell->obj = p;
    p.Set(cellObject, (Am_Ptr)new_cell);
  }
}

void alignzoom_create_demon(Am_Object self)
{
  // $B%*%j%8%J%k$N%G!<%b%s%W%m%7!<%8%c$r8F$V(B
  Am_Object_Advanced proto_adv = (Am_Object_Advanced&)Am_Group;
  Am_Object_Demon* proto_create = proto_adv.Get_Demons().Get_Object_Demon(Am_CREATE_OBJ);
  if (proto_create) proto_create(self);
  alignzoom_create_copy_demon_proc(self);
}

void alignzoom_copy_demon(Am_Object self)
{
  // $B%*%j%8%J%k$N%G!<%b%s%W%m%7!<%8%c$r8F$V(B
  Am_Object_Advanced proto_adv = (Am_Object_Advanced&)Am_Group;
  Am_Object_Demon* proto_create = proto_adv.Get_Demons().Get_Object_Demon(Am_COPY_OBJ);
  if (proto_create) proto_create(self);
  alignzoom_create_copy_demon_proc(self);
}

// create copy demon procedures for parts of AlignZoomGroup

void alignzoom_parts_create_copy_demon_proc(Am_Object self)
{
  cell* c = (cell*)(Am_Ptr)self.Get(cellObject);
  self
    .Set(Am_LEFT,   c->origX)
    .Set(Am_TOP,    c->origY)
    .Set(Am_WIDTH,  c->origW)
    .Set(Am_HEIGHT, c->origH)
    ;
}

void alignzoom_parts_create_demon(Am_Object self)
{
  Am_Object_Advanced proto_adv = (Am_Object_Advanced&)Am_Group;
  Am_Object_Demon* proto_create = proto_adv.Get_Demons().Get_Object_Demon(Am_CREATE_OBJ);
  if (proto_create) proto_create(self);
  /*
  //   $B%W%m%H%?%$%W$N%G!<%b%s%a%=%C%I$r8F$V%3!<%I%U%i%0%a%s%H(B
  Am_Object_Advanced self_adv = (Am_Object_Advanced&)self;
  Am_Object_Demon* self_create = self_adv.Get_Demons().Get_Object_Demon(Am_CREATE_OBJ);

  Am_Object pivot = self;
  Am_Object_Demon* proto_create = 0;
  for (;;) {
    Am_Object proto = pivot.Get_Prototype();
    if (!proto.Valid()) { proto_create = 0;  break; }
    Am_Object_Advanced proto_adv = (Am_Object_Advanced&)pivot;
    Am_Object_Demon* proto_create = proto_adv.Get_Demons().Get_Object_Demon(Am_CREATE_OBJ);
    if (self_create != proto_create) break;
    pivot = proto;
  }
  if (proto_create) proto_create(self);
  */

  alignzoom_parts_create_copy_demon_proc(self);
}

void alignzoom_parts_copy_demon(Am_Object self)
{
  Am_Object_Advanced proto_adv = (Am_Object_Advanced&)Am_Group;
  Am_Object_Demon* proto_create = proto_adv.Get_Demons().Get_Object_Demon(Am_COPY_OBJ);
  if (proto_create) proto_create(self);

  /*
  //   $B%W%m%H%?%$%W$N%G!<%b%s%a%=%C%I$r8F$V%3!<%I%U%i%0%a%s%H(B
  Am_Object_Advanced self_adv = (Am_Object_Advanced&)self;
  Am_Object_Demon* self_create = self_adv.Get_Demons().Get_Object_Demon(Am_COPY_OBJ);

  Am_Object pivot = self;
  Am_Object_Demon* proto_create = 0;
  for (;;) {
    Am_Object proto = pivot.Get_Prototype();
    if (!proto.Valid()) { proto_create = 0;  break; }
    Am_Object_Advanced proto_adv = (Am_Object_Advanced&)pivot;
    Am_Object_Demon* proto_create = proto_adv.Get_Demons().Get_Object_Demon(Am_COPY_OBJ);
    if (self_create != proto_create) break;
    pivot = proto;
  }
  if (proto_create) proto_create(self);
  */

  alignzoom_parts_create_copy_demon_proc(self);
}

// Add Part Demon for AlignZoomGroup

void alignzoom_part_demon(Am_Object self, Am_Object removed, Am_Object added)
{
  // $B%*%j%8%J%k$N%G!<%b%s%W%m%7!<%8%c$r8F$V(B
  Am_Object_Advanced proto_adv = (Am_Object_Advanced&)Am_Group;
  Am_Part_Demon* proto_part = proto_adv.Get_Demons().Get_Part_Demon(Am_ADD_PART);
  if (proto_part) proto_part(self, removed, added);
  // $B%0%i%U%#%+%k%Q!<%H$NJQ99$+(B?
  if (!added.Is_Instance_Of(Am_Graphical_Object)
      && !removed.Is_Instance_Of(Am_Graphical_Object)) return;

  if (removed.Valid()) {
    if (removed.Get_Slot_Type(cellObject) == Am_NONE) return;
    cell* c = (cell*)(Am_Ptr)removed.Get(cellObject);
    removed
      .Set(Am_LEFT, c->origX)
      .Set(Am_TOP, c->origY)
      .Set(Am_WIDTH, c->origW)
      .Set(Am_HEIGHT, c->origH)
      ;
    delete c;
    removed.Remove_Slot(cellObject);
    removed.Remove_Slot(sizeHistory);
    removed.Remove_Slot(lastPointer);
    removed.Remove_Slot(undoPointer);
    removed.Remove_Slot(grown);
    removed.Remove_Slot(numberThreshold);
    self.Set(partMoved, true);
  }
  if (added.Valid()) {
    cell* c = new cell(added, self);
    Am_Inter_Location new_loc = Am_Inter_Location(false, self, 0, 0,
						  c->origW, c->origH);
    added.Set(cellObject, (Am_Ptr)c);
    added.Set(sizeHistory, Am_Value_List().Add(new_loc));
    added.Set(lastPointer, new_loc);
    added.Set(undoPointer, new_loc);
    added.Set(grown, false);
    added.Set(numberThreshold, number_threshold);
    self.Set(partMoved, true);

    /*
    Am_Object_Advanced obj_adv = (Am_Object_Advanced&)added;
    Am_Demon_Set obj_demon_set(obj_adv.Get_Demons().Copy());
    obj_demon_set.Set_Object_Demon(Am_CREATE_OBJ, alignzoom_parts_create_demon);
    obj_demon_set.Set_Object_Demon(Am_COPY_OBJ, alignzoom_parts_copy_demon);
    obj_adv.Set_Demons(obj_demon_set);
    */
  }
}


// Formulas

// Check Changes	----------------------------------------

Am_Define_Formula(bool, IsShurunkenForm)
{
  if ((int)self.GV(xScaleFactor) < denom ||
      (int)self.GV(yScaleFactor) < denom)
    return true;
  else
    return false;
}

Am_Define_Formula(int, CheckChangesForm)
{
  //  cout << self << "start recover ";
  //  int minspace = self.Get(minimumSpace);
  //  int width  = (int)self.Get(Am_WIDTH)  - minspace * 2;
  //  int height = (int)self.Get(Am_HEIGHT) - minspace * 2;
  int xscale = self.Get(xScaleFactor);
  int yscale = self.Get(yScaleFactor);

  bool moving  = false;
  bool growing = false;

  if ((bool)self.Get(partMoved) == true) {
    moving = true;
    self.Set(partMoved, false);
  }

  Am_Value_List parts = self.GV(Am_GRAPHICAL_PARTS);
  for (parts.Start(); !parts.Last(); parts.Next()) {
    Am_Object obj = parts.Get();
    // $B8=:_$N:BI8!&Bg$-$5!&2D;k(B
    int nx = obj.GV(Am_LEFT);
    int ny = obj.GV(Am_TOP);
    int nw = obj.GV(Am_WIDTH);
    int nh = obj.GV(Am_HEIGHT);

    bool temp_growing = false;

    cell* c = (cell*)(Am_Ptr)obj.Get(cellObject);
    c->visible = (bool)obj.GV(Am_VISIBLE);
    //    if (!c->visible) continue; // $BIT2D;k$OL5;k(B
    if (c->visible != c->origVisible) moving = true;
    c->origVisible = c->visible;

    int ow = c->origW;
    int oh = c->origH;
    
    if (c->isMoved) { // $B%*%V%8%'%/%H$,DI2C$5$l$?$H$-!"(Btrue$B$K$J$C$F$$$k(B
      c->x = c->origX;
      c->y = c->origY;
      c->w = c->origW;
      c->h = c->origH;
      moving = true;
    } else {
      if (nw != c->w) { // $BI}$,JQ2=$7$F$$$k$H$-(B
	c->w = nw * denom / xscale;
	//	  int omaxw = c->origMaxW;
	//	  if (omaxw < width && c->origW < width) c->origMaxW = c->origW; // origMax$B$NJQ99(B
	//	  if (width < omaxw  && omaxw < c->origW) c->origW = omaxw; // origMax$B$^$G3HBg5v$9!#(B
	//	  if (omaxw <= width && width * 3 < c->origW) c->origW = width * 3; 
	c->x = (c->origX + ow / 2) - c->w / 2; // $BCf1{$OF1$80LCV(B
	c->isGrown = true;
	growing = true;
	temp_growing = true;
      } else {
	c->w = ow;
      }
      if (nh != c->h) { // $B9b$5$,JQ2=$7$F$$$k$H$-(B
	c->h = nh * denom / yscale;
	// 	  int omaxh = c->origMaxH;
	//	  if (omaxh < height && c->origH < height) c->origMaxH = c->origH; // origMax$B$NJQ99(B
	//	  if (height < omaxh  && omaxh < c->origH)  c->origH = omaxh;
	//	  if (omaxh <= height && height * 3 < c->origH) c->origH = height * 3;
	c->y = (c->origY + oh / 2) - c->h / 2; // $BCf1{$OF1$80LCV(B
	c->isGrown = true;
	growing = true;
	temp_growing = true;
      } else {
	c->h = oh;
      }
      if (!temp_growing) {
	if (nx != c->x) { // x$B:BI8$,JQ2=$7$F$$$k$H$-(B
	  c->x = nx * denom / xscale;
	  c->isMoved = true;
	  moving = true;
	} else {
	  c->x = c->origX;
	}
	if (ny != c->y) { // y$B:BI8$,JQ2=$7$F$$$k$H$-(B
	  c->y = ny * denom / yscale;
	  c->isMoved = true;
	  moving = true;
	} else {
	  c->y = c->origY;
	}
      }
    }
  }
  if (moving)  { /* cout << " Part moving" << endl; */   return PartMoving; }  
  if (growing) { /* cout << " Part growing" << endl; */  return PartGrowing; }
  /* cout << " All growing" << endl; */                  return NoChangeInside;
}


// Avoid Overlap	----------------------------------------

Am_Define_Formula(int, AvoidOverlapLayout)
{
  int threshold = self.GV(alignThreshold);

  Am_Value_List parts = self.Get(Am_GRAPHICAL_PARTS);
  Am_Value_List others = self.Get(Am_GRAPHICAL_PARTS);

  for (parts.Start(); !parts.Last(); parts.Next()) {
    cell* one = (cell*)(Am_Ptr)((Am_Object)parts.Get()).Get(cellObject);
    if (one->isMoved) {
      bool objectMoved;
      int xdir = 0;
      int ydir = 0;
      do {
	objectMoved = false;
	for (others.Start(); !others.Last(); others.Next()) {
	  cell* another = (cell*)(Am_Ptr)((Am_Object)others.Get()).Get(cellObject);
	  if (one == another) continue;
	  
	  int onex = one->x + one->w / 2;
	  int oney = one->y + one->h / 2;
	  int anox = another->x + another->w / 2;
	  int anoy = another->y + another->h / 2;
	  int xdiff = abs(onex - anox);
	  int ydiff = abs(oney - anoy);

	  if (xdiff < threshold && ydiff < threshold) {
	    if (xdir == 0 && ydir == 0) {
	      xdir = ((onex - anox < 0) ? -1 : 1) * ((xdiff >= ydiff) ? 1 : 0);
	      ydir = ((oney - anoy < 0) ? -1 : 1) * ((ydiff >= xdiff) ? 1 : 0);
	    }
	    one->x = one->x + (anox - xdir * (threshold + 2) - onex);
	    one->y = one->y + (anoy - ydir * (threshold + 2) - oney);
	    objectMoved = true;
	  }
	}
      } while (objectMoved);
    }
  }
  return 0;
}

Am_Define_Formula(int, AlignSequenceLayout)
{
  int maxw = 0;
  int maxh = 0;

  Am_Value_List parts = self.GV(Am_GRAPHICAL_PARTS);
  int length = parts.Length();
  if (length <= 0) return 1;

  for (parts.Start(); !parts.Last(); parts.Next()) {
    cell* c = (cell*)(Am_Ptr)((Am_Object)parts.Get()).Get(cellObject);
    int w = c->w;
    int h = c->h;
    maxw = imax(maxw, w);
    maxh = imax(maxh, h);
  }
  int dir = self.GV(seqDir);
  bool inc_left = true;
  bool forward = true;
  if (dir == TopBottom || dir == BottomTop) inc_left = false;
  if (dir == LeftRight || dir == TopBottom) {parts.Start(); forward = true;}
  if (dir == RightLeft || dir == BottomTop) {parts.End(); forward = false;}

  int left = 0;
  int top = 0;

  for ( ; !parts.Last() && !parts.First() ; ) {
    cell* c = (cell*)(Am_Ptr)((Am_Object)parts.Get()).Get(cellObject);
    int w = c->w;
    int h = c->h;
    if (inc_left) top = (maxh - h) / 2;
    else          left = (maxw - w) / 2;
    c->x = left;
    c->origX = left;
    c->y = top;
    c->origY = top;
    if (inc_left) left += w; else top += h; 
    if (forward) parts.Next(); else parts.Prev();
  }
  return 1;
}


// Align		----------------------------------------

Am_Define_Formula(int, AlignLayout)
{
  int threshold = self.Get(alignThreshold);

  Am_Value_List parts = self.Get(Am_GRAPHICAL_PARTS);
  Am_Value_List others = self.Get(Am_GRAPHICAL_PARTS);

  for (parts.Start(); !parts.Last(); parts.Next()) {
    cell* one = (cell*)(Am_Ptr)((Am_Object)parts.Get()).Get(cellObject);
    others.Start();
    others.Member(one);
    others.Next();
    for (; !others.Last(); others.Next()) {
      cell* another = (cell*)(Am_Ptr)((Am_Object)others.Get()).Get(cellObject);
      int onex = one->x + one->w / 2;
      int oney = one->y + one->h / 2;
      int onew = one->w;
      int oneh = one->h;
      int anox = another->x + another->w / 2;
      int anoy = another->y + another->h / 2;
      int anow = another->w;
      int anoh = another->h;
      int xdiff = anox - onex;
      int ydiff = anoy - oney;
      if (abs(xdiff) < threshold && abs(xdiff) < (onew + anow) / 2)
	one->x = one->x + xdiff;
      if (abs(ydiff) < threshold && abs(ydiff) < (oneh + anoh) / 2)
	one->y = one->y + ydiff;
    }
  }
  return 0;
}


// Arrange and Zoom	----------------------------------------

// some utilitiy functions 

Am_Define_Formula(int, ArrangeLayout)
{
  //  int minspace = self.GV(minimumSpace);
  //  int minsize = self.GV(minimumSize);
  //  int maxpercent = self.GV(maximumPercentage);

  grid* g = new grid(self);
  self.Set(gridObject, (Am_Ptr)g);

  g->calc_intervals();
  g->shrink(PartMoving);
  g->arrange(PartMoving);
  //  g->show();
  return 0;
}

Am_Define_Formula(int, RearrangeLayout)
{
  grid* g = 0;
  if ((grid*)(Am_Ptr)self.Get(gridObject) != 0) {
    g = (grid*)(Am_Ptr)self.Get(gridObject);
  } else {
    ArrangeLayout(cc, self);
    return 0;
  }
  g->update();
  g->calc_intervals();
  g->shrink(PartGrowing);
  g->arrange(PartGrowing);
  return 0;
}

Am_Define_Formula(int, ResizeLayout)
{
  grid* g = 0;
  if ((grid*)(Am_Ptr)self.Get(gridObject) != 0) {
    g = (grid*)(Am_Ptr)self.Get(gridObject);
  } else {
    ArrangeLayout(cc, self);
    return 0;
  }
  g->update();
  g->calc_intervals();
  g->shrink(NoChangeInside);
  g->arrange(NoChangeInside);
  return 0;
}

Am_Define_Formula(int, AlignZoomLayout)
{
  //  cout << "begin AlignZoomLayout on " << self << endl;
  // ACTIVE$B$G$J$$$H$-$O2?$b$7$J$$!#(B
  if ((bool)self.GV(Am_ACTIVE) == false) return 0;


  // detailThreshhold$B0J2<$N;~$OI=<($7$J$$!#(B
  int detailthres = self.GV(detailThreshold);
  if ((int)self.GV(Am_WIDTH) <= detailthres || (int)self.GV(Am_HEIGHT) <= detailthres) {
    self.Set(Am_VISIBLE, false);
    //    cout << "end AlignZoomLayout on " << self << endl;
    return 0;
  }
  self.Set(Am_VISIBLE, true);


  // numberThreshold$B$$$8$g$&$N(Bparts$B$r$b$C$F$$$k$H$-$O$R$g$&$8$7$J$$!#(B
  int nthreshold = self.GV(numberThreshold);
  Am_Value_List parts = self.GV(Am_GRAPHICAL_PARTS);
  int parts_num = 0;
  for (parts.Start(); !parts.Last(); parts.Next()) {
    Am_Object p = parts.Get();
    if (p.GV(Am_VISIBLE)) ++parts_num;
  }
  if (nthreshold < parts_num) { self.Set(Am_VISIBLE, false); return 0; }
  else self.Set(Am_VISIBLE, true);

  // $B5/$3$C$?JQ2=$O2?$+(B?
  int type = CheckChangesForm(cc, self);
  switch(type) {
  case PartMoving:
    AvoidOverlapLayout(cc, self);
    AlignLayout(cc, self);
    ArrangeLayout(cc, self);
    break;
  case PartGrowing:
    RearrangeLayout(cc, self);
    break;
  default:
    ResizeLayout(cc, self);
    break;
  }
  //  Am_Do_Events();
  //  cout << "end AlignZoomLayout on " << self << endl;
  return 0;
}

Am_Define_Formula(int, SequenceAlignZoomLayoutForm)
{
  //  cout << "begin AlignZoomLayout on " << self << endl;
  // ACTIVE$B$G$J$$$H$-$O2?$b$7$J$$!#(B
  if ((bool)self.GV(Am_ACTIVE) == false) return 0;


  // detailThreshhold$B0J2<$N;~$OI=<($7$J$$!#(B
  int detailthres = self.GV(detailThreshold);
  if ((int)self.GV(Am_WIDTH) <= detailthres || (int)self.GV(Am_HEIGHT) <= detailthres) {
    //    self.Set(Am_VISIBLE, false);
    //    cout << "end AlignZoomLayout on " << self << endl;
    //    return 0;
  }
  self.Set(Am_VISIBLE, true);

  // numberThreshold$B$$$8$g$&$N(Bparts$B$r$b$C$F$$$k$H$-$O$R$g$&$8$7$J$$!#(B
  int nthreshold = self.GV(numberThreshold);
  Am_Value_List parts = self.GV(Am_GRAPHICAL_PARTS);
  int parts_num = 0;
  for (parts.Start(); !parts.Last(); parts.Next()) {
    Am_Object p = parts.Get();
    if (p.GV(Am_VISIBLE)) ++parts_num;
  }
  //  if (nthreshold < parts_num) { self.Set(Am_VISIBLE, false); return 0; }
  self.Set(Am_VISIBLE, true);

  // $B5/$3$C$?JQ2=$O2?$+(B?
  int type = CheckChangesForm(cc, self);
  //  AlignSequenceLayout(cc, self);
  switch(type) {
  case PartMoving:
    ArrangeLayout(cc, self);
    break;
  case PartGrowing:
    RearrangeLayout(cc, self);
    break;
  default:
    ResizeLayout(cc, self);
    break;
  }
  //  Am_Do_Events();
  //  cout << "end AlignZoomLayout on " << self << endl;
  return 0;
}


Am_Define_Object_Formula(OwnerForm)
{
  return self.GV_Owner();
}

/*
Am_Define_Method(Am_Object_Method, void, set_run_also,
		 (Am_Object command_obj)) {
  if (command_obj.Get(Am_VALUE).Valid()) {
    command_obj.Get_Owner().Set(Am_RUN_ALSO, false);
  } else {
    command_obj.Get_Owner().Set(Am_RUN_ALSO, true);
  }
}

Am_Define_Method(Am_Object_Method, void, reset_run_also,
		 (Am_Object command_obj)) {
  command_obj.Get_Owner().Set(Am_RUN_ALSO, false);
}

Am_Define_Formula(bool, ForwardNeededForm)
{
  //  cout << self.GV_Part(Am_COMMAND).GV(Am_VALUE) << endl;
  return !self.GV_Part(Am_COMMAND).GV(Am_VALUE).Valid();
}
*/

// ------------------------------------------------------------
// Undo
// ------------------------------------------------------------

void add_history(Am_Object target)
{
  if (target.Get_Slot_Type(lastPointer) == Am_NONE) return;

  Am_Object group = target.Get_Owner();
  Am_Inter_Location last_p = target.Get(lastPointer);
  Am_Inter_Location undo_p = target.Get(undoPointer);
  cell* c = (cell*)(Am_Ptr)target.Get(cellObject);
  Am_Inter_Location new_loc = Am_Inter_Location(false, group, 0, 0, c->origW, c->origH);

  target.Make_Unique(sizeHistory);
  Am_Value_List history = target.Get(sizeHistory);
  if (undo_p != last_p) {
    history.Start();
    history.Member(undo_p);
    history.Next();
    while (!history.Last()) {
      history.Delete(false);
      history.Next();
    }
  }
  history.Add(new_loc, Am_TAIL, false);
  target.Set(lastPointer, new_loc)
        .Set(undoPointer, new_loc);
  target.Note_Changed(sizeHistory);
}

Am_Define_Method(Am_Object_Method, void, record_size_history, (Am_Object command_obj))
{
  Am_Do_Events();
  // Am_Object target = command_obj.Get_Owner().Get(Am_OBJECT_MODIFIED);
  // add_history(target);
  Am_Value_List objs = command_obj.Get_Owner().Get_Owner().Get(Am_VALUE);
  for (objs.Start(); !objs.Last(); objs.Next()) {
    Am_Object target = objs.Get();
    add_history(target);

    Am_Object group = target.Get_Owner();
    if (!group.Valid()) break;
    while (group.Get_Slot_Type(propagateParent)) {
      Am_Object parent = group.Get(propagateParent);
      if (parent.Get_Slot_Type(grown)) {
	if (parent.Get(grown) == true) {
	  parent.Set(grown, false);
	  add_history(parent);
	  group = parent.Get_Owner();
	  continue;
	}
      }
      break;
    }
  }
}

Am_Define_Method(Am_Object_Method, void, grow_all_selected_objs, (Am_Object command_obj))
{
  Am_Object target = command_obj.Get_Owner().Get(Am_OBJECT_MODIFIED);
  int width = target.Get(Am_WIDTH);
  int height = target.Get(Am_HEIGHT);

  //  Am_Inter_Location old_loc = command_obj.Get_Owner().Get(Am_OLD_VALUE);
  //  int x, y, w, h;
  //  old_loc.Get_Points(x, y, w, h);

  //  int wdiff = width - w;
  //  int hdiff = height - h;

  Am_Value_List objs = command_obj.Get_Owner().Get_Owner().Get(Am_VALUE);
  for (objs.Start(); !objs.Last(); objs.Next()) {
    Am_Object obj = objs.Get();
    obj.Set(Am_WIDTH, width);
    obj.Set(Am_HEIGHT, height);
    //    obj.Set(Am_WIDTH, (int)obj.Get(Am_WIDTH) + wdiff);
    //    obj.Set(Am_HEIGHT, (int)obj.Get(Am_HEIGHT) + hdiff);
  }
}

// command objects for popup menu item

void animate_obj(Am_Object target, Am_Object group, Am_Inter_Location loc)
{
  int x, y, w, h;
  loc.Get_Points(x, y, w, h);
  
  for (int i = 0; i < 4; ++i) {
    int startw = target.Get(Am_WIDTH);
    int starth = target.Get(Am_HEIGHT);

    int xscale = group.Get(xScaleFactor);
    int yscale = group.Get(yScaleFactor);

    int endw = w * xscale / denom;
    int endh = h * yscale / denom;

    int diffw = (endw - startw) / (5 - i);
    int diffh = (endh - starth) / (5 - i);

    target.Set(Am_WIDTH, startw + diffw).Set(Am_HEIGHT, starth + diffh);
    Am_Do_Events();
  }
  int xscale = group.Get(xScaleFactor);
  int yscale = group.Get(yScaleFactor);
  int endw = w * xscale / denom;
  int endh = h * yscale / denom;

  target
    .Set(Am_WIDTH, endw)
    .Set(Am_HEIGHT, endh)
    ;
}

Am_Define_Method(Am_Object_Method, void, Undo_Zoom_Method, (Am_Object command_obj))
{
  Am_Object menu = command_obj.Get_Owner().Get_Owner(); // $B%a%K%e!<(B
  Am_Object target = menu.Get(TargetObj); // undo$B$9$k?^7A(B
  Am_Object group = target.Get_Owner();

  if (target.Get_Slot_Type(lastPointer) == Am_NONE) return;

  Am_Value_List history = target.Get(sizeHistory);
  Am_Inter_Location undo_p = target.Get(undoPointer);

  history.Start();
  if ((Am_Inter_Location)history.Get() == undo_p) return;
  
  history.Start();
  history.Member(undo_p);
  history.Prev();
  Am_Inter_Location loc = history.Get();
  
  animate_obj(target, group, loc);
  target.Set(undoPointer, loc);

  cout << "Undo_Zoom_Method " << target << endl;
}

Am_Define_Method(Am_Object_Method, void, Redo_Zoom_Method, (Am_Object command_obj))
{
  Am_Object menu = command_obj.Get_Owner().Get_Owner(); // $B%a%K%e!<(B
  Am_Object target = menu.Get(TargetObj); // undo$B$9$k?^7A(B
  Am_Object group = target.Get_Owner();

  if (target.Get_Slot_Type(lastPointer) == Am_NONE) return;

  Am_Value_List history = target.Get(sizeHistory);
  Am_Inter_Location last_p = target.Get(lastPointer);
  Am_Inter_Location undo_p = target.Get(undoPointer);

  if (last_p == undo_p) return;

  history.Start();
  history.Member(undo_p);
  history.Next();
  Am_Inter_Location loc = history.Get();
  
  animate_obj(target, group, loc);
  target.Set(undoPointer, loc);
  cout << "Redo_Zoom_Method " << target << endl;
}

Am_Define_Method(Am_Object_Method, void, Zoom_Menu_Method, (Am_Object command_obj))
{
  Am_Object target = command_obj.Get(TargetObj);
  if (target.Get_Slot_Type(lastPointer) == Am_NONE) return;

  Am_Object group = target.Get_Owner();
  Am_Inter_Location loc = command_obj.Get(undoPointer);

  animate_obj(target, group, loc);
  target.Set(undoPointer, loc);
  cout << "Zoom_Menu_Method " << target << endl;
}

Am_Define_Method(Am_Object_Method, void, Selective_Undo_Zoom_Method, (Am_Object command_obj))
{
  Am_Object menu = command_obj.Get_Owner().Get_Owner(); // $B%a%K%e!<(B
  Am_Object target = menu.Get(TargetObj); // $BDI2C@h(B
  Am_Object window = menu.Get_Owner();

  if (target.Get_Slot_Type(lastPointer) == Am_NONE) return;

  Am_Finish_Pop_Up_Waiting(window, Am_No_Value);

  //  int orig_w = target.Get(Am_WIDTH);
  //  int orig_h = target.Get(Am_HEIGHT);
  Am_Inter_Location undo_p = target.Get(undoPointer);

  char name[100];
  ostrstream oname(name, 100);

  Am_Value_List items = Am_Value_List();
  Am_Value_List history = target.Get(sizeHistory);
  for (history.End(); !history.First(); history.Prev()) {
    Am_Inter_Location loc = history.Get();
    int x, y, w, h;
    loc.Get_Points(x, y, w, h);
    oname.seekp(0, ios::beg);

    oname << w << ", " << h;
    if (loc == undo_p) oname << "* ";
    oname << '\0';
    items.Add(ZoomMenuCmd.Create()
	      .Set(Am_LABEL, name)
	      .Set(undoPointer, loc)
	      .Set(TargetObj, target));
  }

  Am_Object size_selection_menu = Am_Menu.Create()
    .Set(Am_WIDTH, 100)
    .Set(Am_ITEMS, items)
    ;

  ZoomUndoDialog.Get_Part(Am_DIALOG_GROUP)
    .Get_Part(Am_ITEMS)
      .Remove_Part(Am_ITEMS);

  ZoomUndoDialog
    .Set(Am_LEFT, window.Get(Am_LEFT))
    .Set(Am_TOP, window.Get(Am_TOP))
    .Get_Part(Am_DIALOG_GROUP)
      .Get_Part(Am_ITEMS)
        .Add_Part(Am_ITEMS, size_selection_menu)
    ;

  Am_String result = Am_Show_Dialog_And_Wait(ZoomUndoDialog, true);
  if (result == "OK") {
    Am_Inter_Location new_undo_p = (Am_Inter_Location)target.Get(undoPointer);
    if (new_undo_p != undo_p) {
//       target.Set(undoPointer, target.Get(lastPointer));
//       add_history(target);
      int x, y, w, h;
      new_undo_p.Get_Points(x, y, w, h);
      Am_Inter_Location new_loc = Am_Inter_Location(false, target.Get_Owner(), 0, 0, w, h);
      Am_Value_List history = target.Get(sizeHistory);
      history.Add(new_loc, Am_TAIL, false);
      target.Set(lastPointer, new_loc)
	.Set(undoPointer, new_loc);
      target.Note_Changed(sizeHistory);
    }
  } else {
    animate_obj(target, target.Get_Owner(), undo_p);
    target.Set(undoPointer, undo_p);
  }
  cout << "Selective_Undo_Zoom_Method " << target << endl;
}

Am_Define_Formula(bool, UndoActiveForm)
{
  Am_Object menu_item = self.GV_Owner();  if (!menu_item.Valid()) return false;
  Am_Object menu = menu_item.GV_Owner();  if (!menu.Valid()) return false;
  Am_Object target = menu.GV(TargetObj); // undo$B$9$k?^7A(B

  if (target.Get_Slot_Type(sizeHistory) == Am_NONE) return false;
  Am_Value_List history = target.GV(sizeHistory);
  Am_Inter_Location undo_p = target.GV(undoPointer);
  if (history.Empty()) return false;

  history.Start();
  if ((Am_Inter_Location)history.Get() == undo_p) return false;
  return true;
}

Am_Define_Formula(bool, RedoActiveForm)
{
  Am_Object menu_item = self.GV_Owner();  if (!menu_item.Valid()) return false;
  Am_Object menu = menu_item.GV_Owner();  if (!menu.Valid()) return false;
  Am_Object target = menu.GV(TargetObj); // undo$B$9$k?^7A(B

  if (target.Get_Slot_Type(sizeHistory) == Am_NONE) return false;
  Am_Value_List history = target.GV(sizeHistory);
  Am_Inter_Location last_p = target.GV(lastPointer);
  Am_Inter_Location undo_p = target.GV(undoPointer);

  if (last_p == undo_p) return false;
  return true;
}

Am_Define_Formula(bool, SelectiveUndoActiveForm)
{
  Am_Object menu_item = self.GV_Owner();  if (!menu_item.Valid()) return false;
  Am_Object menu = menu_item.GV_Owner();  if (!menu.Valid()) return false;
  Am_Object target = menu.GV(TargetObj); // undo$B$9$k?^7A(B

  if (target.Get_Slot_Type(sizeHistory) == Am_NONE) return false;
  Am_Value_List history = target.GV(sizeHistory);
  if (history.Length() < 2) return false;
  return true;
}

void initUndo(void)
{
  UndoZoomCmd = MenuCommand.Create()
    .Set(Am_LABEL, "Undo Zooming")
    .Set(Am_ACTIVE, UndoActiveForm)
    .Set(Am_DO_METHOD, Undo_Zoom_Method);

  RedoZoomCmd = MenuCommand.Create()
    .Set(Am_LABEL, "Redo Zooming")
    .Set(Am_ACTIVE, RedoActiveForm)
    .Set(Am_DO_METHOD, Redo_Zoom_Method);

  SelectiveUndoZoomCmd = MenuCommand.Create()
    .Set(Am_LABEL, "Selective Undo Zooming...")
    .Set(Am_ACTIVE, SelectiveUndoActiveForm)
    .Set(Am_DO_METHOD, Selective_Undo_Zoom_Method);

  ZoomMenuCmd = Am_Command.Create()
    .Set(Am_DO_METHOD, Zoom_Menu_Method);

  Am_Object size_selection_group = Am_Scrolling_Group.Create()
    .Set(Am_WIDTH, 100)
    .Set(Am_HEIGHT, 200)
    .Set(Am_H_SCROLL_BAR, false)
    ;

  ZoomUndoDialog = Am_Choice_Dialog.Create()
    .Set(Am_TITLE, "Selective Undo Zooming")
    .Set(Am_ICON_TITLE, "Selective Undo Zooming")
    .Get_Part(Am_DIALOG_GROUP)
      .Add_Part(Am_ITEMS, size_selection_group)
      .Get_Part(Am_DIALOG_BUTTONS)
        .Set(Am_H_SPACING, 5)
      .Get_Owner()
    .Get_Owner()
    ;
  //  Am_To_Bottom(size_selection_group);
}

// Customized Stop Method for grow_inter in the selection widget

Am_Object move_grow_set_impl_command(Am_Object inter,
				     Am_Object object_modified,
				     Am_Inter_Location data);

Am_Inter_Location my_move_grow_interim_val(Am_Object inter,
					   Am_Object /* command_obj */, Am_Object /* object_to_move */,
					   int /* x */, int /* y */, Am_Object /* ref_obj */, Am_Input_Char /* ic */) {
  Am_Inter_Location data (inter.Get(Am_INTERIM_VALUE));
  //don't need Make_Unique on Am_INTERIM_VALUE because will have called
  //Am_Copy_Data_Into_Slot during initialize which does it.
  //  Am_Get_Filtered_Input(inter, x, y, x, y); // set x,y based on gridding
  //  calc_all (inter, object_to_move, x, y, ref_obj, data);
  //  inter.Note_Changed (Am_INTERIM_VALUE);
  //Am_Inter_Call_Both_Method(inter, command_obj, Am_INTERIM_DO_METHOD, x, y,
  //ref_obj, ic, object_to_move, data);
  return data;
}



Am_Define_Method(Am_Inter_Internal_Method, void, my_Am_Move_Grow_Stop_Method,
		 (Am_Object& inter, Am_Object& /* object */,
		  Am_Object& event_window, Am_Input_Event *ev)) {
  int x = ev->x;
  int y = ev->y;
  // ignore object parameter, used saved object
  Am_Object object;
  object = inter.Get(Am_START_OBJECT);
  Am_INTER_TRACE_PRINT(inter, "Move_Grow stopping over " << object);
  //now, call interim_do on last point
  Am_Input_Char ic = ev->input_char;
  Am_Object command_obj;
  command_obj = inter.Get_Part(Am_COMMAND);
  Am_Inter_Location data = my_move_grow_interim_val(inter, command_obj, object,
						 x, y, event_window, ic);
  
  // call DO method
  //data is points calculated by move_grow_interim_val
  Am_Call_Final_Do_And_Register(inter, command_obj, x, y, event_window, ic,
				object, data, move_grow_set_impl_command);
  //  Am_Register_For_Undo(inter, command_obj, object, data, move_grow_set_impl_command);

  // LAST, call the prototype's method
  Am_Inter_Internal_Method inter_method;
  inter_method = Am_Interactor.Get(Am_INTER_STOP_METHOD);
  inter_method.Call(inter, object, event_window, ev);
}

void Am_Check_And_Fix_Owner_For_Object(Am_Object &obj, Am_Inter_Location &data);
void Am_Copy_Data_Into_Slot(Am_Object dest_obj, Am_Slot_Key dest_slot, Am_Inter_Location src_data);
bool Am_Check_Final_Point_In_Multi(Am_Object inter);

Am_Define_Method(Am_Current_Location_Method, void, my_Am_Move_Grow_Do,
		 (Am_Object inter, Am_Object object_modified,
		  Am_Inter_Location data)) {
  Am_Object feedback;
  Am_Object inter_window = inter.Get(Am_WINDOW);
  feedback = inter.Get(Am_FEEDBACK_OBJECT);
  bool growing = inter.Get(Am_GROWING);
  if (feedback.Valid ()) {
    Am_REPORT_VIS_CONDITION(Am_INTER_TRACE_SETTING, inter, feedback, false);
    feedback.Set(Am_VISIBLE, false);
    if (feedback.Is_Instance_Of(Am_Window)) {
      Am_Add_Remove_Inter_To_Extra_Window(inter, feedback, false, false);
      //special test to see if need to figure out new window for the object
      inter_window =
	Am_Check_And_Fix_Point_In_Feedback_Window(inter_window, feedback);
      if (!inter_window.Valid()) { //release outside all windows
	Am_INTER_TRACE_PRINT(inter, "Aborting " << inter <<
			     " because stopped outside all windows");
	if ((bool)inter.Get(Am_INTER_BEEP_ON_ABORT))
	  Am_Beep();
	Am_Abort_Interactor(inter);
	return;
      }
    }
  }
  //if multi-window, abort if final point is outside of the windows
  // ** Is this always what is desired? **
  if (!Am_Check_Final_Point_In_Multi(inter)) {
	Am_INTER_TRACE_PRINT(inter, "Aborting " << inter <<
		      " because stopped outside windows in Am_MULTI_OWNERS");
	if ((bool)inter.Get(Am_INTER_BEEP_ON_ABORT))
	  Am_Beep();
	Am_Abort_Interactor(inter);
	return;
      }
  if (object_modified.Valid ()) {
    if (!growing) {
      //see if need to move the real object
      if (!Am_Check_And_Fix_Object_Window(object_modified,inter,inter_window))
	return;
    }
    // Am_Modify_Object_Pos(object_modified, data, growing, inter);
  }
    
  //set VALUE of inter with final location
  Am_Copy_Data_Into_Slot(inter, Am_VALUE, data);
  inter.Set(Am_OBJECT_MODIFIED, object_modified);
  Am_Copy_Values_To_Command(inter);
}


Am_Define_Formula(bool, UndoArrowGroupVisibleForm)
{
  Am_Object owner = self.GV_Owner();  if (!owner.Valid()) return false;
  Am_Value_List selection = owner.GV(Am_VALUE);

  if (selection.Empty()) return false;
  selection.End();
  Am_Object last_selected = selection.Get();
  int x = last_selected.GV(Am_LEFT);
  int y = last_selected.GV(Am_TOP);
  int w = last_selected.GV(Am_WIDTH);
  int h = last_selected.GV(Am_HEIGHT);

  Am_Translate_Coordinates(last_selected.Get_Owner(), x, y, owner, x, y);

  self.Set(Am_LEFT, x + (w / 2) - 35)
      .Set(Am_TOP, y + (h / 2) - 15)
    ;
  return true;
}

void initAlignZoomGroup(void)
{
  AlignZoomGroup = Am_Group.Create("AlignZoomGroup")
    .Set(gridObject, 0)
    .Set(seqDir, 0)
    .Set(partMoved, false)
    .Set(Am_ACTIVE, true)
    .Set(alignThreshold, 20)
    .Set(minimumSpace, 5)
    .Set(minimumSize, 10)
    .Set(maximumPercentage, 90)
    .Set(detailThreshold, 30)
    .Set(numberThreshold, number_threshold)
    .Set(allowGrowing, false)
    .Set(isShrunken, IsShurunkenForm)
    .Set(propagateParent, 0)
    .Set(xScaleFactor, denom)
    .Set(yScaleFactor, denom)
    .Set(origWidth, 0)
    .Set(origHeight, 0)

    .Set(Am_WIDTH, 50)
    .Set(Am_HEIGHT, 50)
    .Set(Am_LAYOUT, AlignZoomLayout)
    ;


  Am_Object_Advanced azg_adv = (Am_Object_Advanced&)AlignZoomGroup;
  Am_Demon_Set azg_demon_set(azg_adv.Get_Demons().Copy());
  azg_demon_set.Set_Object_Demon(Am_CREATE_OBJ, alignzoom_create_demon);
  azg_demon_set.Set_Object_Demon(Am_COPY_OBJ, alignzoom_copy_demon);
  azg_demon_set.Set_Part_Demon(Am_ADD_PART, alignzoom_part_demon);
  azg_adv.Set_Demons(azg_demon_set);

  SequenceAlignZoomGroup = AlignZoomGroup.Create("SequenceAlignZoomGroup")
    .Set(Am_LAYOUT, SequenceAlignZoomLayoutForm)
    ;
  
  /*
  Am_Object UndoArrowGroup = Am_Group.Create("UndoArrowGroup")
    .Set(Am_WIDTH, 70)
    .Set(Am_HEIGHT, 30)
    .Set(Am_VISIBLE, UndoArrowGroupVisibleForm)
    .Add_Part(Am_Arrow2.Create("UndoArrow")
	      .Set(Am_X1, 30)
	      .Set(Am_Y1, 15)
	      .Set(Am_X2, 0)
	      .Set(Am_Y2, 15)
	      .Set(Am_ARROW_H_WIDTH, 30)
	      .Set(Am_ARROW_H_HEIGHT, 15)
	      .Set(Am_ARROW_WIDTH, 15)
 	      .Set(Am_LINE_STYLE, Am_Style(0, 0, 0, 1, Am_CAP_BUTT, Am_JOIN_MITER,
 					   Am_LINE_SOLID, Am_DEFAULT_DASH_LIST,
 					   Am_DEFAULT_DASH_LIST_LENGTH,
 					   Am_FILL_STIPPLED, Am_FILL_POLY_EVEN_ODD,
 					   Am_Image_Array(50)))
	      .Set(Am_FILL_STYLE, Am_Style(0, 1, 0, 10, Am_CAP_BUTT, Am_JOIN_MITER,
					   Am_LINE_SOLID, Am_DEFAULT_DASH_LIST,
					   Am_DEFAULT_DASH_LIST_LENGTH,
					   Am_FILL_STIPPLED, Am_FILL_POLY_EVEN_ODD,
					   Am_Image_Array(30)))
	      )
    .Add_Part(Am_Arrow2.Create("RedoArrow")
	      .Set(Am_X1, 40)
	      .Set(Am_Y1, 15)
	      .Set(Am_X2, 70)
	      .Set(Am_Y2, 15)
	      .Set(Am_ARROW_H_WIDTH, 30)
	      .Set(Am_ARROW_H_HEIGHT, 15)
	      .Set(Am_ARROW_WIDTH, 15)
 	      .Set(Am_LINE_STYLE, Am_Style(0, 0, 0, 1, Am_CAP_BUTT, Am_JOIN_MITER,
 					   Am_LINE_SOLID, Am_DEFAULT_DASH_LIST,
 					   Am_DEFAULT_DASH_LIST_LENGTH,
 					   Am_FILL_STIPPLED, Am_FILL_POLY_EVEN_ODD,
 					   Am_Image_Array(50)))
	      .Set(Am_FILL_STYLE, Am_Style(0, 1, 0, 10, Am_CAP_BUTT, Am_JOIN_MITER,
					   Am_LINE_SOLID, Am_DEFAULT_DASH_LIST,
					   Am_DEFAULT_DASH_LIST_LENGTH,
					   Am_FILL_STIPPLED, Am_FILL_POLY_EVEN_ODD,
					   Am_Image_Array(50)))
	      )
    ;
    */
    
  AlignZoomSelectionWidget = Am_Selection_Widget.Create()
    .Set(Am_OPERATES_ON, OwnerForm)
    .Get_Part(Am_INTERACTOR)
    //.Set(Am_RUN_ALSO, false)
    //      .Set(Am_RUN_ALSO, ForwardNeededForm)
    //      .Get_Part(Am_COMMAND)
    //        .Set(Am_START_DO_METHOD, set_run_also)
    //        .Set(Am_DO_METHOD, reset_run_also)
    //      .Get_Owner()
    .Get_Owner()
    .Get_Part(Am_GROW_INTERACTOR)
      .Set(Am_FEEDBACK_OBJECT, NULL)
      .Set(Am_MINIMUM_WIDTH, 10)
      .Set(Am_MINIMUM_HEIGHT, 10)
      .Set(Am_INTER_STOP_METHOD, my_Am_Move_Grow_Stop_Method)
      .Set(Am_DO_METHOD, my_Am_Move_Grow_Do)
      .Get_Part(Am_COMMAND)
        .Set(Am_INTERIM_DO_METHOD, grow_all_selected_objs)
        .Set(Am_DO_METHOD, record_size_history)
      .Get_Owner()
    .Get_Owner()
    .Get_Part(Am_MOVE_INTERACTOR)
      .Set(Am_PRIORITY, 2)
    //  .Set(Am_RUN_ALSO, true)
    //  .Set(Am_FEEDBACK_OBJECT, NULL)
    .Get_Owner()
    //    .Add_Part(UndoArrowGroup)
    ;
  Am_Object move_inter = AlignZoomSelectionWidget.Get_Part(Am_MOVE_INTERACTOR);
  AlignZoomSelectionWidget.Remove_Part(Am_MOVE_INTERACTOR);
  AlignZoomSelectionWidget.Add_Part(Am_MOVE_INTERACTOR, move_inter);

}

// ------------------------------------------------------------
// Zooming Text
// ------------------------------------------------------------

#define NofFontSizes	8
#define FontSizes	{60, 46, 34, 24, 18, 12, 10, 8}

Am_Font FontTable[NofFontFamilies][2][2][NofFontSizes];

Am_Object ZoomingText = 0;
// public
DEFINE_SLOT(TextPart);
DEFINE_SLOT(FontFamily);
DEFINE_SLOT(FontIsBold);
DEFINE_SLOT(FontIsItalic);
DEFINE_SLOT(FontIsUnderline);


char* make_font_name(int family, bool is_bold, bool is_italic, int size)
{
  char* wild_font_name = new char[50];  // Given hard-coded defaults, max length is 50
  char *family_part, *face_part;

  switch(family) {
  case FontFixed:      family_part = "courier"; break;
  case FontSerif:      family_part = "times"; break;
  case FontSansSerif:  family_part = "helvetica"; break;
  }
  
  if((is_bold == false) && (is_italic == false))
    face_part = "medium-r";
  else if ((is_bold == true) && (is_italic == false))
    face_part = "bold-r";
  else if ((is_bold == false) && (is_italic == true)) {
    if (family == Am_FONT_SERIF) face_part = "medium-i";
    else face_part = "medium-o";
  }
  else if ((is_bold == true) && (is_italic == true)) {
    if (family == Am_FONT_SERIF) face_part = "bold-i";
    else face_part = "bold-o";
  }
  // Guide to fonts.dir format (try xfontsel on an HP):
  // -fndry-fmly-weight-slant-sWidth-adstyl-pixelsize-pointsize-...
  // ...resx-resy-spc-avgWdth-registry-encoding
  sprintf(wild_font_name, "-*-%s-%s-*-*-%i-*-*-*-*-*-*-*", family_part, face_part, size);

  return wild_font_name;
}

Am_Define_Formula(int, ResizeTextForm) {
  const int sizeList[NofFontSizes] = FontSizes;

  int  family       = self.GV(FontFamily);
  bool is_bold      = self.GV(FontIsBold);
  bool is_italic    = self.GV(FontIsItalic);
  //  bool is_underline = self.GV(FontIsUnderline);

  Am_Font* fontList = FontTable[family][is_bold][is_italic];
  if ((void *)fontList[0] == (void *)0) {
    for (int i = 0; i < NofFontSizes; ++i) {
      fontList[i] = Am_Font(make_font_name(family, is_bold, is_italic, sizeList[i]));
    }
  }

  int w = self.GV(Am_WIDTH);
  int h = self.GV(Am_HEIGHT);
  Am_Object textObj = self.Get_Part(TextPart);

  for (int i = 0; i < NofFontSizes; ++i) {
    textObj.Set(Am_FONT, fontList[i]);
    int tw = textObj.GV(Am_WIDTH);
    int th = textObj.GV(Am_HEIGHT);

    if (tw <= w && th <= h) return 0;
  }
  return 0;
}

void initZoomingText(void)
{
  Am_Object textObj = Am_Text.Create("ZoomingTextPart")
    .Set_Single_Constraint_Mode(Am_TEXT, false);

  ZoomingText = Am_Group.Create("ZoomingText")
    .Set(FontFamily, FontFixed)
    .Set(FontIsBold, false)
    .Set(FontIsItalic, false)
    .Set(FontIsUnderline, false)
    .Set(Am_LAYOUT, ResizeTextForm)
    .Add_Part(TextPart, textObj
	      .Set(Am_TEXT, "")
	      .Set(Am_LEFT, Am_Center_X_Is_Center_Of_Owner)
	      .Set(Am_TOP,  Am_Center_Y_Is_Center_Of_Owner))
    ;
}

// ------------------------------------------------------------
// Initialize all widgets
// ------------------------------------------------------------
void Initialize_Zooming_Widgets(void) {
  bzero (FontTable, sizeof(FontTable));
  initAlignZoomGroup();
  initUndo();
  initZoomingText();
}
