
/*  A Bison parser, made from kl.rie with Bison version GNU Bison version 1.24
  */

#define YYBISON 1  /* Identify Bison output.  */

#define	Imply	258
#define	Assign	259
#define	Mod	260
#define	Land	261
#define	Lor	262
#define	Integer	263
#define	Symbol	264
#define	Variable	265
#define	String	266
#define	Opt_define	267
#define	Opt_port	268
#define	Opt_size	269
#define	Opt_point	270
#define	Opt_type	271
#define	Opt_guard	272
#define	Opt_rule	273
#define	Opt_rule_id	274
#define	Opt_mesg	275
#define	Opt_atom	276
#define	Opt_merge	277
#define	Opt_from	278
#define	Opt_into	279
#define	Opt_link	280
#define	Opt_unify	281
#define	Opt_assign	282
#define	Opt_list	283
#define	Opt_proc	284
#define	Opt_begin	285
#define	Opt_proc_part	286
#define	Opt_other_part	287
#define	Opt_end	288
#define	Opt_comment	289
#define	Opt_creator	290
#define	Opt_normal	291
#define	Opt_network	292
#define	Opt_vanishing	293
#define	Opt_continuous	294
#define	Opt_transition	295
#define	Opt_stream	296
#define	Opt_single	297
#define	Opt_left	298
#define	Opt_right	299
#define	Opt_arrange	300
#define	Opt_rightward	301
#define	Opt_downward	302
#define	Opt_SYMBOL	303
#define	Opt_VARIABLE	304

#line 1 "kl.rie"
// -*- C++ -*-
  // Copyright (C) 1996,1997 Buntarou Shizuki(shizuki@is.titech.ac.jp)
#include "parse.h"

static char *current_module = NULL;

#ifndef YYLTYPE
typedef
  struct yyltype
    {
      int timestamp;
      int first_line;
      int first_column;
      int last_line;
      int last_column;
      char *text;
   }
  yyltype;

#define YYLTYPE yyltype
#endif

#ifndef YYSTYPE
#define YYSTYPE int
#endif
#include <stdio.h>

#ifndef __cplusplus
#ifndef __STDC__
#define const
#endif
#endif

typedef
  union
    {
      struct {
	char	state;
      } rrtr_sub_state;

      struct {
	RSUBGTYPE	g;
      } rrtr_subgoal, rrtr_subgoals;

      struct {
	RSUBGTYPE	sg;
      } rrtr_subgoal_part;

      struct {
	RCONSTYPE	tt;
	RCONSTYPE	th;
      } rrtr_list_elements, rrtr_list_contents;

      struct {
	int	num;
	RTERMTYPE	ts;
      } rrtr_args, rrtr_arg, rrtr_argument;

      struct {
	int	arity;
	NAMETYPE	name;
	NAMETYPE	module;
	RTERMTYPE	t;
      } rrtr_head, rrtr_list, rrtr_functor, rrtr_term;

      struct {
	ActType	act;
      } rrtr_action;

      struct {
	SUBPROCTYPE	sps;
	PORTTYPE	ps;
	int	num;
      } rrt_merge, rrt_assign, rrt_unify, rrt_structure, rrt_vector_elements
      , rrt_vector_contents, rrt_vector, rrt_list_elements, rrt_list_contents, rrt_list
      , rrt_arg, rrt_term_info, rrt_term_body, rrt_term, rrt_args
      , rrt_argument, rrargs, rrargument;

      struct {
	SUBPROCTYPE	sps;
	PORTTYPE	ps;
	int	arity;
	NAMETYPE	name;
	NAMETYPE	module;
      } rrt_functor, rrsubproc_info;

      struct {
	SUBPROCTYPE	sp;
      } rrsubproc;

      struct {
	int	arity;
	NAMETYPE	name;
      } rrfunctor, rrhead;

      struct {
	RuleType	rt;
      } rrrule_type;

      struct {
	RULETYPE	rule;
      } rrruledef;

      struct {
	ExpandMethod	arrange;
      } rrarrange_info;

      struct {
	int	h;
	int	w;
	int	t;
	int	l;
	int	lr;
	PortType	type;
	int	id;
	NAMETYPE	name;
      } rrtr_goalid, rrleft_or_right, rrport_type, rrport_info, rrpoint_size
      , rrproc_type;

      struct {
	PROCTYPE	proc;
      } rrprocdef, rrprocess;

      struct {
	NAMETYPE	str;
      } rrString;

      struct {
	NAMETYPE	name;
	NAMETYPE	module;
      } rrOpt_VARIABLE, rrOpt_SYMBOL, rrVariable, rrSymbol;

      struct {
	int	value;
      } rrInteger;

    }
  rrsastype;

typedef
  struct
    {
      PROCTYPE	EC0;
      PROCTYPE	EC1;
      PROCTYPE	EC2;
      PROCTYPE	EC3;
      PROCTYPE	EC4;
      RULETYPE	EC5;
      RULETYPE	EC6;
      PROCTYPE	EC7;
      RULETYPE	EC8;
      RULETYPE	EC9;
      RULETYPE	EC10;
      RULETYPE	EC11;
      RULETYPE	EC12;
      RULETYPE	EC13;
      RULETYPE	EC14;
      RULETYPE	EC15;
      RULETYPE	EC16;
      RULETYPE	EC17;
      RULETYPE	EC18;
      RULETYPE	EC19;
      RULETYPE	EC20;
      RULETYPE	EC21;
      RULETYPE	EC22;
      SUBPROCTYPE	EC23;
      CONTEXTTYPE	EC24;
      RULETYPE	EC25;
      RULETYPE	EC26;
      RULETYPE	EC27;
      SUBPROCTYPE	EC28;
      PORTTYPE	EC29;
      int	EC30;
      RULETYPE	EC31;
      SUBPROCTYPE	EC32;
      PORTTYPE	EC33;
      int	EC34;
      RULETYPE	EC35;
      SUBPROCTYPE	EC36;
      PORTTYPE	EC37;
      int	EC38;
      RULETYPE	EC39;
      SUBPROCTYPE	EC40;
      PORTTYPE	EC41;
      int	EC42;
      RULETYPE	EC43;
      SUBPROCTYPE	EC44;
      PORTTYPE	EC45;
      int	EC46;
      RULETYPE	EC47;
      SUBPROCTYPE	EC48;
      PORTTYPE	EC49;
      int	EC50;
      RULETYPE	EC51;
      SUBPROCTYPE	EC52;
      PORTTYPE	EC53;
      int	EC54;
      RULETYPE	EC55;
      SUBPROCTYPE	EC56;
      PORTTYPE	EC57;
      int	EC58;
      RULETYPE	EC59;
      SUBPROCTYPE	EC60;
      PORTTYPE	EC61;
      int	EC62;
      RULETYPE	EC63;
      SUBPROCTYPE	EC64;
      PORTTYPE	EC65;
      int	EC66;
      RULETYPE	EC67;
      SUBPROCTYPE	EC68;
      PORTTYPE	EC69;
      int	EC70;
      RULETYPE	EC71;
      SUBPROCTYPE	EC72;
      PORTTYPE	EC73;
      int	EC74;
      RULETYPE	EC75;
      SUBPROCTYPE	EC76;
      PORTTYPE	EC77;
      int	EC78;
      RULETYPE	EC79;
      SUBPROCTYPE	EC80;
      PORTTYPE	EC81;
      int	EC82;
      RULETYPE	EC83;
      SUBPROCTYPE	EC84;
      PORTTYPE	EC85;
      int	EC86;
      RULETYPE	EC87;
      SUBPROCTYPE	EC88;
      PORTTYPE	EC89;
      int	EC90;
      RULETYPE	EC91;
      SUBPROCTYPE	EC92;
      PORTTYPE	EC93;
      int	EC94;
      RULETYPE	EC95;
      int	EC96;
      RULETYPE	EC97;
      int	EC98;
      RULETYPE	EC99;
      RTERMTYPE	EC100;
      RTERMTYPE	EC101;
      RTERMTYPE	EC102;
      NAMETYPE	EC103;
      NAMETYPE	EC104;
      NAMETYPE	EC105;
    }
  rriastype;

typedef
  struct rrlastype
    {
      union
	{
	  SUBPROCTYPE	sp_58;
	} C0;

      union
	{
	  PORTTYPE	port_117;
	} C1;

      union
	{
	  RCONSTYPE	cell_189;
	} C2;

      union
	{
	  RCONSTYPE	cell_190;
	} C3;

    }
  rrlastype;

#ifndef RIE_SOME_SYNTHESIZE
#define RIE_SOME_SYNTHESIZE
#endif

#ifndef RIE_SOME_INHERIT
#define RIE_SOME_INHERIT
#endif

#ifndef RIE_SOME_LOCAL
#define RIE_SOME_LOCAL
#endif



#define	YYFINAL		351
#define	YYFLAG		-32768
#define	YYNTBASE	71

#define YYTRANSLATE(x) ((unsigned)(x) <= 304 ? yytranslate[x] : 170)

static const char yytranslate[] = {     0,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,    70,     2,     2,     2,     2,     2,     2,    53,
    54,    67,    65,    52,    66,    50,    68,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,    57,     2,    59,
    55,    56,    69,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
    61,    58,    62,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,    63,    51,    64,    60,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     1,     2,     3,     4,     5,
     6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
    16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
    26,    27,    28,    29,    30,    31,    32,    33,    34,    35,
    36,    37,    38,    39,    40,    41,    42,    43,    44,    45,
    46,    47,    48,    49
};

#if YYDEBUG != 0
static const short yyprhs[] = {     0,
     0,     2,     4,     6,     9,    11,    13,    17,    20,    27,
    33,    34,    37,    40,    41,    43,    45,    47,    48,    51,
    57,    63,    65,    68,    74,    78,    80,    82,    84,    86,
    87,    90,    92,    94,    95,   100,   102,   104,   108,   112,
   113,   116,   118,   122,   128,   131,   132,   136,   139,   140,
   144,   146,   148,   150,   154,   157,   164,   168,   173,   174,
   176,   179,   180,   183,   185,   191,   193,   195,   202,   206,
   210,   215,   221,   227,   231,   236,   240,   244,   248,   250,
   252,   254,   256,   258,   260,   265,   268,   271,   272,   276,
   278,   282,   284,   288,   289,   291,   295,   297,   301,   305,
   306,   308,   310,   314,   316,   319,   322,   326,   330,   334,
   336,   340,   344,   346,   348,   352,   355,   357,   358,   360,
   362,   364,   366,   368,   370,   372,   374,   379,   383,   384,
   386,   390,   392,   396,   399,   400,   404,   406,   410,   412,
   415,   419,   420,   422,   424,   428,   432,   436,   442,   449,
   460,   467,   474,   477,   480,   483,   486,   487,   489,   491,
   494,   498,   502,   505,   510,   512,   515,   517,   519,   521,
   524,   531,   533,   535,   537,   539,   541,   543,   545,   548,
   549,   553,   555,   559,   561,   565,   566,   568,   572,   574,
   578,   579,   582,   584,   587,   593,   599,   601
};

static const short yyrhs[] = {   145,
     0,   167,     0,   146,     0,   146,   145,     0,   147,     0,
    71,     0,     3,   148,    50,     0,     9,     9,     0,    72,
    75,    30,    77,    83,    33,     0,    12,    48,    73,    74,
   149,     0,     0,    45,    46,     0,    45,    47,     0,     0,
   102,     0,    35,     0,    36,     0,     0,    76,    75,     0,
    13,    49,   124,   125,   102,     0,    34,    11,    15,     8,
     8,     0,    78,     0,    78,    77,     0,    79,    81,    84,
    85,    50,     0,    18,     8,    80,     0,    37,     0,    38,
     0,    39,     0,    40,     0,     0,    82,    81,     0,   102,
     0,   106,     0,     0,     3,    86,    51,    91,     0,    87,
     0,    88,     0,    88,    52,    87,     0,   100,    17,    89,
     0,     0,    90,    89,     0,   102,     0,    92,    93,    95,
     0,     9,    53,     8,    54,    19,     0,    31,    94,     0,
     0,    52,    98,    94,     0,    32,    96,     0,     0,    52,
    97,    96,     0,   101,     0,   122,     0,   120,     0,   120,
    26,     8,     0,   121,   150,     0,    10,    55,    10,    25,
     8,     8,     0,   106,    22,   126,     0,   106,    29,    48,
    99,     0,     0,   102,     0,    16,     9,     0,     0,   151,
   150,     0,    27,     0,     9,    53,    10,    54,    50,     0,
   153,     0,   152,     0,    15,     8,     8,    14,     8,     8,
     0,   162,    55,   162,     0,   162,    56,   162,     0,   162,
    56,    55,   162,     0,   162,    55,    57,    55,   162,     0,
   162,    55,    58,    55,   162,     0,   162,     4,   162,     0,
   162,    55,    59,   162,     0,   162,    59,   162,     0,   162,
     6,   162,     0,   162,     7,   162,     0,   103,     0,   154,
     0,   156,     0,   159,     0,    11,     0,     8,     0,    60,
    53,   162,    54,     0,     9,   104,     0,    10,   104,     0,
     0,    53,   105,    54,     0,   155,     0,   155,    52,   105,
     0,   153,     0,    61,   157,    62,     0,     0,   158,     0,
   158,    51,   153,     0,   153,     0,   153,    52,   158,     0,
    63,   160,    64,     0,     0,   161,     0,   153,     0,   153,
    52,   161,     0,   163,     0,    65,   163,     0,    66,   163,
     0,   162,    65,   163,     0,   162,    66,   163,     0,   162,
     5,   162,     0,   164,     0,   163,    67,   164,     0,   163,
    68,   164,     0,    10,     0,     8,     0,    53,   162,    54,
     0,   110,   111,     0,   123,     0,     0,   165,     0,   166,
     0,   113,     0,   106,     0,   119,     0,   116,     0,    10,
     0,     8,     0,    60,    53,   162,    54,     0,    61,   114,
    62,     0,     0,   115,     0,   115,    51,   109,     0,   109,
     0,   109,    52,   115,     0,     9,   107,     0,     0,    53,
   108,    54,     0,   112,     0,   112,    52,   108,     0,   109,
     0,    10,   107,     0,    63,   117,    64,     0,     0,   118,
     0,   109,     0,   109,    52,   118,     0,   109,    55,   109,
     0,    10,     4,   162,     0,    13,    49,     8,   124,   125,
     0,    13,    49,     8,   124,   125,   102,     0,    13,    49,
     8,   124,   125,    13,    49,   124,   125,   102,     0,   165,
    13,    49,   124,   125,   102,     0,   166,    13,    49,   124,
   125,   102,     0,    65,    42,     0,    66,    42,     0,    65,
    41,     0,    66,    41,     0,     0,    43,     0,    44,     0,
    21,    11,     0,    21,    11,   102,     0,    20,    48,   102,
     0,    20,    48,     0,    24,     8,    23,   127,     0,   128,
     0,   128,   127,     0,     8,     0,   168,     0,   169,     0,
   169,   168,     0,   129,   130,    57,   139,   140,    69,     0,
   132,     0,     8,     0,    10,     0,   132,     0,    10,     0,
     8,     0,   136,     0,     9,   133,     0,     0,    53,   135,
    54,     0,   134,     0,   134,    52,   135,     0,   131,     0,
    61,   137,    62,     0,     0,   138,     0,   138,    51,   131,
     0,   131,     0,   131,    52,   138,     0,     0,     3,   141,
     0,   142,     0,   142,   141,     0,   129,     8,    57,   143,
   131,     0,   129,     8,    70,   143,   131,     0,    65,     0,
    66,     0
};

#endif

#if YYDEBUG != 0
static const short yyrline[] = { 0,
   155,   156,   161,   162,   164,   165,   171,   173,   188,   194,
   201,   203,   205,   208,   209,   211,   213,   216,   217,   221,
   234,   239,   241,   244,   250,   254,   256,   258,   260,   264,
   265,   268,   274,   283,   284,   287,   290,   292,   295,   299,
   300,   303,   308,   311,   314,   317,   318,   327,   330,   331,
   334,   336,   341,   346,   354,   363,   367,   375,   392,   394,
   400,   404,   405,   407,   409,   411,   412,   421,   427,   428,
   429,   430,   431,   432,   433,   434,   435,   436,   438,   439,
   440,   441,   442,   443,   444,   446,   450,   452,   454,   457,
   459,   462,   464,   466,   467,   468,   470,   471,   473,   475,
   476,   478,   479,   481,   482,   483,   484,   485,   486,   488,
   489,   490,   492,   493,   494,   497,   509,   525,   527,   529,
   532,   536,   540,   544,   548,   550,   552,   555,   560,   562,
   566,   572,   576,   582,   590,   593,   599,   604,   611,   637,
   642,   647,   649,   654,   658,   664,   670,   678,   687,   696,
   706,   715,   725,   727,   729,   731,   734,   736,   738,   741,
   742,   744,   745,   747,   751,   753,   756,   764,   768,   769,
   771,   785,   789,   794,   798,   802,   804,   807,   810,   820,
   823,   827,   830,   834,   838,   841,   844,   848,   853,   857,
   862,   864,   868,   871,   879,   889,   900,   902
};

static const char * const yytname[] = {   "$","error","$undefined.","Imply",
"Assign","Mod","Land","Lor","Integer","Symbol","Variable","String","Opt_define",
"Opt_port","Opt_size","Opt_point","Opt_type","Opt_guard","Opt_rule","Opt_rule_id",
"Opt_mesg","Opt_atom","Opt_merge","Opt_from","Opt_into","Opt_link","Opt_unify",
"Opt_assign","Opt_list","Opt_proc","Opt_begin","Opt_proc_part","Opt_other_part",
"Opt_end","Opt_comment","Opt_creator","Opt_normal","Opt_network","Opt_vanishing",
"Opt_continuous","Opt_transition","Opt_stream","Opt_single","Opt_left","Opt_right",
"Opt_arrange","Opt_rightward","Opt_downward","Opt_SYMBOL","Opt_VARIABLE","'.'",
"'|'","','","'('","')'","'='","'>'","':'","'\\\\'","'<'","'~'","'['","']'","'{'",
"'}'","'+'","'-'","'*'","'/'","'?'","'!'","process","procdef","proc_type","arrange_info",
"proc_infos","proc_info","clauses","clause","ruledef","rule_type","rule_infos",
"rule_info","rule_clause","head","tail","guard","guard_goals","guard_goal","guard_infos",
"guard_info","body","rule_id","subproc_part","subprocs","other_part","other_bodies",
"other_body","subproc","subproc_info","goal","link","point_size","functor","argument",
"args","t_functor","t_argument","t_args","t_term","t_term_body","t_term_info",
"t_arg","t_list","t_list_contents","t_list_elements","t_vector","t_vector_contents",
"t_vector_elements","t_structure","t_unify","t_assign","t_merge","port_info",
"port_type","left_or_right","merge_info","merge_froms","merge_from","tr_goalid",
"tr_action","tr_term","tr_functor","tr_argument","tr_arg","tr_args","tr_list",
"tr_list_contents","tr_list_elements","tr_head","tr_subgoal_part","tr_subgoals",
"tr_subgoal","tr_sub_state","S","definitions","definition","declaration","decl_body",
"procdef_point_size","assign_infos","assign_info","relation","term","structure",
"arg","list","list_contents","list_elements","vector","vector_contents","vector_elements",
"exp","e_term","e_factor","atom_info","mesg_info","tracer","tr_lines","tr_line",
""
};
#endif

static const short yyr1[] = {     0,
   144,   144,   145,   145,   146,   146,   147,   148,    71,    72,
    74,    74,    74,   149,   149,    73,    73,    75,    75,    76,
    76,    77,    77,    78,    79,    80,    80,    80,    80,    81,
    81,    82,    84,    85,    85,    86,    87,    87,    88,    89,
    89,    90,    91,    92,    93,    94,    94,    95,    96,    96,
    97,    97,    97,    97,    97,   101,   122,    98,    99,    99,
    99,   150,   150,   151,    83,   100,   100,   102,   152,   152,
   152,   152,   152,   152,   152,   152,   152,   152,   153,   153,
   153,   153,   153,   153,   153,   103,   154,   104,   104,   105,
   105,   155,   156,   157,   157,   157,   158,   158,   159,   160,
   160,   161,   161,   162,   162,   162,   162,   162,   162,   163,
   163,   163,   164,   164,   164,   109,   111,   111,   111,   111,
   110,   110,   110,   110,   110,   110,   110,   113,   114,   114,
   114,   115,   115,   106,   107,   107,   108,   108,   112,   119,
   116,   117,   117,   118,   118,   120,   121,   123,   123,   123,
   123,   123,   124,   124,   124,   124,   125,   125,   125,   165,
   165,   166,   166,   126,   127,   127,   128,   167,   168,   168,
   169,   139,   129,   130,   131,   131,   131,   131,   132,   133,
   133,   135,   135,   134,   136,   137,   137,   137,   138,   138,
   140,   140,   141,   141,   142,   142,   143,   143
};

static const short yyr2[] = {     0,
     1,     1,     1,     2,     1,     1,     3,     2,     6,     5,
     0,     2,     2,     0,     1,     1,     1,     0,     2,     5,
     5,     1,     2,     5,     3,     1,     1,     1,     1,     0,
     2,     1,     1,     0,     4,     1,     1,     3,     3,     0,
     2,     1,     3,     5,     2,     0,     3,     2,     0,     3,
     1,     1,     1,     3,     2,     6,     3,     4,     0,     1,
     2,     0,     2,     1,     5,     1,     1,     6,     3,     3,
     4,     5,     5,     3,     4,     3,     3,     3,     1,     1,
     1,     1,     1,     1,     4,     2,     2,     0,     3,     1,
     3,     1,     3,     0,     1,     3,     1,     3,     3,     0,
     1,     1,     3,     1,     2,     2,     3,     3,     3,     1,
     3,     3,     1,     1,     3,     2,     1,     0,     1,     1,
     1,     1,     1,     1,     1,     1,     4,     3,     0,     1,
     3,     1,     3,     2,     0,     3,     1,     3,     1,     2,
     3,     0,     1,     1,     3,     3,     3,     5,     6,    10,
     6,     6,     2,     2,     2,     2,     0,     1,     1,     2,
     3,     3,     2,     4,     1,     2,     1,     1,     1,     2,
     6,     1,     1,     1,     1,     1,     1,     1,     2,     0,
     3,     1,     3,     1,     3,     0,     1,     3,     1,     3,
     0,     2,     1,     2,     5,     5,     1,     1
};

static const short yydefact[] = {     0,
     0,   173,     0,     6,    18,     0,     1,     3,     5,     2,
   168,   169,     0,     0,     0,     0,     0,     0,    18,   174,
     0,     4,   170,     8,     7,    16,    17,    11,     0,     0,
     0,    19,     0,     0,    14,     0,     0,   157,     0,     0,
     0,    22,    30,   180,   172,   191,    12,    13,     0,    15,
    10,   155,   153,   156,   154,   158,   159,     0,     0,     0,
     0,     0,    23,     0,    30,    32,     0,   179,     0,     0,
     0,    20,    21,    26,    27,    28,    29,    25,     0,     9,
   135,    34,    33,    31,   177,   176,   186,   184,   175,   182,
     0,   178,     0,   192,   193,   171,     0,     0,     0,   134,
     0,     0,   189,     0,   187,     0,   181,     0,   194,     0,
     0,   126,   125,     0,   129,   142,   122,     0,   139,   118,
   137,   121,   124,   123,   114,    88,   113,    83,     0,     0,
    94,   100,     0,     0,     0,    36,    37,     0,    79,    67,
    66,    80,    81,    82,     0,   104,   110,    24,     0,   185,
     0,   183,     0,     0,     0,    65,   140,     0,   132,     0,
   130,   144,     0,   143,   136,     0,     0,     0,   116,   117,
   119,   120,     0,     0,    86,    87,   114,   113,     0,     0,
    84,    88,    97,     0,    95,   102,     0,   101,   105,   106,
     0,     0,    40,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,   190,   188,   197,   198,     0,     0,
    68,     0,     0,   128,     0,     0,   141,     0,   163,   160,
     0,     0,   138,     0,    92,    90,   115,     0,     0,    93,
     0,     0,    99,     0,    35,     0,    38,    39,    40,    42,
    74,   109,    77,    78,     0,     0,     0,    69,     0,    70,
    76,   107,   108,   111,   112,   195,   196,   127,   133,   131,
   145,     0,   162,   161,     0,     0,    89,     0,    85,    98,
    96,   103,     0,    46,     0,    41,     0,     0,    75,    71,
   157,   157,   157,    91,     0,     0,    45,    49,    43,    72,
    73,   148,     0,     0,     0,    46,     0,     0,    48,     0,
   149,   151,   152,    44,    47,     0,   125,    49,    51,   122,
     0,    53,    62,    52,     0,    59,     0,     0,    50,     0,
     0,     0,    64,    55,    62,   157,     0,    58,    60,   147,
     0,     0,    57,   146,    54,    63,     0,    61,     0,     0,
   150,     0,     0,    56,   167,   164,   165,   166,     0,     0,
     0
};

static const short yydefgoto[] = {     4,
     5,    28,    35,    18,    19,    41,    42,    43,    78,    64,
    65,    62,    82,   102,   135,   136,   137,   238,   239,   235,
   236,   275,   287,   289,   299,   308,   296,   328,   138,   309,
    66,   139,   176,   224,   117,   157,   118,   119,   120,   169,
   121,   122,   160,   161,   123,   163,   164,   124,   312,   313,
   314,   170,    38,    58,   333,   346,   347,     6,    21,    88,
    89,    68,    90,    91,    92,   104,   105,    46,    70,    94,
    95,   209,   349,     7,     8,     9,    14,    51,   324,   325,
   140,   141,   142,   226,   143,   184,   185,   144,   187,   188,
   145,   146,   147,   171,   172,    10,    11,    12
};

static const short yypact[] = {   137,
    18,-32768,     4,-32768,    -4,    19,-32768,    12,-32768,-32768,
-32768,    36,    54,    45,    10,    57,   106,    89,    -4,-32768,
    64,-32768,-32768,-32768,-32768,-32768,-32768,    98,   -10,   133,
   139,-32768,   153,    95,   157,   111,   113,   116,   169,   173,
   174,   139,   157,   134,-32768,   189,-32768,-32768,   185,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,   157,   188,    93,
   144,   165,-32768,   190,   157,-32768,    39,-32768,    36,   131,
   193,-32768,-32768,-32768,-32768,-32768,-32768,-32768,   192,-32768,
   150,   202,-32768,-32768,-32768,-32768,    39,-32768,-32768,   154,
   156,-32768,   199,-32768,    36,-32768,   194,   158,   119,-32768,
    49,   161,   162,   151,   164,    39,-32768,   -19,-32768,   208,
   167,-32768,   150,   166,   119,   119,-32768,   168,-32768,   126,
   172,-32768,-32768,-32768,   201,   175,   -11,-32768,   103,   176,
   115,   115,    29,    29,   170,-32768,   178,   203,-32768,-32768,
-32768,-32768,-32768,-32768,    28,    97,-32768,-32768,    39,-32768,
    39,-32768,   101,   101,   217,-32768,-32768,   103,   179,   171,
   181,   182,   163,-32768,-32768,   177,   191,   225,-32768,-32768,
   224,   227,   119,   115,-32768,-32768,-32768,-32768,     0,   103,
-32768,   175,   186,   180,   195,   196,   183,-32768,    97,    97,
   232,    49,   157,   103,   103,   103,   103,    33,   108,   103,
    29,    29,    29,    29,-32768,-32768,-32768,-32768,    39,    39,
-32768,    23,   119,-32768,   119,   119,-32768,   235,   157,   157,
   200,   204,-32768,   197,-32768,   198,-32768,    31,   115,-32768,
   115,   115,-32768,   207,-32768,   213,-32768,-32768,   157,-32768,
    15,    15,    15,    15,   206,   209,   103,    15,   103,    15,
    15,    97,    97,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,   -10,-32768,-32768,   -10,   -10,-32768,   115,-32768,-32768,
-32768,-32768,   237,   210,   220,-32768,   103,   103,    15,    15,
   116,   116,   116,-32768,   211,   190,-32768,   214,-32768,    15,
    15,     6,   157,   157,   236,   210,   234,   128,-32768,   205,
-32768,-32768,-32768,-32768,-32768,   219,     9,   214,-32768,   246,
   215,   230,   242,-32768,   -10,   155,   103,   261,-32768,   248,
   119,   265,-32768,-32768,   242,   116,   266,-32768,-32768,    15,
   249,   268,-32768,-32768,-32768,-32768,   157,-32768,   269,   255,
-32768,   271,   272,-32768,-32768,-32768,   272,-32768,   282,   283,
-32768
};

static const short yypgoto[] = {-32768,
-32768,-32768,-32768,   267,-32768,   243,-32768,-32768,-32768,   222,
-32768,-32768,-32768,-32768,-32768,    92,-32768,    50,-32768,-32768,
-32768,-32768,    -8,-32768,   -18,-32768,-32768,-32768,-32768,-32768,
   -35,-32768,   184,    24,   -63,   212,   118,  -112,-32768,-32768,
-32768,-32768,-32768,    81,-32768,-32768,    79,-32768,-32768,-32768,
-32768,-32768,  -240,  -265,-32768,   -51,-32768,   -55,-32768,   -75,
   264,-32768,-32768,   216,-32768,-32768,   149,-32768,-32768,   218,
-32768,   145,-32768,   292,-32768,-32768,-32768,-32768,   -24,-32768,
-32768,  -124,-32768,-32768,-32768,-32768,    74,-32768,-32768,    72,
  -127,  -123,    -9,-32768,-32768,-32768,   293,-32768
};


#define	YYLAST		322


static const short yytable[] = {    50,
    83,   179,   159,   162,   195,   -88,   183,   186,    16,   189,
   190,   103,   317,    93,     1,   292,   293,   294,   300,   195,
    49,   281,    72,     3,   282,   283,    13,   195,    20,    17,
   212,   194,   195,   196,   197,   195,   177,   153,   178,    93,
   177,   174,   178,     2,    26,    27,    85,    44,    86,   225,
   154,    15,   228,   227,    36,    37,   125,   126,   127,   128,
   337,    99,    24,   318,   201,   202,   241,   242,   243,   244,
   248,   250,   251,   103,   326,   206,   258,   252,   253,   201,
   202,   129,   198,   199,   269,   129,   200,   201,   202,   245,
   246,   247,   201,   202,    25,   201,   202,   133,   134,    87,
   159,   129,   260,   162,   183,    29,   271,   186,   130,   131,
   177,   132,   178,   133,   134,   177,    30,   178,    31,   279,
    33,   280,   181,   126,   182,   128,   112,    81,   113,    74,
    75,    76,    77,   256,   257,   112,    81,   307,   166,     1,
    47,    48,    34,   225,     2,   167,   168,    39,     3,   290,
   291,    52,    53,    54,    55,   129,    40,   240,    56,    57,
   129,    44,   249,   203,   204,   207,   208,   133,   134,    49,
   327,    49,   133,   134,   130,   131,    59,   132,   114,   115,
    60,   116,    61,   263,   264,   311,    67,   114,   115,   330,
   116,    69,    71,   254,   255,    73,    79,    80,    81,    96,
    97,    98,    99,   240,   101,   106,   108,   110,   334,   107,
   148,   111,   150,   149,   151,   155,   156,   -84,   158,   193,
   191,   165,   297,   173,   211,   218,   217,   174,   180,   192,
   213,   215,   214,   216,   310,   220,   221,   229,   219,   222,
   234,   230,   262,   274,   285,   231,   233,   232,   265,   268,
   267,   288,   266,   315,   304,   322,   301,   302,   303,   273,
   277,   286,   306,   278,   295,   298,   316,   320,   323,   321,
   331,   332,   335,   339,   338,   340,   342,   343,   344,   345,
   329,   350,   351,   237,    63,    32,    84,   305,   276,   319,
   223,   284,   100,   259,   261,   348,    45,   205,   210,    22,
   336,   341,   270,   272,    23,     0,     0,     0,     0,   175,
     0,     0,   109,     0,     0,     0,     0,     0,     0,     0,
     0,   152
};

static const short yycheck[] = {    35,
    64,   129,   115,   116,     5,    17,   131,   132,    13,   133,
   134,    87,     4,    69,     3,   281,   282,   283,    13,     5,
    15,   262,    58,    12,   265,   266,     9,     5,    10,    34,
   158,     4,     5,     6,     7,     5,     8,    57,    10,    95,
     8,    53,    10,     8,    35,    36,     8,     9,    10,   174,
    70,    48,   180,    54,    65,    66,     8,     9,    10,    11,
   326,    53,     9,    55,    65,    66,   194,   195,   196,   197,
   198,   199,   200,   149,   315,   151,    54,   201,   202,    65,
    66,    53,    55,    56,    54,    53,    59,    65,    66,    57,
    58,    59,    65,    66,    50,    65,    66,    65,    66,    61,
   213,    53,   215,   216,   229,    49,   231,   232,    60,    61,
     8,    63,    10,    65,    66,     8,    11,    10,    30,   247,
    57,   249,     8,     9,    10,    11,     8,     9,    10,    37,
    38,    39,    40,   209,   210,     8,     9,    10,    13,     3,
    46,    47,    45,   268,     8,    20,    21,    15,    12,   277,
   278,    41,    42,    41,    42,    53,    18,   193,    43,    44,
    53,     9,    55,    67,    68,    65,    66,    65,    66,    15,
    16,    15,    65,    66,    60,    61,     8,    63,    60,    61,
     8,    63,     9,   219,   220,   298,    53,    60,    61,   317,
    63,     3,     8,   203,   204,     8,    53,    33,     9,    69,
     8,    10,    53,   239,     3,    52,     8,    14,   321,    54,
    50,    54,    62,    52,    51,     8,    50,    17,    53,    17,
    51,    54,   286,    52,     8,    49,    64,    53,    53,    52,
    52,    51,    62,    52,   298,    11,    13,    52,    48,    13,
     9,    62,     8,    31,     8,    51,    64,    52,    49,    52,
    54,    32,    49,    49,    19,    26,   292,   293,   294,    53,
    55,    52,    29,    55,    54,    52,    48,    22,    27,    55,
    10,    24,     8,    25,     9,     8,     8,    23,     8,     8,
   316,     0,     0,   192,    42,    19,    65,   296,   239,   308,
   173,   268,    81,   213,   216,   347,    33,   149,   154,     8,
   325,   337,   229,   232,    12,    -1,    -1,    -1,    -1,   126,
    -1,    -1,    95,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,   106
};
/* -*-C-*-  Note some compilers choke on comments on `#line' lines.  */
#line 3 "bison.simple"
#line 4 "/usr/local/lib/rie-1.0.6/rie.simple"

/* Skeleton output parser for Rie,
   Copyright (C) 1991-1993 Masataka Sassa, Kazuhiro Kuroishi, Teruhisa Hirai.

This file is part of Rie, A Compiler Compiler Based on ECLR-attributed Grammar.

This file is made with modifying "bison.simple", Bison skeleton parser.
Copyright of "bison.simple" is described below.  */

/* Skeleton output parser for bison,
   Copyright (C) 1984, 1989, 1990 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

#ifndef alloca
#ifdef __GNUC__
#define alloca __builtin_alloca
#else /* not GNU C.  */
#if (!defined (__STDC__) && defined (sparc)) || defined (__sparc__) || defined (__sparc) || defined (__sgi)
#include <alloca.h>
#else /* not sparc */
#if defined (MSDOS) && !defined (__TURBOC__)
#include <malloc.h>
#else /* not MSDOS, or __TURBOC__ */
#if defined(_AIX)
#include <malloc.h>
 #pragma alloca
#else /* not MSDOS, __TURBOC__, or _AIX */
#ifdef __hpux
#ifdef __cplusplus
extern "C" {
void *alloca (unsigned int);
};
#else /* not __cplusplus */
void *alloca ();
#endif /* not __cplusplus */
#endif /* __hpux */
#endif /* not _AIX */
#endif /* not MSDOS, or __TURBOC__ */
#endif /* not sparc.  */
#endif /* not GNU C.  */
#endif /* alloca not defined.  */

/* This is the parser code that is written into each bison parser
  when the %semantic_parser declaration is not specified in the grammar.
  It was written by Richard Stallman by simplifying the hairy parser
  used when %semantic_parser is specified.  */

/* Note: there must be only one dollar sign in this file.
   It is replaced by the list of actions, each action
   as one case of the switch.  */

/* But Rie has three dollar signs.
   The first is for inherited attribute evaluation. 
   The second is for synthesized evaluation.
   And the third is for debugging action and messages.  */

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		-2
#define YYEOF		0
#define YYACCEPT	return(0)
#define YYABORT 	return(1)
#define YYERROR		goto yyerrlab1
/* Like YYERROR except do call yyerror.
   This remains here temporarily to ease the
   transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */
#define YYFAIL		goto yyerrlab
#define YYRECOVERING()  (!!yyerrstatus)
#define YYBACKUP(token, value) \
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    { yychar = (token), yylval = (value);			\
      yychar1 = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { yyerror ("syntax error: cannot back up"); YYERROR; }	\
while (0)

#define YYTERROR	1
#define YYERRCODE	256

#ifndef YYPURE
#define YYLEX		yylex()
#endif

#ifdef YYPURE
#ifdef YYLSP_NEEDED
#ifdef YYLEX_PARAM
#define YYLEX		yylex(&yylval, &yylloc, YYLEX_PARAM)
#else
#define YYLEX		yylex(&yylval, &yylloc)
#endif
#else /* not YYLSP_NEEDED */
#ifdef YYLEX_PARAM
#define YYLEX		yylex(&yylval, YYLEX_PARAM)
#else
#define YYLEX		yylex(&yylval)
#endif
#endif /* not YYLSP_NEEDED */
#endif

/* If nonreentrant, generate the variables here */

#ifndef YYPURE

#ifdef RIE_SOME_SYNTHESIZE
rrsastype rrlval;		/* synthesized attribute returnd by	*/
				/* lexical analyzer. 			*/
#endif

int	yychar;			/*  the lookahead symbol		*/
YYSTYPE	yylval;			/*  the semantic value of the		*/
				/*  lookahead symbol			*/

#ifdef YYLSP_NEEDED
YYLTYPE yylloc;			/*  location data for the lookahead	*/
				/*  symbol				*/
#endif

int yynerrs;			/*  number of parse errors so far       */
#endif  /* not YYPURE */

#if YYDEBUG != 0
int yydebug;			/*  nonzero means print parse trace	*/
/* Since this is uninitialized, it does not stop multiple parsers
   from coexisting.  */
#endif

#if RRDEBUG != 0
int rrdebug;			/*  nonzero means eval debug action	*/
#endif

FILE *rrmessage = stderr;	/* the stream %message write out to	*/

/*  YYINITDEPTH indicates the initial size of the parser's stacks	*/

#ifndef	YYINITDEPTH
#define YYINITDEPTH 200
#endif

/*  YYMAXDEPTH is the maximum size the stacks can grow to
    (effective only if the built-in stack extension method is used).  */

#if YYMAXDEPTH == 0
#undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
#define YYMAXDEPTH 10000
#endif

/* Prevent warning if -Wstrict-prototypes.  */
#ifdef __GNUC__
int yyparse (void);
#endif

/* convenience function  */
void
#ifdef __cplusplus
rroption(int ac, char *av[])
#else
rroption(ac, av)
  int ac;
  char *av[];
#endif
{
  register char c;

  while(--ac > 0 && (*++av)[0] == '-')
    {
      c = *++av[0];
      switch(c)
	{
	case 'y':
	case 'Y':
#if YYDEBUG != 0
	  yydebug = 1;
	  fprintf(rrmessage, "Trace Facility ON\n");
#endif
	  break;

	case 'r':
	case 'R':
#if RRDEBUG != 0
	  rrdebug = 1;
	  fprintf(rrmessage, "Debug Action Facility ON\n");
#endif
	  break;

        default:
	  break;
	}
    }
}

#if __GNUC__ > 1		/* GNU C and GNU C++ define this.  */
#define __yy_memcpy(FROM,TO,COUNT)	__builtin_memcpy(TO,FROM,COUNT)
#else				/* not GNU C or C++ */
#ifndef __cplusplus

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_memcpy (from, to, count)
     char *from;
     char *to;
     int count;
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#else /* __cplusplus */

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_memcpy (char *from, char *to, int count)
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#endif
#endif

#line 260 "bison.simple"
#line 261 "/usr/local/lib/rie-1.0.6/rie.simple"

/* The user can define YYPARSE_PARAM as the name of an argument to be passed
   into yyparse.  The argument should have type void *.
   It should actually point to an object.
   Grammar actions can access the variable by casting it
   to the proper pointer type.  */

#ifdef YYPARSE_PARAM
#define YYPARSE_PARAM_DECL void *YYPARSE_PARAM;
#else
#define YYPARSE_PARAM
#define YYPARSE_PARAM_DECL
#endif

int
yyparse(YYPARSE_PARAM)
     YYPARSE_PARAM_DECL
{
  register int yystate;
  register int yyn;
  register short *yyssp;
#ifdef NOT_RIE
  register YYSTYPE *yyvsp;
#endif
#ifdef RIE_SOME_SYNTHESIZE
  register rrsastype *rrsasp;
#endif

#ifdef RIE_SOME_INHERIT
  register rriastype *rriasp;
#endif

#ifdef RIE_SOME_LOCAL
  register rrlastype *rrlasp;
#endif
  
  int yyerrstatus;	/*  number of tokens to shift before error messages enabled */
  int yychar1 = 0;		/*  lookahead token as an internal (translated) token number */

  short	yyssa[YYINITDEPTH];	/*  the state stack			*/
#ifdef NOT_RIE
  YYSTYPE yyvsa[YYINITDEPTH];	/*  the semantic value stack		*/
#endif

#ifdef RIE_SOME_SYNTHESIZE
  rrsastype rrsas[YYINITDEPTH];	/*  the sythesized attribute statck	*/
#endif

#ifdef RIE_SOME_INHERIT
  rriastype rrias[YYINITDEPTH];	/*  the inherited attribute stack	*/
#endif

#ifdef RIE_SOME_LOCAL
  rrlastype rrlas[YYINITDEPTH];	/*  the local attribute stack		*/
#endif
  
  short *yyss = yyssa;		/*  refer to the stacks thru separate pointers */
#ifdef NOT_RIE
  YYSTYPE *yyvs = yyvsa;	/*  to allow yyoverflow to reallocate them elsewhere */
#endif
#ifdef RIE_SOME_SYNTHESIZE
  rrsastype *rrss = rrsas;
#endif

#ifdef RIE_SOME_INHERIT
  rriastype *rris = rrias;
#endif

#ifdef RIE_SOME_LOCAL
  rrlastype *rrls = rrlas;
#endif

#ifdef YYLSP_NEEDED
  YYLTYPE yylsa[YYINITDEPTH];	/*  the location stack			*/
  YYLTYPE *yyls = yylsa;
  YYLTYPE *yylsp;

#define YYPOPSTACK   (yyvsp--, yyssp--, yylsp--)
#else
#define YYPOPSTACK   (yyvsp--, yyssp--)
#endif

  int yystacksize = YYINITDEPTH;

#ifdef YYPURE
  int yychar;
#ifdef NOT_RIE
  YYSTYPE yylval;
#endif
  int yynerrs;
#ifdef RIE_SOME_SYNTHESIZE
  rrsastype rrlval;
#endif
#ifdef YYLSP_NEEDED
  YYLTYPE yylloc;
#endif
#endif

#ifdef RIE_SOME_SYNTHESIZE
  rrsastype rrval;	/* assigned temprally at synthesized attribute
			   evaluation time.  */
#endif
#ifdef NOT_RIE
  YYSTYPE yyval;		/*  the variable used to return		*/
				/*  semantic values from the action	*/
				/*  routines				*/

#endif
  int yylen;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Starting parse\n");
#endif

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss - 1;
#ifdef NOT_RIE
  yyvsp = yyvs;
#endif
#ifdef RIE_SOME_SYNTHESIZE
  rrsasp = rrss;
#endif

#ifdef RIE_SOME_INHERIT
  rriasp = rris - 1;
#endif

#ifdef RIE_SOME_LOCAL
  rrlasp = rrls - 1;
#endif

#ifdef YYLSP_NEEDED
  yylsp = yyls;
#endif

/* Push a new state, which is found in  yystate  .  */
/* In all cases, when you get here, the value and location stacks
   have just been pushed. so pushing a state here evens the stacks.  */
yynewstate:

  *++yyssp = yystate;

#ifdef RIE_SOME_INHERIT
  ++rriasp;
#endif

#ifdef RIE_SOME_LOCAL
  ++rrlasp;
#endif
 
  /*								*/
  /*  inherited attribute and local attribute evaluation.	*/
  /*								*/
  switch (yystate)
    {
      case 5:
#line 190 "kl.rie"
	rriasp->EC0 = rrsasp->rrprocdef.proc;
#line 218 "kl.rie"
	rriasp->EC1 = rrsasp->rrprocdef.proc;
	break;

      case 19:
#line 219 "kl.rie"
	rriasp->EC0 = rriasp[-1].EC0;
#line 218 "kl.rie"
	rriasp->EC1 = rriasp[-1].EC0;
	break;

      case 31:
#line 191 "kl.rie"
	rriasp->EC2 = rrsasp[-2].rrprocdef.proc;
#line 240 "kl.rie"
	rriasp->EC3 = rrsasp[-2].rrprocdef.proc;
#line 245 "kl.rie"
	rriasp->EC4 = rrsasp[-2].rrprocdef.proc;
	break;

      case 41:
#line 192 "kl.rie"
	rriasp->EC7 = rrsasp[-3].rrprocdef.proc;
	break;

      case 42:
#line 242 "kl.rie"
	rriasp->EC2 = rriasp[-1].EC2;
#line 240 "kl.rie"
	rriasp->EC3 = rriasp[-1].EC2;
#line 245 "kl.rie"
	rriasp->EC4 = rriasp[-1].EC2;
	break;

      case 43:
#line 246 "kl.rie"
	rriasp->EC5 = rrsasp->rrruledef.rule;
#line 266 "kl.rie"
	rriasp->EC6 = rrsasp->rrruledef.rule;
	break;

      case 44:
#line 812 "kl.rie"
	rriasp->EC100 =new term_functor( rrsasp->rrSymbol.module, rrsasp->rrSymbol.name);
	break;

      case 46:
#line 772 "kl.rie"
	rriasp->EC103 = rrsasp->rrtr_head.module;
	break;

      case 64:
#line 247 "kl.rie"
	rriasp->EC8 = rrsasp[-1].rrruledef.rule;
#line 275 "kl.rie"
	rriasp->EC27 = rrsasp[-1].rrruledef.rule;
#line 278 "kl.rie"
	rriasp->EC28 =NULL;
#line 279 "kl.rie"
	rriasp->EC29 =NULL;
#line 280 "kl.rie"
	rriasp->EC30 =0;
	break;

      case 65:
#line 266 "kl.rie"
	rriasp->EC5 = rriasp[-1].EC5;
#line 266 "kl.rie"
	rriasp->EC6 = rriasp[-1].EC5;
	break;

      case 67:
#line 829 "kl.rie"
	rriasp->EC101 = rriasp[-1].EC100;
#line 825 "kl.rie"
	rriasp->EC102 = rriasp[-1].EC100;
	break;

      case 69:
#line 866 "kl.rie"
	rriasp->EC104 = rriasp[-1].EC103;
#line 870 "kl.rie"
	rriasp->EC105 = rriasp[-1].EC103;
	break;

      case 81:
#line 584 "kl.rie"
	rriasp->EC31 = rriasp[-1].EC27;
#line 583 "kl.rie"
	rriasp->EC32 = rriasp[-1].EC28;
#line 583 "kl.rie"
	rriasp->EC33 = rriasp[-1].EC29;
#line 585 "kl.rie"
	rriasp->EC34 = rriasp[-1].EC30+ 1;
	break;

      case 82:
#line 248 "kl.rie"
	rriasp->EC9 = rrsasp[-2].rrruledef.rule;
	break;

      case 95:
#line 873 "kl.rie"
	rriasp->EC104 = rriasp[-1].EC104;
#line 870 "kl.rie"
	rriasp->EC105 = rriasp[-1].EC104;
	break;

      case 99:
#line 538 "kl.rie"
	rriasp->EC27 = rriasp[-1].EC31;
#line 537 "kl.rie"
	rriasp->EC28 = rriasp[-1].EC32;
#line 537 "kl.rie"
	rriasp->EC29 = rriasp[-1].EC33;
#line 539 "kl.rie"
	rriasp->EC30 = rriasp[-1].EC34;
#line 595 "kl.rie"
	rriasp->EC35 = rriasp[-1].EC31;
#line 594 "kl.rie"
	rriasp->EC36 = rriasp[-1].EC32;
#line 594 "kl.rie"
	rriasp->EC37 = rriasp[-1].EC33;
#line 597 "kl.rie"
	rriasp->EC38 = rriasp[-1].EC34;
#line 613 "kl.rie"
	rriasp->EC39 = rriasp[-1].EC31;
#line 612 "kl.rie"
	rriasp->EC40 = rriasp[-1].EC32;
#line 615 "kl.rie"
	rriasp->EC41 = rriasp[-1].EC33;
#line 614 "kl.rie"
	rriasp->EC42 = rriasp[-1].EC34;
#line 499 "kl.rie"
	rriasp->EC43 = rriasp[-1].EC31;
#line 498 "kl.rie"
	rriasp->EC44 = rriasp[-1].EC32;
#line 498 "kl.rie"
	rriasp->EC45 = rriasp[-1].EC33;
#line 499 "kl.rie"
	rriasp->EC46 = rriasp[-1].EC34;
#line 601 "kl.rie"
	rriasp->EC51 = rriasp[-1].EC31;
#line 600 "kl.rie"
	rriasp->EC52 = rriasp[-1].EC32;
#line 600 "kl.rie"
	rriasp->EC53 = rriasp[-1].EC33;
#line 602 "kl.rie"
	rriasp->EC54 = rriasp[-1].EC34;
#line 534 "kl.rie"
	rriasp->EC55 = rriasp[-1].EC31;
#line 533 "kl.rie"
	rriasp->EC56 = rriasp[-1].EC32;
#line 533 "kl.rie"
	rriasp->EC57 = rriasp[-1].EC33;
#line 535 "kl.rie"
	rriasp->EC58 = rriasp[-1].EC34;
#line 546 "kl.rie"
	rriasp->EC67 = rriasp[-1].EC31;
#line 545 "kl.rie"
	rriasp->EC68 = rriasp[-1].EC32;
#line 545 "kl.rie"
	rriasp->EC69 = rriasp[-1].EC33;
#line 547 "kl.rie"
	rriasp->EC70 = rriasp[-1].EC34;
#line 542 "kl.rie"
	rriasp->EC79 = rriasp[-1].EC31;
#line 541 "kl.rie"
	rriasp->EC80 = rriasp[-1].EC32;
#line 541 "kl.rie"
	rriasp->EC81 = rriasp[-1].EC33;
#line 543 "kl.rie"
	rriasp->EC82 = rriasp[-1].EC34;
	break;

      case 101:
#line 285 "kl.rie"
	rriasp->EC10 = rriasp[-1].EC9;
#line 288 "kl.rie"
	rriasp->EC11 = rriasp[-1].EC9;
#line 291 "kl.rie"
	rriasp->EC12 = rriasp[-1].EC9;
#line 297 "kl.rie"
	rriasp->EC24 =con_guard;
#line 296 "kl.rie"
	rriasp->EC25 = rriasp[-1].EC9;
	break;

      case 106:
#line 829 "kl.rie"
	rriasp->EC101 = rrsasp[-1].rrtr_arg.ts;
#line 832 "kl.rie"
	rriasp->EC102 = rrsasp[-1].rrtr_arg.ts;
	break;

      case 113:
#line 639 "kl.rie"
	rriasp->EC31 = rriasp[-1].EC79;
#line 638 "kl.rie"
	rriasp->EC32 = rriasp[-1].EC80;
#line 638 "kl.rie"
	rriasp->EC33 = rriasp[-1].EC81;
#line 640 "kl.rie"
	rriasp->EC34 = rriasp[-1].EC82+ 1;
	break;

      case 115:
#line 538 "kl.rie"
	rriasp->EC27 = rriasp[-1].EC55;
#line 537 "kl.rie"
	rriasp->EC28 = rriasp[-1].EC56;
#line 537 "kl.rie"
	rriasp->EC29 = rriasp[-1].EC57;
#line 539 "kl.rie"
	rriasp->EC30 = rriasp[-1].EC58+ 1;
#line 574 "kl.rie"
	rriasp->EC39 = rriasp[-1].EC55;
#line 573 "kl.rie"
	rriasp->EC40 = rriasp[-1].EC56;
#line 573 "kl.rie"
	rriasp->EC41 = rriasp[-1].EC57;
#line 575 "kl.rie"
	rriasp->EC42 = rriasp[-1].EC58+ 1;
#line 499 "kl.rie"
	rriasp->EC43 = rriasp[-1].EC55;
#line 498 "kl.rie"
	rriasp->EC44 = rriasp[-1].EC56;
#line 498 "kl.rie"
	rriasp->EC45 = rriasp[-1].EC57;
#line 499 "kl.rie"
	rriasp->EC46 = rriasp[-1].EC58+ 1;
#line 534 "kl.rie"
	rriasp->EC55 = rriasp[-1].EC55;
#line 533 "kl.rie"
	rriasp->EC56 = rriasp[-1].EC56;
#line 533 "kl.rie"
	rriasp->EC57 = rriasp[-1].EC57;
#line 535 "kl.rie"
	rriasp->EC58 = rriasp[-1].EC58+ 1;
#line 557 "kl.rie"
	rriasp->EC59 = rriasp[-1].EC55;
#line 556 "kl.rie"
	rriasp->EC60 = rriasp[-1].EC56;
#line 556 "kl.rie"
	rriasp->EC61 = rriasp[-1].EC57;
#line 558 "kl.rie"
	rriasp->EC62 = rriasp[-1].EC58+ 1;
#line 564 "kl.rie"
	rriasp->EC63 = rriasp[-1].EC55;
#line 563 "kl.rie"
	rriasp->EC64 = rriasp[-1].EC56;
#line 563 "kl.rie"
	rriasp->EC65 = rriasp[-1].EC57;
#line 565 "kl.rie"
	rriasp->EC66 = rriasp[-1].EC58+ 1;
#line 546 "kl.rie"
	rriasp->EC67 = rriasp[-1].EC55;
#line 545 "kl.rie"
	rriasp->EC68 = rriasp[-1].EC56;
#line 545 "kl.rie"
	rriasp->EC69 = rriasp[-1].EC57;
#line 547 "kl.rie"
	rriasp->EC70 = rriasp[-1].EC58+ 1;
#line 542 "kl.rie"
	rriasp->EC79 = rriasp[-1].EC55;
#line 541 "kl.rie"
	rriasp->EC80 = rriasp[-1].EC56;
#line 541 "kl.rie"
	rriasp->EC81 = rriasp[-1].EC57;
#line 543 "kl.rie"
	rriasp->EC82 = rriasp[-1].EC58+ 1;
	break;

      case 116:
#line 538 "kl.rie"
	rriasp->EC27 = rriasp[-1].EC67;
#line 537 "kl.rie"
	rriasp->EC28 = rriasp[-1].EC68;
#line 537 "kl.rie"
	rriasp->EC29 = rriasp[-1].EC69;
#line 539 "kl.rie"
	rriasp->EC30 = rriasp[-1].EC70+ 1;
#line 656 "kl.rie"
	rriasp->EC39 = rriasp[-1].EC67;
#line 655 "kl.rie"
	rriasp->EC40 = rriasp[-1].EC68;
#line 655 "kl.rie"
	rriasp->EC41 = rriasp[-1].EC69;
#line 657 "kl.rie"
	rriasp->EC42 = rriasp[-1].EC70+ 1;
#line 499 "kl.rie"
	rriasp->EC43 = rriasp[-1].EC67;
#line 498 "kl.rie"
	rriasp->EC44 = rriasp[-1].EC68;
#line 498 "kl.rie"
	rriasp->EC45 = rriasp[-1].EC69;
#line 499 "kl.rie"
	rriasp->EC46 = rriasp[-1].EC70+ 1;
#line 534 "kl.rie"
	rriasp->EC55 = rriasp[-1].EC67;
#line 533 "kl.rie"
	rriasp->EC56 = rriasp[-1].EC68;
#line 533 "kl.rie"
	rriasp->EC57 = rriasp[-1].EC69;
#line 535 "kl.rie"
	rriasp->EC58 = rriasp[-1].EC70+ 1;
#line 546 "kl.rie"
	rriasp->EC67 = rriasp[-1].EC67;
#line 545 "kl.rie"
	rriasp->EC68 = rriasp[-1].EC68;
#line 545 "kl.rie"
	rriasp->EC69 = rriasp[-1].EC69;
#line 547 "kl.rie"
	rriasp->EC70 = rriasp[-1].EC70+ 1;
#line 644 "kl.rie"
	rriasp->EC71 = rriasp[-1].EC67;
#line 643 "kl.rie"
	rriasp->EC72 = rriasp[-1].EC68;
#line 643 "kl.rie"
	rriasp->EC73 = rriasp[-1].EC69;
#line 645 "kl.rie"
	rriasp->EC74 = rriasp[-1].EC70+ 1;
#line 651 "kl.rie"
	rriasp->EC75 = rriasp[-1].EC67;
#line 650 "kl.rie"
	rriasp->EC76 = rriasp[-1].EC68;
#line 650 "kl.rie"
	rriasp->EC77 = rriasp[-1].EC69;
#line 652 "kl.rie"
	rriasp->EC78 = rriasp[-1].EC70+ 1;
#line 542 "kl.rie"
	rriasp->EC79 = rriasp[-1].EC67;
#line 541 "kl.rie"
	rriasp->EC80 = rriasp[-1].EC68;
#line 541 "kl.rie"
	rriasp->EC81 = rriasp[-1].EC69;
#line 543 "kl.rie"
	rriasp->EC82 = rriasp[-1].EC70+ 1;
	break;

      case 120:
#line 511 "kl.rie"
	rrlasp->C1.port_117 =new Port();
#line 499 "kl.rie"
	rriasp->EC47 = rriasp[-1].EC39;
#line 498 "kl.rie"
	rriasp->EC48 = rrsasp->rrt_term_body.sps;
#line 498 "kl.rie"
	rriasp->EC49 = rrsasp->rrt_term_body.ps;
#line 499 "kl.rie"
	rriasp->EC50 = rriasp[-1].EC42;
	break;

      case 173:
#line 538 "kl.rie"
	rriasp->EC27 = rriasp[-2].EC35;
#line 537 "kl.rie"
	rriasp->EC28 = rrsasp[-1].rrt_arg.sps;
#line 537 "kl.rie"
	rriasp->EC29 = rrsasp[-1].rrt_arg.ps;
#line 539 "kl.rie"
	rriasp->EC30 = rriasp[-2].EC38;
#line 606 "kl.rie"
	rriasp->EC35 = rriasp[-2].EC35;
#line 605 "kl.rie"
	rriasp->EC36 = rrsasp[-1].rrt_arg.sps;
#line 605 "kl.rie"
	rriasp->EC37 = rrsasp[-1].rrt_arg.ps;
#line 608 "kl.rie"
	rriasp->EC38 = rriasp[-2].EC38;
#line 613 "kl.rie"
	rriasp->EC39 = rriasp[-2].EC35;
#line 612 "kl.rie"
	rriasp->EC40 = rrsasp[-1].rrt_arg.sps;
#line 615 "kl.rie"
	rriasp->EC41 = rrsasp[-1].rrt_arg.ps;
#line 614 "kl.rie"
	rriasp->EC42 = rriasp[-2].EC38;
#line 499 "kl.rie"
	rriasp->EC43 = rriasp[-2].EC35;
#line 498 "kl.rie"
	rriasp->EC44 = rrsasp[-1].rrt_arg.sps;
#line 498 "kl.rie"
	rriasp->EC45 = rrsasp[-1].rrt_arg.ps;
#line 499 "kl.rie"
	rriasp->EC46 = rriasp[-2].EC38;
#line 601 "kl.rie"
	rriasp->EC51 = rriasp[-2].EC35;
#line 600 "kl.rie"
	rriasp->EC52 = rrsasp[-1].rrt_arg.sps;
#line 600 "kl.rie"
	rriasp->EC53 = rrsasp[-1].rrt_arg.ps;
#line 602 "kl.rie"
	rriasp->EC54 = rriasp[-2].EC38;
#line 534 "kl.rie"
	rriasp->EC55 = rriasp[-2].EC35;
#line 533 "kl.rie"
	rriasp->EC56 = rrsasp[-1].rrt_arg.sps;
#line 533 "kl.rie"
	rriasp->EC57 = rrsasp[-1].rrt_arg.ps;
#line 535 "kl.rie"
	rriasp->EC58 = rriasp[-2].EC38;
#line 546 "kl.rie"
	rriasp->EC67 = rriasp[-2].EC35;
#line 545 "kl.rie"
	rriasp->EC68 = rrsasp[-1].rrt_arg.sps;
#line 545 "kl.rie"
	rriasp->EC69 = rrsasp[-1].rrt_arg.ps;
#line 547 "kl.rie"
	rriasp->EC70 = rriasp[-2].EC38;
#line 542 "kl.rie"
	rriasp->EC79 = rriasp[-2].EC35;
#line 541 "kl.rie"
	rriasp->EC80 = rrsasp[-1].rrt_arg.sps;
#line 541 "kl.rie"
	rriasp->EC81 = rrsasp[-1].rrt_arg.ps;
#line 543 "kl.rie"
	rriasp->EC82 = rriasp[-2].EC38;
	break;

      case 191:
#line 285 "kl.rie"
	rriasp->EC15 = rriasp[-3].EC9;
#line 309 "kl.rie"
	rriasp->EC16 = rriasp[-3].EC9;
	break;

      case 192:
#line 293 "kl.rie"
	rriasp->EC11 = rriasp[-2].EC11;
#line 291 "kl.rie"
	rriasp->EC12 = rriasp[-2].EC11;
#line 297 "kl.rie"
	rriasp->EC24 =con_guard;
#line 296 "kl.rie"
	rriasp->EC25 = rriasp[-2].EC11;
	break;

      case 193:
#line 296 "kl.rie"
	rriasp->EC13 = rriasp[-2].EC12;
#line 301 "kl.rie"
	rriasp->EC14 = rriasp[-2].EC12;
	break;

      case 213:
#line 538 "kl.rie"
	rriasp->EC27 = rriasp[-2].EC63;
#line 537 "kl.rie"
	rriasp->EC28 = rrsasp[-1].rrt_term.sps;
#line 537 "kl.rie"
	rriasp->EC29 = rrsasp[-1].rrt_term.ps;
#line 539 "kl.rie"
	rriasp->EC30 = rriasp[-2].EC66;
#line 574 "kl.rie"
	rriasp->EC39 = rriasp[-2].EC63;
#line 573 "kl.rie"
	rriasp->EC40 = rrsasp[-1].rrt_term.sps;
#line 573 "kl.rie"
	rriasp->EC41 = rrsasp[-1].rrt_term.ps;
#line 575 "kl.rie"
	rriasp->EC42 = rriasp[-2].EC66;
#line 499 "kl.rie"
	rriasp->EC43 = rriasp[-2].EC63;
#line 498 "kl.rie"
	rriasp->EC44 = rrsasp[-1].rrt_term.sps;
#line 498 "kl.rie"
	rriasp->EC45 = rrsasp[-1].rrt_term.ps;
#line 499 "kl.rie"
	rriasp->EC46 = rriasp[-2].EC66;
#line 534 "kl.rie"
	rriasp->EC55 = rriasp[-2].EC63;
#line 533 "kl.rie"
	rriasp->EC56 = rrsasp[-1].rrt_term.sps;
#line 533 "kl.rie"
	rriasp->EC57 = rrsasp[-1].rrt_term.ps;
#line 535 "kl.rie"
	rriasp->EC58 = rriasp[-2].EC66;
#line 578 "kl.rie"
	rriasp->EC63 = rriasp[-2].EC63;
#line 577 "kl.rie"
	rriasp->EC64 = rrsasp[-1].rrt_term.sps;
#line 577 "kl.rie"
	rriasp->EC65 = rrsasp[-1].rrt_term.ps;
#line 580 "kl.rie"
	rriasp->EC66 = rriasp[-2].EC66;
#line 546 "kl.rie"
	rriasp->EC67 = rriasp[-2].EC63;
#line 545 "kl.rie"
	rriasp->EC68 = rrsasp[-1].rrt_term.sps;
#line 545 "kl.rie"
	rriasp->EC69 = rrsasp[-1].rrt_term.ps;
#line 547 "kl.rie"
	rriasp->EC70 = rriasp[-2].EC66;
#line 542 "kl.rie"
	rriasp->EC79 = rriasp[-2].EC63;
#line 541 "kl.rie"
	rriasp->EC80 = rrsasp[-1].rrt_term.sps;
#line 541 "kl.rie"
	rriasp->EC81 = rrsasp[-1].rrt_term.ps;
#line 543 "kl.rie"
	rriasp->EC82 = rriasp[-2].EC66;
	break;

      case 215:
#line 538 "kl.rie"
	rriasp->EC27 = rriasp[-2].EC59;
#line 537 "kl.rie"
	rriasp->EC28 = rrsasp[-1].rrt_list_elements.sps;
#line 537 "kl.rie"
	rriasp->EC29 = rrsasp[-1].rrt_list_elements.ps;
#line 539 "kl.rie"
	rriasp->EC30 = rriasp[-2].EC62;
#line 568 "kl.rie"
	rriasp->EC39 = rriasp[-2].EC59;
#line 567 "kl.rie"
	rriasp->EC40 = rrsasp[-1].rrt_list_elements.sps;
#line 567 "kl.rie"
	rriasp->EC41 = rrsasp[-1].rrt_list_elements.ps;
#line 570 "kl.rie"
	rriasp->EC42 = rriasp[-2].EC62;
#line 499 "kl.rie"
	rriasp->EC43 = rriasp[-2].EC59;
#line 498 "kl.rie"
	rriasp->EC44 = rrsasp[-1].rrt_list_elements.sps;
#line 498 "kl.rie"
	rriasp->EC45 = rrsasp[-1].rrt_list_elements.ps;
#line 499 "kl.rie"
	rriasp->EC46 = rriasp[-2].EC62;
#line 534 "kl.rie"
	rriasp->EC55 = rriasp[-2].EC59;
#line 533 "kl.rie"
	rriasp->EC56 = rrsasp[-1].rrt_list_elements.sps;
#line 533 "kl.rie"
	rriasp->EC57 = rrsasp[-1].rrt_list_elements.ps;
#line 535 "kl.rie"
	rriasp->EC58 = rriasp[-2].EC62;
#line 546 "kl.rie"
	rriasp->EC67 = rriasp[-2].EC59;
#line 545 "kl.rie"
	rriasp->EC68 = rrsasp[-1].rrt_list_elements.sps;
#line 545 "kl.rie"
	rriasp->EC69 = rrsasp[-1].rrt_list_elements.ps;
#line 547 "kl.rie"
	rriasp->EC70 = rriasp[-2].EC62;
#line 542 "kl.rie"
	rriasp->EC79 = rriasp[-2].EC59;
#line 541 "kl.rie"
	rriasp->EC80 = rrsasp[-1].rrt_list_elements.sps;
#line 541 "kl.rie"
	rriasp->EC81 = rrsasp[-1].rrt_list_elements.ps;
#line 543 "kl.rie"
	rriasp->EC82 = rriasp[-2].EC62;
	break;

      case 216:
#line 538 "kl.rie"
	rriasp->EC27 = rriasp[-2].EC75;
#line 537 "kl.rie"
	rriasp->EC28 = rrsasp[-1].rrt_term.sps;
#line 537 "kl.rie"
	rriasp->EC29 = rrsasp[-1].rrt_term.ps;
#line 539 "kl.rie"
	rriasp->EC30 = rriasp[-2].EC78;
#line 656 "kl.rie"
	rriasp->EC39 = rriasp[-2].EC75;
#line 655 "kl.rie"
	rriasp->EC40 = rrsasp[-1].rrt_term.sps;
#line 655 "kl.rie"
	rriasp->EC41 = rrsasp[-1].rrt_term.ps;
#line 657 "kl.rie"
	rriasp->EC42 = rriasp[-2].EC78;
#line 499 "kl.rie"
	rriasp->EC43 = rriasp[-2].EC75;
#line 498 "kl.rie"
	rriasp->EC44 = rrsasp[-1].rrt_term.sps;
#line 498 "kl.rie"
	rriasp->EC45 = rrsasp[-1].rrt_term.ps;
#line 499 "kl.rie"
	rriasp->EC46 = rriasp[-2].EC78;
#line 534 "kl.rie"
	rriasp->EC55 = rriasp[-2].EC75;
#line 533 "kl.rie"
	rriasp->EC56 = rrsasp[-1].rrt_term.sps;
#line 533 "kl.rie"
	rriasp->EC57 = rrsasp[-1].rrt_term.ps;
#line 535 "kl.rie"
	rriasp->EC58 = rriasp[-2].EC78;
#line 546 "kl.rie"
	rriasp->EC67 = rriasp[-2].EC75;
#line 545 "kl.rie"
	rriasp->EC68 = rrsasp[-1].rrt_term.sps;
#line 545 "kl.rie"
	rriasp->EC69 = rrsasp[-1].rrt_term.ps;
#line 547 "kl.rie"
	rriasp->EC70 = rriasp[-2].EC78;
#line 660 "kl.rie"
	rriasp->EC75 = rriasp[-2].EC75;
#line 659 "kl.rie"
	rriasp->EC76 = rrsasp[-1].rrt_term.sps;
#line 659 "kl.rie"
	rriasp->EC77 = rrsasp[-1].rrt_term.ps;
#line 662 "kl.rie"
	rriasp->EC78 = rriasp[-2].EC78;
#line 542 "kl.rie"
	rriasp->EC79 = rriasp[-2].EC75;
#line 541 "kl.rie"
	rriasp->EC80 = rrsasp[-1].rrt_term.sps;
#line 541 "kl.rie"
	rriasp->EC81 = rrsasp[-1].rrt_term.ps;
#line 543 "kl.rie"
	rriasp->EC82 = rriasp[-2].EC78;
	break;

      case 236:
#line 309 "kl.rie"
	rriasp->EC17 = rriasp[-1].EC15;
	break;

      case 239:
#line 301 "kl.rie"
	rriasp->EC13 = rriasp[-1].EC13;
#line 301 "kl.rie"
	rriasp->EC14 = rriasp[-1].EC13;
	break;

      case 274:
#line 315 "kl.rie"
	rriasp->EC18 = rriasp[-1].EC17;
	break;

      case 275:
#line 309 "kl.rie"
	rriasp->EC19 = rriasp[-2].EC15;
	break;

      case 286:
#line 376 "kl.rie"
	rrlasp->C0.sp_58 = rriasp[-1].EC18->NewSubProc();
#line 319 "kl.rie"
	rriasp->EC22 = rriasp[-1].EC18;
#line 377 "kl.rie"
	rriasp->EC27 = rriasp[-1].EC18;
#line 378 "kl.rie"
	rriasp->EC28 = rrlasp->C0.sp_58;
#line 379 "kl.rie"
	rriasp->EC29 =NULL;
#line 382 "kl.rie"
	rriasp->EC30 =0;
	break;

      case 288:
#line 328 "kl.rie"
	rriasp->EC20 = rriasp[-1].EC19;
	break;

      case 296:
#line 319 "kl.rie"
	rriasp->EC18 = rriasp[-2].EC18;
	break;

      case 298:
#line 332 "kl.rie"
	rriasp->EC21 = rriasp[-1].EC20;
#line 335 "kl.rie"
	rriasp->EC26 = rriasp[-1].EC20;
#line 369 "kl.rie"
	rriasp->EC27 = rriasp[-1].EC20;
#line 368 "kl.rie"
	rriasp->EC28 =NULL;
#line 368 "kl.rie"
	rriasp->EC29 =NULL;
#line 370 "kl.rie"
	rriasp->EC30 =99999;
#line 666 "kl.rie"
	rriasp->EC39 = rriasp[-1].EC20;
#line 665 "kl.rie"
	rriasp->EC40 =NULL;
#line 665 "kl.rie"
	rriasp->EC41 =NULL;
#line 667 "kl.rie"
	rriasp->EC42 =99999;
#line 499 "kl.rie"
	rriasp->EC43 = rriasp[-1].EC20;
#line 498 "kl.rie"
	rriasp->EC44 =NULL;
#line 498 "kl.rie"
	rriasp->EC45 =NULL;
#line 499 "kl.rie"
	rriasp->EC46 =99999;
#line 534 "kl.rie"
	rriasp->EC55 = rriasp[-1].EC20;
#line 533 "kl.rie"
	rriasp->EC56 =NULL;
#line 533 "kl.rie"
	rriasp->EC57 =NULL;
#line 535 "kl.rie"
	rriasp->EC58 =99999;
#line 546 "kl.rie"
	rriasp->EC67 = rriasp[-1].EC20;
#line 545 "kl.rie"
	rriasp->EC68 =NULL;
#line 545 "kl.rie"
	rriasp->EC69 =NULL;
#line 547 "kl.rie"
	rriasp->EC70 =99999;
#line 542 "kl.rie"
	rriasp->EC79 = rriasp[-1].EC20;
#line 541 "kl.rie"
	rriasp->EC80 =NULL;
#line 541 "kl.rie"
	rriasp->EC81 =NULL;
#line 543 "kl.rie"
	rriasp->EC82 =99999;
#line 342 "kl.rie"
	rriasp->EC83 = rriasp[-1].EC20;
#line 343 "kl.rie"
	rriasp->EC84 =NULL;
#line 344 "kl.rie"
	rriasp->EC85 =NULL;
#line 345 "kl.rie"
	rriasp->EC86 =99999;
#line 355 "kl.rie"
	rriasp->EC87 = rriasp[-1].EC20;
#line 356 "kl.rie"
	rriasp->EC88 =NULL;
#line 357 "kl.rie"
	rriasp->EC89 =NULL;
#line 358 "kl.rie"
	rriasp->EC90 =99999;
#line 337 "kl.rie"
	rriasp->EC91 = rriasp[-1].EC20;
#line 338 "kl.rie"
	rriasp->EC92 =NULL;
#line 339 "kl.rie"
	rriasp->EC93 =NULL;
#line 340 "kl.rie"
	rriasp->EC94 =99999;
	break;

      case 307:
#line 639 "kl.rie"
	rriasp->EC31 = rriasp[-1].EC79;
#line 638 "kl.rie"
	rriasp->EC32 = rriasp[-1].EC80;
#line 638 "kl.rie"
	rriasp->EC33 = rriasp[-1].EC81;
#line 640 "kl.rie"
	rriasp->EC34 = rriasp[-1].EC82+ 1;
	break;

      case 308:
#line 332 "kl.rie"
	rriasp->EC20 = rriasp[-2].EC20;
	break;

      case 316:
#line 380 "kl.rie"
	rriasp->EC23 = rrsasp[-2].rrt_functor.sps;
	break;

      case 320:
#line 369 "kl.rie"
	rriasp->EC95 = rriasp[-2].EC91;
	break;

      case 321:
#line 538 "kl.rie"
	rriasp->EC27 = rriasp[-2].EC83;
#line 537 "kl.rie"
	rriasp->EC28 = rrsasp[-1].rrt_term.sps;
#line 537 "kl.rie"
	rriasp->EC29 = rrsasp[-1].rrt_term.ps;
#line 539 "kl.rie"
	rriasp->EC30 = rriasp[-2].EC86;
#line 666 "kl.rie"
	rriasp->EC39 = rriasp[-2].EC83;
#line 665 "kl.rie"
	rriasp->EC40 = rrsasp[-1].rrt_term.sps;
#line 665 "kl.rie"
	rriasp->EC41 = rrsasp[-1].rrt_term.ps;
#line 668 "kl.rie"
	rriasp->EC42 = rriasp[-2].EC86;
#line 499 "kl.rie"
	rriasp->EC43 = rriasp[-2].EC83;
#line 498 "kl.rie"
	rriasp->EC44 = rrsasp[-1].rrt_term.sps;
#line 498 "kl.rie"
	rriasp->EC45 = rrsasp[-1].rrt_term.ps;
#line 499 "kl.rie"
	rriasp->EC46 = rriasp[-2].EC86;
#line 534 "kl.rie"
	rriasp->EC55 = rriasp[-2].EC83;
#line 533 "kl.rie"
	rriasp->EC56 = rrsasp[-1].rrt_term.sps;
#line 533 "kl.rie"
	rriasp->EC57 = rrsasp[-1].rrt_term.ps;
#line 535 "kl.rie"
	rriasp->EC58 = rriasp[-2].EC86;
#line 546 "kl.rie"
	rriasp->EC67 = rriasp[-2].EC83;
#line 545 "kl.rie"
	rriasp->EC68 = rrsasp[-1].rrt_term.sps;
#line 545 "kl.rie"
	rriasp->EC69 = rrsasp[-1].rrt_term.ps;
#line 547 "kl.rie"
	rriasp->EC70 = rriasp[-2].EC86;
#line 542 "kl.rie"
	rriasp->EC79 = rriasp[-2].EC83;
#line 541 "kl.rie"
	rriasp->EC80 = rrsasp[-1].rrt_term.sps;
#line 541 "kl.rie"
	rriasp->EC81 = rrsasp[-1].rrt_term.ps;
#line 543 "kl.rie"
	rriasp->EC82 = rriasp[-2].EC86;
	break;

      case 343:
#line 749 "kl.rie"
	rriasp->EC96 = rrsasp[-1].rrInteger.value;
#line 748 "kl.rie"
	rriasp->EC97 = rriasp[-3].EC95;
#line 752 "kl.rie"
	rriasp->EC98 = rrsasp[-1].rrInteger.value;
#line 752 "kl.rie"
	rriasp->EC99 = rriasp[-3].EC95;
	break;

      case 347:
#line 754 "kl.rie"
	rriasp->EC96 = rriasp[-1].EC96;
#line 754 "kl.rie"
	rriasp->EC97 = rriasp[-1].EC97;
#line 752 "kl.rie"
	rriasp->EC98 = rriasp[-1].EC96;
#line 752 "kl.rie"
	rriasp->EC99 = rriasp[-1].EC97;
	break;

    }



#line 425 "/usr/local/lib/rie-1.0.6/rie.simple"
  if (yyssp >= yyss + yystacksize - 1)
    {
      /* Give user a chance to reallocate the stack */
      /* Use copies of these so that the &'s don't force the real ones into memory. */
#ifdef NOT_RIE
      YYSTYPE *yyvs1 = yyvs;
#endif
      short *yyss1 = yyss;
#ifdef YYLSP_NEEDED
      YYLTYPE *yyls1 = yyls;
#endif

#ifdef RIE_SOME_SYNTHESIZE
      rrsastype *rrss1 = rrss;
#endif

#ifdef RIE_SOME_INHERIT
      rriastype *rris1 = rris;
#endif

#ifdef RIE_SOME_LOCAL
      rrlastype *rrls1 = rrls;
#endif
      
      /* Get the current used size of the three stacks, in elements.  */
      int size = yyssp - yyss + 1;

#ifdef yyoverflow
      /* Each stack pointer address is followed by the size of
	 the data in use in that stack, in bytes.  */
#ifdef YYLSP_NEEDED
      /* This used to be a conditional around just the two extra args,
	 but that might be undefined if yyoverflow is a macro.  */
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
#ifdef NOT_RIE
		 &yyvs1, size * sizeof (*yyvsp),
#endif
		 &yyls1, size * sizeof (*yylsp),
#ifdef RIE_SOME_SYNTHESIZE
		 &rrss1, size * sizeof (*rrsasp),
#endif
#ifdef RIE_SOME_INHERIT
		 &rris1, size * sizeof (*rriasp),
#endif
#ifdef RIE_SOME_LOCAL
		 &rrls1, size * sizeof (*rrlasp),
#endif
		 &yystacksize);
#else
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
#ifdef NOT_RIE
		 &yyvs1, size * sizeof (*yyvsp),
#endif
#ifdef RIE_SOME_SYNTHESIZE
		 &rrss1, size * sizeof (*rrsasp),
#endif
#ifdef RIE_SOME_INHERIT
		 &rris1, size * sizeof (*rriasp),
#endif
#ifdef RIE_SOME_LOCAL
		 &rrls1, size * sizeof (*rrlasp),
#endif
		 &yystacksize);
#endif

      yyss = yyss1;
#ifdef YYLSP_NEEDED
      yyls = yyls1;
#endif
#ifdef RIE_SOME_SYNTHESIZE
      rrss = rrss1;
#endif
#ifdef RIE_SOME_INHERIT
      rris = rris1;
#endif
#ifdef RIE_SOME_LOCAL
      rrls = rrls1;
#endif

#else /* no yyoverflow */
      /* Extend the stack our own way.  */
      if (yystacksize >= YYMAXDEPTH)
	{
	  yyerror("parser stack overflow");
	  return 2;
	}
      yystacksize *= 2;
      if (yystacksize > YYMAXDEPTH)
	yystacksize = YYMAXDEPTH;
      yyss = (short *) alloca (yystacksize * sizeof (*yyssp));
      __yy_memcpy ((char *)yyss1, (char *)yyss, size * sizeof (*yyssp));
#ifdef NOT_RIE
      yyvs = (YYSTYPE *) alloca (yystacksize * sizeof (*yyvsp));
      __yy_memcpy ((char *)yyvs1, (char *)yyvs, size * sizeof (*yyvsp));
#endif
#ifdef YYLSP_NEEDED
      yyls = (YYLTYPE *) alloca (yystacksize * sizeof (*yylsp));
      __yy_memcpy ((char *)yyls1, (char *)yyls, size * sizeof (*yylsp));
#endif
#ifdef RIE_SOME_SYNTHESIZE
      rrss = (rrsastype *) alloca (yystacksize * sizeof (*rrsasp));
      __yy_memcpy ((char *)rrss1, (char *)rrss, size * sizeof (*rrsasp));
#endif
#ifdef RIE_SOME_INHERIT
      rris = (rriastype *) alloca (yystacksize * sizeof (*rriasp));
      __yy_memcpy ((char *)rris1, (char *)rris, size * sizeof (*rriasp));
#endif
#ifdef RIE_SOME_LOCAL
      rrls = (rrlastype *) alloca (yystacksize * sizeof (*rrlasp));
      __yy_memcpy ((char *)rrls1, (char *)rrls, size * sizeof (*rrlasp));
#endif	/* RIE_SOME_LOCAL */
      	
#endif /* no yyoverflow */

      yyssp = yyss + size - 1;
#ifdef NOT_RIE
      yyvsp = yyvs + size - 1;
#endif
#ifdef YYLSP_NEEDED
      yylsp = yyls + size - 1;
#endif

#ifdef RIE_SOME_SYNTHESIZE
      rrsasp = rrss + size -1;
#endif
#ifdef RIE_SOME_INHERIT
      rriasp = rris + size -1;
#endif
#ifdef RIE_SOME_LOCAL
      rrlasp = rrls + size -1;
#endif	/* RIE_SOME_LOCAL */
       
#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Stack size increased to %d\n", yystacksize);
#endif

      if (yyssp >= yyss + yystacksize - 1)
	YYABORT;
    }

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Entering state %d\n", yystate);
#endif

  goto yybackup;
 yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* yychar is either YYEMPTY or YYEOF
     or a valid token in external form.  */

  if (yychar == YYEMPTY)
    {
#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Reading a token: ");
#endif
      yychar = YYLEX;
    }

  /* Convert token to internal form (in yychar1) for indexing tables with */

  if (yychar <= 0)		/* This means end of input. */
    {
      yychar1 = 0;
      yychar = YYEOF;		/* Don't call YYLEX any more */

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Now at end of input.\n");
#endif
    }
  else
    {
      yychar1 = YYTRANSLATE(yychar);

#if YYDEBUG != 0
      if (yydebug)
	{
	  fprintf (stderr, "Next token is %d (%s", yychar, yytname[yychar1]);
	  /* Give the individual parser a way to print the precise meaning
	     of a token, for further debugging info.  */
#ifdef YYPRINT
	  YYPRINT (stderr, yychar, yylval);
#endif
	  fprintf (stderr, ")\n");
	}
#endif
    }

  yyn += yychar1;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != yychar1)
    goto yydefault;

  yyn = yytable[yyn];

  /* yyn is what to do for this token type in this state.
     Negative => reduce, -yyn is rule number.
     Positive => shift, yyn is new state.
       New state is final state => don't bother to shift,
       just return success.
     0, or most negative number => error.  */

  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrlab;

  if (yyn == YYFINAL)
    {
#ifdef RIE_SOME_SYNTHESIZE
      rrlval = *--rrsasp;	/* return the last synthesized value.  */
#endif
    YYACCEPT;
    }

  /* Shift the lookahead token.  */

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting token %d (%s), ", yychar, yytname[yychar1]);
#endif

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

#ifdef NOT_RIE
  *++yyvsp = yylval;
#endif
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

#ifdef RIE_SOME_SYNTHESIZE
  *++rrsasp = rrlval;	/* 'rrlval' is returned by YYLEX.  */
#endif

  /* count tokens shifted since error; after three, turn off error status.  */
  if (yyerrstatus) yyerrstatus--;

  yystate = yyn;
  goto yynewstate;

/* Do the default action for the current state.  */
yydefault:

  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;

/* Do a reduction.  yyn is the number of a rule to reduce with.  */
yyreduce:
  yylen = yyr2[yyn];
#ifdef NOT_RIE
  if (yylen > 0)
    yyval = yyvsp[1-yylen]; /* implement default value of the action */
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      int i;

      fprintf (stderr, "Reducing via rule %d (line %d), ",
	       yyn, yyrline[yyn]);

      /* Print the symbols being reduced, and their result.  */
      for (i = yyprhs[yyn]; yyrhs[i] > 0; i++)
	fprintf (stderr, "%s ", yytname[yyrhs[i]]);
      fprintf (stderr, " -> %s\n", yytname[yyr1[yyn]]);
    }
#endif

  /*									*/
  /*  synthesized attribute evaluation. 'rrval' is assigned here.	*/
  /*									*/
  switch (yyn)
    {
      case 6:
#line 166 "kl.rie"
	procRegister( rrsasp->rrprocess.proc);
	break;

      case 8:
#line 179 "kl.rie"
	{
		    if ( rrsasp[-1].rrSymbol.name == get_symbol("module")) {
		      current_module =  rrsasp->rrSymbol.name;
		      printf("MODULE = %s\n", current_module);
		    }
		  }
	break;

      case 9:
#line 189 "kl.rie"
	rrval.rrprocess.proc = rrsasp[-5].rrprocdef.proc;
	break;

      case 10:
#line 197 "kl.rie"
	rrval.rrprocdef.proc =new Proc(current_module, rrsasp[-3].rrOpt_SYMBOL.name, rrsasp[-2].rrproc_type.t, rrsasp[-1].rrarrange_info.arrange);
#line 199 "kl.rie"
	printf("defining %s : %s\n",current_module, rrsasp[-3].rrOpt_SYMBOL.name);
	break;

      case 11:
#line 202 "kl.rie"
	rrval.rrarrange_info.arrange =expand_default;
	break;

      case 12:
#line 204 "kl.rie"
	rrval.rrarrange_info.arrange =expand_rightward;
	break;

      case 13:
#line 206 "kl.rie"
	rrval.rrarrange_info.arrange =expand_downward;
	break;

      case 16:
#line 212 "kl.rie"
	rrval.rrproc_type.t =PROC_TYPE_CREATOR;
	break;

      case 17:
#line 214 "kl.rie"
	rrval.rrproc_type.t =PROC_TYPE_NORMAL;
	break;

      case 20:
#line 228 "kl.rie"
	 rriasp[-5].EC1->AddPort((NAMETYPE)get_symbol( rrsasp[-3].rrOpt_VARIABLE.name), rrsasp[-2].rrport_type.type, rrsasp[-1].rrleft_or_right.lr, rrsasp->rrpoint_size.l, rrsasp->rrpoint_size.t, rrsasp->rrpoint_size.w, rrsasp->rrpoint_size.h);
	break;

      case 21:
#line 237 "kl.rie"
	 rriasp[-5].EC1->AddComment( rrsasp[-1].rrInteger.value, rrsasp->rrInteger.value, rrsasp[-3].rrString.str);
	break;

      case 25:
#line 252 "kl.rie"
	rrval.rrruledef.rule = rriasp[-3].EC4->NewRule( rrsasp[-1].rrInteger.value, rrsasp->rrrule_type.rt);
	break;

      case 26:
#line 255 "kl.rie"
	rrval.rrrule_type.rt =rule_network;
	break;

      case 27:
#line 257 "kl.rie"
	rrval.rrrule_type.rt =rule_vanishing;
	break;

      case 28:
#line 259 "kl.rie"
	rrval.rrrule_type.rt =rule_continuous;
	break;

      case 29:
#line 261 "kl.rie"
	rrval.rrrule_type.rt =rule_continuous;
	break;

      case 32:
#line 272 "kl.rie"
	{  rriasp[-1].EC6->SetPoint( rrsasp->rrpoint_size.l,
						      rrsasp->rrpoint_size.t);
			     rriasp[-1].EC6->SetSize( rrsasp->rrpoint_size.w,
						     rrsasp->rrpoint_size.h); }
	break;

      case 33:
#line 277 "kl.rie"
	rrval.rrhead.arity = rrsasp->rrt_functor.arity;
#line 276 "kl.rie"
	rrval.rrhead.name = rrsasp->rrt_functor.name;
	break;

      case 44:
#line 312 "kl.rie"
	 rriasp[-5].EC16->SetRuleNum( rrsasp[-2].rrInteger.value);
	break;

      case 54:
#line 352 "kl.rie"
	 rriasp[-3].EC21->UnifyPorts( rrsasp->rrInteger.value, rrsasp[-2].rrt_unify.ps);
	break;

      case 56:
#line 365 "kl.rie"
	 rriasp[-6].EC26->AddLink( rrsasp[-1].rrInteger.value, rrsasp->rrInteger.value);
	break;

      case 57:
#line 368 "kl.rie"
	rrval.rrt_merge.ps = rrsasp[-2].rrt_functor.ps;
#line 368 "kl.rie"
	rrval.rrt_merge.sps = rrsasp[-2].rrt_functor.sps;
	break;

      case 58:
#line 381 "kl.rie"
	rrval.rrsubproc.sp = rrsasp->rrsubproc_info.sps;
#line 389 "kl.rie"
	{ if ( rrsasp[-3].rrt_functor.module)
		               rrlasp[-4].C0.sp_58->SetModule( rrsasp[-3].rrt_functor.module);
		            else
		               rrlasp[-4].C0.sp_58->SetModule(current_module);
		             rrlasp[-4].C0.sp_58->SetName( rrsasp[-3].rrt_functor.name);
			     rrlasp[-4].C0.sp_58->SetArity( rrsasp[-3].rrt_functor.arity);
			     rriasp[-4].EC22->AddBody( rrlasp[-4].C0.sp_58); }
	break;

      case 59:
#line 393 "kl.rie"
	rrval.rrsubproc_info.sps = rriasp->EC23;
	break;

      case 60:
#line 395 "kl.rie"
	rrval.rrsubproc_info.sps = rriasp[-1].EC23;
#line 399 "kl.rie"
	{  rriasp[-1].EC23->SetPoint( rrsasp->rrpoint_size.l,
						        rrsasp->rrpoint_size.t);
			     rriasp[-1].EC23->SetSize( rrsasp->rrpoint_size.w,
						       rrsasp->rrpoint_size.h); }
	break;

      case 61:
#line 402 "kl.rie"
	rrval.rrsubproc_info.sps = rriasp[-2].EC23;
	break;

      case 68:
#line 425 "kl.rie"
	rrval.rrpoint_size.h = rrsasp->rrInteger.value;
#line 424 "kl.rie"
	rrval.rrpoint_size.w = rrsasp[-1].rrInteger.value;
#line 423 "kl.rie"
	rrval.rrpoint_size.t = rrsasp[-3].rrInteger.value;
#line 422 "kl.rie"
	rrval.rrpoint_size.l = rrsasp[-4].rrInteger.value;
	break;

      case 86:
#line 448 "kl.rie"
	rrval.rrfunctor.arity = rrsasp->rrargument.num;
#line 447 "kl.rie"
	rrval.rrfunctor.name = rrsasp[-1].rrSymbol.name;
	break;

      case 88:
#line 453 "kl.rie"
	rrval.rrargument.num =0;
	break;

      case 89:
#line 455 "kl.rie"
	rrval.rrargument.num = rrsasp[-1].rrargs.num;
	break;

      case 90:
#line 458 "kl.rie"
	rrval.rrargs.num =1;
	break;

      case 91:
#line 460 "kl.rie"
	rrval.rrargs.num = rrsasp->rrargs.num+ 1;
	break;

      case 116:
#line 498 "kl.rie"
	rrval.rrt_term.ps = rrsasp->rrt_term_info.ps;
#line 498 "kl.rie"
	rrval.rrt_term.sps = rrsasp->rrt_term_info.sps;
	break;

      case 117:
#line 512 "kl.rie"
	rrval.rrt_term_info.ps = rrlasp[-1].C1.port_117;
#line 510 "kl.rie"
	rrval.rrt_term_info.sps = rriasp[-1].EC48;
#line 523 "kl.rie"
	{ 
		     rrlasp[-1].C1.port_117->name   =  rrsasp->rrport_info.name;
		     rrlasp[-1].C1.port_117->id     =  rrsasp->rrport_info.id;
		     rrlasp[-1].C1.port_117->type   =  rrsasp->rrport_info.type;
		     rrlasp[-1].C1.port_117->lr     =  rrsasp->rrport_info.lr;
		     rrlasp[-1].C1.port_117->left   =  rrsasp->rrport_info.l;
		     rrlasp[-1].C1.port_117->top    =  rrsasp->rrport_info.t;
		     rrlasp[-1].C1.port_117->width  =  rrsasp->rrport_info.w;
		     rrlasp[-1].C1.port_117->height =  rrsasp->rrport_info.h;
		     rrlasp[-1].C1.port_117->next   =  rriasp[-1].EC49; // make list
		  }
	break;

      case 118:
#line 526 "kl.rie"
	rrval.rrt_term_info.ps = rriasp->EC49;
#line 526 "kl.rie"
	rrval.rrt_term_info.sps = rriasp->EC48;
	break;

      case 119:
#line 528 "kl.rie"
	rrval.rrt_term_info.ps = rriasp[-1].EC49;
#line 528 "kl.rie"
	rrval.rrt_term_info.sps = rriasp[-1].EC48;
	break;

      case 120:
#line 530 "kl.rie"
	rrval.rrt_term_info.ps = rriasp[-1].EC49;
#line 530 "kl.rie"
	rrval.rrt_term_info.sps = rriasp[-1].EC48;
	break;

      case 121:
#line 533 "kl.rie"
	rrval.rrt_term_body.ps = rrsasp->rrt_list.ps;
#line 533 "kl.rie"
	rrval.rrt_term_body.sps = rrsasp->rrt_list.sps;
	break;

      case 122:
#line 537 "kl.rie"
	rrval.rrt_term_body.ps = rrsasp->rrt_functor.ps;
#line 537 "kl.rie"
	rrval.rrt_term_body.sps = rrsasp->rrt_functor.sps;
	break;

      case 123:
#line 541 "kl.rie"
	rrval.rrt_term_body.ps = rrsasp->rrt_structure.ps;
#line 541 "kl.rie"
	rrval.rrt_term_body.sps = rrsasp->rrt_structure.sps;
	break;

      case 124:
#line 545 "kl.rie"
	rrval.rrt_term_body.ps = rrsasp->rrt_vector.ps;
#line 545 "kl.rie"
	rrval.rrt_term_body.sps = rrsasp->rrt_vector.sps;
	break;

      case 125:
#line 549 "kl.rie"
	rrval.rrt_term_body.ps = rriasp[-1].EC45;
#line 549 "kl.rie"
	rrval.rrt_term_body.sps = rriasp[-1].EC44;
	break;

      case 126:
#line 551 "kl.rie"
	rrval.rrt_term_body.ps = rriasp[-1].EC45;
#line 551 "kl.rie"
	rrval.rrt_term_body.sps = rriasp[-1].EC44;
	break;

      case 127:
#line 553 "kl.rie"
	rrval.rrt_term_body.ps = rriasp[-4].EC45;
#line 553 "kl.rie"
	rrval.rrt_term_body.sps = rriasp[-4].EC44;
	break;

      case 128:
#line 556 "kl.rie"
	rrval.rrt_list.ps = rrsasp[-1].rrt_list_contents.ps;
#line 556 "kl.rie"
	rrval.rrt_list.sps = rrsasp[-1].rrt_list_contents.sps;
	break;

      case 129:
#line 561 "kl.rie"
	rrval.rrt_list_contents.ps = rriasp->EC61;
#line 561 "kl.rie"
	rrval.rrt_list_contents.sps = rriasp->EC60;
	break;

      case 130:
#line 563 "kl.rie"
	rrval.rrt_list_contents.ps = rrsasp->rrt_list_elements.ps;
#line 563 "kl.rie"
	rrval.rrt_list_contents.sps = rrsasp->rrt_list_elements.sps;
	break;

      case 131:
#line 567 "kl.rie"
	rrval.rrt_list_contents.ps = rrsasp->rrt_term.ps;
#line 567 "kl.rie"
	rrval.rrt_list_contents.sps = rrsasp->rrt_term.sps;
	break;

      case 132:
#line 573 "kl.rie"
	rrval.rrt_list_elements.ps = rrsasp->rrt_term.ps;
#line 573 "kl.rie"
	rrval.rrt_list_elements.sps = rrsasp->rrt_term.sps;
	break;

      case 133:
#line 577 "kl.rie"
	rrval.rrt_list_elements.ps = rrsasp->rrt_list_elements.ps;
#line 577 "kl.rie"
	rrval.rrt_list_elements.sps = rrsasp->rrt_list_elements.sps;
	break;

      case 134:
#line 588 "kl.rie"
	rrval.rrt_functor.arity = rrsasp->rrt_argument.num;
#line 587 "kl.rie"
	rrval.rrt_functor.name = rrsasp[-1].rrSymbol.name;
#line 586 "kl.rie"
	rrval.rrt_functor.module = rrsasp[-1].rrSymbol.module;
#line 583 "kl.rie"
	rrval.rrt_functor.ps = rrsasp->rrt_argument.ps;
#line 583 "kl.rie"
	rrval.rrt_functor.sps = rrsasp->rrt_argument.sps;
	break;

      case 135:
#line 592 "kl.rie"
	rrval.rrt_argument.num =0;
#line 591 "kl.rie"
	rrval.rrt_argument.ps = rriasp->EC33;
#line 591 "kl.rie"
	rrval.rrt_argument.sps = rriasp->EC32;
	break;

      case 136:
#line 596 "kl.rie"
	rrval.rrt_argument.num = rrsasp[-1].rrt_args.num;
#line 594 "kl.rie"
	rrval.rrt_argument.ps = rrsasp[-1].rrt_args.ps;
#line 594 "kl.rie"
	rrval.rrt_argument.sps = rrsasp[-1].rrt_args.sps;
	break;

      case 137:
#line 603 "kl.rie"
	rrval.rrt_args.num =1;
#line 600 "kl.rie"
	rrval.rrt_args.ps = rrsasp->rrt_arg.ps;
#line 600 "kl.rie"
	rrval.rrt_args.sps = rrsasp->rrt_arg.sps;
	break;

      case 138:
#line 609 "kl.rie"
	rrval.rrt_args.num = rrsasp->rrt_args.num+ 1;
#line 605 "kl.rie"
	rrval.rrt_args.ps = rrsasp->rrt_args.ps;
#line 605 "kl.rie"
	rrval.rrt_args.sps = rrsasp->rrt_args.sps;
	break;

      case 139:
#line 616 "kl.rie"
	rrval.rrt_arg.ps =( rriasp[-1].EC54==1)?NULL: rrsasp->rrt_term.ps;
#line 612 "kl.rie"
	rrval.rrt_arg.sps = rrsasp->rrt_term.sps;
#line 634 "kl.rie"
	{
//		    printf("t_arg: t_arg.level = %d, t_term.ps = %x\n",
//			   t_arg.level, t_term.ps);
		    if ( rriasp[-1].EC54 == 1) {
		      int subproc_id;
		      if ( rriasp[-1].EC52 == NULL)
			subproc_id = -1; // in head
		      else
			subproc_id =  rriasp[-1].EC52->GetID();
		      if ( rrsasp->rrt_term.ps != NULL) {
			 rriasp[-1].EC51->AddPort(subproc_id,  rrsasp->rrt_term.ps);
			if ( rrsasp->rrt_term.ps->next != NULL) {
			   rriasp[-1].EC51->UnifyPorts( rrsasp->rrt_term.ps->id,
						  rrsasp->rrt_term.ps->next);
			}
		      }
		    }
		  }
	break;

      case 140:
#line 638 "kl.rie"
	rrval.rrt_structure.ps = rrsasp->rrt_argument.ps;
#line 638 "kl.rie"
	rrval.rrt_structure.sps = rrsasp->rrt_argument.sps;
	break;

      case 141:
#line 643 "kl.rie"
	rrval.rrt_vector.ps = rrsasp[-1].rrt_vector_contents.ps;
#line 643 "kl.rie"
	rrval.rrt_vector.sps = rrsasp[-1].rrt_vector_contents.sps;
	break;

      case 142:
#line 648 "kl.rie"
	rrval.rrt_vector_contents.ps = rriasp->EC73;
#line 648 "kl.rie"
	rrval.rrt_vector_contents.sps = rriasp->EC72;
	break;

      case 143:
#line 650 "kl.rie"
	rrval.rrt_vector_contents.ps = rrsasp->rrt_vector_elements.ps;
#line 650 "kl.rie"
	rrval.rrt_vector_contents.sps = rrsasp->rrt_vector_elements.sps;
	break;

      case 144:
#line 655 "kl.rie"
	rrval.rrt_vector_elements.ps = rrsasp->rrt_term.ps;
#line 655 "kl.rie"
	rrval.rrt_vector_elements.sps = rrsasp->rrt_term.sps;
	break;

      case 145:
#line 659 "kl.rie"
	rrval.rrt_vector_elements.ps = rrsasp->rrt_vector_elements.ps;
#line 659 "kl.rie"
	rrval.rrt_vector_elements.sps = rrsasp->rrt_vector_elements.sps;
	break;

      case 146:
#line 665 "kl.rie"
	rrval.rrt_unify.ps = rrsasp->rrt_term.ps;
#line 665 "kl.rie"
	rrval.rrt_unify.sps = rrsasp->rrt_term.sps;
	break;

      case 147:
#line 671 "kl.rie"
	rrval.rrt_assign.ps = rriasp[-3].EC89;
#line 671 "kl.rie"
	rrval.rrt_assign.sps = rriasp[-3].EC88;
	break;

      case 148:
#line 686 "kl.rie"
	rrval.rrport_info.h =0;
#line 685 "kl.rie"
	rrval.rrport_info.w =0;
#line 684 "kl.rie"
	rrval.rrport_info.t =0;
#line 683 "kl.rie"
	rrval.rrport_info.l =0;
#line 682 "kl.rie"
	rrval.rrport_info.lr = rrsasp->rrleft_or_right.lr;
#line 681 "kl.rie"
	rrval.rrport_info.type = rrsasp[-1].rrport_type.type;
#line 680 "kl.rie"
	rrval.rrport_info.id = rrsasp[-2].rrInteger.value;
#line 679 "kl.rie"
	rrval.rrport_info.name =(NAMETYPE)get_symbol( rrsasp[-3].rrOpt_VARIABLE.name);
	break;

      case 149:
#line 695 "kl.rie"
	rrval.rrport_info.h = rrsasp->rrpoint_size.h;
#line 694 "kl.rie"
	rrval.rrport_info.w = rrsasp->rrpoint_size.w;
#line 693 "kl.rie"
	rrval.rrport_info.t = rrsasp->rrpoint_size.t;
#line 692 "kl.rie"
	rrval.rrport_info.l = rrsasp->rrpoint_size.l;
#line 691 "kl.rie"
	rrval.rrport_info.lr = rrsasp[-1].rrleft_or_right.lr;
#line 690 "kl.rie"
	rrval.rrport_info.type = rrsasp[-2].rrport_type.type;
#line 689 "kl.rie"
	rrval.rrport_info.id = rrsasp[-3].rrInteger.value;
#line 688 "kl.rie"
	rrval.rrport_info.name =(NAMETYPE)get_symbol( rrsasp[-4].rrOpt_VARIABLE.name);
	break;

      case 150:
#line 705 "kl.rie"
	rrval.rrport_info.h = rrsasp->rrpoint_size.h;
#line 704 "kl.rie"
	rrval.rrport_info.w = rrsasp->rrpoint_size.w;
#line 703 "kl.rie"
	rrval.rrport_info.t = rrsasp->rrpoint_size.t;
#line 702 "kl.rie"
	rrval.rrport_info.l = rrsasp->rrpoint_size.l;
#line 701 "kl.rie"
	rrval.rrport_info.lr = rrsasp[-5].rrleft_or_right.lr;
#line 700 "kl.rie"
	rrval.rrport_info.type = rrsasp[-6].rrport_type.type;
#line 699 "kl.rie"
	rrval.rrport_info.id = rrsasp[-7].rrInteger.value;
#line 698 "kl.rie"
	rrval.rrport_info.name =(NAMETYPE)get_symbol( rrsasp[-3].rrOpt_VARIABLE.name);
	break;

      case 151:
#line 714 "kl.rie"
	rrval.rrport_info.h = rrsasp->rrpoint_size.h;
#line 713 "kl.rie"
	rrval.rrport_info.w = rrsasp->rrpoint_size.w;
#line 712 "kl.rie"
	rrval.rrport_info.t = rrsasp->rrpoint_size.t;
#line 711 "kl.rie"
	rrval.rrport_info.l = rrsasp->rrpoint_size.l;
#line 710 "kl.rie"
	rrval.rrport_info.lr = rrsasp[-1].rrleft_or_right.lr;
#line 709 "kl.rie"
	rrval.rrport_info.type = rrsasp[-2].rrport_type.type;
#line 708 "kl.rie"
	rrval.rrport_info.id =-1;
#line 707 "kl.rie"
	rrval.rrport_info.name =(NAMETYPE)get_symbol( rrsasp[-3].rrOpt_VARIABLE.name);
	break;

      case 152:
#line 723 "kl.rie"
	rrval.rrport_info.h =0;
#line 722 "kl.rie"
	rrval.rrport_info.w =0;
#line 721 "kl.rie"
	rrval.rrport_info.t =0;
#line 720 "kl.rie"
	rrval.rrport_info.l =0;
#line 719 "kl.rie"
	rrval.rrport_info.lr = rrsasp[-1].rrleft_or_right.lr;
#line 718 "kl.rie"
	rrval.rrport_info.type = rrsasp[-2].rrport_type.type;
#line 717 "kl.rie"
	rrval.rrport_info.id =-1;
#line 716 "kl.rie"
	rrval.rrport_info.name =(NAMETYPE)get_symbol( rrsasp[-3].rrOpt_VARIABLE.name);
	break;

      case 153:
#line 726 "kl.rie"
	rrval.rrport_type.type =port_single_in;
	break;

      case 154:
#line 728 "kl.rie"
	rrval.rrport_type.type =port_single_out;
	break;

      case 155:
#line 730 "kl.rie"
	rrval.rrport_type.type =port_stream_in;
	break;

      case 156:
#line 732 "kl.rie"
	rrval.rrport_type.type =port_stream_out;
	break;

      case 157:
#line 735 "kl.rie"
	rrval.rrleft_or_right.lr =Port_Null;
	break;

      case 158:
#line 737 "kl.rie"
	rrval.rrleft_or_right.lr =Port_Left;
	break;

      case 159:
#line 739 "kl.rie"
	rrval.rrleft_or_right.lr =Port_Right;
	break;

      case 167:
#line 758 "kl.rie"
	 rriasp[-1].EC99->AddLink( rriasp[-1].EC98, rrsasp->rrInteger.value);
	break;

      case 168:
#line 766 "kl.rie"
	window_set_state(WINDOW_STATE_DEAD);
	break;

      case 171:
#line 782 "kl.rie"
	{ update( rrsasp[-5].rrtr_goalid.id,
				    rrsasp[-4].rrtr_action.act,
				    rrsasp[-2].rrtr_head.t,
				    rrsasp[-1].rrtr_subgoal_part.sg);
			    // printf("ACCEPT(type %s)\n", ActType_to_str(tr_action.act));
			    if (window_get_state() != WINDOW_STATE_RUNNING)
			      return 1;	// XXX
			    if (tracing_mode != TRACE_LOGFILE) // XXX
			      subprocess_send("\n");	       // XXX
			  }
	break;

      case 172:
#line 787 "kl.rie"
	rrval.rrtr_head.module =((term_functor*) rrsasp->rrtr_functor.t)->GetModule();
#line 786 "kl.rie"
	rrval.rrtr_head.t = rrsasp->rrtr_functor.t;
	break;

      case 173:
#line 790 "kl.rie"
	rrval.rrtr_goalid.id = rrsasp->rrInteger.value;
	break;

      case 174:
#line 795 "kl.rie"
	rrval.rrtr_action.act =str_to_ActType( rrsasp->rrVariable.name);
	break;

      case 175:
#line 799 "kl.rie"
	rrval.rrtr_term.t = rrsasp->rrtr_functor.t;
	break;

      case 176:
#line 803 "kl.rie"
	rrval.rrtr_term.t =env_getvar( rrsasp->rrVariable.name);
	break;

      case 177:
#line 806 "kl.rie"
	rrval.rrtr_term.t =alloc_term_integer( rrsasp->rrInteger.value);
	break;

      case 178:
#line 808 "kl.rie"
	rrval.rrtr_term.t = rrsasp->rrtr_list.t;
	break;

      case 179:
#line 816 "kl.rie"
	rrval.rrtr_functor.arity = rrsasp->rrtr_argument.num;
#line 815 "kl.rie"
	rrval.rrtr_functor.name = rrsasp[-1].rrSymbol.name;
#line 814 "kl.rie"
	rrval.rrtr_functor.module = rrsasp[-1].rrSymbol.module;
#line 813 "kl.rie"
	rrval.rrtr_functor.t = rrsasp->rrtr_argument.ts;
#line 817 "kl.rie"
	{ ((RFUNCTYPE)  rrsasp->rrtr_argument.ts)->SetArity( rrsasp->rrtr_argument.num); }
	break;

      case 180:
#line 822 "kl.rie"
	rrval.rrtr_argument.ts = rriasp->EC100;
#line 821 "kl.rie"
	rrval.rrtr_argument.num =0;
	break;

      case 181:
#line 825 "kl.rie"
	rrval.rrtr_argument.ts = rrsasp[-1].rrtr_args.ts;
#line 824 "kl.rie"
	rrval.rrtr_argument.num = rrsasp[-1].rrtr_args.num;
	break;

      case 182:
#line 829 "kl.rie"
	rrval.rrtr_args.ts = rrsasp->rrtr_arg.ts;
#line 828 "kl.rie"
	rrval.rrtr_args.num =1;
	break;

      case 183:
#line 832 "kl.rie"
	rrval.rrtr_args.ts = rrsasp->rrtr_args.ts;
#line 831 "kl.rie"
	rrval.rrtr_args.num = rrsasp->rrtr_args.num+ 1;
	break;

      case 184:
#line 836 "kl.rie"
	rrval.rrtr_arg.ts = rriasp[-1].EC101;
#line 835 "kl.rie"
	{ ((RFUNCTYPE)  rriasp[-1].EC101)->AppendArg( rrsasp->rrtr_term.t);}
	break;

      case 185:
#line 839 "kl.rie"
	rrval.rrtr_list.t = rrsasp[-1].rrtr_list_contents.th;
	break;

      case 186:
#line 843 "kl.rie"
	rrval.rrtr_list_contents.tt =(RCONSTYPE)NIL;
#line 842 "kl.rie"
	rrval.rrtr_list_contents.th =(RCONSTYPE)NIL;
	break;

      case 187:
#line 846 "kl.rie"
	rrval.rrtr_list_contents.tt = rrsasp->rrtr_list_elements.tt;
#line 845 "kl.rie"
	rrval.rrtr_list_contents.th = rrsasp->rrtr_list_elements.th;
#line 847 "kl.rie"
	 rrsasp->rrtr_list_elements.tt->SetCdr(NIL);
	break;

      case 188:
#line 850 "kl.rie"
	rrval.rrtr_list_contents.tt = rrsasp[-2].rrtr_list_elements.tt;
#line 849 "kl.rie"
	rrval.rrtr_list_contents.th = rrsasp[-2].rrtr_list_elements.th;
#line 851 "kl.rie"
	 rrsasp[-2].rrtr_list_elements.tt->SetCdr( rrsasp->rrtr_term.t);
	break;

      case 189:
#line 854 "kl.rie"
	rrlasp->C2.cell_189 =new term_cons( rrsasp->rrtr_term.t,NIL);
#line 856 "kl.rie"
	rrval.rrtr_list_elements.tt = rrlasp->C2.cell_189;
#line 855 "kl.rie"
	rrval.rrtr_list_elements.th = rrlasp->C2.cell_189;
	break;

      case 190:
#line 859 "kl.rie"
	rrlasp->C3.cell_190 =new term_cons( rrsasp[-2].rrtr_term.t, rrsasp->rrtr_list_elements.th);
#line 861 "kl.rie"
	rrval.rrtr_list_elements.tt = rrsasp->rrtr_list_elements.tt;
#line 860 "kl.rie"
	rrval.rrtr_list_elements.th = rrlasp->C3.cell_190;
	break;

      case 191:
#line 863 "kl.rie"
	rrval.rrtr_subgoal_part.sg =NULL;
	break;

      case 192:
#line 865 "kl.rie"
	rrval.rrtr_subgoal_part.sg = rrsasp->rrtr_subgoals.g;
	break;

      case 193:
#line 869 "kl.rie"
	rrval.rrtr_subgoals.g = rrsasp->rrtr_subgoal.g;
	break;

      case 194:
#line 872 "kl.rie"
	rrval.rrtr_subgoals.g = rrsasp[-1].rrtr_subgoal.g;
#line 876 "kl.rie"
	{ //printf("Set next of %d\n", tr_subgoal.g->GetID());
			     rrsasp[-1].rrtr_subgoal.g->SetNext( rrsasp->rrtr_subgoals.g); }
	break;

      case 195:
#line 884 "kl.rie"
	rrval.rrtr_subgoal.g =new rsubgoal( rrsasp[-4].rrtr_goalid.id, rrsasp[-3].rrInteger.value,':', rrsasp[-1].rrtr_sub_state.state, rrsasp->rrtr_term.t);
#line 887 "kl.rie"
	{ if (((term_functor*) rrsasp->rrtr_term.t)->GetModule() == NULL) 
		            ((term_functor*) rrsasp->rrtr_term.t)->SetModule( rriasp[-5].EC105);
		  }
	break;

      case 196:
#line 894 "kl.rie"
	rrval.rrtr_subgoal.g =new rsubgoal( rrsasp[-4].rrtr_goalid.id, rrsasp[-3].rrInteger.value,'!', rrsasp[-1].rrtr_sub_state.state, rrsasp->rrtr_term.t);
#line 897 "kl.rie"
	{ if (((term_functor *) rrsasp->rrtr_term.t)->GetModule() == NULL) 
		  ((term_functor*) rrsasp->rrtr_term.t)->SetModule( rriasp[-5].EC105);
		  }
	break;

      case 197:
#line 901 "kl.rie"
	rrval.rrtr_sub_state.state ='+';
	break;

      case 198:
#line 903 "kl.rie"
	rrval.rrtr_sub_state.state ='-';
	break;

    }


#line 725 "/usr/local/lib/rie-1.0.6/rie.simple"

   /* the action file gets copied in in place of this dollarsign */
#line 728 "bison.simple"
#line 729 "/usr/local/lib/rie-1.0.6/rie.simple"

#ifdef NOT_RIE
  yyvsp -= yylen;
#endif
  yyssp -= yylen;
#ifdef YYLSP_NEEDED
  yylsp -= yylen;
#endif
#ifdef RIE_SOME_SYNTHESIZE
  rrsasp -= yylen;
#endif
#ifdef RIE_SOME_INHERIT
  rriasp -= yylen;
#endif
#ifdef RIE_SOME_LOCAL
  rrlasp -= yylen;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

#ifdef NOT_RIE
  *++yyvsp = yyval;
#endif

#ifdef RIE_SOME_SYNTHESIZE
  *++rrsasp = rrval;
#endif

#ifdef YYLSP_NEEDED
  yylsp++;
  if (yylen == 0)
    {
      yylsp->first_line = yylloc.first_line;
      yylsp->first_column = yylloc.first_column;
      yylsp->last_line = (yylsp-1)->last_line;
      yylsp->last_column = (yylsp-1)->last_column;
      yylsp->text = 0;
    }
  else
    {
      yylsp->last_line = (yylsp+yylen-1)->last_line;
      yylsp->last_column = (yylsp+yylen-1)->last_column;
    }
#endif

  /* Now "shift" the result of the reduction.
     Determine what state that goes to,
     based on the state we popped back to
     and the rule number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTBASE] + *yyssp;
  if (yystate >= 0 && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTBASE];

  goto yynewstate;

yyerrlab:   /* here on detecting error */

  if (! yyerrstatus)
    /* If not already recovering from an error, report this error.  */
    {
      ++yynerrs;

#ifdef YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (yyn > YYFLAG && yyn < YYLAST)
	{
	  int size = 0;
	  char *msg;
	  int x, count;

	  count = 0;
	  /* Start X at -yyn if nec to avoid negative indexes in yycheck.  */
	  for (x = (yyn < 0 ? -yyn : 0);
	       x < (sizeof(yytname) / sizeof(char *)); x++)
	    if (yycheck[x + yyn] == x)
	      size += strlen(yytname[x]) + 15, count++;
	  msg = (char *) malloc(size + 15);
	  if (msg != 0)
	    {
	      strcpy(msg, "parse error");

	      if (count < 5)
		{
		  count = 0;
		  for (x = (yyn < 0 ? -yyn : 0);
		       x < (sizeof(yytname) / sizeof(char *)); x++)
		    if (yycheck[x + yyn] == x)
		      {
			strcat(msg, count == 0 ? ", expecting `" : " or `");
			strcat(msg, yytname[x]);
			strcat(msg, "'");
			count++;
		      }
		}
	      yyerror(msg);
	      free(msg);
	    }
	  else
	    yyerror ("parse error; also virtual memory exceeded");
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror("parse error");
    }

  goto yyerrlab1;
yyerrlab1:   /* here on error raised explicitly by an action */

  if (yyerrstatus == 3)
    {
      /* if just tried and failed to reuse lookahead token after an error, discard it.  */

      /* return failure if at end of input */
      if (yychar == YYEOF)
	YYABORT;

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Discarding token %d (%s).\n", yychar, yytname[yychar1]);
#endif

      yychar = YYEMPTY;
    }

  /* Else will try to reuse lookahead token
     after shifting the error token.  */

  yyerrstatus = 3;		/* Each real token shifted decrements this */

  goto yyerrhandle;

yyerrdefault:  /* current state does not do anything special for the error token. */

#if 0
  /* This is wrong; only states that explicitly want error tokens
     should shift them.  */
  yyn = yydefact[yystate];  /* If its default is to accept any token, ok.  Otherwise pop it.*/
  if (yyn) goto yydefault;
#endif

yyerrpop:   /* pop the current state because it cannot handle the error token */

  if (yyssp == yyss) YYABORT;
#ifdef NOT_RIE
  yyvsp--;
#endif
  yystate = *--yyssp;
#ifdef YYLSP_NEEDED
  yylsp--;
#endif
#ifdef RIE_SOME_SYNTHESIZE
  rrsasp--;
#endif
#ifdef RIE_SOME_INHERIT
  rriasp--;
#endif
#ifdef RIE_SOME_LOCAL
  rrlasp--;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "Error: state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

yyerrhandle:

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yyerrdefault;

  yyn += YYTERROR;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != YYTERROR)
    goto yyerrdefault;

  yyn = yytable[yyn];
  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrpop;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrpop;

  if (yyn == YYFINAL)
    {
#ifdef RIE_SOME_SYNTHESIZE
      rrlval = *--rrsasp;	/* return the last synthesized value.  */
#endif
    YYACCEPT;
    }

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting error token, ");
#endif

#ifdef NOT_RIE
  *++yyvsp = yylval;
#endif
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

#ifdef RIE_SOME_SYNTHESIZE
  *++rrsasp = rrlval;
#endif
  
  yystate = yyn;
  goto yynewstate;
}
#line 905 "kl.rie"


/* eof */
