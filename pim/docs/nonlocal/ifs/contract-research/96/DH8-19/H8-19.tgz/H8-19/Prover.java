/*
 * Copyright (C) 1997 Hidemoto Nakada, Yoshiki Kinoshita, Koichi Takahashi
 */
/*
  Line connects two points.
  The relations must be maintained. 
*/

import java.awt.*;
import java.applet.*;

import java.util.Vector;
import java.util.Hashtable;

public class Prover extends Applet {
    public void init() {
	setLayout(new BorderLayout());
	MassagePanel mp = new MassagePanel("", 200, 20, Color.black, Color.white);
	String tick = getParameter("autoDemoTick");
	String ad = getParameter("autoDemo");
	DrawPanel dp = new DrawPanel(mp, ad, tick);
	add("Center", dp);
	add("North", mp);
	add("South",new DrawControls(dp));
    }

    public boolean handleEvent(Event e) {
	switch (e.id) {
	  case Event.WINDOW_DESTROY:
	    System.exit(0);
	    return true;
	  default:
	    return false;
	}
    }

    public static void main(String args[]) {
	Frame f = new Frame("DrawTest");
	Prover drawTest = new Prover();
	drawTest.init();
	drawTest.start();

	f.add("Center", drawTest);
	f.resize(300, 300);
	f.show();
    }
}


	
