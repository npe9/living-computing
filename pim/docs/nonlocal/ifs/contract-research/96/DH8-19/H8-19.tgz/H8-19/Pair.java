/*
 * Copyright (C) 1997 Hidemoto Nakada, Yoshiki Kinoshita, Koichi Takahashi
 */


public class Pair{
  public Object car;
  public Object cdr;

  public Pair(Object a, Object b){
    car = a;
    cdr = b;
  }

  public String toString(){
    return "Pair [" + car + ", " + cdr + "] ";
  }
}
