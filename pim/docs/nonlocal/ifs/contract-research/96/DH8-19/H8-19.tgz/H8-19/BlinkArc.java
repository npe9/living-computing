/*
 * Copyright (C) 1997 Hidemoto Nakada, Yoshiki Kinoshita, Koichi Takahashi
 */
import java.lang.*;

class BlinkArc implements Tickable {
  DrawPanel p;
  ArcPutable ap;
  boolean toggle;

  public BlinkArc(DrawPanel p, Arc arc){
    this.p = p;
    ap =  new ArcPutable(arc);
    toggle = true;
  }

  public void tick(int i){
    if (toggle){
      p.addVolatile(ap);
      toggle = false;
    } else {
      toggle = true;
    }
    p.repaint();      
  }

  public void last(){
    p.removeVolatile(ap);
    p.repaint();
  }
}
