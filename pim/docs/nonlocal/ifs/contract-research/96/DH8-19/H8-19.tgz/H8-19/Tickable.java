/*
 * Copyright (C) 1997 Hidemoto Nakada, Yoshiki Kinoshita, Koichi Takahashi
 */

interface Tickable {
  public void tick(int i);
  public void last();
}
