/*
 * Copyright (C) 1997 Hidemoto Nakada, Yoshiki Kinoshita, Koichi Takahashi
 */


interface Namable{
  public void name(String s);
  public String getName();
  public boolean compareByName(Namable n);
}
