/*
 * Copyright (C) 1997 Hidemoto Nakada, Yoshiki Kinoshita, Koichi Takahashi
 */
import java.awt.Graphics;
import java.awt.Color;

class ArcPutable implements Putable{
  public Arc arc;

  public ArcPutable (Arc arc){
    this.arc = arc;
  }

  public void put(Graphics g){
    arc.paint(g, Color.white);
  }
}
