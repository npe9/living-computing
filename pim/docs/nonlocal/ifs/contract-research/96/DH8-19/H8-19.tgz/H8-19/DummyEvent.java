/*
 * Copyright (C) 1997 Hidemoto Nakada, Yoshiki Kinoshita, Koichi Takahashi
 */
import java.awt.Event;
import java.awt.Panel;

class DummyEvent{
  public static final int DOWN = 0;
  public static final int DRAG = 1;
  public static final int UP = 2;

  public static final int[] eventMap = {
    Event.MOUSE_DOWN,
    Event.MOUSE_DRAG,
    Event.MOUSE_UP
  };

  public int eventKind;
  public int dpMode;
  public int x;
  public int y;
  public Panel panel;

  public DummyEvent(int a, int b, int c, int d, Panel p){
    eventKind = a;
    dpMode = b;
    x = c;
    y = d;
    panel = p;
  }

  public Event toEvent(){
    return new Event(panel, System.currentTimeMillis(), eventMap[eventKind], x, y, 0, 0);
  }

}
