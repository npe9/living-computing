/*
 * Copyright (C) 1997 Hidemoto Nakada, Yoshiki Kinoshita, Koichi Takahashi
 */
import java.awt.Graphics;

class LoopPutable implements Putable{
  public int x, y;
  public Loop loop;

  public LoopPutable (Loop loop, int x, int y){
    this.loop = loop;
    this.x = x;
    this.y = y;
  }

  public LoopPutable setLocation(int x, int y){
    this.x = x;
    this.y = y;
    return this;
  }

  public void put(Graphics g){
    loop.paint(g, x, y);
  }
}
