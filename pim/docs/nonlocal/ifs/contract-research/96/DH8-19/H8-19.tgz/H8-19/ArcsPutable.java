/*
 * Copyright (C) 1997 Hidemoto Nakada, Yoshiki Kinoshita, Koichi Takahashi
 */
import java.awt.Graphics;
import java.awt.Color;

class ArcsPutable implements Putable{
  public Set arcs;

  public ArcsPutable (Set arcs){
    this.arcs = arcs;
  }

  public void put(Graphics g){
    for (int i = 0; i < arcs.size(); i++)
      ((Arc)arcs.elementAt(i)).paint(g, Color.white);
  }
}
