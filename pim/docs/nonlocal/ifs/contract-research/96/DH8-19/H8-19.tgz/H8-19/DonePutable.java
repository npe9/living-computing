/*
 * Copyright (C) 1997 Hidemoto Nakada, Yoshiki Kinoshita, Koichi Takahashi
 */
import java.awt.Graphics;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Color;
import java.awt.Panel;

class DonePutable implements Putable{
  public MyPoint p;
  public String str;
  public Panel panel;

  public DonePutable (MyPoint p, String str, Panel panel){
    this.p = p;
    this.str = str;
    this.panel = panel;
  }

  public void put(Graphics g){
    Font f = new Font("Helvetica", Font.BOLD, 34);
    FontMetrics fm = panel.getFontMetrics(f);
    int len = fm.stringWidth(str);
    int height = fm.getHeight();
    g.setFont(f);
    g.drawString(str, p.x - (len/2), p.y + (height /2));
  }
}
