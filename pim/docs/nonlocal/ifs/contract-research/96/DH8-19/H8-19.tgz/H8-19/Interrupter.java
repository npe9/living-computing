/*
 * Copyright (C) 1997 Hidemoto Nakada, Yoshiki Kinoshita, Koichi Takahashi
 */
import java.lang.*;



class Interrupter implements Runnable {
  int times;
  int mil;
  Thread current;
  Tickable ti;

  public Interrupter(int times, int mil, Tickable ti){
    this.times = times;
    this.mil = mil;
    this.ti = ti;
    current = new Thread(this);
    current.start();
  }

  public void kill(){
    current.stop();
  }
  public void run(){
    for (int i = 0; i < times; i++){
      ti.tick(i);
      try{
	Thread.currentThread().sleep(mil);
      } catch(Exception e){}
    }
    ti.last();
  }
}
