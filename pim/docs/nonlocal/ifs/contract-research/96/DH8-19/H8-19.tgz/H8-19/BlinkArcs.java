/*
 * Copyright (C) 1997 Hidemoto Nakada, Yoshiki Kinoshita, Koichi Takahashi
 */
import java.lang.*;

class BlinkArcs implements Tickable {
  DrawPanel p;
  ArcsPutable ap;
  boolean toggle;

  public BlinkArcs(DrawPanel p, Set arcs){
    this.p = p;
    ap =  new ArcsPutable(arcs);
    toggle = true;
  }

  public void tick(int i){
    if (toggle){
      p.addVolatile(ap);
      toggle = false;
    } else {
      toggle = true;
    }
    p.repaint();      
  }

  public void last(){
    p.removeVolatile(ap);
    p.repaint();
  }
}
