/* Compiled by KLIC compiler version 2.002 (1997ǯ05��10�� (��) 19��58ʬ16�� JST) */
#include <klic/klichdr.h>
#include <klic/sched.h>
#include "atom.h"
#include "funct.h"
#include <klic/gobj.h>

module module_unify__term__dcode();
Const struct predicate predicate_unify__term__dcode_xunify_2 =
   { module_unify__term__dcode, 0, 2 };
Const struct predicate predicate_unify__term__dcode_xunify__pf_2 =
   { module_unify__term__dcode, 1, 2 };
Const struct predicate predicate_unify__term__dcode_xunify__args_3 =
   { module_unify__term__dcode, 2, 3 };
Const struct predicate predicate_unify__term__dcode_xunify__goal_2 =
   { module_unify__term__dcode, 3, 2 };
Const struct predicate predicate_unify__term__dcode_xresume__check_0 =
   { module_unify__term__dcode, 4, 0 };

module module_unify__term__dcode(glbl, qp, allocp, toppred, stackp)
  struct global_variables *glbl;
  struct threadrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
  register q* stackp;
{
  q a0, a1, a2;

  q *reasonp;
 module_top:
  switch_on_pred() {
    case_pred(0, unify_2_top);
    case_pred(1, unify__pf_2_top);
    case_pred(2, unify__args_3_top);
    case_pred(3, unify__goal_2_top);
    last_case_pred(4, resume__check_0_top);
  }

 unify_2_top: {
  q x0, x1, x2, x3;
  stackp -= 2;
  a0 = stackp[0];
  a1 = stackp[1];
 unify_2_clear_reason:
  reasonp = reasons;
 unify_2_0:
 unify_2_1:
  if (isref(a0)) goto unify_2_4;
  gblt_pfunctor(a0,x0,unify_2_interrupt);
  gblt_arity(a0,x1,unify_2_interrupt);
 unify_2_2:
  if (isref(a1)) goto unify_2_3;
  gblt_pfunctor(a1,x2,unify_2_interrupt);
  gblt_arity(a1,x3,unify_2_interrupt);
  gblt_eq(x1,x3,unify_2_interrupt);
  check_stack(4);
  stackp[0] = x1;
  stackp[1] = a0;
  stackp[2] = a1;
  stackp[3] = (q)(&predicate_unify__term__dcode_xunify__args_3);
  a0 = x0;
  a1 = x2;
  stackp += 4;
  execute(unify__pf_2_0);
  check_stack(3);
  goto unify__pf_2_ext_interrupt;
 unify_2_3:
  deref_and_jump_of_lvalue(a1,unify_2_2);
  *reasonp++ =  a1;
  goto unify_2_interrupt;
 unify_2_4:
  deref_and_jump_of_lvalue(a0,unify_2_1);
  *reasonp++ =  a0;
  goto unify_2_interrupt;
 unify_2_ext_interrupt:
  reasonp = 0l;
 unify_2_interrupt:
  toppred = &predicate_unify__term__dcode_xunify_2;
  goto interrupt_2;
 }

 unify__pf_2_top: {
  stackp -= 2;
  a0 = stackp[0];
  a1 = stackp[1];
 unify__pf_2_clear_reason:
  reasonp = reasons;
 unify__pf_2_0:
 unify__pf_2_1:
  if (isref(a0)) goto unify__pf_2_4;
 unify__pf_2_2:
  if (isref(a1)) goto unify__pf_2_3;
  
         if (isatomic(a0)) {
           if (a0 != a1) goto unify__pf_2_interrupt;
         } else if (isatomic(a1)) {
	   goto unify__pf_2_interrupt;
         } else {
            generic_active_unify(data_objectp(a0),
			         data_objectp(a1),allocp);
         }
  proceed();
 unify__pf_2_3:
  deref_and_jump_of_lvalue(a1,unify__pf_2_2);
  *reasonp++ =  a1;
  goto unify__pf_2_interrupt;
 unify__pf_2_4:
  deref_and_jump_of_lvalue(a0,unify__pf_2_1);
  *reasonp++ =  a0;
  goto unify__pf_2_interrupt;
 unify__pf_2_ext_interrupt:
  reasonp = 0l;
 unify__pf_2_interrupt:
  toppred = &predicate_unify__term__dcode_xunify__pf_2;
  goto interrupt_2;
 }

 unify__args_3_top: {
  q x0, x1, x2;
  stackp -= 3;
  a0 = stackp[0];
  a1 = stackp[1];
  a2 = stackp[2];
 unify__args_3_clear_reason:
  reasonp = reasons;
 unify__args_3_0:
 unify__args_3_1:
  if (!isint(a0)) goto unify__args_3_7;
  gblt_greater(a0,makeint(0L),unify__args_3_6);
 unify__args_3_2:
  if (isref(a1)) goto unify__args_3_5;
  gblt_arg(a0,a1,x0,unify__args_3_6);
 unify__args_3_3:
  if (isref(a2)) goto unify__args_3_4;
  gblt_arg(a0,a2,x1,unify__args_3_6);
  unify(x0, x1);
  bblt_sub_no_check(a0,makeint(1L),x2);
  a0 = x2;
  execute(unify__args_3_0);
  check_stack(4);
  goto unify__args_3_ext_interrupt;
 unify__args_3_4:
  deref_and_jump_of_lvalue(a2,unify__args_3_3);
  *reasonp++ =  a2;
  goto unify__args_3_6;
 unify__args_3_5:
  deref_and_jump_of_lvalue(a1,unify__args_3_2);
  *reasonp++ =  a1;
  goto unify__args_3_6;
 unify__args_3_6:
  if (a0 != makeint(0L)) goto unify__args_3_interrupt;
  proceed();
 unify__args_3_7:
  if (!isref(a0)) goto unify__args_3_interrupt;
  deref_and_jump_of_lvalue(a0,unify__args_3_1);
  *reasonp++ =  a0;
  goto unify__args_3_interrupt;
 unify__args_3_ext_interrupt:
  reasonp = 0l;
 unify__args_3_interrupt:
  toppred = &predicate_unify__term__dcode_xunify__args_3;
  goto interrupt_3;
 }

 unify__goal_2_top: {
  stackp -= 2;
  a0 = stackp[0];
  a1 = stackp[1];
 unify__goal_2_clear_reason:
  reasonp = reasons;
 unify__goal_2_0:
  unify(a0, a1);
  proceed();
 unify__goal_2_ext_interrupt:
  reasonp = 0l;
 unify__goal_2_interrupt:
  toppred = &predicate_unify__term__dcode_xunify__goal_2;
  goto interrupt_2;
 }

 resume__check_0_top: {
		resume_check();
  }
 interrupt_3:
 stackp[2] = a2;
 interrupt_2:
 stackp[1] = a1;
 interrupt_1:
 stackp[0] = a0;
  interrupt_0:
  interrupt_check();
  loop_within_module(module_unify__term__dcode);
}
