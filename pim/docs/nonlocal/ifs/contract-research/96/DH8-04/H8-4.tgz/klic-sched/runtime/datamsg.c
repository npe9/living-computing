/* ----------------------------------------------------------
%        Copyright (C) 1996-1997 Kazuhiko Ohno, Masahiko Ikawa,
%        and Computer Architecture Laboratory, Depertment of
%        Information Science, Kyoto University.
%----------------------------------------------------------- */  

/* ---------------------------------------------------------- 
%   (C)1994,1995 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
/* #define INT_CL_DEBUG */
#include <klic/basic.h>
#include <klic/struct.h>
#include <klic/primitives.h>
#include <klic/unify.h>
#include <klic/functorstuffs.h> 
#include <klic/timing.h>

#include <klic/gb.h>
#include <klic/gobj.h>
#include <klic/susp.h>
#include <klic/functorstuffs.h>
#include <klic/atomstuffs.h>

#include <stdio.h>

#include <klic/interpe.h>

#include <klic/generic.h> 
#include <klic/index.h> 
#include <klic/alloc.h>

#include <klic/distio.h>
#ifdef PACKSEND
#include <klic/ge_exref.h>
#include <pk_macro.h>
#include <pk_struct.h>
#include <packsend.h>
#endif

#include <klic/sched.h>

extern Const long initial_atoms;
extern Const long initial_functors;
q search_exptbl();
extern q exref_g_new();
#ifdef PACKSEND
extern q in_exref_g_new();
extern q out_exref_g_new();
#endif
/* 
  public entry point
  DATA ENCODER			void encode_data(buffer, data, depth)

  specially defined as extern for reference from exref generic object;
  EXREF DECODER			q* decode_exref(inbuf, allocp)
  decode atomic or const	static q* decode_atomic_or_const(inbuf, allocp)
  decode list			static q* decode_list(inbuf, allocp)
  decode funct			static q* decode_funct(inbuf, allocp)
  */

void push_decode_stack();
q pop_decode_stack();

/* decoding data */
/*
  LEVEL0 OBJECTS encoding
  e.g. const, atomic and ref
  */
#ifdef PACKSEND
q*
#else
static q*
#endif
decode_atomic_or_const(inbuf, allocp)
     combuf *inbuf;
     q *allocp;
{
  declare_globals;

  decode_data = (q)GET_BUFFER(inbuf);
  INT_CL_DEBUG_X(PRINT("%d:decode_const_or_atomic (%d)\n", my_node,intval(decode_data)));
  push_decode_stack(decode_data);
  return(allocp);
}

q* decode_exref(inbuf, allocp)
     combuf *inbuf;
     q *allocp;
{
  declare_globals;
  long node;

  node = GET_BUFFER(inbuf);
  if(node == my_node) {
      /* If the data is data exported by myself */
    long index = GET_BUFFER(inbuf);
    long wec   = GET_BUFFER(inbuf);

    decode_data = (q)search_exptbl(index, wec);
		INT_CL_DEBUG_X(PRINT("%d:decode_exref_own_node %x\n", my_node,decode_data));

    push_decode_stack(decode_data);
    return(allocp);

  } else {
      /* If the data is others data */
		q exref_rec;
    generic_arg[0] = makeint(node);  /* PE number */
    generic_arg[1] = makeint(GET_BUFFER(inbuf));  /* exp_table index */
    generic_arg[2] = makeint(GET_BUFFER(inbuf));  /* WEC */

    new_generic(exref_g_new, 3L, decode_data, 0);
		INT_CL_DEBUG_X(PRINT("%d:decode_exref %x\n", my_node,decode_data));
    push_decode_stack(decode_data);
    return(allocp);
  }
}

q* decode_exref_for_outref(inbuf, allocp)
     combuf *inbuf;
     q *allocp;
{
  declare_globals;
  long node;

  INT_CL_DEBUG_X(PRINT("%d:decode_exref\n", my_node));

  node = GET_BUFFER(inbuf);
  if(node == my_node) {
      /* If the data is data exported by myself */
    long index = GET_BUFFER(inbuf);
    long wec   = GET_BUFFER(inbuf);

    decode_data = (q)search_exptbl(index, wec);
    push_decode_stack(decode_data);
    return(allocp);

  } else {
      /* If the data is others data */
		q exref_rec;
    generic_arg[0] = makeint(node);  /* PE number */
    generic_arg[1] = makeint(GET_BUFFER(inbuf));  /* exp_table index */
    generic_arg[2] = makeint(GET_BUFFER(inbuf));  /* WEC */

    new_generic(exref_g_new, 3L, decode_data, 0);
    push_decode_stack(decode_data);
    return(allocp);
  }
}

/*
  decode  STRUCTURED VALUE
  e.g. lists and functors
 */
#ifdef PACKSEND
q*
#else
static q*
#endif
decode_list(inbuf, allocp)
     combuf *inbuf;
     q *allocp;
{
  declare_globals;
  q list;
  module decoder;

  INT_CL_DEBUG_X(PRINT("%d:decode_list\n", my_node));

 loop:
  heapalloc(list, sizeof(struct cons)/sizeof(q), makecons);

  cdr_of(list) = pop_decode_stack();
  car_of(list) = pop_decode_stack();
  push_decode_stack(list);
  return(allocp);
}

#ifdef PACKSEND
q*
#else
static q*
#endif
decode_funct(inbuf, allocp)
     combuf *inbuf;
     q *allocp;
{
  declare_globals;
  q funct, p_funct;
  module decoder;
  int i;

  INT_CL_DEBUG_X(PRINT("%d:decode_funct\n", my_node));

  p_funct = (q)GET_BUFFER(inbuf);

  heapalloc(funct, arityof(p_funct)+1, makefunctor);
  /* if heapover */

  functor_of(funct) = p_funct;
  for(i=arityof(p_funct) ; i > 0; i--){
    arg(funct, i-1) = pop_decode_stack();
  }
  push_decode_stack(funct);
  return(allocp);
}

#ifdef PACKSEND
q *decode_inexref(inbuf, allocp)
	combuf *inbuf;
	q *allocp;
{
	declare_globals;
	long node;

  INT_CL_DEBUG_X(PRINT("%d:decode_inexref\n", my_node));
	
	node = GET_BUFFER(inbuf);
	if(node == my_node) {
		/* $B<+J,$,M"=P$7$?%G!<%?$@$C$?(B */
		
		long index = GET_BUFFER(inbuf);
		long wec = GET_BUFFER(inbuf);
		decode_data = (q)search_exptbl(index,wec);
		push_decode_stack(decode_data);
		BUF_INC(inbuf);
		return(allocp);
	}else{
		/* $BB>%/%i%9%?$N%G!<%?(B */
		
		generic_arg[0] = makeint(node);
		generic_arg[1] = makeint(GET_BUFFER(inbuf));
		generic_arg[2] = makeint(GET_BUFFER(inbuf));
		generic_arg[3] = makeint(GET_BUFFER(inbuf)); /* goal_num */

		new_generic(in_exref_g_new, 4L, decode_data, 0);
		push_decode_stack(decode_data);
		return(allocp);
	}
}

q *decode_outexref(inbuf, allocp)
	combuf *inbuf;
	q *allocp;
{
	declare_globals;
	q data;
	long node;
			
	INT_CL_DEBUG_X(PRINT("%d:decode_outexref\n", my_node));

	node = GET_BUFFER(inbuf);
	if(node == my_node){
		long index = GET_BUFFER(inbuf);
		long wec = GET_BUFFER(inbuf);
		decode_data = (q)search_exptbl(index,wec);
		push_decode_stack(decode_data);
		BUF_INC(inbuf);
		return(allocp);
	}else{
		
		generic_arg[0] = makeint(node);
		generic_arg[1] = makeint(GET_BUFFER(inbuf));
		generic_arg[2] = makeint(GET_BUFFER(inbuf));
		generic_arg[3] = makeint(GET_BUFFER(inbuf));

		new_generic(out_exref_g_new, 4L, decode_data, 0);
		push_decode_stack(decode_data);
		return(allocp);
	}
}
#endif

/*
  encode  STRUCTURED VALUE
  if depth is negative, entire data structures are encoded.
  if depth is zero, only one word structures are encoded.
  */

#define   END_ENCODE_DATA()\
{\
    int i;\
    for(i = 0 ; i < cdrlist ; i++){\
	PUT_BUFFER(buffer, decode_list);\
    }\
}


#ifdef PFIRST
void encode_data(buffer, data, depth, throw)
	combuf *buffer;
	q data;
	long depth;
	int throw;
#else
void encode_data(buffer, data, depth)
	combuf *buffer;
	q data;
	long depth;
#endif
{
  int i,depth_org;
  declare_globals;
  int cdrlist = 0;
/*  depth_org = depth;*/

#ifdef WDEBUG
	{
		char buf[1000];
		char *bufp = buf;
		bufp = sprint_data(data,bufp);
		PRINT("%d: send_data %s \n",my_node,buf);
	}
#endif
	
 again:
  switch (ptagof(data)){
    case ATOMIC:
      if (issym(data) &&
					symval(data) >= initial_atoms+ATOMNUMBERBASE) {
				ioeprintf("initial_atoms %d\n",initial_atoms);
				ioeprintf("symval(data) %d\n",symval(data));
				fatal("cannot send a newly created atom in this version.");
      } else {
				goto Atomic_case;
      } 
      break;
    case CONS:
      if ((q*)data < heaptop ||
					(q*)data >= heaptop+heapsize+incrementsize) {
	  goto Const_case;
      } else if (depth == 0) {
				goto Make_exref;
      } else {
				if (depth > 0)
					depth--;
#ifdef PFIRST
				encode_data(buffer, car_of(data), depth, throw);
#else
				encode_data(buffer, car_of(data), depth);
#endif
				data = cdr_of(data);
				cdrlist++;
				goto again;
				
				/*	  encode_data(buffer, cdr_of(data), depth);	      
			PUT_BUFFER(buffer, decode_list);*/
      }
      break;
    case FUNCTOR:
      if ((q*)data < heaptop ||
					(q*)data >= heaptop+heapsize+incrementsize) {
				goto Const_case;
      } else {
				q f = functor_of(data);
				if (isref(f)) { /* data_object */
					if(depth == 0){
						goto Make_exref;
					} else {
#ifdef PFIRST
						throw_flag = 1;
#endif
						generic_encode((struct data_object *)functorp(data), buffer, depth); 
#ifdef PFIRST
						throw_flag = 0;
#endif
					}
				} else {      /* functor */
					if((symval(f) - FUNCTORNUMBERBASE) >= initial_functors){
						ioeprintf("initial_functors %d\nsymval(data) %d\n",
											initial_functors, symval(f));
						fatal("cannot send a newly created functor in this version.");
					} else if (depth == 0) {
						goto Make_exref;
					} else {
						int arity1 = arityof(functor_of(data));
						if (depth > 0)
							depth--;
						for (i = 0; i < arity1; i++) {
#ifdef PFIRST
							encode_data(buffer, arg(data, i), depth, throw);
#else
							encode_data(buffer, arg(data, i), depth);
#endif
						}
						PUT2_BUFFER(buffer, decode_funct, functor_of(data));  
					}
				}
      }
      break;	   
		case VARREF:
      {
#ifdef PFIRST
				q temp = smask(derefone(data));
#else
				q temp = derefone(data);
#endif
      deref_x:
				if (data != temp){
					if (isref(temp)) {
						q temp1;
						temp1 = derefone(temp);
						if (temp1 == data) {
							struct susprec *sdata = (struct susprec *)temp;
							if(is_generator_susp(sdata->u)){
								/* generator */
								struct generator_susp *genobj = generator_suspp(sdata);
								if(generic_encode
									 (untag_generator_susp(genobj->u.o), buffer, depth)){
									goto Make_exref;
								}
							} else {
								/* consumer, goal */
								goto Make_exref;
							}
						} else {
							/* REF chain continued */
							data = temp;
							temp = temp1;
							goto deref_x;
						}
					} else {
						/* Already instantiated */
						data = temp;
						goto again;
					}
				} else {
					/* Simple variable */
#ifdef PFIRST
					if(data != derefone(data))
						goto Make_exsrec;
					else
						goto Make_exref;
#endif
					goto Make_exref;
				}
      }
      break;
    }
  END_ENCODE_DATA();
  return;
 Make_exref:
  {
		long index = regist_exptbl(data);
		PUT4_BUFFER(buffer, decode_exref, my_node, index, EXPORT_UNIT_WEC);
		END_ENCODE_DATA();
		return;
  }

#ifdef PFIRST
	Make_exsrec:
		{
			long index = regist_exptbl(data);
			struct threadrec *pthread = ((struct scheduling_record*)data)->pthread;
/* 			if(throwing_thread == pthread || current_queue != pthread) 
			if((throw && (throwing_thread == pthread
						|| pthread->next == (struct threadrec*)1)) ||
				 (!throw && current_queue != pthread))
					 derefone(data) = data; */
			if((throw && (throwing_thread == pthread)))
					 derefone(data) = data;

			
			PUT4_BUFFER(buffer, decode_exref, my_node, index, EXPORT_UNIT_WEC);
			END_ENCODE_DATA();
		return;
		}
#endif
	
 Atomic_case:
 Const_case:
  PUT2_BUFFER(buffer, decode_atomic_or_const, data);
  END_ENCODE_DATA();
  return;
}


#ifdef PACKSEND
void pk_encode_data(buffer, data, mode, goal_num)
	combuf *buffer;
	long mode,goal_num;
	q data;
{
	long index, wec;
	declare_globals;
	int cdrlist = 0;

 again:
	switch (ptagof(data)){
	case ATOMIC:
		if(issym(data) &&
			 symval(data) >= initial_atoms+ATOMNUMBERBASE) {
			ioeprintf("initial_atoms %d\n",initial_atoms);
	ioeprintf("symval(data) %d\n",symval(data));
	fatal("cannot send a newly created atom in this version.");
      } else {
				goto Atomic_case;
			}
		break;
	case CONS:
		if ((q*)data < heaptop ||
				(q*)data >= heaptop+heapsize+incrementsize) {
			goto Const_case;
		}else{
			goto Make_exref;
		}
	case FUNCTOR:
		if ((q*)data < heaptop ||
	  (q*)data >= heaptop+heapsize+incrementsize) {
	  goto Const_case;
      } else {
				q f = functor_of(data);
				if(isref(f)) { /*data_object*/
					goto Make_exref;
				}else{ /* functor */
					if((symval(f) - FUNCTORNUMBERBASE) >= initial_functors){
						ioeprintf("initial_functors %d\nsymval(data) %d\n",
											initial_functors, symval(f));
						fatal("cannot send a newly created functor in this version.");
					}else{
						goto Make_exref;
					}
				}
			}
		break;
	case VARREF:
		{
			q temp = derefone(data);
		deref_x:
			if(data != temp){
				if(isref(temp)){
					q temp1 = derefone(temp);
					if (temp1 == data) {
						struct susprec *sdata = (struct susprec *)temp;
						if(is_generator_susp(sdata->u)){
							/*generator*/
							long send_wec;
							struct generator_susp *genobj = generator_suspp(sdata);
							struct exref_object *exref =
								(struct exref_object *)untag_generator_susp(genobj->u.o);

							if(exref->wec < MIN_WEC){
								fatal("illegal WEC in exref object");
							}
							if(exref->wec < MIN_WEC*2){
								goto Make_gobj;
							}
							send_wec = (exref->wec)>>1;
							exref->wec -= send_wec;

							if(mode == MODE_IN){
								PUT5_BUFFER(buffer, decode_inexref, exref->node,
														exref->index, send_wec, goal_num);
							}else if(mode == MODE_OUT){
								struct out_exref_object *outexref =
									(struct out_exref_object *)exref;
								PUT5_BUFFER(buffer, decode_outexref, outexref->node,
														outexref->index,send_wec,outexref->goalnum);
							}else{
								PUT4_BUFFER(buffer, decode_exref, exref->node, 
														exref->index, send_wec);
							}
						}else {
							/* consumer, goal */
							goto Make_exref;
						}
					} else {
						/* REF chain continued */
						data = temp;
						temp = temp1;
						goto deref_x;
					}
				}else {
					/* Already instantiated */
					data = temp;
					goto again;
				}
			} else {
				/* Simple variable */
				goto Make_exref;
			}
		}
		break;
	}
	END_ENCODE_DATA();
	return;

	Atomic_case:
	Const_case:
		PUT2_BUFFER(buffer, decode_atomic_or_const, data);
		END_ENCODE_DATA();
		return;
	Make_exref:
		{
			long index = regist_exptbl(data);
			if(mode == MODE_IN){
				PUT5_BUFFER(buffer, decode_inexref, my_node, index, 
										EXPORT_UNIT_WEC, goal_num);
			}else if(mode == MODE_OUT){
				PUT5_BUFFER(buffer, decode_outexref, my_node, index,
										EXPORT_UNIT_WEC, goal_num);
			}else{
				PUT4_BUFFER(buffer, decode_exref, my_node, index, EXPORT_UNIT_WEC);
			}
			END_ENCODE_DATA();
			return;
		}
 Make_gobj:
		{
			long index = regist_exptbl(data);
			if(mode == MODE_IN){
				PUT5_BUFFER(buffer, decode_inexref, my_node, index, 
										EXPORT_UNIT_WEC, goal_num);
			}else{
				PUT4_BUFFER(buffer, decode_exref, my_node, index, EXPORT_UNIT_WEC);
			}
			END_ENCODE_DATA();
			return;
		}
 Normal_ref:
	{
		long index = regist_exptbl(data);
		PUT4_BUFFER(buffer, decode_exref, my_node, index, EXPORT_UNIT_WEC);
		END_ENCODE_DATA();
		return;
	}
}		
#endif


