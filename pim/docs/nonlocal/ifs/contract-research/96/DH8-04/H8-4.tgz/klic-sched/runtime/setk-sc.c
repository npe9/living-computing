/* Compiled by KLIC compiler version 2.002 (1997ǯ05��10�� (��) 19��58ʬ16�� JST) */
#include <klic/klichdr.h>
#include <klic/sched.h>
#include "atom.h"
#include "funct.h"

module module_keyed__set();
Const struct predicate predicate_keyed__set_xcreate_3 =
   { module_keyed__set, 0, 3 };
Const struct predicate predicate_keyed__set_xcreate_2 =
   { module_keyed__set, 1, 2 };
Const struct predicate predicate_keyed__set_xcreate_1 =
   { module_keyed__set, 2, 1 };
Const struct predicate predicate_keyed__set_xresume__check_0 =
   { module_keyed__set, 3, 0 };
extern Const struct predicate predicate_keyed__sorted__set_xcreate_1;

module module_keyed__set(glbl, qp, allocp, toppred, stackp)
  struct global_variables *glbl;
  struct threadrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
  register q* stackp;
{
  q a0, a1, a2;

  q *reasonp;
 module_top:
  switch_on_pred() {
    case_pred(0, create_3_top);
    case_pred(1, create_2_top);
    case_pred(2, create_1_top);
    last_case_pred(3, resume__check_0_top);
  }

 create_3_top: {
  stackp -= 3;
  a0 = stackp[0];
  a1 = stackp[1];
  a2 = stackp[2];
 create_3_clear_reason:
  reasonp = reasons;
 create_3_0:
  check_stack(2);
  stackp[0] = a1;
  stackp[1] = (q)(&predicate_keyed__sorted__set_xcreate_1);
  stackp += 2;
  proceed();
 create_3_ext_interrupt:
  reasonp = 0l;
 create_3_interrupt:
  toppred = &predicate_keyed__set_xcreate_3;
  goto interrupt_3;
 }

 create_2_top: {
  stackp -= 2;
  a0 = stackp[0];
  a1 = stackp[1];
 create_2_clear_reason:
  reasonp = reasons;
 create_2_0:
  check_stack(2);
  stackp[0] = a0;
  stackp[1] = (q)(&predicate_keyed__sorted__set_xcreate_1);
  stackp += 2;
  proceed();
 create_2_ext_interrupt:
  reasonp = 0l;
 create_2_interrupt:
  toppred = &predicate_keyed__set_xcreate_2;
  goto interrupt_2;
 }

 create_1_top: {
  stackp -= 1;
  a0 = stackp[0];
 create_1_clear_reason:
  reasonp = reasons;
 create_1_0:
  check_stack(2);
  stackp[0] = a0;
  stackp[1] = (q)(&predicate_keyed__sorted__set_xcreate_1);
  stackp += 2;
  proceed();
 create_1_ext_interrupt:
  reasonp = 0l;
 create_1_interrupt:
  toppred = &predicate_keyed__set_xcreate_1;
  goto interrupt_1;
 }

 resume__check_0_top: {
		resume_check();
  }
 interrupt_3:
 stackp[2] = a2;
 interrupt_2:
 stackp[1] = a1;
 interrupt_1:
 stackp[0] = a0;
  interrupt_0:
  interrupt_check();
  loop_within_module(module_keyed__set);
}
