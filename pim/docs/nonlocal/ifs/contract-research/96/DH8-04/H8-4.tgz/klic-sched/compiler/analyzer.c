/* Compiled by KLIC compiler version 2.002 (Tue May 23 13:27:38 JST 1995) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"
q opt_trace_atom_value = makeint(1);
q opt_analyze_dependency = makeint(1);

module module_analyzer();
Const struct predicate predicate_analyzer_xmain_2 =
   { module_analyzer, 0, 2 };
extern Const struct predicate predicate_print_xdatan_1;
extern Const struct predicate predicate_converter_xto__analyze_3;
extern Const struct predicate predicate_converter_xfrom__analyze_2;
extern Const struct predicate predicate_loop_xcheck_2;
extern Const struct predicate predicate_loop_xget__goals_2;
extern Const struct predicate predicate_unify__head__body_xmake__head__body__list_2;
extern Const struct predicate predicate_unify__head__body_xcheck__shared_4;
extern Const struct predicate predicate_dependency_xinit__deps_2;
extern Const struct predicate predicate_dependency_xmake__control__dep_3;
extern Const struct predicate predicate_dependency_xmake__data__dep_5;
extern Const struct predicate predicate_dependency_xindirect_4;
extern Const struct predicate predicate_determine__type_xmain_8;
extern Const struct predicate predicate_schedule_xmain_3;
extern Const struct predicate predicate_direct__call_xmain_2;

module module_analyzer(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  q a0, a1;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    last_case_pred(0, main_2_top);
  }

 main_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18;
  qp = qp->next;
 main_2_clear_reason:
  reasonp = reasons;
 main_2_0:
 main_2_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_normal_2)) goto main_2_interrupt;
  allocp[0] = makesym(functor_normal_2);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = arg(a0, 1);
  x0 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdatan_1);
  allocp[2] = makesym(atom__3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_20Analysis_20End_20_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D);
  allocp[3] = (q)(struct goalrec*)&allocp[0];
  allocp[4] = (q)(&predicate_converter_xfrom__analyze_2);
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = x1;
  allocp[7] = (q)(struct goalrec*)&allocp[3];
  allocp[8] = (q)(&predicate_direct__call_xmain_2);
  allocp[9] = x3 = makeref(&allocp[9]);
  allocp[10] = x2;
  allocp[11] = (q)(struct goalrec*)&allocp[7];
  allocp[12] = (q)(&predicate_print_xdatan_1);
  allocp[13] = makesym(atom__2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_20Optimizing_20Direct_20Jumps_20_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B);
  allocp[14] = (q)(struct goalrec*)&allocp[11];
  allocp[15] = (q)(&predicate_schedule_xmain_3);
  allocp[16] = x4 = makeref(&allocp[16]);
  allocp[17] = x3;
  allocp[18] = x5 = makeref(&allocp[18]);
  allocp[19] = (q)(struct goalrec*)&allocp[14];
  allocp[20] = (q)(&predicate_print_xdatan_1);
  allocp[21] = makesym(atom__2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_20Scheduling_20Goals_20_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B);
  allocp[22] = (q)(struct goalrec*)&allocp[19];
  allocp[23] = (q)(&predicate_dependency_xindirect_4);
  allocp[24] = x4;
  allocp[25] = x6 = makeref(&allocp[25]);
  allocp[26] = x7 = makeref(&allocp[26]);
  allocp[27] = x5;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_print_xdatan_1);
  allocp[30] = makesym(atom__2D_2D_2D_2D_2D_20Analyzing_20Indirect_20Dependencies);
  allocp[31] = (q)(struct goalrec*)&allocp[28];
  allocp[32] = (q)(&predicate_dependency_xmake__data__dep_5);
  allocp[33] = x4;
  allocp[34] = x6;
  allocp[35] = x8 = makeref(&allocp[35]);
  allocp[36] = x7;
  allocp[37] = x9 = makeref(&allocp[37]);
  allocp[38] = (q)(struct goalrec*)&allocp[31];
  allocp[39] = (q)(&predicate_print_xdatan_1);
  allocp[40] = makesym(atom__2D_2D_2D_2D_2D_20Checking_20Direct_20Data_20Dependencies);
  allocp[41] = (q)(struct goalrec*)&allocp[38];
  allocp[42] = (q)(&predicate_dependency_xmake__control__dep_3);
  allocp[43] = x4;
  allocp[44] = x10 = makeref(&allocp[44]);
  allocp[45] = x8;
  allocp[46] = (q)(struct goalrec*)&allocp[41];
  allocp[47] = (q)(&predicate_print_xdatan_1);
  allocp[48] = makesym(atom__2D_2D_2D_2D_2D_20Checking_20Direct_20Control_20Dependencies);
  allocp[49] = (q)(struct goalrec*)&allocp[46];
  allocp[50] = (q)(&predicate_print_xdatan_1);
  allocp[51] = makesym(atom__2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_20Analyzing_20Dependencies_20_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B);
  allocp[52] = (q)(struct goalrec*)&allocp[49];
  allocp[53] = (q)(&predicate_determine__type_xmain_8);
  allocp[54] = x11 = makeref(&allocp[54]);
  allocp[55] = x4;
  allocp[56] = x12 = makeref(&allocp[56]);
  allocp[57] = x6;
  allocp[58] = x13 = makeref(&allocp[58]);
  allocp[59] = x14 = makeref(&allocp[59]);
  allocp[60] = x10;
  allocp[61] = x9;
  allocp[62] = (q)(struct goalrec*)&allocp[52];
  allocp[63] = (q)(&predicate_print_xdatan_1);
  allocp[64] = makesym(atom__2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_20Analyzing_20Variable_20Types_20_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B);
  allocp[65] = (q)(struct goalrec*)&allocp[62];
  allocp[66] = (q)(&predicate_dependency_xinit__deps_2);
  allocp[67] = x11;
  allocp[68] = x14;
  allocp[69] = (q)(struct goalrec*)&allocp[65];
  allocp[70] = (q)(&predicate_loop_xget__goals_2);
  allocp[71] = x11;
  allocp[72] = x9;
  allocp[73] = (q)(struct goalrec*)&allocp[69];
  allocp[74] = (q)(&predicate_unify__head__body_xcheck__shared_4);
  allocp[75] = x15 = makeref(&allocp[75]);
  allocp[76] = x11;
  allocp[77] = x16 = makeref(&allocp[77]);
  allocp[78] = x13;
  allocp[79] = (q)(struct goalrec*)&allocp[73];
  allocp[80] = (q)(&predicate_unify__head__body_xmake__head__body__list_2);
  allocp[81] = x15;
  allocp[82] = x16;
  allocp[83] = (q)(struct goalrec*)&allocp[79];
  allocp[84] = (q)(&predicate_loop_xcheck_2);
  allocp[85] = x17 = makeref(&allocp[85]);
  allocp[86] = x15;
  allocp[87] = (q)(struct goalrec*)&allocp[83];
  allocp[88] = (q)(&predicate_converter_xto__analyze_3);
  x18 = arg(a0, 0);
  allocp[89] = x18;
  allocp[90] = x17;
  allocp[91] = x12;
  allocp[92] = (q)(struct goalrec*)&allocp[87];
  allocp[93] = (q)(&predicate_print_xdatan_1);
  allocp[94] = makesym(atom__2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_20Analyzing_20Program_20Structure_20_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B);
  allocp[95] = (q)(struct goalrec*)&allocp[92];
  allocp[96] = (q)(&predicate_print_xdatan_1);
  allocp[97] = makesym(atom__3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_20Analysis_20Start_20_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D);
  qp = (struct goalrec*)&allocp[95];
  allocp += 98;
  proceed();
 case VARREF:
  deref_and_jump(a0,main_2_1);
  *reasonp++ =  a0;
  goto main_2_interrupt;
  };
  goto main_2_interrupt;
 main_2_ext_interrupt:
  reasonp = 0l;
 main_2_interrupt:
  goto interrupt_2;
 }
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_analyzer);
}
