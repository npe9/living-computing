/* ----------------------------------------------------------
%        Copyright (C) 1996-1997 Kazuhiko Ohno, Masahiko Ikawa,
%        and Computer Architecture Laboratory, Depertment of
%        Information Science, Kyoto University.
%----------------------------------------------------------- */  

#include <stdio.h>
char wbuf[1000];
char *wbufp;

#ifdef MAIN
FILE *logfile;
#else
extern FILE *logfile;
#endif
/* 
#ifdef DIST
#define PRINT ioprintf
#else
#define PRINT printf
#endif
*/

#ifdef WWDEBUG
#ifdef WDEBUG
#define WDEB(X) X; fflush(logfile)
#else
#define WDEB(X)
#endif
#else
#define WDEB(X)
#endif

char *sprint_data();
void print_data();
