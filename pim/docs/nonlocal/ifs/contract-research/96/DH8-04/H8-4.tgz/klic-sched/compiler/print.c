/* Compiled by KLIC compiler version 2.002 (Tue May 23 13:27:38 JST 1995) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_print();
Const struct predicate predicate_print_xmodules_2 =
   { module_print, 0, 2 };
Const struct predicate predicate_print_xclauses_2 =
   { module_print, 1, 2 };
Const struct predicate predicate_print_xgoal_2 =
   { module_print, 2, 2 };
Const struct predicate predicate_print_xguards_2 =
   { module_print, 3, 2 };
Const struct predicate predicate_print_xguards1_2 =
   { module_print, 4, 2 };
Const struct predicate predicate_print_xbodys_2 =
   { module_print, 5, 2 };
Const struct predicate predicate_print_xbodys1_2 =
   { module_print, 6, 2 };
Const struct predicate predicate_print_xmodules__a_2 =
   { module_print, 7, 2 };
Const struct predicate predicate_print_xclauses__a_2 =
   { module_print, 8, 2 };
Const struct predicate predicate_print_xclause__a_4 =
   { module_print, 9, 4 };
Const struct predicate predicate_print_xguards__a_2 =
   { module_print, 10, 2 };
Const struct predicate predicate_print_xguards__a1_4 =
   { module_print, 11, 4 };
Const struct predicate predicate_print_xbodys__a_2 =
   { module_print, 12, 2 };
Const struct predicate predicate_print_xbodys__a1_4 =
   { module_print, 13, 4 };
Const struct predicate predicate_print_xtype__table_2 =
   { module_print, 14, 2 };
Const struct predicate predicate_print_xtype__modules_2 =
   { module_print, 15, 2 };
Const struct predicate predicate_print_xtype__clauses_2 =
   { module_print, 16, 2 };
Const struct predicate predicate_print_xtype__clauses1_4 =
   { module_print, 17, 4 };
Const struct predicate predicate_print_xtype__clause_3 =
   { module_print, 18, 3 };
Const struct predicate predicate_print_xtype__clause1_4 =
   { module_print, 19, 4 };
Const struct predicate predicate_print_xheadbody__table_2 =
   { module_print, 20, 2 };
Const struct predicate predicate_print_xheadbody__modules_2 =
   { module_print, 21, 2 };
Const struct predicate predicate_print_xheadbody__clauses_2 =
   { module_print, 22, 2 };
Const struct predicate predicate_print_xdepends_1 =
   { module_print, 23, 1 };
Const struct predicate predicate_print_xdepends1_1 =
   { module_print, 24, 1 };
Const struct predicate predicate_print_xdata_1 =
   { module_print, 25, 1 };
Const struct predicate predicate_print_xdatan_1 =
   { module_print, 26, 1 };
Const struct predicate predicate_print_xdata_2 =
   { module_print, 27, 2 };
Const struct predicate predicate_print_xdatan_2 =
   { module_print, 28, 2 };
Const struct predicate predicate_print_xlist_2 =
   { module_print, 29, 2 };
Const struct predicate predicate_print_xlist_1 =
   { module_print, 30, 1 };
Const struct predicate predicate_print_xtermn_1 =
   { module_print, 31, 1 };
Const struct predicate predicate_print_xterm_1 =
   { module_print, 32, 1 };
Const struct predicate predicate_print_xterm1_2 =
   { module_print, 33, 2 };
Const struct predicate predicate_print_xterm2_1 =
   { module_print, 34, 1 };
Const struct predicate predicate_print_xterm__arg_3 =
   { module_print, 35, 3 };
Const struct predicate predicate_print_xterm__vector__arg_3 =
   { module_print, 36, 3 };
Const struct predicate predicate_print_xprogram_1 =
   { module_print, 37, 1 };
Const struct predicate predicate_print_xprogram__modules_1 =
   { module_print, 38, 1 };
Const struct predicate predicate_print_xprogram__clauses_1 =
   { module_print, 39, 1 };
Const struct predicate predicate_print_xprogram__clause_1 =
   { module_print, 40, 1 };
Const struct predicate predicate_print_xprogram__goals_1 =
   { module_print, 41, 1 };
Const struct predicate predicate_print_xdeps_1 =
   { module_print, 42, 1 };
Const struct predicate predicate_print_xdeps__modules_1 =
   { module_print, 43, 1 };
Const struct predicate predicate_print_xdeps__clauses_3 =
   { module_print, 44, 3 };
Const struct predicate predicate_print_xdeps__goals_1 =
   { module_print, 45, 1 };
Const struct predicate predicate_print_xdeps__goals_3 =
   { module_print, 46, 3 };
Const struct predicate predicate_print_xmodule__split_1 =
   { module_print, 47, 1 };
Const struct predicate predicate_print_xmodule__split__stdout_2 =
   { module_print, 48, 2 };
Const struct predicate predicate_print_xmodule__split__modules_3 =
   { module_print, 49, 3 };
Const struct predicate predicate_print_xmodule__split__clauses_3 =
   { module_print, 50, 3 };
extern Const struct predicate predicate_print_xdata_1;
extern Const struct predicate predicate_print_xdata_2;
extern Const struct predicate predicate_print_xdatan_1;
extern Const struct predicate predicate_print_xterm_1;
extern Const struct predicate predicate_print_xterm1_2;
extern Const struct predicate predicate_print_xterm__arg_3;
extern Const struct predicate predicate_print_xterm__vector__arg_3;
extern Const struct predicate predicate_print_xprogram__clause_1;
extern Const struct predicate predicate_variable_xunbound_2;
extern Const struct predicate predicate_variable_xwrap_2;
extern Const struct predicate predicate_integer__arithmetics_xadd_3;
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_functor__table_xfunctor_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_io_xoutstream_1;
extern Const struct predicate predicate_klicio_xklicio_1;
declare_method_table_of(vector);

module module_print(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  static Const q cons_const_0[] = {
    NILATOM,
    makesym(atom_nl),
  };
  static Const q funct_const_1[] = {
    makesym(functor_print_1),
    makesym(atom__20),
  };
  static Const q cons_const_2[] = {
    NILATOM,
    makefunctor(funct_const_1),
  };
  static Const q cons_const_3[] = {
    NILATOM,
    makesym(atom_nl),
  };
  static Const q funct_const_4[] = {
    makesym(functor_puttq_1),
    makesym(atom__5D_29_2Catom_28_5B_5D_29_29_29_2E),
  };
  static Const q cons_const_5[] = {
    makecons(cons_const_3),
    makefunctor(funct_const_4),
  };
  static Const q funct_const_6[] = {
    makesym(functor_putt_1),
    makesym(atom__5D_29),
  };
  static Const q funct_const_7[] = {
    makesym(functor_putt_1),
    makesym(atom_functor_28module_28atom_28),
  };
  static Const q funct_const_8[] = {
    makesym(functor_putt_1),
    makesym(atom__29_2Clist_28_5B),
  };
  static Const q funct_const_9[] = {
    makesym(functor_putt_1),
    makesym(atom__5D_29_29_29),
  };
  static Const q funct_const_10[] = {
    makesym(functor_putt_1),
    makesym(atom__7Catom_28_5B_5D_29),
  };
  static Const q funct_const_11[] = {
    makesym(functor_putt_1),
    makesym(atom__7Clist_28_5B),
  };
  static Const q funct_const_12[] = {
    makesym(functor_puttq_1),
    makesym(atom_functor_28normal_28list_28_5B),
  };
  q a0, a1, a2, a3;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  switch_on_pred() {
    case_pred(0, modules_2_top);
    case_pred(1, clauses_2_top);
    case_pred(2, goal_2_top);
    case_pred(3, guards_2_top);
    case_pred(4, guards1_2_top);
    case_pred(5, bodys_2_top);
    case_pred(6, bodys1_2_top);
    case_pred(7, modules__a_2_top);
    case_pred(8, clauses__a_2_top);
    case_pred(9, clause__a_4_top);
    case_pred(10, guards__a_2_top);
    case_pred(11, guards__a1_4_top);
    case_pred(12, bodys__a_2_top);
    case_pred(13, bodys__a1_4_top);
    case_pred(14, type__table_2_top);
    case_pred(15, type__modules_2_top);
    case_pred(16, type__clauses_2_top);
    case_pred(17, type__clauses1_4_top);
    case_pred(18, type__clause_3_top);
    case_pred(19, type__clause1_4_top);
    case_pred(20, headbody__table_2_top);
    case_pred(21, headbody__modules_2_top);
    case_pred(22, headbody__clauses_2_top);
    case_pred(23, depends_1_top);
    case_pred(24, depends1_1_top);
    case_pred(25, data_1_top);
    case_pred(26, datan_1_top);
    case_pred(27, data_2_top);
    case_pred(28, datan_2_top);
    case_pred(29, list_2_top);
    case_pred(30, list_1_top);
    case_pred(31, termn_1_top);
    case_pred(32, term_1_top);
    case_pred(33, term1_2_top);
    case_pred(34, term2_1_top);
    case_pred(35, term__arg_3_top);
    case_pred(36, term__vector__arg_3_top);
    case_pred(37, program_1_top);
    case_pred(38, program__modules_1_top);
    case_pred(39, program__clauses_1_top);
    case_pred(40, program__clause_1_top);
    case_pred(41, program__goals_1_top);
    case_pred(42, deps_1_top);
    case_pred(43, deps__modules_1_top);
    case_pred(44, deps__clauses_3_top);
    case_pred(45, deps__goals_1_top);
    case_pred(46, deps__goals_3_top);
    case_pred(47, module__split_1_top);
    case_pred(48, module__split__stdout_2_top);
    case_pred(49, module__split__modules_3_top);
    last_case_pred(50, module__split__clauses_3_top);
  }

 modules_2_top: {
  q x0, x1, x2, x3, x4;
  a1 = qp->args[1];
  qp = qp->next;
 modules_2_clear_reason:
  reasonp = reasons;
 modules_2_0:
 modules_2_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 modules_2_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto modules_2_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xmodules_2);
  allocp[2] = a0;
  x1 = cdr_of(a1);
  allocp[3] = x1;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_print_xclauses_2);
  allocp[6] = x2 = makeref(&allocp[6]);
  x3 = arg(x0, 1);
  allocp[7] = x3;
  allocp[8] = (q)(struct goalrec*)&allocp[4];
  allocp[9] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[10] = a0;
  allocp[11] = makeint(2L);
  allocp[12] = x2;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_print_xdatan_1);
  x4 = arg(x0, 0);
  allocp[15] = x4;
  allocp[16] = (q)(struct goalrec*)&allocp[13];
  allocp[17] = (q)(&predicate_print_xdata_2);
  allocp[18] = a0;
  allocp[19] = makesym(atom_MODULE_3A);
  qp = (struct goalrec*)&allocp[16];
  allocp += 20;
  proceed();
 case VARREF:
  deref_and_jump(x0,modules_2_2);
  *reasonp++ =  x0;
  goto modules_2_interrupt;
  };
  goto modules_2_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto modules_2_interrupt;
  proceed();
 case VARREF:
  deref_and_jump(a1,modules_2_1);
  *reasonp++ =  a1;
  goto modules_2_interrupt;
  };
  goto modules_2_interrupt;
 modules_2_ext_interrupt:
  reasonp = 0l;
 modules_2_interrupt:
  goto interrupt_2;
 }

 clauses_2_top: {
  q x0, x1, x2, x3, x4, x5;
  a1 = qp->args[1];
  qp = qp->next;
 clauses_2_clear_reason:
  reasonp = reasons;
 clauses_2_0:
 clauses_2_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 clauses_2_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (isint(x0)) goto clauses_2_interrupt;
 clauses_2_3:
  gblt_atom(x0,clauses_2_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xclauses_2);
  allocp[2] = a0;
  x1 = cdr_of(a1);
  allocp[3] = x1;
  a1 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  execute(datan_2_0);
  goto datan_2_ext_interrupt;
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_clause_4)) goto clauses_2_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xclauses_2);
  allocp[2] = a0;
  x1 = cdr_of(a1);
  allocp[3] = x1;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_print_xdatan_2);
  allocp[6] = x2 = makeref(&allocp[6]);
  x3 = arg(x0, 3);
  allocp[7] = x3;
  allocp[8] = (q)(struct goalrec*)&allocp[4];
  allocp[9] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[10] = a0;
  allocp[11] = makeint(8L);
  allocp[12] = x2;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_print_xbodys_2);
  allocp[15] = a0;
  x4 = arg(x0, 2);
  allocp[16] = x4;
  allocp[17] = (q)(struct goalrec*)&allocp[13];
  allocp[18] = (q)(&predicate_print_xguards_2);
  allocp[19] = a0;
  x5 = arg(x0, 1);
  allocp[20] = x5;
  a1 = arg(x0, 0);
  qp = (struct goalrec*)&allocp[17];
  allocp += 21;
  execute(goal_2_0);
  goto goal_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,clauses_2_2);
  *reasonp++ =  x0;
  goto clauses_2_interrupt;
  };
  goto clauses_2_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto clauses_2_interrupt;
  proceed();
 case VARREF:
  deref_and_jump(a1,clauses_2_1);
  *reasonp++ =  a1;
  goto clauses_2_interrupt;
  };
  goto clauses_2_interrupt;
 clauses_2_ext_interrupt:
  reasonp = 0l;
 clauses_2_interrupt:
  goto interrupt_2;
 }

 goal_2_top: {
  q x0, x1;
  a1 = qp->args[1];
  qp = qp->next;
 goal_2_clear_reason:
  reasonp = reasons;
 goal_2_0:
 goal_2_1:
  switch (ptagof(a1)) {
 case FUNCTOR:
  switch (symval(functor_of(a1))) {
 case functor_atom_1:
  a1 = arg(a1, 0);
  execute(datan_2_0);
  goto datan_2_ext_interrupt;
 case functor_functor_1:
  a1 = arg(a1, 0);
  execute(datan_2_0);
  goto datan_2_ext_interrupt;
 case functor_functor_3:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdatan_1);
  allocp[2] = makesym(atom_);
  allocp[3] = (q)(struct goalrec*)&allocp[0];
  allocp[4] = (q)(&predicate_print_xdata_1);
  x0 = arg(a1, 2);
  allocp[5] = x0;
  allocp[6] = (q)(struct goalrec*)&allocp[3];
  allocp[7] = (q)(&predicate_print_xdata_1);
  allocp[8] = makesym(atom__2F);
  allocp[9] = (q)(struct goalrec*)&allocp[6];
  allocp[10] = (q)(&predicate_print_xdata_1);
  x1 = arg(a1, 1);
  allocp[11] = x1;
  allocp[12] = (q)(struct goalrec*)&allocp[9];
  allocp[13] = (q)(&predicate_print_xdata_1);
  allocp[14] = makesym(atom__20_3A_20);
  a1 = arg(a1, 0);
  qp = (struct goalrec*)&allocp[12];
  allocp += 15;
  execute(data_2_0);
  goto data_2_ext_interrupt;
  };
  goto goal_2_interrupt;
 case VARREF:
  deref_and_jump(a1,goal_2_1);
  *reasonp++ =  a1;
  goto goal_2_interrupt;
  };
  goto goal_2_interrupt;
 goal_2_ext_interrupt:
  reasonp = 0l;
 goal_2_interrupt:
  toppred = &predicate_print_xgoal_2;
  goto interrupt_2;
 }

 guards_2_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  qp = qp->next;
 guards_2_clear_reason:
  reasonp = reasons;
 guards_2_0:
 guards_2_1:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xguards1_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  x1 = cdr_of(a1);
  allocp[3] = x1;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[6] = a0;
  allocp[7] = makeint(4L);
  allocp[8] = x0;
  allocp[9] = (q)(struct goalrec*)&allocp[4];
  allocp[10] = (q)(&predicate_print_xgoal_2);
  allocp[11] = makeint(0L);
  x2 = car_of(a1);
  allocp[12] = x2;
  a1 = makesym(atom__20_3A_2D_20);
  qp = (struct goalrec*)&allocp[9];
  allocp += 13;
  execute(data_2_0);
  goto data_2_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto guards_2_interrupt;
  proceed();
 case VARREF:
  deref_and_jump(a1,guards_2_1);
  *reasonp++ =  a1;
  goto guards_2_interrupt;
  };
  goto guards_2_interrupt;
 guards_2_ext_interrupt:
  reasonp = 0l;
 guards_2_interrupt:
  goto interrupt_2;
 }

 guards1_2_top: {
  q x0;
  a1 = qp->args[1];
  qp = qp->next;
 guards1_2_clear_reason:
  reasonp = reasons;
 guards1_2_0:
 guards1_2_1:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xguards1_2);
  allocp[2] = a0;
  x0 = cdr_of(a1);
  allocp[3] = x0;
  a1 = car_of(a1);
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  execute(goal_2_0);
  goto goal_2_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto guards1_2_interrupt;
  proceed();
 case VARREF:
  deref_and_jump(a1,guards1_2_1);
  *reasonp++ =  a1;
  goto guards1_2_interrupt;
  };
  goto guards1_2_interrupt;
 guards1_2_ext_interrupt:
  reasonp = 0l;
 guards1_2_interrupt:
  goto interrupt_2;
 }

 bodys_2_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  qp = qp->next;
 bodys_2_clear_reason:
  reasonp = reasons;
 bodys_2_0:
 bodys_2_1:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xbodys1_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  x1 = cdr_of(a1);
  allocp[3] = x1;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[6] = a0;
  allocp[7] = makeint(4L);
  allocp[8] = x0;
  allocp[9] = (q)(struct goalrec*)&allocp[4];
  allocp[10] = (q)(&predicate_print_xgoal_2);
  allocp[11] = makeint(0L);
  x2 = car_of(a1);
  allocp[12] = x2;
  a1 = makesym(atom__20_20_7C_20);
  qp = (struct goalrec*)&allocp[9];
  allocp += 13;
  execute(data_2_0);
  goto data_2_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto bodys_2_interrupt;
  proceed();
 case VARREF:
  deref_and_jump(a1,bodys_2_1);
  *reasonp++ =  a1;
  goto bodys_2_interrupt;
  };
  goto bodys_2_interrupt;
 bodys_2_ext_interrupt:
  reasonp = 0l;
 bodys_2_interrupt:
  goto interrupt_2;
 }

 bodys1_2_top: {
  q x0;
  a1 = qp->args[1];
  qp = qp->next;
 bodys1_2_clear_reason:
  reasonp = reasons;
 bodys1_2_0:
 bodys1_2_1:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xbodys1_2);
  allocp[2] = a0;
  x0 = cdr_of(a1);
  allocp[3] = x0;
  a1 = car_of(a1);
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  execute(goal_2_0);
  goto goal_2_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto bodys1_2_interrupt;
  proceed();
 case VARREF:
  deref_and_jump(a1,bodys1_2_1);
  *reasonp++ =  a1;
  goto bodys1_2_interrupt;
  };
  goto bodys1_2_interrupt;
 bodys1_2_ext_interrupt:
  reasonp = 0l;
 bodys1_2_interrupt:
  goto interrupt_2;
 }

 modules__a_2_top: {
  q x0, x1, x2, x3, x4;
  a1 = qp->args[1];
  qp = qp->next;
 modules__a_2_clear_reason:
  reasonp = reasons;
 modules__a_2_0:
 modules__a_2_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 modules__a_2_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto modules__a_2_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xmodules__a_2);
  allocp[2] = a0;
  x1 = cdr_of(a1);
  allocp[3] = x1;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_print_xclauses__a_2);
  allocp[6] = x2 = makeref(&allocp[6]);
  x3 = arg(x0, 1);
  allocp[7] = x3;
  allocp[8] = (q)(struct goalrec*)&allocp[4];
  allocp[9] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[10] = a0;
  allocp[11] = makeint(2L);
  allocp[12] = x2;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_print_xdatan_1);
  x4 = arg(x0, 0);
  allocp[15] = x4;
  a1 = makesym(atom_A__MODULE_3A);
  qp = (struct goalrec*)&allocp[13];
  allocp += 16;
  execute(data_2_0);
  goto data_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,modules__a_2_2);
  *reasonp++ =  x0;
  goto modules__a_2_interrupt;
  };
  goto modules__a_2_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto modules__a_2_interrupt;
  proceed();
 case VARREF:
  deref_and_jump(a1,modules__a_2_1);
  *reasonp++ =  a1;
  goto modules__a_2_interrupt;
  };
  goto modules__a_2_interrupt;
 modules__a_2_ext_interrupt:
  reasonp = 0l;
 modules__a_2_interrupt:
  goto interrupt_2;
 }

 clauses__a_2_top: {
  q x0, x1;
  a1 = qp->args[1];
  qp = qp->next;
 clauses__a_2_clear_reason:
  reasonp = reasons;
 clauses__a_2_0:
 clauses__a_2_1:
  if (isref(a1)) goto clauses__a_2_2;
  gblt_pfunctor(a1,x0,clauses__a_2_interrupt);
  gblt_arity(a1,x1,clauses__a_2_interrupt);
  a2 = makeint(1L);
  a3 = x1;
  execute(clause__a_4_0);
  goto clause__a_4_ext_interrupt;
 clauses__a_2_2:
  deref_and_jump(a1,clauses__a_2_1);
  *reasonp++ =  a1;
  goto clauses__a_2_interrupt;
 clauses__a_2_ext_interrupt:
  reasonp = 0l;
 clauses__a_2_interrupt:
  goto interrupt_2;
 }

 clause__a_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 clause__a_4_clear_reason:
  reasonp = reasons;
 clause__a_4_0:
 clause__a_4_1:
  if (!isint(a2)) goto clause__a_4_9;
 clause__a_4_2:
  if (!isint(a3)) goto clause__a_4_8;
  gblt_less_or_eq(a2,a3,clause__a_4_7);
 clause__a_4_3:
  if (isref(a1)) goto clause__a_4_6;
  gblt_arg(a2,a1,x0,clause__a_4_7);
 clause__a_4_4:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (isint(x0)) goto clause__a_4_7;
 clause__a_4_5:
  gblt_atom(x0,clause__a_4_7);
  bblt_sub_no_check_y(a0,makeint(2L),x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xclause__a_4);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[8] = a2;
  allocp[9] = makeint(1L);
  allocp[10] = x2;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_print_xdatan_2);
  allocp[13] = a0;
  allocp[14] = x0;
  allocp[15] = (q)(struct goalrec*)&allocp[11];
  allocp[16] = (q)(&predicate_print_xdata_1);
  allocp[17] = makesym(atom__20);
  a0 = x1;
  a1 = a2;
  qp = (struct goalrec*)&allocp[15];
  allocp += 18;
  execute(data_2_0);
  goto data_2_ext_interrupt;
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_clause_6)) goto clause__a_4_7;
  bblt_sub_no_check_y(a0,makeint(2L),x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xclause__a_4);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[8] = a2;
  allocp[9] = makeint(1L);
  allocp[10] = x2;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_print_xdatan_2);
  allocp[13] = x3 = makeref(&allocp[13]);
  x4 = arg(x0, 5);
  allocp[14] = x4;
  allocp[15] = (q)(struct goalrec*)&allocp[11];
  allocp[16] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[17] = a0;
  allocp[18] = makeint(10L);
  allocp[19] = x3;
  allocp[20] = (q)(struct goalrec*)&allocp[15];
  allocp[21] = (q)(&predicate_print_xdatan_2);
  allocp[22] = x5 = makeref(&allocp[22]);
  x6 = arg(x0, 4);
  allocp[23] = x6;
  allocp[24] = (q)(struct goalrec*)&allocp[20];
  allocp[25] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[26] = a0;
  allocp[27] = makeint(10L);
  allocp[28] = x5;
  allocp[29] = (q)(struct goalrec*)&allocp[24];
  allocp[30] = (q)(&predicate_print_xdatan_2);
  allocp[31] = x7 = makeref(&allocp[31]);
  x8 = arg(x0, 3);
  allocp[32] = x8;
  allocp[33] = (q)(struct goalrec*)&allocp[29];
  allocp[34] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[35] = a0;
  allocp[36] = makeint(8L);
  allocp[37] = x7;
  allocp[38] = (q)(struct goalrec*)&allocp[33];
  allocp[39] = (q)(&predicate_print_xbodys__a_2);
  allocp[40] = a0;
  x9 = arg(x0, 2);
  allocp[41] = x9;
  allocp[42] = (q)(struct goalrec*)&allocp[38];
  allocp[43] = (q)(&predicate_print_xguards__a_2);
  allocp[44] = a0;
  x10 = arg(x0, 1);
  allocp[45] = x10;
  allocp[46] = (q)(struct goalrec*)&allocp[42];
  allocp[47] = (q)(&predicate_print_xgoal_2);
  allocp[48] = a0;
  x11 = arg(x0, 0);
  allocp[49] = x11;
  allocp[50] = (q)(struct goalrec*)&allocp[46];
  allocp[51] = (q)(&predicate_print_xdata_1);
  allocp[52] = makesym(atom__20);
  a0 = x1;
  a1 = a2;
  qp = (struct goalrec*)&allocp[50];
  allocp += 53;
  execute(data_2_0);
  goto data_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,clause__a_4_4);
  *reasonp++ =  x0;
  goto clause__a_4_7;
  };
  goto clause__a_4_7;
 clause__a_4_6:
  deref_and_jump(a1,clause__a_4_3);
  *reasonp++ =  a1;
  goto clause__a_4_7;
 clause__a_4_7:
  gblt_greater(a2,a3,clause__a_4_interrupt);
  proceed();
 clause__a_4_8:
  if (!isref(a3)) goto clause__a_4_interrupt;
  deref_and_jump(a3,clause__a_4_2);
  *reasonp++ =  a3;
  goto clause__a_4_interrupt;
 clause__a_4_9:
  if (!isref(a2)) goto clause__a_4_interrupt;
  deref_and_jump(a2,clause__a_4_1);
  *reasonp++ =  a2;
  goto clause__a_4_interrupt;
 clause__a_4_ext_interrupt:
  reasonp = 0l;
 clause__a_4_interrupt:
  toppred = &predicate_print_xclause__a_4;
  goto interrupt_4;
 }

 guards__a_2_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  qp = qp->next;
 guards__a_2_clear_reason:
  reasonp = reasons;
 guards__a_2_0:
 guards__a_2_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (isint(a1)) goto guards__a_2_3;
 guards__a_2_2:
  gblt_atom(a1,guards__a_2_3);
  a1 = makesym(atom__20_3A_2D_20true);
  execute(datan_2_0);
  goto datan_2_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,guards__a_2_1);
  *reasonp++ =  a1;
  goto guards__a_2_interrupt;
  };
  goto guards__a_2_3;
 guards__a_2_3:
  gblt_pfunctor(a1,x0,guards__a_2_interrupt);
  gblt_arity(a1,x1,guards__a_2_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xguards__a1_4);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = makeint(2L);
  allocp[5] = x1;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[8] = a0;
  allocp[9] = makeint(4L);
  allocp[10] = x2;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_print_xgoal_2);
  allocp[13] = makeint(0L);
  allocp[14] = x3 = makeref(&allocp[14]);
  allocp[15] = (q)(struct goalrec*)&allocp[11];
  allocp[16] = (q)(&predicate_functor__table_xarg_3);
  allocp[17] = makeint(1L);
  allocp[18] = a1;
  allocp[19] = x3;
  a1 = makesym(atom__20_3A_2D_20);
  qp = (struct goalrec*)&allocp[15];
  allocp += 20;
  execute(data_2_0);
  goto data_2_ext_interrupt;
 guards__a_2_ext_interrupt:
  reasonp = 0l;
 guards__a_2_interrupt:
  goto interrupt_2;
 }

 guards__a1_4_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 guards__a1_4_clear_reason:
  reasonp = reasons;
 guards__a1_4_0:
 guards__a1_4_1:
  if (!isint(a2)) goto guards__a1_4_5;
 guards__a1_4_2:
  if (!isint(a3)) goto guards__a1_4_4;
  gblt_less_or_eq(a2,a3,guards__a1_4_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xguards__a1_4);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[8] = a2;
  allocp[9] = makeint(1L);
  allocp[10] = x0;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_print_xgoal_2);
  allocp[13] = a0;
  allocp[14] = x1 = makeref(&allocp[14]);
  allocp[15] = (q)(struct goalrec*)&allocp[11];
  allocp[16] = (q)(&predicate_functor__table_xarg_3);
  allocp[17] = a2;
  allocp[18] = a1;
  allocp[19] = x1;
  qp = (struct goalrec*)&allocp[15];
  allocp += 20;
  proceed();
 guards__a1_4_3:
  gblt_greater(a2,a3,guards__a1_4_interrupt);
  proceed();
 guards__a1_4_4:
  if (!isref(a3)) goto guards__a1_4_interrupt;
  deref_and_jump(a3,guards__a1_4_2);
  *reasonp++ =  a3;
  goto guards__a1_4_interrupt;
 guards__a1_4_5:
  if (!isref(a2)) goto guards__a1_4_interrupt;
  deref_and_jump(a2,guards__a1_4_1);
  *reasonp++ =  a2;
  goto guards__a1_4_interrupt;
 guards__a1_4_ext_interrupt:
  reasonp = 0l;
 guards__a1_4_interrupt:
  goto interrupt_4;
 }

 bodys__a_2_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  qp = qp->next;
 bodys__a_2_clear_reason:
  reasonp = reasons;
 bodys__a_2_0:
 bodys__a_2_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (isint(a1)) goto bodys__a_2_3;
 bodys__a_2_2:
  gblt_atom(a1,bodys__a_2_3);
  a1 = makesym(atom__20_20_7C_20true);
  execute(datan_2_0);
  goto datan_2_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,bodys__a_2_1);
  *reasonp++ =  a1;
  goto bodys__a_2_interrupt;
  };
  goto bodys__a_2_3;
 bodys__a_2_3:
  gblt_pfunctor(a1,x0,bodys__a_2_interrupt);
  gblt_arity(a1,x1,bodys__a_2_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xbodys__a1_4);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = makeint(2L);
  allocp[5] = x1;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[8] = a0;
  allocp[9] = makeint(4L);
  allocp[10] = x2;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_print_xgoal_2);
  allocp[13] = makeint(0L);
  allocp[14] = x3 = makeref(&allocp[14]);
  allocp[15] = (q)(struct goalrec*)&allocp[11];
  allocp[16] = (q)(&predicate_functor__table_xarg_3);
  allocp[17] = makeint(1L);
  allocp[18] = a1;
  allocp[19] = x3;
  a1 = makesym(atom__20_20_7C_20);
  qp = (struct goalrec*)&allocp[15];
  allocp += 20;
  execute(data_2_0);
  goto data_2_ext_interrupt;
 bodys__a_2_ext_interrupt:
  reasonp = 0l;
 bodys__a_2_interrupt:
  goto interrupt_2;
 }

 bodys__a1_4_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 bodys__a1_4_clear_reason:
  reasonp = reasons;
 bodys__a1_4_0:
 bodys__a1_4_1:
  if (!isint(a2)) goto bodys__a1_4_5;
 bodys__a1_4_2:
  if (!isint(a3)) goto bodys__a1_4_4;
  gblt_less_or_eq(a2,a3,bodys__a1_4_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xbodys__a1_4);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[8] = a2;
  allocp[9] = makeint(1L);
  allocp[10] = x0;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_print_xgoal_2);
  allocp[13] = a0;
  allocp[14] = x1 = makeref(&allocp[14]);
  allocp[15] = (q)(struct goalrec*)&allocp[11];
  allocp[16] = (q)(&predicate_functor__table_xarg_3);
  allocp[17] = a2;
  allocp[18] = a1;
  allocp[19] = x1;
  qp = (struct goalrec*)&allocp[15];
  allocp += 20;
  proceed();
 bodys__a1_4_3:
  gblt_greater(a2,a3,bodys__a1_4_interrupt);
  proceed();
 bodys__a1_4_4:
  if (!isref(a3)) goto bodys__a1_4_interrupt;
  deref_and_jump(a3,bodys__a1_4_2);
  *reasonp++ =  a3;
  goto bodys__a1_4_interrupt;
 bodys__a1_4_5:
  if (!isref(a2)) goto bodys__a1_4_interrupt;
  deref_and_jump(a2,bodys__a1_4_1);
  *reasonp++ =  a2;
  goto bodys__a1_4_interrupt;
 bodys__a1_4_ext_interrupt:
  reasonp = 0l;
 bodys__a1_4_interrupt:
  goto interrupt_4;
 }

 type__table_2_top: {
  a1 = qp->args[1];
  qp = qp->next;
 type__table_2_clear_reason:
  reasonp = reasons;
 type__table_2_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdatan_1);
  allocp[2] = makesym(atom__2D_2D_2D_2D_2D_20Variable_20Type_20End_20_20_20_2D_2D_2D_2D_2D);
  allocp[3] = (q)(struct goalrec*)&allocp[0];
  allocp[4] = (q)(&predicate_print_xtype__modules_2);
  allocp[5] = a0;
  allocp[6] = a1;
  a0 = makesym(atom__2D_2D_2D_2D_2D_20Variable_20Type_20Begin_20_2D_2D_2D_2D_2D);
  qp = (struct goalrec*)&allocp[3];
  allocp += 7;
  execute(datan_1_0);
  goto datan_1_ext_interrupt;
 type__table_2_ext_interrupt:
  reasonp = 0l;
 type__table_2_interrupt:
  goto interrupt_2;
 }

 type__modules_2_top: {
  q x0, x1, x2, x3, x4;
  a1 = qp->args[1];
  qp = qp->next;
 type__modules_2_clear_reason:
  reasonp = reasons;
 type__modules_2_0:
 type__modules_2_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 type__modules_2_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto type__modules_2_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xtype__modules_2);
  allocp[2] = a0;
  x1 = cdr_of(a1);
  allocp[3] = x1;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_print_xtype__clauses_2);
  allocp[6] = x2 = makeref(&allocp[6]);
  x3 = arg(x0, 1);
  allocp[7] = x3;
  allocp[8] = (q)(struct goalrec*)&allocp[4];
  allocp[9] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[10] = a0;
  allocp[11] = makeint(2L);
  allocp[12] = x2;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_print_xdatan_1);
  x4 = arg(x0, 0);
  allocp[15] = x4;
  a0 = makesym(atom_MODULE_3A);
  qp = (struct goalrec*)&allocp[13];
  allocp += 16;
  execute(data_1_0);
  goto data_1_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,type__modules_2_2);
  *reasonp++ =  x0;
  goto type__modules_2_interrupt;
  };
  goto type__modules_2_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto type__modules_2_interrupt;
  proceed();
 case VARREF:
  deref_and_jump(a1,type__modules_2_1);
  *reasonp++ =  a1;
  goto type__modules_2_interrupt;
  };
  goto type__modules_2_interrupt;
 type__modules_2_ext_interrupt:
  reasonp = 0l;
 type__modules_2_interrupt:
  goto interrupt_2;
 }

 type__clauses_2_top: {
  q x0, x1;
  a1 = qp->args[1];
  qp = qp->next;
 type__clauses_2_clear_reason:
  reasonp = reasons;
 type__clauses_2_0:
 type__clauses_2_1:
  if (isref(a1)) goto type__clauses_2_2;
  gblt_pfunctor(a1,x0,type__clauses_2_interrupt);
  if (x0 != makesym(atom_clauses)) goto type__clauses_2_interrupt;
  gblt_arity(a1,x1,type__clauses_2_interrupt);
  a2 = makeint(1L);
  a3 = x1;
  execute(type__clauses1_4_0);
  goto type__clauses1_4_ext_interrupt;
 type__clauses_2_2:
  deref_and_jump(a1,type__clauses_2_1);
  *reasonp++ =  a1;
  goto type__clauses_2_interrupt;
 type__clauses_2_ext_interrupt:
  reasonp = 0l;
 type__clauses_2_interrupt:
  goto interrupt_2;
 }

 type__clauses1_4_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 type__clauses1_4_clear_reason:
  reasonp = reasons;
 type__clauses1_4_0:
 type__clauses1_4_1:
  if (!isint(a2)) goto type__clauses1_4_5;
 type__clauses1_4_2:
  if (!isint(a3)) goto type__clauses1_4_4;
  gblt_less_or_eq(a2,a3,type__clauses1_4_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xtype__clauses1_4);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[8] = a2;
  allocp[9] = makeint(1L);
  allocp[10] = x0;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_print_xtype__clause_3);
  allocp[13] = a0;
  allocp[14] = x1 = makeref(&allocp[14]);
  allocp[15] = a2;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_functor__table_xarg_3);
  allocp[18] = a2;
  allocp[19] = a1;
  allocp[20] = x1;
  qp = (struct goalrec*)&allocp[16];
  allocp += 21;
  proceed();
 type__clauses1_4_3:
  gblt_greater(a2,a3,type__clauses1_4_interrupt);
  proceed();
 type__clauses1_4_4:
  if (!isref(a3)) goto type__clauses1_4_interrupt;
  deref_and_jump(a3,type__clauses1_4_2);
  *reasonp++ =  a3;
  goto type__clauses1_4_interrupt;
 type__clauses1_4_5:
  if (!isref(a2)) goto type__clauses1_4_interrupt;
  deref_and_jump(a2,type__clauses1_4_1);
  *reasonp++ =  a2;
  goto type__clauses1_4_interrupt;
 type__clauses1_4_ext_interrupt:
  reasonp = 0l;
 type__clauses1_4_interrupt:
  toppred = &predicate_print_xtype__clauses1_4;
  goto interrupt_4;
 }

 type__clause_3_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 type__clause_3_clear_reason:
  reasonp = reasons;
 type__clause_3_0:
 type__clause_3_1:
  if (isref(a1)) goto type__clause_3_2;
  gblt_pfunctor(a1,x0,type__clause_3_interrupt);
  gblt_arity(a1,x1,type__clause_3_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xtype__clause1_4);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = makeint(1L);
  allocp[5] = x1;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[8] = a0;
  allocp[9] = makeint(2L);
  allocp[10] = x2;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_print_xdatan_1);
  allocp[13] = a2;
  a1 = makesym(atom_clause_20);
  qp = (struct goalrec*)&allocp[11];
  allocp += 14;
  execute(data_2_0);
  goto data_2_ext_interrupt;
 type__clause_3_2:
  deref_and_jump(a1,type__clause_3_1);
  *reasonp++ =  a1;
  goto type__clause_3_interrupt;
 type__clause_3_ext_interrupt:
  reasonp = 0l;
 type__clause_3_interrupt:
  goto interrupt_3;
 }

 type__clause1_4_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 type__clause1_4_clear_reason:
  reasonp = reasons;
 type__clause1_4_0:
 type__clause1_4_1:
  if (!isint(a2)) goto type__clause1_4_5;
 type__clause1_4_2:
  if (!isint(a3)) goto type__clause1_4_4;
  gblt_less_or_eq(a2,a3,type__clause1_4_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xtype__clause1_4);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[8] = a2;
  allocp[9] = makeint(1L);
  allocp[10] = x0;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_print_xdatan_1);
  allocp[13] = x1 = makeref(&allocp[13]);
  allocp[14] = (q)(struct goalrec*)&allocp[11];
  allocp[15] = (q)(&predicate_print_xdata_1);
  allocp[16] = makesym(atom__3A);
  allocp[17] = (q)(struct goalrec*)&allocp[14];
  allocp[18] = (q)(&predicate_print_xdata_1);
  allocp[19] = x2 = makeref(&allocp[19]);
  allocp[20] = (q)(struct goalrec*)&allocp[17];
  allocp[21] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[22] = a2;
  allocp[23] = makeint(1L);
  allocp[24] = x2;
  allocp[25] = (q)(struct goalrec*)&allocp[20];
  allocp[26] = (q)(&predicate_print_xdata_2);
  allocp[27] = a0;
  allocp[28] = makesym(atom_V);
  allocp[29] = (q)(struct goalrec*)&allocp[25];
  allocp[30] = (q)(&predicate_functor__table_xarg_3);
  allocp[31] = a2;
  allocp[32] = a1;
  allocp[33] = x1;
  qp = (struct goalrec*)&allocp[29];
  allocp += 34;
  proceed();
 type__clause1_4_3:
  gblt_greater(a2,a3,type__clause1_4_interrupt);
  proceed();
 type__clause1_4_4:
  if (!isref(a3)) goto type__clause1_4_interrupt;
  deref_and_jump(a3,type__clause1_4_2);
  *reasonp++ =  a3;
  goto type__clause1_4_interrupt;
 type__clause1_4_5:
  if (!isref(a2)) goto type__clause1_4_interrupt;
  deref_and_jump(a2,type__clause1_4_1);
  *reasonp++ =  a2;
  goto type__clause1_4_interrupt;
 type__clause1_4_ext_interrupt:
  reasonp = 0l;
 type__clause1_4_interrupt:
  goto interrupt_4;
 }

 headbody__table_2_top: {
  a1 = qp->args[1];
  qp = qp->next;
 headbody__table_2_clear_reason:
  reasonp = reasons;
 headbody__table_2_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdatan_1);
  allocp[2] = makesym(atom__2D_2D_2D_2D_2D_20Head_2DBody_20End_20_20_20_2D_2D_2D_2D_2D);
  allocp[3] = (q)(struct goalrec*)&allocp[0];
  allocp[4] = (q)(&predicate_print_xheadbody__modules_2);
  allocp[5] = a0;
  allocp[6] = a1;
  a0 = makesym(atom__2D_2D_2D_2D_2D_20Head_2DBody_20Begin_20_2D_2D_2D_2D_2D);
  qp = (struct goalrec*)&allocp[3];
  allocp += 7;
  execute(datan_1_0);
  goto datan_1_ext_interrupt;
 headbody__table_2_ext_interrupt:
  reasonp = 0l;
 headbody__table_2_interrupt:
  goto interrupt_2;
 }

 headbody__modules_2_top: {
  q x0, x1, x2, x3, x4;
  a1 = qp->args[1];
  qp = qp->next;
 headbody__modules_2_clear_reason:
  reasonp = reasons;
 headbody__modules_2_0:
 headbody__modules_2_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 headbody__modules_2_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto headbody__modules_2_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xheadbody__modules_2);
  allocp[2] = a0;
  x1 = cdr_of(a1);
  allocp[3] = x1;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_print_xheadbody__clauses_2);
  allocp[6] = x2 = makeref(&allocp[6]);
  x3 = arg(x0, 1);
  allocp[7] = x3;
  allocp[8] = (q)(struct goalrec*)&allocp[4];
  allocp[9] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[10] = a0;
  allocp[11] = makeint(2L);
  allocp[12] = x2;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_print_xdatan_1);
  x4 = arg(x0, 0);
  allocp[15] = x4;
  a1 = makesym(atom_Module_3A);
  qp = (struct goalrec*)&allocp[13];
  allocp += 16;
  execute(data_2_0);
  goto data_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,headbody__modules_2_2);
  *reasonp++ =  x0;
  goto headbody__modules_2_interrupt;
  };
  goto headbody__modules_2_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto headbody__modules_2_interrupt;
  proceed();
 case VARREF:
  deref_and_jump(a1,headbody__modules_2_1);
  *reasonp++ =  a1;
  goto headbody__modules_2_interrupt;
  };
  goto headbody__modules_2_interrupt;
 headbody__modules_2_ext_interrupt:
  reasonp = 0l;
 headbody__modules_2_interrupt:
  goto interrupt_2;
 }

 headbody__clauses_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a1 = qp->args[1];
  qp = qp->next;
 headbody__clauses_2_clear_reason:
  reasonp = reasons;
 headbody__clauses_2_0:
 headbody__clauses_2_1:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  x0 = makefunctor(&allocp[0]);
  x5 = car_of(a1);
  allocp += 5;
  unify_value(x5, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xheadbody__clauses_2);
  allocp[2] = a0;
  x6 = cdr_of(a1);
  allocp[3] = x6;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_print_xdatan_2);
  allocp[6] = x7 = makeref(&allocp[6]);
  allocp[7] = x4;
  allocp[8] = (q)(struct goalrec*)&allocp[4];
  allocp[9] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[10] = a0;
  allocp[11] = makeint(2L);
  allocp[12] = x7;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_print_xdatan_2);
  allocp[15] = x8 = makeref(&allocp[15]);
  allocp[16] = x3;
  allocp[17] = (q)(struct goalrec*)&allocp[13];
  allocp[18] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[19] = a0;
  allocp[20] = makeint(2L);
  allocp[21] = x8;
  allocp[22] = (q)(struct goalrec*)&allocp[17];
  allocp[23] = (q)(&predicate_print_xdatan_1);
  allocp[24] = x2;
  allocp[25] = (q)(struct goalrec*)&allocp[22];
  allocp[26] = (q)(&predicate_print_xdata_1);
  allocp[27] = makesym(atom__2F);
  a1 = x1;
  qp = (struct goalrec*)&allocp[25];
  allocp += 28;
  execute(data_2_0);
  goto data_2_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto headbody__clauses_2_interrupt;
  proceed();
 case VARREF:
  deref_and_jump(a1,headbody__clauses_2_1);
  *reasonp++ =  a1;
  goto headbody__clauses_2_interrupt;
  };
  goto headbody__clauses_2_interrupt;
 headbody__clauses_2_ext_interrupt:
  reasonp = 0l;
 headbody__clauses_2_interrupt:
  goto interrupt_2;
 }

 depends_1_top: {
  qp = qp->next;
 depends_1_clear_reason:
  reasonp = reasons;
 depends_1_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdatan_1);
  allocp[2] = makesym(atom__2D_2D_2D_2D_2D_20Userdef_20Depends_20END_20_2D_2D_2D_2D_2D);
  allocp[3] = (q)(struct goalrec*)&allocp[0];
  allocp[4] = (q)(&predicate_print_xdepends1_1);
  allocp[5] = a0;
  allocp[6] = (q)(struct goalrec*)&allocp[3];
  allocp[7] = (q)(&predicate_print_xdatan_1);
  allocp[8] = a0;
  a0 = makesym(atom__2D_2D_2D_2D_2D_20Userdef_20Depends_20BEGIN_20_2D_2D_2D_2D_2D);
  qp = (struct goalrec*)&allocp[6];
  allocp += 9;
  execute(datan_1_0);
  goto datan_1_ext_interrupt;
 depends_1_ext_interrupt:
  reasonp = 0l;
 depends_1_interrupt:
  goto interrupt_1;
 }

 depends1_1_top: {
  q x0, x1, x2, x3, x4, x5;
  qp = qp->next;
 depends1_1_clear_reason:
  reasonp = reasons;
 depends1_1_0:
 depends1_1_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 depends1_1_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_goal_5)) goto depends1_1_3;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdepends1_1);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = (q)(struct goalrec*)&allocp[0];
  allocp[4] = (q)(&predicate_print_xdatan_1);
  x2 = arg(x0, 4);
  allocp[5] = x2;
  allocp[6] = (q)(struct goalrec*)&allocp[3];
  allocp[7] = (q)(&predicate_print_xdata_1);
  allocp[8] = makesym(atom__20_20_20_20);
  allocp[9] = (q)(struct goalrec*)&allocp[6];
  allocp[10] = (q)(&predicate_print_xdatan_1);
  x3 = arg(x0, 3);
  allocp[11] = x3;
  allocp[12] = (q)(struct goalrec*)&allocp[9];
  allocp[13] = (q)(&predicate_print_xdata_1);
  allocp[14] = makesym(atom__3A);
  allocp[15] = (q)(struct goalrec*)&allocp[12];
  allocp[16] = (q)(&predicate_print_xdata_1);
  x4 = arg(x0, 2);
  allocp[17] = x4;
  allocp[18] = (q)(struct goalrec*)&allocp[15];
  allocp[19] = (q)(&predicate_print_xdata_1);
  allocp[20] = makesym(atom__2F);
  allocp[21] = (q)(struct goalrec*)&allocp[18];
  allocp[22] = (q)(&predicate_print_xdata_1);
  x5 = arg(x0, 1);
  allocp[23] = x5;
  allocp[24] = (q)(struct goalrec*)&allocp[21];
  allocp[25] = (q)(&predicate_print_xdata_1);
  allocp[26] = makesym(atom__3A);
  a0 = arg(x0, 0);
  qp = (struct goalrec*)&allocp[24];
  allocp += 27;
  execute(data_1_0);
  goto data_1_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,depends1_1_2);
  *reasonp++ =  x0;
  goto depends1_1_3;
  };
  goto depends1_1_3;
 case VARREF:
  deref_and_jump(a0,depends1_1_1);
  *reasonp++ =  a0;
  goto depends1_1_3;
  };
  goto depends1_1_3;
 depends1_1_3:
  otherwise(depends1_1_interrupt);
 depends1_1_4:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdepends1_1);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  a0 = car_of(a0);
  qp = (struct goalrec*)&allocp[0];
  allocp += 3;
  execute(data_1_0);
  goto data_1_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto depends1_1_interrupt;
  proceed();
 case VARREF:
  deref_and_jump(a0,depends1_1_4);
  *reasonp++ =  a0;
  goto depends1_1_interrupt;
  };
  goto depends1_1_interrupt;
 depends1_1_ext_interrupt:
  reasonp = 0l;
 depends1_1_interrupt:
  goto interrupt_1;
 }

 data_1_top: {
  q x0, x1;
  qp = qp->next;
 data_1_clear_reason:
  reasonp = reasons;
 data_1_0:
  allocp[0] = makesym(functor_print_1);
  allocp[1] = a0;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = NILATOM;
  allocp[3] = x0;
  x1 = makecons(&allocp[2]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_io_xoutstream_1);
  allocp[6] = x1;
  qp = (struct goalrec*)&allocp[4];
  allocp += 7;
  proceed();
 data_1_ext_interrupt:
  reasonp = 0l;
 data_1_interrupt:
  toppred = &predicate_print_xdata_1;
  goto interrupt_1;
 }

 datan_1_top: {
  q x0, x1;
  qp = qp->next;
 datan_1_clear_reason:
  reasonp = reasons;
 datan_1_0:
  allocp[0] = makesym(functor_print_1);
  allocp[1] = a0;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makecons(cons_const_0);
  allocp[3] = x0;
  x1 = makecons(&allocp[2]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_io_xoutstream_1);
  allocp[6] = x1;
  qp = (struct goalrec*)&allocp[4];
  allocp += 7;
  proceed();
 datan_1_ext_interrupt:
  reasonp = 0l;
 datan_1_interrupt:
  toppred = &predicate_print_xdatan_1;
  goto interrupt_1;
 }

 data_2_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  qp = qp->next;
 data_2_clear_reason:
  reasonp = reasons;
 data_2_0:
 data_2_1:
  if (!isint(a0)) goto data_2_3;
  gblt_greater(a0,makeint(0L),data_2_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdata_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[6] = a0;
  allocp[7] = makeint(1L);
  allocp[8] = x0;
  allocp[9] = (q)(struct goalrec*)&allocp[4];
  allocp[10] = (q)(&predicate_io_xoutstream_1);
  allocp[11] = makecons(cons_const_2);
  qp = (struct goalrec*)&allocp[9];
  allocp += 12;
  proceed();
 data_2_2:
  if (a0 != makeint(0L)) goto data_2_interrupt;
  allocp[0] = makesym(functor_print_1);
  allocp[1] = a1;
  x1 = makefunctor(&allocp[0]);
  allocp[2] = NILATOM;
  allocp[3] = x1;
  x2 = makecons(&allocp[2]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_io_xoutstream_1);
  allocp[6] = x2;
  qp = (struct goalrec*)&allocp[4];
  allocp += 7;
  proceed();
 data_2_3:
  if (!isref(a0)) goto data_2_interrupt;
  deref_and_jump(a0,data_2_1);
  *reasonp++ =  a0;
  goto data_2_interrupt;
 data_2_ext_interrupt:
  reasonp = 0l;
 data_2_interrupt:
  toppred = &predicate_print_xdata_2;
  goto interrupt_2;
 }

 datan_2_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  qp = qp->next;
 datan_2_clear_reason:
  reasonp = reasons;
 datan_2_0:
 datan_2_1:
  if (!isint(a0)) goto datan_2_3;
  gblt_greater(a0,makeint(0L),datan_2_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdatan_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[6] = a0;
  allocp[7] = makeint(1L);
  allocp[8] = x0;
  allocp[9] = (q)(struct goalrec*)&allocp[4];
  allocp[10] = (q)(&predicate_io_xoutstream_1);
  allocp[11] = makecons(cons_const_2);
  qp = (struct goalrec*)&allocp[9];
  allocp += 12;
  proceed();
 datan_2_2:
  if (a0 != makeint(0L)) goto datan_2_interrupt;
  allocp[0] = makesym(functor_print_1);
  allocp[1] = a1;
  x1 = makefunctor(&allocp[0]);
  allocp[2] = makecons(cons_const_0);
  allocp[3] = x1;
  x2 = makecons(&allocp[2]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_io_xoutstream_1);
  allocp[6] = x2;
  qp = (struct goalrec*)&allocp[4];
  allocp += 7;
  proceed();
 datan_2_3:
  if (!isref(a0)) goto datan_2_interrupt;
  deref_and_jump(a0,datan_2_1);
  *reasonp++ =  a0;
  goto datan_2_interrupt;
 datan_2_ext_interrupt:
  reasonp = 0l;
 datan_2_interrupt:
  toppred = &predicate_print_xdatan_2;
  goto interrupt_2;
 }

 list_2_top: {
  a1 = qp->args[1];
  qp = qp->next;
 list_2_clear_reason:
  reasonp = reasons;
 list_2_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xlist_1);
  allocp[2] = a1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 3;
  execute(datan_1_0);
  goto datan_1_ext_interrupt;
 list_2_ext_interrupt:
  reasonp = 0l;
 list_2_interrupt:
  goto interrupt_2;
 }

 list_1_top: {
  q x0, x1;
  qp = qp->next;
 list_1_clear_reason:
  reasonp = reasons;
 list_1_0:
 list_1_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xlist_1);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = (q)(struct goalrec*)&allocp[0];
  allocp[4] = (q)(&predicate_print_xdatan_1);
  x1 = car_of(a0);
  allocp[5] = x1;
  a0 = makesym(atom__20_20);
  qp = (struct goalrec*)&allocp[3];
  allocp += 6;
  execute(data_1_0);
  goto data_1_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto list_1_interrupt;
  proceed();
 case VARREF:
  deref_and_jump(a0,list_1_1);
  *reasonp++ =  a0;
  goto list_1_interrupt;
  };
  goto list_1_interrupt;
 list_1_ext_interrupt:
  reasonp = 0l;
 list_1_interrupt:
  goto interrupt_1;
 }

 termn_1_top: {
  qp = qp->next;
 termn_1_clear_reason:
  reasonp = reasons;
 termn_1_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdatan_1);
  allocp[2] = makesym(atom_);
  qp = (struct goalrec*)&allocp[0];
  allocp += 3;
  execute(term_1_0);
  goto term_1_ext_interrupt;
 termn_1_ext_interrupt:
  reasonp = 0l;
 termn_1_interrupt:
  goto interrupt_1;
 }

 term_1_top: {
  q x0;
  qp = qp->next;
 term_1_clear_reason:
  reasonp = reasons;
 term_1_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xterm1_2);
  allocp[2] = a0;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_variable_xunbound_2);
  allocp[6] = a0;
  allocp[7] = x0;
  qp = (struct goalrec*)&allocp[4];
  allocp += 8;
  proceed();
 term_1_ext_interrupt:
  reasonp = 0l;
 term_1_interrupt:
  toppred = &predicate_print_xterm_1;
  goto interrupt_1;
 }

 term1_2_top: {
  q x0;
  a1 = qp->args[1];
  qp = qp->next;
 term1_2_clear_reason:
  reasonp = reasons;
 term1_2_0:
 term1_2_1:
  switch (ptagof(a1)) {
 case FUNCTOR:
 term1_2_2:
  if (!isgobj(a1)) goto term1_2_4;
  if (!isclass(a1,vector)) goto term1_2_4;
  gblt_size_of_vector(a1,x0,term1_2_4);
 term1_2_3:
  if (x0 != makeint(1L)) goto term1_2_4;
  execute(term2_1_0);
  goto term2_1_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,term1_2_1);
  *reasonp++ =  a1;
  goto term1_2_4;
  };
  goto term1_2_4;
 term1_2_4:
  otherwise(term1_2_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdata_1);
  allocp[2] = makesym(atom____3F__);
  qp = (struct goalrec*)&allocp[0];
  allocp += 3;
  proceed();
 term1_2_ext_interrupt:
  reasonp = 0l;
 term1_2_interrupt:
  goto interrupt_2;
 }

 term2_1_top: {
  q x0, x1;
  qp = qp->next;
 term2_1_clear_reason:
  reasonp = reasons;
 term2_1_0:
 term2_1_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 term2_1_2:
  gblt_atomic(a0,term2_1_5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdata_1);
  allocp[2] = a0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 3;
  proceed();
 case FUNCTOR:
 term2_1_3:
  if (!isgobj(a0)) goto term2_1_5;
 term2_1_4:
  gblt_is_string(a0,term2_1_5);
  gblt_size_of_string(a0,x0,term2_1_5);
  gblt_element_size_of_string(a0,x1,term2_1_5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdata_1);
  allocp[2] = a0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 3;
  proceed();
 case VARREF:
  deref_and_jump(a0,term2_1_1);
  *reasonp++ =  a0;
  goto term2_1_5;
  };
  goto term2_1_5;
 term2_1_5:
  otherwise(term2_1_interrupt);
 term2_1_6:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdata_1);
  allocp[2] = makesym(atom__5D);
  allocp[3] = (q)(struct goalrec*)&allocp[0];
  allocp[4] = (q)(&predicate_print_xterm_1);
  x0 = cdr_of(a0);
  allocp[5] = x0;
  allocp[6] = (q)(struct goalrec*)&allocp[3];
  allocp[7] = (q)(&predicate_print_xdata_1);
  allocp[8] = makesym(atom__7C);
  allocp[9] = (q)(struct goalrec*)&allocp[6];
  allocp[10] = (q)(&predicate_print_xterm_1);
  x1 = car_of(a0);
  allocp[11] = x1;
  allocp[12] = (q)(struct goalrec*)&allocp[9];
  allocp[13] = (q)(&predicate_print_xdata_1);
  allocp[14] = makesym(atom__5B);
  qp = (struct goalrec*)&allocp[12];
  allocp += 15;
  proceed();
 case FUNCTOR:
 term2_1_7:
  if (!isgobj(a0)) goto term2_1_8;
  if (!isclass(a0,vector)) goto term2_1_8;
  gblt_size_of_vector(a0,x0,term2_1_8);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdata_1);
  allocp[2] = makesym(atom__7D);
  allocp[3] = (q)(struct goalrec*)&allocp[0];
  allocp[4] = (q)(&predicate_print_xterm__vector__arg_3);
  allocp[5] = a0;
  allocp[6] = makeint(0L);
  allocp[7] = x0;
  allocp[8] = (q)(struct goalrec*)&allocp[3];
  allocp[9] = (q)(&predicate_print_xdata_1);
  allocp[10] = makesym(atom__7B);
  qp = (struct goalrec*)&allocp[8];
  allocp += 11;
  proceed();
 case VARREF:
  deref_and_jump(a0,term2_1_6);
  *reasonp++ =  a0;
  goto term2_1_interrupt;
  };
  goto term2_1_8;
 term2_1_8:
  gblt_pfunctor(a0,x0,term2_1_interrupt);
  gblt_arity(a0,x1,term2_1_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdata_1);
  allocp[2] = makesym(atom__29);
  allocp[3] = (q)(struct goalrec*)&allocp[0];
  allocp[4] = (q)(&predicate_print_xterm__arg_3);
  allocp[5] = a0;
  allocp[6] = makeint(1L);
  allocp[7] = x1;
  allocp[8] = (q)(struct goalrec*)&allocp[3];
  allocp[9] = (q)(&predicate_print_xdata_1);
  allocp[10] = makesym(atom__28);
  allocp[11] = (q)(struct goalrec*)&allocp[8];
  allocp[12] = (q)(&predicate_print_xdata_1);
  allocp[13] = x0;
  qp = (struct goalrec*)&allocp[11];
  allocp += 14;
  proceed();
 term2_1_ext_interrupt:
  reasonp = 0l;
 term2_1_interrupt:
  toppred = &predicate_print_xterm2_1;
  goto interrupt_1;
 }

 term__arg_3_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 term__arg_3_clear_reason:
  reasonp = reasons;
 term__arg_3_0:
 term__arg_3_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (!isint(a1)) goto term__arg_3_5;
 term__arg_3_2:
 term__arg_3_3:
  if (!isint(a2)) goto term__arg_3_4;
  gblt_less(a1,a2,term__arg_3_5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xterm__arg_3);
  allocp[2] = a0;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[7] = a1;
  allocp[8] = makeint(1L);
  allocp[9] = x0;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_print_xterm_1);
  allocp[12] = makesym(atom__2C);
  allocp[13] = (q)(struct goalrec*)&allocp[10];
  allocp[14] = (q)(&predicate_print_xterm_1);
  allocp[15] = x1 = makeref(&allocp[15]);
  allocp[16] = (q)(struct goalrec*)&allocp[13];
  allocp[17] = (q)(&predicate_functor__table_xarg_3);
  allocp[18] = a1;
  allocp[19] = a0;
  allocp[20] = x1;
  qp = (struct goalrec*)&allocp[16];
  allocp += 21;
  proceed();
 term__arg_3_4:
  if (!isref(a2)) goto term__arg_3_5;
  deref_and_jump(a2,term__arg_3_3);
  *reasonp++ =  a2;
  goto term__arg_3_5;
 case VARREF:
  deref_and_jump(a1,term__arg_3_1);
  *reasonp++ =  a1;
  goto term__arg_3_interrupt;
  };
  goto term__arg_3_5;
 term__arg_3_5:
 term__arg_3_6:
  if (isref(a1)) goto term__arg_3_7;
  if_not_equal(a1, a2, term__arg_3_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xterm_1);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = (q)(struct goalrec*)&allocp[0];
  allocp[4] = (q)(&predicate_functor__table_xarg_3);
  allocp[5] = a1;
  allocp[6] = a0;
  allocp[7] = x0;
  qp = (struct goalrec*)&allocp[3];
  allocp += 8;
  proceed();
 term__arg_3_7:
  deref_and_jump(a1,term__arg_3_6);
  *reasonp++ =  a1;
  goto term__arg_3_interrupt;
 term__arg_3_ext_interrupt:
  reasonp = 0l;
 term__arg_3_interrupt:
  goto interrupt_3;
 }

 term__vector__arg_3_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 term__vector__arg_3_clear_reason:
  reasonp = reasons;
 term__vector__arg_3_0:
 term__vector__arg_3_1:
  if (!isint(a2)) goto term__vector__arg_3_5;
  gblt_subtract(a2,makeint(1L),x0,term__vector__arg_3_interrupt);
 term__vector__arg_3_2:
  if (!isint(a1)) goto term__vector__arg_3_4;
  gblt_less(a1,x0,term__vector__arg_3_3);
  generic_arg[0] = a1;
  allocp[0] = x1 = makeref(&allocp[0]);
  generic_arg[1] = x1;
  call_generic(a0, functor_element_2, 1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xterm__vector__arg_3);
  allocp[2] = a0;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[7] = a1;
  allocp[8] = makeint(1L);
  allocp[9] = x2;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_print_xterm_1);
  allocp[12] = makesym(atom__2C);
  allocp[13] = (q)(struct goalrec*)&allocp[10];
  allocp[14] = (q)(&predicate_print_xterm_1);
  allocp[15] = x1;
  qp = (struct goalrec*)&allocp[13];
  allocp += 16;
  proceed();
 term__vector__arg_3_3:
  gblt_eq(a1,x0,term__vector__arg_3_interrupt);
  generic_arg[0] = a1;
  allocp[0] = x1 = makeref(&allocp[0]);
  generic_arg[1] = x1;
  call_generic(a0, functor_element_2, 1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xterm_1);
  allocp[2] = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 3;
  proceed();
 term__vector__arg_3_4:
  if (!isref(a1)) goto term__vector__arg_3_interrupt;
  deref_and_jump(a1,term__vector__arg_3_2);
  *reasonp++ =  a1;
  goto term__vector__arg_3_interrupt;
 term__vector__arg_3_5:
  if (!isref(a2)) goto term__vector__arg_3_interrupt;
  deref_and_jump(a2,term__vector__arg_3_1);
  *reasonp++ =  a2;
  goto term__vector__arg_3_interrupt;
 term__vector__arg_3_ext_interrupt:
  reasonp = 0l;
 term__vector__arg_3_interrupt:
  goto interrupt_3;
 }

 program_1_top: {
  q x0, x1;
  qp = qp->next;
 program_1_clear_reason:
  reasonp = reasons;
 program_1_0:
 program_1_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_normal_2)) goto program_1_interrupt;
  x0 = arg(a0, 1);
 program_1_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != NILATOM) goto program_1_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdatan_1);
  allocp[2] = makesym(atom__5D_2C_5B_5D_29);
  allocp[3] = (q)(struct goalrec*)&allocp[0];
  allocp[4] = (q)(&predicate_print_xprogram__modules_1);
  x1 = arg(a0, 0);
  allocp[5] = x1;
  allocp[6] = (q)(struct goalrec*)&allocp[3];
  allocp[7] = (q)(&predicate_print_xdatan_1);
  allocp[8] = makesym(atom_normal_28_5B);
  qp = (struct goalrec*)&allocp[6];
  allocp += 9;
  proceed();
 case VARREF:
  deref_and_jump(x0,program_1_2);
  *reasonp++ =  x0;
  goto program_1_interrupt;
  };
  goto program_1_interrupt;
 case VARREF:
  deref_and_jump(a0,program_1_1);
  *reasonp++ =  a0;
  goto program_1_interrupt;
  };
  goto program_1_interrupt;
 program_1_ext_interrupt:
  reasonp = 0l;
 program_1_interrupt:
  goto interrupt_1;
 }

 program__modules_1_top: {
  q x0, x1, x2, x3;
  qp = qp->next;
 program__modules_1_clear_reason:
  reasonp = reasons;
 program__modules_1_0:
 program__modules_1_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = cdr_of(a0);
 program__modules_1_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != NILATOM) goto program__modules_1_4;
  x1 = car_of(a0);
 program__modules_1_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_module_2)) goto program__modules_1_4;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdatan_1);
  allocp[2] = makesym(atom__5D_29);
  allocp[3] = (q)(struct goalrec*)&allocp[0];
  allocp[4] = (q)(&predicate_print_xprogram__clauses_1);
  x2 = arg(x1, 1);
  allocp[5] = x2;
  allocp[6] = (q)(struct goalrec*)&allocp[3];
  allocp[7] = (q)(&predicate_print_xdatan_1);
  allocp[8] = makesym(atom__2C_5B);
  allocp[9] = (q)(struct goalrec*)&allocp[6];
  allocp[10] = (q)(&predicate_print_xdata_1);
  x3 = arg(x1, 0);
  allocp[11] = x3;
  allocp[12] = (q)(struct goalrec*)&allocp[9];
  allocp[13] = (q)(&predicate_print_xdata_1);
  allocp[14] = makesym(atom_module_28);
  qp = (struct goalrec*)&allocp[12];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(x1,program__modules_1_3);
  *reasonp++ =  x1;
  goto program__modules_1_4;
  };
  goto program__modules_1_4;
 case VARREF:
  deref_and_jump(x0,program__modules_1_2);
  *reasonp++ =  x0;
  goto program__modules_1_4;
  };
  goto program__modules_1_4;
 case VARREF:
  deref_and_jump(a0,program__modules_1_1);
  *reasonp++ =  a0;
  goto program__modules_1_4;
  };
  goto program__modules_1_4;
 program__modules_1_4:
  otherwise(program__modules_1_interrupt);
 program__modules_1_5:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 program__modules_1_6:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto program__modules_1_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xprogram__modules_1);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = (q)(struct goalrec*)&allocp[0];
  allocp[4] = (q)(&predicate_print_xdatan_1);
  allocp[5] = makesym(atom__5D_29_2C);
  allocp[6] = (q)(struct goalrec*)&allocp[3];
  allocp[7] = (q)(&predicate_print_xprogram__clauses_1);
  x2 = arg(x0, 1);
  allocp[8] = x2;
  allocp[9] = (q)(struct goalrec*)&allocp[6];
  allocp[10] = (q)(&predicate_print_xdatan_1);
  allocp[11] = makesym(atom__2C_5B);
  allocp[12] = (q)(struct goalrec*)&allocp[9];
  allocp[13] = (q)(&predicate_print_xdata_1);
  x3 = arg(x0, 0);
  allocp[14] = x3;
  allocp[15] = (q)(struct goalrec*)&allocp[12];
  allocp[16] = (q)(&predicate_print_xdata_1);
  allocp[17] = makesym(atom_module_28);
  qp = (struct goalrec*)&allocp[15];
  allocp += 18;
  proceed();
 case VARREF:
  deref_and_jump(x0,program__modules_1_6);
  *reasonp++ =  x0;
  goto program__modules_1_interrupt;
  };
  goto program__modules_1_interrupt;
 case VARREF:
  deref_and_jump(a0,program__modules_1_5);
  *reasonp++ =  a0;
  goto program__modules_1_interrupt;
  };
  goto program__modules_1_interrupt;
 program__modules_1_ext_interrupt:
  reasonp = 0l;
 program__modules_1_interrupt:
  goto interrupt_1;
 }

 program__clauses_1_top: {
  q x0, x1;
  qp = qp->next;
 program__clauses_1_clear_reason:
  reasonp = reasons;
 program__clauses_1_0:
 program__clauses_1_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = cdr_of(a0);
 program__clauses_1_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != NILATOM) goto program__clauses_1_3;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xprogram__clause_1);
  x1 = car_of(a0);
  allocp[2] = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 3;
  proceed();
 case VARREF:
  deref_and_jump(x0,program__clauses_1_2);
  *reasonp++ =  x0;
  goto program__clauses_1_3;
  };
  goto program__clauses_1_3;
 case VARREF:
  deref_and_jump(a0,program__clauses_1_1);
  *reasonp++ =  a0;
  goto program__clauses_1_3;
  };
  goto program__clauses_1_3;
 program__clauses_1_3:
  otherwise(program__clauses_1_interrupt);
 program__clauses_1_4:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xprogram__clauses_1);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = (q)(struct goalrec*)&allocp[0];
  allocp[4] = (q)(&predicate_print_xdatan_1);
  allocp[5] = makesym(atom__2C);
  allocp[6] = (q)(struct goalrec*)&allocp[3];
  allocp[7] = (q)(&predicate_print_xprogram__clause_1);
  x1 = car_of(a0);
  allocp[8] = x1;
  qp = (struct goalrec*)&allocp[6];
  allocp += 9;
  proceed();
 case VARREF:
  deref_and_jump(a0,program__clauses_1_4);
  *reasonp++ =  a0;
  goto program__clauses_1_interrupt;
  };
  goto program__clauses_1_interrupt;
 program__clauses_1_ext_interrupt:
  reasonp = 0l;
 program__clauses_1_interrupt:
  goto interrupt_1;
 }

 program__clause_1_top: {
  q x0, x1, x2, x3;
  qp = qp->next;
 program__clause_1_clear_reason:
  reasonp = reasons;
 program__clause_1_0:
 program__clause_1_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_clause_4)) goto program__clause_1_2;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdata_1);
  allocp[2] = makesym(atom__29);
  allocp[3] = (q)(struct goalrec*)&allocp[0];
  allocp[4] = (q)(&predicate_print_xdata_1);
  x0 = arg(a0, 3);
  allocp[5] = x0;
  allocp[6] = (q)(struct goalrec*)&allocp[3];
  allocp[7] = (q)(&predicate_print_xdata_1);
  allocp[8] = makesym(atom__20_20_20_20_5D_2C);
  allocp[9] = (q)(struct goalrec*)&allocp[6];
  allocp[10] = (q)(&predicate_print_xprogram__goals_1);
  x1 = arg(a0, 2);
  allocp[11] = x1;
  allocp[12] = (q)(struct goalrec*)&allocp[9];
  allocp[13] = (q)(&predicate_print_xdatan_1);
  allocp[14] = makesym(atom__20_20_20_20_5D_2C_5B);
  allocp[15] = (q)(struct goalrec*)&allocp[12];
  allocp[16] = (q)(&predicate_print_xprogram__goals_1);
  x2 = arg(a0, 1);
  allocp[17] = x2;
  allocp[18] = (q)(struct goalrec*)&allocp[15];
  allocp[19] = (q)(&predicate_print_xdatan_1);
  allocp[20] = makesym(atom__2C_5B);
  allocp[21] = (q)(struct goalrec*)&allocp[18];
  allocp[22] = (q)(&predicate_print_xdata_1);
  x3 = arg(a0, 0);
  allocp[23] = x3;
  a0 = makesym(atom__20_20clause_28);
  qp = (struct goalrec*)&allocp[21];
  allocp += 24;
  execute(data_1_0);
  goto data_1_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,program__clause_1_1);
  *reasonp++ =  a0;
  goto program__clause_1_2;
  };
  goto program__clause_1_2;
 program__clause_1_2:
  otherwise(program__clause_1_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdatan_1);
  allocp[2] = a0;
  a0 = makesym(atom__20_20);
  qp = (struct goalrec*)&allocp[0];
  allocp += 3;
  execute(data_1_0);
  goto data_1_ext_interrupt;
 program__clause_1_ext_interrupt:
  reasonp = 0l;
 program__clause_1_interrupt:
  goto interrupt_1;
 }

 program__goals_1_top: {
  q x0, x1;
  qp = qp->next;
 program__goals_1_clear_reason:
  reasonp = reasons;
 program__goals_1_0:
 program__goals_1_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = cdr_of(a0);
 program__goals_1_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != NILATOM) goto program__goals_1_3;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdatan_1);
  x1 = car_of(a0);
  allocp[2] = x1;
  a0 = makesym(atom__20_20_20_20);
  qp = (struct goalrec*)&allocp[0];
  allocp += 3;
  execute(data_1_0);
  goto data_1_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,program__goals_1_2);
  *reasonp++ =  x0;
  goto program__goals_1_3;
  };
  goto program__goals_1_3;
 case ATOMIC:
  if (a0 != NILATOM) goto program__goals_1_3;
  proceed();
 case VARREF:
  deref_and_jump(a0,program__goals_1_1);
  *reasonp++ =  a0;
  goto program__goals_1_3;
  };
  goto program__goals_1_3;
 program__goals_1_3:
  otherwise(program__goals_1_interrupt);
 program__goals_1_4:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xprogram__goals_1);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = (q)(struct goalrec*)&allocp[0];
  allocp[4] = (q)(&predicate_print_xdatan_1);
  allocp[5] = makesym(atom__2C);
  allocp[6] = (q)(struct goalrec*)&allocp[3];
  allocp[7] = (q)(&predicate_print_xdata_1);
  x1 = car_of(a0);
  allocp[8] = x1;
  a0 = makesym(atom__20_20_20_20);
  qp = (struct goalrec*)&allocp[6];
  allocp += 9;
  execute(data_1_0);
  goto data_1_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,program__goals_1_4);
  *reasonp++ =  a0;
  goto program__goals_1_interrupt;
  };
  goto program__goals_1_interrupt;
 program__goals_1_ext_interrupt:
  reasonp = 0l;
 program__goals_1_interrupt:
  goto interrupt_1;
 }

 deps_1_top: {
  qp = qp->next;
 deps_1_clear_reason:
  reasonp = reasons;
 deps_1_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdatan_1);
  allocp[2] = makesym(atom__2D_2D_2D_2D_2D_20Dependencies_20END_20_2D_2D_2D_2D_2D);
  allocp[3] = (q)(struct goalrec*)&allocp[0];
  allocp[4] = (q)(&predicate_print_xdeps__modules_1);
  allocp[5] = a0;
  a0 = makesym(atom__2D_2D_2D_2D_2D_20Dependencies_20BEGIN_20_2D_2D_2D_2D_2D);
  qp = (struct goalrec*)&allocp[3];
  allocp += 6;
  execute(datan_1_0);
  goto datan_1_ext_interrupt;
 deps_1_ext_interrupt:
  reasonp = 0l;
 deps_1_interrupt:
  goto interrupt_1;
 }

 deps__modules_1_top: {
  q x0, x1, x2, x3, x4, x5;
  qp = qp->next;
 deps__modules_1_clear_reason:
  reasonp = reasons;
 deps__modules_1_0:
 deps__modules_1_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 deps__modules_1_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto deps__modules_1_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdeps__modules_1);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = (q)(struct goalrec*)&allocp[0];
  allocp[4] = (q)(&predicate_print_xdeps__clauses_3);
  allocp[5] = makeint(1L);
  allocp[6] = x2 = makeref(&allocp[6]);
  x3 = arg(x0, 1);
  allocp[7] = x3;
  allocp[8] = (q)(struct goalrec*)&allocp[3];
  allocp[9] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[10] = x3;
  allocp[11] = x4 = makeref(&allocp[11]);
  allocp[12] = x2;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_print_xdatan_1);
  x5 = arg(x0, 0);
  allocp[15] = x5;
  a0 = makesym(atom_module_3A);
  qp = (struct goalrec*)&allocp[13];
  allocp += 16;
  execute(data_1_0);
  goto data_1_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,deps__modules_1_2);
  *reasonp++ =  x0;
  goto deps__modules_1_interrupt;
  };
  goto deps__modules_1_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto deps__modules_1_interrupt;
  proceed();
 case VARREF:
  deref_and_jump(a0,deps__modules_1_1);
  *reasonp++ =  a0;
  goto deps__modules_1_interrupt;
  };
  goto deps__modules_1_interrupt;
 deps__modules_1_ext_interrupt:
  reasonp = 0l;
 deps__modules_1_interrupt:
  goto interrupt_1;
 }

 deps__clauses_3_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 deps__clauses_3_clear_reason:
  reasonp = reasons;
 deps__clauses_3_0:
 deps__clauses_3_1:
  if (!isint(a0)) goto deps__clauses_3_7;
 deps__clauses_3_2:
  if (!isint(a1)) goto deps__clauses_3_6;
  gblt_less_or_eq(a0,a1,deps__clauses_3_8);
 deps__clauses_3_3:
  if (isref(a2)) goto deps__clauses_3_5;
  gblt_arg(a0,a2,x0,deps__clauses_3_8);
 deps__clauses_3_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_deps_2)) goto deps__clauses_3_8;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdeps__clauses_3);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[7] = a0;
  allocp[8] = makeint(1L);
  allocp[9] = x1;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_print_xdeps__goals_1);
  x2 = arg(x0, 1);
  allocp[12] = x2;
  allocp[13] = (q)(struct goalrec*)&allocp[10];
  allocp[14] = (q)(&predicate_print_xdatan_1);
  allocp[15] = makesym(atom__20_20_20_20body);
  allocp[16] = (q)(struct goalrec*)&allocp[13];
  allocp[17] = (q)(&predicate_print_xdeps__goals_1);
  x3 = arg(x0, 0);
  allocp[18] = x3;
  allocp[19] = (q)(struct goalrec*)&allocp[16];
  allocp[20] = (q)(&predicate_print_xdatan_1);
  allocp[21] = makesym(atom__20guard);
  qp = (struct goalrec*)&allocp[19];
  allocp += 22;
  execute(data_1_0);
  goto data_1_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,deps__clauses_3_4);
  *reasonp++ =  x0;
  goto deps__clauses_3_8;
  };
  goto deps__clauses_3_8;
 deps__clauses_3_5:
  deref_and_jump(a2,deps__clauses_3_3);
  *reasonp++ =  a2;
  goto deps__clauses_3_8;
 deps__clauses_3_6:
  if (!isref(a1)) goto deps__clauses_3_8;
  deref_and_jump(a1,deps__clauses_3_2);
  *reasonp++ =  a1;
  goto deps__clauses_3_8;
 deps__clauses_3_7:
  if (!isref(a0)) goto deps__clauses_3_8;
  deref_and_jump(a0,deps__clauses_3_1);
  *reasonp++ =  a0;
  goto deps__clauses_3_8;
 deps__clauses_3_8:
  otherwise(deps__clauses_3_interrupt);
 deps__clauses_3_9:
  if (!isint(a0)) goto deps__clauses_3_13;
 deps__clauses_3_10:
  if (!isint(a1)) goto deps__clauses_3_12;
  gblt_less_or_eq(a0,a1,deps__clauses_3_11);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdeps__clauses_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[7] = a0;
  allocp[8] = makeint(1L);
  allocp[9] = x0;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_print_xdatan_1);
  allocp[12] = makesym(atom__20otherwise);
  qp = (struct goalrec*)&allocp[10];
  allocp += 13;
  execute(data_1_0);
  goto data_1_ext_interrupt;
 deps__clauses_3_11:
  gblt_greater(a0,a1,deps__clauses_3_interrupt);
  proceed();
 deps__clauses_3_12:
  if (!isref(a1)) goto deps__clauses_3_interrupt;
  deref_and_jump(a1,deps__clauses_3_10);
  *reasonp++ =  a1;
  goto deps__clauses_3_interrupt;
 deps__clauses_3_13:
  if (!isref(a0)) goto deps__clauses_3_interrupt;
  deref_and_jump(a0,deps__clauses_3_9);
  *reasonp++ =  a0;
  goto deps__clauses_3_interrupt;
 deps__clauses_3_ext_interrupt:
  reasonp = 0l;
 deps__clauses_3_interrupt:
  goto interrupt_3;
 }

 deps__goals_1_top: {
  q x0, x1;
  qp = qp->next;
 deps__goals_1_clear_reason:
  reasonp = reasons;
 deps__goals_1_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdeps__goals_3);
  allocp[2] = makeint(1L);
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a0;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[7] = a0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x0;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 deps__goals_1_ext_interrupt:
  reasonp = 0l;
 deps__goals_1_interrupt:
  goto interrupt_1;
 }

 deps__goals_3_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 deps__goals_3_clear_reason:
  reasonp = reasons;
 deps__goals_3_0:
 deps__goals_3_1:
  if (!isint(a0)) goto deps__goals_3_5;
 deps__goals_3_2:
  if (!isint(a1)) goto deps__goals_3_4;
  gblt_less_or_eq(a0,a1,deps__goals_3_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdeps__goals_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[7] = a0;
  allocp[8] = makeint(1L);
  allocp[9] = x0;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_print_xdatan_1);
  allocp[12] = x1 = makeref(&allocp[12]);
  allocp[13] = (q)(struct goalrec*)&allocp[10];
  allocp[14] = (q)(&predicate_print_xdata_1);
  allocp[15] = makesym(atom__20_20_20_20_20_20);
  allocp[16] = (q)(struct goalrec*)&allocp[13];
  allocp[17] = (q)(&predicate_functor__table_xarg_3);
  allocp[18] = a0;
  allocp[19] = a2;
  allocp[20] = x1;
  qp = (struct goalrec*)&allocp[16];
  allocp += 21;
  proceed();
 deps__goals_3_3:
  gblt_greater(a0,a1,deps__goals_3_interrupt);
  proceed();
 deps__goals_3_4:
  if (!isref(a1)) goto deps__goals_3_interrupt;
  deref_and_jump(a1,deps__goals_3_2);
  *reasonp++ =  a1;
  goto deps__goals_3_interrupt;
 deps__goals_3_5:
  if (!isref(a0)) goto deps__goals_3_interrupt;
  deref_and_jump(a0,deps__goals_3_1);
  *reasonp++ =  a0;
  goto deps__goals_3_interrupt;
 deps__goals_3_ext_interrupt:
  reasonp = 0l;
 deps__goals_3_interrupt:
  goto interrupt_3;
 }

 module__split_1_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  qp = qp->next;
 module__split_1_clear_reason:
  reasonp = reasons;
 module__split_1_0:
  x0 = makecons(cons_const_5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xmodule__split__modules_3);
  allocp[2] = a0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x0;
  allocp[5] = x1;
  allocp[6] = makesym(atom_nl);
  x2 = makecons(&allocp[5]);
  allocp[7] = x2;
  allocp[8] = makefunctor(funct_const_12);
  x3 = makecons(&allocp[7]);
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_print_xmodule__split__stdout_2);
  allocp[11] = x4 = makeref(&allocp[11]);
  allocp[12] = x3;
  allocp[13] = makesym(functor_stdout_1);
  allocp[14] = x4;
  x5 = makefunctor(&allocp[13]);
  allocp[15] = NILATOM;
  allocp[16] = x5;
  x6 = makecons(&allocp[15]);
  allocp[17] = (q)(struct goalrec*)&allocp[9];
  allocp[18] = (q)(&predicate_klicio_xklicio_1);
  allocp[19] = x6;
  allocp[20] = (q)(struct goalrec*)&allocp[17];
  allocp[21] = (q)(&predicate_print_xdatan_1);
  allocp[22] = a0;
  qp = (struct goalrec*)&allocp[20];
  allocp += 23;
  proceed();
 module__split_1_ext_interrupt:
  reasonp = 0l;
 module__split_1_interrupt:
  goto interrupt_1;
 }

 module__split__stdout_2_top: {
  q x0;
  a1 = qp->args[1];
  qp = qp->next;
 module__split__stdout_2_clear_reason:
  reasonp = reasons;
 module__split__stdout_2_0:
 module__split__stdout_2_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_normal_1)) goto module__split__stdout_2_2;
  x0 = arg(a0, 0);
  unify(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,module__split__stdout_2_1);
  *reasonp++ =  a0;
  goto module__split__stdout_2_2;
  };
  goto module__split__stdout_2_2;
 module__split__stdout_2_2:
  otherwise(module__split__stdout_2_interrupt);
  x0 = makesym(atom_error);
  unify(x0, makesym(atom_module__split__stdout));
  proceed();
 module__split__stdout_2_ext_interrupt:
  reasonp = 0l;
 module__split__stdout_2_interrupt:
  goto interrupt_2;
 }

 module__split__modules_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 module__split__modules_3_clear_reason:
  reasonp = reasons;
 module__split__modules_3_0:
 module__split__modules_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 module__split__modules_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto module__split__modules_3_4;
  x1 = cdr_of(a0);
 module__split__modules_3_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto module__split__modules_3_4;
  allocp[0] = makesym(functor_putt_1);
  allocp[1] = arg(x0, 0);
  x2 = makefunctor(&allocp[0]);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = makesym(atom_nl);
  x3 = makecons(&allocp[2]);
  allocp[4] = x3;
  allocp[5] = makefunctor(funct_const_8);
  x5 = makecons(&allocp[4]);
  allocp[6] = x5;
  allocp[7] = x2;
  x6 = makecons(&allocp[6]);
  allocp[8] = x6;
  allocp[9] = makefunctor(funct_const_7);
  x7 = makecons(&allocp[8]);
  allocp += 10;
  unify_value(a1, x7);
  allocp[0] = a2;
  allocp[1] = makesym(atom_nl);
  x8 = makecons(&allocp[0]);
  allocp[2] = x8;
  allocp[3] = makefunctor(funct_const_10);
  x9 = makecons(&allocp[2]);
  allocp[4] = x9;
  allocp[5] = makesym(atom_nl);
  x10 = makecons(&allocp[4]);
  allocp[6] = x10;
  allocp[7] = makefunctor(funct_const_9);
  x11 = makecons(&allocp[6]);
  a0 = arg(x0, 1);
  a1 = x4;
  a2 = x11;
  allocp += 8;
  execute(module__split__clauses_3_0);
  goto module__split__clauses_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,module__split__modules_3_3);
  *reasonp++ =  x1;
  goto module__split__modules_3_4;
  };
  goto module__split__modules_3_4;
 case VARREF:
  deref_and_jump(x0,module__split__modules_3_2);
  *reasonp++ =  x0;
  goto module__split__modules_3_4;
  };
  goto module__split__modules_3_4;
 case VARREF:
  deref_and_jump(a0,module__split__modules_3_1);
  *reasonp++ =  a0;
  goto module__split__modules_3_4;
  };
  goto module__split__modules_3_4;
 module__split__modules_3_4:
  otherwise(module__split__modules_3_interrupt);
 module__split__modules_3_5:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 module__split__modules_3_6:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto module__split__modules_3_interrupt;
  allocp[0] = makesym(functor_putt_1);
  allocp[1] = arg(x0, 0);
  x1 = makefunctor(&allocp[0]);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = makesym(atom_nl);
  x2 = makecons(&allocp[2]);
  allocp[4] = x2;
  allocp[5] = makefunctor(funct_const_8);
  x4 = makecons(&allocp[4]);
  allocp[6] = x4;
  allocp[7] = x1;
  x5 = makecons(&allocp[6]);
  allocp[8] = x5;
  allocp[9] = makefunctor(funct_const_7);
  x6 = makecons(&allocp[8]);
  allocp += 10;
  unify_value(a1, x6);
  allocp[0] = a2;
  allocp[1] = makesym(atom_nl);
  x7 = makecons(&allocp[0]);
  allocp[2] = x7;
  allocp[3] = makefunctor(funct_const_6);
  x8 = makecons(&allocp[2]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_print_xmodule__split__modules_3);
  x9 = cdr_of(a0);
  allocp[6] = x9;
  allocp[7] = x10 = makeref(&allocp[7]);
  allocp[8] = x8;
  allocp[9] = x10;
  allocp[10] = makesym(atom_nl);
  x11 = makecons(&allocp[9]);
  allocp[11] = x11;
  allocp[12] = makefunctor(funct_const_11);
  x12 = makecons(&allocp[11]);
  allocp[13] = x12;
  allocp[14] = makesym(atom_nl);
  x13 = makecons(&allocp[13]);
  allocp[15] = x13;
  allocp[16] = makefunctor(funct_const_9);
  x14 = makecons(&allocp[15]);
  a0 = arg(x0, 1);
  a1 = x3;
  a2 = x14;
  qp = (struct goalrec*)&allocp[4];
  allocp += 17;
  execute(module__split__clauses_3_0);
  goto module__split__clauses_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,module__split__modules_3_6);
  *reasonp++ =  x0;
  goto module__split__modules_3_interrupt;
  };
  goto module__split__modules_3_interrupt;
 case VARREF:
  deref_and_jump(a0,module__split__modules_3_5);
  *reasonp++ =  a0;
  goto module__split__modules_3_interrupt;
  };
  goto module__split__modules_3_interrupt;
 module__split__modules_3_ext_interrupt:
  reasonp = 0l;
 module__split__modules_3_interrupt:
  goto interrupt_3;
 }

 module__split__clauses_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 module__split__clauses_3_clear_reason:
  reasonp = reasons;
 module__split__clauses_3_0:
 module__split__clauses_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = cdr_of(a0);
 module__split__clauses_3_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != NILATOM) goto module__split__clauses_3_3;
  allocp[0] = a2;
  allocp[1] = makesym(atom_nl);
  x1 = makecons(&allocp[0]);
  allocp[2] = x1;
  allocp[3] = makefunctor(funct_const_10);
  x2 = makecons(&allocp[2]);
  allocp[4] = makesym(functor_putt_1);
  allocp[5] = x4 = makeref(&allocp[5]);
  x3 = makefunctor(&allocp[4]);
  allocp[6] = x2;
  allocp[7] = makesym(atom_nl);
  x5 = makecons(&allocp[6]);
  allocp[8] = x5;
  allocp[9] = x3;
  x6 = makecons(&allocp[8]);
  allocp += 10;
  unify_value(a1, x6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_variable_xwrap_2);
  x7 = car_of(a0);
  allocp[2] = x7;
  allocp[3] = x4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  proceed();
 case VARREF:
  deref_and_jump(x0,module__split__clauses_3_2);
  *reasonp++ =  x0;
  goto module__split__clauses_3_3;
  };
  goto module__split__clauses_3_3;
 case VARREF:
  deref_and_jump(a0,module__split__clauses_3_1);
  *reasonp++ =  a0;
  goto module__split__clauses_3_3;
  };
  goto module__split__clauses_3_3;
 module__split__clauses_3_3:
  otherwise(module__split__clauses_3_interrupt);
 module__split__clauses_3_4:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = a2;
  allocp[1] = makesym(atom_nl);
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = makefunctor(funct_const_6);
  x1 = makecons(&allocp[2]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_print_xmodule__split__clauses_3);
  x2 = cdr_of(a0);
  allocp[6] = x2;
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = x1;
  allocp[9] = x3;
  allocp[10] = makesym(atom_nl);
  x4 = makecons(&allocp[9]);
  allocp[11] = x4;
  allocp[12] = makefunctor(funct_const_11);
  x5 = makecons(&allocp[11]);
  allocp[13] = makesym(functor_putt_1);
  allocp[14] = x7 = makeref(&allocp[14]);
  x6 = makefunctor(&allocp[13]);
  allocp[15] = x5;
  allocp[16] = makesym(atom_nl);
  x8 = makecons(&allocp[15]);
  allocp[17] = x8;
  allocp[18] = x6;
  x9 = makecons(&allocp[17]);
  qp = (struct goalrec*)&allocp[4];
  allocp += 19;
  unify_value(a1, x9);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_variable_xwrap_2);
  x10 = car_of(a0);
  allocp[2] = x10;
  allocp[3] = x7;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  proceed();
 case VARREF:
  deref_and_jump(a0,module__split__clauses_3_4);
  *reasonp++ =  a0;
  goto module__split__clauses_3_interrupt;
  };
  goto module__split__clauses_3_interrupt;
 module__split__clauses_3_ext_interrupt:
  reasonp = 0l;
 module__split__clauses_3_interrupt:
  toppred = &predicate_print_xmodule__split__clauses_3;
  goto interrupt_3;
 }
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_print);
}
