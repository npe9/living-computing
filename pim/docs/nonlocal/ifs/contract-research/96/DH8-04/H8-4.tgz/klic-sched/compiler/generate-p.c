/* Compiled by KLIC compiler version 2.002 (Tue May 23 13:27:38 JST 1995) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_klic__comp__generate();
Const struct predicate predicate_klic__comp__generate_xprint__data_2 =
   { module_klic__comp__generate, 0, 2 };
Const struct predicate predicate_klic__comp__generate_xexit_1 =
   { module_klic__comp__generate, 1, 1 };
Const struct predicate predicate_klic__comp__generate_xgen__code_14 =
   { module_klic__comp__generate, 2, 14 };
Const struct predicate predicate_klic__comp__generate_xgen__code__1_15 =
   { module_klic__comp__generate, 3, 15 };
Const struct predicate predicate_klic__comp__generate_xgen__type__code_18 =
   { module_klic__comp__generate, 4, 18 };
Const struct predicate predicate_klic__comp__generate_xgen__code__3_14 =
   { module_klic__comp__generate, 5, 14 };
Const struct predicate predicate_klic__comp__generate_xgen__code__3__1_14 =
   { module_klic__comp__generate, 6, 14 };
Const struct predicate predicate_klic__comp__generate_xgen__code__3__2_14 =
   { module_klic__comp__generate, 7, 14 };
Const struct predicate predicate_klic__comp__generate_xgen__code__3__3_14 =
   { module_klic__comp__generate, 8, 14 };
Const struct predicate predicate_klic__comp__generate_xcase__info_7 =
   { module_klic__comp__generate, 9, 7 };
Const struct predicate predicate_klic__comp__generate_xgen__atomic_15 =
   { module_klic__comp__generate, 10, 15 };
Const struct predicate predicate_klic__comp__generate_xgen__atomic_2F15_240_18 =
   { module_klic__comp__generate, 11, 18 };
Const struct predicate predicate_klic__comp__generate_xgen__atomic_2F15_240_2F18_240_13 =
   { module_klic__comp__generate, 12, 13 };
Const struct predicate predicate_klic__comp__generate_xgen__atomic__2_20 =
   { module_klic__comp__generate, 13, 20 };
Const struct predicate predicate_klic__comp__generate_xgen__functs_15 =
   { module_klic__comp__generate, 14, 15 };
Const struct predicate predicate_klic__comp__generate_xgen__gobjs_15 =
   { module_klic__comp__generate, 15, 15 };
Const struct predicate predicate_klic__comp__generate_xgen__classes_15 =
   { module_klic__comp__generate, 16, 15 };
Const struct predicate predicate_klic__comp__generate_xgen__cases_16 =
   { module_klic__comp__generate, 17, 16 };
Const struct predicate predicate_klic__comp__generate_xgen__if__not_7 =
   { module_klic__comp__generate, 18, 7 };
Const struct predicate predicate_klic__comp__generate_xgen__sw__instr_3 =
   { module_klic__comp__generate, 19, 3 };
Const struct predicate predicate_klic__comp__generate_xgen__all__cases_14 =
   { module_klic__comp__generate, 20, 14 };
Const struct predicate predicate_klic__comp__generate_xgen__case__lab_5 =
   { module_klic__comp__generate, 21, 5 };
Const struct predicate predicate_klic__comp__generate_xgen__lab_5 =
   { module_klic__comp__generate, 22, 5 };
Const struct predicate predicate_klic__comp__generate_xgen__new__lab_5 =
   { module_klic__comp__generate, 23, 5 };
Const struct predicate predicate_klic__comp__generate_xgen__type__known_3 =
   { module_klic__comp__generate, 24, 3 };
Const struct predicate predicate_klic__comp__generate_xbasic__type_2 =
   { module_klic__comp__generate, 25, 2 };
Const struct predicate predicate_klic__comp__generate_xatomic__type_2 =
   { module_klic__comp__generate, 26, 2 };
Const struct predicate predicate_klic__comp__generate_xfunctor__type_2 =
   { module_klic__comp__generate, 27, 2 };
Const struct predicate predicate_klic__comp__generate_xgen__cond_12 =
   { module_klic__comp__generate, 28, 12 };
Const struct predicate predicate_klic__comp__generate_xadd__inline__info_3 =
   { module_klic__comp__generate, 29, 3 };
Const struct predicate predicate_klic__comp__generate_xload__guard__generic__out_11 =
   { module_klic__comp__generate, 30, 11 };
Const struct predicate predicate_klic__comp__generate_xprep__poss__for__set__tmake_10 =
   { module_klic__comp__generate, 31, 10 };
Const struct predicate predicate_klic__comp__generate_xprep__poss_10 =
   { module_klic__comp__generate, 32, 10 };
Const struct predicate predicate_klic__comp__generate_xprep__vec__elems_10 =
   { module_klic__comp__generate, 33, 10 };
Const struct predicate predicate_klic__comp__generate_xalloc__if__var_8 =
   { module_klic__comp__generate, 34, 8 };
Const struct predicate predicate_klic__comp__generate_xprep__pos__for__set__tmake_10 =
   { module_klic__comp__generate, 35, 10 };
Const struct predicate predicate_klic__comp__generate_xprep__pos_10 =
   { module_klic__comp__generate, 36, 10 };
Const struct predicate predicate_klic__comp__generate_xprep__pos__1_10 =
   { module_klic__comp__generate, 37, 10 };
Const struct predicate predicate_klic__comp__generate_xalloc__args__for__struct_13 =
   { module_klic__comp__generate, 38, 13 };
Const struct predicate predicate_klic__comp__generate_xalloc__one__for__struct_13 =
   { module_klic__comp__generate, 39, 13 };
Const struct predicate predicate_klic__comp__generate_xalloc__one__for__struct__1_13 =
   { module_klic__comp__generate, 40, 13 };
Const struct predicate predicate_klic__comp__generate_xload__inline__args_11 =
   { module_klic__comp__generate, 41, 11 };
Const struct predicate predicate_klic__comp__generate_xload__pos_10 =
   { module_klic__comp__generate, 42, 10 };
Const struct predicate predicate_klic__comp__generate_xload__reg_11 =
   { module_klic__comp__generate, 43, 11 };
Const struct predicate predicate_klic__comp__generate_xload__reg__1_11 =
   { module_klic__comp__generate, 44, 11 };
Const struct predicate predicate_klic__comp__generate_xload__reg__2_11 =
   { module_klic__comp__generate, 45, 11 };
Const struct predicate predicate_klic__comp__generate_xgen__body__arg_12 =
   { module_klic__comp__generate, 46, 12 };
Const struct predicate predicate_klic__comp__generate_xgen__body__arg__1_12 =
   { module_klic__comp__generate, 47, 12 };
Const struct predicate predicate_klic__comp__generate_xgen__out__vars_12 =
   { module_klic__comp__generate, 48, 12 };
Const struct predicate predicate_klic__comp__generate_xgen__out__var_12 =
   { module_klic__comp__generate, 49, 12 };
Const struct predicate predicate_klic__comp__generate_xgen__out__var__1_13 =
   { module_klic__comp__generate, 50, 13 };
Const struct predicate predicate_klic__comp__generate_xput__srec_6 =
   { module_klic__comp__generate, 51, 6 };
Const struct predicate predicate_klic__comp__generate_xgen__body_14 =
   { module_klic__comp__generate, 52, 14 };
Const struct predicate predicate_klic__comp__generate_xgen__body__goal_13 =
   { module_klic__comp__generate, 53, 13 };
Const struct predicate predicate_klic__comp__generate_xset__call_10 =
   { module_klic__comp__generate, 54, 10 };
Const struct predicate predicate_klic__comp__generate_xput__call_11 =
   { module_klic__comp__generate, 55, 11 };
Const struct predicate predicate_klic__comp__generate_xpush__tcall_11 =
   { module_klic__comp__generate, 56, 11 };
Const struct predicate predicate_klic__comp__generate_xset__args__for__newthread_10 =
   { module_klic__comp__generate, 57, 10 };
Const struct predicate predicate_klic__comp__generate_xset__call__merge_3 =
   { module_klic__comp__generate, 58, 3 };
Const struct predicate predicate_klic__comp__generate_xenq__at__prio_12 =
   { module_klic__comp__generate, 59, 12 };
Const struct predicate predicate_klic__comp__generate_xprio__code_7 =
   { module_klic__comp__generate, 60, 7 };
Const struct predicate predicate_klic__comp__generate_xbody__unify_12 =
   { module_klic__comp__generate, 61, 12 };
Const struct predicate predicate_klic__comp__generate_xbody__unify__1_11 =
   { module_klic__comp__generate, 62, 11 };
Const struct predicate predicate_klic__comp__generate_xbody__unify__2_7 =
   { module_klic__comp__generate, 63, 7 };
Const struct predicate predicate_klic__comp__generate_xbb__in_14 =
   { module_klic__comp__generate, 64, 14 };
Const struct predicate predicate_klic__comp__generate_xbb__in__type_3 =
   { module_klic__comp__generate, 65, 3 };
Const struct predicate predicate_klic__comp__generate_xbb__in__check_4 =
   { module_klic__comp__generate, 66, 4 };
Const struct predicate predicate_klic__comp__generate_xbb__out_14 =
   { module_klic__comp__generate, 67, 14 };
Const struct predicate predicate_klic__comp__generate_xbb__out__type_3 =
   { module_klic__comp__generate, 68, 3 };
Const struct predicate predicate_klic__comp__generate_xprep__call__arg_10 =
   { module_klic__comp__generate, 69, 10 };
Const struct predicate predicate_klic__comp__generate_xset__args_10 =
   { module_klic__comp__generate, 70, 10 };
Const struct predicate predicate_klic__comp__generate_xset__one_10 =
   { module_klic__comp__generate, 71, 10 };
Const struct predicate predicate_klic__comp__generate_xset__one__1_10 =
   { module_klic__comp__generate, 72, 10 };
Const struct predicate predicate_klic__comp__generate_xmake__var_7 =
   { module_klic__comp__generate, 73, 7 };
Const struct predicate predicate_klic__comp__generate_xput__args_12 =
   { module_klic__comp__generate, 74, 12 };
Const struct predicate predicate_klic__comp__generate_xput__one_12 =
   { module_klic__comp__generate, 75, 12 };
Const struct predicate predicate_klic__comp__generate_xput__one__1_12 =
   { module_klic__comp__generate, 76, 12 };
Const struct predicate predicate_klic__comp__generate_xset__generic__args_10 =
   { module_klic__comp__generate, 77, 10 };
Const struct predicate predicate_klic__comp__generate_xmove__args_10 =
   { module_klic__comp__generate, 78, 10 };
Const struct predicate predicate_klic__comp__generate_xmove__args__1_12 =
   { module_klic__comp__generate, 79, 12 };
Const struct predicate predicate_klic__comp__generate_xmove__one_10 =
   { module_klic__comp__generate, 80, 10 };
Const struct predicate predicate_klic__comp__generate_xmove__one__1_10 =
   { module_klic__comp__generate, 81, 10 };
Const struct predicate predicate_klic__comp__generate_xused__in_4 =
   { module_klic__comp__generate, 82, 4 };
Const struct predicate predicate_klic__comp__generate_xused__in__1_5 =
   { module_klic__comp__generate, 83, 5 };
Const struct predicate predicate_klic__comp__generate_xstrip__types_2 =
   { module_klic__comp__generate, 84, 2 };
Const struct predicate predicate_klic__comp__generate_xstrip__type_2 =
   { module_klic__comp__generate, 85, 2 };
Const struct predicate predicate_klic__comp__generate_xmake__label_2 =
   { module_klic__comp__generate, 86, 2 };
Const struct predicate predicate_klic__comp__generate_xadd__info_4 =
   { module_klic__comp__generate, 87, 4 };
Const struct predicate predicate_klic__comp__generate_xrassoc_3 =
   { module_klic__comp__generate, 88, 3 };
Const struct predicate predicate_klic__comp__generate_xassocx_3 =
   { module_klic__comp__generate, 89, 3 };
Const struct predicate predicate_klic__comp__generate_xassocx__for__set__tmake_3 =
   { module_klic__comp__generate, 90, 3 };
Const struct predicate predicate_klic__comp__generate_xreverse_3 =
   { module_klic__comp__generate, 91, 3 };
Const struct predicate predicate_klic__comp__generate_xappend_3 =
   { module_klic__comp__generate, 92, 3 };
Const struct predicate predicate_klic__comp__generate_xcount__arity__of__normal__call_6 =
   { module_klic__comp__generate, 93, 6 };
extern Const struct predicate predicate_unix_xexit_1;
extern Const struct predicate predicate_integer__arithmetics_xadd_3;
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_klic__comp__util_xmax_3;
extern Const struct predicate predicate_klic__comp__util_xmax__vect_2;
extern Const struct predicate predicate_klic__comp__util_xuniv_2;
extern Const struct predicate predicate_klic__comp__util_xappend_3;
extern Const struct predicate predicate_klic__comp__util_xlength_2;
extern Const struct predicate predicate_klic__comp__insert_xsubsumed__type_3;

module module_klic__comp__generate(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  static Const unsigned char strconst_body_0[8] =
    "ATOMIC";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_0 =
      declare_string_constant_8(strconst_body_0,6);
  static Const unsigned char strconst_body_1[4] =
    {'C','O','N','S',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_1 =
      declare_string_constant_8(strconst_body_1,4);
  static Const unsigned char strconst_body_2[8] =
    "FUNCTOR";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_2 =
      declare_string_constant_8(strconst_body_2,7);
  static Const unsigned char strconst_body_3[8] =
    "VARREF";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_3 =
      declare_string_constant_8(strconst_body_3,6);
  static Const q funct_const_4[] = {
    makesym(functor_case__label_1),
    makefunctor(&string_const_3),
  };
  static Const q funct_const_5[] = {
    makesym(functor_make__space_1),
    makeint(1),
  };
  q a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17, a18, a19;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  switch_on_pred() {
    case_pred(0, print__data_2_top);
    case_pred(1, exit_1_top);
    case_pred(2, gen__code_14_top);
    case_pred(3, gen__code__1_15_top);
    case_pred(4, gen__type__code_18_top);
    case_pred(5, gen__code__3_14_top);
    case_pred(6, gen__code__3__1_14_top);
    case_pred(7, gen__code__3__2_14_top);
    case_pred(8, gen__code__3__3_14_top);
    case_pred(9, case__info_7_top);
    case_pred(10, gen__atomic_15_top);
    case_pred(11, gen__atomic_2F15_240_18_top);
    case_pred(12, gen__atomic_2F15_240_2F18_240_13_top);
    case_pred(13, gen__atomic__2_20_top);
    case_pred(14, gen__functs_15_top);
    case_pred(15, gen__gobjs_15_top);
    case_pred(16, gen__classes_15_top);
    case_pred(17, gen__cases_16_top);
    case_pred(18, gen__if__not_7_top);
    case_pred(19, gen__sw__instr_3_top);
    case_pred(20, gen__all__cases_14_top);
    case_pred(21, gen__case__lab_5_top);
    case_pred(22, gen__lab_5_top);
    case_pred(23, gen__new__lab_5_top);
    case_pred(24, gen__type__known_3_top);
    case_pred(25, basic__type_2_top);
    case_pred(26, atomic__type_2_top);
    case_pred(27, functor__type_2_top);
    case_pred(28, gen__cond_12_top);
    case_pred(29, add__inline__info_3_top);
    case_pred(30, load__guard__generic__out_11_top);
    case_pred(31, prep__poss__for__set__tmake_10_top);
    case_pred(32, prep__poss_10_top);
    case_pred(33, prep__vec__elems_10_top);
    case_pred(34, alloc__if__var_8_top);
    case_pred(35, prep__pos__for__set__tmake_10_top);
    case_pred(36, prep__pos_10_top);
    case_pred(37, prep__pos__1_10_top);
    case_pred(38, alloc__args__for__struct_13_top);
    case_pred(39, alloc__one__for__struct_13_top);
    case_pred(40, alloc__one__for__struct__1_13_top);
    case_pred(41, load__inline__args_11_top);
    case_pred(42, load__pos_10_top);
    case_pred(43, load__reg_11_top);
    case_pred(44, load__reg__1_11_top);
    case_pred(45, load__reg__2_11_top);
    case_pred(46, gen__body__arg_12_top);
    case_pred(47, gen__body__arg__1_12_top);
    case_pred(48, gen__out__vars_12_top);
    case_pred(49, gen__out__var_12_top);
    case_pred(50, gen__out__var__1_13_top);
    case_pred(51, put__srec_6_top);
    case_pred(52, gen__body_14_top);
    case_pred(53, gen__body__goal_13_top);
    case_pred(54, set__call_10_top);
    case_pred(55, put__call_11_top);
    case_pred(56, push__tcall_11_top);
    case_pred(57, set__args__for__newthread_10_top);
    case_pred(58, set__call__merge_3_top);
    case_pred(59, enq__at__prio_12_top);
    case_pred(60, prio__code_7_top);
    case_pred(61, body__unify_12_top);
    case_pred(62, body__unify__1_11_top);
    case_pred(63, body__unify__2_7_top);
    case_pred(64, bb__in_14_top);
    case_pred(65, bb__in__type_3_top);
    case_pred(66, bb__in__check_4_top);
    case_pred(67, bb__out_14_top);
    case_pred(68, bb__out__type_3_top);
    case_pred(69, prep__call__arg_10_top);
    case_pred(70, set__args_10_top);
    case_pred(71, set__one_10_top);
    case_pred(72, set__one__1_10_top);
    case_pred(73, make__var_7_top);
    case_pred(74, put__args_12_top);
    case_pred(75, put__one_12_top);
    case_pred(76, put__one__1_12_top);
    case_pred(77, set__generic__args_10_top);
    case_pred(78, move__args_10_top);
    case_pred(79, move__args__1_12_top);
    case_pred(80, move__one_10_top);
    case_pred(81, move__one__1_10_top);
    case_pred(82, used__in_4_top);
    case_pred(83, used__in__1_5_top);
    case_pred(84, strip__types_2_top);
    case_pred(85, strip__type_2_top);
    case_pred(86, make__label_2_top);
    case_pred(87, add__info_4_top);
    case_pred(88, rassoc_3_top);
    case_pred(89, assocx_3_top);
    case_pred(90, assocx__for__set__tmake_3_top);
    case_pred(91, reverse_3_top);
    case_pred(92, append_3_top);
    last_case_pred(93, count__arity__of__normal__call_6_top);
  }

 print__data_2_top: {
  a1 = qp->args[1];
  qp = qp->next;
 print__data_2_clear_reason:
  reasonp = reasons;
 print__data_2_0:
  proceed();
 print__data_2_ext_interrupt:
  reasonp = 0l;
 print__data_2_interrupt:
  toppred = &predicate_klic__comp__generate_xprint__data_2;
  goto interrupt_2;
 }

 exit_1_top: {
  qp = qp->next;
 exit_1_clear_reason:
  reasonp = reasons;
 exit_1_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unix_xexit_1);
  allocp[2] = a0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 3;
  proceed();
 exit_1_ext_interrupt:
  reasonp = 0l;
 exit_1_interrupt:
  goto interrupt_1;
 }

 gen__code_14_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20, x21, x22, x23, x24, x25, x26, x27, x28, x29, x30, x31, x32, x33, x34;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  qp = qp->next;
 gen__code_14_clear_reason:
  reasonp = reasons;
 gen__code_14_0:
 gen__code_14_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_e)) goto gen__code_14_5;
  unify4(a13, a12, a11, a10, a9, a8, a7, a6);
  unify(a5, a4);
  a0 = a2;
  execute(make__label_2_0);
  goto make__label_2_ext_interrupt;
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_other_2:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__util_xmax_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a5;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_klic__comp__util_xmax_3);
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  x4 = arg(a0, 1);
  allocp[12] = x4;
  allocp[13] = a1;
  allocp[14] = makesym(atom_none);
  allocp[15] = a3;
  allocp[16] = x5 = makeref(&allocp[16]);
  allocp[17] = x1;
  allocp[18] = x6 = makeref(&allocp[18]);
  allocp[19] = a7;
  allocp[20] = x7 = makeref(&allocp[20]);
  allocp[21] = x3;
  allocp[22] = x8 = makeref(&allocp[22]);
  allocp[23] = a11;
  allocp[24] = x9 = makeref(&allocp[24]);
  allocp[25] = a13;
  qp = (struct goalrec*)&allocp[10];
  allocp += 26;
  unify2(x7, a8, x5, a4);
  allocp[0] = x9;
  allocp[1] = makesym(atom_otherwise);
  x10 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__generate_xgen__new__lab_5);
  allocp[4] = x11 = makeref(&allocp[4]);
  allocp[5] = x12 = makeref(&allocp[5]);
  allocp[6] = x6;
  allocp[7] = x13 = makeref(&allocp[7]);
  allocp[8] = x10;
  a0 = arg(a0, 0);
  a1 = x11;
  a5 = x0;
  a7 = x12;
  a9 = x2;
  a11 = x8;
  a13 = x13;
  qp = (struct goalrec*)&allocp[2];
  allocp += 9;
  execute(gen__code_14_0);
  goto gen__code_14_ext_interrupt;
 case functor_alter_2:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__util_xmax_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a5;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  x2 = arg(a0, 1);
  allocp[7] = x2;
  allocp[8] = a1;
  allocp[9] = makesym(atom_none);
  allocp[10] = a3;
  allocp[11] = x3 = makeref(&allocp[11]);
  allocp[12] = x1;
  allocp[13] = x4 = makeref(&allocp[13]);
  allocp[14] = a7;
  allocp[15] = x5 = makeref(&allocp[15]);
  allocp[16] = a9;
  allocp[17] = x6 = makeref(&allocp[17]);
  allocp[18] = a11;
  allocp[19] = x7 = makeref(&allocp[19]);
  allocp[20] = a13;
  qp = (struct goalrec*)&allocp[5];
  allocp += 21;
  unify(x3, a4);
  allocp[0] = x7;
  allocp[1] = makesym(atom_alternatively);
  x8 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__generate_xgen__new__lab_5);
  allocp[4] = x9 = makeref(&allocp[4]);
  allocp[5] = x10 = makeref(&allocp[5]);
  allocp[6] = x4;
  allocp[7] = x11 = makeref(&allocp[7]);
  allocp[8] = x8;
  a0 = arg(a0, 0);
  a1 = x9;
  a5 = x0;
  a7 = x10;
  a9 = x5;
  a11 = x6;
  a13 = x11;
  qp = (struct goalrec*)&allocp[2];
  allocp += 9;
  execute(gen__code_14_0);
  goto gen__code_14_ext_interrupt;
 case functor_l_1:
  unify(a9, a8);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xgen__body_14);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a8;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = makesym(atom_qp);
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a7;
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = a5;
  allocp[10] = x4 = makeref(&allocp[10]);
  allocp[11] = x5 = makeref(&allocp[11]);
  allocp[12] = a10;
  allocp[13] = a11;
  allocp[14] = x6 = makeref(&allocp[14]);
  allocp[15] = a13;
  allocp[16] = (q)(struct goalrec*)&allocp[0];
  allocp[17] = (q)(&predicate_klic__comp__generate_xprint__data_2);
  allocp[18] = makesym(atom_body1);
  allocp[19] = x0;
  allocp[20] = (q)(struct goalrec*)&allocp[16];
  allocp[21] = (q)(&predicate_klic__comp__generate_xprint__data_2);
  allocp[22] = makesym(atom_w);
  allocp[23] = x3;
  allocp[24] = (q)(struct goalrec*)&allocp[20];
  allocp[25] = (q)(&predicate_klic__comp__generate_xgen__body__arg_12);
  allocp[26] = x7 = makeref(&allocp[26]);
  allocp[27] = x0;
  allocp[28] = makeint(0L);
  allocp[29] = x8 = makeref(&allocp[29]);
  allocp[30] = makeint(0L);
  allocp[31] = x9 = makeref(&allocp[31]);
  allocp[32] = a4;
  allocp[33] = x3;
  allocp[34] = a3;
  allocp[35] = x4;
  allocp[36] = x10 = makeref(&allocp[36]);
  allocp[37] = x6;
  allocp[38] = (q)(struct goalrec*)&allocp[24];
  allocp[39] = (q)(&predicate_klic__comp__generate_xprint__data_2);
  allocp[40] = makesym(atom_w);
  allocp[41] = a4;
  allocp[42] = (q)(struct goalrec*)&allocp[38];
  allocp[43] = (q)(&predicate_klic__comp__generate_xprint__data_2);
  allocp[44] = makesym(atom_body);
  allocp[45] = x7;
  allocp[46] = (q)(struct goalrec*)&allocp[42];
  allocp[47] = (q)(&predicate_klic__comp__generate_xcount__arity__of__normal__call_6);
  x11 = arg(a0, 0);
  allocp[48] = x11;
  allocp[49] = makeint(0L);
  allocp[50] = x1;
  allocp[51] = x7;
  allocp[52] = x12 = makeref(&allocp[52]);
  allocp[53] = x10;
  a0 = a2;
  a1 = a6;
  a2 = x2;
  a3 = a12;
  a4 = x12;
  qp = (struct goalrec*)&allocp[46];
  allocp += 54;
  execute(gen__lab_5_0);
  goto gen__lab_5_ext_interrupt;
 case functor_x_3:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__util_xmax_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a5;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_klic__comp__util_xmax_3);
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = makesym(functor_lab_1);
  allocp[11] = x5 = makeref(&allocp[11]);
  x4 = makefunctor(&allocp[10]);
  allocp[12] = (q)(struct goalrec*)&allocp[5];
  allocp[13] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  x6 = arg(a0, 2);
  allocp[14] = x6;
  allocp[15] = a1;
  allocp[16] = x4;
  allocp[17] = x7 = makeref(&allocp[17]);
  allocp[18] = x8 = makeref(&allocp[18]);
  allocp[19] = x1;
  allocp[20] = x9 = makeref(&allocp[20]);
  allocp[21] = a7;
  allocp[22] = x10 = makeref(&allocp[22]);
  allocp[23] = x3;
  allocp[24] = x11 = makeref(&allocp[24]);
  allocp[25] = a11;
  allocp[26] = x12 = makeref(&allocp[26]);
  allocp[27] = a13;
  allocp[28] = (q)(struct goalrec*)&allocp[12];
  allocp[29] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  x13 = arg(a0, 1);
  allocp[30] = x13;
  allocp[31] = x5;
  allocp[32] = makesym(atom_none);
  allocp[33] = x7;
  allocp[34] = x14 = makeref(&allocp[34]);
  allocp[35] = x0;
  allocp[36] = x15 = makeref(&allocp[36]);
  allocp[37] = x9;
  allocp[38] = x16 = makeref(&allocp[38]);
  allocp[39] = x2;
  allocp[40] = x17 = makeref(&allocp[40]);
  allocp[41] = x11;
  allocp[42] = x18 = makeref(&allocp[42]);
  allocp[43] = x12;
  qp = (struct goalrec*)&allocp[28];
  allocp += 44;
  unify2(x10, x16, x8, x14);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xgen__cond_12);
  x19 = arg(a0, 0);
  allocp[2] = x19;
  allocp[3] = x5;
  allocp[4] = a4;
  allocp[5] = x14;
  allocp[6] = a3;
  allocp[7] = x7;
  allocp[8] = a8;
  allocp[9] = x16;
  allocp[10] = a10;
  allocp[11] = x17;
  allocp[12] = x20 = makeref(&allocp[12]);
  allocp[13] = x18;
  a0 = a2;
  a1 = a6;
  a2 = x15;
  a3 = a12;
  a4 = x20;
  qp = (struct goalrec*)&allocp[0];
  allocp += 14;
  execute(gen__lab_5_0);
  goto gen__lab_5_ext_interrupt;
 case functor_v_6:
  x0 = arg(a0, 1);
 gen__code_14_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_e)) goto gen__code_14_5;
  x1 = arg(a0, 2);
 gen__code_14_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_e)) goto gen__code_14_5;
  x2 = arg(a0, 3);
 gen__code_14_4:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != makesym(atom_e)) goto gen__code_14_5;
  bblt_add_no_check_y(a8,makeint(1L),x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__util_xmax_3);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = a5;
  allocp[5] = makesym(functor_lab_1);
  allocp[6] = x7 = makeref(&allocp[6]);
  x6 = makefunctor(&allocp[5]);
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  x8 = arg(a0, 5);
  allocp[9] = x8;
  allocp[10] = a1;
  allocp[11] = x6;
  allocp[12] = x9 = makeref(&allocp[12]);
  allocp[13] = x10 = makeref(&allocp[13]);
  allocp[14] = x5;
  allocp[15] = x11 = makeref(&allocp[15]);
  allocp[16] = a7;
  allocp[17] = x12 = makeref(&allocp[17]);
  allocp[18] = a9;
  allocp[19] = x13 = makeref(&allocp[19]);
  allocp[20] = a11;
  allocp[21] = x14 = makeref(&allocp[21]);
  allocp[22] = a13;
  allocp[23] = (q)(struct goalrec*)&allocp[7];
  allocp[24] = (q)(&predicate_klic__comp__util_xmax_3);
  allocp[25] = x3;
  allocp[26] = x15 = makeref(&allocp[26]);
  allocp[27] = x12;
  allocp[28] = makesym(functor_deref_3);
  allocp[29] = x17 = makeref(&allocp[29]);
  allocp[30] = x18 = makeref(&allocp[30]);
  allocp[31] = x7;
  x16 = makefunctor(&allocp[28]);
  allocp[32] = x14;
  allocp[33] = x16;
  x19 = makecons(&allocp[32]);
  allocp[34] = (q)(struct goalrec*)&allocp[23];
  allocp[35] = (q)(&predicate_klic__comp__generate_xgen__new__lab_5);
  allocp[36] = x20 = makeref(&allocp[36]);
  allocp[37] = x21 = makeref(&allocp[37]);
  allocp[38] = x11;
  allocp[39] = x22 = makeref(&allocp[39]);
  allocp[40] = x19;
  allocp[41] = (q)(struct goalrec*)&allocp[34];
  allocp[42] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  x23 = arg(a0, 4);
  allocp[43] = x23;
  allocp[44] = x7;
  allocp[45] = makesym(atom_none);
  allocp[46] = x9;
  allocp[47] = x24 = makeref(&allocp[47]);
  allocp[48] = x4;
  allocp[49] = x25 = makeref(&allocp[49]);
  allocp[50] = x21;
  allocp[51] = a8;
  allocp[52] = x15;
  allocp[53] = x26 = makeref(&allocp[53]);
  allocp[54] = x13;
  allocp[55] = x27 = makeref(&allocp[55]);
  allocp[56] = x22;
  allocp[57] = (q)(struct goalrec*)&allocp[41];
  allocp[58] = (q)(&predicate_klic__comp__generate_xadd__info_4);
  allocp[59] = x17;
  allocp[60] = makesym(atom_bound);
  allocp[61] = x28 = makeref(&allocp[61]);
  allocp[62] = x9;
  allocp[63] = makesym(functor_if__ref_2);
  allocp[64] = x17;
  allocp[65] = x20;
  x29 = makefunctor(&allocp[63]);
  allocp[66] = x27;
  allocp[67] = x29;
  x30 = makecons(&allocp[66]);
  allocp[68] = (q)(struct goalrec*)&allocp[57];
  allocp[69] = (q)(&predicate_klic__comp__generate_xgen__new__lab_5);
  allocp[70] = x18;
  allocp[71] = x31 = makeref(&allocp[71]);
  allocp[72] = x25;
  allocp[73] = x32 = makeref(&allocp[73]);
  allocp[74] = x30;
  qp = (struct goalrec*)&allocp[68];
  allocp += 75;
  unify(x10, x24);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xload__pos_10);
  x33 = arg(a0, 0);
  allocp[2] = x33;
  allocp[3] = x17;
  allocp[4] = a4;
  allocp[5] = x24;
  allocp[6] = a3;
  allocp[7] = x28;
  allocp[8] = a10;
  allocp[9] = x26;
  allocp[10] = x34 = makeref(&allocp[10]);
  allocp[11] = x32;
  a0 = a2;
  a1 = a6;
  a2 = x31;
  a3 = a12;
  a4 = x34;
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  execute(gen__lab_5_0);
  goto gen__lab_5_ext_interrupt;
 case VARREF:
  deref_and_jump(x2,gen__code_14_4);
  *reasonp++ =  x2;
  goto gen__code_14_5;
  };
  goto gen__code_14_5;
 case VARREF:
  deref_and_jump(x1,gen__code_14_3);
  *reasonp++ =  x1;
  goto gen__code_14_5;
  };
  goto gen__code_14_5;
 case VARREF:
  deref_and_jump(x0,gen__code_14_2);
  *reasonp++ =  x0;
  goto gen__code_14_5;
  };
  goto gen__code_14_5;
  };
  goto gen__code_14_5;
 case VARREF:
  deref_and_jump(a0,gen__code_14_1);
  *reasonp++ =  a0;
  goto gen__code_14_5;
  };
  goto gen__code_14_5;
 gen__code_14_5:
  otherwise(gen__code_14_interrupt);
 gen__code_14_6:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_v_6)) goto gen__code_14_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xgen__code__1_15);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = a8;
  allocp[12] = a9;
  allocp[13] = a10;
  allocp[14] = a11;
  allocp[15] = a12;
  allocp[16] = a13;
  a0 = arg(a0, 0);
  a1 = a3;
  a2 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 17;
  execute(gen__type__known_3_0);
  goto gen__type__known_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,gen__code_14_6);
  *reasonp++ =  a0;
  goto gen__code_14_interrupt;
  };
  goto gen__code_14_interrupt;
 gen__code_14_ext_interrupt:
  reasonp = 0l;
 gen__code_14_interrupt:
  toppred = &predicate_klic__comp__generate_xgen__code_14;
  goto interrupt_14;
 }

 gen__code__1_15_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20, x21, x22, x23, x24, x25, x26, x27, x28, x29, x30, x31, x32, x33, x34, x35, x36, x37, x38, x39, x40, x41, x42, x43, x44, x45, x46, x47, x48, x49, x50, x51;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  qp = qp->next;
 gen__code__1_15_clear_reason:
  reasonp = reasons;
 gen__code__1_15_0:
 gen__code__1_15_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_no)) goto gen__code__1_15_13;
 gen__code__1_15_2:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_v_6)) goto gen__code__1_15_13;
  x0 = arg(a1, 1);
 gen__code__1_15_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_a_5)) goto gen__code__1_15_13;
  x1 = arg(x0, 0);
 gen__code__1_15_4:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto gen__code__1_15_13;
  x2 = arg(x0, 1);
 gen__code__1_15_5:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != makesym(atom_e)) goto gen__code__1_15_13;
  x3 = arg(x0, 4);
 gen__code__1_15_6:
  switch (ptagof(x3)) {
 case ATOMIC:
  if (x3 != makesym(atom_e)) goto gen__code__1_15_13;
  x4 = arg(a1, 2);
 gen__code__1_15_7:
  switch (ptagof(x4)) {
 case ATOMIC:
  if (x4 != makesym(atom_e)) goto gen__code__1_15_13;
  x5 = arg(a1, 3);
 gen__code__1_15_8:
  switch (ptagof(x5)) {
 case ATOMIC:
  if (x5 != makesym(atom_e)) goto gen__code__1_15_13;
  x6 = arg(a1, 4);
 gen__code__1_15_9:
  switch (ptagof(x6)) {
 case ATOMIC:
  if (x6 != makesym(atom_e)) goto gen__code__1_15_13;
  x7 = arg(x0, 3);
 gen__code__1_15_10:
  switch (ptagof(x7)) {
 case ATOMIC:
  if (x7 != makesym(atom_e)) goto gen__code__1_15_11;
  a0 = a1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  a5 = a6;
  a6 = a7;
  a7 = a8;
  a8 = a9;
  a9 = a10;
  a10 = a11;
  a11 = a12;
  a12 = a13;
  a13 = a14;
  execute(gen__code__3_14_0);
  goto gen__code__3_14_ext_interrupt;
 case VARREF:
  deref_and_jump(x7,gen__code__1_15_10);
  *reasonp++ =  x7;
  goto gen__code__1_15_13;
  };
  goto gen__code__1_15_11;
 gen__code__1_15_11:
  gblt_diff(x7,makesym(atom_e),gen__code__1_15_13);
  bblt_add_no_check_y(a9,makeint(1L),x8);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__util_xmax_3);
  allocp[2] = x9 = makeref(&allocp[2]);
  allocp[3] = x10 = makeref(&allocp[3]);
  allocp[4] = a6;
  allocp[5] = makesym(functor_lab_1);
  allocp[6] = x12 = makeref(&allocp[6]);
  x11 = makefunctor(&allocp[5]);
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  x13 = arg(a1, 5);
  allocp[9] = x13;
  allocp[10] = a2;
  allocp[11] = x11;
  allocp[12] = x14 = makeref(&allocp[12]);
  allocp[13] = x15 = makeref(&allocp[13]);
  allocp[14] = x10;
  allocp[15] = x16 = makeref(&allocp[15]);
  allocp[16] = a8;
  allocp[17] = x17 = makeref(&allocp[17]);
  allocp[18] = a10;
  allocp[19] = x18 = makeref(&allocp[19]);
  allocp[20] = a12;
  allocp[21] = x19 = makeref(&allocp[21]);
  allocp[22] = a14;
  allocp[23] = (q)(struct goalrec*)&allocp[7];
  allocp[24] = (q)(&predicate_klic__comp__util_xmax_3);
  allocp[25] = x8;
  allocp[26] = x20 = makeref(&allocp[26]);
  allocp[27] = x17;
  allocp[28] = (q)(struct goalrec*)&allocp[23];
  allocp[29] = (q)(&predicate_klic__comp__util_xmax_3);
  allocp[30] = x21 = makeref(&allocp[30]);
  allocp[31] = x22 = makeref(&allocp[31]);
  allocp[32] = x20;
  allocp[33] = makesym(functor_deref_3);
  allocp[34] = x24 = makeref(&allocp[34]);
  allocp[35] = x25 = makeref(&allocp[35]);
  allocp[36] = x12;
  x23 = makefunctor(&allocp[33]);
  allocp[37] = x19;
  allocp[38] = x23;
  x26 = makecons(&allocp[37]);
  allocp[39] = makesym(functor_if__not__ref_2);
  allocp[40] = x24;
  allocp[41] = x12;
  x27 = makefunctor(&allocp[39]);
  allocp[42] = x26;
  allocp[43] = x27;
  x28 = makecons(&allocp[42]);
  allocp[44] = (q)(struct goalrec*)&allocp[28];
  allocp[45] = (q)(&predicate_klic__comp__generate_xgen__new__lab_5);
  allocp[46] = x29 = makeref(&allocp[46]);
  allocp[47] = x30 = makeref(&allocp[47]);
  allocp[48] = x16;
  allocp[49] = x31 = makeref(&allocp[49]);
  allocp[50] = x28;
  allocp[51] = makesym(functor_lab_1);
  allocp[52] = x33 = makeref(&allocp[52]);
  x32 = makefunctor(&allocp[51]);
  allocp[53] = (q)(struct goalrec*)&allocp[44];
  allocp[54] = (q)(&predicate_klic__comp__generate_xgen__cases_16);
  x34 = arg(x0, 2);
  allocp[55] = x34;
  allocp[56] = x12;
  allocp[57] = x32;
  allocp[58] = makesym(atom_int);
  allocp[59] = x24;
  allocp[60] = x35 = makeref(&allocp[60]);
  allocp[61] = x36 = makeref(&allocp[61]);
  allocp[62] = x9;
  allocp[63] = x37 = makeref(&allocp[63]);
  allocp[64] = x30;
  allocp[65] = a9;
  allocp[66] = x38 = makeref(&allocp[66]);
  allocp[67] = x39 = makeref(&allocp[67]);
  allocp[68] = x18;
  allocp[69] = x40 = makeref(&allocp[69]);
  allocp[70] = x31;
  qp = (struct goalrec*)&allocp[53];
  allocp += 71;
  unify(x22, a9);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  allocp[2] = x7;
  allocp[3] = x33;
  allocp[4] = makesym(atom_none);
  allocp[5] = x35;
  allocp[6] = x41 = makeref(&allocp[6]);
  allocp[7] = x36;
  allocp[8] = x42 = makeref(&allocp[8]);
  allocp[9] = x37;
  allocp[10] = a9;
  allocp[11] = x21;
  allocp[12] = x43 = makeref(&allocp[12]);
  allocp[13] = x39;
  allocp[14] = x44 = makeref(&allocp[14]);
  allocp[15] = x40;
  allocp[16] = (q)(struct goalrec*)&allocp[0];
  allocp[17] = (q)(&predicate_klic__comp__generate_xadd__info_4);
  allocp[18] = x24;
  allocp[19] = makesym(atom_int);
  allocp[20] = x45 = makeref(&allocp[20]);
  allocp[21] = x35;
  allocp[22] = makesym(functor_if__not__int_2);
  allocp[23] = x24;
  allocp[24] = x29;
  x46 = makefunctor(&allocp[22]);
  allocp[25] = x44;
  allocp[26] = x46;
  x47 = makecons(&allocp[25]);
  allocp[27] = (q)(struct goalrec*)&allocp[16];
  allocp[28] = (q)(&predicate_klic__comp__generate_xgen__new__lab_5);
  allocp[29] = x25;
  allocp[30] = x48 = makeref(&allocp[30]);
  allocp[31] = x42;
  allocp[32] = x49 = makeref(&allocp[32]);
  allocp[33] = x47;
  qp = (struct goalrec*)&allocp[27];
  allocp += 34;
  unify2(x15, x41, x14, x45);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xload__pos_10);
  x50 = arg(a1, 0);
  allocp[2] = x50;
  allocp[3] = x24;
  allocp[4] = a5;
  allocp[5] = x41;
  allocp[6] = a4;
  allocp[7] = x45;
  allocp[8] = a11;
  allocp[9] = x43;
  allocp[10] = x51 = makeref(&allocp[10]);
  allocp[11] = x49;
  a0 = a3;
  a1 = a7;
  a2 = x48;
  a3 = a13;
  a4 = x51;
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  execute(gen__lab_5_0);
  goto gen__lab_5_ext_interrupt;
 case VARREF:
  deref_and_jump(x6,gen__code__1_15_9);
  *reasonp++ =  x6;
  goto gen__code__1_15_13;
  };
  goto gen__code__1_15_13;
 case VARREF:
  deref_and_jump(x5,gen__code__1_15_8);
  *reasonp++ =  x5;
  goto gen__code__1_15_13;
  };
  goto gen__code__1_15_13;
 case VARREF:
  deref_and_jump(x4,gen__code__1_15_7);
  *reasonp++ =  x4;
  goto gen__code__1_15_13;
  };
  goto gen__code__1_15_13;
 case VARREF:
  deref_and_jump(x3,gen__code__1_15_6);
  *reasonp++ =  x3;
  goto gen__code__1_15_13;
  };
  goto gen__code__1_15_13;
 case VARREF:
  deref_and_jump(x2,gen__code__1_15_5);
  *reasonp++ =  x2;
  goto gen__code__1_15_13;
  };
  goto gen__code__1_15_13;
 case VARREF:
  deref_and_jump(x1,gen__code__1_15_4);
  *reasonp++ =  x1;
  goto gen__code__1_15_13;
  };
  goto gen__code__1_15_13;
 case VARREF:
  deref_and_jump(x0,gen__code__1_15_3);
  *reasonp++ =  x0;
  goto gen__code__1_15_13;
  };
  goto gen__code__1_15_13;
 case VARREF:
  deref_and_jump(a1,gen__code__1_15_2);
  *reasonp++ =  a1;
  goto gen__code__1_15_13;
  };
  goto gen__code__1_15_13;
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_yes_2)) goto gen__code__1_15_13;
 gen__code__1_15_12:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_v_6)) goto gen__code__1_15_13;
  allocp[0] = makesym(functor_lab_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  x2 = arg(a1, 5);
  allocp[4] = x2;
  allocp[5] = a2;
  allocp[6] = x0;
  allocp[7] = a4;
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = a6;
  allocp[10] = x4 = makeref(&allocp[10]);
  allocp[11] = a8;
  allocp[12] = x5 = makeref(&allocp[12]);
  allocp[13] = a10;
  allocp[14] = x6 = makeref(&allocp[14]);
  allocp[15] = a12;
  allocp[16] = x7 = makeref(&allocp[16]);
  allocp[17] = a14;
  allocp[18] = makesym(functor_lab_1);
  allocp[19] = x9 = makeref(&allocp[19]);
  x8 = makefunctor(&allocp[18]);
  allocp[20] = (q)(struct goalrec*)&allocp[2];
  allocp[21] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  x10 = arg(a1, 4);
  allocp[22] = x10;
  allocp[23] = x1;
  allocp[24] = x8;
  allocp[25] = a4;
  allocp[26] = x11 = makeref(&allocp[26]);
  allocp[27] = x3;
  allocp[28] = x12 = makeref(&allocp[28]);
  allocp[29] = x4;
  allocp[30] = x13 = makeref(&allocp[30]);
  allocp[31] = x5;
  allocp[32] = x14 = makeref(&allocp[32]);
  allocp[33] = x6;
  allocp[34] = x15 = makeref(&allocp[34]);
  allocp[35] = x7;
  x16 = arg(a0, 1);
  x17 = arg(a1, 1);
  a2 = arg(a1, 2);
  x18 = arg(a1, 3);
  x19 = a3;
  a6 = arg(a0, 0);
  x20 = a4;
  a8 = a5;
  a10 = a7;
  a12 = a9;
  a14 = a11;
  a15 = x14;
  a16 = a13;
  a17 = x15;
  a13 = x13;
  a11 = x12;
  a9 = x11;
  a7 = x20;
  a5 = x19;
  a4 = x9;
  a3 = x18;
  a1 = x17;
  a0 = x16;
  qp = (struct goalrec*)&allocp[20];
  allocp += 36;
  execute(gen__type__code_18_0);
  goto gen__type__code_18_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,gen__code__1_15_12);
  *reasonp++ =  a1;
  goto gen__code__1_15_13;
  };
  goto gen__code__1_15_13;
 case VARREF:
  deref_and_jump(a0,gen__code__1_15_1);
  *reasonp++ =  a0;
  goto gen__code__1_15_13;
  };
  goto gen__code__1_15_13;
 gen__code__1_15_13:
  otherwise(gen__code__1_15_interrupt);
 gen__code__1_15_14:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_no)) goto gen__code__1_15_interrupt;
  a0 = a1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  a5 = a6;
  a6 = a7;
  a7 = a8;
  a8 = a9;
  a9 = a10;
  a10 = a11;
  a11 = a12;
  a12 = a13;
  a13 = a14;
  execute(gen__code__3_14_0);
  goto gen__code__3_14_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,gen__code__1_15_14);
  *reasonp++ =  a0;
  goto gen__code__1_15_interrupt;
  };
  goto gen__code__1_15_interrupt;
 gen__code__1_15_ext_interrupt:
  reasonp = 0l;
 gen__code__1_15_interrupt:
  goto interrupt_15;
 }

 gen__type__code_18_top: {
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  qp = qp->next;
 gen__type__code_18_clear_reason:
  reasonp = reasons;
 gen__type__code_18_0:
 gen__type__code_18_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto gen__type__code_18_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_atomic)):
  a0 = a1;
  a1 = a4;
  a2 = a5;
  a3 = a6;
  a4 = a7;
  a5 = a8;
  a6 = a9;
  a7 = a10;
  a8 = a11;
  a9 = a12;
  a10 = a13;
  a11 = a14;
  a12 = a15;
  a13 = a16;
  a14 = a17;
  execute(gen__atomic_15_0);
  goto gen__atomic_15_ext_interrupt;
 case symval(makesym(atom_list)):
  a0 = a2;
  a1 = a4;
  a2 = a5;
  a3 = a7;
  a4 = a8;
  a5 = a9;
  a6 = a10;
  a7 = a11;
  a8 = a12;
  a9 = a13;
  a10 = a14;
  a11 = a15;
  a12 = a16;
  a13 = a17;
  execute(gen__code_14_0);
  goto gen__code_14_ext_interrupt;
 case symval(makesym(atom_functor)):
  a0 = a3;
  a1 = a4;
  a2 = a5;
  a3 = a6;
  a4 = a7;
  a5 = a8;
  a6 = a9;
  a7 = a10;
  a8 = a11;
  a9 = a12;
  a10 = a13;
  a11 = a14;
  a12 = a15;
  a13 = a16;
  a14 = a17;
  execute(gen__functs_15_0);
  goto gen__functs_15_ext_interrupt;
  };
  goto gen__type__code_18_interrupt;
 case VARREF:
  deref_and_jump(a0,gen__type__code_18_1);
  *reasonp++ =  a0;
  goto gen__type__code_18_interrupt;
  };
  goto gen__type__code_18_interrupt;
 gen__type__code_18_ext_interrupt:
  reasonp = 0l;
 gen__type__code_18_interrupt:
  toppred = &predicate_klic__comp__generate_xgen__type__code_18;
  goto interrupt_18;
 }

 gen__code__3_14_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20, x21, x22, x23, x24, x25, x26, x27, x28, x29, x30, x31, x32, x33, x34, x35, x36, x37, x38, x39, x40, x41, x42, x43, x44, x45, x46, x47, x48, x49, x50, x51, x52, x53;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  qp = qp->next;
 gen__code__3_14_clear_reason:
  reasonp = reasons;
 gen__code__3_14_0:
 gen__code__3_14_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_v_6)) goto gen__code__3_14_interrupt;
  bblt_add_no_check_y(a8,makeint(1L),x0);
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = x2 = makeref(&allocp[1]);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = x4 = makeref(&allocp[3]);
  allocp[4] = x5 = makeref(&allocp[4]);
  allocp[5] = x1;
  allocp[6] = x2;
  allocp[7] = x3;
  allocp[8] = x4;
  allocp[9] = x5;
  x6 = create_vector(&allocp[5], 5, allocp);
  allocp[10] = (q)qp;
  allocp[11] = (q)(&predicate_klic__comp__util_xmax__vect_2);
  allocp[12] = x6;
  allocp[13] = a5;
  allocp[14] = makesym(functor_lab_1);
  allocp[15] = x8 = makeref(&allocp[15]);
  x7 = makefunctor(&allocp[14]);
  allocp[16] = (q)(struct goalrec*)&allocp[10];
  allocp[17] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  x9 = arg(a0, 5);
  allocp[18] = x9;
  allocp[19] = a1;
  allocp[20] = x7;
  allocp[21] = x10 = makeref(&allocp[21]);
  allocp[22] = x11 = makeref(&allocp[22]);
  allocp[23] = x5;
  allocp[24] = x12 = makeref(&allocp[24]);
  allocp[25] = a7;
  allocp[26] = x13 = makeref(&allocp[26]);
  allocp[27] = a9;
  allocp[28] = x14 = makeref(&allocp[28]);
  allocp[29] = a11;
  allocp[30] = x15 = makeref(&allocp[30]);
  allocp[31] = a13;
  allocp[32] = x16 = makeref(&allocp[32]);
  allocp[33] = x17 = makeref(&allocp[33]);
  allocp[34] = x18 = makeref(&allocp[34]);
  allocp[35] = x19 = makeref(&allocp[35]);
  allocp[36] = x16;
  allocp[37] = x17;
  allocp[38] = x18;
  allocp[39] = x19;
  allocp[40] = x0;
  x20 = create_vector(&allocp[36], 5, allocp);
  allocp[41] = (q)(struct goalrec*)&allocp[16];
  allocp[42] = (q)(&predicate_klic__comp__util_xmax__vect_2);
  allocp[43] = x20;
  allocp[44] = x13;
  allocp[45] = makesym(functor_lab_1);
  allocp[46] = x22 = makeref(&allocp[46]);
  x21 = makefunctor(&allocp[45]);
  allocp[47] = (q)(struct goalrec*)&allocp[41];
  allocp[48] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  x23 = arg(a0, 4);
  allocp[49] = x23;
  allocp[50] = x8;
  allocp[51] = x21;
  allocp[52] = x24 = makeref(&allocp[52]);
  allocp[53] = x11;
  allocp[54] = x4;
  allocp[55] = x25 = makeref(&allocp[55]);
  allocp[56] = x12;
  allocp[57] = a8;
  allocp[58] = x19;
  allocp[59] = x26 = makeref(&allocp[59]);
  allocp[60] = x14;
  allocp[61] = x27 = makeref(&allocp[61]);
  allocp[62] = x15;
  allocp[63] = (q)(struct goalrec*)&allocp[47];
  allocp[64] = (q)(&predicate_klic__comp__generate_xadd__info_4);
  allocp[65] = x28 = makeref(&allocp[65]);
  allocp[66] = makesym(atom_bound);
  allocp[67] = x10;
  allocp[68] = x24;
  allocp[69] = makesym(functor_goto_1);
  allocp[70] = x22;
  x29 = makefunctor(&allocp[69]);
  allocp[71] = x27;
  allocp[72] = x29;
  x30 = makecons(&allocp[71]);
  allocp[73] = x30;
  allocp[74] = makesym(atom_end__sw);
  x31 = makecons(&allocp[73]);
  allocp[75] = makesym(functor_deref_3);
  allocp[76] = x28;
  allocp[77] = x33 = makeref(&allocp[77]);
  allocp[78] = x8;
  x32 = makefunctor(&allocp[75]);
  allocp[79] = x31;
  allocp[80] = x32;
  x34 = makecons(&allocp[79]);
  allocp[81] = x34;
  allocp[82] = makefunctor(funct_const_4);
  x35 = makecons(&allocp[81]);
  allocp[83] = (q)(struct goalrec*)&allocp[63];
  allocp[84] = (q)(&predicate_klic__comp__generate_xgen__code__3__3_14);
  x36 = arg(a0, 3);
  allocp[85] = x36;
  allocp[86] = x22;
  allocp[87] = x28;
  allocp[88] = x10;
  allocp[89] = x11;
  allocp[90] = x3;
  allocp[91] = x37 = makeref(&allocp[91]);
  allocp[92] = x25;
  allocp[93] = a8;
  allocp[94] = x18;
  allocp[95] = x38 = makeref(&allocp[95]);
  allocp[96] = x26;
  allocp[97] = x39 = makeref(&allocp[97]);
  allocp[98] = x35;
  allocp[99] = (q)(struct goalrec*)&allocp[83];
  allocp[100] = (q)(&predicate_klic__comp__generate_xgen__code__3__2_14);
  x40 = arg(a0, 1);
  allocp[101] = x40;
  allocp[102] = x22;
  allocp[103] = x28;
  allocp[104] = x10;
  allocp[105] = x11;
  allocp[106] = x2;
  allocp[107] = x41 = makeref(&allocp[107]);
  allocp[108] = x37;
  allocp[109] = a8;
  allocp[110] = x17;
  allocp[111] = x42 = makeref(&allocp[111]);
  allocp[112] = x38;
  allocp[113] = x43 = makeref(&allocp[113]);
  allocp[114] = x39;
  allocp[115] = (q)(struct goalrec*)&allocp[99];
  allocp[116] = (q)(&predicate_klic__comp__generate_xgen__code__3__1_14);
  x44 = arg(a0, 2);
  allocp[117] = x44;
  allocp[118] = x22;
  allocp[119] = x28;
  allocp[120] = x10;
  allocp[121] = x11;
  allocp[122] = x1;
  allocp[123] = x45 = makeref(&allocp[123]);
  allocp[124] = x41;
  allocp[125] = a8;
  allocp[126] = x16;
  allocp[127] = x46 = makeref(&allocp[127]);
  allocp[128] = x42;
  allocp[129] = x47 = makeref(&allocp[129]);
  allocp[130] = x43;
  allocp[131] = makesym(functor_sw__tag_1);
  allocp[132] = x28;
  x48 = makefunctor(&allocp[131]);
  allocp[133] = x47;
  allocp[134] = x48;
  x49 = makecons(&allocp[133]);
  allocp[135] = (q)(struct goalrec*)&allocp[115];
  allocp[136] = (q)(&predicate_klic__comp__generate_xgen__new__lab_5);
  allocp[137] = x33;
  allocp[138] = x50 = makeref(&allocp[138]);
  allocp[139] = x45;
  allocp[140] = x51 = makeref(&allocp[140]);
  allocp[141] = x49;
  allocp[142] = (q)(struct goalrec*)&allocp[135];
  allocp[143] = (q)(&predicate_klic__comp__generate_xload__pos_10);
  x52 = arg(a0, 0);
  allocp[144] = x52;
  allocp[145] = x28;
  allocp[146] = a4;
  allocp[147] = x11;
  allocp[148] = a3;
  allocp[149] = x10;
  allocp[150] = a10;
  allocp[151] = x46;
  allocp[152] = x53 = makeref(&allocp[152]);
  allocp[153] = x51;
  a0 = a2;
  a1 = a6;
  a2 = x50;
  a3 = a12;
  a4 = x53;
  qp = (struct goalrec*)&allocp[142];
  allocp += 154;
  execute(gen__lab_5_0);
  goto gen__lab_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,gen__code__3_14_1);
  *reasonp++ =  a0;
  goto gen__code__3_14_interrupt;
  };
  goto gen__code__3_14_interrupt;
 gen__code__3_14_ext_interrupt:
  reasonp = 0l;
 gen__code__3_14_interrupt:
  toppred = &predicate_klic__comp__generate_xgen__code__3_14;
  goto interrupt_14;
 }

 gen__code__3__1_14_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  qp = qp->next;
 gen__code__3__1_14_clear_reason:
  reasonp = reasons;
 gen__code__3__1_14_0:
 gen__code__3__1_14_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_e)) goto gen__code__3__1_14_2;
  unify4(a13, a12, a11, a10, a9, a8, a7, a6);
  unify(a5, a4);
  proceed();
 case VARREF:
  deref_and_jump(a0,gen__code__3__1_14_1);
  *reasonp++ =  a0;
  goto gen__code__3__1_14_interrupt;
  };
  goto gen__code__3__1_14_2;
 gen__code__3__1_14_2:
  gblt_diff(a0,makesym(atom_e),gen__code__3__1_14_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = makesym(atom_none);
  allocp[5] = x0 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  allocp[12] = a10;
  allocp[13] = a11;
  allocp[14] = x1 = makeref(&allocp[14]);
  allocp[15] = a13;
  a0 = a2;
  a1 = makesym(atom_list);
  a2 = makefunctor(&string_const_1);
  a4 = x0;
  a5 = a12;
  a6 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 16;
  execute(case__info_7_0);
  goto case__info_7_ext_interrupt;
 gen__code__3__1_14_ext_interrupt:
  reasonp = 0l;
 gen__code__3__1_14_interrupt:
  goto interrupt_14;
 }

 gen__code__3__2_14_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  qp = qp->next;
 gen__code__3__2_14_clear_reason:
  reasonp = reasons;
 gen__code__3__2_14_0:
 gen__code__3__2_14_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_e)) goto gen__code__3__2_14_2;
  unify4(a13, a12, a11, a10, a9, a8, a7, a6);
  unify(a5, a4);
  proceed();
 case VARREF:
  deref_and_jump(a0,gen__code__3__2_14_1);
  *reasonp++ =  a0;
  goto gen__code__3__2_14_interrupt;
  };
  goto gen__code__3__2_14_2;
 gen__code__3__2_14_2:
  gblt_diff(a0,makesym(atom_e),gen__code__3__2_14_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xgen__atomic_15);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = makesym(atom_none);
  allocp[5] = a2;
  allocp[6] = x0 = makeref(&allocp[6]);
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = a8;
  allocp[12] = a9;
  allocp[13] = a10;
  allocp[14] = a11;
  allocp[15] = x1 = makeref(&allocp[15]);
  allocp[16] = a13;
  a0 = a2;
  a1 = makesym(atom_atomic);
  a2 = makefunctor(&string_const_0);
  a4 = x0;
  a5 = a12;
  a6 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 17;
  execute(case__info_7_0);
  goto case__info_7_ext_interrupt;
 gen__code__3__2_14_ext_interrupt:
  reasonp = 0l;
 gen__code__3__2_14_interrupt:
  goto interrupt_14;
 }

 gen__code__3__3_14_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  qp = qp->next;
 gen__code__3__3_14_clear_reason:
  reasonp = reasons;
 gen__code__3__3_14_0:
 gen__code__3__3_14_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_e)) goto gen__code__3__3_14_2;
  unify4(a13, a12, a11, a10, a9, a8, a7, a6);
  unify(a5, a4);
  proceed();
 case VARREF:
  deref_and_jump(a0,gen__code__3__3_14_1);
  *reasonp++ =  a0;
  goto gen__code__3__3_14_interrupt;
  };
  goto gen__code__3__3_14_2;
 gen__code__3__3_14_2:
  gblt_diff(a0,makesym(atom_e),gen__code__3__3_14_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xgen__functs_15);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = makesym(atom_none);
  allocp[5] = a2;
  allocp[6] = x0 = makeref(&allocp[6]);
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = a8;
  allocp[12] = a9;
  allocp[13] = a10;
  allocp[14] = a11;
  allocp[15] = x1 = makeref(&allocp[15]);
  allocp[16] = a13;
  a0 = a2;
  a1 = makesym(atom_functor);
  a2 = makefunctor(&string_const_2);
  a4 = x0;
  a5 = a12;
  a6 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 17;
  execute(case__info_7_0);
  goto case__info_7_ext_interrupt;
 gen__code__3__3_14_ext_interrupt:
  reasonp = 0l;
 gen__code__3__3_14_interrupt:
  goto interrupt_14;
 }

 case__info_7_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 case__info_7_clear_reason:
  reasonp = reasons;
 case__info_7_0:
  allocp[0] = makesym(functor_case__label_1);
  allocp[1] = a2;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = a6;
  allocp[3] = x0;
  x1 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a5, x1);
  a2 = a3;
  a3 = a4;
  execute(add__info_4_0);
  goto add__info_4_ext_interrupt;
 case__info_7_ext_interrupt:
  reasonp = 0l;
 case__info_7_interrupt:
  toppred = &predicate_klic__comp__generate_xcase__info_7;
  goto interrupt_7;
 }

 gen__atomic_15_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  qp = qp->next;
 gen__atomic_15_clear_reason:
  reasonp = reasons;
 gen__atomic_15_0:
 gen__atomic_15_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_e)) goto gen__atomic_15_interrupt;
  unify4(a14, a13, a12, a11, a10, a9, a8, a7);
  unify(a6, a5);
  a0 = a2;
  execute(make__label_2_0);
  goto make__label_2_ext_interrupt;
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_a_5)) goto gen__atomic_15_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xgen__atomic_2F15_240_18);
  x0 = arg(a0, 0);
  allocp[2] = x0;
  x1 = arg(a0, 1);
  allocp[3] = x1;
  x2 = arg(a0, 3);
  allocp[4] = x2;
  x3 = arg(a0, 2);
  allocp[5] = x3;
  x4 = arg(a0, 4);
  allocp[6] = x4;
  allocp[7] = a1;
  allocp[8] = a3;
  allocp[9] = a4;
  allocp[10] = a5;
  allocp[11] = x5 = makeref(&allocp[11]);
  allocp[12] = a9;
  allocp[13] = a11;
  allocp[14] = x6 = makeref(&allocp[14]);
  allocp[15] = a6;
  allocp[16] = a8;
  allocp[17] = a10;
  allocp[18] = a12;
  allocp[19] = a14;
  a0 = a2;
  a1 = a7;
  a2 = x5;
  a3 = a13;
  a4 = x6;
  qp = (struct goalrec*)&allocp[0];
  allocp += 20;
  execute(gen__lab_5_0);
  goto gen__lab_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,gen__atomic_15_1);
  *reasonp++ =  a0;
  goto gen__atomic_15_interrupt;
  };
  goto gen__atomic_15_interrupt;
 gen__atomic_15_ext_interrupt:
  reasonp = 0l;
 gen__atomic_15_interrupt:
  toppred = &predicate_klic__comp__generate_xgen__atomic_15;
  goto interrupt_15;
 }

 gen__atomic_2F15_240_18_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20, x21, x22, x23;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  qp = qp->next;
 gen__atomic_2F15_240_18_clear_reason:
  reasonp = reasons;
 gen__atomic_2F15_240_18_0:
 gen__atomic_2F15_240_18_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != NILATOM) goto gen__atomic_2F15_240_18_5;
 gen__atomic_2F15_240_18_2:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_e)) goto gen__atomic_2F15_240_18_5;
 gen__atomic_2F15_240_18_3:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_e)) goto gen__atomic_2F15_240_18_4;
  a0 = a3;
  a1 = a2;
  a2 = a4;
  a3 = a5;
  a4 = a6;
  a5 = a7;
  allocp[0] = x0 = makeref(&allocp[0]);
  a6 = x0;
  allocp[1] = x1 = makeref(&allocp[1]);
  a7 = x1;
  x2 = a13;
  x3 = a9;
  x4 = a14;
  x5 = a10;
  a13 = a10;
  a14 = a10;
  x6 = a11;
  x7 = a16;
  a18 = a12;
  a19 = a17;
  a17 = x7;
  a16 = x6;
  a12 = x5;
  a11 = x4;
  a10 = x3;
  a9 = x2;
  allocp += 2;
  execute(gen__atomic__2_20_0);
  goto gen__atomic__2_20_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,gen__atomic_2F15_240_18_3);
  *reasonp++ =  a2;
  goto gen__atomic_2F15_240_18_5;
  };
  goto gen__atomic_2F15_240_18_4;
 gen__atomic_2F15_240_18_4:
  gblt_diff(a2,makesym(atom_e),gen__atomic_2F15_240_18_5);
  allocp[0] = makesym(functor_if__not__int_2);
  allocp[1] = a6;
  allocp[2] = a5;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = x0;
  x1 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a12, x1);
  a0 = a3;
  a1 = a2;
  a2 = a4;
  a3 = a5;
  a4 = a6;
  a5 = a7;
  allocp[0] = x3 = makeref(&allocp[0]);
  a6 = x3;
  allocp[1] = x4 = makeref(&allocp[1]);
  a7 = x4;
  x5 = a13;
  x6 = a9;
  x7 = a14;
  a12 = a10;
  a13 = a10;
  a14 = a10;
  x8 = a11;
  x9 = a16;
  a18 = x2;
  a19 = a17;
  a17 = x9;
  a16 = x8;
  a11 = x7;
  a10 = x6;
  a9 = x5;
  allocp += 2;
  execute(gen__atomic__2_20_0);
  goto gen__atomic__2_20_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,gen__atomic_2F15_240_18_2);
  *reasonp++ =  a1;
  goto gen__atomic_2F15_240_18_5;
  };
  goto gen__atomic_2F15_240_18_5;
 case VARREF:
  deref_and_jump(a0,gen__atomic_2F15_240_18_1);
  *reasonp++ =  a0;
  goto gen__atomic_2F15_240_18_9;
  };
  goto gen__atomic_2F15_240_18_5;
 gen__atomic_2F15_240_18_5:
  gblt_diff(a0,NILATOM,gen__atomic_2F15_240_18_9);
 gen__atomic_2F15_240_18_6:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_e)) goto gen__atomic_2F15_240_18_9;
 gen__atomic_2F15_240_18_7:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != NILATOM) goto gen__atomic_2F15_240_18_9;
 gen__atomic_2F15_240_18_8:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_e)) goto gen__atomic_2F15_240_18_9;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__util_xmax_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a13;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_klic__comp__generate_xgen__atomic__2_20);
  allocp[7] = NILATOM;
  allocp[8] = makesym(atom_e);
  allocp[9] = a4;
  allocp[10] = a5;
  allocp[11] = a6;
  allocp[12] = a7;
  allocp[13] = x2 = makeref(&allocp[13]);
  allocp[14] = x3 = makeref(&allocp[14]);
  allocp[15] = x4 = makeref(&allocp[15]);
  allocp[16] = x1;
  allocp[17] = x5 = makeref(&allocp[17]);
  allocp[18] = a14;
  allocp[19] = x6 = makeref(&allocp[19]);
  allocp[20] = x7 = makeref(&allocp[20]);
  allocp[21] = x7;
  allocp[22] = a15;
  allocp[23] = x8 = makeref(&allocp[23]);
  allocp[24] = a16;
  allocp[25] = x9 = makeref(&allocp[25]);
  allocp[26] = a17;
  allocp[27] = (q)(struct goalrec*)&allocp[5];
  allocp[28] = (q)(&predicate_klic__comp__generate_xgen__cases_16);
  allocp[29] = a0;
  allocp[30] = x3;
  allocp[31] = makesym(atom_none);
  allocp[32] = makesym(atom_sym);
  allocp[33] = a6;
  allocp[34] = x10 = makeref(&allocp[34]);
  allocp[35] = x11 = makeref(&allocp[35]);
  allocp[36] = x0;
  allocp[37] = x12 = makeref(&allocp[37]);
  allocp[38] = x5;
  allocp[39] = x13 = makeref(&allocp[39]);
  allocp[40] = x7;
  allocp[41] = x14 = makeref(&allocp[41]);
  allocp[42] = x8;
  allocp[43] = x15 = makeref(&allocp[43]);
  allocp[44] = x9;
  qp = (struct goalrec*)&allocp[27];
  allocp += 45;
  unify2(x4, x11, x6, x13);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xadd__info_4);
  allocp[2] = a6;
  allocp[3] = makesym(atom_atom);
  allocp[4] = a7;
  allocp[5] = x10;
  a1 = x11;
  a2 = a8;
  a3 = x12;
  a4 = a9;
  a5 = x13;
  x16 = a10;
  a7 = x14;
  a8 = a11;
  a9 = x15;
  a10 = a12;
  a11 = a6;
  a12 = x3;
  a6 = x16;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(gen__atomic_2F15_240_2F18_240_13_0);
  goto gen__atomic_2F15_240_2F18_240_13_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,gen__atomic_2F15_240_18_8);
  *reasonp++ =  a2;
  goto gen__atomic_2F15_240_18_9;
  };
  goto gen__atomic_2F15_240_18_9;
 case VARREF:
  deref_and_jump(a3,gen__atomic_2F15_240_18_7);
  *reasonp++ =  a3;
  goto gen__atomic_2F15_240_18_9;
  };
  goto gen__atomic_2F15_240_18_9;
 case VARREF:
  deref_and_jump(a1,gen__atomic_2F15_240_18_6);
  *reasonp++ =  a1;
  goto gen__atomic_2F15_240_18_9;
  };
  goto gen__atomic_2F15_240_18_9;
 gen__atomic_2F15_240_18_9:
  otherwise(gen__atomic_2F15_240_18_interrupt);
  allocp[0] = makesym(functor_if__int_2);
  allocp[1] = a6;
  allocp[2] = x1 = makeref(&allocp[2]);
  x0 = makefunctor(&allocp[0]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x0;
  x2 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a12, x2);
  allocp[0] = x4 = makeref(&allocp[0]);
  allocp[1] = x5 = makeref(&allocp[1]);
  allocp[2] = x6 = makeref(&allocp[2]);
  allocp[3] = x4;
  allocp[4] = x5;
  allocp[5] = x6;
  x7 = create_vector(&allocp[3], 3, allocp);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_klic__comp__util_xmax__vect_2);
  allocp[8] = x7;
  allocp[9] = a13;
  allocp[10] = (q)(struct goalrec*)&allocp[6];
  allocp[11] = (q)(&predicate_klic__comp__generate_xgen__atomic__2_20);
  allocp[12] = a3;
  allocp[13] = a2;
  allocp[14] = a4;
  allocp[15] = a5;
  allocp[16] = a6;
  allocp[17] = a7;
  allocp[18] = x1;
  allocp[19] = x8 = makeref(&allocp[19]);
  allocp[20] = x9 = makeref(&allocp[20]);
  allocp[21] = x6;
  allocp[22] = x10 = makeref(&allocp[22]);
  allocp[23] = a14;
  allocp[24] = x11 = makeref(&allocp[24]);
  allocp[25] = x12 = makeref(&allocp[25]);
  allocp[26] = x13 = makeref(&allocp[26]);
  allocp[27] = a15;
  allocp[28] = x14 = makeref(&allocp[28]);
  allocp[29] = a16;
  allocp[30] = x15 = makeref(&allocp[30]);
  allocp[31] = a17;
  allocp[32] = makesym(functor_lab_1);
  allocp[33] = x17 = makeref(&allocp[33]);
  x16 = makefunctor(&allocp[32]);
  allocp[34] = (q)(struct goalrec*)&allocp[10];
  allocp[35] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  allocp[36] = a1;
  allocp[37] = x8;
  allocp[38] = x16;
  allocp[39] = x18 = makeref(&allocp[39]);
  allocp[40] = x19 = makeref(&allocp[40]);
  allocp[41] = x5;
  allocp[42] = x20 = makeref(&allocp[42]);
  allocp[43] = x10;
  allocp[44] = x21 = makeref(&allocp[44]);
  allocp[45] = x13;
  allocp[46] = x22 = makeref(&allocp[46]);
  allocp[47] = x14;
  allocp[48] = x23 = makeref(&allocp[48]);
  allocp[49] = x15;
  qp = (struct goalrec*)&allocp[34];
  allocp += 50;
  unify2(x19, x9, x21, x11);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xgen__cases_16);
  allocp[2] = a0;
  allocp[3] = x17;
  allocp[4] = makesym(atom_none);
  allocp[5] = makesym(atom_sym);
  allocp[6] = a6;
  allocp[7] = x18;
  allocp[8] = a8;
  allocp[9] = x4;
  allocp[10] = a9;
  allocp[11] = x20;
  allocp[12] = a10;
  allocp[13] = x12;
  allocp[14] = a11;
  allocp[15] = x22;
  allocp[16] = x3;
  allocp[17] = x23;
  qp = (struct goalrec*)&allocp[0];
  allocp += 18;
  unify2(x9, a8, x11, a10);
  a0 = a6;
  a1 = makesym(atom_atom);
  a2 = a7;
  a3 = x18;
  execute(add__info_4_0);
  goto add__info_4_ext_interrupt;
 gen__atomic_2F15_240_18_ext_interrupt:
  reasonp = 0l;
 gen__atomic_2F15_240_18_interrupt:
  goto interrupt_18;
 }

 gen__atomic_2F15_240_2F18_240_13_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  qp = qp->next;
 gen__atomic_2F15_240_2F18_240_13_clear_reason:
  reasonp = reasons;
 gen__atomic_2F15_240_2F18_240_13_0:
 gen__atomic_2F15_240_2F18_240_13_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = cdr_of(a0);
 gen__atomic_2F15_240_2F18_240_13_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != NILATOM) goto gen__atomic_2F15_240_2F18_240_13_3;
  unify4(a1, a2, a3, a4, a5, a6, a7, a8);
  unify(a9, a10);
  proceed();
 case VARREF:
  deref_and_jump(x0,gen__atomic_2F15_240_2F18_240_13_2);
  *reasonp++ =  x0;
  goto gen__atomic_2F15_240_2F18_240_13_3;
  };
  goto gen__atomic_2F15_240_2F18_240_13_3;
 case VARREF:
  deref_and_jump(a0,gen__atomic_2F15_240_2F18_240_13_1);
  *reasonp++ =  a0;
  goto gen__atomic_2F15_240_2F18_240_13_3;
  };
  goto gen__atomic_2F15_240_2F18_240_13_3;
 gen__atomic_2F15_240_2F18_240_13_3:
  otherwise(gen__atomic_2F15_240_2F18_240_13_interrupt);
  allocp[0] = makesym(functor_if__int_2);
  allocp[1] = a11;
  allocp[2] = a12;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = x0;
  x1 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a10, x1);
  unify4(a1, a2, a3, a4, a5, a6, a7, a8);
  unify(a9, x2);
  proceed();
 gen__atomic_2F15_240_2F18_240_13_ext_interrupt:
  reasonp = 0l;
 gen__atomic_2F15_240_2F18_240_13_interrupt:
  toppred = &predicate_klic__comp__generate_xgen__atomic_2F15_240_2F18_240_13;
  goto interrupt_13;
 }

 gen__atomic__2_20_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  a18 = qp->args[18];
  a19 = qp->args[19];
  qp = qp->next;
 gen__atomic__2_20_clear_reason:
  reasonp = reasons;
 gen__atomic__2_20_0:
  allocp[0] = makesym(functor_lab_1);
  allocp[1] = a7;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x0;
  allocp[7] = a5;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = x2 = makeref(&allocp[10]);
  allocp[11] = a11;
  allocp[12] = x3 = makeref(&allocp[12]);
  allocp[13] = a15;
  allocp[14] = x4 = makeref(&allocp[14]);
  allocp[15] = a17;
  allocp[16] = x5 = makeref(&allocp[16]);
  allocp[17] = a19;
  allocp[18] = x6 = makeref(&allocp[18]);
  allocp[19] = x7 = makeref(&allocp[19]);
  allocp[20] = a13;
  allocp[21] = a14;
  allocp[22] = x6;
  allocp[23] = x7;
  x8 = create_vector(&allocp[20], 4, allocp);
  allocp[24] = (q)(struct goalrec*)&allocp[2];
  allocp[25] = (q)(&predicate_klic__comp__util_xmax__vect_2);
  allocp[26] = x8;
  allocp[27] = x3;
  allocp[28] = makesym(functor_lab_1);
  allocp[29] = x10 = makeref(&allocp[29]);
  x9 = makefunctor(&allocp[28]);
  allocp[30] = (q)(struct goalrec*)&allocp[24];
  allocp[31] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  allocp[32] = a1;
  allocp[33] = a7;
  allocp[34] = x9;
  allocp[35] = x11 = makeref(&allocp[35]);
  allocp[36] = x12 = makeref(&allocp[36]);
  allocp[37] = x1;
  allocp[38] = x13 = makeref(&allocp[38]);
  allocp[39] = x2;
  allocp[40] = a12;
  allocp[41] = x7;
  allocp[42] = x14 = makeref(&allocp[42]);
  allocp[43] = x4;
  allocp[44] = x15 = makeref(&allocp[44]);
  allocp[45] = x5;
  allocp[46] = makesym(functor_lab_1);
  allocp[47] = a6;
  x16 = makefunctor(&allocp[46]);
  allocp[48] = (q)(struct goalrec*)&allocp[30];
  allocp[49] = (q)(&predicate_klic__comp__generate_xgen__cases_16);
  allocp[50] = a0;
  allocp[51] = x10;
  allocp[52] = x16;
  allocp[53] = makesym(atom_int);
  allocp[54] = a4;
  allocp[55] = x11;
  allocp[56] = a8;
  allocp[57] = x12;
  allocp[58] = a10;
  allocp[59] = x13;
  allocp[60] = a12;
  allocp[61] = x6;
  allocp[62] = a16;
  allocp[63] = x14;
  allocp[64] = a18;
  allocp[65] = x15;
  a0 = a4;
  a1 = makesym(atom_int);
  a2 = a5;
  a3 = x11;
  qp = (struct goalrec*)&allocp[48];
  allocp += 66;
  execute(add__info_4_0);
  goto add__info_4_ext_interrupt;
 gen__atomic__2_20_ext_interrupt:
  reasonp = 0l;
 gen__atomic__2_20_interrupt:
  toppred = &predicate_klic__comp__generate_xgen__atomic__2_20;
  goto interrupt_20;
 }

 gen__functs_15_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20, x21;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  qp = qp->next;
 gen__functs_15_clear_reason:
  reasonp = reasons;
 gen__functs_15_0:
 gen__functs_15_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_e)) goto gen__functs_15_interrupt;
  unify4(a14, a13, a12, a11, a10, a9, a8, a7);
  unify(a6, a5);
  a0 = a2;
  execute(make__label_2_0);
  goto make__label_2_ext_interrupt;
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_f_3)) goto gen__functs_15_interrupt;
  allocp[0] = x0 = makeref(&allocp[0]);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x0;
  allocp[4] = x1;
  allocp[5] = x2;
  x3 = create_vector(&allocp[3], 3, allocp);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_klic__comp__util_xmax__vect_2);
  allocp[8] = x3;
  allocp[9] = a6;
  allocp[10] = makesym(functor_lab_1);
  allocp[11] = x5 = makeref(&allocp[11]);
  x4 = makefunctor(&allocp[10]);
  allocp[12] = (q)(struct goalrec*)&allocp[6];
  allocp[13] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  x6 = arg(a0, 2);
  allocp[14] = x6;
  allocp[15] = a1;
  allocp[16] = x4;
  allocp[17] = a4;
  allocp[18] = x7 = makeref(&allocp[18]);
  allocp[19] = x2;
  allocp[20] = x8 = makeref(&allocp[20]);
  allocp[21] = a8;
  allocp[22] = x9 = makeref(&allocp[22]);
  allocp[23] = a10;
  allocp[24] = x10 = makeref(&allocp[24]);
  allocp[25] = a12;
  allocp[26] = x11 = makeref(&allocp[26]);
  allocp[27] = a14;
  qp = (struct goalrec*)&allocp[12];
  allocp += 28;
  unify(x7, a5);
  allocp[0] = makesym(functor_lab_1);
  allocp[1] = x13 = makeref(&allocp[1]);
  x12 = makefunctor(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__generate_xgen__gobjs_15);
  x14 = arg(a0, 1);
  allocp[4] = x14;
  allocp[5] = x5;
  allocp[6] = x12;
  allocp[7] = a3;
  allocp[8] = a4;
  allocp[9] = x15 = makeref(&allocp[9]);
  allocp[10] = x1;
  allocp[11] = x16 = makeref(&allocp[11]);
  allocp[12] = x8;
  allocp[13] = x17 = makeref(&allocp[13]);
  allocp[14] = x9;
  allocp[15] = x18 = makeref(&allocp[15]);
  allocp[16] = x10;
  allocp[17] = x19 = makeref(&allocp[17]);
  allocp[18] = x11;
  qp = (struct goalrec*)&allocp[2];
  allocp += 19;
  unify(x15, a5);
  a0 = arg(a0, 0);
  a1 = x13;
  x20 = a3;
  x21 = a4;
  a6 = a5;
  a8 = a7;
  a10 = a9;
  a12 = a11;
  a14 = a13;
  a15 = x19;
  a13 = x18;
  a11 = x17;
  a9 = x16;
  a7 = x0;
  a5 = x21;
  a4 = x20;
  a3 = makesym(atom_funct);
  execute(gen__cases_16_0);
  goto gen__cases_16_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,gen__functs_15_1);
  *reasonp++ =  a0;
  goto gen__functs_15_interrupt;
  };
  goto gen__functs_15_interrupt;
 gen__functs_15_ext_interrupt:
  reasonp = 0l;
 gen__functs_15_interrupt:
  toppred = &predicate_klic__comp__generate_xgen__functs_15;
  goto interrupt_15;
 }

 gen__gobjs_15_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  qp = qp->next;
 gen__gobjs_15_clear_reason:
  reasonp = reasons;
 gen__gobjs_15_0:
 gen__gobjs_15_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_e)) goto gen__gobjs_15_interrupt;
  unify4(a14, a13, a12, a11, a10, a9, a8, a7);
  unify(a6, a5);
  a0 = a2;
  execute(make__label_2_0);
  goto make__label_2_ext_interrupt;
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_o_2)) goto gen__gobjs_15_interrupt;
  allocp[0] = makesym(functor_lab_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  x2 = arg(a0, 1);
  allocp[4] = x2;
  allocp[5] = a1;
  allocp[6] = x0;
  allocp[7] = a4;
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = a6;
  allocp[10] = x4 = makeref(&allocp[10]);
  allocp[11] = a8;
  allocp[12] = x5 = makeref(&allocp[12]);
  allocp[13] = a10;
  allocp[14] = x6 = makeref(&allocp[14]);
  allocp[15] = a12;
  allocp[16] = x7 = makeref(&allocp[16]);
  allocp[17] = a14;
  allocp[18] = (q)(struct goalrec*)&allocp[2];
  allocp[19] = (q)(&predicate_klic__comp__generate_xgen__classes_15);
  x8 = arg(a0, 0);
  allocp[20] = x8;
  allocp[21] = x1;
  allocp[22] = makesym(atom_none);
  allocp[23] = a3;
  allocp[24] = a4;
  allocp[25] = a5;
  allocp[26] = x3;
  allocp[27] = x9 = makeref(&allocp[27]);
  allocp[28] = x4;
  allocp[29] = a9;
  allocp[30] = x5;
  allocp[31] = a11;
  allocp[32] = x6;
  allocp[33] = x10 = makeref(&allocp[33]);
  allocp[34] = x7;
  allocp[35] = makesym(functor_if__not__gobj_2);
  allocp[36] = a3;
  allocp[37] = a1;
  x11 = makefunctor(&allocp[35]);
  allocp[38] = x10;
  allocp[39] = x11;
  x12 = makecons(&allocp[38]);
  a0 = a2;
  a1 = a7;
  a2 = x9;
  a3 = a13;
  a4 = x12;
  qp = (struct goalrec*)&allocp[18];
  allocp += 40;
  execute(gen__lab_5_0);
  goto gen__lab_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,gen__gobjs_15_1);
  *reasonp++ =  a0;
  goto gen__gobjs_15_interrupt;
  };
  goto gen__gobjs_15_interrupt;
 gen__gobjs_15_ext_interrupt:
  reasonp = 0l;
 gen__gobjs_15_interrupt:
  goto interrupt_15;
 }

 gen__classes_15_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  qp = qp->next;
 gen__classes_15_clear_reason:
  reasonp = reasons;
 gen__classes_15_0:
 gen__classes_15_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 gen__classes_15_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__2D_2)) goto gen__classes_15_interrupt;
  allocp[0] = makesym(functor_lab_1);
  allocp[1] = x2 = makeref(&allocp[1]);
  x1 = makefunctor(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__generate_xgen__classes_15);
  x3 = cdr_of(a0);
  allocp[4] = x3;
  allocp[5] = a1;
  allocp[6] = x1;
  allocp[7] = a3;
  allocp[8] = a4;
  allocp[9] = x4 = makeref(&allocp[9]);
  allocp[10] = a6;
  allocp[11] = x5 = makeref(&allocp[11]);
  allocp[12] = a8;
  allocp[13] = x6 = makeref(&allocp[13]);
  allocp[14] = a10;
  allocp[15] = x7 = makeref(&allocp[15]);
  allocp[16] = a12;
  allocp[17] = x8 = makeref(&allocp[17]);
  allocp[18] = a14;
  allocp[19] = (q)(struct goalrec*)&allocp[2];
  allocp[20] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  x9 = arg(x0, 1);
  allocp[21] = x9;
  allocp[22] = a1;
  allocp[23] = makesym(atom_none);
  allocp[24] = a4;
  allocp[25] = a5;
  allocp[26] = x4;
  allocp[27] = x10 = makeref(&allocp[27]);
  allocp[28] = x5;
  allocp[29] = a9;
  allocp[30] = x6;
  allocp[31] = x11 = makeref(&allocp[31]);
  allocp[32] = x7;
  allocp[33] = x12 = makeref(&allocp[33]);
  allocp[34] = x8;
  allocp[35] = makesym(functor_guse_1);
  allocp[36] = arg(x0, 0);
  x13 = makefunctor(&allocp[35]);
  allocp[37] = x11;
  allocp[38] = x13;
  x14 = makecons(&allocp[37]);
  qp = (struct goalrec*)&allocp[19];
  allocp += 39;
  unify_value(a11, x14);
  allocp[0] = makesym(functor_if__not__class_3);
  allocp[1] = a3;
  allocp[2] = arg(x0, 0);
  allocp[3] = x2;
  x15 = makefunctor(&allocp[0]);
  allocp[4] = x12;
  allocp[5] = x15;
  x16 = makecons(&allocp[4]);
  a0 = a2;
  a1 = a7;
  a2 = x10;
  a3 = a13;
  a4 = x16;
  allocp += 6;
  execute(gen__lab_5_0);
  goto gen__lab_5_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,gen__classes_15_2);
  *reasonp++ =  x0;
  goto gen__classes_15_interrupt;
  };
  goto gen__classes_15_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto gen__classes_15_interrupt;
  unify4(a14, a13, a12, a11, a10, a9, a8, a7);
  unify(a6, a5);
  a0 = a2;
  execute(make__label_2_0);
  goto make__label_2_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,gen__classes_15_1);
  *reasonp++ =  a0;
  goto gen__classes_15_interrupt;
  };
  goto gen__classes_15_interrupt;
 gen__classes_15_ext_interrupt:
  reasonp = 0l;
 gen__classes_15_interrupt:
  goto interrupt_15;
 }

 gen__cases_16_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  qp = qp->next;
 gen__cases_16_clear_reason:
  reasonp = reasons;
 gen__cases_16_0:
 gen__cases_16_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = cdr_of(a0);
 gen__cases_16_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != NILATOM) goto gen__cases_16_4;
  x1 = car_of(a0);
 gen__cases_16_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor__2D_2)) goto gen__cases_16_4;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  x2 = arg(x1, 1);
  allocp[2] = x2;
  allocp[3] = a1;
  allocp[4] = makesym(atom_none);
  allocp[5] = a5;
  allocp[6] = a6;
  allocp[7] = a7;
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = a11;
  allocp[12] = x4 = makeref(&allocp[12]);
  allocp[13] = a13;
  allocp[14] = x5 = makeref(&allocp[14]);
  allocp[15] = a15;
  allocp[16] = x5;
  allocp[17] = x7 = makeref(&allocp[17]);
  x6 = makecons(&allocp[16]);
  allocp[18] = (q)(struct goalrec*)&allocp[0];
  allocp[19] = (q)(&predicate_klic__comp__generate_xgen__if__not_7);
  allocp[20] = a3;
  x8 = arg(x1, 0);
  allocp[21] = x8;
  allocp[22] = a4;
  allocp[23] = a1;
  allocp[24] = x7;
  allocp[25] = a12;
  allocp[26] = x4;
  a0 = a2;
  a1 = a8;
  a2 = x3;
  a3 = a14;
  a4 = x6;
  qp = (struct goalrec*)&allocp[18];
  allocp += 27;
  execute(gen__lab_5_0);
  goto gen__lab_5_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,gen__cases_16_3);
  *reasonp++ =  x1;
  goto gen__cases_16_4;
  };
  goto gen__cases_16_4;
 case VARREF:
  deref_and_jump(x0,gen__cases_16_2);
  *reasonp++ =  x0;
  goto gen__cases_16_interrupt;
  };
  goto gen__cases_16_4;
 gen__cases_16_4:
  gblt_diff(x0,NILATOM,gen__cases_16_interrupt);
  allocp[0] = makesym(functor_goto_1);
  allocp[1] = a1;
  x1 = makefunctor(&allocp[0]);
  allocp[2] = a15;
  allocp[3] = x1;
  x2 = makecons(&allocp[2]);
  allocp[4] = x2;
  allocp[5] = makesym(atom_end__sw);
  x3 = makecons(&allocp[4]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_klic__comp__generate_xgen__all__cases_14);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a3;
  allocp[11] = a5;
  allocp[12] = a6;
  allocp[13] = a7;
  allocp[14] = x4 = makeref(&allocp[14]);
  allocp[15] = a9;
  allocp[16] = a10;
  allocp[17] = a11;
  allocp[18] = a12;
  allocp[19] = a13;
  allocp[20] = x5 = makeref(&allocp[20]);
  allocp[21] = x3;
  allocp[22] = x5;
  allocp[23] = x7 = makeref(&allocp[23]);
  x6 = makecons(&allocp[22]);
  allocp[24] = (q)(struct goalrec*)&allocp[6];
  allocp[25] = (q)(&predicate_klic__comp__generate_xgen__sw__instr_3);
  allocp[26] = a3;
  allocp[27] = a4;
  allocp[28] = x7;
  a0 = a2;
  a1 = a8;
  a2 = x4;
  a3 = a14;
  a4 = x6;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  execute(gen__lab_5_0);
  goto gen__lab_5_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto gen__cases_16_interrupt;
  unify4(a15, a14, a13, a12, a11, a10, a9, a8);
  unify(a7, a6);
  a0 = a2;
  execute(make__label_2_0);
  goto make__label_2_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,gen__cases_16_1);
  *reasonp++ =  a0;
  goto gen__cases_16_interrupt;
  };
  goto gen__cases_16_interrupt;
 gen__cases_16_ext_interrupt:
  reasonp = 0l;
 gen__cases_16_interrupt:
  toppred = &predicate_klic__comp__generate_xgen__cases_16;
  goto interrupt_16;
 }

 gen__if__not_7_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 gen__if__not_7_clear_reason:
  reasonp = reasons;
 gen__if__not_7_0:
 gen__if__not_7_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto gen__if__not_7_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_sym)):
  allocp[0] = makesym(functor_atom_1);
  allocp[1] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_if__not_3);
  allocp[3] = a2;
  allocp[4] = x0;
  allocp[5] = a3;
  x1 = makefunctor(&allocp[2]);
  allocp += 6;
  unify_value(a4, x1);
  allocp[0] = a6;
  allocp[1] = x0;
  x2 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a5, x2);
  proceed();
 case symval(makesym(atom_int)):
  unify(a6, a5);
  allocp[0] = makesym(functor_int_1);
  allocp[1] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_if__not_3);
  allocp[3] = a2;
  allocp[4] = x0;
  allocp[5] = a3;
  x1 = makefunctor(&allocp[2]);
  allocp += 6;
  unify_value(a4, x1);
  proceed();
 case symval(makesym(atom_funct)):
  allocp[0] = makesym(functor_if__funct__not_3);
  allocp[1] = a2;
  allocp[2] = a1;
  allocp[3] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a4, x0);
  allocp[0] = makesym(functor_funct_1);
  allocp[1] = a1;
  x1 = makefunctor(&allocp[0]);
  allocp[2] = a6;
  allocp[3] = x1;
  x2 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a5, x2);
  proceed();
  };
  goto gen__if__not_7_interrupt;
 case VARREF:
  deref_and_jump(a0,gen__if__not_7_1);
  *reasonp++ =  a0;
  goto gen__if__not_7_interrupt;
  };
  goto gen__if__not_7_interrupt;
 gen__if__not_7_ext_interrupt:
  reasonp = 0l;
 gen__if__not_7_interrupt:
  goto interrupt_7;
 }

 gen__sw__instr_3_top: {
  q x0;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 gen__sw__instr_3_clear_reason:
  reasonp = reasons;
 gen__sw__instr_3_0:
 gen__sw__instr_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto gen__sw__instr_3_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_sym)):
  allocp[0] = makesym(functor_sw__sym_1);
  allocp[1] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  proceed();
 case symval(makesym(atom_int)):
  allocp[0] = makesym(functor_sw__int_1);
  allocp[1] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  proceed();
 case symval(makesym(atom_funct)):
  allocp[0] = makesym(functor_sw__funct_1);
  allocp[1] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  proceed();
  };
  goto gen__sw__instr_3_interrupt;
 case VARREF:
  deref_and_jump(a0,gen__sw__instr_3_1);
  *reasonp++ =  a0;
  goto gen__sw__instr_3_interrupt;
  };
  goto gen__sw__instr_3_interrupt;
 gen__sw__instr_3_ext_interrupt:
  reasonp = 0l;
 gen__sw__instr_3_interrupt:
  goto interrupt_3;
 }

 gen__all__cases_14_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  qp = qp->next;
 gen__all__cases_14_clear_reason:
  reasonp = reasons;
 gen__all__cases_14_0:
 gen__all__cases_14_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 gen__all__cases_14_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__2D_2)) goto gen__all__cases_14_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__util_xmax_3);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a5;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_klic__comp__util_xmax_3);
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_klic__comp__generate_xgen__all__cases_14);
  x5 = cdr_of(a0);
  allocp[12] = x5;
  allocp[13] = a1;
  allocp[14] = a2;
  allocp[15] = a3;
  allocp[16] = x6 = makeref(&allocp[16]);
  allocp[17] = x2;
  allocp[18] = x7 = makeref(&allocp[18]);
  allocp[19] = a7;
  allocp[20] = x8 = makeref(&allocp[20]);
  allocp[21] = x4;
  allocp[22] = x9 = makeref(&allocp[22]);
  allocp[23] = a11;
  allocp[24] = x10 = makeref(&allocp[24]);
  allocp[25] = a13;
  allocp[26] = (q)(struct goalrec*)&allocp[10];
  allocp[27] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  x11 = arg(x0, 1);
  allocp[28] = x11;
  allocp[29] = a1;
  allocp[30] = makesym(atom_none);
  allocp[31] = a3;
  allocp[32] = a4;
  allocp[33] = x1;
  allocp[34] = a6;
  allocp[35] = x7;
  allocp[36] = a8;
  allocp[37] = x3;
  allocp[38] = x12 = makeref(&allocp[38]);
  allocp[39] = x9;
  allocp[40] = x13 = makeref(&allocp[40]);
  allocp[41] = x10;
  qp = (struct goalrec*)&allocp[26];
  allocp += 42;
  unify2(x6, a4, x8, a8);
  allocp[0] = x13;
  allocp[1] = x15 = makeref(&allocp[1]);
  x14 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a12, x14);
  a0 = a2;
  a1 = arg(x0, 0);
  a2 = x15;
  a3 = a10;
  a4 = x12;
  execute(gen__case__lab_5_0);
  goto gen__case__lab_5_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,gen__all__cases_14_2);
  *reasonp++ =  x0;
  goto gen__all__cases_14_interrupt;
  };
  goto gen__all__cases_14_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto gen__all__cases_14_interrupt;
  unify4(a13, a12, a11, a10, a9, a8, a7, a6);
  unify(a5, a4);
  proceed();
 case VARREF:
  deref_and_jump(a0,gen__all__cases_14_1);
  *reasonp++ =  a0;
  goto gen__all__cases_14_interrupt;
  };
  goto gen__all__cases_14_interrupt;
 gen__all__cases_14_ext_interrupt:
  reasonp = 0l;
 gen__all__cases_14_interrupt:
  goto interrupt_14;
 }

 gen__case__lab_5_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 gen__case__lab_5_clear_reason:
  reasonp = reasons;
 gen__case__lab_5_0:
 gen__case__lab_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto gen__case__lab_5_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_sym)):
  allocp[0] = makesym(functor_case__sym_1);
  allocp[1] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  allocp[0] = makesym(functor_atom_1);
  allocp[1] = a1;
  x1 = makefunctor(&allocp[0]);
  allocp[2] = a4;
  allocp[3] = x1;
  x2 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a3, x2);
  proceed();
 case symval(makesym(atom_int)):
  unify(a4, a3);
  allocp[0] = makesym(functor_case__int_1);
  allocp[1] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  proceed();
 case symval(makesym(atom_funct)):
  allocp[0] = makesym(functor_case__funct_1);
  allocp[1] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  allocp[0] = makesym(functor_funct_1);
  allocp[1] = a1;
  x1 = makefunctor(&allocp[0]);
  allocp[2] = a4;
  allocp[3] = x1;
  x2 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a3, x2);
  proceed();
  };
  goto gen__case__lab_5_interrupt;
 case VARREF:
  deref_and_jump(a0,gen__case__lab_5_1);
  *reasonp++ =  a0;
  goto gen__case__lab_5_interrupt;
  };
  goto gen__case__lab_5_interrupt;
 gen__case__lab_5_ext_interrupt:
  reasonp = 0l;
 gen__case__lab_5_interrupt:
  toppred = &predicate_klic__comp__generate_xgen__case__lab_5;
  goto interrupt_5;
 }

 gen__lab_5_top: {
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 gen__lab_5_clear_reason:
  reasonp = reasons;
 gen__lab_5_0:
 gen__lab_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_none)) goto gen__lab_5_interrupt;
  unify2(a4, a3, a2, a1);
  proceed();
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_lab_1)) goto gen__lab_5_interrupt;
  a0 = arg(a0, 0);
  execute(gen__new__lab_5_0);
  goto gen__new__lab_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,gen__lab_5_1);
  *reasonp++ =  a0;
  goto gen__lab_5_interrupt;
  };
  goto gen__lab_5_interrupt;
 gen__lab_5_ext_interrupt:
  reasonp = 0l;
 gen__lab_5_interrupt:
  toppred = &predicate_klic__comp__generate_xgen__lab_5;
  goto interrupt_5;
 }

 gen__new__lab_5_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 gen__new__lab_5_clear_reason:
  reasonp = reasons;
 gen__new__lab_5_0:
  unify(a0, a1);
  allocp[0] = makesym(functor_label_1);
  allocp[1] = a0;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = a4;
  allocp[3] = x0;
  x1 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a3, x1);
  bblt_add_no_check_y(a1,makeint(1L),x2);
  unify(a2, x2);
  proceed();
 gen__new__lab_5_ext_interrupt:
  reasonp = 0l;
 gen__new__lab_5_interrupt:
  toppred = &predicate_klic__comp__generate_xgen__new__lab_5;
  goto interrupt_5;
 }

 gen__type__known_3_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 gen__type__known_3_clear_reason:
  reasonp = reasons;
 gen__type__known_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xbasic__type_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a2;
  x1 = a1;
  a1 = a0;
  a2 = x0;
  a0 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  execute(assocx_3_0);
  goto assocx_3_ext_interrupt;
 gen__type__known_3_ext_interrupt:
  reasonp = 0l;
 gen__type__known_3_interrupt:
  toppred = &predicate_klic__comp__generate_xgen__type__known_3;
  goto interrupt_3;
 }

 basic__type_2_top: {
  q x0;
  a1 = qp->args[1];
  qp = qp->next;
 basic__type_2_clear_reason:
  reasonp = reasons;
 basic__type_2_0:
 basic__type_2_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_yes_2)) goto basic__type_2_3;
  x0 = arg(a0, 1);
 basic__type_2_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (isint(x0)) goto basic__type_2_3;
  switch (symval(x0)) {
 case symval(makesym(atom_atom)):
  a0 = arg(a0, 0);
  execute(atomic__type_2_0);
  goto atomic__type_2_ext_interrupt;
 case symval(makesym(atom_int)):
  a0 = arg(a0, 0);
  execute(atomic__type_2_0);
  goto atomic__type_2_ext_interrupt;
 case symval(makesym(atom_atomic)):
  a0 = arg(a0, 0);
  execute(atomic__type_2_0);
  goto atomic__type_2_ext_interrupt;
 case symval(makesym(atom_functor)):
  a0 = arg(a0, 0);
  execute(functor__type_2_0);
  goto functor__type_2_ext_interrupt;
 case symval(makesym(atom_list)):
  unify_value(a1, a0);
  proceed();
  };
  goto basic__type_2_3;
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_atom_1:
  a0 = arg(a0, 0);
  execute(atomic__type_2_0);
  goto atomic__type_2_ext_interrupt;
 case functor_functor_1:
  a0 = arg(a0, 0);
  execute(functor__type_2_0);
  goto functor__type_2_ext_interrupt;
 case functor_functor_2:
  a0 = arg(a0, 0);
  execute(functor__type_2_0);
  goto functor__type_2_ext_interrupt;
  };
  goto basic__type_2_3;
 case VARREF:
  deref_and_jump(x0,basic__type_2_2);
  *reasonp++ =  x0;
  goto basic__type_2_3;
  };
  goto basic__type_2_3;
 case VARREF:
  deref_and_jump(a0,basic__type_2_1);
  *reasonp++ =  a0;
  goto basic__type_2_3;
  };
  goto basic__type_2_3;
 basic__type_2_3:
  otherwise(basic__type_2_interrupt);
  unify_value(a1, makesym(atom_no));
  proceed();
 basic__type_2_ext_interrupt:
  reasonp = 0l;
 basic__type_2_interrupt:
  goto interrupt_2;
 }

 atomic__type_2_top: {
  q x0;
  a1 = qp->args[1];
  qp = qp->next;
 atomic__type_2_clear_reason:
  reasonp = reasons;
 atomic__type_2_0:
  allocp[0] = makesym(functor_yes_2);
  allocp[1] = a0;
  allocp[2] = makesym(atom_atomic);
  x0 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a1, x0);
  proceed();
 atomic__type_2_ext_interrupt:
  reasonp = 0l;
 atomic__type_2_interrupt:
  toppred = &predicate_klic__comp__generate_xatomic__type_2;
  goto interrupt_2;
 }

 functor__type_2_top: {
  q x0;
  a1 = qp->args[1];
  qp = qp->next;
 functor__type_2_clear_reason:
  reasonp = reasons;
 functor__type_2_0:
  allocp[0] = makesym(functor_yes_2);
  allocp[1] = a0;
  allocp[2] = makesym(atom_functor);
  x0 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a1, x0);
  proceed();
 functor__type_2_ext_interrupt:
  reasonp = 0l;
 functor__type_2_interrupt:
  toppred = &predicate_klic__comp__generate_xfunctor__type_2;
  goto interrupt_2;
 }

 gen__cond_12_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20, x21, x22, x23, x24, x25, x26, x27, x28, x29, x30, x31, x32;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 gen__cond_12_clear_reason:
  reasonp = reasons;
 gen__cond_12_0:
 gen__cond_12_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_gp_1:
  x0 = arg(a0, 0);
 gen__cond_12_2:
  if (isref(x0)) goto gen__cond_12_3;
  gblt_pfunctor(x0,x1,gen__cond_12_interrupt);
  gblt_arity(x0,x2,gen__cond_12_interrupt);
  unify(a7, a6);
  allocp[0] = makesym(functor_gblt__pred_4);
  allocp[1] = x1;
  allocp[2] = x2;
  allocp[3] = x4 = makeref(&allocp[3]);
  allocp[4] = a1;
  x3 = makefunctor(&allocp[0]);
  allocp[5] = a11;
  allocp[6] = x3;
  x5 = makecons(&allocp[5]);
  allocp[7] = (q)qp;
  allocp[8] = (q)(&predicate_klic__comp__generate_xstrip__types_2);
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = x4;
  allocp[11] = (q)(struct goalrec*)&allocp[7];
  allocp[12] = (q)(&predicate_klic__comp__generate_xprep__poss_10);
  allocp[13] = x7 = makeref(&allocp[13]);
  allocp[14] = x6;
  allocp[15] = a2;
  allocp[16] = a3;
  allocp[17] = a4;
  allocp[18] = a5;
  allocp[19] = a8;
  allocp[20] = a9;
  allocp[21] = a10;
  allocp[22] = x5;
  allocp[23] = x7;
  allocp[24] = x9 = makeref(&allocp[24]);
  x8 = makecons(&allocp[23]);
  allocp[25] = (q)(struct goalrec*)&allocp[11];
  allocp[26] = (q)(&predicate_klic__comp__util_xuniv_2);
  allocp[27] = x0;
  allocp[28] = x8;
  qp = (struct goalrec*)&allocp[25];
  allocp += 29;
  proceed();
 gen__cond_12_3:
  deref_and_jump(x0,gen__cond_12_2);
  *reasonp++ =  x0;
  goto gen__cond_12_interrupt;
 case functor_gb_2:
  x0 = arg(a0, 0);
 gen__cond_12_4:
  if (isref(x0)) goto gen__cond_12_5;
  gblt_pfunctor(x0,x1,gen__cond_12_interrupt);
  gblt_arity(x0,x2,gen__cond_12_interrupt);
  unify(a7, a6);
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a2;
  x3 = makefunctor(&allocp[0]);
  bblt_add_no_check_y(a2,makeint(1L),x4);
  allocp[2] = makesym(functor_gb_1);
  allocp[3] = x0;
  x5 = makefunctor(&allocp[2]);
  allocp[4] = makesym(functor__24_3);
  allocp[5] = x5;
  allocp[6] = x3;
  allocp[7] = arg(a0, 1);
  x6 = makefunctor(&allocp[4]);
  allocp[8] = x8 = makeref(&allocp[8]);
  allocp[9] = x6;
  x7 = makecons(&allocp[8]);
  allocp += 10;
  unify_value(a5, x7);
  allocp[0] = makesym(functor_gblt__pred_4);
  allocp[1] = x1;
  allocp[2] = x2;
  allocp[3] = x10 = makeref(&allocp[3]);
  allocp[4] = a1;
  x9 = makefunctor(&allocp[0]);
  allocp[5] = a11;
  allocp[6] = x9;
  x11 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_r_1);
  allocp[8] = x3;
  x12 = makefunctor(&allocp[7]);
  allocp[9] = NILATOM;
  allocp[10] = x12;
  x13 = makecons(&allocp[9]);
  allocp[11] = (q)qp;
  allocp[12] = (q)(&predicate_klic__comp__util_xappend_3);
  allocp[13] = x14 = makeref(&allocp[13]);
  allocp[14] = x13;
  allocp[15] = x10;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_klic__comp__generate_xstrip__types_2);
  allocp[18] = x15 = makeref(&allocp[18]);
  allocp[19] = x14;
  allocp[20] = (q)(struct goalrec*)&allocp[16];
  allocp[21] = (q)(&predicate_klic__comp__generate_xprep__poss_10);
  allocp[22] = x16 = makeref(&allocp[22]);
  allocp[23] = x15;
  allocp[24] = x4;
  allocp[25] = a3;
  allocp[26] = a4;
  allocp[27] = x8;
  allocp[28] = a8;
  allocp[29] = a9;
  allocp[30] = a10;
  allocp[31] = x11;
  allocp[32] = x16;
  allocp[33] = x18 = makeref(&allocp[33]);
  x17 = makecons(&allocp[32]);
  allocp[34] = (q)(struct goalrec*)&allocp[20];
  allocp[35] = (q)(&predicate_klic__comp__util_xuniv_2);
  allocp[36] = x0;
  allocp[37] = x17;
  qp = (struct goalrec*)&allocp[34];
  allocp += 38;
  proceed();
 gen__cond_12_5:
  deref_and_jump(x0,gen__cond_12_4);
  *reasonp++ =  x0;
  goto gen__cond_12_interrupt;
 case functor_gg_2:
  x0 = arg(a0, 0);
 gen__cond_12_6:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_gg_3)) goto gen__cond_12_interrupt;
  x1 = arg(x0, 0);
 gen__cond_12_7:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor__2F_2)) goto gen__cond_12_interrupt;
  unify(a7, a6);
  allocp[0] = makesym(functor__2F_2);
  allocp[1] = arg(x1, 0);
  allocp[2] = x3 = makeref(&allocp[2]);
  x2 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_funct_1);
  allocp[4] = x2;
  x4 = makefunctor(&allocp[3]);
  allocp[5] = x6 = makeref(&allocp[5]);
  allocp[6] = x4;
  x5 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a8, x5);
  x7 = arg(x1, 1);
  x8 = arg(a0, 1);
  bblt_add(x7,x8,x9);
  bblt_sub_no_check_y(x9,makeint(1L),x10);
  unify(x3, x10);
  allocp[0] = makesym(functor__2F_2);
  allocp[1] = arg(x1, 0);
  allocp[2] = x7;
  x11 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_gg_3);
  allocp[4] = x11;
  allocp[5] = arg(x0, 1);
  allocp[6] = arg(x0, 2);
  x12 = makefunctor(&allocp[3]);
  allocp[7] = (q)qp;
  allocp[8] = (q)(&predicate_klic__comp__generate_xload__guard__generic__out_11);
  allocp[9] = x13 = makeref(&allocp[9]);
  allocp[10] = x3;
  allocp[11] = x12;
  allocp[12] = x14 = makeref(&allocp[12]);
  allocp[13] = a3;
  allocp[14] = x15 = makeref(&allocp[14]);
  allocp[15] = a5;
  allocp[16] = x16 = makeref(&allocp[16]);
  allocp[17] = a9;
  allocp[18] = x17 = makeref(&allocp[18]);
  allocp[19] = a11;
  allocp[20] = makesym(functor_r_1);
  allocp[21] = x19 = makeref(&allocp[21]);
  x18 = makefunctor(&allocp[20]);
  allocp[22] = makesym(functor__2F_2);
  allocp[23] = arg(x1, 0);
  allocp[24] = x3;
  x20 = makefunctor(&allocp[22]);
  allocp[25] = makesym(functor_guard__generic_4);
  allocp[26] = x18;
  allocp[27] = x20;
  allocp[28] = x13;
  allocp[29] = a1;
  x21 = makefunctor(&allocp[25]);
  allocp[30] = x17;
  allocp[31] = x21;
  x22 = makecons(&allocp[30]);
  allocp[32] = (q)(struct goalrec*)&allocp[7];
  allocp[33] = (q)(&predicate_klic__comp__util_xlength_2);
  allocp[34] = x23 = makeref(&allocp[34]);
  allocp[35] = x13;
  allocp[36] = (q)(struct goalrec*)&allocp[32];
  allocp[37] = (q)(&predicate_klic__comp__generate_xload__pos_10);
  x24 = arg(x0, 1);
  allocp[38] = x24;
  allocp[39] = x19;
  allocp[40] = x25 = makeref(&allocp[40]);
  allocp[41] = x14;
  allocp[42] = x26 = makeref(&allocp[42]);
  allocp[43] = x15;
  allocp[44] = x27 = makeref(&allocp[44]);
  allocp[45] = x16;
  allocp[46] = x28 = makeref(&allocp[46]);
  allocp[47] = x22;
  allocp[48] = (q)(struct goalrec*)&allocp[36];
  allocp[49] = (q)(&predicate_klic__comp__generate_xset__generic__args_10);
  allocp[50] = x23;
  allocp[51] = makeint(0L);
  allocp[52] = x29 = makeref(&allocp[52]);
  allocp[53] = x25;
  allocp[54] = x30 = makeref(&allocp[54]);
  allocp[55] = x26;
  allocp[56] = x31 = makeref(&allocp[56]);
  allocp[57] = x27;
  allocp[58] = x32 = makeref(&allocp[58]);
  allocp[59] = x28;
  a0 = arg(x0, 2);
  a1 = x23;
  a3 = x29;
  a5 = x30;
  a6 = x6;
  a7 = x31;
  a8 = a10;
  a9 = x32;
  qp = (struct goalrec*)&allocp[48];
  allocp += 60;
  execute(prep__poss_10_0);
  goto prep__poss_10_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,gen__cond_12_7);
  *reasonp++ =  x1;
  goto gen__cond_12_interrupt;
  };
  goto gen__cond_12_interrupt;
 case VARREF:
  deref_and_jump(x0,gen__cond_12_6);
  *reasonp++ =  x0;
  goto gen__cond_12_interrupt;
  };
  goto gen__cond_12_interrupt;
 case functor_eq_2:
  bblt_add_no_check_y(a6,makeint(1L),x0);
  unify(a7, x0);
  allocp[0] = makesym(functor_if__not__eq_3);
  allocp[1] = x2 = makeref(&allocp[1]);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = a1;
  x1 = makefunctor(&allocp[0]);
  allocp[4] = a11;
  allocp[5] = x1;
  x4 = makecons(&allocp[4]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_klic__comp__generate_xload__pos_10);
  x5 = arg(a0, 1);
  allocp[8] = x5;
  allocp[9] = x3;
  allocp[10] = x6 = makeref(&allocp[10]);
  allocp[11] = a3;
  allocp[12] = x7 = makeref(&allocp[12]);
  allocp[13] = a5;
  allocp[14] = x8 = makeref(&allocp[14]);
  allocp[15] = a9;
  allocp[16] = x9 = makeref(&allocp[16]);
  allocp[17] = x4;
  a0 = arg(a0, 0);
  a1 = x2;
  a3 = x6;
  a5 = x7;
  a6 = a8;
  a7 = x8;
  a8 = a10;
  a9 = x9;
  qp = (struct goalrec*)&allocp[6];
  allocp += 18;
  execute(load__pos_10_0);
  goto load__pos_10_ext_interrupt;
 case functor_il_3:
  bblt_add_no_check_y(a6,makeint(1L),x0);
  unify(a7, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xadd__inline__info_3);
  x1 = arg(a0, 2);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a5;
  allocp[5] = makesym(functor_inline_3);
  allocp[6] = arg(a0, 0);
  allocp[7] = x4 = makeref(&allocp[7]);
  allocp[8] = a1;
  x3 = makefunctor(&allocp[5]);
  allocp[9] = a11;
  allocp[10] = x3;
  x5 = makecons(&allocp[9]);
  a0 = arg(a0, 1);
  a1 = x1;
  x6 = a2;
  x7 = a3;
  a5 = a4;
  a6 = x2;
  a7 = a8;
  a8 = a9;
  a9 = a10;
  a10 = x5;
  a4 = x7;
  a3 = x6;
  a2 = x4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 11;
  execute(load__inline__args_11_0);
  goto load__inline__args_11_ext_interrupt;
  };
  goto gen__cond_12_interrupt;
 case VARREF:
  deref_and_jump(a0,gen__cond_12_1);
  *reasonp++ =  a0;
  goto gen__cond_12_interrupt;
  };
  goto gen__cond_12_interrupt;
 gen__cond_12_ext_interrupt:
  reasonp = 0l;
 gen__cond_12_interrupt:
  goto interrupt_12;
 }

 add__inline__info_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 add__inline__info_3_clear_reason:
  reasonp = reasons;
 add__inline__info_3_0:
 add__inline__info_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 add__inline__info_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__3A_2)) goto add__inline__info_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xadd__inline__info_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = makesym(functor_var_1);
  allocp[6] = arg(x0, 0);
  x3 = makefunctor(&allocp[5]);
  allocp[7] = makesym(functor__24_3);
  allocp[8] = x3;
  allocp[9] = x5 = makeref(&allocp[9]);
  allocp[10] = arg(x0, 1);
  x4 = makefunctor(&allocp[7]);
  allocp[11] = a1;
  allocp[12] = x4;
  x6 = makecons(&allocp[11]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 13;
  unify_value(x2, x6);
  allocp[0] = makesym(functor_var_1);
  allocp[1] = arg(x0, 0);
  x7 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_yes_2);
  allocp[3] = x5;
  allocp[4] = x9 = makeref(&allocp[4]);
  x8 = makefunctor(&allocp[2]);
  a0 = a1;
  a1 = x7;
  a2 = x8;
  allocp += 5;
  execute(assocx_3_0);
  goto assocx_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,add__inline__info_3_2);
  *reasonp++ =  x0;
  goto add__inline__info_3_interrupt;
  };
  goto add__inline__info_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto add__inline__info_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,add__inline__info_3_1);
  *reasonp++ =  a0;
  goto add__inline__info_3_interrupt;
  };
  goto add__inline__info_3_interrupt;
 add__inline__info_3_ext_interrupt:
  reasonp = 0l;
 add__inline__info_3_interrupt:
  goto interrupt_3;
 }

 load__guard__generic__out_11_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 load__guard__generic__out_11_clear_reason:
  reasonp = reasons;
 load__guard__generic__out_11_0:
 load__guard__generic__out_11_1:
  if (!isint(a0)) goto load__guard__generic__out_11_5;
 load__guard__generic__out_11_2:
  if (!isint(a1)) goto load__guard__generic__out_11_4;
  gblt_eq(a0,a1,load__guard__generic__out_11_3);
  unify4(a10, a9, a8, a7, a6, a5, a4, a3);
  proceed();
 load__guard__generic__out_11_3:
  gblt_less(a0,a1,load__guard__generic__out_11_interrupt);
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a3;
  x0 = makefunctor(&allocp[0]);
  bblt_add_no_check_y(a3,makeint(1L),x1);
  bblt_add_no_check(a0,makeint(1L),x2);
  allocp[2] = makesym(functor_gg_2);
  allocp[3] = a2;
  allocp[4] = a0;
  x3 = makefunctor(&allocp[2]);
  allocp[5] = makesym(functor__24_3);
  allocp[6] = x3;
  allocp[7] = x0;
  allocp[8] = makesym(atom_any);
  x4 = makefunctor(&allocp[5]);
  allocp[9] = a5;
  allocp[10] = x4;
  x5 = makecons(&allocp[9]);
  allocp[11] = makesym(functor_load__generic__arg_2);
  allocp[12] = x0;
  allocp[13] = a0;
  x6 = makefunctor(&allocp[11]);
  allocp[14] = x8 = makeref(&allocp[14]);
  allocp[15] = x6;
  x7 = makecons(&allocp[14]);
  allocp += 16;
  unify_value(a9, x7);
  a0 = x2;
  a3 = x1;
  a5 = x5;
  a9 = x8;
  execute(load__guard__generic__out_11_0);
  goto load__guard__generic__out_11_ext_interrupt;
 load__guard__generic__out_11_4:
  if (!isref(a1)) goto load__guard__generic__out_11_interrupt;
  deref_and_jump(a1,load__guard__generic__out_11_2);
  *reasonp++ =  a1;
  goto load__guard__generic__out_11_interrupt;
 load__guard__generic__out_11_5:
  if (!isref(a0)) goto load__guard__generic__out_11_interrupt;
  deref_and_jump(a0,load__guard__generic__out_11_1);
  *reasonp++ =  a0;
  goto load__guard__generic__out_11_interrupt;
 load__guard__generic__out_11_ext_interrupt:
  reasonp = 0l;
 load__guard__generic__out_11_interrupt:
  goto interrupt_11;
 }

 prep__poss__for__set__tmake_10_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 prep__poss__for__set__tmake_10_clear_reason:
  reasonp = reasons;
 prep__poss__for__set__tmake_10_0:
 prep__poss__for__set__tmake_10_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = x2 = makeref(&allocp[1]);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xprep__poss__for__set__tmake_10);
  x3 = cdr_of(a0);
  allocp[2] = x3;
  allocp[3] = x1;
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x5 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x6 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x7 = makeref(&allocp[10]);
  allocp[11] = a9;
  a0 = car_of(a0);
  a1 = x2;
  a3 = x4;
  a5 = x5;
  a7 = x6;
  a9 = x7;
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  execute(prep__pos__for__set__tmake_10_0);
  goto prep__pos__for__set__tmake_10_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto prep__poss__for__set__tmake_10_interrupt;
  unify4(a9, a8, a7, a6, a5, a4, a3, a2);
  unify_value(a1, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a0,prep__poss__for__set__tmake_10_1);
  *reasonp++ =  a0;
  goto prep__poss__for__set__tmake_10_interrupt;
  };
  goto prep__poss__for__set__tmake_10_interrupt;
 prep__poss__for__set__tmake_10_ext_interrupt:
  reasonp = 0l;
 prep__poss__for__set__tmake_10_interrupt:
  goto interrupt_10;
 }

 prep__poss_10_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 prep__poss_10_clear_reason:
  reasonp = reasons;
 prep__poss_10_0:
 prep__poss_10_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = x2 = makeref(&allocp[1]);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xprep__poss_10);
  x3 = cdr_of(a0);
  allocp[2] = x3;
  allocp[3] = x1;
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x5 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x6 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x7 = makeref(&allocp[10]);
  allocp[11] = a9;
  a0 = car_of(a0);
  a1 = x2;
  a3 = x4;
  a5 = x5;
  a7 = x6;
  a9 = x7;
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  execute(prep__pos_10_0);
  goto prep__pos_10_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto prep__poss_10_interrupt;
  unify4(a9, a8, a7, a6, a5, a4, a3, a2);
  unify_value(a1, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a0,prep__poss_10_1);
  *reasonp++ =  a0;
  goto prep__poss_10_interrupt;
  };
  goto prep__poss_10_interrupt;
 prep__poss_10_ext_interrupt:
  reasonp = 0l;
 prep__poss_10_interrupt:
  toppred = &predicate_klic__comp__generate_xprep__poss_10;
  goto interrupt_10;
 }

 prep__vec__elems_10_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 prep__vec__elems_10_clear_reason:
  reasonp = reasons;
 prep__vec__elems_10_0:
 prep__vec__elems_10_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = x2 = makeref(&allocp[1]);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xprep__vec__elems_10);
  x3 = cdr_of(a0);
  allocp[2] = x3;
  allocp[3] = x1;
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x5 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x6 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x7 = makeref(&allocp[10]);
  allocp[11] = a9;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_klic__comp__generate_xalloc__if__var_8);
  allocp[14] = x8 = makeref(&allocp[14]);
  allocp[15] = x2;
  allocp[16] = x9 = makeref(&allocp[16]);
  allocp[17] = x4;
  allocp[18] = x10 = makeref(&allocp[18]);
  allocp[19] = x5;
  allocp[20] = x11 = makeref(&allocp[20]);
  allocp[21] = x7;
  a0 = car_of(a0);
  a1 = x8;
  a3 = x9;
  a5 = x10;
  a7 = x6;
  a9 = x11;
  qp = (struct goalrec*)&allocp[12];
  allocp += 22;
  execute(prep__pos_10_0);
  goto prep__pos_10_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto prep__vec__elems_10_interrupt;
  unify4(a9, a8, a7, a6, a5, a4, a3, a2);
  unify_value(a1, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a0,prep__vec__elems_10_1);
  *reasonp++ =  a0;
  goto prep__vec__elems_10_interrupt;
  };
  goto prep__vec__elems_10_interrupt;
 prep__vec__elems_10_ext_interrupt:
  reasonp = 0l;
 prep__vec__elems_10_interrupt:
  toppred = &predicate_klic__comp__generate_xprep__vec__elems_10;
  goto interrupt_10;
 }

 alloc__if__var_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 alloc__if__var_8_clear_reason:
  reasonp = reasons;
 alloc__if__var_8_0:
 alloc__if__var_8_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_var_1:
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a2;
  x0 = makefunctor(&allocp[0]);
  bblt_add_no_check_y(a2,makeint(1L),x1);
  allocp += 2;
  unify(a3, x1);
  allocp[0] = makesym(functor_r_1);
  allocp[1] = x0;
  x2 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__3A_2);
  allocp[3] = x2;
  allocp[4] = makesym(atom_any);
  x3 = makefunctor(&allocp[2]);
  allocp += 5;
  unify_value(a1, x3);
  allocp[0] = makesym(functor__24_3);
  allocp[1] = a0;
  allocp[2] = x0;
  allocp[3] = makesym(atom_any);
  x4 = makefunctor(&allocp[0]);
  allocp[4] = a4;
  allocp[5] = x4;
  x5 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a5, x5);
  allocp[0] = makesym(functor_alloc__var_2);
  allocp[1] = x0;
  allocp[2] = makeint(0L);
  x6 = makefunctor(&allocp[0]);
  allocp[3] = x8 = makeref(&allocp[3]);
  allocp[4] = x6;
  x7 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a6, x7);
  allocp[0] = a7;
  allocp[1] = makefunctor(funct_const_5);
  x9 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(x8, x9);
  proceed();
 case functor_var_2:
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a2;
  x0 = makefunctor(&allocp[0]);
  bblt_add_no_check_y(a2,makeint(1L),x1);
  allocp += 2;
  unify(a3, x1);
  allocp[0] = makesym(functor_r_1);
  allocp[1] = x0;
  x2 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__3A_2);
  allocp[3] = x2;
  allocp[4] = makesym(atom_any);
  x3 = makefunctor(&allocp[2]);
  allocp += 5;
  unify_value(a1, x3);
  allocp[0] = makesym(functor_var_1);
  allocp[1] = arg(a0, 0);
  x4 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__24_3);
  allocp[3] = x4;
  allocp[4] = x0;
  allocp[5] = makesym(atom_any);
  x5 = makefunctor(&allocp[2]);
  allocp[6] = a4;
  allocp[7] = x5;
  x6 = makecons(&allocp[6]);
  allocp += 8;
  unify_value(a5, x6);
  allocp[0] = makesym(functor_alloc__var_2);
  allocp[1] = x0;
  allocp[2] = makeint(0L);
  x7 = makefunctor(&allocp[0]);
  allocp[3] = x9 = makeref(&allocp[3]);
  allocp[4] = x7;
  x8 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a6, x8);
  allocp[0] = a7;
  allocp[1] = makefunctor(funct_const_5);
  x10 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(x9, x10);
  proceed();
  };
  goto alloc__if__var_8_2;
 case VARREF:
  deref_and_jump(a0,alloc__if__var_8_1);
  *reasonp++ =  a0;
  goto alloc__if__var_8_2;
  };
  goto alloc__if__var_8_2;
 alloc__if__var_8_2:
  otherwise(alloc__if__var_8_interrupt);
  unify4(a7, a6, a5, a4, a3, a2, a1, a0);
  proceed();
 alloc__if__var_8_ext_interrupt:
  reasonp = 0l;
 alloc__if__var_8_interrupt:
  goto interrupt_8;
 }

 prep__pos__for__set__tmake_10_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 prep__pos__for__set__tmake_10_clear_reason:
  reasonp = reasons;
 prep__pos__for__set__tmake_10_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xprep__pos__1_10);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  x1 = a4;
  a1 = a0;
  a2 = x0;
  a0 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  execute(assocx__for__set__tmake_3_0);
  goto assocx__for__set__tmake_3_ext_interrupt;
 prep__pos__for__set__tmake_10_ext_interrupt:
  reasonp = 0l;
 prep__pos__for__set__tmake_10_interrupt:
  toppred = &predicate_klic__comp__generate_xprep__pos__for__set__tmake_10;
  goto interrupt_10;
 }

 prep__pos_10_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 prep__pos_10_clear_reason:
  reasonp = reasons;
 prep__pos_10_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xprep__pos__1_10);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  x1 = a4;
  a1 = a0;
  a2 = x0;
  a0 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  execute(assocx_3_0);
  goto assocx_3_ext_interrupt;
 prep__pos_10_ext_interrupt:
  reasonp = 0l;
 prep__pos_10_interrupt:
  toppred = &predicate_klic__comp__generate_xprep__pos_10;
  goto interrupt_10;
 }

 prep__pos__1_10_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20, x21, x22, x23, x24;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 prep__pos__1_10_clear_reason:
  reasonp = reasons;
 prep__pos__1_10_0:
 prep__pos__1_10_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_yes_2:
  unify4(a9, a8, a7, a6, a5, a4, a3, a2);
  allocp[0] = makesym(functor_r_1);
  allocp[1] = arg(a0, 0);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__3A_2);
  allocp[3] = x0;
  allocp[4] = arg(a0, 1);
  x1 = makefunctor(&allocp[2]);
  allocp += 5;
  unify_value(a1, x1);
  proceed();
 case functor_no_1:
  x0 = arg(a0, 0);
 prep__pos__1_10_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_cons_2:
  allocp[0] = makesym(functor_r_1);
  allocp[1] = x2 = makeref(&allocp[1]);
  x1 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__3A_2);
  allocp[3] = x1;
  allocp[4] = makesym(atom_cons);
  x3 = makefunctor(&allocp[2]);
  allocp += 5;
  unify_value(a1, x3);
  allocp[0] = makesym(functor_make__space_1);
  allocp[1] = x5 = makeref(&allocp[1]);
  x4 = makefunctor(&allocp[0]);
  allocp[2] = a9;
  allocp[3] = x4;
  x6 = makecons(&allocp[2]);
  allocp[4] = makesym(functor_make__cons_1);
  allocp[5] = x2;
  x7 = makefunctor(&allocp[4]);
  allocp[6] = x6;
  allocp[7] = x7;
  x8 = makecons(&allocp[6]);
  allocp[8] = NILATOM;
  allocp[9] = x10 = makeref(&allocp[9]);
  x9 = makecons(&allocp[8]);
  allocp[10] = x9;
  allocp[11] = x12 = makeref(&allocp[11]);
  x11 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_klic__comp__generate_xalloc__args__for__struct_13);
  allocp[14] = x11;
  allocp[15] = makeint(0L);
  allocp[16] = makeint(2L);
  allocp[17] = makeint(0L);
  allocp[18] = x5;
  allocp[19] = x13 = makeref(&allocp[19]);
  allocp[20] = a3;
  allocp[21] = x14 = makeref(&allocp[21]);
  allocp[22] = a5;
  allocp[23] = x15 = makeref(&allocp[23]);
  allocp[24] = a7;
  allocp[25] = x16 = makeref(&allocp[25]);
  allocp[26] = x8;
  allocp[27] = (q)(struct goalrec*)&allocp[12];
  allocp[28] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[29] = x17 = makeref(&allocp[29]);
  allocp[30] = makeint(1L);
  allocp[31] = x13;
  allocp[32] = makesym(functor_x_1);
  allocp[33] = x17;
  x18 = makefunctor(&allocp[32]);
  qp = (struct goalrec*)&allocp[27];
  allocp += 34;
  unify_value(x2, x18);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xprep__pos_10);
  x19 = arg(x0, 1);
  allocp[2] = x19;
  allocp[3] = x12;
  allocp[4] = x20 = makeref(&allocp[4]);
  allocp[5] = x17;
  allocp[6] = x21 = makeref(&allocp[6]);
  allocp[7] = x14;
  allocp[8] = x22 = makeref(&allocp[8]);
  allocp[9] = x15;
  allocp[10] = x23 = makeref(&allocp[10]);
  allocp[11] = x16;
  a0 = arg(x0, 0);
  a1 = x10;
  a3 = x20;
  a5 = x21;
  a7 = x22;
  a9 = x23;
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  execute(prep__pos_10_0);
  goto prep__pos_10_ext_interrupt;
 case functor_mkfunct_2:
  x1 = arg(x0, 0);
 prep__pos__1_10_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor__2F_2)) goto prep__pos__1_10_4;
  allocp[0] = makesym(functor__2F_2);
  allocp[1] = arg(x1, 0);
  allocp[2] = arg(x1, 1);
  x2 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_funct_1);
  allocp[4] = x2;
  x3 = makefunctor(&allocp[3]);
  allocp[5] = x5 = makeref(&allocp[5]);
  allocp[6] = x3;
  x4 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a6, x4);
  x6 = arg(x1, 1);
  bblt_add_no_check_y(x6,makeint(1L),x7);
  allocp[0] = makesym(functor_r_1);
  allocp[1] = x9 = makeref(&allocp[1]);
  x8 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__3A_2);
  allocp[3] = x8;
  allocp[4] = makesym(atom_functor);
  x10 = makefunctor(&allocp[2]);
  allocp += 5;
  unify_value(a1, x10);
  allocp[0] = makesym(functor_make__space_1);
  allocp[1] = x12 = makeref(&allocp[1]);
  x11 = makefunctor(&allocp[0]);
  allocp[2] = a9;
  allocp[3] = x11;
  x13 = makecons(&allocp[2]);
  allocp[4] = makesym(functor_make__functor_2);
  allocp[5] = x9;
  allocp[6] = x7;
  x14 = makefunctor(&allocp[4]);
  allocp[7] = x13;
  allocp[8] = x14;
  x15 = makecons(&allocp[7]);
  allocp[9] = (q)qp;
  allocp[10] = (q)(&predicate_klic__comp__generate_xalloc__args__for__struct_13);
  allocp[11] = x16 = makeref(&allocp[11]);
  allocp[12] = makeint(1L);
  allocp[13] = x7;
  allocp[14] = makeint(0L);
  allocp[15] = x12;
  allocp[16] = x17 = makeref(&allocp[16]);
  allocp[17] = a3;
  allocp[18] = x18 = makeref(&allocp[18]);
  allocp[19] = a5;
  allocp[20] = x19 = makeref(&allocp[20]);
  allocp[21] = a7;
  allocp[22] = x20 = makeref(&allocp[22]);
  allocp[23] = x15;
  allocp[24] = (q)(struct goalrec*)&allocp[9];
  allocp[25] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[26] = x21 = makeref(&allocp[26]);
  allocp[27] = makeint(1L);
  allocp[28] = x17;
  allocp[29] = makesym(functor_x_1);
  allocp[30] = x21;
  x22 = makefunctor(&allocp[29]);
  qp = (struct goalrec*)&allocp[24];
  allocp += 31;
  unify_value(x9, x22);
  allocp[0] = makesym(functor_alloc__functor__id_2);
  allocp[1] = arg(x1, 0);
  allocp[2] = x6;
  x23 = makefunctor(&allocp[0]);
  allocp[3] = x20;
  allocp[4] = x23;
  x24 = makecons(&allocp[3]);
  a0 = arg(x0, 1);
  a1 = x16;
  a3 = x21;
  a5 = x18;
  a6 = x5;
  a7 = x19;
  a9 = x24;
  allocp += 5;
  execute(prep__poss_10_0);
  goto prep__poss_10_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,prep__pos__1_10_3);
  *reasonp++ =  x1;
  goto prep__pos__1_10_4;
  };
  goto prep__pos__1_10_4;
 case functor_mkvect_2:
  allocp[0] = makesym(functor_r_1);
  allocp[1] = x2 = makeref(&allocp[1]);
  x1 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__3A_2);
  allocp[3] = x1;
  allocp[4] = makesym(atom_vector);
  x3 = makefunctor(&allocp[2]);
  allocp += 5;
  unify_value(a1, x3);
  allocp[0] = makesym(functor_make__vector_2);
  allocp[1] = x2;
  allocp[2] = arg(x0, 0);
  x4 = makefunctor(&allocp[0]);
  allocp[3] = a9;
  allocp[4] = x4;
  x5 = makecons(&allocp[3]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_klic__comp__generate_xalloc__args__for__struct_13);
  allocp[7] = x6 = makeref(&allocp[7]);
  allocp[8] = makeint(0L);
  x7 = arg(x0, 0);
  allocp[9] = x7;
  allocp[10] = makeint(0L);
  allocp[11] = x8 = makeref(&allocp[11]);
  allocp[12] = x9 = makeref(&allocp[12]);
  allocp[13] = a3;
  allocp[14] = x10 = makeref(&allocp[14]);
  allocp[15] = a5;
  allocp[16] = x11 = makeref(&allocp[16]);
  allocp[17] = a7;
  allocp[18] = x12 = makeref(&allocp[18]);
  allocp[19] = x5;
  allocp[20] = (q)(struct goalrec*)&allocp[5];
  allocp[21] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[22] = x13 = makeref(&allocp[22]);
  allocp[23] = makeint(1L);
  allocp[24] = x9;
  allocp[25] = makesym(functor_x_1);
  allocp[26] = x13;
  x14 = makefunctor(&allocp[25]);
  qp = (struct goalrec*)&allocp[20];
  allocp += 27;
  unify_value(x2, x14);
  a0 = arg(x0, 1);
  a1 = x6;
  a3 = x13;
  a5 = x10;
  a7 = x11;
  a9 = x12;
  execute(prep__vec__elems_10_0);
  goto prep__vec__elems_10_ext_interrupt;
 case functor_atom_1:
  unify3(a9, a8, a5, a4, a3, a2);
  allocp[0] = a7;
  allocp[1] = x0;
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a6, x1);
  unify_value(a1, x0);
  proceed();
 case functor_predicate_3:
  unify3(a9, a8, a5, a4, a3, a2);
  allocp[0] = makesym(functor_ext_3);
  allocp[1] = arg(x0, 0);
  allocp[2] = arg(x0, 1);
  allocp[3] = arg(x0, 2);
  x1 = makefunctor(&allocp[0]);
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = x1;
  x2 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a6, x2);
  allocp[0] = makesym(functor_const_2);
  allocp[1] = x5 = makeref(&allocp[1]);
  allocp[2] = x0;
  x4 = makefunctor(&allocp[0]);
  allocp[3] = a7;
  allocp[4] = x4;
  x6 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(x3, x6);
  allocp[0] = makesym(functor_const_1);
  allocp[1] = x5;
  x7 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x7);
  proceed();
 case functor_float_1:
  unify3(a9, a8, a5, a4, a3, a2);
  allocp[0] = makesym(functor_const_2);
  allocp[1] = x2 = makeref(&allocp[1]);
  allocp[2] = x0;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a7;
  allocp[4] = x1;
  x3 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a6, x3);
  allocp[0] = makesym(functor_const_1);
  allocp[1] = x2;
  x4 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x4);
  proceed();
 case functor_list_1:
  unify3(a9, a8, a5, a4, a3, a2);
  allocp[0] = makesym(functor_const_2);
  allocp[1] = x2 = makeref(&allocp[1]);
  allocp[2] = x0;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a7;
  allocp[4] = x1;
  x3 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a6, x3);
  allocp[0] = makesym(functor_const_1);
  allocp[1] = x2;
  x4 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x4);
  proceed();
 case functor_functor_1:
  unify3(a9, a8, a5, a4, a3, a2);
  allocp[0] = makesym(functor_const_2);
  allocp[1] = x2 = makeref(&allocp[1]);
  allocp[2] = x0;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a7;
  allocp[4] = x1;
  x3 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a6, x3);
  allocp[0] = makesym(functor_const_1);
  allocp[1] = x2;
  x4 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x4);
  proceed();
 case functor_string_1:
  unify3(a9, a8, a5, a4, a3, a2);
  allocp[0] = makesym(functor_const_2);
  allocp[1] = x2 = makeref(&allocp[1]);
  allocp[2] = x0;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a7;
  allocp[4] = x1;
  x3 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a6, x3);
  allocp[0] = makesym(functor_const_1);
  allocp[1] = x2;
  x4 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x4);
  proceed();
 case functor_vector_1:
  unify3(a9, a8, a5, a4, a3, a2);
  allocp[0] = makesym(functor_const_2);
  allocp[1] = x2 = makeref(&allocp[1]);
  allocp[2] = x0;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a7;
  allocp[4] = x1;
  x3 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a6, x3);
  allocp[0] = makesym(functor_const_1);
  allocp[1] = x2;
  x4 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x4);
  proceed();
  };
  goto prep__pos__1_10_4;
 case VARREF:
  deref_and_jump(x0,prep__pos__1_10_2);
  *reasonp++ =  x0;
  goto prep__pos__1_10_4;
  };
  goto prep__pos__1_10_4;
  };
  goto prep__pos__1_10_4;
 case VARREF:
  deref_and_jump(a0,prep__pos__1_10_1);
  *reasonp++ =  a0;
  goto prep__pos__1_10_4;
  };
  goto prep__pos__1_10_4;
 prep__pos__1_10_4:
  otherwise(prep__pos__1_10_interrupt);
 prep__pos__1_10_5:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_no_1)) goto prep__pos__1_10_interrupt;
  unify4(a9, a8, a7, a6, a5, a4, a3, a2);
  x0 = arg(a0, 0);
  unify(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,prep__pos__1_10_5);
  *reasonp++ =  a0;
  goto prep__pos__1_10_interrupt;
  };
  goto prep__pos__1_10_interrupt;
 prep__pos__1_10_ext_interrupt:
  reasonp = 0l;
 prep__pos__1_10_interrupt:
  goto interrupt_10;
 }

 alloc__args__for__struct_13_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  qp = qp->next;
 alloc__args__for__struct_13_clear_reason:
  reasonp = reasons;
 alloc__args__for__struct_13_0:
 alloc__args__for__struct_13_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xalloc__args__for__struct_13);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = x4 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = x5 = makeref(&allocp[11]);
  allocp[12] = a10;
  allocp[13] = x6 = makeref(&allocp[13]);
  allocp[14] = a12;
  allocp[15] = (q)(struct goalrec*)&allocp[0];
  allocp[16] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[17] = a1;
  allocp[18] = makeint(1L);
  allocp[19] = x1;
  a0 = car_of(a0);
  a4 = x2;
  a6 = x3;
  a8 = x4;
  a10 = x5;
  a12 = x6;
  qp = (struct goalrec*)&allocp[15];
  allocp += 20;
  execute(alloc__one__for__struct_13_0);
  goto alloc__one__for__struct_13_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto alloc__args__for__struct_13_interrupt;
  unify4(a12, a11, a10, a9, a8, a7, a6, a5);
  unify(a4, a3);
  proceed();
 case VARREF:
  deref_and_jump(a0,alloc__args__for__struct_13_1);
  *reasonp++ =  a0;
  goto alloc__args__for__struct_13_interrupt;
  };
  goto alloc__args__for__struct_13_interrupt;
 alloc__args__for__struct_13_ext_interrupt:
  reasonp = 0l;
 alloc__args__for__struct_13_interrupt:
  goto interrupt_13;
 }

 alloc__one__for__struct_13_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  qp = qp->next;
 alloc__one__for__struct_13_clear_reason:
  reasonp = reasons;
 alloc__one__for__struct_13_0:
 alloc__one__for__struct_13_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor__3A_2)) goto alloc__one__for__struct_13_3;
  x0 = arg(a0, 0);
 alloc__one__for__struct_13_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_r_1)) goto alloc__one__for__struct_13_3;
  unify4(a10, a9, a8, a7, a6, a5, a4, a3);
  allocp[0] = makesym(functor_alloc__value_2);
  allocp[1] = arg(x0, 0);
  allocp[2] = a1;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a12;
  allocp[4] = x1;
  x2 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a11, x2);
  proceed();
 case VARREF:
  deref_and_jump(x0,alloc__one__for__struct_13_2);
  *reasonp++ =  x0;
  goto alloc__one__for__struct_13_3;
  };
  goto alloc__one__for__struct_13_3;
 case VARREF:
  deref_and_jump(a0,alloc__one__for__struct_13_1);
  *reasonp++ =  a0;
  goto alloc__one__for__struct_13_3;
  };
  goto alloc__one__for__struct_13_3;
 alloc__one__for__struct_13_3:
  otherwise(alloc__one__for__struct_13_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xalloc__one__for__struct__1_13);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  allocp[12] = a10;
  allocp[13] = a11;
  allocp[14] = a12;
  x1 = a7;
  a1 = a0;
  a2 = x0;
  a0 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 15;
  execute(assocx_3_0);
  goto assocx_3_ext_interrupt;
 alloc__one__for__struct_13_ext_interrupt:
  reasonp = 0l;
 alloc__one__for__struct_13_interrupt:
  toppred = &predicate_klic__comp__generate_xalloc__one__for__struct_13;
  goto interrupt_13;
 }

 alloc__one__for__struct__1_13_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  qp = qp->next;
 alloc__one__for__struct__1_13_clear_reason:
  reasonp = reasons;
 alloc__one__for__struct__1_13_0:
 alloc__one__for__struct__1_13_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_yes_2:
  allocp[0] = makesym(functor_r_1);
  allocp[1] = arg(a0, 0);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__3A_2);
  allocp[3] = x0;
  allocp[4] = arg(a0, 1);
  x1 = makefunctor(&allocp[2]);
  a0 = x1;
  allocp += 5;
  execute(alloc__one__for__struct_13_0);
  goto alloc__one__for__struct_13_ext_interrupt;
 case functor_no_1:
  x0 = arg(a0, 0);
 alloc__one__for__struct__1_13_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_var_1:
  unify2(a10, a9, a4, a3);
  allocp[0] = makesym(functor__24_3);
  allocp[1] = x0;
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = makesym(atom_any);
  x1 = makefunctor(&allocp[0]);
  allocp[4] = a7;
  allocp[5] = x1;
  x3 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a8, x3);
  allocp[0] = makesym(functor_alloc__var_2);
  allocp[1] = x2;
  allocp[2] = a1;
  x4 = makefunctor(&allocp[0]);
  allocp[3] = a12;
  allocp[4] = x4;
  x5 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a11, x5);
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a5;
  x6 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(x2, x6);
  bblt_add_no_check_y(a5,makeint(1L),x7);
  unify(a6, x7);
  proceed();
 case functor_var_2:
  unify2(a10, a9, a4, a3);
  allocp[0] = makesym(functor_var_1);
  allocp[1] = arg(x0, 0);
  x1 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__24_3);
  allocp[3] = x1;
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = makesym(atom_any);
  x2 = makefunctor(&allocp[2]);
  allocp[6] = a7;
  allocp[7] = x2;
  x4 = makecons(&allocp[6]);
  allocp += 8;
  unify_value(a8, x4);
  allocp[0] = makesym(functor_alloc__var_2);
  allocp[1] = x3;
  allocp[2] = a1;
  x5 = makefunctor(&allocp[0]);
  allocp[3] = a12;
  allocp[4] = x5;
  x6 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a11, x6);
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a5;
  x7 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(x3, x7);
  bblt_add_no_check_y(a5,makeint(1L),x8);
  unify(a6, x8);
  proceed();
 case functor_atom_1:
  unify4(a10, a9, a8, a7, a6, a5, a4, a3);
  allocp[0] = makesym(functor_alloc__const_2);
  allocp[1] = x0;
  allocp[2] = a1;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a12;
  allocp[4] = x1;
  x2 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a11, x2);
  proceed();
 case functor_int_1:
  unify4(a10, a9, a8, a7, a6, a5, a4, a3);
  allocp[0] = makesym(functor_alloc__const_2);
  allocp[1] = x0;
  allocp[2] = a1;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a12;
  allocp[4] = x1;
  x2 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a11, x2);
  proceed();
 case functor_const_1:
  unify4(a10, a9, a8, a7, a6, a5, a4, a3);
  allocp[0] = makesym(functor_alloc__const_2);
  allocp[1] = x0;
  allocp[2] = a1;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a12;
  allocp[4] = x1;
  x2 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a11, x2);
  proceed();
 case functor_arg_2:
  unify(a4, a3);
  allocp[0] = makesym(functor_alloc__elem_3);
  allocp[1] = x2 = makeref(&allocp[1]);
  allocp[2] = arg(x0, 1);
  allocp[3] = a1;
  x1 = makefunctor(&allocp[0]);
  allocp[4] = a12;
  allocp[5] = x1;
  x3 = makecons(&allocp[4]);
  a0 = arg(x0, 0);
  a1 = x2;
  a2 = a5;
  a3 = a6;
  a4 = a7;
  a5 = a8;
  a6 = a9;
  a7 = a10;
  a8 = a11;
  a9 = x3;
  allocp += 6;
  execute(load__pos_10_0);
  goto load__pos_10_ext_interrupt;
 case functor_arg_3:
  unify(a4, a3);
  allocp[0] = makesym(functor_alloc__elem_4);
  allocp[1] = x2 = makeref(&allocp[1]);
  allocp[2] = arg(x0, 1);
  allocp[3] = a1;
  allocp[4] = arg(x0, 2);
  x1 = makefunctor(&allocp[0]);
  allocp[5] = a12;
  allocp[6] = x1;
  x3 = makecons(&allocp[5]);
  a0 = arg(x0, 0);
  a1 = x2;
  a2 = a5;
  a3 = a6;
  a4 = a7;
  a5 = a8;
  a6 = a9;
  a7 = a10;
  a8 = a11;
  a9 = x3;
  allocp += 7;
  execute(load__pos_10_0);
  goto load__pos_10_ext_interrupt;
  };
  goto alloc__one__for__struct__1_13_interrupt;
 case VARREF:
  deref_and_jump(x0,alloc__one__for__struct__1_13_2);
  *reasonp++ =  x0;
  goto alloc__one__for__struct__1_13_interrupt;
  };
  goto alloc__one__for__struct__1_13_interrupt;
  };
  goto alloc__one__for__struct__1_13_interrupt;
 case VARREF:
  deref_and_jump(a0,alloc__one__for__struct__1_13_1);
  *reasonp++ =  a0;
  goto alloc__one__for__struct__1_13_interrupt;
  };
  goto alloc__one__for__struct__1_13_interrupt;
 alloc__one__for__struct__1_13_ext_interrupt:
  reasonp = 0l;
 alloc__one__for__struct__1_13_interrupt:
  goto interrupt_13;
 }

 load__inline__args_11_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 load__inline__args_11_clear_reason:
  reasonp = reasons;
 load__inline__args_11_0:
 load__inline__args_11_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 load__inline__args_11_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor__2B_1:
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = x3 = makeref(&allocp[1]);
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xload__inline__args_11);
  x4 = cdr_of(a0);
  allocp[2] = x4;
  allocp[3] = a1;
  allocp[4] = x2;
  allocp[5] = x5 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x6 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = x7 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = x8 = makeref(&allocp[11]);
  allocp[12] = a10;
  a0 = arg(x0, 0);
  a1 = x3;
  a2 = a3;
  a3 = x5;
  a4 = a5;
  a5 = x6;
  a6 = a7;
  a7 = x7;
  a8 = a9;
  a9 = x8;
  qp = (struct goalrec*)&allocp[0];
  allocp += 13;
  execute(load__pos_10_0);
  goto load__pos_10_ext_interrupt;
 case functor__2D_1:
 load__inline__args_11_3:
  switch (ptagof(a1)) {
 case CONS:
  x1 = car_of(a1);
 load__inline__args_11_4:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor__3A_2)) goto load__inline__args_11_interrupt;
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a3;
  x2 = makefunctor(&allocp[0]);
  bblt_add_no_check_y(a3,makeint(1L),x3);
  allocp[2] = makesym(functor_r_1);
  allocp[3] = x2;
  x4 = makefunctor(&allocp[2]);
  allocp[4] = makesym(functor__24_3);
  allocp[5] = arg(x0, 0);
  allocp[6] = x4;
  allocp[7] = arg(x1, 1);
  x5 = makefunctor(&allocp[4]);
  allocp[8] = a5;
  allocp[9] = x5;
  x6 = makecons(&allocp[8]);
  allocp[10] = x8 = makeref(&allocp[10]);
  allocp[11] = x4;
  x7 = makecons(&allocp[10]);
  allocp += 12;
  unify_value(a2, x7);
  a0 = cdr_of(a0);
  a1 = cdr_of(a1);
  a2 = x8;
  a3 = x3;
  a5 = x6;
  execute(load__inline__args_11_0);
  goto load__inline__args_11_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,load__inline__args_11_4);
  *reasonp++ =  x1;
  goto load__inline__args_11_interrupt;
  };
  goto load__inline__args_11_interrupt;
 case VARREF:
  deref_and_jump(a1,load__inline__args_11_3);
  *reasonp++ =  a1;
  goto load__inline__args_11_interrupt;
  };
  goto load__inline__args_11_interrupt;
  };
  goto load__inline__args_11_interrupt;
 case VARREF:
  deref_and_jump(x0,load__inline__args_11_2);
  *reasonp++ =  x0;
  goto load__inline__args_11_interrupt;
  };
  goto load__inline__args_11_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto load__inline__args_11_interrupt;
  unify4(a10, a9, a8, a7, a6, a5, a4, a3);
  unify_value(a2, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a0,load__inline__args_11_1);
  *reasonp++ =  a0;
  goto load__inline__args_11_interrupt;
  };
  goto load__inline__args_11_interrupt;
 load__inline__args_11_ext_interrupt:
  reasonp = 0l;
 load__inline__args_11_interrupt:
  toppred = &predicate_klic__comp__generate_xload__inline__args_11;
  goto interrupt_11;
 }

 load__pos_10_top: {
  q x0, x1, x2, x3, x4, x5;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 load__pos_10_clear_reason:
  reasonp = reasons;
 load__pos_10_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xload__reg_11);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a3;
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = a5;
  allocp[9] = x4 = makeref(&allocp[9]);
  allocp[10] = a7;
  allocp[11] = x5 = makeref(&allocp[11]);
  allocp[12] = a9;
  a1 = x0;
  a3 = x2;
  a5 = x3;
  a7 = x4;
  a9 = x5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 13;
  execute(prep__pos_10_0);
  goto prep__pos_10_ext_interrupt;
 load__pos_10_ext_interrupt:
  reasonp = 0l;
 load__pos_10_interrupt:
  toppred = &predicate_klic__comp__generate_xload__pos_10;
  goto interrupt_10;
 }

 load__reg_11_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 load__reg_11_clear_reason:
  reasonp = reasons;
 load__reg_11_0:
 load__reg_11_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor__3A_2)) goto load__reg_11_3;
  x0 = arg(a0, 0);
 load__reg_11_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_r_1)) goto load__reg_11_3;
  unify4(a10, a9, a8, a7, a6, a5, a4, a3);
  x1 = arg(x0, 0);
  unify(a1, x1);
  x2 = arg(a0, 1);
  unify(a2, x2);
  proceed();
 case VARREF:
  deref_and_jump(x0,load__reg_11_2);
  *reasonp++ =  x0;
  goto load__reg_11_3;
  };
  goto load__reg_11_3;
 case VARREF:
  deref_and_jump(a0,load__reg_11_1);
  *reasonp++ =  a0;
  goto load__reg_11_3;
  };
  goto load__reg_11_3;
 load__reg_11_3:
  otherwise(load__reg_11_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xload__reg__1_11);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  allocp[12] = a10;
  x1 = a5;
  a1 = a0;
  a2 = x0;
  a0 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 13;
  execute(assocx_3_0);
  goto assocx_3_ext_interrupt;
 load__reg_11_ext_interrupt:
  reasonp = 0l;
 load__reg_11_interrupt:
  toppred = &predicate_klic__comp__generate_xload__reg_11;
  goto interrupt_11;
 }

 load__reg__1_11_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 load__reg__1_11_clear_reason:
  reasonp = reasons;
 load__reg__1_11_0:
 load__reg__1_11_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_yes_2:
  unify4(a10, a9, a8, a7, a6, a5, a4, a3);
  x0 = arg(a0, 0);
  unify(a1, x0);
  x1 = arg(a0, 1);
  unify(a2, x1);
  proceed();
 case functor_no_1:
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  bblt_add_no_check_y(a3,makeint(1L),x1);
  a0 = arg(a0, 0);
  a3 = x1;
  execute(load__reg__2_11_0);
  goto load__reg__2_11_ext_interrupt;
  };
  goto load__reg__1_11_interrupt;
 case VARREF:
  deref_and_jump(a0,load__reg__1_11_1);
  *reasonp++ =  a0;
  goto load__reg__1_11_interrupt;
  };
  goto load__reg__1_11_interrupt;
 load__reg__1_11_ext_interrupt:
  reasonp = 0l;
 load__reg__1_11_interrupt:
  goto interrupt_11;
 }

 load__reg__2_11_top: {
  q x0, x1, x2, x3, x4;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 load__reg__2_11_clear_reason:
  reasonp = reasons;
 load__reg__2_11_0:
 load__reg__2_11_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_arg_2:
  unify_value(a2, makesym(atom_any));
  allocp[0] = makesym(functor__24_3);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  x0 = makefunctor(&allocp[0]);
  allocp[4] = a5;
  allocp[5] = x0;
  x1 = makecons(&allocp[4]);
  allocp[6] = makesym(functor_get__elem_3);
  allocp[7] = a1;
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = arg(a0, 1);
  x2 = makefunctor(&allocp[6]);
  allocp[10] = a10;
  allocp[11] = x2;
  x4 = makecons(&allocp[10]);
  a0 = arg(a0, 0);
  a1 = x3;
  a2 = a3;
  a3 = a4;
  a4 = x1;
  a5 = a6;
  a6 = a7;
  a7 = a8;
  a8 = a9;
  a9 = x4;
  allocp += 12;
  execute(load__pos_10_0);
  goto load__pos_10_ext_interrupt;
 case functor_atom_1:
  unify3(a8, a7, a6, a5, a4, a3);
  unify_value(a2, makesym(atom_atom));
  allocp[0] = makesym(functor_load__const_2);
  allocp[1] = a1;
  allocp[2] = a0;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = a10;
  allocp[4] = x0;
  x1 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a9, x1);
  proceed();
 case functor_int_1:
  unify3(a8, a7, a6, a5, a4, a3);
  unify_value(a2, makesym(atom_int));
  allocp[0] = makesym(functor_load__const_2);
  allocp[1] = a1;
  allocp[2] = a0;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = a10;
  allocp[4] = x0;
  x1 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a9, x1);
  proceed();
 case functor_var_1:
  unify2(a8, a7, a4, a3);
  unify_value(a2, makesym(atom_any));
  allocp[0] = makesym(functor__24_3);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  x0 = makefunctor(&allocp[0]);
  allocp[4] = a5;
  allocp[5] = x0;
  x1 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a6, x1);
  allocp[0] = makesym(functor_load__newvar_1);
  allocp[1] = a1;
  x2 = makefunctor(&allocp[0]);
  allocp[2] = a10;
  allocp[3] = x2;
  x3 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a9, x3);
  proceed();
 case functor_const_1:
  unify3(a8, a7, a6, a5, a4, a3);
  unify_value(a2, makesym(atom_known));
  allocp[0] = makesym(functor_load__const_2);
  allocp[1] = a1;
  allocp[2] = a0;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = a10;
  allocp[4] = x0;
  x1 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a9, x1);
  proceed();
 case functor_arg_3:
  unify4(a10, a9, a8, a7, a6, a5, a4, a3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unix_xexit_1);
  allocp[2] = makeint(-1L);
  qp = (struct goalrec*)&allocp[0];
  allocp += 3;
  proceed();
 case functor_var_2:
  unify4(a10, a9, a8, a7, a6, a5, a4, a3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unix_xexit_1);
  allocp[2] = makeint(-1L);
  qp = (struct goalrec*)&allocp[0];
  allocp += 3;
  proceed();
  };
  goto load__reg__2_11_interrupt;
 case VARREF:
  deref_and_jump(a0,load__reg__2_11_1);
  *reasonp++ =  a0;
  goto load__reg__2_11_interrupt;
  };
  goto load__reg__2_11_interrupt;
 load__reg__2_11_ext_interrupt:
  reasonp = 0l;
 load__reg__2_11_interrupt:
  toppred = &predicate_klic__comp__generate_xload__reg__2_11;
  goto interrupt_11;
 }

 gen__body__arg_12_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 gen__body__arg_12_clear_reason:
  reasonp = reasons;
 gen__body__arg_12_0:
 gen__body__arg_12_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 gen__body__arg_12_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_makethread_2)) goto gen__body__arg_12_7;
  x1 = arg(x0, 1);
 gen__body__arg_12_3:
  if (isref(x1)) goto gen__body__arg_12_6;
 gen__body__arg_12_4:
  if (isref(x1)) goto gen__body__arg_12_5;
  x2 = arg(x0, 0);
  if_not_equal(x1, x2, gen__body__arg_12_7);
  a0 = cdr_of(a0);
  a2 = makeint(-1L);
  execute(gen__body__arg_12_clear_reason);
  goto gen__body__arg_12_ext_interrupt;
 gen__body__arg_12_5:
  deref_and_jump(x1,gen__body__arg_12_4);
  *reasonp++ =  x1;
  goto gen__body__arg_12_7;
 gen__body__arg_12_6:
  deref_and_jump(x1,gen__body__arg_12_3);
  *reasonp++ =  x1;
  goto gen__body__arg_12_7;
 case VARREF:
  deref_and_jump(x0,gen__body__arg_12_2);
  *reasonp++ =  x0;
  goto gen__body__arg_12_7;
  };
  goto gen__body__arg_12_7;
 case ATOMIC:
  if (a0 != NILATOM) goto gen__body__arg_12_7;
  unify4(a9, a8, a7, a6, a5, a4, a3, a2);
  unify_value(a1, NILATOM);
  allocp[0] = makesym(functor_move__allocp_1);
  allocp[1] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = a11;
  allocp[3] = x0;
  x1 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a10, x1);
  proceed();
 case VARREF:
  deref_and_jump(a0,gen__body__arg_12_1);
  *reasonp++ =  a0;
  goto gen__body__arg_12_7;
  };
  goto gen__body__arg_12_7;
 gen__body__arg_12_7:
  otherwise(gen__body__arg_12_interrupt);
 gen__body__arg_12_8:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 gen__body__arg_12_9:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_makethread_2)) goto gen__body__arg_12_10;
  allocp[0] = makesym(functor_makethread_2);
  allocp[1] = arg(x0, 0);
  allocp[2] = arg(x0, 1);
  x1 = makefunctor(&allocp[0]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x1;
  x2 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a10, x2);
  a0 = cdr_of(a0);
  a2 = arg(x0, 0);
  a10 = x3;
  execute(gen__body__arg_12_0);
  goto gen__body__arg_12_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,gen__body__arg_12_9);
  *reasonp++ =  x0;
  goto gen__body__arg_12_10;
  };
  goto gen__body__arg_12_10;
 case VARREF:
  deref_and_jump(a0,gen__body__arg_12_8);
  *reasonp++ =  a0;
  goto gen__body__arg_12_10;
  };
  goto gen__body__arg_12_10;
 gen__body__arg_12_10:
  otherwise(gen__body__arg_12_interrupt);
 gen__body__arg_12_11:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = x2 = makeref(&allocp[1]);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xgen__body__arg_12);
  x3 = cdr_of(a0);
  allocp[2] = x3;
  allocp[3] = x1;
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x5 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x6 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x7 = makeref(&allocp[10]);
  allocp[11] = a9;
  allocp[12] = x8 = makeref(&allocp[12]);
  allocp[13] = a11;
  a0 = car_of(a0);
  a1 = x2;
  a3 = x4;
  a5 = x5;
  a7 = x6;
  a9 = x7;
  a11 = x8;
  qp = (struct goalrec*)&allocp[0];
  allocp += 14;
  execute(gen__body__arg__1_12_0);
  goto gen__body__arg__1_12_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,gen__body__arg_12_11);
  *reasonp++ =  a0;
  goto gen__body__arg_12_interrupt;
  };
  goto gen__body__arg_12_interrupt;
 gen__body__arg_12_ext_interrupt:
  reasonp = 0l;
 gen__body__arg_12_interrupt:
  goto interrupt_12;
 }

 gen__body__arg__1_12_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 gen__body__arg__1_12_clear_reason:
  reasonp = reasons;
 gen__body__arg__1_12_0:
 gen__body__arg__1_12_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_call_4:
  allocp[0] = makesym(functor_call_4);
  allocp[1] = arg(a0, 0);
  allocp[2] = arg(a0, 1);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = arg(a0, 3);
  x0 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a1, x0);
  a0 = arg(a0, 2);
  a1 = x1;
  execute(gen__out__vars_12_0);
  goto gen__out__vars_12_ext_interrupt;
 case functor_xcall_5:
  allocp[0] = makesym(functor_xcall_5);
  allocp[1] = arg(a0, 0);
  allocp[2] = arg(a0, 1);
  allocp[3] = arg(a0, 2);
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = arg(a0, 4);
  x0 = makefunctor(&allocp[0]);
  allocp += 6;
  unify_value(a1, x0);
  a0 = arg(a0, 3);
  a1 = x1;
  execute(gen__out__vars_12_0);
  goto gen__out__vars_12_ext_interrupt;
 case functor_makethread_2:
  unify4(a11, a10, a9, a8, a7, a6, a5, a4);
  unify(a3, a2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xexit_1);
  allocp[2] = makeint(0L);
  a0 = makesym(atom_fatal);
  a1 = makesym(atom_makethread__errorr);
  qp = (struct goalrec*)&allocp[0];
  allocp += 3;
  execute(print__data_2_0);
  goto print__data_2_ext_interrupt;
 case functor_thread__top_1:
  unify4(a11, a10, a9, a8, a7, a6, a5, a4);
  allocp[0] = makesym(functor_thread__top_1);
  allocp[1] = arg(a0, 0);
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  x1 = arg(a0, 0);
  unify(a3, x1);
  proceed();
 case functor_thread__tail_2:
  unify4(a11, a10, a9, a8, a7, a6, a5, a4);
  allocp[0] = makesym(functor_thread__tail_2);
  allocp[1] = arg(a0, 0);
  allocp[2] = arg(a0, 1);
  x0 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a1, x0);
  bblt_sub_no_check_y(a2,makeint(1L),x1);
  unify(a3, x1);
  proceed();
 case functor_tcall_4:
  allocp[0] = makesym(functor_tcall_4);
  allocp[1] = arg(a0, 0);
  allocp[2] = arg(a0, 1);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = arg(a0, 3);
  x0 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a1, x0);
  a0 = arg(a0, 2);
  a1 = x1;
  execute(gen__out__vars_12_0);
  goto gen__out__vars_12_ext_interrupt;
 case functor_xtcall_5:
  allocp[0] = makesym(functor_xtcall_5);
  allocp[1] = arg(a0, 0);
  allocp[2] = arg(a0, 1);
  allocp[3] = arg(a0, 2);
  allocp[4] = arg(a0, 3);
  allocp[5] = arg(a0, 4);
  x0 = makefunctor(&allocp[0]);
  allocp += 6;
  unify_value(a1, x0);
  allocp[0] = x2 = makeref(&allocp[0]);
  x1 = x2;
  a1 = arg(a0, 3);
  a0 = x1;
  allocp += 1;
  execute(gen__out__vars_12_0);
  goto gen__out__vars_12_ext_interrupt;
 case functor_loop_4:
  allocp[0] = makesym(functor_loop_4);
  allocp[1] = arg(a0, 0);
  allocp[2] = arg(a0, 1);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = arg(a0, 3);
  x0 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a1, x0);
  a0 = arg(a0, 2);
  a1 = x1;
  execute(gen__out__vars_12_0);
  goto gen__out__vars_12_ext_interrupt;
 case functor_xloop_5:
  allocp[0] = makesym(functor_xloop_5);
  allocp[1] = arg(a0, 0);
  allocp[2] = arg(a0, 1);
  allocp[3] = arg(a0, 2);
  allocp[4] = arg(a0, 3);
  allocp[5] = arg(a0, 4);
  x0 = makefunctor(&allocp[0]);
  allocp += 6;
  unify_value(a1, x0);
  allocp[0] = x2 = makeref(&allocp[0]);
  x1 = x2;
  a1 = arg(a0, 3);
  a0 = x1;
  allocp += 1;
  execute(gen__out__vars_12_0);
  goto gen__out__vars_12_ext_interrupt;
 case functor_throw_5:
  x0 = arg(a0, 3);
  allocp[0] = makesym(functor_throw_5);
  allocp[1] = arg(a0, 0);
  allocp[2] = arg(a0, 1);
  allocp[3] = arg(a0, 2);
  allocp[4] = x0;
  allocp[5] = x2 = makeref(&allocp[5]);
  x1 = makefunctor(&allocp[0]);
  allocp += 6;
  unify_value(a1, x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = makeint(1L);
  allocp[4] = a3;
  a0 = arg(a0, 4);
  a1 = x2;
  a2 = x0;
  a3 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(gen__out__vars_12_0);
  goto gen__out__vars_12_ext_interrupt;
 case functor_xthrow_6:
  x0 = arg(a0, 4);
  allocp[0] = makesym(functor_xthrow_6);
  allocp[1] = arg(a0, 0);
  allocp[2] = arg(a0, 1);
  allocp[3] = arg(a0, 2);
  allocp[4] = arg(a0, 3);
  allocp[5] = x0;
  allocp[6] = x2 = makeref(&allocp[6]);
  x1 = makefunctor(&allocp[0]);
  allocp += 7;
  unify_value(a1, x1);
  a0 = arg(a0, 5);
  a1 = x2;
  a2 = x0;
  execute(gen__out__vars_12_0);
  goto gen__out__vars_12_ext_interrupt;
  };
  goto gen__body__arg__1_12_2;
 case VARREF:
  deref_and_jump(a0,gen__body__arg__1_12_1);
  *reasonp++ =  a0;
  goto gen__body__arg__1_12_2;
  };
  goto gen__body__arg__1_12_2;
 gen__body__arg__1_12_2:
  otherwise(gen__body__arg__1_12_interrupt);
  unify4(a11, a10, a9, a8, a7, a6, a5, a4);
  unify2(a3, a2, a1, a0);
  proceed();
 gen__body__arg__1_12_ext_interrupt:
  reasonp = 0l;
 gen__body__arg__1_12_interrupt:
  toppred = &predicate_klic__comp__generate_xgen__body__arg__1_12;
  goto interrupt_12;
 }

 gen__out__vars_12_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 gen__out__vars_12_clear_reason:
  reasonp = reasons;
 gen__out__vars_12_0:
 gen__out__vars_12_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = x2 = makeref(&allocp[1]);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xgen__out__vars_12);
  x3 = cdr_of(a0);
  allocp[2] = x3;
  allocp[3] = x1;
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x5 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x6 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x7 = makeref(&allocp[10]);
  allocp[11] = a9;
  allocp[12] = x8 = makeref(&allocp[12]);
  allocp[13] = a11;
  a0 = car_of(a0);
  a1 = x2;
  a3 = x4;
  a5 = x5;
  a7 = x6;
  a9 = x7;
  a11 = x8;
  qp = (struct goalrec*)&allocp[0];
  allocp += 14;
  execute(gen__out__var_12_0);
  goto gen__out__var_12_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto gen__out__vars_12_interrupt;
  unify4(a11, a10, a9, a8, a7, a6, a5, a4);
  unify(a3, a2);
  unify_value(a1, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a0,gen__out__vars_12_1);
  *reasonp++ =  a0;
  goto gen__out__vars_12_interrupt;
  };
  goto gen__out__vars_12_interrupt;
 gen__out__vars_12_ext_interrupt:
  reasonp = 0l;
 gen__out__vars_12_interrupt:
  toppred = &predicate_klic__comp__generate_xgen__out__vars_12;
  goto interrupt_12;
 }

 gen__out__var_12_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 gen__out__var_12_clear_reason:
  reasonp = reasons;
 gen__out__var_12_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xgen__out__var__1_13);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = a8;
  allocp[12] = a9;
  allocp[13] = a10;
  allocp[14] = a11;
  x1 = a8;
  a1 = a0;
  a2 = x0;
  a0 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 15;
  execute(assocx_3_0);
  goto assocx_3_ext_interrupt;
 gen__out__var_12_ext_interrupt:
  reasonp = 0l;
 gen__out__var_12_interrupt:
  toppred = &predicate_klic__comp__generate_xgen__out__var_12;
  goto interrupt_12;
 }

 gen__out__var__1_13_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  qp = qp->next;
 gen__out__var__1_13_clear_reason:
  reasonp = reasons;
 gen__out__var__1_13_0:
 gen__out__var__1_13_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_yes_2:
  unify4(a12, a11, a10, a9, a8, a7, a6, a5);
  unify2(a4, a3, a2, a1);
  proceed();
 case functor_no_1:
  x0 = arg(a0, 0);
 gen__out__var__1_13_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_var_2)) goto gen__out__var__1_13_4;
  x1 = arg(x0, 1);
 gen__out__var__1_13_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_o)) goto gen__out__var__1_13_4;
  unify(a4, a3);
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a7;
  x2 = makefunctor(&allocp[0]);
  bblt_add_no_check_y(a7,makeint(1L),x3);
  allocp += 2;
  unify(a8, x3);
  allocp[0] = makesym(functor_var_1);
  allocp[1] = arg(x0, 0);
  x4 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__24_3);
  allocp[3] = x4;
  allocp[4] = x2;
  allocp[5] = makesym(atom_any);
  x5 = makefunctor(&allocp[2]);
  allocp[6] = a9;
  allocp[7] = x5;
  x6 = makecons(&allocp[6]);
  allocp += 8;
  unify_value(a10, x6);
  unify(a2, a1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[2] = x7 = makeref(&allocp[2]);
  allocp[3] = makeint(2L);
  allocp[4] = a6;
  a0 = x2;
  a1 = a3;
  a2 = a5;
  a3 = x7;
  a4 = a11;
  a5 = a12;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(put__srec_6_0);
  goto put__srec_6_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,gen__out__var__1_13_3);
  *reasonp++ =  x1;
  goto gen__out__var__1_13_4;
  };
  goto gen__out__var__1_13_4;
 case VARREF:
  deref_and_jump(x0,gen__out__var__1_13_2);
  *reasonp++ =  x0;
  goto gen__out__var__1_13_4;
  };
  goto gen__out__var__1_13_4;
  };
  goto gen__out__var__1_13_4;
 case VARREF:
  deref_and_jump(a0,gen__out__var__1_13_1);
  *reasonp++ =  a0;
  goto gen__out__var__1_13_4;
  };
  goto gen__out__var__1_13_4;
 gen__out__var__1_13_4:
  otherwise(gen__out__var__1_13_interrupt);
  unify4(a12, a11, a10, a9, a8, a7, a6, a5);
  unify2(a4, a3, a2, a1);
  proceed();
 gen__out__var__1_13_ext_interrupt:
  reasonp = 0l;
 gen__out__var__1_13_interrupt:
  goto interrupt_13;
 }

 put__srec_6_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 put__srec_6_clear_reason:
  reasonp = reasons;
 put__srec_6_0:
 put__srec_6_1:
  if (!isint(a1)) goto put__srec_6_3;
  gblt_less(a1,makeint(0L),put__srec_6_2);
  unify(a3, a2);
  allocp[0] = makesym(functor_make__srec_3);
  allocp[1] = a2;
  allocp[2] = a0;
  allocp[3] = makesym(atom_qp);
  x0 = makefunctor(&allocp[0]);
  allocp[4] = a5;
  allocp[5] = x0;
  x1 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a4, x1);
  proceed();
 put__srec_6_2:
  gblt_greater_or_eq(a1,makeint(0L),put__srec_6_interrupt);
  unify(a3, a2);
  allocp[0] = makesym(functor_make__srec_3);
  allocp[1] = a2;
  allocp[2] = a0;
  allocp[3] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp[4] = a5;
  allocp[5] = x0;
  x1 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a4, x1);
  proceed();
 put__srec_6_3:
  if (!isref(a1)) goto put__srec_6_interrupt;
  deref_and_jump(a1,put__srec_6_1);
  *reasonp++ =  a1;
  goto put__srec_6_interrupt;
 put__srec_6_ext_interrupt:
  reasonp = 0l;
 put__srec_6_interrupt:
  toppred = &predicate_klic__comp__generate_xput__srec_6;
  goto interrupt_6;
 }

 gen__body_14_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  qp = qp->next;
 gen__body_14_clear_reason:
  reasonp = reasons;
 gen__body_14_0:
 gen__body_14_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 gen__body_14_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_go_3:
  x1 = cdr_of(a0);
 gen__body_14_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto gen__body_14_6;
  unify4(a11, a10, a9, a8, a7, a6, a5, a4);
  allocp[0] = makesym(functor_move__stackp_1);
  allocp[1] = a2;
  x2 = makefunctor(&allocp[0]);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = x2;
  x3 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a12, x3);
  allocp[0] = makesym(functor_go_5);
  allocp[1] = arg(x0, 0);
  allocp[2] = arg(x0, 1);
  allocp[3] = arg(x0, 2);
  allocp[4] = a1;
  allocp[5] = a3;
  x5 = makefunctor(&allocp[0]);
  allocp[6] = a13;
  allocp[7] = x5;
  x6 = makecons(&allocp[6]);
  allocp += 8;
  unify_value(x4, x6);
  proceed();
 case VARREF:
  deref_and_jump(x1,gen__body_14_3);
  *reasonp++ =  x1;
  goto gen__body_14_6;
  };
  goto gen__body_14_6;
 case functor_call_4:
  x1 = cdr_of(a0);
 gen__body_14_4:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto gen__body_14_6;
  unify(a5, a4);
  allocp[0] = makesym(functor__2F_2);
  allocp[1] = arg(x0, 0);
  allocp[2] = arg(x0, 1);
  x2 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_exec_1);
  allocp[4] = x2;
  x3 = makefunctor(&allocp[3]);
  allocp[5] = x5 = makeref(&allocp[5]);
  allocp[6] = x3;
  x4 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a10, x4);
  allocp[0] = makesym(functor_execute_4);
  allocp[1] = arg(x0, 0);
  allocp[2] = arg(x0, 1);
  allocp[3] = a1;
  allocp[4] = a3;
  x6 = makefunctor(&allocp[0]);
  allocp[5] = a13;
  allocp[6] = x6;
  x7 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_move__stackp_1);
  allocp[8] = a2;
  x8 = makefunctor(&allocp[7]);
  allocp[9] = x7;
  allocp[10] = x8;
  x9 = makecons(&allocp[9]);
  allocp[11] = (q)qp;
  allocp[12] = (q)(&predicate_klic__comp__generate_xmove__args_10);
  allocp[13] = x10 = makeref(&allocp[13]);
  allocp[14] = makeint(0L);
  allocp[15] = x11 = makeref(&allocp[15]);
  allocp[16] = a7;
  allocp[17] = x12 = makeref(&allocp[17]);
  allocp[18] = a9;
  allocp[19] = x13 = makeref(&allocp[19]);
  allocp[20] = a11;
  allocp[21] = x14 = makeref(&allocp[21]);
  allocp[22] = x9;
  a0 = arg(x0, 2);
  a1 = x10;
  a2 = a6;
  a3 = x11;
  a4 = a8;
  a5 = x12;
  a6 = x5;
  a7 = x13;
  a8 = a12;
  a9 = x14;
  qp = (struct goalrec*)&allocp[11];
  allocp += 23;
  execute(prep__poss_10_0);
  goto prep__poss_10_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,gen__body_14_4);
  *reasonp++ =  x1;
  goto gen__body_14_6;
  };
  goto gen__body_14_6;
 case functor_loop_4:
  x1 = cdr_of(a0);
 gen__body_14_5:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto gen__body_14_6;
  unify(a5, a4);
  allocp[0] = makesym(functor__2F_2);
  allocp[1] = arg(x0, 0);
  allocp[2] = arg(x0, 1);
  x2 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_exec_1);
  allocp[4] = x2;
  x3 = makefunctor(&allocp[3]);
  allocp[5] = x5 = makeref(&allocp[5]);
  allocp[6] = x3;
  x4 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a10, x4);
  allocp[0] = makesym(functor_execute__for__loop_4);
  allocp[1] = arg(x0, 0);
  allocp[2] = arg(x0, 1);
  allocp[3] = a1;
  allocp[4] = a3;
  x6 = makefunctor(&allocp[0]);
  allocp[5] = a13;
  allocp[6] = x6;
  x7 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_move__stackp_1);
  allocp[8] = a2;
  x8 = makefunctor(&allocp[7]);
  allocp[9] = x7;
  allocp[10] = x8;
  x9 = makecons(&allocp[9]);
  allocp[11] = (q)qp;
  allocp[12] = (q)(&predicate_klic__comp__generate_xmove__args_10);
  allocp[13] = x10 = makeref(&allocp[13]);
  allocp[14] = makeint(0L);
  allocp[15] = x11 = makeref(&allocp[15]);
  allocp[16] = a7;
  allocp[17] = x12 = makeref(&allocp[17]);
  allocp[18] = a9;
  allocp[19] = x13 = makeref(&allocp[19]);
  allocp[20] = a11;
  allocp[21] = x14 = makeref(&allocp[21]);
  allocp[22] = x9;
  a0 = arg(x0, 2);
  a1 = x10;
  a2 = a6;
  a3 = x11;
  a4 = a8;
  a5 = x12;
  a6 = x5;
  a7 = x13;
  a8 = a12;
  a9 = x14;
  qp = (struct goalrec*)&allocp[11];
  allocp += 23;
  execute(prep__poss_10_0);
  goto prep__poss_10_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,gen__body_14_5);
  *reasonp++ =  x1;
  goto gen__body_14_6;
  };
  goto gen__body_14_6;
  };
  goto gen__body_14_6;
 case VARREF:
  deref_and_jump(x0,gen__body_14_2);
  *reasonp++ =  x0;
  goto gen__body_14_6;
  };
  goto gen__body_14_6;
 case ATOMIC:
  if (a0 != NILATOM) goto gen__body_14_6;
  unify4(a11, a10, a9, a8, a7, a6, a5, a4);
  allocp[0] = makesym(functor_move__stackp_1);
  allocp[1] = a2;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x0;
  x1 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a12, x1);
  allocp[0] = makesym(functor_proceed_1);
  allocp[1] = a3;
  x3 = makefunctor(&allocp[0]);
  allocp[2] = a13;
  allocp[3] = x3;
  x4 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(x2, x4);
  proceed();
 case VARREF:
  deref_and_jump(a0,gen__body_14_1);
  *reasonp++ =  a0;
  goto gen__body_14_6;
  };
  goto gen__body_14_6;
 gen__body_14_6:
  otherwise(gen__body_14_interrupt);
 gen__body_14_7:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xgen__body_14);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x4 = makeref(&allocp[10]);
  allocp[11] = a9;
  allocp[12] = x5 = makeref(&allocp[12]);
  allocp[13] = a11;
  allocp[14] = x6 = makeref(&allocp[14]);
  allocp[15] = a13;
  allocp[16] = (q)(struct goalrec*)&allocp[0];
  allocp[17] = (q)(&predicate_klic__comp__generate_xgen__body__goal_13);
  x7 = car_of(a0);
  allocp[18] = x7;
  allocp[19] = a3;
  allocp[20] = x1;
  allocp[21] = a4;
  allocp[22] = x2;
  allocp[23] = a6;
  allocp[24] = x3;
  allocp[25] = a8;
  allocp[26] = x4;
  allocp[27] = a10;
  allocp[28] = x5;
  allocp[29] = a12;
  allocp[30] = x6;
  allocp[31] = (q)(struct goalrec*)&allocp[16];
  allocp[32] = (q)(&predicate_klic__comp__generate_xprint__data_2);
  allocp[33] = makesym(atom_gen__body__cdr);
  allocp[34] = x0;
  a0 = makesym(atom_gen__body__car);
  a1 = x7;
  qp = (struct goalrec*)&allocp[31];
  allocp += 35;
  execute(print__data_2_0);
  goto print__data_2_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,gen__body_14_7);
  *reasonp++ =  a0;
  goto gen__body_14_interrupt;
  };
  goto gen__body_14_interrupt;
 gen__body_14_ext_interrupt:
  reasonp = 0l;
 gen__body_14_interrupt:
  goto interrupt_14;
 }

 gen__body__goal_13_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20, x21, x22, x23, x24, x25, x26, x27, x28, x29, x30, x31;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  qp = qp->next;
 gen__body__goal_13_clear_reason:
  reasonp = reasons;
 gen__body__goal_13_0:
 gen__body__goal_13_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor__3D_2:
  unify(a4, a3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xbody__unify_12);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a6;
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = a8;
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = a10;
  allocp[10] = a1;
  allocp[11] = a2;
  allocp[12] = x5 = makeref(&allocp[12]);
  allocp[13] = a12;
  allocp[14] = (q)(struct goalrec*)&allocp[0];
  allocp[15] = (q)(&predicate_klic__comp__generate_xprep__pos_10);
  x6 = arg(a0, 1);
  allocp[16] = x6;
  allocp[17] = x1;
  allocp[18] = x7 = makeref(&allocp[18]);
  allocp[19] = x2;
  allocp[20] = x8 = makeref(&allocp[20]);
  allocp[21] = x3;
  allocp[22] = x9 = makeref(&allocp[22]);
  allocp[23] = x4;
  allocp[24] = x10 = makeref(&allocp[24]);
  allocp[25] = x5;
  a0 = arg(a0, 0);
  a1 = x0;
  a2 = a5;
  a3 = x7;
  a4 = a7;
  a5 = x8;
  a6 = a9;
  a7 = x9;
  a8 = a11;
  a9 = x10;
  qp = (struct goalrec*)&allocp[14];
  allocp += 26;
  execute(prep__pos_10_0);
  goto prep__pos_10_ext_interrupt;
 case functor_builtin_5:
  unify(a4, a3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xbb__out_14);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  x2 = arg(a0, 4);
  allocp[4] = x2;
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = x4 = makeref(&allocp[6]);
  allocp[7] = a6;
  allocp[8] = x5 = makeref(&allocp[8]);
  allocp[9] = a8;
  allocp[10] = x6 = makeref(&allocp[10]);
  allocp[11] = a10;
  allocp[12] = a1;
  allocp[13] = a2;
  allocp[14] = x7 = makeref(&allocp[14]);
  allocp[15] = a12;
  allocp[16] = makesym(functor_bblt_4);
  allocp[17] = x1;
  allocp[18] = arg(a0, 0);
  allocp[19] = x9 = makeref(&allocp[19]);
  allocp[20] = x3;
  x8 = makefunctor(&allocp[16]);
  allocp[21] = x7;
  allocp[22] = x8;
  x10 = makecons(&allocp[21]);
  allocp[23] = (q)(struct goalrec*)&allocp[0];
  allocp[24] = (q)(&predicate_klic__comp__generate_xbb__in_14);
  x11 = arg(a0, 3);
  allocp[25] = x11;
  allocp[26] = x12 = makeref(&allocp[26]);
  allocp[27] = x0;
  allocp[28] = makeint(1L);
  allocp[29] = x1;
  allocp[30] = x9;
  allocp[31] = x13 = makeref(&allocp[31]);
  allocp[32] = x4;
  allocp[33] = x14 = makeref(&allocp[33]);
  allocp[34] = x5;
  allocp[35] = x15 = makeref(&allocp[35]);
  allocp[36] = x6;
  allocp[37] = x16 = makeref(&allocp[37]);
  allocp[38] = x10;
  a0 = arg(a0, 2);
  a1 = x12;
  a2 = a5;
  a3 = x13;
  a4 = a7;
  a5 = x14;
  a6 = a9;
  a7 = x15;
  a8 = a11;
  a9 = x16;
  qp = (struct goalrec*)&allocp[23];
  allocp += 39;
  execute(prep__poss_10_0);
  goto prep__poss_10_ext_interrupt;
 case functor_call_4:
  unify2(a4, a3, a2, a1);
  allocp[0] = makesym(functor_put__pred_3);
  allocp[1] = arg(a0, 0);
  allocp[2] = arg(a0, 1);
  allocp[3] = arg(a0, 3);
  x0 = makefunctor(&allocp[0]);
  allocp[4] = NILATOM;
  allocp[5] = x0;
  x1 = makecons(&allocp[4]);
  x2 = arg(a0, 2);
  a1 = arg(a0, 3);
  a2 = x1;
  a3 = a5;
  a4 = a6;
  a5 = a7;
  a6 = a8;
  a7 = a9;
  a8 = a10;
  a9 = a11;
  a10 = a12;
  a0 = x2;
  allocp += 6;
  execute(put__call_11_0);
  goto put__call_11_ext_interrupt;
 case functor_xcall_5:
  unify2(a4, a3, a2, a1);
  allocp[0] = makesym(functor_ext_3);
  allocp[1] = arg(a0, 0);
  allocp[2] = arg(a0, 1);
  allocp[3] = arg(a0, 2);
  x0 = makefunctor(&allocp[0]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = x0;
  x1 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a9, x1);
  allocp[0] = makesym(functor_put__ext__pred_4);
  allocp[1] = arg(a0, 0);
  allocp[2] = arg(a0, 1);
  allocp[3] = arg(a0, 2);
  allocp[4] = arg(a0, 4);
  x3 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x3;
  x4 = makecons(&allocp[5]);
  x5 = arg(a0, 3);
  a1 = arg(a0, 4);
  a2 = x4;
  a3 = a5;
  a4 = a6;
  a5 = a7;
  a6 = a8;
  a7 = x2;
  a8 = a10;
  a9 = a11;
  a10 = a12;
  a0 = x5;
  allocp += 7;
  execute(put__call_11_0);
  goto put__call_11_ext_interrupt;
 case functor_gcall_3:
  x0 = arg(a0, 0);
 gen__body__goal_13_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (isint(x0)) goto gen__body__goal_13_17;
  switch (symval(x0)) {
 case symval(makesym(atom_new)):
  x1 = arg(a0, 2);
 gen__body__goal_13_3:
  switch (ptagof(x1)) {
 case CONS:
  x2 = car_of(x1);
 gen__body__goal_13_4:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_atom_1)) goto gen__body__goal_13_17;
  x3 = cdr_of(x1);
 gen__body__goal_13_5:
  switch (ptagof(x3)) {
 case CONS:
  unify(a4, a3);
  allocp[0] = makesym(functor_gnew_1);
  allocp[1] = arg(x2, 0);
  x4 = makefunctor(&allocp[0]);
  allocp[2] = x6 = makeref(&allocp[2]);
  allocp[3] = x4;
  x5 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a9, x5);
  x7 = arg(a0, 1);
  bblt_sub_no_check_y(x7,makeint(2L),x8);
  allocp[0] = makesym(functor_r_1);
  allocp[1] = x10 = makeref(&allocp[1]);
  x9 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__3A_2);
  allocp[3] = x9;
  allocp[4] = makesym(atom_any);
  x11 = makefunctor(&allocp[2]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_klic__comp__generate_xbody__unify_12);
  allocp[7] = x12 = makeref(&allocp[7]);
  allocp[8] = x11;
  allocp[9] = x13 = makeref(&allocp[9]);
  allocp[10] = a6;
  allocp[11] = x14 = makeref(&allocp[11]);
  allocp[12] = a8;
  allocp[13] = x15 = makeref(&allocp[13]);
  allocp[14] = a10;
  allocp[15] = x16 = makeref(&allocp[15]);
  allocp[16] = a2;
  allocp[17] = x17 = makeref(&allocp[17]);
  allocp[18] = a12;
  allocp[19] = (q)(struct goalrec*)&allocp[5];
  allocp[20] = (q)(&predicate_klic__comp__generate_xprep__pos_10);
  x18 = car_of(x3);
  allocp[21] = x18;
  allocp[22] = x12;
  allocp[23] = x19 = makeref(&allocp[23]);
  allocp[24] = x13;
  allocp[25] = x20 = makeref(&allocp[25]);
  allocp[26] = x14;
  allocp[27] = x21 = makeref(&allocp[27]);
  allocp[28] = x15;
  allocp[29] = x22 = makeref(&allocp[29]);
  allocp[30] = x17;
  qp = (struct goalrec*)&allocp[19];
  allocp += 31;
  unify_value(x16, makesym(atom_qp));
  allocp[0] = makesym(functor_new__generic_4);
  allocp[1] = arg(x2, 0);
  allocp[2] = x8;
  allocp[3] = x10;
  allocp[4] = a1;
  x23 = makefunctor(&allocp[0]);
  allocp[5] = x22;
  allocp[6] = x23;
  x24 = makecons(&allocp[5]);
  allocp[7] = (q)qp;
  allocp[8] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[9] = x25 = makeref(&allocp[9]);
  allocp[10] = makeint(1L);
  allocp[11] = x19;
  allocp[12] = makesym(functor_x_1);
  allocp[13] = x25;
  x26 = makefunctor(&allocp[12]);
  qp = (struct goalrec*)&allocp[7];
  allocp += 14;
  unify_value(x10, x26);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xset__generic__args_10);
  allocp[2] = x27 = makeref(&allocp[2]);
  allocp[3] = makeint(0L);
  allocp[4] = x28 = makeref(&allocp[4]);
  allocp[5] = x25;
  allocp[6] = x29 = makeref(&allocp[6]);
  allocp[7] = x20;
  allocp[8] = x30 = makeref(&allocp[8]);
  allocp[9] = x21;
  allocp[10] = x31 = makeref(&allocp[10]);
  allocp[11] = x24;
  a0 = cdr_of(x3);
  a1 = x27;
  a2 = a5;
  a3 = x28;
  a4 = a7;
  a5 = x29;
  a6 = x6;
  a7 = x30;
  a8 = a11;
  a9 = x31;
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  execute(prep__poss_10_0);
  goto prep__poss_10_ext_interrupt;
 case VARREF:
  deref_and_jump(x3,gen__body__goal_13_5);
  *reasonp++ =  x3;
  goto gen__body__goal_13_17;
  };
  goto gen__body__goal_13_17;
 case VARREF:
  deref_and_jump(x2,gen__body__goal_13_4);
  *reasonp++ =  x2;
  goto gen__body__goal_13_17;
  };
  goto gen__body__goal_13_17;
 case VARREF:
  deref_and_jump(x1,gen__body__goal_13_3);
  *reasonp++ =  x1;
  goto gen__body__goal_13_17;
  };
  goto gen__body__goal_13_17;
 case symval(makesym(atom_generic)):
  x1 = arg(a0, 1);
 gen__body__goal_13_6:
  switch (ptagof(x1)) {
 case ATOMIC:
 gen__body__goal_13_7:
  if (x1 != makeint(2L)) goto gen__body__goal_13_17;
  x2 = arg(a0, 2);
 gen__body__goal_13_8:
  switch (ptagof(x2)) {
 case CONS:
  x3 = cdr_of(x2);
 gen__body__goal_13_9:
  switch (ptagof(x3)) {
 case CONS:
  x4 = car_of(x3);
 gen__body__goal_13_10:
  switch (ptagof(x4)) {
 case FUNCTOR:
  switch (symval(functor_of(x4))) {
 case functor_mkfunct_2:
  x5 = arg(x4, 0);
 gen__body__goal_13_11:
  switch (ptagof(x5)) {
 case FUNCTOR:
  if (functor_of(x5) != makesym(functor__2F_2)) goto gen__body__goal_13_17;
  x6 = cdr_of(x3);
 gen__body__goal_13_12:
  switch (ptagof(x6)) {
 case ATOMIC:
  if (x6 != NILATOM) goto gen__body__goal_13_17;
  x7 = arg(x5, 1);
  bblt_add_no_check_y(x7,makeint(1L),x8);
  allocp[0] = arg(x4, 1);
  allocp[1] = car_of(x2);
  x9 = makecons(&allocp[0]);
  allocp[2] = makesym(functor_gcall_3);
  allocp[3] = arg(x5, 0);
  allocp[4] = x8;
  allocp[5] = x9;
  x10 = makefunctor(&allocp[2]);
  a0 = x10;
  allocp += 6;
  execute(gen__body__goal_13_0);
  goto gen__body__goal_13_ext_interrupt;
 case VARREF:
  deref_and_jump(x6,gen__body__goal_13_12);
  *reasonp++ =  x6;
  goto gen__body__goal_13_17;
  };
  goto gen__body__goal_13_17;
 case VARREF:
  deref_and_jump(x5,gen__body__goal_13_11);
  *reasonp++ =  x5;
  goto gen__body__goal_13_17;
  };
  goto gen__body__goal_13_17;
 case functor_atom_1:
  x5 = cdr_of(x3);
 gen__body__goal_13_13:
  switch (ptagof(x5)) {
 case ATOMIC:
  if (x5 != NILATOM) goto gen__body__goal_13_17;
  allocp[0] = NILATOM;
  allocp[1] = car_of(x2);
  x6 = makecons(&allocp[0]);
  allocp[2] = makesym(functor_gcall_3);
  allocp[3] = arg(x4, 0);
  allocp[4] = makeint(1L);
  allocp[5] = x6;
  x7 = makefunctor(&allocp[2]);
  a0 = x7;
  allocp += 6;
  execute(gen__body__goal_13_0);
  goto gen__body__goal_13_ext_interrupt;
 case VARREF:
  deref_and_jump(x5,gen__body__goal_13_13);
  *reasonp++ =  x5;
  goto gen__body__goal_13_17;
  };
  goto gen__body__goal_13_17;
 case functor_functor_1:
  x5 = cdr_of(x3);
 gen__body__goal_13_14:
  switch (ptagof(x5)) {
 case ATOMIC:
  if (x5 != NILATOM) goto gen__body__goal_13_17;
  x6 = arg(x4, 0);
 gen__body__goal_13_15:
  if (isref(x6)) goto gen__body__goal_13_16;
  gblt_pfunctor(x6,x7,gen__body__goal_13_17);
  gblt_arity(x6,x8,gen__body__goal_13_17);
  bblt_add_no_check(x8,makeint(1L),x9);
  allocp[0] = x11 = makeref(&allocp[0]);
  allocp[1] = car_of(x2);
  x10 = makecons(&allocp[0]);
  allocp[2] = makesym(functor_gcall_3);
  allocp[3] = x7;
  allocp[4] = x9;
  allocp[5] = x10;
  x12 = makefunctor(&allocp[2]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_klic__comp__generate_xgen__body__goal_13);
  allocp[8] = x12;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  allocp[12] = a4;
  allocp[13] = a5;
  allocp[14] = a6;
  allocp[15] = a7;
  allocp[16] = a8;
  allocp[17] = a9;
  allocp[18] = a10;
  allocp[19] = a11;
  allocp[20] = a12;
  allocp[21] = x11;
  allocp[22] = x14 = makeref(&allocp[22]);
  x13 = makecons(&allocp[21]);
  allocp[23] = (q)(struct goalrec*)&allocp[6];
  allocp[24] = (q)(&predicate_klic__comp__util_xuniv_2);
  allocp[25] = x6;
  allocp[26] = x13;
  qp = (struct goalrec*)&allocp[23];
  allocp += 27;
  proceed();
 gen__body__goal_13_16:
  deref_and_jump(x6,gen__body__goal_13_15);
  *reasonp++ =  x6;
  goto gen__body__goal_13_17;
 case VARREF:
  deref_and_jump(x5,gen__body__goal_13_14);
  *reasonp++ =  x5;
  goto gen__body__goal_13_17;
  };
  goto gen__body__goal_13_17;
  };
  goto gen__body__goal_13_17;
 case VARREF:
  deref_and_jump(x4,gen__body__goal_13_10);
  *reasonp++ =  x4;
  goto gen__body__goal_13_17;
  };
  goto gen__body__goal_13_17;
 case VARREF:
  deref_and_jump(x3,gen__body__goal_13_9);
  *reasonp++ =  x3;
  goto gen__body__goal_13_17;
  };
  goto gen__body__goal_13_17;
 case VARREF:
  deref_and_jump(x2,gen__body__goal_13_8);
  *reasonp++ =  x2;
  goto gen__body__goal_13_17;
  };
  goto gen__body__goal_13_17;
 case VARREF:
  deref_and_jump(x1,gen__body__goal_13_6);
  *reasonp++ =  x1;
  goto gen__body__goal_13_17;
  };
  goto gen__body__goal_13_17;
  };
  goto gen__body__goal_13_17;
 case VARREF:
  deref_and_jump(x0,gen__body__goal_13_2);
  *reasonp++ =  x0;
  goto gen__body__goal_13_17;
  };
  goto gen__body__goal_13_17;
  };
  goto gen__body__goal_13_17;
 case VARREF:
  deref_and_jump(a0,gen__body__goal_13_1);
  *reasonp++ =  a0;
  goto gen__body__goal_13_17;
  };
  goto gen__body__goal_13_17;
 gen__body__goal_13_17:
  otherwise(gen__body__goal_13_interrupt);
 gen__body__goal_13_18:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_gcall_3:
  x0 = arg(a0, 2);
 gen__body__goal_13_19:
  switch (ptagof(x0)) {
 case CONS:
  unify(a4, a3);
  x1 = arg(a0, 1);
  bblt_sub_no_check_y(x1,makeint(1L),x2);
  allocp[0] = makesym(functor__2F_2);
  allocp[1] = arg(a0, 0);
  allocp[2] = x2;
  x3 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_funct_1);
  allocp[4] = x3;
  x4 = makefunctor(&allocp[3]);
  allocp[5] = x6 = makeref(&allocp[5]);
  allocp[6] = x4;
  x5 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a9, x5);
  unify_value(a2, makesym(atom_qp));
  allocp[0] = makesym(functor_r_1);
  allocp[1] = x8 = makeref(&allocp[1]);
  x7 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__2F_2);
  allocp[3] = arg(a0, 0);
  allocp[4] = x2;
  x9 = makefunctor(&allocp[2]);
  allocp[5] = makesym(functor_call__generic_3);
  allocp[6] = x7;
  allocp[7] = x9;
  allocp[8] = a1;
  x10 = makefunctor(&allocp[5]);
  allocp[9] = a12;
  allocp[10] = x10;
  x11 = makecons(&allocp[9]);
  allocp[11] = (q)qp;
  allocp[12] = (q)(&predicate_klic__comp__generate_xload__pos_10);
  x12 = car_of(x0);
  allocp[13] = x12;
  allocp[14] = x8;
  allocp[15] = x13 = makeref(&allocp[15]);
  allocp[16] = a6;
  allocp[17] = x14 = makeref(&allocp[17]);
  allocp[18] = a8;
  allocp[19] = x15 = makeref(&allocp[19]);
  allocp[20] = a10;
  allocp[21] = x16 = makeref(&allocp[21]);
  allocp[22] = x11;
  allocp[23] = (q)(struct goalrec*)&allocp[11];
  allocp[24] = (q)(&predicate_klic__comp__generate_xset__generic__args_10);
  allocp[25] = x17 = makeref(&allocp[25]);
  allocp[26] = makeint(0L);
  allocp[27] = x18 = makeref(&allocp[27]);
  allocp[28] = x13;
  allocp[29] = x19 = makeref(&allocp[29]);
  allocp[30] = x14;
  allocp[31] = x20 = makeref(&allocp[31]);
  allocp[32] = x15;
  allocp[33] = x21 = makeref(&allocp[33]);
  allocp[34] = x16;
  a0 = cdr_of(x0);
  a1 = x17;
  a2 = a5;
  a3 = x18;
  a4 = a7;
  a5 = x19;
  a6 = x6;
  a7 = x20;
  a8 = a11;
  a9 = x21;
  qp = (struct goalrec*)&allocp[23];
  allocp += 35;
  execute(prep__poss_10_0);
  goto prep__poss_10_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,gen__body__goal_13_19);
  *reasonp++ =  x0;
  goto gen__body__goal_13_interrupt;
  };
  goto gen__body__goal_13_interrupt;
 case functor_makethread_2:
  unify4(a12, a11, a10, a9, a8, a7, a6, a5);
  unify2(a4, a3, a2, a1);
  proceed();
 case functor_thread__top_1:
  unify4(a10, a9, a8, a7, a6, a5, a4, a3);
  unify(a2, a1);
  allocp[0] = makesym(functor_thread__top_1);
  allocp[1] = arg(a0, 0);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = a12;
  allocp[3] = x0;
  x1 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a11, x1);
  proceed();
 case functor_thread__tail_2:
  unify4(a10, a9, a8, a7, a6, a5, a4, a3);
  unify(a2, a1);
  allocp[0] = makesym(functor_enqueue_2);
  allocp[1] = arg(a0, 0);
  allocp[2] = arg(a0, 1);
  x0 = makefunctor(&allocp[0]);
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = x0;
  x1 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a11, x1);
  allocp[0] = a12;
  allocp[1] = makesym(atom_thread__tail);
  x3 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(x2, x3);
  proceed();
 case functor_tcall_4:
  unify2(a4, a3, a2, a1);
  allocp[0] = makesym(functor_put__pred_3);
  allocp[1] = arg(a0, 0);
  allocp[2] = arg(a0, 1);
  allocp[3] = arg(a0, 3);
  x0 = makefunctor(&allocp[0]);
  allocp[4] = NILATOM;
  allocp[5] = x0;
  x1 = makecons(&allocp[4]);
  x2 = arg(a0, 2);
  a1 = arg(a0, 3);
  a2 = x1;
  a3 = a5;
  a4 = a6;
  a5 = a7;
  a6 = a8;
  a7 = a9;
  a8 = a10;
  a9 = a11;
  a10 = a12;
  a0 = x2;
  allocp += 6;
  execute(push__tcall_11_0);
  goto push__tcall_11_ext_interrupt;
 case functor_xtcall_5:
  unify2(a4, a3, a2, a1);
  allocp[0] = makesym(functor_ext_3);
  allocp[1] = arg(a0, 0);
  allocp[2] = arg(a0, 1);
  allocp[3] = arg(a0, 2);
  x0 = makefunctor(&allocp[0]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = x0;
  x1 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a9, x1);
  allocp[0] = makesym(functor_put__ext__pred_4);
  allocp[1] = arg(a0, 0);
  allocp[2] = arg(a0, 1);
  allocp[3] = arg(a0, 2);
  allocp[4] = arg(a0, 4);
  x3 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x3;
  x4 = makecons(&allocp[5]);
  x5 = arg(a0, 3);
  a1 = arg(a0, 4);
  a2 = x4;
  a3 = a5;
  a4 = a6;
  a5 = a7;
  a6 = a8;
  a7 = x2;
  a8 = a10;
  a9 = a11;
  a10 = a12;
  a0 = x5;
  allocp += 7;
  execute(push__tcall_11_0);
  goto push__tcall_11_ext_interrupt;
 case functor_loop_4:
  unify2(a4, a3, a2, a1);
  x0 = arg(a0, 3);
  x1 = arg(a0, 1);
  bblt_add(x0,x1,x2);
  bblt_add_no_check_y(x2,makeint(1L),x3);
  allocp[0] = makesym(functor_put__pred_3);
  allocp[1] = arg(a0, 0);
  allocp[2] = x1;
  allocp[3] = x0;
  x4 = makefunctor(&allocp[0]);
  allocp[4] = makesym(functor_put__loop_1);
  allocp[5] = x3;
  x5 = makefunctor(&allocp[4]);
  allocp[6] = NILATOM;
  allocp[7] = x5;
  x6 = makecons(&allocp[6]);
  allocp[8] = x6;
  allocp[9] = x4;
  x7 = makecons(&allocp[8]);
  a0 = arg(a0, 2);
  a1 = x0;
  a2 = x7;
  a3 = a5;
  a4 = a6;
  a5 = a7;
  a6 = a8;
  a7 = a9;
  a8 = a10;
  a9 = a11;
  a10 = a12;
  allocp += 10;
  execute(put__call_11_0);
  goto put__call_11_ext_interrupt;
 case functor_xloop_5:
  unify2(a4, a3, a2, a1);
  allocp[0] = makesym(functor_ext_3);
  allocp[1] = arg(a0, 0);
  allocp[2] = arg(a0, 1);
  allocp[3] = arg(a0, 2);
  x0 = makefunctor(&allocp[0]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = x0;
  x1 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a9, x1);
  x3 = arg(a0, 4);
  x4 = arg(a0, 2);
  bblt_add(x3,x4,x5);
  bblt_add_no_check_y(x5,makeint(1L),x6);
  allocp[0] = makesym(functor_put__ext__pred_4);
  allocp[1] = arg(a0, 0);
  allocp[2] = arg(a0, 1);
  allocp[3] = x4;
  allocp[4] = x3;
  x7 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_put__loop_1);
  allocp[6] = x6;
  x8 = makefunctor(&allocp[5]);
  allocp[7] = NILATOM;
  allocp[8] = x8;
  x9 = makecons(&allocp[7]);
  allocp[9] = x9;
  allocp[10] = x7;
  x10 = makecons(&allocp[9]);
  a0 = arg(a0, 3);
  a1 = x3;
  a2 = x10;
  a3 = a5;
  a4 = a6;
  a5 = a7;
  a6 = a8;
  a7 = x2;
  a8 = a10;
  a9 = a11;
  a10 = a12;
  allocp += 11;
  execute(put__call_11_0);
  goto put__call_11_ext_interrupt;
 case functor_throw_5:
  unify(a4, a3);
  allocp[0] = makesym(functor_thread__top_1);
  allocp[1] = arg(a0, 3);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x0;
  x1 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a11, x1);
  unify_value(a2, makesym(atom_qp));
  allocp[0] = a12;
  allocp[1] = makesym(atom_thread__tail);
  x3 = makecons(&allocp[0]);
  allocp[2] = x3;
  allocp[3] = makesym(atom_reset__allocp);
  x4 = makecons(&allocp[2]);
  allocp[4] = makesym(functor_throw__thread_2);
  allocp[5] = x6 = makeref(&allocp[5]);
  allocp[6] = arg(a0, 3);
  x5 = makefunctor(&allocp[4]);
  allocp[7] = x4;
  allocp[8] = x5;
  x7 = makecons(&allocp[7]);
  allocp[9] = (q)qp;
  allocp[10] = (q)(&predicate_klic__comp__generate_xload__pos_10);
  x8 = arg(a0, 0);
  allocp[11] = x8;
  allocp[12] = x6;
  allocp[13] = x9 = makeref(&allocp[13]);
  allocp[14] = a6;
  allocp[15] = x10 = makeref(&allocp[15]);
  allocp[16] = a8;
  allocp[17] = x11 = makeref(&allocp[17]);
  allocp[18] = a10;
  allocp[19] = x12 = makeref(&allocp[19]);
  allocp[20] = x7;
  allocp[21] = makesym(functor_move__stacktop_2);
  allocp[22] = arg(a0, 3);
  allocp[23] = x14 = makeref(&allocp[23]);
  x13 = makefunctor(&allocp[21]);
  allocp[24] = x12;
  allocp[25] = x13;
  x15 = makecons(&allocp[24]);
  allocp[26] = (q)(struct goalrec*)&allocp[9];
  allocp[27] = (q)(&predicate_integer__arithmetics_xadd_3);
  x16 = arg(a0, 2);
  allocp[28] = x16;
  allocp[29] = makeint(1L);
  allocp[30] = x14;
  allocp[31] = makesym(functor_put__pred_3);
  allocp[32] = arg(a0, 1);
  allocp[33] = x16;
  allocp[34] = makeint(0L);
  x17 = makefunctor(&allocp[31]);
  allocp[35] = NILATOM;
  allocp[36] = x17;
  x18 = makecons(&allocp[35]);
  a0 = arg(a0, 4);
  a1 = x18;
  a2 = a5;
  a3 = x9;
  a4 = a7;
  a5 = x10;
  a6 = a9;
  a7 = x11;
  a8 = x2;
  a9 = x15;
  qp = (struct goalrec*)&allocp[26];
  allocp += 37;
  execute(set__args__for__newthread_10_0);
  goto set__args__for__newthread_10_ext_interrupt;
 case functor_xthrow_6:
  unify(a4, a3);
  allocp[0] = makesym(functor_ext_3);
  allocp[1] = arg(a0, 1);
  allocp[2] = arg(a0, 2);
  allocp[3] = arg(a0, 3);
  x0 = makefunctor(&allocp[0]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = x0;
  x1 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a9, x1);
  unify_value(a2, makesym(atom_qp));
  allocp[0] = a12;
  allocp[1] = makesym(atom_reset__allocp);
  x3 = makecons(&allocp[0]);
  allocp[2] = makesym(functor_throw__goal_3);
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = a1;
  allocp[5] = x6 = makeref(&allocp[5]);
  x4 = makefunctor(&allocp[2]);
  allocp[6] = x3;
  allocp[7] = x4;
  x7 = makecons(&allocp[6]);
  allocp[8] = (q)qp;
  allocp[9] = (q)(&predicate_klic__comp__generate_xload__pos_10);
  x8 = arg(a0, 0);
  allocp[10] = x8;
  allocp[11] = x5;
  allocp[12] = x9 = makeref(&allocp[12]);
  allocp[13] = a6;
  allocp[14] = x10 = makeref(&allocp[14]);
  allocp[15] = a8;
  allocp[16] = x11 = makeref(&allocp[16]);
  allocp[17] = a10;
  allocp[18] = x12 = makeref(&allocp[18]);
  allocp[19] = x7;
  allocp[20] = makesym(functor_heappos_1);
  allocp[21] = x6;
  x13 = makefunctor(&allocp[20]);
  allocp[22] = makesym(functor_set__ext__pred_3);
  allocp[23] = arg(a0, 1);
  allocp[24] = arg(a0, 2);
  allocp[25] = arg(a0, 3);
  x14 = makefunctor(&allocp[22]);
  allocp[26] = NILATOM;
  allocp[27] = x14;
  x15 = makecons(&allocp[26]);
  allocp[28] = x15;
  allocp[29] = x13;
  x16 = makecons(&allocp[28]);
  a0 = arg(a0, 5);
  a1 = x16;
  a2 = a5;
  a3 = x9;
  a4 = a7;
  a5 = x10;
  a6 = x2;
  a7 = x11;
  a8 = a11;
  a9 = x12;
  qp = (struct goalrec*)&allocp[8];
  allocp += 30;
  execute(set__call_10_0);
  goto set__call_10_ext_interrupt;
  };
  goto gen__body__goal_13_interrupt;
 case VARREF:
  deref_and_jump(a0,gen__body__goal_13_18);
  *reasonp++ =  a0;
  goto gen__body__goal_13_interrupt;
  };
  goto gen__body__goal_13_interrupt;
 gen__body__goal_13_ext_interrupt:
  reasonp = 0l;
 gen__body__goal_13_interrupt:
  goto interrupt_13;
 }

 set__call_10_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 set__call_10_clear_reason:
  reasonp = reasons;
 set__call_10_0:
  allocp[0] = makesym(functor_make__space_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = a9;
  allocp[3] = x0;
  x2 = makecons(&allocp[2]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = makeint(2L);
  allocp[8] = x1;
  allocp[9] = (q)(struct goalrec*)&allocp[4];
  allocp[10] = (q)(&predicate_klic__comp__util_xlength_2);
  allocp[11] = x4 = makeref(&allocp[11]);
  allocp[12] = x3;
  allocp[13] = (q)(struct goalrec*)&allocp[9];
  allocp[14] = (q)(&predicate_klic__comp__generate_xset__args_10);
  allocp[15] = x4;
  allocp[16] = makeint(0L);
  allocp[17] = x5 = makeref(&allocp[17]);
  allocp[18] = a3;
  allocp[19] = x6 = makeref(&allocp[19]);
  allocp[20] = a5;
  allocp[21] = x7 = makeref(&allocp[21]);
  allocp[22] = a7;
  allocp[23] = x8 = makeref(&allocp[23]);
  allocp[24] = x2;
  allocp[25] = (q)(struct goalrec*)&allocp[13];
  allocp[26] = (q)(&predicate_klic__comp__generate_xset__call__merge_3);
  allocp[27] = a1;
  allocp[28] = x9 = makeref(&allocp[28]);
  allocp[29] = x8;
  a1 = x4;
  a3 = x5;
  a5 = x6;
  a7 = x7;
  a9 = x9;
  qp = (struct goalrec*)&allocp[25];
  allocp += 30;
  execute(prep__poss_10_0);
  goto prep__poss_10_ext_interrupt;
 set__call_10_ext_interrupt:
  reasonp = 0l;
 set__call_10_interrupt:
  toppred = &predicate_klic__comp__generate_xset__call_10;
  goto interrupt_10;
 }

 put__call_11_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 put__call_11_clear_reason:
  reasonp = reasons;
 put__call_11_0:
  allocp[0] = makesym(functor_make__space_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = a10;
  allocp[3] = x0;
  x2 = makecons(&allocp[2]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_klic__comp__generate_xset__call__merge_3);
  allocp[6] = a2;
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = x2;
  allocp[9] = (q)(struct goalrec*)&allocp[4];
  allocp[10] = (q)(&predicate_klic__comp__generate_xput__args_12);
  allocp[11] = x4 = makeref(&allocp[11]);
  allocp[12] = a1;
  allocp[13] = makeint(0L);
  allocp[14] = x1;
  allocp[15] = x5 = makeref(&allocp[15]);
  allocp[16] = a4;
  allocp[17] = x6 = makeref(&allocp[17]);
  allocp[18] = a6;
  allocp[19] = x7 = makeref(&allocp[19]);
  allocp[20] = a8;
  allocp[21] = x8 = makeref(&allocp[21]);
  allocp[22] = x3;
  a1 = x4;
  a2 = a3;
  a3 = x5;
  a4 = a5;
  a5 = x6;
  a6 = a7;
  a7 = x7;
  a8 = a9;
  a9 = x8;
  qp = (struct goalrec*)&allocp[9];
  allocp += 23;
  execute(prep__poss_10_0);
  goto prep__poss_10_ext_interrupt;
 put__call_11_ext_interrupt:
  reasonp = 0l;
 put__call_11_interrupt:
  toppred = &predicate_klic__comp__generate_xput__call_11;
  goto interrupt_11;
 }

 push__tcall_11_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 push__tcall_11_clear_reason:
  reasonp = reasons;
 push__tcall_11_0:
  allocp[0] = makesym(functor_make__space_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = a10;
  allocp[3] = x0;
  x2 = makecons(&allocp[2]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_klic__comp__generate_xset__call__merge_3);
  allocp[6] = a2;
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = x2;
  allocp[9] = (q)(struct goalrec*)&allocp[4];
  allocp[10] = (q)(&predicate_klic__comp__generate_xput__args_12);
  allocp[11] = x4 = makeref(&allocp[11]);
  allocp[12] = a1;
  allocp[13] = makeint(0L);
  allocp[14] = x1;
  allocp[15] = x5 = makeref(&allocp[15]);
  allocp[16] = a4;
  allocp[17] = x6 = makeref(&allocp[17]);
  allocp[18] = a6;
  allocp[19] = x7 = makeref(&allocp[19]);
  allocp[20] = a8;
  allocp[21] = x8 = makeref(&allocp[21]);
  allocp[22] = x3;
  a1 = x4;
  a2 = a3;
  a3 = x5;
  a4 = a5;
  a5 = x6;
  a6 = a7;
  a7 = x7;
  a8 = a9;
  a9 = x8;
  qp = (struct goalrec*)&allocp[9];
  allocp += 23;
  execute(prep__poss_10_0);
  goto prep__poss_10_ext_interrupt;
 push__tcall_11_ext_interrupt:
  reasonp = 0l;
 push__tcall_11_interrupt:
  toppred = &predicate_klic__comp__generate_xpush__tcall_11;
  goto interrupt_11;
 }

 set__args__for__newthread_10_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 set__args__for__newthread_10_clear_reason:
  reasonp = reasons;
 set__args__for__newthread_10_0:
  allocp[0] = makesym(functor_make__space_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = a9;
  allocp[3] = x0;
  x2 = makecons(&allocp[2]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_klic__comp__generate_xset__call__merge_3);
  allocp[6] = a1;
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = x2;
  allocp[9] = (q)(struct goalrec*)&allocp[4];
  allocp[10] = (q)(&predicate_klic__comp__generate_xput__args_12);
  allocp[11] = x4 = makeref(&allocp[11]);
  allocp[12] = makeint(0L);
  allocp[13] = makeint(0L);
  allocp[14] = x1;
  allocp[15] = x5 = makeref(&allocp[15]);
  allocp[16] = a3;
  allocp[17] = x6 = makeref(&allocp[17]);
  allocp[18] = a5;
  allocp[19] = x7 = makeref(&allocp[19]);
  allocp[20] = a7;
  allocp[21] = x8 = makeref(&allocp[21]);
  allocp[22] = x3;
  a1 = x4;
  a3 = x5;
  a5 = x6;
  a7 = x7;
  a9 = x8;
  qp = (struct goalrec*)&allocp[9];
  allocp += 23;
  execute(prep__poss_10_0);
  goto prep__poss_10_ext_interrupt;
 set__args__for__newthread_10_ext_interrupt:
  reasonp = 0l;
 set__args__for__newthread_10_interrupt:
  toppred = &predicate_klic__comp__generate_xset__args__for__newthread_10;
  goto interrupt_10;
 }

 set__call__merge_3_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 set__call__merge_3_clear_reason:
  reasonp = reasons;
 set__call__merge_3_0:
 set__call__merge_3_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = car_of(a0);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(set__call__merge_3_0);
  goto set__call__merge_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto set__call__merge_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,set__call__merge_3_1);
  *reasonp++ =  a0;
  goto set__call__merge_3_interrupt;
  };
  goto set__call__merge_3_interrupt;
 set__call__merge_3_ext_interrupt:
  reasonp = 0l;
 set__call__merge_3_interrupt:
  goto interrupt_3;
 }

 enq__at__prio_12_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 enq__at__prio_12_clear_reason:
  reasonp = reasons;
 enq__at__prio_12_0:
 enq__at__prio_12_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_int_1)) goto enq__at__prio_12_2;
  unify3(a7, a6, a5, a4, a3, a2);
  x0 = a1;
  a1 = makesym(atom_int);
  a2 = a0;
  a3 = a8;
  a4 = a9;
  a5 = a10;
  a6 = a11;
  a0 = x0;
  execute(prio__code_7_0);
  goto prio__code_7_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,enq__at__prio_12_1);
  *reasonp++ =  a0;
  goto enq__at__prio_12_2;
  };
  goto enq__at__prio_12_2;
 enq__at__prio_12_2:
  otherwise(enq__at__prio_12_interrupt);
  allocp[0] = makesym(functor_r_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__generate_xprio__code_7);
  allocp[4] = a1;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = x0;
  allocp[7] = a8;
  allocp[8] = a9;
  allocp[9] = x3 = makeref(&allocp[9]);
  allocp[10] = a11;
  a1 = x1;
  x4 = a2;
  x5 = a3;
  x6 = a4;
  x7 = a5;
  x8 = a6;
  a8 = a7;
  a9 = a10;
  a10 = x3;
  a7 = x8;
  a6 = x7;
  a5 = x6;
  a4 = x5;
  a3 = x4;
  a2 = x2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 11;
  execute(load__reg_11_0);
  goto load__reg_11_ext_interrupt;
 enq__at__prio_12_ext_interrupt:
  reasonp = 0l;
 enq__at__prio_12_interrupt:
  goto interrupt_12;
 }

 prio__code_7_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 prio__code_7_clear_reason:
  reasonp = reasons;
 prio__code_7_0:
 prio__code_7_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto prio__code_7_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_abs)):
 prio__code_7_2:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_int)) goto prio__code_7_3;
  allocp[0] = makesym(functor_enq__at__prio__no__check_3);
  allocp[1] = a2;
  allocp[2] = a3;
  allocp[3] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[4] = a6;
  allocp[5] = x0;
  x1 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a5, x1);
  proceed();
 case VARREF:
  deref_and_jump(a1,prio__code_7_2);
  *reasonp++ =  a1;
  goto prio__code_7_interrupt;
  };
  goto prio__code_7_3;
 prio__code_7_3:
  gblt_diff(a1,makesym(atom_int),prio__code_7_interrupt);
  allocp[0] = makesym(functor_enq__at__prio_3);
  allocp[1] = a2;
  allocp[2] = a3;
  allocp[3] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[4] = a6;
  allocp[5] = x0;
  x1 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a5, x1);
  proceed();
 case symval(makesym(atom_rel)):
 prio__code_7_4:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_int)) goto prio__code_7_5;
  allocp[0] = makesym(functor_enq__at__lower__prio__no__check_3);
  allocp[1] = a2;
  allocp[2] = a3;
  allocp[3] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[4] = a6;
  allocp[5] = x0;
  x1 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a5, x1);
  proceed();
 case VARREF:
  deref_and_jump(a1,prio__code_7_4);
  *reasonp++ =  a1;
  goto prio__code_7_interrupt;
  };
  goto prio__code_7_5;
 prio__code_7_5:
  gblt_diff(a1,makesym(atom_int),prio__code_7_interrupt);
  allocp[0] = makesym(functor_enq__at__lower__prio_3);
  allocp[1] = a2;
  allocp[2] = a3;
  allocp[3] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[4] = a6;
  allocp[5] = x0;
  x1 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a5, x1);
  proceed();
  };
  goto prio__code_7_interrupt;
 case VARREF:
  deref_and_jump(a0,prio__code_7_1);
  *reasonp++ =  a0;
  goto prio__code_7_interrupt;
  };
  goto prio__code_7_interrupt;
 prio__code_7_ext_interrupt:
  reasonp = 0l;
 prio__code_7_interrupt:
  toppred = &predicate_klic__comp__generate_xprio__code_7;
  goto interrupt_7;
 }

 body__unify_12_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 body__unify_12_clear_reason:
  reasonp = reasons;
 body__unify_12_0:
 body__unify_12_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_var_1:
 body__unify_12_2:
  switch (ptagof(a1)) {
 case FUNCTOR:
  switch (symval(functor_of(a1))) {
 case functor_var_1:
  unify2(a9, a8, a7, a6);
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a2;
  x0 = makefunctor(&allocp[0]);
  bblt_add_no_check_y(a2,makeint(1L),x1);
  allocp += 2;
  unify(a3, x1);
  allocp[0] = makesym(functor_var_1);
  allocp[1] = arg(a0, 0);
  x2 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__24_3);
  allocp[3] = x2;
  allocp[4] = x0;
  allocp[5] = makesym(atom_any);
  x3 = makefunctor(&allocp[2]);
  allocp[6] = a4;
  allocp[7] = x3;
  x4 = makecons(&allocp[6]);
  allocp[8] = makesym(functor_var_1);
  allocp[9] = arg(a1, 0);
  x5 = makefunctor(&allocp[8]);
  allocp[10] = makesym(functor__24_3);
  allocp[11] = x5;
  allocp[12] = x0;
  allocp[13] = makesym(atom_any);
  x6 = makefunctor(&allocp[10]);
  allocp[14] = x4;
  allocp[15] = x6;
  x7 = makecons(&allocp[14]);
  allocp += 16;
  unify_value(a5, x7);
  allocp[0] = makesym(functor_alloc__var_2);
  allocp[1] = x0;
  allocp[2] = makeint(0L);
  x8 = makefunctor(&allocp[0]);
  allocp[3] = x10 = makeref(&allocp[3]);
  allocp[4] = x8;
  x9 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a10, x9);
  allocp[0] = a11;
  allocp[1] = makefunctor(funct_const_5);
  x11 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(x10, x11);
  proceed();
 case functor_var_2:
  unify2(a9, a8, a7, a6);
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a2;
  x0 = makefunctor(&allocp[0]);
  bblt_add_no_check_y(a2,makeint(1L),x1);
  allocp += 2;
  unify(a3, x1);
  allocp[0] = makesym(functor_var_1);
  allocp[1] = arg(a0, 0);
  x2 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__24_3);
  allocp[3] = x2;
  allocp[4] = x0;
  allocp[5] = makesym(atom_any);
  x3 = makefunctor(&allocp[2]);
  allocp[6] = a4;
  allocp[7] = x3;
  x4 = makecons(&allocp[6]);
  allocp[8] = makesym(functor_var_1);
  allocp[9] = arg(a1, 0);
  x5 = makefunctor(&allocp[8]);
  allocp[10] = makesym(functor__24_3);
  allocp[11] = x5;
  allocp[12] = x0;
  allocp[13] = makesym(atom_any);
  x6 = makefunctor(&allocp[10]);
  allocp[14] = x4;
  allocp[15] = x6;
  x7 = makecons(&allocp[14]);
  allocp += 16;
  unify_value(a5, x7);
  allocp[0] = makesym(functor_alloc__var_2);
  allocp[1] = x0;
  allocp[2] = makeint(0L);
  x8 = makefunctor(&allocp[0]);
  allocp[3] = x10 = makeref(&allocp[3]);
  allocp[4] = x8;
  x9 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a10, x9);
  allocp[0] = a11;
  allocp[1] = makefunctor(funct_const_5);
  x11 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(x10, x11);
  proceed();
  };
  goto body__unify_12_4;
 case VARREF:
  deref_and_jump(a1,body__unify_12_2);
  *reasonp++ =  a1;
  goto body__unify_12_4;
  };
  goto body__unify_12_4;
 case functor_var_2:
 body__unify_12_3:
  switch (ptagof(a1)) {
 case FUNCTOR:
  switch (symval(functor_of(a1))) {
 case functor_var_1:
  unify2(a9, a8, a7, a6);
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a2;
  x0 = makefunctor(&allocp[0]);
  bblt_add_no_check_y(a2,makeint(1L),x1);
  allocp += 2;
  unify(a3, x1);
  allocp[0] = makesym(functor_var_1);
  allocp[1] = arg(a0, 0);
  x2 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__24_3);
  allocp[3] = x2;
  allocp[4] = x0;
  allocp[5] = makesym(atom_any);
  x3 = makefunctor(&allocp[2]);
  allocp[6] = a4;
  allocp[7] = x3;
  x4 = makecons(&allocp[6]);
  allocp[8] = makesym(functor_var_1);
  allocp[9] = arg(a1, 0);
  x5 = makefunctor(&allocp[8]);
  allocp[10] = makesym(functor__24_3);
  allocp[11] = x5;
  allocp[12] = x0;
  allocp[13] = makesym(atom_any);
  x6 = makefunctor(&allocp[10]);
  allocp[14] = x4;
  allocp[15] = x6;
  x7 = makecons(&allocp[14]);
  allocp += 16;
  unify_value(a5, x7);
  allocp[0] = makesym(functor_alloc__var_2);
  allocp[1] = x0;
  allocp[2] = makeint(0L);
  x8 = makefunctor(&allocp[0]);
  allocp[3] = x10 = makeref(&allocp[3]);
  allocp[4] = x8;
  x9 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a10, x9);
  allocp[0] = a11;
  allocp[1] = makefunctor(funct_const_5);
  x11 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(x10, x11);
  proceed();
 case functor_var_2:
  unify2(a9, a8, a7, a6);
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a2;
  x0 = makefunctor(&allocp[0]);
  bblt_add_no_check_y(a2,makeint(1L),x1);
  allocp += 2;
  unify(a3, x1);
  allocp[0] = makesym(functor_var_1);
  allocp[1] = arg(a0, 0);
  x2 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__24_3);
  allocp[3] = x2;
  allocp[4] = x0;
  allocp[5] = makesym(atom_any);
  x3 = makefunctor(&allocp[2]);
  allocp[6] = a4;
  allocp[7] = x3;
  x4 = makecons(&allocp[6]);
  allocp[8] = makesym(functor_var_1);
  allocp[9] = arg(a1, 0);
  x5 = makefunctor(&allocp[8]);
  allocp[10] = makesym(functor__24_3);
  allocp[11] = x5;
  allocp[12] = x0;
  allocp[13] = makesym(atom_any);
  x6 = makefunctor(&allocp[10]);
  allocp[14] = x4;
  allocp[15] = x6;
  x7 = makecons(&allocp[14]);
  allocp += 16;
  unify_value(a5, x7);
  allocp[0] = makesym(functor_alloc__var_2);
  allocp[1] = x0;
  allocp[2] = makeint(0L);
  x8 = makefunctor(&allocp[0]);
  allocp[3] = x10 = makeref(&allocp[3]);
  allocp[4] = x8;
  x9 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a10, x9);
  allocp[0] = a11;
  allocp[1] = makefunctor(funct_const_5);
  x11 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(x10, x11);
  proceed();
  };
  goto body__unify_12_4;
 case VARREF:
  deref_and_jump(a1,body__unify_12_3);
  *reasonp++ =  a1;
  goto body__unify_12_4;
  };
  goto body__unify_12_4;
  };
  goto body__unify_12_4;
 case VARREF:
  deref_and_jump(a0,body__unify_12_1);
  *reasonp++ =  a0;
  goto body__unify_12_7;
  };
  goto body__unify_12_4;
 body__unify_12_4:
 body__unify_12_5:
  if (isref(a0)) goto body__unify_12_6;
  if_not_equal(a0, a1, body__unify_12_7);
  unify4(a11, a10, a9, a8, a7, a6, a5, a4);
  unify(a3, a2);
  proceed();
 body__unify_12_6:
  deref_and_jump(a0,body__unify_12_5);
  *reasonp++ =  a0;
  goto body__unify_12_7;
 body__unify_12_7:
  otherwise(body__unify_12_interrupt);
 body__unify_12_8:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_var_1:
  unify(a9, a8);
  allocp[0] = makesym(functor__24_3);
  allocp[1] = a0;
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = x2 = makeref(&allocp[3]);
  x0 = makefunctor(&allocp[0]);
  allocp[4] = a4;
  allocp[5] = x0;
  x3 = makecons(&allocp[4]);
  a0 = a1;
  a1 = x1;
  x4 = a2;
  a4 = a3;
  x5 = a5;
  x6 = a6;
  a8 = a7;
  a9 = a10;
  a10 = a11;
  a7 = x6;
  a6 = x5;
  a5 = x3;
  a3 = x4;
  a2 = x2;
  allocp += 6;
  execute(load__reg_11_0);
  goto load__reg_11_ext_interrupt;
 case functor_var_2:
  unify(a9, a8);
  allocp[0] = makesym(functor_var_1);
  allocp[1] = arg(a0, 0);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__24_3);
  allocp[3] = x0;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = x3 = makeref(&allocp[5]);
  x1 = makefunctor(&allocp[2]);
  allocp[6] = a4;
  allocp[7] = x1;
  x4 = makecons(&allocp[6]);
  a0 = a1;
  a1 = x2;
  x5 = a2;
  a4 = a3;
  x6 = a5;
  x7 = a6;
  a8 = a7;
  a9 = a10;
  a10 = a11;
  a7 = x7;
  a6 = x6;
  a5 = x4;
  a3 = x5;
  a2 = x3;
  allocp += 8;
  execute(load__reg_11_0);
  goto load__reg_11_ext_interrupt;
  };
  goto body__unify_12_9;
 case VARREF:
  deref_and_jump(a0,body__unify_12_8);
  *reasonp++ =  a0;
  goto body__unify_12_9;
  };
  goto body__unify_12_9;
 body__unify_12_9:
 body__unify_12_10:
  switch (ptagof(a1)) {
 case FUNCTOR:
  switch (symval(functor_of(a1))) {
 case functor_var_1:
  unify(a9, a8);
  allocp[0] = makesym(functor__24_3);
  allocp[1] = a1;
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = x2 = makeref(&allocp[3]);
  x0 = makefunctor(&allocp[0]);
  allocp[4] = a4;
  allocp[5] = x0;
  x3 = makecons(&allocp[4]);
  a1 = x1;
  x4 = a2;
  a4 = a3;
  x5 = a5;
  x6 = a6;
  a8 = a7;
  a9 = a10;
  a10 = a11;
  a7 = x6;
  a6 = x5;
  a5 = x3;
  a3 = x4;
  a2 = x2;
  allocp += 6;
  execute(load__reg_11_clear_reason);
  goto load__reg_11_ext_interrupt;
 case functor_var_2:
  unify(a9, a8);
  allocp[0] = makesym(functor_var_1);
  allocp[1] = arg(a1, 0);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__24_3);
  allocp[3] = x0;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = x3 = makeref(&allocp[5]);
  x1 = makefunctor(&allocp[2]);
  allocp[6] = a4;
  allocp[7] = x1;
  x4 = makecons(&allocp[6]);
  a1 = x2;
  x5 = a2;
  a4 = a3;
  x6 = a5;
  x7 = a6;
  a8 = a7;
  a9 = a10;
  a10 = a11;
  a7 = x7;
  a6 = x6;
  a5 = x4;
  a3 = x5;
  a2 = x3;
  allocp += 8;
  execute(load__reg_11_clear_reason);
  goto load__reg_11_ext_interrupt;
  };
  goto body__unify_12_11;
 case VARREF:
  deref_and_jump(a1,body__unify_12_10);
  *reasonp++ =  a1;
  goto body__unify_12_11;
  };
  goto body__unify_12_11;
 body__unify_12_11:
  otherwise(body__unify_12_interrupt);
  unify_value(a9, makesym(atom_qp));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xbody__unify__1_11);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a8;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a3;
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = a5;
  allocp[9] = x4 = makeref(&allocp[9]);
  allocp[10] = a7;
  allocp[11] = x5 = makeref(&allocp[11]);
  allocp[12] = a11;
  allocp[13] = (q)(struct goalrec*)&allocp[0];
  allocp[14] = (q)(&predicate_klic__comp__generate_xprep__call__arg_10);
  allocp[15] = a1;
  allocp[16] = x1;
  allocp[17] = x6 = makeref(&allocp[17]);
  allocp[18] = x2;
  allocp[19] = x7 = makeref(&allocp[19]);
  allocp[20] = x3;
  allocp[21] = x8 = makeref(&allocp[21]);
  allocp[22] = x4;
  allocp[23] = x9 = makeref(&allocp[23]);
  allocp[24] = x5;
  a1 = x0;
  a3 = x6;
  a5 = x7;
  a7 = x8;
  a8 = a10;
  a9 = x9;
  qp = (struct goalrec*)&allocp[13];
  allocp += 25;
  execute(prep__call__arg_10_0);
  goto prep__call__arg_10_ext_interrupt;
 body__unify_12_ext_interrupt:
  reasonp = 0l;
 body__unify_12_interrupt:
  goto interrupt_12;
 }

 body__unify__1_11_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 body__unify__1_11_clear_reason:
  reasonp = reasons;
 body__unify__1_11_0:
 body__unify__1_11_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor__3A_2)) goto body__unify__1_11_3;
 body__unify__1_11_2:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor__3A_2)) goto body__unify__1_11_3;
  unify3(a8, a7, a6, a5, a4, a3);
  x0 = arg(a0, 0);
  x1 = arg(a0, 1);
  x2 = arg(a1, 0);
  a3 = arg(a1, 1);
  a4 = a2;
  a5 = a9;
  a6 = a10;
  a2 = x2;
  a1 = x1;
  a0 = x0;
  execute(body__unify__2_7_0);
  goto body__unify__2_7_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,body__unify__1_11_2);
  *reasonp++ =  a1;
  goto body__unify__1_11_3;
  };
  goto body__unify__1_11_3;
 case VARREF:
  deref_and_jump(a0,body__unify__1_11_1);
  *reasonp++ =  a0;
  goto body__unify__1_11_3;
  };
  goto body__unify__1_11_3;
 body__unify__1_11_3:
  otherwise(body__unify__1_11_interrupt);
 body__unify__1_11_4:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor__3A_2)) goto body__unify__1_11_5;
  unify3(a8, a7, a6, a5, a4, a3);
  x0 = makesym(atom_known);
  x1 = arg(a0, 0);
  x2 = arg(a0, 1);
  x3 = a1;
  a3 = x0;
  a4 = a2;
  a5 = a9;
  a6 = a10;
  a2 = x3;
  a1 = x2;
  a0 = x1;
  execute(body__unify__2_7_0);
  goto body__unify__2_7_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,body__unify__1_11_4);
  *reasonp++ =  a0;
  goto body__unify__1_11_5;
  };
  goto body__unify__1_11_5;
 body__unify__1_11_5:
 body__unify__1_11_6:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor__3A_2)) goto body__unify__1_11_7;
  unify3(a8, a7, a6, a5, a4, a3);
  x0 = makesym(atom_known);
  x1 = arg(a1, 0);
  a3 = arg(a1, 1);
  a4 = a2;
  a5 = a9;
  a6 = a10;
  a2 = x1;
  a1 = x0;
  execute(body__unify__2_7_clear_reason);
  goto body__unify__2_7_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,body__unify__1_11_6);
  *reasonp++ =  a1;
  goto body__unify__1_11_7;
  };
  goto body__unify__1_11_7;
 body__unify__1_11_7:
  otherwise(body__unify__1_11_interrupt);
  allocp[0] = makesym(functor_r_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__3A_2);
  allocp[3] = x0;
  allocp[4] = x3 = makeref(&allocp[4]);
  x2 = makefunctor(&allocp[2]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_klic__comp__generate_xbody__unify__1_11);
  allocp[7] = x2;
  allocp[8] = a1;
  allocp[9] = a2;
  allocp[10] = x4 = makeref(&allocp[10]);
  allocp[11] = a4;
  allocp[12] = x5 = makeref(&allocp[12]);
  allocp[13] = a6;
  allocp[14] = x6 = makeref(&allocp[14]);
  allocp[15] = a8;
  allocp[16] = x7 = makeref(&allocp[16]);
  allocp[17] = a10;
  a1 = x1;
  a2 = x3;
  a4 = x4;
  a6 = x5;
  a8 = x6;
  a10 = x7;
  qp = (struct goalrec*)&allocp[5];
  allocp += 18;
  execute(load__reg_11_0);
  goto load__reg_11_ext_interrupt;
 body__unify__1_11_ext_interrupt:
  reasonp = 0l;
 body__unify__1_11_interrupt:
  goto interrupt_11;
 }

 body__unify__2_7_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 body__unify__2_7_clear_reason:
  reasonp = reasons;
 body__unify__2_7_0:
 body__unify__2_7_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_any)) goto body__unify__2_7_3;
 body__unify__2_7_2:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_any)) goto body__unify__2_7_3;
  allocp[0] = makesym(functor_unify_3);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[4] = a6;
  allocp[5] = x0;
  x1 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a5, x1);
  proceed();
 case VARREF:
  deref_and_jump(a3,body__unify__2_7_2);
  *reasonp++ =  a3;
  goto body__unify__2_7_3;
  };
  goto body__unify__2_7_3;
 case VARREF:
  deref_and_jump(a1,body__unify__2_7_1);
  *reasonp++ =  a1;
  goto body__unify__2_7_3;
  };
  goto body__unify__2_7_3;
 body__unify__2_7_3:
  otherwise(body__unify__2_7_interrupt);
 body__unify__2_7_4:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_any)) goto body__unify__2_7_5;
  allocp[0] = makesym(functor_unify__value_3);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[4] = a6;
  allocp[5] = x0;
  x1 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a5, x1);
  proceed();
 case VARREF:
  deref_and_jump(a1,body__unify__2_7_4);
  *reasonp++ =  a1;
  goto body__unify__2_7_5;
  };
  goto body__unify__2_7_5;
 body__unify__2_7_5:
 body__unify__2_7_6:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_any)) goto body__unify__2_7_7;
  allocp[0] = makesym(functor_unify__value_3);
  allocp[1] = a2;
  allocp[2] = a0;
  allocp[3] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[4] = a6;
  allocp[5] = x0;
  x1 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a5, x1);
  proceed();
 case VARREF:
  deref_and_jump(a3,body__unify__2_7_6);
  *reasonp++ =  a3;
  goto body__unify__2_7_7;
  };
  goto body__unify__2_7_7;
 body__unify__2_7_7:
  otherwise(body__unify__2_7_interrupt);
  allocp[0] = makesym(functor_unify_3);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[4] = a6;
  allocp[5] = x0;
  x1 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a5, x1);
  proceed();
 body__unify__2_7_ext_interrupt:
  reasonp = 0l;
 body__unify__2_7_interrupt:
  toppred = &predicate_klic__comp__generate_xbody__unify__2_7;
  goto interrupt_7;
 }

 bb__in_14_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  qp = qp->next;
 bb__in_14_clear_reason:
  reasonp = reasons;
 bb__in_14_0:
 bb__in_14_1:
  switch (ptagof(a0)) {
 case CONS:
 bb__in_14_2:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = x2 = makeref(&allocp[1]);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a5, x0);
  bblt_add_no_check_y(a3,makeint(1L),x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xbb__in_14);
  x4 = cdr_of(a0);
  allocp[2] = x4;
  x5 = cdr_of(a1);
  allocp[3] = x5;
  allocp[4] = a2;
  allocp[5] = x3;
  allocp[6] = x6 = makeref(&allocp[6]);
  allocp[7] = x1;
  allocp[8] = x7 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x8 = makeref(&allocp[10]);
  allocp[11] = a9;
  allocp[12] = x9 = makeref(&allocp[12]);
  allocp[13] = a11;
  allocp[14] = x10 = makeref(&allocp[14]);
  allocp[15] = a13;
  allocp[16] = (q)(struct goalrec*)&allocp[0];
  allocp[17] = (q)(&predicate_klic__comp__generate_xbb__in__check_4);
  allocp[18] = x11 = makeref(&allocp[18]);
  allocp[19] = a3;
  allocp[20] = x6;
  allocp[21] = a4;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_klic__comp__insert_xsubsumed__type_3);
  allocp[24] = x12 = makeref(&allocp[24]);
  x13 = car_of(a0);
  allocp[25] = x13;
  allocp[26] = x11;
  allocp[27] = (q)(struct goalrec*)&allocp[22];
  allocp[28] = (q)(&predicate_klic__comp__generate_xbb__in__type_3);
  allocp[29] = x14 = makeref(&allocp[29]);
  allocp[30] = x2;
  allocp[31] = x12;
  a0 = car_of(a1);
  a1 = x14;
  a2 = a6;
  a3 = x7;
  a4 = a8;
  a5 = x8;
  a6 = a10;
  a7 = x9;
  a8 = a12;
  a9 = x10;
  qp = (struct goalrec*)&allocp[27];
  allocp += 32;
  execute(prep__call__arg_10_0);
  goto prep__call__arg_10_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,bb__in_14_2);
  *reasonp++ =  a1;
  goto bb__in_14_interrupt;
  };
  goto bb__in_14_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto bb__in_14_interrupt;
  unify4(a13, a12, a11, a10, a9, a8, a7, a6);
  unify_value(a4, NILATOM);
  unify_value(a5, NILATOM);
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,bb__in_14_1);
  *reasonp++ =  a0;
  goto bb__in_14_interrupt;
  };
  goto bb__in_14_interrupt;
 bb__in_14_ext_interrupt:
  reasonp = 0l;
 bb__in_14_interrupt:
  goto interrupt_14;
 }

 bb__in__type_3_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 bb__in__type_3_clear_reason:
  reasonp = reasons;
 bb__in__type_3_0:
 bb__in__type_3_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor__3A_2)) goto bb__in__type_3_2;
  x0 = arg(a0, 0);
  unify(a1, x0);
  x1 = arg(a0, 1);
  unify(a2, x1);
  proceed();
 case VARREF:
  deref_and_jump(a0,bb__in__type_3_1);
  *reasonp++ =  a0;
  goto bb__in__type_3_2;
  };
  goto bb__in__type_3_2;
 bb__in__type_3_2:
  otherwise(bb__in__type_3_interrupt);
  unify2(a1, a0, a2, a0);
  proceed();
 bb__in__type_3_ext_interrupt:
  reasonp = 0l;
 bb__in__type_3_interrupt:
  goto interrupt_3;
 }

 bb__in__check_4_top: {
  q x0;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 bb__in__check_4_clear_reason:
  reasonp = reasons;
 bb__in__check_4_0:
 bb__in__check_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto bb__in__check_4_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_normal)):
  unify(a3, a2);
  proceed();
 case symval(makesym(atom_abnormal)):
  allocp[0] = a2;
  allocp[1] = a1;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a3, x0);
  proceed();
  };
  goto bb__in__check_4_interrupt;
 case VARREF:
  deref_and_jump(a0,bb__in__check_4_1);
  *reasonp++ =  a0;
  goto bb__in__check_4_interrupt;
  };
  goto bb__in__check_4_interrupt;
 bb__in__check_4_ext_interrupt:
  reasonp = 0l;
 bb__in__check_4_interrupt:
  goto interrupt_4;
 }

 bb__out_14_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  qp = qp->next;
 bb__out_14_clear_reason:
  reasonp = reasons;
 bb__out_14_0:
 bb__out_14_1:
  switch (ptagof(a0)) {
 case CONS:
 bb__out_14_2:
  switch (ptagof(a2)) {
 case CONS:
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a4;
  x0 = makefunctor(&allocp[0]);
  bblt_add_no_check_y(a4,makeint(1L),x1);
  allocp[2] = makesym(functor_r_1);
  allocp[3] = x0;
  x2 = makefunctor(&allocp[2]);
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = x2;
  x3 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a3, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xbb__out_14);
  x5 = cdr_of(a0);
  allocp[2] = x5;
  allocp[3] = a1;
  x6 = cdr_of(a2);
  allocp[4] = x6;
  allocp[5] = x4;
  allocp[6] = x7 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x8 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x9 = makeref(&allocp[10]);
  allocp[11] = a9;
  allocp[12] = x10 = makeref(&allocp[12]);
  allocp[13] = a11;
  allocp[14] = x11 = makeref(&allocp[14]);
  allocp[15] = a13;
  allocp[16] = makesym(functor__3A_2);
  allocp[17] = x2;
  allocp[18] = x13 = makeref(&allocp[18]);
  x12 = makefunctor(&allocp[16]);
  allocp[19] = (q)(struct goalrec*)&allocp[0];
  allocp[20] = (q)(&predicate_klic__comp__generate_xbody__unify_12);
  x14 = car_of(a0);
  allocp[21] = x14;
  allocp[22] = x12;
  allocp[23] = x1;
  allocp[24] = x7;
  allocp[25] = a6;
  allocp[26] = x8;
  allocp[27] = a8;
  allocp[28] = x9;
  allocp[29] = a10;
  allocp[30] = x10;
  allocp[31] = a12;
  allocp[32] = x11;
  a0 = a1;
  a1 = car_of(a2);
  a2 = x13;
  qp = (struct goalrec*)&allocp[19];
  allocp += 33;
  execute(bb__out__type_3_0);
  goto bb__out__type_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,bb__out_14_2);
  *reasonp++ =  a2;
  goto bb__out_14_interrupt;
  };
  goto bb__out_14_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto bb__out_14_interrupt;
 bb__out_14_3:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != NILATOM) goto bb__out_14_interrupt;
  unify4(a13, a12, a11, a10, a9, a8, a7, a6);
  unify(a5, a4);
  unify_value(a3, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a2,bb__out_14_3);
  *reasonp++ =  a2;
  goto bb__out_14_interrupt;
  };
  goto bb__out_14_interrupt;
 case VARREF:
  deref_and_jump(a0,bb__out_14_1);
  *reasonp++ =  a0;
  goto bb__out_14_interrupt;
  };
  goto bb__out_14_interrupt;
 bb__out_14_ext_interrupt:
  reasonp = 0l;
 bb__out_14_interrupt:
  goto interrupt_14;
 }

 bb__out__type_3_top: {
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 bb__out__type_3_clear_reason:
  reasonp = reasons;
 bb__out__type_3_0:
 bb__out__type_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != NILATOM) goto bb__out__type_3_2;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,bb__out__type_3_1);
  *reasonp++ =  a0;
  goto bb__out__type_3_interrupt;
  };
  goto bb__out__type_3_2;
 bb__out__type_3_2:
  gblt_diff(a0,NILATOM,bb__out__type_3_interrupt);
  unify_value(a2, makesym(atom_any));
  proceed();
 bb__out__type_3_ext_interrupt:
  reasonp = 0l;
 bb__out__type_3_interrupt:
  toppred = &predicate_klic__comp__generate_xbb__out__type_3;
  goto interrupt_3;
 }

 prep__call__arg_10_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 prep__call__arg_10_clear_reason:
  reasonp = reasons;
 prep__call__arg_10_0:
 prep__call__arg_10_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_var_1:
  allocp[0] = makesym(functor_r_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__3A_2);
  allocp[3] = x0;
  allocp[4] = x3 = makeref(&allocp[4]);
  x2 = makefunctor(&allocp[2]);
  allocp += 5;
  unify_value(a1, x2);
  a1 = x1;
  x4 = a2;
  x5 = a3;
  x6 = a4;
  x7 = a5;
  x8 = a6;
  x9 = a7;
  x10 = a8;
  a10 = a9;
  a9 = x10;
  a8 = x9;
  a7 = x8;
  a6 = x7;
  a5 = x6;
  a4 = x5;
  a3 = x4;
  a2 = x3;
  execute(load__reg_11_0);
  goto load__reg_11_ext_interrupt;
 case functor_arg_2:
  allocp[0] = makesym(functor_r_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__3A_2);
  allocp[3] = x0;
  allocp[4] = x3 = makeref(&allocp[4]);
  x2 = makefunctor(&allocp[2]);
  allocp += 5;
  unify_value(a1, x2);
  a1 = x1;
  x4 = a2;
  x5 = a3;
  x6 = a4;
  x7 = a5;
  x8 = a6;
  x9 = a7;
  x10 = a8;
  a10 = a9;
  a9 = x10;
  a8 = x9;
  a7 = x8;
  a6 = x7;
  a5 = x6;
  a4 = x5;
  a3 = x4;
  a2 = x3;
  execute(load__reg_11_0);
  goto load__reg_11_ext_interrupt;
 case functor_var_2:
  allocp[0] = makesym(functor_r_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = arg(a0, 1);
  allocp[3] = x3 = makeref(&allocp[3]);
  x2 = makecons(&allocp[2]);
  allocp[4] = makesym(functor__3A_2);
  allocp[5] = x0;
  allocp[6] = x2;
  x4 = makefunctor(&allocp[4]);
  allocp += 7;
  unify_value(a1, x4);
  a1 = x1;
  x5 = a2;
  x6 = a3;
  x7 = a4;
  x8 = a5;
  x9 = a6;
  x10 = a7;
  x11 = a8;
  a10 = a9;
  a9 = x11;
  a8 = x10;
  a7 = x9;
  a6 = x8;
  a5 = x7;
  a4 = x6;
  a3 = x5;
  a2 = x3;
  execute(load__reg_11_0);
  goto load__reg_11_ext_interrupt;
 case functor_arg_3:
  allocp[0] = makesym(functor_r_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = arg(a0, 2);
  allocp[3] = x3 = makeref(&allocp[3]);
  x2 = makecons(&allocp[2]);
  allocp[4] = makesym(functor__3A_2);
  allocp[5] = x0;
  allocp[6] = x2;
  x4 = makefunctor(&allocp[4]);
  allocp += 7;
  unify_value(a1, x4);
  a1 = x1;
  x5 = a2;
  x6 = a3;
  x7 = a4;
  x8 = a5;
  x9 = a6;
  x10 = a7;
  x11 = a8;
  a10 = a9;
  a9 = x11;
  a8 = x10;
  a7 = x9;
  a6 = x8;
  a5 = x7;
  a4 = x6;
  a3 = x5;
  a2 = x3;
  execute(load__reg_11_0);
  goto load__reg_11_ext_interrupt;
  };
  goto prep__call__arg_10_2;
 case VARREF:
  deref_and_jump(a0,prep__call__arg_10_1);
  *reasonp++ =  a0;
  goto prep__call__arg_10_2;
  };
  goto prep__call__arg_10_2;
 prep__call__arg_10_2:
  otherwise(prep__call__arg_10_interrupt);
  unify4(a9, a8, a7, a6, a5, a4, a3, a2);
  unify(a1, a0);
  proceed();
 prep__call__arg_10_ext_interrupt:
  reasonp = 0l;
 prep__call__arg_10_interrupt:
  toppred = &predicate_klic__comp__generate_xprep__call__arg_10;
  goto interrupt_10;
 }

 set__args_10_top: {
  q x0, x1, x2, x3, x4, x5;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 set__args_10_clear_reason:
  reasonp = reasons;
 set__args_10_0:
 set__args_10_1:
  switch (ptagof(a0)) {
 case CONS:
  bblt_add_no_check_y(a1,makeint(1L),x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xset__args_10);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x0;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x5 = makeref(&allocp[10]);
  allocp[11] = a9;
  a0 = car_of(a0);
  a3 = x2;
  a5 = x3;
  a7 = x4;
  a9 = x5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  execute(set__one_10_0);
  goto set__one_10_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto set__args_10_interrupt;
  unify4(a9, a8, a7, a6, a5, a4, a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,set__args_10_1);
  *reasonp++ =  a0;
  goto set__args_10_interrupt;
  };
  goto set__args_10_interrupt;
 set__args_10_ext_interrupt:
  reasonp = 0l;
 set__args_10_interrupt:
  goto interrupt_10;
 }

 set__one_10_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 set__one_10_clear_reason:
  reasonp = reasons;
 set__one_10_0:
 set__one_10_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor__3A_2)) goto set__one_10_3;
  x0 = arg(a0, 0);
 set__one_10_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_r_1)) goto set__one_10_3;
  unify3(a7, a6, a5, a4, a3, a2);
  allocp[0] = makesym(functor_set__value_2);
  allocp[1] = a1;
  allocp[2] = arg(x0, 0);
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a9;
  allocp[4] = x1;
  x2 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a8, x2);
  proceed();
 case VARREF:
  deref_and_jump(x0,set__one_10_2);
  *reasonp++ =  x0;
  goto set__one_10_3;
  };
  goto set__one_10_3;
 case VARREF:
  deref_and_jump(a0,set__one_10_1);
  *reasonp++ =  a0;
  goto set__one_10_3;
  };
  goto set__one_10_3;
 set__one_10_3:
  otherwise(set__one_10_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xset__one__1_10);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  x1 = a4;
  a1 = a0;
  a2 = x0;
  a0 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  execute(assocx_3_0);
  goto assocx_3_ext_interrupt;
 set__one_10_ext_interrupt:
  reasonp = 0l;
 set__one_10_interrupt:
  toppred = &predicate_klic__comp__generate_xset__one_10;
  goto interrupt_10;
 }

 set__one__1_10_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 set__one__1_10_clear_reason:
  reasonp = reasons;
 set__one__1_10_0:
 set__one__1_10_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_yes_2:
  allocp[0] = makesym(functor_r_1);
  allocp[1] = arg(a0, 0);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__3A_2);
  allocp[3] = x0;
  allocp[4] = arg(a0, 1);
  x1 = makefunctor(&allocp[2]);
  a0 = x1;
  allocp += 5;
  execute(set__one_10_0);
  goto set__one_10_ext_interrupt;
 case functor_no_1:
  x0 = arg(a0, 0);
 set__one__1_10_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_atom_1:
  unify3(a7, a6, a5, a4, a3, a2);
  allocp[0] = makesym(functor_set__const_2);
  allocp[1] = a1;
  allocp[2] = x0;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a9;
  allocp[4] = x1;
  x2 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a8, x2);
  proceed();
 case functor_int_1:
  unify3(a7, a6, a5, a4, a3, a2);
  allocp[0] = makesym(functor_set__const_2);
  allocp[1] = a1;
  allocp[2] = x0;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a9;
  allocp[4] = x1;
  x2 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a8, x2);
  proceed();
 case functor_const_1:
  unify3(a7, a6, a5, a4, a3, a2);
  allocp[0] = makesym(functor_set__const_2);
  allocp[1] = a1;
  allocp[2] = x0;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a9;
  allocp[4] = x1;
  x2 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a8, x2);
  proceed();
 case functor_arg_2:
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a2;
  x1 = makefunctor(&allocp[0]);
  bblt_add_no_check_y(a2,makeint(1L),x2);
  allocp[2] = makesym(functor__24_3);
  allocp[3] = x0;
  allocp[4] = x1;
  allocp[5] = makesym(atom_any);
  x3 = makefunctor(&allocp[2]);
  allocp[6] = a4;
  allocp[7] = x3;
  x4 = makecons(&allocp[6]);
  allocp[8] = makesym(functor_set__value_2);
  allocp[9] = a1;
  allocp[10] = x1;
  x5 = makefunctor(&allocp[8]);
  allocp[11] = a9;
  allocp[12] = x5;
  x6 = makecons(&allocp[11]);
  allocp[13] = makesym(functor_get__elem_3);
  allocp[14] = x1;
  allocp[15] = x8 = makeref(&allocp[15]);
  allocp[16] = arg(x0, 1);
  x7 = makefunctor(&allocp[13]);
  allocp[17] = x6;
  allocp[18] = x7;
  x9 = makecons(&allocp[17]);
  a0 = arg(x0, 0);
  a1 = x8;
  a2 = x2;
  a4 = x4;
  a9 = x9;
  allocp += 19;
  execute(load__pos_10_0);
  goto load__pos_10_ext_interrupt;
 case functor_arg_3:
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a2;
  x1 = makefunctor(&allocp[0]);
  bblt_add_no_check_y(a2,makeint(1L),x2);
  allocp[2] = makesym(functor__24_3);
  allocp[3] = x0;
  allocp[4] = x1;
  allocp[5] = makesym(atom_any);
  x3 = makefunctor(&allocp[2]);
  allocp[6] = a4;
  allocp[7] = x3;
  x4 = makecons(&allocp[6]);
  allocp[8] = makesym(functor_set__value_3);
  allocp[9] = a1;
  allocp[10] = x1;
  allocp[11] = arg(x0, 2);
  x5 = makefunctor(&allocp[8]);
  allocp[12] = a9;
  allocp[13] = x5;
  x6 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_get__elem_3);
  allocp[15] = x1;
  allocp[16] = x8 = makeref(&allocp[16]);
  allocp[17] = arg(x0, 1);
  x7 = makefunctor(&allocp[14]);
  allocp[18] = x6;
  allocp[19] = x7;
  x9 = makecons(&allocp[18]);
  a0 = arg(x0, 0);
  a1 = x8;
  a2 = x2;
  a4 = x4;
  a9 = x9;
  allocp += 20;
  execute(load__pos_10_0);
  goto load__pos_10_ext_interrupt;
 case functor_var_1:
  unify(a7, a6);
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a2;
  x1 = makefunctor(&allocp[0]);
  bblt_add_no_check_y(a2,makeint(1L),x2);
  allocp += 2;
  unify(a3, x2);
  allocp[0] = makesym(functor__24_3);
  allocp[1] = x0;
  allocp[2] = x1;
  allocp[3] = makesym(atom_any);
  x3 = makefunctor(&allocp[0]);
  allocp[4] = a4;
  allocp[5] = x3;
  x4 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a5, x4);
  allocp[0] = makesym(functor_set__newvar_2);
  allocp[1] = a1;
  allocp[2] = x1;
  x5 = makefunctor(&allocp[0]);
  allocp[3] = a9;
  allocp[4] = x5;
  x6 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a8, x6);
  proceed();
 case functor_var_2:
  unify(a7, a6);
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a2;
  x1 = makefunctor(&allocp[0]);
  bblt_add_no_check_y(a2,makeint(1L),x2);
  allocp += 2;
  unify(a3, x2);
  allocp[0] = makesym(functor_var_1);
  allocp[1] = arg(x0, 0);
  x3 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__24_3);
  allocp[3] = x3;
  allocp[4] = x1;
  allocp[5] = makesym(atom_any);
  x4 = makefunctor(&allocp[2]);
  allocp[6] = a4;
  allocp[7] = x4;
  x5 = makecons(&allocp[6]);
  allocp += 8;
  unify_value(a5, x5);
  allocp[0] = makesym(functor_set__newvar_3);
  allocp[1] = a1;
  allocp[2] = x1;
  allocp[3] = arg(x0, 1);
  x6 = makefunctor(&allocp[0]);
  allocp[4] = a9;
  allocp[5] = x6;
  x7 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a8, x7);
  proceed();
  };
  goto set__one__1_10_interrupt;
 case VARREF:
  deref_and_jump(x0,set__one__1_10_2);
  *reasonp++ =  x0;
  goto set__one__1_10_interrupt;
  };
  goto set__one__1_10_interrupt;
  };
  goto set__one__1_10_interrupt;
 case VARREF:
  deref_and_jump(a0,set__one__1_10_1);
  *reasonp++ =  a0;
  goto set__one__1_10_interrupt;
  };
  goto set__one__1_10_interrupt;
 set__one__1_10_ext_interrupt:
  reasonp = 0l;
 set__one__1_10_interrupt:
  goto interrupt_10;
 }

 make__var_7_top: {
  q x0;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 make__var_7_clear_reason:
  reasonp = reasons;
 make__var_7_0:
 make__var_7_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != NILATOM) goto make__var_7_interrupt;
  unify2(a6, a5, a4, a3);
  allocp[0] = x0 = makeref(&allocp[0]);
  allocp += 1;
  proceed();
 case VARREF:
  deref_and_jump(a0,make__var_7_1);
  *reasonp++ =  a0;
  goto make__var_7_interrupt;
  };
  goto make__var_7_interrupt;
 make__var_7_ext_interrupt:
  reasonp = 0l;
 make__var_7_interrupt:
  goto interrupt_7;
 }

 put__args_12_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 put__args_12_clear_reason:
  reasonp = reasons;
 put__args_12_0:
 put__args_12_1:
  switch (ptagof(a0)) {
 case CONS:
  bblt_add_no_check_y(a1,makeint(1L),x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xput__args_12);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x0;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x5 = makeref(&allocp[10]);
  allocp[11] = a9;
  allocp[12] = x6 = makeref(&allocp[12]);
  allocp[13] = a11;
  a0 = car_of(a0);
  a3 = x2;
  a5 = x3;
  a7 = x4;
  a9 = x5;
  a11 = x6;
  qp = (struct goalrec*)&allocp[0];
  allocp += 14;
  execute(put__one_12_0);
  goto put__one_12_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto put__args_12_interrupt;
  unify4(a11, a10, a9, a8, a7, a6, a5, a4);
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,put__args_12_1);
  *reasonp++ =  a0;
  goto put__args_12_interrupt;
  };
  goto put__args_12_interrupt;
 put__args_12_ext_interrupt:
  reasonp = 0l;
 put__args_12_interrupt:
  goto interrupt_12;
 }

 put__one_12_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 put__one_12_clear_reason:
  reasonp = reasons;
 put__one_12_0:
 put__one_12_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor__3A_2)) goto put__one_12_3;
  x0 = arg(a0, 0);
 put__one_12_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_r_1)) goto put__one_12_3;
  unify4(a9, a8, a7, a6, a5, a4, a3, a2);
  allocp[0] = makesym(functor_put__value_2);
  allocp[1] = a1;
  allocp[2] = arg(x0, 0);
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a11;
  allocp[4] = x1;
  x2 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a10, x2);
  proceed();
 case VARREF:
  deref_and_jump(x0,put__one_12_2);
  *reasonp++ =  x0;
  goto put__one_12_3;
  };
  goto put__one_12_3;
 case VARREF:
  deref_and_jump(a0,put__one_12_1);
  *reasonp++ =  a0;
  goto put__one_12_3;
  };
  goto put__one_12_3;
 put__one_12_3:
  otherwise(put__one_12_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xput__one__1_12);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  allocp[12] = a10;
  allocp[13] = a11;
  x1 = a6;
  a1 = a0;
  a2 = x0;
  a0 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 14;
  execute(assocx_3_0);
  goto assocx_3_ext_interrupt;
 put__one_12_ext_interrupt:
  reasonp = 0l;
 put__one_12_interrupt:
  toppred = &predicate_klic__comp__generate_xput__one_12;
  goto interrupt_12;
 }

 put__one__1_12_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 put__one__1_12_clear_reason:
  reasonp = reasons;
 put__one__1_12_0:
 put__one__1_12_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_yes_2:
  allocp[0] = makesym(functor_r_1);
  allocp[1] = arg(a0, 0);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__3A_2);
  allocp[3] = x0;
  allocp[4] = arg(a0, 1);
  x1 = makefunctor(&allocp[2]);
  a0 = x1;
  allocp += 5;
  execute(put__one_12_0);
  goto put__one_12_ext_interrupt;
 case functor_no_1:
  x0 = arg(a0, 0);
 put__one__1_12_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_atom_1:
  unify4(a9, a8, a7, a6, a5, a4, a3, a2);
  allocp[0] = makesym(functor_put__const_2);
  allocp[1] = a1;
  allocp[2] = x0;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a11;
  allocp[4] = x1;
  x2 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a10, x2);
  proceed();
 case functor_int_1:
  unify4(a9, a8, a7, a6, a5, a4, a3, a2);
  allocp[0] = makesym(functor_put__const_2);
  allocp[1] = a1;
  allocp[2] = x0;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a11;
  allocp[4] = x1;
  x2 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a10, x2);
  proceed();
 case functor_const_1:
  unify4(a9, a8, a7, a6, a5, a4, a3, a2);
  allocp[0] = makesym(functor_put__const_2);
  allocp[1] = a1;
  allocp[2] = x0;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a11;
  allocp[4] = x1;
  x2 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a10, x2);
  proceed();
 case functor_arg_2:
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a4;
  x1 = makefunctor(&allocp[0]);
  bblt_add_no_check_y(a4,makeint(1L),x2);
  allocp[2] = makesym(functor__24_3);
  allocp[3] = x0;
  allocp[4] = x1;
  allocp[5] = makesym(atom_any);
  x3 = makefunctor(&allocp[2]);
  allocp[6] = a6;
  allocp[7] = x3;
  x4 = makecons(&allocp[6]);
  allocp[8] = makesym(functor_put__value_2);
  allocp[9] = a1;
  allocp[10] = x1;
  x5 = makefunctor(&allocp[8]);
  allocp[11] = a11;
  allocp[12] = x5;
  x6 = makecons(&allocp[11]);
  allocp += 13;
  unify(a3, a2);
  allocp[0] = makesym(functor_get__elem_3);
  allocp[1] = x1;
  allocp[2] = x8 = makeref(&allocp[2]);
  allocp[3] = arg(x0, 1);
  x7 = makefunctor(&allocp[0]);
  allocp[4] = x6;
  allocp[5] = x7;
  x9 = makecons(&allocp[4]);
  a0 = arg(x0, 0);
  a1 = x8;
  a2 = x2;
  a3 = a5;
  a4 = x4;
  a5 = a7;
  a6 = a8;
  a7 = a9;
  a8 = a10;
  a9 = x9;
  allocp += 6;
  execute(load__pos_10_0);
  goto load__pos_10_ext_interrupt;
 case functor_arg_3:
  x1 = arg(x0, 2);
 put__one__1_12_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (isint(x1)) goto put__one__1_12_interrupt;
  switch (symval(x1)) {
 case symval(makesym(atom_o)):
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a4;
  x2 = makefunctor(&allocp[0]);
  bblt_add_no_check_y(a4,makeint(1L),x3);
  allocp[2] = makesym(functor__24_3);
  allocp[3] = x0;
  allocp[4] = x2;
  allocp[5] = makesym(atom_any);
  x4 = makefunctor(&allocp[2]);
  allocp[6] = a6;
  allocp[7] = x4;
  x5 = makecons(&allocp[6]);
  allocp[8] = makesym(functor_put__value_4);
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = x2;
  allocp[12] = makesym(atom_o);
  x6 = makefunctor(&allocp[8]);
  allocp[13] = a11;
  allocp[14] = x6;
  x7 = makecons(&allocp[13]);
  allocp += 15;
  unify(a3, a2);
  allocp[0] = makesym(functor_get__elem_3);
  allocp[1] = x2;
  allocp[2] = x9 = makeref(&allocp[2]);
  allocp[3] = arg(x0, 1);
  x8 = makefunctor(&allocp[0]);
  allocp[4] = x7;
  allocp[5] = x8;
  x10 = makecons(&allocp[4]);
  a0 = arg(x0, 0);
  a1 = x9;
  a2 = x3;
  a3 = a5;
  a4 = x5;
  a5 = a7;
  a6 = a8;
  a7 = a9;
  a8 = a10;
  a9 = x10;
  allocp += 6;
  execute(load__pos_10_0);
  goto load__pos_10_ext_interrupt;
 case symval(makesym(atom_i)):
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a4;
  x2 = makefunctor(&allocp[0]);
  bblt_add_no_check_y(a4,makeint(1L),x3);
  allocp[2] = makesym(functor__24_3);
  allocp[3] = x0;
  allocp[4] = x2;
  allocp[5] = makesym(atom_any);
  x4 = makefunctor(&allocp[2]);
  allocp[6] = a6;
  allocp[7] = x4;
  x5 = makecons(&allocp[6]);
  allocp[8] = makesym(functor_put__value_2);
  allocp[9] = a1;
  allocp[10] = x2;
  x6 = makefunctor(&allocp[8]);
  allocp[11] = a11;
  allocp[12] = x6;
  x7 = makecons(&allocp[11]);
  allocp += 13;
  unify(a3, a2);
  allocp[0] = makesym(functor_get__elem_3);
  allocp[1] = x2;
  allocp[2] = x9 = makeref(&allocp[2]);
  allocp[3] = arg(x0, 1);
  x8 = makefunctor(&allocp[0]);
  allocp[4] = x7;
  allocp[5] = x8;
  x10 = makecons(&allocp[4]);
  a0 = arg(x0, 0);
  a1 = x9;
  a2 = x3;
  a3 = a5;
  a4 = x5;
  a5 = a7;
  a6 = a8;
  a7 = a9;
  a8 = a10;
  a9 = x10;
  allocp += 6;
  execute(load__pos_10_0);
  goto load__pos_10_ext_interrupt;
  };
  goto put__one__1_12_interrupt;
 case VARREF:
  deref_and_jump(x1,put__one__1_12_3);
  *reasonp++ =  x1;
  goto put__one__1_12_interrupt;
  };
  goto put__one__1_12_interrupt;
 case functor_var_1:
  unify(a9, a8);
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a4;
  x1 = makefunctor(&allocp[0]);
  bblt_add_no_check_y(a4,makeint(1L),x2);
  allocp += 2;
  unify(a5, x2);
  allocp[0] = makesym(functor__24_3);
  allocp[1] = x0;
  allocp[2] = x1;
  allocp[3] = makesym(atom_any);
  x3 = makefunctor(&allocp[0]);
  allocp[4] = a6;
  allocp[5] = x3;
  x4 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a7, x4);
  allocp[0] = makesym(functor_put__newvar_3);
  allocp[1] = a1;
  allocp[2] = a2;
  allocp[3] = x1;
  x5 = makefunctor(&allocp[0]);
  allocp[4] = a11;
  allocp[5] = x5;
  x6 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a10, x6);
  bblt_add_no_check_y(a2,makeint(1L),x7);
  unify(a3, x7);
  proceed();
 case functor_var_2:
  unify(a9, a8);
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a4;
  x1 = makefunctor(&allocp[0]);
  bblt_add_no_check_y(a4,makeint(1L),x2);
  allocp += 2;
  unify(a5, x2);
  allocp[0] = makesym(functor_var_1);
  allocp[1] = arg(x0, 0);
  x3 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__24_3);
  allocp[3] = x3;
  allocp[4] = x1;
  allocp[5] = makesym(atom_any);
  x4 = makefunctor(&allocp[2]);
  allocp[6] = a6;
  allocp[7] = x4;
  x5 = makecons(&allocp[6]);
  allocp += 8;
  unify_value(a7, x5);
  allocp[0] = makesym(functor_put__newvar_3);
  allocp[1] = a1;
  allocp[2] = a2;
  allocp[3] = x1;
  x6 = makefunctor(&allocp[0]);
  allocp[4] = a11;
  allocp[5] = x6;
  x7 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a10, x7);
  bblt_add_no_check_y(a2,makeint(1L),x8);
  unify(a3, x8);
  proceed();
  };
  goto put__one__1_12_interrupt;
 case VARREF:
  deref_and_jump(x0,put__one__1_12_2);
  *reasonp++ =  x0;
  goto put__one__1_12_interrupt;
  };
  goto put__one__1_12_interrupt;
  };
  goto put__one__1_12_interrupt;
 case VARREF:
  deref_and_jump(a0,put__one__1_12_1);
  *reasonp++ =  a0;
  goto put__one__1_12_interrupt;
  };
  goto put__one__1_12_interrupt;
 put__one__1_12_ext_interrupt:
  reasonp = 0l;
 put__one__1_12_interrupt:
  goto interrupt_12;
 }

 set__generic__args_10_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 set__generic__args_10_clear_reason:
  reasonp = reasons;
 set__generic__args_10_0:
 set__generic__args_10_1:
  switch (ptagof(a0)) {
 case CONS:
  bblt_add_no_check_y(a1,makeint(1L),x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xset__generic__args_10);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x0;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x5 = makeref(&allocp[10]);
  allocp[11] = a9;
  allocp[12] = makesym(functor_store__generic__arg_2);
  allocp[13] = x7 = makeref(&allocp[13]);
  allocp[14] = a1;
  x6 = makefunctor(&allocp[12]);
  allocp[15] = x5;
  allocp[16] = x6;
  x8 = makecons(&allocp[15]);
  allocp[17] = (q)(struct goalrec*)&allocp[0];
  allocp[18] = (q)(&predicate_klic__comp__generate_xstrip__type_2);
  allocp[19] = x9 = makeref(&allocp[19]);
  allocp[20] = x7;
  a0 = car_of(a0);
  a1 = x9;
  a3 = x2;
  a5 = x3;
  a7 = x4;
  a9 = x8;
  qp = (struct goalrec*)&allocp[17];
  allocp += 21;
  execute(prep__call__arg_10_0);
  goto prep__call__arg_10_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto set__generic__args_10_interrupt;
  unify4(a9, a8, a7, a6, a5, a4, a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,set__generic__args_10_1);
  *reasonp++ =  a0;
  goto set__generic__args_10_interrupt;
  };
  goto set__generic__args_10_interrupt;
 set__generic__args_10_ext_interrupt:
  reasonp = 0l;
 set__generic__args_10_interrupt:
  goto interrupt_10;
 }

 move__args_10_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 move__args_10_clear_reason:
  reasonp = reasons;
 move__args_10_0:
 move__args_10_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xmove__args__1_12);
  allocp[2] = x0 = makeref(&allocp[2]);
  x1 = car_of(a0);
  allocp[3] = x1;
  x2 = cdr_of(a0);
  allocp[4] = x2;
  allocp[5] = a1;
  allocp[6] = a2;
  allocp[7] = a3;
  allocp[8] = a4;
  allocp[9] = a5;
  allocp[10] = a6;
  allocp[11] = a7;
  allocp[12] = a8;
  allocp[13] = a9;
  allocp[14] = makesym(functor_a_1);
  allocp[15] = a1;
  x3 = makefunctor(&allocp[14]);
  a0 = x2;
  a1 = x3;
  a2 = a4;
  a3 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 16;
  execute(used__in_4_0);
  goto used__in_4_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto move__args_10_interrupt;
  unify4(a9, a8, a7, a6, a5, a4, a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,move__args_10_1);
  *reasonp++ =  a0;
  goto move__args_10_interrupt;
  };
  goto move__args_10_interrupt;
 move__args_10_ext_interrupt:
  reasonp = 0l;
 move__args_10_interrupt:
  toppred = &predicate_klic__comp__generate_xmove__args_10;
  goto interrupt_10;
 }

 move__args__1_12_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 move__args__1_12_clear_reason:
  reasonp = reasons;
 move__args__1_12_0:
 move__args__1_12_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto move__args__1_12_5;
  switch (symval(a0)) {
 case symval(makesym(atom_no)):
  bblt_add_no_check_y(a3,makeint(1L),x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xmove__args_10);
  allocp[2] = a2;
  allocp[3] = x0;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a5;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a7;
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = x4 = makeref(&allocp[10]);
  allocp[11] = a11;
  allocp[12] = makesym(functor_a_1);
  allocp[13] = a3;
  x5 = makefunctor(&allocp[12]);
  a0 = a1;
  a1 = x5;
  a2 = a4;
  a3 = x1;
  a4 = a6;
  a5 = x2;
  a6 = a8;
  a7 = x3;
  a8 = a10;
  a9 = x4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 14;
  execute(move__one_10_0);
  goto move__one_10_ext_interrupt;
 case symval(makesym(atom_yes)):
 move__args__1_12_2:
  switch (ptagof(a1)) {
 case FUNCTOR:
  switch (symval(functor_of(a1))) {
 case functor__3A_2:
  x0 = arg(a1, 0);
 move__args__1_12_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_r_1)) goto move__args__1_12_5;
  x1 = arg(x0, 0);
 move__args__1_12_4:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_a_1)) goto move__args__1_12_5;
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a4;
  x2 = makefunctor(&allocp[0]);
  bblt_add_no_check_y(a4,makeint(1L),x3);
  bblt_add_no_check_y(a3,makeint(1L),x4);
  allocp[2] = makesym(functor_r_1);
  allocp[3] = x2;
  x5 = makefunctor(&allocp[2]);
  allocp[4] = makesym(functor__3A_2);
  allocp[5] = x5;
  allocp[6] = arg(a1, 1);
  x6 = makefunctor(&allocp[4]);
  allocp[7] = makesym(functor_a_1);
  allocp[8] = a3;
  x7 = makefunctor(&allocp[7]);
  allocp[9] = (q)qp;
  allocp[10] = (q)(&predicate_klic__comp__generate_xmove__one_10);
  allocp[11] = x6;
  allocp[12] = x7;
  allocp[13] = x8 = makeref(&allocp[13]);
  allocp[14] = a5;
  allocp[15] = x9 = makeref(&allocp[15]);
  allocp[16] = a7;
  allocp[17] = x10 = makeref(&allocp[17]);
  allocp[18] = a9;
  allocp[19] = x11 = makeref(&allocp[19]);
  allocp[20] = a11;
  allocp[21] = (q)(struct goalrec*)&allocp[9];
  allocp[22] = (q)(&predicate_klic__comp__generate_xmove__args_10);
  allocp[23] = a2;
  allocp[24] = x4;
  allocp[25] = x12 = makeref(&allocp[25]);
  allocp[26] = x8;
  allocp[27] = x13 = makeref(&allocp[27]);
  allocp[28] = x9;
  allocp[29] = x14 = makeref(&allocp[29]);
  allocp[30] = x10;
  allocp[31] = x15 = makeref(&allocp[31]);
  allocp[32] = x11;
  a0 = a1;
  a1 = x2;
  a2 = x3;
  a3 = x12;
  a4 = a6;
  a5 = x13;
  a6 = a8;
  a7 = x14;
  a8 = a10;
  a9 = x15;
  qp = (struct goalrec*)&allocp[21];
  allocp += 33;
  execute(move__one_10_0);
  goto move__one_10_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,move__args__1_12_4);
  *reasonp++ =  x1;
  goto move__args__1_12_5;
  };
  goto move__args__1_12_5;
 case VARREF:
  deref_and_jump(x0,move__args__1_12_3);
  *reasonp++ =  x0;
  goto move__args__1_12_5;
  };
  goto move__args__1_12_5;
 case functor_arg_2:
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a4;
  x0 = makefunctor(&allocp[0]);
  bblt_add_no_check_y(a4,makeint(1L),x1);
  bblt_add_no_check_y(a3,makeint(1L),x2);
  allocp[2] = makesym(functor_r_1);
  allocp[3] = x0;
  x3 = makefunctor(&allocp[2]);
  allocp[4] = makesym(functor__3A_2);
  allocp[5] = x3;
  allocp[6] = x5 = makeref(&allocp[6]);
  x4 = makefunctor(&allocp[4]);
  allocp[7] = makesym(functor_a_1);
  allocp[8] = a3;
  x6 = makefunctor(&allocp[7]);
  allocp[9] = (q)qp;
  allocp[10] = (q)(&predicate_klic__comp__generate_xmove__one_10);
  allocp[11] = x4;
  allocp[12] = x6;
  allocp[13] = x7 = makeref(&allocp[13]);
  allocp[14] = a5;
  allocp[15] = x8 = makeref(&allocp[15]);
  allocp[16] = a7;
  allocp[17] = x9 = makeref(&allocp[17]);
  allocp[18] = a9;
  allocp[19] = x10 = makeref(&allocp[19]);
  allocp[20] = a11;
  allocp[21] = (q)(struct goalrec*)&allocp[9];
  allocp[22] = (q)(&predicate_klic__comp__generate_xmove__args_10);
  allocp[23] = a2;
  allocp[24] = x2;
  allocp[25] = x11 = makeref(&allocp[25]);
  allocp[26] = x7;
  allocp[27] = x12 = makeref(&allocp[27]);
  allocp[28] = x8;
  allocp[29] = x13 = makeref(&allocp[29]);
  allocp[30] = x9;
  allocp[31] = x14 = makeref(&allocp[31]);
  allocp[32] = x10;
  a0 = a1;
  a1 = x0;
  a2 = x1;
  a3 = x11;
  a4 = a6;
  a5 = x12;
  a6 = a8;
  a7 = x13;
  a8 = a10;
  a9 = x14;
  qp = (struct goalrec*)&allocp[21];
  allocp += 33;
  execute(move__one_10_0);
  goto move__one_10_ext_interrupt;
 case functor_var_1:
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a4;
  x0 = makefunctor(&allocp[0]);
  bblt_add_no_check_y(a4,makeint(1L),x1);
  bblt_add_no_check_y(a3,makeint(1L),x2);
  allocp[2] = makesym(functor_r_1);
  allocp[3] = x0;
  x3 = makefunctor(&allocp[2]);
  allocp[4] = makesym(functor__3A_2);
  allocp[5] = x3;
  allocp[6] = x5 = makeref(&allocp[6]);
  x4 = makefunctor(&allocp[4]);
  allocp[7] = makesym(functor_a_1);
  allocp[8] = a3;
  x6 = makefunctor(&allocp[7]);
  allocp[9] = (q)qp;
  allocp[10] = (q)(&predicate_klic__comp__generate_xmove__one_10);
  allocp[11] = x4;
  allocp[12] = x6;
  allocp[13] = x7 = makeref(&allocp[13]);
  allocp[14] = a5;
  allocp[15] = x8 = makeref(&allocp[15]);
  allocp[16] = a7;
  allocp[17] = x9 = makeref(&allocp[17]);
  allocp[18] = a9;
  allocp[19] = x10 = makeref(&allocp[19]);
  allocp[20] = a11;
  allocp[21] = (q)(struct goalrec*)&allocp[9];
  allocp[22] = (q)(&predicate_klic__comp__generate_xmove__args_10);
  allocp[23] = a2;
  allocp[24] = x2;
  allocp[25] = x11 = makeref(&allocp[25]);
  allocp[26] = x7;
  allocp[27] = x12 = makeref(&allocp[27]);
  allocp[28] = x8;
  allocp[29] = x13 = makeref(&allocp[29]);
  allocp[30] = x9;
  allocp[31] = x14 = makeref(&allocp[31]);
  allocp[32] = x10;
  a0 = a1;
  a1 = x0;
  a2 = x1;
  a3 = x11;
  a4 = a6;
  a5 = x12;
  a6 = a8;
  a7 = x13;
  a8 = a10;
  a9 = x14;
  qp = (struct goalrec*)&allocp[21];
  allocp += 33;
  execute(move__one_10_0);
  goto move__one_10_ext_interrupt;
  };
  goto move__args__1_12_5;
 case VARREF:
  deref_and_jump(a1,move__args__1_12_2);
  *reasonp++ =  a1;
  goto move__args__1_12_5;
  };
  goto move__args__1_12_5;
  };
  goto move__args__1_12_5;
 case VARREF:
  deref_and_jump(a0,move__args__1_12_1);
  *reasonp++ =  a0;
  goto move__args__1_12_5;
  };
  goto move__args__1_12_5;
 move__args__1_12_5:
  otherwise(move__args__1_12_interrupt);
 move__args__1_12_6:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_yes)) goto move__args__1_12_interrupt;
  bblt_add_no_check_y(a3,makeint(1L),x0);
  allocp[0] = makesym(functor_a_1);
  allocp[1] = a3;
  x1 = makefunctor(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__generate_xmove__one_10);
  allocp[4] = a1;
  allocp[5] = x1;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x4 = makeref(&allocp[10]);
  allocp[11] = a9;
  allocp[12] = x5 = makeref(&allocp[12]);
  allocp[13] = a11;
  a0 = a2;
  a1 = x0;
  a2 = a4;
  a3 = x2;
  a4 = a6;
  a5 = x3;
  a6 = a8;
  a7 = x4;
  a8 = a10;
  a9 = x5;
  qp = (struct goalrec*)&allocp[2];
  allocp += 14;
  execute(move__args_10_0);
  goto move__args_10_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,move__args__1_12_6);
  *reasonp++ =  a0;
  goto move__args__1_12_interrupt;
  };
  goto move__args__1_12_interrupt;
 move__args__1_12_ext_interrupt:
  reasonp = 0l;
 move__args__1_12_interrupt:
  goto interrupt_12;
 }

 move__one_10_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 move__one_10_clear_reason:
  reasonp = reasons;
 move__one_10_0:
 move__one_10_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor__3A_2)) goto move__one_10_7;
  x0 = arg(a0, 0);
 move__one_10_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_r_1)) goto move__one_10_7;
  x1 = arg(x0, 0);
 move__one_10_3:
  if (isref(x1)) goto move__one_10_6;
 move__one_10_4:
  if (isref(x1)) goto move__one_10_5;
  if_not_equal(x1, a1, move__one_10_7);
  unify4(a9, a8, a7, a6, a5, a4, a3, a2);
  proceed();
 move__one_10_5:
  deref_and_jump(x1,move__one_10_4);
  *reasonp++ =  x1;
  goto move__one_10_7;
 move__one_10_6:
  deref_and_jump(x1,move__one_10_3);
  *reasonp++ =  x1;
  goto move__one_10_7;
 case VARREF:
  deref_and_jump(x0,move__one_10_2);
  *reasonp++ =  x0;
  goto move__one_10_7;
  };
  goto move__one_10_7;
 case VARREF:
  deref_and_jump(a0,move__one_10_1);
  *reasonp++ =  a0;
  goto move__one_10_7;
  };
  goto move__one_10_7;
 move__one_10_7:
  otherwise(move__one_10_interrupt);
 move__one_10_8:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor__3A_2)) goto move__one_10_10;
  x0 = arg(a0, 0);
 move__one_10_9:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_r_1)) goto move__one_10_10;
  unify3(a7, a6, a5, a4, a3, a2);
  allocp[0] = makesym(functor_move_2);
  allocp[1] = a1;
  allocp[2] = arg(x0, 0);
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a9;
  allocp[4] = x1;
  x2 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a8, x2);
  proceed();
 case VARREF:
  deref_and_jump(x0,move__one_10_9);
  *reasonp++ =  x0;
  goto move__one_10_10;
  };
  goto move__one_10_10;
 case VARREF:
  deref_and_jump(a0,move__one_10_8);
  *reasonp++ =  a0;
  goto move__one_10_10;
  };
  goto move__one_10_10;
 move__one_10_10:
  otherwise(move__one_10_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xmove__one__1_10);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  x1 = a4;
  a1 = a0;
  a2 = x0;
  a0 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  execute(assocx_3_0);
  goto assocx_3_ext_interrupt;
 move__one_10_ext_interrupt:
  reasonp = 0l;
 move__one_10_interrupt:
  toppred = &predicate_klic__comp__generate_xmove__one_10;
  goto interrupt_10;
 }

 move__one__1_10_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 move__one__1_10_clear_reason:
  reasonp = reasons;
 move__one__1_10_0:
 move__one__1_10_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_yes_2:
  allocp[0] = makesym(functor_r_1);
  allocp[1] = arg(a0, 0);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__3A_2);
  allocp[3] = x0;
  allocp[4] = arg(a0, 1);
  x1 = makefunctor(&allocp[2]);
  a0 = x1;
  allocp += 5;
  execute(move__one_10_0);
  goto move__one_10_ext_interrupt;
 case functor_no_1:
  x0 = arg(a0, 0);
 move__one__1_10_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_atom_1:
  unify3(a7, a6, a5, a4, a3, a2);
  allocp[0] = makesym(functor_load__const_2);
  allocp[1] = a1;
  allocp[2] = x0;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a9;
  allocp[4] = x1;
  x2 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a8, x2);
  proceed();
 case functor_int_1:
  unify3(a7, a6, a5, a4, a3, a2);
  allocp[0] = makesym(functor_load__const_2);
  allocp[1] = a1;
  allocp[2] = x0;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a9;
  allocp[4] = x1;
  x2 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a8, x2);
  proceed();
 case functor_const_1:
  unify3(a7, a6, a5, a4, a3, a2);
  allocp[0] = makesym(functor_load__const_2);
  allocp[1] = a1;
  allocp[2] = x0;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a9;
  allocp[4] = x1;
  x2 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a8, x2);
  proceed();
 case functor_arg_2:
  allocp[0] = makesym(functor__24_3);
  allocp[1] = x0;
  allocp[2] = a1;
  allocp[3] = makesym(atom_any);
  x1 = makefunctor(&allocp[0]);
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = x1;
  x2 = makecons(&allocp[4]);
  allocp[6] = makesym(functor_get__elem_3);
  allocp[7] = a1;
  allocp[8] = x5 = makeref(&allocp[8]);
  allocp[9] = arg(x0, 1);
  x4 = makefunctor(&allocp[6]);
  allocp[10] = a9;
  allocp[11] = x4;
  x6 = makecons(&allocp[10]);
  a0 = arg(x0, 0);
  a1 = x5;
  a9 = x6;
  allocp += 12;
  execute(load__pos_10_0);
  goto load__pos_10_ext_interrupt;
 case functor_arg_3:
  allocp[0] = makesym(functor__24_3);
  allocp[1] = x0;
  allocp[2] = a1;
  allocp[3] = makesym(atom_any);
  x1 = makefunctor(&allocp[0]);
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = x1;
  x2 = makecons(&allocp[4]);
  allocp[6] = makesym(functor_get__elem_3);
  allocp[7] = a1;
  allocp[8] = x5 = makeref(&allocp[8]);
  allocp[9] = arg(x0, 1);
  x4 = makefunctor(&allocp[6]);
  allocp[10] = a9;
  allocp[11] = x4;
  x6 = makecons(&allocp[10]);
  a0 = arg(x0, 0);
  a1 = x5;
  a9 = x6;
  allocp += 12;
  execute(load__pos_10_0);
  goto load__pos_10_ext_interrupt;
 case functor_var_1:
  unify(a7, a6);
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a2;
  x1 = makefunctor(&allocp[0]);
  bblt_add_no_check_y(a2,makeint(1L),x2);
  allocp += 2;
  unify(a3, x2);
  allocp[0] = makesym(functor__24_3);
  allocp[1] = x0;
  allocp[2] = x1;
  allocp[3] = makesym(atom_any);
  x3 = makefunctor(&allocp[0]);
  allocp[4] = a4;
  allocp[5] = x3;
  x4 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a5, x4);
  allocp[0] = makesym(functor_load__newvar_1);
  allocp[1] = x1;
  x5 = makefunctor(&allocp[0]);
  allocp[2] = x7 = makeref(&allocp[2]);
  allocp[3] = x5;
  x6 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a8, x6);
  allocp[0] = makesym(functor_move_2);
  allocp[1] = a1;
  allocp[2] = x1;
  x8 = makefunctor(&allocp[0]);
  allocp[3] = a9;
  allocp[4] = x8;
  x9 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(x7, x9);
  proceed();
 case functor_var_2:
  unify(a7, a6);
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a2;
  x1 = makefunctor(&allocp[0]);
  bblt_add_no_check_y(a2,makeint(1L),x2);
  allocp += 2;
  unify(a3, x2);
  allocp[0] = makesym(functor_var_1);
  allocp[1] = arg(x0, 0);
  x3 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__24_3);
  allocp[3] = x3;
  allocp[4] = x1;
  allocp[5] = makesym(atom_any);
  x4 = makefunctor(&allocp[2]);
  allocp[6] = a4;
  allocp[7] = x4;
  x5 = makecons(&allocp[6]);
  allocp += 8;
  unify_value(a5, x5);
  allocp[0] = makesym(functor_load__newvar_2);
  allocp[1] = x1;
  allocp[2] = arg(x0, 1);
  x6 = makefunctor(&allocp[0]);
  allocp[3] = x8 = makeref(&allocp[3]);
  allocp[4] = x6;
  x7 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a8, x7);
  allocp[0] = makesym(functor_move_2);
  allocp[1] = a1;
  allocp[2] = x1;
  x9 = makefunctor(&allocp[0]);
  allocp[3] = a9;
  allocp[4] = x9;
  x10 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(x8, x10);
  proceed();
  };
  goto move__one__1_10_interrupt;
 case VARREF:
  deref_and_jump(x0,move__one__1_10_2);
  *reasonp++ =  x0;
  goto move__one__1_10_interrupt;
  };
  goto move__one__1_10_interrupt;
  };
  goto move__one__1_10_interrupt;
 case VARREF:
  deref_and_jump(a0,move__one__1_10_1);
  *reasonp++ =  a0;
  goto move__one__1_10_interrupt;
  };
  goto move__one__1_10_interrupt;
 move__one__1_10_ext_interrupt:
  reasonp = 0l;
 move__one__1_10_interrupt:
  goto interrupt_10;
 }

 used__in_4_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 used__in_4_clear_reason:
  reasonp = reasons;
 used__in_4_0:
 used__in_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 used__in_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor__3A_2:
  x1 = arg(x0, 0);
 used__in_4_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_r_1)) goto used__in_4_8;
  x2 = arg(x1, 0);
 used__in_4_4:
  if (isref(x2)) goto used__in_4_7;
 used__in_4_5:
  if (isref(x2)) goto used__in_4_6;
  if_not_equal(x2, a1, used__in_4_8);
  unify_value(a3, makesym(atom_yes));
  proceed();
 used__in_4_6:
  deref_and_jump(x2,used__in_4_5);
  *reasonp++ =  x2;
  goto used__in_4_8;
 used__in_4_7:
  deref_and_jump(x2,used__in_4_4);
  *reasonp++ =  x2;
  goto used__in_4_8;
 case VARREF:
  deref_and_jump(x1,used__in_4_3);
  *reasonp++ =  x1;
  goto used__in_4_8;
  };
  goto used__in_4_8;
 case functor_arg_2:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xused__in__1_5);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  a0 = a2;
  a1 = arg(x0, 0);
  a2 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(assocx_3_0);
  goto assocx_3_ext_interrupt;
 case functor_var_1:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xused__in__1_5);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  a0 = a2;
  a1 = x0;
  a2 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(assocx_3_0);
  goto assocx_3_ext_interrupt;
  };
  goto used__in_4_8;
 case VARREF:
  deref_and_jump(x0,used__in_4_2);
  *reasonp++ =  x0;
  goto used__in_4_8;
  };
  goto used__in_4_8;
 case ATOMIC:
  if (a0 != NILATOM) goto used__in_4_8;
  unify_value(a3, makesym(atom_no));
  proceed();
 case VARREF:
  deref_and_jump(a0,used__in_4_1);
  *reasonp++ =  a0;
  goto used__in_4_8;
  };
  goto used__in_4_8;
 used__in_4_8:
  otherwise(used__in_4_interrupt);
 used__in_4_9:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(used__in_4_0);
  goto used__in_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,used__in_4_9);
  *reasonp++ =  a0;
  goto used__in_4_interrupt;
  };
  goto used__in_4_interrupt;
 used__in_4_ext_interrupt:
  reasonp = 0l;
 used__in_4_interrupt:
  toppred = &predicate_klic__comp__generate_xused__in_4;
  goto interrupt_4;
 }

 used__in__1_5_top: {
  q x0;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 used__in__1_5_clear_reason:
  reasonp = reasons;
 used__in__1_5_0:
 used__in__1_5_1:
  switch (ptagof(a4)) {
 case FUNCTOR:
  if (functor_of(a4) != makesym(functor_yes_2)) goto used__in__1_5_6;
  x0 = arg(a4, 0);
 used__in__1_5_2:
  if (isref(x0)) goto used__in__1_5_5;
 used__in__1_5_3:
  if (isref(x0)) goto used__in__1_5_4;
  if_not_equal(x0, a1, used__in__1_5_6);
  unify_value(a3, makesym(atom_yes));
  proceed();
 used__in__1_5_4:
  deref_and_jump(x0,used__in__1_5_3);
  *reasonp++ =  x0;
  goto used__in__1_5_6;
 used__in__1_5_5:
  deref_and_jump(x0,used__in__1_5_2);
  *reasonp++ =  x0;
  goto used__in__1_5_6;
 case VARREF:
  deref_and_jump(a4,used__in__1_5_1);
  *reasonp++ =  a4;
  goto used__in__1_5_6;
  };
  goto used__in__1_5_6;
 used__in__1_5_6:
  otherwise(used__in__1_5_interrupt);
  execute(used__in_4_0);
  goto used__in_4_ext_interrupt;
 used__in__1_5_ext_interrupt:
  reasonp = 0l;
 used__in__1_5_interrupt:
  goto interrupt_5;
 }

 strip__types_2_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  qp = qp->next;
 strip__types_2_clear_reason:
  reasonp = reasons;
 strip__types_2_0:
 strip__types_2_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xstrip__types_2);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x1;
  allocp[5] = x3 = makeref(&allocp[5]);
  x2 = makecons(&allocp[4]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  unify_value(a1, x2);
  a0 = car_of(a0);
  a1 = x3;
  execute(strip__type_2_0);
  goto strip__type_2_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto strip__types_2_interrupt;
  unify_value(a1, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a0,strip__types_2_1);
  *reasonp++ =  a0;
  goto strip__types_2_interrupt;
  };
  goto strip__types_2_interrupt;
 strip__types_2_ext_interrupt:
  reasonp = 0l;
 strip__types_2_interrupt:
  goto interrupt_2;
 }

 strip__type_2_top: {
  q x0;
  a1 = qp->args[1];
  qp = qp->next;
 strip__type_2_clear_reason:
  reasonp = reasons;
 strip__type_2_0:
 strip__type_2_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor__3A_2)) goto strip__type_2_2;
  x0 = arg(a0, 0);
  unify(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,strip__type_2_1);
  *reasonp++ =  a0;
  goto strip__type_2_2;
  };
  goto strip__type_2_2;
 strip__type_2_2:
  otherwise(strip__type_2_interrupt);
  unify(a1, a0);
  proceed();
 strip__type_2_ext_interrupt:
  reasonp = 0l;
 strip__type_2_interrupt:
  toppred = &predicate_klic__comp__generate_xstrip__type_2;
  goto interrupt_2;
 }

 make__label_2_top: {
  q x0;
  a1 = qp->args[1];
  qp = qp->next;
 make__label_2_clear_reason:
  reasonp = reasons;
 make__label_2_0:
 make__label_2_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_none)) goto make__label_2_interrupt;
  proceed();
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_lab_1)) goto make__label_2_interrupt;
  x0 = arg(a0, 0);
  unify(x0, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,make__label_2_1);
  *reasonp++ =  a0;
  goto make__label_2_interrupt;
  };
  goto make__label_2_interrupt;
 make__label_2_ext_interrupt:
  reasonp = 0l;
 make__label_2_interrupt:
  toppred = &predicate_klic__comp__generate_xmake__label_2;
  goto interrupt_2;
 }

 add__info_4_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 add__info_4_clear_reason:
  reasonp = reasons;
 add__info_4_0:
  allocp[0] = makesym(functor__24_3);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = a0;
  allocp[3] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp[4] = a2;
  allocp[5] = x0;
  x2 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a3, x2);
  x3 = a2;
  a1 = x1;
  a2 = a0;
  a0 = x3;
  execute(rassoc_3_0);
  goto rassoc_3_ext_interrupt;
 add__info_4_ext_interrupt:
  reasonp = 0l;
 add__info_4_interrupt:
  toppred = &predicate_klic__comp__generate_xadd__info_4;
  goto interrupt_4;
 }

 rassoc_3_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 rassoc_3_clear_reason:
  reasonp = reasons;
 rassoc_3_0:
 rassoc_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 rassoc_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__24_3)) goto rassoc_3_7;
  x1 = arg(x0, 1);
 rassoc_3_3:
  if (isref(x1)) goto rassoc_3_6;
 rassoc_3_4:
  if (isref(x1)) goto rassoc_3_5;
  if_not_equal(x1, a2, rassoc_3_7);
  x2 = arg(x0, 0);
  unify(x2, a1);
  proceed();
 rassoc_3_5:
  deref_and_jump(x1,rassoc_3_4);
  *reasonp++ =  x1;
  goto rassoc_3_7;
 rassoc_3_6:
  deref_and_jump(x1,rassoc_3_3);
  *reasonp++ =  x1;
  goto rassoc_3_7;
 case VARREF:
  deref_and_jump(x0,rassoc_3_2);
  *reasonp++ =  x0;
  goto rassoc_3_7;
  };
  goto rassoc_3_7;
 case VARREF:
  deref_and_jump(a0,rassoc_3_1);
  *reasonp++ =  a0;
  goto rassoc_3_7;
  };
  goto rassoc_3_7;
 rassoc_3_7:
  otherwise(rassoc_3_interrupt);
 rassoc_3_8:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(rassoc_3_0);
  goto rassoc_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,rassoc_3_8);
  *reasonp++ =  a0;
  goto rassoc_3_interrupt;
  };
  goto rassoc_3_interrupt;
 rassoc_3_ext_interrupt:
  reasonp = 0l;
 rassoc_3_interrupt:
  toppred = &predicate_klic__comp__generate_xrassoc_3;
  goto interrupt_3;
 }

 assocx_3_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 assocx_3_clear_reason:
  reasonp = reasons;
 assocx_3_0:
 assocx_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 assocx_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__24_3)) goto assocx_3_21;
 assocx_3_3:
  switch (ptagof(a1)) {
 case FUNCTOR:
  switch (symval(functor_of(a1))) {
 case functor_arg_3:
  x1 = arg(x0, 0);
 assocx_3_4:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_arg_2)) goto assocx_3_18;
  x2 = arg(x1, 0);
 assocx_3_5:
  if (isref(x2)) goto assocx_3_12;
 assocx_3_6:
  if (isref(x2)) goto assocx_3_11;
  x3 = arg(a1, 0);
  if_not_equal(x2, x3, assocx_3_18);
  x4 = arg(x1, 1);
 assocx_3_7:
  if (isref(x4)) goto assocx_3_10;
 assocx_3_8:
  if (isref(x4)) goto assocx_3_9;
  x5 = arg(a1, 1);
  if_not_equal(x4, x5, assocx_3_18);
  allocp[0] = makesym(functor_yes_2);
  allocp[1] = arg(x0, 1);
  allocp[2] = arg(x0, 2);
  x6 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a2, x6);
  proceed();
 assocx_3_9:
  deref_and_jump(x4,assocx_3_8);
  *reasonp++ =  x4;
  goto assocx_3_18;
 assocx_3_10:
  deref_and_jump(x4,assocx_3_7);
  *reasonp++ =  x4;
  goto assocx_3_18;
 assocx_3_11:
  deref_and_jump(x2,assocx_3_6);
  *reasonp++ =  x2;
  goto assocx_3_18;
 assocx_3_12:
  deref_and_jump(x2,assocx_3_5);
  *reasonp++ =  x2;
  goto assocx_3_18;
 case VARREF:
  deref_and_jump(x1,assocx_3_4);
  *reasonp++ =  x1;
  goto assocx_3_18;
  };
  goto assocx_3_18;
 case functor_var_2:
  x1 = arg(x0, 0);
 assocx_3_13:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_var_1)) goto assocx_3_18;
  x2 = arg(x1, 0);
 assocx_3_14:
  if (isref(x2)) goto assocx_3_17;
 assocx_3_15:
  if (isref(x2)) goto assocx_3_16;
  x3 = arg(a1, 0);
  if_not_equal(x2, x3, assocx_3_18);
  allocp[0] = makesym(functor_yes_2);
  allocp[1] = arg(x0, 1);
  allocp[2] = arg(x0, 2);
  x4 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a2, x4);
  proceed();
 assocx_3_16:
  deref_and_jump(x2,assocx_3_15);
  *reasonp++ =  x2;
  goto assocx_3_18;
 assocx_3_17:
  deref_and_jump(x2,assocx_3_14);
  *reasonp++ =  x2;
  goto assocx_3_18;
 case VARREF:
  deref_and_jump(x1,assocx_3_13);
  *reasonp++ =  x1;
  goto assocx_3_18;
  };
  goto assocx_3_18;
  };
  goto assocx_3_18;
 case VARREF:
  deref_and_jump(a1,assocx_3_3);
  *reasonp++ =  a1;
  goto assocx_3_21;
  };
  goto assocx_3_18;
 assocx_3_18:
 assocx_3_19:
  if (isref(a1)) goto assocx_3_20;
  x1 = arg(x0, 0);
  if_not_equal(a1, x1, assocx_3_21);
  allocp[0] = makesym(functor_yes_2);
  allocp[1] = arg(x0, 1);
  allocp[2] = arg(x0, 2);
  x2 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a2, x2);
  proceed();
 assocx_3_20:
  deref_and_jump(a1,assocx_3_19);
  *reasonp++ =  a1;
  goto assocx_3_21;
 case VARREF:
  deref_and_jump(x0,assocx_3_2);
  *reasonp++ =  x0;
  goto assocx_3_21;
  };
  goto assocx_3_21;
 case ATOMIC:
  if (a0 != NILATOM) goto assocx_3_21;
  allocp[0] = makesym(functor_no_1);
  allocp[1] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,assocx_3_1);
  *reasonp++ =  a0;
  goto assocx_3_21;
  };
  goto assocx_3_21;
 assocx_3_21:
  otherwise(assocx_3_interrupt);
 assocx_3_22:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(assocx_3_0);
  goto assocx_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,assocx_3_22);
  *reasonp++ =  a0;
  goto assocx_3_interrupt;
  };
  goto assocx_3_interrupt;
 assocx_3_ext_interrupt:
  reasonp = 0l;
 assocx_3_interrupt:
  toppred = &predicate_klic__comp__generate_xassocx_3;
  goto interrupt_3;
 }

 assocx__for__set__tmake_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 assocx__for__set__tmake_3_clear_reason:
  reasonp = reasons;
 assocx__for__set__tmake_3_0:
 assocx__for__set__tmake_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 assocx__for__set__tmake_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__24_3)) goto assocx__for__set__tmake_3_21;
 assocx__for__set__tmake_3_3:
  switch (ptagof(a1)) {
 case FUNCTOR:
  switch (symval(functor_of(a1))) {
 case functor_arg_3:
  x1 = arg(x0, 0);
 assocx__for__set__tmake_3_4:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_arg_2)) goto assocx__for__set__tmake_3_18;
  x2 = arg(x1, 0);
 assocx__for__set__tmake_3_5:
  if (isref(x2)) goto assocx__for__set__tmake_3_12;
 assocx__for__set__tmake_3_6:
  if (isref(x2)) goto assocx__for__set__tmake_3_11;
  x3 = arg(a1, 0);
  if_not_equal(x2, x3, assocx__for__set__tmake_3_18);
  x4 = arg(x1, 1);
 assocx__for__set__tmake_3_7:
  if (isref(x4)) goto assocx__for__set__tmake_3_10;
 assocx__for__set__tmake_3_8:
  if (isref(x4)) goto assocx__for__set__tmake_3_9;
  x5 = arg(a1, 1);
  if_not_equal(x4, x5, assocx__for__set__tmake_3_18);
  allocp[0] = arg(a1, 2);
  allocp[1] = arg(x0, 2);
  x6 = makecons(&allocp[0]);
  allocp[2] = makesym(functor_yes_2);
  allocp[3] = arg(x0, 1);
  allocp[4] = x6;
  x7 = makefunctor(&allocp[2]);
  allocp += 5;
  unify_value(a2, x7);
  proceed();
 assocx__for__set__tmake_3_9:
  deref_and_jump(x4,assocx__for__set__tmake_3_8);
  *reasonp++ =  x4;
  goto assocx__for__set__tmake_3_18;
 assocx__for__set__tmake_3_10:
  deref_and_jump(x4,assocx__for__set__tmake_3_7);
  *reasonp++ =  x4;
  goto assocx__for__set__tmake_3_18;
 assocx__for__set__tmake_3_11:
  deref_and_jump(x2,assocx__for__set__tmake_3_6);
  *reasonp++ =  x2;
  goto assocx__for__set__tmake_3_18;
 assocx__for__set__tmake_3_12:
  deref_and_jump(x2,assocx__for__set__tmake_3_5);
  *reasonp++ =  x2;
  goto assocx__for__set__tmake_3_18;
 case VARREF:
  deref_and_jump(x1,assocx__for__set__tmake_3_4);
  *reasonp++ =  x1;
  goto assocx__for__set__tmake_3_18;
  };
  goto assocx__for__set__tmake_3_18;
 case functor_var_2:
  x1 = arg(x0, 0);
 assocx__for__set__tmake_3_13:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_var_1)) goto assocx__for__set__tmake_3_18;
  x2 = arg(x1, 0);
 assocx__for__set__tmake_3_14:
  if (isref(x2)) goto assocx__for__set__tmake_3_17;
 assocx__for__set__tmake_3_15:
  if (isref(x2)) goto assocx__for__set__tmake_3_16;
  x3 = arg(a1, 0);
  if_not_equal(x2, x3, assocx__for__set__tmake_3_18);
  allocp[0] = arg(a1, 1);
  allocp[1] = arg(x0, 2);
  x4 = makecons(&allocp[0]);
  allocp[2] = makesym(functor_yes_2);
  allocp[3] = arg(x0, 1);
  allocp[4] = x4;
  x5 = makefunctor(&allocp[2]);
  allocp += 5;
  unify_value(a2, x5);
  proceed();
 assocx__for__set__tmake_3_16:
  deref_and_jump(x2,assocx__for__set__tmake_3_15);
  *reasonp++ =  x2;
  goto assocx__for__set__tmake_3_18;
 assocx__for__set__tmake_3_17:
  deref_and_jump(x2,assocx__for__set__tmake_3_14);
  *reasonp++ =  x2;
  goto assocx__for__set__tmake_3_18;
 case VARREF:
  deref_and_jump(x1,assocx__for__set__tmake_3_13);
  *reasonp++ =  x1;
  goto assocx__for__set__tmake_3_18;
  };
  goto assocx__for__set__tmake_3_18;
  };
  goto assocx__for__set__tmake_3_18;
 case VARREF:
  deref_and_jump(a1,assocx__for__set__tmake_3_3);
  *reasonp++ =  a1;
  goto assocx__for__set__tmake_3_21;
  };
  goto assocx__for__set__tmake_3_18;
 assocx__for__set__tmake_3_18:
 assocx__for__set__tmake_3_19:
  if (isref(a1)) goto assocx__for__set__tmake_3_20;
  x1 = arg(x0, 0);
  if_not_equal(a1, x1, assocx__for__set__tmake_3_21);
  allocp[0] = makesym(functor_yes_2);
  allocp[1] = arg(x0, 1);
  allocp[2] = arg(x0, 2);
  x2 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a2, x2);
  proceed();
 assocx__for__set__tmake_3_20:
  deref_and_jump(a1,assocx__for__set__tmake_3_19);
  *reasonp++ =  a1;
  goto assocx__for__set__tmake_3_21;
 case VARREF:
  deref_and_jump(x0,assocx__for__set__tmake_3_2);
  *reasonp++ =  x0;
  goto assocx__for__set__tmake_3_21;
  };
  goto assocx__for__set__tmake_3_21;
 case ATOMIC:
  if (a0 != NILATOM) goto assocx__for__set__tmake_3_21;
  allocp[0] = makesym(functor_no_1);
  allocp[1] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,assocx__for__set__tmake_3_1);
  *reasonp++ =  a0;
  goto assocx__for__set__tmake_3_21;
  };
  goto assocx__for__set__tmake_3_21;
 assocx__for__set__tmake_3_21:
  otherwise(assocx__for__set__tmake_3_interrupt);
 assocx__for__set__tmake_3_22:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(assocx__for__set__tmake_3_0);
  goto assocx__for__set__tmake_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,assocx__for__set__tmake_3_22);
  *reasonp++ =  a0;
  goto assocx__for__set__tmake_3_interrupt;
  };
  goto assocx__for__set__tmake_3_interrupt;
 assocx__for__set__tmake_3_ext_interrupt:
  reasonp = 0l;
 assocx__for__set__tmake_3_interrupt:
  toppred = &predicate_klic__comp__generate_xassocx__for__set__tmake_3;
  goto interrupt_3;
 }

 reverse_3_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 reverse_3_clear_reason:
  reasonp = reasons;
 reverse_3_0:
 reverse_3_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xreverse_3);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = NILATOM;
  allocp[6] = car_of(a0);
  x2 = makecons(&allocp[5]);
  a0 = x2;
  a2 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(append_3_0);
  goto append_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto reverse_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,reverse_3_1);
  *reasonp++ =  a0;
  goto reverse_3_interrupt;
  };
  goto reverse_3_interrupt;
 reverse_3_ext_interrupt:
  reasonp = 0l;
 reverse_3_interrupt:
  goto interrupt_3;
 }

 append_3_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 append_3_clear_reason:
  reasonp = reasons;
 append_3_0:
 append_3_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = car_of(a0);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  a0 = cdr_of(a0);
  a2 = x1;
  execute(append_3_0);
  goto append_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto append_3_interrupt;
  unify(a1, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,append_3_1);
  *reasonp++ =  a0;
  goto append_3_interrupt;
  };
  goto append_3_interrupt;
 append_3_ext_interrupt:
  reasonp = 0l;
 append_3_interrupt:
  toppred = &predicate_klic__comp__generate_xappend_3;
  goto interrupt_3;
 }

 count__arity__of__normal__call_6_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 count__arity__of__normal__call_6_clear_reason:
  reasonp = reasons;
 count__arity__of__normal__call_6_0:
 count__arity__of__normal__call_6_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 count__arity__of__normal__call_6_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_thread__top)) goto count__arity__of__normal__call_6_5;
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = makesym(atom_thread__top);
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a3, x1);
  a0 = cdr_of(a0);
  a1 = makeint(0L);
  a3 = x2;
  execute(count__arity__of__normal__call_6_0);
  goto count__arity__of__normal__call_6_ext_interrupt;
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_makethread_2:
  allocp[0] = makesym(functor_makethread_2);
  allocp[1] = arg(x0, 0);
  allocp[2] = arg(x0, 1);
  x1 = makefunctor(&allocp[0]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x1;
  x2 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a3, x2);
  a0 = cdr_of(a0);
  a3 = x3;
  execute(count__arity__of__normal__call_6_0);
  goto count__arity__of__normal__call_6_ext_interrupt;
 case functor_thread__tail_1:
  allocp[0] = makesym(functor_thread__tail_2);
  allocp[1] = arg(x0, 0);
  allocp[2] = a1;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x1;
  x2 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a3, x2);
  a0 = cdr_of(a0);
  a1 = makeint(0L);
  a3 = x3;
  execute(count__arity__of__normal__call_6_0);
  goto count__arity__of__normal__call_6_ext_interrupt;
 case functor_call_3:
  x1 = cdr_of(a0);
 count__arity__of__normal__call_6_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto count__arity__of__normal__call_6_5;
  allocp[0] = makesym(functor_stack__check_1);
  allocp[1] = a1;
  x2 = makefunctor(&allocp[0]);
  allocp[2] = a5;
  allocp[3] = x2;
  x3 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a4, x3);
  unify(a2, a1);
  allocp[0] = makesym(functor_call_4);
  allocp[1] = arg(x0, 0);
  allocp[2] = arg(x0, 1);
  allocp[3] = arg(x0, 2);
  allocp[4] = a1;
  x4 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x4;
  x5 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a3, x5);
  proceed();
 case VARREF:
  deref_and_jump(x1,count__arity__of__normal__call_6_3);
  *reasonp++ =  x1;
  goto count__arity__of__normal__call_6_5;
  };
  goto count__arity__of__normal__call_6_5;
 case functor_tcall_3:
  x1 = cdr_of(a0);
 count__arity__of__normal__call_6_4:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto count__arity__of__normal__call_6_5;
  unify2(a5, a4, a2, a1);
  allocp[0] = makesym(functor_tcall_4);
  allocp[1] = arg(x0, 0);
  allocp[2] = arg(x0, 1);
  allocp[3] = arg(x0, 2);
  allocp[4] = a1;
  x2 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x2;
  x3 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a3, x3);
  proceed();
 case VARREF:
  deref_and_jump(x1,count__arity__of__normal__call_6_4);
  *reasonp++ =  x1;
  goto count__arity__of__normal__call_6_5;
  };
  goto count__arity__of__normal__call_6_5;
  };
  goto count__arity__of__normal__call_6_5;
 case VARREF:
  deref_and_jump(x0,count__arity__of__normal__call_6_2);
  *reasonp++ =  x0;
  goto count__arity__of__normal__call_6_5;
  };
  goto count__arity__of__normal__call_6_5;
 case ATOMIC:
  if (a0 != NILATOM) goto count__arity__of__normal__call_6_5;
  allocp[0] = makesym(functor_stack__check_1);
  allocp[1] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = a5;
  allocp[3] = x0;
  x1 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a4, x1);
  unify(a2, a1);
  unify_value(a3, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a0,count__arity__of__normal__call_6_1);
  *reasonp++ =  a0;
  goto count__arity__of__normal__call_6_5;
  };
  goto count__arity__of__normal__call_6_5;
 count__arity__of__normal__call_6_5:
  otherwise(count__arity__of__normal__call_6_interrupt);
 count__arity__of__normal__call_6_6:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 count__arity__of__normal__call_6_7:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_call_3:
  allocp[0] = makesym(functor_call_4);
  allocp[1] = arg(x0, 0);
  allocp[2] = arg(x0, 1);
  allocp[3] = arg(x0, 2);
  allocp[4] = a1;
  x1 = makefunctor(&allocp[0]);
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = x1;
  x2 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a3, x2);
  x4 = arg(x0, 1);
  bblt_add(a1,x4,x5);
  bblt_add_no_check_y(x5,makeint(1L),x6);
  a0 = cdr_of(a0);
  a1 = x6;
  a3 = x3;
  execute(count__arity__of__normal__call_6_0);
  goto count__arity__of__normal__call_6_ext_interrupt;
 case functor_xcall_4:
  allocp[0] = makesym(functor_xcall_5);
  allocp[1] = arg(x0, 0);
  allocp[2] = arg(x0, 1);
  allocp[3] = arg(x0, 2);
  allocp[4] = arg(x0, 3);
  allocp[5] = a1;
  x1 = makefunctor(&allocp[0]);
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = x1;
  x2 = makecons(&allocp[6]);
  allocp += 8;
  unify_value(a3, x2);
  x4 = arg(x0, 2);
  bblt_add(a1,x4,x5);
  bblt_add_no_check_y(x5,makeint(1L),x6);
  a0 = cdr_of(a0);
  a1 = x6;
  a3 = x3;
  execute(count__arity__of__normal__call_6_0);
  goto count__arity__of__normal__call_6_ext_interrupt;
 case functor_tcall_3:
  allocp[0] = makesym(functor_tcall_4);
  allocp[1] = arg(x0, 0);
  allocp[2] = arg(x0, 1);
  allocp[3] = arg(x0, 2);
  allocp[4] = a1;
  x1 = makefunctor(&allocp[0]);
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = x1;
  x2 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a3, x2);
  x4 = arg(x0, 1);
  bblt_add(a1,x4,x5);
  bblt_add_no_check_y(x5,makeint(1L),x6);
  a0 = cdr_of(a0);
  a1 = x6;
  a3 = x3;
  execute(count__arity__of__normal__call_6_0);
  goto count__arity__of__normal__call_6_ext_interrupt;
 case functor_xtcall_4:
  allocp[0] = makesym(functor_xtcall_5);
  allocp[1] = arg(x0, 0);
  allocp[2] = arg(x0, 1);
  allocp[3] = arg(x0, 2);
  allocp[4] = arg(x0, 3);
  allocp[5] = a1;
  x1 = makefunctor(&allocp[0]);
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = x1;
  x2 = makecons(&allocp[6]);
  allocp += 8;
  unify_value(a3, x2);
  x4 = arg(x0, 2);
  bblt_add(a1,x4,x5);
  bblt_add_no_check_y(x5,makeint(1L),x6);
  a0 = cdr_of(a0);
  a1 = x6;
  a3 = x3;
  execute(count__arity__of__normal__call_6_0);
  goto count__arity__of__normal__call_6_ext_interrupt;
 case functor_loop_3:
  x1 = cdr_of(a0);
 count__arity__of__normal__call_6_8:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto count__arity__of__normal__call_6_9;
  allocp[0] = makesym(functor_stack__check_1);
  allocp[1] = a1;
  x2 = makefunctor(&allocp[0]);
  allocp[2] = a5;
  allocp[3] = x2;
  x3 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a4, x3);
  unify(a2, a1);
  allocp[0] = makesym(functor_loop_4);
  allocp[1] = arg(x0, 0);
  allocp[2] = arg(x0, 1);
  allocp[3] = arg(x0, 2);
  allocp[4] = a1;
  x4 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x4;
  x5 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a3, x5);
  proceed();
 case VARREF:
  deref_and_jump(x1,count__arity__of__normal__call_6_8);
  *reasonp++ =  x1;
  goto count__arity__of__normal__call_6_9;
  };
  goto count__arity__of__normal__call_6_9;
  };
  goto count__arity__of__normal__call_6_9;
 case VARREF:
  deref_and_jump(x0,count__arity__of__normal__call_6_7);
  *reasonp++ =  x0;
  goto count__arity__of__normal__call_6_9;
  };
  goto count__arity__of__normal__call_6_9;
 case VARREF:
  deref_and_jump(a0,count__arity__of__normal__call_6_6);
  *reasonp++ =  a0;
  goto count__arity__of__normal__call_6_9;
  };
  goto count__arity__of__normal__call_6_9;
 count__arity__of__normal__call_6_9:
  otherwise(count__arity__of__normal__call_6_interrupt);
 count__arity__of__normal__call_6_10:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 count__arity__of__normal__call_6_11:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_loop_3:
  allocp[0] = makesym(functor_loop_4);
  allocp[1] = arg(x0, 0);
  allocp[2] = arg(x0, 1);
  allocp[3] = arg(x0, 2);
  allocp[4] = a1;
  x1 = makefunctor(&allocp[0]);
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = x1;
  x2 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a3, x2);
  x4 = arg(x0, 1);
  bblt_add(a1,x4,x5);
  bblt_add_no_check_y(x5,makeint(2L),x6);
  a0 = cdr_of(a0);
  a1 = x6;
  a3 = x3;
  execute(count__arity__of__normal__call_6_0);
  goto count__arity__of__normal__call_6_ext_interrupt;
 case functor_xloop_4:
  allocp[0] = makesym(functor_xloop_5);
  allocp[1] = arg(x0, 0);
  allocp[2] = arg(x0, 1);
  allocp[3] = arg(x0, 2);
  allocp[4] = arg(x0, 3);
  allocp[5] = a1;
  x1 = makefunctor(&allocp[0]);
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = x1;
  x2 = makecons(&allocp[6]);
  allocp += 8;
  unify_value(a3, x2);
  x4 = arg(x0, 2);
  bblt_add(a1,x4,x5);
  bblt_add_no_check_y(x5,makeint(2L),x6);
  a0 = cdr_of(a0);
  a1 = x6;
  a3 = x3;
  execute(count__arity__of__normal__call_6_0);
  goto count__arity__of__normal__call_6_ext_interrupt;
  };
  goto count__arity__of__normal__call_6_12;
 case VARREF:
  deref_and_jump(x0,count__arity__of__normal__call_6_11);
  *reasonp++ =  x0;
  goto count__arity__of__normal__call_6_12;
  };
  goto count__arity__of__normal__call_6_12;
 case VARREF:
  deref_and_jump(a0,count__arity__of__normal__call_6_10);
  *reasonp++ =  a0;
  goto count__arity__of__normal__call_6_12;
  };
  goto count__arity__of__normal__call_6_12;
 count__arity__of__normal__call_6_12:
  otherwise(count__arity__of__normal__call_6_interrupt);
 count__arity__of__normal__call_6_13:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = car_of(a0);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a3, x0);
  a0 = cdr_of(a0);
  a3 = x1;
  execute(count__arity__of__normal__call_6_0);
  goto count__arity__of__normal__call_6_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,count__arity__of__normal__call_6_13);
  *reasonp++ =  a0;
  goto count__arity__of__normal__call_6_interrupt;
  };
  goto count__arity__of__normal__call_6_interrupt;
 count__arity__of__normal__call_6_ext_interrupt:
  reasonp = 0l;
 count__arity__of__normal__call_6_interrupt:
  goto interrupt_6;
 }
 interrupt_20:
  allocp[21] = a19;
 interrupt_19:
  allocp[20] = a18;
 interrupt_18:
  allocp[19] = a17;
 interrupt_17:
  allocp[18] = a16;
 interrupt_16:
  allocp[17] = a15;
 interrupt_15:
  allocp[16] = a14;
 interrupt_14:
  allocp[15] = a13;
 interrupt_13:
  allocp[14] = a12;
 interrupt_12:
  allocp[13] = a11;
 interrupt_11:
  allocp[12] = a10;
 interrupt_10:
  allocp[11] = a9;
 interrupt_9:
  allocp[10] = a8;
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_klic__comp__generate);
}
