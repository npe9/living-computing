/* ----------------------------------------------------------
%        Copyright (C) 1996-1997 Kazuhiko Ohno, Masahiko Ikawa,
%        and Computer Architecture Laboratory, Depertment of
%        Information Science, Kyoto University.
%----------------------------------------------------------- */  

/* ---------------------------------------------------------- 
%   (C)1993 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */

struct prioqrec
*more_priorec();

#ifdef SCHED
extern module topsucceed();
extern struct threadrec * enqueue_thread();
extern struct threadrec * get_top_priority_queue();
void put_top_priority_queue();
#else
extern module topsucceed();
extern struct goalrec * enqueue_goal();
extern struct goalrec * get_top_priority_queue();
void put_top_priority_queue();
#endif
 
