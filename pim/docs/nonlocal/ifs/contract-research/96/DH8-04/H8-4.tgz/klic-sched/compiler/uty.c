/* Compiled by KLIC compiler version 2.002 (Tue May 23 13:27:38 JST 1995) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_uty();
Const struct predicate predicate_uty_xnew__functor__init_4 =
   { module_uty, 0, 4 };
Const struct predicate predicate_uty_xnew__functor__init1_4 =
   { module_uty, 1, 4 };
Const struct predicate predicate_uty_xcreate__functor_3 =
   { module_uty, 2, 3 };
Const struct predicate predicate_uty_xcreate__functor1_4 =
   { module_uty, 3, 4 };
Const struct predicate predicate_uty_xmax_3 =
   { module_uty, 4, 3 };
extern Const struct predicate predicate_list_xcount__element_2;
extern Const struct predicate predicate_integer__arithmetics_xadd_3;
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_functor__table_xnew__functor_3;
extern Const struct predicate predicate_functor__table_xsetarg_4;

module module_uty(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  q a0, a1, a2, a3;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  switch_on_pred() {
    case_pred(0, new__functor__init_4_top);
    case_pred(1, new__functor__init1_4_top);
    case_pred(2, create__functor_3_top);
    case_pred(3, create__functor1_4_top);
    last_case_pred(4, max_3_top);
  }

 new__functor__init_4_top: {
  q x0;
  a3 = qp->args[3];
  qp = qp->next;
 new__functor__init_4_clear_reason:
  reasonp = reasons;
 new__functor__init_4_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_uty_xnew__functor__init1_4);
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xnew__functor_3);
  allocp[8] = x0;
  allocp[9] = a0;
  allocp[10] = a1;
  qp = (struct goalrec*)&allocp[6];
  allocp += 11;
  proceed();
 new__functor__init_4_ext_interrupt:
  reasonp = 0l;
 new__functor__init_4_interrupt:
  goto interrupt_4;
 }

 new__functor__init1_4_top: {
  q x0, x1;
  a3 = qp->args[3];
  qp = qp->next;
 new__functor__init1_4_clear_reason:
  reasonp = reasons;
 new__functor__init1_4_0:
 new__functor__init1_4_1:
  if (!isint(a0)) goto new__functor__init1_4_3;
  gblt_greater(a0,makeint(0L),new__functor__init1_4_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_uty_xnew__functor__init1_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x0;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[13] = a0;
  allocp[14] = a2;
  allocp[15] = a1;
  allocp[16] = x1;
  qp = (struct goalrec*)&allocp[11];
  allocp += 17;
  proceed();
 new__functor__init1_4_2:
  if (a0 != makeint(0L)) goto new__functor__init1_4_interrupt;
  unify(a3, a2);
  proceed();
 new__functor__init1_4_3:
  if (!isref(a0)) goto new__functor__init1_4_interrupt;
  deref_and_jump(a0,new__functor__init1_4_1);
  *reasonp++ =  a0;
  goto new__functor__init1_4_interrupt;
 new__functor__init1_4_ext_interrupt:
  reasonp = 0l;
 new__functor__init1_4_interrupt:
  goto interrupt_4;
 }

 create__functor_3_top: {
  q x0, x1;
  qp = qp->next;
 create__functor_3_clear_reason:
  reasonp = reasons;
 create__functor_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_uty_xcreate__functor1_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = makeint(1L);
  allocp[5] = a2;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xnew__functor_3);
  allocp[8] = x0;
  allocp[9] = a0;
  allocp[10] = x1 = makeref(&allocp[10]);
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_list_xcount__element_2);
  allocp[13] = a1;
  allocp[14] = x1;
  qp = (struct goalrec*)&allocp[11];
  allocp += 15;
  proceed();
 create__functor_3_ext_interrupt:
  reasonp = 0l;
 create__functor_3_interrupt:
  goto interrupt_3;
 }

 create__functor1_4_top: {
  q x0, x1, x2, x3;
  a3 = qp->args[3];
  qp = qp->next;
 create__functor1_4_clear_reason:
  reasonp = reasons;
 create__functor1_4_0:
 create__functor1_4_1:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_uty_xcreate__functor1_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  x1 = cdr_of(a1);
  allocp[3] = x1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[8] = a2;
  allocp[9] = makeint(1L);
  allocp[10] = x2;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[13] = a2;
  allocp[14] = a0;
  x3 = car_of(a1);
  allocp[15] = x3;
  allocp[16] = x0;
  qp = (struct goalrec*)&allocp[11];
  allocp += 17;
  proceed();
 case ATOMIC:
  if (a1 != NILATOM) goto create__functor1_4_interrupt;
  unify(a3, a0);
  proceed();
 case VARREF:
  deref_and_jump(a1,create__functor1_4_1);
  *reasonp++ =  a1;
  goto create__functor1_4_interrupt;
  };
  goto create__functor1_4_interrupt;
 create__functor1_4_ext_interrupt:
  reasonp = 0l;
 create__functor1_4_interrupt:
  goto interrupt_4;
 }

 max_3_top: {
  qp = qp->next;
 max_3_clear_reason:
  reasonp = reasons;
 max_3_0:
 max_3_1:
  if (!isint(a0)) goto max_3_5;
 max_3_2:
  if (!isint(a1)) goto max_3_4;
  gblt_greater_or_eq(a0,a1,max_3_3);
  unify_value(a2, a0);
  proceed();
 max_3_3:
  gblt_less(a0,a1,max_3_interrupt);
  unify_value(a2, a1);
  proceed();
 max_3_4:
  if (!isref(a1)) goto max_3_interrupt;
  deref_and_jump(a1,max_3_2);
  *reasonp++ =  a1;
  goto max_3_interrupt;
 max_3_5:
  if (!isref(a0)) goto max_3_interrupt;
  deref_and_jump(a0,max_3_1);
  *reasonp++ =  a0;
  goto max_3_interrupt;
 max_3_ext_interrupt:
  reasonp = 0l;
 max_3_interrupt:
  goto interrupt_3;
 }
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_uty);
}
