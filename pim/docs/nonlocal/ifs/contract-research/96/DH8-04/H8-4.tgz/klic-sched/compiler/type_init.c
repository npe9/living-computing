/* Compiled by KLIC compiler version 2.002 (Tue May 23 13:27:38 JST 1995) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_type__init();
Const struct predicate predicate_type__init_xcheck__builtin__modules_6 =
   { module_type__init, 0, 6 };
Const struct predicate predicate_type__init_xcheck__builtin__clauses_7 =
   { module_type__init, 1, 7 };
Const struct predicate predicate_type__init_xcheck__builtin__clauses1_9 =
   { module_type__init, 2, 9 };
Const struct predicate predicate_type__init_xcheck__builtin__clause_8 =
   { module_type__init, 3, 8 };
Const struct predicate predicate_type__init_xcheck__builtin__goals_11 =
   { module_type__init, 4, 11 };
Const struct predicate predicate_type__init_xcheck__builtin__goals1_13 =
   { module_type__init, 5, 13 };
Const struct predicate predicate_type__init_xcreate__userdef__waits_4 =
   { module_type__init, 6, 4 };
Const struct predicate predicate_type__init_xcreate__userdef__waits1_4 =
   { module_type__init, 7, 4 };
Const struct predicate predicate_type__init_xcreate__userdef__waits2_3 =
   { module_type__init, 8, 3 };
Const struct predicate predicate_type__init_xcheck__builtin__goal_12 =
   { module_type__init, 9, 12 };
Const struct predicate predicate_type__init_xcheck__builtin__goal1_15 =
   { module_type__init, 10, 15 };
Const struct predicate predicate_type__init_xbuiltin__type_17 =
   { module_type__init, 11, 17 };
Const struct predicate predicate_type__init_xbuiltin__type__unify_15 =
   { module_type__init, 12, 15 };
Const struct predicate predicate_type__init_xcreate__goal__wait_4 =
   { module_type__init, 13, 4 };
Const struct predicate predicate_type__init_xcreate__goal__wait1_6 =
   { module_type__init, 14, 6 };
Const struct predicate predicate_type__init_xcreate__wait_4 =
   { module_type__init, 15, 4 };
Const struct predicate predicate_type__init_xcreate__functor__wait_4 =
   { module_type__init, 16, 4 };
Const struct predicate predicate_type__init_xcreate__functor__wait_5 =
   { module_type__init, 17, 5 };
extern Const struct predicate predicate_print_xdata_1;
extern Const struct predicate predicate_print_xdatan_1;
extern Const struct predicate predicate_mode_xset__goal__modes_6;
extern Const struct predicate predicate_mode_xset__arg__mode_6;
extern Const struct predicate predicate_integer__arithmetics_xadd_3;
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_functor__table_xfunctor_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_xsetarg_4;
extern Const struct predicate predicate_uty_xnew__functor__init_4;
extern Const struct predicate predicate_parse__uty_xdecode__goal_3;
extern Const struct predicate predicate_parse__uty_xencode__goal_4;
extern Const struct predicate predicate_builtin__type_xupdate__type__functor_4;
extern Const struct predicate predicate_builtin__type_xupdate__type__arg_4;
extern Const struct predicate predicate_builtin__type_xupdate__type__new__functor_4;
extern Const struct predicate predicate_builtin__type_xupdate__type__setarg_6;
extern Const struct predicate predicate_builtin__type_xupdate__type__new__vector_4;
extern Const struct predicate predicate_builtin__type_xupdate__type__element_4;
extern Const struct predicate predicate_type_xset__types_11;
extern Const struct predicate predicate_type_xget__arg__types_5;
extern Const struct predicate predicate_type_xtype2int_2;
extern Const struct predicate predicate_type_xtype2atom_2;
extern Const struct predicate predicate_type_xtype2structtype_2;
extern Const struct predicate predicate_type_xtype2list_2;
extern Const struct predicate predicate_type_xvalue2types_7;
extern Const struct predicate predicate_atom__table_xmake__atom_2;
extern Const struct predicate predicate_atom__table_xget__atom__string_2;

module module_type__init(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  static Const q cons_const_0[] = {
    NILATOM,
    makesym(atom_n),
  };
  static Const q cons_const_1[] = {
    NILATOM,
    makesym(atom_n),
  };
  static Const q cons_const_2[] = {
    makecons(cons_const_1),
    makesym(atom_n),
  };
  static Const q funct_const_3[] = {
    makesym(functor_d_1),
    makeint(1),
  };
  static Const q cons_const_4[] = {
    NILATOM,
    makefunctor(funct_const_3),
  };
  static Const q funct_const_5[] = {
    makesym(functor_d_1),
    makeint(1),
  };
  static Const q cons_const_6[] = {
    makecons(cons_const_4),
    makefunctor(funct_const_5),
  };
  static Const q cons_const_7[] = {
    makecons(cons_const_6),
    makesym(atom_n),
  };
  static Const q cons_const_8[] = {
    NILATOM,
    makesym(atom_o),
  };
  static Const q cons_const_9[] = {
    NILATOM,
    makesym(atom_o),
  };
  static Const q cons_const_10[] = {
    makecons(cons_const_9),
    makesym(atom_o),
  };
  static Const q cons_const_11[] = {
    NILATOM,
    makesym(atom_i),
  };
  static Const q cons_const_12[] = {
    makecons(cons_const_11),
    makesym(atom_i),
  };
  static Const q cons_const_13[] = {
    makecons(cons_const_12),
    makesym(atom_o),
  };
  static Const q cons_const_14[] = {
    NILATOM,
    makesym(atom_i),
  };
  static Const q cons_const_15[] = {
    NILATOM,
    makesym(atom_o),
  };
  static Const q cons_const_16[] = {
    makecons(cons_const_15),
    makesym(atom_i),
  };
  static Const q cons_const_17[] = {
    NILATOM,
    makesym(atom_o),
  };
  static Const q cons_const_18[] = {
    makecons(cons_const_17),
    makesym(atom_o),
  };
  static Const q cons_const_19[] = {
    makecons(cons_const_18),
    makesym(atom_i),
  };
  static Const q cons_const_20[] = {
    NILATOM,
    makesym(atom_i),
  };
  static Const q cons_const_21[] = {
    makecons(cons_const_20),
    makesym(atom_o),
  };
  static Const q cons_const_22[] = {
    makecons(cons_const_21),
    makesym(atom_i),
  };
  static Const q cons_const_23[] = {
    NILATOM,
    makesym(atom_i),
  };
  static Const q cons_const_24[] = {
    makecons(cons_const_23),
    makesym(atom_i),
  };
  static Const q cons_const_25[] = {
    NILATOM,
    makesym(atom_o),
  };
  static Const q cons_const_26[] = {
    makecons(cons_const_25),
    makesym(atom_i),
  };
  static Const q cons_const_27[] = {
    makecons(cons_const_26),
    makesym(atom_i),
  };
  static Const q cons_const_28[] = {
    NILATOM,
    makesym(atom_o),
  };
  static Const q cons_const_29[] = {
    makecons(cons_const_28),
    makesym(atom_i),
  };
  static Const q cons_const_30[] = {
    makecons(cons_const_29),
    makesym(atom_o),
  };
  static Const q cons_const_31[] = {
    makecons(cons_const_30),
    makesym(atom_i),
  };
  static Const q cons_const_32[] = {
    makecons(cons_const_31),
    makesym(atom_i),
  };
  static Const q cons_const_33[] = {
    NILATOM,
    makesym(atom_o),
  };
  static Const q cons_const_34[] = {
    makecons(cons_const_33),
    makesym(atom_i),
  };
  static Const q cons_const_35[] = {
    makecons(cons_const_34),
    makesym(atom_i),
  };
  static Const q cons_const_36[] = {
    makecons(cons_const_35),
    makesym(atom_i),
  };
  static Const q funct_const_37[] = {
    makesym(functor_d_1),
    makeint(1),
  };
  static Const q cons_const_38[] = {
    NILATOM,
    makefunctor(funct_const_37),
  };
  static Const q cons_const_39[] = {
    NILATOM,
    makesym(atom_n),
  };
  static Const q funct_const_40[] = {
    makesym(functor_d_1),
    makeint(1),
  };
  static Const q cons_const_41[] = {
    makecons(cons_const_39),
    makefunctor(funct_const_40),
  };
  static Const q cons_const_42[] = {
    NILATOM,
    makesym(atom_n),
  };
  static Const q cons_const_43[] = {
    makecons(cons_const_42),
    makesym(atom_n),
  };
  static Const q funct_const_44[] = {
    makesym(functor_d_1),
    makeint(1),
  };
  static Const q cons_const_45[] = {
    makecons(cons_const_43),
    makefunctor(funct_const_44),
  };
  static Const q funct_const_46[] = {
    makesym(functor_d_1),
    makeint(1),
  };
  static Const q cons_const_47[] = {
    NILATOM,
    makefunctor(funct_const_46),
  };
  static Const q cons_const_48[] = {
    makecons(cons_const_47),
    makesym(atom_n),
  };
  static Const q funct_const_49[] = {
    makesym(functor_d_1),
    makeint(1),
  };
  static Const q cons_const_50[] = {
    makecons(cons_const_48),
    makefunctor(funct_const_49),
  };
  static Const q funct_const_51[] = {
    makesym(functor_d_1),
    makeint(1),
  };
  static Const q cons_const_52[] = {
    NILATOM,
    makefunctor(funct_const_51),
  };
  static Const q funct_const_53[] = {
    makesym(functor_d_1),
    makeint(1),
  };
  static Const q cons_const_54[] = {
    makecons(cons_const_52),
    makefunctor(funct_const_53),
  };
  static Const q cons_const_55[] = {
    NILATOM,
    makesym(atom_n),
  };
  static Const q funct_const_56[] = {
    makesym(functor_d_1),
    makeint(1),
  };
  static Const q cons_const_57[] = {
    makecons(cons_const_55),
    makefunctor(funct_const_56),
  };
  static Const q funct_const_58[] = {
    makesym(functor_d_1),
    makeint(1),
  };
  static Const q cons_const_59[] = {
    makecons(cons_const_57),
    makefunctor(funct_const_58),
  };
  static Const q cons_const_60[] = {
    NILATOM,
    makesym(atom_n),
  };
  static Const q funct_const_61[] = {
    makesym(functor_d_1),
    makeint(1),
  };
  static Const q cons_const_62[] = {
    makecons(cons_const_60),
    makefunctor(funct_const_61),
  };
  static Const q cons_const_63[] = {
    makecons(cons_const_62),
    makesym(atom_n),
  };
  static Const q funct_const_64[] = {
    makesym(functor_d_1),
    makeint(1),
  };
  static Const q cons_const_65[] = {
    makecons(cons_const_63),
    makefunctor(funct_const_64),
  };
  static Const q funct_const_66[] = {
    makesym(functor_d_1),
    makeint(1),
  };
  static Const q cons_const_67[] = {
    makecons(cons_const_65),
    makefunctor(funct_const_66),
  };
  static Const q cons_const_68[] = {
    NILATOM,
    makesym(atom_n),
  };
  static Const q funct_const_69[] = {
    makesym(functor_d_1),
    makeint(1),
  };
  static Const q cons_const_70[] = {
    makecons(cons_const_68),
    makefunctor(funct_const_69),
  };
  static Const q funct_const_71[] = {
    makesym(functor_d_1),
    makeint(1),
  };
  static Const q cons_const_72[] = {
    makecons(cons_const_70),
    makefunctor(funct_const_71),
  };
  static Const q funct_const_73[] = {
    makesym(functor_d_1),
    makeint(1),
  };
  static Const q cons_const_74[] = {
    makecons(cons_const_72),
    makefunctor(funct_const_73),
  };
  static Const q cons_const_75[] = {
    NILATOM,
    makesym(atom_n),
  };
  static Const q funct_const_76[] = {
    makesym(functor_d_1),
    makesym(atom_n),
  };
  static Const q cons_const_77[] = {
    makecons(cons_const_75),
    makefunctor(funct_const_76),
  };
  static Const q funct_const_78[] = {
    makesym(functor_d_1),
    makeint(1),
  };
  static Const q cons_const_79[] = {
    makecons(cons_const_77),
    makefunctor(funct_const_78),
  };
  static Const q funct_const_80[] = {
    makesym(functor_d_1),
    makesym(atom_n),
  };
  static Const q cons_const_81[] = {
    NILATOM,
    makefunctor(funct_const_80),
  };
  static Const q cons_const_82[] = {
    NILATOM,
    makesym(atom_n),
  };
  static Const q funct_const_83[] = {
    makesym(functor_d_1),
    makesym(atom_n),
  };
  static Const q cons_const_84[] = {
    makecons(cons_const_82),
    makefunctor(funct_const_83),
  };
  static Const q cons_const_85[] = {
    NILATOM,
    makesym(atom_n),
  };
  static Const q funct_const_86[] = {
    makesym(functor_d_1),
    makeint(1),
  };
  static Const q cons_const_87[] = {
    makecons(cons_const_85),
    makefunctor(funct_const_86),
  };
  static Const q funct_const_88[] = {
    makesym(functor_d_1),
    makesym(atom_n),
  };
  static Const q cons_const_89[] = {
    makecons(cons_const_87),
    makefunctor(funct_const_88),
  };
  static Const q cons_const_90[] = {
    NILATOM,
    makesym(atom_n),
  };
  static Const q funct_const_91[] = {
    makesym(functor_d_1),
    makesym(atom_n),
  };
  static Const q cons_const_92[] = {
    makecons(cons_const_90),
    makefunctor(funct_const_91),
  };
  static Const q funct_const_93[] = {
    makesym(functor_d_1),
    makesym(atom_n),
  };
  static Const q cons_const_94[] = {
    makecons(cons_const_92),
    makefunctor(funct_const_93),
  };
  q a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  switch_on_pred() {
    case_pred(0, check__builtin__modules_6_top);
    case_pred(1, check__builtin__clauses_7_top);
    case_pred(2, check__builtin__clauses1_9_top);
    case_pred(3, check__builtin__clause_8_top);
    case_pred(4, check__builtin__goals_11_top);
    case_pred(5, check__builtin__goals1_13_top);
    case_pred(6, create__userdef__waits_4_top);
    case_pred(7, create__userdef__waits1_4_top);
    case_pred(8, create__userdef__waits2_3_top);
    case_pred(9, check__builtin__goal_12_top);
    case_pred(10, check__builtin__goal1_15_top);
    case_pred(11, builtin__type_17_top);
    case_pred(12, builtin__type__unify_15_top);
    case_pred(13, create__goal__wait_4_top);
    case_pred(14, create__goal__wait1_6_top);
    case_pred(15, create__wait_4_top);
    case_pred(16, create__functor__wait_4_top);
    last_case_pred(17, create__functor__wait_5_top);
  }

 check__builtin__modules_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 check__builtin__modules_6_clear_reason:
  reasonp = reasons;
 check__builtin__modules_6_0:
 check__builtin__modules_6_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 check__builtin__modules_6_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto check__builtin__modules_6_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type__init_xcheck__builtin__modules_6);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x4 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = makesym(functor_module_2);
  allocp[9] = arg(x0, 0);
  allocp[10] = x6 = makeref(&allocp[10]);
  x5 = makefunctor(&allocp[8]);
  allocp[11] = x2;
  allocp[12] = x5;
  x7 = makecons(&allocp[11]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 13;
  unify_value(a1, x7);
  a0 = arg(x0, 0);
  a1 = arg(x0, 1);
  a3 = a2;
  a5 = a4;
  a6 = x4;
  a4 = x3;
  a2 = x6;
  execute(check__builtin__clauses_7_0);
  goto check__builtin__clauses_7_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,check__builtin__modules_6_2);
  *reasonp++ =  x0;
  goto check__builtin__modules_6_interrupt;
  };
  goto check__builtin__modules_6_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto check__builtin__modules_6_interrupt;
  unify_value(a1, NILATOM);
  unify2(a3, a2, a5, a4);
  proceed();
 case VARREF:
  deref_and_jump(a0,check__builtin__modules_6_1);
  *reasonp++ =  a0;
  goto check__builtin__modules_6_interrupt;
  };
  goto check__builtin__modules_6_interrupt;
 check__builtin__modules_6_ext_interrupt:
  reasonp = 0l;
 check__builtin__modules_6_interrupt:
  goto interrupt_6;
 }

 check__builtin__clauses_7_top: {
  q x0, x1;
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 check__builtin__clauses_7_clear_reason:
  reasonp = reasons;
 check__builtin__clauses_7_0:
 check__builtin__clauses_7_1:
  if (isref(a1)) goto check__builtin__clauses_7_2;
  gblt_pfunctor(a1,x0,check__builtin__clauses_7_interrupt);
  gblt_arity(a1,x1,check__builtin__clauses_7_interrupt);
  a7 = a5;
  a8 = a6;
  a6 = x1;
  a5 = makeint(1L);
  execute(check__builtin__clauses1_9_0);
  goto check__builtin__clauses1_9_ext_interrupt;
 check__builtin__clauses_7_2:
  deref_and_jump(a1,check__builtin__clauses_7_1);
  *reasonp++ =  a1;
  goto check__builtin__clauses_7_interrupt;
 check__builtin__clauses_7_ext_interrupt:
  reasonp = 0l;
 check__builtin__clauses_7_interrupt:
  toppred = &predicate_type__init_xcheck__builtin__clauses_7;
  goto interrupt_7;
 }

 check__builtin__clauses1_9_top: {
  q x0, x1, x2, x3, x4, x5;
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 check__builtin__clauses1_9_clear_reason:
  reasonp = reasons;
 check__builtin__clauses1_9_0:
 check__builtin__clauses1_9_1:
  if (!isint(a5)) goto check__builtin__clauses1_9_5;
 check__builtin__clauses1_9_2:
  if (!isint(a6)) goto check__builtin__clauses1_9_4;
  gblt_less_or_eq(a5,a6,check__builtin__clauses1_9_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type__init_xcheck__builtin__clauses1_9);
  allocp[2] = a0;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = x3 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[13] = a5;
  allocp[14] = makeint(1L);
  allocp[15] = x2;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[18] = a5;
  allocp[19] = a1;
  allocp[20] = x4 = makeref(&allocp[20]);
  allocp[21] = x0;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_type__init_xcheck__builtin__clause_8);
  allocp[24] = a0;
  allocp[25] = a5;
  allocp[26] = x5 = makeref(&allocp[26]);
  allocp[27] = x4;
  allocp[28] = a3;
  allocp[29] = x1;
  allocp[30] = a7;
  allocp[31] = x3;
  allocp[32] = (q)(struct goalrec*)&allocp[22];
  allocp[33] = (q)(&predicate_functor__table_xarg_3);
  allocp[34] = a5;
  allocp[35] = a1;
  allocp[36] = x5;
  qp = (struct goalrec*)&allocp[32];
  allocp += 37;
  proceed();
 check__builtin__clauses1_9_3:
  gblt_greater(a5,a6,check__builtin__clauses1_9_interrupt);
  unify3(a2, a1, a4, a3, a8, a7);
  proceed();
 check__builtin__clauses1_9_4:
  if (!isref(a6)) goto check__builtin__clauses1_9_interrupt;
  deref_and_jump(a6,check__builtin__clauses1_9_2);
  *reasonp++ =  a6;
  goto check__builtin__clauses1_9_interrupt;
 check__builtin__clauses1_9_5:
  if (!isref(a5)) goto check__builtin__clauses1_9_interrupt;
  deref_and_jump(a5,check__builtin__clauses1_9_1);
  *reasonp++ =  a5;
  goto check__builtin__clauses1_9_interrupt;
 check__builtin__clauses1_9_ext_interrupt:
  reasonp = 0l;
 check__builtin__clauses1_9_interrupt:
  toppred = &predicate_type__init_xcheck__builtin__clauses1_9;
  goto interrupt_9;
 }

 check__builtin__clause_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17;
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 check__builtin__clause_8_clear_reason:
  reasonp = reasons;
 check__builtin__clause_8_0:
 check__builtin__clause_8_1:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (isint(a2)) goto check__builtin__clause_8_interrupt;
 check__builtin__clause_8_2:
  gblt_atom(a2,check__builtin__clause_8_interrupt);
  unify_value(a3, a2);
  unify2(a5, a4, a7, a6);
  proceed();
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_clause_6)) goto check__builtin__clause_8_interrupt;
  allocp[0] = makesym(functor_functor_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  x2 = arg(a2, 0);
  allocp += 2;
  unify_value(x2, x0);
  allocp[0] = makesym(functor_clause_6);
  allocp[1] = x4 = makeref(&allocp[1]);
  allocp[2] = x5 = makeref(&allocp[2]);
  allocp[3] = x6 = makeref(&allocp[3]);
  allocp[4] = arg(a2, 3);
  allocp[5] = arg(a2, 4);
  allocp[6] = x7 = makeref(&allocp[6]);
  x3 = makefunctor(&allocp[0]);
  allocp += 7;
  unify_value(a3, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type__init_xcheck__builtin__goals_11);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = makesym(atom_body);
  x8 = arg(a2, 2);
  allocp[5] = x8;
  allocp[6] = x6;
  allocp[7] = x9 = makeref(&allocp[7]);
  allocp[8] = a5;
  allocp[9] = x10 = makeref(&allocp[9]);
  allocp[10] = a7;
  allocp[11] = x11 = makeref(&allocp[11]);
  allocp[12] = x7;
  allocp[13] = (q)(struct goalrec*)&allocp[0];
  allocp[14] = (q)(&predicate_type__init_xcheck__builtin__goals_11);
  allocp[15] = a0;
  allocp[16] = a1;
  allocp[17] = makesym(atom_guard);
  x12 = arg(a2, 1);
  allocp[18] = x12;
  allocp[19] = x5;
  allocp[20] = a4;
  allocp[21] = x9;
  allocp[22] = a6;
  allocp[23] = x10;
  x13 = arg(a2, 5);
  allocp[24] = x13;
  allocp[25] = x11;
  allocp[26] = makesym(functor_functor_3);
  allocp[27] = x1;
  allocp[28] = x15 = makeref(&allocp[28]);
  allocp[29] = makesym(atom_userdef);
  x14 = makefunctor(&allocp[26]);
  qp = (struct goalrec*)&allocp[13];
  allocp += 30;
  unify_value(x4, x14);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type__init_xcreate__userdef__waits_4);
  allocp[2] = x1;
  allocp[3] = x16 = makeref(&allocp[3]);
  allocp[4] = x13;
  allocp[5] = x15;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[8] = x1;
  allocp[9] = x17 = makeref(&allocp[9]);
  allocp[10] = x16;
  qp = (struct goalrec*)&allocp[6];
  allocp += 11;
  proceed();
 case VARREF:
  deref_and_jump(a2,check__builtin__clause_8_1);
  *reasonp++ =  a2;
  goto check__builtin__clause_8_interrupt;
  };
  goto check__builtin__clause_8_interrupt;
 check__builtin__clause_8_ext_interrupt:
  reasonp = 0l;
 check__builtin__clause_8_interrupt:
  goto interrupt_8;
 }

 check__builtin__goals_11_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 check__builtin__goals_11_clear_reason:
  reasonp = reasons;
 check__builtin__goals_11_0:
 check__builtin__goals_11_1:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (isint(a3)) goto check__builtin__goals_11_3;
 check__builtin__goals_11_2:
  gblt_atom(a3,check__builtin__goals_11_3);
  unify_value(a4, a3);
  unify3(a6, a5, a8, a7, a10, a9);
  proceed();
 case VARREF:
  deref_and_jump(a3,check__builtin__goals_11_1);
  *reasonp++ =  a3;
  goto check__builtin__goals_11_interrupt;
  };
  goto check__builtin__goals_11_3;
 check__builtin__goals_11_3:
  gblt_pfunctor(a3,x0,check__builtin__goals_11_interrupt);
  gblt_arity(a3,x1,check__builtin__goals_11_interrupt);
  x2 = a0;
  x3 = a1;
  x4 = a2;
  x5 = a3;
  x6 = a4;
  x7 = a5;
  x8 = a6;
  x9 = a7;
  x10 = a8;
  a11 = a9;
  a12 = a10;
  a10 = x10;
  a9 = x9;
  a8 = x8;
  a7 = x7;
  a6 = x6;
  a5 = x5;
  a4 = x4;
  a3 = x3;
  a2 = x2;
  a1 = x1;
  a0 = makeint(1L);
  execute(check__builtin__goals1_13_0);
  goto check__builtin__goals1_13_ext_interrupt;
 check__builtin__goals_11_ext_interrupt:
  reasonp = 0l;
 check__builtin__goals_11_interrupt:
  goto interrupt_11;
 }

 check__builtin__goals1_13_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  qp = qp->next;
 check__builtin__goals1_13_clear_reason:
  reasonp = reasons;
 check__builtin__goals1_13_0:
 check__builtin__goals1_13_1:
  if (!isint(a0)) goto check__builtin__goals1_13_5;
 check__builtin__goals1_13_2:
  if (!isint(a1)) goto check__builtin__goals1_13_4;
  gblt_less_or_eq(a0,a1,check__builtin__goals1_13_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type__init_xcheck__builtin__goals1_13);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = x3 = makeref(&allocp[11]);
  allocp[12] = a10;
  allocp[13] = x4 = makeref(&allocp[13]);
  allocp[14] = a12;
  allocp[15] = (q)(struct goalrec*)&allocp[0];
  allocp[16] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[17] = a0;
  allocp[18] = makeint(1L);
  allocp[19] = x0;
  allocp[20] = (q)(struct goalrec*)&allocp[15];
  allocp[21] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[22] = a0;
  allocp[23] = a5;
  allocp[24] = x5 = makeref(&allocp[24]);
  allocp[25] = x1;
  allocp[26] = (q)(struct goalrec*)&allocp[20];
  allocp[27] = (q)(&predicate_type__init_xcheck__builtin__goal_12);
  allocp[28] = a2;
  allocp[29] = a3;
  allocp[30] = a0;
  allocp[31] = a4;
  allocp[32] = x6 = makeref(&allocp[32]);
  allocp[33] = x5;
  allocp[34] = a7;
  allocp[35] = x2;
  allocp[36] = a9;
  allocp[37] = x3;
  allocp[38] = a11;
  allocp[39] = x4;
  allocp[40] = (q)(struct goalrec*)&allocp[26];
  allocp[41] = (q)(&predicate_functor__table_xarg_3);
  allocp[42] = a0;
  allocp[43] = a5;
  allocp[44] = x6;
  qp = (struct goalrec*)&allocp[40];
  allocp += 45;
  proceed();
 check__builtin__goals1_13_3:
  gblt_greater(a0,a1,check__builtin__goals1_13_interrupt);
  unify4(a6, a5, a8, a7, a10, a9, a12, a11);
  proceed();
 check__builtin__goals1_13_4:
  if (!isref(a1)) goto check__builtin__goals1_13_interrupt;
  deref_and_jump(a1,check__builtin__goals1_13_2);
  *reasonp++ =  a1;
  goto check__builtin__goals1_13_interrupt;
 check__builtin__goals1_13_5:
  if (!isref(a0)) goto check__builtin__goals1_13_interrupt;
  deref_and_jump(a0,check__builtin__goals1_13_1);
  *reasonp++ =  a0;
  goto check__builtin__goals1_13_interrupt;
 check__builtin__goals1_13_ext_interrupt:
  reasonp = 0l;
 check__builtin__goals1_13_interrupt:
  toppred = &predicate_type__init_xcheck__builtin__goals1_13;
  goto interrupt_13;
 }

 create__userdef__waits_4_top: {
  q x0, x1, x2;
  a3 = qp->args[3];
  qp = qp->next;
 create__userdef__waits_4_clear_reason:
  reasonp = reasons;
 create__userdef__waits_4_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type__init_xcreate__userdef__waits1_4);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_uty_xnew__functor__init_4);
  allocp[8] = makesym(atom_waits);
  allocp[9] = x1 = makeref(&allocp[9]);
  allocp[10] = makesym(atom___);
  allocp[11] = x0;
  allocp[12] = (q)(struct goalrec*)&allocp[6];
  allocp[13] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[14] = a2;
  allocp[15] = x2 = makeref(&allocp[15]);
  allocp[16] = x1;
  qp = (struct goalrec*)&allocp[12];
  allocp += 17;
  proceed();
 create__userdef__waits_4_ext_interrupt:
  reasonp = 0l;
 create__userdef__waits_4_interrupt:
  toppred = &predicate_type__init_xcreate__userdef__waits_4;
  goto interrupt_4;
 }

 create__userdef__waits1_4_top: {
  q x0, x1, x2;
  a3 = qp->args[3];
  qp = qp->next;
 create__userdef__waits1_4_clear_reason:
  reasonp = reasons;
 create__userdef__waits1_4_0:
 create__userdef__waits1_4_1:
  if (!isint(a1)) goto create__userdef__waits1_4_3;
  gblt_greater(a1,makeint(0L),create__userdef__waits1_4_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type__init_xcreate__userdef__waits1_4);
  allocp[2] = a0;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a1;
  allocp[9] = makeint(1L);
  allocp[10] = x0;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_type__init_xcreate__userdef__waits2_3);
  allocp[13] = x2 = makeref(&allocp[13]);
  allocp[14] = a2;
  allocp[15] = x1;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_functor__table_xarg_3);
  allocp[18] = a1;
  allocp[19] = a0;
  allocp[20] = x2;
  qp = (struct goalrec*)&allocp[16];
  allocp += 21;
  proceed();
 create__userdef__waits1_4_2:
  if (a1 != makeint(0L)) goto create__userdef__waits1_4_interrupt;
  unify(a3, a2);
  proceed();
 create__userdef__waits1_4_3:
  if (!isref(a1)) goto create__userdef__waits1_4_interrupt;
  deref_and_jump(a1,create__userdef__waits1_4_1);
  *reasonp++ =  a1;
  goto create__userdef__waits1_4_interrupt;
 create__userdef__waits1_4_ext_interrupt:
  reasonp = 0l;
 create__userdef__waits1_4_interrupt:
  toppred = &predicate_type__init_xcreate__userdef__waits1_4;
  goto interrupt_4;
 }

 create__userdef__waits2_3_top: {
  q x0, x1, x2;
  qp = qp->next;
 create__userdef__waits2_3_clear_reason:
  reasonp = reasons;
 create__userdef__waits2_3_0:
 create__userdef__waits2_3_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_variable_3)) goto create__userdef__waits2_3_2;
  x0 = arg(a0, 0);
  bblt_add_no_check_y(x0,makeint(1L),x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = makesym(atom_n);
  allocp[5] = a2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  proceed();
 case VARREF:
  deref_and_jump(a0,create__userdef__waits2_3_1);
  *reasonp++ =  a0;
  goto create__userdef__waits2_3_2;
  };
  goto create__userdef__waits2_3_2;
 create__userdef__waits2_3_2:
  otherwise(create__userdef__waits2_3_interrupt);
 create__userdef__waits2_3_3:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto create__userdef__waits2_3_5;
 create__userdef__waits2_3_4:
  gblt_atom(a0,create__userdef__waits2_3_5);
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,create__userdef__waits2_3_3);
  *reasonp++ =  a0;
  goto create__userdef__waits2_3_5;
  };
  goto create__userdef__waits2_3_5;
 create__userdef__waits2_3_5:
  otherwise(create__userdef__waits2_3_interrupt);
 create__userdef__waits2_3_6:
  if (isref(a0)) goto create__userdef__waits2_3_7;
  gblt_pfunctor(a0,x0,create__userdef__waits2_3_interrupt);
  gblt_arity(a0,x1,create__userdef__waits2_3_interrupt);
  x2 = a1;
  a3 = a2;
  a2 = x2;
  a1 = x1;
  execute(create__userdef__waits1_4_0);
  goto create__userdef__waits1_4_ext_interrupt;
 create__userdef__waits2_3_7:
  deref_and_jump(a0,create__userdef__waits2_3_6);
  *reasonp++ =  a0;
  goto create__userdef__waits2_3_interrupt;
 create__userdef__waits2_3_ext_interrupt:
  reasonp = 0l;
 create__userdef__waits2_3_interrupt:
  goto interrupt_3;
 }

 check__builtin__goal_12_top: {
  q x0, x1, x2, x3, x4, x5;
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 check__builtin__goal_12_clear_reason:
  reasonp = reasons;
 check__builtin__goal_12_0:
  allocp[0] = makesym(functor_attrs_2);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  x0 = makefunctor(&allocp[0]);
  allocp[3] = (q)qp;
  allocp[4] = (q)(&predicate_parse__uty_xencode__goal_4);
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = x0;
  allocp[7] = x4 = makeref(&allocp[7]);
  allocp[8] = a5;
  allocp[9] = (q)(struct goalrec*)&allocp[3];
  allocp[10] = (q)(&predicate_type__init_xcheck__builtin__goal1_15);
  allocp[11] = a0;
  allocp[12] = a1;
  allocp[13] = a2;
  allocp[14] = a3;
  allocp[15] = x5 = makeref(&allocp[15]);
  allocp[16] = x3;
  allocp[17] = x4;
  allocp[18] = a6;
  allocp[19] = a7;
  allocp[20] = a8;
  allocp[21] = a9;
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = x1;
  allocp[25] = x2;
  allocp[26] = (q)(struct goalrec*)&allocp[9];
  allocp[27] = (q)(&predicate_parse__uty_xdecode__goal_3);
  allocp[28] = a4;
  allocp[29] = x5;
  allocp[30] = x4;
  qp = (struct goalrec*)&allocp[26];
  allocp += 31;
  proceed();
 check__builtin__goal_12_ext_interrupt:
  reasonp = 0l;
 check__builtin__goal_12_interrupt:
  goto interrupt_12;
 }

 check__builtin__goal1_15_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  qp = qp->next;
 check__builtin__goal1_15_clear_reason:
  reasonp = reasons;
 check__builtin__goal1_15_0:
 check__builtin__goal1_15_1:
  switch (ptagof(a6)) {
 case FUNCTOR:
  if (functor_of(a6) != makesym(functor_options_2)) goto check__builtin__goal1_15_5;
  x0 = arg(a6, 0);
 check__builtin__goal1_15_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom___)) goto check__builtin__goal1_15_5;
 check__builtin__goal1_15_3:
  if (isref(a4)) goto check__builtin__goal1_15_4;
  gblt_pfunctor(a4,x1,check__builtin__goal1_15_5);
  gblt_arity(a4,x2,check__builtin__goal1_15_5);
  x3 = a0;
  x4 = a0;
  a6 = x2;
  x5 = a4;
  x6 = a5;
  x7 = a7;
  x8 = a8;
  x9 = a9;
  x10 = a10;
  x11 = a11;
  x12 = a12;
  a15 = a13;
  a16 = a14;
  a14 = x12;
  a13 = x11;
  a12 = x10;
  a11 = x9;
  a10 = x8;
  a9 = x7;
  a8 = x6;
  a7 = x5;
  a5 = x1;
  a4 = x4;
  a0 = x3;
  execute(builtin__type_17_0);
  goto builtin__type_17_ext_interrupt;
 check__builtin__goal1_15_4:
  deref_and_jump(a4,check__builtin__goal1_15_3);
  *reasonp++ =  a4;
  goto check__builtin__goal1_15_5;
 case VARREF:
  deref_and_jump(x0,check__builtin__goal1_15_2);
  *reasonp++ =  x0;
  goto check__builtin__goal1_15_5;
  };
  goto check__builtin__goal1_15_5;
 case VARREF:
  deref_and_jump(a6,check__builtin__goal1_15_1);
  *reasonp++ =  a6;
  goto check__builtin__goal1_15_5;
  };
  goto check__builtin__goal1_15_5;
 check__builtin__goal1_15_5:
  otherwise(check__builtin__goal1_15_interrupt);
 check__builtin__goal1_15_6:
  switch (ptagof(a6)) {
 case FUNCTOR:
  if (functor_of(a6) != makesym(functor_options_2)) goto check__builtin__goal1_15_interrupt;
 check__builtin__goal1_15_7:
  if (isref(a4)) goto check__builtin__goal1_15_8;
  gblt_pfunctor(a4,x0,check__builtin__goal1_15_interrupt);
  gblt_arity(a4,x1,check__builtin__goal1_15_interrupt);
  x2 = arg(a6, 0);
  a6 = x1;
  x3 = a4;
  x4 = a5;
  x5 = a7;
  x6 = a8;
  x7 = a9;
  x8 = a10;
  x9 = a11;
  x10 = a12;
  a15 = a13;
  a16 = a14;
  a14 = x10;
  a13 = x9;
  a12 = x8;
  a11 = x7;
  a10 = x6;
  a9 = x5;
  a8 = x4;
  a7 = x3;
  a5 = x0;
  a4 = x2;
  execute(builtin__type_17_0);
  goto builtin__type_17_ext_interrupt;
 check__builtin__goal1_15_8:
  deref_and_jump(a4,check__builtin__goal1_15_7);
  *reasonp++ =  a4;
  goto check__builtin__goal1_15_interrupt;
 case VARREF:
  deref_and_jump(a6,check__builtin__goal1_15_6);
  *reasonp++ =  a6;
  goto check__builtin__goal1_15_interrupt;
  };
  goto check__builtin__goal1_15_interrupt;
 check__builtin__goal1_15_ext_interrupt:
  reasonp = 0l;
 check__builtin__goal1_15_interrupt:
  goto interrupt_15;
 }

 builtin__type_17_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20, x21, x22, x23, x24, x25, x26, x27, x28, x29, x30, x31, x32, x33, x34, x35;
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  qp = qp->next;
 builtin__type_17_clear_reason:
  reasonp = reasons;
 builtin__type_17_0:
 builtin__type_17_1:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (isint(a5)) goto builtin__type_17_39;
  switch (symval(a5)) {
 case symval(makesym(atom__3D)):
 builtin__type_17_2:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_3:
  if (a6 != makeint(2L)) goto builtin__type_17_39;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = makeint(2L);
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a8;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[8] = makeint(1L);
  allocp[9] = a7;
  allocp[10] = x2 = makeref(&allocp[10]);
  allocp[11] = x0;
  allocp[12] = (q)(struct goalrec*)&allocp[6];
  allocp[13] = (q)(&predicate_type__init_xbuiltin__type__unify_15);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x3 = makeref(&allocp[18]);
  allocp[19] = x2;
  allocp[20] = x4 = makeref(&allocp[20]);
  allocp[21] = x1;
  allocp[22] = a9;
  allocp[23] = a10;
  allocp[24] = a11;
  allocp[25] = a12;
  allocp[26] = a13;
  allocp[27] = a14;
  allocp[28] = a15;
  qp = (struct goalrec*)&allocp[12];
  allocp += 29;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x3;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_2);
  *reasonp++ =  a6;
  goto builtin__type_17_39;
  };
  goto builtin__type_17_39;
 case symval(makesym(atom_wait)):
 builtin__type_17_4:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_5:
  if (a6 != makeint(1L)) goto builtin__type_17_39;
 builtin__type_17_6:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_guard)) goto builtin__type_17_39;
  unify_value(a16, makesym(atom_builtin));
  unify2(a12, a11, a10, a9);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[2] = makecons(cons_const_14);
  allocp[3] = a3;
  allocp[4] = a7;
  allocp[5] = a8;
  allocp[6] = a13;
  allocp[7] = a14;
  a0 = a7;
  a1 = makecons(cons_const_38);
  a2 = a15;
  a3 = a13;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  execute(create__goal__wait_4_0);
  goto create__goal__wait_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a3,builtin__type_17_6);
  *reasonp++ =  a3;
  goto builtin__type_17_39;
  };
  goto builtin__type_17_39;
 case VARREF:
  deref_and_jump(a6,builtin__type_17_4);
  *reasonp++ =  a6;
  goto builtin__type_17_39;
  };
  goto builtin__type_17_39;
 case symval(makesym(atom_compare)):
 builtin__type_17_7:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_8:
  if (a6 != makeint(3L)) goto builtin__type_17_39;
 builtin__type_17_9:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_guard)) goto builtin__type_17_39;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_i);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_27);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_94);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x8 = makeref(&allocp[14]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(a3,builtin__type_17_9);
  *reasonp++ =  a3;
  goto builtin__type_17_39;
  };
  goto builtin__type_17_39;
 case VARREF:
  deref_and_jump(a6,builtin__type_17_7);
  *reasonp++ =  a6;
  goto builtin__type_17_39;
  };
  goto builtin__type_17_39;
 case symval(makesym(atom_diff)):
 builtin__type_17_10:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_11:
  if (a6 != makeint(2L)) goto builtin__type_17_39;
 builtin__type_17_12:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_guard)) goto builtin__type_17_39;
  unify_value(a16, makesym(atom_builtin));
  unify2(a12, a11, a10, a9);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[2] = makecons(cons_const_24);
  allocp[3] = a3;
  allocp[4] = a7;
  allocp[5] = a8;
  allocp[6] = a13;
  allocp[7] = a14;
  a0 = a7;
  a1 = makecons(cons_const_54);
  a2 = a15;
  a3 = a13;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  execute(create__goal__wait_4_0);
  goto create__goal__wait_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a3,builtin__type_17_12);
  *reasonp++ =  a3;
  goto builtin__type_17_39;
  };
  goto builtin__type_17_39;
 case VARREF:
  deref_and_jump(a6,builtin__type_17_10);
  *reasonp++ =  a6;
  goto builtin__type_17_39;
  };
  goto builtin__type_17_39;
 case symval(makesym(atom_hash)):
 builtin__type_17_13:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_14:
  if (a6 != makeint(2L)) goto builtin__type_17_39;
 builtin__type_17_15:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_guard)) goto builtin__type_17_39;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_i);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_16);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_84);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a3,builtin__type_17_15);
  *reasonp++ =  a3;
  goto builtin__type_17_39;
  };
  goto builtin__type_17_39;
 case VARREF:
  deref_and_jump(a6,builtin__type_17_13);
  *reasonp++ =  a6;
  goto builtin__type_17_39;
  };
  goto builtin__type_17_39;
 case symval(makesym(atom_current__priority)):
 builtin__type_17_16:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_17:
  if (a6 != makeint(1L)) goto builtin__type_17_39;
 builtin__type_17_18:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_guard)) goto builtin__type_17_39;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_i);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_8);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_0);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(1L);
  allocp[3] = a7;
  allocp[4] = x6;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case VARREF:
  deref_and_jump(a3,builtin__type_17_18);
  *reasonp++ =  a3;
  goto builtin__type_17_39;
  };
  goto builtin__type_17_39;
 case VARREF:
  deref_and_jump(a6,builtin__type_17_16);
  *reasonp++ =  a6;
  goto builtin__type_17_39;
  };
  goto builtin__type_17_39;
 case symval(makesym(atom_current__node)):
 builtin__type_17_19:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_20:
  if (a6 != makeint(2L)) goto builtin__type_17_39;
 builtin__type_17_21:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_body)) goto builtin__type_17_39;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_i);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = x7 = makeref(&allocp[30]);
  allocp[31] = a10;
  allocp[32] = x8 = makeref(&allocp[32]);
  allocp[33] = a12;
  allocp[34] = makesym(functor_goal_4);
  allocp[35] = a0;
  allocp[36] = a1;
  allocp[37] = a2;
  allocp[38] = a3;
  x9 = makefunctor(&allocp[34]);
  allocp[39] = NILATOM;
  allocp[40] = x9;
  x10 = makecons(&allocp[39]);
  allocp[41] = makesym(functor_goal_4);
  allocp[42] = a0;
  allocp[43] = a1;
  allocp[44] = a2;
  allocp[45] = a3;
  x11 = makefunctor(&allocp[41]);
  allocp[46] = NILATOM;
  allocp[47] = x11;
  x12 = makecons(&allocp[46]);
  allocp[48] = makesym(functor_t_4);
  allocp[49] = makesym(atom_i);
  allocp[50] = x10;
  allocp[51] = x12;
  allocp[52] = makesym(atom_u);
  x13 = makefunctor(&allocp[48]);
  allocp[53] = NILATOM;
  allocp[54] = x13;
  x14 = makecons(&allocp[53]);
  allocp[55] = (q)(struct goalrec*)&allocp[21];
  allocp[56] = (q)(&predicate_type_xset__types_11);
  allocp[57] = a0;
  allocp[58] = a1;
  allocp[59] = a3;
  allocp[60] = a2;
  allocp[61] = x15 = makeref(&allocp[61]);
  allocp[62] = makesym(atom_o);
  allocp[63] = x14;
  allocp[64] = a9;
  allocp[65] = x7;
  allocp[66] = a11;
  allocp[67] = x8;
  allocp[68] = (q)(struct goalrec*)&allocp[55];
  allocp[69] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[70] = makecons(cons_const_10);
  allocp[71] = a3;
  allocp[72] = a7;
  allocp[73] = a8;
  allocp[74] = a13;
  allocp[75] = a14;
  allocp[76] = (q)(struct goalrec*)&allocp[68];
  allocp[77] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[78] = a7;
  allocp[79] = makecons(cons_const_2);
  allocp[80] = a15;
  allocp[81] = a13;
  qp = (struct goalrec*)&allocp[76];
  allocp += 82;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x15;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a3,builtin__type_17_21);
  *reasonp++ =  a3;
  goto builtin__type_17_39;
  };
  goto builtin__type_17_39;
 case VARREF:
  deref_and_jump(a6,builtin__type_17_19);
  *reasonp++ =  a6;
  goto builtin__type_17_39;
  };
  goto builtin__type_17_39;
 case symval(makesym(atom_unbound)):
 builtin__type_17_22:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_23:
  if (a6 != makeint(2L)) goto builtin__type_17_39;
 builtin__type_17_24:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_body)) goto builtin__type_17_39;
 builtin__type_17_25:
  if (isref(a7)) goto builtin__type_17_27;
  gblt_arg(makeint(1L),a7,x0,builtin__type_17_39);
  gblt_arg(makeint(2L),a7,x1,builtin__type_17_39);
 builtin__type_17_26:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_variable_3)) goto builtin__type_17_39;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = makesym(functor_v_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = arg(x0, 1);
  allocp[4] = arg(x0, 0);
  x2 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_t_4);
  allocp[6] = x2;
  allocp[7] = NILATOM;
  allocp[8] = NILATOM;
  allocp[9] = makesym(atom__3F);
  x3 = makefunctor(&allocp[5]);
  allocp[10] = NILATOM;
  allocp[11] = x3;
  x4 = makecons(&allocp[10]);
  allocp[12] = makesym(functor_arg_1);
  allocp[13] = x4;
  x5 = makefunctor(&allocp[12]);
  allocp[14] = makesym(functor_s_3);
  allocp[15] = makesym(atom___v);
  allocp[16] = makeint(1L);
  allocp[17] = x5;
  x6 = makefunctor(&allocp[14]);
  allocp[18] = makesym(functor_goal_4);
  allocp[19] = a0;
  allocp[20] = a1;
  allocp[21] = a2;
  allocp[22] = a3;
  x7 = makefunctor(&allocp[18]);
  allocp[23] = NILATOM;
  allocp[24] = x7;
  x8 = makecons(&allocp[23]);
  allocp[25] = makesym(functor_goal_4);
  allocp[26] = a0;
  allocp[27] = a1;
  allocp[28] = a2;
  allocp[29] = a3;
  x9 = makefunctor(&allocp[25]);
  allocp[30] = NILATOM;
  allocp[31] = x9;
  x10 = makecons(&allocp[30]);
  allocp[32] = makesym(functor_t_4);
  allocp[33] = x6;
  allocp[34] = x8;
  allocp[35] = x10;
  allocp[36] = makesym(atom_u);
  x11 = makefunctor(&allocp[32]);
  allocp[37] = makesym(functor_goal_4);
  allocp[38] = a0;
  allocp[39] = a1;
  allocp[40] = a2;
  allocp[41] = a3;
  x12 = makefunctor(&allocp[37]);
  allocp[42] = NILATOM;
  allocp[43] = x12;
  x13 = makecons(&allocp[42]);
  allocp[44] = makesym(functor_goal_4);
  allocp[45] = a0;
  allocp[46] = a1;
  allocp[47] = a2;
  allocp[48] = a3;
  x14 = makefunctor(&allocp[44]);
  allocp[49] = NILATOM;
  allocp[50] = x14;
  x15 = makecons(&allocp[49]);
  allocp[51] = makesym(functor_t_4);
  allocp[52] = makesym(atom_i);
  allocp[53] = x13;
  allocp[54] = x15;
  allocp[55] = makesym(atom_u);
  x16 = makefunctor(&allocp[51]);
  allocp[56] = NILATOM;
  allocp[57] = x16;
  x17 = makecons(&allocp[56]);
  allocp[58] = makesym(functor_goal_4);
  allocp[59] = a0;
  allocp[60] = a1;
  allocp[61] = a2;
  allocp[62] = a3;
  x18 = makefunctor(&allocp[58]);
  allocp[63] = NILATOM;
  allocp[64] = x18;
  x19 = makecons(&allocp[63]);
  allocp[65] = makesym(functor_goal_4);
  allocp[66] = a0;
  allocp[67] = a1;
  allocp[68] = a2;
  allocp[69] = a3;
  x20 = makefunctor(&allocp[65]);
  allocp[70] = NILATOM;
  allocp[71] = x20;
  x21 = makecons(&allocp[70]);
  allocp[72] = makesym(functor_t_4);
  allocp[73] = makesym(atom_i);
  allocp[74] = x19;
  allocp[75] = x21;
  allocp[76] = makesym(atom_u);
  x22 = makefunctor(&allocp[72]);
  allocp[77] = NILATOM;
  allocp[78] = x22;
  x23 = makecons(&allocp[77]);
  allocp[79] = makesym(functor_v_4);
  allocp[80] = a0;
  allocp[81] = a1;
  allocp[82] = arg(x0, 1);
  allocp[83] = arg(x0, 0);
  x24 = makefunctor(&allocp[79]);
  allocp[84] = makesym(functor_t_4);
  allocp[85] = x24;
  allocp[86] = NILATOM;
  allocp[87] = NILATOM;
  allocp[88] = makesym(atom__3F);
  x25 = makefunctor(&allocp[84]);
  allocp[89] = NILATOM;
  allocp[90] = x25;
  x26 = makecons(&allocp[89]);
  allocp[91] = makesym(functor_arg_3);
  allocp[92] = x17;
  allocp[93] = x23;
  allocp[94] = x26;
  x27 = makefunctor(&allocp[91]);
  allocp[95] = makesym(functor_s_3);
  allocp[96] = makesym(atom___v);
  allocp[97] = makeint(3L);
  allocp[98] = x27;
  x28 = makefunctor(&allocp[95]);
  allocp[99] = makesym(functor_goal_4);
  allocp[100] = a0;
  allocp[101] = a1;
  allocp[102] = a2;
  allocp[103] = a3;
  x29 = makefunctor(&allocp[99]);
  allocp[104] = NILATOM;
  allocp[105] = x29;
  x30 = makecons(&allocp[104]);
  allocp[106] = makesym(functor_goal_4);
  allocp[107] = a0;
  allocp[108] = a1;
  allocp[109] = a2;
  allocp[110] = a3;
  x31 = makefunctor(&allocp[106]);
  allocp[111] = NILATOM;
  allocp[112] = x31;
  x32 = makecons(&allocp[111]);
  allocp[113] = makesym(functor_t_4);
  allocp[114] = x28;
  allocp[115] = x30;
  allocp[116] = x32;
  allocp[117] = makesym(atom_u);
  x33 = makefunctor(&allocp[113]);
  allocp[118] = NILATOM;
  allocp[119] = x33;
  x34 = makecons(&allocp[118]);
  allocp[120] = x34;
  allocp[121] = x11;
  x35 = makecons(&allocp[120]);
  allocp[122] = (q)qp;
  allocp[123] = (q)(&predicate_type_xset__types_11);
  allocp[124] = a0;
  allocp[125] = a1;
  allocp[126] = a3;
  allocp[127] = a2;
  allocp[128] = x1;
  allocp[129] = makesym(atom_o);
  allocp[130] = x35;
  allocp[131] = a9;
  allocp[132] = a10;
  allocp[133] = a11;
  allocp[134] = a12;
  allocp[135] = (q)(struct goalrec*)&allocp[122];
  allocp[136] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[137] = makecons(cons_const_16);
  allocp[138] = a3;
  allocp[139] = a7;
  allocp[140] = a8;
  allocp[141] = a13;
  allocp[142] = a14;
  a0 = a7;
  a1 = makecons(cons_const_41);
  a2 = a15;
  a3 = a13;
  qp = (struct goalrec*)&allocp[135];
  allocp += 143;
  execute(create__goal__wait_4_0);
  goto create__goal__wait_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,builtin__type_17_26);
  *reasonp++ =  x0;
  goto builtin__type_17_39;
  };
  goto builtin__type_17_39;
 builtin__type_17_27:
  deref_and_jump(a7,builtin__type_17_25);
  *reasonp++ =  a7;
  goto builtin__type_17_39;
 case VARREF:
  deref_and_jump(a3,builtin__type_17_24);
  *reasonp++ =  a3;
  goto builtin__type_17_39;
  };
  goto builtin__type_17_39;
 case VARREF:
  deref_and_jump(a6,builtin__type_17_22);
  *reasonp++ =  a6;
  goto builtin__type_17_39;
  };
  goto builtin__type_17_39;
 case symval(makesym(atom_atomic)):
 builtin__type_17_28:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_29:
  if (a6 != makeint(1L)) goto builtin__type_17_39;
 builtin__type_17_30:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_guard)) goto builtin__type_17_39;
  unify2(a12, a11, a10, a9);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[2] = makecons(cons_const_14);
  allocp[3] = a3;
  allocp[4] = a7;
  allocp[5] = a8;
  allocp[6] = a13;
  allocp[7] = a14;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[10] = a7;
  allocp[11] = makecons(cons_const_38);
  allocp[12] = a15;
  allocp[13] = a13;
  qp = (struct goalrec*)&allocp[8];
  allocp += 14;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(1L);
  allocp[3] = a7;
  allocp[4] = x0 = makeref(&allocp[4]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case VARREF:
  deref_and_jump(a3,builtin__type_17_30);
  *reasonp++ =  a3;
  goto builtin__type_17_39;
  };
  goto builtin__type_17_39;
 case VARREF:
  deref_and_jump(a6,builtin__type_17_28);
  *reasonp++ =  a6;
  goto builtin__type_17_39;
  };
  goto builtin__type_17_39;
 case symval(makesym(atom_atom)):
 builtin__type_17_31:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_32:
  if (a6 != makeint(1L)) goto builtin__type_17_39;
 builtin__type_17_33:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_guard)) goto builtin__type_17_39;
  unify2(a12, a11, a10, a9);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[2] = makecons(cons_const_14);
  allocp[3] = a3;
  allocp[4] = a7;
  allocp[5] = a8;
  allocp[6] = a13;
  allocp[7] = a14;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[10] = a7;
  allocp[11] = makecons(cons_const_38);
  allocp[12] = a15;
  allocp[13] = a13;
  qp = (struct goalrec*)&allocp[8];
  allocp += 14;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(1L);
  allocp[3] = a7;
  allocp[4] = x0 = makeref(&allocp[4]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case VARREF:
  deref_and_jump(a3,builtin__type_17_33);
  *reasonp++ =  a3;
  goto builtin__type_17_39;
  };
  goto builtin__type_17_39;
 case VARREF:
  deref_and_jump(a6,builtin__type_17_31);
  *reasonp++ =  a6;
  goto builtin__type_17_39;
  };
  goto builtin__type_17_39;
 case symval(makesym(atom_make__atom)):
 builtin__type_17_34:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_35:
  if (a6 != makeint(2L)) goto builtin__type_17_39;
 builtin__type_17_36:
  if (isref(a7)) goto builtin__type_17_38;
  gblt_arg(makeint(1L),a7,x0,builtin__type_17_39);
  gblt_arg(makeint(2L),a7,x1,builtin__type_17_39);
 builtin__type_17_37:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_string_1)) goto builtin__type_17_39;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = makesym(functor_a_1);
  allocp[1] = x3 = makeref(&allocp[1]);
  x2 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_goal_4);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  x4 = makefunctor(&allocp[2]);
  allocp[7] = NILATOM;
  allocp[8] = x4;
  x5 = makecons(&allocp[7]);
  allocp[9] = makesym(functor_goal_4);
  allocp[10] = a0;
  allocp[11] = a1;
  allocp[12] = a2;
  allocp[13] = a3;
  x6 = makefunctor(&allocp[9]);
  allocp[14] = NILATOM;
  allocp[15] = x6;
  x7 = makecons(&allocp[14]);
  allocp[16] = makesym(functor_t_4);
  allocp[17] = x2;
  allocp[18] = x5;
  allocp[19] = x7;
  allocp[20] = makesym(atom_u);
  x8 = makefunctor(&allocp[16]);
  allocp[21] = NILATOM;
  allocp[22] = x8;
  x9 = makecons(&allocp[21]);
  allocp[23] = (q)qp;
  allocp[24] = (q)(&predicate_type_xset__types_11);
  allocp[25] = a0;
  allocp[26] = a1;
  allocp[27] = a3;
  allocp[28] = a2;
  allocp[29] = x1;
  allocp[30] = makesym(atom_o);
  allocp[31] = x9;
  allocp[32] = a9;
  allocp[33] = a10;
  allocp[34] = a11;
  allocp[35] = a12;
  allocp[36] = (q)(struct goalrec*)&allocp[23];
  allocp[37] = (q)(&predicate_atom__table_xmake__atom_2);
  x10 = arg(x0, 0);
  allocp[38] = x10;
  allocp[39] = x3;
  allocp[40] = (q)(struct goalrec*)&allocp[36];
  allocp[41] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[42] = makecons(cons_const_16);
  allocp[43] = a3;
  allocp[44] = a7;
  allocp[45] = a8;
  allocp[46] = a13;
  allocp[47] = a14;
  a0 = a7;
  a1 = makecons(cons_const_41);
  a2 = a15;
  a3 = a13;
  qp = (struct goalrec*)&allocp[40];
  allocp += 48;
  execute(create__goal__wait_4_0);
  goto create__goal__wait_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,builtin__type_17_37);
  *reasonp++ =  x0;
  goto builtin__type_17_39;
  };
  goto builtin__type_17_39;
 builtin__type_17_38:
  deref_and_jump(a7,builtin__type_17_36);
  *reasonp++ =  a7;
  goto builtin__type_17_39;
 case VARREF:
  deref_and_jump(a6,builtin__type_17_34);
  *reasonp++ =  a6;
  goto builtin__type_17_39;
  };
  goto builtin__type_17_39;
  };
  goto builtin__type_17_39;
 case VARREF:
  deref_and_jump(a5,builtin__type_17_1);
  *reasonp++ =  a5;
  goto builtin__type_17_39;
  };
  goto builtin__type_17_39;
 builtin__type_17_39:
  otherwise(builtin__type_17_interrupt);
 builtin__type_17_40:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (isint(a5)) goto builtin__type_17_50;
  switch (symval(a5)) {
 case symval(makesym(atom_make__atom)):
 builtin__type_17_41:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_42:
  if (a6 != makeint(2L)) goto builtin__type_17_50;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_a);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_16);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_41);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_41);
  *reasonp++ =  a6;
  goto builtin__type_17_50;
  };
  goto builtin__type_17_50;
 case symval(makesym(atom_atom__number)):
 builtin__type_17_43:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_44:
  if (a6 != makeint(2L)) goto builtin__type_17_50;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_i);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_16);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_41);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_43);
  *reasonp++ =  a6;
  goto builtin__type_17_50;
  };
  goto builtin__type_17_50;
 case symval(makesym(atom_get__atom__string)):
 builtin__type_17_45:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_46:
  if (a6 != makeint(2L)) goto builtin__type_17_50;
 builtin__type_17_47:
  if (isref(a7)) goto builtin__type_17_49;
  gblt_arg(makeint(1L),a7,x0,builtin__type_17_50);
  gblt_arg(makeint(2L),a7,x1,builtin__type_17_50);
 builtin__type_17_48:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_atom_1)) goto builtin__type_17_50;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = makesym(functor_c_1);
  allocp[1] = x3 = makeref(&allocp[1]);
  x2 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_goal_4);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  x4 = makefunctor(&allocp[2]);
  allocp[7] = NILATOM;
  allocp[8] = x4;
  x5 = makecons(&allocp[7]);
  allocp[9] = makesym(functor_goal_4);
  allocp[10] = a0;
  allocp[11] = a1;
  allocp[12] = a2;
  allocp[13] = a3;
  x6 = makefunctor(&allocp[9]);
  allocp[14] = NILATOM;
  allocp[15] = x6;
  x7 = makecons(&allocp[14]);
  allocp[16] = makesym(functor_t_4);
  allocp[17] = x2;
  allocp[18] = x5;
  allocp[19] = x7;
  allocp[20] = makesym(atom_u);
  x8 = makefunctor(&allocp[16]);
  allocp[21] = NILATOM;
  allocp[22] = x8;
  x9 = makecons(&allocp[21]);
  allocp[23] = (q)qp;
  allocp[24] = (q)(&predicate_type_xset__types_11);
  allocp[25] = a0;
  allocp[26] = a1;
  allocp[27] = a3;
  allocp[28] = a2;
  allocp[29] = x1;
  allocp[30] = makesym(atom_o);
  allocp[31] = x9;
  allocp[32] = a9;
  allocp[33] = a10;
  allocp[34] = a11;
  allocp[35] = a12;
  allocp[36] = (q)(struct goalrec*)&allocp[23];
  allocp[37] = (q)(&predicate_atom__table_xget__atom__string_2);
  x10 = arg(x0, 0);
  allocp[38] = x10;
  allocp[39] = x3;
  allocp[40] = (q)(struct goalrec*)&allocp[36];
  allocp[41] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[42] = makecons(cons_const_16);
  allocp[43] = a3;
  allocp[44] = a7;
  allocp[45] = a8;
  allocp[46] = a13;
  allocp[47] = a14;
  a0 = a7;
  a1 = makecons(cons_const_41);
  a2 = a15;
  a3 = a13;
  qp = (struct goalrec*)&allocp[40];
  allocp += 48;
  execute(create__goal__wait_4_0);
  goto create__goal__wait_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,builtin__type_17_48);
  *reasonp++ =  x0;
  goto builtin__type_17_50;
  };
  goto builtin__type_17_50;
 builtin__type_17_49:
  deref_and_jump(a7,builtin__type_17_47);
  *reasonp++ =  a7;
  goto builtin__type_17_50;
 case VARREF:
  deref_and_jump(a6,builtin__type_17_45);
  *reasonp++ =  a6;
  goto builtin__type_17_50;
  };
  goto builtin__type_17_50;
  };
  goto builtin__type_17_50;
 case VARREF:
  deref_and_jump(a5,builtin__type_17_40);
  *reasonp++ =  a5;
  goto builtin__type_17_50;
  };
  goto builtin__type_17_50;
 builtin__type_17_50:
  otherwise(builtin__type_17_interrupt);
 builtin__type_17_51:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (isint(a5)) goto builtin__type_17_59;
  switch (symval(a5)) {
 case symval(makesym(atom_get__atom__string)):
 builtin__type_17_52:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_53:
  if (a6 != makeint(2L)) goto builtin__type_17_59;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_c);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_16);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_41);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_52);
  *reasonp++ =  a6;
  goto builtin__type_17_59;
  };
  goto builtin__type_17_59;
 case symval(makesym(atom_intern)):
 builtin__type_17_54:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_55:
  if (a6 != makeint(2L)) goto builtin__type_17_59;
 builtin__type_17_56:
  if (isref(a7)) goto builtin__type_17_58;
  gblt_arg(makeint(1L),a7,x0,builtin__type_17_59);
  gblt_arg(makeint(2L),a7,x1,builtin__type_17_59);
 builtin__type_17_57:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_string_1)) goto builtin__type_17_59;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = makesym(functor_a_1);
  allocp[1] = x3 = makeref(&allocp[1]);
  x2 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_goal_4);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  x4 = makefunctor(&allocp[2]);
  allocp[7] = NILATOM;
  allocp[8] = x4;
  x5 = makecons(&allocp[7]);
  allocp[9] = makesym(functor_goal_4);
  allocp[10] = a0;
  allocp[11] = a1;
  allocp[12] = a2;
  allocp[13] = a3;
  x6 = makefunctor(&allocp[9]);
  allocp[14] = NILATOM;
  allocp[15] = x6;
  x7 = makecons(&allocp[14]);
  allocp[16] = makesym(functor_t_4);
  allocp[17] = x2;
  allocp[18] = x5;
  allocp[19] = x7;
  allocp[20] = makesym(atom_u);
  x8 = makefunctor(&allocp[16]);
  allocp[21] = NILATOM;
  allocp[22] = x8;
  x9 = makecons(&allocp[21]);
  allocp[23] = makesym(functor_arg_1);
  allocp[24] = x9;
  x10 = makefunctor(&allocp[23]);
  allocp[25] = makesym(functor_s_3);
  allocp[26] = makesym(atom_normal);
  allocp[27] = makeint(1L);
  allocp[28] = x10;
  x11 = makefunctor(&allocp[25]);
  allocp[29] = makesym(functor_goal_4);
  allocp[30] = a0;
  allocp[31] = a1;
  allocp[32] = a2;
  allocp[33] = a3;
  x12 = makefunctor(&allocp[29]);
  allocp[34] = NILATOM;
  allocp[35] = x12;
  x13 = makecons(&allocp[34]);
  allocp[36] = makesym(functor_goal_4);
  allocp[37] = a0;
  allocp[38] = a1;
  allocp[39] = a2;
  allocp[40] = a3;
  x14 = makefunctor(&allocp[36]);
  allocp[41] = NILATOM;
  allocp[42] = x14;
  x15 = makecons(&allocp[41]);
  allocp[43] = makesym(functor_t_4);
  allocp[44] = x11;
  allocp[45] = x13;
  allocp[46] = x15;
  allocp[47] = makesym(atom_u);
  x16 = makefunctor(&allocp[43]);
  allocp[48] = NILATOM;
  allocp[49] = x16;
  x17 = makecons(&allocp[48]);
  allocp[50] = (q)qp;
  allocp[51] = (q)(&predicate_type_xset__types_11);
  allocp[52] = a0;
  allocp[53] = a1;
  allocp[54] = a3;
  allocp[55] = a2;
  allocp[56] = x1;
  allocp[57] = makesym(atom_o);
  allocp[58] = x17;
  allocp[59] = a9;
  allocp[60] = a10;
  allocp[61] = a11;
  allocp[62] = a12;
  allocp[63] = (q)(struct goalrec*)&allocp[50];
  allocp[64] = (q)(&predicate_atom__table_xmake__atom_2);
  x18 = arg(x0, 0);
  allocp[65] = x18;
  allocp[66] = x3;
  allocp[67] = (q)(struct goalrec*)&allocp[63];
  allocp[68] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[69] = makecons(cons_const_16);
  allocp[70] = a3;
  allocp[71] = a7;
  allocp[72] = a8;
  allocp[73] = a13;
  allocp[74] = a14;
  a0 = a7;
  a1 = makecons(cons_const_41);
  a2 = a15;
  a3 = a13;
  qp = (struct goalrec*)&allocp[67];
  allocp += 75;
  execute(create__goal__wait_4_0);
  goto create__goal__wait_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,builtin__type_17_57);
  *reasonp++ =  x0;
  goto builtin__type_17_59;
  };
  goto builtin__type_17_59;
 builtin__type_17_58:
  deref_and_jump(a7,builtin__type_17_56);
  *reasonp++ =  a7;
  goto builtin__type_17_59;
 case VARREF:
  deref_and_jump(a6,builtin__type_17_54);
  *reasonp++ =  a6;
  goto builtin__type_17_59;
  };
  goto builtin__type_17_59;
  };
  goto builtin__type_17_59;
 case VARREF:
  deref_and_jump(a5,builtin__type_17_51);
  *reasonp++ =  a5;
  goto builtin__type_17_59;
  };
  goto builtin__type_17_59;
 builtin__type_17_59:
  otherwise(builtin__type_17_interrupt);
 builtin__type_17_60:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (isint(a5)) goto builtin__type_17_68;
  switch (symval(a5)) {
 case symval(makesym(atom_intern)):
 builtin__type_17_61:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_62:
  if (a6 != makeint(2L)) goto builtin__type_17_68;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_a);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = makesym(functor_arg_1);
  allocp[22] = x5;
  x6 = makefunctor(&allocp[21]);
  allocp[23] = makesym(functor_s_3);
  allocp[24] = makesym(atom_normal);
  allocp[25] = makeint(1L);
  allocp[26] = x6;
  x7 = makefunctor(&allocp[23]);
  allocp[27] = makesym(functor_goal_4);
  allocp[28] = a0;
  allocp[29] = a1;
  allocp[30] = a2;
  allocp[31] = a3;
  x8 = makefunctor(&allocp[27]);
  allocp[32] = NILATOM;
  allocp[33] = x8;
  x9 = makecons(&allocp[32]);
  allocp[34] = makesym(functor_goal_4);
  allocp[35] = a0;
  allocp[36] = a1;
  allocp[37] = a2;
  allocp[38] = a3;
  x10 = makefunctor(&allocp[34]);
  allocp[39] = NILATOM;
  allocp[40] = x10;
  x11 = makecons(&allocp[39]);
  allocp[41] = makesym(functor_t_4);
  allocp[42] = x7;
  allocp[43] = x9;
  allocp[44] = x11;
  allocp[45] = makesym(atom_u);
  x12 = makefunctor(&allocp[41]);
  allocp[46] = NILATOM;
  allocp[47] = x12;
  x13 = makecons(&allocp[46]);
  allocp[48] = (q)qp;
  allocp[49] = (q)(&predicate_type_xset__types_11);
  allocp[50] = a0;
  allocp[51] = a1;
  allocp[52] = a3;
  allocp[53] = a2;
  allocp[54] = x14 = makeref(&allocp[54]);
  allocp[55] = makesym(atom_o);
  allocp[56] = x13;
  allocp[57] = a9;
  allocp[58] = a10;
  allocp[59] = a11;
  allocp[60] = a12;
  allocp[61] = (q)(struct goalrec*)&allocp[48];
  allocp[62] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[63] = makecons(cons_const_16);
  allocp[64] = a3;
  allocp[65] = a7;
  allocp[66] = a8;
  allocp[67] = a13;
  allocp[68] = a14;
  allocp[69] = (q)(struct goalrec*)&allocp[61];
  allocp[70] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[71] = a7;
  allocp[72] = makecons(cons_const_41);
  allocp[73] = a15;
  allocp[74] = a13;
  qp = (struct goalrec*)&allocp[69];
  allocp += 75;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x14;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x15 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_61);
  *reasonp++ =  a6;
  goto builtin__type_17_68;
  };
  goto builtin__type_17_68;
 case symval(makesym(atom_get__atom__name)):
 builtin__type_17_63:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_64:
  if (a6 != makeint(2L)) goto builtin__type_17_68;
 builtin__type_17_65:
  if (isref(a7)) goto builtin__type_17_67;
  gblt_arg(makeint(1L),a7,x0,builtin__type_17_68);
  gblt_arg(makeint(2L),a7,x1,builtin__type_17_68);
 builtin__type_17_66:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_atom_1)) goto builtin__type_17_68;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = makesym(functor_c_1);
  allocp[1] = x3 = makeref(&allocp[1]);
  x2 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_goal_4);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  x4 = makefunctor(&allocp[2]);
  allocp[7] = NILATOM;
  allocp[8] = x4;
  x5 = makecons(&allocp[7]);
  allocp[9] = makesym(functor_goal_4);
  allocp[10] = a0;
  allocp[11] = a1;
  allocp[12] = a2;
  allocp[13] = a3;
  x6 = makefunctor(&allocp[9]);
  allocp[14] = NILATOM;
  allocp[15] = x6;
  x7 = makecons(&allocp[14]);
  allocp[16] = makesym(functor_t_4);
  allocp[17] = x2;
  allocp[18] = x5;
  allocp[19] = x7;
  allocp[20] = makesym(atom_u);
  x8 = makefunctor(&allocp[16]);
  allocp[21] = NILATOM;
  allocp[22] = x8;
  x9 = makecons(&allocp[21]);
  allocp[23] = makesym(functor_arg_1);
  allocp[24] = x9;
  x10 = makefunctor(&allocp[23]);
  allocp[25] = makesym(functor_s_3);
  allocp[26] = makesym(atom_normal);
  allocp[27] = makeint(1L);
  allocp[28] = x10;
  x11 = makefunctor(&allocp[25]);
  allocp[29] = makesym(functor_goal_4);
  allocp[30] = a0;
  allocp[31] = a1;
  allocp[32] = a2;
  allocp[33] = a3;
  x12 = makefunctor(&allocp[29]);
  allocp[34] = NILATOM;
  allocp[35] = x12;
  x13 = makecons(&allocp[34]);
  allocp[36] = makesym(functor_goal_4);
  allocp[37] = a0;
  allocp[38] = a1;
  allocp[39] = a2;
  allocp[40] = a3;
  x14 = makefunctor(&allocp[36]);
  allocp[41] = NILATOM;
  allocp[42] = x14;
  x15 = makecons(&allocp[41]);
  allocp[43] = makesym(functor_t_4);
  allocp[44] = x11;
  allocp[45] = x13;
  allocp[46] = x15;
  allocp[47] = makesym(atom_u);
  x16 = makefunctor(&allocp[43]);
  allocp[48] = NILATOM;
  allocp[49] = x16;
  x17 = makecons(&allocp[48]);
  allocp[50] = (q)qp;
  allocp[51] = (q)(&predicate_type_xset__types_11);
  allocp[52] = a0;
  allocp[53] = a1;
  allocp[54] = a3;
  allocp[55] = a2;
  allocp[56] = x1;
  allocp[57] = makesym(atom_o);
  allocp[58] = x17;
  allocp[59] = a9;
  allocp[60] = a10;
  allocp[61] = a11;
  allocp[62] = a12;
  allocp[63] = (q)(struct goalrec*)&allocp[50];
  allocp[64] = (q)(&predicate_atom__table_xget__atom__string_2);
  x18 = arg(x0, 0);
  allocp[65] = x18;
  allocp[66] = x3;
  allocp[67] = (q)(struct goalrec*)&allocp[63];
  allocp[68] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[69] = makecons(cons_const_16);
  allocp[70] = a3;
  allocp[71] = a7;
  allocp[72] = a8;
  allocp[73] = a13;
  allocp[74] = a14;
  a0 = a7;
  a1 = makecons(cons_const_41);
  a2 = a15;
  a3 = a13;
  qp = (struct goalrec*)&allocp[67];
  allocp += 75;
  execute(create__goal__wait_4_0);
  goto create__goal__wait_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,builtin__type_17_66);
  *reasonp++ =  x0;
  goto builtin__type_17_68;
  };
  goto builtin__type_17_68;
 builtin__type_17_67:
  deref_and_jump(a7,builtin__type_17_65);
  *reasonp++ =  a7;
  goto builtin__type_17_68;
 case VARREF:
  deref_and_jump(a6,builtin__type_17_63);
  *reasonp++ =  a6;
  goto builtin__type_17_68;
  };
  goto builtin__type_17_68;
  };
  goto builtin__type_17_68;
 case VARREF:
  deref_and_jump(a5,builtin__type_17_60);
  *reasonp++ =  a5;
  goto builtin__type_17_68;
  };
  goto builtin__type_17_68;
 builtin__type_17_68:
  otherwise(builtin__type_17_interrupt);
 builtin__type_17_69:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (isint(a5)) goto builtin__type_17_159;
  switch (symval(a5)) {
 case symval(makesym(atom_get__atom__name)):
 builtin__type_17_70:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_71:
  if (a6 != makeint(2L)) goto builtin__type_17_159;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_c);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = makesym(functor_arg_1);
  allocp[22] = x5;
  x6 = makefunctor(&allocp[21]);
  allocp[23] = makesym(functor_s_3);
  allocp[24] = makesym(atom_normal);
  allocp[25] = makeint(1L);
  allocp[26] = x6;
  x7 = makefunctor(&allocp[23]);
  allocp[27] = makesym(functor_goal_4);
  allocp[28] = a0;
  allocp[29] = a1;
  allocp[30] = a2;
  allocp[31] = a3;
  x8 = makefunctor(&allocp[27]);
  allocp[32] = NILATOM;
  allocp[33] = x8;
  x9 = makecons(&allocp[32]);
  allocp[34] = makesym(functor_goal_4);
  allocp[35] = a0;
  allocp[36] = a1;
  allocp[37] = a2;
  allocp[38] = a3;
  x10 = makefunctor(&allocp[34]);
  allocp[39] = NILATOM;
  allocp[40] = x10;
  x11 = makecons(&allocp[39]);
  allocp[41] = makesym(functor_t_4);
  allocp[42] = x7;
  allocp[43] = x9;
  allocp[44] = x11;
  allocp[45] = makesym(atom_u);
  x12 = makefunctor(&allocp[41]);
  allocp[46] = NILATOM;
  allocp[47] = x12;
  x13 = makecons(&allocp[46]);
  allocp[48] = (q)qp;
  allocp[49] = (q)(&predicate_type_xset__types_11);
  allocp[50] = a0;
  allocp[51] = a1;
  allocp[52] = a3;
  allocp[53] = a2;
  allocp[54] = x14 = makeref(&allocp[54]);
  allocp[55] = makesym(atom_o);
  allocp[56] = x13;
  allocp[57] = a9;
  allocp[58] = a10;
  allocp[59] = a11;
  allocp[60] = a12;
  allocp[61] = (q)(struct goalrec*)&allocp[48];
  allocp[62] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[63] = makecons(cons_const_16);
  allocp[64] = a3;
  allocp[65] = a7;
  allocp[66] = a8;
  allocp[67] = a13;
  allocp[68] = a14;
  allocp[69] = (q)(struct goalrec*)&allocp[61];
  allocp[70] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[71] = a7;
  allocp[72] = makecons(cons_const_41);
  allocp[73] = a15;
  allocp[74] = a13;
  qp = (struct goalrec*)&allocp[69];
  allocp += 75;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x14;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x15 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_70);
  *reasonp++ =  a6;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case symval(makesym(atom_integer)):
 builtin__type_17_72:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_73:
  if (a6 != makeint(1L)) goto builtin__type_17_159;
 builtin__type_17_74:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_guard)) goto builtin__type_17_159;
  unify2(a12, a11, a10, a9);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[2] = makecons(cons_const_14);
  allocp[3] = a3;
  allocp[4] = a7;
  allocp[5] = a8;
  allocp[6] = a13;
  allocp[7] = a14;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[10] = a7;
  allocp[11] = makecons(cons_const_38);
  allocp[12] = a15;
  allocp[13] = a13;
  qp = (struct goalrec*)&allocp[8];
  allocp += 14;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(1L);
  allocp[3] = a7;
  allocp[4] = x0 = makeref(&allocp[4]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case VARREF:
  deref_and_jump(a3,builtin__type_17_74);
  *reasonp++ =  a3;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case VARREF:
  deref_and_jump(a6,builtin__type_17_72);
  *reasonp++ =  a6;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case symval(makesym(atom_add)):
 builtin__type_17_75:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_76:
  if (a6 != makeint(3L)) goto builtin__type_17_159;
 builtin__type_17_77:
  if (isref(a0)) goto builtin__type_17_80;
 builtin__type_17_78:
  if (isref(a0)) goto builtin__type_17_79;
  if_not_equal(a0, a4, builtin__type_17_159);
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_i);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_27);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_59);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x8 = makeref(&allocp[14]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 builtin__type_17_79:
  deref_and_jump(a0,builtin__type_17_78);
  *reasonp++ =  a0;
  goto builtin__type_17_159;
 builtin__type_17_80:
  deref_and_jump(a0,builtin__type_17_77);
  *reasonp++ =  a0;
  goto builtin__type_17_159;
 case VARREF:
  deref_and_jump(a6,builtin__type_17_75);
  *reasonp++ =  a6;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case symval(makesym(atom_plus)):
 builtin__type_17_81:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_82:
  if (a6 != makeint(2L)) goto builtin__type_17_159;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_i);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_16);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_41);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_81);
  *reasonp++ =  a6;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case symval(makesym(atom_subtract)):
 builtin__type_17_83:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_84:
  if (a6 != makeint(3L)) goto builtin__type_17_159;
 builtin__type_17_85:
  if (isref(a0)) goto builtin__type_17_88;
 builtin__type_17_86:
  if (isref(a0)) goto builtin__type_17_87;
  if_not_equal(a0, a4, builtin__type_17_159);
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_i);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_27);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_59);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x8 = makeref(&allocp[14]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 builtin__type_17_87:
  deref_and_jump(a0,builtin__type_17_86);
  *reasonp++ =  a0;
  goto builtin__type_17_159;
 builtin__type_17_88:
  deref_and_jump(a0,builtin__type_17_85);
  *reasonp++ =  a0;
  goto builtin__type_17_159;
 case VARREF:
  deref_and_jump(a6,builtin__type_17_83);
  *reasonp++ =  a6;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case symval(makesym(atom_minus)):
 builtin__type_17_89:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_90:
  if (a6 != makeint(2L)) goto builtin__type_17_159;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_i);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_16);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_41);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_89);
  *reasonp++ =  a6;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case symval(makesym(atom_multiply)):
 builtin__type_17_91:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_92:
  if (a6 != makeint(3L)) goto builtin__type_17_159;
 builtin__type_17_93:
  if (isref(a0)) goto builtin__type_17_96;
 builtin__type_17_94:
  if (isref(a0)) goto builtin__type_17_95;
  if_not_equal(a0, a4, builtin__type_17_159);
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_i);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_27);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_59);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x8 = makeref(&allocp[14]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 builtin__type_17_95:
  deref_and_jump(a0,builtin__type_17_94);
  *reasonp++ =  a0;
  goto builtin__type_17_159;
 builtin__type_17_96:
  deref_and_jump(a0,builtin__type_17_93);
  *reasonp++ =  a0;
  goto builtin__type_17_159;
 case VARREF:
  deref_and_jump(a6,builtin__type_17_91);
  *reasonp++ =  a6;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case symval(makesym(atom_divide)):
 builtin__type_17_97:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_98:
  if (a6 != makeint(3L)) goto builtin__type_17_159;
 builtin__type_17_99:
  if (isref(a0)) goto builtin__type_17_102;
 builtin__type_17_100:
  if (isref(a0)) goto builtin__type_17_101;
  if_not_equal(a0, a4, builtin__type_17_159);
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_i);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_27);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_59);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x8 = makeref(&allocp[14]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 builtin__type_17_101:
  deref_and_jump(a0,builtin__type_17_100);
  *reasonp++ =  a0;
  goto builtin__type_17_159;
 builtin__type_17_102:
  deref_and_jump(a0,builtin__type_17_99);
  *reasonp++ =  a0;
  goto builtin__type_17_159;
 case VARREF:
  deref_and_jump(a6,builtin__type_17_97);
  *reasonp++ =  a6;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case symval(makesym(atom_modulo)):
 builtin__type_17_103:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_104:
  if (a6 != makeint(3L)) goto builtin__type_17_159;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_i);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_27);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_59);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x8 = makeref(&allocp[14]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_103);
  *reasonp++ =  a6;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case symval(makesym(atom_complement)):
 builtin__type_17_105:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_106:
  if (a6 != makeint(2L)) goto builtin__type_17_159;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_i);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_16);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_41);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_105);
  *reasonp++ =  a6;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case symval(makesym(atom_and)):
 builtin__type_17_107:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_108:
  if (a6 != makeint(3L)) goto builtin__type_17_159;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_i);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_27);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_59);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x8 = makeref(&allocp[14]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_107);
  *reasonp++ =  a6;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case symval(makesym(atom_or)):
 builtin__type_17_109:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_110:
  if (a6 != makeint(3L)) goto builtin__type_17_159;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_i);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_27);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_59);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x8 = makeref(&allocp[14]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_109);
  *reasonp++ =  a6;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case symval(makesym(atom_exclusive__or)):
 builtin__type_17_111:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_112:
  if (a6 != makeint(3L)) goto builtin__type_17_159;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_i);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_27);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_59);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x8 = makeref(&allocp[14]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_111);
  *reasonp++ =  a6;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case symval(makesym(atom_shift__left)):
 builtin__type_17_113:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_114:
  if (a6 != makeint(3L)) goto builtin__type_17_159;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_i);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_27);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_59);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x8 = makeref(&allocp[14]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_113);
  *reasonp++ =  a6;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case symval(makesym(atom_shift__right)):
 builtin__type_17_115:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_116:
  if (a6 != makeint(3L)) goto builtin__type_17_159;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_i);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_27);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_59);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x8 = makeref(&allocp[14]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_115);
  *reasonp++ =  a6;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case symval(makesym(atom_floating__point__to__integer)):
 builtin__type_17_117:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_118:
  if (a6 != makeint(2L)) goto builtin__type_17_159;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_i);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_16);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_41);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_117);
  *reasonp++ =  a6;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case symval(makesym(atom_greater__than)):
 builtin__type_17_119:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_120:
  if (a6 != makeint(2L)) goto builtin__type_17_159;
 builtin__type_17_121:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_guard)) goto builtin__type_17_159;
  unify2(a12, a11, a10, a9);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[2] = makecons(cons_const_24);
  allocp[3] = a3;
  allocp[4] = a7;
  allocp[5] = a8;
  allocp[6] = a13;
  allocp[7] = a14;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[10] = a7;
  allocp[11] = makecons(cons_const_54);
  allocp[12] = a15;
  allocp[13] = a13;
  qp = (struct goalrec*)&allocp[8];
  allocp += 14;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x1 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a3,builtin__type_17_121);
  *reasonp++ =  a3;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case VARREF:
  deref_and_jump(a6,builtin__type_17_119);
  *reasonp++ =  a6;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case symval(makesym(atom_not__less__than)):
 builtin__type_17_122:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_123:
  if (a6 != makeint(2L)) goto builtin__type_17_159;
 builtin__type_17_124:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_guard)) goto builtin__type_17_159;
  unify2(a12, a11, a10, a9);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[2] = makecons(cons_const_24);
  allocp[3] = a3;
  allocp[4] = a7;
  allocp[5] = a8;
  allocp[6] = a13;
  allocp[7] = a14;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[10] = a7;
  allocp[11] = makecons(cons_const_54);
  allocp[12] = a15;
  allocp[13] = a13;
  qp = (struct goalrec*)&allocp[8];
  allocp += 14;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x1 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a3,builtin__type_17_124);
  *reasonp++ =  a3;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case VARREF:
  deref_and_jump(a6,builtin__type_17_122);
  *reasonp++ =  a6;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case symval(makesym(atom_equal)):
 builtin__type_17_125:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_126:
  if (a6 != makeint(2L)) goto builtin__type_17_159;
 builtin__type_17_127:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_guard)) goto builtin__type_17_159;
  unify2(a12, a11, a10, a9);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[2] = makecons(cons_const_24);
  allocp[3] = a3;
  allocp[4] = a7;
  allocp[5] = a8;
  allocp[6] = a13;
  allocp[7] = a14;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[10] = a7;
  allocp[11] = makecons(cons_const_54);
  allocp[12] = a15;
  allocp[13] = a13;
  qp = (struct goalrec*)&allocp[8];
  allocp += 14;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x1 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a3,builtin__type_17_127);
  *reasonp++ =  a3;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case VARREF:
  deref_and_jump(a6,builtin__type_17_125);
  *reasonp++ =  a6;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case symval(makesym(atom_not__equal)):
 builtin__type_17_128:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_129:
  if (a6 != makeint(2L)) goto builtin__type_17_159;
 builtin__type_17_130:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_guard)) goto builtin__type_17_159;
  unify2(a12, a11, a10, a9);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[2] = makecons(cons_const_24);
  allocp[3] = a3;
  allocp[4] = a7;
  allocp[5] = a8;
  allocp[6] = a13;
  allocp[7] = a14;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[10] = a7;
  allocp[11] = makecons(cons_const_54);
  allocp[12] = a15;
  allocp[13] = a13;
  qp = (struct goalrec*)&allocp[8];
  allocp += 14;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x1 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a3,builtin__type_17_130);
  *reasonp++ =  a3;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case VARREF:
  deref_and_jump(a6,builtin__type_17_128);
  *reasonp++ =  a6;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case symval(makesym(atom_not__greater__than)):
 builtin__type_17_131:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_132:
  if (a6 != makeint(2L)) goto builtin__type_17_159;
 builtin__type_17_133:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_guard)) goto builtin__type_17_159;
  unify2(a12, a11, a10, a9);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[2] = makecons(cons_const_24);
  allocp[3] = a3;
  allocp[4] = a7;
  allocp[5] = a8;
  allocp[6] = a13;
  allocp[7] = a14;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[10] = a7;
  allocp[11] = makecons(cons_const_54);
  allocp[12] = a15;
  allocp[13] = a13;
  qp = (struct goalrec*)&allocp[8];
  allocp += 14;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x1 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a3,builtin__type_17_133);
  *reasonp++ =  a3;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case VARREF:
  deref_and_jump(a6,builtin__type_17_131);
  *reasonp++ =  a6;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case symval(makesym(atom_less__than)):
 builtin__type_17_134:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_135:
  if (a6 != makeint(2L)) goto builtin__type_17_159;
 builtin__type_17_136:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_guard)) goto builtin__type_17_159;
  unify2(a12, a11, a10, a9);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[2] = makecons(cons_const_24);
  allocp[3] = a3;
  allocp[4] = a7;
  allocp[5] = a8;
  allocp[6] = a13;
  allocp[7] = a14;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[10] = a7;
  allocp[11] = makecons(cons_const_54);
  allocp[12] = a15;
  allocp[13] = a13;
  qp = (struct goalrec*)&allocp[8];
  allocp += 14;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x1 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a3,builtin__type_17_136);
  *reasonp++ =  a3;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case VARREF:
  deref_and_jump(a6,builtin__type_17_134);
  *reasonp++ =  a6;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case symval(makesym(atom_float)):
 builtin__type_17_137:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_138:
  if (a6 != makeint(1L)) goto builtin__type_17_159;
 builtin__type_17_139:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_guard)) goto builtin__type_17_159;
  unify2(a12, a11, a10, a9);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[2] = makecons(cons_const_14);
  allocp[3] = a3;
  allocp[4] = a7;
  allocp[5] = a8;
  allocp[6] = a13;
  allocp[7] = a14;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[10] = a7;
  allocp[11] = makecons(cons_const_38);
  allocp[12] = a15;
  allocp[13] = a13;
  qp = (struct goalrec*)&allocp[8];
  allocp += 14;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(1L);
  allocp[3] = a7;
  allocp[4] = x0 = makeref(&allocp[4]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case VARREF:
  deref_and_jump(a3,builtin__type_17_139);
  *reasonp++ =  a3;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case VARREF:
  deref_and_jump(a6,builtin__type_17_137);
  *reasonp++ =  a6;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case symval(makesym(atom_functor)):
 builtin__type_17_140:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_141:
  if (a6 != makeint(3L)) goto builtin__type_17_159;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xset__types_11);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a3;
  allocp[5] = a2;
  allocp[6] = x0 = makeref(&allocp[6]);
  allocp[7] = makesym(atom_o);
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = x3 = makeref(&allocp[11]);
  allocp[12] = a12;
  allocp[13] = (q)(struct goalrec*)&allocp[0];
  allocp[14] = (q)(&predicate_type_xset__types_11);
  allocp[15] = a0;
  allocp[16] = a1;
  allocp[17] = a3;
  allocp[18] = a2;
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = makesym(atom_o);
  allocp[21] = x5 = makeref(&allocp[21]);
  allocp[22] = a9;
  allocp[23] = x2;
  allocp[24] = a11;
  allocp[25] = x3;
  allocp[26] = makesym(functor_goal_4);
  allocp[27] = a0;
  allocp[28] = a1;
  allocp[29] = a2;
  allocp[30] = a3;
  x6 = makefunctor(&allocp[26]);
  allocp[31] = (q)(struct goalrec*)&allocp[13];
  allocp[32] = (q)(&predicate_builtin__type_xupdate__type__functor_4);
  allocp[33] = x7 = makeref(&allocp[33]);
  allocp[34] = x5;
  allocp[35] = x1;
  allocp[36] = x6;
  allocp[37] = (q)(struct goalrec*)&allocp[31];
  allocp[38] = (q)(&predicate_type_xget__arg__types_5);
  allocp[39] = a0;
  allocp[40] = a1;
  allocp[41] = x8 = makeref(&allocp[41]);
  allocp[42] = a9;
  allocp[43] = x7;
  allocp[44] = (q)(struct goalrec*)&allocp[37];
  allocp[45] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[46] = makecons(cons_const_19);
  allocp[47] = a3;
  allocp[48] = a7;
  allocp[49] = a8;
  allocp[50] = a13;
  allocp[51] = a14;
  allocp[52] = (q)(struct goalrec*)&allocp[44];
  allocp[53] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[54] = a7;
  allocp[55] = makecons(cons_const_45);
  allocp[56] = a15;
  allocp[57] = a13;
  qp = (struct goalrec*)&allocp[52];
  allocp += 58;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x0;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x4;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x8;
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_140);
  *reasonp++ =  a6;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case symval(makesym(atom_arg)):
 builtin__type_17_142:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_143:
  if (a6 != makeint(3L)) goto builtin__type_17_159;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xset__types_11);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a3;
  allocp[5] = a2;
  allocp[6] = x0 = makeref(&allocp[6]);
  allocp[7] = makesym(atom_o);
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = a11;
  allocp[12] = a12;
  allocp[13] = makesym(functor_goal_4);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  x2 = makefunctor(&allocp[13]);
  allocp[18] = (q)(struct goalrec*)&allocp[0];
  allocp[19] = (q)(&predicate_builtin__type_xupdate__type__arg_4);
  allocp[20] = x3 = makeref(&allocp[20]);
  allocp[21] = x4 = makeref(&allocp[21]);
  allocp[22] = x1;
  allocp[23] = x2;
  allocp[24] = (q)(struct goalrec*)&allocp[18];
  allocp[25] = (q)(&predicate_type_xtype2int_2);
  allocp[26] = x5 = makeref(&allocp[26]);
  allocp[27] = x3;
  allocp[28] = (q)(struct goalrec*)&allocp[24];
  allocp[29] = (q)(&predicate_type_xget__arg__types_5);
  allocp[30] = a0;
  allocp[31] = a1;
  allocp[32] = x6 = makeref(&allocp[32]);
  allocp[33] = a9;
  allocp[34] = x4;
  allocp[35] = (q)(struct goalrec*)&allocp[28];
  allocp[36] = (q)(&predicate_type_xget__arg__types_5);
  allocp[37] = a0;
  allocp[38] = a1;
  allocp[39] = x7 = makeref(&allocp[39]);
  allocp[40] = a9;
  allocp[41] = x5;
  allocp[42] = (q)(struct goalrec*)&allocp[35];
  allocp[43] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[44] = makecons(cons_const_27);
  allocp[45] = a3;
  allocp[46] = a7;
  allocp[47] = a8;
  allocp[48] = a13;
  allocp[49] = a14;
  allocp[50] = (q)(struct goalrec*)&allocp[42];
  allocp[51] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[52] = a7;
  allocp[53] = makecons(cons_const_79);
  allocp[54] = a15;
  allocp[55] = a13;
  qp = (struct goalrec*)&allocp[50];
  allocp += 56;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x0;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x6;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x7;
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_142);
  *reasonp++ =  a6;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case symval(makesym(atom_new__functor)):
 builtin__type_17_144:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_145:
  if (a6 != makeint(3L)) goto builtin__type_17_159;
 builtin__type_17_146:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_body)) goto builtin__type_17_159;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xset__types_11);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a3;
  allocp[5] = a2;
  allocp[6] = x0 = makeref(&allocp[6]);
  allocp[7] = makesym(atom_o);
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = a11;
  allocp[12] = a12;
  allocp[13] = makesym(functor_goal_4);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  x2 = makefunctor(&allocp[13]);
  allocp[18] = (q)(struct goalrec*)&allocp[0];
  allocp[19] = (q)(&predicate_builtin__type_xupdate__type__new__functor_4);
  allocp[20] = x3 = makeref(&allocp[20]);
  allocp[21] = x4 = makeref(&allocp[21]);
  allocp[22] = x1;
  allocp[23] = x2;
  allocp[24] = (q)(struct goalrec*)&allocp[18];
  allocp[25] = (q)(&predicate_type_xtype2int_2);
  allocp[26] = x5 = makeref(&allocp[26]);
  allocp[27] = x4;
  allocp[28] = (q)(struct goalrec*)&allocp[24];
  allocp[29] = (q)(&predicate_type_xtype2atom_2);
  allocp[30] = x6 = makeref(&allocp[30]);
  allocp[31] = x3;
  allocp[32] = (q)(struct goalrec*)&allocp[28];
  allocp[33] = (q)(&predicate_type_xget__arg__types_5);
  allocp[34] = a0;
  allocp[35] = a1;
  allocp[36] = x7 = makeref(&allocp[36]);
  allocp[37] = a9;
  allocp[38] = x5;
  allocp[39] = (q)(struct goalrec*)&allocp[32];
  allocp[40] = (q)(&predicate_type_xget__arg__types_5);
  allocp[41] = a0;
  allocp[42] = a1;
  allocp[43] = x8 = makeref(&allocp[43]);
  allocp[44] = a9;
  allocp[45] = x6;
  allocp[46] = (q)(struct goalrec*)&allocp[39];
  allocp[47] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[48] = makecons(cons_const_13);
  allocp[49] = a3;
  allocp[50] = a7;
  allocp[51] = a8;
  allocp[52] = a13;
  allocp[53] = a14;
  allocp[54] = (q)(struct goalrec*)&allocp[46];
  allocp[55] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[56] = a7;
  allocp[57] = makecons(cons_const_7);
  allocp[58] = a15;
  allocp[59] = a13;
  qp = (struct goalrec*)&allocp[54];
  allocp += 60;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x7;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x8;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x0;
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(a3,builtin__type_17_146);
  *reasonp++ =  a3;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case VARREF:
  deref_and_jump(a6,builtin__type_17_144);
  *reasonp++ =  a6;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case symval(makesym(atom_setarg)):
 builtin__type_17_147:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_148:
  switch ((unsigned long)a6) {
 case (unsigned long) makeint(4L):
 builtin__type_17_149:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_body)) goto builtin__type_17_159;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xset__types_11);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a3;
  allocp[5] = a2;
  allocp[6] = x0 = makeref(&allocp[6]);
  allocp[7] = makesym(atom_o);
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = a11;
  allocp[12] = a12;
  allocp[13] = makesym(functor_goal_4);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  x2 = makefunctor(&allocp[13]);
  allocp[18] = (q)(struct goalrec*)&allocp[0];
  allocp[19] = (q)(&predicate_builtin__type_xupdate__type__setarg_6);
  allocp[20] = x3 = makeref(&allocp[20]);
  allocp[21] = x4 = makeref(&allocp[21]);
  allocp[22] = x5 = makeref(&allocp[22]);
  allocp[23] = x1;
  allocp[24] = x6 = makeref(&allocp[24]);
  allocp[25] = x2;
  allocp[26] = (q)(struct goalrec*)&allocp[18];
  allocp[27] = (q)(&predicate_type_xtype2structtype_2);
  allocp[28] = x7 = makeref(&allocp[28]);
  allocp[29] = x4;
  allocp[30] = (q)(struct goalrec*)&allocp[26];
  allocp[31] = (q)(&predicate_type_xtype2int_2);
  allocp[32] = x8 = makeref(&allocp[32]);
  allocp[33] = x3;
  allocp[34] = (q)(struct goalrec*)&allocp[30];
  allocp[35] = (q)(&predicate_type_xget__arg__types_5);
  allocp[36] = a0;
  allocp[37] = a1;
  allocp[38] = x9 = makeref(&allocp[38]);
  allocp[39] = a9;
  allocp[40] = x5;
  allocp[41] = (q)(struct goalrec*)&allocp[34];
  allocp[42] = (q)(&predicate_type_xget__arg__types_5);
  allocp[43] = a0;
  allocp[44] = a1;
  allocp[45] = x10 = makeref(&allocp[45]);
  allocp[46] = a9;
  allocp[47] = x7;
  allocp[48] = (q)(struct goalrec*)&allocp[41];
  allocp[49] = (q)(&predicate_type_xget__arg__types_5);
  allocp[50] = a0;
  allocp[51] = a1;
  allocp[52] = x11 = makeref(&allocp[52]);
  allocp[53] = a9;
  allocp[54] = x8;
  allocp[55] = (q)(struct goalrec*)&allocp[48];
  allocp[56] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[57] = makecons(cons_const_36);
  allocp[58] = a3;
  allocp[59] = a7;
  allocp[60] = a8;
  allocp[61] = a13;
  allocp[62] = a14;
  allocp[63] = (q)(struct goalrec*)&allocp[55];
  allocp[64] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[65] = a7;
  allocp[66] = makecons(cons_const_74);
  allocp[67] = a15;
  allocp[68] = a13;
  qp = (struct goalrec*)&allocp[63];
  allocp += 69;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(4L);
  allocp[3] = a7;
  allocp[4] = x0;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(3L);
  allocp[8] = a7;
  allocp[9] = x9;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(2L);
  allocp[13] = a7;
  allocp[14] = x10;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_functor__table_xarg_3);
  allocp[17] = makeint(1L);
  allocp[18] = a7;
  allocp[19] = x11;
  qp = (struct goalrec*)&allocp[15];
  allocp += 20;
  proceed();
 case VARREF:
  deref_and_jump(a3,builtin__type_17_149);
  *reasonp++ =  a3;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case (unsigned long) makeint(5L):
 builtin__type_17_150:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_body)) goto builtin__type_17_159;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xset__types_11);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a3;
  allocp[5] = a2;
  allocp[6] = x0 = makeref(&allocp[6]);
  allocp[7] = makesym(atom_o);
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = x3 = makeref(&allocp[11]);
  allocp[12] = a12;
  allocp[13] = (q)(struct goalrec*)&allocp[0];
  allocp[14] = (q)(&predicate_type_xset__types_11);
  allocp[15] = a0;
  allocp[16] = a1;
  allocp[17] = a3;
  allocp[18] = a2;
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = makesym(atom_o);
  allocp[21] = x5 = makeref(&allocp[21]);
  allocp[22] = a9;
  allocp[23] = x2;
  allocp[24] = a11;
  allocp[25] = x3;
  allocp[26] = makesym(functor_goal_4);
  allocp[27] = a0;
  allocp[28] = a1;
  allocp[29] = a2;
  allocp[30] = a3;
  x6 = makefunctor(&allocp[26]);
  allocp[31] = (q)(struct goalrec*)&allocp[13];
  allocp[32] = (q)(&predicate_builtin__type_xupdate__type__setarg_6);
  allocp[33] = x7 = makeref(&allocp[33]);
  allocp[34] = x8 = makeref(&allocp[34]);
  allocp[35] = x9 = makeref(&allocp[35]);
  allocp[36] = x1;
  allocp[37] = x5;
  allocp[38] = x6;
  allocp[39] = (q)(struct goalrec*)&allocp[31];
  allocp[40] = (q)(&predicate_type_xtype2structtype_2);
  allocp[41] = x10 = makeref(&allocp[41]);
  allocp[42] = x8;
  allocp[43] = (q)(struct goalrec*)&allocp[39];
  allocp[44] = (q)(&predicate_type_xtype2int_2);
  allocp[45] = x11 = makeref(&allocp[45]);
  allocp[46] = x7;
  allocp[47] = (q)(struct goalrec*)&allocp[43];
  allocp[48] = (q)(&predicate_type_xget__arg__types_5);
  allocp[49] = a0;
  allocp[50] = a1;
  allocp[51] = x12 = makeref(&allocp[51]);
  allocp[52] = a9;
  allocp[53] = x9;
  allocp[54] = (q)(struct goalrec*)&allocp[47];
  allocp[55] = (q)(&predicate_type_xget__arg__types_5);
  allocp[56] = a0;
  allocp[57] = a1;
  allocp[58] = x13 = makeref(&allocp[58]);
  allocp[59] = a9;
  allocp[60] = x10;
  allocp[61] = (q)(struct goalrec*)&allocp[54];
  allocp[62] = (q)(&predicate_type_xget__arg__types_5);
  allocp[63] = a0;
  allocp[64] = a1;
  allocp[65] = x14 = makeref(&allocp[65]);
  allocp[66] = a9;
  allocp[67] = x11;
  allocp[68] = (q)(struct goalrec*)&allocp[61];
  allocp[69] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[70] = makecons(cons_const_32);
  allocp[71] = a3;
  allocp[72] = a7;
  allocp[73] = a8;
  allocp[74] = a13;
  allocp[75] = a14;
  allocp[76] = (q)(struct goalrec*)&allocp[68];
  allocp[77] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[78] = a7;
  allocp[79] = makecons(cons_const_67);
  allocp[80] = a15;
  allocp[81] = a13;
  qp = (struct goalrec*)&allocp[76];
  allocp += 82;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(5L);
  allocp[3] = a7;
  allocp[4] = x0;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(4L);
  allocp[8] = a7;
  allocp[9] = x12;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(3L);
  allocp[13] = a7;
  allocp[14] = x4;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_functor__table_xarg_3);
  allocp[17] = makeint(2L);
  allocp[18] = a7;
  allocp[19] = x13;
  allocp[20] = (q)(struct goalrec*)&allocp[15];
  allocp[21] = (q)(&predicate_functor__table_xarg_3);
  allocp[22] = makeint(1L);
  allocp[23] = a7;
  allocp[24] = x14;
  qp = (struct goalrec*)&allocp[20];
  allocp += 25;
  proceed();
 case VARREF:
  deref_and_jump(a3,builtin__type_17_150);
  *reasonp++ =  a3;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case VARREF:
  deref_and_jump(a6,builtin__type_17_147);
  *reasonp++ =  a6;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case symval(makesym(atom_list)):
 builtin__type_17_151:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_152:
  if (a6 != makeint(1L)) goto builtin__type_17_159;
 builtin__type_17_153:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_guard)) goto builtin__type_17_159;
  unify2(a12, a11, a10, a9);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[2] = makecons(cons_const_14);
  allocp[3] = a3;
  allocp[4] = a7;
  allocp[5] = a8;
  allocp[6] = a13;
  allocp[7] = a14;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[10] = a7;
  allocp[11] = makecons(cons_const_38);
  allocp[12] = a15;
  allocp[13] = a13;
  qp = (struct goalrec*)&allocp[8];
  allocp += 14;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(1L);
  allocp[3] = a7;
  allocp[4] = x0 = makeref(&allocp[4]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case VARREF:
  deref_and_jump(a3,builtin__type_17_153);
  *reasonp++ =  a3;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case VARREF:
  deref_and_jump(a6,builtin__type_17_151);
  *reasonp++ =  a6;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case symval(makesym(atom_vector)):
 builtin__type_17_154:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_155:
  if (a6 != makeint(2L)) goto builtin__type_17_159;
 builtin__type_17_156:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_guard)) goto builtin__type_17_159;
 builtin__type_17_157:
  if (isref(a7)) goto builtin__type_17_158;
  gblt_arg(makeint(1L),a7,x0,builtin__type_17_159);
  gblt_arg(makeint(2L),a7,x1,builtin__type_17_159);
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x2 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x2;
  x3 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x4 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x4;
  x5 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_i);
  allocp[16] = x3;
  allocp[17] = x5;
  allocp[18] = makesym(atom_u);
  x6 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x6;
  x7 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x1;
  allocp[28] = makesym(atom_o);
  allocp[29] = x7;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_16);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  a0 = a7;
  a1 = makecons(cons_const_41);
  a2 = a15;
  a3 = a13;
  qp = (struct goalrec*)&allocp[34];
  allocp += 42;
  execute(create__goal__wait_4_0);
  goto create__goal__wait_4_ext_interrupt;
 builtin__type_17_158:
  deref_and_jump(a7,builtin__type_17_157);
  *reasonp++ =  a7;
  goto builtin__type_17_159;
 case VARREF:
  deref_and_jump(a3,builtin__type_17_156);
  *reasonp++ =  a3;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case VARREF:
  deref_and_jump(a6,builtin__type_17_154);
  *reasonp++ =  a6;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 case VARREF:
  deref_and_jump(a5,builtin__type_17_69);
  *reasonp++ =  a5;
  goto builtin__type_17_159;
  };
  goto builtin__type_17_159;
 builtin__type_17_159:
 builtin__type_17_160:
  switch (ptagof(a4)) {
 case ATOMIC:
  if (isint(a4)) goto builtin__type_17_251;
  switch (symval(a4)) {
 case symval(makesym(atom_builtin)):
 builtin__type_17_161:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (isint(a5)) goto builtin__type_17_251;
  switch (symval(a5)) {
 case symval(makesym(atom_add)):
 builtin__type_17_162:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_163:
  if (a6 != makeint(3L)) goto builtin__type_17_251;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_i);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_27);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_59);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x8 = makeref(&allocp[14]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_162);
  *reasonp++ =  a6;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case symval(makesym(atom_subtract)):
 builtin__type_17_164:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_165:
  if (a6 != makeint(3L)) goto builtin__type_17_251;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_i);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_27);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_59);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x8 = makeref(&allocp[14]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_164);
  *reasonp++ =  a6;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case symval(makesym(atom_multiply)):
 builtin__type_17_166:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_167:
  if (a6 != makeint(3L)) goto builtin__type_17_251;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_i);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_27);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_59);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x8 = makeref(&allocp[14]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_166);
  *reasonp++ =  a6;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case symval(makesym(atom_divide)):
 builtin__type_17_168:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_169:
  if (a6 != makeint(3L)) goto builtin__type_17_251;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_i);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_27);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_59);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x8 = makeref(&allocp[14]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_168);
  *reasonp++ =  a6;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case VARREF:
  deref_and_jump(a5,builtin__type_17_161);
  *reasonp++ =  a5;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case symval(makesym(atom_generic)):
 builtin__type_17_170:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (isint(a5)) goto builtin__type_17_251;
  switch (symval(a5)) {
 case symval(makesym(atom_float)):
 builtin__type_17_171:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_172:
  if (a6 != makeint(1L)) goto builtin__type_17_251;
 builtin__type_17_173:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_guard)) goto builtin__type_17_251;
  unify2(a12, a11, a10, a9);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[2] = makecons(cons_const_14);
  allocp[3] = a3;
  allocp[4] = a7;
  allocp[5] = a8;
  allocp[6] = a13;
  allocp[7] = a14;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[10] = a7;
  allocp[11] = makecons(cons_const_38);
  allocp[12] = a15;
  allocp[13] = a13;
  qp = (struct goalrec*)&allocp[8];
  allocp += 14;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(1L);
  allocp[3] = a7;
  allocp[4] = x0 = makeref(&allocp[4]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case VARREF:
  deref_and_jump(a3,builtin__type_17_173);
  *reasonp++ =  a3;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case VARREF:
  deref_and_jump(a6,builtin__type_17_171);
  *reasonp++ =  a6;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case symval(makesym(atom_new)):
 builtin__type_17_174:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_175:
  if (a6 != makeint(3L)) goto builtin__type_17_251;
 builtin__type_17_176:
  if (isref(a7)) goto builtin__type_17_179;
  gblt_arg(makeint(1L),a7,x0,builtin__type_17_251);
 builtin__type_17_177:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_atom_1)) goto builtin__type_17_251;
  x1 = arg(x0, 0);
 builtin__type_17_178:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (isint(x1)) goto builtin__type_17_251;
  switch (symval(x1)) {
 case symval(makesym(atom_float)):
  gblt_arg(makeint(2L),a7,x2,builtin__type_17_251);
  gblt_arg(makeint(3L),a7,x3,builtin__type_17_251);
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x4 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x4;
  x5 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x6 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x6;
  x7 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_f);
  allocp[16] = x5;
  allocp[17] = x7;
  allocp[18] = makesym(atom_u);
  x8 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x8;
  x9 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x2;
  allocp[28] = makesym(atom_o);
  allocp[29] = x9;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_22);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  a0 = a7;
  a1 = makecons(cons_const_50);
  a2 = a15;
  a3 = a13;
  qp = (struct goalrec*)&allocp[34];
  allocp += 42;
  execute(create__goal__wait_4_clear_reason);
  goto create__goal__wait_4_ext_interrupt;
 case symval(makesym(atom_vector)):
  gblt_arg(makeint(2L),a7,x2,builtin__type_17_251);
  gblt_arg(makeint(3L),a7,x3,builtin__type_17_251);
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xset__types_11);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a3;
  allocp[5] = a2;
  allocp[6] = x2;
  allocp[7] = makesym(atom_o);
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = a11;
  allocp[12] = a12;
  allocp[13] = makesym(functor_goal_4);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  x5 = makefunctor(&allocp[13]);
  allocp[18] = (q)(struct goalrec*)&allocp[0];
  allocp[19] = (q)(&predicate_builtin__type_xupdate__type__new__vector_4);
  allocp[20] = x6 = makeref(&allocp[20]);
  allocp[21] = x7 = makeref(&allocp[21]);
  allocp[22] = x4;
  allocp[23] = x5;
  allocp[24] = (q)(struct goalrec*)&allocp[18];
  allocp[25] = (q)(&predicate_print_xdatan_1);
  allocp[26] = x7;
  allocp[27] = (q)(struct goalrec*)&allocp[24];
  allocp[28] = (q)(&predicate_print_xdata_1);
  allocp[29] = makesym(atom_XXIL_3A);
  allocp[30] = (q)(struct goalrec*)&allocp[27];
  allocp[31] = (q)(&predicate_type_xtype2list_2);
  allocp[32] = x8 = makeref(&allocp[32]);
  allocp[33] = x7;
  allocp[34] = (q)(struct goalrec*)&allocp[30];
  allocp[35] = (q)(&predicate_type_xtype2int_2);
  allocp[36] = x8;
  allocp[37] = x6;
  allocp[38] = (q)(struct goalrec*)&allocp[34];
  allocp[39] = (q)(&predicate_type_xget__arg__types_5);
  allocp[40] = a0;
  allocp[41] = a1;
  allocp[42] = x3;
  allocp[43] = a9;
  allocp[44] = x8;
  allocp[45] = (q)(struct goalrec*)&allocp[38];
  allocp[46] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[47] = makecons(cons_const_22);
  allocp[48] = a3;
  allocp[49] = a7;
  allocp[50] = a8;
  allocp[51] = a13;
  allocp[52] = a14;
  a0 = a7;
  a1 = makecons(cons_const_50);
  a2 = a15;
  a3 = a13;
  qp = (struct goalrec*)&allocp[45];
  allocp += 53;
  execute(create__goal__wait_4_clear_reason);
  goto create__goal__wait_4_ext_interrupt;
  };
  goto builtin__type_17_251;
 case VARREF:
  deref_and_jump(x1,builtin__type_17_178);
  *reasonp++ =  x1;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case VARREF:
  deref_and_jump(x0,builtin__type_17_177);
  *reasonp++ =  x0;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 builtin__type_17_179:
  deref_and_jump(a7,builtin__type_17_176);
  *reasonp++ =  a7;
  goto builtin__type_17_251;
 case VARREF:
  deref_and_jump(a6,builtin__type_17_174);
  *reasonp++ =  a6;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case symval(makesym(atom_add)):
 builtin__type_17_180:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_181:
  if (a6 != makeint(3L)) goto builtin__type_17_251;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_f);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_27);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_59);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x8 = makeref(&allocp[14]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_180);
  *reasonp++ =  a6;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case symval(makesym(atom_subtract)):
 builtin__type_17_182:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_183:
  if (a6 != makeint(3L)) goto builtin__type_17_251;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_f);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_27);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_59);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x8 = makeref(&allocp[14]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_182);
  *reasonp++ =  a6;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case symval(makesym(atom_multiply)):
 builtin__type_17_184:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_185:
  if (a6 != makeint(3L)) goto builtin__type_17_251;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_f);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_27);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_59);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x8 = makeref(&allocp[14]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_184);
  *reasonp++ =  a6;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case symval(makesym(atom_divide)):
 builtin__type_17_186:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_187:
  if (a6 != makeint(3L)) goto builtin__type_17_251;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_f);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_27);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_59);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x8 = makeref(&allocp[14]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_186);
  *reasonp++ =  a6;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case symval(makesym(atom_pow)):
 builtin__type_17_188:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_189:
  if (a6 != makeint(3L)) goto builtin__type_17_251;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_f);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_27);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_59);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x8 = makeref(&allocp[14]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_188);
  *reasonp++ =  a6;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case symval(makesym(atom_sin)):
 builtin__type_17_190:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_191:
  if (a6 != makeint(2L)) goto builtin__type_17_251;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_f);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_16);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_41);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_190);
  *reasonp++ =  a6;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case symval(makesym(atom_cos)):
 builtin__type_17_192:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_193:
  if (a6 != makeint(2L)) goto builtin__type_17_251;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_f);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_16);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_41);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_192);
  *reasonp++ =  a6;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case symval(makesym(atom_tan)):
 builtin__type_17_194:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_195:
  if (a6 != makeint(2L)) goto builtin__type_17_251;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_f);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_16);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_41);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_194);
  *reasonp++ =  a6;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case symval(makesym(atom_asin)):
 builtin__type_17_196:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_197:
  if (a6 != makeint(2L)) goto builtin__type_17_251;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_f);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_16);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_41);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_196);
  *reasonp++ =  a6;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case symval(makesym(atom_acos)):
 builtin__type_17_198:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_199:
  if (a6 != makeint(2L)) goto builtin__type_17_251;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_f);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_16);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_41);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_198);
  *reasonp++ =  a6;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case symval(makesym(atom_atan)):
 builtin__type_17_200:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_201:
  if (a6 != makeint(2L)) goto builtin__type_17_251;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_f);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_16);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_41);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_200);
  *reasonp++ =  a6;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case symval(makesym(atom_sinh)):
 builtin__type_17_202:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_203:
  if (a6 != makeint(2L)) goto builtin__type_17_251;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_f);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_16);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_41);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_202);
  *reasonp++ =  a6;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case symval(makesym(atom_cosh)):
 builtin__type_17_204:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_205:
  if (a6 != makeint(2L)) goto builtin__type_17_251;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_f);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_16);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_41);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_204);
  *reasonp++ =  a6;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case symval(makesym(atom_tanh)):
 builtin__type_17_206:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_207:
  if (a6 != makeint(2L)) goto builtin__type_17_251;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_f);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_16);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_41);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_206);
  *reasonp++ =  a6;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case symval(makesym(atom_exp)):
 builtin__type_17_208:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_209:
  if (a6 != makeint(2L)) goto builtin__type_17_251;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_f);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_16);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_41);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_208);
  *reasonp++ =  a6;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case symval(makesym(atom_log)):
 builtin__type_17_210:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_211:
  if (a6 != makeint(2L)) goto builtin__type_17_251;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_f);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_16);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_41);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_210);
  *reasonp++ =  a6;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case symval(makesym(atom_sqrt)):
 builtin__type_17_212:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_213:
  if (a6 != makeint(2L)) goto builtin__type_17_251;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_f);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_16);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_41);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_212);
  *reasonp++ =  a6;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case symval(makesym(atom_ceil)):
 builtin__type_17_214:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_215:
  if (a6 != makeint(2L)) goto builtin__type_17_251;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_f);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_16);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_41);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_214);
  *reasonp++ =  a6;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case symval(makesym(atom_floor)):
 builtin__type_17_216:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_217:
  if (a6 != makeint(2L)) goto builtin__type_17_251;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_f);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = makesym(atom_u);
  x4 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x4;
  x5 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = makesym(atom_o);
  allocp[29] = x5;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_16);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[44] = a7;
  allocp[45] = makecons(cons_const_41);
  allocp[46] = a15;
  allocp[47] = a13;
  qp = (struct goalrec*)&allocp[42];
  allocp += 48;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x7 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_216);
  *reasonp++ =  a6;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case symval(makesym(atom_greater__than)):
 builtin__type_17_218:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_219:
  if (a6 != makeint(2L)) goto builtin__type_17_251;
 builtin__type_17_220:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_guard)) goto builtin__type_17_251;
  unify2(a12, a11, a10, a9);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[2] = makecons(cons_const_24);
  allocp[3] = a3;
  allocp[4] = a7;
  allocp[5] = a8;
  allocp[6] = a13;
  allocp[7] = a14;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[10] = a7;
  allocp[11] = makecons(cons_const_54);
  allocp[12] = a15;
  allocp[13] = a13;
  qp = (struct goalrec*)&allocp[8];
  allocp += 14;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x1 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a3,builtin__type_17_220);
  *reasonp++ =  a3;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case VARREF:
  deref_and_jump(a6,builtin__type_17_218);
  *reasonp++ =  a6;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case symval(makesym(atom_not__less__than)):
 builtin__type_17_221:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_222:
  if (a6 != makeint(2L)) goto builtin__type_17_251;
 builtin__type_17_223:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_guard)) goto builtin__type_17_251;
  unify2(a12, a11, a10, a9);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[2] = makecons(cons_const_24);
  allocp[3] = a3;
  allocp[4] = a7;
  allocp[5] = a8;
  allocp[6] = a13;
  allocp[7] = a14;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[10] = a7;
  allocp[11] = makecons(cons_const_54);
  allocp[12] = a15;
  allocp[13] = a13;
  qp = (struct goalrec*)&allocp[8];
  allocp += 14;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x1 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a3,builtin__type_17_223);
  *reasonp++ =  a3;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case VARREF:
  deref_and_jump(a6,builtin__type_17_221);
  *reasonp++ =  a6;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case symval(makesym(atom_equal)):
 builtin__type_17_224:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_225:
  if (a6 != makeint(2L)) goto builtin__type_17_251;
 builtin__type_17_226:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_guard)) goto builtin__type_17_251;
  unify2(a12, a11, a10, a9);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[2] = makecons(cons_const_24);
  allocp[3] = a3;
  allocp[4] = a7;
  allocp[5] = a8;
  allocp[6] = a13;
  allocp[7] = a14;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[10] = a7;
  allocp[11] = makecons(cons_const_54);
  allocp[12] = a15;
  allocp[13] = a13;
  qp = (struct goalrec*)&allocp[8];
  allocp += 14;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x1 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a3,builtin__type_17_226);
  *reasonp++ =  a3;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case VARREF:
  deref_and_jump(a6,builtin__type_17_224);
  *reasonp++ =  a6;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case symval(makesym(atom_not__equal)):
 builtin__type_17_227:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_228:
  if (a6 != makeint(2L)) goto builtin__type_17_251;
 builtin__type_17_229:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_guard)) goto builtin__type_17_251;
  unify2(a12, a11, a10, a9);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[2] = makecons(cons_const_24);
  allocp[3] = a3;
  allocp[4] = a7;
  allocp[5] = a8;
  allocp[6] = a13;
  allocp[7] = a14;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[10] = a7;
  allocp[11] = makecons(cons_const_54);
  allocp[12] = a15;
  allocp[13] = a13;
  qp = (struct goalrec*)&allocp[8];
  allocp += 14;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x1 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a3,builtin__type_17_229);
  *reasonp++ =  a3;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case VARREF:
  deref_and_jump(a6,builtin__type_17_227);
  *reasonp++ =  a6;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case symval(makesym(atom_not__greater__than)):
 builtin__type_17_230:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_231:
  if (a6 != makeint(2L)) goto builtin__type_17_251;
 builtin__type_17_232:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_guard)) goto builtin__type_17_251;
  unify2(a12, a11, a10, a9);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[2] = makecons(cons_const_24);
  allocp[3] = a3;
  allocp[4] = a7;
  allocp[5] = a8;
  allocp[6] = a13;
  allocp[7] = a14;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[10] = a7;
  allocp[11] = makecons(cons_const_54);
  allocp[12] = a15;
  allocp[13] = a13;
  qp = (struct goalrec*)&allocp[8];
  allocp += 14;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x1 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a3,builtin__type_17_232);
  *reasonp++ =  a3;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case VARREF:
  deref_and_jump(a6,builtin__type_17_230);
  *reasonp++ =  a6;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case symval(makesym(atom_less__than)):
 builtin__type_17_233:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_234:
  if (a6 != makeint(2L)) goto builtin__type_17_251;
 builtin__type_17_235:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_guard)) goto builtin__type_17_251;
  unify2(a12, a11, a10, a9);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[2] = makecons(cons_const_24);
  allocp[3] = a3;
  allocp[4] = a7;
  allocp[5] = a8;
  allocp[6] = a13;
  allocp[7] = a14;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[10] = a7;
  allocp[11] = makecons(cons_const_54);
  allocp[12] = a15;
  allocp[13] = a13;
  qp = (struct goalrec*)&allocp[8];
  allocp += 14;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x1 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a3,builtin__type_17_235);
  *reasonp++ =  a3;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case VARREF:
  deref_and_jump(a6,builtin__type_17_233);
  *reasonp++ =  a6;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case symval(makesym(atom_size)):
 builtin__type_17_236:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_237:
  if (a6 != makeint(2L)) goto builtin__type_17_251;
 builtin__type_17_238:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_body)) goto builtin__type_17_251;
 builtin__type_17_239:
  if (isref(a7)) goto builtin__type_17_240;
  gblt_arg(makeint(1L),a7,x0,builtin__type_17_251);
  gblt_arg(makeint(2L),a7,x1,builtin__type_17_251);
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x2 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x2;
  x3 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x4 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x4;
  x5 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_i);
  allocp[16] = x3;
  allocp[17] = x5;
  allocp[18] = makesym(atom_u);
  x6 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x6;
  x7 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x1;
  allocp[28] = makesym(atom_o);
  allocp[29] = x7;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_16);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  a0 = a7;
  a1 = makecons(cons_const_41);
  a2 = a15;
  a3 = a13;
  qp = (struct goalrec*)&allocp[34];
  allocp += 42;
  execute(create__goal__wait_4_clear_reason);
  goto create__goal__wait_4_ext_interrupt;
 builtin__type_17_240:
  deref_and_jump(a7,builtin__type_17_239);
  *reasonp++ =  a7;
  goto builtin__type_17_251;
 case VARREF:
  deref_and_jump(a3,builtin__type_17_238);
  *reasonp++ =  a3;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case VARREF:
  deref_and_jump(a6,builtin__type_17_236);
  *reasonp++ =  a6;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case symval(makesym(atom_vector)):
 builtin__type_17_241:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_242:
  if (a6 != makeint(2L)) goto builtin__type_17_251;
 builtin__type_17_243:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_guard)) goto builtin__type_17_251;
 builtin__type_17_244:
  if (isref(a7)) goto builtin__type_17_245;
  gblt_arg(makeint(1L),a7,x0,builtin__type_17_251);
  gblt_arg(makeint(2L),a7,x1,builtin__type_17_251);
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x2 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x2;
  x3 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_goal_4);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x4 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x4;
  x5 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = makesym(atom_i);
  allocp[16] = x3;
  allocp[17] = x5;
  allocp[18] = makesym(atom_u);
  x6 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x6;
  x7 = makecons(&allocp[19]);
  allocp[21] = (q)qp;
  allocp[22] = (q)(&predicate_type_xset__types_11);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a3;
  allocp[26] = a2;
  allocp[27] = x1;
  allocp[28] = makesym(atom_o);
  allocp[29] = x7;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[36] = makecons(cons_const_16);
  allocp[37] = a3;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = a13;
  allocp[41] = a14;
  a0 = a7;
  a1 = makecons(cons_const_41);
  a2 = a15;
  a3 = a13;
  qp = (struct goalrec*)&allocp[34];
  allocp += 42;
  execute(create__goal__wait_4_clear_reason);
  goto create__goal__wait_4_ext_interrupt;
 builtin__type_17_245:
  deref_and_jump(a7,builtin__type_17_244);
  *reasonp++ =  a7;
  goto builtin__type_17_251;
 case VARREF:
  deref_and_jump(a3,builtin__type_17_243);
  *reasonp++ =  a3;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case VARREF:
  deref_and_jump(a6,builtin__type_17_241);
  *reasonp++ =  a6;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case symval(makesym(atom_element)):
 builtin__type_17_246:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_247:
  if (a6 != makeint(3L)) goto builtin__type_17_251;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xset__types_11);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a3;
  allocp[5] = a2;
  allocp[6] = x0 = makeref(&allocp[6]);
  allocp[7] = makesym(atom_o);
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = a11;
  allocp[12] = a12;
  allocp[13] = makesym(functor_goal_4);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  x2 = makefunctor(&allocp[13]);
  allocp[18] = (q)(struct goalrec*)&allocp[0];
  allocp[19] = (q)(&predicate_builtin__type_xupdate__type__element_4);
  allocp[20] = x3 = makeref(&allocp[20]);
  allocp[21] = x4 = makeref(&allocp[21]);
  allocp[22] = x1;
  allocp[23] = x2;
  allocp[24] = (q)(struct goalrec*)&allocp[18];
  allocp[25] = (q)(&predicate_type_xtype2int_2);
  allocp[26] = x5 = makeref(&allocp[26]);
  allocp[27] = x3;
  allocp[28] = (q)(struct goalrec*)&allocp[24];
  allocp[29] = (q)(&predicate_type_xget__arg__types_5);
  allocp[30] = a0;
  allocp[31] = a1;
  allocp[32] = x6 = makeref(&allocp[32]);
  allocp[33] = a9;
  allocp[34] = x5;
  allocp[35] = (q)(struct goalrec*)&allocp[28];
  allocp[36] = (q)(&predicate_type_xget__arg__types_5);
  allocp[37] = a0;
  allocp[38] = a1;
  allocp[39] = x7 = makeref(&allocp[39]);
  allocp[40] = a9;
  allocp[41] = x4;
  allocp[42] = (q)(struct goalrec*)&allocp[35];
  allocp[43] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[44] = makecons(cons_const_27);
  allocp[45] = a3;
  allocp[46] = a7;
  allocp[47] = a8;
  allocp[48] = a13;
  allocp[49] = a14;
  allocp[50] = (q)(struct goalrec*)&allocp[42];
  allocp[51] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[52] = a7;
  allocp[53] = makecons(cons_const_89);
  allocp[54] = a15;
  allocp[55] = a13;
  qp = (struct goalrec*)&allocp[50];
  allocp += 56;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x0;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x6;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x7;
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_246);
  *reasonp++ =  a6;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case VARREF:
  deref_and_jump(a5,builtin__type_17_170);
  *reasonp++ =  a5;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case symval(makesym(atom_io)):
 builtin__type_17_248:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (a5 != makesym(atom_outstream)) goto builtin__type_17_251;
 builtin__type_17_249:
  switch (ptagof(a6)) {
 case ATOMIC:
 builtin__type_17_250:
  if (a6 != makeint(1L)) goto builtin__type_17_251;
  unify2(a12, a11, a10, a9);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xset__goal__modes_6);
  allocp[2] = makecons(cons_const_14);
  allocp[3] = a3;
  allocp[4] = a7;
  allocp[5] = a8;
  allocp[6] = a13;
  allocp[7] = a14;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_type__init_xcreate__goal__wait_4);
  allocp[10] = a7;
  allocp[11] = makecons(cons_const_81);
  allocp[12] = a15;
  allocp[13] = a13;
  qp = (struct goalrec*)&allocp[8];
  allocp += 14;
  unify_value(a16, makesym(atom_builtin));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(1L);
  allocp[3] = a7;
  allocp[4] = x0 = makeref(&allocp[4]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case VARREF:
  deref_and_jump(a6,builtin__type_17_249);
  *reasonp++ =  a6;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case VARREF:
  deref_and_jump(a5,builtin__type_17_248);
  *reasonp++ =  a5;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 case VARREF:
  deref_and_jump(a4,builtin__type_17_160);
  *reasonp++ =  a4;
  goto builtin__type_17_251;
  };
  goto builtin__type_17_251;
 builtin__type_17_251:
  otherwise(builtin__type_17_interrupt);
  unify_value(a16, makesym(atom_userdef));
  unify4(a12, a11, a10, a9, a14, a13, a8, a7);
  a0 = a7;
  a1 = a6;
  a2 = a13;
  a3 = a15;
  execute(create__userdef__waits_4_0);
  goto create__userdef__waits_4_ext_interrupt;
 builtin__type_17_ext_interrupt:
  reasonp = 0l;
 builtin__type_17_interrupt:
  toppred = &predicate_type__init_xbuiltin__type_17;
  goto interrupt_17;
 }

 builtin__type__unify_15_top: {
  q x0, x1, x2, x3, x4, x5;
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  qp = qp->next;
 builtin__type__unify_15_clear_reason:
  reasonp = reasons;
 builtin__type__unify_15_0:
 builtin__type__unify_15_1:
  switch (ptagof(a4)) {
 case FUNCTOR:
  if (functor_of(a4) != makesym(functor_variable_3)) goto builtin__type__unify_15_3;
 builtin__type__unify_15_2:
  switch (ptagof(a6)) {
 case FUNCTOR:
  if (functor_of(a6) != makesym(functor_variable_3)) goto builtin__type__unify_15_3;
  unify3(a13, a12, a11, a10, a9, a8);
  unify_value(a7, a6);
  unify_value(a5, a4);
  allocp[0] = makesym(functor_f_2);
  allocp[1] = a4;
  allocp[2] = a6;
  x0 = makefunctor(&allocp[0]);
  a0 = x0;
  a1 = makecons(cons_const_2);
  a2 = a14;
  a3 = a12;
  allocp += 3;
  execute(create__goal__wait_4_0);
  goto create__goal__wait_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a6,builtin__type__unify_15_2);
  *reasonp++ =  a6;
  goto builtin__type__unify_15_3;
  };
  goto builtin__type__unify_15_3;
 case VARREF:
  deref_and_jump(a4,builtin__type__unify_15_1);
  *reasonp++ =  a4;
  goto builtin__type__unify_15_3;
  };
  goto builtin__type__unify_15_3;
 builtin__type__unify_15_3:
  otherwise(builtin__type__unify_15_interrupt);
 builtin__type__unify_15_4:
  switch (ptagof(a4)) {
 case FUNCTOR:
  if (functor_of(a4) != makesym(functor_variable_3)) goto builtin__type__unify_15_6;
 builtin__type__unify_15_5:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (isint(a3)) goto builtin__type__unify_15_6;
  switch (symval(a3)) {
 case symval(makesym(atom_guard)):
  unify3(a11, a10, a9, a8, a7, a6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xset__arg__mode_6);
  allocp[2] = a4;
  allocp[3] = makesym(atom_i);
  allocp[4] = a3;
  allocp[5] = a5;
  allocp[6] = a12;
  allocp[7] = a13;
  allocp[8] = makesym(functor_f_2);
  allocp[9] = a4;
  allocp[10] = a6;
  x0 = makefunctor(&allocp[8]);
  a0 = x0;
  a1 = makecons(cons_const_2);
  a2 = a14;
  a3 = a12;
  qp = (struct goalrec*)&allocp[0];
  allocp += 11;
  execute(create__goal__wait_4_0);
  goto create__goal__wait_4_ext_interrupt;
 case symval(makesym(atom_body)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xset__types_11);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a3;
  allocp[5] = a2;
  allocp[6] = a5;
  allocp[7] = makesym(atom_o);
  allocp[8] = x0 = makeref(&allocp[8]);
  allocp[9] = a8;
  allocp[10] = a9;
  allocp[11] = a10;
  allocp[12] = a11;
  qp = (struct goalrec*)&allocp[0];
  allocp += 13;
  unify(a7, a6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xset__arg__mode_6);
  allocp[2] = a4;
  allocp[3] = makesym(atom_o);
  allocp[4] = a3;
  allocp[5] = a5;
  allocp[6] = a12;
  allocp[7] = a13;
  allocp[8] = makesym(functor_goal_4);
  allocp[9] = a0;
  allocp[10] = a1;
  allocp[11] = a2;
  allocp[12] = a3;
  x1 = makefunctor(&allocp[8]);
  allocp[13] = NILATOM;
  allocp[14] = x1;
  x2 = makecons(&allocp[13]);
  allocp[15] = makesym(functor_goal_4);
  allocp[16] = a0;
  allocp[17] = a1;
  allocp[18] = a2;
  allocp[19] = a3;
  x3 = makefunctor(&allocp[15]);
  allocp[20] = NILATOM;
  allocp[21] = x3;
  x4 = makecons(&allocp[20]);
  allocp[22] = (q)(struct goalrec*)&allocp[0];
  allocp[23] = (q)(&predicate_type_xvalue2types_7);
  allocp[24] = a0;
  allocp[25] = a1;
  allocp[26] = a6;
  allocp[27] = x2;
  allocp[28] = x4;
  allocp[29] = makesym(atom_u);
  allocp[30] = x0;
  allocp[31] = makesym(functor_f_2);
  allocp[32] = a4;
  allocp[33] = a6;
  x5 = makefunctor(&allocp[31]);
  a0 = x5;
  a1 = makecons(cons_const_2);
  a2 = a14;
  a3 = a12;
  qp = (struct goalrec*)&allocp[22];
  allocp += 34;
  execute(create__goal__wait_4_0);
  goto create__goal__wait_4_ext_interrupt;
  };
  goto builtin__type__unify_15_6;
 case VARREF:
  deref_and_jump(a3,builtin__type__unify_15_5);
  *reasonp++ =  a3;
  goto builtin__type__unify_15_6;
  };
  goto builtin__type__unify_15_6;
 case VARREF:
  deref_and_jump(a4,builtin__type__unify_15_4);
  *reasonp++ =  a4;
  goto builtin__type__unify_15_6;
  };
  goto builtin__type__unify_15_6;
 builtin__type__unify_15_6:
 builtin__type__unify_15_7:
  switch (ptagof(a6)) {
 case FUNCTOR:
  if (functor_of(a6) != makesym(functor_variable_3)) goto builtin__type__unify_15_9;
 builtin__type__unify_15_8:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (isint(a3)) goto builtin__type__unify_15_9;
  switch (symval(a3)) {
 case symval(makesym(atom_guard)):
  unify3(a11, a10, a9, a8, a5, a4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xset__arg__mode_6);
  allocp[2] = a6;
  allocp[3] = makesym(atom_i);
  allocp[4] = a3;
  allocp[5] = a7;
  allocp[6] = a12;
  allocp[7] = a13;
  allocp[8] = makesym(functor_f_2);
  allocp[9] = a4;
  allocp[10] = a6;
  x0 = makefunctor(&allocp[8]);
  a0 = x0;
  a1 = makecons(cons_const_2);
  a2 = a14;
  a3 = a12;
  qp = (struct goalrec*)&allocp[0];
  allocp += 11;
  execute(create__goal__wait_4_clear_reason);
  goto create__goal__wait_4_ext_interrupt;
 case symval(makesym(atom_body)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xset__types_11);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a3;
  allocp[5] = a2;
  allocp[6] = a7;
  allocp[7] = makesym(atom_o);
  allocp[8] = x0 = makeref(&allocp[8]);
  allocp[9] = a8;
  allocp[10] = a9;
  allocp[11] = a10;
  allocp[12] = a11;
  qp = (struct goalrec*)&allocp[0];
  allocp += 13;
  unify(a5, a4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xset__arg__mode_6);
  allocp[2] = a6;
  allocp[3] = makesym(atom_o);
  allocp[4] = a3;
  allocp[5] = a7;
  allocp[6] = a12;
  allocp[7] = a13;
  allocp[8] = makesym(functor_goal_4);
  allocp[9] = a0;
  allocp[10] = a1;
  allocp[11] = a2;
  allocp[12] = a3;
  x1 = makefunctor(&allocp[8]);
  allocp[13] = NILATOM;
  allocp[14] = x1;
  x2 = makecons(&allocp[13]);
  allocp[15] = makesym(functor_goal_4);
  allocp[16] = a0;
  allocp[17] = a1;
  allocp[18] = a2;
  allocp[19] = a3;
  x3 = makefunctor(&allocp[15]);
  allocp[20] = NILATOM;
  allocp[21] = x3;
  x4 = makecons(&allocp[20]);
  allocp[22] = (q)(struct goalrec*)&allocp[0];
  allocp[23] = (q)(&predicate_type_xvalue2types_7);
  allocp[24] = a0;
  allocp[25] = a1;
  allocp[26] = a4;
  allocp[27] = x2;
  allocp[28] = x4;
  allocp[29] = makesym(atom_u);
  allocp[30] = x0;
  allocp[31] = makesym(functor_f_2);
  allocp[32] = a4;
  allocp[33] = a6;
  x5 = makefunctor(&allocp[31]);
  a0 = x5;
  a1 = makecons(cons_const_2);
  a2 = a14;
  a3 = a12;
  qp = (struct goalrec*)&allocp[22];
  allocp += 34;
  execute(create__goal__wait_4_clear_reason);
  goto create__goal__wait_4_ext_interrupt;
  };
  goto builtin__type__unify_15_9;
 case VARREF:
  deref_and_jump(a3,builtin__type__unify_15_8);
  *reasonp++ =  a3;
  goto builtin__type__unify_15_9;
  };
  goto builtin__type__unify_15_9;
 case VARREF:
  deref_and_jump(a6,builtin__type__unify_15_7);
  *reasonp++ =  a6;
  goto builtin__type__unify_15_9;
  };
  goto builtin__type__unify_15_9;
 builtin__type__unify_15_9:
  otherwise(builtin__type__unify_15_interrupt);
  unify2(a11, a10, a9, a8);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdata_1);
  allocp[2] = makesym(atom_Value_3DValue_20not_20implemented_2E);
  allocp[3] = (q)(struct goalrec*)&allocp[0];
  allocp[4] = (q)(&predicate_print_xdata_1);
  allocp[5] = makesym(atom_Error_20in_20type__init_3Abuiltin__type__unify);
  qp = (struct goalrec*)&allocp[3];
  allocp += 6;
  proceed();
 builtin__type__unify_15_ext_interrupt:
  reasonp = 0l;
 builtin__type__unify_15_interrupt:
  goto interrupt_15;
 }

 create__goal__wait_4_top: {
  q x0, x1, x2, x3, x4;
  a3 = qp->args[3];
  qp = qp->next;
 create__goal__wait_4_clear_reason:
  reasonp = reasons;
 create__goal__wait_4_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type__init_xcreate__goal__wait1_6);
  allocp[2] = makeint(1L);
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a0;
  allocp[5] = a1;
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = a2;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_uty_xnew__functor__init_4);
  allocp[10] = makesym(atom_wait);
  allocp[11] = x2 = makeref(&allocp[11]);
  allocp[12] = makesym(atom___);
  allocp[13] = x1;
  allocp[14] = (q)(struct goalrec*)&allocp[8];
  allocp[15] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[16] = a0;
  allocp[17] = x3 = makeref(&allocp[17]);
  allocp[18] = x0;
  allocp[19] = (q)(struct goalrec*)&allocp[14];
  allocp[20] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[21] = a3;
  allocp[22] = x4 = makeref(&allocp[22]);
  allocp[23] = x2;
  qp = (struct goalrec*)&allocp[19];
  allocp += 24;
  proceed();
 create__goal__wait_4_ext_interrupt:
  reasonp = 0l;
 create__goal__wait_4_interrupt:
  toppred = &predicate_type__init_xcreate__goal__wait_4;
  goto interrupt_4;
 }

 create__goal__wait1_6_top: {
  q x0, x1, x2, x3, x4;
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 create__goal__wait1_6_clear_reason:
  reasonp = reasons;
 create__goal__wait1_6_0:
 create__goal__wait1_6_1:
  switch (ptagof(a3)) {
 case CONS:
 create__goal__wait1_6_2:
  if (!isint(a0)) goto create__goal__wait1_6_5;
 create__goal__wait1_6_3:
  if (!isint(a1)) goto create__goal__wait1_6_4;
  gblt_less_or_eq(a0,a1,create__goal__wait1_6_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type__init_xcreate__goal__wait1_6);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  x1 = cdr_of(a3);
  allocp[5] = x1;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[10] = a0;
  allocp[11] = makeint(1L);
  allocp[12] = x0;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_type__init_xcreate__wait_4);
  allocp[15] = x3 = makeref(&allocp[15]);
  x4 = car_of(a3);
  allocp[16] = x4;
  allocp[17] = a4;
  allocp[18] = x2;
  allocp[19] = (q)(struct goalrec*)&allocp[13];
  allocp[20] = (q)(&predicate_functor__table_xarg_3);
  allocp[21] = a0;
  allocp[22] = a2;
  allocp[23] = x3;
  qp = (struct goalrec*)&allocp[19];
  allocp += 24;
  proceed();
 create__goal__wait1_6_4:
  if (!isref(a1)) goto create__goal__wait1_6_interrupt;
  deref_and_jump(a1,create__goal__wait1_6_3);
  *reasonp++ =  a1;
  goto create__goal__wait1_6_interrupt;
 create__goal__wait1_6_5:
  if (!isref(a0)) goto create__goal__wait1_6_interrupt;
  deref_and_jump(a0,create__goal__wait1_6_2);
  *reasonp++ =  a0;
  goto create__goal__wait1_6_interrupt;
 case ATOMIC:
  if (a3 != NILATOM) goto create__goal__wait1_6_interrupt;
 create__goal__wait1_6_6:
  if (!isint(a0)) goto create__goal__wait1_6_9;
 create__goal__wait1_6_7:
  if (!isint(a1)) goto create__goal__wait1_6_8;
  gblt_greater(a0,a1,create__goal__wait1_6_interrupt);
  unify(a5, a4);
  proceed();
 create__goal__wait1_6_8:
  if (!isref(a1)) goto create__goal__wait1_6_interrupt;
  deref_and_jump(a1,create__goal__wait1_6_7);
  *reasonp++ =  a1;
  goto create__goal__wait1_6_interrupt;
 create__goal__wait1_6_9:
  if (!isref(a0)) goto create__goal__wait1_6_interrupt;
  deref_and_jump(a0,create__goal__wait1_6_6);
  *reasonp++ =  a0;
  goto create__goal__wait1_6_interrupt;
 case VARREF:
  deref_and_jump(a3,create__goal__wait1_6_1);
  *reasonp++ =  a3;
  goto create__goal__wait1_6_interrupt;
  };
  goto create__goal__wait1_6_interrupt;
 create__goal__wait1_6_ext_interrupt:
  reasonp = 0l;
 create__goal__wait1_6_interrupt:
  goto interrupt_6;
 }

 create__wait_4_top: {
  q x0, x1;
  a3 = qp->args[3];
  qp = qp->next;
 create__wait_4_clear_reason:
  reasonp = reasons;
 create__wait_4_0:
 create__wait_4_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_variable_3)) goto create__wait_4_2;
  x0 = arg(a0, 0);
  bblt_add_no_check_y(x0,makeint(1L),x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = x1;
  allocp[3] = a2;
  allocp[4] = a1;
  allocp[5] = a3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  proceed();
 case VARREF:
  deref_and_jump(a0,create__wait_4_1);
  *reasonp++ =  a0;
  goto create__wait_4_2;
  };
  goto create__wait_4_2;
 create__wait_4_2:
  otherwise(create__wait_4_interrupt);
  execute(create__functor__wait_4_0);
  goto create__functor__wait_4_ext_interrupt;
 create__wait_4_ext_interrupt:
  reasonp = 0l;
 create__wait_4_interrupt:
  goto interrupt_4;
 }

 create__functor__wait_4_top: {
  q x0, x1, x2, x3;
  a3 = qp->args[3];
  qp = qp->next;
 create__functor__wait_4_clear_reason:
  reasonp = reasons;
 create__functor__wait_4_0:
 create__functor__wait_4_1:
  if (isref(a0)) goto create__functor__wait_4_2;
  gblt_pfunctor(a0,x0,create__functor__wait_4_interrupt);
  gblt_arity(a0,x1,create__functor__wait_4_interrupt);
  x2 = a0;
  x3 = a2;
  a4 = a3;
  a3 = x3;
  a2 = x2;
  a0 = x1;
  execute(create__functor__wait_5_0);
  goto create__functor__wait_5_ext_interrupt;
 create__functor__wait_4_2:
  deref_and_jump(a0,create__functor__wait_4_1);
  *reasonp++ =  a0;
  goto create__functor__wait_4_interrupt;
 create__functor__wait_4_ext_interrupt:
  reasonp = 0l;
 create__functor__wait_4_interrupt:
  toppred = &predicate_type__init_xcreate__functor__wait_4;
  goto interrupt_4;
 }

 create__functor__wait_5_top: {
  q x0, x1, x2, x3;
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 create__functor__wait_5_clear_reason:
  reasonp = reasons;
 create__functor__wait_5_0:
 create__functor__wait_5_1:
  if (!isint(a0)) goto create__functor__wait_5_4;
  gblt_greater(a0,makeint(0L),create__functor__wait_5_5);
 create__functor__wait_5_2:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_d_1)) goto create__functor__wait_5_5;
  x0 = arg(a1, 0);
 create__functor__wait_5_3:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_n)) goto create__functor__wait_5_5;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type__init_xcreate__functor__wait_5);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[9] = a0;
  allocp[10] = makeint(1L);
  allocp[11] = x1;
  allocp[12] = (q)(struct goalrec*)&allocp[7];
  allocp[13] = (q)(&predicate_type__init_xcreate__wait_4);
  allocp[14] = x3 = makeref(&allocp[14]);
  allocp[15] = a1;
  allocp[16] = a3;
  allocp[17] = x2;
  allocp[18] = (q)(struct goalrec*)&allocp[12];
  allocp[19] = (q)(&predicate_functor__table_xarg_3);
  allocp[20] = a0;
  allocp[21] = a2;
  allocp[22] = x3;
  qp = (struct goalrec*)&allocp[18];
  allocp += 23;
  proceed();
 case VARREF:
  deref_and_jump(x0,create__functor__wait_5_3);
  *reasonp++ =  x0;
  goto create__functor__wait_5_5;
  };
  goto create__functor__wait_5_5;
 case VARREF:
  deref_and_jump(a1,create__functor__wait_5_2);
  *reasonp++ =  a1;
  goto create__functor__wait_5_5;
  };
  goto create__functor__wait_5_5;
 create__functor__wait_5_4:
  if (!isref(a0)) goto create__functor__wait_5_5;
  deref_and_jump(a0,create__functor__wait_5_1);
  *reasonp++ =  a0;
  goto create__functor__wait_5_5;
 create__functor__wait_5_5:
  otherwise(create__functor__wait_5_interrupt);
 create__functor__wait_5_6:
  if (!isint(a0)) goto create__functor__wait_5_8;
  gblt_greater(a0,makeint(0L),create__functor__wait_5_7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type__init_xcreate__functor__wait_5);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[9] = a0;
  allocp[10] = makeint(1L);
  allocp[11] = x0;
  allocp[12] = (q)(struct goalrec*)&allocp[7];
  allocp[13] = (q)(&predicate_type__init_xcreate__wait_4);
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = makesym(atom_n);
  allocp[16] = a3;
  allocp[17] = x1;
  allocp[18] = (q)(struct goalrec*)&allocp[12];
  allocp[19] = (q)(&predicate_functor__table_xarg_3);
  allocp[20] = a0;
  allocp[21] = a2;
  allocp[22] = x2;
  qp = (struct goalrec*)&allocp[18];
  allocp += 23;
  proceed();
 create__functor__wait_5_7:
  if (a0 != makeint(0L)) goto create__functor__wait_5_interrupt;
  unify(a4, a3);
  proceed();
 create__functor__wait_5_8:
  if (!isref(a0)) goto create__functor__wait_5_interrupt;
  deref_and_jump(a0,create__functor__wait_5_6);
  *reasonp++ =  a0;
  goto create__functor__wait_5_interrupt;
 create__functor__wait_5_ext_interrupt:
  reasonp = 0l;
 create__functor__wait_5_interrupt:
  toppred = &predicate_type__init_xcreate__functor__wait_5;
  goto interrupt_5;
 }
 interrupt_17:
  allocp[18] = a16;
 interrupt_16:
  allocp[17] = a15;
 interrupt_15:
  allocp[16] = a14;
 interrupt_14:
  allocp[15] = a13;
 interrupt_13:
  allocp[14] = a12;
 interrupt_12:
  allocp[13] = a11;
 interrupt_11:
  allocp[12] = a10;
 interrupt_10:
  allocp[11] = a9;
 interrupt_9:
  allocp[10] = a8;
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_type__init);
}
