/* Compiled by KLIC compiler version 2.002 (Tue May 23 13:27:38 JST 1995) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_mode__check();
Const struct predicate predicate_mode__check_xchange__clause_2 =
   { module_mode__check, 0, 2 };
Const struct predicate predicate_mode__check_xcheck__head_2 =
   { module_mode__check, 1, 2 };
Const struct predicate predicate_mode__check_xcheck__body_2 =
   { module_mode__check, 2, 2 };
Const struct predicate predicate_mode__check_xprint__data_2 =
   { module_mode__check, 3, 2 };
Const struct predicate predicate_mode__check_xcheck__top__goal_2 =
   { module_mode__check, 4, 2 };
Const struct predicate predicate_mode__check_xcheck__args_4 =
   { module_mode__check, 5, 4 };
Const struct predicate predicate_mode__check_xcheck__arg_2 =
   { module_mode__check, 6, 2 };
extern Const struct predicate predicate_integer__arithmetics_xadd_3;
extern Const struct predicate predicate_functor__table_xfunctor_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_xsetarg_4;
extern Const struct predicate predicate_io_xoutstream_1;

module module_mode__check(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  static Const q cons_const_0[] = {
    NILATOM,
    makesym(atom_nl),
  };
  static Const unsigned char strconst_body_1[4] =
    "::";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_1 =
      declare_string_constant_8(strconst_body_1,2);
  static Const q funct_const_2[] = {
    makesym(functor_print_1),
    makefunctor(&string_const_1),
  };
  q a0, a1, a2, a3;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, change__clause_2_top);
    case_pred(1, check__head_2_top);
    case_pred(2, check__body_2_top);
    case_pred(3, print__data_2_top);
    case_pred(4, check__top__goal_2_top);
    case_pred(5, check__args_4_top);
    last_case_pred(6, check__arg_2_top);
  }

 change__clause_2_top: {
  q x0, x1, x2, x3, x4, x5;
  qp = qp->next;
 change__clause_2_clear_reason:
  reasonp = reasons;
 change__clause_2_0:
 change__clause_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 change__clause_2_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_clause_4)) goto change__clause_2_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode__check_xchange__clause_2);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = makesym(functor_clause_4);
  allocp[5] = arg(x0, 0);
  allocp[6] = arg(x0, 1);
  allocp[7] = arg(x0, 2);
  allocp[8] = x4 = makeref(&allocp[8]);
  x3 = makefunctor(&allocp[4]);
  allocp[9] = x2;
  allocp[10] = x3;
  x5 = makecons(&allocp[9]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 11;
  unify_value(a1, x5);
  a0 = arg(x0, 3);
  a1 = x4;
  execute(check__body_2_0);
  goto check__body_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,change__clause_2_2);
  *reasonp++ =  x0;
  goto change__clause_2_interrupt;
  };
  goto change__clause_2_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto change__clause_2_interrupt;
  unify_value(a1, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a0,change__clause_2_1);
  *reasonp++ =  a0;
  goto change__clause_2_interrupt;
  };
  goto change__clause_2_interrupt;
 change__clause_2_ext_interrupt:
  reasonp = 0l;
 change__clause_2_interrupt:
  goto interrupt_2;
 }

 check__head_2_top: {
  q x0, x1, x2;
  qp = qp->next;
 check__head_2_clear_reason:
  reasonp = reasons;
 check__head_2_0:
 check__head_2_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_functor_1:
  x0 = arg(a0, 0);
 check__head_2_2:
  if (isref(x0)) goto check__head_2_3;
  gblt_pfunctor(x0,x1,check__head_2_interrupt);
  gblt_arity(x0,x2,check__head_2_interrupt);
  a0 = x0;
  a2 = x2;
  a3 = a1;
  a1 = makeint(1L);
  execute(check__args_4_0);
  goto check__args_4_ext_interrupt;
 check__head_2_3:
  deref_and_jump(x0,check__head_2_2);
  *reasonp++ =  x0;
  goto check__head_2_interrupt;
 case functor_atom_1:
  proceed();
  };
  goto check__head_2_interrupt;
 case VARREF:
  deref_and_jump(a0,check__head_2_1);
  *reasonp++ =  a0;
  goto check__head_2_interrupt;
  };
  goto check__head_2_interrupt;
 check__head_2_ext_interrupt:
  reasonp = 0l;
 check__head_2_interrupt:
  goto interrupt_2;
 }

 check__body_2_top: {
  q x0, x1, x2, x3;
  qp = qp->next;
 check__body_2_clear_reason:
  reasonp = reasons;
 check__body_2_0:
 check__body_2_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode__check_xcheck__body_2);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x1;
  allocp[5] = x3 = makeref(&allocp[5]);
  x2 = makecons(&allocp[4]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  unify_value(a1, x2);
  a0 = car_of(a0);
  a1 = x3;
  execute(check__top__goal_2_0);
  goto check__top__goal_2_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto check__body_2_interrupt;
  unify_value(a1, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a0,check__body_2_1);
  *reasonp++ =  a0;
  goto check__body_2_interrupt;
  };
  goto check__body_2_interrupt;
 check__body_2_ext_interrupt:
  reasonp = 0l;
 check__body_2_interrupt:
  toppred = &predicate_mode__check_xcheck__body_2;
  goto interrupt_2;
 }

 print__data_2_top: {
  q x0, x1, x2, x3, x4;
  qp = qp->next;
 print__data_2_clear_reason:
  reasonp = reasons;
 print__data_2_0:
  allocp[0] = makesym(functor_print_1);
  allocp[1] = a0;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_print_1);
  allocp[3] = a1;
  x1 = makefunctor(&allocp[2]);
  allocp[4] = makecons(cons_const_0);
  allocp[5] = x1;
  x2 = makecons(&allocp[4]);
  allocp[6] = x2;
  allocp[7] = makefunctor(funct_const_2);
  x3 = makecons(&allocp[6]);
  allocp[8] = x3;
  allocp[9] = x0;
  x4 = makecons(&allocp[8]);
  allocp[10] = (q)qp;
  allocp[11] = (q)(&predicate_io_xoutstream_1);
  allocp[12] = x4;
  qp = (struct goalrec*)&allocp[10];
  allocp += 13;
  proceed();
 print__data_2_ext_interrupt:
  reasonp = 0l;
 print__data_2_interrupt:
  goto interrupt_2;
 }

 check__top__goal_2_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  qp = qp->next;
 check__top__goal_2_clear_reason:
  reasonp = reasons;
 check__top__goal_2_0:
 check__top__goal_2_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_functor_1)) goto check__top__goal_2_7;
  x0 = arg(a0, 0);
 check__top__goal_2_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor__3D_2:
  allocp[0] = makesym(functor__3D_2);
  allocp[1] = x2 = makeref(&allocp[1]);
  allocp[2] = x3 = makeref(&allocp[2]);
  x1 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_functor_1);
  allocp[4] = x1;
  x4 = makefunctor(&allocp[3]);
  allocp += 5;
  unify_value(a1, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode__check_xcheck__arg_2);
  x5 = arg(x0, 1);
  allocp[2] = x5;
  allocp[3] = x3;
  a0 = arg(x0, 0);
  a1 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  execute(check__arg_2_0);
  goto check__arg_2_ext_interrupt;
 case functor__3A_2:
  x1 = arg(x0, 1);
 check__top__goal_2_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_functor_1)) goto check__top__goal_2_7;
  x2 = arg(x1, 0);
 check__top__goal_2_4:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor__40_2)) goto check__top__goal_2_7;
  x3 = arg(x0, 0);
 check__top__goal_2_5:
  switch (ptagof(x3)) {
 case FUNCTOR:
  if (functor_of(x3) != makesym(functor_atom_1)) goto check__top__goal_2_7;
  x4 = arg(x3, 0);
 check__top__goal_2_6:
  switch (ptagof(x4)) {
 case ATOMIC:
  if (x4 != makesym(atom_generic)) goto check__top__goal_2_7;
  allocp[0] = makesym(functor__3A_2);
  allocp[1] = x3;
  allocp[2] = arg(x2, 0);
  x5 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_functor_1);
  allocp[4] = x5;
  x6 = makefunctor(&allocp[3]);
  a0 = x6;
  allocp += 5;
  execute(check__top__goal_2_0);
  goto check__top__goal_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x4,check__top__goal_2_6);
  *reasonp++ =  x4;
  goto check__top__goal_2_7;
  };
  goto check__top__goal_2_7;
 case VARREF:
  deref_and_jump(x3,check__top__goal_2_5);
  *reasonp++ =  x3;
  goto check__top__goal_2_7;
  };
  goto check__top__goal_2_7;
 case VARREF:
  deref_and_jump(x2,check__top__goal_2_4);
  *reasonp++ =  x2;
  goto check__top__goal_2_7;
  };
  goto check__top__goal_2_7;
 case VARREF:
  deref_and_jump(x1,check__top__goal_2_3);
  *reasonp++ =  x1;
  goto check__top__goal_2_7;
  };
  goto check__top__goal_2_7;
  };
  goto check__top__goal_2_7;
 case VARREF:
  deref_and_jump(x0,check__top__goal_2_2);
  *reasonp++ =  x0;
  goto check__top__goal_2_7;
  };
  goto check__top__goal_2_7;
 case VARREF:
  deref_and_jump(a0,check__top__goal_2_1);
  *reasonp++ =  a0;
  goto check__top__goal_2_7;
  };
  goto check__top__goal_2_7;
 check__top__goal_2_7:
  otherwise(check__top__goal_2_interrupt);
 check__top__goal_2_8:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_functor_1)) goto check__top__goal_2_12;
  x0 = arg(a0, 0);
 check__top__goal_2_9:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__3A_2)) goto check__top__goal_2_12;
  x1 = arg(x0, 0);
 check__top__goal_2_10:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_atom_1)) goto check__top__goal_2_12;
  x2 = arg(x1, 0);
 check__top__goal_2_11:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != makesym(atom_generic)) goto check__top__goal_2_12;
  allocp[0] = makesym(functor__3A_2);
  allocp[1] = x1;
  allocp[2] = x4 = makeref(&allocp[2]);
  x3 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a1, x3);
  a0 = arg(x0, 1);
  a1 = x4;
  execute(check__top__goal_2_0);
  goto check__top__goal_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x2,check__top__goal_2_11);
  *reasonp++ =  x2;
  goto check__top__goal_2_12;
  };
  goto check__top__goal_2_12;
 case VARREF:
  deref_and_jump(x1,check__top__goal_2_10);
  *reasonp++ =  x1;
  goto check__top__goal_2_12;
  };
  goto check__top__goal_2_12;
 case VARREF:
  deref_and_jump(x0,check__top__goal_2_9);
  *reasonp++ =  x0;
  goto check__top__goal_2_12;
  };
  goto check__top__goal_2_12;
 case VARREF:
  deref_and_jump(a0,check__top__goal_2_8);
  *reasonp++ =  a0;
  goto check__top__goal_2_12;
  };
  goto check__top__goal_2_12;
 check__top__goal_2_12:
  otherwise(check__top__goal_2_interrupt);
 check__top__goal_2_13:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_functor_1)) goto check__top__goal_2_18;
  x0 = arg(a0, 0);
 check__top__goal_2_14:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__3A_2)) goto check__top__goal_2_18;
  x1 = arg(x0, 0);
 check__top__goal_2_15:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_atom_1)) goto check__top__goal_2_18;
  x2 = arg(x0, 1);
 check__top__goal_2_16:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_functor_1)) goto check__top__goal_2_18;
  x3 = arg(x2, 0);
 check__top__goal_2_17:
  switch (ptagof(x3)) {
 case FUNCTOR:
  if (functor_of(x3) != makesym(functor__40_2)) goto check__top__goal_2_18;
  allocp[0] = makesym(functor__3A_2);
  allocp[1] = x1;
  allocp[2] = x5 = makeref(&allocp[2]);
  x4 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a1, x4);
  a0 = x2;
  a1 = x5;
  execute(check__top__goal_2_0);
  goto check__top__goal_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x3,check__top__goal_2_17);
  *reasonp++ =  x3;
  goto check__top__goal_2_18;
  };
  goto check__top__goal_2_18;
 case VARREF:
  deref_and_jump(x2,check__top__goal_2_16);
  *reasonp++ =  x2;
  goto check__top__goal_2_18;
  };
  goto check__top__goal_2_18;
 case VARREF:
  deref_and_jump(x1,check__top__goal_2_15);
  *reasonp++ =  x1;
  goto check__top__goal_2_18;
  };
  goto check__top__goal_2_18;
 case VARREF:
  deref_and_jump(x0,check__top__goal_2_14);
  *reasonp++ =  x0;
  goto check__top__goal_2_18;
  };
  goto check__top__goal_2_18;
 case VARREF:
  deref_and_jump(a0,check__top__goal_2_13);
  *reasonp++ =  a0;
  goto check__top__goal_2_18;
  };
  goto check__top__goal_2_18;
 check__top__goal_2_18:
  otherwise(check__top__goal_2_interrupt);
 check__top__goal_2_19:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_functor_1)) goto check__top__goal_2_22;
  x0 = arg(a0, 0);
 check__top__goal_2_20:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor__3A_2:
  x1 = arg(x0, 0);
 check__top__goal_2_21:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_atom_1)) goto check__top__goal_2_22;
  allocp[0] = makesym(functor__3A_2);
  allocp[1] = x1;
  allocp[2] = x3 = makeref(&allocp[2]);
  x2 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_functor_1);
  allocp[4] = x2;
  x4 = makefunctor(&allocp[3]);
  allocp += 5;
  unify_value(a1, x4);
  a0 = arg(x0, 1);
  a1 = x3;
  execute(check__top__goal_2_0);
  goto check__top__goal_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,check__top__goal_2_21);
  *reasonp++ =  x1;
  goto check__top__goal_2_22;
  };
  goto check__top__goal_2_22;
 case functor__40_2:
  allocp[0] = makesym(functor__40_2);
  allocp[1] = x2 = makeref(&allocp[1]);
  allocp[2] = arg(x0, 1);
  x1 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_functor_1);
  allocp[4] = x1;
  x3 = makefunctor(&allocp[3]);
  allocp += 5;
  unify_value(a1, x3);
  a0 = arg(x0, 0);
  a1 = x2;
  execute(check__top__goal_2_0);
  goto check__top__goal_2_ext_interrupt;
  };
  goto check__top__goal_2_22;
 case VARREF:
  deref_and_jump(x0,check__top__goal_2_20);
  *reasonp++ =  x0;
  goto check__top__goal_2_22;
  };
  goto check__top__goal_2_22;
 case VARREF:
  deref_and_jump(a0,check__top__goal_2_19);
  *reasonp++ =  a0;
  goto check__top__goal_2_22;
  };
  goto check__top__goal_2_22;
 check__top__goal_2_22:
  otherwise(check__top__goal_2_interrupt);
 check__top__goal_2_23:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_functor_1)) goto check__top__goal_2_interrupt;
  allocp[0] = makesym(functor_functor_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode__check_xcheck__args_4);
  x2 = arg(a0, 0);
  allocp[2] = x2;
  allocp[3] = makeint(1L);
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = x1;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[8] = x2;
  allocp[9] = x4 = makeref(&allocp[9]);
  allocp[10] = x3;
  qp = (struct goalrec*)&allocp[6];
  allocp += 11;
  proceed();
 case VARREF:
  deref_and_jump(a0,check__top__goal_2_23);
  *reasonp++ =  a0;
  goto check__top__goal_2_interrupt;
  };
  goto check__top__goal_2_interrupt;
 check__top__goal_2_ext_interrupt:
  reasonp = 0l;
 check__top__goal_2_interrupt:
  toppred = &predicate_mode__check_xcheck__top__goal_2;
  goto interrupt_2;
 }

 check__args_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 check__args_4_clear_reason:
  reasonp = reasons;
 check__args_4_0:
 check__args_4_1:
  if (!isint(a1)) goto check__args_4_5;
 check__args_4_2:
  if (!isint(a2)) goto check__args_4_4;
  gblt_less_or_eq(a1,a2,check__args_4_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode__check_xcheck__args_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[8] = a1;
  allocp[9] = makeint(1L);
  allocp[10] = x1;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[13] = a1;
  allocp[14] = a0;
  allocp[15] = x2 = makeref(&allocp[15]);
  allocp[16] = x0;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_mode__check_xcheck__arg_2);
  allocp[19] = x3 = makeref(&allocp[19]);
  allocp[20] = x2;
  allocp[21] = (q)(struct goalrec*)&allocp[17];
  allocp[22] = (q)(&predicate_functor__table_xarg_3);
  allocp[23] = a1;
  allocp[24] = a0;
  allocp[25] = x3;
  qp = (struct goalrec*)&allocp[21];
  allocp += 26;
  proceed();
 check__args_4_3:
  gblt_greater(a1,a2,check__args_4_interrupt);
  unify(a3, a0);
  proceed();
 check__args_4_4:
  if (!isref(a2)) goto check__args_4_interrupt;
  deref_and_jump(a2,check__args_4_2);
  *reasonp++ =  a2;
  goto check__args_4_interrupt;
 check__args_4_5:
  if (!isref(a1)) goto check__args_4_interrupt;
  deref_and_jump(a1,check__args_4_1);
  *reasonp++ =  a1;
  goto check__args_4_interrupt;
 check__args_4_ext_interrupt:
  reasonp = 0l;
 check__args_4_interrupt:
  toppred = &predicate_mode__check_xcheck__args_4;
  goto interrupt_4;
 }

 check__arg_2_top: {
  q x0, x1, x2, x3, x4, x5;
  qp = qp->next;
 check__arg_2_clear_reason:
  reasonp = reasons;
 check__arg_2_0:
 check__arg_2_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_functor_1:
  x0 = arg(a0, 0);
 check__arg_2_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__3A_3A_2)) goto check__arg_2_9;
  x1 = arg(x0, 0);
 check__arg_2_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_variable_1)) goto check__arg_2_9;
  x2 = arg(x0, 1);
 check__arg_2_4:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_atom_1)) goto check__arg_2_9;
  x3 = arg(x2, 0);
 check__arg_2_5:
  switch (ptagof(x3)) {
 case ATOMIC:
  if (isint(x3)) goto check__arg_2_9;
  switch (symval(x3)) {
 case symval(makesym(atom_i)):
  allocp[0] = makesym(functor_variable_2);
  allocp[1] = arg(x1, 0);
  allocp[2] = makesym(atom_i);
  x4 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a1, x4);
  proceed();
 case symval(makesym(atom_o)):
  allocp[0] = makesym(functor_variable_2);
  allocp[1] = arg(x1, 0);
  allocp[2] = makesym(atom_o);
  x4 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a1, x4);
  proceed();
  };
  goto check__arg_2_9;
 case VARREF:
  deref_and_jump(x3,check__arg_2_5);
  *reasonp++ =  x3;
  goto check__arg_2_9;
  };
  goto check__arg_2_9;
 case VARREF:
  deref_and_jump(x2,check__arg_2_4);
  *reasonp++ =  x2;
  goto check__arg_2_9;
  };
  goto check__arg_2_9;
 case VARREF:
  deref_and_jump(x1,check__arg_2_3);
  *reasonp++ =  x1;
  goto check__arg_2_9;
  };
  goto check__arg_2_9;
 case VARREF:
  deref_and_jump(x0,check__arg_2_2);
  *reasonp++ =  x0;
  goto check__arg_2_9;
  };
  goto check__arg_2_9;
 case functor__3A_3A_2:
  x0 = arg(a0, 0);
 check__arg_2_6:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_variable_1)) goto check__arg_2_9;
  x1 = arg(a0, 1);
 check__arg_2_7:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_atom_1)) goto check__arg_2_9;
  x2 = arg(x1, 0);
 check__arg_2_8:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (isint(x2)) goto check__arg_2_9;
  switch (symval(x2)) {
 case symval(makesym(atom_i)):
  allocp[0] = makesym(functor_variable_2);
  allocp[1] = arg(x0, 0);
  allocp[2] = makesym(atom_i);
  x3 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a1, x3);
  proceed();
 case symval(makesym(atom_o)):
  allocp[0] = makesym(functor_variable_2);
  allocp[1] = arg(x0, 0);
  allocp[2] = makesym(atom_o);
  x3 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a1, x3);
  proceed();
  };
  goto check__arg_2_9;
 case VARREF:
  deref_and_jump(x2,check__arg_2_8);
  *reasonp++ =  x2;
  goto check__arg_2_9;
  };
  goto check__arg_2_9;
 case VARREF:
  deref_and_jump(x1,check__arg_2_7);
  *reasonp++ =  x1;
  goto check__arg_2_9;
  };
  goto check__arg_2_9;
 case VARREF:
  deref_and_jump(x0,check__arg_2_6);
  *reasonp++ =  x0;
  goto check__arg_2_9;
  };
  goto check__arg_2_9;
  };
  goto check__arg_2_9;
 case VARREF:
  deref_and_jump(a0,check__arg_2_1);
  *reasonp++ =  a0;
  goto check__arg_2_9;
  };
  goto check__arg_2_9;
 check__arg_2_9:
  otherwise(check__arg_2_interrupt);
 check__arg_2_10:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_functor_1)) goto check__arg_2_11;
  allocp[0] = makesym(functor_functor_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode__check_xcheck__args_4);
  x2 = arg(a0, 0);
  allocp[2] = x2;
  allocp[3] = makeint(1L);
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = x1;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[8] = x2;
  allocp[9] = x4 = makeref(&allocp[9]);
  allocp[10] = x3;
  qp = (struct goalrec*)&allocp[6];
  allocp += 11;
  proceed();
 case VARREF:
  deref_and_jump(a0,check__arg_2_10);
  *reasonp++ =  a0;
  goto check__arg_2_11;
  };
  goto check__arg_2_11;
 check__arg_2_11:
  otherwise(check__arg_2_interrupt);
 check__arg_2_12:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_list_1)) goto check__arg_2_14;
  x0 = arg(a0, 0);
 check__arg_2_13:
  switch (ptagof(x0)) {
 case CONS:
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = x3 = makeref(&allocp[1]);
  x1 = makecons(&allocp[0]);
  allocp[2] = makesym(functor_list_1);
  allocp[3] = x1;
  x4 = makefunctor(&allocp[2]);
  allocp += 4;
  unify_value(a1, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode__check_xcheck__arg_2);
  x5 = cdr_of(x0);
  allocp[2] = x5;
  allocp[3] = x2;
  a0 = car_of(x0);
  a1 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  execute(check__arg_2_0);
  goto check__arg_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,check__arg_2_13);
  *reasonp++ =  x0;
  goto check__arg_2_14;
  };
  goto check__arg_2_14;
 case VARREF:
  deref_and_jump(a0,check__arg_2_12);
  *reasonp++ =  a0;
  goto check__arg_2_14;
  };
  goto check__arg_2_14;
 check__arg_2_14:
  otherwise(check__arg_2_interrupt);
  unify(a1, a0);
  proceed();
 check__arg_2_ext_interrupt:
  reasonp = 0l;
 check__arg_2_interrupt:
  toppred = &predicate_mode__check_xcheck__arg_2;
  goto interrupt_2;
 }
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_mode__check);
}
