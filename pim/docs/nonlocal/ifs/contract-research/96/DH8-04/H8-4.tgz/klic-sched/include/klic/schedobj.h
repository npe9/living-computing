/* ----------------------------------------------------------
%        Copyright (C) 1996-1997 Kazuhiko Ohno, Masahiko Ikawa,
%        and Computer Architecture Laboratory, Depertment of
%        Information Science, Kyoto University.
%----------------------------------------------------------- */  

struct scheduling_object_method_table {
	void (*generate)();
	long (*print)();
	q *(*gc)();
	q (*encode)();
};

#ifdef INIT
extern void scheduling_g_generate();
extern long scheduling_g_print();
extern q* scheduling_g_gc();
#ifdef DIST
extern q scheduling_g_encode();
#else
extern q GD_STD_ENCODE();
#endif

struct scheduling_object_method_table scheduling_method_table
= {
	scheduling_g_generate,
	scheduling_g_print,
	scheduling_g_gc,
#ifdef DIST
	scheduling_g_encode
#else
		GD_STD_ENCODE
#endif
};
#else
extern struct scheduling_object_method_table scheduling_method_table;
#endif


