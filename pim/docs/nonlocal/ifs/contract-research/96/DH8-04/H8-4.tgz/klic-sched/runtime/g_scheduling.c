/* ----------------------------------------------------------
%        Copyright (C) 1996-1997 Kazuhiko Ohno, Masahiko Ikawa,
%        and Computer Architecture Laboratory, Depertment of
%        Information Science, Kyoto University.
%----------------------------------------------------------- */  

#include <stdio.h>

#include <klic/basic.h>
#include <klic/struct.h>
#include <klic/primitives.h>
#include <klic/unify.h>
#include <klic/index.h>
#include <klic/gb.h>
#include <klic/bb.h>
#include <klic/g_basic.h>
#include <klic/g_extern.h>
#include <klic/g_extinl.h>
#include <klic/susp.h>
#include <klic/gg_macro.h>

#ifdef DIST
#include <klic/interpe.h>
#include <klic/distio.h>
#endif

#include "atom.h"
#include "funct.h"

#include <klic/sched.h>

/*
struct scheduling_object{
	struct generator_object_method_table *method_table;
	struct threadrec* pthread;
};
*/
#define GG_CLASS_NAME() scheduling
#define GG_OBJ_TYPE struct scheduling_object

#include <klic/gc_macro.h>
#include <klic/gd_macro.h>
#include <klic/generic.h>

#include <klic/print.h>

/* For Wake up Thread */
void scheduling_g_generate(gthread)
	struct threadrec* gthread;
{
	return;
}		

Extern void *decode_exref();

#ifdef DIST
/* GGDEF_ENCODE() */
scheduling_g_encode(GG_SELF,buffer,depth)
	struct scheduling_object *GG_SELF;
	combuf *buffer;
	long depth;
{
	return;
}
#else
#endif

q* scheduling_g_gc()
{
	return;
}


/* GGDEF_PRINT()*/
long scheduling_g_print()
{
	return(1);
}


