/* ----------------------------------------------------------
%        Copyright (C) 1996-1997 Kazuhiko Ohno, Masahiko Ikawa,
%        and Computer Architecture Laboratory, Depertment of
%        Information Science, Kyoto University.
%----------------------------------------------------------- */  

#define GV_STACKSIZE 10
#define GV_STACKNUM 10
#define GSTACK_TAIL 1

#ifdef INIT
struct gstackrec gstack_tail;
#else
extern struct gstackrec gstack_tail;
#endif
