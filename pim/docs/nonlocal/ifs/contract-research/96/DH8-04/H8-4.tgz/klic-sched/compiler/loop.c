/* Compiled by KLIC compiler version 2.002 (Tue May 23 13:27:38 JST 1995) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_loop();
Const struct predicate predicate_loop_xcheck_2 =
   { module_loop, 0, 2 };
Const struct predicate predicate_loop_xcheck__loop_7 =
   { module_loop, 1, 7 };
Const struct predicate predicate_loop_xcheck__loop1_7 =
   { module_loop, 2, 7 };
Const struct predicate predicate_loop_xcheck__loop__module_7 =
   { module_loop, 3, 7 };
Const struct predicate predicate_loop_xcheck__loop__clauses_7 =
   { module_loop, 4, 7 };
Const struct predicate predicate_loop_xcheck__loop__clauses1_9 =
   { module_loop, 5, 9 };
Const struct predicate predicate_loop_xcheck__loop__bodys_6 =
   { module_loop, 6, 6 };
Const struct predicate predicate_loop_xcheck__loop__bodys1_8 =
   { module_loop, 7, 8 };
Const struct predicate predicate_loop_xcheck__loop__body_8 =
   { module_loop, 8, 8 };
Const struct predicate predicate_loop_xcheck__loop__body1_5 =
   { module_loop, 9, 5 };
Const struct predicate predicate_loop_xcheck__ancestors_5 =
   { module_loop, 10, 5 };
Const struct predicate predicate_loop_xget__goals_2 =
   { module_loop, 11, 2 };
Const struct predicate predicate_loop_xget__goals__modules_4 =
   { module_loop, 12, 4 };
Const struct predicate predicate_loop_xget__goals__clauses_6 =
   { module_loop, 13, 6 };
Const struct predicate predicate_loop_xget__goals__bodys_6 =
   { module_loop, 14, 6 };
Const struct predicate predicate_loop_xget__goals__body_7 =
   { module_loop, 15, 7 };
Const struct predicate predicate_loop_xget__goals__recursive__goal_7 =
   { module_loop, 16, 7 };
Const struct predicate predicate_loop_xget__goals__entry_6 =
   { module_loop, 17, 6 };
Const struct predicate predicate_loop_xget__goals__check__entry_5 =
   { module_loop, 18, 5 };
Const struct predicate predicate_loop_xget__goals__entry1_7 =
   { module_loop, 19, 7 };
Const struct predicate predicate_loop_xcollect__loop__clauses_4 =
   { module_loop, 20, 4 };
Const struct predicate predicate_loop_xcollect__loop__clauses__modules_9 =
   { module_loop, 21, 9 };
Const struct predicate predicate_loop_xcollect__loop__clauses__clauses_10 =
   { module_loop, 22, 10 };
Const struct predicate predicate_loop_xcollect__loop__clauses__clauses1_12 =
   { module_loop, 23, 12 };
Const struct predicate predicate_loop_xcollect__loop__clauses__entry__bodys_5 =
   { module_loop, 24, 5 };
Const struct predicate predicate_loop_xget__lf__entry_5 =
   { module_loop, 25, 5 };
Const struct predicate predicate_loop_xget__lv__entry_5 =
   { module_loop, 26, 5 };
Const struct predicate predicate_loop_xupdate__lv__entry_6 =
   { module_loop, 27, 6 };
Const struct predicate predicate_loop_xcheck__within_3 =
   { module_loop, 28, 3 };
Const struct predicate predicate_loop_xcheck__var__within_3 =
   { module_loop, 29, 3 };
Const struct predicate predicate_loop_xdeps__loop__entry_4 =
   { module_loop, 30, 4 };
Const struct predicate predicate_loop_xdeps__loop__entry__predicate_9 =
   { module_loop, 31, 9 };
Const struct predicate predicate_loop_xdeps__loop__entry__clauses_8 =
   { module_loop, 32, 8 };
Const struct predicate predicate_loop_xdeps__loop__entry__goals_11 =
   { module_loop, 33, 11 };
Const struct predicate predicate_loop_xdeps__loop__entry__goal_14 =
   { module_loop, 34, 14 };
Const struct predicate predicate_loop_xmake__loopdep_3 =
   { module_loop, 35, 3 };
Const struct predicate predicate_loop_xmake__loopdep1_4 =
   { module_loop, 36, 4 };
extern Const struct predicate predicate_list_xor__unique_3;
extern Const struct predicate predicate_integer__arithmetics_xadd_3;
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_functor__table_xfunctor_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_xsetarg_4;
extern Const struct predicate predicate_parse__uty_xupdate__clause_5;
extern Const struct predicate predicate_parse__uty_xdecode__goal_3;
extern Const struct predicate predicate_parse__uty_xencode__goal_3;
extern Const struct predicate predicate_parse__uty_xdecode__goalcall_5;
extern Const struct predicate predicate_parse__uty_xdecode__goalcall_6;
extern Const struct predicate predicate_parse__uty_xinit__cfrags_2;
extern Const struct predicate predicate_parse__uty_xread__cfrag_4;
extern Const struct predicate predicate_parse__uty_xset__cfrag_5;
extern Const struct predicate predicate_parse__uty_xget__def__clauses_5;
extern Const struct predicate predicate_dependency_xentry__deps_5;

module module_loop(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  static Const q funct_const_0[] = {
    makesym(functor_atom_1),
    makesym(atom_loop),
  };
  static Const q funct_const_1[] = {
    makesym(functor_loop_3),
    makesym(atom_main),
    makesym(atom_main),
    makeint(0),
  };
  q a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, check_2_top);
    case_pred(1, check__loop_7_top);
    case_pred(2, check__loop1_7_top);
    case_pred(3, check__loop__module_7_top);
    case_pred(4, check__loop__clauses_7_top);
    case_pred(5, check__loop__clauses1_9_top);
    case_pred(6, check__loop__bodys_6_top);
    case_pred(7, check__loop__bodys1_8_top);
    case_pred(8, check__loop__body_8_top);
    case_pred(9, check__loop__body1_5_top);
    case_pred(10, check__ancestors_5_top);
    case_pred(11, get__goals_2_top);
    case_pred(12, get__goals__modules_4_top);
    case_pred(13, get__goals__clauses_6_top);
    case_pred(14, get__goals__bodys_6_top);
    case_pred(15, get__goals__body_7_top);
    case_pred(16, get__goals__recursive__goal_7_top);
    case_pred(17, get__goals__entry_6_top);
    case_pred(18, get__goals__check__entry_5_top);
    case_pred(19, get__goals__entry1_7_top);
    case_pred(20, collect__loop__clauses_4_top);
    case_pred(21, collect__loop__clauses__modules_9_top);
    case_pred(22, collect__loop__clauses__clauses_10_top);
    case_pred(23, collect__loop__clauses__clauses1_12_top);
    case_pred(24, collect__loop__clauses__entry__bodys_5_top);
    case_pred(25, get__lf__entry_5_top);
    case_pred(26, get__lv__entry_5_top);
    case_pred(27, update__lv__entry_6_top);
    case_pred(28, check__within_3_top);
    case_pred(29, check__var__within_3_top);
    case_pred(30, deps__loop__entry_4_top);
    case_pred(31, deps__loop__entry__predicate_9_top);
    case_pred(32, deps__loop__entry__clauses_8_top);
    case_pred(33, deps__loop__entry__goals_11_top);
    case_pred(34, deps__loop__entry__goal_14_top);
    case_pred(35, make__loopdep_3_top);
    last_case_pred(36, make__loopdep1_4_top);
  }

 check_2_top: {
  q x0;
  qp = qp->next;
 check_2_clear_reason:
  reasonp = reasons;
 check_2_0:
  a2 = makeint(0L);
  a3 = NILATOM;
  a4 = a0;
  a5 = a1;
  allocp[0] = x0 = makeref(&allocp[0]);
  a6 = x0;
  a1 = makesym(atom_main);
  a0 = makesym(atom_main);
  allocp += 1;
  execute(check__loop_7_0);
  goto check__loop_7_ext_interrupt;
 check_2_ext_interrupt:
  reasonp = 0l;
 check_2_interrupt:
  goto interrupt_2;
 }

 check__loop_7_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 check__loop_7_clear_reason:
  reasonp = reasons;
 check__loop_7_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_loop_xcheck__loop1_7);
  allocp[2] = a6;
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = x0 = makeref(&allocp[9]);
  a0 = x0;
  a4 = a6;
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  execute(check__ancestors_5_0);
  goto check__ancestors_5_ext_interrupt;
 check__loop_7_ext_interrupt:
  reasonp = 0l;
 check__loop_7_interrupt:
  toppred = &predicate_loop_xcheck__loop_7;
  goto interrupt_7;
 }

 check__loop1_7_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 check__loop1_7_clear_reason:
  reasonp = reasons;
 check__loop1_7_0:
 check__loop1_7_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto check__loop1_7_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  unify(a6, a5);
  proceed();
 case symval(makesym(atom_no)):
  allocp[0] = makesym(functor_ancestor_3);
  allocp[1] = a1;
  allocp[2] = a2;
  allocp[3] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[4] = a4;
  allocp[5] = x0;
  x1 = makecons(&allocp[4]);
  a0 = a1;
  a1 = a2;
  a2 = a3;
  a3 = x1;
  a4 = a5;
  allocp += 6;
  execute(check__loop__module_7_0);
  goto check__loop__module_7_ext_interrupt;
  };
  goto check__loop1_7_interrupt;
 case VARREF:
  deref_and_jump(a0,check__loop1_7_1);
  *reasonp++ =  a0;
  goto check__loop1_7_interrupt;
  };
  goto check__loop1_7_interrupt;
 check__loop1_7_ext_interrupt:
  reasonp = 0l;
 check__loop1_7_interrupt:
  goto interrupt_7;
 }

 check__loop__module_7_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 check__loop__module_7_clear_reason:
  reasonp = reasons;
 check__loop__module_7_0:
 check__loop__module_7_1:
  switch (ptagof(a4)) {
 case CONS:
  x0 = car_of(a4);
 check__loop__module_7_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto check__loop__module_7_7;
  x1 = arg(x0, 0);
 check__loop__module_7_3:
  if (isref(x1)) goto check__loop__module_7_6;
 check__loop__module_7_4:
  if (isref(x1)) goto check__loop__module_7_5;
  if_not_equal(x1, a0, check__loop__module_7_7);
  a4 = arg(x0, 1);
  execute(check__loop__clauses_7_clear_reason);
  goto check__loop__clauses_7_ext_interrupt;
 check__loop__module_7_5:
  deref_and_jump(x1,check__loop__module_7_4);
  *reasonp++ =  x1;
  goto check__loop__module_7_7;
 check__loop__module_7_6:
  deref_and_jump(x1,check__loop__module_7_3);
  *reasonp++ =  x1;
  goto check__loop__module_7_7;
 case VARREF:
  deref_and_jump(x0,check__loop__module_7_2);
  *reasonp++ =  x0;
  goto check__loop__module_7_7;
  };
  goto check__loop__module_7_7;
 case VARREF:
  deref_and_jump(a4,check__loop__module_7_1);
  *reasonp++ =  a4;
  goto check__loop__module_7_7;
  };
  goto check__loop__module_7_7;
 check__loop__module_7_7:
  otherwise(check__loop__module_7_interrupt);
 check__loop__module_7_8:
  switch (ptagof(a4)) {
 case CONS:
  a4 = cdr_of(a4);
  execute(check__loop__module_7_0);
  goto check__loop__module_7_ext_interrupt;
 case ATOMIC:
  if (a4 != NILATOM) goto check__loop__module_7_interrupt;
  unify(a6, a5);
  proceed();
 case VARREF:
  deref_and_jump(a4,check__loop__module_7_8);
  *reasonp++ =  a4;
  goto check__loop__module_7_interrupt;
  };
  goto check__loop__module_7_interrupt;
 check__loop__module_7_ext_interrupt:
  reasonp = 0l;
 check__loop__module_7_interrupt:
  toppred = &predicate_loop_xcheck__loop__module_7;
  goto interrupt_7;
 }

 check__loop__clauses_7_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 check__loop__clauses_7_clear_reason:
  reasonp = reasons;
 check__loop__clauses_7_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_loop_xcheck__loop__clauses1_9);
  allocp[2] = makeint(1L);
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a0;
  allocp[5] = a1;
  allocp[6] = a2;
  allocp[7] = a3;
  allocp[8] = a4;
  allocp[9] = a5;
  allocp[10] = a6;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[13] = a4;
  allocp[14] = x1 = makeref(&allocp[14]);
  allocp[15] = x0;
  qp = (struct goalrec*)&allocp[11];
  allocp += 16;
  proceed();
 check__loop__clauses_7_ext_interrupt:
  reasonp = 0l;
 check__loop__clauses_7_interrupt:
  toppred = &predicate_loop_xcheck__loop__clauses_7;
  goto interrupt_7;
 }

 check__loop__clauses1_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 check__loop__clauses1_9_clear_reason:
  reasonp = reasons;
 check__loop__clauses1_9_0:
 check__loop__clauses1_9_1:
  if (!isint(a0)) goto check__loop__clauses1_9_18;
 check__loop__clauses1_9_2:
  if (!isint(a1)) goto check__loop__clauses1_9_17;
  gblt_less_or_eq(a0,a1,check__loop__clauses1_9_19);
 check__loop__clauses1_9_3:
  if (isref(a6)) goto check__loop__clauses1_9_16;
  gblt_arg(a0,a6,x0,check__loop__clauses1_9_19);
 check__loop__clauses1_9_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_clause_6)) goto check__loop__clauses1_9_19;
  x1 = arg(x0, 0);
 check__loop__clauses1_9_5:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_functor_1)) goto check__loop__clauses1_9_19;
  x2 = arg(x1, 0);
 check__loop__clauses1_9_6:
  if (isref(x2)) goto check__loop__clauses1_9_15;
  gblt_pfunctor(x2,x3,check__loop__clauses1_9_19);
 check__loop__clauses1_9_7:
  if (isref(x3)) goto check__loop__clauses1_9_14;
 check__loop__clauses1_9_8:
  if (isref(x3)) goto check__loop__clauses1_9_13;
  if_not_equal(x3, a3, check__loop__clauses1_9_19);
  gblt_arity(x2,x4,check__loop__clauses1_9_19);
 check__loop__clauses1_9_9:
  if (isref(x4)) goto check__loop__clauses1_9_12;
 check__loop__clauses1_9_10:
  if (isref(x4)) goto check__loop__clauses1_9_11;
  if_not_equal(x4, a4, check__loop__clauses1_9_19);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_loop_xcheck__loop__clauses1_9);
  allocp[2] = x5 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x5;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_parse__uty_xupdate__clause_5);
  allocp[18] = a2;
  allocp[19] = a0;
  allocp[20] = x7 = makeref(&allocp[20]);
  allocp[21] = x8 = makeref(&allocp[21]);
  allocp[22] = x6;
  allocp[23] = (q)(struct goalrec*)&allocp[16];
  allocp[24] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[25] = makeint(3L);
  allocp[26] = x0;
  allocp[27] = x9 = makeref(&allocp[27]);
  allocp[28] = x7;
  a0 = a2;
  a1 = arg(x0, 2);
  a2 = x9;
  a3 = a5;
  a4 = a7;
  a5 = x8;
  qp = (struct goalrec*)&allocp[23];
  allocp += 29;
  execute(check__loop__bodys_6_clear_reason);
  goto check__loop__bodys_6_ext_interrupt;
 check__loop__clauses1_9_11:
  deref_and_jump(x4,check__loop__clauses1_9_10);
  *reasonp++ =  x4;
  goto check__loop__clauses1_9_19;
 check__loop__clauses1_9_12:
  deref_and_jump(x4,check__loop__clauses1_9_9);
  *reasonp++ =  x4;
  goto check__loop__clauses1_9_19;
 check__loop__clauses1_9_13:
  deref_and_jump(x3,check__loop__clauses1_9_8);
  *reasonp++ =  x3;
  goto check__loop__clauses1_9_19;
 check__loop__clauses1_9_14:
  deref_and_jump(x3,check__loop__clauses1_9_7);
  *reasonp++ =  x3;
  goto check__loop__clauses1_9_19;
 check__loop__clauses1_9_15:
  deref_and_jump(x2,check__loop__clauses1_9_6);
  *reasonp++ =  x2;
  goto check__loop__clauses1_9_19;
 case VARREF:
  deref_and_jump(x1,check__loop__clauses1_9_5);
  *reasonp++ =  x1;
  goto check__loop__clauses1_9_19;
  };
  goto check__loop__clauses1_9_19;
 case VARREF:
  deref_and_jump(x0,check__loop__clauses1_9_4);
  *reasonp++ =  x0;
  goto check__loop__clauses1_9_19;
  };
  goto check__loop__clauses1_9_19;
 check__loop__clauses1_9_16:
  deref_and_jump(a6,check__loop__clauses1_9_3);
  *reasonp++ =  a6;
  goto check__loop__clauses1_9_19;
 check__loop__clauses1_9_17:
  if (!isref(a1)) goto check__loop__clauses1_9_19;
  deref_and_jump(a1,check__loop__clauses1_9_2);
  *reasonp++ =  a1;
  goto check__loop__clauses1_9_19;
 check__loop__clauses1_9_18:
  if (!isref(a0)) goto check__loop__clauses1_9_19;
  deref_and_jump(a0,check__loop__clauses1_9_1);
  *reasonp++ =  a0;
  goto check__loop__clauses1_9_19;
 check__loop__clauses1_9_19:
  otherwise(check__loop__clauses1_9_interrupt);
 check__loop__clauses1_9_20:
  if (!isint(a0)) goto check__loop__clauses1_9_24;
 check__loop__clauses1_9_21:
  if (!isint(a1)) goto check__loop__clauses1_9_23;
  gblt_less_or_eq(a0,a1,check__loop__clauses1_9_22);
  bblt_add_no_check(a0,makeint(1L),x0);
  a0 = x0;
  execute(check__loop__clauses1_9_0);
  goto check__loop__clauses1_9_ext_interrupt;
 check__loop__clauses1_9_22:
  gblt_greater(a0,a1,check__loop__clauses1_9_interrupt);
  unify(a8, a7);
  proceed();
 check__loop__clauses1_9_23:
  if (!isref(a1)) goto check__loop__clauses1_9_interrupt;
  deref_and_jump(a1,check__loop__clauses1_9_21);
  *reasonp++ =  a1;
  goto check__loop__clauses1_9_interrupt;
 check__loop__clauses1_9_24:
  if (!isref(a0)) goto check__loop__clauses1_9_interrupt;
  deref_and_jump(a0,check__loop__clauses1_9_20);
  *reasonp++ =  a0;
  goto check__loop__clauses1_9_interrupt;
 check__loop__clauses1_9_ext_interrupt:
  reasonp = 0l;
 check__loop__clauses1_9_interrupt:
  goto interrupt_9;
 }

 check__loop__bodys_6_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 check__loop__bodys_6_clear_reason:
  reasonp = reasons;
 check__loop__bodys_6_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_loop_xcheck__loop__bodys1_8);
  allocp[2] = makeint(1L);
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a0;
  allocp[5] = a1;
  allocp[6] = a2;
  allocp[7] = a3;
  allocp[8] = a4;
  allocp[9] = a5;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[12] = a1;
  allocp[13] = x1 = makeref(&allocp[13]);
  allocp[14] = x0;
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 check__loop__bodys_6_ext_interrupt:
  reasonp = 0l;
 check__loop__bodys_6_interrupt:
  toppred = &predicate_loop_xcheck__loop__bodys_6;
  goto interrupt_6;
 }

 check__loop__bodys1_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 check__loop__bodys1_8_clear_reason:
  reasonp = reasons;
 check__loop__bodys1_8_0:
 check__loop__bodys1_8_1:
  if (!isint(a0)) goto check__loop__bodys1_8_5;
 check__loop__bodys1_8_2:
  if (!isint(a1)) goto check__loop__bodys1_8_4;
  gblt_less_or_eq(a0,a1,check__loop__bodys1_8_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_loop_xcheck__loop__bodys1_8);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[12] = a0;
  allocp[13] = makeint(1L);
  allocp[14] = x0;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[17] = a0;
  allocp[18] = a3;
  allocp[19] = x3 = makeref(&allocp[19]);
  allocp[20] = x1;
  allocp[21] = (q)(struct goalrec*)&allocp[15];
  allocp[22] = (q)(&predicate_loop_xcheck__loop__body_8);
  allocp[23] = a2;
  allocp[24] = x4 = makeref(&allocp[24]);
  allocp[25] = x5 = makeref(&allocp[25]);
  allocp[26] = x6 = makeref(&allocp[26]);
  allocp[27] = x3;
  allocp[28] = a5;
  allocp[29] = a6;
  allocp[30] = x2;
  allocp[31] = makesym(functor_options_2);
  allocp[32] = x4;
  allocp[33] = x5;
  x7 = makefunctor(&allocp[31]);
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_parse__uty_xdecode__goal_3);
  allocp[36] = x8 = makeref(&allocp[36]);
  allocp[37] = x6;
  allocp[38] = x7;
  allocp[39] = (q)(struct goalrec*)&allocp[34];
  allocp[40] = (q)(&predicate_functor__table_xarg_3);
  allocp[41] = a0;
  allocp[42] = a3;
  allocp[43] = x8;
  qp = (struct goalrec*)&allocp[39];
  allocp += 44;
  proceed();
 check__loop__bodys1_8_3:
  gblt_greater(a0,a1,check__loop__bodys1_8_interrupt);
  unify2(a4, a3, a7, a6);
  proceed();
 check__loop__bodys1_8_4:
  if (!isref(a1)) goto check__loop__bodys1_8_interrupt;
  deref_and_jump(a1,check__loop__bodys1_8_2);
  *reasonp++ =  a1;
  goto check__loop__bodys1_8_interrupt;
 check__loop__bodys1_8_5:
  if (!isref(a0)) goto check__loop__bodys1_8_interrupt;
  deref_and_jump(a0,check__loop__bodys1_8_1);
  *reasonp++ =  a0;
  goto check__loop__bodys1_8_interrupt;
 check__loop__bodys1_8_ext_interrupt:
  reasonp = 0l;
 check__loop__bodys1_8_interrupt:
  goto interrupt_8;
 }

 check__loop__body_8_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 check__loop__body_8_clear_reason:
  reasonp = reasons;
 check__loop__body_8_0:
 check__loop__body_8_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom___)) goto check__loop__body_8_4;
 check__loop__body_8_2:
  if (isref(a3)) goto check__loop__body_8_3;
  gblt_pfunctor(a3,x0,check__loop__body_8_4);
  gblt_arity(a3,x1,check__loop__body_8_4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_loop_xcheck__loop__body1_5);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = makesym(atom___);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  a1 = x0;
  a2 = x1;
  a3 = a5;
  a4 = a6;
  a5 = a7;
  a6 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(check__loop_7_0);
  goto check__loop_7_ext_interrupt;
 check__loop__body_8_3:
  deref_and_jump(a3,check__loop__body_8_2);
  *reasonp++ =  a3;
  goto check__loop__body_8_4;
 case VARREF:
  deref_and_jump(a1,check__loop__body_8_1);
  *reasonp++ =  a1;
  goto check__loop__body_8_4;
  };
  goto check__loop__body_8_4;
 check__loop__body_8_4:
  otherwise(check__loop__body_8_interrupt);
 check__loop__body_8_5:
  if (isref(a3)) goto check__loop__body_8_6;
  gblt_pfunctor(a3,x0,check__loop__body_8_interrupt);
  gblt_arity(a3,x1,check__loop__body_8_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_loop_xcheck__loop__body1_5);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  a0 = a1;
  a1 = x0;
  a2 = x1;
  a3 = a5;
  a4 = a6;
  a5 = a7;
  a6 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(check__loop_7_0);
  goto check__loop_7_ext_interrupt;
 check__loop__body_8_6:
  deref_and_jump(a3,check__loop__body_8_5);
  *reasonp++ =  a3;
  goto check__loop__body_8_interrupt;
 check__loop__body_8_ext_interrupt:
  reasonp = 0l;
 check__loop__body_8_interrupt:
  goto interrupt_8;
 }

 check__loop__body1_5_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 check__loop__body1_5_clear_reason:
  reasonp = reasons;
 check__loop__body1_5_0:
 check__loop__body1_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto check__loop__body1_5_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
 check__loop__body1_5_2:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom___)) goto check__loop__body1_5_interrupt;
  allocp[0] = makesym(functor_options_2);
  allocp[1] = a1;
  allocp[2] = makefunctor(funct_const_0);
  x0 = makefunctor(&allocp[0]);
  allocp[3] = (q)qp;
  allocp[4] = (q)(&predicate_parse__uty_xencode__goal_3);
  allocp[5] = a3;
  allocp[6] = x0;
  allocp[7] = a4;
  qp = (struct goalrec*)&allocp[3];
  allocp += 8;
  proceed();
 case FUNCTOR:
  switch (symval(functor_of(a2))) {
 case functor_atom_1:
  x0 = arg(a2, 0);
 check__loop__body1_5_3:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_loop)) goto check__loop__body1_5_interrupt;
  allocp[0] = makesym(functor_options_2);
  allocp[1] = a1;
  allocp[2] = a2;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = (q)qp;
  allocp[4] = (q)(&predicate_parse__uty_xencode__goal_3);
  allocp[5] = a3;
  allocp[6] = x1;
  allocp[7] = a4;
  qp = (struct goalrec*)&allocp[3];
  allocp += 8;
  proceed();
 case VARREF:
  deref_and_jump(x0,check__loop__body1_5_3);
  *reasonp++ =  x0;
  goto check__loop__body1_5_interrupt;
  };
  goto check__loop__body1_5_interrupt;
 case functor_functor_1:
  x0 = arg(a2, 0);
 check__loop__body1_5_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_node_1)) goto check__loop__body1_5_interrupt;
  allocp[0] = makesym(functor_options_2);
  allocp[1] = a1;
  allocp[2] = a2;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = (q)qp;
  allocp[4] = (q)(&predicate_parse__uty_xencode__goal_3);
  allocp[5] = a3;
  allocp[6] = x1;
  allocp[7] = a4;
  qp = (struct goalrec*)&allocp[3];
  allocp += 8;
  proceed();
 case VARREF:
  deref_and_jump(x0,check__loop__body1_5_4);
  *reasonp++ =  x0;
  goto check__loop__body1_5_interrupt;
  };
  goto check__loop__body1_5_interrupt;
  };
  goto check__loop__body1_5_interrupt;
 case VARREF:
  deref_and_jump(a2,check__loop__body1_5_2);
  *reasonp++ =  a2;
  goto check__loop__body1_5_interrupt;
  };
  goto check__loop__body1_5_interrupt;
 case symval(makesym(atom_no)):
  allocp[0] = makesym(functor_options_2);
  allocp[1] = a1;
  allocp[2] = a2;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = (q)qp;
  allocp[4] = (q)(&predicate_parse__uty_xencode__goal_3);
  allocp[5] = a3;
  allocp[6] = x0;
  allocp[7] = a4;
  qp = (struct goalrec*)&allocp[3];
  allocp += 8;
  proceed();
  };
  goto check__loop__body1_5_interrupt;
 case VARREF:
  deref_and_jump(a0,check__loop__body1_5_1);
  *reasonp++ =  a0;
  goto check__loop__body1_5_interrupt;
  };
  goto check__loop__body1_5_interrupt;
 check__loop__body1_5_ext_interrupt:
  reasonp = 0l;
 check__loop__body1_5_interrupt:
  goto interrupt_5;
 }

 check__ancestors_5_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 check__ancestors_5_clear_reason:
  reasonp = reasons;
 check__ancestors_5_0:
 check__ancestors_5_1:
  switch (ptagof(a3)) {
 case CONS:
  x0 = car_of(a3);
 check__ancestors_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_ancestor_3)) goto check__ancestors_5_11;
  x1 = arg(x0, 1);
 check__ancestors_5_3:
  if (isref(x1)) goto check__ancestors_5_10;
 check__ancestors_5_4:
  if (isref(x1)) goto check__ancestors_5_9;
  if_not_equal(x1, a1, check__ancestors_5_11);
  x2 = arg(x0, 2);
 check__ancestors_5_5:
  if (isref(x2)) goto check__ancestors_5_8;
 check__ancestors_5_6:
  if (isref(x2)) goto check__ancestors_5_7;
  if_not_equal(x2, a2, check__ancestors_5_11);
  unify_value(a4, makesym(atom_yes));
  proceed();
 check__ancestors_5_7:
  deref_and_jump(x2,check__ancestors_5_6);
  *reasonp++ =  x2;
  goto check__ancestors_5_11;
 check__ancestors_5_8:
  deref_and_jump(x2,check__ancestors_5_5);
  *reasonp++ =  x2;
  goto check__ancestors_5_11;
 check__ancestors_5_9:
  deref_and_jump(x1,check__ancestors_5_4);
  *reasonp++ =  x1;
  goto check__ancestors_5_11;
 check__ancestors_5_10:
  deref_and_jump(x1,check__ancestors_5_3);
  *reasonp++ =  x1;
  goto check__ancestors_5_11;
 case VARREF:
  deref_and_jump(x0,check__ancestors_5_2);
  *reasonp++ =  x0;
  goto check__ancestors_5_11;
  };
  goto check__ancestors_5_11;
 case VARREF:
  deref_and_jump(a3,check__ancestors_5_1);
  *reasonp++ =  a3;
  goto check__ancestors_5_11;
  };
  goto check__ancestors_5_11;
 check__ancestors_5_11:
  otherwise(check__ancestors_5_interrupt);
 check__ancestors_5_12:
  switch (ptagof(a3)) {
 case CONS:
  a3 = cdr_of(a3);
  execute(check__ancestors_5_0);
  goto check__ancestors_5_ext_interrupt;
 case ATOMIC:
  if (a3 != NILATOM) goto check__ancestors_5_interrupt;
  unify_value(a4, makesym(atom_no));
  proceed();
 case VARREF:
  deref_and_jump(a3,check__ancestors_5_12);
  *reasonp++ =  a3;
  goto check__ancestors_5_interrupt;
  };
  goto check__ancestors_5_interrupt;
 check__ancestors_5_ext_interrupt:
  reasonp = 0l;
 check__ancestors_5_interrupt:
  toppred = &predicate_loop_xcheck__ancestors_5;
  goto interrupt_5;
 }

 get__goals_2_top: {
  q x0, x1;
  qp = qp->next;
 get__goals_2_clear_reason:
  reasonp = reasons;
 get__goals_2_0:
  x0 = a0;
  x1 = a0;
  a2 = NILATOM;
  a3 = a1;
  a1 = x1;
  a0 = x0;
  execute(get__goals__modules_4_0);
  goto get__goals__modules_4_ext_interrupt;
 get__goals_2_ext_interrupt:
  reasonp = 0l;
 get__goals_2_interrupt:
  goto interrupt_2;
 }

 get__goals__modules_4_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 get__goals__modules_4_clear_reason:
  reasonp = reasons;
 get__goals__modules_4_0:
 get__goals__modules_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 get__goals__modules_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto get__goals__modules_4_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_loop_xget__goals__modules_4);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_loop_xget__goals__clauses_6);
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = a1;
  x4 = arg(x0, 0);
  allocp[10] = x4;
  x5 = arg(x0, 1);
  allocp[11] = x5;
  allocp[12] = a2;
  allocp[13] = x2;
  allocp[14] = (q)(struct goalrec*)&allocp[6];
  allocp[15] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[16] = x5;
  allocp[17] = x6 = makeref(&allocp[17]);
  allocp[18] = x3;
  qp = (struct goalrec*)&allocp[14];
  allocp += 19;
  proceed();
 case VARREF:
  deref_and_jump(x0,get__goals__modules_4_2);
  *reasonp++ =  x0;
  goto get__goals__modules_4_interrupt;
  };
  goto get__goals__modules_4_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto get__goals__modules_4_interrupt;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,get__goals__modules_4_1);
  *reasonp++ =  a0;
  goto get__goals__modules_4_interrupt;
  };
  goto get__goals__modules_4_interrupt;
 get__goals__modules_4_ext_interrupt:
  reasonp = 0l;
 get__goals__modules_4_interrupt:
  toppred = &predicate_loop_xget__goals__modules_4;
  goto interrupt_4;
 }

 get__goals__clauses_6_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 get__goals__clauses_6_clear_reason:
  reasonp = reasons;
 get__goals__clauses_6_0:
 get__goals__clauses_6_1:
  if (!isint(a0)) goto get__goals__clauses_6_3;
  gblt_greater(a0,makeint(0L),get__goals__clauses_6_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_loop_xget__goals__clauses_6);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[10] = a0;
  allocp[11] = makeint(1L);
  allocp[12] = x0;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_loop_xget__goals__bodys_6);
  allocp[15] = x2 = makeref(&allocp[15]);
  allocp[16] = a2;
  allocp[17] = a0;
  allocp[18] = a1;
  allocp[19] = a4;
  allocp[20] = x1;
  allocp[21] = (q)(struct goalrec*)&allocp[13];
  allocp[22] = (q)(&predicate_functor__table_xarg_3);
  allocp[23] = a0;
  allocp[24] = a3;
  allocp[25] = x2;
  qp = (struct goalrec*)&allocp[21];
  allocp += 26;
  proceed();
 get__goals__clauses_6_2:
  if (a0 != makeint(0L)) goto get__goals__clauses_6_interrupt;
  unify(a5, a4);
  proceed();
 get__goals__clauses_6_3:
  if (!isref(a0)) goto get__goals__clauses_6_interrupt;
  deref_and_jump(a0,get__goals__clauses_6_1);
  *reasonp++ =  a0;
  goto get__goals__clauses_6_interrupt;
 get__goals__clauses_6_ext_interrupt:
  reasonp = 0l;
 get__goals__clauses_6_interrupt:
  goto interrupt_6;
 }

 get__goals__bodys_6_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 get__goals__bodys_6_clear_reason:
  reasonp = reasons;
 get__goals__bodys_6_0:
 get__goals__bodys_6_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_clause_6)) goto get__goals__bodys_6_2;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_loop_xget__goals__body_7);
  allocp[2] = x0 = makeref(&allocp[2]);
  x1 = arg(a0, 2);
  allocp[3] = x1;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[11] = x1;
  allocp[12] = x2 = makeref(&allocp[12]);
  allocp[13] = x0;
  qp = (struct goalrec*)&allocp[9];
  allocp += 14;
  proceed();
 case VARREF:
  deref_and_jump(a0,get__goals__bodys_6_1);
  *reasonp++ =  a0;
  goto get__goals__bodys_6_2;
  };
  goto get__goals__bodys_6_2;
 get__goals__bodys_6_2:
  otherwise(get__goals__bodys_6_interrupt);
  unify(a5, a4);
  proceed();
 get__goals__bodys_6_ext_interrupt:
  reasonp = 0l;
 get__goals__bodys_6_interrupt:
  goto interrupt_6;
 }

 get__goals__body_7_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 get__goals__body_7_clear_reason:
  reasonp = reasons;
 get__goals__body_7_0:
 get__goals__body_7_1:
  if (!isint(a0)) goto get__goals__body_7_3;
  gblt_greater(a0,makeint(0L),get__goals__body_7_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_loop_xget__goals__body_7);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[11] = a0;
  allocp[12] = makeint(1L);
  allocp[13] = x0;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_loop_xget__goals__recursive__goal_7);
  allocp[16] = x2 = makeref(&allocp[16]);
  allocp[17] = x3 = makeref(&allocp[17]);
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = a3;
  allocp[20] = a4;
  allocp[21] = a5;
  allocp[22] = x1;
  allocp[23] = (q)(struct goalrec*)&allocp[14];
  allocp[24] = (q)(&predicate_parse__uty_xdecode__goalcall_6);
  allocp[25] = a2;
  allocp[26] = x4;
  allocp[27] = x5 = makeref(&allocp[27]);
  allocp[28] = x3;
  allocp[29] = x2;
  allocp[30] = x6 = makeref(&allocp[30]);
  allocp[31] = (q)(struct goalrec*)&allocp[23];
  allocp[32] = (q)(&predicate_functor__table_xarg_3);
  allocp[33] = a0;
  allocp[34] = a1;
  allocp[35] = x5;
  qp = (struct goalrec*)&allocp[31];
  allocp += 36;
  proceed();
 get__goals__body_7_2:
  if (a0 != makeint(0L)) goto get__goals__body_7_interrupt;
  unify(a6, a5);
  proceed();
 get__goals__body_7_3:
  if (!isref(a0)) goto get__goals__body_7_interrupt;
  deref_and_jump(a0,get__goals__body_7_1);
  *reasonp++ =  a0;
  goto get__goals__body_7_interrupt;
 get__goals__body_7_ext_interrupt:
  reasonp = 0l;
 get__goals__body_7_interrupt:
  goto interrupt_7;
 }

 get__goals__recursive__goal_7_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 get__goals__recursive__goal_7_clear_reason:
  reasonp = reasons;
 get__goals__recursive__goal_7_0:
 get__goals__recursive__goal_7_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_atom_1)) goto get__goals__recursive__goal_7_3;
  x0 = arg(a0, 0);
 get__goals__recursive__goal_7_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (isint(x0)) goto get__goals__recursive__goal_7_3;
  switch (symval(x0)) {
 case symval(makesym(atom_loop)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_loop_xget__goals__entry_6);
  allocp[2] = a2;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a4;
  allocp[6] = a5;
  allocp[7] = a6;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[10] = a1;
  allocp[11] = x1;
  allocp[12] = x2;
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  proceed();
 case symval(makesym(atom_shared)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_loop_xget__goals__entry_6);
  allocp[2] = a2;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a4;
  allocp[6] = a5;
  allocp[7] = a6;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[10] = a1;
  allocp[11] = x1;
  allocp[12] = x2;
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  proceed();
  };
  goto get__goals__recursive__goal_7_3;
 case VARREF:
  deref_and_jump(x0,get__goals__recursive__goal_7_2);
  *reasonp++ =  x0;
  goto get__goals__recursive__goal_7_3;
  };
  goto get__goals__recursive__goal_7_3;
 case VARREF:
  deref_and_jump(a0,get__goals__recursive__goal_7_1);
  *reasonp++ =  a0;
  goto get__goals__recursive__goal_7_3;
  };
  goto get__goals__recursive__goal_7_3;
 get__goals__recursive__goal_7_3:
  otherwise(get__goals__recursive__goal_7_interrupt);
  unify(a6, a5);
  proceed();
 get__goals__recursive__goal_7_ext_interrupt:
  reasonp = 0l;
 get__goals__recursive__goal_7_interrupt:
  goto interrupt_7;
 }

 get__goals__entry_6_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 get__goals__entry_6_clear_reason:
  reasonp = reasons;
 get__goals__entry_6_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_loop_xget__goals__entry1_7);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  a3 = a4;
  a4 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 9;
  execute(get__goals__check__entry_5_0);
  goto get__goals__check__entry_5_ext_interrupt;
 get__goals__entry_6_ext_interrupt:
  reasonp = 0l;
 get__goals__entry_6_interrupt:
  goto interrupt_6;
 }

 get__goals__check__entry_5_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 get__goals__check__entry_5_clear_reason:
  reasonp = reasons;
 get__goals__check__entry_5_0:
 get__goals__check__entry_5_1:
  switch (ptagof(a3)) {
 case CONS:
  x0 = car_of(a3);
 get__goals__check__entry_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_loop_5)) goto get__goals__check__entry_5_15;
  x1 = arg(x0, 0);
 get__goals__check__entry_5_3:
  if (isref(x1)) goto get__goals__check__entry_5_14;
 get__goals__check__entry_5_4:
  if (isref(x1)) goto get__goals__check__entry_5_13;
  if_not_equal(x1, a0, get__goals__check__entry_5_15);
  x2 = arg(x0, 1);
 get__goals__check__entry_5_5:
  if (isref(x2)) goto get__goals__check__entry_5_12;
 get__goals__check__entry_5_6:
  if (isref(x2)) goto get__goals__check__entry_5_11;
  if_not_equal(x2, a1, get__goals__check__entry_5_15);
  x3 = arg(x0, 2);
 get__goals__check__entry_5_7:
  if (isref(x3)) goto get__goals__check__entry_5_10;
 get__goals__check__entry_5_8:
  if (isref(x3)) goto get__goals__check__entry_5_9;
  if_not_equal(x3, a2, get__goals__check__entry_5_15);
  unify_value(a4, makesym(atom_yes));
  proceed();
 get__goals__check__entry_5_9:
  deref_and_jump(x3,get__goals__check__entry_5_8);
  *reasonp++ =  x3;
  goto get__goals__check__entry_5_15;
 get__goals__check__entry_5_10:
  deref_and_jump(x3,get__goals__check__entry_5_7);
  *reasonp++ =  x3;
  goto get__goals__check__entry_5_15;
 get__goals__check__entry_5_11:
  deref_and_jump(x2,get__goals__check__entry_5_6);
  *reasonp++ =  x2;
  goto get__goals__check__entry_5_15;
 get__goals__check__entry_5_12:
  deref_and_jump(x2,get__goals__check__entry_5_5);
  *reasonp++ =  x2;
  goto get__goals__check__entry_5_15;
 get__goals__check__entry_5_13:
  deref_and_jump(x1,get__goals__check__entry_5_4);
  *reasonp++ =  x1;
  goto get__goals__check__entry_5_15;
 get__goals__check__entry_5_14:
  deref_and_jump(x1,get__goals__check__entry_5_3);
  *reasonp++ =  x1;
  goto get__goals__check__entry_5_15;
 case VARREF:
  deref_and_jump(x0,get__goals__check__entry_5_2);
  *reasonp++ =  x0;
  goto get__goals__check__entry_5_15;
  };
  goto get__goals__check__entry_5_15;
 case VARREF:
  deref_and_jump(a3,get__goals__check__entry_5_1);
  *reasonp++ =  a3;
  goto get__goals__check__entry_5_15;
  };
  goto get__goals__check__entry_5_15;
 get__goals__check__entry_5_15:
  otherwise(get__goals__check__entry_5_interrupt);
 get__goals__check__entry_5_16:
  switch (ptagof(a3)) {
 case CONS:
  a3 = cdr_of(a3);
  execute(get__goals__check__entry_5_0);
  goto get__goals__check__entry_5_ext_interrupt;
 case ATOMIC:
  if (a3 != NILATOM) goto get__goals__check__entry_5_interrupt;
  unify_value(a4, makesym(atom_no));
  proceed();
 case VARREF:
  deref_and_jump(a3,get__goals__check__entry_5_16);
  *reasonp++ =  a3;
  goto get__goals__check__entry_5_interrupt;
  };
  goto get__goals__check__entry_5_interrupt;
 get__goals__check__entry_5_ext_interrupt:
  reasonp = 0l;
 get__goals__check__entry_5_interrupt:
  toppred = &predicate_loop_xget__goals__check__entry_5;
  goto interrupt_5;
 }

 get__goals__entry1_7_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 get__goals__entry1_7_clear_reason:
  reasonp = reasons;
 get__goals__entry1_7_0:
 get__goals__entry1_7_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto get__goals__entry1_7_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  unify(a6, a5);
  proceed();
 case symval(makesym(atom_no)):
  allocp[0] = makesym(functor_loop_4);
  allocp[1] = a1;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = x1 = makeref(&allocp[4]);
  x0 = makefunctor(&allocp[0]);
  allocp[5] = a5;
  allocp[6] = x0;
  x2 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a6, x2);
  allocp[0] = makesym(functor_goal_3);
  allocp[1] = a1;
  allocp[2] = a2;
  allocp[3] = a3;
  x3 = makefunctor(&allocp[0]);
  allocp[4] = NILATOM;
  allocp[5] = x3;
  x4 = makecons(&allocp[4]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_loop_xcollect__loop__clauses_4);
  allocp[8] = x4;
  allocp[9] = a4;
  allocp[10] = x5 = makeref(&allocp[10]);
  allocp[11] = x1;
  allocp[12] = (q)(struct goalrec*)&allocp[6];
  allocp[13] = (q)(&predicate_parse__uty_xinit__cfrags_2);
  allocp[14] = a4;
  allocp[15] = x5;
  qp = (struct goalrec*)&allocp[12];
  allocp += 16;
  proceed();
  };
  goto get__goals__entry1_7_interrupt;
 case VARREF:
  deref_and_jump(a0,get__goals__entry1_7_1);
  *reasonp++ =  a0;
  goto get__goals__entry1_7_interrupt;
  };
  goto get__goals__entry1_7_interrupt;
 get__goals__entry1_7_ext_interrupt:
  reasonp = 0l;
 get__goals__entry1_7_interrupt:
  goto interrupt_7;
 }

 collect__loop__clauses_4_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 collect__loop__clauses_4_clear_reason:
  reasonp = reasons;
 collect__loop__clauses_4_0:
 collect__loop__clauses_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 collect__loop__clauses_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_goal_3)) goto collect__loop__clauses_4_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_loop_xcollect__loop__clauses_4);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  x3 = a1;
  x4 = arg(x0, 0);
  a3 = arg(x0, 1);
  a4 = arg(x0, 2);
  a5 = cdr_of(a0);
  a6 = x1;
  a7 = a2;
  a8 = x2;
  a2 = x4;
  a0 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(collect__loop__clauses__modules_9_0);
  goto collect__loop__clauses__modules_9_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,collect__loop__clauses_4_2);
  *reasonp++ =  x0;
  goto collect__loop__clauses_4_interrupt;
  };
  goto collect__loop__clauses_4_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto collect__loop__clauses_4_interrupt;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,collect__loop__clauses_4_1);
  *reasonp++ =  a0;
  goto collect__loop__clauses_4_interrupt;
  };
  goto collect__loop__clauses_4_interrupt;
 collect__loop__clauses_4_ext_interrupt:
  reasonp = 0l;
 collect__loop__clauses_4_interrupt:
  goto interrupt_4;
 }

 collect__loop__clauses__modules_9_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 collect__loop__clauses__modules_9_clear_reason:
  reasonp = reasons;
 collect__loop__clauses__modules_9_0:
 collect__loop__clauses__modules_9_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 collect__loop__clauses__modules_9_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto collect__loop__clauses__modules_9_7;
  x1 = arg(x0, 0);
 collect__loop__clauses__modules_9_3:
  if (isref(x1)) goto collect__loop__clauses__modules_9_6;
 collect__loop__clauses__modules_9_4:
  if (isref(x1)) goto collect__loop__clauses__modules_9_5;
  if_not_equal(x1, a2, collect__loop__clauses__modules_9_7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_loop_xcollect__loop__clauses__clauses_10);
  allocp[2] = x2 = makeref(&allocp[2]);
  x3 = arg(x0, 1);
  allocp[3] = x3;
  allocp[4] = a1;
  allocp[5] = x1;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = a8;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[14] = x3;
  allocp[15] = x4 = makeref(&allocp[15]);
  allocp[16] = x2;
  qp = (struct goalrec*)&allocp[12];
  allocp += 17;
  proceed();
 collect__loop__clauses__modules_9_5:
  deref_and_jump(x1,collect__loop__clauses__modules_9_4);
  *reasonp++ =  x1;
  goto collect__loop__clauses__modules_9_7;
 collect__loop__clauses__modules_9_6:
  deref_and_jump(x1,collect__loop__clauses__modules_9_3);
  *reasonp++ =  x1;
  goto collect__loop__clauses__modules_9_7;
 case VARREF:
  deref_and_jump(x0,collect__loop__clauses__modules_9_2);
  *reasonp++ =  x0;
  goto collect__loop__clauses__modules_9_7;
  };
  goto collect__loop__clauses__modules_9_7;
 case VARREF:
  deref_and_jump(a0,collect__loop__clauses__modules_9_1);
  *reasonp++ =  a0;
  goto collect__loop__clauses__modules_9_7;
  };
  goto collect__loop__clauses__modules_9_7;
 collect__loop__clauses__modules_9_7:
  otherwise(collect__loop__clauses__modules_9_interrupt);
 collect__loop__clauses__modules_9_8:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(collect__loop__clauses__modules_9_0);
  goto collect__loop__clauses__modules_9_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto collect__loop__clauses__modules_9_interrupt;
  unify2(a6, a5, a8, a7);
  proceed();
 case VARREF:
  deref_and_jump(a0,collect__loop__clauses__modules_9_8);
  *reasonp++ =  a0;
  goto collect__loop__clauses__modules_9_interrupt;
  };
  goto collect__loop__clauses__modules_9_interrupt;
 collect__loop__clauses__modules_9_ext_interrupt:
  reasonp = 0l;
 collect__loop__clauses__modules_9_interrupt:
  toppred = &predicate_loop_xcollect__loop__clauses__modules_9;
  goto interrupt_9;
 }

 collect__loop__clauses__clauses_10_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 collect__loop__clauses__clauses_10_clear_reason:
  reasonp = reasons;
 collect__loop__clauses__clauses_10_0:
 collect__loop__clauses__clauses_10_1:
  if (!isint(a0)) goto collect__loop__clauses__clauses_10_16;
  gblt_greater(a0,makeint(0L),collect__loop__clauses__clauses_10_17);
 collect__loop__clauses__clauses_10_2:
  if (isref(a1)) goto collect__loop__clauses__clauses_10_15;
  gblt_arg(a0,a1,x0,collect__loop__clauses__clauses_10_17);
 collect__loop__clauses__clauses_10_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_clause_6)) goto collect__loop__clauses__clauses_10_17;
  x1 = arg(x0, 0);
 collect__loop__clauses__clauses_10_4:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_functor_1)) goto collect__loop__clauses__clauses_10_17;
  x2 = arg(x1, 0);
 collect__loop__clauses__clauses_10_5:
  if (isref(x2)) goto collect__loop__clauses__clauses_10_14;
  gblt_pfunctor(x2,x3,collect__loop__clauses__clauses_10_17);
 collect__loop__clauses__clauses_10_6:
  if (isref(x3)) goto collect__loop__clauses__clauses_10_13;
 collect__loop__clauses__clauses_10_7:
  if (isref(x3)) goto collect__loop__clauses__clauses_10_12;
  if_not_equal(x3, a4, collect__loop__clauses__clauses_10_17);
  gblt_arity(x2,x4,collect__loop__clauses__clauses_10_17);
 collect__loop__clauses__clauses_10_8:
  if (isref(x4)) goto collect__loop__clauses__clauses_10_11;
 collect__loop__clauses__clauses_10_9:
  if (isref(x4)) goto collect__loop__clauses__clauses_10_10;
  if_not_equal(x4, a5, collect__loop__clauses__clauses_10_17);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_loop_xcollect__loop__clauses__clauses1_12);
  allocp[2] = x5 = makeref(&allocp[2]);
  x6 = arg(x0, 2);
  allocp[3] = x6;
  allocp[4] = a0;
  allocp[5] = a1;
  allocp[6] = a2;
  allocp[7] = a3;
  allocp[8] = a4;
  allocp[9] = a5;
  allocp[10] = a6;
  allocp[11] = a7;
  allocp[12] = a8;
  allocp[13] = a9;
  allocp[14] = (q)(struct goalrec*)&allocp[0];
  allocp[15] = (q)(&predicate_parse__uty_xread__cfrag_4);
  allocp[16] = a3;
  allocp[17] = a0;
  allocp[18] = x5;
  allocp[19] = a8;
  qp = (struct goalrec*)&allocp[14];
  allocp += 20;
  proceed();
 collect__loop__clauses__clauses_10_10:
  deref_and_jump(x4,collect__loop__clauses__clauses_10_9);
  *reasonp++ =  x4;
  goto collect__loop__clauses__clauses_10_17;
 collect__loop__clauses__clauses_10_11:
  deref_and_jump(x4,collect__loop__clauses__clauses_10_8);
  *reasonp++ =  x4;
  goto collect__loop__clauses__clauses_10_17;
 collect__loop__clauses__clauses_10_12:
  deref_and_jump(x3,collect__loop__clauses__clauses_10_7);
  *reasonp++ =  x3;
  goto collect__loop__clauses__clauses_10_17;
 collect__loop__clauses__clauses_10_13:
  deref_and_jump(x3,collect__loop__clauses__clauses_10_6);
  *reasonp++ =  x3;
  goto collect__loop__clauses__clauses_10_17;
 collect__loop__clauses__clauses_10_14:
  deref_and_jump(x2,collect__loop__clauses__clauses_10_5);
  *reasonp++ =  x2;
  goto collect__loop__clauses__clauses_10_17;
 case VARREF:
  deref_and_jump(x1,collect__loop__clauses__clauses_10_4);
  *reasonp++ =  x1;
  goto collect__loop__clauses__clauses_10_17;
  };
  goto collect__loop__clauses__clauses_10_17;
 case VARREF:
  deref_and_jump(x0,collect__loop__clauses__clauses_10_3);
  *reasonp++ =  x0;
  goto collect__loop__clauses__clauses_10_17;
  };
  goto collect__loop__clauses__clauses_10_17;
 collect__loop__clauses__clauses_10_15:
  deref_and_jump(a1,collect__loop__clauses__clauses_10_2);
  *reasonp++ =  a1;
  goto collect__loop__clauses__clauses_10_17;
 collect__loop__clauses__clauses_10_16:
  if (!isref(a0)) goto collect__loop__clauses__clauses_10_17;
  deref_and_jump(a0,collect__loop__clauses__clauses_10_1);
  *reasonp++ =  a0;
  goto collect__loop__clauses__clauses_10_17;
 collect__loop__clauses__clauses_10_17:
  otherwise(collect__loop__clauses__clauses_10_interrupt);
 collect__loop__clauses__clauses_10_18:
  if (!isint(a0)) goto collect__loop__clauses__clauses_10_20;
  gblt_greater(a0,makeint(0L),collect__loop__clauses__clauses_10_19);
  bblt_sub_no_check(a0,makeint(1L),x0);
  a0 = x0;
  execute(collect__loop__clauses__clauses_10_0);
  goto collect__loop__clauses__clauses_10_ext_interrupt;
 collect__loop__clauses__clauses_10_19:
  if (a0 != makeint(0L)) goto collect__loop__clauses__clauses_10_interrupt;
  unify2(a7, a6, a9, a8);
  proceed();
 collect__loop__clauses__clauses_10_20:
  if (!isref(a0)) goto collect__loop__clauses__clauses_10_interrupt;
  deref_and_jump(a0,collect__loop__clauses__clauses_10_18);
  *reasonp++ =  a0;
  goto collect__loop__clauses__clauses_10_interrupt;
 collect__loop__clauses__clauses_10_ext_interrupt:
  reasonp = 0l;
 collect__loop__clauses__clauses_10_interrupt:
  goto interrupt_10;
 }

 collect__loop__clauses__clauses1_12_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 collect__loop__clauses__clauses1_12_clear_reason:
  reasonp = reasons;
 collect__loop__clauses__clauses1_12_0:
 collect__loop__clauses__clauses1_12_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 collect__loop__clauses__clauses1_12_2:
  if (a0 != makeint(1L)) goto collect__loop__clauses__clauses1_12_3;
  unify2(a9, a8, a11, a10);
  proceed();
 case VARREF:
  deref_and_jump(a0,collect__loop__clauses__clauses1_12_1);
  *reasonp++ =  a0;
  goto collect__loop__clauses__clauses1_12_3;
  };
  goto collect__loop__clauses__clauses1_12_3;
 collect__loop__clauses__clauses1_12_3:
  otherwise(collect__loop__clauses__clauses1_12_interrupt);
 collect__loop__clauses__clauses1_12_4:
  switch (ptagof(a0)) {
 case ATOMIC:
 collect__loop__clauses__clauses1_12_5:
  if (a0 != makeint(0L)) goto collect__loop__clauses__clauses1_12_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_loop_xcollect__loop__clauses__clauses_10);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a3;
  allocp[4] = a4;
  allocp[5] = a5;
  allocp[6] = a6;
  allocp[7] = a7;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = x2 = makeref(&allocp[10]);
  allocp[11] = a11;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[14] = a2;
  allocp[15] = makeint(1L);
  allocp[16] = x0;
  allocp[17] = (q)(struct goalrec*)&allocp[12];
  allocp[18] = (q)(&predicate_loop_xcollect__loop__clauses__entry__bodys_5);
  allocp[19] = x3 = makeref(&allocp[19]);
  allocp[20] = a1;
  allocp[21] = a5;
  allocp[22] = a8;
  allocp[23] = x1;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[26] = a1;
  allocp[27] = x4 = makeref(&allocp[27]);
  allocp[28] = x3;
  allocp[29] = (q)(struct goalrec*)&allocp[24];
  allocp[30] = (q)(&predicate_parse__uty_xset__cfrag_5);
  allocp[31] = a5;
  allocp[32] = a2;
  allocp[33] = makeint(1L);
  allocp[34] = a10;
  allocp[35] = x2;
  qp = (struct goalrec*)&allocp[29];
  allocp += 36;
  proceed();
 case VARREF:
  deref_and_jump(a0,collect__loop__clauses__clauses1_12_4);
  *reasonp++ =  a0;
  goto collect__loop__clauses__clauses1_12_interrupt;
  };
  goto collect__loop__clauses__clauses1_12_interrupt;
 collect__loop__clauses__clauses1_12_ext_interrupt:
  reasonp = 0l;
 collect__loop__clauses__clauses1_12_interrupt:
  goto interrupt_12;
 }

 collect__loop__clauses__entry__bodys_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 collect__loop__clauses__entry__bodys_5_clear_reason:
  reasonp = reasons;
 collect__loop__clauses__entry__bodys_5_0:
 collect__loop__clauses__entry__bodys_5_1:
  if (!isint(a0)) goto collect__loop__clauses__entry__bodys_5_5;
  gblt_greater(a0,makeint(0L),collect__loop__clauses__entry__bodys_5_4);
 collect__loop__clauses__entry__bodys_5_2:
  if (isref(a1)) goto collect__loop__clauses__entry__bodys_5_3;
  gblt_arg(a0,a1,x0,collect__loop__clauses__entry__bodys_5_4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_loop_xcollect__loop__clauses__entry__bodys_5);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[9] = a0;
  allocp[10] = makeint(1L);
  allocp[11] = x1;
  allocp[12] = makesym(functor_goal_3);
  allocp[13] = x4 = makeref(&allocp[13]);
  allocp[14] = x5 = makeref(&allocp[14]);
  allocp[15] = x6 = makeref(&allocp[15]);
  x3 = makefunctor(&allocp[12]);
  allocp[16] = a3;
  allocp[17] = x3;
  x7 = makecons(&allocp[16]);
  qp = (struct goalrec*)&allocp[7];
  allocp += 18;
  unify_value(x2, x7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[2] = x8 = makeref(&allocp[2]);
  allocp[3] = x5;
  allocp[4] = x6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_parse__uty_xdecode__goalcall_5);
  allocp[7] = a2;
  allocp[8] = x4;
  allocp[9] = x0;
  allocp[10] = x8;
  allocp[11] = x9 = makeref(&allocp[11]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 12;
  proceed();
 collect__loop__clauses__entry__bodys_5_3:
  deref_and_jump(a1,collect__loop__clauses__entry__bodys_5_2);
  *reasonp++ =  a1;
  goto collect__loop__clauses__entry__bodys_5_4;
 collect__loop__clauses__entry__bodys_5_4:
  if (a0 != makeint(0L)) goto collect__loop__clauses__entry__bodys_5_interrupt;
  unify(a4, a3);
  proceed();
 collect__loop__clauses__entry__bodys_5_5:
  if (!isref(a0)) goto collect__loop__clauses__entry__bodys_5_interrupt;
  deref_and_jump(a0,collect__loop__clauses__entry__bodys_5_1);
  *reasonp++ =  a0;
  goto collect__loop__clauses__entry__bodys_5_interrupt;
 collect__loop__clauses__entry__bodys_5_ext_interrupt:
  reasonp = 0l;
 collect__loop__clauses__entry__bodys_5_interrupt:
  goto interrupt_5;
 }

 get__lf__entry_5_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 get__lf__entry_5_clear_reason:
  reasonp = reasons;
 get__lf__entry_5_0:
 get__lf__entry_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_main)) goto get__lf__entry_5_5;
 get__lf__entry_5_2:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_main)) goto get__lf__entry_5_5;
 get__lf__entry_5_3:
  switch (ptagof(a2)) {
 case ATOMIC:
 get__lf__entry_5_4:
  if (a2 != makeint(0L)) goto get__lf__entry_5_5;
  unify_value(a4, makesym(atom___));
  proceed();
 case VARREF:
  deref_and_jump(a2,get__lf__entry_5_3);
  *reasonp++ =  a2;
  goto get__lf__entry_5_5;
  };
  goto get__lf__entry_5_5;
 case VARREF:
  deref_and_jump(a1,get__lf__entry_5_2);
  *reasonp++ =  a1;
  goto get__lf__entry_5_5;
  };
  goto get__lf__entry_5_5;
 case VARREF:
  deref_and_jump(a0,get__lf__entry_5_1);
  *reasonp++ =  a0;
  goto get__lf__entry_5_5;
  };
  goto get__lf__entry_5_5;
 get__lf__entry_5_5:
  otherwise(get__lf__entry_5_interrupt);
 get__lf__entry_5_6:
  switch (ptagof(a3)) {
 case CONS:
  x0 = car_of(a3);
 get__lf__entry_5_7:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_loop_5)) goto get__lf__entry_5_20;
  x1 = arg(x0, 0);
 get__lf__entry_5_8:
  if (isref(x1)) goto get__lf__entry_5_19;
 get__lf__entry_5_9:
  if (isref(x1)) goto get__lf__entry_5_18;
  if_not_equal(x1, a0, get__lf__entry_5_20);
  x2 = arg(x0, 1);
 get__lf__entry_5_10:
  if (isref(x2)) goto get__lf__entry_5_17;
 get__lf__entry_5_11:
  if (isref(x2)) goto get__lf__entry_5_16;
  if_not_equal(x2, a1, get__lf__entry_5_20);
  x3 = arg(x0, 2);
 get__lf__entry_5_12:
  if (isref(x3)) goto get__lf__entry_5_15;
 get__lf__entry_5_13:
  if (isref(x3)) goto get__lf__entry_5_14;
  if_not_equal(x3, a2, get__lf__entry_5_20);
  x4 = arg(x0, 3);
  unify(a4, x4);
  proceed();
 get__lf__entry_5_14:
  deref_and_jump(x3,get__lf__entry_5_13);
  *reasonp++ =  x3;
  goto get__lf__entry_5_20;
 get__lf__entry_5_15:
  deref_and_jump(x3,get__lf__entry_5_12);
  *reasonp++ =  x3;
  goto get__lf__entry_5_20;
 get__lf__entry_5_16:
  deref_and_jump(x2,get__lf__entry_5_11);
  *reasonp++ =  x2;
  goto get__lf__entry_5_20;
 get__lf__entry_5_17:
  deref_and_jump(x2,get__lf__entry_5_10);
  *reasonp++ =  x2;
  goto get__lf__entry_5_20;
 get__lf__entry_5_18:
  deref_and_jump(x1,get__lf__entry_5_9);
  *reasonp++ =  x1;
  goto get__lf__entry_5_20;
 get__lf__entry_5_19:
  deref_and_jump(x1,get__lf__entry_5_8);
  *reasonp++ =  x1;
  goto get__lf__entry_5_20;
 case VARREF:
  deref_and_jump(x0,get__lf__entry_5_7);
  *reasonp++ =  x0;
  goto get__lf__entry_5_20;
  };
  goto get__lf__entry_5_20;
 case VARREF:
  deref_and_jump(a3,get__lf__entry_5_6);
  *reasonp++ =  a3;
  goto get__lf__entry_5_20;
  };
  goto get__lf__entry_5_20;
 get__lf__entry_5_20:
  otherwise(get__lf__entry_5_interrupt);
 get__lf__entry_5_21:
  switch (ptagof(a3)) {
 case CONS:
  a3 = cdr_of(a3);
  execute(get__lf__entry_5_0);
  goto get__lf__entry_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a3,get__lf__entry_5_21);
  *reasonp++ =  a3;
  goto get__lf__entry_5_interrupt;
  };
  goto get__lf__entry_5_interrupt;
 get__lf__entry_5_ext_interrupt:
  reasonp = 0l;
 get__lf__entry_5_interrupt:
  goto interrupt_5;
 }

 get__lv__entry_5_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 get__lv__entry_5_clear_reason:
  reasonp = reasons;
 get__lv__entry_5_0:
 get__lv__entry_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_main)) goto get__lv__entry_5_5;
 get__lv__entry_5_2:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_main)) goto get__lv__entry_5_5;
 get__lv__entry_5_3:
  switch (ptagof(a2)) {
 case ATOMIC:
 get__lv__entry_5_4:
  if (a2 != makeint(0L)) goto get__lv__entry_5_5;
  unify_value(a4, makesym(atom___));
  proceed();
 case VARREF:
  deref_and_jump(a2,get__lv__entry_5_3);
  *reasonp++ =  a2;
  goto get__lv__entry_5_5;
  };
  goto get__lv__entry_5_5;
 case VARREF:
  deref_and_jump(a1,get__lv__entry_5_2);
  *reasonp++ =  a1;
  goto get__lv__entry_5_5;
  };
  goto get__lv__entry_5_5;
 case VARREF:
  deref_and_jump(a0,get__lv__entry_5_1);
  *reasonp++ =  a0;
  goto get__lv__entry_5_5;
  };
  goto get__lv__entry_5_5;
 get__lv__entry_5_5:
  otherwise(get__lv__entry_5_interrupt);
 get__lv__entry_5_6:
  switch (ptagof(a3)) {
 case CONS:
  x0 = car_of(a3);
 get__lv__entry_5_7:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_loop_5)) goto get__lv__entry_5_20;
  x1 = arg(x0, 0);
 get__lv__entry_5_8:
  if (isref(x1)) goto get__lv__entry_5_19;
 get__lv__entry_5_9:
  if (isref(x1)) goto get__lv__entry_5_18;
  if_not_equal(x1, a0, get__lv__entry_5_20);
  x2 = arg(x0, 1);
 get__lv__entry_5_10:
  if (isref(x2)) goto get__lv__entry_5_17;
 get__lv__entry_5_11:
  if (isref(x2)) goto get__lv__entry_5_16;
  if_not_equal(x2, a1, get__lv__entry_5_20);
  x3 = arg(x0, 2);
 get__lv__entry_5_12:
  if (isref(x3)) goto get__lv__entry_5_15;
 get__lv__entry_5_13:
  if (isref(x3)) goto get__lv__entry_5_14;
  if_not_equal(x3, a2, get__lv__entry_5_20);
  x4 = arg(x0, 4);
  unify(a4, x4);
  proceed();
 get__lv__entry_5_14:
  deref_and_jump(x3,get__lv__entry_5_13);
  *reasonp++ =  x3;
  goto get__lv__entry_5_20;
 get__lv__entry_5_15:
  deref_and_jump(x3,get__lv__entry_5_12);
  *reasonp++ =  x3;
  goto get__lv__entry_5_20;
 get__lv__entry_5_16:
  deref_and_jump(x2,get__lv__entry_5_11);
  *reasonp++ =  x2;
  goto get__lv__entry_5_20;
 get__lv__entry_5_17:
  deref_and_jump(x2,get__lv__entry_5_10);
  *reasonp++ =  x2;
  goto get__lv__entry_5_20;
 get__lv__entry_5_18:
  deref_and_jump(x1,get__lv__entry_5_9);
  *reasonp++ =  x1;
  goto get__lv__entry_5_20;
 get__lv__entry_5_19:
  deref_and_jump(x1,get__lv__entry_5_8);
  *reasonp++ =  x1;
  goto get__lv__entry_5_20;
 case VARREF:
  deref_and_jump(x0,get__lv__entry_5_7);
  *reasonp++ =  x0;
  goto get__lv__entry_5_20;
  };
  goto get__lv__entry_5_20;
 case VARREF:
  deref_and_jump(a3,get__lv__entry_5_6);
  *reasonp++ =  a3;
  goto get__lv__entry_5_20;
  };
  goto get__lv__entry_5_20;
 get__lv__entry_5_20:
  otherwise(get__lv__entry_5_interrupt);
 get__lv__entry_5_21:
  switch (ptagof(a3)) {
 case CONS:
  a3 = cdr_of(a3);
  execute(get__lv__entry_5_0);
  goto get__lv__entry_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a3,get__lv__entry_5_21);
  *reasonp++ =  a3;
  goto get__lv__entry_5_interrupt;
  };
  goto get__lv__entry_5_interrupt;
 get__lv__entry_5_ext_interrupt:
  reasonp = 0l;
 get__lv__entry_5_interrupt:
  goto interrupt_5;
 }

 update__lv__entry_6_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 update__lv__entry_6_clear_reason:
  reasonp = reasons;
 update__lv__entry_6_0:
 update__lv__entry_6_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_main)) goto update__lv__entry_6_5;
 update__lv__entry_6_2:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_main)) goto update__lv__entry_6_5;
 update__lv__entry_6_3:
  switch (ptagof(a2)) {
 case ATOMIC:
 update__lv__entry_6_4:
  if (a2 != makeint(0L)) goto update__lv__entry_6_5;
  unify(a4, a3);
  proceed();
 case VARREF:
  deref_and_jump(a2,update__lv__entry_6_3);
  *reasonp++ =  a2;
  goto update__lv__entry_6_5;
  };
  goto update__lv__entry_6_5;
 case VARREF:
  deref_and_jump(a1,update__lv__entry_6_2);
  *reasonp++ =  a1;
  goto update__lv__entry_6_5;
  };
  goto update__lv__entry_6_5;
 case VARREF:
  deref_and_jump(a0,update__lv__entry_6_1);
  *reasonp++ =  a0;
  goto update__lv__entry_6_5;
  };
  goto update__lv__entry_6_5;
 update__lv__entry_6_5:
  otherwise(update__lv__entry_6_interrupt);
 update__lv__entry_6_6:
  switch (ptagof(a3)) {
 case CONS:
  x0 = car_of(a3);
 update__lv__entry_6_7:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_loop_5)) goto update__lv__entry_6_20;
  x1 = arg(x0, 0);
 update__lv__entry_6_8:
  if (isref(x1)) goto update__lv__entry_6_19;
 update__lv__entry_6_9:
  if (isref(x1)) goto update__lv__entry_6_18;
  if_not_equal(x1, a0, update__lv__entry_6_20);
  x2 = arg(x0, 1);
 update__lv__entry_6_10:
  if (isref(x2)) goto update__lv__entry_6_17;
 update__lv__entry_6_11:
  if (isref(x2)) goto update__lv__entry_6_16;
  if_not_equal(x2, a1, update__lv__entry_6_20);
  x3 = arg(x0, 2);
 update__lv__entry_6_12:
  if (isref(x3)) goto update__lv__entry_6_15;
 update__lv__entry_6_13:
  if (isref(x3)) goto update__lv__entry_6_14;
  if_not_equal(x3, a2, update__lv__entry_6_20);
  allocp[0] = cdr_of(a3);
  allocp[1] = x5 = makeref(&allocp[1]);
  x4 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a4, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = makeint(5L);
  allocp[3] = x0;
  allocp[4] = a5;
  allocp[5] = x5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  proceed();
 update__lv__entry_6_14:
  deref_and_jump(x3,update__lv__entry_6_13);
  *reasonp++ =  x3;
  goto update__lv__entry_6_20;
 update__lv__entry_6_15:
  deref_and_jump(x3,update__lv__entry_6_12);
  *reasonp++ =  x3;
  goto update__lv__entry_6_20;
 update__lv__entry_6_16:
  deref_and_jump(x2,update__lv__entry_6_11);
  *reasonp++ =  x2;
  goto update__lv__entry_6_20;
 update__lv__entry_6_17:
  deref_and_jump(x2,update__lv__entry_6_10);
  *reasonp++ =  x2;
  goto update__lv__entry_6_20;
 update__lv__entry_6_18:
  deref_and_jump(x1,update__lv__entry_6_9);
  *reasonp++ =  x1;
  goto update__lv__entry_6_20;
 update__lv__entry_6_19:
  deref_and_jump(x1,update__lv__entry_6_8);
  *reasonp++ =  x1;
  goto update__lv__entry_6_20;
 case VARREF:
  deref_and_jump(x0,update__lv__entry_6_7);
  *reasonp++ =  x0;
  goto update__lv__entry_6_20;
  };
  goto update__lv__entry_6_20;
 case VARREF:
  deref_and_jump(a3,update__lv__entry_6_6);
  *reasonp++ =  a3;
  goto update__lv__entry_6_20;
  };
  goto update__lv__entry_6_20;
 update__lv__entry_6_20:
  otherwise(update__lv__entry_6_interrupt);
 update__lv__entry_6_21:
  switch (ptagof(a3)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = car_of(a3);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a4, x0);
  a3 = cdr_of(a3);
  a4 = x1;
  execute(update__lv__entry_6_0);
  goto update__lv__entry_6_ext_interrupt;
 case VARREF:
  deref_and_jump(a3,update__lv__entry_6_21);
  *reasonp++ =  a3;
  goto update__lv__entry_6_interrupt;
  };
  goto update__lv__entry_6_interrupt;
 update__lv__entry_6_ext_interrupt:
  reasonp = 0l;
 update__lv__entry_6_interrupt:
  goto interrupt_6;
 }

 check__within_3_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  qp = qp->next;
 check__within_3_clear_reason:
  reasonp = reasons;
 check__within_3_0:
 check__within_3_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 check__within_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto check__within_3_23;
 check__within_3_3:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_goal_4)) goto check__within_3_23;
  x1 = arg(a0, 0);
 check__within_3_4:
  if (isref(x1)) goto check__within_3_22;
 check__within_3_5:
  if (isref(x1)) goto check__within_3_21;
  x2 = arg(x0, 0);
  if_not_equal(x1, x2, check__within_3_12);
  x3 = arg(a0, 1);
 check__within_3_6:
  if (!isint(x3)) goto check__within_3_11;
  x4 = arg(x0, 1);
 check__within_3_7:
  if (isref(x4)) goto check__within_3_10;
  gblt_arg(x3,x4,x5,check__within_3_12);
 check__within_3_8:
  switch (ptagof(x5)) {
 case ATOMIC:
 check__within_3_9:
  if (x5 != makeint(1L)) goto check__within_3_12;
  unify_value(a2, makesym(atom_yes));
  proceed();
 case VARREF:
  deref_and_jump(x5,check__within_3_8);
  *reasonp++ =  x5;
  goto check__within_3_12;
  };
  goto check__within_3_12;
 check__within_3_10:
  deref_and_jump(x4,check__within_3_7);
  *reasonp++ =  x4;
  goto check__within_3_12;
 check__within_3_11:
  if (!isref(x3)) goto check__within_3_12;
  deref_and_jump(x3,check__within_3_6);
  *reasonp++ =  x3;
  goto check__within_3_12;
 check__within_3_12:
 check__within_3_13:
  if (isref(x1)) goto check__within_3_20;
  if_not_equal(x1, x2, check__within_3_23);
  x3 = arg(a0, 1);
 check__within_3_14:
  if (!isint(x3)) goto check__within_3_19;
  x4 = arg(x0, 1);
 check__within_3_15:
  if (isref(x4)) goto check__within_3_18;
  gblt_arg(x3,x4,x5,check__within_3_23);
 check__within_3_16:
  switch (ptagof(x5)) {
 case ATOMIC:
 check__within_3_17:
  if (x5 != makeint(0L)) goto check__within_3_23;
  unify_value(a2, makesym(atom_no));
  proceed();
 case VARREF:
  deref_and_jump(x5,check__within_3_16);
  *reasonp++ =  x5;
  goto check__within_3_23;
  };
  goto check__within_3_23;
 check__within_3_18:
  deref_and_jump(x4,check__within_3_15);
  *reasonp++ =  x4;
  goto check__within_3_23;
 check__within_3_19:
  if (!isref(x3)) goto check__within_3_23;
  deref_and_jump(x3,check__within_3_14);
  *reasonp++ =  x3;
  goto check__within_3_23;
 check__within_3_20:
  deref_and_jump(x1,check__within_3_13);
  *reasonp++ =  x1;
  goto check__within_3_23;
 check__within_3_21:
  deref_and_jump(x1,check__within_3_5);
  *reasonp++ =  x1;
  goto check__within_3_23;
 check__within_3_22:
  deref_and_jump(x1,check__within_3_4);
  *reasonp++ =  x1;
  goto check__within_3_23;
 case VARREF:
  deref_and_jump(a0,check__within_3_3);
  *reasonp++ =  a0;
  goto check__within_3_23;
  };
  goto check__within_3_23;
 case VARREF:
  deref_and_jump(x0,check__within_3_2);
  *reasonp++ =  x0;
  goto check__within_3_23;
  };
  goto check__within_3_23;
 case ATOMIC:
  if (a1 != makesym(atom___)) goto check__within_3_23;
  unify_value(a2, makesym(atom_yes));
  proceed();
 case VARREF:
  deref_and_jump(a1,check__within_3_1);
  *reasonp++ =  a1;
  goto check__within_3_23;
  };
  goto check__within_3_23;
 check__within_3_23:
  otherwise(check__within_3_interrupt);
 check__within_3_24:
  switch (ptagof(a1)) {
 case CONS:
  a1 = cdr_of(a1);
  execute(check__within_3_0);
  goto check__within_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,check__within_3_24);
  *reasonp++ =  a1;
  goto check__within_3_interrupt;
  };
  goto check__within_3_interrupt;
 check__within_3_ext_interrupt:
  reasonp = 0l;
 check__within_3_interrupt:
  goto interrupt_3;
 }

 check__var__within_3_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  qp = qp->next;
 check__var__within_3_clear_reason:
  reasonp = reasons;
 check__var__within_3_0:
 check__var__within_3_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 check__var__within_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto check__var__within_3_23;
 check__var__within_3_3:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_v_4)) goto check__var__within_3_23;
  x1 = arg(a0, 0);
 check__var__within_3_4:
  if (isref(x1)) goto check__var__within_3_22;
 check__var__within_3_5:
  if (isref(x1)) goto check__var__within_3_21;
  x2 = arg(x0, 0);
  if_not_equal(x1, x2, check__var__within_3_12);
  x3 = arg(a0, 1);
 check__var__within_3_6:
  if (!isint(x3)) goto check__var__within_3_11;
  x4 = arg(x0, 1);
 check__var__within_3_7:
  if (isref(x4)) goto check__var__within_3_10;
  gblt_arg(x3,x4,x5,check__var__within_3_12);
 check__var__within_3_8:
  switch (ptagof(x5)) {
 case ATOMIC:
 check__var__within_3_9:
  if (x5 != makeint(1L)) goto check__var__within_3_12;
  unify_value(a2, makesym(atom_yes));
  proceed();
 case VARREF:
  deref_and_jump(x5,check__var__within_3_8);
  *reasonp++ =  x5;
  goto check__var__within_3_12;
  };
  goto check__var__within_3_12;
 check__var__within_3_10:
  deref_and_jump(x4,check__var__within_3_7);
  *reasonp++ =  x4;
  goto check__var__within_3_12;
 check__var__within_3_11:
  if (!isref(x3)) goto check__var__within_3_12;
  deref_and_jump(x3,check__var__within_3_6);
  *reasonp++ =  x3;
  goto check__var__within_3_12;
 check__var__within_3_12:
 check__var__within_3_13:
  if (isref(x1)) goto check__var__within_3_20;
  if_not_equal(x1, x2, check__var__within_3_23);
  x3 = arg(a0, 1);
 check__var__within_3_14:
  if (!isint(x3)) goto check__var__within_3_19;
  x4 = arg(x0, 1);
 check__var__within_3_15:
  if (isref(x4)) goto check__var__within_3_18;
  gblt_arg(x3,x4,x5,check__var__within_3_23);
 check__var__within_3_16:
  switch (ptagof(x5)) {
 case ATOMIC:
 check__var__within_3_17:
  if (x5 != makeint(0L)) goto check__var__within_3_23;
  unify_value(a2, makesym(atom_no));
  proceed();
 case VARREF:
  deref_and_jump(x5,check__var__within_3_16);
  *reasonp++ =  x5;
  goto check__var__within_3_23;
  };
  goto check__var__within_3_23;
 check__var__within_3_18:
  deref_and_jump(x4,check__var__within_3_15);
  *reasonp++ =  x4;
  goto check__var__within_3_23;
 check__var__within_3_19:
  if (!isref(x3)) goto check__var__within_3_23;
  deref_and_jump(x3,check__var__within_3_14);
  *reasonp++ =  x3;
  goto check__var__within_3_23;
 check__var__within_3_20:
  deref_and_jump(x1,check__var__within_3_13);
  *reasonp++ =  x1;
  goto check__var__within_3_23;
 check__var__within_3_21:
  deref_and_jump(x1,check__var__within_3_5);
  *reasonp++ =  x1;
  goto check__var__within_3_23;
 check__var__within_3_22:
  deref_and_jump(x1,check__var__within_3_4);
  *reasonp++ =  x1;
  goto check__var__within_3_23;
 case VARREF:
  deref_and_jump(a0,check__var__within_3_3);
  *reasonp++ =  a0;
  goto check__var__within_3_23;
  };
  goto check__var__within_3_23;
 case VARREF:
  deref_and_jump(x0,check__var__within_3_2);
  *reasonp++ =  x0;
  goto check__var__within_3_23;
  };
  goto check__var__within_3_23;
 case VARREF:
  deref_and_jump(a1,check__var__within_3_1);
  *reasonp++ =  a1;
  goto check__var__within_3_23;
  };
  goto check__var__within_3_23;
 check__var__within_3_23:
  otherwise(check__var__within_3_interrupt);
 check__var__within_3_24:
  switch (ptagof(a1)) {
 case CONS:
  a1 = cdr_of(a1);
  execute(check__var__within_3_0);
  goto check__var__within_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,check__var__within_3_24);
  *reasonp++ =  a1;
  goto check__var__within_3_interrupt;
  };
  goto check__var__within_3_interrupt;
 check__var__within_3_ext_interrupt:
  reasonp = 0l;
 check__var__within_3_interrupt:
  goto interrupt_3;
 }

 deps__loop__entry_4_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 deps__loop__entry_4_clear_reason:
  reasonp = reasons;
 deps__loop__entry_4_0:
  a4 = a1;
  a5 = a0;
  allocp[0] = x0 = makeref(&allocp[0]);
  a6 = x0;
  a7 = a2;
  a8 = a3;
  a3 = makefunctor(funct_const_1);
  a2 = makeint(0L);
  a1 = makesym(atom_main);
  a0 = makesym(atom_main);
  allocp += 1;
  execute(deps__loop__entry__predicate_9_0);
  goto deps__loop__entry__predicate_9_ext_interrupt;
 deps__loop__entry_4_ext_interrupt:
  reasonp = 0l;
 deps__loop__entry_4_interrupt:
  goto interrupt_4;
 }

 deps__loop__entry__predicate_9_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 deps__loop__entry__predicate_9_clear_reason:
  reasonp = reasons;
 deps__loop__entry__predicate_9_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_loop_xdeps__loop__entry__clauses_8);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a3;
  allocp[5] = a4;
  allocp[6] = a5;
  allocp[7] = a6;
  allocp[8] = a7;
  allocp[9] = a8;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_parse__uty_xget__def__clauses_5);
  allocp[12] = a0;
  allocp[13] = a1;
  allocp[14] = a2;
  allocp[15] = x0;
  allocp[16] = a5;
  qp = (struct goalrec*)&allocp[10];
  allocp += 17;
  proceed();
 deps__loop__entry__predicate_9_ext_interrupt:
  reasonp = 0l;
 deps__loop__entry__predicate_9_interrupt:
  toppred = &predicate_loop_xdeps__loop__entry__predicate_9;
  goto interrupt_9;
 }

 deps__loop__entry__clauses_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 deps__loop__entry__clauses_8_clear_reason:
  reasonp = reasons;
 deps__loop__entry__clauses_8_0:
 deps__loop__entry__clauses_8_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 deps__loop__entry__clauses_8_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_cl_2)) goto deps__loop__entry__clauses_8_interrupt;
  x1 = arg(x0, 1);
 deps__loop__entry__clauses_8_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_clause_6)) goto deps__loop__entry__clauses_8_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_loop_xdeps__loop__entry__clauses_8);
  x2 = cdr_of(a0);
  allocp[2] = x2;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_loop_xdeps__loop__entry__goals_11);
  allocp[12] = x5 = makeref(&allocp[12]);
  x6 = arg(x1, 2);
  allocp[13] = x6;
  allocp[14] = a1;
  x7 = arg(x0, 0);
  allocp[15] = x7;
  allocp[16] = makesym(atom_body);
  allocp[17] = a2;
  allocp[18] = a3;
  allocp[19] = x8 = makeref(&allocp[19]);
  allocp[20] = x3;
  allocp[21] = x9 = makeref(&allocp[21]);
  allocp[22] = x4;
  allocp[23] = (q)(struct goalrec*)&allocp[10];
  allocp[24] = (q)(&predicate_loop_xdeps__loop__entry__goals_11);
  allocp[25] = x10 = makeref(&allocp[25]);
  x11 = arg(x1, 1);
  allocp[26] = x11;
  allocp[27] = a1;
  allocp[28] = x7;
  allocp[29] = makesym(atom_guard);
  allocp[30] = a2;
  allocp[31] = a3;
  allocp[32] = a4;
  allocp[33] = x8;
  allocp[34] = a6;
  allocp[35] = x9;
  allocp[36] = (q)(struct goalrec*)&allocp[23];
  allocp[37] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[38] = x6;
  allocp[39] = x12 = makeref(&allocp[39]);
  allocp[40] = x5;
  allocp[41] = (q)(struct goalrec*)&allocp[36];
  allocp[42] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[43] = x11;
  allocp[44] = x13 = makeref(&allocp[44]);
  allocp[45] = x10;
  qp = (struct goalrec*)&allocp[41];
  allocp += 46;
  proceed();
 case VARREF:
  deref_and_jump(x1,deps__loop__entry__clauses_8_3);
  *reasonp++ =  x1;
  goto deps__loop__entry__clauses_8_interrupt;
  };
  goto deps__loop__entry__clauses_8_interrupt;
 case VARREF:
  deref_and_jump(x0,deps__loop__entry__clauses_8_2);
  *reasonp++ =  x0;
  goto deps__loop__entry__clauses_8_interrupt;
  };
  goto deps__loop__entry__clauses_8_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto deps__loop__entry__clauses_8_interrupt;
  unify2(a5, a4, a7, a6);
  proceed();
 case VARREF:
  deref_and_jump(a0,deps__loop__entry__clauses_8_1);
  *reasonp++ =  a0;
  goto deps__loop__entry__clauses_8_interrupt;
  };
  goto deps__loop__entry__clauses_8_interrupt;
 deps__loop__entry__clauses_8_ext_interrupt:
  reasonp = 0l;
 deps__loop__entry__clauses_8_interrupt:
  goto interrupt_8;
 }

 deps__loop__entry__goals_11_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 deps__loop__entry__goals_11_clear_reason:
  reasonp = reasons;
 deps__loop__entry__goals_11_0:
 deps__loop__entry__goals_11_1:
  if (!isint(a0)) goto deps__loop__entry__goals_11_3;
  gblt_greater(a0,makeint(0L),deps__loop__entry__goals_11_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_loop_xdeps__loop__entry__goals_11);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = x1 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = x2 = makeref(&allocp[11]);
  allocp[12] = a10;
  allocp[13] = (q)(struct goalrec*)&allocp[0];
  allocp[14] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[15] = a0;
  allocp[16] = makeint(1L);
  allocp[17] = x0;
  allocp[18] = (q)(struct goalrec*)&allocp[13];
  allocp[19] = (q)(&predicate_loop_xdeps__loop__entry__goal_14);
  allocp[20] = a2;
  allocp[21] = a3;
  allocp[22] = a0;
  allocp[23] = a4;
  allocp[24] = x3 = makeref(&allocp[24]);
  allocp[25] = x4 = makeref(&allocp[25]);
  allocp[26] = x5 = makeref(&allocp[26]);
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = a5;
  allocp[29] = a6;
  allocp[30] = a7;
  allocp[31] = x1;
  allocp[32] = a9;
  allocp[33] = x2;
  allocp[34] = makesym(functor_attrs_2);
  allocp[35] = x8 = makeref(&allocp[35]);
  allocp[36] = x6;
  x7 = makefunctor(&allocp[34]);
  allocp[37] = (q)(struct goalrec*)&allocp[18];
  allocp[38] = (q)(&predicate_parse__uty_xdecode__goalcall_6);
  allocp[39] = a2;
  allocp[40] = x4;
  allocp[41] = x9 = makeref(&allocp[41]);
  allocp[42] = x3;
  allocp[43] = x5;
  allocp[44] = x7;
  allocp[45] = (q)(struct goalrec*)&allocp[37];
  allocp[46] = (q)(&predicate_functor__table_xarg_3);
  allocp[47] = a0;
  allocp[48] = a1;
  allocp[49] = x9;
  qp = (struct goalrec*)&allocp[45];
  allocp += 50;
  proceed();
 deps__loop__entry__goals_11_2:
  if (a0 != makeint(0L)) goto deps__loop__entry__goals_11_interrupt;
  unify2(a8, a7, a10, a9);
  proceed();
 deps__loop__entry__goals_11_3:
  if (!isref(a0)) goto deps__loop__entry__goals_11_interrupt;
  deref_and_jump(a0,deps__loop__entry__goals_11_1);
  *reasonp++ =  a0;
  goto deps__loop__entry__goals_11_interrupt;
 deps__loop__entry__goals_11_ext_interrupt:
  reasonp = 0l;
 deps__loop__entry__goals_11_interrupt:
  goto interrupt_11;
 }

 deps__loop__entry__goal_14_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  qp = qp->next;
 deps__loop__entry__goal_14_clear_reason:
  reasonp = reasons;
 deps__loop__entry__goal_14_0:
 deps__loop__entry__goal_14_1:
  switch (ptagof(a7)) {
 case ATOMIC:
  if (a7 != makesym(atom_builtin)) goto deps__loop__entry__goal_14_2;
  unify(a11, a10);
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dependency_xentry__deps_5);
  allocp[7] = makesym(atom_loopname);
  allocp[8] = x0;
  allocp[9] = a8;
  allocp[10] = a12;
  allocp[11] = a13;
  qp = (struct goalrec*)&allocp[5];
  allocp += 12;
  proceed();
 case VARREF:
  deref_and_jump(a7,deps__loop__entry__goal_14_1);
  *reasonp++ =  a7;
  goto deps__loop__entry__goal_14_2;
  };
  goto deps__loop__entry__goal_14_2;
 deps__loop__entry__goal_14_2:
 deps__loop__entry__goal_14_3:
  switch (ptagof(a6)) {
 case FUNCTOR:
  if (functor_of(a6) != makesym(functor_atom_1)) goto deps__loop__entry__goal_14_7;
  x0 = arg(a6, 0);
 deps__loop__entry__goal_14_4:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_shared)) goto deps__loop__entry__goal_14_7;
 deps__loop__entry__goal_14_5:
  if (isref(a4)) goto deps__loop__entry__goal_14_6;
  gblt_pfunctor(a4,x1,deps__loop__entry__goal_14_7);
  gblt_arity(a4,x2,deps__loop__entry__goal_14_7);
  allocp[0] = makesym(functor_loop_3);
  allocp[1] = a5;
  allocp[2] = x1;
  allocp[3] = x2;
  x3 = makefunctor(&allocp[0]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_loop_xdeps__loop__entry__predicate_9);
  allocp[6] = a5;
  allocp[7] = x1;
  allocp[8] = x2;
  allocp[9] = x3;
  allocp[10] = a9;
  allocp[11] = a10;
  allocp[12] = a11;
  allocp[13] = x4 = makeref(&allocp[13]);
  allocp[14] = a13;
  allocp[15] = makesym(functor_goal_4);
  allocp[16] = a0;
  allocp[17] = a1;
  allocp[18] = a2;
  allocp[19] = a3;
  x5 = makefunctor(&allocp[15]);
  allocp[20] = (q)(struct goalrec*)&allocp[4];
  allocp[21] = (q)(&predicate_dependency_xentry__deps_5);
  allocp[22] = makesym(atom_loopname);
  allocp[23] = x5;
  allocp[24] = x3;
  allocp[25] = a12;
  allocp[26] = x4;
  qp = (struct goalrec*)&allocp[20];
  allocp += 27;
  proceed();
 deps__loop__entry__goal_14_6:
  deref_and_jump(a4,deps__loop__entry__goal_14_5);
  *reasonp++ =  a4;
  goto deps__loop__entry__goal_14_7;
 case VARREF:
  deref_and_jump(x0,deps__loop__entry__goal_14_4);
  *reasonp++ =  x0;
  goto deps__loop__entry__goal_14_7;
  };
  goto deps__loop__entry__goal_14_7;
 case VARREF:
  deref_and_jump(a6,deps__loop__entry__goal_14_3);
  *reasonp++ =  a6;
  goto deps__loop__entry__goal_14_7;
  };
  goto deps__loop__entry__goal_14_7;
 deps__loop__entry__goal_14_7:
  otherwise(deps__loop__entry__goal_14_interrupt);
 deps__loop__entry__goal_14_8:
  switch (ptagof(a6)) {
 case FUNCTOR:
  if (functor_of(a6) != makesym(functor_atom_1)) goto deps__loop__entry__goal_14_12;
  x0 = arg(a6, 0);
 deps__loop__entry__goal_14_9:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_loop)) goto deps__loop__entry__goal_14_12;
 deps__loop__entry__goal_14_10:
  if (isref(a4)) goto deps__loop__entry__goal_14_11;
  gblt_pfunctor(a4,x1,deps__loop__entry__goal_14_12);
  gblt_arity(a4,x2,deps__loop__entry__goal_14_12);
  allocp[0] = makesym(functor_loop_3);
  allocp[1] = a5;
  allocp[2] = x1;
  allocp[3] = x2;
  x3 = makefunctor(&allocp[0]);
  allocp += 4;
  unify(a11, a10);
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x4 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dependency_xentry__deps_5);
  allocp[7] = makesym(atom_loopname);
  allocp[8] = x4;
  allocp[9] = x3;
  allocp[10] = a12;
  allocp[11] = a13;
  qp = (struct goalrec*)&allocp[5];
  allocp += 12;
  proceed();
 deps__loop__entry__goal_14_11:
  deref_and_jump(a4,deps__loop__entry__goal_14_10);
  *reasonp++ =  a4;
  goto deps__loop__entry__goal_14_12;
 case VARREF:
  deref_and_jump(x0,deps__loop__entry__goal_14_9);
  *reasonp++ =  x0;
  goto deps__loop__entry__goal_14_12;
  };
  goto deps__loop__entry__goal_14_12;
 case VARREF:
  deref_and_jump(a6,deps__loop__entry__goal_14_8);
  *reasonp++ =  a6;
  goto deps__loop__entry__goal_14_12;
  };
  goto deps__loop__entry__goal_14_12;
 deps__loop__entry__goal_14_12:
  otherwise(deps__loop__entry__goal_14_interrupt);
 deps__loop__entry__goal_14_13:
  if (isref(a4)) goto deps__loop__entry__goal_14_14;
  gblt_pfunctor(a4,x0,deps__loop__entry__goal_14_interrupt);
  gblt_arity(a4,x1,deps__loop__entry__goal_14_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_loop_xdeps__loop__entry__predicate_9);
  allocp[2] = a5;
  allocp[3] = x0;
  allocp[4] = x1;
  allocp[5] = a8;
  allocp[6] = a9;
  allocp[7] = a10;
  allocp[8] = a11;
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a13;
  allocp[11] = makesym(functor_goal_4);
  allocp[12] = a0;
  allocp[13] = a1;
  allocp[14] = a2;
  allocp[15] = a3;
  x3 = makefunctor(&allocp[11]);
  allocp[16] = (q)(struct goalrec*)&allocp[0];
  allocp[17] = (q)(&predicate_dependency_xentry__deps_5);
  allocp[18] = makesym(atom_loopname);
  allocp[19] = x3;
  allocp[20] = a8;
  allocp[21] = a12;
  allocp[22] = x2;
  qp = (struct goalrec*)&allocp[16];
  allocp += 23;
  proceed();
 deps__loop__entry__goal_14_14:
  deref_and_jump(a4,deps__loop__entry__goal_14_13);
  *reasonp++ =  a4;
  goto deps__loop__entry__goal_14_interrupt;
 deps__loop__entry__goal_14_ext_interrupt:
  reasonp = 0l;
 deps__loop__entry__goal_14_interrupt:
  goto interrupt_14;
 }

 make__loopdep_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 make__loopdep_3_clear_reason:
  reasonp = reasons;
 make__loopdep_3_0:
  allocp[0] = makesym(functor_loopgoal_2);
  allocp[1] = a0;
  allocp[2] = x1 = makeref(&allocp[2]);
  x0 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a2, x0);
  a2 = NILATOM;
  a3 = x1;
  execute(make__loopdep1_4_0);
  goto make__loopdep1_4_ext_interrupt;
 make__loopdep_3_ext_interrupt:
  reasonp = 0l;
 make__loopdep_3_interrupt:
  goto interrupt_3;
 }

 make__loopdep1_4_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 make__loopdep1_4_clear_reason:
  reasonp = reasons;
 make__loopdep1_4_0:
 make__loopdep1_4_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 make__loopdep1_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_loopgoal_2)) goto make__loopdep1_4_7;
  x1 = arg(x0, 0);
 make__loopdep1_4_3:
  if (isref(x1)) goto make__loopdep1_4_6;
 make__loopdep1_4_4:
  if (isref(x1)) goto make__loopdep1_4_5;
  if_not_equal(x1, a0, make__loopdep1_4_7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_loop_xmake__loopdep1_4);
  allocp[2] = a0;
  x2 = cdr_of(a1);
  allocp[3] = x2;
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_list_xor__unique_3);
  allocp[8] = a2;
  x4 = arg(x0, 1);
  allocp[9] = x4;
  allocp[10] = x3;
  qp = (struct goalrec*)&allocp[6];
  allocp += 11;
  proceed();
 make__loopdep1_4_5:
  deref_and_jump(x1,make__loopdep1_4_4);
  *reasonp++ =  x1;
  goto make__loopdep1_4_7;
 make__loopdep1_4_6:
  deref_and_jump(x1,make__loopdep1_4_3);
  *reasonp++ =  x1;
  goto make__loopdep1_4_7;
 case VARREF:
  deref_and_jump(x0,make__loopdep1_4_2);
  *reasonp++ =  x0;
  goto make__loopdep1_4_7;
  };
  goto make__loopdep1_4_7;
 case VARREF:
  deref_and_jump(a1,make__loopdep1_4_1);
  *reasonp++ =  a1;
  goto make__loopdep1_4_7;
  };
  goto make__loopdep1_4_7;
 make__loopdep1_4_7:
  otherwise(make__loopdep1_4_interrupt);
 make__loopdep1_4_8:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_loop_xmake__loopdep1_4);
  allocp[2] = a0;
  x0 = cdr_of(a1);
  allocp[3] = x0;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = NILATOM;
  allocp[7] = car_of(a1);
  x2 = makecons(&allocp[6]);
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_list_xor__unique_3);
  allocp[10] = a2;
  allocp[11] = x2;
  allocp[12] = x1;
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  proceed();
 case ATOMIC:
  if (a1 != NILATOM) goto make__loopdep1_4_interrupt;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a1,make__loopdep1_4_8);
  *reasonp++ =  a1;
  goto make__loopdep1_4_interrupt;
  };
  goto make__loopdep1_4_interrupt;
 make__loopdep1_4_ext_interrupt:
  reasonp = 0l;
 make__loopdep1_4_interrupt:
  toppred = &predicate_loop_xmake__loopdep1_4;
  goto interrupt_4;
 }
 interrupt_14:
  allocp[15] = a13;
 interrupt_13:
  allocp[14] = a12;
 interrupt_12:
  allocp[13] = a11;
 interrupt_11:
  allocp[12] = a10;
 interrupt_10:
  allocp[11] = a9;
 interrupt_9:
  allocp[10] = a8;
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_loop);
}
