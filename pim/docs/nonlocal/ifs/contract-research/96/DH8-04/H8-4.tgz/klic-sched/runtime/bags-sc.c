/* Compiled by KLIC compiler version 2.002 (1997ǯ05��10�� (��) 19��58ʬ16�� JST) */
#include <klic/klichdr.h>
#include <klic/sched.h>
#include "atom.h"
#include "funct.h"

module module_sorted__bag();
Const struct predicate predicate_sorted__bag_xcreate_1 =
   { module_sorted__bag, 0, 1 };
Const struct predicate predicate_sorted__bag_xcreate_2 =
   { module_sorted__bag, 1, 2 };
Const struct predicate predicate_sorted__bag_xmain_3 =
   { module_sorted__bag, 2, 3 };
Const struct predicate predicate_sorted__bag_xmessage_3 =
   { module_sorted__bag, 3, 3 };
Const struct predicate predicate_sorted__bag_xmessage_2F3_243_4 =
   { module_sorted__bag, 4, 4 };
Const struct predicate predicate_sorted__bag_xmessage_2F3_242_4 =
   { module_sorted__bag, 5, 4 };
Const struct predicate predicate_sorted__bag_xmessage_2F3_242_2F4_240_4 =
   { module_sorted__bag, 6, 4 };
Const struct predicate predicate_sorted__bag_xmessage_2F3_241_4 =
   { module_sorted__bag, 7, 4 };
Const struct predicate predicate_sorted__bag_xmessage_2F3_241_2F4_240_4 =
   { module_sorted__bag, 8, 4 };
Const struct predicate predicate_sorted__bag_xmessage_2F3_240_4 =
   { module_sorted__bag, 9, 4 };
Const struct predicate predicate_sorted__bag_xmessage_2F3_240_2F4_240_4 =
   { module_sorted__bag, 10, 4 };
Const struct predicate predicate_sorted__bag_xflatten_2 =
   { module_sorted__bag, 11, 2 };
Const struct predicate predicate_sorted__bag_xflatten_4 =
   { module_sorted__bag, 12, 4 };
Const struct predicate predicate_sorted__bag_xappend_3 =
   { module_sorted__bag, 13, 3 };
Const struct predicate predicate_sorted__bag_xlast__elem_3 =
   { module_sorted__bag, 14, 3 };
Const struct predicate predicate_sorted__bag_xresume__check_0 =
   { module_sorted__bag, 15, 0 };
extern Const struct predicate predicate_splay__tree_xempty_3;
extern Const struct predicate predicate_splay__tree_xempty_4;
extern Const struct predicate predicate_splay__tree_xput_4;
extern Const struct predicate predicate_splay__tree_xget__all_3;
extern Const struct predicate predicate_splay__tree_xcreate_1;
extern Const struct predicate predicate_splay__tree_xcreate_2;
extern Const struct predicate predicate_splay__tree_xupdate_5;
extern Const struct predicate predicate_splay__tree_xget__max_4;
extern Const struct predicate predicate_splay__tree_xget__min_4;

module module_sorted__bag(glbl, qp, allocp, toppred, stackp)
  struct global_variables *glbl;
  struct threadrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
  register q* stackp;
{
  declare_method_table_of(vector);
  static Const vector_structure_type vector_const_0 =
      declare_vector_constant(0,0);
  q a0, a1, a2, a3;

  q *reasonp;
 module_top:
  switch_on_pred() {
    case_pred(0, create_1_top);
    case_pred(1, create_2_top);
    case_pred(2, main_3_top);
    case_pred(3, message_3_top);
    case_pred(4, message_2F3_243_4_top);
    case_pred(5, message_2F3_242_4_top);
    case_pred(6, message_2F3_242_2F4_240_4_top);
    case_pred(7, message_2F3_241_4_top);
    case_pred(8, message_2F3_241_2F4_240_4_top);
    case_pred(9, message_2F3_240_4_top);
    case_pred(10, message_2F3_240_2F4_240_4_top);
    case_pred(11, flatten_2_top);
    case_pred(12, flatten_4_top);
    case_pred(13, append_3_top);
    case_pred(14, last__elem_3_top);
    last_case_pred(15, resume__check_0_top);
  }

 create_1_top: {
  q x0;
  stackp -= 1;
  a0 = stackp[0];
 create_1_clear_reason:
  reasonp = reasons;
 create_1_0:
  check_stack(6);
  stackp[0] = a0;
  stackp[1] = NILATOM;
  stackp[2] = allocp[0] = x0 = makeref(&allocp[0]);
  stackp[3] = (q)(&predicate_sorted__bag_xmain_3);
  stackp[4] = x0;
  stackp[5] = (q)(&predicate_splay__tree_xcreate_1);
  stackp += 6;
  allocp += 1;
  proceed();
 create_1_ext_interrupt:
  reasonp = 0l;
 create_1_interrupt:
  toppred = &predicate_sorted__bag_xcreate_1;
  goto interrupt_1;
 }

 create_2_top: {
  q x0;
  stackp -= 2;
  a0 = stackp[0];
  a1 = stackp[1];
 create_2_clear_reason:
  reasonp = reasons;
 create_2_0:
  check_stack(7);
  stackp[0] = a1;
  stackp[1] = NILATOM;
  stackp[2] = allocp[0] = x0 = makeref(&allocp[0]);
  stackp[3] = (q)(&predicate_sorted__bag_xmain_3);
  stackp[4] = a0;
  stackp[5] = x0;
  stackp[6] = (q)(&predicate_splay__tree_xcreate_2);
  stackp += 7;
  allocp += 1;
  proceed();
 create_2_ext_interrupt:
  reasonp = 0l;
 create_2_interrupt:
  toppred = &predicate_sorted__bag_xcreate_2;
  goto interrupt_2;
 }

 main_3_top: {
  q x0, x1;
  stackp -= 3;
  a0 = stackp[0];
  a1 = stackp[1];
  a2 = stackp[2];
 main_3_clear_reason:
  reasonp = reasons;
 main_3_0:
 main_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 main_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_do_1)) goto main_3_4;
  allocp[0] = a1;
  allocp[1] = cdr_of(a0);
  x1 = makecons(&allocp[0]);
  a0 = arg(x0, 0);
  a1 = x1;
  allocp += 2;
  execute(main_3_0);
  check_stack(4);
  goto main_3_ext_interrupt;
 case VARREF:
  deref_and_jump_of_lvalue(x0,main_3_2);
  *reasonp++ =  x0;
  goto main_3_4;
  };
  goto main_3_4;
 case ATOMIC:
  if (a0 != NILATOM) goto main_3_4;
 main_3_3:
  switch (ptagof(a1)) {
 case CONS:
  a0 = car_of(a1);
  a1 = cdr_of(a1);
  execute(main_3_0);
  check_stack(4);
  goto main_3_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto main_3_4;
  proceed();
 case VARREF:
  deref_and_jump_of_lvalue(a1,main_3_3);
  *reasonp++ =  a1;
  goto main_3_4;
  };
  goto main_3_4;
 case VARREF:
  deref_and_jump_of_lvalue(a0,main_3_1);
  *reasonp++ =  a0;
  goto main_3_4;
  };
  goto main_3_4;
 main_3_4:
  otherwise(main_3_interrupt);
 main_3_5:
  switch (ptagof(a0)) {
 case CONS:
  check_stack(4);
  x0 = cdr_of(a0);
  stackp[0] = x0;
  stackp[1] = a1;
  stackp[2] = allocp[0] = x1 = makeref(&allocp[0]);
  stackp[3] = (q)(&predicate_sorted__bag_xmain_3);
  a0 = car_of(a0);
  a1 = a2;
  a2 = x1;
  stackp += 4;
  allocp += 1;
  execute(message_3_0);
  check_stack(4);
  goto message_3_ext_interrupt;
 case VARREF:
  deref_and_jump_of_lvalue(a0,main_3_5);
  *reasonp++ =  a0;
  goto main_3_interrupt;
  };
  goto main_3_interrupt;
 main_3_ext_interrupt:
  reasonp = 0l;
 main_3_interrupt:
  toppred = &predicate_sorted__bag_xmain_3;
  goto interrupt_3;
 }

 message_3_top: {
  q x0, x1, x2;
  stackp -= 3;
  a0 = stackp[0];
  a1 = stackp[1];
  a2 = stackp[2];
 message_3_clear_reason:
  reasonp = reasons;
 message_3_0:
 message_3_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_empty_1:
  check_stack(4);
  x0 = arg(a0, 0);
  stackp[0] = x0;
  stackp[1] = a1;
  stackp[2] = a2;
  stackp[3] = (q)(&predicate_splay__tree_xempty_3);
  stackp += 4;
  proceed();
 case functor_put_1:
  check_stack(10);
  stackp[0] = allocp[0] = x0 = makeref(&allocp[0]);
  x1 = arg(a0, 0);
  stackp[1] = x1;
  stackp[2] = allocp[1] = x2 = makeref(&allocp[1]);
  stackp[3] = a2;
  stackp[4] = (q)(&predicate_sorted__bag_xmessage_2F3_243_4);
  stackp[5] = x1;
  stackp[6] = x0;
  stackp[7] = a1;
  stackp[8] = x2;
  stackp[9] = (q)(&predicate_splay__tree_xempty_4);
  stackp += 10;
  allocp += 2;
  proceed();
 case functor_get_1:
  check_stack(9);
  stackp[0] = allocp[0] = x0 = makeref(&allocp[0]);
  stackp[1] = allocp[1] = x1 = makeref(&allocp[1]);
  x2 = arg(a0, 0);
  stackp[2] = x2;
  stackp[3] = a2;
  stackp[4] = (q)(&predicate_sorted__bag_xmessage_2F3_242_4);
  stackp[5] = x0;
  stackp[6] = a1;
  stackp[7] = x1;
  stackp[8] = (q)(&predicate_splay__tree_xempty_3);
  stackp += 9;
  allocp += 2;
  proceed();
 case functor_get__if__any_1:
  allocp[0] = makesym(functor_get__min__if__any_1);
  allocp[1] = arg(a0, 0);
  x0 = makefunctor(&allocp[0]);
  a0 = x0;
  allocp += 2;
  execute(message_3_0);
  check_stack(4);
  goto message_3_ext_interrupt;
 case functor_get__all_1:
  check_stack(7);
  stackp[0] = allocp[0] = x0 = makeref(&allocp[0]);
  x1 = arg(a0, 0);
  stackp[1] = x1;
  stackp[2] = (q)(&predicate_sorted__bag_xflatten_2);
  stackp[3] = x0;
  stackp[4] = a1;
  stackp[5] = a2;
  stackp[6] = (q)(&predicate_splay__tree_xget__all_3);
  stackp += 7;
  allocp += 1;
  proceed();
 case functor_carbon__copy_1:
  check_stack(7);
  unify(a2, a1);
  stackp[0] = allocp[0] = x0 = makeref(&allocp[0]);
  x1 = arg(a0, 0);
  stackp[1] = x1;
  stackp[2] = (q)(&predicate_sorted__bag_xflatten_2);
  stackp[3] = x0;
  stackp[4] = a1;
  stackp[5] = allocp[1] = x2 = makeref(&allocp[1]);
  stackp[6] = (q)(&predicate_splay__tree_xget__all_3);
  stackp += 7;
  allocp += 2;
  proceed();
 case functor_get__max__if__any_1:
  check_stack(9);
  stackp[0] = allocp[0] = x0 = makeref(&allocp[0]);
  x1 = arg(a0, 0);
  stackp[1] = x1;
  stackp[2] = a2;
  stackp[3] = allocp[1] = x2 = makeref(&allocp[1]);
  stackp[4] = (q)(&predicate_sorted__bag_xmessage_2F3_241_4);
  stackp[5] = x0;
  stackp[6] = a1;
  stackp[7] = x2;
  stackp[8] = (q)(&predicate_splay__tree_xempty_3);
  stackp += 9;
  allocp += 2;
  proceed();
 case functor_get__min__if__any_1:
  check_stack(9);
  stackp[0] = allocp[0] = x0 = makeref(&allocp[0]);
  x1 = arg(a0, 0);
  stackp[1] = x1;
  stackp[2] = a2;
  stackp[3] = allocp[1] = x2 = makeref(&allocp[1]);
  stackp[4] = (q)(&predicate_sorted__bag_xmessage_2F3_240_4);
  stackp[5] = x0;
  stackp[6] = a1;
  stackp[7] = x2;
  stackp[8] = (q)(&predicate_splay__tree_xempty_3);
  stackp += 9;
  allocp += 2;
  proceed();
  };
  goto message_3_interrupt;
 case VARREF:
  deref_and_jump_of_lvalue(a0,message_3_1);
  *reasonp++ =  a0;
  goto message_3_interrupt;
  };
  goto message_3_interrupt;
 message_3_ext_interrupt:
  reasonp = 0l;
 message_3_interrupt:
  toppred = &predicate_sorted__bag_xmessage_3;
  goto interrupt_3;
 }

 message_2F3_243_4_top: {
  q x0, x1, x2;
  stackp -= 4;
  a0 = stackp[0];
  a1 = stackp[1];
  a2 = stackp[2];
  a3 = stackp[3];
 message_2F3_243_4_clear_reason:
  reasonp = reasons;
 message_2F3_243_4_0:
 message_2F3_243_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto message_2F3_243_4_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  check_stack(5);
  allocp[0] = NILATOM;
  allocp[1] = a1;
  x0 = makecons(&allocp[0]);
  stackp[0] = a1;
  stackp[1] = x0;
  stackp[2] = a2;
  stackp[3] = a3;
  stackp[4] = (q)(&predicate_splay__tree_xput_4);
  stackp += 5;
  allocp += 2;
  proceed();
 case symval(makesym(atom_no)):
  check_stack(10);
  allocp[0] = NILATOM;
  allocp[1] = a1;
  x0 = makecons(&allocp[0]);
  stackp[0] = allocp[2] = x1 = makeref(&allocp[2]);
  stackp[1] = x0;
  stackp[2] = allocp[3] = x2 = makeref(&allocp[3]);
  stackp[3] = (q)(&predicate_sorted__bag_xappend_3);
  stackp[4] = a1;
  stackp[5] = x1;
  stackp[6] = x2;
  stackp[7] = a2;
  stackp[8] = a3;
  stackp[9] = (q)(&predicate_splay__tree_xupdate_5);
  stackp += 10;
  allocp += 4;
  proceed();
  };
  goto message_2F3_243_4_interrupt;
 case VARREF:
  deref_and_jump_of_lvalue(a0,message_2F3_243_4_1);
  *reasonp++ =  a0;
  goto message_2F3_243_4_interrupt;
  };
  goto message_2F3_243_4_interrupt;
 message_2F3_243_4_ext_interrupt:
  reasonp = 0l;
 message_2F3_243_4_interrupt:
  toppred = &predicate_sorted__bag_xmessage_2F3_243_4;
  goto interrupt_4;
 }

 message_2F3_242_4_top: {
  q x0, x1, x2, x3;
  stackp -= 4;
  a0 = stackp[0];
  a1 = stackp[1];
  a2 = stackp[2];
  a3 = stackp[3];
 message_2F3_242_4_clear_reason:
  reasonp = reasons;
 message_2F3_242_4_0:
 message_2F3_242_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_no)) goto message_2F3_242_4_interrupt;
  check_stack(14);
  stackp[0] = allocp[0] = x0 = makeref(&allocp[0]);
  stackp[1] = a3;
  stackp[2] = allocp[1] = x1 = makeref(&allocp[1]);
  stackp[3] = allocp[2] = x2 = makeref(&allocp[2]);
  stackp[4] = (q)(&predicate_sorted__bag_xmessage_2F3_242_2F4_240_4);
  stackp[5] = allocp[3] = x3 = makeref(&allocp[3]);
  stackp[6] = x0;
  stackp[7] = a2;
  stackp[8] = (q)(&predicate_sorted__bag_xlast__elem_3);
  stackp[9] = x2;
  stackp[10] = x3;
  stackp[11] = a1;
  stackp[12] = x1;
  stackp[13] = (q)(&predicate_splay__tree_xget__max_4);
  stackp += 14;
  allocp += 4;
  proceed();
 case VARREF:
  deref_and_jump_of_lvalue(a0,message_2F3_242_4_1);
  *reasonp++ =  a0;
  goto message_2F3_242_4_interrupt;
  };
  goto message_2F3_242_4_interrupt;
 message_2F3_242_4_ext_interrupt:
  reasonp = 0l;
 message_2F3_242_4_interrupt:
  toppred = &predicate_sorted__bag_xmessage_2F3_242_4;
  goto interrupt_4;
 }

 message_2F3_242_2F4_240_4_top: {
  stackp -= 4;
  a0 = stackp[0];
  a1 = stackp[1];
  a2 = stackp[2];
  a3 = stackp[3];
 message_2F3_242_2F4_240_4_clear_reason:
  reasonp = reasons;
 message_2F3_242_2F4_240_4_0:
 message_2F3_242_2F4_240_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != NILATOM) goto message_2F3_242_2F4_240_4_2;
  unify(a1, a2);
  proceed();
 case VARREF:
  deref_and_jump_of_lvalue(a0,message_2F3_242_2F4_240_4_1);
  *reasonp++ =  a0;
  goto message_2F3_242_2F4_240_4_2;
  };
  goto message_2F3_242_2F4_240_4_2;
 message_2F3_242_2F4_240_4_2:
  otherwise(message_2F3_242_2F4_240_4_interrupt);
  check_stack(5);
  stackp[0] = a3;
  stackp[1] = a0;
  stackp[2] = a2;
  stackp[3] = a1;
  stackp[4] = (q)(&predicate_splay__tree_xput_4);
  stackp += 5;
  proceed();
 message_2F3_242_2F4_240_4_ext_interrupt:
  reasonp = 0l;
 message_2F3_242_2F4_240_4_interrupt:
  toppred = &predicate_sorted__bag_xmessage_2F3_242_2F4_240_4;
  goto interrupt_4;
 }

 message_2F3_241_4_top: {
  q x0, x1, x2, x3, x4, x5;
  stackp -= 4;
  a0 = stackp[0];
  a1 = stackp[1];
  a2 = stackp[2];
  a3 = stackp[3];
 message_2F3_241_4_clear_reason:
  reasonp = reasons;
 message_2F3_241_4_0:
 message_2F3_241_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto message_2F3_241_4_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  unify_value(a1, makefunctor(&vector_const_0));
  unify(a2, a3);
  proceed();
 case symval(makesym(atom_no)):
  check_stack(14);
  stackp[0] = allocp[0] = x0 = makeref(&allocp[0]);
  stackp[1] = a2;
  stackp[2] = allocp[1] = x1 = makeref(&allocp[1]);
  stackp[3] = allocp[2] = x2 = makeref(&allocp[2]);
  stackp[4] = (q)(&predicate_sorted__bag_xmessage_2F3_241_2F4_240_4);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x3;
  x4 = create_vector(&allocp[4], 1, allocp);
  allocp += 5;
  unify_value(a1, x4);
  stackp[5] = allocp[0] = x5 = makeref(&allocp[0]);
  stackp[6] = x0;
  stackp[7] = x3;
  stackp[8] = (q)(&predicate_sorted__bag_xlast__elem_3);
  stackp[9] = x2;
  stackp[10] = x5;
  stackp[11] = a3;
  stackp[12] = x1;
  stackp[13] = (q)(&predicate_splay__tree_xget__max_4);
  stackp += 14;
  allocp += 1;
  proceed();
  };
  goto message_2F3_241_4_interrupt;
 case VARREF:
  deref_and_jump_of_lvalue(a0,message_2F3_241_4_1);
  *reasonp++ =  a0;
  goto message_2F3_241_4_interrupt;
  };
  goto message_2F3_241_4_interrupt;
 message_2F3_241_4_ext_interrupt:
  reasonp = 0l;
 message_2F3_241_4_interrupt:
  toppred = &predicate_sorted__bag_xmessage_2F3_241_4;
  goto interrupt_4;
 }

 message_2F3_241_2F4_240_4_top: {
  stackp -= 4;
  a0 = stackp[0];
  a1 = stackp[1];
  a2 = stackp[2];
  a3 = stackp[3];
 message_2F3_241_2F4_240_4_clear_reason:
  reasonp = reasons;
 message_2F3_241_2F4_240_4_0:
 message_2F3_241_2F4_240_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != NILATOM) goto message_2F3_241_2F4_240_4_2;
  unify(a1, a2);
  proceed();
 case VARREF:
  deref_and_jump_of_lvalue(a0,message_2F3_241_2F4_240_4_1);
  *reasonp++ =  a0;
  goto message_2F3_241_2F4_240_4_2;
  };
  goto message_2F3_241_2F4_240_4_2;
 message_2F3_241_2F4_240_4_2:
  otherwise(message_2F3_241_2F4_240_4_interrupt);
  check_stack(5);
  stackp[0] = a3;
  stackp[1] = a0;
  stackp[2] = a2;
  stackp[3] = a1;
  stackp[4] = (q)(&predicate_splay__tree_xput_4);
  stackp += 5;
  proceed();
 message_2F3_241_2F4_240_4_ext_interrupt:
  reasonp = 0l;
 message_2F3_241_2F4_240_4_interrupt:
  toppred = &predicate_sorted__bag_xmessage_2F3_241_2F4_240_4;
  goto interrupt_4;
 }

 message_2F3_240_4_top: {
  q x0, x1, x2, x3, x4, x5;
  stackp -= 4;
  a0 = stackp[0];
  a1 = stackp[1];
  a2 = stackp[2];
  a3 = stackp[3];
 message_2F3_240_4_clear_reason:
  reasonp = reasons;
 message_2F3_240_4_0:
 message_2F3_240_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto message_2F3_240_4_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  unify_value(a1, makefunctor(&vector_const_0));
  unify(a2, a3);
  proceed();
 case symval(makesym(atom_no)):
  check_stack(10);
  stackp[0] = allocp[0] = x0 = makeref(&allocp[0]);
  stackp[1] = a2;
  stackp[2] = allocp[1] = x1 = makeref(&allocp[1]);
  stackp[3] = allocp[2] = x2 = makeref(&allocp[2]);
  stackp[4] = (q)(&predicate_sorted__bag_xmessage_2F3_240_2F4_240_4);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x3;
  x4 = create_vector(&allocp[4], 1, allocp);
  allocp += 5;
  unify_value(a1, x4);
  allocp[0] = x0;
  allocp[1] = x3;
  x5 = makecons(&allocp[0]);
  stackp[5] = x2;
  stackp[6] = x5;
  stackp[7] = a3;
  stackp[8] = x1;
  stackp[9] = (q)(&predicate_splay__tree_xget__min_4);
  stackp += 10;
  allocp += 2;
  proceed();
  };
  goto message_2F3_240_4_interrupt;
 case VARREF:
  deref_and_jump_of_lvalue(a0,message_2F3_240_4_1);
  *reasonp++ =  a0;
  goto message_2F3_240_4_interrupt;
  };
  goto message_2F3_240_4_interrupt;
 message_2F3_240_4_ext_interrupt:
  reasonp = 0l;
 message_2F3_240_4_interrupt:
  toppred = &predicate_sorted__bag_xmessage_2F3_240_4;
  goto interrupt_4;
 }

 message_2F3_240_2F4_240_4_top: {
  stackp -= 4;
  a0 = stackp[0];
  a1 = stackp[1];
  a2 = stackp[2];
  a3 = stackp[3];
 message_2F3_240_2F4_240_4_clear_reason:
  reasonp = reasons;
 message_2F3_240_2F4_240_4_0:
 message_2F3_240_2F4_240_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != NILATOM) goto message_2F3_240_2F4_240_4_2;
  unify(a1, a2);
  proceed();
 case VARREF:
  deref_and_jump_of_lvalue(a0,message_2F3_240_2F4_240_4_1);
  *reasonp++ =  a0;
  goto message_2F3_240_2F4_240_4_2;
  };
  goto message_2F3_240_2F4_240_4_2;
 message_2F3_240_2F4_240_4_2:
  otherwise(message_2F3_240_2F4_240_4_interrupt);
  check_stack(5);
  stackp[0] = a3;
  stackp[1] = a0;
  stackp[2] = a2;
  stackp[3] = a1;
  stackp[4] = (q)(&predicate_splay__tree_xput_4);
  stackp += 5;
  proceed();
 message_2F3_240_2F4_240_4_ext_interrupt:
  reasonp = 0l;
 message_2F3_240_2F4_240_4_interrupt:
  toppred = &predicate_sorted__bag_xmessage_2F3_240_2F4_240_4;
  goto interrupt_4;
 }

 flatten_2_top: {
  q x0, x1, x2, x3;
  stackp -= 2;
  a0 = stackp[0];
  a1 = stackp[1];
 flatten_2_clear_reason:
  reasonp = reasons;
 flatten_2_0:
 flatten_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 flatten_2_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__3D_2)) goto flatten_2_interrupt;
  check_stack(3);
  x1 = cdr_of(a0);
  stackp[0] = x1;
  stackp[1] = allocp[0] = x2 = makeref(&allocp[0]);
  stackp[2] = (q)(&predicate_sorted__bag_xflatten_2);
  a0 = arg(x0, 1);
  x3 = arg(x0, 0);
  a2 = a1;
  a3 = x2;
  a1 = x3;
  stackp += 3;
  allocp += 1;
  execute(flatten_4_0);
  check_stack(5);
  goto flatten_4_ext_interrupt;
 case VARREF:
  deref_and_jump_of_lvalue(x0,flatten_2_2);
  *reasonp++ =  x0;
  goto flatten_2_interrupt;
  };
  goto flatten_2_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto flatten_2_interrupt;
  unify_value(a1, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump_of_lvalue(a0,flatten_2_1);
  *reasonp++ =  a0;
  goto flatten_2_interrupt;
  };
  goto flatten_2_interrupt;
 flatten_2_ext_interrupt:
  reasonp = 0l;
 flatten_2_interrupt:
  toppred = &predicate_sorted__bag_xflatten_2;
  goto interrupt_2;
 }

 flatten_4_top: {
  q x0, x1;
  stackp -= 4;
  a0 = stackp[0];
  a1 = stackp[1];
  a2 = stackp[2];
  a3 = stackp[3];
 flatten_4_clear_reason:
  reasonp = reasons;
 flatten_4_0:
 flatten_4_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = car_of(a0);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  a0 = cdr_of(a0);
  a2 = x1;
  execute(flatten_4_0);
  check_stack(5);
  goto flatten_4_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto flatten_4_interrupt;
  unify(a2, a3);
  proceed();
 case VARREF:
  deref_and_jump_of_lvalue(a0,flatten_4_1);
  *reasonp++ =  a0;
  goto flatten_4_interrupt;
  };
  goto flatten_4_interrupt;
 flatten_4_ext_interrupt:
  reasonp = 0l;
 flatten_4_interrupt:
  toppred = &predicate_sorted__bag_xflatten_4;
  goto interrupt_4;
 }

 append_3_top: {
  q x0, x1;
  stackp -= 3;
  a0 = stackp[0];
  a1 = stackp[1];
  a2 = stackp[2];
 append_3_clear_reason:
  reasonp = reasons;
 append_3_0:
 append_3_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = car_of(a0);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  a0 = cdr_of(a0);
  a2 = x1;
  execute(append_3_0);
  check_stack(4);
  goto append_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto append_3_interrupt;
  unify(a1, a2);
  proceed();
 case VARREF:
  deref_and_jump_of_lvalue(a0,append_3_1);
  *reasonp++ =  a0;
  goto append_3_interrupt;
  };
  goto append_3_interrupt;
 append_3_ext_interrupt:
  reasonp = 0l;
 append_3_interrupt:
  toppred = &predicate_sorted__bag_xappend_3;
  goto interrupt_3;
 }

 last__elem_3_top: {
  q x0, x1;
  stackp -= 3;
  a0 = stackp[0];
  a1 = stackp[1];
  a2 = stackp[2];
 last__elem_3_clear_reason:
  reasonp = reasons;
 last__elem_3_0:
 last__elem_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = cdr_of(a0);
 last__elem_3_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != NILATOM) goto last__elem_3_3;
  unify_value(a1, NILATOM);
  x1 = car_of(a0);
  unify(a2, x1);
  proceed();
 case VARREF:
  deref_and_jump_of_lvalue(x0,last__elem_3_2);
  *reasonp++ =  x0;
  goto last__elem_3_3;
  };
  goto last__elem_3_3;
 case VARREF:
  deref_and_jump_of_lvalue(a0,last__elem_3_1);
  *reasonp++ =  a0;
  goto last__elem_3_3;
  };
  goto last__elem_3_3;
 last__elem_3_3:
  otherwise(last__elem_3_interrupt);
 last__elem_3_4:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = car_of(a0);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(last__elem_3_0);
  check_stack(4);
  goto last__elem_3_ext_interrupt;
 case VARREF:
  deref_and_jump_of_lvalue(a0,last__elem_3_4);
  *reasonp++ =  a0;
  goto last__elem_3_interrupt;
  };
  goto last__elem_3_interrupt;
 last__elem_3_ext_interrupt:
  reasonp = 0l;
 last__elem_3_interrupt:
  toppred = &predicate_sorted__bag_xlast__elem_3;
  goto interrupt_3;
 }

 resume__check_0_top: {
		resume_check();
  }
 interrupt_4:
 stackp[3] = a3;
 interrupt_3:
 stackp[2] = a2;
 interrupt_2:
 stackp[1] = a1;
 interrupt_1:
 stackp[0] = a0;
  interrupt_0:
  interrupt_check();
  loop_within_module(module_sorted__bag);
}
