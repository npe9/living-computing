/* Compiled by KLIC compiler version 2.002 (Tue May 23 13:27:38 JST 1995) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_converter();
Const struct predicate predicate_converter_xto__analyze_3 =
   { module_converter, 0, 3 };
Const struct predicate predicate_converter_xto__analyze__modules_3 =
   { module_converter, 1, 3 };
Const struct predicate predicate_converter_xto__analyze__clauses_3 =
   { module_converter, 2, 3 };
Const struct predicate predicate_converter_xto__analyze__clause_3 =
   { module_converter, 3, 3 };
Const struct predicate predicate_converter_xcount__variables_8 =
   { module_converter, 4, 8 };
Const struct predicate predicate_converter_xget__varnummax__goallist_8 =
   { module_converter, 5, 8 };
Const struct predicate predicate_converter_xget__varnummax__goal_8 =
   { module_converter, 6, 8 };
Const struct predicate predicate_converter_xget__varnummax__functor_9 =
   { module_converter, 7, 9 };
Const struct predicate predicate_converter_xget__varnummax__arg_8 =
   { module_converter, 8, 8 };
Const struct predicate predicate_converter_xinit__headvar_4 =
   { module_converter, 9, 4 };
Const struct predicate predicate_converter_xinit__headvar__head_4 =
   { module_converter, 10, 4 };
Const struct predicate predicate_converter_xinit__headvar__head1_5 =
   { module_converter, 11, 5 };
Const struct predicate predicate_converter_xinit__headvar__guard_4 =
   { module_converter, 12, 4 };
Const struct predicate predicate_converter_xinit__headvar__guard1_6 =
   { module_converter, 13, 6 };
Const struct predicate predicate_converter_xinit__headvar__guard2_5 =
   { module_converter, 14, 5 };
Const struct predicate predicate_converter_xinit__headvar__guard2__functor_6 =
   { module_converter, 15, 6 };
Const struct predicate predicate_converter_xinit__varcount_3 =
   { module_converter, 16, 3 };
Const struct predicate predicate_converter_xinit__varcount1_3 =
   { module_converter, 17, 3 };
Const struct predicate predicate_converter_xfrom__analyze_2 =
   { module_converter, 18, 2 };
Const struct predicate predicate_converter_xfrom__analyze__modules_2 =
   { module_converter, 19, 2 };
Const struct predicate predicate_converter_xfrom__analyze__clauses_4 =
   { module_converter, 20, 4 };
Const struct predicate predicate_converter_xfrom__analyze__clause_2 =
   { module_converter, 21, 2 };
Const struct predicate predicate_converter_xfrom__analyze__goals_3 =
   { module_converter, 22, 3 };
Const struct predicate predicate_converter_xfrom__analyze__goals1_5 =
   { module_converter, 23, 5 };
Const struct predicate predicate_converter_xfrom__analyze__goal_3 =
   { module_converter, 24, 3 };
Const struct predicate predicate_converter_xfrom__analyze__functor_3 =
   { module_converter, 25, 3 };
Const struct predicate predicate_converter_xfrom__analyze__args_4 =
   { module_converter, 26, 4 };
Const struct predicate predicate_converter_xfrom__analyze__goal__modulename_4 =
   { module_converter, 27, 4 };
Const struct predicate predicate_converter_xfrom__analyze__goal__pragma_3 =
   { module_converter, 28, 3 };
extern Const struct predicate predicate_integer__arithmetics_xadd_3;
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_functor__table_xfunctor_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_xnew__functor_3;
extern Const struct predicate predicate_functor__table_xsetarg_4;
extern Const struct predicate predicate_uty_xcreate__functor_3;
extern Const struct predicate predicate_uty_xnew__functor__init_4;
extern Const struct predicate predicate_uty_xmax_3;
extern Const struct predicate predicate_parse__uty_xdecode__goal_4;

module module_converter(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  static Const q cons_const_0[] = {
    NILATOM,
    makesym(atom__3F),
  };
  q a0, a1, a2, a3, a4, a5, a6, a7, a8;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, to__analyze_3_top);
    case_pred(1, to__analyze__modules_3_top);
    case_pred(2, to__analyze__clauses_3_top);
    case_pred(3, to__analyze__clause_3_top);
    case_pred(4, count__variables_8_top);
    case_pred(5, get__varnummax__goallist_8_top);
    case_pred(6, get__varnummax__goal_8_top);
    case_pred(7, get__varnummax__functor_9_top);
    case_pred(8, get__varnummax__arg_8_top);
    case_pred(9, init__headvar_4_top);
    case_pred(10, init__headvar__head_4_top);
    case_pred(11, init__headvar__head1_5_top);
    case_pred(12, init__headvar__guard_4_top);
    case_pred(13, init__headvar__guard1_6_top);
    case_pred(14, init__headvar__guard2_5_top);
    case_pred(15, init__headvar__guard2__functor_6_top);
    case_pred(16, init__varcount_3_top);
    case_pred(17, init__varcount1_3_top);
    case_pred(18, from__analyze_2_top);
    case_pred(19, from__analyze__modules_2_top);
    case_pred(20, from__analyze__clauses_4_top);
    case_pred(21, from__analyze__clause_2_top);
    case_pred(22, from__analyze__goals_3_top);
    case_pred(23, from__analyze__goals1_5_top);
    case_pred(24, from__analyze__goal_3_top);
    case_pred(25, from__analyze__functor_3_top);
    case_pred(26, from__analyze__args_4_top);
    case_pred(27, from__analyze__goal__modulename_4_top);
    last_case_pred(28, from__analyze__goal__pragma_3_top);
  }

 to__analyze_3_top: {
  a2 = qp->args[2];
  qp = qp->next;
 to__analyze_3_clear_reason:
  reasonp = reasons;
 to__analyze_3_0:
  execute(to__analyze__modules_3_0);
  goto to__analyze__modules_3_ext_interrupt;
 to__analyze_3_ext_interrupt:
  reasonp = 0l;
 to__analyze_3_interrupt:
  goto interrupt_3;
 }

 to__analyze__modules_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a2 = qp->args[2];
  qp = qp->next;
 to__analyze__modules_3_clear_reason:
  reasonp = reasons;
 to__analyze__modules_3_0:
 to__analyze__modules_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 to__analyze__modules_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto to__analyze__modules_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_converter_xto__analyze__modules_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = makesym(functor_module_2);
  allocp[6] = arg(x0, 0);
  allocp[7] = x5 = makeref(&allocp[7]);
  x4 = makefunctor(&allocp[5]);
  allocp[8] = x3;
  allocp[9] = x4;
  x6 = makecons(&allocp[8]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  unify_value(a2, x6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_uty_xcreate__functor_3);
  allocp[2] = makesym(atom_clauses);
  allocp[3] = x7 = makeref(&allocp[3]);
  allocp[4] = x5;
  allocp[5] = makesym(functor_module_2);
  allocp[6] = arg(x0, 0);
  allocp[7] = x9 = makeref(&allocp[7]);
  x8 = makefunctor(&allocp[5]);
  allocp[8] = x2;
  allocp[9] = x8;
  x10 = makecons(&allocp[8]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  unify_value(a1, x10);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_uty_xcreate__functor_3);
  allocp[2] = makesym(atom_clauses);
  allocp[3] = x11 = makeref(&allocp[3]);
  allocp[4] = x9;
  a0 = arg(x0, 1);
  a1 = x11;
  a2 = x7;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(to__analyze__clauses_3_0);
  goto to__analyze__clauses_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,to__analyze__modules_3_2);
  *reasonp++ =  x0;
  goto to__analyze__modules_3_interrupt;
  };
  goto to__analyze__modules_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto to__analyze__modules_3_interrupt;
  unify_value(a1, NILATOM);
  unify_value(a2, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a0,to__analyze__modules_3_1);
  *reasonp++ =  a0;
  goto to__analyze__modules_3_interrupt;
  };
  goto to__analyze__modules_3_interrupt;
 to__analyze__modules_3_ext_interrupt:
  reasonp = 0l;
 to__analyze__modules_3_interrupt:
  toppred = &predicate_converter_xto__analyze__modules_3;
  goto interrupt_3;
 }

 to__analyze__clauses_3_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  qp = qp->next;
 to__analyze__clauses_3_clear_reason:
  reasonp = reasons;
 to__analyze__clauses_3_0:
 to__analyze__clauses_3_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_converter_xto__analyze__clauses_3);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = x1;
  allocp[6] = x4 = makeref(&allocp[6]);
  x3 = makecons(&allocp[5]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  unify_value(a1, x3);
  allocp[0] = x2;
  allocp[1] = x6 = makeref(&allocp[1]);
  x5 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x5);
  a0 = car_of(a0);
  a1 = x4;
  a2 = x6;
  execute(to__analyze__clause_3_0);
  goto to__analyze__clause_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto to__analyze__clauses_3_interrupt;
  unify_value(a1, NILATOM);
  unify_value(a2, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a0,to__analyze__clauses_3_1);
  *reasonp++ =  a0;
  goto to__analyze__clauses_3_interrupt;
  };
  goto to__analyze__clauses_3_interrupt;
 to__analyze__clauses_3_ext_interrupt:
  reasonp = 0l;
 to__analyze__clauses_3_interrupt:
  toppred = &predicate_converter_xto__analyze__clauses_3;
  goto interrupt_3;
 }

 to__analyze__clause_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  qp = qp->next;
 to__analyze__clause_3_clear_reason:
  reasonp = reasons;
 to__analyze__clause_3_0:
 to__analyze__clause_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto to__analyze__clause_3_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_otherwise)):
  unify_value(a2, makesym(atom_type));
  unify_value(a1, a0);
  proceed();
 case symval(makesym(atom_alternatively)):
  unify_value(a2, makesym(atom_type));
  unify_value(a1, a0);
  proceed();
  };
  goto to__analyze__clause_3_interrupt;
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_clause_4)) goto to__analyze__clause_3_interrupt;
  allocp[0] = makesym(functor_clause_6);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = arg(a0, 3);
  allocp[5] = x4 = makeref(&allocp[5]);
  allocp[6] = x5 = makeref(&allocp[6]);
  x0 = makefunctor(&allocp[0]);
  allocp += 7;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_uty_xcreate__functor_3);
  allocp[2] = makesym(atom_bodys);
  allocp[3] = x6 = makeref(&allocp[3]);
  allocp[4] = x3;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_uty_xcreate__functor_3);
  allocp[7] = makesym(atom_guards);
  allocp[8] = x7 = makeref(&allocp[8]);
  allocp[9] = x2;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_converter_xinit__varcount_3);
  allocp[12] = x8 = makeref(&allocp[12]);
  allocp[13] = x9 = makeref(&allocp[13]);
  allocp[14] = x5;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_converter_xinit__headvar_4);
  allocp[17] = x1;
  allocp[18] = x7;
  allocp[19] = x8;
  allocp[20] = x4;
  allocp[21] = (q)(struct goalrec*)&allocp[15];
  allocp[22] = (q)(&predicate_uty_xnew__functor__init_4);
  allocp[23] = makesym(atom_type);
  allocp[24] = x8;
  allocp[25] = makecons(cons_const_0);
  allocp[26] = a2;
  x10 = arg(a0, 0);
  a1 = x1;
  a2 = arg(a0, 1);
  a3 = x7;
  a4 = arg(a0, 2);
  a5 = x6;
  a6 = x8;
  a7 = x9;
  a0 = x10;
  qp = (struct goalrec*)&allocp[21];
  allocp += 27;
  execute(count__variables_8_0);
  goto count__variables_8_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,to__analyze__clause_3_1);
  *reasonp++ =  a0;
  goto to__analyze__clause_3_interrupt;
  };
  goto to__analyze__clause_3_interrupt;
 to__analyze__clause_3_ext_interrupt:
  reasonp = 0l;
 to__analyze__clause_3_interrupt:
  toppred = &predicate_converter_xto__analyze__clause_3;
  goto interrupt_3;
 }

 count__variables_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 count__variables_8_clear_reason:
  reasonp = reasons;
 count__variables_8_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = makeint(1L);
  allocp[4] = a6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_uty_xmax_3);
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = x0;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_converter_xget__varnummax__goallist_8);
  allocp[12] = makeint(-1L);
  allocp[13] = a4;
  allocp[14] = a5;
  allocp[15] = x2;
  allocp[16] = x3 = makeref(&allocp[16]);
  allocp[17] = a7;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = x5 = makeref(&allocp[19]);
  allocp[20] = (q)(struct goalrec*)&allocp[10];
  allocp[21] = (q)(&predicate_converter_xget__varnummax__goallist_8);
  allocp[22] = makeint(-1L);
  allocp[23] = a2;
  allocp[24] = a3;
  allocp[25] = x1;
  allocp[26] = x6 = makeref(&allocp[26]);
  allocp[27] = x3;
  allocp[28] = x7 = makeref(&allocp[28]);
  allocp[29] = x4;
  x8 = a0;
  a2 = a1;
  allocp[30] = x9 = makeref(&allocp[30]);
  a3 = x9;
  a4 = NILATOM;
  a5 = x6;
  a6 = makeint(0L);
  a7 = x7;
  a1 = x8;
  a0 = makeint(-1L);
  qp = (struct goalrec*)&allocp[20];
  allocp += 31;
  execute(get__varnummax__goal_8_0);
  goto get__varnummax__goal_8_ext_interrupt;
 count__variables_8_ext_interrupt:
  reasonp = 0l;
 count__variables_8_interrupt:
  toppred = &predicate_converter_xcount__variables_8;
  goto interrupt_8;
 }

 get__varnummax__goallist_8_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 get__varnummax__goallist_8_clear_reason:
  reasonp = reasons;
 get__varnummax__goallist_8_0:
 get__varnummax__goallist_8_1:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_converter_xget__varnummax__goallist_8);
  allocp[2] = x0 = makeref(&allocp[2]);
  x1 = cdr_of(a1);
  allocp[3] = x1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x2;
  allocp[11] = x6 = makeref(&allocp[11]);
  x5 = makecons(&allocp[10]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  unify_value(a2, x5);
  a1 = car_of(a1);
  a2 = x6;
  a3 = x0;
  a5 = x3;
  a7 = x4;
  execute(get__varnummax__goal_8_0);
  goto get__varnummax__goal_8_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto get__varnummax__goallist_8_interrupt;
  unify_value(a2, NILATOM);
  unify3(a3, a0, a5, a4, a7, a6);
  proceed();
 case VARREF:
  deref_and_jump(a1,get__varnummax__goallist_8_1);
  *reasonp++ =  a1;
  goto get__varnummax__goallist_8_interrupt;
  };
  goto get__varnummax__goallist_8_interrupt;
 get__varnummax__goallist_8_ext_interrupt:
  reasonp = 0l;
 get__varnummax__goallist_8_interrupt:
  goto interrupt_8;
 }

 get__varnummax__goal_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 get__varnummax__goal_8_clear_reason:
  reasonp = reasons;
 get__varnummax__goal_8_0:
 get__varnummax__goal_8_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (isint(a1)) goto get__varnummax__goal_8_3;
 get__varnummax__goal_8_2:
  gblt_atom(a1,get__varnummax__goal_8_3);
  unify_value(a2, a1);
  unify3(a3, a0, a5, a4, a7, a6);
  proceed();
 case VARREF:
  deref_and_jump(a1,get__varnummax__goal_8_1);
  *reasonp++ =  a1;
  goto get__varnummax__goal_8_interrupt;
  };
  goto get__varnummax__goal_8_3;
 get__varnummax__goal_8_3:
  gblt_pfunctor(a1,x0,get__varnummax__goal_8_interrupt);
  gblt_arity(a1,x1,get__varnummax__goal_8_interrupt);
  x2 = a0;
  x3 = a1;
  x4 = a2;
  x5 = a3;
  x6 = a4;
  x7 = a5;
  x8 = a6;
  a8 = a7;
  a7 = x8;
  a6 = x7;
  a5 = x6;
  a4 = x5;
  a3 = x4;
  a2 = x3;
  a1 = x2;
  a0 = x1;
  execute(get__varnummax__functor_9_0);
  goto get__varnummax__functor_9_ext_interrupt;
 get__varnummax__goal_8_ext_interrupt:
  reasonp = 0l;
 get__varnummax__goal_8_interrupt:
  toppred = &predicate_converter_xget__varnummax__goal_8;
  goto interrupt_8;
 }

 get__varnummax__functor_9_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 get__varnummax__functor_9_clear_reason:
  reasonp = reasons;
 get__varnummax__functor_9_0:
 get__varnummax__functor_9_1:
  if (!isint(a0)) goto get__varnummax__functor_9_3;
  gblt_greater(a0,makeint(0L),get__varnummax__functor_9_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_converter_xget__varnummax__functor_9);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = x4 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x0;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[18] = a0;
  allocp[19] = a2;
  allocp[20] = x5 = makeref(&allocp[20]);
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_converter_xget__varnummax__arg_8);
  allocp[24] = a1;
  allocp[25] = x6 = makeref(&allocp[25]);
  allocp[26] = x5;
  allocp[27] = x1;
  allocp[28] = a5;
  allocp[29] = x3;
  allocp[30] = a7;
  allocp[31] = x4;
  allocp[32] = (q)(struct goalrec*)&allocp[22];
  allocp[33] = (q)(&predicate_functor__table_xarg_3);
  allocp[34] = a0;
  allocp[35] = a2;
  allocp[36] = x6;
  qp = (struct goalrec*)&allocp[32];
  allocp += 37;
  proceed();
 get__varnummax__functor_9_2:
  if (a0 != makeint(0L)) goto get__varnummax__functor_9_interrupt;
  unify4(a3, a2, a4, a1, a6, a5, a8, a7);
  proceed();
 get__varnummax__functor_9_3:
  if (!isref(a0)) goto get__varnummax__functor_9_interrupt;
  deref_and_jump(a0,get__varnummax__functor_9_1);
  *reasonp++ =  a0;
  goto get__varnummax__functor_9_interrupt;
 get__varnummax__functor_9_ext_interrupt:
  reasonp = 0l;
 get__varnummax__functor_9_interrupt:
  toppred = &predicate_converter_xget__varnummax__functor_9;
  goto interrupt_9;
 }

 get__varnummax__arg_8_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 get__varnummax__arg_8_clear_reason:
  reasonp = reasons;
 get__varnummax__arg_8_0:
 get__varnummax__arg_8_1:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_variable_1)) goto get__varnummax__arg_8_2;
  allocp[0] = a4;
  allocp[1] = arg(a1, 0);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a5, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[2] = a6;
  allocp[3] = makeint(1L);
  allocp[4] = a7;
  allocp[5] = makesym(functor_variable_3);
  allocp[6] = arg(a1, 0);
  allocp[7] = a6;
  allocp[8] = makesym(atom__3F);
  x1 = makefunctor(&allocp[5]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 9;
  unify_value(a2, x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_uty_xmax_3);
  allocp[2] = a0;
  x2 = arg(a1, 0);
  allocp[3] = x2;
  allocp[4] = a3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case VARREF:
  deref_and_jump(a1,get__varnummax__arg_8_1);
  *reasonp++ =  a1;
  goto get__varnummax__arg_8_2;
  };
  goto get__varnummax__arg_8_2;
 get__varnummax__arg_8_2:
  otherwise(get__varnummax__arg_8_interrupt);
  execute(get__varnummax__goal_8_0);
  goto get__varnummax__goal_8_ext_interrupt;
 get__varnummax__arg_8_ext_interrupt:
  reasonp = 0l;
 get__varnummax__arg_8_interrupt:
  goto interrupt_8;
 }

 init__headvar_4_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 init__headvar_4_clear_reason:
  reasonp = reasons;
 init__headvar_4_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_converter_xinit__headvar__guard_4);
  allocp[2] = a1;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_converter_xinit__headvar__head_4);
  allocp[8] = a0;
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = x1;
  allocp[11] = x0;
  allocp[12] = (q)(struct goalrec*)&allocp[6];
  allocp[13] = (q)(&predicate_functor__table_xnew__functor_3);
  allocp[14] = x2;
  allocp[15] = makesym(atom_headf);
  allocp[16] = a2;
  qp = (struct goalrec*)&allocp[12];
  allocp += 17;
  proceed();
 init__headvar_4_ext_interrupt:
  reasonp = 0l;
 init__headvar_4_interrupt:
  goto interrupt_4;
 }

 init__headvar__head_4_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 init__headvar__head_4_clear_reason:
  reasonp = reasons;
 init__headvar__head_4_0:
 init__headvar__head_4_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_functor_1)) goto init__headvar__head_4_interrupt;
  x0 = arg(a0, 0);
 init__headvar__head_4_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (isint(x0)) goto init__headvar__head_4_4;
 init__headvar__head_4_3:
  gblt_atom(x0,init__headvar__head_4_4);
  unify(a2, a1);
  unify_value(a3, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(x0,init__headvar__head_4_2);
  *reasonp++ =  x0;
  goto init__headvar__head_4_interrupt;
  };
  goto init__headvar__head_4_4;
 init__headvar__head_4_4:
  gblt_pfunctor(x0,x1,init__headvar__head_4_interrupt);
  gblt_arity(x0,x2,init__headvar__head_4_interrupt);
  a0 = x0;
  x3 = a1;
  x4 = a2;
  a4 = a3;
  a3 = x4;
  a2 = x3;
  a1 = x2;
  execute(init__headvar__head1_5_0);
  goto init__headvar__head1_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,init__headvar__head_4_1);
  *reasonp++ =  a0;
  goto init__headvar__head_4_interrupt;
  };
  goto init__headvar__head_4_interrupt;
 init__headvar__head_4_ext_interrupt:
  reasonp = 0l;
 init__headvar__head_4_interrupt:
  goto interrupt_4;
 }

 init__headvar__head1_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 init__headvar__head1_5_clear_reason:
  reasonp = reasons;
 init__headvar__head1_5_0:
 init__headvar__head1_5_1:
  if (!isint(a1)) goto init__headvar__head1_5_3;
  gblt_greater(a1,makeint(0L),init__headvar__head1_5_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_converter_xinit__headvar__head1_5);
  allocp[2] = a0;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[9] = a1;
  allocp[10] = makeint(1L);
  allocp[11] = x0;
  allocp[12] = x2;
  allocp[13] = x4 = makeref(&allocp[13]);
  x3 = makecons(&allocp[12]);
  qp = (struct goalrec*)&allocp[7];
  allocp += 14;
  unify_value(a4, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = x5 = makeref(&allocp[2]);
  allocp[3] = a2;
  allocp[4] = makeint(1L);
  allocp[5] = x1;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[8] = x4;
  allocp[9] = makeint(1L);
  allocp[10] = x5;
  allocp[11] = makesym(functor_variable_3);
  allocp[12] = x4;
  allocp[13] = x7 = makeref(&allocp[13]);
  allocp[14] = x8 = makeref(&allocp[14]);
  x6 = makefunctor(&allocp[11]);
  allocp[15] = (q)(struct goalrec*)&allocp[6];
  allocp[16] = (q)(&predicate_functor__table_xarg_3);
  allocp[17] = a1;
  allocp[18] = a0;
  allocp[19] = x6;
  qp = (struct goalrec*)&allocp[15];
  allocp += 20;
  proceed();
 init__headvar__head1_5_2:
  if (a1 != makeint(0L)) goto init__headvar__head1_5_interrupt;
  unify(a3, a2);
  unify_value(a4, NILATOM);
  proceed();
 init__headvar__head1_5_3:
  if (!isref(a1)) goto init__headvar__head1_5_interrupt;
  deref_and_jump(a1,init__headvar__head1_5_1);
  *reasonp++ =  a1;
  goto init__headvar__head1_5_interrupt;
 init__headvar__head1_5_ext_interrupt:
  reasonp = 0l;
 init__headvar__head1_5_interrupt:
  toppred = &predicate_converter_xinit__headvar__head1_5;
  goto interrupt_5;
 }

 init__headvar__guard_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 init__headvar__guard_4_clear_reason:
  reasonp = reasons;
 init__headvar__guard_4_0:
 init__headvar__guard_4_1:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_converter_xinit__headvar__guard_4);
  allocp[2] = a0;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a3;
  x2 = car_of(a1);
  x3 = cdr_of(a1);
  a3 = x0;
  a4 = a2;
  a5 = x1;
  a2 = x3;
  a1 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(init__headvar__guard1_6_0);
  goto init__headvar__guard1_6_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto init__headvar__guard_4_interrupt;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a1,init__headvar__guard_4_1);
  *reasonp++ =  a1;
  goto init__headvar__guard_4_interrupt;
  };
  goto init__headvar__guard_4_interrupt;
 init__headvar__guard_4_ext_interrupt:
  reasonp = 0l;
 init__headvar__guard_4_interrupt:
  goto interrupt_4;
 }

 init__headvar__guard1_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 init__headvar__guard1_6_clear_reason:
  reasonp = reasons;
 init__headvar__guard1_6_0:
 init__headvar__guard1_6_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 init__headvar__guard1_6_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_functor_1)) goto init__headvar__guard1_6_17;
  x1 = arg(x0, 0);
 init__headvar__guard1_6_3:
  if (isref(x1)) goto init__headvar__guard1_6_16;
  gblt_pfunctor(x1,x2,init__headvar__guard1_6_17);
  if (x2 != makesym(atom__3D)) goto init__headvar__guard1_6_17;
  gblt_arity(x1,x3,init__headvar__guard1_6_17);
 init__headvar__guard1_6_4:
  if (x3 != makeint(2L)) goto init__headvar__guard1_6_17;
  gblt_arg(makeint(1L),x1,x4,init__headvar__guard1_6_17);
 init__headvar__guard1_6_5:
  switch (ptagof(x4)) {
 case FUNCTOR:
  if (functor_of(x4) != makesym(functor_variable_3)) goto init__headvar__guard1_6_10;
  x5 = arg(x4, 0);
 init__headvar__guard1_6_6:
  if (isref(x5)) goto init__headvar__guard1_6_9;
 init__headvar__guard1_6_7:
  if (isref(x5)) goto init__headvar__guard1_6_8;
  if_not_equal(x5, a1, init__headvar__guard1_6_10);
  gblt_arg(makeint(2L),x1,x6,init__headvar__guard1_6_10);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_converter_xinit__headvar__guard1_6);
  x7 = cdr_of(a0);
  allocp[2] = x7;
  allocp[3] = a1;
  allocp[4] = x8 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x9 = makeref(&allocp[6]);
  allocp[7] = a5;
  a0 = x6;
  a1 = a2;
  a2 = x8;
  a3 = a4;
  a4 = x9;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  execute(init__headvar__guard2_5_clear_reason);
  goto init__headvar__guard2_5_ext_interrupt;
 init__headvar__guard1_6_8:
  deref_and_jump(x5,init__headvar__guard1_6_7);
  *reasonp++ =  x5;
  goto init__headvar__guard1_6_10;
 init__headvar__guard1_6_9:
  deref_and_jump(x5,init__headvar__guard1_6_6);
  *reasonp++ =  x5;
  goto init__headvar__guard1_6_10;
 case VARREF:
  deref_and_jump(x4,init__headvar__guard1_6_5);
  *reasonp++ =  x4;
  goto init__headvar__guard1_6_10;
  };
  goto init__headvar__guard1_6_10;
 init__headvar__guard1_6_10:
  gblt_arg(makeint(2L),x1,x5,init__headvar__guard1_6_17);
 init__headvar__guard1_6_11:
  switch (ptagof(x5)) {
 case FUNCTOR:
  if (functor_of(x5) != makesym(functor_variable_3)) goto init__headvar__guard1_6_17;
  x6 = arg(x5, 0);
 init__headvar__guard1_6_12:
  if (isref(x6)) goto init__headvar__guard1_6_15;
 init__headvar__guard1_6_13:
  if (isref(x6)) goto init__headvar__guard1_6_14;
  if_not_equal(x6, a1, init__headvar__guard1_6_17);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_converter_xinit__headvar__guard1_6);
  x7 = cdr_of(a0);
  allocp[2] = x7;
  allocp[3] = a1;
  allocp[4] = x8 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x9 = makeref(&allocp[6]);
  allocp[7] = a5;
  a0 = x4;
  a1 = a2;
  a2 = x8;
  a3 = a4;
  a4 = x9;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  execute(init__headvar__guard2_5_clear_reason);
  goto init__headvar__guard2_5_ext_interrupt;
 init__headvar__guard1_6_14:
  deref_and_jump(x6,init__headvar__guard1_6_13);
  *reasonp++ =  x6;
  goto init__headvar__guard1_6_17;
 init__headvar__guard1_6_15:
  deref_and_jump(x6,init__headvar__guard1_6_12);
  *reasonp++ =  x6;
  goto init__headvar__guard1_6_17;
 case VARREF:
  deref_and_jump(x5,init__headvar__guard1_6_11);
  *reasonp++ =  x5;
  goto init__headvar__guard1_6_17;
  };
  goto init__headvar__guard1_6_17;
 init__headvar__guard1_6_16:
  deref_and_jump(x1,init__headvar__guard1_6_3);
  *reasonp++ =  x1;
  goto init__headvar__guard1_6_17;
 case VARREF:
  deref_and_jump(x0,init__headvar__guard1_6_2);
  *reasonp++ =  x0;
  goto init__headvar__guard1_6_17;
  };
  goto init__headvar__guard1_6_17;
 case VARREF:
  deref_and_jump(a0,init__headvar__guard1_6_1);
  *reasonp++ =  a0;
  goto init__headvar__guard1_6_17;
  };
  goto init__headvar__guard1_6_17;
 init__headvar__guard1_6_17:
  otherwise(init__headvar__guard1_6_interrupt);
 init__headvar__guard1_6_18:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 init__headvar__guard1_6_19:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_functor_1)) goto init__headvar__guard1_6_interrupt;
  a0 = cdr_of(a0);
  execute(init__headvar__guard1_6_0);
  goto init__headvar__guard1_6_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,init__headvar__guard1_6_19);
  *reasonp++ =  x0;
  goto init__headvar__guard1_6_interrupt;
  };
  goto init__headvar__guard1_6_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto init__headvar__guard1_6_interrupt;
  unify2(a3, a2, a5, a4);
  proceed();
 case VARREF:
  deref_and_jump(a0,init__headvar__guard1_6_18);
  *reasonp++ =  a0;
  goto init__headvar__guard1_6_interrupt;
  };
  goto init__headvar__guard1_6_interrupt;
 init__headvar__guard1_6_ext_interrupt:
  reasonp = 0l;
 init__headvar__guard1_6_interrupt:
  toppred = &predicate_converter_xinit__headvar__guard1_6;
  goto interrupt_6;
 }

 init__headvar__guard2_5_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 init__headvar__guard2_5_clear_reason:
  reasonp = reasons;
 init__headvar__guard2_5_0:
 init__headvar__guard2_5_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_variable_3:
  x0 = arg(a0, 0);
 init__headvar__guard2_5_2:
  if (!isint(x0)) goto init__headvar__guard2_5_7;
  gblt_add(x0,makeint(1L),x1,init__headvar__guard2_5_10);
 init__headvar__guard2_5_3:
  if (isref(a3)) goto init__headvar__guard2_5_6;
  gblt_arg(x1,a3,x2,init__headvar__guard2_5_10);
 init__headvar__guard2_5_4:
  switch (ptagof(x2)) {
 case ATOMIC:
 init__headvar__guard2_5_5:
  if (x2 != makeint(0L)) goto init__headvar__guard2_5_10;
  bblt_add_no_check(x0,makeint(1L),x3);
  allocp[0] = a1;
  allocp[1] = x0;
  x4 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = x3;
  allocp[3] = a3;
  allocp[4] = makeint(1L);
  allocp[5] = a4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  proceed();
 case VARREF:
  deref_and_jump(x2,init__headvar__guard2_5_4);
  *reasonp++ =  x2;
  goto init__headvar__guard2_5_10;
  };
  goto init__headvar__guard2_5_10;
 init__headvar__guard2_5_6:
  deref_and_jump(a3,init__headvar__guard2_5_3);
  *reasonp++ =  a3;
  goto init__headvar__guard2_5_10;
 init__headvar__guard2_5_7:
  if (!isref(x0)) goto init__headvar__guard2_5_10;
  deref_and_jump(x0,init__headvar__guard2_5_2);
  *reasonp++ =  x0;
  goto init__headvar__guard2_5_10;
 case functor_functor_1:
  x0 = arg(a0, 0);
 init__headvar__guard2_5_8:
  if (isref(x0)) goto init__headvar__guard2_5_9;
  gblt_pfunctor(x0,x1,init__headvar__guard2_5_10);
  gblt_arity(x0,x2,init__headvar__guard2_5_10);
  a0 = x2;
  x3 = a1;
  x4 = a2;
  x5 = a3;
  a5 = a4;
  a4 = x5;
  a3 = x4;
  a2 = x3;
  a1 = x0;
  execute(init__headvar__guard2__functor_6_0);
  goto init__headvar__guard2__functor_6_ext_interrupt;
 init__headvar__guard2_5_9:
  deref_and_jump(x0,init__headvar__guard2_5_8);
  *reasonp++ =  x0;
  goto init__headvar__guard2_5_10;
  };
  goto init__headvar__guard2_5_10;
 case VARREF:
  deref_and_jump(a0,init__headvar__guard2_5_1);
  *reasonp++ =  a0;
  goto init__headvar__guard2_5_10;
  };
  goto init__headvar__guard2_5_10;
 init__headvar__guard2_5_10:
  otherwise(init__headvar__guard2_5_interrupt);
  unify2(a2, a1, a4, a3);
  proceed();
 init__headvar__guard2_5_ext_interrupt:
  reasonp = 0l;
 init__headvar__guard2_5_interrupt:
  toppred = &predicate_converter_xinit__headvar__guard2_5;
  goto interrupt_5;
 }

 init__headvar__guard2__functor_6_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 init__headvar__guard2__functor_6_clear_reason:
  reasonp = reasons;
 init__headvar__guard2__functor_6_0:
 init__headvar__guard2__functor_6_1:
  if (!isint(a0)) goto init__headvar__guard2__functor_6_3;
  gblt_greater(a0,makeint(0L),init__headvar__guard2__functor_6_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_converter_xinit__headvar__guard2__functor_6);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[10] = a0;
  allocp[11] = makeint(1L);
  allocp[12] = x0;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_converter_xinit__headvar__guard2_5);
  allocp[15] = x3 = makeref(&allocp[15]);
  allocp[16] = a2;
  allocp[17] = x1;
  allocp[18] = a4;
  allocp[19] = x2;
  allocp[20] = (q)(struct goalrec*)&allocp[13];
  allocp[21] = (q)(&predicate_functor__table_xarg_3);
  allocp[22] = a0;
  allocp[23] = a1;
  allocp[24] = x3;
  qp = (struct goalrec*)&allocp[20];
  allocp += 25;
  proceed();
 init__headvar__guard2__functor_6_2:
  if (a0 != makeint(0L)) goto init__headvar__guard2__functor_6_interrupt;
  unify2(a3, a2, a5, a4);
  proceed();
 init__headvar__guard2__functor_6_3:
  if (!isref(a0)) goto init__headvar__guard2__functor_6_interrupt;
  deref_and_jump(a0,init__headvar__guard2__functor_6_1);
  *reasonp++ =  a0;
  goto init__headvar__guard2__functor_6_interrupt;
 init__headvar__guard2__functor_6_ext_interrupt:
  reasonp = 0l;
 init__headvar__guard2__functor_6_interrupt:
  toppred = &predicate_converter_xinit__headvar__guard2__functor_6;
  goto interrupt_6;
 }

 init__varcount_3_top: {
  q x0;
  a2 = qp->args[2];
  qp = qp->next;
 init__varcount_3_clear_reason:
  reasonp = reasons;
 init__varcount_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_converter_xinit__varcount1_3);
  allocp[2] = a1;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_uty_xnew__functor__init_4);
  allocp[7] = makesym(atom_varcount);
  allocp[8] = a0;
  allocp[9] = makeint(0L);
  allocp[10] = x0;
  qp = (struct goalrec*)&allocp[5];
  allocp += 11;
  proceed();
 init__varcount_3_ext_interrupt:
  reasonp = 0l;
 init__varcount_3_interrupt:
  goto interrupt_3;
 }

 init__varcount1_3_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  qp = qp->next;
 init__varcount1_3_clear_reason:
  reasonp = reasons;
 init__varcount1_3_0:
 init__varcount1_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
  bblt_add_no_check_y(x0,makeint(1L),x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_converter_xinit__varcount1_3);
  x2 = cdr_of(a0);
  allocp[2] = x2;
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[7] = x4 = makeref(&allocp[7]);
  allocp[8] = a1;
  allocp[9] = x5 = makeref(&allocp[9]);
  allocp[10] = x3;
  allocp[11] = (q)(struct goalrec*)&allocp[5];
  allocp[12] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[13] = x0;
  allocp[14] = makeint(1L);
  allocp[15] = x4;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[18] = x6 = makeref(&allocp[18]);
  allocp[19] = makeint(1L);
  allocp[20] = x5;
  allocp[21] = (q)(struct goalrec*)&allocp[16];
  allocp[22] = (q)(&predicate_functor__table_xarg_3);
  allocp[23] = x1;
  allocp[24] = a1;
  allocp[25] = x6;
  qp = (struct goalrec*)&allocp[21];
  allocp += 26;
  proceed();
 case ATOMIC:
  if (a0 != NILATOM) goto init__varcount1_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,init__varcount1_3_1);
  *reasonp++ =  a0;
  goto init__varcount1_3_interrupt;
  };
  goto init__varcount1_3_interrupt;
 init__varcount1_3_ext_interrupt:
  reasonp = 0l;
 init__varcount1_3_interrupt:
  goto interrupt_3;
 }

 from__analyze_2_top: {
  qp = qp->next;
 from__analyze_2_clear_reason:
  reasonp = reasons;
 from__analyze_2_0:
  execute(from__analyze__modules_2_0);
  goto from__analyze__modules_2_ext_interrupt;
 from__analyze_2_ext_interrupt:
  reasonp = 0l;
 from__analyze_2_interrupt:
  goto interrupt_2;
 }

 from__analyze__modules_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  qp = qp->next;
 from__analyze__modules_2_clear_reason:
  reasonp = reasons;
 from__analyze__modules_2_0:
 from__analyze__modules_2_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = makesym(functor_module_2);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  x0 = makefunctor(&allocp[0]);
  x3 = car_of(a0);
  allocp += 3;
  unify_value(x3, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_converter_xfrom__analyze__modules_2);
  x4 = cdr_of(a0);
  allocp[2] = x4;
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = makesym(functor_module_2);
  allocp[5] = x1;
  allocp[6] = x7 = makeref(&allocp[6]);
  x6 = makefunctor(&allocp[4]);
  allocp[7] = x5;
  allocp[8] = x6;
  x8 = makecons(&allocp[7]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 9;
  unify_value(a1, x8);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_converter_xfrom__analyze__clauses_4);
  allocp[2] = makeint(1L);
  allocp[3] = x9 = makeref(&allocp[3]);
  allocp[4] = x2;
  allocp[5] = x7;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[8] = x2;
  allocp[9] = x10 = makeref(&allocp[9]);
  allocp[10] = x9;
  qp = (struct goalrec*)&allocp[6];
  allocp += 11;
  proceed();
 case ATOMIC:
  if (a0 != NILATOM) goto from__analyze__modules_2_interrupt;
  unify_value(a1, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a0,from__analyze__modules_2_1);
  *reasonp++ =  a0;
  goto from__analyze__modules_2_interrupt;
  };
  goto from__analyze__modules_2_interrupt;
 from__analyze__modules_2_ext_interrupt:
  reasonp = 0l;
 from__analyze__modules_2_interrupt:
  toppred = &predicate_converter_xfrom__analyze__modules_2;
  goto interrupt_2;
 }

 from__analyze__clauses_4_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 from__analyze__clauses_4_clear_reason:
  reasonp = reasons;
 from__analyze__clauses_4_0:
 from__analyze__clauses_4_1:
  if (!isint(a0)) goto from__analyze__clauses_4_7;
 from__analyze__clauses_4_2:
  if (!isint(a1)) goto from__analyze__clauses_4_6;
  gblt_less_or_eq(a0,a1,from__analyze__clauses_4_5);
 from__analyze__clauses_4_3:
  if (isref(a2)) goto from__analyze__clauses_4_4;
  gblt_arg(a0,a2,x0,from__analyze__clauses_4_5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_converter_xfrom__analyze__clauses_4);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x1;
  allocp[11] = x2;
  allocp[12] = x4 = makeref(&allocp[12]);
  x3 = makecons(&allocp[11]);
  qp = (struct goalrec*)&allocp[6];
  allocp += 13;
  unify_value(a3, x3);
  a0 = x0;
  a1 = x4;
  execute(from__analyze__clause_2_0);
  goto from__analyze__clause_2_ext_interrupt;
 from__analyze__clauses_4_4:
  deref_and_jump(a2,from__analyze__clauses_4_3);
  *reasonp++ =  a2;
  goto from__analyze__clauses_4_5;
 from__analyze__clauses_4_5:
  gblt_greater(a0,a1,from__analyze__clauses_4_interrupt);
  unify_value(a3, NILATOM);
  proceed();
 from__analyze__clauses_4_6:
  if (!isref(a1)) goto from__analyze__clauses_4_interrupt;
  deref_and_jump(a1,from__analyze__clauses_4_2);
  *reasonp++ =  a1;
  goto from__analyze__clauses_4_interrupt;
 from__analyze__clauses_4_7:
  if (!isref(a0)) goto from__analyze__clauses_4_interrupt;
  deref_and_jump(a0,from__analyze__clauses_4_1);
  *reasonp++ =  a0;
  goto from__analyze__clauses_4_interrupt;
 from__analyze__clauses_4_ext_interrupt:
  reasonp = 0l;
 from__analyze__clauses_4_interrupt:
  goto interrupt_4;
 }

 from__analyze__clause_2_top: {
  q x0, x1, x2, x3, x4, x5;
  qp = qp->next;
 from__analyze__clause_2_clear_reason:
  reasonp = reasons;
 from__analyze__clause_2_0:
 from__analyze__clause_2_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto from__analyze__clause_2_interrupt;
 from__analyze__clause_2_2:
  gblt_atom(a0,from__analyze__clause_2_interrupt);
  unify_value(a1, a0);
  proceed();
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_clause_6)) goto from__analyze__clause_2_interrupt;
  allocp[0] = makesym(functor_clause_4);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = arg(a0, 3);
  x0 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_converter_xfrom__analyze__goals_3);
  allocp[2] = makesym(atom_body);
  x4 = arg(a0, 2);
  allocp[3] = x4;
  allocp[4] = x3;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_converter_xfrom__analyze__goals_3);
  allocp[7] = makesym(atom_guard);
  x5 = arg(a0, 1);
  allocp[8] = x5;
  allocp[9] = x2;
  a1 = arg(a0, 0);
  a2 = x1;
  a0 = makesym(atom_head);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  execute(from__analyze__goal_3_0);
  goto from__analyze__goal_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,from__analyze__clause_2_1);
  *reasonp++ =  a0;
  goto from__analyze__clause_2_interrupt;
  };
  goto from__analyze__clause_2_interrupt;
 from__analyze__clause_2_ext_interrupt:
  reasonp = 0l;
 from__analyze__clause_2_interrupt:
  toppred = &predicate_converter_xfrom__analyze__clause_2;
  goto interrupt_2;
 }

 from__analyze__goals_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 from__analyze__goals_3_clear_reason:
  reasonp = reasons;
 from__analyze__goals_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_converter_xfrom__analyze__goals1_5);
  allocp[2] = makeint(1L);
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a0;
  allocp[5] = a1;
  allocp[6] = a2;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[9] = a1;
  allocp[10] = x1 = makeref(&allocp[10]);
  allocp[11] = x0;
  qp = (struct goalrec*)&allocp[7];
  allocp += 12;
  proceed();
 from__analyze__goals_3_ext_interrupt:
  reasonp = 0l;
 from__analyze__goals_3_interrupt:
  goto interrupt_3;
 }

 from__analyze__goals1_5_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 from__analyze__goals1_5_clear_reason:
  reasonp = reasons;
 from__analyze__goals1_5_0:
 from__analyze__goals1_5_1:
  if (!isint(a0)) goto from__analyze__goals1_5_5;
 from__analyze__goals1_5_2:
  if (!isint(a1)) goto from__analyze__goals1_5_4;
  gblt_less_or_eq(a0,a1,from__analyze__goals1_5_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_converter_xfrom__analyze__goals1_5);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[9] = a0;
  allocp[10] = makeint(1L);
  allocp[11] = x0;
  allocp[12] = x1;
  allocp[13] = x3 = makeref(&allocp[13]);
  x2 = makecons(&allocp[12]);
  qp = (struct goalrec*)&allocp[7];
  allocp += 14;
  unify_value(a4, x2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_converter_xfrom__analyze__goal_3);
  allocp[2] = a2;
  allocp[3] = x4 = makeref(&allocp[3]);
  allocp[4] = x3;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = a0;
  allocp[8] = a3;
  allocp[9] = x4;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 from__analyze__goals1_5_3:
  gblt_greater(a0,a1,from__analyze__goals1_5_interrupt);
  unify_value(a4, NILATOM);
  proceed();
 from__analyze__goals1_5_4:
  if (!isref(a1)) goto from__analyze__goals1_5_interrupt;
  deref_and_jump(a1,from__analyze__goals1_5_2);
  *reasonp++ =  a1;
  goto from__analyze__goals1_5_interrupt;
 from__analyze__goals1_5_5:
  if (!isref(a0)) goto from__analyze__goals1_5_interrupt;
  deref_and_jump(a0,from__analyze__goals1_5_1);
  *reasonp++ =  a0;
  goto from__analyze__goals1_5_interrupt;
 from__analyze__goals1_5_ext_interrupt:
  reasonp = 0l;
 from__analyze__goals1_5_interrupt:
  goto interrupt_5;
 }

 from__analyze__goal_3_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  qp = qp->next;
 from__analyze__goal_3_clear_reason:
  reasonp = reasons;
 from__analyze__goal_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_converter_xfrom__analyze__goal__modulename_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a2;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_converter_xfrom__analyze__functor_3);
  allocp[8] = a0;
  allocp[9] = x3 = makeref(&allocp[9]);
  allocp[10] = x0;
  allocp[11] = makesym(functor_options_2);
  allocp[12] = x1;
  allocp[13] = x2;
  x4 = makefunctor(&allocp[11]);
  allocp[14] = (q)(struct goalrec*)&allocp[6];
  allocp[15] = (q)(&predicate_parse__uty_xdecode__goal_4);
  allocp[16] = a1;
  allocp[17] = x3;
  allocp[18] = x5 = makeref(&allocp[18]);
  allocp[19] = x4;
  qp = (struct goalrec*)&allocp[14];
  allocp += 20;
  proceed();
 from__analyze__goal_3_ext_interrupt:
  reasonp = 0l;
 from__analyze__goal_3_interrupt:
  toppred = &predicate_converter_xfrom__analyze__goal_3;
  goto interrupt_3;
 }

 from__analyze__functor_3_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  qp = qp->next;
 from__analyze__functor_3_clear_reason:
  reasonp = reasons;
 from__analyze__functor_3_0:
 from__analyze__functor_3_1:
  switch (ptagof(a1)) {
 case ATOMIC:
 from__analyze__functor_3_2:
  gblt_atomic(a1,from__analyze__functor_3_3);
  unify_value(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a1,from__analyze__functor_3_1);
  *reasonp++ =  a1;
  goto from__analyze__functor_3_3;
  };
  goto from__analyze__functor_3_3;
 from__analyze__functor_3_3:
  otherwise(from__analyze__functor_3_interrupt);
 from__analyze__functor_3_4:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_body)) goto from__analyze__functor_3_6;
 from__analyze__functor_3_5:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_variable_3)) goto from__analyze__functor_3_6;
  allocp[0] = makesym(functor_variable_2);
  allocp[1] = arg(a1, 0);
  allocp[2] = arg(a1, 2);
  x0 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,from__analyze__functor_3_5);
  *reasonp++ =  a1;
  goto from__analyze__functor_3_6;
  };
  goto from__analyze__functor_3_6;
 case VARREF:
  deref_and_jump(a0,from__analyze__functor_3_4);
  *reasonp++ =  a0;
  goto from__analyze__functor_3_6;
  };
  goto from__analyze__functor_3_6;
 from__analyze__functor_3_6:
  otherwise(from__analyze__functor_3_interrupt);
 from__analyze__functor_3_7:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_variable_3)) goto from__analyze__functor_3_8;
  allocp[0] = makesym(functor_variable_1);
  allocp[1] = arg(a1, 0);
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,from__analyze__functor_3_7);
  *reasonp++ =  a1;
  goto from__analyze__functor_3_8;
  };
  goto from__analyze__functor_3_8;
 from__analyze__functor_3_8:
  otherwise(from__analyze__functor_3_interrupt);
 from__analyze__functor_3_9:
  if (isref(a1)) goto from__analyze__functor_3_10;
  gblt_pfunctor(a1,x0,from__analyze__functor_3_interrupt);
  gblt_arity(a1,x1,from__analyze__functor_3_interrupt);
  x2 = a1;
  a3 = a2;
  a2 = x2;
  a1 = x1;
  execute(from__analyze__args_4_0);
  goto from__analyze__args_4_ext_interrupt;
 from__analyze__functor_3_10:
  deref_and_jump(a1,from__analyze__functor_3_9);
  *reasonp++ =  a1;
  goto from__analyze__functor_3_interrupt;
 from__analyze__functor_3_ext_interrupt:
  reasonp = 0l;
 from__analyze__functor_3_interrupt:
  goto interrupt_3;
 }

 from__analyze__args_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 from__analyze__args_4_clear_reason:
  reasonp = reasons;
 from__analyze__args_4_0:
 from__analyze__args_4_1:
  if (!isint(a1)) goto from__analyze__args_4_3;
  gblt_greater(a1,makeint(0L),from__analyze__args_4_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_converter_xfrom__analyze__args_4);
  allocp[2] = a0;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a1;
  allocp[9] = makeint(1L);
  allocp[10] = x0;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[13] = a1;
  allocp[14] = a2;
  allocp[15] = x2 = makeref(&allocp[15]);
  allocp[16] = x1;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_converter_xfrom__analyze__functor_3);
  allocp[19] = a0;
  allocp[20] = x3 = makeref(&allocp[20]);
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[17];
  allocp[23] = (q)(&predicate_functor__table_xarg_3);
  allocp[24] = a1;
  allocp[25] = a2;
  allocp[26] = x3;
  qp = (struct goalrec*)&allocp[22];
  allocp += 27;
  proceed();
 from__analyze__args_4_2:
  if (a1 != makeint(0L)) goto from__analyze__args_4_interrupt;
  unify(a3, a2);
  proceed();
 from__analyze__args_4_3:
  if (!isref(a1)) goto from__analyze__args_4_interrupt;
  deref_and_jump(a1,from__analyze__args_4_1);
  *reasonp++ =  a1;
  goto from__analyze__args_4_interrupt;
 from__analyze__args_4_ext_interrupt:
  reasonp = 0l;
 from__analyze__args_4_interrupt:
  toppred = &predicate_converter_xfrom__analyze__args_4;
  goto interrupt_4;
 }

 from__analyze__goal__modulename_4_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 from__analyze__goal__modulename_4_clear_reason:
  reasonp = reasons;
 from__analyze__goal__modulename_4_0:
 from__analyze__goal__modulename_4_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom___)) goto from__analyze__goal__modulename_4_5;
 from__analyze__goal__modulename_4_2:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto from__analyze__goal__modulename_4_4;
 from__analyze__goal__modulename_4_3:
  gblt_atom(a0,from__analyze__goal__modulename_4_4);
  allocp[0] = makesym(functor_functor_1);
  allocp[1] = a0;
  x0 = makefunctor(&allocp[0]);
  a0 = x0;
  a1 = a2;
  a2 = a3;
  allocp += 2;
  execute(from__analyze__goal__pragma_3_0);
  goto from__analyze__goal__pragma_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,from__analyze__goal__modulename_4_2);
  *reasonp++ =  a0;
  goto from__analyze__goal__modulename_4_5;
  };
  goto from__analyze__goal__modulename_4_4;
 from__analyze__goal__modulename_4_4:
  gblt_pfunctor(a0,x0,from__analyze__goal__modulename_4_5);
  gblt_arity(a0,x1,from__analyze__goal__modulename_4_5);
  allocp[0] = makesym(functor_functor_1);
  allocp[1] = a0;
  x2 = makefunctor(&allocp[0]);
  a0 = x2;
  a1 = a2;
  a2 = a3;
  allocp += 2;
  execute(from__analyze__goal__pragma_3_0);
  goto from__analyze__goal__pragma_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,from__analyze__goal__modulename_4_1);
  *reasonp++ =  a1;
  goto from__analyze__goal__modulename_4_5;
  };
  goto from__analyze__goal__modulename_4_5;
 from__analyze__goal__modulename_4_5:
  otherwise(from__analyze__goal__modulename_4_interrupt);
 from__analyze__goal__modulename_4_6:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto from__analyze__goal__modulename_4_8;
 from__analyze__goal__modulename_4_7:
  gblt_atom(a0,from__analyze__goal__modulename_4_8);
  allocp[0] = makesym(functor_atom_1);
  allocp[1] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_functor_1);
  allocp[3] = a0;
  x1 = makefunctor(&allocp[2]);
  allocp[4] = makesym(functor__3A_2);
  allocp[5] = x0;
  allocp[6] = x1;
  x2 = makefunctor(&allocp[4]);
  allocp[7] = makesym(functor_functor_1);
  allocp[8] = x2;
  x3 = makefunctor(&allocp[7]);
  a0 = x3;
  a1 = a2;
  a2 = a3;
  allocp += 9;
  execute(from__analyze__goal__pragma_3_0);
  goto from__analyze__goal__pragma_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,from__analyze__goal__modulename_4_6);
  *reasonp++ =  a0;
  goto from__analyze__goal__modulename_4_interrupt;
  };
  goto from__analyze__goal__modulename_4_8;
 from__analyze__goal__modulename_4_8:
  gblt_pfunctor(a0,x0,from__analyze__goal__modulename_4_interrupt);
  gblt_arity(a0,x1,from__analyze__goal__modulename_4_interrupt);
  allocp[0] = makesym(functor_atom_1);
  allocp[1] = a1;
  x2 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_functor_1);
  allocp[3] = a0;
  x3 = makefunctor(&allocp[2]);
  allocp[4] = makesym(functor__3A_2);
  allocp[5] = x2;
  allocp[6] = x3;
  x4 = makefunctor(&allocp[4]);
  allocp[7] = makesym(functor_functor_1);
  allocp[8] = x4;
  x5 = makefunctor(&allocp[7]);
  a0 = x5;
  a1 = a2;
  a2 = a3;
  allocp += 9;
  execute(from__analyze__goal__pragma_3_0);
  goto from__analyze__goal__pragma_3_ext_interrupt;
 from__analyze__goal__modulename_4_ext_interrupt:
  reasonp = 0l;
 from__analyze__goal__modulename_4_interrupt:
  goto interrupt_4;
 }

 from__analyze__goal__pragma_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 from__analyze__goal__pragma_3_clear_reason:
  reasonp = reasons;
 from__analyze__goal__pragma_3_0:
 from__analyze__goal__pragma_3_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom___)) goto from__analyze__goal__pragma_3_3;
  unify(a2, a0);
  proceed();
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_atom_1)) goto from__analyze__goal__pragma_3_3;
  x0 = arg(a1, 0);
 from__analyze__goal__pragma_3_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_shared)) goto from__analyze__goal__pragma_3_3;
  unify(a2, a0);
  proceed();
 case VARREF:
  deref_and_jump(x0,from__analyze__goal__pragma_3_2);
  *reasonp++ =  x0;
  goto from__analyze__goal__pragma_3_3;
  };
  goto from__analyze__goal__pragma_3_3;
 case VARREF:
  deref_and_jump(a1,from__analyze__goal__pragma_3_1);
  *reasonp++ =  a1;
  goto from__analyze__goal__pragma_3_3;
  };
  goto from__analyze__goal__pragma_3_3;
 from__analyze__goal__pragma_3_3:
  otherwise(from__analyze__goal__pragma_3_interrupt);
  allocp[0] = makesym(functor__40_2);
  allocp[1] = a0;
  allocp[2] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_functor_1);
  allocp[4] = x0;
  x1 = makefunctor(&allocp[3]);
  allocp += 5;
  unify_value(a2, x1);
  proceed();
 from__analyze__goal__pragma_3_ext_interrupt:
  reasonp = 0l;
 from__analyze__goal__pragma_3_interrupt:
  toppred = &predicate_converter_xfrom__analyze__goal__pragma_3;
  goto interrupt_3;
 }
 interrupt_9:
  allocp[10] = a8;
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_converter);
}
