/* ----------------------------------------------------------
%        Copyright (C) 1996-1997 Kazuhiko Ohno, Masahiko Ikawa,
%        and Computer Architecture Laboratory, Depertment of
%        Information Science, Kyoto University.
%----------------------------------------------------------- */  

extern struct predicate predicate_main_xmain_0;
extern struct predicate predicate_main_xp0_4;
extern struct predicate predicate_main_xp1_4;
extern struct predicate predicate_main_xp2_4;
extern struct predicate predicate_main_xcheck__and__send_4;
extern struct predicate predicate_main_xprint__list_6;
extern struct predicate predicate_io_xoutstream_1;
extern struct predicate predicate_main_xresume__check_0;

#define print_predicates() \
{ \
		puts("aho"); \
}
/*
	printf("main_xmain_0 %x\n",&predicate_main_xmain_0); \
	printf("main_xp0_2 %x\n",&predicate_main_xp0_2); \
	printf("main_xdec0_2 %x\n",&predicate_main_xdec0_2); \
	printf("main_xsend0_3 %x\n",&predicate_main_xsend0_3); \
	printf("main_xp1_2 %x\n",&predicate_main_xp1_2); \
	printf("main_xdec1_2 %x\n",&predicate_main_xdec1_2); \
	printf("main_xsend1_3 %x\n",&predicate_main_xsend1_3); \
*/

#define print_predicate_name(pred) \
{ \
	if(pred == &predicate_main_xmain_0) \
		printf("predicate_main_xmain_0\n"); \
	else if(pred == &predicate_main_xp0_4) \
		printf("predicate_main_xp0_4\n"); \
	else if(pred == &predicate_main_xp1_4) \
		printf("predicate_main_xp1_4\n"); \
	else if(pred == &predicate_main_xp2_4) \
		printf("predicate_main_xp2_4\n"); \
	else if(pred == &predicate_main_xcheck__and__send_4) \
		printf("predicate_main_xcheck__and__send_4\n"); \
	else if(pred == &predicate_main_xprint__list_6) \
		printf("predicate_main_xprint__list_6\n"); \
	else if(pred == &predicate_io_xoutstream_1) \
		printf("predicate_io_xoutstream_1\n"); \
	else if(pred == &predicate_main_xresume__check_0) \
		printf("predicate_main_xresume__check_0\n"); \
	else \
		printf("builtin_predicate %x\n",pred); \
}
