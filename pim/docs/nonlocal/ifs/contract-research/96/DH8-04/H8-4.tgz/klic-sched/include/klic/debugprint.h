/* ----------------------------------------------------------
%        Copyright (C) 1996-1997 Kazuhiko Ohno, Masahiko Ikawa,
%        and Computer Architecture Laboratory, Depertment of
%        Information Science, Kyoto University.
%----------------------------------------------------------- */  

extern void print_qp();
extern void print_queue();
extern void print_thread();
extern void reset_thread_name_rec();
void set_thread_name_rec();
void print_thread_name();
void print_susprec();
extern char* sprint_qp();




