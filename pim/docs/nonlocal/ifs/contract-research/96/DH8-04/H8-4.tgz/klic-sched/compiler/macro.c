/* Compiled by KLIC compiler version 2.002 (Tue May 23 13:27:38 JST 1995) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_klic__comp__macro();
Const struct predicate predicate_klic__comp__macro_xmacro_2 =
   { module_klic__comp__macro, 0, 2 };
Const struct predicate predicate_klic__comp__macro_xmacro__1_3 =
   { module_klic__comp__macro, 1, 3 };
Const struct predicate predicate_klic__comp__macro_xexp__one__clause_4 =
   { module_klic__comp__macro, 2, 4 };
Const struct predicate predicate_klic__comp__macro_xdlclause_9 =
   { module_klic__comp__macro, 3, 9 };
Const struct predicate predicate_klic__comp__macro_xdlclause__1_9 =
   { module_klic__comp__macro, 4, 9 };
Const struct predicate predicate_klic__comp__macro_xinitialize__info_7 =
   { module_klic__comp__macro, 5, 7 };
Const struct predicate predicate_klic__comp__macro_xinitialize__info__1_10 =
   { module_klic__comp__macro, 6, 10 };
Const struct predicate predicate_klic__comp__macro_xdlgoals_7 =
   { module_klic__comp__macro, 7, 7 };
Const struct predicate predicate_klic__comp__macro_xdlor_8 =
   { module_klic__comp__macro, 8, 8 };
Const struct predicate predicate_klic__comp__macro_xmerge__vinfo_5 =
   { module_klic__comp__macro, 9, 5 };
Const struct predicate predicate_klic__comp__macro_xdlgoal_7 =
   { module_klic__comp__macro, 10, 7 };
Const struct predicate predicate_klic__comp__macro_xdl__compute_9 =
   { module_klic__comp__macro, 11, 9 };
Const struct predicate predicate_klic__comp__macro_xdl__update_12 =
   { module_klic__comp__macro, 12, 12 };
Const struct predicate predicate_klic__comp__macro_xdl__common_9 =
   { module_klic__comp__macro, 13, 9 };
Const struct predicate predicate_klic__comp__macro_xdlgoal__atom_3 =
   { module_klic__comp__macro, 14, 3 };
Const struct predicate predicate_klic__comp__macro_xdlappend__args_3 =
   { module_klic__comp__macro, 15, 3 };
Const struct predicate predicate_klic__comp__macro_xdlappend__args_2F3_240_4 =
   { module_klic__comp__macro, 16, 4 };
Const struct predicate predicate_klic__comp__macro_xupdate__info_6 =
   { module_klic__comp__macro, 17, 6 };
Const struct predicate predicate_klic__comp__macro_xupdate__info__1_9 =
   { module_klic__comp__macro, 18, 9 };
Const struct predicate predicate_klic__comp__macro_xreplace__vars_3 =
   { module_klic__comp__macro, 19, 3 };
Const struct predicate predicate_klic__comp__macro_xreplace__vars__1_3 =
   { module_klic__comp__macro, 20, 3 };
Const struct predicate predicate_klic__comp__macro_xreplace__vars__elems_3 =
   { module_klic__comp__macro, 21, 3 };
Const struct predicate predicate_klic__comp__macro_xcountvars_2 =
   { module_klic__comp__macro, 22, 2 };
Const struct predicate predicate_klic__comp__macro_xcountvars_3 =
   { module_klic__comp__macro, 23, 3 };
Const struct predicate predicate_klic__comp__macro_xfindvars_3 =
   { module_klic__comp__macro, 24, 3 };
Const struct predicate predicate_klic__comp__macro_xfindvars__elems_3 =
   { module_klic__comp__macro, 25, 3 };
Const struct predicate predicate_klic__comp__macro_xcountsame_5 =
   { module_klic__comp__macro, 26, 5 };
Const struct predicate predicate_klic__comp__macro_xfinalize__vars_4 =
   { module_klic__comp__macro, 27, 4 };
Const struct predicate predicate_klic__comp__macro_xexp__head_6 =
   { module_klic__comp__macro, 28, 6 };
Const struct predicate predicate_klic__comp__macro_xexp__head__and__guard__top_6 =
   { module_klic__comp__macro, 29, 6 };
Const struct predicate predicate_klic__comp__macro_xlinearize__guard_3 =
   { module_klic__comp__macro, 30, 3 };
Const struct predicate predicate_klic__comp__macro_xexp__guard_5 =
   { module_klic__comp__macro, 31, 5 };
Const struct predicate predicate_klic__comp__macro_xexp__body_8 =
   { module_klic__comp__macro, 32, 8 };
Const struct predicate predicate_klic__comp__macro_xexp__body__or_6 =
   { module_klic__comp__macro, 33, 6 };
Const struct predicate predicate_klic__comp__macro_xfind__interface__vars_3 =
   { module_klic__comp__macro, 34, 3 };
Const struct predicate predicate_klic__comp__macro_xfind__interface__vars__1_6 =
   { module_klic__comp__macro, 35, 6 };
Const struct predicate predicate_klic__comp__macro_xbody__or__clauses_6 =
   { module_klic__comp__macro, 36, 6 };
Const struct predicate predicate_klic__comp__macro_xbody__or__one_6 =
   { module_klic__comp__macro, 37, 6 };
Const struct predicate predicate_klic__comp__macro_xmacro__goal_8 =
   { module_klic__comp__macro, 38, 8 };
Const struct predicate predicate_klic__comp__macro_xmacro__goal__functor_8 =
   { module_klic__comp__macro, 39, 8 };
Const struct predicate predicate_klic__comp__macro_xmacro__goal__functor__cmp_9 =
   { module_klic__comp__macro, 40, 9 };
Const struct predicate predicate_klic__comp__macro_xmake__expanded__call_2 =
   { module_klic__comp__macro, 41, 2 };
Const struct predicate predicate_klic__comp__macro_xexpand__goal_3 =
   { module_klic__comp__macro, 42, 3 };
Const struct predicate predicate_klic__comp__macro_xcompar__macro_2 =
   { module_klic__comp__macro, 43, 2 };
Const struct predicate predicate_klic__comp__macro_xmacro__args_9 =
   { module_klic__comp__macro, 44, 9 };
Const struct predicate predicate_klic__comp__macro_xmacro__arg_9 =
   { module_klic__comp__macro, 45, 9 };
Const struct predicate predicate_klic__comp__macro_xmacro__arg__n_8 =
   { module_klic__comp__macro, 46, 8 };
Const struct predicate predicate_klic__comp__macro_xmacro__vector__elems_10 =
   { module_klic__comp__macro, 47, 10 };
Const struct predicate predicate_klic__comp__macro_xmacro__vec__elems_8 =
   { module_klic__comp__macro, 48, 8 };
Const struct predicate predicate_klic__comp__macro_xmacro__arg__functor_9 =
   { module_klic__comp__macro, 49, 9 };
Const struct predicate predicate_klic__comp__macro_xmacro__arg__functor__sharp_10 =
   { module_klic__comp__macro, 50, 10 };
Const struct predicate predicate_klic__comp__macro_xmacro__N__10_4 =
   { module_klic__comp__macro, 51, 4 };
Const struct predicate predicate_klic__comp__macro_xmacro__exp_6 =
   { module_klic__comp__macro, 52, 6 };
Const struct predicate predicate_klic__comp__macro_xmacro__arith__op_2 =
   { module_klic__comp__macro, 53, 2 };
Const struct predicate predicate_klic__comp__macro_xmacro__exp__1_7 =
   { module_klic__comp__macro, 54, 7 };
Const struct predicate predicate_klic__comp__macro_xmacro__exp__args_7 =
   { module_klic__comp__macro, 55, 7 };
Const struct predicate predicate_klic__comp__macro_xmacro__float__exp_6 =
   { module_klic__comp__macro, 56, 6 };
Const struct predicate predicate_klic__comp__macro_xmacro__float__op_2 =
   { module_klic__comp__macro, 57, 2 };
Const struct predicate predicate_klic__comp__macro_xmacro__float__exp__1_7 =
   { module_klic__comp__macro, 58, 7 };
Const struct predicate predicate_klic__comp__macro_xmacro__float__args_7 =
   { module_klic__comp__macro, 59, 7 };
extern q vector_g_new();
extern Const struct predicate predicate_integer__arithmetics_xadd_3;
extern Const struct predicate predicate_functor__table_x_3D_2E_2E_2;
extern Const struct predicate predicate_klic__comp__util_xnumbervars_4;
extern Const struct predicate predicate_klic__comp__util_xuniv_2;
extern Const struct predicate predicate_klic__comp__util_xuniv_3;
extern Const struct predicate predicate_klic__comp__util_xassoc_3;
extern Const struct predicate predicate_klic__comp__util_xlength_2;
extern Const struct predicate predicate_klic__comp__util_xvector__to__list_2;
extern Const struct predicate predicate_klic__comp__util_xstring__to__char__list_2;
extern Const struct predicate predicate_klic__comp__kl1cmp_xreport__error_2;
extern Const struct predicate predicate_klic__comp__kl1cmp_xwarning_2;
declare_method_table_of(vector);

module module_klic__comp__macro(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  static Const unsigned char strconst_body_0[16] =
    {'I','l','l','e','g','a','l',' ','G','o','a','l',':',' ','~','w',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_0 =
      declare_string_constant_8(strconst_body_0,16);
  static Const unsigned char strconst_body_1[24] =
    {'I','l','l','e','g','a','l',' ','b','o','d','y',' ','o','r',' ','c','a','s','e',':',' ','~','w',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_1 =
      declare_string_constant_8(strconst_body_1,24);
  static Const unsigned char strconst_body_2[16] =
    {'I','l','l','e','g','a','l',' ','h','e','a','d',':',' ','~','w',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_2 =
      declare_string_constant_8(strconst_body_2,16);
  static Const unsigned char strconst_body_3[32] =
    "Unknown term in expression: ~w";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_3 =
      declare_string_constant_8(strconst_body_3,30);
  static Const unsigned char strconst_body_4[48] =
    "Unknown term in floating point expression: ~w";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_4 =
      declare_string_constant_8(strconst_body_4,45);
  static Const q funct_const_5[] = {
    makesym(functor_integer_1),
    makeint(0),
  };
  static Const q cons_const_6[] = {
    NILATOM,
    makefunctor(funct_const_5),
  };
  static Const q funct_const_7[] = {
    makesym(functor_integer_1),
    makeint(10),
  };
  static Const q funct_const_8[] = {
    makesym(functor_integer_1),
    makeint(13),
  };
  static Const q funct_const_9[] = {
    makesym(functor_atom_1),
    makesym(atom_vector),
  };
  static Const q funct_const_10[] = {
    makesym(functor_atom_1),
    makesym(atom_string),
  };
  static Const q funct_const_11[] = {
    makesym(functor_atom_1),
    makesym(atom_float),
  };
  static Const q funct_const_12[] = {
    makesym(functor_atom_1),
    makesym(atom_module),
  };
  static Const q funct_const_13[] = {
    makesym(functor_atom_1),
    makesym(atom_generic),
  };
  static Const q funct_const_14[] = {
    makesym(functor_atom_1),
    makesym(atom_true),
  };
  static Const q funct_const_15[] = {
    makesym(functor_atom_1),
    makesym(atom_merge),
  };
  static Const q funct_const_16[] = {
    makesym(functor_yes_1),
    makesym(atom_sin),
  };
  static Const q funct_const_17[] = {
    makesym(functor_yes_1),
    makesym(atom_cos),
  };
  static Const q funct_const_18[] = {
    makesym(functor_yes_1),
    makesym(atom_tan),
  };
  static Const q funct_const_19[] = {
    makesym(functor_yes_1),
    makesym(atom_asin),
  };
  static Const q funct_const_20[] = {
    makesym(functor_yes_1),
    makesym(atom_acos),
  };
  static Const q funct_const_21[] = {
    makesym(functor_yes_1),
    makesym(atom_atan),
  };
  static Const q funct_const_22[] = {
    makesym(functor_yes_1),
    makesym(atom_sinh),
  };
  static Const q funct_const_23[] = {
    makesym(functor_yes_1),
    makesym(atom_cosh),
  };
  static Const q funct_const_24[] = {
    makesym(functor_yes_1),
    makesym(atom_tanh),
  };
  static Const q funct_const_25[] = {
    makesym(functor_yes_1),
    makesym(atom_exp),
  };
  static Const q funct_const_26[] = {
    makesym(functor_yes_1),
    makesym(atom_log),
  };
  static Const q funct_const_27[] = {
    makesym(functor_yes_1),
    makesym(atom_sqrt),
  };
  static Const q funct_const_28[] = {
    makesym(functor_yes_1),
    makesym(atom_ceil),
  };
  static Const q funct_const_29[] = {
    makesym(functor_yes_1),
    makesym(atom_floor),
  };
  static Const q funct_const_30[] = {
    makesym(functor_yes_1),
    makesym(atom_add),
  };
  static Const q funct_const_31[] = {
    makesym(functor_yes_1),
    makesym(atom_subtract),
  };
  static Const q funct_const_32[] = {
    makesym(functor_yes_1),
    makesym(atom_multiply),
  };
  static Const q funct_const_33[] = {
    makesym(functor_yes_1),
    makesym(atom_divide),
  };
  static Const q funct_const_34[] = {
    makesym(functor_yes_1),
    makesym(atom_pow),
  };
  static Const q funct_const_35[] = {
    makesym(functor_yes_1),
    makesym(atom_modulo),
  };
  static Const q funct_const_36[] = {
    makesym(functor_yes_1),
    makesym(atom_and),
  };
  static Const q funct_const_37[] = {
    makesym(functor_yes_1),
    makesym(atom_or),
  };
  static Const q funct_const_38[] = {
    makesym(functor_yes_1),
    makesym(atom_exclusive__or),
  };
  static Const q funct_const_39[] = {
    makesym(functor_yes_1),
    makesym(atom_shift__left),
  };
  static Const q funct_const_40[] = {
    makesym(functor_yes_1),
    makesym(atom_shift__right),
  };
  static Const q funct_const_41[] = {
    makesym(functor_yes_1),
    makesym(atom_complement),
  };
  static Const q funct_const_42[] = {
    makesym(functor_yes_1),
    makesym(atom_plus),
  };
  static Const q funct_const_43[] = {
    makesym(functor_yes_1),
    makesym(atom_minus),
  };
  q a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, macro_2_top);
    case_pred(1, macro__1_3_top);
    case_pred(2, exp__one__clause_4_top);
    case_pred(3, dlclause_9_top);
    case_pred(4, dlclause__1_9_top);
    case_pred(5, initialize__info_7_top);
    case_pred(6, initialize__info__1_10_top);
    case_pred(7, dlgoals_7_top);
    case_pred(8, dlor_8_top);
    case_pred(9, merge__vinfo_5_top);
    case_pred(10, dlgoal_7_top);
    case_pred(11, dl__compute_9_top);
    case_pred(12, dl__update_12_top);
    case_pred(13, dl__common_9_top);
    case_pred(14, dlgoal__atom_3_top);
    case_pred(15, dlappend__args_3_top);
    case_pred(16, dlappend__args_2F3_240_4_top);
    case_pred(17, update__info_6_top);
    case_pred(18, update__info__1_9_top);
    case_pred(19, replace__vars_3_top);
    case_pred(20, replace__vars__1_3_top);
    case_pred(21, replace__vars__elems_3_top);
    case_pred(22, countvars_2_top);
    case_pred(23, countvars_3_top);
    case_pred(24, findvars_3_top);
    case_pred(25, findvars__elems_3_top);
    case_pred(26, countsame_5_top);
    case_pred(27, finalize__vars_4_top);
    case_pred(28, exp__head_6_top);
    case_pred(29, exp__head__and__guard__top_6_top);
    case_pred(30, linearize__guard_3_top);
    case_pred(31, exp__guard_5_top);
    case_pred(32, exp__body_8_top);
    case_pred(33, exp__body__or_6_top);
    case_pred(34, find__interface__vars_3_top);
    case_pred(35, find__interface__vars__1_6_top);
    case_pred(36, body__or__clauses_6_top);
    case_pred(37, body__or__one_6_top);
    case_pred(38, macro__goal_8_top);
    case_pred(39, macro__goal__functor_8_top);
    case_pred(40, macro__goal__functor__cmp_9_top);
    case_pred(41, make__expanded__call_2_top);
    case_pred(42, expand__goal_3_top);
    case_pred(43, compar__macro_2_top);
    case_pred(44, macro__args_9_top);
    case_pred(45, macro__arg_9_top);
    case_pred(46, macro__arg__n_8_top);
    case_pred(47, macro__vector__elems_10_top);
    case_pred(48, macro__vec__elems_8_top);
    case_pred(49, macro__arg__functor_9_top);
    case_pred(50, macro__arg__functor__sharp_10_top);
    case_pred(51, macro__N__10_4_top);
    case_pred(52, macro__exp_6_top);
    case_pred(53, macro__arith__op_2_top);
    case_pred(54, macro__exp__1_7_top);
    case_pred(55, macro__exp__args_7_top);
    case_pred(56, macro__float__exp_6_top);
    case_pred(57, macro__float__op_2_top);
    case_pred(58, macro__float__exp__1_7_top);
    last_case_pred(59, macro__float__args_7_top);
  }

 macro_2_top: {
  q x0;
  qp = qp->next;
 macro_2_clear_reason:
  reasonp = reasons;
 macro_2_0:
 macro_2_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_atom_1:
  x0 = arg(a0, 0);
 macro_2_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (isint(x0)) goto macro_2_4;
  switch (symval(x0)) {
 case symval(makesym(atom_otherwise)):
  unify_value(a1, makesym(atom_otherwise));
  proceed();
 case symval(makesym(atom_alternatively)):
  unify_value(a1, makesym(atom_alternatively));
  proceed();
  };
  goto macro_2_4;
 case VARREF:
  deref_and_jump(x0,macro_2_2);
  *reasonp++ =  x0;
  goto macro_2_4;
  };
  goto macro_2_4;
 case functor_functor_1:
  x0 = arg(a0, 0);
 macro_2_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__3A_2D_2)) goto macro_2_4;
  a0 = arg(x0, 1);
  a2 = arg(x0, 0);
  execute(macro__1_3_0);
  goto macro__1_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,macro_2_3);
  *reasonp++ =  x0;
  goto macro_2_4;
  };
  goto macro_2_4;
  };
  goto macro_2_4;
 case VARREF:
  deref_and_jump(a0,macro_2_1);
  *reasonp++ =  a0;
  goto macro_2_4;
  };
  goto macro_2_4;
 macro_2_4:
  otherwise(macro_2_interrupt);
  a2 = makefunctor(funct_const_14);
  a3 = a1;
  a1 = makefunctor(funct_const_14);
  execute(exp__one__clause_4_0);
  goto exp__one__clause_4_ext_interrupt;
 macro_2_ext_interrupt:
  reasonp = 0l;
 macro_2_interrupt:
  goto interrupt_2;
 }

 macro__1_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 macro__1_3_clear_reason:
  reasonp = reasons;
 macro__1_3_0:
 macro__1_3_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_functor_1)) goto macro__1_3_3;
  x0 = arg(a0, 0);
 macro__1_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__7C_2)) goto macro__1_3_3;
  a0 = a2;
  x1 = arg(x0, 0);
  a2 = arg(x0, 1);
  a3 = a1;
  a1 = x1;
  execute(exp__one__clause_4_0);
  goto exp__one__clause_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,macro__1_3_2);
  *reasonp++ =  x0;
  goto macro__1_3_3;
  };
  goto macro__1_3_3;
 case VARREF:
  deref_and_jump(a0,macro__1_3_1);
  *reasonp++ =  a0;
  goto macro__1_3_3;
  };
  goto macro__1_3_3;
 macro__1_3_3:
  otherwise(macro__1_3_interrupt);
  x0 = a2;
  a2 = a0;
  a3 = a1;
  a1 = makefunctor(funct_const_14);
  a0 = x0;
  execute(exp__one__clause_4_0);
  goto exp__one__clause_4_ext_interrupt;
 macro__1_3_ext_interrupt:
  reasonp = 0l;
 macro__1_3_interrupt:
  toppred = &predicate_klic__comp__macro_xmacro__1_3;
  goto interrupt_3;
 }

 exp__one__clause_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20, x21, x22, x23, x24;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 exp__one__clause_4_clear_reason:
  reasonp = reasons;
 exp__one__clause_4_0:
  allocp[0] = makesym(functor_clause_4);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  x0 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a3, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xexp__body_8);
  allocp[2] = x5 = makeref(&allocp[2]);
  allocp[3] = x6 = makeref(&allocp[3]);
  allocp[4] = x7 = makeref(&allocp[4]);
  allocp[5] = x8 = makeref(&allocp[5]);
  allocp[6] = x4;
  allocp[7] = NILATOM;
  allocp[8] = x3;
  allocp[9] = NILATOM;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_klic__comp__macro_xexp__guard_5);
  allocp[12] = x9 = makeref(&allocp[12]);
  allocp[13] = x10 = makeref(&allocp[13]);
  allocp[14] = x6;
  allocp[15] = x2;
  allocp[16] = NILATOM;
  allocp[17] = (q)(struct goalrec*)&allocp[10];
  allocp[18] = (q)(&predicate_klic__comp__macro_xlinearize__guard_3);
  allocp[19] = x11 = makeref(&allocp[19]);
  allocp[20] = x12 = makeref(&allocp[20]);
  allocp[21] = NILATOM;
  allocp[22] = (q)(struct goalrec*)&allocp[17];
  allocp[23] = (q)(&predicate_klic__comp__macro_xexp__head_6);
  allocp[24] = x13 = makeref(&allocp[24]);
  allocp[25] = x1;
  allocp[26] = x14 = makeref(&allocp[26]);
  allocp[27] = x10;
  allocp[28] = x9;
  allocp[29] = x12;
  allocp[30] = x5;
  allocp[31] = x11;
  x15 = makecons(&allocp[30]);
  allocp[32] = x15;
  allocp[33] = x13;
  x16 = makecons(&allocp[32]);
  allocp[34] = (q)(struct goalrec*)&allocp[22];
  allocp[35] = (q)(&predicate_klic__comp__macro_xcountvars_2);
  allocp[36] = x16;
  allocp[37] = x8;
  allocp[38] = (q)(struct goalrec*)&allocp[34];
  allocp[39] = (q)(&predicate_klic__comp__macro_xdlclause_9);
  allocp[40] = x17 = makeref(&allocp[40]);
  allocp[41] = x18 = makeref(&allocp[41]);
  allocp[42] = x19 = makeref(&allocp[42]);
  allocp[43] = x13;
  allocp[44] = x11;
  allocp[45] = x5;
  allocp[46] = x20 = makeref(&allocp[46]);
  allocp[47] = x14;
  allocp[48] = NILATOM;
  allocp[49] = a2;
  allocp[50] = a1;
  x21 = makecons(&allocp[49]);
  allocp[51] = x21;
  allocp[52] = a0;
  x22 = makecons(&allocp[51]);
  allocp[53] = x19;
  allocp[54] = x18;
  x23 = makecons(&allocp[53]);
  allocp[55] = x23;
  allocp[56] = x17;
  x24 = makecons(&allocp[55]);
  allocp[57] = (q)(struct goalrec*)&allocp[38];
  allocp[58] = (q)(&predicate_klic__comp__util_xnumbervars_4);
  allocp[59] = x22;
  allocp[60] = x24;
  allocp[61] = makeint(0L);
  allocp[62] = x20;
  qp = (struct goalrec*)&allocp[57];
  allocp += 63;
  proceed();
 exp__one__clause_4_ext_interrupt:
  reasonp = 0l;
 exp__one__clause_4_interrupt:
  toppred = &predicate_klic__comp__macro_xexp__one__clause_4;
  goto interrupt_4;
 }

 dlclause_9_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 dlclause_9_clear_reason:
  reasonp = reasons;
 dlclause_9_0:
 dlclause_9_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_functor_1:
  a0 = arg(a0, 0);
  execute(dlclause__1_9_0);
  goto dlclause__1_9_ext_interrupt;
 case functor_atom_1:
  a0 = arg(a0, 0);
  execute(dlclause__1_9_0);
  goto dlclause__1_9_ext_interrupt;
  };
  goto dlclause_9_2;
 case VARREF:
  deref_and_jump(a0,dlclause_9_1);
  *reasonp++ =  a0;
  goto dlclause_9_2;
  };
  goto dlclause_9_2;
 dlclause_9_2:
  otherwise(dlclause_9_interrupt);
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__kl1cmp_xreport__error_2);
  allocp[4] = makefunctor(&string_const_2);
  allocp[5] = x0;
  qp = (struct goalrec*)&allocp[2];
  allocp += 6;
  proceed();
 dlclause_9_ext_interrupt:
  reasonp = 0l;
 dlclause_9_interrupt:
  toppred = &predicate_klic__comp__macro_xdlclause_9;
  goto interrupt_9;
 }

 dlclause__1_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 dlclause__1_9_clear_reason:
  reasonp = reasons;
 dlclause__1_9_0:
 dlclause__1_9_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor__2D_2:
  x0 = arg(a0, 1);
 dlclause__1_9_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_variable_1)) goto dlclause__1_9_3;
  allocp[0] = makesym(functor__2D_1);
  allocp[1] = arg(x0, 0);
  x1 = makefunctor(&allocp[0]);
  allocp[2] = a8;
  allocp[3] = x1;
  x2 = makecons(&allocp[2]);
  a0 = arg(a0, 0);
  a8 = x2;
  allocp += 4;
  execute(dlclause_9_0);
  goto dlclause_9_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,dlclause__1_9_2);
  *reasonp++ =  x0;
  goto dlclause__1_9_3;
  };
  goto dlclause__1_9_3;
 case functor__2B_2:
  allocp[0] = makesym(functor__2B_1);
  allocp[1] = arg(a0, 1);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = a8;
  allocp[3] = x0;
  x1 = makecons(&allocp[2]);
  a0 = arg(a0, 0);
  a8 = x1;
  allocp += 4;
  execute(dlclause_9_0);
  goto dlclause_9_ext_interrupt;
  };
  goto dlclause__1_9_3;
 case VARREF:
  deref_and_jump(a0,dlclause__1_9_1);
  *reasonp++ =  a0;
  goto dlclause__1_9_3;
  };
  goto dlclause__1_9_3;
 dlclause__1_9_3:
  otherwise(dlclause__1_9_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xfinalize__vars_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a5;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_klic__comp__macro_xdlgoals_7);
  allocp[8] = a2;
  allocp[9] = x2;
  allocp[10] = x0;
  allocp[11] = x3 = makeref(&allocp[11]);
  allocp[12] = a7;
  allocp[13] = x4 = makeref(&allocp[13]);
  allocp[14] = x1;
  allocp[15] = (q)(struct goalrec*)&allocp[6];
  allocp[16] = (q)(&predicate_klic__comp__macro_xdlgoals_7);
  allocp[17] = a1;
  allocp[18] = a4;
  allocp[19] = x0;
  allocp[20] = x5 = makeref(&allocp[20]);
  allocp[21] = x3;
  allocp[22] = x6 = makeref(&allocp[22]);
  allocp[23] = x4;
  allocp[24] = x8 = makeref(&allocp[24]);
  allocp[25] = x9 = makeref(&allocp[25]);
  x7 = makecons(&allocp[24]);
  allocp[26] = (q)(struct goalrec*)&allocp[15];
  allocp[27] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[28] = a3;
  allocp[29] = x7;
  allocp[30] = x8;
  allocp[31] = x9;
  x10 = makecons(&allocp[30]);
  allocp[32] = (q)(struct goalrec*)&allocp[26];
  allocp[33] = (q)(&predicate_klic__comp__util_xuniv_3);
  allocp[34] = a0;
  allocp[35] = x10;
  allocp[36] = x11 = makeref(&allocp[36]);
  a0 = a8;
  a1 = a6;
  a2 = x5;
  a3 = NILATOM;
  a4 = x6;
  a5 = x11;
  a6 = x0;
  qp = (struct goalrec*)&allocp[32];
  allocp += 37;
  execute(initialize__info_7_0);
  goto initialize__info_7_ext_interrupt;
 dlclause__1_9_ext_interrupt:
  reasonp = 0l;
 dlclause__1_9_interrupt:
  toppred = &predicate_klic__comp__macro_xdlclause__1_9;
  goto interrupt_9;
 }

 initialize__info_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 initialize__info_7_clear_reason:
  reasonp = reasons;
 initialize__info_7_0:
 initialize__info_7_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 initialize__info_7_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor__2D_1:
  allocp[0] = makesym(functor_variable_1);
  allocp[1] = x2 = makeref(&allocp[1]);
  x1 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_variable_1);
  allocp[3] = a1;
  x3 = makefunctor(&allocp[2]);
  allocp[4] = x5 = makeref(&allocp[4]);
  allocp[5] = x3;
  x4 = makecons(&allocp[4]);
  allocp[6] = x4;
  allocp[7] = x1;
  x6 = makecons(&allocp[6]);
  allocp += 8;
  unify_value(a5, x6);
  allocp[0] = x8 = makeref(&allocp[0]);
  allocp[1] = a1;
  x7 = makecons(&allocp[0]);
  allocp[2] = x7;
  allocp[3] = x2;
  x9 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a6, x9);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xinitialize__info__1_10);
  x10 = cdr_of(a0);
  allocp[2] = x10;
  allocp[3] = x11 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x12 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x5;
  allocp[8] = x8;
  allocp[9] = x13 = makeref(&allocp[9]);
  allocp[10] = x2;
  x14 = arg(x0, 0);
  allocp[11] = x14;
  allocp[12] = makesym(functor__3D_2);
  allocp[13] = x14;
  allocp[14] = x2;
  x15 = makefunctor(&allocp[12]);
  allocp[15] = a3;
  allocp[16] = x15;
  x16 = makecons(&allocp[15]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 17;
  unify_value(x12, x16);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[2] = a1;
  allocp[3] = makeint(1L);
  allocp[4] = x11;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_klic__comp__util_xassoc_3);
  allocp[7] = a3;
  allocp[8] = x14;
  allocp[9] = x13;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case functor__2B_1:
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = x3 = makeref(&allocp[1]);
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a5, x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xinitialize__info_7);
  x4 = cdr_of(a0);
  allocp[2] = x4;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x2;
  allocp[8] = a6;
  a0 = arg(x0, 0);
  a1 = x3;
  a2 = a3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 9;
  execute(replace__vars_3_0);
  goto replace__vars_3_ext_interrupt;
  };
  goto initialize__info_7_interrupt;
 case VARREF:
  deref_and_jump(x0,initialize__info_7_2);
  *reasonp++ =  x0;
  goto initialize__info_7_interrupt;
  };
  goto initialize__info_7_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto initialize__info_7_interrupt;
  unify2(a4, a3, a2, a1);
  unify_value(a5, NILATOM);
  unify_value(a6, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a0,initialize__info_7_1);
  *reasonp++ =  a0;
  goto initialize__info_7_interrupt;
  };
  goto initialize__info_7_interrupt;
 initialize__info_7_ext_interrupt:
  reasonp = 0l;
 initialize__info_7_interrupt:
  toppred = &predicate_klic__comp__macro_xinitialize__info_7;
  goto interrupt_7;
 }

 initialize__info__1_10_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 initialize__info__1_10_clear_reason:
  reasonp = reasons;
 initialize__info__1_10_0:
 initialize__info__1_10_1:
  switch (ptagof(a7)) {
 case ATOMIC:
  if (a7 != makesym(atom_no)) goto initialize__info__1_10_interrupt;
  unify(a8, a9);
  execute(initialize__info_7_0);
  goto initialize__info_7_ext_interrupt;
 case FUNCTOR:
  if (functor_of(a7) != makesym(functor_yes_1)) goto initialize__info__1_10_interrupt;
  x0 = arg(a7, 0);
  unify(a8, x0);
  execute(initialize__info_7_0);
  goto initialize__info_7_ext_interrupt;
 case VARREF:
  deref_and_jump(a7,initialize__info__1_10_1);
  *reasonp++ =  a7;
  goto initialize__info__1_10_interrupt;
  };
  goto initialize__info__1_10_interrupt;
 initialize__info__1_10_ext_interrupt:
  reasonp = 0l;
 initialize__info__1_10_interrupt:
  goto interrupt_10;
 }

 dlgoals_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 dlgoals_7_clear_reason:
  reasonp = reasons;
 dlgoals_7_0:
 dlgoals_7_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_functor_1)) goto dlgoals_7_3;
  x0 = arg(a0, 0);
 dlgoals_7_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor__2C_2:
  allocp[0] = makesym(functor__2C_2);
  allocp[1] = x2 = makeref(&allocp[1]);
  allocp[2] = x3 = makeref(&allocp[2]);
  x1 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_functor_1);
  allocp[4] = x1;
  x4 = makefunctor(&allocp[3]);
  allocp += 5;
  unify_value(a1, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xdlgoals_7);
  x5 = arg(x0, 1);
  allocp[2] = x5;
  allocp[3] = x3;
  allocp[4] = a2;
  allocp[5] = x6 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x7 = makeref(&allocp[7]);
  allocp[8] = a6;
  a0 = arg(x0, 0);
  a1 = x2;
  a4 = x6;
  a6 = x7;
  qp = (struct goalrec*)&allocp[0];
  allocp += 9;
  execute(dlgoals_7_0);
  goto dlgoals_7_ext_interrupt;
 case functor__3B_2:
  allocp[0] = x1 = makeref(&allocp[0]);
  a7 = x1;
  allocp += 1;
  execute(dlor_8_0);
  goto dlor_8_ext_interrupt;
 case functor__2D_3E_2:
  allocp[0] = x1 = makeref(&allocp[0]);
  a7 = x1;
  allocp += 1;
  execute(dlor_8_0);
  goto dlor_8_ext_interrupt;
 case functor__40_2:
  allocp[0] = makesym(functor__40_2);
  allocp[1] = x2 = makeref(&allocp[1]);
  allocp[2] = x3 = makeref(&allocp[2]);
  x1 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_functor_1);
  allocp[4] = x1;
  x4 = makefunctor(&allocp[3]);
  allocp += 5;
  unify_value(a1, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xreplace__vars_3);
  x5 = arg(x0, 1);
  allocp[2] = x5;
  allocp[3] = x3;
  allocp[4] = a6;
  a0 = arg(x0, 0);
  a1 = x2;
  a2 = NILATOM;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(dlgoal_7_0);
  goto dlgoal_7_ext_interrupt;
  };
  goto dlgoals_7_3;
 case VARREF:
  deref_and_jump(x0,dlgoals_7_2);
  *reasonp++ =  x0;
  goto dlgoals_7_3;
  };
  goto dlgoals_7_3;
 case VARREF:
  deref_and_jump(a0,dlgoals_7_1);
  *reasonp++ =  a0;
  goto dlgoals_7_3;
  };
  goto dlgoals_7_3;
 dlgoals_7_3:
  otherwise(dlgoals_7_interrupt);
  a2 = NILATOM;
  execute(dlgoal_7_0);
  goto dlgoal_7_ext_interrupt;
 dlgoals_7_ext_interrupt:
  reasonp = 0l;
 dlgoals_7_interrupt:
  toppred = &predicate_klic__comp__macro_xdlgoals_7;
  goto interrupt_7;
 }

 dlor_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 dlor_8_clear_reason:
  reasonp = reasons;
 dlor_8_0:
 dlor_8_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_functor_1)) goto dlor_8_5;
  x0 = arg(a0, 0);
 dlor_8_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor__3B_2:
  x1 = arg(x0, 0);
 dlor_8_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_functor_1)) goto dlor_8_5;
  x2 = arg(x1, 0);
 dlor_8_4:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor__2D_3E_2)) goto dlor_8_5;
  allocp[0] = makesym(functor__2C_2);
  allocp[1] = x4 = makeref(&allocp[1]);
  allocp[2] = x5 = makeref(&allocp[2]);
  x3 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_functor_1);
  allocp[4] = x3;
  x6 = makefunctor(&allocp[3]);
  allocp[5] = makesym(functor__2D_3E_2);
  allocp[6] = x8 = makeref(&allocp[6]);
  allocp[7] = x6;
  x7 = makefunctor(&allocp[5]);
  allocp[8] = makesym(functor_functor_1);
  allocp[9] = x7;
  x9 = makefunctor(&allocp[8]);
  allocp[10] = makesym(functor__3B_2);
  allocp[11] = x9;
  allocp[12] = x11 = makeref(&allocp[12]);
  x10 = makefunctor(&allocp[10]);
  allocp[13] = makesym(functor_functor_1);
  allocp[14] = x10;
  x12 = makefunctor(&allocp[13]);
  allocp += 15;
  unify_value(a1, x12);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xmerge__vinfo_5);
  allocp[2] = a2;
  allocp[3] = a7;
  allocp[4] = x5;
  allocp[5] = x13 = makeref(&allocp[5]);
  allocp[6] = a6;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_klic__comp__macro_xdlor_8);
  x14 = arg(x0, 1);
  allocp[9] = x14;
  allocp[10] = x11;
  allocp[11] = a2;
  allocp[12] = x15 = makeref(&allocp[12]);
  allocp[13] = a4;
  allocp[14] = a5;
  allocp[15] = x16 = makeref(&allocp[15]);
  allocp[16] = a7;
  allocp[17] = (q)(struct goalrec*)&allocp[7];
  allocp[18] = (q)(&predicate_klic__comp__macro_xdlgoals_7);
  x17 = arg(x2, 1);
  allocp[19] = x17;
  allocp[20] = x4;
  allocp[21] = a2;
  allocp[22] = x18 = makeref(&allocp[22]);
  allocp[23] = x15;
  allocp[24] = x19 = makeref(&allocp[24]);
  allocp[25] = x13;
  a0 = arg(x2, 0);
  a1 = x8;
  a4 = x18;
  a6 = x19;
  qp = (struct goalrec*)&allocp[17];
  allocp += 26;
  execute(dlgoals_7_0);
  goto dlgoals_7_ext_interrupt;
 case VARREF:
  deref_and_jump(x2,dlor_8_4);
  *reasonp++ =  x2;
  goto dlor_8_5;
  };
  goto dlor_8_5;
 case VARREF:
  deref_and_jump(x1,dlor_8_3);
  *reasonp++ =  x1;
  goto dlor_8_5;
  };
  goto dlor_8_5;
 case functor__2D_3E_2:
  allocp[0] = makesym(functor__2C_2);
  allocp[1] = x2 = makeref(&allocp[1]);
  allocp[2] = x3 = makeref(&allocp[2]);
  x1 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_functor_1);
  allocp[4] = x1;
  x4 = makefunctor(&allocp[3]);
  allocp[5] = makesym(functor__2D_3E_2);
  allocp[6] = x6 = makeref(&allocp[6]);
  allocp[7] = x4;
  x5 = makefunctor(&allocp[5]);
  allocp[8] = makesym(functor_functor_1);
  allocp[9] = x5;
  x7 = makefunctor(&allocp[8]);
  allocp += 10;
  unify_value(a1, x7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xmerge__vinfo_5);
  allocp[2] = a2;
  allocp[3] = a7;
  allocp[4] = x3;
  allocp[5] = x8 = makeref(&allocp[5]);
  allocp[6] = a6;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[9] = x9 = makeref(&allocp[9]);
  allocp[10] = x10 = makeref(&allocp[10]);
  allocp[11] = a4;
  allocp[12] = (q)(struct goalrec*)&allocp[7];
  allocp[13] = (q)(&predicate_klic__comp__util_xlength_2);
  allocp[14] = a2;
  allocp[15] = x10;
  qp = (struct goalrec*)&allocp[12];
  allocp += 16;
  unify(a7, x9);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xdlgoals_7);
  x11 = arg(x0, 1);
  allocp[2] = x11;
  allocp[3] = x2;
  allocp[4] = a2;
  allocp[5] = x12 = makeref(&allocp[5]);
  allocp[6] = x9;
  allocp[7] = x13 = makeref(&allocp[7]);
  allocp[8] = x8;
  a0 = arg(x0, 0);
  a1 = x6;
  a4 = x12;
  a6 = x13;
  qp = (struct goalrec*)&allocp[0];
  allocp += 9;
  execute(dlgoals_7_0);
  goto dlgoals_7_ext_interrupt;
  };
  goto dlor_8_5;
 case VARREF:
  deref_and_jump(x0,dlor_8_2);
  *reasonp++ =  x0;
  goto dlor_8_5;
  };
  goto dlor_8_5;
 case VARREF:
  deref_and_jump(a0,dlor_8_1);
  *reasonp++ =  a0;
  goto dlor_8_5;
  };
  goto dlor_8_5;
 dlor_8_5:
  otherwise(dlor_8_interrupt);
 dlor_8_6:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_functor_1)) goto dlor_8_8;
  x0 = arg(a0, 0);
 dlor_8_7:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__3B_2)) goto dlor_8_8;
  allocp[0] = makesym(functor__3B_2);
  allocp[1] = x2 = makeref(&allocp[1]);
  allocp[2] = x3 = makeref(&allocp[2]);
  x1 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_functor_1);
  allocp[4] = x1;
  x4 = makefunctor(&allocp[3]);
  allocp += 5;
  unify_value(a1, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xdlor_8);
  x5 = arg(x0, 1);
  allocp[2] = x5;
  allocp[3] = x3;
  allocp[4] = a2;
  allocp[5] = x6 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x7 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = a7;
  a0 = arg(x0, 0);
  a1 = x2;
  a4 = x6;
  a6 = x7;
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  execute(dlgoals_7_0);
  goto dlgoals_7_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,dlor_8_7);
  *reasonp++ =  x0;
  goto dlor_8_8;
  };
  goto dlor_8_8;
 case VARREF:
  deref_and_jump(a0,dlor_8_6);
  *reasonp++ =  a0;
  goto dlor_8_8;
  };
  goto dlor_8_8;
 dlor_8_8:
  otherwise(dlor_8_interrupt);
  execute(dlgoals_7_0);
  goto dlgoals_7_ext_interrupt;
 dlor_8_ext_interrupt:
  reasonp = 0l;
 dlor_8_interrupt:
  toppred = &predicate_klic__comp__macro_xdlor_8;
  goto interrupt_8;
 }

 merge__vinfo_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 merge__vinfo_5_clear_reason:
  reasonp = reasons;
 merge__vinfo_5_0:
 merge__vinfo_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = cdr_of(a0);
 merge__vinfo_5_2:
  switch (ptagof(x0)) {
 case CONS:
  allocp[0] = makesym(functor_variable_1);
  allocp[1] = a1;
  x1 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_variable_1);
  allocp[3] = x3 = makeref(&allocp[3]);
  x2 = makefunctor(&allocp[2]);
  allocp[4] = makesym(functor__3D_2);
  allocp[5] = x1;
  allocp[6] = x2;
  x4 = makefunctor(&allocp[4]);
  allocp[7] = makesym(functor_functor_1);
  allocp[8] = x4;
  x5 = makefunctor(&allocp[7]);
  allocp[9] = makesym(functor__2C_2);
  allocp[10] = x5;
  allocp[11] = x7 = makeref(&allocp[11]);
  x6 = makefunctor(&allocp[9]);
  allocp[12] = makesym(functor_functor_1);
  allocp[13] = x6;
  x8 = makefunctor(&allocp[12]);
  allocp += 14;
  unify_value(a2, x8);
  allocp[0] = makesym(functor__3D_2);
  allocp[1] = car_of(a0);
  allocp[2] = a1;
  x9 = makefunctor(&allocp[0]);
  allocp[3] = x11 = makeref(&allocp[3]);
  allocp[4] = x9;
  x10 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a4, x10);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xmerge__vinfo_5);
  x12 = cdr_of(x0);
  allocp[2] = x12;
  allocp[3] = x13 = makeref(&allocp[3]);
  allocp[4] = x7;
  allocp[5] = a3;
  allocp[6] = x11;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[9] = a1;
  allocp[10] = makeint(1L);
  allocp[11] = x13;
  allocp[12] = makesym(functor_yes_1);
  allocp[13] = x3;
  x14 = makefunctor(&allocp[12]);
  allocp[14] = (q)(struct goalrec*)&allocp[7];
  allocp[15] = (q)(&predicate_klic__comp__util_xassoc_3);
  allocp[16] = a3;
  x15 = car_of(a0);
  allocp[17] = x15;
  allocp[18] = x14;
  qp = (struct goalrec*)&allocp[14];
  allocp += 19;
  proceed();
 case VARREF:
  deref_and_jump(x0,merge__vinfo_5_2);
  *reasonp++ =  x0;
  goto merge__vinfo_5_interrupt;
  };
  goto merge__vinfo_5_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto merge__vinfo_5_interrupt;
  unify_value(a2, makefunctor(funct_const_14));
  unify_value(a4, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a0,merge__vinfo_5_1);
  *reasonp++ =  a0;
  goto merge__vinfo_5_interrupt;
  };
  goto merge__vinfo_5_interrupt;
 merge__vinfo_5_ext_interrupt:
  reasonp = 0l;
 merge__vinfo_5_interrupt:
  goto interrupt_5;
 }

 dlgoal_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 dlgoal_7_clear_reason:
  reasonp = reasons;
 dlgoal_7_0:
 dlgoal_7_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_functor_1:
  x0 = arg(a0, 0);
 dlgoal_7_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor__3A_2:
  x1 = arg(x0, 0);
 dlgoal_7_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_atom_1)) goto dlgoal_7_14;
  x2 = arg(x1, 0);
 dlgoal_7_4:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != makesym(atom_inline)) goto dlgoal_7_5;
  allocp[0] = makesym(functor__3A_2);
  allocp[1] = x1;
  allocp[2] = x4 = makeref(&allocp[2]);
  x3 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_functor_1);
  allocp[4] = x3;
  x5 = makefunctor(&allocp[3]);
  allocp += 5;
  unify_value(a1, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xdlappend__args_3);
  allocp[2] = x6 = makeref(&allocp[2]);
  allocp[3] = x7 = makeref(&allocp[3]);
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_klic__comp__macro_xupdate__info_6);
  allocp[7] = a2;
  allocp[8] = x7;
  allocp[9] = a3;
  allocp[10] = a4;
  allocp[11] = a5;
  allocp[12] = a6;
  a0 = arg(x0, 1);
  a1 = x6;
  a2 = a5;
  qp = (struct goalrec*)&allocp[5];
  allocp += 13;
  execute(replace__vars_3_0);
  goto replace__vars_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x2,dlgoal_7_4);
  *reasonp++ =  x2;
  goto dlgoal_7_14;
  };
  goto dlgoal_7_5;
 dlgoal_7_5:
  gblt_diff(x2,makesym(atom_inline),dlgoal_7_14);
  allocp[0] = makesym(functor__3A_2);
  allocp[1] = x1;
  allocp[2] = x4 = makeref(&allocp[2]);
  x3 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_functor_1);
  allocp[4] = x3;
  x5 = makefunctor(&allocp[3]);
  allocp += 5;
  unify_value(a1, x5);
  a0 = arg(x0, 1);
  a1 = x4;
  execute(dlgoal_7_0);
  goto dlgoal_7_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,dlgoal_7_3);
  *reasonp++ =  x1;
  goto dlgoal_7_14;
  };
  goto dlgoal_7_14;
 case functor__2D_2:
  x1 = arg(x0, 1);
 dlgoal_7_6:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_variable_1)) goto dlgoal_7_14;
  allocp[0] = makesym(functor__2D_1);
  allocp[1] = arg(x1, 0);
  x2 = makefunctor(&allocp[0]);
  allocp[2] = a2;
  allocp[3] = x2;
  x3 = makecons(&allocp[2]);
  a0 = arg(x0, 0);
  a2 = x3;
  allocp += 4;
  execute(dlgoal_7_0);
  goto dlgoal_7_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,dlgoal_7_6);
  *reasonp++ =  x1;
  goto dlgoal_7_14;
  };
  goto dlgoal_7_14;
 case functor__2B_2:
  allocp[0] = makesym(functor__2B_1);
  allocp[1] = arg(x0, 1);
  x1 = makefunctor(&allocp[0]);
  allocp[2] = a2;
  allocp[3] = x1;
  x2 = makecons(&allocp[2]);
  a0 = arg(x0, 0);
  a2 = x2;
  allocp += 4;
  execute(dlgoal_7_0);
  goto dlgoal_7_ext_interrupt;
 case functor__3C_3D_3D_2:
  x1 = arg(x0, 0);
 dlgoal_7_7:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_variable_1)) goto dlgoal_7_14;
  a0 = arg(x0, 1);
  x2 = a3;
  a7 = arg(x1, 0);
  allocp[0] = x3 = makeref(&allocp[0]);
  a8 = x3;
  a9 = a3;
  allocp[1] = x4 = makeref(&allocp[1]);
  a10 = x4;
  a11 = x4;
  a3 = x2;
  allocp += 2;
  execute(dl__update_12_0);
  goto dl__update_12_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,dlgoal_7_7);
  *reasonp++ =  x1;
  goto dlgoal_7_14;
  };
  goto dlgoal_7_14;
 case functor__3C_3D_2:
  x1 = arg(x0, 0);
 dlgoal_7_8:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_variable_1)) goto dlgoal_7_14;
  allocp[0] = makesym(functor_variable_1);
  allocp[1] = a3;
  x2 = makefunctor(&allocp[0]);
  allocp[2] = x2;
  allocp[3] = x4 = makeref(&allocp[3]);
  x3 = makecons(&allocp[2]);
  allocp[4] = makesym(functor_list_1);
  allocp[5] = x3;
  x5 = makefunctor(&allocp[4]);
  a0 = arg(x0, 1);
  a7 = arg(x1, 0);
  allocp[6] = x6 = makeref(&allocp[6]);
  a8 = x6;
  a9 = x6;
  a10 = x4;
  a11 = x5;
  allocp += 7;
  execute(dl__update_12_0);
  goto dl__update_12_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,dlgoal_7_8);
  *reasonp++ =  x1;
  goto dlgoal_7_14;
  };
  goto dlgoal_7_14;
 case functor__3D_3E_2:
  x1 = arg(x0, 1);
 dlgoal_7_9:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_variable_1)) goto dlgoal_7_14;
  allocp[0] = makesym(functor_variable_1);
  allocp[1] = x3 = makeref(&allocp[1]);
  x2 = makefunctor(&allocp[0]);
  allocp[2] = x2;
  allocp[3] = x5 = makeref(&allocp[3]);
  x4 = makecons(&allocp[2]);
  allocp[4] = makesym(functor_list_1);
  allocp[5] = x4;
  x6 = makefunctor(&allocp[4]);
  a0 = arg(x0, 0);
  x7 = a3;
  a7 = arg(x1, 0);
  a8 = x3;
  a9 = a3;
  a10 = x5;
  a11 = x6;
  a3 = x7;
  allocp += 6;
  execute(dl__update_12_0);
  goto dl__update_12_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,dlgoal_7_9);
  *reasonp++ =  x1;
  goto dlgoal_7_14;
  };
  goto dlgoal_7_14;
 case functor__2B_3D_2:
  x1 = arg(x0, 0);
 dlgoal_7_10:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_variable_1)) goto dlgoal_7_14;
  a0 = arg(x0, 1);
  a7 = arg(x1, 0);
  a8 = makesym(atom__2B);
  execute(dl__compute_9_0);
  goto dl__compute_9_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,dlgoal_7_10);
  *reasonp++ =  x1;
  goto dlgoal_7_14;
  };
  goto dlgoal_7_14;
 case functor__2D_3D_2:
  x1 = arg(x0, 0);
 dlgoal_7_11:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_variable_1)) goto dlgoal_7_14;
  a0 = arg(x0, 1);
  a7 = arg(x1, 0);
  a8 = makesym(atom__2D);
  execute(dl__compute_9_0);
  goto dl__compute_9_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,dlgoal_7_11);
  *reasonp++ =  x1;
  goto dlgoal_7_14;
  };
  goto dlgoal_7_14;
 case functor__2A_3D_2:
  x1 = arg(x0, 0);
 dlgoal_7_12:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_variable_1)) goto dlgoal_7_14;
  a0 = arg(x0, 1);
  a7 = arg(x1, 0);
  a8 = makesym(atom__2A);
  execute(dl__compute_9_0);
  goto dl__compute_9_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,dlgoal_7_12);
  *reasonp++ =  x1;
  goto dlgoal_7_14;
  };
  goto dlgoal_7_14;
 case functor__2F_3D_2:
  x1 = arg(x0, 0);
 dlgoal_7_13:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_variable_1)) goto dlgoal_7_14;
  a0 = arg(x0, 1);
  a7 = arg(x1, 0);
  a8 = makesym(atom__2F);
  execute(dl__compute_9_0);
  goto dl__compute_9_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,dlgoal_7_13);
  *reasonp++ =  x1;
  goto dlgoal_7_14;
  };
  goto dlgoal_7_14;
  };
  goto dlgoal_7_14;
 case VARREF:
  deref_and_jump(x0,dlgoal_7_2);
  *reasonp++ =  x0;
  goto dlgoal_7_14;
  };
  goto dlgoal_7_14;
 case functor_atom_1:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xdlgoal__atom_3);
  x0 = arg(a0, 0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a1;
  a0 = a2;
  a1 = x1;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  a5 = a6;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(update__info_6_0);
  goto update__info_6_ext_interrupt;
  };
  goto dlgoal_7_14;
 case VARREF:
  deref_and_jump(a0,dlgoal_7_1);
  *reasonp++ =  a0;
  goto dlgoal_7_14;
  };
  goto dlgoal_7_14;
 dlgoal_7_14:
  otherwise(dlgoal_7_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xdlappend__args_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a1;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_klic__comp__macro_xupdate__info_6);
  allocp[7] = a2;
  allocp[8] = x1;
  allocp[9] = a3;
  allocp[10] = a4;
  allocp[11] = a5;
  allocp[12] = a6;
  a1 = x0;
  a2 = a5;
  qp = (struct goalrec*)&allocp[5];
  allocp += 13;
  execute(replace__vars_3_0);
  goto replace__vars_3_ext_interrupt;
 dlgoal_7_ext_interrupt:
  reasonp = 0l;
 dlgoal_7_interrupt:
  toppred = &predicate_klic__comp__macro_xdlgoal_7;
  goto interrupt_7;
 }

 dl__compute_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 dl__compute_9_clear_reason:
  reasonp = reasons;
 dl__compute_9_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xdl__common_9);
  allocp[2] = a0;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = x1 = makeref(&allocp[10]);
  allocp[11] = makesym(functor_variable_1);
  allocp[12] = a3;
  x2 = makefunctor(&allocp[11]);
  allocp[13] = makesym(functor_functor_1);
  allocp[14] = x4 = makeref(&allocp[14]);
  x3 = makefunctor(&allocp[13]);
  allocp[15] = makesym(functor__3A_3D_2);
  allocp[16] = x2;
  allocp[17] = x3;
  x5 = makefunctor(&allocp[15]);
  allocp[18] = makesym(functor_functor_1);
  allocp[19] = x5;
  x6 = makefunctor(&allocp[18]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 20;
  unify_value(a1, x6);
  allocp[0] = makesym(functor_variable_1);
  allocp[1] = x1;
  x7 = makefunctor(&allocp[0]);
  allocp[2] = NILATOM;
  allocp[3] = x0;
  x8 = makecons(&allocp[2]);
  allocp[4] = x8;
  allocp[5] = x7;
  x9 = makecons(&allocp[4]);
  allocp[6] = x9;
  allocp[7] = a8;
  x10 = makecons(&allocp[6]);
  allocp[8] = (q)qp;
  allocp[9] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[10] = x4;
  allocp[11] = x10;
  qp = (struct goalrec*)&allocp[8];
  allocp += 12;
  proceed();
 dl__compute_9_ext_interrupt:
  reasonp = 0l;
 dl__compute_9_interrupt:
  toppred = &predicate_klic__comp__macro_xdl__compute_9;
  goto interrupt_9;
 }

 dl__update_12_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 dl__update_12_clear_reason:
  reasonp = reasons;
 dl__update_12_0:
  allocp[0] = makesym(functor_variable_1);
  allocp[1] = a9;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__3D_2);
  allocp[3] = x0;
  allocp[4] = a11;
  x1 = makefunctor(&allocp[2]);
  allocp[5] = makesym(functor_functor_1);
  allocp[6] = x1;
  x2 = makefunctor(&allocp[5]);
  allocp += 7;
  unify_value(a1, x2);
  a1 = a10;
  execute(dl__common_9_0);
  goto dl__common_9_ext_interrupt;
 dl__update_12_ext_interrupt:
  reasonp = 0l;
 dl__update_12_interrupt:
  toppred = &predicate_klic__comp__macro_xdl__update_12;
  goto interrupt_12;
 }

 dl__common_9_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 dl__common_9_clear_reason:
  reasonp = reasons;
 dl__common_9_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xupdate__info__1_9);
  allocp[2] = a2;
  allocp[3] = a2;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = a4;
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = a6;
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[13] = a3;
  allocp[14] = makeint(1L);
  allocp[15] = x0;
  allocp[16] = makesym(functor__3D_2);
  allocp[17] = a7;
  allocp[18] = a3;
  x3 = makefunctor(&allocp[16]);
  allocp[19] = a5;
  allocp[20] = x3;
  x4 = makecons(&allocp[19]);
  qp = (struct goalrec*)&allocp[11];
  allocp += 21;
  unify_value(x1, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__util_xassoc_3);
  allocp[2] = a5;
  allocp[3] = a7;
  allocp[4] = x2;
  a2 = a5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(replace__vars_3_0);
  goto replace__vars_3_ext_interrupt;
 dl__common_9_ext_interrupt:
  reasonp = 0l;
 dl__common_9_interrupt:
  toppred = &predicate_klic__comp__macro_xdl__common_9;
  goto interrupt_9;
 }

 dlgoal__atom_3_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  qp = qp->next;
 dlgoal__atom_3_clear_reason:
  reasonp = reasons;
 dlgoal__atom_3_0:
 dlgoal__atom_3_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != NILATOM) goto dlgoal__atom_3_2;
  allocp[0] = makesym(functor_atom_1);
  allocp[1] = a0;
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,dlgoal__atom_3_1);
  *reasonp++ =  a1;
  goto dlgoal__atom_3_interrupt;
  };
  goto dlgoal__atom_3_2;
 dlgoal__atom_3_2:
  gblt_diff(a1,NILATOM,dlgoal__atom_3_interrupt);
  allocp[0] = makesym(functor_functor_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  allocp[0] = a1;
  allocp[1] = a0;
  x2 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[4] = x1;
  allocp[5] = x2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 6;
  proceed();
 dlgoal__atom_3_ext_interrupt:
  reasonp = 0l;
 dlgoal__atom_3_interrupt:
  goto interrupt_3;
 }

 dlappend__args_3_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  qp = qp->next;
 dlappend__args_3_clear_reason:
  reasonp = reasons;
 dlappend__args_3_0:
 dlappend__args_3_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != NILATOM) goto dlappend__args_3_2;
  unify(a2, a0);
  proceed();
 case VARREF:
  deref_and_jump(a1,dlappend__args_3_1);
  *reasonp++ =  a1;
  goto dlappend__args_3_interrupt;
  };
  goto dlappend__args_3_2;
 dlappend__args_3_2:
  gblt_diff(a1,NILATOM,dlappend__args_3_interrupt);
  allocp[0] = makesym(functor_functor_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  allocp[0] = x3 = makeref(&allocp[0]);
  allocp[1] = x4 = makeref(&allocp[1]);
  x2 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[4] = x1;
  allocp[5] = x2;
  a2 = x3;
  a3 = a1;
  a1 = x4;
  qp = (struct goalrec*)&allocp[2];
  allocp += 6;
  execute(dlappend__args_2F3_240_4_0);
  goto dlappend__args_2F3_240_4_ext_interrupt;
 dlappend__args_3_ext_interrupt:
  reasonp = 0l;
 dlappend__args_3_interrupt:
  goto interrupt_3;
 }

 dlappend__args_2F3_240_4_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 dlappend__args_2F3_240_4_clear_reason:
  reasonp = reasons;
 dlappend__args_2F3_240_4_0:
 dlappend__args_2F3_240_4_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_functor_1:
  allocp[0] = a2;
  allocp[1] = a1;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__util_xuniv_3);
  x1 = arg(a0, 0);
  allocp[4] = x1;
  allocp[5] = x0;
  allocp[6] = a3;
  qp = (struct goalrec*)&allocp[2];
  allocp += 7;
  proceed();
 case functor_atom_1:
  x0 = arg(a0, 0);
  unify2(a1, x0, a2, a3);
  proceed();
 case functor_list_1:
  x0 = arg(a0, 0);
 dlappend__args_2F3_240_4_2:
  switch (ptagof(x0)) {
 case CONS:
  unify_value(a1, PERIODATOM);
  allocp[0] = a3;
  allocp[1] = cdr_of(x0);
  x1 = makecons(&allocp[0]);
  allocp[2] = x1;
  allocp[3] = car_of(x0);
  x2 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a2, x2);
  proceed();
 case VARREF:
  deref_and_jump(x0,dlappend__args_2F3_240_4_2);
  *reasonp++ =  x0;
  goto dlappend__args_2F3_240_4_interrupt;
  };
  goto dlappend__args_2F3_240_4_interrupt;
  };
  goto dlappend__args_2F3_240_4_interrupt;
 case VARREF:
  deref_and_jump(a0,dlappend__args_2F3_240_4_1);
  *reasonp++ =  a0;
  goto dlappend__args_2F3_240_4_interrupt;
  };
  goto dlappend__args_2F3_240_4_interrupt;
 dlappend__args_2F3_240_4_ext_interrupt:
  reasonp = 0l;
 dlappend__args_2F3_240_4_interrupt:
  toppred = &predicate_klic__comp__macro_xdlappend__args_2F3_240_4;
  goto interrupt_4;
 }

 update__info_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 update__info_6_clear_reason:
  reasonp = reasons;
 update__info_6_0:
 update__info_6_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 update__info_6_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor__2D_1:
  allocp[0] = makesym(functor_variable_1);
  allocp[1] = x2 = makeref(&allocp[1]);
  x1 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_variable_1);
  allocp[3] = a2;
  x3 = makefunctor(&allocp[2]);
  allocp[4] = x5 = makeref(&allocp[4]);
  allocp[5] = x3;
  x4 = makecons(&allocp[4]);
  allocp[6] = x4;
  allocp[7] = x1;
  x6 = makecons(&allocp[6]);
  allocp += 8;
  unify_value(a1, x6);
  allocp[0] = makesym(functor__3D_2);
  allocp[1] = arg(x0, 0);
  allocp[2] = a2;
  x7 = makefunctor(&allocp[0]);
  allocp[3] = a4;
  allocp[4] = x7;
  x8 = makecons(&allocp[3]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_klic__comp__macro_xupdate__info__1_9);
  x9 = cdr_of(a0);
  allocp[7] = x9;
  allocp[8] = x5;
  allocp[9] = x10 = makeref(&allocp[9]);
  allocp[10] = a3;
  allocp[11] = x8;
  allocp[12] = a5;
  allocp[13] = x11 = makeref(&allocp[13]);
  x12 = arg(x0, 0);
  allocp[14] = x12;
  allocp[15] = x2;
  allocp[16] = (q)(struct goalrec*)&allocp[5];
  allocp[17] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[18] = a2;
  allocp[19] = makeint(1L);
  allocp[20] = x10;
  allocp[21] = (q)(struct goalrec*)&allocp[16];
  allocp[22] = (q)(&predicate_klic__comp__util_xassoc_3);
  allocp[23] = a4;
  allocp[24] = x12;
  allocp[25] = x11;
  qp = (struct goalrec*)&allocp[21];
  allocp += 26;
  proceed();
 case functor__2B_1:
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = x3 = makeref(&allocp[1]);
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xupdate__info_6);
  x4 = cdr_of(a0);
  allocp[2] = x4;
  allocp[3] = x2;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  a0 = arg(x0, 0);
  a1 = x3;
  a2 = a4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  execute(replace__vars_3_0);
  goto replace__vars_3_ext_interrupt;
  };
  goto update__info_6_interrupt;
 case VARREF:
  deref_and_jump(x0,update__info_6_2);
  *reasonp++ =  x0;
  goto update__info_6_interrupt;
  };
  goto update__info_6_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto update__info_6_interrupt;
  unify2(a3, a2, a5, a4);
  unify_value(a1, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a0,update__info_6_1);
  *reasonp++ =  a0;
  goto update__info_6_interrupt;
  };
  goto update__info_6_interrupt;
 update__info_6_ext_interrupt:
  reasonp = 0l;
 update__info_6_interrupt:
  toppred = &predicate_klic__comp__macro_xupdate__info_6;
  goto interrupt_6;
 }

 update__info__1_9_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 update__info__1_9_clear_reason:
  reasonp = reasons;
 update__info__1_9_0:
 update__info__1_9_1:
  switch (ptagof(a6)) {
 case ATOMIC:
  if (a6 != makesym(atom_no)) goto update__info__1_9_interrupt;
  unify(a8, a7);
  execute(update__info_6_0);
  goto update__info_6_ext_interrupt;
 case FUNCTOR:
  if (functor_of(a6) != makesym(functor_yes_1)) goto update__info__1_9_interrupt;
  x0 = arg(a6, 0);
  unify(a8, x0);
  execute(update__info_6_0);
  goto update__info_6_ext_interrupt;
 case VARREF:
  deref_and_jump(a6,update__info__1_9_1);
  *reasonp++ =  a6;
  goto update__info__1_9_interrupt;
  };
  goto update__info__1_9_interrupt;
 update__info__1_9_ext_interrupt:
  reasonp = 0l;
 update__info__1_9_interrupt:
  goto interrupt_9;
 }

 replace__vars_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  qp = qp->next;
 replace__vars_3_clear_reason:
  reasonp = reasons;
 replace__vars_3_0:
 replace__vars_3_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_variable_1:
  allocp[0] = makesym(functor_variable_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xreplace__vars__1_3);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x1;
  x3 = arg(a0, 0);
  allocp[4] = x3;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_klic__comp__util_xassoc_3);
  allocp[7] = a2;
  allocp[8] = x3;
  allocp[9] = x2;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case functor_list_1:
  x0 = arg(a0, 0);
 replace__vars_3_2:
  switch (ptagof(x0)) {
 case CONS:
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = x3 = makeref(&allocp[1]);
  x1 = makecons(&allocp[0]);
  allocp[2] = makesym(functor_list_1);
  allocp[3] = x1;
  x4 = makefunctor(&allocp[2]);
  allocp += 4;
  unify_value(a1, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xreplace__vars_3);
  x5 = cdr_of(x0);
  allocp[2] = x5;
  allocp[3] = x2;
  allocp[4] = a2;
  a0 = car_of(x0);
  a1 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(replace__vars_3_0);
  goto replace__vars_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,replace__vars_3_2);
  *reasonp++ =  x0;
  goto replace__vars_3_3;
  };
  goto replace__vars_3_3;
 case functor_vector_1:
  allocp[0] = makesym(functor_vector_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = x2 = makeref(&allocp[0]);
  generic_arg[0] = x2;
  new_generic(vector_g_new, 1, x3, 1);
  unify(x1, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xreplace__vars__elems_3);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = x2;
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_klic__comp__util_xvector__to__list_2);
  x5 = arg(a0, 0);
  allocp[7] = x5;
  allocp[8] = x4;
  qp = (struct goalrec*)&allocp[5];
  allocp += 9;
  proceed();
 case functor_functor_1:
  allocp[0] = makesym(functor_functor_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = x3 = makeref(&allocp[0]);
  allocp[1] = x4 = makeref(&allocp[1]);
  x2 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[4] = x1;
  allocp[5] = x2;
  allocp[6] = (q)(struct goalrec*)&allocp[2];
  allocp[7] = (q)(&predicate_klic__comp__macro_xreplace__vars__elems_3);
  allocp[8] = x5 = makeref(&allocp[8]);
  allocp[9] = x3;
  allocp[10] = a2;
  allocp[11] = x5;
  allocp[12] = x4;
  x6 = makecons(&allocp[11]);
  allocp[13] = (q)(struct goalrec*)&allocp[6];
  allocp[14] = (q)(&predicate_klic__comp__util_xuniv_2);
  x7 = arg(a0, 0);
  allocp[15] = x7;
  allocp[16] = x6;
  qp = (struct goalrec*)&allocp[13];
  allocp += 17;
  proceed();
  };
  goto replace__vars_3_3;
 case VARREF:
  deref_and_jump(a0,replace__vars_3_1);
  *reasonp++ =  a0;
  goto replace__vars_3_3;
  };
  goto replace__vars_3_3;
 replace__vars_3_3:
  otherwise(replace__vars_3_interrupt);
  unify(a1, a0);
  proceed();
 replace__vars_3_ext_interrupt:
  reasonp = 0l;
 replace__vars_3_interrupt:
  toppred = &predicate_klic__comp__macro_xreplace__vars_3;
  goto interrupt_3;
 }

 replace__vars__1_3_top: {
  q x0;
  a2 = qp->args[2];
  qp = qp->next;
 replace__vars__1_3_clear_reason:
  reasonp = reasons;
 replace__vars__1_3_0:
 replace__vars__1_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_no)) goto replace__vars__1_3_interrupt;
  unify(a1, a2);
  proceed();
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_yes_1)) goto replace__vars__1_3_interrupt;
  x0 = arg(a0, 0);
  unify(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,replace__vars__1_3_1);
  *reasonp++ =  a0;
  goto replace__vars__1_3_interrupt;
  };
  goto replace__vars__1_3_interrupt;
 replace__vars__1_3_ext_interrupt:
  reasonp = 0l;
 replace__vars__1_3_interrupt:
  goto interrupt_3;
 }

 replace__vars__elems_3_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  qp = qp->next;
 replace__vars__elems_3_clear_reason:
  reasonp = reasons;
 replace__vars__elems_3_0:
 replace__vars__elems_3_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xreplace__vars__elems_3);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x1;
  allocp[6] = x3 = makeref(&allocp[6]);
  x2 = makecons(&allocp[5]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  unify_value(a1, x2);
  a0 = car_of(a0);
  a1 = x3;
  execute(replace__vars_3_0);
  goto replace__vars_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto replace__vars__elems_3_interrupt;
  unify_value(a1, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a0,replace__vars__elems_3_1);
  *reasonp++ =  a0;
  goto replace__vars__elems_3_interrupt;
  };
  goto replace__vars__elems_3_interrupt;
 replace__vars__elems_3_ext_interrupt:
  reasonp = 0l;
 replace__vars__elems_3_interrupt:
  goto interrupt_3;
 }

 countvars_2_top: {
  q x0;
  qp = qp->next;
 countvars_2_clear_reason:
  reasonp = reasons;
 countvars_2_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xcountvars_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = NILATOM;
  a1 = x0;
  a2 = NILATOM;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(findvars_3_0);
  goto findvars_3_ext_interrupt;
 countvars_2_ext_interrupt:
  reasonp = 0l;
 countvars_2_interrupt:
  toppred = &predicate_klic__comp__macro_xcountvars_2;
  goto interrupt_2;
 }

 countvars_3_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  qp = qp->next;
 countvars_3_clear_reason:
  reasonp = reasons;
 countvars_3_0:
 countvars_3_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xcountvars_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = makesym(functor__3D_2);
  allocp[6] = car_of(a0);
  allocp[7] = x3 = makeref(&allocp[7]);
  x2 = makefunctor(&allocp[5]);
  allocp[8] = x1;
  allocp[9] = x2;
  x4 = makecons(&allocp[8]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  unify_value(a1, x4);
  x5 = cdr_of(a0);
  a1 = x0;
  a2 = car_of(a0);
  a3 = makeint(1L);
  a4 = x3;
  a0 = x5;
  execute(countsame_5_0);
  goto countsame_5_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto countvars_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,countvars_3_1);
  *reasonp++ =  a0;
  goto countvars_3_interrupt;
  };
  goto countvars_3_interrupt;
 countvars_3_ext_interrupt:
  reasonp = 0l;
 countvars_3_interrupt:
  goto interrupt_3;
 }

 findvars_3_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  qp = qp->next;
 findvars_3_clear_reason:
  reasonp = reasons;
 findvars_3_0:
 findvars_3_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_variable_1)) goto findvars_3_4;
  x0 = arg(a0, 0);
 findvars_3_2:
  if (!isint(x0)) goto findvars_3_3;
  gblt_integer(x0,findvars_3_4);
  allocp[0] = a2;
  allocp[1] = x0;
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x1);
  proceed();
 findvars_3_3:
  if (!isref(x0)) goto findvars_3_4;
  deref_and_jump(x0,findvars_3_2);
  *reasonp++ =  x0;
  goto findvars_3_4;
 findvars_3_4:
  if (!isgobj(a0)) goto findvars_3_5;
  if (!isclass(a0,vector)) goto findvars_3_5;
  gblt_size_of_vector(a0,x0,findvars_3_5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xfindvars__elems_3);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_klic__comp__util_xvector__to__list_2);
  allocp[7] = a0;
  allocp[8] = x1;
  qp = (struct goalrec*)&allocp[5];
  allocp += 9;
  proceed();
 case VARREF:
  deref_and_jump(a0,findvars_3_1);
  *reasonp++ =  a0;
  goto findvars_3_5;
  };
  goto findvars_3_5;
 findvars_3_5:
  otherwise(findvars_3_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xfindvars__elems_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x0;
  allocp[6] = x2 = makeref(&allocp[6]);
  x1 = makecons(&allocp[5]);
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_klic__comp__util_xuniv_2);
  allocp[9] = a0;
  allocp[10] = x1;
  qp = (struct goalrec*)&allocp[7];
  allocp += 11;
  proceed();
 findvars_3_ext_interrupt:
  reasonp = 0l;
 findvars_3_interrupt:
  toppred = &predicate_klic__comp__macro_xfindvars_3;
  goto interrupt_3;
 }

 findvars__elems_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 findvars__elems_3_clear_reason:
  reasonp = reasons;
 findvars__elems_3_0:
 findvars__elems_3_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xfindvars__elems_3);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  a0 = car_of(a0);
  a2 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(findvars_3_0);
  goto findvars_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto findvars__elems_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,findvars__elems_3_1);
  *reasonp++ =  a0;
  goto findvars__elems_3_interrupt;
  };
  goto findvars__elems_3_interrupt;
 findvars__elems_3_ext_interrupt:
  reasonp = 0l;
 findvars__elems_3_interrupt:
  goto interrupt_3;
 }

 countsame_5_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 countsame_5_clear_reason:
  reasonp = reasons;
 countsame_5_0:
 countsame_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 countsame_5_2:
  if (!isint(x0)) goto countsame_5_6;
 countsame_5_3:
  if (!isint(a2)) goto countsame_5_5;
  gblt_eq(x0,a2,countsame_5_4);
  bblt_add_no_check_y(a3,makeint(1L),x1);
  a0 = cdr_of(a0);
  a3 = x1;
  execute(countsame_5_0);
  goto countsame_5_ext_interrupt;
 countsame_5_4:
  gblt_not_eq(x0,a2,countsame_5_interrupt);
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = x0;
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x1);
  a0 = cdr_of(a0);
  a1 = x2;
  execute(countsame_5_0);
  goto countsame_5_ext_interrupt;
 countsame_5_5:
  if (!isref(a2)) goto countsame_5_interrupt;
  deref_and_jump(a2,countsame_5_3);
  *reasonp++ =  a2;
  goto countsame_5_interrupt;
 countsame_5_6:
  if (!isref(x0)) goto countsame_5_interrupt;
  deref_and_jump(x0,countsame_5_2);
  *reasonp++ =  x0;
  goto countsame_5_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto countsame_5_interrupt;
  unify(a4, a3);
  unify_value(a1, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a0,countsame_5_1);
  *reasonp++ =  a0;
  goto countsame_5_interrupt;
  };
  goto countsame_5_interrupt;
 countsame_5_ext_interrupt:
  reasonp = 0l;
 countsame_5_interrupt:
  toppred = &predicate_klic__comp__macro_xcountsame_5;
  goto interrupt_5;
 }

 finalize__vars_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 finalize__vars_4_clear_reason:
  reasonp = reasons;
 finalize__vars_4_0:
 finalize__vars_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = cdr_of(a0);
 finalize__vars_4_2:
  switch (ptagof(x0)) {
 case CONS:
  allocp[0] = makesym(functor_variable_1);
  allocp[1] = car_of(x0);
  x1 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_variable_1);
  allocp[3] = x3 = makeref(&allocp[3]);
  x2 = makefunctor(&allocp[2]);
  allocp[4] = makesym(functor__3D_2);
  allocp[5] = x1;
  allocp[6] = x2;
  x4 = makefunctor(&allocp[4]);
  allocp[7] = makesym(functor_functor_1);
  allocp[8] = x4;
  x5 = makefunctor(&allocp[7]);
  allocp[9] = makesym(functor__2C_2);
  allocp[10] = x5;
  allocp[11] = a2;
  x6 = makefunctor(&allocp[9]);
  allocp[12] = makesym(functor_functor_1);
  allocp[13] = x6;
  x7 = makefunctor(&allocp[12]);
  allocp[14] = (q)qp;
  allocp[15] = (q)(&predicate_klic__comp__macro_xfinalize__vars_4);
  x8 = cdr_of(x0);
  allocp[16] = x8;
  allocp[17] = a1;
  allocp[18] = x7;
  allocp[19] = a3;
  allocp[20] = makesym(functor_yes_1);
  allocp[21] = x3;
  x9 = makefunctor(&allocp[20]);
  allocp[22] = (q)(struct goalrec*)&allocp[14];
  allocp[23] = (q)(&predicate_klic__comp__util_xassoc_3);
  allocp[24] = a1;
  x10 = car_of(a0);
  allocp[25] = x10;
  allocp[26] = x9;
  qp = (struct goalrec*)&allocp[22];
  allocp += 27;
  proceed();
 case VARREF:
  deref_and_jump(x0,finalize__vars_4_2);
  *reasonp++ =  x0;
  goto finalize__vars_4_interrupt;
  };
  goto finalize__vars_4_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto finalize__vars_4_interrupt;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,finalize__vars_4_1);
  *reasonp++ =  a0;
  goto finalize__vars_4_interrupt;
  };
  goto finalize__vars_4_interrupt;
 finalize__vars_4_ext_interrupt:
  reasonp = 0l;
 finalize__vars_4_interrupt:
  goto interrupt_4;
 }

 exp__head_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 exp__head_6_clear_reason:
  reasonp = reasons;
 exp__head_6_0:
 exp__head_6_1:
  if (isref(a0)) goto exp__head_6_2;
  gblt_pfunctor(a0,x0,exp__head_6_interrupt);
  gblt_arity(a0,x1,exp__head_6_interrupt);
  allocp[0] = makesym(functor_functor_1);
  allocp[1] = x3 = makeref(&allocp[1]);
  x2 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x2);
  allocp[0] = x5 = makeref(&allocp[0]);
  allocp[1] = x0;
  x4 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[4] = x3;
  allocp[5] = x4;
  allocp[6] = (q)(struct goalrec*)&allocp[2];
  allocp[7] = (q)(&predicate_klic__comp__macro_xexp__head__and__guard__top_6);
  allocp[8] = x6 = makeref(&allocp[8]);
  allocp[9] = x5;
  allocp[10] = a2;
  allocp[11] = a3;
  allocp[12] = a4;
  allocp[13] = a5;
  allocp[14] = x6;
  allocp[15] = x0;
  x7 = makecons(&allocp[14]);
  allocp[16] = (q)(struct goalrec*)&allocp[6];
  allocp[17] = (q)(&predicate_klic__comp__util_xuniv_2);
  allocp[18] = a0;
  allocp[19] = x7;
  qp = (struct goalrec*)&allocp[16];
  allocp += 20;
  proceed();
 exp__head_6_2:
  deref_and_jump(a0,exp__head_6_1);
  *reasonp++ =  a0;
  goto exp__head_6_interrupt;
 exp__head_6_ext_interrupt:
  reasonp = 0l;
 exp__head_6_interrupt:
  goto interrupt_6;
 }

 exp__head__and__guard__top_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 exp__head__and__guard__top_6_clear_reason:
  reasonp = reasons;
 exp__head__and__guard__top_6_0:
 exp__head__and__guard__top_6_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = makesym(functor_variable_1);
  allocp[1] = a2;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x0;
  x1 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a1, x1);
  allocp[0] = makesym(functor_variable_1);
  allocp[1] = a2;
  x3 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__3D_2);
  allocp[3] = car_of(a0);
  allocp[4] = x3;
  x4 = makefunctor(&allocp[2]);
  allocp[5] = makesym(functor_functor_1);
  allocp[6] = x4;
  x5 = makefunctor(&allocp[5]);
  allocp[7] = x7 = makeref(&allocp[7]);
  allocp[8] = x5;
  x6 = makecons(&allocp[7]);
  allocp += 9;
  unify_value(a4, x6);
  bblt_add_no_check_y(a2,makeint(1L),x8);
  a0 = cdr_of(a0);
  a1 = x2;
  a2 = x8;
  a4 = x7;
  execute(exp__head__and__guard__top_6_0);
  goto exp__head__and__guard__top_6_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto exp__head__and__guard__top_6_interrupt;
  unify2(a5, a4, a3, a2);
  unify_value(a1, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a0,exp__head__and__guard__top_6_1);
  *reasonp++ =  a0;
  goto exp__head__and__guard__top_6_interrupt;
  };
  goto exp__head__and__guard__top_6_interrupt;
 exp__head__and__guard__top_6_ext_interrupt:
  reasonp = 0l;
 exp__head__and__guard__top_6_interrupt:
  goto interrupt_6;
 }

 linearize__guard_3_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  qp = qp->next;
 linearize__guard_3_clear_reason:
  reasonp = reasons;
 linearize__guard_3_0:
 linearize__guard_3_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_atom_1:
  x0 = arg(a0, 0);
 linearize__guard_3_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_true)) goto linearize__guard_3_4;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(x0,linearize__guard_3_2);
  *reasonp++ =  x0;
  goto linearize__guard_3_4;
  };
  goto linearize__guard_3_4;
 case functor_functor_1:
  x0 = arg(a0, 0);
 linearize__guard_3_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__2C_2)) goto linearize__guard_3_4;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xlinearize__guard_3);
  x1 = arg(x0, 1);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  a0 = arg(x0, 0);
  a2 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(linearize__guard_3_0);
  goto linearize__guard_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,linearize__guard_3_3);
  *reasonp++ =  x0;
  goto linearize__guard_3_4;
  };
  goto linearize__guard_3_4;
  };
  goto linearize__guard_3_4;
 case VARREF:
  deref_and_jump(a0,linearize__guard_3_1);
  *reasonp++ =  a0;
  goto linearize__guard_3_4;
  };
  goto linearize__guard_3_4;
 linearize__guard_3_4:
  otherwise(linearize__guard_3_interrupt);
  allocp[0] = a2;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  proceed();
 linearize__guard_3_ext_interrupt:
  reasonp = 0l;
 linearize__guard_3_interrupt:
  toppred = &predicate_klic__comp__macro_xlinearize__guard_3;
  goto interrupt_3;
 }

 exp__guard_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 exp__guard_5_clear_reason:
  reasonp = reasons;
 exp__guard_5_0:
 exp__guard_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 exp__guard_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_functor_1)) goto exp__guard_5_4;
  x1 = arg(x0, 0);
 exp__guard_5_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor__3B_2)) goto exp__guard_5_4;
  allocp[0] = makesym(functor__3B_2);
  allocp[1] = x3 = makeref(&allocp[1]);
  allocp[2] = x4 = makeref(&allocp[2]);
  x2 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_functor_1);
  allocp[4] = x2;
  x5 = makefunctor(&allocp[3]);
  allocp[5] = a4;
  allocp[6] = x5;
  x6 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a3, x6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xexp__guard_5);
  allocp[2] = x7 = makeref(&allocp[2]);
  allocp[3] = x8 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x4;
  allocp[6] = NILATOM;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_klic__comp__macro_xlinearize__guard_3);
  x9 = arg(x1, 1);
  allocp[9] = x9;
  allocp[10] = x7;
  x10 = cdr_of(a0);
  allocp[11] = x10;
  allocp[12] = (q)(struct goalrec*)&allocp[7];
  allocp[13] = (q)(&predicate_klic__comp__macro_xexp__guard_5);
  allocp[14] = x11 = makeref(&allocp[14]);
  allocp[15] = a1;
  allocp[16] = x8;
  allocp[17] = x3;
  allocp[18] = NILATOM;
  a0 = arg(x1, 0);
  a1 = x11;
  a2 = x10;
  qp = (struct goalrec*)&allocp[12];
  allocp += 19;
  execute(linearize__guard_3_0);
  goto linearize__guard_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,exp__guard_5_3);
  *reasonp++ =  x1;
  goto exp__guard_5_4;
  };
  goto exp__guard_5_4;
 case VARREF:
  deref_and_jump(x0,exp__guard_5_2);
  *reasonp++ =  x0;
  goto exp__guard_5_4;
  };
  goto exp__guard_5_4;
 case ATOMIC:
  if (a0 != NILATOM) goto exp__guard_5_4;
  unify2(a4, a3, a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,exp__guard_5_1);
  *reasonp++ =  a0;
  goto exp__guard_5_4;
  };
  goto exp__guard_5_4;
 exp__guard_5_4:
  otherwise(exp__guard_5_interrupt);
 exp__guard_5_5:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xexp__guard_5);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  a0 = car_of(a0);
  a2 = x1;
  allocp[7] = x4 = makeref(&allocp[7]);
  x3 = x4;
  a4 = x2;
  a5 = a3;
  a6 = x4;
  a7 = makesym(atom_g);
  a3 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  execute(macro__goal_8_0);
  goto macro__goal_8_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,exp__guard_5_5);
  *reasonp++ =  a0;
  goto exp__guard_5_interrupt;
  };
  goto exp__guard_5_interrupt;
 exp__guard_5_ext_interrupt:
  reasonp = 0l;
 exp__guard_5_interrupt:
  goto interrupt_5;
 }

 exp__body_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 exp__body_8_clear_reason:
  reasonp = reasons;
 exp__body_8_0:
 exp__body_8_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_atom_1:
  x0 = arg(a0, 0);
 exp__body_8_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_true)) goto exp__body_8_4;
  unify3(a7, a6, a5, a4, a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(x0,exp__body_8_2);
  *reasonp++ =  x0;
  goto exp__body_8_4;
  };
  goto exp__body_8_4;
 case functor_functor_1:
  x0 = arg(a0, 0);
 exp__body_8_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor__2C_2:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xexp__body_8);
  x1 = arg(x0, 1);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = a7;
  a0 = arg(x0, 0);
  a2 = x2;
  a5 = x3;
  a7 = x4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  execute(exp__body_8_0);
  goto exp__body_8_ext_interrupt;
 case functor__2D_3E_2:
  unify(a2, a1);
  allocp[0] = makesym(functor_expanded_2);
  allocp[1] = x2 = makeref(&allocp[1]);
  allocp[2] = x3 = makeref(&allocp[2]);
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a5;
  allocp[4] = x1;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a4, x4);
  allocp[0] = a7;
  allocp[1] = x6 = makeref(&allocp[1]);
  x5 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a6, x5);
  a2 = x3;
  x7 = a1;
  a4 = a3;
  a5 = x2;
  a3 = x7;
  a1 = x6;
  execute(exp__body__or_6_0);
  goto exp__body__or_6_ext_interrupt;
 case functor__3B_2:
  unify(a2, a1);
  allocp[0] = makesym(functor_expanded_2);
  allocp[1] = x2 = makeref(&allocp[1]);
  allocp[2] = x3 = makeref(&allocp[2]);
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a5;
  allocp[4] = x1;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a4, x4);
  allocp[0] = a7;
  allocp[1] = x6 = makeref(&allocp[1]);
  x5 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a6, x5);
  a2 = x3;
  x7 = a1;
  a4 = a3;
  a5 = x2;
  a3 = x7;
  a1 = x6;
  execute(exp__body__or_6_0);
  goto exp__body__or_6_ext_interrupt;
  };
  goto exp__body_8_4;
 case VARREF:
  deref_and_jump(x0,exp__body_8_3);
  *reasonp++ =  x0;
  goto exp__body_8_4;
  };
  goto exp__body_8_4;
  };
  goto exp__body_8_4;
 case VARREF:
  deref_and_jump(a0,exp__body_8_1);
  *reasonp++ =  a0;
  goto exp__body_8_4;
  };
  goto exp__body_8_4;
 exp__body_8_4:
  otherwise(exp__body_8_interrupt);
  unify(a5, a4);
  allocp[0] = x0 = makeref(&allocp[0]);
  a3 = x0;
  a4 = a7;
  a5 = a6;
  a6 = x0;
  a7 = makesym(atom_b);
  allocp += 1;
  execute(macro__goal_8_0);
  goto macro__goal_8_ext_interrupt;
 exp__body_8_ext_interrupt:
  reasonp = 0l;
 exp__body_8_interrupt:
  goto interrupt_8;
 }

 exp__body__or_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 exp__body__or_6_clear_reason:
  reasonp = reasons;
 exp__body__or_6_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xbody__or__clauses_6);
  allocp[2] = a0;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a3;
  allocp[5] = a4;
  allocp[6] = a5;
  allocp[7] = NILATOM;
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = a2;
  x1 = makecons(&allocp[8]);
  allocp[10] = x1;
  allocp[11] = makesym(atom__24macroexpanded);
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[14] = x0;
  allocp[15] = x3;
  allocp[16] = NILATOM;
  allocp[17] = x2;
  x4 = makecons(&allocp[16]);
  allocp[18] = x4;
  allocp[19] = a2;
  x5 = makecons(&allocp[18]);
  allocp[20] = x5;
  allocp[21] = makesym(atom__24macroexpanded);
  x6 = makecons(&allocp[20]);
  allocp[22] = (q)(struct goalrec*)&allocp[12];
  allocp[23] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[24] = a1;
  allocp[25] = x6;
  allocp[26] = (q)(struct goalrec*)&allocp[22];
  allocp[27] = (q)(&predicate_klic__comp__macro_xfind__interface__vars_3);
  allocp[28] = x7 = makeref(&allocp[28]);
  allocp[29] = a4;
  allocp[30] = x2;
  a1 = x7;
  qp = (struct goalrec*)&allocp[26];
  allocp += 31;
  execute(countvars_2_0);
  goto countvars_2_ext_interrupt;
 exp__body__or_6_ext_interrupt:
  reasonp = 0l;
 exp__body__or_6_interrupt:
  toppred = &predicate_klic__comp__macro_xexp__body__or_6;
  goto interrupt_6;
 }

 find__interface__vars_3_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  qp = qp->next;
 find__interface__vars_3_clear_reason:
  reasonp = reasons;
 find__interface__vars_3_0:
 find__interface__vars_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 find__interface__vars_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__3D_2)) goto find__interface__vars_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xfind__interface__vars__1_6);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = a2;
  x2 = arg(x0, 0);
  allocp[5] = x2;
  x3 = arg(x0, 1);
  allocp[6] = x3;
  allocp[7] = x4 = makeref(&allocp[7]);
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_klic__comp__util_xassoc_3);
  allocp[10] = a1;
  allocp[11] = x2;
  allocp[12] = x4;
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  proceed();
 case VARREF:
  deref_and_jump(x0,find__interface__vars_3_2);
  *reasonp++ =  x0;
  goto find__interface__vars_3_interrupt;
  };
  goto find__interface__vars_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto find__interface__vars_3_interrupt;
  unify_value(a2, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a0,find__interface__vars_3_1);
  *reasonp++ =  a0;
  goto find__interface__vars_3_interrupt;
  };
  goto find__interface__vars_3_interrupt;
 find__interface__vars_3_ext_interrupt:
  reasonp = 0l;
 find__interface__vars_3_interrupt:
  toppred = &predicate_klic__comp__macro_xfind__interface__vars_3;
  goto interrupt_3;
 }

 find__interface__vars__1_6_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 find__interface__vars__1_6_clear_reason:
  reasonp = reasons;
 find__interface__vars__1_6_0:
 find__interface__vars__1_6_1:
  switch (ptagof(a5)) {
 case FUNCTOR:
  if (functor_of(a5) != makesym(functor_yes_1)) goto find__interface__vars__1_6_6;
  x0 = arg(a5, 0);
 find__interface__vars__1_6_2:
  if (isref(x0)) goto find__interface__vars__1_6_5;
 find__interface__vars__1_6_3:
  if (isref(x0)) goto find__interface__vars__1_6_4;
  if_not_equal(x0, a4, find__interface__vars__1_6_6);
  execute(find__interface__vars_3_clear_reason);
  goto find__interface__vars_3_ext_interrupt;
 find__interface__vars__1_6_4:
  deref_and_jump(x0,find__interface__vars__1_6_3);
  *reasonp++ =  x0;
  goto find__interface__vars__1_6_6;
 find__interface__vars__1_6_5:
  deref_and_jump(x0,find__interface__vars__1_6_2);
  *reasonp++ =  x0;
  goto find__interface__vars__1_6_6;
 case VARREF:
  deref_and_jump(a5,find__interface__vars__1_6_1);
  *reasonp++ =  a5;
  goto find__interface__vars__1_6_6;
  };
  goto find__interface__vars__1_6_6;
 find__interface__vars__1_6_6:
  otherwise(find__interface__vars__1_6_interrupt);
  allocp[0] = makesym(functor_variable_1);
  allocp[1] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x0;
  x1 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a2, x1);
  a2 = x2;
  execute(find__interface__vars_3_0);
  goto find__interface__vars_3_ext_interrupt;
 find__interface__vars__1_6_ext_interrupt:
  reasonp = 0l;
 find__interface__vars__1_6_interrupt:
  goto interrupt_6;
 }

 body__or__clauses_6_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 body__or__clauses_6_clear_reason:
  reasonp = reasons;
 body__or__clauses_6_0:
 body__or__clauses_6_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_functor_1)) goto body__or__clauses_6_3;
  x0 = arg(a0, 0);
 body__or__clauses_6_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__3B_2)) goto body__or__clauses_6_3;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xbody__or__clauses_6);
  x1 = arg(x0, 1);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  a0 = arg(x0, 0);
  a5 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  execute(body__or__one_6_0);
  goto body__or__one_6_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,body__or__clauses_6_2);
  *reasonp++ =  x0;
  goto body__or__clauses_6_3;
  };
  goto body__or__clauses_6_3;
 case VARREF:
  deref_and_jump(a0,body__or__clauses_6_1);
  *reasonp++ =  a0;
  goto body__or__clauses_6_3;
  };
  goto body__or__clauses_6_3;
 body__or__clauses_6_3:
  otherwise(body__or__clauses_6_interrupt);
  execute(body__or__one_6_0);
  goto body__or__one_6_ext_interrupt;
 body__or__clauses_6_ext_interrupt:
  reasonp = 0l;
 body__or__clauses_6_interrupt:
  goto interrupt_6;
 }

 body__or__one_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 body__or__one_6_clear_reason:
  reasonp = reasons;
 body__or__one_6_0:
 body__or__one_6_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_atom_1:
  x0 = arg(a0, 0);
 body__or__one_6_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (isint(x0)) goto body__or__one_6_4;
  switch (symval(x0)) {
 case symval(makesym(atom_otherwise)):
  allocp[0] = a5;
  allocp[1] = x0;
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a4, x1);
  proceed();
 case symval(makesym(atom_alternatively)):
  allocp[0] = a5;
  allocp[1] = x0;
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a4, x1);
  proceed();
  };
  goto body__or__one_6_4;
 case VARREF:
  deref_and_jump(x0,body__or__one_6_2);
  *reasonp++ =  x0;
  goto body__or__one_6_4;
  };
  goto body__or__one_6_4;
 case functor_functor_1:
  x0 = arg(a0, 0);
 body__or__one_6_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__2D_3E_2)) goto body__or__one_6_4;
  allocp[0] = makesym(functor_clause_4);
  allocp[1] = a1;
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  x1 = makefunctor(&allocp[0]);
  allocp[5] = a5;
  allocp[6] = x1;
  x5 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a4, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xexp__body_8);
  x6 = arg(x0, 1);
  allocp[2] = x6;
  allocp[3] = x7 = makeref(&allocp[3]);
  allocp[4] = x8 = makeref(&allocp[4]);
  allocp[5] = x9 = makeref(&allocp[5]);
  allocp[6] = x4;
  allocp[7] = NILATOM;
  allocp[8] = x3;
  allocp[9] = NILATOM;
  allocp[10] = x6;
  allocp[11] = arg(x0, 0);
  x10 = makecons(&allocp[10]);
  allocp[12] = x10;
  allocp[13] = a1;
  x11 = makecons(&allocp[12]);
  allocp[14] = (q)(struct goalrec*)&allocp[0];
  allocp[15] = (q)(&predicate_klic__comp__macro_xcountvars_2);
  allocp[16] = x11;
  allocp[17] = x9;
  allocp[18] = (q)(struct goalrec*)&allocp[14];
  allocp[19] = (q)(&predicate_klic__comp__macro_xexp__guard_5);
  allocp[20] = x12 = makeref(&allocp[20]);
  allocp[21] = a2;
  allocp[22] = x7;
  allocp[23] = x2;
  allocp[24] = NILATOM;
  a0 = arg(x0, 0);
  a1 = x12;
  a2 = NILATOM;
  qp = (struct goalrec*)&allocp[18];
  allocp += 25;
  execute(linearize__guard_3_0);
  goto linearize__guard_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,body__or__one_6_3);
  *reasonp++ =  x0;
  goto body__or__one_6_4;
  };
  goto body__or__one_6_4;
  };
  goto body__or__one_6_4;
 case VARREF:
  deref_and_jump(a0,body__or__one_6_1);
  *reasonp++ =  a0;
  goto body__or__one_6_4;
  };
  goto body__or__one_6_4;
 body__or__one_6_4:
  otherwise(body__or__one_6_interrupt);
  unify(a5, a4);
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__kl1cmp_xreport__error_2);
  allocp[4] = makefunctor(&string_const_1);
  allocp[5] = x0;
  qp = (struct goalrec*)&allocp[2];
  allocp += 6;
  proceed();
 body__or__one_6_ext_interrupt:
  reasonp = 0l;
 body__or__one_6_interrupt:
  toppred = &predicate_klic__comp__macro_xbody__or__one_6;
  goto interrupt_6;
 }

 macro__goal_8_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 macro__goal_8_clear_reason:
  reasonp = reasons;
 macro__goal_8_0:
 macro__goal_8_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_functor_1:
  a0 = arg(a0, 0);
  execute(macro__goal__functor_8_0);
  goto macro__goal__functor_8_ext_interrupt;
 case functor_atom_1:
  unify2(a4, a3, a2, a1);
  allocp[0] = makesym(functor_atom_1);
  allocp[1] = arg(a0, 0);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = a6;
  allocp[3] = x0;
  x1 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a5, x1);
  proceed();
  };
  goto macro__goal_8_2;
 case VARREF:
  deref_and_jump(a0,macro__goal_8_1);
  *reasonp++ =  a0;
  goto macro__goal_8_2;
  };
  goto macro__goal_8_2;
 macro__goal_8_2:
  otherwise(macro__goal_8_interrupt);
  unify3(a6, a5, a4, a3, a2, a1);
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__kl1cmp_xreport__error_2);
  allocp[4] = makefunctor(&string_const_0);
  allocp[5] = x0;
  qp = (struct goalrec*)&allocp[2];
  allocp += 6;
  proceed();
 macro__goal_8_ext_interrupt:
  reasonp = 0l;
 macro__goal_8_interrupt:
  toppred = &predicate_klic__comp__macro_xmacro__goal_8;
  goto interrupt_8;
 }

 macro__goal__functor_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 macro__goal__functor_8_clear_reason:
  reasonp = reasons;
 macro__goal__functor_8_0:
 macro__goal__functor_8_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor__3A_3D_2:
  allocp[0] = makesym(functor__3D_2);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  x0 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_functor_1);
  allocp[4] = x0;
  x3 = makefunctor(&allocp[3]);
  allocp[5] = a6;
  allocp[6] = x3;
  x4 = makecons(&allocp[5]);
  allocp[7] = (q)qp;
  allocp[8] = (q)(&predicate_klic__comp__macro_xmacro__exp_6);
  allocp[9] = x5 = makeref(&allocp[9]);
  allocp[10] = x2;
  allocp[11] = x6 = makeref(&allocp[11]);
  allocp[12] = a2;
  allocp[13] = x7 = makeref(&allocp[13]);
  allocp[14] = x4;
  allocp[15] = x1;
  allocp[16] = arg(a0, 0);
  x8 = makecons(&allocp[15]);
  allocp[17] = x5;
  allocp[18] = arg(a0, 1);
  x9 = makecons(&allocp[17]);
  allocp[19] = NILATOM;
  allocp[20] = x9;
  x10 = makecons(&allocp[19]);
  allocp[21] = x10;
  allocp[22] = x8;
  x11 = makecons(&allocp[21]);
  a0 = x11;
  a2 = x6;
  a6 = x7;
  qp = (struct goalrec*)&allocp[7];
  allocp += 23;
  execute(macro__arg__n_8_0);
  goto macro__arg__n_8_ext_interrupt;
 case functor__24_3A_3D_2:
  allocp[0] = makesym(functor__3D_2);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  x0 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_functor_1);
  allocp[4] = x0;
  x3 = makefunctor(&allocp[3]);
  allocp[5] = a6;
  allocp[6] = x3;
  x4 = makecons(&allocp[5]);
  allocp[7] = (q)qp;
  allocp[8] = (q)(&predicate_klic__comp__macro_xmacro__float__exp_6);
  allocp[9] = x5 = makeref(&allocp[9]);
  allocp[10] = x2;
  allocp[11] = x6 = makeref(&allocp[11]);
  allocp[12] = a2;
  allocp[13] = x7 = makeref(&allocp[13]);
  allocp[14] = x4;
  allocp[15] = x1;
  allocp[16] = arg(a0, 0);
  x8 = makecons(&allocp[15]);
  allocp[17] = x5;
  allocp[18] = arg(a0, 1);
  x9 = makecons(&allocp[17]);
  allocp[19] = NILATOM;
  allocp[20] = x9;
  x10 = makecons(&allocp[19]);
  allocp[21] = x10;
  allocp[22] = x8;
  x11 = makecons(&allocp[21]);
  a0 = x11;
  a2 = x6;
  a6 = x7;
  qp = (struct goalrec*)&allocp[7];
  allocp += 23;
  execute(macro__arg__n_8_0);
  goto macro__arg__n_8_ext_interrupt;
 case functor__5C_3D_2:
 macro__goal__functor_8_2:
  switch (ptagof(a7)) {
 case ATOMIC:
  if (a7 != makesym(atom_g)) goto macro__goal__functor_8_15;
  allocp[0] = makesym(functor_diff_2);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  x0 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_functor_1);
  allocp[4] = x0;
  x3 = makefunctor(&allocp[3]);
  allocp[5] = a6;
  allocp[6] = x3;
  x4 = makecons(&allocp[5]);
  allocp[7] = x1;
  allocp[8] = arg(a0, 0);
  x5 = makecons(&allocp[7]);
  allocp[9] = x2;
  allocp[10] = arg(a0, 1);
  x6 = makecons(&allocp[9]);
  allocp[11] = NILATOM;
  allocp[12] = x6;
  x7 = makecons(&allocp[11]);
  allocp[13] = x7;
  allocp[14] = x5;
  x8 = makecons(&allocp[13]);
  a0 = x8;
  a6 = x4;
  a7 = makesym(atom_g);
  allocp += 15;
  execute(macro__arg__n_8_0);
  goto macro__arg__n_8_ext_interrupt;
 case VARREF:
  deref_and_jump(a7,macro__goal__functor_8_2);
  *reasonp++ =  a7;
  goto macro__goal__functor_8_15;
  };
  goto macro__goal__functor_8_15;
 case functor_vector_1:
 macro__goal__functor_8_3:
  switch (ptagof(a7)) {
 case ATOMIC:
  if (a7 != makesym(atom_g)) goto macro__goal__functor_8_15;
  bblt_add_no_check_y(a1,makeint(1L),x0);
  allocp[0] = makesym(functor_variable_1);
  allocp[1] = a1;
  x1 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_vector_2);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x1;
  x2 = makefunctor(&allocp[2]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_klic__comp__macro_xmacro__goal__functor_8);
  allocp[7] = x2;
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = a2;
  allocp[10] = x5 = makeref(&allocp[10]);
  allocp[11] = a4;
  allocp[12] = x6 = makeref(&allocp[12]);
  allocp[13] = a6;
  allocp[14] = makesym(atom_g);
  a0 = arg(a0, 0);
  a1 = x3;
  a2 = makesym(atom_g);
  a4 = x4;
  x7 = a3;
  a6 = x5;
  a7 = a5;
  a8 = x6;
  a5 = x7;
  a3 = x0;
  qp = (struct goalrec*)&allocp[5];
  allocp += 15;
  execute(macro__arg_9_0);
  goto macro__arg_9_ext_interrupt;
 case VARREF:
  deref_and_jump(a7,macro__goal__functor_8_3);
  *reasonp++ =  a7;
  goto macro__goal__functor_8_15;
  };
  goto macro__goal__functor_8_15;
 case functor_string_1:
 macro__goal__functor_8_4:
  switch (ptagof(a7)) {
 case ATOMIC:
  if (a7 != makesym(atom_g)) goto macro__goal__functor_8_15;
  bblt_add_no_check_y(a1,makeint(1L),x0);
  bblt_add_no_check_y(a1,makeint(2L),x1);
  allocp[0] = makesym(functor_variable_1);
  allocp[1] = a1;
  x2 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_variable_1);
  allocp[3] = x0;
  x3 = makefunctor(&allocp[2]);
  allocp[4] = makesym(functor_string_3);
  allocp[5] = x5 = makeref(&allocp[5]);
  allocp[6] = x2;
  allocp[7] = x3;
  x4 = makefunctor(&allocp[4]);
  allocp[8] = (q)qp;
  allocp[9] = (q)(&predicate_klic__comp__macro_xmacro__goal__functor_8);
  allocp[10] = x4;
  allocp[11] = x6 = makeref(&allocp[11]);
  allocp[12] = a2;
  allocp[13] = x7 = makeref(&allocp[13]);
  allocp[14] = a4;
  allocp[15] = x8 = makeref(&allocp[15]);
  allocp[16] = a6;
  allocp[17] = makesym(atom_g);
  a0 = arg(a0, 0);
  a1 = x5;
  a2 = makesym(atom_g);
  a4 = x6;
  x9 = a3;
  a6 = x7;
  a7 = a5;
  a8 = x8;
  a5 = x9;
  a3 = x1;
  qp = (struct goalrec*)&allocp[8];
  allocp += 18;
  execute(macro__arg_9_0);
  goto macro__arg_9_ext_interrupt;
 case VARREF:
  deref_and_jump(a7,macro__goal__functor_8_4);
  *reasonp++ =  a7;
  goto macro__goal__functor_8_15;
  };
  goto macro__goal__functor_8_15;
 case functor_string_2:
 macro__goal__functor_8_5:
  switch (ptagof(a7)) {
 case ATOMIC:
  if (a7 != makesym(atom_g)) goto macro__goal__functor_8_15;
  allocp[0] = makesym(functor_variable_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_string_3);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = x0;
  x2 = makefunctor(&allocp[2]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_klic__comp__macro_xmacro__goal__functor_8);
  allocp[8] = x2;
  allocp[9] = x5 = makeref(&allocp[9]);
  allocp[10] = a2;
  allocp[11] = x6 = makeref(&allocp[11]);
  allocp[12] = a4;
  allocp[13] = x7 = makeref(&allocp[13]);
  allocp[14] = a6;
  allocp[15] = makesym(atom_g);
  allocp[16] = (q)(struct goalrec*)&allocp[6];
  allocp[17] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[18] = x8 = makeref(&allocp[18]);
  allocp[19] = makeint(1L);
  allocp[20] = x5;
  qp = (struct goalrec*)&allocp[16];
  allocp += 21;
  unify(x1, x8);
  allocp[0] = x3;
  allocp[1] = arg(a0, 0);
  x9 = makecons(&allocp[0]);
  allocp[2] = x4;
  allocp[3] = arg(a0, 1);
  x10 = makecons(&allocp[2]);
  allocp[4] = NILATOM;
  allocp[5] = x10;
  x11 = makecons(&allocp[4]);
  allocp[6] = x11;
  allocp[7] = x9;
  x12 = makecons(&allocp[6]);
  a0 = x12;
  a2 = x8;
  a4 = x6;
  a6 = x7;
  a7 = makesym(atom_g);
  allocp += 8;
  execute(macro__arg__n_8_0);
  goto macro__arg__n_8_ext_interrupt;
 case VARREF:
  deref_and_jump(a7,macro__goal__functor_8_5);
  *reasonp++ =  a7;
  goto macro__goal__functor_8_15;
  };
  goto macro__goal__functor_8_15;
 case functor_vector__element_4:
 macro__goal__functor_8_6:
  switch (ptagof(a7)) {
 case ATOMIC:
  if (a7 != makesym(atom_b)) goto macro__goal__functor_8_15;
  allocp[0] = makesym(functor_vector__element_3);
  allocp[1] = arg(a0, 0);
  allocp[2] = arg(a0, 1);
  allocp[3] = arg(a0, 2);
  x0 = makefunctor(&allocp[0]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_klic__comp__macro_xmacro__goal__functor_8);
  allocp[6] = x0;
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = a2;
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a4;
  allocp[11] = x3 = makeref(&allocp[11]);
  allocp[12] = a6;
  allocp[13] = makesym(atom_b);
  allocp[14] = makesym(functor__3D_2);
  allocp[15] = arg(a0, 0);
  allocp[16] = arg(a0, 3);
  x4 = makefunctor(&allocp[14]);
  a0 = x4;
  a2 = x1;
  a4 = x2;
  a6 = x3;
  a7 = makesym(atom_b);
  qp = (struct goalrec*)&allocp[4];
  allocp += 17;
  execute(macro__goal__functor_8_0);
  goto macro__goal__functor_8_ext_interrupt;
 case VARREF:
  deref_and_jump(a7,macro__goal__functor_8_6);
  *reasonp++ =  a7;
  goto macro__goal__functor_8_15;
  };
  goto macro__goal__functor_8_15;
 case functor_string_4:
 macro__goal__functor_8_7:
  switch (ptagof(a7)) {
 case ATOMIC:
  if (a7 != makesym(atom_b)) goto macro__goal__functor_8_15;
  allocp[0] = makesym(functor_string_3);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  x0 = makefunctor(&allocp[0]);
  allocp[4] = makesym(functor_functor_1);
  allocp[5] = x0;
  x4 = makefunctor(&allocp[4]);
  allocp[6] = makesym(functor__3A_2);
  allocp[7] = makefunctor(funct_const_13);
  allocp[8] = x4;
  x5 = makefunctor(&allocp[6]);
  allocp[9] = makesym(functor_functor_1);
  allocp[10] = x5;
  x6 = makefunctor(&allocp[9]);
  allocp[11] = a6;
  allocp[12] = x6;
  x7 = makecons(&allocp[11]);
  allocp[13] = makesym(functor__3D_2);
  allocp[14] = x1;
  allocp[15] = x9 = makeref(&allocp[15]);
  x8 = makefunctor(&allocp[13]);
  allocp[16] = makesym(functor_functor_1);
  allocp[17] = x8;
  x10 = makefunctor(&allocp[16]);
  allocp[18] = x7;
  allocp[19] = x10;
  x11 = makecons(&allocp[18]);
  allocp[20] = x1;
  allocp[21] = arg(a0, 0);
  x12 = makecons(&allocp[20]);
  allocp[22] = x2;
  allocp[23] = arg(a0, 1);
  x13 = makecons(&allocp[22]);
  allocp[24] = x3;
  allocp[25] = arg(a0, 2);
  x14 = makecons(&allocp[24]);
  allocp[26] = x9;
  allocp[27] = arg(a0, 3);
  x15 = makecons(&allocp[26]);
  allocp[28] = NILATOM;
  allocp[29] = x15;
  x16 = makecons(&allocp[28]);
  allocp[30] = x16;
  allocp[31] = x14;
  x17 = makecons(&allocp[30]);
  allocp[32] = x17;
  allocp[33] = x13;
  x18 = makecons(&allocp[32]);
  allocp[34] = x18;
  allocp[35] = x12;
  x19 = makecons(&allocp[34]);
  a0 = x19;
  a6 = x11;
  a7 = makesym(atom_b);
  allocp += 36;
  execute(macro__arg__n_8_0);
  goto macro__arg__n_8_ext_interrupt;
 case VARREF:
  deref_and_jump(a7,macro__goal__functor_8_7);
  *reasonp++ =  a7;
  goto macro__goal__functor_8_15;
  };
  goto macro__goal__functor_8_15;
 case functor_string__element_4:
 macro__goal__functor_8_8:
  switch (ptagof(a7)) {
 case ATOMIC:
  if (a7 != makesym(atom_b)) goto macro__goal__functor_8_15;
  allocp[0] = makesym(functor_element_3);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  x0 = makefunctor(&allocp[0]);
  allocp[4] = makesym(functor_functor_1);
  allocp[5] = x0;
  x4 = makefunctor(&allocp[4]);
  allocp[6] = makesym(functor__3A_2);
  allocp[7] = makefunctor(funct_const_13);
  allocp[8] = x4;
  x5 = makefunctor(&allocp[6]);
  allocp[9] = makesym(functor_functor_1);
  allocp[10] = x5;
  x6 = makefunctor(&allocp[9]);
  allocp[11] = a6;
  allocp[12] = x6;
  x7 = makecons(&allocp[11]);
  allocp[13] = makesym(functor__3D_2);
  allocp[14] = x1;
  allocp[15] = x9 = makeref(&allocp[15]);
  x8 = makefunctor(&allocp[13]);
  allocp[16] = makesym(functor_functor_1);
  allocp[17] = x8;
  x10 = makefunctor(&allocp[16]);
  allocp[18] = x7;
  allocp[19] = x10;
  x11 = makecons(&allocp[18]);
  allocp[20] = x1;
  allocp[21] = arg(a0, 0);
  x12 = makecons(&allocp[20]);
  allocp[22] = x2;
  allocp[23] = arg(a0, 1);
  x13 = makecons(&allocp[22]);
  allocp[24] = x3;
  allocp[25] = arg(a0, 2);
  x14 = makecons(&allocp[24]);
  allocp[26] = x9;
  allocp[27] = arg(a0, 3);
  x15 = makecons(&allocp[26]);
  allocp[28] = NILATOM;
  allocp[29] = x15;
  x16 = makecons(&allocp[28]);
  allocp[30] = x16;
  allocp[31] = x14;
  x17 = makecons(&allocp[30]);
  allocp[32] = x17;
  allocp[33] = x13;
  x18 = makecons(&allocp[32]);
  allocp[34] = x18;
  allocp[35] = x12;
  x19 = makecons(&allocp[34]);
  a0 = x19;
  a6 = x11;
  a7 = makesym(atom_b);
  allocp += 36;
  execute(macro__arg__n_8_0);
  goto macro__arg__n_8_ext_interrupt;
 case VARREF:
  deref_and_jump(a7,macro__goal__functor_8_8);
  *reasonp++ =  a7;
  goto macro__goal__functor_8_15;
  };
  goto macro__goal__functor_8_15;
 case functor_vector_3:
 macro__goal__functor_8_9:
  switch (ptagof(a7)) {
 case ATOMIC:
  if (a7 != makesym(atom_b)) goto macro__goal__functor_8_15;
  allocp[0] = makesym(functor_size_2);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  x0 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_functor_1);
  allocp[4] = x0;
  x3 = makefunctor(&allocp[3]);
  allocp[5] = makesym(functor__3A_2);
  allocp[6] = makefunctor(funct_const_13);
  allocp[7] = x3;
  x4 = makefunctor(&allocp[5]);
  allocp[8] = makesym(functor_functor_1);
  allocp[9] = x4;
  x5 = makefunctor(&allocp[8]);
  allocp[10] = a6;
  allocp[11] = x5;
  x6 = makecons(&allocp[10]);
  allocp[12] = makesym(functor__3D_2);
  allocp[13] = x1;
  allocp[14] = x8 = makeref(&allocp[14]);
  x7 = makefunctor(&allocp[12]);
  allocp[15] = makesym(functor_functor_1);
  allocp[16] = x7;
  x9 = makefunctor(&allocp[15]);
  allocp[17] = x6;
  allocp[18] = x9;
  x10 = makecons(&allocp[17]);
  allocp[19] = x1;
  allocp[20] = arg(a0, 0);
  x11 = makecons(&allocp[19]);
  allocp[21] = x2;
  allocp[22] = arg(a0, 1);
  x12 = makecons(&allocp[21]);
  allocp[23] = x8;
  allocp[24] = arg(a0, 2);
  x13 = makecons(&allocp[23]);
  allocp[25] = NILATOM;
  allocp[26] = x13;
  x14 = makecons(&allocp[25]);
  allocp[27] = x14;
  allocp[28] = x12;
  x15 = makecons(&allocp[27]);
  allocp[29] = x15;
  allocp[30] = x11;
  x16 = makecons(&allocp[29]);
  a0 = x16;
  a6 = x10;
  a7 = makesym(atom_b);
  allocp += 31;
  execute(macro__arg__n_8_0);
  goto macro__arg__n_8_ext_interrupt;
 case VARREF:
  deref_and_jump(a7,macro__goal__functor_8_9);
  *reasonp++ =  a7;
  goto macro__goal__functor_8_15;
  };
  goto macro__goal__functor_8_15;
 case functor__23_2:
  x0 = arg(a0, 0);
 macro__goal__functor_8_10:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_atom_1)) goto macro__goal__functor_8_15;
  x1 = arg(x0, 0);
 macro__goal__functor_8_11:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_builtin)) goto macro__goal__functor_8_15;
  x2 = arg(a0, 1);
 macro__goal__functor_8_12:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_functor_1)) goto macro__goal__functor_8_15;
  x3 = arg(x2, 0);
 macro__goal__functor_8_13:
  switch (ptagof(x3)) {
 case FUNCTOR:
  if (functor_of(x3) != makesym(functor_apply_2)) goto macro__goal__functor_8_15;
 macro__goal__functor_8_14:
  switch (ptagof(a7)) {
 case ATOMIC:
  if (a7 != makesym(atom_b)) goto macro__goal__functor_8_15;
  allocp[0] = makesym(functor_apply_2);
  allocp[1] = x5 = makeref(&allocp[1]);
  allocp[2] = x6 = makeref(&allocp[2]);
  x4 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_functor_1);
  allocp[4] = x4;
  x7 = makefunctor(&allocp[3]);
  allocp[5] = makesym(functor__3A_2);
  allocp[6] = makefunctor(funct_const_13);
  allocp[7] = x7;
  x8 = makefunctor(&allocp[5]);
  allocp[8] = makesym(functor_functor_1);
  allocp[9] = x8;
  x9 = makefunctor(&allocp[8]);
  allocp[10] = a6;
  allocp[11] = x9;
  x10 = makecons(&allocp[10]);
  allocp[12] = x5;
  allocp[13] = arg(x3, 0);
  x11 = makecons(&allocp[12]);
  allocp[14] = x6;
  allocp[15] = arg(x3, 1);
  x12 = makecons(&allocp[14]);
  allocp[16] = NILATOM;
  allocp[17] = x12;
  x13 = makecons(&allocp[16]);
  allocp[18] = x13;
  allocp[19] = x11;
  x14 = makecons(&allocp[18]);
  a0 = x14;
  a6 = x10;
  a7 = makesym(atom_b);
  allocp += 20;
  execute(macro__arg__n_8_0);
  goto macro__arg__n_8_ext_interrupt;
 case VARREF:
  deref_and_jump(a7,macro__goal__functor_8_14);
  *reasonp++ =  a7;
  goto macro__goal__functor_8_15;
  };
  goto macro__goal__functor_8_15;
 case VARREF:
  deref_and_jump(x3,macro__goal__functor_8_13);
  *reasonp++ =  x3;
  goto macro__goal__functor_8_15;
  };
  goto macro__goal__functor_8_15;
 case VARREF:
  deref_and_jump(x2,macro__goal__functor_8_12);
  *reasonp++ =  x2;
  goto macro__goal__functor_8_15;
  };
  goto macro__goal__functor_8_15;
 case VARREF:
  deref_and_jump(x1,macro__goal__functor_8_11);
  *reasonp++ =  x1;
  goto macro__goal__functor_8_15;
  };
  goto macro__goal__functor_8_15;
 case VARREF:
  deref_and_jump(x0,macro__goal__functor_8_10);
  *reasonp++ =  x0;
  goto macro__goal__functor_8_15;
  };
  goto macro__goal__functor_8_15;
  };
  goto macro__goal__functor_8_15;
 case VARREF:
  deref_and_jump(a0,macro__goal__functor_8_1);
  *reasonp++ =  a0;
  goto macro__goal__functor_8_15;
  };
  goto macro__goal__functor_8_15;
 macro__goal__functor_8_15:
  otherwise(macro__goal__functor_8_interrupt);
  allocp[0] = makesym(functor_functor_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = a6;
  allocp[3] = x0;
  x2 = makecons(&allocp[2]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_klic__comp__macro_xmacro__goal__functor__cmp_9);
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = a1;
  allocp[8] = a2;
  allocp[9] = a3;
  allocp[10] = a4;
  allocp[11] = a5;
  allocp[12] = x2;
  allocp[13] = a7;
  allocp[14] = x1;
  a1 = x3;
  qp = (struct goalrec*)&allocp[4];
  allocp += 15;
  execute(compar__macro_2_0);
  goto compar__macro_2_ext_interrupt;
 macro__goal__functor_8_ext_interrupt:
  reasonp = 0l;
 macro__goal__functor_8_interrupt:
  toppred = &predicate_klic__comp__macro_xmacro__goal__functor_8;
  goto interrupt_8;
 }

 macro__goal__functor__cmp_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 macro__goal__functor__cmp_9_clear_reason:
  reasonp = reasons;
 macro__goal__functor__cmp_9_0:
 macro__goal__functor__cmp_9_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_int_3:
 macro__goal__functor__cmp_9_2:
  switch (ptagof(a7)) {
 case ATOMIC:
  if (a7 != makesym(atom_g)) goto macro__goal__functor__cmp_9_interrupt;
  allocp[0] = NILATOM;
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = x3 = makeref(&allocp[3]);
  x2 = makecons(&allocp[2]);
  allocp[4] = x2;
  allocp[5] = arg(a0, 2);
  x4 = makecons(&allocp[4]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[8] = a8;
  allocp[9] = x4;
  allocp[10] = (q)(struct goalrec*)&allocp[6];
  allocp[11] = (q)(&predicate_klic__comp__macro_xmacro__exp_6);
  allocp[12] = x5 = makeref(&allocp[12]);
  allocp[13] = x1;
  allocp[14] = x6 = makeref(&allocp[14]);
  allocp[15] = a2;
  allocp[16] = x7 = makeref(&allocp[16]);
  allocp[17] = a6;
  allocp[18] = (q)(struct goalrec*)&allocp[10];
  allocp[19] = (q)(&predicate_klic__comp__macro_xmacro__exp_6);
  allocp[20] = x8 = makeref(&allocp[20]);
  allocp[21] = x3;
  allocp[22] = x9 = makeref(&allocp[22]);
  allocp[23] = x6;
  allocp[24] = x10 = makeref(&allocp[24]);
  allocp[25] = x7;
  allocp[26] = x8;
  allocp[27] = arg(a0, 0);
  x11 = makecons(&allocp[26]);
  allocp[28] = x5;
  allocp[29] = arg(a0, 1);
  x12 = makecons(&allocp[28]);
  allocp[30] = NILATOM;
  allocp[31] = x12;
  x13 = makecons(&allocp[30]);
  allocp[32] = x13;
  allocp[33] = x11;
  x14 = makecons(&allocp[32]);
  a0 = x14;
  a2 = x9;
  a6 = x10;
  a7 = makesym(atom_g);
  qp = (struct goalrec*)&allocp[18];
  allocp += 34;
  execute(macro__arg__n_8_0);
  goto macro__arg__n_8_ext_interrupt;
 case VARREF:
  deref_and_jump(a7,macro__goal__functor__cmp_9_2);
  *reasonp++ =  a7;
  goto macro__goal__functor__cmp_9_interrupt;
  };
  goto macro__goal__functor__cmp_9_interrupt;
 case functor_float_3:
 macro__goal__functor__cmp_9_3:
  switch (ptagof(a7)) {
 case ATOMIC:
  if (a7 != makesym(atom_g)) goto macro__goal__functor__cmp_9_interrupt;
  allocp[0] = makesym(functor_functor_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__3A_2);
  allocp[3] = makefunctor(funct_const_13);
  allocp[4] = x0;
  x2 = makefunctor(&allocp[2]);
  allocp += 5;
  unify_value(a8, x2);
  allocp[0] = NILATOM;
  allocp[1] = x4 = makeref(&allocp[1]);
  x3 = makecons(&allocp[0]);
  allocp[2] = x3;
  allocp[3] = x6 = makeref(&allocp[3]);
  x5 = makecons(&allocp[2]);
  allocp[4] = x5;
  allocp[5] = arg(a0, 2);
  x7 = makecons(&allocp[4]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[8] = x1;
  allocp[9] = x7;
  allocp[10] = (q)(struct goalrec*)&allocp[6];
  allocp[11] = (q)(&predicate_klic__comp__macro_xmacro__float__exp_6);
  allocp[12] = x8 = makeref(&allocp[12]);
  allocp[13] = x4;
  allocp[14] = x9 = makeref(&allocp[14]);
  allocp[15] = a2;
  allocp[16] = x10 = makeref(&allocp[16]);
  allocp[17] = a6;
  allocp[18] = (q)(struct goalrec*)&allocp[10];
  allocp[19] = (q)(&predicate_klic__comp__macro_xmacro__float__exp_6);
  allocp[20] = x11 = makeref(&allocp[20]);
  allocp[21] = x6;
  allocp[22] = x12 = makeref(&allocp[22]);
  allocp[23] = x9;
  allocp[24] = x13 = makeref(&allocp[24]);
  allocp[25] = x10;
  allocp[26] = x11;
  allocp[27] = arg(a0, 0);
  x14 = makecons(&allocp[26]);
  allocp[28] = x8;
  allocp[29] = arg(a0, 1);
  x15 = makecons(&allocp[28]);
  allocp[30] = NILATOM;
  allocp[31] = x15;
  x16 = makecons(&allocp[30]);
  allocp[32] = x16;
  allocp[33] = x14;
  x17 = makecons(&allocp[32]);
  a0 = x17;
  a2 = x12;
  a6 = x13;
  a7 = makesym(atom_g);
  qp = (struct goalrec*)&allocp[18];
  allocp += 34;
  execute(macro__arg__n_8_0);
  goto macro__arg__n_8_ext_interrupt;
 case VARREF:
  deref_and_jump(a7,macro__goal__functor__cmp_9_3);
  *reasonp++ =  a7;
  goto macro__goal__functor__cmp_9_interrupt;
  };
  goto macro__goal__functor__cmp_9_interrupt;
 case functor_general_3:
 macro__goal__functor__cmp_9_4:
  switch (ptagof(a7)) {
 case ATOMIC:
  if (a7 != makesym(atom_g)) goto macro__goal__functor__cmp_9_interrupt;
  bblt_add_no_check_y(a1,makeint(1L),x0);
  allocp[0] = makesym(functor_variable_1);
  allocp[1] = a1;
  x1 = makefunctor(&allocp[0]);
  allocp[2] = makecons(cons_const_6);
  allocp[3] = x1;
  x2 = makecons(&allocp[2]);
  allocp[4] = x2;
  allocp[5] = arg(a0, 2);
  x3 = makecons(&allocp[4]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[8] = a8;
  allocp[9] = x3;
  allocp[10] = makesym(functor_variable_1);
  allocp[11] = a1;
  x4 = makefunctor(&allocp[10]);
  allocp[12] = makesym(functor_compare_3);
  allocp[13] = x6 = makeref(&allocp[13]);
  allocp[14] = x7 = makeref(&allocp[14]);
  allocp[15] = x4;
  x5 = makefunctor(&allocp[12]);
  allocp[16] = makesym(functor_functor_1);
  allocp[17] = x5;
  x8 = makefunctor(&allocp[16]);
  allocp[18] = a6;
  allocp[19] = x8;
  x9 = makecons(&allocp[18]);
  allocp[20] = x6;
  allocp[21] = arg(a0, 0);
  x10 = makecons(&allocp[20]);
  allocp[22] = x7;
  allocp[23] = arg(a0, 1);
  x11 = makecons(&allocp[22]);
  allocp[24] = NILATOM;
  allocp[25] = x11;
  x12 = makecons(&allocp[24]);
  allocp[26] = x12;
  allocp[27] = x10;
  x13 = makecons(&allocp[26]);
  a0 = x13;
  a1 = x0;
  a6 = x9;
  a7 = makesym(atom_g);
  qp = (struct goalrec*)&allocp[6];
  allocp += 28;
  execute(macro__arg__n_8_0);
  goto macro__arg__n_8_ext_interrupt;
 case VARREF:
  deref_and_jump(a7,macro__goal__functor__cmp_9_4);
  *reasonp++ =  a7;
  goto macro__goal__functor__cmp_9_interrupt;
  };
  goto macro__goal__functor__cmp_9_interrupt;
 case functor_no_1:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xmake__expanded__call_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a8;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_klic__comp__macro_xexpand__goal_3);
  allocp[6] = a7;
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = x0;
  allocp[9] = x3 = makeref(&allocp[9]);
  allocp[10] = x4 = makeref(&allocp[10]);
  x2 = makecons(&allocp[9]);
  allocp[11] = (q)(struct goalrec*)&allocp[4];
  allocp[12] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[13] = x1;
  allocp[14] = x2;
  allocp[15] = (q)(struct goalrec*)&allocp[11];
  allocp[16] = (q)(&predicate_klic__comp__macro_xmacro__args_9);
  allocp[17] = x5 = makeref(&allocp[17]);
  allocp[18] = x3;
  allocp[19] = a7;
  allocp[20] = a1;
  allocp[21] = a2;
  allocp[22] = a3;
  allocp[23] = a4;
  allocp[24] = a5;
  allocp[25] = a6;
  allocp[26] = x5;
  allocp[27] = x4;
  x6 = makecons(&allocp[26]);
  allocp[28] = (q)(struct goalrec*)&allocp[15];
  allocp[29] = (q)(&predicate_klic__comp__util_xuniv_2);
  x7 = arg(a0, 0);
  allocp[30] = x7;
  allocp[31] = x6;
  qp = (struct goalrec*)&allocp[28];
  allocp += 32;
  proceed();
  };
  goto macro__goal__functor__cmp_9_interrupt;
 case VARREF:
  deref_and_jump(a0,macro__goal__functor__cmp_9_1);
  *reasonp++ =  a0;
  goto macro__goal__functor__cmp_9_interrupt;
  };
  goto macro__goal__functor__cmp_9_interrupt;
 macro__goal__functor__cmp_9_ext_interrupt:
  reasonp = 0l;
 macro__goal__functor__cmp_9_interrupt:
  goto interrupt_9;
 }

 make__expanded__call_2_top: {
  q x0, x1, x2;
  qp = qp->next;
 make__expanded__call_2_clear_reason:
  reasonp = reasons;
 make__expanded__call_2_0:
 make__expanded__call_2_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_yes_2:
  allocp[0] = makesym(functor_atom_1);
  allocp[1] = arg(a0, 0);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_functor_1);
  allocp[3] = arg(a0, 1);
  x1 = makefunctor(&allocp[2]);
  allocp[4] = makesym(functor__3A_2);
  allocp[5] = x0;
  allocp[6] = x1;
  x2 = makefunctor(&allocp[4]);
  allocp += 7;
  unify_value(a1, x2);
  proceed();
 case functor_no_1:
  x0 = arg(a0, 0);
  unify(a1, x0);
  proceed();
  };
  goto make__expanded__call_2_interrupt;
 case VARREF:
  deref_and_jump(a0,make__expanded__call_2_1);
  *reasonp++ =  a0;
  goto make__expanded__call_2_interrupt;
  };
  goto make__expanded__call_2_interrupt;
 make__expanded__call_2_ext_interrupt:
  reasonp = 0l;
 make__expanded__call_2_interrupt:
  goto interrupt_2;
 }

 expand__goal_3_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  qp = qp->next;
 expand__goal_3_clear_reason:
  reasonp = reasons;
 expand__goal_3_0:
 expand__goal_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto expand__goal_3_7;
  switch (symval(a0)) {
 case symval(makesym(atom_b)):
 expand__goal_3_2:
  switch (ptagof(a1)) {
 case FUNCTOR:
  switch (symval(functor_of(a1))) {
 case functor_unbound_2:
  allocp[0] = makesym(functor_yes_2);
  allocp[1] = makesym(atom_variable);
  allocp[2] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a2, x0);
  proceed();
 case functor_new__functor_3:
  allocp[0] = makesym(functor_yes_2);
  allocp[1] = makesym(atom_functor__table);
  allocp[2] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a2, x0);
  proceed();
 case functor_functor_3:
  allocp[0] = makesym(functor_yes_2);
  allocp[1] = makesym(atom_functor__table);
  allocp[2] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a2, x0);
  proceed();
 case functor_functor_4:
  allocp[0] = makesym(functor_yes_2);
  allocp[1] = makesym(atom_functor__table);
  allocp[2] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a2, x0);
  proceed();
 case functor_setarg_4:
  allocp[0] = makesym(functor_yes_2);
  allocp[1] = makesym(atom_functor__table);
  allocp[2] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a2, x0);
  proceed();
 case functor_setarg_5:
  allocp[0] = makesym(functor_yes_2);
  allocp[1] = makesym(atom_functor__table);
  allocp[2] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a2, x0);
  proceed();
 case functor_arg_3:
  allocp[0] = makesym(functor_yes_2);
  allocp[1] = makesym(atom_functor__table);
  allocp[2] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a2, x0);
  proceed();
 case functor_arg_4:
  allocp[0] = makesym(functor_yes_2);
  allocp[1] = makesym(atom_functor__table);
  allocp[2] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a2, x0);
  proceed();
 case functor_apply_2:
  allocp[0] = makesym(functor_yes_2);
  allocp[1] = makesym(atom_generic);
  allocp[2] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a2, x0);
  proceed();
 case functor_string__element_3:
  allocp[0] = makesym(functor_element_3);
  allocp[1] = arg(a1, 0);
  allocp[2] = arg(a1, 1);
  allocp[3] = arg(a1, 2);
  x0 = makefunctor(&allocp[0]);
  allocp[4] = makesym(functor_yes_2);
  allocp[5] = makesym(atom_generic);
  allocp[6] = x0;
  x1 = makefunctor(&allocp[4]);
  allocp += 7;
  unify_value(a2, x1);
  proceed();
 case functor_set__string__element_4:
  allocp[0] = makesym(functor_set__element_4);
  allocp[1] = arg(a1, 0);
  allocp[2] = arg(a1, 1);
  allocp[3] = arg(a1, 2);
  allocp[4] = arg(a1, 3);
  x0 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_yes_2);
  allocp[6] = makesym(atom_generic);
  allocp[7] = x0;
  x1 = makefunctor(&allocp[5]);
  allocp += 8;
  unify_value(a2, x1);
  proceed();
 case functor_vector__element_3:
  allocp[0] = makesym(functor_element_3);
  allocp[1] = arg(a1, 0);
  allocp[2] = arg(a1, 1);
  allocp[3] = arg(a1, 2);
  x0 = makefunctor(&allocp[0]);
  allocp[4] = makesym(functor_yes_2);
  allocp[5] = makesym(atom_generic);
  allocp[6] = x0;
  x1 = makefunctor(&allocp[4]);
  allocp += 7;
  unify_value(a2, x1);
  proceed();
 case functor_set__vector__element_4:
  allocp[0] = makesym(functor_set__element_4);
  allocp[1] = arg(a1, 0);
  allocp[2] = arg(a1, 1);
  allocp[3] = arg(a1, 2);
  allocp[4] = arg(a1, 3);
  x0 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_yes_2);
  allocp[6] = makesym(atom_generic);
  allocp[7] = x0;
  x1 = makefunctor(&allocp[5]);
  allocp += 8;
  unify_value(a2, x1);
  proceed();
 case functor_set__vector__element_5:
  allocp[0] = makesym(functor_set__element_5);
  allocp[1] = arg(a1, 0);
  allocp[2] = arg(a1, 1);
  allocp[3] = arg(a1, 2);
  allocp[4] = arg(a1, 3);
  allocp[5] = arg(a1, 4);
  x0 = makefunctor(&allocp[0]);
  allocp[6] = makesym(functor_yes_2);
  allocp[7] = makesym(atom_generic);
  allocp[8] = x0;
  x1 = makefunctor(&allocp[6]);
  allocp += 9;
  unify_value(a2, x1);
  proceed();
 case functor_string__less__than_2:
  allocp[0] = makesym(functor_less__than_2);
  allocp[1] = arg(a1, 0);
  allocp[2] = arg(a1, 1);
  x0 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_yes_2);
  allocp[4] = makesym(atom_generic);
  allocp[5] = x0;
  x1 = makefunctor(&allocp[3]);
  allocp += 6;
  unify_value(a2, x1);
  proceed();
 case functor_string__not__less__than_2:
  allocp[0] = makesym(functor_not__less__than_2);
  allocp[1] = arg(a1, 0);
  allocp[2] = arg(a1, 1);
  x0 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_yes_2);
  allocp[4] = makesym(atom_generic);
  allocp[5] = x0;
  x1 = makefunctor(&allocp[3]);
  allocp += 6;
  unify_value(a2, x1);
  proceed();
 case functor_new__string_3:
  allocp[0] = makesym(functor_new_4);
  allocp[1] = makefunctor(funct_const_10);
  allocp[2] = arg(a1, 0);
  allocp[3] = arg(a1, 1);
  allocp[4] = arg(a1, 2);
  x0 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_yes_2);
  allocp[6] = makesym(atom_generic);
  allocp[7] = x0;
  x1 = makefunctor(&allocp[5]);
  allocp += 8;
  unify_value(a2, x1);
  proceed();
 case functor_new__vector_2:
  allocp[0] = makesym(functor_new_3);
  allocp[1] = makefunctor(funct_const_9);
  allocp[2] = arg(a1, 0);
  allocp[3] = arg(a1, 1);
  x0 = makefunctor(&allocp[0]);
  allocp[4] = makesym(functor_yes_2);
  allocp[5] = makesym(atom_generic);
  allocp[6] = x0;
  x1 = makefunctor(&allocp[4]);
  allocp += 7;
  unify_value(a2, x1);
  proceed();
 case functor_module_2:
  allocp[0] = makesym(functor_module_1);
  allocp[1] = arg(a1, 0);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_yes_2);
  allocp[3] = makesym(atom_generic);
  allocp[4] = x0;
  x1 = makefunctor(&allocp[2]);
  allocp += 5;
  unify_value(a2, x1);
  proceed();
 case functor_code_4:
  allocp[0] = makesym(functor_predicate_1);
  allocp[1] = arg(a1, 0);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_yes_2);
  allocp[3] = makesym(atom_generic);
  allocp[4] = x0;
  x1 = makefunctor(&allocp[2]);
  allocp += 5;
  unify_value(a2, x1);
  proceed();
 case functor_merge_2:
  allocp[0] = makesym(functor_new_3);
  allocp[1] = makefunctor(funct_const_15);
  allocp[2] = arg(a1, 0);
  allocp[3] = arg(a1, 1);
  x0 = makefunctor(&allocp[0]);
  allocp[4] = makesym(functor_yes_2);
  allocp[5] = makesym(atom_generic);
  allocp[6] = x0;
  x1 = makefunctor(&allocp[4]);
  allocp += 7;
  unify_value(a2, x1);
  proceed();
 case functor_predicate__to__code_4:
  allocp[0] = makesym(functor_predicate__to__code_4);
  allocp[1] = arg(a1, 0);
  allocp[2] = arg(a1, 1);
  allocp[3] = arg(a1, 2);
  allocp[4] = arg(a1, 3);
  x0 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_yes_2);
  allocp[6] = makesym(atom_builtin__utility);
  allocp[7] = x0;
  x1 = makefunctor(&allocp[5]);
  allocp += 8;
  unify_value(a2, x1);
  proceed();
 case functor__23_2:
  x0 = arg(a1, 0);
 expand__goal_3_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_atom_1)) goto expand__goal_3_7;
  x1 = arg(x0, 0);
 expand__goal_3_4:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_builtin)) goto expand__goal_3_7;
  x2 = arg(a1, 1);
 expand__goal_3_5:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_functor_1)) goto expand__goal_3_7;
  allocp[0] = makesym(functor_yes_2);
  allocp[1] = makesym(atom_builtin__utility);
  allocp[2] = arg(x2, 0);
  x3 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a2, x3);
  proceed();
 case VARREF:
  deref_and_jump(x2,expand__goal_3_5);
  *reasonp++ =  x2;
  goto expand__goal_3_7;
  };
  goto expand__goal_3_7;
 case VARREF:
  deref_and_jump(x1,expand__goal_3_4);
  *reasonp++ =  x1;
  goto expand__goal_3_7;
  };
  goto expand__goal_3_7;
 case VARREF:
  deref_and_jump(x0,expand__goal_3_3);
  *reasonp++ =  x0;
  goto expand__goal_3_7;
  };
  goto expand__goal_3_7;
  };
  goto expand__goal_3_7;
 case VARREF:
  deref_and_jump(a1,expand__goal_3_2);
  *reasonp++ =  a1;
  goto expand__goal_3_7;
  };
  goto expand__goal_3_7;
 case symval(makesym(atom_g)):
 expand__goal_3_6:
  switch (ptagof(a1)) {
 case FUNCTOR:
  switch (symval(functor_of(a1))) {
 case functor_string__less__than_2:
  allocp[0] = makesym(functor_less__than_2);
  allocp[1] = arg(a1, 0);
  allocp[2] = arg(a1, 1);
  x0 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_yes_2);
  allocp[4] = makesym(atom_generic);
  allocp[5] = x0;
  x1 = makefunctor(&allocp[3]);
  allocp += 6;
  unify_value(a2, x1);
  proceed();
 case functor_string__not__less__than_2:
  allocp[0] = makesym(functor_not__less__than_2);
  allocp[1] = arg(a1, 0);
  allocp[2] = arg(a1, 1);
  x0 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_yes_2);
  allocp[4] = makesym(atom_generic);
  allocp[5] = x0;
  x1 = makefunctor(&allocp[3]);
  allocp += 6;
  unify_value(a2, x1);
  proceed();
 case functor_module_2:
  allocp[0] = makesym(functor_module_1);
  allocp[1] = arg(a1, 0);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_yes_2);
  allocp[3] = makesym(atom_generic);
  allocp[4] = x0;
  x1 = makefunctor(&allocp[2]);
  allocp += 5;
  unify_value(a2, x1);
  proceed();
 case functor_code_4:
  allocp[0] = makesym(functor_predicate_1);
  allocp[1] = arg(a1, 0);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_yes_2);
  allocp[3] = makesym(atom_generic);
  allocp[4] = x0;
  x1 = makefunctor(&allocp[2]);
  allocp += 5;
  unify_value(a2, x1);
  proceed();
  };
  goto expand__goal_3_7;
 case VARREF:
  deref_and_jump(a1,expand__goal_3_6);
  *reasonp++ =  a1;
  goto expand__goal_3_7;
  };
  goto expand__goal_3_7;
  };
  goto expand__goal_3_7;
 case VARREF:
  deref_and_jump(a0,expand__goal_3_1);
  *reasonp++ =  a0;
  goto expand__goal_3_7;
  };
  goto expand__goal_3_7;
 expand__goal_3_7:
  otherwise(expand__goal_3_interrupt);
  allocp[0] = makesym(functor_no_1);
  allocp[1] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  proceed();
 expand__goal_3_ext_interrupt:
  reasonp = 0l;
 expand__goal_3_interrupt:
  goto interrupt_3;
 }

 compar__macro_2_top: {
  q x0;
  qp = qp->next;
 compar__macro_2_clear_reason:
  reasonp = reasons;
 compar__macro_2_0:
 compar__macro_2_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor__3C_2:
  allocp[0] = makesym(functor_int_3);
  allocp[1] = arg(a0, 0);
  allocp[2] = arg(a0, 1);
  allocp[3] = makesym(atom_less__than);
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a1, x0);
  proceed();
 case functor__3D_3C_2:
  allocp[0] = makesym(functor_int_3);
  allocp[1] = arg(a0, 0);
  allocp[2] = arg(a0, 1);
  allocp[3] = makesym(atom_not__greater__than);
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a1, x0);
  proceed();
 case functor__3E_3D_2:
  allocp[0] = makesym(functor_int_3);
  allocp[1] = arg(a0, 0);
  allocp[2] = arg(a0, 1);
  allocp[3] = makesym(atom_not__less__than);
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a1, x0);
  proceed();
 case functor__3E_2:
  allocp[0] = makesym(functor_int_3);
  allocp[1] = arg(a0, 0);
  allocp[2] = arg(a0, 1);
  allocp[3] = makesym(atom_greater__than);
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a1, x0);
  proceed();
 case functor__3D_3A_3D_2:
  allocp[0] = makesym(functor_int_3);
  allocp[1] = arg(a0, 0);
  allocp[2] = arg(a0, 1);
  allocp[3] = makesym(atom_equal);
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a1, x0);
  proceed();
 case functor__3D_5C_3D_2:
  allocp[0] = makesym(functor_int_3);
  allocp[1] = arg(a0, 0);
  allocp[2] = arg(a0, 1);
  allocp[3] = makesym(atom_not__equal);
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a1, x0);
  proceed();
 case functor__24_3C_2:
  allocp[0] = makesym(functor_float_3);
  allocp[1] = arg(a0, 0);
  allocp[2] = arg(a0, 1);
  allocp[3] = makesym(atom_less__than);
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a1, x0);
  proceed();
 case functor__24_3D_3C_2:
  allocp[0] = makesym(functor_float_3);
  allocp[1] = arg(a0, 0);
  allocp[2] = arg(a0, 1);
  allocp[3] = makesym(atom_not__greater__than);
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a1, x0);
  proceed();
 case functor__24_3E_3D_2:
  allocp[0] = makesym(functor_float_3);
  allocp[1] = arg(a0, 0);
  allocp[2] = arg(a0, 1);
  allocp[3] = makesym(atom_not__less__than);
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a1, x0);
  proceed();
 case functor__24_3E_2:
  allocp[0] = makesym(functor_float_3);
  allocp[1] = arg(a0, 0);
  allocp[2] = arg(a0, 1);
  allocp[3] = makesym(atom_greater__than);
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a1, x0);
  proceed();
 case functor__24_3D_3A_3D_2:
  allocp[0] = makesym(functor_float_3);
  allocp[1] = arg(a0, 0);
  allocp[2] = arg(a0, 1);
  allocp[3] = makesym(atom_equal);
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a1, x0);
  proceed();
 case functor__24_3D_5C_3D_2:
  allocp[0] = makesym(functor_float_3);
  allocp[1] = arg(a0, 0);
  allocp[2] = arg(a0, 1);
  allocp[3] = makesym(atom_not__equal);
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a1, x0);
  proceed();
 case functor__40_3C_2:
  allocp[0] = makesym(functor_general_3);
  allocp[1] = arg(a0, 0);
  allocp[2] = arg(a0, 1);
  allocp[3] = makesym(atom_less__than);
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a1, x0);
  proceed();
 case functor__40_3D_3C_2:
  allocp[0] = makesym(functor_general_3);
  allocp[1] = arg(a0, 0);
  allocp[2] = arg(a0, 1);
  allocp[3] = makesym(atom_not__greater__than);
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a1, x0);
  proceed();
 case functor__40_3E_3D_2:
  allocp[0] = makesym(functor_general_3);
  allocp[1] = arg(a0, 0);
  allocp[2] = arg(a0, 1);
  allocp[3] = makesym(atom_not__less__than);
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a1, x0);
  proceed();
 case functor__40_3E_2:
  allocp[0] = makesym(functor_general_3);
  allocp[1] = arg(a0, 0);
  allocp[2] = arg(a0, 1);
  allocp[3] = makesym(atom_greater__than);
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a1, x0);
  proceed();
  };
  goto compar__macro_2_2;
 case VARREF:
  deref_and_jump(a0,compar__macro_2_1);
  *reasonp++ =  a0;
  goto compar__macro_2_2;
  };
  goto compar__macro_2_2;
 compar__macro_2_2:
  otherwise(compar__macro_2_interrupt);
  allocp[0] = makesym(functor_no_1);
  allocp[1] = a0;
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  proceed();
 compar__macro_2_ext_interrupt:
  reasonp = 0l;
 compar__macro_2_interrupt:
  toppred = &predicate_klic__comp__macro_xcompar__macro_2;
  goto interrupt_2;
 }

 macro__args_9_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 macro__args_9_clear_reason:
  reasonp = reasons;
 macro__args_9_0:
 macro__args_9_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = x2 = makeref(&allocp[1]);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xmacro__args_9);
  x3 = cdr_of(a0);
  allocp[2] = x3;
  allocp[3] = x1;
  allocp[4] = a2;
  allocp[5] = x4 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x5 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = a8;
  a0 = car_of(a0);
  a1 = x2;
  a4 = x4;
  a6 = x5;
  a8 = x6;
  qp = (struct goalrec*)&allocp[0];
  allocp += 11;
  execute(macro__arg_9_0);
  goto macro__arg_9_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto macro__args_9_interrupt;
  unify3(a8, a7, a6, a5, a4, a3);
  unify_value(a1, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a0,macro__args_9_1);
  *reasonp++ =  a0;
  goto macro__args_9_interrupt;
  };
  goto macro__args_9_interrupt;
 macro__args_9_ext_interrupt:
  reasonp = 0l;
 macro__args_9_interrupt:
  goto interrupt_9;
 }

 macro__arg_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 macro__arg_9_clear_reason:
  reasonp = reasons;
 macro__arg_9_0:
 macro__arg_9_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_variable_1:
  unify3(a8, a7, a6, a5, a4, a3);
  unify_value(a1, a0);
  proceed();
 case functor_atom_1:
  unify3(a8, a7, a6, a5, a4, a3);
  unify_value(a1, a0);
  proceed();
 case functor_integer_1:
  unify3(a8, a7, a6, a5, a4, a3);
  unify_value(a1, a0);
  proceed();
 case functor_float_1:
  unify3(a8, a7, a6, a5, a4, a3);
  unify_value(a1, a0);
  proceed();
 case functor_string_1:
  unify3(a8, a7, a6, a5, a4, a3);
  unify_value(a1, a0);
  proceed();
 case functor_list_1:
  x0 = arg(a0, 0);
 macro__arg_9_2:
  switch (ptagof(x0)) {
 case CONS:
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = x3 = makeref(&allocp[1]);
  x1 = makecons(&allocp[0]);
  allocp[2] = makesym(functor_list_1);
  allocp[3] = x1;
  x4 = makefunctor(&allocp[2]);
  allocp += 4;
  unify_value(a1, x4);
  allocp[0] = x3;
  allocp[1] = car_of(x0);
  x5 = makecons(&allocp[0]);
  allocp[2] = x2;
  allocp[3] = cdr_of(x0);
  x6 = makecons(&allocp[2]);
  allocp[4] = NILATOM;
  allocp[5] = x6;
  x7 = makecons(&allocp[4]);
  allocp[6] = x7;
  allocp[7] = x5;
  x8 = makecons(&allocp[6]);
  a0 = x8;
  a1 = a3;
  x9 = a4;
  a3 = a5;
  a4 = a6;
  a5 = a7;
  a6 = a8;
  a7 = a2;
  a2 = x9;
  allocp += 8;
  execute(macro__arg__n_8_0);
  goto macro__arg__n_8_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,macro__arg_9_2);
  *reasonp++ =  x0;
  goto macro__arg_9_interrupt;
  };
  goto macro__arg_9_interrupt;
 case functor_functor_1:
  a0 = arg(a0, 0);
  execute(macro__arg__functor_9_0);
  goto macro__arg__functor_9_ext_interrupt;
 case functor_vector_1:
 macro__arg_9_3:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (isint(a2)) goto macro__arg_9_interrupt;
  switch (symval(a2)) {
 case symval(makesym(atom_g)):
  x0 = arg(a0, 0);
 macro__arg_9_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
 macro__arg_9_5:
  if (!isgobj(x0)) goto macro__arg_9_interrupt;
  if (!isclass(x0,vector)) goto macro__arg_9_interrupt;
  gblt_size_of_vector(x0,x1,macro__arg_9_interrupt);
  unify(a8, a7);
  allocp[0] = makesym(functor_variable_1);
  allocp[1] = a3;
  x2 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x2);
  bblt_add_no_check_y(a3,makeint(1L),x3);
  allocp[0] = makesym(functor_integer_1);
  allocp[1] = x1;
  x4 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_vector_2);
  allocp[3] = a1;
  allocp[4] = x4;
  x5 = makefunctor(&allocp[2]);
  allocp[5] = makesym(functor_functor_1);
  allocp[6] = x5;
  x6 = makefunctor(&allocp[5]);
  allocp[7] = x8 = makeref(&allocp[7]);
  allocp[8] = x6;
  x7 = makecons(&allocp[7]);
  allocp += 9;
  unify_value(a5, x7);
  a0 = makeint(0L);
  a2 = a1;
  a3 = x0;
  a5 = a4;
  a7 = a6;
  a6 = x8;
  a4 = x3;
  a1 = x1;
  execute(macro__vec__elems_8_0);
  goto macro__vec__elems_8_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,macro__arg_9_4);
  *reasonp++ =  x0;
  goto macro__arg_9_interrupt;
  };
  goto macro__arg_9_interrupt;
 case symval(makesym(atom_b)):
  x0 = arg(a0, 0);
 macro__arg_9_6:
  switch (ptagof(x0)) {
 case FUNCTOR:
 macro__arg_9_7:
  if (!isgobj(x0)) goto macro__arg_9_interrupt;
  if (!isclass(x0,vector)) goto macro__arg_9_interrupt;
  gblt_size_of_vector(x0,x1,macro__arg_9_interrupt);
  allocp[0] = makesym(functor_vector_1);
  allocp[1] = x3 = makeref(&allocp[1]);
  x2 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x2);
  a0 = x0;
  a1 = x3;
  a2 = makeint(0L);
  x4 = a3;
  x5 = a4;
  x6 = a5;
  x7 = a6;
  x8 = a7;
  a9 = a8;
  a8 = x8;
  a7 = x7;
  a6 = x6;
  a5 = x5;
  a4 = x4;
  a3 = x1;
  execute(macro__vector__elems_10_0);
  goto macro__vector__elems_10_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,macro__arg_9_6);
  *reasonp++ =  x0;
  goto macro__arg_9_interrupt;
  };
  goto macro__arg_9_interrupt;
  };
  goto macro__arg_9_interrupt;
 case VARREF:
  deref_and_jump(a2,macro__arg_9_3);
  *reasonp++ =  a2;
  goto macro__arg_9_interrupt;
  };
  goto macro__arg_9_interrupt;
  };
  goto macro__arg_9_interrupt;
 case VARREF:
  deref_and_jump(a0,macro__arg_9_1);
  *reasonp++ =  a0;
  goto macro__arg_9_interrupt;
  };
  goto macro__arg_9_interrupt;
 macro__arg_9_ext_interrupt:
  reasonp = 0l;
 macro__arg_9_interrupt:
  toppred = &predicate_klic__comp__macro_xmacro__arg_9;
  goto interrupt_9;
 }

 macro__arg__n_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 macro__arg__n_8_clear_reason:
  reasonp = reasons;
 macro__arg__n_8_0:
 macro__arg__n_8_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 macro__arg__n_8_2:
  switch (ptagof(x0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xmacro__arg__n_8);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x4 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = a7;
  a0 = car_of(x0);
  x5 = cdr_of(x0);
  a2 = a7;
  x6 = a1;
  a4 = x2;
  x7 = a3;
  a6 = x3;
  a7 = a5;
  a8 = x4;
  a5 = x7;
  a3 = x6;
  a1 = x5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  execute(macro__arg_9_0);
  goto macro__arg_9_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,macro__arg__n_8_2);
  *reasonp++ =  x0;
  goto macro__arg__n_8_interrupt;
  };
  goto macro__arg__n_8_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto macro__arg__n_8_interrupt;
  unify3(a6, a5, a4, a3, a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,macro__arg__n_8_1);
  *reasonp++ =  a0;
  goto macro__arg__n_8_interrupt;
  };
  goto macro__arg__n_8_interrupt;
 macro__arg__n_8_ext_interrupt:
  reasonp = 0l;
 macro__arg__n_8_interrupt:
  toppred = &predicate_klic__comp__macro_xmacro__arg__n_8;
  goto interrupt_8;
 }

 macro__vector__elems_10_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 macro__vector__elems_10_clear_reason:
  reasonp = reasons;
 macro__vector__elems_10_0:
 macro__vector__elems_10_1:
  if (!isint(a2)) goto macro__vector__elems_10_5;
 macro__vector__elems_10_2:
  if (!isint(a3)) goto macro__vector__elems_10_4;
  gblt_greater_or_eq(a2,a3,macro__vector__elems_10_3);
  unify4(a9, a8, a7, a6, a5, a4, a1, a0);
  proceed();
 macro__vector__elems_10_3:
  gblt_less(a2,a3,macro__vector__elems_10_interrupt);
  bblt_add_no_check(a2,makeint(1L),x0);
  generic_arg[0] = a2;
  allocp[0] = x1 = makeref(&allocp[0]);
  generic_arg[1] = x1;
  allocp[1] = x2 = makeref(&allocp[1]);
  generic_arg[2] = x2;
  allocp[2] = x3 = makeref(&allocp[2]);
  generic_arg[3] = x3;
  call_generic(a0, functor_set__element_4, 3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xmacro__vector__elems_10);
  allocp[2] = x3;
  allocp[3] = a1;
  allocp[4] = x0;
  allocp[5] = a3;
  allocp[6] = x4 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x5 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x6 = makeref(&allocp[10]);
  allocp[11] = a9;
  a0 = x1;
  a1 = x2;
  a2 = makesym(atom_b);
  a3 = a4;
  a4 = x4;
  a5 = a6;
  a6 = x5;
  a7 = a8;
  a8 = x6;
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  execute(macro__arg_9_0);
  goto macro__arg_9_ext_interrupt;
 macro__vector__elems_10_4:
  if (!isref(a3)) goto macro__vector__elems_10_interrupt;
  deref_and_jump(a3,macro__vector__elems_10_2);
  *reasonp++ =  a3;
  goto macro__vector__elems_10_interrupt;
 macro__vector__elems_10_5:
  if (!isref(a2)) goto macro__vector__elems_10_interrupt;
  deref_and_jump(a2,macro__vector__elems_10_1);
  *reasonp++ =  a2;
  goto macro__vector__elems_10_interrupt;
 macro__vector__elems_10_ext_interrupt:
  reasonp = 0l;
 macro__vector__elems_10_interrupt:
  toppred = &predicate_klic__comp__macro_xmacro__vector__elems_10;
  goto interrupt_10;
 }

 macro__vec__elems_8_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 macro__vec__elems_8_clear_reason:
  reasonp = reasons;
 macro__vec__elems_8_0:
 macro__vec__elems_8_1:
  if (!isint(a0)) goto macro__vec__elems_8_7;
 macro__vec__elems_8_2:
  if (!isint(a1)) goto macro__vec__elems_8_6;
  gblt_greater_or_eq(a0,a1,macro__vec__elems_8_3);
  unify2(a7, a6, a5, a4);
  proceed();
 macro__vec__elems_8_3:
  gblt_less(a0,a1,macro__vec__elems_8_interrupt);
 macro__vec__elems_8_4:
  switch (ptagof(a3)) {
 case FUNCTOR:
 macro__vec__elems_8_5:
  if (!isgobj(a3)) goto macro__vec__elems_8_interrupt;
  if (!isclass(a3,vector)) goto macro__vec__elems_8_interrupt;
  gblt_element_of_vector(a3,a0,x0,macro__vec__elems_8_interrupt);
  bblt_add_no_check(a0,makeint(1L),x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xmacro__vec__elems_8);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = makesym(functor_integer_1);
  allocp[11] = a0;
  x4 = makefunctor(&allocp[10]);
  allocp[12] = makesym(functor_vector__element_3);
  allocp[13] = a2;
  allocp[14] = x4;
  allocp[15] = x0;
  x5 = makefunctor(&allocp[12]);
  a0 = x5;
  a1 = a4;
  a2 = x2;
  allocp[16] = x6 = makeref(&allocp[16]);
  a3 = x6;
  a4 = x3;
  a5 = a6;
  a6 = x6;
  a7 = makesym(atom_g);
  qp = (struct goalrec*)&allocp[0];
  allocp += 17;
  execute(macro__goal__functor_8_0);
  goto macro__goal__functor_8_ext_interrupt;
 case VARREF:
  deref_and_jump(a3,macro__vec__elems_8_4);
  *reasonp++ =  a3;
  goto macro__vec__elems_8_interrupt;
  };
  goto macro__vec__elems_8_interrupt;
 macro__vec__elems_8_6:
  if (!isref(a1)) goto macro__vec__elems_8_interrupt;
  deref_and_jump(a1,macro__vec__elems_8_2);
  *reasonp++ =  a1;
  goto macro__vec__elems_8_interrupt;
 macro__vec__elems_8_7:
  if (!isref(a0)) goto macro__vec__elems_8_interrupt;
  deref_and_jump(a0,macro__vec__elems_8_1);
  *reasonp++ =  a0;
  goto macro__vec__elems_8_interrupt;
 macro__vec__elems_8_ext_interrupt:
  reasonp = 0l;
 macro__vec__elems_8_interrupt:
  toppred = &predicate_klic__comp__macro_xmacro__vec__elems_8;
  goto interrupt_8;
 }

 macro__arg__functor_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 macro__arg__functor_9_clear_reason:
  reasonp = reasons;
 macro__arg__functor_9_0:
 macro__arg__functor_9_1:
  if (isref(a0)) goto macro__arg__functor_9_16;
  gblt_pfunctor(a0,x0,macro__arg__functor_9_17);
  if (isint(x0)) goto macro__arg__functor_9_17;
  switch (symval(x0)) {
 case symval(makesym(atom__23)):
  gblt_arity(a0,x1,macro__arg__functor_9_17);
 macro__arg__functor_9_2:
  switch ((unsigned long)x1) {
 case (unsigned long) makeint(1L):
  gblt_arg(makeint(1L),a0,x2,macro__arg__functor_9_17);
 macro__arg__functor_9_3:
  switch (ptagof(x2)) {
 case FUNCTOR:
  switch (symval(functor_of(x2))) {
 case functor_list_1:
  x3 = arg(x2, 0);
 macro__arg__functor_9_4:
  switch (ptagof(x3)) {
 case CONS:
  x4 = car_of(x3);
 macro__arg__functor_9_5:
  switch (ptagof(x4)) {
 case FUNCTOR:
  if (functor_of(x4) != makesym(functor_integer_1)) goto macro__arg__functor_9_17;
  x5 = cdr_of(x3);
 macro__arg__functor_9_6:
  switch (ptagof(x5)) {
 case FUNCTOR:
  if (functor_of(x5) != makesym(functor_atom_1)) goto macro__arg__functor_9_17;
  x6 = arg(x5, 0);
 macro__arg__functor_9_7:
  switch (ptagof(x6)) {
 case ATOMIC:
  if (x6 != NILATOM) goto macro__arg__functor_9_17;
  unify3(a8, a7, a6, a5, a4, a3);
  allocp[0] = makesym(functor_integer_1);
  allocp[1] = arg(x4, 0);
  x7 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x7);
  proceed();
 case VARREF:
  deref_and_jump(x6,macro__arg__functor_9_7);
  *reasonp++ =  x6;
  goto macro__arg__functor_9_17;
  };
  goto macro__arg__functor_9_17;
 case VARREF:
  deref_and_jump(x5,macro__arg__functor_9_6);
  *reasonp++ =  x5;
  goto macro__arg__functor_9_17;
  };
  goto macro__arg__functor_9_17;
 case VARREF:
  deref_and_jump(x4,macro__arg__functor_9_5);
  *reasonp++ =  x4;
  goto macro__arg__functor_9_17;
  };
  goto macro__arg__functor_9_17;
 case VARREF:
  deref_and_jump(x3,macro__arg__functor_9_4);
  *reasonp++ =  x3;
  goto macro__arg__functor_9_17;
  };
  goto macro__arg__functor_9_17;
 case functor_string_1:
  x3 = arg(x2, 0);
 macro__arg__functor_9_8:
  switch (ptagof(x3)) {
 case FUNCTOR:
 macro__arg__functor_9_9:
  if (!isgobj(x3)) goto macro__arg__functor_9_17;
 macro__arg__functor_9_10:
  gblt_is_string(x3,macro__arg__functor_9_17);
  gblt_size_of_string(x3,x4,macro__arg__functor_9_17);
 macro__arg__functor_9_11:
  if (x4 != makeint(1L)) goto macro__arg__functor_9_17;
  gblt_element_size_of_string(x3,x5,macro__arg__functor_9_17);
  unify3(a8, a7, a6, a5, a4, a3);
  generic_arg[0] = makeint(0L);
  allocp[0] = x6 = makeref(&allocp[0]);
  generic_arg[1] = x6;
  call_generic(x3, functor_element_2, 1);
  allocp[0] = makesym(functor_integer_1);
  allocp[1] = x6;
  x7 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x7);
  proceed();
 case VARREF:
  deref_and_jump(x3,macro__arg__functor_9_8);
  *reasonp++ =  x3;
  goto macro__arg__functor_9_17;
  };
  goto macro__arg__functor_9_17;
  };
  goto macro__arg__functor_9_17;
 case VARREF:
  deref_and_jump(x2,macro__arg__functor_9_3);
  *reasonp++ =  x2;
  goto macro__arg__functor_9_17;
  };
  goto macro__arg__functor_9_17;
 case (unsigned long) makeint(2L):
  gblt_arg(makeint(1L),a0,x2,macro__arg__functor_9_17);
  gblt_arg(makeint(2L),a0,x3,macro__arg__functor_9_17);
  a0 = x2;
  x4 = a1;
  x5 = a2;
  x6 = a3;
  x7 = a4;
  x8 = a5;
  x9 = a6;
  x10 = a7;
  a9 = a8;
  a8 = x10;
  a7 = x9;
  a6 = x8;
  a5 = x7;
  a4 = x6;
  a3 = x5;
  a2 = x4;
  a1 = x3;
  execute(macro__arg__functor__sharp_10_0);
  goto macro__arg__functor__sharp_10_ext_interrupt;
  };
  goto macro__arg__functor_9_17;
 case symval(makesym(atom__7E)):
  gblt_arity(a0,x1,macro__arg__functor_9_17);
 macro__arg__functor_9_12:
  if (x1 != makeint(1L)) goto macro__arg__functor_9_17;
  gblt_arg(makeint(1L),a0,x2,macro__arg__functor_9_17);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xmacro__exp_6);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = a4;
  allocp[6] = x5 = makeref(&allocp[6]);
  allocp[7] = a8;
  a0 = x2;
  a1 = x3;
  a4 = x4;
  a8 = x5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  execute(macro__arg_9_0);
  goto macro__arg_9_ext_interrupt;
 case symval(makesym(atom__24_7E)):
  gblt_arity(a0,x1,macro__arg__functor_9_17);
 macro__arg__functor_9_13:
  if (x1 != makeint(1L)) goto macro__arg__functor_9_17;
  gblt_arg(makeint(1L),a0,x2,macro__arg__functor_9_17);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xmacro__float__exp_6);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = a4;
  allocp[6] = x5 = makeref(&allocp[6]);
  allocp[7] = a8;
  a0 = x2;
  a1 = x3;
  a4 = x4;
  a8 = x5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  execute(macro__arg_9_0);
  goto macro__arg_9_ext_interrupt;
 case symval(makesym(atom__60)):
  gblt_arity(a0,x1,macro__arg__functor_9_17);
 macro__arg__functor_9_14:
  if (x1 != makeint(1L)) goto macro__arg__functor_9_17;
  gblt_arg(makeint(1L),a0,x2,macro__arg__functor_9_17);
  a0 = x2;
  execute(macro__arg_9_0);
  goto macro__arg_9_ext_interrupt;
 case symval(makesym(atom__60_60)):
  gblt_arity(a0,x1,macro__arg__functor_9_17);
 macro__arg__functor_9_15:
  if (x1 != makeint(1L)) goto macro__arg__functor_9_17;
  gblt_arg(makeint(1L),a0,x2,macro__arg__functor_9_17);
  unify4(a8, a7, a6, a5, a4, a3, a1, x2);
  proceed();
  };
  goto macro__arg__functor_9_17;
 macro__arg__functor_9_16:
  deref_and_jump(a0,macro__arg__functor_9_1);
  *reasonp++ =  a0;
  goto macro__arg__functor_9_17;
 macro__arg__functor_9_17:
  otherwise(macro__arg__functor_9_interrupt);
  allocp[0] = makesym(functor_functor_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = x3 = makeref(&allocp[0]);
  allocp[1] = x4 = makeref(&allocp[1]);
  x2 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[4] = x1;
  allocp[5] = x2;
  allocp[6] = (q)(struct goalrec*)&allocp[2];
  allocp[7] = (q)(&predicate_klic__comp__macro_xmacro__args_9);
  allocp[8] = x5 = makeref(&allocp[8]);
  allocp[9] = x3;
  allocp[10] = a2;
  allocp[11] = a3;
  allocp[12] = a4;
  allocp[13] = a5;
  allocp[14] = a6;
  allocp[15] = a7;
  allocp[16] = a8;
  allocp[17] = x5;
  allocp[18] = x4;
  x6 = makecons(&allocp[17]);
  allocp[19] = (q)(struct goalrec*)&allocp[6];
  allocp[20] = (q)(&predicate_klic__comp__util_xuniv_2);
  allocp[21] = a0;
  allocp[22] = x6;
  qp = (struct goalrec*)&allocp[19];
  allocp += 23;
  proceed();
 macro__arg__functor_9_ext_interrupt:
  reasonp = 0l;
 macro__arg__functor_9_interrupt:
  toppred = &predicate_klic__comp__macro_xmacro__arg__functor_9;
  goto interrupt_9;
 }

 macro__arg__functor__sharp_10_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 macro__arg__functor__sharp_10_clear_reason:
  reasonp = reasons;
 macro__arg__functor__sharp_10_0:
 macro__arg__functor__sharp_10_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_atom_1:
  x0 = arg(a0, 0);
 macro__arg__functor__sharp_10_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (isint(x0)) goto macro__arg__functor__sharp_10_21;
  switch (symval(x0)) {
 case symval(makesym(atom_predicate)):
 macro__arg__functor__sharp_10_3:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_functor_1)) goto macro__arg__functor__sharp_10_21;
  x1 = arg(a1, 0);
 macro__arg__functor__sharp_10_4:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor__3A_2)) goto macro__arg__functor__sharp_10_21;
  x2 = arg(x1, 0);
 macro__arg__functor__sharp_10_5:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_atom_1)) goto macro__arg__functor__sharp_10_21;
  x3 = arg(x1, 1);
 macro__arg__functor__sharp_10_6:
  switch (ptagof(x3)) {
 case FUNCTOR:
  if (functor_of(x3) != makesym(functor_functor_1)) goto macro__arg__functor__sharp_10_21;
  x4 = arg(x3, 0);
 macro__arg__functor__sharp_10_7:
  switch (ptagof(x4)) {
 case FUNCTOR:
  if (functor_of(x4) != makesym(functor__2F_2)) goto macro__arg__functor__sharp_10_21;
  x5 = arg(x4, 0);
 macro__arg__functor__sharp_10_8:
  switch (ptagof(x5)) {
 case FUNCTOR:
  if (functor_of(x5) != makesym(functor_atom_1)) goto macro__arg__functor__sharp_10_21;
  x6 = arg(x4, 1);
 macro__arg__functor__sharp_10_9:
  switch (ptagof(x6)) {
 case FUNCTOR:
  if (functor_of(x6) != makesym(functor_integer_1)) goto macro__arg__functor__sharp_10_21;
  unify3(a9, a8, a7, a6, a5, a4);
  allocp[0] = makesym(functor_predicate_3);
  allocp[1] = arg(x2, 0);
  allocp[2] = arg(x5, 0);
  allocp[3] = arg(x6, 0);
  x7 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a2, x7);
  proceed();
 case VARREF:
  deref_and_jump(x6,macro__arg__functor__sharp_10_9);
  *reasonp++ =  x6;
  goto macro__arg__functor__sharp_10_21;
  };
  goto macro__arg__functor__sharp_10_21;
 case VARREF:
  deref_and_jump(x5,macro__arg__functor__sharp_10_8);
  *reasonp++ =  x5;
  goto macro__arg__functor__sharp_10_21;
  };
  goto macro__arg__functor__sharp_10_21;
 case VARREF:
  deref_and_jump(x4,macro__arg__functor__sharp_10_7);
  *reasonp++ =  x4;
  goto macro__arg__functor__sharp_10_21;
  };
  goto macro__arg__functor__sharp_10_21;
 case VARREF:
  deref_and_jump(x3,macro__arg__functor__sharp_10_6);
  *reasonp++ =  x3;
  goto macro__arg__functor__sharp_10_21;
  };
  goto macro__arg__functor__sharp_10_21;
 case VARREF:
  deref_and_jump(x2,macro__arg__functor__sharp_10_5);
  *reasonp++ =  x2;
  goto macro__arg__functor__sharp_10_21;
  };
  goto macro__arg__functor__sharp_10_21;
 case VARREF:
  deref_and_jump(x1,macro__arg__functor__sharp_10_4);
  *reasonp++ =  x1;
  goto macro__arg__functor__sharp_10_21;
  };
  goto macro__arg__functor__sharp_10_21;
 case VARREF:
  deref_and_jump(a1,macro__arg__functor__sharp_10_3);
  *reasonp++ =  a1;
  goto macro__arg__functor__sharp_10_21;
  };
  goto macro__arg__functor__sharp_10_21;
 case symval(makesym(atom_c)):
 macro__arg__functor__sharp_10_10:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_string_1)) goto macro__arg__functor__sharp_10_21;
  x1 = arg(a1, 0);
 macro__arg__functor__sharp_10_11:
  switch (ptagof(x1)) {
 case FUNCTOR:
 macro__arg__functor__sharp_10_12:
  if (!isgobj(x1)) goto macro__arg__functor__sharp_10_21;
 macro__arg__functor__sharp_10_13:
  gblt_is_string(x1,macro__arg__functor__sharp_10_21);
  gblt_size_of_string(x1,x2,macro__arg__functor__sharp_10_21);
 macro__arg__functor__sharp_10_14:
  if (x2 != makeint(1L)) goto macro__arg__functor__sharp_10_21;
  gblt_element_size_of_string(x1,x3,macro__arg__functor__sharp_10_21);
  unify3(a9, a8, a7, a6, a5, a4);
  generic_arg[0] = makeint(0L);
  allocp[0] = x4 = makeref(&allocp[0]);
  generic_arg[1] = x4;
  call_generic(x1, functor_element_2, 1);
  allocp[0] = makesym(functor_integer_1);
  allocp[1] = x4;
  x5 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a2, x5);
  proceed();
 case VARREF:
  deref_and_jump(x1,macro__arg__functor__sharp_10_11);
  *reasonp++ =  x1;
  goto macro__arg__functor__sharp_10_21;
  };
  goto macro__arg__functor__sharp_10_21;
 case VARREF:
  deref_and_jump(a1,macro__arg__functor__sharp_10_10);
  *reasonp++ =  a1;
  goto macro__arg__functor__sharp_10_21;
  };
  goto macro__arg__functor__sharp_10_21;
 case symval(makesym(atom_key)):
 macro__arg__functor__sharp_10_15:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_atom_1)) goto macro__arg__functor__sharp_10_21;
  x1 = arg(a1, 0);
 macro__arg__functor__sharp_10_16:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (isint(x1)) goto macro__arg__functor__sharp_10_21;
  switch (symval(x1)) {
 case symval(makesym(atom_lf)):
  unify3(a9, a8, a7, a6, a5, a4);
  unify_value(a2, makefunctor(funct_const_7));
  proceed();
 case symval(makesym(atom_cr)):
  unify3(a9, a8, a7, a6, a5, a4);
  unify_value(a2, makefunctor(funct_const_8));
  proceed();
  };
  goto macro__arg__functor__sharp_10_21;
 case VARREF:
  deref_and_jump(x1,macro__arg__functor__sharp_10_16);
  *reasonp++ =  x1;
  goto macro__arg__functor__sharp_10_21;
  };
  goto macro__arg__functor__sharp_10_21;
 case VARREF:
  deref_and_jump(a1,macro__arg__functor__sharp_10_15);
  *reasonp++ =  a1;
  goto macro__arg__functor__sharp_10_21;
  };
  goto macro__arg__functor__sharp_10_21;
 case symval(makesym(atom_string)):
 macro__arg__functor__sharp_10_17:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_string_1)) goto macro__arg__functor__sharp_10_21;
  unify3(a9, a8, a7, a6, a5, a4);
  unify_value(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a1,macro__arg__functor__sharp_10_17);
  *reasonp++ =  a1;
  goto macro__arg__functor__sharp_10_21;
  };
  goto macro__arg__functor__sharp_10_21;
 case symval(makesym(atom_module)):
 macro__arg__functor__sharp_10_18:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_atom_1)) goto macro__arg__functor__sharp_10_21;
 macro__arg__functor__sharp_10_19:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_b)) goto macro__arg__functor__sharp_10_21;
  unify(a7, a6);
  bblt_add_no_check_y(a4,makeint(1L),x1);
  unify(a5, x1);
  allocp[0] = makesym(functor_variable_1);
  allocp[1] = a4;
  x2 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a2, x2);
  allocp[0] = makesym(functor_atom_1);
  allocp[1] = arg(a1, 0);
  x3 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_new_3);
  allocp[3] = makefunctor(funct_const_12);
  allocp[4] = a2;
  allocp[5] = x3;
  x4 = makefunctor(&allocp[2]);
  allocp[6] = makesym(functor_functor_1);
  allocp[7] = x4;
  x5 = makefunctor(&allocp[6]);
  allocp[8] = makesym(functor__3A_2);
  allocp[9] = makefunctor(funct_const_13);
  allocp[10] = x5;
  x6 = makefunctor(&allocp[8]);
  allocp[11] = makesym(functor_functor_1);
  allocp[12] = x6;
  x7 = makefunctor(&allocp[11]);
  allocp[13] = a9;
  allocp[14] = x7;
  x8 = makecons(&allocp[13]);
  allocp += 15;
  unify_value(a8, x8);
  proceed();
 case VARREF:
  deref_and_jump(a3,macro__arg__functor__sharp_10_19);
  *reasonp++ =  a3;
  goto macro__arg__functor__sharp_10_21;
  };
  goto macro__arg__functor__sharp_10_21;
 case VARREF:
  deref_and_jump(a1,macro__arg__functor__sharp_10_18);
  *reasonp++ =  a1;
  goto macro__arg__functor__sharp_10_21;
  };
  goto macro__arg__functor__sharp_10_21;
  };
  goto macro__arg__functor__sharp_10_21;
 case VARREF:
  deref_and_jump(x0,macro__arg__functor__sharp_10_2);
  *reasonp++ =  x0;
  goto macro__arg__functor__sharp_10_21;
  };
  goto macro__arg__functor__sharp_10_21;
 case functor_integer_1:
 macro__arg__functor__sharp_10_20:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_string_1)) goto macro__arg__functor__sharp_10_21;
  unify3(a9, a8, a7, a6, a5, a4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xmacro__N__10_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  x1 = arg(a0, 0);
  allocp[3] = x1;
  allocp[4] = makeint(0L);
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = makesym(functor_integer_1);
  allocp[7] = x2;
  x3 = makefunctor(&allocp[6]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  unify_value(a2, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__util_xstring__to__char__list_2);
  x4 = arg(a1, 0);
  allocp[2] = x4;
  allocp[3] = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  proceed();
 case VARREF:
  deref_and_jump(a1,macro__arg__functor__sharp_10_20);
  *reasonp++ =  a1;
  goto macro__arg__functor__sharp_10_21;
  };
  goto macro__arg__functor__sharp_10_21;
  };
  goto macro__arg__functor__sharp_10_21;
 case VARREF:
  deref_and_jump(a0,macro__arg__functor__sharp_10_1);
  *reasonp++ =  a0;
  goto macro__arg__functor__sharp_10_21;
  };
  goto macro__arg__functor__sharp_10_21;
 macro__arg__functor__sharp_10_21:
 macro__arg__functor__sharp_10_22:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_vector_1)) goto macro__arg__functor__sharp_10_23;
  unify3(a9, a8, a7, a6, a5, a4);
  allocp[0] = makesym(functor_vector_1);
  allocp[1] = arg(a1, 0);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__23_2);
  allocp[3] = a0;
  allocp[4] = x0;
  x1 = makefunctor(&allocp[2]);
  allocp += 5;
  unify_value(a2, x1);
  proceed();
 case VARREF:
  deref_and_jump(a1,macro__arg__functor__sharp_10_22);
  *reasonp++ =  a1;
  goto macro__arg__functor__sharp_10_23;
  };
  goto macro__arg__functor__sharp_10_23;
 macro__arg__functor__sharp_10_23:
  otherwise(macro__arg__functor__sharp_10_interrupt);
  allocp[0] = makesym(functor__23_2);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  x0 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_functor_1);
  allocp[4] = x0;
  x3 = makefunctor(&allocp[3]);
  allocp += 5;
  unify_value(a2, x3);
  allocp[0] = x1;
  allocp[1] = a0;
  x4 = makecons(&allocp[0]);
  allocp[2] = x2;
  allocp[3] = a1;
  x5 = makecons(&allocp[2]);
  allocp[4] = NILATOM;
  allocp[5] = x5;
  x6 = makecons(&allocp[4]);
  allocp[6] = x6;
  allocp[7] = x4;
  x7 = makecons(&allocp[6]);
  a0 = x7;
  a1 = a4;
  a2 = a5;
  x8 = a6;
  a4 = a7;
  a5 = a8;
  a6 = a9;
  a7 = a3;
  a3 = x8;
  allocp += 8;
  execute(macro__arg__n_8_0);
  goto macro__arg__n_8_ext_interrupt;
 macro__arg__functor__sharp_10_ext_interrupt:
  reasonp = 0l;
 macro__arg__functor__sharp_10_interrupt:
  toppred = &predicate_klic__comp__macro_xmacro__arg__functor__sharp_10;
  goto interrupt_10;
 }

 macro__N__10_4_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 macro__N__10_4_clear_reason:
  reasonp = reasons;
 macro__N__10_4_0:
 macro__N__10_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 macro__N__10_4_2:
  if (!isint(x0)) goto macro__N__10_4_5;
  gblt_greater_or_eq(x0,makeint(97L),macro__N__10_4_3);
  gblt_less_or_eq(x0,makeint(122L),macro__N__10_4_3);
  bblt_mult(a2,a1,x1);
  bblt_add_no_check_y(x1,x0,x2);
  bblt_sub_no_check_y(x2,makeint(97L),x3);
  bblt_add_no_check_y(x3,makeint(10L),x4);
  a0 = cdr_of(a0);
  a2 = x4;
  execute(macro__N__10_4_0);
  goto macro__N__10_4_ext_interrupt;
 macro__N__10_4_3:
  gblt_greater_or_eq(x0,makeint(65L),macro__N__10_4_4);
  gblt_less_or_eq(x0,makeint(90L),macro__N__10_4_4);
  bblt_mult(a2,a1,x1);
  bblt_add_no_check_y(x1,x0,x2);
  bblt_sub_no_check_y(x2,makeint(65L),x3);
  bblt_add_no_check_y(x3,makeint(10L),x4);
  a0 = cdr_of(a0);
  a2 = x4;
  execute(macro__N__10_4_0);
  goto macro__N__10_4_ext_interrupt;
 macro__N__10_4_4:
  gblt_greater_or_eq(x0,makeint(48L),macro__N__10_4_interrupt);
  gblt_less_or_eq(x0,makeint(57L),macro__N__10_4_interrupt);
  bblt_mult(a2,a1,x1);
  bblt_add_no_check_y(x1,x0,x2);
  bblt_sub_no_check_y(x2,makeint(48L),x3);
  a0 = cdr_of(a0);
  a2 = x3;
  execute(macro__N__10_4_0);
  goto macro__N__10_4_ext_interrupt;
 macro__N__10_4_5:
  if (!isref(x0)) goto macro__N__10_4_interrupt;
  deref_and_jump(x0,macro__N__10_4_2);
  *reasonp++ =  x0;
  goto macro__N__10_4_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto macro__N__10_4_interrupt;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,macro__N__10_4_1);
  *reasonp++ =  a0;
  goto macro__N__10_4_interrupt;
  };
  goto macro__N__10_4_interrupt;
 macro__N__10_4_ext_interrupt:
  reasonp = 0l;
 macro__N__10_4_interrupt:
  goto interrupt_4;
 }

 macro__exp_6_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 macro__exp_6_clear_reason:
  reasonp = reasons;
 macro__exp_6_0:
 macro__exp_6_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_variable_1:
  unify2(a5, a4, a3, a2);
  unify_value(a1, a0);
  proceed();
 case functor_integer_1:
  unify2(a5, a4, a3, a2);
  unify_value(a1, a0);
  proceed();
 case functor_functor_1:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xmacro__exp__1_7);
  x0 = arg(a0, 0);
  allocp[2] = x0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = a4;
  allocp[8] = a5;
  a0 = x0;
  a1 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 9;
  execute(macro__arith__op_2_0);
  goto macro__arith__op_2_ext_interrupt;
  };
  goto macro__exp_6_2;
 case VARREF:
  deref_and_jump(a0,macro__exp_6_1);
  *reasonp++ =  a0;
  goto macro__exp_6_2;
  };
  goto macro__exp_6_2;
 macro__exp_6_2:
  otherwise(macro__exp_6_interrupt);
  unify3(a5, a4, a3, a2, a1, a0);
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__kl1cmp_xwarning_2);
  allocp[4] = makefunctor(&string_const_3);
  allocp[5] = x0;
  qp = (struct goalrec*)&allocp[2];
  allocp += 6;
  proceed();
 macro__exp_6_ext_interrupt:
  reasonp = 0l;
 macro__exp_6_interrupt:
  toppred = &predicate_klic__comp__macro_xmacro__exp_6;
  goto interrupt_6;
 }

 macro__arith__op_2_top: {
  qp = qp->next;
 macro__arith__op_2_clear_reason:
  reasonp = reasons;
 macro__arith__op_2_0:
 macro__arith__op_2_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor__2B_2:
  unify_value(a1, makefunctor(funct_const_30));
  proceed();
 case functor__2D_2:
  unify_value(a1, makefunctor(funct_const_31));
  proceed();
 case functor__2A_2:
  unify_value(a1, makefunctor(funct_const_32));
  proceed();
 case functor__2F_2:
  unify_value(a1, makefunctor(funct_const_33));
  proceed();
 case functor_mod_2:
  unify_value(a1, makefunctor(funct_const_35));
  proceed();
 case functor__2F_5C_2:
  unify_value(a1, makefunctor(funct_const_36));
  proceed();
 case functor__5C_2F_2:
  unify_value(a1, makefunctor(funct_const_37));
  proceed();
 case functor_xor_2:
  unify_value(a1, makefunctor(funct_const_38));
  proceed();
 case functor__3E_3E_2:
  unify_value(a1, makefunctor(funct_const_40));
  proceed();
 case functor__3C_3C_2:
  unify_value(a1, makefunctor(funct_const_39));
  proceed();
 case functor__2B_1:
  unify_value(a1, makefunctor(funct_const_42));
  proceed();
 case functor__2D_1:
  unify_value(a1, makefunctor(funct_const_43));
  proceed();
 case functor__5C_1:
  unify_value(a1, makefunctor(funct_const_41));
  proceed();
 case functor_int_1:
  unify_value(a1, makesym(atom_fix));
  proceed();
  };
  goto macro__arith__op_2_2;
 case VARREF:
  deref_and_jump(a0,macro__arith__op_2_1);
  *reasonp++ =  a0;
  goto macro__arith__op_2_2;
  };
  goto macro__arith__op_2_2;
 macro__arith__op_2_2:
  otherwise(macro__arith__op_2_interrupt);
  unify_value(a1, makesym(atom_no));
  proceed();
 macro__arith__op_2_ext_interrupt:
  reasonp = 0l;
 macro__arith__op_2_interrupt:
  toppred = &predicate_klic__comp__macro_xmacro__arith__op_2;
  goto interrupt_2;
 }

 macro__exp__1_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 macro__exp__1_7_clear_reason:
  reasonp = reasons;
 macro__exp__1_7_0:
 macro__exp__1_7_1:
  switch (ptagof(a4)) {
 case ATOMIC:
  if (isint(a4)) goto macro__exp__1_7_interrupt;
  switch (symval(a4)) {
 case symval(makesym(atom_fix)):
  allocp[0] = makesym(functor_variable_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = makesym(functor_functor_1);
  allocp[1] = x3 = makeref(&allocp[1]);
  x2 = makefunctor(&allocp[0]);
  allocp[2] = a6;
  allocp[3] = x2;
  x4 = makecons(&allocp[2]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[6] = x1;
  allocp[7] = makeint(1L);
  allocp[8] = a3;
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = makesym(atom_floating__point__to__integer);
  x5 = makecons(&allocp[9]);
  allocp[11] = (q)(struct goalrec*)&allocp[4];
  allocp[12] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[13] = x3;
  allocp[14] = x5;
  allocp[15] = NILATOM;
  allocp[16] = a1;
  x7 = makecons(&allocp[15]);
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_klic__comp__macro_xmacro__float__args_7);
  allocp[19] = x8 = makeref(&allocp[19]);
  allocp[20] = x7;
  allocp[21] = x6;
  allocp[22] = a2;
  allocp[23] = x1;
  allocp[24] = a5;
  allocp[25] = x4;
  allocp[26] = x8;
  allocp[27] = x10 = makeref(&allocp[27]);
  x9 = makecons(&allocp[26]);
  allocp[28] = (q)(struct goalrec*)&allocp[17];
  allocp[29] = (q)(&predicate_klic__comp__util_xuniv_2);
  allocp[30] = a0;
  allocp[31] = x9;
  qp = (struct goalrec*)&allocp[28];
  allocp += 32;
  proceed();
 case symval(makesym(atom_no)):
  unify3(a6, a5, a1, a0, a3, a2);
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__kl1cmp_xwarning_2);
  allocp[4] = makefunctor(&string_const_3);
  allocp[5] = x0;
  qp = (struct goalrec*)&allocp[2];
  allocp += 6;
  proceed();
  };
  goto macro__exp__1_7_interrupt;
 case FUNCTOR:
  if (functor_of(a4) != makesym(functor_yes_1)) goto macro__exp__1_7_interrupt;
  allocp[0] = makesym(functor_variable_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = makesym(functor_functor_1);
  allocp[1] = x3 = makeref(&allocp[1]);
  x2 = makefunctor(&allocp[0]);
  allocp[2] = a6;
  allocp[3] = x2;
  x4 = makecons(&allocp[2]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[6] = x1;
  allocp[7] = makeint(1L);
  allocp[8] = a3;
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = arg(a4, 0);
  x5 = makecons(&allocp[9]);
  allocp[11] = (q)(struct goalrec*)&allocp[4];
  allocp[12] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[13] = x3;
  allocp[14] = x5;
  allocp[15] = NILATOM;
  allocp[16] = a1;
  x7 = makecons(&allocp[15]);
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_klic__comp__macro_xmacro__exp__args_7);
  allocp[19] = x8 = makeref(&allocp[19]);
  allocp[20] = x7;
  allocp[21] = x6;
  allocp[22] = a2;
  allocp[23] = x1;
  allocp[24] = a5;
  allocp[25] = x4;
  allocp[26] = x8;
  allocp[27] = x10 = makeref(&allocp[27]);
  x9 = makecons(&allocp[26]);
  allocp[28] = (q)(struct goalrec*)&allocp[17];
  allocp[29] = (q)(&predicate_klic__comp__util_xuniv_2);
  allocp[30] = a0;
  allocp[31] = x9;
  qp = (struct goalrec*)&allocp[28];
  allocp += 32;
  proceed();
 case VARREF:
  deref_and_jump(a4,macro__exp__1_7_1);
  *reasonp++ =  a4;
  goto macro__exp__1_7_interrupt;
  };
  goto macro__exp__1_7_interrupt;
 macro__exp__1_7_ext_interrupt:
  reasonp = 0l;
 macro__exp__1_7_interrupt:
  goto interrupt_7;
 }

 macro__exp__args_7_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 macro__exp__args_7_clear_reason:
  reasonp = reasons;
 macro__exp__args_7_0:
 macro__exp__args_7_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = x2 = makeref(&allocp[1]);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xmacro__exp__args_7);
  x3 = cdr_of(a0);
  allocp[2] = x3;
  allocp[3] = a1;
  allocp[4] = x1;
  allocp[5] = x4 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x5 = makeref(&allocp[7]);
  allocp[8] = a6;
  a0 = car_of(a0);
  a1 = x2;
  a2 = a3;
  a3 = x4;
  a4 = a5;
  a5 = x5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 9;
  execute(macro__exp_6_0);
  goto macro__exp_6_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto macro__exp__args_7_interrupt;
  unify3(a6, a5, a4, a3, a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,macro__exp__args_7_1);
  *reasonp++ =  a0;
  goto macro__exp__args_7_interrupt;
  };
  goto macro__exp__args_7_interrupt;
 macro__exp__args_7_ext_interrupt:
  reasonp = 0l;
 macro__exp__args_7_interrupt:
  goto interrupt_7;
 }

 macro__float__exp_6_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 macro__float__exp_6_clear_reason:
  reasonp = reasons;
 macro__float__exp_6_0:
 macro__float__exp_6_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_variable_1:
  unify2(a5, a4, a3, a2);
  unify_value(a1, a0);
  proceed();
 case functor_float_1:
  unify2(a5, a4, a3, a2);
  unify_value(a1, a0);
  proceed();
 case functor_functor_1:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xmacro__float__exp__1_7);
  x0 = arg(a0, 0);
  allocp[2] = x0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = a4;
  allocp[8] = a5;
  a0 = x0;
  a1 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 9;
  execute(macro__float__op_2_0);
  goto macro__float__op_2_ext_interrupt;
  };
  goto macro__float__exp_6_2;
 case VARREF:
  deref_and_jump(a0,macro__float__exp_6_1);
  *reasonp++ =  a0;
  goto macro__float__exp_6_2;
  };
  goto macro__float__exp_6_2;
 macro__float__exp_6_2:
  otherwise(macro__float__exp_6_interrupt);
  unify3(a5, a4, a3, a2, a1, a0);
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__kl1cmp_xwarning_2);
  allocp[4] = makefunctor(&string_const_4);
  allocp[5] = x0;
  qp = (struct goalrec*)&allocp[2];
  allocp += 6;
  proceed();
 macro__float__exp_6_ext_interrupt:
  reasonp = 0l;
 macro__float__exp_6_interrupt:
  toppred = &predicate_klic__comp__macro_xmacro__float__exp_6;
  goto interrupt_6;
 }

 macro__float__op_2_top: {
  qp = qp->next;
 macro__float__op_2_clear_reason:
  reasonp = reasons;
 macro__float__op_2_0:
 macro__float__op_2_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor__2B_2:
  unify_value(a1, makefunctor(funct_const_30));
  proceed();
 case functor__2D_2:
  unify_value(a1, makefunctor(funct_const_31));
  proceed();
 case functor__2A_2:
  unify_value(a1, makefunctor(funct_const_32));
  proceed();
 case functor__2F_2:
  unify_value(a1, makefunctor(funct_const_33));
  proceed();
 case functor_pow_2:
  unify_value(a1, makefunctor(funct_const_34));
  proceed();
 case functor_sin_1:
  unify_value(a1, makefunctor(funct_const_16));
  proceed();
 case functor_cos_1:
  unify_value(a1, makefunctor(funct_const_17));
  proceed();
 case functor_tan_1:
  unify_value(a1, makefunctor(funct_const_18));
  proceed();
 case functor_asin_1:
  unify_value(a1, makefunctor(funct_const_19));
  proceed();
 case functor_acos_1:
  unify_value(a1, makefunctor(funct_const_20));
  proceed();
 case functor_atan_1:
  unify_value(a1, makefunctor(funct_const_21));
  proceed();
 case functor_sinh_1:
  unify_value(a1, makefunctor(funct_const_22));
  proceed();
 case functor_cosh_1:
  unify_value(a1, makefunctor(funct_const_23));
  proceed();
 case functor_tanh_1:
  unify_value(a1, makefunctor(funct_const_24));
  proceed();
 case functor_exp_1:
  unify_value(a1, makefunctor(funct_const_25));
  proceed();
 case functor_log_1:
  unify_value(a1, makefunctor(funct_const_26));
  proceed();
 case functor_sqrt_1:
  unify_value(a1, makefunctor(funct_const_27));
  proceed();
 case functor_ceil_1:
  unify_value(a1, makefunctor(funct_const_28));
  proceed();
 case functor_floor_1:
  unify_value(a1, makefunctor(funct_const_29));
  proceed();
 case functor_float_1:
  unify_value(a1, makesym(atom_new));
  proceed();
  };
  goto macro__float__op_2_2;
 case VARREF:
  deref_and_jump(a0,macro__float__op_2_1);
  *reasonp++ =  a0;
  goto macro__float__op_2_2;
  };
  goto macro__float__op_2_2;
 macro__float__op_2_2:
  otherwise(macro__float__op_2_interrupt);
  unify_value(a1, makesym(atom_no));
  proceed();
 macro__float__op_2_ext_interrupt:
  reasonp = 0l;
 macro__float__op_2_interrupt:
  toppred = &predicate_klic__comp__macro_xmacro__float__op_2;
  goto interrupt_2;
 }

 macro__float__exp__1_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 macro__float__exp__1_7_clear_reason:
  reasonp = reasons;
 macro__float__exp__1_7_0:
 macro__float__exp__1_7_1:
  switch (ptagof(a4)) {
 case ATOMIC:
  if (isint(a4)) goto macro__float__exp__1_7_interrupt;
  switch (symval(a4)) {
 case symval(makesym(atom_new)):
 macro__float__exp__1_7_2:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_float_1)) goto macro__float__exp__1_7_interrupt;
  allocp[0] = makesym(functor_variable_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = makesym(functor_functor_1);
  allocp[1] = x3 = makeref(&allocp[1]);
  x2 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__3A_2);
  allocp[3] = makefunctor(funct_const_13);
  allocp[4] = x2;
  x4 = makefunctor(&allocp[2]);
  allocp[5] = makesym(functor_functor_1);
  allocp[6] = x4;
  x5 = makefunctor(&allocp[5]);
  allocp[7] = a6;
  allocp[8] = x5;
  x6 = makecons(&allocp[7]);
  allocp[9] = (q)qp;
  allocp[10] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[11] = x1;
  allocp[12] = makeint(1L);
  allocp[13] = a3;
  allocp[14] = NILATOM;
  allocp[15] = x8 = makeref(&allocp[15]);
  x7 = makecons(&allocp[14]);
  allocp[16] = x7;
  allocp[17] = a1;
  x9 = makecons(&allocp[16]);
  allocp[18] = x9;
  allocp[19] = makefunctor(funct_const_11);
  x10 = makecons(&allocp[18]);
  allocp[20] = x10;
  allocp[21] = makesym(atom_new);
  x11 = makecons(&allocp[20]);
  allocp[22] = (q)(struct goalrec*)&allocp[9];
  allocp[23] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[24] = x3;
  allocp[25] = x11;
  a0 = arg(a0, 0);
  a1 = x8;
  a3 = x1;
  a4 = a5;
  a5 = x6;
  qp = (struct goalrec*)&allocp[22];
  allocp += 26;
  execute(macro__exp_6_0);
  goto macro__exp_6_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,macro__float__exp__1_7_2);
  *reasonp++ =  a0;
  goto macro__float__exp__1_7_interrupt;
  };
  goto macro__float__exp__1_7_interrupt;
 case symval(makesym(atom_no)):
  unify3(a6, a5, a1, a0, a3, a2);
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__kl1cmp_xwarning_2);
  allocp[4] = makefunctor(&string_const_3);
  allocp[5] = x0;
  qp = (struct goalrec*)&allocp[2];
  allocp += 6;
  proceed();
  };
  goto macro__float__exp__1_7_interrupt;
 case FUNCTOR:
  if (functor_of(a4) != makesym(functor_yes_1)) goto macro__float__exp__1_7_interrupt;
  allocp[0] = makesym(functor_variable_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = makesym(functor_functor_1);
  allocp[1] = x3 = makeref(&allocp[1]);
  x2 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__3A_2);
  allocp[3] = makefunctor(funct_const_13);
  allocp[4] = x2;
  x4 = makefunctor(&allocp[2]);
  allocp[5] = makesym(functor_functor_1);
  allocp[6] = x4;
  x5 = makefunctor(&allocp[5]);
  allocp[7] = a6;
  allocp[8] = x5;
  x6 = makecons(&allocp[7]);
  allocp[9] = (q)qp;
  allocp[10] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[11] = x1;
  allocp[12] = makeint(1L);
  allocp[13] = a3;
  allocp[14] = x8 = makeref(&allocp[14]);
  allocp[15] = arg(a4, 0);
  x7 = makecons(&allocp[14]);
  allocp[16] = (q)(struct goalrec*)&allocp[9];
  allocp[17] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[18] = x3;
  allocp[19] = x7;
  allocp[20] = NILATOM;
  allocp[21] = a1;
  x9 = makecons(&allocp[20]);
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_klic__comp__macro_xmacro__float__args_7);
  allocp[24] = x10 = makeref(&allocp[24]);
  allocp[25] = x9;
  allocp[26] = x8;
  allocp[27] = a2;
  allocp[28] = x1;
  allocp[29] = a5;
  allocp[30] = x6;
  allocp[31] = x10;
  allocp[32] = x12 = makeref(&allocp[32]);
  x11 = makecons(&allocp[31]);
  allocp[33] = (q)(struct goalrec*)&allocp[22];
  allocp[34] = (q)(&predicate_klic__comp__util_xuniv_2);
  allocp[35] = a0;
  allocp[36] = x11;
  qp = (struct goalrec*)&allocp[33];
  allocp += 37;
  proceed();
 case VARREF:
  deref_and_jump(a4,macro__float__exp__1_7_1);
  *reasonp++ =  a4;
  goto macro__float__exp__1_7_interrupt;
  };
  goto macro__float__exp__1_7_interrupt;
 macro__float__exp__1_7_ext_interrupt:
  reasonp = 0l;
 macro__float__exp__1_7_interrupt:
  goto interrupt_7;
 }

 macro__float__args_7_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 macro__float__args_7_clear_reason:
  reasonp = reasons;
 macro__float__args_7_0:
 macro__float__args_7_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = x2 = makeref(&allocp[1]);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xmacro__float__args_7);
  x3 = cdr_of(a0);
  allocp[2] = x3;
  allocp[3] = a1;
  allocp[4] = x1;
  allocp[5] = x4 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x5 = makeref(&allocp[7]);
  allocp[8] = a6;
  a0 = car_of(a0);
  a1 = x2;
  a2 = a3;
  a3 = x4;
  a4 = a5;
  a5 = x5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 9;
  execute(macro__float__exp_6_0);
  goto macro__float__exp_6_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto macro__float__args_7_interrupt;
  unify3(a6, a5, a4, a3, a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,macro__float__args_7_1);
  *reasonp++ =  a0;
  goto macro__float__args_7_interrupt;
  };
  goto macro__float__args_7_interrupt;
 macro__float__args_7_ext_interrupt:
  reasonp = 0l;
 macro__float__args_7_interrupt:
  goto interrupt_7;
 }
 interrupt_12:
  allocp[13] = a11;
 interrupt_11:
  allocp[12] = a10;
 interrupt_10:
  allocp[11] = a9;
 interrupt_9:
  allocp[10] = a8;
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_klic__comp__macro);
}
