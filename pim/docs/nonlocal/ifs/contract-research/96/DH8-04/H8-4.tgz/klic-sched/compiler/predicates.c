#include <klic/basic.h>
#include <klic/predinfo.h>

extern Const struct predicate predicate_klic__comp__bb_xis__body__builtin_2;
static Const struct predinfo predinfo_klic__comp__bb_xis__body__builtin_2 = {
  (unsigned char *)"is_body_builtin",
  &predicate_klic__comp__bb_xis__body__builtin_2
};

extern Const struct predicate predicate_klic__comp__bb_xint__unary_2;
static Const struct predinfo predinfo_klic__comp__bb_xint__unary_2 = {
  (unsigned char *)"int_unary",
  &predicate_klic__comp__bb_xint__unary_2
};

extern Const struct predicate predicate_klic__comp__bb_xint__binary_2;
static Const struct predinfo predinfo_klic__comp__bb_xint__binary_2 = {
  (unsigned char *)"int_binary",
  &predicate_klic__comp__bb_xint__binary_2
};

extern Const struct predicate predicate_klic__comp__bb_xfloat__unary_2;
static Const struct predinfo predinfo_klic__comp__bb_xfloat__unary_2 = {
  (unsigned char *)"float_unary",
  &predicate_klic__comp__bb_xfloat__unary_2
};

extern Const struct predicate predicate_klic__comp__bb_xfloat__binary_2;
static Const struct predinfo predinfo_klic__comp__bb_xfloat__binary_2 = {
  (unsigned char *)"float_binary",
  &predicate_klic__comp__bb_xfloat__binary_2
};

static Const struct predinfo * Const preds_in_klic__comp__bb[] = {
  &predinfo_klic__comp__bb_xis__body__builtin_2,
  &predinfo_klic__comp__bb_xint__unary_2,
  &predinfo_klic__comp__bb_xint__binary_2,
  &predinfo_klic__comp__bb_xfloat__unary_2,
  &predinfo_klic__comp__bb_xfloat__binary_2,
  0
};
extern Const struct predicate predicate_klic__comp__gb_xis__guard__builtin_2;
static Const struct predinfo predinfo_klic__comp__gb_xis__guard__builtin_2 = {
  (unsigned char *)"is_guard_builtin",
  &predicate_klic__comp__gb_xis__guard__builtin_2
};

extern Const struct predicate predicate_klic__comp__gb_xint__unary_4;
static Const struct predinfo predinfo_klic__comp__gb_xint__unary_4 = {
  (unsigned char *)"int_unary",
  &predicate_klic__comp__gb_xint__unary_4
};

extern Const struct predicate predicate_klic__comp__gb_xint__compare_4;
static Const struct predinfo predinfo_klic__comp__gb_xint__compare_4 = {
  (unsigned char *)"int_compare",
  &predicate_klic__comp__gb_xint__compare_4
};

extern Const struct predicate predicate_klic__comp__gb_xint__binary_5;
static Const struct predinfo predinfo_klic__comp__gb_xint__binary_5 = {
  (unsigned char *)"int_binary",
  &predicate_klic__comp__gb_xint__binary_5
};

extern Const struct predicate predicate_klic__comp__gb_xbuiltin_4;
static Const struct predinfo predinfo_klic__comp__gb_xbuiltin_4 = {
  (unsigned char *)"builtin",
  &predicate_klic__comp__gb_xbuiltin_4
};

static Const struct predinfo * Const preds_in_klic__comp__gb[] = {
  &predinfo_klic__comp__gb_xis__guard__builtin_2,
  &predinfo_klic__comp__gb_xint__unary_4,
  &predinfo_klic__comp__gb_xint__compare_4,
  &predinfo_klic__comp__gb_xint__binary_5,
  &predinfo_klic__comp__gb_xbuiltin_4,
  0
};
extern Const struct predicate predicate_klic__comp__normalize_xyes__const_5;
static Const struct predinfo predinfo_klic__comp__normalize_xyes__const_5 = {
  (unsigned char *)"yes_const",
  &predicate_klic__comp__normalize_xyes__const_5
};

extern Const struct predicate predicate_klic__comp__normalize_xseparate__cond__1_9;
static Const struct predinfo predinfo_klic__comp__normalize_xseparate__cond__1_9 = {
  (unsigned char *)"separate_cond_1",
  &predicate_klic__comp__normalize_xseparate__cond__1_9
};

extern Const struct predicate predicate_klic__comp__normalize_xseparate__cond_5;
static Const struct predinfo predinfo_klic__comp__normalize_xseparate__cond_5 = {
  (unsigned char *)"separate_cond",
  &predicate_klic__comp__normalize_xseparate__cond_5
};

extern Const struct predicate predicate_klic__comp__normalize_xprint__error_1;
static Const struct predinfo predinfo_klic__comp__normalize_xprint__error_1 = {
  (unsigned char *)"print_error",
  &predicate_klic__comp__normalize_xprint__error_1
};

extern Const struct predicate predicate_klic__comp__normalize_xprint__data_2;
static Const struct predinfo predinfo_klic__comp__normalize_xprint__data_2 = {
  (unsigned char *)"print_data",
  &predicate_klic__comp__normalize_xprint__data_2
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__top__goal__unify_8;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__top__goal__unify_8 = {
  (unsigned char *)"norm_top_goal_unify",
  &predicate_klic__comp__normalize_xnorm__top__goal__unify_8
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__top__goal__builtin_7;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__top__goal__builtin_7 = {
  (unsigned char *)"norm_top_goal_builtin",
  &predicate_klic__comp__normalize_xnorm__top__goal__builtin_7
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__top__goal_7;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__top__goal_7 = {
  (unsigned char *)"norm_top_goal",
  &predicate_klic__comp__normalize_xnorm__top__goal_7
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__tail__goal__unify_8;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__tail__goal__unify_8 = {
  (unsigned char *)"norm_tail_goal_unify",
  &predicate_klic__comp__normalize_xnorm__tail__goal__unify_8
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__tail__goal__generic_9;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__tail__goal__generic_9 = {
  (unsigned char *)"norm_tail_goal_generic",
  &predicate_klic__comp__normalize_xnorm__tail__goal__generic_9
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__tail__goal__builtin_8;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__tail__goal__builtin_8 = {
  (unsigned char *)"norm_tail_goal_builtin",
  &predicate_klic__comp__normalize_xnorm__tail__goal__builtin_8
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__tail__goal_7;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__tail__goal_7 = {
  (unsigned char *)"norm_tail_goal",
  &predicate_klic__comp__normalize_xnorm__tail__goal_7
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__pragma__thread_7;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__pragma__thread_7 = {
  (unsigned char *)"norm_pragma_thread",
  &predicate_klic__comp__normalize_xnorm__pragma__thread_7
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__pragma__tcall_7;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__pragma__tcall_7 = {
  (unsigned char *)"norm_pragma_tcall",
  &predicate_klic__comp__normalize_xnorm__pragma__tcall_7
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__pragma__priority_8;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__pragma__priority_8 = {
  (unsigned char *)"norm_pragma_priority",
  &predicate_klic__comp__normalize_xnorm__pragma__priority_8
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__pragma__pragma__arg_8;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__pragma__pragma__arg_8 = {
  (unsigned char *)"norm_pragma_pragma_arg",
  &predicate_klic__comp__normalize_xnorm__pragma__pragma__arg_8
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__pragma__node_9;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__pragma__node_9 = {
  (unsigned char *)"norm_pragma_node",
  &predicate_klic__comp__normalize_xnorm__pragma__node_9
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__pragma__lower__priority_8;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__pragma__lower__priority_8 = {
  (unsigned char *)"norm_pragma_lower_priority",
  &predicate_klic__comp__normalize_xnorm__pragma__lower__priority_8
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__pragma__loop_7;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__pragma__loop_7 = {
  (unsigned char *)"norm_pragma_loop",
  &predicate_klic__comp__normalize_xnorm__pragma__loop_7
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__pragma__go_10;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__pragma__go_10 = {
  (unsigned char *)"norm_pragma_go",
  &predicate_klic__comp__normalize_xnorm__pragma__go_10
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__pragma__1_8;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__pragma__1_8 = {
  (unsigned char *)"norm_pragma_1",
  &predicate_klic__comp__normalize_xnorm__pragma__1_8
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__pragma__0_9;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__pragma__0_9 = {
  (unsigned char *)"norm_pragma_0",
  &predicate_klic__comp__normalize_xnorm__pragma__0_9
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__pragma_8;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__pragma_8 = {
  (unsigned char *)"norm_pragma",
  &predicate_klic__comp__normalize_xnorm__pragma_8
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__inline__arg__1_7;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__inline__arg__1_7 = {
  (unsigned char *)"norm_inline_arg_1",
  &predicate_klic__comp__normalize_xnorm__inline__arg__1_7
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__inline__arg_11;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__inline__arg_11 = {
  (unsigned char *)"norm_inline_arg",
  &predicate_klic__comp__normalize_xnorm__inline__arg_11
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__inline_2F12_240_13;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__inline_2F12_240_13 = {
  (unsigned char *)"norm_inline/12$0",
  &predicate_klic__comp__normalize_xnorm__inline_2F12_240_13
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__inline_12;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__inline_12 = {
  (unsigned char *)"norm_inline",
  &predicate_klic__comp__normalize_xnorm__inline_12
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__head_5;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__head_5 = {
  (unsigned char *)"norm_head",
  &predicate_klic__comp__normalize_xnorm__head_5
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__guard__unify__new_6;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__guard__unify__new_6 = {
  (unsigned char *)"norm_guard_unify_new",
  &predicate_klic__comp__normalize_xnorm__guard__unify__new_6
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__guard__unify__new_2F6_240_7;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__guard__unify__new_2F6_240_7 = {
  (unsigned char *)"norm_guard_unify_new/6$0",
  &predicate_klic__comp__normalize_xnorm__guard__unify__new_2F6_240_7
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__guard__unify__args_10;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__guard__unify__args_10 = {
  (unsigned char *)"norm_guard_unify_args",
  &predicate_klic__comp__normalize_xnorm__guard__unify__args_10
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__guard__unify_9;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__guard__unify_9 = {
  (unsigned char *)"norm_guard_unify",
  &predicate_klic__comp__normalize_xnorm__guard__unify_9
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__guard__unify_2F9_241_2F10_240_9;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__guard__unify_2F9_241_2F10_240_9 = {
  (unsigned char *)"norm_guard_unify/9$1/10$0",
  &predicate_klic__comp__normalize_xnorm__guard__unify_2F9_241_2F10_240_9
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__guard__unify_2F9_241_10;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__guard__unify_2F9_241_10 = {
  (unsigned char *)"norm_guard_unify/9$1",
  &predicate_klic__comp__normalize_xnorm__guard__unify_2F9_241_10
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__guard__unify_2F9_240_10;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__guard__unify_2F9_240_10 = {
  (unsigned char *)"norm_guard_unify/9$0",
  &predicate_klic__comp__normalize_xnorm__guard__unify_2F9_240_10
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__guard__term__1_7;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__guard__term__1_7 = {
  (unsigned char *)"norm_guard_term_1",
  &predicate_klic__comp__normalize_xnorm__guard__term__1_7
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__guard__term_6;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__guard__term_6 = {
  (unsigned char *)"norm_guard_term",
  &predicate_klic__comp__normalize_xnorm__guard__term_6
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__guard__goal_8;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__guard__goal_8 = {
  (unsigned char *)"norm_guard_goal",
  &predicate_klic__comp__normalize_xnorm__guard__goal_8
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__guard__goal_2F8_241_8;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__guard__goal_2F8_241_8 = {
  (unsigned char *)"norm_guard_goal/8$1",
  &predicate_klic__comp__normalize_xnorm__guard__goal_2F8_241_8
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__guard__goal_2F8_240_8;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__guard__goal_2F8_240_8 = {
  (unsigned char *)"norm_guard_goal/8$0",
  &predicate_klic__comp__normalize_xnorm__guard__goal_2F8_240_8
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__guard__generic__3_13;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__guard__generic__3_13 = {
  (unsigned char *)"norm_guard_generic_3",
  &predicate_klic__comp__normalize_xnorm__guard__generic__3_13
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__guard__generic__2_14;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__guard__generic__2_14 = {
  (unsigned char *)"norm_guard_generic_2",
  &predicate_klic__comp__normalize_xnorm__guard__generic__2_14
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__guard__generic__1_14;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__guard__generic__1_14 = {
  (unsigned char *)"norm_guard_generic_1",
  &predicate_klic__comp__normalize_xnorm__guard__generic__1_14
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__guard__generic_8;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__guard__generic_8 = {
  (unsigned char *)"norm_guard_generic",
  &predicate_klic__comp__normalize_xnorm__guard__generic_8
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__guard__builts__1_12;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__guard__builts__1_12 = {
  (unsigned char *)"norm_guard_builts_1",
  &predicate_klic__comp__normalize_xnorm__guard__builts__1_12
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__guard__builts_8;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__guard__builts_8 = {
  (unsigned char *)"norm_guard_builts",
  &predicate_klic__comp__normalize_xnorm__guard__builts_8
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__guard_2F10_241_11;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__guard_2F10_241_11 = {
  (unsigned char *)"norm_guard/10$1",
  &predicate_klic__comp__normalize_xnorm__guard_2F10_241_11
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__guard_2F10_240_11;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__guard_2F10_240_11 = {
  (unsigned char *)"norm_guard/10$0",
  &predicate_klic__comp__normalize_xnorm__guard_2F10_240_11
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__guard_10;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__guard_10 = {
  (unsigned char *)"norm_guard",
  &predicate_klic__comp__normalize_xnorm__guard_10
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__gg__outs_9;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__gg__outs_9 = {
  (unsigned char *)"norm_gg_outs",
  &predicate_klic__comp__normalize_xnorm__gg__outs_9
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__gg__ins__1_9;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__gg__ins__1_9 = {
  (unsigned char *)"norm_gg_ins_1",
  &predicate_klic__comp__normalize_xnorm__gg__ins__1_9
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__gg__ins_8;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__gg__ins_8 = {
  (unsigned char *)"norm_gg_ins",
  &predicate_klic__comp__normalize_xnorm__gg__ins_8
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__gg__in__out_7;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__gg__in__out_7 = {
  (unsigned char *)"norm_gg_in_out",
  &predicate_klic__comp__normalize_xnorm__gg__in__out_7
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__gg__in__2_8;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__gg__in__2_8 = {
  (unsigned char *)"norm_gg_in_2",
  &predicate_klic__comp__normalize_xnorm__gg__in__2_8
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__gg__in__1_10;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__gg__in__1_10 = {
  (unsigned char *)"norm_gg_in_1",
  &predicate_klic__comp__normalize_xnorm__gg__in__1_10
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__gg__in_9;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__gg__in_9 = {
  (unsigned char *)"norm_gg_in",
  &predicate_klic__comp__normalize_xnorm__gg__in_9
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__gg__count__out_4;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__gg__count__out_4 = {
  (unsigned char *)"norm_gg_count_out",
  &predicate_klic__comp__normalize_xnorm__gg__count__out_4
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__gg__2_6;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__gg__2_6 = {
  (unsigned char *)"norm_gg_2",
  &predicate_klic__comp__normalize_xnorm__gg__2_6
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__gg__1_8;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__gg__1_8 = {
  (unsigned char *)"norm_gg_1",
  &predicate_klic__comp__normalize_xnorm__gg__1_8
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__gg_5;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__gg_5 = {
  (unsigned char *)"norm_gg",
  &predicate_klic__comp__normalize_xnorm__gg_5
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__gblt__args__1_9;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__gblt__args__1_9 = {
  (unsigned char *)"norm_gblt_args_1",
  &predicate_klic__comp__normalize_xnorm__gblt__args__1_9
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__gblt__args_8;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__gblt__args_8 = {
  (unsigned char *)"norm_gblt_args",
  &predicate_klic__comp__normalize_xnorm__gblt__args_8
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__gblt__arg__2_8;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__gblt__arg__2_8 = {
  (unsigned char *)"norm_gblt_arg_2",
  &predicate_klic__comp__normalize_xnorm__gblt__arg__2_8
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__gblt__arg__1_10;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__gblt__arg__1_10 = {
  (unsigned char *)"norm_gblt_arg_1",
  &predicate_klic__comp__normalize_xnorm__gblt__arg__1_10
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__gblt__arg_9;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__gblt__arg_9 = {
  (unsigned char *)"norm_gblt_arg",
  &predicate_klic__comp__normalize_xnorm__gblt__arg_9
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__body__tail__1_8;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__body__tail__1_8 = {
  (unsigned char *)"norm_body_tail_1",
  &predicate_klic__comp__normalize_xnorm__body__tail__1_8
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__body__tail_7;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__body__tail_7 = {
  (unsigned char *)"norm_body_tail",
  &predicate_klic__comp__normalize_xnorm__body__tail_7
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__body__args__1_9;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__body__args__1_9 = {
  (unsigned char *)"norm_body_args_1",
  &predicate_klic__comp__normalize_xnorm__body__args__1_9
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__body__args_8;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__body__args_8 = {
  (unsigned char *)"norm_body_args",
  &predicate_klic__comp__normalize_xnorm__body__args_8
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__body__args_10;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__body__args_10 = {
  (unsigned char *)"norm_body_args",
  &predicate_klic__comp__normalize_xnorm__body__args_10
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__body__arg__3__2_6;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__body__arg__3__2_6 = {
  (unsigned char *)"norm_body_arg_3_2",
  &predicate_klic__comp__normalize_xnorm__body__arg__3__2_6
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__body__arg__3__1_11;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__body__arg__3__1_11 = {
  (unsigned char *)"norm_body_arg_3_1",
  &predicate_klic__comp__normalize_xnorm__body__arg__3__1_11
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__body__arg__3_9;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__body__arg__3_9 = {
  (unsigned char *)"norm_body_arg_3",
  &predicate_klic__comp__normalize_xnorm__body__arg__3_9
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__body__arg__2_8;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__body__arg__2_8 = {
  (unsigned char *)"norm_body_arg_2",
  &predicate_klic__comp__normalize_xnorm__body__arg__2_8
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__body__arg__1_9;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__body__arg__1_9 = {
  (unsigned char *)"norm_body_arg_1",
  &predicate_klic__comp__normalize_xnorm__body__arg__1_9
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__body__arg__1_10;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__body__arg__1_10 = {
  (unsigned char *)"norm_body_arg_1",
  &predicate_klic__comp__normalize_xnorm__body__arg__1_10
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__body__arg_8;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__body__arg_8 = {
  (unsigned char *)"norm_body_arg",
  &predicate_klic__comp__normalize_xnorm__body__arg_8
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__body__1_9;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__body__1_9 = {
  (unsigned char *)"norm_body_1",
  &predicate_klic__comp__normalize_xnorm__body__1_9
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__body_6;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__body_6 = {
  (unsigned char *)"norm_body",
  &predicate_klic__comp__normalize_xnorm__body_6
};

extern Const struct predicate predicate_klic__comp__normalize_xnorm__args_8;
static Const struct predinfo predinfo_klic__comp__normalize_xnorm__args_8 = {
  (unsigned char *)"norm_args",
  &predicate_klic__comp__normalize_xnorm__args_8
};

extern Const struct predicate predicate_klic__comp__normalize_xmake__arg__assoc_3;
static Const struct predinfo predinfo_klic__comp__normalize_xmake__arg__assoc_3 = {
  (unsigned char *)"make_arg_assoc",
  &predicate_klic__comp__normalize_xmake__arg__assoc_3
};

extern Const struct predicate predicate_klic__comp__normalize_xis__const__args_3;
static Const struct predinfo predinfo_klic__comp__normalize_xis__const__args_3 = {
  (unsigned char *)"is_const_args",
  &predicate_klic__comp__normalize_xis__const__args_3
};

extern Const struct predicate predicate_klic__comp__normalize_xis__const__1_6;
static Const struct predinfo predinfo_klic__comp__normalize_xis__const__1_6 = {
  (unsigned char *)"is_const_1",
  &predicate_klic__comp__normalize_xis__const__1_6
};

extern Const struct predicate predicate_klic__comp__normalize_xis__const_5;
static Const struct predinfo predinfo_klic__comp__normalize_xis__const_5 = {
  (unsigned char *)"is_const",
  &predicate_klic__comp__normalize_xis__const_5
};

extern Const struct predicate predicate_klic__comp__normalize_xinline__arg__type_2;
static Const struct predinfo predinfo_klic__comp__normalize_xinline__arg__type_2 = {
  (unsigned char *)"inline_arg_type",
  &predicate_klic__comp__normalize_xinline__arg__type_2
};

extern Const struct predicate predicate_klic__comp__normalize_xgenerate_9;
static Const struct predinfo predinfo_klic__comp__normalize_xgenerate_9 = {
  (unsigned char *)"generate",
  &predicate_klic__comp__normalize_xgenerate_9
};

extern Const struct predicate predicate_klic__comp__normalize_xexit_1;
static Const struct predinfo predinfo_klic__comp__normalize_xexit_1 = {
  (unsigned char *)"exit",
  &predicate_klic__comp__normalize_xexit_1
};

extern Const struct predicate predicate_klic__comp__normalize_xcheck__gblt__input_5;
static Const struct predinfo predinfo_klic__comp__normalize_xcheck__gblt__input_5 = {
  (unsigned char *)"check_gblt_input",
  &predicate_klic__comp__normalize_xcheck__gblt__input_5
};

extern Const struct predicate predicate_klic__comp__normalize_xadd__make__thread__2_5;
static Const struct predinfo predinfo_klic__comp__normalize_xadd__make__thread__2_5 = {
  (unsigned char *)"add_make_thread_2",
  &predicate_klic__comp__normalize_xadd__make__thread__2_5
};

extern Const struct predicate predicate_klic__comp__normalize_xadd__make__thread__1_5;
static Const struct predinfo predinfo_klic__comp__normalize_xadd__make__thread__1_5 = {
  (unsigned char *)"add_make_thread_1",
  &predicate_klic__comp__normalize_xadd__make__thread__1_5
};

extern Const struct predicate predicate_klic__comp__normalize_xadd__make__thread_4;
static Const struct predinfo predinfo_klic__comp__normalize_xadd__make__thread_4 = {
  (unsigned char *)"add_make_thread",
  &predicate_klic__comp__normalize_xadd__make__thread_4
};

static Const struct predinfo * Const preds_in_klic__comp__normalize[] = {
  &predinfo_klic__comp__normalize_xyes__const_5,
  &predinfo_klic__comp__normalize_xseparate__cond__1_9,
  &predinfo_klic__comp__normalize_xseparate__cond_5,
  &predinfo_klic__comp__normalize_xprint__error_1,
  &predinfo_klic__comp__normalize_xprint__data_2,
  &predinfo_klic__comp__normalize_xnorm__top__goal__unify_8,
  &predinfo_klic__comp__normalize_xnorm__top__goal__builtin_7,
  &predinfo_klic__comp__normalize_xnorm__top__goal_7,
  &predinfo_klic__comp__normalize_xnorm__tail__goal__unify_8,
  &predinfo_klic__comp__normalize_xnorm__tail__goal__generic_9,
  &predinfo_klic__comp__normalize_xnorm__tail__goal__builtin_8,
  &predinfo_klic__comp__normalize_xnorm__tail__goal_7,
  &predinfo_klic__comp__normalize_xnorm__pragma__thread_7,
  &predinfo_klic__comp__normalize_xnorm__pragma__tcall_7,
  &predinfo_klic__comp__normalize_xnorm__pragma__priority_8,
  &predinfo_klic__comp__normalize_xnorm__pragma__pragma__arg_8,
  &predinfo_klic__comp__normalize_xnorm__pragma__node_9,
  &predinfo_klic__comp__normalize_xnorm__pragma__lower__priority_8,
  &predinfo_klic__comp__normalize_xnorm__pragma__loop_7,
  &predinfo_klic__comp__normalize_xnorm__pragma__go_10,
  &predinfo_klic__comp__normalize_xnorm__pragma__1_8,
  &predinfo_klic__comp__normalize_xnorm__pragma__0_9,
  &predinfo_klic__comp__normalize_xnorm__pragma_8,
  &predinfo_klic__comp__normalize_xnorm__inline__arg__1_7,
  &predinfo_klic__comp__normalize_xnorm__inline__arg_11,
  &predinfo_klic__comp__normalize_xnorm__inline_2F12_240_13,
  &predinfo_klic__comp__normalize_xnorm__inline_12,
  &predinfo_klic__comp__normalize_xnorm__head_5,
  &predinfo_klic__comp__normalize_xnorm__guard__unify__new_6,
  &predinfo_klic__comp__normalize_xnorm__guard__unify__new_2F6_240_7,
  &predinfo_klic__comp__normalize_xnorm__guard__unify__args_10,
  &predinfo_klic__comp__normalize_xnorm__guard__unify_9,
  &predinfo_klic__comp__normalize_xnorm__guard__unify_2F9_241_2F10_240_9,
  &predinfo_klic__comp__normalize_xnorm__guard__unify_2F9_241_10,
  &predinfo_klic__comp__normalize_xnorm__guard__unify_2F9_240_10,
  &predinfo_klic__comp__normalize_xnorm__guard__term__1_7,
  &predinfo_klic__comp__normalize_xnorm__guard__term_6,
  &predinfo_klic__comp__normalize_xnorm__guard__goal_8,
  &predinfo_klic__comp__normalize_xnorm__guard__goal_2F8_241_8,
  &predinfo_klic__comp__normalize_xnorm__guard__goal_2F8_240_8,
  &predinfo_klic__comp__normalize_xnorm__guard__generic__3_13,
  &predinfo_klic__comp__normalize_xnorm__guard__generic__2_14,
  &predinfo_klic__comp__normalize_xnorm__guard__generic__1_14,
  &predinfo_klic__comp__normalize_xnorm__guard__generic_8,
  &predinfo_klic__comp__normalize_xnorm__guard__builts__1_12,
  &predinfo_klic__comp__normalize_xnorm__guard__builts_8,
  &predinfo_klic__comp__normalize_xnorm__guard_2F10_241_11,
  &predinfo_klic__comp__normalize_xnorm__guard_2F10_240_11,
  &predinfo_klic__comp__normalize_xnorm__guard_10,
  &predinfo_klic__comp__normalize_xnorm__gg__outs_9,
  &predinfo_klic__comp__normalize_xnorm__gg__ins__1_9,
  &predinfo_klic__comp__normalize_xnorm__gg__ins_8,
  &predinfo_klic__comp__normalize_xnorm__gg__in__out_7,
  &predinfo_klic__comp__normalize_xnorm__gg__in__2_8,
  &predinfo_klic__comp__normalize_xnorm__gg__in__1_10,
  &predinfo_klic__comp__normalize_xnorm__gg__in_9,
  &predinfo_klic__comp__normalize_xnorm__gg__count__out_4,
  &predinfo_klic__comp__normalize_xnorm__gg__2_6,
  &predinfo_klic__comp__normalize_xnorm__gg__1_8,
  &predinfo_klic__comp__normalize_xnorm__gg_5,
  &predinfo_klic__comp__normalize_xnorm__gblt__args__1_9,
  &predinfo_klic__comp__normalize_xnorm__gblt__args_8,
  &predinfo_klic__comp__normalize_xnorm__gblt__arg__2_8,
  &predinfo_klic__comp__normalize_xnorm__gblt__arg__1_10,
  &predinfo_klic__comp__normalize_xnorm__gblt__arg_9,
  &predinfo_klic__comp__normalize_xnorm__body__tail__1_8,
  &predinfo_klic__comp__normalize_xnorm__body__tail_7,
  &predinfo_klic__comp__normalize_xnorm__body__args__1_9,
  &predinfo_klic__comp__normalize_xnorm__body__args_8,
  &predinfo_klic__comp__normalize_xnorm__body__args_10,
  &predinfo_klic__comp__normalize_xnorm__body__arg__3__2_6,
  &predinfo_klic__comp__normalize_xnorm__body__arg__3__1_11,
  &predinfo_klic__comp__normalize_xnorm__body__arg__3_9,
  &predinfo_klic__comp__normalize_xnorm__body__arg__2_8,
  &predinfo_klic__comp__normalize_xnorm__body__arg__1_9,
  &predinfo_klic__comp__normalize_xnorm__body__arg__1_10,
  &predinfo_klic__comp__normalize_xnorm__body__arg_8,
  &predinfo_klic__comp__normalize_xnorm__body__1_9,
  &predinfo_klic__comp__normalize_xnorm__body_6,
  &predinfo_klic__comp__normalize_xnorm__args_8,
  &predinfo_klic__comp__normalize_xmake__arg__assoc_3,
  &predinfo_klic__comp__normalize_xis__const__args_3,
  &predinfo_klic__comp__normalize_xis__const__1_6,
  &predinfo_klic__comp__normalize_xis__const_5,
  &predinfo_klic__comp__normalize_xinline__arg__type_2,
  &predinfo_klic__comp__normalize_xgenerate_9,
  &predinfo_klic__comp__normalize_xexit_1,
  &predinfo_klic__comp__normalize_xcheck__gblt__input_5,
  &predinfo_klic__comp__normalize_xadd__make__thread__2_5,
  &predinfo_klic__comp__normalize_xadd__make__thread__1_5,
  &predinfo_klic__comp__normalize_xadd__make__thread_4,
  0
};
extern Const struct predicate predicate_klic__comp__util_xvector__to__list_4;
static Const struct predinfo predinfo_klic__comp__util_xvector__to__list_4 = {
  (unsigned char *)"vector_to_list",
  &predicate_klic__comp__util_xvector__to__list_4
};

extern Const struct predicate predicate_klic__comp__util_xvector__to__list_2;
static Const struct predinfo predinfo_klic__comp__util_xvector__to__list_2 = {
  (unsigned char *)"vector_to_list",
  &predicate_klic__comp__util_xvector__to__list_2
};

extern Const struct predicate predicate_klic__comp__util_xuniv__funct__to__list_5;
static Const struct predinfo predinfo_klic__comp__util_xuniv__funct__to__list_5 = {
  (unsigned char *)"univ_funct_to_list",
  &predicate_klic__comp__util_xuniv__funct__to__list_5
};

extern Const struct predicate predicate_klic__comp__util_xuniv_3;
static Const struct predinfo predinfo_klic__comp__util_xuniv_3 = {
  (unsigned char *)"univ",
  &predicate_klic__comp__util_xuniv_3
};

extern Const struct predicate predicate_klic__comp__util_xuniv_2;
static Const struct predinfo predinfo_klic__comp__util_xuniv_2 = {
  (unsigned char *)"univ",
  &predicate_klic__comp__util_xuniv_2
};

extern Const struct predicate predicate_klic__comp__util_xstring__to__char__list_4;
static Const struct predinfo predinfo_klic__comp__util_xstring__to__char__list_4 = {
  (unsigned char *)"string_to_char_list",
  &predicate_klic__comp__util_xstring__to__char__list_4
};

extern Const struct predicate predicate_klic__comp__util_xstring__to__char__list_2;
static Const struct predinfo predinfo_klic__comp__util_xstring__to__char__list_2 = {
  (unsigned char *)"string_to_char_list",
  &predicate_klic__comp__util_xstring__to__char__list_2
};

extern Const struct predicate predicate_klic__comp__util_xremove_4;
static Const struct predinfo predinfo_klic__comp__util_xremove_4 = {
  (unsigned char *)"remove",
  &predicate_klic__comp__util_xremove_4
};

extern Const struct predicate predicate_klic__comp__util_xqsort_3;
static Const struct predinfo predinfo_klic__comp__util_xqsort_3 = {
  (unsigned char *)"qsort",
  &predicate_klic__comp__util_xqsort_3
};

extern Const struct predicate predicate_klic__comp__util_xqsort_2;
static Const struct predinfo predinfo_klic__comp__util_xqsort_2 = {
  (unsigned char *)"qsort",
  &predicate_klic__comp__util_xqsort_2
};

extern Const struct predicate predicate_klic__comp__util_xpartition_4;
static Const struct predinfo predinfo_klic__comp__util_xpartition_4 = {
  (unsigned char *)"partition",
  &predicate_klic__comp__util_xpartition_4
};

extern Const struct predicate predicate_klic__comp__util_xnumbervars__vector_7;
static Const struct predinfo predinfo_klic__comp__util_xnumbervars__vector_7 = {
  (unsigned char *)"numbervars_vector",
  &predicate_klic__comp__util_xnumbervars__vector_7
};

extern Const struct predicate predicate_klic__comp__util_xnumbervars__funct_9;
static Const struct predinfo predinfo_klic__comp__util_xnumbervars__funct_9 = {
  (unsigned char *)"numbervars_funct",
  &predicate_klic__comp__util_xnumbervars__funct_9
};

extern Const struct predicate predicate_klic__comp__util_xnumbervars__1__pfirst_8;
static Const struct predinfo predinfo_klic__comp__util_xnumbervars__1__pfirst_8 = {
  (unsigned char *)"numbervars_1_pfirst",
  &predicate_klic__comp__util_xnumbervars__1__pfirst_8
};

extern Const struct predicate predicate_klic__comp__util_xnumbervars__1_8;
static Const struct predinfo predinfo_klic__comp__util_xnumbervars__1_8 = {
  (unsigned char *)"numbervars_1",
  &predicate_klic__comp__util_xnumbervars__1_8
};

extern Const struct predicate predicate_klic__comp__util_xnumbervars__1_7;
static Const struct predinfo predinfo_klic__comp__util_xnumbervars__1_7 = {
  (unsigned char *)"numbervars_1",
  &predicate_klic__comp__util_xnumbervars__1_7
};

extern Const struct predicate predicate_klic__comp__util_xnumbervars_6;
static Const struct predinfo predinfo_klic__comp__util_xnumbervars_6 = {
  (unsigned char *)"numbervars",
  &predicate_klic__comp__util_xnumbervars_6
};

extern Const struct predicate predicate_klic__comp__util_xnumbervars_4;
static Const struct predinfo predinfo_klic__comp__util_xnumbervars_4 = {
  (unsigned char *)"numbervars",
  &predicate_klic__comp__util_xnumbervars_4
};

extern Const struct predicate predicate_klic__comp__util_xnth_3;
static Const struct predinfo predinfo_klic__comp__util_xnth_3 = {
  (unsigned char *)"nth",
  &predicate_klic__comp__util_xnth_3
};

extern Const struct predicate predicate_klic__comp__util_xname__integer_3;
static Const struct predinfo predinfo_klic__comp__util_xname__integer_3 = {
  (unsigned char *)"name_integer",
  &predicate_klic__comp__util_xname__integer_3
};

extern Const struct predicate predicate_klic__comp__util_xname__integer_2;
static Const struct predinfo predinfo_klic__comp__util_xname__integer_2 = {
  (unsigned char *)"name_integer",
  &predicate_klic__comp__util_xname__integer_2
};

extern Const struct predicate predicate_klic__comp__util_xname_2;
static Const struct predinfo predinfo_klic__comp__util_xname_2 = {
  (unsigned char *)"name",
  &predicate_klic__comp__util_xname_2
};

extern Const struct predicate predicate_klic__comp__util_xmin_3;
static Const struct predinfo predinfo_klic__comp__util_xmin_3 = {
  (unsigned char *)"min",
  &predicate_klic__comp__util_xmin_3
};

extern Const struct predicate predicate_klic__comp__util_xmember_3;
static Const struct predinfo predinfo_klic__comp__util_xmember_3 = {
  (unsigned char *)"member",
  &predicate_klic__comp__util_xmember_3
};

extern Const struct predicate predicate_klic__comp__util_xmax__vect_4;
static Const struct predinfo predinfo_klic__comp__util_xmax__vect_4 = {
  (unsigned char *)"max_vect",
  &predicate_klic__comp__util_xmax__vect_4
};

extern Const struct predicate predicate_klic__comp__util_xmax__vect_2;
static Const struct predinfo predinfo_klic__comp__util_xmax__vect_2 = {
  (unsigned char *)"max_vect",
  &predicate_klic__comp__util_xmax__vect_2
};

extern Const struct predicate predicate_klic__comp__util_xmax_3;
static Const struct predinfo predinfo_klic__comp__util_xmax_3 = {
  (unsigned char *)"max",
  &predicate_klic__comp__util_xmax_3
};

extern Const struct predicate predicate_klic__comp__util_xmake__atom_2;
static Const struct predinfo predinfo_klic__comp__util_xmake__atom_2 = {
  (unsigned char *)"make_atom",
  &predicate_klic__comp__util_xmake__atom_2
};

extern Const struct predicate predicate_klic__comp__util_xlength_3;
static Const struct predinfo predinfo_klic__comp__util_xlength_3 = {
  (unsigned char *)"length",
  &predicate_klic__comp__util_xlength_3
};

extern Const struct predicate predicate_klic__comp__util_xlength_2;
static Const struct predinfo predinfo_klic__comp__util_xlength_2 = {
  (unsigned char *)"length",
  &predicate_klic__comp__util_xlength_2
};

extern Const struct predicate predicate_klic__comp__util_xassoc_3;
static Const struct predinfo predinfo_klic__comp__util_xassoc_3 = {
  (unsigned char *)"assoc",
  &predicate_klic__comp__util_xassoc_3
};

extern Const struct predicate predicate_klic__comp__util_xappend_3;
static Const struct predinfo predinfo_klic__comp__util_xappend_3 = {
  (unsigned char *)"append",
  &predicate_klic__comp__util_xappend_3
};

static Const struct predinfo * Const preds_in_klic__comp__util[] = {
  &predinfo_klic__comp__util_xvector__to__list_4,
  &predinfo_klic__comp__util_xvector__to__list_2,
  &predinfo_klic__comp__util_xuniv__funct__to__list_5,
  &predinfo_klic__comp__util_xuniv_3,
  &predinfo_klic__comp__util_xuniv_2,
  &predinfo_klic__comp__util_xstring__to__char__list_4,
  &predinfo_klic__comp__util_xstring__to__char__list_2,
  &predinfo_klic__comp__util_xremove_4,
  &predinfo_klic__comp__util_xqsort_3,
  &predinfo_klic__comp__util_xqsort_2,
  &predinfo_klic__comp__util_xpartition_4,
  &predinfo_klic__comp__util_xnumbervars__vector_7,
  &predinfo_klic__comp__util_xnumbervars__funct_9,
  &predinfo_klic__comp__util_xnumbervars__1__pfirst_8,
  &predinfo_klic__comp__util_xnumbervars__1_8,
  &predinfo_klic__comp__util_xnumbervars__1_7,
  &predinfo_klic__comp__util_xnumbervars_6,
  &predinfo_klic__comp__util_xnumbervars_4,
  &predinfo_klic__comp__util_xnth_3,
  &predinfo_klic__comp__util_xname__integer_3,
  &predinfo_klic__comp__util_xname__integer_2,
  &predinfo_klic__comp__util_xname_2,
  &predinfo_klic__comp__util_xmin_3,
  &predinfo_klic__comp__util_xmember_3,
  &predinfo_klic__comp__util_xmax__vect_4,
  &predinfo_klic__comp__util_xmax__vect_2,
  &predinfo_klic__comp__util_xmax_3,
  &predinfo_klic__comp__util_xmake__atom_2,
  &predinfo_klic__comp__util_xlength_3,
  &predinfo_klic__comp__util_xlength_2,
  &predinfo_klic__comp__util_xassoc_3,
  &predinfo_klic__comp__util_xappend_3,
  0
};
extern Const struct predicate predicate_comparator_xsort_5;
static Const struct predinfo predinfo_comparator_xsort_5 = {
  (unsigned char *)"sort",
  &predicate_comparator_xsort_5
};

static Const struct predinfo * Const preds_in_comparator[] = {
  &predinfo_comparator_xsort_5,
  0
};
extern Const struct predicate predicate_splay__tree_xupdate__right_2F11_240_15;
static Const struct predinfo predinfo_splay__tree_xupdate__right_2F11_240_15 = {
  (unsigned char *)"update_right/11$0",
  &predicate_splay__tree_xupdate__right_2F11_240_15
};

extern Const struct predicate predicate_splay__tree_xupdate__right_11;
static Const struct predinfo predinfo_splay__tree_xupdate__right_11 = {
  (unsigned char *)"update_right",
  &predicate_splay__tree_xupdate__right_11
};

extern Const struct predicate predicate_splay__tree_xupdate__left_2F11_240_15;
static Const struct predinfo predinfo_splay__tree_xupdate__left_2F11_240_15 = {
  (unsigned char *)"update_left/11$0",
  &predicate_splay__tree_xupdate__left_2F11_240_15
};

extern Const struct predicate predicate_splay__tree_xupdate__left_11;
static Const struct predinfo predinfo_splay__tree_xupdate__left_11 = {
  (unsigned char *)"update_left",
  &predicate_splay__tree_xupdate__left_11
};

extern Const struct predicate predicate_splay__tree_xupdate_8;
static Const struct predinfo predinfo_splay__tree_xupdate_8 = {
  (unsigned char *)"update",
  &predicate_splay__tree_xupdate_8
};

extern Const struct predicate predicate_splay__tree_xupdate_6;
static Const struct predinfo predinfo_splay__tree_xupdate_6 = {
  (unsigned char *)"update",
  &predicate_splay__tree_xupdate_6
};

extern Const struct predicate predicate_splay__tree_xupdate_5;
static Const struct predinfo predinfo_splay__tree_xupdate_5 = {
  (unsigned char *)"update",
  &predicate_splay__tree_xupdate_5
};

extern Const struct predicate predicate_splay__tree_xupdate_2F8_240_12;
static Const struct predinfo predinfo_splay__tree_xupdate_2F8_240_12 = {
  (unsigned char *)"update/8$0",
  &predicate_splay__tree_xupdate_2F8_240_12
};

extern Const struct predicate predicate_splay__tree_xreform__tree_3;
static Const struct predinfo predinfo_splay__tree_xreform__tree_3 = {
  (unsigned char *)"reform_tree",
  &predicate_splay__tree_xreform__tree_3
};

extern Const struct predicate predicate_splay__tree_xrefer_5;
static Const struct predinfo predinfo_splay__tree_xrefer_5 = {
  (unsigned char *)"refer",
  &predicate_splay__tree_xrefer_5
};

extern Const struct predicate predicate_splay__tree_xput_4;
static Const struct predinfo predinfo_splay__tree_xput_4 = {
  (unsigned char *)"put",
  &predicate_splay__tree_xput_4
};

extern Const struct predicate predicate_splay__tree_xget__min__sub_4;
static Const struct predinfo predinfo_splay__tree_xget__min__sub_4 = {
  (unsigned char *)"get_min_sub",
  &predicate_splay__tree_xget__min__sub_4
};

extern Const struct predicate predicate_splay__tree_xget__min_4;
static Const struct predinfo predinfo_splay__tree_xget__min_4 = {
  (unsigned char *)"get_min",
  &predicate_splay__tree_xget__min_4
};

extern Const struct predicate predicate_splay__tree_xget__max__sub_4;
static Const struct predinfo predinfo_splay__tree_xget__max__sub_4 = {
  (unsigned char *)"get_max_sub",
  &predicate_splay__tree_xget__max__sub_4
};

extern Const struct predicate predicate_splay__tree_xget__max_4;
static Const struct predinfo predinfo_splay__tree_xget__max_4 = {
  (unsigned char *)"get_max",
  &predicate_splay__tree_xget__max_4
};

extern Const struct predicate predicate_splay__tree_xget__all__sub_3;
static Const struct predinfo predinfo_splay__tree_xget__all__sub_3 = {
  (unsigned char *)"get_all_sub",
  &predicate_splay__tree_xget__all__sub_3
};

extern Const struct predicate predicate_splay__tree_xget__all_3;
static Const struct predinfo predinfo_splay__tree_xget__all_3 = {
  (unsigned char *)"get_all",
  &predicate_splay__tree_xget__all_3
};

extern Const struct predicate predicate_splay__tree_xget_5;
static Const struct predinfo predinfo_splay__tree_xget_5 = {
  (unsigned char *)"get",
  &predicate_splay__tree_xget_5
};

extern Const struct predicate predicate_splay__tree_xget_4;
static Const struct predinfo predinfo_splay__tree_xget_4 = {
  (unsigned char *)"get",
  &predicate_splay__tree_xget_4
};

extern Const struct predicate predicate_splay__tree_xget_2F5_241_3;
static Const struct predinfo predinfo_splay__tree_xget_2F5_241_3 = {
  (unsigned char *)"get/5$1",
  &predicate_splay__tree_xget_2F5_241_3
};

extern Const struct predicate predicate_splay__tree_xget_2F5_240_9;
static Const struct predinfo predinfo_splay__tree_xget_2F5_240_9 = {
  (unsigned char *)"get/5$0",
  &predicate_splay__tree_xget_2F5_240_9
};

extern Const struct predicate predicate_splay__tree_xempty__sub_4;
static Const struct predinfo predinfo_splay__tree_xempty__sub_4 = {
  (unsigned char *)"empty_sub",
  &predicate_splay__tree_xempty__sub_4
};

extern Const struct predicate predicate_splay__tree_xempty__sub_2F4_240_6;
static Const struct predinfo predinfo_splay__tree_xempty__sub_2F4_240_6 = {
  (unsigned char *)"empty_sub/4$0",
  &predicate_splay__tree_xempty__sub_2F4_240_6
};

extern Const struct predicate predicate_splay__tree_xempty_4;
static Const struct predinfo predinfo_splay__tree_xempty_4 = {
  (unsigned char *)"empty",
  &predicate_splay__tree_xempty_4
};

extern Const struct predicate predicate_splay__tree_xempty_3;
static Const struct predinfo predinfo_splay__tree_xempty_3 = {
  (unsigned char *)"empty",
  &predicate_splay__tree_xempty_3
};

extern Const struct predicate predicate_splay__tree_xempty_2F3_240_3;
static Const struct predinfo predinfo_splay__tree_xempty_2F3_240_3 = {
  (unsigned char *)"empty/3$0",
  &predicate_splay__tree_xempty_2F3_240_3
};

extern Const struct predicate predicate_splay__tree_xdefault__comparator_1;
static Const struct predinfo predinfo_splay__tree_xdefault__comparator_1 = {
  (unsigned char *)"default_comparator",
  &predicate_splay__tree_xdefault__comparator_1
};

extern Const struct predicate predicate_splay__tree_xcreate_2;
static Const struct predinfo predinfo_splay__tree_xcreate_2 = {
  (unsigned char *)"create",
  &predicate_splay__tree_xcreate_2
};

extern Const struct predicate predicate_splay__tree_xcreate_1;
static Const struct predinfo predinfo_splay__tree_xcreate_1 = {
  (unsigned char *)"create",
  &predicate_splay__tree_xcreate_1
};

static Const struct predinfo * Const preds_in_splay__tree[] = {
  &predinfo_splay__tree_xupdate__right_2F11_240_15,
  &predinfo_splay__tree_xupdate__right_11,
  &predinfo_splay__tree_xupdate__left_2F11_240_15,
  &predinfo_splay__tree_xupdate__left_11,
  &predinfo_splay__tree_xupdate_8,
  &predinfo_splay__tree_xupdate_6,
  &predinfo_splay__tree_xupdate_5,
  &predinfo_splay__tree_xupdate_2F8_240_12,
  &predinfo_splay__tree_xreform__tree_3,
  &predinfo_splay__tree_xrefer_5,
  &predinfo_splay__tree_xput_4,
  &predinfo_splay__tree_xget__min__sub_4,
  &predinfo_splay__tree_xget__min_4,
  &predinfo_splay__tree_xget__max__sub_4,
  &predinfo_splay__tree_xget__max_4,
  &predinfo_splay__tree_xget__all__sub_3,
  &predinfo_splay__tree_xget__all_3,
  &predinfo_splay__tree_xget_5,
  &predinfo_splay__tree_xget_4,
  &predinfo_splay__tree_xget_2F5_241_3,
  &predinfo_splay__tree_xget_2F5_240_9,
  &predinfo_splay__tree_xempty__sub_4,
  &predinfo_splay__tree_xempty__sub_2F4_240_6,
  &predinfo_splay__tree_xempty_4,
  &predinfo_splay__tree_xempty_3,
  &predinfo_splay__tree_xempty_2F3_240_3,
  &predinfo_splay__tree_xdefault__comparator_1,
  &predinfo_splay__tree_xcreate_2,
  &predinfo_splay__tree_xcreate_1,
  0
};
extern Const struct predicate predicate_keyed__sorted__set_xmessage_3;
static Const struct predinfo predinfo_keyed__sorted__set_xmessage_3 = {
  (unsigned char *)"message",
  &predicate_keyed__sorted__set_xmessage_3
};

extern Const struct predicate predicate_keyed__sorted__set_xmessage_2F3_246_5;
static Const struct predinfo predinfo_keyed__sorted__set_xmessage_2F3_246_5 = {
  (unsigned char *)"message/3$6",
  &predicate_keyed__sorted__set_xmessage_2F3_246_5
};

extern Const struct predicate predicate_keyed__sorted__set_xmessage_2F3_245_5;
static Const struct predinfo predinfo_keyed__sorted__set_xmessage_2F3_245_5 = {
  (unsigned char *)"message/3$5",
  &predicate_keyed__sorted__set_xmessage_2F3_245_5
};

extern Const struct predicate predicate_keyed__sorted__set_xmessage_2F3_244_5;
static Const struct predinfo predinfo_keyed__sorted__set_xmessage_2F3_244_5 = {
  (unsigned char *)"message/3$4",
  &predicate_keyed__sorted__set_xmessage_2F3_244_5
};

extern Const struct predicate predicate_keyed__sorted__set_xmessage_2F3_243_6;
static Const struct predinfo predinfo_keyed__sorted__set_xmessage_2F3_243_6 = {
  (unsigned char *)"message/3$3",
  &predicate_keyed__sorted__set_xmessage_2F3_243_6
};

extern Const struct predicate predicate_keyed__sorted__set_xmessage_2F3_242_7;
static Const struct predinfo predinfo_keyed__sorted__set_xmessage_2F3_242_7 = {
  (unsigned char *)"message/3$2",
  &predicate_keyed__sorted__set_xmessage_2F3_242_7
};

extern Const struct predicate predicate_keyed__sorted__set_xmessage_2F3_241_4;
static Const struct predinfo predinfo_keyed__sorted__set_xmessage_2F3_241_4 = {
  (unsigned char *)"message/3$1",
  &predicate_keyed__sorted__set_xmessage_2F3_241_4
};

extern Const struct predicate predicate_keyed__sorted__set_xmessage_2F3_240_4;
static Const struct predinfo predinfo_keyed__sorted__set_xmessage_2F3_240_4 = {
  (unsigned char *)"message/3$0",
  &predicate_keyed__sorted__set_xmessage_2F3_240_4
};

extern Const struct predicate predicate_keyed__sorted__set_xmain_3;
static Const struct predinfo predinfo_keyed__sorted__set_xmain_3 = {
  (unsigned char *)"main",
  &predicate_keyed__sorted__set_xmain_3
};

extern Const struct predicate predicate_keyed__sorted__set_xcreate_2;
static Const struct predinfo predinfo_keyed__sorted__set_xcreate_2 = {
  (unsigned char *)"create",
  &predicate_keyed__sorted__set_xcreate_2
};

extern Const struct predicate predicate_keyed__sorted__set_xcreate_1;
static Const struct predinfo predinfo_keyed__sorted__set_xcreate_1 = {
  (unsigned char *)"create",
  &predicate_keyed__sorted__set_xcreate_1
};

extern Const struct predicate predicate_keyed__sorted__set_xconvert_2;
static Const struct predinfo predinfo_keyed__sorted__set_xconvert_2 = {
  (unsigned char *)"convert",
  &predicate_keyed__sorted__set_xconvert_2
};

static Const struct predinfo * Const preds_in_keyed__sorted__set[] = {
  &predinfo_keyed__sorted__set_xmessage_3,
  &predinfo_keyed__sorted__set_xmessage_2F3_246_5,
  &predinfo_keyed__sorted__set_xmessage_2F3_245_5,
  &predinfo_keyed__sorted__set_xmessage_2F3_244_5,
  &predinfo_keyed__sorted__set_xmessage_2F3_243_6,
  &predinfo_keyed__sorted__set_xmessage_2F3_242_7,
  &predinfo_keyed__sorted__set_xmessage_2F3_241_4,
  &predinfo_keyed__sorted__set_xmessage_2F3_240_4,
  &predinfo_keyed__sorted__set_xmain_3,
  &predinfo_keyed__sorted__set_xcreate_2,
  &predinfo_keyed__sorted__set_xcreate_1,
  &predinfo_keyed__sorted__set_xconvert_2,
  0
};
extern Const struct predicate predicate_klic__comp__extern_xmake__ext__table_3;
static Const struct predinfo predinfo_klic__comp__extern_xmake__ext__table_3 = {
  (unsigned char *)"make_ext_table",
  &predicate_klic__comp__extern_xmake__ext__table_3
};

extern Const struct predicate predicate_klic__comp__extern_xext__struct__vector_5;
static Const struct predinfo predinfo_klic__comp__extern_xext__struct__vector_5 = {
  (unsigned char *)"ext_struct_vector",
  &predicate_klic__comp__extern_xext__struct__vector_5
};

extern Const struct predicate predicate_klic__comp__extern_xext__struct__funct_5;
static Const struct predinfo predinfo_klic__comp__extern_xext__struct__funct_5 = {
  (unsigned char *)"ext_struct_funct",
  &predicate_klic__comp__extern_xext__struct__funct_5
};

extern Const struct predicate predicate_klic__comp__extern_xext__struct_3;
static Const struct predinfo predinfo_klic__comp__extern_xext__struct_3 = {
  (unsigned char *)"ext_struct",
  &predicate_klic__comp__extern_xext__struct_3
};

static Const struct predinfo * Const preds_in_klic__comp__extern[] = {
  &predinfo_klic__comp__extern_xmake__ext__table_3,
  &predinfo_klic__comp__extern_xext__struct__vector_5,
  &predinfo_klic__comp__extern_xext__struct__funct_5,
  &predinfo_klic__comp__extern_xext__struct_3,
  0
};
extern Const struct predicate predicate_klic__comp__write_xwrite__threadrec_3;
static Const struct predinfo predinfo_klic__comp__write_xwrite__threadrec_3 = {
  (unsigned char *)"write_threadrec",
  &predicate_klic__comp__write_xwrite__threadrec_3
};

extern Const struct predicate predicate_klic__comp__write_xwrite__string__elements_5;
static Const struct predinfo predinfo_klic__comp__write_xwrite__string__elements_5 = {
  (unsigned char *)"write_string_elements",
  &predicate_klic__comp__write_xwrite__string__elements_5
};

extern Const struct predicate predicate_klic__comp__write_xwrite__string__element_3;
static Const struct predinfo predinfo_klic__comp__write_xwrite__string__element_3 = {
  (unsigned char *)"write_string_element",
  &predicate_klic__comp__write_xwrite__string__element_3
};

extern Const struct predicate predicate_klic__comp__write_xwrite__string__body_4;
static Const struct predinfo predinfo_klic__comp__write_xwrite__string__body_4 = {
  (unsigned char *)"write_string_body",
  &predicate_klic__comp__write_xwrite__string__body_4
};

extern Const struct predicate predicate_klic__comp__write_xwrite__predicates__1_6;
static Const struct predinfo predinfo_klic__comp__write_xwrite__predicates__1_6 = {
  (unsigned char *)"write_predicates_1",
  &predicate_klic__comp__write_xwrite__predicates__1_6
};

extern Const struct predicate predicate_klic__comp__write_xwrite__predicates_6;
static Const struct predinfo predinfo_klic__comp__write_xwrite__predicates_6 = {
  (unsigned char *)"write_predicates",
  &predicate_klic__comp__write_xwrite__predicates_6
};

extern Const struct predicate predicate_klic__comp__write_xwrite__pred__structs_4;
static Const struct predinfo predinfo_klic__comp__write_xwrite__pred__structs_4 = {
  (unsigned char *)"write_pred_structs",
  &predicate_klic__comp__write_xwrite__pred__structs_4
};

extern Const struct predicate predicate_klic__comp__write_xwrite__pred__name_5;
static Const struct predinfo predinfo_klic__comp__write_xwrite__pred__name_5 = {
  (unsigned char *)"write_pred_name",
  &predicate_klic__comp__write_xwrite__pred__name_5
};

extern Const struct predicate predicate_klic__comp__write_xwrite__pred__dispatch_3;
static Const struct predinfo predinfo_klic__comp__write_xwrite__pred__dispatch_3 = {
  (unsigned char *)"write_pred_dispatch",
  &predicate_klic__comp__write_xwrite__pred__dispatch_3
};

extern Const struct predicate predicate_klic__comp__write_xwrite__out_3;
static Const struct predinfo predinfo_klic__comp__write_xwrite__out_3 = {
  (unsigned char *)"write_out",
  &predicate_klic__comp__write_xwrite__out_3
};

extern Const struct predicate predicate_klic__comp__write_xwrite__interrupt__call_4;
static Const struct predinfo predinfo_klic__comp__write_xwrite__interrupt__call_4 = {
  (unsigned char *)"write_interrupt_call",
  &predicate_klic__comp__write_xwrite__interrupt__call_4
};

extern Const struct predicate predicate_klic__comp__write_xwrite__header__file_3;
static Const struct predinfo predinfo_klic__comp__write_xwrite__header__file_3 = {
  (unsigned char *)"write_header_file",
  &predicate_klic__comp__write_xwrite__header__file_3
};

extern Const struct predicate predicate_klic__comp__write_xwrite__get__args__1_5;
static Const struct predinfo predinfo_klic__comp__write_xwrite__get__args__1_5 = {
  (unsigned char *)"write_get_args_1",
  &predicate_klic__comp__write_xwrite__get__args__1_5
};

extern Const struct predicate predicate_klic__comp__write_xwrite__get__args_4;
static Const struct predinfo predinfo_klic__comp__write_xwrite__get__args_4 = {
  (unsigned char *)"write_get_args",
  &predicate_klic__comp__write_xwrite__get__args_4
};

extern Const struct predicate predicate_klic__comp__write_xwrite__funct__name_4;
static Const struct predinfo predinfo_klic__comp__write_xwrite__funct__name_4 = {
  (unsigned char *)"write_funct_name",
  &predicate_klic__comp__write_xwrite__funct__name_4
};

extern Const struct predicate predicate_klic__comp__write_xwrite__ext__entry_3;
static Const struct predinfo predinfo_klic__comp__write_xwrite__ext__entry_3 = {
  (unsigned char *)"write_ext_entry",
  &predicate_klic__comp__write_xwrite__ext__entry_3
};

extern Const struct predicate predicate_klic__comp__write_xwrite__ext__entries_3;
static Const struct predinfo predinfo_klic__comp__write_xwrite__ext__entries_3 = {
  (unsigned char *)"write_ext_entries",
  &predicate_klic__comp__write_xwrite__ext__entries_3
};

extern Const struct predicate predicate_klic__comp__write_xwrite__defined__preds_4;
static Const struct predinfo predinfo_klic__comp__write_xwrite__defined__preds_4 = {
  (unsigned char *)"write_defined_preds",
  &predicate_klic__comp__write_xwrite__defined__preds_4
};

extern Const struct predicate predicate_klic__comp__write_xwrite__const__elems_3;
static Const struct predinfo predinfo_klic__comp__write_xwrite__const__elems_3 = {
  (unsigned char *)"write_const_elems",
  &predicate_klic__comp__write_xwrite__const__elems_3
};

extern Const struct predicate predicate_klic__comp__write_xwrite__const__elem_3;
static Const struct predinfo predinfo_klic__comp__write_xwrite__const__elem_3 = {
  (unsigned char *)"write_const_elem",
  &predicate_klic__comp__write_xwrite__const__elem_3
};

extern Const struct predicate predicate_klic__comp__write_xwrite__comma__list_5;
static Const struct predinfo predinfo_klic__comp__write_xwrite__comma__list_5 = {
  (unsigned char *)"write_comma_list",
  &predicate_klic__comp__write_xwrite__comma__list_5
};

extern Const struct predicate predicate_klic__comp__write_xwrite__comma__list1_5;
static Const struct predinfo predinfo_klic__comp__write_xwrite__comma__list1_5 = {
  (unsigned char *)"write_comma_list1",
  &predicate_klic__comp__write_xwrite__comma__list1_5
};

extern Const struct predicate predicate_klic__comp__write_xwrite__character__constants_5;
static Const struct predinfo predinfo_klic__comp__write_xwrite__character__constants_5 = {
  (unsigned char *)"write_character_constants",
  &predicate_klic__comp__write_xwrite__character__constants_5
};

extern Const struct predicate predicate_klic__comp__write_xwrite__atom_3;
static Const struct predinfo predinfo_klic__comp__write_xwrite__atom_3 = {
  (unsigned char *)"write_atom",
  &predicate_klic__comp__write_xwrite__atom_3
};

extern Const struct predicate predicate_klic__comp__write_xsort__info_3;
static Const struct predinfo predinfo_klic__comp__write_xsort__info_3 = {
  (unsigned char *)"sort_info",
  &predicate_klic__comp__write_xsort__info_3
};

extern Const struct predicate predicate_klic__comp__write_xsort__info_2;
static Const struct predinfo predinfo_klic__comp__write_xsort__info_2 = {
  (unsigned char *)"sort_info",
  &predicate_klic__comp__write_xsort__info_2
};

extern Const struct predicate predicate_klic__comp__write_xprev__write__pred__dispatch_3;
static Const struct predinfo predinfo_klic__comp__write_xprev__write__pred__dispatch_3 = {
  (unsigned char *)"prev_write_pred_dispatch",
  &predicate_klic__comp__write_xprev__write__pred__dispatch_3
};

extern Const struct predicate predicate_klic__comp__write_xpred__min__max_5;
static Const struct predinfo predinfo_klic__comp__write_xpred__min__max_5 = {
  (unsigned char *)"pred_min_max",
  &predicate_klic__comp__write_xpred__min__max_5
};

extern Const struct predicate predicate_klic__comp__write_xpartition_4;
static Const struct predinfo predinfo_klic__comp__write_xpartition_4 = {
  (unsigned char *)"partition",
  &predicate_klic__comp__write_xpartition_4
};

extern Const struct predicate predicate_klic__comp__write_xdeclare__threadrec_4;
static Const struct predinfo predinfo_klic__comp__write_xdeclare__threadrec_4 = {
  (unsigned char *)"declare_threadrec",
  &predicate_klic__comp__write_xdeclare__threadrec_4
};

extern Const struct predicate predicate_klic__comp__write_xdeclare__registers_4;
static Const struct predinfo predinfo_klic__comp__write_xdeclare__registers_4 = {
  (unsigned char *)"declare_registers",
  &predicate_klic__comp__write_xdeclare__registers_4
};

extern Const struct predicate predicate_klic__comp__write_xdeclare__one__external_3;
static Const struct predinfo predinfo_klic__comp__write_xdeclare__one__external_3 = {
  (unsigned char *)"declare_one_external",
  &predicate_klic__comp__write_xdeclare__one__external_3
};

extern Const struct predicate predicate_klic__comp__write_xdeclare__externals_3;
static Const struct predinfo predinfo_klic__comp__write_xdeclare__externals_3 = {
  (unsigned char *)"declare_externals",
  &predicate_klic__comp__write_xdeclare__externals_3
};

extern Const struct predicate predicate_klic__comp__write_xdeclare__const__list_6;
static Const struct predinfo predinfo_klic__comp__write_xdeclare__const__list_6 = {
  (unsigned char *)"declare_const_list",
  &predicate_klic__comp__write_xdeclare__const__list_6
};

extern Const struct predicate predicate_klic__comp__write_xdeclare__const_6;
static Const struct predinfo predinfo_klic__comp__write_xdeclare__const_6 = {
  (unsigned char *)"declare_const",
  &predicate_klic__comp__write_xdeclare__const_6
};

extern Const struct predicate predicate_klic__comp__write_xdeclare__const_5;
static Const struct predinfo predinfo_klic__comp__write_xdeclare__const_5 = {
  (unsigned char *)"declare_const",
  &predicate_klic__comp__write_xdeclare__const_5
};

static Const struct predinfo * Const preds_in_klic__comp__write[] = {
  &predinfo_klic__comp__write_xwrite__threadrec_3,
  &predinfo_klic__comp__write_xwrite__string__elements_5,
  &predinfo_klic__comp__write_xwrite__string__element_3,
  &predinfo_klic__comp__write_xwrite__string__body_4,
  &predinfo_klic__comp__write_xwrite__predicates__1_6,
  &predinfo_klic__comp__write_xwrite__predicates_6,
  &predinfo_klic__comp__write_xwrite__pred__structs_4,
  &predinfo_klic__comp__write_xwrite__pred__name_5,
  &predinfo_klic__comp__write_xwrite__pred__dispatch_3,
  &predinfo_klic__comp__write_xwrite__out_3,
  &predinfo_klic__comp__write_xwrite__interrupt__call_4,
  &predinfo_klic__comp__write_xwrite__header__file_3,
  &predinfo_klic__comp__write_xwrite__get__args__1_5,
  &predinfo_klic__comp__write_xwrite__get__args_4,
  &predinfo_klic__comp__write_xwrite__funct__name_4,
  &predinfo_klic__comp__write_xwrite__ext__entry_3,
  &predinfo_klic__comp__write_xwrite__ext__entries_3,
  &predinfo_klic__comp__write_xwrite__defined__preds_4,
  &predinfo_klic__comp__write_xwrite__const__elems_3,
  &predinfo_klic__comp__write_xwrite__const__elem_3,
  &predinfo_klic__comp__write_xwrite__comma__list_5,
  &predinfo_klic__comp__write_xwrite__comma__list1_5,
  &predinfo_klic__comp__write_xwrite__character__constants_5,
  &predinfo_klic__comp__write_xwrite__atom_3,
  &predinfo_klic__comp__write_xsort__info_3,
  &predinfo_klic__comp__write_xsort__info_2,
  &predinfo_klic__comp__write_xprev__write__pred__dispatch_3,
  &predinfo_klic__comp__write_xpred__min__max_5,
  &predinfo_klic__comp__write_xpartition_4,
  &predinfo_klic__comp__write_xdeclare__threadrec_4,
  &predinfo_klic__comp__write_xdeclare__registers_4,
  &predinfo_klic__comp__write_xdeclare__one__external_3,
  &predinfo_klic__comp__write_xdeclare__externals_3,
  &predinfo_klic__comp__write_xdeclare__const__list_6,
  &predinfo_klic__comp__write_xdeclare__const_6,
  &predinfo_klic__comp__write_xdeclare__const_5,
  0
};
extern Const struct predicate predicate_klic__comp__version_xcompiler__version_1;
static Const struct predinfo predinfo_klic__comp__version_xcompiler__version_1 = {
  (unsigned char *)"compiler_version",
  &predicate_klic__comp__version_xcompiler__version_1
};

extern Const struct predicate predicate_klic__comp__version_xcompiler__date_1;
static Const struct predinfo predinfo_klic__comp__version_xcompiler__date_1 = {
  (unsigned char *)"compiler_date",
  &predicate_klic__comp__version_xcompiler__date_1
};

static Const struct predinfo * Const preds_in_klic__comp__version[] = {
  &predinfo_klic__comp__version_xcompiler__version_1,
  &predinfo_klic__comp__version_xcompiler__date_1,
  0
};
extern Const struct predicate predicate_klic__comp__macro_xupdate__info__1_9;
static Const struct predinfo predinfo_klic__comp__macro_xupdate__info__1_9 = {
  (unsigned char *)"update_info_1",
  &predicate_klic__comp__macro_xupdate__info__1_9
};

extern Const struct predicate predicate_klic__comp__macro_xupdate__info_6;
static Const struct predinfo predinfo_klic__comp__macro_xupdate__info_6 = {
  (unsigned char *)"update_info",
  &predicate_klic__comp__macro_xupdate__info_6
};

extern Const struct predicate predicate_klic__comp__macro_xreplace__vars__elems_3;
static Const struct predinfo predinfo_klic__comp__macro_xreplace__vars__elems_3 = {
  (unsigned char *)"replace_vars_elems",
  &predicate_klic__comp__macro_xreplace__vars__elems_3
};

extern Const struct predicate predicate_klic__comp__macro_xreplace__vars__1_3;
static Const struct predinfo predinfo_klic__comp__macro_xreplace__vars__1_3 = {
  (unsigned char *)"replace_vars_1",
  &predicate_klic__comp__macro_xreplace__vars__1_3
};

extern Const struct predicate predicate_klic__comp__macro_xreplace__vars_3;
static Const struct predinfo predinfo_klic__comp__macro_xreplace__vars_3 = {
  (unsigned char *)"replace_vars",
  &predicate_klic__comp__macro_xreplace__vars_3
};

extern Const struct predicate predicate_klic__comp__macro_xmerge__vinfo_5;
static Const struct predinfo predinfo_klic__comp__macro_xmerge__vinfo_5 = {
  (unsigned char *)"merge_vinfo",
  &predicate_klic__comp__macro_xmerge__vinfo_5
};

extern Const struct predicate predicate_klic__comp__macro_xmake__expanded__call_2;
static Const struct predinfo predinfo_klic__comp__macro_xmake__expanded__call_2 = {
  (unsigned char *)"make_expanded_call",
  &predicate_klic__comp__macro_xmake__expanded__call_2
};

extern Const struct predicate predicate_klic__comp__macro_xmacro__vector__elems_10;
static Const struct predinfo predinfo_klic__comp__macro_xmacro__vector__elems_10 = {
  (unsigned char *)"macro_vector_elems",
  &predicate_klic__comp__macro_xmacro__vector__elems_10
};

extern Const struct predicate predicate_klic__comp__macro_xmacro__vec__elems_8;
static Const struct predinfo predinfo_klic__comp__macro_xmacro__vec__elems_8 = {
  (unsigned char *)"macro_vec_elems",
  &predicate_klic__comp__macro_xmacro__vec__elems_8
};

extern Const struct predicate predicate_klic__comp__macro_xmacro__goal__functor__cmp_9;
static Const struct predinfo predinfo_klic__comp__macro_xmacro__goal__functor__cmp_9 = {
  (unsigned char *)"macro_goal_functor_cmp",
  &predicate_klic__comp__macro_xmacro__goal__functor__cmp_9
};

extern Const struct predicate predicate_klic__comp__macro_xmacro__goal__functor_8;
static Const struct predinfo predinfo_klic__comp__macro_xmacro__goal__functor_8 = {
  (unsigned char *)"macro_goal_functor",
  &predicate_klic__comp__macro_xmacro__goal__functor_8
};

extern Const struct predicate predicate_klic__comp__macro_xmacro__goal_8;
static Const struct predinfo predinfo_klic__comp__macro_xmacro__goal_8 = {
  (unsigned char *)"macro_goal",
  &predicate_klic__comp__macro_xmacro__goal_8
};

extern Const struct predicate predicate_klic__comp__macro_xmacro__float__op_2;
static Const struct predinfo predinfo_klic__comp__macro_xmacro__float__op_2 = {
  (unsigned char *)"macro_float_op",
  &predicate_klic__comp__macro_xmacro__float__op_2
};

extern Const struct predicate predicate_klic__comp__macro_xmacro__float__exp__1_7;
static Const struct predinfo predinfo_klic__comp__macro_xmacro__float__exp__1_7 = {
  (unsigned char *)"macro_float_exp_1",
  &predicate_klic__comp__macro_xmacro__float__exp__1_7
};

extern Const struct predicate predicate_klic__comp__macro_xmacro__float__exp_6;
static Const struct predinfo predinfo_klic__comp__macro_xmacro__float__exp_6 = {
  (unsigned char *)"macro_float_exp",
  &predicate_klic__comp__macro_xmacro__float__exp_6
};

extern Const struct predicate predicate_klic__comp__macro_xmacro__float__args_7;
static Const struct predinfo predinfo_klic__comp__macro_xmacro__float__args_7 = {
  (unsigned char *)"macro_float_args",
  &predicate_klic__comp__macro_xmacro__float__args_7
};

extern Const struct predicate predicate_klic__comp__macro_xmacro__exp__args_7;
static Const struct predinfo predinfo_klic__comp__macro_xmacro__exp__args_7 = {
  (unsigned char *)"macro_exp_args",
  &predicate_klic__comp__macro_xmacro__exp__args_7
};

extern Const struct predicate predicate_klic__comp__macro_xmacro__exp__1_7;
static Const struct predinfo predinfo_klic__comp__macro_xmacro__exp__1_7 = {
  (unsigned char *)"macro_exp_1",
  &predicate_klic__comp__macro_xmacro__exp__1_7
};

extern Const struct predicate predicate_klic__comp__macro_xmacro__exp_6;
static Const struct predinfo predinfo_klic__comp__macro_xmacro__exp_6 = {
  (unsigned char *)"macro_exp",
  &predicate_klic__comp__macro_xmacro__exp_6
};

extern Const struct predicate predicate_klic__comp__macro_xmacro__arith__op_2;
static Const struct predinfo predinfo_klic__comp__macro_xmacro__arith__op_2 = {
  (unsigned char *)"macro_arith_op",
  &predicate_klic__comp__macro_xmacro__arith__op_2
};

extern Const struct predicate predicate_klic__comp__macro_xmacro__args_9;
static Const struct predinfo predinfo_klic__comp__macro_xmacro__args_9 = {
  (unsigned char *)"macro_args",
  &predicate_klic__comp__macro_xmacro__args_9
};

extern Const struct predicate predicate_klic__comp__macro_xmacro__arg__n_8;
static Const struct predinfo predinfo_klic__comp__macro_xmacro__arg__n_8 = {
  (unsigned char *)"macro_arg_n",
  &predicate_klic__comp__macro_xmacro__arg__n_8
};

extern Const struct predicate predicate_klic__comp__macro_xmacro__arg__functor__sharp_10;
static Const struct predinfo predinfo_klic__comp__macro_xmacro__arg__functor__sharp_10 = {
  (unsigned char *)"macro_arg_functor_sharp",
  &predicate_klic__comp__macro_xmacro__arg__functor__sharp_10
};

extern Const struct predicate predicate_klic__comp__macro_xmacro__arg__functor_9;
static Const struct predinfo predinfo_klic__comp__macro_xmacro__arg__functor_9 = {
  (unsigned char *)"macro_arg_functor",
  &predicate_klic__comp__macro_xmacro__arg__functor_9
};

extern Const struct predicate predicate_klic__comp__macro_xmacro__arg_9;
static Const struct predinfo predinfo_klic__comp__macro_xmacro__arg_9 = {
  (unsigned char *)"macro_arg",
  &predicate_klic__comp__macro_xmacro__arg_9
};

extern Const struct predicate predicate_klic__comp__macro_xmacro__N__10_4;
static Const struct predinfo predinfo_klic__comp__macro_xmacro__N__10_4 = {
  (unsigned char *)"macro_N_10",
  &predicate_klic__comp__macro_xmacro__N__10_4
};

extern Const struct predicate predicate_klic__comp__macro_xmacro__1_3;
static Const struct predinfo predinfo_klic__comp__macro_xmacro__1_3 = {
  (unsigned char *)"macro_1",
  &predicate_klic__comp__macro_xmacro__1_3
};

extern Const struct predicate predicate_klic__comp__macro_xmacro_2;
static Const struct predinfo predinfo_klic__comp__macro_xmacro_2 = {
  (unsigned char *)"macro",
  &predicate_klic__comp__macro_xmacro_2
};

extern Const struct predicate predicate_klic__comp__macro_xlinearize__guard_3;
static Const struct predinfo predinfo_klic__comp__macro_xlinearize__guard_3 = {
  (unsigned char *)"linearize_guard",
  &predicate_klic__comp__macro_xlinearize__guard_3
};

extern Const struct predicate predicate_klic__comp__macro_xinitialize__info__1_10;
static Const struct predinfo predinfo_klic__comp__macro_xinitialize__info__1_10 = {
  (unsigned char *)"initialize_info_1",
  &predicate_klic__comp__macro_xinitialize__info__1_10
};

extern Const struct predicate predicate_klic__comp__macro_xinitialize__info_7;
static Const struct predinfo predinfo_klic__comp__macro_xinitialize__info_7 = {
  (unsigned char *)"initialize_info",
  &predicate_klic__comp__macro_xinitialize__info_7
};

extern Const struct predicate predicate_klic__comp__macro_xfindvars__elems_3;
static Const struct predinfo predinfo_klic__comp__macro_xfindvars__elems_3 = {
  (unsigned char *)"findvars_elems",
  &predicate_klic__comp__macro_xfindvars__elems_3
};

extern Const struct predicate predicate_klic__comp__macro_xfindvars_3;
static Const struct predinfo predinfo_klic__comp__macro_xfindvars_3 = {
  (unsigned char *)"findvars",
  &predicate_klic__comp__macro_xfindvars_3
};

extern Const struct predicate predicate_klic__comp__macro_xfind__interface__vars__1_6;
static Const struct predinfo predinfo_klic__comp__macro_xfind__interface__vars__1_6 = {
  (unsigned char *)"find_interface_vars_1",
  &predicate_klic__comp__macro_xfind__interface__vars__1_6
};

extern Const struct predicate predicate_klic__comp__macro_xfind__interface__vars_3;
static Const struct predinfo predinfo_klic__comp__macro_xfind__interface__vars_3 = {
  (unsigned char *)"find_interface_vars",
  &predicate_klic__comp__macro_xfind__interface__vars_3
};

extern Const struct predicate predicate_klic__comp__macro_xfinalize__vars_4;
static Const struct predinfo predinfo_klic__comp__macro_xfinalize__vars_4 = {
  (unsigned char *)"finalize_vars",
  &predicate_klic__comp__macro_xfinalize__vars_4
};

extern Const struct predicate predicate_klic__comp__macro_xexpand__goal_3;
static Const struct predinfo predinfo_klic__comp__macro_xexpand__goal_3 = {
  (unsigned char *)"expand_goal",
  &predicate_klic__comp__macro_xexpand__goal_3
};

extern Const struct predicate predicate_klic__comp__macro_xexp__one__clause_4;
static Const struct predinfo predinfo_klic__comp__macro_xexp__one__clause_4 = {
  (unsigned char *)"exp_one_clause",
  &predicate_klic__comp__macro_xexp__one__clause_4
};

extern Const struct predicate predicate_klic__comp__macro_xexp__head__and__guard__top_6;
static Const struct predinfo predinfo_klic__comp__macro_xexp__head__and__guard__top_6 = {
  (unsigned char *)"exp_head_and_guard_top",
  &predicate_klic__comp__macro_xexp__head__and__guard__top_6
};

extern Const struct predicate predicate_klic__comp__macro_xexp__head_6;
static Const struct predinfo predinfo_klic__comp__macro_xexp__head_6 = {
  (unsigned char *)"exp_head",
  &predicate_klic__comp__macro_xexp__head_6
};

extern Const struct predicate predicate_klic__comp__macro_xexp__guard_5;
static Const struct predinfo predinfo_klic__comp__macro_xexp__guard_5 = {
  (unsigned char *)"exp_guard",
  &predicate_klic__comp__macro_xexp__guard_5
};

extern Const struct predicate predicate_klic__comp__macro_xexp__body__or_6;
static Const struct predinfo predinfo_klic__comp__macro_xexp__body__or_6 = {
  (unsigned char *)"exp_body_or",
  &predicate_klic__comp__macro_xexp__body__or_6
};

extern Const struct predicate predicate_klic__comp__macro_xexp__body_8;
static Const struct predinfo predinfo_klic__comp__macro_xexp__body_8 = {
  (unsigned char *)"exp_body",
  &predicate_klic__comp__macro_xexp__body_8
};

extern Const struct predicate predicate_klic__comp__macro_xdlor_8;
static Const struct predinfo predinfo_klic__comp__macro_xdlor_8 = {
  (unsigned char *)"dlor",
  &predicate_klic__comp__macro_xdlor_8
};

extern Const struct predicate predicate_klic__comp__macro_xdlgoals_7;
static Const struct predinfo predinfo_klic__comp__macro_xdlgoals_7 = {
  (unsigned char *)"dlgoals",
  &predicate_klic__comp__macro_xdlgoals_7
};

extern Const struct predicate predicate_klic__comp__macro_xdlgoal__atom_3;
static Const struct predinfo predinfo_klic__comp__macro_xdlgoal__atom_3 = {
  (unsigned char *)"dlgoal_atom",
  &predicate_klic__comp__macro_xdlgoal__atom_3
};

extern Const struct predicate predicate_klic__comp__macro_xdlgoal_7;
static Const struct predinfo predinfo_klic__comp__macro_xdlgoal_7 = {
  (unsigned char *)"dlgoal",
  &predicate_klic__comp__macro_xdlgoal_7
};

extern Const struct predicate predicate_klic__comp__macro_xdlclause__1_9;
static Const struct predinfo predinfo_klic__comp__macro_xdlclause__1_9 = {
  (unsigned char *)"dlclause_1",
  &predicate_klic__comp__macro_xdlclause__1_9
};

extern Const struct predicate predicate_klic__comp__macro_xdlclause_9;
static Const struct predinfo predinfo_klic__comp__macro_xdlclause_9 = {
  (unsigned char *)"dlclause",
  &predicate_klic__comp__macro_xdlclause_9
};

extern Const struct predicate predicate_klic__comp__macro_xdlappend__args_3;
static Const struct predinfo predinfo_klic__comp__macro_xdlappend__args_3 = {
  (unsigned char *)"dlappend_args",
  &predicate_klic__comp__macro_xdlappend__args_3
};

extern Const struct predicate predicate_klic__comp__macro_xdlappend__args_2F3_240_4;
static Const struct predinfo predinfo_klic__comp__macro_xdlappend__args_2F3_240_4 = {
  (unsigned char *)"dlappend_args/3$0",
  &predicate_klic__comp__macro_xdlappend__args_2F3_240_4
};

extern Const struct predicate predicate_klic__comp__macro_xdl__update_12;
static Const struct predinfo predinfo_klic__comp__macro_xdl__update_12 = {
  (unsigned char *)"dl_update",
  &predicate_klic__comp__macro_xdl__update_12
};

extern Const struct predicate predicate_klic__comp__macro_xdl__compute_9;
static Const struct predinfo predinfo_klic__comp__macro_xdl__compute_9 = {
  (unsigned char *)"dl_compute",
  &predicate_klic__comp__macro_xdl__compute_9
};

extern Const struct predicate predicate_klic__comp__macro_xdl__common_9;
static Const struct predinfo predinfo_klic__comp__macro_xdl__common_9 = {
  (unsigned char *)"dl_common",
  &predicate_klic__comp__macro_xdl__common_9
};

extern Const struct predicate predicate_klic__comp__macro_xcountvars_3;
static Const struct predinfo predinfo_klic__comp__macro_xcountvars_3 = {
  (unsigned char *)"countvars",
  &predicate_klic__comp__macro_xcountvars_3
};

extern Const struct predicate predicate_klic__comp__macro_xcountvars_2;
static Const struct predinfo predinfo_klic__comp__macro_xcountvars_2 = {
  (unsigned char *)"countvars",
  &predicate_klic__comp__macro_xcountvars_2
};

extern Const struct predicate predicate_klic__comp__macro_xcountsame_5;
static Const struct predinfo predinfo_klic__comp__macro_xcountsame_5 = {
  (unsigned char *)"countsame",
  &predicate_klic__comp__macro_xcountsame_5
};

extern Const struct predicate predicate_klic__comp__macro_xcompar__macro_2;
static Const struct predinfo predinfo_klic__comp__macro_xcompar__macro_2 = {
  (unsigned char *)"compar_macro",
  &predicate_klic__comp__macro_xcompar__macro_2
};

extern Const struct predicate predicate_klic__comp__macro_xbody__or__one_6;
static Const struct predinfo predinfo_klic__comp__macro_xbody__or__one_6 = {
  (unsigned char *)"body_or_one",
  &predicate_klic__comp__macro_xbody__or__one_6
};

extern Const struct predicate predicate_klic__comp__macro_xbody__or__clauses_6;
static Const struct predinfo predinfo_klic__comp__macro_xbody__or__clauses_6 = {
  (unsigned char *)"body_or_clauses",
  &predicate_klic__comp__macro_xbody__or__clauses_6
};

static Const struct predinfo * Const preds_in_klic__comp__macro[] = {
  &predinfo_klic__comp__macro_xupdate__info__1_9,
  &predinfo_klic__comp__macro_xupdate__info_6,
  &predinfo_klic__comp__macro_xreplace__vars__elems_3,
  &predinfo_klic__comp__macro_xreplace__vars__1_3,
  &predinfo_klic__comp__macro_xreplace__vars_3,
  &predinfo_klic__comp__macro_xmerge__vinfo_5,
  &predinfo_klic__comp__macro_xmake__expanded__call_2,
  &predinfo_klic__comp__macro_xmacro__vector__elems_10,
  &predinfo_klic__comp__macro_xmacro__vec__elems_8,
  &predinfo_klic__comp__macro_xmacro__goal__functor__cmp_9,
  &predinfo_klic__comp__macro_xmacro__goal__functor_8,
  &predinfo_klic__comp__macro_xmacro__goal_8,
  &predinfo_klic__comp__macro_xmacro__float__op_2,
  &predinfo_klic__comp__macro_xmacro__float__exp__1_7,
  &predinfo_klic__comp__macro_xmacro__float__exp_6,
  &predinfo_klic__comp__macro_xmacro__float__args_7,
  &predinfo_klic__comp__macro_xmacro__exp__args_7,
  &predinfo_klic__comp__macro_xmacro__exp__1_7,
  &predinfo_klic__comp__macro_xmacro__exp_6,
  &predinfo_klic__comp__macro_xmacro__arith__op_2,
  &predinfo_klic__comp__macro_xmacro__args_9,
  &predinfo_klic__comp__macro_xmacro__arg__n_8,
  &predinfo_klic__comp__macro_xmacro__arg__functor__sharp_10,
  &predinfo_klic__comp__macro_xmacro__arg__functor_9,
  &predinfo_klic__comp__macro_xmacro__arg_9,
  &predinfo_klic__comp__macro_xmacro__N__10_4,
  &predinfo_klic__comp__macro_xmacro__1_3,
  &predinfo_klic__comp__macro_xmacro_2,
  &predinfo_klic__comp__macro_xlinearize__guard_3,
  &predinfo_klic__comp__macro_xinitialize__info__1_10,
  &predinfo_klic__comp__macro_xinitialize__info_7,
  &predinfo_klic__comp__macro_xfindvars__elems_3,
  &predinfo_klic__comp__macro_xfindvars_3,
  &predinfo_klic__comp__macro_xfind__interface__vars__1_6,
  &predinfo_klic__comp__macro_xfind__interface__vars_3,
  &predinfo_klic__comp__macro_xfinalize__vars_4,
  &predinfo_klic__comp__macro_xexpand__goal_3,
  &predinfo_klic__comp__macro_xexp__one__clause_4,
  &predinfo_klic__comp__macro_xexp__head__and__guard__top_6,
  &predinfo_klic__comp__macro_xexp__head_6,
  &predinfo_klic__comp__macro_xexp__guard_5,
  &predinfo_klic__comp__macro_xexp__body__or_6,
  &predinfo_klic__comp__macro_xexp__body_8,
  &predinfo_klic__comp__macro_xdlor_8,
  &predinfo_klic__comp__macro_xdlgoals_7,
  &predinfo_klic__comp__macro_xdlgoal__atom_3,
  &predinfo_klic__comp__macro_xdlgoal_7,
  &predinfo_klic__comp__macro_xdlclause__1_9,
  &predinfo_klic__comp__macro_xdlclause_9,
  &predinfo_klic__comp__macro_xdlappend__args_3,
  &predinfo_klic__comp__macro_xdlappend__args_2F3_240_4,
  &predinfo_klic__comp__macro_xdl__update_12,
  &predinfo_klic__comp__macro_xdl__compute_9,
  &predinfo_klic__comp__macro_xdl__common_9,
  &predinfo_klic__comp__macro_xcountvars_3,
  &predinfo_klic__comp__macro_xcountvars_2,
  &predinfo_klic__comp__macro_xcountsame_5,
  &predinfo_klic__comp__macro_xcompar__macro_2,
  &predinfo_klic__comp__macro_xbody__or__one_6,
  &predinfo_klic__comp__macro_xbody__or__clauses_6,
  0
};
extern Const struct predicate predicate_direct__call_xremove__no__go__clauses_3;
static Const struct predinfo predinfo_direct__call_xremove__no__go__clauses_3 = {
  (unsigned char *)"remove_no_go_clauses",
  &predicate_direct__call_xremove__no__go__clauses_3
};

extern Const struct predicate predicate_direct__call_xremove__no__go__clause_2;
static Const struct predinfo predinfo_direct__call_xremove__no__go__clause_2 = {
  (unsigned char *)"remove_no_go_clause",
  &predicate_direct__call_xremove__no__go__clause_2
};

extern Const struct predicate predicate_direct__call_xremove__no__go__bodys_6;
static Const struct predinfo predinfo_direct__call_xremove__no__go__bodys_6 = {
  (unsigned char *)"remove_no_go_bodys",
  &predicate_direct__call_xremove__no__go__bodys_6
};

extern Const struct predicate predicate_direct__call_xremove__no__go_2;
static Const struct predinfo predinfo_direct__call_xremove__no__go_2 = {
  (unsigned char *)"remove_no_go",
  &predicate_direct__call_xremove__no__go_2
};

extern Const struct predicate predicate_direct__call_xrecursive__bodys_6;
static Const struct predinfo predinfo_direct__call_xrecursive__bodys_6 = {
  (unsigned char *)"recursive_bodys",
  &predicate_direct__call_xrecursive__bodys_6
};

extern Const struct predicate predicate_direct__call_xrecursive__bodys1_6;
static Const struct predinfo predinfo_direct__call_xrecursive__bodys1_6 = {
  (unsigned char *)"recursive_bodys1",
  &predicate_direct__call_xrecursive__bodys1_6
};

extern Const struct predicate predicate_direct__call_xrecursive__body_9;
static Const struct predinfo predinfo_direct__call_xrecursive__body_9 = {
  (unsigned char *)"recursive_body",
  &predicate_direct__call_xrecursive__body_9
};

extern Const struct predicate predicate_direct__call_xmake__nextgoal_8;
static Const struct predinfo predinfo_direct__call_xmake__nextgoal_8 = {
  (unsigned char *)"make_nextgoal",
  &predicate_direct__call_xmake__nextgoal_8
};

extern Const struct predicate predicate_direct__call_xmain_2;
static Const struct predinfo predinfo_direct__call_xmain_2 = {
  (unsigned char *)"main",
  &predicate_direct__call_xmain_2
};

extern Const struct predicate predicate_direct__call_xcheck__clauses_5;
static Const struct predinfo predinfo_direct__call_xcheck__clauses_5 = {
  (unsigned char *)"check_clauses",
  &predicate_direct__call_xcheck__clauses_5
};

extern Const struct predicate predicate_direct__call_xcheck__call_6;
static Const struct predinfo predinfo_direct__call_xcheck__call_6 = {
  (unsigned char *)"check_call",
  &predicate_direct__call_xcheck__call_6
};

extern Const struct predicate predicate_direct__call_xcheck__builtin_4;
static Const struct predinfo predinfo_direct__call_xcheck__builtin_4 = {
  (unsigned char *)"check_builtin",
  &predicate_direct__call_xcheck__builtin_4
};

extern Const struct predicate predicate_direct__call_xcheck__builtin1_6;
static Const struct predinfo predinfo_direct__call_xcheck__builtin1_6 = {
  (unsigned char *)"check_builtin1",
  &predicate_direct__call_xcheck__builtin1_6
};

extern Const struct predicate predicate_direct__call_xadd__go_6;
static Const struct predinfo predinfo_direct__call_xadd__go_6 = {
  (unsigned char *)"add_go",
  &predicate_direct__call_xadd__go_6
};

extern Const struct predicate predicate_direct__call_xadd__go1_8;
static Const struct predinfo predinfo_direct__call_xadd__go1_8 = {
  (unsigned char *)"add_go1",
  &predicate_direct__call_xadd__go1_8
};

static Const struct predinfo * Const preds_in_direct__call[] = {
  &predinfo_direct__call_xremove__no__go__clauses_3,
  &predinfo_direct__call_xremove__no__go__clause_2,
  &predinfo_direct__call_xremove__no__go__bodys_6,
  &predinfo_direct__call_xremove__no__go_2,
  &predinfo_direct__call_xrecursive__bodys_6,
  &predinfo_direct__call_xrecursive__bodys1_6,
  &predinfo_direct__call_xrecursive__body_9,
  &predinfo_direct__call_xmake__nextgoal_8,
  &predinfo_direct__call_xmain_2,
  &predinfo_direct__call_xcheck__clauses_5,
  &predinfo_direct__call_xcheck__call_6,
  &predinfo_direct__call_xcheck__builtin_4,
  &predinfo_direct__call_xcheck__builtin1_6,
  &predinfo_direct__call_xadd__go_6,
  &predinfo_direct__call_xadd__go1_8,
  0
};
extern Const struct predicate predicate_schedule_xsplit__goals_4;
static Const struct predinfo predinfo_schedule_xsplit__goals_4 = {
  (unsigned char *)"split_goals",
  &predicate_schedule_xsplit__goals_4
};

extern Const struct predicate predicate_schedule_xsort__numset__size_2;
static Const struct predinfo predinfo_schedule_xsort__numset__size_2 = {
  (unsigned char *)"sort_numset_size",
  &predicate_schedule_xsort__numset__size_2
};

extern Const struct predicate predicate_schedule_xsort__numset__size2_7;
static Const struct predinfo predinfo_schedule_xsort__numset__size2_7 = {
  (unsigned char *)"sort_numset_size2",
  &predicate_schedule_xsort__numset__size2_7
};

extern Const struct predicate predicate_schedule_xsort__numset__size1_5;
static Const struct predinfo predinfo_schedule_xsort__numset__size1_5 = {
  (unsigned char *)"sort_numset_size1",
  &predicate_schedule_xsort__numset__size1_5
};

extern Const struct predicate predicate_schedule_xschedule__predicate_8;
static Const struct predinfo predinfo_schedule_xschedule__predicate_8 = {
  (unsigned char *)"schedule_predicate",
  &predicate_schedule_xschedule__predicate_8
};

extern Const struct predicate predicate_schedule_xschedule__def__clauses_9;
static Const struct predinfo predinfo_schedule_xschedule__def__clauses_9 = {
  (unsigned char *)"schedule_def_clauses",
  &predicate_schedule_xschedule__def__clauses_9
};

extern Const struct predicate predicate_schedule_xschedule__clause_9;
static Const struct predinfo predinfo_schedule_xschedule__clause_9 = {
  (unsigned char *)"schedule_clause",
  &predicate_schedule_xschedule__clause_9
};

extern Const struct predicate predicate_schedule_xschedule__bodys_5;
static Const struct predinfo predinfo_schedule_xschedule__bodys_5 = {
  (unsigned char *)"schedule_bodys",
  &predicate_schedule_xschedule__bodys_5
};

extern Const struct predicate predicate_schedule_xmake__order__insert__entry_5;
static Const struct predinfo predinfo_schedule_xmake__order__insert__entry_5 = {
  (unsigned char *)"make_order_insert_entry",
  &predicate_schedule_xmake__order__insert__entry_5
};

extern Const struct predicate predicate_schedule_xmake__order__insert__entry1_8;
static Const struct predinfo predinfo_schedule_xmake__order__insert__entry1_8 = {
  (unsigned char *)"make_order_insert_entry1",
  &predicate_schedule_xmake__order__insert__entry1_8
};

extern Const struct predicate predicate_schedule_xmake__order__entry__depsets_3;
static Const struct predinfo predinfo_schedule_xmake__order__entry__depsets_3 = {
  (unsigned char *)"make_order_entry_depsets",
  &predicate_schedule_xmake__order__entry__depsets_3
};

extern Const struct predicate predicate_schedule_xmake__order__entry__depsets1_4;
static Const struct predinfo predinfo_schedule_xmake__order__entry__depsets1_4 = {
  (unsigned char *)"make_order_entry_depsets1",
  &predicate_schedule_xmake__order__entry__depsets1_4
};

extern Const struct predicate predicate_schedule_xmake__order__entry__depset_4;
static Const struct predinfo predinfo_schedule_xmake__order__entry__depset_4 = {
  (unsigned char *)"make_order_entry_depset",
  &predicate_schedule_xmake__order__entry__depset_4
};

extern Const struct predicate predicate_schedule_xmake__order__entry__depset1_6;
static Const struct predinfo predinfo_schedule_xmake__order__entry__depset1_6 = {
  (unsigned char *)"make_order_entry_depset1",
  &predicate_schedule_xmake__order__entry__depset1_6
};

extern Const struct predicate predicate_schedule_xmake__order_2;
static Const struct predinfo predinfo_schedule_xmake__order_2 = {
  (unsigned char *)"make_order",
  &predicate_schedule_xmake__order_2
};

extern Const struct predicate predicate_schedule_xmake__order1_3;
static Const struct predinfo predinfo_schedule_xmake__order1_3 = {
  (unsigned char *)"make_order1",
  &predicate_schedule_xmake__order1_3
};

extern Const struct predicate predicate_schedule_xmake__deps__gk_3;
static Const struct predinfo predinfo_schedule_xmake__deps__gk_3 = {
  (unsigned char *)"make_deps_gk",
  &predicate_schedule_xmake__deps__gk_3
};

extern Const struct predicate predicate_schedule_xmake__deps_7;
static Const struct predinfo predinfo_schedule_xmake__deps_7 = {
  (unsigned char *)"make_deps",
  &predicate_schedule_xmake__deps_7
};

extern Const struct predicate predicate_schedule_xmake__brother__deps_5;
static Const struct predinfo predinfo_schedule_xmake__brother__deps_5 = {
  (unsigned char *)"make_brother_deps",
  &predicate_schedule_xmake__brother__deps_5
};

extern Const struct predicate predicate_schedule_xmain_3;
static Const struct predinfo predinfo_schedule_xmain_3 = {
  (unsigned char *)"main",
  &predicate_schedule_xmain_3
};

extern Const struct predicate predicate_schedule_xget__pos__dep__to__entry_3;
static Const struct predinfo predinfo_schedule_xget__pos__dep__to__entry_3 = {
  (unsigned char *)"get_pos_dep_to_entry",
  &predicate_schedule_xget__pos__dep__to__entry_3
};

extern Const struct predicate predicate_schedule_xget__pos__dep__to__entry2_5;
static Const struct predinfo predinfo_schedule_xget__pos__dep__to__entry2_5 = {
  (unsigned char *)"get_pos_dep_to_entry2",
  &predicate_schedule_xget__pos__dep__to__entry2_5
};

extern Const struct predicate predicate_schedule_xget__pos__dep__to__entry1_4;
static Const struct predinfo predinfo_schedule_xget__pos__dep__to__entry1_4 = {
  (unsigned char *)"get_pos_dep_to_entry1",
  &predicate_schedule_xget__pos__dep__to__entry1_4
};

extern Const struct predicate predicate_schedule_xget__pos__dep__from__entry_3;
static Const struct predinfo predinfo_schedule_xget__pos__dep__from__entry_3 = {
  (unsigned char *)"get_pos_dep_from_entry",
  &predicate_schedule_xget__pos__dep__from__entry_3
};

extern Const struct predicate predicate_schedule_xget__pos__dep__from__entry2_5;
static Const struct predinfo predinfo_schedule_xget__pos__dep__from__entry2_5 = {
  (unsigned char *)"get_pos_dep_from_entry2",
  &predicate_schedule_xget__pos__dep__from__entry2_5
};

extern Const struct predicate predicate_schedule_xget__pos__dep__from__entry1_4;
static Const struct predinfo predinfo_schedule_xget__pos__dep__from__entry1_4 = {
  (unsigned char *)"get_pos_dep_from_entry1",
  &predicate_schedule_xget__pos__dep__from__entry1_4
};

extern Const struct predicate predicate_schedule_xget__depset__pos_3;
static Const struct predinfo predinfo_schedule_xget__depset__pos_3 = {
  (unsigned char *)"get_depset_pos",
  &predicate_schedule_xget__depset__pos_3
};

extern Const struct predicate predicate_schedule_xget__depset__pos1_4;
static Const struct predinfo predinfo_schedule_xget__depset__pos1_4 = {
  (unsigned char *)"get_depset_pos1",
  &predicate_schedule_xget__depset__pos1_4
};

extern Const struct predicate predicate_schedule_xdepsets2numsets_2;
static Const struct predinfo predinfo_schedule_xdepsets2numsets_2 = {
  (unsigned char *)"depsets2numsets",
  &predicate_schedule_xdepsets2numsets_2
};

extern Const struct predicate predicate_schedule_xdepset2numset_2;
static Const struct predinfo predinfo_schedule_xdepset2numset_2 = {
  (unsigned char *)"depset2numset",
  &predicate_schedule_xdepset2numset_2
};

extern Const struct predicate predicate_schedule_xchange__order_3;
static Const struct predinfo predinfo_schedule_xchange__order_3 = {
  (unsigned char *)"change_order",
  &predicate_schedule_xchange__order_3
};

extern Const struct predicate predicate_schedule_xchange__order2_7;
static Const struct predinfo predinfo_schedule_xchange__order2_7 = {
  (unsigned char *)"change_order2",
  &predicate_schedule_xchange__order2_7
};

extern Const struct predicate predicate_schedule_xchange__order1_6;
static Const struct predinfo predinfo_schedule_xchange__order1_6 = {
  (unsigned char *)"change_order1",
  &predicate_schedule_xchange__order1_6
};

extern Const struct predicate predicate_schedule_xapply__schedule__bodys_8;
static Const struct predinfo predinfo_schedule_xapply__schedule__bodys_8 = {
  (unsigned char *)"apply_schedule_bodys",
  &predicate_schedule_xapply__schedule__bodys_8
};

extern Const struct predicate predicate_schedule_xapply__schedule__body_14;
static Const struct predinfo predinfo_schedule_xapply__schedule__body_14 = {
  (unsigned char *)"apply_schedule_body",
  &predicate_schedule_xapply__schedule__body_14
};

extern Const struct predicate predicate_schedule_xappend__nodegoal_3;
static Const struct predinfo predinfo_schedule_xappend__nodegoal_3 = {
  (unsigned char *)"append_nodegoal",
  &predicate_schedule_xappend__nodegoal_3
};

extern Const struct predicate predicate_schedule_xadd__thread_4;
static Const struct predinfo predinfo_schedule_xadd__thread_4 = {
  (unsigned char *)"add_thread",
  &predicate_schedule_xadd__thread_4
};

static Const struct predinfo * Const preds_in_schedule[] = {
  &predinfo_schedule_xsplit__goals_4,
  &predinfo_schedule_xsort__numset__size_2,
  &predinfo_schedule_xsort__numset__size2_7,
  &predinfo_schedule_xsort__numset__size1_5,
  &predinfo_schedule_xschedule__predicate_8,
  &predinfo_schedule_xschedule__def__clauses_9,
  &predinfo_schedule_xschedule__clause_9,
  &predinfo_schedule_xschedule__bodys_5,
  &predinfo_schedule_xmake__order__insert__entry_5,
  &predinfo_schedule_xmake__order__insert__entry1_8,
  &predinfo_schedule_xmake__order__entry__depsets_3,
  &predinfo_schedule_xmake__order__entry__depsets1_4,
  &predinfo_schedule_xmake__order__entry__depset_4,
  &predinfo_schedule_xmake__order__entry__depset1_6,
  &predinfo_schedule_xmake__order_2,
  &predinfo_schedule_xmake__order1_3,
  &predinfo_schedule_xmake__deps__gk_3,
  &predinfo_schedule_xmake__deps_7,
  &predinfo_schedule_xmake__brother__deps_5,
  &predinfo_schedule_xmain_3,
  &predinfo_schedule_xget__pos__dep__to__entry_3,
  &predinfo_schedule_xget__pos__dep__to__entry2_5,
  &predinfo_schedule_xget__pos__dep__to__entry1_4,
  &predinfo_schedule_xget__pos__dep__from__entry_3,
  &predinfo_schedule_xget__pos__dep__from__entry2_5,
  &predinfo_schedule_xget__pos__dep__from__entry1_4,
  &predinfo_schedule_xget__depset__pos_3,
  &predinfo_schedule_xget__depset__pos1_4,
  &predinfo_schedule_xdepsets2numsets_2,
  &predinfo_schedule_xdepset2numset_2,
  &predinfo_schedule_xchange__order_3,
  &predinfo_schedule_xchange__order2_7,
  &predinfo_schedule_xchange__order1_6,
  &predinfo_schedule_xapply__schedule__bodys_8,
  &predinfo_schedule_xapply__schedule__body_14,
  &predinfo_schedule_xappend__nodegoal_3,
  &predinfo_schedule_xadd__thread_4,
  0
};
extern Const struct predicate predicate_analyze__type_xset__head__body__types_21;
static Const struct predinfo predinfo_analyze__type_xset__head__body__types_21 = {
  (unsigned char *)"set_head_body_types",
  &predicate_analyze__type_xset__head__body__types_21
};

extern Const struct predicate predicate_analyze__type_xset__goals__types_20;
static Const struct predinfo predinfo_analyze__type_xset__goals__types_20 = {
  (unsigned char *)"set_goals_types",
  &predicate_analyze__type_xset__goals__types_20
};

extern Const struct predicate predicate_analyze__type_xset__goals__types1_21;
static Const struct predinfo predinfo_analyze__type_xset__goals__types1_21 = {
  (unsigned char *)"set_goals_types1",
  &predicate_analyze__type_xset__goals__types1_21
};

extern Const struct predicate predicate_analyze__type_xset__goals__mode_11;
static Const struct predinfo predinfo_analyze__type_xset__goals__mode_11 = {
  (unsigned char *)"set_goals_mode",
  &predicate_analyze__type_xset__goals__mode_11
};

extern Const struct predicate predicate_analyze__type_xset__goals__mode1_12;
static Const struct predinfo predinfo_analyze__type_xset__goals__mode1_12 = {
  (unsigned char *)"set_goals_mode1",
  &predicate_analyze__type_xset__goals__mode1_12
};

extern Const struct predicate predicate_analyze__type_xset__goal__types_21;
static Const struct predinfo predinfo_analyze__type_xset__goal__types_21 = {
  (unsigned char *)"set_goal_types",
  &predicate_analyze__type_xset__goal__types_21
};

extern Const struct predicate predicate_analyze__type_xset__goal__types1_23;
static Const struct predinfo predinfo_analyze__type_xset__goal__types1_23 = {
  (unsigned char *)"set_goal_types1",
  &predicate_analyze__type_xset__goal__types1_23
};

extern Const struct predicate predicate_analyze__type_xset__goal__mode_11;
static Const struct predinfo predinfo_analyze__type_xset__goal__mode_11 = {
  (unsigned char *)"set_goal_mode",
  &predicate_analyze__type_xset__goal__mode_11
};

extern Const struct predicate predicate_analyze__type_xset__goal__mode1_11;
static Const struct predinfo predinfo_analyze__type_xset__goal__mode1_11 = {
  (unsigned char *)"set_goal_mode1",
  &predicate_analyze__type_xset__goal__mode1_11
};

extern Const struct predicate predicate_analyze__type_xset__arg__types_13;
static Const struct predinfo predinfo_analyze__type_xset__arg__types_13 = {
  (unsigned char *)"set_arg_types",
  &predicate_analyze__type_xset__arg__types_13
};

extern Const struct predicate predicate_analyze__type_xremove__redundant__indirect_2;
static Const struct predinfo predinfo_analyze__type_xremove__redundant__indirect_2 = {
  (unsigned char *)"remove_redundant_indirect",
  &predicate_analyze__type_xremove__redundant__indirect_2
};

extern Const struct predicate predicate_analyze__type_xremove__redundant__indirect1_3;
static Const struct predinfo predinfo_analyze__type_xremove__redundant__indirect1_3 = {
  (unsigned char *)"remove_redundant_indirect1",
  &predicate_analyze__type_xremove__redundant__indirect1_3
};

extern Const struct predicate predicate_analyze__type_xremove__redandant__indirect__updown_5;
static Const struct predinfo predinfo_analyze__type_xremove__redandant__indirect__updown_5 = {
  (unsigned char *)"remove_redandant_indirect_updown",
  &predicate_analyze__type_xremove__redandant__indirect__updown_5
};

extern Const struct predicate predicate_analyze__type_xremove__redandant__indirect__unify_3;
static Const struct predinfo predinfo_analyze__type_xremove__redandant__indirect__unify_3 = {
  (unsigned char *)"remove_redandant_indirect_unify",
  &predicate_analyze__type_xremove__redandant__indirect__unify_3
};

extern Const struct predicate predicate_analyze__type_xremove__redandant__indirect__unify1_3;
static Const struct predinfo predinfo_analyze__type_xremove__redandant__indirect__unify1_3 = {
  (unsigned char *)"remove_redandant_indirect_unify1",
  &predicate_analyze__type_xremove__redandant__indirect__unify1_3
};

extern Const struct predicate predicate_analyze__type_xremove__redandant__indirect2_4;
static Const struct predinfo predinfo_analyze__type_xremove__redandant__indirect2_4 = {
  (unsigned char *)"remove_redandant_indirect2",
  &predicate_analyze__type_xremove__redandant__indirect2_4
};

extern Const struct predicate predicate_analyze__type_xmake__arg__types_13;
static Const struct predinfo predinfo_analyze__type_xmake__arg__types_13 = {
  (unsigned char *)"make_arg_types",
  &predicate_analyze__type_xmake__arg__types_13
};

extern Const struct predicate predicate_analyze__type_xmain_12;
static Const struct predinfo predinfo_analyze__type_xmain_12 = {
  (unsigned char *)"main",
  &predicate_analyze__type_xmain_12
};

extern Const struct predicate predicate_analyze__type_xmain1_13;
static Const struct predinfo predinfo_analyze__type_xmain1_13 = {
  (unsigned char *)"main1",
  &predicate_analyze__type_xmain1_13
};

extern Const struct predicate predicate_analyze__type_xinterclause__modules_19;
static Const struct predinfo predinfo_analyze__type_xinterclause__modules_19 = {
  (unsigned char *)"interclause_modules",
  &predicate_analyze__type_xinterclause__modules_19
};

extern Const struct predicate predicate_analyze__type_xinterclause__clauses_22;
static Const struct predinfo predinfo_analyze__type_xinterclause__clauses_22 = {
  (unsigned char *)"interclause_clauses",
  &predicate_analyze__type_xinterclause__clauses_22
};

extern Const struct predicate predicate_analyze__type_xinterclause__clause_22;
static Const struct predinfo predinfo_analyze__type_xinterclause__clause_22 = {
  (unsigned char *)"interclause_clause",
  &predicate_analyze__type_xinterclause__clause_22
};

extern Const struct predicate predicate_analyze__type_xindirect__mode__modules_8;
static Const struct predinfo predinfo_analyze__type_xindirect__mode__modules_8 = {
  (unsigned char *)"indirect_mode_modules",
  &predicate_analyze__type_xindirect__mode__modules_8
};

extern Const struct predicate predicate_analyze__type_xindirect__mode__goals_6;
static Const struct predinfo predinfo_analyze__type_xindirect__mode__goals_6 = {
  (unsigned char *)"indirect_mode_goals",
  &predicate_analyze__type_xindirect__mode__goals_6
};

extern Const struct predicate predicate_analyze__type_xindirect__mode__goals1_7;
static Const struct predinfo predinfo_analyze__type_xindirect__mode__goals1_7 = {
  (unsigned char *)"indirect_mode_goals1",
  &predicate_analyze__type_xindirect__mode__goals1_7
};

extern Const struct predicate predicate_analyze__type_xindirect__mode__goal_6;
static Const struct predinfo predinfo_analyze__type_xindirect__mode__goal_6 = {
  (unsigned char *)"indirect_mode_goal",
  &predicate_analyze__type_xindirect__mode__goal_6
};

extern Const struct predicate predicate_analyze__type_xindirect__mode__expansion__alias_6;
static Const struct predinfo predinfo_analyze__type_xindirect__mode__expansion__alias_6 = {
  (unsigned char *)"indirect_mode_expansion_alias",
  &predicate_analyze__type_xindirect__mode__expansion__alias_6
};

extern Const struct predicate predicate_analyze__type_xindirect__mode__expansion_17;
static Const struct predinfo predinfo_analyze__type_xindirect__mode__expansion_17 = {
  (unsigned char *)"indirect_mode_expansion",
  &predicate_analyze__type_xindirect__mode__expansion_17
};

extern Const struct predicate predicate_analyze__type_xindirect__mode__expansion2_14;
static Const struct predinfo predinfo_analyze__type_xindirect__mode__expansion2_14 = {
  (unsigned char *)"indirect_mode_expansion2",
  &predicate_analyze__type_xindirect__mode__expansion2_14
};

extern Const struct predicate predicate_analyze__type_xindirect__mode__expansion1_19;
static Const struct predinfo predinfo_analyze__type_xindirect__mode__expansion1_19 = {
  (unsigned char *)"indirect_mode_expansion1",
  &predicate_analyze__type_xindirect__mode__expansion1_19
};

extern Const struct predicate predicate_analyze__type_xindirect__mode__expansion11_20;
static Const struct predinfo predinfo_analyze__type_xindirect__mode__expansion11_20 = {
  (unsigned char *)"indirect_mode_expansion11",
  &predicate_analyze__type_xindirect__mode__expansion11_20
};

extern Const struct predicate predicate_analyze__type_xindirect__mode__clause_4;
static Const struct predinfo predinfo_analyze__type_xindirect__mode__clause_4 = {
  (unsigned char *)"indirect_mode_clause",
  &predicate_analyze__type_xindirect__mode__clause_4
};

extern Const struct predicate predicate_analyze__type_xindirect__mode__arg_7;
static Const struct predinfo predinfo_analyze__type_xindirect__mode__arg_7 = {
  (unsigned char *)"indirect_mode_arg",
  &predicate_analyze__type_xindirect__mode__arg_7
};

extern Const struct predicate predicate_analyze__type_xindirect__mode__arg1_6;
static Const struct predinfo predinfo_analyze__type_xindirect__mode__arg1_6 = {
  (unsigned char *)"indirect_mode_arg1",
  &predicate_analyze__type_xindirect__mode__arg1_6
};

extern Const struct predicate predicate_analyze__type_xget__call__modulename_3;
static Const struct predinfo predinfo_analyze__type_xget__call__modulename_3 = {
  (unsigned char *)"get_call_modulename",
  &predicate_analyze__type_xget__call__modulename_3
};

extern Const struct predicate predicate_analyze__type_xget__arg__types_6;
static Const struct predinfo predinfo_analyze__type_xget__arg__types_6 = {
  (unsigned char *)"get_arg_types",
  &predicate_analyze__type_xget__arg__types_6
};

extern Const struct predicate predicate_analyze__type_xexpand__ru__indirect__updown_8;
static Const struct predinfo predinfo_analyze__type_xexpand__ru__indirect__updown_8 = {
  (unsigned char *)"expand_ru_indirect_updown",
  &predicate_analyze__type_xexpand__ru__indirect__updown_8
};

extern Const struct predicate predicate_analyze__type_xexpand__ru__indirect__updown2_6;
static Const struct predinfo predinfo_analyze__type_xexpand__ru__indirect__updown2_6 = {
  (unsigned char *)"expand_ru_indirect_updown2",
  &predicate_analyze__type_xexpand__ru__indirect__updown2_6
};

extern Const struct predicate predicate_analyze__type_xexpand__ru__indirect__updown1_9;
static Const struct predinfo predinfo_analyze__type_xexpand__ru__indirect__updown1_9 = {
  (unsigned char *)"expand_ru_indirect_updown1",
  &predicate_analyze__type_xexpand__ru__indirect__updown1_9
};

extern Const struct predicate predicate_analyze__type_xexpand__ru__indirect__unify_8;
static Const struct predinfo predinfo_analyze__type_xexpand__ru__indirect__unify_8 = {
  (unsigned char *)"expand_ru_indirect_unify",
  &predicate_analyze__type_xexpand__ru__indirect__unify_8
};

extern Const struct predicate predicate_analyze__type_xexpand__ru__indirect__unify2_6;
static Const struct predinfo predinfo_analyze__type_xexpand__ru__indirect__unify2_6 = {
  (unsigned char *)"expand_ru_indirect_unify2",
  &predicate_analyze__type_xexpand__ru__indirect__unify2_6
};

extern Const struct predicate predicate_analyze__type_xexpand__ru__indirect__unify1_9;
static Const struct predinfo predinfo_analyze__type_xexpand__ru__indirect__unify1_9 = {
  (unsigned char *)"expand_ru_indirect_unify1",
  &predicate_analyze__type_xexpand__ru__indirect__unify1_9
};

extern Const struct predicate predicate_analyze__type_xexpand__ru__indirect_4;
static Const struct predinfo predinfo_analyze__type_xexpand__ru__indirect_4 = {
  (unsigned char *)"expand_ru_indirect",
  &predicate_analyze__type_xexpand__ru__indirect_4
};

extern Const struct predicate predicate_analyze__type_xexpand__ru__indirect1_5;
static Const struct predinfo predinfo_analyze__type_xexpand__ru__indirect1_5 = {
  (unsigned char *)"expand_ru_indirect1",
  &predicate_analyze__type_xexpand__ru__indirect1_5
};

extern Const struct predicate predicate_analyze__type_xcheck__waits_3;
static Const struct predinfo predinfo_analyze__type_xcheck__waits_3 = {
  (unsigned char *)"check_waits",
  &predicate_analyze__type_xcheck__waits_3
};

extern Const struct predicate predicate_analyze__type_xbuiltin__type__userdef_10;
static Const struct predinfo predinfo_analyze__type_xbuiltin__type__userdef_10 = {
  (unsigned char *)"builtin_type_userdef",
  &predicate_analyze__type_xbuiltin__type__userdef_10
};

extern Const struct predicate predicate_analyze__type_xbuiltin__type__userdef1_11;
static Const struct predinfo predinfo_analyze__type_xbuiltin__type__userdef1_11 = {
  (unsigned char *)"builtin_type_userdef1",
  &predicate_analyze__type_xbuiltin__type__userdef1_11
};

extern Const struct predicate predicate_analyze__type_xbuiltin__type__unify_18;
static Const struct predinfo predinfo_analyze__type_xbuiltin__type__unify_18 = {
  (unsigned char *)"builtin_type_unify",
  &predicate_analyze__type_xbuiltin__type__unify_18
};

extern Const struct predicate predicate_analyze__type_xbuiltin__type_21;
static Const struct predinfo predinfo_analyze__type_xbuiltin__type_21 = {
  (unsigned char *)"builtin_type",
  &predicate_analyze__type_xbuiltin__type_21
};

extern Const struct predicate predicate_analyze__type_xapply__type__goals_16;
static Const struct predinfo predinfo_analyze__type_xapply__type__goals_16 = {
  (unsigned char *)"apply_type_goals",
  &predicate_analyze__type_xapply__type__goals_16
};

extern Const struct predicate predicate_analyze__type_xapply__type__goals1_17;
static Const struct predinfo predinfo_analyze__type_xapply__type__goals1_17 = {
  (unsigned char *)"apply_type_goals1",
  &predicate_analyze__type_xapply__type__goals1_17
};

extern Const struct predicate predicate_analyze__type_xapply__type__goal_17;
static Const struct predinfo predinfo_analyze__type_xapply__type__goal_17 = {
  (unsigned char *)"apply_type_goal",
  &predicate_analyze__type_xapply__type__goal_17
};

extern Const struct predicate predicate_analyze__type_xapply__type__goal2_20;
static Const struct predinfo predinfo_analyze__type_xapply__type__goal2_20 = {
  (unsigned char *)"apply_type_goal2",
  &predicate_analyze__type_xapply__type__goal2_20
};

extern Const struct predicate predicate_analyze__type_xapply__type__goal1_19;
static Const struct predinfo predinfo_analyze__type_xapply__type__goal1_19 = {
  (unsigned char *)"apply_type_goal1",
  &predicate_analyze__type_xapply__type__goal1_19
};

extern Const struct predicate predicate_analyze__type_xapply__new__indirect_13;
static Const struct predinfo predinfo_analyze__type_xapply__new__indirect_13 = {
  (unsigned char *)"apply_new_indirect",
  &predicate_analyze__type_xapply__new__indirect_13
};

extern Const struct predicate predicate_analyze__type_xapply__new__indirect1__alias_28;
static Const struct predinfo predinfo_analyze__type_xapply__new__indirect1__alias_28 = {
  (unsigned char *)"apply_new_indirect1_alias",
  &predicate_analyze__type_xapply__new__indirect1__alias_28
};

extern Const struct predicate predicate_analyze__type_xapply__new__indirect1_18;
static Const struct predinfo predinfo_analyze__type_xapply__new__indirect1_18 = {
  (unsigned char *)"apply_new_indirect1",
  &predicate_analyze__type_xapply__new__indirect1_18
};

extern Const struct predicate predicate_analyze__type_xapply__indirect_16;
static Const struct predinfo predinfo_analyze__type_xapply__indirect_16 = {
  (unsigned char *)"apply_indirect",
  &predicate_analyze__type_xapply__indirect_16
};

extern Const struct predicate predicate_analyze__type_xapply__indirect2__alias_31;
static Const struct predinfo predinfo_analyze__type_xapply__indirect2__alias_31 = {
  (unsigned char *)"apply_indirect2_alias",
  &predicate_analyze__type_xapply__indirect2__alias_31
};

extern Const struct predicate predicate_analyze__type_xapply__indirect2_26;
static Const struct predinfo predinfo_analyze__type_xapply__indirect2_26 = {
  (unsigned char *)"apply_indirect2",
  &predicate_analyze__type_xapply__indirect2_26
};

extern Const struct predicate predicate_analyze__type_xapply__indirect1_19;
static Const struct predinfo predinfo_analyze__type_xapply__indirect1_19 = {
  (unsigned char *)"apply_indirect1",
  &predicate_analyze__type_xapply__indirect1_19
};

extern Const struct predicate predicate_analyze__type_xanalyze__type__modules_12;
static Const struct predinfo predinfo_analyze__type_xanalyze__type__modules_12 = {
  (unsigned char *)"analyze_type_modules",
  &predicate_analyze__type_xanalyze__type__modules_12
};

extern Const struct predicate predicate_analyze__type_xanalyze__type__modules_11;
static Const struct predinfo predinfo_analyze__type_xanalyze__type__modules_11 = {
  (unsigned char *)"analyze_type_modules",
  &predicate_analyze__type_xanalyze__type__modules_11
};

extern Const struct predicate predicate_analyze__type_xanalyze__type__clause_13;
static Const struct predinfo predinfo_analyze__type_xanalyze__type__clause_13 = {
  (unsigned char *)"analyze_type_clause",
  &predicate_analyze__type_xanalyze__type__clause_13
};

extern Const struct predicate predicate_analyze__type_xadd__indirect__deps__alias_15;
static Const struct predinfo predinfo_analyze__type_xadd__indirect__deps__alias_15 = {
  (unsigned char *)"add_indirect_deps_alias",
  &predicate_analyze__type_xadd__indirect__deps__alias_15
};

extern Const struct predicate predicate_analyze__type_xadd__dep__goal_8;
static Const struct predinfo predinfo_analyze__type_xadd__dep__goal_8 = {
  (unsigned char *)"add_dep_goal",
  &predicate_analyze__type_xadd__dep__goal_8
};

static Const struct predinfo * Const preds_in_analyze__type[] = {
  &predinfo_analyze__type_xset__head__body__types_21,
  &predinfo_analyze__type_xset__goals__types_20,
  &predinfo_analyze__type_xset__goals__types1_21,
  &predinfo_analyze__type_xset__goals__mode_11,
  &predinfo_analyze__type_xset__goals__mode1_12,
  &predinfo_analyze__type_xset__goal__types_21,
  &predinfo_analyze__type_xset__goal__types1_23,
  &predinfo_analyze__type_xset__goal__mode_11,
  &predinfo_analyze__type_xset__goal__mode1_11,
  &predinfo_analyze__type_xset__arg__types_13,
  &predinfo_analyze__type_xremove__redundant__indirect_2,
  &predinfo_analyze__type_xremove__redundant__indirect1_3,
  &predinfo_analyze__type_xremove__redandant__indirect__updown_5,
  &predinfo_analyze__type_xremove__redandant__indirect__unify_3,
  &predinfo_analyze__type_xremove__redandant__indirect__unify1_3,
  &predinfo_analyze__type_xremove__redandant__indirect2_4,
  &predinfo_analyze__type_xmake__arg__types_13,
  &predinfo_analyze__type_xmain_12,
  &predinfo_analyze__type_xmain1_13,
  &predinfo_analyze__type_xinterclause__modules_19,
  &predinfo_analyze__type_xinterclause__clauses_22,
  &predinfo_analyze__type_xinterclause__clause_22,
  &predinfo_analyze__type_xindirect__mode__modules_8,
  &predinfo_analyze__type_xindirect__mode__goals_6,
  &predinfo_analyze__type_xindirect__mode__goals1_7,
  &predinfo_analyze__type_xindirect__mode__goal_6,
  &predinfo_analyze__type_xindirect__mode__expansion__alias_6,
  &predinfo_analyze__type_xindirect__mode__expansion_17,
  &predinfo_analyze__type_xindirect__mode__expansion2_14,
  &predinfo_analyze__type_xindirect__mode__expansion1_19,
  &predinfo_analyze__type_xindirect__mode__expansion11_20,
  &predinfo_analyze__type_xindirect__mode__clause_4,
  &predinfo_analyze__type_xindirect__mode__arg_7,
  &predinfo_analyze__type_xindirect__mode__arg1_6,
  &predinfo_analyze__type_xget__call__modulename_3,
  &predinfo_analyze__type_xget__arg__types_6,
  &predinfo_analyze__type_xexpand__ru__indirect__updown_8,
  &predinfo_analyze__type_xexpand__ru__indirect__updown2_6,
  &predinfo_analyze__type_xexpand__ru__indirect__updown1_9,
  &predinfo_analyze__type_xexpand__ru__indirect__unify_8,
  &predinfo_analyze__type_xexpand__ru__indirect__unify2_6,
  &predinfo_analyze__type_xexpand__ru__indirect__unify1_9,
  &predinfo_analyze__type_xexpand__ru__indirect_4,
  &predinfo_analyze__type_xexpand__ru__indirect1_5,
  &predinfo_analyze__type_xcheck__waits_3,
  &predinfo_analyze__type_xbuiltin__type__userdef_10,
  &predinfo_analyze__type_xbuiltin__type__userdef1_11,
  &predinfo_analyze__type_xbuiltin__type__unify_18,
  &predinfo_analyze__type_xbuiltin__type_21,
  &predinfo_analyze__type_xapply__type__goals_16,
  &predinfo_analyze__type_xapply__type__goals1_17,
  &predinfo_analyze__type_xapply__type__goal_17,
  &predinfo_analyze__type_xapply__type__goal2_20,
  &predinfo_analyze__type_xapply__type__goal1_19,
  &predinfo_analyze__type_xapply__new__indirect_13,
  &predinfo_analyze__type_xapply__new__indirect1__alias_28,
  &predinfo_analyze__type_xapply__new__indirect1_18,
  &predinfo_analyze__type_xapply__indirect_16,
  &predinfo_analyze__type_xapply__indirect2__alias_31,
  &predinfo_analyze__type_xapply__indirect2_26,
  &predinfo_analyze__type_xapply__indirect1_19,
  &predinfo_analyze__type_xanalyze__type__modules_12,
  &predinfo_analyze__type_xanalyze__type__modules_11,
  &predinfo_analyze__type_xanalyze__type__clause_13,
  &predinfo_analyze__type_xadd__indirect__deps__alias_15,
  &predinfo_analyze__type_xadd__dep__goal_8,
  0
};
extern Const struct predicate predicate_builtin__type_xupdate__type__setarg_6;
static Const struct predinfo predinfo_builtin__type_xupdate__type__setarg_6 = {
  (unsigned char *)"update_type_setarg",
  &predicate_builtin__type_xupdate__type__setarg_6
};

extern Const struct predicate predicate_builtin__type_xupdate__type__setarg2_6;
static Const struct predinfo predinfo_builtin__type_xupdate__type__setarg2_6 = {
  (unsigned char *)"update_type_setarg2",
  &predicate_builtin__type_xupdate__type__setarg2_6
};

extern Const struct predicate predicate_builtin__type_xupdate__type__setarg1_8;
static Const struct predinfo predinfo_builtin__type_xupdate__type__setarg1_8 = {
  (unsigned char *)"update_type_setarg1",
  &predicate_builtin__type_xupdate__type__setarg1_8
};

extern Const struct predicate predicate_builtin__type_xupdate__type__new__vector_4;
static Const struct predinfo predinfo_builtin__type_xupdate__type__new__vector_4 = {
  (unsigned char *)"update_type_new_vector",
  &predicate_builtin__type_xupdate__type__new__vector_4
};

extern Const struct predicate predicate_builtin__type_xupdate__type__new__vector3_3;
static Const struct predinfo predinfo_builtin__type_xupdate__type__new__vector3_3 = {
  (unsigned char *)"update_type_new_vector3",
  &predicate_builtin__type_xupdate__type__new__vector3_3
};

extern Const struct predicate predicate_builtin__type_xupdate__type__new__vector2_5;
static Const struct predinfo predinfo_builtin__type_xupdate__type__new__vector2_5 = {
  (unsigned char *)"update_type_new_vector2",
  &predicate_builtin__type_xupdate__type__new__vector2_5
};

extern Const struct predicate predicate_builtin__type_xupdate__type__new__vector2_4;
static Const struct predinfo predinfo_builtin__type_xupdate__type__new__vector2_4 = {
  (unsigned char *)"update_type_new_vector2",
  &predicate_builtin__type_xupdate__type__new__vector2_4
};

extern Const struct predicate predicate_builtin__type_xupdate__type__new__vector1_5;
static Const struct predinfo predinfo_builtin__type_xupdate__type__new__vector1_5 = {
  (unsigned char *)"update_type_new_vector1",
  &predicate_builtin__type_xupdate__type__new__vector1_5
};

extern Const struct predicate predicate_builtin__type_xupdate__type__new__functor_4;
static Const struct predinfo predinfo_builtin__type_xupdate__type__new__functor_4 = {
  (unsigned char *)"update_type_new_functor",
  &predicate_builtin__type_xupdate__type__new__functor_4
};

extern Const struct predicate predicate_builtin__type_xupdate__type__new__functor1_4;
static Const struct predinfo predinfo_builtin__type_xupdate__type__new__functor1_4 = {
  (unsigned char *)"update_type_new_functor1",
  &predicate_builtin__type_xupdate__type__new__functor1_4
};

extern Const struct predicate predicate_builtin__type_xupdate__type__functor_4;
static Const struct predinfo predinfo_builtin__type_xupdate__type__functor_4 = {
  (unsigned char *)"update_type_functor",
  &predicate_builtin__type_xupdate__type__functor_4
};

extern Const struct predicate predicate_builtin__type_xupdate__type__functor2_6;
static Const struct predinfo predinfo_builtin__type_xupdate__type__functor2_6 = {
  (unsigned char *)"update_type_functor2",
  &predicate_builtin__type_xupdate__type__functor2_6
};

extern Const struct predicate predicate_builtin__type_xupdate__type__functor1_5;
static Const struct predinfo predinfo_builtin__type_xupdate__type__functor1_5 = {
  (unsigned char *)"update_type_functor1",
  &predicate_builtin__type_xupdate__type__functor1_5
};

extern Const struct predicate predicate_builtin__type_xupdate__type__element__merge_4;
static Const struct predinfo predinfo_builtin__type_xupdate__type__element__merge_4 = {
  (unsigned char *)"update_type_element_merge",
  &predicate_builtin__type_xupdate__type__element__merge_4
};

extern Const struct predicate predicate_builtin__type_xupdate__type__element_4;
static Const struct predinfo predinfo_builtin__type_xupdate__type__element_4 = {
  (unsigned char *)"update_type_element",
  &predicate_builtin__type_xupdate__type__element_4
};

extern Const struct predicate predicate_builtin__type_xupdate__type__element1_4;
static Const struct predinfo predinfo_builtin__type_xupdate__type__element1_4 = {
  (unsigned char *)"update_type_element1",
  &predicate_builtin__type_xupdate__type__element1_4
};

extern Const struct predicate predicate_builtin__type_xupdate__type__arg__merge_4;
static Const struct predinfo predinfo_builtin__type_xupdate__type__arg__merge_4 = {
  (unsigned char *)"update_type_arg_merge",
  &predicate_builtin__type_xupdate__type__arg__merge_4
};

extern Const struct predicate predicate_builtin__type_xupdate__type__arg_4;
static Const struct predinfo predinfo_builtin__type_xupdate__type__arg_4 = {
  (unsigned char *)"update_type_arg",
  &predicate_builtin__type_xupdate__type__arg_4
};

extern Const struct predicate predicate_builtin__type_xupdate__type__arg1_4;
static Const struct predinfo predinfo_builtin__type_xupdate__type__arg1_4 = {
  (unsigned char *)"update_type_arg1",
  &predicate_builtin__type_xupdate__type__arg1_4
};

extern Const struct predicate predicate_builtin__type_xstructname_2;
static Const struct predinfo predinfo_builtin__type_xstructname_2 = {
  (unsigned char *)"structname",
  &predicate_builtin__type_xstructname_2
};

extern Const struct predicate predicate_builtin__type_xstructarity_2;
static Const struct predinfo predinfo_builtin__type_xstructarity_2 = {
  (unsigned char *)"structarity",
  &predicate_builtin__type_xstructarity_2
};

static Const struct predinfo * Const preds_in_builtin__type[] = {
  &predinfo_builtin__type_xupdate__type__setarg_6,
  &predinfo_builtin__type_xupdate__type__setarg2_6,
  &predinfo_builtin__type_xupdate__type__setarg1_8,
  &predinfo_builtin__type_xupdate__type__new__vector_4,
  &predinfo_builtin__type_xupdate__type__new__vector3_3,
  &predinfo_builtin__type_xupdate__type__new__vector2_5,
  &predinfo_builtin__type_xupdate__type__new__vector2_4,
  &predinfo_builtin__type_xupdate__type__new__vector1_5,
  &predinfo_builtin__type_xupdate__type__new__functor_4,
  &predinfo_builtin__type_xupdate__type__new__functor1_4,
  &predinfo_builtin__type_xupdate__type__functor_4,
  &predinfo_builtin__type_xupdate__type__functor2_6,
  &predinfo_builtin__type_xupdate__type__functor1_5,
  &predinfo_builtin__type_xupdate__type__element__merge_4,
  &predinfo_builtin__type_xupdate__type__element_4,
  &predinfo_builtin__type_xupdate__type__element1_4,
  &predinfo_builtin__type_xupdate__type__arg__merge_4,
  &predinfo_builtin__type_xupdate__type__arg_4,
  &predinfo_builtin__type_xupdate__type__arg1_4,
  &predinfo_builtin__type_xstructname_2,
  &predinfo_builtin__type_xstructarity_2,
  0
};
extern Const struct predicate predicate_type__init_xcreate__wait_4;
static Const struct predinfo predinfo_type__init_xcreate__wait_4 = {
  (unsigned char *)"create_wait",
  &predicate_type__init_xcreate__wait_4
};

extern Const struct predicate predicate_type__init_xcreate__userdef__waits_4;
static Const struct predinfo predinfo_type__init_xcreate__userdef__waits_4 = {
  (unsigned char *)"create_userdef_waits",
  &predicate_type__init_xcreate__userdef__waits_4
};

extern Const struct predicate predicate_type__init_xcreate__userdef__waits2_3;
static Const struct predinfo predinfo_type__init_xcreate__userdef__waits2_3 = {
  (unsigned char *)"create_userdef_waits2",
  &predicate_type__init_xcreate__userdef__waits2_3
};

extern Const struct predicate predicate_type__init_xcreate__userdef__waits1_4;
static Const struct predinfo predinfo_type__init_xcreate__userdef__waits1_4 = {
  (unsigned char *)"create_userdef_waits1",
  &predicate_type__init_xcreate__userdef__waits1_4
};

extern Const struct predicate predicate_type__init_xcreate__goal__wait_4;
static Const struct predinfo predinfo_type__init_xcreate__goal__wait_4 = {
  (unsigned char *)"create_goal_wait",
  &predicate_type__init_xcreate__goal__wait_4
};

extern Const struct predicate predicate_type__init_xcreate__goal__wait1_6;
static Const struct predinfo predinfo_type__init_xcreate__goal__wait1_6 = {
  (unsigned char *)"create_goal_wait1",
  &predicate_type__init_xcreate__goal__wait1_6
};

extern Const struct predicate predicate_type__init_xcreate__functor__wait_5;
static Const struct predinfo predinfo_type__init_xcreate__functor__wait_5 = {
  (unsigned char *)"create_functor_wait",
  &predicate_type__init_xcreate__functor__wait_5
};

extern Const struct predicate predicate_type__init_xcreate__functor__wait_4;
static Const struct predinfo predinfo_type__init_xcreate__functor__wait_4 = {
  (unsigned char *)"create_functor_wait",
  &predicate_type__init_xcreate__functor__wait_4
};

extern Const struct predicate predicate_type__init_xcheck__builtin__modules_6;
static Const struct predinfo predinfo_type__init_xcheck__builtin__modules_6 = {
  (unsigned char *)"check_builtin_modules",
  &predicate_type__init_xcheck__builtin__modules_6
};

extern Const struct predicate predicate_type__init_xcheck__builtin__goals_11;
static Const struct predinfo predinfo_type__init_xcheck__builtin__goals_11 = {
  (unsigned char *)"check_builtin_goals",
  &predicate_type__init_xcheck__builtin__goals_11
};

extern Const struct predicate predicate_type__init_xcheck__builtin__goals1_13;
static Const struct predinfo predinfo_type__init_xcheck__builtin__goals1_13 = {
  (unsigned char *)"check_builtin_goals1",
  &predicate_type__init_xcheck__builtin__goals1_13
};

extern Const struct predicate predicate_type__init_xcheck__builtin__goal_12;
static Const struct predinfo predinfo_type__init_xcheck__builtin__goal_12 = {
  (unsigned char *)"check_builtin_goal",
  &predicate_type__init_xcheck__builtin__goal_12
};

extern Const struct predicate predicate_type__init_xcheck__builtin__goal1_15;
static Const struct predinfo predinfo_type__init_xcheck__builtin__goal1_15 = {
  (unsigned char *)"check_builtin_goal1",
  &predicate_type__init_xcheck__builtin__goal1_15
};

extern Const struct predicate predicate_type__init_xcheck__builtin__clauses_7;
static Const struct predinfo predinfo_type__init_xcheck__builtin__clauses_7 = {
  (unsigned char *)"check_builtin_clauses",
  &predicate_type__init_xcheck__builtin__clauses_7
};

extern Const struct predicate predicate_type__init_xcheck__builtin__clauses1_9;
static Const struct predinfo predinfo_type__init_xcheck__builtin__clauses1_9 = {
  (unsigned char *)"check_builtin_clauses1",
  &predicate_type__init_xcheck__builtin__clauses1_9
};

extern Const struct predicate predicate_type__init_xcheck__builtin__clause_8;
static Const struct predinfo predinfo_type__init_xcheck__builtin__clause_8 = {
  (unsigned char *)"check_builtin_clause",
  &predicate_type__init_xcheck__builtin__clause_8
};

extern Const struct predicate predicate_type__init_xbuiltin__type__unify_15;
static Const struct predinfo predinfo_type__init_xbuiltin__type__unify_15 = {
  (unsigned char *)"builtin_type_unify",
  &predicate_type__init_xbuiltin__type__unify_15
};

extern Const struct predicate predicate_type__init_xbuiltin__type_17;
static Const struct predinfo predinfo_type__init_xbuiltin__type_17 = {
  (unsigned char *)"builtin_type",
  &predicate_type__init_xbuiltin__type_17
};

static Const struct predinfo * Const preds_in_type__init[] = {
  &predinfo_type__init_xcreate__wait_4,
  &predinfo_type__init_xcreate__userdef__waits_4,
  &predinfo_type__init_xcreate__userdef__waits2_3,
  &predinfo_type__init_xcreate__userdef__waits1_4,
  &predinfo_type__init_xcreate__goal__wait_4,
  &predinfo_type__init_xcreate__goal__wait1_6,
  &predinfo_type__init_xcreate__functor__wait_5,
  &predinfo_type__init_xcreate__functor__wait_4,
  &predinfo_type__init_xcheck__builtin__modules_6,
  &predinfo_type__init_xcheck__builtin__goals_11,
  &predinfo_type__init_xcheck__builtin__goals1_13,
  &predinfo_type__init_xcheck__builtin__goal_12,
  &predinfo_type__init_xcheck__builtin__goal1_15,
  &predinfo_type__init_xcheck__builtin__clauses_7,
  &predinfo_type__init_xcheck__builtin__clauses1_9,
  &predinfo_type__init_xcheck__builtin__clause_8,
  &predinfo_type__init_xbuiltin__type__unify_15,
  &predinfo_type__init_xbuiltin__type_17,
  0
};
extern Const struct predicate predicate_determine__type_xmain_8;
static Const struct predinfo predinfo_determine__type_xmain_8 = {
  (unsigned char *)"main",
  &predicate_determine__type_xmain_8
};

static Const struct predinfo * Const preds_in_determine__type[] = {
  &predinfo_determine__type_xmain_8,
  0
};
extern Const struct predicate predicate_dependency_xmake__goal__dependency_12;
static Const struct predinfo predinfo_dependency_xmake__goal__dependency_12 = {
  (unsigned char *)"make_goal_dependency",
  &predicate_dependency_xmake__goal__dependency_12
};

extern Const struct predicate predicate_dependency_xmake__goal__dependency1_9;
static Const struct predinfo predinfo_dependency_xmake__goal__dependency1_9 = {
  (unsigned char *)"make_goal_dependency1",
  &predicate_dependency_xmake__goal__dependency1_9
};

extern Const struct predicate predicate_dependency_xmake__dependency__unify_8;
static Const struct predinfo predinfo_dependency_xmake__dependency__unify_8 = {
  (unsigned char *)"make_dependency_unify",
  &predicate_dependency_xmake__dependency__unify_8
};

extern Const struct predicate predicate_dependency_xmake__depend__guards_4;
static Const struct predinfo predinfo_dependency_xmake__depend__guards_4 = {
  (unsigned char *)"make_depend_guards",
  &predicate_dependency_xmake__depend__guards_4
};

extern Const struct predicate predicate_dependency_xmake__data__dep__goals_8;
static Const struct predinfo predinfo_dependency_xmake__data__dep__goals_8 = {
  (unsigned char *)"make_data_dep_goals",
  &predicate_dependency_xmake__data__dep__goals_8
};

extern Const struct predicate predicate_dependency_xmake__data__dep__goals1_9;
static Const struct predinfo predinfo_dependency_xmake__data__dep__goals1_9 = {
  (unsigned char *)"make_data_dep_goals1",
  &predicate_dependency_xmake__data__dep__goals1_9
};

extern Const struct predicate predicate_dependency_xmake__data__dep__clauses_7;
static Const struct predinfo predinfo_dependency_xmake__data__dep__clauses_7 = {
  (unsigned char *)"make_data_dep_clauses",
  &predicate_dependency_xmake__data__dep__clauses_7
};

extern Const struct predicate predicate_dependency_xmake__data__dep__clause_7;
static Const struct predinfo predinfo_dependency_xmake__data__dep__clause_7 = {
  (unsigned char *)"make_data_dep_clause",
  &predicate_dependency_xmake__data__dep__clause_7
};

extern Const struct predicate predicate_dependency_xmake__data__dep_5;
static Const struct predinfo predinfo_dependency_xmake__data__dep_5 = {
  (unsigned char *)"make_data_dep",
  &predicate_dependency_xmake__data__dep_5
};

extern Const struct predicate predicate_dependency_xmake__control__dep__modules_8;
static Const struct predinfo predinfo_dependency_xmake__control__dep__modules_8 = {
  (unsigned char *)"make_control_dep_modules",
  &predicate_dependency_xmake__control__dep__modules_8
};

extern Const struct predicate predicate_dependency_xmake__control__dep__guards_6;
static Const struct predinfo predinfo_dependency_xmake__control__dep__guards_6 = {
  (unsigned char *)"make_control_dep_guards",
  &predicate_dependency_xmake__control__dep__guards_6
};

extern Const struct predicate predicate_dependency_xmake__control__dep__clauses_9;
static Const struct predinfo predinfo_dependency_xmake__control__dep__clauses_9 = {
  (unsigned char *)"make_control_dep_clauses",
  &predicate_dependency_xmake__control__dep__clauses_9
};

extern Const struct predicate predicate_dependency_xmake__control__dep__bodys_9;
static Const struct predinfo predinfo_dependency_xmake__control__dep__bodys_9 = {
  (unsigned char *)"make_control_dep_bodys",
  &predicate_dependency_xmake__control__dep__bodys_9
};

extern Const struct predicate predicate_dependency_xmake__control__dep_3;
static Const struct predinfo predinfo_dependency_xmake__control__dep_3 = {
  (unsigned char *)"make_control_dep",
  &predicate_dependency_xmake__control__dep_3
};

extern Const struct predicate predicate_dependency_xinit__deps__clauses_3;
static Const struct predinfo predinfo_dependency_xinit__deps__clauses_3 = {
  (unsigned char *)"init_deps_clauses",
  &predicate_dependency_xinit__deps__clauses_3
};

extern Const struct predicate predicate_dependency_xinit__deps__clause_2;
static Const struct predinfo predinfo_dependency_xinit__deps__clause_2 = {
  (unsigned char *)"init_deps_clause",
  &predicate_dependency_xinit__deps__clause_2
};

extern Const struct predicate predicate_dependency_xinit__deps_2;
static Const struct predinfo predinfo_dependency_xinit__deps_2 = {
  (unsigned char *)"init_deps",
  &predicate_dependency_xinit__deps_2
};

extern Const struct predicate predicate_dependency_xindirect__goals_9;
static Const struct predinfo predinfo_dependency_xindirect__goals_9 = {
  (unsigned char *)"indirect_goals",
  &predicate_dependency_xindirect__goals_9
};

extern Const struct predicate predicate_dependency_xindirect__goals1_9;
static Const struct predinfo predinfo_dependency_xindirect__goals1_9 = {
  (unsigned char *)"indirect_goals1",
  &predicate_dependency_xindirect__goals1_9
};

extern Const struct predicate predicate_dependency_xindirect__goal_7;
static Const struct predinfo predinfo_dependency_xindirect__goal_7 = {
  (unsigned char *)"indirect_goal",
  &predicate_dependency_xindirect__goal_7
};

extern Const struct predicate predicate_dependency_xindirect__clause_8;
static Const struct predinfo predinfo_dependency_xindirect__clause_8 = {
  (unsigned char *)"indirect_clause",
  &predicate_dependency_xindirect__clause_8
};

extern Const struct predicate predicate_dependency_xindirect_4;
static Const struct predinfo predinfo_dependency_xindirect_4 = {
  (unsigned char *)"indirect",
  &predicate_dependency_xindirect_4
};

extern Const struct predicate predicate_dependency_xget__var__dependency__var_8;
static Const struct predinfo predinfo_dependency_xget__var__dependency__var_8 = {
  (unsigned char *)"get_var_dependency_var",
  &predicate_dependency_xget__var__dependency__var_8
};

extern Const struct predicate predicate_dependency_xget__var__dependency__var1_9;
static Const struct predinfo predinfo_dependency_xget__var__dependency__var1_9 = {
  (unsigned char *)"get_var_dependency_var1",
  &predicate_dependency_xget__var__dependency__var1_9
};

extern Const struct predicate predicate_dependency_xget__var__dependency__struct_8;
static Const struct predinfo predinfo_dependency_xget__var__dependency__struct_8 = {
  (unsigned char *)"get_var_dependency_struct",
  &predicate_dependency_xget__var__dependency__struct_8
};

extern Const struct predicate predicate_dependency_xget__var__dependency__struct1_9;
static Const struct predinfo predinfo_dependency_xget__var__dependency__struct1_9 = {
  (unsigned char *)"get_var_dependency_struct1",
  &predicate_dependency_xget__var__dependency__struct1_9
};

extern Const struct predicate predicate_dependency_xget__var__dependency_8;
static Const struct predinfo predinfo_dependency_xget__var__dependency_8 = {
  (unsigned char *)"get_var_dependency",
  &predicate_dependency_xget__var__dependency_8
};

extern Const struct predicate predicate_dependency_xget__unify__depgoals__struct_6;
static Const struct predinfo predinfo_dependency_xget__unify__depgoals__struct_6 = {
  (unsigned char *)"get_unify_depgoals_struct",
  &predicate_dependency_xget__unify__depgoals__struct_6
};

extern Const struct predicate predicate_dependency_xget__unify__depgoals__dstruct_6;
static Const struct predinfo predinfo_dependency_xget__unify__depgoals__dstruct_6 = {
  (unsigned char *)"get_unify_depgoals_dstruct",
  &predicate_dependency_xget__unify__depgoals__dstruct_6
};

extern Const struct predicate predicate_dependency_xget__unify__depgoals_4;
static Const struct predinfo predinfo_dependency_xget__unify__depgoals_4 = {
  (unsigned char *)"get_unify_depgoals",
  &predicate_dependency_xget__unify__depgoals_4
};

extern Const struct predicate predicate_dependency_xget__unify__depgoals3_5;
static Const struct predinfo predinfo_dependency_xget__unify__depgoals3_5 = {
  (unsigned char *)"get_unify_depgoals3",
  &predicate_dependency_xget__unify__depgoals3_5
};

extern Const struct predicate predicate_dependency_xget__unify__depgoals2_5;
static Const struct predinfo predinfo_dependency_xget__unify__depgoals2_5 = {
  (unsigned char *)"get_unify_depgoals2",
  &predicate_dependency_xget__unify__depgoals2_5
};

extern Const struct predicate predicate_dependency_xget__unify__depgoals1_5;
static Const struct predinfo predinfo_dependency_xget__unify__depgoals1_5 = {
  (unsigned char *)"get_unify_depgoals1",
  &predicate_dependency_xget__unify__depgoals1_5
};

extern Const struct predicate predicate_dependency_xget__deps__clause__goals_2;
static Const struct predinfo predinfo_dependency_xget__deps__clause__goals_2 = {
  (unsigned char *)"get_deps_clause_goals",
  &predicate_dependency_xget__deps__clause__goals_2
};

extern Const struct predicate predicate_dependency_xget__deps__clause__goals1_4;
static Const struct predinfo predinfo_dependency_xget__deps__clause__goals1_4 = {
  (unsigned char *)"get_deps_clause_goals1",
  &predicate_dependency_xget__deps__clause__goals1_4
};

extern Const struct predicate predicate_dependency_xget__deps__clause_4;
static Const struct predinfo predinfo_dependency_xget__deps__clause_4 = {
  (unsigned char *)"get_deps_clause",
  &predicate_dependency_xget__deps__clause_4
};

extern Const struct predicate predicate_dependency_xget__deps_4;
static Const struct predinfo predinfo_dependency_xget__deps_4 = {
  (unsigned char *)"get_deps",
  &predicate_dependency_xget__deps_4
};

extern Const struct predicate predicate_dependency_xget__deps1_3;
static Const struct predinfo predinfo_dependency_xget__deps1_3 = {
  (unsigned char *)"get_deps1",
  &predicate_dependency_xget__deps1_3
};

extern Const struct predicate predicate_dependency_xexpand__shared__types_10;
static Const struct predinfo predinfo_dependency_xexpand__shared__types_10 = {
  (unsigned char *)"expand_shared_types",
  &predicate_dependency_xexpand__shared__types_10
};

extern Const struct predicate predicate_dependency_xexpand__shared__type__var_15;
static Const struct predinfo predinfo_dependency_xexpand__shared__type__var_15 = {
  (unsigned char *)"expand_shared_type_var",
  &predicate_dependency_xexpand__shared__type__var_15
};

extern Const struct predicate predicate_dependency_xexpand__shared__type__struct_11;
static Const struct predinfo predinfo_dependency_xexpand__shared__type__struct_11 = {
  (unsigned char *)"expand_shared_type_struct",
  &predicate_dependency_xexpand__shared__type__struct_11
};

extern Const struct predicate predicate_dependency_xexpand__shared__type__make__mode_3;
static Const struct predinfo predinfo_dependency_xexpand__shared__type__make__mode_3 = {
  (unsigned char *)"expand_shared_type_make_mode",
  &predicate_dependency_xexpand__shared__type__make__mode_3
};

extern Const struct predicate predicate_dependency_xexpand__shared__type__make__mode1_2;
static Const struct predinfo predinfo_dependency_xexpand__shared__type__make__mode1_2 = {
  (unsigned char *)"expand_shared_type_make_mode1",
  &predicate_dependency_xexpand__shared__type__make__mode1_2
};

extern Const struct predicate predicate_dependency_xexpand__shared__type__add__deps_7;
static Const struct predinfo predinfo_dependency_xexpand__shared__type__add__deps_7 = {
  (unsigned char *)"expand_shared_type_add_deps",
  &predicate_dependency_xexpand__shared__type__add__deps_7
};

extern Const struct predicate predicate_dependency_xexpand__shared__type_11;
static Const struct predinfo predinfo_dependency_xexpand__shared__type_11 = {
  (unsigned char *)"expand_shared_type",
  &predicate_dependency_xexpand__shared__type_11
};

extern Const struct predicate predicate_dependency_xexpand__shared__clauses_7;
static Const struct predinfo predinfo_dependency_xexpand__shared__clauses_7 = {
  (unsigned char *)"expand_shared_clauses",
  &predicate_dependency_xexpand__shared__clauses_7
};

extern Const struct predicate predicate_dependency_xexpand__shared__bodys_8;
static Const struct predinfo predinfo_dependency_xexpand__shared__bodys_8 = {
  (unsigned char *)"expand_shared_bodys",
  &predicate_dependency_xexpand__shared__bodys_8
};

extern Const struct predicate predicate_dependency_xexpand__shared__body_9;
static Const struct predinfo predinfo_dependency_xexpand__shared__body_9 = {
  (unsigned char *)"expand_shared_body",
  &predicate_dependency_xexpand__shared__body_9
};

extern Const struct predicate predicate_dependency_xexpand__shared__args_9;
static Const struct predinfo predinfo_dependency_xexpand__shared__args_9 = {
  (unsigned char *)"expand_shared_args",
  &predicate_dependency_xexpand__shared__args_9
};

extern Const struct predicate predicate_dependency_xexpand__shared__arg_8;
static Const struct predinfo predinfo_dependency_xexpand__shared__arg_8 = {
  (unsigned char *)"expand_shared_arg",
  &predicate_dependency_xexpand__shared__arg_8
};

extern Const struct predicate predicate_dependency_xexpand__shared__arg_5;
static Const struct predinfo predinfo_dependency_xexpand__shared__arg_5 = {
  (unsigned char *)"expand_shared_arg",
  &predicate_dependency_xexpand__shared__arg_5
};

extern Const struct predicate predicate_dependency_xexpand__indirect_6;
static Const struct predinfo predinfo_dependency_xexpand__indirect_6 = {
  (unsigned char *)"expand_indirect",
  &predicate_dependency_xexpand__indirect_6
};

extern Const struct predicate predicate_dependency_xexpand__indirect1_7;
static Const struct predinfo predinfo_dependency_xexpand__indirect1_7 = {
  (unsigned char *)"expand_indirect1",
  &predicate_dependency_xexpand__indirect1_7
};

extern Const struct predicate predicate_dependency_xentry__deps_5;
static Const struct predinfo predinfo_dependency_xentry__deps_5 = {
  (unsigned char *)"entry_deps",
  &predicate_dependency_xentry__deps_5
};

extern Const struct predicate predicate_dependency_xentry__deps1_4;
static Const struct predinfo predinfo_dependency_xentry__deps1_4 = {
  (unsigned char *)"entry_deps1",
  &predicate_dependency_xentry__deps1_4
};

extern Const struct predicate predicate_dependency_xentry__data__deps__loops_3;
static Const struct predinfo predinfo_dependency_xentry__data__deps__loops_3 = {
  (unsigned char *)"entry_data_deps_loops",
  &predicate_dependency_xentry__data__deps__loops_3
};

extern Const struct predicate predicate_dependency_xentry__data__deps__filter_3;
static Const struct predinfo predinfo_dependency_xentry__data__deps__filter_3 = {
  (unsigned char *)"entry_data_deps_filter",
  &predicate_dependency_xentry__data__deps__filter_3
};

extern Const struct predicate predicate_dependency_xentry__data__deps_4;
static Const struct predinfo predinfo_dependency_xentry__data__deps_4 = {
  (unsigned char *)"entry_data_deps",
  &predicate_dependency_xentry__data__deps_4
};

extern Const struct predicate predicate_dependency_xcall__make__control__dep__modules_9;
static Const struct predinfo predinfo_dependency_xcall__make__control__dep__modules_9 = {
  (unsigned char *)"call_make_control_dep_modules",
  &predicate_dependency_xcall__make__control__dep__modules_9
};

static Const struct predinfo * Const preds_in_dependency[] = {
  &predinfo_dependency_xmake__goal__dependency_12,
  &predinfo_dependency_xmake__goal__dependency1_9,
  &predinfo_dependency_xmake__dependency__unify_8,
  &predinfo_dependency_xmake__depend__guards_4,
  &predinfo_dependency_xmake__data__dep__goals_8,
  &predinfo_dependency_xmake__data__dep__goals1_9,
  &predinfo_dependency_xmake__data__dep__clauses_7,
  &predinfo_dependency_xmake__data__dep__clause_7,
  &predinfo_dependency_xmake__data__dep_5,
  &predinfo_dependency_xmake__control__dep__modules_8,
  &predinfo_dependency_xmake__control__dep__guards_6,
  &predinfo_dependency_xmake__control__dep__clauses_9,
  &predinfo_dependency_xmake__control__dep__bodys_9,
  &predinfo_dependency_xmake__control__dep_3,
  &predinfo_dependency_xinit__deps__clauses_3,
  &predinfo_dependency_xinit__deps__clause_2,
  &predinfo_dependency_xinit__deps_2,
  &predinfo_dependency_xindirect__goals_9,
  &predinfo_dependency_xindirect__goals1_9,
  &predinfo_dependency_xindirect__goal_7,
  &predinfo_dependency_xindirect__clause_8,
  &predinfo_dependency_xindirect_4,
  &predinfo_dependency_xget__var__dependency__var_8,
  &predinfo_dependency_xget__var__dependency__var1_9,
  &predinfo_dependency_xget__var__dependency__struct_8,
  &predinfo_dependency_xget__var__dependency__struct1_9,
  &predinfo_dependency_xget__var__dependency_8,
  &predinfo_dependency_xget__unify__depgoals__struct_6,
  &predinfo_dependency_xget__unify__depgoals__dstruct_6,
  &predinfo_dependency_xget__unify__depgoals_4,
  &predinfo_dependency_xget__unify__depgoals3_5,
  &predinfo_dependency_xget__unify__depgoals2_5,
  &predinfo_dependency_xget__unify__depgoals1_5,
  &predinfo_dependency_xget__deps__clause__goals_2,
  &predinfo_dependency_xget__deps__clause__goals1_4,
  &predinfo_dependency_xget__deps__clause_4,
  &predinfo_dependency_xget__deps_4,
  &predinfo_dependency_xget__deps1_3,
  &predinfo_dependency_xexpand__shared__types_10,
  &predinfo_dependency_xexpand__shared__type__var_15,
  &predinfo_dependency_xexpand__shared__type__struct_11,
  &predinfo_dependency_xexpand__shared__type__make__mode_3,
  &predinfo_dependency_xexpand__shared__type__make__mode1_2,
  &predinfo_dependency_xexpand__shared__type__add__deps_7,
  &predinfo_dependency_xexpand__shared__type_11,
  &predinfo_dependency_xexpand__shared__clauses_7,
  &predinfo_dependency_xexpand__shared__bodys_8,
  &predinfo_dependency_xexpand__shared__body_9,
  &predinfo_dependency_xexpand__shared__args_9,
  &predinfo_dependency_xexpand__shared__arg_8,
  &predinfo_dependency_xexpand__shared__arg_5,
  &predinfo_dependency_xexpand__indirect_6,
  &predinfo_dependency_xexpand__indirect1_7,
  &predinfo_dependency_xentry__deps_5,
  &predinfo_dependency_xentry__deps1_4,
  &predinfo_dependency_xentry__data__deps__loops_3,
  &predinfo_dependency_xentry__data__deps__filter_3,
  &predinfo_dependency_xentry__data__deps_4,
  &predinfo_dependency_xcall__make__control__dep__modules_9,
  0
};
extern Const struct predicate predicate_type_xvalue2types__vector__arg_10;
static Const struct predinfo predinfo_type_xvalue2types__vector__arg_10 = {
  (unsigned char *)"value2types_vector_arg",
  &predicate_type_xvalue2types__vector__arg_10
};

extern Const struct predicate predicate_type_xvalue2types__functor__arg_10;
static Const struct predinfo predinfo_type_xvalue2types__functor__arg_10 = {
  (unsigned char *)"value2types_functor_arg",
  &predicate_type_xvalue2types__functor__arg_10
};

extern Const struct predicate predicate_type_xvalue2types_7;
static Const struct predinfo predinfo_type_xvalue2types_7 = {
  (unsigned char *)"value2types",
  &predicate_type_xvalue2types_7
};

extern Const struct predicate predicate_type_xvalue2types1_9;
static Const struct predinfo predinfo_type_xvalue2types1_9 = {
  (unsigned char *)"value2types1",
  &predicate_type_xvalue2types1_9
};

extern Const struct predicate predicate_type_xtype2structtype_2;
static Const struct predinfo predinfo_type_xtype2structtype_2 = {
  (unsigned char *)"type2structtype",
  &predicate_type_xtype2structtype_2
};

extern Const struct predicate predicate_type_xtype2structtype1_3;
static Const struct predinfo predinfo_type_xtype2structtype1_3 = {
  (unsigned char *)"type2structtype1",
  &predicate_type_xtype2structtype1_3
};

extern Const struct predicate predicate_type_xtype2list_2;
static Const struct predinfo predinfo_type_xtype2list_2 = {
  (unsigned char *)"type2list",
  &predicate_type_xtype2list_2
};

extern Const struct predicate predicate_type_xtype2list1_2;
static Const struct predinfo predinfo_type_xtype2list1_2 = {
  (unsigned char *)"type2list1",
  &predicate_type_xtype2list1_2
};

extern Const struct predicate predicate_type_xtype2int_2;
static Const struct predinfo predinfo_type_xtype2int_2 = {
  (unsigned char *)"type2int",
  &predicate_type_xtype2int_2
};

extern Const struct predicate predicate_type_xtype2atom_2;
static Const struct predinfo predinfo_type_xtype2atom_2 = {
  (unsigned char *)"type2atom",
  &predicate_type_xtype2atom_2
};

extern Const struct predicate predicate_type_xsplit__types__var__val_3;
static Const struct predinfo predinfo_type_xsplit__types__var__val_3 = {
  (unsigned char *)"split_types_var_val",
  &predicate_type_xsplit__types__var__val_3
};

extern Const struct predicate predicate_type_xset__types_13;
static Const struct predinfo predinfo_type_xset__types_13 = {
  (unsigned char *)"set_types",
  &predicate_type_xset__types_13
};

extern Const struct predicate predicate_type_xset__types_11;
static Const struct predinfo predinfo_type_xset__types_11 = {
  (unsigned char *)"set_types",
  &predicate_type_xset__types_11
};

extern Const struct predicate predicate_type_xset__types1_13;
static Const struct predinfo predinfo_type_xset__types1_13 = {
  (unsigned char *)"set_types1",
  &predicate_type_xset__types1_13
};

extern Const struct predicate predicate_type_xset__struct__arg__types_4;
static Const struct predinfo predinfo_type_xset__struct__arg__types_4 = {
  (unsigned char *)"set_struct_arg_types",
  &predicate_type_xset__struct__arg__types_4
};

extern Const struct predicate predicate_type_xset__ru__args_4;
static Const struct predinfo predinfo_type_xset__ru__args_4 = {
  (unsigned char *)"set_ru_args",
  &predicate_type_xset__ru__args_4
};

extern Const struct predicate predicate_type_xset__ru_3;
static Const struct predinfo predinfo_type_xset__ru_3 = {
  (unsigned char *)"set_ru",
  &predicate_type_xset__ru_3
};

extern Const struct predicate predicate_type_xremove__types__deps_4;
static Const struct predinfo predinfo_type_xremove__types__deps_4 = {
  (unsigned char *)"remove_types_deps",
  &predicate_type_xremove__types__deps_4
};

extern Const struct predicate predicate_type_xremove__types__deps_3;
static Const struct predinfo predinfo_type_xremove__types__deps_3 = {
  (unsigned char *)"remove_types_deps",
  &predicate_type_xremove__types__deps_3
};

extern Const struct predicate predicate_type_xremove__type__deps_4;
static Const struct predinfo predinfo_type_xremove__type__deps_4 = {
  (unsigned char *)"remove_type_deps",
  &predicate_type_xremove__type__deps_4
};

extern Const struct predicate predicate_type_xremove__type__args_5;
static Const struct predinfo predinfo_type_xremove__type__args_5 = {
  (unsigned char *)"remove_type_args",
  &predicate_type_xremove__type__args_5
};

extern Const struct predicate predicate_type_xor__types_3;
static Const struct predinfo predinfo_type_xor__types_3 = {
  (unsigned char *)"or_types",
  &predicate_type_xor__types_3
};

extern Const struct predicate predicate_type_xor__types2_6;
static Const struct predinfo predinfo_type_xor__types2_6 = {
  (unsigned char *)"or_types2",
  &predicate_type_xor__types2_6
};

extern Const struct predicate predicate_type_xor__types1_3;
static Const struct predinfo predinfo_type_xor__types1_3 = {
  (unsigned char *)"or_types1",
  &predicate_type_xor__types1_3
};

extern Const struct predicate predicate_type_xor__type__element__vmode_3;
static Const struct predinfo predinfo_type_xor__type__element__vmode_3 = {
  (unsigned char *)"or_type_element_vmode",
  &predicate_type_xor__type__element__vmode_3
};

extern Const struct predicate predicate_type_xor__type__element__struct_8;
static Const struct predinfo predinfo_type_xor__type__element__struct_8 = {
  (unsigned char *)"or_type_element_struct",
  &predicate_type_xor__type__element__struct_8
};

extern Const struct predicate predicate_type_xor__type__element__struct1_7;
static Const struct predinfo predinfo_type_xor__type__element__struct1_7 = {
  (unsigned char *)"or_type_element_struct1",
  &predicate_type_xor__type__element__struct1_7
};

extern Const struct predicate predicate_type_xor__type__element__argslist_4;
static Const struct predinfo predinfo_type_xor__type__element__argslist_4 = {
  (unsigned char *)"or_type_element_argslist",
  &predicate_type_xor__type__element__argslist_4
};

extern Const struct predicate predicate_type_xor__type__element__args_4;
static Const struct predinfo predinfo_type_xor__type__element__args_4 = {
  (unsigned char *)"or_type_element_args",
  &predicate_type_xor__type__element__args_4
};

extern Const struct predicate predicate_type_xor__type__element_4;
static Const struct predinfo predinfo_type_xor__type__element_4 = {
  (unsigned char *)"or_type_element",
  &predicate_type_xor__type__element_4
};

extern Const struct predicate predicate_type_xmerge__ru_3;
static Const struct predinfo predinfo_type_xmerge__ru_3 = {
  (unsigned char *)"merge_ru",
  &predicate_type_xmerge__ru_3
};

extern Const struct predicate predicate_type_xmerge__loopgoals__filter_5;
static Const struct predinfo predinfo_type_xmerge__loopgoals__filter_5 = {
  (unsigned char *)"merge_loopgoals_filter",
  &predicate_type_xmerge__loopgoals__filter_5
};

extern Const struct predicate predicate_type_xmerge__goals__filter_3;
static Const struct predinfo predinfo_type_xmerge__goals__filter_3 = {
  (unsigned char *)"merge_goals_filter",
  &predicate_type_xmerge__goals__filter_3
};

extern Const struct predicate predicate_type_xmerge__goals_3;
static Const struct predinfo predinfo_type_xmerge__goals_3 = {
  (unsigned char *)"merge_goals",
  &predicate_type_xmerge__goals_3
};

extern Const struct predicate predicate_type_xmerge__atomic_4;
static Const struct predinfo predinfo_type_xmerge__atomic_4 = {
  (unsigned char *)"merge_atomic",
  &predicate_type_xmerge__atomic_4
};

extern Const struct predicate predicate_type_xmake__types__loopup_9;
static Const struct predinfo predinfo_type_xmake__types__loopup_9 = {
  (unsigned char *)"make_types_loopup",
  &predicate_type_xmake__types__loopup_9
};

extern Const struct predicate predicate_type_xmake__types__loopup1_9;
static Const struct predinfo predinfo_type_xmake__types__loopup1_9 = {
  (unsigned char *)"make_types_loopup1",
  &predicate_type_xmake__types__loopup1_9
};

extern Const struct predicate predicate_type_xmake__types__loopdown_16;
static Const struct predinfo predinfo_type_xmake__types__loopdown_16 = {
  (unsigned char *)"make_types_loopdown",
  &predicate_type_xmake__types__loopdown_16
};

extern Const struct predicate predicate_type_xmake__type__loopup__struct_10;
static Const struct predinfo predinfo_type_xmake__type__loopup__struct_10 = {
  (unsigned char *)"make_type_loopup_struct",
  &predicate_type_xmake__type__loopup__struct_10
};

extern Const struct predicate predicate_type_xmake__type__loopup_9;
static Const struct predinfo predinfo_type_xmake__type__loopup_9 = {
  (unsigned char *)"make_type_loopup",
  &predicate_type_xmake__type__loopup_9
};

extern Const struct predicate predicate_type_xmake__type__loopdown__args_17;
static Const struct predinfo predinfo_type_xmake__type__loopdown__args_17 = {
  (unsigned char *)"make_type_loopdown_args",
  &predicate_type_xmake__type__loopdown__args_17
};

extern Const struct predicate predicate_type_xmake__type__loopdown_16;
static Const struct predinfo predinfo_type_xmake__type__loopdown_16 = {
  (unsigned char *)"make_type_loopdown",
  &predicate_type_xmake__type__loopdown_16
};

extern Const struct predicate predicate_type_xmake__indirect__unify_4;
static Const struct predinfo predinfo_type_xmake__indirect__unify_4 = {
  (unsigned char *)"make_indirect_unify",
  &predicate_type_xmake__indirect__unify_4
};

extern Const struct predicate predicate_type_xmake__indirect__unify3_4;
static Const struct predinfo predinfo_type_xmake__indirect__unify3_4 = {
  (unsigned char *)"make_indirect_unify3",
  &predicate_type_xmake__indirect__unify3_4
};

extern Const struct predicate predicate_type_xmake__indirect__unify2_4;
static Const struct predinfo predinfo_type_xmake__indirect__unify2_4 = {
  (unsigned char *)"make_indirect_unify2",
  &predicate_type_xmake__indirect__unify2_4
};

extern Const struct predicate predicate_type_xmake__indirect__unify1_4;
static Const struct predinfo predinfo_type_xmake__indirect__unify1_4 = {
  (unsigned char *)"make_indirect_unify1",
  &predicate_type_xmake__indirect__unify1_4
};

extern Const struct predicate predicate_type_xlisttype__val__merge_3;
static Const struct predinfo predinfo_type_xlisttype__val__merge_3 = {
  (unsigned char *)"listtype_val_merge",
  &predicate_type_xlisttype__val__merge_3
};

extern Const struct predicate predicate_type_xlisttype__val__merge1_3;
static Const struct predinfo predinfo_type_xlisttype__val__merge1_3 = {
  (unsigned char *)"listtype_val_merge1",
  &predicate_type_xlisttype__val__merge1_3
};

extern Const struct predicate predicate_type_xlisttype__val_3;
static Const struct predinfo predinfo_type_xlisttype__val_3 = {
  (unsigned char *)"listtype_val",
  &predicate_type_xlisttype__val_3
};

extern Const struct predicate predicate_type_xlisttype__val2_4;
static Const struct predinfo predinfo_type_xlisttype__val2_4 = {
  (unsigned char *)"listtype_val2",
  &predicate_type_xlisttype__val2_4
};

extern Const struct predicate predicate_type_xlisttype__val1_4;
static Const struct predinfo predinfo_type_xlisttype__val1_4 = {
  (unsigned char *)"listtype_val1",
  &predicate_type_xlisttype__val1_4
};

extern Const struct predicate predicate_type_xget__types_5;
static Const struct predinfo predinfo_type_xget__types_5 = {
  (unsigned char *)"get_types",
  &predicate_type_xget__types_5
};

extern Const struct predicate predicate_type_xget__struct__arg__types_3;
static Const struct predinfo predinfo_type_xget__struct__arg__types_3 = {
  (unsigned char *)"get_struct_arg_types",
  &predicate_type_xget__struct__arg__types_3
};

extern Const struct predicate predicate_type_xget__loopdeps_2;
static Const struct predinfo predinfo_type_xget__loopdeps_2 = {
  (unsigned char *)"get_loopdeps",
  &predicate_type_xget__loopdeps_2
};

extern Const struct predicate predicate_type_xget__loopdeps1_3;
static Const struct predinfo predinfo_type_xget__loopdeps1_3 = {
  (unsigned char *)"get_loopdeps1",
  &predicate_type_xget__loopdeps1_3
};

extern Const struct predicate predicate_type_xget__arg__types_5;
static Const struct predinfo predinfo_type_xget__arg__types_5 = {
  (unsigned char *)"get_arg_types",
  &predicate_type_xget__arg__types_5
};

extern Const struct predicate predicate_type_xentry__updated_10;
static Const struct predinfo predinfo_type_xentry__updated_10 = {
  (unsigned char *)"entry_updated",
  &predicate_type_xentry__updated_10
};

extern Const struct predicate predicate_type_xentry__new__aliasvar__gen_13;
static Const struct predinfo predinfo_type_xentry__new__aliasvar__gen_13 = {
  (unsigned char *)"entry_new_aliasvar_gen",
  &predicate_type_xentry__new__aliasvar__gen_13
};

extern Const struct predicate predicate_type_xentry__new__aliasvar__gen1_5;
static Const struct predinfo predinfo_type_xentry__new__aliasvar__gen1_5 = {
  (unsigned char *)"entry_new_aliasvar_gen1",
  &predicate_type_xentry__new__aliasvar__gen1_5
};

extern Const struct predicate predicate_type_xentry__new__aliasvar__cycliccheck_10;
static Const struct predinfo predinfo_type_xentry__new__aliasvar__cycliccheck_10 = {
  (unsigned char *)"entry_new_aliasvar_cycliccheck",
  &predicate_type_xentry__new__aliasvar__cycliccheck_10
};

extern Const struct predicate predicate_type_xentry__new__aliasvar__cycliccheck2_9;
static Const struct predinfo predinfo_type_xentry__new__aliasvar__cycliccheck2_9 = {
  (unsigned char *)"entry_new_aliasvar_cycliccheck2",
  &predicate_type_xentry__new__aliasvar__cycliccheck2_9
};

extern Const struct predicate predicate_type_xentry__new__aliasvar__cycliccheck1_8;
static Const struct predinfo predinfo_type_xentry__new__aliasvar__cycliccheck1_8 = {
  (unsigned char *)"entry_new_aliasvar_cycliccheck1",
  &predicate_type_xentry__new__aliasvar__cycliccheck1_8
};

extern Const struct predicate predicate_type_xentry__new__aliasvar__cycliccheck11_8;
static Const struct predinfo predinfo_type_xentry__new__aliasvar__cycliccheck11_8 = {
  (unsigned char *)"entry_new_aliasvar_cycliccheck11",
  &predicate_type_xentry__new__aliasvar__cycliccheck11_8
};

extern Const struct predicate predicate_type_xentry__new__aliasvar__check_9;
static Const struct predinfo predinfo_type_xentry__new__aliasvar__check_9 = {
  (unsigned char *)"entry_new_aliasvar_check",
  &predicate_type_xentry__new__aliasvar__check_9
};

extern Const struct predicate predicate_type_xentry__new__aliasvar_14;
static Const struct predinfo predinfo_type_xentry__new__aliasvar_14 = {
  (unsigned char *)"entry_new_aliasvar",
  &predicate_type_xentry__new__aliasvar_14
};

extern Const struct predicate predicate_type_xentry__new__aliasvar1_16;
static Const struct predinfo predinfo_type_xentry__new__aliasvar1_16 = {
  (unsigned char *)"entry_new_aliasvar1",
  &predicate_type_xentry__new__aliasvar1_16
};

extern Const struct predicate predicate_type_xentry__indirect_3;
static Const struct predinfo predinfo_type_xentry__indirect_3 = {
  (unsigned char *)"entry_indirect",
  &predicate_type_xentry__indirect_3
};

extern Const struct predicate predicate_type_xclear__depgoals_2;
static Const struct predinfo predinfo_type_xclear__depgoals_2 = {
  (unsigned char *)"clear_depgoals",
  &predicate_type_xclear__depgoals_2
};

extern Const struct predicate predicate_type_xcheck__type__table__type_4;
static Const struct predinfo predinfo_type_xcheck__type__table__type_4 = {
  (unsigned char *)"check_type_table_type",
  &predicate_type_xcheck__type__table__type_4
};

extern Const struct predicate predicate_type_xcheck__type__table__clauses_2;
static Const struct predinfo predinfo_type_xcheck__type__table__clauses_2 = {
  (unsigned char *)"check_type_table_clauses",
  &predicate_type_xcheck__type__table__clauses_2
};

extern Const struct predicate predicate_type_xcheck__type__table__clauses1_4;
static Const struct predinfo predinfo_type_xcheck__type__table__clauses1_4 = {
  (unsigned char *)"check_type_table_clauses1",
  &predicate_type_xcheck__type__table__clauses1_4
};

extern Const struct predicate predicate_type_xcheck__type__table__clause_3;
static Const struct predinfo predinfo_type_xcheck__type__table__clause_3 = {
  (unsigned char *)"check_type_table_clause",
  &predicate_type_xcheck__type__table__clause_3
};

extern Const struct predicate predicate_type_xcheck__type__table__clause1_5;
static Const struct predinfo predinfo_type_xcheck__type__table__clause1_5 = {
  (unsigned char *)"check_type_table_clause1",
  &predicate_type_xcheck__type__table__clause1_5
};

extern Const struct predicate predicate_type_xcheck__type__table_1;
static Const struct predinfo predinfo_type_xcheck__type__table_1 = {
  (unsigned char *)"check_type_table",
  &predicate_type_xcheck__type__table_1
};

extern Const struct predicate predicate_type_xand__types__val_5;
static Const struct predinfo predinfo_type_xand__types__val_5 = {
  (unsigned char *)"and_types_val",
  &predicate_type_xand__types__val_5
};

extern Const struct predicate predicate_type_xand__types__val2_9;
static Const struct predinfo predinfo_type_xand__types__val2_9 = {
  (unsigned char *)"and_types_val2",
  &predicate_type_xand__types__val2_9
};

extern Const struct predicate predicate_type_xand__types__val1_6;
static Const struct predinfo predinfo_type_xand__types__val1_6 = {
  (unsigned char *)"and_types_val1",
  &predicate_type_xand__types__val1_6
};

extern Const struct predicate predicate_type_xand__types_5;
static Const struct predinfo predinfo_type_xand__types_5 = {
  (unsigned char *)"and_types",
  &predicate_type_xand__types_5
};

extern Const struct predicate predicate_type_xand__types_4;
static Const struct predinfo predinfo_type_xand__types_4 = {
  (unsigned char *)"and_types",
  &predicate_type_xand__types_4
};

extern Const struct predicate predicate_type_xand__types1_7;
static Const struct predinfo predinfo_type_xand__types1_7 = {
  (unsigned char *)"and_types1",
  &predicate_type_xand__types1_7
};

extern Const struct predicate predicate_type_xand__type__element__struct_14;
static Const struct predinfo predinfo_type_xand__type__element__struct_14 = {
  (unsigned char *)"and_type_element_struct",
  &predicate_type_xand__type__element__struct_14
};

extern Const struct predicate predicate_type_xand__type__element__struct1_13;
static Const struct predinfo predinfo_type_xand__type__element__struct1_13 = {
  (unsigned char *)"and_type_element_struct1",
  &predicate_type_xand__type__element__struct1_13
};

extern Const struct predicate predicate_type_xand__type__element__argslist_8;
static Const struct predinfo predinfo_type_xand__type__element__argslist_8 = {
  (unsigned char *)"and_type_element_argslist",
  &predicate_type_xand__type__element__argslist_8
};

extern Const struct predicate predicate_type_xand__type__element__args_8;
static Const struct predinfo predinfo_type_xand__type__element__args_8 = {
  (unsigned char *)"and_type_element_args",
  &predicate_type_xand__type__element__args_8
};

extern Const struct predicate predicate_type_xand__type__element_10;
static Const struct predinfo predinfo_type_xand__type__element_10 = {
  (unsigned char *)"and_type_element",
  &predicate_type_xand__type__element_10
};

extern Const struct predicate predicate_type_xadd__indirect__deps_11;
static Const struct predinfo predinfo_type_xadd__indirect__deps_11 = {
  (unsigned char *)"add_indirect_deps",
  &predicate_type_xadd__indirect__deps_11
};

extern Const struct predicate predicate_type_xadd__i__goals_3;
static Const struct predinfo predinfo_type_xadd__i__goals_3 = {
  (unsigned char *)"add_i_goals",
  &predicate_type_xadd__i__goals_3
};

extern Const struct predicate predicate_type_xadd__i__goal_3;
static Const struct predinfo predinfo_type_xadd__i__goal_3 = {
  (unsigned char *)"add_i_goal",
  &predicate_type_xadd__i__goal_3
};

extern Const struct predicate predicate_type_xadd__i__goal1_3;
static Const struct predinfo predinfo_type_xadd__i__goal1_3 = {
  (unsigned char *)"add_i_goal1",
  &predicate_type_xadd__i__goal1_3
};

extern Const struct predicate predicate_type_xadd__dep__goals_3;
static Const struct predinfo predinfo_type_xadd__dep__goals_3 = {
  (unsigned char *)"add_dep_goals",
  &predicate_type_xadd__dep__goals_3
};

extern Const struct predicate predicate_type_xadd__dep__goal_3;
static Const struct predinfo predinfo_type_xadd__dep__goal_3 = {
  (unsigned char *)"add_dep_goal",
  &predicate_type_xadd__dep__goal_3
};

extern Const struct predicate predicate_type_xadd__dep__goal1_3;
static Const struct predinfo predinfo_type_xadd__dep__goal1_3 = {
  (unsigned char *)"add_dep_goal1",
  &predicate_type_xadd__dep__goal1_3
};

extern Const struct predicate predicate_type_x_2C_2;
static Const struct predinfo predinfo_type_x_2C_2 = {
  (unsigned char *)",",
  &predicate_type_x_2C_2
};

static Const struct predinfo * Const preds_in_type[] = {
  &predinfo_type_xvalue2types__vector__arg_10,
  &predinfo_type_xvalue2types__functor__arg_10,
  &predinfo_type_xvalue2types_7,
  &predinfo_type_xvalue2types1_9,
  &predinfo_type_xtype2structtype_2,
  &predinfo_type_xtype2structtype1_3,
  &predinfo_type_xtype2list_2,
  &predinfo_type_xtype2list1_2,
  &predinfo_type_xtype2int_2,
  &predinfo_type_xtype2atom_2,
  &predinfo_type_xsplit__types__var__val_3,
  &predinfo_type_xset__types_13,
  &predinfo_type_xset__types_11,
  &predinfo_type_xset__types1_13,
  &predinfo_type_xset__struct__arg__types_4,
  &predinfo_type_xset__ru__args_4,
  &predinfo_type_xset__ru_3,
  &predinfo_type_xremove__types__deps_4,
  &predinfo_type_xremove__types__deps_3,
  &predinfo_type_xremove__type__deps_4,
  &predinfo_type_xremove__type__args_5,
  &predinfo_type_xor__types_3,
  &predinfo_type_xor__types2_6,
  &predinfo_type_xor__types1_3,
  &predinfo_type_xor__type__element__vmode_3,
  &predinfo_type_xor__type__element__struct_8,
  &predinfo_type_xor__type__element__struct1_7,
  &predinfo_type_xor__type__element__argslist_4,
  &predinfo_type_xor__type__element__args_4,
  &predinfo_type_xor__type__element_4,
  &predinfo_type_xmerge__ru_3,
  &predinfo_type_xmerge__loopgoals__filter_5,
  &predinfo_type_xmerge__goals__filter_3,
  &predinfo_type_xmerge__goals_3,
  &predinfo_type_xmerge__atomic_4,
  &predinfo_type_xmake__types__loopup_9,
  &predinfo_type_xmake__types__loopup1_9,
  &predinfo_type_xmake__types__loopdown_16,
  &predinfo_type_xmake__type__loopup__struct_10,
  &predinfo_type_xmake__type__loopup_9,
  &predinfo_type_xmake__type__loopdown__args_17,
  &predinfo_type_xmake__type__loopdown_16,
  &predinfo_type_xmake__indirect__unify_4,
  &predinfo_type_xmake__indirect__unify3_4,
  &predinfo_type_xmake__indirect__unify2_4,
  &predinfo_type_xmake__indirect__unify1_4,
  &predinfo_type_xlisttype__val__merge_3,
  &predinfo_type_xlisttype__val__merge1_3,
  &predinfo_type_xlisttype__val_3,
  &predinfo_type_xlisttype__val2_4,
  &predinfo_type_xlisttype__val1_4,
  &predinfo_type_xget__types_5,
  &predinfo_type_xget__struct__arg__types_3,
  &predinfo_type_xget__loopdeps_2,
  &predinfo_type_xget__loopdeps1_3,
  &predinfo_type_xget__arg__types_5,
  &predinfo_type_xentry__updated_10,
  &predinfo_type_xentry__new__aliasvar__gen_13,
  &predinfo_type_xentry__new__aliasvar__gen1_5,
  &predinfo_type_xentry__new__aliasvar__cycliccheck_10,
  &predinfo_type_xentry__new__aliasvar__cycliccheck2_9,
  &predinfo_type_xentry__new__aliasvar__cycliccheck1_8,
  &predinfo_type_xentry__new__aliasvar__cycliccheck11_8,
  &predinfo_type_xentry__new__aliasvar__check_9,
  &predinfo_type_xentry__new__aliasvar_14,
  &predinfo_type_xentry__new__aliasvar1_16,
  &predinfo_type_xentry__indirect_3,
  &predinfo_type_xclear__depgoals_2,
  &predinfo_type_xcheck__type__table__type_4,
  &predinfo_type_xcheck__type__table__clauses_2,
  &predinfo_type_xcheck__type__table__clauses1_4,
  &predinfo_type_xcheck__type__table__clause_3,
  &predinfo_type_xcheck__type__table__clause1_5,
  &predinfo_type_xcheck__type__table_1,
  &predinfo_type_xand__types__val_5,
  &predinfo_type_xand__types__val2_9,
  &predinfo_type_xand__types__val1_6,
  &predinfo_type_xand__types_5,
  &predinfo_type_xand__types_4,
  &predinfo_type_xand__types1_7,
  &predinfo_type_xand__type__element__struct_14,
  &predinfo_type_xand__type__element__struct1_13,
  &predinfo_type_xand__type__element__argslist_8,
  &predinfo_type_xand__type__element__args_8,
  &predinfo_type_xand__type__element_10,
  &predinfo_type_xadd__indirect__deps_11,
  &predinfo_type_xadd__i__goals_3,
  &predinfo_type_xadd__i__goal_3,
  &predinfo_type_xadd__i__goal1_3,
  &predinfo_type_xadd__dep__goals_3,
  &predinfo_type_xadd__dep__goal_3,
  &predinfo_type_xadd__dep__goal1_3,
  &predinfo_type_x_2C_2,
  0
};
extern Const struct predicate predicate_mode_xset__goal__modes_6;
static Const struct predinfo predinfo_mode_xset__goal__modes_6 = {
  (unsigned char *)"set_goal_modes",
  &predicate_mode_xset__goal__modes_6
};

extern Const struct predicate predicate_mode_xset__goal__modes1_8;
static Const struct predinfo predinfo_mode_xset__goal__modes1_8 = {
  (unsigned char *)"set_goal_modes1",
  &predicate_mode_xset__goal__modes1_8
};

extern Const struct predicate predicate_mode_xset__arg__mode_6;
static Const struct predinfo predinfo_mode_xset__arg__mode_6 = {
  (unsigned char *)"set_arg_mode",
  &predicate_mode_xset__arg__mode_6
};

extern Const struct predicate predicate_mode_xru2mode_2;
static Const struct predinfo predinfo_mode_xru2mode_2 = {
  (unsigned char *)"ru2mode",
  &predicate_mode_xru2mode_2
};

extern Const struct predicate predicate_mode_xreverse__ru_2;
static Const struct predinfo predinfo_mode_xreverse__ru_2 = {
  (unsigned char *)"reverse_ru",
  &predicate_mode_xreverse__ru_2
};

extern Const struct predicate predicate_mode_xreverse__mode_2;
static Const struct predinfo predinfo_mode_xreverse__mode_2 = {
  (unsigned char *)"reverse_mode",
  &predicate_mode_xreverse__mode_2
};

extern Const struct predicate predicate_mode_xmode2ru_2;
static Const struct predinfo predinfo_mode_xmode2ru_2 = {
  (unsigned char *)"mode2ru",
  &predicate_mode_xmode2ru_2
};

extern Const struct predicate predicate_mode_xmake__mode_4;
static Const struct predinfo predinfo_mode_xmake__mode_4 = {
  (unsigned char *)"make_mode",
  &predicate_mode_xmake__mode_4
};

extern Const struct predicate predicate_mode_xmake__mode1_2;
static Const struct predinfo predinfo_mode_xmake__mode1_2 = {
  (unsigned char *)"make_mode1",
  &predicate_mode_xmake__mode1_2
};

extern Const struct predicate predicate_mode_xget__mode__goals_7;
static Const struct predinfo predinfo_mode_xget__mode__goals_7 = {
  (unsigned char *)"get_mode_goals",
  &predicate_mode_xget__mode__goals_7
};

extern Const struct predicate predicate_mode_xget__mode__goals1_8;
static Const struct predinfo predinfo_mode_xget__mode__goals1_8 = {
  (unsigned char *)"get_mode_goals1",
  &predicate_mode_xget__mode__goals1_8
};

extern Const struct predicate predicate_mode_xget__mode__functor_8;
static Const struct predinfo predinfo_mode_xget__mode__functor_8 = {
  (unsigned char *)"get_mode_functor",
  &predicate_mode_xget__mode__functor_8
};

extern Const struct predicate predicate_mode_xget__mode__functor1_9;
static Const struct predinfo predinfo_mode_xget__mode__functor1_9 = {
  (unsigned char *)"get_mode_functor1",
  &predicate_mode_xget__mode__functor1_9
};

extern Const struct predicate predicate_mode_xget__mode__clause_6;
static Const struct predinfo predinfo_mode_xget__mode__clause_6 = {
  (unsigned char *)"get_mode_clause",
  &predicate_mode_xget__mode__clause_6
};

extern Const struct predicate predicate_mode_xget__mode_9;
static Const struct predinfo predinfo_mode_xget__mode_9 = {
  (unsigned char *)"get_mode",
  &predicate_mode_xget__mode_9
};

extern Const struct predicate predicate_mode_xdetermine__goal__mode_6;
static Const struct predinfo predinfo_mode_xdetermine__goal__mode_6 = {
  (unsigned char *)"determine_goal_mode",
  &predicate_mode_xdetermine__goal__mode_6
};

extern Const struct predicate predicate_mode_xdetermine__goal__mode1_8;
static Const struct predinfo predinfo_mode_xdetermine__goal__mode1_8 = {
  (unsigned char *)"determine_goal_mode1",
  &predicate_mode_xdetermine__goal__mode1_8
};

extern Const struct predicate predicate_mode_xdetermine__functor__mode_7;
static Const struct predinfo predinfo_mode_xdetermine__functor__mode_7 = {
  (unsigned char *)"determine_functor_mode",
  &predicate_mode_xdetermine__functor__mode_7
};

extern Const struct predicate predicate_mode_xdec__varcount_5;
static Const struct predinfo predinfo_mode_xdec__varcount_5 = {
  (unsigned char *)"dec_varcount",
  &predicate_mode_xdec__varcount_5
};

extern Const struct predicate predicate_mode_xdec__varcount1_5;
static Const struct predinfo predinfo_mode_xdec__varcount1_5 = {
  (unsigned char *)"dec_varcount1",
  &predicate_mode_xdec__varcount1_5
};

static Const struct predinfo * Const preds_in_mode[] = {
  &predinfo_mode_xset__goal__modes_6,
  &predinfo_mode_xset__goal__modes1_8,
  &predinfo_mode_xset__arg__mode_6,
  &predinfo_mode_xru2mode_2,
  &predinfo_mode_xreverse__ru_2,
  &predinfo_mode_xreverse__mode_2,
  &predinfo_mode_xmode2ru_2,
  &predinfo_mode_xmake__mode_4,
  &predinfo_mode_xmake__mode1_2,
  &predinfo_mode_xget__mode__goals_7,
  &predinfo_mode_xget__mode__goals1_8,
  &predinfo_mode_xget__mode__functor_8,
  &predinfo_mode_xget__mode__functor1_9,
  &predinfo_mode_xget__mode__clause_6,
  &predinfo_mode_xget__mode_9,
  &predinfo_mode_xdetermine__goal__mode_6,
  &predinfo_mode_xdetermine__goal__mode1_8,
  &predinfo_mode_xdetermine__functor__mode_7,
  &predinfo_mode_xdec__varcount_5,
  &predinfo_mode_xdec__varcount1_5,
  0
};
extern Const struct predicate predicate_functor_xinsert__arg__args_7;
static Const struct predinfo predinfo_functor_xinsert__arg__args_7 = {
  (unsigned char *)"insert_arg_args",
  &predicate_functor_xinsert__arg__args_7
};

extern Const struct predicate predicate_functor_xinsert__arg_4;
static Const struct predinfo predinfo_functor_xinsert__arg_4 = {
  (unsigned char *)"insert_arg",
  &predicate_functor_xinsert__arg_4
};

extern Const struct predicate predicate_functor_xget__arg__pos_3;
static Const struct predinfo predinfo_functor_xget__arg__pos_3 = {
  (unsigned char *)"get_arg_pos",
  &predicate_functor_xget__arg__pos_3
};

extern Const struct predicate predicate_functor_xget__arg__pos1_4;
static Const struct predinfo predinfo_functor_xget__arg__pos1_4 = {
  (unsigned char *)"get_arg_pos1",
  &predicate_functor_xget__arg__pos1_4
};

extern Const struct predicate predicate_functor_xdelete__arg__args_6;
static Const struct predinfo predinfo_functor_xdelete__arg__args_6 = {
  (unsigned char *)"delete_arg_args",
  &predicate_functor_xdelete__arg__args_6
};

extern Const struct predicate predicate_functor_xdelete__arg_3;
static Const struct predinfo predinfo_functor_xdelete__arg_3 = {
  (unsigned char *)"delete_arg",
  &predicate_functor_xdelete__arg_3
};

static Const struct predinfo * Const preds_in_functor[] = {
  &predinfo_functor_xinsert__arg__args_7,
  &predinfo_functor_xinsert__arg_4,
  &predinfo_functor_xget__arg__pos_3,
  &predinfo_functor_xget__arg__pos1_4,
  &predinfo_functor_xdelete__arg__args_6,
  &predinfo_functor_xdelete__arg_3,
  0
};
extern Const struct predicate predicate_unify__head__body_xset__head__type_6;
static Const struct predinfo predinfo_unify__head__body_xset__head__type_6 = {
  (unsigned char *)"set_head_type",
  &predicate_unify__head__body_xset__head__type_6
};

extern Const struct predicate predicate_unify__head__body_xset__head__mode__modules_6;
static Const struct predinfo predinfo_unify__head__body_xset__head__mode__modules_6 = {
  (unsigned char *)"set_head_mode_modules",
  &predicate_unify__head__body_xset__head__mode__modules_6
};

extern Const struct predicate predicate_unify__head__body_xset__head__mode__clauses_5;
static Const struct predinfo predinfo_unify__head__body_xset__head__mode__clauses_5 = {
  (unsigned char *)"set_head_mode_clauses",
  &predicate_unify__head__body_xset__head__mode__clauses_5
};

extern Const struct predicate predicate_unify__head__body_xset__head__mode__clauses1_7;
static Const struct predinfo predinfo_unify__head__body_xset__head__mode__clauses1_7 = {
  (unsigned char *)"set_head_mode_clauses1",
  &predicate_unify__head__body_xset__head__mode__clauses1_7
};

extern Const struct predicate predicate_unify__head__body_xset__head__mode_4;
static Const struct predinfo predinfo_unify__head__body_xset__head__mode_4 = {
  (unsigned char *)"set_head_mode",
  &predicate_unify__head__body_xset__head__mode_4
};

extern Const struct predicate predicate_unify__head__body_xmake__modules_2;
static Const struct predinfo predinfo_unify__head__body_xmake__modules_2 = {
  (unsigned char *)"make_modules",
  &predicate_unify__head__body_xmake__modules_2
};

extern Const struct predicate predicate_unify__head__body_xmake__head__body__list_2;
static Const struct predinfo predinfo_unify__head__body_xmake__head__body__list_2 = {
  (unsigned char *)"make_head_body_list",
  &predicate_unify__head__body_xmake__head__body__list_2
};

extern Const struct predicate predicate_unify__head__body_xmake__direct__type_2;
static Const struct predinfo predinfo_unify__head__body_xmake__direct__type_2 = {
  (unsigned char *)"make_direct_type",
  &predicate_unify__head__body_xmake__direct__type_2
};

extern Const struct predicate predicate_unify__head__body_xmake__direct__type1_3;
static Const struct predinfo predinfo_unify__head__body_xmake__direct__type1_3 = {
  (unsigned char *)"make_direct_type1",
  &predicate_unify__head__body_xmake__direct__type1_3
};

extern Const struct predicate predicate_unify__head__body_xmake__clauses__headlist__args_7;
static Const struct predinfo predinfo_unify__head__body_xmake__clauses__headlist__args_7 = {
  (unsigned char *)"make_clauses_headlist_args",
  &predicate_unify__head__body_xmake__clauses__headlist__args_7
};

extern Const struct predicate predicate_unify__head__body_xmake__clauses__headlist_9;
static Const struct predinfo predinfo_unify__head__body_xmake__clauses__headlist_9 = {
  (unsigned char *)"make_clauses_headlist",
  &predicate_unify__head__body_xmake__clauses__headlist_9
};

extern Const struct predicate predicate_unify__head__body_xmake__clauses_5;
static Const struct predinfo predinfo_unify__head__body_xmake__clauses_5 = {
  (unsigned char *)"make_clauses",
  &predicate_unify__head__body_xmake__clauses_5
};

extern Const struct predicate predicate_unify__head__body_xget__types__namelist_17;
static Const struct predinfo predinfo_unify__head__body_xget__types__namelist_17 = {
  (unsigned char *)"get_types_namelist",
  &predicate_unify__head__body_xget__types__namelist_17
};

extern Const struct predicate predicate_unify__head__body_xget__types__head_15;
static Const struct predinfo predinfo_unify__head__body_xget__types__head_15 = {
  (unsigned char *)"get_types_head",
  &predicate_unify__head__body_xget__types__head_15
};

extern Const struct predicate predicate_unify__head__body_xget__types__body_15;
static Const struct predinfo predinfo_unify__head__body_xget__types__body_15 = {
  (unsigned char *)"get_types_body",
  &predicate_unify__head__body_xget__types__body_15
};

extern Const struct predicate predicate_unify__head__body_xget__types_17;
static Const struct predinfo predinfo_unify__head__body_xget__types_17 = {
  (unsigned char *)"get_types",
  &predicate_unify__head__body_xget__types_17
};

extern Const struct predicate predicate_unify__head__body_xexpand__looped__goal_15;
static Const struct predinfo predinfo_unify__head__body_xexpand__looped__goal_15 = {
  (unsigned char *)"expand_looped_goal",
  &predicate_unify__head__body_xexpand__looped__goal_15
};

extern Const struct predicate predicate_unify__head__body_xcheck__shared__hbs_4;
static Const struct predinfo predinfo_unify__head__body_xcheck__shared__hbs_4 = {
  (unsigned char *)"check_shared_hbs",
  &predicate_unify__head__body_xcheck__shared__hbs_4
};

extern Const struct predicate predicate_unify__head__body_xcheck__shared__bodys_4;
static Const struct predinfo predinfo_unify__head__body_xcheck__shared__bodys_4 = {
  (unsigned char *)"check_shared_bodys",
  &predicate_unify__head__body_xcheck__shared__bodys_4
};

extern Const struct predicate predicate_unify__head__body_xcheck__shared__bodys3_5;
static Const struct predinfo predinfo_unify__head__body_xcheck__shared__bodys3_5 = {
  (unsigned char *)"check_shared_bodys3",
  &predicate_unify__head__body_xcheck__shared__bodys3_5
};

extern Const struct predicate predicate_unify__head__body_xcheck__shared__bodys2_5;
static Const struct predinfo predinfo_unify__head__body_xcheck__shared__bodys2_5 = {
  (unsigned char *)"check_shared_bodys2",
  &predicate_unify__head__body_xcheck__shared__bodys2_5
};

extern Const struct predicate predicate_unify__head__body_xcheck__shared__bodys1_4;
static Const struct predinfo predinfo_unify__head__body_xcheck__shared__bodys1_4 = {
  (unsigned char *)"check_shared_bodys1",
  &predicate_unify__head__body_xcheck__shared__bodys1_4
};

extern Const struct predicate predicate_unify__head__body_xcheck__shared_4;
static Const struct predinfo predinfo_unify__head__body_xcheck__shared_4 = {
  (unsigned char *)"check_shared",
  &predicate_unify__head__body_xcheck__shared_4
};

extern Const struct predicate predicate_unify__head__body_xcheck__only__vars_2;
static Const struct predinfo predinfo_unify__head__body_xcheck__only__vars_2 = {
  (unsigned char *)"check_only_vars",
  &predicate_unify__head__body_xcheck__only__vars_2
};

extern Const struct predicate predicate_unify__head__body_xcheck__only__vars1_3;
static Const struct predinfo predinfo_unify__head__body_xcheck__only__vars1_3 = {
  (unsigned char *)"check_only_vars1",
  &predicate_unify__head__body_xcheck__only__vars1_3
};

extern Const struct predicate predicate_unify__head__body_xcheck__body__search__modules_6;
static Const struct predinfo predinfo_unify__head__body_xcheck__body__search__modules_6 = {
  (unsigned char *)"check_body_search_modules",
  &predicate_unify__head__body_xcheck__body__search__modules_6
};

extern Const struct predicate predicate_unify__head__body_xcheck__body__search__clauses_9;
static Const struct predinfo predinfo_unify__head__body_xcheck__body__search__clauses_9 = {
  (unsigned char *)"check_body_search_clauses",
  &predicate_unify__head__body_xcheck__body__search__clauses_9
};

extern Const struct predicate predicate_unify__head__body_xcheck__body__search__bodys_10;
static Const struct predinfo predinfo_unify__head__body_xcheck__body__search__bodys_10 = {
  (unsigned char *)"check_body_search_bodys",
  &predicate_unify__head__body_xcheck__body__search__bodys_10
};

extern Const struct predicate predicate_unify__head__body_xcheck__body__search__body_10;
static Const struct predinfo predinfo_unify__head__body_xcheck__body__search__body_10 = {
  (unsigned char *)"check_body_search_body",
  &predicate_unify__head__body_xcheck__body__search__body_10
};

extern Const struct predicate predicate_unify__head__body_xcheck__body__search__body1_11;
static Const struct predinfo predinfo_unify__head__body_xcheck__body__search__body1_11 = {
  (unsigned char *)"check_body_search_body1",
  &predicate_unify__head__body_xcheck__body__search__body1_11
};

extern Const struct predicate predicate_unify__head__body_xcheck__body__modules_3;
static Const struct predinfo predinfo_unify__head__body_xcheck__body__modules_3 = {
  (unsigned char *)"check_body_modules",
  &predicate_unify__head__body_xcheck__body__modules_3
};

extern Const struct predicate predicate_unify__head__body_xcheck__body__clauses_4;
static Const struct predinfo predinfo_unify__head__body_xcheck__body__clauses_4 = {
  (unsigned char *)"check_body_clauses",
  &predicate_unify__head__body_xcheck__body__clauses_4
};

extern Const struct predicate predicate_unify__head__body_xcheck__body__bodylist__args_9;
static Const struct predinfo predinfo_unify__head__body_xcheck__body__bodylist__args_9 = {
  (unsigned char *)"check_body_bodylist_args",
  &predicate_unify__head__body_xcheck__body__bodylist__args_9
};

extern Const struct predicate predicate_unify__head__body_xapply__direct__value__head_9;
static Const struct predinfo predinfo_unify__head__body_xapply__direct__value__head_9 = {
  (unsigned char *)"apply_direct_value_head",
  &predicate_unify__head__body_xapply__direct__value__head_9
};

extern Const struct predicate predicate_unify__head__body_xapply__direct__value__clauses_7;
static Const struct predinfo predinfo_unify__head__body_xapply__direct__value__clauses_7 = {
  (unsigned char *)"apply_direct_value_clauses",
  &predicate_unify__head__body_xapply__direct__value__clauses_7
};

extern Const struct predicate predicate_unify__head__body_xapply__direct__value__clause_10;
static Const struct predinfo predinfo_unify__head__body_xapply__direct__value__clause_10 = {
  (unsigned char *)"apply_direct_value_clause",
  &predicate_unify__head__body_xapply__direct__value__clause_10
};

extern Const struct predicate predicate_unify__head__body_xapply__direct__value_7;
static Const struct predinfo predinfo_unify__head__body_xapply__direct__value_7 = {
  (unsigned char *)"apply_direct_value",
  &predicate_unify__head__body_xapply__direct__value_7
};

extern Const struct predicate predicate_unify__head__body_xadd__shared_7;
static Const struct predinfo predinfo_unify__head__body_xadd__shared_7 = {
  (unsigned char *)"add_shared",
  &predicate_unify__head__body_xadd__shared_7
};

static Const struct predinfo * Const preds_in_unify__head__body[] = {
  &predinfo_unify__head__body_xset__head__type_6,
  &predinfo_unify__head__body_xset__head__mode__modules_6,
  &predinfo_unify__head__body_xset__head__mode__clauses_5,
  &predinfo_unify__head__body_xset__head__mode__clauses1_7,
  &predinfo_unify__head__body_xset__head__mode_4,
  &predinfo_unify__head__body_xmake__modules_2,
  &predinfo_unify__head__body_xmake__head__body__list_2,
  &predinfo_unify__head__body_xmake__direct__type_2,
  &predinfo_unify__head__body_xmake__direct__type1_3,
  &predinfo_unify__head__body_xmake__clauses__headlist__args_7,
  &predinfo_unify__head__body_xmake__clauses__headlist_9,
  &predinfo_unify__head__body_xmake__clauses_5,
  &predinfo_unify__head__body_xget__types__namelist_17,
  &predinfo_unify__head__body_xget__types__head_15,
  &predinfo_unify__head__body_xget__types__body_15,
  &predinfo_unify__head__body_xget__types_17,
  &predinfo_unify__head__body_xexpand__looped__goal_15,
  &predinfo_unify__head__body_xcheck__shared__hbs_4,
  &predinfo_unify__head__body_xcheck__shared__bodys_4,
  &predinfo_unify__head__body_xcheck__shared__bodys3_5,
  &predinfo_unify__head__body_xcheck__shared__bodys2_5,
  &predinfo_unify__head__body_xcheck__shared__bodys1_4,
  &predinfo_unify__head__body_xcheck__shared_4,
  &predinfo_unify__head__body_xcheck__only__vars_2,
  &predinfo_unify__head__body_xcheck__only__vars1_3,
  &predinfo_unify__head__body_xcheck__body__search__modules_6,
  &predinfo_unify__head__body_xcheck__body__search__clauses_9,
  &predinfo_unify__head__body_xcheck__body__search__bodys_10,
  &predinfo_unify__head__body_xcheck__body__search__body_10,
  &predinfo_unify__head__body_xcheck__body__search__body1_11,
  &predinfo_unify__head__body_xcheck__body__modules_3,
  &predinfo_unify__head__body_xcheck__body__clauses_4,
  &predinfo_unify__head__body_xcheck__body__bodylist__args_9,
  &predinfo_unify__head__body_xapply__direct__value__head_9,
  &predinfo_unify__head__body_xapply__direct__value__clauses_7,
  &predinfo_unify__head__body_xapply__direct__value__clause_10,
  &predinfo_unify__head__body_xapply__direct__value_7,
  &predinfo_unify__head__body_xadd__shared_7,
  0
};
extern Const struct predicate predicate_loop_xupdate__lv__entry_6;
static Const struct predinfo predinfo_loop_xupdate__lv__entry_6 = {
  (unsigned char *)"update_lv_entry",
  &predicate_loop_xupdate__lv__entry_6
};

extern Const struct predicate predicate_loop_xmake__loopdep_3;
static Const struct predinfo predinfo_loop_xmake__loopdep_3 = {
  (unsigned char *)"make_loopdep",
  &predicate_loop_xmake__loopdep_3
};

extern Const struct predicate predicate_loop_xmake__loopdep1_4;
static Const struct predinfo predinfo_loop_xmake__loopdep1_4 = {
  (unsigned char *)"make_loopdep1",
  &predicate_loop_xmake__loopdep1_4
};

extern Const struct predicate predicate_loop_xget__lv__entry_5;
static Const struct predinfo predinfo_loop_xget__lv__entry_5 = {
  (unsigned char *)"get_lv_entry",
  &predicate_loop_xget__lv__entry_5
};

extern Const struct predicate predicate_loop_xget__lf__entry_5;
static Const struct predinfo predinfo_loop_xget__lf__entry_5 = {
  (unsigned char *)"get_lf_entry",
  &predicate_loop_xget__lf__entry_5
};

extern Const struct predicate predicate_loop_xget__goals__recursive__goal_7;
static Const struct predinfo predinfo_loop_xget__goals__recursive__goal_7 = {
  (unsigned char *)"get_goals_recursive_goal",
  &predicate_loop_xget__goals__recursive__goal_7
};

extern Const struct predicate predicate_loop_xget__goals__modules_4;
static Const struct predinfo predinfo_loop_xget__goals__modules_4 = {
  (unsigned char *)"get_goals_modules",
  &predicate_loop_xget__goals__modules_4
};

extern Const struct predicate predicate_loop_xget__goals__entry_6;
static Const struct predinfo predinfo_loop_xget__goals__entry_6 = {
  (unsigned char *)"get_goals_entry",
  &predicate_loop_xget__goals__entry_6
};

extern Const struct predicate predicate_loop_xget__goals__entry1_7;
static Const struct predinfo predinfo_loop_xget__goals__entry1_7 = {
  (unsigned char *)"get_goals_entry1",
  &predicate_loop_xget__goals__entry1_7
};

extern Const struct predicate predicate_loop_xget__goals__clauses_6;
static Const struct predinfo predinfo_loop_xget__goals__clauses_6 = {
  (unsigned char *)"get_goals_clauses",
  &predicate_loop_xget__goals__clauses_6
};

extern Const struct predicate predicate_loop_xget__goals__check__entry_5;
static Const struct predinfo predinfo_loop_xget__goals__check__entry_5 = {
  (unsigned char *)"get_goals_check_entry",
  &predicate_loop_xget__goals__check__entry_5
};

extern Const struct predicate predicate_loop_xget__goals__bodys_6;
static Const struct predinfo predinfo_loop_xget__goals__bodys_6 = {
  (unsigned char *)"get_goals_bodys",
  &predicate_loop_xget__goals__bodys_6
};

extern Const struct predicate predicate_loop_xget__goals__body_7;
static Const struct predinfo predinfo_loop_xget__goals__body_7 = {
  (unsigned char *)"get_goals_body",
  &predicate_loop_xget__goals__body_7
};

extern Const struct predicate predicate_loop_xget__goals_2;
static Const struct predinfo predinfo_loop_xget__goals_2 = {
  (unsigned char *)"get_goals",
  &predicate_loop_xget__goals_2
};

extern Const struct predicate predicate_loop_xdeps__loop__entry__predicate_9;
static Const struct predinfo predinfo_loop_xdeps__loop__entry__predicate_9 = {
  (unsigned char *)"deps_loop_entry_predicate",
  &predicate_loop_xdeps__loop__entry__predicate_9
};

extern Const struct predicate predicate_loop_xdeps__loop__entry__goals_11;
static Const struct predinfo predinfo_loop_xdeps__loop__entry__goals_11 = {
  (unsigned char *)"deps_loop_entry_goals",
  &predicate_loop_xdeps__loop__entry__goals_11
};

extern Const struct predicate predicate_loop_xdeps__loop__entry__goal_14;
static Const struct predinfo predinfo_loop_xdeps__loop__entry__goal_14 = {
  (unsigned char *)"deps_loop_entry_goal",
  &predicate_loop_xdeps__loop__entry__goal_14
};

extern Const struct predicate predicate_loop_xdeps__loop__entry__clauses_8;
static Const struct predinfo predinfo_loop_xdeps__loop__entry__clauses_8 = {
  (unsigned char *)"deps_loop_entry_clauses",
  &predicate_loop_xdeps__loop__entry__clauses_8
};

extern Const struct predicate predicate_loop_xdeps__loop__entry_4;
static Const struct predinfo predinfo_loop_xdeps__loop__entry_4 = {
  (unsigned char *)"deps_loop_entry",
  &predicate_loop_xdeps__loop__entry_4
};

extern Const struct predicate predicate_loop_xcollect__loop__clauses__modules_9;
static Const struct predinfo predinfo_loop_xcollect__loop__clauses__modules_9 = {
  (unsigned char *)"collect_loop_clauses_modules",
  &predicate_loop_xcollect__loop__clauses__modules_9
};

extern Const struct predicate predicate_loop_xcollect__loop__clauses__entry__bodys_5;
static Const struct predinfo predinfo_loop_xcollect__loop__clauses__entry__bodys_5 = {
  (unsigned char *)"collect_loop_clauses_entry_bodys",
  &predicate_loop_xcollect__loop__clauses__entry__bodys_5
};

extern Const struct predicate predicate_loop_xcollect__loop__clauses__clauses_10;
static Const struct predinfo predinfo_loop_xcollect__loop__clauses__clauses_10 = {
  (unsigned char *)"collect_loop_clauses_clauses",
  &predicate_loop_xcollect__loop__clauses__clauses_10
};

extern Const struct predicate predicate_loop_xcollect__loop__clauses__clauses1_12;
static Const struct predinfo predinfo_loop_xcollect__loop__clauses__clauses1_12 = {
  (unsigned char *)"collect_loop_clauses_clauses1",
  &predicate_loop_xcollect__loop__clauses__clauses1_12
};

extern Const struct predicate predicate_loop_xcollect__loop__clauses_4;
static Const struct predinfo predinfo_loop_xcollect__loop__clauses_4 = {
  (unsigned char *)"collect_loop_clauses",
  &predicate_loop_xcollect__loop__clauses_4
};

extern Const struct predicate predicate_loop_xcheck__within_3;
static Const struct predinfo predinfo_loop_xcheck__within_3 = {
  (unsigned char *)"check_within",
  &predicate_loop_xcheck__within_3
};

extern Const struct predicate predicate_loop_xcheck__var__within_3;
static Const struct predinfo predinfo_loop_xcheck__var__within_3 = {
  (unsigned char *)"check_var_within",
  &predicate_loop_xcheck__var__within_3
};

extern Const struct predicate predicate_loop_xcheck__loop__module_7;
static Const struct predinfo predinfo_loop_xcheck__loop__module_7 = {
  (unsigned char *)"check_loop_module",
  &predicate_loop_xcheck__loop__module_7
};

extern Const struct predicate predicate_loop_xcheck__loop__clauses_7;
static Const struct predinfo predinfo_loop_xcheck__loop__clauses_7 = {
  (unsigned char *)"check_loop_clauses",
  &predicate_loop_xcheck__loop__clauses_7
};

extern Const struct predicate predicate_loop_xcheck__loop__clauses1_9;
static Const struct predinfo predinfo_loop_xcheck__loop__clauses1_9 = {
  (unsigned char *)"check_loop_clauses1",
  &predicate_loop_xcheck__loop__clauses1_9
};

extern Const struct predicate predicate_loop_xcheck__loop__bodys_6;
static Const struct predinfo predinfo_loop_xcheck__loop__bodys_6 = {
  (unsigned char *)"check_loop_bodys",
  &predicate_loop_xcheck__loop__bodys_6
};

extern Const struct predicate predicate_loop_xcheck__loop__bodys1_8;
static Const struct predinfo predinfo_loop_xcheck__loop__bodys1_8 = {
  (unsigned char *)"check_loop_bodys1",
  &predicate_loop_xcheck__loop__bodys1_8
};

extern Const struct predicate predicate_loop_xcheck__loop__body_8;
static Const struct predinfo predinfo_loop_xcheck__loop__body_8 = {
  (unsigned char *)"check_loop_body",
  &predicate_loop_xcheck__loop__body_8
};

extern Const struct predicate predicate_loop_xcheck__loop__body1_5;
static Const struct predinfo predinfo_loop_xcheck__loop__body1_5 = {
  (unsigned char *)"check_loop_body1",
  &predicate_loop_xcheck__loop__body1_5
};

extern Const struct predicate predicate_loop_xcheck__loop_7;
static Const struct predinfo predinfo_loop_xcheck__loop_7 = {
  (unsigned char *)"check_loop",
  &predicate_loop_xcheck__loop_7
};

extern Const struct predicate predicate_loop_xcheck__loop1_7;
static Const struct predinfo predinfo_loop_xcheck__loop1_7 = {
  (unsigned char *)"check_loop1",
  &predicate_loop_xcheck__loop1_7
};

extern Const struct predicate predicate_loop_xcheck__ancestors_5;
static Const struct predinfo predinfo_loop_xcheck__ancestors_5 = {
  (unsigned char *)"check_ancestors",
  &predicate_loop_xcheck__ancestors_5
};

extern Const struct predicate predicate_loop_xcheck_2;
static Const struct predinfo predinfo_loop_xcheck_2 = {
  (unsigned char *)"check",
  &predicate_loop_xcheck_2
};

static Const struct predinfo * Const preds_in_loop[] = {
  &predinfo_loop_xupdate__lv__entry_6,
  &predinfo_loop_xmake__loopdep_3,
  &predinfo_loop_xmake__loopdep1_4,
  &predinfo_loop_xget__lv__entry_5,
  &predinfo_loop_xget__lf__entry_5,
  &predinfo_loop_xget__goals__recursive__goal_7,
  &predinfo_loop_xget__goals__modules_4,
  &predinfo_loop_xget__goals__entry_6,
  &predinfo_loop_xget__goals__entry1_7,
  &predinfo_loop_xget__goals__clauses_6,
  &predinfo_loop_xget__goals__check__entry_5,
  &predinfo_loop_xget__goals__bodys_6,
  &predinfo_loop_xget__goals__body_7,
  &predinfo_loop_xget__goals_2,
  &predinfo_loop_xdeps__loop__entry__predicate_9,
  &predinfo_loop_xdeps__loop__entry__goals_11,
  &predinfo_loop_xdeps__loop__entry__goal_14,
  &predinfo_loop_xdeps__loop__entry__clauses_8,
  &predinfo_loop_xdeps__loop__entry_4,
  &predinfo_loop_xcollect__loop__clauses__modules_9,
  &predinfo_loop_xcollect__loop__clauses__entry__bodys_5,
  &predinfo_loop_xcollect__loop__clauses__clauses_10,
  &predinfo_loop_xcollect__loop__clauses__clauses1_12,
  &predinfo_loop_xcollect__loop__clauses_4,
  &predinfo_loop_xcheck__within_3,
  &predinfo_loop_xcheck__var__within_3,
  &predinfo_loop_xcheck__loop__module_7,
  &predinfo_loop_xcheck__loop__clauses_7,
  &predinfo_loop_xcheck__loop__clauses1_9,
  &predinfo_loop_xcheck__loop__bodys_6,
  &predinfo_loop_xcheck__loop__bodys1_8,
  &predinfo_loop_xcheck__loop__body_8,
  &predinfo_loop_xcheck__loop__body1_5,
  &predinfo_loop_xcheck__loop_7,
  &predinfo_loop_xcheck__loop1_7,
  &predinfo_loop_xcheck__ancestors_5,
  &predinfo_loop_xcheck_2,
  0
};
extern Const struct predicate predicate_parse__uty_xupdate__goal_7;
static Const struct predinfo predinfo_parse__uty_xupdate__goal_7 = {
  (unsigned char *)"update_goal",
  &predicate_parse__uty_xupdate__goal_7
};

extern Const struct predicate predicate_parse__uty_xupdate__def__clauses_4;
static Const struct predinfo predinfo_parse__uty_xupdate__def__clauses_4 = {
  (unsigned char *)"update_def_clauses",
  &predicate_parse__uty_xupdate__def__clauses_4
};

extern Const struct predicate predicate_parse__uty_xupdate__def__clauses1_3;
static Const struct predinfo predinfo_parse__uty_xupdate__def__clauses1_3 = {
  (unsigned char *)"update_def_clauses1",
  &predicate_parse__uty_xupdate__def__clauses1_3
};

extern Const struct predicate predicate_parse__uty_xupdate__clause_5;
static Const struct predinfo predinfo_parse__uty_xupdate__clause_5 = {
  (unsigned char *)"update_clause",
  &predicate_parse__uty_xupdate__clause_5
};

extern Const struct predicate predicate_parse__uty_xset__cfrag_5;
static Const struct predinfo predinfo_parse__uty_xset__cfrag_5 = {
  (unsigned char *)"set_cfrag",
  &predicate_parse__uty_xset__cfrag_5
};

extern Const struct predicate predicate_parse__uty_xread__cfrag_4;
static Const struct predinfo predinfo_parse__uty_xread__cfrag_4 = {
  (unsigned char *)"read_cfrag",
  &predicate_parse__uty_xread__cfrag_4
};

extern Const struct predicate predicate_parse__uty_xinit__cfrags_2;
static Const struct predinfo predinfo_parse__uty_xinit__cfrags_2 = {
  (unsigned char *)"init_cfrags",
  &predicate_parse__uty_xinit__cfrags_2
};

extern Const struct predicate predicate_parse__uty_xinit__cfrags1_2;
static Const struct predinfo predinfo_parse__uty_xinit__cfrags1_2 = {
  (unsigned char *)"init_cfrags1",
  &predicate_parse__uty_xinit__cfrags1_2
};

extern Const struct predicate predicate_parse__uty_xget__var__from__struct__functor_4;
static Const struct predinfo predinfo_parse__uty_xget__var__from__struct__functor_4 = {
  (unsigned char *)"get_var_from_struct_functor",
  &predicate_parse__uty_xget__var__from__struct__functor_4
};

extern Const struct predicate predicate_parse__uty_xget__var__from__struct_3;
static Const struct predinfo predinfo_parse__uty_xget__var__from__struct_3 = {
  (unsigned char *)"get_var_from_struct",
  &predicate_parse__uty_xget__var__from__struct_3
};

extern Const struct predicate predicate_parse__uty_xget__var__from__struct_2;
static Const struct predinfo predinfo_parse__uty_xget__var__from__struct_2 = {
  (unsigned char *)"get_var_from_struct",
  &predicate_parse__uty_xget__var__from__struct_2
};

extern Const struct predicate predicate_parse__uty_xget__next__clause_6;
static Const struct predinfo predinfo_parse__uty_xget__next__clause_6 = {
  (unsigned char *)"get_next_clause",
  &predicate_parse__uty_xget__next__clause_6
};

extern Const struct predicate predicate_parse__uty_xget__next__clause1_8;
static Const struct predinfo predinfo_parse__uty_xget__next__clause1_8 = {
  (unsigned char *)"get_next_clause1",
  &predicate_parse__uty_xget__next__clause1_8
};

extern Const struct predicate predicate_parse__uty_xget__goal_6;
static Const struct predinfo predinfo_parse__uty_xget__goal_6 = {
  (unsigned char *)"get_goal",
  &predicate_parse__uty_xget__goal_6
};

extern Const struct predicate predicate_parse__uty_xget__def__clauses_5;
static Const struct predinfo predinfo_parse__uty_xget__def__clauses_5 = {
  (unsigned char *)"get_def_clauses",
  &predicate_parse__uty_xget__def__clauses_5
};

extern Const struct predicate predicate_parse__uty_xget__def__clauses1_6;
static Const struct predinfo predinfo_parse__uty_xget__def__clauses1_6 = {
  (unsigned char *)"get_def_clauses1",
  &predicate_parse__uty_xget__def__clauses1_6
};

extern Const struct predicate predicate_parse__uty_xget__clauses_3;
static Const struct predinfo predinfo_parse__uty_xget__clauses_3 = {
  (unsigned char *)"get_clauses",
  &predicate_parse__uty_xget__clauses_3
};

extern Const struct predicate predicate_parse__uty_xget__clause_4;
static Const struct predinfo predinfo_parse__uty_xget__clause_4 = {
  (unsigned char *)"get_clause",
  &predicate_parse__uty_xget__clause_4
};

extern Const struct predicate predicate_parse__uty_xencode__goal__pragma_4;
static Const struct predinfo predinfo_parse__uty_xencode__goal__pragma_4 = {
  (unsigned char *)"encode_goal_pragma",
  &predicate_parse__uty_xencode__goal__pragma_4
};

extern Const struct predicate predicate_parse__uty_xencode__goal__modulename_4;
static Const struct predinfo predinfo_parse__uty_xencode__goal__modulename_4 = {
  (unsigned char *)"encode_goal_modulename",
  &predicate_parse__uty_xencode__goal__modulename_4
};

extern Const struct predicate predicate_parse__uty_xencode__goal_4;
static Const struct predinfo predinfo_parse__uty_xencode__goal_4 = {
  (unsigned char *)"encode_goal",
  &predicate_parse__uty_xencode__goal_4
};

extern Const struct predicate predicate_parse__uty_xencode__goal_3;
static Const struct predinfo predinfo_parse__uty_xencode__goal_3 = {
  (unsigned char *)"encode_goal",
  &predicate_parse__uty_xencode__goal_3
};

extern Const struct predicate predicate_parse__uty_xdecode__goalcall_6;
static Const struct predinfo predinfo_parse__uty_xdecode__goalcall_6 = {
  (unsigned char *)"decode_goalcall",
  &predicate_parse__uty_xdecode__goalcall_6
};

extern Const struct predicate predicate_parse__uty_xdecode__goalcall_5;
static Const struct predinfo predinfo_parse__uty_xdecode__goalcall_5 = {
  (unsigned char *)"decode_goalcall",
  &predicate_parse__uty_xdecode__goalcall_5
};

extern Const struct predicate predicate_parse__uty_xdecode__goalcall1_3;
static Const struct predinfo predinfo_parse__uty_xdecode__goalcall1_3 = {
  (unsigned char *)"decode_goalcall1",
  &predicate_parse__uty_xdecode__goalcall1_3
};

extern Const struct predicate predicate_parse__uty_xdecode__goal_4;
static Const struct predinfo predinfo_parse__uty_xdecode__goal_4 = {
  (unsigned char *)"decode_goal",
  &predicate_parse__uty_xdecode__goal_4
};

extern Const struct predicate predicate_parse__uty_xdecode__goal_3;
static Const struct predinfo predinfo_parse__uty_xdecode__goal_3 = {
  (unsigned char *)"decode_goal",
  &predicate_parse__uty_xdecode__goal_3
};

extern Const struct predicate predicate_parse__uty_xdecode__goal1_5;
static Const struct predinfo predinfo_parse__uty_xdecode__goal1_5 = {
  (unsigned char *)"decode_goal1",
  &predicate_parse__uty_xdecode__goal1_5
};

static Const struct predinfo * Const preds_in_parse__uty[] = {
  &predinfo_parse__uty_xupdate__goal_7,
  &predinfo_parse__uty_xupdate__def__clauses_4,
  &predinfo_parse__uty_xupdate__def__clauses1_3,
  &predinfo_parse__uty_xupdate__clause_5,
  &predinfo_parse__uty_xset__cfrag_5,
  &predinfo_parse__uty_xread__cfrag_4,
  &predinfo_parse__uty_xinit__cfrags_2,
  &predinfo_parse__uty_xinit__cfrags1_2,
  &predinfo_parse__uty_xget__var__from__struct__functor_4,
  &predinfo_parse__uty_xget__var__from__struct_3,
  &predinfo_parse__uty_xget__var__from__struct_2,
  &predinfo_parse__uty_xget__next__clause_6,
  &predinfo_parse__uty_xget__next__clause1_8,
  &predinfo_parse__uty_xget__goal_6,
  &predinfo_parse__uty_xget__def__clauses_5,
  &predinfo_parse__uty_xget__def__clauses1_6,
  &predinfo_parse__uty_xget__clauses_3,
  &predinfo_parse__uty_xget__clause_4,
  &predinfo_parse__uty_xencode__goal__pragma_4,
  &predinfo_parse__uty_xencode__goal__modulename_4,
  &predinfo_parse__uty_xencode__goal_4,
  &predinfo_parse__uty_xencode__goal_3,
  &predinfo_parse__uty_xdecode__goalcall_6,
  &predinfo_parse__uty_xdecode__goalcall_5,
  &predinfo_parse__uty_xdecode__goalcall1_3,
  &predinfo_parse__uty_xdecode__goal_4,
  &predinfo_parse__uty_xdecode__goal_3,
  &predinfo_parse__uty_xdecode__goal1_5,
  0
};
extern Const struct predicate predicate_list_xsplit__nth_4;
static Const struct predinfo predinfo_list_xsplit__nth_4 = {
  (unsigned char *)"split_nth",
  &predicate_list_xsplit__nth_4
};

extern Const struct predicate predicate_list_xsort__int__up_2;
static Const struct predinfo predinfo_list_xsort__int__up_2 = {
  (unsigned char *)"sort_int_up",
  &predicate_list_xsort__int__up_2
};

extern Const struct predicate predicate_list_xsort__int__split_4;
static Const struct predinfo predinfo_list_xsort__int__split_4 = {
  (unsigned char *)"sort_int_split",
  &predicate_list_xsort__int__split_4
};

extern Const struct predicate predicate_list_xor__unique_3;
static Const struct predinfo predinfo_list_xor__unique_3 = {
  (unsigned char *)"or_unique",
  &predicate_list_xor__unique_3
};

extern Const struct predicate predicate_list_xnth__element_3;
static Const struct predinfo predinfo_list_xnth__element_3 = {
  (unsigned char *)"nth_element",
  &predicate_list_xnth__element_3
};

extern Const struct predicate predicate_list_xmake__unique_2;
static Const struct predinfo predinfo_list_xmake__unique_2 = {
  (unsigned char *)"make_unique",
  &predicate_list_xmake__unique_2
};

extern Const struct predicate predicate_list_xmake__unique1_3;
static Const struct predinfo predinfo_list_xmake__unique1_3 = {
  (unsigned char *)"make_unique1",
  &predicate_list_xmake__unique1_3
};

extern Const struct predicate predicate_list_xinsert__nth__element_4;
static Const struct predinfo predinfo_list_xinsert__nth__element_4 = {
  (unsigned char *)"insert_nth_element",
  &predicate_list_xinsert__nth__element_4
};

extern Const struct predicate predicate_list_xentry__unique__data_3;
static Const struct predinfo predinfo_list_xentry__unique__data_3 = {
  (unsigned char *)"entry_unique_data",
  &predicate_list_xentry__unique__data_3
};

extern Const struct predicate predicate_list_xdelete__incomplete__element__match__args_4;
static Const struct predinfo predinfo_list_xdelete__incomplete__element__match__args_4 = {
  (unsigned char *)"delete_incomplete_element_match_args",
  &predicate_list_xdelete__incomplete__element__match__args_4
};

extern Const struct predicate predicate_list_xdelete__incomplete__element__match__args1_5;
static Const struct predinfo predinfo_list_xdelete__incomplete__element__match__args1_5 = {
  (unsigned char *)"delete_incomplete_element_match_args1",
  &predicate_list_xdelete__incomplete__element__match__args1_5
};

extern Const struct predicate predicate_list_xdelete__incomplete__element__match_3;
static Const struct predinfo predinfo_list_xdelete__incomplete__element__match_3 = {
  (unsigned char *)"delete_incomplete_element_match",
  &predicate_list_xdelete__incomplete__element__match_3
};

extern Const struct predicate predicate_list_xdelete__incomplete__element_3;
static Const struct predinfo predinfo_list_xdelete__incomplete__element_3 = {
  (unsigned char *)"delete_incomplete_element",
  &predicate_list_xdelete__incomplete__element_3
};

extern Const struct predicate predicate_list_xdelete__incomplete__element1_5;
static Const struct predinfo predinfo_list_xdelete__incomplete__element1_5 = {
  (unsigned char *)"delete_incomplete_element1",
  &predicate_list_xdelete__incomplete__element1_5
};

extern Const struct predicate predicate_list_xdelete__elements_3;
static Const struct predinfo predinfo_list_xdelete__elements_3 = {
  (unsigned char *)"delete_elements",
  &predicate_list_xdelete__elements_3
};

extern Const struct predicate predicate_list_xdelete__element_3;
static Const struct predinfo predinfo_list_xdelete__element_3 = {
  (unsigned char *)"delete_element",
  &predicate_list_xdelete__element_3
};

extern Const struct predicate predicate_list_xcount__element_2;
static Const struct predinfo predinfo_list_xcount__element_2 = {
  (unsigned char *)"count_element",
  &predicate_list_xcount__element_2
};

extern Const struct predicate predicate_list_xcount__element1_3;
static Const struct predinfo predinfo_list_xcount__element1_3 = {
  (unsigned char *)"count_element1",
  &predicate_list_xcount__element1_3
};

extern Const struct predicate predicate_list_xcheck__subset_3;
static Const struct predinfo predinfo_list_xcheck__subset_3 = {
  (unsigned char *)"check_subset",
  &predicate_list_xcheck__subset_3
};

extern Const struct predicate predicate_list_xcheck__subset1_4;
static Const struct predinfo predinfo_list_xcheck__subset1_4 = {
  (unsigned char *)"check_subset1",
  &predicate_list_xcheck__subset1_4
};

extern Const struct predicate predicate_list_xcheck__include_3;
static Const struct predinfo predinfo_list_xcheck__include_3 = {
  (unsigned char *)"check_include",
  &predicate_list_xcheck__include_3
};

extern Const struct predicate predicate_list_xappend_3;
static Const struct predinfo predinfo_list_xappend_3 = {
  (unsigned char *)"append",
  &predicate_list_xappend_3
};

extern Const struct predicate predicate_list_xand__unique_3;
static Const struct predinfo predinfo_list_xand__unique_3 = {
  (unsigned char *)"and_unique",
  &predicate_list_xand__unique_3
};

extern Const struct predicate predicate_list_xand__unique1_4;
static Const struct predinfo predinfo_list_xand__unique1_4 = {
  (unsigned char *)"and_unique1",
  &predicate_list_xand__unique1_4
};

static Const struct predinfo * Const preds_in_list[] = {
  &predinfo_list_xsplit__nth_4,
  &predinfo_list_xsort__int__up_2,
  &predinfo_list_xsort__int__split_4,
  &predinfo_list_xor__unique_3,
  &predinfo_list_xnth__element_3,
  &predinfo_list_xmake__unique_2,
  &predinfo_list_xmake__unique1_3,
  &predinfo_list_xinsert__nth__element_4,
  &predinfo_list_xentry__unique__data_3,
  &predinfo_list_xdelete__incomplete__element__match__args_4,
  &predinfo_list_xdelete__incomplete__element__match__args1_5,
  &predinfo_list_xdelete__incomplete__element__match_3,
  &predinfo_list_xdelete__incomplete__element_3,
  &predinfo_list_xdelete__incomplete__element1_5,
  &predinfo_list_xdelete__elements_3,
  &predinfo_list_xdelete__element_3,
  &predinfo_list_xcount__element_2,
  &predinfo_list_xcount__element1_3,
  &predinfo_list_xcheck__subset_3,
  &predinfo_list_xcheck__subset1_4,
  &predinfo_list_xcheck__include_3,
  &predinfo_list_xappend_3,
  &predinfo_list_xand__unique_3,
  &predinfo_list_xand__unique1_4,
  0
};
extern Const struct predicate predicate_uty_xnew__functor__init_4;
static Const struct predinfo predinfo_uty_xnew__functor__init_4 = {
  (unsigned char *)"new_functor_init",
  &predicate_uty_xnew__functor__init_4
};

extern Const struct predicate predicate_uty_xnew__functor__init1_4;
static Const struct predinfo predinfo_uty_xnew__functor__init1_4 = {
  (unsigned char *)"new_functor_init1",
  &predicate_uty_xnew__functor__init1_4
};

extern Const struct predicate predicate_uty_xmax_3;
static Const struct predinfo predinfo_uty_xmax_3 = {
  (unsigned char *)"max",
  &predicate_uty_xmax_3
};

extern Const struct predicate predicate_uty_xcreate__functor_3;
static Const struct predinfo predinfo_uty_xcreate__functor_3 = {
  (unsigned char *)"create_functor",
  &predicate_uty_xcreate__functor_3
};

extern Const struct predicate predicate_uty_xcreate__functor1_4;
static Const struct predinfo predinfo_uty_xcreate__functor1_4 = {
  (unsigned char *)"create_functor1",
  &predicate_uty_xcreate__functor1_4
};

static Const struct predinfo * Const preds_in_uty[] = {
  &predinfo_uty_xnew__functor__init_4,
  &predinfo_uty_xnew__functor__init1_4,
  &predinfo_uty_xmax_3,
  &predinfo_uty_xcreate__functor_3,
  &predinfo_uty_xcreate__functor1_4,
  0
};
extern Const struct predicate predicate_converter_xto__analyze__modules_3;
static Const struct predinfo predinfo_converter_xto__analyze__modules_3 = {
  (unsigned char *)"to_analyze_modules",
  &predicate_converter_xto__analyze__modules_3
};

extern Const struct predicate predicate_converter_xto__analyze__clauses_3;
static Const struct predinfo predinfo_converter_xto__analyze__clauses_3 = {
  (unsigned char *)"to_analyze_clauses",
  &predicate_converter_xto__analyze__clauses_3
};

extern Const struct predicate predicate_converter_xto__analyze__clause_3;
static Const struct predinfo predinfo_converter_xto__analyze__clause_3 = {
  (unsigned char *)"to_analyze_clause",
  &predicate_converter_xto__analyze__clause_3
};

extern Const struct predicate predicate_converter_xto__analyze_3;
static Const struct predinfo predinfo_converter_xto__analyze_3 = {
  (unsigned char *)"to_analyze",
  &predicate_converter_xto__analyze_3
};

extern Const struct predicate predicate_converter_xinit__varcount_3;
static Const struct predinfo predinfo_converter_xinit__varcount_3 = {
  (unsigned char *)"init_varcount",
  &predicate_converter_xinit__varcount_3
};

extern Const struct predicate predicate_converter_xinit__varcount1_3;
static Const struct predinfo predinfo_converter_xinit__varcount1_3 = {
  (unsigned char *)"init_varcount1",
  &predicate_converter_xinit__varcount1_3
};

extern Const struct predicate predicate_converter_xinit__headvar__head_4;
static Const struct predinfo predinfo_converter_xinit__headvar__head_4 = {
  (unsigned char *)"init_headvar_head",
  &predicate_converter_xinit__headvar__head_4
};

extern Const struct predicate predicate_converter_xinit__headvar__head1_5;
static Const struct predinfo predinfo_converter_xinit__headvar__head1_5 = {
  (unsigned char *)"init_headvar_head1",
  &predicate_converter_xinit__headvar__head1_5
};

extern Const struct predicate predicate_converter_xinit__headvar__guard_4;
static Const struct predinfo predinfo_converter_xinit__headvar__guard_4 = {
  (unsigned char *)"init_headvar_guard",
  &predicate_converter_xinit__headvar__guard_4
};

extern Const struct predicate predicate_converter_xinit__headvar__guard2__functor_6;
static Const struct predinfo predinfo_converter_xinit__headvar__guard2__functor_6 = {
  (unsigned char *)"init_headvar_guard2_functor",
  &predicate_converter_xinit__headvar__guard2__functor_6
};

extern Const struct predicate predicate_converter_xinit__headvar__guard2_5;
static Const struct predinfo predinfo_converter_xinit__headvar__guard2_5 = {
  (unsigned char *)"init_headvar_guard2",
  &predicate_converter_xinit__headvar__guard2_5
};

extern Const struct predicate predicate_converter_xinit__headvar__guard1_6;
static Const struct predinfo predinfo_converter_xinit__headvar__guard1_6 = {
  (unsigned char *)"init_headvar_guard1",
  &predicate_converter_xinit__headvar__guard1_6
};

extern Const struct predicate predicate_converter_xinit__headvar_4;
static Const struct predinfo predinfo_converter_xinit__headvar_4 = {
  (unsigned char *)"init_headvar",
  &predicate_converter_xinit__headvar_4
};

extern Const struct predicate predicate_converter_xget__varnummax__goallist_8;
static Const struct predinfo predinfo_converter_xget__varnummax__goallist_8 = {
  (unsigned char *)"get_varnummax_goallist",
  &predicate_converter_xget__varnummax__goallist_8
};

extern Const struct predicate predicate_converter_xget__varnummax__goal_8;
static Const struct predinfo predinfo_converter_xget__varnummax__goal_8 = {
  (unsigned char *)"get_varnummax_goal",
  &predicate_converter_xget__varnummax__goal_8
};

extern Const struct predicate predicate_converter_xget__varnummax__functor_9;
static Const struct predinfo predinfo_converter_xget__varnummax__functor_9 = {
  (unsigned char *)"get_varnummax_functor",
  &predicate_converter_xget__varnummax__functor_9
};

extern Const struct predicate predicate_converter_xget__varnummax__arg_8;
static Const struct predinfo predinfo_converter_xget__varnummax__arg_8 = {
  (unsigned char *)"get_varnummax_arg",
  &predicate_converter_xget__varnummax__arg_8
};

extern Const struct predicate predicate_converter_xfrom__analyze__modules_2;
static Const struct predinfo predinfo_converter_xfrom__analyze__modules_2 = {
  (unsigned char *)"from_analyze_modules",
  &predicate_converter_xfrom__analyze__modules_2
};

extern Const struct predicate predicate_converter_xfrom__analyze__goals_3;
static Const struct predinfo predinfo_converter_xfrom__analyze__goals_3 = {
  (unsigned char *)"from_analyze_goals",
  &predicate_converter_xfrom__analyze__goals_3
};

extern Const struct predicate predicate_converter_xfrom__analyze__goals1_5;
static Const struct predinfo predinfo_converter_xfrom__analyze__goals1_5 = {
  (unsigned char *)"from_analyze_goals1",
  &predicate_converter_xfrom__analyze__goals1_5
};

extern Const struct predicate predicate_converter_xfrom__analyze__goal__pragma_3;
static Const struct predinfo predinfo_converter_xfrom__analyze__goal__pragma_3 = {
  (unsigned char *)"from_analyze_goal_pragma",
  &predicate_converter_xfrom__analyze__goal__pragma_3
};

extern Const struct predicate predicate_converter_xfrom__analyze__goal__modulename_4;
static Const struct predinfo predinfo_converter_xfrom__analyze__goal__modulename_4 = {
  (unsigned char *)"from_analyze_goal_modulename",
  &predicate_converter_xfrom__analyze__goal__modulename_4
};

extern Const struct predicate predicate_converter_xfrom__analyze__goal_3;
static Const struct predinfo predinfo_converter_xfrom__analyze__goal_3 = {
  (unsigned char *)"from_analyze_goal",
  &predicate_converter_xfrom__analyze__goal_3
};

extern Const struct predicate predicate_converter_xfrom__analyze__functor_3;
static Const struct predinfo predinfo_converter_xfrom__analyze__functor_3 = {
  (unsigned char *)"from_analyze_functor",
  &predicate_converter_xfrom__analyze__functor_3
};

extern Const struct predicate predicate_converter_xfrom__analyze__clauses_4;
static Const struct predinfo predinfo_converter_xfrom__analyze__clauses_4 = {
  (unsigned char *)"from_analyze_clauses",
  &predicate_converter_xfrom__analyze__clauses_4
};

extern Const struct predicate predicate_converter_xfrom__analyze__clause_2;
static Const struct predinfo predinfo_converter_xfrom__analyze__clause_2 = {
  (unsigned char *)"from_analyze_clause",
  &predicate_converter_xfrom__analyze__clause_2
};

extern Const struct predicate predicate_converter_xfrom__analyze__args_4;
static Const struct predinfo predinfo_converter_xfrom__analyze__args_4 = {
  (unsigned char *)"from_analyze_args",
  &predicate_converter_xfrom__analyze__args_4
};

extern Const struct predicate predicate_converter_xfrom__analyze_2;
static Const struct predinfo predinfo_converter_xfrom__analyze_2 = {
  (unsigned char *)"from_analyze",
  &predicate_converter_xfrom__analyze_2
};

extern Const struct predicate predicate_converter_xcount__variables_8;
static Const struct predinfo predinfo_converter_xcount__variables_8 = {
  (unsigned char *)"count_variables",
  &predicate_converter_xcount__variables_8
};

static Const struct predinfo * Const preds_in_converter[] = {
  &predinfo_converter_xto__analyze__modules_3,
  &predinfo_converter_xto__analyze__clauses_3,
  &predinfo_converter_xto__analyze__clause_3,
  &predinfo_converter_xto__analyze_3,
  &predinfo_converter_xinit__varcount_3,
  &predinfo_converter_xinit__varcount1_3,
  &predinfo_converter_xinit__headvar__head_4,
  &predinfo_converter_xinit__headvar__head1_5,
  &predinfo_converter_xinit__headvar__guard_4,
  &predinfo_converter_xinit__headvar__guard2__functor_6,
  &predinfo_converter_xinit__headvar__guard2_5,
  &predinfo_converter_xinit__headvar__guard1_6,
  &predinfo_converter_xinit__headvar_4,
  &predinfo_converter_xget__varnummax__goallist_8,
  &predinfo_converter_xget__varnummax__goal_8,
  &predinfo_converter_xget__varnummax__functor_9,
  &predinfo_converter_xget__varnummax__arg_8,
  &predinfo_converter_xfrom__analyze__modules_2,
  &predinfo_converter_xfrom__analyze__goals_3,
  &predinfo_converter_xfrom__analyze__goals1_5,
  &predinfo_converter_xfrom__analyze__goal__pragma_3,
  &predinfo_converter_xfrom__analyze__goal__modulename_4,
  &predinfo_converter_xfrom__analyze__goal_3,
  &predinfo_converter_xfrom__analyze__functor_3,
  &predinfo_converter_xfrom__analyze__clauses_4,
  &predinfo_converter_xfrom__analyze__clause_2,
  &predinfo_converter_xfrom__analyze__args_4,
  &predinfo_converter_xfrom__analyze_2,
  &predinfo_converter_xcount__variables_8,
  0
};
extern Const struct predicate predicate_print_xtype__table_2;
static Const struct predinfo predinfo_print_xtype__table_2 = {
  (unsigned char *)"type_table",
  &predicate_print_xtype__table_2
};

extern Const struct predicate predicate_print_xtype__modules_2;
static Const struct predinfo predinfo_print_xtype__modules_2 = {
  (unsigned char *)"type_modules",
  &predicate_print_xtype__modules_2
};

extern Const struct predicate predicate_print_xtype__clauses_2;
static Const struct predinfo predinfo_print_xtype__clauses_2 = {
  (unsigned char *)"type_clauses",
  &predicate_print_xtype__clauses_2
};

extern Const struct predicate predicate_print_xtype__clauses1_4;
static Const struct predinfo predinfo_print_xtype__clauses1_4 = {
  (unsigned char *)"type_clauses1",
  &predicate_print_xtype__clauses1_4
};

extern Const struct predicate predicate_print_xtype__clause_3;
static Const struct predinfo predinfo_print_xtype__clause_3 = {
  (unsigned char *)"type_clause",
  &predicate_print_xtype__clause_3
};

extern Const struct predicate predicate_print_xtype__clause1_4;
static Const struct predinfo predinfo_print_xtype__clause1_4 = {
  (unsigned char *)"type_clause1",
  &predicate_print_xtype__clause1_4
};

extern Const struct predicate predicate_print_xtermn_1;
static Const struct predinfo predinfo_print_xtermn_1 = {
  (unsigned char *)"termn",
  &predicate_print_xtermn_1
};

extern Const struct predicate predicate_print_xterm__vector__arg_3;
static Const struct predinfo predinfo_print_xterm__vector__arg_3 = {
  (unsigned char *)"term_vector_arg",
  &predicate_print_xterm__vector__arg_3
};

extern Const struct predicate predicate_print_xterm__arg_3;
static Const struct predinfo predinfo_print_xterm__arg_3 = {
  (unsigned char *)"term_arg",
  &predicate_print_xterm__arg_3
};

extern Const struct predicate predicate_print_xterm_1;
static Const struct predinfo predinfo_print_xterm_1 = {
  (unsigned char *)"term",
  &predicate_print_xterm_1
};

extern Const struct predicate predicate_print_xterm2_1;
static Const struct predinfo predinfo_print_xterm2_1 = {
  (unsigned char *)"term2",
  &predicate_print_xterm2_1
};

extern Const struct predicate predicate_print_xterm1_2;
static Const struct predinfo predinfo_print_xterm1_2 = {
  (unsigned char *)"term1",
  &predicate_print_xterm1_2
};

extern Const struct predicate predicate_print_xprogram__modules_1;
static Const struct predinfo predinfo_print_xprogram__modules_1 = {
  (unsigned char *)"program_modules",
  &predicate_print_xprogram__modules_1
};

extern Const struct predicate predicate_print_xprogram__goals_1;
static Const struct predinfo predinfo_print_xprogram__goals_1 = {
  (unsigned char *)"program_goals",
  &predicate_print_xprogram__goals_1
};

extern Const struct predicate predicate_print_xprogram__clauses_1;
static Const struct predinfo predinfo_print_xprogram__clauses_1 = {
  (unsigned char *)"program_clauses",
  &predicate_print_xprogram__clauses_1
};

extern Const struct predicate predicate_print_xprogram__clause_1;
static Const struct predinfo predinfo_print_xprogram__clause_1 = {
  (unsigned char *)"program_clause",
  &predicate_print_xprogram__clause_1
};

extern Const struct predicate predicate_print_xprogram_1;
static Const struct predinfo predinfo_print_xprogram_1 = {
  (unsigned char *)"program",
  &predicate_print_xprogram_1
};

extern Const struct predicate predicate_print_xmodules__a_2;
static Const struct predinfo predinfo_print_xmodules__a_2 = {
  (unsigned char *)"modules_a",
  &predicate_print_xmodules__a_2
};

extern Const struct predicate predicate_print_xmodules_2;
static Const struct predinfo predinfo_print_xmodules_2 = {
  (unsigned char *)"modules",
  &predicate_print_xmodules_2
};

extern Const struct predicate predicate_print_xmodule__split__stdout_2;
static Const struct predinfo predinfo_print_xmodule__split__stdout_2 = {
  (unsigned char *)"module_split_stdout",
  &predicate_print_xmodule__split__stdout_2
};

extern Const struct predicate predicate_print_xmodule__split__modules_3;
static Const struct predinfo predinfo_print_xmodule__split__modules_3 = {
  (unsigned char *)"module_split_modules",
  &predicate_print_xmodule__split__modules_3
};

extern Const struct predicate predicate_print_xmodule__split__clauses_3;
static Const struct predinfo predinfo_print_xmodule__split__clauses_3 = {
  (unsigned char *)"module_split_clauses",
  &predicate_print_xmodule__split__clauses_3
};

extern Const struct predicate predicate_print_xmodule__split_1;
static Const struct predinfo predinfo_print_xmodule__split_1 = {
  (unsigned char *)"module_split",
  &predicate_print_xmodule__split_1
};

extern Const struct predicate predicate_print_xlist_2;
static Const struct predinfo predinfo_print_xlist_2 = {
  (unsigned char *)"list",
  &predicate_print_xlist_2
};

extern Const struct predicate predicate_print_xlist_1;
static Const struct predinfo predinfo_print_xlist_1 = {
  (unsigned char *)"list",
  &predicate_print_xlist_1
};

extern Const struct predicate predicate_print_xheadbody__table_2;
static Const struct predinfo predinfo_print_xheadbody__table_2 = {
  (unsigned char *)"headbody_table",
  &predicate_print_xheadbody__table_2
};

extern Const struct predicate predicate_print_xheadbody__modules_2;
static Const struct predinfo predinfo_print_xheadbody__modules_2 = {
  (unsigned char *)"headbody_modules",
  &predicate_print_xheadbody__modules_2
};

extern Const struct predicate predicate_print_xheadbody__clauses_2;
static Const struct predinfo predinfo_print_xheadbody__clauses_2 = {
  (unsigned char *)"headbody_clauses",
  &predicate_print_xheadbody__clauses_2
};

extern Const struct predicate predicate_print_xguards__a_2;
static Const struct predinfo predinfo_print_xguards__a_2 = {
  (unsigned char *)"guards_a",
  &predicate_print_xguards__a_2
};

extern Const struct predicate predicate_print_xguards__a1_4;
static Const struct predinfo predinfo_print_xguards__a1_4 = {
  (unsigned char *)"guards_a1",
  &predicate_print_xguards__a1_4
};

extern Const struct predicate predicate_print_xguards_2;
static Const struct predinfo predinfo_print_xguards_2 = {
  (unsigned char *)"guards",
  &predicate_print_xguards_2
};

extern Const struct predicate predicate_print_xguards1_2;
static Const struct predinfo predinfo_print_xguards1_2 = {
  (unsigned char *)"guards1",
  &predicate_print_xguards1_2
};

extern Const struct predicate predicate_print_xgoal_2;
static Const struct predinfo predinfo_print_xgoal_2 = {
  (unsigned char *)"goal",
  &predicate_print_xgoal_2
};

extern Const struct predicate predicate_print_xdeps__modules_1;
static Const struct predinfo predinfo_print_xdeps__modules_1 = {
  (unsigned char *)"deps_modules",
  &predicate_print_xdeps__modules_1
};

extern Const struct predicate predicate_print_xdeps__goals_3;
static Const struct predinfo predinfo_print_xdeps__goals_3 = {
  (unsigned char *)"deps_goals",
  &predicate_print_xdeps__goals_3
};

extern Const struct predicate predicate_print_xdeps__goals_1;
static Const struct predinfo predinfo_print_xdeps__goals_1 = {
  (unsigned char *)"deps_goals",
  &predicate_print_xdeps__goals_1
};

extern Const struct predicate predicate_print_xdeps__clauses_3;
static Const struct predinfo predinfo_print_xdeps__clauses_3 = {
  (unsigned char *)"deps_clauses",
  &predicate_print_xdeps__clauses_3
};

extern Const struct predicate predicate_print_xdeps_1;
static Const struct predinfo predinfo_print_xdeps_1 = {
  (unsigned char *)"deps",
  &predicate_print_xdeps_1
};

extern Const struct predicate predicate_print_xdepends_1;
static Const struct predinfo predinfo_print_xdepends_1 = {
  (unsigned char *)"depends",
  &predicate_print_xdepends_1
};

extern Const struct predicate predicate_print_xdepends1_1;
static Const struct predinfo predinfo_print_xdepends1_1 = {
  (unsigned char *)"depends1",
  &predicate_print_xdepends1_1
};

extern Const struct predicate predicate_print_xdatan_2;
static Const struct predinfo predinfo_print_xdatan_2 = {
  (unsigned char *)"datan",
  &predicate_print_xdatan_2
};

extern Const struct predicate predicate_print_xdatan_1;
static Const struct predinfo predinfo_print_xdatan_1 = {
  (unsigned char *)"datan",
  &predicate_print_xdatan_1
};

extern Const struct predicate predicate_print_xdata_2;
static Const struct predinfo predinfo_print_xdata_2 = {
  (unsigned char *)"data",
  &predicate_print_xdata_2
};

extern Const struct predicate predicate_print_xdata_1;
static Const struct predinfo predinfo_print_xdata_1 = {
  (unsigned char *)"data",
  &predicate_print_xdata_1
};

extern Const struct predicate predicate_print_xclauses__a_2;
static Const struct predinfo predinfo_print_xclauses__a_2 = {
  (unsigned char *)"clauses_a",
  &predicate_print_xclauses__a_2
};

extern Const struct predicate predicate_print_xclauses_2;
static Const struct predinfo predinfo_print_xclauses_2 = {
  (unsigned char *)"clauses",
  &predicate_print_xclauses_2
};

extern Const struct predicate predicate_print_xclause__a_4;
static Const struct predinfo predinfo_print_xclause__a_4 = {
  (unsigned char *)"clause_a",
  &predicate_print_xclause__a_4
};

extern Const struct predicate predicate_print_xbodys__a_2;
static Const struct predinfo predinfo_print_xbodys__a_2 = {
  (unsigned char *)"bodys_a",
  &predicate_print_xbodys__a_2
};

extern Const struct predicate predicate_print_xbodys__a1_4;
static Const struct predinfo predinfo_print_xbodys__a1_4 = {
  (unsigned char *)"bodys_a1",
  &predicate_print_xbodys__a1_4
};

extern Const struct predicate predicate_print_xbodys_2;
static Const struct predinfo predinfo_print_xbodys_2 = {
  (unsigned char *)"bodys",
  &predicate_print_xbodys_2
};

extern Const struct predicate predicate_print_xbodys1_2;
static Const struct predinfo predinfo_print_xbodys1_2 = {
  (unsigned char *)"bodys1",
  &predicate_print_xbodys1_2
};

static Const struct predinfo * Const preds_in_print[] = {
  &predinfo_print_xtype__table_2,
  &predinfo_print_xtype__modules_2,
  &predinfo_print_xtype__clauses_2,
  &predinfo_print_xtype__clauses1_4,
  &predinfo_print_xtype__clause_3,
  &predinfo_print_xtype__clause1_4,
  &predinfo_print_xtermn_1,
  &predinfo_print_xterm__vector__arg_3,
  &predinfo_print_xterm__arg_3,
  &predinfo_print_xterm_1,
  &predinfo_print_xterm2_1,
  &predinfo_print_xterm1_2,
  &predinfo_print_xprogram__modules_1,
  &predinfo_print_xprogram__goals_1,
  &predinfo_print_xprogram__clauses_1,
  &predinfo_print_xprogram__clause_1,
  &predinfo_print_xprogram_1,
  &predinfo_print_xmodules__a_2,
  &predinfo_print_xmodules_2,
  &predinfo_print_xmodule__split__stdout_2,
  &predinfo_print_xmodule__split__modules_3,
  &predinfo_print_xmodule__split__clauses_3,
  &predinfo_print_xmodule__split_1,
  &predinfo_print_xlist_2,
  &predinfo_print_xlist_1,
  &predinfo_print_xheadbody__table_2,
  &predinfo_print_xheadbody__modules_2,
  &predinfo_print_xheadbody__clauses_2,
  &predinfo_print_xguards__a_2,
  &predinfo_print_xguards__a1_4,
  &predinfo_print_xguards_2,
  &predinfo_print_xguards1_2,
  &predinfo_print_xgoal_2,
  &predinfo_print_xdeps__modules_1,
  &predinfo_print_xdeps__goals_3,
  &predinfo_print_xdeps__goals_1,
  &predinfo_print_xdeps__clauses_3,
  &predinfo_print_xdeps_1,
  &predinfo_print_xdepends_1,
  &predinfo_print_xdepends1_1,
  &predinfo_print_xdatan_2,
  &predinfo_print_xdatan_1,
  &predinfo_print_xdata_2,
  &predinfo_print_xdata_1,
  &predinfo_print_xclauses__a_2,
  &predinfo_print_xclauses_2,
  &predinfo_print_xclause__a_4,
  &predinfo_print_xbodys__a_2,
  &predinfo_print_xbodys__a1_4,
  &predinfo_print_xbodys_2,
  &predinfo_print_xbodys1_2,
  0
};
extern Const struct predicate predicate_analyzer_xmain_2;
static Const struct predinfo predinfo_analyzer_xmain_2 = {
  (unsigned char *)"main",
  &predicate_analyzer_xmain_2
};

static Const struct predinfo * Const preds_in_analyzer[] = {
  &predinfo_analyzer_xmain_2,
  0
};
extern Const struct predicate predicate_io_xwait__and__print_4;
static Const struct predinfo predinfo_io_xwait__and__print_4 = {
  (unsigned char *)"wait_and_print",
  &predicate_io_xwait__and__print_4
};

extern Const struct predicate predicate_io_xwaitAll_5;
static Const struct predinfo predinfo_io_xwaitAll_5 = {
  (unsigned char *)"waitAll",
  &predicate_io_xwaitAll_5
};

extern Const struct predicate predicate_io_xtestok_2;
static Const struct predinfo predinfo_io_xtestok_2 = {
  (unsigned char *)"testok",
  &predicate_io_xtestok_2
};

extern Const struct predicate predicate_io_xputs_5;
static Const struct predinfo predinfo_io_xputs_5 = {
  (unsigned char *)"puts",
  &predicate_io_xputs_5
};

extern Const struct predicate predicate_io_xoutstreamq_2;
static Const struct predinfo predinfo_io_xoutstreamq_2 = {
  (unsigned char *)"outstreamq",
  &predicate_io_xoutstreamq_2
};

extern Const struct predicate predicate_io_xoutstream_2;
static Const struct predinfo predinfo_io_xoutstream_2 = {
  (unsigned char *)"outstream",
  &predicate_io_xoutstream_2
};

extern Const struct predicate predicate_io_xoutstream_1;
static Const struct predinfo predinfo_io_xoutstream_1 = {
  (unsigned char *)"outstream",
  &predicate_io_xoutstream_1
};

extern Const struct predicate predicate_io_xout_2;
static Const struct predinfo predinfo_io_xout_2 = {
  (unsigned char *)"out",
  &predicate_io_xout_2
};

extern Const struct predicate predicate_io_xinstreamq_2;
static Const struct predinfo predinfo_io_xinstreamq_2 = {
  (unsigned char *)"instreamq",
  &predicate_io_xinstreamq_2
};

extern Const struct predicate predicate_io_xinstream_2;
static Const struct predinfo predinfo_io_xinstream_2 = {
  (unsigned char *)"instream",
  &predicate_io_xinstream_2
};

extern Const struct predicate predicate_io_xinstream_1;
static Const struct predinfo predinfo_io_xinstream_1 = {
  (unsigned char *)"instream",
  &predicate_io_xinstream_1
};

extern Const struct predicate predicate_io_xin_2;
static Const struct predinfo predinfo_io_xin_2 = {
  (unsigned char *)"in",
  &predicate_io_xin_2
};

extern Const struct predicate predicate_io_xerrstream_1;
static Const struct predinfo predinfo_io_xerrstream_1 = {
  (unsigned char *)"errstream",
  &predicate_io_xerrstream_1
};

static Const struct predinfo * Const preds_in_io[] = {
  &predinfo_io_xwait__and__print_4,
  &predinfo_io_xwaitAll_5,
  &predinfo_io_xtestok_2,
  &predinfo_io_xputs_5,
  &predinfo_io_xoutstreamq_2,
  &predinfo_io_xoutstream_2,
  &predinfo_io_xoutstream_1,
  &predinfo_io_xout_2,
  &predinfo_io_xinstreamq_2,
  &predinfo_io_xinstream_2,
  &predinfo_io_xinstream_1,
  &predinfo_io_xin_2,
  &predinfo_io_xerrstream_1,
  0
};
extern Const struct predicate predicate_parser_xwrap__list_2;
static Const struct predinfo predinfo_parser_xwrap__list_2 = {
  (unsigned char *)"wrap_list",
  &predicate_parser_xwrap__list_2
};

extern Const struct predicate predicate_parser_xwrap__functor_2;
static Const struct predinfo predinfo_parser_xwrap__functor_2 = {
  (unsigned char *)"wrap_functor",
  &predicate_parser_xwrap__functor_2
};

extern Const struct predicate predicate_parser_xwrap__functor1_2;
static Const struct predinfo predinfo_parser_xwrap__functor1_2 = {
  (unsigned char *)"wrap_functor1",
  &predicate_parser_xwrap__functor1_2
};

extern Const struct predicate predicate_parser_xwparse_5;
static Const struct predinfo predinfo_parser_xwparse_5 = {
  (unsigned char *)"wparse",
  &predicate_parser_xwparse_5
};

extern Const struct predicate predicate_parser_xwparse_4;
static Const struct predinfo predinfo_parser_xwparse_4 = {
  (unsigned char *)"wparse",
  &predicate_parser_xwparse_4
};

extern Const struct predicate predicate_parser_xwparse_3;
static Const struct predinfo predinfo_parser_xwparse_3 = {
  (unsigned char *)"wparse",
  &predicate_parser_xwparse_3
};

extern Const struct predicate predicate_parser_xwparse_2F5_244_5;
static Const struct predinfo predinfo_parser_xwparse_2F5_244_5 = {
  (unsigned char *)"wparse/5$4",
  &predicate_parser_xwparse_2F5_244_5
};

extern Const struct predicate predicate_parser_xwparse_2F5_244_2F5_242_2;
static Const struct predinfo predinfo_parser_xwparse_2F5_244_2F5_242_2 = {
  (unsigned char *)"wparse/5$4/5$2",
  &predicate_parser_xwparse_2F5_244_2F5_242_2
};

extern Const struct predicate predicate_parser_xwparse_2F5_244_2F5_241_5;
static Const struct predinfo predinfo_parser_xwparse_2F5_244_2F5_241_5 = {
  (unsigned char *)"wparse/5$4/5$1",
  &predicate_parser_xwparse_2F5_244_2F5_241_5
};

extern Const struct predicate predicate_parser_xwparse_2F5_244_2F5_240_6;
static Const struct predinfo predinfo_parser_xwparse_2F5_244_2F5_240_6 = {
  (unsigned char *)"wparse/5$4/5$0",
  &predicate_parser_xwparse_2F5_244_2F5_240_6
};

extern Const struct predicate predicate_parser_xwparse_2F5_244_2F5_240_2F6_240_6;
static Const struct predinfo predinfo_parser_xwparse_2F5_244_2F5_240_2F6_240_6 = {
  (unsigned char *)"wparse/5$4/5$0/6$0",
  &predicate_parser_xwparse_2F5_244_2F5_240_2F6_240_6
};

extern Const struct predicate predicate_parser_xwparse_2F5_243_5;
static Const struct predinfo predinfo_parser_xwparse_2F5_243_5 = {
  (unsigned char *)"wparse/5$3",
  &predicate_parser_xwparse_2F5_243_5
};

extern Const struct predicate predicate_parser_xwparse_2F5_242_4;
static Const struct predinfo predinfo_parser_xwparse_2F5_242_4 = {
  (unsigned char *)"wparse/5$2",
  &predicate_parser_xwparse_2F5_242_4
};

extern Const struct predicate predicate_parser_xwparse_2F5_242_2F4_240_4;
static Const struct predinfo predinfo_parser_xwparse_2F5_242_2F4_240_4 = {
  (unsigned char *)"wparse/5$2/4$0",
  &predicate_parser_xwparse_2F5_242_2F4_240_4
};

extern Const struct predicate predicate_parser_xwparse_2F5_241_4;
static Const struct predinfo predinfo_parser_xwparse_2F5_241_4 = {
  (unsigned char *)"wparse/5$1",
  &predicate_parser_xwparse_2F5_241_4
};

extern Const struct predicate predicate_parser_xwparse_2F5_241_2F4_240_4;
static Const struct predinfo predinfo_parser_xwparse_2F5_241_2F4_240_4 = {
  (unsigned char *)"wparse/5$1/4$0",
  &predicate_parser_xwparse_2F5_241_2F4_240_4
};

extern Const struct predicate predicate_parser_xwparse_2F5_240_4;
static Const struct predinfo predinfo_parser_xwparse_2F5_240_4 = {
  (unsigned char *)"wparse/5$0",
  &predicate_parser_xwparse_2F5_240_4
};

extern Const struct predicate predicate_parser_xwparse_2F5_240_2F4_240_5;
static Const struct predinfo predinfo_parser_xwparse_2F5_240_2F4_240_5 = {
  (unsigned char *)"wparse/5$0/4$0",
  &predicate_parser_xwparse_2F5_240_2F4_240_5
};

extern Const struct predicate predicate_parser_xwait__parse_2F2_240_2;
static Const struct predinfo predinfo_parser_xwait__parse_2F2_240_2 = {
  (unsigned char *)"wait_parse/2$0",
  &predicate_parser_xwait__parse_2F2_240_2
};

extern Const struct predicate predicate_parser_xwait__parse_2;
static Const struct predinfo predinfo_parser_xwait__parse_2 = {
  (unsigned char *)"wait_parse",
  &predicate_parser_xwait__parse_2
};

extern Const struct predicate predicate_parser_xunwrap_2;
static Const struct predinfo predinfo_parser_xunwrap_2 = {
  (unsigned char *)"unwrap",
  &predicate_parser_xunwrap_2
};

extern Const struct predicate predicate_parser_xselect__better_3;
static Const struct predinfo predinfo_parser_xselect__better_3 = {
  (unsigned char *)"select_better",
  &predicate_parser_xselect__better_3
};

extern Const struct predicate predicate_parser_xselect__better_2F3_241_4;
static Const struct predinfo predinfo_parser_xselect__better_2F3_241_4 = {
  (unsigned char *)"select_better/3$1",
  &predicate_parser_xselect__better_2F3_241_4
};

extern Const struct predicate predicate_parser_xselect__better_2F3_240_4;
static Const struct predinfo predinfo_parser_xselect__better_2F3_240_4 = {
  (unsigned char *)"select_better/3$0",
  &predicate_parser_xselect__better_2F3_240_4
};

extern Const struct predicate predicate_parser_xprefixop_4;
static Const struct predinfo predinfo_parser_xprefixop_4 = {
  (unsigned char *)"prefixop",
  &predicate_parser_xprefixop_4
};

extern Const struct predicate predicate_parser_xprefixop_2F4_240_4;
static Const struct predinfo predinfo_parser_xprefixop_2F4_240_4 = {
  (unsigned char *)"prefixop/4$0",
  &predicate_parser_xprefixop_2F4_240_4
};

extern Const struct predicate predicate_parser_xpostfixop_5;
static Const struct predinfo predinfo_parser_xpostfixop_5 = {
  (unsigned char *)"postfixop",
  &predicate_parser_xpostfixop_5
};

extern Const struct predicate predicate_parser_xpostfixop_2F5_240_5;
static Const struct predinfo predinfo_parser_xpostfixop_2F5_240_5 = {
  (unsigned char *)"postfixop/5$0",
  &predicate_parser_xpostfixop_2F5_240_5
};

extern Const struct predicate predicate_parser_xparse__comma__list_8;
static Const struct predinfo predinfo_parser_xparse__comma__list_8 = {
  (unsigned char *)"parse_comma_list",
  &predicate_parser_xparse__comma__list_8
};

extern Const struct predicate predicate_parser_xparse__comma__list_6;
static Const struct predinfo predinfo_parser_xparse__comma__list_6 = {
  (unsigned char *)"parse_comma_list",
  &predicate_parser_xparse__comma__list_6
};

extern Const struct predicate predicate_parser_xparse__comma__list_2F8_240_8;
static Const struct predinfo predinfo_parser_xparse__comma__list_2F8_240_8 = {
  (unsigned char *)"parse_comma_list/8$0",
  &predicate_parser_xparse__comma__list_2F8_240_8
};

extern Const struct predicate predicate_parser_xparse__comma__list_2F8_240_2F8_240_8;
static Const struct predinfo predinfo_parser_xparse__comma__list_2F8_240_2F8_240_8 = {
  (unsigned char *)"parse_comma_list/8$0/8$0",
  &predicate_parser_xparse__comma__list_2F8_240_2F8_240_8
};

extern Const struct predicate predicate_parser_xparse__comma__list_2F8_240_2F8_240_2F8_240_5;
static Const struct predinfo predinfo_parser_xparse__comma__list_2F8_240_2F8_240_2F8_240_5 = {
  (unsigned char *)"parse_comma_list/8$0/8$0/8$0",
  &predicate_parser_xparse__comma__list_2F8_240_2F8_240_2F8_240_5
};

extern Const struct predicate predicate_parser_xparse__comma__list_2F8_240_2F8_240_2F8_240_2F5_240_4;
static Const struct predinfo predinfo_parser_xparse__comma__list_2F8_240_2F8_240_2F8_240_2F5_240_4 = {
  (unsigned char *)"parse_comma_list/8$0/8$0/8$0/5$0",
  &predicate_parser_xparse__comma__list_2F8_240_2F8_240_2F8_240_2F5_240_4
};

extern Const struct predicate predicate_parser_xparse_3;
static Const struct predinfo predinfo_parser_xparse_3 = {
  (unsigned char *)"parse",
  &predicate_parser_xparse_3
};

extern Const struct predicate predicate_parser_xlookup__op_4;
static Const struct predinfo predinfo_parser_xlookup__op_4 = {
  (unsigned char *)"lookup_op",
  &predicate_parser_xlookup__op_4
};

extern Const struct predicate predicate_parser_xlonger_3;
static Const struct predinfo predinfo_parser_xlonger_3 = {
  (unsigned char *)"longer",
  &predicate_parser_xlonger_3
};

extern Const struct predicate predicate_parser_xlist__to__comma__list_2;
static Const struct predinfo predinfo_parser_xlist__to__comma__list_2 = {
  (unsigned char *)"list_to_comma_list",
  &predicate_parser_xlist__to__comma__list_2
};

extern Const struct predicate predicate_parser_xlast__check_2;
static Const struct predinfo predinfo_parser_xlast__check_2 = {
  (unsigned char *)"last_check",
  &predicate_parser_xlast__check_2
};

extern Const struct predicate predicate_parser_xinfixop_5;
static Const struct predinfo predinfo_parser_xinfixop_5 = {
  (unsigned char *)"infixop",
  &predicate_parser_xinfixop_5
};

extern Const struct predicate predicate_parser_xinfixop_2F5_240_5;
static Const struct predinfo predinfo_parser_xinfixop_2F5_240_5 = {
  (unsigned char *)"infixop/5$0",
  &predicate_parser_xinfixop_2F5_240_5
};

extern Const struct predicate predicate_parser_xafter__term_6;
static Const struct predinfo predinfo_parser_xafter__term_6 = {
  (unsigned char *)"after_term",
  &predicate_parser_xafter__term_6
};

extern Const struct predicate predicate_parser_xafter__term_2F6_242_8;
static Const struct predinfo predinfo_parser_xafter__term_2F6_242_8 = {
  (unsigned char *)"after_term/6$2",
  &predicate_parser_xafter__term_2F6_242_8
};

extern Const struct predicate predicate_parser_xafter__term_2F6_242_2F8_241_7;
static Const struct predinfo predinfo_parser_xafter__term_2F6_242_2F8_241_7 = {
  (unsigned char *)"after_term/6$2/8$1",
  &predicate_parser_xafter__term_2F6_242_2F8_241_7
};

extern Const struct predicate predicate_parser_xafter__term_2F6_242_2F8_240_9;
static Const struct predinfo predinfo_parser_xafter__term_2F6_242_2F8_240_9 = {
  (unsigned char *)"after_term/6$2/8$0",
  &predicate_parser_xafter__term_2F6_242_2F8_240_9
};

extern Const struct predicate predicate_parser_xafter__term_2F6_242_2F8_240_2F9_240_7;
static Const struct predinfo predinfo_parser_xafter__term_2F6_242_2F8_240_2F9_240_7 = {
  (unsigned char *)"after_term/6$2/8$0/9$0",
  &predicate_parser_xafter__term_2F6_242_2F8_240_2F9_240_7
};

extern Const struct predicate predicate_parser_xafter__term_2F6_241_5;
static Const struct predinfo predinfo_parser_xafter__term_2F6_241_5 = {
  (unsigned char *)"after_term/6$1",
  &predicate_parser_xafter__term_2F6_241_5
};

extern Const struct predicate predicate_parser_xafter__term_2F6_240_5;
static Const struct predinfo predinfo_parser_xafter__term_2F6_240_5 = {
  (unsigned char *)"after_term/6$0",
  &predicate_parser_xafter__term_2F6_240_5
};

static Const struct predinfo * Const preds_in_parser[] = {
  &predinfo_parser_xwrap__list_2,
  &predinfo_parser_xwrap__functor_2,
  &predinfo_parser_xwrap__functor1_2,
  &predinfo_parser_xwparse_5,
  &predinfo_parser_xwparse_4,
  &predinfo_parser_xwparse_3,
  &predinfo_parser_xwparse_2F5_244_5,
  &predinfo_parser_xwparse_2F5_244_2F5_242_2,
  &predinfo_parser_xwparse_2F5_244_2F5_241_5,
  &predinfo_parser_xwparse_2F5_244_2F5_240_6,
  &predinfo_parser_xwparse_2F5_244_2F5_240_2F6_240_6,
  &predinfo_parser_xwparse_2F5_243_5,
  &predinfo_parser_xwparse_2F5_242_4,
  &predinfo_parser_xwparse_2F5_242_2F4_240_4,
  &predinfo_parser_xwparse_2F5_241_4,
  &predinfo_parser_xwparse_2F5_241_2F4_240_4,
  &predinfo_parser_xwparse_2F5_240_4,
  &predinfo_parser_xwparse_2F5_240_2F4_240_5,
  &predinfo_parser_xwait__parse_2F2_240_2,
  &predinfo_parser_xwait__parse_2,
  &predinfo_parser_xunwrap_2,
  &predinfo_parser_xselect__better_3,
  &predinfo_parser_xselect__better_2F3_241_4,
  &predinfo_parser_xselect__better_2F3_240_4,
  &predinfo_parser_xprefixop_4,
  &predinfo_parser_xprefixop_2F4_240_4,
  &predinfo_parser_xpostfixop_5,
  &predinfo_parser_xpostfixop_2F5_240_5,
  &predinfo_parser_xparse__comma__list_8,
  &predinfo_parser_xparse__comma__list_6,
  &predinfo_parser_xparse__comma__list_2F8_240_8,
  &predinfo_parser_xparse__comma__list_2F8_240_2F8_240_8,
  &predinfo_parser_xparse__comma__list_2F8_240_2F8_240_2F8_240_5,
  &predinfo_parser_xparse__comma__list_2F8_240_2F8_240_2F8_240_2F5_240_4,
  &predinfo_parser_xparse_3,
  &predinfo_parser_xlookup__op_4,
  &predinfo_parser_xlonger_3,
  &predinfo_parser_xlist__to__comma__list_2,
  &predinfo_parser_xlast__check_2,
  &predinfo_parser_xinfixop_5,
  &predinfo_parser_xinfixop_2F5_240_5,
  &predinfo_parser_xafter__term_6,
  &predinfo_parser_xafter__term_2F6_242_8,
  &predinfo_parser_xafter__term_2F6_242_2F8_241_7,
  &predinfo_parser_xafter__term_2F6_242_2F8_240_9,
  &predinfo_parser_xafter__term_2F6_242_2F8_240_2F9_240_7,
  &predinfo_parser_xafter__term_2F6_241_5,
  &predinfo_parser_xafter__term_2F6_240_5,
  0
};
extern Const struct predicate predicate_klic__reader_xwrite__tokens_4;
static Const struct predinfo predinfo_klic__reader_xwrite__tokens_4 = {
  (unsigned char *)"write_tokens",
  &predicate_klic__reader_xwrite__tokens_4
};

extern Const struct predicate predicate_klic__reader_xwrite__string_3;
static Const struct predinfo predinfo_klic__reader_xwrite__string_3 = {
  (unsigned char *)"write_string",
  &predicate_klic__reader_xwrite__string_3
};

extern Const struct predicate predicate_klic__reader_xwrite__one__token_3;
static Const struct predinfo predinfo_klic__reader_xwrite__one__token_3 = {
  (unsigned char *)"write_one_token",
  &predicate_klic__reader_xwrite__one__token_3
};

extern Const struct predicate predicate_klic__reader_xwrite__number_3;
static Const struct predinfo predinfo_klic__reader_xwrite__number_3 = {
  (unsigned char *)"write_number",
  &predicate_klic__reader_xwrite__number_3
};

extern Const struct predicate predicate_klic__reader_xwrite__decimal_3;
static Const struct predinfo predinfo_klic__reader_xwrite__decimal_3 = {
  (unsigned char *)"write_decimal",
  &predicate_klic__reader_xwrite__decimal_3
};

extern Const struct predicate predicate_klic__reader_xwrite__char_3;
static Const struct predinfo predinfo_klic__reader_xwrite__char_3 = {
  (unsigned char *)"write_char",
  &predicate_klic__reader_xwrite__char_3
};

extern Const struct predicate predicate_klic__reader_xwrite__atom_3;
static Const struct predinfo predinfo_klic__reader_xwrite__atom_3 = {
  (unsigned char *)"write_atom",
  &predicate_klic__reader_xwrite__atom_3
};

extern Const struct predicate predicate_klic__reader_xwparse__one__term__reporting__errors_4;
static Const struct predinfo predinfo_klic__reader_xwparse__one__term__reporting__errors_4 = {
  (unsigned char *)"wparse_one_term_reporting_errors",
  &predicate_klic__reader_xwparse__one__term__reporting__errors_4
};

extern Const struct predicate predicate_klic__reader_xwparse__one__term__reporting__errors_2F4_240_8;
static Const struct predinfo predinfo_klic__reader_xwparse__one__term__reporting__errors_2F4_240_8 = {
  (unsigned char *)"wparse_one_term_reporting_errors/4$0",
  &predicate_klic__reader_xwparse__one__term__reporting__errors_2F4_240_8
};

extern Const struct predicate predicate_klic__reader_xreport__syntax__error_7;
static Const struct predinfo predinfo_klic__reader_xreport__syntax__error_7 = {
  (unsigned char *)"report_syntax_error",
  &predicate_klic__reader_xreport__syntax__error_7
};

extern Const struct predicate predicate_klic__reader_xreport__syntax__error_2F7_240_2;
static Const struct predinfo predinfo_klic__reader_xreport__syntax__error_2F7_240_2 = {
  (unsigned char *)"report_syntax_error/7$0",
  &predicate_klic__reader_xreport__syntax__error_2F7_240_2
};

extern Const struct predicate predicate_klic__reader_xparse__one__term__reporting__errors_4;
static Const struct predinfo predinfo_klic__reader_xparse__one__term__reporting__errors_4 = {
  (unsigned char *)"parse_one_term_reporting_errors",
  &predicate_klic__reader_xparse__one__term__reporting__errors_4
};

extern Const struct predicate predicate_klic__reader_xparse__one__term__reporting__errors_2F4_240_8;
static Const struct predinfo predinfo_klic__reader_xparse__one__term__reporting__errors_2F4_240_8 = {
  (unsigned char *)"parse_one_term_reporting_errors/4$0",
  &predicate_klic__reader_xparse__one__term__reporting__errors_2F4_240_8
};

extern Const struct predicate predicate_klic__reader_xlength_3;
static Const struct predinfo predinfo_klic__reader_xlength_3 = {
  (unsigned char *)"length",
  &predicate_klic__reader_xlength_3
};

extern Const struct predicate predicate_klic__reader_xlength_2;
static Const struct predinfo predinfo_klic__reader_xlength_2 = {
  (unsigned char *)"length",
  &predicate_klic__reader_xlength_2
};

extern Const struct predicate predicate_klic__reader_xblank_2;
static Const struct predinfo predinfo_klic__reader_xblank_2 = {
  (unsigned char *)"blank",
  &predicate_klic__reader_xblank_2
};

static Const struct predinfo * Const preds_in_klic__reader[] = {
  &predinfo_klic__reader_xwrite__tokens_4,
  &predinfo_klic__reader_xwrite__string_3,
  &predinfo_klic__reader_xwrite__one__token_3,
  &predinfo_klic__reader_xwrite__number_3,
  &predinfo_klic__reader_xwrite__decimal_3,
  &predinfo_klic__reader_xwrite__char_3,
  &predinfo_klic__reader_xwrite__atom_3,
  &predinfo_klic__reader_xwparse__one__term__reporting__errors_4,
  &predinfo_klic__reader_xwparse__one__term__reporting__errors_2F4_240_8,
  &predinfo_klic__reader_xreport__syntax__error_7,
  &predinfo_klic__reader_xreport__syntax__error_2F7_240_2,
  &predinfo_klic__reader_xparse__one__term__reporting__errors_4,
  &predinfo_klic__reader_xparse__one__term__reporting__errors_2F4_240_8,
  &predinfo_klic__reader_xlength_3,
  &predinfo_klic__reader_xlength_2,
  &predinfo_klic__reader_xblank_2,
  0
};
extern Const struct predicate predicate_klicio_xupdt_3;
static Const struct predinfo predinfo_klicio_xupdt_3 = {
  (unsigned char *)"updt",
  &predicate_klicio_xupdt_3
};

extern Const struct predicate predicate_klicio_xupdate__lc_3;
static Const struct predinfo predinfo_klicio_xupdate__lc_3 = {
  (unsigned char *)"update_lc",
  &predicate_klicio_xupdate__lc_3
};

extern Const struct predicate predicate_klicio_xtermupdt_2;
static Const struct predinfo predinfo_klicio_xtermupdt_2 = {
  (unsigned char *)"termupdt",
  &predicate_klicio_xtermupdt_2
};

extern Const struct predicate predicate_klicio_xtermout_2;
static Const struct predinfo predinfo_klicio_xtermout_2 = {
  (unsigned char *)"termout",
  &predicate_klicio_xtermout_2
};

extern Const struct predicate predicate_klicio_xtermin_2;
static Const struct predinfo predinfo_klicio_xtermin_2 = {
  (unsigned char *)"termin",
  &predicate_klicio_xtermin_2
};

extern Const struct predicate predicate_klicio_xstring__output_4;
static Const struct predinfo predinfo_klicio_xstring__output_4 = {
  (unsigned char *)"string_output",
  &predicate_klicio_xstring__output_4
};

extern Const struct predicate predicate_klicio_xstring__input_5;
static Const struct predinfo predinfo_klicio_xstring__input_5 = {
  (unsigned char *)"string_input",
  &predicate_klicio_xstring__input_5
};

extern Const struct predicate predicate_klicio_xset__string__elements_6;
static Const struct predinfo predinfo_klicio_xset__string__elements_6 = {
  (unsigned char *)"set_string_elements",
  &predicate_klicio_xset__string__elements_6
};

extern Const struct predicate predicate_klicio_xsend__unix_3;
static Const struct predinfo predinfo_klicio_xsend__unix_3 = {
  (unsigned char *)"send_unix",
  &predicate_klicio_xsend__unix_3
};

extern Const struct predicate predicate_klicio_xrmop_4;
static Const struct predinfo predinfo_klicio_xrmop_4 = {
  (unsigned char *)"rmop",
  &predicate_klicio_xrmop_4
};

extern Const struct predicate predicate_klicio_xrmop2_4;
static Const struct predinfo predinfo_klicio_xrmop2_4 = {
  (unsigned char *)"rmop2",
  &predicate_klicio_xrmop2_4
};

extern Const struct predicate predicate_klicio_xoutput__stream_2;
static Const struct predinfo predinfo_klicio_xoutput__stream_2 = {
  (unsigned char *)"output_stream",
  &predicate_klicio_xoutput__stream_2
};

extern Const struct predicate predicate_klicio_xout_3;
static Const struct predinfo predinfo_klicio_xout_3 = {
  (unsigned char *)"out",
  &predicate_klicio_xout_3
};

extern Const struct predicate predicate_klicio_xklicio_2;
static Const struct predinfo predinfo_klicio_xklicio_2 = {
  (unsigned char *)"klicio",
  &predicate_klicio_xklicio_2
};

extern Const struct predicate predicate_klicio_xklicio_1;
static Const struct predinfo predinfo_klicio_xklicio_1 = {
  (unsigned char *)"klicio",
  &predicate_klicio_xklicio_1
};

extern Const struct predicate predicate_klicio_xin_3;
static Const struct predinfo predinfo_klicio_xin_3 = {
  (unsigned char *)"in",
  &predicate_klicio_xin_3
};

extern Const struct predicate predicate_klicio_xfill__string_4;
static Const struct predinfo predinfo_klicio_xfill__string_4 = {
  (unsigned char *)"fill_string",
  &predicate_klicio_xfill__string_4
};

extern Const struct predicate predicate_klicio_xdefault__operator__table_1;
static Const struct predinfo predinfo_klicio_xdefault__operator__table_1 = {
  (unsigned char *)"default_operator_table",
  &predicate_klicio_xdefault__operator__table_1
};

extern Const struct predicate predicate_klicio_xcompute__string__length_3;
static Const struct predinfo predinfo_klicio_xcompute__string__length_3 = {
  (unsigned char *)"compute_string_length",
  &predicate_klicio_xcompute__string__length_3
};

extern Const struct predicate predicate_klicio_xclose__unix_1;
static Const struct predinfo predinfo_klicio_xclose__unix_1 = {
  (unsigned char *)"close_unix",
  &predicate_klicio_xclose__unix_1
};

extern Const struct predicate predicate_klicio_xaddop_5;
static Const struct predinfo predinfo_klicio_xaddop_5 = {
  (unsigned char *)"addop",
  &predicate_klicio_xaddop_5
};

extern Const struct predicate predicate_klicio_xaddop2_5;
static Const struct predinfo predinfo_klicio_xaddop2_5 = {
  (unsigned char *)"addop2",
  &predicate_klicio_xaddop2_5
};

static Const struct predinfo * Const preds_in_klicio[] = {
  &predinfo_klicio_xupdt_3,
  &predinfo_klicio_xupdate__lc_3,
  &predinfo_klicio_xtermupdt_2,
  &predinfo_klicio_xtermout_2,
  &predinfo_klicio_xtermin_2,
  &predinfo_klicio_xstring__output_4,
  &predinfo_klicio_xstring__input_5,
  &predinfo_klicio_xset__string__elements_6,
  &predinfo_klicio_xsend__unix_3,
  &predinfo_klicio_xrmop_4,
  &predinfo_klicio_xrmop2_4,
  &predinfo_klicio_xoutput__stream_2,
  &predinfo_klicio_xout_3,
  &predinfo_klicio_xklicio_2,
  &predinfo_klicio_xklicio_1,
  &predinfo_klicio_xin_3,
  &predinfo_klicio_xfill__string_4,
  &predinfo_klicio_xdefault__operator__table_1,
  &predinfo_klicio_xcompute__string__length_3,
  &predinfo_klicio_xclose__unix_1,
  &predinfo_klicio_xaddop_5,
  &predinfo_klicio_xaddop2_5,
  0
};
extern Const struct predicate predicate_atom__table_xset__atom__string_5;
static Const struct predinfo predinfo_atom__table_xset__atom__string_5 = {
  (unsigned char *)"set_atom_string",
  &predicate_atom__table_xset__atom__string_5
};

extern Const struct predicate predicate_atom__table_xmake__atom_2;
static Const struct predinfo predinfo_atom__table_xmake__atom_2 = {
  (unsigned char *)"make_atom",
  &predicate_atom__table_xmake__atom_2
};

extern Const struct predicate predicate_atom__table_xintern_2;
static Const struct predinfo predinfo_atom__table_xintern_2 = {
  (unsigned char *)"intern",
  &predicate_atom__table_xintern_2
};

extern Const struct predicate predicate_atom__table_xget__atom__string_2;
static Const struct predinfo predinfo_atom__table_xget__atom__string_2 = {
  (unsigned char *)"get_atom_string",
  &predicate_atom__table_xget__atom__string_2
};

extern Const struct predicate predicate_atom__table_xget__atom__name_2;
static Const struct predinfo predinfo_atom__table_xget__atom__name_2 = {
  (unsigned char *)"get_atom_name",
  &predicate_atom__table_xget__atom__name_2
};

extern Const struct predicate predicate_atom__table_xcache__table_1;
static Const struct predinfo predinfo_atom__table_xcache__table_1 = {
  (unsigned char *)"cache_table",
  &predicate_atom__table_xcache__table_1
};

extern Const struct predicate predicate_atom__table_xatom__number_2;
static Const struct predinfo predinfo_atom__table_xatom__number_2 = {
  (unsigned char *)"atom_number",
  &predicate_atom__table_xatom__number_2
};

static Const struct predinfo * Const preds_in_atom__table[] = {
  &predinfo_atom__table_xset__atom__string_5,
  &predinfo_atom__table_xmake__atom_2,
  &predinfo_atom__table_xintern_2,
  &predinfo_atom__table_xget__atom__string_2,
  &predinfo_atom__table_xget__atom__name_2,
  &predinfo_atom__table_xcache__table_1,
  &predinfo_atom__table_xatom__number_2,
  0
};
extern Const struct predicate predicate_klic__comp__insert_xsubsumed__type_3;
static Const struct predinfo predinfo_klic__comp__insert_xsubsumed__type_3 = {
  (unsigned char *)"subsumed_type",
  &predicate_klic__comp__insert_xsubsumed__type_3
};

extern Const struct predicate predicate_klic__comp__insert_xsubsumed__2_3;
static Const struct predinfo predinfo_klic__comp__insert_xsubsumed__2_3 = {
  (unsigned char *)"subsumed_2",
  &predicate_klic__comp__insert_xsubsumed__2_3
};

extern Const struct predicate predicate_klic__comp__insert_xsubsumed__1_5;
static Const struct predinfo predinfo_klic__comp__insert_xsubsumed__1_5 = {
  (unsigned char *)"subsumed_1",
  &predicate_klic__comp__insert_xsubsumed__1_5
};

extern Const struct predicate predicate_klic__comp__insert_xsubsumed_4;
static Const struct predinfo predinfo_klic__comp__insert_xsubsumed_4 = {
  (unsigned char *)"subsumed",
  &predicate_klic__comp__insert_xsubsumed_4
};

extern Const struct predicate predicate_klic__comp__insert_xpattern__kind_2;
static Const struct predinfo predinfo_klic__comp__insert_xpattern__kind_2 = {
  (unsigned char *)"pattern_kind",
  &predicate_klic__comp__insert_xpattern__kind_2
};

extern Const struct predicate predicate_klic__comp__insert_xmake__index__tree__1_7;
static Const struct predinfo predinfo_klic__comp__insert_xmake__index__tree__1_7 = {
  (unsigned char *)"make_index_tree_1",
  &predicate_klic__comp__insert_xmake__index__tree__1_7
};

extern Const struct predicate predicate_klic__comp__insert_xmake__index__tree_5;
static Const struct predinfo predinfo_klic__comp__insert_xmake__index__tree_5 = {
  (unsigned char *)"make_index_tree",
  &predicate_klic__comp__insert_xmake__index__tree_5
};

extern Const struct predicate predicate_klic__comp__insert_xins__value__node_12;
static Const struct predinfo predinfo_klic__comp__insert_xins__value__node_12 = {
  (unsigned char *)"ins_value_node",
  &predicate_klic__comp__insert_xins__value__node_12
};

extern Const struct predicate predicate_klic__comp__insert_xins__redundant_1;
static Const struct predinfo predinfo_klic__comp__insert_xins__redundant_1 = {
  (unsigned char *)"ins_redundant",
  &predicate_klic__comp__insert_xins__redundant_1
};

extern Const struct predicate predicate_klic__comp__insert_xins__pattern_9;
static Const struct predinfo predinfo_klic__comp__insert_xins__pattern_9 = {
  (unsigned char *)"ins_pattern",
  &predicate_klic__comp__insert_xins__pattern_9
};

extern Const struct predicate predicate_klic__comp__insert_xins__merge__case_5;
static Const struct predinfo predinfo_klic__comp__insert_xins__merge__case_5 = {
  (unsigned char *)"ins_merge_case",
  &predicate_klic__comp__insert_xins__merge__case_5
};

extern Const struct predicate predicate_klic__comp__insert_xins__index__check__and__stop_7;
static Const struct predinfo predinfo_klic__comp__insert_xins__index__check__and__stop_7 = {
  (unsigned char *)"ins_index_check_and_stop",
  &predicate_klic__comp__insert_xins__index__check__and__stop_7
};

extern Const struct predicate predicate_klic__comp__insert_xins__index__check__and__go_7;
static Const struct predinfo predinfo_klic__comp__insert_xins__index__check__and__go_7 = {
  (unsigned char *)"ins_index_check_and_go",
  &predicate_klic__comp__insert_xins__index__check__and__go_7
};

extern Const struct predicate predicate_klic__comp__insert_xins__index__1_6;
static Const struct predinfo predinfo_klic__comp__insert_xins__index__1_6 = {
  (unsigned char *)"ins_index_1",
  &predicate_klic__comp__insert_xins__index__1_6
};

extern Const struct predicate predicate_klic__comp__insert_xins__index_6;
static Const struct predinfo predinfo_klic__comp__insert_xins__index_6 = {
  (unsigned char *)"ins_index",
  &predicate_klic__comp__insert_xins__index_6
};

extern Const struct predicate predicate_klic__comp__insert_xins__gb_6;
static Const struct predinfo predinfo_klic__comp__insert_xins__gb_6 = {
  (unsigned char *)"ins_gb",
  &predicate_klic__comp__insert_xins__gb_6
};

extern Const struct predicate predicate_klic__comp__insert_xins__funct__node_6;
static Const struct predinfo predinfo_klic__comp__insert_xins__funct__node_6 = {
  (unsigned char *)"ins_funct_node",
  &predicate_klic__comp__insert_xins__funct__node_6
};

extern Const struct predicate predicate_klic__comp__insert_xins__eq_7;
static Const struct predinfo predinfo_klic__comp__insert_xins__eq_7 = {
  (unsigned char *)"ins_eq",
  &predicate_klic__comp__insert_xins__eq_7
};

extern Const struct predicate predicate_klic__comp__insert_xins__atomic__node_6;
static Const struct predinfo predinfo_klic__comp__insert_xins__atomic__node_6 = {
  (unsigned char *)"ins_atomic_node",
  &predicate_klic__comp__insert_xins__atomic__node_6
};

static Const struct predinfo * Const preds_in_klic__comp__insert[] = {
  &predinfo_klic__comp__insert_xsubsumed__type_3,
  &predinfo_klic__comp__insert_xsubsumed__2_3,
  &predinfo_klic__comp__insert_xsubsumed__1_5,
  &predinfo_klic__comp__insert_xsubsumed_4,
  &predinfo_klic__comp__insert_xpattern__kind_2,
  &predinfo_klic__comp__insert_xmake__index__tree__1_7,
  &predinfo_klic__comp__insert_xmake__index__tree_5,
  &predinfo_klic__comp__insert_xins__value__node_12,
  &predinfo_klic__comp__insert_xins__redundant_1,
  &predinfo_klic__comp__insert_xins__pattern_9,
  &predinfo_klic__comp__insert_xins__merge__case_5,
  &predinfo_klic__comp__insert_xins__index__check__and__stop_7,
  &predinfo_klic__comp__insert_xins__index__check__and__go_7,
  &predinfo_klic__comp__insert_xins__index__1_6,
  &predinfo_klic__comp__insert_xins__index_6,
  &predinfo_klic__comp__insert_xins__gb_6,
  &predinfo_klic__comp__insert_xins__funct__node_6,
  &predinfo_klic__comp__insert_xins__eq_7,
  &predinfo_klic__comp__insert_xins__atomic__node_6,
  0
};
extern Const struct predicate predicate_klic__comp__generate_xused__in__1_5;
static Const struct predinfo predinfo_klic__comp__generate_xused__in__1_5 = {
  (unsigned char *)"used_in_1",
  &predicate_klic__comp__generate_xused__in__1_5
};

extern Const struct predicate predicate_klic__comp__generate_xused__in_4;
static Const struct predinfo predinfo_klic__comp__generate_xused__in_4 = {
  (unsigned char *)"used_in",
  &predicate_klic__comp__generate_xused__in_4
};

extern Const struct predicate predicate_klic__comp__generate_xstrip__types_2;
static Const struct predinfo predinfo_klic__comp__generate_xstrip__types_2 = {
  (unsigned char *)"strip_types",
  &predicate_klic__comp__generate_xstrip__types_2
};

extern Const struct predicate predicate_klic__comp__generate_xstrip__type_2;
static Const struct predinfo predinfo_klic__comp__generate_xstrip__type_2 = {
  (unsigned char *)"strip_type",
  &predicate_klic__comp__generate_xstrip__type_2
};

extern Const struct predicate predicate_klic__comp__generate_xset__one__1_10;
static Const struct predinfo predinfo_klic__comp__generate_xset__one__1_10 = {
  (unsigned char *)"set_one_1",
  &predicate_klic__comp__generate_xset__one__1_10
};

extern Const struct predicate predicate_klic__comp__generate_xset__one_10;
static Const struct predinfo predinfo_klic__comp__generate_xset__one_10 = {
  (unsigned char *)"set_one",
  &predicate_klic__comp__generate_xset__one_10
};

extern Const struct predicate predicate_klic__comp__generate_xset__generic__args_10;
static Const struct predinfo predinfo_klic__comp__generate_xset__generic__args_10 = {
  (unsigned char *)"set_generic_args",
  &predicate_klic__comp__generate_xset__generic__args_10
};

extern Const struct predicate predicate_klic__comp__generate_xset__call__merge_3;
static Const struct predinfo predinfo_klic__comp__generate_xset__call__merge_3 = {
  (unsigned char *)"set_call_merge",
  &predicate_klic__comp__generate_xset__call__merge_3
};

extern Const struct predicate predicate_klic__comp__generate_xset__call_10;
static Const struct predinfo predinfo_klic__comp__generate_xset__call_10 = {
  (unsigned char *)"set_call",
  &predicate_klic__comp__generate_xset__call_10
};

extern Const struct predicate predicate_klic__comp__generate_xset__args__for__newthread_10;
static Const struct predinfo predinfo_klic__comp__generate_xset__args__for__newthread_10 = {
  (unsigned char *)"set_args_for_newthread",
  &predicate_klic__comp__generate_xset__args__for__newthread_10
};

extern Const struct predicate predicate_klic__comp__generate_xset__args_10;
static Const struct predinfo predinfo_klic__comp__generate_xset__args_10 = {
  (unsigned char *)"set_args",
  &predicate_klic__comp__generate_xset__args_10
};

extern Const struct predicate predicate_klic__comp__generate_xreverse_3;
static Const struct predinfo predinfo_klic__comp__generate_xreverse_3 = {
  (unsigned char *)"reverse",
  &predicate_klic__comp__generate_xreverse_3
};

extern Const struct predicate predicate_klic__comp__generate_xrassoc_3;
static Const struct predinfo predinfo_klic__comp__generate_xrassoc_3 = {
  (unsigned char *)"rassoc",
  &predicate_klic__comp__generate_xrassoc_3
};

extern Const struct predicate predicate_klic__comp__generate_xput__srec_6;
static Const struct predinfo predinfo_klic__comp__generate_xput__srec_6 = {
  (unsigned char *)"put_srec",
  &predicate_klic__comp__generate_xput__srec_6
};

extern Const struct predicate predicate_klic__comp__generate_xput__one__1_12;
static Const struct predinfo predinfo_klic__comp__generate_xput__one__1_12 = {
  (unsigned char *)"put_one_1",
  &predicate_klic__comp__generate_xput__one__1_12
};

extern Const struct predicate predicate_klic__comp__generate_xput__one_12;
static Const struct predinfo predinfo_klic__comp__generate_xput__one_12 = {
  (unsigned char *)"put_one",
  &predicate_klic__comp__generate_xput__one_12
};

extern Const struct predicate predicate_klic__comp__generate_xput__call_11;
static Const struct predinfo predinfo_klic__comp__generate_xput__call_11 = {
  (unsigned char *)"put_call",
  &predicate_klic__comp__generate_xput__call_11
};

extern Const struct predicate predicate_klic__comp__generate_xput__args_12;
static Const struct predinfo predinfo_klic__comp__generate_xput__args_12 = {
  (unsigned char *)"put_args",
  &predicate_klic__comp__generate_xput__args_12
};

extern Const struct predicate predicate_klic__comp__generate_xpush__tcall_11;
static Const struct predinfo predinfo_klic__comp__generate_xpush__tcall_11 = {
  (unsigned char *)"push_tcall",
  &predicate_klic__comp__generate_xpush__tcall_11
};

extern Const struct predicate predicate_klic__comp__generate_xprio__code_7;
static Const struct predinfo predinfo_klic__comp__generate_xprio__code_7 = {
  (unsigned char *)"prio_code",
  &predicate_klic__comp__generate_xprio__code_7
};

extern Const struct predicate predicate_klic__comp__generate_xprint__data_2;
static Const struct predinfo predinfo_klic__comp__generate_xprint__data_2 = {
  (unsigned char *)"print_data",
  &predicate_klic__comp__generate_xprint__data_2
};

extern Const struct predicate predicate_klic__comp__generate_xprep__vec__elems_10;
static Const struct predinfo predinfo_klic__comp__generate_xprep__vec__elems_10 = {
  (unsigned char *)"prep_vec_elems",
  &predicate_klic__comp__generate_xprep__vec__elems_10
};

extern Const struct predicate predicate_klic__comp__generate_xprep__poss__for__set__tmake_10;
static Const struct predinfo predinfo_klic__comp__generate_xprep__poss__for__set__tmake_10 = {
  (unsigned char *)"prep_poss_for_set_tmake",
  &predicate_klic__comp__generate_xprep__poss__for__set__tmake_10
};

extern Const struct predicate predicate_klic__comp__generate_xprep__poss_10;
static Const struct predinfo predinfo_klic__comp__generate_xprep__poss_10 = {
  (unsigned char *)"prep_poss",
  &predicate_klic__comp__generate_xprep__poss_10
};

extern Const struct predicate predicate_klic__comp__generate_xprep__pos__for__set__tmake_10;
static Const struct predinfo predinfo_klic__comp__generate_xprep__pos__for__set__tmake_10 = {
  (unsigned char *)"prep_pos_for_set_tmake",
  &predicate_klic__comp__generate_xprep__pos__for__set__tmake_10
};

extern Const struct predicate predicate_klic__comp__generate_xprep__pos__1_10;
static Const struct predinfo predinfo_klic__comp__generate_xprep__pos__1_10 = {
  (unsigned char *)"prep_pos_1",
  &predicate_klic__comp__generate_xprep__pos__1_10
};

extern Const struct predicate predicate_klic__comp__generate_xprep__pos_10;
static Const struct predinfo predinfo_klic__comp__generate_xprep__pos_10 = {
  (unsigned char *)"prep_pos",
  &predicate_klic__comp__generate_xprep__pos_10
};

extern Const struct predicate predicate_klic__comp__generate_xprep__call__arg_10;
static Const struct predinfo predinfo_klic__comp__generate_xprep__call__arg_10 = {
  (unsigned char *)"prep_call_arg",
  &predicate_klic__comp__generate_xprep__call__arg_10
};

extern Const struct predicate predicate_klic__comp__generate_xmove__one__1_10;
static Const struct predinfo predinfo_klic__comp__generate_xmove__one__1_10 = {
  (unsigned char *)"move_one_1",
  &predicate_klic__comp__generate_xmove__one__1_10
};

extern Const struct predicate predicate_klic__comp__generate_xmove__one_10;
static Const struct predinfo predinfo_klic__comp__generate_xmove__one_10 = {
  (unsigned char *)"move_one",
  &predicate_klic__comp__generate_xmove__one_10
};

extern Const struct predicate predicate_klic__comp__generate_xmove__args__1_12;
static Const struct predinfo predinfo_klic__comp__generate_xmove__args__1_12 = {
  (unsigned char *)"move_args_1",
  &predicate_klic__comp__generate_xmove__args__1_12
};

extern Const struct predicate predicate_klic__comp__generate_xmove__args_10;
static Const struct predinfo predinfo_klic__comp__generate_xmove__args_10 = {
  (unsigned char *)"move_args",
  &predicate_klic__comp__generate_xmove__args_10
};

extern Const struct predicate predicate_klic__comp__generate_xmake__var_7;
static Const struct predinfo predinfo_klic__comp__generate_xmake__var_7 = {
  (unsigned char *)"make_var",
  &predicate_klic__comp__generate_xmake__var_7
};

extern Const struct predicate predicate_klic__comp__generate_xmake__label_2;
static Const struct predinfo predinfo_klic__comp__generate_xmake__label_2 = {
  (unsigned char *)"make_label",
  &predicate_klic__comp__generate_xmake__label_2
};

extern Const struct predicate predicate_klic__comp__generate_xload__reg__2_11;
static Const struct predinfo predinfo_klic__comp__generate_xload__reg__2_11 = {
  (unsigned char *)"load_reg_2",
  &predicate_klic__comp__generate_xload__reg__2_11
};

extern Const struct predicate predicate_klic__comp__generate_xload__reg__1_11;
static Const struct predinfo predinfo_klic__comp__generate_xload__reg__1_11 = {
  (unsigned char *)"load_reg_1",
  &predicate_klic__comp__generate_xload__reg__1_11
};

extern Const struct predicate predicate_klic__comp__generate_xload__reg_11;
static Const struct predinfo predinfo_klic__comp__generate_xload__reg_11 = {
  (unsigned char *)"load_reg",
  &predicate_klic__comp__generate_xload__reg_11
};

extern Const struct predicate predicate_klic__comp__generate_xload__pos_10;
static Const struct predinfo predinfo_klic__comp__generate_xload__pos_10 = {
  (unsigned char *)"load_pos",
  &predicate_klic__comp__generate_xload__pos_10
};

extern Const struct predicate predicate_klic__comp__generate_xload__inline__args_11;
static Const struct predinfo predinfo_klic__comp__generate_xload__inline__args_11 = {
  (unsigned char *)"load_inline_args",
  &predicate_klic__comp__generate_xload__inline__args_11
};

extern Const struct predicate predicate_klic__comp__generate_xload__guard__generic__out_11;
static Const struct predinfo predinfo_klic__comp__generate_xload__guard__generic__out_11 = {
  (unsigned char *)"load_guard_generic_out",
  &predicate_klic__comp__generate_xload__guard__generic__out_11
};

extern Const struct predicate predicate_klic__comp__generate_xgen__type__known_3;
static Const struct predinfo predinfo_klic__comp__generate_xgen__type__known_3 = {
  (unsigned char *)"gen_type_known",
  &predicate_klic__comp__generate_xgen__type__known_3
};

extern Const struct predicate predicate_klic__comp__generate_xgen__type__code_18;
static Const struct predinfo predinfo_klic__comp__generate_xgen__type__code_18 = {
  (unsigned char *)"gen_type_code",
  &predicate_klic__comp__generate_xgen__type__code_18
};

extern Const struct predicate predicate_klic__comp__generate_xgen__sw__instr_3;
static Const struct predinfo predinfo_klic__comp__generate_xgen__sw__instr_3 = {
  (unsigned char *)"gen_sw_instr",
  &predicate_klic__comp__generate_xgen__sw__instr_3
};

extern Const struct predicate predicate_klic__comp__generate_xgen__out__vars_12;
static Const struct predinfo predinfo_klic__comp__generate_xgen__out__vars_12 = {
  (unsigned char *)"gen_out_vars",
  &predicate_klic__comp__generate_xgen__out__vars_12
};

extern Const struct predicate predicate_klic__comp__generate_xgen__out__var__1_13;
static Const struct predinfo predinfo_klic__comp__generate_xgen__out__var__1_13 = {
  (unsigned char *)"gen_out_var_1",
  &predicate_klic__comp__generate_xgen__out__var__1_13
};

extern Const struct predicate predicate_klic__comp__generate_xgen__out__var_12;
static Const struct predinfo predinfo_klic__comp__generate_xgen__out__var_12 = {
  (unsigned char *)"gen_out_var",
  &predicate_klic__comp__generate_xgen__out__var_12
};

extern Const struct predicate predicate_klic__comp__generate_xgen__new__lab_5;
static Const struct predinfo predinfo_klic__comp__generate_xgen__new__lab_5 = {
  (unsigned char *)"gen_new_lab",
  &predicate_klic__comp__generate_xgen__new__lab_5
};

extern Const struct predicate predicate_klic__comp__generate_xgen__lab_5;
static Const struct predinfo predinfo_klic__comp__generate_xgen__lab_5 = {
  (unsigned char *)"gen_lab",
  &predicate_klic__comp__generate_xgen__lab_5
};

extern Const struct predicate predicate_klic__comp__generate_xgen__if__not_7;
static Const struct predinfo predinfo_klic__comp__generate_xgen__if__not_7 = {
  (unsigned char *)"gen_if_not",
  &predicate_klic__comp__generate_xgen__if__not_7
};

extern Const struct predicate predicate_klic__comp__generate_xgen__gobjs_15;
static Const struct predinfo predinfo_klic__comp__generate_xgen__gobjs_15 = {
  (unsigned char *)"gen_gobjs",
  &predicate_klic__comp__generate_xgen__gobjs_15
};

extern Const struct predicate predicate_klic__comp__generate_xgen__functs_15;
static Const struct predinfo predinfo_klic__comp__generate_xgen__functs_15 = {
  (unsigned char *)"gen_functs",
  &predicate_klic__comp__generate_xgen__functs_15
};

extern Const struct predicate predicate_klic__comp__generate_xgen__cond_12;
static Const struct predinfo predinfo_klic__comp__generate_xgen__cond_12 = {
  (unsigned char *)"gen_cond",
  &predicate_klic__comp__generate_xgen__cond_12
};

extern Const struct predicate predicate_klic__comp__generate_xgen__code__3__3_14;
static Const struct predinfo predinfo_klic__comp__generate_xgen__code__3__3_14 = {
  (unsigned char *)"gen_code_3_3",
  &predicate_klic__comp__generate_xgen__code__3__3_14
};

extern Const struct predicate predicate_klic__comp__generate_xgen__code__3__2_14;
static Const struct predinfo predinfo_klic__comp__generate_xgen__code__3__2_14 = {
  (unsigned char *)"gen_code_3_2",
  &predicate_klic__comp__generate_xgen__code__3__2_14
};

extern Const struct predicate predicate_klic__comp__generate_xgen__code__3__1_14;
static Const struct predinfo predinfo_klic__comp__generate_xgen__code__3__1_14 = {
  (unsigned char *)"gen_code_3_1",
  &predicate_klic__comp__generate_xgen__code__3__1_14
};

extern Const struct predicate predicate_klic__comp__generate_xgen__code__3_14;
static Const struct predinfo predinfo_klic__comp__generate_xgen__code__3_14 = {
  (unsigned char *)"gen_code_3",
  &predicate_klic__comp__generate_xgen__code__3_14
};

extern Const struct predicate predicate_klic__comp__generate_xgen__code__1_15;
static Const struct predinfo predinfo_klic__comp__generate_xgen__code__1_15 = {
  (unsigned char *)"gen_code_1",
  &predicate_klic__comp__generate_xgen__code__1_15
};

extern Const struct predicate predicate_klic__comp__generate_xgen__code_14;
static Const struct predinfo predinfo_klic__comp__generate_xgen__code_14 = {
  (unsigned char *)"gen_code",
  &predicate_klic__comp__generate_xgen__code_14
};

extern Const struct predicate predicate_klic__comp__generate_xgen__classes_15;
static Const struct predinfo predinfo_klic__comp__generate_xgen__classes_15 = {
  (unsigned char *)"gen_classes",
  &predicate_klic__comp__generate_xgen__classes_15
};

extern Const struct predicate predicate_klic__comp__generate_xgen__cases_16;
static Const struct predinfo predinfo_klic__comp__generate_xgen__cases_16 = {
  (unsigned char *)"gen_cases",
  &predicate_klic__comp__generate_xgen__cases_16
};

extern Const struct predicate predicate_klic__comp__generate_xgen__case__lab_5;
static Const struct predinfo predinfo_klic__comp__generate_xgen__case__lab_5 = {
  (unsigned char *)"gen_case_lab",
  &predicate_klic__comp__generate_xgen__case__lab_5
};

extern Const struct predicate predicate_klic__comp__generate_xgen__body__goal_13;
static Const struct predinfo predinfo_klic__comp__generate_xgen__body__goal_13 = {
  (unsigned char *)"gen_body_goal",
  &predicate_klic__comp__generate_xgen__body__goal_13
};

extern Const struct predicate predicate_klic__comp__generate_xgen__body__arg__1_12;
static Const struct predinfo predinfo_klic__comp__generate_xgen__body__arg__1_12 = {
  (unsigned char *)"gen_body_arg_1",
  &predicate_klic__comp__generate_xgen__body__arg__1_12
};

extern Const struct predicate predicate_klic__comp__generate_xgen__body__arg_12;
static Const struct predinfo predinfo_klic__comp__generate_xgen__body__arg_12 = {
  (unsigned char *)"gen_body_arg",
  &predicate_klic__comp__generate_xgen__body__arg_12
};

extern Const struct predicate predicate_klic__comp__generate_xgen__body_14;
static Const struct predinfo predinfo_klic__comp__generate_xgen__body_14 = {
  (unsigned char *)"gen_body",
  &predicate_klic__comp__generate_xgen__body_14
};

extern Const struct predicate predicate_klic__comp__generate_xgen__atomic__2_20;
static Const struct predinfo predinfo_klic__comp__generate_xgen__atomic__2_20 = {
  (unsigned char *)"gen_atomic_2",
  &predicate_klic__comp__generate_xgen__atomic__2_20
};

extern Const struct predicate predicate_klic__comp__generate_xgen__atomic_2F15_240_2F18_240_13;
static Const struct predinfo predinfo_klic__comp__generate_xgen__atomic_2F15_240_2F18_240_13 = {
  (unsigned char *)"gen_atomic/15$0/18$0",
  &predicate_klic__comp__generate_xgen__atomic_2F15_240_2F18_240_13
};

extern Const struct predicate predicate_klic__comp__generate_xgen__atomic_2F15_240_18;
static Const struct predinfo predinfo_klic__comp__generate_xgen__atomic_2F15_240_18 = {
  (unsigned char *)"gen_atomic/15$0",
  &predicate_klic__comp__generate_xgen__atomic_2F15_240_18
};

extern Const struct predicate predicate_klic__comp__generate_xgen__atomic_15;
static Const struct predinfo predinfo_klic__comp__generate_xgen__atomic_15 = {
  (unsigned char *)"gen_atomic",
  &predicate_klic__comp__generate_xgen__atomic_15
};

extern Const struct predicate predicate_klic__comp__generate_xgen__all__cases_14;
static Const struct predinfo predinfo_klic__comp__generate_xgen__all__cases_14 = {
  (unsigned char *)"gen_all_cases",
  &predicate_klic__comp__generate_xgen__all__cases_14
};

extern Const struct predicate predicate_klic__comp__generate_xfunctor__type_2;
static Const struct predinfo predinfo_klic__comp__generate_xfunctor__type_2 = {
  (unsigned char *)"functor_type",
  &predicate_klic__comp__generate_xfunctor__type_2
};

extern Const struct predicate predicate_klic__comp__generate_xexit_1;
static Const struct predinfo predinfo_klic__comp__generate_xexit_1 = {
  (unsigned char *)"exit",
  &predicate_klic__comp__generate_xexit_1
};

extern Const struct predicate predicate_klic__comp__generate_xenq__at__prio_12;
static Const struct predinfo predinfo_klic__comp__generate_xenq__at__prio_12 = {
  (unsigned char *)"enq_at_prio",
  &predicate_klic__comp__generate_xenq__at__prio_12
};

extern Const struct predicate predicate_klic__comp__generate_xcount__arity__of__normal__call_6;
static Const struct predinfo predinfo_klic__comp__generate_xcount__arity__of__normal__call_6 = {
  (unsigned char *)"count_arity_of_normal_call",
  &predicate_klic__comp__generate_xcount__arity__of__normal__call_6
};

extern Const struct predicate predicate_klic__comp__generate_xcase__info_7;
static Const struct predinfo predinfo_klic__comp__generate_xcase__info_7 = {
  (unsigned char *)"case_info",
  &predicate_klic__comp__generate_xcase__info_7
};

extern Const struct predicate predicate_klic__comp__generate_xbody__unify__2_7;
static Const struct predinfo predinfo_klic__comp__generate_xbody__unify__2_7 = {
  (unsigned char *)"body_unify_2",
  &predicate_klic__comp__generate_xbody__unify__2_7
};

extern Const struct predicate predicate_klic__comp__generate_xbody__unify__1_11;
static Const struct predinfo predinfo_klic__comp__generate_xbody__unify__1_11 = {
  (unsigned char *)"body_unify_1",
  &predicate_klic__comp__generate_xbody__unify__1_11
};

extern Const struct predicate predicate_klic__comp__generate_xbody__unify_12;
static Const struct predinfo predinfo_klic__comp__generate_xbody__unify_12 = {
  (unsigned char *)"body_unify",
  &predicate_klic__comp__generate_xbody__unify_12
};

extern Const struct predicate predicate_klic__comp__generate_xbb__out__type_3;
static Const struct predinfo predinfo_klic__comp__generate_xbb__out__type_3 = {
  (unsigned char *)"bb_out_type",
  &predicate_klic__comp__generate_xbb__out__type_3
};

extern Const struct predicate predicate_klic__comp__generate_xbb__out_14;
static Const struct predinfo predinfo_klic__comp__generate_xbb__out_14 = {
  (unsigned char *)"bb_out",
  &predicate_klic__comp__generate_xbb__out_14
};

extern Const struct predicate predicate_klic__comp__generate_xbb__in__type_3;
static Const struct predinfo predinfo_klic__comp__generate_xbb__in__type_3 = {
  (unsigned char *)"bb_in_type",
  &predicate_klic__comp__generate_xbb__in__type_3
};

extern Const struct predicate predicate_klic__comp__generate_xbb__in__check_4;
static Const struct predinfo predinfo_klic__comp__generate_xbb__in__check_4 = {
  (unsigned char *)"bb_in_check",
  &predicate_klic__comp__generate_xbb__in__check_4
};

extern Const struct predicate predicate_klic__comp__generate_xbb__in_14;
static Const struct predinfo predinfo_klic__comp__generate_xbb__in_14 = {
  (unsigned char *)"bb_in",
  &predicate_klic__comp__generate_xbb__in_14
};

extern Const struct predicate predicate_klic__comp__generate_xbasic__type_2;
static Const struct predinfo predinfo_klic__comp__generate_xbasic__type_2 = {
  (unsigned char *)"basic_type",
  &predicate_klic__comp__generate_xbasic__type_2
};

extern Const struct predicate predicate_klic__comp__generate_xatomic__type_2;
static Const struct predinfo predinfo_klic__comp__generate_xatomic__type_2 = {
  (unsigned char *)"atomic_type",
  &predicate_klic__comp__generate_xatomic__type_2
};

extern Const struct predicate predicate_klic__comp__generate_xassocx__for__set__tmake_3;
static Const struct predinfo predinfo_klic__comp__generate_xassocx__for__set__tmake_3 = {
  (unsigned char *)"assocx_for_set_tmake",
  &predicate_klic__comp__generate_xassocx__for__set__tmake_3
};

extern Const struct predicate predicate_klic__comp__generate_xassocx_3;
static Const struct predinfo predinfo_klic__comp__generate_xassocx_3 = {
  (unsigned char *)"assocx",
  &predicate_klic__comp__generate_xassocx_3
};

extern Const struct predicate predicate_klic__comp__generate_xappend_3;
static Const struct predinfo predinfo_klic__comp__generate_xappend_3 = {
  (unsigned char *)"append",
  &predicate_klic__comp__generate_xappend_3
};

extern Const struct predicate predicate_klic__comp__generate_xalloc__one__for__struct__1_13;
static Const struct predinfo predinfo_klic__comp__generate_xalloc__one__for__struct__1_13 = {
  (unsigned char *)"alloc_one_for_struct_1",
  &predicate_klic__comp__generate_xalloc__one__for__struct__1_13
};

extern Const struct predicate predicate_klic__comp__generate_xalloc__one__for__struct_13;
static Const struct predinfo predinfo_klic__comp__generate_xalloc__one__for__struct_13 = {
  (unsigned char *)"alloc_one_for_struct",
  &predicate_klic__comp__generate_xalloc__one__for__struct_13
};

extern Const struct predicate predicate_klic__comp__generate_xalloc__if__var_8;
static Const struct predinfo predinfo_klic__comp__generate_xalloc__if__var_8 = {
  (unsigned char *)"alloc_if_var",
  &predicate_klic__comp__generate_xalloc__if__var_8
};

extern Const struct predicate predicate_klic__comp__generate_xalloc__args__for__struct_13;
static Const struct predinfo predinfo_klic__comp__generate_xalloc__args__for__struct_13 = {
  (unsigned char *)"alloc_args_for_struct",
  &predicate_klic__comp__generate_xalloc__args__for__struct_13
};

extern Const struct predicate predicate_klic__comp__generate_xadd__inline__info_3;
static Const struct predinfo predinfo_klic__comp__generate_xadd__inline__info_3 = {
  (unsigned char *)"add_inline_info",
  &predicate_klic__comp__generate_xadd__inline__info_3
};

extern Const struct predicate predicate_klic__comp__generate_xadd__info_4;
static Const struct predinfo predinfo_klic__comp__generate_xadd__info_4 = {
  (unsigned char *)"add_info",
  &predicate_klic__comp__generate_xadd__info_4
};

static Const struct predinfo * Const preds_in_klic__comp__generate[] = {
  &predinfo_klic__comp__generate_xused__in__1_5,
  &predinfo_klic__comp__generate_xused__in_4,
  &predinfo_klic__comp__generate_xstrip__types_2,
  &predinfo_klic__comp__generate_xstrip__type_2,
  &predinfo_klic__comp__generate_xset__one__1_10,
  &predinfo_klic__comp__generate_xset__one_10,
  &predinfo_klic__comp__generate_xset__generic__args_10,
  &predinfo_klic__comp__generate_xset__call__merge_3,
  &predinfo_klic__comp__generate_xset__call_10,
  &predinfo_klic__comp__generate_xset__args__for__newthread_10,
  &predinfo_klic__comp__generate_xset__args_10,
  &predinfo_klic__comp__generate_xreverse_3,
  &predinfo_klic__comp__generate_xrassoc_3,
  &predinfo_klic__comp__generate_xput__srec_6,
  &predinfo_klic__comp__generate_xput__one__1_12,
  &predinfo_klic__comp__generate_xput__one_12,
  &predinfo_klic__comp__generate_xput__call_11,
  &predinfo_klic__comp__generate_xput__args_12,
  &predinfo_klic__comp__generate_xpush__tcall_11,
  &predinfo_klic__comp__generate_xprio__code_7,
  &predinfo_klic__comp__generate_xprint__data_2,
  &predinfo_klic__comp__generate_xprep__vec__elems_10,
  &predinfo_klic__comp__generate_xprep__poss__for__set__tmake_10,
  &predinfo_klic__comp__generate_xprep__poss_10,
  &predinfo_klic__comp__generate_xprep__pos__for__set__tmake_10,
  &predinfo_klic__comp__generate_xprep__pos__1_10,
  &predinfo_klic__comp__generate_xprep__pos_10,
  &predinfo_klic__comp__generate_xprep__call__arg_10,
  &predinfo_klic__comp__generate_xmove__one__1_10,
  &predinfo_klic__comp__generate_xmove__one_10,
  &predinfo_klic__comp__generate_xmove__args__1_12,
  &predinfo_klic__comp__generate_xmove__args_10,
  &predinfo_klic__comp__generate_xmake__var_7,
  &predinfo_klic__comp__generate_xmake__label_2,
  &predinfo_klic__comp__generate_xload__reg__2_11,
  &predinfo_klic__comp__generate_xload__reg__1_11,
  &predinfo_klic__comp__generate_xload__reg_11,
  &predinfo_klic__comp__generate_xload__pos_10,
  &predinfo_klic__comp__generate_xload__inline__args_11,
  &predinfo_klic__comp__generate_xload__guard__generic__out_11,
  &predinfo_klic__comp__generate_xgen__type__known_3,
  &predinfo_klic__comp__generate_xgen__type__code_18,
  &predinfo_klic__comp__generate_xgen__sw__instr_3,
  &predinfo_klic__comp__generate_xgen__out__vars_12,
  &predinfo_klic__comp__generate_xgen__out__var__1_13,
  &predinfo_klic__comp__generate_xgen__out__var_12,
  &predinfo_klic__comp__generate_xgen__new__lab_5,
  &predinfo_klic__comp__generate_xgen__lab_5,
  &predinfo_klic__comp__generate_xgen__if__not_7,
  &predinfo_klic__comp__generate_xgen__gobjs_15,
  &predinfo_klic__comp__generate_xgen__functs_15,
  &predinfo_klic__comp__generate_xgen__cond_12,
  &predinfo_klic__comp__generate_xgen__code__3__3_14,
  &predinfo_klic__comp__generate_xgen__code__3__2_14,
  &predinfo_klic__comp__generate_xgen__code__3__1_14,
  &predinfo_klic__comp__generate_xgen__code__3_14,
  &predinfo_klic__comp__generate_xgen__code__1_15,
  &predinfo_klic__comp__generate_xgen__code_14,
  &predinfo_klic__comp__generate_xgen__classes_15,
  &predinfo_klic__comp__generate_xgen__cases_16,
  &predinfo_klic__comp__generate_xgen__case__lab_5,
  &predinfo_klic__comp__generate_xgen__body__goal_13,
  &predinfo_klic__comp__generate_xgen__body__arg__1_12,
  &predinfo_klic__comp__generate_xgen__body__arg_12,
  &predinfo_klic__comp__generate_xgen__body_14,
  &predinfo_klic__comp__generate_xgen__atomic__2_20,
  &predinfo_klic__comp__generate_xgen__atomic_2F15_240_2F18_240_13,
  &predinfo_klic__comp__generate_xgen__atomic_2F15_240_18,
  &predinfo_klic__comp__generate_xgen__atomic_15,
  &predinfo_klic__comp__generate_xgen__all__cases_14,
  &predinfo_klic__comp__generate_xfunctor__type_2,
  &predinfo_klic__comp__generate_xexit_1,
  &predinfo_klic__comp__generate_xenq__at__prio_12,
  &predinfo_klic__comp__generate_xcount__arity__of__normal__call_6,
  &predinfo_klic__comp__generate_xcase__info_7,
  &predinfo_klic__comp__generate_xbody__unify__2_7,
  &predinfo_klic__comp__generate_xbody__unify__1_11,
  &predinfo_klic__comp__generate_xbody__unify_12,
  &predinfo_klic__comp__generate_xbb__out__type_3,
  &predinfo_klic__comp__generate_xbb__out_14,
  &predinfo_klic__comp__generate_xbb__in__type_3,
  &predinfo_klic__comp__generate_xbb__in__check_4,
  &predinfo_klic__comp__generate_xbb__in_14,
  &predinfo_klic__comp__generate_xbasic__type_2,
  &predinfo_klic__comp__generate_xatomic__type_2,
  &predinfo_klic__comp__generate_xassocx__for__set__tmake_3,
  &predinfo_klic__comp__generate_xassocx_3,
  &predinfo_klic__comp__generate_xappend_3,
  &predinfo_klic__comp__generate_xalloc__one__for__struct__1_13,
  &predinfo_klic__comp__generate_xalloc__one__for__struct_13,
  &predinfo_klic__comp__generate_xalloc__if__var_8,
  &predinfo_klic__comp__generate_xalloc__args__for__struct_13,
  &predinfo_klic__comp__generate_xadd__inline__info_3,
  &predinfo_klic__comp__generate_xadd__info_4,
  0
};
extern Const struct predicate predicate_scanner_xungetc_3;
static Const struct predinfo predinfo_scanner_xungetc_3 = {
  (unsigned char *)"ungetc",
  &predicate_scanner_xungetc_3
};

extern Const struct predicate predicate_scanner_xscan__unsigned__exponent_9;
static Const struct predinfo predinfo_scanner_xscan__unsigned__exponent_9 = {
  (unsigned char *)"scan_unsigned_exponent",
  &predicate_scanner_xscan__unsigned__exponent_9
};

extern Const struct predicate predicate_scanner_xscan__string_8;
static Const struct predinfo predinfo_scanner_xscan__string_8 = {
  (unsigned char *)"scan_string",
  &predicate_scanner_xscan__string_8
};

extern Const struct predicate predicate_scanner_xscan__string_2F8_240_8;
static Const struct predinfo predinfo_scanner_xscan__string_2F8_240_8 = {
  (unsigned char *)"scan_string/8$0",
  &predicate_scanner_xscan__string_2F8_240_8
};

extern Const struct predicate predicate_scanner_xscan__sname_7;
static Const struct predinfo predinfo_scanner_xscan__sname_7 = {
  (unsigned char *)"scan_sname",
  &predicate_scanner_xscan__sname_7
};

extern Const struct predicate predicate_scanner_xscan__rest_4;
static Const struct predinfo predinfo_scanner_xscan__rest_4 = {
  (unsigned char *)"scan_rest",
  &predicate_scanner_xscan__rest_4
};

extern Const struct predicate predicate_scanner_xscan__octal__escape__2_9;
static Const struct predinfo predinfo_scanner_xscan__octal__escape__2_9 = {
  (unsigned char *)"scan_octal_escape_2",
  &predicate_scanner_xscan__octal__escape__2_9
};

extern Const struct predicate predicate_scanner_xscan__octal__escape__2_2F9_240_9;
static Const struct predinfo predinfo_scanner_xscan__octal__escape__2_2F9_240_9 = {
  (unsigned char *)"scan_octal_escape_2/9$0",
  &predicate_scanner_xscan__octal__escape__2_2F9_240_9
};

extern Const struct predicate predicate_scanner_xscan__octal__escape_9;
static Const struct predinfo predinfo_scanner_xscan__octal__escape_9 = {
  (unsigned char *)"scan_octal_escape",
  &predicate_scanner_xscan__octal__escape_9
};

extern Const struct predicate predicate_scanner_xscan__number_9;
static Const struct predinfo predinfo_scanner_xscan__number_9 = {
  (unsigned char *)"scan_number",
  &predicate_scanner_xscan__number_9
};

extern Const struct predicate predicate_scanner_xscan__number_2F9_241_8;
static Const struct predinfo predinfo_scanner_xscan__number_2F9_241_8 = {
  (unsigned char *)"scan_number/9$1",
  &predicate_scanner_xscan__number_2F9_241_8
};

extern Const struct predicate predicate_scanner_xscan__number_2F9_240_9;
static Const struct predinfo predinfo_scanner_xscan__number_2F9_240_9 = {
  (unsigned char *)"scan_number/9$0",
  &predicate_scanner_xscan__number_2F9_240_9
};

extern Const struct predicate predicate_scanner_xscan__name_7;
static Const struct predinfo predinfo_scanner_xscan__name_7 = {
  (unsigned char *)"scan_name",
  &predicate_scanner_xscan__name_7
};

extern Const struct predicate predicate_scanner_xscan__hex__escape_9;
static Const struct predinfo predinfo_scanner_xscan__hex__escape_9 = {
  (unsigned char *)"scan_hex_escape",
  &predicate_scanner_xscan__hex__escape_9
};

extern Const struct predicate predicate_scanner_xscan__fraction_9;
static Const struct predinfo predinfo_scanner_xscan__fraction_9 = {
  (unsigned char *)"scan_fraction",
  &predicate_scanner_xscan__fraction_9
};

extern Const struct predicate predicate_scanner_xscan__fraction_2F9_240_11;
static Const struct predinfo predinfo_scanner_xscan__fraction_2F9_240_11 = {
  (unsigned char *)"scan_fraction/9$0",
  &predicate_scanner_xscan__fraction_2F9_240_11
};

extern Const struct predicate predicate_scanner_xscan__exponent_9;
static Const struct predinfo predinfo_scanner_xscan__exponent_9 = {
  (unsigned char *)"scan_exponent",
  &predicate_scanner_xscan__exponent_9
};

extern Const struct predicate predicate_scanner_xscan__escape_8;
static Const struct predinfo predinfo_scanner_xscan__escape_8 = {
  (unsigned char *)"scan_escape",
  &predicate_scanner_xscan__escape_8
};

extern Const struct predicate predicate_scanner_xscan__comment__line_5;
static Const struct predinfo predinfo_scanner_xscan__comment__line_5 = {
  (unsigned char *)"scan_comment_line",
  &predicate_scanner_xscan__comment__line_5
};

extern Const struct predicate predicate_scanner_xscan__comment_5;
static Const struct predinfo predinfo_scanner_xscan__comment_5 = {
  (unsigned char *)"scan_comment",
  &predicate_scanner_xscan__comment_5
};

extern Const struct predicate predicate_scanner_xscan__comment_2F5_240_5;
static Const struct predinfo predinfo_scanner_xscan__comment_2F5_240_5 = {
  (unsigned char *)"scan_comment/5$0",
  &predicate_scanner_xscan__comment_2F5_240_5
};

extern Const struct predicate predicate_scanner_xscan__based__number_9;
static Const struct predinfo predinfo_scanner_xscan__based__number_9 = {
  (unsigned char *)"scan_based_number",
  &predicate_scanner_xscan__based__number_9
};

extern Const struct predicate predicate_scanner_xscan__based__number_2F9_242_9;
static Const struct predinfo predinfo_scanner_xscan__based__number_2F9_242_9 = {
  (unsigned char *)"scan_based_number/9$2",
  &predicate_scanner_xscan__based__number_2F9_242_9
};

extern Const struct predicate predicate_scanner_xscan__based__number_2F9_241_9;
static Const struct predinfo predinfo_scanner_xscan__based__number_2F9_241_9 = {
  (unsigned char *)"scan_based_number/9$1",
  &predicate_scanner_xscan__based__number_2F9_241_9
};

extern Const struct predicate predicate_scanner_xscan__based__number_2F9_240_9;
static Const struct predinfo predinfo_scanner_xscan__based__number_2F9_240_9 = {
  (unsigned char *)"scan_based_number/9$0",
  &predicate_scanner_xscan__based__number_2F9_240_9
};

extern Const struct predicate predicate_scanner_xscan__after__atom_8;
static Const struct predinfo predinfo_scanner_xscan__after__atom_8 = {
  (unsigned char *)"scan_after_atom",
  &predicate_scanner_xscan__after__atom_8
};

extern Const struct predicate predicate_scanner_xscan_6;
static Const struct predinfo predinfo_scanner_xscan_6 = {
  (unsigned char *)"scan",
  &predicate_scanner_xscan_6
};

extern Const struct predicate predicate_scanner_xscan_3;
static Const struct predinfo predinfo_scanner_xscan_3 = {
  (unsigned char *)"scan",
  &predicate_scanner_xscan_3
};

extern Const struct predicate predicate_scanner_xscan_2F6_243_7;
static Const struct predinfo predinfo_scanner_xscan_2F6_243_7 = {
  (unsigned char *)"scan/6$3",
  &predicate_scanner_xscan_2F6_243_7
};

extern Const struct predicate predicate_scanner_xscan_2F6_243_2F7_240_7;
static Const struct predinfo predinfo_scanner_xscan_2F6_243_2F7_240_7 = {
  (unsigned char *)"scan/6$3/7$0",
  &predicate_scanner_xscan_2F6_243_2F7_240_7
};

extern Const struct predicate predicate_scanner_xscan_2F6_242_8;
static Const struct predinfo predinfo_scanner_xscan_2F6_242_8 = {
  (unsigned char *)"scan/6$2",
  &predicate_scanner_xscan_2F6_242_8
};

extern Const struct predicate predicate_scanner_xscan_2F6_241_8;
static Const struct predinfo predinfo_scanner_xscan_2F6_241_8 = {
  (unsigned char *)"scan/6$1",
  &predicate_scanner_xscan_2F6_241_8
};

extern Const struct predicate predicate_scanner_xscan_2F6_240_6;
static Const struct predinfo predinfo_scanner_xscan_2F6_240_6 = {
  (unsigned char *)"scan/6$0",
  &predicate_scanner_xscan_2F6_240_6
};

extern Const struct predicate predicate_scanner_xmake__new__string_2;
static Const struct predinfo predinfo_scanner_xmake__new__string_2 = {
  (unsigned char *)"make_new_string",
  &predicate_scanner_xmake__new__string_2
};

extern Const struct predicate predicate_scanner_xlookup__var_8;
static Const struct predinfo predinfo_scanner_xlookup__var_8 = {
  (unsigned char *)"lookup_var",
  &predicate_scanner_xlookup__var_8
};

extern Const struct predicate predicate_scanner_xgetchar_4;
static Const struct predinfo predinfo_scanner_xgetchar_4 = {
  (unsigned char *)"getchar",
  &predicate_scanner_xgetchar_4
};

extern Const struct predicate predicate_scanner_xget0_3;
static Const struct predinfo predinfo_scanner_xget0_3 = {
  (unsigned char *)"get0",
  &predicate_scanner_xget0_3
};

extern Const struct predicate predicate_scanner_xfinalize__vars_2F1_240_2;
static Const struct predinfo predinfo_scanner_xfinalize__vars_2F1_240_2 = {
  (unsigned char *)"finalize_vars/1$0",
  &predicate_scanner_xfinalize__vars_2F1_240_2
};

extern Const struct predicate predicate_scanner_xfinalize__vars_1;
static Const struct predinfo predinfo_scanner_xfinalize__vars_1 = {
  (unsigned char *)"finalize_vars",
  &predicate_scanner_xfinalize__vars_1
};

extern Const struct predicate predicate_scanner_xescape__char_2;
static Const struct predinfo predinfo_scanner_xescape__char_2 = {
  (unsigned char *)"escape_char",
  &predicate_scanner_xescape__char_2
};

extern Const struct predicate predicate_scanner_xchartype_2;
static Const struct predinfo predinfo_scanner_xchartype_2 = {
  (unsigned char *)"chartype",
  &predicate_scanner_xchartype_2
};

extern Const struct predicate predicate_scanner_xchar__list__to__int_3;
static Const struct predinfo predinfo_scanner_xchar__list__to__int_3 = {
  (unsigned char *)"char_list_to_int",
  &predicate_scanner_xchar__list__to__int_3
};

extern Const struct predicate predicate_scanner_xchar__list__to__float_3;
static Const struct predinfo predinfo_scanner_xchar__list__to__float_3 = {
  (unsigned char *)"char_list_to_float",
  &predicate_scanner_xchar__list__to__float_3
};

extern Const struct predicate predicate_scanner_xatom__chars_2;
static Const struct predinfo predinfo_scanner_xatom__chars_2 = {
  (unsigned char *)"atom_chars",
  &predicate_scanner_xatom__chars_2
};

static Const struct predinfo * Const preds_in_scanner[] = {
  &predinfo_scanner_xungetc_3,
  &predinfo_scanner_xscan__unsigned__exponent_9,
  &predinfo_scanner_xscan__string_8,
  &predinfo_scanner_xscan__string_2F8_240_8,
  &predinfo_scanner_xscan__sname_7,
  &predinfo_scanner_xscan__rest_4,
  &predinfo_scanner_xscan__octal__escape__2_9,
  &predinfo_scanner_xscan__octal__escape__2_2F9_240_9,
  &predinfo_scanner_xscan__octal__escape_9,
  &predinfo_scanner_xscan__number_9,
  &predinfo_scanner_xscan__number_2F9_241_8,
  &predinfo_scanner_xscan__number_2F9_240_9,
  &predinfo_scanner_xscan__name_7,
  &predinfo_scanner_xscan__hex__escape_9,
  &predinfo_scanner_xscan__fraction_9,
  &predinfo_scanner_xscan__fraction_2F9_240_11,
  &predinfo_scanner_xscan__exponent_9,
  &predinfo_scanner_xscan__escape_8,
  &predinfo_scanner_xscan__comment__line_5,
  &predinfo_scanner_xscan__comment_5,
  &predinfo_scanner_xscan__comment_2F5_240_5,
  &predinfo_scanner_xscan__based__number_9,
  &predinfo_scanner_xscan__based__number_2F9_242_9,
  &predinfo_scanner_xscan__based__number_2F9_241_9,
  &predinfo_scanner_xscan__based__number_2F9_240_9,
  &predinfo_scanner_xscan__after__atom_8,
  &predinfo_scanner_xscan_6,
  &predinfo_scanner_xscan_3,
  &predinfo_scanner_xscan_2F6_243_7,
  &predinfo_scanner_xscan_2F6_243_2F7_240_7,
  &predinfo_scanner_xscan_2F6_242_8,
  &predinfo_scanner_xscan_2F6_241_8,
  &predinfo_scanner_xscan_2F6_240_6,
  &predinfo_scanner_xmake__new__string_2,
  &predinfo_scanner_xlookup__var_8,
  &predinfo_scanner_xgetchar_4,
  &predinfo_scanner_xget0_3,
  &predinfo_scanner_xfinalize__vars_2F1_240_2,
  &predinfo_scanner_xfinalize__vars_1,
  &predinfo_scanner_xescape__char_2,
  &predinfo_scanner_xchartype_2,
  &predinfo_scanner_xchar__list__to__int_3,
  &predinfo_scanner_xchar__list__to__float_3,
  &predinfo_scanner_xatom__chars_2,
  0
};
extern Const struct predicate predicate_unparser_xunwparse__cons_5;
static Const struct predinfo predinfo_unparser_xunwparse__cons_5 = {
  (unsigned char *)"unwparse_cons",
  &predicate_unparser_xunwparse__cons_5
};

extern Const struct predicate predicate_unparser_xunwparse__cdr_5;
static Const struct predinfo predinfo_unparser_xunwparse__cdr_5 = {
  (unsigned char *)"unwparse_cdr",
  &predicate_unparser_xunwparse__cdr_5
};

extern Const struct predicate predicate_unparser_xunwparse_6;
static Const struct predinfo predinfo_unparser_xunwparse_6 = {
  (unsigned char *)"unwparse",
  &predicate_unparser_xunwparse_6
};

extern Const struct predicate predicate_unparser_xunwparse_4;
static Const struct predinfo predinfo_unparser_xunwparse_4 = {
  (unsigned char *)"unwparse",
  &predicate_unparser_xunwparse_4
};

extern Const struct predicate predicate_unparser_xunscan__after__op_4;
static Const struct predinfo predinfo_unparser_xunscan__after__op_4 = {
  (unsigned char *)"unscan_after_op",
  &predicate_unparser_xunscan__after__op_4
};

extern Const struct predicate predicate_unparser_xunscan_4;
static Const struct predinfo predinfo_unparser_xunscan_4 = {
  (unsigned char *)"unscan",
  &predicate_unparser_xunscan_4
};

extern Const struct predicate predicate_unparser_xunparse__with__op_10;
static Const struct predinfo predinfo_unparser_xunparse__with__op_10 = {
  (unsigned char *)"unparse_with_op",
  &predicate_unparser_xunparse__with__op_10
};

extern Const struct predicate predicate_unparser_xunparse__vector_5;
static Const struct predinfo predinfo_unparser_xunparse__vector_5 = {
  (unsigned char *)"unparse_vector",
  &predicate_unparser_xunparse__vector_5
};

extern Const struct predicate predicate_unparser_xunparse__vecelems_7;
static Const struct predinfo predinfo_unparser_xunparse__vecelems_7 = {
  (unsigned char *)"unparse_vecelems",
  &predicate_unparser_xunparse__vecelems_7
};

extern Const struct predicate predicate_unparser_xunparse__string_3;
static Const struct predinfo predinfo_unparser_xunparse__string_3 = {
  (unsigned char *)"unparse_string",
  &predicate_unparser_xunparse__string_3
};

extern Const struct predicate predicate_unparser_xunparse__int_3;
static Const struct predinfo predinfo_unparser_xunparse__int_3 = {
  (unsigned char *)"unparse_int",
  &predicate_unparser_xunparse__int_3
};

extern Const struct predicate predicate_unparser_xunparse__general_6;
static Const struct predinfo predinfo_unparser_xunparse__general_6 = {
  (unsigned char *)"unparse_general",
  &predicate_unparser_xunparse__general_6
};

extern Const struct predicate predicate_unparser_xunparse__float_3;
static Const struct predinfo predinfo_unparser_xunparse__float_3 = {
  (unsigned char *)"unparse_float",
  &predicate_unparser_xunparse__float_3
};

extern Const struct predicate predicate_unparser_xunparse__elems_7;
static Const struct predinfo predinfo_unparser_xunparse__elems_7 = {
  (unsigned char *)"unparse_elems",
  &predicate_unparser_xunparse__elems_7
};

extern Const struct predicate predicate_unparser_xunparse__cons_5;
static Const struct predinfo predinfo_unparser_xunparse__cons_5 = {
  (unsigned char *)"unparse_cons",
  &predicate_unparser_xunparse__cons_5
};

extern Const struct predicate predicate_unparser_xunparse__comma__list__elem_5;
static Const struct predinfo predinfo_unparser_xunparse__comma__list__elem_5 = {
  (unsigned char *)"unparse_comma_list_elem",
  &predicate_unparser_xunparse__comma__list__elem_5
};

extern Const struct predicate predicate_unparser_xunparse__cdr_5;
static Const struct predinfo predinfo_unparser_xunparse__cdr_5 = {
  (unsigned char *)"unparse_cdr",
  &predicate_unparser_xunparse__cdr_5
};

extern Const struct predicate predicate_unparser_xunparse__bin__op_3;
static Const struct predinfo predinfo_unparser_xunparse__bin__op_3 = {
  (unsigned char *)"unparse_bin_op",
  &predicate_unparser_xunparse__bin__op_3
};

extern Const struct predicate predicate_unparser_xunparse__atom_3;
static Const struct predinfo predinfo_unparser_xunparse__atom_3 = {
  (unsigned char *)"unparse_atom",
  &predicate_unparser_xunparse__atom_3
};

extern Const struct predicate predicate_unparser_xunparse_6;
static Const struct predinfo predinfo_unparser_xunparse_6 = {
  (unsigned char *)"unparse",
  &predicate_unparser_xunparse_6
};

extern Const struct predicate predicate_unparser_xunparse_4;
static Const struct predinfo predinfo_unparser_xunparse_4 = {
  (unsigned char *)"unparse",
  &predicate_unparser_xunparse_4
};

extern Const struct predicate predicate_unparser_xstr__elem__chars_3;
static Const struct predinfo predinfo_unparser_xstr__elem__chars_3 = {
  (unsigned char *)"str_elem_chars",
  &predicate_unparser_xstr__elem__chars_3
};

extern Const struct predicate predicate_unparser_xstr__chars_5;
static Const struct predinfo predinfo_unparser_xstr__chars_5 = {
  (unsigned char *)"str_chars",
  &predicate_unparser_xstr__chars_5
};

extern Const struct predicate predicate_unparser_xquoted__atom__chars_4;
static Const struct predinfo predinfo_unparser_xquoted__atom__chars_4 = {
  (unsigned char *)"quoted_atom_chars",
  &predicate_unparser_xquoted__atom__chars_4
};

extern Const struct predicate predicate_unparser_xquoted__atom__chars_2F4_240_3;
static Const struct predinfo predinfo_unparser_xquoted__atom__chars_2F4_240_3 = {
  (unsigned char *)"quoted_atom_chars/4$0",
  &predicate_unparser_xquoted__atom__chars_2F4_240_3
};

extern Const struct predicate predicate_unparser_xmax__op_4;
static Const struct predinfo predinfo_unparser_xmax__op_4 = {
  (unsigned char *)"max_op",
  &predicate_unparser_xmax__op_4
};

extern Const struct predicate predicate_unparser_xmax_3;
static Const struct predinfo predinfo_unparser_xmax_3 = {
  (unsigned char *)"max",
  &predicate_unparser_xmax_3
};

extern Const struct predicate predicate_unparser_xmake__atom__string_4;
static Const struct predinfo predinfo_unparser_xmake__atom__string_4 = {
  (unsigned char *)"make_atom_string",
  &predicate_unparser_xmake__atom__string_4
};

extern Const struct predicate predicate_unparser_xjudge__quoted_6;
static Const struct predinfo predinfo_unparser_xjudge__quoted_6 = {
  (unsigned char *)"judge_quoted",
  &predicate_unparser_xjudge__quoted_6
};

extern Const struct predicate predicate_unparser_xint__chars_3;
static Const struct predinfo predinfo_unparser_xint__chars_3 = {
  (unsigned char *)"int_chars",
  &predicate_unparser_xint__chars_3
};

extern Const struct predicate predicate_unparser_xins__if__greater__than_5;
static Const struct predinfo predinfo_unparser_xins__if__greater__than_5 = {
  (unsigned char *)"ins_if_greater_than",
  &predicate_unparser_xins__if__greater__than_5
};

extern Const struct predicate predicate_unparser_xins__backslash_3;
static Const struct predinfo predinfo_unparser_xins__backslash_3 = {
  (unsigned char *)"ins_backslash",
  &predicate_unparser_xins__backslash_3
};

extern Const struct predicate predicate_unparser_xfirst__char__kind_2;
static Const struct predinfo predinfo_unparser_xfirst__char__kind_2 = {
  (unsigned char *)"first_char_kind",
  &predicate_unparser_xfirst__char__kind_2
};

extern Const struct predicate predicate_unparser_xfind__operator_3;
static Const struct predinfo predinfo_unparser_xfind__operator_3 = {
  (unsigned char *)"find_operator",
  &predicate_unparser_xfind__operator_3
};

extern Const struct predicate predicate_unparser_xdelimit_4;
static Const struct predinfo predinfo_unparser_xdelimit_4 = {
  (unsigned char *)"delimit",
  &predicate_unparser_xdelimit_4
};

extern Const struct predicate predicate_unparser_xchartype_2F2_240_2;
static Const struct predinfo predinfo_unparser_xchartype_2F2_240_2 = {
  (unsigned char *)"chartype/2$0",
  &predicate_unparser_xchartype_2F2_240_2
};

extern Const struct predicate predicate_unparser_xchartype_2;
static Const struct predinfo predinfo_unparser_xchartype_2 = {
  (unsigned char *)"chartype",
  &predicate_unparser_xchartype_2
};

extern Const struct predicate predicate_unparser_xchar__kind_2;
static Const struct predinfo predinfo_unparser_xchar__kind_2 = {
  (unsigned char *)"char_kind",
  &predicate_unparser_xchar__kind_2
};

extern Const struct predicate predicate_unparser_xcall__unparser_6;
static Const struct predinfo predinfo_unparser_xcall__unparser_6 = {
  (unsigned char *)"call_unparser",
  &predicate_unparser_xcall__unparser_6
};

extern Const struct predicate predicate_unparser_xatom__kind_3;
static Const struct predinfo predinfo_unparser_xatom__kind_3 = {
  (unsigned char *)"atom_kind",
  &predicate_unparser_xatom__kind_3
};

extern Const struct predicate predicate_unparser_xatom__kind_2F3_240_4;
static Const struct predinfo predinfo_unparser_xatom__kind_2F3_240_4 = {
  (unsigned char *)"atom_kind/3$0",
  &predicate_unparser_xatom__kind_2F3_240_4
};

static Const struct predinfo * Const preds_in_unparser[] = {
  &predinfo_unparser_xunwparse__cons_5,
  &predinfo_unparser_xunwparse__cdr_5,
  &predinfo_unparser_xunwparse_6,
  &predinfo_unparser_xunwparse_4,
  &predinfo_unparser_xunscan__after__op_4,
  &predinfo_unparser_xunscan_4,
  &predinfo_unparser_xunparse__with__op_10,
  &predinfo_unparser_xunparse__vector_5,
  &predinfo_unparser_xunparse__vecelems_7,
  &predinfo_unparser_xunparse__string_3,
  &predinfo_unparser_xunparse__int_3,
  &predinfo_unparser_xunparse__general_6,
  &predinfo_unparser_xunparse__float_3,
  &predinfo_unparser_xunparse__elems_7,
  &predinfo_unparser_xunparse__cons_5,
  &predinfo_unparser_xunparse__comma__list__elem_5,
  &predinfo_unparser_xunparse__cdr_5,
  &predinfo_unparser_xunparse__bin__op_3,
  &predinfo_unparser_xunparse__atom_3,
  &predinfo_unparser_xunparse_6,
  &predinfo_unparser_xunparse_4,
  &predinfo_unparser_xstr__elem__chars_3,
  &predinfo_unparser_xstr__chars_5,
  &predinfo_unparser_xquoted__atom__chars_4,
  &predinfo_unparser_xquoted__atom__chars_2F4_240_3,
  &predinfo_unparser_xmax__op_4,
  &predinfo_unparser_xmax_3,
  &predinfo_unparser_xmake__atom__string_4,
  &predinfo_unparser_xjudge__quoted_6,
  &predinfo_unparser_xint__chars_3,
  &predinfo_unparser_xins__if__greater__than_5,
  &predinfo_unparser_xins__backslash_3,
  &predinfo_unparser_xfirst__char__kind_2,
  &predinfo_unparser_xfind__operator_3,
  &predinfo_unparser_xdelimit_4,
  &predinfo_unparser_xchartype_2F2_240_2,
  &predinfo_unparser_xchartype_2,
  &predinfo_unparser_xchar__kind_2,
  &predinfo_unparser_xcall__unparser_6,
  &predinfo_unparser_xatom__kind_3,
  &predinfo_unparser_xatom__kind_2F3_240_4,
  0
};
extern Const struct predicate predicate_klic__comp__obj_xwrite__threadp_3;
static Const struct predinfo predinfo_klic__comp__obj_xwrite__threadp_3 = {
  (unsigned char *)"write_threadp",
  &predicate_klic__comp__obj_xwrite__threadp_3
};

extern Const struct predicate predicate_klic__comp__obj_xwrite__thread_6;
static Const struct predinfo predinfo_klic__comp__obj_xwrite__thread_6 = {
  (unsigned char *)"write_thread",
  &predicate_klic__comp__obj_xwrite__thread_6
};

extern Const struct predicate predicate_klic__comp__obj_xwrite__reg_3;
static Const struct predinfo predinfo_klic__comp__obj_xwrite__reg_3 = {
  (unsigned char *)"write_reg",
  &predicate_klic__comp__obj_xwrite__reg_3
};

extern Const struct predicate predicate_klic__comp__obj_xwrite__qp_3;
static Const struct predinfo predinfo_klic__comp__obj_xwrite__qp_3 = {
  (unsigned char *)"write_qp",
  &predicate_klic__comp__obj_xwrite__qp_3
};

extern Const struct predicate predicate_klic__comp__obj_xwrite__params_3;
static Const struct predinfo predinfo_klic__comp__obj_xwrite__params_3 = {
  (unsigned char *)"write_params",
  &predicate_klic__comp__obj_xwrite__params_3
};

extern Const struct predicate predicate_klic__comp__obj_xwrite__param_3;
static Const struct predinfo predinfo_klic__comp__obj_xwrite__param_3 = {
  (unsigned char *)"write_param",
  &predicate_klic__comp__obj_xwrite__param_3
};

extern Const struct predicate predicate_klic__comp__obj_xwrite__one__move_4;
static Const struct predinfo predinfo_klic__comp__obj_xwrite__one__move_4 = {
  (unsigned char *)"write_one_move",
  &predicate_klic__comp__obj_xwrite__one__move_4
};

extern Const struct predicate predicate_klic__comp__obj_xwrite__one__go_6;
static Const struct predinfo predinfo_klic__comp__obj_xwrite__one__go_6 = {
  (unsigned char *)"write_one_go",
  &predicate_klic__comp__obj_xwrite__one__go_6
};

extern Const struct predicate predicate_klic__comp__obj_xwrite__one__execute__for__loop_5;
static Const struct predinfo predinfo_klic__comp__obj_xwrite__one__execute__for__loop_5 = {
  (unsigned char *)"write_one_execute_for_loop",
  &predicate_klic__comp__obj_xwrite__one__execute__for__loop_5
};

extern Const struct predicate predicate_klic__comp__obj_xwrite__one__execute_5;
static Const struct predinfo predinfo_klic__comp__obj_xwrite__one__execute_5 = {
  (unsigned char *)"write_one_execute",
  &predicate_klic__comp__obj_xwrite__one__execute_5
};

extern Const struct predicate predicate_klic__comp__obj_xwrite__one__bblt_6;
static Const struct predinfo predinfo_klic__comp__obj_xwrite__one__bblt_6 = {
  (unsigned char *)"write_one_bblt",
  &predicate_klic__comp__obj_xwrite__one__bblt_6
};

extern Const struct predicate predicate_klic__comp__obj_xwrite__one_6;
static Const struct predinfo predinfo_klic__comp__obj_xwrite__one_6 = {
  (unsigned char *)"write_one",
  &predicate_klic__comp__obj_xwrite__one_6
};

extern Const struct predicate predicate_klic__comp__obj_xwrite__object_5;
static Const struct predinfo predinfo_klic__comp__obj_xwrite__object_5 = {
  (unsigned char *)"write_object",
  &predicate_klic__comp__obj_xwrite__object_5
};

extern Const struct predicate predicate_klic__comp__obj_xwrite__object_4;
static Const struct predinfo predinfo_klic__comp__obj_xwrite__object_4 = {
  (unsigned char *)"write_object",
  &predicate_klic__comp__obj_xwrite__object_4
};

extern Const struct predicate predicate_klic__comp__obj_xwrite__object_2F5_240_8;
static Const struct predinfo predinfo_klic__comp__obj_xwrite__object_2F5_240_8 = {
  (unsigned char *)"write_object/5$0",
  &predicate_klic__comp__obj_xwrite__object_2F5_240_8
};

extern Const struct predicate predicate_klic__comp__obj_xwrite__object_2F5_240_2F8_240_10;
static Const struct predinfo predinfo_klic__comp__obj_xwrite__object_2F5_240_2F8_240_10 = {
  (unsigned char *)"write_object/5$0/8$0",
  &predicate_klic__comp__obj_xwrite__object_2F5_240_2F8_240_10
};

extern Const struct predicate predicate_klic__comp__obj_xwrite__next__args_5;
static Const struct predinfo predinfo_klic__comp__obj_xwrite__next__args_5 = {
  (unsigned char *)"write_next_args",
  &predicate_klic__comp__obj_xwrite__next__args_5
};

extern Const struct predicate predicate_klic__comp__obj_xwrite__jump__nonloop_6;
static Const struct predinfo predinfo_klic__comp__obj_xwrite__jump__nonloop_6 = {
  (unsigned char *)"write_jump_nonloop",
  &predicate_klic__comp__obj_xwrite__jump__nonloop_6
};

extern Const struct predicate predicate_klic__comp__obj_xwrite__jump__loop_6;
static Const struct predinfo predinfo_klic__comp__obj_xwrite__jump__loop_6 = {
  (unsigned char *)"write_jump_loop",
  &predicate_klic__comp__obj_xwrite__jump__loop_6
};

extern Const struct predicate predicate_klic__comp__obj_xwrite__int_3;
static Const struct predinfo predinfo_klic__comp__obj_xwrite__int_3 = {
  (unsigned char *)"write_int",
  &predicate_klic__comp__obj_xwrite__int_3
};

extern Const struct predicate predicate_klic__comp__obj_xwrite__inline_8;
static Const struct predinfo predinfo_klic__comp__obj_xwrite__inline_8 = {
  (unsigned char *)"write_inline",
  &predicate_klic__comp__obj_xwrite__inline_8
};

extern Const struct predicate predicate_klic__comp__obj_xwrite__inline_6;
static Const struct predinfo predinfo_klic__comp__obj_xwrite__inline_6 = {
  (unsigned char *)"write_inline",
  &predicate_klic__comp__obj_xwrite__inline_6
};

extern Const struct predicate predicate_klic__comp__obj_xwrite__elem__access_4;
static Const struct predinfo predinfo_klic__comp__obj_xwrite__elem__access_4 = {
  (unsigned char *)"write_elem_access",
  &predicate_klic__comp__obj_xwrite__elem__access_4
};

extern Const struct predicate predicate_klic__comp__obj_xwrite__debug__name_6;
static Const struct predinfo predinfo_klic__comp__obj_xwrite__debug__name_6 = {
  (unsigned char *)"write_debug_name",
  &predicate_klic__comp__obj_xwrite__debug__name_6
};

extern Const struct predicate predicate_klic__comp__obj_xwrite__atom__name__string_5;
static Const struct predinfo predinfo_klic__comp__obj_xwrite__atom__name__string_5 = {
  (unsigned char *)"write_atom_name_string",
  &predicate_klic__comp__obj_xwrite__atom__name__string_5
};

extern Const struct predicate predicate_klic__comp__obj_xwrite__atom__name__string_3;
static Const struct predinfo predinfo_klic__comp__obj_xwrite__atom__name__string_3 = {
  (unsigned char *)"write_atom_name_string",
  &predicate_klic__comp__obj_xwrite__atom__name__string_3
};

extern Const struct predicate predicate_klic__comp__obj_xwrite__atom__name__char_3;
static Const struct predinfo predinfo_klic__comp__obj_xwrite__atom__name__char_3 = {
  (unsigned char *)"write_atom_name_char",
  &predicate_klic__comp__obj_xwrite__atom__name__char_3
};

extern Const struct predicate predicate_klic__comp__obj_xwrite__adjust__qp_3;
static Const struct predinfo predinfo_klic__comp__obj_xwrite__adjust__qp_3 = {
  (unsigned char *)"write_adjust_qp",
  &predicate_klic__comp__obj_xwrite__adjust__qp_3
};

extern Const struct predicate predicate_klic__comp__obj_xwrite__adjust__allocp_3;
static Const struct predinfo predinfo_klic__comp__obj_xwrite__adjust__allocp_3 = {
  (unsigned char *)"write_adjust_allocp",
  &predicate_klic__comp__obj_xwrite__adjust__allocp_3
};

extern Const struct predicate predicate_klic__comp__obj_xwrite__adjust_4;
static Const struct predinfo predinfo_klic__comp__obj_xwrite__adjust_4 = {
  (unsigned char *)"write_adjust",
  &predicate_klic__comp__obj_xwrite__adjust_4
};

extern Const struct predicate predicate_klic__comp__obj_xwait__and__out_4;
static Const struct predinfo predinfo_klic__comp__obj_xwait__and__out_4 = {
  (unsigned char *)"wait_and_out",
  &predicate_klic__comp__obj_xwait__and__out_4
};

extern Const struct predicate predicate_klic__comp__obj_xklicformat__stderr_2;
static Const struct predinfo predinfo_klic__comp__obj_xklicformat__stderr_2 = {
  (unsigned char *)"klicformat_stderr",
  &predicate_klic__comp__obj_xklicformat__stderr_2
};

extern Const struct predicate predicate_klic__comp__obj_xklicformat_6;
static Const struct predinfo predinfo_klic__comp__obj_xklicformat_6 = {
  (unsigned char *)"klicformat",
  &predicate_klic__comp__obj_xklicformat_6
};

extern Const struct predicate predicate_klic__comp__obj_xklicformat_4;
static Const struct predinfo predinfo_klic__comp__obj_xklicformat_4 = {
  (unsigned char *)"klicformat",
  &predicate_klic__comp__obj_xklicformat_4
};

extern Const struct predicate predicate_klic__comp__obj_xklicformat_3;
static Const struct predinfo predinfo_klic__comp__obj_xklicformat_3 = {
  (unsigned char *)"klicformat",
  &predicate_klic__comp__obj_xklicformat_3
};

extern Const struct predicate predicate_klic__comp__obj_xinline__special_6;
static Const struct predinfo predinfo_klic__comp__obj_xinline__special_6 = {
  (unsigned char *)"inline_special",
  &predicate_klic__comp__obj_xinline__special_6
};

extern Const struct predicate predicate_klic__comp__obj_xhexchar_2;
static Const struct predinfo predinfo_klic__comp__obj_xhexchar_2 = {
  (unsigned char *)"hexchar",
  &predicate_klic__comp__obj_xhexchar_2
};

extern Const struct predicate predicate_klic__comp__obj_xformat__special__w_3;
static Const struct predinfo predinfo_klic__comp__obj_xformat__special__w_3 = {
  (unsigned char *)"format_special_w",
  &predicate_klic__comp__obj_xformat__special__w_3
};

extern Const struct predicate predicate_klic__comp__obj_xformat__special_5;
static Const struct predinfo predinfo_klic__comp__obj_xformat__special_5 = {
  (unsigned char *)"format_special",
  &predicate_klic__comp__obj_xformat__special_5
};

extern Const struct predicate predicate_klic__comp__obj_xflush_3;
static Const struct predinfo predinfo_klic__comp__obj_xflush_3 = {
  (unsigned char *)"flush",
  &predicate_klic__comp__obj_xflush_3
};

extern Const struct predicate predicate_klic__comp__obj_xflush_2;
static Const struct predinfo predinfo_klic__comp__obj_xflush_2 = {
  (unsigned char *)"flush",
  &predicate_klic__comp__obj_xflush_2
};

static Const struct predinfo * Const preds_in_klic__comp__obj[] = {
  &predinfo_klic__comp__obj_xwrite__threadp_3,
  &predinfo_klic__comp__obj_xwrite__thread_6,
  &predinfo_klic__comp__obj_xwrite__reg_3,
  &predinfo_klic__comp__obj_xwrite__qp_3,
  &predinfo_klic__comp__obj_xwrite__params_3,
  &predinfo_klic__comp__obj_xwrite__param_3,
  &predinfo_klic__comp__obj_xwrite__one__move_4,
  &predinfo_klic__comp__obj_xwrite__one__go_6,
  &predinfo_klic__comp__obj_xwrite__one__execute__for__loop_5,
  &predinfo_klic__comp__obj_xwrite__one__execute_5,
  &predinfo_klic__comp__obj_xwrite__one__bblt_6,
  &predinfo_klic__comp__obj_xwrite__one_6,
  &predinfo_klic__comp__obj_xwrite__object_5,
  &predinfo_klic__comp__obj_xwrite__object_4,
  &predinfo_klic__comp__obj_xwrite__object_2F5_240_8,
  &predinfo_klic__comp__obj_xwrite__object_2F5_240_2F8_240_10,
  &predinfo_klic__comp__obj_xwrite__next__args_5,
  &predinfo_klic__comp__obj_xwrite__jump__nonloop_6,
  &predinfo_klic__comp__obj_xwrite__jump__loop_6,
  &predinfo_klic__comp__obj_xwrite__int_3,
  &predinfo_klic__comp__obj_xwrite__inline_8,
  &predinfo_klic__comp__obj_xwrite__inline_6,
  &predinfo_klic__comp__obj_xwrite__elem__access_4,
  &predinfo_klic__comp__obj_xwrite__debug__name_6,
  &predinfo_klic__comp__obj_xwrite__atom__name__string_5,
  &predinfo_klic__comp__obj_xwrite__atom__name__string_3,
  &predinfo_klic__comp__obj_xwrite__atom__name__char_3,
  &predinfo_klic__comp__obj_xwrite__adjust__qp_3,
  &predinfo_klic__comp__obj_xwrite__adjust__allocp_3,
  &predinfo_klic__comp__obj_xwrite__adjust_4,
  &predinfo_klic__comp__obj_xwait__and__out_4,
  &predinfo_klic__comp__obj_xklicformat__stderr_2,
  &predinfo_klic__comp__obj_xklicformat_6,
  &predinfo_klic__comp__obj_xklicformat_4,
  &predinfo_klic__comp__obj_xklicformat_3,
  &predinfo_klic__comp__obj_xinline__special_6,
  &predinfo_klic__comp__obj_xhexchar_2,
  &predinfo_klic__comp__obj_xformat__special__w_3,
  &predinfo_klic__comp__obj_xformat__special_5,
  &predinfo_klic__comp__obj_xflush_3,
  &predinfo_klic__comp__obj_xflush_2,
  0
};
extern Const struct predicate predicate_functor__table_xsetarg_5;
static Const struct predinfo predinfo_functor__table_xsetarg_5 = {
  (unsigned char *)"setarg",
  &predicate_functor__table_xsetarg_5
};

extern Const struct predicate predicate_functor__table_xsetarg_4;
static Const struct predinfo predinfo_functor__table_xsetarg_4 = {
  (unsigned char *)"setarg",
  &predicate_functor__table_xsetarg_4
};

extern Const struct predicate predicate_functor__table_xnew__functor_3;
static Const struct predinfo predinfo_functor__table_xnew__functor_3 = {
  (unsigned char *)"new_functor",
  &predicate_functor__table_xnew__functor_3
};

extern Const struct predicate predicate_functor__table_xlength_3;
static Const struct predinfo predinfo_functor__table_xlength_3 = {
  (unsigned char *)"length",
  &predicate_functor__table_xlength_3
};

extern Const struct predicate predicate_functor__table_xfunctor_4;
static Const struct predinfo predinfo_functor__table_xfunctor_4 = {
  (unsigned char *)"functor",
  &predicate_functor__table_xfunctor_4
};

extern Const struct predicate predicate_functor__table_xfunctor_3;
static Const struct predinfo predinfo_functor__table_xfunctor_3 = {
  (unsigned char *)"functor",
  &predicate_functor__table_xfunctor_3
};

extern Const struct predicate predicate_functor__table_xfill__args_4;
static Const struct predinfo predinfo_functor__table_xfill__args_4 = {
  (unsigned char *)"fill_args",
  &predicate_functor__table_xfill__args_4
};

extern Const struct predicate predicate_functor__table_xarg_4;
static Const struct predinfo predinfo_functor__table_xarg_4 = {
  (unsigned char *)"arg",
  &predicate_functor__table_xarg_4
};

extern Const struct predicate predicate_functor__table_xarg_3;
static Const struct predinfo predinfo_functor__table_xarg_3 = {
  (unsigned char *)"arg",
  &predicate_functor__table_xarg_3
};

extern Const struct predicate predicate_functor__table_x_3D_2E_2E_2;
static Const struct predinfo predinfo_functor__table_x_3D_2E_2E_2 = {
  (unsigned char *)"=..",
  &predicate_functor__table_x_3D_2E_2E_2
};

static Const struct predinfo * Const preds_in_functor__table[] = {
  &predinfo_functor__table_xsetarg_5,
  &predinfo_functor__table_xsetarg_4,
  &predinfo_functor__table_xnew__functor_3,
  &predinfo_functor__table_xlength_3,
  &predinfo_functor__table_xfunctor_4,
  &predinfo_functor__table_xfunctor_3,
  &predinfo_functor__table_xfill__args_4,
  &predinfo_functor__table_xarg_4,
  &predinfo_functor__table_xarg_3,
  &predinfo_functor__table_x_3D_2E_2E_2,
  0
};
extern Const struct predicate predicate_variable_xwrap__vec__elems_5;
static Const struct predinfo predinfo_variable_xwrap__vec__elems_5 = {
  (unsigned char *)"wrap_vec_elems",
  &predicate_variable_xwrap__vec__elems_5
};

extern Const struct predicate predicate_variable_xwrap__funct__elems_6;
static Const struct predinfo predinfo_variable_xwrap__funct__elems_6 = {
  (unsigned char *)"wrap_funct_elems",
  &predicate_variable_xwrap__funct__elems_6
};

extern Const struct predicate predicate_variable_xwrap__bound_2;
static Const struct predinfo predinfo_variable_xwrap__bound_2 = {
  (unsigned char *)"wrap_bound",
  &predicate_variable_xwrap__bound_2
};

extern Const struct predicate predicate_variable_xwrap_2F2_240_3;
static Const struct predinfo predinfo_variable_xwrap_2F2_240_3 = {
  (unsigned char *)"wrap/2$0",
  &predicate_variable_xwrap_2F2_240_3
};

extern Const struct predicate predicate_variable_xwrap_2;
static Const struct predinfo predinfo_variable_xwrap_2 = {
  (unsigned char *)"wrap",
  &predicate_variable_xwrap_2
};

extern Const struct predicate predicate_variable_xunwrap__vector_6;
static Const struct predinfo predinfo_variable_xunwrap__vector_6 = {
  (unsigned char *)"unwrap_vector",
  &predicate_variable_xunwrap__vector_6
};

extern Const struct predicate predicate_variable_xunwrap__functor_8;
static Const struct predinfo predinfo_variable_xunwrap__functor_8 = {
  (unsigned char *)"unwrap_functor",
  &predicate_variable_xunwrap__functor_8
};

extern Const struct predicate predicate_variable_xunwrap_4;
static Const struct predinfo predinfo_variable_xunwrap_4 = {
  (unsigned char *)"unwrap",
  &predicate_variable_xunwrap_4
};

extern Const struct predicate predicate_variable_xunwrap_3;
static Const struct predinfo predinfo_variable_xunwrap_3 = {
  (unsigned char *)"unwrap",
  &predicate_variable_xunwrap_3
};

extern Const struct predicate predicate_variable_xunwrap_2;
static Const struct predinfo predinfo_variable_xunwrap_2 = {
  (unsigned char *)"unwrap",
  &predicate_variable_xunwrap_2
};

extern Const struct predicate predicate_variable_xunbound_2;
static Const struct predinfo predinfo_variable_xunbound_2 = {
  (unsigned char *)"unbound",
  &predicate_variable_xunbound_2
};

extern Const struct predicate predicate_variable_xget__variable_4;
static Const struct predinfo predinfo_variable_xget__variable_4 = {
  (unsigned char *)"get_variable",
  &predicate_variable_xget__variable_4
};

extern Const struct predicate predicate_variable_xget__variable2_4;
static Const struct predinfo predinfo_variable_xget__variable2_4 = {
  (unsigned char *)"get_variable2",
  &predicate_variable_xget__variable2_4
};

static Const struct predinfo * Const preds_in_variable[] = {
  &predinfo_variable_xwrap__vec__elems_5,
  &predinfo_variable_xwrap__funct__elems_6,
  &predinfo_variable_xwrap__bound_2,
  &predinfo_variable_xwrap_2F2_240_3,
  &predinfo_variable_xwrap_2,
  &predinfo_variable_xunwrap__vector_6,
  &predinfo_variable_xunwrap__functor_8,
  &predinfo_variable_xunwrap_4,
  &predinfo_variable_xunwrap_3,
  &predinfo_variable_xunwrap_2,
  &predinfo_variable_xunbound_2,
  &predinfo_variable_xget__variable_4,
  &predinfo_variable_xget__variable2_4,
  0
};
extern Const struct predicate predicate_klic__comp__kl1cmp_xwrite__message_5;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xwrite__message_5 = {
  (unsigned char *)"write_message",
  &predicate_klic__comp__kl1cmp_xwrite__message_5
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xwrite__message_3;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xwrite__message_3 = {
  (unsigned char *)"write_message",
  &predicate_klic__comp__kl1cmp_xwrite__message_3
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xwrite__message2_8;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xwrite__message2_8 = {
  (unsigned char *)"write_message2",
  &predicate_klic__comp__kl1cmp_xwrite__message2_8
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xwrite__message1_7;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xwrite__message1_7 = {
  (unsigned char *)"write_message1",
  &predicate_klic__comp__kl1cmp_xwrite__message1_7
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xwrite__inline__header_3;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xwrite__inline__header_3 = {
  (unsigned char *)"write_inline_header",
  &predicate_klic__comp__kl1cmp_xwrite__inline__header_3
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xwrite__file__header_2;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xwrite__file__header_2 = {
  (unsigned char *)"write_file_header",
  &predicate_klic__comp__kl1cmp_xwrite__file__header_2
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xwarning_4;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xwarning_4 = {
  (unsigned char *)"warning",
  &predicate_klic__comp__kl1cmp_xwarning_4
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xwarning_2;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xwarning_2 = {
  (unsigned char *)"warning",
  &predicate_klic__comp__kl1cmp_xwarning_2
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xwait__output__end_3;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xwait__output__end_3 = {
  (unsigned char *)"wait_output_end",
  &predicate_klic__comp__kl1cmp_xwait__output__end_3
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xtell_2;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xtell_2 = {
  (unsigned char *)"tell",
  &predicate_klic__comp__kl1cmp_xtell_2
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xtell1_3;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xtell1_3 = {
  (unsigned char *)"tell1",
  &predicate_klic__comp__kl1cmp_xtell1_3
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xshift__vector_5;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xshift__vector_5 = {
  (unsigned char *)"shift_vector",
  &predicate_klic__comp__kl1cmp_xshift__vector_5
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xshift__vector_3;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xshift__vector_3 = {
  (unsigned char *)"shift_vector",
  &predicate_klic__comp__kl1cmp_xshift__vector_3
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xshift__vector_2;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xshift__vector_2 = {
  (unsigned char *)"shift_vector",
  &predicate_klic__comp__kl1cmp_xshift__vector_2
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xsee__2_3;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xsee__2_3 = {
  (unsigned char *)"see_2",
  &predicate_klic__comp__kl1cmp_xsee__2_3
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xsee_2;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xsee_2 = {
  (unsigned char *)"see",
  &predicate_klic__comp__kl1cmp_xsee_2
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xreport__error_4;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xreport__error_4 = {
  (unsigned char *)"report_error",
  &predicate_klic__comp__kl1cmp_xreport__error_4
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xreport__error_2;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xreport__error_2 = {
  (unsigned char *)"report_error",
  &predicate_klic__comp__kl1cmp_xreport__error_2
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xrename__macro__preds_5;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xrename__macro__preds_5 = {
  (unsigned char *)"rename_macro_preds",
  &predicate_klic__comp__kl1cmp_xrename__macro__preds_5
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xrename__macro__clauses_3;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xrename__macro__clauses_3 = {
  (unsigned char *)"rename_macro_clauses",
  &predicate_klic__comp__kl1cmp_xrename__macro__clauses_3
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xread__src_2;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xread__src_2 = {
  (unsigned char *)"read_src",
  &predicate_klic__comp__kl1cmp_xread__src_2
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xread__src1_2;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xread__src1_2 = {
  (unsigned char *)"read_src1",
  &predicate_klic__comp__kl1cmp_xread__src1_2
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xread__one__module_5;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xread__one__module_5 = {
  (unsigned char *)"read_one_module",
  &predicate_klic__comp__kl1cmp_xread__one__module_5
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xread__inline_5;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xread__inline_5 = {
  (unsigned char *)"read_inline",
  &predicate_klic__comp__kl1cmp_xread__inline_5
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xread__in_3;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xread__in_3 = {
  (unsigned char *)"read_in",
  &predicate_klic__comp__kl1cmp_xread__in_3
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xread__all__1_4;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xread__all__1_4 = {
  (unsigned char *)"read_all_1",
  &predicate_klic__comp__kl1cmp_xread__all__1_4
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xread__all_4;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xread__all_4 = {
  (unsigned char *)"read_all",
  &predicate_klic__comp__kl1cmp_xread__all_4
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xklcmp_2F2_240_4;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xklcmp_2F2_240_4 = {
  (unsigned char *)"klcmp/2$0",
  &predicate_klic__comp__kl1cmp_xklcmp_2F2_240_4
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xklcmp_2;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xklcmp_2 = {
  (unsigned char *)"klcmp",
  &predicate_klic__comp__kl1cmp_xklcmp_2
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xklcmp1_4;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xklcmp1_4 = {
  (unsigned char *)"klcmp1",
  &predicate_klic__comp__kl1cmp_xklcmp1_4
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xhandle__exception_3;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xhandle__exception_3 = {
  (unsigned char *)"handle_exception",
  &predicate_klic__comp__kl1cmp_xhandle__exception_3
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xhandle__exception_1;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xhandle__exception_1 = {
  (unsigned char *)"handle_exception",
  &predicate_klic__comp__kl1cmp_xhandle__exception_1
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xget__clause__name_3;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xget__clause__name_3 = {
  (unsigned char *)"get_clause_name",
  &predicate_klic__comp__kl1cmp_xget__clause__name_3
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xcomplain__words_3;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xcomplain__words_3 = {
  (unsigned char *)"complain_words",
  &predicate_klic__comp__kl1cmp_xcomplain__words_3
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xcomplain__tokens_6;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xcomplain__tokens_6 = {
  (unsigned char *)"complain_tokens",
  &predicate_klic__comp__kl1cmp_xcomplain__tokens_6
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xcomplain__tokens_3;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xcomplain__tokens_3 = {
  (unsigned char *)"complain_tokens",
  &predicate_klic__comp__kl1cmp_xcomplain__tokens_3
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xcomplain__token_3;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xcomplain__token_3 = {
  (unsigned char *)"complain_token",
  &predicate_klic__comp__kl1cmp_xcomplain__token_3
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xcomplain__string_3;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xcomplain__string_3 = {
  (unsigned char *)"complain_string",
  &predicate_klic__comp__kl1cmp_xcomplain__string_3
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xcompile__modules_6;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xcompile__modules_6 = {
  (unsigned char *)"compile_modules",
  &predicate_klic__comp__kl1cmp_xcompile__modules_6
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xcompile_4;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xcompile_4 = {
  (unsigned char *)"compile",
  &predicate_klic__comp__kl1cmp_xcompile_4
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xcompile2_6;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xcompile2_6 = {
  (unsigned char *)"compile2",
  &predicate_klic__comp__kl1cmp_xcompile2_6
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xcompile1_4;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xcompile1_4 = {
  (unsigned char *)"compile1",
  &predicate_klic__comp__kl1cmp_xcompile1_4
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xcompilation__error_1;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xcompilation__error_1 = {
  (unsigned char *)"compilation_error",
  &predicate_klic__comp__kl1cmp_xcompilation__error_1
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xcompilation__error_0;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xcompilation__error_0 = {
  (unsigned char *)"compilation_error",
  &predicate_klic__comp__kl1cmp_xcompilation__error_0
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xcollect__same__1_10;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xcollect__same__1_10 = {
  (unsigned char *)"collect_same_1",
  &predicate_klic__comp__kl1cmp_xcollect__same__1_10
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xcollect__same_8;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xcollect__same_8 = {
  (unsigned char *)"collect_same",
  &predicate_klic__comp__kl1cmp_xcollect__same_8
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xclose__streams_1;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xclose__streams_1 = {
  (unsigned char *)"close_streams",
  &predicate_klic__comp__kl1cmp_xclose__streams_1
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xanalyze__preds_6;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xanalyze__preds_6 = {
  (unsigned char *)"analyze_preds",
  &predicate_klic__comp__kl1cmp_xanalyze__preds_6
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xanalyze_2;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xanalyze_2 = {
  (unsigned char *)"analyze",
  &predicate_klic__comp__kl1cmp_xanalyze_2
};

extern Const struct predicate predicate_klic__comp__kl1cmp_xanalyze1_6;
static Const struct predinfo predinfo_klic__comp__kl1cmp_xanalyze1_6 = {
  (unsigned char *)"analyze1",
  &predicate_klic__comp__kl1cmp_xanalyze1_6
};

static Const struct predinfo * Const preds_in_klic__comp__kl1cmp[] = {
  &predinfo_klic__comp__kl1cmp_xwrite__message_5,
  &predinfo_klic__comp__kl1cmp_xwrite__message_3,
  &predinfo_klic__comp__kl1cmp_xwrite__message2_8,
  &predinfo_klic__comp__kl1cmp_xwrite__message1_7,
  &predinfo_klic__comp__kl1cmp_xwrite__inline__header_3,
  &predinfo_klic__comp__kl1cmp_xwrite__file__header_2,
  &predinfo_klic__comp__kl1cmp_xwarning_4,
  &predinfo_klic__comp__kl1cmp_xwarning_2,
  &predinfo_klic__comp__kl1cmp_xwait__output__end_3,
  &predinfo_klic__comp__kl1cmp_xtell_2,
  &predinfo_klic__comp__kl1cmp_xtell1_3,
  &predinfo_klic__comp__kl1cmp_xshift__vector_5,
  &predinfo_klic__comp__kl1cmp_xshift__vector_3,
  &predinfo_klic__comp__kl1cmp_xshift__vector_2,
  &predinfo_klic__comp__kl1cmp_xsee__2_3,
  &predinfo_klic__comp__kl1cmp_xsee_2,
  &predinfo_klic__comp__kl1cmp_xreport__error_4,
  &predinfo_klic__comp__kl1cmp_xreport__error_2,
  &predinfo_klic__comp__kl1cmp_xrename__macro__preds_5,
  &predinfo_klic__comp__kl1cmp_xrename__macro__clauses_3,
  &predinfo_klic__comp__kl1cmp_xread__src_2,
  &predinfo_klic__comp__kl1cmp_xread__src1_2,
  &predinfo_klic__comp__kl1cmp_xread__one__module_5,
  &predinfo_klic__comp__kl1cmp_xread__inline_5,
  &predinfo_klic__comp__kl1cmp_xread__in_3,
  &predinfo_klic__comp__kl1cmp_xread__all__1_4,
  &predinfo_klic__comp__kl1cmp_xread__all_4,
  &predinfo_klic__comp__kl1cmp_xklcmp_2F2_240_4,
  &predinfo_klic__comp__kl1cmp_xklcmp_2,
  &predinfo_klic__comp__kl1cmp_xklcmp1_4,
  &predinfo_klic__comp__kl1cmp_xhandle__exception_3,
  &predinfo_klic__comp__kl1cmp_xhandle__exception_1,
  &predinfo_klic__comp__kl1cmp_xget__clause__name_3,
  &predinfo_klic__comp__kl1cmp_xcomplain__words_3,
  &predinfo_klic__comp__kl1cmp_xcomplain__tokens_6,
  &predinfo_klic__comp__kl1cmp_xcomplain__tokens_3,
  &predinfo_klic__comp__kl1cmp_xcomplain__token_3,
  &predinfo_klic__comp__kl1cmp_xcomplain__string_3,
  &predinfo_klic__comp__kl1cmp_xcompile__modules_6,
  &predinfo_klic__comp__kl1cmp_xcompile_4,
  &predinfo_klic__comp__kl1cmp_xcompile2_6,
  &predinfo_klic__comp__kl1cmp_xcompile1_4,
  &predinfo_klic__comp__kl1cmp_xcompilation__error_1,
  &predinfo_klic__comp__kl1cmp_xcompilation__error_0,
  &predinfo_klic__comp__kl1cmp_xcollect__same__1_10,
  &predinfo_klic__comp__kl1cmp_xcollect__same_8,
  &predinfo_klic__comp__kl1cmp_xclose__streams_1,
  &predinfo_klic__comp__kl1cmp_xanalyze__preds_6,
  &predinfo_klic__comp__kl1cmp_xanalyze_2,
  &predinfo_klic__comp__kl1cmp_xanalyze1_6,
  0
};
extern Const struct predicate predicate_unix_xwrite__open_2;
static Const struct predinfo predinfo_unix_xwrite__open_2 = {
  (unsigned char *)"write_open",
  &predicate_unix_xwrite__open_2
};

extern Const struct predicate predicate_unix_xupdate__open_2;
static Const struct predinfo predinfo_unix_xupdate__open_2 = {
  (unsigned char *)"update_open",
  &predicate_unix_xupdate__open_2
};

extern Const struct predicate predicate_unix_xunlink_2;
static Const struct predinfo predinfo_unix_xunlink_2 = {
  (unsigned char *)"unlink",
  &predicate_unix_xunlink_2
};

extern Const struct predicate predicate_unix_xunix_1;
static Const struct predinfo predinfo_unix_xunix_1 = {
  (unsigned char *)"unix",
  &predicate_unix_xunix_1
};

extern Const struct predicate predicate_unix_xumask_2;
static Const struct predinfo predinfo_unix_xumask_2 = {
  (unsigned char *)"umask",
  &predicate_unix_xumask_2
};

extern Const struct predicate predicate_unix_xumask_1;
static Const struct predinfo predinfo_unix_xumask_1 = {
  (unsigned char *)"umask",
  &predicate_unix_xumask_1
};

extern Const struct predicate predicate_unix_xtimes_4;
static Const struct predinfo predinfo_unix_xtimes_4 = {
  (unsigned char *)"times",
  &predicate_unix_xtimes_4
};

extern Const struct predicate predicate_unix_xsystem_2;
static Const struct predinfo predinfo_unix_xsystem_2 = {
  (unsigned char *)"system",
  &predicate_unix_xsystem_2
};

extern Const struct predicate predicate_unix_xstdout_1;
static Const struct predinfo predinfo_unix_xstdout_1 = {
  (unsigned char *)"stdout",
  &predicate_unix_xstdout_1
};

extern Const struct predicate predicate_unix_xstdin_1;
static Const struct predinfo predinfo_unix_xstdin_1 = {
  (unsigned char *)"stdin",
  &predicate_unix_xstdin_1
};

extern Const struct predicate predicate_unix_xstderr_1;
static Const struct predinfo predinfo_unix_xstderr_1 = {
  (unsigned char *)"stderr",
  &predicate_unix_xstderr_1
};

extern Const struct predicate predicate_unix_xsignal__stream_3;
static Const struct predinfo predinfo_unix_xsignal__stream_3 = {
  (unsigned char *)"signal_stream",
  &predicate_unix_xsignal__stream_3
};

extern Const struct predicate predicate_unix_xsignal__stream_2;
static Const struct predinfo predinfo_unix_xsignal__stream_2 = {
  (unsigned char *)"signal_stream",
  &predicate_unix_xsignal__stream_2
};

extern Const struct predicate predicate_unix_xread__open_2;
static Const struct predinfo predinfo_unix_xread__open_2 = {
  (unsigned char *)"read_open",
  &predicate_unix_xread__open_2
};

extern Const struct predicate predicate_unix_xputenv_2;
static Const struct predinfo predinfo_unix_xputenv_2 = {
  (unsigned char *)"putenv",
  &predicate_unix_xputenv_2
};

extern Const struct predicate predicate_unix_xpipe_1;
static Const struct predinfo predinfo_unix_xpipe_1 = {
  (unsigned char *)"pipe",
  &predicate_unix_xpipe_1
};

extern Const struct predicate predicate_unix_xnet__convert_3;
static Const struct predinfo predinfo_unix_xnet__convert_3 = {
  (unsigned char *)"net_convert",
  &predicate_unix_xnet__convert_3
};

extern Const struct predicate predicate_unix_xmktemp_2;
static Const struct predinfo predinfo_unix_xmktemp_2 = {
  (unsigned char *)"mktemp",
  &predicate_unix_xmktemp_2
};

extern Const struct predicate predicate_unix_xmake__argv__list_3;
static Const struct predinfo predinfo_unix_xmake__argv__list_3 = {
  (unsigned char *)"make_argv_list",
  &predicate_unix_xmake__argv__list_3
};

extern Const struct predicate predicate_unix_xkill_3;
static Const struct predinfo predinfo_unix_xkill_3 = {
  (unsigned char *)"kill",
  &predicate_unix_xkill_3
};

extern Const struct predicate predicate_unix_xgetenv_2;
static Const struct predinfo predinfo_unix_xgetenv_2 = {
  (unsigned char *)"getenv",
  &predicate_unix_xgetenv_2
};

extern Const struct predicate predicate_unix_xfork__with__pipes_2F1_240_6;
static Const struct predinfo predinfo_unix_xfork__with__pipes_2F1_240_6 = {
  (unsigned char *)"fork_with_pipes/1$0",
  &predicate_unix_xfork__with__pipes_2F1_240_6
};

extern Const struct predicate predicate_unix_xfork__with__pipes_1;
static Const struct predinfo predinfo_unix_xfork__with__pipes_1 = {
  (unsigned char *)"fork_with_pipes",
  &predicate_unix_xfork__with__pipes_1
};

extern Const struct predicate predicate_unix_xfork_1;
static Const struct predinfo predinfo_unix_xfork_1 = {
  (unsigned char *)"fork",
  &predicate_unix_xfork_1
};

extern Const struct predicate predicate_unix_xexit_1;
static Const struct predinfo predinfo_unix_xexit_1 = {
  (unsigned char *)"exit",
  &predicate_unix_xexit_1
};

extern Const struct predicate predicate_unix_xdummy_0;
static Const struct predinfo predinfo_unix_xdummy_0 = {
  (unsigned char *)"dummy",
  &predicate_unix_xdummy_0
};

extern Const struct predicate predicate_unix_xcont_3;
static Const struct predinfo predinfo_unix_xcont_3 = {
  (unsigned char *)"cont",
  &predicate_unix_xcont_3
};

extern Const struct predicate predicate_unix_xconnect__sub_4;
static Const struct predinfo predinfo_unix_xconnect__sub_4 = {
  (unsigned char *)"connect_sub",
  &predicate_unix_xconnect__sub_4
};

extern Const struct predicate predicate_unix_xconnect_4;
static Const struct predinfo predinfo_unix_xconnect_4 = {
  (unsigned char *)"connect",
  &predicate_unix_xconnect_4
};

extern Const struct predicate predicate_unix_xconnect_2;
static Const struct predinfo predinfo_unix_xconnect_2 = {
  (unsigned char *)"connect",
  &predicate_unix_xconnect_2
};

extern Const struct predicate predicate_unix_xchmod_3;
static Const struct predinfo predinfo_unix_xchmod_3 = {
  (unsigned char *)"chmod",
  &predicate_unix_xchmod_3
};

extern Const struct predicate predicate_unix_xcd_2;
static Const struct predinfo predinfo_unix_xcd_2 = {
  (unsigned char *)"cd",
  &predicate_unix_xcd_2
};

extern Const struct predicate predicate_unix_xbound__sock_4;
static Const struct predinfo predinfo_unix_xbound__sock_4 = {
  (unsigned char *)"bound_sock",
  &predicate_unix_xbound__sock_4
};

extern Const struct predicate predicate_unix_xbind_4;
static Const struct predinfo predinfo_unix_xbind_4 = {
  (unsigned char *)"bind",
  &predicate_unix_xbind_4
};

extern Const struct predicate predicate_unix_xbind_2;
static Const struct predinfo predinfo_unix_xbind_2 = {
  (unsigned char *)"bind",
  &predicate_unix_xbind_2
};

extern Const struct predicate predicate_unix_xasync__io_5;
static Const struct predinfo predinfo_unix_xasync__io_5 = {
  (unsigned char *)"async_io",
  &predicate_unix_xasync__io_5
};

extern Const struct predicate predicate_unix_xargv_1;
static Const struct predinfo predinfo_unix_xargv_1 = {
  (unsigned char *)"argv",
  &predicate_unix_xargv_1
};

extern Const struct predicate predicate_unix_xargc_1;
static Const struct predinfo predinfo_unix_xargc_1 = {
  (unsigned char *)"argc",
  &predicate_unix_xargc_1
};

extern Const struct predicate predicate_unix_xappend__open_2;
static Const struct predinfo predinfo_unix_xappend__open_2 = {
  (unsigned char *)"append_open",
  &predicate_unix_xappend__open_2
};

extern Const struct predicate predicate_unix_xaccess_3;
static Const struct predinfo predinfo_unix_xaccess_3 = {
  (unsigned char *)"access",
  &predicate_unix_xaccess_3
};

static Const struct predinfo * Const preds_in_unix[] = {
  &predinfo_unix_xwrite__open_2,
  &predinfo_unix_xupdate__open_2,
  &predinfo_unix_xunlink_2,
  &predinfo_unix_xunix_1,
  &predinfo_unix_xumask_2,
  &predinfo_unix_xumask_1,
  &predinfo_unix_xtimes_4,
  &predinfo_unix_xsystem_2,
  &predinfo_unix_xstdout_1,
  &predinfo_unix_xstdin_1,
  &predinfo_unix_xstderr_1,
  &predinfo_unix_xsignal__stream_3,
  &predinfo_unix_xsignal__stream_2,
  &predinfo_unix_xread__open_2,
  &predinfo_unix_xputenv_2,
  &predinfo_unix_xpipe_1,
  &predinfo_unix_xnet__convert_3,
  &predinfo_unix_xmktemp_2,
  &predinfo_unix_xmake__argv__list_3,
  &predinfo_unix_xkill_3,
  &predinfo_unix_xgetenv_2,
  &predinfo_unix_xfork__with__pipes_2F1_240_6,
  &predinfo_unix_xfork__with__pipes_1,
  &predinfo_unix_xfork_1,
  &predinfo_unix_xexit_1,
  &predinfo_unix_xdummy_0,
  &predinfo_unix_xcont_3,
  &predinfo_unix_xconnect__sub_4,
  &predinfo_unix_xconnect_4,
  &predinfo_unix_xconnect_2,
  &predinfo_unix_xchmod_3,
  &predinfo_unix_xcd_2,
  &predinfo_unix_xbound__sock_4,
  &predinfo_unix_xbind_4,
  &predinfo_unix_xbind_2,
  &predinfo_unix_xasync__io_5,
  &predinfo_unix_xargv_1,
  &predinfo_unix_xargc_1,
  &predinfo_unix_xappend__open_2,
  &predinfo_unix_xaccess_3,
  0
};
extern Const struct predicate predicate_main_xmain_0;
static Const struct predinfo predinfo_main_xmain_0 = {
  (unsigned char *)"main",
  &predicate_main_xmain_0
};

extern Const struct predicate predicate_main_xkl1cmps_2;
static Const struct predinfo predinfo_main_xkl1cmps_2 = {
  (unsigned char *)"kl1cmps",
  &predicate_main_xkl1cmps_2
};

static Const struct predinfo * Const preds_in_main[] = {
  &predinfo_main_xmain_0,
  &predinfo_main_xkl1cmps_2,
  0
};
extern Const struct predicate predicate_generic_xnew_3;
static Const struct predinfo predinfo_generic_xnew_3 = {
  (unsigned char *)"new",
  &predicate_generic_xnew_3
};

extern Const struct predicate predicate_generic_xgeneric_2;
static Const struct predinfo predinfo_generic_xgeneric_2 = {
  (unsigned char *)"generic",
  &predicate_generic_xgeneric_2
};

static Const struct predinfo * Const preds_in_generic[] = {
  &predinfo_generic_xnew_3,
  &predinfo_generic_xgeneric_2,
  0
};
extern Const struct predicate predicate_unify__term__dcode_xunify__pf_2;
static Const struct predinfo predinfo_unify__term__dcode_xunify__pf_2 = {
  (unsigned char *)"unify_pf",
  &predicate_unify__term__dcode_xunify__pf_2
};

extern Const struct predicate predicate_unify__term__dcode_xunify__goal_2;
static Const struct predinfo predinfo_unify__term__dcode_xunify__goal_2 = {
  (unsigned char *)"unify_goal",
  &predicate_unify__term__dcode_xunify__goal_2
};

extern Const struct predicate predicate_unify__term__dcode_xunify__args_3;
static Const struct predinfo predinfo_unify__term__dcode_xunify__args_3 = {
  (unsigned char *)"unify_args",
  &predicate_unify__term__dcode_xunify__args_3
};

extern Const struct predicate predicate_unify__term__dcode_xunify_2;
static Const struct predinfo predinfo_unify__term__dcode_xunify_2 = {
  (unsigned char *)"unify",
  &predicate_unify__term__dcode_xunify_2
};

static Const struct predinfo * Const preds_in_unify__term__dcode[] = {
  &predinfo_unify__term__dcode_xunify__pf_2,
  &predinfo_unify__term__dcode_xunify__goal_2,
  &predinfo_unify__term__dcode_xunify__args_3,
  &predinfo_unify__term__dcode_xunify_2,
  0
};
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
static Const struct predinfo predinfo_integer__arithmetics_xsubtract_3 = {
  (unsigned char *)"subtract",
  &predicate_integer__arithmetics_xsubtract_3
};

extern Const struct predicate predicate_integer__arithmetics_xshift__right_3;
static Const struct predinfo predinfo_integer__arithmetics_xshift__right_3 = {
  (unsigned char *)"shift_right",
  &predicate_integer__arithmetics_xshift__right_3
};

extern Const struct predicate predicate_integer__arithmetics_xshift__left_3;
static Const struct predinfo predinfo_integer__arithmetics_xshift__left_3 = {
  (unsigned char *)"shift_left",
  &predicate_integer__arithmetics_xshift__left_3
};

extern Const struct predicate predicate_integer__arithmetics_xplus_2;
static Const struct predinfo predinfo_integer__arithmetics_xplus_2 = {
  (unsigned char *)"plus",
  &predicate_integer__arithmetics_xplus_2
};

extern Const struct predicate predicate_integer__arithmetics_xor_3;
static Const struct predinfo predinfo_integer__arithmetics_xor_3 = {
  (unsigned char *)"or",
  &predicate_integer__arithmetics_xor_3
};

extern Const struct predicate predicate_integer__arithmetics_xmultiply_3;
static Const struct predinfo predinfo_integer__arithmetics_xmultiply_3 = {
  (unsigned char *)"multiply",
  &predicate_integer__arithmetics_xmultiply_3
};

extern Const struct predicate predicate_integer__arithmetics_xmodulo_3;
static Const struct predinfo predinfo_integer__arithmetics_xmodulo_3 = {
  (unsigned char *)"modulo",
  &predicate_integer__arithmetics_xmodulo_3
};

extern Const struct predicate predicate_integer__arithmetics_xminus_2;
static Const struct predinfo predinfo_integer__arithmetics_xminus_2 = {
  (unsigned char *)"minus",
  &predicate_integer__arithmetics_xminus_2
};

extern Const struct predicate predicate_integer__arithmetics_xexclusive__or_3;
static Const struct predinfo predinfo_integer__arithmetics_xexclusive__or_3 = {
  (unsigned char *)"exclusive_or",
  &predicate_integer__arithmetics_xexclusive__or_3
};

extern Const struct predicate predicate_integer__arithmetics_xdivide_3;
static Const struct predinfo predinfo_integer__arithmetics_xdivide_3 = {
  (unsigned char *)"divide",
  &predicate_integer__arithmetics_xdivide_3
};

extern Const struct predicate predicate_integer__arithmetics_xcomplement_2;
static Const struct predinfo predinfo_integer__arithmetics_xcomplement_2 = {
  (unsigned char *)"complement",
  &predicate_integer__arithmetics_xcomplement_2
};

extern Const struct predicate predicate_integer__arithmetics_xand_3;
static Const struct predinfo predinfo_integer__arithmetics_xand_3 = {
  (unsigned char *)"and",
  &predicate_integer__arithmetics_xand_3
};

extern Const struct predicate predicate_integer__arithmetics_xadd_3;
static Const struct predinfo predinfo_integer__arithmetics_xadd_3 = {
  (unsigned char *)"add",
  &predicate_integer__arithmetics_xadd_3
};

static Const struct predinfo * Const preds_in_integer__arithmetics[] = {
  &predinfo_integer__arithmetics_xsubtract_3,
  &predinfo_integer__arithmetics_xshift__right_3,
  &predinfo_integer__arithmetics_xshift__left_3,
  &predinfo_integer__arithmetics_xplus_2,
  &predinfo_integer__arithmetics_xor_3,
  &predinfo_integer__arithmetics_xmultiply_3,
  &predinfo_integer__arithmetics_xmodulo_3,
  &predinfo_integer__arithmetics_xminus_2,
  &predinfo_integer__arithmetics_xexclusive__or_3,
  &predinfo_integer__arithmetics_xdivide_3,
  &predinfo_integer__arithmetics_xcomplement_2,
  &predinfo_integer__arithmetics_xand_3,
  &predinfo_integer__arithmetics_xadd_3,
  0
};
Const struct modinfo defined_modules[] = {
  (unsigned char *)"klic_comp_bb",
  preds_in_klic__comp__bb,
  (unsigned char *)"klic_comp_gb",
  preds_in_klic__comp__gb,
  (unsigned char *)"klic_comp_normalize",
  preds_in_klic__comp__normalize,
  (unsigned char *)"klic_comp_util",
  preds_in_klic__comp__util,
  (unsigned char *)"comparator",
  preds_in_comparator,
  (unsigned char *)"splay_tree",
  preds_in_splay__tree,
  (unsigned char *)"keyed_sorted_set",
  preds_in_keyed__sorted__set,
  (unsigned char *)"klic_comp_extern",
  preds_in_klic__comp__extern,
  (unsigned char *)"klic_comp_write",
  preds_in_klic__comp__write,
  (unsigned char *)"klic_comp_version",
  preds_in_klic__comp__version,
  (unsigned char *)"klic_comp_macro",
  preds_in_klic__comp__macro,
  (unsigned char *)"direct_call",
  preds_in_direct__call,
  (unsigned char *)"schedule",
  preds_in_schedule,
  (unsigned char *)"analyze_type",
  preds_in_analyze__type,
  (unsigned char *)"builtin_type",
  preds_in_builtin__type,
  (unsigned char *)"type_init",
  preds_in_type__init,
  (unsigned char *)"determine_type",
  preds_in_determine__type,
  (unsigned char *)"dependency",
  preds_in_dependency,
  (unsigned char *)"type",
  preds_in_type,
  (unsigned char *)"mode",
  preds_in_mode,
  (unsigned char *)"functor",
  preds_in_functor,
  (unsigned char *)"unify_head_body",
  preds_in_unify__head__body,
  (unsigned char *)"loop",
  preds_in_loop,
  (unsigned char *)"parse_uty",
  preds_in_parse__uty,
  (unsigned char *)"list",
  preds_in_list,
  (unsigned char *)"uty",
  preds_in_uty,
  (unsigned char *)"converter",
  preds_in_converter,
  (unsigned char *)"print",
  preds_in_print,
  (unsigned char *)"analyzer",
  preds_in_analyzer,
  (unsigned char *)"io",
  preds_in_io,
  (unsigned char *)"parser",
  preds_in_parser,
  (unsigned char *)"klic_reader",
  preds_in_klic__reader,
  (unsigned char *)"klicio",
  preds_in_klicio,
  (unsigned char *)"atom_table",
  preds_in_atom__table,
  (unsigned char *)"klic_comp_insert",
  preds_in_klic__comp__insert,
  (unsigned char *)"klic_comp_generate",
  preds_in_klic__comp__generate,
  (unsigned char *)"scanner",
  preds_in_scanner,
  (unsigned char *)"unparser",
  preds_in_unparser,
  (unsigned char *)"klic_comp_obj",
  preds_in_klic__comp__obj,
  (unsigned char *)"functor_table",
  preds_in_functor__table,
  (unsigned char *)"variable",
  preds_in_variable,
  (unsigned char *)"klic_comp_kl1cmp",
  preds_in_klic__comp__kl1cmp,
  (unsigned char *)"unix",
  preds_in_unix,
  (unsigned char *)"main",
  preds_in_main,
  (unsigned char *)"generic",
  preds_in_generic,
  (unsigned char *)"unify_term_dcode",
  preds_in_unify__term__dcode,
  (unsigned char *)"integer_arithmetics",
  preds_in_integer__arithmetics,
  0, 0
};
