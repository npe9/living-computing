/* ----------------------------------------------------------
%        Copyright (C) 1996-1997 Kazuhiko Ohno, Masahiko Ikawa,
%        and Computer Architecture Laboratory, Depertment of
%        Information Science, Kyoto University.
%----------------------------------------------------------- */  

struct hook {
  struct hook *next;		/* next suspension structure */
  union thread_or_consumer {
    long l;			/* long integer for tag manipulation */
    struct threadrec *t;		/* pointer to a thread record */
    struct consumer_object *o;	/* pointer to a consumer object */
  } u;
	struct gstackrec *gstack;
};

struct susprec {
  q backpt;
	struct threadrec *gthread;
  union {
    struct hook first_hook;
    long l;
  } u;
  struct hook first_hook;
};
