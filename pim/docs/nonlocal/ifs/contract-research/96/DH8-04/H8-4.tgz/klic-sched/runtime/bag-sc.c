/* Compiled by KLIC compiler version 2.002 (1997ǯ05��10�� (��) 19��58ʬ16�� JST) */
#include <klic/klichdr.h>
#include <klic/sched.h>
#include "atom.h"
#include "funct.h"

module module_bag();
Const struct predicate predicate_bag_xcreate_1 =
   { module_bag, 0, 1 };
Const struct predicate predicate_bag_xresume__check_0 =
   { module_bag, 1, 0 };
extern Const struct predicate predicate_sorted__bag_xcreate_1;

module module_bag(glbl, qp, allocp, toppred, stackp)
  struct global_variables *glbl;
  struct threadrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
  register q* stackp;
{
  q a0;

  q *reasonp;
 module_top:
  switch_on_pred() {
    case_pred(0, create_1_top);
    last_case_pred(1, resume__check_0_top);
  }

 create_1_top: {
  stackp -= 1;
  a0 = stackp[0];
 create_1_clear_reason:
  reasonp = reasons;
 create_1_0:
  check_stack(2);
  stackp[0] = a0;
  stackp[1] = (q)(&predicate_sorted__bag_xcreate_1);
  stackp += 2;
  proceed();
 create_1_ext_interrupt:
  reasonp = 0l;
 create_1_interrupt:
  toppred = &predicate_bag_xcreate_1;
  goto interrupt_1;
 }

 resume__check_0_top: {
		resume_check();
  }
 interrupt_1:
 stackp[0] = a0;
  interrupt_0:
  interrupt_check();
  loop_within_module(module_bag);
}
