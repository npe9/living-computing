/* Compiled by KLIC compiler version 2.002 (Tue May 23 13:27:38 JST 1995) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_dependency();
Const struct predicate predicate_dependency_xinit__deps_2 =
   { module_dependency, 0, 2 };
Const struct predicate predicate_dependency_xinit__deps__clauses_3 =
   { module_dependency, 1, 3 };
Const struct predicate predicate_dependency_xinit__deps__clause_2 =
   { module_dependency, 2, 2 };
Const struct predicate predicate_dependency_xget__deps__clause_4 =
   { module_dependency, 3, 4 };
Const struct predicate predicate_dependency_xget__deps__clause__goals_2 =
   { module_dependency, 4, 2 };
Const struct predicate predicate_dependency_xget__deps__clause__goals1_4 =
   { module_dependency, 5, 4 };
Const struct predicate predicate_dependency_xget__deps_4 =
   { module_dependency, 6, 4 };
Const struct predicate predicate_dependency_xget__deps1_3 =
   { module_dependency, 7, 3 };
Const struct predicate predicate_dependency_xentry__data__deps_4 =
   { module_dependency, 8, 4 };
Const struct predicate predicate_dependency_xentry__data__deps__filter_3 =
   { module_dependency, 9, 3 };
Const struct predicate predicate_dependency_xentry__data__deps__loops_3 =
   { module_dependency, 10, 3 };
Const struct predicate predicate_dependency_xentry__deps_5 =
   { module_dependency, 11, 5 };
Const struct predicate predicate_dependency_xentry__deps1_4 =
   { module_dependency, 12, 4 };
Const struct predicate predicate_dependency_xmake__control__dep_3 =
   { module_dependency, 13, 3 };
Const struct predicate predicate_dependency_xmake__control__dep__modules_8 =
   { module_dependency, 14, 8 };
Const struct predicate predicate_dependency_xmake__control__dep__clauses_9 =
   { module_dependency, 15, 9 };
Const struct predicate predicate_dependency_xmake__depend__guards_4 =
   { module_dependency, 16, 4 };
Const struct predicate predicate_dependency_xmake__control__dep__guards_6 =
   { module_dependency, 17, 6 };
Const struct predicate predicate_dependency_xmake__control__dep__bodys_9 =
   { module_dependency, 18, 9 };
Const struct predicate predicate_dependency_xcall__make__control__dep__modules_9 =
   { module_dependency, 19, 9 };
Const struct predicate predicate_dependency_xmake__data__dep_5 =
   { module_dependency, 20, 5 };
Const struct predicate predicate_dependency_xmake__data__dep__clauses_7 =
   { module_dependency, 21, 7 };
Const struct predicate predicate_dependency_xmake__data__dep__clause_7 =
   { module_dependency, 22, 7 };
Const struct predicate predicate_dependency_xmake__data__dep__goals_8 =
   { module_dependency, 23, 8 };
Const struct predicate predicate_dependency_xmake__data__dep__goals1_9 =
   { module_dependency, 24, 9 };
Const struct predicate predicate_dependency_xmake__goal__dependency_12 =
   { module_dependency, 25, 12 };
Const struct predicate predicate_dependency_xmake__goal__dependency1_9 =
   { module_dependency, 26, 9 };
Const struct predicate predicate_dependency_xget__var__dependency_8 =
   { module_dependency, 27, 8 };
Const struct predicate predicate_dependency_xget__var__dependency__struct_8 =
   { module_dependency, 28, 8 };
Const struct predicate predicate_dependency_xget__var__dependency__struct1_9 =
   { module_dependency, 29, 9 };
Const struct predicate predicate_dependency_xget__var__dependency__var_8 =
   { module_dependency, 30, 8 };
Const struct predicate predicate_dependency_xget__var__dependency__var1_9 =
   { module_dependency, 31, 9 };
Const struct predicate predicate_dependency_xmake__dependency__unify_8 =
   { module_dependency, 32, 8 };
Const struct predicate predicate_dependency_xget__unify__depgoals_4 =
   { module_dependency, 33, 4 };
Const struct predicate predicate_dependency_xget__unify__depgoals1_5 =
   { module_dependency, 34, 5 };
Const struct predicate predicate_dependency_xget__unify__depgoals2_5 =
   { module_dependency, 35, 5 };
Const struct predicate predicate_dependency_xget__unify__depgoals3_5 =
   { module_dependency, 36, 5 };
Const struct predicate predicate_dependency_xget__unify__depgoals__struct_6 =
   { module_dependency, 37, 6 };
Const struct predicate predicate_dependency_xget__unify__depgoals__dstruct_6 =
   { module_dependency, 38, 6 };
Const struct predicate predicate_dependency_xindirect_4 =
   { module_dependency, 39, 4 };
Const struct predicate predicate_dependency_xindirect__clause_8 =
   { module_dependency, 40, 8 };
Const struct predicate predicate_dependency_xindirect__goals_9 =
   { module_dependency, 41, 9 };
Const struct predicate predicate_dependency_xindirect__goals1_9 =
   { module_dependency, 42, 9 };
Const struct predicate predicate_dependency_xindirect__goal_7 =
   { module_dependency, 43, 7 };
Const struct predicate predicate_dependency_xexpand__indirect_6 =
   { module_dependency, 44, 6 };
Const struct predicate predicate_dependency_xexpand__indirect1_7 =
   { module_dependency, 45, 7 };
Const struct predicate predicate_dependency_xexpand__shared__arg_5 =
   { module_dependency, 46, 5 };
Const struct predicate predicate_dependency_xexpand__shared__clauses_7 =
   { module_dependency, 47, 7 };
Const struct predicate predicate_dependency_xexpand__shared__bodys_8 =
   { module_dependency, 48, 8 };
Const struct predicate predicate_dependency_xexpand__shared__body_9 =
   { module_dependency, 49, 9 };
Const struct predicate predicate_dependency_xexpand__shared__args_9 =
   { module_dependency, 50, 9 };
Const struct predicate predicate_dependency_xexpand__shared__arg_8 =
   { module_dependency, 51, 8 };
Const struct predicate predicate_dependency_xexpand__shared__types_10 =
   { module_dependency, 52, 10 };
Const struct predicate predicate_dependency_xexpand__shared__type_11 =
   { module_dependency, 53, 11 };
Const struct predicate predicate_dependency_xexpand__shared__type__var_15 =
   { module_dependency, 54, 15 };
Const struct predicate predicate_dependency_xexpand__shared__type__struct_11 =
   { module_dependency, 55, 11 };
Const struct predicate predicate_dependency_xexpand__shared__type__add__deps_7 =
   { module_dependency, 56, 7 };
Const struct predicate predicate_dependency_xexpand__shared__type__make__mode_3 =
   { module_dependency, 57, 3 };
Const struct predicate predicate_dependency_xexpand__shared__type__make__mode1_2 =
   { module_dependency, 58, 2 };
extern Const struct predicate predicate_list_xor__unique_3;
extern Const struct predicate predicate_list_xcheck__include_3;
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_functor__table_xfunctor_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_xsetarg_4;
extern Const struct predicate predicate_uty_xnew__functor__init_4;
extern Const struct predicate predicate_parse__uty_xdecode__goalcall_6;
extern Const struct predicate predicate_parse__uty_xget__clause_4;
extern Const struct predicate predicate_parse__uty_xget__next__clause_6;
extern Const struct predicate predicate_parse__uty_xget__goal_6;
extern Const struct predicate predicate_parse__uty_xupdate__goal_7;
extern Const struct predicate predicate_parse__uty_xdecode__goal_4;
extern Const struct predicate predicate_loop_xget__lf__entry_5;
extern Const struct predicate predicate_loop_xcheck__var__within_3;
extern Const struct predicate predicate_type_xget__types_5;
extern Const struct predicate predicate_type_xvalue2types_7;

module module_dependency(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  static Const q funct_const_0[] = {
    makesym(functor_dep_4),
    NILATOM,
    NILATOM,
    makesym(atom___),
    makesym(atom___),
  };
  q a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, init__deps_2_top);
    case_pred(1, init__deps__clauses_3_top);
    case_pred(2, init__deps__clause_2_top);
    case_pred(3, get__deps__clause_4_top);
    case_pred(4, get__deps__clause__goals_2_top);
    case_pred(5, get__deps__clause__goals1_4_top);
    case_pred(6, get__deps_4_top);
    case_pred(7, get__deps1_3_top);
    case_pred(8, entry__data__deps_4_top);
    case_pred(9, entry__data__deps__filter_3_top);
    case_pred(10, entry__data__deps__loops_3_top);
    case_pred(11, entry__deps_5_top);
    case_pred(12, entry__deps1_4_top);
    case_pred(13, make__control__dep_3_top);
    case_pred(14, make__control__dep__modules_8_top);
    case_pred(15, make__control__dep__clauses_9_top);
    case_pred(16, make__depend__guards_4_top);
    case_pred(17, make__control__dep__guards_6_top);
    case_pred(18, make__control__dep__bodys_9_top);
    case_pred(19, call__make__control__dep__modules_9_top);
    case_pred(20, make__data__dep_5_top);
    case_pred(21, make__data__dep__clauses_7_top);
    case_pred(22, make__data__dep__clause_7_top);
    case_pred(23, make__data__dep__goals_8_top);
    case_pred(24, make__data__dep__goals1_9_top);
    case_pred(25, make__goal__dependency_12_top);
    case_pred(26, make__goal__dependency1_9_top);
    case_pred(27, get__var__dependency_8_top);
    case_pred(28, get__var__dependency__struct_8_top);
    case_pred(29, get__var__dependency__struct1_9_top);
    case_pred(30, get__var__dependency__var_8_top);
    case_pred(31, get__var__dependency__var1_9_top);
    case_pred(32, make__dependency__unify_8_top);
    case_pred(33, get__unify__depgoals_4_top);
    case_pred(34, get__unify__depgoals1_5_top);
    case_pred(35, get__unify__depgoals2_5_top);
    case_pred(36, get__unify__depgoals3_5_top);
    case_pred(37, get__unify__depgoals__struct_6_top);
    case_pred(38, get__unify__depgoals__dstruct_6_top);
    case_pred(39, indirect_4_top);
    case_pred(40, indirect__clause_8_top);
    case_pred(41, indirect__goals_9_top);
    case_pred(42, indirect__goals1_9_top);
    case_pred(43, indirect__goal_7_top);
    case_pred(44, expand__indirect_6_top);
    case_pred(45, expand__indirect1_7_top);
    case_pred(46, expand__shared__arg_5_top);
    case_pred(47, expand__shared__clauses_7_top);
    case_pred(48, expand__shared__bodys_8_top);
    case_pred(49, expand__shared__body_9_top);
    case_pred(50, expand__shared__args_9_top);
    case_pred(51, expand__shared__arg_8_top);
    case_pred(52, expand__shared__types_10_top);
    case_pred(53, expand__shared__type_11_top);
    case_pred(54, expand__shared__type__var_15_top);
    case_pred(55, expand__shared__type__struct_11_top);
    case_pred(56, expand__shared__type__add__deps_7_top);
    case_pred(57, expand__shared__type__make__mode_3_top);
    last_case_pred(58, expand__shared__type__make__mode1_2_top);
  }

 init__deps_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  qp = qp->next;
 init__deps_2_clear_reason:
  reasonp = reasons;
 init__deps_2_0:
 init__deps_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 init__deps_2_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto init__deps_2_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xinit__deps_2);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = makesym(functor_module_2);
  allocp[5] = arg(x0, 0);
  allocp[6] = x4 = makeref(&allocp[6]);
  x3 = makefunctor(&allocp[4]);
  allocp[7] = x2;
  allocp[8] = x3;
  x5 = makecons(&allocp[7]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 9;
  unify_value(a1, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xinit__deps__clauses_3);
  allocp[2] = x6 = makeref(&allocp[2]);
  x7 = arg(x0, 1);
  allocp[3] = x7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[7] = x7;
  allocp[8] = x8 = makeref(&allocp[8]);
  allocp[9] = x6;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(x0,init__deps_2_2);
  *reasonp++ =  x0;
  goto init__deps_2_interrupt;
  };
  goto init__deps_2_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto init__deps_2_interrupt;
  unify_value(a1, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a0,init__deps_2_1);
  *reasonp++ =  a0;
  goto init__deps_2_interrupt;
  };
  goto init__deps_2_interrupt;
 init__deps_2_ext_interrupt:
  reasonp = 0l;
 init__deps_2_interrupt:
  goto interrupt_2;
 }

 init__deps__clauses_3_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  qp = qp->next;
 init__deps__clauses_3_clear_reason:
  reasonp = reasons;
 init__deps__clauses_3_0:
 init__deps__clauses_3_1:
  if (!isint(a0)) goto init__deps__clauses_3_3;
  gblt_greater(a0,makeint(0L),init__deps__clauses_3_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xinit__deps__clauses_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[7] = a0;
  allocp[8] = makeint(1L);
  allocp[9] = x0;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[12] = a0;
  allocp[13] = a1;
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = (q)(struct goalrec*)&allocp[10];
  allocp[17] = (q)(&predicate_dependency_xinit__deps__clause_2);
  allocp[18] = x3 = makeref(&allocp[18]);
  allocp[19] = x2;
  allocp[20] = (q)(struct goalrec*)&allocp[16];
  allocp[21] = (q)(&predicate_functor__table_xarg_3);
  allocp[22] = a0;
  allocp[23] = a1;
  allocp[24] = x3;
  qp = (struct goalrec*)&allocp[20];
  allocp += 25;
  proceed();
 init__deps__clauses_3_2:
  if (a0 != makeint(0L)) goto init__deps__clauses_3_interrupt;
  unify(a2, a1);
  proceed();
 init__deps__clauses_3_3:
  if (!isref(a0)) goto init__deps__clauses_3_interrupt;
  deref_and_jump(a0,init__deps__clauses_3_1);
  *reasonp++ =  a0;
  goto init__deps__clauses_3_interrupt;
 init__deps__clauses_3_ext_interrupt:
  reasonp = 0l;
 init__deps__clauses_3_interrupt:
  goto interrupt_3;
 }

 init__deps__clause_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  qp = qp->next;
 init__deps__clause_2_clear_reason:
  reasonp = reasons;
 init__deps__clause_2_0:
 init__deps__clause_2_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_clause_6)) goto init__deps__clause_2_2;
  allocp[0] = makesym(functor_deps_2);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  x0 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_uty_xnew__functor__init_4);
  allocp[2] = makesym(atom_body);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = makefunctor(funct_const_0);
  allocp[5] = x2;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_uty_xnew__functor__init_4);
  allocp[8] = makesym(atom_guard);
  allocp[9] = x4 = makeref(&allocp[9]);
  allocp[10] = makefunctor(funct_const_0);
  allocp[11] = x1;
  allocp[12] = (q)(struct goalrec*)&allocp[6];
  allocp[13] = (q)(&predicate_functor__table_xfunctor_3);
  x5 = arg(a0, 2);
  allocp[14] = x5;
  allocp[15] = x6 = makeref(&allocp[15]);
  allocp[16] = x3;
  allocp[17] = (q)(struct goalrec*)&allocp[12];
  allocp[18] = (q)(&predicate_functor__table_xfunctor_3);
  x7 = arg(a0, 1);
  allocp[19] = x7;
  allocp[20] = x8 = makeref(&allocp[20]);
  allocp[21] = x4;
  qp = (struct goalrec*)&allocp[17];
  allocp += 22;
  proceed();
 case VARREF:
  deref_and_jump(a0,init__deps__clause_2_1);
  *reasonp++ =  a0;
  goto init__deps__clause_2_2;
  };
  goto init__deps__clause_2_2;
 init__deps__clause_2_2:
  otherwise(init__deps__clause_2_interrupt);
  unify_value(a1, makesym(atom_body));
  proceed();
 init__deps__clause_2_ext_interrupt:
  reasonp = 0l;
 init__deps__clause_2_interrupt:
  goto interrupt_2;
 }

 get__deps__clause_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 get__deps__clause_4_clear_reason:
  reasonp = reasons;
 get__deps__clause_4_0:
 get__deps__clause_4_1:
  switch (ptagof(a3)) {
 case CONS:
  x0 = car_of(a3);
 get__deps__clause_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto get__deps__clause_4_7;
  x1 = arg(x0, 0);
 get__deps__clause_4_3:
  if (isref(x1)) goto get__deps__clause_4_6;
 get__deps__clause_4_4:
  if (isref(x1)) goto get__deps__clause_4_5;
  if_not_equal(x1, a0, get__deps__clause_4_7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_list_xor__unique_3);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_dependency_xget__deps__clause__goals_2);
  allocp[7] = x4 = makeref(&allocp[7]);
  allocp[8] = x3;
  allocp[9] = (q)(struct goalrec*)&allocp[5];
  allocp[10] = (q)(&predicate_dependency_xget__deps__clause__goals_2);
  allocp[11] = x5 = makeref(&allocp[11]);
  allocp[12] = x2;
  allocp[13] = makesym(functor_deps_2);
  allocp[14] = x5;
  allocp[15] = x4;
  x6 = makefunctor(&allocp[13]);
  allocp[16] = (q)(struct goalrec*)&allocp[9];
  allocp[17] = (q)(&predicate_functor__table_xarg_3);
  allocp[18] = a1;
  x7 = arg(x0, 1);
  allocp[19] = x7;
  allocp[20] = x6;
  qp = (struct goalrec*)&allocp[16];
  allocp += 21;
  proceed();
 get__deps__clause_4_5:
  deref_and_jump(x1,get__deps__clause_4_4);
  *reasonp++ =  x1;
  goto get__deps__clause_4_7;
 get__deps__clause_4_6:
  deref_and_jump(x1,get__deps__clause_4_3);
  *reasonp++ =  x1;
  goto get__deps__clause_4_7;
 case VARREF:
  deref_and_jump(x0,get__deps__clause_4_2);
  *reasonp++ =  x0;
  goto get__deps__clause_4_7;
  };
  goto get__deps__clause_4_7;
 case VARREF:
  deref_and_jump(a3,get__deps__clause_4_1);
  *reasonp++ =  a3;
  goto get__deps__clause_4_7;
  };
  goto get__deps__clause_4_7;
 get__deps__clause_4_7:
  otherwise(get__deps__clause_4_interrupt);
 get__deps__clause_4_8:
  switch (ptagof(a3)) {
 case CONS:
  a3 = cdr_of(a3);
  execute(get__deps__clause_4_0);
  goto get__deps__clause_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a3,get__deps__clause_4_8);
  *reasonp++ =  a3;
  goto get__deps__clause_4_interrupt;
  };
  goto get__deps__clause_4_interrupt;
 get__deps__clause_4_ext_interrupt:
  reasonp = 0l;
 get__deps__clause_4_interrupt:
  goto interrupt_4;
 }

 get__deps__clause__goals_2_top: {
  q x0, x1;
  qp = qp->next;
 get__deps__clause__goals_2_clear_reason:
  reasonp = reasons;
 get__deps__clause__goals_2_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xget__deps__clause__goals1_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = NILATOM;
  allocp[5] = a1;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[8] = a0;
  allocp[9] = x1 = makeref(&allocp[9]);
  allocp[10] = x0;
  qp = (struct goalrec*)&allocp[6];
  allocp += 11;
  proceed();
 get__deps__clause__goals_2_ext_interrupt:
  reasonp = 0l;
 get__deps__clause__goals_2_interrupt:
  goto interrupt_2;
 }

 get__deps__clause__goals1_4_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 get__deps__clause__goals1_4_clear_reason:
  reasonp = reasons;
 get__deps__clause__goals1_4_0:
 get__deps__clause__goals1_4_1:
  if (!isint(a0)) goto get__deps__clause__goals1_4_3;
  gblt_greater(a0,makeint(0L),get__deps__clause__goals1_4_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xget__deps__clause__goals1_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x0;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_list_xor__unique_3);
  allocp[13] = a2;
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = makesym(functor_dep_4);
  allocp[17] = x4 = makeref(&allocp[17]);
  allocp[18] = x2;
  allocp[19] = x5 = makeref(&allocp[19]);
  allocp[20] = x6 = makeref(&allocp[20]);
  x3 = makefunctor(&allocp[16]);
  allocp[21] = (q)(struct goalrec*)&allocp[11];
  allocp[22] = (q)(&predicate_functor__table_xarg_3);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = x3;
  qp = (struct goalrec*)&allocp[21];
  allocp += 26;
  proceed();
 get__deps__clause__goals1_4_2:
  if (a0 != makeint(0L)) goto get__deps__clause__goals1_4_interrupt;
  unify(a3, a2);
  proceed();
 get__deps__clause__goals1_4_3:
  if (!isref(a0)) goto get__deps__clause__goals1_4_interrupt;
  deref_and_jump(a0,get__deps__clause__goals1_4_1);
  *reasonp++ =  a0;
  goto get__deps__clause__goals1_4_interrupt;
 get__deps__clause__goals1_4_ext_interrupt:
  reasonp = 0l;
 get__deps__clause__goals1_4_interrupt:
  goto interrupt_4;
 }

 get__deps_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 get__deps_4_clear_reason:
  reasonp = reasons;
 get__deps_4_0:
 get__deps_4_1:
  switch (ptagof(a3)) {
 case CONS:
 get__deps_4_2:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_goal_4)) goto get__deps_4_14;
  x0 = arg(a1, 3);
 get__deps_4_3:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (isint(x0)) goto get__deps_4_14;
  switch (symval(x0)) {
 case symval(makesym(atom_guard)):
  x1 = car_of(a3);
 get__deps_4_4:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_module_2)) goto get__deps_4_14;
  x2 = arg(x1, 0);
 get__deps_4_5:
  if (isref(x2)) goto get__deps_4_8;
 get__deps_4_6:
  if (isref(x2)) goto get__deps_4_7;
  x3 = arg(a1, 0);
  if_not_equal(x2, x3, get__deps_4_14);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xget__deps1_3);
  allocp[2] = a0;
  allocp[3] = x4 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  x5 = arg(a1, 2);
  allocp[7] = x5;
  allocp[8] = x6 = makeref(&allocp[8]);
  allocp[9] = x4;
  allocp[10] = makesym(functor_deps_2);
  allocp[11] = x6;
  allocp[12] = x8 = makeref(&allocp[12]);
  x7 = makefunctor(&allocp[10]);
  allocp[13] = (q)(struct goalrec*)&allocp[5];
  allocp[14] = (q)(&predicate_functor__table_xarg_3);
  x9 = arg(a1, 1);
  allocp[15] = x9;
  x10 = arg(x1, 1);
  allocp[16] = x10;
  allocp[17] = x7;
  qp = (struct goalrec*)&allocp[13];
  allocp += 18;
  proceed();
 get__deps_4_7:
  deref_and_jump(x2,get__deps_4_6);
  *reasonp++ =  x2;
  goto get__deps_4_14;
 get__deps_4_8:
  deref_and_jump(x2,get__deps_4_5);
  *reasonp++ =  x2;
  goto get__deps_4_14;
 case VARREF:
  deref_and_jump(x1,get__deps_4_4);
  *reasonp++ =  x1;
  goto get__deps_4_14;
  };
  goto get__deps_4_14;
 case symval(makesym(atom_body)):
  x1 = car_of(a3);
 get__deps_4_9:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_module_2)) goto get__deps_4_14;
  x2 = arg(x1, 0);
 get__deps_4_10:
  if (isref(x2)) goto get__deps_4_13;
 get__deps_4_11:
  if (isref(x2)) goto get__deps_4_12;
  x3 = arg(a1, 0);
  if_not_equal(x2, x3, get__deps_4_14);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xget__deps1_3);
  allocp[2] = a0;
  allocp[3] = x4 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  x5 = arg(a1, 2);
  allocp[7] = x5;
  allocp[8] = x6 = makeref(&allocp[8]);
  allocp[9] = x4;
  allocp[10] = makesym(functor_deps_2);
  allocp[11] = x8 = makeref(&allocp[11]);
  allocp[12] = x6;
  x7 = makefunctor(&allocp[10]);
  allocp[13] = (q)(struct goalrec*)&allocp[5];
  allocp[14] = (q)(&predicate_functor__table_xarg_3);
  x9 = arg(a1, 1);
  allocp[15] = x9;
  x10 = arg(x1, 1);
  allocp[16] = x10;
  allocp[17] = x7;
  qp = (struct goalrec*)&allocp[13];
  allocp += 18;
  proceed();
 get__deps_4_12:
  deref_and_jump(x2,get__deps_4_11);
  *reasonp++ =  x2;
  goto get__deps_4_14;
 get__deps_4_13:
  deref_and_jump(x2,get__deps_4_10);
  *reasonp++ =  x2;
  goto get__deps_4_14;
 case VARREF:
  deref_and_jump(x1,get__deps_4_9);
  *reasonp++ =  x1;
  goto get__deps_4_14;
  };
  goto get__deps_4_14;
  };
  goto get__deps_4_14;
 case VARREF:
  deref_and_jump(x0,get__deps_4_3);
  *reasonp++ =  x0;
  goto get__deps_4_14;
  };
  goto get__deps_4_14;
 case VARREF:
  deref_and_jump(a1,get__deps_4_2);
  *reasonp++ =  a1;
  goto get__deps_4_14;
  };
  goto get__deps_4_14;
 case VARREF:
  deref_and_jump(a3,get__deps_4_1);
  *reasonp++ =  a3;
  goto get__deps_4_14;
  };
  goto get__deps_4_14;
 get__deps_4_14:
  otherwise(get__deps_4_interrupt);
 get__deps_4_15:
  switch (ptagof(a3)) {
 case CONS:
  a3 = cdr_of(a3);
  execute(get__deps_4_0);
  goto get__deps_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a3,get__deps_4_15);
  *reasonp++ =  a3;
  goto get__deps_4_interrupt;
  };
  goto get__deps_4_interrupt;
 get__deps_4_ext_interrupt:
  reasonp = 0l;
 get__deps_4_interrupt:
  toppred = &predicate_dependency_xget__deps_4;
  goto interrupt_4;
 }

 get__deps1_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 get__deps1_3_clear_reason:
  reasonp = reasons;
 get__deps1_3_0:
 get__deps1_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto get__deps1_3_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_control)):
 get__deps1_3_2:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_dep_4)) goto get__deps1_3_interrupt;
  x0 = arg(a1, 0);
  unify(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,get__deps1_3_2);
  *reasonp++ =  a1;
  goto get__deps1_3_interrupt;
  };
  goto get__deps1_3_interrupt;
 case symval(makesym(atom_data)):
 get__deps1_3_3:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_dep_4)) goto get__deps1_3_interrupt;
  x0 = arg(a1, 1);
  unify(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,get__deps1_3_3);
  *reasonp++ =  a1;
  goto get__deps1_3_interrupt;
  };
  goto get__deps1_3_interrupt;
 case symval(makesym(atom_execute)):
 get__deps1_3_4:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_dep_4)) goto get__deps1_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_list_xor__unique_3);
  x0 = arg(a1, 0);
  allocp[2] = x0;
  x1 = arg(a1, 1);
  allocp[3] = x1;
  allocp[4] = a2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case VARREF:
  deref_and_jump(a1,get__deps1_3_4);
  *reasonp++ =  a1;
  goto get__deps1_3_interrupt;
  };
  goto get__deps1_3_interrupt;
 case symval(makesym(atom_loopname)):
 get__deps1_3_5:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_dep_4)) goto get__deps1_3_interrupt;
  x0 = arg(a1, 2);
  unify(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,get__deps1_3_5);
  *reasonp++ =  a1;
  goto get__deps1_3_interrupt;
  };
  goto get__deps1_3_interrupt;
 case symval(makesym(atom_decendants)):
 get__deps1_3_6:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_dep_4)) goto get__deps1_3_interrupt;
  x0 = arg(a1, 3);
  unify(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,get__deps1_3_6);
  *reasonp++ =  a1;
  goto get__deps1_3_interrupt;
  };
  goto get__deps1_3_interrupt;
  };
  goto get__deps1_3_interrupt;
 case VARREF:
  deref_and_jump(a0,get__deps1_3_1);
  *reasonp++ =  a0;
  goto get__deps1_3_interrupt;
  };
  goto get__deps1_3_interrupt;
 get__deps1_3_ext_interrupt:
  reasonp = 0l;
 get__deps1_3_interrupt:
  goto interrupt_3;
 }

 entry__data__deps_4_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 entry__data__deps_4_clear_reason:
  reasonp = reasons;
 entry__data__deps_4_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xentry__data__deps__loops_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a3;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_dependency_xentry__deps_5);
  allocp[7] = makesym(atom_data);
  allocp[8] = a0;
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a2;
  allocp[11] = x1;
  a0 = a1;
  a1 = x0;
  a2 = x2;
  qp = (struct goalrec*)&allocp[5];
  allocp += 12;
  execute(entry__data__deps__filter_3_0);
  goto entry__data__deps__filter_3_ext_interrupt;
 entry__data__deps_4_ext_interrupt:
  reasonp = 0l;
 entry__data__deps_4_interrupt:
  toppred = &predicate_dependency_xentry__data__deps_4;
  goto interrupt_4;
 }

 entry__data__deps__filter_3_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  qp = qp->next;
 entry__data__deps__filter_3_clear_reason:
  reasonp = reasons;
 entry__data__deps__filter_3_0:
 entry__data__deps__filter_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 entry__data__deps__filter_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_goal_4)) goto entry__data__deps__filter_3_4;
  x1 = arg(x0, 3);
 entry__data__deps__filter_3_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_alias)) goto entry__data__deps__filter_3_4;
  a0 = cdr_of(a0);
  execute(entry__data__deps__filter_3_0);
  goto entry__data__deps__filter_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,entry__data__deps__filter_3_3);
  *reasonp++ =  x1;
  goto entry__data__deps__filter_3_4;
  };
  goto entry__data__deps__filter_3_4;
 case VARREF:
  deref_and_jump(x0,entry__data__deps__filter_3_2);
  *reasonp++ =  x0;
  goto entry__data__deps__filter_3_4;
  };
  goto entry__data__deps__filter_3_4;
 case VARREF:
  deref_and_jump(a0,entry__data__deps__filter_3_1);
  *reasonp++ =  a0;
  goto entry__data__deps__filter_3_4;
  };
  goto entry__data__deps__filter_3_4;
 entry__data__deps__filter_3_4:
  otherwise(entry__data__deps__filter_3_interrupt);
 entry__data__deps__filter_3_5:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 entry__data__deps__filter_3_6:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_goal_4:
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = x0;
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x1);
  a0 = cdr_of(a0);
  a2 = x2;
  execute(entry__data__deps__filter_3_0);
  goto entry__data__deps__filter_3_ext_interrupt;
 case functor_loopgoal_2:
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = x0;
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x1);
  a0 = cdr_of(a0);
  a1 = x2;
  execute(entry__data__deps__filter_3_0);
  goto entry__data__deps__filter_3_ext_interrupt;
  };
  goto entry__data__deps__filter_3_interrupt;
 case VARREF:
  deref_and_jump(x0,entry__data__deps__filter_3_6);
  *reasonp++ =  x0;
  goto entry__data__deps__filter_3_interrupt;
  };
  goto entry__data__deps__filter_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto entry__data__deps__filter_3_interrupt;
  unify_value(a1, NILATOM);
  unify_value(a2, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a0,entry__data__deps__filter_3_5);
  *reasonp++ =  a0;
  goto entry__data__deps__filter_3_interrupt;
  };
  goto entry__data__deps__filter_3_interrupt;
 entry__data__deps__filter_3_ext_interrupt:
  reasonp = 0l;
 entry__data__deps__filter_3_interrupt:
  toppred = &predicate_dependency_xentry__data__deps__filter_3;
  goto interrupt_3;
 }

 entry__data__deps__loops_3_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  qp = qp->next;
 entry__data__deps__loops_3_clear_reason:
  reasonp = reasons;
 entry__data__deps__loops_3_0:
 entry__data__deps__loops_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 entry__data__deps__loops_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_loopgoal_2)) goto entry__data__deps__loops_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xentry__data__deps__loops_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  a0 = arg(x0, 0);
  x3 = arg(x0, 1);
  a2 = a1;
  a3 = x2;
  a1 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(entry__data__deps_4_0);
  goto entry__data__deps_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,entry__data__deps__loops_3_2);
  *reasonp++ =  x0;
  goto entry__data__deps__loops_3_interrupt;
  };
  goto entry__data__deps__loops_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto entry__data__deps__loops_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,entry__data__deps__loops_3_1);
  *reasonp++ =  a0;
  goto entry__data__deps__loops_3_interrupt;
  };
  goto entry__data__deps__loops_3_interrupt;
 entry__data__deps__loops_3_ext_interrupt:
  reasonp = 0l;
 entry__data__deps__loops_3_interrupt:
  goto interrupt_3;
 }

 entry__deps_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 entry__deps_5_clear_reason:
  reasonp = reasons;
 entry__deps_5_0:
 entry__deps_5_1:
  switch (ptagof(a3)) {
 case CONS:
 entry__deps_5_2:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_goal_4)) goto entry__deps_5_14;
  x0 = arg(a1, 3);
 entry__deps_5_3:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (isint(x0)) goto entry__deps_5_14;
  switch (symval(x0)) {
 case symval(makesym(atom_guard)):
  x1 = car_of(a3);
 entry__deps_5_4:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_module_2)) goto entry__deps_5_14;
  x2 = arg(x1, 0);
 entry__deps_5_5:
  if (isref(x2)) goto entry__deps_5_8;
 entry__deps_5_6:
  if (isref(x2)) goto entry__deps_5_7;
  x3 = arg(a1, 0);
  if_not_equal(x2, x3, entry__deps_5_14);
  allocp[0] = makesym(functor_module_2);
  allocp[1] = x3;
  allocp[2] = x5 = makeref(&allocp[2]);
  x4 = makefunctor(&allocp[0]);
  allocp[3] = cdr_of(a3);
  allocp[4] = x4;
  x6 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a4, x6);
  allocp[0] = makesym(functor_deps_2);
  allocp[1] = x8 = makeref(&allocp[1]);
  allocp[2] = x9 = makeref(&allocp[2]);
  x7 = makefunctor(&allocp[0]);
  allocp[3] = (q)qp;
  allocp[4] = (q)(&predicate_functor__table_xsetarg_4);
  x10 = arg(a1, 1);
  allocp[5] = x10;
  x11 = arg(x1, 1);
  allocp[6] = x11;
  allocp[7] = x7;
  allocp[8] = x5;
  allocp[9] = (q)(struct goalrec*)&allocp[3];
  allocp[10] = (q)(&predicate_functor__table_xsetarg_4);
  x12 = arg(a1, 2);
  allocp[11] = x12;
  allocp[12] = x13 = makeref(&allocp[12]);
  allocp[13] = x14 = makeref(&allocp[13]);
  allocp[14] = x8;
  allocp[15] = (q)(struct goalrec*)&allocp[9];
  allocp[16] = (q)(&predicate_dependency_xentry__deps1_4);
  allocp[17] = a0;
  allocp[18] = x15 = makeref(&allocp[18]);
  allocp[19] = a2;
  allocp[20] = x14;
  allocp[21] = (q)(struct goalrec*)&allocp[15];
  allocp[22] = (q)(&predicate_functor__table_xarg_3);
  allocp[23] = x12;
  allocp[24] = x13;
  allocp[25] = x15;
  allocp[26] = makesym(functor_deps_2);
  allocp[27] = x13;
  allocp[28] = x9;
  x16 = makefunctor(&allocp[26]);
  allocp[29] = (q)(struct goalrec*)&allocp[21];
  allocp[30] = (q)(&predicate_functor__table_xarg_3);
  allocp[31] = x10;
  allocp[32] = x11;
  allocp[33] = x16;
  qp = (struct goalrec*)&allocp[29];
  allocp += 34;
  proceed();
 entry__deps_5_7:
  deref_and_jump(x2,entry__deps_5_6);
  *reasonp++ =  x2;
  goto entry__deps_5_14;
 entry__deps_5_8:
  deref_and_jump(x2,entry__deps_5_5);
  *reasonp++ =  x2;
  goto entry__deps_5_14;
 case VARREF:
  deref_and_jump(x1,entry__deps_5_4);
  *reasonp++ =  x1;
  goto entry__deps_5_14;
  };
  goto entry__deps_5_14;
 case symval(makesym(atom_body)):
  x1 = car_of(a3);
 entry__deps_5_9:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_module_2)) goto entry__deps_5_14;
  x2 = arg(x1, 0);
 entry__deps_5_10:
  if (isref(x2)) goto entry__deps_5_13;
 entry__deps_5_11:
  if (isref(x2)) goto entry__deps_5_12;
  x3 = arg(a1, 0);
  if_not_equal(x2, x3, entry__deps_5_14);
  allocp[0] = makesym(functor_module_2);
  allocp[1] = x3;
  allocp[2] = x5 = makeref(&allocp[2]);
  x4 = makefunctor(&allocp[0]);
  allocp[3] = cdr_of(a3);
  allocp[4] = x4;
  x6 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a4, x6);
  allocp[0] = makesym(functor_deps_2);
  allocp[1] = x8 = makeref(&allocp[1]);
  allocp[2] = x9 = makeref(&allocp[2]);
  x7 = makefunctor(&allocp[0]);
  allocp[3] = (q)qp;
  allocp[4] = (q)(&predicate_functor__table_xsetarg_4);
  x10 = arg(a1, 1);
  allocp[5] = x10;
  x11 = arg(x1, 1);
  allocp[6] = x11;
  allocp[7] = x7;
  allocp[8] = x5;
  allocp[9] = (q)(struct goalrec*)&allocp[3];
  allocp[10] = (q)(&predicate_functor__table_xsetarg_4);
  x12 = arg(a1, 2);
  allocp[11] = x12;
  allocp[12] = x13 = makeref(&allocp[12]);
  allocp[13] = x14 = makeref(&allocp[13]);
  allocp[14] = x9;
  allocp[15] = (q)(struct goalrec*)&allocp[9];
  allocp[16] = (q)(&predicate_dependency_xentry__deps1_4);
  allocp[17] = a0;
  allocp[18] = x15 = makeref(&allocp[18]);
  allocp[19] = a2;
  allocp[20] = x14;
  allocp[21] = (q)(struct goalrec*)&allocp[15];
  allocp[22] = (q)(&predicate_functor__table_xarg_3);
  allocp[23] = x12;
  allocp[24] = x13;
  allocp[25] = x15;
  allocp[26] = makesym(functor_deps_2);
  allocp[27] = x8;
  allocp[28] = x13;
  x16 = makefunctor(&allocp[26]);
  allocp[29] = (q)(struct goalrec*)&allocp[21];
  allocp[30] = (q)(&predicate_functor__table_xarg_3);
  allocp[31] = x10;
  allocp[32] = x11;
  allocp[33] = x16;
  qp = (struct goalrec*)&allocp[29];
  allocp += 34;
  proceed();
 entry__deps_5_12:
  deref_and_jump(x2,entry__deps_5_11);
  *reasonp++ =  x2;
  goto entry__deps_5_14;
 entry__deps_5_13:
  deref_and_jump(x2,entry__deps_5_10);
  *reasonp++ =  x2;
  goto entry__deps_5_14;
 case VARREF:
  deref_and_jump(x1,entry__deps_5_9);
  *reasonp++ =  x1;
  goto entry__deps_5_14;
  };
  goto entry__deps_5_14;
  };
  goto entry__deps_5_14;
 case VARREF:
  deref_and_jump(x0,entry__deps_5_3);
  *reasonp++ =  x0;
  goto entry__deps_5_14;
  };
  goto entry__deps_5_14;
 case VARREF:
  deref_and_jump(a1,entry__deps_5_2);
  *reasonp++ =  a1;
  goto entry__deps_5_14;
  };
  goto entry__deps_5_14;
 case VARREF:
  deref_and_jump(a3,entry__deps_5_1);
  *reasonp++ =  a3;
  goto entry__deps_5_14;
  };
  goto entry__deps_5_14;
 entry__deps_5_14:
  otherwise(entry__deps_5_interrupt);
 entry__deps_5_15:
  switch (ptagof(a3)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = car_of(a3);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a4, x0);
  a3 = cdr_of(a3);
  a4 = x1;
  execute(entry__deps_5_0);
  goto entry__deps_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a3,entry__deps_5_15);
  *reasonp++ =  a3;
  goto entry__deps_5_interrupt;
  };
  goto entry__deps_5_interrupt;
 entry__deps_5_ext_interrupt:
  reasonp = 0l;
 entry__deps_5_interrupt:
  toppred = &predicate_dependency_xentry__deps_5;
  goto interrupt_5;
 }

 entry__deps1_4_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 entry__deps1_4_clear_reason:
  reasonp = reasons;
 entry__deps1_4_0:
 entry__deps1_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto entry__deps1_4_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_control)):
  allocp[0] = makesym(functor_dep_4);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  x0 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a1, x0);
  allocp[0] = makesym(functor_dep_4);
  allocp[1] = x6 = makeref(&allocp[1]);
  allocp[2] = x2;
  allocp[3] = x3;
  allocp[4] = x4;
  x5 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a3, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_list_xor__unique_3);
  allocp[2] = x1;
  allocp[3] = a2;
  allocp[4] = x6;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case symval(makesym(atom_data)):
  allocp[0] = makesym(functor_dep_4);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  x0 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a1, x0);
  allocp[0] = makesym(functor_dep_4);
  allocp[1] = x1;
  allocp[2] = x6 = makeref(&allocp[2]);
  allocp[3] = x3;
  allocp[4] = x4;
  x5 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a3, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_list_xor__unique_3);
  allocp[2] = x2;
  allocp[3] = a2;
  allocp[4] = x6;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case symval(makesym(atom_loopname)):
  allocp[0] = makesym(functor_dep_4);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  x0 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a1, x0);
  allocp[0] = makesym(functor_dep_4);
  allocp[1] = x1;
  allocp[2] = x2;
  allocp[3] = a2;
  allocp[4] = x4;
  x5 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a3, x5);
  proceed();
 case symval(makesym(atom_decendants)):
  allocp[0] = makesym(functor_dep_4);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  x0 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a1, x0);
  allocp[0] = makesym(functor_dep_4);
  allocp[1] = x1;
  allocp[2] = x2;
  allocp[3] = x3;
  allocp[4] = a2;
  x5 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a3, x5);
  proceed();
  };
  goto entry__deps1_4_interrupt;
 case VARREF:
  deref_and_jump(a0,entry__deps1_4_1);
  *reasonp++ =  a0;
  goto entry__deps1_4_interrupt;
  };
  goto entry__deps1_4_interrupt;
 entry__deps1_4_ext_interrupt:
  reasonp = 0l;
 entry__deps1_4_interrupt:
  goto interrupt_4;
 }

 make__control__dep_3_top: {
  a2 = qp->args[2];
  qp = qp->next;
 make__control__dep_3_clear_reason:
  reasonp = reasons;
 make__control__dep_3_0:
  a3 = makesym(atom_none);
  a4 = a0;
  a5 = a0;
  a6 = a1;
  a7 = a2;
  a2 = makeint(0L);
  a1 = makesym(atom_main);
  a0 = makesym(atom_main);
  execute(make__control__dep__modules_8_0);
  goto make__control__dep__modules_8_ext_interrupt;
 make__control__dep_3_ext_interrupt:
  reasonp = 0l;
 make__control__dep_3_interrupt:
  goto interrupt_3;
 }

 make__control__dep__modules_8_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 make__control__dep__modules_8_clear_reason:
  reasonp = reasons;
 make__control__dep__modules_8_0:
 make__control__dep__modules_8_1:
  switch (ptagof(a4)) {
 case CONS:
  x0 = car_of(a4);
 make__control__dep__modules_8_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto make__control__dep__modules_8_7;
  x1 = arg(x0, 0);
 make__control__dep__modules_8_3:
  if (isref(x1)) goto make__control__dep__modules_8_6;
 make__control__dep__modules_8_4:
  if (isref(x1)) goto make__control__dep__modules_8_5;
  if_not_equal(x1, a0, make__control__dep__modules_8_7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xmake__control__dep__clauses_9);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  x2 = arg(x0, 1);
  allocp[6] = x2;
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[13] = x2;
  allocp[14] = x4 = makeref(&allocp[14]);
  allocp[15] = x3;
  qp = (struct goalrec*)&allocp[11];
  allocp += 16;
  proceed();
 make__control__dep__modules_8_5:
  deref_and_jump(x1,make__control__dep__modules_8_4);
  *reasonp++ =  x1;
  goto make__control__dep__modules_8_7;
 make__control__dep__modules_8_6:
  deref_and_jump(x1,make__control__dep__modules_8_3);
  *reasonp++ =  x1;
  goto make__control__dep__modules_8_7;
 case VARREF:
  deref_and_jump(x0,make__control__dep__modules_8_2);
  *reasonp++ =  x0;
  goto make__control__dep__modules_8_7;
  };
  goto make__control__dep__modules_8_7;
 case VARREF:
  deref_and_jump(a4,make__control__dep__modules_8_1);
  *reasonp++ =  a4;
  goto make__control__dep__modules_8_7;
  };
  goto make__control__dep__modules_8_7;
 make__control__dep__modules_8_7:
  otherwise(make__control__dep__modules_8_interrupt);
 make__control__dep__modules_8_8:
  switch (ptagof(a4)) {
 case CONS:
  a4 = cdr_of(a4);
  execute(make__control__dep__modules_8_0);
  goto make__control__dep__modules_8_ext_interrupt;
 case VARREF:
  deref_and_jump(a4,make__control__dep__modules_8_8);
  *reasonp++ =  a4;
  goto make__control__dep__modules_8_interrupt;
  };
  goto make__control__dep__modules_8_interrupt;
 make__control__dep__modules_8_ext_interrupt:
  reasonp = 0l;
 make__control__dep__modules_8_interrupt:
  toppred = &predicate_dependency_xmake__control__dep__modules_8;
  goto interrupt_8;
 }

 make__control__dep__clauses_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 make__control__dep__clauses_9_clear_reason:
  reasonp = reasons;
 make__control__dep__clauses_9_0:
 make__control__dep__clauses_9_1:
  if (!isint(a5)) goto make__control__dep__clauses_9_16;
  gblt_greater(a5,makeint(0L),make__control__dep__clauses_9_17);
 make__control__dep__clauses_9_2:
  if (isref(a4)) goto make__control__dep__clauses_9_15;
  gblt_arg(a5,a4,x0,make__control__dep__clauses_9_17);
 make__control__dep__clauses_9_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_clause_6)) goto make__control__dep__clauses_9_17;
  x1 = arg(x0, 0);
 make__control__dep__clauses_9_4:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_functor_3)) goto make__control__dep__clauses_9_17;
  x2 = arg(x1, 0);
 make__control__dep__clauses_9_5:
  if (isref(x2)) goto make__control__dep__clauses_9_14;
  gblt_pfunctor(x2,x3,make__control__dep__clauses_9_17);
 make__control__dep__clauses_9_6:
  if (isref(x3)) goto make__control__dep__clauses_9_13;
 make__control__dep__clauses_9_7:
  if (isref(x3)) goto make__control__dep__clauses_9_12;
  if_not_equal(x3, a1, make__control__dep__clauses_9_17);
  gblt_arity(x2,x4,make__control__dep__clauses_9_17);
 make__control__dep__clauses_9_8:
  if (isref(x4)) goto make__control__dep__clauses_9_11;
 make__control__dep__clauses_9_9:
  if (isref(x4)) goto make__control__dep__clauses_9_10;
  if_not_equal(x4, a2, make__control__dep__clauses_9_17);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xmake__control__dep__clauses_9);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x5 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[13] = a5;
  allocp[14] = makeint(1L);
  allocp[15] = x5;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_dependency_xmake__control__dep__bodys_9);
  allocp[18] = x7 = makeref(&allocp[18]);
  x8 = arg(x0, 2);
  allocp[19] = x8;
  allocp[20] = a0;
  allocp[21] = a5;
  allocp[22] = a3;
  allocp[23] = x9 = makeref(&allocp[23]);
  allocp[24] = a6;
  allocp[25] = x10 = makeref(&allocp[25]);
  allocp[26] = x6;
  allocp[27] = (q)(struct goalrec*)&allocp[16];
  allocp[28] = (q)(&predicate_dependency_xmake__control__dep__guards_6);
  allocp[29] = x11 = makeref(&allocp[29]);
  allocp[30] = a3;
  allocp[31] = a0;
  allocp[32] = a5;
  allocp[33] = a7;
  allocp[34] = x10;
  allocp[35] = (q)(struct goalrec*)&allocp[27];
  allocp[36] = (q)(&predicate_dependency_xmake__depend__guards_4);
  allocp[37] = x11;
  allocp[38] = a0;
  allocp[39] = a5;
  allocp[40] = x9;
  allocp[41] = (q)(struct goalrec*)&allocp[35];
  allocp[42] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[43] = x8;
  allocp[44] = x12 = makeref(&allocp[44]);
  allocp[45] = x7;
  allocp[46] = (q)(struct goalrec*)&allocp[41];
  allocp[47] = (q)(&predicate_functor__table_xfunctor_3);
  x13 = arg(x0, 1);
  allocp[48] = x13;
  allocp[49] = x14 = makeref(&allocp[49]);
  allocp[50] = x11;
  qp = (struct goalrec*)&allocp[46];
  allocp += 51;
  proceed();
 make__control__dep__clauses_9_10:
  deref_and_jump(x4,make__control__dep__clauses_9_9);
  *reasonp++ =  x4;
  goto make__control__dep__clauses_9_17;
 make__control__dep__clauses_9_11:
  deref_and_jump(x4,make__control__dep__clauses_9_8);
  *reasonp++ =  x4;
  goto make__control__dep__clauses_9_17;
 make__control__dep__clauses_9_12:
  deref_and_jump(x3,make__control__dep__clauses_9_7);
  *reasonp++ =  x3;
  goto make__control__dep__clauses_9_17;
 make__control__dep__clauses_9_13:
  deref_and_jump(x3,make__control__dep__clauses_9_6);
  *reasonp++ =  x3;
  goto make__control__dep__clauses_9_17;
 make__control__dep__clauses_9_14:
  deref_and_jump(x2,make__control__dep__clauses_9_5);
  *reasonp++ =  x2;
  goto make__control__dep__clauses_9_17;
 case VARREF:
  deref_and_jump(x1,make__control__dep__clauses_9_4);
  *reasonp++ =  x1;
  goto make__control__dep__clauses_9_17;
  };
  goto make__control__dep__clauses_9_17;
 case VARREF:
  deref_and_jump(x0,make__control__dep__clauses_9_3);
  *reasonp++ =  x0;
  goto make__control__dep__clauses_9_17;
  };
  goto make__control__dep__clauses_9_17;
 make__control__dep__clauses_9_15:
  deref_and_jump(a4,make__control__dep__clauses_9_2);
  *reasonp++ =  a4;
  goto make__control__dep__clauses_9_17;
 make__control__dep__clauses_9_16:
  if (!isref(a5)) goto make__control__dep__clauses_9_17;
  deref_and_jump(a5,make__control__dep__clauses_9_1);
  *reasonp++ =  a5;
  goto make__control__dep__clauses_9_17;
 make__control__dep__clauses_9_17:
  otherwise(make__control__dep__clauses_9_interrupt);
 make__control__dep__clauses_9_18:
  if (!isint(a5)) goto make__control__dep__clauses_9_20;
  gblt_greater(a5,makeint(0L),make__control__dep__clauses_9_19);
  bblt_sub_no_check(a5,makeint(1L),x0);
  a5 = x0;
  execute(make__control__dep__clauses_9_0);
  goto make__control__dep__clauses_9_ext_interrupt;
 make__control__dep__clauses_9_19:
  if (a5 != makeint(0L)) goto make__control__dep__clauses_9_interrupt;
  unify(a8, a7);
  proceed();
 make__control__dep__clauses_9_20:
  if (!isref(a5)) goto make__control__dep__clauses_9_interrupt;
  deref_and_jump(a5,make__control__dep__clauses_9_18);
  *reasonp++ =  a5;
  goto make__control__dep__clauses_9_interrupt;
 make__control__dep__clauses_9_ext_interrupt:
  reasonp = 0l;
 make__control__dep__clauses_9_interrupt:
  goto interrupt_9;
 }

 make__depend__guards_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 make__depend__guards_4_clear_reason:
  reasonp = reasons;
 make__depend__guards_4_0:
 make__depend__guards_4_1:
  if (!isint(a0)) goto make__depend__guards_4_3;
  gblt_greater(a0,makeint(0L),make__depend__guards_4_2);
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a1;
  allocp[2] = a2;
  allocp[3] = a0;
  allocp[4] = makesym(atom_guard);
  x0 = makefunctor(&allocp[0]);
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a3, x1);
  bblt_sub_no_check(a0,makeint(1L),x3);
  a0 = x3;
  a3 = x2;
  execute(make__depend__guards_4_0);
  goto make__depend__guards_4_ext_interrupt;
 make__depend__guards_4_2:
  if (a0 != makeint(0L)) goto make__depend__guards_4_interrupt;
  unify_value(a3, NILATOM);
  proceed();
 make__depend__guards_4_3:
  if (!isref(a0)) goto make__depend__guards_4_interrupt;
  deref_and_jump(a0,make__depend__guards_4_1);
  *reasonp++ =  a0;
  goto make__depend__guards_4_interrupt;
 make__depend__guards_4_ext_interrupt:
  reasonp = 0l;
 make__depend__guards_4_interrupt:
  goto interrupt_4;
 }

 make__control__dep__guards_6_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 make__control__dep__guards_6_clear_reason:
  reasonp = reasons;
 make__control__dep__guards_6_0:
 make__control__dep__guards_6_1:
  if (!isint(a0)) goto make__control__dep__guards_6_3;
  gblt_greater(a0,makeint(0L),make__control__dep__guards_6_4);
 make__control__dep__guards_6_2:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_none)) goto make__control__dep__guards_6_4;
  unify(a5, a4);
  proceed();
 case VARREF:
  deref_and_jump(a1,make__control__dep__guards_6_2);
  *reasonp++ =  a1;
  goto make__control__dep__guards_6_4;
  };
  goto make__control__dep__guards_6_4;
 make__control__dep__guards_6_3:
  if (!isref(a0)) goto make__control__dep__guards_6_4;
  deref_and_jump(a0,make__control__dep__guards_6_1);
  *reasonp++ =  a0;
  goto make__control__dep__guards_6_4;
 make__control__dep__guards_6_4:
  otherwise(make__control__dep__guards_6_interrupt);
 make__control__dep__guards_6_5:
  if (!isint(a0)) goto make__control__dep__guards_6_7;
  gblt_greater(a0,makeint(0L),make__control__dep__guards_6_6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xmake__control__dep__guards_6);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[10] = a0;
  allocp[11] = makeint(1L);
  allocp[12] = x0;
  allocp[13] = makesym(functor_goal_4);
  allocp[14] = a2;
  allocp[15] = a3;
  allocp[16] = a0;
  allocp[17] = makesym(atom_guard);
  x2 = makefunctor(&allocp[13]);
  allocp[18] = NILATOM;
  allocp[19] = a1;
  x3 = makecons(&allocp[18]);
  a0 = makesym(atom_control);
  a1 = x2;
  a2 = x3;
  a3 = a4;
  a4 = x1;
  qp = (struct goalrec*)&allocp[8];
  allocp += 20;
  execute(entry__deps_5_0);
  goto entry__deps_5_ext_interrupt;
 make__control__dep__guards_6_6:
  if (a0 != makeint(0L)) goto make__control__dep__guards_6_interrupt;
  unify(a5, a4);
  proceed();
 make__control__dep__guards_6_7:
  if (!isref(a0)) goto make__control__dep__guards_6_interrupt;
  deref_and_jump(a0,make__control__dep__guards_6_5);
  *reasonp++ =  a0;
  goto make__control__dep__guards_6_interrupt;
 make__control__dep__guards_6_ext_interrupt:
  reasonp = 0l;
 make__control__dep__guards_6_interrupt:
  goto interrupt_6;
 }

 make__control__dep__bodys_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 make__control__dep__bodys_9_clear_reason:
  reasonp = reasons;
 make__control__dep__bodys_9_0:
 make__control__dep__bodys_9_1:
  if (!isint(a0)) goto make__control__dep__bodys_9_3;
  gblt_greater(a0,makeint(0L),make__control__dep__bodys_9_4);
 make__control__dep__bodys_9_2:
  switch (ptagof(a4)) {
 case ATOMIC:
  if (a4 != makesym(atom_none)) goto make__control__dep__bodys_9_4;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xmake__control__dep__bodys_9);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = x1 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x0;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_dependency_xcall__make__control__dep__modules_9);
  allocp[18] = x2 = makeref(&allocp[18]);
  allocp[19] = x3 = makeref(&allocp[19]);
  allocp[20] = x4 = makeref(&allocp[20]);
  allocp[21] = x5 = makeref(&allocp[21]);
  allocp[22] = x6 = makeref(&allocp[22]);
  allocp[23] = x7 = makeref(&allocp[23]);
  allocp[24] = a6;
  allocp[25] = x8 = makeref(&allocp[25]);
  allocp[26] = x1;
  allocp[27] = (q)(struct goalrec*)&allocp[16];
  allocp[28] = (q)(&predicate_dependency_xentry__deps_5);
  allocp[29] = makesym(atom_control);
  allocp[30] = x5;
  allocp[31] = a5;
  allocp[32] = a7;
  allocp[33] = x8;
  allocp[34] = makesym(functor_goal_4);
  allocp[35] = a2;
  allocp[36] = a3;
  allocp[37] = a0;
  allocp[38] = makesym(atom_body);
  x9 = makefunctor(&allocp[34]);
  qp = (struct goalrec*)&allocp[27];
  allocp += 39;
  unify_value(x5, x9);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[2] = x10 = makeref(&allocp[2]);
  allocp[3] = x3;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_parse__uty_xdecode__goalcall_6);
  allocp[7] = a2;
  allocp[8] = x2;
  allocp[9] = x11 = makeref(&allocp[9]);
  allocp[10] = x10;
  allocp[11] = x6;
  allocp[12] = x7;
  allocp[13] = (q)(struct goalrec*)&allocp[5];
  allocp[14] = (q)(&predicate_functor__table_xarg_3);
  allocp[15] = a0;
  allocp[16] = a1;
  allocp[17] = x11;
  qp = (struct goalrec*)&allocp[13];
  allocp += 18;
  proceed();
 case VARREF:
  deref_and_jump(a4,make__control__dep__bodys_9_2);
  *reasonp++ =  a4;
  goto make__control__dep__bodys_9_4;
  };
  goto make__control__dep__bodys_9_4;
 make__control__dep__bodys_9_3:
  if (!isref(a0)) goto make__control__dep__bodys_9_4;
  deref_and_jump(a0,make__control__dep__bodys_9_1);
  *reasonp++ =  a0;
  goto make__control__dep__bodys_9_4;
 make__control__dep__bodys_9_4:
  otherwise(make__control__dep__bodys_9_interrupt);
 make__control__dep__bodys_9_5:
  if (!isint(a0)) goto make__control__dep__bodys_9_7;
  gblt_greater(a0,makeint(0L),make__control__dep__bodys_9_6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xmake__control__dep__bodys_9);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = x1 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x0;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_dependency_xcall__make__control__dep__modules_9);
  allocp[18] = x2 = makeref(&allocp[18]);
  allocp[19] = x3 = makeref(&allocp[19]);
  allocp[20] = x4 = makeref(&allocp[20]);
  allocp[21] = x5 = makeref(&allocp[21]);
  allocp[22] = x6 = makeref(&allocp[22]);
  allocp[23] = x7 = makeref(&allocp[23]);
  allocp[24] = a6;
  allocp[25] = x8 = makeref(&allocp[25]);
  allocp[26] = x1;
  allocp[27] = a5;
  allocp[28] = a4;
  x9 = makecons(&allocp[27]);
  allocp[29] = (q)(struct goalrec*)&allocp[16];
  allocp[30] = (q)(&predicate_dependency_xentry__deps_5);
  allocp[31] = makesym(atom_control);
  allocp[32] = x5;
  allocp[33] = x9;
  allocp[34] = a7;
  allocp[35] = x8;
  allocp[36] = makesym(functor_goal_4);
  allocp[37] = a2;
  allocp[38] = a3;
  allocp[39] = a0;
  allocp[40] = makesym(atom_body);
  x10 = makefunctor(&allocp[36]);
  qp = (struct goalrec*)&allocp[29];
  allocp += 41;
  unify_value(x5, x10);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[2] = x11 = makeref(&allocp[2]);
  allocp[3] = x3;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_parse__uty_xdecode__goalcall_6);
  allocp[7] = a2;
  allocp[8] = x2;
  allocp[9] = x12 = makeref(&allocp[9]);
  allocp[10] = x11;
  allocp[11] = x6;
  allocp[12] = x7;
  allocp[13] = (q)(struct goalrec*)&allocp[5];
  allocp[14] = (q)(&predicate_functor__table_xarg_3);
  allocp[15] = a0;
  allocp[16] = a1;
  allocp[17] = x12;
  qp = (struct goalrec*)&allocp[13];
  allocp += 18;
  proceed();
 make__control__dep__bodys_9_6:
  if (a0 != makeint(0L)) goto make__control__dep__bodys_9_interrupt;
  unify(a8, a7);
  proceed();
 make__control__dep__bodys_9_7:
  if (!isref(a0)) goto make__control__dep__bodys_9_interrupt;
  deref_and_jump(a0,make__control__dep__bodys_9_5);
  *reasonp++ =  a0;
  goto make__control__dep__bodys_9_interrupt;
 make__control__dep__bodys_9_ext_interrupt:
  reasonp = 0l;
 make__control__dep__bodys_9_interrupt:
  goto interrupt_9;
 }

 call__make__control__dep__modules_9_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 call__make__control__dep__modules_9_clear_reason:
  reasonp = reasons;
 call__make__control__dep__modules_9_0:
 call__make__control__dep__modules_9_1:
  switch (ptagof(a4)) {
 case FUNCTOR:
  if (functor_of(a4) != makesym(functor_atom_1)) goto call__make__control__dep__modules_9_3;
  x0 = arg(a4, 0);
 call__make__control__dep__modules_9_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (isint(x0)) goto call__make__control__dep__modules_9_3;
  switch (symval(x0)) {
 case symval(makesym(atom_loop)):
  unify(a8, a7);
  proceed();
 case symval(makesym(atom_shared)):
  a3 = makesym(atom_none);
  a4 = a6;
  a5 = a6;
  a6 = a7;
  a7 = a8;
  execute(make__control__dep__modules_8_0);
  goto make__control__dep__modules_8_ext_interrupt;
  };
  goto call__make__control__dep__modules_9_3;
 case VARREF:
  deref_and_jump(x0,call__make__control__dep__modules_9_2);
  *reasonp++ =  x0;
  goto call__make__control__dep__modules_9_3;
  };
  goto call__make__control__dep__modules_9_3;
 case VARREF:
  deref_and_jump(a4,call__make__control__dep__modules_9_1);
  *reasonp++ =  a4;
  goto call__make__control__dep__modules_9_3;
  };
  goto call__make__control__dep__modules_9_3;
 call__make__control__dep__modules_9_3:
 call__make__control__dep__modules_9_4:
  switch (ptagof(a5)) {
 case FUNCTOR:
  if (functor_of(a5) != makesym(functor_attrs_2)) goto call__make__control__dep__modules_9_6;
  x0 = arg(a5, 1);
 call__make__control__dep__modules_9_5:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_builtin)) goto call__make__control__dep__modules_9_6;
  unify(a8, a7);
  proceed();
 case VARREF:
  deref_and_jump(x0,call__make__control__dep__modules_9_5);
  *reasonp++ =  x0;
  goto call__make__control__dep__modules_9_6;
  };
  goto call__make__control__dep__modules_9_6;
 case VARREF:
  deref_and_jump(a5,call__make__control__dep__modules_9_4);
  *reasonp++ =  a5;
  goto call__make__control__dep__modules_9_6;
  };
  goto call__make__control__dep__modules_9_6;
 call__make__control__dep__modules_9_6:
  otherwise(call__make__control__dep__modules_9_interrupt);
  a4 = a6;
  a5 = a6;
  a6 = a7;
  a7 = a8;
  execute(make__control__dep__modules_8_0);
  goto make__control__dep__modules_8_ext_interrupt;
 call__make__control__dep__modules_9_ext_interrupt:
  reasonp = 0l;
 call__make__control__dep__modules_9_interrupt:
  goto interrupt_9;
 }

 make__data__dep_5_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 make__data__dep_5_clear_reason:
  reasonp = reasons;
 make__data__dep_5_0:
 make__data__dep_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 make__data__dep_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto make__data__dep_5_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xmake__data__dep__clauses_7);
  allocp[2] = x1 = makeref(&allocp[2]);
  x2 = arg(x0, 1);
  allocp[3] = x2;
  x3 = arg(x0, 0);
  allocp[4] = x3;
  allocp[5] = a1;
  allocp[6] = a2;
  allocp[7] = a3;
  allocp[8] = a4;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[11] = x2;
  allocp[12] = x4 = makeref(&allocp[12]);
  allocp[13] = x1;
  qp = (struct goalrec*)&allocp[9];
  allocp += 14;
  proceed();
 case VARREF:
  deref_and_jump(x0,make__data__dep_5_2);
  *reasonp++ =  x0;
  goto make__data__dep_5_interrupt;
  };
  goto make__data__dep_5_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto make__data__dep_5_interrupt;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,make__data__dep_5_1);
  *reasonp++ =  a0;
  goto make__data__dep_5_interrupt;
  };
  goto make__data__dep_5_interrupt;
 make__data__dep_5_ext_interrupt:
  reasonp = 0l;
 make__data__dep_5_interrupt:
  goto interrupt_5;
 }

 make__data__dep__clauses_7_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 make__data__dep__clauses_7_clear_reason:
  reasonp = reasons;
 make__data__dep__clauses_7_0:
 make__data__dep__clauses_7_1:
  if (!isint(a0)) goto make__data__dep__clauses_7_3;
  gblt_greater(a0,makeint(0L),make__data__dep__clauses_7_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xmake__data__dep__clauses_7);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[11] = a0;
  allocp[12] = makeint(1L);
  allocp[13] = x0;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_dependency_xmake__data__dep__clause_7);
  allocp[16] = x2 = makeref(&allocp[16]);
  allocp[17] = a2;
  allocp[18] = a0;
  allocp[19] = a3;
  allocp[20] = a4;
  allocp[21] = x1;
  allocp[22] = a6;
  allocp[23] = (q)(struct goalrec*)&allocp[14];
  allocp[24] = (q)(&predicate_functor__table_xarg_3);
  allocp[25] = a0;
  allocp[26] = a1;
  allocp[27] = x2;
  qp = (struct goalrec*)&allocp[23];
  allocp += 28;
  proceed();
 make__data__dep__clauses_7_2:
  if (a0 != makeint(0L)) goto make__data__dep__clauses_7_interrupt;
  unify(a5, a4);
  proceed();
 make__data__dep__clauses_7_3:
  if (!isref(a0)) goto make__data__dep__clauses_7_interrupt;
  deref_and_jump(a0,make__data__dep__clauses_7_1);
  *reasonp++ =  a0;
  goto make__data__dep__clauses_7_interrupt;
 make__data__dep__clauses_7_ext_interrupt:
  reasonp = 0l;
 make__data__dep__clauses_7_interrupt:
  goto interrupt_7;
 }

 make__data__dep__clause_7_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 make__data__dep__clause_7_clear_reason:
  reasonp = reasons;
 make__data__dep__clause_7_0:
 make__data__dep__clause_7_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_clause_6)) goto make__data__dep__clause_7_2;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xmake__data__dep__goals_8);
  x0 = arg(a0, 2);
  allocp[2] = x0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = makesym(atom_body);
  allocp[6] = a3;
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = a5;
  allocp[9] = a6;
  a0 = arg(a0, 1);
  x2 = a3;
  a5 = a4;
  a7 = a6;
  a6 = x1;
  a4 = x2;
  a3 = makesym(atom_guard);
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  execute(make__data__dep__goals_8_0);
  goto make__data__dep__goals_8_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,make__data__dep__clause_7_1);
  *reasonp++ =  a0;
  goto make__data__dep__clause_7_2;
  };
  goto make__data__dep__clause_7_2;
 make__data__dep__clause_7_2:
  otherwise(make__data__dep__clause_7_interrupt);
  unify(a5, a4);
  proceed();
 make__data__dep__clause_7_ext_interrupt:
  reasonp = 0l;
 make__data__dep__clause_7_interrupt:
  goto interrupt_7;
 }

 make__data__dep__goals_8_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 make__data__dep__goals_8_clear_reason:
  reasonp = reasons;
 make__data__dep__goals_8_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xmake__data__dep__goals1_9);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[13] = a0;
  allocp[14] = x1 = makeref(&allocp[14]);
  allocp[15] = x0;
  qp = (struct goalrec*)&allocp[11];
  allocp += 16;
  proceed();
 make__data__dep__goals_8_ext_interrupt:
  reasonp = 0l;
 make__data__dep__goals_8_interrupt:
  toppred = &predicate_dependency_xmake__data__dep__goals_8;
  goto interrupt_8;
 }

 make__data__dep__goals1_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 make__data__dep__goals1_9_clear_reason:
  reasonp = reasons;
 make__data__dep__goals1_9_0:
 make__data__dep__goals1_9_1:
  if (!isint(a0)) goto make__data__dep__goals1_9_3;
  gblt_greater(a0,makeint(0L),make__data__dep__goals1_9_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xmake__data__dep__goals1_9);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x0;
  allocp[16] = makesym(functor_goal_4);
  allocp[17] = a2;
  allocp[18] = a3;
  allocp[19] = a0;
  allocp[20] = a4;
  x2 = makefunctor(&allocp[16]);
  allocp[21] = (q)(struct goalrec*)&allocp[11];
  allocp[22] = (q)(&predicate_dependency_xmake__goal__dependency_12);
  allocp[23] = x3 = makeref(&allocp[23]);
  allocp[24] = x4 = makeref(&allocp[24]);
  allocp[25] = a3;
  allocp[26] = x5 = makeref(&allocp[26]);
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = x7 = makeref(&allocp[28]);
  allocp[29] = a5;
  allocp[30] = x2;
  allocp[31] = x8 = makeref(&allocp[31]);
  allocp[32] = a6;
  allocp[33] = x1;
  allocp[34] = a8;
  allocp[35] = (q)(struct goalrec*)&allocp[21];
  allocp[36] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[37] = x8;
  allocp[38] = x5;
  allocp[39] = x6;
  allocp[40] = makesym(functor_attrs_2);
  allocp[41] = x7;
  allocp[42] = x3;
  x9 = makefunctor(&allocp[40]);
  allocp[43] = (q)(struct goalrec*)&allocp[35];
  allocp[44] = (q)(&predicate_parse__uty_xdecode__goalcall_6);
  allocp[45] = a2;
  allocp[46] = x4;
  allocp[47] = x10 = makeref(&allocp[47]);
  allocp[48] = x8;
  allocp[49] = x11 = makeref(&allocp[49]);
  allocp[50] = x9;
  allocp[51] = (q)(struct goalrec*)&allocp[43];
  allocp[52] = (q)(&predicate_functor__table_xarg_3);
  allocp[53] = a0;
  allocp[54] = a1;
  allocp[55] = x10;
  qp = (struct goalrec*)&allocp[51];
  allocp += 56;
  proceed();
 make__data__dep__goals1_9_2:
  if (a0 != makeint(0L)) goto make__data__dep__goals1_9_interrupt;
  unify(a7, a6);
  proceed();
 make__data__dep__goals1_9_3:
  if (!isref(a0)) goto make__data__dep__goals1_9_interrupt;
  deref_and_jump(a0,make__data__dep__goals1_9_1);
  *reasonp++ =  a0;
  goto make__data__dep__goals1_9_interrupt;
 make__data__dep__goals1_9_ext_interrupt:
  reasonp = 0l;
 make__data__dep__goals1_9_interrupt:
  goto interrupt_9;
 }

 make__goal__dependency_12_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 make__goal__dependency_12_clear_reason:
  reasonp = reasons;
 make__goal__dependency_12_0:
 make__goal__dependency_12_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto make__goal__dependency_12_5;
  switch (symval(a0)) {
 case symval(makesym(atom_userdef)):
  unify(a10, a9);
  proceed();
 case symval(makesym(atom_builtin)):
 make__goal__dependency_12_2:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom__3D)) goto make__goal__dependency_12_5;
 make__goal__dependency_12_3:
  switch (ptagof(a4)) {
 case ATOMIC:
 make__goal__dependency_12_4:
  if (a4 != makeint(2L)) goto make__goal__dependency_12_5;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xmake__dependency__unify_8);
  allocp[2] = a6;
  allocp[3] = a7;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = a5;
  allocp[7] = a9;
  allocp[8] = a10;
  allocp[9] = a11;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(2L);
  allocp[13] = a8;
  allocp[14] = x1;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_functor__table_xarg_3);
  allocp[17] = makeint(1L);
  allocp[18] = a8;
  allocp[19] = x0;
  qp = (struct goalrec*)&allocp[15];
  allocp += 20;
  proceed();
 case VARREF:
  deref_and_jump(a4,make__goal__dependency_12_3);
  *reasonp++ =  a4;
  goto make__goal__dependency_12_5;
  };
  goto make__goal__dependency_12_5;
 case VARREF:
  deref_and_jump(a3,make__goal__dependency_12_2);
  *reasonp++ =  a3;
  goto make__goal__dependency_12_5;
  };
  goto make__goal__dependency_12_5;
  };
  goto make__goal__dependency_12_5;
 case VARREF:
  deref_and_jump(a0,make__goal__dependency_12_1);
  *reasonp++ =  a0;
  goto make__goal__dependency_12_5;
  };
  goto make__goal__dependency_12_5;
 make__goal__dependency_12_5:
  otherwise(make__goal__dependency_12_interrupt);
 make__goal__dependency_12_6:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_builtin)) goto make__goal__dependency_12_interrupt;
 make__goal__dependency_12_7:
  switch (ptagof(a7)) {
 case FUNCTOR:
  if (functor_of(a7) != makesym(functor_goal_4)) goto make__goal__dependency_12_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xmake__goal__dependency1_9);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a5;
  x1 = arg(a7, 0);
  allocp[4] = x1;
  allocp[5] = a2;
  allocp[6] = a6;
  allocp[7] = a7;
  allocp[8] = a9;
  allocp[9] = a10;
  allocp[10] = a11;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[13] = a5;
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x0;
  qp = (struct goalrec*)&allocp[11];
  allocp += 16;
  proceed();
 case VARREF:
  deref_and_jump(a7,make__goal__dependency_12_7);
  *reasonp++ =  a7;
  goto make__goal__dependency_12_interrupt;
  };
  goto make__goal__dependency_12_interrupt;
 case VARREF:
  deref_and_jump(a0,make__goal__dependency_12_6);
  *reasonp++ =  a0;
  goto make__goal__dependency_12_interrupt;
  };
  goto make__goal__dependency_12_interrupt;
 make__goal__dependency_12_ext_interrupt:
  reasonp = 0l;
 make__goal__dependency_12_interrupt:
  goto interrupt_12;
 }

 make__goal__dependency1_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 make__goal__dependency1_9_clear_reason:
  reasonp = reasons;
 make__goal__dependency1_9_0:
 make__goal__dependency1_9_1:
  if (!isint(a0)) goto make__goal__dependency1_9_5;
  gblt_greater(a0,makeint(0L),make__goal__dependency1_9_6);
 make__goal__dependency1_9_2:
  if (isref(a1)) goto make__goal__dependency1_9_4;
  gblt_arg(a0,a1,x0,make__goal__dependency1_9_6);
 make__goal__dependency1_9_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_d_1)) goto make__goal__dependency1_9_6;
  bblt_sub_no_check(a0,makeint(1L),x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xmake__goal__dependency1_9);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x2;
  allocp[16] = makesym(functor_v_3);
  allocp[17] = a2;
  allocp[18] = a3;
  allocp[19] = x1;
  x4 = makefunctor(&allocp[16]);
  allocp[20] = NILATOM;
  allocp[21] = x4;
  x5 = makecons(&allocp[20]);
  allocp[22] = (q)(struct goalrec*)&allocp[11];
  allocp[23] = (q)(&predicate_dependency_xget__var__dependency_8);
  x6 = arg(x0, 0);
  allocp[24] = x6;
  allocp[25] = x5;
  allocp[26] = x7 = makeref(&allocp[26]);
  allocp[27] = a5;
  allocp[28] = a4;
  allocp[29] = a6;
  allocp[30] = x3;
  allocp[31] = a8;
  allocp[32] = (q)(struct goalrec*)&allocp[22];
  allocp[33] = (q)(&predicate_type_xget__types_5);
  allocp[34] = a2;
  allocp[35] = a3;
  allocp[36] = x1;
  allocp[37] = a4;
  allocp[38] = x7;
  qp = (struct goalrec*)&allocp[32];
  allocp += 39;
  proceed();
 case VARREF:
  deref_and_jump(x0,make__goal__dependency1_9_3);
  *reasonp++ =  x0;
  goto make__goal__dependency1_9_6;
  };
  goto make__goal__dependency1_9_6;
 make__goal__dependency1_9_4:
  deref_and_jump(a1,make__goal__dependency1_9_2);
  *reasonp++ =  a1;
  goto make__goal__dependency1_9_6;
 make__goal__dependency1_9_5:
  if (!isref(a0)) goto make__goal__dependency1_9_6;
  deref_and_jump(a0,make__goal__dependency1_9_1);
  *reasonp++ =  a0;
  goto make__goal__dependency1_9_6;
 make__goal__dependency1_9_6:
  otherwise(make__goal__dependency1_9_interrupt);
 make__goal__dependency1_9_7:
  if (!isint(a0)) goto make__goal__dependency1_9_9;
  gblt_greater(a0,makeint(0L),make__goal__dependency1_9_8);
  bblt_sub_no_check(a0,makeint(1L),x0);
  a0 = x0;
  execute(make__goal__dependency1_9_0);
  goto make__goal__dependency1_9_ext_interrupt;
 make__goal__dependency1_9_8:
  if (a0 != makeint(0L)) goto make__goal__dependency1_9_interrupt;
  unify(a7, a6);
  proceed();
 make__goal__dependency1_9_9:
  if (!isref(a0)) goto make__goal__dependency1_9_interrupt;
  deref_and_jump(a0,make__goal__dependency1_9_7);
  *reasonp++ =  a0;
  goto make__goal__dependency1_9_interrupt;
 make__goal__dependency1_9_ext_interrupt:
  reasonp = 0l;
 make__goal__dependency1_9_interrupt:
  goto interrupt_9;
 }

 get__var__dependency_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 get__var__dependency_8_clear_reason:
  reasonp = reasons;
 get__var__dependency_8_0:
 get__var__dependency_8_1:
  switch (ptagof(a2)) {
 case CONS:
  x0 = car_of(a2);
 get__var__dependency_8_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__3F)) goto get__var__dependency_8_6;
  a2 = cdr_of(a2);
  execute(get__var__dependency_8_0);
  goto get__var__dependency_8_ext_interrupt;
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_4)) goto get__var__dependency_8_6;
  x1 = arg(x0, 0);
 get__var__dependency_8_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  switch (symval(functor_of(x1))) {
 case functor_s_3:
 get__var__dependency_8_4:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_n)) goto get__var__dependency_8_6;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xget__var__dependency_8);
  allocp[2] = a0;
  allocp[3] = a1;
  x2 = cdr_of(a2);
  allocp[4] = x2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_dependency_xget__var__dependency__struct_8);
  allocp[12] = a0;
  allocp[13] = a1;
  x4 = arg(x1, 2);
  allocp[14] = x4;
  allocp[15] = a3;
  allocp[16] = a4;
  allocp[17] = x5 = makeref(&allocp[17]);
  allocp[18] = x3;
  allocp[19] = a7;
  allocp[20] = (q)(struct goalrec*)&allocp[10];
  allocp[21] = (q)(&predicate_dependency_xentry__data__deps_4);
  allocp[22] = a3;
  allocp[23] = x6 = makeref(&allocp[23]);
  allocp[24] = a5;
  allocp[25] = x5;
  x7 = arg(x0, 2);
  qp = (struct goalrec*)&allocp[20];
  allocp += 26;
  unify(x6, x7);
  a0 = makesym(atom_loopname);
  a1 = a3;
  allocp[0] = x8 = makeref(&allocp[0]);
  a2 = x8;
  a3 = a5;
  allocp += 1;
  execute(get__deps_4_0);
  goto get__deps_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,get__var__dependency_8_4);
  *reasonp++ =  a0;
  goto get__var__dependency_8_6;
  };
  goto get__var__dependency_8_6;
 case functor_v_4:
 get__var__dependency_8_5:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_n)) goto get__var__dependency_8_6;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xget__var__dependency_8);
  allocp[2] = a0;
  allocp[3] = a1;
  x2 = cdr_of(a2);
  allocp[4] = x2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = makesym(functor_v_3);
  allocp[11] = arg(x1, 0);
  allocp[12] = arg(x1, 1);
  allocp[13] = arg(x1, 3);
  x4 = makefunctor(&allocp[10]);
  allocp[14] = (q)(struct goalrec*)&allocp[0];
  allocp[15] = (q)(&predicate_dependency_xget__var__dependency__var_8);
  allocp[16] = a0;
  allocp[17] = x4;
  allocp[18] = a1;
  allocp[19] = a3;
  allocp[20] = a4;
  allocp[21] = x5 = makeref(&allocp[21]);
  allocp[22] = x3;
  allocp[23] = a7;
  allocp[24] = (q)(struct goalrec*)&allocp[14];
  allocp[25] = (q)(&predicate_dependency_xentry__data__deps_4);
  allocp[26] = a3;
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = a5;
  allocp[29] = x5;
  x7 = arg(x0, 2);
  qp = (struct goalrec*)&allocp[24];
  allocp += 30;
  unify(x6, x7);
  a0 = makesym(atom_loopname);
  a1 = a3;
  allocp[0] = x8 = makeref(&allocp[0]);
  a2 = x8;
  a3 = a5;
  allocp += 1;
  execute(get__deps_4_0);
  goto get__deps_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,get__var__dependency_8_5);
  *reasonp++ =  a0;
  goto get__var__dependency_8_6;
  };
  goto get__var__dependency_8_6;
  };
  goto get__var__dependency_8_6;
 case VARREF:
  deref_and_jump(x1,get__var__dependency_8_3);
  *reasonp++ =  x1;
  goto get__var__dependency_8_6;
  };
  goto get__var__dependency_8_6;
 case VARREF:
  deref_and_jump(x0,get__var__dependency_8_2);
  *reasonp++ =  x0;
  goto get__var__dependency_8_6;
  };
  goto get__var__dependency_8_6;
 case VARREF:
  deref_and_jump(a2,get__var__dependency_8_1);
  *reasonp++ =  a2;
  goto get__var__dependency_8_6;
  };
  goto get__var__dependency_8_6;
 get__var__dependency_8_6:
  otherwise(get__var__dependency_8_interrupt);
 get__var__dependency_8_7:
  switch (ptagof(a2)) {
 case CONS:
  x0 = car_of(a2);
 get__var__dependency_8_8:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_4)) goto get__var__dependency_8_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xget__var__dependency_8);
  allocp[2] = a0;
  allocp[3] = a1;
  x1 = cdr_of(a2);
  allocp[4] = x1;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_dependency_xentry__data__deps_4);
  allocp[12] = a3;
  allocp[13] = x3 = makeref(&allocp[13]);
  allocp[14] = a5;
  allocp[15] = x2;
  x4 = arg(x0, 2);
  qp = (struct goalrec*)&allocp[10];
  allocp += 16;
  unify(x3, x4);
  a0 = makesym(atom_loopname);
  a1 = a3;
  allocp[0] = x5 = makeref(&allocp[0]);
  a2 = x5;
  a3 = a5;
  allocp += 1;
  execute(get__deps_4_0);
  goto get__deps_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,get__var__dependency_8_8);
  *reasonp++ =  x0;
  goto get__var__dependency_8_interrupt;
  };
  goto get__var__dependency_8_interrupt;
 case ATOMIC:
  if (a2 != NILATOM) goto get__var__dependency_8_interrupt;
  unify(a6, a5);
  proceed();
 case VARREF:
  deref_and_jump(a2,get__var__dependency_8_7);
  *reasonp++ =  a2;
  goto get__var__dependency_8_interrupt;
  };
  goto get__var__dependency_8_interrupt;
 get__var__dependency_8_ext_interrupt:
  reasonp = 0l;
 get__var__dependency_8_interrupt:
  toppred = &predicate_dependency_xget__var__dependency_8;
  goto interrupt_8;
 }

 get__var__dependency__struct_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 get__var__dependency__struct_8_clear_reason:
  reasonp = reasons;
 get__var__dependency__struct_8_0:
 get__var__dependency__struct_8_1:
  switch (ptagof(a2)) {
 case CONS:
  gblt_list(a2,get__var__dependency__struct_8_2);
  execute(get__var__dependency_8_0);
  goto get__var__dependency_8_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,get__var__dependency__struct_8_1);
  *reasonp++ =  a2;
  goto get__var__dependency__struct_8_interrupt;
  };
  goto get__var__dependency__struct_8_2;
 get__var__dependency__struct_8_2:
  gblt_pfunctor(a2,x0,get__var__dependency__struct_8_interrupt);
  if (x0 != makesym(atom_arg)) goto get__var__dependency__struct_8_interrupt;
  gblt_arity(a2,x1,get__var__dependency__struct_8_interrupt);
  x2 = a0;
  x3 = a1;
  x4 = a2;
  x5 = a3;
  x6 = a4;
  x7 = a5;
  x8 = a6;
  a8 = a7;
  a7 = x8;
  a6 = x7;
  a5 = x6;
  a4 = x5;
  a3 = x4;
  a2 = x3;
  a1 = x2;
  a0 = x1;
  execute(get__var__dependency__struct1_9_0);
  goto get__var__dependency__struct1_9_ext_interrupt;
 get__var__dependency__struct_8_ext_interrupt:
  reasonp = 0l;
 get__var__dependency__struct_8_interrupt:
  goto interrupt_8;
 }

 get__var__dependency__struct1_9_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 get__var__dependency__struct1_9_clear_reason:
  reasonp = reasons;
 get__var__dependency__struct1_9_0:
 get__var__dependency__struct1_9_1:
  if (!isint(a0)) goto get__var__dependency__struct1_9_3;
  gblt_greater(a0,makeint(0L),get__var__dependency__struct1_9_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xget__var__dependency__struct1_9);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x0;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_dependency_xget__var__dependency_8);
  allocp[18] = a1;
  allocp[19] = a2;
  allocp[20] = x2 = makeref(&allocp[20]);
  allocp[21] = a4;
  allocp[22] = a5;
  allocp[23] = a6;
  allocp[24] = x1;
  allocp[25] = a8;
  allocp[26] = (q)(struct goalrec*)&allocp[16];
  allocp[27] = (q)(&predicate_functor__table_xarg_3);
  allocp[28] = a0;
  allocp[29] = a3;
  allocp[30] = x2;
  qp = (struct goalrec*)&allocp[26];
  allocp += 31;
  proceed();
 get__var__dependency__struct1_9_2:
  if (a0 != makeint(0L)) goto get__var__dependency__struct1_9_interrupt;
  unify(a7, a6);
  proceed();
 get__var__dependency__struct1_9_3:
  if (!isref(a0)) goto get__var__dependency__struct1_9_interrupt;
  deref_and_jump(a0,get__var__dependency__struct1_9_1);
  *reasonp++ =  a0;
  goto get__var__dependency__struct1_9_interrupt;
 get__var__dependency__struct1_9_ext_interrupt:
  reasonp = 0l;
 get__var__dependency__struct1_9_interrupt:
  toppred = &predicate_dependency_xget__var__dependency__struct1_9;
  goto interrupt_9;
 }

 get__var__dependency__var_8_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 get__var__dependency__var_8_clear_reason:
  reasonp = reasons;
 get__var__dependency__var_8_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xget__var__dependency__var1_9);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_list_xcheck__include_3);
  allocp[13] = a1;
  allocp[14] = a2;
  allocp[15] = x0;
  qp = (struct goalrec*)&allocp[11];
  allocp += 16;
  proceed();
 get__var__dependency__var_8_ext_interrupt:
  reasonp = 0l;
 get__var__dependency__var_8_interrupt:
  goto interrupt_8;
 }

 get__var__dependency__var1_9_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 get__var__dependency__var1_9_clear_reason:
  reasonp = reasons;
 get__var__dependency__var1_9_0:
 get__var__dependency__var1_9_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto get__var__dependency__var1_9_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  unify(a7, a6);
  proceed();
 case symval(makesym(atom_no)):
 get__var__dependency__var1_9_2:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_v_3)) goto get__var__dependency__var1_9_interrupt;
  allocp[0] = a3;
  allocp[1] = a2;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_dependency_xget__var__dependency_8);
  allocp[4] = a1;
  allocp[5] = x0;
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = a8;
  allocp[12] = (q)(struct goalrec*)&allocp[2];
  allocp[13] = (q)(&predicate_type_xget__types_5);
  x2 = arg(a2, 0);
  allocp[14] = x2;
  x3 = arg(a2, 1);
  allocp[15] = x3;
  x4 = arg(a2, 2);
  allocp[16] = x4;
  allocp[17] = a5;
  allocp[18] = x1;
  qp = (struct goalrec*)&allocp[12];
  allocp += 19;
  proceed();
 case VARREF:
  deref_and_jump(a2,get__var__dependency__var1_9_2);
  *reasonp++ =  a2;
  goto get__var__dependency__var1_9_interrupt;
  };
  goto get__var__dependency__var1_9_interrupt;
  };
  goto get__var__dependency__var1_9_interrupt;
 case VARREF:
  deref_and_jump(a0,get__var__dependency__var1_9_1);
  *reasonp++ =  a0;
  goto get__var__dependency__var1_9_interrupt;
  };
  goto get__var__dependency__var1_9_interrupt;
 get__var__dependency__var1_9_ext_interrupt:
  reasonp = 0l;
 get__var__dependency__var1_9_interrupt:
  goto interrupt_9;
 }

 make__dependency__unify_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 make__dependency__unify_8_clear_reason:
  reasonp = reasons;
 make__dependency__unify_8_0:
 make__dependency__unify_8_1:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_goal_4)) goto make__dependency__unify_8_7;
  x0 = arg(a1, 3);
 make__dependency__unify_8_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_guard)) goto make__dependency__unify_8_7;
 make__dependency__unify_8_3:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_variable_3)) goto make__dependency__unify_8_7;
  x1 = arg(a2, 2);
 make__dependency__unify_8_4:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_i)) goto make__dependency__unify_8_7;
 make__dependency__unify_8_5:
  switch (ptagof(a3)) {
 case FUNCTOR:
  if (functor_of(a3) != makesym(functor_variable_3)) goto make__dependency__unify_8_7;
  x2 = arg(a3, 2);
 make__dependency__unify_8_6:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != makesym(atom_i)) goto make__dependency__unify_8_7;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xmake__goal__dependency1_9);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = a4;
  x4 = arg(a1, 0);
  allocp[4] = x4;
  x5 = arg(a1, 1);
  allocp[5] = x5;
  allocp[6] = a0;
  allocp[7] = x6 = makeref(&allocp[7]);
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[13] = a4;
  allocp[14] = x7 = makeref(&allocp[14]);
  allocp[15] = x3;
  qp = (struct goalrec*)&allocp[11];
  allocp += 16;
  proceed();
 case VARREF:
  deref_and_jump(x2,make__dependency__unify_8_6);
  *reasonp++ =  x2;
  goto make__dependency__unify_8_7;
  };
  goto make__dependency__unify_8_7;
 case VARREF:
  deref_and_jump(a3,make__dependency__unify_8_5);
  *reasonp++ =  a3;
  goto make__dependency__unify_8_7;
  };
  goto make__dependency__unify_8_7;
 case VARREF:
  deref_and_jump(x1,make__dependency__unify_8_4);
  *reasonp++ =  x1;
  goto make__dependency__unify_8_7;
  };
  goto make__dependency__unify_8_7;
 case VARREF:
  deref_and_jump(a2,make__dependency__unify_8_3);
  *reasonp++ =  a2;
  goto make__dependency__unify_8_7;
  };
  goto make__dependency__unify_8_7;
 case VARREF:
  deref_and_jump(x0,make__dependency__unify_8_2);
  *reasonp++ =  x0;
  goto make__dependency__unify_8_7;
  };
  goto make__dependency__unify_8_7;
 case VARREF:
  deref_and_jump(a1,make__dependency__unify_8_1);
  *reasonp++ =  a1;
  goto make__dependency__unify_8_7;
  };
  goto make__dependency__unify_8_7;
 make__dependency__unify_8_7:
  otherwise(make__dependency__unify_8_interrupt);
 make__dependency__unify_8_8:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_goal_4)) goto make__dependency__unify_8_12;
  x0 = arg(a1, 3);
 make__dependency__unify_8_9:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_guard)) goto make__dependency__unify_8_12;
 make__dependency__unify_8_10:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_variable_3)) goto make__dependency__unify_8_12;
 make__dependency__unify_8_11:
  switch (ptagof(a3)) {
 case FUNCTOR:
  if (functor_of(a3) != makesym(functor_variable_3)) goto make__dependency__unify_8_12;
  unify(a6, a5);
  proceed();
 case VARREF:
  deref_and_jump(a3,make__dependency__unify_8_11);
  *reasonp++ =  a3;
  goto make__dependency__unify_8_12;
  };
  goto make__dependency__unify_8_12;
 case VARREF:
  deref_and_jump(a2,make__dependency__unify_8_10);
  *reasonp++ =  a2;
  goto make__dependency__unify_8_12;
  };
  goto make__dependency__unify_8_12;
 case VARREF:
  deref_and_jump(x0,make__dependency__unify_8_9);
  *reasonp++ =  x0;
  goto make__dependency__unify_8_12;
  };
  goto make__dependency__unify_8_12;
 case VARREF:
  deref_and_jump(a1,make__dependency__unify_8_8);
  *reasonp++ =  a1;
  goto make__dependency__unify_8_12;
  };
  goto make__dependency__unify_8_12;
 make__dependency__unify_8_12:
  otherwise(make__dependency__unify_8_interrupt);
 make__dependency__unify_8_13:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_goal_4)) goto make__dependency__unify_8_17;
  x0 = arg(a1, 3);
 make__dependency__unify_8_14:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_guard)) goto make__dependency__unify_8_17;
 make__dependency__unify_8_15:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_variable_3)) goto make__dependency__unify_8_17;
  x1 = arg(a2, 2);
 make__dependency__unify_8_16:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_i)) goto make__dependency__unify_8_17;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xentry__data__deps_4);
  allocp[2] = a1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a5;
  allocp[5] = a6;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_dependency_xget__deps_4);
  allocp[8] = makesym(atom_loopname);
  allocp[9] = a1;
  allocp[10] = x3 = makeref(&allocp[10]);
  allocp[11] = a5;
  allocp[12] = (q)(struct goalrec*)&allocp[6];
  allocp[13] = (q)(&predicate_dependency_xget__unify__depgoals_4);
  allocp[14] = x4 = makeref(&allocp[14]);
  allocp[15] = x5 = makeref(&allocp[15]);
  allocp[16] = a0;
  allocp[17] = x2;
  allocp[18] = (q)(struct goalrec*)&allocp[12];
  allocp[19] = (q)(&predicate_type_xvalue2types_7);
  x6 = arg(a1, 0);
  allocp[20] = x6;
  x7 = arg(a1, 1);
  allocp[21] = x7;
  allocp[22] = a3;
  allocp[23] = NILATOM;
  allocp[24] = NILATOM;
  allocp[25] = makesym(atom__3F);
  allocp[26] = x4;
  allocp[27] = (q)(struct goalrec*)&allocp[18];
  allocp[28] = (q)(&predicate_type_xget__types_5);
  allocp[29] = x6;
  allocp[30] = x7;
  x8 = arg(a2, 0);
  allocp[31] = x8;
  allocp[32] = a0;
  allocp[33] = x5;
  qp = (struct goalrec*)&allocp[27];
  allocp += 34;
  proceed();
 case VARREF:
  deref_and_jump(x1,make__dependency__unify_8_16);
  *reasonp++ =  x1;
  goto make__dependency__unify_8_17;
  };
  goto make__dependency__unify_8_17;
 case VARREF:
  deref_and_jump(a2,make__dependency__unify_8_15);
  *reasonp++ =  a2;
  goto make__dependency__unify_8_17;
  };
  goto make__dependency__unify_8_17;
 case VARREF:
  deref_and_jump(x0,make__dependency__unify_8_14);
  *reasonp++ =  x0;
  goto make__dependency__unify_8_17;
  };
  goto make__dependency__unify_8_17;
 case VARREF:
  deref_and_jump(a1,make__dependency__unify_8_13);
  *reasonp++ =  a1;
  goto make__dependency__unify_8_17;
  };
  goto make__dependency__unify_8_17;
 make__dependency__unify_8_17:
  otherwise(make__dependency__unify_8_interrupt);
 make__dependency__unify_8_18:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_goal_4)) goto make__dependency__unify_8_21;
  x0 = arg(a1, 3);
 make__dependency__unify_8_19:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_guard)) goto make__dependency__unify_8_21;
 make__dependency__unify_8_20:
  switch (ptagof(a3)) {
 case FUNCTOR:
  if (functor_of(a3) != makesym(functor_variable_3)) goto make__dependency__unify_8_21;
  x1 = a3;
  a3 = a2;
  a2 = x1;
  execute(make__dependency__unify_8_0);
  goto make__dependency__unify_8_ext_interrupt;
 case VARREF:
  deref_and_jump(a3,make__dependency__unify_8_20);
  *reasonp++ =  a3;
  goto make__dependency__unify_8_21;
  };
  goto make__dependency__unify_8_21;
 case VARREF:
  deref_and_jump(x0,make__dependency__unify_8_19);
  *reasonp++ =  x0;
  goto make__dependency__unify_8_21;
  };
  goto make__dependency__unify_8_21;
 case VARREF:
  deref_and_jump(a1,make__dependency__unify_8_18);
  *reasonp++ =  a1;
  goto make__dependency__unify_8_21;
  };
  goto make__dependency__unify_8_21;
 make__dependency__unify_8_21:
  otherwise(make__dependency__unify_8_interrupt);
  unify(a6, a5);
  proceed();
 make__dependency__unify_8_ext_interrupt:
  reasonp = 0l;
 make__dependency__unify_8_interrupt:
  goto interrupt_8;
 }

 get__unify__depgoals_4_top: {
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 get__unify__depgoals_4_clear_reason:
  reasonp = reasons;
 get__unify__depgoals_4_0:
  a4 = a3;
  a3 = NILATOM;
  execute(get__unify__depgoals1_5_0);
  goto get__unify__depgoals1_5_ext_interrupt;
 get__unify__depgoals_4_ext_interrupt:
  reasonp = 0l;
 get__unify__depgoals_4_interrupt:
  goto interrupt_4;
 }

 get__unify__depgoals1_5_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 get__unify__depgoals1_5_clear_reason:
  reasonp = reasons;
 get__unify__depgoals1_5_0:
 get__unify__depgoals1_5_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xget__unify__depgoals1_5);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = a4;
  a0 = car_of(a0);
  a4 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(get__unify__depgoals2_5_0);
  goto get__unify__depgoals2_5_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto get__unify__depgoals1_5_interrupt;
  unify(a4, a3);
  proceed();
 case VARREF:
  deref_and_jump(a0,get__unify__depgoals1_5_1);
  *reasonp++ =  a0;
  goto get__unify__depgoals1_5_interrupt;
  };
  goto get__unify__depgoals1_5_interrupt;
 get__unify__depgoals1_5_ext_interrupt:
  reasonp = 0l;
 get__unify__depgoals1_5_interrupt:
  toppred = &predicate_dependency_xget__unify__depgoals1_5;
  goto interrupt_5;
 }

 get__unify__depgoals2_5_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 get__unify__depgoals2_5_clear_reason:
  reasonp = reasons;
 get__unify__depgoals2_5_0:
 get__unify__depgoals2_5_1:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xget__unify__depgoals2_5);
  allocp[2] = a0;
  x0 = cdr_of(a1);
  allocp[3] = x0;
  allocp[4] = a2;
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = a4;
  a1 = car_of(a1);
  a4 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(get__unify__depgoals3_5_0);
  goto get__unify__depgoals3_5_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto get__unify__depgoals2_5_interrupt;
  unify(a4, a3);
  proceed();
 case VARREF:
  deref_and_jump(a1,get__unify__depgoals2_5_1);
  *reasonp++ =  a1;
  goto get__unify__depgoals2_5_interrupt;
  };
  goto get__unify__depgoals2_5_interrupt;
 get__unify__depgoals2_5_ext_interrupt:
  reasonp = 0l;
 get__unify__depgoals2_5_interrupt:
  toppred = &predicate_dependency_xget__unify__depgoals2_5;
  goto interrupt_5;
 }

 get__unify__depgoals3_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 get__unify__depgoals3_5_clear_reason:
  reasonp = reasons;
 get__unify__depgoals3_5_0:
 get__unify__depgoals3_5_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom__3F)) goto get__unify__depgoals3_5_2;
  unify(a4, a3);
  proceed();
 case VARREF:
  deref_and_jump(a1,get__unify__depgoals3_5_1);
  *reasonp++ =  a1;
  goto get__unify__depgoals3_5_2;
  };
  goto get__unify__depgoals3_5_2;
 get__unify__depgoals3_5_2:
 get__unify__depgoals3_5_3:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_t_4)) goto get__unify__depgoals3_5_34;
 get__unify__depgoals3_5_4:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_t_4)) goto get__unify__depgoals3_5_34;
  x0 = arg(a1, 0);
 get__unify__depgoals3_5_5:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_v_4)) goto get__unify__depgoals3_5_6;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xget__unify__depgoals2_5);
  allocp[2] = a0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_type_xget__types_5);
  x3 = arg(x0, 0);
  allocp[9] = x3;
  x4 = arg(x0, 1);
  allocp[10] = x4;
  x5 = arg(x0, 3);
  allocp[11] = x5;
  allocp[12] = a2;
  allocp[13] = x1;
  allocp[14] = (q)(struct goalrec*)&allocp[7];
  allocp[15] = (q)(&predicate_list_xor__unique_3);
  allocp[16] = a3;
  x6 = arg(a1, 2);
  allocp[17] = x6;
  allocp[18] = x2;
  qp = (struct goalrec*)&allocp[14];
  allocp += 19;
  proceed();
 case VARREF:
  deref_and_jump(x0,get__unify__depgoals3_5_5);
  *reasonp++ =  x0;
  goto get__unify__depgoals3_5_15;
  };
  goto get__unify__depgoals3_5_6;
 get__unify__depgoals3_5_6:
  gblt_pfunctor(x0,x1,get__unify__depgoals3_5_15);
  if (isint(x1)) goto get__unify__depgoals3_5_15;
  switch (symval(x1)) {
 case symval(makesym(atom_a)):
  gblt_arity(x0,x2,get__unify__depgoals3_5_15);
  x3 = arg(a0, 0);
 get__unify__depgoals3_5_7:
  if (isref(x3)) goto get__unify__depgoals3_5_8;
  gblt_pfunctor(x3,x4,get__unify__depgoals3_5_15);
  if (x4 != makesym(atom_a)) goto get__unify__depgoals3_5_15;
  gblt_arity(x3,x5,get__unify__depgoals3_5_15);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_list_xor__unique_3);
  allocp[2] = a3;
  x6 = arg(a1, 2);
  allocp[3] = x6;
  allocp[4] = a4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 get__unify__depgoals3_5_8:
  deref_and_jump(x3,get__unify__depgoals3_5_7);
  *reasonp++ =  x3;
  goto get__unify__depgoals3_5_15;
 case symval(makesym(atom_i)):
  gblt_arity(x0,x2,get__unify__depgoals3_5_15);
  x3 = arg(a0, 0);
 get__unify__depgoals3_5_9:
  if (isref(x3)) goto get__unify__depgoals3_5_10;
  gblt_pfunctor(x3,x4,get__unify__depgoals3_5_15);
  if (x4 != makesym(atom_i)) goto get__unify__depgoals3_5_15;
  gblt_arity(x3,x5,get__unify__depgoals3_5_15);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_list_xor__unique_3);
  allocp[2] = a3;
  x6 = arg(a1, 2);
  allocp[3] = x6;
  allocp[4] = a4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 get__unify__depgoals3_5_10:
  deref_and_jump(x3,get__unify__depgoals3_5_9);
  *reasonp++ =  x3;
  goto get__unify__depgoals3_5_15;
 case symval(makesym(atom_f)):
  gblt_arity(x0,x2,get__unify__depgoals3_5_15);
  x3 = arg(a0, 0);
 get__unify__depgoals3_5_11:
  if (isref(x3)) goto get__unify__depgoals3_5_12;
  gblt_pfunctor(x3,x4,get__unify__depgoals3_5_15);
  if (x4 != makesym(atom_f)) goto get__unify__depgoals3_5_15;
  gblt_arity(x3,x5,get__unify__depgoals3_5_15);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_list_xor__unique_3);
  allocp[2] = a3;
  x6 = arg(a1, 2);
  allocp[3] = x6;
  allocp[4] = a4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 get__unify__depgoals3_5_12:
  deref_and_jump(x3,get__unify__depgoals3_5_11);
  *reasonp++ =  x3;
  goto get__unify__depgoals3_5_15;
 case symval(makesym(atom_c)):
  gblt_arity(x0,x2,get__unify__depgoals3_5_15);
  x3 = arg(a0, 0);
 get__unify__depgoals3_5_13:
  if (isref(x3)) goto get__unify__depgoals3_5_14;
  gblt_pfunctor(x3,x4,get__unify__depgoals3_5_15);
  if (x4 != makesym(atom_c)) goto get__unify__depgoals3_5_15;
  gblt_arity(x3,x5,get__unify__depgoals3_5_15);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_list_xor__unique_3);
  allocp[2] = a3;
  x6 = arg(a1, 2);
  allocp[3] = x6;
  allocp[4] = a4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 get__unify__depgoals3_5_14:
  deref_and_jump(x3,get__unify__depgoals3_5_13);
  *reasonp++ =  x3;
  goto get__unify__depgoals3_5_15;
  };
  goto get__unify__depgoals3_5_15;
 get__unify__depgoals3_5_15:
  x1 = arg(a0, 0);
 get__unify__depgoals3_5_16:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_s_3)) goto get__unify__depgoals3_5_34;
 get__unify__depgoals3_5_17:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_s_3)) goto get__unify__depgoals3_5_34;
  x2 = arg(x0, 0);
 get__unify__depgoals3_5_18:
  if (isref(x2)) goto get__unify__depgoals3_5_33;
 get__unify__depgoals3_5_19:
  if (isref(x2)) goto get__unify__depgoals3_5_32;
  x3 = arg(x1, 0);
  if_not_equal(x2, x3, get__unify__depgoals3_5_24);
  x4 = arg(x0, 1);
 get__unify__depgoals3_5_20:
  if (isref(x4)) goto get__unify__depgoals3_5_23;
 get__unify__depgoals3_5_21:
  if (isref(x4)) goto get__unify__depgoals3_5_22;
  x5 = arg(x1, 1);
  if_not_equal(x4, x5, get__unify__depgoals3_5_24);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xget__unify__depgoals__struct_6);
  allocp[2] = x5;
  x6 = arg(x1, 2);
  allocp[3] = x6;
  x7 = arg(x0, 2);
  allocp[4] = x7;
  allocp[5] = a2;
  allocp[6] = x8 = makeref(&allocp[6]);
  allocp[7] = a4;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_list_xor__unique_3);
  allocp[10] = a3;
  x9 = arg(a1, 2);
  allocp[11] = x9;
  allocp[12] = x8;
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  proceed();
 get__unify__depgoals3_5_22:
  deref_and_jump(x4,get__unify__depgoals3_5_21);
  *reasonp++ =  x4;
  goto get__unify__depgoals3_5_24;
 get__unify__depgoals3_5_23:
  deref_and_jump(x4,get__unify__depgoals3_5_20);
  *reasonp++ =  x4;
  goto get__unify__depgoals3_5_24;
 get__unify__depgoals3_5_24:
 get__unify__depgoals3_5_25:
  if (isref(x2)) goto get__unify__depgoals3_5_31;
  if_not_equal(x2, x3, get__unify__depgoals3_5_34);
  x4 = arg(x0, 1);
 get__unify__depgoals3_5_26:
  switch (ptagof(x4)) {
 case ATOMIC:
  if (x4 != makesym(atom_n)) goto get__unify__depgoals3_5_34;
  x5 = arg(x0, 2);
 get__unify__depgoals3_5_27:
  if (isref(x5)) goto get__unify__depgoals3_5_30;
 get__unify__depgoals3_5_28:
  if (isref(x5)) goto get__unify__depgoals3_5_29;
  x6 = arg(x1, 2);
  if_not_equal(x5, x6, get__unify__depgoals3_5_34);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xget__unify__depgoals__dstruct_6);
  x7 = arg(x1, 1);
  allocp[2] = x7;
  allocp[3] = x8 = makeref(&allocp[3]);
  allocp[4] = x6;
  allocp[5] = a2;
  allocp[6] = x9 = makeref(&allocp[6]);
  allocp[7] = a4;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_list_xor__unique_3);
  allocp[10] = a3;
  x10 = arg(a1, 2);
  allocp[11] = x10;
  allocp[12] = x9;
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  proceed();
 get__unify__depgoals3_5_29:
  deref_and_jump(x5,get__unify__depgoals3_5_28);
  *reasonp++ =  x5;
  goto get__unify__depgoals3_5_34;
 get__unify__depgoals3_5_30:
  deref_and_jump(x5,get__unify__depgoals3_5_27);
  *reasonp++ =  x5;
  goto get__unify__depgoals3_5_34;
 case VARREF:
  deref_and_jump(x4,get__unify__depgoals3_5_26);
  *reasonp++ =  x4;
  goto get__unify__depgoals3_5_34;
  };
  goto get__unify__depgoals3_5_34;
 get__unify__depgoals3_5_31:
  deref_and_jump(x2,get__unify__depgoals3_5_25);
  *reasonp++ =  x2;
  goto get__unify__depgoals3_5_34;
 get__unify__depgoals3_5_32:
  deref_and_jump(x2,get__unify__depgoals3_5_19);
  *reasonp++ =  x2;
  goto get__unify__depgoals3_5_34;
 get__unify__depgoals3_5_33:
  deref_and_jump(x2,get__unify__depgoals3_5_18);
  *reasonp++ =  x2;
  goto get__unify__depgoals3_5_34;
 case VARREF:
  deref_and_jump(x0,get__unify__depgoals3_5_17);
  *reasonp++ =  x0;
  goto get__unify__depgoals3_5_34;
  };
  goto get__unify__depgoals3_5_34;
 case VARREF:
  deref_and_jump(x1,get__unify__depgoals3_5_16);
  *reasonp++ =  x1;
  goto get__unify__depgoals3_5_34;
  };
  goto get__unify__depgoals3_5_34;
 case VARREF:
  deref_and_jump(a1,get__unify__depgoals3_5_4);
  *reasonp++ =  a1;
  goto get__unify__depgoals3_5_34;
  };
  goto get__unify__depgoals3_5_34;
 case VARREF:
  deref_and_jump(a0,get__unify__depgoals3_5_3);
  *reasonp++ =  a0;
  goto get__unify__depgoals3_5_34;
  };
  goto get__unify__depgoals3_5_34;
 get__unify__depgoals3_5_34:
  otherwise(get__unify__depgoals3_5_interrupt);
 get__unify__depgoals3_5_35:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_t_4)) goto get__unify__depgoals3_5_interrupt;
 get__unify__depgoals3_5_36:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_t_4)) goto get__unify__depgoals3_5_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_list_xor__unique_3);
  allocp[2] = a3;
  x0 = arg(a1, 2);
  allocp[3] = x0;
  allocp[4] = a4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case VARREF:
  deref_and_jump(a1,get__unify__depgoals3_5_36);
  *reasonp++ =  a1;
  goto get__unify__depgoals3_5_interrupt;
  };
  goto get__unify__depgoals3_5_interrupt;
 case VARREF:
  deref_and_jump(a0,get__unify__depgoals3_5_35);
  *reasonp++ =  a0;
  goto get__unify__depgoals3_5_interrupt;
  };
  goto get__unify__depgoals3_5_interrupt;
 get__unify__depgoals3_5_ext_interrupt:
  reasonp = 0l;
 get__unify__depgoals3_5_interrupt:
  toppred = &predicate_dependency_xget__unify__depgoals3_5;
  goto interrupt_5;
 }

 get__unify__depgoals__struct_6_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 get__unify__depgoals__struct_6_clear_reason:
  reasonp = reasons;
 get__unify__depgoals__struct_6_0:
 get__unify__depgoals__struct_6_1:
  if (!isint(a0)) goto get__unify__depgoals__struct_6_3;
  gblt_greater(a0,makeint(0L),get__unify__depgoals__struct_6_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xget__unify__depgoals__struct_6);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[10] = a0;
  allocp[11] = makeint(1L);
  allocp[12] = x0;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_dependency_xget__unify__depgoals1_5);
  allocp[15] = x2 = makeref(&allocp[15]);
  allocp[16] = x3 = makeref(&allocp[16]);
  allocp[17] = a3;
  allocp[18] = a4;
  allocp[19] = x1;
  allocp[20] = (q)(struct goalrec*)&allocp[13];
  allocp[21] = (q)(&predicate_functor__table_xarg_3);
  allocp[22] = a0;
  allocp[23] = a2;
  allocp[24] = x3;
  allocp[25] = (q)(struct goalrec*)&allocp[20];
  allocp[26] = (q)(&predicate_functor__table_xarg_3);
  allocp[27] = a0;
  allocp[28] = a1;
  allocp[29] = x2;
  qp = (struct goalrec*)&allocp[25];
  allocp += 30;
  proceed();
 get__unify__depgoals__struct_6_2:
  if (a0 != makeint(0L)) goto get__unify__depgoals__struct_6_interrupt;
  unify(a5, a4);
  proceed();
 get__unify__depgoals__struct_6_3:
  if (!isref(a0)) goto get__unify__depgoals__struct_6_interrupt;
  deref_and_jump(a0,get__unify__depgoals__struct_6_1);
  *reasonp++ =  a0;
  goto get__unify__depgoals__struct_6_interrupt;
 get__unify__depgoals__struct_6_ext_interrupt:
  reasonp = 0l;
 get__unify__depgoals__struct_6_interrupt:
  goto interrupt_6;
 }

 get__unify__depgoals__dstruct_6_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 get__unify__depgoals__dstruct_6_clear_reason:
  reasonp = reasons;
 get__unify__depgoals__dstruct_6_0:
 get__unify__depgoals__dstruct_6_1:
  if (!isint(a0)) goto get__unify__depgoals__dstruct_6_3;
  gblt_greater(a0,makeint(0L),get__unify__depgoals__dstruct_6_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xget__unify__depgoals__dstruct_6);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[10] = a0;
  allocp[11] = makeint(1L);
  allocp[12] = x0;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_dependency_xget__unify__depgoals1_5);
  allocp[15] = x2 = makeref(&allocp[15]);
  allocp[16] = x3 = makeref(&allocp[16]);
  allocp[17] = a3;
  allocp[18] = a4;
  allocp[19] = x1;
  allocp[20] = (q)(struct goalrec*)&allocp[13];
  allocp[21] = (q)(&predicate_functor__table_xarg_3);
  allocp[22] = a0;
  allocp[23] = a2;
  allocp[24] = x3;
  allocp[25] = (q)(struct goalrec*)&allocp[20];
  allocp[26] = (q)(&predicate_functor__table_xarg_3);
  allocp[27] = a0;
  allocp[28] = a1;
  allocp[29] = x2;
  qp = (struct goalrec*)&allocp[25];
  allocp += 30;
  proceed();
 get__unify__depgoals__dstruct_6_2:
  if (a0 != makeint(0L)) goto get__unify__depgoals__dstruct_6_interrupt;
  unify(a5, a4);
  proceed();
 get__unify__depgoals__dstruct_6_3:
  if (!isref(a0)) goto get__unify__depgoals__dstruct_6_interrupt;
  deref_and_jump(a0,get__unify__depgoals__dstruct_6_1);
  *reasonp++ =  a0;
  goto get__unify__depgoals__dstruct_6_interrupt;
 get__unify__depgoals__dstruct_6_ext_interrupt:
  reasonp = 0l;
 get__unify__depgoals__dstruct_6_interrupt:
  goto interrupt_6;
 }

 indirect_4_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 indirect_4_clear_reason:
  reasonp = reasons;
 indirect_4_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xindirect__clause_8);
  allocp[2] = makesym(atom_main);
  allocp[3] = makeint(1L);
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = a1;
  allocp[6] = a0;
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = a2;
  allocp[9] = a3;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_parse__uty_xget__clause_4);
  allocp[12] = makesym(atom_main);
  allocp[13] = makeint(1L);
  allocp[14] = x0;
  allocp[15] = a0;
  qp = (struct goalrec*)&allocp[10];
  allocp += 16;
  proceed();
 indirect_4_ext_interrupt:
  reasonp = 0l;
 indirect_4_interrupt:
  goto interrupt_4;
 }

 indirect__clause_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 indirect__clause_8_clear_reason:
  reasonp = reasons;
 indirect__clause_8_0:
 indirect__clause_8_1:
  switch (ptagof(a1)) {
 case ATOMIC:
 indirect__clause_8_2:
  if (a1 != makeint(0L)) goto indirect__clause_8_3;
  unify2(a5, a4, a7, a6);
  proceed();
 case VARREF:
  deref_and_jump(a1,indirect__clause_8_1);
  *reasonp++ =  a1;
  goto indirect__clause_8_3;
  };
  goto indirect__clause_8_3;
 indirect__clause_8_3:
  otherwise(indirect__clause_8_interrupt);
 indirect__clause_8_4:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_clause_6)) goto indirect__clause_8_5;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xindirect__clause_8);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_parse__uty_xget__next__clause_6);
  allocp[12] = a0;
  allocp[13] = a1;
  allocp[14] = x0;
  allocp[15] = x1;
  allocp[16] = x3;
  allocp[17] = x2;
  allocp[18] = (q)(struct goalrec*)&allocp[10];
  allocp[19] = (q)(&predicate_dependency_xindirect__goals_9);
  x5 = arg(a2, 2);
  allocp[20] = x5;
  allocp[21] = makesym(atom_body);
  allocp[22] = a0;
  allocp[23] = a1;
  allocp[24] = a3;
  allocp[25] = x6 = makeref(&allocp[25]);
  allocp[26] = x3;
  allocp[27] = x7 = makeref(&allocp[27]);
  allocp[28] = x4;
  x8 = arg(a2, 1);
  a2 = a0;
  x9 = a1;
  x10 = a3;
  a5 = a4;
  a7 = a6;
  a8 = x7;
  a6 = x6;
  a4 = x10;
  a3 = x9;
  a1 = makesym(atom_guard);
  a0 = x8;
  qp = (struct goalrec*)&allocp[18];
  allocp += 29;
  execute(indirect__goals_9_0);
  goto indirect__goals_9_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,indirect__clause_8_4);
  *reasonp++ =  a2;
  goto indirect__clause_8_5;
  };
  goto indirect__clause_8_5;
 indirect__clause_8_5:
  otherwise(indirect__clause_8_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xindirect__clause_8);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_parse__uty_xget__next__clause_6);
  allocp[12] = a0;
  allocp[13] = a1;
  allocp[14] = x0;
  allocp[15] = x1;
  allocp[16] = a4;
  allocp[17] = x2;
  qp = (struct goalrec*)&allocp[10];
  allocp += 18;
  proceed();
 indirect__clause_8_ext_interrupt:
  reasonp = 0l;
 indirect__clause_8_interrupt:
  goto interrupt_8;
 }

 indirect__goals_9_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 indirect__goals_9_clear_reason:
  reasonp = reasons;
 indirect__goals_9_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xindirect__goals1_9);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[13] = a0;
  allocp[14] = x1 = makeref(&allocp[14]);
  allocp[15] = x0;
  qp = (struct goalrec*)&allocp[11];
  allocp += 16;
  proceed();
 indirect__goals_9_ext_interrupt:
  reasonp = 0l;
 indirect__goals_9_interrupt:
  toppred = &predicate_dependency_xindirect__goals_9;
  goto interrupt_9;
 }

 indirect__goals1_9_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 indirect__goals1_9_clear_reason:
  reasonp = reasons;
 indirect__goals1_9_0:
 indirect__goals1_9_1:
  if (!isint(a0)) goto indirect__goals1_9_3;
  gblt_greater(a0,makeint(0L),indirect__goals1_9_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xindirect__goals1_9);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x0;
  allocp[16] = makesym(functor_goal_4);
  allocp[17] = a2;
  allocp[18] = a3;
  allocp[19] = a0;
  allocp[20] = a1;
  x3 = makefunctor(&allocp[16]);
  allocp[21] = (q)(struct goalrec*)&allocp[11];
  allocp[22] = (q)(&predicate_dependency_xindirect__goal_7);
  allocp[23] = x3;
  allocp[24] = x4 = makeref(&allocp[24]);
  allocp[25] = x5 = makeref(&allocp[25]);
  allocp[26] = a5;
  allocp[27] = x1;
  allocp[28] = a7;
  allocp[29] = x2;
  allocp[30] = (q)(struct goalrec*)&allocp[21];
  allocp[31] = (q)(&predicate_parse__uty_xget__goal_6);
  allocp[32] = a2;
  allocp[33] = a3;
  allocp[34] = a0;
  allocp[35] = a1;
  allocp[36] = x4;
  allocp[37] = a5;
  qp = (struct goalrec*)&allocp[30];
  allocp += 38;
  proceed();
 indirect__goals1_9_2:
  if (a0 != makeint(0L)) goto indirect__goals1_9_interrupt;
  unify2(a6, a5, a8, a7);
  proceed();
 indirect__goals1_9_3:
  if (!isref(a0)) goto indirect__goals1_9_interrupt;
  deref_and_jump(a0,indirect__goals1_9_1);
  *reasonp++ =  a0;
  goto indirect__goals1_9_interrupt;
 indirect__goals1_9_ext_interrupt:
  reasonp = 0l;
 indirect__goals1_9_interrupt:
  goto interrupt_9;
 }

 indirect__goal_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 indirect__goal_7_clear_reason:
  reasonp = reasons;
 indirect__goal_7_0:
 indirect__goal_7_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_done)) goto indirect__goal_7_2;
  unify2(a6, a5, a4, a3);
  a1 = a0;
  a3 = a5;
  a0 = makesym(atom_execute);
  execute(get__deps_4_0);
  goto get__deps_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,indirect__goal_7_1);
  *reasonp++ =  a1;
  goto indirect__goal_7_2;
  };
  goto indirect__goal_7_2;
 indirect__goal_7_2:
  otherwise(indirect__goal_7_interrupt);
 indirect__goal_7_3:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_goal_4)) goto indirect__goal_7_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_list_xor__unique_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_dependency_xentry__deps_5);
  allocp[7] = makesym(atom_data);
  allocp[8] = a0;
  allocp[9] = x1;
  allocp[10] = x2 = makeref(&allocp[10]);
  allocp[11] = a6;
  allocp[12] = (q)(struct goalrec*)&allocp[5];
  allocp[13] = (q)(&predicate_dependency_xentry__deps_5);
  allocp[14] = makesym(atom_control);
  allocp[15] = a0;
  allocp[16] = x0;
  allocp[17] = x3 = makeref(&allocp[17]);
  allocp[18] = x2;
  allocp[19] = (q)(struct goalrec*)&allocp[12];
  allocp[20] = (q)(&predicate_dependency_xexpand__indirect_6);
  allocp[21] = x4 = makeref(&allocp[21]);
  allocp[22] = x1;
  allocp[23] = x5 = makeref(&allocp[23]);
  allocp[24] = a4;
  allocp[25] = x6 = makeref(&allocp[25]);
  allocp[26] = x3;
  allocp[27] = (q)(struct goalrec*)&allocp[19];
  allocp[28] = (q)(&predicate_dependency_xexpand__indirect_6);
  allocp[29] = x7 = makeref(&allocp[29]);
  allocp[30] = x0;
  allocp[31] = x8 = makeref(&allocp[31]);
  allocp[32] = x5;
  allocp[33] = a5;
  allocp[34] = x6;
  allocp[35] = (q)(struct goalrec*)&allocp[27];
  allocp[36] = (q)(&predicate_dependency_xget__deps_4);
  allocp[37] = makesym(atom_data);
  allocp[38] = a0;
  allocp[39] = x4;
  allocp[40] = a5;
  allocp[41] = (q)(struct goalrec*)&allocp[35];
  allocp[42] = (q)(&predicate_dependency_xget__deps_4);
  allocp[43] = makesym(atom_control);
  allocp[44] = a0;
  allocp[45] = x7;
  allocp[46] = a5;
  allocp[47] = (q)(struct goalrec*)&allocp[41];
  allocp[48] = (q)(&predicate_parse__uty_xupdate__goal_7);
  x9 = arg(a0, 0);
  allocp[49] = x9;
  x10 = arg(a0, 1);
  allocp[50] = x10;
  x11 = arg(a0, 2);
  allocp[51] = x11;
  x12 = arg(a0, 3);
  allocp[52] = x12;
  allocp[53] = makesym(atom_done);
  allocp[54] = a3;
  allocp[55] = x8;
  qp = (struct goalrec*)&allocp[47];
  allocp += 56;
  proceed();
 case VARREF:
  deref_and_jump(a0,indirect__goal_7_3);
  *reasonp++ =  a0;
  goto indirect__goal_7_interrupt;
  };
  goto indirect__goal_7_interrupt;
 indirect__goal_7_ext_interrupt:
  reasonp = 0l;
 indirect__goal_7_interrupt:
  goto interrupt_7;
 }

 expand__indirect_6_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 expand__indirect_6_clear_reason:
  reasonp = reasons;
 expand__indirect_6_0:
  x0 = a0;
  x1 = a0;
  x2 = a1;
  x3 = a2;
  x4 = a3;
  x5 = a4;
  a6 = a5;
  a5 = x5;
  a4 = x4;
  a3 = x3;
  a2 = x2;
  a1 = x1;
  a0 = x0;
  execute(expand__indirect1_7_0);
  goto expand__indirect1_7_ext_interrupt;
 expand__indirect_6_ext_interrupt:
  reasonp = 0l;
 expand__indirect_6_interrupt:
  goto interrupt_6;
 }

 expand__indirect1_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 expand__indirect1_7_clear_reason:
  reasonp = reasons;
 expand__indirect1_7_0:
 expand__indirect1_7_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 expand__indirect1_7_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_goal_4)) goto expand__indirect1_7_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xexpand__indirect1_7);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x4 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_list_xor__unique_3);
  allocp[11] = a1;
  allocp[12] = x5 = makeref(&allocp[12]);
  allocp[13] = x2;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_dependency_xindirect__goal_7);
  allocp[16] = x0;
  allocp[17] = x6 = makeref(&allocp[17]);
  allocp[18] = x5;
  allocp[19] = a3;
  allocp[20] = x3;
  allocp[21] = a5;
  allocp[22] = x4;
  allocp[23] = (q)(struct goalrec*)&allocp[14];
  allocp[24] = (q)(&predicate_parse__uty_xget__goal_6);
  x7 = arg(x0, 0);
  allocp[25] = x7;
  x8 = arg(x0, 1);
  allocp[26] = x8;
  x9 = arg(x0, 2);
  allocp[27] = x9;
  x10 = arg(x0, 3);
  allocp[28] = x10;
  allocp[29] = x6;
  allocp[30] = a3;
  qp = (struct goalrec*)&allocp[23];
  allocp += 31;
  proceed();
 case VARREF:
  deref_and_jump(x0,expand__indirect1_7_2);
  *reasonp++ =  x0;
  goto expand__indirect1_7_interrupt;
  };
  goto expand__indirect1_7_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto expand__indirect1_7_interrupt;
  unify3(a2, a1, a4, a3, a6, a5);
  proceed();
 case VARREF:
  deref_and_jump(a0,expand__indirect1_7_1);
  *reasonp++ =  a0;
  goto expand__indirect1_7_interrupt;
  };
  goto expand__indirect1_7_interrupt;
 expand__indirect1_7_ext_interrupt:
  reasonp = 0l;
 expand__indirect1_7_interrupt:
  toppred = &predicate_dependency_xexpand__indirect1_7;
  goto interrupt_7;
 }

 expand__shared__arg_5_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 expand__shared__arg_5_clear_reason:
  reasonp = reasons;
 expand__shared__arg_5_0:
 expand__shared__arg_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 expand__shared__arg_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto expand__shared__arg_5_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xexpand__shared__arg_5);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_dependency_xexpand__shared__clauses_7);
  x3 = arg(x0, 0);
  allocp[9] = x3;
  allocp[10] = x4 = makeref(&allocp[10]);
  x5 = arg(x0, 1);
  allocp[11] = x5;
  allocp[12] = a1;
  allocp[13] = a2;
  allocp[14] = a3;
  allocp[15] = x2;
  allocp[16] = (q)(struct goalrec*)&allocp[7];
  allocp[17] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[18] = x5;
  allocp[19] = x6 = makeref(&allocp[19]);
  allocp[20] = x4;
  qp = (struct goalrec*)&allocp[16];
  allocp += 21;
  proceed();
 case VARREF:
  deref_and_jump(x0,expand__shared__arg_5_2);
  *reasonp++ =  x0;
  goto expand__shared__arg_5_interrupt;
  };
  goto expand__shared__arg_5_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto expand__shared__arg_5_interrupt;
  unify(a4, a3);
  proceed();
 case VARREF:
  deref_and_jump(a0,expand__shared__arg_5_1);
  *reasonp++ =  a0;
  goto expand__shared__arg_5_interrupt;
  };
  goto expand__shared__arg_5_interrupt;
 expand__shared__arg_5_ext_interrupt:
  reasonp = 0l;
 expand__shared__arg_5_interrupt:
  goto interrupt_5;
 }

 expand__shared__clauses_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 expand__shared__clauses_7_clear_reason:
  reasonp = reasons;
 expand__shared__clauses_7_0:
 expand__shared__clauses_7_1:
  if (!isint(a1)) goto expand__shared__clauses_7_7;
  gblt_greater(a1,makeint(0L),expand__shared__clauses_7_8);
 expand__shared__clauses_7_2:
  if (isref(a2)) goto expand__shared__clauses_7_6;
  gblt_arg(a1,a2,x0,expand__shared__clauses_7_8);
 expand__shared__clauses_7_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_clause_6)) goto expand__shared__clauses_7_8;
  x1 = arg(x0, 2);
 expand__shared__clauses_7_4:
  if (isref(x1)) goto expand__shared__clauses_7_5;
  gblt_pfunctor(x1,x2,expand__shared__clauses_7_8);
  gblt_arity(x1,x3,expand__shared__clauses_7_8);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xexpand__shared__clauses_7);
  allocp[2] = a0;
  allocp[3] = x4 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x5 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[11] = a1;
  allocp[12] = makeint(1L);
  allocp[13] = x4;
  a2 = x3;
  x6 = a3;
  x7 = a4;
  a6 = a5;
  a7 = x5;
  a5 = x7;
  a4 = x6;
  a3 = x1;
  qp = (struct goalrec*)&allocp[9];
  allocp += 14;
  execute(expand__shared__bodys_8_0);
  goto expand__shared__bodys_8_ext_interrupt;
 expand__shared__clauses_7_5:
  deref_and_jump(x1,expand__shared__clauses_7_4);
  *reasonp++ =  x1;
  goto expand__shared__clauses_7_8;
 case VARREF:
  deref_and_jump(x0,expand__shared__clauses_7_3);
  *reasonp++ =  x0;
  goto expand__shared__clauses_7_8;
  };
  goto expand__shared__clauses_7_8;
 expand__shared__clauses_7_6:
  deref_and_jump(a2,expand__shared__clauses_7_2);
  *reasonp++ =  a2;
  goto expand__shared__clauses_7_8;
 expand__shared__clauses_7_7:
  if (!isref(a1)) goto expand__shared__clauses_7_8;
  deref_and_jump(a1,expand__shared__clauses_7_1);
  *reasonp++ =  a1;
  goto expand__shared__clauses_7_8;
 expand__shared__clauses_7_8:
  otherwise(expand__shared__clauses_7_interrupt);
 expand__shared__clauses_7_9:
  if (!isint(a1)) goto expand__shared__clauses_7_11;
  gblt_greater(a1,makeint(0L),expand__shared__clauses_7_10);
  bblt_sub_no_check(a1,makeint(1L),x0);
  a1 = x0;
  execute(expand__shared__clauses_7_0);
  goto expand__shared__clauses_7_ext_interrupt;
 expand__shared__clauses_7_10:
  if (a1 != makeint(0L)) goto expand__shared__clauses_7_interrupt;
  unify(a6, a5);
  proceed();
 expand__shared__clauses_7_11:
  if (!isref(a1)) goto expand__shared__clauses_7_interrupt;
  deref_and_jump(a1,expand__shared__clauses_7_9);
  *reasonp++ =  a1;
  goto expand__shared__clauses_7_interrupt;
 expand__shared__clauses_7_ext_interrupt:
  reasonp = 0l;
 expand__shared__clauses_7_interrupt:
  goto interrupt_7;
 }

 expand__shared__bodys_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 expand__shared__bodys_8_clear_reason:
  reasonp = reasons;
 expand__shared__bodys_8_0:
 expand__shared__bodys_8_1:
  if (!isint(a2)) goto expand__shared__bodys_8_3;
  gblt_greater(a2,makeint(0L),expand__shared__bodys_8_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xexpand__shared__bodys_8);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[12] = a2;
  allocp[13] = makeint(1L);
  allocp[14] = x0;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_dependency_xexpand__shared__body_9);
  allocp[17] = a0;
  allocp[18] = a1;
  allocp[19] = a2;
  allocp[20] = x2 = makeref(&allocp[20]);
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = a4;
  allocp[23] = a5;
  allocp[24] = a6;
  allocp[25] = x1;
  allocp[26] = makesym(functor_options_2);
  allocp[27] = x5 = makeref(&allocp[27]);
  allocp[28] = x3;
  x4 = makefunctor(&allocp[26]);
  allocp[29] = (q)(struct goalrec*)&allocp[15];
  allocp[30] = (q)(&predicate_parse__uty_xdecode__goal_4);
  allocp[31] = x6 = makeref(&allocp[31]);
  allocp[32] = x2;
  allocp[33] = x7 = makeref(&allocp[33]);
  allocp[34] = x4;
  allocp[35] = (q)(struct goalrec*)&allocp[29];
  allocp[36] = (q)(&predicate_functor__table_xarg_3);
  allocp[37] = a2;
  allocp[38] = a3;
  allocp[39] = x6;
  qp = (struct goalrec*)&allocp[35];
  allocp += 40;
  proceed();
 expand__shared__bodys_8_2:
  if (a2 != makeint(0L)) goto expand__shared__bodys_8_interrupt;
  unify(a7, a6);
  proceed();
 expand__shared__bodys_8_3:
  if (!isref(a2)) goto expand__shared__bodys_8_interrupt;
  deref_and_jump(a2,expand__shared__bodys_8_1);
  *reasonp++ =  a2;
  goto expand__shared__bodys_8_interrupt;
 expand__shared__bodys_8_ext_interrupt:
  reasonp = 0l;
 expand__shared__bodys_8_interrupt:
  toppred = &predicate_dependency_xexpand__shared__bodys_8;
  goto interrupt_8;
 }

 expand__shared__body_9_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 expand__shared__body_9_clear_reason:
  reasonp = reasons;
 expand__shared__body_9_0:
 expand__shared__body_9_1:
  switch (ptagof(a4)) {
 case FUNCTOR:
  if (functor_of(a4) != makesym(functor_atom_1)) goto expand__shared__body_9_3;
  x0 = arg(a4, 0);
 expand__shared__body_9_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_shared)) goto expand__shared__body_9_3;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xexpand__shared__args_9);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a3;
  allocp[4] = a0;
  allocp[5] = a1;
  allocp[6] = a2;
  allocp[7] = a5;
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_loop_xget__lf__entry_5);
  allocp[13] = a0;
  allocp[14] = x3 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = a6;
  allocp[17] = x2;
  allocp[18] = (q)(struct goalrec*)&allocp[11];
  allocp[19] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[20] = a3;
  allocp[21] = x3;
  allocp[22] = x1;
  qp = (struct goalrec*)&allocp[18];
  allocp += 23;
  proceed();
 case VARREF:
  deref_and_jump(x0,expand__shared__body_9_2);
  *reasonp++ =  x0;
  goto expand__shared__body_9_3;
  };
  goto expand__shared__body_9_3;
 case VARREF:
  deref_and_jump(a4,expand__shared__body_9_1);
  *reasonp++ =  a4;
  goto expand__shared__body_9_3;
  };
  goto expand__shared__body_9_3;
 expand__shared__body_9_3:
  otherwise(expand__shared__body_9_interrupt);
  unify(a8, a7);
  proceed();
 expand__shared__body_9_ext_interrupt:
  reasonp = 0l;
 expand__shared__body_9_interrupt:
  goto interrupt_9;
 }

 expand__shared__args_9_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 expand__shared__args_9_clear_reason:
  reasonp = reasons;
 expand__shared__args_9_0:
 expand__shared__args_9_1:
  if (!isint(a0)) goto expand__shared__args_9_3;
  gblt_greater(a0,makeint(0L),expand__shared__args_9_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xexpand__shared__args_9);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = x1 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x0;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_dependency_xexpand__shared__arg_8);
  allocp[18] = x2 = makeref(&allocp[18]);
  allocp[19] = a2;
  allocp[20] = a3;
  allocp[21] = a4;
  allocp[22] = a5;
  allocp[23] = a6;
  allocp[24] = a7;
  allocp[25] = x1;
  allocp[26] = (q)(struct goalrec*)&allocp[16];
  allocp[27] = (q)(&predicate_functor__table_xarg_3);
  allocp[28] = a0;
  allocp[29] = a1;
  allocp[30] = x2;
  qp = (struct goalrec*)&allocp[26];
  allocp += 31;
  proceed();
 expand__shared__args_9_2:
  if (a0 != makeint(0L)) goto expand__shared__args_9_interrupt;
  unify(a8, a7);
  proceed();
 expand__shared__args_9_3:
  if (!isref(a0)) goto expand__shared__args_9_interrupt;
  deref_and_jump(a0,expand__shared__args_9_1);
  *reasonp++ =  a0;
  goto expand__shared__args_9_interrupt;
 expand__shared__args_9_ext_interrupt:
  reasonp = 0l;
 expand__shared__args_9_interrupt:
  goto interrupt_9;
 }

 expand__shared__arg_8_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 expand__shared__arg_8_clear_reason:
  reasonp = reasons;
 expand__shared__arg_8_0:
 expand__shared__arg_8_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_variable_3)) goto expand__shared__arg_8_2;
  allocp[0] = makesym(functor_var_3);
  allocp[1] = a1;
  allocp[2] = a2;
  allocp[3] = arg(a0, 0);
  x0 = makefunctor(&allocp[0]);
  allocp[4] = NILATOM;
  allocp[5] = x0;
  x1 = makecons(&allocp[4]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_dependency_xexpand__shared__types_10);
  allocp[8] = x2 = makeref(&allocp[8]);
  x3 = arg(a0, 2);
  allocp[9] = x3;
  allocp[10] = a1;
  allocp[11] = a2;
  allocp[12] = a3;
  allocp[13] = a4;
  allocp[14] = a5;
  allocp[15] = x1;
  allocp[16] = a6;
  allocp[17] = a7;
  allocp[18] = (q)(struct goalrec*)&allocp[6];
  allocp[19] = (q)(&predicate_type_xget__types_5);
  allocp[20] = a1;
  allocp[21] = a2;
  x4 = arg(a0, 0);
  allocp[22] = x4;
  allocp[23] = a4;
  allocp[24] = x2;
  qp = (struct goalrec*)&allocp[18];
  allocp += 25;
  proceed();
 case VARREF:
  deref_and_jump(a0,expand__shared__arg_8_1);
  *reasonp++ =  a0;
  goto expand__shared__arg_8_2;
  };
  goto expand__shared__arg_8_2;
 expand__shared__arg_8_2:
  otherwise(expand__shared__arg_8_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xexpand__shared__types_10);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = makesym(atom_i);
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = NILATOM;
  allocp[10] = a6;
  allocp[11] = a7;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_type_xvalue2types_7);
  allocp[14] = a1;
  allocp[15] = a2;
  allocp[16] = a0;
  allocp[17] = NILATOM;
  allocp[18] = NILATOM;
  allocp[19] = makesym(atom_u);
  allocp[20] = x0;
  qp = (struct goalrec*)&allocp[12];
  allocp += 21;
  proceed();
 expand__shared__arg_8_ext_interrupt:
  reasonp = 0l;
 expand__shared__arg_8_interrupt:
  goto interrupt_8;
 }

 expand__shared__types_10_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 expand__shared__types_10_clear_reason:
  reasonp = reasons;
 expand__shared__types_10_0:
 expand__shared__types_10_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 expand__shared__types_10_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__3F)) goto expand__shared__types_10_3;
  a0 = cdr_of(a0);
  execute(expand__shared__types_10_0);
  goto expand__shared__types_10_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,expand__shared__types_10_2);
  *reasonp++ =  x0;
  goto expand__shared__types_10_3;
  };
  goto expand__shared__types_10_3;
 case VARREF:
  deref_and_jump(a0,expand__shared__types_10_1);
  *reasonp++ =  a0;
  goto expand__shared__types_10_3;
  };
  goto expand__shared__types_10_3;
 expand__shared__types_10_3:
  otherwise(expand__shared__types_10_interrupt);
 expand__shared__types_10_4:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = makesym(functor_t_4);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  x0 = makefunctor(&allocp[0]);
  x5 = car_of(a0);
  allocp += 5;
  unify_value(x5, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xexpand__shared__types_10);
  x6 = cdr_of(a0);
  allocp[2] = x6;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = x7 = makeref(&allocp[10]);
  allocp[11] = a9;
  a0 = x1;
  x8 = a1;
  x9 = a2;
  x10 = a3;
  x11 = a4;
  x12 = a5;
  x13 = a6;
  x14 = a7;
  a9 = a8;
  a10 = x7;
  a8 = x14;
  a7 = x13;
  a6 = x12;
  a5 = x11;
  a4 = x10;
  a3 = x9;
  a2 = x8;
  a1 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  execute(expand__shared__type_11_0);
  goto expand__shared__type_11_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto expand__shared__types_10_interrupt;
  unify(a9, a8);
  proceed();
 case VARREF:
  deref_and_jump(a0,expand__shared__types_10_4);
  *reasonp++ =  a0;
  goto expand__shared__types_10_interrupt;
  };
  goto expand__shared__types_10_interrupt;
 expand__shared__types_10_ext_interrupt:
  reasonp = 0l;
 expand__shared__types_10_interrupt:
  goto interrupt_10;
 }

 expand__shared__type_11_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 expand__shared__type_11_clear_reason:
  reasonp = reasons;
 expand__shared__type_11_0:
 expand__shared__type_11_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_v_4:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xexpand__shared__type__var_15);
  allocp[2] = x0 = makeref(&allocp[2]);
  x1 = arg(a0, 0);
  allocp[3] = x1;
  x2 = arg(a0, 1);
  allocp[4] = x2;
  x3 = arg(a0, 3);
  allocp[5] = x3;
  allocp[6] = a0;
  allocp[7] = a1;
  allocp[8] = a2;
  allocp[9] = a3;
  allocp[10] = a4;
  allocp[11] = a5;
  allocp[12] = a6;
  allocp[13] = a7;
  allocp[14] = a8;
  allocp[15] = a9;
  allocp[16] = a10;
  allocp[17] = makesym(functor_var_3);
  allocp[18] = x1;
  allocp[19] = x2;
  allocp[20] = x3;
  x4 = makefunctor(&allocp[17]);
  allocp[21] = (q)(struct goalrec*)&allocp[0];
  allocp[22] = (q)(&predicate_list_xcheck__include_3);
  allocp[23] = x4;
  allocp[24] = a8;
  allocp[25] = x0;
  qp = (struct goalrec*)&allocp[21];
  allocp += 26;
  proceed();
 case functor_s_3:
  x0 = arg(a0, 1);
 expand__shared__type_11_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (isint(x0)) goto expand__shared__type_11_3;
  if (x0 != makesym(atom_n)) goto expand__shared__type_11_4;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xexpand__shared__types_10);
  x1 = arg(a0, 2);
  allocp[2] = x1;
  allocp[3] = a2;
  allocp[4] = a3;
  allocp[5] = a4;
  allocp[6] = a5;
  allocp[7] = a6;
  allocp[8] = a7;
  allocp[9] = a8;
  allocp[10] = x2 = makeref(&allocp[10]);
  allocp[11] = a10;
  a0 = a2;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  a5 = a9;
  a6 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  execute(expand__shared__type__add__deps_7_0);
  goto expand__shared__type__add__deps_7_ext_interrupt;
 expand__shared__type_11_3:
  gblt_integer(x0,expand__shared__type_11_4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xexpand__shared__type__struct_11);
  allocp[2] = x0;
  x1 = arg(a0, 2);
  allocp[3] = x1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = x2 = makeref(&allocp[11]);
  allocp[12] = a10;
  a0 = a2;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  a5 = a9;
  a6 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 13;
  execute(expand__shared__type__add__deps_7_0);
  goto expand__shared__type__add__deps_7_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,expand__shared__type_11_2);
  *reasonp++ =  x0;
  goto expand__shared__type_11_4;
  };
  goto expand__shared__type_11_4;
  };
  goto expand__shared__type_11_4;
 case VARREF:
  deref_and_jump(a0,expand__shared__type_11_1);
  *reasonp++ =  a0;
  goto expand__shared__type_11_4;
  };
  goto expand__shared__type_11_4;
 expand__shared__type_11_4:
  otherwise(expand__shared__type_11_interrupt);
  a0 = a2;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  a5 = a9;
  a6 = a10;
  execute(expand__shared__type__add__deps_7_0);
  goto expand__shared__type__add__deps_7_ext_interrupt;
 expand__shared__type_11_ext_interrupt:
  reasonp = 0l;
 expand__shared__type_11_interrupt:
  toppred = &predicate_dependency_xexpand__shared__type_11;
  goto interrupt_11;
 }

 expand__shared__type__var_15_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  qp = qp->next;
 expand__shared__type__var_15_clear_reason:
  reasonp = reasons;
 expand__shared__type__var_15_0:
 expand__shared__type__var_15_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto expand__shared__type__var_15_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  unify(a14, a13);
  proceed();
 case symval(makesym(atom_no)):
  allocp[0] = makesym(functor_var_3);
  allocp[1] = a1;
  allocp[2] = a2;
  allocp[3] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[4] = a12;
  allocp[5] = x0;
  x1 = makecons(&allocp[4]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_dependency_xexpand__shared__types_10);
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = x3 = makeref(&allocp[9]);
  allocp[10] = a7;
  allocp[11] = a8;
  allocp[12] = a9;
  allocp[13] = a10;
  allocp[14] = a11;
  allocp[15] = x1;
  allocp[16] = x4 = makeref(&allocp[16]);
  allocp[17] = a14;
  allocp[18] = (q)(struct goalrec*)&allocp[6];
  allocp[19] = (q)(&predicate_dependency_xexpand__shared__type__make__mode_3);
  allocp[20] = x3;
  allocp[21] = a4;
  allocp[22] = a11;
  allocp[23] = (q)(struct goalrec*)&allocp[18];
  allocp[24] = (q)(&predicate_type_xget__types_5);
  allocp[25] = a1;
  allocp[26] = a2;
  allocp[27] = a3;
  allocp[28] = a10;
  allocp[29] = x2;
  a0 = a6;
  a1 = a5;
  a2 = a7;
  a3 = a8;
  a4 = a9;
  a5 = a13;
  a6 = x4;
  qp = (struct goalrec*)&allocp[23];
  allocp += 30;
  execute(expand__shared__type__add__deps_7_0);
  goto expand__shared__type__add__deps_7_ext_interrupt;
  };
  goto expand__shared__type__var_15_interrupt;
 case VARREF:
  deref_and_jump(a0,expand__shared__type__var_15_1);
  *reasonp++ =  a0;
  goto expand__shared__type__var_15_interrupt;
  };
  goto expand__shared__type__var_15_interrupt;
 expand__shared__type__var_15_ext_interrupt:
  reasonp = 0l;
 expand__shared__type__var_15_interrupt:
  goto interrupt_15;
 }

 expand__shared__type__struct_11_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 expand__shared__type__struct_11_clear_reason:
  reasonp = reasons;
 expand__shared__type__struct_11_0:
 expand__shared__type__struct_11_1:
  if (!isint(a0)) goto expand__shared__type__struct_11_3;
  gblt_greater(a0,makeint(0L),expand__shared__type__struct_11_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xexpand__shared__type__struct_11);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = x1 = makeref(&allocp[11]);
  allocp[12] = a10;
  allocp[13] = (q)(struct goalrec*)&allocp[0];
  allocp[14] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[15] = a0;
  allocp[16] = makeint(1L);
  allocp[17] = x0;
  allocp[18] = (q)(struct goalrec*)&allocp[13];
  allocp[19] = (q)(&predicate_dependency_xexpand__shared__types_10);
  allocp[20] = x2 = makeref(&allocp[20]);
  allocp[21] = a2;
  allocp[22] = a3;
  allocp[23] = a4;
  allocp[24] = a5;
  allocp[25] = a6;
  allocp[26] = a7;
  allocp[27] = a8;
  allocp[28] = a9;
  allocp[29] = x1;
  allocp[30] = (q)(struct goalrec*)&allocp[18];
  allocp[31] = (q)(&predicate_functor__table_xarg_3);
  allocp[32] = a0;
  allocp[33] = a1;
  allocp[34] = x2;
  qp = (struct goalrec*)&allocp[30];
  allocp += 35;
  proceed();
 expand__shared__type__struct_11_2:
  if (a0 != makeint(0L)) goto expand__shared__type__struct_11_interrupt;
  unify(a10, a9);
  proceed();
 expand__shared__type__struct_11_3:
  if (!isref(a0)) goto expand__shared__type__struct_11_interrupt;
  deref_and_jump(a0,expand__shared__type__struct_11_1);
  *reasonp++ =  a0;
  goto expand__shared__type__struct_11_interrupt;
 expand__shared__type__struct_11_ext_interrupt:
  reasonp = 0l;
 expand__shared__type__struct_11_interrupt:
  goto interrupt_11;
 }

 expand__shared__type__add__deps_7_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 expand__shared__type__add__deps_7_clear_reason:
  reasonp = reasons;
 expand__shared__type__add__deps_7_0:
 expand__shared__type__add__deps_7_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto expand__shared__type__add__deps_7_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_i)):
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a2;
  allocp[2] = a3;
  allocp[3] = a4;
  allocp[4] = makesym(atom_body);
  x0 = makefunctor(&allocp[0]);
  a0 = makesym(atom_data);
  a2 = a1;
  a3 = a5;
  a4 = a6;
  a1 = x0;
  allocp += 5;
  execute(entry__deps_5_0);
  goto entry__deps_5_ext_interrupt;
 case symval(makesym(atom_o)):
  unify(a6, a5);
  proceed();
  };
  goto expand__shared__type__add__deps_7_interrupt;
 case VARREF:
  deref_and_jump(a0,expand__shared__type__add__deps_7_1);
  *reasonp++ =  a0;
  goto expand__shared__type__add__deps_7_interrupt;
  };
  goto expand__shared__type__add__deps_7_interrupt;
 expand__shared__type__add__deps_7_ext_interrupt:
  reasonp = 0l;
 expand__shared__type__add__deps_7_interrupt:
  toppred = &predicate_dependency_xexpand__shared__type__add__deps_7;
  goto interrupt_7;
 }

 expand__shared__type__make__mode_3_top: {
  q x0;
  a2 = qp->args[2];
  qp = qp->next;
 expand__shared__type__make__mode_3_clear_reason:
  reasonp = reasons;
 expand__shared__type__make__mode_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xexpand__shared__type__make__mode1_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_loop_xcheck__var__within_3);
  allocp[6] = a1;
  allocp[7] = a2;
  allocp[8] = x0;
  qp = (struct goalrec*)&allocp[4];
  allocp += 9;
  proceed();
 expand__shared__type__make__mode_3_ext_interrupt:
  reasonp = 0l;
 expand__shared__type__make__mode_3_interrupt:
  goto interrupt_3;
 }

 expand__shared__type__make__mode1_2_top: {
  qp = qp->next;
 expand__shared__type__make__mode1_2_clear_reason:
  reasonp = reasons;
 expand__shared__type__make__mode1_2_0:
 expand__shared__type__make__mode1_2_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto expand__shared__type__make__mode1_2_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  unify_value(a1, makesym(atom_o));
  proceed();
 case symval(makesym(atom_no)):
  unify_value(a1, makesym(atom_i));
  proceed();
  };
  goto expand__shared__type__make__mode1_2_interrupt;
 case VARREF:
  deref_and_jump(a0,expand__shared__type__make__mode1_2_1);
  *reasonp++ =  a0;
  goto expand__shared__type__make__mode1_2_interrupt;
  };
  goto expand__shared__type__make__mode1_2_interrupt;
 expand__shared__type__make__mode1_2_ext_interrupt:
  reasonp = 0l;
 expand__shared__type__make__mode1_2_interrupt:
  goto interrupt_2;
 }
 interrupt_15:
  allocp[16] = a14;
 interrupt_14:
  allocp[15] = a13;
 interrupt_13:
  allocp[14] = a12;
 interrupt_12:
  allocp[13] = a11;
 interrupt_11:
  allocp[12] = a10;
 interrupt_10:
  allocp[11] = a9;
 interrupt_9:
  allocp[10] = a8;
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_dependency);
}
