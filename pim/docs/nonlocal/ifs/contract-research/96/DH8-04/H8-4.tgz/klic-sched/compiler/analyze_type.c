/* Compiled by KLIC compiler version 2.002 (Tue May 23 13:27:38 JST 1995) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_analyze__type();
Const struct predicate predicate_analyze__type_xmain_12 =
   { module_analyze__type, 0, 12 };
Const struct predicate predicate_analyze__type_xmain1_13 =
   { module_analyze__type, 1, 13 };
Const struct predicate predicate_analyze__type_xanalyze__type__modules_12 =
   { module_analyze__type, 2, 12 };
Const struct predicate predicate_analyze__type_xanalyze__type__modules_11 =
   { module_analyze__type, 3, 11 };
Const struct predicate predicate_analyze__type_xanalyze__type__clause_13 =
   { module_analyze__type, 4, 13 };
Const struct predicate predicate_analyze__type_xapply__type__goals_16 =
   { module_analyze__type, 5, 16 };
Const struct predicate predicate_analyze__type_xapply__type__goals1_17 =
   { module_analyze__type, 6, 17 };
Const struct predicate predicate_analyze__type_xapply__type__goal_17 =
   { module_analyze__type, 7, 17 };
Const struct predicate predicate_analyze__type_xapply__type__goal1_19 =
   { module_analyze__type, 8, 19 };
Const struct predicate predicate_analyze__type_xapply__type__goal2_20 =
   { module_analyze__type, 9, 20 };
Const struct predicate predicate_analyze__type_xcheck__waits_3 =
   { module_analyze__type, 10, 3 };
Const struct predicate predicate_analyze__type_xget__call__modulename_3 =
   { module_analyze__type, 11, 3 };
Const struct predicate predicate_analyze__type_xbuiltin__type_21 =
   { module_analyze__type, 12, 21 };
Const struct predicate predicate_analyze__type_xbuiltin__type__userdef_10 =
   { module_analyze__type, 13, 10 };
Const struct predicate predicate_analyze__type_xbuiltin__type__userdef1_11 =
   { module_analyze__type, 14, 11 };
Const struct predicate predicate_analyze__type_xbuiltin__type__unify_18 =
   { module_analyze__type, 15, 18 };
Const struct predicate predicate_analyze__type_xmake__arg__types_13 =
   { module_analyze__type, 16, 13 };
Const struct predicate predicate_analyze__type_xget__arg__types_6 =
   { module_analyze__type, 17, 6 };
Const struct predicate predicate_analyze__type_xadd__dep__goal_8 =
   { module_analyze__type, 18, 8 };
Const struct predicate predicate_analyze__type_xinterclause__modules_19 =
   { module_analyze__type, 19, 19 };
Const struct predicate predicate_analyze__type_xinterclause__clauses_22 =
   { module_analyze__type, 20, 22 };
Const struct predicate predicate_analyze__type_xinterclause__clause_22 =
   { module_analyze__type, 21, 22 };
Const struct predicate predicate_analyze__type_xset__head__body__types_21 =
   { module_analyze__type, 22, 21 };
Const struct predicate predicate_analyze__type_xset__goals__mode_11 =
   { module_analyze__type, 23, 11 };
Const struct predicate predicate_analyze__type_xset__goals__mode1_12 =
   { module_analyze__type, 24, 12 };
Const struct predicate predicate_analyze__type_xset__goal__mode_11 =
   { module_analyze__type, 25, 11 };
Const struct predicate predicate_analyze__type_xset__goal__mode1_11 =
   { module_analyze__type, 26, 11 };
Const struct predicate predicate_analyze__type_xset__goals__types_20 =
   { module_analyze__type, 27, 20 };
Const struct predicate predicate_analyze__type_xset__goals__types1_21 =
   { module_analyze__type, 28, 21 };
Const struct predicate predicate_analyze__type_xset__goal__types_21 =
   { module_analyze__type, 29, 21 };
Const struct predicate predicate_analyze__type_xset__goal__types1_23 =
   { module_analyze__type, 30, 23 };
Const struct predicate predicate_analyze__type_xset__arg__types_13 =
   { module_analyze__type, 31, 13 };
Const struct predicate predicate_analyze__type_xapply__new__indirect_13 =
   { module_analyze__type, 32, 13 };
Const struct predicate predicate_analyze__type_xapply__new__indirect1_18 =
   { module_analyze__type, 33, 18 };
Const struct predicate predicate_analyze__type_xapply__new__indirect1__alias_28 =
   { module_analyze__type, 34, 28 };
Const struct predicate predicate_analyze__type_xadd__indirect__deps__alias_15 =
   { module_analyze__type, 35, 15 };
Const struct predicate predicate_analyze__type_xapply__indirect_16 =
   { module_analyze__type, 36, 16 };
Const struct predicate predicate_analyze__type_xapply__indirect1_19 =
   { module_analyze__type, 37, 19 };
Const struct predicate predicate_analyze__type_xapply__indirect2_26 =
   { module_analyze__type, 38, 26 };
Const struct predicate predicate_analyze__type_xapply__indirect2__alias_31 =
   { module_analyze__type, 39, 31 };
Const struct predicate predicate_analyze__type_xindirect__mode__expansion_17 =
   { module_analyze__type, 40, 17 };
Const struct predicate predicate_analyze__type_xindirect__mode__expansion1_19 =
   { module_analyze__type, 41, 19 };
Const struct predicate predicate_analyze__type_xindirect__mode__expansion11_20 =
   { module_analyze__type, 42, 20 };
Const struct predicate predicate_analyze__type_xindirect__mode__expansion2_14 =
   { module_analyze__type, 43, 14 };
Const struct predicate predicate_analyze__type_xindirect__mode__modules_8 =
   { module_analyze__type, 44, 8 };
Const struct predicate predicate_analyze__type_xindirect__mode__clause_4 =
   { module_analyze__type, 45, 4 };
Const struct predicate predicate_analyze__type_xindirect__mode__goals_6 =
   { module_analyze__type, 46, 6 };
Const struct predicate predicate_analyze__type_xindirect__mode__goals1_7 =
   { module_analyze__type, 47, 7 };
Const struct predicate predicate_analyze__type_xindirect__mode__goal_6 =
   { module_analyze__type, 48, 6 };
Const struct predicate predicate_analyze__type_xindirect__mode__arg_7 =
   { module_analyze__type, 49, 7 };
Const struct predicate predicate_analyze__type_xindirect__mode__arg1_6 =
   { module_analyze__type, 50, 6 };
Const struct predicate predicate_analyze__type_xindirect__mode__expansion__alias_6 =
   { module_analyze__type, 51, 6 };
Const struct predicate predicate_analyze__type_xexpand__ru__indirect_4 =
   { module_analyze__type, 52, 4 };
Const struct predicate predicate_analyze__type_xexpand__ru__indirect1_5 =
   { module_analyze__type, 53, 5 };
Const struct predicate predicate_analyze__type_xexpand__ru__indirect__unify_8 =
   { module_analyze__type, 54, 8 };
Const struct predicate predicate_analyze__type_xexpand__ru__indirect__unify2_6 =
   { module_analyze__type, 55, 6 };
Const struct predicate predicate_analyze__type_xexpand__ru__indirect__unify1_9 =
   { module_analyze__type, 56, 9 };
Const struct predicate predicate_analyze__type_xexpand__ru__indirect__updown_8 =
   { module_analyze__type, 57, 8 };
Const struct predicate predicate_analyze__type_xexpand__ru__indirect__updown2_6 =
   { module_analyze__type, 58, 6 };
Const struct predicate predicate_analyze__type_xexpand__ru__indirect__updown1_9 =
   { module_analyze__type, 59, 9 };
Const struct predicate predicate_analyze__type_xremove__redundant__indirect_2 =
   { module_analyze__type, 60, 2 };
Const struct predicate predicate_analyze__type_xremove__redundant__indirect1_3 =
   { module_analyze__type, 61, 3 };
Const struct predicate predicate_analyze__type_xremove__redandant__indirect2_4 =
   { module_analyze__type, 62, 4 };
Const struct predicate predicate_analyze__type_xremove__redandant__indirect__updown_5 =
   { module_analyze__type, 63, 5 };
Const struct predicate predicate_analyze__type_xremove__redandant__indirect__unify_3 =
   { module_analyze__type, 64, 3 };
Const struct predicate predicate_analyze__type_xremove__redandant__indirect__unify1_3 =
   { module_analyze__type, 65, 3 };
extern Const struct predicate predicate_list_xappend_3;
extern Const struct predicate predicate_mode_xdetermine__goal__mode_6;
extern Const struct predicate predicate_mode_xset__arg__mode_6;
extern Const struct predicate predicate_mode_xreverse__mode_2;
extern Const struct predicate predicate_mode_xmode2ru_2;
extern Const struct predicate predicate_mode_xget__mode_9;
extern Const struct predicate predicate_mode_xru2mode_2;
extern Const struct predicate predicate_mode_xreverse__ru_2;
extern Const struct predicate predicate_integer__arithmetics_xadd_3;
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_functor__table_xfunctor_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_xsetarg_4;
extern Const struct predicate predicate_type_xget__types_5;
extern Const struct predicate predicate_type_xget__arg__types_5;
extern Const struct predicate predicate_type_xtype2atom_2;
extern Const struct predicate predicate_type_xtype2int_2;
extern Const struct predicate predicate_type_xset__types_13;
extern Const struct predicate predicate_type_xand__types_4;
extern Const struct predicate predicate_type_xand__types_5;
extern Const struct predicate predicate_type_xadd__dep__goal_3;
extern Const struct predicate predicate_type_xset__ru_3;
extern Const struct predicate predicate_type_xmake__types__loopup_9;
extern Const struct predicate predicate_type_xentry__indirect_3;
extern Const struct predicate predicate_type_xadd__dep__goals_3;
extern Const struct predicate predicate_type_xor__types_3;
extern Const struct predicate predicate_type_xmake__types__loopdown_16;
extern Const struct predicate predicate_unify__head__body_xget__types_17;
extern Const struct predicate predicate_parse__uty_xdecode__goal_4;
extern Const struct predicate predicate_parse__uty_xencode__goal_4;
extern Const struct predicate predicate_parse__uty_xdecode__goalcall_6;
extern Const struct predicate predicate_builtin__type_xupdate__type__new__functor_4;
extern Const struct predicate predicate_builtin__type_xupdate__type__arg_4;
extern Const struct predicate predicate_builtin__type_xupdate__type__setarg_6;
extern Const struct predicate predicate_loop_xget__lv__entry_5;
extern Const struct predicate predicate_loop_xupdate__lv__entry_6;

module module_analyze__type(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  static Const q cons_const_0[] = {
    NILATOM,
    makesym(atom__3F),
  };
  static Const q funct_const_1[] = {
    makesym(functor_v_4),
    makeint(0),
    makeint(0),
    makeint(0),
    makeint(0),
  };
  q a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17, a18, a19, a20, a21, a22, a23, a24, a25, a26, a27, a28, a29, a30;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, main_12_top);
    case_pred(1, main1_13_top);
    case_pred(2, analyze__type__modules_12_top);
    case_pred(3, analyze__type__modules_11_top);
    case_pred(4, analyze__type__clause_13_top);
    case_pred(5, apply__type__goals_16_top);
    case_pred(6, apply__type__goals1_17_top);
    case_pred(7, apply__type__goal_17_top);
    case_pred(8, apply__type__goal1_19_top);
    case_pred(9, apply__type__goal2_20_top);
    case_pred(10, check__waits_3_top);
    case_pred(11, get__call__modulename_3_top);
    case_pred(12, builtin__type_21_top);
    case_pred(13, builtin__type__userdef_10_top);
    case_pred(14, builtin__type__userdef1_11_top);
    case_pred(15, builtin__type__unify_18_top);
    case_pred(16, make__arg__types_13_top);
    case_pred(17, get__arg__types_6_top);
    case_pred(18, add__dep__goal_8_top);
    case_pred(19, interclause__modules_19_top);
    case_pred(20, interclause__clauses_22_top);
    case_pred(21, interclause__clause_22_top);
    case_pred(22, set__head__body__types_21_top);
    case_pred(23, set__goals__mode_11_top);
    case_pred(24, set__goals__mode1_12_top);
    case_pred(25, set__goal__mode_11_top);
    case_pred(26, set__goal__mode1_11_top);
    case_pred(27, set__goals__types_20_top);
    case_pred(28, set__goals__types1_21_top);
    case_pred(29, set__goal__types_21_top);
    case_pred(30, set__goal__types1_23_top);
    case_pred(31, set__arg__types_13_top);
    case_pred(32, apply__new__indirect_13_top);
    case_pred(33, apply__new__indirect1_18_top);
    case_pred(34, apply__new__indirect1__alias_28_top);
    case_pred(35, add__indirect__deps__alias_15_top);
    case_pred(36, apply__indirect_16_top);
    case_pred(37, apply__indirect1_19_top);
    case_pred(38, apply__indirect2_26_top);
    case_pred(39, apply__indirect2__alias_31_top);
    case_pred(40, indirect__mode__expansion_17_top);
    case_pred(41, indirect__mode__expansion1_19_top);
    case_pred(42, indirect__mode__expansion11_20_top);
    case_pred(43, indirect__mode__expansion2_14_top);
    case_pred(44, indirect__mode__modules_8_top);
    case_pred(45, indirect__mode__clause_4_top);
    case_pred(46, indirect__mode__goals_6_top);
    case_pred(47, indirect__mode__goals1_7_top);
    case_pred(48, indirect__mode__goal_6_top);
    case_pred(49, indirect__mode__arg_7_top);
    case_pred(50, indirect__mode__arg1_6_top);
    case_pred(51, indirect__mode__expansion__alias_6_top);
    case_pred(52, expand__ru__indirect_4_top);
    case_pred(53, expand__ru__indirect1_5_top);
    case_pred(54, expand__ru__indirect__unify_8_top);
    case_pred(55, expand__ru__indirect__unify2_6_top);
    case_pred(56, expand__ru__indirect__unify1_9_top);
    case_pred(57, expand__ru__indirect__updown_8_top);
    case_pred(58, expand__ru__indirect__updown2_6_top);
    case_pred(59, expand__ru__indirect__updown1_9_top);
    case_pred(60, remove__redundant__indirect_2_top);
    case_pred(61, remove__redundant__indirect1_3_top);
    case_pred(62, remove__redandant__indirect2_4_top);
    case_pred(63, remove__redandant__indirect__updown_5_top);
    case_pred(64, remove__redandant__indirect__unify_3_top);
    last_case_pred(65, remove__redandant__indirect__unify1_3_top);
  }

 main_12_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 main_12_clear_reason:
  reasonp = reasons;
 main_12_0:
 main_12_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 main_12_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_var_5:
  x1 = arg(x0, 4);
 main_12_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_variable_3)) goto main_12_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xmain1_13);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x4 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x5 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = a7;
  allocp[11] = x7 = makeref(&allocp[11]);
  allocp[12] = a9;
  allocp[13] = x8 = makeref(&allocp[13]);
  allocp[14] = a11;
  allocp[15] = (q)(struct goalrec*)&allocp[0];
  allocp[16] = (q)(&predicate_analyze__type_xapply__indirect_16);
  allocp[17] = x0;
  allocp[18] = x9 = makeref(&allocp[18]);
  allocp[19] = a5;
  allocp[20] = x5;
  allocp[21] = x10 = makeref(&allocp[21]);
  allocp[22] = x6;
  allocp[23] = x11 = makeref(&allocp[23]);
  allocp[24] = x4;
  allocp[25] = x12 = makeref(&allocp[25]);
  allocp[26] = x2;
  allocp[27] = x13 = makeref(&allocp[27]);
  allocp[28] = x3;
  allocp[29] = a8;
  allocp[30] = x7;
  allocp[31] = a10;
  allocp[32] = x8;
  allocp[33] = (q)(struct goalrec*)&allocp[15];
  allocp[34] = (q)(&predicate_analyze__type_xanalyze__type__modules_12);
  allocp[35] = x0;
  allocp[36] = x9;
  x14 = arg(x0, 0);
  allocp[37] = x14;
  x15 = cdr_of(a0);
  allocp[38] = x15;
  allocp[39] = x12;
  allocp[40] = a1;
  allocp[41] = x13;
  allocp[42] = a3;
  allocp[43] = x11;
  allocp[44] = NILATOM;
  allocp[45] = x10;
  allocp[46] = a7;
  allocp[47] = (q)(struct goalrec*)&allocp[33];
  allocp[48] = (q)(&predicate_type_xget__types_5);
  allocp[49] = x14;
  x16 = arg(x0, 1);
  allocp[50] = x16;
  x17 = arg(x1, 0);
  allocp[51] = x17;
  allocp[52] = a3;
  allocp[53] = x9;
  qp = (struct goalrec*)&allocp[47];
  allocp += 54;
  proceed();
 case VARREF:
  deref_and_jump(x1,main_12_3);
  *reasonp++ =  x1;
  goto main_12_interrupt;
  };
  goto main_12_interrupt;
 case functor_userdef_7:
  x1 = arg(x0, 6);
 main_12_4:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_variable_3)) goto main_12_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xmain1_13);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x4 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = x5 = makeref(&allocp[9]);
  allocp[10] = a7;
  allocp[11] = x6 = makeref(&allocp[11]);
  allocp[12] = a9;
  allocp[13] = x7 = makeref(&allocp[13]);
  allocp[14] = a11;
  allocp[15] = (q)(struct goalrec*)&allocp[0];
  allocp[16] = (q)(&predicate_analyze__type_xinterclause__modules_19);
  allocp[17] = a1;
  allocp[18] = x3;
  x8 = arg(x0, 0);
  allocp[19] = x8;
  x9 = arg(x0, 1);
  allocp[20] = x9;
  x10 = arg(x0, 2);
  allocp[21] = x10;
  x11 = arg(x0, 3);
  allocp[22] = x11;
  allocp[23] = x12 = makeref(&allocp[23]);
  allocp[24] = x13 = makeref(&allocp[24]);
  x14 = arg(x1, 2);
  allocp[25] = x14;
  allocp[26] = x15 = makeref(&allocp[26]);
  allocp[27] = x4;
  x16 = cdr_of(a0);
  allocp[28] = x16;
  allocp[29] = x2;
  allocp[30] = x17 = makeref(&allocp[30]);
  allocp[31] = x5;
  allocp[32] = a5;
  allocp[33] = x18 = makeref(&allocp[33]);
  allocp[34] = x6;
  allocp[35] = a10;
  allocp[36] = (q)(struct goalrec*)&allocp[15];
  allocp[37] = (q)(&predicate_unify__head__body_xget__types_17);
  allocp[38] = a7;
  allocp[39] = x8;
  allocp[40] = x9;
  allocp[41] = x10;
  allocp[42] = x11;
  allocp[43] = x12;
  allocp[44] = x13;
  allocp[45] = x14;
  allocp[46] = a3;
  allocp[47] = x15;
  allocp[48] = NILATOM;
  allocp[49] = x17;
  allocp[50] = a5;
  allocp[51] = a8;
  allocp[52] = x18;
  allocp[53] = a10;
  allocp[54] = x7;
  qp = (struct goalrec*)&allocp[36];
  allocp += 55;
  proceed();
 case VARREF:
  deref_and_jump(x1,main_12_4);
  *reasonp++ =  x1;
  goto main_12_interrupt;
  };
  goto main_12_interrupt;
  };
  goto main_12_interrupt;
 case VARREF:
  deref_and_jump(x0,main_12_2);
  *reasonp++ =  x0;
  goto main_12_interrupt;
  };
  goto main_12_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto main_12_interrupt;
  unify4(a2, a1, a4, a3, a6, a5, a9, a8);
  unify(a11, a10);
  proceed();
 case VARREF:
  deref_and_jump(a0,main_12_1);
  *reasonp++ =  a0;
  goto main_12_interrupt;
  };
  goto main_12_interrupt;
 main_12_ext_interrupt:
  reasonp = 0l;
 main_12_interrupt:
  goto interrupt_12;
 }

 main1_13_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  qp = qp->next;
 main1_13_clear_reason:
  reasonp = reasons;
 main1_13_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xmain_12);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = a8;
  allocp[10] = x4 = makeref(&allocp[10]);
  allocp[11] = a10;
  allocp[12] = x5 = makeref(&allocp[12]);
  allocp[13] = a12;
  allocp[14] = (q)(struct goalrec*)&allocp[0];
  allocp[15] = (q)(&predicate_analyze__type_xexpand__ru__indirect_4);
  allocp[16] = x6 = makeref(&allocp[16]);
  allocp[17] = x3;
  allocp[18] = x7 = makeref(&allocp[18]);
  allocp[19] = x0;
  x8 = a7;
  x9 = a5;
  a2 = x6;
  a4 = x2;
  a5 = a0;
  a6 = x7;
  a7 = a1;
  a8 = x1;
  a10 = x4;
  a12 = x5;
  a1 = x9;
  a0 = x8;
  qp = (struct goalrec*)&allocp[14];
  allocp += 20;
  execute(apply__new__indirect_13_0);
  goto apply__new__indirect_13_ext_interrupt;
 main1_13_ext_interrupt:
  reasonp = 0l;
 main1_13_interrupt:
  goto interrupt_13;
 }

 analyze__type__modules_12_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 analyze__type__modules_12_clear_reason:
  reasonp = reasons;
 analyze__type__modules_12_0:
 analyze__type__modules_12_1:
  switch (ptagof(a5)) {
 case CONS:
  x0 = car_of(a5);
 analyze__type__modules_12_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto analyze__type__modules_12_8;
  x1 = arg(x0, 0);
 analyze__type__modules_12_3:
  if (isref(x1)) goto analyze__type__modules_12_7;
 analyze__type__modules_12_4:
  if (isref(x1)) goto analyze__type__modules_12_6;
  if_not_equal(x1, a2, analyze__type__modules_12_8);
 analyze__type__modules_12_5:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_var_5)) goto analyze__type__modules_12_8;
  allocp[0] = makesym(functor_module_2);
  allocp[1] = a2;
  allocp[2] = x3 = makeref(&allocp[2]);
  x2 = makefunctor(&allocp[0]);
  allocp[3] = cdr_of(a5);
  allocp[4] = x2;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a6, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  x5 = arg(a0, 1);
  allocp[2] = x5;
  x6 = arg(x0, 1);
  allocp[3] = x6;
  allocp[4] = x7 = makeref(&allocp[4]);
  allocp[5] = x3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_analyze__type_xanalyze__type__clause_13);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a3;
  allocp[11] = a4;
  allocp[12] = x8 = makeref(&allocp[12]);
  allocp[13] = x7;
  allocp[14] = a7;
  allocp[15] = a8;
  allocp[16] = a9;
  allocp[17] = a10;
  allocp[18] = a11;
  allocp[19] = a2;
  allocp[20] = x5;
  allocp[21] = (q)(struct goalrec*)&allocp[6];
  allocp[22] = (q)(&predicate_functor__table_xarg_3);
  allocp[23] = x5;
  allocp[24] = x6;
  allocp[25] = x8;
  qp = (struct goalrec*)&allocp[21];
  allocp += 26;
  proceed();
 case VARREF:
  deref_and_jump(a0,analyze__type__modules_12_5);
  *reasonp++ =  a0;
  goto analyze__type__modules_12_8;
  };
  goto analyze__type__modules_12_8;
 analyze__type__modules_12_6:
  deref_and_jump(x1,analyze__type__modules_12_4);
  *reasonp++ =  x1;
  goto analyze__type__modules_12_8;
 analyze__type__modules_12_7:
  deref_and_jump(x1,analyze__type__modules_12_3);
  *reasonp++ =  x1;
  goto analyze__type__modules_12_8;
 case VARREF:
  deref_and_jump(x0,analyze__type__modules_12_2);
  *reasonp++ =  x0;
  goto analyze__type__modules_12_8;
  };
  goto analyze__type__modules_12_8;
 case VARREF:
  deref_and_jump(a5,analyze__type__modules_12_1);
  *reasonp++ =  a5;
  goto analyze__type__modules_12_8;
  };
  goto analyze__type__modules_12_8;
 analyze__type__modules_12_8:
  otherwise(analyze__type__modules_12_interrupt);
 analyze__type__modules_12_9:
  switch (ptagof(a5)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = car_of(a5);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a6, x0);
  a5 = cdr_of(a5);
  a6 = x1;
  execute(analyze__type__modules_12_0);
  goto analyze__type__modules_12_ext_interrupt;
 case VARREF:
  deref_and_jump(a5,analyze__type__modules_12_9);
  *reasonp++ =  a5;
  goto analyze__type__modules_12_interrupt;
  };
  goto analyze__type__modules_12_interrupt;
 analyze__type__modules_12_ext_interrupt:
  reasonp = 0l;
 analyze__type__modules_12_interrupt:
  goto interrupt_12;
 }

 analyze__type__modules_11_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 analyze__type__modules_11_clear_reason:
  reasonp = reasons;
 analyze__type__modules_11_0:
 analyze__type__modules_11_1:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (a5 != NILATOM) goto analyze__type__modules_11_interrupt;
  x0 = makesym(atom_error);
  unify(x0, makesym(atom_analyze__type__modules));
  proceed();
 case VARREF:
  deref_and_jump(a5,analyze__type__modules_11_1);
  *reasonp++ =  a5;
  goto analyze__type__modules_11_interrupt;
  };
  goto analyze__type__modules_11_interrupt;
 analyze__type__modules_11_ext_interrupt:
  reasonp = 0l;
 analyze__type__modules_11_interrupt:
  goto interrupt_11;
 }

 analyze__type__clause_13_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  qp = qp->next;
 analyze__type__clause_13_clear_reason:
  reasonp = reasons;
 analyze__type__clause_13_0:
 analyze__type__clause_13_1:
  switch (ptagof(a4)) {
 case ATOMIC:
  if (isint(a4)) goto analyze__type__clause_13_interrupt;
 analyze__type__clause_13_2:
  gblt_atom(a4,analyze__type__clause_13_interrupt);
  unify(a3, a2);
  unify_value(a5, a4);
  unify2(a7, a6, a9, a8);
  proceed();
 case FUNCTOR:
  if (functor_of(a4) != makesym(functor_clause_6)) goto analyze__type__clause_13_interrupt;
  allocp[0] = makesym(functor_clause_6);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = arg(a4, 3);
  allocp[5] = arg(a4, 4);
  allocp[6] = x4 = makeref(&allocp[6]);
  x0 = makefunctor(&allocp[0]);
  allocp += 7;
  unify_value(a5, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xapply__type__goals_16);
  x5 = arg(a4, 2);
  allocp[2] = x5;
  allocp[3] = x3;
  allocp[4] = a0;
  allocp[5] = a1;
  allocp[6] = makesym(atom_body);
  allocp[7] = x6 = makeref(&allocp[7]);
  allocp[8] = a3;
  allocp[9] = x7 = makeref(&allocp[9]);
  allocp[10] = a7;
  allocp[11] = x8 = makeref(&allocp[11]);
  allocp[12] = a9;
  allocp[13] = x9 = makeref(&allocp[13]);
  allocp[14] = x4;
  allocp[15] = a10;
  allocp[16] = a11;
  allocp[17] = a12;
  allocp[18] = (q)(struct goalrec*)&allocp[0];
  allocp[19] = (q)(&predicate_analyze__type_xapply__type__goals_16);
  x10 = arg(a4, 1);
  allocp[20] = x10;
  allocp[21] = x2;
  allocp[22] = a0;
  allocp[23] = a1;
  allocp[24] = makesym(atom_guard);
  allocp[25] = x11 = makeref(&allocp[25]);
  allocp[26] = x6;
  allocp[27] = x12 = makeref(&allocp[27]);
  allocp[28] = x7;
  allocp[29] = x13 = makeref(&allocp[29]);
  allocp[30] = x8;
  allocp[31] = x14 = makeref(&allocp[31]);
  allocp[32] = x9;
  allocp[33] = a10;
  allocp[34] = a11;
  allocp[35] = a12;
  x15 = arg(a4, 0);
  x16 = a0;
  a3 = a1;
  a5 = makesym(atom_head);
  x17 = a2;
  a7 = x11;
  x18 = a6;
  a9 = x12;
  x19 = a8;
  x20 = arg(a4, 5);
  a13 = x14;
  a14 = a10;
  a15 = a11;
  a16 = a12;
  a12 = x20;
  a11 = x13;
  a10 = x19;
  a8 = x18;
  a6 = x17;
  a4 = makeint(1L);
  a2 = x16;
  a1 = x1;
  a0 = x15;
  qp = (struct goalrec*)&allocp[18];
  allocp += 36;
  execute(apply__type__goal_17_0);
  goto apply__type__goal_17_ext_interrupt;
 case VARREF:
  deref_and_jump(a4,analyze__type__clause_13_1);
  *reasonp++ =  a4;
  goto analyze__type__clause_13_interrupt;
  };
  goto analyze__type__clause_13_interrupt;
 analyze__type__clause_13_ext_interrupt:
  reasonp = 0l;
 analyze__type__clause_13_interrupt:
  goto interrupt_13;
 }

 apply__type__goals_16_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  qp = qp->next;
 apply__type__goals_16_clear_reason:
  reasonp = reasons;
 apply__type__goals_16_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xapply__type__goals1_17);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = a8;
  allocp[12] = a9;
  allocp[13] = a10;
  allocp[14] = a11;
  allocp[15] = a12;
  allocp[16] = a13;
  allocp[17] = a14;
  allocp[18] = a15;
  allocp[19] = (q)(struct goalrec*)&allocp[0];
  allocp[20] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[21] = a0;
  allocp[22] = x1 = makeref(&allocp[22]);
  allocp[23] = x0;
  qp = (struct goalrec*)&allocp[19];
  allocp += 24;
  proceed();
 apply__type__goals_16_ext_interrupt:
  reasonp = 0l;
 apply__type__goals_16_interrupt:
  goto interrupt_16;
 }

 apply__type__goals1_17_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  qp = qp->next;
 apply__type__goals1_17_clear_reason:
  reasonp = reasons;
 apply__type__goals1_17_0:
 apply__type__goals1_17_1:
  if (!isint(a0)) goto apply__type__goals1_17_3;
  gblt_greater(a0,makeint(0L),apply__type__goals1_17_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xapply__type__goals1_17);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x3 = makeref(&allocp[10]);
  allocp[11] = a9;
  allocp[12] = x4 = makeref(&allocp[12]);
  allocp[13] = a11;
  allocp[14] = x5 = makeref(&allocp[14]);
  allocp[15] = a13;
  allocp[16] = a14;
  allocp[17] = a15;
  allocp[18] = a16;
  allocp[19] = (q)(struct goalrec*)&allocp[0];
  allocp[20] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[21] = a0;
  allocp[22] = makeint(1L);
  allocp[23] = x0;
  allocp[24] = (q)(struct goalrec*)&allocp[19];
  allocp[25] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[26] = a0;
  allocp[27] = a1;
  allocp[28] = x6 = makeref(&allocp[28]);
  allocp[29] = x1;
  allocp[30] = (q)(struct goalrec*)&allocp[24];
  allocp[31] = (q)(&predicate_analyze__type_xapply__type__goal_17);
  allocp[32] = x7 = makeref(&allocp[32]);
  allocp[33] = x6;
  allocp[34] = a3;
  allocp[35] = a4;
  allocp[36] = a0;
  allocp[37] = a5;
  allocp[38] = a6;
  allocp[39] = x2;
  allocp[40] = a8;
  allocp[41] = x3;
  allocp[42] = a10;
  allocp[43] = x4;
  allocp[44] = a12;
  allocp[45] = x5;
  allocp[46] = a14;
  allocp[47] = a15;
  allocp[48] = a16;
  allocp[49] = (q)(struct goalrec*)&allocp[30];
  allocp[50] = (q)(&predicate_functor__table_xarg_3);
  allocp[51] = a0;
  allocp[52] = a1;
  allocp[53] = x7;
  qp = (struct goalrec*)&allocp[49];
  allocp += 54;
  proceed();
 apply__type__goals1_17_2:
  if (a0 != makeint(0L)) goto apply__type__goals1_17_interrupt;
  unify4(a2, a1, a7, a6, a9, a8, a11, a10);
  unify(a13, a12);
  proceed();
 apply__type__goals1_17_3:
  if (!isref(a0)) goto apply__type__goals1_17_interrupt;
  deref_and_jump(a0,apply__type__goals1_17_1);
  *reasonp++ =  a0;
  goto apply__type__goals1_17_interrupt;
 apply__type__goals1_17_ext_interrupt:
  reasonp = 0l;
 apply__type__goals1_17_interrupt:
  goto interrupt_17;
 }

 apply__type__goal_17_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  qp = qp->next;
 apply__type__goal_17_clear_reason:
  reasonp = reasons;
 apply__type__goal_17_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_parse__uty_xencode__goal_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a1;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_analyze__type_xapply__type__goal1_19);
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = x0;
  allocp[10] = x1;
  allocp[11] = x2;
  allocp[12] = a2;
  allocp[13] = a3;
  allocp[14] = a4;
  allocp[15] = a5;
  allocp[16] = a6;
  allocp[17] = a7;
  allocp[18] = a8;
  allocp[19] = a9;
  allocp[20] = a10;
  allocp[21] = a11;
  allocp[22] = a12;
  allocp[23] = a13;
  allocp[24] = a14;
  allocp[25] = a15;
  allocp[26] = a16;
  allocp[27] = (q)(struct goalrec*)&allocp[6];
  allocp[28] = (q)(&predicate_parse__uty_xdecode__goal_4);
  allocp[29] = a0;
  allocp[30] = x3;
  allocp[31] = x1;
  allocp[32] = x2;
  qp = (struct goalrec*)&allocp[27];
  allocp += 33;
  proceed();
 apply__type__goal_17_ext_interrupt:
  reasonp = 0l;
 apply__type__goal_17_interrupt:
  toppred = &predicate_analyze__type_xapply__type__goal_17;
  goto interrupt_17;
 }

 apply__type__goal1_19_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  a18 = qp->args[18];
  qp = qp->next;
 apply__type__goal1_19_clear_reason:
  reasonp = reasons;
 apply__type__goal1_19_0:
 apply__type__goal1_19_1:
  switch (ptagof(a4)) {
 case FUNCTOR:
  if (functor_of(a4) != makesym(functor_var_5)) goto apply__type__goal1_19_19;
  x0 = arg(a4, 0);
 apply__type__goal1_19_2:
  if (isref(x0)) goto apply__type__goal1_19_18;
 apply__type__goal1_19_3:
  if (isref(x0)) goto apply__type__goal1_19_17;
  if_not_equal(x0, a17, apply__type__goal1_19_19);
  x1 = arg(a4, 1);
 apply__type__goal1_19_4:
  if (isref(x1)) goto apply__type__goal1_19_16;
 apply__type__goal1_19_5:
  if (isref(x1)) goto apply__type__goal1_19_15;
  if_not_equal(x1, a18, apply__type__goal1_19_19);
  x2 = arg(a4, 2);
 apply__type__goal1_19_6:
  if (isref(x2)) goto apply__type__goal1_19_14;
 apply__type__goal1_19_7:
  if (isref(x2)) goto apply__type__goal1_19_13;
  if_not_equal(x2, a7, apply__type__goal1_19_19);
  x3 = arg(a4, 3);
 apply__type__goal1_19_8:
  if (isref(x3)) goto apply__type__goal1_19_12;
 apply__type__goal1_19_9:
  if (isref(x3)) goto apply__type__goal1_19_11;
  if_not_equal(x3, a6, apply__type__goal1_19_19);
  x4 = arg(a4, 4);
 apply__type__goal1_19_10:
  switch (ptagof(x4)) {
 case FUNCTOR:
  if (functor_of(x4) != makesym(functor_variable_3)) goto apply__type__goal1_19_19;
  unify4(a1, a0, a9, a8, a11, a10, a13, a12);
  unify(a15, a14);
  proceed();
 case VARREF:
  deref_and_jump(x4,apply__type__goal1_19_10);
  *reasonp++ =  x4;
  goto apply__type__goal1_19_19;
  };
  goto apply__type__goal1_19_19;
 apply__type__goal1_19_11:
  deref_and_jump(x3,apply__type__goal1_19_9);
  *reasonp++ =  x3;
  goto apply__type__goal1_19_19;
 apply__type__goal1_19_12:
  deref_and_jump(x3,apply__type__goal1_19_8);
  *reasonp++ =  x3;
  goto apply__type__goal1_19_19;
 apply__type__goal1_19_13:
  deref_and_jump(x2,apply__type__goal1_19_7);
  *reasonp++ =  x2;
  goto apply__type__goal1_19_19;
 apply__type__goal1_19_14:
  deref_and_jump(x2,apply__type__goal1_19_6);
  *reasonp++ =  x2;
  goto apply__type__goal1_19_19;
 apply__type__goal1_19_15:
  deref_and_jump(x1,apply__type__goal1_19_5);
  *reasonp++ =  x1;
  goto apply__type__goal1_19_19;
 apply__type__goal1_19_16:
  deref_and_jump(x1,apply__type__goal1_19_4);
  *reasonp++ =  x1;
  goto apply__type__goal1_19_19;
 apply__type__goal1_19_17:
  deref_and_jump(x0,apply__type__goal1_19_3);
  *reasonp++ =  x0;
  goto apply__type__goal1_19_19;
 apply__type__goal1_19_18:
  deref_and_jump(x0,apply__type__goal1_19_2);
  *reasonp++ =  x0;
  goto apply__type__goal1_19_19;
 case VARREF:
  deref_and_jump(a4,apply__type__goal1_19_1);
  *reasonp++ =  a4;
  goto apply__type__goal1_19_19;
  };
  goto apply__type__goal1_19_19;
 apply__type__goal1_19_19:
  otherwise(apply__type__goal1_19_interrupt);
 apply__type__goal1_19_20:
  switch (ptagof(a4)) {
 case FUNCTOR:
  if (functor_of(a4) != makesym(functor_var_5)) goto apply__type__goal1_19_interrupt;
  x0 = arg(a4, 4);
 apply__type__goal1_19_21:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_variable_3)) goto apply__type__goal1_19_interrupt;
 apply__type__goal1_19_22:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_attrs_2)) goto apply__type__goal1_19_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xapply__type__goal2_20);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a18;
  allocp[5] = a7;
  allocp[6] = a6;
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = a1;
  allocp[9] = a3;
  allocp[10] = a16;
  allocp[11] = a4;
  allocp[12] = a5;
  x4 = arg(a2, 1);
  allocp[13] = x4;
  allocp[14] = a8;
  allocp[15] = a9;
  allocp[16] = a10;
  allocp[17] = a11;
  allocp[18] = a12;
  allocp[19] = a13;
  allocp[20] = x5 = makeref(&allocp[20]);
  allocp[21] = a15;
  allocp[22] = (q)(struct goalrec*)&allocp[0];
  allocp[23] = (q)(&predicate_analyze__type_xget__call__modulename_3);
  allocp[24] = a3;
  allocp[25] = a17;
  allocp[26] = x2;
  allocp[27] = (q)(struct goalrec*)&allocp[22];
  allocp[28] = (q)(&predicate_mode_xdetermine__goal__mode_6);
  allocp[29] = a0;
  allocp[30] = x3;
  allocp[31] = a7;
  x6 = arg(x0, 0);
  allocp[32] = x6;
  allocp[33] = a14;
  allocp[34] = x5;
  a0 = x6;
  a1 = arg(a2, 0);
  a2 = x1;
  qp = (struct goalrec*)&allocp[27];
  allocp += 35;
  execute(check__waits_3_0);
  goto check__waits_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,apply__type__goal1_19_22);
  *reasonp++ =  a2;
  goto apply__type__goal1_19_interrupt;
  };
  goto apply__type__goal1_19_interrupt;
 case VARREF:
  deref_and_jump(x0,apply__type__goal1_19_21);
  *reasonp++ =  x0;
  goto apply__type__goal1_19_interrupt;
  };
  goto apply__type__goal1_19_interrupt;
 case VARREF:
  deref_and_jump(a4,apply__type__goal1_19_20);
  *reasonp++ =  a4;
  goto apply__type__goal1_19_interrupt;
  };
  goto apply__type__goal1_19_interrupt;
 apply__type__goal1_19_ext_interrupt:
  reasonp = 0l;
 apply__type__goal1_19_interrupt:
  goto interrupt_19;
 }

 apply__type__goal2_20_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  a18 = qp->args[18];
  a19 = qp->args[19];
  qp = qp->next;
 apply__type__goal2_20_clear_reason:
  reasonp = reasons;
 apply__type__goal2_20_0:
 apply__type__goal2_20_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto apply__type__goal2_20_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_no)):
  unify4(a6, a5, a12, a13, a14, a15, a16, a17);
  unify(a18, a19);
  proceed();
 case symval(makesym(atom_yes)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xbuiltin__type_21);
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  allocp[5] = a4;
  allocp[6] = x0 = makeref(&allocp[6]);
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = a9;
  allocp[9] = a10;
  allocp[10] = a5;
  allocp[11] = a6;
  allocp[12] = a7;
  allocp[13] = a8;
  allocp[14] = a11;
  allocp[15] = a12;
  allocp[16] = a13;
  allocp[17] = a14;
  allocp[18] = a15;
  allocp[19] = a16;
  allocp[20] = a17;
  allocp[21] = a18;
  allocp[22] = a19;
  allocp[23] = (q)(struct goalrec*)&allocp[0];
  allocp[24] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[25] = a5;
  allocp[26] = x0;
  allocp[27] = x1;
  qp = (struct goalrec*)&allocp[23];
  allocp += 28;
  proceed();
  };
  goto apply__type__goal2_20_interrupt;
 case VARREF:
  deref_and_jump(a0,apply__type__goal2_20_1);
  *reasonp++ =  a0;
  goto apply__type__goal2_20_interrupt;
  };
  goto apply__type__goal2_20_interrupt;
 apply__type__goal2_20_ext_interrupt:
  reasonp = 0l;
 apply__type__goal2_20_interrupt:
  goto interrupt_20;
 }

 check__waits_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 check__waits_3_clear_reason:
  reasonp = reasons;
 check__waits_3_0:
 check__waits_3_1:
  if (!isint(a0)) goto check__waits_3_5;
  gblt_add(a0,makeint(1L),x0,check__waits_3_6);
 check__waits_3_2:
  if (isref(a1)) goto check__waits_3_4;
  gblt_arg(x0,a1,x1,check__waits_3_6);
 check__waits_3_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom___)) goto check__waits_3_6;
  unify_value(a2, makesym(atom_no));
  proceed();
 case VARREF:
  deref_and_jump(x1,check__waits_3_3);
  *reasonp++ =  x1;
  goto check__waits_3_6;
  };
  goto check__waits_3_6;
 check__waits_3_4:
  deref_and_jump(a1,check__waits_3_2);
  *reasonp++ =  a1;
  goto check__waits_3_6;
 check__waits_3_5:
  if (!isref(a0)) goto check__waits_3_6;
  deref_and_jump(a0,check__waits_3_1);
  *reasonp++ =  a0;
  goto check__waits_3_6;
 check__waits_3_6:
  otherwise(check__waits_3_interrupt);
  unify_value(a2, makesym(atom_yes));
  proceed();
 check__waits_3_ext_interrupt:
  reasonp = 0l;
 check__waits_3_interrupt:
  toppred = &predicate_analyze__type_xcheck__waits_3;
  goto interrupt_3;
 }

 get__call__modulename_3_top: {
  q x0;
  a2 = qp->args[2];
  qp = qp->next;
 get__call__modulename_3_clear_reason:
  reasonp = reasons;
 get__call__modulename_3_0:
 get__call__modulename_3_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_options_2)) goto get__call__modulename_3_3;
  x0 = arg(a0, 0);
 get__call__modulename_3_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (isint(x0)) goto get__call__modulename_3_3;
  switch (symval(x0)) {
 case symval(makesym(atom___)):
  unify(a2, a1);
  proceed();
 case symval(makesym(atom_builtin)):
  unify(a2, a1);
  proceed();
 case symval(makesym(atom_io)):
  unify(a2, a1);
  proceed();
 case symval(makesym(atom_functor__table)):
  unify(a2, a1);
  proceed();
  };
  goto get__call__modulename_3_3;
 case VARREF:
  deref_and_jump(x0,get__call__modulename_3_2);
  *reasonp++ =  x0;
  goto get__call__modulename_3_3;
  };
  goto get__call__modulename_3_3;
 case VARREF:
  deref_and_jump(a0,get__call__modulename_3_1);
  *reasonp++ =  a0;
  goto get__call__modulename_3_3;
  };
  goto get__call__modulename_3_3;
 get__call__modulename_3_3:
  otherwise(get__call__modulename_3_interrupt);
 get__call__modulename_3_4:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_options_2)) goto get__call__modulename_3_interrupt;
  x0 = arg(a0, 0);
  unify(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,get__call__modulename_3_4);
  *reasonp++ =  a0;
  goto get__call__modulename_3_interrupt;
  };
  goto get__call__modulename_3_interrupt;
 get__call__modulename_3_ext_interrupt:
  reasonp = 0l;
 get__call__modulename_3_interrupt:
  goto interrupt_3;
 }

 builtin__type_21_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  a18 = qp->args[18];
  a19 = qp->args[19];
  a20 = qp->args[20];
  qp = qp->next;
 builtin__type_21_clear_reason:
  reasonp = reasons;
 builtin__type_21_0:
 builtin__type_21_1:
  switch (ptagof(a4)) {
 case ATOMIC:
  if (isint(a4)) goto builtin__type_21_14;
  switch (symval(a4)) {
 case symval(makesym(atom__3D)):
 builtin__type_21_2:
  switch (ptagof(a5)) {
 case ATOMIC:
 builtin__type_21_3:
  if (a5 != makeint(2L)) goto builtin__type_21_14;
 builtin__type_21_4:
  switch (ptagof(a12)) {
 case ATOMIC:
  if (a12 != makesym(atom_builtin)) goto builtin__type_21_14;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = makeint(2L);
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a9;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[8] = makeint(1L);
  allocp[9] = a8;
  allocp[10] = x2 = makeref(&allocp[10]);
  allocp[11] = x0;
  allocp[12] = (q)(struct goalrec*)&allocp[6];
  allocp[13] = (q)(&predicate_analyze__type_xbuiltin__type__unify_18);
  allocp[14] = x3 = makeref(&allocp[14]);
  allocp[15] = x4 = makeref(&allocp[15]);
  allocp[16] = x2;
  allocp[17] = x1;
  allocp[18] = x5 = makeref(&allocp[18]);
  allocp[19] = a7;
  allocp[20] = a0;
  allocp[21] = a1;
  allocp[22] = a2;
  allocp[23] = a3;
  allocp[24] = a13;
  allocp[25] = a14;
  allocp[26] = a15;
  allocp[27] = a16;
  allocp[28] = a17;
  allocp[29] = a18;
  allocp[30] = a19;
  allocp[31] = a20;
  allocp[32] = makesym(functor_variable_3);
  allocp[33] = x5;
  allocp[34] = x7 = makeref(&allocp[34]);
  allocp[35] = x8 = makeref(&allocp[35]);
  x6 = makefunctor(&allocp[32]);
  allocp[36] = makesym(functor_var_5);
  allocp[37] = x10 = makeref(&allocp[37]);
  allocp[38] = x11 = makeref(&allocp[38]);
  allocp[39] = x12 = makeref(&allocp[39]);
  allocp[40] = x13 = makeref(&allocp[40]);
  allocp[41] = x6;
  x9 = makefunctor(&allocp[36]);
  qp = (struct goalrec*)&allocp[12];
  allocp += 42;
  unify_value(a6, x9);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a8;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a8;
  allocp[9] = x3;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a12,builtin__type_21_4);
  *reasonp++ =  a12;
  goto builtin__type_21_14;
  };
  goto builtin__type_21_14;
 case VARREF:
  deref_and_jump(a5,builtin__type_21_2);
  *reasonp++ =  a5;
  goto builtin__type_21_14;
  };
  goto builtin__type_21_14;
 case symval(makesym(atom_new__functor)):
 builtin__type_21_5:
  switch (ptagof(a5)) {
 case ATOMIC:
 builtin__type_21_6:
  if (a5 != makeint(3L)) goto builtin__type_21_14;
 builtin__type_21_7:
  switch (ptagof(a12)) {
 case ATOMIC:
  if (a12 != makesym(atom_builtin)) goto builtin__type_21_14;
  unify2(a20, a19, a9, a8);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xset__types_13);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x0 = makeref(&allocp[6]);
  allocp[7] = makesym(atom_o);
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a15;
  allocp[10] = a16;
  allocp[11] = a13;
  allocp[12] = a14;
  allocp[13] = a17;
  allocp[14] = a18;
  allocp[15] = makesym(functor_goal_4);
  allocp[16] = a0;
  allocp[17] = a1;
  allocp[18] = a3;
  allocp[19] = a2;
  x2 = makefunctor(&allocp[15]);
  allocp[20] = (q)(struct goalrec*)&allocp[0];
  allocp[21] = (q)(&predicate_builtin__type_xupdate__type__new__functor_4);
  allocp[22] = x3 = makeref(&allocp[22]);
  allocp[23] = x4 = makeref(&allocp[23]);
  allocp[24] = x1;
  allocp[25] = x2;
  allocp[26] = (q)(struct goalrec*)&allocp[20];
  allocp[27] = (q)(&predicate_type_xtype2int_2);
  allocp[28] = x5 = makeref(&allocp[28]);
  allocp[29] = x4;
  allocp[30] = (q)(struct goalrec*)&allocp[26];
  allocp[31] = (q)(&predicate_type_xtype2atom_2);
  allocp[32] = x6 = makeref(&allocp[32]);
  allocp[33] = x3;
  allocp[34] = (q)(struct goalrec*)&allocp[30];
  allocp[35] = (q)(&predicate_type_xget__arg__types_5);
  allocp[36] = a0;
  allocp[37] = a1;
  allocp[38] = x7 = makeref(&allocp[38]);
  allocp[39] = a15;
  allocp[40] = x5;
  allocp[41] = (q)(struct goalrec*)&allocp[34];
  allocp[42] = (q)(&predicate_type_xget__arg__types_5);
  allocp[43] = a0;
  allocp[44] = a1;
  allocp[45] = x8 = makeref(&allocp[45]);
  allocp[46] = a15;
  allocp[47] = x6;
  allocp[48] = (q)(struct goalrec*)&allocp[41];
  allocp[49] = (q)(&predicate_functor__table_xarg_3);
  allocp[50] = makeint(3L);
  allocp[51] = a8;
  allocp[52] = x7;
  allocp[53] = (q)(struct goalrec*)&allocp[48];
  allocp[54] = (q)(&predicate_functor__table_xarg_3);
  allocp[55] = makeint(2L);
  allocp[56] = a8;
  allocp[57] = x8;
  allocp[58] = (q)(struct goalrec*)&allocp[53];
  allocp[59] = (q)(&predicate_functor__table_xarg_3);
  allocp[60] = makeint(1L);
  allocp[61] = a8;
  allocp[62] = x0;
  qp = (struct goalrec*)&allocp[58];
  allocp += 63;
  proceed();
 case VARREF:
  deref_and_jump(a12,builtin__type_21_7);
  *reasonp++ =  a12;
  goto builtin__type_21_14;
  };
  goto builtin__type_21_14;
 case VARREF:
  deref_and_jump(a5,builtin__type_21_5);
  *reasonp++ =  a5;
  goto builtin__type_21_14;
  };
  goto builtin__type_21_14;
 case symval(makesym(atom_arg)):
 builtin__type_21_8:
  switch (ptagof(a5)) {
 case ATOMIC:
 builtin__type_21_9:
  if (a5 != makeint(3L)) goto builtin__type_21_14;
 builtin__type_21_10:
  switch (ptagof(a12)) {
 case ATOMIC:
  if (a12 != makesym(atom_builtin)) goto builtin__type_21_14;
  unify2(a20, a19, a9, a8);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xset__types_13);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x0 = makeref(&allocp[6]);
  allocp[7] = makesym(atom_o);
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a15;
  allocp[10] = a16;
  allocp[11] = a13;
  allocp[12] = a14;
  allocp[13] = a17;
  allocp[14] = a18;
  allocp[15] = makesym(functor_goal_4);
  allocp[16] = a0;
  allocp[17] = a1;
  allocp[18] = a3;
  allocp[19] = a2;
  x2 = makefunctor(&allocp[15]);
  allocp[20] = (q)(struct goalrec*)&allocp[0];
  allocp[21] = (q)(&predicate_builtin__type_xupdate__type__arg_4);
  allocp[22] = x3 = makeref(&allocp[22]);
  allocp[23] = x4 = makeref(&allocp[23]);
  allocp[24] = x1;
  allocp[25] = x2;
  allocp[26] = (q)(struct goalrec*)&allocp[20];
  allocp[27] = (q)(&predicate_type_xtype2int_2);
  allocp[28] = x5 = makeref(&allocp[28]);
  allocp[29] = x3;
  allocp[30] = (q)(struct goalrec*)&allocp[26];
  allocp[31] = (q)(&predicate_type_xget__arg__types_5);
  allocp[32] = a0;
  allocp[33] = a1;
  allocp[34] = x6 = makeref(&allocp[34]);
  allocp[35] = a15;
  allocp[36] = x4;
  allocp[37] = (q)(struct goalrec*)&allocp[30];
  allocp[38] = (q)(&predicate_type_xget__arg__types_5);
  allocp[39] = a0;
  allocp[40] = a1;
  allocp[41] = x7 = makeref(&allocp[41]);
  allocp[42] = a15;
  allocp[43] = x5;
  allocp[44] = (q)(struct goalrec*)&allocp[37];
  allocp[45] = (q)(&predicate_functor__table_xarg_3);
  allocp[46] = makeint(3L);
  allocp[47] = a8;
  allocp[48] = x0;
  allocp[49] = (q)(struct goalrec*)&allocp[44];
  allocp[50] = (q)(&predicate_functor__table_xarg_3);
  allocp[51] = makeint(2L);
  allocp[52] = a8;
  allocp[53] = x6;
  allocp[54] = (q)(struct goalrec*)&allocp[49];
  allocp[55] = (q)(&predicate_functor__table_xarg_3);
  allocp[56] = makeint(1L);
  allocp[57] = a8;
  allocp[58] = x7;
  qp = (struct goalrec*)&allocp[54];
  allocp += 59;
  proceed();
 case VARREF:
  deref_and_jump(a12,builtin__type_21_10);
  *reasonp++ =  a12;
  goto builtin__type_21_14;
  };
  goto builtin__type_21_14;
 case VARREF:
  deref_and_jump(a5,builtin__type_21_8);
  *reasonp++ =  a5;
  goto builtin__type_21_14;
  };
  goto builtin__type_21_14;
 case symval(makesym(atom_setarg)):
 builtin__type_21_11:
  switch (ptagof(a5)) {
 case ATOMIC:
 builtin__type_21_12:
  if (a5 != makeint(4L)) goto builtin__type_21_14;
 builtin__type_21_13:
  switch (ptagof(a12)) {
 case ATOMIC:
  if (a12 != makesym(atom_builtin)) goto builtin__type_21_14;
  unify2(a20, a19, a9, a8);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xset__types_13);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x0 = makeref(&allocp[6]);
  allocp[7] = makesym(atom_o);
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a15;
  allocp[10] = a16;
  allocp[11] = a13;
  allocp[12] = a14;
  allocp[13] = a17;
  allocp[14] = a18;
  allocp[15] = makesym(functor_goal_4);
  allocp[16] = a0;
  allocp[17] = a1;
  allocp[18] = a3;
  allocp[19] = a2;
  x2 = makefunctor(&allocp[15]);
  allocp[20] = (q)(struct goalrec*)&allocp[0];
  allocp[21] = (q)(&predicate_builtin__type_xupdate__type__setarg_6);
  allocp[22] = x3 = makeref(&allocp[22]);
  allocp[23] = x4 = makeref(&allocp[23]);
  allocp[24] = x5 = makeref(&allocp[24]);
  allocp[25] = x1;
  allocp[26] = x6 = makeref(&allocp[26]);
  allocp[27] = x2;
  allocp[28] = (q)(struct goalrec*)&allocp[20];
  allocp[29] = (q)(&predicate_type_xtype2int_2);
  allocp[30] = x7 = makeref(&allocp[30]);
  allocp[31] = x3;
  allocp[32] = (q)(struct goalrec*)&allocp[28];
  allocp[33] = (q)(&predicate_type_xget__arg__types_5);
  allocp[34] = a0;
  allocp[35] = a1;
  allocp[36] = x8 = makeref(&allocp[36]);
  allocp[37] = a15;
  allocp[38] = x5;
  allocp[39] = (q)(struct goalrec*)&allocp[32];
  allocp[40] = (q)(&predicate_type_xget__arg__types_5);
  allocp[41] = a0;
  allocp[42] = a1;
  allocp[43] = x9 = makeref(&allocp[43]);
  allocp[44] = a15;
  allocp[45] = x4;
  allocp[46] = (q)(struct goalrec*)&allocp[39];
  allocp[47] = (q)(&predicate_type_xget__arg__types_5);
  allocp[48] = a0;
  allocp[49] = a1;
  allocp[50] = x10 = makeref(&allocp[50]);
  allocp[51] = a15;
  allocp[52] = x7;
  allocp[53] = (q)(struct goalrec*)&allocp[46];
  allocp[54] = (q)(&predicate_functor__table_xarg_3);
  allocp[55] = makeint(4L);
  allocp[56] = a8;
  allocp[57] = x0;
  allocp[58] = (q)(struct goalrec*)&allocp[53];
  allocp[59] = (q)(&predicate_functor__table_xarg_3);
  allocp[60] = makeint(3L);
  allocp[61] = a8;
  allocp[62] = x8;
  allocp[63] = (q)(struct goalrec*)&allocp[58];
  allocp[64] = (q)(&predicate_functor__table_xarg_3);
  allocp[65] = makeint(2L);
  allocp[66] = a8;
  allocp[67] = x9;
  allocp[68] = (q)(struct goalrec*)&allocp[63];
  allocp[69] = (q)(&predicate_functor__table_xarg_3);
  allocp[70] = makeint(1L);
  allocp[71] = a8;
  allocp[72] = x10;
  qp = (struct goalrec*)&allocp[68];
  allocp += 73;
  proceed();
 case VARREF:
  deref_and_jump(a12,builtin__type_21_13);
  *reasonp++ =  a12;
  goto builtin__type_21_14;
  };
  goto builtin__type_21_14;
 case VARREF:
  deref_and_jump(a5,builtin__type_21_11);
  *reasonp++ =  a5;
  goto builtin__type_21_14;
  };
  goto builtin__type_21_14;
  };
  goto builtin__type_21_14;
 case VARREF:
  deref_and_jump(a4,builtin__type_21_1);
  *reasonp++ =  a4;
  goto builtin__type_21_14;
  };
  goto builtin__type_21_14;
 builtin__type_21_14:
  otherwise(builtin__type_21_interrupt);
 builtin__type_21_15:
  switch (ptagof(a12)) {
 case ATOMIC:
  if (a12 != makesym(atom_builtin)) goto builtin__type_21_16;
  unify4(a9, a8, a14, a13, a16, a15, a18, a17);
  unify(a20, a19);
  proceed();
 case VARREF:
  deref_and_jump(a12,builtin__type_21_15);
  *reasonp++ =  a12;
  goto builtin__type_21_16;
  };
  goto builtin__type_21_16;
 builtin__type_21_16:
  otherwise(builtin__type_21_interrupt);
 builtin__type_21_17:
  switch (ptagof(a12)) {
 case ATOMIC:
  if (a12 != makesym(atom_userdef)) goto builtin__type_21_interrupt;
  allocp[0] = makesym(functor_variable_3);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  x0 = makefunctor(&allocp[0]);
  allocp[4] = makesym(functor_var_5);
  allocp[5] = x5 = makeref(&allocp[5]);
  allocp[6] = x6 = makeref(&allocp[6]);
  allocp[7] = x7 = makeref(&allocp[7]);
  allocp[8] = x8 = makeref(&allocp[8]);
  allocp[9] = x0;
  x4 = makefunctor(&allocp[4]);
  allocp += 10;
  unify_value(a6, x4);
  unify4(a9, a8, a16, a15, a18, a17, a20, a19);
  x9 = a8;
  a1 = x1;
  a2 = a0;
  a3 = a4;
  a4 = a5;
  a5 = a10;
  a6 = x5;
  a7 = x6;
  a8 = a13;
  a9 = a14;
  a0 = x9;
  execute(builtin__type__userdef_10_0);
  goto builtin__type__userdef_10_ext_interrupt;
 case VARREF:
  deref_and_jump(a12,builtin__type_21_17);
  *reasonp++ =  a12;
  goto builtin__type_21_interrupt;
  };
  goto builtin__type_21_interrupt;
 builtin__type_21_ext_interrupt:
  reasonp = 0l;
 builtin__type_21_interrupt:
  goto interrupt_21;
 }

 builtin__type__userdef_10_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 builtin__type__userdef_10_clear_reason:
  reasonp = reasons;
 builtin__type__userdef_10_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xbuiltin__type__userdef1_11);
  allocp[2] = a4;
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = a8;
  allocp[12] = a9;
  allocp[13] = (q)(struct goalrec*)&allocp[0];
  allocp[14] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[15] = a0;
  allocp[16] = x0 = makeref(&allocp[16]);
  allocp[17] = a4;
  qp = (struct goalrec*)&allocp[13];
  allocp += 18;
  proceed();
 builtin__type__userdef_10_ext_interrupt:
  reasonp = 0l;
 builtin__type__userdef_10_interrupt:
  toppred = &predicate_analyze__type_xbuiltin__type__userdef_10;
  goto interrupt_10;
 }

 builtin__type__userdef1_11_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 builtin__type__userdef1_11_clear_reason:
  reasonp = reasons;
 builtin__type__userdef1_11_0:
 builtin__type__userdef1_11_1:
  if (!isint(a0)) goto builtin__type__userdef1_11_9;
  gblt_greater(a0,makeint(0L),builtin__type__userdef1_11_10);
 builtin__type__userdef1_11_2:
  if (isref(a1)) goto builtin__type__userdef1_11_8;
  gblt_arg(a0,a1,x0,builtin__type__userdef1_11_10);
 builtin__type__userdef1_11_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_variable_3)) goto builtin__type__userdef1_11_10;
  x1 = arg(x0, 0);
 builtin__type__userdef1_11_4:
  if (isref(x1)) goto builtin__type__userdef1_11_7;
 builtin__type__userdef1_11_5:
  if (isref(x1)) goto builtin__type__userdef1_11_6;
  if_not_equal(x1, a2, builtin__type__userdef1_11_10);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xbuiltin__type__userdef1_11);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = x3 = makeref(&allocp[11]);
  allocp[12] = a10;
  allocp[13] = (q)(struct goalrec*)&allocp[0];
  allocp[14] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[15] = a0;
  allocp[16] = makeint(1L);
  allocp[17] = x2;
  allocp[18] = makesym(functor_variable_3);
  allocp[19] = a2;
  allocp[20] = arg(x0, 1);
  allocp[21] = arg(x0, 2);
  x4 = makefunctor(&allocp[18]);
  allocp[22] = makesym(functor_userdef_7);
  allocp[23] = a3;
  allocp[24] = a4;
  allocp[25] = a5;
  allocp[26] = a0;
  allocp[27] = a7;
  allocp[28] = a8;
  allocp[29] = x4;
  x5 = makefunctor(&allocp[22]);
  allocp[30] = NILATOM;
  allocp[31] = x5;
  x6 = makecons(&allocp[30]);
  allocp[32] = (q)(struct goalrec*)&allocp[13];
  allocp[33] = (q)(&predicate_list_xappend_3);
  allocp[34] = a9;
  allocp[35] = x6;
  allocp[36] = x3;
  qp = (struct goalrec*)&allocp[32];
  allocp += 37;
  proceed();
 builtin__type__userdef1_11_6:
  deref_and_jump(x1,builtin__type__userdef1_11_5);
  *reasonp++ =  x1;
  goto builtin__type__userdef1_11_10;
 builtin__type__userdef1_11_7:
  deref_and_jump(x1,builtin__type__userdef1_11_4);
  *reasonp++ =  x1;
  goto builtin__type__userdef1_11_10;
 case VARREF:
  deref_and_jump(x0,builtin__type__userdef1_11_3);
  *reasonp++ =  x0;
  goto builtin__type__userdef1_11_10;
  };
  goto builtin__type__userdef1_11_10;
 builtin__type__userdef1_11_8:
  deref_and_jump(a1,builtin__type__userdef1_11_2);
  *reasonp++ =  a1;
  goto builtin__type__userdef1_11_10;
 builtin__type__userdef1_11_9:
  if (!isref(a0)) goto builtin__type__userdef1_11_10;
  deref_and_jump(a0,builtin__type__userdef1_11_1);
  *reasonp++ =  a0;
  goto builtin__type__userdef1_11_10;
 builtin__type__userdef1_11_10:
  otherwise(builtin__type__userdef1_11_interrupt);
 builtin__type__userdef1_11_11:
  if (!isint(a0)) goto builtin__type__userdef1_11_13;
  gblt_greater(a0,makeint(0L),builtin__type__userdef1_11_12);
  bblt_sub_no_check(a0,makeint(1L),x0);
  a0 = x0;
  execute(builtin__type__userdef1_11_0);
  goto builtin__type__userdef1_11_ext_interrupt;
 builtin__type__userdef1_11_12:
  if (a0 != makeint(0L)) goto builtin__type__userdef1_11_interrupt;
  unify(a10, a9);
  proceed();
 builtin__type__userdef1_11_13:
  if (!isref(a0)) goto builtin__type__userdef1_11_interrupt;
  deref_and_jump(a0,builtin__type__userdef1_11_11);
  *reasonp++ =  a0;
  goto builtin__type__userdef1_11_interrupt;
 builtin__type__userdef1_11_ext_interrupt:
  reasonp = 0l;
 builtin__type__userdef1_11_interrupt:
  goto interrupt_11;
 }

 builtin__type__unify_18_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  qp = qp->next;
 builtin__type__unify_18_clear_reason:
  reasonp = reasons;
 builtin__type__unify_18_0:
 builtin__type__unify_18_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_variable_3)) goto builtin__type__unify_18_7;
  x0 = arg(a0, 0);
 builtin__type__unify_18_2:
  if (isref(x0)) goto builtin__type__unify_18_6;
 builtin__type__unify_18_3:
  if (isref(x0)) goto builtin__type__unify_18_5;
  if_not_equal(x0, a4, builtin__type__unify_18_7);
  x1 = arg(a0, 2);
 builtin__type__unify_18_4:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_i)) goto builtin__type__unify_18_7;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xset__types_13);
  allocp[2] = a6;
  allocp[3] = a7;
  allocp[4] = a8;
  allocp[5] = a9;
  allocp[6] = a3;
  allocp[7] = makesym(atom_o);
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = a12;
  allocp[10] = a13;
  allocp[11] = a10;
  allocp[12] = a11;
  allocp[13] = x3 = makeref(&allocp[13]);
  allocp[14] = a15;
  allocp[15] = (q)(struct goalrec*)&allocp[0];
  allocp[16] = (q)(&predicate_analyze__type_xmake__arg__types_13);
  allocp[17] = a6;
  allocp[18] = a7;
  allocp[19] = a9;
  allocp[20] = a8;
  allocp[21] = a12;
  allocp[22] = a2;
  allocp[23] = a3;
  allocp[24] = makesym(atom_i);
  allocp[25] = makesym(atom_o);
  allocp[26] = x4 = makeref(&allocp[26]);
  allocp[27] = x2;
  allocp[28] = a14;
  allocp[29] = x3;
  qp = (struct goalrec*)&allocp[15];
  allocp += 30;
  unify_value(a2, a0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xset__arg__mode_6);
  allocp[2] = a1;
  allocp[3] = makesym(atom_o);
  allocp[4] = a8;
  allocp[5] = a3;
  allocp[6] = a16;
  allocp[7] = a17;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  proceed();
 case VARREF:
  deref_and_jump(x1,builtin__type__unify_18_4);
  *reasonp++ =  x1;
  goto builtin__type__unify_18_7;
  };
  goto builtin__type__unify_18_7;
 builtin__type__unify_18_5:
  deref_and_jump(x0,builtin__type__unify_18_3);
  *reasonp++ =  x0;
  goto builtin__type__unify_18_7;
 builtin__type__unify_18_6:
  deref_and_jump(x0,builtin__type__unify_18_2);
  *reasonp++ =  x0;
  goto builtin__type__unify_18_7;
 case VARREF:
  deref_and_jump(a0,builtin__type__unify_18_1);
  *reasonp++ =  a0;
  goto builtin__type__unify_18_7;
  };
  goto builtin__type__unify_18_7;
 builtin__type__unify_18_7:
  otherwise(builtin__type__unify_18_interrupt);
 builtin__type__unify_18_8:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_variable_3)) goto builtin__type__unify_18_14;
  x0 = arg(a1, 0);
 builtin__type__unify_18_9:
  if (isref(x0)) goto builtin__type__unify_18_13;
 builtin__type__unify_18_10:
  if (isref(x0)) goto builtin__type__unify_18_12;
  if_not_equal(x0, a4, builtin__type__unify_18_14);
  x1 = arg(a1, 2);
 builtin__type__unify_18_11:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_i)) goto builtin__type__unify_18_14;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xset__types_13);
  allocp[2] = a6;
  allocp[3] = a7;
  allocp[4] = a8;
  allocp[5] = a9;
  allocp[6] = a2;
  allocp[7] = makesym(atom_o);
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = a12;
  allocp[10] = a13;
  allocp[11] = a10;
  allocp[12] = a11;
  allocp[13] = x3 = makeref(&allocp[13]);
  allocp[14] = a15;
  allocp[15] = (q)(struct goalrec*)&allocp[0];
  allocp[16] = (q)(&predicate_analyze__type_xmake__arg__types_13);
  allocp[17] = a6;
  allocp[18] = a7;
  allocp[19] = a9;
  allocp[20] = a8;
  allocp[21] = a12;
  allocp[22] = a2;
  allocp[23] = a3;
  allocp[24] = makesym(atom_o);
  allocp[25] = makesym(atom_i);
  allocp[26] = x2;
  allocp[27] = x4 = makeref(&allocp[27]);
  allocp[28] = a14;
  allocp[29] = x3;
  qp = (struct goalrec*)&allocp[15];
  allocp += 30;
  unify_value(a3, a1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xset__arg__mode_6);
  allocp[2] = a0;
  allocp[3] = makesym(atom_o);
  allocp[4] = a8;
  allocp[5] = a2;
  allocp[6] = a16;
  allocp[7] = a17;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  proceed();
 case VARREF:
  deref_and_jump(x1,builtin__type__unify_18_11);
  *reasonp++ =  x1;
  goto builtin__type__unify_18_14;
  };
  goto builtin__type__unify_18_14;
 builtin__type__unify_18_12:
  deref_and_jump(x0,builtin__type__unify_18_10);
  *reasonp++ =  x0;
  goto builtin__type__unify_18_14;
 builtin__type__unify_18_13:
  deref_and_jump(x0,builtin__type__unify_18_9);
  *reasonp++ =  x0;
  goto builtin__type__unify_18_14;
 case VARREF:
  deref_and_jump(a1,builtin__type__unify_18_8);
  *reasonp++ =  a1;
  goto builtin__type__unify_18_14;
  };
  goto builtin__type__unify_18_14;
 builtin__type__unify_18_14:
  otherwise(builtin__type__unify_18_interrupt);
  unify4(a2, a0, a3, a1, a11, a10, a13, a12);
  unify2(a15, a14, a17, a16);
  proceed();
 builtin__type__unify_18_ext_interrupt:
  reasonp = 0l;
 builtin__type__unify_18_interrupt:
  goto interrupt_18;
 }

 make__arg__types_13_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  qp = qp->next;
 make__arg__types_13_clear_reason:
  reasonp = reasons;
 make__arg__types_13_0:
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_analyze__type_xadd__dep__goal_8);
  allocp[7] = a7;
  allocp[8] = a8;
  allocp[9] = x1 = makeref(&allocp[9]);
  allocp[10] = x2 = makeref(&allocp[10]);
  allocp[11] = a9;
  allocp[12] = a10;
  allocp[13] = x3 = makeref(&allocp[13]);
  allocp[14] = x0;
  allocp[15] = (q)(struct goalrec*)&allocp[5];
  allocp[16] = (q)(&predicate_type_xand__types_5);
  allocp[17] = x1;
  allocp[18] = x2;
  allocp[19] = x3;
  allocp[20] = a11;
  allocp[21] = a12;
  allocp[22] = (q)(struct goalrec*)&allocp[15];
  allocp[23] = (q)(&predicate_analyze__type_xget__arg__types_6);
  allocp[24] = a0;
  allocp[25] = a1;
  allocp[26] = a3;
  allocp[27] = a6;
  allocp[28] = a4;
  allocp[29] = x2;
  a2 = a3;
  a3 = a5;
  a5 = x1;
  qp = (struct goalrec*)&allocp[22];
  allocp += 30;
  execute(get__arg__types_6_0);
  goto get__arg__types_6_ext_interrupt;
 make__arg__types_13_ext_interrupt:
  reasonp = 0l;
 make__arg__types_13_interrupt:
  goto interrupt_13;
 }

 get__arg__types_6_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 get__arg__types_6_clear_reason:
  reasonp = reasons;
 get__arg__types_6_0:
 get__arg__types_6_1:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_guard)) goto get__arg__types_6_3;
 get__arg__types_6_2:
  switch (ptagof(a3)) {
 case FUNCTOR:
  if (functor_of(a3) != makesym(functor_variable_3)) goto get__arg__types_6_3;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xget__arg__types_5);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a3;
  allocp[5] = a4;
  allocp[6] = a5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  proceed();
 case VARREF:
  deref_and_jump(a3,get__arg__types_6_2);
  *reasonp++ =  a3;
  goto get__arg__types_6_3;
  };
  goto get__arg__types_6_3;
 case VARREF:
  deref_and_jump(a2,get__arg__types_6_1);
  *reasonp++ =  a2;
  goto get__arg__types_6_3;
  };
  goto get__arg__types_6_3;
 get__arg__types_6_3:
  otherwise(get__arg__types_6_interrupt);
 get__arg__types_6_4:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_guard)) goto get__arg__types_6_5;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xset__ru_3);
  allocp[2] = makesym(atom_r);
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a5;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_type_xget__arg__types_5);
  allocp[7] = a0;
  allocp[8] = a1;
  allocp[9] = a3;
  allocp[10] = a4;
  allocp[11] = x0;
  qp = (struct goalrec*)&allocp[5];
  allocp += 12;
  proceed();
 case VARREF:
  deref_and_jump(a2,get__arg__types_6_4);
  *reasonp++ =  a2;
  goto get__arg__types_6_5;
  };
  goto get__arg__types_6_5;
 get__arg__types_6_5:
  otherwise(get__arg__types_6_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xget__arg__types_5);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a3;
  allocp[5] = a4;
  allocp[6] = a5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  proceed();
 get__arg__types_6_ext_interrupt:
  reasonp = 0l;
 get__arg__types_6_interrupt:
  toppred = &predicate_analyze__type_xget__arg__types_6;
  goto interrupt_6;
 }

 add__dep__goal_8_top: {
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 add__dep__goal_8_clear_reason:
  reasonp = reasons;
 add__dep__goal_8_0:
 add__dep__goal_8_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto add__dep__goal_8_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_i)):
 add__dep__goal_8_2:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_o)) goto add__dep__goal_8_interrupt;
  unify(a4, a6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xadd__dep__goal_3);
  allocp[2] = a7;
  allocp[3] = a6;
  allocp[4] = a5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case VARREF:
  deref_and_jump(a1,add__dep__goal_8_2);
  *reasonp++ =  a1;
  goto add__dep__goal_8_interrupt;
  };
  goto add__dep__goal_8_interrupt;
 case symval(makesym(atom_o)):
 add__dep__goal_8_3:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_i)) goto add__dep__goal_8_interrupt;
  unify(a5, a6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xadd__dep__goal_3);
  allocp[2] = a7;
  allocp[3] = a6;
  allocp[4] = a4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case VARREF:
  deref_and_jump(a1,add__dep__goal_8_3);
  *reasonp++ =  a1;
  goto add__dep__goal_8_interrupt;
  };
  goto add__dep__goal_8_interrupt;
  };
  goto add__dep__goal_8_interrupt;
 case VARREF:
  deref_and_jump(a0,add__dep__goal_8_1);
  *reasonp++ =  a0;
  goto add__dep__goal_8_interrupt;
  };
  goto add__dep__goal_8_interrupt;
 add__dep__goal_8_ext_interrupt:
  reasonp = 0l;
 add__dep__goal_8_interrupt:
  goto interrupt_8;
 }

 interclause__modules_19_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  a18 = qp->args[18];
  qp = qp->next;
 interclause__modules_19_clear_reason:
  reasonp = reasons;
 interclause__modules_19_0:
 interclause__modules_19_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 interclause__modules_19_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto interclause__modules_19_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xinterclause__modules_19);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = x3 = makeref(&allocp[11]);
  allocp[12] = a10;
  allocp[13] = x4 = makeref(&allocp[13]);
  allocp[14] = a12;
  allocp[15] = x5 = makeref(&allocp[15]);
  allocp[16] = a14;
  allocp[17] = a15;
  allocp[18] = x6 = makeref(&allocp[18]);
  allocp[19] = a17;
  allocp[20] = a18;
  allocp[21] = makesym(functor_module_2);
  allocp[22] = arg(x0, 0);
  allocp[23] = x8 = makeref(&allocp[23]);
  x7 = makefunctor(&allocp[21]);
  allocp[24] = x2;
  allocp[25] = x7;
  x9 = makecons(&allocp[24]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 26;
  unify_value(a1, x9);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xinterclause__clauses_22);
  allocp[2] = makeint(1L);
  allocp[3] = x10 = makeref(&allocp[3]);
  x11 = arg(x0, 1);
  allocp[4] = x11;
  allocp[5] = x8;
  x12 = arg(x0, 0);
  allocp[6] = x12;
  allocp[7] = a2;
  allocp[8] = a3;
  allocp[9] = a4;
  allocp[10] = a5;
  allocp[11] = a6;
  allocp[12] = a7;
  allocp[13] = a8;
  allocp[14] = a9;
  allocp[15] = x3;
  allocp[16] = a11;
  allocp[17] = x4;
  allocp[18] = a13;
  allocp[19] = x5;
  allocp[20] = a15;
  allocp[21] = a16;
  allocp[22] = x6;
  allocp[23] = a18;
  allocp[24] = (q)(struct goalrec*)&allocp[0];
  allocp[25] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[26] = x11;
  allocp[27] = x13 = makeref(&allocp[27]);
  allocp[28] = x10;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(x0,interclause__modules_19_2);
  *reasonp++ =  x0;
  goto interclause__modules_19_interrupt;
  };
  goto interclause__modules_19_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto interclause__modules_19_interrupt;
  unify_value(a1, NILATOM);
  unify4(a10, a9, a12, a11, a14, a13, a17, a16);
  proceed();
 case VARREF:
  deref_and_jump(a0,interclause__modules_19_1);
  *reasonp++ =  a0;
  goto interclause__modules_19_interrupt;
  };
  goto interclause__modules_19_interrupt;
 interclause__modules_19_ext_interrupt:
  reasonp = 0l;
 interclause__modules_19_interrupt:
  goto interrupt_19;
 }

 interclause__clauses_22_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  a18 = qp->args[18];
  a19 = qp->args[19];
  a20 = qp->args[20];
  a21 = qp->args[21];
  qp = qp->next;
 interclause__clauses_22_clear_reason:
  reasonp = reasons;
 interclause__clauses_22_0:
 interclause__clauses_22_1:
  if (!isint(a0)) goto interclause__clauses_22_5;
 interclause__clauses_22_2:
  if (!isint(a1)) goto interclause__clauses_22_4;
  gblt_less_or_eq(a0,a1,interclause__clauses_22_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xinterclause__clauses_22);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  allocp[12] = a10;
  allocp[13] = a11;
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = a13;
  allocp[16] = x3 = makeref(&allocp[16]);
  allocp[17] = a15;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = a17;
  allocp[20] = a18;
  allocp[21] = x5 = makeref(&allocp[21]);
  allocp[22] = a20;
  allocp[23] = a21;
  allocp[24] = (q)(struct goalrec*)&allocp[0];
  allocp[25] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[26] = a0;
  allocp[27] = makeint(1L);
  allocp[28] = x0;
  allocp[29] = (q)(struct goalrec*)&allocp[24];
  allocp[30] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[31] = a0;
  allocp[32] = a2;
  allocp[33] = x6 = makeref(&allocp[33]);
  allocp[34] = x1;
  allocp[35] = (q)(struct goalrec*)&allocp[29];
  allocp[36] = (q)(&predicate_analyze__type_xinterclause__clause_22);
  allocp[37] = x7 = makeref(&allocp[37]);
  allocp[38] = x6;
  allocp[39] = a4;
  allocp[40] = a0;
  allocp[41] = a4;
  allocp[42] = a5;
  allocp[43] = a6;
  allocp[44] = a7;
  allocp[45] = a8;
  allocp[46] = a9;
  allocp[47] = a10;
  allocp[48] = a11;
  allocp[49] = a12;
  allocp[50] = x2;
  allocp[51] = a14;
  allocp[52] = x3;
  allocp[53] = a16;
  allocp[54] = x4;
  allocp[55] = a18;
  allocp[56] = a19;
  allocp[57] = x5;
  allocp[58] = a21;
  allocp[59] = (q)(struct goalrec*)&allocp[35];
  allocp[60] = (q)(&predicate_functor__table_xarg_3);
  allocp[61] = a0;
  allocp[62] = a2;
  allocp[63] = x7;
  qp = (struct goalrec*)&allocp[59];
  allocp += 64;
  proceed();
 interclause__clauses_22_3:
  gblt_greater(a0,a1,interclause__clauses_22_interrupt);
  unify4(a3, a2, a13, a12, a15, a14, a17, a16);
  unify(a20, a19);
  proceed();
 interclause__clauses_22_4:
  if (!isref(a1)) goto interclause__clauses_22_interrupt;
  deref_and_jump(a1,interclause__clauses_22_2);
  *reasonp++ =  a1;
  goto interclause__clauses_22_interrupt;
 interclause__clauses_22_5:
  if (!isref(a0)) goto interclause__clauses_22_interrupt;
  deref_and_jump(a0,interclause__clauses_22_1);
  *reasonp++ =  a0;
  goto interclause__clauses_22_interrupt;
 interclause__clauses_22_ext_interrupt:
  reasonp = 0l;
 interclause__clauses_22_interrupt:
  goto interrupt_22;
 }

 interclause__clause_22_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  a18 = qp->args[18];
  a19 = qp->args[19];
  a20 = qp->args[20];
  a21 = qp->args[21];
  qp = qp->next;
 interclause__clause_22_clear_reason:
  reasonp = reasons;
 interclause__clause_22_0:
 interclause__clause_22_1:
  if (isref(a2)) goto interclause__clause_22_5;
 interclause__clause_22_2:
  if (isref(a2)) goto interclause__clause_22_4;
  if_not_equal(a2, a4, interclause__clause_22_6);
 interclause__clause_22_3:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_clause_6)) goto interclause__clause_22_6;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xset__head__body__types_21);
  allocp[2] = a11;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = arg(a0, 0);
  allocp[5] = x0;
  x1 = arg(a0, 2);
  allocp[6] = x1;
  allocp[7] = a9;
  allocp[8] = a10;
  allocp[9] = a5;
  allocp[10] = a6;
  allocp[11] = a7;
  allocp[12] = a8;
  allocp[13] = a12;
  allocp[14] = a13;
  allocp[15] = a14;
  allocp[16] = a15;
  allocp[17] = a16;
  allocp[18] = a17;
  allocp[19] = a18;
  allocp[20] = a19;
  allocp[21] = a20;
  allocp[22] = a21;
  allocp[23] = makesym(functor_clause_6);
  allocp[24] = x3 = makeref(&allocp[24]);
  allocp[25] = x4 = makeref(&allocp[25]);
  allocp[26] = x5 = makeref(&allocp[26]);
  allocp[27] = arg(a0, 3);
  allocp[28] = arg(a0, 4);
  allocp[29] = x6 = makeref(&allocp[29]);
  x2 = makefunctor(&allocp[23]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 30;
  unify_value(a1, x2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xset__goals__mode_11);
  allocp[2] = a2;
  allocp[3] = x1;
  allocp[4] = x5;
  allocp[5] = a5;
  allocp[6] = a6;
  allocp[7] = a7;
  allocp[8] = a8;
  allocp[9] = makesym(atom_body);
  allocp[10] = a11;
  allocp[11] = x7 = makeref(&allocp[11]);
  allocp[12] = x6;
  allocp[13] = (q)(struct goalrec*)&allocp[0];
  allocp[14] = (q)(&predicate_analyze__type_xset__goals__mode_11);
  allocp[15] = a2;
  x8 = arg(a0, 1);
  allocp[16] = x8;
  allocp[17] = x4;
  allocp[18] = a5;
  allocp[19] = a6;
  allocp[20] = a7;
  allocp[21] = a8;
  allocp[22] = makesym(atom_guard);
  allocp[23] = a11;
  allocp[24] = x9 = makeref(&allocp[24]);
  allocp[25] = x7;
  allocp[26] = (q)(struct goalrec*)&allocp[13];
  allocp[27] = (q)(&predicate_analyze__type_xset__goal__mode_11);
  allocp[28] = a2;
  allocp[29] = x0;
  allocp[30] = x3;
  allocp[31] = a5;
  allocp[32] = a6;
  allocp[33] = a7;
  allocp[34] = a8;
  allocp[35] = makesym(atom_head);
  allocp[36] = a11;
  x10 = arg(a0, 5);
  allocp[37] = x10;
  allocp[38] = x9;
  allocp[39] = (q)(struct goalrec*)&allocp[26];
  allocp[40] = (q)(&predicate_mode_xreverse__mode_2);
  allocp[41] = a11;
  allocp[42] = x11 = makeref(&allocp[42]);
  qp = (struct goalrec*)&allocp[39];
  allocp += 43;
  proceed();
 case VARREF:
  deref_and_jump(a0,interclause__clause_22_3);
  *reasonp++ =  a0;
  goto interclause__clause_22_6;
  };
  goto interclause__clause_22_6;
 interclause__clause_22_4:
  deref_and_jump(a2,interclause__clause_22_2);
  *reasonp++ =  a2;
  goto interclause__clause_22_6;
 interclause__clause_22_5:
  deref_and_jump(a2,interclause__clause_22_1);
  *reasonp++ =  a2;
  goto interclause__clause_22_6;
 interclause__clause_22_6:
  otherwise(interclause__clause_22_interrupt);
 interclause__clause_22_7:
  if (isref(a2)) goto interclause__clause_22_10;
 interclause__clause_22_8:
  if (isref(a2)) goto interclause__clause_22_9;
  if_not_equal(a2, a4, interclause__clause_22_interrupt);
  unify4(a1, a0, a13, a12, a15, a14, a17, a16);
  unify(a20, a19);
  proceed();
 interclause__clause_22_9:
  deref_and_jump(a2,interclause__clause_22_8);
  *reasonp++ =  a2;
  goto interclause__clause_22_interrupt;
 interclause__clause_22_10:
  deref_and_jump(a2,interclause__clause_22_7);
  *reasonp++ =  a2;
  goto interclause__clause_22_interrupt;
 interclause__clause_22_ext_interrupt:
  reasonp = 0l;
 interclause__clause_22_interrupt:
  goto interrupt_22;
 }

 set__head__body__types_21_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  a18 = qp->args[18];
  a19 = qp->args[19];
  a20 = qp->args[20];
  qp = qp->next;
 set__head__body__types_21_clear_reason:
  reasonp = reasons;
 set__head__body__types_21_0:
 set__head__body__types_21_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto set__head__body__types_21_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_i)):
  a0 = a1;
  a1 = a2;
  a2 = makesym(atom_head);
  a4 = a3;
  a5 = a7;
  x0 = a8;
  a7 = a9;
  a8 = a10;
  a9 = a6;
  a10 = makesym(atom_i);
  a6 = x0;
  a3 = makeint(1L);
  execute(set__goal__types_21_0);
  goto set__goal__types_21_ext_interrupt;
 case symval(makesym(atom_o)):
  a0 = a1;
  a1 = a2;
  a2 = makesym(atom_body);
  a3 = a4;
  a4 = a7;
  x0 = a8;
  a6 = a9;
  a7 = a10;
  a8 = a5;
  a9 = makesym(atom_o);
  a10 = a11;
  a11 = a12;
  a12 = a13;
  a13 = a14;
  a14 = a15;
  a15 = a16;
  a16 = a17;
  a17 = a18;
  a18 = a19;
  a19 = a20;
  a5 = x0;
  execute(set__goals__types_20_0);
  goto set__goals__types_20_ext_interrupt;
 case symval(makesym(atom__3F)):
  unify4(a12, a11, a14, a13, a16, a15, a19, a18);
  proceed();
  };
  goto set__head__body__types_21_interrupt;
 case VARREF:
  deref_and_jump(a0,set__head__body__types_21_1);
  *reasonp++ =  a0;
  goto set__head__body__types_21_interrupt;
  };
  goto set__head__body__types_21_interrupt;
 set__head__body__types_21_ext_interrupt:
  reasonp = 0l;
 set__head__body__types_21_interrupt:
  goto interrupt_21;
 }

 set__goals__mode_11_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 set__goals__mode_11_clear_reason:
  reasonp = reasons;
 set__goals__mode_11_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xset__goals__mode1_12);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = a8;
  allocp[12] = a9;
  allocp[13] = a10;
  allocp[14] = (q)(struct goalrec*)&allocp[0];
  allocp[15] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[16] = a1;
  allocp[17] = x1 = makeref(&allocp[17]);
  allocp[18] = x0;
  qp = (struct goalrec*)&allocp[14];
  allocp += 19;
  proceed();
 set__goals__mode_11_ext_interrupt:
  reasonp = 0l;
 set__goals__mode_11_interrupt:
  goto interrupt_11;
 }

 set__goals__mode1_12_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 set__goals__mode1_12_clear_reason:
  reasonp = reasons;
 set__goals__mode1_12_0:
 set__goals__mode1_12_1:
  if (!isint(a0)) goto set__goals__mode1_12_3;
  gblt_greater(a0,makeint(0L),set__goals__mode1_12_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xset__goals__mode1_12);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  allocp[12] = x2 = makeref(&allocp[12]);
  allocp[13] = a11;
  allocp[14] = (q)(struct goalrec*)&allocp[0];
  allocp[15] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[16] = a0;
  allocp[17] = makeint(1L);
  allocp[18] = x0;
  allocp[19] = (q)(struct goalrec*)&allocp[14];
  allocp[20] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[21] = a0;
  allocp[22] = a2;
  allocp[23] = x3 = makeref(&allocp[23]);
  allocp[24] = x1;
  allocp[25] = (q)(struct goalrec*)&allocp[19];
  allocp[26] = (q)(&predicate_analyze__type_xset__goal__mode_11);
  allocp[27] = a1;
  allocp[28] = x4 = makeref(&allocp[28]);
  allocp[29] = x3;
  allocp[30] = a4;
  allocp[31] = a5;
  allocp[32] = a6;
  allocp[33] = a7;
  allocp[34] = a8;
  allocp[35] = a9;
  allocp[36] = a10;
  allocp[37] = x2;
  allocp[38] = (q)(struct goalrec*)&allocp[25];
  allocp[39] = (q)(&predicate_functor__table_xarg_3);
  allocp[40] = a0;
  allocp[41] = a2;
  allocp[42] = x4;
  qp = (struct goalrec*)&allocp[38];
  allocp += 43;
  proceed();
 set__goals__mode1_12_2:
  if (a0 != makeint(0L)) goto set__goals__mode1_12_interrupt;
  unify2(a3, a2, a11, a10);
  proceed();
 set__goals__mode1_12_3:
  if (!isref(a0)) goto set__goals__mode1_12_interrupt;
  deref_and_jump(a0,set__goals__mode1_12_1);
  *reasonp++ =  a0;
  goto set__goals__mode1_12_interrupt;
 set__goals__mode1_12_ext_interrupt:
  reasonp = 0l;
 set__goals__mode1_12_interrupt:
  goto interrupt_12;
 }

 set__goal__mode_11_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 set__goal__mode_11_clear_reason:
  reasonp = reasons;
 set__goal__mode_11_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_parse__uty_xencode__goal_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a2;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_analyze__type_xset__goal__mode1_11);
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = x4 = makeref(&allocp[9]);
  allocp[10] = x0;
  allocp[11] = a3;
  allocp[12] = a4;
  allocp[13] = a5;
  allocp[14] = a6;
  allocp[15] = a7;
  allocp[16] = a8;
  allocp[17] = a9;
  allocp[18] = a10;
  allocp[19] = (q)(struct goalrec*)&allocp[6];
  allocp[20] = (q)(&predicate_analyze__type_xget__call__modulename_3);
  allocp[21] = x2;
  allocp[22] = a0;
  allocp[23] = x3;
  allocp[24] = (q)(struct goalrec*)&allocp[19];
  allocp[25] = (q)(&predicate_parse__uty_xdecode__goal_4);
  allocp[26] = a1;
  allocp[27] = x4;
  allocp[28] = x1;
  allocp[29] = x2;
  qp = (struct goalrec*)&allocp[24];
  allocp += 30;
  proceed();
 set__goal__mode_11_ext_interrupt:
  reasonp = 0l;
 set__goal__mode_11_interrupt:
  goto interrupt_11;
 }

 set__goal__mode1_11_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 set__goal__mode1_11_clear_reason:
  reasonp = reasons;
 set__goal__mode1_11_0:
 set__goal__mode1_11_1:
  if (isref(a3)) goto set__goal__mode1_11_14;
 set__goal__mode1_11_2:
  if (isref(a3)) goto set__goal__mode1_11_13;
  if_not_equal(a3, a0, set__goal__mode1_11_15);
 set__goal__mode1_11_3:
  if (isref(a1)) goto set__goal__mode1_11_12;
  gblt_pfunctor(a1,x0,set__goal__mode1_11_15);
 set__goal__mode1_11_4:
  if (isref(x0)) goto set__goal__mode1_11_11;
 set__goal__mode1_11_5:
  if (isref(x0)) goto set__goal__mode1_11_10;
  if_not_equal(x0, a4, set__goal__mode1_11_15);
  gblt_arity(a1,x1,set__goal__mode1_11_15);
 set__goal__mode1_11_6:
  if (isref(x1)) goto set__goal__mode1_11_9;
 set__goal__mode1_11_7:
  if (isref(x1)) goto set__goal__mode1_11_8;
  if_not_equal(x1, a5, set__goal__mode1_11_15);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = a6;
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a2;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_mode_xset__arg__mode_6);
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = a8;
  allocp[10] = a7;
  allocp[11] = x2;
  allocp[12] = a9;
  allocp[13] = a10;
  allocp[14] = (q)(struct goalrec*)&allocp[6];
  allocp[15] = (q)(&predicate_functor__table_xarg_3);
  allocp[16] = a6;
  allocp[17] = a1;
  allocp[18] = x3;
  qp = (struct goalrec*)&allocp[14];
  allocp += 19;
  proceed();
 set__goal__mode1_11_8:
  deref_and_jump(x1,set__goal__mode1_11_7);
  *reasonp++ =  x1;
  goto set__goal__mode1_11_15;
 set__goal__mode1_11_9:
  deref_and_jump(x1,set__goal__mode1_11_6);
  *reasonp++ =  x1;
  goto set__goal__mode1_11_15;
 set__goal__mode1_11_10:
  deref_and_jump(x0,set__goal__mode1_11_5);
  *reasonp++ =  x0;
  goto set__goal__mode1_11_15;
 set__goal__mode1_11_11:
  deref_and_jump(x0,set__goal__mode1_11_4);
  *reasonp++ =  x0;
  goto set__goal__mode1_11_15;
 set__goal__mode1_11_12:
  deref_and_jump(a1,set__goal__mode1_11_3);
  *reasonp++ =  a1;
  goto set__goal__mode1_11_15;
 set__goal__mode1_11_13:
  deref_and_jump(a3,set__goal__mode1_11_2);
  *reasonp++ =  a3;
  goto set__goal__mode1_11_15;
 set__goal__mode1_11_14:
  deref_and_jump(a3,set__goal__mode1_11_1);
  *reasonp++ =  a3;
  goto set__goal__mode1_11_15;
 set__goal__mode1_11_15:
  otherwise(set__goal__mode1_11_interrupt);
  unify2(a2, a1, a10, a9);
  proceed();
 set__goal__mode1_11_ext_interrupt:
  reasonp = 0l;
 set__goal__mode1_11_interrupt:
  goto interrupt_11;
 }

 set__goals__types_20_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  a18 = qp->args[18];
  a19 = qp->args[19];
  qp = qp->next;
 set__goals__types_20_clear_reason:
  reasonp = reasons;
 set__goals__types_20_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xset__goals__types1_21);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = a8;
  allocp[12] = a9;
  allocp[13] = a10;
  allocp[14] = a11;
  allocp[15] = a12;
  allocp[16] = a13;
  allocp[17] = a14;
  allocp[18] = a15;
  allocp[19] = a16;
  allocp[20] = a17;
  allocp[21] = a18;
  allocp[22] = a19;
  allocp[23] = (q)(struct goalrec*)&allocp[0];
  allocp[24] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[25] = a3;
  allocp[26] = x1 = makeref(&allocp[26]);
  allocp[27] = x0;
  qp = (struct goalrec*)&allocp[23];
  allocp += 28;
  proceed();
 set__goals__types_20_ext_interrupt:
  reasonp = 0l;
 set__goals__types_20_interrupt:
  toppred = &predicate_analyze__type_xset__goals__types_20;
  goto interrupt_20;
 }

 set__goals__types1_21_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  a18 = qp->args[18];
  a19 = qp->args[19];
  a20 = qp->args[20];
  qp = qp->next;
 set__goals__types1_21_clear_reason:
  reasonp = reasons;
 set__goals__types1_21_0:
 set__goals__types1_21_1:
  if (!isint(a0)) goto set__goals__types1_21_3;
  gblt_greater(a0,makeint(0L),set__goals__types1_21_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xset__goals__types1_21);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  allocp[12] = a10;
  allocp[13] = x1 = makeref(&allocp[13]);
  allocp[14] = a12;
  allocp[15] = x2 = makeref(&allocp[15]);
  allocp[16] = a14;
  allocp[17] = x3 = makeref(&allocp[17]);
  allocp[18] = a16;
  allocp[19] = a17;
  allocp[20] = x4 = makeref(&allocp[20]);
  allocp[21] = a19;
  allocp[22] = a20;
  allocp[23] = (q)(struct goalrec*)&allocp[0];
  allocp[24] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[25] = a0;
  allocp[26] = makeint(1L);
  allocp[27] = x0;
  allocp[28] = (q)(struct goalrec*)&allocp[23];
  allocp[29] = (q)(&predicate_analyze__type_xset__goal__types_21);
  allocp[30] = a1;
  allocp[31] = a2;
  allocp[32] = a3;
  allocp[33] = a0;
  allocp[34] = x5 = makeref(&allocp[34]);
  allocp[35] = a5;
  allocp[36] = a6;
  allocp[37] = a7;
  allocp[38] = a8;
  allocp[39] = a9;
  allocp[40] = a10;
  allocp[41] = a11;
  allocp[42] = x1;
  allocp[43] = a13;
  allocp[44] = x2;
  allocp[45] = a15;
  allocp[46] = x3;
  allocp[47] = a17;
  allocp[48] = a18;
  allocp[49] = x4;
  allocp[50] = a20;
  allocp[51] = (q)(struct goalrec*)&allocp[28];
  allocp[52] = (q)(&predicate_functor__table_xarg_3);
  allocp[53] = a0;
  allocp[54] = a4;
  allocp[55] = x5;
  qp = (struct goalrec*)&allocp[51];
  allocp += 56;
  proceed();
 set__goals__types1_21_2:
  if (a0 != makeint(0L)) goto set__goals__types1_21_interrupt;
  unify4(a12, a11, a14, a13, a16, a15, a19, a18);
  proceed();
 set__goals__types1_21_3:
  if (!isref(a0)) goto set__goals__types1_21_interrupt;
  deref_and_jump(a0,set__goals__types1_21_1);
  *reasonp++ =  a0;
  goto set__goals__types1_21_interrupt;
 set__goals__types1_21_ext_interrupt:
  reasonp = 0l;
 set__goals__types1_21_interrupt:
  goto interrupt_21;
 }

 set__goal__types_21_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  a18 = qp->args[18];
  a19 = qp->args[19];
  a20 = qp->args[20];
  qp = qp->next;
 set__goal__types_21_clear_reason:
  reasonp = reasons;
 set__goal__types_21_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xset__goal__types1_23);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a1;
  allocp[6] = a2;
  allocp[7] = a3;
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = a5;
  allocp[10] = a6;
  allocp[11] = a7;
  allocp[12] = a8;
  allocp[13] = a9;
  allocp[14] = a10;
  allocp[15] = a11;
  allocp[16] = a12;
  allocp[17] = a13;
  allocp[18] = a14;
  allocp[19] = a15;
  allocp[20] = a16;
  allocp[21] = a17;
  allocp[22] = a18;
  allocp[23] = a19;
  allocp[24] = a20;
  allocp[25] = (q)(struct goalrec*)&allocp[0];
  allocp[26] = (q)(&predicate_parse__uty_xdecode__goalcall_6);
  allocp[27] = a0;
  allocp[28] = x1;
  allocp[29] = a4;
  allocp[30] = x2;
  allocp[31] = x0;
  allocp[32] = x3 = makeref(&allocp[32]);
  qp = (struct goalrec*)&allocp[25];
  allocp += 33;
  proceed();
 set__goal__types_21_ext_interrupt:
  reasonp = 0l;
 set__goal__types_21_interrupt:
  toppred = &predicate_analyze__type_xset__goal__types_21;
  goto interrupt_21;
 }

 set__goal__types1_23_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  a18 = qp->args[18];
  a19 = qp->args[19];
  a20 = qp->args[20];
  a21 = qp->args[21];
  a22 = qp->args[22];
  qp = qp->next;
 set__goal__types1_23_clear_reason:
  reasonp = reasons;
 set__goal__types1_23_0:
 set__goal__types1_23_1:
  if (isref(a2)) goto set__goal__types1_23_31;
 set__goal__types1_23_2:
  if (isref(a2)) goto set__goal__types1_23_30;
  if_not_equal(a2, a7, set__goal__types1_23_15);
 set__goal__types1_23_3:
  if (isref(a6)) goto set__goal__types1_23_14;
  gblt_pfunctor(a6,x0,set__goal__types1_23_15);
 set__goal__types1_23_4:
  if (isref(x0)) goto set__goal__types1_23_13;
 set__goal__types1_23_5:
  if (isref(x0)) goto set__goal__types1_23_12;
  if_not_equal(x0, a8, set__goal__types1_23_15);
  gblt_arity(a6,x1,set__goal__types1_23_15);
 set__goal__types1_23_6:
  if (isref(x1)) goto set__goal__types1_23_11;
 set__goal__types1_23_7:
  if (isref(x1)) goto set__goal__types1_23_10;
  if_not_equal(x1, a9, set__goal__types1_23_15);
 set__goal__types1_23_8:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_atom_1)) goto set__goal__types1_23_15;
  x2 = arg(a0, 0);
 set__goal__types1_23_9:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != makesym(atom_loop)) goto set__goal__types1_23_15;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xset__arg__types_13);
  allocp[2] = a1;
  allocp[3] = a3;
  allocp[4] = a4;
  allocp[5] = a5;
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = x4 = makeref(&allocp[7]);
  allocp[8] = a12;
  allocp[9] = x5 = makeref(&allocp[9]);
  allocp[10] = a14;
  allocp[11] = a15;
  allocp[12] = a16;
  allocp[13] = x6 = makeref(&allocp[13]);
  allocp[14] = a18;
  qp = (struct goalrec*)&allocp[0];
  allocp += 15;
  unify(a21, a20);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = a10;
  allocp[3] = a6;
  allocp[4] = x3;
  allocp[5] = makesym(functor_goal_4);
  allocp[6] = a7;
  allocp[7] = a3;
  allocp[8] = a5;
  allocp[9] = a4;
  x7 = makefunctor(&allocp[5]);
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_type_xmake__types__loopup_9);
  allocp[12] = a11;
  allocp[13] = x4;
  allocp[14] = x7;
  allocp[15] = makefunctor(funct_const_1);
  allocp[16] = a13;
  allocp[17] = x5;
  allocp[18] = a17;
  allocp[19] = x6;
  allocp[20] = a19;
  qp = (struct goalrec*)&allocp[10];
  allocp += 21;
  proceed();
 case VARREF:
  deref_and_jump(x2,set__goal__types1_23_9);
  *reasonp++ =  x2;
  goto set__goal__types1_23_15;
  };
  goto set__goal__types1_23_15;
 case VARREF:
  deref_and_jump(a0,set__goal__types1_23_8);
  *reasonp++ =  a0;
  goto set__goal__types1_23_15;
  };
  goto set__goal__types1_23_15;
 set__goal__types1_23_10:
  deref_and_jump(x1,set__goal__types1_23_7);
  *reasonp++ =  x1;
  goto set__goal__types1_23_15;
 set__goal__types1_23_11:
  deref_and_jump(x1,set__goal__types1_23_6);
  *reasonp++ =  x1;
  goto set__goal__types1_23_15;
 set__goal__types1_23_12:
  deref_and_jump(x0,set__goal__types1_23_5);
  *reasonp++ =  x0;
  goto set__goal__types1_23_15;
 set__goal__types1_23_13:
  deref_and_jump(x0,set__goal__types1_23_4);
  *reasonp++ =  x0;
  goto set__goal__types1_23_15;
 set__goal__types1_23_14:
  deref_and_jump(a6,set__goal__types1_23_3);
  *reasonp++ =  a6;
  goto set__goal__types1_23_15;
 set__goal__types1_23_15:
 set__goal__types1_23_16:
  if (isref(a2)) goto set__goal__types1_23_29;
  if_not_equal(a2, a7, set__goal__types1_23_32);
 set__goal__types1_23_17:
  if (isref(a6)) goto set__goal__types1_23_28;
  gblt_pfunctor(a6,x0,set__goal__types1_23_32);
 set__goal__types1_23_18:
  if (isref(x0)) goto set__goal__types1_23_27;
 set__goal__types1_23_19:
  if (isref(x0)) goto set__goal__types1_23_26;
  if_not_equal(x0, a8, set__goal__types1_23_32);
  gblt_arity(a6,x1,set__goal__types1_23_32);
 set__goal__types1_23_20:
  if (isref(x1)) goto set__goal__types1_23_25;
 set__goal__types1_23_21:
  if (isref(x1)) goto set__goal__types1_23_24;
  if_not_equal(x1, a9, set__goal__types1_23_32);
 set__goal__types1_23_22:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_atom_1)) goto set__goal__types1_23_32;
  x2 = arg(a0, 0);
 set__goal__types1_23_23:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != makesym(atom_shared)) goto set__goal__types1_23_32;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xset__arg__types_13);
  allocp[2] = a1;
  allocp[3] = a3;
  allocp[4] = a4;
  allocp[5] = a5;
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = x4 = makeref(&allocp[7]);
  allocp[8] = a12;
  allocp[9] = x5 = makeref(&allocp[9]);
  allocp[10] = a14;
  allocp[11] = a15;
  allocp[12] = a16;
  allocp[13] = x6 = makeref(&allocp[13]);
  allocp[14] = a18;
  qp = (struct goalrec*)&allocp[0];
  allocp += 15;
  unify(a21, a20);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = a10;
  allocp[3] = a6;
  allocp[4] = x3;
  allocp[5] = makesym(functor_goal_4);
  allocp[6] = a7;
  allocp[7] = a3;
  allocp[8] = a5;
  allocp[9] = a4;
  x7 = makefunctor(&allocp[5]);
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_type_xmake__types__loopup_9);
  allocp[12] = a11;
  allocp[13] = x4;
  allocp[14] = x7;
  allocp[15] = makefunctor(funct_const_1);
  allocp[16] = a13;
  allocp[17] = x5;
  allocp[18] = a17;
  allocp[19] = x6;
  allocp[20] = a19;
  qp = (struct goalrec*)&allocp[10];
  allocp += 21;
  proceed();
 case VARREF:
  deref_and_jump(x2,set__goal__types1_23_23);
  *reasonp++ =  x2;
  goto set__goal__types1_23_32;
  };
  goto set__goal__types1_23_32;
 case VARREF:
  deref_and_jump(a0,set__goal__types1_23_22);
  *reasonp++ =  a0;
  goto set__goal__types1_23_32;
  };
  goto set__goal__types1_23_32;
 set__goal__types1_23_24:
  deref_and_jump(x1,set__goal__types1_23_21);
  *reasonp++ =  x1;
  goto set__goal__types1_23_32;
 set__goal__types1_23_25:
  deref_and_jump(x1,set__goal__types1_23_20);
  *reasonp++ =  x1;
  goto set__goal__types1_23_32;
 set__goal__types1_23_26:
  deref_and_jump(x0,set__goal__types1_23_19);
  *reasonp++ =  x0;
  goto set__goal__types1_23_32;
 set__goal__types1_23_27:
  deref_and_jump(x0,set__goal__types1_23_18);
  *reasonp++ =  x0;
  goto set__goal__types1_23_32;
 set__goal__types1_23_28:
  deref_and_jump(a6,set__goal__types1_23_17);
  *reasonp++ =  a6;
  goto set__goal__types1_23_32;
 set__goal__types1_23_29:
  deref_and_jump(a2,set__goal__types1_23_16);
  *reasonp++ =  a2;
  goto set__goal__types1_23_32;
 set__goal__types1_23_30:
  deref_and_jump(a2,set__goal__types1_23_2);
  *reasonp++ =  a2;
  goto set__goal__types1_23_32;
 set__goal__types1_23_31:
  deref_and_jump(a2,set__goal__types1_23_1);
  *reasonp++ =  a2;
  goto set__goal__types1_23_32;
 set__goal__types1_23_32:
  otherwise(set__goal__types1_23_interrupt);
 set__goal__types1_23_33:
  if (isref(a2)) goto set__goal__types1_23_46;
 set__goal__types1_23_34:
  if (isref(a2)) goto set__goal__types1_23_45;
  if_not_equal(a2, a7, set__goal__types1_23_47);
 set__goal__types1_23_35:
  if (isref(a6)) goto set__goal__types1_23_44;
  gblt_pfunctor(a6,x0,set__goal__types1_23_47);
 set__goal__types1_23_36:
  if (isref(x0)) goto set__goal__types1_23_43;
 set__goal__types1_23_37:
  if (isref(x0)) goto set__goal__types1_23_42;
  if_not_equal(x0, a8, set__goal__types1_23_47);
  gblt_arity(a6,x1,set__goal__types1_23_47);
 set__goal__types1_23_38:
  if (isref(x1)) goto set__goal__types1_23_41;
 set__goal__types1_23_39:
  if (isref(x1)) goto set__goal__types1_23_40;
  if_not_equal(x1, a9, set__goal__types1_23_47);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xset__arg__types_13);
  allocp[2] = a1;
  allocp[3] = a3;
  allocp[4] = a4;
  allocp[5] = a5;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a11;
  allocp[8] = a12;
  allocp[9] = a13;
  allocp[10] = a14;
  allocp[11] = a15;
  allocp[12] = a16;
  allocp[13] = a17;
  allocp[14] = a18;
  qp = (struct goalrec*)&allocp[0];
  allocp += 15;
  unify(a21, a20);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = a10;
  allocp[3] = a6;
  allocp[4] = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 set__goal__types1_23_40:
  deref_and_jump(x1,set__goal__types1_23_39);
  *reasonp++ =  x1;
  goto set__goal__types1_23_47;
 set__goal__types1_23_41:
  deref_and_jump(x1,set__goal__types1_23_38);
  *reasonp++ =  x1;
  goto set__goal__types1_23_47;
 set__goal__types1_23_42:
  deref_and_jump(x0,set__goal__types1_23_37);
  *reasonp++ =  x0;
  goto set__goal__types1_23_47;
 set__goal__types1_23_43:
  deref_and_jump(x0,set__goal__types1_23_36);
  *reasonp++ =  x0;
  goto set__goal__types1_23_47;
 set__goal__types1_23_44:
  deref_and_jump(a6,set__goal__types1_23_35);
  *reasonp++ =  a6;
  goto set__goal__types1_23_47;
 set__goal__types1_23_45:
  deref_and_jump(a2,set__goal__types1_23_34);
  *reasonp++ =  a2;
  goto set__goal__types1_23_47;
 set__goal__types1_23_46:
  deref_and_jump(a2,set__goal__types1_23_33);
  *reasonp++ =  a2;
  goto set__goal__types1_23_47;
 set__goal__types1_23_47:
  otherwise(set__goal__types1_23_interrupt);
  unify4(a14, a13, a16, a15, a18, a17, a21, a20);
  proceed();
 set__goal__types1_23_ext_interrupt:
  reasonp = 0l;
 set__goal__types1_23_interrupt:
  goto interrupt_23;
 }

 set__arg__types_13_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  qp = qp->next;
 set__arg__types_13_clear_reason:
  reasonp = reasons;
 set__arg__types_13_0:
 set__arg__types_13_1:
  switch (ptagof(a4)) {
 case FUNCTOR:
  if (functor_of(a4) != makesym(functor_variable_3)) goto set__arg__types_13_2;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xset__types_13);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  x0 = arg(a4, 0);
  allocp[6] = x0;
  allocp[7] = a6;
  allocp[8] = a5;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  allocp[12] = a10;
  allocp[13] = a11;
  allocp[14] = a12;
  qp = (struct goalrec*)&allocp[0];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(a4,set__arg__types_13_1);
  *reasonp++ =  a4;
  goto set__arg__types_13_2;
  };
  goto set__arg__types_13_2;
 set__arg__types_13_2:
  otherwise(set__arg__types_13_interrupt);
  unify3(a7, a8, a9, a10, a11, a12);
  proceed();
 set__arg__types_13_ext_interrupt:
  reasonp = 0l;
 set__arg__types_13_interrupt:
  goto interrupt_13;
 }

 apply__new__indirect_13_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20, x21, x22, x23, x24, x25, x26, x27, x28, x29, x30, x31, x32, x33, x34, x35, x36, x37, x38, x39, x40, x41;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  qp = qp->next;
 apply__new__indirect_13_clear_reason:
  reasonp = reasons;
 apply__new__indirect_13_0:
 apply__new__indirect_13_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 apply__new__indirect_13_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_unify_2:
  x1 = arg(x0, 0);
 apply__new__indirect_13_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_t_4)) goto apply__new__indirect_13_23;
  x2 = arg(x1, 0);
 apply__new__indirect_13_4:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_v_4)) goto apply__new__indirect_13_23;
  x3 = arg(x0, 1);
 apply__new__indirect_13_5:
  switch (ptagof(x3)) {
 case FUNCTOR:
  if (functor_of(x3) != makesym(functor_t_4)) goto apply__new__indirect_13_23;
  x4 = arg(x3, 0);
 apply__new__indirect_13_6:
  switch (ptagof(x4)) {
 case FUNCTOR:
  if (functor_of(x4) != makesym(functor_v_4)) goto apply__new__indirect_13_23;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xapply__new__indirect_13);
  allocp[2] = x5 = makeref(&allocp[2]);
  allocp[3] = x6 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x7 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x8 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = x9 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = a9;
  allocp[12] = a10;
  allocp[13] = x10 = makeref(&allocp[13]);
  allocp[14] = a12;
  allocp[15] = makesym(functor_unify_2);
  allocp[16] = x12 = makeref(&allocp[16]);
  allocp[17] = x13 = makeref(&allocp[17]);
  x11 = makefunctor(&allocp[15]);
  allocp[18] = (q)(struct goalrec*)&allocp[0];
  allocp[19] = (q)(&predicate_type_xentry__indirect_3);
  allocp[20] = x11;
  allocp[21] = a1;
  allocp[22] = x6;
  allocp[23] = (q)(struct goalrec*)&allocp[18];
  allocp[24] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[25] = makeint(4L);
  allocp[26] = x3;
  allocp[27] = x14 = makeref(&allocp[27]);
  allocp[28] = x13;
  allocp[29] = (q)(struct goalrec*)&allocp[23];
  allocp[30] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[31] = makeint(4L);
  allocp[32] = x1;
  allocp[33] = x15 = makeref(&allocp[33]);
  allocp[34] = x12;
  allocp[35] = (q)(struct goalrec*)&allocp[29];
  allocp[36] = (q)(&predicate_mode_xmode2ru_2);
  allocp[37] = x16 = makeref(&allocp[37]);
  allocp[38] = x14;
  allocp[39] = (q)(struct goalrec*)&allocp[35];
  allocp[40] = (q)(&predicate_mode_xmode2ru_2);
  allocp[41] = x17 = makeref(&allocp[41]);
  allocp[42] = x15;
  allocp[43] = (q)(struct goalrec*)&allocp[39];
  allocp[44] = (q)(&predicate_analyze__type_xapply__new__indirect1_18);
  allocp[45] = x17;
  allocp[46] = x16;
  x18 = arg(x2, 0);
  allocp[47] = x18;
  x19 = arg(x4, 0);
  allocp[48] = x19;
  x20 = arg(x2, 1);
  allocp[49] = x20;
  x21 = arg(x4, 1);
  allocp[50] = x21;
  x22 = arg(x2, 3);
  allocp[51] = x22;
  x23 = arg(x4, 3);
  allocp[52] = x23;
  allocp[53] = x24 = makeref(&allocp[53]);
  allocp[54] = x25 = makeref(&allocp[54]);
  allocp[55] = x26 = makeref(&allocp[55]);
  allocp[56] = x27 = makeref(&allocp[56]);
  x28 = cdr_of(a0);
  allocp[57] = x28;
  allocp[58] = x5;
  allocp[59] = a3;
  allocp[60] = x7;
  allocp[61] = a5;
  allocp[62] = x8;
  allocp[63] = makesym(functor_variable_3);
  allocp[64] = x22;
  allocp[65] = arg(x2, 2);
  allocp[66] = arg(x1, 3);
  x29 = makefunctor(&allocp[63]);
  allocp[67] = makesym(functor_variable_3);
  allocp[68] = x23;
  allocp[69] = arg(x4, 2);
  allocp[70] = arg(x3, 3);
  x30 = makefunctor(&allocp[67]);
  a0 = x18;
  a1 = x19;
  a2 = x20;
  a4 = x29;
  a5 = x30;
  a6 = x17;
  a8 = a7;
  a9 = x9;
  a10 = x26;
  a12 = x24;
  a13 = x25;
  a14 = a3;
  a15 = a11;
  a16 = x10;
  a11 = x27;
  a7 = x16;
  a3 = x21;
  qp = (struct goalrec*)&allocp[43];
  allocp += 71;
  execute(indirect__mode__expansion_17_0);
  goto indirect__mode__expansion_17_ext_interrupt;
 case VARREF:
  deref_and_jump(x4,apply__new__indirect_13_6);
  *reasonp++ =  x4;
  goto apply__new__indirect_13_23;
  };
  goto apply__new__indirect_13_23;
 case VARREF:
  deref_and_jump(x3,apply__new__indirect_13_5);
  *reasonp++ =  x3;
  goto apply__new__indirect_13_23;
  };
  goto apply__new__indirect_13_23;
 case VARREF:
  deref_and_jump(x2,apply__new__indirect_13_4);
  *reasonp++ =  x2;
  goto apply__new__indirect_13_23;
  };
  goto apply__new__indirect_13_23;
 case VARREF:
  deref_and_jump(x1,apply__new__indirect_13_3);
  *reasonp++ =  x1;
  goto apply__new__indirect_13_23;
  };
  goto apply__new__indirect_13_23;
 case functor_unifyaliasdown_2:
  x1 = arg(x0, 0);
 apply__new__indirect_13_7:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_t_4)) goto apply__new__indirect_13_23;
  x2 = arg(x1, 0);
 apply__new__indirect_13_8:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_v_4)) goto apply__new__indirect_13_23;
  x3 = arg(x1, 2);
 apply__new__indirect_13_9:
  switch (ptagof(x3)) {
 case CONS:
  x4 = cdr_of(x3);
 apply__new__indirect_13_10:
  switch (ptagof(x4)) {
 case ATOMIC:
  if (x4 != NILATOM) goto apply__new__indirect_13_23;
  x5 = arg(x0, 1);
 apply__new__indirect_13_11:
  switch (ptagof(x5)) {
 case FUNCTOR:
  if (functor_of(x5) != makesym(functor_t_4)) goto apply__new__indirect_13_23;
  x6 = arg(x5, 0);
 apply__new__indirect_13_12:
  switch (ptagof(x6)) {
 case FUNCTOR:
  if (functor_of(x6) != makesym(functor_v_4)) goto apply__new__indirect_13_23;
  x7 = arg(x5, 2);
 apply__new__indirect_13_13:
  switch (ptagof(x7)) {
 case CONS:
  x8 = cdr_of(x7);
 apply__new__indirect_13_14:
  switch (ptagof(x8)) {
 case ATOMIC:
  if (x8 != NILATOM) goto apply__new__indirect_13_23;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xapply__new__indirect_13);
  allocp[2] = x9 = makeref(&allocp[2]);
  allocp[3] = x10 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x11 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x12 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = x13 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = x14 = makeref(&allocp[11]);
  allocp[12] = a10;
  allocp[13] = x15 = makeref(&allocp[13]);
  allocp[14] = a12;
  allocp[15] = makesym(functor_unifyaliasdown_2);
  allocp[16] = x17 = makeref(&allocp[16]);
  allocp[17] = x18 = makeref(&allocp[17]);
  x16 = makefunctor(&allocp[15]);
  allocp[18] = (q)(struct goalrec*)&allocp[0];
  allocp[19] = (q)(&predicate_type_xentry__indirect_3);
  allocp[20] = x16;
  allocp[21] = a1;
  allocp[22] = x10;
  allocp[23] = (q)(struct goalrec*)&allocp[18];
  allocp[24] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[25] = makeint(4L);
  allocp[26] = x5;
  allocp[27] = x19 = makeref(&allocp[27]);
  allocp[28] = x18;
  allocp[29] = (q)(struct goalrec*)&allocp[23];
  allocp[30] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[31] = makeint(4L);
  allocp[32] = x1;
  allocp[33] = x20 = makeref(&allocp[33]);
  allocp[34] = x17;
  allocp[35] = (q)(struct goalrec*)&allocp[29];
  allocp[36] = (q)(&predicate_mode_xmode2ru_2);
  allocp[37] = x21 = makeref(&allocp[37]);
  allocp[38] = x19;
  allocp[39] = (q)(struct goalrec*)&allocp[35];
  allocp[40] = (q)(&predicate_mode_xmode2ru_2);
  allocp[41] = x22 = makeref(&allocp[41]);
  allocp[42] = x20;
  allocp[43] = a1;
  allocp[44] = x0;
  x23 = makecons(&allocp[43]);
  allocp[45] = (q)(struct goalrec*)&allocp[39];
  allocp[46] = (q)(&predicate_analyze__type_xapply__new__indirect1__alias_28);
  allocp[47] = makesym(atom_down);
  allocp[48] = x22;
  allocp[49] = x21;
  x24 = arg(x2, 0);
  allocp[50] = x24;
  x25 = arg(x6, 0);
  allocp[51] = x25;
  x26 = arg(x2, 1);
  allocp[52] = x26;
  x27 = arg(x6, 1);
  allocp[53] = x27;
  x28 = arg(x2, 2);
  allocp[54] = x28;
  x29 = arg(x6, 2);
  allocp[55] = x29;
  x30 = arg(x2, 3);
  allocp[56] = x30;
  x31 = arg(x6, 3);
  allocp[57] = x31;
  allocp[58] = x32 = makeref(&allocp[58]);
  allocp[59] = x33 = makeref(&allocp[59]);
  allocp[60] = x34 = makeref(&allocp[60]);
  allocp[61] = x35 = makeref(&allocp[61]);
  x36 = car_of(x3);
  allocp[62] = x36;
  x37 = car_of(x7);
  allocp[63] = x37;
  x38 = cdr_of(a0);
  allocp[64] = x38;
  allocp[65] = x9;
  allocp[66] = x23;
  allocp[67] = a3;
  allocp[68] = x11;
  allocp[69] = a5;
  allocp[70] = x12;
  allocp[71] = a9;
  allocp[72] = x14;
  allocp[73] = x15;
  allocp[74] = x39 = makeref(&allocp[74]);
  allocp[75] = makesym(functor_variable_3);
  allocp[76] = x30;
  allocp[77] = x28;
  allocp[78] = arg(x1, 3);
  x40 = makefunctor(&allocp[75]);
  allocp[79] = makesym(functor_variable_3);
  allocp[80] = x31;
  allocp[81] = x29;
  allocp[82] = arg(x5, 3);
  x41 = makefunctor(&allocp[79]);
  a0 = x24;
  a1 = x25;
  a2 = x26;
  a4 = x40;
  a5 = x41;
  a6 = x22;
  a8 = a7;
  a9 = x13;
  a10 = x34;
  a12 = x32;
  a13 = x33;
  a14 = a3;
  a15 = a11;
  a16 = x15;
  a11 = x35;
  a7 = x21;
  a3 = x27;
  qp = (struct goalrec*)&allocp[45];
  allocp += 83;
  execute(indirect__mode__expansion_17_0);
  goto indirect__mode__expansion_17_ext_interrupt;
 case VARREF:
  deref_and_jump(x8,apply__new__indirect_13_14);
  *reasonp++ =  x8;
  goto apply__new__indirect_13_23;
  };
  goto apply__new__indirect_13_23;
 case VARREF:
  deref_and_jump(x7,apply__new__indirect_13_13);
  *reasonp++ =  x7;
  goto apply__new__indirect_13_23;
  };
  goto apply__new__indirect_13_23;
 case VARREF:
  deref_and_jump(x6,apply__new__indirect_13_12);
  *reasonp++ =  x6;
  goto apply__new__indirect_13_23;
  };
  goto apply__new__indirect_13_23;
 case VARREF:
  deref_and_jump(x5,apply__new__indirect_13_11);
  *reasonp++ =  x5;
  goto apply__new__indirect_13_23;
  };
  goto apply__new__indirect_13_23;
 case VARREF:
  deref_and_jump(x4,apply__new__indirect_13_10);
  *reasonp++ =  x4;
  goto apply__new__indirect_13_23;
  };
  goto apply__new__indirect_13_23;
 case VARREF:
  deref_and_jump(x3,apply__new__indirect_13_9);
  *reasonp++ =  x3;
  goto apply__new__indirect_13_23;
  };
  goto apply__new__indirect_13_23;
 case VARREF:
  deref_and_jump(x2,apply__new__indirect_13_8);
  *reasonp++ =  x2;
  goto apply__new__indirect_13_23;
  };
  goto apply__new__indirect_13_23;
 case VARREF:
  deref_and_jump(x1,apply__new__indirect_13_7);
  *reasonp++ =  x1;
  goto apply__new__indirect_13_23;
  };
  goto apply__new__indirect_13_23;
 case functor_unifyaliasup_2:
  x1 = arg(x0, 0);
 apply__new__indirect_13_15:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_t_4)) goto apply__new__indirect_13_23;
  x2 = arg(x1, 0);
 apply__new__indirect_13_16:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_v_4)) goto apply__new__indirect_13_23;
  x3 = arg(x1, 2);
 apply__new__indirect_13_17:
  switch (ptagof(x3)) {
 case CONS:
  x4 = cdr_of(x3);
 apply__new__indirect_13_18:
  switch (ptagof(x4)) {
 case ATOMIC:
  if (x4 != NILATOM) goto apply__new__indirect_13_23;
  x5 = arg(x0, 1);
 apply__new__indirect_13_19:
  switch (ptagof(x5)) {
 case FUNCTOR:
  if (functor_of(x5) != makesym(functor_t_4)) goto apply__new__indirect_13_23;
  x6 = arg(x5, 0);
 apply__new__indirect_13_20:
  switch (ptagof(x6)) {
 case FUNCTOR:
  if (functor_of(x6) != makesym(functor_v_4)) goto apply__new__indirect_13_23;
  x7 = arg(x5, 2);
 apply__new__indirect_13_21:
  switch (ptagof(x7)) {
 case CONS:
  x8 = cdr_of(x7);
 apply__new__indirect_13_22:
  switch (ptagof(x8)) {
 case ATOMIC:
  if (x8 != NILATOM) goto apply__new__indirect_13_23;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xapply__new__indirect_13);
  allocp[2] = x9 = makeref(&allocp[2]);
  allocp[3] = x10 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x11 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x12 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = x13 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = x14 = makeref(&allocp[11]);
  allocp[12] = a10;
  allocp[13] = x15 = makeref(&allocp[13]);
  allocp[14] = a12;
  allocp[15] = makesym(functor_unifyaliasup_2);
  allocp[16] = x17 = makeref(&allocp[16]);
  allocp[17] = x18 = makeref(&allocp[17]);
  x16 = makefunctor(&allocp[15]);
  allocp[18] = (q)(struct goalrec*)&allocp[0];
  allocp[19] = (q)(&predicate_type_xentry__indirect_3);
  allocp[20] = x16;
  allocp[21] = a1;
  allocp[22] = x10;
  allocp[23] = (q)(struct goalrec*)&allocp[18];
  allocp[24] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[25] = makeint(4L);
  allocp[26] = x5;
  allocp[27] = x19 = makeref(&allocp[27]);
  allocp[28] = x18;
  allocp[29] = (q)(struct goalrec*)&allocp[23];
  allocp[30] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[31] = makeint(4L);
  allocp[32] = x1;
  allocp[33] = x20 = makeref(&allocp[33]);
  allocp[34] = x17;
  allocp[35] = (q)(struct goalrec*)&allocp[29];
  allocp[36] = (q)(&predicate_mode_xmode2ru_2);
  allocp[37] = x21 = makeref(&allocp[37]);
  allocp[38] = x19;
  allocp[39] = (q)(struct goalrec*)&allocp[35];
  allocp[40] = (q)(&predicate_mode_xmode2ru_2);
  allocp[41] = x22 = makeref(&allocp[41]);
  allocp[42] = x20;
  allocp[43] = a1;
  allocp[44] = x0;
  x23 = makecons(&allocp[43]);
  allocp[45] = (q)(struct goalrec*)&allocp[39];
  allocp[46] = (q)(&predicate_analyze__type_xapply__new__indirect1__alias_28);
  allocp[47] = makesym(atom_up);
  allocp[48] = x22;
  allocp[49] = x21;
  x24 = arg(x2, 0);
  allocp[50] = x24;
  x25 = arg(x6, 0);
  allocp[51] = x25;
  x26 = arg(x2, 1);
  allocp[52] = x26;
  x27 = arg(x6, 1);
  allocp[53] = x27;
  x28 = arg(x2, 2);
  allocp[54] = x28;
  x29 = arg(x6, 2);
  allocp[55] = x29;
  x30 = arg(x2, 3);
  allocp[56] = x30;
  x31 = arg(x6, 3);
  allocp[57] = x31;
  allocp[58] = x32 = makeref(&allocp[58]);
  allocp[59] = x33 = makeref(&allocp[59]);
  allocp[60] = x34 = makeref(&allocp[60]);
  allocp[61] = x35 = makeref(&allocp[61]);
  x36 = car_of(x3);
  allocp[62] = x36;
  x37 = car_of(x7);
  allocp[63] = x37;
  x38 = cdr_of(a0);
  allocp[64] = x38;
  allocp[65] = x9;
  allocp[66] = x23;
  allocp[67] = a3;
  allocp[68] = x11;
  allocp[69] = a5;
  allocp[70] = x12;
  allocp[71] = a9;
  allocp[72] = x14;
  allocp[73] = x15;
  allocp[74] = x39 = makeref(&allocp[74]);
  allocp[75] = makesym(functor_variable_3);
  allocp[76] = x30;
  allocp[77] = x28;
  allocp[78] = arg(x1, 3);
  x40 = makefunctor(&allocp[75]);
  allocp[79] = makesym(functor_variable_3);
  allocp[80] = x31;
  allocp[81] = x29;
  allocp[82] = arg(x5, 3);
  x41 = makefunctor(&allocp[79]);
  a0 = x24;
  a1 = x25;
  a2 = x26;
  a4 = x40;
  a5 = x41;
  a6 = x22;
  a8 = a7;
  a9 = x13;
  a10 = x34;
  a12 = x32;
  a13 = x33;
  a14 = a3;
  a15 = a11;
  a16 = x15;
  a11 = x35;
  a7 = x21;
  a3 = x27;
  qp = (struct goalrec*)&allocp[45];
  allocp += 83;
  execute(indirect__mode__expansion_17_0);
  goto indirect__mode__expansion_17_ext_interrupt;
 case VARREF:
  deref_and_jump(x8,apply__new__indirect_13_22);
  *reasonp++ =  x8;
  goto apply__new__indirect_13_23;
  };
  goto apply__new__indirect_13_23;
 case VARREF:
  deref_and_jump(x7,apply__new__indirect_13_21);
  *reasonp++ =  x7;
  goto apply__new__indirect_13_23;
  };
  goto apply__new__indirect_13_23;
 case VARREF:
  deref_and_jump(x6,apply__new__indirect_13_20);
  *reasonp++ =  x6;
  goto apply__new__indirect_13_23;
  };
  goto apply__new__indirect_13_23;
 case VARREF:
  deref_and_jump(x5,apply__new__indirect_13_19);
  *reasonp++ =  x5;
  goto apply__new__indirect_13_23;
  };
  goto apply__new__indirect_13_23;
 case VARREF:
  deref_and_jump(x4,apply__new__indirect_13_18);
  *reasonp++ =  x4;
  goto apply__new__indirect_13_23;
  };
  goto apply__new__indirect_13_23;
 case VARREF:
  deref_and_jump(x3,apply__new__indirect_13_17);
  *reasonp++ =  x3;
  goto apply__new__indirect_13_23;
  };
  goto apply__new__indirect_13_23;
 case VARREF:
  deref_and_jump(x2,apply__new__indirect_13_16);
  *reasonp++ =  x2;
  goto apply__new__indirect_13_23;
  };
  goto apply__new__indirect_13_23;
 case VARREF:
  deref_and_jump(x1,apply__new__indirect_13_15);
  *reasonp++ =  x1;
  goto apply__new__indirect_13_23;
  };
  goto apply__new__indirect_13_23;
  };
  goto apply__new__indirect_13_23;
 case VARREF:
  deref_and_jump(x0,apply__new__indirect_13_2);
  *reasonp++ =  x0;
  goto apply__new__indirect_13_23;
  };
  goto apply__new__indirect_13_23;
 case VARREF:
  deref_and_jump(a0,apply__new__indirect_13_1);
  *reasonp++ =  a0;
  goto apply__new__indirect_13_23;
  };
  goto apply__new__indirect_13_23;
 apply__new__indirect_13_23:
  otherwise(apply__new__indirect_13_interrupt);
 apply__new__indirect_13_24:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 apply__new__indirect_13_25:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_unify_2)) goto apply__new__indirect_13_interrupt;
  x1 = arg(x0, 0);
 apply__new__indirect_13_26:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_t_4)) goto apply__new__indirect_13_interrupt;
  x2 = arg(x1, 0);
 apply__new__indirect_13_27:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_v_4)) goto apply__new__indirect_13_interrupt;
  x3 = arg(x0, 1);
 apply__new__indirect_13_28:
  switch (ptagof(x3)) {
 case FUNCTOR:
  if (functor_of(x3) != makesym(functor_t_4)) goto apply__new__indirect_13_interrupt;
  x4 = arg(x3, 3);
 apply__new__indirect_13_29:
  switch (ptagof(x4)) {
 case ATOMIC:
  if (isint(x4)) goto apply__new__indirect_13_interrupt;
  switch (symval(x4)) {
 case symval(makesym(atom_u)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xapply__new__indirect_13);
  x5 = cdr_of(a0);
  allocp[2] = x5;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x6 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x7 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  allocp[12] = a10;
  allocp[13] = a11;
  allocp[14] = a12;
  allocp[15] = (q)(struct goalrec*)&allocp[0];
  allocp[16] = (q)(&predicate_type_xset__types_13);
  x8 = arg(x2, 0);
  allocp[17] = x8;
  x9 = arg(x2, 1);
  allocp[18] = x9;
  allocp[19] = makesym(atom_unify);
  allocp[20] = makeint(-1L);
  x10 = arg(x2, 3);
  allocp[21] = x10;
  allocp[22] = x11 = makeref(&allocp[22]);
  allocp[23] = x12 = makeref(&allocp[23]);
  allocp[24] = a3;
  allocp[25] = x6;
  allocp[26] = a5;
  allocp[27] = x7;
  allocp[28] = a0;
  allocp[29] = x13 = makeref(&allocp[29]);
  allocp[30] = (q)(struct goalrec*)&allocp[15];
  allocp[31] = (q)(&predicate_type_xor__types_3);
  allocp[32] = x14 = makeref(&allocp[32]);
  allocp[33] = makecons(cons_const_0);
  allocp[34] = x12;
  allocp[35] = makesym(functor_goal_4);
  allocp[36] = x8;
  allocp[37] = x9;
  allocp[38] = x16 = makeref(&allocp[38]);
  allocp[39] = x17 = makeref(&allocp[39]);
  x15 = makefunctor(&allocp[35]);
  allocp[40] = NILATOM;
  allocp[41] = x15;
  x18 = makecons(&allocp[40]);
  allocp[42] = NILATOM;
  allocp[43] = x3;
  x19 = makecons(&allocp[42]);
  allocp[44] = (q)(struct goalrec*)&allocp[30];
  allocp[45] = (q)(&predicate_type_xadd__dep__goals_3);
  allocp[46] = x18;
  allocp[47] = x19;
  allocp[48] = x14;
  allocp[49] = (q)(struct goalrec*)&allocp[44];
  allocp[50] = (q)(&predicate_mode_xget__mode_9);
  allocp[51] = x8;
  allocp[52] = x9;
  x20 = arg(x2, 2);
  allocp[53] = x20;
  allocp[54] = x10;
  allocp[55] = a7;
  allocp[56] = x17;
  allocp[57] = x11;
  allocp[58] = x16;
  allocp[59] = a11;
  qp = (struct goalrec*)&allocp[49];
  allocp += 60;
  proceed();
 case symval(makesym(atom_r)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xapply__new__indirect_13);
  allocp[2] = x5 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  allocp[12] = a10;
  allocp[13] = a11;
  allocp[14] = a12;
  allocp[15] = (q)(struct goalrec*)&allocp[0];
  allocp[16] = (q)(&predicate_list_xappend_3);
  x6 = cdr_of(a0);
  allocp[17] = x6;
  allocp[18] = x7 = makeref(&allocp[18]);
  allocp[19] = x5;
  allocp[20] = NILATOM;
  allocp[21] = x1;
  x8 = makecons(&allocp[20]);
  allocp[22] = NILATOM;
  allocp[23] = x3;
  x9 = makecons(&allocp[22]);
  allocp[24] = (q)(struct goalrec*)&allocp[15];
  allocp[25] = (q)(&predicate_type_xand__types_4);
  allocp[26] = x8;
  allocp[27] = x9;
  allocp[28] = x10 = makeref(&allocp[28]);
  allocp[29] = x7;
  qp = (struct goalrec*)&allocp[24];
  allocp += 30;
  proceed();
  };
  goto apply__new__indirect_13_interrupt;
 case VARREF:
  deref_and_jump(x4,apply__new__indirect_13_29);
  *reasonp++ =  x4;
  goto apply__new__indirect_13_interrupt;
  };
  goto apply__new__indirect_13_interrupt;
 case VARREF:
  deref_and_jump(x3,apply__new__indirect_13_28);
  *reasonp++ =  x3;
  goto apply__new__indirect_13_interrupt;
  };
  goto apply__new__indirect_13_interrupt;
 case VARREF:
  deref_and_jump(x2,apply__new__indirect_13_27);
  *reasonp++ =  x2;
  goto apply__new__indirect_13_interrupt;
  };
  goto apply__new__indirect_13_interrupt;
 case VARREF:
  deref_and_jump(x1,apply__new__indirect_13_26);
  *reasonp++ =  x1;
  goto apply__new__indirect_13_interrupt;
  };
  goto apply__new__indirect_13_interrupt;
 case VARREF:
  deref_and_jump(x0,apply__new__indirect_13_25);
  *reasonp++ =  x0;
  goto apply__new__indirect_13_interrupt;
  };
  goto apply__new__indirect_13_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto apply__new__indirect_13_interrupt;
  unify4(a2, a1, a4, a3, a6, a5, a8, a7);
  unify2(a10, a9, a12, a11);
  proceed();
 case VARREF:
  deref_and_jump(a0,apply__new__indirect_13_24);
  *reasonp++ =  a0;
  goto apply__new__indirect_13_interrupt;
  };
  goto apply__new__indirect_13_interrupt;
 apply__new__indirect_13_ext_interrupt:
  reasonp = 0l;
 apply__new__indirect_13_interrupt:
  toppred = &predicate_analyze__type_xapply__new__indirect_13;
  goto interrupt_13;
 }

 apply__new__indirect1_18_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  qp = qp->next;
 apply__new__indirect1_18_clear_reason:
  reasonp = reasons;
 apply__new__indirect1_18_0:
 apply__new__indirect1_18_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto apply__new__indirect1_18_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_i)):
 apply__new__indirect1_18_2:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_o)) goto apply__new__indirect1_18_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xset__types_13);
  allocp[2] = a3;
  allocp[3] = a5;
  allocp[4] = makesym(atom_unify);
  allocp[5] = makeint(-1L);
  allocp[6] = a7;
  allocp[7] = makesym(atom_o);
  allocp[8] = x0 = makeref(&allocp[8]);
  allocp[9] = a14;
  allocp[10] = a15;
  allocp[11] = a16;
  allocp[12] = a17;
  allocp[13] = a12;
  allocp[14] = a13;
  allocp[15] = (q)(struct goalrec*)&allocp[0];
  allocp[16] = (q)(&predicate_type_xor__types_3);
  allocp[17] = x1 = makeref(&allocp[17]);
  allocp[18] = makecons(cons_const_0);
  allocp[19] = x0;
  allocp[20] = makesym(functor_goal_4);
  allocp[21] = a2;
  allocp[22] = a4;
  allocp[23] = a8;
  allocp[24] = a10;
  x2 = makefunctor(&allocp[20]);
  allocp[25] = NILATOM;
  allocp[26] = x2;
  x3 = makecons(&allocp[25]);
  allocp[27] = (q)(struct goalrec*)&allocp[15];
  allocp[28] = (q)(&predicate_type_xadd__dep__goals_3);
  allocp[29] = x3;
  allocp[30] = x4 = makeref(&allocp[30]);
  allocp[31] = x1;
  allocp[32] = (q)(struct goalrec*)&allocp[27];
  allocp[33] = (q)(&predicate_type_xget__types_5);
  allocp[34] = a2;
  allocp[35] = a4;
  allocp[36] = a6;
  allocp[37] = a14;
  allocp[38] = x4;
  qp = (struct goalrec*)&allocp[32];
  allocp += 39;
  proceed();
 case VARREF:
  deref_and_jump(a1,apply__new__indirect1_18_2);
  *reasonp++ =  a1;
  goto apply__new__indirect1_18_interrupt;
  };
  goto apply__new__indirect1_18_interrupt;
 case symval(makesym(atom_o)):
 apply__new__indirect1_18_3:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_i)) goto apply__new__indirect1_18_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xset__types_13);
  allocp[2] = a2;
  allocp[3] = a4;
  allocp[4] = makesym(atom_unify);
  allocp[5] = makeint(-1L);
  allocp[6] = a6;
  allocp[7] = makesym(atom_o);
  allocp[8] = x0 = makeref(&allocp[8]);
  allocp[9] = a14;
  allocp[10] = a15;
  allocp[11] = a16;
  allocp[12] = a17;
  allocp[13] = a12;
  allocp[14] = a13;
  allocp[15] = (q)(struct goalrec*)&allocp[0];
  allocp[16] = (q)(&predicate_type_xor__types_3);
  allocp[17] = x1 = makeref(&allocp[17]);
  allocp[18] = makecons(cons_const_0);
  allocp[19] = x0;
  allocp[20] = makesym(functor_goal_4);
  allocp[21] = a3;
  allocp[22] = a5;
  allocp[23] = a9;
  allocp[24] = a11;
  x2 = makefunctor(&allocp[20]);
  allocp[25] = NILATOM;
  allocp[26] = x2;
  x3 = makecons(&allocp[25]);
  allocp[27] = (q)(struct goalrec*)&allocp[15];
  allocp[28] = (q)(&predicate_type_xadd__dep__goals_3);
  allocp[29] = x3;
  allocp[30] = x4 = makeref(&allocp[30]);
  allocp[31] = x1;
  allocp[32] = (q)(struct goalrec*)&allocp[27];
  allocp[33] = (q)(&predicate_type_xget__types_5);
  allocp[34] = a3;
  allocp[35] = a5;
  allocp[36] = a7;
  allocp[37] = a14;
  allocp[38] = x4;
  qp = (struct goalrec*)&allocp[32];
  allocp += 39;
  proceed();
 case VARREF:
  deref_and_jump(a1,apply__new__indirect1_18_3);
  *reasonp++ =  a1;
  goto apply__new__indirect1_18_interrupt;
  };
  goto apply__new__indirect1_18_interrupt;
 case symval(makesym(atom__3F)):
 apply__new__indirect1_18_4:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom__3F)) goto apply__new__indirect1_18_interrupt;
  unify3(a13, a12, a15, a14, a17, a16);
  proceed();
 case VARREF:
  deref_and_jump(a1,apply__new__indirect1_18_4);
  *reasonp++ =  a1;
  goto apply__new__indirect1_18_interrupt;
  };
  goto apply__new__indirect1_18_interrupt;
  };
  goto apply__new__indirect1_18_interrupt;
 case VARREF:
  deref_and_jump(a0,apply__new__indirect1_18_1);
  *reasonp++ =  a0;
  goto apply__new__indirect1_18_interrupt;
  };
  goto apply__new__indirect1_18_interrupt;
 apply__new__indirect1_18_ext_interrupt:
  reasonp = 0l;
 apply__new__indirect1_18_interrupt:
  goto interrupt_18;
 }

 apply__new__indirect1__alias_28_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  a18 = qp->args[18];
  a19 = qp->args[19];
  a20 = qp->args[20];
  a21 = qp->args[21];
  a22 = qp->args[22];
  a23 = qp->args[23];
  a24 = qp->args[24];
  a25 = qp->args[25];
  a26 = qp->args[26];
  a27 = qp->args[27];
  qp = qp->next;
 apply__new__indirect1__alias_28_clear_reason:
  reasonp = reasons;
 apply__new__indirect1__alias_28_0:
 apply__new__indirect1__alias_28_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (isint(a1)) goto apply__new__indirect1__alias_28_interrupt;
  switch (symval(a1)) {
 case symval(makesym(atom_i)):
 apply__new__indirect1__alias_28_2:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_o)) goto apply__new__indirect1__alias_28_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xset__types_13);
  allocp[2] = a4;
  allocp[3] = a6;
  allocp[4] = makesym(atom_unify);
  allocp[5] = makeint(-1L);
  allocp[6] = a10;
  allocp[7] = makesym(atom_o);
  allocp[8] = x0 = makeref(&allocp[8]);
  allocp[9] = x1 = makeref(&allocp[9]);
  allocp[10] = a21;
  allocp[11] = a22;
  allocp[12] = a23;
  allocp[13] = x2 = makeref(&allocp[13]);
  allocp[14] = a18;
  allocp[15] = (q)(struct goalrec*)&allocp[0];
  allocp[16] = (q)(&predicate_type_xor__types_3);
  allocp[17] = x3 = makeref(&allocp[17]);
  allocp[18] = makecons(cons_const_0);
  allocp[19] = x0;
  allocp[20] = makesym(functor_v_4);
  allocp[21] = a3;
  allocp[22] = a5;
  allocp[23] = a7;
  allocp[24] = a9;
  x4 = makefunctor(&allocp[20]);
  allocp[25] = (q)(struct goalrec*)&allocp[15];
  allocp[26] = (q)(&predicate_analyze__type_xadd__indirect__deps__alias_15);
  allocp[27] = a0;
  allocp[28] = x4;
  allocp[29] = a16;
  allocp[30] = a15;
  allocp[31] = x5 = makeref(&allocp[31]);
  allocp[32] = x3;
  allocp[33] = a20;
  allocp[34] = x1;
  allocp[35] = a17;
  allocp[36] = x2;
  allocp[37] = a19;
  allocp[38] = a24;
  allocp[39] = a25;
  allocp[40] = a26;
  allocp[41] = a27;
  allocp[42] = (q)(struct goalrec*)&allocp[25];
  allocp[43] = (q)(&predicate_type_xget__types_5);
  allocp[44] = a3;
  allocp[45] = a5;
  allocp[46] = a9;
  allocp[47] = a20;
  allocp[48] = x5;
  qp = (struct goalrec*)&allocp[42];
  allocp += 49;
  proceed();
 case VARREF:
  deref_and_jump(a2,apply__new__indirect1__alias_28_2);
  *reasonp++ =  a2;
  goto apply__new__indirect1__alias_28_interrupt;
  };
  goto apply__new__indirect1__alias_28_interrupt;
 case symval(makesym(atom_o)):
 apply__new__indirect1__alias_28_3:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_i)) goto apply__new__indirect1__alias_28_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xset__types_13);
  allocp[2] = a3;
  allocp[3] = a5;
  allocp[4] = makesym(atom_unify);
  allocp[5] = makeint(-1L);
  allocp[6] = a9;
  allocp[7] = makesym(atom_o);
  allocp[8] = x0 = makeref(&allocp[8]);
  allocp[9] = x1 = makeref(&allocp[9]);
  allocp[10] = a21;
  allocp[11] = a22;
  allocp[12] = a23;
  allocp[13] = x2 = makeref(&allocp[13]);
  allocp[14] = a18;
  allocp[15] = (q)(struct goalrec*)&allocp[0];
  allocp[16] = (q)(&predicate_type_xor__types_3);
  allocp[17] = x3 = makeref(&allocp[17]);
  allocp[18] = makecons(cons_const_0);
  allocp[19] = x0;
  allocp[20] = makesym(functor_v_4);
  allocp[21] = a4;
  allocp[22] = a6;
  allocp[23] = a8;
  allocp[24] = a10;
  x4 = makefunctor(&allocp[20]);
  allocp[25] = (q)(struct goalrec*)&allocp[15];
  allocp[26] = (q)(&predicate_analyze__type_xadd__indirect__deps__alias_15);
  allocp[27] = a0;
  allocp[28] = x4;
  allocp[29] = a16;
  allocp[30] = a15;
  allocp[31] = x5 = makeref(&allocp[31]);
  allocp[32] = x3;
  allocp[33] = a20;
  allocp[34] = x1;
  allocp[35] = a17;
  allocp[36] = x2;
  allocp[37] = a19;
  allocp[38] = a24;
  allocp[39] = a25;
  allocp[40] = a26;
  allocp[41] = a27;
  allocp[42] = (q)(struct goalrec*)&allocp[25];
  allocp[43] = (q)(&predicate_type_xget__types_5);
  allocp[44] = a4;
  allocp[45] = a6;
  allocp[46] = a10;
  allocp[47] = a20;
  allocp[48] = x5;
  qp = (struct goalrec*)&allocp[42];
  allocp += 49;
  proceed();
 case VARREF:
  deref_and_jump(a2,apply__new__indirect1__alias_28_3);
  *reasonp++ =  a2;
  goto apply__new__indirect1__alias_28_interrupt;
  };
  goto apply__new__indirect1__alias_28_interrupt;
 case symval(makesym(atom__3F)):
 apply__new__indirect1__alias_28_4:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom__3F)) goto apply__new__indirect1__alias_28_interrupt;
  unify4(a18, a17, a21, a20, a23, a22, a25, a24);
  unify(a27, a26);
  proceed();
 case VARREF:
  deref_and_jump(a2,apply__new__indirect1__alias_28_4);
  *reasonp++ =  a2;
  goto apply__new__indirect1__alias_28_interrupt;
  };
  goto apply__new__indirect1__alias_28_interrupt;
  };
  goto apply__new__indirect1__alias_28_interrupt;
 case VARREF:
  deref_and_jump(a1,apply__new__indirect1__alias_28_1);
  *reasonp++ =  a1;
  goto apply__new__indirect1__alias_28_interrupt;
  };
  goto apply__new__indirect1__alias_28_interrupt;
 apply__new__indirect1__alias_28_ext_interrupt:
  reasonp = 0l;
 apply__new__indirect1__alias_28_interrupt:
  goto interrupt_28;
 }

 add__indirect__deps__alias_15_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  qp = qp->next;
 add__indirect__deps__alias_15_clear_reason:
  reasonp = reasons;
 add__indirect__deps__alias_15_0:
 add__indirect__deps__alias_15_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto add__indirect__deps__alias_15_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_up)):
  unify2(a14, a13, a12, a11);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xmake__types__loopup_9);
  allocp[2] = a4;
  allocp[3] = a5;
  allocp[4] = a2;
  allocp[5] = a1;
  allocp[6] = a6;
  allocp[7] = a7;
  allocp[8] = a8;
  allocp[9] = a9;
  allocp[10] = a10;
  qp = (struct goalrec*)&allocp[0];
  allocp += 11;
  proceed();
 case symval(makesym(atom_down)):
  allocp[0] = NILATOM;
  allocp[1] = a3;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_type_xadd__dep__goals_3);
  allocp[4] = x0;
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = a5;
  allocp[7] = (q)(struct goalrec*)&allocp[2];
  allocp[8] = (q)(&predicate_type_xmake__types__loopdown_16);
  allocp[9] = a4;
  allocp[10] = x1;
  allocp[11] = makesym(atom_dummy);
  allocp[12] = makesym(atom_dummy);
  allocp[13] = makesym(atom_dummy);
  allocp[14] = a2;
  allocp[15] = a1;
  allocp[16] = a6;
  allocp[17] = a7;
  allocp[18] = a8;
  allocp[19] = a9;
  allocp[20] = a10;
  allocp[21] = a11;
  allocp[22] = a12;
  allocp[23] = a13;
  allocp[24] = a14;
  qp = (struct goalrec*)&allocp[7];
  allocp += 25;
  proceed();
  };
  goto add__indirect__deps__alias_15_interrupt;
 case VARREF:
  deref_and_jump(a0,add__indirect__deps__alias_15_1);
  *reasonp++ =  a0;
  goto add__indirect__deps__alias_15_interrupt;
  };
  goto add__indirect__deps__alias_15_interrupt;
 add__indirect__deps__alias_15_ext_interrupt:
  reasonp = 0l;
 add__indirect__deps__alias_15_interrupt:
  toppred = &predicate_analyze__type_xadd__indirect__deps__alias_15;
  goto interrupt_15;
 }

 apply__indirect_16_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20, x21;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  qp = qp->next;
 apply__indirect_16_clear_reason:
  reasonp = reasons;
 apply__indirect_16_0:
  allocp[0] = makesym(functor_variable_3);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  x0 = makefunctor(&allocp[0]);
  allocp[4] = makesym(functor_var_5);
  allocp[5] = x5 = makeref(&allocp[5]);
  allocp[6] = x6 = makeref(&allocp[6]);
  allocp[7] = x7 = makeref(&allocp[7]);
  allocp[8] = x8 = makeref(&allocp[8]);
  allocp[9] = x0;
  x4 = makefunctor(&allocp[4]);
  allocp += 10;
  unify_value(a0, x4);
  a0 = x5;
  x9 = a1;
  x10 = a2;
  x11 = a3;
  x12 = a4;
  x13 = a5;
  x14 = a2;
  x15 = a6;
  x16 = a7;
  x17 = a8;
  x18 = a9;
  x19 = a10;
  x20 = a11;
  x21 = a12;
  a16 = a13;
  a17 = a14;
  a18 = a15;
  a15 = x21;
  a14 = x20;
  a13 = x19;
  a12 = x18;
  a11 = x17;
  a10 = x16;
  a9 = x15;
  a8 = x14;
  a7 = x13;
  a6 = x12;
  a5 = x11;
  a4 = x10;
  a3 = x9;
  a2 = x1;
  a1 = x6;
  execute(apply__indirect1_19_0);
  goto apply__indirect1_19_ext_interrupt;
 apply__indirect_16_ext_interrupt:
  reasonp = 0l;
 apply__indirect_16_interrupt:
  goto interrupt_16;
 }

 apply__indirect1_19_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20, x21, x22, x23, x24, x25, x26, x27, x28, x29, x30, x31, x32, x33, x34, x35, x36, x37;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  a18 = qp->args[18];
  qp = qp->next;
 apply__indirect1_19_clear_reason:
  reasonp = reasons;
 apply__indirect1_19_0:
 apply__indirect1_19_1:
  switch (ptagof(a4)) {
 case CONS:
  x0 = car_of(a4);
 apply__indirect1_19_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_unify_2:
  x1 = arg(x0, 0);
 apply__indirect1_19_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_t_4)) goto apply__indirect1_19_112;
  x2 = arg(x1, 0);
 apply__indirect1_19_4:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_v_4)) goto apply__indirect1_19_112;
  x3 = arg(x2, 0);
 apply__indirect1_19_5:
  if (isref(x3)) goto apply__indirect1_19_18;
 apply__indirect1_19_6:
  if (isref(x3)) goto apply__indirect1_19_17;
  if_not_equal(x3, a0, apply__indirect1_19_19);
  x4 = arg(x2, 1);
 apply__indirect1_19_7:
  if (isref(x4)) goto apply__indirect1_19_16;
 apply__indirect1_19_8:
  if (isref(x4)) goto apply__indirect1_19_15;
  if_not_equal(x4, a1, apply__indirect1_19_19);
  x5 = arg(x2, 3);
 apply__indirect1_19_9:
  if (isref(x5)) goto apply__indirect1_19_14;
 apply__indirect1_19_10:
  if (isref(x5)) goto apply__indirect1_19_13;
  if_not_equal(x5, a2, apply__indirect1_19_19);
  x6 = arg(x0, 1);
 apply__indirect1_19_11:
  switch (ptagof(x6)) {
 case FUNCTOR:
  if (functor_of(x6) != makesym(functor_t_4)) goto apply__indirect1_19_19;
  x7 = arg(x6, 0);
 apply__indirect1_19_12:
  switch (ptagof(x7)) {
 case FUNCTOR:
  if (functor_of(x7) != makesym(functor_v_4)) goto apply__indirect1_19_19;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xapply__indirect2_26);
  allocp[2] = x8 = makeref(&allocp[2]);
  allocp[3] = x9 = makeref(&allocp[3]);
  x10 = arg(x7, 0);
  allocp[4] = x10;
  x11 = arg(x7, 1);
  allocp[5] = x11;
  x12 = arg(x7, 3);
  allocp[6] = x12;
  allocp[7] = x13 = makeref(&allocp[7]);
  allocp[8] = x14 = makeref(&allocp[8]);
  allocp[9] = a0;
  allocp[10] = a1;
  allocp[11] = a2;
  allocp[12] = a3;
  x15 = cdr_of(a4);
  allocp[13] = x15;
  allocp[14] = x16 = makeref(&allocp[14]);
  allocp[15] = a6;
  allocp[16] = a7;
  allocp[17] = a8;
  allocp[18] = a9;
  allocp[19] = a10;
  allocp[20] = a11;
  allocp[21] = a12;
  allocp[22] = x17 = makeref(&allocp[22]);
  allocp[23] = a14;
  allocp[24] = a15;
  allocp[25] = a16;
  allocp[26] = x18 = makeref(&allocp[26]);
  allocp[27] = a18;
  allocp[28] = makesym(functor_unify_2);
  allocp[29] = x20 = makeref(&allocp[29]);
  allocp[30] = x21 = makeref(&allocp[30]);
  x19 = makefunctor(&allocp[28]);
  allocp[31] = x16;
  allocp[32] = x19;
  x22 = makecons(&allocp[31]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 33;
  unify_value(a5, x22);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = makeint(4L);
  allocp[3] = x6;
  allocp[4] = x23 = makeref(&allocp[4]);
  allocp[5] = x21;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[8] = makeint(4L);
  allocp[9] = x1;
  allocp[10] = x24 = makeref(&allocp[10]);
  allocp[11] = x20;
  allocp[12] = (q)(struct goalrec*)&allocp[6];
  allocp[13] = (q)(&predicate_mode_xmode2ru_2);
  allocp[14] = x8;
  allocp[15] = x23;
  allocp[16] = (q)(struct goalrec*)&allocp[12];
  allocp[17] = (q)(&predicate_mode_xmode2ru_2);
  allocp[18] = x9;
  allocp[19] = x24;
  allocp[20] = makesym(functor_variable_3);
  allocp[21] = a2;
  allocp[22] = arg(x2, 2);
  allocp[23] = arg(x1, 3);
  x25 = makefunctor(&allocp[20]);
  allocp[24] = makesym(functor_variable_3);
  allocp[25] = x12;
  allocp[26] = arg(x7, 2);
  allocp[27] = arg(x6, 3);
  x26 = makefunctor(&allocp[24]);
  a2 = a1;
  a3 = x11;
  a4 = x25;
  a5 = x26;
  a6 = x9;
  a7 = x8;
  a8 = a13;
  allocp[28] = x27 = makeref(&allocp[28]);
  a10 = x27;
  a11 = x14;
  allocp[29] = x28 = makeref(&allocp[29]);
  a12 = x28;
  a13 = x13;
  a14 = a9;
  a15 = a17;
  a16 = x18;
  a9 = x17;
  a1 = x10;
  qp = (struct goalrec*)&allocp[16];
  allocp += 30;
  execute(indirect__mode__expansion_17_clear_reason);
  goto indirect__mode__expansion_17_ext_interrupt;
 case VARREF:
  deref_and_jump(x7,apply__indirect1_19_12);
  *reasonp++ =  x7;
  goto apply__indirect1_19_19;
  };
  goto apply__indirect1_19_19;
 case VARREF:
  deref_and_jump(x6,apply__indirect1_19_11);
  *reasonp++ =  x6;
  goto apply__indirect1_19_19;
  };
  goto apply__indirect1_19_19;
 apply__indirect1_19_13:
  deref_and_jump(x5,apply__indirect1_19_10);
  *reasonp++ =  x5;
  goto apply__indirect1_19_19;
 apply__indirect1_19_14:
  deref_and_jump(x5,apply__indirect1_19_9);
  *reasonp++ =  x5;
  goto apply__indirect1_19_19;
 apply__indirect1_19_15:
  deref_and_jump(x4,apply__indirect1_19_8);
  *reasonp++ =  x4;
  goto apply__indirect1_19_19;
 apply__indirect1_19_16:
  deref_and_jump(x4,apply__indirect1_19_7);
  *reasonp++ =  x4;
  goto apply__indirect1_19_19;
 apply__indirect1_19_17:
  deref_and_jump(x3,apply__indirect1_19_6);
  *reasonp++ =  x3;
  goto apply__indirect1_19_19;
 apply__indirect1_19_18:
  deref_and_jump(x3,apply__indirect1_19_5);
  *reasonp++ =  x3;
  goto apply__indirect1_19_19;
 apply__indirect1_19_19:
  x4 = arg(x0, 1);
 apply__indirect1_19_20:
  switch (ptagof(x4)) {
 case FUNCTOR:
  if (functor_of(x4) != makesym(functor_t_4)) goto apply__indirect1_19_112;
  x5 = arg(x4, 0);
 apply__indirect1_19_21:
  switch (ptagof(x5)) {
 case FUNCTOR:
  if (functor_of(x5) != makesym(functor_v_4)) goto apply__indirect1_19_112;
  x6 = arg(x5, 0);
 apply__indirect1_19_22:
  if (isref(x6)) goto apply__indirect1_19_33;
 apply__indirect1_19_23:
  if (isref(x6)) goto apply__indirect1_19_32;
  if_not_equal(x6, a0, apply__indirect1_19_112);
  x7 = arg(x5, 1);
 apply__indirect1_19_24:
  if (isref(x7)) goto apply__indirect1_19_31;
 apply__indirect1_19_25:
  if (isref(x7)) goto apply__indirect1_19_30;
  if_not_equal(x7, a1, apply__indirect1_19_112);
  x8 = arg(x5, 3);
 apply__indirect1_19_26:
  if (isref(x8)) goto apply__indirect1_19_29;
 apply__indirect1_19_27:
  if (isref(x8)) goto apply__indirect1_19_28;
  if_not_equal(x8, a2, apply__indirect1_19_112);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xapply__indirect2_26);
  allocp[2] = x9 = makeref(&allocp[2]);
  allocp[3] = x10 = makeref(&allocp[3]);
  allocp[4] = x3;
  x11 = arg(x2, 1);
  allocp[5] = x11;
  x12 = arg(x2, 3);
  allocp[6] = x12;
  allocp[7] = x13 = makeref(&allocp[7]);
  allocp[8] = x14 = makeref(&allocp[8]);
  allocp[9] = a0;
  allocp[10] = a1;
  allocp[11] = a2;
  allocp[12] = a3;
  x15 = cdr_of(a4);
  allocp[13] = x15;
  allocp[14] = x16 = makeref(&allocp[14]);
  allocp[15] = a6;
  allocp[16] = a7;
  allocp[17] = a8;
  allocp[18] = a9;
  allocp[19] = a10;
  allocp[20] = a11;
  allocp[21] = a12;
  allocp[22] = x17 = makeref(&allocp[22]);
  allocp[23] = a14;
  allocp[24] = a15;
  allocp[25] = a16;
  allocp[26] = x18 = makeref(&allocp[26]);
  allocp[27] = a18;
  allocp[28] = makesym(functor_unify_2);
  allocp[29] = x20 = makeref(&allocp[29]);
  allocp[30] = x21 = makeref(&allocp[30]);
  x19 = makefunctor(&allocp[28]);
  allocp[31] = x16;
  allocp[32] = x19;
  x22 = makecons(&allocp[31]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 33;
  unify_value(a5, x22);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = makeint(4L);
  allocp[3] = x4;
  allocp[4] = x23 = makeref(&allocp[4]);
  allocp[5] = x21;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[8] = makeint(4L);
  allocp[9] = x1;
  allocp[10] = x24 = makeref(&allocp[10]);
  allocp[11] = x20;
  allocp[12] = (q)(struct goalrec*)&allocp[6];
  allocp[13] = (q)(&predicate_mode_xmode2ru_2);
  allocp[14] = x10;
  allocp[15] = x23;
  allocp[16] = (q)(struct goalrec*)&allocp[12];
  allocp[17] = (q)(&predicate_mode_xmode2ru_2);
  allocp[18] = x9;
  allocp[19] = x24;
  allocp[20] = makesym(functor_variable_3);
  allocp[21] = x12;
  allocp[22] = arg(x2, 2);
  allocp[23] = arg(x1, 3);
  x25 = makefunctor(&allocp[20]);
  allocp[24] = makesym(functor_variable_3);
  allocp[25] = a2;
  allocp[26] = arg(x5, 2);
  allocp[27] = arg(x4, 3);
  x26 = makefunctor(&allocp[24]);
  x27 = a0;
  a2 = x11;
  a3 = a1;
  a4 = x25;
  a5 = x26;
  a6 = x9;
  a7 = x10;
  a8 = a13;
  a10 = x14;
  allocp[28] = x28 = makeref(&allocp[28]);
  a11 = x28;
  a12 = x13;
  allocp[29] = x29 = makeref(&allocp[29]);
  a13 = x29;
  a14 = a9;
  a15 = a17;
  a16 = x18;
  a9 = x17;
  a1 = x27;
  a0 = x3;
  qp = (struct goalrec*)&allocp[16];
  allocp += 30;
  execute(indirect__mode__expansion_17_clear_reason);
  goto indirect__mode__expansion_17_ext_interrupt;
 apply__indirect1_19_28:
  deref_and_jump(x8,apply__indirect1_19_27);
  *reasonp++ =  x8;
  goto apply__indirect1_19_112;
 apply__indirect1_19_29:
  deref_and_jump(x8,apply__indirect1_19_26);
  *reasonp++ =  x8;
  goto apply__indirect1_19_112;
 apply__indirect1_19_30:
  deref_and_jump(x7,apply__indirect1_19_25);
  *reasonp++ =  x7;
  goto apply__indirect1_19_112;
 apply__indirect1_19_31:
  deref_and_jump(x7,apply__indirect1_19_24);
  *reasonp++ =  x7;
  goto apply__indirect1_19_112;
 apply__indirect1_19_32:
  deref_and_jump(x6,apply__indirect1_19_23);
  *reasonp++ =  x6;
  goto apply__indirect1_19_112;
 apply__indirect1_19_33:
  deref_and_jump(x6,apply__indirect1_19_22);
  *reasonp++ =  x6;
  goto apply__indirect1_19_112;
 case VARREF:
  deref_and_jump(x5,apply__indirect1_19_21);
  *reasonp++ =  x5;
  goto apply__indirect1_19_112;
  };
  goto apply__indirect1_19_112;
 case VARREF:
  deref_and_jump(x4,apply__indirect1_19_20);
  *reasonp++ =  x4;
  goto apply__indirect1_19_112;
  };
  goto apply__indirect1_19_112;
 case VARREF:
  deref_and_jump(x2,apply__indirect1_19_4);
  *reasonp++ =  x2;
  goto apply__indirect1_19_112;
  };
  goto apply__indirect1_19_112;
 case VARREF:
  deref_and_jump(x1,apply__indirect1_19_3);
  *reasonp++ =  x1;
  goto apply__indirect1_19_112;
  };
  goto apply__indirect1_19_112;
 case functor_unifyaliasdown_2:
  x1 = arg(x0, 0);
 apply__indirect1_19_34:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_t_4)) goto apply__indirect1_19_112;
  x2 = arg(x1, 0);
 apply__indirect1_19_35:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_v_4)) goto apply__indirect1_19_112;
  x3 = arg(x2, 0);
 apply__indirect1_19_36:
  if (isref(x3)) goto apply__indirect1_19_53;
 apply__indirect1_19_37:
  if (isref(x3)) goto apply__indirect1_19_52;
  if_not_equal(x3, a0, apply__indirect1_19_54);
  x4 = arg(x2, 1);
 apply__indirect1_19_38:
  if (isref(x4)) goto apply__indirect1_19_51;
 apply__indirect1_19_39:
  if (isref(x4)) goto apply__indirect1_19_50;
  if_not_equal(x4, a1, apply__indirect1_19_54);
  x5 = arg(x2, 3);
 apply__indirect1_19_40:
  if (isref(x5)) goto apply__indirect1_19_49;
 apply__indirect1_19_41:
  if (isref(x5)) goto apply__indirect1_19_48;
  if_not_equal(x5, a2, apply__indirect1_19_54);
  x6 = arg(x1, 2);
 apply__indirect1_19_42:
  switch (ptagof(x6)) {
 case CONS:
  x7 = cdr_of(x6);
 apply__indirect1_19_43:
  switch (ptagof(x7)) {
 case ATOMIC:
  if (x7 != NILATOM) goto apply__indirect1_19_54;
  x8 = arg(x0, 1);
 apply__indirect1_19_44:
  switch (ptagof(x8)) {
 case FUNCTOR:
  if (functor_of(x8) != makesym(functor_t_4)) goto apply__indirect1_19_54;
  x9 = arg(x8, 0);
 apply__indirect1_19_45:
  switch (ptagof(x9)) {
 case FUNCTOR:
  if (functor_of(x9) != makesym(functor_v_4)) goto apply__indirect1_19_54;
  x10 = arg(x8, 2);
 apply__indirect1_19_46:
  switch (ptagof(x10)) {
 case CONS:
  x11 = cdr_of(x10);
 apply__indirect1_19_47:
  switch (ptagof(x11)) {
 case ATOMIC:
  if (x11 != NILATOM) goto apply__indirect1_19_54;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xapply__indirect2__alias_31);
  allocp[2] = makesym(atom_up);
  x12 = car_of(x10);
  allocp[3] = x12;
  x13 = car_of(x6);
  allocp[4] = x13;
  allocp[5] = x14 = makeref(&allocp[5]);
  allocp[6] = x15 = makeref(&allocp[6]);
  x16 = arg(x9, 0);
  allocp[7] = x16;
  x17 = arg(x9, 1);
  allocp[8] = x17;
  x18 = arg(x9, 2);
  allocp[9] = x18;
  x19 = arg(x9, 3);
  allocp[10] = x19;
  allocp[11] = x20 = makeref(&allocp[11]);
  allocp[12] = x21 = makeref(&allocp[12]);
  allocp[13] = a0;
  allocp[14] = a1;
  x22 = arg(x2, 2);
  allocp[15] = x22;
  allocp[16] = a2;
  allocp[17] = a3;
  x23 = cdr_of(a4);
  allocp[18] = x23;
  allocp[19] = x24 = makeref(&allocp[19]);
  allocp[20] = a6;
  allocp[21] = a7;
  allocp[22] = a8;
  allocp[23] = a9;
  allocp[24] = a10;
  allocp[25] = a11;
  allocp[26] = a12;
  allocp[27] = x25 = makeref(&allocp[27]);
  allocp[28] = a14;
  allocp[29] = a15;
  allocp[30] = a16;
  allocp[31] = x26 = makeref(&allocp[31]);
  allocp[32] = a18;
  allocp[33] = makesym(functor_unifyaliasdown_2);
  allocp[34] = x28 = makeref(&allocp[34]);
  allocp[35] = x29 = makeref(&allocp[35]);
  x27 = makefunctor(&allocp[33]);
  allocp[36] = x24;
  allocp[37] = x27;
  x30 = makecons(&allocp[36]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 38;
  unify_value(a5, x30);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = makeint(4L);
  allocp[3] = x8;
  allocp[4] = x31 = makeref(&allocp[4]);
  allocp[5] = x29;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[8] = makeint(4L);
  allocp[9] = x1;
  allocp[10] = x32 = makeref(&allocp[10]);
  allocp[11] = x28;
  allocp[12] = (q)(struct goalrec*)&allocp[6];
  allocp[13] = (q)(&predicate_mode_xmode2ru_2);
  allocp[14] = x14;
  allocp[15] = x31;
  allocp[16] = (q)(struct goalrec*)&allocp[12];
  allocp[17] = (q)(&predicate_mode_xmode2ru_2);
  allocp[18] = x15;
  allocp[19] = x32;
  allocp[20] = makesym(functor_variable_3);
  allocp[21] = a2;
  allocp[22] = x22;
  allocp[23] = arg(x1, 3);
  x33 = makefunctor(&allocp[20]);
  allocp[24] = makesym(functor_variable_3);
  allocp[25] = x19;
  allocp[26] = x18;
  allocp[27] = arg(x8, 3);
  x34 = makefunctor(&allocp[24]);
  a2 = a1;
  a3 = x17;
  a4 = x33;
  a5 = x34;
  a6 = x15;
  a7 = x14;
  a8 = a13;
  allocp[28] = x35 = makeref(&allocp[28]);
  a10 = x35;
  a11 = x21;
  allocp[29] = x36 = makeref(&allocp[29]);
  a12 = x36;
  a13 = x20;
  a14 = a9;
  a15 = a17;
  a16 = x26;
  a9 = x25;
  a1 = x16;
  qp = (struct goalrec*)&allocp[16];
  allocp += 30;
  execute(indirect__mode__expansion_17_clear_reason);
  goto indirect__mode__expansion_17_ext_interrupt;
 case VARREF:
  deref_and_jump(x11,apply__indirect1_19_47);
  *reasonp++ =  x11;
  goto apply__indirect1_19_54;
  };
  goto apply__indirect1_19_54;
 case VARREF:
  deref_and_jump(x10,apply__indirect1_19_46);
  *reasonp++ =  x10;
  goto apply__indirect1_19_54;
  };
  goto apply__indirect1_19_54;
 case VARREF:
  deref_and_jump(x9,apply__indirect1_19_45);
  *reasonp++ =  x9;
  goto apply__indirect1_19_54;
  };
  goto apply__indirect1_19_54;
 case VARREF:
  deref_and_jump(x8,apply__indirect1_19_44);
  *reasonp++ =  x8;
  goto apply__indirect1_19_54;
  };
  goto apply__indirect1_19_54;
 case VARREF:
  deref_and_jump(x7,apply__indirect1_19_43);
  *reasonp++ =  x7;
  goto apply__indirect1_19_54;
  };
  goto apply__indirect1_19_54;
 case VARREF:
  deref_and_jump(x6,apply__indirect1_19_42);
  *reasonp++ =  x6;
  goto apply__indirect1_19_54;
  };
  goto apply__indirect1_19_54;
 apply__indirect1_19_48:
  deref_and_jump(x5,apply__indirect1_19_41);
  *reasonp++ =  x5;
  goto apply__indirect1_19_54;
 apply__indirect1_19_49:
  deref_and_jump(x5,apply__indirect1_19_40);
  *reasonp++ =  x5;
  goto apply__indirect1_19_54;
 apply__indirect1_19_50:
  deref_and_jump(x4,apply__indirect1_19_39);
  *reasonp++ =  x4;
  goto apply__indirect1_19_54;
 apply__indirect1_19_51:
  deref_and_jump(x4,apply__indirect1_19_38);
  *reasonp++ =  x4;
  goto apply__indirect1_19_54;
 apply__indirect1_19_52:
  deref_and_jump(x3,apply__indirect1_19_37);
  *reasonp++ =  x3;
  goto apply__indirect1_19_54;
 apply__indirect1_19_53:
  deref_and_jump(x3,apply__indirect1_19_36);
  *reasonp++ =  x3;
  goto apply__indirect1_19_54;
 apply__indirect1_19_54:
  x4 = arg(x1, 2);
 apply__indirect1_19_55:
  switch (ptagof(x4)) {
 case CONS:
  x5 = cdr_of(x4);
 apply__indirect1_19_56:
  switch (ptagof(x5)) {
 case ATOMIC:
  if (x5 != NILATOM) goto apply__indirect1_19_112;
  x6 = arg(x0, 1);
 apply__indirect1_19_57:
  switch (ptagof(x6)) {
 case FUNCTOR:
  if (functor_of(x6) != makesym(functor_t_4)) goto apply__indirect1_19_112;
  x7 = arg(x6, 0);
 apply__indirect1_19_58:
  switch (ptagof(x7)) {
 case FUNCTOR:
  if (functor_of(x7) != makesym(functor_v_4)) goto apply__indirect1_19_112;
  x8 = arg(x7, 0);
 apply__indirect1_19_59:
  if (isref(x8)) goto apply__indirect1_19_72;
 apply__indirect1_19_60:
  if (isref(x8)) goto apply__indirect1_19_71;
  if_not_equal(x8, a0, apply__indirect1_19_112);
  x9 = arg(x7, 1);
 apply__indirect1_19_61:
  if (isref(x9)) goto apply__indirect1_19_70;
 apply__indirect1_19_62:
  if (isref(x9)) goto apply__indirect1_19_69;
  if_not_equal(x9, a1, apply__indirect1_19_112);
  x10 = arg(x7, 3);
 apply__indirect1_19_63:
  if (isref(x10)) goto apply__indirect1_19_68;
 apply__indirect1_19_64:
  if (isref(x10)) goto apply__indirect1_19_67;
  if_not_equal(x10, a2, apply__indirect1_19_112);
  x11 = arg(x6, 2);
 apply__indirect1_19_65:
  switch (ptagof(x11)) {
 case CONS:
  x12 = cdr_of(x11);
 apply__indirect1_19_66:
  switch (ptagof(x12)) {
 case ATOMIC:
  if (x12 != NILATOM) goto apply__indirect1_19_112;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xapply__indirect2__alias_31);
  allocp[2] = makesym(atom_down);
  x13 = car_of(x11);
  allocp[3] = x13;
  x14 = car_of(x4);
  allocp[4] = x14;
  allocp[5] = x15 = makeref(&allocp[5]);
  allocp[6] = x16 = makeref(&allocp[6]);
  allocp[7] = x3;
  x17 = arg(x2, 1);
  allocp[8] = x17;
  x18 = arg(x2, 2);
  allocp[9] = x18;
  x19 = arg(x2, 3);
  allocp[10] = x19;
  allocp[11] = x20 = makeref(&allocp[11]);
  allocp[12] = x21 = makeref(&allocp[12]);
  allocp[13] = a0;
  allocp[14] = a1;
  x22 = arg(x7, 2);
  allocp[15] = x22;
  allocp[16] = a2;
  allocp[17] = a3;
  x23 = cdr_of(a4);
  allocp[18] = x23;
  allocp[19] = x24 = makeref(&allocp[19]);
  allocp[20] = a6;
  allocp[21] = a7;
  allocp[22] = a8;
  allocp[23] = a9;
  allocp[24] = a10;
  allocp[25] = a11;
  allocp[26] = a12;
  allocp[27] = x25 = makeref(&allocp[27]);
  allocp[28] = a14;
  allocp[29] = a15;
  allocp[30] = a16;
  allocp[31] = x26 = makeref(&allocp[31]);
  allocp[32] = a18;
  allocp[33] = makesym(functor_unifyaliasdown_2);
  allocp[34] = x28 = makeref(&allocp[34]);
  allocp[35] = x29 = makeref(&allocp[35]);
  x27 = makefunctor(&allocp[33]);
  allocp[36] = x24;
  allocp[37] = x27;
  x30 = makecons(&allocp[36]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 38;
  unify_value(a5, x30);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = makeint(4L);
  allocp[3] = x6;
  allocp[4] = x31 = makeref(&allocp[4]);
  allocp[5] = x29;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[8] = makeint(4L);
  allocp[9] = x1;
  allocp[10] = x32 = makeref(&allocp[10]);
  allocp[11] = x28;
  allocp[12] = (q)(struct goalrec*)&allocp[6];
  allocp[13] = (q)(&predicate_mode_xmode2ru_2);
  allocp[14] = x16;
  allocp[15] = x31;
  allocp[16] = (q)(struct goalrec*)&allocp[12];
  allocp[17] = (q)(&predicate_mode_xmode2ru_2);
  allocp[18] = x15;
  allocp[19] = x32;
  allocp[20] = makesym(functor_variable_3);
  allocp[21] = x19;
  allocp[22] = x18;
  allocp[23] = arg(x1, 3);
  x33 = makefunctor(&allocp[20]);
  allocp[24] = makesym(functor_variable_3);
  allocp[25] = a2;
  allocp[26] = x22;
  allocp[27] = arg(x6, 3);
  x34 = makefunctor(&allocp[24]);
  x35 = a0;
  a2 = x17;
  a3 = a1;
  a4 = x33;
  a5 = x34;
  a6 = x15;
  a7 = x16;
  a8 = a13;
  a10 = x21;
  allocp[28] = x36 = makeref(&allocp[28]);
  a11 = x36;
  a12 = x20;
  allocp[29] = x37 = makeref(&allocp[29]);
  a13 = x37;
  a14 = a9;
  a15 = a17;
  a16 = x26;
  a9 = x25;
  a1 = x35;
  a0 = x3;
  qp = (struct goalrec*)&allocp[16];
  allocp += 30;
  execute(indirect__mode__expansion_17_clear_reason);
  goto indirect__mode__expansion_17_ext_interrupt;
 case VARREF:
  deref_and_jump(x12,apply__indirect1_19_66);
  *reasonp++ =  x12;
  goto apply__indirect1_19_112;
  };
  goto apply__indirect1_19_112;
 case VARREF:
  deref_and_jump(x11,apply__indirect1_19_65);
  *reasonp++ =  x11;
  goto apply__indirect1_19_112;
  };
  goto apply__indirect1_19_112;
 apply__indirect1_19_67:
  deref_and_jump(x10,apply__indirect1_19_64);
  *reasonp++ =  x10;
  goto apply__indirect1_19_112;
 apply__indirect1_19_68:
  deref_and_jump(x10,apply__indirect1_19_63);
  *reasonp++ =  x10;
  goto apply__indirect1_19_112;
 apply__indirect1_19_69:
  deref_and_jump(x9,apply__indirect1_19_62);
  *reasonp++ =  x9;
  goto apply__indirect1_19_112;
 apply__indirect1_19_70:
  deref_and_jump(x9,apply__indirect1_19_61);
  *reasonp++ =  x9;
  goto apply__indirect1_19_112;
 apply__indirect1_19_71:
  deref_and_jump(x8,apply__indirect1_19_60);
  *reasonp++ =  x8;
  goto apply__indirect1_19_112;
 apply__indirect1_19_72:
  deref_and_jump(x8,apply__indirect1_19_59);
  *reasonp++ =  x8;
  goto apply__indirect1_19_112;
 case VARREF:
  deref_and_jump(x7,apply__indirect1_19_58);
  *reasonp++ =  x7;
  goto apply__indirect1_19_112;
  };
  goto apply__indirect1_19_112;
 case VARREF:
  deref_and_jump(x6,apply__indirect1_19_57);
  *reasonp++ =  x6;
  goto apply__indirect1_19_112;
  };
  goto apply__indirect1_19_112;
 case VARREF:
  deref_and_jump(x5,apply__indirect1_19_56);
  *reasonp++ =  x5;
  goto apply__indirect1_19_112;
  };
  goto apply__indirect1_19_112;
 case VARREF:
  deref_and_jump(x4,apply__indirect1_19_55);
  *reasonp++ =  x4;
  goto apply__indirect1_19_112;
  };
  goto apply__indirect1_19_112;
 case VARREF:
  deref_and_jump(x2,apply__indirect1_19_35);
  *reasonp++ =  x2;
  goto apply__indirect1_19_112;
  };
  goto apply__indirect1_19_112;
 case VARREF:
  deref_and_jump(x1,apply__indirect1_19_34);
  *reasonp++ =  x1;
  goto apply__indirect1_19_112;
  };
  goto apply__indirect1_19_112;
 case functor_unifyaliasup_2:
  x1 = arg(x0, 0);
 apply__indirect1_19_73:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_t_4)) goto apply__indirect1_19_112;
  x2 = arg(x1, 0);
 apply__indirect1_19_74:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_v_4)) goto apply__indirect1_19_112;
  x3 = arg(x2, 0);
 apply__indirect1_19_75:
  if (isref(x3)) goto apply__indirect1_19_92;
 apply__indirect1_19_76:
  if (isref(x3)) goto apply__indirect1_19_91;
  if_not_equal(x3, a0, apply__indirect1_19_93);
  x4 = arg(x2, 1);
 apply__indirect1_19_77:
  if (isref(x4)) goto apply__indirect1_19_90;
 apply__indirect1_19_78:
  if (isref(x4)) goto apply__indirect1_19_89;
  if_not_equal(x4, a1, apply__indirect1_19_93);
  x5 = arg(x2, 3);
 apply__indirect1_19_79:
  if (isref(x5)) goto apply__indirect1_19_88;
 apply__indirect1_19_80:
  if (isref(x5)) goto apply__indirect1_19_87;
  if_not_equal(x5, a2, apply__indirect1_19_93);
  x6 = arg(x1, 2);
 apply__indirect1_19_81:
  switch (ptagof(x6)) {
 case CONS:
  x7 = cdr_of(x6);
 apply__indirect1_19_82:
  switch (ptagof(x7)) {
 case ATOMIC:
  if (x7 != NILATOM) goto apply__indirect1_19_93;
  x8 = arg(x0, 1);
 apply__indirect1_19_83:
  switch (ptagof(x8)) {
 case FUNCTOR:
  if (functor_of(x8) != makesym(functor_t_4)) goto apply__indirect1_19_93;
  x9 = arg(x8, 0);
 apply__indirect1_19_84:
  switch (ptagof(x9)) {
 case FUNCTOR:
  if (functor_of(x9) != makesym(functor_v_4)) goto apply__indirect1_19_93;
  x10 = arg(x8, 2);
 apply__indirect1_19_85:
  switch (ptagof(x10)) {
 case CONS:
  x11 = cdr_of(x10);
 apply__indirect1_19_86:
  switch (ptagof(x11)) {
 case ATOMIC:
  if (x11 != NILATOM) goto apply__indirect1_19_93;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xapply__indirect2__alias_31);
  allocp[2] = makesym(atom_down);
  x12 = car_of(x10);
  allocp[3] = x12;
  x13 = car_of(x6);
  allocp[4] = x13;
  allocp[5] = x14 = makeref(&allocp[5]);
  allocp[6] = x15 = makeref(&allocp[6]);
  x16 = arg(x9, 0);
  allocp[7] = x16;
  x17 = arg(x9, 1);
  allocp[8] = x17;
  x18 = arg(x9, 2);
  allocp[9] = x18;
  x19 = arg(x9, 3);
  allocp[10] = x19;
  allocp[11] = x20 = makeref(&allocp[11]);
  allocp[12] = x21 = makeref(&allocp[12]);
  allocp[13] = a0;
  allocp[14] = a1;
  x22 = arg(x2, 2);
  allocp[15] = x22;
  allocp[16] = a2;
  allocp[17] = a3;
  x23 = cdr_of(a4);
  allocp[18] = x23;
  allocp[19] = x24 = makeref(&allocp[19]);
  allocp[20] = a6;
  allocp[21] = a7;
  allocp[22] = a8;
  allocp[23] = a9;
  allocp[24] = a10;
  allocp[25] = a11;
  allocp[26] = a12;
  allocp[27] = x25 = makeref(&allocp[27]);
  allocp[28] = a14;
  allocp[29] = a15;
  allocp[30] = a16;
  allocp[31] = x26 = makeref(&allocp[31]);
  allocp[32] = a18;
  allocp[33] = makesym(functor_unifyaliasup_2);
  allocp[34] = x28 = makeref(&allocp[34]);
  allocp[35] = x29 = makeref(&allocp[35]);
  x27 = makefunctor(&allocp[33]);
  allocp[36] = x24;
  allocp[37] = x27;
  x30 = makecons(&allocp[36]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 38;
  unify_value(a5, x30);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = makeint(4L);
  allocp[3] = x8;
  allocp[4] = x31 = makeref(&allocp[4]);
  allocp[5] = x29;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[8] = makeint(4L);
  allocp[9] = x1;
  allocp[10] = x32 = makeref(&allocp[10]);
  allocp[11] = x28;
  allocp[12] = (q)(struct goalrec*)&allocp[6];
  allocp[13] = (q)(&predicate_mode_xmode2ru_2);
  allocp[14] = x14;
  allocp[15] = x31;
  allocp[16] = (q)(struct goalrec*)&allocp[12];
  allocp[17] = (q)(&predicate_mode_xmode2ru_2);
  allocp[18] = x15;
  allocp[19] = x32;
  allocp[20] = makesym(functor_variable_3);
  allocp[21] = a2;
  allocp[22] = x22;
  allocp[23] = arg(x1, 3);
  x33 = makefunctor(&allocp[20]);
  allocp[24] = makesym(functor_variable_3);
  allocp[25] = x19;
  allocp[26] = x18;
  allocp[27] = arg(x8, 3);
  x34 = makefunctor(&allocp[24]);
  a2 = a1;
  a3 = x17;
  a4 = x33;
  a5 = x34;
  a6 = x15;
  a7 = x14;
  a8 = a13;
  allocp[28] = x35 = makeref(&allocp[28]);
  a10 = x35;
  a11 = x21;
  allocp[29] = x36 = makeref(&allocp[29]);
  a12 = x36;
  a13 = x20;
  a14 = a9;
  a15 = a17;
  a16 = x26;
  a9 = x25;
  a1 = x16;
  qp = (struct goalrec*)&allocp[16];
  allocp += 30;
  execute(indirect__mode__expansion_17_clear_reason);
  goto indirect__mode__expansion_17_ext_interrupt;
 case VARREF:
  deref_and_jump(x11,apply__indirect1_19_86);
  *reasonp++ =  x11;
  goto apply__indirect1_19_93;
  };
  goto apply__indirect1_19_93;
 case VARREF:
  deref_and_jump(x10,apply__indirect1_19_85);
  *reasonp++ =  x10;
  goto apply__indirect1_19_93;
  };
  goto apply__indirect1_19_93;
 case VARREF:
  deref_and_jump(x9,apply__indirect1_19_84);
  *reasonp++ =  x9;
  goto apply__indirect1_19_93;
  };
  goto apply__indirect1_19_93;
 case VARREF:
  deref_and_jump(x8,apply__indirect1_19_83);
  *reasonp++ =  x8;
  goto apply__indirect1_19_93;
  };
  goto apply__indirect1_19_93;
 case VARREF:
  deref_and_jump(x7,apply__indirect1_19_82);
  *reasonp++ =  x7;
  goto apply__indirect1_19_93;
  };
  goto apply__indirect1_19_93;
 case VARREF:
  deref_and_jump(x6,apply__indirect1_19_81);
  *reasonp++ =  x6;
  goto apply__indirect1_19_93;
  };
  goto apply__indirect1_19_93;
 apply__indirect1_19_87:
  deref_and_jump(x5,apply__indirect1_19_80);
  *reasonp++ =  x5;
  goto apply__indirect1_19_93;
 apply__indirect1_19_88:
  deref_and_jump(x5,apply__indirect1_19_79);
  *reasonp++ =  x5;
  goto apply__indirect1_19_93;
 apply__indirect1_19_89:
  deref_and_jump(x4,apply__indirect1_19_78);
  *reasonp++ =  x4;
  goto apply__indirect1_19_93;
 apply__indirect1_19_90:
  deref_and_jump(x4,apply__indirect1_19_77);
  *reasonp++ =  x4;
  goto apply__indirect1_19_93;
 apply__indirect1_19_91:
  deref_and_jump(x3,apply__indirect1_19_76);
  *reasonp++ =  x3;
  goto apply__indirect1_19_93;
 apply__indirect1_19_92:
  deref_and_jump(x3,apply__indirect1_19_75);
  *reasonp++ =  x3;
  goto apply__indirect1_19_93;
 apply__indirect1_19_93:
  x4 = arg(x1, 2);
 apply__indirect1_19_94:
  switch (ptagof(x4)) {
 case CONS:
  x5 = cdr_of(x4);
 apply__indirect1_19_95:
  switch (ptagof(x5)) {
 case ATOMIC:
  if (x5 != NILATOM) goto apply__indirect1_19_112;
  x6 = arg(x0, 1);
 apply__indirect1_19_96:
  switch (ptagof(x6)) {
 case FUNCTOR:
  if (functor_of(x6) != makesym(functor_t_4)) goto apply__indirect1_19_112;
  x7 = arg(x6, 0);
 apply__indirect1_19_97:
  switch (ptagof(x7)) {
 case FUNCTOR:
  if (functor_of(x7) != makesym(functor_v_4)) goto apply__indirect1_19_112;
  x8 = arg(x7, 0);
 apply__indirect1_19_98:
  if (isref(x8)) goto apply__indirect1_19_111;
 apply__indirect1_19_99:
  if (isref(x8)) goto apply__indirect1_19_110;
  if_not_equal(x8, a0, apply__indirect1_19_112);
  x9 = arg(x7, 1);
 apply__indirect1_19_100:
  if (isref(x9)) goto apply__indirect1_19_109;
 apply__indirect1_19_101:
  if (isref(x9)) goto apply__indirect1_19_108;
  if_not_equal(x9, a1, apply__indirect1_19_112);
  x10 = arg(x7, 3);
 apply__indirect1_19_102:
  if (isref(x10)) goto apply__indirect1_19_107;
 apply__indirect1_19_103:
  if (isref(x10)) goto apply__indirect1_19_106;
  if_not_equal(x10, a2, apply__indirect1_19_112);
  x11 = arg(x6, 2);
 apply__indirect1_19_104:
  switch (ptagof(x11)) {
 case CONS:
  x12 = cdr_of(x11);
 apply__indirect1_19_105:
  switch (ptagof(x12)) {
 case ATOMIC:
  if (x12 != NILATOM) goto apply__indirect1_19_112;
  allocp[0] = NILATOM;
  allocp[1] = car_of(x4);
  x13 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_analyze__type_xapply__indirect2__alias_31);
  allocp[4] = makesym(atom_up);
  x14 = car_of(x11);
  allocp[5] = x14;
  allocp[6] = x13;
  allocp[7] = x15 = makeref(&allocp[7]);
  allocp[8] = x16 = makeref(&allocp[8]);
  allocp[9] = x3;
  x17 = arg(x2, 1);
  allocp[10] = x17;
  x18 = arg(x2, 2);
  allocp[11] = x18;
  x19 = arg(x2, 3);
  allocp[12] = x19;
  allocp[13] = x20 = makeref(&allocp[13]);
  allocp[14] = x21 = makeref(&allocp[14]);
  allocp[15] = a0;
  allocp[16] = a1;
  x22 = arg(x7, 2);
  allocp[17] = x22;
  allocp[18] = a2;
  allocp[19] = a3;
  x23 = cdr_of(a4);
  allocp[20] = x23;
  allocp[21] = x24 = makeref(&allocp[21]);
  allocp[22] = a6;
  allocp[23] = a7;
  allocp[24] = a8;
  allocp[25] = a9;
  allocp[26] = a10;
  allocp[27] = a11;
  allocp[28] = a12;
  allocp[29] = x25 = makeref(&allocp[29]);
  allocp[30] = a14;
  allocp[31] = a15;
  allocp[32] = a16;
  allocp[33] = x26 = makeref(&allocp[33]);
  allocp[34] = a18;
  allocp[35] = makesym(functor_unifyaliasup_2);
  allocp[36] = x28 = makeref(&allocp[36]);
  allocp[37] = x29 = makeref(&allocp[37]);
  x27 = makefunctor(&allocp[35]);
  allocp[38] = x24;
  allocp[39] = x27;
  x30 = makecons(&allocp[38]);
  qp = (struct goalrec*)&allocp[2];
  allocp += 40;
  unify_value(a5, x30);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = makeint(4L);
  allocp[3] = x6;
  allocp[4] = x31 = makeref(&allocp[4]);
  allocp[5] = x29;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[8] = makeint(4L);
  allocp[9] = x1;
  allocp[10] = x32 = makeref(&allocp[10]);
  allocp[11] = x28;
  allocp[12] = (q)(struct goalrec*)&allocp[6];
  allocp[13] = (q)(&predicate_mode_xmode2ru_2);
  allocp[14] = x16;
  allocp[15] = x31;
  allocp[16] = (q)(struct goalrec*)&allocp[12];
  allocp[17] = (q)(&predicate_mode_xmode2ru_2);
  allocp[18] = x15;
  allocp[19] = x32;
  allocp[20] = makesym(functor_variable_3);
  allocp[21] = x19;
  allocp[22] = x18;
  allocp[23] = arg(x1, 3);
  x33 = makefunctor(&allocp[20]);
  allocp[24] = makesym(functor_variable_3);
  allocp[25] = a2;
  allocp[26] = x22;
  allocp[27] = arg(x6, 3);
  x34 = makefunctor(&allocp[24]);
  x35 = a0;
  a2 = x17;
  a3 = a1;
  a4 = x33;
  a5 = x34;
  a6 = x15;
  a7 = x16;
  a8 = a13;
  a10 = x21;
  allocp[28] = x36 = makeref(&allocp[28]);
  a11 = x36;
  a12 = x20;
  allocp[29] = x37 = makeref(&allocp[29]);
  a13 = x37;
  a14 = a9;
  a15 = a17;
  a16 = x26;
  a9 = x25;
  a1 = x35;
  a0 = x3;
  qp = (struct goalrec*)&allocp[16];
  allocp += 30;
  execute(indirect__mode__expansion_17_clear_reason);
  goto indirect__mode__expansion_17_ext_interrupt;
 case VARREF:
  deref_and_jump(x12,apply__indirect1_19_105);
  *reasonp++ =  x12;
  goto apply__indirect1_19_112;
  };
  goto apply__indirect1_19_112;
 case VARREF:
  deref_and_jump(x11,apply__indirect1_19_104);
  *reasonp++ =  x11;
  goto apply__indirect1_19_112;
  };
  goto apply__indirect1_19_112;
 apply__indirect1_19_106:
  deref_and_jump(x10,apply__indirect1_19_103);
  *reasonp++ =  x10;
  goto apply__indirect1_19_112;
 apply__indirect1_19_107:
  deref_and_jump(x10,apply__indirect1_19_102);
  *reasonp++ =  x10;
  goto apply__indirect1_19_112;
 apply__indirect1_19_108:
  deref_and_jump(x9,apply__indirect1_19_101);
  *reasonp++ =  x9;
  goto apply__indirect1_19_112;
 apply__indirect1_19_109:
  deref_and_jump(x9,apply__indirect1_19_100);
  *reasonp++ =  x9;
  goto apply__indirect1_19_112;
 apply__indirect1_19_110:
  deref_and_jump(x8,apply__indirect1_19_99);
  *reasonp++ =  x8;
  goto apply__indirect1_19_112;
 apply__indirect1_19_111:
  deref_and_jump(x8,apply__indirect1_19_98);
  *reasonp++ =  x8;
  goto apply__indirect1_19_112;
 case VARREF:
  deref_and_jump(x7,apply__indirect1_19_97);
  *reasonp++ =  x7;
  goto apply__indirect1_19_112;
  };
  goto apply__indirect1_19_112;
 case VARREF:
  deref_and_jump(x6,apply__indirect1_19_96);
  *reasonp++ =  x6;
  goto apply__indirect1_19_112;
  };
  goto apply__indirect1_19_112;
 case VARREF:
  deref_and_jump(x5,apply__indirect1_19_95);
  *reasonp++ =  x5;
  goto apply__indirect1_19_112;
  };
  goto apply__indirect1_19_112;
 case VARREF:
  deref_and_jump(x4,apply__indirect1_19_94);
  *reasonp++ =  x4;
  goto apply__indirect1_19_112;
  };
  goto apply__indirect1_19_112;
 case VARREF:
  deref_and_jump(x2,apply__indirect1_19_74);
  *reasonp++ =  x2;
  goto apply__indirect1_19_112;
  };
  goto apply__indirect1_19_112;
 case VARREF:
  deref_and_jump(x1,apply__indirect1_19_73);
  *reasonp++ =  x1;
  goto apply__indirect1_19_112;
  };
  goto apply__indirect1_19_112;
  };
  goto apply__indirect1_19_112;
 case VARREF:
  deref_and_jump(x0,apply__indirect1_19_2);
  *reasonp++ =  x0;
  goto apply__indirect1_19_112;
  };
  goto apply__indirect1_19_112;
 case VARREF:
  deref_and_jump(a4,apply__indirect1_19_1);
  *reasonp++ =  a4;
  goto apply__indirect1_19_112;
  };
  goto apply__indirect1_19_112;
 apply__indirect1_19_112:
  otherwise(apply__indirect1_19_interrupt);
 apply__indirect1_19_113:
  switch (ptagof(a4)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = car_of(a4);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a5, x0);
  a4 = cdr_of(a4);
  a5 = x1;
  execute(apply__indirect1_19_0);
  goto apply__indirect1_19_ext_interrupt;
 case ATOMIC:
  if (a4 != NILATOM) goto apply__indirect1_19_interrupt;
  unify_value(a5, NILATOM);
  unify4(a7, a6, a10, a9, a12, a11, a14, a13);
  unify2(a16, a15, a18, a17);
  proceed();
 case VARREF:
  deref_and_jump(a4,apply__indirect1_19_113);
  *reasonp++ =  a4;
  goto apply__indirect1_19_interrupt;
  };
  goto apply__indirect1_19_interrupt;
 apply__indirect1_19_ext_interrupt:
  reasonp = 0l;
 apply__indirect1_19_interrupt:
  toppred = &predicate_analyze__type_xapply__indirect1_19;
  goto interrupt_19;
 }

 apply__indirect2_26_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  a18 = qp->args[18];
  a19 = qp->args[19];
  a20 = qp->args[20];
  a21 = qp->args[21];
  a22 = qp->args[22];
  a23 = qp->args[23];
  a24 = qp->args[24];
  a25 = qp->args[25];
  qp = qp->next;
 apply__indirect2_26_clear_reason:
  reasonp = reasons;
 apply__indirect2_26_0:
 apply__indirect2_26_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto apply__indirect2_26_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_o)):
 apply__indirect2_26_2:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_i)) goto apply__indirect2_26_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xapply__indirect1_19);
  allocp[2] = a7;
  allocp[3] = a8;
  allocp[4] = a9;
  allocp[5] = a10;
  allocp[6] = a11;
  allocp[7] = a12;
  allocp[8] = x0 = makeref(&allocp[8]);
  allocp[9] = a14;
  allocp[10] = a15;
  allocp[11] = x1 = makeref(&allocp[11]);
  allocp[12] = a17;
  allocp[13] = x2 = makeref(&allocp[13]);
  allocp[14] = a19;
  allocp[15] = a20;
  allocp[16] = a21;
  allocp[17] = a22;
  allocp[18] = a23;
  allocp[19] = a24;
  allocp[20] = a25;
  allocp[21] = (q)(struct goalrec*)&allocp[0];
  allocp[22] = (q)(&predicate_type_xset__types_13);
  allocp[23] = a2;
  allocp[24] = a3;
  allocp[25] = makesym(atom_unify);
  allocp[26] = makeint(-1L);
  allocp[27] = a4;
  allocp[28] = makesym(atom_o);
  allocp[29] = x3 = makeref(&allocp[29]);
  allocp[30] = a16;
  allocp[31] = x1;
  allocp[32] = a18;
  allocp[33] = x2;
  allocp[34] = a13;
  allocp[35] = x0;
  allocp[36] = (q)(struct goalrec*)&allocp[21];
  allocp[37] = (q)(&predicate_type_xor__types_3);
  allocp[38] = x4 = makeref(&allocp[38]);
  allocp[39] = makecons(cons_const_0);
  allocp[40] = x3;
  allocp[41] = makesym(functor_goal_4);
  allocp[42] = a2;
  allocp[43] = a3;
  allocp[44] = a5;
  allocp[45] = a6;
  x5 = makefunctor(&allocp[41]);
  allocp[46] = (q)(struct goalrec*)&allocp[36];
  allocp[47] = (q)(&predicate_type_xadd__dep__goal_3);
  allocp[48] = x5;
  allocp[49] = a10;
  allocp[50] = x4;
  qp = (struct goalrec*)&allocp[46];
  allocp += 51;
  proceed();
 case VARREF:
  deref_and_jump(a1,apply__indirect2_26_2);
  *reasonp++ =  a1;
  goto apply__indirect2_26_interrupt;
  };
  goto apply__indirect2_26_interrupt;
 case symval(makesym(atom_i)):
 apply__indirect2_26_3:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_o)) goto apply__indirect2_26_interrupt;
  a0 = a7;
  a1 = a8;
  a2 = a9;
  a3 = a10;
  a4 = a11;
  a5 = a12;
  a6 = a13;
  a7 = a14;
  a8 = a15;
  a9 = a16;
  a10 = a17;
  a11 = a18;
  a12 = a19;
  a13 = a20;
  a14 = a21;
  a15 = a22;
  a16 = a23;
  a17 = a24;
  a18 = a25;
  execute(apply__indirect1_19_0);
  goto apply__indirect1_19_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,apply__indirect2_26_3);
  *reasonp++ =  a1;
  goto apply__indirect2_26_interrupt;
  };
  goto apply__indirect2_26_interrupt;
 case symval(makesym(atom__3F)):
 apply__indirect2_26_4:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom__3F)) goto apply__indirect2_26_interrupt;
  a0 = a7;
  a1 = a8;
  a2 = a9;
  a3 = a10;
  a4 = a11;
  a5 = a12;
  a6 = a13;
  a7 = a14;
  a8 = a15;
  a9 = a16;
  a10 = a17;
  a11 = a18;
  a12 = a19;
  a13 = a20;
  a14 = a21;
  a15 = a22;
  a16 = a23;
  a17 = a24;
  a18 = a25;
  execute(apply__indirect1_19_0);
  goto apply__indirect1_19_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,apply__indirect2_26_4);
  *reasonp++ =  a1;
  goto apply__indirect2_26_interrupt;
  };
  goto apply__indirect2_26_interrupt;
  };
  goto apply__indirect2_26_interrupt;
 case VARREF:
  deref_and_jump(a0,apply__indirect2_26_1);
  *reasonp++ =  a0;
  goto apply__indirect2_26_interrupt;
  };
  goto apply__indirect2_26_interrupt;
 apply__indirect2_26_ext_interrupt:
  reasonp = 0l;
 apply__indirect2_26_interrupt:
  goto interrupt_26;
 }

 apply__indirect2__alias_31_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  a18 = qp->args[18];
  a19 = qp->args[19];
  a20 = qp->args[20];
  a21 = qp->args[21];
  a22 = qp->args[22];
  a23 = qp->args[23];
  a24 = qp->args[24];
  a25 = qp->args[25];
  a26 = qp->args[26];
  a27 = qp->args[27];
  a28 = qp->args[28];
  a29 = qp->args[29];
  a30 = qp->args[30];
  qp = qp->next;
 apply__indirect2__alias_31_clear_reason:
  reasonp = reasons;
 apply__indirect2__alias_31_0:
 apply__indirect2__alias_31_1:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (isint(a3)) goto apply__indirect2__alias_31_interrupt;
  switch (symval(a3)) {
 case symval(makesym(atom_o)):
 apply__indirect2__alias_31_2:
  switch (ptagof(a4)) {
 case ATOMIC:
  if (a4 != makesym(atom_i)) goto apply__indirect2__alias_31_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xapply__indirect1_19);
  allocp[2] = a11;
  allocp[3] = a12;
  allocp[4] = a14;
  allocp[5] = a15;
  allocp[6] = a16;
  allocp[7] = a17;
  allocp[8] = x0 = makeref(&allocp[8]);
  allocp[9] = a19;
  allocp[10] = a20;
  allocp[11] = x1 = makeref(&allocp[11]);
  allocp[12] = a22;
  allocp[13] = x2 = makeref(&allocp[13]);
  allocp[14] = a24;
  allocp[15] = a25;
  allocp[16] = a26;
  allocp[17] = x3 = makeref(&allocp[17]);
  allocp[18] = a28;
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = a30;
  allocp[21] = (q)(struct goalrec*)&allocp[0];
  allocp[22] = (q)(&predicate_type_xset__types_13);
  allocp[23] = a5;
  allocp[24] = a6;
  allocp[25] = makesym(atom_unify);
  allocp[26] = makeint(-1L);
  allocp[27] = a8;
  allocp[28] = makesym(atom_o);
  allocp[29] = x5 = makeref(&allocp[29]);
  allocp[30] = x6 = makeref(&allocp[30]);
  allocp[31] = x1;
  allocp[32] = a23;
  allocp[33] = x2;
  allocp[34] = x7 = makeref(&allocp[34]);
  allocp[35] = x0;
  allocp[36] = (q)(struct goalrec*)&allocp[21];
  allocp[37] = (q)(&predicate_type_xor__types_3);
  allocp[38] = x8 = makeref(&allocp[38]);
  allocp[39] = makecons(cons_const_0);
  allocp[40] = x5;
  allocp[41] = makesym(functor_v_4);
  allocp[42] = a11;
  allocp[43] = a12;
  allocp[44] = a13;
  allocp[45] = a14;
  x9 = makefunctor(&allocp[41]);
  x10 = a1;
  a3 = a2;
  a4 = a15;
  a5 = x8;
  a6 = a21;
  a7 = x6;
  a8 = a18;
  a9 = x7;
  a10 = a20;
  a11 = a27;
  a12 = x3;
  a13 = a29;
  a14 = x4;
  a2 = x10;
  a1 = x9;
  qp = (struct goalrec*)&allocp[36];
  allocp += 46;
  execute(add__indirect__deps__alias_15_0);
  goto add__indirect__deps__alias_15_ext_interrupt;
 case VARREF:
  deref_and_jump(a4,apply__indirect2__alias_31_2);
  *reasonp++ =  a4;
  goto apply__indirect2__alias_31_interrupt;
  };
  goto apply__indirect2__alias_31_interrupt;
 case symval(makesym(atom_i)):
 apply__indirect2__alias_31_3:
  switch (ptagof(a4)) {
 case ATOMIC:
  if (a4 != makesym(atom_o)) goto apply__indirect2__alias_31_interrupt;
  a0 = a11;
  a1 = a12;
  a2 = a14;
  a3 = a15;
  a4 = a16;
  a5 = a17;
  a6 = a18;
  a7 = a19;
  a8 = a20;
  a9 = a21;
  a10 = a22;
  a11 = a23;
  a12 = a24;
  a13 = a25;
  a14 = a26;
  a15 = a27;
  a16 = a28;
  a17 = a29;
  a18 = a30;
  execute(apply__indirect1_19_0);
  goto apply__indirect1_19_ext_interrupt;
 case VARREF:
  deref_and_jump(a4,apply__indirect2__alias_31_3);
  *reasonp++ =  a4;
  goto apply__indirect2__alias_31_interrupt;
  };
  goto apply__indirect2__alias_31_interrupt;
 case symval(makesym(atom__3F)):
 apply__indirect2__alias_31_4:
  switch (ptagof(a4)) {
 case ATOMIC:
  if (a4 != makesym(atom__3F)) goto apply__indirect2__alias_31_interrupt;
  a0 = a11;
  a1 = a12;
  a2 = a14;
  a3 = a15;
  a4 = a16;
  a5 = a17;
  a6 = a18;
  a7 = a19;
  a8 = a20;
  a9 = a21;
  a10 = a22;
  a11 = a23;
  a12 = a24;
  a13 = a25;
  a14 = a26;
  a15 = a27;
  a16 = a28;
  a17 = a29;
  a18 = a30;
  execute(apply__indirect1_19_0);
  goto apply__indirect1_19_ext_interrupt;
 case VARREF:
  deref_and_jump(a4,apply__indirect2__alias_31_4);
  *reasonp++ =  a4;
  goto apply__indirect2__alias_31_interrupt;
  };
  goto apply__indirect2__alias_31_interrupt;
  };
  goto apply__indirect2__alias_31_interrupt;
 case VARREF:
  deref_and_jump(a3,apply__indirect2__alias_31_1);
  *reasonp++ =  a3;
  goto apply__indirect2__alias_31_interrupt;
  };
  goto apply__indirect2__alias_31_interrupt;
 apply__indirect2__alias_31_ext_interrupt:
  reasonp = 0l;
 apply__indirect2__alias_31_interrupt:
  goto interrupt_31;
 }

 indirect__mode__expansion_17_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  qp = qp->next;
 indirect__mode__expansion_17_clear_reason:
  reasonp = reasons;
 indirect__mode__expansion_17_0:
 indirect__mode__expansion_17_1:
  switch (ptagof(a4)) {
 case FUNCTOR:
  if (functor_of(a4) != makesym(functor_variable_3)) goto indirect__mode__expansion_17_interrupt;
 indirect__mode__expansion_17_2:
  switch (ptagof(a5)) {
 case FUNCTOR:
  if (functor_of(a5) != makesym(functor_variable_3)) goto indirect__mode__expansion_17_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xindirect__mode__expansion1_19);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = x0 = makeref(&allocp[8]);
  allocp[9] = x1 = makeref(&allocp[9]);
  allocp[10] = a6;
  allocp[11] = a7;
  allocp[12] = a8;
  allocp[13] = a9;
  allocp[14] = a10;
  allocp[15] = a11;
  allocp[16] = a12;
  allocp[17] = a13;
  allocp[18] = a14;
  allocp[19] = a15;
  allocp[20] = a16;
  allocp[21] = (q)(struct goalrec*)&allocp[0];
  allocp[22] = (q)(&predicate_mode_xget__mode_9);
  allocp[23] = a1;
  allocp[24] = a3;
  x2 = arg(a5, 1);
  allocp[25] = x2;
  x3 = arg(a5, 0);
  allocp[26] = x3;
  allocp[27] = a8;
  allocp[28] = a11;
  allocp[29] = x1;
  allocp[30] = a13;
  allocp[31] = a15;
  allocp[32] = (q)(struct goalrec*)&allocp[21];
  allocp[33] = (q)(&predicate_mode_xget__mode_9);
  allocp[34] = a0;
  allocp[35] = a2;
  x4 = arg(a4, 1);
  allocp[36] = x4;
  x5 = arg(a4, 0);
  allocp[37] = x5;
  allocp[38] = a8;
  allocp[39] = a10;
  allocp[40] = x0;
  allocp[41] = a12;
  allocp[42] = a15;
  qp = (struct goalrec*)&allocp[32];
  allocp += 43;
  proceed();
 case VARREF:
  deref_and_jump(a5,indirect__mode__expansion_17_2);
  *reasonp++ =  a5;
  goto indirect__mode__expansion_17_interrupt;
  };
  goto indirect__mode__expansion_17_interrupt;
 case VARREF:
  deref_and_jump(a4,indirect__mode__expansion_17_1);
  *reasonp++ =  a4;
  goto indirect__mode__expansion_17_interrupt;
  };
  goto indirect__mode__expansion_17_interrupt;
 indirect__mode__expansion_17_ext_interrupt:
  reasonp = 0l;
 indirect__mode__expansion_17_interrupt:
  toppred = &predicate_analyze__type_xindirect__mode__expansion_17;
  goto interrupt_17;
 }

 indirect__mode__expansion1_19_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  a18 = qp->args[18];
  qp = qp->next;
 indirect__mode__expansion1_19_clear_reason:
  reasonp = reasons;
 indirect__mode__expansion1_19_0:
 indirect__mode__expansion1_19_1:
  switch (ptagof(a6)) {
 case ATOMIC:
  if (a6 != makesym(atom__3F)) goto indirect__mode__expansion1_19_7;
 indirect__mode__expansion1_19_2:
  switch (ptagof(a7)) {
 case ATOMIC:
  if (a7 != makesym(atom__3F)) goto indirect__mode__expansion1_19_7;
 indirect__mode__expansion1_19_3:
  switch (ptagof(a4)) {
 case FUNCTOR:
  if (functor_of(a4) != makesym(functor_variable_3)) goto indirect__mode__expansion1_19_7;
  x0 = arg(a4, 2);
 indirect__mode__expansion1_19_4:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__3F)) goto indirect__mode__expansion1_19_7;
 indirect__mode__expansion1_19_5:
  switch (ptagof(a5)) {
 case FUNCTOR:
  if (functor_of(a5) != makesym(functor_variable_3)) goto indirect__mode__expansion1_19_7;
  x1 = arg(a5, 2);
 indirect__mode__expansion1_19_6:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom__3F)) goto indirect__mode__expansion1_19_7;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xindirect__mode__expansion11_20);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = a0;
  allocp[5] = a1;
  allocp[6] = a2;
  allocp[7] = a3;
  allocp[8] = a4;
  allocp[9] = a5;
  allocp[10] = a6;
  allocp[11] = a7;
  allocp[12] = a8;
  allocp[13] = a9;
  allocp[14] = a10;
  allocp[15] = a11;
  allocp[16] = a12;
  allocp[17] = a13;
  allocp[18] = a14;
  allocp[19] = a15;
  allocp[20] = a17;
  allocp[21] = a18;
  allocp[22] = (q)(struct goalrec*)&allocp[0];
  allocp[23] = (q)(&predicate_type_xget__types_5);
  allocp[24] = a1;
  allocp[25] = a3;
  x4 = arg(a5, 0);
  allocp[26] = x4;
  allocp[27] = a16;
  allocp[28] = x3;
  allocp[29] = (q)(struct goalrec*)&allocp[22];
  allocp[30] = (q)(&predicate_type_xget__types_5);
  allocp[31] = a0;
  allocp[32] = a2;
  x5 = arg(a4, 0);
  allocp[33] = x5;
  allocp[34] = a16;
  allocp[35] = x2;
  qp = (struct goalrec*)&allocp[29];
  allocp += 36;
  proceed();
 case VARREF:
  deref_and_jump(x1,indirect__mode__expansion1_19_6);
  *reasonp++ =  x1;
  goto indirect__mode__expansion1_19_7;
  };
  goto indirect__mode__expansion1_19_7;
 case VARREF:
  deref_and_jump(a5,indirect__mode__expansion1_19_5);
  *reasonp++ =  a5;
  goto indirect__mode__expansion1_19_7;
  };
  goto indirect__mode__expansion1_19_7;
 case VARREF:
  deref_and_jump(x0,indirect__mode__expansion1_19_4);
  *reasonp++ =  x0;
  goto indirect__mode__expansion1_19_7;
  };
  goto indirect__mode__expansion1_19_7;
 case VARREF:
  deref_and_jump(a4,indirect__mode__expansion1_19_3);
  *reasonp++ =  a4;
  goto indirect__mode__expansion1_19_7;
  };
  goto indirect__mode__expansion1_19_7;
 case VARREF:
  deref_and_jump(a7,indirect__mode__expansion1_19_2);
  *reasonp++ =  a7;
  goto indirect__mode__expansion1_19_7;
  };
  goto indirect__mode__expansion1_19_7;
 case VARREF:
  deref_and_jump(a6,indirect__mode__expansion1_19_1);
  *reasonp++ =  a6;
  goto indirect__mode__expansion1_19_7;
  };
  goto indirect__mode__expansion1_19_7;
 indirect__mode__expansion1_19_7:
  otherwise(indirect__mode__expansion1_19_interrupt);
 indirect__mode__expansion1_19_8:
  switch (ptagof(a6)) {
 case ATOMIC:
  if (a6 != makesym(atom__3F)) goto indirect__mode__expansion1_19_12;
 indirect__mode__expansion1_19_9:
  switch (ptagof(a7)) {
 case ATOMIC:
  if (a7 != makesym(atom__3F)) goto indirect__mode__expansion1_19_12;
 indirect__mode__expansion1_19_10:
  switch (ptagof(a4)) {
 case FUNCTOR:
  if (functor_of(a4) != makesym(functor_variable_3)) goto indirect__mode__expansion1_19_12;
 indirect__mode__expansion1_19_11:
  switch (ptagof(a5)) {
 case FUNCTOR:
  if (functor_of(a5) != makesym(functor_variable_3)) goto indirect__mode__expansion1_19_12;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xindirect__mode__expansion2_14);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a8;
  allocp[5] = a9;
  allocp[6] = a0;
  allocp[7] = a1;
  allocp[8] = a2;
  allocp[9] = a3;
  allocp[10] = a4;
  allocp[11] = a5;
  allocp[12] = x2 = makeref(&allocp[12]);
  allocp[13] = a11;
  allocp[14] = x3 = makeref(&allocp[14]);
  allocp[15] = a18;
  allocp[16] = (q)(struct goalrec*)&allocp[0];
  allocp[17] = (q)(&predicate_analyze__type_xindirect__mode__modules_8);
  allocp[18] = a1;
  allocp[19] = a3;
  allocp[20] = a5;
  allocp[21] = x1;
  allocp[22] = x4 = makeref(&allocp[22]);
  allocp[23] = x2;
  allocp[24] = x5 = makeref(&allocp[24]);
  allocp[25] = x3;
  allocp[26] = (q)(struct goalrec*)&allocp[16];
  allocp[27] = (q)(&predicate_analyze__type_xindirect__mode__modules_8);
  allocp[28] = a0;
  allocp[29] = a2;
  allocp[30] = a4;
  allocp[31] = x0;
  allocp[32] = a10;
  allocp[33] = x4;
  allocp[34] = a17;
  allocp[35] = x5;
  allocp[36] = (q)(struct goalrec*)&allocp[26];
  allocp[37] = (q)(&predicate_mode_xru2mode_2);
  x6 = arg(a5, 2);
  allocp[38] = x6;
  allocp[39] = x1;
  allocp[40] = (q)(struct goalrec*)&allocp[36];
  allocp[41] = (q)(&predicate_mode_xru2mode_2);
  x7 = arg(a4, 2);
  allocp[42] = x7;
  allocp[43] = x0;
  qp = (struct goalrec*)&allocp[40];
  allocp += 44;
  proceed();
 case VARREF:
  deref_and_jump(a5,indirect__mode__expansion1_19_11);
  *reasonp++ =  a5;
  goto indirect__mode__expansion1_19_12;
  };
  goto indirect__mode__expansion1_19_12;
 case VARREF:
  deref_and_jump(a4,indirect__mode__expansion1_19_10);
  *reasonp++ =  a4;
  goto indirect__mode__expansion1_19_12;
  };
  goto indirect__mode__expansion1_19_12;
 case VARREF:
  deref_and_jump(a7,indirect__mode__expansion1_19_9);
  *reasonp++ =  a7;
  goto indirect__mode__expansion1_19_12;
  };
  goto indirect__mode__expansion1_19_12;
 case VARREF:
  deref_and_jump(a6,indirect__mode__expansion1_19_8);
  *reasonp++ =  a6;
  goto indirect__mode__expansion1_19_12;
  };
  goto indirect__mode__expansion1_19_12;
 indirect__mode__expansion1_19_12:
  otherwise(indirect__mode__expansion1_19_interrupt);
  x0 = a6;
  x1 = a7;
  x2 = a8;
  x3 = a9;
  x4 = a0;
  x5 = a1;
  a6 = a2;
  a7 = a3;
  a8 = a4;
  a9 = a5;
  a12 = a17;
  a13 = a18;
  a5 = x5;
  a4 = x4;
  a3 = x3;
  a2 = x2;
  a1 = x1;
  a0 = x0;
  execute(indirect__mode__expansion2_14_0);
  goto indirect__mode__expansion2_14_ext_interrupt;
 indirect__mode__expansion1_19_ext_interrupt:
  reasonp = 0l;
 indirect__mode__expansion1_19_interrupt:
  goto interrupt_19;
 }

 indirect__mode__expansion11_20_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  a18 = qp->args[18];
  a19 = qp->args[19];
  qp = qp->next;
 indirect__mode__expansion11_20_clear_reason:
  reasonp = reasons;
 indirect__mode__expansion11_20_0:
 indirect__mode__expansion11_20_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 indirect__mode__expansion11_20_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__3F)) goto indirect__mode__expansion11_20_7;
  x1 = cdr_of(a0);
 indirect__mode__expansion11_20_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto indirect__mode__expansion11_20_7;
 indirect__mode__expansion11_20_4:
  switch (ptagof(a1)) {
 case CONS:
  x2 = car_of(a1);
 indirect__mode__expansion11_20_5:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != makesym(atom__3F)) goto indirect__mode__expansion11_20_7;
  x3 = cdr_of(a1);
 indirect__mode__expansion11_20_6:
  switch (ptagof(x3)) {
 case ATOMIC:
  if (x3 != NILATOM) goto indirect__mode__expansion11_20_7;
  a0 = a8;
  a1 = a9;
  x4 = a10;
  x5 = a11;
  x6 = a2;
  x7 = a3;
  x8 = a4;
  x9 = a5;
  a8 = a6;
  a9 = a7;
  a10 = a12;
  a11 = a13;
  a12 = a18;
  a13 = a19;
  a7 = x9;
  a6 = x8;
  a5 = x7;
  a4 = x6;
  a3 = x5;
  a2 = x4;
  execute(indirect__mode__expansion2_14_0);
  goto indirect__mode__expansion2_14_ext_interrupt;
 case VARREF:
  deref_and_jump(x3,indirect__mode__expansion11_20_6);
  *reasonp++ =  x3;
  goto indirect__mode__expansion11_20_7;
  };
  goto indirect__mode__expansion11_20_7;
 case VARREF:
  deref_and_jump(x2,indirect__mode__expansion11_20_5);
  *reasonp++ =  x2;
  goto indirect__mode__expansion11_20_7;
  };
  goto indirect__mode__expansion11_20_7;
 case VARREF:
  deref_and_jump(a1,indirect__mode__expansion11_20_4);
  *reasonp++ =  a1;
  goto indirect__mode__expansion11_20_7;
  };
  goto indirect__mode__expansion11_20_7;
 case VARREF:
  deref_and_jump(x1,indirect__mode__expansion11_20_3);
  *reasonp++ =  x1;
  goto indirect__mode__expansion11_20_7;
  };
  goto indirect__mode__expansion11_20_7;
 case VARREF:
  deref_and_jump(x0,indirect__mode__expansion11_20_2);
  *reasonp++ =  x0;
  goto indirect__mode__expansion11_20_7;
  };
  goto indirect__mode__expansion11_20_7;
 case VARREF:
  deref_and_jump(a0,indirect__mode__expansion11_20_1);
  *reasonp++ =  a0;
  goto indirect__mode__expansion11_20_7;
  };
  goto indirect__mode__expansion11_20_7;
 indirect__mode__expansion11_20_7:
  otherwise(indirect__mode__expansion11_20_interrupt);
 indirect__mode__expansion11_20_8:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 indirect__mode__expansion11_20_9:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__3F)) goto indirect__mode__expansion11_20_11;
  x1 = cdr_of(a1);
 indirect__mode__expansion11_20_10:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto indirect__mode__expansion11_20_11;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xindirect__mode__expansion2_14);
  allocp[2] = makesym(atom_i);
  allocp[3] = makesym(atom_o);
  allocp[4] = a10;
  allocp[5] = a11;
  allocp[6] = a2;
  allocp[7] = a3;
  allocp[8] = a4;
  allocp[9] = a5;
  allocp[10] = a6;
  allocp[11] = a7;
  allocp[12] = x2 = makeref(&allocp[12]);
  allocp[13] = a13;
  allocp[14] = x3 = makeref(&allocp[14]);
  allocp[15] = a19;
  allocp[16] = (q)(struct goalrec*)&allocp[0];
  allocp[17] = (q)(&predicate_analyze__type_xindirect__mode__modules_8);
  allocp[18] = a3;
  allocp[19] = a5;
  allocp[20] = a7;
  allocp[21] = makesym(atom_o);
  allocp[22] = x4 = makeref(&allocp[22]);
  allocp[23] = x2;
  allocp[24] = x5 = makeref(&allocp[24]);
  allocp[25] = x3;
  a0 = a2;
  a1 = a4;
  a2 = a6;
  a3 = makesym(atom_i);
  a4 = a12;
  a5 = x4;
  a6 = a18;
  a7 = x5;
  qp = (struct goalrec*)&allocp[16];
  allocp += 26;
  execute(indirect__mode__modules_8_0);
  goto indirect__mode__modules_8_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,indirect__mode__expansion11_20_10);
  *reasonp++ =  x1;
  goto indirect__mode__expansion11_20_11;
  };
  goto indirect__mode__expansion11_20_11;
 case VARREF:
  deref_and_jump(x0,indirect__mode__expansion11_20_9);
  *reasonp++ =  x0;
  goto indirect__mode__expansion11_20_11;
  };
  goto indirect__mode__expansion11_20_11;
 case VARREF:
  deref_and_jump(a1,indirect__mode__expansion11_20_8);
  *reasonp++ =  a1;
  goto indirect__mode__expansion11_20_11;
  };
  goto indirect__mode__expansion11_20_11;
 indirect__mode__expansion11_20_11:
 indirect__mode__expansion11_20_12:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 indirect__mode__expansion11_20_13:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__3F)) goto indirect__mode__expansion11_20_15;
  x1 = cdr_of(a0);
 indirect__mode__expansion11_20_14:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto indirect__mode__expansion11_20_15;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xindirect__mode__expansion2_14);
  allocp[2] = makesym(atom_o);
  allocp[3] = makesym(atom_i);
  allocp[4] = a10;
  allocp[5] = a11;
  allocp[6] = a2;
  allocp[7] = a3;
  allocp[8] = a4;
  allocp[9] = a5;
  allocp[10] = a6;
  allocp[11] = a7;
  allocp[12] = x2 = makeref(&allocp[12]);
  allocp[13] = a13;
  allocp[14] = x3 = makeref(&allocp[14]);
  allocp[15] = a19;
  allocp[16] = (q)(struct goalrec*)&allocp[0];
  allocp[17] = (q)(&predicate_analyze__type_xindirect__mode__modules_8);
  allocp[18] = a3;
  allocp[19] = a5;
  allocp[20] = a7;
  allocp[21] = makesym(atom_i);
  allocp[22] = x4 = makeref(&allocp[22]);
  allocp[23] = x2;
  allocp[24] = x5 = makeref(&allocp[24]);
  allocp[25] = x3;
  a0 = a2;
  a1 = a4;
  a2 = a6;
  a3 = makesym(atom_o);
  a4 = a12;
  a5 = x4;
  a6 = a18;
  a7 = x5;
  qp = (struct goalrec*)&allocp[16];
  allocp += 26;
  execute(indirect__mode__modules_8_clear_reason);
  goto indirect__mode__modules_8_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,indirect__mode__expansion11_20_14);
  *reasonp++ =  x1;
  goto indirect__mode__expansion11_20_15;
  };
  goto indirect__mode__expansion11_20_15;
 case VARREF:
  deref_and_jump(x0,indirect__mode__expansion11_20_13);
  *reasonp++ =  x0;
  goto indirect__mode__expansion11_20_15;
  };
  goto indirect__mode__expansion11_20_15;
 case VARREF:
  deref_and_jump(a0,indirect__mode__expansion11_20_12);
  *reasonp++ =  a0;
  goto indirect__mode__expansion11_20_15;
  };
  goto indirect__mode__expansion11_20_15;
 indirect__mode__expansion11_20_15:
  otherwise(indirect__mode__expansion11_20_interrupt);
  a0 = a8;
  a1 = a9;
  x0 = a10;
  x1 = a11;
  x2 = a2;
  x3 = a3;
  x4 = a4;
  x5 = a5;
  a8 = a6;
  a9 = a7;
  a10 = a12;
  a11 = a13;
  a12 = a18;
  a13 = a19;
  a7 = x5;
  a6 = x4;
  a5 = x3;
  a4 = x2;
  a3 = x1;
  a2 = x0;
  execute(indirect__mode__expansion2_14_0);
  goto indirect__mode__expansion2_14_ext_interrupt;
 indirect__mode__expansion11_20_ext_interrupt:
  reasonp = 0l;
 indirect__mode__expansion11_20_interrupt:
  goto interrupt_20;
 }

 indirect__mode__expansion2_14_top: {
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  qp = qp->next;
 indirect__mode__expansion2_14_clear_reason:
  reasonp = reasons;
 indirect__mode__expansion2_14_0:
 indirect__mode__expansion2_14_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom__3F)) goto indirect__mode__expansion2_14_3;
 indirect__mode__expansion2_14_2:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom__3F)) goto indirect__mode__expansion2_14_3;
  unify_value(a2, makesym(atom__3F));
  unify_value(a3, makesym(atom__3F));
  unify2(a11, a10, a13, a12);
  proceed();
 case VARREF:
  deref_and_jump(a1,indirect__mode__expansion2_14_2);
  *reasonp++ =  a1;
  goto indirect__mode__expansion2_14_3;
  };
  goto indirect__mode__expansion2_14_3;
 case VARREF:
  deref_and_jump(a0,indirect__mode__expansion2_14_1);
  *reasonp++ =  a0;
  goto indirect__mode__expansion2_14_3;
  };
  goto indirect__mode__expansion2_14_3;
 indirect__mode__expansion2_14_3:
  otherwise(indirect__mode__expansion2_14_interrupt);
 indirect__mode__expansion2_14_4:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom__3F)) goto indirect__mode__expansion2_14_5;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xindirect__mode__modules_8);
  allocp[2] = a4;
  allocp[3] = a6;
  allocp[4] = a8;
  allocp[5] = a2;
  allocp[6] = a10;
  allocp[7] = a11;
  allocp[8] = a12;
  allocp[9] = a13;
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  unify(a3, a1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xreverse__mode_2);
  allocp[2] = a1;
  allocp[3] = a2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  proceed();
 case VARREF:
  deref_and_jump(a0,indirect__mode__expansion2_14_4);
  *reasonp++ =  a0;
  goto indirect__mode__expansion2_14_5;
  };
  goto indirect__mode__expansion2_14_5;
 indirect__mode__expansion2_14_5:
 indirect__mode__expansion2_14_6:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom__3F)) goto indirect__mode__expansion2_14_7;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xindirect__mode__modules_8);
  allocp[2] = a5;
  allocp[3] = a7;
  allocp[4] = a9;
  allocp[5] = a3;
  allocp[6] = a10;
  allocp[7] = a11;
  allocp[8] = a12;
  allocp[9] = a13;
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  unify(a2, a0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xreverse__mode_2);
  allocp[2] = a0;
  allocp[3] = a3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  proceed();
 case VARREF:
  deref_and_jump(a1,indirect__mode__expansion2_14_6);
  *reasonp++ =  a1;
  goto indirect__mode__expansion2_14_7;
  };
  goto indirect__mode__expansion2_14_7;
 indirect__mode__expansion2_14_7:
  otherwise(indirect__mode__expansion2_14_interrupt);
  unify4(a2, a0, a3, a1, a11, a10, a13, a12);
  proceed();
 indirect__mode__expansion2_14_ext_interrupt:
  reasonp = 0l;
 indirect__mode__expansion2_14_interrupt:
  toppred = &predicate_analyze__type_xindirect__mode__expansion2_14;
  goto interrupt_14;
 }

 indirect__mode__modules_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 indirect__mode__modules_8_clear_reason:
  reasonp = reasons;
 indirect__mode__modules_8_0:
 indirect__mode__modules_8_1:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_loop_2)) goto indirect__mode__modules_8_2;
  unify(a5, a4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_loop_xupdate__lv__entry_6);
  allocp[2] = a0;
  x0 = arg(a1, 0);
  allocp[3] = x0;
  x1 = arg(a1, 1);
  allocp[4] = x1;
  allocp[5] = a6;
  allocp[6] = a7;
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[10] = x3 = makeref(&allocp[10]);
  allocp[11] = x4 = makeref(&allocp[11]);
  allocp[12] = a3;
  allocp[13] = x2;
  allocp[14] = (q)(struct goalrec*)&allocp[8];
  allocp[15] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[16] = x5 = makeref(&allocp[16]);
  allocp[17] = makeint(1L);
  allocp[18] = x3;
  allocp[19] = makesym(functor_variable_3);
  allocp[20] = x5;
  allocp[21] = x7 = makeref(&allocp[21]);
  allocp[22] = x8 = makeref(&allocp[22]);
  x6 = makefunctor(&allocp[19]);
  qp = (struct goalrec*)&allocp[14];
  allocp += 23;
  unify_value(a2, x6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_loop_xget__lv__entry_5);
  allocp[2] = a0;
  allocp[3] = x0;
  allocp[4] = x1;
  allocp[5] = a6;
  allocp[6] = x4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  proceed();
 case VARREF:
  deref_and_jump(a1,indirect__mode__modules_8_1);
  *reasonp++ =  a1;
  goto indirect__mode__modules_8_2;
  };
  goto indirect__mode__modules_8_2;
 indirect__mode__modules_8_2:
  otherwise(indirect__mode__modules_8_interrupt);
 indirect__mode__modules_8_3:
  switch (ptagof(a4)) {
 case CONS:
  x0 = car_of(a4);
 indirect__mode__modules_8_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto indirect__mode__modules_8_13;
  x1 = arg(x0, 0);
 indirect__mode__modules_8_5:
  if (isref(x1)) goto indirect__mode__modules_8_12;
 indirect__mode__modules_8_6:
  if (isref(x1)) goto indirect__mode__modules_8_11;
  if_not_equal(x1, a0, indirect__mode__modules_8_13);
 indirect__mode__modules_8_7:
  if (!isint(a1)) goto indirect__mode__modules_8_10;
  x2 = arg(x0, 1);
 indirect__mode__modules_8_8:
  if (isref(x2)) goto indirect__mode__modules_8_9;
  gblt_arg(a1,x2,x3,indirect__mode__modules_8_13);
  unify(a7, a6);
  allocp[0] = makesym(functor_module_2);
  allocp[1] = a0;
  allocp[2] = x5 = makeref(&allocp[2]);
  x4 = makefunctor(&allocp[0]);
  allocp[3] = cdr_of(a4);
  allocp[4] = x4;
  x6 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a5, x6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = a1;
  allocp[3] = x2;
  allocp[4] = x7 = makeref(&allocp[4]);
  allocp[5] = x5;
  a0 = a2;
  a1 = a3;
  a2 = x3;
  a3 = x7;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(indirect__mode__clause_4_clear_reason);
  goto indirect__mode__clause_4_ext_interrupt;
 indirect__mode__modules_8_9:
  deref_and_jump(x2,indirect__mode__modules_8_8);
  *reasonp++ =  x2;
  goto indirect__mode__modules_8_13;
 indirect__mode__modules_8_10:
  if (!isref(a1)) goto indirect__mode__modules_8_13;
  deref_and_jump(a1,indirect__mode__modules_8_7);
  *reasonp++ =  a1;
  goto indirect__mode__modules_8_13;
 indirect__mode__modules_8_11:
  deref_and_jump(x1,indirect__mode__modules_8_6);
  *reasonp++ =  x1;
  goto indirect__mode__modules_8_13;
 indirect__mode__modules_8_12:
  deref_and_jump(x1,indirect__mode__modules_8_5);
  *reasonp++ =  x1;
  goto indirect__mode__modules_8_13;
 case VARREF:
  deref_and_jump(x0,indirect__mode__modules_8_4);
  *reasonp++ =  x0;
  goto indirect__mode__modules_8_13;
  };
  goto indirect__mode__modules_8_13;
 case VARREF:
  deref_and_jump(a4,indirect__mode__modules_8_3);
  *reasonp++ =  a4;
  goto indirect__mode__modules_8_13;
  };
  goto indirect__mode__modules_8_13;
 indirect__mode__modules_8_13:
  otherwise(indirect__mode__modules_8_interrupt);
 indirect__mode__modules_8_14:
  switch (ptagof(a4)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = car_of(a4);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a5, x0);
  unify(a7, a6);
  a4 = cdr_of(a4);
  a5 = x1;
  execute(indirect__mode__modules_8_0);
  goto indirect__mode__modules_8_ext_interrupt;
 case VARREF:
  deref_and_jump(a4,indirect__mode__modules_8_14);
  *reasonp++ =  a4;
  goto indirect__mode__modules_8_interrupt;
  };
  goto indirect__mode__modules_8_interrupt;
 indirect__mode__modules_8_ext_interrupt:
  reasonp = 0l;
 indirect__mode__modules_8_interrupt:
  toppred = &predicate_analyze__type_xindirect__mode__modules_8;
  goto interrupt_8;
 }

 indirect__mode__clause_4_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 indirect__mode__clause_4_clear_reason:
  reasonp = reasons;
 indirect__mode__clause_4_0:
 indirect__mode__clause_4_1:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_clause_6)) goto indirect__mode__clause_4_interrupt;
  allocp[0] = makesym(functor_clause_6);
  allocp[1] = arg(a2, 0);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = arg(a2, 3);
  allocp[5] = arg(a2, 4);
  allocp[6] = x3 = makeref(&allocp[6]);
  x0 = makefunctor(&allocp[0]);
  allocp += 7;
  unify_value(a3, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xindirect__mode__goals_6);
  allocp[2] = a0;
  allocp[3] = a1;
  x4 = arg(a2, 2);
  allocp[4] = x4;
  allocp[5] = x2;
  allocp[6] = x5 = makeref(&allocp[6]);
  allocp[7] = x3;
  x6 = arg(a2, 1);
  a3 = x1;
  a4 = arg(a2, 5);
  a5 = x5;
  a2 = x6;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  execute(indirect__mode__goals_6_0);
  goto indirect__mode__goals_6_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,indirect__mode__clause_4_1);
  *reasonp++ =  a2;
  goto indirect__mode__clause_4_interrupt;
  };
  goto indirect__mode__clause_4_interrupt;
 indirect__mode__clause_4_ext_interrupt:
  reasonp = 0l;
 indirect__mode__clause_4_interrupt:
  toppred = &predicate_analyze__type_xindirect__mode__clause_4;
  goto interrupt_4;
 }

 indirect__mode__goals_6_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 indirect__mode__goals_6_clear_reason:
  reasonp = reasons;
 indirect__mode__goals_6_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xindirect__mode__goals1_7);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[11] = a2;
  allocp[12] = x1 = makeref(&allocp[12]);
  allocp[13] = x0;
  qp = (struct goalrec*)&allocp[9];
  allocp += 14;
  proceed();
 indirect__mode__goals_6_ext_interrupt:
  reasonp = 0l;
 indirect__mode__goals_6_interrupt:
  toppred = &predicate_analyze__type_xindirect__mode__goals_6;
  goto interrupt_6;
 }

 indirect__mode__goals1_7_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 indirect__mode__goals1_7_clear_reason:
  reasonp = reasons;
 indirect__mode__goals1_7_0:
 indirect__mode__goals1_7_1:
  if (!isint(a0)) goto indirect__mode__goals1_7_3;
  gblt_greater(a0,makeint(0L),indirect__mode__goals1_7_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xindirect__mode__goals1_7);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[11] = a0;
  allocp[12] = makeint(1L);
  allocp[13] = x0;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[16] = a0;
  allocp[17] = a3;
  allocp[18] = x3 = makeref(&allocp[18]);
  allocp[19] = x1;
  allocp[20] = (q)(struct goalrec*)&allocp[14];
  allocp[21] = (q)(&predicate_analyze__type_xindirect__mode__goal_6);
  allocp[22] = a1;
  allocp[23] = a2;
  allocp[24] = x4 = makeref(&allocp[24]);
  allocp[25] = x3;
  allocp[26] = a5;
  allocp[27] = x2;
  allocp[28] = (q)(struct goalrec*)&allocp[20];
  allocp[29] = (q)(&predicate_functor__table_xarg_3);
  allocp[30] = a0;
  allocp[31] = a3;
  allocp[32] = x4;
  qp = (struct goalrec*)&allocp[28];
  allocp += 33;
  proceed();
 indirect__mode__goals1_7_2:
  if (a0 != makeint(0L)) goto indirect__mode__goals1_7_interrupt;
  unify2(a4, a3, a6, a5);
  proceed();
 indirect__mode__goals1_7_3:
  if (!isref(a0)) goto indirect__mode__goals1_7_interrupt;
  deref_and_jump(a0,indirect__mode__goals1_7_1);
  *reasonp++ =  a0;
  goto indirect__mode__goals1_7_interrupt;
 indirect__mode__goals1_7_ext_interrupt:
  reasonp = 0l;
 indirect__mode__goals1_7_interrupt:
  goto interrupt_7;
 }

 indirect__mode__goal_6_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 indirect__mode__goal_6_clear_reason:
  reasonp = reasons;
 indirect__mode__goal_6_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xindirect__mode__arg_7);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[11] = a2;
  allocp[12] = x1 = makeref(&allocp[12]);
  allocp[13] = x0;
  qp = (struct goalrec*)&allocp[9];
  allocp += 14;
  proceed();
 indirect__mode__goal_6_ext_interrupt:
  reasonp = 0l;
 indirect__mode__goal_6_interrupt:
  toppred = &predicate_analyze__type_xindirect__mode__goal_6;
  goto interrupt_6;
 }

 indirect__mode__arg_7_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 indirect__mode__arg_7_clear_reason:
  reasonp = reasons;
 indirect__mode__arg_7_0:
 indirect__mode__arg_7_1:
  if (!isint(a0)) goto indirect__mode__arg_7_3;
  gblt_greater(a0,makeint(0L),indirect__mode__arg_7_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xindirect__mode__arg_7);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[11] = a0;
  allocp[12] = makeint(1L);
  allocp[13] = x0;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[16] = a0;
  allocp[17] = a3;
  allocp[18] = x3 = makeref(&allocp[18]);
  allocp[19] = x1;
  allocp[20] = (q)(struct goalrec*)&allocp[14];
  allocp[21] = (q)(&predicate_analyze__type_xindirect__mode__arg1_6);
  allocp[22] = a1;
  allocp[23] = a2;
  allocp[24] = x4 = makeref(&allocp[24]);
  allocp[25] = x3;
  allocp[26] = a5;
  allocp[27] = x2;
  allocp[28] = (q)(struct goalrec*)&allocp[20];
  allocp[29] = (q)(&predicate_functor__table_xarg_3);
  allocp[30] = a0;
  allocp[31] = a3;
  allocp[32] = x4;
  qp = (struct goalrec*)&allocp[28];
  allocp += 33;
  proceed();
 indirect__mode__arg_7_2:
  if (a0 != makeint(0L)) goto indirect__mode__arg_7_interrupt;
  unify2(a4, a3, a6, a5);
  proceed();
 indirect__mode__arg_7_3:
  if (!isref(a0)) goto indirect__mode__arg_7_interrupt;
  deref_and_jump(a0,indirect__mode__arg_7_1);
  *reasonp++ =  a0;
  goto indirect__mode__arg_7_interrupt;
 indirect__mode__arg_7_ext_interrupt:
  reasonp = 0l;
 indirect__mode__arg_7_interrupt:
  goto interrupt_7;
 }

 indirect__mode__arg1_6_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 indirect__mode__arg1_6_clear_reason:
  reasonp = reasons;
 indirect__mode__arg1_6_0:
 indirect__mode__arg1_6_1:
  switch (ptagof(a2)) {
 case ATOMIC:
 indirect__mode__arg1_6_2:
  gblt_atomic(a2,indirect__mode__arg1_6_3);
  unify_value(a3, a2);
  unify(a5, a4);
  proceed();
 case VARREF:
  deref_and_jump(a2,indirect__mode__arg1_6_1);
  *reasonp++ =  a2;
  goto indirect__mode__arg1_6_3;
  };
  goto indirect__mode__arg1_6_3;
 indirect__mode__arg1_6_3:
 indirect__mode__arg1_6_4:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_variable_3)) goto indirect__mode__arg1_6_14;
 indirect__mode__arg1_6_5:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_variable_3)) goto indirect__mode__arg1_6_14;
  x0 = arg(a2, 0);
 indirect__mode__arg1_6_6:
  if (isref(x0)) goto indirect__mode__arg1_6_13;
 indirect__mode__arg1_6_7:
  if (isref(x0)) goto indirect__mode__arg1_6_12;
  x1 = arg(a0, 0);
  if_not_equal(x0, x1, indirect__mode__arg1_6_14);
  x2 = arg(a2, 1);
 indirect__mode__arg1_6_8:
  if (isref(x2)) goto indirect__mode__arg1_6_11;
 indirect__mode__arg1_6_9:
  if (isref(x2)) goto indirect__mode__arg1_6_10;
  x3 = arg(a0, 1);
  if_not_equal(x2, x3, indirect__mode__arg1_6_14);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xset__arg__mode_6);
  allocp[2] = a2;
  allocp[3] = a1;
  allocp[4] = makesym(atom_guard);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  proceed();
 indirect__mode__arg1_6_10:
  deref_and_jump(x2,indirect__mode__arg1_6_9);
  *reasonp++ =  x2;
  goto indirect__mode__arg1_6_14;
 indirect__mode__arg1_6_11:
  deref_and_jump(x2,indirect__mode__arg1_6_8);
  *reasonp++ =  x2;
  goto indirect__mode__arg1_6_14;
 indirect__mode__arg1_6_12:
  deref_and_jump(x0,indirect__mode__arg1_6_7);
  *reasonp++ =  x0;
  goto indirect__mode__arg1_6_14;
 indirect__mode__arg1_6_13:
  deref_and_jump(x0,indirect__mode__arg1_6_6);
  *reasonp++ =  x0;
  goto indirect__mode__arg1_6_14;
 case VARREF:
  deref_and_jump(a2,indirect__mode__arg1_6_5);
  *reasonp++ =  a2;
  goto indirect__mode__arg1_6_14;
  };
  goto indirect__mode__arg1_6_14;
 case VARREF:
  deref_and_jump(a0,indirect__mode__arg1_6_4);
  *reasonp++ =  a0;
  goto indirect__mode__arg1_6_14;
  };
  goto indirect__mode__arg1_6_14;
 indirect__mode__arg1_6_14:
  otherwise(indirect__mode__arg1_6_interrupt);
  execute(indirect__mode__goal_6_0);
  goto indirect__mode__goal_6_ext_interrupt;
 indirect__mode__arg1_6_ext_interrupt:
  reasonp = 0l;
 indirect__mode__arg1_6_interrupt:
  goto interrupt_6;
 }

 indirect__mode__expansion__alias_6_top: {
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 indirect__mode__expansion__alias_6_clear_reason:
  reasonp = reasons;
 indirect__mode__expansion__alias_6_0:
 indirect__mode__expansion__alias_6_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom__3F)) goto indirect__mode__expansion__alias_6_3;
 indirect__mode__expansion__alias_6_2:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom__3F)) goto indirect__mode__expansion__alias_6_3;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xru2mode_2);
  allocp[2] = a3;
  allocp[3] = a5;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_mode_xru2mode_2);
  allocp[6] = a2;
  allocp[7] = a4;
  qp = (struct goalrec*)&allocp[4];
  allocp += 8;
  proceed();
 case VARREF:
  deref_and_jump(a1,indirect__mode__expansion__alias_6_2);
  *reasonp++ =  a1;
  goto indirect__mode__expansion__alias_6_3;
  };
  goto indirect__mode__expansion__alias_6_3;
 case VARREF:
  deref_and_jump(a0,indirect__mode__expansion__alias_6_1);
  *reasonp++ =  a0;
  goto indirect__mode__expansion__alias_6_3;
  };
  goto indirect__mode__expansion__alias_6_3;
 indirect__mode__expansion__alias_6_3:
  otherwise(indirect__mode__expansion__alias_6_interrupt);
  unify2(a4, a0, a5, a1);
  proceed();
 indirect__mode__expansion__alias_6_ext_interrupt:
  reasonp = 0l;
 indirect__mode__expansion__alias_6_interrupt:
  goto interrupt_6;
 }

 expand__ru__indirect_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 expand__ru__indirect_4_clear_reason:
  reasonp = reasons;
 expand__ru__indirect_4_0:
  x0 = a0;
  x1 = a0;
  x2 = a1;
  x3 = a2;
  a4 = a3;
  a3 = x3;
  a2 = x2;
  a1 = x1;
  a0 = x0;
  execute(expand__ru__indirect1_5_0);
  goto expand__ru__indirect1_5_ext_interrupt;
 expand__ru__indirect_4_ext_interrupt:
  reasonp = 0l;
 expand__ru__indirect_4_interrupt:
  goto interrupt_4;
 }

 expand__ru__indirect1_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 expand__ru__indirect1_5_clear_reason:
  reasonp = reasons;
 expand__ru__indirect1_5_0:
 expand__ru__indirect1_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 expand__ru__indirect1_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_unifyaliasdown_2:
  x1 = arg(x0, 0);
 expand__ru__indirect1_5_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_t_4)) goto expand__ru__indirect1_5_16;
  x2 = arg(x1, 0);
 expand__ru__indirect1_5_4:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_v_4)) goto expand__ru__indirect1_5_16;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xexpand__ru__indirect1_5);
  x3 = cdr_of(a0);
  allocp[2] = x3;
  allocp[3] = x4 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x5 = makeref(&allocp[5]);
  allocp[6] = a4;
  a0 = arg(x2, 0);
  x6 = arg(x2, 1);
  a2 = arg(x2, 3);
  x7 = arg(x1, 3);
  a4 = a1;
  a5 = x4;
  a6 = a3;
  a7 = x5;
  a3 = x7;
  a1 = x6;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(expand__ru__indirect__unify_8_0);
  goto expand__ru__indirect__unify_8_ext_interrupt;
 case VARREF:
  deref_and_jump(x2,expand__ru__indirect1_5_4);
  *reasonp++ =  x2;
  goto expand__ru__indirect1_5_16;
  };
  goto expand__ru__indirect1_5_16;
 case VARREF:
  deref_and_jump(x1,expand__ru__indirect1_5_3);
  *reasonp++ =  x1;
  goto expand__ru__indirect1_5_16;
  };
  goto expand__ru__indirect1_5_16;
 case functor_unifyaliasup_2:
  x1 = arg(x0, 0);
 expand__ru__indirect1_5_5:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_t_4)) goto expand__ru__indirect1_5_16;
  x2 = arg(x1, 0);
 expand__ru__indirect1_5_6:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_v_4)) goto expand__ru__indirect1_5_16;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xexpand__ru__indirect1_5);
  x3 = cdr_of(a0);
  allocp[2] = x3;
  allocp[3] = x4 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a4;
  allocp[6] = x5 = makeref(&allocp[6]);
  a0 = arg(x2, 0);
  x6 = arg(x2, 1);
  a2 = arg(x2, 3);
  x7 = arg(x1, 3);
  x8 = a1;
  a5 = x4;
  a6 = a3;
  a7 = a4;
  a4 = x8;
  a3 = x7;
  a1 = x6;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(expand__ru__indirect__unify_8_0);
  goto expand__ru__indirect__unify_8_ext_interrupt;
 case VARREF:
  deref_and_jump(x2,expand__ru__indirect1_5_6);
  *reasonp++ =  x2;
  goto expand__ru__indirect1_5_16;
  };
  goto expand__ru__indirect1_5_16;
 case VARREF:
  deref_and_jump(x1,expand__ru__indirect1_5_5);
  *reasonp++ =  x1;
  goto expand__ru__indirect1_5_16;
  };
  goto expand__ru__indirect1_5_16;
 case functor_unify_2:
  x1 = arg(x0, 0);
 expand__ru__indirect1_5_7:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_t_4)) goto expand__ru__indirect1_5_11;
  x2 = arg(x1, 0);
 expand__ru__indirect1_5_8:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_v_4)) goto expand__ru__indirect1_5_11;
  x3 = arg(x2, 2);
 expand__ru__indirect1_5_9:
  switch (ptagof(x3)) {
 case ATOMIC:
 expand__ru__indirect1_5_10:
  if (x3 != makeint(-1L)) goto expand__ru__indirect1_5_11;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xexpand__ru__indirect1_5);
  x4 = cdr_of(a0);
  allocp[2] = x4;
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x6 = makeref(&allocp[5]);
  allocp[6] = a4;
  a0 = arg(x2, 0);
  x7 = arg(x2, 1);
  a2 = arg(x2, 3);
  x8 = arg(x1, 3);
  a4 = a1;
  a5 = x5;
  a6 = a3;
  a7 = x6;
  a3 = x8;
  a1 = x7;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(expand__ru__indirect__updown_8_0);
  goto expand__ru__indirect__updown_8_ext_interrupt;
 case VARREF:
  deref_and_jump(x3,expand__ru__indirect1_5_9);
  *reasonp++ =  x3;
  goto expand__ru__indirect1_5_11;
  };
  goto expand__ru__indirect1_5_11;
 case VARREF:
  deref_and_jump(x2,expand__ru__indirect1_5_8);
  *reasonp++ =  x2;
  goto expand__ru__indirect1_5_11;
  };
  goto expand__ru__indirect1_5_11;
 case VARREF:
  deref_and_jump(x1,expand__ru__indirect1_5_7);
  *reasonp++ =  x1;
  goto expand__ru__indirect1_5_11;
  };
  goto expand__ru__indirect1_5_11;
 expand__ru__indirect1_5_11:
  x2 = arg(x0, 1);
 expand__ru__indirect1_5_12:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_t_4)) goto expand__ru__indirect1_5_16;
  x3 = arg(x2, 0);
 expand__ru__indirect1_5_13:
  switch (ptagof(x3)) {
 case FUNCTOR:
  if (functor_of(x3) != makesym(functor_v_4)) goto expand__ru__indirect1_5_16;
  x4 = arg(x3, 2);
 expand__ru__indirect1_5_14:
  switch (ptagof(x4)) {
 case ATOMIC:
 expand__ru__indirect1_5_15:
  if (x4 != makeint(-1L)) goto expand__ru__indirect1_5_16;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xexpand__ru__indirect1_5);
  x5 = cdr_of(a0);
  allocp[2] = x5;
  allocp[3] = x6 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x7 = makeref(&allocp[5]);
  allocp[6] = a4;
  a0 = arg(x3, 0);
  x8 = arg(x3, 1);
  a2 = arg(x3, 3);
  x9 = arg(x2, 3);
  a4 = a1;
  a5 = x6;
  a6 = a3;
  a7 = x7;
  a3 = x9;
  a1 = x8;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(expand__ru__indirect__updown_8_clear_reason);
  goto expand__ru__indirect__updown_8_ext_interrupt;
 case VARREF:
  deref_and_jump(x4,expand__ru__indirect1_5_14);
  *reasonp++ =  x4;
  goto expand__ru__indirect1_5_16;
  };
  goto expand__ru__indirect1_5_16;
 case VARREF:
  deref_and_jump(x3,expand__ru__indirect1_5_13);
  *reasonp++ =  x3;
  goto expand__ru__indirect1_5_16;
  };
  goto expand__ru__indirect1_5_16;
 case VARREF:
  deref_and_jump(x2,expand__ru__indirect1_5_12);
  *reasonp++ =  x2;
  goto expand__ru__indirect1_5_16;
  };
  goto expand__ru__indirect1_5_16;
  };
  goto expand__ru__indirect1_5_16;
 case VARREF:
  deref_and_jump(x0,expand__ru__indirect1_5_2);
  *reasonp++ =  x0;
  goto expand__ru__indirect1_5_16;
  };
  goto expand__ru__indirect1_5_16;
 case VARREF:
  deref_and_jump(a0,expand__ru__indirect1_5_1);
  *reasonp++ =  a0;
  goto expand__ru__indirect1_5_16;
  };
  goto expand__ru__indirect1_5_16;
 expand__ru__indirect1_5_16:
  otherwise(expand__ru__indirect1_5_interrupt);
 expand__ru__indirect1_5_17:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(expand__ru__indirect1_5_0);
  goto expand__ru__indirect1_5_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto expand__ru__indirect1_5_interrupt;
  unify2(a2, a1, a4, a3);
  proceed();
 case VARREF:
  deref_and_jump(a0,expand__ru__indirect1_5_17);
  *reasonp++ =  a0;
  goto expand__ru__indirect1_5_interrupt;
  };
  goto expand__ru__indirect1_5_interrupt;
 expand__ru__indirect1_5_ext_interrupt:
  reasonp = 0l;
 expand__ru__indirect1_5_interrupt:
  toppred = &predicate_analyze__type_xexpand__ru__indirect1_5;
  goto interrupt_5;
 }

 expand__ru__indirect__unify_8_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 expand__ru__indirect__unify_8_clear_reason:
  reasonp = reasons;
 expand__ru__indirect__unify_8_0:
 expand__ru__indirect__unify_8_1:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom__3F)) goto expand__ru__indirect__unify_8_2;
  unify2(a5, a4, a7, a6);
  proceed();
 case VARREF:
  deref_and_jump(a3,expand__ru__indirect__unify_8_1);
  *reasonp++ =  a3;
  goto expand__ru__indirect__unify_8_2;
  };
  goto expand__ru__indirect__unify_8_2;
 expand__ru__indirect__unify_8_2:
  otherwise(expand__ru__indirect__unify_8_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xexpand__ru__indirect__unify2_6);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a6;
  allocp[7] = a7;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_analyze__type_xexpand__ru__indirect__unify1_9);
  allocp[10] = a0;
  allocp[11] = a1;
  allocp[12] = a2;
  allocp[13] = x1 = makeref(&allocp[13]);
  allocp[14] = a3;
  allocp[15] = a4;
  allocp[16] = a5;
  allocp[17] = makesym(atom_no);
  allocp[18] = x0;
  allocp[19] = (q)(struct goalrec*)&allocp[8];
  allocp[20] = (q)(&predicate_mode_xreverse__ru_2);
  allocp[21] = a3;
  allocp[22] = x1;
  qp = (struct goalrec*)&allocp[19];
  allocp += 23;
  proceed();
 expand__ru__indirect__unify_8_ext_interrupt:
  reasonp = 0l;
 expand__ru__indirect__unify_8_interrupt:
  toppred = &predicate_analyze__type_xexpand__ru__indirect__unify_8;
  goto interrupt_8;
 }

 expand__ru__indirect__unify2_6_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 expand__ru__indirect__unify2_6_clear_reason:
  reasonp = reasons;
 expand__ru__indirect__unify2_6_0:
 expand__ru__indirect__unify2_6_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto expand__ru__indirect__unify2_6_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_no)):
  unify(a5, a4);
  proceed();
 case symval(makesym(atom_yes)):
  allocp[0] = makesym(functor_variable_3);
  allocp[1] = a3;
  allocp[2] = makeint(-1L);
  allocp[3] = makesym(atom__3F);
  x0 = makefunctor(&allocp[0]);
  allocp[4] = makesym(functor_var_5);
  allocp[5] = a1;
  allocp[6] = a2;
  allocp[7] = makesym(atom_unify);
  allocp[8] = makeint(-1L);
  allocp[9] = x0;
  x1 = makefunctor(&allocp[4]);
  allocp[10] = a4;
  allocp[11] = x1;
  x2 = makecons(&allocp[10]);
  allocp += 12;
  unify_value(a5, x2);
  proceed();
  };
  goto expand__ru__indirect__unify2_6_interrupt;
 case VARREF:
  deref_and_jump(a0,expand__ru__indirect__unify2_6_1);
  *reasonp++ =  a0;
  goto expand__ru__indirect__unify2_6_interrupt;
  };
  goto expand__ru__indirect__unify2_6_interrupt;
 expand__ru__indirect__unify2_6_ext_interrupt:
  reasonp = 0l;
 expand__ru__indirect__unify2_6_interrupt:
  goto interrupt_6;
 }

 expand__ru__indirect__unify1_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 expand__ru__indirect__unify1_9_clear_reason:
  reasonp = reasons;
 expand__ru__indirect__unify1_9_0:
 expand__ru__indirect__unify1_9_1:
  switch (ptagof(a5)) {
 case CONS:
  x0 = car_of(a5);
 expand__ru__indirect__unify1_9_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_unify_2)) goto expand__ru__indirect__unify1_9_38;
  x1 = arg(x0, 0);
 expand__ru__indirect__unify1_9_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_t_4)) goto expand__ru__indirect__unify1_9_20;
  x2 = arg(x1, 0);
 expand__ru__indirect__unify1_9_4:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_v_4)) goto expand__ru__indirect__unify1_9_20;
  x3 = arg(x2, 0);
 expand__ru__indirect__unify1_9_5:
  if (isref(x3)) goto expand__ru__indirect__unify1_9_19;
 expand__ru__indirect__unify1_9_6:
  if (isref(x3)) goto expand__ru__indirect__unify1_9_18;
  if_not_equal(x3, a0, expand__ru__indirect__unify1_9_20);
  x4 = arg(x2, 1);
 expand__ru__indirect__unify1_9_7:
  if (isref(x4)) goto expand__ru__indirect__unify1_9_17;
 expand__ru__indirect__unify1_9_8:
  if (isref(x4)) goto expand__ru__indirect__unify1_9_16;
  if_not_equal(x4, a1, expand__ru__indirect__unify1_9_20);
  x5 = arg(x2, 2);
 expand__ru__indirect__unify1_9_9:
  switch (ptagof(x5)) {
 case ATOMIC:
 expand__ru__indirect__unify1_9_10:
  if (x5 != makeint(-1L)) goto expand__ru__indirect__unify1_9_20;
  x6 = arg(x2, 3);
 expand__ru__indirect__unify1_9_11:
  if (isref(x6)) goto expand__ru__indirect__unify1_9_15;
 expand__ru__indirect__unify1_9_12:
  if (isref(x6)) goto expand__ru__indirect__unify1_9_14;
  if_not_equal(x6, a2, expand__ru__indirect__unify1_9_20);
  x7 = arg(x1, 3);
 expand__ru__indirect__unify1_9_13:
  switch (ptagof(x7)) {
 case ATOMIC:
  if (x7 != makesym(atom__3F)) goto expand__ru__indirect__unify1_9_20;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xexpand__ru__indirect__unify1_9);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  x8 = cdr_of(a5);
  allocp[7] = x8;
  allocp[8] = x9 = makeref(&allocp[8]);
  allocp[9] = makesym(atom_yes);
  allocp[10] = a8;
  allocp[11] = makesym(functor_unify_2);
  allocp[12] = x11 = makeref(&allocp[12]);
  allocp[13] = x12 = makeref(&allocp[13]);
  x10 = makefunctor(&allocp[11]);
  allocp[14] = x9;
  allocp[15] = x10;
  x13 = makecons(&allocp[14]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 16;
  unify_value(a6, x13);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = makeint(4L);
  x14 = arg(x0, 1);
  allocp[3] = x14;
  allocp[4] = a4;
  allocp[5] = x12;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[8] = makeint(4L);
  allocp[9] = x1;
  allocp[10] = a3;
  allocp[11] = x11;
  qp = (struct goalrec*)&allocp[6];
  allocp += 12;
  proceed();
 case VARREF:
  deref_and_jump(x7,expand__ru__indirect__unify1_9_13);
  *reasonp++ =  x7;
  goto expand__ru__indirect__unify1_9_20;
  };
  goto expand__ru__indirect__unify1_9_20;
 expand__ru__indirect__unify1_9_14:
  deref_and_jump(x6,expand__ru__indirect__unify1_9_12);
  *reasonp++ =  x6;
  goto expand__ru__indirect__unify1_9_20;
 expand__ru__indirect__unify1_9_15:
  deref_and_jump(x6,expand__ru__indirect__unify1_9_11);
  *reasonp++ =  x6;
  goto expand__ru__indirect__unify1_9_20;
 case VARREF:
  deref_and_jump(x5,expand__ru__indirect__unify1_9_9);
  *reasonp++ =  x5;
  goto expand__ru__indirect__unify1_9_20;
  };
  goto expand__ru__indirect__unify1_9_20;
 expand__ru__indirect__unify1_9_16:
  deref_and_jump(x4,expand__ru__indirect__unify1_9_8);
  *reasonp++ =  x4;
  goto expand__ru__indirect__unify1_9_20;
 expand__ru__indirect__unify1_9_17:
  deref_and_jump(x4,expand__ru__indirect__unify1_9_7);
  *reasonp++ =  x4;
  goto expand__ru__indirect__unify1_9_20;
 expand__ru__indirect__unify1_9_18:
  deref_and_jump(x3,expand__ru__indirect__unify1_9_6);
  *reasonp++ =  x3;
  goto expand__ru__indirect__unify1_9_20;
 expand__ru__indirect__unify1_9_19:
  deref_and_jump(x3,expand__ru__indirect__unify1_9_5);
  *reasonp++ =  x3;
  goto expand__ru__indirect__unify1_9_20;
 case VARREF:
  deref_and_jump(x2,expand__ru__indirect__unify1_9_4);
  *reasonp++ =  x2;
  goto expand__ru__indirect__unify1_9_20;
  };
  goto expand__ru__indirect__unify1_9_20;
 case VARREF:
  deref_and_jump(x1,expand__ru__indirect__unify1_9_3);
  *reasonp++ =  x1;
  goto expand__ru__indirect__unify1_9_20;
  };
  goto expand__ru__indirect__unify1_9_20;
 expand__ru__indirect__unify1_9_20:
  x2 = arg(x0, 1);
 expand__ru__indirect__unify1_9_21:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_t_4)) goto expand__ru__indirect__unify1_9_38;
  x3 = arg(x2, 0);
 expand__ru__indirect__unify1_9_22:
  switch (ptagof(x3)) {
 case FUNCTOR:
  if (functor_of(x3) != makesym(functor_v_4)) goto expand__ru__indirect__unify1_9_38;
  x4 = arg(x3, 0);
 expand__ru__indirect__unify1_9_23:
  if (isref(x4)) goto expand__ru__indirect__unify1_9_37;
 expand__ru__indirect__unify1_9_24:
  if (isref(x4)) goto expand__ru__indirect__unify1_9_36;
  if_not_equal(x4, a0, expand__ru__indirect__unify1_9_38);
  x5 = arg(x3, 1);
 expand__ru__indirect__unify1_9_25:
  if (isref(x5)) goto expand__ru__indirect__unify1_9_35;
 expand__ru__indirect__unify1_9_26:
  if (isref(x5)) goto expand__ru__indirect__unify1_9_34;
  if_not_equal(x5, a1, expand__ru__indirect__unify1_9_38);
  x6 = arg(x3, 2);
 expand__ru__indirect__unify1_9_27:
  switch (ptagof(x6)) {
 case ATOMIC:
 expand__ru__indirect__unify1_9_28:
  if (x6 != makeint(-1L)) goto expand__ru__indirect__unify1_9_38;
  x7 = arg(x3, 3);
 expand__ru__indirect__unify1_9_29:
  if (isref(x7)) goto expand__ru__indirect__unify1_9_33;
 expand__ru__indirect__unify1_9_30:
  if (isref(x7)) goto expand__ru__indirect__unify1_9_32;
  if_not_equal(x7, a2, expand__ru__indirect__unify1_9_38);
  x8 = arg(x2, 3);
 expand__ru__indirect__unify1_9_31:
  switch (ptagof(x8)) {
 case ATOMIC:
  if (x8 != makesym(atom__3F)) goto expand__ru__indirect__unify1_9_38;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xexpand__ru__indirect__unify1_9);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  x9 = cdr_of(a5);
  allocp[7] = x9;
  allocp[8] = x10 = makeref(&allocp[8]);
  allocp[9] = makesym(atom_yes);
  allocp[10] = a8;
  allocp[11] = makesym(functor_unify_2);
  allocp[12] = x12 = makeref(&allocp[12]);
  allocp[13] = x13 = makeref(&allocp[13]);
  x11 = makefunctor(&allocp[11]);
  allocp[14] = x10;
  allocp[15] = x11;
  x14 = makecons(&allocp[14]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 16;
  unify_value(a6, x14);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = makeint(4L);
  allocp[3] = x1;
  allocp[4] = a4;
  allocp[5] = x12;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[8] = makeint(4L);
  allocp[9] = x2;
  allocp[10] = a3;
  allocp[11] = x13;
  qp = (struct goalrec*)&allocp[6];
  allocp += 12;
  proceed();
 case VARREF:
  deref_and_jump(x8,expand__ru__indirect__unify1_9_31);
  *reasonp++ =  x8;
  goto expand__ru__indirect__unify1_9_38;
  };
  goto expand__ru__indirect__unify1_9_38;
 expand__ru__indirect__unify1_9_32:
  deref_and_jump(x7,expand__ru__indirect__unify1_9_30);
  *reasonp++ =  x7;
  goto expand__ru__indirect__unify1_9_38;
 expand__ru__indirect__unify1_9_33:
  deref_and_jump(x7,expand__ru__indirect__unify1_9_29);
  *reasonp++ =  x7;
  goto expand__ru__indirect__unify1_9_38;
 case VARREF:
  deref_and_jump(x6,expand__ru__indirect__unify1_9_27);
  *reasonp++ =  x6;
  goto expand__ru__indirect__unify1_9_38;
  };
  goto expand__ru__indirect__unify1_9_38;
 expand__ru__indirect__unify1_9_34:
  deref_and_jump(x5,expand__ru__indirect__unify1_9_26);
  *reasonp++ =  x5;
  goto expand__ru__indirect__unify1_9_38;
 expand__ru__indirect__unify1_9_35:
  deref_and_jump(x5,expand__ru__indirect__unify1_9_25);
  *reasonp++ =  x5;
  goto expand__ru__indirect__unify1_9_38;
 expand__ru__indirect__unify1_9_36:
  deref_and_jump(x4,expand__ru__indirect__unify1_9_24);
  *reasonp++ =  x4;
  goto expand__ru__indirect__unify1_9_38;
 expand__ru__indirect__unify1_9_37:
  deref_and_jump(x4,expand__ru__indirect__unify1_9_23);
  *reasonp++ =  x4;
  goto expand__ru__indirect__unify1_9_38;
 case VARREF:
  deref_and_jump(x3,expand__ru__indirect__unify1_9_22);
  *reasonp++ =  x3;
  goto expand__ru__indirect__unify1_9_38;
  };
  goto expand__ru__indirect__unify1_9_38;
 case VARREF:
  deref_and_jump(x2,expand__ru__indirect__unify1_9_21);
  *reasonp++ =  x2;
  goto expand__ru__indirect__unify1_9_38;
  };
  goto expand__ru__indirect__unify1_9_38;
 case VARREF:
  deref_and_jump(x0,expand__ru__indirect__unify1_9_2);
  *reasonp++ =  x0;
  goto expand__ru__indirect__unify1_9_38;
  };
  goto expand__ru__indirect__unify1_9_38;
 case VARREF:
  deref_and_jump(a5,expand__ru__indirect__unify1_9_1);
  *reasonp++ =  a5;
  goto expand__ru__indirect__unify1_9_38;
  };
  goto expand__ru__indirect__unify1_9_38;
 expand__ru__indirect__unify1_9_38:
  otherwise(expand__ru__indirect__unify1_9_interrupt);
 expand__ru__indirect__unify1_9_39:
  switch (ptagof(a5)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = car_of(a5);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a6, x0);
  a5 = cdr_of(a5);
  a6 = x1;
  execute(expand__ru__indirect__unify1_9_0);
  goto expand__ru__indirect__unify1_9_ext_interrupt;
 case ATOMIC:
  if (a5 != NILATOM) goto expand__ru__indirect__unify1_9_interrupt;
  unify_value(a6, NILATOM);
  unify(a8, a7);
  proceed();
 case VARREF:
  deref_and_jump(a5,expand__ru__indirect__unify1_9_39);
  *reasonp++ =  a5;
  goto expand__ru__indirect__unify1_9_interrupt;
  };
  goto expand__ru__indirect__unify1_9_interrupt;
 expand__ru__indirect__unify1_9_ext_interrupt:
  reasonp = 0l;
 expand__ru__indirect__unify1_9_interrupt:
  goto interrupt_9;
 }

 expand__ru__indirect__updown_8_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 expand__ru__indirect__updown_8_clear_reason:
  reasonp = reasons;
 expand__ru__indirect__updown_8_0:
 expand__ru__indirect__updown_8_1:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom__3F)) goto expand__ru__indirect__updown_8_2;
  unify2(a5, a4, a7, a6);
  proceed();
 case VARREF:
  deref_and_jump(a3,expand__ru__indirect__updown_8_1);
  *reasonp++ =  a3;
  goto expand__ru__indirect__updown_8_2;
  };
  goto expand__ru__indirect__updown_8_2;
 expand__ru__indirect__updown_8_2:
  otherwise(expand__ru__indirect__updown_8_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xexpand__ru__indirect__updown2_6);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a6;
  allocp[7] = a7;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_analyze__type_xexpand__ru__indirect__updown1_9);
  allocp[10] = a0;
  allocp[11] = a1;
  allocp[12] = a2;
  allocp[13] = x1 = makeref(&allocp[13]);
  allocp[14] = a3;
  allocp[15] = a4;
  allocp[16] = a5;
  allocp[17] = makesym(atom_no);
  allocp[18] = x0;
  allocp[19] = (q)(struct goalrec*)&allocp[8];
  allocp[20] = (q)(&predicate_mode_xreverse__ru_2);
  allocp[21] = a3;
  allocp[22] = x1;
  qp = (struct goalrec*)&allocp[19];
  allocp += 23;
  proceed();
 expand__ru__indirect__updown_8_ext_interrupt:
  reasonp = 0l;
 expand__ru__indirect__updown_8_interrupt:
  toppred = &predicate_analyze__type_xexpand__ru__indirect__updown_8;
  goto interrupt_8;
 }

 expand__ru__indirect__updown2_6_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 expand__ru__indirect__updown2_6_clear_reason:
  reasonp = reasons;
 expand__ru__indirect__updown2_6_0:
 expand__ru__indirect__updown2_6_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto expand__ru__indirect__updown2_6_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_no)):
  unify(a5, a4);
  proceed();
 case symval(makesym(atom_yes)):
  allocp[0] = makesym(functor_variable_3);
  allocp[1] = a3;
  allocp[2] = makeint(-1L);
  allocp[3] = makesym(atom__3F);
  x0 = makefunctor(&allocp[0]);
  allocp[4] = makesym(functor_var_5);
  allocp[5] = a1;
  allocp[6] = a2;
  allocp[7] = makesym(atom_unify);
  allocp[8] = makeint(-1L);
  allocp[9] = x0;
  x1 = makefunctor(&allocp[4]);
  allocp[10] = a4;
  allocp[11] = x1;
  x2 = makecons(&allocp[10]);
  allocp += 12;
  unify_value(a5, x2);
  proceed();
  };
  goto expand__ru__indirect__updown2_6_interrupt;
 case VARREF:
  deref_and_jump(a0,expand__ru__indirect__updown2_6_1);
  *reasonp++ =  a0;
  goto expand__ru__indirect__updown2_6_interrupt;
  };
  goto expand__ru__indirect__updown2_6_interrupt;
 expand__ru__indirect__updown2_6_ext_interrupt:
  reasonp = 0l;
 expand__ru__indirect__updown2_6_interrupt:
  goto interrupt_6;
 }

 expand__ru__indirect__updown1_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 expand__ru__indirect__updown1_9_clear_reason:
  reasonp = reasons;
 expand__ru__indirect__updown1_9_0:
 expand__ru__indirect__updown1_9_1:
  switch (ptagof(a5)) {
 case CONS:
  x0 = car_of(a5);
 expand__ru__indirect__updown1_9_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_unifyaliasdown_2:
  x1 = arg(x0, 0);
 expand__ru__indirect__updown1_9_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_t_4)) goto expand__ru__indirect__updown1_9_37;
  x2 = arg(x1, 0);
 expand__ru__indirect__updown1_9_4:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_v_4)) goto expand__ru__indirect__updown1_9_37;
  x3 = arg(x2, 0);
 expand__ru__indirect__updown1_9_5:
  if (isref(x3)) goto expand__ru__indirect__updown1_9_19;
 expand__ru__indirect__updown1_9_6:
  if (isref(x3)) goto expand__ru__indirect__updown1_9_18;
  if_not_equal(x3, a0, expand__ru__indirect__updown1_9_37);
  x4 = arg(x2, 1);
 expand__ru__indirect__updown1_9_7:
  if (isref(x4)) goto expand__ru__indirect__updown1_9_17;
 expand__ru__indirect__updown1_9_8:
  if (isref(x4)) goto expand__ru__indirect__updown1_9_16;
  if_not_equal(x4, a1, expand__ru__indirect__updown1_9_37);
  x5 = arg(x2, 2);
 expand__ru__indirect__updown1_9_9:
  switch (ptagof(x5)) {
 case ATOMIC:
 expand__ru__indirect__updown1_9_10:
  if (x5 != makeint(-1L)) goto expand__ru__indirect__updown1_9_37;
  x6 = arg(x2, 3);
 expand__ru__indirect__updown1_9_11:
  if (isref(x6)) goto expand__ru__indirect__updown1_9_15;
 expand__ru__indirect__updown1_9_12:
  if (isref(x6)) goto expand__ru__indirect__updown1_9_14;
  if_not_equal(x6, a2, expand__ru__indirect__updown1_9_37);
  x7 = arg(x1, 3);
 expand__ru__indirect__updown1_9_13:
  switch (ptagof(x7)) {
 case ATOMIC:
  if (x7 != makesym(atom__3F)) goto expand__ru__indirect__updown1_9_37;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xexpand__ru__indirect__updown1_9);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  x8 = cdr_of(a5);
  allocp[7] = x8;
  allocp[8] = x9 = makeref(&allocp[8]);
  allocp[9] = makesym(atom_yes);
  allocp[10] = a8;
  allocp[11] = makesym(functor_unifyaliasdown_2);
  allocp[12] = x11 = makeref(&allocp[12]);
  allocp[13] = x12 = makeref(&allocp[13]);
  x10 = makefunctor(&allocp[11]);
  allocp[14] = x9;
  allocp[15] = x10;
  x13 = makecons(&allocp[14]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 16;
  unify_value(a6, x13);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = makeint(4L);
  x14 = arg(x0, 1);
  allocp[3] = x14;
  allocp[4] = a4;
  allocp[5] = x12;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[8] = makeint(4L);
  allocp[9] = x1;
  allocp[10] = a3;
  allocp[11] = x11;
  qp = (struct goalrec*)&allocp[6];
  allocp += 12;
  proceed();
 case VARREF:
  deref_and_jump(x7,expand__ru__indirect__updown1_9_13);
  *reasonp++ =  x7;
  goto expand__ru__indirect__updown1_9_37;
  };
  goto expand__ru__indirect__updown1_9_37;
 expand__ru__indirect__updown1_9_14:
  deref_and_jump(x6,expand__ru__indirect__updown1_9_12);
  *reasonp++ =  x6;
  goto expand__ru__indirect__updown1_9_37;
 expand__ru__indirect__updown1_9_15:
  deref_and_jump(x6,expand__ru__indirect__updown1_9_11);
  *reasonp++ =  x6;
  goto expand__ru__indirect__updown1_9_37;
 case VARREF:
  deref_and_jump(x5,expand__ru__indirect__updown1_9_9);
  *reasonp++ =  x5;
  goto expand__ru__indirect__updown1_9_37;
  };
  goto expand__ru__indirect__updown1_9_37;
 expand__ru__indirect__updown1_9_16:
  deref_and_jump(x4,expand__ru__indirect__updown1_9_8);
  *reasonp++ =  x4;
  goto expand__ru__indirect__updown1_9_37;
 expand__ru__indirect__updown1_9_17:
  deref_and_jump(x4,expand__ru__indirect__updown1_9_7);
  *reasonp++ =  x4;
  goto expand__ru__indirect__updown1_9_37;
 expand__ru__indirect__updown1_9_18:
  deref_and_jump(x3,expand__ru__indirect__updown1_9_6);
  *reasonp++ =  x3;
  goto expand__ru__indirect__updown1_9_37;
 expand__ru__indirect__updown1_9_19:
  deref_and_jump(x3,expand__ru__indirect__updown1_9_5);
  *reasonp++ =  x3;
  goto expand__ru__indirect__updown1_9_37;
 case VARREF:
  deref_and_jump(x2,expand__ru__indirect__updown1_9_4);
  *reasonp++ =  x2;
  goto expand__ru__indirect__updown1_9_37;
  };
  goto expand__ru__indirect__updown1_9_37;
 case VARREF:
  deref_and_jump(x1,expand__ru__indirect__updown1_9_3);
  *reasonp++ =  x1;
  goto expand__ru__indirect__updown1_9_37;
  };
  goto expand__ru__indirect__updown1_9_37;
 case functor_unifyaliasup_2:
  x1 = arg(x0, 0);
 expand__ru__indirect__updown1_9_20:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_t_4)) goto expand__ru__indirect__updown1_9_37;
  x2 = arg(x1, 0);
 expand__ru__indirect__updown1_9_21:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_v_4)) goto expand__ru__indirect__updown1_9_37;
  x3 = arg(x2, 0);
 expand__ru__indirect__updown1_9_22:
  if (isref(x3)) goto expand__ru__indirect__updown1_9_36;
 expand__ru__indirect__updown1_9_23:
  if (isref(x3)) goto expand__ru__indirect__updown1_9_35;
  if_not_equal(x3, a0, expand__ru__indirect__updown1_9_37);
  x4 = arg(x2, 1);
 expand__ru__indirect__updown1_9_24:
  if (isref(x4)) goto expand__ru__indirect__updown1_9_34;
 expand__ru__indirect__updown1_9_25:
  if (isref(x4)) goto expand__ru__indirect__updown1_9_33;
  if_not_equal(x4, a1, expand__ru__indirect__updown1_9_37);
  x5 = arg(x2, 2);
 expand__ru__indirect__updown1_9_26:
  switch (ptagof(x5)) {
 case ATOMIC:
 expand__ru__indirect__updown1_9_27:
  if (x5 != makeint(-1L)) goto expand__ru__indirect__updown1_9_37;
  x6 = arg(x2, 3);
 expand__ru__indirect__updown1_9_28:
  if (isref(x6)) goto expand__ru__indirect__updown1_9_32;
 expand__ru__indirect__updown1_9_29:
  if (isref(x6)) goto expand__ru__indirect__updown1_9_31;
  if_not_equal(x6, a2, expand__ru__indirect__updown1_9_37);
  x7 = arg(x1, 3);
 expand__ru__indirect__updown1_9_30:
  switch (ptagof(x7)) {
 case ATOMIC:
  if (x7 != makesym(atom__3F)) goto expand__ru__indirect__updown1_9_37;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xexpand__ru__indirect__updown1_9);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  x8 = cdr_of(a5);
  allocp[7] = x8;
  allocp[8] = x9 = makeref(&allocp[8]);
  allocp[9] = makesym(atom_yes);
  allocp[10] = a8;
  allocp[11] = makesym(functor_unifyaliasup_2);
  allocp[12] = x11 = makeref(&allocp[12]);
  allocp[13] = x12 = makeref(&allocp[13]);
  x10 = makefunctor(&allocp[11]);
  allocp[14] = x9;
  allocp[15] = x10;
  x13 = makecons(&allocp[14]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 16;
  unify_value(a6, x13);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = makeint(4L);
  x14 = arg(x0, 1);
  allocp[3] = x14;
  allocp[4] = a4;
  allocp[5] = x12;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[8] = makeint(4L);
  allocp[9] = x1;
  allocp[10] = a3;
  allocp[11] = x11;
  qp = (struct goalrec*)&allocp[6];
  allocp += 12;
  proceed();
 case VARREF:
  deref_and_jump(x7,expand__ru__indirect__updown1_9_30);
  *reasonp++ =  x7;
  goto expand__ru__indirect__updown1_9_37;
  };
  goto expand__ru__indirect__updown1_9_37;
 expand__ru__indirect__updown1_9_31:
  deref_and_jump(x6,expand__ru__indirect__updown1_9_29);
  *reasonp++ =  x6;
  goto expand__ru__indirect__updown1_9_37;
 expand__ru__indirect__updown1_9_32:
  deref_and_jump(x6,expand__ru__indirect__updown1_9_28);
  *reasonp++ =  x6;
  goto expand__ru__indirect__updown1_9_37;
 case VARREF:
  deref_and_jump(x5,expand__ru__indirect__updown1_9_26);
  *reasonp++ =  x5;
  goto expand__ru__indirect__updown1_9_37;
  };
  goto expand__ru__indirect__updown1_9_37;
 expand__ru__indirect__updown1_9_33:
  deref_and_jump(x4,expand__ru__indirect__updown1_9_25);
  *reasonp++ =  x4;
  goto expand__ru__indirect__updown1_9_37;
 expand__ru__indirect__updown1_9_34:
  deref_and_jump(x4,expand__ru__indirect__updown1_9_24);
  *reasonp++ =  x4;
  goto expand__ru__indirect__updown1_9_37;
 expand__ru__indirect__updown1_9_35:
  deref_and_jump(x3,expand__ru__indirect__updown1_9_23);
  *reasonp++ =  x3;
  goto expand__ru__indirect__updown1_9_37;
 expand__ru__indirect__updown1_9_36:
  deref_and_jump(x3,expand__ru__indirect__updown1_9_22);
  *reasonp++ =  x3;
  goto expand__ru__indirect__updown1_9_37;
 case VARREF:
  deref_and_jump(x2,expand__ru__indirect__updown1_9_21);
  *reasonp++ =  x2;
  goto expand__ru__indirect__updown1_9_37;
  };
  goto expand__ru__indirect__updown1_9_37;
 case VARREF:
  deref_and_jump(x1,expand__ru__indirect__updown1_9_20);
  *reasonp++ =  x1;
  goto expand__ru__indirect__updown1_9_37;
  };
  goto expand__ru__indirect__updown1_9_37;
  };
  goto expand__ru__indirect__updown1_9_37;
 case VARREF:
  deref_and_jump(x0,expand__ru__indirect__updown1_9_2);
  *reasonp++ =  x0;
  goto expand__ru__indirect__updown1_9_37;
  };
  goto expand__ru__indirect__updown1_9_37;
 case VARREF:
  deref_and_jump(a5,expand__ru__indirect__updown1_9_1);
  *reasonp++ =  a5;
  goto expand__ru__indirect__updown1_9_37;
  };
  goto expand__ru__indirect__updown1_9_37;
 expand__ru__indirect__updown1_9_37:
  otherwise(expand__ru__indirect__updown1_9_interrupt);
 expand__ru__indirect__updown1_9_38:
  switch (ptagof(a5)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = car_of(a5);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a6, x0);
  a5 = cdr_of(a5);
  a6 = x1;
  execute(expand__ru__indirect__updown1_9_0);
  goto expand__ru__indirect__updown1_9_ext_interrupt;
 case ATOMIC:
  if (a5 != NILATOM) goto expand__ru__indirect__updown1_9_interrupt;
  unify_value(a6, NILATOM);
  unify(a8, a7);
  proceed();
 case VARREF:
  deref_and_jump(a5,expand__ru__indirect__updown1_9_38);
  *reasonp++ =  a5;
  goto expand__ru__indirect__updown1_9_interrupt;
  };
  goto expand__ru__indirect__updown1_9_interrupt;
 expand__ru__indirect__updown1_9_ext_interrupt:
  reasonp = 0l;
 expand__ru__indirect__updown1_9_interrupt:
  goto interrupt_9;
 }

 remove__redundant__indirect_2_top: {
  q x0, x1;
  qp = qp->next;
 remove__redundant__indirect_2_clear_reason:
  reasonp = reasons;
 remove__redundant__indirect_2_0:
  x0 = a0;
  x1 = a0;
  a2 = a1;
  a1 = x1;
  a0 = x0;
  execute(remove__redundant__indirect1_3_0);
  goto remove__redundant__indirect1_3_ext_interrupt;
 remove__redundant__indirect_2_ext_interrupt:
  reasonp = 0l;
 remove__redundant__indirect_2_interrupt:
  goto interrupt_2;
 }

 remove__redundant__indirect1_3_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  qp = qp->next;
 remove__redundant__indirect1_3_clear_reason:
  reasonp = reasons;
 remove__redundant__indirect1_3_0:
 remove__redundant__indirect1_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 remove__redundant__indirect1_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_unifyaliasdown_2:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xremove__redundant__indirect1_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  a0 = arg(x0, 0);
  x3 = arg(x0, 1);
  a2 = a1;
  a3 = x2;
  a1 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(remove__redandant__indirect2_4_0);
  goto remove__redandant__indirect2_4_ext_interrupt;
 case functor_unifyaliasup_2:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xremove__redundant__indirect1_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x3 = makeref(&allocp[5]);
  a0 = x3;
  x4 = arg(x0, 1);
  a2 = a1;
  a3 = x2;
  a1 = x4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(remove__redandant__indirect2_4_0);
  goto remove__redandant__indirect2_4_ext_interrupt;
  };
  goto remove__redundant__indirect1_3_3;
 case VARREF:
  deref_and_jump(x0,remove__redundant__indirect1_3_2);
  *reasonp++ =  x0;
  goto remove__redundant__indirect1_3_3;
  };
  goto remove__redundant__indirect1_3_3;
 case VARREF:
  deref_and_jump(a0,remove__redundant__indirect1_3_1);
  *reasonp++ =  a0;
  goto remove__redundant__indirect1_3_3;
  };
  goto remove__redundant__indirect1_3_3;
 remove__redundant__indirect1_3_3:
  otherwise(remove__redundant__indirect1_3_interrupt);
 remove__redundant__indirect1_3_4:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(remove__redundant__indirect1_3_0);
  goto remove__redundant__indirect1_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto remove__redundant__indirect1_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,remove__redundant__indirect1_3_4);
  *reasonp++ =  a0;
  goto remove__redundant__indirect1_3_interrupt;
  };
  goto remove__redundant__indirect1_3_interrupt;
 remove__redundant__indirect1_3_ext_interrupt:
  reasonp = 0l;
 remove__redundant__indirect1_3_interrupt:
  toppred = &predicate_analyze__type_xremove__redundant__indirect1_3;
  goto interrupt_3;
 }

 remove__redandant__indirect2_4_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 remove__redandant__indirect2_4_clear_reason:
  reasonp = reasons;
 remove__redandant__indirect2_4_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xremove__redandant__indirect__unify_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a3;
  a3 = x1;
  a4 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(remove__redandant__indirect__updown_5_0);
  goto remove__redandant__indirect__updown_5_ext_interrupt;
 remove__redandant__indirect2_4_ext_interrupt:
  reasonp = 0l;
 remove__redandant__indirect2_4_interrupt:
  toppred = &predicate_analyze__type_xremove__redandant__indirect2_4;
  goto interrupt_4;
 }

 remove__redandant__indirect__updown_5_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 remove__redandant__indirect__updown_5_clear_reason:
  reasonp = reasons;
 remove__redandant__indirect__updown_5_0:
 remove__redandant__indirect__updown_5_1:
  switch (ptagof(a2)) {
 case CONS:
  x0 = car_of(a2);
 remove__redandant__indirect__updown_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_unifyaliasdown_2)) goto remove__redandant__indirect__updown_5_11;
  x1 = arg(x0, 0);
 remove__redandant__indirect__updown_5_3:
  if (isref(x1)) goto remove__redandant__indirect__updown_5_10;
 remove__redandant__indirect__updown_5_4:
  if (isref(x1)) goto remove__redandant__indirect__updown_5_9;
  if_not_equal(x1, a0, remove__redandant__indirect__updown_5_11);
  x2 = arg(x0, 1);
 remove__redandant__indirect__updown_5_5:
  if (isref(x2)) goto remove__redandant__indirect__updown_5_8;
 remove__redandant__indirect__updown_5_6:
  if (isref(x2)) goto remove__redandant__indirect__updown_5_7;
  if_not_equal(x2, a1, remove__redandant__indirect__updown_5_11);
  allocp[0] = x4 = makeref(&allocp[0]);
  allocp[1] = x0;
  x3 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a3, x3);
  a2 = cdr_of(a2);
  a3 = x4;
  execute(remove__redandant__indirect__updown_5_clear_reason);
  goto remove__redandant__indirect__updown_5_ext_interrupt;
 remove__redandant__indirect__updown_5_7:
  deref_and_jump(x2,remove__redandant__indirect__updown_5_6);
  *reasonp++ =  x2;
  goto remove__redandant__indirect__updown_5_11;
 remove__redandant__indirect__updown_5_8:
  deref_and_jump(x2,remove__redandant__indirect__updown_5_5);
  *reasonp++ =  x2;
  goto remove__redandant__indirect__updown_5_11;
 remove__redandant__indirect__updown_5_9:
  deref_and_jump(x1,remove__redandant__indirect__updown_5_4);
  *reasonp++ =  x1;
  goto remove__redandant__indirect__updown_5_11;
 remove__redandant__indirect__updown_5_10:
  deref_and_jump(x1,remove__redandant__indirect__updown_5_3);
  *reasonp++ =  x1;
  goto remove__redandant__indirect__updown_5_11;
 case VARREF:
  deref_and_jump(x0,remove__redandant__indirect__updown_5_2);
  *reasonp++ =  x0;
  goto remove__redandant__indirect__updown_5_11;
  };
  goto remove__redandant__indirect__updown_5_11;
 case VARREF:
  deref_and_jump(a2,remove__redandant__indirect__updown_5_1);
  *reasonp++ =  a2;
  goto remove__redandant__indirect__updown_5_11;
  };
  goto remove__redandant__indirect__updown_5_11;
 remove__redandant__indirect__updown_5_11:
  otherwise(remove__redandant__indirect__updown_5_interrupt);
 remove__redandant__indirect__updown_5_12:
  switch (ptagof(a2)) {
 case CONS:
  x0 = car_of(a2);
 remove__redandant__indirect__updown_5_13:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_unifyaliasdown_2:
  x1 = arg(x0, 1);
 remove__redandant__indirect__updown_5_14:
  if (isref(x1)) goto remove__redandant__indirect__updown_5_17;
 remove__redandant__indirect__updown_5_15:
  if (isref(x1)) goto remove__redandant__indirect__updown_5_16;
  if_not_equal(x1, a1, remove__redandant__indirect__updown_5_26);
  allocp[0] = x3 = makeref(&allocp[0]);
  allocp[1] = x4 = makeref(&allocp[1]);
  x2 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a4, x2);
  a2 = cdr_of(a2);
  allocp[0] = x5 = makeref(&allocp[0]);
  a4 = x5;
  allocp += 1;
  execute(remove__redandant__indirect__updown_5_clear_reason);
  goto remove__redandant__indirect__updown_5_ext_interrupt;
 remove__redandant__indirect__updown_5_16:
  deref_and_jump(x1,remove__redandant__indirect__updown_5_15);
  *reasonp++ =  x1;
  goto remove__redandant__indirect__updown_5_26;
 remove__redandant__indirect__updown_5_17:
  deref_and_jump(x1,remove__redandant__indirect__updown_5_14);
  *reasonp++ =  x1;
  goto remove__redandant__indirect__updown_5_26;
 case functor_unifyaliasup_2:
  x1 = arg(x0, 0);
 remove__redandant__indirect__updown_5_18:
  if (isref(x1)) goto remove__redandant__indirect__updown_5_25;
 remove__redandant__indirect__updown_5_19:
  if (isref(x1)) goto remove__redandant__indirect__updown_5_24;
  if_not_equal(x1, a0, remove__redandant__indirect__updown_5_26);
  x2 = arg(x0, 1);
 remove__redandant__indirect__updown_5_20:
  if (isref(x2)) goto remove__redandant__indirect__updown_5_23;
 remove__redandant__indirect__updown_5_21:
  if (isref(x2)) goto remove__redandant__indirect__updown_5_22;
  if_not_equal(x2, a1, remove__redandant__indirect__updown_5_26);
  allocp[0] = x4 = makeref(&allocp[0]);
  allocp[1] = x0;
  x3 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a3, x3);
  a2 = cdr_of(a2);
  a3 = x4;
  execute(remove__redandant__indirect__updown_5_clear_reason);
  goto remove__redandant__indirect__updown_5_ext_interrupt;
 remove__redandant__indirect__updown_5_22:
  deref_and_jump(x2,remove__redandant__indirect__updown_5_21);
  *reasonp++ =  x2;
  goto remove__redandant__indirect__updown_5_26;
 remove__redandant__indirect__updown_5_23:
  deref_and_jump(x2,remove__redandant__indirect__updown_5_20);
  *reasonp++ =  x2;
  goto remove__redandant__indirect__updown_5_26;
 remove__redandant__indirect__updown_5_24:
  deref_and_jump(x1,remove__redandant__indirect__updown_5_19);
  *reasonp++ =  x1;
  goto remove__redandant__indirect__updown_5_26;
 remove__redandant__indirect__updown_5_25:
  deref_and_jump(x1,remove__redandant__indirect__updown_5_18);
  *reasonp++ =  x1;
  goto remove__redandant__indirect__updown_5_26;
  };
  goto remove__redandant__indirect__updown_5_26;
 case VARREF:
  deref_and_jump(x0,remove__redandant__indirect__updown_5_13);
  *reasonp++ =  x0;
  goto remove__redandant__indirect__updown_5_26;
  };
  goto remove__redandant__indirect__updown_5_26;
 case VARREF:
  deref_and_jump(a2,remove__redandant__indirect__updown_5_12);
  *reasonp++ =  a2;
  goto remove__redandant__indirect__updown_5_26;
  };
  goto remove__redandant__indirect__updown_5_26;
 remove__redandant__indirect__updown_5_26:
  otherwise(remove__redandant__indirect__updown_5_interrupt);
 remove__redandant__indirect__updown_5_27:
  switch (ptagof(a2)) {
 case CONS:
  x0 = car_of(a2);
 remove__redandant__indirect__updown_5_28:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_unifyaliasup_2)) goto remove__redandant__indirect__updown_5_33;
  x1 = arg(x0, 1);
 remove__redandant__indirect__updown_5_29:
  if (isref(x1)) goto remove__redandant__indirect__updown_5_32;
 remove__redandant__indirect__updown_5_30:
  if (isref(x1)) goto remove__redandant__indirect__updown_5_31;
  if_not_equal(x1, a1, remove__redandant__indirect__updown_5_33);
  allocp[0] = x3 = makeref(&allocp[0]);
  allocp[1] = x4 = makeref(&allocp[1]);
  x2 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a4, x2);
  a2 = cdr_of(a2);
  allocp[0] = x5 = makeref(&allocp[0]);
  a4 = x5;
  allocp += 1;
  execute(remove__redandant__indirect__updown_5_clear_reason);
  goto remove__redandant__indirect__updown_5_ext_interrupt;
 remove__redandant__indirect__updown_5_31:
  deref_and_jump(x1,remove__redandant__indirect__updown_5_30);
  *reasonp++ =  x1;
  goto remove__redandant__indirect__updown_5_33;
 remove__redandant__indirect__updown_5_32:
  deref_and_jump(x1,remove__redandant__indirect__updown_5_29);
  *reasonp++ =  x1;
  goto remove__redandant__indirect__updown_5_33;
 case VARREF:
  deref_and_jump(x0,remove__redandant__indirect__updown_5_28);
  *reasonp++ =  x0;
  goto remove__redandant__indirect__updown_5_33;
  };
  goto remove__redandant__indirect__updown_5_33;
 case VARREF:
  deref_and_jump(a2,remove__redandant__indirect__updown_5_27);
  *reasonp++ =  a2;
  goto remove__redandant__indirect__updown_5_33;
  };
  goto remove__redandant__indirect__updown_5_33;
 remove__redandant__indirect__updown_5_33:
  otherwise(remove__redandant__indirect__updown_5_interrupt);
 remove__redandant__indirect__updown_5_34:
  switch (ptagof(a2)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = car_of(a2);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a3, x0);
  a2 = cdr_of(a2);
  a3 = x1;
  execute(remove__redandant__indirect__updown_5_0);
  goto remove__redandant__indirect__updown_5_ext_interrupt;
 case ATOMIC:
  if (a2 != NILATOM) goto remove__redandant__indirect__updown_5_interrupt;
  unify_value(a3, NILATOM);
  unify_value(a4, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a2,remove__redandant__indirect__updown_5_34);
  *reasonp++ =  a2;
  goto remove__redandant__indirect__updown_5_interrupt;
  };
  goto remove__redandant__indirect__updown_5_interrupt;
 remove__redandant__indirect__updown_5_ext_interrupt:
  reasonp = 0l;
 remove__redandant__indirect__updown_5_interrupt:
  toppred = &predicate_analyze__type_xremove__redandant__indirect__updown_5;
  goto interrupt_5;
 }

 remove__redandant__indirect__unify_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 remove__redandant__indirect__unify_3_clear_reason:
  reasonp = reasons;
 remove__redandant__indirect__unify_3_0:
 remove__redandant__indirect__unify_3_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xremove__redandant__indirect__unify_3);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  a0 = car_of(a0);
  a2 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(remove__redandant__indirect__unify1_3_0);
  goto remove__redandant__indirect__unify1_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto remove__redandant__indirect__unify_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,remove__redandant__indirect__unify_3_1);
  *reasonp++ =  a0;
  goto remove__redandant__indirect__unify_3_interrupt;
  };
  goto remove__redandant__indirect__unify_3_interrupt;
 remove__redandant__indirect__unify_3_ext_interrupt:
  reasonp = 0l;
 remove__redandant__indirect__unify_3_interrupt:
  goto interrupt_3;
 }

 remove__redandant__indirect__unify1_3_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  qp = qp->next;
 remove__redandant__indirect__unify1_3_clear_reason:
  reasonp = reasons;
 remove__redandant__indirect__unify1_3_0:
 remove__redandant__indirect__unify1_3_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 remove__redandant__indirect__unify1_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_unify_2)) goto remove__redandant__indirect__unify1_3_12;
  x1 = arg(x0, 0);
 remove__redandant__indirect__unify1_3_3:
  if (isref(x1)) goto remove__redandant__indirect__unify1_3_6;
 remove__redandant__indirect__unify1_3_4:
  if (isref(x1)) goto remove__redandant__indirect__unify1_3_5;
  if_not_equal(x1, a0, remove__redandant__indirect__unify1_3_7);
  a1 = cdr_of(a1);
  execute(remove__redandant__indirect__unify1_3_clear_reason);
  goto remove__redandant__indirect__unify1_3_ext_interrupt;
 remove__redandant__indirect__unify1_3_5:
  deref_and_jump(x1,remove__redandant__indirect__unify1_3_4);
  *reasonp++ =  x1;
  goto remove__redandant__indirect__unify1_3_7;
 remove__redandant__indirect__unify1_3_6:
  deref_and_jump(x1,remove__redandant__indirect__unify1_3_3);
  *reasonp++ =  x1;
  goto remove__redandant__indirect__unify1_3_7;
 remove__redandant__indirect__unify1_3_7:
  x2 = arg(x0, 1);
 remove__redandant__indirect__unify1_3_8:
  if (isref(x2)) goto remove__redandant__indirect__unify1_3_11;
 remove__redandant__indirect__unify1_3_9:
  if (isref(x2)) goto remove__redandant__indirect__unify1_3_10;
  if_not_equal(x2, a0, remove__redandant__indirect__unify1_3_12);
  a1 = cdr_of(a1);
  execute(remove__redandant__indirect__unify1_3_clear_reason);
  goto remove__redandant__indirect__unify1_3_ext_interrupt;
 remove__redandant__indirect__unify1_3_10:
  deref_and_jump(x2,remove__redandant__indirect__unify1_3_9);
  *reasonp++ =  x2;
  goto remove__redandant__indirect__unify1_3_12;
 remove__redandant__indirect__unify1_3_11:
  deref_and_jump(x2,remove__redandant__indirect__unify1_3_8);
  *reasonp++ =  x2;
  goto remove__redandant__indirect__unify1_3_12;
 case VARREF:
  deref_and_jump(x0,remove__redandant__indirect__unify1_3_2);
  *reasonp++ =  x0;
  goto remove__redandant__indirect__unify1_3_12;
  };
  goto remove__redandant__indirect__unify1_3_12;
 case VARREF:
  deref_and_jump(a1,remove__redandant__indirect__unify1_3_1);
  *reasonp++ =  a1;
  goto remove__redandant__indirect__unify1_3_12;
  };
  goto remove__redandant__indirect__unify1_3_12;
 remove__redandant__indirect__unify1_3_12:
  otherwise(remove__redandant__indirect__unify1_3_interrupt);
 remove__redandant__indirect__unify1_3_13:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = car_of(a1);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  a1 = cdr_of(a1);
  a2 = x1;
  execute(remove__redandant__indirect__unify1_3_0);
  goto remove__redandant__indirect__unify1_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,remove__redandant__indirect__unify1_3_13);
  *reasonp++ =  a1;
  goto remove__redandant__indirect__unify1_3_interrupt;
  };
  goto remove__redandant__indirect__unify1_3_interrupt;
 remove__redandant__indirect__unify1_3_ext_interrupt:
  reasonp = 0l;
 remove__redandant__indirect__unify1_3_interrupt:
  toppred = &predicate_analyze__type_xremove__redandant__indirect__unify1_3;
  goto interrupt_3;
 }
 interrupt_31:
  allocp[32] = a30;
 interrupt_30:
  allocp[31] = a29;
 interrupt_29:
  allocp[30] = a28;
 interrupt_28:
  allocp[29] = a27;
 interrupt_27:
  allocp[28] = a26;
 interrupt_26:
  allocp[27] = a25;
 interrupt_25:
  allocp[26] = a24;
 interrupt_24:
  allocp[25] = a23;
 interrupt_23:
  allocp[24] = a22;
 interrupt_22:
  allocp[23] = a21;
 interrupt_21:
  allocp[22] = a20;
 interrupt_20:
  allocp[21] = a19;
 interrupt_19:
  allocp[20] = a18;
 interrupt_18:
  allocp[19] = a17;
 interrupt_17:
  allocp[18] = a16;
 interrupt_16:
  allocp[17] = a15;
 interrupt_15:
  allocp[16] = a14;
 interrupt_14:
  allocp[15] = a13;
 interrupt_13:
  allocp[14] = a12;
 interrupt_12:
  allocp[13] = a11;
 interrupt_11:
  allocp[12] = a10;
 interrupt_10:
  allocp[11] = a9;
 interrupt_9:
  allocp[10] = a8;
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_analyze__type);
}
