/* Compiled by KLIC compiler version 2.002 (Tue May 23 13:27:38 JST 1995) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_determine__type();
Const struct predicate predicate_determine__type_xmain_8 =
   { module_determine__type, 0, 8 };
extern Const struct predicate predicate_print_xdatan_1;
extern Const struct predicate predicate_type__init_xcheck__builtin__modules_6;
extern Const struct predicate predicate_loop_xdeps__loop__entry_4;
extern Const struct predicate predicate_unify__head__body_xapply__direct__value_7;
extern Const struct predicate predicate_analyze__type_xmain_12;

module module_determine__type(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  q a0, a1, a2, a3, a4, a5, a6, a7;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  switch_on_pred() {
    last_case_pred(0, main_8_top);
  }

 main_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  qp = qp->next;
 main_8_clear_reason:
  reasonp = reasons;
 main_8_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xmain_12);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a1;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a3;
  allocp[7] = NILATOM;
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = a4;
  allocp[10] = x4 = makeref(&allocp[10]);
  allocp[11] = a6;
  allocp[12] = a7;
  allocp[13] = x5 = makeref(&allocp[13]);
  allocp[14] = (q)(struct goalrec*)&allocp[0];
  allocp[15] = (q)(&predicate_print_xdatan_1);
  allocp[16] = makesym(atom__2B_2B_2B_2B_2BType_20Expantion);
  allocp[17] = (q)(struct goalrec*)&allocp[14];
  allocp[18] = (q)(&predicate_unify__head__body_xapply__direct__value_7);
  allocp[19] = a4;
  allocp[20] = x6 = makeref(&allocp[20]);
  allocp[21] = x2;
  allocp[22] = x7 = makeref(&allocp[22]);
  allocp[23] = x0;
  allocp[24] = x8 = makeref(&allocp[24]);
  allocp[25] = x1;
  allocp[26] = (q)(struct goalrec*)&allocp[17];
  allocp[27] = (q)(&predicate_print_xdatan_1);
  allocp[28] = makesym(atom__2B_2B_2B_2B_2BApply_20Direct_20Value_20of_20User_2DDefined_20Body_20Goals);
  allocp[29] = (q)(struct goalrec*)&allocp[26];
  allocp[30] = (q)(&predicate_loop_xdeps__loop__entry_4);
  allocp[31] = x8;
  allocp[32] = a7;
  allocp[33] = a5;
  allocp[34] = x4;
  allocp[35] = (q)(struct goalrec*)&allocp[29];
  allocp[36] = (q)(&predicate_type__init_xcheck__builtin__modules_6);
  allocp[37] = a0;
  allocp[38] = x8;
  allocp[39] = a2;
  allocp[40] = x6;
  allocp[41] = NILATOM;
  allocp[42] = x7;
  allocp[43] = (q)(struct goalrec*)&allocp[35];
  allocp[44] = (q)(&predicate_print_xdatan_1);
  allocp[45] = makesym(atom__2B_2B_2B_2B_2BFirst_20Check_20of_20Builtin);
  qp = (struct goalrec*)&allocp[43];
  allocp += 46;
  proceed();
 main_8_ext_interrupt:
  reasonp = 0l;
 main_8_interrupt:
  goto interrupt_8;
 }
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_determine__type);
}
