/* Compiled by KLIC compiler version 2.002 (1997ǯ05��10�� (��) 19��58ʬ16�� JST) */
#include <klic/klichdr.h>
#include <klic/sched.h>
#include "atom.h"
#include "funct.h"

module module_klic__reader();
Const struct predicate predicate_klic__reader_xparse__one__term__reporting__errors_4 =
   { module_klic__reader, 0, 4 };
Const struct predicate predicate_klic__reader_xparse__one__term__reporting__errors_2F4_240_8 =
   { module_klic__reader, 1, 8 };
Const struct predicate predicate_klic__reader_xwparse__one__term__reporting__errors_4 =
   { module_klic__reader, 2, 4 };
Const struct predicate predicate_klic__reader_xwparse__one__term__reporting__errors_2F4_240_8 =
   { module_klic__reader, 3, 8 };
Const struct predicate predicate_klic__reader_xreport__syntax__error_7 =
   { module_klic__reader, 4, 7 };
Const struct predicate predicate_klic__reader_xreport__syntax__error_2F7_240_2 =
   { module_klic__reader, 5, 2 };
Const struct predicate predicate_klic__reader_xwrite__tokens_4 =
   { module_klic__reader, 6, 4 };
Const struct predicate predicate_klic__reader_xwrite__one__token_3 =
   { module_klic__reader, 7, 3 };
Const struct predicate predicate_klic__reader_xblank_2 =
   { module_klic__reader, 8, 2 };
Const struct predicate predicate_klic__reader_xwrite__char_3 =
   { module_klic__reader, 9, 3 };
Const struct predicate predicate_klic__reader_xwrite__atom_3 =
   { module_klic__reader, 10, 3 };
Const struct predicate predicate_klic__reader_xwrite__string_3 =
   { module_klic__reader, 11, 3 };
Const struct predicate predicate_klic__reader_xwrite__number_3 =
   { module_klic__reader, 12, 3 };
Const struct predicate predicate_klic__reader_xwrite__decimal_3 =
   { module_klic__reader, 13, 3 };
Const struct predicate predicate_klic__reader_xlength_2 =
   { module_klic__reader, 14, 2 };
Const struct predicate predicate_klic__reader_xlength_3 =
   { module_klic__reader, 15, 3 };
Const struct predicate predicate_klic__reader_xresume__check_0 =
   { module_klic__reader, 16, 0 };
extern Const struct predicate predicate_unix_xunix_1;
extern Const struct predicate predicate_unix_xexit_1;
extern Const struct predicate predicate_integer__arithmetics_xadd_3;
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_integer__arithmetics_xmodulo_3;
extern Const struct predicate predicate_scanner_xscan_3;
extern Const struct predicate predicate_parser_xparse_3;
extern Const struct predicate predicate_parser_xwparse_3;
extern Const struct predicate predicate_atom__table_xget__atom__string_2;

module module_klic__reader(glbl, qp, allocp, toppred, stackp)
  struct global_variables *glbl;
  struct threadrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
  register q* stackp;
{
  static Const q funct_const_0[] = {
    makesym(functor_putc_1),
    makeint(10),
  };
  static Const unsigned char strconst_body_1[12] =
    {'\n','*','*',' ','h','e','r','e',' ','*','*','\n',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_1 =
      declare_string_constant_8(strconst_body_1,12);
  static Const q funct_const_2[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_1),
  };
  static Const unsigned char strconst_body_3[4] =
    {' ','*','*','\n',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_3 =
      declare_string_constant_8(strconst_body_3,4);
  static Const q funct_const_4[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_3),
  };
  static Const unsigned char strconst_body_5[4] =
    "-";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_5 =
      declare_string_constant_8(strconst_body_5,1);
  static Const q funct_const_6[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_5),
  };
  static Const unsigned char strconst_body_7[8] =
    "<float>";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_7 =
      declare_string_constant_8(strconst_body_7,7);
  static Const q funct_const_8[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_7),
  };
  static Const unsigned char strconst_body_9[24] =
    {'{','S','Y','N','T','A','X',' ','E','R','R','O','R',':',' ','i','n',' ','l','i','n','e','s',' ',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_9 =
      declare_string_constant_8(strconst_body_9,24);
  static Const q funct_const_10[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_9),
  };
  static Const unsigned char strconst_body_11[8] =
    "}\n** ";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_11 =
      declare_string_constant_8(strconst_body_11,5);
  static Const q funct_const_12[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_11),
  };
  q a0, a1, a2, a3, a4, a5, a6, a7;

  q *reasonp;
 module_top:
  switch_on_pred() {
    case_pred(0, parse__one__term__reporting__errors_4_top);
    case_pred(1, parse__one__term__reporting__errors_2F4_240_8_top);
    case_pred(2, wparse__one__term__reporting__errors_4_top);
    case_pred(3, wparse__one__term__reporting__errors_2F4_240_8_top);
    case_pred(4, report__syntax__error_7_top);
    case_pred(5, report__syntax__error_2F7_240_2_top);
    case_pred(6, write__tokens_4_top);
    case_pred(7, write__one__token_3_top);
    case_pred(8, blank_2_top);
    case_pred(9, write__char_3_top);
    case_pred(10, write__atom_3_top);
    case_pred(11, write__string_3_top);
    case_pred(12, write__number_3_top);
    case_pred(13, write__decimal_3_top);
    case_pred(14, length_2_top);
    case_pred(15, length_3_top);
    last_case_pred(16, resume__check_0_top);
  }

 parse__one__term__reporting__errors_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  stackp -= 4;
  a0 = stackp[0];
  a1 = stackp[1];
  a2 = stackp[2];
  a3 = stackp[3];
 parse__one__term__reporting__errors_4_clear_reason:
  reasonp = reasons;
 parse__one__term__reporting__errors_4_0:
 parse__one__term__reporting__errors_4_1:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_s_2)) goto parse__one__term__reporting__errors_4_interrupt;
  check_stack(17);
  allocp[0] = makesym(functor_linecount_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = x0;
  x2 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a0, x2);
  stackp[0] = allocp[0] = x4 = makeref(&allocp[0]);
  stackp[1] = a2;
  stackp[2] = a3;
  stackp[3] = allocp[1] = x5 = makeref(&allocp[1]);
  stackp[4] = x1;
  stackp[5] = allocp[2] = x6 = makeref(&allocp[2]);
  x7 = arg(a1, 1);
  stackp[6] = x7;
  x8 = arg(a1, 0);
  stackp[7] = x8;
  stackp[8] = (q)(&predicate_klic__reader_xparse__one__term__reporting__errors_2F4_240_8);
  stackp[9] = x6;
  stackp[10] = x8;
  stackp[11] = x4;
  stackp[12] = (q)(&predicate_parser_xparse_3);
  stackp[13] = x6;
  stackp[14] = x3;
  stackp[15] = x5;
  stackp[16] = (q)(&predicate_scanner_xscan_3);
  stackp += 17;
  allocp += 3;
  proceed();
 case VARREF:
  deref_and_jump_of_lvalue(a1,parse__one__term__reporting__errors_4_1);
  *reasonp++ =  a1;
  goto parse__one__term__reporting__errors_4_interrupt;
  };
  goto parse__one__term__reporting__errors_4_interrupt;
 parse__one__term__reporting__errors_4_ext_interrupt:
  reasonp = 0l;
 parse__one__term__reporting__errors_4_interrupt:
  toppred = &predicate_klic__reader_xparse__one__term__reporting__errors_4;
  goto interrupt_4;
 }

 parse__one__term__reporting__errors_2F4_240_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  stackp -= 8;
  a0 = stackp[0];
  a1 = stackp[1];
  a2 = stackp[2];
  a3 = stackp[3];
  a4 = stackp[4];
  a5 = stackp[5];
  a6 = stackp[6];
  a7 = stackp[7];
 parse__one__term__reporting__errors_2F4_240_8_clear_reason:
  reasonp = reasons;
 parse__one__term__reporting__errors_2F4_240_8_0:
 parse__one__term__reporting__errors_2F4_240_8_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_normal_1:
  x0 = arg(a0, 0);
  unify2(a1, x0, a2, a3);
  proceed();
 case functor_abnormal_2:
  check_stack(15);
  allocp[0] = makesym(functor_s_2);
  allocp[1] = a7;
  allocp[2] = a6;
  x0 = makefunctor(&allocp[0]);
  stackp[0] = allocp[3] = x1 = makeref(&allocp[3]);
  stackp[1] = x0;
  stackp[2] = a1;
  stackp[3] = a2;
  stackp[4] = (q)(&predicate_klic__reader_xparse__one__term__reporting__errors_4);
  x2 = arg(a0, 0);
  stackp[5] = x2;
  stackp[6] = a4;
  stackp[7] = allocp[4] = x3 = makeref(&allocp[4]);
  stackp[8] = a5;
  x4 = arg(a0, 1);
  stackp[9] = x4;
  stackp[10] = allocp[5] = x5 = makeref(&allocp[5]);
  stackp[11] = a6;
  stackp[12] = (q)(&predicate_klic__reader_xreport__syntax__error_7);
  allocp[6] = makesym(functor_linecount_1);
  allocp[7] = x3;
  x6 = makefunctor(&allocp[6]);
  allocp[8] = x1;
  allocp[9] = x6;
  x7 = makecons(&allocp[8]);
  allocp += 10;
  unify_value(a3, x7);
  allocp[0] = makesym(functor_normal_1);
  allocp[1] = x5;
  x8 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_stderr_1);
  allocp[3] = x8;
  x9 = makefunctor(&allocp[2]);
  allocp[4] = NILATOM;
  allocp[5] = x9;
  x10 = makecons(&allocp[4]);
  stackp[13] = x10;
  stackp[14] = (q)(&predicate_unix_xunix_1);
  stackp += 15;
  allocp += 6;
  proceed();
  };
  goto parse__one__term__reporting__errors_2F4_240_8_interrupt;
 case VARREF:
  deref_and_jump_of_lvalue(a0,parse__one__term__reporting__errors_2F4_240_8_1);
  *reasonp++ =  a0;
  goto parse__one__term__reporting__errors_2F4_240_8_interrupt;
  };
  goto parse__one__term__reporting__errors_2F4_240_8_interrupt;
 parse__one__term__reporting__errors_2F4_240_8_ext_interrupt:
  reasonp = 0l;
 parse__one__term__reporting__errors_2F4_240_8_interrupt:
  toppred = &predicate_klic__reader_xparse__one__term__reporting__errors_2F4_240_8;
  goto interrupt_8;
 }

 wparse__one__term__reporting__errors_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  stackp -= 4;
  a0 = stackp[0];
  a1 = stackp[1];
  a2 = stackp[2];
  a3 = stackp[3];
 wparse__one__term__reporting__errors_4_clear_reason:
  reasonp = reasons;
 wparse__one__term__reporting__errors_4_0:
 wparse__one__term__reporting__errors_4_1:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_s_2)) goto wparse__one__term__reporting__errors_4_interrupt;
  check_stack(17);
  allocp[0] = makesym(functor_linecount_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = x0;
  x2 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a0, x2);
  stackp[0] = allocp[0] = x4 = makeref(&allocp[0]);
  stackp[1] = a2;
  stackp[2] = a3;
  stackp[3] = allocp[1] = x5 = makeref(&allocp[1]);
  stackp[4] = x1;
  stackp[5] = allocp[2] = x6 = makeref(&allocp[2]);
  x7 = arg(a1, 1);
  stackp[6] = x7;
  x8 = arg(a1, 0);
  stackp[7] = x8;
  stackp[8] = (q)(&predicate_klic__reader_xwparse__one__term__reporting__errors_2F4_240_8);
  stackp[9] = x6;
  stackp[10] = x8;
  stackp[11] = x4;
  stackp[12] = (q)(&predicate_parser_xwparse_3);
  stackp[13] = x6;
  stackp[14] = x3;
  stackp[15] = x5;
  stackp[16] = (q)(&predicate_scanner_xscan_3);
  stackp += 17;
  allocp += 3;
  proceed();
 case VARREF:
  deref_and_jump_of_lvalue(a1,wparse__one__term__reporting__errors_4_1);
  *reasonp++ =  a1;
  goto wparse__one__term__reporting__errors_4_interrupt;
  };
  goto wparse__one__term__reporting__errors_4_interrupt;
 wparse__one__term__reporting__errors_4_ext_interrupt:
  reasonp = 0l;
 wparse__one__term__reporting__errors_4_interrupt:
  toppred = &predicate_klic__reader_xwparse__one__term__reporting__errors_4;
  goto interrupt_4;
 }

 wparse__one__term__reporting__errors_2F4_240_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  stackp -= 8;
  a0 = stackp[0];
  a1 = stackp[1];
  a2 = stackp[2];
  a3 = stackp[3];
  a4 = stackp[4];
  a5 = stackp[5];
  a6 = stackp[6];
  a7 = stackp[7];
 wparse__one__term__reporting__errors_2F4_240_8_clear_reason:
  reasonp = reasons;
 wparse__one__term__reporting__errors_2F4_240_8_0:
 wparse__one__term__reporting__errors_2F4_240_8_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_normal_1:
  allocp[0] = makesym(functor_normal_1);
  allocp[1] = arg(a0, 0);
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  unify(a2, a3);
  proceed();
 case functor_abnormal_2:
  check_stack(15);
  allocp[0] = makesym(functor_s_2);
  allocp[1] = a7;
  allocp[2] = a6;
  x0 = makefunctor(&allocp[0]);
  stackp[0] = allocp[3] = x1 = makeref(&allocp[3]);
  stackp[1] = x0;
  stackp[2] = a1;
  stackp[3] = a2;
  stackp[4] = (q)(&predicate_klic__reader_xwparse__one__term__reporting__errors_4);
  x2 = arg(a0, 0);
  stackp[5] = x2;
  stackp[6] = a4;
  stackp[7] = allocp[4] = x3 = makeref(&allocp[4]);
  stackp[8] = a5;
  x4 = arg(a0, 1);
  stackp[9] = x4;
  stackp[10] = allocp[5] = x5 = makeref(&allocp[5]);
  stackp[11] = a6;
  stackp[12] = (q)(&predicate_klic__reader_xreport__syntax__error_7);
  allocp[6] = makesym(functor_linecount_1);
  allocp[7] = x3;
  x6 = makefunctor(&allocp[6]);
  allocp[8] = x1;
  allocp[9] = x6;
  x7 = makecons(&allocp[8]);
  allocp += 10;
  unify_value(a3, x7);
  allocp[0] = makesym(functor_normal_1);
  allocp[1] = x5;
  x8 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_stderr_1);
  allocp[3] = x8;
  x9 = makefunctor(&allocp[2]);
  allocp[4] = NILATOM;
  allocp[5] = x9;
  x10 = makecons(&allocp[4]);
  stackp[13] = x10;
  stackp[14] = (q)(&predicate_unix_xunix_1);
  stackp += 15;
  allocp += 6;
  proceed();
  };
  goto wparse__one__term__reporting__errors_2F4_240_8_interrupt;
 case VARREF:
  deref_and_jump_of_lvalue(a0,wparse__one__term__reporting__errors_2F4_240_8_1);
  *reasonp++ =  a0;
  goto wparse__one__term__reporting__errors_2F4_240_8_interrupt;
  };
  goto wparse__one__term__reporting__errors_2F4_240_8_interrupt;
 wparse__one__term__reporting__errors_2F4_240_8_ext_interrupt:
  reasonp = 0l;
 wparse__one__term__reporting__errors_2F4_240_8_interrupt:
  toppred = &predicate_klic__reader_xwparse__one__term__reporting__errors_2F4_240_8;
  goto interrupt_8;
 }

 report__syntax__error_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19;
  stackp -= 7;
  a0 = stackp[0];
  a1 = stackp[1];
  a2 = stackp[2];
  a3 = stackp[3];
  a4 = stackp[4];
  a5 = stackp[5];
  a6 = stackp[6];
 report__syntax__error_7_clear_reason:
  reasonp = reasons;
 report__syntax__error_7_0:
 report__syntax__error_7_1:
  if (!isint(a6)) goto report__syntax__error_7_2;
  gblt_integer(a6,report__syntax__error_7_interrupt);
  check_stack(27);
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = makefunctor(funct_const_10);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a5, x0);
  bblt_add_no_check_y(a1,makeint(1L),x2);
  bblt_add_no_check_y(a2,makeint(1L),x3);
  stackp[0] = a6;
  stackp[1] = allocp[0] = x4 = makeref(&allocp[0]);
  stackp[2] = (q)(&predicate_klic__reader_xreport__syntax__error_2F7_240_2);
  allocp[1] = makesym(functor_fflush_1);
  allocp[2] = x4;
  x5 = makefunctor(&allocp[1]);
  allocp[3] = NILATOM;
  allocp[4] = x5;
  x6 = makecons(&allocp[3]);
  allocp[5] = x6;
  allocp[6] = makefunctor(funct_const_0);
  x7 = makecons(&allocp[5]);
  stackp[3] = allocp[7] = x8 = makeref(&allocp[7]);
  stackp[4] = a4;
  stackp[5] = allocp[8] = x9 = makeref(&allocp[8]);
  stackp[6] = x7;
  stackp[7] = (q)(&predicate_klic__reader_xwrite__tokens_4);
  allocp[9] = x9;
  allocp[10] = makefunctor(funct_const_2);
  x10 = makecons(&allocp[9]);
  stackp[8] = allocp[11] = x11 = makeref(&allocp[11]);
  stackp[9] = a3;
  stackp[10] = allocp[12] = x12 = makeref(&allocp[12]);
  stackp[11] = x10;
  stackp[12] = (q)(&predicate_klic__reader_xwrite__tokens_4);
  stackp[13] = allocp[13] = x13 = makeref(&allocp[13]);
  stackp[14] = x8;
  stackp[15] = x11;
  stackp[16] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  stackp[17] = a4;
  stackp[18] = x8;
  stackp[19] = (q)(&predicate_klic__reader_xlength_2);
  stackp[20] = a3;
  stackp[21] = x13;
  stackp[22] = (q)(&predicate_klic__reader_xlength_2);
  allocp[14] = makesym(functor_fwrite_1);
  allocp[15] = a0;
  x14 = makefunctor(&allocp[14]);
  allocp[16] = x12;
  allocp[17] = makefunctor(funct_const_4);
  x15 = makecons(&allocp[16]);
  allocp[18] = x15;
  allocp[19] = x14;
  x16 = makecons(&allocp[18]);
  allocp[20] = x16;
  allocp[21] = makefunctor(funct_const_12);
  x17 = makecons(&allocp[20]);
  stackp[23] = x3;
  stackp[24] = allocp[22] = x18 = makeref(&allocp[22]);
  stackp[25] = x17;
  stackp[26] = (q)(&predicate_klic__reader_xwrite__number_3);
  allocp[23] = x18;
  allocp[24] = makefunctor(funct_const_6);
  x19 = makecons(&allocp[23]);
  a0 = x2;
  a1 = x1;
  a2 = x19;
  stackp += 27;
  allocp += 25;
  execute(write__number_3_0);
  check_stack(4);
  goto write__number_3_ext_interrupt;
 report__syntax__error_7_2:
  if (!isref(a6)) goto report__syntax__error_7_interrupt;
  deref_and_jump_of_lvalue(a6,report__syntax__error_7_1);
  *reasonp++ =  a6;
  goto report__syntax__error_7_interrupt;
 report__syntax__error_7_ext_interrupt:
  reasonp = 0l;
 report__syntax__error_7_interrupt:
  toppred = &predicate_klic__reader_xreport__syntax__error_7;
  goto interrupt_7;
 }

 report__syntax__error_2F7_240_2_top: {
  stackp -= 2;
  a0 = stackp[0];
  a1 = stackp[1];
 report__syntax__error_2F7_240_2_clear_reason:
  reasonp = reasons;
 report__syntax__error_2F7_240_2_0:
 report__syntax__error_2F7_240_2_1:
  if (!isint(a0)) goto report__syntax__error_2F7_240_2_5;
  gblt_less(a0,makeint(0L),report__syntax__error_2F7_240_2_4);
 report__syntax__error_2F7_240_2_2:
  if (isref(a1)) goto report__syntax__error_2F7_240_2_3;
  gblt_wait(a1,report__syntax__error_2F7_240_2_4);
  check_stack(2);
  stackp[0] = a0;
  stackp[1] = (q)(&predicate_unix_xexit_1);
  stackp += 2;
  proceed();
 report__syntax__error_2F7_240_2_3:
  deref_and_jump_of_lvalue(a1,report__syntax__error_2F7_240_2_2);
  *reasonp++ =  a1;
  goto report__syntax__error_2F7_240_2_4;
 report__syntax__error_2F7_240_2_4:
  gblt_eq(a0,makeint(0L),report__syntax__error_2F7_240_2_interrupt);
  proceed();
 report__syntax__error_2F7_240_2_5:
  if (!isref(a0)) goto report__syntax__error_2F7_240_2_interrupt;
  deref_and_jump_of_lvalue(a0,report__syntax__error_2F7_240_2_1);
  *reasonp++ =  a0;
  goto report__syntax__error_2F7_240_2_interrupt;
 report__syntax__error_2F7_240_2_ext_interrupt:
  reasonp = 0l;
 report__syntax__error_2F7_240_2_interrupt:
  toppred = &predicate_klic__reader_xreport__syntax__error_2F7_240_2;
  goto interrupt_2;
 }

 write__tokens_4_top: {
  q x0, x1, x2;
  stackp -= 4;
  a0 = stackp[0];
  a1 = stackp[1];
  a2 = stackp[2];
  a3 = stackp[3];
 write__tokens_4_clear_reason:
  reasonp = reasons;
 write__tokens_4_0:
 write__tokens_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 write__tokens_4_2:
  if (a0 != makeint(0L)) goto write__tokens_4_3;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump_of_lvalue(a0,write__tokens_4_1);
  *reasonp++ =  a0;
  goto write__tokens_4_3;
  };
  goto write__tokens_4_3;
 write__tokens_4_3:
 write__tokens_4_4:
  switch (ptagof(a1)) {
 case CONS:
 write__tokens_4_5:
  if (!isint(a0)) goto write__tokens_4_6;
  gblt_greater(a0,makeint(0L),write__tokens_4_interrupt);
  check_stack(9);
  stackp[0] = allocp[0] = x0 = makeref(&allocp[0]);
  x1 = cdr_of(a1);
  stackp[1] = x1;
  stackp[2] = allocp[1] = x2 = makeref(&allocp[1]);
  stackp[3] = a3;
  stackp[4] = (q)(&predicate_klic__reader_xwrite__tokens_4);
  stackp[5] = a0;
  stackp[6] = makeint(1L);
  stackp[7] = x0;
  stackp[8] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  a0 = car_of(a1);
  a1 = a2;
  a2 = x2;
  stackp += 9;
  allocp += 2;
  execute(write__one__token_3_clear_reason);
  check_stack(4);
  goto write__one__token_3_ext_interrupt;
 write__tokens_4_6:
  if (!isref(a0)) goto write__tokens_4_interrupt;
  deref_and_jump_of_lvalue(a0,write__tokens_4_5);
  *reasonp++ =  a0;
  goto write__tokens_4_interrupt;
 case VARREF:
  deref_and_jump_of_lvalue(a1,write__tokens_4_4);
  *reasonp++ =  a1;
  goto write__tokens_4_interrupt;
  };
  goto write__tokens_4_interrupt;
 write__tokens_4_ext_interrupt:
  reasonp = 0l;
 write__tokens_4_interrupt:
  toppred = &predicate_klic__reader_xwrite__tokens_4;
  goto interrupt_4;
 }

 write__one__token_3_top: {
  q x0, x1, x2, x3;
  stackp -= 3;
  a0 = stackp[0];
  a1 = stackp[1];
  a2 = stackp[2];
 write__one__token_3_clear_reason:
  reasonp = reasons;
 write__one__token_3_0:
 write__one__token_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_eof)) goto write__one__token_3_2;
  unify(a2, a1);
  proceed();
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_variable_4:
  check_stack(3);
  stackp[0] = allocp[0] = x0 = makeref(&allocp[0]);
  stackp[1] = a2;
  stackp[2] = (q)(&predicate_klic__reader_xblank_2);
  a0 = arg(a0, 2);
  a2 = x0;
  stackp += 3;
  allocp += 1;
  execute(write__string_3_0);
  check_stack(4);
  goto write__string_3_ext_interrupt;
 case functor_number_1:
  check_stack(3);
  stackp[0] = allocp[0] = x0 = makeref(&allocp[0]);
  stackp[1] = a2;
  stackp[2] = (q)(&predicate_klic__reader_xblank_2);
  a0 = arg(a0, 0);
  a2 = x0;
  stackp += 3;
  allocp += 1;
  execute(write__number_3_0);
  check_stack(4);
  goto write__number_3_ext_interrupt;
 case functor_open_1:
  check_stack(7);
  stackp[0] = allocp[0] = x0 = makeref(&allocp[0]);
  stackp[1] = a2;
  stackp[2] = (q)(&predicate_klic__reader_xblank_2);
  stackp[3] = makeint(40L);
  stackp[4] = allocp[1] = x1 = makeref(&allocp[1]);
  stackp[5] = x0;
  stackp[6] = (q)(&predicate_klic__reader_xwrite__char_3);
  a0 = arg(a0, 0);
  a2 = x1;
  stackp += 7;
  allocp += 2;
  execute(write__atom_3_0);
  check_stack(4);
  goto write__atom_3_ext_interrupt;
 case functor_atom_1:
  check_stack(3);
  stackp[0] = allocp[0] = x0 = makeref(&allocp[0]);
  stackp[1] = a2;
  stackp[2] = (q)(&predicate_klic__reader_xblank_2);
  a0 = arg(a0, 0);
  a2 = x0;
  stackp += 3;
  allocp += 1;
  execute(write__atom_3_0);
  check_stack(4);
  goto write__atom_3_ext_interrupt;
 case functor_string_1:
  check_stack(11);
  stackp[0] = allocp[0] = x0 = makeref(&allocp[0]);
  stackp[1] = a2;
  stackp[2] = (q)(&predicate_klic__reader_xblank_2);
  stackp[3] = makeint(34L);
  stackp[4] = allocp[1] = x1 = makeref(&allocp[1]);
  stackp[5] = x0;
  stackp[6] = (q)(&predicate_klic__reader_xwrite__char_3);
  x2 = arg(a0, 0);
  stackp[7] = x2;
  stackp[8] = allocp[2] = x3 = makeref(&allocp[2]);
  stackp[9] = x1;
  stackp[10] = (q)(&predicate_klic__reader_xwrite__string_3);
  a0 = makeint(34L);
  a2 = x3;
  stackp += 11;
  allocp += 3;
  execute(write__char_3_0);
  check_stack(4);
  goto write__char_3_ext_interrupt;
 case functor_error_1:
  unify(a2, a1);
  proceed();
  };
  goto write__one__token_3_2;
 case VARREF:
  deref_and_jump_of_lvalue(a0,write__one__token_3_1);
  *reasonp++ =  a0;
  goto write__one__token_3_2;
  };
  goto write__one__token_3_2;
 write__one__token_3_2:
  otherwise(write__one__token_3_interrupt);
  check_stack(3);
  stackp[0] = allocp[0] = x0 = makeref(&allocp[0]);
  stackp[1] = a2;
  stackp[2] = (q)(&predicate_klic__reader_xblank_2);
  a2 = x0;
  stackp += 3;
  allocp += 1;
  execute(write__atom_3_0);
  check_stack(4);
  goto write__atom_3_ext_interrupt;
 write__one__token_3_ext_interrupt:
  reasonp = 0l;
 write__one__token_3_interrupt:
  toppred = &predicate_klic__reader_xwrite__one__token_3;
  goto interrupt_3;
 }

 blank_2_top: {
  q x0;
  stackp -= 2;
  a0 = stackp[0];
  a1 = stackp[1];
 blank_2_clear_reason:
  reasonp = reasons;
 blank_2_0:
  x0 = a0;
  a2 = a1;
  a1 = x0;
  a0 = makeint(32L);
  execute(write__char_3_0);
  check_stack(4);
  goto write__char_3_ext_interrupt;
 blank_2_ext_interrupt:
  reasonp = 0l;
 blank_2_interrupt:
  toppred = &predicate_klic__reader_xblank_2;
  goto interrupt_2;
 }

 write__char_3_top: {
  q x0, x1;
  stackp -= 3;
  a0 = stackp[0];
  a1 = stackp[1];
  a2 = stackp[2];
 write__char_3_clear_reason:
  reasonp = reasons;
 write__char_3_0:
  allocp[0] = makesym(functor_putc_1);
  allocp[1] = a0;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = a2;
  allocp[3] = x0;
  x1 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a1, x1);
  proceed();
 write__char_3_ext_interrupt:
  reasonp = 0l;
 write__char_3_interrupt:
  toppred = &predicate_klic__reader_xwrite__char_3;
  goto interrupt_3;
 }

 write__atom_3_top: {
  q x0, x1, x2;
  stackp -= 3;
  a0 = stackp[0];
  a1 = stackp[1];
  a2 = stackp[2];
 write__atom_3_clear_reason:
  reasonp = reasons;
 write__atom_3_0:
  check_stack(3);
  allocp[0] = makesym(functor_fwrite_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = a2;
  allocp[3] = x0;
  x2 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a1, x2);
  stackp[0] = a0;
  stackp[1] = x1;
  stackp[2] = (q)(&predicate_atom__table_xget__atom__string_2);
  stackp += 3;
  proceed();
 write__atom_3_ext_interrupt:
  reasonp = 0l;
 write__atom_3_interrupt:
  toppred = &predicate_klic__reader_xwrite__atom_3;
  goto interrupt_3;
 }

 write__string_3_top: {
  q x0, x1;
  stackp -= 3;
  a0 = stackp[0];
  a1 = stackp[1];
  a2 = stackp[2];
 write__string_3_clear_reason:
  reasonp = reasons;
 write__string_3_0:
  allocp[0] = makesym(functor_fwrite_1);
  allocp[1] = a0;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = a2;
  allocp[3] = x0;
  x1 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a1, x1);
  proceed();
 write__string_3_ext_interrupt:
  reasonp = 0l;
 write__string_3_interrupt:
  toppred = &predicate_klic__reader_xwrite__string_3;
  goto interrupt_3;
 }

 write__number_3_top: {
  q x0;
  stackp -= 3;
  a0 = stackp[0];
  a1 = stackp[1];
  a2 = stackp[2];
 write__number_3_clear_reason:
  reasonp = reasons;
 write__number_3_0:
 write__number_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (!isint(a0)) goto write__number_3_interrupt;
 write__number_3_2:
  if (a0 != makeint(0L)) goto write__number_3_3;
  a0 = makeint(48L);
  execute(write__char_3_0);
  check_stack(4);
  goto write__char_3_ext_interrupt;
 write__number_3_3:
  gblt_greater(a0,makeint(0L),write__number_3_interrupt);
  execute(write__decimal_3_0);
  check_stack(4);
  goto write__decimal_3_ext_interrupt;
 case FUNCTOR:
 write__number_3_4:
  if (!isgobj(a0)) goto write__number_3_interrupt;
 write__number_3_5:
  guard_generic(a0, functor_float_0, 0, write__number_3_interrupt);
  allocp[0] = a2;
  allocp[1] = makefunctor(funct_const_8);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump_of_lvalue(a0,write__number_3_1);
  *reasonp++ =  a0;
  goto write__number_3_interrupt;
  };
  goto write__number_3_interrupt;
 write__number_3_ext_interrupt:
  reasonp = 0l;
 write__number_3_interrupt:
  toppred = &predicate_klic__reader_xwrite__number_3;
  goto interrupt_3;
 }

 write__decimal_3_top: {
  q x0, x1, x2, x3;
  stackp -= 3;
  a0 = stackp[0];
  a1 = stackp[1];
  a2 = stackp[2];
 write__decimal_3_clear_reason:
  reasonp = reasons;
 write__decimal_3_0:
 write__decimal_3_1:
  if (!isint(a0)) goto write__decimal_3_3;
  gblt_greater(a0,makeint(0L),write__decimal_3_2);
  check_stack(12);
  bblt_div_no_check(a0,makeint(10L),x0);
  stackp[0] = allocp[0] = x1 = makeref(&allocp[0]);
  stackp[1] = allocp[1] = x2 = makeref(&allocp[1]);
  stackp[2] = a2;
  stackp[3] = (q)(&predicate_klic__reader_xwrite__char_3);
  stackp[4] = allocp[2] = x3 = makeref(&allocp[2]);
  stackp[5] = makeint(48L);
  stackp[6] = x1;
  stackp[7] = (q)(&predicate_integer__arithmetics_xadd_3);
  stackp[8] = a0;
  stackp[9] = makeint(10L);
  stackp[10] = x3;
  stackp[11] = (q)(&predicate_integer__arithmetics_xmodulo_3);
  a0 = x0;
  a2 = x2;
  stackp += 12;
  allocp += 3;
  execute(write__decimal_3_0);
  check_stack(4);
  goto write__decimal_3_ext_interrupt;
 write__decimal_3_2:
  if (a0 != makeint(0L)) goto write__decimal_3_interrupt;
  unify(a2, a1);
  proceed();
 write__decimal_3_3:
  if (!isref(a0)) goto write__decimal_3_interrupt;
  deref_and_jump_of_lvalue(a0,write__decimal_3_1);
  *reasonp++ =  a0;
  goto write__decimal_3_interrupt;
 write__decimal_3_ext_interrupt:
  reasonp = 0l;
 write__decimal_3_interrupt:
  toppred = &predicate_klic__reader_xwrite__decimal_3;
  goto interrupt_3;
 }

 length_2_top: {
  stackp -= 2;
  a0 = stackp[0];
  a1 = stackp[1];
 length_2_clear_reason:
  reasonp = reasons;
 length_2_0:
  a2 = a1;
  a1 = makeint(0L);
  execute(length_3_0);
  check_stack(4);
  goto length_3_ext_interrupt;
 length_2_ext_interrupt:
  reasonp = 0l;
 length_2_interrupt:
  toppred = &predicate_klic__reader_xlength_2;
  goto interrupt_2;
 }

 length_3_top: {
  q x0;
  stackp -= 3;
  a0 = stackp[0];
  a1 = stackp[1];
  a2 = stackp[2];
 length_3_clear_reason:
  reasonp = reasons;
 length_3_0:
 length_3_1:
  switch (ptagof(a0)) {
 case CONS:
  bblt_add_no_check_y(a1,makeint(1L),x0);
  a0 = cdr_of(a0);
  a1 = x0;
  execute(length_3_0);
  check_stack(4);
  goto length_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto length_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump_of_lvalue(a0,length_3_1);
  *reasonp++ =  a0;
  goto length_3_interrupt;
  };
  goto length_3_interrupt;
 length_3_ext_interrupt:
  reasonp = 0l;
 length_3_interrupt:
  toppred = &predicate_klic__reader_xlength_3;
  goto interrupt_3;
 }

 resume__check_0_top: {
		resume_check();
  }
 interrupt_8:
 stackp[7] = a7;
 interrupt_7:
 stackp[6] = a6;
 interrupt_6:
 stackp[5] = a5;
 interrupt_5:
 stackp[4] = a4;
 interrupt_4:
 stackp[3] = a3;
 interrupt_3:
 stackp[2] = a2;
 interrupt_2:
 stackp[1] = a1;
 interrupt_1:
 stackp[0] = a0;
  interrupt_0:
  interrupt_check();
  loop_within_module(module_klic__reader);
}
