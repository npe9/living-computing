/* Compiled by KLIC compiler version 2.002 (Tue May 23 13:27:38 JST 1995) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_parse__uty();
Const struct predicate predicate_parse__uty_xdecode__goal_3 =
   { module_parse__uty, 0, 3 };
Const struct predicate predicate_parse__uty_xdecode__goalcall_5 =
   { module_parse__uty, 1, 5 };
Const struct predicate predicate_parse__uty_xdecode__goalcall_6 =
   { module_parse__uty, 2, 6 };
Const struct predicate predicate_parse__uty_xdecode__goalcall1_3 =
   { module_parse__uty, 3, 3 };
Const struct predicate predicate_parse__uty_xdecode__goal_4 =
   { module_parse__uty, 4, 4 };
Const struct predicate predicate_parse__uty_xdecode__goal1_5 =
   { module_parse__uty, 5, 5 };
Const struct predicate predicate_parse__uty_xencode__goal_3 =
   { module_parse__uty, 6, 3 };
Const struct predicate predicate_parse__uty_xencode__goal_4 =
   { module_parse__uty, 7, 4 };
Const struct predicate predicate_parse__uty_xencode__goal__pragma_4 =
   { module_parse__uty, 8, 4 };
Const struct predicate predicate_parse__uty_xencode__goal__modulename_4 =
   { module_parse__uty, 9, 4 };
Const struct predicate predicate_parse__uty_xget__var__from__struct_2 =
   { module_parse__uty, 10, 2 };
Const struct predicate predicate_parse__uty_xget__var__from__struct_3 =
   { module_parse__uty, 11, 3 };
Const struct predicate predicate_parse__uty_xget__var__from__struct__functor_4 =
   { module_parse__uty, 12, 4 };
Const struct predicate predicate_parse__uty_xget__goal_6 =
   { module_parse__uty, 13, 6 };
Const struct predicate predicate_parse__uty_xupdate__clause_5 =
   { module_parse__uty, 14, 5 };
Const struct predicate predicate_parse__uty_xupdate__goal_7 =
   { module_parse__uty, 15, 7 };
Const struct predicate predicate_parse__uty_xget__def__clauses_5 =
   { module_parse__uty, 16, 5 };
Const struct predicate predicate_parse__uty_xget__def__clauses1_6 =
   { module_parse__uty, 17, 6 };
Const struct predicate predicate_parse__uty_xupdate__def__clauses_4 =
   { module_parse__uty, 18, 4 };
Const struct predicate predicate_parse__uty_xupdate__def__clauses1_3 =
   { module_parse__uty, 19, 3 };
Const struct predicate predicate_parse__uty_xget__clauses_3 =
   { module_parse__uty, 20, 3 };
Const struct predicate predicate_parse__uty_xget__clause_4 =
   { module_parse__uty, 21, 4 };
Const struct predicate predicate_parse__uty_xget__next__clause_6 =
   { module_parse__uty, 22, 6 };
Const struct predicate predicate_parse__uty_xget__next__clause1_8 =
   { module_parse__uty, 23, 8 };
Const struct predicate predicate_parse__uty_xinit__cfrags_2 =
   { module_parse__uty, 24, 2 };
Const struct predicate predicate_parse__uty_xinit__cfrags1_2 =
   { module_parse__uty, 25, 2 };
Const struct predicate predicate_parse__uty_xset__cfrag_5 =
   { module_parse__uty, 26, 5 };
Const struct predicate predicate_parse__uty_xread__cfrag_4 =
   { module_parse__uty, 27, 4 };
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_functor__table_xfunctor_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_xnew__functor_3;
extern Const struct predicate predicate_functor__table_xsetarg_4;

module module_parse__uty(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  static Const q funct_const_0[] = {
    makesym(functor_options_2),
    makesym(atom___),
    makesym(atom___),
  };
  q a0, a1, a2, a3, a4, a5, a6, a7;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, decode__goal_3_top);
    case_pred(1, decode__goalcall_5_top);
    case_pred(2, decode__goalcall_6_top);
    case_pred(3, decode__goalcall1_3_top);
    case_pred(4, decode__goal_4_top);
    case_pred(5, decode__goal1_5_top);
    case_pred(6, encode__goal_3_top);
    case_pred(7, encode__goal_4_top);
    case_pred(8, encode__goal__pragma_4_top);
    case_pred(9, encode__goal__modulename_4_top);
    case_pred(10, get__var__from__struct_2_top);
    case_pred(11, get__var__from__struct_3_top);
    case_pred(12, get__var__from__struct__functor_4_top);
    case_pred(13, get__goal_6_top);
    case_pred(14, update__clause_5_top);
    case_pred(15, update__goal_7_top);
    case_pred(16, get__def__clauses_5_top);
    case_pred(17, get__def__clauses1_6_top);
    case_pred(18, update__def__clauses_4_top);
    case_pred(19, update__def__clauses1_3_top);
    case_pred(20, get__clauses_3_top);
    case_pred(21, get__clause_4_top);
    case_pred(22, get__next__clause_6_top);
    case_pred(23, get__next__clause1_8_top);
    case_pred(24, init__cfrags_2_top);
    case_pred(25, init__cfrags1_2_top);
    case_pred(26, set__cfrag_5_top);
    last_case_pred(27, read__cfrag_4_top);
  }

 decode__goal_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 decode__goal_3_clear_reason:
  reasonp = reasons;
 decode__goal_3_0:
  allocp[0] = x1 = makeref(&allocp[0]);
  x0 = x1;
  a3 = a2;
  a2 = x0;
  allocp += 1;
  execute(decode__goal_4_0);
  goto decode__goal_4_ext_interrupt;
 decode__goal_3_ext_interrupt:
  reasonp = 0l;
 decode__goal_3_interrupt:
  toppred = &predicate_parse__uty_xdecode__goal_3;
  goto interrupt_3;
 }

 decode__goalcall_5_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 decode__goalcall_5_clear_reason:
  reasonp = reasons;
 decode__goalcall_5_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_parse__uty_xdecode__goalcall1_3);
  allocp[2] = a0;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a1;
  allocp[5] = makesym(functor_options_2);
  allocp[6] = x0;
  allocp[7] = a4;
  x1 = makefunctor(&allocp[5]);
  a0 = a2;
  a1 = a3;
  a2 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  execute(decode__goal_3_0);
  goto decode__goal_3_ext_interrupt;
 decode__goalcall_5_ext_interrupt:
  reasonp = 0l;
 decode__goalcall_5_interrupt:
  goto interrupt_5;
 }

 decode__goalcall_6_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 decode__goalcall_6_clear_reason:
  reasonp = reasons;
 decode__goalcall_6_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_parse__uty_xdecode__goalcall1_3);
  allocp[2] = a0;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a1;
  allocp[5] = makesym(functor_options_2);
  allocp[6] = x0;
  allocp[7] = a4;
  x1 = makefunctor(&allocp[5]);
  a0 = a2;
  a1 = a3;
  a2 = a5;
  a3 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  execute(decode__goal_4_0);
  goto decode__goal_4_ext_interrupt;
 decode__goalcall_6_ext_interrupt:
  reasonp = 0l;
 decode__goalcall_6_interrupt:
  goto interrupt_6;
 }

 decode__goalcall1_3_top: {
  a2 = qp->args[2];
  qp = qp->next;
 decode__goalcall1_3_clear_reason:
  reasonp = reasons;
 decode__goalcall1_3_0:
 decode__goalcall1_3_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom___)) goto decode__goalcall1_3_2;
  unify(a2, a0);
  proceed();
 case VARREF:
  deref_and_jump(a1,decode__goalcall1_3_1);
  *reasonp++ =  a1;
  goto decode__goalcall1_3_2;
  };
  goto decode__goalcall1_3_2;
 decode__goalcall1_3_2:
  otherwise(decode__goalcall1_3_interrupt);
  unify(a2, a1);
  proceed();
 decode__goalcall1_3_ext_interrupt:
  reasonp = 0l;
 decode__goalcall1_3_interrupt:
  goto interrupt_3;
 }

 decode__goal_4_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 decode__goal_4_clear_reason:
  reasonp = reasons;
 decode__goal_4_0:
  x0 = makefunctor(funct_const_0);
  a4 = a3;
  a3 = x0;
  execute(decode__goal1_5_0);
  goto decode__goal1_5_ext_interrupt;
 decode__goal_4_ext_interrupt:
  reasonp = 0l;
 decode__goal_4_interrupt:
  toppred = &predicate_parse__uty_xdecode__goal_4;
  goto interrupt_4;
 }

 decode__goal1_5_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 decode__goal1_5_clear_reason:
  reasonp = reasons;
 decode__goal1_5_0:
 decode__goal1_5_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_functor_1)) goto decode__goal1_5_6;
  x0 = arg(a0, 0);
 decode__goal1_5_2:
  if (isref(x0)) goto decode__goal1_5_5;
  gblt_pfunctor(x0,x1,decode__goal1_5_6);
  if (isint(x1)) goto decode__goal1_5_6;
  switch (symval(x1)) {
 case symval(makesym(atom__40)):
  gblt_arity(x0,x2,decode__goal1_5_6);
 decode__goal1_5_3:
  if (x2 != makeint(2L)) goto decode__goal1_5_6;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_parse__uty_xdecode__goal1_5);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x4 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[9] = makeint(2L);
  allocp[10] = a3;
  allocp[11] = x5 = makeref(&allocp[11]);
  allocp[12] = x4;
  allocp[13] = (q)(struct goalrec*)&allocp[7];
  allocp[14] = (q)(&predicate_functor__table_xarg_3);
  allocp[15] = makeint(2L);
  allocp[16] = x0;
  allocp[17] = x5;
  allocp[18] = (q)(struct goalrec*)&allocp[13];
  allocp[19] = (q)(&predicate_functor__table_xarg_3);
  allocp[20] = makeint(1L);
  allocp[21] = x0;
  allocp[22] = x3;
  qp = (struct goalrec*)&allocp[18];
  allocp += 23;
  proceed();
 case symval(makesym(atom__3A)):
  gblt_arity(x0,x2,decode__goal1_5_6);
 decode__goal1_5_4:
  if (x2 != makeint(2L)) goto decode__goal1_5_6;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_parse__uty_xdecode__goal1_5);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x4 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[9] = makeint(1L);
  allocp[10] = a3;
  allocp[11] = x5 = makeref(&allocp[11]);
  allocp[12] = x4;
  allocp[13] = (q)(struct goalrec*)&allocp[7];
  allocp[14] = (q)(&predicate_functor__table_xarg_3);
  allocp[15] = makeint(2L);
  allocp[16] = x0;
  allocp[17] = x3;
  allocp[18] = makesym(functor_atom_1);
  allocp[19] = x5;
  x6 = makefunctor(&allocp[18]);
  allocp[20] = (q)(struct goalrec*)&allocp[13];
  allocp[21] = (q)(&predicate_functor__table_xarg_3);
  allocp[22] = makeint(1L);
  allocp[23] = x0;
  allocp[24] = x6;
  qp = (struct goalrec*)&allocp[20];
  allocp += 25;
  proceed();
  };
  goto decode__goal1_5_6;
 decode__goal1_5_5:
  deref_and_jump(x0,decode__goal1_5_2);
  *reasonp++ =  x0;
  goto decode__goal1_5_6;
 case VARREF:
  deref_and_jump(a0,decode__goal1_5_1);
  *reasonp++ =  a0;
  goto decode__goal1_5_6;
  };
  goto decode__goal1_5_6;
 decode__goal1_5_6:
  otherwise(decode__goal1_5_interrupt);
 decode__goal1_5_7:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_functor_1:
  x0 = arg(a0, 0);
  unify(a1, x0);
  unify_value(a2, makesym(atom_dummy));
  unify(a4, a3);
  proceed();
 case functor_atom_1:
  x0 = arg(a0, 0);
  unify(a1, x0);
  unify_value(a2, makesym(atom_dummy));
  unify(a4, a3);
  proceed();
 case functor_functor_3:
  x0 = arg(a0, 0);
  unify(a1, x0);
  allocp[0] = makesym(functor_attrs_2);
  allocp[1] = arg(a0, 1);
  allocp[2] = arg(a0, 2);
  x1 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a2, x1);
  unify(a4, a3);
  proceed();
  };
  goto decode__goal1_5_interrupt;
 case VARREF:
  deref_and_jump(a0,decode__goal1_5_7);
  *reasonp++ =  a0;
  goto decode__goal1_5_interrupt;
  };
  goto decode__goal1_5_interrupt;
 decode__goal1_5_ext_interrupt:
  reasonp = 0l;
 decode__goal1_5_interrupt:
  toppred = &predicate_parse__uty_xdecode__goal1_5;
  goto interrupt_5;
 }

 encode__goal_3_top: {
  q x0;
  a2 = qp->args[2];
  qp = qp->next;
 encode__goal_3_clear_reason:
  reasonp = reasons;
 encode__goal_3_0:
  x0 = a1;
  a3 = a2;
  a2 = x0;
  a1 = makesym(atom___);
  execute(encode__goal__pragma_4_0);
  goto encode__goal__pragma_4_ext_interrupt;
 encode__goal_3_ext_interrupt:
  reasonp = 0l;
 encode__goal_3_interrupt:
  goto interrupt_3;
 }

 encode__goal_4_top: {
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 encode__goal_4_clear_reason:
  reasonp = reasons;
 encode__goal_4_0:
  execute(encode__goal__pragma_4_0);
  goto encode__goal__pragma_4_ext_interrupt;
 encode__goal_4_ext_interrupt:
  reasonp = 0l;
 encode__goal_4_interrupt:
  goto interrupt_4;
 }

 encode__goal__pragma_4_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 encode__goal__pragma_4_clear_reason:
  reasonp = reasons;
 encode__goal__pragma_4_0:
 encode__goal__pragma_4_1:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_options_2)) goto encode__goal__pragma_4_3;
  x0 = arg(a2, 1);
 encode__goal__pragma_4_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom___)) goto encode__goal__pragma_4_3;
  execute(encode__goal__modulename_4_0);
  goto encode__goal__modulename_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,encode__goal__pragma_4_2);
  *reasonp++ =  x0;
  goto encode__goal__pragma_4_3;
  };
  goto encode__goal__pragma_4_3;
 case VARREF:
  deref_and_jump(a2,encode__goal__pragma_4_1);
  *reasonp++ =  a2;
  goto encode__goal__pragma_4_3;
  };
  goto encode__goal__pragma_4_3;
 encode__goal__pragma_4_3:
  otherwise(encode__goal__pragma_4_interrupt);
  allocp[0] = makesym(functor_options_2);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  x0 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a2, x0);
  allocp[0] = makesym(functor__40_2);
  allocp[1] = x4 = makeref(&allocp[1]);
  allocp[2] = x2;
  x3 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_functor_1);
  allocp[4] = x3;
  x5 = makefunctor(&allocp[3]);
  allocp += 5;
  unify_value(a3, x5);
  a3 = x4;
  execute(encode__goal__modulename_4_0);
  goto encode__goal__modulename_4_ext_interrupt;
 encode__goal__pragma_4_ext_interrupt:
  reasonp = 0l;
 encode__goal__pragma_4_interrupt:
  toppred = &predicate_parse__uty_xencode__goal__pragma_4;
  goto interrupt_4;
 }

 encode__goal__modulename_4_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 encode__goal__modulename_4_clear_reason:
  reasonp = reasons;
 encode__goal__modulename_4_0:
 encode__goal__modulename_4_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom___)) goto encode__goal__modulename_4_4;
 encode__goal__modulename_4_2:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_options_2)) goto encode__goal__modulename_4_4;
  x0 = arg(a2, 0);
 encode__goal__modulename_4_3:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom___)) goto encode__goal__modulename_4_4;
  allocp[0] = makesym(functor_functor_1);
  allocp[1] = a0;
  x1 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a3, x1);
  proceed();
 case VARREF:
  deref_and_jump(x0,encode__goal__modulename_4_3);
  *reasonp++ =  x0;
  goto encode__goal__modulename_4_4;
  };
  goto encode__goal__modulename_4_4;
 case VARREF:
  deref_and_jump(a2,encode__goal__modulename_4_2);
  *reasonp++ =  a2;
  goto encode__goal__modulename_4_4;
  };
  goto encode__goal__modulename_4_4;
 case VARREF:
  deref_and_jump(a1,encode__goal__modulename_4_1);
  *reasonp++ =  a1;
  goto encode__goal__modulename_4_4;
  };
  goto encode__goal__modulename_4_4;
 encode__goal__modulename_4_4:
  otherwise(encode__goal__modulename_4_interrupt);
 encode__goal__modulename_4_5:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom___)) goto encode__goal__modulename_4_7;
 encode__goal__modulename_4_6:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_options_2)) goto encode__goal__modulename_4_7;
  allocp[0] = makesym(functor_atom_1);
  allocp[1] = arg(a2, 0);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_functor_1);
  allocp[3] = a0;
  x1 = makefunctor(&allocp[2]);
  allocp[4] = makesym(functor__3A_2);
  allocp[5] = x0;
  allocp[6] = x1;
  x2 = makefunctor(&allocp[4]);
  allocp[7] = makesym(functor_functor_1);
  allocp[8] = x2;
  x3 = makefunctor(&allocp[7]);
  allocp += 9;
  unify_value(a3, x3);
  proceed();
 case VARREF:
  deref_and_jump(a2,encode__goal__modulename_4_6);
  *reasonp++ =  a2;
  goto encode__goal__modulename_4_7;
  };
  goto encode__goal__modulename_4_7;
 case VARREF:
  deref_and_jump(a1,encode__goal__modulename_4_5);
  *reasonp++ =  a1;
  goto encode__goal__modulename_4_7;
  };
  goto encode__goal__modulename_4_7;
 encode__goal__modulename_4_7:
  otherwise(encode__goal__modulename_4_interrupt);
 encode__goal__modulename_4_8:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_options_2)) goto encode__goal__modulename_4_10;
  x0 = arg(a2, 0);
 encode__goal__modulename_4_9:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom___)) goto encode__goal__modulename_4_10;
  allocp[0] = makesym(functor_attrs_2);
  allocp[1] = x2 = makeref(&allocp[1]);
  allocp[2] = x3 = makeref(&allocp[2]);
  x1 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a1, x1);
  allocp[0] = makesym(functor_functor_3);
  allocp[1] = a0;
  allocp[2] = x2;
  allocp[3] = x3;
  x4 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a3, x4);
  proceed();
 case VARREF:
  deref_and_jump(x0,encode__goal__modulename_4_9);
  *reasonp++ =  x0;
  goto encode__goal__modulename_4_10;
  };
  goto encode__goal__modulename_4_10;
 case VARREF:
  deref_and_jump(a2,encode__goal__modulename_4_8);
  *reasonp++ =  a2;
  goto encode__goal__modulename_4_10;
  };
  goto encode__goal__modulename_4_10;
 encode__goal__modulename_4_10:
  otherwise(encode__goal__modulename_4_interrupt);
 encode__goal__modulename_4_11:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_options_2)) goto encode__goal__modulename_4_interrupt;
  allocp[0] = makesym(functor_attrs_2);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  x0 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a1, x0);
  allocp[0] = makesym(functor_atom_1);
  allocp[1] = arg(a2, 0);
  x3 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_functor_3);
  allocp[3] = a0;
  allocp[4] = x1;
  allocp[5] = x2;
  x4 = makefunctor(&allocp[2]);
  allocp[6] = makesym(functor__3A_2);
  allocp[7] = x3;
  allocp[8] = x4;
  x5 = makefunctor(&allocp[6]);
  allocp[9] = makesym(functor_functor_1);
  allocp[10] = x5;
  x6 = makefunctor(&allocp[9]);
  allocp += 11;
  unify_value(a3, x6);
  proceed();
 case VARREF:
  deref_and_jump(a2,encode__goal__modulename_4_11);
  *reasonp++ =  a2;
  goto encode__goal__modulename_4_interrupt;
  };
  goto encode__goal__modulename_4_interrupt;
 encode__goal__modulename_4_ext_interrupt:
  reasonp = 0l;
 encode__goal__modulename_4_interrupt:
  toppred = &predicate_parse__uty_xencode__goal__modulename_4;
  goto interrupt_4;
 }

 get__var__from__struct_2_top: {
  qp = qp->next;
 get__var__from__struct_2_clear_reason:
  reasonp = reasons;
 get__var__from__struct_2_0:
  a2 = a1;
  a1 = NILATOM;
  execute(get__var__from__struct_3_0);
  goto get__var__from__struct_3_ext_interrupt;
 get__var__from__struct_2_ext_interrupt:
  reasonp = 0l;
 get__var__from__struct_2_interrupt:
  goto interrupt_2;
 }

 get__var__from__struct_3_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  qp = qp->next;
 get__var__from__struct_3_clear_reason:
  reasonp = reasons;
 get__var__from__struct_3_0:
 get__var__from__struct_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 get__var__from__struct_3_2:
  gblt_atomic(a0,get__var__from__struct_3_3);
  unify(a2, a1);
  proceed();
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_variable_1)) goto get__var__from__struct_3_3;
  allocp[0] = a1;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,get__var__from__struct_3_1);
  *reasonp++ =  a0;
  goto get__var__from__struct_3_3;
  };
  goto get__var__from__struct_3_3;
 get__var__from__struct_3_3:
  otherwise(get__var__from__struct_3_interrupt);
 get__var__from__struct_3_4:
  if (isref(a0)) goto get__var__from__struct_3_5;
  gblt_pfunctor(a0,x0,get__var__from__struct_3_interrupt);
  gblt_arity(a0,x1,get__var__from__struct_3_interrupt);
  x2 = a0;
  x3 = a1;
  a3 = a2;
  a2 = x3;
  a1 = x2;
  a0 = x1;
  execute(get__var__from__struct__functor_4_0);
  goto get__var__from__struct__functor_4_ext_interrupt;
 get__var__from__struct_3_5:
  deref_and_jump(a0,get__var__from__struct_3_4);
  *reasonp++ =  a0;
  goto get__var__from__struct_3_interrupt;
 get__var__from__struct_3_ext_interrupt:
  reasonp = 0l;
 get__var__from__struct_3_interrupt:
  toppred = &predicate_parse__uty_xget__var__from__struct_3;
  goto interrupt_3;
 }

 get__var__from__struct__functor_4_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 get__var__from__struct__functor_4_clear_reason:
  reasonp = reasons;
 get__var__from__struct__functor_4_0:
 get__var__from__struct__functor_4_1:
  if (!isint(a0)) goto get__var__from__struct__functor_4_3;
  gblt_greater(a0,makeint(0L),get__var__from__struct__functor_4_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_parse__uty_xget__var__from__struct__functor_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x0;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_parse__uty_xget__var__from__struct_3);
  allocp[13] = x2 = makeref(&allocp[13]);
  allocp[14] = a2;
  allocp[15] = x1;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_functor__table_xarg_3);
  allocp[18] = a0;
  allocp[19] = a1;
  allocp[20] = x2;
  qp = (struct goalrec*)&allocp[16];
  allocp += 21;
  proceed();
 get__var__from__struct__functor_4_2:
  if (a0 != makeint(0L)) goto get__var__from__struct__functor_4_interrupt;
  unify(a3, a2);
  proceed();
 get__var__from__struct__functor_4_3:
  if (!isref(a0)) goto get__var__from__struct__functor_4_interrupt;
  deref_and_jump(a0,get__var__from__struct__functor_4_1);
  *reasonp++ =  a0;
  goto get__var__from__struct__functor_4_interrupt;
 get__var__from__struct__functor_4_ext_interrupt:
  reasonp = 0l;
 get__var__from__struct__functor_4_interrupt:
  toppred = &predicate_parse__uty_xget__var__from__struct__functor_4;
  goto interrupt_4;
 }

 get__goal_6_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 get__goal_6_clear_reason:
  reasonp = reasons;
 get__goal_6_0:
 get__goal_6_1:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (isint(a3)) goto get__goal_6_14;
  switch (symval(a3)) {
 case symval(makesym(atom_guard)):
 get__goal_6_2:
  switch (ptagof(a5)) {
 case CONS:
  x0 = car_of(a5);
 get__goal_6_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto get__goal_6_14;
  x1 = arg(x0, 0);
 get__goal_6_4:
  if (isref(x1)) goto get__goal_6_7;
 get__goal_6_5:
  if (isref(x1)) goto get__goal_6_6;
  if_not_equal(x1, a0, get__goal_6_14);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = a2;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = x2;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = a1;
  x4 = arg(x0, 1);
  allocp[13] = x4;
  allocp[14] = x3;
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 get__goal_6_6:
  deref_and_jump(x1,get__goal_6_5);
  *reasonp++ =  x1;
  goto get__goal_6_14;
 get__goal_6_7:
  deref_and_jump(x1,get__goal_6_4);
  *reasonp++ =  x1;
  goto get__goal_6_14;
 case VARREF:
  deref_and_jump(x0,get__goal_6_3);
  *reasonp++ =  x0;
  goto get__goal_6_14;
  };
  goto get__goal_6_14;
 case VARREF:
  deref_and_jump(a5,get__goal_6_2);
  *reasonp++ =  a5;
  goto get__goal_6_14;
  };
  goto get__goal_6_14;
 case symval(makesym(atom_body)):
 get__goal_6_8:
  switch (ptagof(a5)) {
 case CONS:
  x0 = car_of(a5);
 get__goal_6_9:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto get__goal_6_14;
  x1 = arg(x0, 0);
 get__goal_6_10:
  if (isref(x1)) goto get__goal_6_13;
 get__goal_6_11:
  if (isref(x1)) goto get__goal_6_12;
  if_not_equal(x1, a0, get__goal_6_14);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = a2;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(3L);
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = x2;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = a1;
  x4 = arg(x0, 1);
  allocp[13] = x4;
  allocp[14] = x3;
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 get__goal_6_12:
  deref_and_jump(x1,get__goal_6_11);
  *reasonp++ =  x1;
  goto get__goal_6_14;
 get__goal_6_13:
  deref_and_jump(x1,get__goal_6_10);
  *reasonp++ =  x1;
  goto get__goal_6_14;
 case VARREF:
  deref_and_jump(x0,get__goal_6_9);
  *reasonp++ =  x0;
  goto get__goal_6_14;
  };
  goto get__goal_6_14;
 case VARREF:
  deref_and_jump(a5,get__goal_6_8);
  *reasonp++ =  a5;
  goto get__goal_6_14;
  };
  goto get__goal_6_14;
  };
  goto get__goal_6_14;
 case VARREF:
  deref_and_jump(a3,get__goal_6_1);
  *reasonp++ =  a3;
  goto get__goal_6_14;
  };
  goto get__goal_6_14;
 get__goal_6_14:
  otherwise(get__goal_6_interrupt);
 get__goal_6_15:
  switch (ptagof(a5)) {
 case CONS:
  a5 = cdr_of(a5);
  execute(get__goal_6_0);
  goto get__goal_6_ext_interrupt;
 case VARREF:
  deref_and_jump(a5,get__goal_6_15);
  *reasonp++ =  a5;
  goto get__goal_6_16;
  };
  goto get__goal_6_16;
 get__goal_6_16:
  otherwise(get__goal_6_interrupt);
 get__goal_6_17:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (a5 != NILATOM) goto get__goal_6_interrupt;
  x0 = makesym(atom_error);
  unify(x0, makesym(atom_get__goal));
  proceed();
 case VARREF:
  deref_and_jump(a5,get__goal_6_17);
  *reasonp++ =  a5;
  goto get__goal_6_interrupt;
  };
  goto get__goal_6_interrupt;
 get__goal_6_ext_interrupt:
  reasonp = 0l;
 get__goal_6_interrupt:
  goto interrupt_6;
 }

 update__clause_5_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 update__clause_5_clear_reason:
  reasonp = reasons;
 update__clause_5_0:
 update__clause_5_1:
  switch (ptagof(a3)) {
 case CONS:
  x0 = car_of(a3);
 update__clause_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto update__clause_5_7;
  x1 = arg(x0, 0);
 update__clause_5_3:
  if (isref(x1)) goto update__clause_5_6;
 update__clause_5_4:
  if (isref(x1)) goto update__clause_5_5;
  if_not_equal(x1, a0, update__clause_5_7);
  allocp[0] = makesym(functor_module_2);
  allocp[1] = a0;
  allocp[2] = x3 = makeref(&allocp[2]);
  x2 = makefunctor(&allocp[0]);
  allocp[3] = cdr_of(a3);
  allocp[4] = x2;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a4, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = a1;
  x5 = arg(x0, 1);
  allocp[3] = x5;
  allocp[4] = a2;
  allocp[5] = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  proceed();
 update__clause_5_5:
  deref_and_jump(x1,update__clause_5_4);
  *reasonp++ =  x1;
  goto update__clause_5_7;
 update__clause_5_6:
  deref_and_jump(x1,update__clause_5_3);
  *reasonp++ =  x1;
  goto update__clause_5_7;
 case VARREF:
  deref_and_jump(x0,update__clause_5_2);
  *reasonp++ =  x0;
  goto update__clause_5_7;
  };
  goto update__clause_5_7;
 case VARREF:
  deref_and_jump(a3,update__clause_5_1);
  *reasonp++ =  a3;
  goto update__clause_5_7;
  };
  goto update__clause_5_7;
 update__clause_5_7:
  otherwise(update__clause_5_interrupt);
 update__clause_5_8:
  switch (ptagof(a3)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = car_of(a3);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a4, x0);
  a3 = cdr_of(a3);
  a4 = x1;
  execute(update__clause_5_0);
  goto update__clause_5_ext_interrupt;
 case ATOMIC:
  if (a3 != NILATOM) goto update__clause_5_interrupt;
  x0 = makesym(atom_error);
  unify(x0, makesym(atom_update__clause));
  proceed();
 case VARREF:
  deref_and_jump(a3,update__clause_5_8);
  *reasonp++ =  a3;
  goto update__clause_5_interrupt;
  };
  goto update__clause_5_interrupt;
 update__clause_5_ext_interrupt:
  reasonp = 0l;
 update__clause_5_interrupt:
  goto interrupt_5;
 }

 update__goal_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 update__goal_7_clear_reason:
  reasonp = reasons;
 update__goal_7_0:
 update__goal_7_1:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (isint(a3)) goto update__goal_7_14;
  switch (symval(a3)) {
 case symval(makesym(atom_guard)):
 update__goal_7_2:
  switch (ptagof(a5)) {
 case CONS:
  x0 = car_of(a5);
 update__goal_7_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto update__goal_7_14;
  x1 = arg(x0, 0);
 update__goal_7_4:
  if (isref(x1)) goto update__goal_7_7;
 update__goal_7_5:
  if (isref(x1)) goto update__goal_7_6;
  if_not_equal(x1, a0, update__goal_7_14);
  allocp[0] = makesym(functor_module_2);
  allocp[1] = a0;
  allocp[2] = x3 = makeref(&allocp[2]);
  x2 = makefunctor(&allocp[0]);
  allocp[3] = cdr_of(a5);
  allocp[4] = x2;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a6, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = a1;
  x5 = arg(x0, 1);
  allocp[3] = x5;
  allocp[4] = x6 = makeref(&allocp[4]);
  allocp[5] = x3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[8] = makeint(2L);
  allocp[9] = x7 = makeref(&allocp[9]);
  allocp[10] = x8 = makeref(&allocp[10]);
  allocp[11] = x6;
  allocp[12] = (q)(struct goalrec*)&allocp[6];
  allocp[13] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[14] = a2;
  allocp[15] = x9 = makeref(&allocp[15]);
  allocp[16] = a4;
  allocp[17] = x8;
  allocp[18] = (q)(struct goalrec*)&allocp[12];
  allocp[19] = (q)(&predicate_functor__table_xarg_3);
  allocp[20] = makeint(2L);
  allocp[21] = x7;
  allocp[22] = x9;
  allocp[23] = (q)(struct goalrec*)&allocp[18];
  allocp[24] = (q)(&predicate_functor__table_xarg_3);
  allocp[25] = a1;
  allocp[26] = x5;
  allocp[27] = x7;
  qp = (struct goalrec*)&allocp[23];
  allocp += 28;
  proceed();
 update__goal_7_6:
  deref_and_jump(x1,update__goal_7_5);
  *reasonp++ =  x1;
  goto update__goal_7_14;
 update__goal_7_7:
  deref_and_jump(x1,update__goal_7_4);
  *reasonp++ =  x1;
  goto update__goal_7_14;
 case VARREF:
  deref_and_jump(x0,update__goal_7_3);
  *reasonp++ =  x0;
  goto update__goal_7_14;
  };
  goto update__goal_7_14;
 case VARREF:
  deref_and_jump(a5,update__goal_7_2);
  *reasonp++ =  a5;
  goto update__goal_7_14;
  };
  goto update__goal_7_14;
 case symval(makesym(atom_body)):
 update__goal_7_8:
  switch (ptagof(a5)) {
 case CONS:
  x0 = car_of(a5);
 update__goal_7_9:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto update__goal_7_14;
  x1 = arg(x0, 0);
 update__goal_7_10:
  if (isref(x1)) goto update__goal_7_13;
 update__goal_7_11:
  if (isref(x1)) goto update__goal_7_12;
  if_not_equal(x1, a0, update__goal_7_14);
  allocp[0] = makesym(functor_module_2);
  allocp[1] = a0;
  allocp[2] = x3 = makeref(&allocp[2]);
  x2 = makefunctor(&allocp[0]);
  allocp[3] = cdr_of(a5);
  allocp[4] = x2;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a6, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = a1;
  x5 = arg(x0, 1);
  allocp[3] = x5;
  allocp[4] = x6 = makeref(&allocp[4]);
  allocp[5] = x3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[8] = makeint(3L);
  allocp[9] = x7 = makeref(&allocp[9]);
  allocp[10] = x8 = makeref(&allocp[10]);
  allocp[11] = x6;
  allocp[12] = (q)(struct goalrec*)&allocp[6];
  allocp[13] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[14] = a2;
  allocp[15] = x9 = makeref(&allocp[15]);
  allocp[16] = a4;
  allocp[17] = x8;
  allocp[18] = (q)(struct goalrec*)&allocp[12];
  allocp[19] = (q)(&predicate_functor__table_xarg_3);
  allocp[20] = makeint(3L);
  allocp[21] = x7;
  allocp[22] = x9;
  allocp[23] = (q)(struct goalrec*)&allocp[18];
  allocp[24] = (q)(&predicate_functor__table_xarg_3);
  allocp[25] = a1;
  allocp[26] = x5;
  allocp[27] = x7;
  qp = (struct goalrec*)&allocp[23];
  allocp += 28;
  proceed();
 update__goal_7_12:
  deref_and_jump(x1,update__goal_7_11);
  *reasonp++ =  x1;
  goto update__goal_7_14;
 update__goal_7_13:
  deref_and_jump(x1,update__goal_7_10);
  *reasonp++ =  x1;
  goto update__goal_7_14;
 case VARREF:
  deref_and_jump(x0,update__goal_7_9);
  *reasonp++ =  x0;
  goto update__goal_7_14;
  };
  goto update__goal_7_14;
 case VARREF:
  deref_and_jump(a5,update__goal_7_8);
  *reasonp++ =  a5;
  goto update__goal_7_14;
  };
  goto update__goal_7_14;
  };
  goto update__goal_7_14;
 case VARREF:
  deref_and_jump(a3,update__goal_7_1);
  *reasonp++ =  a3;
  goto update__goal_7_14;
  };
  goto update__goal_7_14;
 update__goal_7_14:
  otherwise(update__goal_7_interrupt);
 update__goal_7_15:
  switch (ptagof(a5)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = car_of(a5);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a6, x0);
  a5 = cdr_of(a5);
  a6 = x1;
  execute(update__goal_7_0);
  goto update__goal_7_ext_interrupt;
 case ATOMIC:
  if (a5 != NILATOM) goto update__goal_7_interrupt;
  x0 = makesym(atom_error);
  unify(x0, makesym(atom_update__clause));
  proceed();
 case VARREF:
  deref_and_jump(a5,update__goal_7_15);
  *reasonp++ =  a5;
  goto update__goal_7_interrupt;
  };
  goto update__goal_7_interrupt;
 update__goal_7_ext_interrupt:
  reasonp = 0l;
 update__goal_7_interrupt:
  goto interrupt_7;
 }

 get__def__clauses_5_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 get__def__clauses_5_clear_reason:
  reasonp = reasons;
 get__def__clauses_5_0:
 get__def__clauses_5_1:
  switch (ptagof(a4)) {
 case CONS:
  x0 = car_of(a4);
 get__def__clauses_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto get__def__clauses_5_7;
  x1 = arg(x0, 0);
 get__def__clauses_5_3:
  if (isref(x1)) goto get__def__clauses_5_6;
 get__def__clauses_5_4:
  if (isref(x1)) goto get__def__clauses_5_5;
  if_not_equal(x1, a0, get__def__clauses_5_7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_parse__uty_xget__def__clauses1_6);
  allocp[2] = makeint(1L);
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a1;
  allocp[5] = a2;
  x3 = arg(x0, 1);
  allocp[6] = x3;
  allocp[7] = a3;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[10] = x3;
  allocp[11] = x4 = makeref(&allocp[11]);
  allocp[12] = x2;
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  proceed();
 get__def__clauses_5_5:
  deref_and_jump(x1,get__def__clauses_5_4);
  *reasonp++ =  x1;
  goto get__def__clauses_5_7;
 get__def__clauses_5_6:
  deref_and_jump(x1,get__def__clauses_5_3);
  *reasonp++ =  x1;
  goto get__def__clauses_5_7;
 case VARREF:
  deref_and_jump(x0,get__def__clauses_5_2);
  *reasonp++ =  x0;
  goto get__def__clauses_5_7;
  };
  goto get__def__clauses_5_7;
 case VARREF:
  deref_and_jump(a4,get__def__clauses_5_1);
  *reasonp++ =  a4;
  goto get__def__clauses_5_7;
  };
  goto get__def__clauses_5_7;
 get__def__clauses_5_7:
  otherwise(get__def__clauses_5_interrupt);
 get__def__clauses_5_8:
  switch (ptagof(a4)) {
 case CONS:
  a4 = cdr_of(a4);
  execute(get__def__clauses_5_0);
  goto get__def__clauses_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a4,get__def__clauses_5_8);
  *reasonp++ =  a4;
  goto get__def__clauses_5_interrupt;
  };
  goto get__def__clauses_5_interrupt;
 get__def__clauses_5_ext_interrupt:
  reasonp = 0l;
 get__def__clauses_5_interrupt:
  goto interrupt_5;
 }

 get__def__clauses1_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 get__def__clauses1_6_clear_reason:
  reasonp = reasons;
 get__def__clauses1_6_0:
 get__def__clauses1_6_1:
  if (!isint(a0)) goto get__def__clauses1_6_28;
 get__def__clauses1_6_2:
  if (!isint(a1)) goto get__def__clauses1_6_27;
  gblt_less_or_eq(a0,a1,get__def__clauses1_6_29);
 get__def__clauses1_6_3:
  if (isref(a4)) goto get__def__clauses1_6_26;
  gblt_arg(a0,a4,x0,get__def__clauses1_6_29);
 get__def__clauses1_6_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_clause_6)) goto get__def__clauses1_6_29;
  x1 = arg(x0, 0);
 get__def__clauses1_6_5:
  switch (ptagof(x1)) {
 case FUNCTOR:
  switch (symval(functor_of(x1))) {
 case functor_functor_3:
  x2 = arg(x1, 0);
 get__def__clauses1_6_6:
  if (isref(x2)) goto get__def__clauses1_6_15;
  gblt_pfunctor(x2,x3,get__def__clauses1_6_29);
 get__def__clauses1_6_7:
  if (isref(x3)) goto get__def__clauses1_6_14;
 get__def__clauses1_6_8:
  if (isref(x3)) goto get__def__clauses1_6_13;
  if_not_equal(x3, a2, get__def__clauses1_6_29);
  gblt_arity(x2,x4,get__def__clauses1_6_29);
 get__def__clauses1_6_9:
  if (isref(x4)) goto get__def__clauses1_6_12;
 get__def__clauses1_6_10:
  if (isref(x4)) goto get__def__clauses1_6_11;
  if_not_equal(x4, a3, get__def__clauses1_6_29);
  allocp[0] = makesym(functor_cl_2);
  allocp[1] = a0;
  allocp[2] = x0;
  x5 = makefunctor(&allocp[0]);
  allocp[3] = x7 = makeref(&allocp[3]);
  allocp[4] = x5;
  x6 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a5, x6);
  bblt_add_no_check(a0,makeint(1L),x8);
  a0 = x8;
  a5 = x7;
  execute(get__def__clauses1_6_clear_reason);
  goto get__def__clauses1_6_ext_interrupt;
 get__def__clauses1_6_11:
  deref_and_jump(x4,get__def__clauses1_6_10);
  *reasonp++ =  x4;
  goto get__def__clauses1_6_29;
 get__def__clauses1_6_12:
  deref_and_jump(x4,get__def__clauses1_6_9);
  *reasonp++ =  x4;
  goto get__def__clauses1_6_29;
 get__def__clauses1_6_13:
  deref_and_jump(x3,get__def__clauses1_6_8);
  *reasonp++ =  x3;
  goto get__def__clauses1_6_29;
 get__def__clauses1_6_14:
  deref_and_jump(x3,get__def__clauses1_6_7);
  *reasonp++ =  x3;
  goto get__def__clauses1_6_29;
 get__def__clauses1_6_15:
  deref_and_jump(x2,get__def__clauses1_6_6);
  *reasonp++ =  x2;
  goto get__def__clauses1_6_29;
 case functor_functor_1:
  x2 = arg(x1, 0);
 get__def__clauses1_6_16:
  if (isref(x2)) goto get__def__clauses1_6_25;
  gblt_pfunctor(x2,x3,get__def__clauses1_6_29);
 get__def__clauses1_6_17:
  if (isref(x3)) goto get__def__clauses1_6_24;
 get__def__clauses1_6_18:
  if (isref(x3)) goto get__def__clauses1_6_23;
  if_not_equal(x3, a2, get__def__clauses1_6_29);
  gblt_arity(x2,x4,get__def__clauses1_6_29);
 get__def__clauses1_6_19:
  if (isref(x4)) goto get__def__clauses1_6_22;
 get__def__clauses1_6_20:
  if (isref(x4)) goto get__def__clauses1_6_21;
  if_not_equal(x4, a3, get__def__clauses1_6_29);
  allocp[0] = makesym(functor_cl_2);
  allocp[1] = a0;
  allocp[2] = x0;
  x5 = makefunctor(&allocp[0]);
  allocp[3] = x7 = makeref(&allocp[3]);
  allocp[4] = x5;
  x6 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a5, x6);
  bblt_add_no_check(a0,makeint(1L),x8);
  a0 = x8;
  a5 = x7;
  execute(get__def__clauses1_6_clear_reason);
  goto get__def__clauses1_6_ext_interrupt;
 get__def__clauses1_6_21:
  deref_and_jump(x4,get__def__clauses1_6_20);
  *reasonp++ =  x4;
  goto get__def__clauses1_6_29;
 get__def__clauses1_6_22:
  deref_and_jump(x4,get__def__clauses1_6_19);
  *reasonp++ =  x4;
  goto get__def__clauses1_6_29;
 get__def__clauses1_6_23:
  deref_and_jump(x3,get__def__clauses1_6_18);
  *reasonp++ =  x3;
  goto get__def__clauses1_6_29;
 get__def__clauses1_6_24:
  deref_and_jump(x3,get__def__clauses1_6_17);
  *reasonp++ =  x3;
  goto get__def__clauses1_6_29;
 get__def__clauses1_6_25:
  deref_and_jump(x2,get__def__clauses1_6_16);
  *reasonp++ =  x2;
  goto get__def__clauses1_6_29;
  };
  goto get__def__clauses1_6_29;
 case VARREF:
  deref_and_jump(x1,get__def__clauses1_6_5);
  *reasonp++ =  x1;
  goto get__def__clauses1_6_29;
  };
  goto get__def__clauses1_6_29;
 case VARREF:
  deref_and_jump(x0,get__def__clauses1_6_4);
  *reasonp++ =  x0;
  goto get__def__clauses1_6_29;
  };
  goto get__def__clauses1_6_29;
 get__def__clauses1_6_26:
  deref_and_jump(a4,get__def__clauses1_6_3);
  *reasonp++ =  a4;
  goto get__def__clauses1_6_29;
 get__def__clauses1_6_27:
  if (!isref(a1)) goto get__def__clauses1_6_29;
  deref_and_jump(a1,get__def__clauses1_6_2);
  *reasonp++ =  a1;
  goto get__def__clauses1_6_29;
 get__def__clauses1_6_28:
  if (!isref(a0)) goto get__def__clauses1_6_29;
  deref_and_jump(a0,get__def__clauses1_6_1);
  *reasonp++ =  a0;
  goto get__def__clauses1_6_29;
 get__def__clauses1_6_29:
  otherwise(get__def__clauses1_6_interrupt);
 get__def__clauses1_6_30:
  if (!isint(a0)) goto get__def__clauses1_6_34;
 get__def__clauses1_6_31:
  if (!isint(a1)) goto get__def__clauses1_6_33;
  gblt_less_or_eq(a0,a1,get__def__clauses1_6_32);
  bblt_add_no_check(a0,makeint(1L),x0);
  a0 = x0;
  execute(get__def__clauses1_6_0);
  goto get__def__clauses1_6_ext_interrupt;
 get__def__clauses1_6_32:
  gblt_greater(a0,a1,get__def__clauses1_6_interrupt);
  unify_value(a5, NILATOM);
  proceed();
 get__def__clauses1_6_33:
  if (!isref(a1)) goto get__def__clauses1_6_interrupt;
  deref_and_jump(a1,get__def__clauses1_6_31);
  *reasonp++ =  a1;
  goto get__def__clauses1_6_interrupt;
 get__def__clauses1_6_34:
  if (!isref(a0)) goto get__def__clauses1_6_interrupt;
  deref_and_jump(a0,get__def__clauses1_6_30);
  *reasonp++ =  a0;
  goto get__def__clauses1_6_interrupt;
 get__def__clauses1_6_ext_interrupt:
  reasonp = 0l;
 get__def__clauses1_6_interrupt:
  goto interrupt_6;
 }

 update__def__clauses_4_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 update__def__clauses_4_clear_reason:
  reasonp = reasons;
 update__def__clauses_4_0:
 update__def__clauses_4_1:
  switch (ptagof(a2)) {
 case CONS:
  x0 = car_of(a2);
 update__def__clauses_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto update__def__clauses_4_7;
  x1 = arg(x0, 0);
 update__def__clauses_4_3:
  if (isref(x1)) goto update__def__clauses_4_6;
 update__def__clauses_4_4:
  if (isref(x1)) goto update__def__clauses_4_5;
  if_not_equal(x1, a0, update__def__clauses_4_7);
  allocp[0] = makesym(functor_module_2);
  allocp[1] = a0;
  allocp[2] = x3 = makeref(&allocp[2]);
  x2 = makefunctor(&allocp[0]);
  allocp[3] = cdr_of(a2);
  allocp[4] = x2;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a3, x4);
  a0 = a1;
  a1 = arg(x0, 1);
  a2 = x3;
  execute(update__def__clauses1_3_clear_reason);
  goto update__def__clauses1_3_ext_interrupt;
 update__def__clauses_4_5:
  deref_and_jump(x1,update__def__clauses_4_4);
  *reasonp++ =  x1;
  goto update__def__clauses_4_7;
 update__def__clauses_4_6:
  deref_and_jump(x1,update__def__clauses_4_3);
  *reasonp++ =  x1;
  goto update__def__clauses_4_7;
 case VARREF:
  deref_and_jump(x0,update__def__clauses_4_2);
  *reasonp++ =  x0;
  goto update__def__clauses_4_7;
  };
  goto update__def__clauses_4_7;
 case VARREF:
  deref_and_jump(a2,update__def__clauses_4_1);
  *reasonp++ =  a2;
  goto update__def__clauses_4_7;
  };
  goto update__def__clauses_4_7;
 update__def__clauses_4_7:
  otherwise(update__def__clauses_4_interrupt);
 update__def__clauses_4_8:
  switch (ptagof(a2)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = car_of(a2);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a3, x0);
  a2 = cdr_of(a2);
  a3 = x1;
  execute(update__def__clauses_4_0);
  goto update__def__clauses_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,update__def__clauses_4_8);
  *reasonp++ =  a2;
  goto update__def__clauses_4_interrupt;
  };
  goto update__def__clauses_4_interrupt;
 update__def__clauses_4_ext_interrupt:
  reasonp = 0l;
 update__def__clauses_4_interrupt:
  goto interrupt_4;
 }

 update__def__clauses1_3_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  qp = qp->next;
 update__def__clauses1_3_clear_reason:
  reasonp = reasons;
 update__def__clauses1_3_0:
 update__def__clauses1_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 update__def__clauses1_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_cl_2)) goto update__def__clauses1_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_parse__uty_xupdate__def__clauses1_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xsetarg_4);
  x3 = arg(x0, 0);
  allocp[7] = x3;
  allocp[8] = a1;
  x4 = arg(x0, 1);
  allocp[9] = x4;
  allocp[10] = x2;
  qp = (struct goalrec*)&allocp[5];
  allocp += 11;
  proceed();
 case VARREF:
  deref_and_jump(x0,update__def__clauses1_3_2);
  *reasonp++ =  x0;
  goto update__def__clauses1_3_interrupt;
  };
  goto update__def__clauses1_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto update__def__clauses1_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,update__def__clauses1_3_1);
  *reasonp++ =  a0;
  goto update__def__clauses1_3_interrupt;
  };
  goto update__def__clauses1_3_interrupt;
 update__def__clauses1_3_ext_interrupt:
  reasonp = 0l;
 update__def__clauses1_3_interrupt:
  toppred = &predicate_parse__uty_xupdate__def__clauses1_3;
  goto interrupt_3;
 }

 get__clauses_3_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  qp = qp->next;
 get__clauses_3_clear_reason:
  reasonp = reasons;
 get__clauses_3_0:
 get__clauses_3_1:
  switch (ptagof(a2)) {
 case CONS:
  x0 = car_of(a2);
 get__clauses_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto get__clauses_3_7;
  x1 = arg(x0, 0);
 get__clauses_3_3:
  if (isref(x1)) goto get__clauses_3_6;
 get__clauses_3_4:
  if (isref(x1)) goto get__clauses_3_5;
  if_not_equal(x1, a0, get__clauses_3_7);
  x2 = arg(x0, 1);
  unify(a1, x2);
  proceed();
 get__clauses_3_5:
  deref_and_jump(x1,get__clauses_3_4);
  *reasonp++ =  x1;
  goto get__clauses_3_7;
 get__clauses_3_6:
  deref_and_jump(x1,get__clauses_3_3);
  *reasonp++ =  x1;
  goto get__clauses_3_7;
 case VARREF:
  deref_and_jump(x0,get__clauses_3_2);
  *reasonp++ =  x0;
  goto get__clauses_3_7;
  };
  goto get__clauses_3_7;
 case VARREF:
  deref_and_jump(a2,get__clauses_3_1);
  *reasonp++ =  a2;
  goto get__clauses_3_7;
  };
  goto get__clauses_3_7;
 get__clauses_3_7:
  otherwise(get__clauses_3_interrupt);
 get__clauses_3_8:
  switch (ptagof(a2)) {
 case CONS:
  allocp[0] = x0 = makeref(&allocp[0]);
  a2 = x0;
  allocp += 1;
  execute(get__clauses_3_0);
  goto get__clauses_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,get__clauses_3_8);
  *reasonp++ =  a2;
  goto get__clauses_3_interrupt;
  };
  goto get__clauses_3_interrupt;
 get__clauses_3_ext_interrupt:
  reasonp = 0l;
 get__clauses_3_interrupt:
  goto interrupt_3;
 }

 get__clause_4_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 get__clause_4_clear_reason:
  reasonp = reasons;
 get__clause_4_0:
 get__clause_4_1:
  switch (ptagof(a3)) {
 case CONS:
  x0 = car_of(a3);
 get__clause_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto get__clause_4_7;
  x1 = arg(x0, 0);
 get__clause_4_3:
  if (isref(x1)) goto get__clause_4_6;
 get__clause_4_4:
  if (isref(x1)) goto get__clause_4_5;
  if_not_equal(x1, a0, get__clause_4_7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = a1;
  x2 = arg(x0, 1);
  allocp[3] = x2;
  allocp[4] = a2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 get__clause_4_5:
  deref_and_jump(x1,get__clause_4_4);
  *reasonp++ =  x1;
  goto get__clause_4_7;
 get__clause_4_6:
  deref_and_jump(x1,get__clause_4_3);
  *reasonp++ =  x1;
  goto get__clause_4_7;
 case VARREF:
  deref_and_jump(x0,get__clause_4_2);
  *reasonp++ =  x0;
  goto get__clause_4_7;
  };
  goto get__clause_4_7;
 case VARREF:
  deref_and_jump(a3,get__clause_4_1);
  *reasonp++ =  a3;
  goto get__clause_4_7;
  };
  goto get__clause_4_7;
 get__clause_4_7:
  otherwise(get__clause_4_interrupt);
 get__clause_4_8:
  switch (ptagof(a3)) {
 case CONS:
  allocp[0] = x0 = makeref(&allocp[0]);
  a3 = x0;
  allocp += 1;
  execute(get__clause_4_0);
  goto get__clause_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a3,get__clause_4_8);
  *reasonp++ =  a3;
  goto get__clause_4_interrupt;
  };
  goto get__clause_4_interrupt;
 get__clause_4_ext_interrupt:
  reasonp = 0l;
 get__clause_4_interrupt:
  goto interrupt_4;
 }

 get__next__clause_6_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 get__next__clause_6_clear_reason:
  reasonp = reasons;
 get__next__clause_6_0:
 get__next__clause_6_1:
  switch (ptagof(a4)) {
 case CONS:
  x0 = car_of(a4);
 get__next__clause_6_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto get__next__clause_6_7;
  x1 = arg(x0, 0);
 get__next__clause_6_3:
  if (isref(x1)) goto get__next__clause_6_6;
 get__next__clause_6_4:
  if (isref(x1)) goto get__next__clause_6_5;
  if_not_equal(x1, a0, get__next__clause_6_7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_parse__uty_xget__next__clause1_8);
  allocp[2] = x2 = makeref(&allocp[2]);
  x3 = arg(x0, 1);
  allocp[3] = x3;
  allocp[4] = a0;
  allocp[5] = a1;
  allocp[6] = a2;
  allocp[7] = a3;
  allocp[8] = a5;
  x4 = cdr_of(a4);
  allocp[9] = x4;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[12] = x3;
  allocp[13] = x5 = makeref(&allocp[13]);
  allocp[14] = x2;
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 get__next__clause_6_5:
  deref_and_jump(x1,get__next__clause_6_4);
  *reasonp++ =  x1;
  goto get__next__clause_6_7;
 get__next__clause_6_6:
  deref_and_jump(x1,get__next__clause_6_3);
  *reasonp++ =  x1;
  goto get__next__clause_6_7;
 case VARREF:
  deref_and_jump(x0,get__next__clause_6_2);
  *reasonp++ =  x0;
  goto get__next__clause_6_7;
  };
  goto get__next__clause_6_7;
 case VARREF:
  deref_and_jump(a4,get__next__clause_6_1);
  *reasonp++ =  a4;
  goto get__next__clause_6_7;
  };
  goto get__next__clause_6_7;
 get__next__clause_6_7:
  otherwise(get__next__clause_6_interrupt);
 get__next__clause_6_8:
  switch (ptagof(a4)) {
 case CONS:
  a4 = cdr_of(a4);
  execute(get__next__clause_6_0);
  goto get__next__clause_6_ext_interrupt;
 case VARREF:
  deref_and_jump(a4,get__next__clause_6_8);
  *reasonp++ =  a4;
  goto get__next__clause_6_interrupt;
  };
  goto get__next__clause_6_interrupt;
 get__next__clause_6_ext_interrupt:
  reasonp = 0l;
 get__next__clause_6_interrupt:
  goto interrupt_6;
 }

 get__next__clause1_8_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 get__next__clause1_8_clear_reason:
  reasonp = reasons;
 get__next__clause1_8_0:
 get__next__clause1_8_1:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (!isint(a3)) goto get__next__clause1_8_9;
 get__next__clause1_8_2:
 get__next__clause1_8_3:
  if (!isint(a0)) goto get__next__clause1_8_8;
  gblt_less(a3,a0,get__next__clause1_8_9);
  gblt_add(a3,makeint(1L),x0,get__next__clause1_8_9);
 get__next__clause1_8_4:
  if (isref(a1)) goto get__next__clause1_8_7;
  gblt_arg(x0,a1,x1,get__next__clause1_8_9);
 get__next__clause1_8_5:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (isint(x1)) goto get__next__clause1_8_9;
 get__next__clause1_8_6:
  gblt_atom(x1,get__next__clause1_8_9);
  bblt_add_no_check(a3,makeint(1L),x2);
  a3 = x2;
  execute(get__next__clause1_8_0);
  goto get__next__clause1_8_ext_interrupt;
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_clause_6)) goto get__next__clause1_8_9;
  bblt_add_no_check(a3,makeint(1L),x2);
  unify_value(a5, x2);
  unify(a4, a2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = a5;
  allocp[3] = a1;
  allocp[4] = a6;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case VARREF:
  deref_and_jump(x1,get__next__clause1_8_5);
  *reasonp++ =  x1;
  goto get__next__clause1_8_9;
  };
  goto get__next__clause1_8_9;
 get__next__clause1_8_7:
  deref_and_jump(a1,get__next__clause1_8_4);
  *reasonp++ =  a1;
  goto get__next__clause1_8_9;
 get__next__clause1_8_8:
  if (!isref(a0)) goto get__next__clause1_8_9;
  deref_and_jump(a0,get__next__clause1_8_3);
  *reasonp++ =  a0;
  goto get__next__clause1_8_9;
 case VARREF:
  deref_and_jump(a3,get__next__clause1_8_1);
  *reasonp++ =  a3;
  goto get__next__clause1_8_interrupt;
  };
  goto get__next__clause1_8_9;
 get__next__clause1_8_9:
 get__next__clause1_8_10:
  if (isref(a3)) goto get__next__clause1_8_17;
  if_not_equal(a3, a0, get__next__clause1_8_13);
 get__next__clause1_8_11:
  switch (ptagof(a7)) {
 case CONS:
  x0 = car_of(a7);
 get__next__clause1_8_12:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto get__next__clause1_8_13;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_parse__uty_xget__next__clause1_8);
  allocp[2] = x1 = makeref(&allocp[2]);
  x2 = arg(x0, 1);
  allocp[3] = x2;
  x3 = arg(x0, 0);
  allocp[4] = x3;
  allocp[5] = makeint(0L);
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  x4 = cdr_of(a7);
  allocp[9] = x4;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[12] = x2;
  allocp[13] = x5 = makeref(&allocp[13]);
  allocp[14] = x1;
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(x0,get__next__clause1_8_12);
  *reasonp++ =  x0;
  goto get__next__clause1_8_13;
  };
  goto get__next__clause1_8_13;
 case VARREF:
  deref_and_jump(a7,get__next__clause1_8_11);
  *reasonp++ =  a7;
  goto get__next__clause1_8_13;
  };
  goto get__next__clause1_8_13;
 get__next__clause1_8_13:
 get__next__clause1_8_14:
  if (isref(a3)) goto get__next__clause1_8_16;
  if_not_equal(a3, a0, get__next__clause1_8_interrupt);
 get__next__clause1_8_15:
  switch (ptagof(a7)) {
 case ATOMIC:
  if (a7 != NILATOM) goto get__next__clause1_8_interrupt;
  unify_value(a4, makesym(atom_));
  unify_value(a5, makeint(0L));
  unify_value(a6, makesym(atom_dummy));
  proceed();
 case VARREF:
  deref_and_jump(a7,get__next__clause1_8_15);
  *reasonp++ =  a7;
  goto get__next__clause1_8_interrupt;
  };
  goto get__next__clause1_8_interrupt;
 get__next__clause1_8_16:
  deref_and_jump(a3,get__next__clause1_8_14);
  *reasonp++ =  a3;
  goto get__next__clause1_8_interrupt;
 get__next__clause1_8_17:
  deref_and_jump(a3,get__next__clause1_8_10);
  *reasonp++ =  a3;
  goto get__next__clause1_8_interrupt;
 get__next__clause1_8_ext_interrupt:
  reasonp = 0l;
 get__next__clause1_8_interrupt:
  goto interrupt_8;
 }

 init__cfrags_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  qp = qp->next;
 init__cfrags_2_clear_reason:
  reasonp = reasons;
 init__cfrags_2_0:
 init__cfrags_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 init__cfrags_2_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto init__cfrags_2_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_parse__uty_xinit__cfrags_2);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = makesym(functor_module_2);
  allocp[5] = arg(x0, 0);
  allocp[6] = x4 = makeref(&allocp[6]);
  x3 = makefunctor(&allocp[4]);
  allocp[7] = x2;
  allocp[8] = x3;
  x5 = makecons(&allocp[7]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 9;
  unify_value(a1, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_parse__uty_xinit__cfrags1_2);
  allocp[2] = x6 = makeref(&allocp[2]);
  allocp[3] = x4;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_functor__table_xfunctor_3);
  x7 = arg(x0, 1);
  allocp[6] = x7;
  allocp[7] = x8 = makeref(&allocp[7]);
  allocp[8] = x6;
  qp = (struct goalrec*)&allocp[4];
  allocp += 9;
  proceed();
 case VARREF:
  deref_and_jump(x0,init__cfrags_2_2);
  *reasonp++ =  x0;
  goto init__cfrags_2_interrupt;
  };
  goto init__cfrags_2_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto init__cfrags_2_interrupt;
  unify_value(a1, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a0,init__cfrags_2_1);
  *reasonp++ =  a0;
  goto init__cfrags_2_interrupt;
  };
  goto init__cfrags_2_interrupt;
 init__cfrags_2_ext_interrupt:
  reasonp = 0l;
 init__cfrags_2_interrupt:
  goto interrupt_2;
 }

 init__cfrags1_2_top: {
  qp = qp->next;
 init__cfrags1_2_clear_reason:
  reasonp = reasons;
 init__cfrags1_2_0:
 init__cfrags1_2_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 init__cfrags1_2_2:
  if (a0 != makeint(0L)) goto init__cfrags1_2_3;
  unify_value(a1, makesym(atom_clauses));
  proceed();
 case VARREF:
  deref_and_jump(a0,init__cfrags1_2_1);
  *reasonp++ =  a0;
  goto init__cfrags1_2_3;
  };
  goto init__cfrags1_2_3;
 init__cfrags1_2_3:
  otherwise(init__cfrags1_2_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xnew__functor_3);
  allocp[2] = a1;
  allocp[3] = makesym(atom_clauses);
  allocp[4] = a0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 init__cfrags1_2_ext_interrupt:
  reasonp = 0l;
 init__cfrags1_2_interrupt:
  goto interrupt_2;
 }

 set__cfrag_5_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 set__cfrag_5_clear_reason:
  reasonp = reasons;
 set__cfrag_5_0:
 set__cfrag_5_1:
  switch (ptagof(a3)) {
 case CONS:
  x0 = car_of(a3);
 set__cfrag_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto set__cfrag_5_7;
  x1 = arg(x0, 0);
 set__cfrag_5_3:
  if (isref(x1)) goto set__cfrag_5_6;
 set__cfrag_5_4:
  if (isref(x1)) goto set__cfrag_5_5;
  if_not_equal(x1, a0, set__cfrag_5_7);
  allocp[0] = makesym(functor_module_2);
  allocp[1] = a0;
  allocp[2] = x3 = makeref(&allocp[2]);
  x2 = makefunctor(&allocp[0]);
  allocp[3] = cdr_of(a3);
  allocp[4] = x2;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a4, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = a1;
  x5 = arg(x0, 1);
  allocp[3] = x5;
  allocp[4] = a2;
  allocp[5] = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  proceed();
 set__cfrag_5_5:
  deref_and_jump(x1,set__cfrag_5_4);
  *reasonp++ =  x1;
  goto set__cfrag_5_7;
 set__cfrag_5_6:
  deref_and_jump(x1,set__cfrag_5_3);
  *reasonp++ =  x1;
  goto set__cfrag_5_7;
 case VARREF:
  deref_and_jump(x0,set__cfrag_5_2);
  *reasonp++ =  x0;
  goto set__cfrag_5_7;
  };
  goto set__cfrag_5_7;
 case VARREF:
  deref_and_jump(a3,set__cfrag_5_1);
  *reasonp++ =  a3;
  goto set__cfrag_5_7;
  };
  goto set__cfrag_5_7;
 set__cfrag_5_7:
  otherwise(set__cfrag_5_interrupt);
 set__cfrag_5_8:
  switch (ptagof(a3)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = car_of(a3);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a4, x0);
  a3 = cdr_of(a3);
  a4 = x1;
  execute(set__cfrag_5_0);
  goto set__cfrag_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a3,set__cfrag_5_8);
  *reasonp++ =  a3;
  goto set__cfrag_5_interrupt;
  };
  goto set__cfrag_5_interrupt;
 set__cfrag_5_ext_interrupt:
  reasonp = 0l;
 set__cfrag_5_interrupt:
  goto interrupt_5;
 }

 read__cfrag_4_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 read__cfrag_4_clear_reason:
  reasonp = reasons;
 read__cfrag_4_0:
 read__cfrag_4_1:
  switch (ptagof(a3)) {
 case CONS:
  x0 = car_of(a3);
 read__cfrag_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto read__cfrag_4_7;
  x1 = arg(x0, 0);
 read__cfrag_4_3:
  if (isref(x1)) goto read__cfrag_4_6;
 read__cfrag_4_4:
  if (isref(x1)) goto read__cfrag_4_5;
  if_not_equal(x1, a0, read__cfrag_4_7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = a1;
  x2 = arg(x0, 1);
  allocp[3] = x2;
  allocp[4] = a2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 read__cfrag_4_5:
  deref_and_jump(x1,read__cfrag_4_4);
  *reasonp++ =  x1;
  goto read__cfrag_4_7;
 read__cfrag_4_6:
  deref_and_jump(x1,read__cfrag_4_3);
  *reasonp++ =  x1;
  goto read__cfrag_4_7;
 case VARREF:
  deref_and_jump(x0,read__cfrag_4_2);
  *reasonp++ =  x0;
  goto read__cfrag_4_7;
  };
  goto read__cfrag_4_7;
 case VARREF:
  deref_and_jump(a3,read__cfrag_4_1);
  *reasonp++ =  a3;
  goto read__cfrag_4_7;
  };
  goto read__cfrag_4_7;
 read__cfrag_4_7:
  otherwise(read__cfrag_4_interrupt);
 read__cfrag_4_8:
  switch (ptagof(a3)) {
 case CONS:
  a3 = cdr_of(a3);
  execute(read__cfrag_4_0);
  goto read__cfrag_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a3,read__cfrag_4_8);
  *reasonp++ =  a3;
  goto read__cfrag_4_interrupt;
  };
  goto read__cfrag_4_interrupt;
 read__cfrag_4_ext_interrupt:
  reasonp = 0l;
 read__cfrag_4_interrupt:
  goto interrupt_4;
 }
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_parse__uty);
}
