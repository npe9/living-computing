/* Compiled by KLIC compiler version 2.002 (1997ǯ05��10�� (��) 19��58ʬ16�� JST) */
#include <klic/klichdr.h>
#include <klic/sched.h>
#include "atom.h"
#include "funct.h"

module module_stack();
Const struct predicate predicate_stack_xcreate_1 =
   { module_stack, 0, 1 };
Const struct predicate predicate_stack_xmain_3 =
   { module_stack, 1, 3 };
Const struct predicate predicate_stack_xmessage_3 =
   { module_stack, 2, 3 };
Const struct predicate predicate_stack_xresume__check_0 =
   { module_stack, 3, 0 };

module module_stack(glbl, qp, allocp, toppred, stackp)
  struct global_variables *glbl;
  struct threadrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
  register q* stackp;
{
  declare_method_table_of(vector);
  static Const vector_structure_type vector_const_0 =
      declare_vector_constant(0,0);
  q a0, a1, a2;

  q *reasonp;
 module_top:
  switch_on_pred() {
    case_pred(0, create_1_top);
    case_pred(1, main_3_top);
    case_pred(2, message_3_top);
    last_case_pred(3, resume__check_0_top);
  }

 create_1_top: {
  stackp -= 1;
  a0 = stackp[0];
 create_1_clear_reason:
  reasonp = reasons;
 create_1_0:
  a1 = NILATOM;
  a2 = NILATOM;
  execute(main_3_0);
  check_stack(4);
  goto main_3_ext_interrupt;
 create_1_ext_interrupt:
  reasonp = 0l;
 create_1_interrupt:
  toppred = &predicate_stack_xcreate_1;
  goto interrupt_1;
 }

 main_3_top: {
  q x0, x1;
  stackp -= 3;
  a0 = stackp[0];
  a1 = stackp[1];
  a2 = stackp[2];
 main_3_clear_reason:
  reasonp = reasons;
 main_3_0:
 main_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 main_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_do_1)) goto main_3_4;
  allocp[0] = a1;
  allocp[1] = cdr_of(a0);
  x1 = makecons(&allocp[0]);
  a0 = arg(x0, 0);
  a1 = x1;
  allocp += 2;
  execute(main_3_0);
  check_stack(4);
  goto main_3_ext_interrupt;
 case VARREF:
  deref_and_jump_of_lvalue(x0,main_3_2);
  *reasonp++ =  x0;
  goto main_3_4;
  };
  goto main_3_4;
 case ATOMIC:
  if (a0 != NILATOM) goto main_3_4;
 main_3_3:
  switch (ptagof(a1)) {
 case CONS:
  a0 = car_of(a1);
  a1 = cdr_of(a1);
  execute(main_3_0);
  check_stack(4);
  goto main_3_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto main_3_4;
  proceed();
 case VARREF:
  deref_and_jump_of_lvalue(a1,main_3_3);
  *reasonp++ =  a1;
  goto main_3_4;
  };
  goto main_3_4;
 case VARREF:
  deref_and_jump_of_lvalue(a0,main_3_1);
  *reasonp++ =  a0;
  goto main_3_4;
  };
  goto main_3_4;
 main_3_4:
  otherwise(main_3_interrupt);
 main_3_5:
  switch (ptagof(a0)) {
 case CONS:
  check_stack(4);
  x0 = cdr_of(a0);
  stackp[0] = x0;
  stackp[1] = a1;
  stackp[2] = allocp[0] = x1 = makeref(&allocp[0]);
  stackp[3] = (q)(&predicate_stack_xmain_3);
  a0 = car_of(a0);
  a1 = a2;
  a2 = x1;
  stackp += 4;
  allocp += 1;
  execute(message_3_0);
  check_stack(4);
  goto message_3_ext_interrupt;
 case VARREF:
  deref_and_jump_of_lvalue(a0,main_3_5);
  *reasonp++ =  a0;
  goto main_3_interrupt;
  };
  goto main_3_interrupt;
 main_3_ext_interrupt:
  reasonp = 0l;
 main_3_interrupt:
  toppred = &predicate_stack_xmain_3;
  goto interrupt_3;
 }

 message_3_top: {
  q x0, x1, x2;
  stackp -= 3;
  a0 = stackp[0];
  a1 = stackp[1];
  a2 = stackp[2];
 message_3_clear_reason:
  reasonp = reasons;
 message_3_0:
 message_3_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_empty_1:
 message_3_2:
  switch (ptagof(a1)) {
 case CONS:
  x0 = arg(a0, 0);
  unify_value(x0, makesym(atom_no));
  allocp[0] = cdr_of(a1);
  allocp[1] = car_of(a1);
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x1);
  proceed();
 case ATOMIC:
  if (a1 != NILATOM) goto message_3_interrupt;
  x0 = arg(a0, 0);
  unify_value(x0, makesym(atom_yes));
  unify_value(a2, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump_of_lvalue(a1,message_3_2);
  *reasonp++ =  a1;
  goto message_3_interrupt;
  };
  goto message_3_interrupt;
 case functor_put_1:
  allocp[0] = a1;
  allocp[1] = arg(a0, 0);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  proceed();
 case functor_get_1:
 message_3_3:
  switch (ptagof(a1)) {
 case CONS:
  x0 = arg(a0, 0);
  x1 = car_of(a1);
  unify(x0, x1);
  x2 = cdr_of(a1);
  unify(a2, x2);
  proceed();
 case VARREF:
  deref_and_jump_of_lvalue(a1,message_3_3);
  *reasonp++ =  a1;
  goto message_3_interrupt;
  };
  goto message_3_interrupt;
 case functor_get__if__any_1:
 message_3_4:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = car_of(a1);
  x0 = create_vector(&allocp[0], 1, allocp);
  x1 = arg(a0, 0);
  allocp += 1;
  unify_value(x1, x0);
  x2 = cdr_of(a1);
  unify(a2, x2);
  proceed();
 case ATOMIC:
  if (a1 != NILATOM) goto message_3_interrupt;
  x0 = arg(a0, 0);
  unify_value(x0, makefunctor(&vector_const_0));
  unify_value(a2, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump_of_lvalue(a1,message_3_4);
  *reasonp++ =  a1;
  goto message_3_interrupt;
  };
  goto message_3_interrupt;
 case functor_get__all_1:
  x0 = arg(a0, 0);
  unify(x0, a1);
  unify_value(a2, NILATOM);
  proceed();
 case functor_carbon__copy_1:
  x0 = arg(a0, 0);
  unify2(x0, a1, a2, a1);
  proceed();
  };
  goto message_3_interrupt;
 case VARREF:
  deref_and_jump_of_lvalue(a0,message_3_1);
  *reasonp++ =  a0;
  goto message_3_interrupt;
  };
  goto message_3_interrupt;
 message_3_ext_interrupt:
  reasonp = 0l;
 message_3_interrupt:
  toppred = &predicate_stack_xmessage_3;
  goto interrupt_3;
 }

 resume__check_0_top: {
		resume_check();
  }
 interrupt_3:
 stackp[2] = a2;
 interrupt_2:
 stackp[1] = a1;
 interrupt_1:
 stackp[0] = a0;
  interrupt_0:
  interrupt_check();
  loop_within_module(module_stack);
}
