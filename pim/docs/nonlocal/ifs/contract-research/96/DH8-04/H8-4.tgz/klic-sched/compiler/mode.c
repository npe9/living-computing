/* Compiled by KLIC compiler version 2.002 (Tue May 23 13:27:38 JST 1995) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_mode();
Const struct predicate predicate_mode_xset__goal__modes_6 =
   { module_mode, 0, 6 };
Const struct predicate predicate_mode_xset__goal__modes1_8 =
   { module_mode, 1, 8 };
Const struct predicate predicate_mode_xset__arg__mode_6 =
   { module_mode, 2, 6 };
Const struct predicate predicate_mode_xdec__varcount_5 =
   { module_mode, 3, 5 };
Const struct predicate predicate_mode_xdec__varcount1_5 =
   { module_mode, 4, 5 };
Const struct predicate predicate_mode_xreverse__mode_2 =
   { module_mode, 5, 2 };
Const struct predicate predicate_mode_xdetermine__goal__mode_6 =
   { module_mode, 6, 6 };
Const struct predicate predicate_mode_xdetermine__goal__mode1_8 =
   { module_mode, 7, 8 };
Const struct predicate predicate_mode_xdetermine__functor__mode_7 =
   { module_mode, 8, 7 };
Const struct predicate predicate_mode_xmake__mode_4 =
   { module_mode, 9, 4 };
Const struct predicate predicate_mode_xmake__mode1_2 =
   { module_mode, 10, 2 };
Const struct predicate predicate_mode_xget__mode_9 =
   { module_mode, 11, 9 };
Const struct predicate predicate_mode_xget__mode__clause_6 =
   { module_mode, 12, 6 };
Const struct predicate predicate_mode_xget__mode__goals_7 =
   { module_mode, 13, 7 };
Const struct predicate predicate_mode_xget__mode__goals1_8 =
   { module_mode, 14, 8 };
Const struct predicate predicate_mode_xget__mode__functor_8 =
   { module_mode, 15, 8 };
Const struct predicate predicate_mode_xget__mode__functor1_9 =
   { module_mode, 16, 9 };
Const struct predicate predicate_mode_xmode2ru_2 =
   { module_mode, 17, 2 };
Const struct predicate predicate_mode_xru2mode_2 =
   { module_mode, 18, 2 };
Const struct predicate predicate_mode_xreverse__ru_2 =
   { module_mode, 19, 2 };
extern Const struct predicate predicate_integer__arithmetics_xadd_3;
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_functor__table_xfunctor_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_xsetarg_4;

module module_mode(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  q a0, a1, a2, a3, a4, a5, a6, a7, a8;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, set__goal__modes_6_top);
    case_pred(1, set__goal__modes1_8_top);
    case_pred(2, set__arg__mode_6_top);
    case_pred(3, dec__varcount_5_top);
    case_pred(4, dec__varcount1_5_top);
    case_pred(5, reverse__mode_2_top);
    case_pred(6, determine__goal__mode_6_top);
    case_pred(7, determine__goal__mode1_8_top);
    case_pred(8, determine__functor__mode_7_top);
    case_pred(9, make__mode_4_top);
    case_pred(10, make__mode1_2_top);
    case_pred(11, get__mode_9_top);
    case_pred(12, get__mode__clause_6_top);
    case_pred(13, get__mode__goals_7_top);
    case_pred(14, get__mode__goals1_8_top);
    case_pred(15, get__mode__functor_8_top);
    case_pred(16, get__mode__functor1_9_top);
    case_pred(17, mode2ru_2_top);
    case_pred(18, ru2mode_2_top);
    last_case_pred(19, reverse__ru_2_top);
  }

 set__goal__modes_6_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 set__goal__modes_6_clear_reason:
  reasonp = reasons;
 set__goal__modes_6_0:
 set__goal__modes_6_1:
  if (isref(a2)) goto set__goal__modes_6_2;
  gblt_pfunctor(a2,x0,set__goal__modes_6_interrupt);
  gblt_arity(a2,x1,set__goal__modes_6_interrupt);
  x2 = a0;
  x3 = a1;
  x4 = a2;
  x5 = a3;
  a6 = a4;
  a7 = a5;
  a5 = x5;
  a4 = x4;
  a3 = x3;
  a2 = x2;
  a1 = x1;
  a0 = makeint(1L);
  execute(set__goal__modes1_8_0);
  goto set__goal__modes1_8_ext_interrupt;
 set__goal__modes_6_2:
  deref_and_jump(a2,set__goal__modes_6_1);
  *reasonp++ =  a2;
  goto set__goal__modes_6_interrupt;
 set__goal__modes_6_ext_interrupt:
  reasonp = 0l;
 set__goal__modes_6_interrupt:
  goto interrupt_6;
 }

 set__goal__modes1_8_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 set__goal__modes1_8_clear_reason:
  reasonp = reasons;
 set__goal__modes1_8_0:
 set__goal__modes1_8_1:
  switch (ptagof(a2)) {
 case CONS:
 set__goal__modes1_8_2:
  if (!isint(a0)) goto set__goal__modes1_8_5;
 set__goal__modes1_8_3:
  if (!isint(a1)) goto set__goal__modes1_8_4;
  gblt_less_or_eq(a0,a1,set__goal__modes1_8_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xset__goal__modes1_8);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  x1 = cdr_of(a2);
  allocp[4] = x1;
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[12] = a0;
  allocp[13] = makeint(1L);
  allocp[14] = x0;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[17] = a0;
  allocp[18] = a4;
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = x2;
  allocp[21] = (q)(struct goalrec*)&allocp[15];
  allocp[22] = (q)(&predicate_mode_xset__arg__mode_6);
  allocp[23] = x5 = makeref(&allocp[23]);
  x6 = car_of(a2);
  allocp[24] = x6;
  allocp[25] = a3;
  allocp[26] = x4;
  allocp[27] = a6;
  allocp[28] = x3;
  allocp[29] = (q)(struct goalrec*)&allocp[21];
  allocp[30] = (q)(&predicate_functor__table_xarg_3);
  allocp[31] = a0;
  allocp[32] = a4;
  allocp[33] = x5;
  qp = (struct goalrec*)&allocp[29];
  allocp += 34;
  proceed();
 set__goal__modes1_8_4:
  if (!isref(a1)) goto set__goal__modes1_8_interrupt;
  deref_and_jump(a1,set__goal__modes1_8_3);
  *reasonp++ =  a1;
  goto set__goal__modes1_8_interrupt;
 set__goal__modes1_8_5:
  if (!isref(a0)) goto set__goal__modes1_8_interrupt;
  deref_and_jump(a0,set__goal__modes1_8_2);
  *reasonp++ =  a0;
  goto set__goal__modes1_8_interrupt;
 case ATOMIC:
  if (a2 != NILATOM) goto set__goal__modes1_8_interrupt;
 set__goal__modes1_8_6:
  if (!isint(a0)) goto set__goal__modes1_8_9;
 set__goal__modes1_8_7:
  if (!isint(a1)) goto set__goal__modes1_8_8;
  gblt_greater(a0,a1,set__goal__modes1_8_interrupt);
  unify2(a5, a4, a7, a6);
  proceed();
 set__goal__modes1_8_8:
  if (!isref(a1)) goto set__goal__modes1_8_interrupt;
  deref_and_jump(a1,set__goal__modes1_8_7);
  *reasonp++ =  a1;
  goto set__goal__modes1_8_interrupt;
 set__goal__modes1_8_9:
  if (!isref(a0)) goto set__goal__modes1_8_interrupt;
  deref_and_jump(a0,set__goal__modes1_8_6);
  *reasonp++ =  a0;
  goto set__goal__modes1_8_interrupt;
 case VARREF:
  deref_and_jump(a2,set__goal__modes1_8_1);
  *reasonp++ =  a2;
  goto set__goal__modes1_8_interrupt;
  };
  goto set__goal__modes1_8_interrupt;
 set__goal__modes1_8_ext_interrupt:
  reasonp = 0l;
 set__goal__modes1_8_interrupt:
  toppred = &predicate_mode_xset__goal__modes1_8;
  goto interrupt_8;
 }

 set__arg__mode_6_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 set__arg__mode_6_clear_reason:
  reasonp = reasons;
 set__arg__mode_6_0:
 set__arg__mode_6_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_variable_3)) goto set__arg__mode_6_3;
  x0 = arg(a0, 2);
 set__arg__mode_6_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__3F)) goto set__arg__mode_6_3;
  allocp[0] = makesym(functor_variable_3);
  allocp[1] = arg(a0, 0);
  allocp[2] = arg(a0, 1);
  allocp[3] = a1;
  x1 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a3, x1);
  x2 = a1;
  a1 = a2;
  a2 = arg(a0, 0);
  a3 = a4;
  a4 = a5;
  a0 = x2;
  execute(dec__varcount_5_0);
  goto dec__varcount_5_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,set__arg__mode_6_2);
  *reasonp++ =  x0;
  goto set__arg__mode_6_3;
  };
  goto set__arg__mode_6_3;
 case VARREF:
  deref_and_jump(a0,set__arg__mode_6_1);
  *reasonp++ =  a0;
  goto set__arg__mode_6_3;
  };
  goto set__arg__mode_6_3;
 set__arg__mode_6_3:
  otherwise(set__arg__mode_6_interrupt);
 set__arg__mode_6_4:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_variable_3)) goto set__arg__mode_6_9;
  x0 = arg(a0, 2);
 set__arg__mode_6_5:
  if (isref(x0)) goto set__arg__mode_6_8;
 set__arg__mode_6_6:
  if (isref(x0)) goto set__arg__mode_6_7;
  if_not_equal(x0, a1, set__arg__mode_6_9);
  allocp[0] = makesym(functor_variable_3);
  allocp[1] = arg(a0, 0);
  allocp[2] = arg(a0, 1);
  allocp[3] = a1;
  x1 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a3, x1);
  unify(a5, a4);
  proceed();
 set__arg__mode_6_7:
  deref_and_jump(x0,set__arg__mode_6_6);
  *reasonp++ =  x0;
  goto set__arg__mode_6_9;
 set__arg__mode_6_8:
  deref_and_jump(x0,set__arg__mode_6_5);
  *reasonp++ =  x0;
  goto set__arg__mode_6_9;
 case VARREF:
  deref_and_jump(a0,set__arg__mode_6_4);
  *reasonp++ =  a0;
  goto set__arg__mode_6_9;
  };
  goto set__arg__mode_6_9;
 set__arg__mode_6_9:
  otherwise(set__arg__mode_6_interrupt);
 set__arg__mode_6_10:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_variable_3)) goto set__arg__mode_6_12;
 set__arg__mode_6_11:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom__3F)) goto set__arg__mode_6_12;
  unify_value(a3, a0);
  unify(a5, a4);
  proceed();
 case VARREF:
  deref_and_jump(a1,set__arg__mode_6_11);
  *reasonp++ =  a1;
  goto set__arg__mode_6_12;
  };
  goto set__arg__mode_6_12;
 case VARREF:
  deref_and_jump(a0,set__arg__mode_6_10);
  *reasonp++ =  a0;
  goto set__arg__mode_6_12;
  };
  goto set__arg__mode_6_12;
 set__arg__mode_6_12:
  otherwise(set__arg__mode_6_interrupt);
 set__arg__mode_6_13:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_variable_3)) goto set__arg__mode_6_14;
  x0 = makesym(atom_error);
  unify(x0, makesym(atom_set__arg__mode));
  unify_value(a3, a0);
  unify(a5, a4);
  proceed();
 case VARREF:
  deref_and_jump(a0,set__arg__mode_6_13);
  *reasonp++ =  a0;
  goto set__arg__mode_6_14;
  };
  goto set__arg__mode_6_14;
 set__arg__mode_6_14:
  otherwise(set__arg__mode_6_interrupt);
  unify2(a3, a0, a5, a4);
  proceed();
 set__arg__mode_6_ext_interrupt:
  reasonp = 0l;
 set__arg__mode_6_interrupt:
  toppred = &predicate_mode_xset__arg__mode_6;
  goto interrupt_6;
 }

 dec__varcount_5_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 dec__varcount_5_clear_reason:
  reasonp = reasons;
 dec__varcount_5_0:
 dec__varcount_5_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_head)) goto dec__varcount_5_2;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xdec__varcount_5);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = makesym(atom_dummy);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  a1 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(reverse__mode_2_0);
  goto reverse__mode_2_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,dec__varcount_5_1);
  *reasonp++ =  a1;
  goto dec__varcount_5_2;
  };
  goto dec__varcount_5_2;
 dec__varcount_5_2:
  otherwise(dec__varcount_5_interrupt);
 dec__varcount_5_3:
  if (isref(a3)) goto dec__varcount_5_6;
  gblt_pfunctor(a3,x0,dec__varcount_5_7);
  gblt_arity(a3,x1,dec__varcount_5_7);
 dec__varcount_5_4:
  if (!isint(a2)) goto dec__varcount_5_5;
  gblt_add(a2,makeint(1L),x2,dec__varcount_5_7);
  gblt_greater(x2,x1,dec__varcount_5_7);
  unify_value(a4, a3);
  proceed();
 dec__varcount_5_5:
  if (!isref(a2)) goto dec__varcount_5_7;
  deref_and_jump(a2,dec__varcount_5_4);
  *reasonp++ =  a2;
  goto dec__varcount_5_7;
 dec__varcount_5_6:
  deref_and_jump(a3,dec__varcount_5_3);
  *reasonp++ =  a3;
  goto dec__varcount_5_7;
 dec__varcount_5_7:
  otherwise(dec__varcount_5_interrupt);
  bblt_add_no_check_y(a2,makeint(1L),x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xdec__varcount1_5);
  allocp[2] = a0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_functor__table_xarg_3);
  allocp[9] = x0;
  allocp[10] = a3;
  allocp[11] = x1;
  qp = (struct goalrec*)&allocp[7];
  allocp += 12;
  proceed();
 dec__varcount_5_ext_interrupt:
  reasonp = 0l;
 dec__varcount_5_interrupt:
  toppred = &predicate_mode_xdec__varcount_5;
  goto interrupt_5;
 }

 dec__varcount1_5_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 dec__varcount1_5_clear_reason:
  reasonp = reasons;
 dec__varcount1_5_0:
 dec__varcount1_5_1:
  switch (ptagof(a1)) {
 case ATOMIC:
 dec__varcount1_5_2:
  if (a1 != makeint(0L)) goto dec__varcount1_5_3;
  unify(a4, a3);
  proceed();
 case VARREF:
  deref_and_jump(a1,dec__varcount1_5_1);
  *reasonp++ =  a1;
  goto dec__varcount1_5_3;
  };
  goto dec__varcount1_5_3;
 dec__varcount1_5_3:
  otherwise(dec__varcount1_5_interrupt);
 dec__varcount1_5_4:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto dec__varcount1_5_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_i)):
  bblt_add_no_check_y(a2,makeint(1L),x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a3;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a4;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a1;
  allocp[9] = makeint(1L);
  allocp[10] = x2;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[13] = a2;
  allocp[14] = makeint(1L);
  allocp[15] = x1;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_functor__table_xarg_3);
  allocp[18] = x0;
  allocp[19] = a3;
  allocp[20] = a1;
  qp = (struct goalrec*)&allocp[16];
  allocp += 21;
  proceed();
 case symval(makesym(atom_o)):
  bblt_add_no_check_y(a2,makeint(1L),x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = x0;
  allocp[3] = a3;
  allocp[4] = makeint(0L);
  allocp[5] = a4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  proceed();
 case symval(makesym(atom__3F)):
  unify(a4, a3);
  proceed();
  };
  goto dec__varcount1_5_interrupt;
 case VARREF:
  deref_and_jump(a0,dec__varcount1_5_4);
  *reasonp++ =  a0;
  goto dec__varcount1_5_interrupt;
  };
  goto dec__varcount1_5_interrupt;
 dec__varcount1_5_ext_interrupt:
  reasonp = 0l;
 dec__varcount1_5_interrupt:
  goto interrupt_5;
 }

 reverse__mode_2_top: {
  qp = qp->next;
 reverse__mode_2_clear_reason:
  reasonp = reasons;
 reverse__mode_2_0:
 reverse__mode_2_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto reverse__mode_2_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_i)):
  unify_value(a1, makesym(atom_o));
  proceed();
 case symval(makesym(atom_o)):
  unify_value(a1, makesym(atom_i));
  proceed();
 case symval(makesym(atom__3F)):
  unify_value(a1, makesym(atom__3F));
  proceed();
  };
  goto reverse__mode_2_interrupt;
 case VARREF:
  deref_and_jump(a0,reverse__mode_2_1);
  *reasonp++ =  a0;
  goto reverse__mode_2_interrupt;
  };
  goto reverse__mode_2_interrupt;
 reverse__mode_2_ext_interrupt:
  reasonp = 0l;
 reverse__mode_2_interrupt:
  toppred = &predicate_mode_xreverse__mode_2;
  goto interrupt_2;
 }

 determine__goal__mode_6_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 determine__goal__mode_6_clear_reason:
  reasonp = reasons;
 determine__goal__mode_6_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xdetermine__goal__mode1_8);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a0;
  allocp[5] = a1;
  allocp[6] = a2;
  allocp[7] = a3;
  allocp[8] = a4;
  allocp[9] = a5;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[12] = a0;
  allocp[13] = x2 = makeref(&allocp[13]);
  allocp[14] = x0;
  a0 = a3;
  a1 = a2;
  a2 = a4;
  a3 = x1;
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  execute(make__mode_4_0);
  goto make__mode_4_ext_interrupt;
 determine__goal__mode_6_ext_interrupt:
  reasonp = 0l;
 determine__goal__mode_6_interrupt:
  goto interrupt_6;
 }

 determine__goal__mode1_8_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 determine__goal__mode1_8_clear_reason:
  reasonp = reasons;
 determine__goal__mode1_8_0:
 determine__goal__mode1_8_1:
  if (!isint(a0)) goto determine__goal__mode1_8_10;
  gblt_greater(a0,makeint(0L),determine__goal__mode1_8_11);
 determine__goal__mode1_8_2:
  if (isref(a2)) goto determine__goal__mode1_8_9;
  gblt_arg(a0,a2,x0,determine__goal__mode1_8_11);
 determine__goal__mode1_8_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_variable_3)) goto determine__goal__mode1_8_11;
  x1 = arg(x0, 0);
 determine__goal__mode1_8_4:
  if (isref(x1)) goto determine__goal__mode1_8_8;
 determine__goal__mode1_8_5:
  if (isref(x1)) goto determine__goal__mode1_8_7;
  if_not_equal(x1, a5, determine__goal__mode1_8_11);
  x2 = arg(x0, 2);
 determine__goal__mode1_8_6:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != makesym(atom__3F)) goto determine__goal__mode1_8_11;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xdetermine__goal__mode1_8);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = x5 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[12] = a0;
  allocp[13] = makeint(1L);
  allocp[14] = x3;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[17] = a0;
  allocp[18] = a2;
  allocp[19] = x6 = makeref(&allocp[19]);
  allocp[20] = x4;
  a0 = x0;
  a2 = a4;
  a3 = x6;
  a4 = a6;
  a5 = x5;
  qp = (struct goalrec*)&allocp[15];
  allocp += 21;
  execute(set__arg__mode_6_clear_reason);
  goto set__arg__mode_6_ext_interrupt;
 case VARREF:
  deref_and_jump(x2,determine__goal__mode1_8_6);
  *reasonp++ =  x2;
  goto determine__goal__mode1_8_11;
  };
  goto determine__goal__mode1_8_11;
 determine__goal__mode1_8_7:
  deref_and_jump(x1,determine__goal__mode1_8_5);
  *reasonp++ =  x1;
  goto determine__goal__mode1_8_11;
 determine__goal__mode1_8_8:
  deref_and_jump(x1,determine__goal__mode1_8_4);
  *reasonp++ =  x1;
  goto determine__goal__mode1_8_11;
 case VARREF:
  deref_and_jump(x0,determine__goal__mode1_8_3);
  *reasonp++ =  x0;
  goto determine__goal__mode1_8_11;
  };
  goto determine__goal__mode1_8_11;
 determine__goal__mode1_8_9:
  deref_and_jump(a2,determine__goal__mode1_8_2);
  *reasonp++ =  a2;
  goto determine__goal__mode1_8_11;
 determine__goal__mode1_8_10:
  if (!isref(a0)) goto determine__goal__mode1_8_11;
  deref_and_jump(a0,determine__goal__mode1_8_1);
  *reasonp++ =  a0;
  goto determine__goal__mode1_8_11;
 determine__goal__mode1_8_11:
  otherwise(determine__goal__mode1_8_interrupt);
 determine__goal__mode1_8_12:
  if (!isint(a0)) goto determine__goal__mode1_8_16;
  gblt_greater(a0,makeint(0L),determine__goal__mode1_8_17);
 determine__goal__mode1_8_13:
  if (isref(a2)) goto determine__goal__mode1_8_15;
  gblt_arg(a0,a2,x0,determine__goal__mode1_8_17);
 determine__goal__mode1_8_14:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_variable_3)) goto determine__goal__mode1_8_17;
  bblt_sub_no_check(a0,makeint(1L),x1);
  a0 = x1;
  execute(determine__goal__mode1_8_0);
  goto determine__goal__mode1_8_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,determine__goal__mode1_8_14);
  *reasonp++ =  x0;
  goto determine__goal__mode1_8_17;
  };
  goto determine__goal__mode1_8_17;
 determine__goal__mode1_8_15:
  deref_and_jump(a2,determine__goal__mode1_8_13);
  *reasonp++ =  a2;
  goto determine__goal__mode1_8_17;
 determine__goal__mode1_8_16:
  if (!isref(a0)) goto determine__goal__mode1_8_17;
  deref_and_jump(a0,determine__goal__mode1_8_12);
  *reasonp++ =  a0;
  goto determine__goal__mode1_8_17;
 determine__goal__mode1_8_17:
  otherwise(determine__goal__mode1_8_interrupt);
 determine__goal__mode1_8_18:
  if (!isint(a0)) goto determine__goal__mode1_8_22;
  gblt_greater(a0,makeint(0L),determine__goal__mode1_8_21);
 determine__goal__mode1_8_19:
  if (isref(a2)) goto determine__goal__mode1_8_20;
  gblt_arg(a0,a2,x0,determine__goal__mode1_8_21);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xdetermine__goal__mode1_8);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[12] = a0;
  allocp[13] = makeint(1L);
  allocp[14] = x1;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[17] = a0;
  allocp[18] = a2;
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = x2;
  a0 = a1;
  a1 = x0;
  a2 = x4;
  a3 = a4;
  a4 = a5;
  a5 = a6;
  a6 = x3;
  qp = (struct goalrec*)&allocp[15];
  allocp += 21;
  execute(determine__functor__mode_7_0);
  goto determine__functor__mode_7_ext_interrupt;
 determine__goal__mode1_8_20:
  deref_and_jump(a2,determine__goal__mode1_8_19);
  *reasonp++ =  a2;
  goto determine__goal__mode1_8_21;
 determine__goal__mode1_8_21:
  if (a0 != makeint(0L)) goto determine__goal__mode1_8_interrupt;
  unify2(a3, a2, a7, a6);
  proceed();
 determine__goal__mode1_8_22:
  if (!isref(a0)) goto determine__goal__mode1_8_interrupt;
  deref_and_jump(a0,determine__goal__mode1_8_18);
  *reasonp++ =  a0;
  goto determine__goal__mode1_8_interrupt;
 determine__goal__mode1_8_ext_interrupt:
  reasonp = 0l;
 determine__goal__mode1_8_interrupt:
  goto interrupt_8;
 }

 determine__functor__mode_7_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 determine__functor__mode_7_clear_reason:
  reasonp = reasons;
 determine__functor__mode_7_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xdetermine__goal__mode1_8);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[12] = a1;
  allocp[13] = x1 = makeref(&allocp[13]);
  allocp[14] = x0;
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 determine__functor__mode_7_ext_interrupt:
  reasonp = 0l;
 determine__functor__mode_7_interrupt:
  toppred = &predicate_mode_xdetermine__functor__mode_7;
  goto interrupt_7;
 }

 make__mode_4_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 make__mode_4_clear_reason:
  reasonp = reasons;
 make__mode_4_0:
 make__mode_4_1:
  if (isref(a2)) goto make__mode_4_4;
  gblt_pfunctor(a2,x0,make__mode_4_5);
  gblt_arity(a2,x1,make__mode_4_5);
 make__mode_4_2:
  if (!isint(a0)) goto make__mode_4_3;
  gblt_add(a0,makeint(1L),x2,make__mode_4_5);
  gblt_greater(x2,x1,make__mode_4_5);
  unify_value(a3, makesym(atom__3F));
  proceed();
 make__mode_4_3:
  if (!isref(a0)) goto make__mode_4_5;
  deref_and_jump(a0,make__mode_4_2);
  *reasonp++ =  a0;
  goto make__mode_4_5;
 make__mode_4_4:
  deref_and_jump(a2,make__mode_4_1);
  *reasonp++ =  a2;
  goto make__mode_4_5;
 make__mode_4_5:
 make__mode_4_6:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_head)) goto make__mode_4_7;
  bblt_add_no_check_y(a0,makeint(1L),x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xreverse__mode_2);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a3;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_mode_xmake__mode1_2);
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = x1;
  allocp[8] = (q)(struct goalrec*)&allocp[4];
  allocp[9] = (q)(&predicate_functor__table_xarg_3);
  allocp[10] = x0;
  allocp[11] = a2;
  allocp[12] = x2;
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  proceed();
 case VARREF:
  deref_and_jump(a1,make__mode_4_6);
  *reasonp++ =  a1;
  goto make__mode_4_7;
  };
  goto make__mode_4_7;
 make__mode_4_7:
  otherwise(make__mode_4_interrupt);
  bblt_add_no_check_y(a0,makeint(1L),x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xmake__mode1_2);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a3;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_functor__table_xarg_3);
  allocp[6] = x0;
  allocp[7] = a2;
  allocp[8] = x1;
  qp = (struct goalrec*)&allocp[4];
  allocp += 9;
  proceed();
 make__mode_4_ext_interrupt:
  reasonp = 0l;
 make__mode_4_interrupt:
  toppred = &predicate_mode_xmake__mode_4;
  goto interrupt_4;
 }

 make__mode1_2_top: {
  qp = qp->next;
 make__mode1_2_clear_reason:
  reasonp = reasons;
 make__mode1_2_0:
 make__mode1_2_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 make__mode1_2_2:
  switch ((unsigned long)a0) {
 case (unsigned long) makeint(1L):
  unify_value(a1, makesym(atom_o));
  proceed();
 case (unsigned long) makeint(0L):
  unify_value(a1, makesym(atom_i));
  proceed();
  };
  goto make__mode1_2_3;
 case VARREF:
  deref_and_jump(a0,make__mode1_2_1);
  *reasonp++ =  a0;
  goto make__mode1_2_3;
  };
  goto make__mode1_2_3;
 make__mode1_2_3:
  otherwise(make__mode1_2_interrupt);
  unify_value(a1, makesym(atom__3F));
  proceed();
 make__mode1_2_ext_interrupt:
  reasonp = 0l;
 make__mode1_2_interrupt:
  goto interrupt_2;
 }

 get__mode_9_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 get__mode_9_clear_reason:
  reasonp = reasons;
 get__mode_9_0:
 get__mode_9_1:
  switch (ptagof(a2)) {
 case ATOMIC:
 get__mode_9_2:
  if (a2 != makeint(-1L)) goto get__mode_9_3;
  unify_value(a6, makesym(atom__3F));
  unify_value(a5, makesym(atom_alias));
  unify_value(a7, makeint(-1L));
  proceed();
 case VARREF:
  deref_and_jump(a2,get__mode_9_1);
  *reasonp++ =  a2;
  goto get__mode_9_3;
  };
  goto get__mode_9_3;
 get__mode_9_3:
  otherwise(get__mode_9_interrupt);
 get__mode_9_4:
  switch (ptagof(a4)) {
 case CONS:
  x0 = car_of(a4);
 get__mode_9_5:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto get__mode_9_14;
  x1 = arg(x0, 0);
 get__mode_9_6:
  if (isref(x1)) goto get__mode_9_13;
 get__mode_9_7:
  if (isref(x1)) goto get__mode_9_12;
  if_not_equal(x1, a0, get__mode_9_14);
 get__mode_9_8:
  if (!isint(a1)) goto get__mode_9_11;
  x2 = arg(x0, 1);
 get__mode_9_9:
  if (isref(x2)) goto get__mode_9_10;
  gblt_arg(a1,x2,x3,get__mode_9_14);
  a0 = a2;
  a1 = a3;
  a2 = x3;
  a3 = a5;
  a4 = a6;
  a5 = a7;
  execute(get__mode__clause_6_clear_reason);
  goto get__mode__clause_6_ext_interrupt;
 get__mode_9_10:
  deref_and_jump(x2,get__mode_9_9);
  *reasonp++ =  x2;
  goto get__mode_9_14;
 get__mode_9_11:
  if (!isref(a1)) goto get__mode_9_14;
  deref_and_jump(a1,get__mode_9_8);
  *reasonp++ =  a1;
  goto get__mode_9_14;
 get__mode_9_12:
  deref_and_jump(x1,get__mode_9_7);
  *reasonp++ =  x1;
  goto get__mode_9_14;
 get__mode_9_13:
  deref_and_jump(x1,get__mode_9_6);
  *reasonp++ =  x1;
  goto get__mode_9_14;
 case VARREF:
  deref_and_jump(x0,get__mode_9_5);
  *reasonp++ =  x0;
  goto get__mode_9_14;
  };
  goto get__mode_9_14;
 case VARREF:
  deref_and_jump(a4,get__mode_9_4);
  *reasonp++ =  a4;
  goto get__mode_9_14;
  };
  goto get__mode_9_14;
 get__mode_9_14:
  otherwise(get__mode_9_interrupt);
 get__mode_9_15:
  switch (ptagof(a4)) {
 case CONS:
  a4 = cdr_of(a4);
  execute(get__mode_9_0);
  goto get__mode_9_ext_interrupt;
 case VARREF:
  deref_and_jump(a4,get__mode_9_15);
  *reasonp++ =  a4;
  goto get__mode_9_interrupt;
  };
  goto get__mode_9_interrupt;
 get__mode_9_ext_interrupt:
  reasonp = 0l;
 get__mode_9_interrupt:
  goto interrupt_9;
 }

 get__mode__clause_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 get__mode__clause_6_clear_reason:
  reasonp = reasons;
 get__mode__clause_6_0:
  allocp[0] = makesym(functor_clause_6);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = x5 = makeref(&allocp[5]);
  allocp[6] = x6 = makeref(&allocp[6]);
  x0 = makefunctor(&allocp[0]);
  allocp += 7;
  unify_value(a2, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xget__mode__goals_7);
  allocp[2] = x3;
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = makesym(atom_body);
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_mode_xget__mode__goals_7);
  allocp[11] = x2;
  allocp[12] = a0;
  allocp[13] = a1;
  allocp[14] = makesym(atom_guard);
  allocp[15] = a3;
  allocp[16] = a4;
  allocp[17] = a5;
  a2 = a0;
  x7 = a1;
  x8 = a3;
  a6 = a4;
  a7 = a5;
  a5 = x8;
  a4 = makesym(atom_head);
  a3 = x7;
  a1 = x1;
  a0 = makeint(1L);
  qp = (struct goalrec*)&allocp[9];
  allocp += 18;
  execute(get__mode__functor_8_0);
  goto get__mode__functor_8_ext_interrupt;
 get__mode__clause_6_ext_interrupt:
  reasonp = 0l;
 get__mode__clause_6_interrupt:
  toppred = &predicate_mode_xget__mode__clause_6;
  goto interrupt_6;
 }

 get__mode__goals_7_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 get__mode__goals_7_clear_reason:
  reasonp = reasons;
 get__mode__goals_7_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xget__mode__goals1_8);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[12] = a0;
  allocp[13] = x1 = makeref(&allocp[13]);
  allocp[14] = x0;
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 get__mode__goals_7_ext_interrupt:
  reasonp = 0l;
 get__mode__goals_7_interrupt:
  goto interrupt_7;
 }

 get__mode__goals1_8_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 get__mode__goals1_8_clear_reason:
  reasonp = reasons;
 get__mode__goals1_8_0:
 get__mode__goals1_8_1:
  if (!isint(a0)) goto get__mode__goals1_8_3;
  gblt_greater(a0,makeint(0L),get__mode__goals1_8_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xget__mode__goals1_8);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[12] = a0;
  allocp[13] = makeint(1L);
  allocp[14] = x0;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_mode_xget__mode__functor_8);
  allocp[17] = x1 = makeref(&allocp[17]);
  allocp[18] = a2;
  allocp[19] = a3;
  allocp[20] = a4;
  allocp[21] = a5;
  allocp[22] = a6;
  allocp[23] = a0;
  allocp[24] = a7;
  allocp[25] = (q)(struct goalrec*)&allocp[15];
  allocp[26] = (q)(&predicate_functor__table_xarg_3);
  allocp[27] = a0;
  allocp[28] = a1;
  allocp[29] = x1;
  qp = (struct goalrec*)&allocp[25];
  allocp += 30;
  proceed();
 get__mode__goals1_8_2:
  if (a0 != makeint(0L)) goto get__mode__goals1_8_interrupt;
  proceed();
 get__mode__goals1_8_3:
  if (!isref(a0)) goto get__mode__goals1_8_interrupt;
  deref_and_jump(a0,get__mode__goals1_8_1);
  *reasonp++ =  a0;
  goto get__mode__goals1_8_interrupt;
 get__mode__goals1_8_ext_interrupt:
  reasonp = 0l;
 get__mode__goals1_8_interrupt:
  goto interrupt_8;
 }

 get__mode__functor_8_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 get__mode__functor_8_clear_reason:
  reasonp = reasons;
 get__mode__functor_8_0:
 get__mode__functor_8_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 get__mode__functor_8_2:
  gblt_atomic(a0,get__mode__functor_8_11);
  proceed();
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_variable_3)) goto get__mode__functor_8_11;
  x0 = arg(a0, 0);
 get__mode__functor_8_3:
  if (isref(x0)) goto get__mode__functor_8_10;
 get__mode__functor_8_4:
  if (isref(x0)) goto get__mode__functor_8_9;
  if_not_equal(x0, a2, get__mode__functor_8_11);
  x1 = arg(a0, 1);
 get__mode__functor_8_5:
  if (isref(x1)) goto get__mode__functor_8_8;
 get__mode__functor_8_6:
  if (isref(x1)) goto get__mode__functor_8_7;
  if_not_equal(x1, a1, get__mode__functor_8_11);
  x2 = arg(a0, 2);
  unify3(a5, x2, a4, a3, a7, a6);
  proceed();
 get__mode__functor_8_7:
  deref_and_jump(x1,get__mode__functor_8_6);
  *reasonp++ =  x1;
  goto get__mode__functor_8_11;
 get__mode__functor_8_8:
  deref_and_jump(x1,get__mode__functor_8_5);
  *reasonp++ =  x1;
  goto get__mode__functor_8_11;
 get__mode__functor_8_9:
  deref_and_jump(x0,get__mode__functor_8_4);
  *reasonp++ =  x0;
  goto get__mode__functor_8_11;
 get__mode__functor_8_10:
  deref_and_jump(x0,get__mode__functor_8_3);
  *reasonp++ =  x0;
  goto get__mode__functor_8_11;
 case VARREF:
  deref_and_jump(a0,get__mode__functor_8_1);
  *reasonp++ =  a0;
  goto get__mode__functor_8_11;
  };
  goto get__mode__functor_8_11;
 get__mode__functor_8_11:
  otherwise(get__mode__functor_8_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xget__mode__functor1_9);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[13] = a0;
  allocp[14] = x1 = makeref(&allocp[14]);
  allocp[15] = x0;
  qp = (struct goalrec*)&allocp[11];
  allocp += 16;
  proceed();
 get__mode__functor_8_ext_interrupt:
  reasonp = 0l;
 get__mode__functor_8_interrupt:
  toppred = &predicate_mode_xget__mode__functor_8;
  goto interrupt_8;
 }

 get__mode__functor1_9_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 get__mode__functor1_9_clear_reason:
  reasonp = reasons;
 get__mode__functor1_9_0:
 get__mode__functor1_9_1:
  if (!isint(a0)) goto get__mode__functor1_9_3;
  gblt_greater(a0,makeint(0L),get__mode__functor1_9_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_mode_xget__mode__functor1_9);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x0;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_mode_xget__mode__functor_8);
  allocp[18] = x1 = makeref(&allocp[18]);
  allocp[19] = a2;
  allocp[20] = a3;
  allocp[21] = a4;
  allocp[22] = a5;
  allocp[23] = a6;
  allocp[24] = a7;
  allocp[25] = a8;
  allocp[26] = (q)(struct goalrec*)&allocp[16];
  allocp[27] = (q)(&predicate_functor__table_xarg_3);
  allocp[28] = a0;
  allocp[29] = a1;
  allocp[30] = x1;
  qp = (struct goalrec*)&allocp[26];
  allocp += 31;
  proceed();
 get__mode__functor1_9_2:
  if (a0 != makeint(0L)) goto get__mode__functor1_9_interrupt;
  proceed();
 get__mode__functor1_9_3:
  if (!isref(a0)) goto get__mode__functor1_9_interrupt;
  deref_and_jump(a0,get__mode__functor1_9_1);
  *reasonp++ =  a0;
  goto get__mode__functor1_9_interrupt;
 get__mode__functor1_9_ext_interrupt:
  reasonp = 0l;
 get__mode__functor1_9_interrupt:
  goto interrupt_9;
 }

 mode2ru_2_top: {
  qp = qp->next;
 mode2ru_2_clear_reason:
  reasonp = reasons;
 mode2ru_2_0:
 mode2ru_2_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto mode2ru_2_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_i)):
  unify_value(a1, makesym(atom_u));
  proceed();
 case symval(makesym(atom_o)):
  unify_value(a1, makesym(atom_r));
  proceed();
 case symval(makesym(atom__3F)):
  unify_value(a1, makesym(atom__3F));
  proceed();
  };
  goto mode2ru_2_interrupt;
 case VARREF:
  deref_and_jump(a0,mode2ru_2_1);
  *reasonp++ =  a0;
  goto mode2ru_2_interrupt;
  };
  goto mode2ru_2_interrupt;
 mode2ru_2_ext_interrupt:
  reasonp = 0l;
 mode2ru_2_interrupt:
  goto interrupt_2;
 }

 ru2mode_2_top: {
  qp = qp->next;
 ru2mode_2_clear_reason:
  reasonp = reasons;
 ru2mode_2_0:
 ru2mode_2_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto ru2mode_2_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_r)):
  unify_value(a1, makesym(atom_o));
  proceed();
 case symval(makesym(atom_u)):
  unify_value(a1, makesym(atom_i));
  proceed();
 case symval(makesym(atom__3F)):
  unify_value(a1, makesym(atom__3F));
  proceed();
 case symval(makesym(atom___)):
  unify_value(a1, makesym(atom__3F));
  proceed();
  };
  goto ru2mode_2_interrupt;
 case VARREF:
  deref_and_jump(a0,ru2mode_2_1);
  *reasonp++ =  a0;
  goto ru2mode_2_interrupt;
  };
  goto ru2mode_2_interrupt;
 ru2mode_2_ext_interrupt:
  reasonp = 0l;
 ru2mode_2_interrupt:
  goto interrupt_2;
 }

 reverse__ru_2_top: {
  qp = qp->next;
 reverse__ru_2_clear_reason:
  reasonp = reasons;
 reverse__ru_2_0:
 reverse__ru_2_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto reverse__ru_2_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_r)):
  unify_value(a1, makesym(atom_u));
  proceed();
 case symval(makesym(atom_u)):
  unify_value(a1, makesym(atom_r));
  proceed();
 case symval(makesym(atom__3F)):
  unify_value(a1, makesym(atom__3F));
  proceed();
  };
  goto reverse__ru_2_interrupt;
 case VARREF:
  deref_and_jump(a0,reverse__ru_2_1);
  *reasonp++ =  a0;
  goto reverse__ru_2_interrupt;
  };
  goto reverse__ru_2_interrupt;
 reverse__ru_2_ext_interrupt:
  reasonp = 0l;
 reverse__ru_2_interrupt:
  goto interrupt_2;
 }
 interrupt_9:
  allocp[10] = a8;
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_mode);
}
