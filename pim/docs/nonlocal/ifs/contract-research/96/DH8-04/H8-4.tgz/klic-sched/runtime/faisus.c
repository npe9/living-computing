/* ----------------------------------------------------------
%        Copyright (C) 1996-1997 Kazuhiko Ohno, Masahiko Ikawa,
%        and Computer Architecture Laboratory, Depertment of
%        Information Science, Kyoto University.
%----------------------------------------------------------- */  

/* ---------------------------------------------------------- 
	 %   (C)1993,1994,1995 Institute for New Generation Computer Technology
	 %       (Read COPYRIGHT for detailed information.) 
	 ----------------------------------------------------------- */

/* #define WWDEBUG
#define WDEBUG  */
#include <klic/wdebug.h>
#ifndef FIRST
#include <stdio.h>
#include <klic/basic.h>
#include <klic/struct.h>
#include <klic/alloc.h>
#include <klic/control.h>
#include <klic/susp.h>
#include <klic/generic.h>
#include <klic/gobj.h>

#ifdef SCHED
#include <klic/sched.h>
#endif
#ifdef PACKSEND
#include <klic/interpe.h>
#endif

#ifdef SCHED
extern struct threadrec thread_queue_tail;
#endif

#ifdef DEBUGLIB
extern int count_suspension;
#endif

#include <klic/debugprint.h>

/*  Not SUNMP
		
		#ifdef __STDC__
		static Volatile voidfn do_fail;
		#endif
		*/

#ifdef SCHED


static void do_fail(thread, reasonp)
	struct threadrec *thread;
	q *reasonp;
{
#ifdef DEBUGLIB
  thread->next = 0;
  trace_failure(thread);
#endif
  fatal("Reduction Failure");
}
#else
static void do_fail(goal, reasonp)
	struct goalrec *goal;
	q *reasonp;
{
  fatal("Reduction Failure");
#ifdef DEBUGLIB
  goal->next = 0;
  trace_failure(goal);
#endif
}
#endif
#ifdef DEBUGLIB
#ifdef SCHED
static Inline q *record_susp(allocp, thread)
	q *allocp;
	struct threadrec *thread;
{
  declare_globals;
  struct suspended_thread_rec *sm;
  void record_suspended_pred();
  heapalloc(sm, sizeof(struct suspended_thread_rec)/sizeof(q),
						(struct suspended_thread_rec *));
  sm->thread = thread;
  sm->next = suspended_thread_list;
  suspended_thread_list = sm;
  if (count_suspension) {
    record_suspended_pred(thread);
  }
  return allocp;
}
#else
static Inline q *record_susp(allocp, goal)
	q *allocp;
	struct goalrec *goal;
{
  declare_globals;
  struct suspended_goal_rec *sm;
  void record_suspended_pred();
  heapalloc(sm, sizeof(struct suspended_goal_rec)/sizeof(q),
						(struct suspended_goal_rec *));
  sm->goal = goal;
  sm->next = suspended_goal_list;
  suspended_goal_list = sm;
  if (count_suspension) {
    record_suspended_pred(goal);
  }
  return allocp;
}

#endif /* SCHED */
#endif
#endif /* aho */

#ifdef SCHED
q *suspend_thread(allocp, thread, reason, spontaneous)
	q *allocp;
	struct threadrec *thread;
	q reason;
	int spontaneous;
{
  declare_globals;
  int suspended = 0;

	fprintf(logfile,"%d:THIS CASE IS NOT IMPLEMENT!\n",my_node);
	
	current_queue = thread->next;
  thread->next = (struct threadrec *)makeint(current_prio);
  if (derefone(reason) == reason) {
    /* no goals suspended yet on this variable */
    struct susprec *susp;
    q newvar;
    allocnewsusp(newvar,susp);
    susp->u.first_hook.u.t = thread;
    derefone(reason) = newvar;
    suspended = 1;
  } else {
    /* some goals already has suspended */
    struct susprec *susp;
    struct hook *newhook;
    susp = suspp(derefone(reason));
    /* generator object ? */
    if ( !isref(susp) || reason != derefone(susp) ) {
      resume_same_prio(thread);
      return(allocp);
    }
    if (!is_generator_susp(susp->u)) {
      /* then allocate new hook */
      allochook(&susp->u.first_hook,newhook);
      newhook->u.t = thread;
      suspended = 1;
    } else {
      struct generator_susp *gsusp = generator_suspp(susp);
      q ref = gsusp->backpt;
      struct generator_object *gobj = untag_generator_susp(gsusp->u.o);
      q tmp = generic_generate(gobj, allocp);
      if (tmp != (q)0) {
				if ( tmp == makecons(0) ) {
					q retval = generic_suspend(gobj, ref, thread);
					if(retval != makeref(0)) {
						resume_same_prio(thread);
					}else{
						suspended = 1;
					}
				} else {
					allocp = heapp;
					derefone(ref) = tmp;
					resume_same_prio(thread);
        }
      } else {
				/* This case, the instanciation by generator object must
					 postponed. Thus:
					 1. ``goal'' is hooked on new variable ``newvar''.
					 2. enqueue unification goal between ``newvar'' and ``ref'' */
				struct susprec *susp;
				q newvar;
				q* newstackp;
				struct threadrec *newtp = (struct threadrec *)allocp;
				extern struct predicate predicate_unify__term__dcode_xunify__goal_2;
				
				suspended = 1;

				allocnewsusp(newvar,susp);
				susp->u.first_hook.u.t = thread;
				newtp->next = (struct threadrec *)makeint(current_prio);
				newtp->stack = stq;
				stq = stq->next;
				if(stq == &stack_tail) 
					expand_stack_area(); 
				newstackp = newtp->stack->top;
				newstackp[0] = newvar;
				newstackp[1] = reason;				
				newstackp[2] = (q) &predicate_unify__term__dcode_xunify__goal_2;
				newtp->stack->top = newstackp+3;
				allocp += 2;
				resume_same_prio(newtp);
      }
    }
  }
  if (suspended) {
#ifdef DEBUGLIB
    allocp = record_susp(allocp, thread);
#endif
/*		fprintf(logfile,"%d:ssuspend_thread %x\n",my_node,thread); */
    suspensions++;
  }
  return(allocp);
}
#else
q *suspend_goal(allocp, goal, reason, spontaneous)
	q *allocp;
	struct goalrec *goal;
	q reason;
	int spontaneous;
{
  declare_globals;
  int suspended = 0;

  goal->next = (struct goalrec *)makeint(current_prio);
  if (derefone(reason) == reason) {
    /* no goals suspended yet on this variable */
    struct susprec *susp;
    q newvar;
    allocnewsusp(newvar,susp);
    susp->u.first_hook.u.g = goal;
    derefone(reason) = newvar;
    suspended = 1;
  } else {
    /* some goals already has suspended */
    struct susprec *susp;
    struct hook *newhook;
    susp = suspp(derefone(reason));
    /* generator object ? */
    if ( !isref(susp) || reason != derefone(susp) ) {
      resume_same_prio(goal);
      return(allocp);
    }
    if (!is_generator_susp(susp->u)) {
      /* then allocate new hook */
      allochook(&susp->u.first_hook,newhook);
      newhook->u.g = goal;
      suspended = 1;
    } else {
      struct generator_susp *gsusp = generator_suspp(susp);
      q ref = gsusp->backpt;
      struct generator_object *gobj = untag_generator_susp(gsusp->u.o);
      q tmp = generic_generate(gobj, allocp);
      if (tmp != (q)0) {
				if ( tmp == makecons(0) ) {
					q retval = generic_suspend(gobj, ref, goal);
					if(retval != makeref(0)) {
						resume_same_prio(goal);
					} else {
						suspended = 1;
					}
				} else {
					allocp = heapp;
					derefone(ref) = tmp;
					resume_same_prio(goal);
        }
      } else {
				/* This case, the instanciation by generator object must
					 postponed. Thus:
					 1. ``goal'' is hooked on new variable ``newvar''.
					 2. enqueue unification goal between ``newvar'' and ``ref'' */
				struct susprec *susp;
				q newvar;
				struct goalrec *newgp = (struct goalrec *)allocp;
				extern struct predicate predicate_unify__term__dcode_xunify__goal_2;

				suspended = 1;

				allocnewsusp(newvar,susp);
				susp->u.first_hook.u.g = goal;
				newgp->next = (struct goalrec *)makeint(current_prio);
				newgp->pred = &predicate_unify__term__dcode_xunify__goal_2;
				newgp->args[0] = reason;
				newgp->args[1] = newvar;
				allocp += 4;

				resume_same_prio(newgp);
      }
    }
  }
  if (suspended) {
#ifdef DEBUGLIB
    allocp = record_susp(allocp, goal);
#endif
    suspensions++;
  }

  return(allocp);
}
#endif
#ifdef PACKSEND
q *pk_suspend_goal(allocp,goal,reason)
	q *allocp;
	struct goalrec *goal;
	q reason;
{
	declare_globals;
	INT_CL_DEBUG_X(iosprintf("%d:pk_suspend_goal\n",my_node));
	goal->next = (struct goalrec *)makeint(current_prio);
	if(derefone(reason) == reason) {
		struct susprec *susp;
		q newvar;
		makenewsusp(newvar,susp,allocp); 
		susp->u.first_hook.u.g = goal;
		derefone(reason) = newvar;
	}else{
		iosprintf("reason %d\n",reason);
		fatal("Error in pk_suspend_goal");
	}
	
#ifdef DEBUGLIB
	allocp = record_susp(allocp, goal);
#endif
	suspensions++;
	return(allocp);
}
#endif

#ifdef SCHED
extern void expand_gvstack();
extern void scheduling_g_generate();
extern struct threadrec *enqueue_resumed_threads();
#ifdef PFIRST
Inline struct threadrec *
enqueue_producer_thread(producer,qp,request)
	struct threadrec *producer;
	struct threadrec *qp;
	struct request_record *request;
{
	declare_globals;

	if(!isint(producer->next)){
		if(producer->prio == current_prio){
			/* producer is active. enqueue request */
			request->next = producer->rtop;
			current_request = producer->rtop = request;
			if(qp != producer){
				/* producer thread is already top thread */
				producer->before->next = producer->next;
				producer->next->before = producer->before;
				producer->next = qp;
				qp->before = producer;
/*				fprintf(logfile,"%d: reply first %x\n",my_node,qp); */
				return producer;
			}
		} else {
			fatal(" generate thread is other priority thread,not implement !\n");
		}
	} else {
		WDEB(fprintf(logfile,"%d:gthread is suspended\n",my_node));
	}
	return qp;
}



extern struct threadrec *enqueue_prior_thread();
#endif

q *interrupt_thread(allocp, pred, reasonp, thread, stackp)
	q *allocp;
	struct predicate *pred;
	q *reasonp;
	struct threadrec *thread;
	q* stackp;
{
  declare_globals;
	struct threadrec *qp = thread->next;
	thread->stack->top = stackp;
	
	if(reasonp == reasons) {
    do_fail(thread, reasons[0]);
  } else {
    /* First, try dereference */
    /* Compiled out code won't dereference more than one level */
    q *rp;
		
#ifndef SCHED
    for (rp=reasons; rp<reasonp; rp++) {
      q v = *rp, iv = v, ov;
      do {
				q tmp;
				tmp = derefone(v);
				if (!isref(tmp)) {
					derefone(iv) = tmp;
					resume_same_prio(thread);
					return allocp;
				}
				ov = v;
				v = tmp;
      } while (derefone(v) != ov);
    }
#endif
		
    /* OK, the goal should really be suspended */
#ifdef DEBUGLIB
    {
      extern int trace_flag;
      struct threadrec *trace_susp();
      if (trace_flag && (reasonp > reasons)) {
				thread = trace_susp(thread, reasonp, 0);
      }
    }
#endif

		/* enqueue resumed thread */
		qp = enqueue_resumed_threads(qp);

    thread->next = (struct threadrec *)makeint(current_prio);

		/* 2 @ikawa */
    {
      int redo_request = 0;
      do {
				q tmp, tmp1;
				tmp = *(--reasonp);
				while(1) {
					tmp1 = derefone(tmp);
					if(!isref(tmp1)){
						resume_same_prio(thread);
						return allocp;
					}
#ifdef PFIRST
					else{
						if(check_srec(tmp1)){
							tmp = tmp1;
							break;
						}
					}
#endif
					if(derefone(tmp1) == tmp) break;
					tmp = tmp1;
				}

				/* 3 @ikawa */
				
#ifdef PFIRST
				if (check_srec(tmp)){
					/* reference scheduling object */
					struct susprec *susp;
					q newvar;
					struct scheduling_record* srec = untag_scheduling_record(tmp);
					struct threadrec *producer = srec->pthread;
					makenewsusp(newvar,susp,allocp);
					susp->u.first_hook.u.t = thread;
					derefone(srec) = newvar;
					susp->gthread = producer;
					WDEB(fprintf(logfile,
								"%d:ref srec %x -> susp %x: suspthread %x producer %x\n",
											 my_node,srec,susp,thread,producer));
					if(!prior_thread){
						/* $BM%@hE*$K$*$3$5$l$k%9%l%C%I$,:F3+$5$l$F$$$J$$>l9g(B
							 $B$OCfCG%9%l%C%I$N(Bproducer$B$rM%@hE*$K%9%1%8%e!<%k(B */
						struct request_record *newreq;
						makenewrequest(allocp,newreq,susp,thread);
						qp = enqueue_producer_thread(producer,qp,newreq);
					}
				} else if(tmp == tmp1) {
#else
					if(tmp == tmp1){
#endif
						/* no goals suspended yet on this variable*/
						struct susprec *susp;
						q newvar;
						makenewsusp(newvar,susp,allocp);
						susp->u.first_hook.u.t = thread;
						derefone(tmp) = newvar;
#ifdef PFIRST
						susp->gthread = (struct threadrec *)0;
#endif
					} else {
						/* some goals already has suspended */
						struct susprec *susp = suspp(tmp1);
					/* generator object ? */
						if(!is_generator_susp(susp->u)) {
							if (susp->u.first_hook.next->u.t == thread) {
								/* If the second hook is for the same thread, do nothing.
									 This includes the case where there's only one hook,
									 because of the loop structure of the hook chain. */
							} else {
								struct hook *newhook;
								addhook(&susp->u.first_hook,newhook,allocp);
								newhook->u.t = thread;
								WDEB(fprintf(logfile,"%d:reference susprec  %x\n",
													 my_node,susp));
							}
						} else {
							/* generator object */
							struct generator_susp *gsusp = generator_suspp(susp);
							q ref = gsusp->backpt;
							struct generator_object *gobj = untag_generator_susp(gsusp->u.o);
							q tmp0 = generic_generate(gobj, allocp);
							WDEB(fprintf(logfile,"%d:reference generator  %x\n",
												 my_node,susp));
							if(tmp0 == makecons(0)) {
								q retval = generic_suspend(gobj, ref, thread);
								if(retval != makeref(0)) {
									redo_request = 1;
								}
							} else {
								redo_request = 1;
								if(tmp0 != makeref(0)) {
									allocp = heapp;
									derefone(ref) = tmp0;
								} /* else GC request */
							}
						}
#ifdef PFIRST
					}
#else
				}
#endif
			} while (reasonp > reasons);
			if (redo_request) {
				/* ref is not normal ref */
				thread->next = qp;
#ifdef PFIRST
				qp->before = thread;
#endif
				qp = thread;
			} else {
#ifdef DEBUGLIB
					allocp = record_susp(allocp, thread);
#endif
#ifdef WDEBUG
					{
						char *buf;
						buf = sprint_qp(qp);
						WDEB(fprintf(logfile,"%d:s(%x) after susp %s",my_node,thread,buf));
				}
#endif
#ifdef PFIRST
					if(prior_thread)
						qp = enqueue_prior_thread(qp);
#endif
#ifdef WDEBUG
					{
						struct threadrec *tmp = qp;
						fprintf(logfile,"%d:change thread ",my_node);
						while(qp != &thread_queue_tail){
							fprintf(logfile," -> %x ",qp);
							qp = qp->next;
						}
						fprintf(logfile," (susp %x)\n",thread);
						fflush(logfile);
						qp = tmp;
					}
#endif
					suspensions++;
			}
		}
		current_queue = qp;
		return allocp;
	}
}
#else
q *interrupt_goal(allocp, pred, reasonp)
     q *allocp;
     struct predicate *pred;
     q *reasonp;
{
  declare_globals;
  struct goalrec *goal = (struct goalrec *)allocp;
  allocp += pred->arity + 2;
  goal->pred = pred;

  if (reasonp == 0) {
    /* Interrupt by some external event, such as: */
    /*   - A higher priority goal got ready for execution */
    /*   - Garbage collection required */
    /* In such cases, the interrupted goal is pushed down to the queue. */
    struct goalrec *rsmg = resumed_goals;
    if (rsmg == 0) {
      goal->next = goal;
    } else {
      goal->next = rsmg->next;
      rsmg->next = goal;
    }
    resumed_goals = goal;
    return allocp;
  } else if (reasonp == reasons) {
    do_fail(goal, reasons[0]);
  } else {
    /* First, try dereference */
    /* Compiled out code won't dereference more than one level */
    q *rp;
    for (rp=reasons; rp<reasonp; rp++) {
      q v = *rp, iv = v, ov;
      do {
	q tmp;
	tmp = derefone(v);
	if (!isref(tmp)) {
	  derefone(iv) = tmp;
	  resume_same_prio(goal);
	  return allocp;
	}
	ov = v;
	v = tmp;
      } while (derefone(v) != ov);
    }
    /* OK, the goal should really be suspended */
#ifdef DEBUGLIB
    {
      extern int trace_flag;
      struct goalrec *trace_susp();
      if (trace_flag && (reasonp > reasons)) {
	goal = trace_susp(goal, reasonp, 0);
      }
    }
#endif

    goal->next = (struct goalrec *)makeint(current_prio);
    {
      int redo_request = 0;
      do {
	q tmp, tmp1;
/*
	for (tmp = *(--reasonp), tmp1 = derefone(tmp);
	     derefone(tmp1) != tmp;
	     tmp = tmp1, tmp1 = derefone(tmp))
	  ;
*/
	tmp = *(--reasonp);
	while (1) {
	  tmp1 = derefone(tmp);
	  if ( !isref(tmp1) ) {
		resume_same_prio(goal);
		return allocp;
	  }
	  if (derefone(tmp1) == tmp ) break;
	  tmp = tmp1;
	}

	if (tmp == tmp1) {
	  /* no goals suspended yet on this variable */
	  struct susprec *susp;
	  q newvar;
	  makenewsusp(newvar,susp,allocp);
	  susp->u.first_hook.u.g = goal;
	  derefone(tmp) = newvar;
	} else {
	  /* some goals already has suspended */
	  struct susprec *susp = suspp(tmp1);
	  /* generator object ? */
	  if(!is_generator_susp(susp->u)) {
	    if (susp->u.first_hook.next->u.g == goal) {
	      /* If the second hook is for the same goal, do nothing.
		 This includes the case where there's only one hook,
		 because of the loop structure of the hook chain. */
	    } else {
	      struct hook *newhook;
	      addhook(&susp->u.first_hook,newhook,allocp);
	      newhook->u.g = goal;
	    }
	  } else {
	    /* generator object */
	    struct generator_susp *gsusp = generator_suspp(susp);
	    q ref = gsusp->backpt;
	    struct generator_object *gobj = untag_generator_susp(gsusp->u.o);
	    q tmp = generic_generate(gobj, allocp);

	    if(tmp == makecons(0)) {
	      q retval = generic_suspend(gobj, ref, goal);
	      if(retval != makeref(0)) {
					redo_request = 1;
	      }
	    } else {
	      redo_request = 1;
	      if(tmp != makeref(0)) {
					allocp = heapp; 
					derefone(ref) = tmp;
	      } /* else GC request */
	    }
	  }
	}
      } while (reasonp > reasons);
      if (redo_request) {
	resume_same_prio(goal);
      } else {
#ifdef DEBUGLIB
	allocp = record_susp(allocp, goal);
#endif
	suspensions++;
      }
    }
    return allocp;
  }
}
#endif

int check_stack_for_alternatively(allocp, reasonp)
     q *allocp;
     q *reasonp;
{
  declare_globals;

  while (reasonp != reasons) {
    /* suspension stack is not empty */
    q tmp, tmp1;
    q var = *(--reasonp);
    q value;
    struct susprec *susp;
    tmp = var;
    if (isref(tmp)) {
      while (1) {
        tmp1 = derefone(tmp);
        if (tmp == tmp1) goto fin;
        if (!isref(tmp1)) {
          value = tmp1;
          goto ok;
        }
        if (tmp == derefone(tmp1)) break;
        tmp = tmp1;
      }
      susp = suspp(tmp1);
      /* generator object ? */
      if (is_generator_susp(susp->u)) {
        struct generator_susp *gsusp = generator_suspp(susp);
        q ref = gsusp->backpt;
        q tmp = generic_generate(untag_generator_susp(gsusp->u.o),
                                 allocp);
        allocp = heapp;
        if (tmp == 0) goto fin;
        derefone(ref) = tmp;
        value = tmp;
        goto ok;
      }
    } else {
      value = tmp;
    ok:
      derefone(var) = value;
      heapp = allocp;
      return 1;
    }
  }
 fin:
  heapp = allocp;
  return 0;
}
