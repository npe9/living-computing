/* Compiled by KLIC compiler version 2.002 (Tue May 23 13:27:38 JST 1995) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_direct__call();
Const struct predicate predicate_direct__call_xmain_2 =
   { module_direct__call, 0, 2 };
Const struct predicate predicate_direct__call_xcheck__call_6 =
   { module_direct__call, 1, 6 };
Const struct predicate predicate_direct__call_xcheck__clauses_5 =
   { module_direct__call, 2, 5 };
Const struct predicate predicate_direct__call_xadd__go_6 =
   { module_direct__call, 3, 6 };
Const struct predicate predicate_direct__call_xcheck__builtin_4 =
   { module_direct__call, 4, 4 };
Const struct predicate predicate_direct__call_xcheck__builtin1_6 =
   { module_direct__call, 5, 6 };
Const struct predicate predicate_direct__call_xadd__go1_8 =
   { module_direct__call, 6, 8 };
Const struct predicate predicate_direct__call_xrecursive__bodys_6 =
   { module_direct__call, 7, 6 };
Const struct predicate predicate_direct__call_xrecursive__bodys1_6 =
   { module_direct__call, 8, 6 };
Const struct predicate predicate_direct__call_xrecursive__body_9 =
   { module_direct__call, 9, 9 };
Const struct predicate predicate_direct__call_xmake__nextgoal_8 =
   { module_direct__call, 10, 8 };
Const struct predicate predicate_direct__call_xremove__no__go_2 =
   { module_direct__call, 11, 2 };
Const struct predicate predicate_direct__call_xremove__no__go__clauses_3 =
   { module_direct__call, 12, 3 };
Const struct predicate predicate_direct__call_xremove__no__go__clause_2 =
   { module_direct__call, 13, 2 };
Const struct predicate predicate_direct__call_xremove__no__go__bodys_6 =
   { module_direct__call, 14, 6 };
extern Const struct predicate predicate_functor_xinsert__arg_4;
extern Const struct predicate predicate_functor_xdelete__arg_3;
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_functor__table_xfunctor_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_xsetarg_4;
extern Const struct predicate predicate_parse__uty_xget__def__clauses_5;
extern Const struct predicate predicate_parse__uty_xupdate__clause_5;
extern Const struct predicate predicate_parse__uty_xdecode__goal_4;
extern Const struct predicate predicate_parse__uty_xdecode__goalcall_6;

module module_direct__call(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  static Const q funct_const_0[] = {
    makesym(functor_functor_3),
    makesym(atom_dummy),
    makesym(atom___),
    makesym(atom_builtin),
  };
  static Const q funct_const_1[] = {
    makesym(functor_functor_1),
    makesym(atom_no__go),
  };
  static Const q funct_const_2[] = {
    makesym(functor__40_2),
    makefunctor(funct_const_0),
    makefunctor(funct_const_1),
  };
  static Const q funct_const_3[] = {
    makesym(functor_functor_1),
    makefunctor(funct_const_2),
  };
  static Const q funct_const_4[] = {
    makesym(functor_functor_3),
    makesym(atom_dummy),
    makesym(atom___),
    makesym(atom_builtin),
  };
  q a0, a1, a2, a3, a4, a5, a6, a7, a8;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, main_2_top);
    case_pred(1, check__call_6_top);
    case_pred(2, check__clauses_5_top);
    case_pred(3, add__go_6_top);
    case_pred(4, check__builtin_4_top);
    case_pred(5, check__builtin1_6_top);
    case_pred(6, add__go1_8_top);
    case_pred(7, recursive__bodys_6_top);
    case_pred(8, recursive__bodys1_6_top);
    case_pred(9, recursive__body_9_top);
    case_pred(10, make__nextgoal_8_top);
    case_pred(11, remove__no__go_2_top);
    case_pred(12, remove__no__go__clauses_3_top);
    case_pred(13, remove__no__go__clause_2_top);
    last_case_pred(14, remove__no__go__bodys_6_top);
  }

 main_2_top: {
  q x0;
  qp = qp->next;
 main_2_clear_reason:
  reasonp = reasons;
 main_2_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xremove__no__go_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  a1 = makesym(atom_main);
  a2 = makeint(0L);
  a3 = makesym(atom___);
  a4 = a0;
  a5 = x0;
  a0 = makesym(atom_main);
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  execute(check__call_6_0);
  goto check__call_6_ext_interrupt;
 main_2_ext_interrupt:
  reasonp = 0l;
 main_2_interrupt:
  goto interrupt_2;
 }

 check__call_6_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 check__call_6_clear_reason:
  reasonp = reasons;
 check__call_6_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xcheck__clauses_5);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a3;
  allocp[5] = a4;
  allocp[6] = a5;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_parse__uty_xget__def__clauses_5);
  allocp[9] = a0;
  allocp[10] = a1;
  allocp[11] = a2;
  allocp[12] = x0;
  allocp[13] = a4;
  qp = (struct goalrec*)&allocp[7];
  allocp += 14;
  proceed();
 check__call_6_ext_interrupt:
  reasonp = 0l;
 check__call_6_interrupt:
  toppred = &predicate_direct__call_xcheck__call_6;
  goto interrupt_6;
 }

 check__clauses_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 check__clauses_5_clear_reason:
  reasonp = reasons;
 check__clauses_5_0:
 check__clauses_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 check__clauses_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_cl_2)) goto check__clauses_5_interrupt;
  x1 = arg(x0, 1);
 check__clauses_5_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_clause_6)) goto check__clauses_5_interrupt;
  x2 = arg(x1, 2);
 check__clauses_5_4:
  if (isref(x2)) goto check__clauses_5_5;
  gblt_pfunctor(x2,x3,check__clauses_5_interrupt);
  gblt_arity(x2,x4,check__clauses_5_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xcheck__clauses_5);
  x5 = cdr_of(a0);
  allocp[2] = x5;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x6 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_direct__call_xrecursive__bodys_6);
  allocp[9] = x7 = makeref(&allocp[9]);
  allocp[10] = x8 = makeref(&allocp[10]);
  allocp[11] = a1;
  allocp[12] = a2;
  allocp[13] = x9 = makeref(&allocp[13]);
  allocp[14] = x6;
  allocp[15] = (q)(struct goalrec*)&allocp[7];
  allocp[16] = (q)(&predicate_parse__uty_xupdate__clause_5);
  allocp[17] = a1;
  x10 = arg(x0, 0);
  allocp[18] = x10;
  allocp[19] = x11 = makeref(&allocp[19]);
  allocp[20] = a3;
  allocp[21] = x9;
  allocp[22] = (q)(struct goalrec*)&allocp[15];
  allocp[23] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[24] = makeint(3L);
  allocp[25] = x1;
  allocp[26] = x8;
  allocp[27] = x11;
  a0 = x4;
  a3 = a1;
  a4 = a2;
  a5 = x7;
  a2 = x8;
  a1 = x2;
  qp = (struct goalrec*)&allocp[22];
  allocp += 28;
  execute(add__go_6_0);
  goto add__go_6_ext_interrupt;
 check__clauses_5_5:
  deref_and_jump(x2,check__clauses_5_4);
  *reasonp++ =  x2;
  goto check__clauses_5_interrupt;
 case VARREF:
  deref_and_jump(x1,check__clauses_5_3);
  *reasonp++ =  x1;
  goto check__clauses_5_interrupt;
  };
  goto check__clauses_5_interrupt;
 case VARREF:
  deref_and_jump(x0,check__clauses_5_2);
  *reasonp++ =  x0;
  goto check__clauses_5_interrupt;
  };
  goto check__clauses_5_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto check__clauses_5_interrupt;
  unify(a4, a3);
  proceed();
 case VARREF:
  deref_and_jump(a0,check__clauses_5_1);
  *reasonp++ =  a0;
  goto check__clauses_5_interrupt;
  };
  goto check__clauses_5_interrupt;
 check__clauses_5_ext_interrupt:
  reasonp = 0l;
 check__clauses_5_interrupt:
  goto interrupt_5;
 }

 add__go_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 add__go_6_clear_reason:
  reasonp = reasons;
 add__go_6_0:
 add__go_6_1:
  if (!isint(a0)) goto add__go_6_3;
  gblt_greater(a0,makeint(0L),add__go_6_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xadd__go1_8);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a0;
  allocp[6] = a1;
  allocp[7] = a2;
  allocp[8] = a4;
  allocp[9] = a5;
  allocp[10] = makesym(functor_options_2);
  allocp[11] = x4 = makeref(&allocp[11]);
  allocp[12] = x1;
  x3 = makefunctor(&allocp[10]);
  allocp[13] = (q)(struct goalrec*)&allocp[0];
  allocp[14] = (q)(&predicate_parse__uty_xdecode__goal_4);
  allocp[15] = x5 = makeref(&allocp[15]);
  allocp[16] = x2;
  allocp[17] = x6 = makeref(&allocp[17]);
  allocp[18] = x3;
  allocp[19] = (q)(struct goalrec*)&allocp[13];
  allocp[20] = (q)(&predicate_functor__table_xarg_3);
  allocp[21] = a0;
  allocp[22] = a1;
  allocp[23] = x5;
  x7 = a3;
  x8 = a0;
  a2 = a1;
  a3 = x0;
  a1 = x8;
  a0 = x7;
  qp = (struct goalrec*)&allocp[19];
  allocp += 24;
  execute(check__builtin_4_0);
  goto check__builtin_4_ext_interrupt;
 add__go_6_2:
  if (a0 != makeint(0L)) goto add__go_6_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xadd__go1_8);
  allocp[2] = x9 = makeref(&allocp[2]);
  allocp[3] = makesym(atom___);
  allocp[4] = makesym(atom___);
  allocp[5] = makeint(0L);
  allocp[6] = a1;
  allocp[7] = a2;
  allocp[8] = a4;
  allocp[9] = a5;
  x10 = a3;
  x11 = a0;
  a2 = a1;
  a3 = x9;
  a1 = x11;
  a0 = x10;
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  execute(check__builtin_4_0);
  goto check__builtin_4_ext_interrupt;
 add__go_6_3:
  if (!isref(a0)) goto add__go_6_interrupt;
  deref_and_jump(a0,add__go_6_1);
  *reasonp++ =  a0;
  goto add__go_6_interrupt;
 add__go_6_ext_interrupt:
  reasonp = 0l;
 add__go_6_interrupt:
  toppred = &predicate_direct__call_xadd__go_6;
  goto interrupt_6;
 }

 check__builtin_4_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 check__builtin_4_clear_reason:
  reasonp = reasons;
 check__builtin_4_0:
 check__builtin_4_1:
  if (!isint(a1)) goto check__builtin_4_3;
  gblt_greater(a1,makeint(0L),check__builtin_4_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xcheck__builtin1_6);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a1;
  allocp[6] = a2;
  allocp[7] = a3;
  allocp[8] = makesym(functor_attrs_2);
  allocp[9] = x3 = makeref(&allocp[9]);
  allocp[10] = x0;
  x2 = makefunctor(&allocp[8]);
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_parse__uty_xdecode__goalcall_6);
  allocp[13] = a0;
  allocp[14] = x1;
  allocp[15] = x4 = makeref(&allocp[15]);
  allocp[16] = x5 = makeref(&allocp[16]);
  allocp[17] = x6 = makeref(&allocp[17]);
  allocp[18] = x2;
  allocp[19] = (q)(struct goalrec*)&allocp[11];
  allocp[20] = (q)(&predicate_functor__table_xarg_3);
  allocp[21] = a1;
  allocp[22] = a2;
  allocp[23] = x4;
  qp = (struct goalrec*)&allocp[19];
  allocp += 24;
  proceed();
 check__builtin_4_2:
  if (a1 != makeint(0L)) goto check__builtin_4_interrupt;
  unify_value(a3, makesym(atom_yes));
  proceed();
 check__builtin_4_3:
  if (!isref(a1)) goto check__builtin_4_interrupt;
  deref_and_jump(a1,check__builtin_4_1);
  *reasonp++ =  a1;
  goto check__builtin_4_interrupt;
 check__builtin_4_ext_interrupt:
  reasonp = 0l;
 check__builtin_4_interrupt:
  toppred = &predicate_direct__call_xcheck__builtin_4;
  goto interrupt_4;
 }

 check__builtin1_6_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 check__builtin1_6_clear_reason:
  reasonp = reasons;
 check__builtin1_6_0:
 check__builtin1_6_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto check__builtin1_6_6;
  switch (symval(a0)) {
 case symval(makesym(atom_userdef)):
  unify_value(a5, makesym(atom_no));
  proceed();
 case symval(makesym(atom_builtin)):
 check__builtin1_6_2:
  if (isref(a1)) goto check__builtin1_6_5;
 check__builtin1_6_3:
  if (isref(a1)) goto check__builtin1_6_4;
  if_not_equal(a1, a2, check__builtin1_6_6);
  bblt_sub_no_check_y(a3,makeint(1L),x0);
  a0 = a1;
  a1 = x0;
  a2 = a4;
  a3 = a5;
  execute(check__builtin_4_clear_reason);
  goto check__builtin_4_ext_interrupt;
 check__builtin1_6_4:
  deref_and_jump(a1,check__builtin1_6_3);
  *reasonp++ =  a1;
  goto check__builtin1_6_6;
 check__builtin1_6_5:
  deref_and_jump(a1,check__builtin1_6_2);
  *reasonp++ =  a1;
  goto check__builtin1_6_6;
  };
  goto check__builtin1_6_6;
 case VARREF:
  deref_and_jump(a0,check__builtin1_6_1);
  *reasonp++ =  a0;
  goto check__builtin1_6_6;
  };
  goto check__builtin1_6_6;
 check__builtin1_6_6:
  otherwise(check__builtin1_6_interrupt);
 check__builtin1_6_7:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_builtin)) goto check__builtin1_6_interrupt;
  unify_value(a5, makesym(atom_no));
  proceed();
 case VARREF:
  deref_and_jump(a0,check__builtin1_6_7);
  *reasonp++ =  a0;
  goto check__builtin1_6_interrupt;
  };
  goto check__builtin1_6_interrupt;
 check__builtin1_6_ext_interrupt:
  reasonp = 0l;
 check__builtin1_6_interrupt:
  goto interrupt_6;
 }

 add__go1_8_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 add__go1_8_clear_reason:
  reasonp = reasons;
 add__go1_8_0:
 add__go1_8_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_yes)) goto add__go1_8_4;
 add__go1_8_2:
  switch (ptagof(a6)) {
 case ATOMIC:
  if (a6 != makesym(atom___)) goto add__go1_8_4;
 add__go1_8_3:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_dummy)) goto add__go1_8_4;
  unify_value(a7, makesym(atom_no));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = a3;
  allocp[3] = a4;
  allocp[4] = makefunctor(funct_const_3);
  allocp[5] = a5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  proceed();
 case VARREF:
  deref_and_jump(a2,add__go1_8_3);
  *reasonp++ =  a2;
  goto add__go1_8_4;
  };
  goto add__go1_8_4;
 case VARREF:
  deref_and_jump(a6,add__go1_8_2);
  *reasonp++ =  a6;
  goto add__go1_8_4;
  };
  goto add__go1_8_4;
 case VARREF:
  deref_and_jump(a0,add__go1_8_1);
  *reasonp++ =  a0;
  goto add__go1_8_4;
  };
  goto add__go1_8_4;
 add__go1_8_4:
  otherwise(add__go1_8_interrupt);
 add__go1_8_5:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_yes)) goto add__go1_8_22;
 add__go1_8_6:
  switch (ptagof(a6)) {
 case ATOMIC:
  if (a6 != makesym(atom___)) goto add__go1_8_22;
  bblt_add_no_check_y(a3,makeint(1L),x0);
  unify_value(a7, makesym(atom_no));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor_xinsert__arg_4);
  allocp[2] = x0;
  allocp[3] = a4;
  allocp[4] = makefunctor(funct_const_3);
  allocp[5] = a5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  proceed();
 case FUNCTOR:
  if (functor_of(a6) != makesym(functor_go_3)) goto add__go1_8_22;
 add__go1_8_7:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_dummy)) goto add__go1_8_22;
 add__go1_8_8:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_functor_1)) goto add__go1_8_22;
  x0 = arg(a1, 0);
 add__go1_8_9:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_go_3)) goto add__go1_8_22;
  x1 = arg(x0, 0);
 add__go1_8_10:
  if (isref(x1)) goto add__go1_8_21;
 add__go1_8_11:
  if (isref(x1)) goto add__go1_8_20;
  x2 = arg(a6, 0);
  if_not_equal(x1, x2, add__go1_8_22);
  x3 = arg(x0, 1);
 add__go1_8_12:
  if (isref(x3)) goto add__go1_8_19;
 add__go1_8_13:
  if (isref(x3)) goto add__go1_8_18;
  x4 = arg(a6, 1);
  if_not_equal(x3, x4, add__go1_8_22);
  x5 = arg(x0, 2);
 add__go1_8_14:
  if (isref(x5)) goto add__go1_8_17;
 add__go1_8_15:
  if (isref(x5)) goto add__go1_8_16;
  x6 = arg(a6, 2);
  if_not_equal(x5, x6, add__go1_8_22);
  unify(a5, a4);
  unify_value(a7, makesym(atom_no));
  proceed();
 add__go1_8_16:
  deref_and_jump(x5,add__go1_8_15);
  *reasonp++ =  x5;
  goto add__go1_8_22;
 add__go1_8_17:
  deref_and_jump(x5,add__go1_8_14);
  *reasonp++ =  x5;
  goto add__go1_8_22;
 add__go1_8_18:
  deref_and_jump(x3,add__go1_8_13);
  *reasonp++ =  x3;
  goto add__go1_8_22;
 add__go1_8_19:
  deref_and_jump(x3,add__go1_8_12);
  *reasonp++ =  x3;
  goto add__go1_8_22;
 add__go1_8_20:
  deref_and_jump(x1,add__go1_8_11);
  *reasonp++ =  x1;
  goto add__go1_8_22;
 add__go1_8_21:
  deref_and_jump(x1,add__go1_8_10);
  *reasonp++ =  x1;
  goto add__go1_8_22;
 case VARREF:
  deref_and_jump(x0,add__go1_8_9);
  *reasonp++ =  x0;
  goto add__go1_8_22;
  };
  goto add__go1_8_22;
 case VARREF:
  deref_and_jump(a1,add__go1_8_8);
  *reasonp++ =  a1;
  goto add__go1_8_22;
  };
  goto add__go1_8_22;
 case VARREF:
  deref_and_jump(a2,add__go1_8_7);
  *reasonp++ =  a2;
  goto add__go1_8_22;
  };
  goto add__go1_8_22;
 case VARREF:
  deref_and_jump(a6,add__go1_8_6);
  *reasonp++ =  a6;
  goto add__go1_8_22;
  };
  goto add__go1_8_22;
 case VARREF:
  deref_and_jump(a0,add__go1_8_5);
  *reasonp++ =  a0;
  goto add__go1_8_22;
  };
  goto add__go1_8_22;
 add__go1_8_22:
  otherwise(add__go1_8_interrupt);
 add__go1_8_23:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_yes)) goto add__go1_8_26;
 add__go1_8_24:
  switch (ptagof(a6)) {
 case FUNCTOR:
  if (functor_of(a6) != makesym(functor_go_3)) goto add__go1_8_26;
 add__go1_8_25:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_dummy)) goto add__go1_8_26;
  unify_value(a7, makesym(atom_no));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = a3;
  allocp[3] = a4;
  allocp[4] = makefunctor(funct_const_3);
  allocp[5] = a5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  proceed();
 case VARREF:
  deref_and_jump(a2,add__go1_8_25);
  *reasonp++ =  a2;
  goto add__go1_8_26;
  };
  goto add__go1_8_26;
 case VARREF:
  deref_and_jump(a6,add__go1_8_24);
  *reasonp++ =  a6;
  goto add__go1_8_26;
  };
  goto add__go1_8_26;
 case VARREF:
  deref_and_jump(a0,add__go1_8_23);
  *reasonp++ =  a0;
  goto add__go1_8_26;
  };
  goto add__go1_8_26;
 add__go1_8_26:
  otherwise(add__go1_8_interrupt);
 add__go1_8_27:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto add__go1_8_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
 add__go1_8_28:
  switch (ptagof(a6)) {
 case FUNCTOR:
  if (functor_of(a6) != makesym(functor_go_3)) goto add__go1_8_interrupt;
  bblt_add_no_check_y(a3,makeint(1L),x0);
  unify_value(a7, makesym(atom_no));
  allocp[0] = makesym(functor_functor_1);
  allocp[1] = a6;
  x1 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__40_2);
  allocp[3] = makefunctor(funct_const_4);
  allocp[4] = x1;
  x2 = makefunctor(&allocp[2]);
  allocp[5] = makesym(functor_functor_1);
  allocp[6] = x2;
  x3 = makefunctor(&allocp[5]);
  allocp[7] = (q)qp;
  allocp[8] = (q)(&predicate_functor_xinsert__arg_4);
  allocp[9] = x0;
  allocp[10] = a4;
  allocp[11] = x3;
  allocp[12] = a5;
  qp = (struct goalrec*)&allocp[7];
  allocp += 13;
  proceed();
 case VARREF:
  deref_and_jump(a6,add__go1_8_28);
  *reasonp++ =  a6;
  goto add__go1_8_interrupt;
  };
  goto add__go1_8_interrupt;
 case symval(makesym(atom_no)):
  unify(a5, a4);
  unify_value(a7, makesym(atom_yes));
  proceed();
  };
  goto add__go1_8_interrupt;
 case VARREF:
  deref_and_jump(a0,add__go1_8_27);
  *reasonp++ =  a0;
  goto add__go1_8_interrupt;
  };
  goto add__go1_8_interrupt;
 add__go1_8_ext_interrupt:
  reasonp = 0l;
 add__go1_8_interrupt:
  goto interrupt_8;
 }

 recursive__bodys_6_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 recursive__bodys_6_clear_reason:
  reasonp = reasons;
 recursive__bodys_6_0:
 recursive__bodys_6_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto recursive__bodys_6_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_no)):
  unify(a5, a4);
  proceed();
 case symval(makesym(atom_yes)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xrecursive__bodys1_6);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[10] = a1;
  allocp[11] = x1 = makeref(&allocp[11]);
  allocp[12] = x0;
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  proceed();
  };
  goto recursive__bodys_6_interrupt;
 case VARREF:
  deref_and_jump(a0,recursive__bodys_6_1);
  *reasonp++ =  a0;
  goto recursive__bodys_6_interrupt;
  };
  goto recursive__bodys_6_interrupt;
 recursive__bodys_6_ext_interrupt:
  reasonp = 0l;
 recursive__bodys_6_interrupt:
  goto interrupt_6;
 }

 recursive__bodys1_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 recursive__bodys1_6_clear_reason:
  reasonp = reasons;
 recursive__bodys1_6_0:
 recursive__bodys1_6_1:
  if (!isint(a0)) goto recursive__bodys1_6_3;
  gblt_greater(a0,makeint(0L),recursive__bodys1_6_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xrecursive__bodys1_6);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[10] = a0;
  allocp[11] = makeint(1L);
  allocp[12] = x0;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_direct__call_xmake__nextgoal_8);
  allocp[15] = a2;
  allocp[16] = x3 = makeref(&allocp[16]);
  allocp[17] = x4 = makeref(&allocp[17]);
  allocp[18] = x5 = makeref(&allocp[18]);
  allocp[19] = x6 = makeref(&allocp[19]);
  allocp[20] = x7 = makeref(&allocp[20]);
  allocp[21] = a3;
  allocp[22] = x1;
  allocp[23] = (q)(struct goalrec*)&allocp[13];
  allocp[24] = (q)(&predicate_direct__call_xrecursive__body_9);
  allocp[25] = x7;
  allocp[26] = x6;
  allocp[27] = a2;
  allocp[28] = x3;
  allocp[29] = x4;
  allocp[30] = x5;
  allocp[31] = a3;
  allocp[32] = a4;
  allocp[33] = x2;
  allocp[34] = (q)(struct goalrec*)&allocp[23];
  allocp[35] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[36] = x8 = makeref(&allocp[36]);
  allocp[37] = x4;
  allocp[38] = x5;
  allocp[39] = makesym(functor_attrs_2);
  allocp[40] = x10 = makeref(&allocp[40]);
  allocp[41] = x7;
  x9 = makefunctor(&allocp[39]);
  allocp[42] = (q)(struct goalrec*)&allocp[34];
  allocp[43] = (q)(&predicate_parse__uty_xdecode__goalcall_6);
  allocp[44] = a2;
  allocp[45] = x3;
  allocp[46] = x11 = makeref(&allocp[46]);
  allocp[47] = x8;
  allocp[48] = x6;
  allocp[49] = x9;
  allocp[50] = (q)(struct goalrec*)&allocp[42];
  allocp[51] = (q)(&predicate_functor__table_xarg_3);
  allocp[52] = a0;
  allocp[53] = a1;
  allocp[54] = x11;
  qp = (struct goalrec*)&allocp[50];
  allocp += 55;
  proceed();
 recursive__bodys1_6_2:
  if (a0 != makeint(0L)) goto recursive__bodys1_6_interrupt;
  unify(a5, a4);
  proceed();
 recursive__bodys1_6_3:
  if (!isref(a0)) goto recursive__bodys1_6_interrupt;
  deref_and_jump(a0,recursive__bodys1_6_1);
  *reasonp++ =  a0;
  goto recursive__bodys1_6_interrupt;
 recursive__bodys1_6_ext_interrupt:
  reasonp = 0l;
 recursive__bodys1_6_interrupt:
  goto interrupt_6;
 }

 recursive__body_9_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 recursive__body_9_clear_reason:
  reasonp = reasons;
 recursive__body_9_0:
 recursive__body_9_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto recursive__body_9_4;
  switch (symval(a0)) {
 case symval(makesym(atom_builtin)):
  unify(a8, a7);
  proceed();
 case symval(makesym(atom_userdef)):
 recursive__body_9_2:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_atom_1)) goto recursive__body_9_4;
  x0 = arg(a1, 0);
 recursive__body_9_3:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_loop)) goto recursive__body_9_4;
  unify(a8, a7);
  proceed();
 case VARREF:
  deref_and_jump(x0,recursive__body_9_3);
  *reasonp++ =  x0;
  goto recursive__body_9_4;
  };
  goto recursive__body_9_4;
 case VARREF:
  deref_and_jump(a1,recursive__body_9_2);
  *reasonp++ =  a1;
  goto recursive__body_9_4;
  };
  goto recursive__body_9_4;
  };
  goto recursive__body_9_4;
 case VARREF:
  deref_and_jump(a0,recursive__body_9_1);
  *reasonp++ =  a0;
  goto recursive__body_9_4;
  };
  goto recursive__body_9_4;
 recursive__body_9_4:
  otherwise(recursive__body_9_interrupt);
 recursive__body_9_5:
  if (isref(a2)) goto recursive__body_9_8;
 recursive__body_9_6:
  if (isref(a2)) goto recursive__body_9_7;
  if_not_equal(a2, a3, recursive__body_9_9);
  a0 = a3;
  a1 = a4;
  a2 = a5;
  a3 = a6;
  a4 = a7;
  a5 = a8;
  execute(check__call_6_clear_reason);
  goto check__call_6_ext_interrupt;
 recursive__body_9_7:
  deref_and_jump(a2,recursive__body_9_6);
  *reasonp++ =  a2;
  goto recursive__body_9_9;
 recursive__body_9_8:
  deref_and_jump(a2,recursive__body_9_5);
  *reasonp++ =  a2;
  goto recursive__body_9_9;
 recursive__body_9_9:
  otherwise(recursive__body_9_interrupt);
  a0 = a3;
  a1 = a4;
  a2 = a5;
  a3 = makesym(atom___);
  a4 = a7;
  a5 = a8;
  execute(check__call_6_0);
  goto check__call_6_ext_interrupt;
 recursive__body_9_ext_interrupt:
  reasonp = 0l;
 recursive__body_9_interrupt:
  goto interrupt_9;
 }

 make__nextgoal_8_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 make__nextgoal_8_clear_reason:
  reasonp = reasons;
 make__nextgoal_8_0:
 make__nextgoal_8_1:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (a5 != makesym(atom_userdef)) goto make__nextgoal_8_17;
 make__nextgoal_8_2:
  if (isref(a0)) goto make__nextgoal_8_16;
 make__nextgoal_8_3:
  if (isref(a0)) goto make__nextgoal_8_15;
  if_not_equal(a0, a1, make__nextgoal_8_5);
 make__nextgoal_8_4:
  switch (ptagof(a4)) {
 case ATOMIC:
  if (a4 != makesym(atom___)) goto make__nextgoal_8_5;
  allocp[0] = makesym(functor_go_3);
  allocp[1] = a2;
  allocp[2] = a3;
  allocp[3] = makesym(atom_nonloop);
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a7, x0);
  proceed();
 case VARREF:
  deref_and_jump(a4,make__nextgoal_8_4);
  *reasonp++ =  a4;
  goto make__nextgoal_8_5;
  };
  goto make__nextgoal_8_5;
 make__nextgoal_8_5:
 make__nextgoal_8_6:
  if (isref(a0)) goto make__nextgoal_8_14;
  if_not_equal(a0, a1, make__nextgoal_8_9);
 make__nextgoal_8_7:
  switch (ptagof(a4)) {
 case FUNCTOR:
  if (functor_of(a4) != makesym(functor_atom_1)) goto make__nextgoal_8_9;
  x0 = arg(a4, 0);
 make__nextgoal_8_8:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_shared)) goto make__nextgoal_8_9;
  allocp[0] = makesym(functor_go_3);
  allocp[1] = a2;
  allocp[2] = a3;
  allocp[3] = makesym(atom_nonloop);
  x1 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a7, x1);
  proceed();
 case VARREF:
  deref_and_jump(x0,make__nextgoal_8_8);
  *reasonp++ =  x0;
  goto make__nextgoal_8_9;
  };
  goto make__nextgoal_8_9;
 case VARREF:
  deref_and_jump(a4,make__nextgoal_8_7);
  *reasonp++ =  a4;
  goto make__nextgoal_8_9;
  };
  goto make__nextgoal_8_9;
 make__nextgoal_8_9:
 make__nextgoal_8_10:
  if (isref(a0)) goto make__nextgoal_8_13;
  if_not_equal(a0, a1, make__nextgoal_8_17);
 make__nextgoal_8_11:
  switch (ptagof(a4)) {
 case FUNCTOR:
  if (functor_of(a4) != makesym(functor_atom_1)) goto make__nextgoal_8_17;
  x0 = arg(a4, 0);
 make__nextgoal_8_12:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_loop)) goto make__nextgoal_8_17;
  allocp[0] = makesym(functor_go_3);
  allocp[1] = a2;
  allocp[2] = a3;
  allocp[3] = makesym(atom_loop);
  x1 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a7, x1);
  proceed();
 case VARREF:
  deref_and_jump(x0,make__nextgoal_8_12);
  *reasonp++ =  x0;
  goto make__nextgoal_8_17;
  };
  goto make__nextgoal_8_17;
 case VARREF:
  deref_and_jump(a4,make__nextgoal_8_11);
  *reasonp++ =  a4;
  goto make__nextgoal_8_17;
  };
  goto make__nextgoal_8_17;
 make__nextgoal_8_13:
  deref_and_jump(a0,make__nextgoal_8_10);
  *reasonp++ =  a0;
  goto make__nextgoal_8_17;
 make__nextgoal_8_14:
  deref_and_jump(a0,make__nextgoal_8_6);
  *reasonp++ =  a0;
  goto make__nextgoal_8_17;
 make__nextgoal_8_15:
  deref_and_jump(a0,make__nextgoal_8_3);
  *reasonp++ =  a0;
  goto make__nextgoal_8_17;
 make__nextgoal_8_16:
  deref_and_jump(a0,make__nextgoal_8_2);
  *reasonp++ =  a0;
  goto make__nextgoal_8_17;
 case VARREF:
  deref_and_jump(a5,make__nextgoal_8_1);
  *reasonp++ =  a5;
  goto make__nextgoal_8_17;
  };
  goto make__nextgoal_8_17;
 make__nextgoal_8_17:
  otherwise(make__nextgoal_8_interrupt);
  unify_value(a7, makesym(atom___));
  proceed();
 make__nextgoal_8_ext_interrupt:
  reasonp = 0l;
 make__nextgoal_8_interrupt:
  goto interrupt_8;
 }

 remove__no__go_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  qp = qp->next;
 remove__no__go_2_clear_reason:
  reasonp = reasons;
 remove__no__go_2_0:
 remove__no__go_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 remove__no__go_2_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto remove__no__go_2_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xremove__no__go_2);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = makesym(functor_module_2);
  allocp[5] = arg(x0, 0);
  allocp[6] = x4 = makeref(&allocp[6]);
  x3 = makefunctor(&allocp[4]);
  allocp[7] = x2;
  allocp[8] = x3;
  x5 = makecons(&allocp[7]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 9;
  unify_value(a1, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xremove__no__go__clauses_3);
  allocp[2] = x6 = makeref(&allocp[2]);
  x7 = arg(x0, 1);
  allocp[3] = x7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[7] = x7;
  allocp[8] = x8 = makeref(&allocp[8]);
  allocp[9] = x6;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(x0,remove__no__go_2_2);
  *reasonp++ =  x0;
  goto remove__no__go_2_interrupt;
  };
  goto remove__no__go_2_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto remove__no__go_2_interrupt;
  unify_value(a1, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a0,remove__no__go_2_1);
  *reasonp++ =  a0;
  goto remove__no__go_2_interrupt;
  };
  goto remove__no__go_2_interrupt;
 remove__no__go_2_ext_interrupt:
  reasonp = 0l;
 remove__no__go_2_interrupt:
  goto interrupt_2;
 }

 remove__no__go__clauses_3_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  qp = qp->next;
 remove__no__go__clauses_3_clear_reason:
  reasonp = reasons;
 remove__no__go__clauses_3_0:
 remove__no__go__clauses_3_1:
  if (!isint(a0)) goto remove__no__go__clauses_3_3;
  gblt_greater(a0,makeint(0L),remove__no__go__clauses_3_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xremove__no__go__clauses_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[7] = a0;
  allocp[8] = makeint(1L);
  allocp[9] = x0;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[12] = a0;
  allocp[13] = a1;
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = (q)(struct goalrec*)&allocp[10];
  allocp[17] = (q)(&predicate_direct__call_xremove__no__go__clause_2);
  allocp[18] = x3 = makeref(&allocp[18]);
  allocp[19] = x2;
  allocp[20] = (q)(struct goalrec*)&allocp[16];
  allocp[21] = (q)(&predicate_functor__table_xarg_3);
  allocp[22] = a0;
  allocp[23] = a1;
  allocp[24] = x3;
  qp = (struct goalrec*)&allocp[20];
  allocp += 25;
  proceed();
 remove__no__go__clauses_3_2:
  if (a0 != makeint(0L)) goto remove__no__go__clauses_3_interrupt;
  unify(a2, a1);
  proceed();
 remove__no__go__clauses_3_3:
  if (!isref(a0)) goto remove__no__go__clauses_3_interrupt;
  deref_and_jump(a0,remove__no__go__clauses_3_1);
  *reasonp++ =  a0;
  goto remove__no__go__clauses_3_interrupt;
 remove__no__go__clauses_3_ext_interrupt:
  reasonp = 0l;
 remove__no__go__clauses_3_interrupt:
  goto interrupt_3;
 }

 remove__no__go__clause_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  qp = qp->next;
 remove__no__go__clause_2_clear_reason:
  reasonp = reasons;
 remove__no__go__clause_2_0:
 remove__no__go__clause_2_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_clause_6)) goto remove__no__go__clause_2_6;
  x0 = arg(a0, 2);
 remove__no__go__clause_2_2:
  if (isref(x0)) goto remove__no__go__clause_2_5;
  gblt_pfunctor(x0,x1,remove__no__go__clause_2_6);
  gblt_arity(x0,x2,remove__no__go__clause_2_6);
  gblt_greater(x2,makeint(0L),remove__no__go__clause_2_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = makeint(3L);
  allocp[3] = a0;
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = a1;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_direct__call_xremove__no__go__bodys_6);
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = x5 = makeref(&allocp[9]);
  allocp[10] = x6 = makeref(&allocp[10]);
  allocp[11] = x2;
  allocp[12] = x0;
  allocp[13] = x3;
  allocp[14] = (q)(struct goalrec*)&allocp[6];
  allocp[15] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[16] = x7 = makeref(&allocp[16]);
  allocp[17] = x5;
  allocp[18] = x6;
  allocp[19] = makesym(functor_options_2);
  allocp[20] = x9 = makeref(&allocp[20]);
  allocp[21] = x4;
  x8 = makefunctor(&allocp[19]);
  allocp[22] = (q)(struct goalrec*)&allocp[14];
  allocp[23] = (q)(&predicate_parse__uty_xdecode__goal_4);
  allocp[24] = x10 = makeref(&allocp[24]);
  allocp[25] = x7;
  allocp[26] = x11 = makeref(&allocp[26]);
  allocp[27] = x8;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_functor__table_xarg_3);
  allocp[30] = x2;
  allocp[31] = x0;
  allocp[32] = x10;
  qp = (struct goalrec*)&allocp[28];
  allocp += 33;
  proceed();
 remove__no__go__clause_2_3:
 remove__no__go__clause_2_4:
  if (x2 != makeint(0L)) goto remove__no__go__clause_2_6;
  unify_value(a1, a0);
  proceed();
 remove__no__go__clause_2_5:
  deref_and_jump(x0,remove__no__go__clause_2_2);
  *reasonp++ =  x0;
  goto remove__no__go__clause_2_6;
 case VARREF:
  deref_and_jump(a0,remove__no__go__clause_2_1);
  *reasonp++ =  a0;
  goto remove__no__go__clause_2_6;
  };
  goto remove__no__go__clause_2_6;
 remove__no__go__clause_2_6:
  otherwise(remove__no__go__clause_2_interrupt);
  unify(a1, a0);
  proceed();
 remove__no__go__clause_2_ext_interrupt:
  reasonp = 0l;
 remove__no__go__clause_2_interrupt:
  goto interrupt_2;
 }

 remove__no__go__bodys_6_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 remove__no__go__bodys_6_clear_reason:
  reasonp = reasons;
 remove__no__go__bodys_6_0:
 remove__no__go__bodys_6_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_functor_1)) goto remove__no__go__bodys_6_4;
  x0 = arg(a0, 0);
 remove__no__go__bodys_6_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_no__go)) goto remove__no__go__bodys_6_4;
 remove__no__go__bodys_6_3:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_dummy)) goto remove__no__go__bodys_6_4;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor_xdelete__arg_3);
  allocp[2] = a3;
  allocp[3] = a4;
  allocp[4] = a5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case VARREF:
  deref_and_jump(a1,remove__no__go__bodys_6_3);
  *reasonp++ =  a1;
  goto remove__no__go__bodys_6_4;
  };
  goto remove__no__go__bodys_6_4;
 case VARREF:
  deref_and_jump(x0,remove__no__go__bodys_6_2);
  *reasonp++ =  x0;
  goto remove__no__go__bodys_6_4;
  };
  goto remove__no__go__bodys_6_4;
 case VARREF:
  deref_and_jump(a0,remove__no__go__bodys_6_1);
  *reasonp++ =  a0;
  goto remove__no__go__bodys_6_4;
  };
  goto remove__no__go__bodys_6_4;
 remove__no__go__bodys_6_4:
  otherwise(remove__no__go__bodys_6_interrupt);
  unify(a5, a4);
  proceed();
 remove__no__go__bodys_6_ext_interrupt:
  reasonp = 0l;
 remove__no__go__bodys_6_interrupt:
  goto interrupt_6;
 }
 interrupt_9:
  allocp[10] = a8;
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_direct__call);
}
