/* Compiled by KLIC compiler version 2.002 (Tue May 23 13:27:38 JST 1995) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"
extern q opt_trace_atom_value;
extern q opt_analyze_dependency;

module module_type();
Const struct predicate predicate_type_xget__arg__types_5 =
   { module_type, 0, 5 };
Const struct predicate predicate_type_xget__types_5 =
   { module_type, 1, 5 };
Const struct predicate predicate_type_xentry__new__aliasvar_14 =
   { module_type, 2, 14 };
Const struct predicate predicate_type_xentry__new__aliasvar1_16 =
   { module_type, 3, 16 };
Const struct predicate predicate_type_xentry__new__aliasvar__cycliccheck_10 =
   { module_type, 4, 10 };
Const struct predicate predicate_type_xentry__new__aliasvar__cycliccheck1_8 =
   { module_type, 5, 8 };
Const struct predicate predicate_type_xentry__new__aliasvar__cycliccheck2_9 =
   { module_type, 6, 9 };
Const struct predicate predicate_type_xentry__new__aliasvar__cycliccheck11_8 =
   { module_type, 7, 8 };
Const struct predicate predicate_type_xentry__new__aliasvar__check_9 =
   { module_type, 8, 9 };
Const struct predicate predicate_type_xentry__new__aliasvar__gen_13 =
   { module_type, 9, 13 };
Const struct predicate predicate_type_xentry__new__aliasvar__gen1_5 =
   { module_type, 10, 5 };
Const struct predicate predicate_type_xset__types_11 =
   { module_type, 11, 11 };
Const struct predicate predicate_type_xset__types_13 =
   { module_type, 12, 13 };
Const struct predicate predicate_type_xset__types1_13 =
   { module_type, 13, 13 };
Const struct predicate predicate_type_xentry__updated_10 =
   { module_type, 14, 10 };
Const struct predicate predicate_type_xclear__depgoals_2 =
   { module_type, 15, 2 };
Const struct predicate predicate_type_xand__types_4 =
   { module_type, 16, 4 };
Const struct predicate predicate_type_xand__types_5 =
   { module_type, 17, 5 };
Const struct predicate predicate_type_xand__types1_7 =
   { module_type, 18, 7 };
Const struct predicate predicate_type_xand__types__val_5 =
   { module_type, 19, 5 };
Const struct predicate predicate_type_xand__types__val1_6 =
   { module_type, 20, 6 };
Const struct predicate predicate_type_xand__types__val2_9 =
   { module_type, 21, 9 };
Const struct predicate predicate_type_xand__type__element_10 =
   { module_type, 22, 10 };
Const struct predicate predicate_type_xand__type__element__struct_14 =
   { module_type, 23, 14 };
Const struct predicate predicate_type_x_2C_2 =
   { module_type, 24, 2 };
Const struct predicate predicate_type_xand__type__element__struct1_13 =
   { module_type, 25, 13 };
Const struct predicate predicate_type_xand__type__element__args_8 =
   { module_type, 26, 8 };
Const struct predicate predicate_type_xand__type__element__argslist_8 =
   { module_type, 27, 8 };
Const struct predicate predicate_type_xmake__indirect__unify_4 =
   { module_type, 28, 4 };
Const struct predicate predicate_type_xmake__indirect__unify1_4 =
   { module_type, 29, 4 };
Const struct predicate predicate_type_xmake__indirect__unify2_4 =
   { module_type, 30, 4 };
Const struct predicate predicate_type_xmake__indirect__unify3_4 =
   { module_type, 31, 4 };
Const struct predicate predicate_type_xentry__indirect_3 =
   { module_type, 32, 3 };
Const struct predicate predicate_type_xmerge__ru_3 =
   { module_type, 33, 3 };
Const struct predicate predicate_type_xor__types_3 =
   { module_type, 34, 3 };
Const struct predicate predicate_type_xor__types1_3 =
   { module_type, 35, 3 };
Const struct predicate predicate_type_xor__types2_6 =
   { module_type, 36, 6 };
Const struct predicate predicate_type_xor__type__element_4 =
   { module_type, 37, 4 };
Const struct predicate predicate_type_xor__type__element__struct_8 =
   { module_type, 38, 8 };
Const struct predicate predicate_type_xor__type__element__struct1_7 =
   { module_type, 39, 7 };
Const struct predicate predicate_type_xor__type__element__args_4 =
   { module_type, 40, 4 };
Const struct predicate predicate_type_xor__type__element__argslist_4 =
   { module_type, 41, 4 };
Const struct predicate predicate_type_xor__type__element__vmode_3 =
   { module_type, 42, 3 };
Const struct predicate predicate_type_xsplit__types__var__val_3 =
   { module_type, 43, 3 };
Const struct predicate predicate_type_xmerge__atomic_4 =
   { module_type, 44, 4 };
Const struct predicate predicate_type_xvalue2types_7 =
   { module_type, 45, 7 };
Const struct predicate predicate_type_xvalue2types1_9 =
   { module_type, 46, 9 };
Const struct predicate predicate_type_xvalue2types__functor__arg_10 =
   { module_type, 47, 10 };
Const struct predicate predicate_type_xvalue2types__vector__arg_10 =
   { module_type, 48, 10 };
Const struct predicate predicate_type_xadd__indirect__deps_11 =
   { module_type, 49, 11 };
Const struct predicate predicate_type_xadd__dep__goals_3 =
   { module_type, 50, 3 };
Const struct predicate predicate_type_xadd__dep__goal_3 =
   { module_type, 51, 3 };
Const struct predicate predicate_type_xadd__dep__goal1_3 =
   { module_type, 52, 3 };
Const struct predicate predicate_type_xadd__i__goals_3 =
   { module_type, 53, 3 };
Const struct predicate predicate_type_xadd__i__goal_3 =
   { module_type, 54, 3 };
Const struct predicate predicate_type_xadd__i__goal1_3 =
   { module_type, 55, 3 };
Const struct predicate predicate_type_xset__ru_3 =
   { module_type, 56, 3 };
Const struct predicate predicate_type_xset__ru__args_4 =
   { module_type, 57, 4 };
Const struct predicate predicate_type_xtype2atom_2 =
   { module_type, 58, 2 };
Const struct predicate predicate_type_xtype2int_2 =
   { module_type, 59, 2 };
Const struct predicate predicate_type_xtype2list_2 =
   { module_type, 60, 2 };
Const struct predicate predicate_type_xtype2list1_2 =
   { module_type, 61, 2 };
Const struct predicate predicate_type_xtype2structtype_2 =
   { module_type, 62, 2 };
Const struct predicate predicate_type_xtype2structtype1_3 =
   { module_type, 63, 3 };
Const struct predicate predicate_type_xget__struct__arg__types_3 =
   { module_type, 64, 3 };
Const struct predicate predicate_type_xset__struct__arg__types_4 =
   { module_type, 65, 4 };
Const struct predicate predicate_type_xlisttype__val_3 =
   { module_type, 66, 3 };
Const struct predicate predicate_type_xlisttype__val1_4 =
   { module_type, 67, 4 };
Const struct predicate predicate_type_xlisttype__val2_4 =
   { module_type, 68, 4 };
Const struct predicate predicate_type_xlisttype__val__merge_3 =
   { module_type, 69, 3 };
Const struct predicate predicate_type_xlisttype__val__merge1_3 =
   { module_type, 70, 3 };
Const struct predicate predicate_type_xcheck__type__table_1 =
   { module_type, 71, 1 };
Const struct predicate predicate_type_xcheck__type__table__clauses_2 =
   { module_type, 72, 2 };
Const struct predicate predicate_type_xcheck__type__table__clauses1_4 =
   { module_type, 73, 4 };
Const struct predicate predicate_type_xcheck__type__table__clause_3 =
   { module_type, 74, 3 };
Const struct predicate predicate_type_xcheck__type__table__clause1_5 =
   { module_type, 75, 5 };
Const struct predicate predicate_type_xcheck__type__table__type_4 =
   { module_type, 76, 4 };
Const struct predicate predicate_type_xremove__types__deps_3 =
   { module_type, 77, 3 };
Const struct predicate predicate_type_xremove__types__deps_4 =
   { module_type, 78, 4 };
Const struct predicate predicate_type_xremove__type__deps_4 =
   { module_type, 79, 4 };
Const struct predicate predicate_type_xremove__type__args_5 =
   { module_type, 80, 5 };
Const struct predicate predicate_type_xget__loopdeps_2 =
   { module_type, 81, 2 };
Const struct predicate predicate_type_xget__loopdeps1_3 =
   { module_type, 82, 3 };
Const struct predicate predicate_type_xmake__types__loopdown_16 =
   { module_type, 83, 16 };
Const struct predicate predicate_type_xmake__type__loopdown_16 =
   { module_type, 84, 16 };
Const struct predicate predicate_type_xmake__type__loopdown__args_17 =
   { module_type, 85, 17 };
Const struct predicate predicate_type_xmake__types__loopup_9 =
   { module_type, 86, 9 };
Const struct predicate predicate_type_xmake__types__loopup1_9 =
   { module_type, 87, 9 };
Const struct predicate predicate_type_xmake__type__loopup_9 =
   { module_type, 88, 9 };
Const struct predicate predicate_type_xmake__type__loopup__struct_10 =
   { module_type, 89, 10 };
Const struct predicate predicate_type_xmerge__goals_3 =
   { module_type, 90, 3 };
Const struct predicate predicate_type_xmerge__goals__filter_3 =
   { module_type, 91, 3 };
Const struct predicate predicate_type_xmerge__loopgoals__filter_5 =
   { module_type, 92, 5 };
extern Const struct predicate predicate_print_xdata_1;
extern Const struct predicate predicate_print_xdatan_1;
extern Const struct predicate predicate_list_xappend_3;
extern Const struct predicate predicate_list_xor__unique_3;
extern Const struct predicate predicate_list_xdelete__elements_3;
extern Const struct predicate predicate_list_xdelete__incomplete__element_3;
extern Const struct predicate predicate_functor_xinsert__arg_4;
extern Const struct predicate predicate_mode_xreverse__mode_2;
extern Const struct predicate predicate_integer__arithmetics_xadd_3;
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_functor__table_xfunctor_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_xsetarg_4;
extern Const struct predicate predicate_uty_xcreate__functor_3;
extern Const struct predicate predicate_loop_xmake__loopdep_3;
declare_method_table_of(vector);

module module_type(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  static Const q cons_const_0[] = {
    NILATOM,
    makesym(atom__3F),
  };
  q a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  switch_on_pred() {
    case_pred(0, get__arg__types_5_top);
    case_pred(1, get__types_5_top);
    case_pred(2, entry__new__aliasvar_14_top);
    case_pred(3, entry__new__aliasvar1_16_top);
    case_pred(4, entry__new__aliasvar__cycliccheck_10_top);
    case_pred(5, entry__new__aliasvar__cycliccheck1_8_top);
    case_pred(6, entry__new__aliasvar__cycliccheck2_9_top);
    case_pred(7, entry__new__aliasvar__cycliccheck11_8_top);
    case_pred(8, entry__new__aliasvar__check_9_top);
    case_pred(9, entry__new__aliasvar__gen_13_top);
    case_pred(10, entry__new__aliasvar__gen1_5_top);
    case_pred(11, set__types_11_top);
    case_pred(12, set__types_13_top);
    case_pred(13, set__types1_13_top);
    case_pred(14, entry__updated_10_top);
    case_pred(15, clear__depgoals_2_top);
    case_pred(16, and__types_4_top);
    case_pred(17, and__types_5_top);
    case_pred(18, and__types1_7_top);
    case_pred(19, and__types__val_5_top);
    case_pred(20, and__types__val1_6_top);
    case_pred(21, and__types__val2_9_top);
    case_pred(22, and__type__element_10_top);
    case_pred(23, and__type__element__struct_14_top);
    case_pred(24, _2C_2_top);
    case_pred(25, and__type__element__struct1_13_top);
    case_pred(26, and__type__element__args_8_top);
    case_pred(27, and__type__element__argslist_8_top);
    case_pred(28, make__indirect__unify_4_top);
    case_pred(29, make__indirect__unify1_4_top);
    case_pred(30, make__indirect__unify2_4_top);
    case_pred(31, make__indirect__unify3_4_top);
    case_pred(32, entry__indirect_3_top);
    case_pred(33, merge__ru_3_top);
    case_pred(34, or__types_3_top);
    case_pred(35, or__types1_3_top);
    case_pred(36, or__types2_6_top);
    case_pred(37, or__type__element_4_top);
    case_pred(38, or__type__element__struct_8_top);
    case_pred(39, or__type__element__struct1_7_top);
    case_pred(40, or__type__element__args_4_top);
    case_pred(41, or__type__element__argslist_4_top);
    case_pred(42, or__type__element__vmode_3_top);
    case_pred(43, split__types__var__val_3_top);
    case_pred(44, merge__atomic_4_top);
    case_pred(45, value2types_7_top);
    case_pred(46, value2types1_9_top);
    case_pred(47, value2types__functor__arg_10_top);
    case_pred(48, value2types__vector__arg_10_top);
    case_pred(49, add__indirect__deps_11_top);
    case_pred(50, add__dep__goals_3_top);
    case_pred(51, add__dep__goal_3_top);
    case_pred(52, add__dep__goal1_3_top);
    case_pred(53, add__i__goals_3_top);
    case_pred(54, add__i__goal_3_top);
    case_pred(55, add__i__goal1_3_top);
    case_pred(56, set__ru_3_top);
    case_pred(57, set__ru__args_4_top);
    case_pred(58, type2atom_2_top);
    case_pred(59, type2int_2_top);
    case_pred(60, type2list_2_top);
    case_pred(61, type2list1_2_top);
    case_pred(62, type2structtype_2_top);
    case_pred(63, type2structtype1_3_top);
    case_pred(64, get__struct__arg__types_3_top);
    case_pred(65, set__struct__arg__types_4_top);
    case_pred(66, listtype__val_3_top);
    case_pred(67, listtype__val1_4_top);
    case_pred(68, listtype__val2_4_top);
    case_pred(69, listtype__val__merge_3_top);
    case_pred(70, listtype__val__merge1_3_top);
    case_pred(71, check__type__table_1_top);
    case_pred(72, check__type__table__clauses_2_top);
    case_pred(73, check__type__table__clauses1_4_top);
    case_pred(74, check__type__table__clause_3_top);
    case_pred(75, check__type__table__clause1_5_top);
    case_pred(76, check__type__table__type_4_top);
    case_pred(77, remove__types__deps_3_top);
    case_pred(78, remove__types__deps_4_top);
    case_pred(79, remove__type__deps_4_top);
    case_pred(80, remove__type__args_5_top);
    case_pred(81, get__loopdeps_2_top);
    case_pred(82, get__loopdeps1_3_top);
    case_pred(83, make__types__loopdown_16_top);
    case_pred(84, make__type__loopdown_16_top);
    case_pred(85, make__type__loopdown__args_17_top);
    case_pred(86, make__types__loopup_9_top);
    case_pred(87, make__types__loopup1_9_top);
    case_pred(88, make__type__loopup_9_top);
    case_pred(89, make__type__loopup__struct_10_top);
    case_pred(90, merge__goals_3_top);
    case_pred(91, merge__goals__filter_3_top);
    last_case_pred(92, merge__loopgoals__filter_5_top);
  }

 get__arg__types_5_top: {
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 get__arg__types_5_clear_reason:
  reasonp = reasons;
 get__arg__types_5_0:
 get__arg__types_5_1:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_variable_3)) goto get__arg__types_5_2;
  a2 = arg(a2, 0);
  execute(get__types_5_0);
  goto get__types_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,get__arg__types_5_1);
  *reasonp++ =  a2;
  goto get__arg__types_5_2;
  };
  goto get__arg__types_5_2;
 get__arg__types_5_2:
  otherwise(get__arg__types_5_interrupt);
  a3 = NILATOM;
  a5 = makesym(atom_u);
  a6 = a4;
  a4 = NILATOM;
  execute(value2types_7_0);
  goto value2types_7_ext_interrupt;
 get__arg__types_5_ext_interrupt:
  reasonp = 0l;
 get__arg__types_5_interrupt:
  goto interrupt_5;
 }

 get__types_5_top: {
  q x0, x1, x2, x3, x4;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 get__types_5_clear_reason:
  reasonp = reasons;
 get__types_5_0:
 get__types_5_1:
  switch (ptagof(a3)) {
 case CONS:
  x0 = car_of(a3);
 get__types_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto get__types_5_7;
  x1 = arg(x0, 0);
 get__types_5_3:
  if (isref(x1)) goto get__types_5_6;
 get__types_5_4:
  if (isref(x1)) goto get__types_5_5;
  if_not_equal(x1, a0, get__types_5_7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = a4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[7] = a2;
  allocp[8] = makeint(1L);
  allocp[9] = x2;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = a1;
  x4 = arg(x0, 1);
  allocp[13] = x4;
  allocp[14] = x3;
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 get__types_5_5:
  deref_and_jump(x1,get__types_5_4);
  *reasonp++ =  x1;
  goto get__types_5_7;
 get__types_5_6:
  deref_and_jump(x1,get__types_5_3);
  *reasonp++ =  x1;
  goto get__types_5_7;
 case VARREF:
  deref_and_jump(x0,get__types_5_2);
  *reasonp++ =  x0;
  goto get__types_5_7;
  };
  goto get__types_5_7;
 case VARREF:
  deref_and_jump(a3,get__types_5_1);
  *reasonp++ =  a3;
  goto get__types_5_7;
  };
  goto get__types_5_7;
 get__types_5_7:
  otherwise(get__types_5_interrupt);
 get__types_5_8:
  switch (ptagof(a3)) {
 case CONS:
  a3 = cdr_of(a3);
  execute(get__types_5_0);
  goto get__types_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a3,get__types_5_8);
  *reasonp++ =  a3;
  goto get__types_5_interrupt;
  };
  goto get__types_5_interrupt;
 get__types_5_ext_interrupt:
  reasonp = 0l;
 get__types_5_interrupt:
  toppred = &predicate_type_xget__types_5;
  goto interrupt_5;
 }

 entry__new__aliasvar_14_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  qp = qp->next;
 entry__new__aliasvar_14_clear_reason:
  reasonp = reasons;
 entry__new__aliasvar_14_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xentry__new__aliasvar1_16);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = x1 = makeref(&allocp[11]);
  allocp[12] = a8;
  allocp[13] = a9;
  allocp[14] = a10;
  allocp[15] = a11;
  allocp[16] = a12;
  allocp[17] = a13;
  allocp[18] = (q)(struct goalrec*)&allocp[0];
  allocp[19] = (q)(&predicate_type_xentry__new__aliasvar__cycliccheck_10);
  allocp[20] = x1;
  allocp[21] = a7;
  allocp[22] = a0;
  allocp[23] = a1;
  allocp[24] = a2;
  allocp[25] = a3;
  allocp[26] = a4;
  allocp[27] = a5;
  allocp[28] = a6;
  allocp[29] = x0;
  allocp[30] = (q)(struct goalrec*)&allocp[18];
  allocp[31] = (q)(&predicate_list_xappend_3);
  allocp[32] = a10;
  allocp[33] = a12;
  allocp[34] = x1;
  qp = (struct goalrec*)&allocp[30];
  allocp += 35;
  proceed();
 entry__new__aliasvar_14_ext_interrupt:
  reasonp = 0l;
 entry__new__aliasvar_14_interrupt:
  goto interrupt_14;
 }

 entry__new__aliasvar1_16_top: {
  q x0;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  qp = qp->next;
 entry__new__aliasvar1_16_clear_reason:
  reasonp = reasons;
 entry__new__aliasvar1_16_0:
 entry__new__aliasvar1_16_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_no)) goto entry__new__aliasvar1_16_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xentry__new__aliasvar__gen_13);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a10;
  allocp[11] = a11;
  allocp[12] = a12;
  allocp[13] = a13;
  allocp[14] = a15;
  a0 = a9;
  a8 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 15;
  execute(entry__new__aliasvar__check_9_0);
  goto entry__new__aliasvar__check_9_ext_interrupt;
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_v_4)) goto entry__new__aliasvar1_16_interrupt;
  unify_value(a15, a0);
  unify2(a11, a10, a13, a12);
  proceed();
 case VARREF:
  deref_and_jump(a0,entry__new__aliasvar1_16_1);
  *reasonp++ =  a0;
  goto entry__new__aliasvar1_16_interrupt;
  };
  goto entry__new__aliasvar1_16_interrupt;
 entry__new__aliasvar1_16_ext_interrupt:
  reasonp = 0l;
 entry__new__aliasvar1_16_interrupt:
  goto interrupt_16;
 }

 entry__new__aliasvar__cycliccheck_10_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 entry__new__aliasvar__cycliccheck_10_clear_reason:
  reasonp = reasons;
 entry__new__aliasvar__cycliccheck_10_0:
 entry__new__aliasvar__cycliccheck_10_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_dummy)) goto entry__new__aliasvar__cycliccheck_10_2;
  unify_value(a9, makesym(atom_no));
  proceed();
 case VARREF:
  deref_and_jump(a1,entry__new__aliasvar__cycliccheck_10_1);
  *reasonp++ =  a1;
  goto entry__new__aliasvar__cycliccheck_10_2;
  };
  goto entry__new__aliasvar__cycliccheck_10_2;
 entry__new__aliasvar__cycliccheck_10_2:
  otherwise(entry__new__aliasvar__cycliccheck_10_interrupt);
  allocp[0] = makesym(functor_v_4);
  allocp[1] = a3;
  allocp[2] = a4;
  allocp[3] = a5;
  allocp[4] = a6;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_v_4);
  allocp[8] = a3;
  allocp[9] = a4;
  allocp[10] = a5;
  allocp[11] = a6;
  x2 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x2;
  x3 = makecons(&allocp[12]);
  a3 = x1;
  a4 = x3;
  a5 = a7;
  a6 = a8;
  a7 = a9;
  allocp += 14;
  execute(entry__new__aliasvar__cycliccheck1_8_0);
  goto entry__new__aliasvar__cycliccheck1_8_ext_interrupt;
 entry__new__aliasvar__cycliccheck_10_ext_interrupt:
  reasonp = 0l;
 entry__new__aliasvar__cycliccheck_10_interrupt:
  goto interrupt_10;
 }

 entry__new__aliasvar__cycliccheck1_8_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 entry__new__aliasvar__cycliccheck1_8_clear_reason:
  reasonp = reasons;
 entry__new__aliasvar__cycliccheck1_8_0:
 entry__new__aliasvar__cycliccheck1_8_1:
  switch (ptagof(a3)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xentry__new__aliasvar__cycliccheck2_9);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_list_xor__unique_3);
  x3 = cdr_of(a3);
  allocp[13] = x3;
  allocp[14] = x4 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_list_xdelete__elements_3);
  allocp[18] = a4;
  allocp[19] = x5 = makeref(&allocp[19]);
  allocp[20] = x4;
  allocp[21] = (q)(struct goalrec*)&allocp[16];
  allocp[22] = (q)(&predicate_list_xor__unique_3);
  allocp[23] = x5;
  allocp[24] = a4;
  allocp[25] = x2;
  allocp[26] = x6 = makeref(&allocp[26]);
  a1 = x6;
  a3 = car_of(a3);
  a4 = NILATOM;
  a6 = a5;
  a7 = x0;
  a5 = x5;
  qp = (struct goalrec*)&allocp[21];
  allocp += 27;
  execute(entry__new__aliasvar__cycliccheck11_8_0);
  goto entry__new__aliasvar__cycliccheck11_8_ext_interrupt;
 case ATOMIC:
  if (a3 != NILATOM) goto entry__new__aliasvar__cycliccheck1_8_interrupt;
  unify_value(a7, makesym(atom_no));
  proceed();
 case VARREF:
  deref_and_jump(a3,entry__new__aliasvar__cycliccheck1_8_1);
  *reasonp++ =  a3;
  goto entry__new__aliasvar__cycliccheck1_8_interrupt;
  };
  goto entry__new__aliasvar__cycliccheck1_8_interrupt;
 entry__new__aliasvar__cycliccheck1_8_ext_interrupt:
  reasonp = 0l;
 entry__new__aliasvar__cycliccheck1_8_interrupt:
  toppred = &predicate_type_xentry__new__aliasvar__cycliccheck1_8;
  goto interrupt_8;
 }

 entry__new__aliasvar__cycliccheck2_9_top: {
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 entry__new__aliasvar__cycliccheck2_9_clear_reason:
  reasonp = reasons;
 entry__new__aliasvar__cycliccheck2_9_0:
 entry__new__aliasvar__cycliccheck2_9_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_no)) goto entry__new__aliasvar__cycliccheck2_9_interrupt;
  a0 = a1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  a5 = a6;
  a6 = a7;
  a7 = a8;
  execute(entry__new__aliasvar__cycliccheck1_8_0);
  goto entry__new__aliasvar__cycliccheck1_8_ext_interrupt;
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_v_4)) goto entry__new__aliasvar__cycliccheck2_9_interrupt;
  unify_value(a8, a0);
  proceed();
 case VARREF:
  deref_and_jump(a0,entry__new__aliasvar__cycliccheck2_9_1);
  *reasonp++ =  a0;
  goto entry__new__aliasvar__cycliccheck2_9_interrupt;
  };
  goto entry__new__aliasvar__cycliccheck2_9_interrupt;
 entry__new__aliasvar__cycliccheck2_9_ext_interrupt:
  reasonp = 0l;
 entry__new__aliasvar__cycliccheck2_9_interrupt:
  goto interrupt_9;
 }

 entry__new__aliasvar__cycliccheck11_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 entry__new__aliasvar__cycliccheck11_8_clear_reason:
  reasonp = reasons;
 entry__new__aliasvar__cycliccheck11_8_0:
 entry__new__aliasvar__cycliccheck11_8_1:
  switch (ptagof(a0)) {
 case CONS:
 entry__new__aliasvar__cycliccheck11_8_2:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (isint(a2)) goto entry__new__aliasvar__cycliccheck11_8_33;
  switch (symval(a2)) {
 case symval(makesym(atom_up)):
  x0 = car_of(a0);
 entry__new__aliasvar__cycliccheck11_8_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_unifyaliasup_2)) goto entry__new__aliasvar__cycliccheck11_8_33;
  x1 = arg(x0, 0);
 entry__new__aliasvar__cycliccheck11_8_4:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_t_4)) goto entry__new__aliasvar__cycliccheck11_8_33;
  x2 = arg(x1, 2);
 entry__new__aliasvar__cycliccheck11_8_5:
  switch (ptagof(x2)) {
 case CONS:
  x3 = cdr_of(x2);
 entry__new__aliasvar__cycliccheck11_8_6:
  switch (ptagof(x3)) {
 case ATOMIC:
  if (x3 != NILATOM) goto entry__new__aliasvar__cycliccheck11_8_33;
  x4 = arg(x0, 1);
 entry__new__aliasvar__cycliccheck11_8_7:
  switch (ptagof(x4)) {
 case FUNCTOR:
  if (functor_of(x4) != makesym(functor_t_4)) goto entry__new__aliasvar__cycliccheck11_8_33;
  x5 = arg(x4, 2);
 entry__new__aliasvar__cycliccheck11_8_8:
  switch (ptagof(x5)) {
 case CONS:
  x6 = cdr_of(x5);
 entry__new__aliasvar__cycliccheck11_8_9:
  switch (ptagof(x6)) {
 case ATOMIC:
  if (x6 != NILATOM) goto entry__new__aliasvar__cycliccheck11_8_33;
 entry__new__aliasvar__cycliccheck11_8_10:
  if (isref(a3)) goto entry__new__aliasvar__cycliccheck11_8_17;
 entry__new__aliasvar__cycliccheck11_8_11:
  if (isref(a3)) goto entry__new__aliasvar__cycliccheck11_8_16;
  x7 = arg(x4, 0);
  if_not_equal(a3, x7, entry__new__aliasvar__cycliccheck11_8_33);
  x8 = car_of(x5);
 entry__new__aliasvar__cycliccheck11_8_12:
  if (isref(x8)) goto entry__new__aliasvar__cycliccheck11_8_15;
 entry__new__aliasvar__cycliccheck11_8_13:
  if (isref(x8)) goto entry__new__aliasvar__cycliccheck11_8_14;
  if_not_equal(x8, a6, entry__new__aliasvar__cycliccheck11_8_33);
  x9 = arg(x1, 0);
  unify(a7, x9);
  unify_value(a5, NILATOM);
  unify_value(a1, NILATOM);
  proceed();
 entry__new__aliasvar__cycliccheck11_8_14:
  deref_and_jump(x8,entry__new__aliasvar__cycliccheck11_8_13);
  *reasonp++ =  x8;
  goto entry__new__aliasvar__cycliccheck11_8_33;
 entry__new__aliasvar__cycliccheck11_8_15:
  deref_and_jump(x8,entry__new__aliasvar__cycliccheck11_8_12);
  *reasonp++ =  x8;
  goto entry__new__aliasvar__cycliccheck11_8_33;
 entry__new__aliasvar__cycliccheck11_8_16:
  deref_and_jump(a3,entry__new__aliasvar__cycliccheck11_8_11);
  *reasonp++ =  a3;
  goto entry__new__aliasvar__cycliccheck11_8_33;
 entry__new__aliasvar__cycliccheck11_8_17:
  deref_and_jump(a3,entry__new__aliasvar__cycliccheck11_8_10);
  *reasonp++ =  a3;
  goto entry__new__aliasvar__cycliccheck11_8_33;
 case VARREF:
  deref_and_jump(x6,entry__new__aliasvar__cycliccheck11_8_9);
  *reasonp++ =  x6;
  goto entry__new__aliasvar__cycliccheck11_8_33;
  };
  goto entry__new__aliasvar__cycliccheck11_8_33;
 case VARREF:
  deref_and_jump(x5,entry__new__aliasvar__cycliccheck11_8_8);
  *reasonp++ =  x5;
  goto entry__new__aliasvar__cycliccheck11_8_33;
  };
  goto entry__new__aliasvar__cycliccheck11_8_33;
 case VARREF:
  deref_and_jump(x4,entry__new__aliasvar__cycliccheck11_8_7);
  *reasonp++ =  x4;
  goto entry__new__aliasvar__cycliccheck11_8_33;
  };
  goto entry__new__aliasvar__cycliccheck11_8_33;
 case VARREF:
  deref_and_jump(x3,entry__new__aliasvar__cycliccheck11_8_6);
  *reasonp++ =  x3;
  goto entry__new__aliasvar__cycliccheck11_8_33;
  };
  goto entry__new__aliasvar__cycliccheck11_8_33;
 case VARREF:
  deref_and_jump(x2,entry__new__aliasvar__cycliccheck11_8_5);
  *reasonp++ =  x2;
  goto entry__new__aliasvar__cycliccheck11_8_33;
  };
  goto entry__new__aliasvar__cycliccheck11_8_33;
 case VARREF:
  deref_and_jump(x1,entry__new__aliasvar__cycliccheck11_8_4);
  *reasonp++ =  x1;
  goto entry__new__aliasvar__cycliccheck11_8_33;
  };
  goto entry__new__aliasvar__cycliccheck11_8_33;
 case VARREF:
  deref_and_jump(x0,entry__new__aliasvar__cycliccheck11_8_3);
  *reasonp++ =  x0;
  goto entry__new__aliasvar__cycliccheck11_8_33;
  };
  goto entry__new__aliasvar__cycliccheck11_8_33;
 case symval(makesym(atom_down)):
  x0 = car_of(a0);
 entry__new__aliasvar__cycliccheck11_8_18:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_unifyaliasdown_2)) goto entry__new__aliasvar__cycliccheck11_8_33;
  x1 = arg(x0, 0);
 entry__new__aliasvar__cycliccheck11_8_19:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_t_4)) goto entry__new__aliasvar__cycliccheck11_8_33;
  x2 = arg(x1, 2);
 entry__new__aliasvar__cycliccheck11_8_20:
  switch (ptagof(x2)) {
 case CONS:
  x3 = cdr_of(x2);
 entry__new__aliasvar__cycliccheck11_8_21:
  switch (ptagof(x3)) {
 case ATOMIC:
  if (x3 != NILATOM) goto entry__new__aliasvar__cycliccheck11_8_33;
  x4 = arg(x0, 1);
 entry__new__aliasvar__cycliccheck11_8_22:
  switch (ptagof(x4)) {
 case FUNCTOR:
  if (functor_of(x4) != makesym(functor_t_4)) goto entry__new__aliasvar__cycliccheck11_8_33;
  x5 = arg(x4, 2);
 entry__new__aliasvar__cycliccheck11_8_23:
  switch (ptagof(x5)) {
 case CONS:
  x6 = cdr_of(x5);
 entry__new__aliasvar__cycliccheck11_8_24:
  switch (ptagof(x6)) {
 case ATOMIC:
  if (x6 != NILATOM) goto entry__new__aliasvar__cycliccheck11_8_33;
 entry__new__aliasvar__cycliccheck11_8_25:
  if (isref(a3)) goto entry__new__aliasvar__cycliccheck11_8_32;
 entry__new__aliasvar__cycliccheck11_8_26:
  if (isref(a3)) goto entry__new__aliasvar__cycliccheck11_8_31;
  x7 = arg(x4, 0);
  if_not_equal(a3, x7, entry__new__aliasvar__cycliccheck11_8_33);
  x8 = car_of(x5);
 entry__new__aliasvar__cycliccheck11_8_27:
  if (isref(x8)) goto entry__new__aliasvar__cycliccheck11_8_30;
 entry__new__aliasvar__cycliccheck11_8_28:
  if (isref(x8)) goto entry__new__aliasvar__cycliccheck11_8_29;
  if_not_equal(x8, a6, entry__new__aliasvar__cycliccheck11_8_33);
  x9 = arg(x1, 0);
  unify(a7, x9);
  unify_value(a5, NILATOM);
  unify_value(a1, NILATOM);
  proceed();
 entry__new__aliasvar__cycliccheck11_8_29:
  deref_and_jump(x8,entry__new__aliasvar__cycliccheck11_8_28);
  *reasonp++ =  x8;
  goto entry__new__aliasvar__cycliccheck11_8_33;
 entry__new__aliasvar__cycliccheck11_8_30:
  deref_and_jump(x8,entry__new__aliasvar__cycliccheck11_8_27);
  *reasonp++ =  x8;
  goto entry__new__aliasvar__cycliccheck11_8_33;
 entry__new__aliasvar__cycliccheck11_8_31:
  deref_and_jump(a3,entry__new__aliasvar__cycliccheck11_8_26);
  *reasonp++ =  a3;
  goto entry__new__aliasvar__cycliccheck11_8_33;
 entry__new__aliasvar__cycliccheck11_8_32:
  deref_and_jump(a3,entry__new__aliasvar__cycliccheck11_8_25);
  *reasonp++ =  a3;
  goto entry__new__aliasvar__cycliccheck11_8_33;
 case VARREF:
  deref_and_jump(x6,entry__new__aliasvar__cycliccheck11_8_24);
  *reasonp++ =  x6;
  goto entry__new__aliasvar__cycliccheck11_8_33;
  };
  goto entry__new__aliasvar__cycliccheck11_8_33;
 case VARREF:
  deref_and_jump(x5,entry__new__aliasvar__cycliccheck11_8_23);
  *reasonp++ =  x5;
  goto entry__new__aliasvar__cycliccheck11_8_33;
  };
  goto entry__new__aliasvar__cycliccheck11_8_33;
 case VARREF:
  deref_and_jump(x4,entry__new__aliasvar__cycliccheck11_8_22);
  *reasonp++ =  x4;
  goto entry__new__aliasvar__cycliccheck11_8_33;
  };
  goto entry__new__aliasvar__cycliccheck11_8_33;
 case VARREF:
  deref_and_jump(x3,entry__new__aliasvar__cycliccheck11_8_21);
  *reasonp++ =  x3;
  goto entry__new__aliasvar__cycliccheck11_8_33;
  };
  goto entry__new__aliasvar__cycliccheck11_8_33;
 case VARREF:
  deref_and_jump(x2,entry__new__aliasvar__cycliccheck11_8_20);
  *reasonp++ =  x2;
  goto entry__new__aliasvar__cycliccheck11_8_33;
  };
  goto entry__new__aliasvar__cycliccheck11_8_33;
 case VARREF:
  deref_and_jump(x1,entry__new__aliasvar__cycliccheck11_8_19);
  *reasonp++ =  x1;
  goto entry__new__aliasvar__cycliccheck11_8_33;
  };
  goto entry__new__aliasvar__cycliccheck11_8_33;
 case VARREF:
  deref_and_jump(x0,entry__new__aliasvar__cycliccheck11_8_18);
  *reasonp++ =  x0;
  goto entry__new__aliasvar__cycliccheck11_8_33;
  };
  goto entry__new__aliasvar__cycliccheck11_8_33;
  };
  goto entry__new__aliasvar__cycliccheck11_8_33;
 case VARREF:
  deref_and_jump(a2,entry__new__aliasvar__cycliccheck11_8_2);
  *reasonp++ =  a2;
  goto entry__new__aliasvar__cycliccheck11_8_33;
  };
  goto entry__new__aliasvar__cycliccheck11_8_33;
 case VARREF:
  deref_and_jump(a0,entry__new__aliasvar__cycliccheck11_8_1);
  *reasonp++ =  a0;
  goto entry__new__aliasvar__cycliccheck11_8_33;
  };
  goto entry__new__aliasvar__cycliccheck11_8_33;
 entry__new__aliasvar__cycliccheck11_8_33:
  otherwise(entry__new__aliasvar__cycliccheck11_8_interrupt);
 entry__new__aliasvar__cycliccheck11_8_34:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 entry__new__aliasvar__cycliccheck11_8_35:
  if (isref(x0)) goto entry__new__aliasvar__cycliccheck11_8_45;
  gblt_arg(makeint(1L),x0,x1,entry__new__aliasvar__cycliccheck11_8_46);
 entry__new__aliasvar__cycliccheck11_8_36:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_t_4)) goto entry__new__aliasvar__cycliccheck11_8_46;
  gblt_arg(makeint(2L),x0,x2,entry__new__aliasvar__cycliccheck11_8_46);
 entry__new__aliasvar__cycliccheck11_8_37:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_t_4)) goto entry__new__aliasvar__cycliccheck11_8_46;
 entry__new__aliasvar__cycliccheck11_8_38:
  if (isref(a3)) goto entry__new__aliasvar__cycliccheck11_8_44;
 entry__new__aliasvar__cycliccheck11_8_39:
  if (isref(a3)) goto entry__new__aliasvar__cycliccheck11_8_43;
  x3 = arg(x1, 0);
  if_not_equal(a3, x3, entry__new__aliasvar__cycliccheck11_8_40);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xentry__new__aliasvar__cycliccheck11_8);
  x4 = cdr_of(a0);
  allocp[2] = x4;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x5 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = NILATOM;
  allocp[11] = arg(x2, 0);
  x6 = makecons(&allocp[10]);
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_list_xor__unique_3);
  allocp[14] = a4;
  allocp[15] = x6;
  allocp[16] = x5;
  qp = (struct goalrec*)&allocp[12];
  allocp += 17;
  proceed();
 entry__new__aliasvar__cycliccheck11_8_40:
 entry__new__aliasvar__cycliccheck11_8_41:
  if (isref(a3)) goto entry__new__aliasvar__cycliccheck11_8_42;
  x4 = arg(x2, 0);
  if_not_equal(a3, x4, entry__new__aliasvar__cycliccheck11_8_46);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xentry__new__aliasvar__cycliccheck11_8);
  x5 = cdr_of(a0);
  allocp[2] = x5;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x6 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = NILATOM;
  allocp[11] = x3;
  x7 = makecons(&allocp[10]);
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_list_xor__unique_3);
  allocp[14] = a4;
  allocp[15] = x7;
  allocp[16] = x6;
  qp = (struct goalrec*)&allocp[12];
  allocp += 17;
  proceed();
 entry__new__aliasvar__cycliccheck11_8_42:
  deref_and_jump(a3,entry__new__aliasvar__cycliccheck11_8_41);
  *reasonp++ =  a3;
  goto entry__new__aliasvar__cycliccheck11_8_46;
 entry__new__aliasvar__cycliccheck11_8_43:
  deref_and_jump(a3,entry__new__aliasvar__cycliccheck11_8_39);
  *reasonp++ =  a3;
  goto entry__new__aliasvar__cycliccheck11_8_46;
 entry__new__aliasvar__cycliccheck11_8_44:
  deref_and_jump(a3,entry__new__aliasvar__cycliccheck11_8_38);
  *reasonp++ =  a3;
  goto entry__new__aliasvar__cycliccheck11_8_46;
 case VARREF:
  deref_and_jump(x2,entry__new__aliasvar__cycliccheck11_8_37);
  *reasonp++ =  x2;
  goto entry__new__aliasvar__cycliccheck11_8_46;
  };
  goto entry__new__aliasvar__cycliccheck11_8_46;
 case VARREF:
  deref_and_jump(x1,entry__new__aliasvar__cycliccheck11_8_36);
  *reasonp++ =  x1;
  goto entry__new__aliasvar__cycliccheck11_8_46;
  };
  goto entry__new__aliasvar__cycliccheck11_8_46;
 entry__new__aliasvar__cycliccheck11_8_45:
  deref_and_jump(x0,entry__new__aliasvar__cycliccheck11_8_35);
  *reasonp++ =  x0;
  goto entry__new__aliasvar__cycliccheck11_8_46;
 case VARREF:
  deref_and_jump(a0,entry__new__aliasvar__cycliccheck11_8_34);
  *reasonp++ =  a0;
  goto entry__new__aliasvar__cycliccheck11_8_46;
  };
  goto entry__new__aliasvar__cycliccheck11_8_46;
 entry__new__aliasvar__cycliccheck11_8_46:
  otherwise(entry__new__aliasvar__cycliccheck11_8_interrupt);
 entry__new__aliasvar__cycliccheck11_8_47:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = car_of(a0);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(entry__new__aliasvar__cycliccheck11_8_0);
  goto entry__new__aliasvar__cycliccheck11_8_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto entry__new__aliasvar__cycliccheck11_8_interrupt;
  unify_value(a1, NILATOM);
  unify(a5, a4);
  unify_value(a7, makesym(atom_no));
  proceed();
 case VARREF:
  deref_and_jump(a0,entry__new__aliasvar__cycliccheck11_8_47);
  *reasonp++ =  a0;
  goto entry__new__aliasvar__cycliccheck11_8_interrupt;
  };
  goto entry__new__aliasvar__cycliccheck11_8_interrupt;
 entry__new__aliasvar__cycliccheck11_8_ext_interrupt:
  reasonp = 0l;
 entry__new__aliasvar__cycliccheck11_8_interrupt:
  toppred = &predicate_type_xentry__new__aliasvar__cycliccheck11_8;
  goto interrupt_8;
 }

 entry__new__aliasvar__check_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 entry__new__aliasvar__check_9_clear_reason:
  reasonp = reasons;
 entry__new__aliasvar__check_9_0:
 entry__new__aliasvar__check_9_1:
  switch (ptagof(a0)) {
 case CONS:
 entry__new__aliasvar__check_9_2:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (isint(a1)) goto entry__new__aliasvar__check_9_93;
  switch (symval(a1)) {
 case symval(makesym(atom_down)):
  x0 = car_of(a0);
 entry__new__aliasvar__check_9_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_unifyaliasdown_2)) goto entry__new__aliasvar__check_9_93;
  x1 = arg(x0, 0);
 entry__new__aliasvar__check_9_4:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_t_4)) goto entry__new__aliasvar__check_9_93;
  x2 = arg(x1, 0);
 entry__new__aliasvar__check_9_5:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_v_4)) goto entry__new__aliasvar__check_9_93;
  x3 = arg(x2, 0);
 entry__new__aliasvar__check_9_6:
  if (isref(x3)) goto entry__new__aliasvar__check_9_47;
 entry__new__aliasvar__check_9_7:
  if (isref(x3)) goto entry__new__aliasvar__check_9_46;
  if_not_equal(x3, a2, entry__new__aliasvar__check_9_93);
  x4 = arg(x2, 1);
 entry__new__aliasvar__check_9_8:
  if (isref(x4)) goto entry__new__aliasvar__check_9_45;
 entry__new__aliasvar__check_9_9:
  if (isref(x4)) goto entry__new__aliasvar__check_9_44;
  if_not_equal(x4, a3, entry__new__aliasvar__check_9_93);
  x5 = arg(x2, 2);
 entry__new__aliasvar__check_9_10:
  switch (ptagof(x5)) {
 case ATOMIC:
 entry__new__aliasvar__check_9_11:
  if (x5 != makeint(-1L)) goto entry__new__aliasvar__check_9_93;
  x6 = arg(x1, 1);
 entry__new__aliasvar__check_9_12:
  switch (ptagof(x6)) {
 case ATOMIC:
  if (x6 != NILATOM) goto entry__new__aliasvar__check_9_93;
  x7 = arg(x1, 2);
 entry__new__aliasvar__check_9_13:
  switch (ptagof(x7)) {
 case CONS:
  x8 = car_of(x7);
 entry__new__aliasvar__check_9_14:
  if (isref(x8)) goto entry__new__aliasvar__check_9_43;
 entry__new__aliasvar__check_9_15:
  if (isref(x8)) goto entry__new__aliasvar__check_9_42;
  if_not_equal(x8, a7, entry__new__aliasvar__check_9_93);
  x9 = cdr_of(x7);
 entry__new__aliasvar__check_9_16:
  switch (ptagof(x9)) {
 case ATOMIC:
  if (x9 != NILATOM) goto entry__new__aliasvar__check_9_93;
  x10 = arg(x0, 1);
 entry__new__aliasvar__check_9_17:
  switch (ptagof(x10)) {
 case FUNCTOR:
  if (functor_of(x10) != makesym(functor_t_4)) goto entry__new__aliasvar__check_9_93;
  x11 = arg(x10, 0);
 entry__new__aliasvar__check_9_18:
  switch (ptagof(x11)) {
 case FUNCTOR:
  if (functor_of(x11) != makesym(functor_v_4)) goto entry__new__aliasvar__check_9_93;
  x12 = arg(x11, 0);
 entry__new__aliasvar__check_9_19:
  if (isref(x12)) goto entry__new__aliasvar__check_9_41;
 entry__new__aliasvar__check_9_20:
  if (isref(x12)) goto entry__new__aliasvar__check_9_40;
  if_not_equal(x12, a2, entry__new__aliasvar__check_9_93);
  x13 = arg(x11, 1);
 entry__new__aliasvar__check_9_21:
  if (isref(x13)) goto entry__new__aliasvar__check_9_39;
 entry__new__aliasvar__check_9_22:
  if (isref(x13)) goto entry__new__aliasvar__check_9_38;
  if_not_equal(x13, a3, entry__new__aliasvar__check_9_93);
  x14 = arg(x11, 2);
 entry__new__aliasvar__check_9_23:
  if (isref(x14)) goto entry__new__aliasvar__check_9_37;
 entry__new__aliasvar__check_9_24:
  if (isref(x14)) goto entry__new__aliasvar__check_9_36;
  if_not_equal(x14, a4, entry__new__aliasvar__check_9_93);
  x15 = arg(x11, 3);
 entry__new__aliasvar__check_9_25:
  if (isref(x15)) goto entry__new__aliasvar__check_9_35;
 entry__new__aliasvar__check_9_26:
  if (isref(x15)) goto entry__new__aliasvar__check_9_34;
  if_not_equal(x15, a5, entry__new__aliasvar__check_9_93);
  x16 = arg(x10, 1);
 entry__new__aliasvar__check_9_27:
  switch (ptagof(x16)) {
 case ATOMIC:
  if (x16 != NILATOM) goto entry__new__aliasvar__check_9_93;
  x17 = arg(x10, 2);
 entry__new__aliasvar__check_9_28:
  switch (ptagof(x17)) {
 case CONS:
  x18 = car_of(x17);
 entry__new__aliasvar__check_9_29:
  if (isref(x18)) goto entry__new__aliasvar__check_9_33;
 entry__new__aliasvar__check_9_30:
  if (isref(x18)) goto entry__new__aliasvar__check_9_32;
  if_not_equal(x18, a6, entry__new__aliasvar__check_9_93);
  x19 = cdr_of(x17);
 entry__new__aliasvar__check_9_31:
  switch (ptagof(x19)) {
 case ATOMIC:
  if (x19 != NILATOM) goto entry__new__aliasvar__check_9_93;
  allocp[0] = makesym(functor_v_4);
  allocp[1] = a2;
  allocp[2] = a3;
  allocp[3] = makeint(-1L);
  allocp[4] = arg(x2, 3);
  x20 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a8, x20);
  proceed();
 case VARREF:
  deref_and_jump(x19,entry__new__aliasvar__check_9_31);
  *reasonp++ =  x19;
  goto entry__new__aliasvar__check_9_93;
  };
  goto entry__new__aliasvar__check_9_93;
 entry__new__aliasvar__check_9_32:
  deref_and_jump(x18,entry__new__aliasvar__check_9_30);
  *reasonp++ =  x18;
  goto entry__new__aliasvar__check_9_93;
 entry__new__aliasvar__check_9_33:
  deref_and_jump(x18,entry__new__aliasvar__check_9_29);
  *reasonp++ =  x18;
  goto entry__new__aliasvar__check_9_93;
 case VARREF:
  deref_and_jump(x17,entry__new__aliasvar__check_9_28);
  *reasonp++ =  x17;
  goto entry__new__aliasvar__check_9_93;
  };
  goto entry__new__aliasvar__check_9_93;
 case VARREF:
  deref_and_jump(x16,entry__new__aliasvar__check_9_27);
  *reasonp++ =  x16;
  goto entry__new__aliasvar__check_9_93;
  };
  goto entry__new__aliasvar__check_9_93;
 entry__new__aliasvar__check_9_34:
  deref_and_jump(x15,entry__new__aliasvar__check_9_26);
  *reasonp++ =  x15;
  goto entry__new__aliasvar__check_9_93;
 entry__new__aliasvar__check_9_35:
  deref_and_jump(x15,entry__new__aliasvar__check_9_25);
  *reasonp++ =  x15;
  goto entry__new__aliasvar__check_9_93;
 entry__new__aliasvar__check_9_36:
  deref_and_jump(x14,entry__new__aliasvar__check_9_24);
  *reasonp++ =  x14;
  goto entry__new__aliasvar__check_9_93;
 entry__new__aliasvar__check_9_37:
  deref_and_jump(x14,entry__new__aliasvar__check_9_23);
  *reasonp++ =  x14;
  goto entry__new__aliasvar__check_9_93;
 entry__new__aliasvar__check_9_38:
  deref_and_jump(x13,entry__new__aliasvar__check_9_22);
  *reasonp++ =  x13;
  goto entry__new__aliasvar__check_9_93;
 entry__new__aliasvar__check_9_39:
  deref_and_jump(x13,entry__new__aliasvar__check_9_21);
  *reasonp++ =  x13;
  goto entry__new__aliasvar__check_9_93;
 entry__new__aliasvar__check_9_40:
  deref_and_jump(x12,entry__new__aliasvar__check_9_20);
  *reasonp++ =  x12;
  goto entry__new__aliasvar__check_9_93;
 entry__new__aliasvar__check_9_41:
  deref_and_jump(x12,entry__new__aliasvar__check_9_19);
  *reasonp++ =  x12;
  goto entry__new__aliasvar__check_9_93;
 case VARREF:
  deref_and_jump(x11,entry__new__aliasvar__check_9_18);
  *reasonp++ =  x11;
  goto entry__new__aliasvar__check_9_93;
  };
  goto entry__new__aliasvar__check_9_93;
 case VARREF:
  deref_and_jump(x10,entry__new__aliasvar__check_9_17);
  *reasonp++ =  x10;
  goto entry__new__aliasvar__check_9_93;
  };
  goto entry__new__aliasvar__check_9_93;
 case VARREF:
  deref_and_jump(x9,entry__new__aliasvar__check_9_16);
  *reasonp++ =  x9;
  goto entry__new__aliasvar__check_9_93;
  };
  goto entry__new__aliasvar__check_9_93;
 entry__new__aliasvar__check_9_42:
  deref_and_jump(x8,entry__new__aliasvar__check_9_15);
  *reasonp++ =  x8;
  goto entry__new__aliasvar__check_9_93;
 entry__new__aliasvar__check_9_43:
  deref_and_jump(x8,entry__new__aliasvar__check_9_14);
  *reasonp++ =  x8;
  goto entry__new__aliasvar__check_9_93;
 case VARREF:
  deref_and_jump(x7,entry__new__aliasvar__check_9_13);
  *reasonp++ =  x7;
  goto entry__new__aliasvar__check_9_93;
  };
  goto entry__new__aliasvar__check_9_93;
 case VARREF:
  deref_and_jump(x6,entry__new__aliasvar__check_9_12);
  *reasonp++ =  x6;
  goto entry__new__aliasvar__check_9_93;
  };
  goto entry__new__aliasvar__check_9_93;
 case VARREF:
  deref_and_jump(x5,entry__new__aliasvar__check_9_10);
  *reasonp++ =  x5;
  goto entry__new__aliasvar__check_9_93;
  };
  goto entry__new__aliasvar__check_9_93;
 entry__new__aliasvar__check_9_44:
  deref_and_jump(x4,entry__new__aliasvar__check_9_9);
  *reasonp++ =  x4;
  goto entry__new__aliasvar__check_9_93;
 entry__new__aliasvar__check_9_45:
  deref_and_jump(x4,entry__new__aliasvar__check_9_8);
  *reasonp++ =  x4;
  goto entry__new__aliasvar__check_9_93;
 entry__new__aliasvar__check_9_46:
  deref_and_jump(x3,entry__new__aliasvar__check_9_7);
  *reasonp++ =  x3;
  goto entry__new__aliasvar__check_9_93;
 entry__new__aliasvar__check_9_47:
  deref_and_jump(x3,entry__new__aliasvar__check_9_6);
  *reasonp++ =  x3;
  goto entry__new__aliasvar__check_9_93;
 case VARREF:
  deref_and_jump(x2,entry__new__aliasvar__check_9_5);
  *reasonp++ =  x2;
  goto entry__new__aliasvar__check_9_93;
  };
  goto entry__new__aliasvar__check_9_93;
 case VARREF:
  deref_and_jump(x1,entry__new__aliasvar__check_9_4);
  *reasonp++ =  x1;
  goto entry__new__aliasvar__check_9_93;
  };
  goto entry__new__aliasvar__check_9_93;
 case VARREF:
  deref_and_jump(x0,entry__new__aliasvar__check_9_3);
  *reasonp++ =  x0;
  goto entry__new__aliasvar__check_9_93;
  };
  goto entry__new__aliasvar__check_9_93;
 case symval(makesym(atom_up)):
  x0 = car_of(a0);
 entry__new__aliasvar__check_9_48:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_unifyaliasup_2)) goto entry__new__aliasvar__check_9_93;
  x1 = arg(x0, 0);
 entry__new__aliasvar__check_9_49:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_t_4)) goto entry__new__aliasvar__check_9_93;
  x2 = arg(x1, 0);
 entry__new__aliasvar__check_9_50:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_v_4)) goto entry__new__aliasvar__check_9_93;
  x3 = arg(x2, 0);
 entry__new__aliasvar__check_9_51:
  if (isref(x3)) goto entry__new__aliasvar__check_9_92;
 entry__new__aliasvar__check_9_52:
  if (isref(x3)) goto entry__new__aliasvar__check_9_91;
  if_not_equal(x3, a2, entry__new__aliasvar__check_9_93);
  x4 = arg(x2, 1);
 entry__new__aliasvar__check_9_53:
  if (isref(x4)) goto entry__new__aliasvar__check_9_90;
 entry__new__aliasvar__check_9_54:
  if (isref(x4)) goto entry__new__aliasvar__check_9_89;
  if_not_equal(x4, a3, entry__new__aliasvar__check_9_93);
  x5 = arg(x2, 2);
 entry__new__aliasvar__check_9_55:
  switch (ptagof(x5)) {
 case ATOMIC:
 entry__new__aliasvar__check_9_56:
  if (x5 != makeint(-1L)) goto entry__new__aliasvar__check_9_93;
  x6 = arg(x1, 1);
 entry__new__aliasvar__check_9_57:
  switch (ptagof(x6)) {
 case ATOMIC:
  if (x6 != NILATOM) goto entry__new__aliasvar__check_9_93;
  x7 = arg(x1, 2);
 entry__new__aliasvar__check_9_58:
  switch (ptagof(x7)) {
 case CONS:
  x8 = car_of(x7);
 entry__new__aliasvar__check_9_59:
  if (isref(x8)) goto entry__new__aliasvar__check_9_88;
 entry__new__aliasvar__check_9_60:
  if (isref(x8)) goto entry__new__aliasvar__check_9_87;
  if_not_equal(x8, a7, entry__new__aliasvar__check_9_93);
  x9 = cdr_of(x7);
 entry__new__aliasvar__check_9_61:
  switch (ptagof(x9)) {
 case ATOMIC:
  if (x9 != NILATOM) goto entry__new__aliasvar__check_9_93;
  x10 = arg(x0, 1);
 entry__new__aliasvar__check_9_62:
  switch (ptagof(x10)) {
 case FUNCTOR:
  if (functor_of(x10) != makesym(functor_t_4)) goto entry__new__aliasvar__check_9_93;
  x11 = arg(x10, 0);
 entry__new__aliasvar__check_9_63:
  switch (ptagof(x11)) {
 case FUNCTOR:
  if (functor_of(x11) != makesym(functor_v_4)) goto entry__new__aliasvar__check_9_93;
  x12 = arg(x11, 0);
 entry__new__aliasvar__check_9_64:
  if (isref(x12)) goto entry__new__aliasvar__check_9_86;
 entry__new__aliasvar__check_9_65:
  if (isref(x12)) goto entry__new__aliasvar__check_9_85;
  if_not_equal(x12, a2, entry__new__aliasvar__check_9_93);
  x13 = arg(x11, 1);
 entry__new__aliasvar__check_9_66:
  if (isref(x13)) goto entry__new__aliasvar__check_9_84;
 entry__new__aliasvar__check_9_67:
  if (isref(x13)) goto entry__new__aliasvar__check_9_83;
  if_not_equal(x13, a3, entry__new__aliasvar__check_9_93);
  x14 = arg(x11, 2);
 entry__new__aliasvar__check_9_68:
  if (isref(x14)) goto entry__new__aliasvar__check_9_82;
 entry__new__aliasvar__check_9_69:
  if (isref(x14)) goto entry__new__aliasvar__check_9_81;
  if_not_equal(x14, a4, entry__new__aliasvar__check_9_93);
  x15 = arg(x11, 3);
 entry__new__aliasvar__check_9_70:
  if (isref(x15)) goto entry__new__aliasvar__check_9_80;
 entry__new__aliasvar__check_9_71:
  if (isref(x15)) goto entry__new__aliasvar__check_9_79;
  if_not_equal(x15, a5, entry__new__aliasvar__check_9_93);
  x16 = arg(x10, 1);
 entry__new__aliasvar__check_9_72:
  switch (ptagof(x16)) {
 case ATOMIC:
  if (x16 != NILATOM) goto entry__new__aliasvar__check_9_93;
  x17 = arg(x10, 2);
 entry__new__aliasvar__check_9_73:
  switch (ptagof(x17)) {
 case CONS:
  x18 = car_of(x17);
 entry__new__aliasvar__check_9_74:
  if (isref(x18)) goto entry__new__aliasvar__check_9_78;
 entry__new__aliasvar__check_9_75:
  if (isref(x18)) goto entry__new__aliasvar__check_9_77;
  if_not_equal(x18, a6, entry__new__aliasvar__check_9_93);
  x19 = cdr_of(x17);
 entry__new__aliasvar__check_9_76:
  switch (ptagof(x19)) {
 case ATOMIC:
  if (x19 != NILATOM) goto entry__new__aliasvar__check_9_93;
  allocp[0] = makesym(functor_v_4);
  allocp[1] = a2;
  allocp[2] = a3;
  allocp[3] = makeint(-1L);
  allocp[4] = arg(x2, 3);
  x20 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a8, x20);
  proceed();
 case VARREF:
  deref_and_jump(x19,entry__new__aliasvar__check_9_76);
  *reasonp++ =  x19;
  goto entry__new__aliasvar__check_9_93;
  };
  goto entry__new__aliasvar__check_9_93;
 entry__new__aliasvar__check_9_77:
  deref_and_jump(x18,entry__new__aliasvar__check_9_75);
  *reasonp++ =  x18;
  goto entry__new__aliasvar__check_9_93;
 entry__new__aliasvar__check_9_78:
  deref_and_jump(x18,entry__new__aliasvar__check_9_74);
  *reasonp++ =  x18;
  goto entry__new__aliasvar__check_9_93;
 case VARREF:
  deref_and_jump(x17,entry__new__aliasvar__check_9_73);
  *reasonp++ =  x17;
  goto entry__new__aliasvar__check_9_93;
  };
  goto entry__new__aliasvar__check_9_93;
 case VARREF:
  deref_and_jump(x16,entry__new__aliasvar__check_9_72);
  *reasonp++ =  x16;
  goto entry__new__aliasvar__check_9_93;
  };
  goto entry__new__aliasvar__check_9_93;
 entry__new__aliasvar__check_9_79:
  deref_and_jump(x15,entry__new__aliasvar__check_9_71);
  *reasonp++ =  x15;
  goto entry__new__aliasvar__check_9_93;
 entry__new__aliasvar__check_9_80:
  deref_and_jump(x15,entry__new__aliasvar__check_9_70);
  *reasonp++ =  x15;
  goto entry__new__aliasvar__check_9_93;
 entry__new__aliasvar__check_9_81:
  deref_and_jump(x14,entry__new__aliasvar__check_9_69);
  *reasonp++ =  x14;
  goto entry__new__aliasvar__check_9_93;
 entry__new__aliasvar__check_9_82:
  deref_and_jump(x14,entry__new__aliasvar__check_9_68);
  *reasonp++ =  x14;
  goto entry__new__aliasvar__check_9_93;
 entry__new__aliasvar__check_9_83:
  deref_and_jump(x13,entry__new__aliasvar__check_9_67);
  *reasonp++ =  x13;
  goto entry__new__aliasvar__check_9_93;
 entry__new__aliasvar__check_9_84:
  deref_and_jump(x13,entry__new__aliasvar__check_9_66);
  *reasonp++ =  x13;
  goto entry__new__aliasvar__check_9_93;
 entry__new__aliasvar__check_9_85:
  deref_and_jump(x12,entry__new__aliasvar__check_9_65);
  *reasonp++ =  x12;
  goto entry__new__aliasvar__check_9_93;
 entry__new__aliasvar__check_9_86:
  deref_and_jump(x12,entry__new__aliasvar__check_9_64);
  *reasonp++ =  x12;
  goto entry__new__aliasvar__check_9_93;
 case VARREF:
  deref_and_jump(x11,entry__new__aliasvar__check_9_63);
  *reasonp++ =  x11;
  goto entry__new__aliasvar__check_9_93;
  };
  goto entry__new__aliasvar__check_9_93;
 case VARREF:
  deref_and_jump(x10,entry__new__aliasvar__check_9_62);
  *reasonp++ =  x10;
  goto entry__new__aliasvar__check_9_93;
  };
  goto entry__new__aliasvar__check_9_93;
 case VARREF:
  deref_and_jump(x9,entry__new__aliasvar__check_9_61);
  *reasonp++ =  x9;
  goto entry__new__aliasvar__check_9_93;
  };
  goto entry__new__aliasvar__check_9_93;
 entry__new__aliasvar__check_9_87:
  deref_and_jump(x8,entry__new__aliasvar__check_9_60);
  *reasonp++ =  x8;
  goto entry__new__aliasvar__check_9_93;
 entry__new__aliasvar__check_9_88:
  deref_and_jump(x8,entry__new__aliasvar__check_9_59);
  *reasonp++ =  x8;
  goto entry__new__aliasvar__check_9_93;
 case VARREF:
  deref_and_jump(x7,entry__new__aliasvar__check_9_58);
  *reasonp++ =  x7;
  goto entry__new__aliasvar__check_9_93;
  };
  goto entry__new__aliasvar__check_9_93;
 case VARREF:
  deref_and_jump(x6,entry__new__aliasvar__check_9_57);
  *reasonp++ =  x6;
  goto entry__new__aliasvar__check_9_93;
  };
  goto entry__new__aliasvar__check_9_93;
 case VARREF:
  deref_and_jump(x5,entry__new__aliasvar__check_9_55);
  *reasonp++ =  x5;
  goto entry__new__aliasvar__check_9_93;
  };
  goto entry__new__aliasvar__check_9_93;
 entry__new__aliasvar__check_9_89:
  deref_and_jump(x4,entry__new__aliasvar__check_9_54);
  *reasonp++ =  x4;
  goto entry__new__aliasvar__check_9_93;
 entry__new__aliasvar__check_9_90:
  deref_and_jump(x4,entry__new__aliasvar__check_9_53);
  *reasonp++ =  x4;
  goto entry__new__aliasvar__check_9_93;
 entry__new__aliasvar__check_9_91:
  deref_and_jump(x3,entry__new__aliasvar__check_9_52);
  *reasonp++ =  x3;
  goto entry__new__aliasvar__check_9_93;
 entry__new__aliasvar__check_9_92:
  deref_and_jump(x3,entry__new__aliasvar__check_9_51);
  *reasonp++ =  x3;
  goto entry__new__aliasvar__check_9_93;
 case VARREF:
  deref_and_jump(x2,entry__new__aliasvar__check_9_50);
  *reasonp++ =  x2;
  goto entry__new__aliasvar__check_9_93;
  };
  goto entry__new__aliasvar__check_9_93;
 case VARREF:
  deref_and_jump(x1,entry__new__aliasvar__check_9_49);
  *reasonp++ =  x1;
  goto entry__new__aliasvar__check_9_93;
  };
  goto entry__new__aliasvar__check_9_93;
 case VARREF:
  deref_and_jump(x0,entry__new__aliasvar__check_9_48);
  *reasonp++ =  x0;
  goto entry__new__aliasvar__check_9_93;
  };
  goto entry__new__aliasvar__check_9_93;
  };
  goto entry__new__aliasvar__check_9_93;
 case VARREF:
  deref_and_jump(a1,entry__new__aliasvar__check_9_2);
  *reasonp++ =  a1;
  goto entry__new__aliasvar__check_9_93;
  };
  goto entry__new__aliasvar__check_9_93;
 case VARREF:
  deref_and_jump(a0,entry__new__aliasvar__check_9_1);
  *reasonp++ =  a0;
  goto entry__new__aliasvar__check_9_93;
  };
  goto entry__new__aliasvar__check_9_93;
 entry__new__aliasvar__check_9_93:
  otherwise(entry__new__aliasvar__check_9_interrupt);
 entry__new__aliasvar__check_9_94:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(entry__new__aliasvar__check_9_0);
  goto entry__new__aliasvar__check_9_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto entry__new__aliasvar__check_9_interrupt;
  unify_value(a8, makesym(atom_no));
  proceed();
 case VARREF:
  deref_and_jump(a0,entry__new__aliasvar__check_9_94);
  *reasonp++ =  a0;
  goto entry__new__aliasvar__check_9_interrupt;
  };
  goto entry__new__aliasvar__check_9_interrupt;
 entry__new__aliasvar__check_9_ext_interrupt:
  reasonp = 0l;
 entry__new__aliasvar__check_9_interrupt:
  toppred = &predicate_type_xentry__new__aliasvar__check_9;
  goto interrupt_9;
 }

 entry__new__aliasvar__gen_13_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  qp = qp->next;
 entry__new__aliasvar__gen_13_clear_reason:
  reasonp = reasons;
 entry__new__aliasvar__gen_13_0:
 entry__new__aliasvar__gen_13_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_no)) goto entry__new__aliasvar__gen_13_3;
 entry__new__aliasvar__gen_13_2:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (isint(a1)) goto entry__new__aliasvar__gen_13_3;
  switch (symval(a1)) {
 case symval(makesym(atom_down)):
  allocp[0] = makesym(functor_v_4);
  allocp[1] = a2;
  allocp[2] = a3;
  allocp[3] = makeint(-1L);
  allocp[4] = x1 = makeref(&allocp[4]);
  x0 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a12, x0);
  allocp[0] = makesym(functor_v_4);
  allocp[1] = a2;
  allocp[2] = a3;
  allocp[3] = makeint(-1L);
  allocp[4] = x1;
  x2 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = a7;
  x3 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_4);
  allocp[8] = x2;
  allocp[9] = NILATOM;
  allocp[10] = x3;
  allocp[11] = makesym(atom__3F);
  x4 = makefunctor(&allocp[7]);
  allocp[12] = makesym(functor_v_4);
  allocp[13] = a2;
  allocp[14] = a3;
  allocp[15] = a4;
  allocp[16] = a5;
  x5 = makefunctor(&allocp[12]);
  allocp[17] = NILATOM;
  allocp[18] = a6;
  x6 = makecons(&allocp[17]);
  allocp[19] = makesym(functor_t_4);
  allocp[20] = x5;
  allocp[21] = NILATOM;
  allocp[22] = x6;
  allocp[23] = makesym(atom__3F);
  x7 = makefunctor(&allocp[19]);
  allocp[24] = makesym(functor_unifyaliasdown_2);
  allocp[25] = x4;
  allocp[26] = x7;
  x8 = makefunctor(&allocp[24]);
  allocp[27] = (q)qp;
  allocp[28] = (q)(&predicate_type_xentry__indirect_3);
  allocp[29] = x8;
  allocp[30] = a10;
  allocp[31] = a11;
  a0 = a2;
  a1 = a3;
  a2 = a8;
  a3 = a9;
  a4 = x1;
  qp = (struct goalrec*)&allocp[27];
  allocp += 32;
  execute(entry__new__aliasvar__gen1_5_0);
  goto entry__new__aliasvar__gen1_5_ext_interrupt;
 case symval(makesym(atom_up)):
  allocp[0] = makesym(functor_v_4);
  allocp[1] = a2;
  allocp[2] = a3;
  allocp[3] = makeint(-1L);
  allocp[4] = x1 = makeref(&allocp[4]);
  x0 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a12, x0);
  allocp[0] = makesym(functor_v_4);
  allocp[1] = a2;
  allocp[2] = a3;
  allocp[3] = makeint(-1L);
  allocp[4] = x1;
  x2 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = a7;
  x3 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_4);
  allocp[8] = x2;
  allocp[9] = NILATOM;
  allocp[10] = x3;
  allocp[11] = makesym(atom__3F);
  x4 = makefunctor(&allocp[7]);
  allocp[12] = makesym(functor_v_4);
  allocp[13] = a2;
  allocp[14] = a3;
  allocp[15] = a4;
  allocp[16] = a5;
  x5 = makefunctor(&allocp[12]);
  allocp[17] = NILATOM;
  allocp[18] = a6;
  x6 = makecons(&allocp[17]);
  allocp[19] = makesym(functor_t_4);
  allocp[20] = x5;
  allocp[21] = NILATOM;
  allocp[22] = x6;
  allocp[23] = makesym(atom__3F);
  x7 = makefunctor(&allocp[19]);
  allocp[24] = makesym(functor_unifyaliasup_2);
  allocp[25] = x4;
  allocp[26] = x7;
  x8 = makefunctor(&allocp[24]);
  allocp[27] = (q)qp;
  allocp[28] = (q)(&predicate_type_xentry__indirect_3);
  allocp[29] = x8;
  allocp[30] = a10;
  allocp[31] = a11;
  a0 = a2;
  a1 = a3;
  a2 = a8;
  a3 = a9;
  a4 = x1;
  qp = (struct goalrec*)&allocp[27];
  allocp += 32;
  execute(entry__new__aliasvar__gen1_5_0);
  goto entry__new__aliasvar__gen1_5_ext_interrupt;
  };
  goto entry__new__aliasvar__gen_13_3;
 case VARREF:
  deref_and_jump(a1,entry__new__aliasvar__gen_13_2);
  *reasonp++ =  a1;
  goto entry__new__aliasvar__gen_13_3;
  };
  goto entry__new__aliasvar__gen_13_3;
 case VARREF:
  deref_and_jump(a0,entry__new__aliasvar__gen_13_1);
  *reasonp++ =  a0;
  goto entry__new__aliasvar__gen_13_3;
  };
  goto entry__new__aliasvar__gen_13_3;
 entry__new__aliasvar__gen_13_3:
  otherwise(entry__new__aliasvar__gen_13_interrupt);
  unify3(a12, a0, a9, a8, a11, a10);
  proceed();
 entry__new__aliasvar__gen_13_ext_interrupt:
  reasonp = 0l;
 entry__new__aliasvar__gen_13_interrupt:
  goto interrupt_13;
 }

 entry__new__aliasvar__gen1_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 entry__new__aliasvar__gen1_5_clear_reason:
  reasonp = reasons;
 entry__new__aliasvar__gen1_5_0:
 entry__new__aliasvar__gen1_5_1:
  switch (ptagof(a2)) {
 case CONS:
  x0 = car_of(a2);
 entry__new__aliasvar__gen1_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto entry__new__aliasvar__gen1_5_7;
  x1 = arg(x0, 0);
 entry__new__aliasvar__gen1_5_3:
  if (isref(x1)) goto entry__new__aliasvar__gen1_5_6;
 entry__new__aliasvar__gen1_5_4:
  if (isref(x1)) goto entry__new__aliasvar__gen1_5_5;
  if_not_equal(x1, a0, entry__new__aliasvar__gen1_5_7);
  allocp[0] = makesym(functor_module_2);
  allocp[1] = a0;
  allocp[2] = x3 = makeref(&allocp[2]);
  x2 = makefunctor(&allocp[0]);
  allocp[3] = cdr_of(a2);
  allocp[4] = x2;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a3, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = a1;
  x5 = arg(x0, 1);
  allocp[3] = x5;
  allocp[4] = x6 = makeref(&allocp[4]);
  allocp[5] = x3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor_xinsert__arg_4);
  allocp[8] = x7 = makeref(&allocp[8]);
  allocp[9] = x8 = makeref(&allocp[9]);
  allocp[10] = makecons(cons_const_0);
  allocp[11] = x6;
  allocp[12] = (q)(struct goalrec*)&allocp[6];
  allocp[13] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[14] = x9 = makeref(&allocp[14]);
  allocp[15] = makeint(1L);
  allocp[16] = x7;
  qp = (struct goalrec*)&allocp[12];
  allocp += 17;
  unify(a4, x9);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[2] = x8;
  allocp[3] = x10 = makeref(&allocp[3]);
  allocp[4] = x9;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = a1;
  allocp[8] = x5;
  allocp[9] = x8;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 entry__new__aliasvar__gen1_5_5:
  deref_and_jump(x1,entry__new__aliasvar__gen1_5_4);
  *reasonp++ =  x1;
  goto entry__new__aliasvar__gen1_5_7;
 entry__new__aliasvar__gen1_5_6:
  deref_and_jump(x1,entry__new__aliasvar__gen1_5_3);
  *reasonp++ =  x1;
  goto entry__new__aliasvar__gen1_5_7;
 case VARREF:
  deref_and_jump(x0,entry__new__aliasvar__gen1_5_2);
  *reasonp++ =  x0;
  goto entry__new__aliasvar__gen1_5_7;
  };
  goto entry__new__aliasvar__gen1_5_7;
 case VARREF:
  deref_and_jump(a2,entry__new__aliasvar__gen1_5_1);
  *reasonp++ =  a2;
  goto entry__new__aliasvar__gen1_5_7;
  };
  goto entry__new__aliasvar__gen1_5_7;
 entry__new__aliasvar__gen1_5_7:
  otherwise(entry__new__aliasvar__gen1_5_interrupt);
 entry__new__aliasvar__gen1_5_8:
  switch (ptagof(a2)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = car_of(a2);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a3, x0);
  a2 = cdr_of(a2);
  a3 = x1;
  execute(entry__new__aliasvar__gen1_5_0);
  goto entry__new__aliasvar__gen1_5_ext_interrupt;
 case ATOMIC:
  if (a2 != NILATOM) goto entry__new__aliasvar__gen1_5_interrupt;
  x0 = makesym(atom_error);
  unify(x0, makesym(atom_entry__new__aliasvar__gen1));
  proceed();
 case VARREF:
  deref_and_jump(a2,entry__new__aliasvar__gen1_5_8);
  *reasonp++ =  a2;
  goto entry__new__aliasvar__gen1_5_interrupt;
  };
  goto entry__new__aliasvar__gen1_5_interrupt;
 entry__new__aliasvar__gen1_5_ext_interrupt:
  reasonp = 0l;
 entry__new__aliasvar__gen1_5_interrupt:
  toppred = &predicate_type_xentry__new__aliasvar__gen1_5;
  goto interrupt_5;
 }

 set__types_11_top: {
  q x0;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 set__types_11_clear_reason:
  reasonp = reasons;
 set__types_11_0:
  a11 = NILATOM;
  allocp[0] = x0 = makeref(&allocp[0]);
  a12 = x0;
  allocp += 1;
  execute(set__types_13_0);
  goto set__types_13_ext_interrupt;
 set__types_11_ext_interrupt:
  reasonp = 0l;
 set__types_11_interrupt:
  goto interrupt_11;
 }

 set__types_13_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  qp = qp->next;
 set__types_13_clear_reason:
  reasonp = reasons;
 set__types_13_0:
 set__types_13_1:
  switch (ptagof(a4)) {
 case FUNCTOR:
  if (functor_of(a4) != makesym(functor_variable_3)) goto set__types_13_2;
  a4 = arg(a4, 0);
  execute(set__types_13_0);
  goto set__types_13_ext_interrupt;
 case VARREF:
  deref_and_jump(a4,set__types_13_1);
  *reasonp++ =  a4;
  goto set__types_13_2;
  };
  goto set__types_13_2;
 set__types_13_2:
  otherwise(set__types_13_interrupt);
 set__types_13_3:
  if (!isint(a4)) goto set__types_13_4;
  gblt_integer(a4,set__types_13_5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xset__types1_13);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = x0 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  allocp[12] = a10;
  allocp[13] = a11;
  allocp[14] = a12;
  allocp[15] = makesym(functor_v_4);
  allocp[16] = a0;
  allocp[17] = a1;
  allocp[18] = makesym(atom___);
  allocp[19] = a4;
  x1 = makefunctor(&allocp[15]);
  allocp[20] = (q)(struct goalrec*)&allocp[0];
  allocp[21] = (q)(&predicate_list_xdelete__incomplete__element_3);
  allocp[22] = x1;
  allocp[23] = a6;
  allocp[24] = x0;
  qp = (struct goalrec*)&allocp[20];
  allocp += 25;
  proceed();
 set__types_13_4:
  if (!isref(a4)) goto set__types_13_5;
  deref_and_jump(a4,set__types_13_3);
  *reasonp++ =  a4;
  goto set__types_13_5;
 set__types_13_5:
  otherwise(set__types_13_interrupt);
  unify3(a8, a7, a10, a9, a12, a11);
  proceed();
 set__types_13_ext_interrupt:
  reasonp = 0l;
 set__types_13_interrupt:
  toppred = &predicate_type_xset__types_13;
  goto interrupt_13;
 }

 set__types1_13_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  qp = qp->next;
 set__types1_13_clear_reason:
  reasonp = reasons;
 set__types1_13_0:
 set__types1_13_1:
  switch (ptagof(a7)) {
 case CONS:
  x0 = car_of(a7);
 set__types1_13_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto set__types1_13_7;
  x1 = arg(x0, 0);
 set__types1_13_3:
  if (isref(x1)) goto set__types1_13_6;
 set__types1_13_4:
  if (isref(x1)) goto set__types1_13_5;
  if_not_equal(x1, a0, set__types1_13_7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xentry__updated_10);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = a0;
  allocp[5] = a1;
  allocp[6] = a2;
  allocp[7] = a3;
  allocp[8] = a4;
  allocp[9] = a5;
  allocp[10] = a9;
  allocp[11] = a10;
  allocp[12] = makesym(functor_module_2);
  allocp[13] = a0;
  allocp[14] = x5 = makeref(&allocp[14]);
  x4 = makefunctor(&allocp[12]);
  allocp[15] = cdr_of(a7);
  allocp[16] = x4;
  x6 = makecons(&allocp[15]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 17;
  unify_value(a8, x6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = a1;
  x7 = arg(x0, 1);
  allocp[3] = x7;
  allocp[4] = x8 = makeref(&allocp[4]);
  allocp[5] = x5;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[8] = x9 = makeref(&allocp[8]);
  allocp[9] = x10 = makeref(&allocp[9]);
  allocp[10] = x3;
  allocp[11] = x8;
  allocp[12] = (q)(struct goalrec*)&allocp[6];
  allocp[13] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[14] = a4;
  allocp[15] = makeint(1L);
  allocp[16] = x9;
  allocp[17] = (q)(struct goalrec*)&allocp[12];
  allocp[18] = (q)(&predicate_type_xand__types_5);
  allocp[19] = x2;
  allocp[20] = x11 = makeref(&allocp[20]);
  allocp[21] = x3;
  allocp[22] = a11;
  allocp[23] = a12;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_functor__table_xarg_3);
  allocp[26] = x12 = makeref(&allocp[26]);
  allocp[27] = x10;
  allocp[28] = x2;
  allocp[29] = (q)(struct goalrec*)&allocp[24];
  allocp[30] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[31] = a4;
  allocp[32] = makeint(1L);
  allocp[33] = x12;
  allocp[34] = (q)(struct goalrec*)&allocp[29];
  allocp[35] = (q)(&predicate_functor__table_xarg_3);
  allocp[36] = a1;
  allocp[37] = x7;
  allocp[38] = x10;
  a0 = a6;
  a1 = x11;
  qp = (struct goalrec*)&allocp[34];
  allocp += 39;
  execute(clear__depgoals_2_clear_reason);
  goto clear__depgoals_2_ext_interrupt;
 set__types1_13_5:
  deref_and_jump(x1,set__types1_13_4);
  *reasonp++ =  x1;
  goto set__types1_13_7;
 set__types1_13_6:
  deref_and_jump(x1,set__types1_13_3);
  *reasonp++ =  x1;
  goto set__types1_13_7;
 case VARREF:
  deref_and_jump(x0,set__types1_13_2);
  *reasonp++ =  x0;
  goto set__types1_13_7;
  };
  goto set__types1_13_7;
 case VARREF:
  deref_and_jump(a7,set__types1_13_1);
  *reasonp++ =  a7;
  goto set__types1_13_7;
  };
  goto set__types1_13_7;
 set__types1_13_7:
  otherwise(set__types1_13_interrupt);
 set__types1_13_8:
  switch (ptagof(a7)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = car_of(a7);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a8, x0);
  a7 = cdr_of(a7);
  a8 = x1;
  execute(set__types1_13_0);
  goto set__types1_13_ext_interrupt;
 case VARREF:
  deref_and_jump(a7,set__types1_13_8);
  *reasonp++ =  a7;
  goto set__types1_13_interrupt;
  };
  goto set__types1_13_interrupt;
 set__types1_13_ext_interrupt:
  reasonp = 0l;
 set__types1_13_interrupt:
  goto interrupt_13;
 }

 entry__updated_10_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 entry__updated_10_clear_reason:
  reasonp = reasons;
 entry__updated_10_0:
 entry__updated_10_1:
  if (isref(a0)) goto entry__updated_10_4;
 entry__updated_10_2:
  if (isref(a0)) goto entry__updated_10_3;
  if_not_equal(a0, a1, entry__updated_10_5);
  unify(a9, a8);
  proceed();
 entry__updated_10_3:
  deref_and_jump(a0,entry__updated_10_2);
  *reasonp++ =  a0;
  goto entry__updated_10_5;
 entry__updated_10_4:
  deref_and_jump(a0,entry__updated_10_1);
  *reasonp++ =  a0;
  goto entry__updated_10_5;
 entry__updated_10_5:
  otherwise(entry__updated_10_interrupt);
 entry__updated_10_6:
  switch (ptagof(a4)) {
 case ATOMIC:
  if (a4 != makesym(atom_head)) goto entry__updated_10_7;
  allocp[0] = makesym(functor_variable_3);
  allocp[1] = a6;
  allocp[2] = makeint(0L);
  allocp[3] = x1 = makeref(&allocp[3]);
  x0 = makefunctor(&allocp[0]);
  allocp[4] = makesym(functor_var_5);
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = x0;
  x2 = makefunctor(&allocp[4]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_list_xappend_3);
  allocp[14] = a8;
  allocp[15] = x3;
  allocp[16] = a9;
  allocp[17] = (q)(struct goalrec*)&allocp[12];
  allocp[18] = (q)(&predicate_mode_xreverse__mode_2);
  allocp[19] = a7;
  allocp[20] = x1;
  qp = (struct goalrec*)&allocp[17];
  allocp += 21;
  proceed();
 case VARREF:
  deref_and_jump(a4,entry__updated_10_6);
  *reasonp++ =  a4;
  goto entry__updated_10_7;
  };
  goto entry__updated_10_7;
 entry__updated_10_7:
  otherwise(entry__updated_10_interrupt);
  allocp[0] = makesym(functor_variable_3);
  allocp[1] = a6;
  allocp[2] = makeint(0L);
  allocp[3] = a7;
  x0 = makefunctor(&allocp[0]);
  allocp[4] = makesym(functor_var_5);
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = x0;
  x1 = makefunctor(&allocp[4]);
  allocp[10] = NILATOM;
  allocp[11] = x1;
  x2 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_list_xappend_3);
  allocp[14] = a8;
  allocp[15] = x2;
  allocp[16] = a9;
  qp = (struct goalrec*)&allocp[12];
  allocp += 17;
  proceed();
 entry__updated_10_ext_interrupt:
  reasonp = 0l;
 entry__updated_10_interrupt:
  goto interrupt_10;
 }

 clear__depgoals_2_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  qp = qp->next;
 clear__depgoals_2_clear_reason:
  reasonp = reasons;
 clear__depgoals_2_0:
  x0 = opt_analyze_dependency;
 clear__depgoals_2_1:
  if (x0 != makeint(1L)) goto clear__depgoals_2_2;
  unify(a1, a0);
  proceed();
 clear__depgoals_2_2:
  otherwise(clear__depgoals_2_interrupt);
 clear__depgoals_2_3:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 clear__depgoals_2_4:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__3F)) goto clear__depgoals_2_interrupt;
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = makesym(atom__3F);
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x1);
  a0 = cdr_of(a0);
  a1 = x2;
  execute(clear__depgoals_2_0);
  goto clear__depgoals_2_ext_interrupt;
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_4)) goto clear__depgoals_2_interrupt;
  allocp[0] = makesym(functor_t_4);
  allocp[1] = arg(x0, 0);
  allocp[2] = NILATOM;
  allocp[3] = NILATOM;
  allocp[4] = arg(x0, 3);
  x1 = makefunctor(&allocp[0]);
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = x1;
  x2 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a1, x2);
  a0 = cdr_of(a0);
  a1 = x3;
  execute(clear__depgoals_2_0);
  goto clear__depgoals_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,clear__depgoals_2_4);
  *reasonp++ =  x0;
  goto clear__depgoals_2_interrupt;
  };
  goto clear__depgoals_2_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto clear__depgoals_2_interrupt;
  unify_value(a1, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a0,clear__depgoals_2_3);
  *reasonp++ =  a0;
  goto clear__depgoals_2_interrupt;
  };
  goto clear__depgoals_2_interrupt;
 clear__depgoals_2_ext_interrupt:
  reasonp = 0l;
 clear__depgoals_2_interrupt:
  toppred = &predicate_type_xclear__depgoals_2;
  goto interrupt_2;
 }

 and__types_4_top: {
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 and__types_4_clear_reason:
  reasonp = reasons;
 and__types_4_0:
  a4 = a3;
  a3 = NILATOM;
  execute(and__types_5_0);
  goto and__types_5_ext_interrupt;
 and__types_4_ext_interrupt:
  reasonp = 0l;
 and__types_4_interrupt:
  goto interrupt_4;
 }

 and__types_5_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 and__types_5_clear_reason:
  reasonp = reasons;
 and__types_5_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xand__types1_7);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = a2;
  allocp[7] = a3;
  allocp[8] = a4;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_type_xsplit__types__var__val_3);
  allocp[11] = a1;
  allocp[12] = x1;
  allocp[13] = x3;
  a1 = x0;
  a2 = x2;
  qp = (struct goalrec*)&allocp[9];
  allocp += 14;
  execute(split__types__var__val_3_0);
  goto split__types__var__val_3_ext_interrupt;
 and__types_5_ext_interrupt:
  reasonp = 0l;
 and__types_5_interrupt:
  toppred = &predicate_type_xand__types_5;
  goto interrupt_5;
 }

 and__types1_7_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 and__types1_7_clear_reason:
  reasonp = reasons;
 and__types1_7_0:
 and__types1_7_1:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != NILATOM) goto and__types1_7_3;
 and__types1_7_2:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != NILATOM) goto and__types1_7_3;
  a2 = a4;
  a3 = a5;
  a4 = a6;
  execute(and__types__val_5_0);
  goto and__types__val_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a3,and__types1_7_2);
  *reasonp++ =  a3;
  goto and__types1_7_3;
  };
  goto and__types1_7_3;
 case VARREF:
  deref_and_jump(a2,and__types1_7_1);
  *reasonp++ =  a2;
  goto and__types1_7_3;
  };
  goto and__types1_7_3;
 and__types1_7_3:
  otherwise(and__types1_7_interrupt);
 and__types1_7_4:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != NILATOM) goto and__types1_7_5;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xmake__indirect__unify_4);
  allocp[2] = a3;
  allocp[3] = a0;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = a6;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_type_xand__types__val_5);
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a0;
  allocp[10] = a4;
  allocp[11] = a5;
  allocp[12] = x0;
  a2 = x1;
  qp = (struct goalrec*)&allocp[6];
  allocp += 13;
  execute(or__types_3_0);
  goto or__types_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,and__types1_7_4);
  *reasonp++ =  a2;
  goto and__types1_7_5;
  };
  goto and__types1_7_5;
 and__types1_7_5:
  otherwise(and__types1_7_interrupt);
 and__types1_7_6:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != NILATOM) goto and__types1_7_7;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xmake__indirect__unify_4);
  allocp[2] = a2;
  allocp[3] = a1;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = a6;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_type_xand__types__val_5);
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a1;
  allocp[10] = a4;
  allocp[11] = a5;
  allocp[12] = x0;
  a2 = x1;
  qp = (struct goalrec*)&allocp[6];
  allocp += 13;
  execute(or__types_3_0);
  goto or__types_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a3,and__types1_7_6);
  *reasonp++ =  a3;
  goto and__types1_7_7;
  };
  goto and__types1_7_7;
 and__types1_7_7:
  otherwise(and__types1_7_interrupt);
 and__types1_7_8:
  switch (ptagof(a2)) {
 case CONS:
  x0 = car_of(a2);
 and__types1_7_9:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__3F)) goto and__types1_7_12;
 and__types1_7_10:
  switch (ptagof(a3)) {
 case CONS:
  x1 = car_of(a3);
 and__types1_7_11:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom__3F)) goto and__types1_7_12;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xmake__indirect__unify_4);
  x2 = cdr_of(a2);
  allocp[2] = x2;
  x3 = cdr_of(a3);
  allocp[3] = x3;
  allocp[4] = a5;
  allocp[5] = a6;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_list_xappend_3);
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = x5 = makeref(&allocp[9]);
  allocp[10] = a4;
  allocp[11] = x2;
  allocp[12] = makesym(atom__3F);
  x6 = makecons(&allocp[11]);
  allocp[13] = (q)(struct goalrec*)&allocp[6];
  allocp[14] = (q)(&predicate_type_xor__types_3);
  allocp[15] = x6;
  allocp[16] = x3;
  allocp[17] = x4;
  a2 = x5;
  qp = (struct goalrec*)&allocp[13];
  allocp += 18;
  execute(or__types_3_0);
  goto or__types_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,and__types1_7_11);
  *reasonp++ =  x1;
  goto and__types1_7_12;
  };
  goto and__types1_7_12;
 case VARREF:
  deref_and_jump(a3,and__types1_7_10);
  *reasonp++ =  a3;
  goto and__types1_7_12;
  };
  goto and__types1_7_12;
 case VARREF:
  deref_and_jump(x0,and__types1_7_9);
  *reasonp++ =  x0;
  goto and__types1_7_12;
  };
  goto and__types1_7_12;
 case VARREF:
  deref_and_jump(a2,and__types1_7_8);
  *reasonp++ =  a2;
  goto and__types1_7_12;
  };
  goto and__types1_7_12;
 and__types1_7_12:
  otherwise(and__types1_7_interrupt);
 and__types1_7_13:
  switch (ptagof(a2)) {
 case CONS:
  x0 = car_of(a2);
 and__types1_7_14:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__3F)) goto and__types1_7_15;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xmake__indirect__unify_4);
  x1 = cdr_of(a2);
  allocp[2] = x1;
  allocp[3] = a3;
  allocp[4] = a5;
  allocp[5] = a6;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_list_xappend_3);
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = x3 = makeref(&allocp[9]);
  allocp[10] = a4;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_type_xor__types_3);
  allocp[13] = x1;
  allocp[14] = a3;
  allocp[15] = x2;
  a2 = x3;
  qp = (struct goalrec*)&allocp[11];
  allocp += 16;
  execute(or__types_3_0);
  goto or__types_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,and__types1_7_14);
  *reasonp++ =  x0;
  goto and__types1_7_15;
  };
  goto and__types1_7_15;
 case VARREF:
  deref_and_jump(a2,and__types1_7_13);
  *reasonp++ =  a2;
  goto and__types1_7_15;
  };
  goto and__types1_7_15;
 and__types1_7_15:
 and__types1_7_16:
  switch (ptagof(a3)) {
 case CONS:
  x0 = car_of(a3);
 and__types1_7_17:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__3F)) goto and__types1_7_18;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xmake__indirect__unify_4);
  allocp[2] = a2;
  x1 = cdr_of(a3);
  allocp[3] = x1;
  allocp[4] = a5;
  allocp[5] = a6;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_list_xappend_3);
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = x3 = makeref(&allocp[9]);
  allocp[10] = a4;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_type_xor__types_3);
  allocp[13] = a2;
  allocp[14] = x1;
  allocp[15] = x2;
  a2 = x3;
  qp = (struct goalrec*)&allocp[11];
  allocp += 16;
  execute(or__types_3_clear_reason);
  goto or__types_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,and__types1_7_17);
  *reasonp++ =  x0;
  goto and__types1_7_18;
  };
  goto and__types1_7_18;
 case VARREF:
  deref_and_jump(a3,and__types1_7_16);
  *reasonp++ =  a3;
  goto and__types1_7_18;
  };
  goto and__types1_7_18;
 and__types1_7_18:
  otherwise(and__types1_7_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xmake__indirect__unify_4);
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a5;
  allocp[5] = a6;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_list_xappend_3);
  allocp[8] = x0 = makeref(&allocp[8]);
  allocp[9] = x1 = makeref(&allocp[9]);
  allocp[10] = a4;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_type_xor__types_3);
  allocp[13] = a2;
  allocp[14] = a3;
  allocp[15] = x0;
  a2 = x1;
  qp = (struct goalrec*)&allocp[11];
  allocp += 16;
  execute(or__types_3_0);
  goto or__types_3_ext_interrupt;
 and__types1_7_ext_interrupt:
  reasonp = 0l;
 and__types1_7_interrupt:
  goto interrupt_7;
 }

 and__types__val_5_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 and__types__val_5_clear_reason:
  reasonp = reasons;
 and__types__val_5_0:
 and__types__val_5_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xand__types__val_5);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = a1;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  a0 = car_of(a0);
  x3 = a2;
  a4 = a3;
  a5 = x2;
  a3 = x3;
  a2 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(and__types__val1_6_0);
  goto and__types__val1_6_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto and__types__val_5_interrupt;
  unify_value(a2, NILATOM);
  unify(a4, a3);
  proceed();
 case VARREF:
  deref_and_jump(a0,and__types__val_5_1);
  *reasonp++ =  a0;
  goto and__types__val_5_interrupt;
  };
  goto and__types__val_5_interrupt;
 and__types__val_5_ext_interrupt:
  reasonp = 0l;
 and__types__val_5_interrupt:
  toppred = &predicate_type_xand__types__val_5;
  goto interrupt_5;
 }

 and__types__val1_6_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 and__types__val1_6_clear_reason:
  reasonp = reasons;
 and__types__val1_6_0:
 and__types__val1_6_1:
  switch (ptagof(a1)) {
 case CONS:
 and__types__val1_6_2:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_t_4)) goto and__types__val1_6_interrupt;
  x0 = car_of(a1);
 and__types__val1_6_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_4)) goto and__types__val1_6_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xand__types__val2_9);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = x0;
  allocp[5] = x2 = makeref(&allocp[5]);
  x3 = cdr_of(a1);
  allocp[6] = x3;
  allocp[7] = a2;
  allocp[8] = a3;
  allocp[9] = x4 = makeref(&allocp[9]);
  allocp[10] = a5;
  x5 = arg(a0, 0);
  a1 = arg(x0, 0);
  a2 = x2;
  a3 = arg(a0, 1);
  x6 = arg(x0, 1);
  a5 = arg(a0, 2);
  a6 = arg(x0, 2);
  a7 = x1;
  a8 = a4;
  a9 = x4;
  a4 = x6;
  a0 = x5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 11;
  execute(and__type__element_10_0);
  goto and__type__element_10_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,and__types__val1_6_3);
  *reasonp++ =  x0;
  goto and__types__val1_6_interrupt;
  };
  goto and__types__val1_6_interrupt;
 case VARREF:
  deref_and_jump(a0,and__types__val1_6_2);
  *reasonp++ =  a0;
  goto and__types__val1_6_interrupt;
  };
  goto and__types__val1_6_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto and__types__val1_6_interrupt;
  unify2(a3, a2, a5, a4);
  proceed();
 case VARREF:
  deref_and_jump(a1,and__types__val1_6_1);
  *reasonp++ =  a1;
  goto and__types__val1_6_interrupt;
  };
  goto and__types__val1_6_interrupt;
 and__types__val1_6_ext_interrupt:
  reasonp = 0l;
 and__types__val1_6_interrupt:
  toppred = &predicate_type_xand__types__val1_6;
  goto interrupt_6;
 }

 and__types__val2_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 and__types__val2_9_clear_reason:
  reasonp = reasons;
 and__types__val2_9_0:
 and__types__val2_9_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto and__types__val2_9_6;
  switch (symval(a0)) {
 case symval(makesym(atom_no)):
  a0 = a1;
  a1 = a4;
  a2 = a5;
  a3 = a6;
  a4 = a7;
  a5 = a8;
  execute(and__types__val1_6_0);
  goto and__types__val1_6_ext_interrupt;
 case symval(makesym(atom_yes)):
 and__types__val2_9_2:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_t_4)) goto and__types__val2_9_6;
  x0 = arg(a1, 3);
 and__types__val2_9_3:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_u)) goto and__types__val2_9_6;
 and__types__val2_9_4:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_t_4)) goto and__types__val2_9_6;
  x1 = arg(a2, 3);
 and__types__val2_9_5:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_u)) goto and__types__val2_9_6;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xand__types__val1_6);
  allocp[2] = a1;
  allocp[3] = a4;
  allocp[4] = a5;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a7;
  allocp[7] = a8;
  allocp[8] = makesym(functor_t_4);
  allocp[9] = a3;
  allocp[10] = x4 = makeref(&allocp[10]);
  allocp[11] = x5 = makeref(&allocp[11]);
  allocp[12] = makesym(atom_u);
  x3 = makefunctor(&allocp[8]);
  allocp[13] = x2;
  allocp[14] = x3;
  x6 = makecons(&allocp[13]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 15;
  unify_value(a6, x6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xmerge__goals_3);
  x7 = arg(a1, 2);
  allocp[2] = x7;
  x8 = arg(a2, 2);
  allocp[3] = x8;
  allocp[4] = x5;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_list_xor__unique_3);
  x9 = arg(a1, 1);
  allocp[7] = x9;
  x10 = arg(a2, 1);
  allocp[8] = x10;
  allocp[9] = x4;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(x1,and__types__val2_9_5);
  *reasonp++ =  x1;
  goto and__types__val2_9_6;
  };
  goto and__types__val2_9_6;
 case VARREF:
  deref_and_jump(a2,and__types__val2_9_4);
  *reasonp++ =  a2;
  goto and__types__val2_9_6;
  };
  goto and__types__val2_9_6;
 case VARREF:
  deref_and_jump(x0,and__types__val2_9_3);
  *reasonp++ =  x0;
  goto and__types__val2_9_6;
  };
  goto and__types__val2_9_6;
 case VARREF:
  deref_and_jump(a1,and__types__val2_9_2);
  *reasonp++ =  a1;
  goto and__types__val2_9_6;
  };
  goto and__types__val2_9_6;
  };
  goto and__types__val2_9_6;
 case VARREF:
  deref_and_jump(a0,and__types__val2_9_1);
  *reasonp++ =  a0;
  goto and__types__val2_9_6;
  };
  goto and__types__val2_9_6;
 and__types__val2_9_6:
  otherwise(and__types__val2_9_interrupt);
 and__types__val2_9_7:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_yes)) goto and__types__val2_9_14;
 and__types__val2_9_8:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_t_4)) goto and__types__val2_9_14;
  x0 = arg(a1, 3);
 and__types__val2_9_9:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_u)) goto and__types__val2_9_11;
 and__types__val2_9_10:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_t_4)) goto and__types__val2_9_11;
  allocp[0] = a5;
  allocp[1] = a1;
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a6, x1);
  unify(a8, a7);
  proceed();
 case VARREF:
  deref_and_jump(a2,and__types__val2_9_10);
  *reasonp++ =  a2;
  goto and__types__val2_9_11;
  };
  goto and__types__val2_9_11;
 case VARREF:
  deref_and_jump(x0,and__types__val2_9_9);
  *reasonp++ =  x0;
  goto and__types__val2_9_11;
  };
  goto and__types__val2_9_11;
 and__types__val2_9_11:
 and__types__val2_9_12:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_t_4)) goto and__types__val2_9_14;
  x1 = arg(a2, 3);
 and__types__val2_9_13:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_u)) goto and__types__val2_9_14;
  allocp[0] = a5;
  allocp[1] = a2;
  x2 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a6, x2);
  unify(a8, a7);
  proceed();
 case VARREF:
  deref_and_jump(x1,and__types__val2_9_13);
  *reasonp++ =  x1;
  goto and__types__val2_9_14;
  };
  goto and__types__val2_9_14;
 case VARREF:
  deref_and_jump(a2,and__types__val2_9_12);
  *reasonp++ =  a2;
  goto and__types__val2_9_14;
  };
  goto and__types__val2_9_14;
 case VARREF:
  deref_and_jump(a1,and__types__val2_9_8);
  *reasonp++ =  a1;
  goto and__types__val2_9_14;
  };
  goto and__types__val2_9_14;
 case VARREF:
  deref_and_jump(a0,and__types__val2_9_7);
  *reasonp++ =  a0;
  goto and__types__val2_9_14;
  };
  goto and__types__val2_9_14;
 and__types__val2_9_14:
  otherwise(and__types__val2_9_interrupt);
 and__types__val2_9_15:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_yes)) goto and__types__val2_9_22;
 and__types__val2_9_16:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_t_4)) goto and__types__val2_9_22;
  x0 = arg(a1, 3);
 and__types__val2_9_17:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_r)) goto and__types__val2_9_19;
 and__types__val2_9_18:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_t_4)) goto and__types__val2_9_19;
  unify(a8, a7);
  allocp[0] = makesym(functor_t_4);
  allocp[1] = a3;
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = makesym(atom_r);
  x1 = makefunctor(&allocp[0]);
  allocp[5] = a5;
  allocp[6] = x1;
  x4 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a6, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xmerge__goals_3);
  x5 = arg(a1, 2);
  allocp[2] = x5;
  x6 = arg(a2, 2);
  allocp[3] = x6;
  allocp[4] = x3;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_list_xor__unique_3);
  x7 = arg(a1, 1);
  allocp[7] = x7;
  x8 = arg(a2, 1);
  allocp[8] = x8;
  allocp[9] = x2;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a2,and__types__val2_9_18);
  *reasonp++ =  a2;
  goto and__types__val2_9_19;
  };
  goto and__types__val2_9_19;
 case VARREF:
  deref_and_jump(x0,and__types__val2_9_17);
  *reasonp++ =  x0;
  goto and__types__val2_9_19;
  };
  goto and__types__val2_9_19;
 and__types__val2_9_19:
 and__types__val2_9_20:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_t_4)) goto and__types__val2_9_22;
  x1 = arg(a2, 3);
 and__types__val2_9_21:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_r)) goto and__types__val2_9_22;
  unify(a8, a7);
  allocp[0] = makesym(functor_t_4);
  allocp[1] = a3;
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = x4 = makeref(&allocp[3]);
  allocp[4] = makesym(atom_r);
  x2 = makefunctor(&allocp[0]);
  allocp[5] = a5;
  allocp[6] = x2;
  x5 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a6, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xmerge__goals_3);
  x6 = arg(a1, 2);
  allocp[2] = x6;
  x7 = arg(a2, 2);
  allocp[3] = x7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_list_xor__unique_3);
  x8 = arg(a1, 1);
  allocp[7] = x8;
  x9 = arg(a2, 1);
  allocp[8] = x9;
  allocp[9] = x3;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(x1,and__types__val2_9_21);
  *reasonp++ =  x1;
  goto and__types__val2_9_22;
  };
  goto and__types__val2_9_22;
 case VARREF:
  deref_and_jump(a2,and__types__val2_9_20);
  *reasonp++ =  a2;
  goto and__types__val2_9_22;
  };
  goto and__types__val2_9_22;
 case VARREF:
  deref_and_jump(a1,and__types__val2_9_16);
  *reasonp++ =  a1;
  goto and__types__val2_9_22;
  };
  goto and__types__val2_9_22;
 case VARREF:
  deref_and_jump(a0,and__types__val2_9_15);
  *reasonp++ =  a0;
  goto and__types__val2_9_22;
  };
  goto and__types__val2_9_22;
 and__types__val2_9_22:
  otherwise(and__types__val2_9_interrupt);
 and__types__val2_9_23:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_yes)) goto and__types__val2_9_interrupt;
 and__types__val2_9_24:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_t_4)) goto and__types__val2_9_interrupt;
  x0 = arg(a1, 3);
 and__types__val2_9_25:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__3F)) goto and__types__val2_9_interrupt;
 and__types__val2_9_26:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_t_4)) goto and__types__val2_9_interrupt;
  x1 = arg(a2, 3);
 and__types__val2_9_27:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom__3F)) goto and__types__val2_9_interrupt;
  unify(a8, a7);
  allocp[0] = makesym(functor_t_4);
  allocp[1] = a3;
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = x4 = makeref(&allocp[3]);
  allocp[4] = makesym(atom__3F);
  x2 = makefunctor(&allocp[0]);
  allocp[5] = a5;
  allocp[6] = x2;
  x5 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a6, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xmerge__goals_3);
  x6 = arg(a1, 2);
  allocp[2] = x6;
  x7 = arg(a2, 2);
  allocp[3] = x7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_list_xor__unique_3);
  x8 = arg(a1, 1);
  allocp[7] = x8;
  x9 = arg(a2, 1);
  allocp[8] = x9;
  allocp[9] = x3;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(x1,and__types__val2_9_27);
  *reasonp++ =  x1;
  goto and__types__val2_9_interrupt;
  };
  goto and__types__val2_9_interrupt;
 case VARREF:
  deref_and_jump(a2,and__types__val2_9_26);
  *reasonp++ =  a2;
  goto and__types__val2_9_interrupt;
  };
  goto and__types__val2_9_interrupt;
 case VARREF:
  deref_and_jump(x0,and__types__val2_9_25);
  *reasonp++ =  x0;
  goto and__types__val2_9_interrupt;
  };
  goto and__types__val2_9_interrupt;
 case VARREF:
  deref_and_jump(a1,and__types__val2_9_24);
  *reasonp++ =  a1;
  goto and__types__val2_9_interrupt;
  };
  goto and__types__val2_9_interrupt;
 case VARREF:
  deref_and_jump(a0,and__types__val2_9_23);
  *reasonp++ =  a0;
  goto and__types__val2_9_interrupt;
  };
  goto and__types__val2_9_interrupt;
 and__types__val2_9_ext_interrupt:
  reasonp = 0l;
 and__types__val2_9_interrupt:
  goto interrupt_9;
 }

 and__type__element_10_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 and__type__element_10_clear_reason:
  reasonp = reasons;
 and__type__element_10_0:
 and__type__element_10_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_s_3)) goto and__type__element_10_3;
 and__type__element_10_2:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_s_3)) goto and__type__element_10_3;
  x0 = arg(a0, 0);
  x1 = arg(a1, 0);
  x2 = arg(a0, 1);
  x3 = arg(a1, 1);
  x4 = arg(a0, 2);
  x5 = arg(a1, 2);
  x6 = a2;
  x7 = a3;
  x8 = a4;
  x9 = a5;
  a10 = a6;
  a11 = a7;
  a12 = a8;
  a13 = a9;
  a9 = x9;
  a8 = x8;
  a7 = x7;
  a6 = x6;
  a5 = x5;
  a4 = x4;
  a3 = x3;
  a2 = x2;
  a1 = x1;
  a0 = x0;
  execute(and__type__element__struct_14_0);
  goto and__type__element__struct_14_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,and__type__element_10_2);
  *reasonp++ =  a1;
  goto and__type__element_10_3;
  };
  goto and__type__element_10_3;
 case VARREF:
  deref_and_jump(a0,and__type__element_10_1);
  *reasonp++ =  a0;
  goto and__type__element_10_12;
  };
  goto and__type__element_10_3;
 and__type__element_10_3:
  gblt_pfunctor(a0,x0,and__type__element_10_12);
  if (isint(x0)) goto and__type__element_10_12;
  switch (symval(x0)) {
 case symval(makesym(atom_a)):
  gblt_arity(a0,x1,and__type__element_10_12);
 and__type__element_10_4:
  if (isref(a1)) goto and__type__element_10_5;
  gblt_pfunctor(a1,x2,and__type__element_10_12);
  if (x2 != makesym(atom_a)) goto and__type__element_10_12;
  gblt_arity(a1,x3,and__type__element_10_12);
  unify(a9, a8);
  unify_value(a7, makesym(atom_yes));
  x4 = a0;
  x5 = a1;
  a3 = a2;
  a2 = x5;
  a1 = x4;
  a0 = makesym(atom_and);
  execute(merge__atomic_4_0);
  goto merge__atomic_4_ext_interrupt;
 and__type__element_10_5:
  deref_and_jump(a1,and__type__element_10_4);
  *reasonp++ =  a1;
  goto and__type__element_10_12;
 case symval(makesym(atom_i)):
  gblt_arity(a0,x1,and__type__element_10_12);
 and__type__element_10_6:
  if (isref(a1)) goto and__type__element_10_7;
  gblt_pfunctor(a1,x2,and__type__element_10_12);
  if (x2 != makesym(atom_i)) goto and__type__element_10_12;
  gblt_arity(a1,x3,and__type__element_10_12);
  unify(a9, a8);
  unify_value(a7, makesym(atom_yes));
  x4 = a0;
  x5 = a1;
  a3 = a2;
  a2 = x5;
  a1 = x4;
  a0 = makesym(atom_and);
  execute(merge__atomic_4_0);
  goto merge__atomic_4_ext_interrupt;
 and__type__element_10_7:
  deref_and_jump(a1,and__type__element_10_6);
  *reasonp++ =  a1;
  goto and__type__element_10_12;
 case symval(makesym(atom_f)):
  gblt_arity(a0,x1,and__type__element_10_12);
 and__type__element_10_8:
  if (isref(a1)) goto and__type__element_10_9;
  gblt_pfunctor(a1,x2,and__type__element_10_12);
  if (x2 != makesym(atom_f)) goto and__type__element_10_12;
  gblt_arity(a1,x3,and__type__element_10_12);
  unify(a9, a8);
  unify_value(a7, makesym(atom_yes));
  x4 = a0;
  x5 = a1;
  a3 = a2;
  a2 = x5;
  a1 = x4;
  a0 = makesym(atom_and);
  execute(merge__atomic_4_0);
  goto merge__atomic_4_ext_interrupt;
 and__type__element_10_9:
  deref_and_jump(a1,and__type__element_10_8);
  *reasonp++ =  a1;
  goto and__type__element_10_12;
 case symval(makesym(atom_c)):
  gblt_arity(a0,x1,and__type__element_10_12);
 and__type__element_10_10:
  if (isref(a1)) goto and__type__element_10_11;
  gblt_pfunctor(a1,x2,and__type__element_10_12);
  if (x2 != makesym(atom_c)) goto and__type__element_10_12;
  gblt_arity(a1,x3,and__type__element_10_12);
  unify(a9, a8);
  unify_value(a7, makesym(atom_yes));
  x4 = a0;
  x5 = a1;
  a3 = a2;
  a2 = x5;
  a1 = x4;
  a0 = makesym(atom_and);
  execute(merge__atomic_4_0);
  goto merge__atomic_4_ext_interrupt;
 and__type__element_10_11:
  deref_and_jump(a1,and__type__element_10_10);
  *reasonp++ =  a1;
  goto and__type__element_10_12;
  };
  goto and__type__element_10_12;
 and__type__element_10_12:
  otherwise(and__type__element_10_interrupt);
  unify_value(a7, makesym(atom_no));
  unify_value(a2, makesym(atom_dmy));
  unify(a9, a8);
  proceed();
 and__type__element_10_ext_interrupt:
  reasonp = 0l;
 and__type__element_10_interrupt:
  toppred = &predicate_type_xand__type__element_10;
  goto interrupt_10;
 }

 and__type__element__struct_14_top: {
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  qp = qp->next;
 and__type__element__struct_14_clear_reason:
  reasonp = reasons;
 and__type__element__struct_14_0:
 and__type__element__struct_14_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom__3F)) goto and__type__element__struct_14_2;
  a0 = a1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  a5 = a6;
  a6 = a7;
  a7 = a8;
  a8 = a9;
  a9 = a10;
  a10 = a11;
  a11 = a12;
  a12 = a13;
  execute(and__type__element__struct1_13_0);
  goto and__type__element__struct1_13_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,and__type__element__struct_14_1);
  *reasonp++ =  a0;
  goto and__type__element__struct_14_2;
  };
  goto and__type__element__struct_14_2;
 and__type__element__struct_14_2:
  otherwise(and__type__element__struct_14_interrupt);
 and__type__element__struct_14_3:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom__3F)) goto and__type__element__struct_14_4;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  a5 = a6;
  a6 = a7;
  a7 = a8;
  a8 = a9;
  a9 = a10;
  a10 = a11;
  a11 = a12;
  a12 = a13;
  execute(and__type__element__struct1_13_0);
  goto and__type__element__struct1_13_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,and__type__element__struct_14_3);
  *reasonp++ =  a1;
  goto and__type__element__struct_14_4;
  };
  goto and__type__element__struct_14_4;
 and__type__element__struct_14_4:
  otherwise(and__type__element__struct_14_interrupt);
 and__type__element__struct_14_5:
  if (isref(a0)) goto and__type__element__struct_14_8;
 and__type__element__struct_14_6:
  if (isref(a0)) goto and__type__element__struct_14_7;
  if_not_equal(a0, a1, and__type__element__struct_14_9);
  a1 = a2;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  a5 = a6;
  a6 = a7;
  a7 = a8;
  a8 = a9;
  a9 = a10;
  a10 = a11;
  a11 = a12;
  a12 = a13;
  execute(and__type__element__struct1_13_clear_reason);
  goto and__type__element__struct1_13_ext_interrupt;
 and__type__element__struct_14_7:
  deref_and_jump(a0,and__type__element__struct_14_6);
  *reasonp++ =  a0;
  goto and__type__element__struct_14_9;
 and__type__element__struct_14_8:
  deref_and_jump(a0,and__type__element__struct_14_5);
  *reasonp++ =  a0;
  goto and__type__element__struct_14_9;
 and__type__element__struct_14_9:
  otherwise(and__type__element__struct_14_interrupt);
  unify_value(a11, makesym(atom_no));
  proceed();
 and__type__element__struct_14_ext_interrupt:
  reasonp = 0l;
 and__type__element__struct_14_interrupt:
  toppred = &predicate_type_xand__type__element__struct_14;
  goto interrupt_14;
 }

 _2C_2_top: {
  q x0;
  a1 = qp->args[1];
  qp = qp->next;
 _2C_2_clear_reason:
  reasonp = reasons;
 _2C_2_0:
 _2C_2_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor__3D_2)) goto _2C_2_interrupt;
  x0 = arg(a0, 1);
 _2C_2_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_dmy)) goto _2C_2_interrupt;
 _2C_2_3:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor__3D_2)) goto _2C_2_interrupt;
  proceed();
 case VARREF:
  deref_and_jump(a1,_2C_2_3);
  *reasonp++ =  a1;
  goto _2C_2_interrupt;
  };
  goto _2C_2_interrupt;
 case VARREF:
  deref_and_jump(x0,_2C_2_2);
  *reasonp++ =  x0;
  goto _2C_2_interrupt;
  };
  goto _2C_2_interrupt;
 case VARREF:
  deref_and_jump(a0,_2C_2_1);
  *reasonp++ =  a0;
  goto _2C_2_interrupt;
  };
  goto _2C_2_interrupt;
 _2C_2_ext_interrupt:
  reasonp = 0l;
 _2C_2_interrupt:
  goto interrupt_2;
 }

 and__type__element__struct1_13_top: {
  q x0, x1, x2, x3, x4, x5;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  qp = qp->next;
 and__type__element__struct1_13_clear_reason:
  reasonp = reasons;
 and__type__element__struct1_13_0:
 and__type__element__struct1_13_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_n)) goto and__type__element__struct1_13_3;
 and__type__element__struct1_13_2:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_n)) goto and__type__element__struct1_13_3;
  unify_value(a10, makesym(atom_yes));
  allocp[0] = makesym(functor_s_3);
  allocp[1] = a0;
  allocp[2] = makesym(atom_n);
  allocp[3] = x1 = makeref(&allocp[3]);
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a5, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xadd__dep__goals_3);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x1;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_type_xadd__i__goals_3);
  allocp[7] = x4 = makeref(&allocp[7]);
  allocp[8] = x5 = makeref(&allocp[8]);
  allocp[9] = x3;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_type_xand__types_5);
  allocp[12] = a3;
  allocp[13] = a4;
  allocp[14] = x5;
  allocp[15] = a11;
  allocp[16] = a12;
  allocp[17] = (q)(struct goalrec*)&allocp[10];
  allocp[18] = (q)(&predicate_type_xmerge__goals_3);
  allocp[19] = a8;
  allocp[20] = a9;
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[17];
  allocp[23] = (q)(&predicate_list_xor__unique_3);
  allocp[24] = a6;
  allocp[25] = a7;
  allocp[26] = x4;
  qp = (struct goalrec*)&allocp[22];
  allocp += 27;
  proceed();
 case VARREF:
  deref_and_jump(a2,and__type__element__struct1_13_2);
  *reasonp++ =  a2;
  goto and__type__element__struct1_13_3;
  };
  goto and__type__element__struct1_13_3;
 case VARREF:
  deref_and_jump(a1,and__type__element__struct1_13_1);
  *reasonp++ =  a1;
  goto and__type__element__struct1_13_3;
  };
  goto and__type__element__struct1_13_3;
 and__type__element__struct1_13_3:
  otherwise(and__type__element__struct1_13_interrupt);
 and__type__element__struct1_13_4:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_n)) goto and__type__element__struct1_13_7;
 and__type__element__struct1_13_5:
  if (!isint(a2)) goto and__type__element__struct1_13_6;
  gblt_integer(a2,and__type__element__struct1_13_7);
  unify_value(a10, makesym(atom_yes));
  allocp[0] = makesym(functor_s_3);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = x1 = makeref(&allocp[3]);
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a5, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xand__type__element__argslist_8);
  allocp[2] = a2;
  allocp[3] = a4;
  allocp[4] = a3;
  allocp[5] = x1;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = a11;
  allocp[9] = a12;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_type_xmerge__goals_3);
  allocp[12] = a8;
  allocp[13] = a9;
  allocp[14] = x3;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_list_xor__unique_3);
  allocp[17] = a6;
  allocp[18] = a7;
  allocp[19] = x2;
  qp = (struct goalrec*)&allocp[15];
  allocp += 20;
  proceed();
 and__type__element__struct1_13_6:
  if (!isref(a2)) goto and__type__element__struct1_13_7;
  deref_and_jump(a2,and__type__element__struct1_13_5);
  *reasonp++ =  a2;
  goto and__type__element__struct1_13_7;
 case VARREF:
  deref_and_jump(a1,and__type__element__struct1_13_4);
  *reasonp++ =  a1;
  goto and__type__element__struct1_13_7;
  };
  goto and__type__element__struct1_13_7;
 and__type__element__struct1_13_7:
 and__type__element__struct1_13_8:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_n)) goto and__type__element__struct1_13_11;
 and__type__element__struct1_13_9:
  if (!isint(a1)) goto and__type__element__struct1_13_10;
  gblt_integer(a1,and__type__element__struct1_13_11);
  unify_value(a10, makesym(atom_yes));
  allocp[0] = makesym(functor_s_3);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = x1 = makeref(&allocp[3]);
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a5, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xand__type__element__argslist_8);
  allocp[2] = a1;
  allocp[3] = a3;
  allocp[4] = a4;
  allocp[5] = x1;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = a11;
  allocp[9] = a12;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_type_xmerge__goals_3);
  allocp[12] = a8;
  allocp[13] = a9;
  allocp[14] = x3;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_list_xor__unique_3);
  allocp[17] = a6;
  allocp[18] = a7;
  allocp[19] = x2;
  qp = (struct goalrec*)&allocp[15];
  allocp += 20;
  proceed();
 and__type__element__struct1_13_10:
  if (!isref(a1)) goto and__type__element__struct1_13_11;
  deref_and_jump(a1,and__type__element__struct1_13_9);
  *reasonp++ =  a1;
  goto and__type__element__struct1_13_11;
 case VARREF:
  deref_and_jump(a2,and__type__element__struct1_13_8);
  *reasonp++ =  a2;
  goto and__type__element__struct1_13_11;
  };
  goto and__type__element__struct1_13_11;
 and__type__element__struct1_13_11:
  otherwise(and__type__element__struct1_13_interrupt);
 and__type__element__struct1_13_12:
  if (isref(a1)) goto and__type__element__struct1_13_17;
 and__type__element__struct1_13_13:
  if (isref(a1)) goto and__type__element__struct1_13_16;
  if_not_equal(a1, a2, and__type__element__struct1_13_18);
 and__type__element__struct1_13_14:
  if (!isint(a1)) goto and__type__element__struct1_13_15;
  gblt_integer(a1,and__type__element__struct1_13_18);
  unify_value(a10, makesym(atom_yes));
  allocp[0] = makesym(functor_s_3);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = x1 = makeref(&allocp[3]);
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a5, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xand__type__element__args_8);
  allocp[2] = a1;
  allocp[3] = a3;
  allocp[4] = a4;
  allocp[5] = x1;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = a11;
  allocp[9] = a12;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_type_xmerge__goals_3);
  allocp[12] = a8;
  allocp[13] = a9;
  allocp[14] = x3;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_list_xor__unique_3);
  allocp[17] = a6;
  allocp[18] = a7;
  allocp[19] = x2;
  qp = (struct goalrec*)&allocp[15];
  allocp += 20;
  proceed();
 and__type__element__struct1_13_15:
  if (!isref(a1)) goto and__type__element__struct1_13_18;
  deref_and_jump(a1,and__type__element__struct1_13_14);
  *reasonp++ =  a1;
  goto and__type__element__struct1_13_18;
 and__type__element__struct1_13_16:
  deref_and_jump(a1,and__type__element__struct1_13_13);
  *reasonp++ =  a1;
  goto and__type__element__struct1_13_18;
 and__type__element__struct1_13_17:
  deref_and_jump(a1,and__type__element__struct1_13_12);
  *reasonp++ =  a1;
  goto and__type__element__struct1_13_18;
 and__type__element__struct1_13_18:
  otherwise(and__type__element__struct1_13_interrupt);
  unify_value(a5, makesym(atom_dmy));
  unify_value(a10, makesym(atom_no));
  unify(a12, a11);
  proceed();
 and__type__element__struct1_13_ext_interrupt:
  reasonp = 0l;
 and__type__element__struct1_13_interrupt:
  toppred = &predicate_type_xand__type__element__struct1_13;
  goto interrupt_13;
 }

 and__type__element__args_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 and__type__element__args_8_clear_reason:
  reasonp = reasons;
 and__type__element__args_8_0:
 and__type__element__args_8_1:
  if (!isint(a0)) goto and__type__element__args_8_3;
  gblt_greater(a0,makeint(0L),and__type__element__args_8_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xand__type__element__args_8);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[12] = a0;
  allocp[13] = makeint(1L);
  allocp[14] = x0;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[17] = a0;
  allocp[18] = a1;
  allocp[19] = x3 = makeref(&allocp[19]);
  allocp[20] = x1;
  allocp[21] = (q)(struct goalrec*)&allocp[15];
  allocp[22] = (q)(&predicate_type_xand__types_5);
  allocp[23] = x4 = makeref(&allocp[23]);
  allocp[24] = x5 = makeref(&allocp[24]);
  allocp[25] = x3;
  allocp[26] = a6;
  allocp[27] = x2;
  allocp[28] = (q)(struct goalrec*)&allocp[21];
  allocp[29] = (q)(&predicate_type_xadd__dep__goals_3);
  allocp[30] = a5;
  allocp[31] = x6 = makeref(&allocp[31]);
  allocp[32] = x5;
  allocp[33] = (q)(struct goalrec*)&allocp[28];
  allocp[34] = (q)(&predicate_type_xadd__i__goals_3);
  allocp[35] = a4;
  allocp[36] = x7 = makeref(&allocp[36]);
  allocp[37] = x6;
  allocp[38] = (q)(struct goalrec*)&allocp[33];
  allocp[39] = (q)(&predicate_type_xadd__dep__goals_3);
  allocp[40] = a5;
  allocp[41] = x8 = makeref(&allocp[41]);
  allocp[42] = x4;
  allocp[43] = (q)(struct goalrec*)&allocp[38];
  allocp[44] = (q)(&predicate_type_xadd__i__goals_3);
  allocp[45] = a4;
  allocp[46] = x9 = makeref(&allocp[46]);
  allocp[47] = x8;
  allocp[48] = (q)(struct goalrec*)&allocp[43];
  allocp[49] = (q)(&predicate_functor__table_xarg_3);
  allocp[50] = a0;
  allocp[51] = a2;
  allocp[52] = x7;
  allocp[53] = (q)(struct goalrec*)&allocp[48];
  allocp[54] = (q)(&predicate_functor__table_xarg_3);
  allocp[55] = a0;
  allocp[56] = a1;
  allocp[57] = x9;
  qp = (struct goalrec*)&allocp[53];
  allocp += 58;
  proceed();
 and__type__element__args_8_2:
  if (a0 != makeint(0L)) goto and__type__element__args_8_interrupt;
  unify2(a3, a1, a7, a6);
  proceed();
 and__type__element__args_8_3:
  if (!isref(a0)) goto and__type__element__args_8_interrupt;
  deref_and_jump(a0,and__type__element__args_8_1);
  *reasonp++ =  a0;
  goto and__type__element__args_8_interrupt;
 and__type__element__args_8_ext_interrupt:
  reasonp = 0l;
 and__type__element__args_8_interrupt:
  goto interrupt_8;
 }

 and__type__element__argslist_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 and__type__element__argslist_8_clear_reason:
  reasonp = reasons;
 and__type__element__argslist_8_0:
 and__type__element__argslist_8_1:
  if (!isint(a0)) goto and__type__element__argslist_8_3;
  gblt_greater(a0,makeint(0L),and__type__element__argslist_8_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xand__type__element__argslist_8);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[12] = a0;
  allocp[13] = makeint(1L);
  allocp[14] = x0;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[17] = a0;
  allocp[18] = a1;
  allocp[19] = x3 = makeref(&allocp[19]);
  allocp[20] = x1;
  allocp[21] = (q)(struct goalrec*)&allocp[15];
  allocp[22] = (q)(&predicate_type_xand__types_5);
  allocp[23] = x4 = makeref(&allocp[23]);
  allocp[24] = x5 = makeref(&allocp[24]);
  allocp[25] = x3;
  allocp[26] = a6;
  allocp[27] = x2;
  allocp[28] = (q)(struct goalrec*)&allocp[21];
  allocp[29] = (q)(&predicate_type_xadd__dep__goals_3);
  allocp[30] = a5;
  allocp[31] = x6 = makeref(&allocp[31]);
  allocp[32] = x5;
  allocp[33] = (q)(struct goalrec*)&allocp[28];
  allocp[34] = (q)(&predicate_type_xadd__i__goals_3);
  allocp[35] = a4;
  allocp[36] = a2;
  allocp[37] = x6;
  allocp[38] = (q)(struct goalrec*)&allocp[33];
  allocp[39] = (q)(&predicate_type_xadd__dep__goals_3);
  allocp[40] = a5;
  allocp[41] = x7 = makeref(&allocp[41]);
  allocp[42] = x4;
  allocp[43] = (q)(struct goalrec*)&allocp[38];
  allocp[44] = (q)(&predicate_type_xadd__i__goals_3);
  allocp[45] = a4;
  allocp[46] = x8 = makeref(&allocp[46]);
  allocp[47] = x7;
  allocp[48] = (q)(struct goalrec*)&allocp[43];
  allocp[49] = (q)(&predicate_functor__table_xarg_3);
  allocp[50] = a0;
  allocp[51] = a1;
  allocp[52] = x8;
  qp = (struct goalrec*)&allocp[48];
  allocp += 53;
  proceed();
 and__type__element__argslist_8_2:
  if (a0 != makeint(0L)) goto and__type__element__argslist_8_interrupt;
  unify2(a3, a1, a7, a6);
  proceed();
 and__type__element__argslist_8_3:
  if (!isref(a0)) goto and__type__element__argslist_8_interrupt;
  deref_and_jump(a0,and__type__element__argslist_8_1);
  *reasonp++ =  a0;
  goto and__type__element__argslist_8_interrupt;
 and__type__element__argslist_8_ext_interrupt:
  reasonp = 0l;
 and__type__element__argslist_8_interrupt:
  goto interrupt_8;
 }

 make__indirect__unify_4_top: {
  q x0;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 make__indirect__unify_4_clear_reason:
  reasonp = reasons;
 make__indirect__unify_4_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xmake__indirect__unify1_4);
  allocp[2] = a1;
  allocp[3] = a0;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = a3;
  a3 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(make__indirect__unify1_4_0);
  goto make__indirect__unify1_4_ext_interrupt;
 make__indirect__unify_4_ext_interrupt:
  reasonp = 0l;
 make__indirect__unify_4_interrupt:
  goto interrupt_4;
 }

 make__indirect__unify1_4_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 make__indirect__unify1_4_clear_reason:
  reasonp = reasons;
 make__indirect__unify1_4_0:
 make__indirect__unify1_4_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xmake__indirect__unify1_4);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = a1;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a3;
  a0 = car_of(a0);
  a3 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(make__indirect__unify2_4_0);
  goto make__indirect__unify2_4_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto make__indirect__unify1_4_interrupt;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,make__indirect__unify1_4_1);
  *reasonp++ =  a0;
  goto make__indirect__unify1_4_interrupt;
  };
  goto make__indirect__unify1_4_interrupt;
 make__indirect__unify1_4_ext_interrupt:
  reasonp = 0l;
 make__indirect__unify1_4_interrupt:
  toppred = &predicate_type_xmake__indirect__unify1_4;
  goto interrupt_4;
 }

 make__indirect__unify2_4_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 make__indirect__unify2_4_clear_reason:
  reasonp = reasons;
 make__indirect__unify2_4_0:
 make__indirect__unify2_4_1:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xmake__indirect__unify2_4);
  allocp[2] = a0;
  x0 = cdr_of(a1);
  allocp[3] = x0;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a3;
  a1 = car_of(a1);
  a3 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(make__indirect__unify3_4_0);
  goto make__indirect__unify3_4_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto make__indirect__unify2_4_interrupt;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a1,make__indirect__unify2_4_1);
  *reasonp++ =  a1;
  goto make__indirect__unify2_4_interrupt;
  };
  goto make__indirect__unify2_4_interrupt;
 make__indirect__unify2_4_ext_interrupt:
  reasonp = 0l;
 make__indirect__unify2_4_interrupt:
  toppred = &predicate_type_xmake__indirect__unify2_4;
  goto interrupt_4;
 }

 make__indirect__unify3_4_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 make__indirect__unify3_4_clear_reason:
  reasonp = reasons;
 make__indirect__unify3_4_0:
 make__indirect__unify3_4_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_t_4)) goto make__indirect__unify3_4_7;
 make__indirect__unify3_4_2:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_t_4)) goto make__indirect__unify3_4_7;
  x0 = arg(a1, 0);
 make__indirect__unify3_4_3:
  if (isref(x0)) goto make__indirect__unify3_4_6;
 make__indirect__unify3_4_4:
  if (isref(x0)) goto make__indirect__unify3_4_5;
  x1 = arg(a0, 0);
  if_not_equal(x0, x1, make__indirect__unify3_4_7);
  unify(a3, a2);
  proceed();
 make__indirect__unify3_4_5:
  deref_and_jump(x0,make__indirect__unify3_4_4);
  *reasonp++ =  x0;
  goto make__indirect__unify3_4_7;
 make__indirect__unify3_4_6:
  deref_and_jump(x0,make__indirect__unify3_4_3);
  *reasonp++ =  x0;
  goto make__indirect__unify3_4_7;
 case VARREF:
  deref_and_jump(a1,make__indirect__unify3_4_2);
  *reasonp++ =  a1;
  goto make__indirect__unify3_4_7;
  };
  goto make__indirect__unify3_4_7;
 case VARREF:
  deref_and_jump(a0,make__indirect__unify3_4_1);
  *reasonp++ =  a0;
  goto make__indirect__unify3_4_7;
  };
  goto make__indirect__unify3_4_7;
 make__indirect__unify3_4_7:
  otherwise(make__indirect__unify3_4_interrupt);
 make__indirect__unify3_4_8:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_t_4)) goto make__indirect__unify3_4_10;
  x0 = arg(a0, 0);
 make__indirect__unify3_4_9:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_v_4)) goto make__indirect__unify3_4_10;
  allocp[0] = makesym(functor_unify_2);
  allocp[1] = a0;
  allocp[2] = a1;
  x1 = makefunctor(&allocp[0]);
  a0 = x1;
  a1 = a2;
  a2 = a3;
  allocp += 3;
  execute(entry__indirect_3_0);
  goto entry__indirect_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,make__indirect__unify3_4_9);
  *reasonp++ =  x0;
  goto make__indirect__unify3_4_10;
  };
  goto make__indirect__unify3_4_10;
 case VARREF:
  deref_and_jump(a0,make__indirect__unify3_4_8);
  *reasonp++ =  a0;
  goto make__indirect__unify3_4_10;
  };
  goto make__indirect__unify3_4_10;
 make__indirect__unify3_4_10:
  otherwise(make__indirect__unify3_4_interrupt);
 make__indirect__unify3_4_11:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_t_4)) goto make__indirect__unify3_4_13;
  x0 = arg(a1, 0);
 make__indirect__unify3_4_12:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_v_4)) goto make__indirect__unify3_4_13;
  allocp[0] = makesym(functor_unify_2);
  allocp[1] = a1;
  allocp[2] = a0;
  x1 = makefunctor(&allocp[0]);
  a0 = x1;
  a1 = a2;
  a2 = a3;
  allocp += 3;
  execute(entry__indirect_3_0);
  goto entry__indirect_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,make__indirect__unify3_4_12);
  *reasonp++ =  x0;
  goto make__indirect__unify3_4_13;
  };
  goto make__indirect__unify3_4_13;
 case VARREF:
  deref_and_jump(a1,make__indirect__unify3_4_11);
  *reasonp++ =  a1;
  goto make__indirect__unify3_4_13;
  };
  goto make__indirect__unify3_4_13;
 make__indirect__unify3_4_13:
  otherwise(make__indirect__unify3_4_interrupt);
  unify(a3, a2);
  proceed();
 make__indirect__unify3_4_ext_interrupt:
  reasonp = 0l;
 make__indirect__unify3_4_interrupt:
  toppred = &predicate_type_xmake__indirect__unify3_4;
  goto interrupt_4;
 }

 entry__indirect_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20, x21, x22, x23, x24, x25, x26, x27, x28;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 entry__indirect_3_clear_reason:
  reasonp = reasons;
 entry__indirect_3_0:
 entry__indirect_3_1:
  switch (ptagof(a1)) {
 case CONS:
 entry__indirect_3_2:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_unify_2:
  x0 = arg(a0, 0);
 entry__indirect_3_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_4)) goto entry__indirect_3_50;
  x1 = arg(a0, 1);
 entry__indirect_3_4:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_t_4)) goto entry__indirect_3_50;
  x2 = car_of(a1);
 entry__indirect_3_5:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_unify_2)) goto entry__indirect_3_50;
  x3 = arg(x2, 0);
 entry__indirect_3_6:
  switch (ptagof(x3)) {
 case FUNCTOR:
  if (functor_of(x3) != makesym(functor_t_4)) goto entry__indirect_3_50;
  x4 = arg(x3, 0);
 entry__indirect_3_7:
  if (isref(x4)) goto entry__indirect_3_23;
 entry__indirect_3_8:
  if (isref(x4)) goto entry__indirect_3_22;
  x5 = arg(x0, 0);
  if_not_equal(x4, x5, entry__indirect_3_14);
  x6 = arg(x2, 1);
 entry__indirect_3_9:
  switch (ptagof(x6)) {
 case FUNCTOR:
  if (functor_of(x6) != makesym(functor_t_4)) goto entry__indirect_3_14;
  x7 = arg(x6, 0);
 entry__indirect_3_10:
  if (isref(x7)) goto entry__indirect_3_13;
 entry__indirect_3_11:
  if (isref(x7)) goto entry__indirect_3_12;
  x8 = arg(x1, 0);
  if_not_equal(x7, x8, entry__indirect_3_14);
  allocp[0] = makesym(functor_t_4);
  allocp[1] = x5;
  allocp[2] = x10 = makeref(&allocp[2]);
  allocp[3] = x11 = makeref(&allocp[3]);
  allocp[4] = x12 = makeref(&allocp[4]);
  x9 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_t_4);
  allocp[6] = x8;
  allocp[7] = x14 = makeref(&allocp[7]);
  allocp[8] = x15 = makeref(&allocp[8]);
  allocp[9] = x16 = makeref(&allocp[9]);
  x13 = makefunctor(&allocp[5]);
  allocp[10] = makesym(functor_unify_2);
  allocp[11] = x9;
  allocp[12] = x13;
  x17 = makefunctor(&allocp[10]);
  allocp[13] = cdr_of(a1);
  allocp[14] = x17;
  x18 = makecons(&allocp[13]);
  allocp += 15;
  unify_value(a2, x18);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xmerge__goals_3);
  x19 = arg(x1, 2);
  allocp[2] = x19;
  x20 = arg(x6, 2);
  allocp[3] = x20;
  allocp[4] = x15;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_type_xmerge__goals_3);
  x21 = arg(x0, 2);
  allocp[7] = x21;
  x22 = arg(x3, 2);
  allocp[8] = x22;
  allocp[9] = x11;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_list_xor__unique_3);
  x23 = arg(x1, 1);
  allocp[12] = x23;
  x24 = arg(x6, 1);
  allocp[13] = x24;
  allocp[14] = x14;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_list_xor__unique_3);
  x25 = arg(x0, 1);
  allocp[17] = x25;
  x26 = arg(x3, 1);
  allocp[18] = x26;
  allocp[19] = x10;
  allocp[20] = (q)(struct goalrec*)&allocp[15];
  allocp[21] = (q)(&predicate_type_xmerge__ru_3);
  x27 = arg(x1, 3);
  allocp[22] = x27;
  x28 = arg(x6, 3);
  allocp[23] = x28;
  allocp[24] = x16;
  a0 = arg(x0, 3);
  a1 = arg(x3, 3);
  a2 = x12;
  qp = (struct goalrec*)&allocp[20];
  allocp += 25;
  execute(merge__ru_3_clear_reason);
  goto merge__ru_3_ext_interrupt;
 entry__indirect_3_12:
  deref_and_jump(x7,entry__indirect_3_11);
  *reasonp++ =  x7;
  goto entry__indirect_3_14;
 entry__indirect_3_13:
  deref_and_jump(x7,entry__indirect_3_10);
  *reasonp++ =  x7;
  goto entry__indirect_3_14;
 case VARREF:
  deref_and_jump(x6,entry__indirect_3_9);
  *reasonp++ =  x6;
  goto entry__indirect_3_14;
  };
  goto entry__indirect_3_14;
 entry__indirect_3_14:
 entry__indirect_3_15:
  if (isref(x4)) goto entry__indirect_3_21;
  x6 = arg(x1, 0);
  if_not_equal(x4, x6, entry__indirect_3_50);
  x7 = arg(x2, 1);
 entry__indirect_3_16:
  switch (ptagof(x7)) {
 case FUNCTOR:
  if (functor_of(x7) != makesym(functor_t_4)) goto entry__indirect_3_50;
  x8 = arg(x7, 0);
 entry__indirect_3_17:
  if (isref(x8)) goto entry__indirect_3_20;
 entry__indirect_3_18:
  if (isref(x8)) goto entry__indirect_3_19;
  if_not_equal(x8, x5, entry__indirect_3_50);
  allocp[0] = makesym(functor_t_4);
  allocp[1] = x5;
  allocp[2] = x10 = makeref(&allocp[2]);
  allocp[3] = x11 = makeref(&allocp[3]);
  allocp[4] = x12 = makeref(&allocp[4]);
  x9 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_t_4);
  allocp[6] = x6;
  allocp[7] = x14 = makeref(&allocp[7]);
  allocp[8] = x15 = makeref(&allocp[8]);
  allocp[9] = x16 = makeref(&allocp[9]);
  x13 = makefunctor(&allocp[5]);
  allocp[10] = makesym(functor_unify_2);
  allocp[11] = x9;
  allocp[12] = x13;
  x17 = makefunctor(&allocp[10]);
  allocp[13] = cdr_of(a1);
  allocp[14] = x17;
  x18 = makecons(&allocp[13]);
  allocp += 15;
  unify_value(a2, x18);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xmerge__goals_3);
  x19 = arg(x1, 2);
  allocp[2] = x19;
  x20 = arg(x3, 2);
  allocp[3] = x20;
  allocp[4] = x15;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_type_xmerge__goals_3);
  x21 = arg(x0, 2);
  allocp[7] = x21;
  x22 = arg(x7, 2);
  allocp[8] = x22;
  allocp[9] = x11;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_list_xor__unique_3);
  x23 = arg(x1, 1);
  allocp[12] = x23;
  x24 = arg(x3, 1);
  allocp[13] = x24;
  allocp[14] = x14;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_list_xor__unique_3);
  x25 = arg(x0, 1);
  allocp[17] = x25;
  x26 = arg(x7, 1);
  allocp[18] = x26;
  allocp[19] = x10;
  allocp[20] = (q)(struct goalrec*)&allocp[15];
  allocp[21] = (q)(&predicate_type_xmerge__ru_3);
  x27 = arg(x1, 3);
  allocp[22] = x27;
  x28 = arg(x3, 3);
  allocp[23] = x28;
  allocp[24] = x16;
  a0 = arg(x0, 3);
  a1 = arg(x7, 3);
  a2 = x12;
  qp = (struct goalrec*)&allocp[20];
  allocp += 25;
  execute(merge__ru_3_clear_reason);
  goto merge__ru_3_ext_interrupt;
 entry__indirect_3_19:
  deref_and_jump(x8,entry__indirect_3_18);
  *reasonp++ =  x8;
  goto entry__indirect_3_50;
 entry__indirect_3_20:
  deref_and_jump(x8,entry__indirect_3_17);
  *reasonp++ =  x8;
  goto entry__indirect_3_50;
 case VARREF:
  deref_and_jump(x7,entry__indirect_3_16);
  *reasonp++ =  x7;
  goto entry__indirect_3_50;
  };
  goto entry__indirect_3_50;
 entry__indirect_3_21:
  deref_and_jump(x4,entry__indirect_3_15);
  *reasonp++ =  x4;
  goto entry__indirect_3_50;
 entry__indirect_3_22:
  deref_and_jump(x4,entry__indirect_3_8);
  *reasonp++ =  x4;
  goto entry__indirect_3_50;
 entry__indirect_3_23:
  deref_and_jump(x4,entry__indirect_3_7);
  *reasonp++ =  x4;
  goto entry__indirect_3_50;
 case VARREF:
  deref_and_jump(x3,entry__indirect_3_6);
  *reasonp++ =  x3;
  goto entry__indirect_3_50;
  };
  goto entry__indirect_3_50;
 case VARREF:
  deref_and_jump(x2,entry__indirect_3_5);
  *reasonp++ =  x2;
  goto entry__indirect_3_50;
  };
  goto entry__indirect_3_50;
 case VARREF:
  deref_and_jump(x1,entry__indirect_3_4);
  *reasonp++ =  x1;
  goto entry__indirect_3_50;
  };
  goto entry__indirect_3_50;
 case VARREF:
  deref_and_jump(x0,entry__indirect_3_3);
  *reasonp++ =  x0;
  goto entry__indirect_3_50;
  };
  goto entry__indirect_3_50;
 case functor_unifyaliasup_2:
  x0 = arg(a0, 0);
 entry__indirect_3_24:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_4)) goto entry__indirect_3_50;
  x1 = arg(a0, 1);
 entry__indirect_3_25:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_t_4)) goto entry__indirect_3_50;
  x2 = car_of(a1);
 entry__indirect_3_26:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_unifyaliasup_2)) goto entry__indirect_3_50;
  x3 = arg(x2, 0);
 entry__indirect_3_27:
  switch (ptagof(x3)) {
 case FUNCTOR:
  if (functor_of(x3) != makesym(functor_t_4)) goto entry__indirect_3_50;
  x4 = arg(x3, 0);
 entry__indirect_3_28:
  if (isref(x4)) goto entry__indirect_3_36;
 entry__indirect_3_29:
  if (isref(x4)) goto entry__indirect_3_35;
  x5 = arg(x0, 0);
  if_not_equal(x4, x5, entry__indirect_3_50);
  x6 = arg(x2, 1);
 entry__indirect_3_30:
  switch (ptagof(x6)) {
 case FUNCTOR:
  if (functor_of(x6) != makesym(functor_t_4)) goto entry__indirect_3_50;
  x7 = arg(x6, 0);
 entry__indirect_3_31:
  if (isref(x7)) goto entry__indirect_3_34;
 entry__indirect_3_32:
  if (isref(x7)) goto entry__indirect_3_33;
  x8 = arg(x1, 0);
  if_not_equal(x7, x8, entry__indirect_3_50);
  allocp[0] = makesym(functor_t_4);
  allocp[1] = x5;
  allocp[2] = x10 = makeref(&allocp[2]);
  allocp[3] = x11 = makeref(&allocp[3]);
  allocp[4] = x12 = makeref(&allocp[4]);
  x9 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_t_4);
  allocp[6] = x8;
  allocp[7] = x14 = makeref(&allocp[7]);
  allocp[8] = x15 = makeref(&allocp[8]);
  allocp[9] = x16 = makeref(&allocp[9]);
  x13 = makefunctor(&allocp[5]);
  allocp[10] = makesym(functor_unifyaliasup_2);
  allocp[11] = x9;
  allocp[12] = x13;
  x17 = makefunctor(&allocp[10]);
  allocp[13] = cdr_of(a1);
  allocp[14] = x17;
  x18 = makecons(&allocp[13]);
  allocp += 15;
  unify_value(a2, x18);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xmerge__goals_3);
  x19 = arg(x1, 2);
  allocp[2] = x19;
  x20 = arg(x6, 2);
  allocp[3] = x20;
  allocp[4] = x15;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_type_xmerge__goals_3);
  x21 = arg(x0, 2);
  allocp[7] = x21;
  x22 = arg(x3, 2);
  allocp[8] = x22;
  allocp[9] = x11;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_list_xor__unique_3);
  x23 = arg(x1, 1);
  allocp[12] = x23;
  x24 = arg(x6, 1);
  allocp[13] = x24;
  allocp[14] = x14;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_list_xor__unique_3);
  x25 = arg(x0, 1);
  allocp[17] = x25;
  x26 = arg(x3, 1);
  allocp[18] = x26;
  allocp[19] = x10;
  allocp[20] = (q)(struct goalrec*)&allocp[15];
  allocp[21] = (q)(&predicate_type_xmerge__ru_3);
  x27 = arg(x1, 3);
  allocp[22] = x27;
  x28 = arg(x6, 3);
  allocp[23] = x28;
  allocp[24] = x16;
  a0 = arg(x0, 3);
  a1 = arg(x3, 3);
  a2 = x12;
  qp = (struct goalrec*)&allocp[20];
  allocp += 25;
  execute(merge__ru_3_clear_reason);
  goto merge__ru_3_ext_interrupt;
 entry__indirect_3_33:
  deref_and_jump(x7,entry__indirect_3_32);
  *reasonp++ =  x7;
  goto entry__indirect_3_50;
 entry__indirect_3_34:
  deref_and_jump(x7,entry__indirect_3_31);
  *reasonp++ =  x7;
  goto entry__indirect_3_50;
 case VARREF:
  deref_and_jump(x6,entry__indirect_3_30);
  *reasonp++ =  x6;
  goto entry__indirect_3_50;
  };
  goto entry__indirect_3_50;
 entry__indirect_3_35:
  deref_and_jump(x4,entry__indirect_3_29);
  *reasonp++ =  x4;
  goto entry__indirect_3_50;
 entry__indirect_3_36:
  deref_and_jump(x4,entry__indirect_3_28);
  *reasonp++ =  x4;
  goto entry__indirect_3_50;
 case VARREF:
  deref_and_jump(x3,entry__indirect_3_27);
  *reasonp++ =  x3;
  goto entry__indirect_3_50;
  };
  goto entry__indirect_3_50;
 case VARREF:
  deref_and_jump(x2,entry__indirect_3_26);
  *reasonp++ =  x2;
  goto entry__indirect_3_50;
  };
  goto entry__indirect_3_50;
 case VARREF:
  deref_and_jump(x1,entry__indirect_3_25);
  *reasonp++ =  x1;
  goto entry__indirect_3_50;
  };
  goto entry__indirect_3_50;
 case VARREF:
  deref_and_jump(x0,entry__indirect_3_24);
  *reasonp++ =  x0;
  goto entry__indirect_3_50;
  };
  goto entry__indirect_3_50;
 case functor_unifyaliasdown_2:
  x0 = arg(a0, 0);
 entry__indirect_3_37:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_4)) goto entry__indirect_3_50;
  x1 = arg(a0, 1);
 entry__indirect_3_38:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_t_4)) goto entry__indirect_3_50;
  x2 = car_of(a1);
 entry__indirect_3_39:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_unifyaliasdown_2)) goto entry__indirect_3_50;
  x3 = arg(x2, 0);
 entry__indirect_3_40:
  switch (ptagof(x3)) {
 case FUNCTOR:
  if (functor_of(x3) != makesym(functor_t_4)) goto entry__indirect_3_50;
  x4 = arg(x3, 0);
 entry__indirect_3_41:
  if (isref(x4)) goto entry__indirect_3_49;
 entry__indirect_3_42:
  if (isref(x4)) goto entry__indirect_3_48;
  x5 = arg(x0, 0);
  if_not_equal(x4, x5, entry__indirect_3_50);
  x6 = arg(x2, 1);
 entry__indirect_3_43:
  switch (ptagof(x6)) {
 case FUNCTOR:
  if (functor_of(x6) != makesym(functor_t_4)) goto entry__indirect_3_50;
  x7 = arg(x6, 0);
 entry__indirect_3_44:
  if (isref(x7)) goto entry__indirect_3_47;
 entry__indirect_3_45:
  if (isref(x7)) goto entry__indirect_3_46;
  x8 = arg(x1, 0);
  if_not_equal(x7, x8, entry__indirect_3_50);
  allocp[0] = makesym(functor_t_4);
  allocp[1] = x5;
  allocp[2] = x10 = makeref(&allocp[2]);
  allocp[3] = x11 = makeref(&allocp[3]);
  allocp[4] = x12 = makeref(&allocp[4]);
  x9 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_t_4);
  allocp[6] = x8;
  allocp[7] = x14 = makeref(&allocp[7]);
  allocp[8] = x15 = makeref(&allocp[8]);
  allocp[9] = x16 = makeref(&allocp[9]);
  x13 = makefunctor(&allocp[5]);
  allocp[10] = makesym(functor_unifyaliasdown_2);
  allocp[11] = x9;
  allocp[12] = x13;
  x17 = makefunctor(&allocp[10]);
  allocp[13] = cdr_of(a1);
  allocp[14] = x17;
  x18 = makecons(&allocp[13]);
  allocp += 15;
  unify_value(a2, x18);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xmerge__goals_3);
  x19 = arg(x1, 2);
  allocp[2] = x19;
  x20 = arg(x6, 2);
  allocp[3] = x20;
  allocp[4] = x15;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_type_xmerge__goals_3);
  x21 = arg(x0, 2);
  allocp[7] = x21;
  x22 = arg(x3, 2);
  allocp[8] = x22;
  allocp[9] = x11;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_list_xor__unique_3);
  x23 = arg(x1, 1);
  allocp[12] = x23;
  x24 = arg(x6, 1);
  allocp[13] = x24;
  allocp[14] = x14;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_list_xor__unique_3);
  x25 = arg(x0, 1);
  allocp[17] = x25;
  x26 = arg(x3, 1);
  allocp[18] = x26;
  allocp[19] = x10;
  allocp[20] = (q)(struct goalrec*)&allocp[15];
  allocp[21] = (q)(&predicate_type_xmerge__ru_3);
  x27 = arg(x1, 3);
  allocp[22] = x27;
  x28 = arg(x6, 3);
  allocp[23] = x28;
  allocp[24] = x16;
  a0 = arg(x0, 3);
  a1 = arg(x3, 3);
  a2 = x12;
  qp = (struct goalrec*)&allocp[20];
  allocp += 25;
  execute(merge__ru_3_clear_reason);
  goto merge__ru_3_ext_interrupt;
 entry__indirect_3_46:
  deref_and_jump(x7,entry__indirect_3_45);
  *reasonp++ =  x7;
  goto entry__indirect_3_50;
 entry__indirect_3_47:
  deref_and_jump(x7,entry__indirect_3_44);
  *reasonp++ =  x7;
  goto entry__indirect_3_50;
 case VARREF:
  deref_and_jump(x6,entry__indirect_3_43);
  *reasonp++ =  x6;
  goto entry__indirect_3_50;
  };
  goto entry__indirect_3_50;
 entry__indirect_3_48:
  deref_and_jump(x4,entry__indirect_3_42);
  *reasonp++ =  x4;
  goto entry__indirect_3_50;
 entry__indirect_3_49:
  deref_and_jump(x4,entry__indirect_3_41);
  *reasonp++ =  x4;
  goto entry__indirect_3_50;
 case VARREF:
  deref_and_jump(x3,entry__indirect_3_40);
  *reasonp++ =  x3;
  goto entry__indirect_3_50;
  };
  goto entry__indirect_3_50;
 case VARREF:
  deref_and_jump(x2,entry__indirect_3_39);
  *reasonp++ =  x2;
  goto entry__indirect_3_50;
  };
  goto entry__indirect_3_50;
 case VARREF:
  deref_and_jump(x1,entry__indirect_3_38);
  *reasonp++ =  x1;
  goto entry__indirect_3_50;
  };
  goto entry__indirect_3_50;
 case VARREF:
  deref_and_jump(x0,entry__indirect_3_37);
  *reasonp++ =  x0;
  goto entry__indirect_3_50;
  };
  goto entry__indirect_3_50;
  };
  goto entry__indirect_3_50;
 case VARREF:
  deref_and_jump(a0,entry__indirect_3_2);
  *reasonp++ =  a0;
  goto entry__indirect_3_50;
  };
  goto entry__indirect_3_50;
 case VARREF:
  deref_and_jump(a1,entry__indirect_3_1);
  *reasonp++ =  a1;
  goto entry__indirect_3_50;
  };
  goto entry__indirect_3_50;
 entry__indirect_3_50:
  otherwise(entry__indirect_3_interrupt);
 entry__indirect_3_51:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = car_of(a1);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  a1 = cdr_of(a1);
  a2 = x1;
  execute(entry__indirect_3_0);
  goto entry__indirect_3_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto entry__indirect_3_interrupt;
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,entry__indirect_3_51);
  *reasonp++ =  a1;
  goto entry__indirect_3_interrupt;
  };
  goto entry__indirect_3_interrupt;
 entry__indirect_3_ext_interrupt:
  reasonp = 0l;
 entry__indirect_3_interrupt:
  toppred = &predicate_type_xentry__indirect_3;
  goto interrupt_3;
 }

 merge__ru_3_top: {
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 merge__ru_3_clear_reason:
  reasonp = reasons;
 merge__ru_3_0:
 merge__ru_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_u)) goto merge__ru_3_2;
  unify_value(a2, makesym(atom_u));
  proceed();
 case VARREF:
  deref_and_jump(a0,merge__ru_3_1);
  *reasonp++ =  a0;
  goto merge__ru_3_2;
  };
  goto merge__ru_3_2;
 merge__ru_3_2:
 merge__ru_3_3:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_u)) goto merge__ru_3_4;
  unify_value(a2, makesym(atom_u));
  proceed();
 case VARREF:
  deref_and_jump(a1,merge__ru_3_3);
  *reasonp++ =  a1;
  goto merge__ru_3_4;
  };
  goto merge__ru_3_4;
 merge__ru_3_4:
  otherwise(merge__ru_3_interrupt);
 merge__ru_3_5:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_r)) goto merge__ru_3_6;
  unify_value(a2, makesym(atom_r));
  proceed();
 case VARREF:
  deref_and_jump(a0,merge__ru_3_5);
  *reasonp++ =  a0;
  goto merge__ru_3_6;
  };
  goto merge__ru_3_6;
 merge__ru_3_6:
 merge__ru_3_7:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_r)) goto merge__ru_3_8;
  unify_value(a2, makesym(atom_r));
  proceed();
 case VARREF:
  deref_and_jump(a1,merge__ru_3_7);
  *reasonp++ =  a1;
  goto merge__ru_3_8;
  };
  goto merge__ru_3_8;
 merge__ru_3_8:
  otherwise(merge__ru_3_interrupt);
 merge__ru_3_9:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom__3F)) goto merge__ru_3_interrupt;
 merge__ru_3_10:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom__3F)) goto merge__ru_3_interrupt;
  unify_value(a2, makesym(atom__3F));
  proceed();
 case VARREF:
  deref_and_jump(a1,merge__ru_3_10);
  *reasonp++ =  a1;
  goto merge__ru_3_interrupt;
  };
  goto merge__ru_3_interrupt;
 case VARREF:
  deref_and_jump(a0,merge__ru_3_9);
  *reasonp++ =  a0;
  goto merge__ru_3_interrupt;
  };
  goto merge__ru_3_interrupt;
 merge__ru_3_ext_interrupt:
  reasonp = 0l;
 merge__ru_3_interrupt:
  toppred = &predicate_type_xmerge__ru_3;
  goto interrupt_3;
 }

 or__types_3_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 or__types_3_clear_reason:
  reasonp = reasons;
 or__types_3_0:
 or__types_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 or__types_3_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__3F)) goto or__types_3_5;
 or__types_3_3:
  switch (ptagof(a1)) {
 case CONS:
  x1 = car_of(a1);
 or__types_3_4:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom__3F)) goto or__types_3_5;
  allocp[0] = x3 = makeref(&allocp[0]);
  allocp[1] = makesym(atom__3F);
  x2 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x2);
  a0 = cdr_of(a0);
  a1 = cdr_of(a1);
  a2 = x3;
  execute(or__types_3_0);
  goto or__types_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,or__types_3_4);
  *reasonp++ =  x1;
  goto or__types_3_5;
  };
  goto or__types_3_5;
 case VARREF:
  deref_and_jump(a1,or__types_3_3);
  *reasonp++ =  a1;
  goto or__types_3_5;
  };
  goto or__types_3_5;
 case VARREF:
  deref_and_jump(x0,or__types_3_2);
  *reasonp++ =  x0;
  goto or__types_3_5;
  };
  goto or__types_3_5;
 case VARREF:
  deref_and_jump(a0,or__types_3_1);
  *reasonp++ =  a0;
  goto or__types_3_5;
  };
  goto or__types_3_5;
 or__types_3_5:
  otherwise(or__types_3_interrupt);
 or__types_3_6:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != NILATOM) goto or__types_3_7;
  unify(a2, a0);
  proceed();
 case VARREF:
  deref_and_jump(a1,or__types_3_6);
  *reasonp++ =  a1;
  goto or__types_3_7;
  };
  goto or__types_3_7;
 or__types_3_7:
 or__types_3_8:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != NILATOM) goto or__types_3_9;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,or__types_3_8);
  *reasonp++ =  a0;
  goto or__types_3_9;
  };
  goto or__types_3_9;
 or__types_3_9:
  otherwise(or__types_3_interrupt);
 or__types_3_10:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 or__types_3_11:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__3F)) goto or__types_3_12;
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = makesym(atom__3F);
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x1);
  a0 = cdr_of(a0);
  a2 = x2;
  execute(or__types_3_0);
  goto or__types_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,or__types_3_11);
  *reasonp++ =  x0;
  goto or__types_3_12;
  };
  goto or__types_3_12;
 case VARREF:
  deref_and_jump(a0,or__types_3_10);
  *reasonp++ =  a0;
  goto or__types_3_12;
  };
  goto or__types_3_12;
 or__types_3_12:
 or__types_3_13:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 or__types_3_14:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__3F)) goto or__types_3_15;
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = makesym(atom__3F);
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x1);
  a1 = cdr_of(a1);
  a2 = x2;
  execute(or__types_3_clear_reason);
  goto or__types_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,or__types_3_14);
  *reasonp++ =  x0;
  goto or__types_3_15;
  };
  goto or__types_3_15;
 case VARREF:
  deref_and_jump(a1,or__types_3_13);
  *reasonp++ =  a1;
  goto or__types_3_15;
  };
  goto or__types_3_15;
 or__types_3_15:
  otherwise(or__types_3_interrupt);
 or__types_3_16:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xor__types_3);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  a0 = car_of(a0);
  a2 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(or__types1_3_0);
  goto or__types1_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto or__types_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,or__types_3_16);
  *reasonp++ =  a0;
  goto or__types_3_interrupt;
  };
  goto or__types_3_interrupt;
 or__types_3_ext_interrupt:
  reasonp = 0l;
 or__types_3_interrupt:
  toppred = &predicate_type_xor__types_3;
  goto interrupt_3;
 }

 or__types1_3_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 or__types1_3_clear_reason:
  reasonp = reasons;
 or__types1_3_0:
 or__types1_3_1:
  switch (ptagof(a1)) {
 case CONS:
 or__types1_3_2:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_t_4)) goto or__types1_3_interrupt;
  x0 = car_of(a1);
 or__types1_3_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_4)) goto or__types1_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xor__types2_6);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = x0;
  allocp[5] = x2 = makeref(&allocp[5]);
  x3 = cdr_of(a1);
  allocp[6] = x3;
  allocp[7] = a2;
  a0 = arg(a0, 0);
  a1 = arg(x0, 0);
  a2 = x2;
  a3 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  execute(or__type__element_4_0);
  goto or__type__element_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,or__types1_3_3);
  *reasonp++ =  x0;
  goto or__types1_3_interrupt;
  };
  goto or__types1_3_interrupt;
 case VARREF:
  deref_and_jump(a0,or__types1_3_2);
  *reasonp++ =  a0;
  goto or__types1_3_interrupt;
  };
  goto or__types1_3_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto or__types1_3_interrupt;
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,or__types1_3_1);
  *reasonp++ =  a1;
  goto or__types1_3_interrupt;
  };
  goto or__types1_3_interrupt;
 or__types1_3_ext_interrupt:
  reasonp = 0l;
 or__types1_3_interrupt:
  toppred = &predicate_type_xor__types1_3;
  goto interrupt_3;
 }

 or__types2_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 or__types2_6_clear_reason:
  reasonp = reasons;
 or__types2_6_0:
 or__types2_6_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto or__types2_6_6;
  switch (symval(a0)) {
 case symval(makesym(atom_no)):
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = a2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a5, x0);
  a0 = a1;
  a1 = a4;
  a2 = x1;
  execute(or__types1_3_0);
  goto or__types1_3_ext_interrupt;
 case symval(makesym(atom_yes)):
 or__types2_6_2:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_t_4)) goto or__types2_6_6;
  x0 = arg(a1, 3);
 or__types2_6_3:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_u)) goto or__types2_6_6;
 or__types2_6_4:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_t_4)) goto or__types2_6_6;
  x1 = arg(a2, 3);
 or__types2_6_5:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_u)) goto or__types2_6_6;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xor__types1_3);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = a4;
  allocp[4] = a5;
  allocp[5] = makesym(functor_t_4);
  allocp[6] = a3;
  allocp[7] = x4 = makeref(&allocp[7]);
  allocp[8] = x5 = makeref(&allocp[8]);
  allocp[9] = makesym(atom_u);
  x3 = makefunctor(&allocp[5]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  unify_value(x2, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xmerge__goals_3);
  x6 = arg(a1, 2);
  allocp[2] = x6;
  x7 = arg(a2, 2);
  allocp[3] = x7;
  allocp[4] = x5;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_list_xor__unique_3);
  x8 = arg(a1, 1);
  allocp[7] = x8;
  x9 = arg(a2, 1);
  allocp[8] = x9;
  allocp[9] = x4;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(x1,or__types2_6_5);
  *reasonp++ =  x1;
  goto or__types2_6_6;
  };
  goto or__types2_6_6;
 case VARREF:
  deref_and_jump(a2,or__types2_6_4);
  *reasonp++ =  a2;
  goto or__types2_6_6;
  };
  goto or__types2_6_6;
 case VARREF:
  deref_and_jump(x0,or__types2_6_3);
  *reasonp++ =  x0;
  goto or__types2_6_6;
  };
  goto or__types2_6_6;
 case VARREF:
  deref_and_jump(a1,or__types2_6_2);
  *reasonp++ =  a1;
  goto or__types2_6_6;
  };
  goto or__types2_6_6;
  };
  goto or__types2_6_6;
 case VARREF:
  deref_and_jump(a0,or__types2_6_1);
  *reasonp++ =  a0;
  goto or__types2_6_6;
  };
  goto or__types2_6_6;
 or__types2_6_6:
  otherwise(or__types2_6_interrupt);
 or__types2_6_7:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_yes)) goto or__types2_6_14;
 or__types2_6_8:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_t_4)) goto or__types2_6_14;
  x0 = arg(a1, 3);
 or__types2_6_9:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (isint(x0)) goto or__types2_6_14;
  switch (symval(x0)) {
 case symval(makesym(atom_u)):
 or__types2_6_10:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_t_4)) goto or__types2_6_14;
  x1 = arg(a2, 3);
 or__types2_6_11:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_r)) goto or__types2_6_14;
  a0 = a1;
  a1 = a4;
  a2 = a5;
  execute(or__types1_3_0);
  goto or__types1_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,or__types2_6_11);
  *reasonp++ =  x1;
  goto or__types2_6_14;
  };
  goto or__types2_6_14;
 case VARREF:
  deref_and_jump(a2,or__types2_6_10);
  *reasonp++ =  a2;
  goto or__types2_6_14;
  };
  goto or__types2_6_14;
 case symval(makesym(atom_r)):
 or__types2_6_12:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_t_4)) goto or__types2_6_14;
  x1 = arg(a2, 3);
 or__types2_6_13:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_u)) goto or__types2_6_14;
  a0 = a2;
  a1 = a4;
  a2 = a5;
  execute(or__types1_3_0);
  goto or__types1_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,or__types2_6_13);
  *reasonp++ =  x1;
  goto or__types2_6_14;
  };
  goto or__types2_6_14;
 case VARREF:
  deref_and_jump(a2,or__types2_6_12);
  *reasonp++ =  a2;
  goto or__types2_6_14;
  };
  goto or__types2_6_14;
  };
  goto or__types2_6_14;
 case VARREF:
  deref_and_jump(x0,or__types2_6_9);
  *reasonp++ =  x0;
  goto or__types2_6_14;
  };
  goto or__types2_6_14;
 case VARREF:
  deref_and_jump(a1,or__types2_6_8);
  *reasonp++ =  a1;
  goto or__types2_6_14;
  };
  goto or__types2_6_14;
 case VARREF:
  deref_and_jump(a0,or__types2_6_7);
  *reasonp++ =  a0;
  goto or__types2_6_14;
  };
  goto or__types2_6_14;
 or__types2_6_14:
  otherwise(or__types2_6_interrupt);
 or__types2_6_15:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_yes)) goto or__types2_6_20;
 or__types2_6_16:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_t_4)) goto or__types2_6_20;
  x0 = arg(a1, 3);
 or__types2_6_17:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_r)) goto or__types2_6_20;
 or__types2_6_18:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_t_4)) goto or__types2_6_20;
  x1 = arg(a2, 3);
 or__types2_6_19:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_r)) goto or__types2_6_20;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xor__types1_3);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = a4;
  allocp[4] = a5;
  allocp[5] = makesym(functor_t_4);
  allocp[6] = a3;
  allocp[7] = x4 = makeref(&allocp[7]);
  allocp[8] = x5 = makeref(&allocp[8]);
  allocp[9] = makesym(atom_r);
  x3 = makefunctor(&allocp[5]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  unify_value(x2, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xmerge__goals_3);
  x6 = arg(a1, 2);
  allocp[2] = x6;
  x7 = arg(a2, 2);
  allocp[3] = x7;
  allocp[4] = x5;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_list_xor__unique_3);
  x8 = arg(a1, 1);
  allocp[7] = x8;
  x9 = arg(a2, 1);
  allocp[8] = x9;
  allocp[9] = x4;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(x1,or__types2_6_19);
  *reasonp++ =  x1;
  goto or__types2_6_20;
  };
  goto or__types2_6_20;
 case VARREF:
  deref_and_jump(a2,or__types2_6_18);
  *reasonp++ =  a2;
  goto or__types2_6_20;
  };
  goto or__types2_6_20;
 case VARREF:
  deref_and_jump(x0,or__types2_6_17);
  *reasonp++ =  x0;
  goto or__types2_6_20;
  };
  goto or__types2_6_20;
 case VARREF:
  deref_and_jump(a1,or__types2_6_16);
  *reasonp++ =  a1;
  goto or__types2_6_20;
  };
  goto or__types2_6_20;
 case VARREF:
  deref_and_jump(a0,or__types2_6_15);
  *reasonp++ =  a0;
  goto or__types2_6_20;
  };
  goto or__types2_6_20;
 or__types2_6_20:
  otherwise(or__types2_6_interrupt);
 or__types2_6_21:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_yes)) goto or__types2_6_26;
 or__types2_6_22:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_t_4)) goto or__types2_6_26;
  x0 = arg(a1, 3);
 or__types2_6_23:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__3F)) goto or__types2_6_26;
 or__types2_6_24:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_t_4)) goto or__types2_6_26;
  x1 = arg(a2, 3);
 or__types2_6_25:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom__3F)) goto or__types2_6_26;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xor__types1_3);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = a4;
  allocp[4] = a5;
  allocp[5] = makesym(functor_t_4);
  allocp[6] = a3;
  allocp[7] = x4 = makeref(&allocp[7]);
  allocp[8] = x5 = makeref(&allocp[8]);
  allocp[9] = makesym(atom__3F);
  x3 = makefunctor(&allocp[5]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  unify_value(x2, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xmerge__goals_3);
  x6 = arg(a1, 2);
  allocp[2] = x6;
  x7 = arg(a2, 2);
  allocp[3] = x7;
  allocp[4] = x5;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_list_xor__unique_3);
  x8 = arg(a1, 1);
  allocp[7] = x8;
  x9 = arg(a2, 1);
  allocp[8] = x9;
  allocp[9] = x4;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(x1,or__types2_6_25);
  *reasonp++ =  x1;
  goto or__types2_6_26;
  };
  goto or__types2_6_26;
 case VARREF:
  deref_and_jump(a2,or__types2_6_24);
  *reasonp++ =  a2;
  goto or__types2_6_26;
  };
  goto or__types2_6_26;
 case VARREF:
  deref_and_jump(x0,or__types2_6_23);
  *reasonp++ =  x0;
  goto or__types2_6_26;
  };
  goto or__types2_6_26;
 case VARREF:
  deref_and_jump(a1,or__types2_6_22);
  *reasonp++ =  a1;
  goto or__types2_6_26;
  };
  goto or__types2_6_26;
 case VARREF:
  deref_and_jump(a0,or__types2_6_21);
  *reasonp++ =  a0;
  goto or__types2_6_26;
  };
  goto or__types2_6_26;
 or__types2_6_26:
  otherwise(or__types2_6_interrupt);
 or__types2_6_27:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_yes)) goto or__types2_6_interrupt;
 or__types2_6_28:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_t_4)) goto or__types2_6_interrupt;
  x0 = arg(a1, 3);
 or__types2_6_29:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__3F)) goto or__types2_6_31;
 or__types2_6_30:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_t_4)) goto or__types2_6_31;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xor__types1_3);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a4;
  allocp[4] = a5;
  allocp[5] = makesym(functor_t_4);
  allocp[6] = a3;
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = arg(a2, 3);
  x2 = makefunctor(&allocp[5]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  unify_value(x1, x2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xmerge__goals_3);
  x5 = arg(a1, 2);
  allocp[2] = x5;
  x6 = arg(a2, 2);
  allocp[3] = x6;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_list_xor__unique_3);
  x7 = arg(a1, 1);
  allocp[7] = x7;
  x8 = arg(a2, 1);
  allocp[8] = x8;
  allocp[9] = x3;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a2,or__types2_6_30);
  *reasonp++ =  a2;
  goto or__types2_6_31;
  };
  goto or__types2_6_31;
 case VARREF:
  deref_and_jump(x0,or__types2_6_29);
  *reasonp++ =  x0;
  goto or__types2_6_31;
  };
  goto or__types2_6_31;
 or__types2_6_31:
 or__types2_6_32:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_t_4)) goto or__types2_6_interrupt;
  x1 = arg(a2, 3);
 or__types2_6_33:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom__3F)) goto or__types2_6_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xor__types1_3);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = a4;
  allocp[4] = a5;
  allocp[5] = makesym(functor_t_4);
  allocp[6] = a3;
  allocp[7] = x4 = makeref(&allocp[7]);
  allocp[8] = x5 = makeref(&allocp[8]);
  allocp[9] = x0;
  x3 = makefunctor(&allocp[5]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  unify_value(x2, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xmerge__goals_3);
  x6 = arg(a1, 2);
  allocp[2] = x6;
  x7 = arg(a2, 2);
  allocp[3] = x7;
  allocp[4] = x5;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_list_xor__unique_3);
  x8 = arg(a1, 1);
  allocp[7] = x8;
  x9 = arg(a2, 1);
  allocp[8] = x9;
  allocp[9] = x4;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(x1,or__types2_6_33);
  *reasonp++ =  x1;
  goto or__types2_6_interrupt;
  };
  goto or__types2_6_interrupt;
 case VARREF:
  deref_and_jump(a2,or__types2_6_32);
  *reasonp++ =  a2;
  goto or__types2_6_interrupt;
  };
  goto or__types2_6_interrupt;
 case VARREF:
  deref_and_jump(a1,or__types2_6_28);
  *reasonp++ =  a1;
  goto or__types2_6_interrupt;
  };
  goto or__types2_6_interrupt;
 case VARREF:
  deref_and_jump(a0,or__types2_6_27);
  *reasonp++ =  a0;
  goto or__types2_6_interrupt;
  };
  goto or__types2_6_interrupt;
 or__types2_6_ext_interrupt:
  reasonp = 0l;
 or__types2_6_interrupt:
  goto interrupt_6;
 }

 or__type__element_4_top: {
  q x0, x1, x2, x3, x4, x5;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 or__type__element_4_clear_reason:
  reasonp = reasons;
 or__type__element_4_0:
 or__type__element_4_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_s_3:
 or__type__element_4_2:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_s_3)) goto or__type__element_4_16;
  x0 = arg(a0, 0);
  x1 = arg(a1, 0);
  x2 = arg(a0, 1);
  x3 = arg(a1, 1);
  a4 = arg(a0, 2);
  a5 = arg(a1, 2);
  a6 = a2;
  a7 = a3;
  a3 = x3;
  a2 = x2;
  a1 = x1;
  a0 = x0;
  execute(or__type__element__struct_8_0);
  goto or__type__element__struct_8_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,or__type__element_4_2);
  *reasonp++ =  a1;
  goto or__type__element_4_16;
  };
  goto or__type__element_4_16;
 case functor_v_4:
 or__type__element_4_3:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_v_4)) goto or__type__element_4_16;
  x0 = arg(a1, 0);
 or__type__element_4_4:
  if (isref(x0)) goto or__type__element_4_15;
 or__type__element_4_5:
  if (isref(x0)) goto or__type__element_4_14;
  x1 = arg(a0, 0);
  if_not_equal(x0, x1, or__type__element_4_16);
  x2 = arg(a1, 1);
 or__type__element_4_6:
  if (isref(x2)) goto or__type__element_4_13;
 or__type__element_4_7:
  if (isref(x2)) goto or__type__element_4_12;
  x3 = arg(a0, 1);
  if_not_equal(x2, x3, or__type__element_4_16);
  x4 = arg(a1, 3);
 or__type__element_4_8:
  if (isref(x4)) goto or__type__element_4_11;
 or__type__element_4_9:
  if (isref(x4)) goto or__type__element_4_10;
  x5 = arg(a0, 3);
  if_not_equal(x4, x5, or__type__element_4_16);
  unify_value(a2, a0);
  unify_value(a3, makesym(atom_yes));
  proceed();
 or__type__element_4_10:
  deref_and_jump(x4,or__type__element_4_9);
  *reasonp++ =  x4;
  goto or__type__element_4_16;
 or__type__element_4_11:
  deref_and_jump(x4,or__type__element_4_8);
  *reasonp++ =  x4;
  goto or__type__element_4_16;
 or__type__element_4_12:
  deref_and_jump(x2,or__type__element_4_7);
  *reasonp++ =  x2;
  goto or__type__element_4_16;
 or__type__element_4_13:
  deref_and_jump(x2,or__type__element_4_6);
  *reasonp++ =  x2;
  goto or__type__element_4_16;
 or__type__element_4_14:
  deref_and_jump(x0,or__type__element_4_5);
  *reasonp++ =  x0;
  goto or__type__element_4_16;
 or__type__element_4_15:
  deref_and_jump(x0,or__type__element_4_4);
  *reasonp++ =  x0;
  goto or__type__element_4_16;
 case VARREF:
  deref_and_jump(a1,or__type__element_4_3);
  *reasonp++ =  a1;
  goto or__type__element_4_16;
  };
  goto or__type__element_4_16;
  };
  goto or__type__element_4_16;
 case VARREF:
  deref_and_jump(a0,or__type__element_4_1);
  *reasonp++ =  a0;
  goto or__type__element_4_25;
  };
  goto or__type__element_4_16;
 or__type__element_4_16:
  gblt_pfunctor(a0,x0,or__type__element_4_25);
  if (isint(x0)) goto or__type__element_4_25;
  switch (symval(x0)) {
 case symval(makesym(atom_a)):
  gblt_arity(a0,x1,or__type__element_4_25);
 or__type__element_4_17:
  if (isref(a1)) goto or__type__element_4_18;
  gblt_pfunctor(a1,x2,or__type__element_4_25);
  if (x2 != makesym(atom_a)) goto or__type__element_4_25;
  gblt_arity(a1,x3,or__type__element_4_25);
  unify_value(a3, makesym(atom_yes));
  x4 = a0;
  x5 = a1;
  a3 = a2;
  a2 = x5;
  a1 = x4;
  a0 = makesym(atom_or);
  execute(merge__atomic_4_0);
  goto merge__atomic_4_ext_interrupt;
 or__type__element_4_18:
  deref_and_jump(a1,or__type__element_4_17);
  *reasonp++ =  a1;
  goto or__type__element_4_25;
 case symval(makesym(atom_i)):
  gblt_arity(a0,x1,or__type__element_4_25);
 or__type__element_4_19:
  if (isref(a1)) goto or__type__element_4_20;
  gblt_pfunctor(a1,x2,or__type__element_4_25);
  if (x2 != makesym(atom_i)) goto or__type__element_4_25;
  gblt_arity(a1,x3,or__type__element_4_25);
  unify_value(a3, makesym(atom_yes));
  x4 = a0;
  x5 = a1;
  a3 = a2;
  a2 = x5;
  a1 = x4;
  a0 = makesym(atom_or);
  execute(merge__atomic_4_0);
  goto merge__atomic_4_ext_interrupt;
 or__type__element_4_20:
  deref_and_jump(a1,or__type__element_4_19);
  *reasonp++ =  a1;
  goto or__type__element_4_25;
 case symval(makesym(atom_f)):
  gblt_arity(a0,x1,or__type__element_4_25);
 or__type__element_4_21:
  if (isref(a1)) goto or__type__element_4_22;
  gblt_pfunctor(a1,x2,or__type__element_4_25);
  if (x2 != makesym(atom_f)) goto or__type__element_4_25;
  gblt_arity(a1,x3,or__type__element_4_25);
  unify_value(a3, makesym(atom_yes));
  x4 = a0;
  x5 = a1;
  a3 = a2;
  a2 = x5;
  a1 = x4;
  a0 = makesym(atom_or);
  execute(merge__atomic_4_0);
  goto merge__atomic_4_ext_interrupt;
 or__type__element_4_22:
  deref_and_jump(a1,or__type__element_4_21);
  *reasonp++ =  a1;
  goto or__type__element_4_25;
 case symval(makesym(atom_c)):
  gblt_arity(a0,x1,or__type__element_4_25);
 or__type__element_4_23:
  if (isref(a1)) goto or__type__element_4_24;
  gblt_pfunctor(a1,x2,or__type__element_4_25);
  if (x2 != makesym(atom_c)) goto or__type__element_4_25;
  gblt_arity(a1,x3,or__type__element_4_25);
  unify_value(a3, makesym(atom_yes));
  x4 = a0;
  x5 = a1;
  a3 = a2;
  a2 = x5;
  a1 = x4;
  a0 = makesym(atom_or);
  execute(merge__atomic_4_0);
  goto merge__atomic_4_ext_interrupt;
 or__type__element_4_24:
  deref_and_jump(a1,or__type__element_4_23);
  *reasonp++ =  a1;
  goto or__type__element_4_25;
  };
  goto or__type__element_4_25;
 or__type__element_4_25:
  otherwise(or__type__element_4_interrupt);
  unify_value(a3, makesym(atom_no));
  proceed();
 or__type__element_4_ext_interrupt:
  reasonp = 0l;
 or__type__element_4_interrupt:
  toppred = &predicate_type_xor__type__element_4;
  goto interrupt_4;
 }

 or__type__element__struct_8_top: {
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 or__type__element__struct_8_clear_reason:
  reasonp = reasons;
 or__type__element__struct_8_0:
 or__type__element__struct_8_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom__3F)) goto or__type__element__struct_8_2;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  a5 = a6;
  a6 = a7;
  execute(or__type__element__struct1_7_0);
  goto or__type__element__struct1_7_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,or__type__element__struct_8_1);
  *reasonp++ =  a0;
  goto or__type__element__struct_8_2;
  };
  goto or__type__element__struct_8_2;
 or__type__element__struct_8_2:
  otherwise(or__type__element__struct_8_interrupt);
 or__type__element__struct_8_3:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom__3F)) goto or__type__element__struct_8_4;
  a0 = a1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  a5 = a6;
  a6 = a7;
  execute(or__type__element__struct1_7_0);
  goto or__type__element__struct1_7_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,or__type__element__struct_8_3);
  *reasonp++ =  a1;
  goto or__type__element__struct_8_4;
  };
  goto or__type__element__struct_8_4;
 or__type__element__struct_8_4:
  otherwise(or__type__element__struct_8_interrupt);
 or__type__element__struct_8_5:
  if (isref(a0)) goto or__type__element__struct_8_8;
 or__type__element__struct_8_6:
  if (isref(a0)) goto or__type__element__struct_8_7;
  if_not_equal(a0, a1, or__type__element__struct_8_9);
  a1 = a2;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  a5 = a6;
  a6 = a7;
  execute(or__type__element__struct1_7_clear_reason);
  goto or__type__element__struct1_7_ext_interrupt;
 or__type__element__struct_8_7:
  deref_and_jump(a0,or__type__element__struct_8_6);
  *reasonp++ =  a0;
  goto or__type__element__struct_8_9;
 or__type__element__struct_8_8:
  deref_and_jump(a0,or__type__element__struct_8_5);
  *reasonp++ =  a0;
  goto or__type__element__struct_8_9;
 or__type__element__struct_8_9:
  otherwise(or__type__element__struct_8_interrupt);
  unify_value(a7, makesym(atom_no));
  unify_value(a6, makesym(atom_dmy));
  proceed();
 or__type__element__struct_8_ext_interrupt:
  reasonp = 0l;
 or__type__element__struct_8_interrupt:
  toppred = &predicate_type_xor__type__element__struct_8;
  goto interrupt_8;
 }

 or__type__element__struct1_7_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 or__type__element__struct1_7_clear_reason:
  reasonp = reasons;
 or__type__element__struct1_7_0:
 or__type__element__struct1_7_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_n)) goto or__type__element__struct1_7_3;
 or__type__element__struct1_7_2:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_n)) goto or__type__element__struct1_7_3;
  unify_value(a6, makesym(atom_yes));
  allocp[0] = makesym(functor_s_3);
  allocp[1] = a0;
  allocp[2] = makesym(atom_n);
  allocp[3] = x1 = makeref(&allocp[3]);
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a5, x0);
  a0 = a3;
  a1 = a4;
  a2 = x1;
  execute(or__types_3_0);
  goto or__types_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,or__type__element__struct1_7_2);
  *reasonp++ =  a2;
  goto or__type__element__struct1_7_3;
  };
  goto or__type__element__struct1_7_3;
 case VARREF:
  deref_and_jump(a1,or__type__element__struct1_7_1);
  *reasonp++ =  a1;
  goto or__type__element__struct1_7_3;
  };
  goto or__type__element__struct1_7_3;
 or__type__element__struct1_7_3:
  otherwise(or__type__element__struct1_7_interrupt);
 or__type__element__struct1_7_4:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_n)) goto or__type__element__struct1_7_7;
 or__type__element__struct1_7_5:
  if (!isint(a2)) goto or__type__element__struct1_7_6;
  gblt_integer(a2,or__type__element__struct1_7_7);
  unify_value(a6, makesym(atom_yes));
  allocp[0] = makesym(functor_s_3);
  allocp[1] = a0;
  allocp[2] = makesym(atom_n);
  allocp[3] = x1 = makeref(&allocp[3]);
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a5, x0);
  a0 = a2;
  a1 = a4;
  a2 = a3;
  a3 = x1;
  execute(or__type__element__argslist_4_0);
  goto or__type__element__argslist_4_ext_interrupt;
 or__type__element__struct1_7_6:
  if (!isref(a2)) goto or__type__element__struct1_7_7;
  deref_and_jump(a2,or__type__element__struct1_7_5);
  *reasonp++ =  a2;
  goto or__type__element__struct1_7_7;
 case VARREF:
  deref_and_jump(a1,or__type__element__struct1_7_4);
  *reasonp++ =  a1;
  goto or__type__element__struct1_7_12;
  };
  goto or__type__element__struct1_7_7;
 or__type__element__struct1_7_7:
 or__type__element__struct1_7_8:
  if (isref(a1)) goto or__type__element__struct1_7_11;
  if_not_equal(a1, a2, or__type__element__struct1_7_12);
 or__type__element__struct1_7_9:
  if (!isint(a1)) goto or__type__element__struct1_7_10;
  gblt_integer(a1,or__type__element__struct1_7_12);
  unify_value(a6, makesym(atom_yes));
  allocp[0] = makesym(functor_s_3);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = x1 = makeref(&allocp[3]);
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a5, x0);
  a0 = a1;
  a1 = a3;
  a2 = a4;
  a3 = x1;
  execute(or__type__element__args_4_clear_reason);
  goto or__type__element__args_4_ext_interrupt;
 or__type__element__struct1_7_10:
  if (!isref(a1)) goto or__type__element__struct1_7_12;
  deref_and_jump(a1,or__type__element__struct1_7_9);
  *reasonp++ =  a1;
  goto or__type__element__struct1_7_12;
 or__type__element__struct1_7_11:
  deref_and_jump(a1,or__type__element__struct1_7_8);
  *reasonp++ =  a1;
  goto or__type__element__struct1_7_12;
 or__type__element__struct1_7_12:
 or__type__element__struct1_7_13:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_n)) goto or__type__element__struct1_7_16;
 or__type__element__struct1_7_14:
  if (!isint(a1)) goto or__type__element__struct1_7_15;
  gblt_integer(a1,or__type__element__struct1_7_16);
  unify_value(a6, makesym(atom_yes));
  allocp[0] = makesym(functor_s_3);
  allocp[1] = a0;
  allocp[2] = makesym(atom_n);
  allocp[3] = x1 = makeref(&allocp[3]);
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a5, x0);
  a0 = a1;
  a1 = a3;
  a2 = a4;
  a3 = x1;
  execute(or__type__element__argslist_4_clear_reason);
  goto or__type__element__argslist_4_ext_interrupt;
 or__type__element__struct1_7_15:
  if (!isref(a1)) goto or__type__element__struct1_7_16;
  deref_and_jump(a1,or__type__element__struct1_7_14);
  *reasonp++ =  a1;
  goto or__type__element__struct1_7_16;
 case VARREF:
  deref_and_jump(a2,or__type__element__struct1_7_13);
  *reasonp++ =  a2;
  goto or__type__element__struct1_7_16;
  };
  goto or__type__element__struct1_7_16;
 or__type__element__struct1_7_16:
  otherwise(or__type__element__struct1_7_interrupt);
  unify_value(a5, makesym(atom_dmy));
  unify_value(a6, makesym(atom_no));
  proceed();
 or__type__element__struct1_7_ext_interrupt:
  reasonp = 0l;
 or__type__element__struct1_7_interrupt:
  toppred = &predicate_type_xor__type__element__struct1_7;
  goto interrupt_7;
 }

 or__type__element__args_4_top: {
  q x0, x1, x2, x3, x4;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 or__type__element__args_4_clear_reason:
  reasonp = reasons;
 or__type__element__args_4_0:
 or__type__element__args_4_1:
  if (!isint(a0)) goto or__type__element__args_4_3;
  gblt_greater(a0,makeint(0L),or__type__element__args_4_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xor__type__element__args_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x0;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[13] = a0;
  allocp[14] = a1;
  allocp[15] = x2 = makeref(&allocp[15]);
  allocp[16] = x1;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_type_xor__types_3);
  allocp[19] = x3 = makeref(&allocp[19]);
  allocp[20] = x4 = makeref(&allocp[20]);
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[17];
  allocp[23] = (q)(&predicate_functor__table_xarg_3);
  allocp[24] = a0;
  allocp[25] = a2;
  allocp[26] = x4;
  allocp[27] = (q)(struct goalrec*)&allocp[22];
  allocp[28] = (q)(&predicate_functor__table_xarg_3);
  allocp[29] = a0;
  allocp[30] = a1;
  allocp[31] = x3;
  qp = (struct goalrec*)&allocp[27];
  allocp += 32;
  proceed();
 or__type__element__args_4_2:
  if (a0 != makeint(0L)) goto or__type__element__args_4_interrupt;
  unify(a3, a1);
  proceed();
 or__type__element__args_4_3:
  if (!isref(a0)) goto or__type__element__args_4_interrupt;
  deref_and_jump(a0,or__type__element__args_4_1);
  *reasonp++ =  a0;
  goto or__type__element__args_4_interrupt;
 or__type__element__args_4_ext_interrupt:
  reasonp = 0l;
 or__type__element__args_4_interrupt:
  toppred = &predicate_type_xor__type__element__args_4;
  goto interrupt_4;
 }

 or__type__element__argslist_4_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 or__type__element__argslist_4_clear_reason:
  reasonp = reasons;
 or__type__element__argslist_4_0:
 or__type__element__argslist_4_1:
  if (!isint(a0)) goto or__type__element__argslist_4_3;
  gblt_greater(a0,makeint(0L),or__type__element__argslist_4_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xor__type__element__argslist_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x0;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_type_xor__types_3);
  allocp[13] = a2;
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_functor__table_xarg_3);
  allocp[18] = a0;
  allocp[19] = a1;
  allocp[20] = x2;
  qp = (struct goalrec*)&allocp[16];
  allocp += 21;
  proceed();
 or__type__element__argslist_4_2:
  if (a0 != makeint(0L)) goto or__type__element__argslist_4_interrupt;
  unify(a3, a2);
  proceed();
 or__type__element__argslist_4_3:
  if (!isref(a0)) goto or__type__element__argslist_4_interrupt;
  deref_and_jump(a0,or__type__element__argslist_4_1);
  *reasonp++ =  a0;
  goto or__type__element__argslist_4_interrupt;
 or__type__element__argslist_4_ext_interrupt:
  reasonp = 0l;
 or__type__element__argslist_4_interrupt:
  toppred = &predicate_type_xor__type__element__argslist_4;
  goto interrupt_4;
 }

 or__type__element__vmode_3_top: {
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 or__type__element__vmode_3_clear_reason:
  reasonp = reasons;
 or__type__element__vmode_3_0:
 or__type__element__vmode_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_i)) goto or__type__element__vmode_3_2;
  unify_value(a2, makesym(atom_i));
  proceed();
 case VARREF:
  deref_and_jump(a0,or__type__element__vmode_3_1);
  *reasonp++ =  a0;
  goto or__type__element__vmode_3_2;
  };
  goto or__type__element__vmode_3_2;
 or__type__element__vmode_3_2:
 or__type__element__vmode_3_3:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_i)) goto or__type__element__vmode_3_4;
  unify_value(a2, makesym(atom_i));
  proceed();
 case VARREF:
  deref_and_jump(a1,or__type__element__vmode_3_3);
  *reasonp++ =  a1;
  goto or__type__element__vmode_3_4;
  };
  goto or__type__element__vmode_3_4;
 or__type__element__vmode_3_4:
  otherwise(or__type__element__vmode_3_interrupt);
 or__type__element__vmode_3_5:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_o)) goto or__type__element__vmode_3_6;
  unify_value(a2, makesym(atom_o));
  proceed();
 case VARREF:
  deref_and_jump(a0,or__type__element__vmode_3_5);
  *reasonp++ =  a0;
  goto or__type__element__vmode_3_6;
  };
  goto or__type__element__vmode_3_6;
 or__type__element__vmode_3_6:
 or__type__element__vmode_3_7:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_o)) goto or__type__element__vmode_3_8;
  unify_value(a2, makesym(atom_o));
  proceed();
 case VARREF:
  deref_and_jump(a1,or__type__element__vmode_3_7);
  *reasonp++ =  a1;
  goto or__type__element__vmode_3_8;
  };
  goto or__type__element__vmode_3_8;
 or__type__element__vmode_3_8:
  otherwise(or__type__element__vmode_3_interrupt);
  unify_value(a2, makesym(atom__3F));
  proceed();
 or__type__element__vmode_3_ext_interrupt:
  reasonp = 0l;
 or__type__element__vmode_3_interrupt:
  goto interrupt_3;
 }

 split__types__var__val_3_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 split__types__var__val_3_clear_reason:
  reasonp = reasons;
 split__types__var__val_3_0:
 split__types__var__val_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 split__types__var__val_3_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__3F)) goto split__types__var__val_3_4;
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = x0;
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x1);
  a0 = cdr_of(a0);
  a2 = x2;
  execute(split__types__var__val_3_0);
  goto split__types__var__val_3_ext_interrupt;
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_4)) goto split__types__var__val_3_4;
  x1 = arg(x0, 0);
 split__types__var__val_3_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_v_4)) goto split__types__var__val_3_4;
  allocp[0] = x3 = makeref(&allocp[0]);
  allocp[1] = x0;
  x2 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x2);
  a0 = cdr_of(a0);
  a2 = x3;
  execute(split__types__var__val_3_0);
  goto split__types__var__val_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,split__types__var__val_3_3);
  *reasonp++ =  x1;
  goto split__types__var__val_3_4;
  };
  goto split__types__var__val_3_4;
 case VARREF:
  deref_and_jump(x0,split__types__var__val_3_2);
  *reasonp++ =  x0;
  goto split__types__var__val_3_4;
  };
  goto split__types__var__val_3_4;
 case VARREF:
  deref_and_jump(a0,split__types__var__val_3_1);
  *reasonp++ =  a0;
  goto split__types__var__val_3_4;
  };
  goto split__types__var__val_3_4;
 split__types__var__val_3_4:
  otherwise(split__types__var__val_3_interrupt);
 split__types__var__val_3_5:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = car_of(a0);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(split__types__var__val_3_0);
  goto split__types__var__val_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto split__types__var__val_3_interrupt;
  unify_value(a1, NILATOM);
  unify_value(a2, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a0,split__types__var__val_3_5);
  *reasonp++ =  a0;
  goto split__types__var__val_3_interrupt;
  };
  goto split__types__var__val_3_interrupt;
 split__types__var__val_3_ext_interrupt:
  reasonp = 0l;
 split__types__var__val_3_interrupt:
  toppred = &predicate_type_xsplit__types__var__val_3;
  goto interrupt_3;
 }

 merge__atomic_4_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 merge__atomic_4_clear_reason:
  reasonp = reasons;
 merge__atomic_4_0:
 merge__atomic_4_1:
  switch (ptagof(a1)) {
 case FUNCTOR:
  switch (symval(functor_of(a1))) {
 case functor_a_1:
 merge__atomic_4_2:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_a_1)) goto merge__atomic_4_22;
  x0 = arg(a2, 0);
 merge__atomic_4_3:
  if (isref(x0)) goto merge__atomic_4_6;
 merge__atomic_4_4:
  if (isref(x0)) goto merge__atomic_4_5;
  x1 = arg(a1, 0);
  if_not_equal(x0, x1, merge__atomic_4_22);
  unify_value(a3, a1);
  proceed();
 merge__atomic_4_5:
  deref_and_jump(x0,merge__atomic_4_4);
  *reasonp++ =  x0;
  goto merge__atomic_4_22;
 merge__atomic_4_6:
  deref_and_jump(x0,merge__atomic_4_3);
  *reasonp++ =  x0;
  goto merge__atomic_4_22;
 case VARREF:
  deref_and_jump(a2,merge__atomic_4_2);
  *reasonp++ =  a2;
  goto merge__atomic_4_22;
  };
  goto merge__atomic_4_22;
 case functor_i_1:
 merge__atomic_4_7:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_i_1)) goto merge__atomic_4_22;
  x0 = arg(a2, 0);
 merge__atomic_4_8:
  if (isref(x0)) goto merge__atomic_4_11;
 merge__atomic_4_9:
  if (isref(x0)) goto merge__atomic_4_10;
  x1 = arg(a1, 0);
  if_not_equal(x0, x1, merge__atomic_4_22);
  unify_value(a3, a1);
  proceed();
 merge__atomic_4_10:
  deref_and_jump(x0,merge__atomic_4_9);
  *reasonp++ =  x0;
  goto merge__atomic_4_22;
 merge__atomic_4_11:
  deref_and_jump(x0,merge__atomic_4_8);
  *reasonp++ =  x0;
  goto merge__atomic_4_22;
 case VARREF:
  deref_and_jump(a2,merge__atomic_4_7);
  *reasonp++ =  a2;
  goto merge__atomic_4_22;
  };
  goto merge__atomic_4_22;
 case functor_f_1:
 merge__atomic_4_12:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_f_1)) goto merge__atomic_4_22;
  x0 = arg(a2, 0);
 merge__atomic_4_13:
  if (isref(x0)) goto merge__atomic_4_16;
 merge__atomic_4_14:
  if (isref(x0)) goto merge__atomic_4_15;
  x1 = arg(a1, 0);
  if_not_equal(x0, x1, merge__atomic_4_22);
  unify_value(a3, a1);
  proceed();
 merge__atomic_4_15:
  deref_and_jump(x0,merge__atomic_4_14);
  *reasonp++ =  x0;
  goto merge__atomic_4_22;
 merge__atomic_4_16:
  deref_and_jump(x0,merge__atomic_4_13);
  *reasonp++ =  x0;
  goto merge__atomic_4_22;
 case VARREF:
  deref_and_jump(a2,merge__atomic_4_12);
  *reasonp++ =  a2;
  goto merge__atomic_4_22;
  };
  goto merge__atomic_4_22;
 case functor_c_1:
 merge__atomic_4_17:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_c_1)) goto merge__atomic_4_22;
  x0 = arg(a2, 0);
 merge__atomic_4_18:
  if (isref(x0)) goto merge__atomic_4_21;
 merge__atomic_4_19:
  if (isref(x0)) goto merge__atomic_4_20;
  x1 = arg(a1, 0);
  if_not_equal(x0, x1, merge__atomic_4_22);
  unify_value(a3, a1);
  proceed();
 merge__atomic_4_20:
  deref_and_jump(x0,merge__atomic_4_19);
  *reasonp++ =  x0;
  goto merge__atomic_4_22;
 merge__atomic_4_21:
  deref_and_jump(x0,merge__atomic_4_18);
  *reasonp++ =  x0;
  goto merge__atomic_4_22;
 case VARREF:
  deref_and_jump(a2,merge__atomic_4_17);
  *reasonp++ =  a2;
  goto merge__atomic_4_22;
  };
  goto merge__atomic_4_22;
  };
  goto merge__atomic_4_22;
 case VARREF:
  deref_and_jump(a1,merge__atomic_4_1);
  *reasonp++ =  a1;
  goto merge__atomic_4_22;
  };
  goto merge__atomic_4_22;
 merge__atomic_4_22:
 merge__atomic_4_23:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_and)) goto merge__atomic_4_33;
 merge__atomic_4_24:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (isint(a1)) goto merge__atomic_4_33;
  switch (symval(a1)) {
 case symval(makesym(atom_a)):
 merge__atomic_4_25:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_a_1)) goto merge__atomic_4_33;
  unify_value(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a2,merge__atomic_4_25);
  *reasonp++ =  a2;
  goto merge__atomic_4_33;
  };
  goto merge__atomic_4_33;
 case symval(makesym(atom_i)):
 merge__atomic_4_26:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_i_1)) goto merge__atomic_4_33;
  unify_value(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a2,merge__atomic_4_26);
  *reasonp++ =  a2;
  goto merge__atomic_4_33;
  };
  goto merge__atomic_4_33;
 case symval(makesym(atom_f)):
 merge__atomic_4_27:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_f_1)) goto merge__atomic_4_33;
  unify_value(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a2,merge__atomic_4_27);
  *reasonp++ =  a2;
  goto merge__atomic_4_33;
  };
  goto merge__atomic_4_33;
 case symval(makesym(atom_c)):
 merge__atomic_4_28:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_c_1)) goto merge__atomic_4_33;
  unify_value(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a2,merge__atomic_4_28);
  *reasonp++ =  a2;
  goto merge__atomic_4_33;
  };
  goto merge__atomic_4_33;
  };
  goto merge__atomic_4_33;
 case FUNCTOR:
  switch (symval(functor_of(a1))) {
 case functor_a_1:
 merge__atomic_4_29:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_a)) goto merge__atomic_4_33;
  unify_value(a3, a1);
  proceed();
 case VARREF:
  deref_and_jump(a2,merge__atomic_4_29);
  *reasonp++ =  a2;
  goto merge__atomic_4_33;
  };
  goto merge__atomic_4_33;
 case functor_i_1:
 merge__atomic_4_30:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_i)) goto merge__atomic_4_33;
  unify_value(a3, a1);
  proceed();
 case VARREF:
  deref_and_jump(a2,merge__atomic_4_30);
  *reasonp++ =  a2;
  goto merge__atomic_4_33;
  };
  goto merge__atomic_4_33;
 case functor_f_1:
 merge__atomic_4_31:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_f)) goto merge__atomic_4_33;
  unify_value(a3, a1);
  proceed();
 case VARREF:
  deref_and_jump(a2,merge__atomic_4_31);
  *reasonp++ =  a2;
  goto merge__atomic_4_33;
  };
  goto merge__atomic_4_33;
 case functor_c_1:
 merge__atomic_4_32:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_c)) goto merge__atomic_4_33;
  unify_value(a3, a1);
  proceed();
 case VARREF:
  deref_and_jump(a2,merge__atomic_4_32);
  *reasonp++ =  a2;
  goto merge__atomic_4_33;
  };
  goto merge__atomic_4_33;
  };
  goto merge__atomic_4_33;
 case VARREF:
  deref_and_jump(a1,merge__atomic_4_24);
  *reasonp++ =  a1;
  goto merge__atomic_4_33;
  };
  goto merge__atomic_4_33;
 case VARREF:
  deref_and_jump(a0,merge__atomic_4_23);
  *reasonp++ =  a0;
  goto merge__atomic_4_33;
  };
  goto merge__atomic_4_33;
 merge__atomic_4_33:
  otherwise(merge__atomic_4_interrupt);
 merge__atomic_4_34:
  if (isref(a1)) goto merge__atomic_4_43;
  gblt_pfunctor(a1,x0,merge__atomic_4_interrupt);
  if (isint(x0)) goto merge__atomic_4_interrupt;
  switch (symval(x0)) {
 case symval(makesym(atom_a)):
  gblt_arity(a1,x1,merge__atomic_4_interrupt);
 merge__atomic_4_35:
  if (isref(a2)) goto merge__atomic_4_36;
  gblt_pfunctor(a2,x2,merge__atomic_4_interrupt);
  if (x2 != makesym(atom_a)) goto merge__atomic_4_interrupt;
  gblt_arity(a2,x3,merge__atomic_4_interrupt);
  unify_value(a3, makesym(atom_a));
  proceed();
 merge__atomic_4_36:
  deref_and_jump(a2,merge__atomic_4_35);
  *reasonp++ =  a2;
  goto merge__atomic_4_interrupt;
 case symval(makesym(atom_i)):
  gblt_arity(a1,x1,merge__atomic_4_interrupt);
 merge__atomic_4_37:
  if (isref(a2)) goto merge__atomic_4_38;
  gblt_pfunctor(a2,x2,merge__atomic_4_interrupt);
  if (x2 != makesym(atom_i)) goto merge__atomic_4_interrupt;
  gblt_arity(a2,x3,merge__atomic_4_interrupt);
  unify_value(a3, makesym(atom_i));
  proceed();
 merge__atomic_4_38:
  deref_and_jump(a2,merge__atomic_4_37);
  *reasonp++ =  a2;
  goto merge__atomic_4_interrupt;
 case symval(makesym(atom_f)):
  gblt_arity(a1,x1,merge__atomic_4_interrupt);
 merge__atomic_4_39:
  if (isref(a2)) goto merge__atomic_4_40;
  gblt_pfunctor(a2,x2,merge__atomic_4_interrupt);
  if (x2 != makesym(atom_f)) goto merge__atomic_4_interrupt;
  gblt_arity(a2,x3,merge__atomic_4_interrupt);
  unify_value(a3, makesym(atom_f));
  proceed();
 merge__atomic_4_40:
  deref_and_jump(a2,merge__atomic_4_39);
  *reasonp++ =  a2;
  goto merge__atomic_4_interrupt;
 case symval(makesym(atom_c)):
  gblt_arity(a1,x1,merge__atomic_4_interrupt);
 merge__atomic_4_41:
  if (isref(a2)) goto merge__atomic_4_42;
  gblt_pfunctor(a2,x2,merge__atomic_4_interrupt);
  if (x2 != makesym(atom_c)) goto merge__atomic_4_interrupt;
  gblt_arity(a2,x3,merge__atomic_4_interrupt);
  unify_value(a3, makesym(atom_c));
  proceed();
 merge__atomic_4_42:
  deref_and_jump(a2,merge__atomic_4_41);
  *reasonp++ =  a2;
  goto merge__atomic_4_interrupt;
  };
  goto merge__atomic_4_interrupt;
 merge__atomic_4_43:
  deref_and_jump(a1,merge__atomic_4_34);
  *reasonp++ =  a1;
  goto merge__atomic_4_interrupt;
 merge__atomic_4_ext_interrupt:
  reasonp = 0l;
 merge__atomic_4_interrupt:
  toppred = &predicate_type_xmerge__atomic_4;
  goto interrupt_4;
 }

 value2types_7_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 value2types_7_clear_reason:
  reasonp = reasons;
 value2types_7_0:
 value2types_7_1:
  switch (ptagof(a4)) {
 case CONS:
  x0 = opt_analyze_dependency;
 value2types_7_2:
  if (x0 != makeint(0L)) goto value2types_7_3;
  a3 = NILATOM;
  a4 = NILATOM;
  execute(value2types_7_clear_reason);
  goto value2types_7_ext_interrupt;
 case VARREF:
  deref_and_jump(a4,value2types_7_1);
  *reasonp++ =  a4;
  goto value2types_7_3;
  };
  goto value2types_7_3;
 value2types_7_3:
  otherwise(value2types_7_interrupt);
  x0 = opt_trace_atom_value;
  x1 = a0;
  x2 = a1;
  x3 = a2;
  x4 = a3;
  x5 = a4;
  x6 = a5;
  a7 = a6;
  a8 = x0;
  a6 = x6;
  a5 = x5;
  a4 = x4;
  a3 = x3;
  a2 = x2;
  a1 = x1;
  a0 = makesym(atom_root);
  execute(value2types1_9_clear_reason);
  goto value2types1_9_ext_interrupt;
 value2types_7_ext_interrupt:
  reasonp = 0l;
 value2types_7_interrupt:
  toppred = &predicate_type_xvalue2types_7;
  goto interrupt_7;
 }

 value2types1_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 value2types1_9_clear_reason:
  reasonp = reasons;
 value2types1_9_0:
 value2types1_9_1:
  switch (ptagof(a3)) {
 case FUNCTOR:
  switch (symval(functor_of(a3))) {
 case functor_atom_1:
 value2types1_9_2:
  switch (ptagof(a8)) {
 case ATOMIC:
 value2types1_9_3:
  switch ((unsigned long)a8) {
 case (unsigned long) makeint(0L):
  allocp[0] = makesym(functor_t_4);
  allocp[1] = makesym(atom_a);
  allocp[2] = a4;
  allocp[3] = a5;
  allocp[4] = a6;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a7, x1);
  proceed();
 case (unsigned long) makeint(1L):
  allocp[0] = makesym(functor_a_1);
  allocp[1] = arg(a3, 0);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_t_4);
  allocp[3] = x0;
  allocp[4] = a4;
  allocp[5] = a5;
  allocp[6] = a6;
  x1 = makefunctor(&allocp[2]);
  allocp[7] = NILATOM;
  allocp[8] = x1;
  x2 = makecons(&allocp[7]);
  allocp += 9;
  unify_value(a7, x2);
  proceed();
  };
  goto value2types1_9_13;
 case VARREF:
  deref_and_jump(a8,value2types1_9_2);
  *reasonp++ =  a8;
  goto value2types1_9_13;
  };
  goto value2types1_9_13;
 case functor_integer_1:
 value2types1_9_4:
  switch (ptagof(a8)) {
 case ATOMIC:
 value2types1_9_5:
  switch ((unsigned long)a8) {
 case (unsigned long) makeint(0L):
  allocp[0] = makesym(functor_t_4);
  allocp[1] = makesym(atom_i);
  allocp[2] = a4;
  allocp[3] = a5;
  allocp[4] = a6;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a7, x1);
  proceed();
 case (unsigned long) makeint(1L):
  allocp[0] = makesym(functor_i_1);
  allocp[1] = arg(a3, 0);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_t_4);
  allocp[3] = x0;
  allocp[4] = a4;
  allocp[5] = a5;
  allocp[6] = a6;
  x1 = makefunctor(&allocp[2]);
  allocp[7] = NILATOM;
  allocp[8] = x1;
  x2 = makecons(&allocp[7]);
  allocp += 9;
  unify_value(a7, x2);
  proceed();
  };
  goto value2types1_9_13;
 case VARREF:
  deref_and_jump(a8,value2types1_9_4);
  *reasonp++ =  a8;
  goto value2types1_9_13;
  };
  goto value2types1_9_13;
 case functor_float_1:
 value2types1_9_6:
  switch (ptagof(a8)) {
 case ATOMIC:
 value2types1_9_7:
  switch ((unsigned long)a8) {
 case (unsigned long) makeint(0L):
  allocp[0] = makesym(functor_t_4);
  allocp[1] = makesym(atom_f);
  allocp[2] = a4;
  allocp[3] = a5;
  allocp[4] = a6;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a7, x1);
  proceed();
 case (unsigned long) makeint(1L):
  allocp[0] = makesym(functor_f_1);
  allocp[1] = arg(a3, 0);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_t_4);
  allocp[3] = x0;
  allocp[4] = a4;
  allocp[5] = a5;
  allocp[6] = a6;
  x1 = makefunctor(&allocp[2]);
  allocp[7] = NILATOM;
  allocp[8] = x1;
  x2 = makecons(&allocp[7]);
  allocp += 9;
  unify_value(a7, x2);
  proceed();
  };
  goto value2types1_9_13;
 case VARREF:
  deref_and_jump(a8,value2types1_9_6);
  *reasonp++ =  a8;
  goto value2types1_9_13;
  };
  goto value2types1_9_13;
 case functor_vector_1:
  x0 = arg(a3, 0);
 value2types1_9_8:
  switch (ptagof(x0)) {
 case FUNCTOR:
 value2types1_9_9:
  if (!isgobj(x0)) goto value2types1_9_13;
  if (!isclass(x0,vector)) goto value2types1_9_13;
  gblt_size_of_vector(x0,x1,value2types1_9_13);
  bblt_sub_no_check(x1,makeint(1L),x2);
  allocp[0] = makesym(functor_s_3);
  allocp[1] = makesym(atom___v);
  allocp[2] = x1;
  allocp[3] = x4 = makeref(&allocp[3]);
  x3 = makefunctor(&allocp[0]);
  allocp[4] = makesym(functor_t_4);
  allocp[5] = x3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  x5 = makefunctor(&allocp[4]);
  allocp[9] = NILATOM;
  allocp[10] = x5;
  x6 = makecons(&allocp[9]);
  allocp += 11;
  unify_value(a7, x6);
  a0 = a1;
  a1 = a2;
  a2 = x2;
  a3 = x0;
  a7 = NILATOM;
  a9 = a8;
  a8 = x4;
  execute(value2types__vector__arg_10_0);
  goto value2types__vector__arg_10_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,value2types1_9_8);
  *reasonp++ =  x0;
  goto value2types1_9_13;
  };
  goto value2types1_9_13;
 case functor_string_1:
 value2types1_9_10:
  switch (ptagof(a8)) {
 case ATOMIC:
 value2types1_9_11:
  switch ((unsigned long)a8) {
 case (unsigned long) makeint(0L):
  allocp[0] = makesym(functor_t_4);
  allocp[1] = makesym(atom_c);
  allocp[2] = a4;
  allocp[3] = a5;
  allocp[4] = a6;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a7, x1);
  proceed();
 case (unsigned long) makeint(1L):
  allocp[0] = makesym(functor_c_1);
  allocp[1] = arg(a3, 0);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_t_4);
  allocp[3] = x0;
  allocp[4] = a4;
  allocp[5] = a5;
  allocp[6] = a6;
  x1 = makefunctor(&allocp[2]);
  allocp[7] = NILATOM;
  allocp[8] = x1;
  x2 = makecons(&allocp[7]);
  allocp += 9;
  unify_value(a7, x2);
  proceed();
  };
  goto value2types1_9_13;
 case VARREF:
  deref_and_jump(a8,value2types1_9_10);
  *reasonp++ =  a8;
  goto value2types1_9_13;
  };
  goto value2types1_9_13;
 case functor_functor_1:
  allocp[0] = makesym(functor_s_3);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  x0 = makefunctor(&allocp[0]);
  allocp[4] = makesym(functor_t_4);
  allocp[5] = x0;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  x4 = makefunctor(&allocp[4]);
  allocp[9] = NILATOM;
  allocp[10] = x4;
  x5 = makecons(&allocp[9]);
  allocp += 11;
  unify_value(a7, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xvalue2types__functor__arg_10);
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = x2;
  x6 = arg(a3, 0);
  allocp[5] = x6;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = NILATOM;
  allocp[10] = x3;
  allocp[11] = a8;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[14] = x6;
  allocp[15] = x1;
  allocp[16] = x2;
  qp = (struct goalrec*)&allocp[12];
  allocp += 17;
  proceed();
 case functor_list_1:
  x0 = arg(a3, 0);
 value2types1_9_12:
  switch (ptagof(x0)) {
 case CONS:
  allocp[0] = makesym(functor_arg_2);
  allocp[1] = x2 = makeref(&allocp[1]);
  allocp[2] = x3 = makeref(&allocp[2]);
  x1 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_s_3);
  allocp[4] = PERIODATOM;
  allocp[5] = makeint(2L);
  allocp[6] = x1;
  x4 = makefunctor(&allocp[3]);
  allocp[7] = makesym(functor_t_4);
  allocp[8] = x4;
  allocp[9] = a4;
  allocp[10] = a5;
  allocp[11] = a6;
  x5 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x5;
  x6 = makecons(&allocp[12]);
  allocp += 14;
  unify_value(a7, x6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xvalue2types1_9);
  allocp[2] = makesym(atom_arg);
  allocp[3] = a1;
  allocp[4] = a2;
  x7 = cdr_of(x0);
  allocp[5] = x7;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = x3;
  allocp[10] = a8;
  a0 = makesym(atom_arg);
  a3 = car_of(x0);
  a7 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 11;
  execute(value2types1_9_0);
  goto value2types1_9_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,value2types1_9_12);
  *reasonp++ =  x0;
  goto value2types1_9_13;
  };
  goto value2types1_9_13;
  };
  goto value2types1_9_13;
 case VARREF:
  deref_and_jump(a3,value2types1_9_1);
  *reasonp++ =  a3;
  goto value2types1_9_13;
  };
  goto value2types1_9_13;
 value2types1_9_13:
 value2types1_9_14:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_arg)) goto value2types1_9_17;
 value2types1_9_15:
  switch (ptagof(a3)) {
 case FUNCTOR:
  if (functor_of(a3) != makesym(functor_variable_3)) goto value2types1_9_17;
  x0 = arg(a3, 2);
 value2types1_9_16:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (isint(x0)) goto value2types1_9_17;
  switch (symval(x0)) {
 case symval(makesym(atom__3F)):
  allocp[0] = makesym(functor_v_4);
  allocp[1] = a1;
  allocp[2] = a2;
  allocp[3] = arg(a3, 1);
  allocp[4] = arg(a3, 0);
  x1 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_t_4);
  allocp[6] = x1;
  allocp[7] = NILATOM;
  allocp[8] = NILATOM;
  allocp[9] = makesym(atom__3F);
  x2 = makefunctor(&allocp[5]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp += 12;
  unify_value(a7, x3);
  proceed();
 case symval(makesym(atom_i)):
  allocp[0] = makesym(functor_v_4);
  allocp[1] = a1;
  allocp[2] = a2;
  allocp[3] = arg(a3, 1);
  allocp[4] = arg(a3, 0);
  x1 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_t_4);
  allocp[6] = x1;
  allocp[7] = NILATOM;
  allocp[8] = NILATOM;
  allocp[9] = makesym(atom_u);
  x2 = makefunctor(&allocp[5]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp += 12;
  unify_value(a7, x3);
  proceed();
 case symval(makesym(atom_o)):
  allocp[0] = makesym(functor_v_4);
  allocp[1] = a1;
  allocp[2] = a2;
  allocp[3] = arg(a3, 1);
  allocp[4] = arg(a3, 0);
  x1 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_t_4);
  allocp[6] = x1;
  allocp[7] = NILATOM;
  allocp[8] = NILATOM;
  allocp[9] = makesym(atom_r);
  x2 = makefunctor(&allocp[5]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp += 12;
  unify_value(a7, x3);
  proceed();
  };
  goto value2types1_9_17;
 case VARREF:
  deref_and_jump(x0,value2types1_9_16);
  *reasonp++ =  x0;
  goto value2types1_9_17;
  };
  goto value2types1_9_17;
 case VARREF:
  deref_and_jump(a3,value2types1_9_15);
  *reasonp++ =  a3;
  goto value2types1_9_17;
  };
  goto value2types1_9_17;
 case VARREF:
  deref_and_jump(a0,value2types1_9_14);
  *reasonp++ =  a0;
  goto value2types1_9_17;
  };
  goto value2types1_9_17;
 value2types1_9_17:
  otherwise(value2types1_9_interrupt);
  unify_value(a7, makecons(cons_const_0));
  proceed();
 value2types1_9_ext_interrupt:
  reasonp = 0l;
 value2types1_9_interrupt:
  toppred = &predicate_type_xvalue2types1_9;
  goto interrupt_9;
 }

 value2types__functor__arg_10_top: {
  q x0, x1, x2, x3, x4;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 value2types__functor__arg_10_clear_reason:
  reasonp = reasons;
 value2types__functor__arg_10_0:
 value2types__functor__arg_10_1:
  if (!isint(a2)) goto value2types__functor__arg_10_3;
  gblt_greater(a2,makeint(0L),value2types__functor__arg_10_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xvalue2types__functor__arg_10);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = x1 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = a9;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[14] = a2;
  allocp[15] = makeint(1L);
  allocp[16] = x0;
  allocp[17] = a7;
  allocp[18] = x3 = makeref(&allocp[18]);
  x2 = makecons(&allocp[17]);
  qp = (struct goalrec*)&allocp[12];
  allocp += 19;
  unify_value(x1, x2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xvalue2types1_9);
  allocp[2] = makesym(atom_arg);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = x4 = makeref(&allocp[5]);
  allocp[6] = NILATOM;
  allocp[7] = NILATOM;
  allocp[8] = a6;
  allocp[9] = x3;
  allocp[10] = a9;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_functor__table_xarg_3);
  allocp[13] = a2;
  allocp[14] = a3;
  allocp[15] = x4;
  qp = (struct goalrec*)&allocp[11];
  allocp += 16;
  proceed();
 value2types__functor__arg_10_2:
  if (a2 != makeint(0L)) goto value2types__functor__arg_10_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_uty_xcreate__functor_3);
  allocp[2] = makesym(atom_arg);
  allocp[3] = a7;
  allocp[4] = a8;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 value2types__functor__arg_10_3:
  if (!isref(a2)) goto value2types__functor__arg_10_interrupt;
  deref_and_jump(a2,value2types__functor__arg_10_1);
  *reasonp++ =  a2;
  goto value2types__functor__arg_10_interrupt;
 value2types__functor__arg_10_ext_interrupt:
  reasonp = 0l;
 value2types__functor__arg_10_interrupt:
  goto interrupt_10;
 }

 value2types__vector__arg_10_top: {
  q x0, x1, x2, x3, x4, x5;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 value2types__vector__arg_10_clear_reason:
  reasonp = reasons;
 value2types__vector__arg_10_0:
 value2types__vector__arg_10_1:
  if (!isint(a2)) goto value2types__vector__arg_10_3;
  gblt_greater_or_eq(a2,makeint(0L),value2types__vector__arg_10_2);
  generic_arg[0] = a2;
  allocp[0] = x0 = makeref(&allocp[0]);
  generic_arg[1] = x0;
  call_generic(a3, functor_element_2, 1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xvalue2types__vector__arg_10);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = a9;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[14] = a2;
  allocp[15] = makeint(1L);
  allocp[16] = x1;
  allocp[17] = a7;
  allocp[18] = x4 = makeref(&allocp[18]);
  x3 = makecons(&allocp[17]);
  qp = (struct goalrec*)&allocp[12];
  allocp += 19;
  unify_value(x2, x3);
  x5 = a0;
  a2 = a1;
  a3 = x0;
  a4 = NILATOM;
  a5 = NILATOM;
  a7 = x4;
  a8 = a9;
  a1 = x5;
  a0 = makesym(atom_arg);
  execute(value2types1_9_0);
  goto value2types1_9_ext_interrupt;
 value2types__vector__arg_10_2:
  gblt_less(a2,makeint(0L),value2types__vector__arg_10_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_uty_xcreate__functor_3);
  allocp[2] = makesym(atom_arg);
  allocp[3] = a7;
  allocp[4] = a8;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 value2types__vector__arg_10_3:
  if (!isref(a2)) goto value2types__vector__arg_10_interrupt;
  deref_and_jump(a2,value2types__vector__arg_10_1);
  *reasonp++ =  a2;
  goto value2types__vector__arg_10_interrupt;
 value2types__vector__arg_10_ext_interrupt:
  reasonp = 0l;
 value2types__vector__arg_10_interrupt:
  toppred = &predicate_type_xvalue2types__vector__arg_10;
  goto interrupt_10;
 }

 add__indirect__deps_11_top: {
  q x0;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 add__indirect__deps_11_clear_reason:
  reasonp = reasons;
 add__indirect__deps_11_0:
 add__indirect__deps_11_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto add__indirect__deps_11_4;
  switch (symval(a0)) {
 case symval(makesym(atom_i)):
 add__indirect__deps_11_2:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_o)) goto add__indirect__deps_11_4;
  unify(a9, a8);
  allocp[0] = a4;
  allocp[1] = a7;
  x0 = makecons(&allocp[0]);
  a0 = x0;
  a1 = a8;
  a2 = a10;
  allocp += 2;
  execute(add__dep__goals_3_0);
  goto add__dep__goals_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,add__indirect__deps_11_2);
  *reasonp++ =  a1;
  goto add__indirect__deps_11_4;
  };
  goto add__indirect__deps_11_4;
 case symval(makesym(atom_o)):
 add__indirect__deps_11_3:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_i)) goto add__indirect__deps_11_4;
  unify(a10, a8);
  allocp[0] = a5;
  allocp[1] = a6;
  x0 = makecons(&allocp[0]);
  a0 = x0;
  a1 = a8;
  a2 = a9;
  allocp += 2;
  execute(add__dep__goals_3_0);
  goto add__dep__goals_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,add__indirect__deps_11_3);
  *reasonp++ =  a1;
  goto add__indirect__deps_11_4;
  };
  goto add__indirect__deps_11_4;
  };
  goto add__indirect__deps_11_4;
 case VARREF:
  deref_and_jump(a0,add__indirect__deps_11_1);
  *reasonp++ =  a0;
  goto add__indirect__deps_11_4;
  };
  goto add__indirect__deps_11_4;
 add__indirect__deps_11_4:
  otherwise(add__indirect__deps_11_interrupt);
  unify_value(a9, NILATOM);
  unify_value(a10, NILATOM);
  proceed();
 add__indirect__deps_11_ext_interrupt:
  reasonp = 0l;
 add__indirect__deps_11_interrupt:
  goto interrupt_11;
 }

 add__dep__goals_3_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 add__dep__goals_3_clear_reason:
  reasonp = reasons;
 add__dep__goals_3_0:
 add__dep__goals_3_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xadd__dep__goals_3);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  a0 = car_of(a0);
  a2 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(add__dep__goal_3_0);
  goto add__dep__goal_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto add__dep__goals_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,add__dep__goals_3_1);
  *reasonp++ =  a0;
  goto add__dep__goals_3_interrupt;
  };
  goto add__dep__goals_3_interrupt;
 add__dep__goals_3_ext_interrupt:
  reasonp = 0l;
 add__dep__goals_3_interrupt:
  toppred = &predicate_type_xadd__dep__goals_3;
  goto interrupt_3;
 }

 add__dep__goal_3_top: {
  q x0, x1, x2, x3, x4, x5;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 add__dep__goal_3_clear_reason:
  reasonp = reasons;
 add__dep__goal_3_0:
  x0 = opt_analyze_dependency;
 add__dep__goal_3_1:
  if (x0 != makeint(0L)) goto add__dep__goal_3_2;
  unify(a2, a1);
  proceed();
 add__dep__goal_3_2:
  otherwise(add__dep__goal_3_interrupt);
 add__dep__goal_3_3:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 add__dep__goal_3_4:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__3F)) goto add__dep__goal_3_interrupt;
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = makesym(atom__3F);
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x1);
  a1 = cdr_of(a1);
  a2 = x2;
  execute(add__dep__goal_3_0);
  goto add__dep__goal_3_ext_interrupt;
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_4)) goto add__dep__goal_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xadd__dep__goal_3);
  allocp[2] = a0;
  x1 = cdr_of(a1);
  allocp[3] = x1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = makesym(functor_t_4);
  allocp[6] = arg(x0, 0);
  allocp[7] = arg(x0, 1);
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = arg(x0, 3);
  x3 = makefunctor(&allocp[5]);
  allocp[10] = x2;
  allocp[11] = x3;
  x5 = makecons(&allocp[10]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  unify_value(a2, x5);
  a1 = arg(x0, 2);
  a2 = x4;
  execute(add__dep__goal1_3_0);
  goto add__dep__goal1_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,add__dep__goal_3_4);
  *reasonp++ =  x0;
  goto add__dep__goal_3_interrupt;
  };
  goto add__dep__goal_3_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto add__dep__goal_3_interrupt;
  unify_value(a2, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a1,add__dep__goal_3_3);
  *reasonp++ =  a1;
  goto add__dep__goal_3_interrupt;
  };
  goto add__dep__goal_3_interrupt;
 add__dep__goal_3_ext_interrupt:
  reasonp = 0l;
 add__dep__goal_3_interrupt:
  toppred = &predicate_type_xadd__dep__goal_3;
  goto interrupt_3;
 }

 add__dep__goal1_3_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 add__dep__goal1_3_clear_reason:
  reasonp = reasons;
 add__dep__goal1_3_0:
 add__dep__goal1_3_1:
  switch (ptagof(a1)) {
 case CONS:
 add__dep__goal1_3_2:
  if (isref(a0)) goto add__dep__goal1_3_5;
 add__dep__goal1_3_3:
  if (isref(a0)) goto add__dep__goal1_3_4;
  x0 = car_of(a1);
  if_not_equal(a0, x0, add__dep__goal1_3_6);
  allocp[0] = cdr_of(a1);
  allocp[1] = x0;
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x1);
  proceed();
 add__dep__goal1_3_4:
  deref_and_jump(a0,add__dep__goal1_3_3);
  *reasonp++ =  a0;
  goto add__dep__goal1_3_6;
 add__dep__goal1_3_5:
  deref_and_jump(a0,add__dep__goal1_3_2);
  *reasonp++ =  a0;
  goto add__dep__goal1_3_6;
 case VARREF:
  deref_and_jump(a1,add__dep__goal1_3_1);
  *reasonp++ =  a1;
  goto add__dep__goal1_3_6;
  };
  goto add__dep__goal1_3_6;
 add__dep__goal1_3_6:
  otherwise(add__dep__goal1_3_interrupt);
 add__dep__goal1_3_7:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = car_of(a1);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  a1 = cdr_of(a1);
  a2 = x1;
  execute(add__dep__goal1_3_0);
  goto add__dep__goal1_3_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto add__dep__goal1_3_interrupt;
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,add__dep__goal1_3_7);
  *reasonp++ =  a1;
  goto add__dep__goal1_3_interrupt;
  };
  goto add__dep__goal1_3_interrupt;
 add__dep__goal1_3_ext_interrupt:
  reasonp = 0l;
 add__dep__goal1_3_interrupt:
  toppred = &predicate_type_xadd__dep__goal1_3;
  goto interrupt_3;
 }

 add__i__goals_3_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 add__i__goals_3_clear_reason:
  reasonp = reasons;
 add__i__goals_3_0:
 add__i__goals_3_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xadd__i__goals_3);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  a0 = car_of(a0);
  a2 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(add__i__goal_3_0);
  goto add__i__goal_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto add__i__goals_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,add__i__goals_3_1);
  *reasonp++ =  a0;
  goto add__i__goals_3_interrupt;
  };
  goto add__i__goals_3_interrupt;
 add__i__goals_3_ext_interrupt:
  reasonp = 0l;
 add__i__goals_3_interrupt:
  goto interrupt_3;
 }

 add__i__goal_3_top: {
  q x0, x1, x2, x3, x4, x5;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 add__i__goal_3_clear_reason:
  reasonp = reasons;
 add__i__goal_3_0:
  x0 = opt_analyze_dependency;
 add__i__goal_3_1:
  if (x0 != makeint(0L)) goto add__i__goal_3_2;
  unify(a2, a1);
  proceed();
 add__i__goal_3_2:
  otherwise(add__i__goal_3_interrupt);
 add__i__goal_3_3:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 add__i__goal_3_4:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__3F)) goto add__i__goal_3_interrupt;
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = makesym(atom__3F);
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x1);
  a1 = cdr_of(a1);
  a2 = x2;
  execute(add__i__goal_3_0);
  goto add__i__goal_3_ext_interrupt;
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_4)) goto add__i__goal_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xadd__i__goal_3);
  allocp[2] = a0;
  x1 = cdr_of(a1);
  allocp[3] = x1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = makesym(functor_t_4);
  allocp[6] = arg(x0, 0);
  allocp[7] = x4 = makeref(&allocp[7]);
  allocp[8] = arg(x0, 2);
  allocp[9] = arg(x0, 3);
  x3 = makefunctor(&allocp[5]);
  allocp[10] = x2;
  allocp[11] = x3;
  x5 = makecons(&allocp[10]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  unify_value(a2, x5);
  a1 = arg(x0, 1);
  a2 = x4;
  execute(add__i__goal1_3_0);
  goto add__i__goal1_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,add__i__goal_3_4);
  *reasonp++ =  x0;
  goto add__i__goal_3_interrupt;
  };
  goto add__i__goal_3_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto add__i__goal_3_interrupt;
  unify_value(a2, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a1,add__i__goal_3_3);
  *reasonp++ =  a1;
  goto add__i__goal_3_interrupt;
  };
  goto add__i__goal_3_interrupt;
 add__i__goal_3_ext_interrupt:
  reasonp = 0l;
 add__i__goal_3_interrupt:
  toppred = &predicate_type_xadd__i__goal_3;
  goto interrupt_3;
 }

 add__i__goal1_3_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 add__i__goal1_3_clear_reason:
  reasonp = reasons;
 add__i__goal1_3_0:
 add__i__goal1_3_1:
  switch (ptagof(a1)) {
 case CONS:
 add__i__goal1_3_2:
  if (isref(a0)) goto add__i__goal1_3_5;
 add__i__goal1_3_3:
  if (isref(a0)) goto add__i__goal1_3_4;
  x0 = car_of(a1);
  if_not_equal(a0, x0, add__i__goal1_3_6);
  allocp[0] = cdr_of(a1);
  allocp[1] = x0;
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x1);
  proceed();
 add__i__goal1_3_4:
  deref_and_jump(a0,add__i__goal1_3_3);
  *reasonp++ =  a0;
  goto add__i__goal1_3_6;
 add__i__goal1_3_5:
  deref_and_jump(a0,add__i__goal1_3_2);
  *reasonp++ =  a0;
  goto add__i__goal1_3_6;
 case VARREF:
  deref_and_jump(a1,add__i__goal1_3_1);
  *reasonp++ =  a1;
  goto add__i__goal1_3_6;
  };
  goto add__i__goal1_3_6;
 add__i__goal1_3_6:
  otherwise(add__i__goal1_3_interrupt);
 add__i__goal1_3_7:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = car_of(a1);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  a1 = cdr_of(a1);
  a2 = x1;
  execute(add__i__goal1_3_0);
  goto add__i__goal1_3_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto add__i__goal1_3_interrupt;
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,add__i__goal1_3_7);
  *reasonp++ =  a1;
  goto add__i__goal1_3_interrupt;
  };
  goto add__i__goal1_3_interrupt;
 add__i__goal1_3_ext_interrupt:
  reasonp = 0l;
 add__i__goal1_3_interrupt:
  toppred = &predicate_type_xadd__i__goal1_3;
  goto interrupt_3;
 }

 set__ru_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 set__ru_3_clear_reason:
  reasonp = reasons;
 set__ru_3_0:
 set__ru_3_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 set__ru_3_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__3F)) goto set__ru_3_4;
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = makesym(atom__3F);
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x1);
  a1 = cdr_of(a1);
  a2 = x2;
  execute(set__ru_3_0);
  goto set__ru_3_ext_interrupt;
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_4)) goto set__ru_3_4;
  x1 = arg(x0, 0);
 set__ru_3_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_s_3)) goto set__ru_3_4;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xset__ru_3);
  allocp[2] = a0;
  x2 = cdr_of(a1);
  allocp[3] = x2;
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = makesym(functor_t_4);
  allocp[6] = x5 = makeref(&allocp[6]);
  allocp[7] = arg(x0, 1);
  allocp[8] = arg(x0, 2);
  allocp[9] = a0;
  x4 = makefunctor(&allocp[5]);
  allocp[10] = x3;
  allocp[11] = x4;
  x6 = makecons(&allocp[10]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  unify_value(a2, x6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = makeint(3L);
  allocp[3] = x1;
  allocp[4] = x7 = makeref(&allocp[4]);
  allocp[5] = x5;
  a1 = arg(x1, 1);
  a2 = arg(x1, 2);
  a3 = x7;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(set__ru__args_4_0);
  goto set__ru__args_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,set__ru_3_3);
  *reasonp++ =  x1;
  goto set__ru_3_4;
  };
  goto set__ru_3_4;
 case VARREF:
  deref_and_jump(x0,set__ru_3_2);
  *reasonp++ =  x0;
  goto set__ru_3_4;
  };
  goto set__ru_3_4;
 case VARREF:
  deref_and_jump(a1,set__ru_3_1);
  *reasonp++ =  a1;
  goto set__ru_3_4;
  };
  goto set__ru_3_4;
 set__ru_3_4:
  otherwise(set__ru_3_interrupt);
 set__ru_3_5:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 set__ru_3_6:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_4)) goto set__ru_3_interrupt;
  allocp[0] = makesym(functor_t_4);
  allocp[1] = arg(x0, 0);
  allocp[2] = arg(x0, 1);
  allocp[3] = arg(x0, 2);
  allocp[4] = a0;
  x1 = makefunctor(&allocp[0]);
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = x1;
  x2 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a2, x2);
  a1 = cdr_of(a1);
  a2 = x3;
  execute(set__ru_3_0);
  goto set__ru_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,set__ru_3_6);
  *reasonp++ =  x0;
  goto set__ru_3_interrupt;
  };
  goto set__ru_3_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto set__ru_3_interrupt;
  unify_value(a2, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a1,set__ru_3_5);
  *reasonp++ =  a1;
  goto set__ru_3_interrupt;
  };
  goto set__ru_3_interrupt;
 set__ru_3_ext_interrupt:
  reasonp = 0l;
 set__ru_3_interrupt:
  goto interrupt_3;
 }

 set__ru__args_4_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 set__ru__args_4_clear_reason:
  reasonp = reasons;
 set__ru__args_4_0:
 set__ru__args_4_1:
  if (!isint(a1)) goto set__ru__args_4_3;
  gblt_greater(a1,makeint(0L),set__ru__args_4_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xset__ru__args_4);
  allocp[2] = a0;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a1;
  allocp[9] = makeint(1L);
  allocp[10] = x0;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[13] = a1;
  allocp[14] = a2;
  allocp[15] = x2 = makeref(&allocp[15]);
  allocp[16] = x1;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_type_xset__ru_3);
  allocp[19] = a0;
  allocp[20] = x3 = makeref(&allocp[20]);
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[17];
  allocp[23] = (q)(&predicate_functor__table_xarg_3);
  allocp[24] = a1;
  allocp[25] = a2;
  allocp[26] = x3;
  qp = (struct goalrec*)&allocp[22];
  allocp += 27;
  proceed();
 set__ru__args_4_2:
  if (a1 != makeint(0L)) goto set__ru__args_4_interrupt;
  unify(a3, a2);
  proceed();
 set__ru__args_4_3:
  if (!isref(a1)) goto set__ru__args_4_interrupt;
  deref_and_jump(a1,set__ru__args_4_1);
  *reasonp++ =  a1;
  goto set__ru__args_4_interrupt;
 set__ru__args_4_ext_interrupt:
  reasonp = 0l;
 set__ru__args_4_interrupt:
  toppred = &predicate_type_xset__ru__args_4;
  goto interrupt_4;
 }

 type2atom_2_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  qp = qp->next;
 type2atom_2_clear_reason:
  reasonp = reasons;
 type2atom_2_0:
 type2atom_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 type2atom_2_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__3F)) goto type2atom_2_4;
  unify_value(a1, makesym(atom__3F));
  proceed();
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_4)) goto type2atom_2_4;
  x1 = arg(x0, 0);
 type2atom_2_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_a)) goto type2atom_2_4;
  unify_value(a1, makesym(atom_a));
  proceed();
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_a_1)) goto type2atom_2_4;
  allocp[0] = makesym(functor_a_1);
  allocp[1] = arg(x1, 0);
  x2 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x2);
  proceed();
 case VARREF:
  deref_and_jump(x1,type2atom_2_3);
  *reasonp++ =  x1;
  goto type2atom_2_4;
  };
  goto type2atom_2_4;
 case VARREF:
  deref_and_jump(x0,type2atom_2_2);
  *reasonp++ =  x0;
  goto type2atom_2_4;
  };
  goto type2atom_2_4;
 case VARREF:
  deref_and_jump(a0,type2atom_2_1);
  *reasonp++ =  a0;
  goto type2atom_2_4;
  };
  goto type2atom_2_4;
 type2atom_2_4:
  otherwise(type2atom_2_interrupt);
 type2atom_2_5:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(type2atom_2_0);
  goto type2atom_2_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto type2atom_2_interrupt;
  unify_value(a1, makesym(atom__3F));
  proceed();
 case VARREF:
  deref_and_jump(a0,type2atom_2_5);
  *reasonp++ =  a0;
  goto type2atom_2_interrupt;
  };
  goto type2atom_2_interrupt;
 type2atom_2_ext_interrupt:
  reasonp = 0l;
 type2atom_2_interrupt:
  goto interrupt_2;
 }

 type2int_2_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  qp = qp->next;
 type2int_2_clear_reason:
  reasonp = reasons;
 type2int_2_0:
 type2int_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 type2int_2_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__3F)) goto type2int_2_4;
  unify_value(a1, makesym(atom__3F));
  proceed();
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_4)) goto type2int_2_4;
  x1 = arg(x0, 0);
 type2int_2_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_i)) goto type2int_2_4;
  unify_value(a1, makesym(atom_i));
  proceed();
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_i_1)) goto type2int_2_4;
  allocp[0] = makesym(functor_i_1);
  allocp[1] = arg(x1, 0);
  x2 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x2);
  proceed();
 case VARREF:
  deref_and_jump(x1,type2int_2_3);
  *reasonp++ =  x1;
  goto type2int_2_4;
  };
  goto type2int_2_4;
 case VARREF:
  deref_and_jump(x0,type2int_2_2);
  *reasonp++ =  x0;
  goto type2int_2_4;
  };
  goto type2int_2_4;
 case VARREF:
  deref_and_jump(a0,type2int_2_1);
  *reasonp++ =  a0;
  goto type2int_2_4;
  };
  goto type2int_2_4;
 type2int_2_4:
  otherwise(type2int_2_interrupt);
 type2int_2_5:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(type2int_2_0);
  goto type2int_2_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto type2int_2_interrupt;
  unify_value(a1, makesym(atom__3F));
  proceed();
 case VARREF:
  deref_and_jump(a0,type2int_2_5);
  *reasonp++ =  a0;
  goto type2int_2_interrupt;
  };
  goto type2int_2_interrupt;
 type2int_2_ext_interrupt:
  reasonp = 0l;
 type2int_2_interrupt:
  goto interrupt_2;
 }

 type2list_2_top: {
  q x0;
  a1 = qp->args[1];
  qp = qp->next;
 type2list_2_clear_reason:
  reasonp = reasons;
 type2list_2_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xtype2list1_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  a1 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  execute(type2structtype_2_0);
  goto type2structtype_2_ext_interrupt;
 type2list_2_ext_interrupt:
  reasonp = 0l;
 type2list_2_interrupt:
  goto interrupt_2;
 }

 type2list1_2_top: {
  q x0, x1, x2, x3, x4, x5;
  a1 = qp->args[1];
  qp = qp->next;
 type2list1_2_clear_reason:
  reasonp = reasons;
 type2list1_2_0:
 type2list1_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 type2list1_2_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__3F)) goto type2list1_2_7;
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = makesym(atom__3F);
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x1);
  a0 = cdr_of(a0);
  a1 = x2;
  execute(type2list1_2_0);
  goto type2list1_2_ext_interrupt;
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_4)) goto type2list1_2_7;
  x1 = arg(x0, 0);
 type2list1_2_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_s_3)) goto type2list1_2_7;
  x2 = arg(x1, 0);
 type2list1_2_4:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != PERIODATOM) goto type2list1_2_7;
  x3 = arg(x1, 1);
 type2list1_2_5:
  switch (ptagof(x3)) {
 case ATOMIC:
 type2list1_2_6:
  if (x3 != makeint(2L)) goto type2list1_2_7;
  allocp[0] = x5 = makeref(&allocp[0]);
  allocp[1] = x0;
  x4 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x4);
  a0 = cdr_of(a0);
  a1 = x5;
  execute(type2list1_2_0);
  goto type2list1_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x3,type2list1_2_5);
  *reasonp++ =  x3;
  goto type2list1_2_7;
  };
  goto type2list1_2_7;
 case VARREF:
  deref_and_jump(x2,type2list1_2_4);
  *reasonp++ =  x2;
  goto type2list1_2_7;
  };
  goto type2list1_2_7;
 case VARREF:
  deref_and_jump(x1,type2list1_2_3);
  *reasonp++ =  x1;
  goto type2list1_2_7;
  };
  goto type2list1_2_7;
 case VARREF:
  deref_and_jump(x0,type2list1_2_2);
  *reasonp++ =  x0;
  goto type2list1_2_7;
  };
  goto type2list1_2_7;
 case VARREF:
  deref_and_jump(a0,type2list1_2_1);
  *reasonp++ =  a0;
  goto type2list1_2_7;
  };
  goto type2list1_2_7;
 type2list1_2_7:
  otherwise(type2list1_2_interrupt);
 type2list1_2_8:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(type2list1_2_0);
  goto type2list1_2_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto type2list1_2_interrupt;
  unify_value(a1, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a0,type2list1_2_8);
  *reasonp++ =  a0;
  goto type2list1_2_interrupt;
  };
  goto type2list1_2_interrupt;
 type2list1_2_ext_interrupt:
  reasonp = 0l;
 type2list1_2_interrupt:
  goto interrupt_2;
 }

 type2structtype_2_top: {
  a1 = qp->args[1];
  qp = qp->next;
 type2structtype_2_clear_reason:
  reasonp = reasons;
 type2structtype_2_0:
  a2 = a1;
  a1 = NILATOM;
  execute(type2structtype1_3_0);
  goto type2structtype1_3_ext_interrupt;
 type2structtype_2_ext_interrupt:
  reasonp = 0l;
 type2structtype_2_interrupt:
  toppred = &predicate_type_xtype2structtype_2;
  goto interrupt_2;
 }

 type2structtype1_3_top: {
  q x0, x1, x2, x3, x4;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 type2structtype1_3_clear_reason:
  reasonp = reasons;
 type2structtype1_3_0:
 type2structtype1_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 type2structtype1_3_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__3F)) goto type2structtype1_3_4;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xtype2structtype1_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  a0 = a1;
  a1 = makecons(cons_const_0);
  a2 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(or__types_3_0);
  goto or__types_3_ext_interrupt;
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_4)) goto type2structtype1_3_4;
  x1 = arg(x0, 0);
 type2structtype1_3_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_s_3)) goto type2structtype1_3_4;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xtype2structtype1_3);
  x2 = cdr_of(a0);
  allocp[2] = x2;
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x4 = makecons(&allocp[5]);
  a0 = a1;
  a1 = x4;
  a2 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(or__types_3_0);
  goto or__types_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,type2structtype1_3_3);
  *reasonp++ =  x1;
  goto type2structtype1_3_4;
  };
  goto type2structtype1_3_4;
 case VARREF:
  deref_and_jump(x0,type2structtype1_3_2);
  *reasonp++ =  x0;
  goto type2structtype1_3_4;
  };
  goto type2structtype1_3_4;
 case VARREF:
  deref_and_jump(a0,type2structtype1_3_1);
  *reasonp++ =  a0;
  goto type2structtype1_3_4;
  };
  goto type2structtype1_3_4;
 type2structtype1_3_4:
  otherwise(type2structtype1_3_interrupt);
 type2structtype1_3_5:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(type2structtype1_3_0);
  goto type2structtype1_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto type2structtype1_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,type2structtype1_3_5);
  *reasonp++ =  a0;
  goto type2structtype1_3_interrupt;
  };
  goto type2structtype1_3_interrupt;
 type2structtype1_3_ext_interrupt:
  reasonp = 0l;
 type2structtype1_3_interrupt:
  toppred = &predicate_type_xtype2structtype1_3;
  goto interrupt_3;
 }

 get__struct__arg__types_3_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 get__struct__arg__types_3_clear_reason:
  reasonp = reasons;
 get__struct__arg__types_3_0:
 get__struct__arg__types_3_1:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_t_4)) goto get__struct__arg__types_3_4;
  x0 = arg(a1, 0);
 get__struct__arg__types_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_s_3)) goto get__struct__arg__types_3_4;
  x1 = arg(x0, 1);
 get__struct__arg__types_3_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_n)) goto get__struct__arg__types_3_4;
  x2 = arg(x0, 2);
  unify(a2, x2);
  proceed();
 case VARREF:
  deref_and_jump(x1,get__struct__arg__types_3_3);
  *reasonp++ =  x1;
  goto get__struct__arg__types_3_4;
  };
  goto get__struct__arg__types_3_4;
 case VARREF:
  deref_and_jump(x0,get__struct__arg__types_3_2);
  *reasonp++ =  x0;
  goto get__struct__arg__types_3_4;
  };
  goto get__struct__arg__types_3_4;
 case VARREF:
  deref_and_jump(a1,get__struct__arg__types_3_1);
  *reasonp++ =  a1;
  goto get__struct__arg__types_3_4;
  };
  goto get__struct__arg__types_3_4;
 get__struct__arg__types_3_4:
  otherwise(get__struct__arg__types_3_interrupt);
 get__struct__arg__types_3_5:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_t_4)) goto get__struct__arg__types_3_interrupt;
  x0 = arg(a1, 0);
 get__struct__arg__types_3_6:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_s_3)) goto get__struct__arg__types_3_interrupt;
  x1 = arg(x0, 1);
 get__struct__arg__types_3_7:
  if (!isint(x1)) goto get__struct__arg__types_3_11;
 get__struct__arg__types_3_8:
  if (!isint(a0)) goto get__struct__arg__types_3_10;
  gblt_less(x1,a0,get__struct__arg__types_3_9);
  unify_value(a2, makecons(cons_const_0));
  proceed();
 get__struct__arg__types_3_9:
  gblt_greater_or_eq(x1,a0,get__struct__arg__types_3_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = a0;
  x2 = arg(x0, 2);
  allocp[3] = x2;
  allocp[4] = a2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 get__struct__arg__types_3_10:
  if (!isref(a0)) goto get__struct__arg__types_3_interrupt;
  deref_and_jump(a0,get__struct__arg__types_3_8);
  *reasonp++ =  a0;
  goto get__struct__arg__types_3_interrupt;
 get__struct__arg__types_3_11:
  if (!isref(x1)) goto get__struct__arg__types_3_interrupt;
  deref_and_jump(x1,get__struct__arg__types_3_7);
  *reasonp++ =  x1;
  goto get__struct__arg__types_3_interrupt;
 case VARREF:
  deref_and_jump(x0,get__struct__arg__types_3_6);
  *reasonp++ =  x0;
  goto get__struct__arg__types_3_interrupt;
  };
  goto get__struct__arg__types_3_interrupt;
 case VARREF:
  deref_and_jump(a1,get__struct__arg__types_3_5);
  *reasonp++ =  a1;
  goto get__struct__arg__types_3_interrupt;
  };
  goto get__struct__arg__types_3_interrupt;
 get__struct__arg__types_3_ext_interrupt:
  reasonp = 0l;
 get__struct__arg__types_3_interrupt:
  goto interrupt_3;
 }

 set__struct__arg__types_4_top: {
  q x0, x1, x2, x3, x4, x5;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 set__struct__arg__types_4_clear_reason:
  reasonp = reasons;
 set__struct__arg__types_4_0:
 set__struct__arg__types_4_1:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_t_4)) goto set__struct__arg__types_4_4;
  x0 = arg(a1, 0);
 set__struct__arg__types_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_s_3)) goto set__struct__arg__types_4_4;
  x1 = arg(x0, 1);
 set__struct__arg__types_4_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_n)) goto set__struct__arg__types_4_4;
  allocp[0] = makesym(functor_s_3);
  allocp[1] = arg(x0, 0);
  allocp[2] = makesym(atom_n);
  allocp[3] = x3 = makeref(&allocp[3]);
  x2 = makefunctor(&allocp[0]);
  allocp[4] = makesym(functor_t_4);
  allocp[5] = x2;
  allocp[6] = arg(a1, 1);
  allocp[7] = arg(a1, 2);
  allocp[8] = arg(a1, 3);
  x4 = makefunctor(&allocp[4]);
  a0 = arg(x0, 2);
  a1 = a2;
  a2 = x3;
  allocp += 9;
  execute(or__types_3_0);
  goto or__types_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,set__struct__arg__types_4_3);
  *reasonp++ =  x1;
  goto set__struct__arg__types_4_4;
  };
  goto set__struct__arg__types_4_4;
 case VARREF:
  deref_and_jump(x0,set__struct__arg__types_4_2);
  *reasonp++ =  x0;
  goto set__struct__arg__types_4_4;
  };
  goto set__struct__arg__types_4_4;
 case VARREF:
  deref_and_jump(a1,set__struct__arg__types_4_1);
  *reasonp++ =  a1;
  goto set__struct__arg__types_4_4;
  };
  goto set__struct__arg__types_4_4;
 set__struct__arg__types_4_4:
  otherwise(set__struct__arg__types_4_interrupt);
 set__struct__arg__types_4_5:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_t_4)) goto set__struct__arg__types_4_interrupt;
  x0 = arg(a1, 0);
 set__struct__arg__types_4_6:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_s_3)) goto set__struct__arg__types_4_interrupt;
  x1 = arg(x0, 1);
 set__struct__arg__types_4_7:
  if (!isint(x1)) goto set__struct__arg__types_4_11;
 set__struct__arg__types_4_8:
  if (!isint(a0)) goto set__struct__arg__types_4_10;
  gblt_less(x1,a0,set__struct__arg__types_4_9);
  unify_value(a3, a1);
  proceed();
 set__struct__arg__types_4_9:
  gblt_greater_or_eq(x1,a0,set__struct__arg__types_4_interrupt);
  allocp[0] = makesym(functor_s_3);
  allocp[1] = arg(x0, 0);
  allocp[2] = x1;
  allocp[3] = x3 = makeref(&allocp[3]);
  x2 = makefunctor(&allocp[0]);
  allocp[4] = makesym(functor_t_4);
  allocp[5] = x2;
  allocp[6] = arg(a1, 1);
  allocp[7] = arg(a1, 2);
  allocp[8] = arg(a1, 3);
  x4 = makefunctor(&allocp[4]);
  allocp += 9;
  unify_value(a3, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = a0;
  x5 = arg(x0, 2);
  allocp[3] = x5;
  allocp[4] = a2;
  allocp[5] = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  proceed();
 set__struct__arg__types_4_10:
  if (!isref(a0)) goto set__struct__arg__types_4_interrupt;
  deref_and_jump(a0,set__struct__arg__types_4_8);
  *reasonp++ =  a0;
  goto set__struct__arg__types_4_interrupt;
 set__struct__arg__types_4_11:
  if (!isref(x1)) goto set__struct__arg__types_4_interrupt;
  deref_and_jump(x1,set__struct__arg__types_4_7);
  *reasonp++ =  x1;
  goto set__struct__arg__types_4_interrupt;
 case VARREF:
  deref_and_jump(x0,set__struct__arg__types_4_6);
  *reasonp++ =  x0;
  goto set__struct__arg__types_4_interrupt;
  };
  goto set__struct__arg__types_4_interrupt;
 case VARREF:
  deref_and_jump(a1,set__struct__arg__types_4_5);
  *reasonp++ =  a1;
  goto set__struct__arg__types_4_interrupt;
  };
  goto set__struct__arg__types_4_interrupt;
 set__struct__arg__types_4_ext_interrupt:
  reasonp = 0l;
 set__struct__arg__types_4_interrupt:
  goto interrupt_4;
 }

 listtype__val_3_top: {
  q x0;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 listtype__val_3_clear_reason:
  reasonp = reasons;
 listtype__val_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xlisttype__val__merge_3);
  allocp[2] = a1;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a2;
  a2 = a1;
  a3 = x0;
  a1 = makeint(0L);
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(listtype__val1_4_0);
  goto listtype__val1_4_ext_interrupt;
 listtype__val_3_ext_interrupt:
  reasonp = 0l;
 listtype__val_3_interrupt:
  goto interrupt_3;
 }

 listtype__val1_4_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 listtype__val1_4_clear_reason:
  reasonp = reasons;
 listtype__val1_4_0:
 listtype__val1_4_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_t_4)) goto listtype__val1_4_7;
  x0 = arg(a0, 0);
 listtype__val1_4_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_a)) goto listtype__val1_4_7;
  unify_value(a3, NILATOM);
  unify(a2, a1);
  proceed();
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_s_3:
  x1 = arg(x0, 0);
 listtype__val1_4_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != PERIODATOM) goto listtype__val1_4_7;
  x2 = arg(x0, 1);
 listtype__val1_4_4:
  switch (ptagof(x2)) {
 case ATOMIC:
 listtype__val1_4_5:
  if (x2 != makeint(2L)) goto listtype__val1_4_7;
  x3 = arg(x0, 2);
 listtype__val1_4_6:
  switch (ptagof(x3)) {
 case FUNCTOR:
  if (functor_of(x3) != makesym(functor_arg_2)) goto listtype__val1_4_7;
  allocp[0] = x5 = makeref(&allocp[0]);
  allocp[1] = arg(x3, 0);
  x4 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a3, x4);
  bblt_add_no_check_y(a1,makeint(1L),x6);
  a0 = arg(x3, 1);
  a1 = x6;
  a3 = x5;
  execute(listtype__val2_4_0);
  goto listtype__val2_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x3,listtype__val1_4_6);
  *reasonp++ =  x3;
  goto listtype__val1_4_7;
  };
  goto listtype__val1_4_7;
 case VARREF:
  deref_and_jump(x2,listtype__val1_4_4);
  *reasonp++ =  x2;
  goto listtype__val1_4_7;
  };
  goto listtype__val1_4_7;
 case VARREF:
  deref_and_jump(x1,listtype__val1_4_3);
  *reasonp++ =  x1;
  goto listtype__val1_4_7;
  };
  goto listtype__val1_4_7;
 case functor_a_1:
  unify_value(a3, NILATOM);
  unify(a2, a1);
  proceed();
  };
  goto listtype__val1_4_7;
 case VARREF:
  deref_and_jump(x0,listtype__val1_4_2);
  *reasonp++ =  x0;
  goto listtype__val1_4_7;
  };
  goto listtype__val1_4_7;
 case VARREF:
  deref_and_jump(a0,listtype__val1_4_1);
  *reasonp++ =  a0;
  goto listtype__val1_4_7;
  };
  goto listtype__val1_4_7;
 listtype__val1_4_7:
  otherwise(listtype__val1_4_interrupt);
  unify_value(a3, NILATOM);
  unify_value(a2, makesym(atom_n));
  proceed();
 listtype__val1_4_ext_interrupt:
  reasonp = 0l;
 listtype__val1_4_interrupt:
  toppred = &predicate_type_xlisttype__val1_4;
  goto interrupt_4;
 }

 listtype__val2_4_top: {
  q x0;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 listtype__val2_4_clear_reason:
  reasonp = reasons;
 listtype__val2_4_0:
 listtype__val2_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = cdr_of(a0);
 listtype__val2_4_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != NILATOM) goto listtype__val2_4_interrupt;
  a0 = car_of(a0);
  execute(listtype__val1_4_0);
  goto listtype__val1_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,listtype__val2_4_2);
  *reasonp++ =  x0;
  goto listtype__val2_4_interrupt;
  };
  goto listtype__val2_4_interrupt;
 case VARREF:
  deref_and_jump(a0,listtype__val2_4_1);
  *reasonp++ =  a0;
  goto listtype__val2_4_interrupt;
  };
  goto listtype__val2_4_interrupt;
 listtype__val2_4_ext_interrupt:
  reasonp = 0l;
 listtype__val2_4_interrupt:
  toppred = &predicate_type_xlisttype__val2_4;
  goto interrupt_4;
 }

 listtype__val__merge_3_top: {
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 listtype__val__merge_3_clear_reason:
  reasonp = reasons;
 listtype__val__merge_3_0:
 listtype__val__merge_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto listtype__val__merge_3_2;
  if (a0 != makesym(atom_n)) goto listtype__val__merge_3_interrupt;
  a0 = NILATOM;
  execute(listtype__val__merge1_3_0);
  goto listtype__val__merge1_3_ext_interrupt;
 listtype__val__merge_3_2:
  gblt_integer(a0,listtype__val__merge_3_interrupt);
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,listtype__val__merge_3_1);
  *reasonp++ =  a0;
  goto listtype__val__merge_3_interrupt;
  };
  goto listtype__val__merge_3_interrupt;
 listtype__val__merge_3_ext_interrupt:
  reasonp = 0l;
 listtype__val__merge_3_interrupt:
  goto interrupt_3;
 }

 listtype__val__merge1_3_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 listtype__val__merge1_3_clear_reason:
  reasonp = reasons;
 listtype__val__merge1_3_0:
 listtype__val__merge1_3_1:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xlisttype__val__merge1_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  x1 = cdr_of(a1);
  allocp[3] = x1;
  allocp[4] = a2;
  a1 = car_of(a1);
  a2 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(or__types_3_0);
  goto or__types_3_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto listtype__val__merge1_3_interrupt;
  unify(a2, a0);
  proceed();
 case VARREF:
  deref_and_jump(a1,listtype__val__merge1_3_1);
  *reasonp++ =  a1;
  goto listtype__val__merge1_3_interrupt;
  };
  goto listtype__val__merge1_3_interrupt;
 listtype__val__merge1_3_ext_interrupt:
  reasonp = 0l;
 listtype__val__merge1_3_interrupt:
  toppred = &predicate_type_xlisttype__val__merge1_3;
  goto interrupt_3;
 }

 check__type__table_1_top: {
  q x0, x1;
  qp = qp->next;
 check__type__table_1_clear_reason:
  reasonp = reasons;
 check__type__table_1_0:
 check__type__table_1_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 check__type__table_1_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto check__type__table_1_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xcheck__type__table_1);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  a0 = arg(x0, 0);
  a1 = arg(x0, 1);
  qp = (struct goalrec*)&allocp[0];
  allocp += 3;
  execute(check__type__table__clauses_2_0);
  goto check__type__table__clauses_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,check__type__table_1_2);
  *reasonp++ =  x0;
  goto check__type__table_1_interrupt;
  };
  goto check__type__table_1_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto check__type__table_1_interrupt;
  proceed();
 case VARREF:
  deref_and_jump(a0,check__type__table_1_1);
  *reasonp++ =  a0;
  goto check__type__table_1_interrupt;
  };
  goto check__type__table_1_interrupt;
 check__type__table_1_ext_interrupt:
  reasonp = 0l;
 check__type__table_1_interrupt:
  goto interrupt_1;
 }

 check__type__table__clauses_2_top: {
  q x0, x1;
  a1 = qp->args[1];
  qp = qp->next;
 check__type__table__clauses_2_clear_reason:
  reasonp = reasons;
 check__type__table__clauses_2_0:
 check__type__table__clauses_2_1:
  if (isref(a1)) goto check__type__table__clauses_2_2;
  gblt_pfunctor(a1,x0,check__type__table__clauses_2_interrupt);
  if (x0 != makesym(atom_clauses)) goto check__type__table__clauses_2_interrupt;
  gblt_arity(a1,x1,check__type__table__clauses_2_interrupt);
  a2 = makeint(1L);
  a3 = x1;
  execute(check__type__table__clauses1_4_0);
  goto check__type__table__clauses1_4_ext_interrupt;
 check__type__table__clauses_2_2:
  deref_and_jump(a1,check__type__table__clauses_2_1);
  *reasonp++ =  a1;
  goto check__type__table__clauses_2_interrupt;
 check__type__table__clauses_2_ext_interrupt:
  reasonp = 0l;
 check__type__table__clauses_2_interrupt:
  toppred = &predicate_type_xcheck__type__table__clauses_2;
  goto interrupt_2;
 }

 check__type__table__clauses1_4_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 check__type__table__clauses1_4_clear_reason:
  reasonp = reasons;
 check__type__table__clauses1_4_0:
 check__type__table__clauses1_4_1:
  if (!isint(a2)) goto check__type__table__clauses1_4_5;
 check__type__table__clauses1_4_2:
  if (!isint(a3)) goto check__type__table__clauses1_4_4;
  gblt_less_or_eq(a2,a3,check__type__table__clauses1_4_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xcheck__type__table__clauses1_4);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[8] = a2;
  allocp[9] = makeint(1L);
  allocp[10] = x0;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_type_xcheck__type__table__clause_3);
  allocp[13] = a0;
  allocp[14] = x1 = makeref(&allocp[14]);
  allocp[15] = a2;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_functor__table_xarg_3);
  allocp[18] = a2;
  allocp[19] = a1;
  allocp[20] = x1;
  qp = (struct goalrec*)&allocp[16];
  allocp += 21;
  proceed();
 check__type__table__clauses1_4_3:
  gblt_greater(a2,a3,check__type__table__clauses1_4_interrupt);
  proceed();
 check__type__table__clauses1_4_4:
  if (!isref(a3)) goto check__type__table__clauses1_4_interrupt;
  deref_and_jump(a3,check__type__table__clauses1_4_2);
  *reasonp++ =  a3;
  goto check__type__table__clauses1_4_interrupt;
 check__type__table__clauses1_4_5:
  if (!isref(a2)) goto check__type__table__clauses1_4_interrupt;
  deref_and_jump(a2,check__type__table__clauses1_4_1);
  *reasonp++ =  a2;
  goto check__type__table__clauses1_4_interrupt;
 check__type__table__clauses1_4_ext_interrupt:
  reasonp = 0l;
 check__type__table__clauses1_4_interrupt:
  toppred = &predicate_type_xcheck__type__table__clauses1_4;
  goto interrupt_4;
 }

 check__type__table__clause_3_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 check__type__table__clause_3_clear_reason:
  reasonp = reasons;
 check__type__table__clause_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xcheck__type__table__clause1_5);
  allocp[2] = a0;
  allocp[3] = a2;
  allocp[4] = a1;
  allocp[5] = makeint(1L);
  allocp[6] = x0 = makeref(&allocp[6]);
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[9] = a1;
  allocp[10] = x1 = makeref(&allocp[10]);
  allocp[11] = x0;
  qp = (struct goalrec*)&allocp[7];
  allocp += 12;
  proceed();
 check__type__table__clause_3_ext_interrupt:
  reasonp = 0l;
 check__type__table__clause_3_interrupt:
  goto interrupt_3;
 }

 check__type__table__clause1_5_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 check__type__table__clause1_5_clear_reason:
  reasonp = reasons;
 check__type__table__clause1_5_0:
 check__type__table__clause1_5_1:
  if (!isint(a3)) goto check__type__table__clause1_5_5;
 check__type__table__clause1_5_2:
  if (!isint(a4)) goto check__type__table__clause1_5_4;
  gblt_less_or_eq(a3,a4,check__type__table__clause1_5_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xcheck__type__table__clause1_5);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x0 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[9] = a3;
  allocp[10] = makeint(1L);
  allocp[11] = x0;
  allocp[12] = x1 = makeref(&allocp[12]);
  allocp[13] = (q)(struct goalrec*)&allocp[7];
  allocp[14] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[15] = a3;
  allocp[16] = makeint(1L);
  allocp[17] = x1;
  allocp[18] = (q)(struct goalrec*)&allocp[13];
  allocp[19] = (q)(&predicate_type_xcheck__type__table__type_4);
  allocp[20] = a0;
  allocp[21] = a1;
  allocp[22] = x2 = makeref(&allocp[22]);
  allocp[23] = x3 = makeref(&allocp[23]);
  allocp[24] = (q)(struct goalrec*)&allocp[18];
  allocp[25] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[26] = a3;
  allocp[27] = makeint(1L);
  allocp[28] = x2;
  allocp[29] = (q)(struct goalrec*)&allocp[24];
  allocp[30] = (q)(&predicate_functor__table_xarg_3);
  allocp[31] = a3;
  allocp[32] = a2;
  allocp[33] = x3;
  qp = (struct goalrec*)&allocp[29];
  allocp += 34;
  proceed();
 check__type__table__clause1_5_3:
  gblt_greater(a3,a4,check__type__table__clause1_5_interrupt);
  proceed();
 check__type__table__clause1_5_4:
  if (!isref(a4)) goto check__type__table__clause1_5_interrupt;
  deref_and_jump(a4,check__type__table__clause1_5_2);
  *reasonp++ =  a4;
  goto check__type__table__clause1_5_interrupt;
 check__type__table__clause1_5_5:
  if (!isref(a3)) goto check__type__table__clause1_5_interrupt;
  deref_and_jump(a3,check__type__table__clause1_5_1);
  *reasonp++ =  a3;
  goto check__type__table__clause1_5_interrupt;
 check__type__table__clause1_5_ext_interrupt:
  reasonp = 0l;
 check__type__table__clause1_5_interrupt:
  goto interrupt_5;
 }

 check__type__table__type_4_top: {
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 check__type__table__type_4_clear_reason:
  reasonp = reasons;
 check__type__table__type_4_0:
 check__type__table__type_4_1:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != NILATOM) goto check__type__table__type_4_2;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdatan_1);
  allocp[2] = makesym(atom__20_20Perhaps_20the_20target_20program_20cannot_20be_20analyzed_20in_20this_20compiler_2E);
  allocp[3] = (q)(struct goalrec*)&allocp[0];
  allocp[4] = (q)(&predicate_print_xdatan_1);
  allocp[5] = makesym(atom__29_2E);
  allocp[6] = (q)(struct goalrec*)&allocp[3];
  allocp[7] = (q)(&predicate_print_xdata_1);
  allocp[8] = a2;
  allocp[9] = (q)(struct goalrec*)&allocp[6];
  allocp[10] = (q)(&predicate_print_xdata_1);
  allocp[11] = makesym(atom__20variable_28);
  allocp[12] = (q)(struct goalrec*)&allocp[9];
  allocp[13] = (q)(&predicate_print_xdata_1);
  allocp[14] = a1;
  allocp[15] = (q)(struct goalrec*)&allocp[12];
  allocp[16] = (q)(&predicate_print_xdata_1);
  allocp[17] = makesym(atom__20clause_20);
  allocp[18] = (q)(struct goalrec*)&allocp[15];
  allocp[19] = (q)(&predicate_print_xdata_1);
  allocp[20] = a0;
  allocp[21] = (q)(struct goalrec*)&allocp[18];
  allocp[22] = (q)(&predicate_print_xdata_1);
  allocp[23] = makesym(atom_Warning_20_3A_20NULL_20type_20in_20module_20);
  qp = (struct goalrec*)&allocp[21];
  allocp += 24;
  proceed();
 case VARREF:
  deref_and_jump(a3,check__type__table__type_4_1);
  *reasonp++ =  a3;
  goto check__type__table__type_4_2;
  };
  goto check__type__table__type_4_2;
 check__type__table__type_4_2:
  otherwise(check__type__table__type_4_interrupt);
  proceed();
 check__type__table__type_4_ext_interrupt:
  reasonp = 0l;
 check__type__table__type_4_interrupt:
  goto interrupt_4;
 }

 remove__types__deps_3_top: {
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 remove__types__deps_3_clear_reason:
  reasonp = reasons;
 remove__types__deps_3_0:
  a3 = a2;
  a2 = NILATOM;
  execute(remove__types__deps_4_0);
  goto remove__types__deps_4_ext_interrupt;
 remove__types__deps_3_ext_interrupt:
  reasonp = 0l;
 remove__types__deps_3_interrupt:
  toppred = &predicate_type_xremove__types__deps_3;
  goto interrupt_3;
 }

 remove__types__deps_4_top: {
  q x0, x1, x2, x3, x4;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 remove__types__deps_4_clear_reason:
  reasonp = reasons;
 remove__types__deps_4_0:
 remove__types__deps_4_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xremove__types__deps_4);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x1;
  allocp[7] = x4 = makeref(&allocp[7]);
  x3 = makecons(&allocp[6]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  unify_value(a1, x3);
  a0 = car_of(a0);
  a1 = x4;
  a3 = x2;
  execute(remove__type__deps_4_0);
  goto remove__type__deps_4_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto remove__types__deps_4_interrupt;
  unify_value(a1, NILATOM);
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,remove__types__deps_4_1);
  *reasonp++ =  a0;
  goto remove__types__deps_4_interrupt;
  };
  goto remove__types__deps_4_interrupt;
 remove__types__deps_4_ext_interrupt:
  reasonp = 0l;
 remove__types__deps_4_interrupt:
  toppred = &predicate_type_xremove__types__deps_4;
  goto interrupt_4;
 }

 remove__type__deps_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 remove__type__deps_4_clear_reason:
  reasonp = reasons;
 remove__type__deps_4_0:
 remove__type__deps_4_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_t_4)) goto remove__type__deps_4_5;
  x0 = arg(a0, 0);
 remove__type__deps_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_s_3)) goto remove__type__deps_4_5;
  x1 = arg(x0, 1);
 remove__type__deps_4_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (isint(x1)) goto remove__type__deps_4_4;
  if (x1 != makesym(atom_n)) goto remove__type__deps_4_5;
  allocp[0] = makesym(functor_t_4);
  allocp[1] = x3 = makeref(&allocp[1]);
  allocp[2] = arg(a0, 1);
  allocp[3] = NILATOM;
  allocp[4] = arg(a0, 3);
  x2 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a1, x2);
  allocp[0] = makesym(functor_s_3);
  allocp[1] = arg(x0, 0);
  allocp[2] = makesym(atom_n);
  allocp[3] = x5 = makeref(&allocp[3]);
  x4 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(x3, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xremove__types__deps_4);
  x6 = arg(x0, 2);
  allocp[2] = x6;
  allocp[3] = x5;
  allocp[4] = x7 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_type_xmerge__goals_3);
  allocp[8] = x8 = makeref(&allocp[8]);
  allocp[9] = a2;
  allocp[10] = x7;
  a0 = arg(a0, 2);
  a1 = x8;
  qp = (struct goalrec*)&allocp[6];
  allocp += 11;
  execute(get__loopdeps_2_0);
  goto get__loopdeps_2_ext_interrupt;
 remove__type__deps_4_4:
  gblt_integer(x1,remove__type__deps_4_5);
  allocp[0] = makesym(functor_t_4);
  allocp[1] = x3 = makeref(&allocp[1]);
  allocp[2] = arg(a0, 1);
  allocp[3] = NILATOM;
  allocp[4] = arg(a0, 3);
  x2 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a1, x2);
  allocp[0] = makesym(functor_s_3);
  allocp[1] = arg(x0, 0);
  allocp[2] = x1;
  allocp[3] = x5 = makeref(&allocp[3]);
  x4 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(x3, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xremove__type__args_5);
  allocp[2] = x1;
  x6 = arg(x0, 2);
  allocp[3] = x6;
  allocp[4] = x5;
  allocp[5] = x7 = makeref(&allocp[5]);
  allocp[6] = a3;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_type_xmerge__goals_3);
  allocp[9] = x8 = makeref(&allocp[9]);
  allocp[10] = a2;
  allocp[11] = x7;
  a0 = arg(a0, 2);
  a1 = x8;
  qp = (struct goalrec*)&allocp[7];
  allocp += 12;
  execute(get__loopdeps_2_0);
  goto get__loopdeps_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,remove__type__deps_4_3);
  *reasonp++ =  x1;
  goto remove__type__deps_4_5;
  };
  goto remove__type__deps_4_5;
 case VARREF:
  deref_and_jump(x0,remove__type__deps_4_2);
  *reasonp++ =  x0;
  goto remove__type__deps_4_5;
  };
  goto remove__type__deps_4_5;
 case VARREF:
  deref_and_jump(a0,remove__type__deps_4_1);
  *reasonp++ =  a0;
  goto remove__type__deps_4_5;
  };
  goto remove__type__deps_4_5;
 remove__type__deps_4_5:
  otherwise(remove__type__deps_4_interrupt);
 remove__type__deps_4_6:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom__3F)) goto remove__type__deps_4_interrupt;
  unify_value(a1, makesym(atom__3F));
  unify(a3, a2);
  proceed();
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_t_4)) goto remove__type__deps_4_interrupt;
  allocp[0] = makesym(functor_t_4);
  allocp[1] = arg(a0, 0);
  allocp[2] = arg(a0, 1);
  allocp[3] = NILATOM;
  allocp[4] = arg(a0, 3);
  x0 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xmerge__goals_3);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a2;
  allocp[4] = a3;
  a0 = arg(a0, 2);
  a1 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(get__loopdeps_2_0);
  goto get__loopdeps_2_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,remove__type__deps_4_6);
  *reasonp++ =  a0;
  goto remove__type__deps_4_interrupt;
  };
  goto remove__type__deps_4_interrupt;
 remove__type__deps_4_ext_interrupt:
  reasonp = 0l;
 remove__type__deps_4_interrupt:
  toppred = &predicate_type_xremove__type__deps_4;
  goto interrupt_4;
 }

 remove__type__args_5_top: {
  q x0, x1, x2, x3, x4;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 remove__type__args_5_clear_reason:
  reasonp = reasons;
 remove__type__args_5_0:
 remove__type__args_5_1:
  if (!isint(a0)) goto remove__type__args_5_3;
  gblt_greater(a0,makeint(0L),remove__type__args_5_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xremove__type__args_5);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[9] = a0;
  allocp[10] = makeint(1L);
  allocp[11] = x0;
  allocp[12] = (q)(struct goalrec*)&allocp[7];
  allocp[13] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = x3 = makeref(&allocp[16]);
  allocp[17] = x1;
  allocp[18] = (q)(struct goalrec*)&allocp[12];
  allocp[19] = (q)(&predicate_type_xremove__types__deps_4);
  allocp[20] = x4 = makeref(&allocp[20]);
  allocp[21] = x3;
  allocp[22] = a3;
  allocp[23] = x2;
  allocp[24] = (q)(struct goalrec*)&allocp[18];
  allocp[25] = (q)(&predicate_functor__table_xarg_3);
  allocp[26] = a0;
  allocp[27] = a1;
  allocp[28] = x4;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 remove__type__args_5_2:
  if (a0 != makeint(0L)) goto remove__type__args_5_interrupt;
  unify2(a2, a1, a4, a3);
  proceed();
 remove__type__args_5_3:
  if (!isref(a0)) goto remove__type__args_5_interrupt;
  deref_and_jump(a0,remove__type__args_5_1);
  *reasonp++ =  a0;
  goto remove__type__args_5_interrupt;
 remove__type__args_5_ext_interrupt:
  reasonp = 0l;
 remove__type__args_5_interrupt:
  goto interrupt_5;
 }

 get__loopdeps_2_top: {
  a1 = qp->args[1];
  qp = qp->next;
 get__loopdeps_2_clear_reason:
  reasonp = reasons;
 get__loopdeps_2_0:
  a2 = a1;
  a1 = NILATOM;
  execute(get__loopdeps1_3_0);
  goto get__loopdeps1_3_ext_interrupt;
 get__loopdeps_2_ext_interrupt:
  reasonp = 0l;
 get__loopdeps_2_interrupt:
  toppred = &predicate_type_xget__loopdeps_2;
  goto interrupt_2;
 }

 get__loopdeps1_3_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 get__loopdeps1_3_clear_reason:
  reasonp = reasons;
 get__loopdeps1_3_0:
 get__loopdeps1_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 get__loopdeps1_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_goal_4:
  a0 = cdr_of(a0);
  execute(get__loopdeps1_3_0);
  goto get__loopdeps1_3_ext_interrupt;
 case functor_loopgoal_2:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xget__loopdeps1_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  a0 = arg(x0, 1);
  a2 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(merge__goals_3_0);
  goto merge__goals_3_ext_interrupt;
  };
  goto get__loopdeps1_3_interrupt;
 case VARREF:
  deref_and_jump(x0,get__loopdeps1_3_2);
  *reasonp++ =  x0;
  goto get__loopdeps1_3_interrupt;
  };
  goto get__loopdeps1_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto get__loopdeps1_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,get__loopdeps1_3_1);
  *reasonp++ =  a0;
  goto get__loopdeps1_3_interrupt;
  };
  goto get__loopdeps1_3_interrupt;
 get__loopdeps1_3_ext_interrupt:
  reasonp = 0l;
 get__loopdeps1_3_interrupt:
  toppred = &predicate_type_xget__loopdeps1_3;
  goto interrupt_3;
 }

 make__types__loopdown_16_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  qp = qp->next;
 make__types__loopdown_16_clear_reason:
  reasonp = reasons;
 make__types__loopdown_16_0:
 make__types__loopdown_16_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xmake__types__loopdown_16);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = x3 = makeref(&allocp[11]);
  allocp[12] = a10;
  allocp[13] = a11;
  allocp[14] = x4 = makeref(&allocp[14]);
  allocp[15] = a13;
  allocp[16] = x5 = makeref(&allocp[16]);
  allocp[17] = a15;
  allocp[18] = x1;
  allocp[19] = x7 = makeref(&allocp[19]);
  x6 = makecons(&allocp[18]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 20;
  unify_value(a1, x6);
  a0 = car_of(a0);
  a1 = x7;
  a8 = x2;
  a10 = x3;
  a13 = x4;
  a15 = x5;
  execute(make__type__loopdown_16_0);
  goto make__type__loopdown_16_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto make__types__loopdown_16_interrupt;
  unify_value(a1, NILATOM);
  unify4(a8, a7, a10, a9, a13, a12, a15, a14);
  proceed();
 case VARREF:
  deref_and_jump(a0,make__types__loopdown_16_1);
  *reasonp++ =  a0;
  goto make__types__loopdown_16_interrupt;
  };
  goto make__types__loopdown_16_interrupt;
 make__types__loopdown_16_ext_interrupt:
  reasonp = 0l;
 make__types__loopdown_16_interrupt:
  toppred = &predicate_type_xmake__types__loopdown_16;
  goto interrupt_16;
 }

 make__type__loopdown_16_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  qp = qp->next;
 make__type__loopdown_16_clear_reason:
  reasonp = reasons;
 make__type__loopdown_16_0:
 make__type__loopdown_16_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_t_4)) goto make__type__loopdown_16_5;
  x0 = arg(a0, 0);
 make__type__loopdown_16_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_s_3:
  x1 = arg(x0, 1);
 make__type__loopdown_16_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (isint(x1)) goto make__type__loopdown_16_4;
  if (x1 != makesym(atom_n)) goto make__type__loopdown_16_5;
  allocp[0] = makesym(functor_s_3);
  allocp[1] = arg(x0, 0);
  allocp[2] = makesym(atom_n);
  allocp[3] = x3 = makeref(&allocp[3]);
  x2 = makefunctor(&allocp[0]);
  allocp[4] = NILATOM;
  allocp[5] = x5 = makeref(&allocp[5]);
  x4 = makecons(&allocp[4]);
  allocp[6] = makesym(functor_t_4);
  allocp[7] = x2;
  allocp[8] = arg(a0, 1);
  allocp[9] = x4;
  allocp[10] = arg(a0, 3);
  x6 = makefunctor(&allocp[6]);
  allocp += 11;
  unify_value(a1, x6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_loop_xmake__loopdep_3);
  allocp[2] = a5;
  x7 = arg(a0, 2);
  allocp[3] = x7;
  allocp[4] = x5;
  a0 = arg(x0, 2);
  a1 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(make__types__loopdown_16_0);
  goto make__types__loopdown_16_ext_interrupt;
 make__type__loopdown_16_4:
  gblt_integer(x1,make__type__loopdown_16_5);
  allocp[0] = makesym(functor_s_3);
  allocp[1] = arg(x0, 0);
  allocp[2] = x1;
  allocp[3] = x3 = makeref(&allocp[3]);
  x2 = makefunctor(&allocp[0]);
  allocp[4] = NILATOM;
  allocp[5] = x5 = makeref(&allocp[5]);
  x4 = makecons(&allocp[4]);
  allocp[6] = makesym(functor_t_4);
  allocp[7] = x2;
  allocp[8] = arg(a0, 1);
  allocp[9] = x4;
  allocp[10] = arg(a0, 3);
  x6 = makefunctor(&allocp[6]);
  allocp += 11;
  unify_value(a1, x6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_loop_xmake__loopdep_3);
  allocp[2] = a5;
  x7 = arg(a0, 2);
  allocp[3] = x7;
  allocp[4] = x5;
  a0 = x1;
  a1 = arg(x0, 2);
  x8 = a2;
  x9 = a3;
  x10 = a4;
  x11 = a5;
  x12 = a6;
  x13 = a7;
  x14 = a8;
  x15 = a9;
  x16 = a10;
  x17 = a11;
  x18 = a12;
  x19 = a13;
  x20 = a14;
  a16 = a15;
  a15 = x20;
  a14 = x19;
  a13 = x18;
  a12 = x17;
  a11 = x16;
  a10 = x15;
  a9 = x14;
  a8 = x13;
  a7 = x12;
  a6 = x11;
  a5 = x10;
  a4 = x9;
  a3 = x8;
  a2 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(make__type__loopdown__args_17_0);
  goto make__type__loopdown__args_17_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,make__type__loopdown_16_3);
  *reasonp++ =  x1;
  goto make__type__loopdown_16_5;
  };
  goto make__type__loopdown_16_5;
 case functor_v_4:
  unify(a13, a12);
  allocp[0] = NILATOM;
  allocp[1] = x2 = makeref(&allocp[1]);
  x1 = makecons(&allocp[0]);
  allocp[2] = makesym(functor_t_4);
  allocp[3] = x4 = makeref(&allocp[3]);
  allocp[4] = arg(a0, 1);
  allocp[5] = x1;
  allocp[6] = arg(a0, 3);
  x3 = makefunctor(&allocp[2]);
  allocp += 7;
  unify_value(a1, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xentry__new__aliasvar_14);
  allocp[2] = makesym(atom_down);
  x5 = arg(x0, 0);
  allocp[3] = x5;
  x6 = arg(x0, 1);
  allocp[4] = x6;
  x7 = arg(x0, 2);
  allocp[5] = x7;
  x8 = arg(x0, 3);
  allocp[6] = x8;
  allocp[7] = a5;
  allocp[8] = x2;
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = a8;
  allocp[12] = a9;
  allocp[13] = a10;
  allocp[14] = a11;
  allocp[15] = x4;
  allocp[16] = (q)(struct goalrec*)&allocp[0];
  allocp[17] = (q)(&predicate_loop_xmake__loopdep_3);
  allocp[18] = a5;
  x9 = arg(a0, 2);
  allocp[19] = x9;
  allocp[20] = x2;
  qp = (struct goalrec*)&allocp[16];
  allocp += 21;
  proceed();
  };
  goto make__type__loopdown_16_5;
 case VARREF:
  deref_and_jump(x0,make__type__loopdown_16_2);
  *reasonp++ =  x0;
  goto make__type__loopdown_16_5;
  };
  goto make__type__loopdown_16_5;
 case VARREF:
  deref_and_jump(a0,make__type__loopdown_16_1);
  *reasonp++ =  a0;
  goto make__type__loopdown_16_5;
  };
  goto make__type__loopdown_16_5;
 make__type__loopdown_16_5:
  otherwise(make__type__loopdown_16_interrupt);
 make__type__loopdown_16_6:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom__3F)) goto make__type__loopdown_16_interrupt;
  unify_value(a1, makesym(atom__3F));
  unify4(a8, a7, a10, a9, a13, a12, a15, a14);
  proceed();
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_t_4)) goto make__type__loopdown_16_interrupt;
  unify4(a15, a14, a13, a12, a10, a9, a8, a7);
  allocp[0] = NILATOM;
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makecons(&allocp[0]);
  allocp[2] = makesym(functor_t_4);
  allocp[3] = arg(a0, 0);
  allocp[4] = arg(a0, 1);
  allocp[5] = x0;
  allocp[6] = arg(a0, 3);
  x2 = makefunctor(&allocp[2]);
  allocp += 7;
  unify_value(a1, x2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_loop_xmake__loopdep_3);
  allocp[2] = a5;
  x3 = arg(a0, 2);
  allocp[3] = x3;
  allocp[4] = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case VARREF:
  deref_and_jump(a0,make__type__loopdown_16_6);
  *reasonp++ =  a0;
  goto make__type__loopdown_16_interrupt;
  };
  goto make__type__loopdown_16_interrupt;
 make__type__loopdown_16_ext_interrupt:
  reasonp = 0l;
 make__type__loopdown_16_interrupt:
  toppred = &predicate_type_xmake__type__loopdown_16;
  goto interrupt_16;
 }

 make__type__loopdown__args_17_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  qp = qp->next;
 make__type__loopdown__args_17_clear_reason:
  reasonp = reasons;
 make__type__loopdown__args_17_0:
 make__type__loopdown__args_17_1:
  if (!isint(a0)) goto make__type__loopdown__args_17_3;
  gblt_greater(a0,makeint(0L),make__type__loopdown__args_17_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xmake__type__loopdown__args_17);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = x2 = makeref(&allocp[10]);
  allocp[11] = a9;
  allocp[12] = x3 = makeref(&allocp[12]);
  allocp[13] = a11;
  allocp[14] = a12;
  allocp[15] = x4 = makeref(&allocp[15]);
  allocp[16] = a14;
  allocp[17] = x5 = makeref(&allocp[17]);
  allocp[18] = a16;
  allocp[19] = (q)(struct goalrec*)&allocp[0];
  allocp[20] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[21] = a0;
  allocp[22] = makeint(1L);
  allocp[23] = x0;
  allocp[24] = (q)(struct goalrec*)&allocp[19];
  allocp[25] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[26] = a0;
  allocp[27] = a1;
  allocp[28] = x6 = makeref(&allocp[28]);
  allocp[29] = x1;
  allocp[30] = (q)(struct goalrec*)&allocp[24];
  allocp[31] = (q)(&predicate_type_xmake__types__loopdown_16);
  allocp[32] = x7 = makeref(&allocp[32]);
  allocp[33] = x6;
  allocp[34] = a3;
  allocp[35] = a4;
  allocp[36] = a5;
  allocp[37] = a6;
  allocp[38] = a7;
  allocp[39] = a8;
  allocp[40] = x2;
  allocp[41] = a10;
  allocp[42] = x3;
  allocp[43] = a12;
  allocp[44] = a13;
  allocp[45] = x4;
  allocp[46] = a15;
  allocp[47] = x5;
  allocp[48] = (q)(struct goalrec*)&allocp[30];
  allocp[49] = (q)(&predicate_functor__table_xarg_3);
  allocp[50] = a0;
  allocp[51] = a1;
  allocp[52] = x7;
  qp = (struct goalrec*)&allocp[48];
  allocp += 53;
  proceed();
 make__type__loopdown__args_17_2:
  if (a0 != makeint(0L)) goto make__type__loopdown__args_17_interrupt;
  unify4(a2, a1, a9, a8, a11, a10, a14, a13);
  unify(a16, a15);
  proceed();
 make__type__loopdown__args_17_3:
  if (!isref(a0)) goto make__type__loopdown__args_17_interrupt;
  deref_and_jump(a0,make__type__loopdown__args_17_1);
  *reasonp++ =  a0;
  goto make__type__loopdown__args_17_interrupt;
 make__type__loopdown__args_17_ext_interrupt:
  reasonp = 0l;
 make__type__loopdown__args_17_interrupt:
  toppred = &predicate_type_xmake__type__loopdown__args_17;
  goto interrupt_17;
 }

 make__types__loopup_9_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 make__types__loopup_9_clear_reason:
  reasonp = reasons;
 make__types__loopup_9_0:
  allocp[0] = NILATOM;
  allocp[1] = a2;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_type_xadd__dep__goals_3);
  allocp[4] = x0;
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = a1;
  allocp[7] = (q)(struct goalrec*)&allocp[2];
  allocp[8] = (q)(&predicate_type_xmake__types__loopup1_9);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = x1;
  allocp[11] = a2;
  allocp[12] = a3;
  allocp[13] = a4;
  allocp[14] = a5;
  allocp[15] = a6;
  allocp[16] = a7;
  allocp[17] = a8;
  a1 = x2;
  allocp[18] = x3 = makeref(&allocp[18]);
  a2 = x3;
  qp = (struct goalrec*)&allocp[7];
  allocp += 19;
  execute(remove__types__deps_3_0);
  goto remove__types__deps_3_ext_interrupt;
 make__types__loopup_9_ext_interrupt:
  reasonp = 0l;
 make__types__loopup_9_interrupt:
  goto interrupt_9;
 }

 make__types__loopup1_9_top: {
  q x0, x1, x2, x3, x4, x5;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 make__types__loopup1_9_clear_reason:
  reasonp = reasons;
 make__types__loopup1_9_0:
 make__types__loopup1_9_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xmake__types__loopup1_9);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = x1;
  allocp[12] = x5 = makeref(&allocp[12]);
  x4 = makecons(&allocp[11]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 13;
  unify_value(a1, x4);
  a0 = car_of(a0);
  a1 = x5;
  a5 = x2;
  a7 = x3;
  execute(make__type__loopup_9_0);
  goto make__type__loopup_9_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto make__types__loopup1_9_interrupt;
  unify_value(a1, NILATOM);
  unify2(a5, a4, a7, a6);
  proceed();
 case VARREF:
  deref_and_jump(a0,make__types__loopup1_9_1);
  *reasonp++ =  a0;
  goto make__types__loopup1_9_interrupt;
  };
  goto make__types__loopup1_9_interrupt;
 make__types__loopup1_9_ext_interrupt:
  reasonp = 0l;
 make__types__loopup1_9_interrupt:
  goto interrupt_9;
 }

 make__type__loopup_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 make__type__loopup_9_clear_reason:
  reasonp = reasons;
 make__type__loopup_9_0:
 make__type__loopup_9_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_t_4)) goto make__type__loopup_9_5;
  x0 = arg(a0, 0);
 make__type__loopup_9_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_s_3:
  x1 = arg(x0, 1);
 make__type__loopup_9_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (isint(x1)) goto make__type__loopup_9_4;
  if (x1 != makesym(atom_n)) goto make__type__loopup_9_5;
  allocp[0] = makesym(functor_s_3);
  allocp[1] = arg(x0, 0);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = x4 = makeref(&allocp[3]);
  x2 = makefunctor(&allocp[0]);
  allocp[4] = makesym(functor_t_4);
  allocp[5] = x2;
  allocp[6] = arg(a0, 1);
  allocp[7] = arg(a0, 2);
  allocp[8] = arg(a0, 3);
  x5 = makefunctor(&allocp[4]);
  allocp += 9;
  unify_value(a1, x5);
  a0 = arg(x0, 2);
  a1 = x4;
  execute(make__type__loopup_9_0);
  goto make__type__loopup_9_ext_interrupt;
 make__type__loopup_9_4:
  gblt_integer(x1,make__type__loopup_9_5);
  allocp[0] = makesym(functor_s_3);
  allocp[1] = arg(x0, 0);
  allocp[2] = x1;
  allocp[3] = x3 = makeref(&allocp[3]);
  x2 = makefunctor(&allocp[0]);
  allocp[4] = makesym(functor_t_4);
  allocp[5] = x2;
  allocp[6] = arg(a0, 1);
  allocp[7] = arg(a0, 2);
  allocp[8] = arg(a0, 3);
  x4 = makefunctor(&allocp[4]);
  allocp += 9;
  unify_value(a1, x4);
  a0 = x1;
  a1 = arg(x0, 2);
  x5 = a2;
  x6 = a3;
  x7 = a4;
  x8 = a5;
  x9 = a6;
  x10 = a7;
  a9 = a8;
  a8 = x10;
  a7 = x9;
  a6 = x8;
  a5 = x7;
  a4 = x6;
  a3 = x5;
  a2 = x3;
  execute(make__type__loopup__struct_10_0);
  goto make__type__loopup__struct_10_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,make__type__loopup_9_3);
  *reasonp++ =  x1;
  goto make__type__loopup_9_5;
  };
  goto make__type__loopup_9_5;
 case functor_v_4:
  allocp[0] = NILATOM;
  allocp[1] = a2;
  x1 = makecons(&allocp[0]);
  allocp[2] = makesym(functor_t_4);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = arg(a0, 1);
  allocp[5] = x1;
  allocp[6] = arg(a0, 3);
  x2 = makefunctor(&allocp[2]);
  allocp += 7;
  unify_value(a1, x2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xentry__new__aliasvar_14);
  allocp[2] = makesym(atom_up);
  x4 = arg(x0, 0);
  allocp[3] = x4;
  x5 = arg(x0, 1);
  allocp[4] = x5;
  x6 = arg(x0, 2);
  allocp[5] = x6;
  x7 = arg(x0, 3);
  allocp[6] = x7;
  allocp[7] = a2;
  allocp[8] = x8 = makeref(&allocp[8]);
  allocp[9] = a3;
  allocp[10] = a4;
  allocp[11] = a5;
  allocp[12] = a6;
  allocp[13] = a7;
  allocp[14] = a8;
  allocp[15] = x3;
  allocp[16] = (q)(struct goalrec*)&allocp[0];
  allocp[17] = (q)(&predicate_loop_xmake__loopdep_3);
  allocp[18] = a2;
  x9 = arg(a0, 2);
  allocp[19] = x9;
  allocp[20] = x8;
  qp = (struct goalrec*)&allocp[16];
  allocp += 21;
  proceed();
  };
  goto make__type__loopup_9_5;
 case VARREF:
  deref_and_jump(x0,make__type__loopup_9_2);
  *reasonp++ =  x0;
  goto make__type__loopup_9_5;
  };
  goto make__type__loopup_9_5;
 case VARREF:
  deref_and_jump(a0,make__type__loopup_9_1);
  *reasonp++ =  a0;
  goto make__type__loopup_9_5;
  };
  goto make__type__loopup_9_5;
 make__type__loopup_9_5:
  otherwise(make__type__loopup_9_interrupt);
  unify3(a1, a0, a5, a4, a7, a6);
  proceed();
 make__type__loopup_9_ext_interrupt:
  reasonp = 0l;
 make__type__loopup_9_interrupt:
  toppred = &predicate_type_xmake__type__loopup_9;
  goto interrupt_9;
 }

 make__type__loopup__struct_10_top: {
  q x0, x1, x2, x3, x4, x5;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 make__type__loopup__struct_10_clear_reason:
  reasonp = reasons;
 make__type__loopup__struct_10_0:
 make__type__loopup__struct_10_1:
  if (!isint(a0)) goto make__type__loopup__struct_10_3;
  gblt_greater(a0,makeint(0L),make__type__loopup__struct_10_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xmake__type__loopup__struct_10);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = x3 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = a9;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[14] = a0;
  allocp[15] = makeint(1L);
  allocp[16] = x0;
  allocp[17] = (q)(struct goalrec*)&allocp[12];
  allocp[18] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[19] = a0;
  allocp[20] = a1;
  allocp[21] = x4 = makeref(&allocp[21]);
  allocp[22] = x1;
  allocp[23] = (q)(struct goalrec*)&allocp[17];
  allocp[24] = (q)(&predicate_type_xmake__types__loopup_9);
  allocp[25] = x5 = makeref(&allocp[25]);
  allocp[26] = x4;
  allocp[27] = a3;
  allocp[28] = a4;
  allocp[29] = a5;
  allocp[30] = x2;
  allocp[31] = a7;
  allocp[32] = x3;
  allocp[33] = a9;
  allocp[34] = (q)(struct goalrec*)&allocp[23];
  allocp[35] = (q)(&predicate_functor__table_xarg_3);
  allocp[36] = a0;
  allocp[37] = a1;
  allocp[38] = x5;
  qp = (struct goalrec*)&allocp[34];
  allocp += 39;
  proceed();
 make__type__loopup__struct_10_2:
  if (a0 != makeint(0L)) goto make__type__loopup__struct_10_interrupt;
  unify3(a2, a1, a6, a5, a8, a7);
  proceed();
 make__type__loopup__struct_10_3:
  if (!isref(a0)) goto make__type__loopup__struct_10_interrupt;
  deref_and_jump(a0,make__type__loopup__struct_10_1);
  *reasonp++ =  a0;
  goto make__type__loopup__struct_10_interrupt;
 make__type__loopup__struct_10_ext_interrupt:
  reasonp = 0l;
 make__type__loopup__struct_10_interrupt:
  toppred = &predicate_type_xmake__type__loopup__struct_10;
  goto interrupt_10;
 }

 merge__goals_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 merge__goals_3_clear_reason:
  reasonp = reasons;
 merge__goals_3_0:
 merge__goals_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 merge__goals_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_goal_4:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xmerge__goals_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = x3;
  allocp[6] = x0;
  x4 = makecons(&allocp[5]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  unify_value(a2, x4);
  a0 = x0;
  a2 = x2;
  execute(merge__goals__filter_3_0);
  goto merge__goals__filter_3_ext_interrupt;
 case functor_loopgoal_2:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xmerge__goals_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = makesym(functor_loopgoal_2);
  allocp[6] = arg(x0, 0);
  allocp[7] = x5 = makeref(&allocp[7]);
  x4 = makefunctor(&allocp[5]);
  allocp[8] = x3;
  allocp[9] = x4;
  x6 = makecons(&allocp[8]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  unify_value(a2, x6);
  a0 = arg(x0, 0);
  x7 = arg(x0, 1);
  a2 = x5;
  a3 = a1;
  a4 = x2;
  a1 = x7;
  execute(merge__loopgoals__filter_5_0);
  goto merge__loopgoals__filter_5_ext_interrupt;
  };
  goto merge__goals_3_interrupt;
 case VARREF:
  deref_and_jump(x0,merge__goals_3_2);
  *reasonp++ =  x0;
  goto merge__goals_3_interrupt;
  };
  goto merge__goals_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto merge__goals_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,merge__goals_3_1);
  *reasonp++ =  a0;
  goto merge__goals_3_interrupt;
  };
  goto merge__goals_3_interrupt;
 merge__goals_3_ext_interrupt:
  reasonp = 0l;
 merge__goals_3_interrupt:
  toppred = &predicate_type_xmerge__goals_3;
  goto interrupt_3;
 }

 merge__goals__filter_3_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 merge__goals__filter_3_clear_reason:
  reasonp = reasons;
 merge__goals__filter_3_0:
 merge__goals__filter_3_1:
  switch (ptagof(a1)) {
 case CONS:
 merge__goals__filter_3_2:
  if (isref(a0)) goto merge__goals__filter_3_5;
 merge__goals__filter_3_3:
  if (isref(a0)) goto merge__goals__filter_3_4;
  x0 = car_of(a1);
  if_not_equal(a0, x0, merge__goals__filter_3_6);
  a1 = cdr_of(a1);
  execute(merge__goals__filter_3_clear_reason);
  goto merge__goals__filter_3_ext_interrupt;
 merge__goals__filter_3_4:
  deref_and_jump(a0,merge__goals__filter_3_3);
  *reasonp++ =  a0;
  goto merge__goals__filter_3_6;
 merge__goals__filter_3_5:
  deref_and_jump(a0,merge__goals__filter_3_2);
  *reasonp++ =  a0;
  goto merge__goals__filter_3_6;
 case VARREF:
  deref_and_jump(a1,merge__goals__filter_3_1);
  *reasonp++ =  a1;
  goto merge__goals__filter_3_6;
  };
  goto merge__goals__filter_3_6;
 merge__goals__filter_3_6:
  otherwise(merge__goals__filter_3_interrupt);
 merge__goals__filter_3_7:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = car_of(a1);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  a1 = cdr_of(a1);
  a2 = x1;
  execute(merge__goals__filter_3_0);
  goto merge__goals__filter_3_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto merge__goals__filter_3_interrupt;
  unify_value(a2, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a1,merge__goals__filter_3_7);
  *reasonp++ =  a1;
  goto merge__goals__filter_3_interrupt;
  };
  goto merge__goals__filter_3_interrupt;
 merge__goals__filter_3_ext_interrupt:
  reasonp = 0l;
 merge__goals__filter_3_interrupt:
  toppred = &predicate_type_xmerge__goals__filter_3;
  goto interrupt_3;
 }

 merge__loopgoals__filter_5_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 merge__loopgoals__filter_5_clear_reason:
  reasonp = reasons;
 merge__loopgoals__filter_5_0:
 merge__loopgoals__filter_5_1:
  switch (ptagof(a3)) {
 case CONS:
  x0 = car_of(a3);
 merge__loopgoals__filter_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_loopgoal_2)) goto merge__loopgoals__filter_5_7;
  x1 = arg(x0, 0);
 merge__loopgoals__filter_5_3:
  if (isref(x1)) goto merge__loopgoals__filter_5_6;
 merge__loopgoals__filter_5_4:
  if (isref(x1)) goto merge__loopgoals__filter_5_5;
  if_not_equal(x1, a0, merge__loopgoals__filter_5_7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xmerge__loopgoals__filter_5);
  allocp[2] = a0;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  x3 = cdr_of(a3);
  allocp[5] = x3;
  allocp[6] = a4;
  a0 = a1;
  a1 = arg(x0, 1);
  a2 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(merge__goals_3_clear_reason);
  goto merge__goals_3_ext_interrupt;
 merge__loopgoals__filter_5_5:
  deref_and_jump(x1,merge__loopgoals__filter_5_4);
  *reasonp++ =  x1;
  goto merge__loopgoals__filter_5_7;
 merge__loopgoals__filter_5_6:
  deref_and_jump(x1,merge__loopgoals__filter_5_3);
  *reasonp++ =  x1;
  goto merge__loopgoals__filter_5_7;
 case VARREF:
  deref_and_jump(x0,merge__loopgoals__filter_5_2);
  *reasonp++ =  x0;
  goto merge__loopgoals__filter_5_7;
  };
  goto merge__loopgoals__filter_5_7;
 case VARREF:
  deref_and_jump(a3,merge__loopgoals__filter_5_1);
  *reasonp++ =  a3;
  goto merge__loopgoals__filter_5_7;
  };
  goto merge__loopgoals__filter_5_7;
 merge__loopgoals__filter_5_7:
  otherwise(merge__loopgoals__filter_5_interrupt);
 merge__loopgoals__filter_5_8:
  switch (ptagof(a3)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = car_of(a3);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a4, x0);
  a3 = cdr_of(a3);
  a4 = x1;
  execute(merge__loopgoals__filter_5_0);
  goto merge__loopgoals__filter_5_ext_interrupt;
 case ATOMIC:
  if (a3 != NILATOM) goto merge__loopgoals__filter_5_interrupt;
  unify(a2, a1);
  unify_value(a4, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a3,merge__loopgoals__filter_5_8);
  *reasonp++ =  a3;
  goto merge__loopgoals__filter_5_interrupt;
  };
  goto merge__loopgoals__filter_5_interrupt;
 merge__loopgoals__filter_5_ext_interrupt:
  reasonp = 0l;
 merge__loopgoals__filter_5_interrupt:
  toppred = &predicate_type_xmerge__loopgoals__filter_5;
  goto interrupt_5;
 }
 interrupt_17:
  allocp[18] = a16;
 interrupt_16:
  allocp[17] = a15;
 interrupt_15:
  allocp[16] = a14;
 interrupt_14:
  allocp[15] = a13;
 interrupt_13:
  allocp[14] = a12;
 interrupt_12:
  allocp[13] = a11;
 interrupt_11:
  allocp[12] = a10;
 interrupt_10:
  allocp[11] = a9;
 interrupt_9:
  allocp[10] = a8;
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_type);
}
