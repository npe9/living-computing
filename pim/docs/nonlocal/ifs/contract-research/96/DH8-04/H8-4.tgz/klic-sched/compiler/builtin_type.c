/* Compiled by KLIC compiler version 2.002 (Tue May 23 13:27:38 JST 1995) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_builtin__type();
Const struct predicate predicate_builtin__type_xupdate__type__new__functor_4 =
   { module_builtin__type, 0, 4 };
Const struct predicate predicate_builtin__type_xupdate__type__new__functor1_4 =
   { module_builtin__type, 1, 4 };
Const struct predicate predicate_builtin__type_xstructname_2 =
   { module_builtin__type, 2, 2 };
Const struct predicate predicate_builtin__type_xstructarity_2 =
   { module_builtin__type, 3, 2 };
Const struct predicate predicate_builtin__type_xupdate__type__functor_4 =
   { module_builtin__type, 4, 4 };
Const struct predicate predicate_builtin__type_xupdate__type__functor1_5 =
   { module_builtin__type, 5, 5 };
Const struct predicate predicate_builtin__type_xupdate__type__functor2_6 =
   { module_builtin__type, 6, 6 };
Const struct predicate predicate_builtin__type_xupdate__type__arg_4 =
   { module_builtin__type, 7, 4 };
Const struct predicate predicate_builtin__type_xupdate__type__arg1_4 =
   { module_builtin__type, 8, 4 };
Const struct predicate predicate_builtin__type_xupdate__type__arg__merge_4 =
   { module_builtin__type, 9, 4 };
Const struct predicate predicate_builtin__type_xupdate__type__setarg_6 =
   { module_builtin__type, 10, 6 };
Const struct predicate predicate_builtin__type_xupdate__type__setarg1_8 =
   { module_builtin__type, 11, 8 };
Const struct predicate predicate_builtin__type_xupdate__type__setarg2_6 =
   { module_builtin__type, 12, 6 };
Const struct predicate predicate_builtin__type_xupdate__type__new__vector_4 =
   { module_builtin__type, 13, 4 };
Const struct predicate predicate_builtin__type_xupdate__type__new__vector1_5 =
   { module_builtin__type, 14, 5 };
Const struct predicate predicate_builtin__type_xupdate__type__new__vector2_4 =
   { module_builtin__type, 15, 4 };
Const struct predicate predicate_builtin__type_xupdate__type__new__vector2_5 =
   { module_builtin__type, 16, 5 };
Const struct predicate predicate_builtin__type_xupdate__type__new__vector3_3 =
   { module_builtin__type, 17, 3 };
Const struct predicate predicate_builtin__type_xupdate__type__element_4 =
   { module_builtin__type, 18, 4 };
Const struct predicate predicate_builtin__type_xupdate__type__element1_4 =
   { module_builtin__type, 19, 4 };
Const struct predicate predicate_builtin__type_xupdate__type__element__merge_4 =
   { module_builtin__type, 20, 4 };
extern Const struct predicate predicate_print_xdatan_1;
extern Const struct predicate predicate_print_xdata_1;
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_xsetarg_4;
extern Const struct predicate predicate_uty_xnew__functor__init_4;
extern Const struct predicate predicate_uty_xcreate__functor_3;
extern Const struct predicate predicate_type_xadd__i__goal_3;
extern Const struct predicate predicate_type_xadd__dep__goal_3;
extern Const struct predicate predicate_type_xor__types_3;
extern Const struct predicate predicate_type_xget__struct__arg__types_3;
extern Const struct predicate predicate_type_xset__struct__arg__types_4;
extern Const struct predicate predicate_type_xlisttype__val_3;

module module_builtin__type(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  static Const q cons_const_0[] = {
    NILATOM,
    makesym(atom__3F),
  };
  static Const q funct_const_1[] = {
    makesym(functor_t_4),
    makesym(atom_i),
    NILATOM,
    NILATOM,
    makesym(atom_u),
  };
  static Const q cons_const_2[] = {
    NILATOM,
    makefunctor(funct_const_1),
  };
  static Const q funct_const_3[] = {
    makesym(functor_i_1),
    makeint(0),
  };
  static Const q funct_const_4[] = {
    makesym(functor_t_4),
    makefunctor(funct_const_3),
    NILATOM,
    NILATOM,
    makesym(atom_u),
  };
  static Const q cons_const_5[] = {
    NILATOM,
    makefunctor(funct_const_4),
  };
  static Const q funct_const_6[] = {
    makesym(functor_i_1),
    makeint(0),
  };
  static Const q funct_const_7[] = {
    makesym(functor_t_4),
    makefunctor(funct_const_6),
    NILATOM,
    NILATOM,
    makesym(atom_u),
  };
  static Const q cons_const_8[] = {
    NILATOM,
    makefunctor(funct_const_7),
  };
  static Const q funct_const_9[] = {
    makesym(functor_s_3),
    makesym(atom___v),
    makesym(atom_n),
    makecons(cons_const_8),
  };
  static Const q funct_const_10[] = {
    makesym(functor_t_4),
    makefunctor(funct_const_9),
    NILATOM,
    NILATOM,
    makesym(atom_u),
  };
  static Const q cons_const_11[] = {
    NILATOM,
    makefunctor(funct_const_10),
  };
  static Const q funct_const_12[] = {
    makesym(functor_i_1),
    makeint(0),
  };
  q a0, a1, a2, a3, a4, a5, a6, a7;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, update__type__new__functor_4_top);
    case_pred(1, update__type__new__functor1_4_top);
    case_pred(2, structname_2_top);
    case_pred(3, structarity_2_top);
    case_pred(4, update__type__functor_4_top);
    case_pred(5, update__type__functor1_5_top);
    case_pred(6, update__type__functor2_6_top);
    case_pred(7, update__type__arg_4_top);
    case_pred(8, update__type__arg1_4_top);
    case_pred(9, update__type__arg__merge_4_top);
    case_pred(10, update__type__setarg_6_top);
    case_pred(11, update__type__setarg1_8_top);
    case_pred(12, update__type__setarg2_6_top);
    case_pred(13, update__type__new__vector_4_top);
    case_pred(14, update__type__new__vector1_5_top);
    case_pred(15, update__type__new__vector2_4_top);
    case_pred(16, update__type__new__vector2_5_top);
    case_pred(17, update__type__new__vector3_3_top);
    case_pred(18, update__type__element_4_top);
    case_pred(19, update__type__element1_4_top);
    last_case_pred(20, update__type__element__merge_4_top);
  }

 update__type__new__functor_4_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 update__type__new__functor_4_clear_reason:
  reasonp = reasons;
 update__type__new__functor_4_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin__type_xupdate__type__new__functor1_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_builtin__type_xstructarity_2);
  allocp[8] = a1;
  allocp[9] = x1;
  a1 = x0;
  qp = (struct goalrec*)&allocp[6];
  allocp += 10;
  execute(structname_2_0);
  goto structname_2_ext_interrupt;
 update__type__new__functor_4_ext_interrupt:
  reasonp = 0l;
 update__type__new__functor_4_interrupt:
  goto interrupt_4;
 }

 update__type__new__functor1_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 update__type__new__functor1_4_clear_reason:
  reasonp = reasons;
 update__type__new__functor1_4_0:
 update__type__new__functor1_4_1:
  if (!isint(a1)) goto update__type__new__functor1_4_2;
  gblt_integer(a1,update__type__new__functor1_4_3);
  gblt_less(a1,makeint(5L),update__type__new__functor1_4_3);
  allocp[0] = makesym(functor_s_3);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = x1 = makeref(&allocp[3]);
  x0 = makefunctor(&allocp[0]);
  allocp[4] = NILATOM;
  allocp[5] = a3;
  x2 = makecons(&allocp[4]);
  allocp[6] = NILATOM;
  allocp[7] = a3;
  x3 = makecons(&allocp[6]);
  allocp[8] = makesym(functor_t_4);
  allocp[9] = x0;
  allocp[10] = x2;
  allocp[11] = x3;
  allocp[12] = makesym(atom_u);
  x4 = makefunctor(&allocp[8]);
  allocp[13] = NILATOM;
  allocp[14] = x4;
  x5 = makecons(&allocp[13]);
  allocp += 15;
  unify_value(a2, x5);
  allocp[0] = NILATOM;
  allocp[1] = a3;
  x6 = makecons(&allocp[0]);
  allocp[2] = NILATOM;
  allocp[3] = a3;
  x7 = makecons(&allocp[2]);
  allocp[4] = makesym(functor_t_4);
  allocp[5] = makefunctor(funct_const_12);
  allocp[6] = x6;
  allocp[7] = x7;
  allocp[8] = makesym(atom_u);
  x8 = makefunctor(&allocp[4]);
  allocp[9] = NILATOM;
  allocp[10] = x8;
  x9 = makecons(&allocp[9]);
  allocp[11] = (q)qp;
  allocp[12] = (q)(&predicate_uty_xnew__functor__init_4);
  allocp[13] = makesym(atom_arg);
  allocp[14] = a1;
  allocp[15] = x9;
  allocp[16] = x1;
  qp = (struct goalrec*)&allocp[11];
  allocp += 17;
  proceed();
 update__type__new__functor1_4_2:
  if (!isref(a1)) goto update__type__new__functor1_4_3;
  deref_and_jump(a1,update__type__new__functor1_4_1);
  *reasonp++ =  a1;
  goto update__type__new__functor1_4_3;
 update__type__new__functor1_4_3:
  otherwise(update__type__new__functor1_4_interrupt);
 update__type__new__functor1_4_4:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (isint(a1)) goto update__type__new__functor1_4_5;
  if (a1 != makesym(atom_n)) goto update__type__new__functor1_4_interrupt;
  allocp[0] = NILATOM;
  allocp[1] = a3;
  x0 = makecons(&allocp[0]);
  allocp[2] = NILATOM;
  allocp[3] = a3;
  x1 = makecons(&allocp[2]);
  allocp[4] = makesym(functor_t_4);
  allocp[5] = makefunctor(funct_const_12);
  allocp[6] = x0;
  allocp[7] = x1;
  allocp[8] = makesym(atom_u);
  x2 = makefunctor(&allocp[4]);
  allocp[9] = NILATOM;
  allocp[10] = x2;
  x3 = makecons(&allocp[9]);
  allocp[11] = makesym(functor_s_3);
  allocp[12] = a0;
  allocp[13] = makesym(atom_n);
  allocp[14] = x3;
  x4 = makefunctor(&allocp[11]);
  allocp[15] = NILATOM;
  allocp[16] = a3;
  x5 = makecons(&allocp[15]);
  allocp[17] = NILATOM;
  allocp[18] = a3;
  x6 = makecons(&allocp[17]);
  allocp[19] = makesym(functor_t_4);
  allocp[20] = x4;
  allocp[21] = x5;
  allocp[22] = x6;
  allocp[23] = makesym(atom_u);
  x7 = makefunctor(&allocp[19]);
  allocp[24] = NILATOM;
  allocp[25] = x7;
  x8 = makecons(&allocp[24]);
  allocp += 26;
  unify_value(a2, x8);
  proceed();
 update__type__new__functor1_4_5:
  gblt_integer(a1,update__type__new__functor1_4_interrupt);
  allocp[0] = NILATOM;
  allocp[1] = a3;
  x0 = makecons(&allocp[0]);
  allocp[2] = NILATOM;
  allocp[3] = a3;
  x1 = makecons(&allocp[2]);
  allocp[4] = makesym(functor_t_4);
  allocp[5] = makefunctor(funct_const_12);
  allocp[6] = x0;
  allocp[7] = x1;
  allocp[8] = makesym(atom_u);
  x2 = makefunctor(&allocp[4]);
  allocp[9] = NILATOM;
  allocp[10] = x2;
  x3 = makecons(&allocp[9]);
  allocp[11] = makesym(functor_s_3);
  allocp[12] = a0;
  allocp[13] = makesym(atom_n);
  allocp[14] = x3;
  x4 = makefunctor(&allocp[11]);
  allocp[15] = NILATOM;
  allocp[16] = a3;
  x5 = makecons(&allocp[15]);
  allocp[17] = NILATOM;
  allocp[18] = a3;
  x6 = makecons(&allocp[17]);
  allocp[19] = makesym(functor_t_4);
  allocp[20] = x4;
  allocp[21] = x5;
  allocp[22] = x6;
  allocp[23] = makesym(atom_u);
  x7 = makefunctor(&allocp[19]);
  allocp[24] = NILATOM;
  allocp[25] = x7;
  x8 = makecons(&allocp[24]);
  allocp += 26;
  unify_value(a2, x8);
  proceed();
 case VARREF:
  deref_and_jump(a1,update__type__new__functor1_4_4);
  *reasonp++ =  a1;
  goto update__type__new__functor1_4_interrupt;
  };
  goto update__type__new__functor1_4_interrupt;
 update__type__new__functor1_4_ext_interrupt:
  reasonp = 0l;
 update__type__new__functor1_4_interrupt:
  goto interrupt_4;
 }

 structname_2_top: {
  q x0;
  qp = qp->next;
 structname_2_clear_reason:
  reasonp = reasons;
 structname_2_0:
 structname_2_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto structname_2_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom__3F)):
  unify_value(a1, makesym(atom__3F));
  proceed();
 case symval(makesym(atom_a)):
  unify_value(a1, makesym(atom__3F));
  proceed();
  };
  goto structname_2_interrupt;
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_a_1)) goto structname_2_interrupt;
  x0 = arg(a0, 0);
  unify(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,structname_2_1);
  *reasonp++ =  a0;
  goto structname_2_interrupt;
  };
  goto structname_2_interrupt;
 structname_2_ext_interrupt:
  reasonp = 0l;
 structname_2_interrupt:
  toppred = &predicate_builtin__type_xstructname_2;
  goto interrupt_2;
 }

 structarity_2_top: {
  q x0;
  qp = qp->next;
 structarity_2_clear_reason:
  reasonp = reasons;
 structarity_2_0:
 structarity_2_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto structarity_2_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom__3F)):
  unify_value(a1, makesym(atom_n));
  proceed();
 case symval(makesym(atom_i)):
  unify_value(a1, makesym(atom_n));
  proceed();
  };
  goto structarity_2_interrupt;
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_i_1)) goto structarity_2_interrupt;
  x0 = arg(a0, 0);
  unify(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,structarity_2_1);
  *reasonp++ =  a0;
  goto structarity_2_interrupt;
  };
  goto structarity_2_interrupt;
 structarity_2_ext_interrupt:
  reasonp = 0l;
 structarity_2_interrupt:
  goto interrupt_2;
 }

 update__type__functor_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 update__type__functor_4_clear_reason:
  reasonp = reasons;
 update__type__functor_4_0:
 update__type__functor_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 update__type__functor_4_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__3F)) goto update__type__functor_4_4;
  x1 = cdr_of(a0);
 update__type__functor_4_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto update__type__functor_4_4;
  unify_value(a1, makecons(cons_const_0));
  unify_value(a2, makecons(cons_const_0));
  proceed();
 case VARREF:
  deref_and_jump(x1,update__type__functor_4_3);
  *reasonp++ =  x1;
  goto update__type__functor_4_4;
  };
  goto update__type__functor_4_4;
 case VARREF:
  deref_and_jump(x0,update__type__functor_4_2);
  *reasonp++ =  x0;
  goto update__type__functor_4_4;
  };
  goto update__type__functor_4_4;
 case VARREF:
  deref_and_jump(a0,update__type__functor_4_1);
  *reasonp++ =  a0;
  goto update__type__functor_4_4;
  };
  goto update__type__functor_4_4;
 update__type__functor_4_4:
  otherwise(update__type__functor_4_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xadd__dep__goal_3);
  allocp[2] = a3;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_type_xadd__i__goal_3);
  allocp[7] = a3;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x0;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_type_xadd__dep__goal_3);
  allocp[12] = a3;
  allocp[13] = x2 = makeref(&allocp[13]);
  allocp[14] = a1;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_type_xadd__i__goal_3);
  allocp[17] = a3;
  allocp[18] = x3 = makeref(&allocp[18]);
  allocp[19] = x2;
  a1 = NILATOM;
  a2 = x3;
  a3 = NILATOM;
  a4 = x1;
  qp = (struct goalrec*)&allocp[15];
  allocp += 20;
  execute(update__type__functor1_5_0);
  goto update__type__functor1_5_ext_interrupt;
 update__type__functor_4_ext_interrupt:
  reasonp = 0l;
 update__type__functor_4_interrupt:
  goto interrupt_4;
 }

 update__type__functor1_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 update__type__functor1_5_clear_reason:
  reasonp = reasons;
 update__type__functor1_5_0:
 update__type__functor1_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 update__type__functor1_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_4)) goto update__type__functor1_5_5;
  x1 = arg(x0, 0);
 update__type__functor1_5_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_s_3)) goto update__type__functor1_5_5;
  x2 = arg(x1, 0);
 update__type__functor1_5_4:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != makesym(atom___v)) goto update__type__functor1_5_5;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin__type_xupdate__type__functor1_5);
  x3 = cdr_of(a0);
  allocp[2] = x3;
  allocp[3] = x4 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x5 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_type_xor__types_3);
  allocp[9] = a3;
  allocp[10] = makecons(cons_const_5);
  allocp[11] = x5;
  allocp[12] = makesym(functor_t_4);
  allocp[13] = x1;
  allocp[14] = NILATOM;
  allocp[15] = NILATOM;
  allocp[16] = makesym(atom_u);
  x6 = makefunctor(&allocp[12]);
  allocp[17] = NILATOM;
  allocp[18] = x6;
  x7 = makecons(&allocp[17]);
  allocp[19] = (q)(struct goalrec*)&allocp[7];
  allocp[20] = (q)(&predicate_type_xor__types_3);
  allocp[21] = a1;
  allocp[22] = x7;
  allocp[23] = x4;
  qp = (struct goalrec*)&allocp[19];
  allocp += 24;
  proceed();
 case VARREF:
  deref_and_jump(x2,update__type__functor1_5_4);
  *reasonp++ =  x2;
  goto update__type__functor1_5_5;
  };
  goto update__type__functor1_5_5;
 case VARREF:
  deref_and_jump(x1,update__type__functor1_5_3);
  *reasonp++ =  x1;
  goto update__type__functor1_5_5;
  };
  goto update__type__functor1_5_5;
 case VARREF:
  deref_and_jump(x0,update__type__functor1_5_2);
  *reasonp++ =  x0;
  goto update__type__functor1_5_5;
  };
  goto update__type__functor1_5_5;
 case VARREF:
  deref_and_jump(a0,update__type__functor1_5_1);
  *reasonp++ =  a0;
  goto update__type__functor1_5_5;
  };
  goto update__type__functor1_5_5;
 update__type__functor1_5_5:
  otherwise(update__type__functor1_5_interrupt);
 update__type__functor1_5_6:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 update__type__functor1_5_7:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_4)) goto update__type__functor1_5_9;
  x1 = arg(x0, 0);
 update__type__functor1_5_8:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_s_3)) goto update__type__functor1_5_9;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin__type_xupdate__type__functor1_5);
  x2 = cdr_of(a0);
  allocp[2] = x2;
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x4 = makeref(&allocp[5]);
  allocp[6] = a4;
  a0 = arg(x1, 0);
  x5 = arg(x1, 1);
  a2 = a1;
  a4 = a3;
  a5 = x4;
  a3 = x3;
  a1 = x5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(update__type__functor2_6_0);
  goto update__type__functor2_6_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,update__type__functor1_5_8);
  *reasonp++ =  x1;
  goto update__type__functor1_5_9;
  };
  goto update__type__functor1_5_9;
 case VARREF:
  deref_and_jump(x0,update__type__functor1_5_7);
  *reasonp++ =  x0;
  goto update__type__functor1_5_9;
  };
  goto update__type__functor1_5_9;
 case VARREF:
  deref_and_jump(a0,update__type__functor1_5_6);
  *reasonp++ =  a0;
  goto update__type__functor1_5_9;
  };
  goto update__type__functor1_5_9;
 update__type__functor1_5_9:
  otherwise(update__type__functor1_5_interrupt);
 update__type__functor1_5_10:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 update__type__functor1_5_11:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_4)) goto update__type__functor1_5_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin__type_xupdate__type__functor1_5);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_type_xor__types_3);
  allocp[9] = a3;
  allocp[10] = makecons(cons_const_5);
  allocp[11] = x3;
  allocp[12] = makesym(functor_t_4);
  allocp[13] = arg(x0, 0);
  allocp[14] = NILATOM;
  allocp[15] = NILATOM;
  allocp[16] = makesym(atom_u);
  x4 = makefunctor(&allocp[12]);
  allocp[17] = NILATOM;
  allocp[18] = x4;
  x5 = makecons(&allocp[17]);
  allocp[19] = (q)(struct goalrec*)&allocp[7];
  allocp[20] = (q)(&predicate_type_xor__types_3);
  allocp[21] = a1;
  allocp[22] = x5;
  allocp[23] = x2;
  qp = (struct goalrec*)&allocp[19];
  allocp += 24;
  proceed();
 case VARREF:
  deref_and_jump(x0,update__type__functor1_5_11);
  *reasonp++ =  x0;
  goto update__type__functor1_5_interrupt;
  };
  goto update__type__functor1_5_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto update__type__functor1_5_interrupt;
  unify2(a2, a1, a4, a3);
  proceed();
 case VARREF:
  deref_and_jump(a0,update__type__functor1_5_10);
  *reasonp++ =  a0;
  goto update__type__functor1_5_interrupt;
  };
  goto update__type__functor1_5_interrupt;
 update__type__functor1_5_ext_interrupt:
  reasonp = 0l;
 update__type__functor1_5_interrupt:
  toppred = &predicate_builtin__type_xupdate__type__functor1_5;
  goto interrupt_5;
 }

 update__type__functor2_6_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 update__type__functor2_6_clear_reason:
  reasonp = reasons;
 update__type__functor2_6_0:
 update__type__functor2_6_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom__3F)) goto update__type__functor2_6_4;
 update__type__functor2_6_2:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (isint(a1)) goto update__type__functor2_6_3;
  if (a1 != makesym(atom_n)) goto update__type__functor2_6_4;
  unify(a3, a2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xor__types_3);
  allocp[2] = a4;
  allocp[3] = makecons(cons_const_2);
  allocp[4] = a5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 update__type__functor2_6_3:
  gblt_integer(a1,update__type__functor2_6_4);
  unify(a3, a2);
  allocp[0] = makesym(functor_i_1);
  allocp[1] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_t_4);
  allocp[3] = x0;
  allocp[4] = NILATOM;
  allocp[5] = NILATOM;
  allocp[6] = makesym(atom_u);
  x1 = makefunctor(&allocp[2]);
  allocp[7] = NILATOM;
  allocp[8] = x1;
  x2 = makecons(&allocp[7]);
  allocp[9] = (q)qp;
  allocp[10] = (q)(&predicate_type_xor__types_3);
  allocp[11] = a4;
  allocp[12] = x2;
  allocp[13] = a5;
  qp = (struct goalrec*)&allocp[9];
  allocp += 14;
  proceed();
 case VARREF:
  deref_and_jump(a1,update__type__functor2_6_2);
  *reasonp++ =  a1;
  goto update__type__functor2_6_4;
  };
  goto update__type__functor2_6_4;
 case VARREF:
  deref_and_jump(a0,update__type__functor2_6_1);
  *reasonp++ =  a0;
  goto update__type__functor2_6_4;
  };
  goto update__type__functor2_6_4;
 update__type__functor2_6_4:
  otherwise(update__type__functor2_6_interrupt);
 update__type__functor2_6_5:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (isint(a1)) goto update__type__functor2_6_6;
  if (a1 != makesym(atom_n)) goto update__type__functor2_6_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xor__types_3);
  allocp[2] = a4;
  allocp[3] = makecons(cons_const_2);
  allocp[4] = a5;
  allocp[5] = makesym(functor_a_1);
  allocp[6] = a0;
  x0 = makefunctor(&allocp[5]);
  allocp[7] = makesym(functor_t_4);
  allocp[8] = x0;
  allocp[9] = NILATOM;
  allocp[10] = NILATOM;
  allocp[11] = makesym(atom_u);
  x1 = makefunctor(&allocp[7]);
  allocp[12] = NILATOM;
  allocp[13] = x1;
  x2 = makecons(&allocp[12]);
  allocp[14] = (q)(struct goalrec*)&allocp[0];
  allocp[15] = (q)(&predicate_type_xor__types_3);
  allocp[16] = a2;
  allocp[17] = x2;
  allocp[18] = a3;
  qp = (struct goalrec*)&allocp[14];
  allocp += 19;
  proceed();
 update__type__functor2_6_6:
  gblt_integer(a1,update__type__functor2_6_interrupt);
  allocp[0] = makesym(functor_i_1);
  allocp[1] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_t_4);
  allocp[3] = x0;
  allocp[4] = NILATOM;
  allocp[5] = NILATOM;
  allocp[6] = makesym(atom_u);
  x1 = makefunctor(&allocp[2]);
  allocp[7] = NILATOM;
  allocp[8] = x1;
  x2 = makecons(&allocp[7]);
  allocp[9] = (q)qp;
  allocp[10] = (q)(&predicate_type_xor__types_3);
  allocp[11] = a4;
  allocp[12] = x2;
  allocp[13] = a5;
  allocp[14] = makesym(functor_a_1);
  allocp[15] = a0;
  x3 = makefunctor(&allocp[14]);
  allocp[16] = makesym(functor_t_4);
  allocp[17] = x3;
  allocp[18] = NILATOM;
  allocp[19] = NILATOM;
  allocp[20] = makesym(atom_u);
  x4 = makefunctor(&allocp[16]);
  allocp[21] = NILATOM;
  allocp[22] = x4;
  x5 = makecons(&allocp[21]);
  allocp[23] = (q)(struct goalrec*)&allocp[9];
  allocp[24] = (q)(&predicate_type_xor__types_3);
  allocp[25] = a2;
  allocp[26] = x5;
  allocp[27] = a3;
  qp = (struct goalrec*)&allocp[23];
  allocp += 28;
  proceed();
 case VARREF:
  deref_and_jump(a1,update__type__functor2_6_5);
  *reasonp++ =  a1;
  goto update__type__functor2_6_interrupt;
  };
  goto update__type__functor2_6_interrupt;
 update__type__functor2_6_ext_interrupt:
  reasonp = 0l;
 update__type__functor2_6_interrupt:
  toppred = &predicate_builtin__type_xupdate__type__functor2_6;
  goto interrupt_6;
 }

 update__type__arg_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 update__type__arg_4_clear_reason:
  reasonp = reasons;
 update__type__arg_4_0:
 update__type__arg_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom__3F)) goto update__type__arg_4_2;
  unify_value(a2, makecons(cons_const_0));
  proceed();
 case VARREF:
  deref_and_jump(a0,update__type__arg_4_1);
  *reasonp++ =  a0;
  goto update__type__arg_4_2;
  };
  goto update__type__arg_4_2;
 update__type__arg_4_2:
 update__type__arg_4_3:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 update__type__arg_4_4:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__3F)) goto update__type__arg_4_6;
  x1 = cdr_of(a1);
 update__type__arg_4_5:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto update__type__arg_4_6;
  unify_value(a2, makecons(cons_const_0));
  proceed();
 case VARREF:
  deref_and_jump(x1,update__type__arg_4_5);
  *reasonp++ =  x1;
  goto update__type__arg_4_6;
  };
  goto update__type__arg_4_6;
 case VARREF:
  deref_and_jump(x0,update__type__arg_4_4);
  *reasonp++ =  x0;
  goto update__type__arg_4_6;
  };
  goto update__type__arg_4_6;
 case VARREF:
  deref_and_jump(a1,update__type__arg_4_3);
  *reasonp++ =  a1;
  goto update__type__arg_4_6;
  };
  goto update__type__arg_4_6;
 update__type__arg_4_6:
  otherwise(update__type__arg_4_interrupt);
 update__type__arg_4_7:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 update__type__arg_4_8:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__3F)) goto update__type__arg_4_9;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xor__types_3);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = makecons(cons_const_0);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_type_xadd__dep__goal_3);
  allocp[7] = a3;
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = x1;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_type_xadd__i__goal_3);
  allocp[12] = a3;
  allocp[13] = x3 = makeref(&allocp[13]);
  allocp[14] = x2;
  a2 = NILATOM;
  a3 = x3;
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  execute(update__type__arg1_4_0);
  goto update__type__arg1_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,update__type__arg_4_8);
  *reasonp++ =  x0;
  goto update__type__arg_4_9;
  };
  goto update__type__arg_4_9;
 case VARREF:
  deref_and_jump(a1,update__type__arg_4_7);
  *reasonp++ =  a1;
  goto update__type__arg_4_9;
  };
  goto update__type__arg_4_9;
 update__type__arg_4_9:
  otherwise(update__type__arg_4_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xadd__dep__goal_3);
  allocp[2] = a3;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_type_xadd__i__goal_3);
  allocp[7] = a3;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x0;
  a2 = NILATOM;
  a3 = x1;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  execute(update__type__arg1_4_0);
  goto update__type__arg1_4_ext_interrupt;
 update__type__arg_4_ext_interrupt:
  reasonp = 0l;
 update__type__arg_4_interrupt:
  goto interrupt_4;
 }

 update__type__arg1_4_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 update__type__arg1_4_clear_reason:
  reasonp = reasons;
 update__type__arg1_4_0:
 update__type__arg1_4_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 update__type__arg1_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_4)) goto update__type__arg1_4_5;
  x1 = arg(x0, 0);
 update__type__arg1_4_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_s_3)) goto update__type__arg1_4_5;
  x2 = arg(x1, 1);
 update__type__arg1_4_4:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != makesym(atom_n)) goto update__type__arg1_4_5;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin__type_xupdate__type__arg1_4);
  allocp[2] = a0;
  x3 = cdr_of(a1);
  allocp[3] = x3;
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_type_xor__types_3);
  allocp[8] = a2;
  x5 = arg(x1, 2);
  allocp[9] = x5;
  allocp[10] = x4;
  qp = (struct goalrec*)&allocp[6];
  allocp += 11;
  proceed();
 case VARREF:
  deref_and_jump(x2,update__type__arg1_4_4);
  *reasonp++ =  x2;
  goto update__type__arg1_4_5;
  };
  goto update__type__arg1_4_5;
 case VARREF:
  deref_and_jump(x1,update__type__arg1_4_3);
  *reasonp++ =  x1;
  goto update__type__arg1_4_5;
  };
  goto update__type__arg1_4_5;
 case VARREF:
  deref_and_jump(x0,update__type__arg1_4_2);
  *reasonp++ =  x0;
  goto update__type__arg1_4_5;
  };
  goto update__type__arg1_4_5;
 case VARREF:
  deref_and_jump(a1,update__type__arg1_4_1);
  *reasonp++ =  a1;
  goto update__type__arg1_4_5;
  };
  goto update__type__arg1_4_5;
 update__type__arg1_4_5:
  otherwise(update__type__arg1_4_interrupt);
 update__type__arg1_4_6:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 update__type__arg1_4_7:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_4)) goto update__type__arg1_4_10;
  x1 = arg(x0, 0);
 update__type__arg1_4_8:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_s_3)) goto update__type__arg1_4_10;
 update__type__arg1_4_9:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_i_1)) goto update__type__arg1_4_10;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin__type_xupdate__type__arg1_4);
  allocp[2] = a0;
  x2 = cdr_of(a1);
  allocp[3] = x2;
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_type_xor__types_3);
  allocp[8] = a2;
  allocp[9] = x4 = makeref(&allocp[9]);
  allocp[10] = x3;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_functor__table_xarg_3);
  x5 = arg(a0, 0);
  allocp[13] = x5;
  x6 = arg(x1, 2);
  allocp[14] = x6;
  allocp[15] = x4;
  qp = (struct goalrec*)&allocp[11];
  allocp += 16;
  proceed();
 case VARREF:
  deref_and_jump(a0,update__type__arg1_4_9);
  *reasonp++ =  a0;
  goto update__type__arg1_4_10;
  };
  goto update__type__arg1_4_10;
 case VARREF:
  deref_and_jump(x1,update__type__arg1_4_8);
  *reasonp++ =  x1;
  goto update__type__arg1_4_10;
  };
  goto update__type__arg1_4_10;
 case VARREF:
  deref_and_jump(x0,update__type__arg1_4_7);
  *reasonp++ =  x0;
  goto update__type__arg1_4_10;
  };
  goto update__type__arg1_4_10;
 case VARREF:
  deref_and_jump(a1,update__type__arg1_4_6);
  *reasonp++ =  a1;
  goto update__type__arg1_4_10;
  };
  goto update__type__arg1_4_10;
 update__type__arg1_4_10:
  otherwise(update__type__arg1_4_interrupt);
 update__type__arg1_4_11:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 update__type__arg1_4_12:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_4)) goto update__type__arg1_4_14;
  x1 = arg(x0, 0);
 update__type__arg1_4_13:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_s_3)) goto update__type__arg1_4_14;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin__type_xupdate__type__arg1_4);
  allocp[2] = a0;
  x2 = cdr_of(a1);
  allocp[3] = x2;
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = a3;
  a0 = arg(x1, 1);
  a1 = arg(x1, 2);
  a3 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(update__type__arg__merge_4_0);
  goto update__type__arg__merge_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,update__type__arg1_4_13);
  *reasonp++ =  x1;
  goto update__type__arg1_4_14;
  };
  goto update__type__arg1_4_14;
 case VARREF:
  deref_and_jump(x0,update__type__arg1_4_12);
  *reasonp++ =  x0;
  goto update__type__arg1_4_14;
  };
  goto update__type__arg1_4_14;
 case VARREF:
  deref_and_jump(a1,update__type__arg1_4_11);
  *reasonp++ =  a1;
  goto update__type__arg1_4_14;
  };
  goto update__type__arg1_4_14;
 update__type__arg1_4_14:
  otherwise(update__type__arg1_4_interrupt);
 update__type__arg1_4_15:
  switch (ptagof(a1)) {
 case CONS:
  a1 = cdr_of(a1);
  execute(update__type__arg1_4_0);
  goto update__type__arg1_4_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto update__type__arg1_4_interrupt;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a1,update__type__arg1_4_15);
  *reasonp++ =  a1;
  goto update__type__arg1_4_interrupt;
  };
  goto update__type__arg1_4_interrupt;
 update__type__arg1_4_ext_interrupt:
  reasonp = 0l;
 update__type__arg1_4_interrupt:
  toppred = &predicate_builtin__type_xupdate__type__arg1_4;
  goto interrupt_4;
 }

 update__type__arg__merge_4_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 update__type__arg__merge_4_clear_reason:
  reasonp = reasons;
 update__type__arg__merge_4_0:
 update__type__arg__merge_4_1:
  if (!isint(a0)) goto update__type__arg__merge_4_3;
  gblt_greater(a0,makeint(0L),update__type__arg__merge_4_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin__type_xupdate__type__arg__merge_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x0;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_type_xor__types_3);
  allocp[13] = a2;
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_functor__table_xarg_3);
  allocp[18] = a0;
  allocp[19] = a1;
  allocp[20] = x2;
  qp = (struct goalrec*)&allocp[16];
  allocp += 21;
  proceed();
 update__type__arg__merge_4_2:
  if (a0 != makeint(0L)) goto update__type__arg__merge_4_interrupt;
  unify(a3, a2);
  proceed();
 update__type__arg__merge_4_3:
  if (!isref(a0)) goto update__type__arg__merge_4_interrupt;
  deref_and_jump(a0,update__type__arg__merge_4_1);
  *reasonp++ =  a0;
  goto update__type__arg__merge_4_interrupt;
 update__type__arg__merge_4_ext_interrupt:
  reasonp = 0l;
 update__type__arg__merge_4_interrupt:
  toppred = &predicate_builtin__type_xupdate__type__arg__merge_4;
  goto interrupt_4;
 }

 update__type__setarg_6_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 update__type__setarg_6_clear_reason:
  reasonp = reasons;
 update__type__setarg_6_0:
 update__type__setarg_6_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom__3F)) goto update__type__setarg_6_2;
  unify_value(a3, makecons(cons_const_0));
  proceed();
 case VARREF:
  deref_and_jump(a0,update__type__setarg_6_1);
  *reasonp++ =  a0;
  goto update__type__setarg_6_2;
  };
  goto update__type__setarg_6_2;
 update__type__setarg_6_2:
 update__type__setarg_6_3:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 update__type__setarg_6_4:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__3F)) goto update__type__setarg_6_6;
  x1 = cdr_of(a1);
 update__type__setarg_6_5:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto update__type__setarg_6_6;
  unify_value(a3, makecons(cons_const_0));
  proceed();
 case VARREF:
  deref_and_jump(x1,update__type__setarg_6_5);
  *reasonp++ =  x1;
  goto update__type__setarg_6_6;
  };
  goto update__type__setarg_6_6;
 case VARREF:
  deref_and_jump(x0,update__type__setarg_6_4);
  *reasonp++ =  x0;
  goto update__type__setarg_6_6;
  };
  goto update__type__setarg_6_6;
 case VARREF:
  deref_and_jump(a1,update__type__setarg_6_3);
  *reasonp++ =  a1;
  goto update__type__setarg_6_6;
  };
  goto update__type__setarg_6_6;
 update__type__setarg_6_6:
 update__type__setarg_6_7:
  switch (ptagof(a2)) {
 case CONS:
  x0 = car_of(a2);
 update__type__setarg_6_8:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__3F)) goto update__type__setarg_6_10;
  x1 = cdr_of(a2);
 update__type__setarg_6_9:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto update__type__setarg_6_10;
  unify_value(a3, makecons(cons_const_0));
  proceed();
 case VARREF:
  deref_and_jump(x1,update__type__setarg_6_9);
  *reasonp++ =  x1;
  goto update__type__setarg_6_10;
  };
  goto update__type__setarg_6_10;
 case VARREF:
  deref_and_jump(x0,update__type__setarg_6_8);
  *reasonp++ =  x0;
  goto update__type__setarg_6_10;
  };
  goto update__type__setarg_6_10;
 case VARREF:
  deref_and_jump(a2,update__type__setarg_6_7);
  *reasonp++ =  a2;
  goto update__type__setarg_6_10;
  };
  goto update__type__setarg_6_10;
 update__type__setarg_6_10:
  otherwise(update__type__setarg_6_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xadd__dep__goal_3);
  allocp[2] = a5;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_type_xadd__i__goal_3);
  allocp[7] = a5;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x0;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_type_xadd__dep__goal_3);
  allocp[12] = a5;
  allocp[13] = x2 = makeref(&allocp[13]);
  allocp[14] = a3;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_type_xadd__i__goal_3);
  allocp[17] = a5;
  allocp[18] = x3 = makeref(&allocp[18]);
  allocp[19] = x2;
  a3 = NILATOM;
  a4 = x3;
  a6 = x1;
  a7 = a5;
  a5 = NILATOM;
  qp = (struct goalrec*)&allocp[15];
  allocp += 20;
  execute(update__type__setarg1_8_0);
  goto update__type__setarg1_8_ext_interrupt;
 update__type__setarg_6_ext_interrupt:
  reasonp = 0l;
 update__type__setarg_6_interrupt:
  goto interrupt_6;
 }

 update__type__setarg1_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 update__type__setarg1_8_clear_reason:
  reasonp = reasons;
 update__type__setarg1_8_0:
 update__type__setarg1_8_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 update__type__setarg1_8_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__3F)) goto update__type__setarg1_8_8;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin__type_xupdate__type__setarg1_8);
  allocp[2] = a0;
  x1 = cdr_of(a1);
  allocp[3] = x1;
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_type_xor__types_3);
  allocp[12] = a5;
  allocp[13] = makecons(cons_const_0);
  allocp[14] = x3;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_type_xor__types_3);
  allocp[17] = a3;
  allocp[18] = makecons(cons_const_0);
  allocp[19] = x2;
  qp = (struct goalrec*)&allocp[15];
  allocp += 20;
  proceed();
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_4)) goto update__type__setarg1_8_8;
  x1 = arg(x0, 0);
 update__type__setarg1_8_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_s_3)) goto update__type__setarg1_8_8;
 update__type__setarg1_8_4:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_i_1)) goto update__type__setarg1_8_5;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin__type_xupdate__type__setarg1_8);
  allocp[2] = a0;
  x2 = cdr_of(a1);
  allocp[3] = x2;
  allocp[4] = a2;
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x4 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_type_xor__types_3);
  allocp[12] = a5;
  allocp[13] = x5 = makeref(&allocp[13]);
  allocp[14] = x4;
  allocp[15] = NILATOM;
  allocp[16] = x7 = makeref(&allocp[16]);
  x6 = makecons(&allocp[15]);
  allocp[17] = (q)(struct goalrec*)&allocp[10];
  allocp[18] = (q)(&predicate_type_xor__types_3);
  allocp[19] = a3;
  allocp[20] = x6;
  allocp[21] = x3;
  allocp[22] = (q)(struct goalrec*)&allocp[17];
  allocp[23] = (q)(&predicate_type_xset__struct__arg__types_4);
  x8 = arg(a0, 0);
  allocp[24] = x8;
  allocp[25] = x0;
  allocp[26] = a2;
  allocp[27] = x7;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_type_xget__struct__arg__types_3);
  allocp[30] = x8;
  allocp[31] = x0;
  allocp[32] = x5;
  qp = (struct goalrec*)&allocp[28];
  allocp += 33;
  proceed();
 case VARREF:
  deref_and_jump(a0,update__type__setarg1_8_4);
  *reasonp++ =  a0;
  goto update__type__setarg1_8_5;
  };
  goto update__type__setarg1_8_5;
 update__type__setarg1_8_5:
  x2 = arg(x1, 1);
 update__type__setarg1_8_6:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != makesym(atom_n)) goto update__type__setarg1_8_8;
 update__type__setarg1_8_7:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_i)) goto update__type__setarg1_8_8;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin__type_xupdate__type__setarg1_8);
  allocp[2] = a0;
  x3 = cdr_of(a1);
  allocp[3] = x3;
  allocp[4] = a2;
  allocp[5] = x4 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x5 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_type_xor__types_3);
  allocp[12] = a5;
  x6 = arg(x1, 2);
  allocp[13] = x6;
  allocp[14] = x5;
  allocp[15] = makesym(functor_s_3);
  allocp[16] = arg(x1, 0);
  allocp[17] = makesym(atom_n);
  allocp[18] = x8 = makeref(&allocp[18]);
  x7 = makefunctor(&allocp[15]);
  allocp[19] = makesym(functor_t_4);
  allocp[20] = x7;
  allocp[21] = arg(x0, 1);
  allocp[22] = arg(x0, 2);
  allocp[23] = arg(x0, 3);
  x9 = makefunctor(&allocp[19]);
  allocp[24] = NILATOM;
  allocp[25] = x9;
  x10 = makecons(&allocp[24]);
  allocp[26] = (q)(struct goalrec*)&allocp[10];
  allocp[27] = (q)(&predicate_type_xor__types_3);
  allocp[28] = a3;
  allocp[29] = x10;
  allocp[30] = x4;
  allocp[31] = (q)(struct goalrec*)&allocp[26];
  allocp[32] = (q)(&predicate_type_xor__types_3);
  allocp[33] = x6;
  allocp[34] = a2;
  allocp[35] = x8;
  qp = (struct goalrec*)&allocp[31];
  allocp += 36;
  proceed();
 case VARREF:
  deref_and_jump(a0,update__type__setarg1_8_7);
  *reasonp++ =  a0;
  goto update__type__setarg1_8_8;
  };
  goto update__type__setarg1_8_8;
 case VARREF:
  deref_and_jump(x2,update__type__setarg1_8_6);
  *reasonp++ =  x2;
  goto update__type__setarg1_8_8;
  };
  goto update__type__setarg1_8_8;
 case VARREF:
  deref_and_jump(x1,update__type__setarg1_8_3);
  *reasonp++ =  x1;
  goto update__type__setarg1_8_8;
  };
  goto update__type__setarg1_8_8;
 case VARREF:
  deref_and_jump(x0,update__type__setarg1_8_2);
  *reasonp++ =  x0;
  goto update__type__setarg1_8_8;
  };
  goto update__type__setarg1_8_8;
 case VARREF:
  deref_and_jump(a1,update__type__setarg1_8_1);
  *reasonp++ =  a1;
  goto update__type__setarg1_8_8;
  };
  goto update__type__setarg1_8_8;
 update__type__setarg1_8_8:
  otherwise(update__type__setarg1_8_interrupt);
 update__type__setarg1_8_9:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 update__type__setarg1_8_10:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_4)) goto update__type__setarg1_8_interrupt;
  x1 = arg(x0, 0);
 update__type__setarg1_8_11:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_s_3)) goto update__type__setarg1_8_interrupt;
 update__type__setarg1_8_12:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_i)) goto update__type__setarg1_8_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin__type_xupdate__type__setarg1_8);
  allocp[2] = a0;
  x2 = cdr_of(a1);
  allocp[3] = x2;
  allocp[4] = a2;
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x4 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = makesym(functor_s_3);
  allocp[11] = arg(x1, 0);
  allocp[12] = arg(x1, 1);
  allocp[13] = x6 = makeref(&allocp[13]);
  x5 = makefunctor(&allocp[10]);
  allocp[14] = makesym(functor_t_4);
  allocp[15] = x5;
  allocp[16] = arg(x0, 1);
  allocp[17] = arg(x0, 2);
  allocp[18] = arg(x0, 3);
  x7 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x7;
  x8 = makecons(&allocp[19]);
  allocp[21] = (q)(struct goalrec*)&allocp[0];
  allocp[22] = (q)(&predicate_type_xor__types_3);
  allocp[23] = a3;
  allocp[24] = x8;
  allocp[25] = x3;
  a0 = arg(x1, 1);
  a1 = a2;
  a2 = arg(x1, 2);
  a3 = x6;
  a4 = a5;
  a5 = x4;
  qp = (struct goalrec*)&allocp[21];
  allocp += 26;
  execute(update__type__setarg2_6_0);
  goto update__type__setarg2_6_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,update__type__setarg1_8_12);
  *reasonp++ =  a0;
  goto update__type__setarg1_8_interrupt;
  };
  goto update__type__setarg1_8_interrupt;
 case VARREF:
  deref_and_jump(x1,update__type__setarg1_8_11);
  *reasonp++ =  x1;
  goto update__type__setarg1_8_interrupt;
  };
  goto update__type__setarg1_8_interrupt;
 case VARREF:
  deref_and_jump(x0,update__type__setarg1_8_10);
  *reasonp++ =  x0;
  goto update__type__setarg1_8_interrupt;
  };
  goto update__type__setarg1_8_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto update__type__setarg1_8_interrupt;
  unify2(a4, a3, a6, a5);
  proceed();
 case VARREF:
  deref_and_jump(a1,update__type__setarg1_8_9);
  *reasonp++ =  a1;
  goto update__type__setarg1_8_interrupt;
  };
  goto update__type__setarg1_8_interrupt;
 update__type__setarg1_8_ext_interrupt:
  reasonp = 0l;
 update__type__setarg1_8_interrupt:
  toppred = &predicate_builtin__type_xupdate__type__setarg1_8;
  goto interrupt_8;
 }

 update__type__setarg2_6_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 update__type__setarg2_6_clear_reason:
  reasonp = reasons;
 update__type__setarg2_6_0:
 update__type__setarg2_6_1:
  if (!isint(a0)) goto update__type__setarg2_6_3;
  gblt_greater(a0,makeint(0L),update__type__setarg2_6_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin__type_xupdate__type__setarg2_6);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[10] = a0;
  allocp[11] = makeint(1L);
  allocp[12] = x0;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[15] = a0;
  allocp[16] = a2;
  allocp[17] = x3 = makeref(&allocp[17]);
  allocp[18] = x1;
  allocp[19] = (q)(struct goalrec*)&allocp[13];
  allocp[20] = (q)(&predicate_type_xor__types_3);
  allocp[21] = x4 = makeref(&allocp[21]);
  allocp[22] = a1;
  allocp[23] = x3;
  allocp[24] = (q)(struct goalrec*)&allocp[19];
  allocp[25] = (q)(&predicate_type_xor__types_3);
  allocp[26] = a4;
  allocp[27] = x4;
  allocp[28] = x2;
  allocp[29] = (q)(struct goalrec*)&allocp[24];
  allocp[30] = (q)(&predicate_functor__table_xarg_3);
  allocp[31] = a0;
  allocp[32] = a2;
  allocp[33] = x4;
  qp = (struct goalrec*)&allocp[29];
  allocp += 34;
  proceed();
 update__type__setarg2_6_2:
  if (a0 != makeint(0L)) goto update__type__setarg2_6_interrupt;
  unify2(a3, a2, a5, a4);
  proceed();
 update__type__setarg2_6_3:
  if (!isref(a0)) goto update__type__setarg2_6_interrupt;
  deref_and_jump(a0,update__type__setarg2_6_1);
  *reasonp++ =  a0;
  goto update__type__setarg2_6_interrupt;
 update__type__setarg2_6_ext_interrupt:
  reasonp = 0l;
 update__type__setarg2_6_interrupt:
  toppred = &predicate_builtin__type_xupdate__type__setarg2_6;
  goto interrupt_6;
 }

 update__type__new__vector_4_top: {
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 update__type__new__vector_4_clear_reason:
  reasonp = reasons;
 update__type__new__vector_4_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin__type_xupdate__type__new__vector1_5);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = NILATOM;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_print_xdatan_1);
  allocp[9] = a1;
  allocp[10] = (q)(struct goalrec*)&allocp[7];
  allocp[11] = (q)(&predicate_print_xdata_1);
  allocp[12] = makesym(atom_IL_3A);
  allocp[13] = (q)(struct goalrec*)&allocp[10];
  allocp[14] = (q)(&predicate_print_xdatan_1);
  allocp[15] = a0;
  allocp[16] = (q)(struct goalrec*)&allocp[13];
  allocp[17] = (q)(&predicate_print_xdata_1);
  allocp[18] = makesym(atom_S_3A);
  allocp[19] = (q)(struct goalrec*)&allocp[16];
  allocp[20] = (q)(&predicate_print_xdatan_1);
  allocp[21] = makesym(atom_VECTEST);
  qp = (struct goalrec*)&allocp[19];
  allocp += 22;
  proceed();
 update__type__new__vector_4_ext_interrupt:
  reasonp = 0l;
 update__type__new__vector_4_interrupt:
  goto interrupt_4;
 }

 update__type__new__vector1_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 update__type__new__vector1_5_clear_reason:
  reasonp = reasons;
 update__type__new__vector1_5_0:
 update__type__new__vector1_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto update__type__new__vector1_5_8;
  switch (symval(a0)) {
 case symval(makesym(atom__3F)):
 update__type__new__vector1_5_2:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 update__type__new__vector1_5_3:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__3F)) goto update__type__new__vector1_5_8;
  x1 = cdr_of(a1);
 update__type__new__vector1_5_4:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto update__type__new__vector1_5_8;
  allocp[0] = a2;
  allocp[1] = makesym(atom__3F);
  x2 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a3, x2);
  proceed();
 case VARREF:
  deref_and_jump(x1,update__type__new__vector1_5_4);
  *reasonp++ =  x1;
  goto update__type__new__vector1_5_8;
  };
  goto update__type__new__vector1_5_8;
 case VARREF:
  deref_and_jump(x0,update__type__new__vector1_5_3);
  *reasonp++ =  x0;
  goto update__type__new__vector1_5_8;
  };
  goto update__type__new__vector1_5_8;
 case ATOMIC:
  if (a1 != NILATOM) goto update__type__new__vector1_5_8;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a1,update__type__new__vector1_5_2);
  *reasonp++ =  a1;
  goto update__type__new__vector1_5_8;
  };
  goto update__type__new__vector1_5_8;
 case symval(NILATOM):
 update__type__new__vector1_5_5:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 update__type__new__vector1_5_6:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__3F)) goto update__type__new__vector1_5_8;
  x1 = cdr_of(a1);
 update__type__new__vector1_5_7:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto update__type__new__vector1_5_8;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(x1,update__type__new__vector1_5_7);
  *reasonp++ =  x1;
  goto update__type__new__vector1_5_8;
  };
  goto update__type__new__vector1_5_8;
 case VARREF:
  deref_and_jump(x0,update__type__new__vector1_5_6);
  *reasonp++ =  x0;
  goto update__type__new__vector1_5_8;
  };
  goto update__type__new__vector1_5_8;
 case ATOMIC:
  if (a1 != NILATOM) goto update__type__new__vector1_5_8;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a1,update__type__new__vector1_5_5);
  *reasonp++ =  a1;
  goto update__type__new__vector1_5_8;
  };
  goto update__type__new__vector1_5_8;
  };
  goto update__type__new__vector1_5_8;
 case VARREF:
  deref_and_jump(a0,update__type__new__vector1_5_1);
  *reasonp++ =  a0;
  goto update__type__new__vector1_5_8;
  };
  goto update__type__new__vector1_5_8;
 update__type__new__vector1_5_8:
  otherwise(update__type__new__vector1_5_interrupt);
 update__type__new__vector1_5_9:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_i)) goto update__type__new__vector1_5_10;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin__type_xupdate__type__new__vector1_5);
  allocp[2] = NILATOM;
  allocp[3] = a1;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_type_xor__types_3);
  allocp[9] = a2;
  allocp[10] = makecons(cons_const_11);
  allocp[11] = x0;
  qp = (struct goalrec*)&allocp[7];
  allocp += 12;
  proceed();
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_i_1)) goto update__type__new__vector1_5_10;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin__type_xupdate__type__new__vector1_5);
  allocp[2] = NILATOM;
  allocp[3] = a1;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = makesym(functor_s_3);
  allocp[8] = makesym(atom___v);
  allocp[9] = arg(a0, 0);
  allocp[10] = x2 = makeref(&allocp[10]);
  x1 = makefunctor(&allocp[7]);
  allocp[11] = NILATOM;
  allocp[12] = a4;
  x3 = makecons(&allocp[11]);
  allocp[13] = NILATOM;
  allocp[14] = a4;
  x4 = makecons(&allocp[13]);
  allocp[15] = makesym(functor_t_4);
  allocp[16] = x1;
  allocp[17] = x3;
  allocp[18] = x4;
  allocp[19] = makesym(atom_u);
  x5 = makefunctor(&allocp[15]);
  allocp[20] = NILATOM;
  allocp[21] = x5;
  x6 = makecons(&allocp[20]);
  allocp[22] = (q)(struct goalrec*)&allocp[0];
  allocp[23] = (q)(&predicate_type_xor__types_3);
  allocp[24] = a2;
  allocp[25] = x6;
  allocp[26] = x0;
  allocp[27] = NILATOM;
  allocp[28] = a4;
  x7 = makecons(&allocp[27]);
  allocp[29] = NILATOM;
  allocp[30] = a4;
  x8 = makecons(&allocp[29]);
  allocp[31] = makesym(functor_t_4);
  allocp[32] = makefunctor(funct_const_12);
  allocp[33] = x7;
  allocp[34] = x8;
  allocp[35] = makesym(atom_u);
  x9 = makefunctor(&allocp[31]);
  allocp[36] = NILATOM;
  allocp[37] = x9;
  x10 = makecons(&allocp[36]);
  allocp[38] = (q)(struct goalrec*)&allocp[22];
  allocp[39] = (q)(&predicate_uty_xnew__functor__init_4);
  allocp[40] = makesym(atom_arg);
  x11 = arg(a0, 0);
  allocp[41] = x11;
  allocp[42] = x10;
  allocp[43] = x2;
  qp = (struct goalrec*)&allocp[38];
  allocp += 44;
  proceed();
 case VARREF:
  deref_and_jump(a0,update__type__new__vector1_5_9);
  *reasonp++ =  a0;
  goto update__type__new__vector1_5_10;
  };
  goto update__type__new__vector1_5_10;
 update__type__new__vector1_5_10:
 update__type__new__vector1_5_11:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 update__type__new__vector1_5_12:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_4)) goto update__type__new__vector1_5_17;
  x1 = arg(x0, 0);
 update__type__new__vector1_5_13:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_s_3)) goto update__type__new__vector1_5_17;
  x2 = arg(x1, 0);
 update__type__new__vector1_5_14:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != PERIODATOM) goto update__type__new__vector1_5_17;
  x3 = arg(x1, 1);
 update__type__new__vector1_5_15:
  switch (ptagof(x3)) {
 case ATOMIC:
 update__type__new__vector1_5_16:
  if (x3 != makeint(2L)) goto update__type__new__vector1_5_17;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin__type_xupdate__type__new__vector1_5);
  allocp[2] = a0;
  x4 = cdr_of(a1);
  allocp[3] = x4;
  allocp[4] = x5 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_builtin__type_xupdate__type__new__vector2_5);
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = x7 = makeref(&allocp[10]);
  allocp[11] = a2;
  allocp[12] = x5;
  allocp[13] = a4;
  allocp[14] = (q)(struct goalrec*)&allocp[7];
  allocp[15] = (q)(&predicate_type_xlisttype__val_3);
  allocp[16] = x0;
  allocp[17] = x6;
  allocp[18] = x7;
  qp = (struct goalrec*)&allocp[14];
  allocp += 19;
  proceed();
 case VARREF:
  deref_and_jump(x3,update__type__new__vector1_5_15);
  *reasonp++ =  x3;
  goto update__type__new__vector1_5_17;
  };
  goto update__type__new__vector1_5_17;
 case VARREF:
  deref_and_jump(x2,update__type__new__vector1_5_14);
  *reasonp++ =  x2;
  goto update__type__new__vector1_5_17;
  };
  goto update__type__new__vector1_5_17;
 case VARREF:
  deref_and_jump(x1,update__type__new__vector1_5_13);
  *reasonp++ =  x1;
  goto update__type__new__vector1_5_17;
  };
  goto update__type__new__vector1_5_17;
 case VARREF:
  deref_and_jump(x0,update__type__new__vector1_5_12);
  *reasonp++ =  x0;
  goto update__type__new__vector1_5_17;
  };
  goto update__type__new__vector1_5_17;
 case VARREF:
  deref_and_jump(a1,update__type__new__vector1_5_11);
  *reasonp++ =  a1;
  goto update__type__new__vector1_5_17;
  };
  goto update__type__new__vector1_5_17;
 update__type__new__vector1_5_17:
  otherwise(update__type__new__vector1_5_interrupt);
  a0 = makesym(atom__3F);
  a1 = makecons(cons_const_0);
  execute(update__type__new__vector1_5_0);
  goto update__type__new__vector1_5_ext_interrupt;
 update__type__new__vector1_5_ext_interrupt:
  reasonp = 0l;
 update__type__new__vector1_5_interrupt:
  goto interrupt_5;
 }

 update__type__new__vector2_4_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 update__type__new__vector2_4_clear_reason:
  reasonp = reasons;
 update__type__new__vector2_4_0:
 update__type__new__vector2_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_n)) goto update__type__new__vector2_4_interrupt;
  allocp[0] = makesym(functor_s_3);
  allocp[1] = makesym(atom___v);
  allocp[2] = makesym(atom_n);
  allocp[3] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp[4] = NILATOM;
  allocp[5] = x2 = makeref(&allocp[5]);
  x1 = makecons(&allocp[4]);
  allocp[6] = NILATOM;
  allocp[7] = x2;
  x3 = makecons(&allocp[6]);
  allocp[8] = makesym(functor_t_4);
  allocp[9] = x0;
  allocp[10] = x1;
  allocp[11] = x3;
  allocp[12] = makesym(atom_u);
  x4 = makefunctor(&allocp[8]);
  allocp[13] = NILATOM;
  allocp[14] = x4;
  x5 = makecons(&allocp[13]);
  allocp[15] = (q)qp;
  allocp[16] = (q)(&predicate_type_xor__types_3);
  allocp[17] = a2;
  allocp[18] = x5;
  allocp[19] = a3;
  allocp[20] = (q)(struct goalrec*)&allocp[15];
  allocp[21] = (q)(&predicate_type_xadd__i__goal_3);
  allocp[22] = x2;
  allocp[23] = a1;
  allocp[24] = x6 = makeref(&allocp[24]);
  qp = (struct goalrec*)&allocp[20];
  allocp += 25;
  proceed();
 case VARREF:
  deref_and_jump(a0,update__type__new__vector2_4_1);
  *reasonp++ =  a0;
  goto update__type__new__vector2_4_interrupt;
  };
  goto update__type__new__vector2_4_interrupt;
 update__type__new__vector2_4_ext_interrupt:
  reasonp = 0l;
 update__type__new__vector2_4_interrupt:
  goto interrupt_4;
 }

 update__type__new__vector2_5_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 update__type__new__vector2_5_clear_reason:
  reasonp = reasons;
 update__type__new__vector2_5_0:
 update__type__new__vector2_5_1:
  if (!isint(a0)) goto update__type__new__vector2_5_2;
  gblt_integer(a0,update__type__new__vector2_5_interrupt);
  allocp[0] = makesym(functor_s_3);
  allocp[1] = makesym(atom___v);
  allocp[2] = a0;
  allocp[3] = x1 = makeref(&allocp[3]);
  x0 = makefunctor(&allocp[0]);
  allocp[4] = NILATOM;
  allocp[5] = a4;
  x2 = makecons(&allocp[4]);
  allocp[6] = NILATOM;
  allocp[7] = a4;
  x3 = makecons(&allocp[6]);
  allocp[8] = makesym(functor_t_4);
  allocp[9] = x0;
  allocp[10] = x2;
  allocp[11] = x3;
  allocp[12] = makesym(atom_u);
  x4 = makefunctor(&allocp[8]);
  allocp[13] = NILATOM;
  allocp[14] = x4;
  x5 = makecons(&allocp[13]);
  allocp[15] = (q)qp;
  allocp[16] = (q)(&predicate_type_xor__types_3);
  allocp[17] = a2;
  allocp[18] = x5;
  allocp[19] = a3;
  allocp[20] = (q)(struct goalrec*)&allocp[15];
  allocp[21] = (q)(&predicate_uty_xcreate__functor_3);
  allocp[22] = makesym(atom_arg);
  allocp[23] = x6 = makeref(&allocp[23]);
  allocp[24] = x1;
  a0 = a1;
  a1 = a4;
  a2 = x6;
  qp = (struct goalrec*)&allocp[20];
  allocp += 25;
  execute(update__type__new__vector3_3_0);
  goto update__type__new__vector3_3_ext_interrupt;
 update__type__new__vector2_5_2:
  if (!isref(a0)) goto update__type__new__vector2_5_interrupt;
  deref_and_jump(a0,update__type__new__vector2_5_1);
  *reasonp++ =  a0;
  goto update__type__new__vector2_5_interrupt;
 update__type__new__vector2_5_ext_interrupt:
  reasonp = 0l;
 update__type__new__vector2_5_interrupt:
  goto interrupt_5;
 }

 update__type__new__vector3_3_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  qp = qp->next;
 update__type__new__vector3_3_clear_reason:
  reasonp = reasons;
 update__type__new__vector3_3_0:
 update__type__new__vector3_3_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin__type_xupdate__type__new__vector3_3);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = a1;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = x1;
  allocp[6] = x3 = makeref(&allocp[6]);
  x2 = makecons(&allocp[5]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  unify_value(a2, x2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xadd__i__goal_3);
  allocp[2] = a1;
  x4 = car_of(a0);
  allocp[3] = x4;
  allocp[4] = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case ATOMIC:
  if (a0 != NILATOM) goto update__type__new__vector3_3_interrupt;
  unify_value(a2, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a0,update__type__new__vector3_3_1);
  *reasonp++ =  a0;
  goto update__type__new__vector3_3_interrupt;
  };
  goto update__type__new__vector3_3_interrupt;
 update__type__new__vector3_3_ext_interrupt:
  reasonp = 0l;
 update__type__new__vector3_3_interrupt:
  toppred = &predicate_builtin__type_xupdate__type__new__vector3_3;
  goto interrupt_3;
 }

 update__type__element_4_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 update__type__element_4_clear_reason:
  reasonp = reasons;
 update__type__element_4_0:
 update__type__element_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom__3F)) goto update__type__element_4_2;
  unify_value(a2, makecons(cons_const_0));
  proceed();
 case VARREF:
  deref_and_jump(a0,update__type__element_4_1);
  *reasonp++ =  a0;
  goto update__type__element_4_2;
  };
  goto update__type__element_4_2;
 update__type__element_4_2:
 update__type__element_4_3:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 update__type__element_4_4:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__3F)) goto update__type__element_4_6;
  x1 = cdr_of(a1);
 update__type__element_4_5:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto update__type__element_4_6;
  unify_value(a2, makecons(cons_const_0));
  proceed();
 case VARREF:
  deref_and_jump(x1,update__type__element_4_5);
  *reasonp++ =  x1;
  goto update__type__element_4_6;
  };
  goto update__type__element_4_6;
 case VARREF:
  deref_and_jump(x0,update__type__element_4_4);
  *reasonp++ =  x0;
  goto update__type__element_4_6;
  };
  goto update__type__element_4_6;
 case VARREF:
  deref_and_jump(a1,update__type__element_4_3);
  *reasonp++ =  a1;
  goto update__type__element_4_6;
  };
  goto update__type__element_4_6;
 update__type__element_4_6:
  otherwise(update__type__element_4_interrupt);
 update__type__element_4_7:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 update__type__element_4_8:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__3F)) goto update__type__element_4_9;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xor__types_3);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = makecons(cons_const_0);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_type_xadd__dep__goal_3);
  allocp[7] = a3;
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = x1;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_type_xadd__i__goal_3);
  allocp[12] = a3;
  allocp[13] = x3 = makeref(&allocp[13]);
  allocp[14] = x2;
  allocp[15] = x4 = makeref(&allocp[15]);
  a1 = x4;
  a2 = NILATOM;
  a3 = x3;
  qp = (struct goalrec*)&allocp[10];
  allocp += 16;
  execute(update__type__element1_4_0);
  goto update__type__element1_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,update__type__element_4_8);
  *reasonp++ =  x0;
  goto update__type__element_4_9;
  };
  goto update__type__element_4_9;
 case VARREF:
  deref_and_jump(a1,update__type__element_4_7);
  *reasonp++ =  a1;
  goto update__type__element_4_9;
  };
  goto update__type__element_4_9;
 update__type__element_4_9:
  otherwise(update__type__element_4_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xadd__dep__goal_3);
  allocp[2] = a3;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_type_xadd__i__goal_3);
  allocp[7] = a3;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x0;
  a2 = NILATOM;
  a3 = x1;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  execute(update__type__element1_4_0);
  goto update__type__element1_4_ext_interrupt;
 update__type__element_4_ext_interrupt:
  reasonp = 0l;
 update__type__element_4_interrupt:
  goto interrupt_4;
 }

 update__type__element1_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 update__type__element1_4_clear_reason:
  reasonp = reasons;
 update__type__element1_4_0:
 update__type__element1_4_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 update__type__element1_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_4)) goto update__type__element1_4_5;
  x1 = arg(x0, 0);
 update__type__element1_4_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_s_3)) goto update__type__element1_4_5;
  x2 = arg(x1, 1);
 update__type__element1_4_4:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != makesym(atom_n)) goto update__type__element1_4_5;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin__type_xupdate__type__element1_4);
  allocp[2] = a0;
  x3 = cdr_of(a1);
  allocp[3] = x3;
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_type_xor__types_3);
  allocp[8] = a2;
  x5 = arg(x1, 2);
  allocp[9] = x5;
  allocp[10] = x4;
  qp = (struct goalrec*)&allocp[6];
  allocp += 11;
  proceed();
 case VARREF:
  deref_and_jump(x2,update__type__element1_4_4);
  *reasonp++ =  x2;
  goto update__type__element1_4_5;
  };
  goto update__type__element1_4_5;
 case VARREF:
  deref_and_jump(x1,update__type__element1_4_3);
  *reasonp++ =  x1;
  goto update__type__element1_4_5;
  };
  goto update__type__element1_4_5;
 case VARREF:
  deref_and_jump(x0,update__type__element1_4_2);
  *reasonp++ =  x0;
  goto update__type__element1_4_5;
  };
  goto update__type__element1_4_5;
 case VARREF:
  deref_and_jump(a1,update__type__element1_4_1);
  *reasonp++ =  a1;
  goto update__type__element1_4_5;
  };
  goto update__type__element1_4_5;
 update__type__element1_4_5:
  otherwise(update__type__element1_4_interrupt);
 update__type__element1_4_6:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 update__type__element1_4_7:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_4)) goto update__type__element1_4_10;
  x1 = arg(x0, 0);
 update__type__element1_4_8:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_s_3)) goto update__type__element1_4_10;
 update__type__element1_4_9:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_i_1)) goto update__type__element1_4_10;
  x2 = arg(a0, 0);
  bblt_add_no_check_y(x2,makeint(1L),x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin__type_xupdate__type__element1_4);
  allocp[2] = a0;
  x4 = cdr_of(a1);
  allocp[3] = x4;
  allocp[4] = x5 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_type_xor__types_3);
  allocp[8] = a2;
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = x5;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_functor__table_xarg_3);
  allocp[13] = x3;
  x7 = arg(x1, 2);
  allocp[14] = x7;
  allocp[15] = x6;
  qp = (struct goalrec*)&allocp[11];
  allocp += 16;
  proceed();
 case VARREF:
  deref_and_jump(a0,update__type__element1_4_9);
  *reasonp++ =  a0;
  goto update__type__element1_4_10;
  };
  goto update__type__element1_4_10;
 case VARREF:
  deref_and_jump(x1,update__type__element1_4_8);
  *reasonp++ =  x1;
  goto update__type__element1_4_10;
  };
  goto update__type__element1_4_10;
 case VARREF:
  deref_and_jump(x0,update__type__element1_4_7);
  *reasonp++ =  x0;
  goto update__type__element1_4_10;
  };
  goto update__type__element1_4_10;
 case VARREF:
  deref_and_jump(a1,update__type__element1_4_6);
  *reasonp++ =  a1;
  goto update__type__element1_4_10;
  };
  goto update__type__element1_4_10;
 update__type__element1_4_10:
  otherwise(update__type__element1_4_interrupt);
 update__type__element1_4_11:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 update__type__element1_4_12:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_4)) goto update__type__element1_4_14;
  x1 = arg(x0, 0);
 update__type__element1_4_13:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_s_3)) goto update__type__element1_4_14;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin__type_xupdate__type__element1_4);
  allocp[2] = a0;
  x2 = cdr_of(a1);
  allocp[3] = x2;
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = a3;
  a0 = arg(x1, 1);
  a1 = arg(x1, 2);
  a3 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(update__type__element__merge_4_0);
  goto update__type__element__merge_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,update__type__element1_4_13);
  *reasonp++ =  x1;
  goto update__type__element1_4_14;
  };
  goto update__type__element1_4_14;
 case VARREF:
  deref_and_jump(x0,update__type__element1_4_12);
  *reasonp++ =  x0;
  goto update__type__element1_4_14;
  };
  goto update__type__element1_4_14;
 case VARREF:
  deref_and_jump(a1,update__type__element1_4_11);
  *reasonp++ =  a1;
  goto update__type__element1_4_14;
  };
  goto update__type__element1_4_14;
 update__type__element1_4_14:
  otherwise(update__type__element1_4_interrupt);
 update__type__element1_4_15:
  switch (ptagof(a1)) {
 case CONS:
  a1 = cdr_of(a1);
  execute(update__type__element1_4_0);
  goto update__type__element1_4_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto update__type__element1_4_interrupt;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a1,update__type__element1_4_15);
  *reasonp++ =  a1;
  goto update__type__element1_4_interrupt;
  };
  goto update__type__element1_4_interrupt;
 update__type__element1_4_ext_interrupt:
  reasonp = 0l;
 update__type__element1_4_interrupt:
  toppred = &predicate_builtin__type_xupdate__type__element1_4;
  goto interrupt_4;
 }

 update__type__element__merge_4_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 update__type__element__merge_4_clear_reason:
  reasonp = reasons;
 update__type__element__merge_4_0:
 update__type__element__merge_4_1:
  if (!isint(a0)) goto update__type__element__merge_4_3;
  gblt_greater(a0,makeint(0L),update__type__element__merge_4_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin__type_xupdate__type__element__merge_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x0;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_type_xor__types_3);
  allocp[13] = a2;
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_functor__table_xarg_3);
  allocp[18] = a0;
  allocp[19] = a1;
  allocp[20] = x2;
  qp = (struct goalrec*)&allocp[16];
  allocp += 21;
  proceed();
 update__type__element__merge_4_2:
  if (a0 != makeint(0L)) goto update__type__element__merge_4_interrupt;
  unify(a3, a2);
  proceed();
 update__type__element__merge_4_3:
  if (!isref(a0)) goto update__type__element__merge_4_interrupt;
  deref_and_jump(a0,update__type__element__merge_4_1);
  *reasonp++ =  a0;
  goto update__type__element__merge_4_interrupt;
 update__type__element__merge_4_ext_interrupt:
  reasonp = 0l;
 update__type__element__merge_4_interrupt:
  toppred = &predicate_builtin__type_xupdate__type__element__merge_4;
  goto interrupt_4;
 }
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_builtin__type);
}
