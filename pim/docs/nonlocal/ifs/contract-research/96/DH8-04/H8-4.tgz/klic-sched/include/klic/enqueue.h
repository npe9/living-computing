/* ----------------------------------------------------------
%        Copyright (C) 1996-1997 Kazuhiko Ohno, Masahiko Ikawa,
%        and Computer Architecture Laboratory, Depertment of
%        Information Science, Kyoto University.
%----------------------------------------------------------- */  

#define enqueue_normal_thread(top,ntop,newthread) \
{ \
	newthread->next = ntop; \
	newthread->before = ntop->before; \
	ntop->before = newthread->before->next = newthread; \
	ntop = newthread; \
}

#define enqueue_top_thread(top,ntop,newthread) \
{ \
		newthread->next = top; \
		top->before = newthread; \
}
