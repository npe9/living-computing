/* Compiled by KLIC compiler version 2.002 (1997ǯ05��10�� (��) 19��58ʬ16�� JST) */
#include <klic/klichdr.h>
#include <klic/sched.h>
#include "atom.h"
#include "funct.h"

module module_comparator();
Const struct predicate predicate_comparator_xsort_5 =
   { module_comparator, 0, 5 };
Const struct predicate predicate_comparator_xresume__check_0 =
   { module_comparator, 1, 0 };

module module_comparator(glbl, qp, allocp, toppred, stackp)
  struct global_variables *glbl;
  struct threadrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
  register q* stackp;
{
  q a0, a1, a2, a3, a4;

  q *reasonp;
 module_top:
  switch_on_pred() {
    case_pred(0, sort_5_top);
    last_case_pred(1, resume__check_0_top);
  }

 sort_5_top: {
  q x0;
  stackp -= 5;
  a0 = stackp[0];
  a1 = stackp[1];
  a2 = stackp[2];
  a3 = stackp[3];
  a4 = stackp[4];
 sort_5_clear_reason:
  reasonp = reasons;
 sort_5_0:
 sort_5_1:
  if (isref(a0)) goto sort_5_5;
 sort_5_2:
  if (isref(a1)) goto sort_5_4;
  gblt_compare(a0,a1,x0,sort_5_interrupt);
  gblt_less_or_eq(x0,makeint(0L),sort_5_3);
  unify_value(a4, makesym(atom_no));
  unify_value(a2, a0);
  unify_value(a3, a1);
  proceed();
 sort_5_3:
  gblt_greater(x0,makeint(0L),sort_5_interrupt);
  unify_value(a4, makesym(atom_yes));
  unify_value(a2, a1);
  unify_value(a3, a0);
  proceed();
 sort_5_4:
  deref_and_jump_of_lvalue(a1,sort_5_2);
  *reasonp++ =  a1;
  goto sort_5_interrupt;
 sort_5_5:
  deref_and_jump_of_lvalue(a0,sort_5_1);
  *reasonp++ =  a0;
  goto sort_5_interrupt;
 sort_5_ext_interrupt:
  reasonp = 0l;
 sort_5_interrupt:
  toppred = &predicate_comparator_xsort_5;
  goto interrupt_5;
 }

 resume__check_0_top: {
		resume_check();
  }
 interrupt_5:
 stackp[4] = a4;
 interrupt_4:
 stackp[3] = a3;
 interrupt_3:
 stackp[2] = a2;
 interrupt_2:
 stackp[1] = a1;
 interrupt_1:
 stackp[0] = a0;
  interrupt_0:
  interrupt_check();
  loop_within_module(module_comparator);
}
