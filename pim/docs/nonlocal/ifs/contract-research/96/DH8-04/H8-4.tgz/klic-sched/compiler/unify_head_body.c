/* Compiled by KLIC compiler version 2.002 (Tue May 23 13:27:38 JST 1995) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_unify__head__body();
Const struct predicate predicate_unify__head__body_xmake__head__body__list_2 =
   { module_unify__head__body, 0, 2 };
Const struct predicate predicate_unify__head__body_xmake__modules_2 =
   { module_unify__head__body, 1, 2 };
Const struct predicate predicate_unify__head__body_xmake__clauses_5 =
   { module_unify__head__body, 2, 5 };
Const struct predicate predicate_unify__head__body_xmake__clauses__headlist_9 =
   { module_unify__head__body, 3, 9 };
Const struct predicate predicate_unify__head__body_xmake__clauses__headlist__args_7 =
   { module_unify__head__body, 4, 7 };
Const struct predicate predicate_unify__head__body_xcheck__body__modules_3 =
   { module_unify__head__body, 5, 3 };
Const struct predicate predicate_unify__head__body_xcheck__body__clauses_4 =
   { module_unify__head__body, 6, 4 };
Const struct predicate predicate_unify__head__body_xcheck__body__search__modules_6 =
   { module_unify__head__body, 7, 6 };
Const struct predicate predicate_unify__head__body_xcheck__body__search__clauses_9 =
   { module_unify__head__body, 8, 9 };
Const struct predicate predicate_unify__head__body_xcheck__body__search__bodys_10 =
   { module_unify__head__body, 9, 10 };
Const struct predicate predicate_unify__head__body_xcheck__body__search__body_10 =
   { module_unify__head__body, 10, 10 };
Const struct predicate predicate_unify__head__body_xcheck__body__search__body1_11 =
   { module_unify__head__body, 11, 11 };
Const struct predicate predicate_unify__head__body_xcheck__body__bodylist__args_9 =
   { module_unify__head__body, 12, 9 };
Const struct predicate predicate_unify__head__body_xapply__direct__value_7 =
   { module_unify__head__body, 13, 7 };
Const struct predicate predicate_unify__head__body_xapply__direct__value__clauses_7 =
   { module_unify__head__body, 14, 7 };
Const struct predicate predicate_unify__head__body_xapply__direct__value__clause_10 =
   { module_unify__head__body, 15, 10 };
Const struct predicate predicate_unify__head__body_xapply__direct__value__head_9 =
   { module_unify__head__body, 16, 9 };
Const struct predicate predicate_unify__head__body_xset__head__mode_4 =
   { module_unify__head__body, 17, 4 };
Const struct predicate predicate_unify__head__body_xset__head__mode__modules_6 =
   { module_unify__head__body, 18, 6 };
Const struct predicate predicate_unify__head__body_xset__head__mode__clauses_5 =
   { module_unify__head__body, 19, 5 };
Const struct predicate predicate_unify__head__body_xset__head__mode__clauses1_7 =
   { module_unify__head__body, 20, 7 };
Const struct predicate predicate_unify__head__body_xset__head__type_6 =
   { module_unify__head__body, 21, 6 };
Const struct predicate predicate_unify__head__body_xget__types_17 =
   { module_unify__head__body, 22, 17 };
Const struct predicate predicate_unify__head__body_xget__types__namelist_17 =
   { module_unify__head__body, 23, 17 };
Const struct predicate predicate_unify__head__body_xget__types__body_15 =
   { module_unify__head__body, 24, 15 };
Const struct predicate predicate_unify__head__body_xexpand__looped__goal_15 =
   { module_unify__head__body, 25, 15 };
Const struct predicate predicate_unify__head__body_xget__types__head_15 =
   { module_unify__head__body, 26, 15 };
Const struct predicate predicate_unify__head__body_xcheck__only__vars_2 =
   { module_unify__head__body, 27, 2 };
Const struct predicate predicate_unify__head__body_xcheck__only__vars1_3 =
   { module_unify__head__body, 28, 3 };
Const struct predicate predicate_unify__head__body_xmake__direct__type_2 =
   { module_unify__head__body, 29, 2 };
Const struct predicate predicate_unify__head__body_xmake__direct__type1_3 =
   { module_unify__head__body, 30, 3 };
Const struct predicate predicate_unify__head__body_xcheck__shared_4 =
   { module_unify__head__body, 31, 4 };
Const struct predicate predicate_unify__head__body_xcheck__shared__hbs_4 =
   { module_unify__head__body, 32, 4 };
Const struct predicate predicate_unify__head__body_xcheck__shared__bodys_4 =
   { module_unify__head__body, 33, 4 };
Const struct predicate predicate_unify__head__body_xcheck__shared__bodys1_4 =
   { module_unify__head__body, 34, 4 };
Const struct predicate predicate_unify__head__body_xcheck__shared__bodys2_5 =
   { module_unify__head__body, 35, 5 };
Const struct predicate predicate_unify__head__body_xcheck__shared__bodys3_5 =
   { module_unify__head__body, 36, 5 };
Const struct predicate predicate_unify__head__body_xadd__shared_7 =
   { module_unify__head__body, 37, 7 };
extern Const struct predicate predicate_list_xappend_3;
extern Const struct predicate predicate_functor_xget__arg__pos_3;
extern Const struct predicate predicate_mode_xset__arg__mode_6;
extern Const struct predicate predicate_integer__arithmetics_xadd_3;
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_functor__table_xfunctor_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_xsetarg_4;
extern Const struct predicate predicate_uty_xnew__functor__init_4;
extern Const struct predicate predicate_parse__uty_xdecode__goalcall_6;
extern Const struct predicate predicate_parse__uty_xget__goal_6;
extern Const struct predicate predicate_parse__uty_xdecode__goal_3;
extern Const struct predicate predicate_parse__uty_xencode__goal_3;
extern Const struct predicate predicate_parse__uty_xupdate__goal_7;
extern Const struct predicate predicate_type_xset__types_11;
extern Const struct predicate predicate_type_xget__types_5;
extern Const struct predicate predicate_type_xor__types_3;
extern Const struct predicate predicate_type_xvalue2types_7;
extern Const struct predicate predicate_type_xmake__type__loopdown_16;

module module_unify__head__body(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  static Const q cons_const_0[] = {
    NILATOM,
    makesym(atom__3F),
  };
  static Const q funct_const_1[] = {
    makesym(functor_atom_1),
    makesym(atom_shared),
  };
  q a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, make__head__body__list_2_top);
    case_pred(1, make__modules_2_top);
    case_pred(2, make__clauses_5_top);
    case_pred(3, make__clauses__headlist_9_top);
    case_pred(4, make__clauses__headlist__args_7_top);
    case_pred(5, check__body__modules_3_top);
    case_pred(6, check__body__clauses_4_top);
    case_pred(7, check__body__search__modules_6_top);
    case_pred(8, check__body__search__clauses_9_top);
    case_pred(9, check__body__search__bodys_10_top);
    case_pred(10, check__body__search__body_10_top);
    case_pred(11, check__body__search__body1_11_top);
    case_pred(12, check__body__bodylist__args_9_top);
    case_pred(13, apply__direct__value_7_top);
    case_pred(14, apply__direct__value__clauses_7_top);
    case_pred(15, apply__direct__value__clause_10_top);
    case_pred(16, apply__direct__value__head_9_top);
    case_pred(17, set__head__mode_4_top);
    case_pred(18, set__head__mode__modules_6_top);
    case_pred(19, set__head__mode__clauses_5_top);
    case_pred(20, set__head__mode__clauses1_7_top);
    case_pred(21, set__head__type_6_top);
    case_pred(22, get__types_17_top);
    case_pred(23, get__types__namelist_17_top);
    case_pred(24, get__types__body_15_top);
    case_pred(25, expand__looped__goal_15_top);
    case_pred(26, get__types__head_15_top);
    case_pred(27, check__only__vars_2_top);
    case_pred(28, check__only__vars1_3_top);
    case_pred(29, make__direct__type_2_top);
    case_pred(30, make__direct__type1_3_top);
    case_pred(31, check__shared_4_top);
    case_pred(32, check__shared__hbs_4_top);
    case_pred(33, check__shared__bodys_4_top);
    case_pred(34, check__shared__bodys1_4_top);
    case_pred(35, check__shared__bodys2_5_top);
    case_pred(36, check__shared__bodys3_5_top);
    last_case_pred(37, add__shared_7_top);
  }

 make__head__body__list_2_top: {
  q x0;
  qp = qp->next;
 make__head__body__list_2_clear_reason:
  reasonp = reasons;
 make__head__body__list_2_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xcheck__body__modules_3);
  allocp[2] = a0;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a1;
  a1 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(make__modules_2_0);
  goto make__modules_2_ext_interrupt;
 make__head__body__list_2_ext_interrupt:
  reasonp = 0l;
 make__head__body__list_2_interrupt:
  goto interrupt_2;
 }

 make__modules_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  qp = qp->next;
 make__modules_2_clear_reason:
  reasonp = reasons;
 make__modules_2_0:
 make__modules_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 make__modules_2_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto make__modules_2_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xmake__modules_2);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = makesym(functor_module_2);
  allocp[5] = arg(x0, 0);
  allocp[6] = x4 = makeref(&allocp[6]);
  x3 = makefunctor(&allocp[4]);
  allocp[7] = x2;
  allocp[8] = x3;
  x5 = makecons(&allocp[7]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 9;
  unify_value(a1, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xmake__clauses_5);
  allocp[2] = makeint(1L);
  allocp[3] = x6 = makeref(&allocp[3]);
  x7 = arg(x0, 0);
  allocp[4] = x7;
  x8 = arg(x0, 1);
  allocp[5] = x8;
  allocp[6] = x4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[9] = x8;
  allocp[10] = x9 = makeref(&allocp[10]);
  allocp[11] = x6;
  qp = (struct goalrec*)&allocp[7];
  allocp += 12;
  proceed();
 case VARREF:
  deref_and_jump(x0,make__modules_2_2);
  *reasonp++ =  x0;
  goto make__modules_2_interrupt;
  };
  goto make__modules_2_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto make__modules_2_interrupt;
  unify_value(a1, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a0,make__modules_2_1);
  *reasonp++ =  a0;
  goto make__modules_2_interrupt;
  };
  goto make__modules_2_interrupt;
 make__modules_2_ext_interrupt:
  reasonp = 0l;
 make__modules_2_interrupt:
  toppred = &predicate_unify__head__body_xmake__modules_2;
  goto interrupt_2;
 }

 make__clauses_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 make__clauses_5_clear_reason:
  reasonp = reasons;
 make__clauses_5_0:
 make__clauses_5_1:
  if (!isint(a0)) goto make__clauses_5_8;
 make__clauses_5_2:
  if (!isint(a1)) goto make__clauses_5_7;
  gblt_less_or_eq(a0,a1,make__clauses_5_interrupt);
 make__clauses_5_3:
  if (isref(a3)) goto make__clauses_5_6;
  gblt_arg(a0,a3,x0,make__clauses_5_interrupt);
 make__clauses_5_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_clause_6)) goto make__clauses_5_interrupt;
  x1 = arg(x0, 0);
 make__clauses_5_5:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_functor_1)) goto make__clauses_5_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xmake__clauses__headlist_9);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = x5 = makeref(&allocp[9]);
  allocp[10] = x6 = makeref(&allocp[10]);
  allocp[11] = makesym(functor_goal_4);
  allocp[12] = x2;
  allocp[13] = x3;
  allocp[14] = x5;
  allocp[15] = x8 = makeref(&allocp[15]);
  x7 = makefunctor(&allocp[11]);
  allocp[16] = x6;
  allocp[17] = x7;
  x9 = makecons(&allocp[16]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 18;
  unify_value(a4, x9);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_uty_xnew__functor__init_4);
  allocp[2] = makesym(atom_bodyargs);
  allocp[3] = x3;
  allocp[4] = NILATOM;
  allocp[5] = x8;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_uty_xnew__functor__init_4);
  allocp[8] = makesym(atom_headargs);
  allocp[9] = x3;
  allocp[10] = NILATOM;
  allocp[11] = x4;
  allocp[12] = (q)(struct goalrec*)&allocp[6];
  allocp[13] = (q)(&predicate_functor__table_xfunctor_3);
  x10 = arg(x1, 0);
  allocp[14] = x10;
  allocp[15] = x2;
  allocp[16] = x3;
  qp = (struct goalrec*)&allocp[12];
  allocp += 17;
  proceed();
 case VARREF:
  deref_and_jump(x1,make__clauses_5_5);
  *reasonp++ =  x1;
  goto make__clauses_5_interrupt;
  };
  goto make__clauses_5_interrupt;
 case VARREF:
  deref_and_jump(x0,make__clauses_5_4);
  *reasonp++ =  x0;
  goto make__clauses_5_interrupt;
  };
  goto make__clauses_5_interrupt;
 make__clauses_5_6:
  deref_and_jump(a3,make__clauses_5_3);
  *reasonp++ =  a3;
  goto make__clauses_5_interrupt;
 make__clauses_5_7:
  if (!isref(a1)) goto make__clauses_5_interrupt;
  deref_and_jump(a1,make__clauses_5_2);
  *reasonp++ =  a1;
  goto make__clauses_5_interrupt;
 make__clauses_5_8:
  if (!isref(a0)) goto make__clauses_5_interrupt;
  deref_and_jump(a0,make__clauses_5_1);
  *reasonp++ =  a0;
  goto make__clauses_5_interrupt;
 make__clauses_5_ext_interrupt:
  reasonp = 0l;
 make__clauses_5_interrupt:
  toppred = &predicate_unify__head__body_xmake__clauses_5;
  goto interrupt_5;
 }

 make__clauses__headlist_9_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 make__clauses__headlist_9_clear_reason:
  reasonp = reasons;
 make__clauses__headlist_9_0:
 make__clauses__headlist_9_1:
  if (!isint(a0)) goto make__clauses__headlist_9_18;
 make__clauses__headlist_9_2:
  if (!isint(a1)) goto make__clauses__headlist_9_17;
  gblt_less_or_eq(a0,a1,make__clauses__headlist_9_19);
 make__clauses__headlist_9_3:
  if (isref(a3)) goto make__clauses__headlist_9_16;
  gblt_arg(a0,a3,x0,make__clauses__headlist_9_19);
 make__clauses__headlist_9_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_clause_6)) goto make__clauses__headlist_9_19;
  x1 = arg(x0, 0);
 make__clauses__headlist_9_5:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_functor_1)) goto make__clauses__headlist_9_19;
  x2 = arg(x1, 0);
 make__clauses__headlist_9_6:
  if (isref(x2)) goto make__clauses__headlist_9_15;
  gblt_pfunctor(x2,x3,make__clauses__headlist_9_19);
 make__clauses__headlist_9_7:
  if (isref(x3)) goto make__clauses__headlist_9_14;
 make__clauses__headlist_9_8:
  if (isref(x3)) goto make__clauses__headlist_9_13;
  if_not_equal(x3, a4, make__clauses__headlist_9_19);
  gblt_arity(x2,x4,make__clauses__headlist_9_19);
 make__clauses__headlist_9_9:
  if (isref(x4)) goto make__clauses__headlist_9_12;
 make__clauses__headlist_9_10:
  if (isref(x4)) goto make__clauses__headlist_9_11;
  if_not_equal(x4, a5, make__clauses__headlist_9_19);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xmake__clauses__headlist_9);
  allocp[2] = x5 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = x6 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x5;
  a1 = a5;
  a3 = a0;
  a4 = a2;
  a5 = a6;
  a6 = x6;
  a2 = x2;
  a0 = makeint(1L);
  qp = (struct goalrec*)&allocp[11];
  allocp += 16;
  execute(make__clauses__headlist__args_7_clear_reason);
  goto make__clauses__headlist__args_7_ext_interrupt;
 make__clauses__headlist_9_11:
  deref_and_jump(x4,make__clauses__headlist_9_10);
  *reasonp++ =  x4;
  goto make__clauses__headlist_9_19;
 make__clauses__headlist_9_12:
  deref_and_jump(x4,make__clauses__headlist_9_9);
  *reasonp++ =  x4;
  goto make__clauses__headlist_9_19;
 make__clauses__headlist_9_13:
  deref_and_jump(x3,make__clauses__headlist_9_8);
  *reasonp++ =  x3;
  goto make__clauses__headlist_9_19;
 make__clauses__headlist_9_14:
  deref_and_jump(x3,make__clauses__headlist_9_7);
  *reasonp++ =  x3;
  goto make__clauses__headlist_9_19;
 make__clauses__headlist_9_15:
  deref_and_jump(x2,make__clauses__headlist_9_6);
  *reasonp++ =  x2;
  goto make__clauses__headlist_9_19;
 case VARREF:
  deref_and_jump(x1,make__clauses__headlist_9_5);
  *reasonp++ =  x1;
  goto make__clauses__headlist_9_19;
  };
  goto make__clauses__headlist_9_19;
 case VARREF:
  deref_and_jump(x0,make__clauses__headlist_9_4);
  *reasonp++ =  x0;
  goto make__clauses__headlist_9_19;
  };
  goto make__clauses__headlist_9_19;
 make__clauses__headlist_9_16:
  deref_and_jump(a3,make__clauses__headlist_9_3);
  *reasonp++ =  a3;
  goto make__clauses__headlist_9_19;
 make__clauses__headlist_9_17:
  if (!isref(a1)) goto make__clauses__headlist_9_19;
  deref_and_jump(a1,make__clauses__headlist_9_2);
  *reasonp++ =  a1;
  goto make__clauses__headlist_9_19;
 make__clauses__headlist_9_18:
  if (!isref(a0)) goto make__clauses__headlist_9_19;
  deref_and_jump(a0,make__clauses__headlist_9_1);
  *reasonp++ =  a0;
  goto make__clauses__headlist_9_19;
 make__clauses__headlist_9_19:
  otherwise(make__clauses__headlist_9_interrupt);
 make__clauses__headlist_9_20:
  if (!isint(a0)) goto make__clauses__headlist_9_27;
 make__clauses__headlist_9_21:
  if (!isint(a1)) goto make__clauses__headlist_9_26;
  gblt_less_or_eq(a0,a1,make__clauses__headlist_9_28);
 make__clauses__headlist_9_22:
  if (isref(a3)) goto make__clauses__headlist_9_25;
  gblt_arg(a0,a3,x0,make__clauses__headlist_9_28);
 make__clauses__headlist_9_23:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (isint(x0)) goto make__clauses__headlist_9_28;
 make__clauses__headlist_9_24:
  gblt_atom(x0,make__clauses__headlist_9_28);
  bblt_add_no_check(a0,makeint(1L),x1);
  a0 = x1;
  execute(make__clauses__headlist_9_0);
  goto make__clauses__headlist_9_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,make__clauses__headlist_9_23);
  *reasonp++ =  x0;
  goto make__clauses__headlist_9_28;
  };
  goto make__clauses__headlist_9_28;
 make__clauses__headlist_9_25:
  deref_and_jump(a3,make__clauses__headlist_9_22);
  *reasonp++ =  a3;
  goto make__clauses__headlist_9_28;
 make__clauses__headlist_9_26:
  if (!isref(a1)) goto make__clauses__headlist_9_28;
  deref_and_jump(a1,make__clauses__headlist_9_21);
  *reasonp++ =  a1;
  goto make__clauses__headlist_9_28;
 make__clauses__headlist_9_27:
  if (!isref(a0)) goto make__clauses__headlist_9_28;
  deref_and_jump(a0,make__clauses__headlist_9_20);
  *reasonp++ =  a0;
  goto make__clauses__headlist_9_28;
 make__clauses__headlist_9_28:
  otherwise(make__clauses__headlist_9_interrupt);
 make__clauses__headlist_9_29:
  if (!isint(a0)) goto make__clauses__headlist_9_33;
 make__clauses__headlist_9_30:
  if (!isint(a1)) goto make__clauses__headlist_9_32;
  gblt_less_or_eq(a0,a1,make__clauses__headlist_9_31);
  unify(a7, a6);
  a4 = a8;
  execute(make__clauses_5_0);
  goto make__clauses_5_ext_interrupt;
 make__clauses__headlist_9_31:
  gblt_greater(a0,a1,make__clauses__headlist_9_interrupt);
  unify(a7, a6);
  unify_value(a8, NILATOM);
  proceed();
 make__clauses__headlist_9_32:
  if (!isref(a1)) goto make__clauses__headlist_9_interrupt;
  deref_and_jump(a1,make__clauses__headlist_9_30);
  *reasonp++ =  a1;
  goto make__clauses__headlist_9_interrupt;
 make__clauses__headlist_9_33:
  if (!isref(a0)) goto make__clauses__headlist_9_interrupt;
  deref_and_jump(a0,make__clauses__headlist_9_29);
  *reasonp++ =  a0;
  goto make__clauses__headlist_9_interrupt;
 make__clauses__headlist_9_ext_interrupt:
  reasonp = 0l;
 make__clauses__headlist_9_interrupt:
  goto interrupt_9;
 }

 make__clauses__headlist__args_7_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 make__clauses__headlist__args_7_clear_reason:
  reasonp = reasons;
 make__clauses__headlist__args_7_0:
 make__clauses__headlist__args_7_1:
  if (!isint(a0)) goto make__clauses__headlist__args_7_5;
 make__clauses__headlist__args_7_2:
  if (!isint(a1)) goto make__clauses__headlist__args_7_4;
  gblt_less_or_eq(a0,a1,make__clauses__headlist__args_7_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xmake__clauses__headlist__args_7);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[11] = a0;
  allocp[12] = makeint(1L);
  allocp[13] = x0;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[16] = a0;
  allocp[17] = a5;
  allocp[18] = x2 = makeref(&allocp[18]);
  allocp[19] = x1;
  allocp[20] = makesym(functor_arg_5);
  allocp[21] = a4;
  allocp[22] = a3;
  allocp[23] = makesym(atom_head);
  allocp[24] = makeint(1L);
  allocp[25] = x4 = makeref(&allocp[25]);
  x3 = makefunctor(&allocp[20]);
  allocp[26] = NILATOM;
  allocp[27] = x3;
  x5 = makecons(&allocp[26]);
  allocp[28] = (q)(struct goalrec*)&allocp[14];
  allocp[29] = (q)(&predicate_list_xappend_3);
  allocp[30] = x6 = makeref(&allocp[30]);
  allocp[31] = x5;
  allocp[32] = x2;
  allocp[33] = (q)(struct goalrec*)&allocp[28];
  allocp[34] = (q)(&predicate_functor__table_xarg_3);
  allocp[35] = a0;
  allocp[36] = a5;
  allocp[37] = x6;
  allocp[38] = (q)(struct goalrec*)&allocp[33];
  allocp[39] = (q)(&predicate_functor__table_xarg_3);
  allocp[40] = a0;
  allocp[41] = a2;
  allocp[42] = x4;
  qp = (struct goalrec*)&allocp[38];
  allocp += 43;
  proceed();
 make__clauses__headlist__args_7_3:
  gblt_greater(a0,a1,make__clauses__headlist__args_7_interrupt);
  unify(a6, a5);
  proceed();
 make__clauses__headlist__args_7_4:
  if (!isref(a1)) goto make__clauses__headlist__args_7_interrupt;
  deref_and_jump(a1,make__clauses__headlist__args_7_2);
  *reasonp++ =  a1;
  goto make__clauses__headlist__args_7_interrupt;
 make__clauses__headlist__args_7_5:
  if (!isref(a0)) goto make__clauses__headlist__args_7_interrupt;
  deref_and_jump(a0,make__clauses__headlist__args_7_1);
  *reasonp++ =  a0;
  goto make__clauses__headlist__args_7_interrupt;
 make__clauses__headlist__args_7_ext_interrupt:
  reasonp = 0l;
 make__clauses__headlist__args_7_interrupt:
  toppred = &predicate_unify__head__body_xmake__clauses__headlist__args_7;
  goto interrupt_7;
 }

 check__body__modules_3_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  qp = qp->next;
 check__body__modules_3_clear_reason:
  reasonp = reasons;
 check__body__modules_3_0:
 check__body__modules_3_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 check__body__modules_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto check__body__modules_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xcheck__body__modules_3);
  allocp[2] = a0;
  x1 = cdr_of(a1);
  allocp[3] = x1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = makesym(functor_module_2);
  allocp[6] = arg(x0, 0);
  allocp[7] = x4 = makeref(&allocp[7]);
  x3 = makefunctor(&allocp[5]);
  allocp[8] = x2;
  allocp[9] = x3;
  x5 = makecons(&allocp[8]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  unify_value(a2, x5);
  x6 = arg(x0, 0);
  a1 = a0;
  a2 = arg(x0, 1);
  a3 = x4;
  a0 = x6;
  execute(check__body__clauses_4_0);
  goto check__body__clauses_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,check__body__modules_3_2);
  *reasonp++ =  x0;
  goto check__body__modules_3_interrupt;
  };
  goto check__body__modules_3_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto check__body__modules_3_interrupt;
  unify_value(a2, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a1,check__body__modules_3_1);
  *reasonp++ =  a1;
  goto check__body__modules_3_interrupt;
  };
  goto check__body__modules_3_interrupt;
 check__body__modules_3_ext_interrupt:
  reasonp = 0l;
 check__body__modules_3_interrupt:
  goto interrupt_3;
 }

 check__body__clauses_4_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 check__body__clauses_4_clear_reason:
  reasonp = reasons;
 check__body__clauses_4_0:
 check__body__clauses_4_1:
  switch (ptagof(a2)) {
 case CONS:
  x0 = car_of(a2);
 check__body__clauses_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_goal_4)) goto check__body__clauses_4_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xcheck__body__clauses_4);
  allocp[2] = a0;
  allocp[3] = a1;
  x1 = cdr_of(a2);
  allocp[4] = x1;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = x2;
  allocp[7] = x4 = makeref(&allocp[7]);
  x3 = makecons(&allocp[6]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  unify_value(a3, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = makeint(4L);
  allocp[3] = x0;
  allocp[4] = x5 = makeref(&allocp[4]);
  allocp[5] = x4;
  x6 = arg(x0, 0);
  a2 = arg(x0, 1);
  a3 = a1;
  a4 = arg(x0, 3);
  a5 = x5;
  a1 = x6;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(check__body__search__modules_6_0);
  goto check__body__search__modules_6_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,check__body__clauses_4_2);
  *reasonp++ =  x0;
  goto check__body__clauses_4_interrupt;
  };
  goto check__body__clauses_4_interrupt;
 case ATOMIC:
  if (a2 != NILATOM) goto check__body__clauses_4_interrupt;
  unify_value(a3, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a2,check__body__clauses_4_1);
  *reasonp++ =  a2;
  goto check__body__clauses_4_interrupt;
  };
  goto check__body__clauses_4_interrupt;
 check__body__clauses_4_ext_interrupt:
  reasonp = 0l;
 check__body__clauses_4_interrupt:
  toppred = &predicate_unify__head__body_xcheck__body__clauses_4;
  goto interrupt_4;
 }

 check__body__search__modules_6_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 check__body__search__modules_6_clear_reason:
  reasonp = reasons;
 check__body__search__modules_6_0:
 check__body__search__modules_6_1:
  switch (ptagof(a3)) {
 case CONS:
  x0 = car_of(a3);
 check__body__search__modules_6_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto check__body__search__modules_6_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xcheck__body__search__modules_6);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  x1 = cdr_of(a3);
  allocp[5] = x1;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_unify__head__body_xcheck__body__search__clauses_9);
  allocp[10] = makeint(1L);
  allocp[11] = x3 = makeref(&allocp[11]);
  x4 = arg(x0, 1);
  allocp[12] = x4;
  allocp[13] = a0;
  x5 = arg(x0, 0);
  allocp[14] = x5;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a4;
  allocp[18] = x2;
  allocp[19] = (q)(struct goalrec*)&allocp[8];
  allocp[20] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[21] = x4;
  allocp[22] = x6 = makeref(&allocp[22]);
  allocp[23] = x3;
  qp = (struct goalrec*)&allocp[19];
  allocp += 24;
  proceed();
 case VARREF:
  deref_and_jump(x0,check__body__search__modules_6_2);
  *reasonp++ =  x0;
  goto check__body__search__modules_6_interrupt;
  };
  goto check__body__search__modules_6_interrupt;
 case ATOMIC:
  if (a3 != NILATOM) goto check__body__search__modules_6_interrupt;
  unify(a5, a4);
  proceed();
 case VARREF:
  deref_and_jump(a3,check__body__search__modules_6_1);
  *reasonp++ =  a3;
  goto check__body__search__modules_6_interrupt;
  };
  goto check__body__search__modules_6_interrupt;
 check__body__search__modules_6_ext_interrupt:
  reasonp = 0l;
 check__body__search__modules_6_interrupt:
  toppred = &predicate_unify__head__body_xcheck__body__search__modules_6;
  goto interrupt_6;
 }

 check__body__search__clauses_9_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 check__body__search__clauses_9_clear_reason:
  reasonp = reasons;
 check__body__search__clauses_9_0:
 check__body__search__clauses_9_1:
  if (!isint(a0)) goto check__body__search__clauses_9_9;
 check__body__search__clauses_9_2:
  if (!isint(a1)) goto check__body__search__clauses_9_8;
  gblt_less_or_eq(a0,a1,check__body__search__clauses_9_7);
 check__body__search__clauses_9_3:
  if (isref(a2)) goto check__body__search__clauses_9_6;
  gblt_arg(a0,a2,x0,check__body__search__clauses_9_7);
 check__body__search__clauses_9_4:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (isint(x0)) goto check__body__search__clauses_9_7;
 check__body__search__clauses_9_5:
  gblt_atom(x0,check__body__search__clauses_9_7);
  bblt_add_no_check(a0,makeint(1L),x1);
  a0 = x1;
  execute(check__body__search__clauses_9_0);
  goto check__body__search__clauses_9_ext_interrupt;
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_clause_6)) goto check__body__search__clauses_9_7;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xcheck__body__search__clauses_9);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x1;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_unify__head__body_xcheck__body__search__bodys_10);
  allocp[18] = makeint(1L);
  allocp[19] = x3 = makeref(&allocp[19]);
  x4 = arg(x0, 2);
  allocp[20] = x4;
  allocp[21] = a0;
  allocp[22] = a3;
  allocp[23] = a4;
  allocp[24] = a5;
  allocp[25] = a6;
  allocp[26] = a7;
  allocp[27] = x2;
  allocp[28] = (q)(struct goalrec*)&allocp[16];
  allocp[29] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[30] = x4;
  allocp[31] = x5 = makeref(&allocp[31]);
  allocp[32] = x3;
  qp = (struct goalrec*)&allocp[28];
  allocp += 33;
  proceed();
 case VARREF:
  deref_and_jump(x0,check__body__search__clauses_9_4);
  *reasonp++ =  x0;
  goto check__body__search__clauses_9_7;
  };
  goto check__body__search__clauses_9_7;
 check__body__search__clauses_9_6:
  deref_and_jump(a2,check__body__search__clauses_9_3);
  *reasonp++ =  a2;
  goto check__body__search__clauses_9_7;
 check__body__search__clauses_9_7:
  gblt_greater(a0,a1,check__body__search__clauses_9_interrupt);
  unify(a8, a7);
  proceed();
 check__body__search__clauses_9_8:
  if (!isref(a1)) goto check__body__search__clauses_9_interrupt;
  deref_and_jump(a1,check__body__search__clauses_9_2);
  *reasonp++ =  a1;
  goto check__body__search__clauses_9_interrupt;
 check__body__search__clauses_9_9:
  if (!isref(a0)) goto check__body__search__clauses_9_interrupt;
  deref_and_jump(a0,check__body__search__clauses_9_1);
  *reasonp++ =  a0;
  goto check__body__search__clauses_9_interrupt;
 check__body__search__clauses_9_ext_interrupt:
  reasonp = 0l;
 check__body__search__clauses_9_interrupt:
  goto interrupt_9;
 }

 check__body__search__bodys_10_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 check__body__search__bodys_10_clear_reason:
  reasonp = reasons;
 check__body__search__bodys_10_0:
 check__body__search__bodys_10_1:
  if (!isint(a0)) goto check__body__search__bodys_10_7;
 check__body__search__bodys_10_2:
  if (!isint(a1)) goto check__body__search__bodys_10_6;
  gblt_less_or_eq(a0,a1,check__body__search__bodys_10_5);
 check__body__search__bodys_10_3:
  if (isref(a2)) goto check__body__search__bodys_10_4;
  gblt_arg(a0,a2,x0,check__body__search__bodys_10_5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xcheck__body__search__bodys_10);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = x2 = makeref(&allocp[10]);
  allocp[11] = a9;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[14] = a0;
  allocp[15] = makeint(1L);
  allocp[16] = x1;
  x3 = a5;
  a1 = a5;
  a2 = a3;
  a3 = a0;
  x4 = a6;
  a5 = a7;
  a6 = x0;
  a7 = a4;
  a9 = x2;
  a4 = x4;
  a0 = x3;
  qp = (struct goalrec*)&allocp[12];
  allocp += 17;
  execute(check__body__search__body_10_0);
  goto check__body__search__body_10_ext_interrupt;
 check__body__search__bodys_10_4:
  deref_and_jump(a2,check__body__search__bodys_10_3);
  *reasonp++ =  a2;
  goto check__body__search__bodys_10_5;
 check__body__search__bodys_10_5:
  gblt_greater(a0,a1,check__body__search__bodys_10_interrupt);
  unify(a9, a8);
  proceed();
 check__body__search__bodys_10_6:
  if (!isref(a1)) goto check__body__search__bodys_10_interrupt;
  deref_and_jump(a1,check__body__search__bodys_10_2);
  *reasonp++ =  a1;
  goto check__body__search__bodys_10_interrupt;
 check__body__search__bodys_10_7:
  if (!isref(a0)) goto check__body__search__bodys_10_interrupt;
  deref_and_jump(a0,check__body__search__bodys_10_1);
  *reasonp++ =  a0;
  goto check__body__search__bodys_10_interrupt;
 check__body__search__bodys_10_ext_interrupt:
  reasonp = 0l;
 check__body__search__bodys_10_interrupt:
  goto interrupt_10;
 }

 check__body__search__body_10_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 check__body__search__body_10_clear_reason:
  reasonp = reasons;
 check__body__search__body_10_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xcheck__body__search__body1_11);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = a0;
  allocp[10] = a7;
  allocp[11] = a8;
  allocp[12] = a9;
  allocp[13] = (q)(struct goalrec*)&allocp[0];
  allocp[14] = (q)(&predicate_parse__uty_xdecode__goalcall_6);
  allocp[15] = a0;
  allocp[16] = x1;
  allocp[17] = a6;
  allocp[18] = x2;
  allocp[19] = x0;
  allocp[20] = x3 = makeref(&allocp[20]);
  qp = (struct goalrec*)&allocp[13];
  allocp += 21;
  proceed();
 check__body__search__body_10_ext_interrupt:
  reasonp = 0l;
 check__body__search__body_10_interrupt:
  toppred = &predicate_unify__head__body_xcheck__body__search__body_10;
  goto interrupt_10;
 }

 check__body__search__body1_11_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 check__body__search__body1_11_clear_reason:
  reasonp = reasons;
 check__body__search__body1_11_0:
 check__body__search__body1_11_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_atom_1)) goto check__body__search__body1_11_17;
  x0 = arg(a0, 0);
 check__body__search__body1_11_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_loop)) goto check__body__search__body1_11_17;
 check__body__search__body1_11_3:
  if (isref(a1)) goto check__body__search__body1_11_16;
 check__body__search__body1_11_4:
  if (isref(a1)) goto check__body__search__body1_11_15;
  if_not_equal(a1, a8, check__body__search__body1_11_17);
 check__body__search__body1_11_5:
  if (isref(a6)) goto check__body__search__body1_11_14;
  gblt_pfunctor(a6,x1,check__body__search__body1_11_17);
 check__body__search__body1_11_6:
  if (isref(x1)) goto check__body__search__body1_11_13;
 check__body__search__body1_11_7:
  if (isref(x1)) goto check__body__search__body1_11_12;
  if_not_equal(x1, a4, check__body__search__body1_11_17);
  gblt_arity(a6,x2,check__body__search__body1_11_17);
 check__body__search__body1_11_8:
  if (isref(x2)) goto check__body__search__body1_11_11;
 check__body__search__body1_11_9:
  if (isref(x2)) goto check__body__search__body1_11_10;
  if_not_equal(x2, a5, check__body__search__body1_11_17);
  a0 = makeint(1L);
  a1 = a5;
  x3 = a6;
  a4 = a7;
  a5 = a2;
  a6 = a3;
  a7 = a9;
  a8 = a10;
  a3 = x3;
  a2 = makesym(atom_loop);
  execute(check__body__bodylist__args_9_clear_reason);
  goto check__body__bodylist__args_9_ext_interrupt;
 check__body__search__body1_11_10:
  deref_and_jump(x2,check__body__search__body1_11_9);
  *reasonp++ =  x2;
  goto check__body__search__body1_11_17;
 check__body__search__body1_11_11:
  deref_and_jump(x2,check__body__search__body1_11_8);
  *reasonp++ =  x2;
  goto check__body__search__body1_11_17;
 check__body__search__body1_11_12:
  deref_and_jump(x1,check__body__search__body1_11_7);
  *reasonp++ =  x1;
  goto check__body__search__body1_11_17;
 check__body__search__body1_11_13:
  deref_and_jump(x1,check__body__search__body1_11_6);
  *reasonp++ =  x1;
  goto check__body__search__body1_11_17;
 check__body__search__body1_11_14:
  deref_and_jump(a6,check__body__search__body1_11_5);
  *reasonp++ =  a6;
  goto check__body__search__body1_11_17;
 check__body__search__body1_11_15:
  deref_and_jump(a1,check__body__search__body1_11_4);
  *reasonp++ =  a1;
  goto check__body__search__body1_11_17;
 check__body__search__body1_11_16:
  deref_and_jump(a1,check__body__search__body1_11_3);
  *reasonp++ =  a1;
  goto check__body__search__body1_11_17;
 case VARREF:
  deref_and_jump(x0,check__body__search__body1_11_2);
  *reasonp++ =  x0;
  goto check__body__search__body1_11_17;
  };
  goto check__body__search__body1_11_17;
 case VARREF:
  deref_and_jump(a0,check__body__search__body1_11_1);
  *reasonp++ =  a0;
  goto check__body__search__body1_11_17;
  };
  goto check__body__search__body1_11_17;
 check__body__search__body1_11_17:
  otherwise(check__body__search__body1_11_interrupt);
 check__body__search__body1_11_18:
  if (isref(a1)) goto check__body__search__body1_11_31;
 check__body__search__body1_11_19:
  if (isref(a1)) goto check__body__search__body1_11_30;
  if_not_equal(a1, a8, check__body__search__body1_11_32);
 check__body__search__body1_11_20:
  if (isref(a6)) goto check__body__search__body1_11_29;
  gblt_pfunctor(a6,x0,check__body__search__body1_11_32);
 check__body__search__body1_11_21:
  if (isref(x0)) goto check__body__search__body1_11_28;
 check__body__search__body1_11_22:
  if (isref(x0)) goto check__body__search__body1_11_27;
  if_not_equal(x0, a4, check__body__search__body1_11_32);
  gblt_arity(a6,x1,check__body__search__body1_11_32);
 check__body__search__body1_11_23:
  if (isref(x1)) goto check__body__search__body1_11_26;
 check__body__search__body1_11_24:
  if (isref(x1)) goto check__body__search__body1_11_25;
  if_not_equal(x1, a5, check__body__search__body1_11_32);
  a0 = makeint(1L);
  a1 = a5;
  x2 = a6;
  a4 = a7;
  a5 = a2;
  a6 = a3;
  a7 = a9;
  a8 = a10;
  a3 = x2;
  a2 = makesym(atom_nonloop);
  execute(check__body__bodylist__args_9_clear_reason);
  goto check__body__bodylist__args_9_ext_interrupt;
 check__body__search__body1_11_25:
  deref_and_jump(x1,check__body__search__body1_11_24);
  *reasonp++ =  x1;
  goto check__body__search__body1_11_32;
 check__body__search__body1_11_26:
  deref_and_jump(x1,check__body__search__body1_11_23);
  *reasonp++ =  x1;
  goto check__body__search__body1_11_32;
 check__body__search__body1_11_27:
  deref_and_jump(x0,check__body__search__body1_11_22);
  *reasonp++ =  x0;
  goto check__body__search__body1_11_32;
 check__body__search__body1_11_28:
  deref_and_jump(x0,check__body__search__body1_11_21);
  *reasonp++ =  x0;
  goto check__body__search__body1_11_32;
 check__body__search__body1_11_29:
  deref_and_jump(a6,check__body__search__body1_11_20);
  *reasonp++ =  a6;
  goto check__body__search__body1_11_32;
 check__body__search__body1_11_30:
  deref_and_jump(a1,check__body__search__body1_11_19);
  *reasonp++ =  a1;
  goto check__body__search__body1_11_32;
 check__body__search__body1_11_31:
  deref_and_jump(a1,check__body__search__body1_11_18);
  *reasonp++ =  a1;
  goto check__body__search__body1_11_32;
 check__body__search__body1_11_32:
  otherwise(check__body__search__body1_11_interrupt);
  unify(a10, a9);
  proceed();
 check__body__search__body1_11_ext_interrupt:
  reasonp = 0l;
 check__body__search__body1_11_interrupt:
  goto interrupt_11;
 }

 check__body__bodylist__args_9_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 check__body__bodylist__args_9_clear_reason:
  reasonp = reasons;
 check__body__bodylist__args_9_0:
 check__body__bodylist__args_9_1:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (isint(a2)) goto check__body__bodylist__args_9_10;
  switch (symval(a2)) {
 case symval(makesym(atom_loop)):
 check__body__bodylist__args_9_2:
  if (!isint(a0)) goto check__body__bodylist__args_9_5;
 check__body__bodylist__args_9_3:
  if (!isint(a1)) goto check__body__bodylist__args_9_4;
  gblt_less_or_eq(a0,a1,check__body__bodylist__args_9_10);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xcheck__body__bodylist__args_9);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = makesym(atom_loop);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = x1 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x0;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[18] = a0;
  allocp[19] = a7;
  allocp[20] = x2 = makeref(&allocp[20]);
  allocp[21] = x1;
  allocp[22] = makesym(functor_looparg_5);
  allocp[23] = a4;
  allocp[24] = a5;
  allocp[25] = makesym(atom_body);
  allocp[26] = a6;
  allocp[27] = x4 = makeref(&allocp[27]);
  x3 = makefunctor(&allocp[22]);
  allocp[28] = NILATOM;
  allocp[29] = x3;
  x5 = makecons(&allocp[28]);
  allocp[30] = (q)(struct goalrec*)&allocp[16];
  allocp[31] = (q)(&predicate_list_xappend_3);
  allocp[32] = x6 = makeref(&allocp[32]);
  allocp[33] = x5;
  allocp[34] = x2;
  allocp[35] = (q)(struct goalrec*)&allocp[30];
  allocp[36] = (q)(&predicate_functor__table_xarg_3);
  allocp[37] = a0;
  allocp[38] = a7;
  allocp[39] = x6;
  allocp[40] = (q)(struct goalrec*)&allocp[35];
  allocp[41] = (q)(&predicate_functor__table_xarg_3);
  allocp[42] = a0;
  allocp[43] = a3;
  allocp[44] = x4;
  qp = (struct goalrec*)&allocp[40];
  allocp += 45;
  proceed();
 check__body__bodylist__args_9_4:
  if (!isref(a1)) goto check__body__bodylist__args_9_10;
  deref_and_jump(a1,check__body__bodylist__args_9_3);
  *reasonp++ =  a1;
  goto check__body__bodylist__args_9_10;
 check__body__bodylist__args_9_5:
  if (!isref(a0)) goto check__body__bodylist__args_9_10;
  deref_and_jump(a0,check__body__bodylist__args_9_2);
  *reasonp++ =  a0;
  goto check__body__bodylist__args_9_10;
 case symval(makesym(atom_nonloop)):
 check__body__bodylist__args_9_6:
  if (!isint(a0)) goto check__body__bodylist__args_9_9;
 check__body__bodylist__args_9_7:
  if (!isint(a1)) goto check__body__bodylist__args_9_8;
  gblt_less_or_eq(a0,a1,check__body__bodylist__args_9_10);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xcheck__body__bodylist__args_9);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = makesym(atom_nonloop);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = x1 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x0;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[18] = a0;
  allocp[19] = a7;
  allocp[20] = x2 = makeref(&allocp[20]);
  allocp[21] = x1;
  allocp[22] = makesym(functor_arg_5);
  allocp[23] = a4;
  allocp[24] = a5;
  allocp[25] = makesym(atom_body);
  allocp[26] = a6;
  allocp[27] = x4 = makeref(&allocp[27]);
  x3 = makefunctor(&allocp[22]);
  allocp[28] = NILATOM;
  allocp[29] = x3;
  x5 = makecons(&allocp[28]);
  allocp[30] = (q)(struct goalrec*)&allocp[16];
  allocp[31] = (q)(&predicate_list_xappend_3);
  allocp[32] = x6 = makeref(&allocp[32]);
  allocp[33] = x5;
  allocp[34] = x2;
  allocp[35] = (q)(struct goalrec*)&allocp[30];
  allocp[36] = (q)(&predicate_functor__table_xarg_3);
  allocp[37] = a0;
  allocp[38] = a7;
  allocp[39] = x6;
  allocp[40] = (q)(struct goalrec*)&allocp[35];
  allocp[41] = (q)(&predicate_functor__table_xarg_3);
  allocp[42] = a0;
  allocp[43] = a3;
  allocp[44] = x4;
  qp = (struct goalrec*)&allocp[40];
  allocp += 45;
  proceed();
 check__body__bodylist__args_9_8:
  if (!isref(a1)) goto check__body__bodylist__args_9_10;
  deref_and_jump(a1,check__body__bodylist__args_9_7);
  *reasonp++ =  a1;
  goto check__body__bodylist__args_9_10;
 check__body__bodylist__args_9_9:
  if (!isref(a0)) goto check__body__bodylist__args_9_10;
  deref_and_jump(a0,check__body__bodylist__args_9_6);
  *reasonp++ =  a0;
  goto check__body__bodylist__args_9_10;
  };
  goto check__body__bodylist__args_9_10;
 case VARREF:
  deref_and_jump(a2,check__body__bodylist__args_9_1);
  *reasonp++ =  a2;
  goto check__body__bodylist__args_9_10;
  };
  goto check__body__bodylist__args_9_10;
 check__body__bodylist__args_9_10:
 check__body__bodylist__args_9_11:
  if (!isint(a0)) goto check__body__bodylist__args_9_14;
 check__body__bodylist__args_9_12:
  if (!isint(a1)) goto check__body__bodylist__args_9_13;
  gblt_greater(a0,a1,check__body__bodylist__args_9_interrupt);
  unify(a8, a7);
  proceed();
 check__body__bodylist__args_9_13:
  if (!isref(a1)) goto check__body__bodylist__args_9_interrupt;
  deref_and_jump(a1,check__body__bodylist__args_9_12);
  *reasonp++ =  a1;
  goto check__body__bodylist__args_9_interrupt;
 check__body__bodylist__args_9_14:
  if (!isref(a0)) goto check__body__bodylist__args_9_interrupt;
  deref_and_jump(a0,check__body__bodylist__args_9_11);
  *reasonp++ =  a0;
  goto check__body__bodylist__args_9_interrupt;
 check__body__bodylist__args_9_ext_interrupt:
  reasonp = 0l;
 check__body__bodylist__args_9_interrupt:
  toppred = &predicate_unify__head__body_xcheck__body__bodylist__args_9;
  goto interrupt_9;
 }

 apply__direct__value_7_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 apply__direct__value_7_clear_reason:
  reasonp = reasons;
 apply__direct__value_7_0:
 apply__direct__value_7_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 apply__direct__value_7_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto apply__direct__value_7_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xapply__direct__value_7);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x4 = makeref(&allocp[7]);
  allocp[8] = a6;
  a0 = arg(x0, 1);
  a2 = x2;
  a4 = x3;
  a6 = x4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 9;
  execute(apply__direct__value__clauses_7_0);
  goto apply__direct__value__clauses_7_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,apply__direct__value_7_2);
  *reasonp++ =  x0;
  goto apply__direct__value_7_interrupt;
  };
  goto apply__direct__value_7_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto apply__direct__value_7_interrupt;
  unify3(a2, a1, a4, a3, a6, a5);
  proceed();
 case VARREF:
  deref_and_jump(a0,apply__direct__value_7_1);
  *reasonp++ =  a0;
  goto apply__direct__value_7_interrupt;
  };
  goto apply__direct__value_7_interrupt;
 apply__direct__value_7_ext_interrupt:
  reasonp = 0l;
 apply__direct__value_7_interrupt:
  goto interrupt_7;
 }

 apply__direct__value__clauses_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 apply__direct__value__clauses_7_clear_reason:
  reasonp = reasons;
 apply__direct__value__clauses_7_0:
 apply__direct__value__clauses_7_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 apply__direct__value__clauses_7_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_goal_4)) goto apply__direct__value__clauses_7_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xapply__direct__value__clauses_7);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x4 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = makesym(functor_goal_2);
  allocp[10] = arg(x0, 0);
  allocp[11] = arg(x0, 1);
  x5 = makefunctor(&allocp[9]);
  a0 = x5;
  x6 = arg(x0, 1);
  a2 = arg(x0, 2);
  x7 = arg(x0, 3);
  a4 = a1;
  a6 = a3;
  a7 = x3;
  a8 = a5;
  a9 = x4;
  a5 = x2;
  a3 = x7;
  a1 = x6;
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  execute(apply__direct__value__clause_10_0);
  goto apply__direct__value__clause_10_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,apply__direct__value__clauses_7_2);
  *reasonp++ =  x0;
  goto apply__direct__value__clauses_7_interrupt;
  };
  goto apply__direct__value__clauses_7_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto apply__direct__value__clauses_7_interrupt;
  unify3(a2, a1, a4, a3, a6, a5);
  proceed();
 case VARREF:
  deref_and_jump(a0,apply__direct__value__clauses_7_1);
  *reasonp++ =  a0;
  goto apply__direct__value__clauses_7_interrupt;
  };
  goto apply__direct__value__clauses_7_interrupt;
 apply__direct__value__clauses_7_ext_interrupt:
  reasonp = 0l;
 apply__direct__value__clauses_7_interrupt:
  toppred = &predicate_unify__head__body_xapply__direct__value__clauses_7;
  goto interrupt_7;
 }

 apply__direct__value__clause_10_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 apply__direct__value__clause_10_clear_reason:
  reasonp = reasons;
 apply__direct__value__clause_10_0:
 apply__direct__value__clause_10_1:
  if (!isint(a1)) goto apply__direct__value__clause_10_3;
  gblt_greater(a1,makeint(0L),apply__direct__value__clause_10_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xapply__direct__value__clause_10);
  allocp[2] = a0;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x3 = makeref(&allocp[10]);
  allocp[11] = a9;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[14] = a1;
  allocp[15] = makeint(1L);
  allocp[16] = x0;
  allocp[17] = (q)(struct goalrec*)&allocp[12];
  allocp[18] = (q)(&predicate_unify__head__body_xapply__direct__value__head_9);
  allocp[19] = a0;
  allocp[20] = x4 = makeref(&allocp[20]);
  allocp[21] = x5 = makeref(&allocp[21]);
  allocp[22] = a4;
  allocp[23] = x1;
  allocp[24] = a6;
  allocp[25] = x2;
  allocp[26] = a8;
  allocp[27] = x3;
  allocp[28] = (q)(struct goalrec*)&allocp[17];
  allocp[29] = (q)(&predicate_unify__head__body_xcheck__only__vars_2);
  allocp[30] = x6 = makeref(&allocp[30]);
  allocp[31] = x4;
  allocp[32] = (q)(struct goalrec*)&allocp[28];
  allocp[33] = (q)(&predicate_unify__head__body_xmake__direct__type_2);
  allocp[34] = x7 = makeref(&allocp[34]);
  allocp[35] = x6;
  allocp[36] = (q)(struct goalrec*)&allocp[32];
  allocp[37] = (q)(&predicate_functor__table_xarg_3);
  allocp[38] = a1;
  allocp[39] = a3;
  allocp[40] = x7;
  allocp[41] = (q)(struct goalrec*)&allocp[36];
  allocp[42] = (q)(&predicate_functor__table_xarg_3);
  allocp[43] = a1;
  allocp[44] = a2;
  allocp[45] = x5;
  qp = (struct goalrec*)&allocp[41];
  allocp += 46;
  proceed();
 apply__direct__value__clause_10_2:
  if (a1 != makeint(0L)) goto apply__direct__value__clause_10_interrupt;
  unify3(a5, a4, a7, a6, a9, a8);
  proceed();
 apply__direct__value__clause_10_3:
  if (!isref(a1)) goto apply__direct__value__clause_10_interrupt;
  deref_and_jump(a1,apply__direct__value__clause_10_1);
  *reasonp++ =  a1;
  goto apply__direct__value__clause_10_interrupt;
 apply__direct__value__clause_10_ext_interrupt:
  reasonp = 0l;
 apply__direct__value__clause_10_interrupt:
  toppred = &predicate_unify__head__body_xapply__direct__value__clause_10;
  goto interrupt_10;
 }

 apply__direct__value__head_9_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 apply__direct__value__head_9_clear_reason:
  reasonp = reasons;
 apply__direct__value__head_9_0:
 apply__direct__value__head_9_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 apply__direct__value__head_9_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__3F)) goto apply__direct__value__head_9_4;
  x1 = cdr_of(a1);
 apply__direct__value__head_9_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto apply__direct__value__head_9_4;
  unify3(a4, a3, a6, a5, a8, a7);
  proceed();
 case VARREF:
  deref_and_jump(x1,apply__direct__value__head_9_3);
  *reasonp++ =  x1;
  goto apply__direct__value__head_9_4;
  };
  goto apply__direct__value__head_9_4;
 case VARREF:
  deref_and_jump(x0,apply__direct__value__head_9_2);
  *reasonp++ =  x0;
  goto apply__direct__value__head_9_4;
  };
  goto apply__direct__value__head_9_4;
 case VARREF:
  deref_and_jump(a1,apply__direct__value__head_9_1);
  *reasonp++ =  a1;
  goto apply__direct__value__head_9_4;
  };
  goto apply__direct__value__head_9_4;
 apply__direct__value__head_9_4:
  otherwise(apply__direct__value__head_9_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xset__head__type_6);
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  allocp[5] = a4;
  allocp[6] = a5;
  allocp[7] = a6;
  a1 = a2;
  a2 = a7;
  a3 = a8;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  execute(set__head__mode_4_0);
  goto set__head__mode_4_ext_interrupt;
 apply__direct__value__head_9_ext_interrupt:
  reasonp = 0l;
 apply__direct__value__head_9_interrupt:
  goto interrupt_9;
 }

 set__head__mode_4_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 set__head__mode_4_clear_reason:
  reasonp = reasons;
 set__head__mode_4_0:
 set__head__mode_4_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 set__head__mode_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_arg_5)) goto set__head__mode_4_interrupt;
  x1 = arg(x0, 2);
 set__head__mode_4_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_head)) goto set__head__mode_4_interrupt;
  x2 = arg(x0, 3);
 set__head__mode_4_4:
  switch (ptagof(x2)) {
 case ATOMIC:
 set__head__mode_4_5:
  if (x2 != makeint(1L)) goto set__head__mode_4_interrupt;
  x3 = arg(x0, 4);
 set__head__mode_4_6:
  switch (ptagof(x3)) {
 case FUNCTOR:
  if (functor_of(x3) != makesym(functor_variable_3)) goto set__head__mode_4_interrupt;
  x4 = arg(x3, 2);
 set__head__mode_4_7:
  switch (ptagof(x4)) {
 case ATOMIC:
  if (x4 != makesym(atom__3F)) goto set__head__mode_4_interrupt;
  a0 = arg(x0, 0);
  a1 = arg(x0, 1);
  x5 = arg(x3, 1);
  x6 = arg(x3, 0);
  a4 = a2;
  a5 = a3;
  a3 = x6;
  a2 = x5;
  execute(set__head__mode__modules_6_0);
  goto set__head__mode__modules_6_ext_interrupt;
 case VARREF:
  deref_and_jump(x4,set__head__mode_4_7);
  *reasonp++ =  x4;
  goto set__head__mode_4_interrupt;
  };
  goto set__head__mode_4_interrupt;
 case VARREF:
  deref_and_jump(x3,set__head__mode_4_6);
  *reasonp++ =  x3;
  goto set__head__mode_4_interrupt;
  };
  goto set__head__mode_4_interrupt;
 case VARREF:
  deref_and_jump(x2,set__head__mode_4_4);
  *reasonp++ =  x2;
  goto set__head__mode_4_interrupt;
  };
  goto set__head__mode_4_interrupt;
 case VARREF:
  deref_and_jump(x1,set__head__mode_4_3);
  *reasonp++ =  x1;
  goto set__head__mode_4_interrupt;
  };
  goto set__head__mode_4_interrupt;
 case VARREF:
  deref_and_jump(x0,set__head__mode_4_2);
  *reasonp++ =  x0;
  goto set__head__mode_4_interrupt;
  };
  goto set__head__mode_4_interrupt;
 case VARREF:
  deref_and_jump(a1,set__head__mode_4_1);
  *reasonp++ =  a1;
  goto set__head__mode_4_interrupt;
  };
  goto set__head__mode_4_interrupt;
 set__head__mode_4_ext_interrupt:
  reasonp = 0l;
 set__head__mode_4_interrupt:
  toppred = &predicate_unify__head__body_xset__head__mode_4;
  goto interrupt_4;
 }

 set__head__mode__modules_6_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 set__head__mode__modules_6_clear_reason:
  reasonp = reasons;
 set__head__mode__modules_6_0:
 set__head__mode__modules_6_1:
  switch (ptagof(a4)) {
 case CONS:
  x0 = car_of(a4);
 set__head__mode__modules_6_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto set__head__mode__modules_6_7;
 set__head__mode__modules_6_3:
  if (isref(a0)) goto set__head__mode__modules_6_6;
 set__head__mode__modules_6_4:
  if (isref(a0)) goto set__head__mode__modules_6_5;
  x1 = arg(x0, 0);
  if_not_equal(a0, x1, set__head__mode__modules_6_7);
  allocp[0] = makesym(functor_module_2);
  allocp[1] = a0;
  allocp[2] = x3 = makeref(&allocp[2]);
  x2 = makefunctor(&allocp[0]);
  allocp[3] = cdr_of(a4);
  allocp[4] = x2;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a5, x4);
  a0 = a1;
  a1 = a2;
  a2 = a3;
  a3 = arg(x0, 1);
  a4 = x3;
  execute(set__head__mode__clauses_5_clear_reason);
  goto set__head__mode__clauses_5_ext_interrupt;
 set__head__mode__modules_6_5:
  deref_and_jump(a0,set__head__mode__modules_6_4);
  *reasonp++ =  a0;
  goto set__head__mode__modules_6_7;
 set__head__mode__modules_6_6:
  deref_and_jump(a0,set__head__mode__modules_6_3);
  *reasonp++ =  a0;
  goto set__head__mode__modules_6_7;
 case VARREF:
  deref_and_jump(x0,set__head__mode__modules_6_2);
  *reasonp++ =  x0;
  goto set__head__mode__modules_6_7;
  };
  goto set__head__mode__modules_6_7;
 case VARREF:
  deref_and_jump(a4,set__head__mode__modules_6_1);
  *reasonp++ =  a4;
  goto set__head__mode__modules_6_7;
  };
  goto set__head__mode__modules_6_7;
 set__head__mode__modules_6_7:
  otherwise(set__head__mode__modules_6_interrupt);
 set__head__mode__modules_6_8:
  switch (ptagof(a4)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = car_of(a4);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a5, x0);
  a4 = cdr_of(a4);
  a5 = x1;
  execute(set__head__mode__modules_6_0);
  goto set__head__mode__modules_6_ext_interrupt;
 case ATOMIC:
  if (a4 != NILATOM) goto set__head__mode__modules_6_interrupt;
  unify_value(a5, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a4,set__head__mode__modules_6_8);
  *reasonp++ =  a4;
  goto set__head__mode__modules_6_interrupt;
  };
  goto set__head__mode__modules_6_interrupt;
 set__head__mode__modules_6_ext_interrupt:
  reasonp = 0l;
 set__head__mode__modules_6_interrupt:
  toppred = &predicate_unify__head__body_xset__head__mode__modules_6;
  goto interrupt_6;
 }

 set__head__mode__clauses_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 set__head__mode__clauses_5_clear_reason:
  reasonp = reasons;
 set__head__mode__clauses_5_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xset__head__mode__clauses1_7);
  allocp[2] = a0;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = a3;
  allocp[8] = a4;
  allocp[9] = makesym(functor_variable_3);
  allocp[10] = a2;
  allocp[11] = a1;
  allocp[12] = makesym(atom__3F);
  x4 = makefunctor(&allocp[9]);
  allocp[13] = (q)(struct goalrec*)&allocp[0];
  allocp[14] = (q)(&predicate_functor_xget__arg__pos_3);
  allocp[15] = x5 = makeref(&allocp[15]);
  allocp[16] = x4;
  allocp[17] = x1;
  allocp[18] = (q)(struct goalrec*)&allocp[13];
  allocp[19] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[20] = x5;
  allocp[21] = x2;
  allocp[22] = x3;
  allocp[23] = makesym(functor_functor_3);
  allocp[24] = x5;
  allocp[25] = x7 = makeref(&allocp[25]);
  allocp[26] = x8 = makeref(&allocp[26]);
  x6 = makefunctor(&allocp[23]);
  allocp[27] = makesym(functor_clause_6);
  allocp[28] = x6;
  allocp[29] = x10 = makeref(&allocp[29]);
  allocp[30] = x11 = makeref(&allocp[30]);
  allocp[31] = x12 = makeref(&allocp[31]);
  allocp[32] = x13 = makeref(&allocp[32]);
  allocp[33] = x14 = makeref(&allocp[33]);
  x9 = makefunctor(&allocp[27]);
  allocp[34] = (q)(struct goalrec*)&allocp[18];
  allocp[35] = (q)(&predicate_functor__table_xarg_3);
  allocp[36] = a0;
  allocp[37] = a3;
  allocp[38] = x9;
  allocp[39] = (q)(struct goalrec*)&allocp[34];
  allocp[40] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[41] = a3;
  allocp[42] = x15 = makeref(&allocp[42]);
  allocp[43] = x0;
  qp = (struct goalrec*)&allocp[39];
  allocp += 44;
  proceed();
 set__head__mode__clauses_5_ext_interrupt:
  reasonp = 0l;
 set__head__mode__clauses_5_interrupt:
  toppred = &predicate_unify__head__body_xset__head__mode__clauses_5;
  goto interrupt_5;
 }

 set__head__mode__clauses1_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 set__head__mode__clauses1_7_clear_reason:
  reasonp = reasons;
 set__head__mode__clauses1_7_0:
 set__head__mode__clauses1_7_1:
  if (!isint(a0)) goto set__head__mode__clauses1_7_18;
 set__head__mode__clauses1_7_2:
  if (!isint(a1)) goto set__head__mode__clauses1_7_17;
  gblt_less_or_eq(a0,a1,set__head__mode__clauses1_7_19);
 set__head__mode__clauses1_7_3:
  if (isref(a5)) goto set__head__mode__clauses1_7_16;
  gblt_arg(a0,a5,x0,set__head__mode__clauses1_7_19);
 set__head__mode__clauses1_7_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_clause_6)) goto set__head__mode__clauses1_7_19;
  x1 = arg(x0, 0);
 set__head__mode__clauses1_7_5:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_functor_3)) goto set__head__mode__clauses1_7_19;
  x2 = arg(x1, 0);
 set__head__mode__clauses1_7_6:
  if (isref(x2)) goto set__head__mode__clauses1_7_15;
  gblt_pfunctor(x2,x3,set__head__mode__clauses1_7_19);
 set__head__mode__clauses1_7_7:
  if (isref(x3)) goto set__head__mode__clauses1_7_14;
 set__head__mode__clauses1_7_8:
  if (isref(x3)) goto set__head__mode__clauses1_7_13;
  if_not_equal(x3, a3, set__head__mode__clauses1_7_19);
  gblt_arity(x2,x4,set__head__mode__clauses1_7_19);
 set__head__mode__clauses1_7_9:
  if (isref(x4)) goto set__head__mode__clauses1_7_12;
 set__head__mode__clauses1_7_10:
  if (isref(x4)) goto set__head__mode__clauses1_7_11;
  if_not_equal(x4, a4, set__head__mode__clauses1_7_19);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xset__head__mode__clauses1_7);
  allocp[2] = x5 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x6 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[11] = a0;
  allocp[12] = makeint(1L);
  allocp[13] = x5;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[16] = a0;
  allocp[17] = a5;
  allocp[18] = x7 = makeref(&allocp[18]);
  allocp[19] = x6;
  allocp[20] = makesym(functor_functor_3);
  allocp[21] = x9 = makeref(&allocp[21]);
  allocp[22] = arg(x1, 1);
  allocp[23] = arg(x1, 2);
  x8 = makefunctor(&allocp[20]);
  allocp[24] = makesym(functor_clause_6);
  allocp[25] = x8;
  allocp[26] = arg(x0, 1);
  allocp[27] = arg(x0, 2);
  allocp[28] = arg(x0, 3);
  allocp[29] = arg(x0, 4);
  allocp[30] = x11 = makeref(&allocp[30]);
  x10 = makefunctor(&allocp[24]);
  qp = (struct goalrec*)&allocp[14];
  allocp += 31;
  unify_value(x7, x10);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = a2;
  allocp[3] = x2;
  allocp[4] = x12 = makeref(&allocp[4]);
  allocp[5] = x9;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_mode_xset__arg__mode_6);
  allocp[8] = x13 = makeref(&allocp[8]);
  allocp[9] = makesym(atom_i);
  allocp[10] = makesym(atom_head);
  allocp[11] = x12;
  x14 = arg(x0, 5);
  allocp[12] = x14;
  allocp[13] = x11;
  allocp[14] = (q)(struct goalrec*)&allocp[6];
  allocp[15] = (q)(&predicate_functor__table_xarg_3);
  allocp[16] = a2;
  allocp[17] = x2;
  allocp[18] = x13;
  qp = (struct goalrec*)&allocp[14];
  allocp += 19;
  proceed();
 set__head__mode__clauses1_7_11:
  deref_and_jump(x4,set__head__mode__clauses1_7_10);
  *reasonp++ =  x4;
  goto set__head__mode__clauses1_7_19;
 set__head__mode__clauses1_7_12:
  deref_and_jump(x4,set__head__mode__clauses1_7_9);
  *reasonp++ =  x4;
  goto set__head__mode__clauses1_7_19;
 set__head__mode__clauses1_7_13:
  deref_and_jump(x3,set__head__mode__clauses1_7_8);
  *reasonp++ =  x3;
  goto set__head__mode__clauses1_7_19;
 set__head__mode__clauses1_7_14:
  deref_and_jump(x3,set__head__mode__clauses1_7_7);
  *reasonp++ =  x3;
  goto set__head__mode__clauses1_7_19;
 set__head__mode__clauses1_7_15:
  deref_and_jump(x2,set__head__mode__clauses1_7_6);
  *reasonp++ =  x2;
  goto set__head__mode__clauses1_7_19;
 case VARREF:
  deref_and_jump(x1,set__head__mode__clauses1_7_5);
  *reasonp++ =  x1;
  goto set__head__mode__clauses1_7_19;
  };
  goto set__head__mode__clauses1_7_19;
 case VARREF:
  deref_and_jump(x0,set__head__mode__clauses1_7_4);
  *reasonp++ =  x0;
  goto set__head__mode__clauses1_7_19;
  };
  goto set__head__mode__clauses1_7_19;
 set__head__mode__clauses1_7_16:
  deref_and_jump(a5,set__head__mode__clauses1_7_3);
  *reasonp++ =  a5;
  goto set__head__mode__clauses1_7_19;
 set__head__mode__clauses1_7_17:
  if (!isref(a1)) goto set__head__mode__clauses1_7_19;
  deref_and_jump(a1,set__head__mode__clauses1_7_2);
  *reasonp++ =  a1;
  goto set__head__mode__clauses1_7_19;
 set__head__mode__clauses1_7_18:
  if (!isref(a0)) goto set__head__mode__clauses1_7_19;
  deref_and_jump(a0,set__head__mode__clauses1_7_1);
  *reasonp++ =  a0;
  goto set__head__mode__clauses1_7_19;
 set__head__mode__clauses1_7_19:
  otherwise(set__head__mode__clauses1_7_interrupt);
  unify(a6, a5);
  proceed();
 set__head__mode__clauses1_7_ext_interrupt:
  reasonp = 0l;
 set__head__mode__clauses1_7_interrupt:
  goto interrupt_7;
 }

 set__head__type_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 set__head__type_6_clear_reason:
  reasonp = reasons;
 set__head__type_6_0:
 set__head__type_6_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 set__head__type_6_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_arg_5)) goto set__head__type_6_interrupt;
  x1 = arg(x0, 2);
 set__head__type_6_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_head)) goto set__head__type_6_interrupt;
  x2 = arg(x0, 3);
 set__head__type_6_4:
  switch (ptagof(x2)) {
 case ATOMIC:
 set__head__type_6_5:
  if (x2 != makeint(1L)) goto set__head__type_6_interrupt;
  x3 = arg(x0, 4);
 set__head__type_6_6:
  switch (ptagof(x3)) {
 case FUNCTOR:
  if (functor_of(x3) != makesym(functor_variable_3)) goto set__head__type_6_interrupt;
  x4 = arg(x3, 2);
 set__head__type_6_7:
  switch (ptagof(x4)) {
 case ATOMIC:
  if (x4 != makesym(atom__3F)) goto set__head__type_6_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xset__head__type_6);
  allocp[2] = a0;
  x5 = cdr_of(a1);
  allocp[3] = x5;
  allocp[4] = x6 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x7 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_type_xset__types_11);
  x8 = arg(x0, 0);
  allocp[10] = x8;
  x9 = arg(x0, 1);
  allocp[11] = x9;
  allocp[12] = makesym(atom_head);
  allocp[13] = makeint(1L);
  x10 = arg(x3, 0);
  allocp[14] = x10;
  allocp[15] = makesym(atom_i);
  allocp[16] = a0;
  allocp[17] = a2;
  allocp[18] = x6;
  allocp[19] = a4;
  allocp[20] = x7;
  qp = (struct goalrec*)&allocp[8];
  allocp += 21;
  proceed();
 case VARREF:
  deref_and_jump(x4,set__head__type_6_7);
  *reasonp++ =  x4;
  goto set__head__type_6_interrupt;
  };
  goto set__head__type_6_interrupt;
 case VARREF:
  deref_and_jump(x3,set__head__type_6_6);
  *reasonp++ =  x3;
  goto set__head__type_6_interrupt;
  };
  goto set__head__type_6_interrupt;
 case VARREF:
  deref_and_jump(x2,set__head__type_6_4);
  *reasonp++ =  x2;
  goto set__head__type_6_interrupt;
  };
  goto set__head__type_6_interrupt;
 case VARREF:
  deref_and_jump(x1,set__head__type_6_3);
  *reasonp++ =  x1;
  goto set__head__type_6_interrupt;
  };
  goto set__head__type_6_interrupt;
 case VARREF:
  deref_and_jump(x0,set__head__type_6_2);
  *reasonp++ =  x0;
  goto set__head__type_6_interrupt;
  };
  goto set__head__type_6_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto set__head__type_6_interrupt;
  unify2(a3, a2, a5, a4);
  proceed();
 case VARREF:
  deref_and_jump(a1,set__head__type_6_1);
  *reasonp++ =  a1;
  goto set__head__type_6_interrupt;
  };
  goto set__head__type_6_interrupt;
 set__head__type_6_ext_interrupt:
  reasonp = 0l;
 set__head__type_6_interrupt:
  goto interrupt_6;
 }

 get__types_17_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  qp = qp->next;
 get__types_17_clear_reason:
  reasonp = reasons;
 get__types_17_0:
 get__types_17_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 get__types_17_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto get__types_17_7;
  x1 = arg(x0, 0);
 get__types_17_3:
  if (isref(x1)) goto get__types_17_6;
 get__types_17_4:
  if (isref(x1)) goto get__types_17_5;
  if_not_equal(x1, a1, get__types_17_7);
  a0 = arg(x0, 1);
  a1 = x1;
  execute(get__types__namelist_17_clear_reason);
  goto get__types__namelist_17_ext_interrupt;
 get__types_17_5:
  deref_and_jump(x1,get__types_17_4);
  *reasonp++ =  x1;
  goto get__types_17_7;
 get__types_17_6:
  deref_and_jump(x1,get__types_17_3);
  *reasonp++ =  x1;
  goto get__types_17_7;
 case VARREF:
  deref_and_jump(x0,get__types_17_2);
  *reasonp++ =  x0;
  goto get__types_17_7;
  };
  goto get__types_17_7;
 case VARREF:
  deref_and_jump(a0,get__types_17_1);
  *reasonp++ =  a0;
  goto get__types_17_7;
  };
  goto get__types_17_7;
 get__types_17_7:
  otherwise(get__types_17_interrupt);
 get__types_17_8:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(get__types_17_0);
  goto get__types_17_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto get__types_17_interrupt;
  x0 = makesym(atom_error);
  unify(x0, makesym(atom_get__types));
  proceed();
 case VARREF:
  deref_and_jump(a0,get__types_17_8);
  *reasonp++ =  a0;
  goto get__types_17_interrupt;
  };
  goto get__types_17_interrupt;
 get__types_17_ext_interrupt:
  reasonp = 0l;
 get__types_17_interrupt:
  goto interrupt_17;
 }

 get__types__namelist_17_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  qp = qp->next;
 get__types__namelist_17_clear_reason:
  reasonp = reasons;
 get__types__namelist_17_0:
 get__types__namelist_17_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 get__types__namelist_17_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_goal_4)) goto get__types__namelist_17_20;
  x1 = arg(x0, 0);
 get__types__namelist_17_3:
  if (isref(x1)) goto get__types__namelist_17_19;
 get__types__namelist_17_4:
  if (isref(x1)) goto get__types__namelist_17_18;
  if_not_equal(x1, a2, get__types__namelist_17_10);
  x2 = arg(x0, 1);
 get__types__namelist_17_5:
  if (isref(x2)) goto get__types__namelist_17_9;
 get__types__namelist_17_6:
  if (isref(x2)) goto get__types__namelist_17_8;
  if_not_equal(x2, a3, get__types__namelist_17_10);
 get__types__namelist_17_7:
  switch (ptagof(a7)) {
 case ATOMIC:
  if (a7 != makesym(atom_i)) goto get__types__namelist_17_10;
  unify_value(a5, makecons(cons_const_0));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xget__types__body_15);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = NILATOM;
  allocp[4] = a6;
  allocp[5] = a8;
  allocp[6] = a9;
  allocp[7] = a10;
  allocp[8] = a11;
  allocp[9] = a12;
  allocp[10] = a1;
  allocp[11] = x1;
  allocp[12] = x2;
  allocp[13] = a13;
  allocp[14] = a14;
  allocp[15] = a15;
  allocp[16] = a16;
  allocp[17] = (q)(struct goalrec*)&allocp[0];
  allocp[18] = (q)(&predicate_functor__table_xarg_3);
  allocp[19] = a4;
  x4 = arg(x0, 3);
  allocp[20] = x4;
  allocp[21] = x3;
  qp = (struct goalrec*)&allocp[17];
  allocp += 22;
  proceed();
 case VARREF:
  deref_and_jump(a7,get__types__namelist_17_7);
  *reasonp++ =  a7;
  goto get__types__namelist_17_10;
  };
  goto get__types__namelist_17_10;
 get__types__namelist_17_8:
  deref_and_jump(x2,get__types__namelist_17_6);
  *reasonp++ =  x2;
  goto get__types__namelist_17_10;
 get__types__namelist_17_9:
  deref_and_jump(x2,get__types__namelist_17_5);
  *reasonp++ =  x2;
  goto get__types__namelist_17_10;
 get__types__namelist_17_10:
 get__types__namelist_17_11:
  if (isref(x1)) goto get__types__namelist_17_17;
  if_not_equal(x1, a2, get__types__namelist_17_20);
  x2 = arg(x0, 1);
 get__types__namelist_17_12:
  if (isref(x2)) goto get__types__namelist_17_16;
 get__types__namelist_17_13:
  if (isref(x2)) goto get__types__namelist_17_15;
  if_not_equal(x2, a3, get__types__namelist_17_20);
 get__types__namelist_17_14:
  switch (ptagof(a7)) {
 case ATOMIC:
  if (a7 != makesym(atom_o)) goto get__types__namelist_17_20;
  unify_value(a6, makecons(cons_const_0));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xget__types__head_15);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = NILATOM;
  allocp[4] = a5;
  allocp[5] = a8;
  allocp[6] = a9;
  allocp[7] = a10;
  allocp[8] = a11;
  allocp[9] = a12;
  allocp[10] = a1;
  allocp[11] = x1;
  allocp[12] = x2;
  allocp[13] = a13;
  allocp[14] = a14;
  allocp[15] = a15;
  allocp[16] = a16;
  allocp[17] = (q)(struct goalrec*)&allocp[0];
  allocp[18] = (q)(&predicate_functor__table_xarg_3);
  allocp[19] = a4;
  x4 = arg(x0, 2);
  allocp[20] = x4;
  allocp[21] = x3;
  qp = (struct goalrec*)&allocp[17];
  allocp += 22;
  proceed();
 case VARREF:
  deref_and_jump(a7,get__types__namelist_17_14);
  *reasonp++ =  a7;
  goto get__types__namelist_17_20;
  };
  goto get__types__namelist_17_20;
 get__types__namelist_17_15:
  deref_and_jump(x2,get__types__namelist_17_13);
  *reasonp++ =  x2;
  goto get__types__namelist_17_20;
 get__types__namelist_17_16:
  deref_and_jump(x2,get__types__namelist_17_12);
  *reasonp++ =  x2;
  goto get__types__namelist_17_20;
 get__types__namelist_17_17:
  deref_and_jump(x1,get__types__namelist_17_11);
  *reasonp++ =  x1;
  goto get__types__namelist_17_20;
 get__types__namelist_17_18:
  deref_and_jump(x1,get__types__namelist_17_4);
  *reasonp++ =  x1;
  goto get__types__namelist_17_20;
 get__types__namelist_17_19:
  deref_and_jump(x1,get__types__namelist_17_3);
  *reasonp++ =  x1;
  goto get__types__namelist_17_20;
 case VARREF:
  deref_and_jump(x0,get__types__namelist_17_2);
  *reasonp++ =  x0;
  goto get__types__namelist_17_20;
  };
  goto get__types__namelist_17_20;
 case VARREF:
  deref_and_jump(a0,get__types__namelist_17_1);
  *reasonp++ =  a0;
  goto get__types__namelist_17_20;
  };
  goto get__types__namelist_17_20;
 get__types__namelist_17_20:
  otherwise(get__types__namelist_17_interrupt);
 get__types__namelist_17_21:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(get__types__namelist_17_0);
  goto get__types__namelist_17_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto get__types__namelist_17_interrupt;
  unify_value(a5, makecons(cons_const_0));
  unify_value(a6, makecons(cons_const_0));
  unify4(a9, a8, a11, a10, a14, a13, a16, a15);
  proceed();
 case VARREF:
  deref_and_jump(a0,get__types__namelist_17_21);
  *reasonp++ =  a0;
  goto get__types__namelist_17_interrupt;
  };
  goto get__types__namelist_17_interrupt;
 get__types__namelist_17_ext_interrupt:
  reasonp = 0l;
 get__types__namelist_17_interrupt:
  toppred = &predicate_unify__head__body_xget__types__namelist_17;
  goto interrupt_17;
 }

 get__types__body_15_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  qp = qp->next;
 get__types__body_15_clear_reason:
  reasonp = reasons;
 get__types__body_15_0:
 get__types__body_15_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 get__types__body_15_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_arg_5:
  x1 = arg(x0, 4);
 get__types__body_15_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_variable_3)) goto get__types__body_15_6;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xget__types__body_15);
  x2 = cdr_of(a0);
  allocp[2] = x2;
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  x4 = arg(x0, 0);
  allocp[10] = x4;
  allocp[11] = a9;
  allocp[12] = a10;
  allocp[13] = a11;
  allocp[14] = a12;
  allocp[15] = a13;
  allocp[16] = a14;
  allocp[17] = (q)(struct goalrec*)&allocp[0];
  allocp[18] = (q)(&predicate_type_xor__types_3);
  allocp[19] = a1;
  allocp[20] = x5 = makeref(&allocp[20]);
  allocp[21] = x3;
  allocp[22] = (q)(struct goalrec*)&allocp[17];
  allocp[23] = (q)(&predicate_type_xget__types_5);
  allocp[24] = x4;
  x6 = arg(x0, 1);
  allocp[25] = x6;
  x7 = arg(x1, 0);
  allocp[26] = x7;
  allocp[27] = a3;
  allocp[28] = x5;
  qp = (struct goalrec*)&allocp[22];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(x1,get__types__body_15_3);
  *reasonp++ =  x1;
  goto get__types__body_15_6;
  };
  goto get__types__body_15_6;
 case functor_looparg_5:
  x1 = arg(x0, 4);
 get__types__body_15_4:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_variable_3)) goto get__types__body_15_6;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xget__types__body_15);
  x2 = cdr_of(a0);
  allocp[2] = x2;
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x4 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x5 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  allocp[12] = a10;
  allocp[13] = x6 = makeref(&allocp[13]);
  allocp[14] = a12;
  allocp[15] = x7 = makeref(&allocp[15]);
  allocp[16] = a14;
  allocp[17] = (q)(struct goalrec*)&allocp[0];
  allocp[18] = (q)(&predicate_type_xor__types_3);
  allocp[19] = a1;
  allocp[20] = x8 = makeref(&allocp[20]);
  allocp[21] = x3;
  allocp[22] = makesym(functor_goal_4);
  allocp[23] = a8;
  allocp[24] = arg(x0, 1);
  allocp[25] = arg(x0, 3);
  allocp[26] = makesym(atom_body);
  x9 = makefunctor(&allocp[22]);
  allocp[27] = (q)(struct goalrec*)&allocp[17];
  allocp[28] = (q)(&predicate_unify__head__body_xexpand__looped__goal_15);
  allocp[29] = a8;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = x9;
  allocp[33] = a3;
  allocp[34] = x4;
  allocp[35] = a5;
  allocp[36] = x5;
  allocp[37] = a7;
  allocp[38] = x10 = makeref(&allocp[38]);
  allocp[39] = x8;
  allocp[40] = a11;
  allocp[41] = x6;
  allocp[42] = a13;
  allocp[43] = x7;
  allocp[44] = (q)(struct goalrec*)&allocp[27];
  allocp[45] = (q)(&predicate_type_xget__types_5);
  x11 = arg(x0, 0);
  allocp[46] = x11;
  x12 = arg(x0, 1);
  allocp[47] = x12;
  x13 = arg(x1, 0);
  allocp[48] = x13;
  allocp[49] = a3;
  allocp[50] = x10;
  qp = (struct goalrec*)&allocp[44];
  allocp += 51;
  proceed();
 case VARREF:
  deref_and_jump(x1,get__types__body_15_4);
  *reasonp++ =  x1;
  goto get__types__body_15_6;
  };
  goto get__types__body_15_6;
 case functor_sharedarg_5:
  x1 = arg(x0, 4);
 get__types__body_15_5:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_variable_3)) goto get__types__body_15_6;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xget__types__body_15);
  x2 = cdr_of(a0);
  allocp[2] = x2;
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x4 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x5 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  allocp[12] = a10;
  allocp[13] = x6 = makeref(&allocp[13]);
  allocp[14] = a12;
  allocp[15] = x7 = makeref(&allocp[15]);
  allocp[16] = a14;
  allocp[17] = (q)(struct goalrec*)&allocp[0];
  allocp[18] = (q)(&predicate_type_xor__types_3);
  allocp[19] = a1;
  allocp[20] = x8 = makeref(&allocp[20]);
  allocp[21] = x3;
  allocp[22] = makesym(functor_goal_4);
  allocp[23] = a8;
  allocp[24] = arg(x0, 1);
  allocp[25] = arg(x0, 3);
  allocp[26] = makesym(atom_body);
  x9 = makefunctor(&allocp[22]);
  allocp[27] = (q)(struct goalrec*)&allocp[17];
  allocp[28] = (q)(&predicate_unify__head__body_xexpand__looped__goal_15);
  allocp[29] = a8;
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = x9;
  allocp[33] = a3;
  allocp[34] = x4;
  allocp[35] = a5;
  allocp[36] = x5;
  allocp[37] = a7;
  allocp[38] = x10 = makeref(&allocp[38]);
  allocp[39] = x8;
  allocp[40] = a11;
  allocp[41] = x6;
  allocp[42] = a13;
  allocp[43] = x7;
  allocp[44] = (q)(struct goalrec*)&allocp[27];
  allocp[45] = (q)(&predicate_type_xget__types_5);
  x11 = arg(x0, 0);
  allocp[46] = x11;
  x12 = arg(x0, 1);
  allocp[47] = x12;
  x13 = arg(x1, 0);
  allocp[48] = x13;
  allocp[49] = a3;
  allocp[50] = x10;
  qp = (struct goalrec*)&allocp[44];
  allocp += 51;
  proceed();
 case VARREF:
  deref_and_jump(x1,get__types__body_15_5);
  *reasonp++ =  x1;
  goto get__types__body_15_6;
  };
  goto get__types__body_15_6;
  };
  goto get__types__body_15_6;
 case VARREF:
  deref_and_jump(x0,get__types__body_15_2);
  *reasonp++ =  x0;
  goto get__types__body_15_6;
  };
  goto get__types__body_15_6;
 case VARREF:
  deref_and_jump(a0,get__types__body_15_1);
  *reasonp++ =  a0;
  goto get__types__body_15_6;
  };
  goto get__types__body_15_6;
 get__types__body_15_6:
  otherwise(get__types__body_15_interrupt);
 get__types__body_15_7:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 get__types__body_15_8:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_arg_5:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xget__types__body_15);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  allocp[12] = a10;
  allocp[13] = a11;
  allocp[14] = a12;
  allocp[15] = a13;
  allocp[16] = a14;
  allocp[17] = (q)(struct goalrec*)&allocp[0];
  allocp[18] = (q)(&predicate_type_xor__types_3);
  allocp[19] = a1;
  allocp[20] = x3 = makeref(&allocp[20]);
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[17];
  allocp[23] = (q)(&predicate_type_xvalue2types_7);
  x4 = arg(x0, 0);
  allocp[24] = x4;
  x5 = arg(x0, 1);
  allocp[25] = x5;
  x6 = arg(x0, 4);
  allocp[26] = x6;
  allocp[27] = NILATOM;
  allocp[28] = NILATOM;
  allocp[29] = makesym(atom_u);
  allocp[30] = x3;
  qp = (struct goalrec*)&allocp[22];
  allocp += 31;
  proceed();
 case functor_looparg_5:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xget__types__body_15);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  allocp[12] = a10;
  allocp[13] = a11;
  allocp[14] = a12;
  allocp[15] = a13;
  allocp[16] = a14;
  allocp[17] = (q)(struct goalrec*)&allocp[0];
  allocp[18] = (q)(&predicate_type_xor__types_3);
  allocp[19] = a1;
  allocp[20] = x3 = makeref(&allocp[20]);
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[17];
  allocp[23] = (q)(&predicate_type_xvalue2types_7);
  x4 = arg(x0, 0);
  allocp[24] = x4;
  x5 = arg(x0, 1);
  allocp[25] = x5;
  x6 = arg(x0, 4);
  allocp[26] = x6;
  allocp[27] = NILATOM;
  allocp[28] = NILATOM;
  allocp[29] = makesym(atom_u);
  allocp[30] = x3;
  qp = (struct goalrec*)&allocp[22];
  allocp += 31;
  proceed();
 case functor_sharedarg_5:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xget__types__body_15);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  allocp[12] = a10;
  allocp[13] = a11;
  allocp[14] = a12;
  allocp[15] = a13;
  allocp[16] = a14;
  allocp[17] = (q)(struct goalrec*)&allocp[0];
  allocp[18] = (q)(&predicate_type_xor__types_3);
  allocp[19] = a1;
  allocp[20] = x3 = makeref(&allocp[20]);
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[17];
  allocp[23] = (q)(&predicate_type_xvalue2types_7);
  x4 = arg(x0, 0);
  allocp[24] = x4;
  x5 = arg(x0, 1);
  allocp[25] = x5;
  x6 = arg(x0, 4);
  allocp[26] = x6;
  allocp[27] = NILATOM;
  allocp[28] = NILATOM;
  allocp[29] = makesym(atom_u);
  allocp[30] = x3;
  qp = (struct goalrec*)&allocp[22];
  allocp += 31;
  proceed();
  };
  goto get__types__body_15_interrupt;
 case VARREF:
  deref_and_jump(x0,get__types__body_15_8);
  *reasonp++ =  x0;
  goto get__types__body_15_interrupt;
  };
  goto get__types__body_15_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto get__types__body_15_interrupt;
  unify4(a2, a1, a4, a3, a6, a5, a12, a11);
  unify(a14, a13);
  proceed();
 case VARREF:
  deref_and_jump(a0,get__types__body_15_7);
  *reasonp++ =  a0;
  goto get__types__body_15_interrupt;
  };
  goto get__types__body_15_interrupt;
 get__types__body_15_ext_interrupt:
  reasonp = 0l;
 get__types__body_15_interrupt:
  goto interrupt_15;
 }

 expand__looped__goal_15_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  qp = qp->next;
 expand__looped__goal_15_clear_reason:
  reasonp = reasons;
 expand__looped__goal_15_0:
 expand__looped__goal_15_1:
  switch (ptagof(a9)) {
 case CONS:
  x0 = car_of(a9);
 expand__looped__goal_15_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__3F)) goto expand__looped__goal_15_interrupt;
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = makesym(atom__3F);
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a10, x1);
  a9 = cdr_of(a9);
  a10 = x2;
  execute(expand__looped__goal_15_0);
  goto expand__looped__goal_15_ext_interrupt;
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_4)) goto expand__looped__goal_15_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xexpand__looped__goal_15);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = a8;
  x3 = cdr_of(a9);
  allocp[11] = x3;
  allocp[12] = x4 = makeref(&allocp[12]);
  allocp[13] = x5 = makeref(&allocp[13]);
  allocp[14] = a12;
  allocp[15] = x6 = makeref(&allocp[15]);
  allocp[16] = a14;
  allocp[17] = x4;
  allocp[18] = x8 = makeref(&allocp[18]);
  x7 = makecons(&allocp[17]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 19;
  unify_value(a10, x7);
  unify(a12, a11);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_type_xmake__type__loopdown_16);
  allocp[2] = x0;
  allocp[3] = x8;
  allocp[4] = a0;
  allocp[5] = a1;
  allocp[6] = a2;
  allocp[7] = a3;
  allocp[8] = a3;
  allocp[9] = a4;
  allocp[10] = x1;
  allocp[11] = a6;
  allocp[12] = x2;
  allocp[13] = a8;
  allocp[14] = a11;
  allocp[15] = x5;
  allocp[16] = a13;
  allocp[17] = x6;
  qp = (struct goalrec*)&allocp[0];
  allocp += 18;
  proceed();
 case VARREF:
  deref_and_jump(x0,expand__looped__goal_15_2);
  *reasonp++ =  x0;
  goto expand__looped__goal_15_interrupt;
  };
  goto expand__looped__goal_15_interrupt;
 case ATOMIC:
  if (a9 != NILATOM) goto expand__looped__goal_15_interrupt;
  unify2(a5, a4, a7, a6);
  unify_value(a10, NILATOM);
  unify2(a12, a11, a14, a13);
  proceed();
 case VARREF:
  deref_and_jump(a9,expand__looped__goal_15_1);
  *reasonp++ =  a9;
  goto expand__looped__goal_15_interrupt;
  };
  goto expand__looped__goal_15_interrupt;
 expand__looped__goal_15_ext_interrupt:
  reasonp = 0l;
 expand__looped__goal_15_interrupt:
  goto interrupt_15;
 }

 get__types__head_15_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  qp = qp->next;
 get__types__head_15_clear_reason:
  reasonp = reasons;
 get__types__head_15_0:
 get__types__head_15_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 get__types__head_15_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_arg_5:
  x1 = arg(x0, 4);
 get__types__head_15_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_variable_3)) goto get__types__head_15_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xget__types__head_15);
  x2 = cdr_of(a0);
  allocp[2] = x2;
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  x4 = arg(x0, 0);
  allocp[10] = x4;
  allocp[11] = a9;
  allocp[12] = a10;
  allocp[13] = a11;
  allocp[14] = a12;
  allocp[15] = a13;
  allocp[16] = a14;
  allocp[17] = (q)(struct goalrec*)&allocp[0];
  allocp[18] = (q)(&predicate_type_xor__types_3);
  allocp[19] = a1;
  allocp[20] = x5 = makeref(&allocp[20]);
  allocp[21] = x3;
  allocp[22] = (q)(struct goalrec*)&allocp[17];
  allocp[23] = (q)(&predicate_type_xget__types_5);
  allocp[24] = x4;
  x6 = arg(x0, 1);
  allocp[25] = x6;
  x7 = arg(x1, 0);
  allocp[26] = x7;
  allocp[27] = a3;
  allocp[28] = x5;
  qp = (struct goalrec*)&allocp[22];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(x1,get__types__head_15_3);
  *reasonp++ =  x1;
  goto get__types__head_15_interrupt;
  };
  goto get__types__head_15_interrupt;
 case functor_looparg_5:
  x1 = arg(x0, 4);
 get__types__head_15_4:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_variable_3)) goto get__types__head_15_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xget__types__head_15);
  x2 = cdr_of(a0);
  allocp[2] = x2;
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  x4 = arg(x0, 0);
  allocp[10] = x4;
  allocp[11] = a9;
  allocp[12] = a10;
  allocp[13] = a11;
  allocp[14] = a12;
  allocp[15] = a13;
  allocp[16] = a14;
  allocp[17] = (q)(struct goalrec*)&allocp[0];
  allocp[18] = (q)(&predicate_type_xor__types_3);
  allocp[19] = a1;
  allocp[20] = x5 = makeref(&allocp[20]);
  allocp[21] = x3;
  allocp[22] = (q)(struct goalrec*)&allocp[17];
  allocp[23] = (q)(&predicate_type_xget__types_5);
  allocp[24] = x4;
  x6 = arg(x0, 1);
  allocp[25] = x6;
  x7 = arg(x1, 0);
  allocp[26] = x7;
  allocp[27] = a3;
  allocp[28] = x5;
  qp = (struct goalrec*)&allocp[22];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(x1,get__types__head_15_4);
  *reasonp++ =  x1;
  goto get__types__head_15_interrupt;
  };
  goto get__types__head_15_interrupt;
 case functor_sharedarg_5:
  x1 = arg(x0, 4);
 get__types__head_15_5:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_variable_3)) goto get__types__head_15_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xget__types__head_15);
  x2 = cdr_of(a0);
  allocp[2] = x2;
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  x4 = arg(x0, 0);
  allocp[10] = x4;
  allocp[11] = a9;
  allocp[12] = a10;
  allocp[13] = a11;
  allocp[14] = a12;
  allocp[15] = a13;
  allocp[16] = a14;
  allocp[17] = (q)(struct goalrec*)&allocp[0];
  allocp[18] = (q)(&predicate_type_xor__types_3);
  allocp[19] = a1;
  allocp[20] = x5 = makeref(&allocp[20]);
  allocp[21] = x3;
  allocp[22] = (q)(struct goalrec*)&allocp[17];
  allocp[23] = (q)(&predicate_type_xget__types_5);
  allocp[24] = x4;
  x6 = arg(x0, 1);
  allocp[25] = x6;
  x7 = arg(x1, 0);
  allocp[26] = x7;
  allocp[27] = a3;
  allocp[28] = x5;
  qp = (struct goalrec*)&allocp[22];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(x1,get__types__head_15_5);
  *reasonp++ =  x1;
  goto get__types__head_15_interrupt;
  };
  goto get__types__head_15_interrupt;
  };
  goto get__types__head_15_interrupt;
 case VARREF:
  deref_and_jump(x0,get__types__head_15_2);
  *reasonp++ =  x0;
  goto get__types__head_15_interrupt;
  };
  goto get__types__head_15_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto get__types__head_15_interrupt;
  unify4(a2, a1, a4, a3, a6, a5, a12, a11);
  unify(a14, a13);
  proceed();
 case VARREF:
  deref_and_jump(a0,get__types__head_15_1);
  *reasonp++ =  a0;
  goto get__types__head_15_interrupt;
  };
  goto get__types__head_15_interrupt;
 get__types__head_15_ext_interrupt:
  reasonp = 0l;
 get__types__head_15_interrupt:
  goto interrupt_15;
 }

 check__only__vars_2_top: {
  q x0, x1;
  qp = qp->next;
 check__only__vars_2_clear_reason:
  reasonp = reasons;
 check__only__vars_2_0:
  x0 = a0;
  x1 = a0;
  a2 = a1;
  a1 = x1;
  a0 = x0;
  execute(check__only__vars1_3_0);
  goto check__only__vars1_3_ext_interrupt;
 check__only__vars_2_ext_interrupt:
  reasonp = 0l;
 check__only__vars_2_interrupt:
  goto interrupt_2;
 }

 check__only__vars1_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 check__only__vars1_3_clear_reason:
  reasonp = reasons;
 check__only__vars1_3_0:
 check__only__vars1_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 check__only__vars1_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_3)) goto check__only__vars1_3_4;
  x1 = arg(x0, 0);
 check__only__vars1_3_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_v_4)) goto check__only__vars1_3_4;
  a0 = cdr_of(a0);
  execute(check__only__vars1_3_0);
  goto check__only__vars1_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,check__only__vars1_3_3);
  *reasonp++ =  x1;
  goto check__only__vars1_3_4;
  };
  goto check__only__vars1_3_4;
 case VARREF:
  deref_and_jump(x0,check__only__vars1_3_2);
  *reasonp++ =  x0;
  goto check__only__vars1_3_4;
  };
  goto check__only__vars1_3_4;
 case VARREF:
  deref_and_jump(a0,check__only__vars1_3_1);
  *reasonp++ =  a0;
  goto check__only__vars1_3_4;
  };
  goto check__only__vars1_3_4;
 check__only__vars1_3_4:
  otherwise(check__only__vars1_3_interrupt);
 check__only__vars1_3_5:
  switch (ptagof(a0)) {
 case CONS:
  unify(a2, a1);
  proceed();
 case ATOMIC:
  if (a0 != NILATOM) goto check__only__vars1_3_interrupt;
  unify_value(a2, makecons(cons_const_0));
  proceed();
 case VARREF:
  deref_and_jump(a0,check__only__vars1_3_5);
  *reasonp++ =  a0;
  goto check__only__vars1_3_interrupt;
  };
  goto check__only__vars1_3_interrupt;
 check__only__vars1_3_ext_interrupt:
  reasonp = 0l;
 check__only__vars1_3_interrupt:
  toppred = &predicate_unify__head__body_xcheck__only__vars1_3;
  goto interrupt_3;
 }

 make__direct__type_2_top: {
  qp = qp->next;
 make__direct__type_2_clear_reason:
  reasonp = reasons;
 make__direct__type_2_0:
  a2 = a1;
  a1 = NILATOM;
  execute(make__direct__type1_3_0);
  goto make__direct__type1_3_ext_interrupt;
 make__direct__type_2_ext_interrupt:
  reasonp = 0l;
 make__direct__type_2_interrupt:
  goto interrupt_2;
 }

 make__direct__type1_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  qp = qp->next;
 make__direct__type1_3_clear_reason:
  reasonp = reasons;
 make__direct__type1_3_0:
 make__direct__type1_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 make__direct__type1_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_arg_5:
  x1 = arg(x0, 4);
 make__direct__type1_3_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_variable_3)) goto make__direct__type1_3_6;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xmake__direct__type1_3);
  x2 = cdr_of(a0);
  allocp[2] = x2;
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_type_xor__types_3);
  allocp[7] = a1;
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = x3;
  allocp[10] = makesym(functor_variable_3);
  allocp[11] = arg(x1, 0);
  allocp[12] = arg(x1, 1);
  allocp[13] = makesym(atom_i);
  x5 = makefunctor(&allocp[10]);
  allocp[14] = (q)(struct goalrec*)&allocp[5];
  allocp[15] = (q)(&predicate_type_xvalue2types_7);
  x6 = arg(x0, 0);
  allocp[16] = x6;
  x7 = arg(x0, 1);
  allocp[17] = x7;
  allocp[18] = x5;
  allocp[19] = NILATOM;
  allocp[20] = NILATOM;
  allocp[21] = makesym(atom__3F);
  allocp[22] = x4;
  qp = (struct goalrec*)&allocp[14];
  allocp += 23;
  proceed();
 case VARREF:
  deref_and_jump(x1,make__direct__type1_3_3);
  *reasonp++ =  x1;
  goto make__direct__type1_3_6;
  };
  goto make__direct__type1_3_6;
 case functor_looparg_5:
  x1 = arg(x0, 4);
 make__direct__type1_3_4:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_variable_3)) goto make__direct__type1_3_6;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xmake__direct__type1_3);
  x2 = cdr_of(a0);
  allocp[2] = x2;
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_type_xor__types_3);
  allocp[7] = a1;
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = x3;
  allocp[10] = makesym(functor_variable_3);
  allocp[11] = arg(x1, 0);
  allocp[12] = arg(x1, 1);
  allocp[13] = makesym(atom_i);
  x5 = makefunctor(&allocp[10]);
  allocp[14] = (q)(struct goalrec*)&allocp[5];
  allocp[15] = (q)(&predicate_type_xvalue2types_7);
  x6 = arg(x0, 0);
  allocp[16] = x6;
  x7 = arg(x0, 1);
  allocp[17] = x7;
  allocp[18] = x5;
  allocp[19] = NILATOM;
  allocp[20] = NILATOM;
  allocp[21] = makesym(atom__3F);
  allocp[22] = x4;
  qp = (struct goalrec*)&allocp[14];
  allocp += 23;
  proceed();
 case VARREF:
  deref_and_jump(x1,make__direct__type1_3_4);
  *reasonp++ =  x1;
  goto make__direct__type1_3_6;
  };
  goto make__direct__type1_3_6;
 case functor_sharedarg_5:
  x1 = arg(x0, 4);
 make__direct__type1_3_5:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_variable_3)) goto make__direct__type1_3_6;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xmake__direct__type1_3);
  x2 = cdr_of(a0);
  allocp[2] = x2;
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_type_xor__types_3);
  allocp[7] = a1;
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = x3;
  allocp[10] = makesym(functor_variable_3);
  allocp[11] = arg(x1, 0);
  allocp[12] = arg(x1, 1);
  allocp[13] = makesym(atom_i);
  x5 = makefunctor(&allocp[10]);
  allocp[14] = (q)(struct goalrec*)&allocp[5];
  allocp[15] = (q)(&predicate_type_xvalue2types_7);
  x6 = arg(x0, 0);
  allocp[16] = x6;
  x7 = arg(x0, 1);
  allocp[17] = x7;
  allocp[18] = x5;
  allocp[19] = NILATOM;
  allocp[20] = NILATOM;
  allocp[21] = makesym(atom__3F);
  allocp[22] = x4;
  qp = (struct goalrec*)&allocp[14];
  allocp += 23;
  proceed();
 case VARREF:
  deref_and_jump(x1,make__direct__type1_3_5);
  *reasonp++ =  x1;
  goto make__direct__type1_3_6;
  };
  goto make__direct__type1_3_6;
  };
  goto make__direct__type1_3_6;
 case VARREF:
  deref_and_jump(x0,make__direct__type1_3_2);
  *reasonp++ =  x0;
  goto make__direct__type1_3_6;
  };
  goto make__direct__type1_3_6;
 case VARREF:
  deref_and_jump(a0,make__direct__type1_3_1);
  *reasonp++ =  a0;
  goto make__direct__type1_3_6;
  };
  goto make__direct__type1_3_6;
 make__direct__type1_3_6:
  otherwise(make__direct__type1_3_interrupt);
 make__direct__type1_3_7:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 make__direct__type1_3_8:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_arg_5:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xmake__direct__type1_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_type_xor__types_3);
  allocp[7] = a1;
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = x2;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_type_xvalue2types_7);
  x4 = arg(x0, 0);
  allocp[12] = x4;
  x5 = arg(x0, 1);
  allocp[13] = x5;
  x6 = arg(x0, 4);
  allocp[14] = x6;
  allocp[15] = NILATOM;
  allocp[16] = NILATOM;
  allocp[17] = makesym(atom_u);
  allocp[18] = x3;
  qp = (struct goalrec*)&allocp[10];
  allocp += 19;
  proceed();
 case functor_looparg_5:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xmake__direct__type1_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_type_xor__types_3);
  allocp[7] = a1;
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = x2;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_type_xvalue2types_7);
  x4 = arg(x0, 0);
  allocp[12] = x4;
  x5 = arg(x0, 1);
  allocp[13] = x5;
  x6 = arg(x0, 4);
  allocp[14] = x6;
  allocp[15] = NILATOM;
  allocp[16] = NILATOM;
  allocp[17] = makesym(atom_u);
  allocp[18] = x3;
  qp = (struct goalrec*)&allocp[10];
  allocp += 19;
  proceed();
 case functor_sharedarg_5:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xmake__direct__type1_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_type_xor__types_3);
  allocp[7] = a1;
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = x2;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_type_xvalue2types_7);
  x4 = arg(x0, 0);
  allocp[12] = x4;
  x5 = arg(x0, 1);
  allocp[13] = x5;
  x6 = arg(x0, 4);
  allocp[14] = x6;
  allocp[15] = NILATOM;
  allocp[16] = NILATOM;
  allocp[17] = makesym(atom_u);
  allocp[18] = x3;
  qp = (struct goalrec*)&allocp[10];
  allocp += 19;
  proceed();
  };
  goto make__direct__type1_3_interrupt;
 case VARREF:
  deref_and_jump(x0,make__direct__type1_3_8);
  *reasonp++ =  x0;
  goto make__direct__type1_3_interrupt;
  };
  goto make__direct__type1_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto make__direct__type1_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,make__direct__type1_3_7);
  *reasonp++ =  a0;
  goto make__direct__type1_3_interrupt;
  };
  goto make__direct__type1_3_interrupt;
 make__direct__type1_3_ext_interrupt:
  reasonp = 0l;
 make__direct__type1_3_interrupt:
  toppred = &predicate_unify__head__body_xmake__direct__type1_3;
  goto interrupt_3;
 }

 check__shared_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 check__shared_4_clear_reason:
  reasonp = reasons;
 check__shared_4_0:
 check__shared_4_1:
  switch (ptagof(a2)) {
 case CONS:
  x0 = car_of(a2);
 check__shared_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto check__shared_4_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xcheck__shared_4);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  x2 = cdr_of(a2);
  allocp[4] = x2;
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = makesym(functor_module_2);
  allocp[7] = arg(x0, 0);
  allocp[8] = x5 = makeref(&allocp[8]);
  x4 = makefunctor(&allocp[6]);
  allocp[9] = x3;
  allocp[10] = x4;
  x6 = makecons(&allocp[9]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 11;
  unify_value(a3, x6);
  x7 = arg(x0, 1);
  a1 = x5;
  a2 = a0;
  a3 = x1;
  a0 = x7;
  execute(check__shared__hbs_4_0);
  goto check__shared__hbs_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,check__shared_4_2);
  *reasonp++ =  x0;
  goto check__shared_4_interrupt;
  };
  goto check__shared_4_interrupt;
 case ATOMIC:
  if (a2 != NILATOM) goto check__shared_4_interrupt;
  unify(a1, a0);
  unify_value(a3, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a2,check__shared_4_1);
  *reasonp++ =  a2;
  goto check__shared_4_interrupt;
  };
  goto check__shared_4_interrupt;
 check__shared_4_ext_interrupt:
  reasonp = 0l;
 check__shared_4_interrupt:
  goto interrupt_4;
 }

 check__shared__hbs_4_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 check__shared__hbs_4_clear_reason:
  reasonp = reasons;
 check__shared__hbs_4_0:
 check__shared__hbs_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 check__shared__hbs_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_goal_4)) goto check__shared__hbs_4_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xcheck__shared__hbs_4);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x2;
  allocp[7] = x5 = makeref(&allocp[7]);
  x4 = makecons(&allocp[6]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  unify_value(a1, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = makeint(4L);
  allocp[3] = x0;
  allocp[4] = x6 = makeref(&allocp[4]);
  allocp[5] = x5;
  a0 = arg(x0, 3);
  a1 = x6;
  a3 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(check__shared__bodys_4_0);
  goto check__shared__bodys_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,check__shared__hbs_4_2);
  *reasonp++ =  x0;
  goto check__shared__hbs_4_interrupt;
  };
  goto check__shared__hbs_4_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto check__shared__hbs_4_interrupt;
  unify_value(a1, NILATOM);
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,check__shared__hbs_4_1);
  *reasonp++ =  a0;
  goto check__shared__hbs_4_interrupt;
  };
  goto check__shared__hbs_4_interrupt;
 check__shared__hbs_4_ext_interrupt:
  reasonp = 0l;
 check__shared__hbs_4_interrupt:
  toppred = &predicate_unify__head__body_xcheck__shared__hbs_4;
  goto interrupt_4;
 }

 check__shared__bodys_4_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 check__shared__bodys_4_clear_reason:
  reasonp = reasons;
 check__shared__bodys_4_0:
 check__shared__bodys_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_bodyargs)) goto check__shared__bodys_4_2;
  unify_value(a1, makesym(atom_bodyargs));
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,check__shared__bodys_4_1);
  *reasonp++ =  a0;
  goto check__shared__bodys_4_2;
  };
  goto check__shared__bodys_4_2;
 check__shared__bodys_4_2:
  otherwise(check__shared__bodys_4_interrupt);
 check__shared__bodys_4_3:
  if (isref(a0)) goto check__shared__bodys_4_6;
  gblt_arg(makeint(1L),a0,x0,check__shared__bodys_4_7);
 check__shared__bodys_4_4:
  switch (ptagof(x0)) {
 case CONS:
  x1 = cdr_of(x0);
 check__shared__bodys_4_5:
  switch (ptagof(x1)) {
 case CONS:
  execute(check__shared__bodys1_4_0);
  goto check__shared__bodys1_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,check__shared__bodys_4_5);
  *reasonp++ =  x1;
  goto check__shared__bodys_4_7;
  };
  goto check__shared__bodys_4_7;
 case VARREF:
  deref_and_jump(x0,check__shared__bodys_4_4);
  *reasonp++ =  x0;
  goto check__shared__bodys_4_7;
  };
  goto check__shared__bodys_4_7;
 check__shared__bodys_4_6:
  deref_and_jump(a0,check__shared__bodys_4_3);
  *reasonp++ =  a0;
  goto check__shared__bodys_4_7;
 check__shared__bodys_4_7:
  otherwise(check__shared__bodys_4_interrupt);
  unify2(a1, a0, a3, a2);
  proceed();
 check__shared__bodys_4_ext_interrupt:
  reasonp = 0l;
 check__shared__bodys_4_interrupt:
  toppred = &predicate_unify__head__body_xcheck__shared__bodys_4;
  goto interrupt_4;
 }

 check__shared__bodys1_4_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 check__shared__bodys1_4_clear_reason:
  reasonp = reasons;
 check__shared__bodys1_4_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xcheck__shared__bodys2_5);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[9] = a0;
  allocp[10] = x1 = makeref(&allocp[10]);
  allocp[11] = x0;
  qp = (struct goalrec*)&allocp[7];
  allocp += 12;
  proceed();
 check__shared__bodys1_4_ext_interrupt:
  reasonp = 0l;
 check__shared__bodys1_4_interrupt:
  toppred = &predicate_unify__head__body_xcheck__shared__bodys1_4;
  goto interrupt_4;
 }

 check__shared__bodys2_5_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 check__shared__bodys2_5_clear_reason:
  reasonp = reasons;
 check__shared__bodys2_5_0:
 check__shared__bodys2_5_1:
  if (!isint(a0)) goto check__shared__bodys2_5_3;
  gblt_greater(a0,makeint(0L),check__shared__bodys2_5_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xcheck__shared__bodys2_5);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[9] = a0;
  allocp[10] = makeint(1L);
  allocp[11] = x0;
  allocp[12] = (q)(struct goalrec*)&allocp[7];
  allocp[13] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = x3 = makeref(&allocp[16]);
  allocp[17] = x1;
  allocp[18] = (q)(struct goalrec*)&allocp[12];
  allocp[19] = (q)(&predicate_unify__head__body_xcheck__shared__bodys3_5);
  allocp[20] = a0;
  allocp[21] = x4 = makeref(&allocp[21]);
  allocp[22] = x3;
  allocp[23] = a3;
  allocp[24] = x2;
  allocp[25] = (q)(struct goalrec*)&allocp[18];
  allocp[26] = (q)(&predicate_functor__table_xarg_3);
  allocp[27] = a0;
  allocp[28] = a1;
  allocp[29] = x4;
  qp = (struct goalrec*)&allocp[25];
  allocp += 30;
  proceed();
 check__shared__bodys2_5_2:
  if (a0 != makeint(0L)) goto check__shared__bodys2_5_interrupt;
  unify2(a2, a1, a4, a3);
  proceed();
 check__shared__bodys2_5_3:
  if (!isref(a0)) goto check__shared__bodys2_5_interrupt;
  deref_and_jump(a0,check__shared__bodys2_5_1);
  *reasonp++ =  a0;
  goto check__shared__bodys2_5_interrupt;
 check__shared__bodys2_5_ext_interrupt:
  reasonp = 0l;
 check__shared__bodys2_5_interrupt:
  goto interrupt_5;
 }

 check__shared__bodys3_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 check__shared__bodys3_5_clear_reason:
  reasonp = reasons;
 check__shared__bodys3_5_0:
 check__shared__bodys3_5_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 check__shared__bodys3_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_looparg_5:
  x1 = arg(x0, 2);
 check__shared__bodys3_5_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_body)) goto check__shared__bodys3_5_interrupt;
  allocp[0] = x3 = makeref(&allocp[0]);
  allocp[1] = x0;
  x2 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x2);
  a1 = cdr_of(a1);
  a2 = x3;
  execute(check__shared__bodys3_5_0);
  goto check__shared__bodys3_5_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,check__shared__bodys3_5_3);
  *reasonp++ =  x1;
  goto check__shared__bodys3_5_interrupt;
  };
  goto check__shared__bodys3_5_interrupt;
 case functor_arg_5:
  x1 = arg(x0, 2);
 check__shared__bodys3_5_4:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_body)) goto check__shared__bodys3_5_interrupt;
 check__shared__bodys3_5_5:
  if (!isint(a0)) goto check__shared__bodys3_5_7;
  gblt_greater(a0,makeint(1L),check__shared__bodys3_5_6);
  allocp[0] = makesym(functor_sharedarg_5);
  allocp[1] = arg(x0, 0);
  allocp[2] = arg(x0, 1);
  allocp[3] = makesym(atom_body);
  allocp[4] = arg(x0, 3);
  allocp[5] = arg(x0, 4);
  x2 = makefunctor(&allocp[0]);
  allocp[6] = x4 = makeref(&allocp[6]);
  allocp[7] = x2;
  x3 = makecons(&allocp[6]);
  allocp += 8;
  unify_value(a2, x3);
  a1 = cdr_of(a1);
  a2 = x4;
  execute(check__shared__bodys3_5_0);
  goto check__shared__bodys3_5_ext_interrupt;
 check__shared__bodys3_5_6:
  if (a0 != makeint(1L)) goto check__shared__bodys3_5_interrupt;
  allocp[0] = makesym(functor_sharedarg_5);
  allocp[1] = arg(x0, 0);
  allocp[2] = arg(x0, 1);
  allocp[3] = makesym(atom_body);
  allocp[4] = arg(x0, 3);
  allocp[5] = arg(x0, 4);
  x5 = makefunctor(&allocp[0]);
  allocp[6] = x7 = makeref(&allocp[6]);
  allocp[7] = x5;
  x6 = makecons(&allocp[6]);
  allocp += 8;
  unify_value(a2, x6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unify__head__body_xcheck__shared__bodys3_5);
  allocp[2] = a0;
  x8 = cdr_of(a1);
  allocp[3] = x8;
  allocp[4] = x7;
  allocp[5] = x9 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_unify__head__body_xadd__shared_7);
  x10 = arg(x0, 0);
  allocp[9] = x10;
  x11 = arg(x0, 1);
  allocp[10] = x11;
  x12 = arg(x0, 3);
  allocp[11] = x12;
  allocp[12] = x13 = makeref(&allocp[12]);
  allocp[13] = x14 = makeref(&allocp[13]);
  allocp[14] = a3;
  allocp[15] = x9;
  allocp[16] = (q)(struct goalrec*)&allocp[7];
  allocp[17] = (q)(&predicate_parse__uty_xdecode__goal_3);
  allocp[18] = x15 = makeref(&allocp[18]);
  allocp[19] = x13;
  allocp[20] = x14;
  allocp[21] = (q)(struct goalrec*)&allocp[16];
  allocp[22] = (q)(&predicate_parse__uty_xget__goal_6);
  allocp[23] = x10;
  allocp[24] = x11;
  allocp[25] = x12;
  allocp[26] = makesym(atom_body);
  allocp[27] = x15;
  allocp[28] = a3;
  qp = (struct goalrec*)&allocp[21];
  allocp += 29;
  proceed();
 check__shared__bodys3_5_7:
  if (!isref(a0)) goto check__shared__bodys3_5_interrupt;
  deref_and_jump(a0,check__shared__bodys3_5_5);
  *reasonp++ =  a0;
  goto check__shared__bodys3_5_interrupt;
 case VARREF:
  deref_and_jump(x1,check__shared__bodys3_5_4);
  *reasonp++ =  x1;
  goto check__shared__bodys3_5_interrupt;
  };
  goto check__shared__bodys3_5_interrupt;
  };
  goto check__shared__bodys3_5_interrupt;
 case VARREF:
  deref_and_jump(x0,check__shared__bodys3_5_2);
  *reasonp++ =  x0;
  goto check__shared__bodys3_5_interrupt;
  };
  goto check__shared__bodys3_5_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto check__shared__bodys3_5_interrupt;
  unify_value(a2, NILATOM);
  unify(a4, a3);
  proceed();
 case VARREF:
  deref_and_jump(a1,check__shared__bodys3_5_1);
  *reasonp++ =  a1;
  goto check__shared__bodys3_5_interrupt;
  };
  goto check__shared__bodys3_5_interrupt;
 check__shared__bodys3_5_ext_interrupt:
  reasonp = 0l;
 check__shared__bodys3_5_interrupt:
  goto interrupt_5;
 }

 add__shared_7_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 add__shared_7_clear_reason:
  reasonp = reasons;
 add__shared_7_0:
 add__shared_7_1:
  switch (ptagof(a4)) {
 case FUNCTOR:
  if (functor_of(a4) != makesym(functor_options_2)) goto add__shared_7_3;
  x0 = arg(a4, 1);
 add__shared_7_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom___)) goto add__shared_7_3;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_parse__uty_xupdate__goal_7);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = makesym(atom_body);
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_parse__uty_xencode__goal_3);
  allocp[11] = a3;
  allocp[12] = x2 = makeref(&allocp[12]);
  allocp[13] = x1;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[16] = makeint(2L);
  allocp[17] = a4;
  allocp[18] = makefunctor(funct_const_1);
  allocp[19] = x2;
  qp = (struct goalrec*)&allocp[14];
  allocp += 20;
  proceed();
 case VARREF:
  deref_and_jump(x0,add__shared_7_2);
  *reasonp++ =  x0;
  goto add__shared_7_3;
  };
  goto add__shared_7_3;
 case VARREF:
  deref_and_jump(a4,add__shared_7_1);
  *reasonp++ =  a4;
  goto add__shared_7_3;
  };
  goto add__shared_7_3;
 add__shared_7_3:
  otherwise(add__shared_7_interrupt);
  unify(a6, a5);
  proceed();
 add__shared_7_ext_interrupt:
  reasonp = 0l;
 add__shared_7_interrupt:
  goto interrupt_7;
 }
 interrupt_17:
  allocp[18] = a16;
 interrupt_16:
  allocp[17] = a15;
 interrupt_15:
  allocp[16] = a14;
 interrupt_14:
  allocp[15] = a13;
 interrupt_13:
  allocp[14] = a12;
 interrupt_12:
  allocp[13] = a11;
 interrupt_11:
  allocp[12] = a10;
 interrupt_10:
  allocp[11] = a9;
 interrupt_9:
  allocp[10] = a8;
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_unify__head__body);
}
