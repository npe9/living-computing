# ---------------------------------------------------------- 
#   (C) 1995 Institute for New Generation Computer Technology 
#	(Read COPYRIGHT for detailed information.) 
# ----------------------------------------------------------

if $CROSS; then
cat <<GAZONK >>Makefile

KL1SELFCOMP=

all:	cross

install:	install-basics

GAZONK
else
cat <<GAZONK >>Makefile

KL1SELFCOMP=kl1cmp

all:	self

install:	install-basics

GAZONK
fi
