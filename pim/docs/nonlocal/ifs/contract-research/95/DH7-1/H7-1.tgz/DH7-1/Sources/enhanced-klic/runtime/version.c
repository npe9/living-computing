char *runtime_version = "2.004";
char *runtime_date = "Mon Nov 27 15:50:11 JST 1995";
