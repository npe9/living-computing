# Copyright 1993, 1994, 1995 Institute for New Generation Computer Technology
# Read COPYRIGHT for detailed information
#
# Machine-specific definitions
#

cat <<GAZONK >>Makefile

KL1SELFCOMP=kl1cmp

all:	self

install:	install-basics

GAZONK
