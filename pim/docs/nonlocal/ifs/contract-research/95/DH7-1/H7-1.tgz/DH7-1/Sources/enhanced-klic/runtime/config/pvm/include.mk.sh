# ---------------------------------------------------------- 
#   (C) 1995 Institute for New Generation Computer Technology 
#	(Read COPYRIGHT for detailed information.) 
# ----------------------------------------------------------
cat <<GAZONK

DIST_OTHER_HEADERS =

GAZONK
