# ---------------------------------------------------------- 
#   (C)1995 Institute for New Generation Computer Technology 
#       (Read COPYRIGHT for detailed information.) 
#-----------------------------------------------------------
cat <<GAZONK

DISTCFLAGS = \$(CFLAGS) -DDEBUGLIB -DDIST -I$PVM_ROOT/include -I../include

EXT_OTHER_HEADERS =

DIST_OTHER_SRCS = distpkt.c distio.c distproc.c

DIST_OTHER_OBJS = distpkt.o distio.o distproc.o

distpkt.o: distpkt.c
	\$(CC) $(DISTCFLAGS) -c distpkt.c
distio.o: distio.c ../include/klic/distpkt.h
	\$(CC) $(DISTCFLAGS) -c distio.c
distproc.o: distproc.c
	\$(CC) $(DISTCFLAGS) -c distproc.c

GAZONK
