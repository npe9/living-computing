# ---------------------------------------------------------- 
#   (C) 1995 Institute for New Generation Computer Technology 
#	(Read COPYRIGHT for detailed information.) 
# ----------------------------------------------------------

cat <<GAZONK >>config.h

#define DIST_COMPILER_FLAG() 

#define DIST_LINKAGE_FLAG() 

GAZONK
echo " "
