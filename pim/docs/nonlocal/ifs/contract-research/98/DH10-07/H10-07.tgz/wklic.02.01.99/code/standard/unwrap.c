/* Compiled by KLIC compiler version 3.001 (Thu Jun  5 20:19:10 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_unwrap();
Const struct predicate predicate_unwrap_xunwrap_2 =
   { module_unwrap, 0, 2 };
Const struct predicate predicate_unwrap_xunwrap1_2 =
   { module_unwrap, 1, 2 };
Const struct predicate predicate_unwrap_xrec__set__arg_4 =
   { module_unwrap, 2, 4 };
Const struct predicate predicate_unwrap_xunwraparg_3 =
   { module_unwrap, 3, 3 };
Const struct predicate predicate_unwrap_xunwraparg_4 =
   { module_unwrap, 4, 4 };
Const struct predicate predicate_unwrap_xreverse_2 =
   { module_unwrap, 5, 2 };
Const struct predicate predicate_unwrap_xreverse1_2 =
   { module_unwrap, 6, 2 };
Const struct predicate predicate_unwrap_xreverse1_3 =
   { module_unwrap, 7, 3 };
Const struct predicate predicate_unwrap_xlength_2 =
   { module_unwrap, 8, 2 };
Const struct predicate predicate_unwrap_xunlist_2 =
   { module_unwrap, 9, 2 };
Const struct predicate predicate_unwrap_xunlist1_2 =
   { module_unwrap, 10, 2 };
Const struct predicate predicate_unwrap_xunlist1_3 =
   { module_unwrap, 11, 3 };
Const struct predicate predicate_unwrap_xappend_3 =
   { module_unwrap, 12, 3 };
Const struct predicate predicate_unwrap_xappend1_3 =
   { module_unwrap, 13, 3 };
extern Const struct predicate predicate_integer__arithmetics_xadd_3;
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_xsetarg_4;
extern Const struct predicate predicate_functor__table_xfunctor_3;
extern Const struct predicate predicate_functor__table_xnew__functor_3;
extern Const struct predicate predicate_util_xlosToLst_2;
extern Const struct predicate predicate_html_xparseHTML_2;

module module_unwrap(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  q a0, a1, a2, a3;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, unwrap_2_top);
    case_pred(1, unwrap1_2_top);
    case_pred(2, rec__set__arg_4_top);
    case_pred(3, unwraparg_3_top);
    case_pred(4, unwraparg_4_top);
    case_pred(5, reverse_2_top);
    case_pred(6, reverse1_2_top);
    case_pred(7, reverse1_3_top);
    case_pred(8, length_2_top);
    case_pred(9, unlist_2_top);
    case_pred(10, unlist1_2_top);
    case_pred(11, unlist1_3_top);
    case_pred(12, append_3_top);
    last_case_pred(13, append1_3_top);
  }

 unwrap_2_top: {
  q x0, x1, x2;
  qp = qp->next;
 unwrap_2_clear_reason:
  reasonp = reasons;
 unwrap_2_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unwrap_xunwrap1_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = NILATOM;
  allocp[5] = x0;
  x1 = makecons(&allocp[4]);
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_html_xparseHTML_2);
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = x1;
  allocp[10] = (q)(struct goalrec*)&allocp[6];
  allocp[11] = (q)(&predicate_util_xlosToLst_2);
  allocp[12] = a0;
  allocp[13] = x2;
  qp = (struct goalrec*)&allocp[10];
  allocp += 14;
  proceed();
 unwrap_2_ext_interrupt:
  reasonp = 0l;
 unwrap_2_interrupt:
  goto interrupt_2;
 }

 unwrap1_2_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  qp = qp->next;
 unwrap1_2_clear_reason:
  reasonp = reasons;
 unwrap1_2_0:
 unwrap1_2_1:
  if (isref(a0)) goto unwrap1_2_3;
  gblt_pfunctor(a0,x0,unwrap1_2_4);
  if (x0 != makesym(atom_text)) goto unwrap1_2_4;
  gblt_arity(a0,x1,unwrap1_2_4);
 unwrap1_2_2:
  if (x1 != makeint(1L)) goto unwrap1_2_4;
  unify_value(a1, a0);
  proceed();
 unwrap1_2_3:
  deref_and_jump(a0,unwrap1_2_1);
  *reasonp++ =  a0;
  goto unwrap1_2_4;
 unwrap1_2_4:
  otherwise(unwrap1_2_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unwrap_xrec__set__arg_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a1;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xnew__functor_3);
  allocp[8] = x1;
  allocp[9] = x3 = makeref(&allocp[9]);
  allocp[10] = x0;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_unwrap_xreverse_2);
  allocp[13] = x4 = makeref(&allocp[13]);
  allocp[14] = x2;
  allocp[15] = (q)(struct goalrec*)&allocp[11];
  allocp[16] = (q)(&predicate_unwrap_xlength_2);
  allocp[17] = x4;
  allocp[18] = x0;
  allocp[19] = (q)(struct goalrec*)&allocp[15];
  allocp[20] = (q)(&predicate_unwrap_xunlist_2);
  allocp[21] = x5 = makeref(&allocp[21]);
  allocp[22] = x4;
  allocp[23] = (q)(struct goalrec*)&allocp[19];
  allocp[24] = (q)(&predicate_unwrap_xunwraparg_3);
  allocp[25] = x6 = makeref(&allocp[25]);
  allocp[26] = a0;
  allocp[27] = x5;
  allocp[28] = (q)(struct goalrec*)&allocp[23];
  allocp[29] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[30] = a0;
  allocp[31] = x3;
  allocp[32] = x6;
  qp = (struct goalrec*)&allocp[28];
  allocp += 33;
  proceed();
 unwrap1_2_ext_interrupt:
  reasonp = 0l;
 unwrap1_2_interrupt:
  toppred = &predicate_unwrap_xunwrap1_2;
  goto interrupt_2;
 }

 rec__set__arg_4_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 rec__set__arg_4_clear_reason:
  reasonp = reasons;
 rec__set__arg_4_0:
 rec__set__arg_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 rec__set__arg_4_2:
  if (a0 != makeint(0L)) goto rec__set__arg_4_4;
 rec__set__arg_4_3:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != NILATOM) goto rec__set__arg_4_4;
  unify(a3, a1);
  proceed();
 case VARREF:
  deref_and_jump(a2,rec__set__arg_4_3);
  *reasonp++ =  a2;
  goto rec__set__arg_4_4;
  };
  goto rec__set__arg_4_4;
 case VARREF:
  deref_and_jump(a0,rec__set__arg_4_1);
  *reasonp++ =  a0;
  goto rec__set__arg_4_4;
  };
  goto rec__set__arg_4_4;
 rec__set__arg_4_4:
  alternative(rec__set__arg_4_clear_reason);
 rec__set__arg_4_5:
  switch (ptagof(a2)) {
 case CONS:
 rec__set__arg_4_6:
  if (!isint(a0)) goto rec__set__arg_4_7;
  x0 = makeint(0L);
  gblt_greater(a0,x0,rec__set__arg_4_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unwrap_xrec__set__arg_4);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = x2 = makeref(&allocp[3]);
  x3 = cdr_of(a2);
  allocp[4] = x3;
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x1;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[13] = a0;
  allocp[14] = a1;
  x4 = car_of(a2);
  allocp[15] = x4;
  allocp[16] = x2;
  qp = (struct goalrec*)&allocp[11];
  allocp += 17;
  proceed();
 rec__set__arg_4_7:
  if (!isref(a0)) goto rec__set__arg_4_interrupt;
  deref_and_jump(a0,rec__set__arg_4_6);
  *reasonp++ =  a0;
  goto rec__set__arg_4_interrupt;
 case VARREF:
  deref_and_jump(a2,rec__set__arg_4_5);
  *reasonp++ =  a2;
  goto rec__set__arg_4_interrupt;
  };
  goto rec__set__arg_4_interrupt;
 rec__set__arg_4_ext_interrupt:
  reasonp = 0l;
 rec__set__arg_4_interrupt:
  goto interrupt_4;
 }

 unwraparg_3_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  qp = qp->next;
 unwraparg_3_clear_reason:
  reasonp = reasons;
 unwraparg_3_0:
  allocp[0] = NILATOM;
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_unwrap_xunwraparg_4);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a1;
  allocp[6] = x0;
  allocp[7] = a2;
  allocp[8] = (q)(struct goalrec*)&allocp[2];
  allocp[9] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[10] = a0;
  allocp[11] = makeint(1L);
  allocp[12] = x2;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_functor__table_xarg_3);
  allocp[15] = a0;
  allocp[16] = a1;
  allocp[17] = x1;
  qp = (struct goalrec*)&allocp[13];
  allocp += 18;
  proceed();
 unwraparg_3_ext_interrupt:
  reasonp = 0l;
 unwraparg_3_interrupt:
  goto interrupt_3;
 }

 unwraparg_4_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 unwraparg_4_clear_reason:
  reasonp = reasons;
 unwraparg_4_0:
 unwraparg_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 unwraparg_4_2:
  if (a0 != makeint(0L)) goto unwraparg_4_3;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,unwraparg_4_1);
  *reasonp++ =  a0;
  goto unwraparg_4_3;
  };
  goto unwraparg_4_3;
 unwraparg_4_3:
  alternative(unwraparg_4_clear_reason);
  allocp[0] = a2;
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_unwrap_xunwraparg_4);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a1;
  allocp[6] = x0;
  allocp[7] = a3;
  allocp[8] = (q)(struct goalrec*)&allocp[2];
  allocp[9] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[10] = a0;
  allocp[11] = makeint(1L);
  allocp[12] = x2;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_functor__table_xarg_3);
  allocp[15] = a0;
  allocp[16] = a1;
  allocp[17] = x1;
  qp = (struct goalrec*)&allocp[13];
  allocp += 18;
  proceed();
 unwraparg_4_ext_interrupt:
  reasonp = 0l;
 unwraparg_4_interrupt:
  goto interrupt_4;
 }

 reverse_2_top: {
  q x0;
  qp = qp->next;
 reverse_2_clear_reason:
  reasonp = reasons;
 reverse_2_0:
 reverse_2_1:
  switch (ptagof(a0)) {
 case CONS:
  gblt_list(a0,reverse_2_interrupt);
  execute(reverse1_2_0);
  goto reverse1_2_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto reverse_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,reverse_2_1);
  *reasonp++ =  a0;
  goto reverse_2_interrupt;
  };
  goto reverse_2_interrupt;
 reverse_2_ext_interrupt:
  reasonp = 0l;
 reverse_2_interrupt:
  toppred = &predicate_unwrap_xreverse_2;
  goto interrupt_2;
 }

 reverse1_2_top: {
  q x0, x1, x2, x3;
  qp = qp->next;
 reverse1_2_clear_reason:
  reasonp = reasons;
 reverse1_2_0:
 reverse1_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 reverse1_2_2:
  switch (ptagof(x0)) {
 case CONS:
  gblt_list(x0,reverse1_2_3);
  allocp[0] = NILATOM;
  allocp[1] = x2 = makeref(&allocp[1]);
  x1 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_unwrap_xreverse1_3);
  x3 = cdr_of(a0);
  allocp[4] = x3;
  allocp[5] = x1;
  allocp[6] = a1;
  a0 = x0;
  a1 = x2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 7;
  execute(reverse_2_0);
  goto reverse_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,reverse1_2_2);
  *reasonp++ =  x0;
  goto reverse1_2_3;
  };
  goto reverse1_2_3;
 case VARREF:
  deref_and_jump(a0,reverse1_2_1);
  *reasonp++ =  a0;
  goto reverse1_2_3;
  };
  goto reverse1_2_3;
 reverse1_2_3:
  otherwise(reverse1_2_interrupt);
 reverse1_2_4:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = NILATOM;
  x1 = car_of(a0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  a0 = cdr_of(a0);
  a2 = a1;
  a1 = x0;
  allocp += 2;
  execute(reverse1_3_0);
  goto reverse1_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,reverse1_2_4);
  *reasonp++ =  a0;
  goto reverse1_2_interrupt;
  };
  goto reverse1_2_interrupt;
 reverse1_2_ext_interrupt:
  reasonp = 0l;
 reverse1_2_interrupt:
  toppred = &predicate_unwrap_xreverse1_2;
  goto interrupt_2;
 }

 reverse1_3_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  qp = qp->next;
 reverse1_3_clear_reason:
  reasonp = reasons;
 reverse1_3_0:
 reverse1_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 reverse1_3_2:
  switch (ptagof(x0)) {
 case CONS:
  gblt_list(x0,reverse1_3_3);
  allocp[0] = a1;
  allocp[1] = x2 = makeref(&allocp[1]);
  x1 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_unwrap_xreverse1_3);
  x3 = cdr_of(a0);
  allocp[4] = x3;
  allocp[5] = x1;
  allocp[6] = a2;
  a0 = x0;
  a1 = x2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 7;
  execute(reverse_2_0);
  goto reverse_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,reverse1_3_2);
  *reasonp++ =  x0;
  goto reverse1_3_3;
  };
  goto reverse1_3_3;
 case VARREF:
  deref_and_jump(a0,reverse1_3_1);
  *reasonp++ =  a0;
  goto reverse1_3_3;
  };
  goto reverse1_3_3;
 reverse1_3_3:
  otherwise(reverse1_3_interrupt);
 reverse1_3_4:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = a1;
  x1 = car_of(a0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  a0 = cdr_of(a0);
  a1 = x0;
  allocp += 2;
  execute(reverse1_3_0);
  goto reverse1_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto reverse1_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,reverse1_3_4);
  *reasonp++ =  a0;
  goto reverse1_3_interrupt;
  };
  goto reverse1_3_interrupt;
 reverse1_3_ext_interrupt:
  reasonp = 0l;
 reverse1_3_interrupt:
  toppred = &predicate_unwrap_xreverse1_3;
  goto interrupt_3;
 }

 length_2_top: {
  q x0;
  qp = qp->next;
 length_2_clear_reason:
  reasonp = reasons;
 length_2_0:
 length_2_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = makeint(1L);
  allocp[4] = a1;
  a0 = cdr_of(a0);
  a1 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(length_2_0);
  goto length_2_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto length_2_interrupt;
  x0 = makeint(0L);
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,length_2_1);
  *reasonp++ =  a0;
  goto length_2_interrupt;
  };
  goto length_2_interrupt;
 length_2_ext_interrupt:
  reasonp = 0l;
 length_2_interrupt:
  goto interrupt_2;
 }

 unlist_2_top: {
  qp = qp->next;
 unlist_2_clear_reason:
  reasonp = reasons;
 unlist_2_0:
 unlist_2_1:
  switch (ptagof(a0)) {
 case CONS:
  gblt_list(a0,unlist_2_interrupt);
  execute(unlist1_2_0);
  goto unlist1_2_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,unlist_2_1);
  *reasonp++ =  a0;
  goto unlist_2_interrupt;
  };
  goto unlist_2_interrupt;
 unlist_2_ext_interrupt:
  reasonp = 0l;
 unlist_2_interrupt:
  toppred = &predicate_unwrap_xunlist_2;
  goto interrupt_2;
 }

 unlist1_2_top: {
  q x0, x1, x2, x3;
  qp = qp->next;
 unlist1_2_clear_reason:
  reasonp = reasons;
 unlist1_2_0:
 unlist1_2_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != NILATOM) goto unlist1_2_2;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,unlist1_2_1);
  *reasonp++ =  a0;
  goto unlist1_2_2;
  };
  goto unlist1_2_2;
 unlist1_2_2:
  otherwise(unlist1_2_interrupt);
 unlist1_2_3:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 unlist1_2_4:
  switch (ptagof(x0)) {
 case CONS:
  gblt_list(x0,unlist1_2_5);
  allocp[0] = NILATOM;
  allocp[1] = x0;
  x1 = makecons(&allocp[0]);
  a0 = cdr_of(a0);
  a2 = a1;
  a1 = x1;
  allocp += 2;
  execute(unlist1_3_0);
  goto unlist1_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,unlist1_2_4);
  *reasonp++ =  x0;
  goto unlist1_2_5;
  };
  goto unlist1_2_5;
 case VARREF:
  deref_and_jump(a0,unlist1_2_3);
  *reasonp++ =  a0;
  goto unlist1_2_5;
  };
  goto unlist1_2_5;
 unlist1_2_5:
  otherwise(unlist1_2_interrupt);
 unlist1_2_6:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 unlist1_2_7:
  switch (ptagof(x0)) {
 case ATOMIC:
 unlist1_2_8:
  gblt_atomic(x0,unlist1_2_9);
  allocp[0] = NILATOM;
  allocp[1] = x0;
  x1 = makecons(&allocp[0]);
  a0 = cdr_of(a0);
  a2 = a1;
  a1 = x1;
  allocp += 2;
  execute(unlist1_3_0);
  goto unlist1_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,unlist1_2_7);
  *reasonp++ =  x0;
  goto unlist1_2_9;
  };
  goto unlist1_2_9;
 case VARREF:
  deref_and_jump(a0,unlist1_2_6);
  *reasonp++ =  a0;
  goto unlist1_2_9;
  };
  goto unlist1_2_9;
 unlist1_2_9:
  otherwise(unlist1_2_interrupt);
 unlist1_2_10:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 unlist1_2_11:
  switch (ptagof(x0)) {
 case FUNCTOR:
 unlist1_2_12:
  if (!isgobj(x0)) goto unlist1_2_14;
 unlist1_2_13:
  gblt_is_string(x0,unlist1_2_14);
  gblt_size_of_string(x0,x1,unlist1_2_14);
  gblt_element_size_of_string(x0,x2,unlist1_2_14);
  allocp[0] = NILATOM;
  allocp[1] = x0;
  x3 = makecons(&allocp[0]);
  a0 = cdr_of(a0);
  a2 = a1;
  a1 = x3;
  allocp += 2;
  execute(unlist1_3_0);
  goto unlist1_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,unlist1_2_11);
  *reasonp++ =  x0;
  goto unlist1_2_14;
  };
  goto unlist1_2_14;
 case VARREF:
  deref_and_jump(a0,unlist1_2_10);
  *reasonp++ =  a0;
  goto unlist1_2_14;
  };
  goto unlist1_2_14;
 unlist1_2_14:
  otherwise(unlist1_2_interrupt);
 unlist1_2_15:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = NILATOM;
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_unwrap_xunlist1_3);
  x2 = cdr_of(a0);
  allocp[4] = x2;
  allocp[5] = x0;
  allocp[6] = a1;
  a0 = car_of(a0);
  a1 = x1;
  qp = (struct goalrec*)&allocp[2];
  allocp += 7;
  execute(unwrap1_2_0);
  goto unwrap1_2_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,unlist1_2_15);
  *reasonp++ =  a0;
  goto unlist1_2_interrupt;
  };
  goto unlist1_2_interrupt;
 unlist1_2_ext_interrupt:
  reasonp = 0l;
 unlist1_2_interrupt:
  toppred = &predicate_unwrap_xunlist1_2;
  goto interrupt_2;
 }

 unlist1_3_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  qp = qp->next;
 unlist1_3_clear_reason:
  reasonp = reasons;
 unlist1_3_0:
 unlist1_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != NILATOM) goto unlist1_3_2;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,unlist1_3_1);
  *reasonp++ =  a0;
  goto unlist1_3_2;
  };
  goto unlist1_3_2;
 unlist1_3_2:
  otherwise(unlist1_3_interrupt);
 unlist1_3_3:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 unlist1_3_4:
  switch (ptagof(x0)) {
 case CONS:
  gblt_list(x0,unlist1_3_5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unwrap_xunlist1_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_unwrap_xappend_3);
  allocp[7] = a1;
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = x2;
  a0 = x0;
  a1 = x3;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  execute(unlist_2_0);
  goto unlist_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,unlist1_3_4);
  *reasonp++ =  x0;
  goto unlist1_3_5;
  };
  goto unlist1_3_5;
 case VARREF:
  deref_and_jump(a0,unlist1_3_3);
  *reasonp++ =  a0;
  goto unlist1_3_5;
  };
  goto unlist1_3_5;
 unlist1_3_5:
  otherwise(unlist1_3_interrupt);
 unlist1_3_6:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 unlist1_3_7:
  switch (ptagof(x0)) {
 case ATOMIC:
 unlist1_3_8:
  gblt_atomic(x0,unlist1_3_9);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unwrap_xunlist1_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x3 = makecons(&allocp[5]);
  a0 = a1;
  a1 = x3;
  a2 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(append_3_0);
  goto append_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,unlist1_3_7);
  *reasonp++ =  x0;
  goto unlist1_3_9;
  };
  goto unlist1_3_9;
 case VARREF:
  deref_and_jump(a0,unlist1_3_6);
  *reasonp++ =  a0;
  goto unlist1_3_9;
  };
  goto unlist1_3_9;
 unlist1_3_9:
  otherwise(unlist1_3_interrupt);
 unlist1_3_10:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 unlist1_3_11:
  switch (ptagof(x0)) {
 case FUNCTOR:
 unlist1_3_12:
  if (!isgobj(x0)) goto unlist1_3_14;
 unlist1_3_13:
  gblt_is_string(x0,unlist1_3_14);
  gblt_size_of_string(x0,x1,unlist1_3_14);
  gblt_element_size_of_string(x0,x2,unlist1_3_14);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unwrap_xunlist1_3);
  x3 = cdr_of(a0);
  allocp[2] = x3;
  allocp[3] = x4 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x5 = makecons(&allocp[5]);
  a0 = a1;
  a1 = x5;
  a2 = x4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(append_3_0);
  goto append_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,unlist1_3_11);
  *reasonp++ =  x0;
  goto unlist1_3_14;
  };
  goto unlist1_3_14;
 case VARREF:
  deref_and_jump(a0,unlist1_3_10);
  *reasonp++ =  a0;
  goto unlist1_3_14;
  };
  goto unlist1_3_14;
 unlist1_3_14:
  otherwise(unlist1_3_interrupt);
 unlist1_3_15:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unwrap_xunlist1_3);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = NILATOM;
  allocp[6] = x3 = makeref(&allocp[6]);
  x2 = makecons(&allocp[5]);
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_unwrap_xappend_3);
  allocp[9] = a1;
  allocp[10] = x2;
  allocp[11] = x1;
  a0 = car_of(a0);
  a1 = x3;
  qp = (struct goalrec*)&allocp[7];
  allocp += 12;
  execute(unwrap1_2_0);
  goto unwrap1_2_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,unlist1_3_15);
  *reasonp++ =  a0;
  goto unlist1_3_interrupt;
  };
  goto unlist1_3_interrupt;
 unlist1_3_ext_interrupt:
  reasonp = 0l;
 unlist1_3_interrupt:
  toppred = &predicate_unwrap_xunlist1_3;
  goto interrupt_3;
 }

 append_3_top: {
  q x0;
  a2 = qp->args[2];
  qp = qp->next;
 append_3_clear_reason:
  reasonp = reasons;
 append_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unwrap_xappend1_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  a1 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(reverse_2_0);
  goto reverse_2_ext_interrupt;
 append_3_ext_interrupt:
  reasonp = 0l;
 append_3_interrupt:
  toppred = &predicate_unwrap_xappend_3;
  goto interrupt_3;
 }

 append1_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 append1_3_clear_reason:
  reasonp = reasons;
 append1_3_0:
 append1_3_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = a1;
  x1 = car_of(a0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  a0 = cdr_of(a0);
  a1 = x0;
  allocp += 2;
  execute(append1_3_0);
  goto append1_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto append1_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,append1_3_1);
  *reasonp++ =  a0;
  goto append1_3_interrupt;
  };
  goto append1_3_interrupt;
 append1_3_ext_interrupt:
  reasonp = 0l;
 append1_3_interrupt:
  goto interrupt_3;
 }
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_unwrap);
}
