/* Compiled by KLIC compiler version 3.001 (Thu Jun  5 20:19:10 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_http();
Const struct predicate predicate_http_xhttpcomm_11 =
   { module_http, 0, 11 };
Const struct predicate predicate_http_xhttpcomm_2F11_240_3 =
   { module_http, 1, 3 };
Const struct predicate predicate_http_xisDigit_2 =
   { module_http, 2, 2 };
Const struct predicate predicate_http_xisDigit_2F2_240_2 =
   { module_http, 3, 2 };
Const struct predicate predicate_http_xpartDigit_2 =
   { module_http, 4, 2 };
Const struct predicate predicate_http_xpartDigit1_2 =
   { module_http, 5, 2 };
Const struct predicate predicate_http_xpartDigit1_2F2_240_4 =
   { module_http, 6, 4 };
Const struct predicate predicate_http_xpartDigit1_2F2_240_2F4_240_2 =
   { module_http, 7, 2 };
Const struct predicate predicate_http_xhttpcomm1_9 =
   { module_http, 8, 9 };
Const struct predicate predicate_http_xmkReq_5 =
   { module_http, 9, 5 };
Const struct predicate predicate_http_xhttpGetResp_5 =
   { module_http, 10, 5 };
Const struct predicate predicate_http_xhttpGetResp1_4 =
   { module_http, 11, 4 };
Const struct predicate predicate_http_xhttpGetResp1_2F4_240_6 =
   { module_http, 12, 6 };
Const struct predicate predicate_http_xpartHeadBody_3 =
   { module_http, 13, 3 };
Const struct predicate predicate_http_xpartHeadBody_2F3_241_6 =
   { module_http, 14, 6 };
Const struct predicate predicate_http_xpartHeadBody_2F3_241_2F6_240_6 =
   { module_http, 15, 6 };
Const struct predicate predicate_http_xpartHeadBody_2F3_240_4 =
   { module_http, 16, 4 };
Const struct predicate predicate_http_xpartHeadBody_2F3_240_2F4_240_4 =
   { module_http, 17, 4 };
Const struct predicate predicate_http_xpartHeadBody1_4 =
   { module_http, 18, 4 };
Const struct predicate predicate_http_xpartHeadBody1_2F4_241_8 =
   { module_http, 19, 8 };
Const struct predicate predicate_http_xpartHeadBody1_2F4_241_2F8_240_14 =
   { module_http, 20, 14 };
Const struct predicate predicate_http_xpartHeadBody1_2F4_240_6 =
   { module_http, 21, 6 };
Const struct predicate predicate_http_xpartHeadBody1_2F4_240_2F6_240_12 =
   { module_http, 22, 12 };
Const struct predicate predicate_http_xpartHeadBodyCRLF_6 =
   { module_http, 23, 6 };
Const struct predicate predicate_http_xpartHeadBodyCRLF_2F6_240_7 =
   { module_http, 24, 7 };
Const struct predicate predicate_http_xpartHeadBodyCRLF_2F6_240_2F7_240_10 =
   { module_http, 25, 10 };
Const struct predicate predicate_http_xpartHeadBodyLF_6 =
   { module_http, 26, 6 };
Const struct predicate predicate_http_xpartHeadBodyLF_2F6_240_7 =
   { module_http, 27, 7 };
Const struct predicate predicate_http_xpartHeadBodyLF_2F6_240_2F7_240_7 =
   { module_http, 28, 7 };
Const struct predicate predicate_http_xfiletype_2 =
   { module_http, 29, 2 };
Const struct predicate predicate_http_xpartHead_2 =
   { module_http, 30, 2 };
Const struct predicate predicate_http_xpartHead1_3 =
   { module_http, 31, 3 };
Const struct predicate predicate_http_xpartHead2_2 =
   { module_http, 32, 2 };
Const struct predicate predicate_http_xsearchHead_3 =
   { module_http, 33, 3 };
Const struct predicate predicate_http_xsearchHead1_3 =
   { module_http, 34, 3 };
Const struct predicate predicate_http_xsearchHead1_2F3_240_5 =
   { module_http, 35, 5 };
Const struct predicate predicate_http_xsearchHead1_2F3_240_2F5_240_5 =
   { module_http, 36, 5 };
Const struct predicate predicate_http_xrmCommentSP_2 =
   { module_http, 37, 2 };
Const struct predicate predicate_http_xrmCommentSP1_2 =
   { module_http, 38, 2 };
Const struct predicate predicate_http_xrmCommentSPDQ_2 =
   { module_http, 39, 2 };
Const struct predicate predicate_http_xrmCommentSPBr_2 =
   { module_http, 40, 2 };
Const struct predicate predicate_http_xrmCommentSPComm_2 =
   { module_http, 41, 2 };
Const struct predicate predicate_http_xsearchCommentEnd_2 =
   { module_http, 42, 2 };
Const struct predicate predicate_http_xignoreParam_2 =
   { module_http, 43, 2 };
Const struct predicate predicate_http_xignoreParam_2F2_240_3 =
   { module_http, 44, 3 };
Const struct predicate predicate_http_xpartContentType_2 =
   { module_http, 45, 2 };
Const struct predicate predicate_http_xpartContentType_2F2_240_3 =
   { module_http, 46, 3 };
Const struct predicate predicate_http_xgetStatusCode_2 =
   { module_http, 47, 2 };
Const struct predicate predicate_http_xgetStatusCode_2F2_240_3 =
   { module_http, 48, 3 };
Const struct predicate predicate_http_xgetStatusCode_2F2_240_2F3_240_2 =
   { module_http, 49, 2 };
Const struct predicate predicate_http_xnewLocation_2 =
   { module_http, 50, 2 };
Const struct predicate predicate_http_xnewLocation_2F2_240_3 =
   { module_http, 51, 3 };
extern q string_g_new();
extern Const struct predicate predicate_unix_xunix_1;
extern Const struct predicate predicate_builtin_xprint_1;
extern Const struct predicate predicate_generic_xgeneric_2;
extern Const struct predicate predicate_util_xstrToLst_2;
extern Const struct predicate predicate_util_xatoi_2;
extern Const struct predicate predicate_util_xmin_3;
extern Const struct predicate predicate_util_xcrlfToLf_2;
extern Const struct predicate predicate_util_xtoLower_2;
extern Const struct predicate predicate_util_xrev_2;
extern Const struct predicate predicate_util_xlstToAtom_2;
extern Const struct predicate predicate_util_xskipSP_2;

module module_http(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_0 =
      declare_string_constant_8(0,0);
  static Const unsigned char strconst_body_1[4] =
    "\015\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_1 =
      declare_string_constant_8(strconst_body_1,2);
  static Const unsigned char strconst_body_2[4] =
    " /";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_2 =
      declare_string_constant_8(strconst_body_2,2);
  static Const unsigned char strconst_body_3[12] =
    " HTTP/1.0\015\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_3 =
      declare_string_constant_8(strconst_body_3,11);
  static Const unsigned char strconst_body_4[12] =
    {'C','o','n','t','e','n','t','-','T','y','p','e',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_4 =
      declare_string_constant_8(strconst_body_4,12);
  static Const unsigned char strconst_body_5[4] =
    {'H','T','T','P',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_5 =
      declare_string_constant_8(strconst_body_5,4);
  static Const unsigned char strconst_body_6[8] =
    {'L','o','c','a','t','i','o','n',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_6 =
      declare_string_constant_8(strconst_body_6,8);
  static Const unsigned char strconst_body_7[16] =
    "Making Request";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_7 =
      declare_string_constant_8(strconst_body_7,14);
  static Const unsigned char strconst_body_8[20] =
    {'P','r','e','p','a','r','i','n','g',' ','t','o',' ','c','o','n','n','e','c','t',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_8 =
      declare_string_constant_8(strconst_body_8,20);
  static Const unsigned char strconst_body_9[4] =
    "URI";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_9 =
      declare_string_constant_8(strconst_body_9,3);
  q a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, httpcomm_11_top);
    case_pred(1, httpcomm_2F11_240_3_top);
    case_pred(2, isDigit_2_top);
    case_pred(3, isDigit_2F2_240_2_top);
    case_pred(4, partDigit_2_top);
    case_pred(5, partDigit1_2_top);
    case_pred(6, partDigit1_2F2_240_4_top);
    case_pred(7, partDigit1_2F2_240_2F4_240_2_top);
    case_pred(8, httpcomm1_9_top);
    case_pred(9, mkReq_5_top);
    case_pred(10, httpGetResp_5_top);
    case_pred(11, httpGetResp1_4_top);
    case_pred(12, httpGetResp1_2F4_240_6_top);
    case_pred(13, partHeadBody_3_top);
    case_pred(14, partHeadBody_2F3_241_6_top);
    case_pred(15, partHeadBody_2F3_241_2F6_240_6_top);
    case_pred(16, partHeadBody_2F3_240_4_top);
    case_pred(17, partHeadBody_2F3_240_2F4_240_4_top);
    case_pred(18, partHeadBody1_4_top);
    case_pred(19, partHeadBody1_2F4_241_8_top);
    case_pred(20, partHeadBody1_2F4_241_2F8_240_14_top);
    case_pred(21, partHeadBody1_2F4_240_6_top);
    case_pred(22, partHeadBody1_2F4_240_2F6_240_12_top);
    case_pred(23, partHeadBodyCRLF_6_top);
    case_pred(24, partHeadBodyCRLF_2F6_240_7_top);
    case_pred(25, partHeadBodyCRLF_2F6_240_2F7_240_10_top);
    case_pred(26, partHeadBodyLF_6_top);
    case_pred(27, partHeadBodyLF_2F6_240_7_top);
    case_pred(28, partHeadBodyLF_2F6_240_2F7_240_7_top);
    case_pred(29, filetype_2_top);
    case_pred(30, partHead_2_top);
    case_pred(31, partHead1_3_top);
    case_pred(32, partHead2_2_top);
    case_pred(33, searchHead_3_top);
    case_pred(34, searchHead1_3_top);
    case_pred(35, searchHead1_2F3_240_5_top);
    case_pred(36, searchHead1_2F3_240_2F5_240_5_top);
    case_pred(37, rmCommentSP_2_top);
    case_pred(38, rmCommentSP1_2_top);
    case_pred(39, rmCommentSPDQ_2_top);
    case_pred(40, rmCommentSPBr_2_top);
    case_pred(41, rmCommentSPComm_2_top);
    case_pred(42, searchCommentEnd_2_top);
    case_pred(43, ignoreParam_2_top);
    case_pred(44, ignoreParam_2F2_240_3_top);
    case_pred(45, partContentType_2_top);
    case_pred(46, partContentType_2F2_240_3_top);
    case_pred(47, getStatusCode_2_top);
    case_pred(48, getStatusCode_2F2_240_3_top);
    case_pred(49, getStatusCode_2F2_240_2F3_240_2_top);
    case_pred(50, newLocation_2_top);
    last_case_pred(51, newLocation_2F2_240_3_top);
  }

 httpcomm_11_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 httpcomm_11_clear_reason:
  reasonp = reasons;
 httpcomm_11_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_http_xpartHead_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a6;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_http_xhttpcomm1_9);
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = a0;
  allocp[8] = a3;
  allocp[9] = a4;
  allocp[10] = a5;
  allocp[11] = x0;
  allocp[12] = a7;
  allocp[13] = a8;
  allocp[14] = a9;
  allocp[15] = makesym(functor_inet_2);
  allocp[16] = x3 = makeref(&allocp[16]);
  allocp[17] = a2;
  x2 = makefunctor(&allocp[15]);
  allocp[18] = makesym(functor_connect_2);
  allocp[19] = x2;
  allocp[20] = x1;
  x4 = makefunctor(&allocp[18]);
  allocp[21] = NILATOM;
  allocp[22] = x4;
  x5 = makecons(&allocp[21]);
  allocp[23] = (q)(struct goalrec*)&allocp[4];
  allocp[24] = (q)(&predicate_unix_xunix_1);
  allocp[25] = x5;
  allocp[26] = (q)(struct goalrec*)&allocp[23];
  allocp[27] = (q)(&predicate_builtin_xprint_1);
  allocp[28] = makefunctor(&string_const_8);
  allocp[29] = (q)(struct goalrec*)&allocp[26];
  allocp[30] = (q)(&predicate_http_xhttpcomm_2F11_240_3);
  allocp[31] = x6 = makeref(&allocp[31]);
  allocp[32] = a1;
  allocp[33] = x3;
  a0 = a1;
  a1 = x6;
  qp = (struct goalrec*)&allocp[29];
  allocp += 34;
  execute(isDigit_2_0);
  goto isDigit_2_ext_interrupt;
 httpcomm_11_ext_interrupt:
  reasonp = 0l;
 httpcomm_11_interrupt:
  goto interrupt_11;
 }

 httpcomm_2F11_240_3_top: {
  a2 = qp->args[2];
  qp = qp->next;
 httpcomm_2F11_240_3_clear_reason:
  reasonp = reasons;
 httpcomm_2F11_240_3_0:
 httpcomm_2F11_240_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_true)) goto httpcomm_2F11_240_3_2;
  a0 = a1;
  a1 = a2;
  execute(partDigit_2_0);
  goto partDigit_2_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,httpcomm_2F11_240_3_1);
  *reasonp++ =  a0;
  goto httpcomm_2F11_240_3_2;
  };
  goto httpcomm_2F11_240_3_2;
 httpcomm_2F11_240_3_2:
  otherwise(httpcomm_2F11_240_3_interrupt);
  unify(a2, a1);
  proceed();
 httpcomm_2F11_240_3_ext_interrupt:
  reasonp = 0l;
 httpcomm_2F11_240_3_interrupt:
  goto interrupt_3;
 }

 isDigit_2_top: {
  q x0, x1;
  qp = qp->next;
 isDigit_2_clear_reason:
  reasonp = reasons;
 isDigit_2_0:
 isDigit_2_1:
  if (isref(a0)) goto isDigit_2_4;
 isDigit_2_2:
  if (isref(a0)) goto isDigit_2_3;
  x0 = makefunctor(&string_const_0);
  if_not_equal(a0, x0, isDigit_2_5);
  x1 = makesym(atom_false);
  unify_value(a1, x1);
  proceed();
 isDigit_2_3:
  deref_and_jump(a0,isDigit_2_2);
  *reasonp++ =  a0;
  goto isDigit_2_5;
 isDigit_2_4:
  deref_and_jump(a0,isDigit_2_1);
  *reasonp++ =  a0;
  goto isDigit_2_5;
 isDigit_2_5:
  otherwise(isDigit_2_interrupt);
  x0 = makeint(0L);
  generic_arg[0] = x0;
  allocp[0] = x1 = makeref(&allocp[0]);
  generic_arg[1] = x1;
  call_generic(a0, functor_element_2, 1);
  a0 = x1;
  execute(isDigit_2F2_240_2_0);
  goto isDigit_2F2_240_2_ext_interrupt;
 isDigit_2_ext_interrupt:
  reasonp = 0l;
 isDigit_2_interrupt:
  toppred = &predicate_http_xisDigit_2;
  goto interrupt_2;
 }

 isDigit_2F2_240_2_top: {
  q x0, x1, x2;
  qp = qp->next;
 isDigit_2F2_240_2_clear_reason:
  reasonp = reasons;
 isDigit_2F2_240_2_0:
 isDigit_2F2_240_2_1:
  if (!isint(a0)) goto isDigit_2F2_240_2_2;
  x0 = makeint(48L);
  gblt_less_or_eq(x0,a0,isDigit_2F2_240_2_3);
  x1 = makeint(57L);
  gblt_less_or_eq(a0,x1,isDigit_2F2_240_2_3);
  x2 = makesym(atom_true);
  unify_value(a1, x2);
  proceed();
 isDigit_2F2_240_2_2:
  if (!isref(a0)) goto isDigit_2F2_240_2_3;
  deref_and_jump(a0,isDigit_2F2_240_2_1);
  *reasonp++ =  a0;
  goto isDigit_2F2_240_2_3;
 isDigit_2F2_240_2_3:
  otherwise(isDigit_2F2_240_2_interrupt);
  x0 = makesym(atom_false);
  unify_value(a1, x0);
  proceed();
 isDigit_2F2_240_2_ext_interrupt:
  reasonp = 0l;
 isDigit_2F2_240_2_interrupt:
  toppred = &predicate_http_xisDigit_2F2_240_2;
  goto interrupt_2;
 }

 partDigit_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  qp = qp->next;
 partDigit_2_clear_reason:
  reasonp = reasons;
 partDigit_2_0:
  allocp[0] = x0 = makeref(&allocp[0]);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x0;
  allocp[5] = x1;
  allocp[6] = x2;
  allocp[7] = x3;
  x4 = create_vector(&allocp[4], 4, allocp);
  allocp += 8;
  unify_value(a1, x4);
  allocp[0] = NILATOM;
  allocp[1] = x3;
  x5 = makecons(&allocp[0]);
  allocp[2] = x5;
  allocp[3] = x2;
  x6 = makecons(&allocp[2]);
  allocp[4] = x6;
  allocp[5] = x1;
  x7 = makecons(&allocp[4]);
  allocp[6] = x7;
  allocp[7] = x0;
  x8 = makecons(&allocp[6]);
  a1 = x8;
  allocp += 8;
  execute(partDigit1_2_0);
  goto partDigit1_2_ext_interrupt;
 partDigit_2_ext_interrupt:
  reasonp = 0l;
 partDigit_2_interrupt:
  toppred = &predicate_http_xpartDigit_2;
  goto interrupt_2;
 }

 partDigit1_2_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  qp = qp->next;
 partDigit1_2_clear_reason:
  reasonp = reasons;
 partDigit1_2_0:
 partDigit1_2_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != NILATOM) goto partDigit1_2_2;
  proceed();
 case VARREF:
  deref_and_jump(a1,partDigit1_2_1);
  *reasonp++ =  a1;
  goto partDigit1_2_2;
  };
  goto partDigit1_2_2;
 partDigit1_2_2:
 partDigit1_2_3:
  if (isref(a0)) goto partDigit1_2_7;
 partDigit1_2_4:
  if (isref(a0)) goto partDigit1_2_6;
  x0 = makefunctor(&string_const_0);
  if_not_equal(a0, x0, partDigit1_2_8);
 partDigit1_2_5:
  switch (ptagof(a1)) {
 case CONS:
  x1 = car_of(a1);
  x2 = makesym(atom_hostname__error);
  unify_value(x1, x2);
  a0 = makefunctor(&string_const_0);
  a1 = cdr_of(a1);
  execute(partDigit1_2_clear_reason);
  goto partDigit1_2_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,partDigit1_2_5);
  *reasonp++ =  a1;
  goto partDigit1_2_8;
  };
  goto partDigit1_2_8;
 partDigit1_2_6:
  deref_and_jump(a0,partDigit1_2_4);
  *reasonp++ =  a0;
  goto partDigit1_2_8;
 partDigit1_2_7:
  deref_and_jump(a0,partDigit1_2_3);
  *reasonp++ =  a0;
  goto partDigit1_2_8;
 partDigit1_2_8:
  otherwise(partDigit1_2_interrupt);
 partDigit1_2_9:
  switch (ptagof(a1)) {
 case CONS:
  x0 = cdr_of(a1);
 partDigit1_2_10:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != NILATOM) goto partDigit1_2_11;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_util_xatoi_2);
  allocp[2] = x1 = makeref(&allocp[2]);
  x2 = car_of(a1);
  allocp[3] = x2;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_util_xstrToLst_2);
  allocp[6] = a0;
  allocp[7] = x1;
  qp = (struct goalrec*)&allocp[4];
  allocp += 8;
  proceed();
 case VARREF:
  deref_and_jump(x0,partDigit1_2_10);
  *reasonp++ =  x0;
  goto partDigit1_2_11;
  };
  goto partDigit1_2_11;
 case VARREF:
  deref_and_jump(a1,partDigit1_2_9);
  *reasonp++ =  a1;
  goto partDigit1_2_11;
  };
  goto partDigit1_2_11;
 partDigit1_2_11:
  otherwise(partDigit1_2_interrupt);
 partDigit1_2_12:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = x0 = makeref(&allocp[0]);
  generic_arg[0] = x0;
  call_generic(a0, functor_size_1, 1);
  x1 = makeint(1L);
  bblt_sub_no_check_y(x0,x1,x2);
  x3 = makeint(0L);
  generic_arg[0] = x3;
  generic_arg[1] = x2;
  x4 = makeint(46L);
  generic_arg[2] = x4;
  allocp[0] = x5 = makeref(&allocp[0]);
  generic_arg[3] = x5;
  call_generic(a0, functor_search__character_4, 1);
  x6 = car_of(a1);
  a2 = cdr_of(a1);
  a3 = a0;
  a1 = x6;
  a0 = x5;
  execute(partDigit1_2F2_240_4_0);
  goto partDigit1_2F2_240_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,partDigit1_2_12);
  *reasonp++ =  a1;
  goto partDigit1_2_interrupt;
  };
  goto partDigit1_2_interrupt;
 partDigit1_2_ext_interrupt:
  reasonp = 0l;
 partDigit1_2_interrupt:
  toppred = &predicate_http_xpartDigit1_2;
  goto interrupt_2;
 }

 partDigit1_2F2_240_4_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 partDigit1_2F2_240_4_clear_reason:
  reasonp = reasons;
 partDigit1_2F2_240_4_0:
 partDigit1_2F2_240_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 partDigit1_2F2_240_4_2:
  if (a0 != makeint(-1L)) goto partDigit1_2F2_240_4_3;
  x0 = makesym(atom_hostname__error);
  unify_value(a1, x0);
  a0 = makefunctor(&string_const_0);
  a1 = a2;
  execute(partDigit1_2_0);
  goto partDigit1_2_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,partDigit1_2F2_240_4_1);
  *reasonp++ =  a0;
  goto partDigit1_2F2_240_4_3;
  };
  goto partDigit1_2F2_240_4_3;
 partDigit1_2F2_240_4_3:
  otherwise(partDigit1_2F2_240_4_interrupt);
  generic_arg[0] = a0;
  allocp[0] = x0 = makeref(&allocp[0]);
  generic_arg[1] = x0;
  allocp[1] = x1 = makeref(&allocp[1]);
  generic_arg[2] = x1;
  call_generic(a3, functor_split_3, 2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_http_xpartDigit1_2F2_240_2F4_240_2);
  allocp[2] = x1;
  allocp[3] = a2;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_util_xatoi_2);
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a1;
  allocp[8] = (q)(struct goalrec*)&allocp[4];
  allocp[9] = (q)(&predicate_util_xstrToLst_2);
  allocp[10] = x0;
  allocp[11] = x2;
  qp = (struct goalrec*)&allocp[8];
  allocp += 12;
  proceed();
 partDigit1_2F2_240_4_ext_interrupt:
  reasonp = 0l;
 partDigit1_2F2_240_4_interrupt:
  toppred = &predicate_http_xpartDigit1_2F2_240_4;
  goto interrupt_4;
 }

 partDigit1_2F2_240_2F4_240_2_top: {
  q x0, x1, x2;
  qp = qp->next;
 partDigit1_2F2_240_2F4_240_2_clear_reason:
  reasonp = reasons;
 partDigit1_2F2_240_2F4_240_2_0:
 partDigit1_2F2_240_2F4_240_2_1:
  if (isref(a0)) goto partDigit1_2F2_240_2F4_240_2_4;
 partDigit1_2F2_240_2F4_240_2_2:
  if (isref(a0)) goto partDigit1_2F2_240_2F4_240_2_3;
  x0 = makefunctor(&string_const_0);
  if_not_equal(a0, x0, partDigit1_2F2_240_2F4_240_2_5);
  a0 = makefunctor(&string_const_0);
  execute(partDigit1_2_clear_reason);
  goto partDigit1_2_ext_interrupt;
 partDigit1_2F2_240_2F4_240_2_3:
  deref_and_jump(a0,partDigit1_2F2_240_2F4_240_2_2);
  *reasonp++ =  a0;
  goto partDigit1_2F2_240_2F4_240_2_5;
 partDigit1_2F2_240_2F4_240_2_4:
  deref_and_jump(a0,partDigit1_2F2_240_2F4_240_2_1);
  *reasonp++ =  a0;
  goto partDigit1_2F2_240_2F4_240_2_5;
 partDigit1_2F2_240_2F4_240_2_5:
  otherwise(partDigit1_2F2_240_2F4_240_2_interrupt);
  x0 = makeint(1L);
  generic_arg[0] = x0;
  allocp[0] = x1 = makeref(&allocp[0]);
  generic_arg[1] = x1;
  allocp[1] = x2 = makeref(&allocp[1]);
  generic_arg[2] = x2;
  call_generic(a0, functor_split_3, 2);
  a0 = x2;
  execute(partDigit1_2_0);
  goto partDigit1_2_ext_interrupt;
 partDigit1_2F2_240_2F4_240_2_ext_interrupt:
  reasonp = 0l;
 partDigit1_2F2_240_2F4_240_2_interrupt:
  goto interrupt_2;
 }

 httpcomm1_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 httpcomm1_9_clear_reason:
  reasonp = reasons;
 httpcomm1_9_0:
 httpcomm1_9_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_abnormal)) goto httpcomm1_9_interrupt;
  x0 = makesym(atom_abnormal);
  unify_value(a8, x0);
  proceed();
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_normal_1)) goto httpcomm1_9_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_http_xhttpGetResp_5);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a5;
  allocp[4] = a6;
  allocp[5] = a7;
  allocp[6] = a8;
  allocp[7] = makesym(functor_fwrite_2);
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = x3 = makeref(&allocp[9]);
  x1 = makefunctor(&allocp[7]);
  allocp[10] = makesym(functor_fflush_1);
  allocp[11] = x5 = makeref(&allocp[11]);
  x4 = makefunctor(&allocp[10]);
  allocp[12] = x0;
  allocp[13] = x4;
  x6 = makecons(&allocp[12]);
  allocp[14] = x6;
  allocp[15] = x1;
  x7 = makecons(&allocp[14]);
  x8 = arg(a0, 0);
  qp = (struct goalrec*)&allocp[0];
  allocp += 16;
  unify_value(x8, x7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_http_xmkReq_5);
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  allocp[5] = a4;
  allocp[6] = x2;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_builtin_xprint_1);
  allocp[9] = x8;
  allocp[10] = (q)(struct goalrec*)&allocp[7];
  allocp[11] = (q)(&predicate_builtin_xprint_1);
  allocp[12] = makefunctor(&string_const_7);
  qp = (struct goalrec*)&allocp[10];
  allocp += 13;
  proceed();
 case VARREF:
  deref_and_jump(a0,httpcomm1_9_1);
  *reasonp++ =  a0;
  goto httpcomm1_9_interrupt;
  };
  goto httpcomm1_9_interrupt;
 httpcomm1_9_ext_interrupt:
  reasonp = 0l;
 httpcomm1_9_interrupt:
  goto interrupt_9;
 }

 mkReq_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 mkReq_5_clear_reason:
  reasonp = reasons;
 mkReq_5_0:
  x0 = makefunctor(&string_const_2);
  generic_arg[0] = x0;
  allocp[0] = x1 = makeref(&allocp[0]);
  generic_arg[1] = x1;
  call_generic(a0, functor_join_2, 1);
  generic_arg[0] = a1;
  allocp[0] = x2 = makeref(&allocp[0]);
  generic_arg[1] = x2;
  call_generic(x1, functor_join_2, 1);
  x3 = makefunctor(&string_const_3);
  generic_arg[0] = x3;
  allocp[0] = x4 = makeref(&allocp[0]);
  generic_arg[1] = x4;
  call_generic(x2, functor_join_2, 1);
  generic_arg[0] = a2;
  allocp[0] = x5 = makeref(&allocp[0]);
  generic_arg[1] = x5;
  call_generic(x4, functor_join_2, 1);
  x6 = makefunctor(&string_const_1);
  generic_arg[0] = x6;
  allocp[0] = x7 = makeref(&allocp[0]);
  generic_arg[1] = x7;
  call_generic(x5, functor_join_2, 1);
  generic_arg[0] = a3;
  generic_arg[1] = a4;
  call_generic(x7, functor_join_2, 0);
  proceed();
 mkReq_5_ext_interrupt:
  reasonp = 0l;
 mkReq_5_interrupt:
  goto interrupt_5;
 }

 httpGetResp_5_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 httpGetResp_5_clear_reason:
  reasonp = reasons;
 httpGetResp_5_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_http_xpartHeadBody_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  a1 = x0;
  a2 = a3;
  a3 = a4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(httpGetResp1_4_0);
  goto httpGetResp1_4_ext_interrupt;
 httpGetResp_5_ext_interrupt:
  reasonp = 0l;
 httpGetResp_5_interrupt:
  goto interrupt_5;
 }

 httpGetResp1_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 httpGetResp1_4_clear_reason:
  reasonp = reasons;
 httpGetResp1_4_0:
 httpGetResp1_4_1:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_stop)) goto httpGetResp1_4_2;
  x0 = makesym(atom_stop);
  unify_value(a3, x0);
  x1 = NILATOM;
  unify_value(a0, x1);
  x2 = NILATOM;
  unify_value(a1, x2);
  proceed();
 case VARREF:
  deref_and_jump(a2,httpGetResp1_4_1);
  *reasonp++ =  a2;
  goto httpGetResp1_4_2;
  };
  goto httpGetResp1_4_2;
 httpGetResp1_4_2:
  alternative(httpGetResp1_4_clear_reason);
  allocp[0] = makesym(functor_fread_2);
  allocp[1] = makeint(128L);
  allocp[2] = x1 = makeref(&allocp[2]);
  x0 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_feof_1);
  allocp[4] = x3 = makeref(&allocp[4]);
  x2 = makefunctor(&allocp[3]);
  allocp[5] = x5 = makeref(&allocp[5]);
  allocp[6] = x2;
  x4 = makecons(&allocp[5]);
  allocp[7] = x4;
  allocp[8] = x0;
  x6 = makecons(&allocp[7]);
  allocp += 9;
  unify_value(a0, x6);
  a0 = x3;
  x7 = a1;
  a4 = a3;
  a5 = a2;
  a3 = x1;
  a2 = x7;
  a1 = x5;
  execute(httpGetResp1_2F4_240_6_clear_reason);
  goto httpGetResp1_2F4_240_6_ext_interrupt;
 httpGetResp1_4_ext_interrupt:
  reasonp = 0l;
 httpGetResp1_4_interrupt:
  toppred = &predicate_http_xhttpGetResp1_4;
  goto interrupt_4;
 }

 httpGetResp1_2F4_240_6_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 httpGetResp1_2F4_240_6_clear_reason:
  reasonp = reasons;
 httpGetResp1_2F4_240_6_0:
 httpGetResp1_2F4_240_6_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 httpGetResp1_2F4_240_6_2:
  switch ((unsigned long)a0) {
 case (unsigned long) makeint(1L):
  x0 = NILATOM;
  unify_value(a1, x0);
  allocp[0] = NILATOM;
  allocp[1] = a3;
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x1);
  x2 = makesym(atom_ok);
  unify_value(a4, x2);
  proceed();
 case (unsigned long) makeint(0L):
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = a3;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  a0 = a1;
  a1 = x1;
  a2 = a5;
  a3 = a4;
  execute(httpGetResp1_4_0);
  goto httpGetResp1_4_ext_interrupt;
  };
  goto httpGetResp1_2F4_240_6_interrupt;
 case VARREF:
  deref_and_jump(a0,httpGetResp1_2F4_240_6_1);
  *reasonp++ =  a0;
  goto httpGetResp1_2F4_240_6_interrupt;
  };
  goto httpGetResp1_2F4_240_6_interrupt;
 httpGetResp1_2F4_240_6_ext_interrupt:
  reasonp = 0l;
 httpGetResp1_2F4_240_6_interrupt:
  toppred = &predicate_http_xhttpGetResp1_2F4_240_6;
  goto interrupt_6;
 }

 partHeadBody_3_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  qp = qp->next;
 partHeadBody_3_clear_reason:
  reasonp = reasons;
 partHeadBody_3_0:
 partHeadBody_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = cdr_of(a0);
 partHeadBody_3_2:
  switch (ptagof(x0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  generic_arg[0] = x1;
  x2 = car_of(a0);
  call_generic(x2, functor_size_1, 1);
  a0 = x1;
  x3 = car_of(x0);
  a3 = cdr_of(x0);
  a4 = a1;
  a5 = a2;
  a2 = x3;
  a1 = x2;
  execute(partHeadBody_2F3_241_6_0);
  goto partHeadBody_2F3_241_6_ext_interrupt;
 case ATOMIC:
  if (x0 != NILATOM) goto partHeadBody_3_interrupt;
  allocp[0] = x1 = makeref(&allocp[0]);
  generic_arg[0] = x1;
  x2 = car_of(a0);
  call_generic(x2, functor_size_1, 1);
  a0 = x1;
  x3 = a1;
  a3 = a2;
  a2 = x3;
  a1 = x2;
  execute(partHeadBody_2F3_240_4_0);
  goto partHeadBody_2F3_240_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,partHeadBody_3_2);
  *reasonp++ =  x0;
  goto partHeadBody_3_interrupt;
  };
  goto partHeadBody_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto partHeadBody_3_interrupt;
  x0 = makefunctor(&string_const_0);
  unify_value(a1, x0);
  x1 = NILATOM;
  unify_value(a2, x1);
  proceed();
 case VARREF:
  deref_and_jump(a0,partHeadBody_3_1);
  *reasonp++ =  a0;
  goto partHeadBody_3_interrupt;
  };
  goto partHeadBody_3_interrupt;
 partHeadBody_3_ext_interrupt:
  reasonp = 0l;
 partHeadBody_3_interrupt:
  toppred = &predicate_http_xpartHeadBody_3;
  goto interrupt_3;
 }

 partHeadBody_2F3_241_6_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 partHeadBody_2F3_241_6_clear_reason:
  reasonp = reasons;
 partHeadBody_2F3_241_6_0:
 partHeadBody_2F3_241_6_1:
  if (!isint(a0)) goto partHeadBody_2F3_241_6_3;
  x0 = makeint(3L);
  gblt_greater(a0,x0,partHeadBody_2F3_241_6_2);
  x1 = makeint(4L);
  generic_arg[0] = x1;
  allocp[0] = x2 = makeref(&allocp[0]);
  generic_arg[1] = x2;
  allocp[1] = x3 = makeref(&allocp[1]);
  generic_arg[2] = x3;
  call_generic(a1, functor_split_3, 2);
  a0 = x2;
  execute(partHeadBody_2F3_241_2F6_240_6_0);
  goto partHeadBody_2F3_241_2F6_240_6_ext_interrupt;
 partHeadBody_2F3_241_6_2:
  x1 = makeint(3L);
  gblt_less_or_eq(a0,x1,partHeadBody_2F3_241_6_interrupt);
  generic_arg[0] = a2;
  allocp[0] = x2 = makeref(&allocp[0]);
  generic_arg[1] = x2;
  call_generic(a1, functor_join_2, 1);
  allocp[0] = a3;
  allocp[1] = x2;
  x3 = makecons(&allocp[0]);
  a0 = x3;
  a1 = a4;
  a2 = a5;
  allocp += 2;
  execute(partHeadBody_3_0);
  goto partHeadBody_3_ext_interrupt;
 partHeadBody_2F3_241_6_3:
  if (!isref(a0)) goto partHeadBody_2F3_241_6_interrupt;
  deref_and_jump(a0,partHeadBody_2F3_241_6_1);
  *reasonp++ =  a0;
  goto partHeadBody_2F3_241_6_interrupt;
 partHeadBody_2F3_241_6_ext_interrupt:
  reasonp = 0l;
 partHeadBody_2F3_241_6_interrupt:
  toppred = &predicate_http_xpartHeadBody_2F3_241_6;
  goto interrupt_6;
 }

 partHeadBody_2F3_241_2F6_240_6_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 partHeadBody_2F3_241_2F6_240_6_clear_reason:
  reasonp = reasons;
 partHeadBody_2F3_241_2F6_240_6_0:
 partHeadBody_2F3_241_2F6_240_6_1:
  if (isref(a0)) goto partHeadBody_2F3_241_2F6_240_6_4;
 partHeadBody_2F3_241_2F6_240_6_2:
  if (isref(a0)) goto partHeadBody_2F3_241_2F6_240_6_3;
  x0 = makefunctor(&string_const_5);
  if_not_equal(a0, x0, partHeadBody_2F3_241_2F6_240_6_5);
  allocp[0] = a3;
  allocp[1] = a2;
  x1 = makecons(&allocp[0]);
  allocp[2] = x1;
  allocp[3] = a1;
  x2 = makecons(&allocp[2]);
  a0 = x2;
  a1 = makefunctor(&string_const_0);
  a2 = a4;
  a3 = a5;
  allocp += 4;
  execute(partHeadBody1_4_clear_reason);
  goto partHeadBody1_4_ext_interrupt;
 partHeadBody_2F3_241_2F6_240_6_3:
  deref_and_jump(a0,partHeadBody_2F3_241_2F6_240_6_2);
  *reasonp++ =  a0;
  goto partHeadBody_2F3_241_2F6_240_6_5;
 partHeadBody_2F3_241_2F6_240_6_4:
  deref_and_jump(a0,partHeadBody_2F3_241_2F6_240_6_1);
  *reasonp++ =  a0;
  goto partHeadBody_2F3_241_2F6_240_6_5;
 partHeadBody_2F3_241_2F6_240_6_5:
  otherwise(partHeadBody_2F3_241_2F6_240_6_interrupt);
  x0 = NILATOM;
  unify_value(a4, x0);
  allocp[0] = a3;
  allocp[1] = a2;
  x1 = makecons(&allocp[0]);
  allocp[2] = x1;
  allocp[3] = a1;
  x2 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a5, x2);
  proceed();
 partHeadBody_2F3_241_2F6_240_6_ext_interrupt:
  reasonp = 0l;
 partHeadBody_2F3_241_2F6_240_6_interrupt:
  toppred = &predicate_http_xpartHeadBody_2F3_241_2F6_240_6;
  goto interrupt_6;
 }

 partHeadBody_2F3_240_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 partHeadBody_2F3_240_4_clear_reason:
  reasonp = reasons;
 partHeadBody_2F3_240_4_0:
 partHeadBody_2F3_240_4_1:
  if (!isint(a0)) goto partHeadBody_2F3_240_4_3;
  x0 = makeint(3L);
  gblt_greater(a0,x0,partHeadBody_2F3_240_4_2);
  x1 = makeint(4L);
  generic_arg[0] = x1;
  allocp[0] = x2 = makeref(&allocp[0]);
  generic_arg[1] = x2;
  allocp[1] = x3 = makeref(&allocp[1]);
  generic_arg[2] = x3;
  call_generic(a1, functor_split_3, 2);
  a0 = x2;
  execute(partHeadBody_2F3_240_2F4_240_4_0);
  goto partHeadBody_2F3_240_2F4_240_4_ext_interrupt;
 partHeadBody_2F3_240_4_2:
  x1 = makeint(3L);
  gblt_less_or_eq(a0,x1,partHeadBody_2F3_240_4_interrupt);
  unify(a2, a1);
  x2 = NILATOM;
  unify_value(a3, x2);
  proceed();
 partHeadBody_2F3_240_4_3:
  if (!isref(a0)) goto partHeadBody_2F3_240_4_interrupt;
  deref_and_jump(a0,partHeadBody_2F3_240_4_1);
  *reasonp++ =  a0;
  goto partHeadBody_2F3_240_4_interrupt;
 partHeadBody_2F3_240_4_ext_interrupt:
  reasonp = 0l;
 partHeadBody_2F3_240_4_interrupt:
  toppred = &predicate_http_xpartHeadBody_2F3_240_4;
  goto interrupt_4;
 }

 partHeadBody_2F3_240_2F4_240_4_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 partHeadBody_2F3_240_2F4_240_4_clear_reason:
  reasonp = reasons;
 partHeadBody_2F3_240_2F4_240_4_0:
 partHeadBody_2F3_240_2F4_240_4_1:
  if (isref(a0)) goto partHeadBody_2F3_240_2F4_240_4_4;
 partHeadBody_2F3_240_2F4_240_4_2:
  if (isref(a0)) goto partHeadBody_2F3_240_2F4_240_4_3;
  x0 = makefunctor(&string_const_5);
  if_not_equal(a0, x0, partHeadBody_2F3_240_2F4_240_4_5);
  allocp[0] = NILATOM;
  allocp[1] = a1;
  x1 = makecons(&allocp[0]);
  a0 = x1;
  a1 = makefunctor(&string_const_0);
  allocp += 2;
  execute(partHeadBody1_4_clear_reason);
  goto partHeadBody1_4_ext_interrupt;
 partHeadBody_2F3_240_2F4_240_4_3:
  deref_and_jump(a0,partHeadBody_2F3_240_2F4_240_4_2);
  *reasonp++ =  a0;
  goto partHeadBody_2F3_240_2F4_240_4_5;
 partHeadBody_2F3_240_2F4_240_4_4:
  deref_and_jump(a0,partHeadBody_2F3_240_2F4_240_4_1);
  *reasonp++ =  a0;
  goto partHeadBody_2F3_240_2F4_240_4_5;
 partHeadBody_2F3_240_2F4_240_4_5:
  otherwise(partHeadBody_2F3_240_2F4_240_4_interrupt);
  x0 = NILATOM;
  unify_value(a2, x0);
  allocp[0] = NILATOM;
  allocp[1] = a1;
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a3, x1);
  proceed();
 partHeadBody_2F3_240_2F4_240_4_ext_interrupt:
  reasonp = 0l;
 partHeadBody_2F3_240_2F4_240_4_interrupt:
  toppred = &predicate_http_xpartHeadBody_2F3_240_2F4_240_4;
  goto interrupt_4;
 }

 partHeadBody1_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 partHeadBody1_4_clear_reason:
  reasonp = reasons;
 partHeadBody1_4_0:
 partHeadBody1_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = cdr_of(a0);
 partHeadBody1_4_2:
  switch (ptagof(x0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  generic_arg[0] = x1;
  x2 = car_of(a0);
  call_generic(x2, functor_size_1, 1);
  x3 = makeint(4L);
  bblt_sub_no_check_y(x1,x3,x4);
  x5 = makeint(2L);
  bblt_sub_no_check_y(x1,x5,x6);
  a0 = x4;
  x7 = a1;
  a4 = a2;
  a5 = a3;
  a6 = car_of(x0);
  a7 = cdr_of(x0);
  a3 = x7;
  a2 = x6;
  a1 = x2;
  execute(partHeadBody1_2F4_241_8_0);
  goto partHeadBody1_2F4_241_8_ext_interrupt;
 case ATOMIC:
  if (x0 != NILATOM) goto partHeadBody1_4_interrupt;
  allocp[0] = x1 = makeref(&allocp[0]);
  generic_arg[0] = x1;
  x2 = car_of(a0);
  call_generic(x2, functor_size_1, 1);
  x3 = makeint(4L);
  bblt_sub_no_check_y(x1,x3,x4);
  x5 = makeint(2L);
  bblt_sub_no_check_y(x1,x5,x6);
  a0 = x4;
  x7 = a1;
  a4 = a2;
  a5 = a3;
  a3 = x7;
  a2 = x6;
  a1 = x2;
  execute(partHeadBody1_2F4_240_6_0);
  goto partHeadBody1_2F4_240_6_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,partHeadBody1_4_2);
  *reasonp++ =  x0;
  goto partHeadBody1_4_interrupt;
  };
  goto partHeadBody1_4_interrupt;
 case VARREF:
  deref_and_jump(a0,partHeadBody1_4_1);
  *reasonp++ =  a0;
  goto partHeadBody1_4_interrupt;
  };
  goto partHeadBody1_4_interrupt;
 partHeadBody1_4_ext_interrupt:
  reasonp = 0l;
 partHeadBody1_4_interrupt:
  toppred = &predicate_http_xpartHeadBody1_4;
  goto interrupt_4;
 }

 partHeadBody1_2F4_241_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 partHeadBody1_2F4_241_8_clear_reason:
  reasonp = reasons;
 partHeadBody1_2F4_241_8_0:
 partHeadBody1_2F4_241_8_1:
  if (!isint(a0)) goto partHeadBody1_2F4_241_8_2;
  x0 = makeint(0L);
  gblt_less_or_eq(x0,a0,partHeadBody1_2F4_241_8_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_http_xpartHeadBody1_2F4_241_2F8_240_14);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a3;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a4;
  allocp[6] = a5;
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = x4 = makeref(&allocp[10]);
  allocp[11] = x5 = makeref(&allocp[11]);
  allocp[12] = x6 = makeref(&allocp[12]);
  allocp[13] = x7 = makeref(&allocp[13]);
  allocp[14] = x8 = makeref(&allocp[14]);
  allocp[15] = a1;
  allocp[16] = (q)(struct goalrec*)&allocp[0];
  allocp[17] = (q)(&predicate_http_xpartHeadBodyLF_6);
  allocp[18] = a1;
  allocp[19] = a2;
  allocp[20] = x5;
  allocp[21] = x6;
  allocp[22] = x4;
  allocp[23] = x8;
  x9 = a1;
  a1 = a0;
  a2 = x2;
  a3 = x3;
  a4 = x1;
  a5 = x7;
  a0 = x9;
  qp = (struct goalrec*)&allocp[16];
  allocp += 24;
  execute(partHeadBodyCRLF_6_0);
  goto partHeadBodyCRLF_6_ext_interrupt;
 partHeadBody1_2F4_241_8_2:
  if (!isref(a0)) goto partHeadBody1_2F4_241_8_3;
  deref_and_jump(a0,partHeadBody1_2F4_241_8_1);
  *reasonp++ =  a0;
  goto partHeadBody1_2F4_241_8_3;
 partHeadBody1_2F4_241_8_3:
  otherwise(partHeadBody1_2F4_241_8_interrupt);
  generic_arg[0] = a6;
  allocp[0] = x0 = makeref(&allocp[0]);
  generic_arg[1] = x0;
  call_generic(a1, functor_join_2, 1);
  allocp[0] = a7;
  allocp[1] = x0;
  x1 = makecons(&allocp[0]);
  a0 = x1;
  a1 = a3;
  a2 = a4;
  a3 = a5;
  allocp += 2;
  execute(partHeadBody1_4_0);
  goto partHeadBody1_4_ext_interrupt;
 partHeadBody1_2F4_241_8_ext_interrupt:
  reasonp = 0l;
 partHeadBody1_2F4_241_8_interrupt:
  toppred = &predicate_http_xpartHeadBody1_2F4_241_8;
  goto interrupt_8;
 }

 partHeadBody1_2F4_241_2F8_240_14_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  qp = qp->next;
 partHeadBody1_2F4_241_2F8_240_14_clear_reason:
  reasonp = reasons;
 partHeadBody1_2F4_241_2F8_240_14_0:
 partHeadBody1_2F4_241_2F8_240_14_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_true)) goto partHeadBody1_2F4_241_2F8_240_14_2;
  generic_arg[0] = a2;
  generic_arg[1] = a3;
  call_generic(a1, functor_join_2, 0);
  allocp[0] = a7;
  allocp[1] = a6;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a5;
  x1 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a4, x1);
  proceed();
 case VARREF:
  deref_and_jump(a0,partHeadBody1_2F4_241_2F8_240_14_1);
  *reasonp++ =  a0;
  goto partHeadBody1_2F4_241_2F8_240_14_2;
  };
  goto partHeadBody1_2F4_241_2F8_240_14_2;
 partHeadBody1_2F4_241_2F8_240_14_2:
  otherwise(partHeadBody1_2F4_241_2F8_240_14_interrupt);
 partHeadBody1_2F4_241_2F8_240_14_3:
  switch (ptagof(a8)) {
 case ATOMIC:
  if (a8 != makesym(atom_true)) goto partHeadBody1_2F4_241_2F8_240_14_4;
  generic_arg[0] = a9;
  generic_arg[1] = a3;
  call_generic(a1, functor_join_2, 0);
  allocp[0] = a7;
  allocp[1] = a6;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a10;
  x1 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a4, x1);
  proceed();
 case VARREF:
  deref_and_jump(a8,partHeadBody1_2F4_241_2F8_240_14_3);
  *reasonp++ =  a8;
  goto partHeadBody1_2F4_241_2F8_240_14_4;
  };
  goto partHeadBody1_2F4_241_2F8_240_14_4;
 partHeadBody1_2F4_241_2F8_240_14_4:
  otherwise(partHeadBody1_2F4_241_2F8_240_14_interrupt);
  allocp[0] = a7;
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_http_xpartHeadBody1_4);
  allocp[4] = x0;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = makesym(functor_join_2);
  allocp[9] = a6;
  allocp[10] = x1;
  x3 = makefunctor(&allocp[8]);
  allocp[11] = (q)(struct goalrec*)&allocp[2];
  allocp[12] = (q)(&predicate_generic_xgeneric_2);
  allocp[13] = x3;
  allocp[14] = x4 = makeref(&allocp[14]);
  allocp[15] = makesym(functor_join_2);
  allocp[16] = x6 = makeref(&allocp[16]);
  allocp[17] = x2;
  x5 = makefunctor(&allocp[15]);
  allocp[18] = (q)(struct goalrec*)&allocp[11];
  allocp[19] = (q)(&predicate_generic_xgeneric_2);
  allocp[20] = x5;
  allocp[21] = a1;
  allocp[22] = makesym(functor_split_3);
  allocp[23] = x8 = makeref(&allocp[23]);
  allocp[24] = x6;
  allocp[25] = x4;
  x7 = makefunctor(&allocp[22]);
  allocp[26] = (q)(struct goalrec*)&allocp[18];
  allocp[27] = (q)(&predicate_generic_xgeneric_2);
  allocp[28] = x7;
  allocp[29] = a13;
  allocp[30] = (q)(struct goalrec*)&allocp[26];
  allocp[31] = (q)(&predicate_util_xmin_3);
  allocp[32] = a11;
  allocp[33] = a12;
  allocp[34] = x8;
  qp = (struct goalrec*)&allocp[30];
  allocp += 35;
  proceed();
 partHeadBody1_2F4_241_2F8_240_14_ext_interrupt:
  reasonp = 0l;
 partHeadBody1_2F4_241_2F8_240_14_interrupt:
  goto interrupt_14;
 }

 partHeadBody1_2F4_240_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 partHeadBody1_2F4_240_6_clear_reason:
  reasonp = reasons;
 partHeadBody1_2F4_240_6_0:
 partHeadBody1_2F4_240_6_1:
  if (!isint(a0)) goto partHeadBody1_2F4_240_6_2;
  x0 = makeint(0L);
  gblt_less_or_eq(x0,a0,partHeadBody1_2F4_240_6_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_http_xpartHeadBody1_2F4_240_2F6_240_12);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a3;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a4;
  allocp[6] = a5;
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = x5 = makeref(&allocp[9]);
  allocp[10] = x6 = makeref(&allocp[10]);
  allocp[11] = x7 = makeref(&allocp[11]);
  allocp[12] = x8 = makeref(&allocp[12]);
  allocp[13] = a1;
  allocp[14] = (q)(struct goalrec*)&allocp[0];
  allocp[15] = (q)(&predicate_http_xpartHeadBodyLF_6);
  allocp[16] = a1;
  allocp[17] = a2;
  allocp[18] = x5;
  allocp[19] = x6;
  allocp[20] = x4;
  allocp[21] = x8;
  x9 = a1;
  a1 = a0;
  a2 = x2;
  a3 = x3;
  a4 = x1;
  a5 = x7;
  a0 = x9;
  qp = (struct goalrec*)&allocp[14];
  allocp += 22;
  execute(partHeadBodyCRLF_6_0);
  goto partHeadBodyCRLF_6_ext_interrupt;
 partHeadBody1_2F4_240_6_2:
  if (!isref(a0)) goto partHeadBody1_2F4_240_6_3;
  deref_and_jump(a0,partHeadBody1_2F4_240_6_1);
  *reasonp++ =  a0;
  goto partHeadBody1_2F4_240_6_3;
 partHeadBody1_2F4_240_6_3:
  otherwise(partHeadBody1_2F4_240_6_interrupt);
  generic_arg[0] = a1;
  generic_arg[1] = a4;
  call_generic(a3, functor_join_2, 0);
  x0 = NILATOM;
  unify_value(a5, x0);
  proceed();
 partHeadBody1_2F4_240_6_ext_interrupt:
  reasonp = 0l;
 partHeadBody1_2F4_240_6_interrupt:
  toppred = &predicate_http_xpartHeadBody1_2F4_240_6;
  goto interrupt_6;
 }

 partHeadBody1_2F4_240_2F6_240_12_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 partHeadBody1_2F4_240_2F6_240_12_clear_reason:
  reasonp = reasons;
 partHeadBody1_2F4_240_2F6_240_12_0:
 partHeadBody1_2F4_240_2F6_240_12_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_true)) goto partHeadBody1_2F4_240_2F6_240_12_2;
  generic_arg[0] = a2;
  generic_arg[1] = a3;
  call_generic(a1, functor_join_2, 0);
  allocp[0] = NILATOM;
  allocp[1] = a5;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a4, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,partHeadBody1_2F4_240_2F6_240_12_1);
  *reasonp++ =  a0;
  goto partHeadBody1_2F4_240_2F6_240_12_2;
  };
  goto partHeadBody1_2F4_240_2F6_240_12_2;
 partHeadBody1_2F4_240_2F6_240_12_2:
  otherwise(partHeadBody1_2F4_240_2F6_240_12_interrupt);
 partHeadBody1_2F4_240_2F6_240_12_3:
  switch (ptagof(a6)) {
 case ATOMIC:
  if (a6 != makesym(atom_true)) goto partHeadBody1_2F4_240_2F6_240_12_4;
  generic_arg[0] = a7;
  generic_arg[1] = a3;
  call_generic(a1, functor_join_2, 0);
  allocp[0] = NILATOM;
  allocp[1] = a8;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a4, x0);
  proceed();
 case VARREF:
  deref_and_jump(a6,partHeadBody1_2F4_240_2F6_240_12_3);
  *reasonp++ =  a6;
  goto partHeadBody1_2F4_240_2F6_240_12_4;
  };
  goto partHeadBody1_2F4_240_2F6_240_12_4;
 partHeadBody1_2F4_240_2F6_240_12_4:
  otherwise(partHeadBody1_2F4_240_2F6_240_12_interrupt);
  allocp[0] = NILATOM;
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_http_xpartHeadBody1_4);
  allocp[4] = x0;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = makesym(functor_join_2);
  allocp[9] = x4 = makeref(&allocp[9]);
  allocp[10] = x2;
  x3 = makefunctor(&allocp[8]);
  allocp[11] = (q)(struct goalrec*)&allocp[2];
  allocp[12] = (q)(&predicate_generic_xgeneric_2);
  allocp[13] = x3;
  allocp[14] = a1;
  allocp[15] = makesym(functor_split_3);
  allocp[16] = x6 = makeref(&allocp[16]);
  allocp[17] = x4;
  allocp[18] = x1;
  x5 = makefunctor(&allocp[15]);
  allocp[19] = (q)(struct goalrec*)&allocp[11];
  allocp[20] = (q)(&predicate_generic_xgeneric_2);
  allocp[21] = x5;
  allocp[22] = a11;
  allocp[23] = (q)(struct goalrec*)&allocp[19];
  allocp[24] = (q)(&predicate_util_xmin_3);
  allocp[25] = a9;
  allocp[26] = a10;
  allocp[27] = x6;
  qp = (struct goalrec*)&allocp[23];
  allocp += 28;
  proceed();
 partHeadBody1_2F4_240_2F6_240_12_ext_interrupt:
  reasonp = 0l;
 partHeadBody1_2F4_240_2F6_240_12_interrupt:
  goto interrupt_12;
 }

 partHeadBodyCRLF_6_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 partHeadBodyCRLF_6_clear_reason:
  reasonp = reasons;
 partHeadBodyCRLF_6_0:
  x0 = makeint(0L);
  generic_arg[0] = x0;
  generic_arg[1] = a1;
  x1 = makeint(13L);
  generic_arg[2] = x1;
  allocp[0] = x2 = makeref(&allocp[0]);
  generic_arg[3] = x2;
  call_generic(a0, functor_search__character_4, 1);
  x3 = a4;
  a4 = a5;
  a5 = a1;
  a6 = a0;
  a1 = x3;
  a0 = x2;
  execute(partHeadBodyCRLF_2F6_240_7_0);
  goto partHeadBodyCRLF_2F6_240_7_ext_interrupt;
 partHeadBodyCRLF_6_ext_interrupt:
  reasonp = 0l;
 partHeadBodyCRLF_6_interrupt:
  toppred = &predicate_http_xpartHeadBodyCRLF_6;
  goto interrupt_6;
 }

 partHeadBodyCRLF_2F6_240_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 partHeadBodyCRLF_2F6_240_7_clear_reason:
  reasonp = reasons;
 partHeadBodyCRLF_2F6_240_7_0:
 partHeadBodyCRLF_2F6_240_7_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 partHeadBodyCRLF_2F6_240_7_2:
  if (a0 != makeint(-1L)) goto partHeadBodyCRLF_2F6_240_7_3;
  x0 = makesym(atom_false);
  unify_value(a1, x0);
  x1 = makefunctor(&string_const_0);
  unify_value(a2, x1);
  x2 = makefunctor(&string_const_0);
  unify_value(a3, x2);
  x3 = makeint(1L);
  bblt_add_no_check_y(a5,x3,x4);
  unify(a4, x4);
  proceed();
 case VARREF:
  deref_and_jump(a0,partHeadBodyCRLF_2F6_240_7_1);
  *reasonp++ =  a0;
  goto partHeadBodyCRLF_2F6_240_7_interrupt;
  };
  goto partHeadBodyCRLF_2F6_240_7_3;
 partHeadBodyCRLF_2F6_240_7_3:
  x0 = makeint(-1L);
  gblt_diff(a0,x0,partHeadBodyCRLF_2F6_240_7_interrupt);
  x1 = makeint(1L);
  bblt_add_no_check_y(a0,x1,x2);
  x3 = makeint(2L);
  bblt_add_no_check_y(a0,x3,x4);
  x5 = makeint(3L);
  bblt_add_no_check_y(a0,x5,x6);
  generic_arg[0] = x2;
  allocp[0] = x7 = makeref(&allocp[0]);
  generic_arg[1] = x7;
  call_generic(a6, functor_element_2, 1);
  generic_arg[0] = x4;
  allocp[0] = x8 = makeref(&allocp[0]);
  generic_arg[1] = x8;
  call_generic(a6, functor_element_2, 1);
  generic_arg[0] = x6;
  allocp[0] = x9 = makeref(&allocp[0]);
  generic_arg[1] = x9;
  call_generic(a6, functor_element_2, 1);
  a0 = x7;
  x10 = a1;
  a5 = x6;
  a7 = a2;
  a8 = a3;
  a9 = x2;
  a3 = x10;
  a2 = x9;
  a1 = x8;
  execute(partHeadBodyCRLF_2F6_240_2F7_240_10_0);
  goto partHeadBodyCRLF_2F6_240_2F7_240_10_ext_interrupt;
 partHeadBodyCRLF_2F6_240_7_ext_interrupt:
  reasonp = 0l;
 partHeadBodyCRLF_2F6_240_7_interrupt:
  toppred = &predicate_http_xpartHeadBodyCRLF_2F6_240_7;
  goto interrupt_7;
 }

 partHeadBodyCRLF_2F6_240_2F7_240_10_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 partHeadBodyCRLF_2F6_240_2F7_240_10_clear_reason:
  reasonp = reasons;
 partHeadBodyCRLF_2F6_240_2F7_240_10_0:
 partHeadBodyCRLF_2F6_240_2F7_240_10_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 partHeadBodyCRLF_2F6_240_2F7_240_10_2:
  if (a0 != makeint(10L)) goto partHeadBodyCRLF_2F6_240_2F7_240_10_7;
 partHeadBodyCRLF_2F6_240_2F7_240_10_3:
  switch (ptagof(a1)) {
 case ATOMIC:
 partHeadBodyCRLF_2F6_240_2F7_240_10_4:
  if (a1 != makeint(13L)) goto partHeadBodyCRLF_2F6_240_2F7_240_10_7;
 partHeadBodyCRLF_2F6_240_2F7_240_10_5:
  switch (ptagof(a2)) {
 case ATOMIC:
 partHeadBodyCRLF_2F6_240_2F7_240_10_6:
  if (a2 != makeint(10L)) goto partHeadBodyCRLF_2F6_240_2F7_240_10_7;
  x0 = makesym(atom_true);
  unify_value(a3, x0);
  x1 = makeint(1L);
  bblt_add_no_check_y(a5,x1,x2);
  unify(a4, x2);
  generic_arg[0] = a4;
  generic_arg[1] = a7;
  generic_arg[2] = a8;
  call_generic(a6, functor_split_3, 0);
  proceed();
 case VARREF:
  deref_and_jump(a2,partHeadBodyCRLF_2F6_240_2F7_240_10_5);
  *reasonp++ =  a2;
  goto partHeadBodyCRLF_2F6_240_2F7_240_10_7;
  };
  goto partHeadBodyCRLF_2F6_240_2F7_240_10_7;
 case VARREF:
  deref_and_jump(a1,partHeadBodyCRLF_2F6_240_2F7_240_10_3);
  *reasonp++ =  a1;
  goto partHeadBodyCRLF_2F6_240_2F7_240_10_7;
  };
  goto partHeadBodyCRLF_2F6_240_2F7_240_10_7;
 case VARREF:
  deref_and_jump(a0,partHeadBodyCRLF_2F6_240_2F7_240_10_1);
  *reasonp++ =  a0;
  goto partHeadBodyCRLF_2F6_240_2F7_240_10_7;
  };
  goto partHeadBodyCRLF_2F6_240_2F7_240_10_7;
 partHeadBodyCRLF_2F6_240_2F7_240_10_7:
  otherwise(partHeadBodyCRLF_2F6_240_2F7_240_10_interrupt);
  x0 = makesym(atom_false);
  unify_value(a3, x0);
  x1 = makefunctor(&string_const_0);
  unify_value(a7, x1);
  x2 = makefunctor(&string_const_0);
  unify_value(a8, x2);
  unify(a4, a9);
  proceed();
 partHeadBodyCRLF_2F6_240_2F7_240_10_ext_interrupt:
  reasonp = 0l;
 partHeadBodyCRLF_2F6_240_2F7_240_10_interrupt:
  toppred = &predicate_http_xpartHeadBodyCRLF_2F6_240_2F7_240_10;
  goto interrupt_10;
 }

 partHeadBodyLF_6_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 partHeadBodyLF_6_clear_reason:
  reasonp = reasons;
 partHeadBodyLF_6_0:
  x0 = makeint(0L);
  generic_arg[0] = x0;
  generic_arg[1] = a1;
  x1 = makeint(10L);
  generic_arg[2] = x1;
  allocp[0] = x2 = makeref(&allocp[0]);
  generic_arg[3] = x2;
  call_generic(a0, functor_search__character_4, 1);
  x3 = a4;
  a4 = a5;
  a5 = a1;
  a6 = a0;
  a1 = x3;
  a0 = x2;
  execute(partHeadBodyLF_2F6_240_7_0);
  goto partHeadBodyLF_2F6_240_7_ext_interrupt;
 partHeadBodyLF_6_ext_interrupt:
  reasonp = 0l;
 partHeadBodyLF_6_interrupt:
  goto interrupt_6;
 }

 partHeadBodyLF_2F6_240_7_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 partHeadBodyLF_2F6_240_7_clear_reason:
  reasonp = reasons;
 partHeadBodyLF_2F6_240_7_0:
 partHeadBodyLF_2F6_240_7_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 partHeadBodyLF_2F6_240_7_2:
  if (a0 != makeint(-1L)) goto partHeadBodyLF_2F6_240_7_3;
  x0 = makesym(atom_false);
  unify_value(a1, x0);
  x1 = makefunctor(&string_const_0);
  unify_value(a2, x1);
  x2 = makefunctor(&string_const_0);
  unify_value(a3, x2);
  x3 = makeint(1L);
  bblt_add_no_check_y(a5,x3,x4);
  unify(a4, x4);
  proceed();
 case VARREF:
  deref_and_jump(a0,partHeadBodyLF_2F6_240_7_1);
  *reasonp++ =  a0;
  goto partHeadBodyLF_2F6_240_7_interrupt;
  };
  goto partHeadBodyLF_2F6_240_7_3;
 partHeadBodyLF_2F6_240_7_3:
  x0 = makeint(-1L);
  gblt_diff(a0,x0,partHeadBodyLF_2F6_240_7_interrupt);
  x1 = makeint(1L);
  bblt_add_no_check_y(a0,x1,x2);
  generic_arg[0] = x2;
  allocp[0] = x3 = makeref(&allocp[0]);
  generic_arg[1] = x3;
  call_generic(a6, functor_element_2, 1);
  a0 = x3;
  x4 = a4;
  a4 = a6;
  a5 = a2;
  a6 = a3;
  a3 = x2;
  a2 = x4;
  execute(partHeadBodyLF_2F6_240_2F7_240_7_0);
  goto partHeadBodyLF_2F6_240_2F7_240_7_ext_interrupt;
 partHeadBodyLF_2F6_240_7_ext_interrupt:
  reasonp = 0l;
 partHeadBodyLF_2F6_240_7_interrupt:
  toppred = &predicate_http_xpartHeadBodyLF_2F6_240_7;
  goto interrupt_7;
 }

 partHeadBodyLF_2F6_240_2F7_240_7_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 partHeadBodyLF_2F6_240_2F7_240_7_clear_reason:
  reasonp = reasons;
 partHeadBodyLF_2F6_240_2F7_240_7_0:
 partHeadBodyLF_2F6_240_2F7_240_7_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 partHeadBodyLF_2F6_240_2F7_240_7_2:
  if (a0 != makeint(10L)) goto partHeadBodyLF_2F6_240_2F7_240_7_3;
  x0 = makesym(atom_true);
  unify_value(a1, x0);
  x1 = makeint(1L);
  bblt_add_no_check_y(a3,x1,x2);
  unify(a2, x2);
  generic_arg[0] = a2;
  generic_arg[1] = a5;
  generic_arg[2] = a6;
  call_generic(a4, functor_split_3, 0);
  proceed();
 case VARREF:
  deref_and_jump(a0,partHeadBodyLF_2F6_240_2F7_240_7_1);
  *reasonp++ =  a0;
  goto partHeadBodyLF_2F6_240_2F7_240_7_3;
  };
  goto partHeadBodyLF_2F6_240_2F7_240_7_3;
 partHeadBodyLF_2F6_240_2F7_240_7_3:
  otherwise(partHeadBodyLF_2F6_240_2F7_240_7_interrupt);
  x0 = makesym(atom_false);
  unify_value(a1, x0);
  x1 = makefunctor(&string_const_0);
  unify_value(a5, x1);
  x2 = makefunctor(&string_const_0);
  unify_value(a6, x2);
  unify(a2, a3);
  proceed();
 partHeadBodyLF_2F6_240_2F7_240_7_ext_interrupt:
  reasonp = 0l;
 partHeadBodyLF_2F6_240_2F7_240_7_interrupt:
  toppred = &predicate_http_xpartHeadBodyLF_2F6_240_2F7_240_7;
  goto interrupt_7;
 }

 filetype_2_top: {
  q x0;
  qp = qp->next;
 filetype_2_clear_reason:
  reasonp = reasons;
 filetype_2_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_http_xpartContentType_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  a1 = a0;
  a2 = x0;
  a0 = makefunctor(&string_const_4);
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  execute(searchHead_3_0);
  goto searchHead_3_ext_interrupt;
 filetype_2_ext_interrupt:
  reasonp = 0l;
 filetype_2_interrupt:
  goto interrupt_2;
 }

 partHead_2_top: {
  q x0, x1, x2, x3, x4, x5;
  qp = qp->next;
 partHead_2_clear_reason:
  reasonp = reasons;
 partHead_2_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_http_xpartHead2_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_http_xpartHead1_3);
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = x3;
  allocp[10] = x2;
  x4 = makecons(&allocp[9]);
  qp = (struct goalrec*)&allocp[4];
  allocp += 11;
  unify_value(x0, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_util_xcrlfToLf_2);
  allocp[2] = x5 = makeref(&allocp[2]);
  allocp[3] = x1;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_util_xstrToLst_2);
  allocp[6] = a0;
  allocp[7] = x5;
  qp = (struct goalrec*)&allocp[4];
  allocp += 8;
  proceed();
 partHead_2_ext_interrupt:
  reasonp = 0l;
 partHead_2_interrupt:
  goto interrupt_2;
 }

 partHead1_3_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  qp = qp->next;
 partHead1_3_clear_reason:
  reasonp = reasons;
 partHead1_3_0:
 partHead1_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 partHead1_3_2:
  switch (ptagof(x0)) {
 case ATOMIC:
 partHead1_3_3:
  if (x0 != makeint(10L)) goto partHead1_3_7;
  x1 = cdr_of(a0);
 partHead1_3_4:
  switch (ptagof(x1)) {
 case CONS:
  x2 = car_of(x1);
 partHead1_3_5:
  switch (ptagof(x2)) {
 case ATOMIC:
 partHead1_3_6:
  if (x2 != makeint(32L)) goto partHead1_3_7;
  allocp[0] = x4 = makeref(&allocp[0]);
  allocp[1] = makeint(32L);
  x3 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x3);
  a0 = cdr_of(x1);
  a1 = x4;
  execute(partHead1_3_0);
  goto partHead1_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x2,partHead1_3_5);
  *reasonp++ =  x2;
  goto partHead1_3_7;
  };
  goto partHead1_3_7;
 case VARREF:
  deref_and_jump(x1,partHead1_3_4);
  *reasonp++ =  x1;
  goto partHead1_3_7;
  };
  goto partHead1_3_7;
 case VARREF:
  deref_and_jump(x0,partHead1_3_2);
  *reasonp++ =  x0;
  goto partHead1_3_7;
  };
  goto partHead1_3_7;
 case VARREF:
  deref_and_jump(a0,partHead1_3_1);
  *reasonp++ =  a0;
  goto partHead1_3_7;
  };
  goto partHead1_3_7;
 partHead1_3_7:
  otherwise(partHead1_3_interrupt);
 partHead1_3_8:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 partHead1_3_9:
  switch (ptagof(x0)) {
 case ATOMIC:
 partHead1_3_10:
  if (x0 != makeint(10L)) goto partHead1_3_11;
  x1 = NILATOM;
  unify_value(a1, x1);
  allocp[0] = x3 = makeref(&allocp[0]);
  allocp[1] = x4 = makeref(&allocp[1]);
  x2 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x2);
  a0 = cdr_of(a0);
  a1 = x4;
  a2 = x3;
  execute(partHead1_3_0);
  goto partHead1_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,partHead1_3_9);
  *reasonp++ =  x0;
  goto partHead1_3_11;
  };
  goto partHead1_3_11;
 case VARREF:
  deref_and_jump(a0,partHead1_3_8);
  *reasonp++ =  a0;
  goto partHead1_3_11;
  };
  goto partHead1_3_11;
 partHead1_3_11:
  otherwise(partHead1_3_interrupt);
 partHead1_3_12:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(partHead1_3_0);
  goto partHead1_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto partHead1_3_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  x1 = NILATOM;
  unify_value(a2, x1);
  proceed();
 case VARREF:
  deref_and_jump(a0,partHead1_3_12);
  *reasonp++ =  a0;
  goto partHead1_3_interrupt;
  };
  goto partHead1_3_interrupt;
 partHead1_3_ext_interrupt:
  reasonp = 0l;
 partHead1_3_interrupt:
  goto interrupt_3;
 }

 partHead2_2_top: {
  q x0, x1, x2, x3, x4;
  qp = qp->next;
 partHead2_2_clear_reason:
  reasonp = reasons;
 partHead2_2_0:
 partHead2_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
  generic_arg[0] = x0;
  x1 = makeint(8L);
  generic_arg[1] = x1;
  new_generic(string_g_new, 2, x2, 0);
  allocp[0] = x4 = makeref(&allocp[0]);
  allocp[1] = x2;
  x3 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x3);
  a0 = cdr_of(a0);
  a1 = x4;
  execute(partHead2_2_0);
  goto partHead2_2_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto partHead2_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,partHead2_2_1);
  *reasonp++ =  a0;
  goto partHead2_2_interrupt;
  };
  goto partHead2_2_interrupt;
 partHead2_2_ext_interrupt:
  reasonp = 0l;
 partHead2_2_interrupt:
  goto interrupt_2;
 }

 searchHead_3_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  qp = qp->next;
 searchHead_3_clear_reason:
  reasonp = reasons;
 searchHead_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_http_xignoreParam_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a2;
  allocp[4] = x1 = makeref(&allocp[4]);
  generic_arg[0] = x1;
  x2 = makeint(8L);
  generic_arg[1] = x2;
  qp = (struct goalrec*)&allocp[0];
  new_generic(string_g_new, 2, x3, 5);
  unify(x0, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_http_xrmCommentSP_2);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = x1;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_http_xsearchHead1_3);
  allocp[6] = x5 = makeref(&allocp[6]);
  allocp[7] = a1;
  allocp[8] = x4;
  allocp[9] = (q)(struct goalrec*)&allocp[4];
  allocp[10] = (q)(&predicate_util_xtoLower_2);
  allocp[11] = x6 = makeref(&allocp[11]);
  allocp[12] = x5;
  allocp[13] = (q)(struct goalrec*)&allocp[9];
  allocp[14] = (q)(&predicate_util_xstrToLst_2);
  allocp[15] = a0;
  allocp[16] = x6;
  qp = (struct goalrec*)&allocp[13];
  allocp += 17;
  proceed();
 searchHead_3_ext_interrupt:
  reasonp = 0l;
 searchHead_3_interrupt:
  toppred = &predicate_http_xsearchHead_3;
  goto interrupt_3;
 }

 searchHead1_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  qp = qp->next;
 searchHead1_3_clear_reason:
  reasonp = reasons;
 searchHead1_3_0:
 searchHead1_3_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 searchHead1_3_2:
  if (isref(x0)) goto searchHead1_3_5;
 searchHead1_3_3:
  if (isref(x0)) goto searchHead1_3_4;
  x1 = makefunctor(&string_const_0);
  if_not_equal(x0, x1, searchHead1_3_6);
  a1 = cdr_of(a1);
  execute(searchHead1_3_clear_reason);
  goto searchHead1_3_ext_interrupt;
 searchHead1_3_4:
  deref_and_jump(x0,searchHead1_3_3);
  *reasonp++ =  x0;
  goto searchHead1_3_6;
 searchHead1_3_5:
  deref_and_jump(x0,searchHead1_3_2);
  *reasonp++ =  x0;
  goto searchHead1_3_6;
 case VARREF:
  deref_and_jump(a1,searchHead1_3_1);
  *reasonp++ =  a1;
  goto searchHead1_3_6;
  };
  goto searchHead1_3_6;
 searchHead1_3_6:
  otherwise(searchHead1_3_interrupt);
 searchHead1_3_7:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = x0 = makeref(&allocp[0]);
  generic_arg[0] = x0;
  x1 = car_of(a1);
  call_generic(x1, functor_size_1, 1);
  x2 = makeint(1L);
  bblt_sub_no_check_y(x0,x2,x3);
  x4 = makeint(0L);
  generic_arg[0] = x4;
  generic_arg[1] = x3;
  x5 = makeint(58L);
  generic_arg[2] = x5;
  allocp[0] = x6 = makeref(&allocp[0]);
  generic_arg[3] = x6;
  call_generic(x1, functor_search__character_4, 1);
  x7 = a0;
  x8 = cdr_of(a1);
  a3 = a2;
  a4 = x1;
  a2 = x8;
  a1 = x7;
  a0 = x6;
  execute(searchHead1_2F3_240_5_0);
  goto searchHead1_2F3_240_5_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto searchHead1_3_interrupt;
  x0 = makefunctor(&string_const_0);
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,searchHead1_3_7);
  *reasonp++ =  a1;
  goto searchHead1_3_interrupt;
  };
  goto searchHead1_3_interrupt;
 searchHead1_3_ext_interrupt:
  reasonp = 0l;
 searchHead1_3_interrupt:
  toppred = &predicate_http_xsearchHead1_3;
  goto interrupt_3;
 }

 searchHead1_2F3_240_5_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 searchHead1_2F3_240_5_clear_reason:
  reasonp = reasons;
 searchHead1_2F3_240_5_0:
 searchHead1_2F3_240_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 searchHead1_2F3_240_5_2:
  if (a0 != makeint(-1L)) goto searchHead1_2F3_240_5_3;
  a0 = a1;
  a1 = a2;
  a2 = a3;
  execute(searchHead1_3_0);
  goto searchHead1_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,searchHead1_2F3_240_5_1);
  *reasonp++ =  a0;
  goto searchHead1_2F3_240_5_3;
  };
  goto searchHead1_2F3_240_5_3;
 searchHead1_2F3_240_5_3:
  otherwise(searchHead1_2F3_240_5_interrupt);
  generic_arg[0] = a0;
  allocp[0] = x0 = makeref(&allocp[0]);
  generic_arg[1] = x0;
  allocp[1] = x1 = makeref(&allocp[1]);
  generic_arg[2] = x1;
  call_generic(a4, functor_split_3, 2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_http_xsearchHead1_2F3_240_2F5_240_5);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x1;
  allocp[5] = a3;
  allocp[6] = a2;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_util_xtoLower_2);
  allocp[9] = x3 = makeref(&allocp[9]);
  allocp[10] = x2;
  allocp[11] = (q)(struct goalrec*)&allocp[7];
  allocp[12] = (q)(&predicate_util_xstrToLst_2);
  allocp[13] = x0;
  allocp[14] = x3;
  qp = (struct goalrec*)&allocp[11];
  allocp += 15;
  proceed();
 searchHead1_2F3_240_5_ext_interrupt:
  reasonp = 0l;
 searchHead1_2F3_240_5_interrupt:
  toppred = &predicate_http_xsearchHead1_2F3_240_5;
  goto interrupt_5;
 }

 searchHead1_2F3_240_2F5_240_5_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 searchHead1_2F3_240_2F5_240_5_clear_reason:
  reasonp = reasons;
 searchHead1_2F3_240_2F5_240_5_0:
 searchHead1_2F3_240_2F5_240_5_1:
  if (isref(a0)) goto searchHead1_2F3_240_2F5_240_5_4;
 searchHead1_2F3_240_2F5_240_5_2:
  if (isref(a0)) goto searchHead1_2F3_240_2F5_240_5_3;
  if_not_equal(a0, a1, searchHead1_2F3_240_2F5_240_5_5);
  x0 = makeint(1L);
  generic_arg[0] = x0;
  allocp[0] = x1 = makeref(&allocp[0]);
  generic_arg[1] = x1;
  generic_arg[2] = a3;
  call_generic(a2, functor_split_3, 1);
  proceed();
 searchHead1_2F3_240_2F5_240_5_3:
  deref_and_jump(a0,searchHead1_2F3_240_2F5_240_5_2);
  *reasonp++ =  a0;
  goto searchHead1_2F3_240_2F5_240_5_5;
 searchHead1_2F3_240_2F5_240_5_4:
  deref_and_jump(a0,searchHead1_2F3_240_2F5_240_5_1);
  *reasonp++ =  a0;
  goto searchHead1_2F3_240_2F5_240_5_5;
 searchHead1_2F3_240_2F5_240_5_5:
  otherwise(searchHead1_2F3_240_2F5_240_5_interrupt);
  a0 = a1;
  a1 = a4;
  a2 = a3;
  execute(searchHead1_3_0);
  goto searchHead1_3_ext_interrupt;
 searchHead1_2F3_240_2F5_240_5_ext_interrupt:
  reasonp = 0l;
 searchHead1_2F3_240_2F5_240_5_interrupt:
  goto interrupt_5;
 }

 rmCommentSP_2_top: {
  q x0;
  qp = qp->next;
 rmCommentSP_2_clear_reason:
  reasonp = reasons;
 rmCommentSP_2_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_http_xrmCommentSP1_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_util_xstrToLst_2);
  allocp[6] = a0;
  allocp[7] = x0;
  qp = (struct goalrec*)&allocp[4];
  allocp += 8;
  proceed();
 rmCommentSP_2_ext_interrupt:
  reasonp = 0l;
 rmCommentSP_2_interrupt:
  goto interrupt_2;
 }

 rmCommentSP1_2_top: {
  q x0, x1, x2;
  qp = qp->next;
 rmCommentSP1_2_clear_reason:
  reasonp = reasons;
 rmCommentSP1_2_0:
 rmCommentSP1_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 rmCommentSP1_2_2:
  switch (ptagof(x0)) {
 case ATOMIC:
 rmCommentSP1_2_3:
  switch ((unsigned long)x0) {
 case (unsigned long) makeint(34L):
  a0 = cdr_of(a0);
  execute(rmCommentSPDQ_2_0);
  goto rmCommentSPDQ_2_ext_interrupt;
 case (unsigned long) makeint(60L):
  a0 = cdr_of(a0);
  execute(rmCommentSPBr_2_0);
  goto rmCommentSPBr_2_ext_interrupt;
 case (unsigned long) makeint(40L):
  a0 = cdr_of(a0);
  execute(rmCommentSPComm_2_0);
  goto rmCommentSPComm_2_ext_interrupt;
 case (unsigned long) makeint(32L):
  a0 = cdr_of(a0);
  execute(rmCommentSP1_2_0);
  goto rmCommentSP1_2_ext_interrupt;
  };
  goto rmCommentSP1_2_4;
 case VARREF:
  deref_and_jump(x0,rmCommentSP1_2_2);
  *reasonp++ =  x0;
  goto rmCommentSP1_2_4;
  };
  goto rmCommentSP1_2_4;
 case VARREF:
  deref_and_jump(a0,rmCommentSP1_2_1);
  *reasonp++ =  a0;
  goto rmCommentSP1_2_4;
  };
  goto rmCommentSP1_2_4;
 rmCommentSP1_2_4:
  otherwise(rmCommentSP1_2_interrupt);
 rmCommentSP1_2_5:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(rmCommentSP1_2_0);
  goto rmCommentSP1_2_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto rmCommentSP1_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,rmCommentSP1_2_5);
  *reasonp++ =  a0;
  goto rmCommentSP1_2_interrupt;
  };
  goto rmCommentSP1_2_interrupt;
 rmCommentSP1_2_ext_interrupt:
  reasonp = 0l;
 rmCommentSP1_2_interrupt:
  toppred = &predicate_http_xrmCommentSP1_2;
  goto interrupt_2;
 }

 rmCommentSPDQ_2_top: {
  q x0, x1, x2;
  qp = qp->next;
 rmCommentSPDQ_2_clear_reason:
  reasonp = reasons;
 rmCommentSPDQ_2_0:
 rmCommentSPDQ_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 rmCommentSPDQ_2_2:
  switch (ptagof(x0)) {
 case ATOMIC:
 rmCommentSPDQ_2_3:
  if (x0 != makeint(34L)) goto rmCommentSPDQ_2_4;
  a0 = cdr_of(a0);
  execute(rmCommentSP1_2_0);
  goto rmCommentSP1_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,rmCommentSPDQ_2_2);
  *reasonp++ =  x0;
  goto rmCommentSPDQ_2_4;
  };
  goto rmCommentSPDQ_2_4;
 case VARREF:
  deref_and_jump(a0,rmCommentSPDQ_2_1);
  *reasonp++ =  a0;
  goto rmCommentSPDQ_2_4;
  };
  goto rmCommentSPDQ_2_4;
 rmCommentSPDQ_2_4:
  otherwise(rmCommentSPDQ_2_interrupt);
 rmCommentSPDQ_2_5:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(rmCommentSPDQ_2_0);
  goto rmCommentSPDQ_2_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,rmCommentSPDQ_2_5);
  *reasonp++ =  a0;
  goto rmCommentSPDQ_2_interrupt;
  };
  goto rmCommentSPDQ_2_interrupt;
 rmCommentSPDQ_2_ext_interrupt:
  reasonp = 0l;
 rmCommentSPDQ_2_interrupt:
  toppred = &predicate_http_xrmCommentSPDQ_2;
  goto interrupt_2;
 }

 rmCommentSPBr_2_top: {
  q x0, x1, x2;
  qp = qp->next;
 rmCommentSPBr_2_clear_reason:
  reasonp = reasons;
 rmCommentSPBr_2_0:
 rmCommentSPBr_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 rmCommentSPBr_2_2:
  switch (ptagof(x0)) {
 case ATOMIC:
 rmCommentSPBr_2_3:
  if (x0 != makeint(62L)) goto rmCommentSPBr_2_4;
  a0 = cdr_of(a0);
  execute(rmCommentSP1_2_0);
  goto rmCommentSP1_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,rmCommentSPBr_2_2);
  *reasonp++ =  x0;
  goto rmCommentSPBr_2_4;
  };
  goto rmCommentSPBr_2_4;
 case VARREF:
  deref_and_jump(a0,rmCommentSPBr_2_1);
  *reasonp++ =  a0;
  goto rmCommentSPBr_2_4;
  };
  goto rmCommentSPBr_2_4;
 rmCommentSPBr_2_4:
  otherwise(rmCommentSPBr_2_interrupt);
 rmCommentSPBr_2_5:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(rmCommentSPBr_2_0);
  goto rmCommentSPBr_2_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,rmCommentSPBr_2_5);
  *reasonp++ =  a0;
  goto rmCommentSPBr_2_interrupt;
  };
  goto rmCommentSPBr_2_interrupt;
 rmCommentSPBr_2_ext_interrupt:
  reasonp = 0l;
 rmCommentSPBr_2_interrupt:
  toppred = &predicate_http_xrmCommentSPBr_2;
  goto interrupt_2;
 }

 rmCommentSPComm_2_top: {
  q x0, x1, x2;
  qp = qp->next;
 rmCommentSPComm_2_clear_reason:
  reasonp = reasons;
 rmCommentSPComm_2_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_http_xrmCommentSP1_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_util_xrev_2);
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = x0;
  allocp[8] = (q)(struct goalrec*)&allocp[4];
  allocp[9] = (q)(&predicate_http_xsearchCommentEnd_2);
  allocp[10] = x2 = makeref(&allocp[10]);
  allocp[11] = x1;
  allocp[12] = (q)(struct goalrec*)&allocp[8];
  allocp[13] = (q)(&predicate_util_xrev_2);
  allocp[14] = a0;
  allocp[15] = x2;
  qp = (struct goalrec*)&allocp[12];
  allocp += 16;
  proceed();
 rmCommentSPComm_2_ext_interrupt:
  reasonp = 0l;
 rmCommentSPComm_2_interrupt:
  toppred = &predicate_http_xrmCommentSPComm_2;
  goto interrupt_2;
 }

 searchCommentEnd_2_top: {
  q x0, x1, x2;
  qp = qp->next;
 searchCommentEnd_2_clear_reason:
  reasonp = reasons;
 searchCommentEnd_2_0:
 searchCommentEnd_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 searchCommentEnd_2_2:
  switch (ptagof(x0)) {
 case ATOMIC:
 searchCommentEnd_2_3:
  if (x0 != makeint(41L)) goto searchCommentEnd_2_4;
  x1 = NILATOM;
  unify_value(a1, x1);
  proceed();
 case VARREF:
  deref_and_jump(x0,searchCommentEnd_2_2);
  *reasonp++ =  x0;
  goto searchCommentEnd_2_4;
  };
  goto searchCommentEnd_2_4;
 case VARREF:
  deref_and_jump(a0,searchCommentEnd_2_1);
  *reasonp++ =  a0;
  goto searchCommentEnd_2_4;
  };
  goto searchCommentEnd_2_4;
 searchCommentEnd_2_4:
  otherwise(searchCommentEnd_2_interrupt);
 searchCommentEnd_2_5:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(searchCommentEnd_2_0);
  goto searchCommentEnd_2_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto searchCommentEnd_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,searchCommentEnd_2_5);
  *reasonp++ =  a0;
  goto searchCommentEnd_2_interrupt;
  };
  goto searchCommentEnd_2_interrupt;
 searchCommentEnd_2_ext_interrupt:
  reasonp = 0l;
 searchCommentEnd_2_interrupt:
  goto interrupt_2;
 }

 ignoreParam_2_top: {
  q x0, x1, x2, x3, x4, x5;
  qp = qp->next;
 ignoreParam_2_clear_reason:
  reasonp = reasons;
 ignoreParam_2_0:
 ignoreParam_2_1:
  if (isref(a0)) goto ignoreParam_2_4;
 ignoreParam_2_2:
  if (isref(a0)) goto ignoreParam_2_3;
  x0 = makefunctor(&string_const_0);
  if_not_equal(a0, x0, ignoreParam_2_5);
  x1 = makefunctor(&string_const_0);
  unify_value(a1, x1);
  proceed();
 ignoreParam_2_3:
  deref_and_jump(a0,ignoreParam_2_2);
  *reasonp++ =  a0;
  goto ignoreParam_2_5;
 ignoreParam_2_4:
  deref_and_jump(a0,ignoreParam_2_1);
  *reasonp++ =  a0;
  goto ignoreParam_2_5;
 ignoreParam_2_5:
  otherwise(ignoreParam_2_interrupt);
  allocp[0] = x0 = makeref(&allocp[0]);
  generic_arg[0] = x0;
  call_generic(a0, functor_size_1, 1);
  x1 = makeint(1L);
  bblt_sub_no_check_y(x0,x1,x2);
  x3 = makeint(0L);
  generic_arg[0] = x3;
  generic_arg[1] = x2;
  x4 = makeint(59L);
  generic_arg[2] = x4;
  allocp[0] = x5 = makeref(&allocp[0]);
  generic_arg[3] = x5;
  call_generic(a0, functor_search__character_4, 1);
  a2 = a0;
  a0 = x5;
  execute(ignoreParam_2F2_240_3_0);
  goto ignoreParam_2F2_240_3_ext_interrupt;
 ignoreParam_2_ext_interrupt:
  reasonp = 0l;
 ignoreParam_2_interrupt:
  goto interrupt_2;
 }

 ignoreParam_2F2_240_3_top: {
  q x0;
  a2 = qp->args[2];
  qp = qp->next;
 ignoreParam_2F2_240_3_clear_reason:
  reasonp = reasons;
 ignoreParam_2F2_240_3_0:
 ignoreParam_2F2_240_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 ignoreParam_2F2_240_3_2:
  if (a0 != makeint(-1L)) goto ignoreParam_2F2_240_3_3;
  unify(a1, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,ignoreParam_2F2_240_3_1);
  *reasonp++ =  a0;
  goto ignoreParam_2F2_240_3_3;
  };
  goto ignoreParam_2F2_240_3_3;
 ignoreParam_2F2_240_3_3:
  otherwise(ignoreParam_2F2_240_3_interrupt);
  generic_arg[0] = a0;
  generic_arg[1] = a1;
  allocp[0] = x0 = makeref(&allocp[0]);
  generic_arg[2] = x0;
  call_generic(a2, functor_split_3, 1);
  proceed();
 ignoreParam_2F2_240_3_ext_interrupt:
  reasonp = 0l;
 ignoreParam_2F2_240_3_interrupt:
  toppred = &predicate_http_xignoreParam_2F2_240_3;
  goto interrupt_3;
 }

 partContentType_2_top: {
  q x0, x1, x2, x3, x4, x5;
  qp = qp->next;
 partContentType_2_clear_reason:
  reasonp = reasons;
 partContentType_2_0:
 partContentType_2_1:
  if (isref(a0)) goto partContentType_2_4;
 partContentType_2_2:
  if (isref(a0)) goto partContentType_2_3;
  x0 = makefunctor(&string_const_0);
  if_not_equal(a0, x0, partContentType_2_5);
  x1 = makesym(atom_not__found);
  unify_value(a1, x1);
  proceed();
 partContentType_2_3:
  deref_and_jump(a0,partContentType_2_2);
  *reasonp++ =  a0;
  goto partContentType_2_5;
 partContentType_2_4:
  deref_and_jump(a0,partContentType_2_1);
  *reasonp++ =  a0;
  goto partContentType_2_5;
 partContentType_2_5:
  otherwise(partContentType_2_interrupt);
  allocp[0] = x0 = makeref(&allocp[0]);
  generic_arg[0] = x0;
  call_generic(a0, functor_size_1, 1);
  x1 = makeint(1L);
  bblt_sub_no_check_y(x0,x1,x2);
  x3 = makeint(0L);
  generic_arg[0] = x3;
  generic_arg[1] = x2;
  x4 = makeint(47L);
  generic_arg[2] = x4;
  allocp[0] = x5 = makeref(&allocp[0]);
  generic_arg[3] = x5;
  call_generic(a0, functor_search__character_4, 1);
  a2 = a0;
  a0 = x5;
  execute(partContentType_2F2_240_3_0);
  goto partContentType_2F2_240_3_ext_interrupt;
 partContentType_2_ext_interrupt:
  reasonp = 0l;
 partContentType_2_interrupt:
  goto interrupt_2;
 }

 partContentType_2F2_240_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a2 = qp->args[2];
  qp = qp->next;
 partContentType_2F2_240_3_clear_reason:
  reasonp = reasons;
 partContentType_2F2_240_3_0:
 partContentType_2F2_240_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 partContentType_2F2_240_3_2:
  if (a0 != makeint(-1L)) goto partContentType_2F2_240_3_3;
  x0 = makesym(atom_not__found);
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,partContentType_2F2_240_3_1);
  *reasonp++ =  a0;
  goto partContentType_2F2_240_3_3;
  };
  goto partContentType_2F2_240_3_3;
 partContentType_2F2_240_3_3:
  otherwise(partContentType_2F2_240_3_interrupt);
  generic_arg[0] = a0;
  allocp[0] = x0 = makeref(&allocp[0]);
  generic_arg[1] = x0;
  allocp[1] = x1 = makeref(&allocp[1]);
  generic_arg[2] = x1;
  call_generic(a2, functor_split_3, 2);
  x2 = makeint(1L);
  generic_arg[0] = x2;
  allocp[0] = x3 = makeref(&allocp[0]);
  generic_arg[1] = x3;
  allocp[1] = x4 = makeref(&allocp[1]);
  generic_arg[2] = x4;
  call_generic(x1, functor_split_3, 2);
  allocp[0] = makesym(functor__2F_2);
  allocp[1] = x6 = makeref(&allocp[1]);
  allocp[2] = x7 = makeref(&allocp[2]);
  x5 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a1, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_util_xlstToAtom_2);
  allocp[2] = x8 = makeref(&allocp[2]);
  allocp[3] = x7;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_util_xtoLower_2);
  allocp[6] = x9 = makeref(&allocp[6]);
  allocp[7] = x8;
  allocp[8] = (q)(struct goalrec*)&allocp[4];
  allocp[9] = (q)(&predicate_util_xstrToLst_2);
  allocp[10] = x4;
  allocp[11] = x9;
  allocp[12] = (q)(struct goalrec*)&allocp[8];
  allocp[13] = (q)(&predicate_util_xlstToAtom_2);
  allocp[14] = x10 = makeref(&allocp[14]);
  allocp[15] = x6;
  allocp[16] = (q)(struct goalrec*)&allocp[12];
  allocp[17] = (q)(&predicate_util_xtoLower_2);
  allocp[18] = x11 = makeref(&allocp[18]);
  allocp[19] = x10;
  allocp[20] = (q)(struct goalrec*)&allocp[16];
  allocp[21] = (q)(&predicate_util_xstrToLst_2);
  allocp[22] = x0;
  allocp[23] = x11;
  qp = (struct goalrec*)&allocp[20];
  allocp += 24;
  proceed();
 partContentType_2F2_240_3_ext_interrupt:
  reasonp = 0l;
 partContentType_2F2_240_3_interrupt:
  toppred = &predicate_http_xpartContentType_2F2_240_3;
  goto interrupt_3;
 }

 getStatusCode_2_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  qp = qp->next;
 getStatusCode_2_clear_reason:
  reasonp = reasons;
 getStatusCode_2_0:
 getStatusCode_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 getStatusCode_2_2:
  if (isref(x0)) goto getStatusCode_2_5;
 getStatusCode_2_3:
  if (isref(x0)) goto getStatusCode_2_4;
  x1 = makefunctor(&string_const_0);
  if_not_equal(x0, x1, getStatusCode_2_6);
  x2 = makefunctor(&string_const_0);
  unify_value(a1, x2);
  proceed();
 getStatusCode_2_4:
  deref_and_jump(x0,getStatusCode_2_3);
  *reasonp++ =  x0;
  goto getStatusCode_2_6;
 getStatusCode_2_5:
  deref_and_jump(x0,getStatusCode_2_2);
  *reasonp++ =  x0;
  goto getStatusCode_2_6;
 case VARREF:
  deref_and_jump(a0,getStatusCode_2_1);
  *reasonp++ =  a0;
  goto getStatusCode_2_6;
  };
  goto getStatusCode_2_6;
 getStatusCode_2_6:
  otherwise(getStatusCode_2_interrupt);
 getStatusCode_2_7:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x0 = makeref(&allocp[0]);
  generic_arg[0] = x0;
  x1 = car_of(a0);
  call_generic(x1, functor_size_1, 1);
  x2 = makeint(1L);
  bblt_sub_no_check_y(x0,x2,x3);
  x4 = makeint(0L);
  generic_arg[0] = x4;
  generic_arg[1] = x3;
  x5 = makeint(32L);
  generic_arg[2] = x5;
  allocp[0] = x6 = makeref(&allocp[0]);
  generic_arg[3] = x6;
  call_generic(x1, functor_search__character_4, 1);
  a0 = x6;
  a2 = x1;
  execute(getStatusCode_2F2_240_3_0);
  goto getStatusCode_2F2_240_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,getStatusCode_2_7);
  *reasonp++ =  a0;
  goto getStatusCode_2_interrupt;
  };
  goto getStatusCode_2_interrupt;
 getStatusCode_2_ext_interrupt:
  reasonp = 0l;
 getStatusCode_2_interrupt:
  goto interrupt_2;
 }

 getStatusCode_2F2_240_3_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  qp = qp->next;
 getStatusCode_2F2_240_3_clear_reason:
  reasonp = reasons;
 getStatusCode_2F2_240_3_0:
 getStatusCode_2F2_240_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 getStatusCode_2F2_240_3_2:
  if (a0 != makeint(-1L)) goto getStatusCode_2F2_240_3_3;
  x0 = makefunctor(&string_const_0);
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,getStatusCode_2F2_240_3_1);
  *reasonp++ =  a0;
  goto getStatusCode_2F2_240_3_3;
  };
  goto getStatusCode_2F2_240_3_3;
 getStatusCode_2F2_240_3_3:
  otherwise(getStatusCode_2F2_240_3_interrupt);
  generic_arg[0] = a0;
  allocp[0] = x0 = makeref(&allocp[0]);
  generic_arg[1] = x0;
  allocp[1] = x1 = makeref(&allocp[1]);
  generic_arg[2] = x1;
  call_generic(a2, functor_split_3, 2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_http_xgetStatusCode_2F2_240_2F3_240_2);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_util_xskipSP_2);
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = x2;
  allocp[8] = (q)(struct goalrec*)&allocp[4];
  allocp[9] = (q)(&predicate_util_xstrToLst_2);
  allocp[10] = x1;
  allocp[11] = x3;
  qp = (struct goalrec*)&allocp[8];
  allocp += 12;
  proceed();
 getStatusCode_2F2_240_3_ext_interrupt:
  reasonp = 0l;
 getStatusCode_2F2_240_3_interrupt:
  toppred = &predicate_http_xgetStatusCode_2F2_240_3;
  goto interrupt_3;
 }

 getStatusCode_2F2_240_2F3_240_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  qp = qp->next;
 getStatusCode_2F2_240_2F3_240_2_clear_reason:
  reasonp = reasons;
 getStatusCode_2F2_240_2F3_240_2_0:
 getStatusCode_2F2_240_2F3_240_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = cdr_of(a0);
 getStatusCode_2F2_240_2F3_240_2_2:
  switch (ptagof(x0)) {
 case CONS:
  x1 = cdr_of(x0);
 getStatusCode_2F2_240_2F3_240_2_3:
  switch (ptagof(x1)) {
 case CONS:
  allocp[0] = NILATOM;
  x3 = car_of(x1);
  allocp[1] = x3;
  x2 = makecons(&allocp[0]);
  allocp[2] = x2;
  x5 = car_of(x0);
  allocp[3] = x5;
  x4 = makecons(&allocp[2]);
  allocp[4] = x4;
  x7 = car_of(a0);
  allocp[5] = x7;
  x6 = makecons(&allocp[4]);
  generic_arg[0] = x6;
  x8 = makeint(8L);
  generic_arg[1] = x8;
  new_generic(string_g_new, 2, x9, 6);
  unify(a1, x9);
  proceed();
 case VARREF:
  deref_and_jump(x1,getStatusCode_2F2_240_2F3_240_2_3);
  *reasonp++ =  x1;
  goto getStatusCode_2F2_240_2F3_240_2_4;
  };
  goto getStatusCode_2F2_240_2F3_240_2_4;
 case VARREF:
  deref_and_jump(x0,getStatusCode_2F2_240_2F3_240_2_2);
  *reasonp++ =  x0;
  goto getStatusCode_2F2_240_2F3_240_2_4;
  };
  goto getStatusCode_2F2_240_2F3_240_2_4;
 case VARREF:
  deref_and_jump(a0,getStatusCode_2F2_240_2F3_240_2_1);
  *reasonp++ =  a0;
  goto getStatusCode_2F2_240_2F3_240_2_4;
  };
  goto getStatusCode_2F2_240_2F3_240_2_4;
 getStatusCode_2F2_240_2F3_240_2_4:
  otherwise(getStatusCode_2F2_240_2F3_240_2_interrupt);
  x0 = makefunctor(&string_const_0);
  unify_value(a1, x0);
  proceed();
 getStatusCode_2F2_240_2F3_240_2_ext_interrupt:
  reasonp = 0l;
 getStatusCode_2F2_240_2F3_240_2_interrupt:
  goto interrupt_2;
 }

 newLocation_2_top: {
  q x0;
  qp = qp->next;
 newLocation_2_clear_reason:
  reasonp = reasons;
 newLocation_2_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_http_xnewLocation_2F2_240_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  a1 = a0;
  a2 = x0;
  a0 = makefunctor(&string_const_9);
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(searchHead_3_0);
  goto searchHead_3_ext_interrupt;
 newLocation_2_ext_interrupt:
  reasonp = 0l;
 newLocation_2_interrupt:
  goto interrupt_2;
 }

 newLocation_2F2_240_3_top: {
  q x0;
  a2 = qp->args[2];
  qp = qp->next;
 newLocation_2F2_240_3_clear_reason:
  reasonp = reasons;
 newLocation_2F2_240_3_0:
 newLocation_2F2_240_3_1:
  if (isref(a0)) goto newLocation_2F2_240_3_4;
 newLocation_2F2_240_3_2:
  if (isref(a0)) goto newLocation_2F2_240_3_3;
  x0 = makefunctor(&string_const_0);
  if_not_equal(a0, x0, newLocation_2F2_240_3_5);
  a0 = makefunctor(&string_const_6);
  execute(searchHead_3_clear_reason);
  goto searchHead_3_ext_interrupt;
 newLocation_2F2_240_3_3:
  deref_and_jump(a0,newLocation_2F2_240_3_2);
  *reasonp++ =  a0;
  goto newLocation_2F2_240_3_5;
 newLocation_2F2_240_3_4:
  deref_and_jump(a0,newLocation_2F2_240_3_1);
  *reasonp++ =  a0;
  goto newLocation_2F2_240_3_5;
 newLocation_2F2_240_3_5:
  otherwise(newLocation_2F2_240_3_interrupt);
  unify(a2, a0);
  proceed();
 newLocation_2F2_240_3_ext_interrupt:
  reasonp = 0l;
 newLocation_2F2_240_3_interrupt:
  goto interrupt_3;
 }
 interrupt_14:
  allocp[15] = a13;
 interrupt_13:
  allocp[14] = a12;
 interrupt_12:
  allocp[13] = a11;
 interrupt_11:
  allocp[12] = a10;
 interrupt_10:
  allocp[11] = a9;
 interrupt_9:
  allocp[10] = a8;
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_http);
}
