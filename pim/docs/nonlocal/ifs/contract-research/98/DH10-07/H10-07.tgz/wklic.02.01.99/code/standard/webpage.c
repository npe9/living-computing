/* Compiled by KLIC compiler version 3.001 (Thu Jun  5 20:19:10 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_main();
Const struct predicate predicate_main_xmain_0 =
   { module_main, 0, 0 };
Const struct predicate predicate_main_xprint__page_2 =
   { module_main, 1, 2 };
Const struct predicate predicate_main_xprint__page_2F2_240_2 =
   { module_main, 2, 2 };
extern Const struct predicate predicate_builtin_xprint_1;
extern Const struct predicate predicate_page_xgetwebpage_3;

module module_main(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  static Const unsigned char strconst_body_0[20] =
    "Page not accessible";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_0 =
      declare_string_constant_8(strconst_body_0,19);
  static Const unsigned char strconst_body_1[24] =
    "http://www.cs.nmsu.edu";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_1 =
      declare_string_constant_8(strconst_body_1,22);
  q a0, a1;

  q *reasonp;
 module_top:
  switch_on_pred() {
    case_pred(0, main_0_top);
    case_pred(1, print__page_2_top);
    last_case_pred(2, print__page_2F2_240_2_top);
  }

 main_0_top: {
  q x0, x1;
  qp = qp->next;
 main_0_clear_reason:
  reasonp = reasons;
 main_0_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_main_xprint__page_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_page_xgetwebpage_3);
  allocp[6] = makefunctor(&string_const_1);
  allocp[7] = x0;
  allocp[8] = x1;
  qp = (struct goalrec*)&allocp[4];
  allocp += 9;
  proceed();
 main_0_ext_interrupt:
  reasonp = 0l;
 main_0_interrupt:
  goto interrupt_0;
 }

 print__page_2_top: {
  q x0;
  a0 = qp->args[0];
  a1 = qp->args[1];
  qp = qp->next;
 print__page_2_clear_reason:
  reasonp = reasons;
 print__page_2_0:
  x0 = a1;
  a1 = a0;
  a0 = x0;
  execute(print__page_2F2_240_2_0);
  goto print__page_2F2_240_2_ext_interrupt;
 print__page_2_ext_interrupt:
  reasonp = 0l;
 print__page_2_interrupt:
  goto interrupt_2;
 }

 print__page_2F2_240_2_top: {
  a0 = qp->args[0];
  a1 = qp->args[1];
  qp = qp->next;
 print__page_2F2_240_2_clear_reason:
  reasonp = reasons;
 print__page_2F2_240_2_0:
 print__page_2F2_240_2_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_ok)) goto print__page_2F2_240_2_2;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin_xprint_1);
  allocp[2] = a1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 3;
  proceed();
 case VARREF:
  deref_and_jump(a0,print__page_2F2_240_2_1);
  *reasonp++ =  a0;
  goto print__page_2F2_240_2_2;
  };
  goto print__page_2F2_240_2_2;
 print__page_2F2_240_2_2:
  otherwise(print__page_2F2_240_2_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin_xprint_1);
  allocp[2] = makefunctor(&string_const_0);
  qp = (struct goalrec*)&allocp[0];
  allocp += 3;
  proceed();
 print__page_2F2_240_2_ext_interrupt:
  reasonp = 0l;
 print__page_2F2_240_2_interrupt:
  toppred = &predicate_main_xprint__page_2F2_240_2;
  goto interrupt_2;
 }
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_main);
}
