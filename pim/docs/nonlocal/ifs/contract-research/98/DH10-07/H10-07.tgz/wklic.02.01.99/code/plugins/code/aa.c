/* Compiled by KLIC compiler version 3.001 (Thu Jun  5 20:19:10 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_main();
Const struct predicate predicate_main_xmain_0 =
   { module_main, 0, 0 };
Const struct predicate predicate_main_xcontinue_1 =
   { module_main, 1, 1 };
Const struct predicate predicate_main_xsubcont1_1 =
   { module_main, 2, 1 };
Const struct predicate predicate_main_xmy__target_2 =
   { module_main, 3, 2 };
Const struct predicate predicate_main_xpi__cazzuto_2 =
   { module_main, 4, 2 };
Const struct predicate predicate_main_xcontinue__cazzuto1_2 =
   { module_main, 5, 2 };
Const struct predicate predicate_main_xcontinue__cazzuto_2 =
   { module_main, 6, 2 };
extern Const struct predicate predicate_builtin_xprint_1;

module module_main(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  static Const unsigned char strconst_body_0[24] =
    "Initialization failed";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_0 =
      declare_string_constant_8(strconst_body_0,21);
  q a0, a1;

  q *reasonp;
 module_top:
  switch_on_pred() {
    case_pred(0, main_0_top);
    case_pred(1, continue_1_top);
    case_pred(2, subcont1_1_top);
    case_pred(3, my__target_2_top);
    case_pred(4, pi__cazzuto_2_top);
    case_pred(5, continue__cazzuto1_2_top);
    last_case_pred(6, continue__cazzuto_2_top);
  }

 main_0_top: {
  qp = qp->next;
 main_0_clear_reason:
  reasonp = reasons;
 main_0_0:
  a0 = makeint(0L);
  execute(continue_1_0);
  goto continue_1_ext_interrupt;
 main_0_ext_interrupt:
  reasonp = 0l;
 main_0_interrupt:
  goto interrupt_0;
 }

 continue_1_top: {
  q x0, x1, x2, x3, x4;
  a0 = qp->args[0];
  qp = qp->next;
 continue_1_clear_reason:
  reasonp = reasons;
 continue_1_0:
 continue_1_1:
  if (isref(a0)) goto continue_1_5;
  x1 = makeint(1L);
  gblt_compare(a0,x1,x0,continue_1_3);
 continue_1_2:
  if (x0 != makeint(0L)) goto continue_1_3;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin_xprint_1);
  allocp[2] = makefunctor(&string_const_0);
  qp = (struct goalrec*)&allocp[0];
  allocp += 3;
  proceed();
 continue_1_3:
  x3 = makeint(0L);
  gblt_compare(a0,x3,x2,continue_1_interrupt);
 continue_1_4:
  if (x2 != makeint(0L)) goto continue_1_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_main_xsubcont1_1);
  allocp[2] = x4 = makeref(&allocp[2]);
  a0 = makesym(atom_popo);
  a1 = x4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 3;
  execute(pi__cazzuto_2_0);
  goto pi__cazzuto_2_ext_interrupt;
 continue_1_5:
  deref_and_jump(a0,continue_1_1);
  *reasonp++ =  a0;
  goto continue_1_interrupt;
 continue_1_ext_interrupt:
  reasonp = 0l;
 continue_1_interrupt:
  toppred = &predicate_main_xcontinue_1;
  goto interrupt_1;
 }

 subcont1_1_top: {
  a0 = qp->args[0];
  qp = qp->next;
 subcont1_1_clear_reason:
  reasonp = reasons;
 subcont1_1_0:
 subcont1_1_1:
  if (isref(a0)) goto subcont1_1_2;
  gblt_wait(a0,subcont1_1_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin_xprint_1);
  allocp[2] = a0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 3;
  proceed();
 subcont1_1_2:
  deref_and_jump(a0,subcont1_1_1);
  *reasonp++ =  a0;
  goto subcont1_1_interrupt;
 subcont1_1_ext_interrupt:
  reasonp = 0l;
 subcont1_1_interrupt:
  goto interrupt_1;
 }

 my__target_2_top: {
  q x0;
  a0 = qp->args[0];
  a1 = qp->args[1];
  qp = qp->next;
 my__target_2_clear_reason:
  reasonp = reasons;
 my__target_2_0:
 my__target_2_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto my__target_2_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_cacca)):
  { printf("browser\n"); }
  x0 = makeint(1L);
  unify_value(a1, x0);
  proceed();
 case symval(makesym(atom_pipi)):
  { printf("stream\n");
		   }
  x0 = makeint(0L);
  unify_value(a1, x0);
  proceed();
 case symval(makesym(atom_popo)):
  { printf("file\n");
		   }
  x0 = makeint(2L);
  unify_value(a1, x0);
  proceed();
  };
  goto my__target_2_interrupt;
 case VARREF:
  deref_and_jump(a0,my__target_2_1);
  *reasonp++ =  a0;
  goto my__target_2_interrupt;
  };
  goto my__target_2_interrupt;
 my__target_2_ext_interrupt:
  reasonp = 0l;
 my__target_2_interrupt:
  toppred = &predicate_main_xmy__target_2;
  goto interrupt_2;
 }

 pi__cazzuto_2_top: {
  q x0;
  a0 = qp->args[0];
  a1 = qp->args[1];
  qp = qp->next;
 pi__cazzuto_2_clear_reason:
  reasonp = reasons;
 pi__cazzuto_2_0:
 pi__cazzuto_2_1:
  if (isref(a0)) goto pi__cazzuto_2_2;
  gblt_wait(a0,pi__cazzuto_2_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_main_xcontinue__cazzuto1_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  a1 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  execute(my__target_2_0);
  goto my__target_2_ext_interrupt;
 pi__cazzuto_2_2:
  deref_and_jump(a0,pi__cazzuto_2_1);
  *reasonp++ =  a0;
  goto pi__cazzuto_2_interrupt;
 pi__cazzuto_2_ext_interrupt:
  reasonp = 0l;
 pi__cazzuto_2_interrupt:
  toppred = &predicate_main_xpi__cazzuto_2;
  goto interrupt_2;
 }

 continue__cazzuto1_2_top: {
  a0 = qp->args[0];
  a1 = qp->args[1];
  qp = qp->next;
 continue__cazzuto1_2_clear_reason:
  reasonp = reasons;
 continue__cazzuto1_2_0:
 continue__cazzuto1_2_1:
  if (!isint(a0)) goto continue__cazzuto1_2_2;
  { printf("entering cazzuot\n");
		   exit(0); }
  execute(continue__cazzuto_2_clear_reason);
  goto continue__cazzuto_2_ext_interrupt;
 continue__cazzuto1_2_2:
  if (!isref(a0)) goto continue__cazzuto1_2_interrupt;
  deref_and_jump(a0,continue__cazzuto1_2_1);
  *reasonp++ =  a0;
  goto continue__cazzuto1_2_interrupt;
 continue__cazzuto1_2_ext_interrupt:
  reasonp = 0l;
 continue__cazzuto1_2_interrupt:
  goto interrupt_2;
 }

 continue__cazzuto_2_top: {
  q x0;
  a0 = qp->args[0];
  a1 = qp->args[1];
  qp = qp->next;
 continue__cazzuto_2_clear_reason:
  reasonp = reasons;
 continue__cazzuto_2_0:
 continue__cazzuto_2_1:
  if (!isint(a0)) goto continue__cazzuto_2_2;
  { printf("arg is %d\n",intval(a0));
		 }
  x0 = makeint(1L);
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin_xprint_1);
  allocp[2] = a0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 3;
  proceed();
 continue__cazzuto_2_2:
  if (!isref(a0)) goto continue__cazzuto_2_interrupt;
  deref_and_jump(a0,continue__cazzuto_2_1);
  *reasonp++ =  a0;
  goto continue__cazzuto_2_interrupt;
 continue__cazzuto_2_ext_interrupt:
  reasonp = 0l;
 continue__cazzuto_2_interrupt:
  toppred = &predicate_main_xcontinue__cazzuto_2;
  goto interrupt_2;
 }
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_main);
}
