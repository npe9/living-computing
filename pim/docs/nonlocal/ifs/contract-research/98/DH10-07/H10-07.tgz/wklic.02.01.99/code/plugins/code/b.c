#include <stdio.h>
#include <stdlib.h>
#include <string.h>

main ()
{
	char str[256];
	char a1[40] = "this is str1";
	char a2[40] = "this is str2";
	char a3[5];
	char *target, *url;
	int i;

	sprintf(str,"its' %s %c %s",a1,27,a2);
	sprintf(a3," %c ",27);

	for (i = 0; i < strlen(str); i++)
		printf("[%x]  %d\n",&(str[i]),str[i]);

	  target = index(str,' ');
	  printf("Target is %x\n",target);
	  target[0] = '\0';
	  target = &(target[1]);
	  url = strstr(target,a3);
	  printf("Url is %x\n",url);
	  url[0] = url[1] = url[2] = '\0';
	  url = &(url[3]);

	printf("target %s url %s\n",target,url);
}




