/* Compiled by KLIC compiler version 3.001 (Thu Jun  5 20:19:10 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_tohtml();
Const struct predicate predicate_tohtml_xtohtml_2 =
   { module_tohtml, 0, 2 };
Const struct predicate predicate_tohtml_xconvert__to__html_4 =
   { module_tohtml, 1, 4 };
Const struct predicate predicate_tohtml_xarglist_3 =
   { module_tohtml, 2, 3 };
Const struct predicate predicate_tohtml_xarglist_4 =
   { module_tohtml, 3, 4 };
Const struct predicate predicate_tohtml_xjoin__inline__tags_3 =
   { module_tohtml, 4, 3 };
Const struct predicate predicate_tohtml_xget__endtag_3 =
   { module_tohtml, 5, 3 };
Const struct predicate predicate_tohtml_xget__endtag_2F3_240_3 =
   { module_tohtml, 6, 3 };
extern q string_g_new();
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_generic_xgeneric_2;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_xfunctor_3;
extern Const struct predicate predicate_atom__table_xget__atom__string_2;
extern Const struct predicate predicate_util_xintegertostring_2;
extern Const struct predicate predicate_util_xisMember_3;
extern Const struct predicate predicate_html_xnoEndtag_1;

module module_tohtml(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  static Const unsigned char strconst_body_0[4] =
    " ";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_0 =
      declare_string_constant_8(strconst_body_0,1);
  static Const unsigned char strconst_body_1[4] =
    " = ";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_1 =
      declare_string_constant_8(strconst_body_1,3);
  static Const unsigned char strconst_body_2[4] =
    "\"";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_2 =
      declare_string_constant_8(strconst_body_2,1);
  static Const unsigned char strconst_body_3[4] =
    "<";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_3 =
      declare_string_constant_8(strconst_body_3,1);
  static Const unsigned char strconst_body_4[4] =
    "</";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_4 =
      declare_string_constant_8(strconst_body_4,2);
  static Const unsigned char strconst_body_5[4] =
    ">";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_5 =
      declare_string_constant_8(strconst_body_5,1);
  q a0, a1, a2, a3;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, tohtml_2_top);
    case_pred(1, convert__to__html_4_top);
    case_pred(2, arglist_3_top);
    case_pred(3, arglist_4_top);
    case_pred(4, join__inline__tags_3_top);
    case_pred(5, get__endtag_3_top);
    last_case_pred(6, get__endtag_2F3_240_3_top);
  }

 tohtml_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  qp = qp->next;
 tohtml_2_clear_reason:
  reasonp = reasons;
 tohtml_2_0:
 tohtml_2_1:
  if (isref(a0)) goto tohtml_2_3;
  gblt_pfunctor(a0,x0,tohtml_2_4);
  if (x0 != makesym(atom_text)) goto tohtml_2_4;
  gblt_arity(a0,x1,tohtml_2_4);
 tohtml_2_2:
  if (x1 != makeint(1L)) goto tohtml_2_4;
  allocp[0] = x2 = makeref(&allocp[0]);
  generic_arg[0] = x2;
  x3 = makeint(8L);
  generic_arg[1] = x3;
  new_generic(string_g_new, 2, x4, 1);
  unify(a1, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(1L);
  allocp[3] = a0;
  allocp[4] = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 tohtml_2_3:
  deref_and_jump(a0,tohtml_2_1);
  *reasonp++ =  a0;
  goto tohtml_2_4;
 tohtml_2_4:
  otherwise(tohtml_2_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_tohtml_xconvert__to__html_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a1;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_tohtml_xget__endtag_3);
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = x4 = makeref(&allocp[9]);
  allocp[10] = x2;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_tohtml_xjoin__inline__tags_3);
  allocp[13] = x5 = makeref(&allocp[13]);
  allocp[14] = x6 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = makesym(functor_join_2);
  allocp[17] = x4;
  allocp[18] = x5;
  x7 = makefunctor(&allocp[16]);
  allocp[19] = (q)(struct goalrec*)&allocp[11];
  allocp[20] = (q)(&predicate_generic_xgeneric_2);
  allocp[21] = x7;
  allocp[22] = makefunctor(&string_const_3);
  allocp[23] = (q)(struct goalrec*)&allocp[19];
  allocp[24] = (q)(&predicate_atom__table_xget__atom__string_2);
  allocp[25] = x3;
  allocp[26] = x4;
  allocp[27] = x0;
  allocp[28] = x6;
  x8 = makecons(&allocp[27]);
  allocp[29] = (q)(struct goalrec*)&allocp[23];
  allocp[30] = (q)(&predicate_tohtml_xarglist_3);
  allocp[31] = x9 = makeref(&allocp[31]);
  allocp[32] = a0;
  allocp[33] = x8;
  allocp[34] = (q)(struct goalrec*)&allocp[29];
  allocp[35] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[36] = a0;
  allocp[37] = x3;
  allocp[38] = x9;
  qp = (struct goalrec*)&allocp[34];
  allocp += 39;
  proceed();
 tohtml_2_ext_interrupt:
  reasonp = 0l;
 tohtml_2_interrupt:
  toppred = &predicate_tohtml_xtohtml_2;
  goto interrupt_2;
 }

 convert__to__html_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 convert__to__html_4_clear_reason:
  reasonp = reasons;
 convert__to__html_4_0:
 convert__to__html_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != NILATOM) goto convert__to__html_4_2;
  generic_arg[0] = a2;
  generic_arg[1] = a3;
  call_generic(a1, functor_join_2, 0);
  proceed();
 case VARREF:
  deref_and_jump(a0,convert__to__html_4_1);
  *reasonp++ =  a0;
  goto convert__to__html_4_2;
  };
  goto convert__to__html_4_2;
 convert__to__html_4_2:
  otherwise(convert__to__html_4_interrupt);
 convert__to__html_4_3:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 convert__to__html_4_4:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != NILATOM) goto convert__to__html_4_6;
  x1 = cdr_of(a0);
 convert__to__html_4_5:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto convert__to__html_4_6;
  generic_arg[0] = a2;
  generic_arg[1] = a3;
  call_generic(a1, functor_join_2, 0);
  proceed();
 case VARREF:
  deref_and_jump(x1,convert__to__html_4_5);
  *reasonp++ =  x1;
  goto convert__to__html_4_6;
  };
  goto convert__to__html_4_6;
 case VARREF:
  deref_and_jump(x0,convert__to__html_4_4);
  *reasonp++ =  x0;
  goto convert__to__html_4_6;
  };
  goto convert__to__html_4_6;
 case VARREF:
  deref_and_jump(a0,convert__to__html_4_3);
  *reasonp++ =  a0;
  goto convert__to__html_4_6;
  };
  goto convert__to__html_4_6;
 convert__to__html_4_6:
  otherwise(convert__to__html_4_interrupt);
 convert__to__html_4_7:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_tohtml_xconvert__to__html_4);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = makesym(functor_join_2);
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = x1;
  x2 = makefunctor(&allocp[6]);
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_generic_xgeneric_2);
  allocp[11] = x2;
  allocp[12] = a1;
  a0 = car_of(a0);
  a1 = x3;
  qp = (struct goalrec*)&allocp[9];
  allocp += 13;
  execute(tohtml_2_0);
  goto tohtml_2_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,convert__to__html_4_7);
  *reasonp++ =  a0;
  goto convert__to__html_4_interrupt;
  };
  goto convert__to__html_4_interrupt;
 convert__to__html_4_ext_interrupt:
  reasonp = 0l;
 convert__to__html_4_interrupt:
  goto interrupt_4;
 }

 arglist_3_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  qp = qp->next;
 arglist_3_clear_reason:
  reasonp = reasons;
 arglist_3_0:
 arglist_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 arglist_3_2:
  if (a0 != makeint(0L)) goto arglist_3_3;
  x0 = NILATOM;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,arglist_3_1);
  *reasonp++ =  a0;
  goto arglist_3_3;
  };
  goto arglist_3_3;
 arglist_3_3:
  otherwise(arglist_3_interrupt);
  allocp[0] = NILATOM;
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_tohtml_xarglist_4);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a1;
  allocp[6] = x0;
  allocp[7] = a2;
  allocp[8] = (q)(struct goalrec*)&allocp[2];
  allocp[9] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[10] = a0;
  allocp[11] = makeint(1L);
  allocp[12] = x2;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_functor__table_xarg_3);
  allocp[15] = a0;
  allocp[16] = a1;
  allocp[17] = x1;
  qp = (struct goalrec*)&allocp[13];
  allocp += 18;
  proceed();
 arglist_3_ext_interrupt:
  reasonp = 0l;
 arglist_3_interrupt:
  goto interrupt_3;
 }

 arglist_4_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 arglist_4_clear_reason:
  reasonp = reasons;
 arglist_4_0:
 arglist_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 arglist_4_2:
  if (a0 != makeint(0L)) goto arglist_4_3;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,arglist_4_1);
  *reasonp++ =  a0;
  goto arglist_4_3;
  };
  goto arglist_4_3;
 arglist_4_3:
  otherwise(arglist_4_interrupt);
  allocp[0] = a2;
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_tohtml_xarglist_4);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a1;
  allocp[6] = x0;
  allocp[7] = a3;
  allocp[8] = (q)(struct goalrec*)&allocp[2];
  allocp[9] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[10] = a0;
  allocp[11] = makeint(1L);
  allocp[12] = x2;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_functor__table_xarg_3);
  allocp[15] = a0;
  allocp[16] = a1;
  allocp[17] = x1;
  qp = (struct goalrec*)&allocp[13];
  allocp += 18;
  proceed();
 arglist_4_ext_interrupt:
  reasonp = 0l;
 arglist_4_interrupt:
  goto interrupt_4;
 }

 join__inline__tags_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13;
  a2 = qp->args[2];
  qp = qp->next;
 join__inline__tags_3_clear_reason:
  reasonp = reasons;
 join__inline__tags_3_0:
 join__inline__tags_3_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != NILATOM) goto join__inline__tags_3_2;
  x0 = makefunctor(&string_const_5);
  generic_arg[0] = x0;
  generic_arg[1] = a2;
  call_generic(a0, functor_join_2, 0);
  proceed();
 case VARREF:
  deref_and_jump(a1,join__inline__tags_3_1);
  *reasonp++ =  a1;
  goto join__inline__tags_3_2;
  };
  goto join__inline__tags_3_2;
 join__inline__tags_3_2:
  otherwise(join__inline__tags_3_interrupt);
 join__inline__tags_3_3:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 join__inline__tags_3_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
 join__inline__tags_3_5:
  if (!isgobj(x0)) goto join__inline__tags_3_7;
 join__inline__tags_3_6:
  gblt_is_string(x0,join__inline__tags_3_7);
  gblt_size_of_string(x0,x1,join__inline__tags_3_7);
  gblt_element_size_of_string(x0,x2,join__inline__tags_3_7);
  generic_arg[0] = x0;
  allocp[0] = x3 = makeref(&allocp[0]);
  generic_arg[1] = x3;
  x4 = makefunctor(&string_const_2);
  call_generic(x4, functor_join_2, 1);
  x5 = makefunctor(&string_const_2);
  generic_arg[0] = x5;
  allocp[0] = x6 = makeref(&allocp[0]);
  generic_arg[1] = x6;
  call_generic(x3, functor_join_2, 1);
  generic_arg[0] = x6;
  allocp[0] = x7 = makeref(&allocp[0]);
  generic_arg[1] = x7;
  call_generic(a0, functor_join_2, 1);
  a0 = x7;
  a1 = cdr_of(a1);
  execute(join__inline__tags_3_0);
  goto join__inline__tags_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,join__inline__tags_3_4);
  *reasonp++ =  x0;
  goto join__inline__tags_3_7;
  };
  goto join__inline__tags_3_7;
 case VARREF:
  deref_and_jump(a1,join__inline__tags_3_3);
  *reasonp++ =  a1;
  goto join__inline__tags_3_7;
  };
  goto join__inline__tags_3_7;
 join__inline__tags_3_7:
  otherwise(join__inline__tags_3_interrupt);
 join__inline__tags_3_8:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 join__inline__tags_3_9:
  if (!isint(x0)) goto join__inline__tags_3_10;
  gblt_integer(x0,join__inline__tags_3_11);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_tohtml_xjoin__inline__tags_3);
  allocp[2] = x1 = makeref(&allocp[2]);
  x2 = cdr_of(a1);
  allocp[3] = x2;
  allocp[4] = a2;
  allocp[5] = makesym(functor_join_2);
  allocp[6] = x4 = makeref(&allocp[6]);
  allocp[7] = x1;
  x3 = makefunctor(&allocp[5]);
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_generic_xgeneric_2);
  allocp[10] = x3;
  allocp[11] = a0;
  allocp[12] = (q)(struct goalrec*)&allocp[8];
  allocp[13] = (q)(&predicate_util_xintegertostring_2);
  allocp[14] = x0;
  allocp[15] = x4;
  qp = (struct goalrec*)&allocp[12];
  allocp += 16;
  proceed();
 join__inline__tags_3_10:
  if (!isref(x0)) goto join__inline__tags_3_11;
  deref_and_jump(x0,join__inline__tags_3_9);
  *reasonp++ =  x0;
  goto join__inline__tags_3_11;
 case VARREF:
  deref_and_jump(a1,join__inline__tags_3_8);
  *reasonp++ =  a1;
  goto join__inline__tags_3_11;
  };
  goto join__inline__tags_3_11;
 join__inline__tags_3_11:
  otherwise(join__inline__tags_3_interrupt);
 join__inline__tags_3_12:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 join__inline__tags_3_13:
  if (isref(x0)) goto join__inline__tags_3_14;
  gblt_pfunctor(x0,x1,join__inline__tags_3_15);
  gblt_arity(x0,x2,join__inline__tags_3_15);
  x3 = makeint(1L);
  gblt_greater_or_eq(x2,x3,join__inline__tags_3_15);
  x5 = cdr_of(a1);
  allocp[0] = x5;
  allocp[1] = x6 = makeref(&allocp[1]);
  x4 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_tohtml_xjoin__inline__tags_3);
  allocp[4] = x7 = makeref(&allocp[4]);
  allocp[5] = x4;
  allocp[6] = a2;
  allocp[7] = (q)(struct goalrec*)&allocp[2];
  allocp[8] = (q)(&predicate_functor__table_xarg_3);
  allocp[9] = makeint(1L);
  allocp[10] = x0;
  allocp[11] = x6;
  allocp[12] = makesym(functor_join_2);
  allocp[13] = x9 = makeref(&allocp[13]);
  allocp[14] = x7;
  x8 = makefunctor(&allocp[12]);
  allocp[15] = (q)(struct goalrec*)&allocp[7];
  allocp[16] = (q)(&predicate_generic_xgeneric_2);
  allocp[17] = x8;
  allocp[18] = x10 = makeref(&allocp[18]);
  allocp[19] = makesym(functor_join_2);
  allocp[20] = makefunctor(&string_const_0);
  allocp[21] = x10;
  x11 = makefunctor(&allocp[19]);
  allocp[22] = (q)(struct goalrec*)&allocp[15];
  allocp[23] = (q)(&predicate_generic_xgeneric_2);
  allocp[24] = x11;
  allocp[25] = a0;
  allocp[26] = makesym(functor_join_2);
  allocp[27] = makefunctor(&string_const_1);
  allocp[28] = x9;
  x12 = makefunctor(&allocp[26]);
  allocp[29] = (q)(struct goalrec*)&allocp[22];
  allocp[30] = (q)(&predicate_generic_xgeneric_2);
  allocp[31] = x12;
  allocp[32] = x13 = makeref(&allocp[32]);
  allocp[33] = (q)(struct goalrec*)&allocp[29];
  allocp[34] = (q)(&predicate_atom__table_xget__atom__string_2);
  allocp[35] = x1;
  allocp[36] = x13;
  qp = (struct goalrec*)&allocp[33];
  allocp += 37;
  proceed();
 join__inline__tags_3_14:
  deref_and_jump(x0,join__inline__tags_3_13);
  *reasonp++ =  x0;
  goto join__inline__tags_3_15;
 case VARREF:
  deref_and_jump(a1,join__inline__tags_3_12);
  *reasonp++ =  a1;
  goto join__inline__tags_3_15;
  };
  goto join__inline__tags_3_15;
 join__inline__tags_3_15:
  otherwise(join__inline__tags_3_interrupt);
 join__inline__tags_3_16:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 join__inline__tags_3_17:
  switch (ptagof(x0)) {
 case ATOMIC:
 join__inline__tags_3_18:
  gblt_atomic(x0,join__inline__tags_3_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_tohtml_xjoin__inline__tags_3);
  allocp[2] = x1 = makeref(&allocp[2]);
  x2 = cdr_of(a1);
  allocp[3] = x2;
  allocp[4] = a2;
  allocp[5] = makesym(functor_join_2);
  allocp[6] = x4 = makeref(&allocp[6]);
  allocp[7] = x1;
  x3 = makefunctor(&allocp[5]);
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_generic_xgeneric_2);
  allocp[10] = x3;
  allocp[11] = a0;
  allocp[12] = (q)(struct goalrec*)&allocp[8];
  allocp[13] = (q)(&predicate_atom__table_xget__atom__string_2);
  allocp[14] = x0;
  allocp[15] = x4;
  qp = (struct goalrec*)&allocp[12];
  allocp += 16;
  proceed();
 case VARREF:
  deref_and_jump(x0,join__inline__tags_3_17);
  *reasonp++ =  x0;
  goto join__inline__tags_3_interrupt;
  };
  goto join__inline__tags_3_interrupt;
 case VARREF:
  deref_and_jump(a1,join__inline__tags_3_16);
  *reasonp++ =  a1;
  goto join__inline__tags_3_interrupt;
  };
  goto join__inline__tags_3_interrupt;
 join__inline__tags_3_ext_interrupt:
  reasonp = 0l;
 join__inline__tags_3_interrupt:
  goto interrupt_3;
 }

 get__endtag_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 get__endtag_3_clear_reason:
  reasonp = reasons;
 get__endtag_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_tohtml_xget__endtag_2F3_240_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a2;
  allocp[4] = a1;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_util_xisMember_3);
  allocp[7] = a0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x0;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_html_xnoEndtag_1);
  allocp[12] = x1;
  qp = (struct goalrec*)&allocp[10];
  allocp += 13;
  proceed();
 get__endtag_3_ext_interrupt:
  reasonp = 0l;
 get__endtag_3_interrupt:
  goto interrupt_3;
 }

 get__endtag_2F3_240_3_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  qp = qp->next;
 get__endtag_2F3_240_3_clear_reason:
  reasonp = reasons;
 get__endtag_2F3_240_3_0:
 get__endtag_2F3_240_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto get__endtag_2F3_240_3_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_true)):
  x0 = makefunctor(&string_const_0);
  unify_value(a1, x0);
  proceed();
 case symval(makesym(atom_false)):
  generic_arg[0] = a2;
  allocp[0] = x0 = makeref(&allocp[0]);
  generic_arg[1] = x0;
  x1 = makefunctor(&string_const_4);
  call_generic(x1, functor_join_2, 1);
  x2 = makefunctor(&string_const_5);
  generic_arg[0] = x2;
  allocp[0] = x3 = makeref(&allocp[0]);
  generic_arg[1] = x3;
  call_generic(x0, functor_join_2, 1);
  unify(a1, x3);
  proceed();
  };
  goto get__endtag_2F3_240_3_interrupt;
 case VARREF:
  deref_and_jump(a0,get__endtag_2F3_240_3_1);
  *reasonp++ =  a0;
  goto get__endtag_2F3_240_3_interrupt;
  };
  goto get__endtag_2F3_240_3_interrupt;
 get__endtag_2F3_240_3_ext_interrupt:
  reasonp = 0l;
 get__endtag_2F3_240_3_interrupt:
  goto interrupt_3;
 }
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_tohtml);
}
