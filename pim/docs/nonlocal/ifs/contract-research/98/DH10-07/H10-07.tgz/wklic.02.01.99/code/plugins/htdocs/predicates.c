#include <klic/basic.h>
#include <klic/predinfo.h>

extern Const struct predicate predicate_builtin_xstart__measure_0;
static Const struct predinfo predinfo_builtin_xstart__measure_0 = {
  (unsigned char *)"start_measure",
  &predicate_builtin_xstart__measure_0
};

extern Const struct predicate predicate_builtin_xreport__measure_1;
static Const struct predinfo predinfo_builtin_xreport__measure_1 = {
  (unsigned char *)"report_measure",
  &predicate_builtin_xreport__measure_1
};

extern Const struct predicate predicate_builtin_xreadint_1;
static Const struct predinfo predinfo_builtin_xreadint_1 = {
  (unsigned char *)"readint",
  &predicate_builtin_xreadint_1
};

extern Const struct predicate predicate_builtin_xputc_2;
static Const struct predinfo predinfo_builtin_xputc_2 = {
  (unsigned char *)"putc",
  &predicate_builtin_xputc_2
};

extern Const struct predicate predicate_builtin_xprint_2;
static Const struct predinfo predinfo_builtin_xprint_2 = {
  (unsigned char *)"print",
  &predicate_builtin_xprint_2
};

extern Const struct predicate predicate_builtin_xprint_1;
static Const struct predinfo predinfo_builtin_xprint_1 = {
  (unsigned char *)"print",
  &predicate_builtin_xprint_1
};

extern Const struct predicate predicate_builtin_xidle_0;
static Const struct predinfo predinfo_builtin_xidle_0 = {
  (unsigned char *)"idle",
  &predicate_builtin_xidle_0
};

extern Const struct predicate predicate_builtin_xcurrent__node_2;
static Const struct predinfo predinfo_builtin_xcurrent__node_2 = {
  (unsigned char *)"current_node",
  &predicate_builtin_xcurrent__node_2
};

static Const struct predinfo * Const preds_in_builtin[] = {
  &predinfo_builtin_xstart__measure_0,
  &predinfo_builtin_xreport__measure_1,
  &predinfo_builtin_xreadint_1,
  &predinfo_builtin_xputc_2,
  &predinfo_builtin_xprint_2,
  &predinfo_builtin_xprint_1,
  &predinfo_builtin_xidle_0,
  &predinfo_builtin_xcurrent__node_2,
  0
};
extern Const struct predicate predicate_unix_xwrite__open_2;
static Const struct predinfo predinfo_unix_xwrite__open_2 = {
  (unsigned char *)"write_open",
  &predicate_unix_xwrite__open_2
};

extern Const struct predicate predicate_unix_xupdate__open_2;
static Const struct predinfo predinfo_unix_xupdate__open_2 = {
  (unsigned char *)"update_open",
  &predicate_unix_xupdate__open_2
};

extern Const struct predicate predicate_unix_xunlink_2;
static Const struct predinfo predinfo_unix_xunlink_2 = {
  (unsigned char *)"unlink",
  &predicate_unix_xunlink_2
};

extern Const struct predicate predicate_unix_xunix_1;
static Const struct predinfo predinfo_unix_xunix_1 = {
  (unsigned char *)"unix",
  &predicate_unix_xunix_1
};

extern Const struct predicate predicate_unix_xumask_2;
static Const struct predinfo predinfo_unix_xumask_2 = {
  (unsigned char *)"umask",
  &predicate_unix_xumask_2
};

extern Const struct predicate predicate_unix_xumask_1;
static Const struct predinfo predinfo_unix_xumask_1 = {
  (unsigned char *)"umask",
  &predicate_unix_xumask_1
};

extern Const struct predicate predicate_unix_xtimes_4;
static Const struct predinfo predinfo_unix_xtimes_4 = {
  (unsigned char *)"times",
  &predicate_unix_xtimes_4
};

extern Const struct predicate predicate_unix_xsystem_2;
static Const struct predinfo predinfo_unix_xsystem_2 = {
  (unsigned char *)"system",
  &predicate_unix_xsystem_2
};

extern Const struct predicate predicate_unix_xstdout_1;
static Const struct predinfo predinfo_unix_xstdout_1 = {
  (unsigned char *)"stdout",
  &predicate_unix_xstdout_1
};

extern Const struct predicate predicate_unix_xstdio_1;
static Const struct predinfo predinfo_unix_xstdio_1 = {
  (unsigned char *)"stdio",
  &predicate_unix_xstdio_1
};

extern Const struct predicate predicate_unix_xstdin_1;
static Const struct predinfo predinfo_unix_xstdin_1 = {
  (unsigned char *)"stdin",
  &predicate_unix_xstdin_1
};

extern Const struct predicate predicate_unix_xstderr_1;
static Const struct predinfo predinfo_unix_xstderr_1 = {
  (unsigned char *)"stderr",
  &predicate_unix_xstderr_1
};

extern Const struct predicate predicate_unix_xsignal__stream_3;
static Const struct predinfo predinfo_unix_xsignal__stream_3 = {
  (unsigned char *)"signal_stream",
  &predicate_unix_xsignal__stream_3
};

extern Const struct predicate predicate_unix_xsignal__stream_2;
static Const struct predinfo predinfo_unix_xsignal__stream_2 = {
  (unsigned char *)"signal_stream",
  &predicate_unix_xsignal__stream_2
};

extern Const struct predicate predicate_unix_xread__open_2;
static Const struct predinfo predinfo_unix_xread__open_2 = {
  (unsigned char *)"read_open",
  &predicate_unix_xread__open_2
};

extern Const struct predicate predicate_unix_xputenv_2;
static Const struct predinfo predinfo_unix_xputenv_2 = {
  (unsigned char *)"putenv",
  &predicate_unix_xputenv_2
};

extern Const struct predicate predicate_unix_xpipe_1;
static Const struct predinfo predinfo_unix_xpipe_1 = {
  (unsigned char *)"pipe",
  &predicate_unix_xpipe_1
};

extern Const struct predicate predicate_unix_xnet__convert_3;
static Const struct predinfo predinfo_unix_xnet__convert_3 = {
  (unsigned char *)"net_convert",
  &predicate_unix_xnet__convert_3
};

extern Const struct predicate predicate_unix_xmktemp_2;
static Const struct predinfo predinfo_unix_xmktemp_2 = {
  (unsigned char *)"mktemp",
  &predicate_unix_xmktemp_2
};

extern Const struct predicate predicate_unix_xmake__argv__list_3;
static Const struct predinfo predinfo_unix_xmake__argv__list_3 = {
  (unsigned char *)"make_argv_list",
  &predicate_unix_xmake__argv__list_3
};

extern Const struct predicate predicate_unix_xkill_3;
static Const struct predinfo predinfo_unix_xkill_3 = {
  (unsigned char *)"kill",
  &predicate_unix_xkill_3
};

extern Const struct predicate predicate_unix_xgetenv_2;
static Const struct predinfo predinfo_unix_xgetenv_2 = {
  (unsigned char *)"getenv",
  &predicate_unix_xgetenv_2
};

extern Const struct predicate predicate_unix_xfork__with__pipes_2F1_240_6;
static Const struct predinfo predinfo_unix_xfork__with__pipes_2F1_240_6 = {
  (unsigned char *)"fork_with_pipes/1$0",
  &predicate_unix_xfork__with__pipes_2F1_240_6
};

extern Const struct predicate predicate_unix_xfork__with__pipes_1;
static Const struct predinfo predinfo_unix_xfork__with__pipes_1 = {
  (unsigned char *)"fork_with_pipes",
  &predicate_unix_xfork__with__pipes_1
};

extern Const struct predicate predicate_unix_xfork_1;
static Const struct predinfo predinfo_unix_xfork_1 = {
  (unsigned char *)"fork",
  &predicate_unix_xfork_1
};

extern Const struct predicate predicate_unix_xexit_1;
static Const struct predinfo predinfo_unix_xexit_1 = {
  (unsigned char *)"exit",
  &predicate_unix_xexit_1
};

extern Const struct predicate predicate_unix_xdummy_0;
static Const struct predinfo predinfo_unix_xdummy_0 = {
  (unsigned char *)"dummy",
  &predicate_unix_xdummy_0
};

extern Const struct predicate predicate_unix_xcont_3;
static Const struct predinfo predinfo_unix_xcont_3 = {
  (unsigned char *)"cont",
  &predicate_unix_xcont_3
};

extern Const struct predicate predicate_unix_xconnect__sub_4;
static Const struct predinfo predinfo_unix_xconnect__sub_4 = {
  (unsigned char *)"connect_sub",
  &predicate_unix_xconnect__sub_4
};

extern Const struct predicate predicate_unix_xconnect_4;
static Const struct predinfo predinfo_unix_xconnect_4 = {
  (unsigned char *)"connect",
  &predicate_unix_xconnect_4
};

extern Const struct predicate predicate_unix_xconnect_2;
static Const struct predinfo predinfo_unix_xconnect_2 = {
  (unsigned char *)"connect",
  &predicate_unix_xconnect_2
};

extern Const struct predicate predicate_unix_xchmod_3;
static Const struct predinfo predinfo_unix_xchmod_3 = {
  (unsigned char *)"chmod",
  &predicate_unix_xchmod_3
};

extern Const struct predicate predicate_unix_xcd_2;
static Const struct predinfo predinfo_unix_xcd_2 = {
  (unsigned char *)"cd",
  &predicate_unix_xcd_2
};

extern Const struct predicate predicate_unix_xbound__sock_4;
static Const struct predinfo predinfo_unix_xbound__sock_4 = {
  (unsigned char *)"bound_sock",
  &predicate_unix_xbound__sock_4
};

extern Const struct predicate predicate_unix_xbind_4;
static Const struct predinfo predinfo_unix_xbind_4 = {
  (unsigned char *)"bind",
  &predicate_unix_xbind_4
};

extern Const struct predicate predicate_unix_xbind_2;
static Const struct predinfo predinfo_unix_xbind_2 = {
  (unsigned char *)"bind",
  &predicate_unix_xbind_2
};

extern Const struct predicate predicate_unix_xasync__io_5;
static Const struct predinfo predinfo_unix_xasync__io_5 = {
  (unsigned char *)"async_io",
  &predicate_unix_xasync__io_5
};

extern Const struct predicate predicate_unix_xargv_1;
static Const struct predinfo predinfo_unix_xargv_1 = {
  (unsigned char *)"argv",
  &predicate_unix_xargv_1
};

extern Const struct predicate predicate_unix_xargc_1;
static Const struct predinfo predinfo_unix_xargc_1 = {
  (unsigned char *)"argc",
  &predicate_unix_xargc_1
};

extern Const struct predicate predicate_unix_xappend__open_2;
static Const struct predinfo predinfo_unix_xappend__open_2 = {
  (unsigned char *)"append_open",
  &predicate_unix_xappend__open_2
};

extern Const struct predicate predicate_unix_xaccess_3;
static Const struct predinfo predinfo_unix_xaccess_3 = {
  (unsigned char *)"access",
  &predicate_unix_xaccess_3
};

static Const struct predinfo * Const preds_in_unix[] = {
  &predinfo_unix_xwrite__open_2,
  &predinfo_unix_xupdate__open_2,
  &predinfo_unix_xunlink_2,
  &predinfo_unix_xunix_1,
  &predinfo_unix_xumask_2,
  &predinfo_unix_xumask_1,
  &predinfo_unix_xtimes_4,
  &predinfo_unix_xsystem_2,
  &predinfo_unix_xstdout_1,
  &predinfo_unix_xstdio_1,
  &predinfo_unix_xstdin_1,
  &predinfo_unix_xstderr_1,
  &predinfo_unix_xsignal__stream_3,
  &predinfo_unix_xsignal__stream_2,
  &predinfo_unix_xread__open_2,
  &predinfo_unix_xputenv_2,
  &predinfo_unix_xpipe_1,
  &predinfo_unix_xnet__convert_3,
  &predinfo_unix_xmktemp_2,
  &predinfo_unix_xmake__argv__list_3,
  &predinfo_unix_xkill_3,
  &predinfo_unix_xgetenv_2,
  &predinfo_unix_xfork__with__pipes_2F1_240_6,
  &predinfo_unix_xfork__with__pipes_1,
  &predinfo_unix_xfork_1,
  &predinfo_unix_xexit_1,
  &predinfo_unix_xdummy_0,
  &predinfo_unix_xcont_3,
  &predinfo_unix_xconnect__sub_4,
  &predinfo_unix_xconnect_4,
  &predinfo_unix_xconnect_2,
  &predinfo_unix_xchmod_3,
  &predinfo_unix_xcd_2,
  &predinfo_unix_xbound__sock_4,
  &predinfo_unix_xbind_4,
  &predinfo_unix_xbind_2,
  &predinfo_unix_xasync__io_5,
  &predinfo_unix_xargv_1,
  &predinfo_unix_xargc_1,
  &predinfo_unix_xappend__open_2,
  &predinfo_unix_xaccess_3,
  0
};
extern Const struct predicate predicate_main_xterminate_2;
static Const struct predinfo predinfo_main_xterminate_2 = {
  (unsigned char *)"terminate",
  &predicate_main_xterminate_2
};

extern Const struct predicate predicate_main_xsend__write__stream_4;
static Const struct predinfo predinfo_main_xsend__write__stream_4 = {
  (unsigned char *)"send_write_stream",
  &predicate_main_xsend__write__stream_4
};

extern Const struct predicate predicate_main_xsend__pi__initialize_3;
static Const struct predinfo predinfo_main_xsend__pi__initialize_3 = {
  (unsigned char *)"send_pi_initialize",
  &predicate_main_xsend__pi__initialize_3
};

extern Const struct predicate predicate_main_xsend__new__stream__request_3;
static Const struct predinfo predinfo_main_xsend__new__stream__request_3 = {
  (unsigned char *)"send_new_stream_request",
  &predicate_main_xsend__new__stream__request_3
};

extern Const struct predicate predicate_main_xsend__get__url__1_6;
static Const struct predinfo predinfo_main_xsend__get__url__1_6 = {
  (unsigned char *)"send_get_url_1",
  &predicate_main_xsend__get__url__1_6
};

extern Const struct predicate predicate_main_xsend__get__url_6;
static Const struct predinfo predinfo_main_xsend__get__url_6 = {
  (unsigned char *)"send_get_url",
  &predicate_main_xsend__get__url_6
};

extern Const struct predicate predicate_main_xsend__destroy__stream_3;
static Const struct predinfo predinfo_main_xsend__destroy__stream_3 = {
  (unsigned char *)"send_destroy_stream",
  &predicate_main_xsend__destroy__stream_3
};

extern Const struct predicate predicate_main_xpi__write__stream_2;
static Const struct predinfo predinfo_main_xpi__write__stream_2 = {
  (unsigned char *)"pi_write_stream",
  &predicate_main_xpi__write__stream_2
};

extern Const struct predicate predicate_main_xpi__new__stream_1;
static Const struct predinfo predinfo_main_xpi__new__stream_1 = {
  (unsigned char *)"pi_new_stream",
  &predicate_main_xpi__new__stream_1
};

extern Const struct predicate predicate_main_xpi__initialize_1;
static Const struct predinfo predinfo_main_xpi__initialize_1 = {
  (unsigned char *)"pi_initialize",
  &predicate_main_xpi__initialize_1
};

extern Const struct predicate predicate_main_xpi__get__url_4;
static Const struct predinfo predinfo_main_xpi__get__url_4 = {
  (unsigned char *)"pi_get_url",
  &predicate_main_xpi__get__url_4
};

extern Const struct predicate predicate_main_xpi__destroy__stream_1;
static Const struct predinfo predinfo_main_xpi__destroy__stream_1 = {
  (unsigned char *)"pi_destroy_stream",
  &predicate_main_xpi__destroy__stream_1
};

extern Const struct predicate predicate_main_xmain_0;
static Const struct predinfo predinfo_main_xmain_0 = {
  (unsigned char *)"main",
  &predicate_main_xmain_0
};

extern Const struct predicate predicate_main_xgo__final_1;
static Const struct predinfo predinfo_main_xgo__final_1 = {
  (unsigned char *)"go_final",
  &predicate_main_xgo__final_1
};

extern Const struct predicate predicate_main_xgetting__url__txt_5;
static Const struct predinfo predinfo_main_xgetting__url__txt_5 = {
  (unsigned char *)"getting_url_txt",
  &predicate_main_xgetting__url__txt_5
};

extern Const struct predicate predicate_main_xcontinue__send__url_4;
static Const struct predinfo predinfo_main_xcontinue__send__url_4 = {
  (unsigned char *)"continue_send_url",
  &predicate_main_xcontinue__send__url_4
};

extern Const struct predicate predicate_main_xcontinue_1;
static Const struct predinfo predinfo_main_xcontinue_1 = {
  (unsigned char *)"continue",
  &predicate_main_xcontinue_1
};

extern Const struct predicate predicate_main_xcombine__answers_5;
static Const struct predinfo predinfo_main_xcombine__answers_5 = {
  (unsigned char *)"combine_answers",
  &predicate_main_xcombine__answers_5
};

extern Const struct predicate predicate_main_xcheck__target_2;
static Const struct predinfo predinfo_main_xcheck__target_2 = {
  (unsigned char *)"check_target",
  &predicate_main_xcheck__target_2
};

static Const struct predinfo * Const preds_in_main[] = {
  &predinfo_main_xterminate_2,
  &predinfo_main_xsend__write__stream_4,
  &predinfo_main_xsend__pi__initialize_3,
  &predinfo_main_xsend__new__stream__request_3,
  &predinfo_main_xsend__get__url__1_6,
  &predinfo_main_xsend__get__url_6,
  &predinfo_main_xsend__destroy__stream_3,
  &predinfo_main_xpi__write__stream_2,
  &predinfo_main_xpi__new__stream_1,
  &predinfo_main_xpi__initialize_1,
  &predinfo_main_xpi__get__url_4,
  &predinfo_main_xpi__destroy__stream_1,
  &predinfo_main_xmain_0,
  &predinfo_main_xgo__final_1,
  &predinfo_main_xgetting__url__txt_5,
  &predinfo_main_xcontinue__send__url_4,
  &predinfo_main_xcontinue_1,
  &predinfo_main_xcombine__answers_5,
  &predinfo_main_xcheck__target_2,
  0
};
extern Const struct predicate predicate_generic_xnew_3;
static Const struct predinfo predinfo_generic_xnew_3 = {
  (unsigned char *)"new",
  &predicate_generic_xnew_3
};

extern Const struct predicate predicate_generic_xgeneric_2;
static Const struct predinfo predinfo_generic_xgeneric_2 = {
  (unsigned char *)"generic",
  &predicate_generic_xgeneric_2
};

static Const struct predinfo * Const preds_in_generic[] = {
  &predinfo_generic_xnew_3,
  &predinfo_generic_xgeneric_2,
  0
};
extern Const struct predicate predicate_unify__term__dcode_xunify__pf_2;
static Const struct predinfo predinfo_unify__term__dcode_xunify__pf_2 = {
  (unsigned char *)"unify_pf",
  &predicate_unify__term__dcode_xunify__pf_2
};

extern Const struct predicate predicate_unify__term__dcode_xunify__goal_2;
static Const struct predinfo predinfo_unify__term__dcode_xunify__goal_2 = {
  (unsigned char *)"unify_goal",
  &predicate_unify__term__dcode_xunify__goal_2
};

extern Const struct predicate predicate_unify__term__dcode_xunify__args_3;
static Const struct predinfo predinfo_unify__term__dcode_xunify__args_3 = {
  (unsigned char *)"unify_args",
  &predicate_unify__term__dcode_xunify__args_3
};

extern Const struct predicate predicate_unify__term__dcode_xunify_2;
static Const struct predinfo predinfo_unify__term__dcode_xunify_2 = {
  (unsigned char *)"unify",
  &predicate_unify__term__dcode_xunify_2
};

static Const struct predinfo * Const preds_in_unify__term__dcode[] = {
  &predinfo_unify__term__dcode_xunify__pf_2,
  &predinfo_unify__term__dcode_xunify__goal_2,
  &predinfo_unify__term__dcode_xunify__args_3,
  &predinfo_unify__term__dcode_xunify_2,
  0
};
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
static Const struct predinfo predinfo_integer__arithmetics_xsubtract_3 = {
  (unsigned char *)"subtract",
  &predicate_integer__arithmetics_xsubtract_3
};

extern Const struct predicate predicate_integer__arithmetics_xshift__right_3;
static Const struct predinfo predinfo_integer__arithmetics_xshift__right_3 = {
  (unsigned char *)"shift_right",
  &predicate_integer__arithmetics_xshift__right_3
};

extern Const struct predicate predicate_integer__arithmetics_xshift__left_3;
static Const struct predinfo predinfo_integer__arithmetics_xshift__left_3 = {
  (unsigned char *)"shift_left",
  &predicate_integer__arithmetics_xshift__left_3
};

extern Const struct predicate predicate_integer__arithmetics_xplus_2;
static Const struct predinfo predinfo_integer__arithmetics_xplus_2 = {
  (unsigned char *)"plus",
  &predicate_integer__arithmetics_xplus_2
};

extern Const struct predicate predicate_integer__arithmetics_xor_3;
static Const struct predinfo predinfo_integer__arithmetics_xor_3 = {
  (unsigned char *)"or",
  &predicate_integer__arithmetics_xor_3
};

extern Const struct predicate predicate_integer__arithmetics_xmultiply_3;
static Const struct predinfo predinfo_integer__arithmetics_xmultiply_3 = {
  (unsigned char *)"multiply",
  &predicate_integer__arithmetics_xmultiply_3
};

extern Const struct predicate predicate_integer__arithmetics_xmodulo_3;
static Const struct predinfo predinfo_integer__arithmetics_xmodulo_3 = {
  (unsigned char *)"modulo",
  &predicate_integer__arithmetics_xmodulo_3
};

extern Const struct predicate predicate_integer__arithmetics_xminus_2;
static Const struct predinfo predinfo_integer__arithmetics_xminus_2 = {
  (unsigned char *)"minus",
  &predicate_integer__arithmetics_xminus_2
};

extern Const struct predicate predicate_integer__arithmetics_xexclusive__or_3;
static Const struct predinfo predinfo_integer__arithmetics_xexclusive__or_3 = {
  (unsigned char *)"exclusive_or",
  &predicate_integer__arithmetics_xexclusive__or_3
};

extern Const struct predicate predicate_integer__arithmetics_xdivide_3;
static Const struct predinfo predinfo_integer__arithmetics_xdivide_3 = {
  (unsigned char *)"divide",
  &predicate_integer__arithmetics_xdivide_3
};

extern Const struct predicate predicate_integer__arithmetics_xcomplement_2;
static Const struct predinfo predinfo_integer__arithmetics_xcomplement_2 = {
  (unsigned char *)"complement",
  &predicate_integer__arithmetics_xcomplement_2
};

extern Const struct predicate predicate_integer__arithmetics_xand_3;
static Const struct predinfo predinfo_integer__arithmetics_xand_3 = {
  (unsigned char *)"and",
  &predicate_integer__arithmetics_xand_3
};

extern Const struct predicate predicate_integer__arithmetics_xadd_3;
static Const struct predinfo predinfo_integer__arithmetics_xadd_3 = {
  (unsigned char *)"add",
  &predicate_integer__arithmetics_xadd_3
};

static Const struct predinfo * Const preds_in_integer__arithmetics[] = {
  &predinfo_integer__arithmetics_xsubtract_3,
  &predinfo_integer__arithmetics_xshift__right_3,
  &predinfo_integer__arithmetics_xshift__left_3,
  &predinfo_integer__arithmetics_xplus_2,
  &predinfo_integer__arithmetics_xor_3,
  &predinfo_integer__arithmetics_xmultiply_3,
  &predinfo_integer__arithmetics_xmodulo_3,
  &predinfo_integer__arithmetics_xminus_2,
  &predinfo_integer__arithmetics_xexclusive__or_3,
  &predinfo_integer__arithmetics_xdivide_3,
  &predinfo_integer__arithmetics_xcomplement_2,
  &predinfo_integer__arithmetics_xand_3,
  &predinfo_integer__arithmetics_xadd_3,
  0
};
Const struct modinfo defined_modules[] = {
  (unsigned char *)"builtin",
  preds_in_builtin,
  (unsigned char *)"unix",
  preds_in_unix,
  (unsigned char *)"main",
  preds_in_main,
  (unsigned char *)"generic",
  preds_in_generic,
  (unsigned char *)"unify_term_dcode",
  preds_in_unify__term__dcode,
  (unsigned char *)"integer_arithmetics",
  preds_in_integer__arithmetics,
  0, 0
};
