/* Compiled by KLIC compiler version 3.001 (Thu Jun  5 20:19:10 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_main();
Const struct predicate predicate_main_xmain_0 =
   { module_main, 0, 0 };
Const struct predicate predicate_main_xget__input_2 =
   { module_main, 1, 2 };
Const struct predicate predicate_main_xprocess__string_2 =
   { module_main, 2, 2 };
Const struct predicate predicate_main_xconnect__to__socket_4 =
   { module_main, 3, 4 };
Const struct predicate predicate_main_xcomm__msg_5 =
   { module_main, 4, 5 };
Const struct predicate predicate_main_xwrite__msg_3 =
   { module_main, 5, 3 };
Const struct predicate predicate_main_xread__response_4 =
   { module_main, 6, 4 };
Const struct predicate predicate_main_xread__response_2F4_240_5 =
   { module_main, 7, 5 };
Const struct predicate predicate_main_xcheck__input_4 =
   { module_main, 8, 4 };
Const struct predicate predicate_main_xwrite__to__stdout_2 =
   { module_main, 9, 2 };
Const struct predicate predicate_main_xprint__result_1 =
   { module_main, 10, 1 };
Const struct predicate predicate_main_xfind__socket_4 =
   { module_main, 11, 4 };
Const struct predicate predicate_main_xfind__socket_2F4_240_4 =
   { module_main, 12, 4 };
Const struct predicate predicate_main_xfind__pair_4 =
   { module_main, 13, 4 };
Const struct predicate predicate_main_xfind__pair_5 =
   { module_main, 14, 5 };
Const struct predicate predicate_main_xfind__pair_2F5_240_7 =
   { module_main, 15, 7 };
Const struct predicate predicate_main_xfind__pair_2F5_240_2F7_240_8 =
   { module_main, 16, 8 };
Const struct predicate predicate_main_xjoin__list_2 =
   { module_main, 17, 2 };
Const struct predicate predicate_main_xjoin__list_3 =
   { module_main, 18, 3 };
extern q string_g_new();
extern Const struct predicate predicate_unix_xunix_1;
extern Const struct predicate predicate_builtin_xprint_1;
extern Const struct predicate predicate_functor__table_x_3D_2E_2E_2;
extern Const struct predicate predicate_cgi_xnamevaluepairs_2;
extern Const struct predicate predicate_util_xlosToLst_2;
extern Const struct predicate predicate_util_xatoi_2;
extern Const struct predicate predicate_util_xappend_3;
extern Const struct predicate predicate_atom__table_xmake__atom_2;

module module_main(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_0 =
      declare_string_constant_8(0,0);
  static Const unsigned char strconst_body_1[4] =
    "&";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_1 =
      declare_string_constant_8(strconst_body_1,1);
  static Const unsigned char strconst_body_2[28] =
    "Content-type: text/html\n\015\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_2 =
      declare_string_constant_8(strconst_body_2,26);
  static Const unsigned char strconst_body_3[8] =
    "sioux";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_3 =
      declare_string_constant_8(strconst_body_3,5);
  static Const unsigned char strconst_body_4[8] =
    "sioux";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_4 =
      declare_string_constant_8(strconst_body_4,5);
  static Const q funct_const_5[] = {
    makesym(functor_inet_2),
    makefunctor(&string_const_4),
    makeint(50000),
  };
  static Const unsigned char strconst_body_6[8] =
    "sioux";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_6 =
      declare_string_constant_8(strconst_body_6,5);
  static Const q funct_const_7[] = {
    makesym(functor_inet_2),
    makefunctor(&string_const_6),
    makeint(50001),
  };
  q a0, a1, a2, a3, a4, a5, a6, a7;

  q *reasonp;
 module_top:
  switch_on_pred() {
    case_pred(0, main_0_top);
    case_pred(1, get__input_2_top);
    case_pred(2, process__string_2_top);
    case_pred(3, connect__to__socket_4_top);
    case_pred(4, comm__msg_5_top);
    case_pred(5, write__msg_3_top);
    case_pred(6, read__response_4_top);
    case_pred(7, read__response_2F4_240_5_top);
    case_pred(8, check__input_4_top);
    case_pred(9, write__to__stdout_2_top);
    case_pred(10, print__result_1_top);
    case_pred(11, find__socket_4_top);
    case_pred(12, find__socket_2F4_240_4_top);
    case_pred(13, find__pair_4_top);
    case_pred(14, find__pair_5_top);
    case_pred(15, find__pair_2F5_240_7_top);
    case_pred(16, find__pair_2F5_240_2F7_240_8_top);
    case_pred(17, join__list_2_top);
    last_case_pred(18, join__list_3_top);
  }

 main_0_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  qp = qp->next;
 main_0_clear_reason:
  reasonp = reasons;
 main_0_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_main_xprocess__string_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = makesym(functor_stdout_1);
  allocp[5] = x0;
  x2 = makefunctor(&allocp[4]);
  allocp[6] = NILATOM;
  allocp[7] = x2;
  x3 = makecons(&allocp[6]);
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_unix_xunix_1);
  allocp[10] = x3;
  allocp[11] = (q)(struct goalrec*)&allocp[8];
  allocp[12] = (q)(&predicate_main_xget__input_2);
  allocp[13] = x4 = makeref(&allocp[13]);
  allocp[14] = x1;
  allocp[15] = makesym(functor_stdin_1);
  allocp[16] = x4;
  x5 = makefunctor(&allocp[15]);
  allocp[17] = NILATOM;
  allocp[18] = x5;
  x6 = makecons(&allocp[17]);
  allocp[19] = (q)(struct goalrec*)&allocp[11];
  allocp[20] = (q)(&predicate_unix_xunix_1);
  allocp[21] = x6;
  qp = (struct goalrec*)&allocp[19];
  allocp += 22;
  proceed();
 main_0_ext_interrupt:
  reasonp = 0l;
 main_0_interrupt:
  goto interrupt_0;
 }

 get__input_2_top: {
  q x0, x1, x2;
  a0 = qp->args[0];
  a1 = qp->args[1];
  qp = qp->next;
 get__input_2_clear_reason:
  reasonp = reasons;
 get__input_2_0:
 get__input_2_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_normal_1)) goto get__input_2_interrupt;
  allocp[0] = makesym(functor_fread_2);
  allocp[1] = makeint(4096L);
  allocp[2] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = NILATOM;
  allocp[4] = x0;
  x1 = makecons(&allocp[3]);
  x2 = arg(a0, 0);
  allocp += 5;
  unify_value(x2, x1);
  proceed();
 case VARREF:
  deref_and_jump(a0,get__input_2_1);
  *reasonp++ =  a0;
  goto get__input_2_interrupt;
  };
  goto get__input_2_interrupt;
 get__input_2_ext_interrupt:
  reasonp = 0l;
 get__input_2_interrupt:
  goto interrupt_2;
 }

 process__string_2_top: {
  q x0, x1, x2;
  a0 = qp->args[0];
  a1 = qp->args[1];
  qp = qp->next;
 process__string_2_clear_reason:
  reasonp = reasons;
 process__string_2_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_main_xconnect__to__socket_4);
  allocp[2] = a0;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_builtin_xprint_1);
  allocp[8] = x2;
  a0 = a1;
  a1 = x0;
  a2 = x1;
  a3 = x2;
  qp = (struct goalrec*)&allocp[6];
  allocp += 9;
  execute(find__socket_4_0);
  goto find__socket_4_ext_interrupt;
 process__string_2_ext_interrupt:
  reasonp = 0l;
 process__string_2_interrupt:
  goto interrupt_2;
 }

 connect__to__socket_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 connect__to__socket_4_clear_reason:
  reasonp = reasons;
 connect__to__socket_4_0:
 connect__to__socket_4_1:
  if (!isint(a1)) goto connect__to__socket_4_4;
  gblt_integer(a1,connect__to__socket_4_5);
 connect__to__socket_4_2:
  if (!isint(a2)) goto connect__to__socket_4_3;
  gblt_integer(a2,connect__to__socket_4_5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_main_xcheck__input_4);
  allocp[2] = a0;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = x2 = makeref(&allocp[5]);
  x3 = makeint(0L);
  generic_arg[0] = x3;
  x4 = makeint(8L);
  generic_arg[1] = x4;
  qp = (struct goalrec*)&allocp[0];
  new_generic(string_g_new, 2, x5, 6);
  unify(x0, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_main_xcomm__msg_5);
  allocp[2] = x6 = makeref(&allocp[2]);
  allocp[3] = x7 = makeref(&allocp[3]);
  allocp[4] = a3;
  allocp[5] = x1;
  allocp[6] = x2;
  allocp[7] = makesym(functor_inet_2);
  allocp[8] = makefunctor(&string_const_3);
  allocp[9] = a2;
  x8 = makefunctor(&allocp[7]);
  allocp[10] = makesym(functor_connect_2);
  allocp[11] = x8;
  allocp[12] = x7;
  x9 = makefunctor(&allocp[10]);
  allocp[13] = NILATOM;
  allocp[14] = x9;
  x10 = makecons(&allocp[13]);
  allocp[15] = (q)(struct goalrec*)&allocp[0];
  allocp[16] = (q)(&predicate_unix_xunix_1);
  allocp[17] = x10;
  allocp[18] = makesym(functor_inet_2);
  allocp[19] = makefunctor(&string_const_3);
  allocp[20] = a1;
  x11 = makefunctor(&allocp[18]);
  allocp[21] = makesym(functor_connect_2);
  allocp[22] = x11;
  allocp[23] = x6;
  x12 = makefunctor(&allocp[21]);
  allocp[24] = NILATOM;
  allocp[25] = x12;
  x13 = makecons(&allocp[24]);
  allocp[26] = (q)(struct goalrec*)&allocp[15];
  allocp[27] = (q)(&predicate_unix_xunix_1);
  allocp[28] = x13;
  qp = (struct goalrec*)&allocp[26];
  allocp += 29;
  proceed();
 connect__to__socket_4_3:
  if (!isref(a2)) goto connect__to__socket_4_5;
  deref_and_jump(a2,connect__to__socket_4_2);
  *reasonp++ =  a2;
  goto connect__to__socket_4_5;
 connect__to__socket_4_4:
  if (!isref(a1)) goto connect__to__socket_4_5;
  deref_and_jump(a1,connect__to__socket_4_1);
  *reasonp++ =  a1;
  goto connect__to__socket_4_5;
 connect__to__socket_4_5:
  otherwise(connect__to__socket_4_interrupt);
 connect__to__socket_4_6:
  if (isref(a1)) goto connect__to__socket_4_13;
 connect__to__socket_4_7:
  if (isref(a1)) goto connect__to__socket_4_12;
  x0 = makefunctor(&string_const_0);
  if_not_equal(a1, x0, connect__to__socket_4_interrupt);
 connect__to__socket_4_8:
  if (isref(a2)) goto connect__to__socket_4_11;
 connect__to__socket_4_9:
  if (isref(a2)) goto connect__to__socket_4_10;
  x1 = makefunctor(&string_const_0);
  if_not_equal(a2, x1, connect__to__socket_4_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_main_xcheck__input_4);
  allocp[2] = a0;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = x4 = makeref(&allocp[5]);
  x5 = makeint(0L);
  generic_arg[0] = x5;
  x6 = makeint(8L);
  generic_arg[1] = x6;
  qp = (struct goalrec*)&allocp[0];
  new_generic(string_g_new, 2, x7, 6);
  unify(x2, x7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_main_xcomm__msg_5);
  allocp[2] = x8 = makeref(&allocp[2]);
  allocp[3] = x9 = makeref(&allocp[3]);
  allocp[4] = a3;
  allocp[5] = x3;
  allocp[6] = x4;
  allocp[7] = makesym(functor_connect_2);
  allocp[8] = makefunctor(funct_const_7);
  allocp[9] = x9;
  x10 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x10;
  x11 = makecons(&allocp[10]);
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_unix_xunix_1);
  allocp[14] = x11;
  allocp[15] = makesym(functor_connect_2);
  allocp[16] = makefunctor(funct_const_5);
  allocp[17] = x8;
  x12 = makefunctor(&allocp[15]);
  allocp[18] = NILATOM;
  allocp[19] = x12;
  x13 = makecons(&allocp[18]);
  allocp[20] = (q)(struct goalrec*)&allocp[12];
  allocp[21] = (q)(&predicate_unix_xunix_1);
  allocp[22] = x13;
  qp = (struct goalrec*)&allocp[20];
  allocp += 23;
  proceed();
 connect__to__socket_4_10:
  deref_and_jump(a2,connect__to__socket_4_9);
  *reasonp++ =  a2;
  goto connect__to__socket_4_interrupt;
 connect__to__socket_4_11:
  deref_and_jump(a2,connect__to__socket_4_8);
  *reasonp++ =  a2;
  goto connect__to__socket_4_interrupt;
 connect__to__socket_4_12:
  deref_and_jump(a1,connect__to__socket_4_7);
  *reasonp++ =  a1;
  goto connect__to__socket_4_interrupt;
 connect__to__socket_4_13:
  deref_and_jump(a1,connect__to__socket_4_6);
  *reasonp++ =  a1;
  goto connect__to__socket_4_interrupt;
 connect__to__socket_4_ext_interrupt:
  reasonp = 0l;
 connect__to__socket_4_interrupt:
  goto interrupt_4;
 }

 comm__msg_5_top: {
  q x0, x1;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 comm__msg_5_clear_reason:
  reasonp = reasons;
 comm__msg_5_0:
 comm__msg_5_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_normal_1)) goto comm__msg_5_interrupt;
 comm__msg_5_2:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_normal_1)) goto comm__msg_5_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_main_xread__response_4);
  x0 = arg(a1, 0);
  allocp[2] = x0;
  allocp[3] = a3;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a4;
  a0 = arg(a0, 0);
  a1 = a2;
  a2 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(write__msg_3_0);
  goto write__msg_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,comm__msg_5_2);
  *reasonp++ =  a1;
  goto comm__msg_5_interrupt;
  };
  goto comm__msg_5_interrupt;
 case VARREF:
  deref_and_jump(a0,comm__msg_5_1);
  *reasonp++ =  a0;
  goto comm__msg_5_interrupt;
  };
  goto comm__msg_5_interrupt;
 comm__msg_5_ext_interrupt:
  reasonp = 0l;
 comm__msg_5_interrupt:
  goto interrupt_5;
 }

 write__msg_3_top: {
  q x0, x1, x2, x3, x4;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 write__msg_3_clear_reason:
  reasonp = reasons;
 write__msg_3_0:
  allocp[0] = makesym(functor_fwrite_2);
  allocp[1] = a1;
  allocp[2] = a2;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_sync_1);
  allocp[4] = x2 = makeref(&allocp[4]);
  x1 = makefunctor(&allocp[3]);
  allocp[5] = NILATOM;
  allocp[6] = x1;
  x3 = makecons(&allocp[5]);
  allocp[7] = x3;
  allocp[8] = x0;
  x4 = makecons(&allocp[7]);
  allocp += 9;
  unify_value(a0, x4);
  proceed();
 write__msg_3_ext_interrupt:
  reasonp = 0l;
 write__msg_3_interrupt:
  toppred = &predicate_main_xwrite__msg_3;
  goto interrupt_3;
 }

 read__response_4_top: {
  q x0, x1, x2, x3, x4;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 read__response_4_clear_reason:
  reasonp = reasons;
 read__response_4_0:
 read__response_4_1:
  if (isref(a2)) goto read__response_4_2;
  gblt_wait(a2,read__response_4_interrupt);
  allocp[0] = makesym(functor_getc_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = x0;
  x2 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a0, x2);
  a0 = x1;
  x4 = a1;
  a4 = a2;
  a2 = x4;
  a1 = x3;
  execute(read__response_2F4_240_5_0);
  goto read__response_2F4_240_5_ext_interrupt;
 read__response_4_2:
  deref_and_jump(a2,read__response_4_1);
  *reasonp++ =  a2;
  goto read__response_4_interrupt;
 read__response_4_ext_interrupt:
  reasonp = 0l;
 read__response_4_interrupt:
  toppred = &predicate_main_xread__response_4;
  goto interrupt_4;
 }

 read__response_2F4_240_5_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 read__response_2F4_240_5_clear_reason:
  reasonp = reasons;
 read__response_2F4_240_5_0:
 read__response_2F4_240_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 read__response_2F4_240_5_2:
  if (a0 != makeint(0L)) goto read__response_2F4_240_5_3;
  x0 = NILATOM;
  unify_value(a1, x0);
  x1 = NILATOM;
  unify_value(a2, x1);
  x2 = makesym(atom_ok);
  unify_value(a3, x2);
  proceed();
 case VARREF:
  deref_and_jump(a0,read__response_2F4_240_5_1);
  *reasonp++ =  a0;
  goto read__response_2F4_240_5_interrupt;
  };
  goto read__response_2F4_240_5_3;
 read__response_2F4_240_5_3:
  x0 = makeint(0L);
  gblt_diff(a0,x0,read__response_2F4_240_5_interrupt);
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x1 = makecons(&allocp[0]);
  generic_arg[0] = x1;
  x2 = makeint(8L);
  generic_arg[1] = x2;
  new_generic(string_g_new, 2, x3, 2);
  allocp[0] = makesym(functor_f_1);
  allocp[1] = x3;
  x4 = makefunctor(&allocp[0]);
  allocp[2] = x6 = makeref(&allocp[2]);
  allocp[3] = x4;
  x5 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a2, x5);
  a0 = a1;
  a1 = x6;
  a2 = a4;
  execute(read__response_4_0);
  goto read__response_4_ext_interrupt;
 read__response_2F4_240_5_ext_interrupt:
  reasonp = 0l;
 read__response_2F4_240_5_interrupt:
  toppred = &predicate_main_xread__response_2F4_240_5;
  goto interrupt_5;
 }

 check__input_4_top: {
  q x0, x1, x2, x3, x4;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 check__input_4_clear_reason:
  reasonp = reasons;
 check__input_4_0:
 check__input_4_1:
  switch (ptagof(a1)) {
 case FUNCTOR:
 check__input_4_2:
  if (!isgobj(a1)) goto check__input_4_7;
 check__input_4_3:
  gblt_is_string(a1,check__input_4_7);
  gblt_size_of_string(a1,x0,check__input_4_7);
  gblt_element_size_of_string(a1,x1,check__input_4_7);
 check__input_4_4:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != NILATOM) goto check__input_4_7;
 check__input_4_5:
  if (isref(a3)) goto check__input_4_6;
  gblt_wait(a3,check__input_4_7);
  execute(write__to__stdout_2_0);
  goto write__to__stdout_2_ext_interrupt;
 check__input_4_6:
  deref_and_jump(a3,check__input_4_5);
  *reasonp++ =  a3;
  goto check__input_4_7;
 case VARREF:
  deref_and_jump(a2,check__input_4_4);
  *reasonp++ =  a2;
  goto check__input_4_7;
  };
  goto check__input_4_7;
 case VARREF:
  deref_and_jump(a1,check__input_4_1);
  *reasonp++ =  a1;
  goto check__input_4_7;
  };
  goto check__input_4_7;
 check__input_4_7:
 check__input_4_8:
  switch (ptagof(a2)) {
 case CONS:
 check__input_4_9:
  switch (ptagof(a1)) {
 case FUNCTOR:
 check__input_4_10:
  if (!isgobj(a1)) goto check__input_4_interrupt;
 check__input_4_11:
  gblt_is_string(a1,check__input_4_interrupt);
  gblt_size_of_string(a1,x0,check__input_4_interrupt);
  gblt_element_size_of_string(a1,x1,check__input_4_interrupt);
  x2 = car_of(a2);
 check__input_4_12:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_f_1)) goto check__input_4_interrupt;
 check__input_4_13:
  if (isref(a3)) goto check__input_4_14;
  gblt_wait(a3,check__input_4_interrupt);
  x3 = arg(x2, 0);
  generic_arg[0] = x3;
  allocp[0] = x4 = makeref(&allocp[0]);
  generic_arg[1] = x4;
  call_generic(a1, functor_join_2, 1);
  a1 = x4;
  a2 = cdr_of(a2);
  execute(check__input_4_clear_reason);
  goto check__input_4_ext_interrupt;
 check__input_4_14:
  deref_and_jump(a3,check__input_4_13);
  *reasonp++ =  a3;
  goto check__input_4_interrupt;
 case VARREF:
  deref_and_jump(x2,check__input_4_12);
  *reasonp++ =  x2;
  goto check__input_4_interrupt;
  };
  goto check__input_4_interrupt;
 case VARREF:
  deref_and_jump(a1,check__input_4_9);
  *reasonp++ =  a1;
  goto check__input_4_interrupt;
  };
  goto check__input_4_interrupt;
 case VARREF:
  deref_and_jump(a2,check__input_4_8);
  *reasonp++ =  a2;
  goto check__input_4_interrupt;
  };
  goto check__input_4_interrupt;
 check__input_4_ext_interrupt:
  reasonp = 0l;
 check__input_4_interrupt:
  goto interrupt_4;
 }

 write__to__stdout_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a0 = qp->args[0];
  a1 = qp->args[1];
  qp = qp->next;
 write__to__stdout_2_clear_reason:
  reasonp = reasons;
 write__to__stdout_2_0:
 write__to__stdout_2_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_normal_1)) goto write__to__stdout_2_interrupt;
  generic_arg[0] = a1;
  allocp[0] = x0 = makeref(&allocp[0]);
  generic_arg[1] = x0;
  x1 = makefunctor(&string_const_2);
  call_generic(x1, functor_join_2, 1);
  allocp[0] = makesym(functor_fwrite_1);
  allocp[1] = x0;
  x2 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_sync_1);
  allocp[3] = x4 = makeref(&allocp[3]);
  x3 = makefunctor(&allocp[2]);
  allocp[4] = NILATOM;
  allocp[5] = x3;
  x5 = makecons(&allocp[4]);
  allocp[6] = x5;
  allocp[7] = x2;
  x6 = makecons(&allocp[6]);
  x7 = arg(a0, 0);
  allocp += 8;
  unify_value(x7, x6);
  proceed();
 case VARREF:
  deref_and_jump(a0,write__to__stdout_2_1);
  *reasonp++ =  a0;
  goto write__to__stdout_2_interrupt;
  };
  goto write__to__stdout_2_interrupt;
 write__to__stdout_2_ext_interrupt:
  reasonp = 0l;
 write__to__stdout_2_interrupt:
  toppred = &predicate_main_xwrite__to__stdout_2;
  goto interrupt_2;
 }

 print__result_1_top: {
  a0 = qp->args[0];
  qp = qp->next;
 print__result_1_clear_reason:
  reasonp = reasons;
 print__result_1_0:
 print__result_1_1:
  if (isref(a0)) goto print__result_1_2;
  gblt_wait(a0,print__result_1_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin_xprint_1);
  allocp[2] = a0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 3;
  proceed();
 print__result_1_2:
  deref_and_jump(a0,print__result_1_1);
  *reasonp++ =  a0;
  goto print__result_1_interrupt;
 print__result_1_ext_interrupt:
  reasonp = 0l;
 print__result_1_interrupt:
  goto interrupt_1;
 }

 find__socket_4_top: {
  q x0, x1, x2, x3, x4;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 find__socket_4_clear_reason:
  reasonp = reasons;
 find__socket_4_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_main_xfind__socket_2F4_240_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_main_xjoin__list_2);
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = a3;
  allocp[10] = (q)(struct goalrec*)&allocp[6];
  allocp[11] = (q)(&predicate_main_xfind__pair_4);
  allocp[12] = x3 = makeref(&allocp[12]);
  allocp[13] = makesym(atom_socket2);
  allocp[14] = x1;
  allocp[15] = x2;
  allocp[16] = (q)(struct goalrec*)&allocp[10];
  allocp[17] = (q)(&predicate_main_xfind__pair_4);
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom_socket1);
  allocp[20] = x0;
  allocp[21] = x3;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_cgi_xnamevaluepairs_2);
  allocp[24] = a0;
  allocp[25] = x4;
  qp = (struct goalrec*)&allocp[22];
  allocp += 26;
  proceed();
 find__socket_4_ext_interrupt:
  reasonp = 0l;
 find__socket_4_interrupt:
  toppred = &predicate_main_xfind__socket_4;
  goto interrupt_4;
 }

 find__socket_2F4_240_4_top: {
  q x0, x1, x2, x3, x4, x5;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 find__socket_2F4_240_4_clear_reason:
  reasonp = reasons;
 find__socket_2F4_240_4_0:
 find__socket_2F4_240_4_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_socket1_1)) goto find__socket_2F4_240_4_3;
 find__socket_2F4_240_4_2:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_socket2_1)) goto find__socket_2F4_240_4_3;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_util_xatoi_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a3;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_util_xatoi_2);
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = a2;
  allocp[8] = NILATOM;
  x3 = arg(a1, 0);
  allocp[9] = x3;
  x2 = makecons(&allocp[8]);
  allocp[10] = (q)(struct goalrec*)&allocp[4];
  allocp[11] = (q)(&predicate_util_xlosToLst_2);
  allocp[12] = x2;
  allocp[13] = x0;
  allocp[14] = NILATOM;
  x5 = arg(a0, 0);
  allocp[15] = x5;
  x4 = makecons(&allocp[14]);
  allocp[16] = (q)(struct goalrec*)&allocp[10];
  allocp[17] = (q)(&predicate_util_xlosToLst_2);
  allocp[18] = x4;
  allocp[19] = x1;
  qp = (struct goalrec*)&allocp[16];
  allocp += 20;
  proceed();
 case VARREF:
  deref_and_jump(a1,find__socket_2F4_240_4_2);
  *reasonp++ =  a1;
  goto find__socket_2F4_240_4_3;
  };
  goto find__socket_2F4_240_4_3;
 case VARREF:
  deref_and_jump(a0,find__socket_2F4_240_4_1);
  *reasonp++ =  a0;
  goto find__socket_2F4_240_4_3;
  };
  goto find__socket_2F4_240_4_3;
 find__socket_2F4_240_4_3:
  otherwise(find__socket_2F4_240_4_interrupt);
  x0 = makefunctor(&string_const_0);
  unify_value(a2, x0);
  x1 = makefunctor(&string_const_0);
  unify_value(a3, x1);
  proceed();
 find__socket_2F4_240_4_ext_interrupt:
  reasonp = 0l;
 find__socket_2F4_240_4_interrupt:
  goto interrupt_4;
 }

 find__pair_4_top: {
  q x0;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 find__pair_4_clear_reason:
  reasonp = reasons;
 find__pair_4_0:
  x0 = a2;
  a4 = a3;
  a3 = x0;
  a2 = NILATOM;
  execute(find__pair_5_0);
  goto find__pair_5_ext_interrupt;
 find__pair_4_ext_interrupt:
  reasonp = 0l;
 find__pair_4_interrupt:
  goto interrupt_4;
 }

 find__pair_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 find__pair_5_clear_reason:
  reasonp = reasons;
 find__pair_5_0:
 find__pair_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != NILATOM) goto find__pair_5_2;
  x0 = makefunctor(&string_const_0);
  unify_value(a3, x0);
  unify(a4, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,find__pair_5_1);
  *reasonp++ =  a0;
  goto find__pair_5_2;
  };
  goto find__pair_5_2;
 find__pair_5_2:
  otherwise(find__pair_5_interrupt);
 find__pair_5_3:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 find__pair_5_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
 find__pair_5_5:
  if (!isgobj(x0)) goto find__pair_5_interrupt;
 find__pair_5_6:
  gblt_is_string(x0,find__pair_5_interrupt);
  gblt_size_of_string(x0,x1,find__pair_5_interrupt);
  gblt_element_size_of_string(x0,x2,find__pair_5_interrupt);
  allocp[0] = x3 = makeref(&allocp[0]);
  generic_arg[0] = x3;
  call_generic(x0, functor_size_1, 1);
  x4 = makeint(1L);
  bblt_sub_no_check_y(x3,x4,x5);
  x6 = makeint(0L);
  generic_arg[0] = x6;
  generic_arg[1] = x5;
  x7 = makeint(61L);
  generic_arg[2] = x7;
  allocp[0] = x8 = makeref(&allocp[0]);
  generic_arg[3] = x8;
  call_generic(x0, functor_search__character_4, 1);
  x9 = a2;
  a2 = x0;
  x10 = cdr_of(a0);
  x11 = a1;
  a5 = a3;
  a6 = a4;
  a4 = x11;
  a3 = x10;
  a1 = x9;
  a0 = x8;
  execute(find__pair_2F5_240_7_0);
  goto find__pair_2F5_240_7_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,find__pair_5_4);
  *reasonp++ =  x0;
  goto find__pair_5_interrupt;
  };
  goto find__pair_5_interrupt;
 case VARREF:
  deref_and_jump(a0,find__pair_5_3);
  *reasonp++ =  a0;
  goto find__pair_5_interrupt;
  };
  goto find__pair_5_interrupt;
 find__pair_5_ext_interrupt:
  reasonp = 0l;
 find__pair_5_interrupt:
  toppred = &predicate_main_xfind__pair_5;
  goto interrupt_5;
 }

 find__pair_2F5_240_7_top: {
  q x0, x1, x2, x3;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 find__pair_2F5_240_7_clear_reason:
  reasonp = reasons;
 find__pair_2F5_240_7_0:
 find__pair_2F5_240_7_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 find__pair_2F5_240_7_2:
  if (a0 != makeint(-1L)) goto find__pair_2F5_240_7_3;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_main_xfind__pair_5);
  allocp[2] = a3;
  allocp[3] = a4;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = a5;
  allocp[6] = a6;
  allocp[7] = NILATOM;
  allocp[8] = a2;
  x1 = makecons(&allocp[7]);
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_util_xappend_3);
  allocp[11] = a1;
  allocp[12] = x1;
  allocp[13] = x0;
  qp = (struct goalrec*)&allocp[9];
  allocp += 14;
  proceed();
 case VARREF:
  deref_and_jump(a0,find__pair_2F5_240_7_1);
  *reasonp++ =  a0;
  goto find__pair_2F5_240_7_interrupt;
  };
  goto find__pair_2F5_240_7_3;
 find__pair_2F5_240_7_3:
  x0 = makeint(-1L);
  gblt_diff(a0,x0,find__pair_2F5_240_7_interrupt);
  generic_arg[0] = a0;
  allocp[0] = x1 = makeref(&allocp[0]);
  generic_arg[1] = x1;
  allocp[1] = x2 = makeref(&allocp[1]);
  generic_arg[2] = x2;
  call_generic(a2, functor_split_3, 2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_main_xfind__pair_2F5_240_2F7_240_8);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = a4;
  allocp[4] = x2;
  allocp[5] = a5;
  allocp[6] = a1;
  allocp[7] = a3;
  allocp[8] = a6;
  allocp[9] = a2;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_atom__table_xmake__atom_2);
  allocp[12] = x1;
  allocp[13] = x3;
  qp = (struct goalrec*)&allocp[10];
  allocp += 14;
  proceed();
 find__pair_2F5_240_7_ext_interrupt:
  reasonp = 0l;
 find__pair_2F5_240_7_interrupt:
  toppred = &predicate_main_xfind__pair_2F5_240_7;
  goto interrupt_7;
 }

 find__pair_2F5_240_2F7_240_8_top: {
  q x0, x1, x2, x3, x4;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 find__pair_2F5_240_2F7_240_8_clear_reason:
  reasonp = reasons;
 find__pair_2F5_240_2F7_240_8_0:
 find__pair_2F5_240_2F7_240_8_1:
  if (isref(a0)) goto find__pair_2F5_240_2F7_240_8_4;
 find__pair_2F5_240_2F7_240_8_2:
  if (isref(a0)) goto find__pair_2F5_240_2F7_240_8_3;
  if_not_equal(a0, a1, find__pair_2F5_240_2F7_240_8_5);
  x0 = makeint(1L);
  generic_arg[0] = x0;
  allocp[0] = x1 = makeref(&allocp[0]);
  generic_arg[1] = x1;
  allocp[1] = x2 = makeref(&allocp[1]);
  generic_arg[2] = x2;
  call_generic(a2, functor_split_3, 2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_util_xappend_3);
  allocp[2] = a4;
  allocp[3] = a5;
  allocp[4] = a6;
  allocp[5] = NILATOM;
  allocp[6] = x2;
  x3 = makecons(&allocp[5]);
  allocp[7] = x3;
  allocp[8] = a0;
  x4 = makecons(&allocp[7]);
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[11] = a3;
  allocp[12] = x4;
  qp = (struct goalrec*)&allocp[9];
  allocp += 13;
  proceed();
 find__pair_2F5_240_2F7_240_8_3:
  deref_and_jump(a0,find__pair_2F5_240_2F7_240_8_2);
  *reasonp++ =  a0;
  goto find__pair_2F5_240_2F7_240_8_5;
 find__pair_2F5_240_2F7_240_8_4:
  deref_and_jump(a0,find__pair_2F5_240_2F7_240_8_1);
  *reasonp++ =  a0;
  goto find__pair_2F5_240_2F7_240_8_5;
 find__pair_2F5_240_2F7_240_8_5:
  otherwise(find__pair_2F5_240_2F7_240_8_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_main_xfind__pair_5);
  allocp[2] = a5;
  allocp[3] = a1;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a6;
  allocp[7] = NILATOM;
  allocp[8] = a7;
  x1 = makecons(&allocp[7]);
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_util_xappend_3);
  allocp[11] = a4;
  allocp[12] = x1;
  allocp[13] = x0;
  qp = (struct goalrec*)&allocp[9];
  allocp += 14;
  proceed();
 find__pair_2F5_240_2F7_240_8_ext_interrupt:
  reasonp = 0l;
 find__pair_2F5_240_2F7_240_8_interrupt:
  goto interrupt_8;
 }

 join__list_2_top: {
  q x0, x1, x2, x3, x4, x5;
  a0 = qp->args[0];
  a1 = qp->args[1];
  qp = qp->next;
 join__list_2_clear_reason:
  reasonp = reasons;
 join__list_2_0:
 join__list_2_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != NILATOM) goto join__list_2_2;
  x0 = makefunctor(&string_const_0);
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,join__list_2_1);
  *reasonp++ =  a0;
  goto join__list_2_2;
  };
  goto join__list_2_2;
 join__list_2_2:
  otherwise(join__list_2_interrupt);
 join__list_2_3:
  switch (ptagof(a0)) {
 case CONS:
  x0 = cdr_of(a0);
 join__list_2_4:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != NILATOM) goto join__list_2_5;
  x1 = car_of(a0);
  unify(a1, x1);
  proceed();
 case VARREF:
  deref_and_jump(x0,join__list_2_4);
  *reasonp++ =  x0;
  goto join__list_2_5;
  };
  goto join__list_2_5;
 case VARREF:
  deref_and_jump(a0,join__list_2_3);
  *reasonp++ =  a0;
  goto join__list_2_5;
  };
  goto join__list_2_5;
 join__list_2_5:
  otherwise(join__list_2_interrupt);
 join__list_2_6:
  switch (ptagof(a0)) {
 case CONS:
  x0 = cdr_of(a0);
 join__list_2_7:
  switch (ptagof(x0)) {
 case CONS:
  x1 = makefunctor(&string_const_1);
  generic_arg[0] = x1;
  allocp[0] = x2 = makeref(&allocp[0]);
  generic_arg[1] = x2;
  x3 = car_of(a0);
  call_generic(x3, functor_join_2, 1);
  x4 = car_of(x0);
  generic_arg[0] = x4;
  allocp[0] = x5 = makeref(&allocp[0]);
  generic_arg[1] = x5;
  call_generic(x2, functor_join_2, 1);
  a0 = cdr_of(x0);
  a2 = a1;
  a1 = x5;
  execute(join__list_3_0);
  goto join__list_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,join__list_2_7);
  *reasonp++ =  x0;
  goto join__list_2_interrupt;
  };
  goto join__list_2_interrupt;
 case VARREF:
  deref_and_jump(a0,join__list_2_6);
  *reasonp++ =  a0;
  goto join__list_2_interrupt;
  };
  goto join__list_2_interrupt;
 join__list_2_ext_interrupt:
  reasonp = 0l;
 join__list_2_interrupt:
  goto interrupt_2;
 }

 join__list_3_top: {
  q x0, x1, x2, x3;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 join__list_3_clear_reason:
  reasonp = reasons;
 join__list_3_0:
 join__list_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != NILATOM) goto join__list_3_2;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,join__list_3_1);
  *reasonp++ =  a0;
  goto join__list_3_2;
  };
  goto join__list_3_2;
 join__list_3_2:
  otherwise(join__list_3_interrupt);
 join__list_3_3:
  switch (ptagof(a0)) {
 case CONS:
  x0 = makefunctor(&string_const_1);
  generic_arg[0] = x0;
  allocp[0] = x1 = makeref(&allocp[0]);
  generic_arg[1] = x1;
  call_generic(a1, functor_join_2, 1);
  x2 = car_of(a0);
  generic_arg[0] = x2;
  allocp[0] = x3 = makeref(&allocp[0]);
  generic_arg[1] = x3;
  call_generic(x1, functor_join_2, 1);
  a0 = cdr_of(a0);
  a1 = x3;
  execute(join__list_3_0);
  goto join__list_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,join__list_3_3);
  *reasonp++ =  a0;
  goto join__list_3_interrupt;
  };
  goto join__list_3_interrupt;
 join__list_3_ext_interrupt:
  reasonp = 0l;
 join__list_3_interrupt:
  toppred = &predicate_main_xjoin__list_3;
  goto interrupt_3;
 }
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_main);
}
