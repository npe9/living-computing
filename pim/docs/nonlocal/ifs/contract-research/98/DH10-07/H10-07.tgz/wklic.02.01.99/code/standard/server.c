/* Compiled by KLIC compiler version 3.001 (Thu Jun  5 20:19:10 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_main();
Const struct predicate predicate_main_xmain_0 =
   { module_main, 0, 0 };
Const struct predicate predicate_main_xprocess__accept_4 =
   { module_main, 1, 4 };
Const struct predicate predicate_main_xcreate__child_4 =
   { module_main, 2, 4 };
Const struct predicate predicate_main_xcreate__child_2F4_240_5 =
   { module_main, 3, 5 };
Const struct predicate predicate_main_xparent__process_4 =
   { module_main, 4, 4 };
Const struct predicate predicate_main_xchild__process_4 =
   { module_main, 5, 4 };
Const struct predicate predicate_main_xwrite__to__parent_3 =
   { module_main, 6, 3 };
Const struct predicate predicate_main_xwrite__io_3 =
   { module_main, 7, 3 };
Const struct predicate predicate_main_xprint__result_1 =
   { module_main, 8, 1 };
Const struct predicate predicate_main_xp1_2 =
   { module_main, 9, 2 };
extern Const struct predicate predicate_unix_xunix_1;
extern Const struct predicate predicate_builtin_xprint_1;
extern Const struct predicate predicate_generic_xgeneric_2;
extern Const struct predicate predicate_cgi_xbind__cgi_2;
extern Const struct predicate predicate_cgi_xwait__cgi__input_6;
extern Const struct predicate predicate_cgi_xread__cgi__input_3;
extern Const struct predicate predicate_tohtml_xtohtml_2;
extern Const struct predicate predicate_util_xlosToLst_2;

module module_main(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  static Const unsigned char strconst_body_0[4] =
    "\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_0 =
      declare_string_constant_8(strconst_body_0,1);
  static Const unsigned char strconst_body_1[12] =
    "I am parent";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_1 =
      declare_string_constant_8(strconst_body_1,11);
  static Const unsigned char strconst_body_2[16] =
    "GENERATED PAGE";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_2 =
      declare_string_constant_8(strconst_body_2,14);
  static Const q cons_const_3[] = {
    NILATOM,
    makefunctor(&string_const_2),
  };
  static Const q funct_const_4[] = {
    makesym(functor_align_1),
    makesym(atom_center),
  };
  static Const q cons_const_5[] = {
    NILATOM,
    makefunctor(funct_const_4),
  };
  static Const q funct_const_6[] = {
    makesym(functor_putc_1),
    makeint(0),
  };
  q a0, a1, a2, a3, a4;

  q *reasonp;
 module_top:
  switch_on_pred() {
    case_pred(0, main_0_top);
    case_pred(1, process__accept_4_top);
    case_pred(2, create__child_4_top);
    case_pred(3, create__child_2F4_240_5_top);
    case_pred(4, parent__process_4_top);
    case_pred(5, child__process_4_top);
    case_pred(6, write__to__parent_3_top);
    case_pred(7, write__io_3_top);
    case_pred(8, print__result_1_top);
    last_case_pred(9, p1_2_top);
  }

 main_0_top: {
  q x0, x1, x2, x3, x4, x5;
  qp = qp->next;
 main_0_clear_reason:
  reasonp = reasons;
 main_0_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_main_xprocess__accept_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_cgi_xwait__cgi__input_6);
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = x5 = makeref(&allocp[9]);
  allocp[10] = x0;
  allocp[11] = x1;
  allocp[12] = x2;
  allocp[13] = x3;
  allocp[14] = (q)(struct goalrec*)&allocp[6];
  allocp[15] = (q)(&predicate_cgi_xbind__cgi_2);
  allocp[16] = x4;
  allocp[17] = x5;
  qp = (struct goalrec*)&allocp[14];
  allocp += 18;
  proceed();
 main_0_ext_interrupt:
  reasonp = 0l;
 main_0_interrupt:
  goto interrupt_0;
 }

 process__accept_4_top: {
  q x0, x1;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 process__accept_4_clear_reason:
  reasonp = reasons;
 process__accept_4_0:
  x0 = a2;
  a2 = a1;
  allocp[0] = x1 = makeref(&allocp[0]);
  a3 = x1;
  a1 = x0;
  allocp += 1;
  execute(create__child_4_0);
  goto create__child_4_ext_interrupt;
 process__accept_4_ext_interrupt:
  reasonp = 0l;
 process__accept_4_interrupt:
  goto interrupt_4;
 }

 create__child_4_top: {
  q x0, x1, x2, x3, x4;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 create__child_4_clear_reason:
  reasonp = reasons;
 create__child_4_0:
 create__child_4_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_normal_1)) goto create__child_4_interrupt;
 create__child_4_2:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_normal_1)) goto create__child_4_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_main_xcreate__child_2F4_240_5);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a3;
  x1 = arg(a0, 0);
  allocp[5] = x1;
  x2 = arg(a2, 0);
  allocp[6] = x2;
  allocp[7] = makesym(functor_fork__with__pipes_1);
  allocp[8] = x0;
  x3 = makefunctor(&allocp[7]);
  allocp[9] = NILATOM;
  allocp[10] = x3;
  x4 = makecons(&allocp[9]);
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_unix_xunix_1);
  allocp[13] = x4;
  qp = (struct goalrec*)&allocp[11];
  allocp += 14;
  proceed();
 case VARREF:
  deref_and_jump(a2,create__child_4_2);
  *reasonp++ =  a2;
  goto create__child_4_interrupt;
  };
  goto create__child_4_interrupt;
 case VARREF:
  deref_and_jump(a0,create__child_4_1);
  *reasonp++ =  a0;
  goto create__child_4_interrupt;
  };
  goto create__child_4_interrupt;
 create__child_4_ext_interrupt:
  reasonp = 0l;
 create__child_4_interrupt:
  toppred = &predicate_main_xcreate__child_4;
  goto interrupt_4;
 }

 create__child_2F4_240_5_top: {
  q x0;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 create__child_2F4_240_5_clear_reason:
  reasonp = reasons;
 create__child_2F4_240_5_0:
 create__child_2F4_240_5_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_parent_3:
  x0 = a1;
  a1 = a2;
  a2 = arg(a0, 1);
  a3 = arg(a0, 2);
  a0 = x0;
  execute(parent__process_4_0);
  goto parent__process_4_ext_interrupt;
 case functor_child_2:
  x0 = a3;
  a1 = a4;
  a2 = arg(a0, 0);
  a3 = arg(a0, 1);
  a0 = x0;
  execute(child__process_4_0);
  goto child__process_4_ext_interrupt;
  };
  goto create__child_2F4_240_5_interrupt;
 case VARREF:
  deref_and_jump(a0,create__child_2F4_240_5_1);
  *reasonp++ =  a0;
  goto create__child_2F4_240_5_interrupt;
  };
  goto create__child_2F4_240_5_interrupt;
 create__child_2F4_240_5_ext_interrupt:
  reasonp = 0l;
 create__child_2F4_240_5_interrupt:
  goto interrupt_5;
 }

 parent__process_4_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 parent__process_4_clear_reason:
  reasonp = reasons;
 parent__process_4_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_main_xprocess__accept_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_cgi_xwait__cgi__input_6);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = x0;
  allocp[11] = x1;
  allocp[12] = x2;
  allocp[13] = x3;
  allocp[14] = (q)(struct goalrec*)&allocp[6];
  allocp[15] = (q)(&predicate_main_xprint__result_1);
  allocp[16] = x4 = makeref(&allocp[16]);
  allocp[17] = makesym(functor_fread_2);
  allocp[18] = makeint(4096L);
  allocp[19] = x4;
  x5 = makefunctor(&allocp[17]);
  allocp[20] = NILATOM;
  allocp[21] = x5;
  x6 = makecons(&allocp[20]);
  qp = (struct goalrec*)&allocp[14];
  allocp += 22;
  unify_value(a2, x6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin_xprint_1);
  allocp[2] = makefunctor(&string_const_1);
  qp = (struct goalrec*)&allocp[0];
  allocp += 3;
  proceed();
 parent__process_4_ext_interrupt:
  reasonp = 0l;
 parent__process_4_interrupt:
  toppred = &predicate_main_xparent__process_4;
  goto interrupt_4;
 }

 child__process_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 child__process_4_clear_reason:
  reasonp = reasons;
 child__process_4_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_main_xwrite__io_3);
  allocp[2] = a1;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = makesym(functor_join_2);
  allocp[6] = makefunctor(&string_const_0);
  allocp[7] = x0;
  x2 = makefunctor(&allocp[5]);
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_generic_xgeneric_2);
  allocp[10] = x2;
  allocp[11] = x3 = makeref(&allocp[11]);
  allocp[12] = (q)(struct goalrec*)&allocp[8];
  allocp[13] = (q)(&predicate_main_xwrite__to__parent_3);
  allocp[14] = a3;
  allocp[15] = x3;
  allocp[16] = x1;
  allocp[17] = (q)(struct goalrec*)&allocp[12];
  allocp[18] = (q)(&predicate_tohtml_xtohtml_2);
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = x3;
  allocp[21] = makesym(functor_call_2);
  allocp[22] = x6 = makeref(&allocp[22]);
  allocp[23] = x4;
  x5 = makefunctor(&allocp[21]);
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_generic_xgeneric_2);
  allocp[26] = x5;
  allocp[27] = x7 = makeref(&allocp[27]);
  allocp[28] = (q)(struct goalrec*)&allocp[24];
  allocp[29] = (q)(&predicate_cgi_xread__cgi__input_3);
  allocp[30] = a0;
  allocp[31] = x7;
  allocp[32] = x6;
  qp = (struct goalrec*)&allocp[28];
  allocp += 33;
  proceed();
 child__process_4_ext_interrupt:
  reasonp = 0l;
 child__process_4_interrupt:
  toppred = &predicate_main_xchild__process_4;
  goto interrupt_4;
 }

 write__to__parent_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 write__to__parent_3_clear_reason:
  reasonp = reasons;
 write__to__parent_3_0:
  allocp[0] = makesym(functor_fwrite_1);
  allocp[1] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_fflush_1);
  allocp[3] = x2 = makeref(&allocp[3]);
  x1 = makefunctor(&allocp[2]);
  allocp[4] = makesym(functor_sync_1);
  allocp[5] = x4 = makeref(&allocp[5]);
  x3 = makefunctor(&allocp[4]);
  allocp[6] = NILATOM;
  allocp[7] = x3;
  x5 = makecons(&allocp[6]);
  allocp[8] = x5;
  allocp[9] = x1;
  x6 = makecons(&allocp[8]);
  allocp[10] = x6;
  allocp[11] = x0;
  x7 = makecons(&allocp[10]);
  allocp += 12;
  unify_value(a0, x7);
  x8 = makesym(atom_ok);
  unify_value(a2, x8);
  proceed();
 write__to__parent_3_ext_interrupt:
  reasonp = 0l;
 write__to__parent_3_interrupt:
  goto interrupt_3;
 }

 write__io_3_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 write__io_3_clear_reason:
  reasonp = reasons;
 write__io_3_0:
 write__io_3_1:
  if (isref(a2)) goto write__io_3_2;
  gblt_wait(a2,write__io_3_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_main_xprint__result_1);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = makesym(functor_fwrite_2);
  allocp[4] = a1;
  allocp[5] = x0;
  x1 = makefunctor(&allocp[3]);
  allocp[6] = makesym(functor_sync_1);
  allocp[7] = x3 = makeref(&allocp[7]);
  x2 = makefunctor(&allocp[6]);
  allocp[8] = NILATOM;
  allocp[9] = x2;
  x4 = makecons(&allocp[8]);
  allocp[10] = x4;
  allocp[11] = makefunctor(funct_const_6);
  x5 = makecons(&allocp[10]);
  allocp[12] = x5;
  allocp[13] = x1;
  x6 = makecons(&allocp[12]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 14;
  unify_value(a0, x6);
  a0 = a1;
  execute(print__result_1_0);
  goto print__result_1_ext_interrupt;
 write__io_3_2:
  deref_and_jump(a2,write__io_3_1);
  *reasonp++ =  a2;
  goto write__io_3_interrupt;
 write__io_3_ext_interrupt:
  reasonp = 0l;
 write__io_3_interrupt:
  goto interrupt_3;
 }

 print__result_1_top: {
  a0 = qp->args[0];
  qp = qp->next;
 print__result_1_clear_reason:
  reasonp = reasons;
 print__result_1_0:
 print__result_1_1:
  if (isref(a0)) goto print__result_1_2;
  gblt_wait(a0,print__result_1_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin_xprint_1);
  allocp[2] = a0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 3;
  proceed();
 print__result_1_2:
  deref_and_jump(a0,print__result_1_1);
  *reasonp++ =  a0;
  goto print__result_1_interrupt;
 print__result_1_ext_interrupt:
  reasonp = 0l;
 print__result_1_interrupt:
  toppred = &predicate_main_xprint__result_1;
  goto interrupt_1;
 }

 p1_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a0 = qp->args[0];
  a1 = qp->args[1];
  qp = qp->next;
 p1_2_clear_reason:
  reasonp = reasons;
 p1_2_0:
 p1_2_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = makesym(functor_text_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_title_2);
  allocp[3] = NILATOM;
  allocp[4] = x0;
  x2 = makefunctor(&allocp[2]);
  allocp[5] = makesym(functor_head_2);
  allocp[6] = NILATOM;
  allocp[7] = x2;
  x3 = makefunctor(&allocp[5]);
  allocp[8] = makesym(functor_text_1);
  allocp[9] = x5 = makeref(&allocp[9]);
  x4 = makefunctor(&allocp[8]);
  allocp[10] = makesym(functor_h1_2);
  allocp[11] = makecons(cons_const_5);
  allocp[12] = x4;
  x6 = makefunctor(&allocp[10]);
  allocp[13] = makesym(functor_body_2);
  allocp[14] = NILATOM;
  allocp[15] = x6;
  x7 = makefunctor(&allocp[13]);
  allocp[16] = makesym(functor_html_3);
  allocp[17] = NILATOM;
  allocp[18] = x3;
  allocp[19] = x7;
  x8 = makefunctor(&allocp[16]);
  allocp += 20;
  unify_value(a1, x8);
  allocp[0] = NILATOM;
  x10 = car_of(a0);
  allocp[1] = x10;
  x9 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_util_xlosToLst_2);
  allocp[4] = x9;
  allocp[5] = x5;
  allocp[6] = (q)(struct goalrec*)&allocp[2];
  allocp[7] = (q)(&predicate_util_xlosToLst_2);
  allocp[8] = makecons(cons_const_3);
  allocp[9] = x1;
  qp = (struct goalrec*)&allocp[6];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a0,p1_2_1);
  *reasonp++ =  a0;
  goto p1_2_interrupt;
  };
  goto p1_2_interrupt;
 p1_2_ext_interrupt:
  reasonp = 0l;
 p1_2_interrupt:
  goto interrupt_2;
 }
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_main);
}
