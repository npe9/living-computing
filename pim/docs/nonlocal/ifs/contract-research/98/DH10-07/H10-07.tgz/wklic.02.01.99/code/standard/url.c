/* Compiled by KLIC compiler version 3.001 (Thu Jun  5 20:19:10 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_url();
Const struct predicate predicate_url_xmkabsURL_3 =
   { module_url, 0, 3 };
Const struct predicate predicate_url_xmkabsURL_2F3_241_7 =
   { module_url, 1, 7 };
Const struct predicate predicate_url_xmkabsURL_2F3_241_2F7_240_7 =
   { module_url, 2, 7 };
Const struct predicate predicate_url_xmkabsURL_2F3_241_2F7_240_2F7_240_7 =
   { module_url, 3, 7 };
Const struct predicate predicate_url_xmkabsURL_2F3_241_2F7_240_2F7_240_2F7_240_6 =
   { module_url, 4, 6 };
Const struct predicate predicate_url_xmkabsURL_2F3_240_5 =
   { module_url, 5, 5 };
Const struct predicate predicate_url_xisAbsURL_3 =
   { module_url, 6, 3 };
Const struct predicate predicate_url_xfromScheme_2 =
   { module_url, 7, 2 };
Const struct predicate predicate_url_xfromScheme_2F2_240_3 =
   { module_url, 8, 3 };
Const struct predicate predicate_url_xfromScheme_2F2_240_2F3_240_2 =
   { module_url, 9, 2 };
Const struct predicate predicate_url_xpartScheme_3 =
   { module_url, 10, 3 };
Const struct predicate predicate_url_xpartScheme1_3 =
   { module_url, 11, 3 };
Const struct predicate predicate_url_xpartURL_5 =
   { module_url, 12, 5 };
Const struct predicate predicate_url_xpartURL1_5 =
   { module_url, 13, 5 };
Const struct predicate predicate_url_xpartURLnetloc_4 =
   { module_url, 14, 4 };
Const struct predicate predicate_url_xpartURLnetloc1_4 =
   { module_url, 15, 4 };
Const struct predicate predicate_url_xpartURLpath_3 =
   { module_url, 16, 3 };
Const struct predicate predicate_url_xfromNetPath_2 =
   { module_url, 17, 2 };
Const struct predicate predicate_url_xfromAbsPath_2 =
   { module_url, 18, 2 };
Const struct predicate predicate_url_xfromFragment_2 =
   { module_url, 19, 2 };
Const struct predicate predicate_url_xcutTail_2 =
   { module_url, 20, 2 };
Const struct predicate predicate_url_xcutTail1_2 =
   { module_url, 21, 2 };
Const struct predicate predicate_url_xnormalizePath_2 =
   { module_url, 22, 2 };
Const struct predicate predicate_url_xpartPath_2 =
   { module_url, 23, 2 };
Const struct predicate predicate_url_xpartPath_3 =
   { module_url, 24, 3 };
Const struct predicate predicate_url_xnormalizePath1_2 =
   { module_url, 25, 2 };
Const struct predicate predicate_url_xnormalizePath2_2 =
   { module_url, 26, 2 };
Const struct predicate predicate_url_xnormalizePath21_3 =
   { module_url, 27, 3 };
Const struct predicate predicate_url_xnormalizePath22_3 =
   { module_url, 28, 3 };
Const struct predicate predicate_url_xappendPath_2 =
   { module_url, 29, 2 };
Const struct predicate predicate_url_xpartNetLoc_3 =
   { module_url, 30, 3 };
Const struct predicate predicate_url_xpartNetLoc_2F3_240_4 =
   { module_url, 31, 4 };
Const struct predicate predicate_url_xencodeQueries_2 =
   { module_url, 32, 2 };
Const struct predicate predicate_url_xencodeQueries1_3 =
   { module_url, 33, 3 };
Const struct predicate predicate_url_xencode_2 =
   { module_url, 34, 2 };
Const struct predicate predicate_url_xencode1_2 =
   { module_url, 35, 2 };
Const struct predicate predicate_url_xencode1_2F2_240_4 =
   { module_url, 36, 4 };
Const struct predicate predicate_url_xencode1_2F2_240_2F4_240_3 =
   { module_url, 37, 3 };
Const struct predicate predicate_url_xtoHexChars_3 =
   { module_url, 38, 3 };
Const struct predicate predicate_url_xtoChar_2 =
   { module_url, 39, 2 };
Const struct predicate predicate_url_xneedEncode_2 =
   { module_url, 40, 2 };
Const struct predicate predicate_url_xrmQuery_2 =
   { module_url, 41, 2 };
Const struct predicate predicate_url_xrmQuery_2F2_240_3 =
   { module_url, 42, 3 };
extern q string_g_new();
extern Const struct predicate predicate_integer__arithmetics_xdivide_3;
extern Const struct predicate predicate_generic_xgeneric_2;
extern Const struct predicate predicate_util_xstrToLst_2;
extern Const struct predicate predicate_util_xstringJoin_2;
extern Const struct predicate predicate_util_xappend_3;
extern Const struct predicate predicate_util_xgetCarCdr_3;
extern Const struct predicate predicate_util_xatoi_2;

module module_url(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_0 =
      declare_string_constant_8(0,0);
  static Const unsigned char strconst_body_1[4] =
    "/";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_1 =
      declare_string_constant_8(strconst_body_1,1);
  static Const unsigned char strconst_body_2[4] =
    ":";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_2 =
      declare_string_constant_8(strconst_body_2,1);
  static Const unsigned char strconst_body_3[4] =
    "://";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_3 =
      declare_string_constant_8(strconst_body_3,3);
  static Const unsigned char strconst_body_4[4] =
    "&";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_4 =
      declare_string_constant_8(strconst_body_4,1);
  static Const q cons_const_5[] = {
    NILATOM,
    makefunctor(&string_const_4),
  };
  static Const q cons_const_6[] = {
    NILATOM,
    makeint(46),
  };
  static Const q cons_const_7[] = {
    makecons(cons_const_6),
    makeint(46),
  };
  static Const q cons_const_8[] = {
    NILATOM,
    NILATOM,
  };
  q a0, a1, a2, a3, a4, a5, a6;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, mkabsURL_3_top);
    case_pred(1, mkabsURL_2F3_241_7_top);
    case_pred(2, mkabsURL_2F3_241_2F7_240_7_top);
    case_pred(3, mkabsURL_2F3_241_2F7_240_2F7_240_7_top);
    case_pred(4, mkabsURL_2F3_241_2F7_240_2F7_240_2F7_240_6_top);
    case_pred(5, mkabsURL_2F3_240_5_top);
    case_pred(6, isAbsURL_3_top);
    case_pred(7, fromScheme_2_top);
    case_pred(8, fromScheme_2F2_240_3_top);
    case_pred(9, fromScheme_2F2_240_2F3_240_2_top);
    case_pred(10, partScheme_3_top);
    case_pred(11, partScheme1_3_top);
    case_pred(12, partURL_5_top);
    case_pred(13, partURL1_5_top);
    case_pred(14, partURLnetloc_4_top);
    case_pred(15, partURLnetloc1_4_top);
    case_pred(16, partURLpath_3_top);
    case_pred(17, fromNetPath_2_top);
    case_pred(18, fromAbsPath_2_top);
    case_pred(19, fromFragment_2_top);
    case_pred(20, cutTail_2_top);
    case_pred(21, cutTail1_2_top);
    case_pred(22, normalizePath_2_top);
    case_pred(23, partPath_2_top);
    case_pred(24, partPath_3_top);
    case_pred(25, normalizePath1_2_top);
    case_pred(26, normalizePath2_2_top);
    case_pred(27, normalizePath21_3_top);
    case_pred(28, normalizePath22_3_top);
    case_pred(29, appendPath_2_top);
    case_pred(30, partNetLoc_3_top);
    case_pred(31, partNetLoc_2F3_240_4_top);
    case_pred(32, encodeQueries_2_top);
    case_pred(33, encodeQueries1_3_top);
    case_pred(34, encode_2_top);
    case_pred(35, encode1_2_top);
    case_pred(36, encode1_2F2_240_4_top);
    case_pred(37, encode1_2F2_240_2F4_240_3_top);
    case_pred(38, toHexChars_3_top);
    case_pred(39, toChar_2_top);
    case_pred(40, needEncode_2_top);
    case_pred(41, rmQuery_2_top);
    last_case_pred(42, rmQuery_2F2_240_3_top);
  }

 mkabsURL_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  qp = qp->next;
 mkabsURL_3_clear_reason:
  reasonp = reasons;
 mkabsURL_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_url_xmkabsURL_2F3_241_7);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a2;
  allocp[4] = a0;
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_url_xisAbsURL_3);
  allocp[11] = x5 = makeref(&allocp[11]);
  allocp[12] = x2;
  allocp[13] = x0;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_url_xmkabsURL_2F3_240_5);
  allocp[16] = x6 = makeref(&allocp[16]);
  allocp[17] = a0;
  allocp[18] = x2;
  allocp[19] = x1;
  allocp[20] = x5;
  allocp[21] = (q)(struct goalrec*)&allocp[14];
  allocp[22] = (q)(&predicate_url_xpartURL_5);
  allocp[23] = a1;
  allocp[24] = x5;
  allocp[25] = x3;
  allocp[26] = x4;
  allocp[27] = x7 = makeref(&allocp[27]);
  a1 = x6;
  qp = (struct goalrec*)&allocp[21];
  allocp += 28;
  execute(fromScheme_2_0);
  goto fromScheme_2_ext_interrupt;
 mkabsURL_3_ext_interrupt:
  reasonp = 0l;
 mkabsURL_3_interrupt:
  goto interrupt_3;
 }

 mkabsURL_2F3_241_7_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 mkabsURL_2F3_241_7_clear_reason:
  reasonp = reasons;
 mkabsURL_2F3_241_7_0:
 mkabsURL_2F3_241_7_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_true)) goto mkabsURL_2F3_241_7_2;
  unify(a1, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,mkabsURL_2F3_241_7_1);
  *reasonp++ =  a0;
  goto mkabsURL_2F3_241_7_2;
  };
  goto mkabsURL_2F3_241_7_2;
 mkabsURL_2F3_241_7_2:
  otherwise(mkabsURL_2F3_241_7_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_url_xmkabsURL_2F3_241_2F7_240_7);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a4;
  allocp[4] = a3;
  allocp[5] = a1;
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_url_xfromNetPath_2);
  allocp[11] = x1;
  allocp[12] = x0;
  allocp[13] = (q)(struct goalrec*)&allocp[9];
  allocp[14] = (q)(&predicate_util_xstrToLst_2);
  allocp[15] = a3;
  allocp[16] = x1;
  qp = (struct goalrec*)&allocp[13];
  allocp += 17;
  proceed();
 mkabsURL_2F3_241_7_ext_interrupt:
  reasonp = 0l;
 mkabsURL_2F3_241_7_interrupt:
  goto interrupt_7;
 }

 mkabsURL_2F3_241_2F7_240_7_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 mkabsURL_2F3_241_2F7_240_7_clear_reason:
  reasonp = reasons;
 mkabsURL_2F3_241_2F7_240_7_0:
 mkabsURL_2F3_241_2F7_240_7_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto mkabsURL_2F3_241_2F7_240_7_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_true)):
  allocp[0] = NILATOM;
  allocp[1] = a2;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = makefunctor(&string_const_2);
  x1 = makecons(&allocp[2]);
  allocp[4] = x1;
  allocp[5] = a1;
  x2 = makecons(&allocp[4]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_util_xstringJoin_2);
  allocp[8] = x2;
  allocp[9] = a3;
  qp = (struct goalrec*)&allocp[6];
  allocp += 10;
  proceed();
 case symval(makesym(atom_false)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_url_xmkabsURL_2F3_241_2F7_240_2F7_240_7);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a5;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a6;
  a0 = a4;
  a1 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 9;
  execute(fromAbsPath_2_0);
  goto fromAbsPath_2_ext_interrupt;
  };
  goto mkabsURL_2F3_241_2F7_240_7_interrupt;
 case VARREF:
  deref_and_jump(a0,mkabsURL_2F3_241_2F7_240_7_1);
  *reasonp++ =  a0;
  goto mkabsURL_2F3_241_2F7_240_7_interrupt;
  };
  goto mkabsURL_2F3_241_2F7_240_7_interrupt;
 mkabsURL_2F3_241_2F7_240_7_ext_interrupt:
  reasonp = 0l;
 mkabsURL_2F3_241_2F7_240_7_interrupt:
  goto interrupt_7;
 }

 mkabsURL_2F3_241_2F7_240_2F7_240_7_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 mkabsURL_2F3_241_2F7_240_2F7_240_7_clear_reason:
  reasonp = reasons;
 mkabsURL_2F3_241_2F7_240_2F7_240_7_0:
 mkabsURL_2F3_241_2F7_240_2F7_240_7_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto mkabsURL_2F3_241_2F7_240_2F7_240_7_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_true)):
  allocp[0] = NILATOM;
  allocp[1] = a3;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a2;
  x1 = makecons(&allocp[2]);
  allocp[4] = x1;
  allocp[5] = makefunctor(&string_const_3);
  x2 = makecons(&allocp[4]);
  allocp[6] = x2;
  allocp[7] = a1;
  x3 = makecons(&allocp[6]);
  allocp[8] = (q)qp;
  allocp[9] = (q)(&predicate_util_xstringJoin_2);
  allocp[10] = x3;
  allocp[11] = a4;
  qp = (struct goalrec*)&allocp[8];
  allocp += 12;
  proceed();
 case symval(makesym(atom_false)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_url_xmkabsURL_2F3_241_2F7_240_2F7_240_2F7_240_6);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a6;
  allocp[6] = a3;
  allocp[7] = a4;
  a0 = a5;
  a1 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  execute(fromFragment_2_0);
  goto fromFragment_2_ext_interrupt;
  };
  goto mkabsURL_2F3_241_2F7_240_2F7_240_7_interrupt;
 case VARREF:
  deref_and_jump(a0,mkabsURL_2F3_241_2F7_240_2F7_240_7_1);
  *reasonp++ =  a0;
  goto mkabsURL_2F3_241_2F7_240_2F7_240_7_interrupt;
  };
  goto mkabsURL_2F3_241_2F7_240_2F7_240_7_interrupt;
 mkabsURL_2F3_241_2F7_240_2F7_240_7_ext_interrupt:
  reasonp = 0l;
 mkabsURL_2F3_241_2F7_240_2F7_240_7_interrupt:
  goto interrupt_7;
 }

 mkabsURL_2F3_241_2F7_240_2F7_240_2F7_240_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 mkabsURL_2F3_241_2F7_240_2F7_240_2F7_240_6_clear_reason:
  reasonp = reasons;
 mkabsURL_2F3_241_2F7_240_2F7_240_2F7_240_6_0:
 mkabsURL_2F3_241_2F7_240_2F7_240_2F7_240_6_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto mkabsURL_2F3_241_2F7_240_2F7_240_2F7_240_6_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_true)):
  allocp[0] = NILATOM;
  allocp[1] = a4;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a3;
  x1 = makecons(&allocp[2]);
  allocp[4] = x1;
  allocp[5] = makefunctor(&string_const_1);
  x2 = makecons(&allocp[4]);
  allocp[6] = x2;
  allocp[7] = a2;
  x3 = makecons(&allocp[6]);
  allocp[8] = x3;
  allocp[9] = makefunctor(&string_const_3);
  x4 = makecons(&allocp[8]);
  allocp[10] = x4;
  allocp[11] = a1;
  x5 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_util_xstringJoin_2);
  allocp[14] = x5;
  allocp[15] = a5;
  qp = (struct goalrec*)&allocp[12];
  allocp += 16;
  proceed();
 case symval(makesym(atom_false)):
  allocp[0] = NILATOM;
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = makefunctor(&string_const_1);
  x2 = makecons(&allocp[2]);
  allocp[4] = x2;
  allocp[5] = a2;
  x3 = makecons(&allocp[4]);
  allocp[6] = x3;
  allocp[7] = makefunctor(&string_const_3);
  x4 = makecons(&allocp[6]);
  allocp[8] = x4;
  allocp[9] = a1;
  x5 = makecons(&allocp[8]);
  allocp[10] = (q)qp;
  allocp[11] = (q)(&predicate_util_xstringJoin_2);
  allocp[12] = x5;
  allocp[13] = a5;
  allocp[14] = (q)(struct goalrec*)&allocp[10];
  allocp[15] = (q)(&predicate_url_xnormalizePath_2);
  allocp[16] = x6 = makeref(&allocp[16]);
  allocp[17] = x1;
  allocp[18] = makesym(functor_join_2);
  allocp[19] = a4;
  allocp[20] = x6;
  x7 = makefunctor(&allocp[18]);
  allocp[21] = (q)(struct goalrec*)&allocp[14];
  allocp[22] = (q)(&predicate_generic_xgeneric_2);
  allocp[23] = x7;
  allocp[24] = x8 = makeref(&allocp[24]);
  a0 = a3;
  a1 = x8;
  qp = (struct goalrec*)&allocp[21];
  allocp += 25;
  execute(cutTail_2_0);
  goto cutTail_2_ext_interrupt;
  };
  goto mkabsURL_2F3_241_2F7_240_2F7_240_2F7_240_6_interrupt;
 case VARREF:
  deref_and_jump(a0,mkabsURL_2F3_241_2F7_240_2F7_240_2F7_240_6_1);
  *reasonp++ =  a0;
  goto mkabsURL_2F3_241_2F7_240_2F7_240_2F7_240_6_interrupt;
  };
  goto mkabsURL_2F3_241_2F7_240_2F7_240_2F7_240_6_interrupt;
 mkabsURL_2F3_241_2F7_240_2F7_240_2F7_240_6_ext_interrupt:
  reasonp = 0l;
 mkabsURL_2F3_241_2F7_240_2F7_240_2F7_240_6_interrupt:
  goto interrupt_6;
 }

 mkabsURL_2F3_240_5_top: {
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 mkabsURL_2F3_240_5_clear_reason:
  reasonp = reasons;
 mkabsURL_2F3_240_5_0:
 mkabsURL_2F3_240_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_true)) goto mkabsURL_2F3_240_5_2;
  a0 = a1;
  a1 = a2;
  a2 = a3;
  execute(partScheme_3_0);
  goto partScheme_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,mkabsURL_2F3_240_5_1);
  *reasonp++ =  a0;
  goto mkabsURL_2F3_240_5_2;
  };
  goto mkabsURL_2F3_240_5_2;
 mkabsURL_2F3_240_5_2:
  otherwise(mkabsURL_2F3_240_5_interrupt);
  unify2(a2, a4, a3, a1);
  proceed();
 mkabsURL_2F3_240_5_ext_interrupt:
  reasonp = 0l;
 mkabsURL_2F3_240_5_interrupt:
  goto interrupt_5;
 }

 isAbsURL_3_top: {
  q x0;
  a2 = qp->args[2];
  qp = qp->next;
 isAbsURL_3_clear_reason:
  reasonp = reasons;
 isAbsURL_3_0:
 isAbsURL_3_1:
  if (isref(a0)) goto isAbsURL_3_4;
 isAbsURL_3_2:
  if (isref(a0)) goto isAbsURL_3_3;
  if_not_equal(a0, a1, isAbsURL_3_5);
  x0 = makesym(atom_false);
  unify_value(a2, x0);
  proceed();
 isAbsURL_3_3:
  deref_and_jump(a0,isAbsURL_3_2);
  *reasonp++ =  a0;
  goto isAbsURL_3_5;
 isAbsURL_3_4:
  deref_and_jump(a0,isAbsURL_3_1);
  *reasonp++ =  a0;
  goto isAbsURL_3_5;
 isAbsURL_3_5:
  otherwise(isAbsURL_3_interrupt);
  x0 = makesym(atom_true);
  unify_value(a2, x0);
  proceed();
 isAbsURL_3_ext_interrupt:
  reasonp = 0l;
 isAbsURL_3_interrupt:
  goto interrupt_3;
 }

 fromScheme_2_top: {
  q x0, x1;
  qp = qp->next;
 fromScheme_2_clear_reason:
  reasonp = reasons;
 fromScheme_2_0:
 fromScheme_2_1:
  if (isref(a0)) goto fromScheme_2_4;
 fromScheme_2_2:
  if (isref(a0)) goto fromScheme_2_3;
  x0 = makefunctor(&string_const_0);
  if_not_equal(a0, x0, fromScheme_2_5);
  x1 = makesym(atom_false);
  unify_value(a1, x1);
  proceed();
 fromScheme_2_3:
  deref_and_jump(a0,fromScheme_2_2);
  *reasonp++ =  a0;
  goto fromScheme_2_5;
 fromScheme_2_4:
  deref_and_jump(a0,fromScheme_2_1);
  *reasonp++ =  a0;
  goto fromScheme_2_5;
 fromScheme_2_5:
  otherwise(fromScheme_2_interrupt);
  x0 = makeint(0L);
  generic_arg[0] = x0;
  allocp[0] = x1 = makeref(&allocp[0]);
  generic_arg[1] = x1;
  call_generic(a0, functor_element_2, 1);
  a2 = a0;
  a0 = x1;
  execute(fromScheme_2F2_240_3_0);
  goto fromScheme_2F2_240_3_ext_interrupt;
 fromScheme_2_ext_interrupt:
  reasonp = 0l;
 fromScheme_2_interrupt:
  toppred = &predicate_url_xfromScheme_2;
  goto interrupt_2;
 }

 fromScheme_2F2_240_3_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  qp = qp->next;
 fromScheme_2F2_240_3_clear_reason:
  reasonp = reasons;
 fromScheme_2F2_240_3_0:
 fromScheme_2F2_240_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 fromScheme_2F2_240_3_2:
  if (a0 != makeint(47L)) goto fromScheme_2F2_240_3_3;
  x0 = makesym(atom_false);
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,fromScheme_2F2_240_3_1);
  *reasonp++ =  a0;
  goto fromScheme_2F2_240_3_3;
  };
  goto fromScheme_2F2_240_3_3;
 fromScheme_2F2_240_3_3:
  otherwise(fromScheme_2F2_240_3_interrupt);
  allocp[0] = x0 = makeref(&allocp[0]);
  generic_arg[0] = x0;
  call_generic(a2, functor_size_1, 1);
  x1 = makeint(1L);
  bblt_sub_no_check_y(x0,x1,x2);
  x3 = makeint(0L);
  generic_arg[0] = x3;
  generic_arg[1] = x2;
  x4 = makeint(58L);
  generic_arg[2] = x4;
  allocp[0] = x5 = makeref(&allocp[0]);
  generic_arg[3] = x5;
  call_generic(a2, functor_search__character_4, 1);
  a0 = x5;
  execute(fromScheme_2F2_240_2F3_240_2_0);
  goto fromScheme_2F2_240_2F3_240_2_ext_interrupt;
 fromScheme_2F2_240_3_ext_interrupt:
  reasonp = 0l;
 fromScheme_2F2_240_3_interrupt:
  toppred = &predicate_url_xfromScheme_2F2_240_3;
  goto interrupt_3;
 }

 fromScheme_2F2_240_2F3_240_2_top: {
  q x0;
  qp = qp->next;
 fromScheme_2F2_240_2F3_240_2_clear_reason:
  reasonp = reasons;
 fromScheme_2F2_240_2F3_240_2_0:
 fromScheme_2F2_240_2F3_240_2_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 fromScheme_2F2_240_2F3_240_2_2:
  if (a0 != makeint(-1L)) goto fromScheme_2F2_240_2F3_240_2_3;
  x0 = makesym(atom_false);
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,fromScheme_2F2_240_2F3_240_2_1);
  *reasonp++ =  a0;
  goto fromScheme_2F2_240_2F3_240_2_3;
  };
  goto fromScheme_2F2_240_2F3_240_2_3;
 fromScheme_2F2_240_2F3_240_2_3:
  otherwise(fromScheme_2F2_240_2F3_240_2_interrupt);
  x0 = makesym(atom_true);
  unify_value(a1, x0);
  proceed();
 fromScheme_2F2_240_2F3_240_2_ext_interrupt:
  reasonp = 0l;
 fromScheme_2F2_240_2F3_240_2_interrupt:
  toppred = &predicate_url_xfromScheme_2F2_240_2F3_240_2;
  goto interrupt_2;
 }

 partScheme_3_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  qp = qp->next;
 partScheme_3_clear_reason:
  reasonp = reasons;
 partScheme_3_0:
  allocp[0] = x0 = makeref(&allocp[0]);
  generic_arg[0] = x0;
  x1 = makeint(8L);
  generic_arg[1] = x1;
  new_generic(string_g_new, 2, x2, 1);
  unify(a2, x2);
  allocp[0] = x3 = makeref(&allocp[0]);
  generic_arg[0] = x3;
  x4 = makeint(8L);
  generic_arg[1] = x4;
  new_generic(string_g_new, 2, x5, 1);
  unify(a1, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_url_xpartScheme1_3);
  allocp[2] = x6 = makeref(&allocp[2]);
  allocp[3] = x3;
  allocp[4] = x0;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_util_xstrToLst_2);
  allocp[7] = a0;
  allocp[8] = x6;
  qp = (struct goalrec*)&allocp[5];
  allocp += 9;
  proceed();
 partScheme_3_ext_interrupt:
  reasonp = 0l;
 partScheme_3_interrupt:
  toppred = &predicate_url_xpartScheme_3;
  goto interrupt_3;
 }

 partScheme1_3_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  qp = qp->next;
 partScheme1_3_clear_reason:
  reasonp = reasons;
 partScheme1_3_0:
 partScheme1_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 partScheme1_3_2:
  switch (ptagof(x0)) {
 case ATOMIC:
 partScheme1_3_3:
  if (x0 != makeint(58L)) goto partScheme1_3_4;
  x1 = NILATOM;
  unify_value(a1, x1);
  x2 = cdr_of(a0);
  unify(a2, x2);
  proceed();
 case VARREF:
  deref_and_jump(x0,partScheme1_3_2);
  *reasonp++ =  x0;
  goto partScheme1_3_4;
  };
  goto partScheme1_3_4;
 case VARREF:
  deref_and_jump(a0,partScheme1_3_1);
  *reasonp++ =  a0;
  goto partScheme1_3_4;
  };
  goto partScheme1_3_4;
 partScheme1_3_4:
  otherwise(partScheme1_3_interrupt);
 partScheme1_3_5:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(partScheme1_3_0);
  goto partScheme1_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto partScheme1_3_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  x1 = NILATOM;
  unify_value(a2, x1);
  proceed();
 case VARREF:
  deref_and_jump(a0,partScheme1_3_5);
  *reasonp++ =  a0;
  goto partScheme1_3_interrupt;
  };
  goto partScheme1_3_interrupt;
 partScheme1_3_ext_interrupt:
  reasonp = 0l;
 partScheme1_3_interrupt:
  goto interrupt_3;
 }

 partURL_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 partURL_5_clear_reason:
  reasonp = reasons;
 partURL_5_0:
  allocp[0] = x0 = makeref(&allocp[0]);
  generic_arg[0] = x0;
  x1 = makeint(8L);
  generic_arg[1] = x1;
  new_generic(string_g_new, 2, x2, 1);
  unify(a4, x2);
  allocp[0] = x3 = makeref(&allocp[0]);
  generic_arg[0] = x3;
  x4 = makeint(8L);
  generic_arg[1] = x4;
  new_generic(string_g_new, 2, x5, 1);
  unify(a3, x5);
  allocp[0] = x6 = makeref(&allocp[0]);
  generic_arg[0] = x6;
  x7 = makeint(8L);
  generic_arg[1] = x7;
  new_generic(string_g_new, 2, x8, 1);
  unify(a2, x8);
  allocp[0] = x9 = makeref(&allocp[0]);
  generic_arg[0] = x9;
  x10 = makeint(8L);
  generic_arg[1] = x10;
  new_generic(string_g_new, 2, x11, 1);
  unify(a1, x11);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_url_xpartURL1_5);
  allocp[2] = x12 = makeref(&allocp[2]);
  allocp[3] = x9;
  allocp[4] = x6;
  allocp[5] = x3;
  allocp[6] = x0;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_util_xstrToLst_2);
  allocp[9] = a0;
  allocp[10] = x12;
  qp = (struct goalrec*)&allocp[7];
  allocp += 11;
  proceed();
 partURL_5_ext_interrupt:
  reasonp = 0l;
 partURL_5_interrupt:
  goto interrupt_5;
 }

 partURL1_5_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 partURL1_5_clear_reason:
  reasonp = reasons;
 partURL1_5_0:
 partURL1_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 partURL1_5_2:
  switch (ptagof(x0)) {
 case ATOMIC:
 partURL1_5_3:
  if (x0 != makeint(58L)) goto partURL1_5_4;
  x1 = NILATOM;
  unify_value(a1, x1);
  a0 = cdr_of(a0);
  a1 = a2;
  a2 = a3;
  a3 = a4;
  execute(partURLnetloc_4_0);
  goto partURLnetloc_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,partURL1_5_2);
  *reasonp++ =  x0;
  goto partURL1_5_4;
  };
  goto partURL1_5_4;
 case VARREF:
  deref_and_jump(a0,partURL1_5_1);
  *reasonp++ =  a0;
  goto partURL1_5_4;
  };
  goto partURL1_5_4;
 partURL1_5_4:
  otherwise(partURL1_5_interrupt);
 partURL1_5_5:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(partURL1_5_0);
  goto partURL1_5_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto partURL1_5_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  x1 = NILATOM;
  unify_value(a2, x1);
  x2 = NILATOM;
  unify_value(a3, x2);
  x3 = NILATOM;
  unify_value(a4, x3);
  proceed();
 case VARREF:
  deref_and_jump(a0,partURL1_5_5);
  *reasonp++ =  a0;
  goto partURL1_5_interrupt;
  };
  goto partURL1_5_interrupt;
 partURL1_5_ext_interrupt:
  reasonp = 0l;
 partURL1_5_interrupt:
  goto interrupt_5;
 }

 partURLnetloc_4_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 partURLnetloc_4_clear_reason:
  reasonp = reasons;
 partURLnetloc_4_0:
 partURLnetloc_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 partURLnetloc_4_2:
  switch (ptagof(x0)) {
 case ATOMIC:
 partURLnetloc_4_3:
  if (x0 != makeint(47L)) goto partURLnetloc_4_7;
  x1 = cdr_of(a0);
 partURLnetloc_4_4:
  switch (ptagof(x1)) {
 case CONS:
  x2 = car_of(x1);
 partURLnetloc_4_5:
  switch (ptagof(x2)) {
 case ATOMIC:
 partURLnetloc_4_6:
  if (x2 != makeint(47L)) goto partURLnetloc_4_7;
  a0 = cdr_of(x1);
  execute(partURLnetloc1_4_0);
  goto partURLnetloc1_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x2,partURLnetloc_4_5);
  *reasonp++ =  x2;
  goto partURLnetloc_4_7;
  };
  goto partURLnetloc_4_7;
 case VARREF:
  deref_and_jump(x1,partURLnetloc_4_4);
  *reasonp++ =  x1;
  goto partURLnetloc_4_7;
  };
  goto partURLnetloc_4_7;
 case VARREF:
  deref_and_jump(x0,partURLnetloc_4_2);
  *reasonp++ =  x0;
  goto partURLnetloc_4_7;
  };
  goto partURLnetloc_4_7;
 case VARREF:
  deref_and_jump(a0,partURLnetloc_4_1);
  *reasonp++ =  a0;
  goto partURLnetloc_4_7;
  };
  goto partURLnetloc_4_7;
 partURLnetloc_4_7:
  otherwise(partURLnetloc_4_interrupt);
 partURLnetloc_4_8:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 partURLnetloc_4_9:
  switch (ptagof(x0)) {
 case ATOMIC:
 partURLnetloc_4_10:
  if (x0 != makeint(47L)) goto partURLnetloc_4_11;
  x1 = NILATOM;
  unify_value(a1, x1);
  a0 = cdr_of(a0);
  a1 = a2;
  a2 = a3;
  execute(partURLpath_3_0);
  goto partURLpath_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,partURLnetloc_4_9);
  *reasonp++ =  x0;
  goto partURLnetloc_4_11;
  };
  goto partURLnetloc_4_11;
 case VARREF:
  deref_and_jump(a0,partURLnetloc_4_8);
  *reasonp++ =  a0;
  goto partURLnetloc_4_11;
  };
  goto partURLnetloc_4_11;
 partURLnetloc_4_11:
  otherwise(partURLnetloc_4_interrupt);
 partURLnetloc_4_12:
  switch (ptagof(a0)) {
 case CONS:
  x1 = cdr_of(a0);
  allocp[0] = x1;
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  a0 = x0;
  allocp += 2;
  execute(partURLnetloc1_4_0);
  goto partURLnetloc1_4_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto partURLnetloc_4_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  x1 = NILATOM;
  unify_value(a2, x1);
  x2 = NILATOM;
  unify_value(a3, x2);
  proceed();
 case VARREF:
  deref_and_jump(a0,partURLnetloc_4_12);
  *reasonp++ =  a0;
  goto partURLnetloc_4_interrupt;
  };
  goto partURLnetloc_4_interrupt;
 partURLnetloc_4_ext_interrupt:
  reasonp = 0l;
 partURLnetloc_4_interrupt:
  toppred = &predicate_url_xpartURLnetloc_4;
  goto interrupt_4;
 }

 partURLnetloc1_4_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 partURLnetloc1_4_clear_reason:
  reasonp = reasons;
 partURLnetloc1_4_0:
 partURLnetloc1_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 partURLnetloc1_4_2:
  switch (ptagof(x0)) {
 case ATOMIC:
 partURLnetloc1_4_3:
  if (x0 != makeint(47L)) goto partURLnetloc1_4_4;
  x1 = NILATOM;
  unify_value(a1, x1);
  a0 = cdr_of(a0);
  a1 = a2;
  a2 = a3;
  execute(partURLpath_3_0);
  goto partURLpath_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,partURLnetloc1_4_2);
  *reasonp++ =  x0;
  goto partURLnetloc1_4_4;
  };
  goto partURLnetloc1_4_4;
 case VARREF:
  deref_and_jump(a0,partURLnetloc1_4_1);
  *reasonp++ =  a0;
  goto partURLnetloc1_4_4;
  };
  goto partURLnetloc1_4_4;
 partURLnetloc1_4_4:
  otherwise(partURLnetloc1_4_interrupt);
 partURLnetloc1_4_5:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(partURLnetloc1_4_0);
  goto partURLnetloc1_4_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto partURLnetloc1_4_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  x1 = NILATOM;
  unify_value(a2, x1);
  x2 = NILATOM;
  unify_value(a3, x2);
  proceed();
 case VARREF:
  deref_and_jump(a0,partURLnetloc1_4_5);
  *reasonp++ =  a0;
  goto partURLnetloc1_4_interrupt;
  };
  goto partURLnetloc1_4_interrupt;
 partURLnetloc1_4_ext_interrupt:
  reasonp = 0l;
 partURLnetloc1_4_interrupt:
  toppred = &predicate_url_xpartURLnetloc1_4;
  goto interrupt_4;
 }

 partURLpath_3_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  qp = qp->next;
 partURLpath_3_clear_reason:
  reasonp = reasons;
 partURLpath_3_0:
 partURLpath_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 partURLpath_3_2:
  switch (ptagof(x0)) {
 case ATOMIC:
 partURLpath_3_3:
  if (x0 != makeint(35L)) goto partURLpath_3_4;
  x1 = NILATOM;
  unify_value(a1, x1);
  x2 = cdr_of(a0);
  unify(a2, x2);
  proceed();
 case VARREF:
  deref_and_jump(x0,partURLpath_3_2);
  *reasonp++ =  x0;
  goto partURLpath_3_4;
  };
  goto partURLpath_3_4;
 case VARREF:
  deref_and_jump(a0,partURLpath_3_1);
  *reasonp++ =  a0;
  goto partURLpath_3_4;
  };
  goto partURLpath_3_4;
 partURLpath_3_4:
  otherwise(partURLpath_3_interrupt);
 partURLpath_3_5:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(partURLpath_3_0);
  goto partURLpath_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto partURLpath_3_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  x1 = NILATOM;
  unify_value(a2, x1);
  proceed();
 case VARREF:
  deref_and_jump(a0,partURLpath_3_5);
  *reasonp++ =  a0;
  goto partURLpath_3_interrupt;
  };
  goto partURLpath_3_interrupt;
 partURLpath_3_ext_interrupt:
  reasonp = 0l;
 partURLpath_3_interrupt:
  toppred = &predicate_url_xpartURLpath_3;
  goto interrupt_3;
 }

 fromNetPath_2_top: {
  q x0, x1, x2, x3;
  qp = qp->next;
 fromNetPath_2_clear_reason:
  reasonp = reasons;
 fromNetPath_2_0:
 fromNetPath_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 fromNetPath_2_2:
  switch (ptagof(x0)) {
 case ATOMIC:
 fromNetPath_2_3:
  if (x0 != makeint(47L)) goto fromNetPath_2_7;
  x1 = cdr_of(a0);
 fromNetPath_2_4:
  switch (ptagof(x1)) {
 case CONS:
  x2 = car_of(x1);
 fromNetPath_2_5:
  switch (ptagof(x2)) {
 case ATOMIC:
 fromNetPath_2_6:
  if (x2 != makeint(47L)) goto fromNetPath_2_7;
  x3 = makesym(atom_true);
  unify_value(a1, x3);
  proceed();
 case VARREF:
  deref_and_jump(x2,fromNetPath_2_5);
  *reasonp++ =  x2;
  goto fromNetPath_2_7;
  };
  goto fromNetPath_2_7;
 case VARREF:
  deref_and_jump(x1,fromNetPath_2_4);
  *reasonp++ =  x1;
  goto fromNetPath_2_7;
  };
  goto fromNetPath_2_7;
 case VARREF:
  deref_and_jump(x0,fromNetPath_2_2);
  *reasonp++ =  x0;
  goto fromNetPath_2_7;
  };
  goto fromNetPath_2_7;
 case VARREF:
  deref_and_jump(a0,fromNetPath_2_1);
  *reasonp++ =  a0;
  goto fromNetPath_2_7;
  };
  goto fromNetPath_2_7;
 fromNetPath_2_7:
  otherwise(fromNetPath_2_interrupt);
  x0 = makesym(atom_false);
  unify_value(a1, x0);
  proceed();
 fromNetPath_2_ext_interrupt:
  reasonp = 0l;
 fromNetPath_2_interrupt:
  goto interrupt_2;
 }

 fromAbsPath_2_top: {
  q x0, x1;
  qp = qp->next;
 fromAbsPath_2_clear_reason:
  reasonp = reasons;
 fromAbsPath_2_0:
 fromAbsPath_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 fromAbsPath_2_2:
  switch (ptagof(x0)) {
 case ATOMIC:
 fromAbsPath_2_3:
  if (x0 != makeint(47L)) goto fromAbsPath_2_4;
  x1 = makesym(atom_true);
  unify_value(a1, x1);
  proceed();
 case VARREF:
  deref_and_jump(x0,fromAbsPath_2_2);
  *reasonp++ =  x0;
  goto fromAbsPath_2_4;
  };
  goto fromAbsPath_2_4;
 case VARREF:
  deref_and_jump(a0,fromAbsPath_2_1);
  *reasonp++ =  a0;
  goto fromAbsPath_2_4;
  };
  goto fromAbsPath_2_4;
 fromAbsPath_2_4:
  otherwise(fromAbsPath_2_interrupt);
  x0 = makesym(atom_false);
  unify_value(a1, x0);
  proceed();
 fromAbsPath_2_ext_interrupt:
  reasonp = 0l;
 fromAbsPath_2_interrupt:
  toppred = &predicate_url_xfromAbsPath_2;
  goto interrupt_2;
 }

 fromFragment_2_top: {
  q x0, x1;
  qp = qp->next;
 fromFragment_2_clear_reason:
  reasonp = reasons;
 fromFragment_2_0:
 fromFragment_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 fromFragment_2_2:
  switch (ptagof(x0)) {
 case ATOMIC:
 fromFragment_2_3:
  if (x0 != makeint(35L)) goto fromFragment_2_4;
  x1 = makesym(atom_true);
  unify_value(a1, x1);
  proceed();
 case VARREF:
  deref_and_jump(x0,fromFragment_2_2);
  *reasonp++ =  x0;
  goto fromFragment_2_4;
  };
  goto fromFragment_2_4;
 case VARREF:
  deref_and_jump(a0,fromFragment_2_1);
  *reasonp++ =  a0;
  goto fromFragment_2_4;
  };
  goto fromFragment_2_4;
 fromFragment_2_4:
  otherwise(fromFragment_2_interrupt);
  x0 = makesym(atom_false);
  unify_value(a1, x0);
  proceed();
 fromFragment_2_ext_interrupt:
  reasonp = 0l;
 fromFragment_2_interrupt:
  toppred = &predicate_url_xfromFragment_2;
  goto interrupt_2;
 }

 cutTail_2_top: {
  q x0, x1, x2, x3, x4, x5;
  qp = qp->next;
 cutTail_2_clear_reason:
  reasonp = reasons;
 cutTail_2_0:
  allocp[0] = x0 = makeref(&allocp[0]);
  generic_arg[0] = x0;
  x1 = makeint(8L);
  generic_arg[1] = x1;
  new_generic(string_g_new, 2, x2, 1);
  unify(a1, x2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_url_xappendPath_2);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = x0;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_url_xcutTail1_2);
  allocp[6] = x4 = makeref(&allocp[6]);
  allocp[7] = x3;
  allocp[8] = (q)(struct goalrec*)&allocp[4];
  allocp[9] = (q)(&predicate_url_xpartPath_2);
  allocp[10] = x5 = makeref(&allocp[10]);
  allocp[11] = x4;
  allocp[12] = (q)(struct goalrec*)&allocp[8];
  allocp[13] = (q)(&predicate_util_xstrToLst_2);
  allocp[14] = a0;
  allocp[15] = x5;
  qp = (struct goalrec*)&allocp[12];
  allocp += 16;
  proceed();
 cutTail_2_ext_interrupt:
  reasonp = 0l;
 cutTail_2_interrupt:
  toppred = &predicate_url_xcutTail_2;
  goto interrupt_2;
 }

 cutTail1_2_top: {
  q x0, x1, x2;
  qp = qp->next;
 cutTail1_2_clear_reason:
  reasonp = reasons;
 cutTail1_2_0:
 cutTail1_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = cdr_of(a0);
 cutTail1_2_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != NILATOM) goto cutTail1_2_3;
  x1 = makecons(cons_const_8);
  unify_value(a1, x1);
  proceed();
 case VARREF:
  deref_and_jump(x0,cutTail1_2_2);
  *reasonp++ =  x0;
  goto cutTail1_2_3;
  };
  goto cutTail1_2_3;
 case VARREF:
  deref_and_jump(a0,cutTail1_2_1);
  *reasonp++ =  a0;
  goto cutTail1_2_3;
  };
  goto cutTail1_2_3;
 cutTail1_2_3:
  otherwise(cutTail1_2_interrupt);
 cutTail1_2_4:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(cutTail1_2_0);
  goto cutTail1_2_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,cutTail1_2_4);
  *reasonp++ =  a0;
  goto cutTail1_2_interrupt;
  };
  goto cutTail1_2_interrupt;
 cutTail1_2_ext_interrupt:
  reasonp = 0l;
 cutTail1_2_interrupt:
  goto interrupt_2;
 }

 normalizePath_2_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  qp = qp->next;
 normalizePath_2_clear_reason:
  reasonp = reasons;
 normalizePath_2_0:
  allocp[0] = x0 = makeref(&allocp[0]);
  generic_arg[0] = x0;
  x1 = makeint(8L);
  generic_arg[1] = x1;
  new_generic(string_g_new, 2, x2, 1);
  unify(a1, x2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_url_xappendPath_2);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = x0;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_url_xnormalizePath2_2);
  allocp[6] = x4 = makeref(&allocp[6]);
  allocp[7] = x3;
  allocp[8] = (q)(struct goalrec*)&allocp[4];
  allocp[9] = (q)(&predicate_url_xnormalizePath1_2);
  allocp[10] = x5 = makeref(&allocp[10]);
  allocp[11] = x4;
  allocp[12] = (q)(struct goalrec*)&allocp[8];
  allocp[13] = (q)(&predicate_url_xpartPath_2);
  allocp[14] = x6 = makeref(&allocp[14]);
  allocp[15] = x5;
  allocp[16] = (q)(struct goalrec*)&allocp[12];
  allocp[17] = (q)(&predicate_util_xstrToLst_2);
  allocp[18] = a0;
  allocp[19] = x6;
  qp = (struct goalrec*)&allocp[16];
  allocp += 20;
  proceed();
 normalizePath_2_ext_interrupt:
  reasonp = 0l;
 normalizePath_2_interrupt:
  goto interrupt_2;
 }

 partPath_2_top: {
  q x0, x1;
  qp = qp->next;
 partPath_2_clear_reason:
  reasonp = reasons;
 partPath_2_0:
  allocp[0] = makesym(functor__2D_2);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x1;
  x0 = makefunctor(&allocp[0]);
  a2 = a1;
  a1 = x0;
  allocp += 3;
  execute(partPath_3_0);
  goto partPath_3_ext_interrupt;
 partPath_2_ext_interrupt:
  reasonp = 0l;
 partPath_2_interrupt:
  goto interrupt_2;
 }

 partPath_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  qp = qp->next;
 partPath_3_clear_reason:
  reasonp = reasons;
 partPath_3_0:
 partPath_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 partPath_3_2:
  switch (ptagof(x0)) {
 case ATOMIC:
 partPath_3_3:
  if (x0 != makeint(47L)) goto partPath_3_5;
 partPath_3_4:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor__2D_2)) goto partPath_3_5;
  x1 = arg(a1, 1);
  x2 = NILATOM;
  unify_value(x1, x2);
  allocp[0] = x4 = makeref(&allocp[0]);
  x5 = arg(a1, 0);
  allocp[1] = x5;
  x3 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x3);
  allocp[0] = makesym(functor__2D_2);
  allocp[1] = x7 = makeref(&allocp[1]);
  allocp[2] = x7;
  x6 = makefunctor(&allocp[0]);
  a0 = cdr_of(a0);
  a1 = x6;
  a2 = x4;
  allocp += 3;
  execute(partPath_3_0);
  goto partPath_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,partPath_3_4);
  *reasonp++ =  a1;
  goto partPath_3_5;
  };
  goto partPath_3_5;
 case VARREF:
  deref_and_jump(x0,partPath_3_2);
  *reasonp++ =  x0;
  goto partPath_3_5;
  };
  goto partPath_3_5;
 case VARREF:
  deref_and_jump(a0,partPath_3_1);
  *reasonp++ =  a0;
  goto partPath_3_5;
  };
  goto partPath_3_5;
 partPath_3_5:
  otherwise(partPath_3_interrupt);
 partPath_3_6:
  switch (ptagof(a0)) {
 case CONS:
 partPath_3_7:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor__2D_2)) goto partPath_3_interrupt;
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  x3 = arg(a1, 1);
  allocp += 2;
  unify_value(x3, x0);
  allocp[0] = makesym(functor__2D_2);
  x5 = arg(a1, 0);
  allocp[1] = x5;
  allocp[2] = x1;
  x4 = makefunctor(&allocp[0]);
  a0 = cdr_of(a0);
  a1 = x4;
  allocp += 3;
  execute(partPath_3_0);
  goto partPath_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,partPath_3_7);
  *reasonp++ =  a1;
  goto partPath_3_interrupt;
  };
  goto partPath_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto partPath_3_interrupt;
 partPath_3_8:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor__2D_2)) goto partPath_3_interrupt;
  x0 = arg(a1, 1);
  x1 = NILATOM;
  unify_value(x0, x1);
  allocp[0] = NILATOM;
  x3 = arg(a1, 0);
  allocp[1] = x3;
  x2 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x2);
  proceed();
 case VARREF:
  deref_and_jump(a1,partPath_3_8);
  *reasonp++ =  a1;
  goto partPath_3_interrupt;
  };
  goto partPath_3_interrupt;
 case VARREF:
  deref_and_jump(a0,partPath_3_6);
  *reasonp++ =  a0;
  goto partPath_3_interrupt;
  };
  goto partPath_3_interrupt;
 partPath_3_ext_interrupt:
  reasonp = 0l;
 partPath_3_interrupt:
  toppred = &predicate_url_xpartPath_3;
  goto interrupt_3;
 }

 normalizePath1_2_top: {
  q x0, x1, x2;
  qp = qp->next;
 normalizePath1_2_clear_reason:
  reasonp = reasons;
 normalizePath1_2_0:
 normalizePath1_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 normalizePath1_2_2:
  switch (ptagof(x0)) {
 case CONS:
  x1 = car_of(x0);
 normalizePath1_2_3:
  switch (ptagof(x1)) {
 case ATOMIC:
 normalizePath1_2_4:
  if (x1 != makeint(46L)) goto normalizePath1_2_6;
  x2 = cdr_of(x0);
 normalizePath1_2_5:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != NILATOM) goto normalizePath1_2_6;
  a0 = cdr_of(a0);
  execute(normalizePath1_2_0);
  goto normalizePath1_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x2,normalizePath1_2_5);
  *reasonp++ =  x2;
  goto normalizePath1_2_6;
  };
  goto normalizePath1_2_6;
 case VARREF:
  deref_and_jump(x1,normalizePath1_2_3);
  *reasonp++ =  x1;
  goto normalizePath1_2_6;
  };
  goto normalizePath1_2_6;
 case VARREF:
  deref_and_jump(x0,normalizePath1_2_2);
  *reasonp++ =  x0;
  goto normalizePath1_2_6;
  };
  goto normalizePath1_2_6;
 case VARREF:
  deref_and_jump(a0,normalizePath1_2_1);
  *reasonp++ =  a0;
  goto normalizePath1_2_6;
  };
  goto normalizePath1_2_6;
 normalizePath1_2_6:
  otherwise(normalizePath1_2_interrupt);
 normalizePath1_2_7:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(normalizePath1_2_0);
  goto normalizePath1_2_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto normalizePath1_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,normalizePath1_2_7);
  *reasonp++ =  a0;
  goto normalizePath1_2_interrupt;
  };
  goto normalizePath1_2_interrupt;
 normalizePath1_2_ext_interrupt:
  reasonp = 0l;
 normalizePath1_2_interrupt:
  goto interrupt_2;
 }

 normalizePath2_2_top: {
  qp = qp->next;
 normalizePath2_2_clear_reason:
  reasonp = reasons;
 normalizePath2_2_0:
  a2 = a1;
  a1 = NILATOM;
  execute(normalizePath21_3_0);
  goto normalizePath21_3_ext_interrupt;
 normalizePath2_2_ext_interrupt:
  reasonp = 0l;
 normalizePath2_2_interrupt:
  goto interrupt_2;
 }

 normalizePath21_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  a2 = qp->args[2];
  qp = qp->next;
 normalizePath21_3_clear_reason:
  reasonp = reasons;
 normalizePath21_3_0:
 normalizePath21_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 normalizePath21_3_2:
  switch (ptagof(x0)) {
 case CONS:
  x1 = car_of(x0);
 normalizePath21_3_3:
  switch (ptagof(x1)) {
 case ATOMIC:
 normalizePath21_3_4:
  if (x1 != makeint(46L)) goto normalizePath21_3_17;
  x2 = cdr_of(x0);
 normalizePath21_3_5:
  switch (ptagof(x2)) {
 case CONS:
  x3 = car_of(x2);
 normalizePath21_3_6:
  switch (ptagof(x3)) {
 case ATOMIC:
 normalizePath21_3_7:
  if (x3 != makeint(46L)) goto normalizePath21_3_17;
  x4 = cdr_of(x2);
 normalizePath21_3_8:
  switch (ptagof(x4)) {
 case ATOMIC:
  if (x4 != NILATOM) goto normalizePath21_3_17;
 normalizePath21_3_9:
  switch (ptagof(a1)) {
 case CONS:
  x5 = car_of(a1);
 normalizePath21_3_10:
  switch (ptagof(x5)) {
 case CONS:
  x6 = car_of(x5);
 normalizePath21_3_11:
  switch (ptagof(x6)) {
 case ATOMIC:
 normalizePath21_3_12:
  if (x6 != makeint(46L)) goto normalizePath21_3_17;
  x7 = cdr_of(x5);
 normalizePath21_3_13:
  switch (ptagof(x7)) {
 case CONS:
  x8 = car_of(x7);
 normalizePath21_3_14:
  switch (ptagof(x8)) {
 case ATOMIC:
 normalizePath21_3_15:
  if (x8 != makeint(46L)) goto normalizePath21_3_17;
  x9 = cdr_of(x7);
 normalizePath21_3_16:
  switch (ptagof(x9)) {
 case ATOMIC:
  if (x9 != NILATOM) goto normalizePath21_3_17;
  x11 = cdr_of(a1);
  allocp[0] = x11;
  allocp[1] = makecons(cons_const_7);
  x10 = makecons(&allocp[0]);
  allocp[2] = x10;
  allocp[3] = makecons(cons_const_7);
  x12 = makecons(&allocp[2]);
  a0 = cdr_of(a0);
  a1 = x12;
  allocp += 4;
  execute(normalizePath21_3_0);
  goto normalizePath21_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x9,normalizePath21_3_16);
  *reasonp++ =  x9;
  goto normalizePath21_3_17;
  };
  goto normalizePath21_3_17;
 case VARREF:
  deref_and_jump(x8,normalizePath21_3_14);
  *reasonp++ =  x8;
  goto normalizePath21_3_17;
  };
  goto normalizePath21_3_17;
 case VARREF:
  deref_and_jump(x7,normalizePath21_3_13);
  *reasonp++ =  x7;
  goto normalizePath21_3_17;
  };
  goto normalizePath21_3_17;
 case VARREF:
  deref_and_jump(x6,normalizePath21_3_11);
  *reasonp++ =  x6;
  goto normalizePath21_3_17;
  };
  goto normalizePath21_3_17;
 case ATOMIC:
  if (x5 != NILATOM) goto normalizePath21_3_17;
  x7 = cdr_of(a1);
  allocp[0] = x7;
  allocp[1] = NILATOM;
  x6 = makecons(&allocp[0]);
  allocp[2] = x6;
  allocp[3] = makecons(cons_const_7);
  x8 = makecons(&allocp[2]);
  a0 = cdr_of(a0);
  a1 = x8;
  allocp += 4;
  execute(normalizePath21_3_0);
  goto normalizePath21_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x5,normalizePath21_3_10);
  *reasonp++ =  x5;
  goto normalizePath21_3_17;
  };
  goto normalizePath21_3_17;
 case VARREF:
  deref_and_jump(a1,normalizePath21_3_9);
  *reasonp++ =  a1;
  goto normalizePath21_3_17;
  };
  goto normalizePath21_3_17;
 case VARREF:
  deref_and_jump(x4,normalizePath21_3_8);
  *reasonp++ =  x4;
  goto normalizePath21_3_17;
  };
  goto normalizePath21_3_17;
 case VARREF:
  deref_and_jump(x3,normalizePath21_3_6);
  *reasonp++ =  x3;
  goto normalizePath21_3_17;
  };
  goto normalizePath21_3_17;
 case VARREF:
  deref_and_jump(x2,normalizePath21_3_5);
  *reasonp++ =  x2;
  goto normalizePath21_3_17;
  };
  goto normalizePath21_3_17;
 case VARREF:
  deref_and_jump(x1,normalizePath21_3_3);
  *reasonp++ =  x1;
  goto normalizePath21_3_17;
  };
  goto normalizePath21_3_17;
 case VARREF:
  deref_and_jump(x0,normalizePath21_3_2);
  *reasonp++ =  x0;
  goto normalizePath21_3_17;
  };
  goto normalizePath21_3_17;
 case VARREF:
  deref_and_jump(a0,normalizePath21_3_1);
  *reasonp++ =  a0;
  goto normalizePath21_3_17;
  };
  goto normalizePath21_3_17;
 normalizePath21_3_17:
  otherwise(normalizePath21_3_interrupt);
 normalizePath21_3_18:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 normalizePath21_3_19:
  switch (ptagof(x0)) {
 case CONS:
  x1 = car_of(x0);
 normalizePath21_3_20:
  switch (ptagof(x1)) {
 case ATOMIC:
 normalizePath21_3_21:
  if (x1 != makeint(46L)) goto normalizePath21_3_27;
  x2 = cdr_of(x0);
 normalizePath21_3_22:
  switch (ptagof(x2)) {
 case CONS:
  x3 = car_of(x2);
 normalizePath21_3_23:
  switch (ptagof(x3)) {
 case ATOMIC:
 normalizePath21_3_24:
  if (x3 != makeint(46L)) goto normalizePath21_3_27;
  x4 = cdr_of(x2);
 normalizePath21_3_25:
  switch (ptagof(x4)) {
 case ATOMIC:
  if (x4 != NILATOM) goto normalizePath21_3_27;
 normalizePath21_3_26:
  switch (ptagof(a1)) {
 case CONS:
  a0 = cdr_of(a0);
  a1 = cdr_of(a1);
  execute(normalizePath21_3_0);
  goto normalizePath21_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,normalizePath21_3_26);
  *reasonp++ =  a1;
  goto normalizePath21_3_27;
  };
  goto normalizePath21_3_27;
 case VARREF:
  deref_and_jump(x4,normalizePath21_3_25);
  *reasonp++ =  x4;
  goto normalizePath21_3_27;
  };
  goto normalizePath21_3_27;
 case VARREF:
  deref_and_jump(x3,normalizePath21_3_23);
  *reasonp++ =  x3;
  goto normalizePath21_3_27;
  };
  goto normalizePath21_3_27;
 case VARREF:
  deref_and_jump(x2,normalizePath21_3_22);
  *reasonp++ =  x2;
  goto normalizePath21_3_27;
  };
  goto normalizePath21_3_27;
 case VARREF:
  deref_and_jump(x1,normalizePath21_3_20);
  *reasonp++ =  x1;
  goto normalizePath21_3_27;
  };
  goto normalizePath21_3_27;
 case VARREF:
  deref_and_jump(x0,normalizePath21_3_19);
  *reasonp++ =  x0;
  goto normalizePath21_3_27;
  };
  goto normalizePath21_3_27;
 case VARREF:
  deref_and_jump(a0,normalizePath21_3_18);
  *reasonp++ =  a0;
  goto normalizePath21_3_27;
  };
  goto normalizePath21_3_27;
 normalizePath21_3_27:
  otherwise(normalizePath21_3_interrupt);
 normalizePath21_3_28:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = a1;
  x1 = car_of(a0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  a0 = cdr_of(a0);
  a1 = x0;
  allocp += 2;
  execute(normalizePath21_3_0);
  goto normalizePath21_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto normalizePath21_3_interrupt;
  a0 = a1;
  a1 = NILATOM;
  execute(normalizePath22_3_0);
  goto normalizePath22_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,normalizePath21_3_28);
  *reasonp++ =  a0;
  goto normalizePath21_3_interrupt;
  };
  goto normalizePath21_3_interrupt;
 normalizePath21_3_ext_interrupt:
  reasonp = 0l;
 normalizePath21_3_interrupt:
  toppred = &predicate_url_xnormalizePath21_3;
  goto interrupt_3;
 }

 normalizePath22_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 normalizePath22_3_clear_reason:
  reasonp = reasons;
 normalizePath22_3_0:
 normalizePath22_3_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = a1;
  x1 = car_of(a0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  a0 = cdr_of(a0);
  a1 = x0;
  allocp += 2;
  execute(normalizePath22_3_0);
  goto normalizePath22_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto normalizePath22_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,normalizePath22_3_1);
  *reasonp++ =  a0;
  goto normalizePath22_3_interrupt;
  };
  goto normalizePath22_3_interrupt;
 normalizePath22_3_ext_interrupt:
  reasonp = 0l;
 normalizePath22_3_interrupt:
  toppred = &predicate_url_xnormalizePath22_3;
  goto interrupt_3;
 }

 appendPath_2_top: {
  q x0, x1, x2, x3;
  qp = qp->next;
 appendPath_2_clear_reason:
  reasonp = reasons;
 appendPath_2_0:
 appendPath_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = cdr_of(a0);
 appendPath_2_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != NILATOM) goto appendPath_2_3;
  x1 = car_of(a0);
  unify(a1, x1);
  proceed();
 case VARREF:
  deref_and_jump(x0,appendPath_2_2);
  *reasonp++ =  x0;
  goto appendPath_2_3;
  };
  goto appendPath_2_3;
 case VARREF:
  deref_and_jump(a0,appendPath_2_1);
  *reasonp++ =  a0;
  goto appendPath_2_3;
  };
  goto appendPath_2_3;
 appendPath_2_3:
  otherwise(appendPath_2_interrupt);
 appendPath_2_4:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_url_xappendPath_2);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x1;
  allocp[5] = makeint(47L);
  x2 = makecons(&allocp[4]);
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_util_xappend_3);
  x3 = car_of(a0);
  allocp[8] = x3;
  allocp[9] = x2;
  allocp[10] = a1;
  qp = (struct goalrec*)&allocp[6];
  allocp += 11;
  proceed();
 case ATOMIC:
  if (a0 != NILATOM) goto appendPath_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,appendPath_2_4);
  *reasonp++ =  a0;
  goto appendPath_2_interrupt;
  };
  goto appendPath_2_interrupt;
 appendPath_2_ext_interrupt:
  reasonp = 0l;
 appendPath_2_interrupt:
  goto interrupt_2;
 }

 partNetLoc_3_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  qp = qp->next;
 partNetLoc_3_clear_reason:
  reasonp = reasons;
 partNetLoc_3_0:
 partNetLoc_3_1:
  if (isref(a0)) goto partNetLoc_3_4;
 partNetLoc_3_2:
  if (isref(a0)) goto partNetLoc_3_3;
  x0 = makefunctor(&string_const_0);
  if_not_equal(a0, x0, partNetLoc_3_5);
  x1 = makefunctor(&string_const_0);
  unify_value(a1, x1);
  x2 = makeint(80L);
  unify_value(a2, x2);
  proceed();
 partNetLoc_3_3:
  deref_and_jump(a0,partNetLoc_3_2);
  *reasonp++ =  a0;
  goto partNetLoc_3_5;
 partNetLoc_3_4:
  deref_and_jump(a0,partNetLoc_3_1);
  *reasonp++ =  a0;
  goto partNetLoc_3_5;
 partNetLoc_3_5:
  otherwise(partNetLoc_3_interrupt);
  allocp[0] = x0 = makeref(&allocp[0]);
  generic_arg[0] = x0;
  call_generic(a0, functor_size_1, 1);
  x1 = makeint(1L);
  bblt_sub_no_check_y(x0,x1,x2);
  x3 = makeint(0L);
  generic_arg[0] = x3;
  generic_arg[1] = x2;
  x4 = makeint(58L);
  generic_arg[2] = x4;
  allocp[0] = x5 = makeref(&allocp[0]);
  generic_arg[3] = x5;
  call_generic(a0, functor_search__character_4, 1);
  x6 = a0;
  a3 = a2;
  a2 = x6;
  a0 = x5;
  execute(partNetLoc_2F3_240_4_0);
  goto partNetLoc_2F3_240_4_ext_interrupt;
 partNetLoc_3_ext_interrupt:
  reasonp = 0l;
 partNetLoc_3_interrupt:
  goto interrupt_3;
 }

 partNetLoc_2F3_240_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 partNetLoc_2F3_240_4_clear_reason:
  reasonp = reasons;
 partNetLoc_2F3_240_4_0:
 partNetLoc_2F3_240_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 partNetLoc_2F3_240_4_2:
  if (a0 != makeint(-1L)) goto partNetLoc_2F3_240_4_3;
  unify(a1, a2);
  x0 = makeint(80L);
  unify_value(a3, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,partNetLoc_2F3_240_4_1);
  *reasonp++ =  a0;
  goto partNetLoc_2F3_240_4_3;
  };
  goto partNetLoc_2F3_240_4_3;
 partNetLoc_2F3_240_4_3:
  otherwise(partNetLoc_2F3_240_4_interrupt);
  generic_arg[0] = a0;
  generic_arg[1] = a1;
  allocp[0] = x0 = makeref(&allocp[0]);
  generic_arg[2] = x0;
  call_generic(a2, functor_split_3, 1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_util_xatoi_2);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a3;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_util_xgetCarCdr_3);
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = x1;
  allocp[9] = (q)(struct goalrec*)&allocp[4];
  allocp[10] = (q)(&predicate_util_xstrToLst_2);
  allocp[11] = x0;
  allocp[12] = x2;
  qp = (struct goalrec*)&allocp[9];
  allocp += 13;
  proceed();
 partNetLoc_2F3_240_4_ext_interrupt:
  reasonp = 0l;
 partNetLoc_2F3_240_4_interrupt:
  toppred = &predicate_url_xpartNetLoc_2F3_240_4;
  goto interrupt_4;
 }

 encodeQueries_2_top: {
  qp = qp->next;
 encodeQueries_2_clear_reason:
  reasonp = reasons;
 encodeQueries_2_0:
  a2 = a1;
  a1 = makefunctor(&string_const_0);
  execute(encodeQueries1_3_0);
  goto encodeQueries1_3_ext_interrupt;
 encodeQueries_2_ext_interrupt:
  reasonp = 0l;
 encodeQueries_2_interrupt:
  goto interrupt_2;
 }

 encodeQueries1_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  qp = qp->next;
 encodeQueries1_3_clear_reason:
  reasonp = reasons;
 encodeQueries1_3_0:
 encodeQueries1_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = cdr_of(a0);
 encodeQueries1_3_2:
  switch (ptagof(x0)) {
 case CONS:
  x2 = cdr_of(x0);
  allocp[0] = x2;
  x3 = car_of(x0);
  allocp[1] = x3;
  x1 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_url_xencodeQueries1_3);
  allocp[4] = x1;
  allocp[5] = x4 = makeref(&allocp[5]);
  allocp[6] = a2;
  allocp[7] = makecons(cons_const_5);
  allocp[8] = x6 = makeref(&allocp[8]);
  x5 = makecons(&allocp[7]);
  allocp[9] = x5;
  allocp[10] = a1;
  x7 = makecons(&allocp[9]);
  allocp[11] = (q)(struct goalrec*)&allocp[2];
  allocp[12] = (q)(&predicate_util_xstringJoin_2);
  allocp[13] = x7;
  allocp[14] = x4;
  a0 = car_of(a0);
  a1 = x6;
  qp = (struct goalrec*)&allocp[11];
  allocp += 15;
  execute(encode_2_0);
  goto encode_2_ext_interrupt;
 case ATOMIC:
  if (x0 != NILATOM) goto encodeQueries1_3_interrupt;
  allocp[0] = makesym(functor_join_2);
  allocp[1] = x2 = makeref(&allocp[1]);
  allocp[2] = a2;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = (q)qp;
  allocp[4] = (q)(&predicate_generic_xgeneric_2);
  allocp[5] = x1;
  allocp[6] = a1;
  a0 = car_of(a0);
  a1 = x2;
  qp = (struct goalrec*)&allocp[3];
  allocp += 7;
  execute(encode_2_0);
  goto encode_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,encodeQueries1_3_2);
  *reasonp++ =  x0;
  goto encodeQueries1_3_interrupt;
  };
  goto encodeQueries1_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto encodeQueries1_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,encodeQueries1_3_1);
  *reasonp++ =  a0;
  goto encodeQueries1_3_interrupt;
  };
  goto encodeQueries1_3_interrupt;
 encodeQueries1_3_ext_interrupt:
  reasonp = 0l;
 encodeQueries1_3_interrupt:
  toppred = &predicate_url_xencodeQueries1_3;
  goto interrupt_3;
 }

 encode_2_top: {
  q x0, x1, x2, x3;
  qp = qp->next;
 encode_2_clear_reason:
  reasonp = reasons;
 encode_2_0:
  allocp[0] = x0 = makeref(&allocp[0]);
  generic_arg[0] = x0;
  x1 = makeint(8L);
  generic_arg[1] = x1;
  new_generic(string_g_new, 2, x2, 1);
  unify(a1, x2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_url_xencode1_2);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = x0;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_util_xstrToLst_2);
  allocp[6] = a0;
  allocp[7] = x3;
  qp = (struct goalrec*)&allocp[4];
  allocp += 8;
  proceed();
 encode_2_ext_interrupt:
  reasonp = 0l;
 encode_2_interrupt:
  toppred = &predicate_url_xencode_2;
  goto interrupt_2;
 }

 encode1_2_top: {
  q x0, x1, x2;
  qp = qp->next;
 encode1_2_clear_reason:
  reasonp = reasons;
 encode1_2_0:
 encode1_2_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_url_xencode1_2F2_240_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  x1 = car_of(a0);
  allocp[3] = x1;
  allocp[4] = a1;
  x2 = cdr_of(a0);
  allocp[5] = x2;
  a0 = x1;
  a1 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(needEncode_2_0);
  goto needEncode_2_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto encode1_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,encode1_2_1);
  *reasonp++ =  a0;
  goto encode1_2_interrupt;
  };
  goto encode1_2_interrupt;
 encode1_2_ext_interrupt:
  reasonp = 0l;
 encode1_2_interrupt:
  toppred = &predicate_url_xencode1_2;
  goto interrupt_2;
 }

 encode1_2F2_240_4_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 encode1_2F2_240_4_clear_reason:
  reasonp = reasons;
 encode1_2F2_240_4_0:
 encode1_2F2_240_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto encode1_2F2_240_4_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_true)):
  a0 = a1;
  a1 = a2;
  a2 = a3;
  execute(encode1_2F2_240_2F4_240_3_0);
  goto encode1_2F2_240_2F4_240_3_ext_interrupt;
 case symval(makesym(atom_false)):
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = a1;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  a0 = a3;
  a1 = x1;
  execute(encode1_2_0);
  goto encode1_2_ext_interrupt;
  };
  goto encode1_2F2_240_4_interrupt;
 case VARREF:
  deref_and_jump(a0,encode1_2F2_240_4_1);
  *reasonp++ =  a0;
  goto encode1_2F2_240_4_interrupt;
  };
  goto encode1_2F2_240_4_interrupt;
 encode1_2F2_240_4_ext_interrupt:
  reasonp = 0l;
 encode1_2F2_240_4_interrupt:
  goto interrupt_4;
 }

 encode1_2F2_240_2F4_240_3_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  qp = qp->next;
 encode1_2F2_240_2F4_240_3_clear_reason:
  reasonp = reasons;
 encode1_2F2_240_2F4_240_3_0:
 encode1_2F2_240_2F4_240_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 encode1_2F2_240_2F4_240_3_2:
  if (a0 != makeint(32L)) goto encode1_2F2_240_2F4_240_3_3;
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = makeint(43L);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = a2;
  a1 = x1;
  execute(encode1_2_0);
  goto encode1_2_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,encode1_2F2_240_2F4_240_3_1);
  *reasonp++ =  a0;
  goto encode1_2F2_240_2F4_240_3_3;
  };
  goto encode1_2F2_240_2F4_240_3_3;
 encode1_2F2_240_2F4_240_3_3:
  otherwise(encode1_2F2_240_2F4_240_3_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_url_xencode1_2);
  allocp[2] = a2;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = x0;
  allocp[5] = x2 = makeref(&allocp[5]);
  x1 = makecons(&allocp[4]);
  allocp[6] = x1;
  allocp[7] = x4 = makeref(&allocp[7]);
  x3 = makecons(&allocp[6]);
  allocp[8] = x3;
  allocp[9] = makeint(37L);
  x5 = makecons(&allocp[8]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  unify_value(a1, x5);
  a1 = x4;
  a2 = x2;
  execute(toHexChars_3_0);
  goto toHexChars_3_ext_interrupt;
 encode1_2F2_240_2F4_240_3_ext_interrupt:
  reasonp = 0l;
 encode1_2F2_240_2F4_240_3_interrupt:
  toppred = &predicate_url_xencode1_2F2_240_2F4_240_3;
  goto interrupt_3;
 }

 toHexChars_3_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  qp = qp->next;
 toHexChars_3_clear_reason:
  reasonp = reasons;
 toHexChars_3_0:
  x0 = makeint(16L);
  bblt_mod_no_check_y(a0,x0,x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_url_xtoChar_2);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_integer__arithmetics_xdivide_3);
  allocp[6] = a0;
  allocp[7] = makeint(16L);
  allocp[8] = x2;
  a0 = x1;
  a1 = a2;
  qp = (struct goalrec*)&allocp[4];
  allocp += 9;
  execute(toChar_2_0);
  goto toChar_2_ext_interrupt;
 toHexChars_3_ext_interrupt:
  reasonp = 0l;
 toHexChars_3_interrupt:
  toppred = &predicate_url_xtoHexChars_3;
  goto interrupt_3;
 }

 toChar_2_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  qp = qp->next;
 toChar_2_clear_reason:
  reasonp = reasons;
 toChar_2_0:
 toChar_2_1:
  if (!isint(a0)) goto toChar_2_3;
  x0 = makeint(0L);
  gblt_less_or_eq(x0,a0,toChar_2_2);
  x1 = makeint(9L);
  gblt_less_or_eq(a0,x1,toChar_2_2);
  x2 = makeint(48L);
  bblt_add_no_check(x2,a0,x3);
  unify_value(a1, x3);
  proceed();
 toChar_2_2:
  x1 = makeint(10L);
  gblt_less_or_eq(x1,a0,toChar_2_interrupt);
  x2 = makeint(15L);
  gblt_less_or_eq(a0,x2,toChar_2_interrupt);
  x3 = makeint(65L);
  bblt_add_no_check(x3,a0,x4);
  x5 = makeint(10L);
  bblt_sub_no_check(x4,x5,x6);
  unify_value(a1, x6);
  proceed();
 toChar_2_3:
  if (!isref(a0)) goto toChar_2_interrupt;
  deref_and_jump(a0,toChar_2_1);
  *reasonp++ =  a0;
  goto toChar_2_interrupt;
 toChar_2_ext_interrupt:
  reasonp = 0l;
 toChar_2_interrupt:
  toppred = &predicate_url_xtoChar_2;
  goto interrupt_2;
 }

 needEncode_2_top: {
  q x0, x1, x2, x3;
  qp = qp->next;
 needEncode_2_clear_reason:
  reasonp = reasons;
 needEncode_2_0:
 needEncode_2_1:
  if (!isint(a0)) goto needEncode_2_3;
  x0 = makeint(65L);
  gblt_less_or_eq(x0,a0,needEncode_2_2);
  x1 = makeint(90L);
  gblt_less_or_eq(a0,x1,needEncode_2_2);
  x2 = makesym(atom_false);
  unify_value(a1, x2);
  proceed();
 needEncode_2_2:
  x1 = makeint(97L);
  gblt_less_or_eq(x1,a0,needEncode_2_4);
  x2 = makeint(122L);
  gblt_less_or_eq(a0,x2,needEncode_2_4);
  x3 = makesym(atom_false);
  unify_value(a1, x3);
  proceed();
 needEncode_2_3:
  if (!isref(a0)) goto needEncode_2_4;
  deref_and_jump(a0,needEncode_2_1);
  *reasonp++ =  a0;
  goto needEncode_2_4;
 needEncode_2_4:
  otherwise(needEncode_2_interrupt);
  x0 = makesym(atom_true);
  unify_value(a1, x0);
  proceed();
 needEncode_2_ext_interrupt:
  reasonp = 0l;
 needEncode_2_interrupt:
  toppred = &predicate_url_xneedEncode_2;
  goto interrupt_2;
 }

 rmQuery_2_top: {
  q x0, x1, x2, x3, x4, x5;
  qp = qp->next;
 rmQuery_2_clear_reason:
  reasonp = reasons;
 rmQuery_2_0:
  allocp[0] = x0 = makeref(&allocp[0]);
  generic_arg[0] = x0;
  call_generic(a0, functor_size_1, 1);
  x1 = makeint(1L);
  bblt_sub_no_check_y(x0,x1,x2);
  x3 = makeint(0L);
  generic_arg[0] = x3;
  generic_arg[1] = x2;
  x4 = makeint(63L);
  generic_arg[2] = x4;
  allocp[0] = x5 = makeref(&allocp[0]);
  generic_arg[3] = x5;
  call_generic(a0, functor_search__character_4, 1);
  a2 = a0;
  a0 = x5;
  execute(rmQuery_2F2_240_3_0);
  goto rmQuery_2F2_240_3_ext_interrupt;
 rmQuery_2_ext_interrupt:
  reasonp = 0l;
 rmQuery_2_interrupt:
  goto interrupt_2;
 }

 rmQuery_2F2_240_3_top: {
  q x0;
  a2 = qp->args[2];
  qp = qp->next;
 rmQuery_2F2_240_3_clear_reason:
  reasonp = reasons;
 rmQuery_2F2_240_3_0:
 rmQuery_2F2_240_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 rmQuery_2F2_240_3_2:
  if (a0 != makeint(-1L)) goto rmQuery_2F2_240_3_3;
  unify(a1, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,rmQuery_2F2_240_3_1);
  *reasonp++ =  a0;
  goto rmQuery_2F2_240_3_3;
  };
  goto rmQuery_2F2_240_3_3;
 rmQuery_2F2_240_3_3:
  otherwise(rmQuery_2F2_240_3_interrupt);
  generic_arg[0] = a0;
  generic_arg[1] = a1;
  allocp[0] = x0 = makeref(&allocp[0]);
  generic_arg[2] = x0;
  call_generic(a2, functor_split_3, 1);
  proceed();
 rmQuery_2F2_240_3_ext_interrupt:
  reasonp = 0l;
 rmQuery_2F2_240_3_interrupt:
  toppred = &predicate_url_xrmQuery_2F2_240_3;
  goto interrupt_3;
 }
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_url);
}
