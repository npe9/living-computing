#include <klic/basic.h>
#include <klic/predinfo.h>

extern Const struct predicate predicate_unparser_xunwparse__cons_5;
static Const struct predinfo predinfo_unparser_xunwparse__cons_5 = {
  (unsigned char *)"unwparse_cons",
  &predicate_unparser_xunwparse__cons_5
};

extern Const struct predicate predicate_unparser_xunwparse__cdr_5;
static Const struct predinfo predinfo_unparser_xunwparse__cdr_5 = {
  (unsigned char *)"unwparse_cdr",
  &predicate_unparser_xunwparse__cdr_5
};

extern Const struct predicate predicate_unparser_xunwparse_6;
static Const struct predinfo predinfo_unparser_xunwparse_6 = {
  (unsigned char *)"unwparse",
  &predicate_unparser_xunwparse_6
};

extern Const struct predicate predicate_unparser_xunwparse_4;
static Const struct predinfo predinfo_unparser_xunwparse_4 = {
  (unsigned char *)"unwparse",
  &predicate_unparser_xunwparse_4
};

extern Const struct predicate predicate_unparser_xunscan__after__op_4;
static Const struct predinfo predinfo_unparser_xunscan__after__op_4 = {
  (unsigned char *)"unscan_after_op",
  &predicate_unparser_xunscan__after__op_4
};

extern Const struct predicate predicate_unparser_xunscan_4;
static Const struct predinfo predinfo_unparser_xunscan_4 = {
  (unsigned char *)"unscan",
  &predicate_unparser_xunscan_4
};

extern Const struct predicate predicate_unparser_xunparse__with__op_10;
static Const struct predinfo predinfo_unparser_xunparse__with__op_10 = {
  (unsigned char *)"unparse_with_op",
  &predicate_unparser_xunparse__with__op_10
};

extern Const struct predicate predicate_unparser_xunparse__vector_5;
static Const struct predinfo predinfo_unparser_xunparse__vector_5 = {
  (unsigned char *)"unparse_vector",
  &predicate_unparser_xunparse__vector_5
};

extern Const struct predicate predicate_unparser_xunparse__vecelems_7;
static Const struct predinfo predinfo_unparser_xunparse__vecelems_7 = {
  (unsigned char *)"unparse_vecelems",
  &predicate_unparser_xunparse__vecelems_7
};

extern Const struct predicate predicate_unparser_xunparse__string_3;
static Const struct predinfo predinfo_unparser_xunparse__string_3 = {
  (unsigned char *)"unparse_string",
  &predicate_unparser_xunparse__string_3
};

extern Const struct predicate predicate_unparser_xunparse__int_3;
static Const struct predinfo predinfo_unparser_xunparse__int_3 = {
  (unsigned char *)"unparse_int",
  &predicate_unparser_xunparse__int_3
};

extern Const struct predicate predicate_unparser_xunparse__general_6;
static Const struct predinfo predinfo_unparser_xunparse__general_6 = {
  (unsigned char *)"unparse_general",
  &predicate_unparser_xunparse__general_6
};

extern Const struct predicate predicate_unparser_xunparse__float_3;
static Const struct predinfo predinfo_unparser_xunparse__float_3 = {
  (unsigned char *)"unparse_float",
  &predicate_unparser_xunparse__float_3
};

extern Const struct predicate predicate_unparser_xunparse__elems_7;
static Const struct predinfo predinfo_unparser_xunparse__elems_7 = {
  (unsigned char *)"unparse_elems",
  &predicate_unparser_xunparse__elems_7
};

extern Const struct predicate predicate_unparser_xunparse__cons_5;
static Const struct predinfo predinfo_unparser_xunparse__cons_5 = {
  (unsigned char *)"unparse_cons",
  &predicate_unparser_xunparse__cons_5
};

extern Const struct predicate predicate_unparser_xunparse__comma__list__elem_5;
static Const struct predinfo predinfo_unparser_xunparse__comma__list__elem_5 = {
  (unsigned char *)"unparse_comma_list_elem",
  &predicate_unparser_xunparse__comma__list__elem_5
};

extern Const struct predicate predicate_unparser_xunparse__cdr_5;
static Const struct predinfo predinfo_unparser_xunparse__cdr_5 = {
  (unsigned char *)"unparse_cdr",
  &predicate_unparser_xunparse__cdr_5
};

extern Const struct predicate predicate_unparser_xunparse__bin__op_3;
static Const struct predinfo predinfo_unparser_xunparse__bin__op_3 = {
  (unsigned char *)"unparse_bin_op",
  &predicate_unparser_xunparse__bin__op_3
};

extern Const struct predicate predicate_unparser_xunparse__atom_3;
static Const struct predinfo predinfo_unparser_xunparse__atom_3 = {
  (unsigned char *)"unparse_atom",
  &predicate_unparser_xunparse__atom_3
};

extern Const struct predicate predicate_unparser_xunparse_6;
static Const struct predinfo predinfo_unparser_xunparse_6 = {
  (unsigned char *)"unparse",
  &predicate_unparser_xunparse_6
};

extern Const struct predicate predicate_unparser_xunparse_4;
static Const struct predinfo predinfo_unparser_xunparse_4 = {
  (unsigned char *)"unparse",
  &predicate_unparser_xunparse_4
};

extern Const struct predicate predicate_unparser_xstr__elem__chars_3;
static Const struct predinfo predinfo_unparser_xstr__elem__chars_3 = {
  (unsigned char *)"str_elem_chars",
  &predicate_unparser_xstr__elem__chars_3
};

extern Const struct predicate predicate_unparser_xstr__chars_5;
static Const struct predinfo predinfo_unparser_xstr__chars_5 = {
  (unsigned char *)"str_chars",
  &predicate_unparser_xstr__chars_5
};

extern Const struct predicate predicate_unparser_xquoted__atom__chars_4;
static Const struct predinfo predinfo_unparser_xquoted__atom__chars_4 = {
  (unsigned char *)"quoted_atom_chars",
  &predicate_unparser_xquoted__atom__chars_4
};

extern Const struct predicate predicate_unparser_xquoted__atom__chars_2F4_240_3;
static Const struct predinfo predinfo_unparser_xquoted__atom__chars_2F4_240_3 = {
  (unsigned char *)"quoted_atom_chars/4$0",
  &predicate_unparser_xquoted__atom__chars_2F4_240_3
};

extern Const struct predicate predicate_unparser_xmax__op_4;
static Const struct predinfo predinfo_unparser_xmax__op_4 = {
  (unsigned char *)"max_op",
  &predicate_unparser_xmax__op_4
};

extern Const struct predicate predicate_unparser_xmax_3;
static Const struct predinfo predinfo_unparser_xmax_3 = {
  (unsigned char *)"max",
  &predicate_unparser_xmax_3
};

extern Const struct predicate predicate_unparser_xmake__atom__string_4;
static Const struct predinfo predinfo_unparser_xmake__atom__string_4 = {
  (unsigned char *)"make_atom_string",
  &predicate_unparser_xmake__atom__string_4
};

extern Const struct predicate predicate_unparser_xjudge__quoted_6;
static Const struct predinfo predinfo_unparser_xjudge__quoted_6 = {
  (unsigned char *)"judge_quoted",
  &predicate_unparser_xjudge__quoted_6
};

extern Const struct predicate predicate_unparser_xint__chars_3;
static Const struct predinfo predinfo_unparser_xint__chars_3 = {
  (unsigned char *)"int_chars",
  &predicate_unparser_xint__chars_3
};

extern Const struct predicate predicate_unparser_xins__if__greater__than_5;
static Const struct predinfo predinfo_unparser_xins__if__greater__than_5 = {
  (unsigned char *)"ins_if_greater_than",
  &predicate_unparser_xins__if__greater__than_5
};

extern Const struct predicate predicate_unparser_xins__backslash_3;
static Const struct predinfo predinfo_unparser_xins__backslash_3 = {
  (unsigned char *)"ins_backslash",
  &predicate_unparser_xins__backslash_3
};

extern Const struct predicate predicate_unparser_xfirst__char__kind_2;
static Const struct predinfo predinfo_unparser_xfirst__char__kind_2 = {
  (unsigned char *)"first_char_kind",
  &predicate_unparser_xfirst__char__kind_2
};

extern Const struct predicate predicate_unparser_xfind__operator_3;
static Const struct predinfo predinfo_unparser_xfind__operator_3 = {
  (unsigned char *)"find_operator",
  &predicate_unparser_xfind__operator_3
};

extern Const struct predicate predicate_unparser_xdelimit_4;
static Const struct predinfo predinfo_unparser_xdelimit_4 = {
  (unsigned char *)"delimit",
  &predicate_unparser_xdelimit_4
};

extern Const struct predicate predicate_unparser_xchartype_2F2_240_2;
static Const struct predinfo predinfo_unparser_xchartype_2F2_240_2 = {
  (unsigned char *)"chartype/2$0",
  &predicate_unparser_xchartype_2F2_240_2
};

extern Const struct predicate predicate_unparser_xchartype_2;
static Const struct predinfo predinfo_unparser_xchartype_2 = {
  (unsigned char *)"chartype",
  &predicate_unparser_xchartype_2
};

extern Const struct predicate predicate_unparser_xchar__kind_2;
static Const struct predinfo predinfo_unparser_xchar__kind_2 = {
  (unsigned char *)"char_kind",
  &predicate_unparser_xchar__kind_2
};

extern Const struct predicate predicate_unparser_xcall__unparser_6;
static Const struct predinfo predinfo_unparser_xcall__unparser_6 = {
  (unsigned char *)"call_unparser",
  &predicate_unparser_xcall__unparser_6
};

extern Const struct predicate predicate_unparser_xatom__kind_3;
static Const struct predinfo predinfo_unparser_xatom__kind_3 = {
  (unsigned char *)"atom_kind",
  &predicate_unparser_xatom__kind_3
};

extern Const struct predicate predicate_unparser_xatom__kind_2F3_240_4;
static Const struct predinfo predinfo_unparser_xatom__kind_2F3_240_4 = {
  (unsigned char *)"atom_kind/3$0",
  &predicate_unparser_xatom__kind_2F3_240_4
};

static Const struct predinfo * Const preds_in_unparser[] = {
  &predinfo_unparser_xunwparse__cons_5,
  &predinfo_unparser_xunwparse__cdr_5,
  &predinfo_unparser_xunwparse_6,
  &predinfo_unparser_xunwparse_4,
  &predinfo_unparser_xunscan__after__op_4,
  &predinfo_unparser_xunscan_4,
  &predinfo_unparser_xunparse__with__op_10,
  &predinfo_unparser_xunparse__vector_5,
  &predinfo_unparser_xunparse__vecelems_7,
  &predinfo_unparser_xunparse__string_3,
  &predinfo_unparser_xunparse__int_3,
  &predinfo_unparser_xunparse__general_6,
  &predinfo_unparser_xunparse__float_3,
  &predinfo_unparser_xunparse__elems_7,
  &predinfo_unparser_xunparse__cons_5,
  &predinfo_unparser_xunparse__comma__list__elem_5,
  &predinfo_unparser_xunparse__cdr_5,
  &predinfo_unparser_xunparse__bin__op_3,
  &predinfo_unparser_xunparse__atom_3,
  &predinfo_unparser_xunparse_6,
  &predinfo_unparser_xunparse_4,
  &predinfo_unparser_xstr__elem__chars_3,
  &predinfo_unparser_xstr__chars_5,
  &predinfo_unparser_xquoted__atom__chars_4,
  &predinfo_unparser_xquoted__atom__chars_2F4_240_3,
  &predinfo_unparser_xmax__op_4,
  &predinfo_unparser_xmax_3,
  &predinfo_unparser_xmake__atom__string_4,
  &predinfo_unparser_xjudge__quoted_6,
  &predinfo_unparser_xint__chars_3,
  &predinfo_unparser_xins__if__greater__than_5,
  &predinfo_unparser_xins__backslash_3,
  &predinfo_unparser_xfirst__char__kind_2,
  &predinfo_unparser_xfind__operator_3,
  &predinfo_unparser_xdelimit_4,
  &predinfo_unparser_xchartype_2F2_240_2,
  &predinfo_unparser_xchartype_2,
  &predinfo_unparser_xchar__kind_2,
  &predinfo_unparser_xcall__unparser_6,
  &predinfo_unparser_xatom__kind_3,
  &predinfo_unparser_xatom__kind_2F3_240_4,
  0
};
extern Const struct predicate predicate_scanner_xungetc_3;
static Const struct predinfo predinfo_scanner_xungetc_3 = {
  (unsigned char *)"ungetc",
  &predicate_scanner_xungetc_3
};

extern Const struct predicate predicate_scanner_xscan__unsigned__exponent_9;
static Const struct predinfo predinfo_scanner_xscan__unsigned__exponent_9 = {
  (unsigned char *)"scan_unsigned_exponent",
  &predicate_scanner_xscan__unsigned__exponent_9
};

extern Const struct predicate predicate_scanner_xscan__string_8;
static Const struct predinfo predinfo_scanner_xscan__string_8 = {
  (unsigned char *)"scan_string",
  &predicate_scanner_xscan__string_8
};

extern Const struct predicate predicate_scanner_xscan__string_2F8_240_8;
static Const struct predinfo predinfo_scanner_xscan__string_2F8_240_8 = {
  (unsigned char *)"scan_string/8$0",
  &predicate_scanner_xscan__string_2F8_240_8
};

extern Const struct predicate predicate_scanner_xscan__sname_7;
static Const struct predinfo predinfo_scanner_xscan__sname_7 = {
  (unsigned char *)"scan_sname",
  &predicate_scanner_xscan__sname_7
};

extern Const struct predicate predicate_scanner_xscan__rest_4;
static Const struct predinfo predinfo_scanner_xscan__rest_4 = {
  (unsigned char *)"scan_rest",
  &predicate_scanner_xscan__rest_4
};

extern Const struct predicate predicate_scanner_xscan__octal__escape__2_9;
static Const struct predinfo predinfo_scanner_xscan__octal__escape__2_9 = {
  (unsigned char *)"scan_octal_escape_2",
  &predicate_scanner_xscan__octal__escape__2_9
};

extern Const struct predicate predicate_scanner_xscan__octal__escape__2_2F9_240_9;
static Const struct predinfo predinfo_scanner_xscan__octal__escape__2_2F9_240_9 = {
  (unsigned char *)"scan_octal_escape_2/9$0",
  &predicate_scanner_xscan__octal__escape__2_2F9_240_9
};

extern Const struct predicate predicate_scanner_xscan__octal__escape_9;
static Const struct predinfo predinfo_scanner_xscan__octal__escape_9 = {
  (unsigned char *)"scan_octal_escape",
  &predicate_scanner_xscan__octal__escape_9
};

extern Const struct predicate predicate_scanner_xscan__number_9;
static Const struct predinfo predinfo_scanner_xscan__number_9 = {
  (unsigned char *)"scan_number",
  &predicate_scanner_xscan__number_9
};

extern Const struct predicate predicate_scanner_xscan__number_2F9_241_8;
static Const struct predinfo predinfo_scanner_xscan__number_2F9_241_8 = {
  (unsigned char *)"scan_number/9$1",
  &predicate_scanner_xscan__number_2F9_241_8
};

extern Const struct predicate predicate_scanner_xscan__number_2F9_240_9;
static Const struct predinfo predinfo_scanner_xscan__number_2F9_240_9 = {
  (unsigned char *)"scan_number/9$0",
  &predicate_scanner_xscan__number_2F9_240_9
};

extern Const struct predicate predicate_scanner_xscan__name_7;
static Const struct predinfo predinfo_scanner_xscan__name_7 = {
  (unsigned char *)"scan_name",
  &predicate_scanner_xscan__name_7
};

extern Const struct predicate predicate_scanner_xscan__hex__escape_9;
static Const struct predinfo predinfo_scanner_xscan__hex__escape_9 = {
  (unsigned char *)"scan_hex_escape",
  &predicate_scanner_xscan__hex__escape_9
};

extern Const struct predicate predicate_scanner_xscan__fraction_9;
static Const struct predinfo predinfo_scanner_xscan__fraction_9 = {
  (unsigned char *)"scan_fraction",
  &predicate_scanner_xscan__fraction_9
};

extern Const struct predicate predicate_scanner_xscan__fraction_2F9_240_11;
static Const struct predinfo predinfo_scanner_xscan__fraction_2F9_240_11 = {
  (unsigned char *)"scan_fraction/9$0",
  &predicate_scanner_xscan__fraction_2F9_240_11
};

extern Const struct predicate predicate_scanner_xscan__exponent_9;
static Const struct predinfo predinfo_scanner_xscan__exponent_9 = {
  (unsigned char *)"scan_exponent",
  &predicate_scanner_xscan__exponent_9
};

extern Const struct predicate predicate_scanner_xscan__escape_8;
static Const struct predinfo predinfo_scanner_xscan__escape_8 = {
  (unsigned char *)"scan_escape",
  &predicate_scanner_xscan__escape_8
};

extern Const struct predicate predicate_scanner_xscan__comment__line_5;
static Const struct predinfo predinfo_scanner_xscan__comment__line_5 = {
  (unsigned char *)"scan_comment_line",
  &predicate_scanner_xscan__comment__line_5
};

extern Const struct predicate predicate_scanner_xscan__comment_5;
static Const struct predinfo predinfo_scanner_xscan__comment_5 = {
  (unsigned char *)"scan_comment",
  &predicate_scanner_xscan__comment_5
};

extern Const struct predicate predicate_scanner_xscan__comment_2F5_240_5;
static Const struct predinfo predinfo_scanner_xscan__comment_2F5_240_5 = {
  (unsigned char *)"scan_comment/5$0",
  &predicate_scanner_xscan__comment_2F5_240_5
};

extern Const struct predicate predicate_scanner_xscan__based__number_9;
static Const struct predinfo predinfo_scanner_xscan__based__number_9 = {
  (unsigned char *)"scan_based_number",
  &predicate_scanner_xscan__based__number_9
};

extern Const struct predicate predicate_scanner_xscan__based__number_2F9_242_9;
static Const struct predinfo predinfo_scanner_xscan__based__number_2F9_242_9 = {
  (unsigned char *)"scan_based_number/9$2",
  &predicate_scanner_xscan__based__number_2F9_242_9
};

extern Const struct predicate predicate_scanner_xscan__based__number_2F9_241_9;
static Const struct predinfo predinfo_scanner_xscan__based__number_2F9_241_9 = {
  (unsigned char *)"scan_based_number/9$1",
  &predicate_scanner_xscan__based__number_2F9_241_9
};

extern Const struct predicate predicate_scanner_xscan__based__number_2F9_240_9;
static Const struct predinfo predinfo_scanner_xscan__based__number_2F9_240_9 = {
  (unsigned char *)"scan_based_number/9$0",
  &predicate_scanner_xscan__based__number_2F9_240_9
};

extern Const struct predicate predicate_scanner_xscan__after__atom_8;
static Const struct predinfo predinfo_scanner_xscan__after__atom_8 = {
  (unsigned char *)"scan_after_atom",
  &predicate_scanner_xscan__after__atom_8
};

extern Const struct predicate predicate_scanner_xscan_6;
static Const struct predinfo predinfo_scanner_xscan_6 = {
  (unsigned char *)"scan",
  &predicate_scanner_xscan_6
};

extern Const struct predicate predicate_scanner_xscan_3;
static Const struct predinfo predinfo_scanner_xscan_3 = {
  (unsigned char *)"scan",
  &predicate_scanner_xscan_3
};

extern Const struct predicate predicate_scanner_xscan_2F6_243_7;
static Const struct predinfo predinfo_scanner_xscan_2F6_243_7 = {
  (unsigned char *)"scan/6$3",
  &predicate_scanner_xscan_2F6_243_7
};

extern Const struct predicate predicate_scanner_xscan_2F6_243_2F7_240_7;
static Const struct predinfo predinfo_scanner_xscan_2F6_243_2F7_240_7 = {
  (unsigned char *)"scan/6$3/7$0",
  &predicate_scanner_xscan_2F6_243_2F7_240_7
};

extern Const struct predicate predicate_scanner_xscan_2F6_242_8;
static Const struct predinfo predinfo_scanner_xscan_2F6_242_8 = {
  (unsigned char *)"scan/6$2",
  &predicate_scanner_xscan_2F6_242_8
};

extern Const struct predicate predicate_scanner_xscan_2F6_241_8;
static Const struct predinfo predinfo_scanner_xscan_2F6_241_8 = {
  (unsigned char *)"scan/6$1",
  &predicate_scanner_xscan_2F6_241_8
};

extern Const struct predicate predicate_scanner_xscan_2F6_240_6;
static Const struct predinfo predinfo_scanner_xscan_2F6_240_6 = {
  (unsigned char *)"scan/6$0",
  &predicate_scanner_xscan_2F6_240_6
};

extern Const struct predicate predicate_scanner_xmake__new__string_2;
static Const struct predinfo predinfo_scanner_xmake__new__string_2 = {
  (unsigned char *)"make_new_string",
  &predicate_scanner_xmake__new__string_2
};

extern Const struct predicate predicate_scanner_xlookup__var_8;
static Const struct predinfo predinfo_scanner_xlookup__var_8 = {
  (unsigned char *)"lookup_var",
  &predicate_scanner_xlookup__var_8
};

extern Const struct predicate predicate_scanner_xgetchar_4;
static Const struct predinfo predinfo_scanner_xgetchar_4 = {
  (unsigned char *)"getchar",
  &predicate_scanner_xgetchar_4
};

extern Const struct predicate predicate_scanner_xget0_3;
static Const struct predinfo predinfo_scanner_xget0_3 = {
  (unsigned char *)"get0",
  &predicate_scanner_xget0_3
};

extern Const struct predicate predicate_scanner_xfinalize__vars_2F1_240_2;
static Const struct predinfo predinfo_scanner_xfinalize__vars_2F1_240_2 = {
  (unsigned char *)"finalize_vars/1$0",
  &predicate_scanner_xfinalize__vars_2F1_240_2
};

extern Const struct predicate predicate_scanner_xfinalize__vars_1;
static Const struct predinfo predinfo_scanner_xfinalize__vars_1 = {
  (unsigned char *)"finalize_vars",
  &predicate_scanner_xfinalize__vars_1
};

extern Const struct predicate predicate_scanner_xescape__char_2;
static Const struct predinfo predinfo_scanner_xescape__char_2 = {
  (unsigned char *)"escape_char",
  &predicate_scanner_xescape__char_2
};

extern Const struct predicate predicate_scanner_xchartype_2;
static Const struct predinfo predinfo_scanner_xchartype_2 = {
  (unsigned char *)"chartype",
  &predicate_scanner_xchartype_2
};

extern Const struct predicate predicate_scanner_xchar__list__to__int_3;
static Const struct predinfo predinfo_scanner_xchar__list__to__int_3 = {
  (unsigned char *)"char_list_to_int",
  &predicate_scanner_xchar__list__to__int_3
};

extern Const struct predicate predicate_scanner_xchar__list__to__float_3;
static Const struct predinfo predinfo_scanner_xchar__list__to__float_3 = {
  (unsigned char *)"char_list_to_float",
  &predicate_scanner_xchar__list__to__float_3
};

extern Const struct predicate predicate_scanner_xatom__chars_2;
static Const struct predinfo predinfo_scanner_xatom__chars_2 = {
  (unsigned char *)"atom_chars",
  &predicate_scanner_xatom__chars_2
};

static Const struct predinfo * Const preds_in_scanner[] = {
  &predinfo_scanner_xungetc_3,
  &predinfo_scanner_xscan__unsigned__exponent_9,
  &predinfo_scanner_xscan__string_8,
  &predinfo_scanner_xscan__string_2F8_240_8,
  &predinfo_scanner_xscan__sname_7,
  &predinfo_scanner_xscan__rest_4,
  &predinfo_scanner_xscan__octal__escape__2_9,
  &predinfo_scanner_xscan__octal__escape__2_2F9_240_9,
  &predinfo_scanner_xscan__octal__escape_9,
  &predinfo_scanner_xscan__number_9,
  &predinfo_scanner_xscan__number_2F9_241_8,
  &predinfo_scanner_xscan__number_2F9_240_9,
  &predinfo_scanner_xscan__name_7,
  &predinfo_scanner_xscan__hex__escape_9,
  &predinfo_scanner_xscan__fraction_9,
  &predinfo_scanner_xscan__fraction_2F9_240_11,
  &predinfo_scanner_xscan__exponent_9,
  &predinfo_scanner_xscan__escape_8,
  &predinfo_scanner_xscan__comment__line_5,
  &predinfo_scanner_xscan__comment_5,
  &predinfo_scanner_xscan__comment_2F5_240_5,
  &predinfo_scanner_xscan__based__number_9,
  &predinfo_scanner_xscan__based__number_2F9_242_9,
  &predinfo_scanner_xscan__based__number_2F9_241_9,
  &predinfo_scanner_xscan__based__number_2F9_240_9,
  &predinfo_scanner_xscan__after__atom_8,
  &predinfo_scanner_xscan_6,
  &predinfo_scanner_xscan_3,
  &predinfo_scanner_xscan_2F6_243_7,
  &predinfo_scanner_xscan_2F6_243_2F7_240_7,
  &predinfo_scanner_xscan_2F6_242_8,
  &predinfo_scanner_xscan_2F6_241_8,
  &predinfo_scanner_xscan_2F6_240_6,
  &predinfo_scanner_xmake__new__string_2,
  &predinfo_scanner_xlookup__var_8,
  &predinfo_scanner_xgetchar_4,
  &predinfo_scanner_xget0_3,
  &predinfo_scanner_xfinalize__vars_2F1_240_2,
  &predinfo_scanner_xfinalize__vars_1,
  &predinfo_scanner_xescape__char_2,
  &predinfo_scanner_xchartype_2,
  &predinfo_scanner_xchar__list__to__int_3,
  &predinfo_scanner_xchar__list__to__float_3,
  &predinfo_scanner_xatom__chars_2,
  0
};
extern Const struct predicate predicate_variable_xwrap__vec__elems_4;
static Const struct predinfo predinfo_variable_xwrap__vec__elems_4 = {
  (unsigned char *)"wrap_vec_elems",
  &predicate_variable_xwrap__vec__elems_4
};

extern Const struct predicate predicate_variable_xwrap__funct__elems_6;
static Const struct predinfo predinfo_variable_xwrap__funct__elems_6 = {
  (unsigned char *)"wrap_funct_elems",
  &predicate_variable_xwrap__funct__elems_6
};

extern Const struct predicate predicate_variable_xwrap__bound_2;
static Const struct predinfo predinfo_variable_xwrap__bound_2 = {
  (unsigned char *)"wrap_bound",
  &predicate_variable_xwrap__bound_2
};

extern Const struct predicate predicate_variable_xwrap_2F2_240_3;
static Const struct predinfo predinfo_variable_xwrap_2F2_240_3 = {
  (unsigned char *)"wrap/2$0",
  &predicate_variable_xwrap_2F2_240_3
};

extern Const struct predicate predicate_variable_xwrap_2;
static Const struct predinfo predinfo_variable_xwrap_2 = {
  (unsigned char *)"wrap",
  &predicate_variable_xwrap_2
};

extern Const struct predicate predicate_variable_xunwrap__vector_6;
static Const struct predinfo predinfo_variable_xunwrap__vector_6 = {
  (unsigned char *)"unwrap_vector",
  &predicate_variable_xunwrap__vector_6
};

extern Const struct predicate predicate_variable_xunwrap__functor_8;
static Const struct predinfo predinfo_variable_xunwrap__functor_8 = {
  (unsigned char *)"unwrap_functor",
  &predicate_variable_xunwrap__functor_8
};

extern Const struct predicate predicate_variable_xunwrap_4;
static Const struct predinfo predinfo_variable_xunwrap_4 = {
  (unsigned char *)"unwrap",
  &predicate_variable_xunwrap_4
};

extern Const struct predicate predicate_variable_xunwrap_3;
static Const struct predinfo predinfo_variable_xunwrap_3 = {
  (unsigned char *)"unwrap",
  &predicate_variable_xunwrap_3
};

extern Const struct predicate predicate_variable_xunwrap_2;
static Const struct predinfo predinfo_variable_xunwrap_2 = {
  (unsigned char *)"unwrap",
  &predicate_variable_xunwrap_2
};

extern Const struct predicate predicate_variable_xunbound_2;
static Const struct predinfo predinfo_variable_xunbound_2 = {
  (unsigned char *)"unbound",
  &predicate_variable_xunbound_2
};

extern Const struct predicate predicate_variable_xget__variable_4;
static Const struct predinfo predinfo_variable_xget__variable_4 = {
  (unsigned char *)"get_variable",
  &predicate_variable_xget__variable_4
};

extern Const struct predicate predicate_variable_xget__variable2_4;
static Const struct predinfo predinfo_variable_xget__variable2_4 = {
  (unsigned char *)"get_variable2",
  &predicate_variable_xget__variable2_4
};

static Const struct predinfo * Const preds_in_variable[] = {
  &predinfo_variable_xwrap__vec__elems_4,
  &predinfo_variable_xwrap__funct__elems_6,
  &predinfo_variable_xwrap__bound_2,
  &predinfo_variable_xwrap_2F2_240_3,
  &predinfo_variable_xwrap_2,
  &predinfo_variable_xunwrap__vector_6,
  &predinfo_variable_xunwrap__functor_8,
  &predinfo_variable_xunwrap_4,
  &predinfo_variable_xunwrap_3,
  &predinfo_variable_xunwrap_2,
  &predinfo_variable_xunbound_2,
  &predinfo_variable_xget__variable_4,
  &predinfo_variable_xget__variable2_4,
  0
};
extern Const struct predicate predicate_parser_xwrap__list_2;
static Const struct predinfo predinfo_parser_xwrap__list_2 = {
  (unsigned char *)"wrap_list",
  &predicate_parser_xwrap__list_2
};

extern Const struct predicate predicate_parser_xwrap__functor_2;
static Const struct predinfo predinfo_parser_xwrap__functor_2 = {
  (unsigned char *)"wrap_functor",
  &predicate_parser_xwrap__functor_2
};

extern Const struct predicate predicate_parser_xwrap__functor1_2;
static Const struct predinfo predinfo_parser_xwrap__functor1_2 = {
  (unsigned char *)"wrap_functor1",
  &predicate_parser_xwrap__functor1_2
};

extern Const struct predicate predicate_parser_xwparse_5;
static Const struct predinfo predinfo_parser_xwparse_5 = {
  (unsigned char *)"wparse",
  &predicate_parser_xwparse_5
};

extern Const struct predicate predicate_parser_xwparse_4;
static Const struct predinfo predinfo_parser_xwparse_4 = {
  (unsigned char *)"wparse",
  &predicate_parser_xwparse_4
};

extern Const struct predicate predicate_parser_xwparse_3;
static Const struct predinfo predinfo_parser_xwparse_3 = {
  (unsigned char *)"wparse",
  &predicate_parser_xwparse_3
};

extern Const struct predicate predicate_parser_xwparse_2F5_244_5;
static Const struct predinfo predinfo_parser_xwparse_2F5_244_5 = {
  (unsigned char *)"wparse/5$4",
  &predicate_parser_xwparse_2F5_244_5
};

extern Const struct predicate predicate_parser_xwparse_2F5_244_2F5_242_2;
static Const struct predinfo predinfo_parser_xwparse_2F5_244_2F5_242_2 = {
  (unsigned char *)"wparse/5$4/5$2",
  &predicate_parser_xwparse_2F5_244_2F5_242_2
};

extern Const struct predicate predicate_parser_xwparse_2F5_244_2F5_241_5;
static Const struct predinfo predinfo_parser_xwparse_2F5_244_2F5_241_5 = {
  (unsigned char *)"wparse/5$4/5$1",
  &predicate_parser_xwparse_2F5_244_2F5_241_5
};

extern Const struct predicate predicate_parser_xwparse_2F5_244_2F5_240_6;
static Const struct predinfo predinfo_parser_xwparse_2F5_244_2F5_240_6 = {
  (unsigned char *)"wparse/5$4/5$0",
  &predicate_parser_xwparse_2F5_244_2F5_240_6
};

extern Const struct predicate predicate_parser_xwparse_2F5_244_2F5_240_2F6_240_6;
static Const struct predinfo predinfo_parser_xwparse_2F5_244_2F5_240_2F6_240_6 = {
  (unsigned char *)"wparse/5$4/5$0/6$0",
  &predicate_parser_xwparse_2F5_244_2F5_240_2F6_240_6
};

extern Const struct predicate predicate_parser_xwparse_2F5_243_5;
static Const struct predinfo predinfo_parser_xwparse_2F5_243_5 = {
  (unsigned char *)"wparse/5$3",
  &predicate_parser_xwparse_2F5_243_5
};

extern Const struct predicate predicate_parser_xwparse_2F5_242_4;
static Const struct predinfo predinfo_parser_xwparse_2F5_242_4 = {
  (unsigned char *)"wparse/5$2",
  &predicate_parser_xwparse_2F5_242_4
};

extern Const struct predicate predicate_parser_xwparse_2F5_242_2F4_240_4;
static Const struct predinfo predinfo_parser_xwparse_2F5_242_2F4_240_4 = {
  (unsigned char *)"wparse/5$2/4$0",
  &predicate_parser_xwparse_2F5_242_2F4_240_4
};

extern Const struct predicate predicate_parser_xwparse_2F5_241_4;
static Const struct predinfo predinfo_parser_xwparse_2F5_241_4 = {
  (unsigned char *)"wparse/5$1",
  &predicate_parser_xwparse_2F5_241_4
};

extern Const struct predicate predicate_parser_xwparse_2F5_241_2F4_240_4;
static Const struct predinfo predinfo_parser_xwparse_2F5_241_2F4_240_4 = {
  (unsigned char *)"wparse/5$1/4$0",
  &predicate_parser_xwparse_2F5_241_2F4_240_4
};

extern Const struct predicate predicate_parser_xwparse_2F5_240_4;
static Const struct predinfo predinfo_parser_xwparse_2F5_240_4 = {
  (unsigned char *)"wparse/5$0",
  &predicate_parser_xwparse_2F5_240_4
};

extern Const struct predicate predicate_parser_xwparse_2F5_240_2F4_240_5;
static Const struct predinfo predinfo_parser_xwparse_2F5_240_2F4_240_5 = {
  (unsigned char *)"wparse/5$0/4$0",
  &predicate_parser_xwparse_2F5_240_2F4_240_5
};

extern Const struct predicate predicate_parser_xwait__parse_2F2_240_2;
static Const struct predinfo predinfo_parser_xwait__parse_2F2_240_2 = {
  (unsigned char *)"wait_parse/2$0",
  &predicate_parser_xwait__parse_2F2_240_2
};

extern Const struct predicate predicate_parser_xwait__parse_2;
static Const struct predinfo predinfo_parser_xwait__parse_2 = {
  (unsigned char *)"wait_parse",
  &predicate_parser_xwait__parse_2
};

extern Const struct predicate predicate_parser_xunwrap_2;
static Const struct predinfo predinfo_parser_xunwrap_2 = {
  (unsigned char *)"unwrap",
  &predicate_parser_xunwrap_2
};

extern Const struct predicate predicate_parser_xselect__better_3;
static Const struct predinfo predinfo_parser_xselect__better_3 = {
  (unsigned char *)"select_better",
  &predicate_parser_xselect__better_3
};

extern Const struct predicate predicate_parser_xselect__better_2F3_241_4;
static Const struct predinfo predinfo_parser_xselect__better_2F3_241_4 = {
  (unsigned char *)"select_better/3$1",
  &predicate_parser_xselect__better_2F3_241_4
};

extern Const struct predicate predicate_parser_xselect__better_2F3_240_4;
static Const struct predinfo predinfo_parser_xselect__better_2F3_240_4 = {
  (unsigned char *)"select_better/3$0",
  &predicate_parser_xselect__better_2F3_240_4
};

extern Const struct predicate predicate_parser_xprefixop_4;
static Const struct predinfo predinfo_parser_xprefixop_4 = {
  (unsigned char *)"prefixop",
  &predicate_parser_xprefixop_4
};

extern Const struct predicate predicate_parser_xprefixop_2F4_240_4;
static Const struct predinfo predinfo_parser_xprefixop_2F4_240_4 = {
  (unsigned char *)"prefixop/4$0",
  &predicate_parser_xprefixop_2F4_240_4
};

extern Const struct predicate predicate_parser_xpostfixop_5;
static Const struct predinfo predinfo_parser_xpostfixop_5 = {
  (unsigned char *)"postfixop",
  &predicate_parser_xpostfixop_5
};

extern Const struct predicate predicate_parser_xpostfixop_2F5_240_5;
static Const struct predinfo predinfo_parser_xpostfixop_2F5_240_5 = {
  (unsigned char *)"postfixop/5$0",
  &predicate_parser_xpostfixop_2F5_240_5
};

extern Const struct predicate predicate_parser_xparse__comma__list_8;
static Const struct predinfo predinfo_parser_xparse__comma__list_8 = {
  (unsigned char *)"parse_comma_list",
  &predicate_parser_xparse__comma__list_8
};

extern Const struct predicate predicate_parser_xparse__comma__list_6;
static Const struct predinfo predinfo_parser_xparse__comma__list_6 = {
  (unsigned char *)"parse_comma_list",
  &predicate_parser_xparse__comma__list_6
};

extern Const struct predicate predicate_parser_xparse__comma__list_2F8_240_8;
static Const struct predinfo predinfo_parser_xparse__comma__list_2F8_240_8 = {
  (unsigned char *)"parse_comma_list/8$0",
  &predicate_parser_xparse__comma__list_2F8_240_8
};

extern Const struct predicate predicate_parser_xparse__comma__list_2F8_240_2F8_240_8;
static Const struct predinfo predinfo_parser_xparse__comma__list_2F8_240_2F8_240_8 = {
  (unsigned char *)"parse_comma_list/8$0/8$0",
  &predicate_parser_xparse__comma__list_2F8_240_2F8_240_8
};

extern Const struct predicate predicate_parser_xparse__comma__list_2F8_240_2F8_240_2F8_240_5;
static Const struct predinfo predinfo_parser_xparse__comma__list_2F8_240_2F8_240_2F8_240_5 = {
  (unsigned char *)"parse_comma_list/8$0/8$0/8$0",
  &predicate_parser_xparse__comma__list_2F8_240_2F8_240_2F8_240_5
};

extern Const struct predicate predicate_parser_xparse__comma__list_2F8_240_2F8_240_2F8_240_2F5_240_4;
static Const struct predinfo predinfo_parser_xparse__comma__list_2F8_240_2F8_240_2F8_240_2F5_240_4 = {
  (unsigned char *)"parse_comma_list/8$0/8$0/8$0/5$0",
  &predicate_parser_xparse__comma__list_2F8_240_2F8_240_2F8_240_2F5_240_4
};

extern Const struct predicate predicate_parser_xparse_3;
static Const struct predinfo predinfo_parser_xparse_3 = {
  (unsigned char *)"parse",
  &predicate_parser_xparse_3
};

extern Const struct predicate predicate_parser_xlookup__op_4;
static Const struct predinfo predinfo_parser_xlookup__op_4 = {
  (unsigned char *)"lookup_op",
  &predicate_parser_xlookup__op_4
};

extern Const struct predicate predicate_parser_xlonger_3;
static Const struct predinfo predinfo_parser_xlonger_3 = {
  (unsigned char *)"longer",
  &predicate_parser_xlonger_3
};

extern Const struct predicate predicate_parser_xlist__to__comma__list_2;
static Const struct predinfo predinfo_parser_xlist__to__comma__list_2 = {
  (unsigned char *)"list_to_comma_list",
  &predicate_parser_xlist__to__comma__list_2
};

extern Const struct predicate predicate_parser_xlast__check_2;
static Const struct predinfo predinfo_parser_xlast__check_2 = {
  (unsigned char *)"last_check",
  &predicate_parser_xlast__check_2
};

extern Const struct predicate predicate_parser_xinfixop_5;
static Const struct predinfo predinfo_parser_xinfixop_5 = {
  (unsigned char *)"infixop",
  &predicate_parser_xinfixop_5
};

extern Const struct predicate predicate_parser_xinfixop_2F5_240_5;
static Const struct predinfo predinfo_parser_xinfixop_2F5_240_5 = {
  (unsigned char *)"infixop/5$0",
  &predicate_parser_xinfixop_2F5_240_5
};

extern Const struct predicate predicate_parser_xafter__term_6;
static Const struct predinfo predinfo_parser_xafter__term_6 = {
  (unsigned char *)"after_term",
  &predicate_parser_xafter__term_6
};

extern Const struct predicate predicate_parser_xafter__term_2F6_242_8;
static Const struct predinfo predinfo_parser_xafter__term_2F6_242_8 = {
  (unsigned char *)"after_term/6$2",
  &predicate_parser_xafter__term_2F6_242_8
};

extern Const struct predicate predicate_parser_xafter__term_2F6_242_2F8_241_7;
static Const struct predinfo predinfo_parser_xafter__term_2F6_242_2F8_241_7 = {
  (unsigned char *)"after_term/6$2/8$1",
  &predicate_parser_xafter__term_2F6_242_2F8_241_7
};

extern Const struct predicate predicate_parser_xafter__term_2F6_242_2F8_240_9;
static Const struct predinfo predinfo_parser_xafter__term_2F6_242_2F8_240_9 = {
  (unsigned char *)"after_term/6$2/8$0",
  &predicate_parser_xafter__term_2F6_242_2F8_240_9
};

extern Const struct predicate predicate_parser_xafter__term_2F6_242_2F8_240_2F9_240_7;
static Const struct predinfo predinfo_parser_xafter__term_2F6_242_2F8_240_2F9_240_7 = {
  (unsigned char *)"after_term/6$2/8$0/9$0",
  &predicate_parser_xafter__term_2F6_242_2F8_240_2F9_240_7
};

extern Const struct predicate predicate_parser_xafter__term_2F6_241_5;
static Const struct predinfo predinfo_parser_xafter__term_2F6_241_5 = {
  (unsigned char *)"after_term/6$1",
  &predicate_parser_xafter__term_2F6_241_5
};

extern Const struct predicate predicate_parser_xafter__term_2F6_240_5;
static Const struct predinfo predinfo_parser_xafter__term_2F6_240_5 = {
  (unsigned char *)"after_term/6$0",
  &predicate_parser_xafter__term_2F6_240_5
};

static Const struct predinfo * Const preds_in_parser[] = {
  &predinfo_parser_xwrap__list_2,
  &predinfo_parser_xwrap__functor_2,
  &predinfo_parser_xwrap__functor1_2,
  &predinfo_parser_xwparse_5,
  &predinfo_parser_xwparse_4,
  &predinfo_parser_xwparse_3,
  &predinfo_parser_xwparse_2F5_244_5,
  &predinfo_parser_xwparse_2F5_244_2F5_242_2,
  &predinfo_parser_xwparse_2F5_244_2F5_241_5,
  &predinfo_parser_xwparse_2F5_244_2F5_240_6,
  &predinfo_parser_xwparse_2F5_244_2F5_240_2F6_240_6,
  &predinfo_parser_xwparse_2F5_243_5,
  &predinfo_parser_xwparse_2F5_242_4,
  &predinfo_parser_xwparse_2F5_242_2F4_240_4,
  &predinfo_parser_xwparse_2F5_241_4,
  &predinfo_parser_xwparse_2F5_241_2F4_240_4,
  &predinfo_parser_xwparse_2F5_240_4,
  &predinfo_parser_xwparse_2F5_240_2F4_240_5,
  &predinfo_parser_xwait__parse_2F2_240_2,
  &predinfo_parser_xwait__parse_2,
  &predinfo_parser_xunwrap_2,
  &predinfo_parser_xselect__better_3,
  &predinfo_parser_xselect__better_2F3_241_4,
  &predinfo_parser_xselect__better_2F3_240_4,
  &predinfo_parser_xprefixop_4,
  &predinfo_parser_xprefixop_2F4_240_4,
  &predinfo_parser_xpostfixop_5,
  &predinfo_parser_xpostfixop_2F5_240_5,
  &predinfo_parser_xparse__comma__list_8,
  &predinfo_parser_xparse__comma__list_6,
  &predinfo_parser_xparse__comma__list_2F8_240_8,
  &predinfo_parser_xparse__comma__list_2F8_240_2F8_240_8,
  &predinfo_parser_xparse__comma__list_2F8_240_2F8_240_2F8_240_5,
  &predinfo_parser_xparse__comma__list_2F8_240_2F8_240_2F8_240_2F5_240_4,
  &predinfo_parser_xparse_3,
  &predinfo_parser_xlookup__op_4,
  &predinfo_parser_xlonger_3,
  &predinfo_parser_xlist__to__comma__list_2,
  &predinfo_parser_xlast__check_2,
  &predinfo_parser_xinfixop_5,
  &predinfo_parser_xinfixop_2F5_240_5,
  &predinfo_parser_xafter__term_6,
  &predinfo_parser_xafter__term_2F6_242_8,
  &predinfo_parser_xafter__term_2F6_242_2F8_241_7,
  &predinfo_parser_xafter__term_2F6_242_2F8_240_9,
  &predinfo_parser_xafter__term_2F6_242_2F8_240_2F9_240_7,
  &predinfo_parser_xafter__term_2F6_241_5,
  &predinfo_parser_xafter__term_2F6_240_5,
  0
};
extern Const struct predicate predicate_klic__reader_xwrite__tokens_4;
static Const struct predinfo predinfo_klic__reader_xwrite__tokens_4 = {
  (unsigned char *)"write_tokens",
  &predicate_klic__reader_xwrite__tokens_4
};

extern Const struct predicate predicate_klic__reader_xwrite__string_3;
static Const struct predinfo predinfo_klic__reader_xwrite__string_3 = {
  (unsigned char *)"write_string",
  &predicate_klic__reader_xwrite__string_3
};

extern Const struct predicate predicate_klic__reader_xwrite__one__token_3;
static Const struct predinfo predinfo_klic__reader_xwrite__one__token_3 = {
  (unsigned char *)"write_one_token",
  &predicate_klic__reader_xwrite__one__token_3
};

extern Const struct predicate predicate_klic__reader_xwrite__number_3;
static Const struct predinfo predinfo_klic__reader_xwrite__number_3 = {
  (unsigned char *)"write_number",
  &predicate_klic__reader_xwrite__number_3
};

extern Const struct predicate predicate_klic__reader_xwrite__decimal_3;
static Const struct predinfo predinfo_klic__reader_xwrite__decimal_3 = {
  (unsigned char *)"write_decimal",
  &predicate_klic__reader_xwrite__decimal_3
};

extern Const struct predicate predicate_klic__reader_xwrite__char_3;
static Const struct predinfo predinfo_klic__reader_xwrite__char_3 = {
  (unsigned char *)"write_char",
  &predicate_klic__reader_xwrite__char_3
};

extern Const struct predicate predicate_klic__reader_xwrite__atom_3;
static Const struct predinfo predinfo_klic__reader_xwrite__atom_3 = {
  (unsigned char *)"write_atom",
  &predicate_klic__reader_xwrite__atom_3
};

extern Const struct predicate predicate_klic__reader_xwparse__one__term__reporting__errors_4;
static Const struct predinfo predinfo_klic__reader_xwparse__one__term__reporting__errors_4 = {
  (unsigned char *)"wparse_one_term_reporting_errors",
  &predicate_klic__reader_xwparse__one__term__reporting__errors_4
};

extern Const struct predicate predicate_klic__reader_xwparse__one__term__reporting__errors_2F4_240_8;
static Const struct predinfo predinfo_klic__reader_xwparse__one__term__reporting__errors_2F4_240_8 = {
  (unsigned char *)"wparse_one_term_reporting_errors/4$0",
  &predicate_klic__reader_xwparse__one__term__reporting__errors_2F4_240_8
};

extern Const struct predicate predicate_klic__reader_xreport__syntax__error_7;
static Const struct predinfo predinfo_klic__reader_xreport__syntax__error_7 = {
  (unsigned char *)"report_syntax_error",
  &predicate_klic__reader_xreport__syntax__error_7
};

extern Const struct predicate predicate_klic__reader_xreport__syntax__error_2F7_240_2;
static Const struct predinfo predinfo_klic__reader_xreport__syntax__error_2F7_240_2 = {
  (unsigned char *)"report_syntax_error/7$0",
  &predicate_klic__reader_xreport__syntax__error_2F7_240_2
};

extern Const struct predicate predicate_klic__reader_xparse__one__term__reporting__errors_4;
static Const struct predinfo predinfo_klic__reader_xparse__one__term__reporting__errors_4 = {
  (unsigned char *)"parse_one_term_reporting_errors",
  &predicate_klic__reader_xparse__one__term__reporting__errors_4
};

extern Const struct predicate predicate_klic__reader_xparse__one__term__reporting__errors_2F4_240_8;
static Const struct predinfo predinfo_klic__reader_xparse__one__term__reporting__errors_2F4_240_8 = {
  (unsigned char *)"parse_one_term_reporting_errors/4$0",
  &predicate_klic__reader_xparse__one__term__reporting__errors_2F4_240_8
};

extern Const struct predicate predicate_klic__reader_xlength_3;
static Const struct predinfo predinfo_klic__reader_xlength_3 = {
  (unsigned char *)"length",
  &predicate_klic__reader_xlength_3
};

extern Const struct predicate predicate_klic__reader_xlength_2;
static Const struct predinfo predinfo_klic__reader_xlength_2 = {
  (unsigned char *)"length",
  &predicate_klic__reader_xlength_2
};

extern Const struct predicate predicate_klic__reader_xblank_2;
static Const struct predinfo predinfo_klic__reader_xblank_2 = {
  (unsigned char *)"blank",
  &predicate_klic__reader_xblank_2
};

static Const struct predinfo * Const preds_in_klic__reader[] = {
  &predinfo_klic__reader_xwrite__tokens_4,
  &predinfo_klic__reader_xwrite__string_3,
  &predinfo_klic__reader_xwrite__one__token_3,
  &predinfo_klic__reader_xwrite__number_3,
  &predinfo_klic__reader_xwrite__decimal_3,
  &predinfo_klic__reader_xwrite__char_3,
  &predinfo_klic__reader_xwrite__atom_3,
  &predinfo_klic__reader_xwparse__one__term__reporting__errors_4,
  &predinfo_klic__reader_xwparse__one__term__reporting__errors_2F4_240_8,
  &predinfo_klic__reader_xreport__syntax__error_7,
  &predinfo_klic__reader_xreport__syntax__error_2F7_240_2,
  &predinfo_klic__reader_xparse__one__term__reporting__errors_4,
  &predinfo_klic__reader_xparse__one__term__reporting__errors_2F4_240_8,
  &predinfo_klic__reader_xlength_3,
  &predinfo_klic__reader_xlength_2,
  &predinfo_klic__reader_xblank_2,
  0
};
extern Const struct predicate predicate_klicio_xupdt_3;
static Const struct predinfo predinfo_klicio_xupdt_3 = {
  (unsigned char *)"updt",
  &predicate_klicio_xupdt_3
};

extern Const struct predicate predicate_klicio_xupdate__lc_3;
static Const struct predinfo predinfo_klicio_xupdate__lc_3 = {
  (unsigned char *)"update_lc",
  &predicate_klicio_xupdate__lc_3
};

extern Const struct predicate predicate_klicio_xtermupdt_2;
static Const struct predinfo predinfo_klicio_xtermupdt_2 = {
  (unsigned char *)"termupdt",
  &predicate_klicio_xtermupdt_2
};

extern Const struct predicate predicate_klicio_xtermout_2;
static Const struct predinfo predinfo_klicio_xtermout_2 = {
  (unsigned char *)"termout",
  &predicate_klicio_xtermout_2
};

extern Const struct predicate predicate_klicio_xtermin_2;
static Const struct predinfo predinfo_klicio_xtermin_2 = {
  (unsigned char *)"termin",
  &predicate_klicio_xtermin_2
};

extern Const struct predicate predicate_klicio_xstring__output_4;
static Const struct predinfo predinfo_klicio_xstring__output_4 = {
  (unsigned char *)"string_output",
  &predicate_klicio_xstring__output_4
};

extern Const struct predicate predicate_klicio_xstring__input_5;
static Const struct predinfo predinfo_klicio_xstring__input_5 = {
  (unsigned char *)"string_input",
  &predicate_klicio_xstring__input_5
};

extern Const struct predicate predicate_klicio_xset__string__elements_6;
static Const struct predinfo predinfo_klicio_xset__string__elements_6 = {
  (unsigned char *)"set_string_elements",
  &predicate_klicio_xset__string__elements_6
};

extern Const struct predicate predicate_klicio_xsend__unix_3;
static Const struct predinfo predinfo_klicio_xsend__unix_3 = {
  (unsigned char *)"send_unix",
  &predicate_klicio_xsend__unix_3
};

extern Const struct predicate predicate_klicio_xrmop_4;
static Const struct predinfo predinfo_klicio_xrmop_4 = {
  (unsigned char *)"rmop",
  &predicate_klicio_xrmop_4
};

extern Const struct predicate predicate_klicio_xrmop2_4;
static Const struct predinfo predinfo_klicio_xrmop2_4 = {
  (unsigned char *)"rmop2",
  &predicate_klicio_xrmop2_4
};

extern Const struct predicate predicate_klicio_xoutput__stream_2;
static Const struct predinfo predinfo_klicio_xoutput__stream_2 = {
  (unsigned char *)"output_stream",
  &predicate_klicio_xoutput__stream_2
};

extern Const struct predicate predicate_klicio_xout_3;
static Const struct predinfo predinfo_klicio_xout_3 = {
  (unsigned char *)"out",
  &predicate_klicio_xout_3
};

extern Const struct predicate predicate_klicio_xklicio_2;
static Const struct predinfo predinfo_klicio_xklicio_2 = {
  (unsigned char *)"klicio",
  &predicate_klicio_xklicio_2
};

extern Const struct predicate predicate_klicio_xklicio_1;
static Const struct predinfo predinfo_klicio_xklicio_1 = {
  (unsigned char *)"klicio",
  &predicate_klicio_xklicio_1
};

extern Const struct predicate predicate_klicio_xin_3;
static Const struct predinfo predinfo_klicio_xin_3 = {
  (unsigned char *)"in",
  &predicate_klicio_xin_3
};

extern Const struct predicate predicate_klicio_xfill__string_4;
static Const struct predinfo predinfo_klicio_xfill__string_4 = {
  (unsigned char *)"fill_string",
  &predicate_klicio_xfill__string_4
};

extern Const struct predicate predicate_klicio_xdefault__operator__table_1;
static Const struct predinfo predinfo_klicio_xdefault__operator__table_1 = {
  (unsigned char *)"default_operator_table",
  &predicate_klicio_xdefault__operator__table_1
};

extern Const struct predicate predicate_klicio_xcompute__string__length_3;
static Const struct predinfo predinfo_klicio_xcompute__string__length_3 = {
  (unsigned char *)"compute_string_length",
  &predicate_klicio_xcompute__string__length_3
};

extern Const struct predicate predicate_klicio_xclose__unix_1;
static Const struct predinfo predinfo_klicio_xclose__unix_1 = {
  (unsigned char *)"close_unix",
  &predicate_klicio_xclose__unix_1
};

extern Const struct predicate predicate_klicio_xaddop_5;
static Const struct predinfo predinfo_klicio_xaddop_5 = {
  (unsigned char *)"addop",
  &predicate_klicio_xaddop_5
};

extern Const struct predicate predicate_klicio_xaddop2_5;
static Const struct predinfo predinfo_klicio_xaddop2_5 = {
  (unsigned char *)"addop2",
  &predicate_klicio_xaddop2_5
};

static Const struct predinfo * Const preds_in_klicio[] = {
  &predinfo_klicio_xupdt_3,
  &predinfo_klicio_xupdate__lc_3,
  &predinfo_klicio_xtermupdt_2,
  &predinfo_klicio_xtermout_2,
  &predinfo_klicio_xtermin_2,
  &predinfo_klicio_xstring__output_4,
  &predinfo_klicio_xstring__input_5,
  &predinfo_klicio_xset__string__elements_6,
  &predinfo_klicio_xsend__unix_3,
  &predinfo_klicio_xrmop_4,
  &predinfo_klicio_xrmop2_4,
  &predinfo_klicio_xoutput__stream_2,
  &predinfo_klicio_xout_3,
  &predinfo_klicio_xklicio_2,
  &predinfo_klicio_xklicio_1,
  &predinfo_klicio_xin_3,
  &predinfo_klicio_xfill__string_4,
  &predinfo_klicio_xdefault__operator__table_1,
  &predinfo_klicio_xcompute__string__length_3,
  &predinfo_klicio_xclose__unix_1,
  &predinfo_klicio_xaddop_5,
  &predinfo_klicio_xaddop2_5,
  0
};
extern Const struct predicate predicate_util_xtoLower_2;
static Const struct predinfo predinfo_util_xtoLower_2 = {
  (unsigned char *)"toLower",
  &predicate_util_xtoLower_2
};

extern Const struct predicate predicate_util_xtabToSP_2;
static Const struct predinfo predinfo_util_xtabToSP_2 = {
  (unsigned char *)"tabToSP",
  &predicate_util_xtabToSP_2
};

extern Const struct predicate predicate_util_xstringJoin_3;
static Const struct predinfo predinfo_util_xstringJoin_3 = {
  (unsigned char *)"stringJoin",
  &predicate_util_xstringJoin_3
};

extern Const struct predicate predicate_util_xstringJoin_2;
static Const struct predinfo predinfo_util_xstringJoin_2 = {
  (unsigned char *)"stringJoin",
  &predicate_util_xstringJoin_2
};

extern Const struct predicate predicate_util_xstrToLst_3;
static Const struct predinfo predinfo_util_xstrToLst_3 = {
  (unsigned char *)"strToLst",
  &predicate_util_xstrToLst_3
};

extern Const struct predicate predicate_util_xstrToLst_2;
static Const struct predinfo predinfo_util_xstrToLst_2 = {
  (unsigned char *)"strToLst",
  &predicate_util_xstrToLst_2
};

extern Const struct predicate predicate_util_xstrToLst1_5;
static Const struct predinfo predinfo_util_xstrToLst1_5 = {
  (unsigned char *)"strToLst1",
  &predicate_util_xstrToLst1_5
};

extern Const struct predicate predicate_util_xskipSP_2;
static Const struct predinfo predinfo_util_xskipSP_2 = {
  (unsigned char *)"skipSP",
  &predicate_util_xskipSP_2
};

extern Const struct predicate predicate_util_xshowReached_1;
static Const struct predinfo predinfo_util_xshowReached_1 = {
  (unsigned char *)"showReached",
  &predicate_util_xshowReached_1
};

extern Const struct predicate predicate_util_xshowCommand_1;
static Const struct predinfo predinfo_util_xshowCommand_1 = {
  (unsigned char *)"showCommand",
  &predicate_util_xshowCommand_1
};

extern Const struct predicate predicate_util_xshowCommand1_2;
static Const struct predinfo predinfo_util_xshowCommand1_2 = {
  (unsigned char *)"showCommand1",
  &predicate_util_xshowCommand1_2
};

extern Const struct predicate predicate_util_xrmRedundantSP_2;
static Const struct predinfo predinfo_util_xrmRedundantSP_2 = {
  (unsigned char *)"rmRedundantSP",
  &predicate_util_xrmRedundantSP_2
};

extern Const struct predicate predicate_util_xrmLastLf_2;
static Const struct predinfo predinfo_util_xrmLastLf_2 = {
  (unsigned char *)"rmLastLf",
  &predicate_util_xrmLastLf_2
};

extern Const struct predicate predicate_util_xrmFirstSP_2;
static Const struct predinfo predinfo_util_xrmFirstSP_2 = {
  (unsigned char *)"rmFirstSP",
  &predicate_util_xrmFirstSP_2
};

extern Const struct predicate predicate_util_xrmFirstLf_2;
static Const struct predinfo predinfo_util_xrmFirstLf_2 = {
  (unsigned char *)"rmFirstLf",
  &predicate_util_xrmFirstLf_2
};

extern Const struct predicate predicate_util_xrev_3;
static Const struct predinfo predinfo_util_xrev_3 = {
  (unsigned char *)"rev",
  &predicate_util_xrev_3
};

extern Const struct predicate predicate_util_xrev_2;
static Const struct predinfo predinfo_util_xrev_2 = {
  (unsigned char *)"rev",
  &predicate_util_xrev_2
};

extern Const struct predicate predicate_util_xmin_3;
static Const struct predinfo predinfo_util_xmin_3 = {
  (unsigned char *)"min",
  &predicate_util_xmin_3
};

extern Const struct predicate predicate_util_xmerge_3;
static Const struct predinfo predinfo_util_xmerge_3 = {
  (unsigned char *)"merge",
  &predicate_util_xmerge_3
};

extern Const struct predicate predicate_util_xlstToStrs_2;
static Const struct predinfo predinfo_util_xlstToStrs_2 = {
  (unsigned char *)"lstToStrs",
  &predicate_util_xlstToStrs_2
};

extern Const struct predicate predicate_util_xlstToAtom_2;
static Const struct predinfo predinfo_util_xlstToAtom_2 = {
  (unsigned char *)"lstToAtom",
  &predicate_util_xlstToAtom_2
};

extern Const struct predicate predicate_util_xlosToLst_2;
static Const struct predinfo predinfo_util_xlosToLst_2 = {
  (unsigned char *)"losToLst",
  &predicate_util_xlosToLst_2
};

extern Const struct predicate predicate_util_xisMember_3;
static Const struct predinfo predinfo_util_xisMember_3 = {
  (unsigned char *)"isMember",
  &predicate_util_xisMember_3
};

extern Const struct predicate predicate_util_xgetSuffix_2F2_240_3;
static Const struct predinfo predinfo_util_xgetSuffix_2F2_240_3 = {
  (unsigned char *)"getSuffix/2$0",
  &predicate_util_xgetSuffix_2F2_240_3
};

extern Const struct predicate predicate_util_xgetSuffix_2F2_240_2F3_240_3;
static Const struct predinfo predinfo_util_xgetSuffix_2F2_240_2F3_240_3 = {
  (unsigned char *)"getSuffix/2$0/3$0",
  &predicate_util_xgetSuffix_2F2_240_2F3_240_3
};

extern Const struct predicate predicate_util_xgetSuffix_2;
static Const struct predinfo predinfo_util_xgetSuffix_2 = {
  (unsigned char *)"getSuffix",
  &predicate_util_xgetSuffix_2
};

extern Const struct predicate predicate_util_xgetCarCdr_3;
static Const struct predinfo predinfo_util_xgetCarCdr_3 = {
  (unsigned char *)"getCarCdr",
  &predicate_util_xgetCarCdr_3
};

extern Const struct predicate predicate_util_xcrlfToSP_2;
static Const struct predinfo predinfo_util_xcrlfToSP_2 = {
  (unsigned char *)"crlfToSP",
  &predicate_util_xcrlfToSP_2
};

extern Const struct predicate predicate_util_xcrlfToLf_2;
static Const struct predinfo predinfo_util_xcrlfToLf_2 = {
  (unsigned char *)"crlfToLf",
  &predicate_util_xcrlfToLf_2
};

extern Const struct predicate predicate_util_xatoi_2;
static Const struct predinfo predinfo_util_xatoi_2 = {
  (unsigned char *)"atoi",
  &predicate_util_xatoi_2
};

extern Const struct predicate predicate_util_xatoi1_3;
static Const struct predinfo predinfo_util_xatoi1_3 = {
  (unsigned char *)"atoi1",
  &predicate_util_xatoi1_3
};

extern Const struct predicate predicate_util_xappend_3;
static Const struct predinfo predinfo_util_xappend_3 = {
  (unsigned char *)"append",
  &predicate_util_xappend_3
};

static Const struct predinfo * Const preds_in_util[] = {
  &predinfo_util_xtoLower_2,
  &predinfo_util_xtabToSP_2,
  &predinfo_util_xstringJoin_3,
  &predinfo_util_xstringJoin_2,
  &predinfo_util_xstrToLst_3,
  &predinfo_util_xstrToLst_2,
  &predinfo_util_xstrToLst1_5,
  &predinfo_util_xskipSP_2,
  &predinfo_util_xshowReached_1,
  &predinfo_util_xshowCommand_1,
  &predinfo_util_xshowCommand1_2,
  &predinfo_util_xrmRedundantSP_2,
  &predinfo_util_xrmLastLf_2,
  &predinfo_util_xrmFirstSP_2,
  &predinfo_util_xrmFirstLf_2,
  &predinfo_util_xrev_3,
  &predinfo_util_xrev_2,
  &predinfo_util_xmin_3,
  &predinfo_util_xmerge_3,
  &predinfo_util_xlstToStrs_2,
  &predinfo_util_xlstToAtom_2,
  &predinfo_util_xlosToLst_2,
  &predinfo_util_xisMember_3,
  &predinfo_util_xgetSuffix_2F2_240_3,
  &predinfo_util_xgetSuffix_2F2_240_2F3_240_3,
  &predinfo_util_xgetSuffix_2,
  &predinfo_util_xgetCarCdr_3,
  &predinfo_util_xcrlfToSP_2,
  &predinfo_util_xcrlfToLf_2,
  &predinfo_util_xatoi_2,
  &predinfo_util_xatoi1_3,
  &predinfo_util_xappend_3,
  0
};
extern Const struct predicate predicate_unwrap_xunwraparg_4;
static Const struct predinfo predinfo_unwrap_xunwraparg_4 = {
  (unsigned char *)"unwraparg",
  &predicate_unwrap_xunwraparg_4
};

extern Const struct predicate predicate_unwrap_xunwraparg_3;
static Const struct predinfo predinfo_unwrap_xunwraparg_3 = {
  (unsigned char *)"unwraparg",
  &predicate_unwrap_xunwraparg_3
};

extern Const struct predicate predicate_unwrap_xunwrap_2;
static Const struct predinfo predinfo_unwrap_xunwrap_2 = {
  (unsigned char *)"unwrap",
  &predicate_unwrap_xunwrap_2
};

extern Const struct predicate predicate_unwrap_xunwrap1_2;
static Const struct predinfo predinfo_unwrap_xunwrap1_2 = {
  (unsigned char *)"unwrap1",
  &predicate_unwrap_xunwrap1_2
};

extern Const struct predicate predicate_unwrap_xunlist_2;
static Const struct predinfo predinfo_unwrap_xunlist_2 = {
  (unsigned char *)"unlist",
  &predicate_unwrap_xunlist_2
};

extern Const struct predicate predicate_unwrap_xunlist1_3;
static Const struct predinfo predinfo_unwrap_xunlist1_3 = {
  (unsigned char *)"unlist1",
  &predicate_unwrap_xunlist1_3
};

extern Const struct predicate predicate_unwrap_xunlist1_2;
static Const struct predinfo predinfo_unwrap_xunlist1_2 = {
  (unsigned char *)"unlist1",
  &predicate_unwrap_xunlist1_2
};

extern Const struct predicate predicate_unwrap_xreverse_2;
static Const struct predinfo predinfo_unwrap_xreverse_2 = {
  (unsigned char *)"reverse",
  &predicate_unwrap_xreverse_2
};

extern Const struct predicate predicate_unwrap_xreverse1_3;
static Const struct predinfo predinfo_unwrap_xreverse1_3 = {
  (unsigned char *)"reverse1",
  &predicate_unwrap_xreverse1_3
};

extern Const struct predicate predicate_unwrap_xreverse1_2;
static Const struct predinfo predinfo_unwrap_xreverse1_2 = {
  (unsigned char *)"reverse1",
  &predicate_unwrap_xreverse1_2
};

extern Const struct predicate predicate_unwrap_xrec__set__arg_4;
static Const struct predinfo predinfo_unwrap_xrec__set__arg_4 = {
  (unsigned char *)"rec_set_arg",
  &predicate_unwrap_xrec__set__arg_4
};

extern Const struct predicate predicate_unwrap_xlength_2;
static Const struct predinfo predinfo_unwrap_xlength_2 = {
  (unsigned char *)"length",
  &predicate_unwrap_xlength_2
};

extern Const struct predicate predicate_unwrap_xappend_3;
static Const struct predinfo predinfo_unwrap_xappend_3 = {
  (unsigned char *)"append",
  &predicate_unwrap_xappend_3
};

extern Const struct predicate predicate_unwrap_xappend1_3;
static Const struct predinfo predinfo_unwrap_xappend1_3 = {
  (unsigned char *)"append1",
  &predicate_unwrap_xappend1_3
};

static Const struct predinfo * Const preds_in_unwrap[] = {
  &predinfo_unwrap_xunwraparg_4,
  &predinfo_unwrap_xunwraparg_3,
  &predinfo_unwrap_xunwrap_2,
  &predinfo_unwrap_xunwrap1_2,
  &predinfo_unwrap_xunlist_2,
  &predinfo_unwrap_xunlist1_3,
  &predinfo_unwrap_xunlist1_2,
  &predinfo_unwrap_xreverse_2,
  &predinfo_unwrap_xreverse1_3,
  &predinfo_unwrap_xreverse1_2,
  &predinfo_unwrap_xrec__set__arg_4,
  &predinfo_unwrap_xlength_2,
  &predinfo_unwrap_xappend_3,
  &predinfo_unwrap_xappend1_3,
  0
};
extern Const struct predicate predicate_unix_xwrite__open_2;
static Const struct predinfo predinfo_unix_xwrite__open_2 = {
  (unsigned char *)"write_open",
  &predicate_unix_xwrite__open_2
};

extern Const struct predicate predicate_unix_xupdate__open_2;
static Const struct predinfo predinfo_unix_xupdate__open_2 = {
  (unsigned char *)"update_open",
  &predicate_unix_xupdate__open_2
};

extern Const struct predicate predicate_unix_xunlink_2;
static Const struct predinfo predinfo_unix_xunlink_2 = {
  (unsigned char *)"unlink",
  &predicate_unix_xunlink_2
};

extern Const struct predicate predicate_unix_xunix_1;
static Const struct predinfo predinfo_unix_xunix_1 = {
  (unsigned char *)"unix",
  &predicate_unix_xunix_1
};

extern Const struct predicate predicate_unix_xumask_2;
static Const struct predinfo predinfo_unix_xumask_2 = {
  (unsigned char *)"umask",
  &predicate_unix_xumask_2
};

extern Const struct predicate predicate_unix_xumask_1;
static Const struct predinfo predinfo_unix_xumask_1 = {
  (unsigned char *)"umask",
  &predicate_unix_xumask_1
};

extern Const struct predicate predicate_unix_xtimes_4;
static Const struct predinfo predinfo_unix_xtimes_4 = {
  (unsigned char *)"times",
  &predicate_unix_xtimes_4
};

extern Const struct predicate predicate_unix_xsystem_2;
static Const struct predinfo predinfo_unix_xsystem_2 = {
  (unsigned char *)"system",
  &predicate_unix_xsystem_2
};

extern Const struct predicate predicate_unix_xstdout_1;
static Const struct predinfo predinfo_unix_xstdout_1 = {
  (unsigned char *)"stdout",
  &predicate_unix_xstdout_1
};

extern Const struct predicate predicate_unix_xstdio_1;
static Const struct predinfo predinfo_unix_xstdio_1 = {
  (unsigned char *)"stdio",
  &predicate_unix_xstdio_1
};

extern Const struct predicate predicate_unix_xstdin_1;
static Const struct predinfo predinfo_unix_xstdin_1 = {
  (unsigned char *)"stdin",
  &predicate_unix_xstdin_1
};

extern Const struct predicate predicate_unix_xstderr_1;
static Const struct predinfo predinfo_unix_xstderr_1 = {
  (unsigned char *)"stderr",
  &predicate_unix_xstderr_1
};

extern Const struct predicate predicate_unix_xsignal__stream_3;
static Const struct predinfo predinfo_unix_xsignal__stream_3 = {
  (unsigned char *)"signal_stream",
  &predicate_unix_xsignal__stream_3
};

extern Const struct predicate predicate_unix_xsignal__stream_2;
static Const struct predinfo predinfo_unix_xsignal__stream_2 = {
  (unsigned char *)"signal_stream",
  &predicate_unix_xsignal__stream_2
};

extern Const struct predicate predicate_unix_xread__open_2;
static Const struct predinfo predinfo_unix_xread__open_2 = {
  (unsigned char *)"read_open",
  &predicate_unix_xread__open_2
};

extern Const struct predicate predicate_unix_xputenv_2;
static Const struct predinfo predinfo_unix_xputenv_2 = {
  (unsigned char *)"putenv",
  &predicate_unix_xputenv_2
};

extern Const struct predicate predicate_unix_xpipe_1;
static Const struct predinfo predinfo_unix_xpipe_1 = {
  (unsigned char *)"pipe",
  &predicate_unix_xpipe_1
};

extern Const struct predicate predicate_unix_xnet__convert_3;
static Const struct predinfo predinfo_unix_xnet__convert_3 = {
  (unsigned char *)"net_convert",
  &predicate_unix_xnet__convert_3
};

extern Const struct predicate predicate_unix_xmktemp_2;
static Const struct predinfo predinfo_unix_xmktemp_2 = {
  (unsigned char *)"mktemp",
  &predicate_unix_xmktemp_2
};

extern Const struct predicate predicate_unix_xmake__argv__list_3;
static Const struct predinfo predinfo_unix_xmake__argv__list_3 = {
  (unsigned char *)"make_argv_list",
  &predicate_unix_xmake__argv__list_3
};

extern Const struct predicate predicate_unix_xkill_3;
static Const struct predinfo predinfo_unix_xkill_3 = {
  (unsigned char *)"kill",
  &predicate_unix_xkill_3
};

extern Const struct predicate predicate_unix_xgetenv_2;
static Const struct predinfo predinfo_unix_xgetenv_2 = {
  (unsigned char *)"getenv",
  &predicate_unix_xgetenv_2
};

extern Const struct predicate predicate_unix_xfork__with__pipes_2F1_240_6;
static Const struct predinfo predinfo_unix_xfork__with__pipes_2F1_240_6 = {
  (unsigned char *)"fork_with_pipes/1$0",
  &predicate_unix_xfork__with__pipes_2F1_240_6
};

extern Const struct predicate predicate_unix_xfork__with__pipes_1;
static Const struct predinfo predinfo_unix_xfork__with__pipes_1 = {
  (unsigned char *)"fork_with_pipes",
  &predicate_unix_xfork__with__pipes_1
};

extern Const struct predicate predicate_unix_xfork_1;
static Const struct predinfo predinfo_unix_xfork_1 = {
  (unsigned char *)"fork",
  &predicate_unix_xfork_1
};

extern Const struct predicate predicate_unix_xexit_1;
static Const struct predinfo predinfo_unix_xexit_1 = {
  (unsigned char *)"exit",
  &predicate_unix_xexit_1
};

extern Const struct predicate predicate_unix_xdummy_0;
static Const struct predinfo predinfo_unix_xdummy_0 = {
  (unsigned char *)"dummy",
  &predicate_unix_xdummy_0
};

extern Const struct predicate predicate_unix_xcont_3;
static Const struct predinfo predinfo_unix_xcont_3 = {
  (unsigned char *)"cont",
  &predicate_unix_xcont_3
};

extern Const struct predicate predicate_unix_xconnect__sub_4;
static Const struct predinfo predinfo_unix_xconnect__sub_4 = {
  (unsigned char *)"connect_sub",
  &predicate_unix_xconnect__sub_4
};

extern Const struct predicate predicate_unix_xconnect_4;
static Const struct predinfo predinfo_unix_xconnect_4 = {
  (unsigned char *)"connect",
  &predicate_unix_xconnect_4
};

extern Const struct predicate predicate_unix_xconnect_2;
static Const struct predinfo predinfo_unix_xconnect_2 = {
  (unsigned char *)"connect",
  &predicate_unix_xconnect_2
};

extern Const struct predicate predicate_unix_xchmod_3;
static Const struct predinfo predinfo_unix_xchmod_3 = {
  (unsigned char *)"chmod",
  &predicate_unix_xchmod_3
};

extern Const struct predicate predicate_unix_xcd_2;
static Const struct predinfo predinfo_unix_xcd_2 = {
  (unsigned char *)"cd",
  &predicate_unix_xcd_2
};

extern Const struct predicate predicate_unix_xbound__sock_4;
static Const struct predinfo predinfo_unix_xbound__sock_4 = {
  (unsigned char *)"bound_sock",
  &predicate_unix_xbound__sock_4
};

extern Const struct predicate predicate_unix_xbind_4;
static Const struct predinfo predinfo_unix_xbind_4 = {
  (unsigned char *)"bind",
  &predicate_unix_xbind_4
};

extern Const struct predicate predicate_unix_xbind_2;
static Const struct predinfo predinfo_unix_xbind_2 = {
  (unsigned char *)"bind",
  &predicate_unix_xbind_2
};

extern Const struct predicate predicate_unix_xasync__io_5;
static Const struct predinfo predinfo_unix_xasync__io_5 = {
  (unsigned char *)"async_io",
  &predicate_unix_xasync__io_5
};

extern Const struct predicate predicate_unix_xargv_1;
static Const struct predinfo predinfo_unix_xargv_1 = {
  (unsigned char *)"argv",
  &predicate_unix_xargv_1
};

extern Const struct predicate predicate_unix_xargc_1;
static Const struct predinfo predinfo_unix_xargc_1 = {
  (unsigned char *)"argc",
  &predicate_unix_xargc_1
};

extern Const struct predicate predicate_unix_xappend__open_2;
static Const struct predinfo predinfo_unix_xappend__open_2 = {
  (unsigned char *)"append_open",
  &predicate_unix_xappend__open_2
};

extern Const struct predicate predicate_unix_xaccess_3;
static Const struct predinfo predinfo_unix_xaccess_3 = {
  (unsigned char *)"access",
  &predicate_unix_xaccess_3
};

static Const struct predinfo * Const preds_in_unix[] = {
  &predinfo_unix_xwrite__open_2,
  &predinfo_unix_xupdate__open_2,
  &predinfo_unix_xunlink_2,
  &predinfo_unix_xunix_1,
  &predinfo_unix_xumask_2,
  &predinfo_unix_xumask_1,
  &predinfo_unix_xtimes_4,
  &predinfo_unix_xsystem_2,
  &predinfo_unix_xstdout_1,
  &predinfo_unix_xstdio_1,
  &predinfo_unix_xstdin_1,
  &predinfo_unix_xstderr_1,
  &predinfo_unix_xsignal__stream_3,
  &predinfo_unix_xsignal__stream_2,
  &predinfo_unix_xread__open_2,
  &predinfo_unix_xputenv_2,
  &predinfo_unix_xpipe_1,
  &predinfo_unix_xnet__convert_3,
  &predinfo_unix_xmktemp_2,
  &predinfo_unix_xmake__argv__list_3,
  &predinfo_unix_xkill_3,
  &predinfo_unix_xgetenv_2,
  &predinfo_unix_xfork__with__pipes_2F1_240_6,
  &predinfo_unix_xfork__with__pipes_1,
  &predinfo_unix_xfork_1,
  &predinfo_unix_xexit_1,
  &predinfo_unix_xdummy_0,
  &predinfo_unix_xcont_3,
  &predinfo_unix_xconnect__sub_4,
  &predinfo_unix_xconnect_4,
  &predinfo_unix_xconnect_2,
  &predinfo_unix_xchmod_3,
  &predinfo_unix_xcd_2,
  &predinfo_unix_xbound__sock_4,
  &predinfo_unix_xbind_4,
  &predinfo_unix_xbind_2,
  &predinfo_unix_xasync__io_5,
  &predinfo_unix_xargv_1,
  &predinfo_unix_xargc_1,
  &predinfo_unix_xappend__open_2,
  &predinfo_unix_xaccess_3,
  0
};
extern Const struct predicate predicate_http_xsearchHead_3;
static Const struct predinfo predinfo_http_xsearchHead_3 = {
  (unsigned char *)"searchHead",
  &predicate_http_xsearchHead_3
};

extern Const struct predicate predicate_http_xsearchHead1_3;
static Const struct predinfo predinfo_http_xsearchHead1_3 = {
  (unsigned char *)"searchHead1",
  &predicate_http_xsearchHead1_3
};

extern Const struct predicate predicate_http_xsearchHead1_2F3_240_5;
static Const struct predinfo predinfo_http_xsearchHead1_2F3_240_5 = {
  (unsigned char *)"searchHead1/3$0",
  &predicate_http_xsearchHead1_2F3_240_5
};

extern Const struct predicate predicate_http_xsearchHead1_2F3_240_2F5_240_5;
static Const struct predinfo predinfo_http_xsearchHead1_2F3_240_2F5_240_5 = {
  (unsigned char *)"searchHead1/3$0/5$0",
  &predicate_http_xsearchHead1_2F3_240_2F5_240_5
};

extern Const struct predicate predicate_http_xsearchCommentEnd_2;
static Const struct predinfo predinfo_http_xsearchCommentEnd_2 = {
  (unsigned char *)"searchCommentEnd",
  &predicate_http_xsearchCommentEnd_2
};

extern Const struct predicate predicate_http_xrmCommentSP_2;
static Const struct predinfo predinfo_http_xrmCommentSP_2 = {
  (unsigned char *)"rmCommentSP",
  &predicate_http_xrmCommentSP_2
};

extern Const struct predicate predicate_http_xrmCommentSPDQ_2;
static Const struct predinfo predinfo_http_xrmCommentSPDQ_2 = {
  (unsigned char *)"rmCommentSPDQ",
  &predicate_http_xrmCommentSPDQ_2
};

extern Const struct predicate predicate_http_xrmCommentSPComm_2;
static Const struct predinfo predinfo_http_xrmCommentSPComm_2 = {
  (unsigned char *)"rmCommentSPComm",
  &predicate_http_xrmCommentSPComm_2
};

extern Const struct predicate predicate_http_xrmCommentSPBr_2;
static Const struct predinfo predinfo_http_xrmCommentSPBr_2 = {
  (unsigned char *)"rmCommentSPBr",
  &predicate_http_xrmCommentSPBr_2
};

extern Const struct predicate predicate_http_xrmCommentSP1_2;
static Const struct predinfo predinfo_http_xrmCommentSP1_2 = {
  (unsigned char *)"rmCommentSP1",
  &predicate_http_xrmCommentSP1_2
};

extern Const struct predicate predicate_http_xpartHead_2;
static Const struct predinfo predinfo_http_xpartHead_2 = {
  (unsigned char *)"partHead",
  &predicate_http_xpartHead_2
};

extern Const struct predicate predicate_http_xpartHeadBody_3;
static Const struct predinfo predinfo_http_xpartHeadBody_3 = {
  (unsigned char *)"partHeadBody",
  &predicate_http_xpartHeadBody_3
};

extern Const struct predicate predicate_http_xpartHeadBody_2F3_241_6;
static Const struct predinfo predinfo_http_xpartHeadBody_2F3_241_6 = {
  (unsigned char *)"partHeadBody/3$1",
  &predicate_http_xpartHeadBody_2F3_241_6
};

extern Const struct predicate predicate_http_xpartHeadBody_2F3_241_2F6_240_6;
static Const struct predinfo predinfo_http_xpartHeadBody_2F3_241_2F6_240_6 = {
  (unsigned char *)"partHeadBody/3$1/6$0",
  &predicate_http_xpartHeadBody_2F3_241_2F6_240_6
};

extern Const struct predicate predicate_http_xpartHeadBody_2F3_240_4;
static Const struct predinfo predinfo_http_xpartHeadBody_2F3_240_4 = {
  (unsigned char *)"partHeadBody/3$0",
  &predicate_http_xpartHeadBody_2F3_240_4
};

extern Const struct predicate predicate_http_xpartHeadBody_2F3_240_2F4_240_4;
static Const struct predinfo predinfo_http_xpartHeadBody_2F3_240_2F4_240_4 = {
  (unsigned char *)"partHeadBody/3$0/4$0",
  &predicate_http_xpartHeadBody_2F3_240_2F4_240_4
};

extern Const struct predicate predicate_http_xpartHeadBodyLF_6;
static Const struct predinfo predinfo_http_xpartHeadBodyLF_6 = {
  (unsigned char *)"partHeadBodyLF",
  &predicate_http_xpartHeadBodyLF_6
};

extern Const struct predicate predicate_http_xpartHeadBodyLF_2F6_240_7;
static Const struct predinfo predinfo_http_xpartHeadBodyLF_2F6_240_7 = {
  (unsigned char *)"partHeadBodyLF/6$0",
  &predicate_http_xpartHeadBodyLF_2F6_240_7
};

extern Const struct predicate predicate_http_xpartHeadBodyLF_2F6_240_2F7_240_7;
static Const struct predinfo predinfo_http_xpartHeadBodyLF_2F6_240_2F7_240_7 = {
  (unsigned char *)"partHeadBodyLF/6$0/7$0",
  &predicate_http_xpartHeadBodyLF_2F6_240_2F7_240_7
};

extern Const struct predicate predicate_http_xpartHeadBodyCRLF_6;
static Const struct predinfo predinfo_http_xpartHeadBodyCRLF_6 = {
  (unsigned char *)"partHeadBodyCRLF",
  &predicate_http_xpartHeadBodyCRLF_6
};

extern Const struct predicate predicate_http_xpartHeadBodyCRLF_2F6_240_7;
static Const struct predinfo predinfo_http_xpartHeadBodyCRLF_2F6_240_7 = {
  (unsigned char *)"partHeadBodyCRLF/6$0",
  &predicate_http_xpartHeadBodyCRLF_2F6_240_7
};

extern Const struct predicate predicate_http_xpartHeadBodyCRLF_2F6_240_2F7_240_10;
static Const struct predinfo predinfo_http_xpartHeadBodyCRLF_2F6_240_2F7_240_10 = {
  (unsigned char *)"partHeadBodyCRLF/6$0/7$0",
  &predicate_http_xpartHeadBodyCRLF_2F6_240_2F7_240_10
};

extern Const struct predicate predicate_http_xpartHeadBody1_4;
static Const struct predinfo predinfo_http_xpartHeadBody1_4 = {
  (unsigned char *)"partHeadBody1",
  &predicate_http_xpartHeadBody1_4
};

extern Const struct predicate predicate_http_xpartHeadBody1_2F4_241_8;
static Const struct predinfo predinfo_http_xpartHeadBody1_2F4_241_8 = {
  (unsigned char *)"partHeadBody1/4$1",
  &predicate_http_xpartHeadBody1_2F4_241_8
};

extern Const struct predicate predicate_http_xpartHeadBody1_2F4_241_2F8_240_14;
static Const struct predinfo predinfo_http_xpartHeadBody1_2F4_241_2F8_240_14 = {
  (unsigned char *)"partHeadBody1/4$1/8$0",
  &predicate_http_xpartHeadBody1_2F4_241_2F8_240_14
};

extern Const struct predicate predicate_http_xpartHeadBody1_2F4_240_6;
static Const struct predinfo predinfo_http_xpartHeadBody1_2F4_240_6 = {
  (unsigned char *)"partHeadBody1/4$0",
  &predicate_http_xpartHeadBody1_2F4_240_6
};

extern Const struct predicate predicate_http_xpartHeadBody1_2F4_240_2F6_240_12;
static Const struct predinfo predinfo_http_xpartHeadBody1_2F4_240_2F6_240_12 = {
  (unsigned char *)"partHeadBody1/4$0/6$0",
  &predicate_http_xpartHeadBody1_2F4_240_2F6_240_12
};

extern Const struct predicate predicate_http_xpartHead2_2;
static Const struct predinfo predinfo_http_xpartHead2_2 = {
  (unsigned char *)"partHead2",
  &predicate_http_xpartHead2_2
};

extern Const struct predicate predicate_http_xpartHead1_3;
static Const struct predinfo predinfo_http_xpartHead1_3 = {
  (unsigned char *)"partHead1",
  &predicate_http_xpartHead1_3
};

extern Const struct predicate predicate_http_xpartDigit_2;
static Const struct predinfo predinfo_http_xpartDigit_2 = {
  (unsigned char *)"partDigit",
  &predicate_http_xpartDigit_2
};

extern Const struct predicate predicate_http_xpartDigit1_2F2_240_4;
static Const struct predinfo predinfo_http_xpartDigit1_2F2_240_4 = {
  (unsigned char *)"partDigit1/2$0",
  &predicate_http_xpartDigit1_2F2_240_4
};

extern Const struct predicate predicate_http_xpartDigit1_2F2_240_2F4_240_2;
static Const struct predinfo predinfo_http_xpartDigit1_2F2_240_2F4_240_2 = {
  (unsigned char *)"partDigit1/2$0/4$0",
  &predicate_http_xpartDigit1_2F2_240_2F4_240_2
};

extern Const struct predicate predicate_http_xpartDigit1_2;
static Const struct predinfo predinfo_http_xpartDigit1_2 = {
  (unsigned char *)"partDigit1",
  &predicate_http_xpartDigit1_2
};

extern Const struct predicate predicate_http_xpartContentType_2F2_240_3;
static Const struct predinfo predinfo_http_xpartContentType_2F2_240_3 = {
  (unsigned char *)"partContentType/2$0",
  &predicate_http_xpartContentType_2F2_240_3
};

extern Const struct predicate predicate_http_xpartContentType_2;
static Const struct predinfo predinfo_http_xpartContentType_2 = {
  (unsigned char *)"partContentType",
  &predicate_http_xpartContentType_2
};

extern Const struct predicate predicate_http_xnewLocation_2F2_240_3;
static Const struct predinfo predinfo_http_xnewLocation_2F2_240_3 = {
  (unsigned char *)"newLocation/2$0",
  &predicate_http_xnewLocation_2F2_240_3
};

extern Const struct predicate predicate_http_xnewLocation_2;
static Const struct predinfo predinfo_http_xnewLocation_2 = {
  (unsigned char *)"newLocation",
  &predicate_http_xnewLocation_2
};

extern Const struct predicate predicate_http_xmkReq_5;
static Const struct predinfo predinfo_http_xmkReq_5 = {
  (unsigned char *)"mkReq",
  &predicate_http_xmkReq_5
};

extern Const struct predicate predicate_http_xisDigit_2F2_240_2;
static Const struct predinfo predinfo_http_xisDigit_2F2_240_2 = {
  (unsigned char *)"isDigit/2$0",
  &predicate_http_xisDigit_2F2_240_2
};

extern Const struct predicate predicate_http_xisDigit_2;
static Const struct predinfo predinfo_http_xisDigit_2 = {
  (unsigned char *)"isDigit",
  &predicate_http_xisDigit_2
};

extern Const struct predicate predicate_http_xignoreParam_2F2_240_3;
static Const struct predinfo predinfo_http_xignoreParam_2F2_240_3 = {
  (unsigned char *)"ignoreParam/2$0",
  &predicate_http_xignoreParam_2F2_240_3
};

extern Const struct predicate predicate_http_xignoreParam_2;
static Const struct predinfo predinfo_http_xignoreParam_2 = {
  (unsigned char *)"ignoreParam",
  &predicate_http_xignoreParam_2
};

extern Const struct predicate predicate_http_xhttpcomm_2F11_240_3;
static Const struct predinfo predinfo_http_xhttpcomm_2F11_240_3 = {
  (unsigned char *)"httpcomm/11$0",
  &predicate_http_xhttpcomm_2F11_240_3
};

extern Const struct predicate predicate_http_xhttpcomm_11;
static Const struct predinfo predinfo_http_xhttpcomm_11 = {
  (unsigned char *)"httpcomm",
  &predicate_http_xhttpcomm_11
};

extern Const struct predicate predicate_http_xhttpcomm1_9;
static Const struct predinfo predinfo_http_xhttpcomm1_9 = {
  (unsigned char *)"httpcomm1",
  &predicate_http_xhttpcomm1_9
};

extern Const struct predicate predicate_http_xhttpGetResp_5;
static Const struct predinfo predinfo_http_xhttpGetResp_5 = {
  (unsigned char *)"httpGetResp",
  &predicate_http_xhttpGetResp_5
};

extern Const struct predicate predicate_http_xhttpGetResp1_4;
static Const struct predinfo predinfo_http_xhttpGetResp1_4 = {
  (unsigned char *)"httpGetResp1",
  &predicate_http_xhttpGetResp1_4
};

extern Const struct predicate predicate_http_xhttpGetResp1_2F4_240_6;
static Const struct predinfo predinfo_http_xhttpGetResp1_2F4_240_6 = {
  (unsigned char *)"httpGetResp1/4$0",
  &predicate_http_xhttpGetResp1_2F4_240_6
};

extern Const struct predicate predicate_http_xgetStatusCode_2F2_240_3;
static Const struct predinfo predinfo_http_xgetStatusCode_2F2_240_3 = {
  (unsigned char *)"getStatusCode/2$0",
  &predicate_http_xgetStatusCode_2F2_240_3
};

extern Const struct predicate predicate_http_xgetStatusCode_2F2_240_2F3_240_2;
static Const struct predinfo predinfo_http_xgetStatusCode_2F2_240_2F3_240_2 = {
  (unsigned char *)"getStatusCode/2$0/3$0",
  &predicate_http_xgetStatusCode_2F2_240_2F3_240_2
};

extern Const struct predicate predicate_http_xgetStatusCode_2;
static Const struct predinfo predinfo_http_xgetStatusCode_2 = {
  (unsigned char *)"getStatusCode",
  &predicate_http_xgetStatusCode_2
};

extern Const struct predicate predicate_http_xfiletype_2;
static Const struct predinfo predinfo_http_xfiletype_2 = {
  (unsigned char *)"filetype",
  &predicate_http_xfiletype_2
};

static Const struct predinfo * Const preds_in_http[] = {
  &predinfo_http_xsearchHead_3,
  &predinfo_http_xsearchHead1_3,
  &predinfo_http_xsearchHead1_2F3_240_5,
  &predinfo_http_xsearchHead1_2F3_240_2F5_240_5,
  &predinfo_http_xsearchCommentEnd_2,
  &predinfo_http_xrmCommentSP_2,
  &predinfo_http_xrmCommentSPDQ_2,
  &predinfo_http_xrmCommentSPComm_2,
  &predinfo_http_xrmCommentSPBr_2,
  &predinfo_http_xrmCommentSP1_2,
  &predinfo_http_xpartHead_2,
  &predinfo_http_xpartHeadBody_3,
  &predinfo_http_xpartHeadBody_2F3_241_6,
  &predinfo_http_xpartHeadBody_2F3_241_2F6_240_6,
  &predinfo_http_xpartHeadBody_2F3_240_4,
  &predinfo_http_xpartHeadBody_2F3_240_2F4_240_4,
  &predinfo_http_xpartHeadBodyLF_6,
  &predinfo_http_xpartHeadBodyLF_2F6_240_7,
  &predinfo_http_xpartHeadBodyLF_2F6_240_2F7_240_7,
  &predinfo_http_xpartHeadBodyCRLF_6,
  &predinfo_http_xpartHeadBodyCRLF_2F6_240_7,
  &predinfo_http_xpartHeadBodyCRLF_2F6_240_2F7_240_10,
  &predinfo_http_xpartHeadBody1_4,
  &predinfo_http_xpartHeadBody1_2F4_241_8,
  &predinfo_http_xpartHeadBody1_2F4_241_2F8_240_14,
  &predinfo_http_xpartHeadBody1_2F4_240_6,
  &predinfo_http_xpartHeadBody1_2F4_240_2F6_240_12,
  &predinfo_http_xpartHead2_2,
  &predinfo_http_xpartHead1_3,
  &predinfo_http_xpartDigit_2,
  &predinfo_http_xpartDigit1_2F2_240_4,
  &predinfo_http_xpartDigit1_2F2_240_2F4_240_2,
  &predinfo_http_xpartDigit1_2,
  &predinfo_http_xpartContentType_2F2_240_3,
  &predinfo_http_xpartContentType_2,
  &predinfo_http_xnewLocation_2F2_240_3,
  &predinfo_http_xnewLocation_2,
  &predinfo_http_xmkReq_5,
  &predinfo_http_xisDigit_2F2_240_2,
  &predinfo_http_xisDigit_2,
  &predinfo_http_xignoreParam_2F2_240_3,
  &predinfo_http_xignoreParam_2,
  &predinfo_http_xhttpcomm_2F11_240_3,
  &predinfo_http_xhttpcomm_11,
  &predinfo_http_xhttpcomm1_9,
  &predinfo_http_xhttpGetResp_5,
  &predinfo_http_xhttpGetResp1_4,
  &predinfo_http_xhttpGetResp1_2F4_240_6,
  &predinfo_http_xgetStatusCode_2F2_240_3,
  &predinfo_http_xgetStatusCode_2F2_240_2F3_240_2,
  &predinfo_http_xgetStatusCode_2,
  &predinfo_http_xfiletype_2,
  0
};
extern Const struct predicate predicate_html_xunescape_2;
static Const struct predinfo predinfo_html_xunescape_2 = {
  (unsigned char *)"unescape",
  &predicate_html_xunescape_2
};

extern Const struct predicate predicate_html_xunescapeText_2;
static Const struct predinfo predinfo_html_xunescapeText_2 = {
  (unsigned char *)"unescapeText",
  &predicate_html_xunescapeText_2
};

extern Const struct predicate predicate_html_xrmNullText_2;
static Const struct predinfo predinfo_html_xrmNullText_2 = {
  (unsigned char *)"rmNullText",
  &predicate_html_xrmNullText_2
};

extern Const struct predicate predicate_html_xrmNullP_2;
static Const struct predinfo predinfo_html_xrmNullP_2 = {
  (unsigned char *)"rmNullP",
  &predicate_html_xrmNullP_2
};

extern Const struct predicate predicate_html_xrmNullElm_2;
static Const struct predinfo predinfo_html_xrmNullElm_2 = {
  (unsigned char *)"rmNullElm",
  &predicate_html_xrmNullElm_2
};

extern Const struct predicate predicate_html_xrmNullAttr_2;
static Const struct predinfo predinfo_html_xrmNullAttr_2 = {
  (unsigned char *)"rmNullAttr",
  &predicate_html_xrmNullAttr_2
};

extern Const struct predicate predicate_html_xpartNameAttr_2;
static Const struct predinfo predinfo_html_xpartNameAttr_2 = {
  (unsigned char *)"partNameAttr",
  &predicate_html_xpartNameAttr_2
};

extern Const struct predicate predicate_html_xpartNameAttr1_3;
static Const struct predinfo predinfo_html_xpartNameAttr1_3 = {
  (unsigned char *)"partNameAttr1",
  &predicate_html_xpartNameAttr1_3
};

extern Const struct predicate predicate_html_xpartAttr_4;
static Const struct predinfo predinfo_html_xpartAttr_4 = {
  (unsigned char *)"partAttr",
  &predicate_html_xpartAttr_4
};

extern Const struct predicate predicate_html_xpartAttr2_3;
static Const struct predinfo predinfo_html_xpartAttr2_3 = {
  (unsigned char *)"partAttr2",
  &predicate_html_xpartAttr2_3
};

extern Const struct predicate predicate_html_xpartAttr2SQ_3;
static Const struct predinfo predinfo_html_xpartAttr2SQ_3 = {
  (unsigned char *)"partAttr2SQ",
  &predicate_html_xpartAttr2SQ_3
};

extern Const struct predicate predicate_html_xpartAttr2NT_3;
static Const struct predinfo predinfo_html_xpartAttr2NT_3 = {
  (unsigned char *)"partAttr2NT",
  &predicate_html_xpartAttr2NT_3
};

extern Const struct predicate predicate_html_xpartAttr2DQ_3;
static Const struct predinfo predinfo_html_xpartAttr2DQ_3 = {
  (unsigned char *)"partAttr2DQ",
  &predicate_html_xpartAttr2DQ_3
};

extern Const struct predicate predicate_html_xpartAttr1_3;
static Const struct predinfo predinfo_html_xpartAttr1_3 = {
  (unsigned char *)"partAttr1",
  &predicate_html_xpartAttr1_3
};

extern Const struct predicate predicate_html_xparseTag_3;
static Const struct predinfo predinfo_html_xparseTag_3 = {
  (unsigned char *)"parseTag",
  &predicate_html_xparseTag_3
};

extern Const struct predicate predicate_html_xparseTag_2F3_246_4;
static Const struct predinfo predinfo_html_xparseTag_2F3_246_4 = {
  (unsigned char *)"parseTag/3$6",
  &predicate_html_xparseTag_2F3_246_4
};

extern Const struct predicate predicate_html_xparseTag_2F3_245_4;
static Const struct predinfo predinfo_html_xparseTag_2F3_245_4 = {
  (unsigned char *)"parseTag/3$5",
  &predicate_html_xparseTag_2F3_245_4
};

extern Const struct predicate predicate_html_xparseTag_2F3_244_6;
static Const struct predinfo predinfo_html_xparseTag_2F3_244_6 = {
  (unsigned char *)"parseTag/3$4",
  &predicate_html_xparseTag_2F3_244_6
};

extern Const struct predicate predicate_html_xparseTag_2F3_244_2F6_240_6;
static Const struct predinfo predinfo_html_xparseTag_2F3_244_2F6_240_6 = {
  (unsigned char *)"parseTag/3$4/6$0",
  &predicate_html_xparseTag_2F3_244_2F6_240_6
};

extern Const struct predicate predicate_html_xparseTag_2F3_244_2F6_240_2F6_240_5;
static Const struct predinfo predinfo_html_xparseTag_2F3_244_2F6_240_2F6_240_5 = {
  (unsigned char *)"parseTag/3$4/6$0/6$0",
  &predicate_html_xparseTag_2F3_244_2F6_240_2F6_240_5
};

extern Const struct predicate predicate_html_xparseTag_2F3_244_2F6_240_2F6_240_2F5_240_4;
static Const struct predinfo predinfo_html_xparseTag_2F3_244_2F6_240_2F6_240_2F5_240_4 = {
  (unsigned char *)"parseTag/3$4/6$0/6$0/5$0",
  &predicate_html_xparseTag_2F3_244_2F6_240_2F6_240_2F5_240_4
};

extern Const struct predicate predicate_html_xparseTag_2F3_243_4;
static Const struct predinfo predinfo_html_xparseTag_2F3_243_4 = {
  (unsigned char *)"parseTag/3$3",
  &predicate_html_xparseTag_2F3_243_4
};

extern Const struct predicate predicate_html_xparseTag_2F3_243_2F4_240_7;
static Const struct predinfo predinfo_html_xparseTag_2F3_243_2F4_240_7 = {
  (unsigned char *)"parseTag/3$3/4$0",
  &predicate_html_xparseTag_2F3_243_2F4_240_7
};

extern Const struct predicate predicate_html_xparseTag_2F3_242_4;
static Const struct predinfo predinfo_html_xparseTag_2F3_242_4 = {
  (unsigned char *)"parseTag/3$2",
  &predicate_html_xparseTag_2F3_242_4
};

extern Const struct predicate predicate_html_xparseTag_2F3_241_4;
static Const struct predinfo predinfo_html_xparseTag_2F3_241_4 = {
  (unsigned char *)"parseTag/3$1",
  &predicate_html_xparseTag_2F3_241_4
};

extern Const struct predicate predicate_html_xparseTag_2F3_240_6;
static Const struct predinfo predinfo_html_xparseTag_2F3_240_6 = {
  (unsigned char *)"parseTag/3$0",
  &predicate_html_xparseTag_2F3_240_6
};

extern Const struct predicate predicate_html_xparseTag_2F3_240_2F6_241_4;
static Const struct predinfo predinfo_html_xparseTag_2F3_240_2F6_241_4 = {
  (unsigned char *)"parseTag/3$0/6$1",
  &predicate_html_xparseTag_2F3_240_2F6_241_4
};

extern Const struct predicate predicate_html_xparseTag_2F3_240_2F6_241_2F4_240_7;
static Const struct predinfo predinfo_html_xparseTag_2F3_240_2F6_241_2F4_240_7 = {
  (unsigned char *)"parseTag/3$0/6$1/4$0",
  &predicate_html_xparseTag_2F3_240_2F6_241_2F4_240_7
};

extern Const struct predicate predicate_html_xparseTag_2F3_240_2F6_240_5;
static Const struct predinfo predinfo_html_xparseTag_2F3_240_2F6_240_5 = {
  (unsigned char *)"parseTag/3$0/6$0",
  &predicate_html_xparseTag_2F3_240_2F6_240_5
};

extern Const struct predicate predicate_html_xparseTag_2F3_240_2F6_240_2F5_240_4;
static Const struct predinfo predinfo_html_xparseTag_2F3_240_2F6_240_2F5_240_4 = {
  (unsigned char *)"parseTag/3$0/6$0/5$0",
  &predicate_html_xparseTag_2F3_240_2F6_240_2F5_240_4
};

extern Const struct predicate predicate_html_xparseTag_2;
static Const struct predinfo predinfo_html_xparseTag_2 = {
  (unsigned char *)"parseTag",
  &predicate_html_xparseTag_2
};

extern Const struct predicate predicate_html_xparseHTML_2;
static Const struct predinfo predinfo_html_xparseHTML_2 = {
  (unsigned char *)"parseHTML",
  &predicate_html_xparseHTML_2
};

extern Const struct predicate predicate_html_xparseBrac_3;
static Const struct predinfo predinfo_html_xparseBrac_3 = {
  (unsigned char *)"parseBrac",
  &predicate_html_xparseBrac_3
};

extern Const struct predicate predicate_html_xparseBracInText_4;
static Const struct predinfo predinfo_html_xparseBracInText_4 = {
  (unsigned char *)"parseBracInText",
  &predicate_html_xparseBracInText_4
};

extern Const struct predicate predicate_html_xparseBracInTag_4;
static Const struct predinfo predinfo_html_xparseBracInTag_4 = {
  (unsigned char *)"parseBracInTag",
  &predicate_html_xparseBracInTag_4
};

extern Const struct predicate predicate_html_xparseBracInComment_3;
static Const struct predinfo predinfo_html_xparseBracInComment_3 = {
  (unsigned char *)"parseBracInComment",
  &predicate_html_xparseBracInComment_3
};

extern Const struct predicate predicate_html_xparseBracInComment1_3;
static Const struct predinfo predinfo_html_xparseBracInComment1_3 = {
  (unsigned char *)"parseBracInComment1",
  &predicate_html_xparseBracInComment1_3
};

extern Const struct predicate predicate_html_xnormalizeText_2F2_240_4;
static Const struct predinfo predinfo_html_xnormalizeText_2F2_240_4 = {
  (unsigned char *)"normalizeText/2$0",
  &predicate_html_xnormalizeText_2F2_240_4
};

extern Const struct predicate predicate_html_xnormalizeText_2;
static Const struct predinfo predinfo_html_xnormalizeText_2 = {
  (unsigned char *)"normalizeText",
  &predicate_html_xnormalizeText_2
};

extern Const struct predicate predicate_html_xnormalizeTextInPre_2;
static Const struct predinfo predinfo_html_xnormalizeTextInPre_2 = {
  (unsigned char *)"normalizeTextInPre",
  &predicate_html_xnormalizeTextInPre_2
};

extern Const struct predicate predicate_html_xnormalizeTextInPreFirst_2;
static Const struct predinfo predinfo_html_xnormalizeTextInPreFirst_2 = {
  (unsigned char *)"normalizeTextInPreFirst",
  &predicate_html_xnormalizeTextInPreFirst_2
};

extern Const struct predicate predicate_html_xnormalizeTextInPre1_2;
static Const struct predinfo predinfo_html_xnormalizeTextInPre1_2 = {
  (unsigned char *)"normalizeTextInPre1",
  &predicate_html_xnormalizeTextInPre1_2
};

extern Const struct predicate predicate_html_xnormalizeHTML_2;
static Const struct predinfo predinfo_html_xnormalizeHTML_2 = {
  (unsigned char *)"normalizeHTML",
  &predicate_html_xnormalizeHTML_2
};

extern Const struct predicate predicate_html_xnormTag_2;
static Const struct predinfo predinfo_html_xnormTag_2 = {
  (unsigned char *)"normTag",
  &predicate_html_xnormTag_2
};

extern Const struct predicate predicate_html_xnormAttr_2;
static Const struct predinfo predinfo_html_xnormAttr_2 = {
  (unsigned char *)"normAttr",
  &predicate_html_xnormAttr_2
};

extern Const struct predicate predicate_html_xnormAttrValue_2;
static Const struct predinfo predinfo_html_xnormAttrValue_2 = {
  (unsigned char *)"normAttrValue",
  &predicate_html_xnormAttrValue_2
};

extern Const struct predicate predicate_html_xnormAttrValueSQ_2;
static Const struct predinfo predinfo_html_xnormAttrValueSQ_2 = {
  (unsigned char *)"normAttrValueSQ",
  &predicate_html_xnormAttrValueSQ_2
};

extern Const struct predicate predicate_html_xnormAttrValueDQ_2;
static Const struct predinfo predinfo_html_xnormAttrValueDQ_2 = {
  (unsigned char *)"normAttrValueDQ",
  &predicate_html_xnormAttrValueDQ_2
};

extern Const struct predicate predicate_html_xnoEndtag_1;
static Const struct predinfo predinfo_html_xnoEndtag_1 = {
  (unsigned char *)"noEndtag",
  &predicate_html_xnoEndtag_1
};

extern Const struct predicate predicate_html_xknownTag_1;
static Const struct predinfo predinfo_html_xknownTag_1 = {
  (unsigned char *)"knownTag",
  &predicate_html_xknownTag_1
};

extern Const struct predicate predicate_html_xhasAttr_3;
static Const struct predinfo predinfo_html_xhasAttr_3 = {
  (unsigned char *)"hasAttr",
  &predicate_html_xhasAttr_3
};

extern Const struct predicate predicate_html_xgetAttr_3;
static Const struct predinfo predinfo_html_xgetAttr_3 = {
  (unsigned char *)"getAttr",
  &predicate_html_xgetAttr_3
};

extern Const struct predicate predicate_html_xclosePtag_1;
static Const struct predinfo predinfo_html_xclosePtag_1 = {
  (unsigned char *)"closePtag",
  &predicate_html_xclosePtag_1
};

extern Const struct predicate predicate_html_xcheckTag_2;
static Const struct predinfo predinfo_html_xcheckTag_2 = {
  (unsigned char *)"checkTag",
  &predicate_html_xcheckTag_2
};

extern Const struct predicate predicate_html_xcatText_2;
static Const struct predinfo predinfo_html_xcatText_2 = {
  (unsigned char *)"catText",
  &predicate_html_xcatText_2
};

extern Const struct predicate predicate_html_xcatText1_4;
static Const struct predinfo predinfo_html_xcatText1_4 = {
  (unsigned char *)"catText1",
  &predicate_html_xcatText1_4
};

static Const struct predinfo * Const preds_in_html[] = {
  &predinfo_html_xunescape_2,
  &predinfo_html_xunescapeText_2,
  &predinfo_html_xrmNullText_2,
  &predinfo_html_xrmNullP_2,
  &predinfo_html_xrmNullElm_2,
  &predinfo_html_xrmNullAttr_2,
  &predinfo_html_xpartNameAttr_2,
  &predinfo_html_xpartNameAttr1_3,
  &predinfo_html_xpartAttr_4,
  &predinfo_html_xpartAttr2_3,
  &predinfo_html_xpartAttr2SQ_3,
  &predinfo_html_xpartAttr2NT_3,
  &predinfo_html_xpartAttr2DQ_3,
  &predinfo_html_xpartAttr1_3,
  &predinfo_html_xparseTag_3,
  &predinfo_html_xparseTag_2F3_246_4,
  &predinfo_html_xparseTag_2F3_245_4,
  &predinfo_html_xparseTag_2F3_244_6,
  &predinfo_html_xparseTag_2F3_244_2F6_240_6,
  &predinfo_html_xparseTag_2F3_244_2F6_240_2F6_240_5,
  &predinfo_html_xparseTag_2F3_244_2F6_240_2F6_240_2F5_240_4,
  &predinfo_html_xparseTag_2F3_243_4,
  &predinfo_html_xparseTag_2F3_243_2F4_240_7,
  &predinfo_html_xparseTag_2F3_242_4,
  &predinfo_html_xparseTag_2F3_241_4,
  &predinfo_html_xparseTag_2F3_240_6,
  &predinfo_html_xparseTag_2F3_240_2F6_241_4,
  &predinfo_html_xparseTag_2F3_240_2F6_241_2F4_240_7,
  &predinfo_html_xparseTag_2F3_240_2F6_240_5,
  &predinfo_html_xparseTag_2F3_240_2F6_240_2F5_240_4,
  &predinfo_html_xparseTag_2,
  &predinfo_html_xparseHTML_2,
  &predinfo_html_xparseBrac_3,
  &predinfo_html_xparseBracInText_4,
  &predinfo_html_xparseBracInTag_4,
  &predinfo_html_xparseBracInComment_3,
  &predinfo_html_xparseBracInComment1_3,
  &predinfo_html_xnormalizeText_2F2_240_4,
  &predinfo_html_xnormalizeText_2,
  &predinfo_html_xnormalizeTextInPre_2,
  &predinfo_html_xnormalizeTextInPreFirst_2,
  &predinfo_html_xnormalizeTextInPre1_2,
  &predinfo_html_xnormalizeHTML_2,
  &predinfo_html_xnormTag_2,
  &predinfo_html_xnormAttr_2,
  &predinfo_html_xnormAttrValue_2,
  &predinfo_html_xnormAttrValueSQ_2,
  &predinfo_html_xnormAttrValueDQ_2,
  &predinfo_html_xnoEndtag_1,
  &predinfo_html_xknownTag_1,
  &predinfo_html_xhasAttr_3,
  &predinfo_html_xgetAttr_3,
  &predinfo_html_xclosePtag_1,
  &predinfo_html_xcheckTag_2,
  &predinfo_html_xcatText_2,
  &predinfo_html_xcatText1_4,
  0
};
extern Const struct predicate predicate_inttostr_xinttostr_3;
static Const struct predinfo predinfo_inttostr_xinttostr_3 = {
  (unsigned char *)"inttostr",
  &predicate_inttostr_xinttostr_3
};

extern Const struct predicate predicate_inttostr_xinttostr_2F3_240_3;
static Const struct predinfo predinfo_inttostr_xinttostr_2F3_240_3 = {
  (unsigned char *)"inttostr/3$0",
  &predicate_inttostr_xinttostr_2F3_240_3
};

extern Const struct predicate predicate_inttostr_xintegertostring_2;
static Const struct predinfo predinfo_inttostr_xintegertostring_2 = {
  (unsigned char *)"integertostring",
  &predicate_inttostr_xintegertostring_2
};

static Const struct predinfo * Const preds_in_inttostr[] = {
  &predinfo_inttostr_xinttostr_3,
  &predinfo_inttostr_xinttostr_2F3_240_3,
  &predinfo_inttostr_xintegertostring_2,
  0
};
extern Const struct predicate predicate_atom__table_xset__atom__string_5;
static Const struct predinfo predinfo_atom__table_xset__atom__string_5 = {
  (unsigned char *)"set_atom_string",
  &predicate_atom__table_xset__atom__string_5
};

extern Const struct predicate predicate_atom__table_xmake__atom_2;
static Const struct predinfo predinfo_atom__table_xmake__atom_2 = {
  (unsigned char *)"make_atom",
  &predicate_atom__table_xmake__atom_2
};

extern Const struct predicate predicate_atom__table_xintern_2;
static Const struct predinfo predinfo_atom__table_xintern_2 = {
  (unsigned char *)"intern",
  &predicate_atom__table_xintern_2
};

extern Const struct predicate predicate_atom__table_xget__atom__string_2;
static Const struct predinfo predinfo_atom__table_xget__atom__string_2 = {
  (unsigned char *)"get_atom_string",
  &predicate_atom__table_xget__atom__string_2
};

extern Const struct predicate predicate_atom__table_xget__atom__name_2;
static Const struct predinfo predinfo_atom__table_xget__atom__name_2 = {
  (unsigned char *)"get_atom_name",
  &predicate_atom__table_xget__atom__name_2
};

extern Const struct predicate predicate_atom__table_xcache__table_1;
static Const struct predinfo predinfo_atom__table_xcache__table_1 = {
  (unsigned char *)"cache_table",
  &predicate_atom__table_xcache__table_1
};

extern Const struct predicate predicate_atom__table_xatom__number_2;
static Const struct predinfo predinfo_atom__table_xatom__number_2 = {
  (unsigned char *)"atom_number",
  &predicate_atom__table_xatom__number_2
};

static Const struct predinfo * Const preds_in_atom__table[] = {
  &predinfo_atom__table_xset__atom__string_5,
  &predinfo_atom__table_xmake__atom_2,
  &predinfo_atom__table_xintern_2,
  &predinfo_atom__table_xget__atom__string_2,
  &predinfo_atom__table_xget__atom__name_2,
  &predinfo_atom__table_xcache__table_1,
  &predinfo_atom__table_xatom__number_2,
  0
};
extern Const struct predicate predicate_tohtml_xtohtml_2;
static Const struct predinfo predinfo_tohtml_xtohtml_2 = {
  (unsigned char *)"tohtml",
  &predicate_tohtml_xtohtml_2
};

extern Const struct predicate predicate_tohtml_xjoin__inline__tags_3;
static Const struct predinfo predinfo_tohtml_xjoin__inline__tags_3 = {
  (unsigned char *)"join_inline_tags",
  &predicate_tohtml_xjoin__inline__tags_3
};

extern Const struct predicate predicate_tohtml_xget__endtag_3;
static Const struct predinfo predinfo_tohtml_xget__endtag_3 = {
  (unsigned char *)"get_endtag",
  &predicate_tohtml_xget__endtag_3
};

extern Const struct predicate predicate_tohtml_xget__endtag_2F3_240_3;
static Const struct predinfo predinfo_tohtml_xget__endtag_2F3_240_3 = {
  (unsigned char *)"get_endtag/3$0",
  &predicate_tohtml_xget__endtag_2F3_240_3
};

extern Const struct predicate predicate_tohtml_xconvert__to__html_4;
static Const struct predinfo predinfo_tohtml_xconvert__to__html_4 = {
  (unsigned char *)"convert_to_html",
  &predicate_tohtml_xconvert__to__html_4
};

extern Const struct predicate predicate_tohtml_xarglist_4;
static Const struct predinfo predinfo_tohtml_xarglist_4 = {
  (unsigned char *)"arglist",
  &predicate_tohtml_xarglist_4
};

extern Const struct predicate predicate_tohtml_xarglist_3;
static Const struct predinfo predinfo_tohtml_xarglist_3 = {
  (unsigned char *)"arglist",
  &predicate_tohtml_xarglist_3
};

static Const struct predinfo * Const preds_in_tohtml[] = {
  &predinfo_tohtml_xtohtml_2,
  &predinfo_tohtml_xjoin__inline__tags_3,
  &predinfo_tohtml_xget__endtag_3,
  &predinfo_tohtml_xget__endtag_2F3_240_3,
  &predinfo_tohtml_xconvert__to__html_4,
  &predinfo_tohtml_xarglist_4,
  &predinfo_tohtml_xarglist_3,
  0
};
extern Const struct predicate predicate_url_xtoHexChars_3;
static Const struct predinfo predinfo_url_xtoHexChars_3 = {
  (unsigned char *)"toHexChars",
  &predicate_url_xtoHexChars_3
};

extern Const struct predicate predicate_url_xtoChar_2;
static Const struct predinfo predinfo_url_xtoChar_2 = {
  (unsigned char *)"toChar",
  &predicate_url_xtoChar_2
};

extern Const struct predicate predicate_url_xrmQuery_2F2_240_3;
static Const struct predinfo predinfo_url_xrmQuery_2F2_240_3 = {
  (unsigned char *)"rmQuery/2$0",
  &predicate_url_xrmQuery_2F2_240_3
};

extern Const struct predicate predicate_url_xrmQuery_2;
static Const struct predinfo predinfo_url_xrmQuery_2 = {
  (unsigned char *)"rmQuery",
  &predicate_url_xrmQuery_2
};

extern Const struct predicate predicate_url_xpartURLpath_3;
static Const struct predinfo predinfo_url_xpartURLpath_3 = {
  (unsigned char *)"partURLpath",
  &predicate_url_xpartURLpath_3
};

extern Const struct predicate predicate_url_xpartURLnetloc_4;
static Const struct predinfo predinfo_url_xpartURLnetloc_4 = {
  (unsigned char *)"partURLnetloc",
  &predicate_url_xpartURLnetloc_4
};

extern Const struct predicate predicate_url_xpartURLnetloc1_4;
static Const struct predinfo predinfo_url_xpartURLnetloc1_4 = {
  (unsigned char *)"partURLnetloc1",
  &predicate_url_xpartURLnetloc1_4
};

extern Const struct predicate predicate_url_xpartURL_5;
static Const struct predinfo predinfo_url_xpartURL_5 = {
  (unsigned char *)"partURL",
  &predicate_url_xpartURL_5
};

extern Const struct predicate predicate_url_xpartURL1_5;
static Const struct predinfo predinfo_url_xpartURL1_5 = {
  (unsigned char *)"partURL1",
  &predicate_url_xpartURL1_5
};

extern Const struct predicate predicate_url_xpartScheme_3;
static Const struct predinfo predinfo_url_xpartScheme_3 = {
  (unsigned char *)"partScheme",
  &predicate_url_xpartScheme_3
};

extern Const struct predicate predicate_url_xpartScheme1_3;
static Const struct predinfo predinfo_url_xpartScheme1_3 = {
  (unsigned char *)"partScheme1",
  &predicate_url_xpartScheme1_3
};

extern Const struct predicate predicate_url_xpartPath_3;
static Const struct predinfo predinfo_url_xpartPath_3 = {
  (unsigned char *)"partPath",
  &predicate_url_xpartPath_3
};

extern Const struct predicate predicate_url_xpartPath_2;
static Const struct predinfo predinfo_url_xpartPath_2 = {
  (unsigned char *)"partPath",
  &predicate_url_xpartPath_2
};

extern Const struct predicate predicate_url_xpartNetLoc_3;
static Const struct predinfo predinfo_url_xpartNetLoc_3 = {
  (unsigned char *)"partNetLoc",
  &predicate_url_xpartNetLoc_3
};

extern Const struct predicate predicate_url_xpartNetLoc_2F3_240_4;
static Const struct predinfo predinfo_url_xpartNetLoc_2F3_240_4 = {
  (unsigned char *)"partNetLoc/3$0",
  &predicate_url_xpartNetLoc_2F3_240_4
};

extern Const struct predicate predicate_url_xnormalizePath_2;
static Const struct predinfo predinfo_url_xnormalizePath_2 = {
  (unsigned char *)"normalizePath",
  &predicate_url_xnormalizePath_2
};

extern Const struct predicate predicate_url_xnormalizePath2_2;
static Const struct predinfo predinfo_url_xnormalizePath2_2 = {
  (unsigned char *)"normalizePath2",
  &predicate_url_xnormalizePath2_2
};

extern Const struct predicate predicate_url_xnormalizePath22_3;
static Const struct predinfo predinfo_url_xnormalizePath22_3 = {
  (unsigned char *)"normalizePath22",
  &predicate_url_xnormalizePath22_3
};

extern Const struct predicate predicate_url_xnormalizePath21_3;
static Const struct predinfo predinfo_url_xnormalizePath21_3 = {
  (unsigned char *)"normalizePath21",
  &predicate_url_xnormalizePath21_3
};

extern Const struct predicate predicate_url_xnormalizePath1_2;
static Const struct predinfo predinfo_url_xnormalizePath1_2 = {
  (unsigned char *)"normalizePath1",
  &predicate_url_xnormalizePath1_2
};

extern Const struct predicate predicate_url_xneedEncode_2;
static Const struct predinfo predinfo_url_xneedEncode_2 = {
  (unsigned char *)"needEncode",
  &predicate_url_xneedEncode_2
};

extern Const struct predicate predicate_url_xmkabsURL_3;
static Const struct predinfo predinfo_url_xmkabsURL_3 = {
  (unsigned char *)"mkabsURL",
  &predicate_url_xmkabsURL_3
};

extern Const struct predicate predicate_url_xmkabsURL_2F3_241_7;
static Const struct predinfo predinfo_url_xmkabsURL_2F3_241_7 = {
  (unsigned char *)"mkabsURL/3$1",
  &predicate_url_xmkabsURL_2F3_241_7
};

extern Const struct predicate predicate_url_xmkabsURL_2F3_241_2F7_240_7;
static Const struct predinfo predinfo_url_xmkabsURL_2F3_241_2F7_240_7 = {
  (unsigned char *)"mkabsURL/3$1/7$0",
  &predicate_url_xmkabsURL_2F3_241_2F7_240_7
};

extern Const struct predicate predicate_url_xmkabsURL_2F3_241_2F7_240_2F7_240_7;
static Const struct predinfo predinfo_url_xmkabsURL_2F3_241_2F7_240_2F7_240_7 = {
  (unsigned char *)"mkabsURL/3$1/7$0/7$0",
  &predicate_url_xmkabsURL_2F3_241_2F7_240_2F7_240_7
};

extern Const struct predicate predicate_url_xmkabsURL_2F3_241_2F7_240_2F7_240_2F7_240_6;
static Const struct predinfo predinfo_url_xmkabsURL_2F3_241_2F7_240_2F7_240_2F7_240_6 = {
  (unsigned char *)"mkabsURL/3$1/7$0/7$0/7$0",
  &predicate_url_xmkabsURL_2F3_241_2F7_240_2F7_240_2F7_240_6
};

extern Const struct predicate predicate_url_xmkabsURL_2F3_240_5;
static Const struct predinfo predinfo_url_xmkabsURL_2F3_240_5 = {
  (unsigned char *)"mkabsURL/3$0",
  &predicate_url_xmkabsURL_2F3_240_5
};

extern Const struct predicate predicate_url_xisAbsURL_3;
static Const struct predinfo predinfo_url_xisAbsURL_3 = {
  (unsigned char *)"isAbsURL",
  &predicate_url_xisAbsURL_3
};

extern Const struct predicate predicate_url_xfromScheme_2F2_240_3;
static Const struct predinfo predinfo_url_xfromScheme_2F2_240_3 = {
  (unsigned char *)"fromScheme/2$0",
  &predicate_url_xfromScheme_2F2_240_3
};

extern Const struct predicate predicate_url_xfromScheme_2F2_240_2F3_240_2;
static Const struct predinfo predinfo_url_xfromScheme_2F2_240_2F3_240_2 = {
  (unsigned char *)"fromScheme/2$0/3$0",
  &predicate_url_xfromScheme_2F2_240_2F3_240_2
};

extern Const struct predicate predicate_url_xfromScheme_2;
static Const struct predinfo predinfo_url_xfromScheme_2 = {
  (unsigned char *)"fromScheme",
  &predicate_url_xfromScheme_2
};

extern Const struct predicate predicate_url_xfromNetPath_2;
static Const struct predinfo predinfo_url_xfromNetPath_2 = {
  (unsigned char *)"fromNetPath",
  &predicate_url_xfromNetPath_2
};

extern Const struct predicate predicate_url_xfromFragment_2;
static Const struct predinfo predinfo_url_xfromFragment_2 = {
  (unsigned char *)"fromFragment",
  &predicate_url_xfromFragment_2
};

extern Const struct predicate predicate_url_xfromAbsPath_2;
static Const struct predinfo predinfo_url_xfromAbsPath_2 = {
  (unsigned char *)"fromAbsPath",
  &predicate_url_xfromAbsPath_2
};

extern Const struct predicate predicate_url_xencode_2;
static Const struct predinfo predinfo_url_xencode_2 = {
  (unsigned char *)"encode",
  &predicate_url_xencode_2
};

extern Const struct predicate predicate_url_xencodeQueries_2;
static Const struct predinfo predinfo_url_xencodeQueries_2 = {
  (unsigned char *)"encodeQueries",
  &predicate_url_xencodeQueries_2
};

extern Const struct predicate predicate_url_xencodeQueries1_3;
static Const struct predinfo predinfo_url_xencodeQueries1_3 = {
  (unsigned char *)"encodeQueries1",
  &predicate_url_xencodeQueries1_3
};

extern Const struct predicate predicate_url_xencode1_2F2_240_4;
static Const struct predinfo predinfo_url_xencode1_2F2_240_4 = {
  (unsigned char *)"encode1/2$0",
  &predicate_url_xencode1_2F2_240_4
};

extern Const struct predicate predicate_url_xencode1_2F2_240_2F4_240_3;
static Const struct predinfo predinfo_url_xencode1_2F2_240_2F4_240_3 = {
  (unsigned char *)"encode1/2$0/4$0",
  &predicate_url_xencode1_2F2_240_2F4_240_3
};

extern Const struct predicate predicate_url_xencode1_2;
static Const struct predinfo predinfo_url_xencode1_2 = {
  (unsigned char *)"encode1",
  &predicate_url_xencode1_2
};

extern Const struct predicate predicate_url_xcutTail_2;
static Const struct predinfo predinfo_url_xcutTail_2 = {
  (unsigned char *)"cutTail",
  &predicate_url_xcutTail_2
};

extern Const struct predicate predicate_url_xcutTail1_2;
static Const struct predinfo predinfo_url_xcutTail1_2 = {
  (unsigned char *)"cutTail1",
  &predicate_url_xcutTail1_2
};

extern Const struct predicate predicate_url_xappendPath_2;
static Const struct predinfo predinfo_url_xappendPath_2 = {
  (unsigned char *)"appendPath",
  &predicate_url_xappendPath_2
};

static Const struct predinfo * Const preds_in_url[] = {
  &predinfo_url_xtoHexChars_3,
  &predinfo_url_xtoChar_2,
  &predinfo_url_xrmQuery_2F2_240_3,
  &predinfo_url_xrmQuery_2,
  &predinfo_url_xpartURLpath_3,
  &predinfo_url_xpartURLnetloc_4,
  &predinfo_url_xpartURLnetloc1_4,
  &predinfo_url_xpartURL_5,
  &predinfo_url_xpartURL1_5,
  &predinfo_url_xpartScheme_3,
  &predinfo_url_xpartScheme1_3,
  &predinfo_url_xpartPath_3,
  &predinfo_url_xpartPath_2,
  &predinfo_url_xpartNetLoc_3,
  &predinfo_url_xpartNetLoc_2F3_240_4,
  &predinfo_url_xnormalizePath_2,
  &predinfo_url_xnormalizePath2_2,
  &predinfo_url_xnormalizePath22_3,
  &predinfo_url_xnormalizePath21_3,
  &predinfo_url_xnormalizePath1_2,
  &predinfo_url_xneedEncode_2,
  &predinfo_url_xmkabsURL_3,
  &predinfo_url_xmkabsURL_2F3_241_7,
  &predinfo_url_xmkabsURL_2F3_241_2F7_240_7,
  &predinfo_url_xmkabsURL_2F3_241_2F7_240_2F7_240_7,
  &predinfo_url_xmkabsURL_2F3_241_2F7_240_2F7_240_2F7_240_6,
  &predinfo_url_xmkabsURL_2F3_240_5,
  &predinfo_url_xisAbsURL_3,
  &predinfo_url_xfromScheme_2F2_240_3,
  &predinfo_url_xfromScheme_2F2_240_2F3_240_2,
  &predinfo_url_xfromScheme_2,
  &predinfo_url_xfromNetPath_2,
  &predinfo_url_xfromFragment_2,
  &predinfo_url_xfromAbsPath_2,
  &predinfo_url_xencode_2,
  &predinfo_url_xencodeQueries_2,
  &predinfo_url_xencodeQueries1_3,
  &predinfo_url_xencode1_2F2_240_4,
  &predinfo_url_xencode1_2F2_240_2F4_240_3,
  &predinfo_url_xencode1_2,
  &predinfo_url_xcutTail_2,
  &predinfo_url_xcutTail1_2,
  &predinfo_url_xappendPath_2,
  0
};
extern Const struct predicate predicate_functor__table_xsetarg_5;
static Const struct predinfo predinfo_functor__table_xsetarg_5 = {
  (unsigned char *)"setarg",
  &predicate_functor__table_xsetarg_5
};

extern Const struct predicate predicate_functor__table_xsetarg_4;
static Const struct predinfo predinfo_functor__table_xsetarg_4 = {
  (unsigned char *)"setarg",
  &predicate_functor__table_xsetarg_4
};

extern Const struct predicate predicate_functor__table_xnew__functor_3;
static Const struct predinfo predinfo_functor__table_xnew__functor_3 = {
  (unsigned char *)"new_functor",
  &predicate_functor__table_xnew__functor_3
};

extern Const struct predicate predicate_functor__table_xlength_3;
static Const struct predinfo predinfo_functor__table_xlength_3 = {
  (unsigned char *)"length",
  &predicate_functor__table_xlength_3
};

extern Const struct predicate predicate_functor__table_xfunctor_4;
static Const struct predinfo predinfo_functor__table_xfunctor_4 = {
  (unsigned char *)"functor",
  &predicate_functor__table_xfunctor_4
};

extern Const struct predicate predicate_functor__table_xfunctor_3;
static Const struct predinfo predinfo_functor__table_xfunctor_3 = {
  (unsigned char *)"functor",
  &predicate_functor__table_xfunctor_3
};

extern Const struct predicate predicate_functor__table_xfill__args_4;
static Const struct predinfo predinfo_functor__table_xfill__args_4 = {
  (unsigned char *)"fill_args",
  &predicate_functor__table_xfill__args_4
};

extern Const struct predicate predicate_functor__table_xarg_4;
static Const struct predinfo predinfo_functor__table_xarg_4 = {
  (unsigned char *)"arg",
  &predicate_functor__table_xarg_4
};

extern Const struct predicate predicate_functor__table_xarg_3;
static Const struct predinfo predinfo_functor__table_xarg_3 = {
  (unsigned char *)"arg",
  &predicate_functor__table_xarg_3
};

extern Const struct predicate predicate_functor__table_x_3D_2E_2E_2;
static Const struct predinfo predinfo_functor__table_x_3D_2E_2E_2 = {
  (unsigned char *)"=..",
  &predicate_functor__table_x_3D_2E_2E_2
};

static Const struct predinfo * Const preds_in_functor__table[] = {
  &predinfo_functor__table_xsetarg_5,
  &predinfo_functor__table_xsetarg_4,
  &predinfo_functor__table_xnew__functor_3,
  &predinfo_functor__table_xlength_3,
  &predinfo_functor__table_xfunctor_4,
  &predinfo_functor__table_xfunctor_3,
  &predinfo_functor__table_xfill__args_4,
  &predinfo_functor__table_xarg_4,
  &predinfo_functor__table_xarg_3,
  &predinfo_functor__table_x_3D_2E_2E_2,
  0
};
extern Const struct predicate predicate_builtin_xstart__measure_0;
static Const struct predinfo predinfo_builtin_xstart__measure_0 = {
  (unsigned char *)"start_measure",
  &predicate_builtin_xstart__measure_0
};

extern Const struct predicate predicate_builtin_xreport__measure_1;
static Const struct predinfo predinfo_builtin_xreport__measure_1 = {
  (unsigned char *)"report_measure",
  &predicate_builtin_xreport__measure_1
};

extern Const struct predicate predicate_builtin_xreadint_1;
static Const struct predinfo predinfo_builtin_xreadint_1 = {
  (unsigned char *)"readint",
  &predicate_builtin_xreadint_1
};

extern Const struct predicate predicate_builtin_xputc_2;
static Const struct predinfo predinfo_builtin_xputc_2 = {
  (unsigned char *)"putc",
  &predicate_builtin_xputc_2
};

extern Const struct predicate predicate_builtin_xprint_2;
static Const struct predinfo predinfo_builtin_xprint_2 = {
  (unsigned char *)"print",
  &predicate_builtin_xprint_2
};

extern Const struct predicate predicate_builtin_xprint_1;
static Const struct predinfo predinfo_builtin_xprint_1 = {
  (unsigned char *)"print",
  &predicate_builtin_xprint_1
};

extern Const struct predicate predicate_builtin_xidle_0;
static Const struct predinfo predinfo_builtin_xidle_0 = {
  (unsigned char *)"idle",
  &predicate_builtin_xidle_0
};

extern Const struct predicate predicate_builtin_xcurrent__node_2;
static Const struct predinfo predinfo_builtin_xcurrent__node_2 = {
  (unsigned char *)"current_node",
  &predicate_builtin_xcurrent__node_2
};

static Const struct predinfo * Const preds_in_builtin[] = {
  &predinfo_builtin_xstart__measure_0,
  &predinfo_builtin_xreport__measure_1,
  &predinfo_builtin_xreadint_1,
  &predinfo_builtin_xputc_2,
  &predinfo_builtin_xprint_2,
  &predinfo_builtin_xprint_1,
  &predinfo_builtin_xidle_0,
  &predinfo_builtin_xcurrent__node_2,
  0
};
extern Const struct predicate predicate_main_xsearch__to__depth_7;
static Const struct predinfo predinfo_main_xsearch__to__depth_7 = {
  (unsigned char *)"search_to_depth",
  &predicate_main_xsearch__to__depth_7
};

extern Const struct predicate predicate_main_xsearch__to__depth_2F7_240_2F11_240_4;
static Const struct predinfo predinfo_main_xsearch__to__depth_2F7_240_2F11_240_4 = {
  (unsigned char *)"search_to_depth/7$0/11$0",
  &predicate_main_xsearch__to__depth_2F7_240_2F11_240_4
};

extern Const struct predicate predicate_main_xsearch__to__depth_2F7_240_11;
static Const struct predinfo predinfo_main_xsearch__to__depth_2F7_240_11 = {
  (unsigned char *)"search_to_depth/7$0",
  &predicate_main_xsearch__to__depth_2F7_240_11
};

extern Const struct predicate predicate_main_xsearch__page_4;
static Const struct predinfo predinfo_main_xsearch__page_4 = {
  (unsigned char *)"search_page",
  &predicate_main_xsearch__page_4
};

extern Const struct predicate predicate_main_xno__response__page_1;
static Const struct predinfo predinfo_main_xno__response__page_1 = {
  (unsigned char *)"no_response_page",
  &predicate_main_xno__response__page_1
};

extern Const struct predicate predicate_main_xmain_0;
static Const struct predinfo predinfo_main_xmain_0 = {
  (unsigned char *)"main",
  &predicate_main_xmain_0
};

extern Const struct predicate predicate_main_xgetwebpage_5;
static Const struct predinfo predinfo_main_xgetwebpage_5 = {
  (unsigned char *)"getwebpage",
  &predicate_main_xgetwebpage_5
};

extern Const struct predicate predicate_main_xgetwebpage_3;
static Const struct predinfo predinfo_main_xgetwebpage_3 = {
  (unsigned char *)"getwebpage",
  &predicate_main_xgetwebpage_3
};

extern Const struct predicate predicate_main_xgetwebpage_2F5_240_5;
static Const struct predinfo predinfo_main_xgetwebpage_2F5_240_5 = {
  (unsigned char *)"getwebpage/5$0",
  &predicate_main_xgetwebpage_2F5_240_5
};

extern Const struct predicate predicate_main_xgetwebpage_2F5_240_2F5_240_5;
static Const struct predinfo predinfo_main_xgetwebpage_2F5_240_2F5_240_5 = {
  (unsigned char *)"getwebpage/5$0/5$0",
  &predicate_main_xgetwebpage_2F5_240_2F5_240_5
};

extern Const struct predicate predicate_main_xgetwebpage_2F5_240_2F5_240_2F5_240_4;
static Const struct predinfo predinfo_main_xgetwebpage_2F5_240_2F5_240_2F5_240_4 = {
  (unsigned char *)"getwebpage/5$0/5$0/5$0",
  &predicate_main_xgetwebpage_2F5_240_2F5_240_2F5_240_4
};

extern Const struct predicate predicate_main_xget__link__list_2;
static Const struct predinfo predinfo_main_xget__link__list_2 = {
  (unsigned char *)"get_link_list",
  &predicate_main_xget__link__list_2
};

extern Const struct predicate predicate_main_xget__link__list2_3;
static Const struct predinfo predinfo_main_xget__link__list2_3 = {
  (unsigned char *)"get_link_list2",
  &predicate_main_xget__link__list2_3
};

extern Const struct predicate predicate_main_xget__link__list2_2;
static Const struct predinfo predinfo_main_xget__link__list2_2 = {
  (unsigned char *)"get_link_list2",
  &predicate_main_xget__link__list2_2
};

extern Const struct predicate predicate_main_xget__link__list1_2;
static Const struct predinfo predinfo_main_xget__link__list1_2 = {
  (unsigned char *)"get_link_list1",
  &predicate_main_xget__link__list1_2
};

extern Const struct predicate predicate_main_xform__page_2;
static Const struct predinfo predinfo_main_xform__page_2 = {
  (unsigned char *)"form_page",
  &predicate_main_xform__page_2
};

extern Const struct predicate predicate_main_xform__graph_4;
static Const struct predinfo predinfo_main_xform__graph_4 = {
  (unsigned char *)"form_graph",
  &predicate_main_xform__graph_4
};

extern Const struct predicate predicate_main_xform__graph_3;
static Const struct predinfo predinfo_main_xform__graph_3 = {
  (unsigned char *)"form_graph",
  &predicate_main_xform__graph_3
};

extern Const struct predicate predicate_main_xfind__links_3;
static Const struct predinfo predinfo_main_xfind__links_3 = {
  (unsigned char *)"find_links",
  &predicate_main_xfind__links_3
};

extern Const struct predicate predicate_main_xfind__links1_3;
static Const struct predinfo predinfo_main_xfind__links1_3 = {
  (unsigned char *)"find_links1",
  &predicate_main_xfind__links1_3
};

extern Const struct predicate predicate_main_xfind__base_3;
static Const struct predinfo predinfo_main_xfind__base_3 = {
  (unsigned char *)"find_base",
  &predicate_main_xfind__base_3
};

extern Const struct predicate predicate_main_xfind__base_2F3_240_2;
static Const struct predinfo predinfo_main_xfind__base_2F3_240_2 = {
  (unsigned char *)"find_base/3$0",
  &predicate_main_xfind__base_2F3_240_2
};

extern Const struct predicate predicate_main_xfind__base_2F2_240_3;
static Const struct predinfo predinfo_main_xfind__base_2F2_240_3 = {
  (unsigned char *)"find_base/2$0",
  &predicate_main_xfind__base_2F2_240_3
};

extern Const struct predicate predicate_main_xfind__base_2;
static Const struct predinfo predinfo_main_xfind__base_2 = {
  (unsigned char *)"find_base",
  &predicate_main_xfind__base_2
};

extern Const struct predicate predicate_main_xfind__base1_2F2_240_3;
static Const struct predinfo predinfo_main_xfind__base1_2F2_240_3 = {
  (unsigned char *)"find_base1/2$0",
  &predicate_main_xfind__base1_2F2_240_3
};

extern Const struct predicate predicate_main_xfind__base1_2;
static Const struct predinfo predinfo_main_xfind__base1_2 = {
  (unsigned char *)"find_base1",
  &predicate_main_xfind__base1_2
};

extern Const struct predicate predicate_main_xfind__args_4;
static Const struct predinfo predinfo_main_xfind__args_4 = {
  (unsigned char *)"find_args",
  &predicate_main_xfind__args_4
};

extern Const struct predicate predicate_main_xfind__args_3;
static Const struct predinfo predinfo_main_xfind__args_3 = {
  (unsigned char *)"find_args",
  &predicate_main_xfind__args_3
};

extern Const struct predicate predicate_main_xcheck__body_2F2_240_2;
static Const struct predinfo predinfo_main_xcheck__body_2F2_240_2 = {
  (unsigned char *)"check_body/2$0",
  &predicate_main_xcheck__body_2F2_240_2
};

extern Const struct predicate predicate_main_xcheck__body_2;
static Const struct predinfo predinfo_main_xcheck__body_2 = {
  (unsigned char *)"check_body",
  &predicate_main_xcheck__body_2
};

extern Const struct predicate predicate_main_xcheck__base_3;
static Const struct predinfo predinfo_main_xcheck__base_3 = {
  (unsigned char *)"check_base",
  &predicate_main_xcheck__base_3
};

extern Const struct predicate predicate_main_xcheck__base_2F3_240_3;
static Const struct predinfo predinfo_main_xcheck__base_2F3_240_3 = {
  (unsigned char *)"check_base/3$0",
  &predicate_main_xcheck__base_2F3_240_3
};

extern Const struct predicate predicate_main_xattach__base_4;
static Const struct predinfo predinfo_main_xattach__base_4 = {
  (unsigned char *)"attach_base",
  &predicate_main_xattach__base_4
};

extern Const struct predicate predicate_main_xattach__base_3;
static Const struct predinfo predinfo_main_xattach__base_3 = {
  (unsigned char *)"attach_base",
  &predicate_main_xattach__base_3
};

extern Const struct predicate predicate_main_xattach__base_2F4_240_7;
static Const struct predinfo predinfo_main_xattach__base_2F4_240_7 = {
  (unsigned char *)"attach_base/4$0",
  &predicate_main_xattach__base_2F4_240_7
};

extern Const struct predicate predicate_main_x_2C_2;
static Const struct predinfo predinfo_main_x_2C_2 = {
  (unsigned char *)",",
  &predicate_main_x_2C_2
};

static Const struct predinfo * Const preds_in_main[] = {
  &predinfo_main_xsearch__to__depth_7,
  &predinfo_main_xsearch__to__depth_2F7_240_2F11_240_4,
  &predinfo_main_xsearch__to__depth_2F7_240_11,
  &predinfo_main_xsearch__page_4,
  &predinfo_main_xno__response__page_1,
  &predinfo_main_xmain_0,
  &predinfo_main_xgetwebpage_5,
  &predinfo_main_xgetwebpage_3,
  &predinfo_main_xgetwebpage_2F5_240_5,
  &predinfo_main_xgetwebpage_2F5_240_2F5_240_5,
  &predinfo_main_xgetwebpage_2F5_240_2F5_240_2F5_240_4,
  &predinfo_main_xget__link__list_2,
  &predinfo_main_xget__link__list2_3,
  &predinfo_main_xget__link__list2_2,
  &predinfo_main_xget__link__list1_2,
  &predinfo_main_xform__page_2,
  &predinfo_main_xform__graph_4,
  &predinfo_main_xform__graph_3,
  &predinfo_main_xfind__links_3,
  &predinfo_main_xfind__links1_3,
  &predinfo_main_xfind__base_3,
  &predinfo_main_xfind__base_2F3_240_2,
  &predinfo_main_xfind__base_2F2_240_3,
  &predinfo_main_xfind__base_2,
  &predinfo_main_xfind__base1_2F2_240_3,
  &predinfo_main_xfind__base1_2,
  &predinfo_main_xfind__args_4,
  &predinfo_main_xfind__args_3,
  &predinfo_main_xcheck__body_2F2_240_2,
  &predinfo_main_xcheck__body_2,
  &predinfo_main_xcheck__base_3,
  &predinfo_main_xcheck__base_2F3_240_3,
  &predinfo_main_xattach__base_4,
  &predinfo_main_xattach__base_3,
  &predinfo_main_xattach__base_2F4_240_7,
  &predinfo_main_x_2C_2,
  0
};
extern Const struct predicate predicate_generic_xnew_3;
static Const struct predinfo predinfo_generic_xnew_3 = {
  (unsigned char *)"new",
  &predicate_generic_xnew_3
};

extern Const struct predicate predicate_generic_xgeneric_2;
static Const struct predinfo predinfo_generic_xgeneric_2 = {
  (unsigned char *)"generic",
  &predicate_generic_xgeneric_2
};

static Const struct predinfo * Const preds_in_generic[] = {
  &predinfo_generic_xnew_3,
  &predinfo_generic_xgeneric_2,
  0
};
extern Const struct predicate predicate_unify__term__dcode_xunify__pf_2;
static Const struct predinfo predinfo_unify__term__dcode_xunify__pf_2 = {
  (unsigned char *)"unify_pf",
  &predicate_unify__term__dcode_xunify__pf_2
};

extern Const struct predicate predicate_unify__term__dcode_xunify__goal_2;
static Const struct predinfo predinfo_unify__term__dcode_xunify__goal_2 = {
  (unsigned char *)"unify_goal",
  &predicate_unify__term__dcode_xunify__goal_2
};

extern Const struct predicate predicate_unify__term__dcode_xunify__args_3;
static Const struct predinfo predinfo_unify__term__dcode_xunify__args_3 = {
  (unsigned char *)"unify_args",
  &predicate_unify__term__dcode_xunify__args_3
};

extern Const struct predicate predicate_unify__term__dcode_xunify_2;
static Const struct predinfo predinfo_unify__term__dcode_xunify_2 = {
  (unsigned char *)"unify",
  &predicate_unify__term__dcode_xunify_2
};

static Const struct predinfo * Const preds_in_unify__term__dcode[] = {
  &predinfo_unify__term__dcode_xunify__pf_2,
  &predinfo_unify__term__dcode_xunify__goal_2,
  &predinfo_unify__term__dcode_xunify__args_3,
  &predinfo_unify__term__dcode_xunify_2,
  0
};
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
static Const struct predinfo predinfo_integer__arithmetics_xsubtract_3 = {
  (unsigned char *)"subtract",
  &predicate_integer__arithmetics_xsubtract_3
};

extern Const struct predicate predicate_integer__arithmetics_xshift__right_3;
static Const struct predinfo predinfo_integer__arithmetics_xshift__right_3 = {
  (unsigned char *)"shift_right",
  &predicate_integer__arithmetics_xshift__right_3
};

extern Const struct predicate predicate_integer__arithmetics_xshift__left_3;
static Const struct predinfo predinfo_integer__arithmetics_xshift__left_3 = {
  (unsigned char *)"shift_left",
  &predicate_integer__arithmetics_xshift__left_3
};

extern Const struct predicate predicate_integer__arithmetics_xplus_2;
static Const struct predinfo predinfo_integer__arithmetics_xplus_2 = {
  (unsigned char *)"plus",
  &predicate_integer__arithmetics_xplus_2
};

extern Const struct predicate predicate_integer__arithmetics_xor_3;
static Const struct predinfo predinfo_integer__arithmetics_xor_3 = {
  (unsigned char *)"or",
  &predicate_integer__arithmetics_xor_3
};

extern Const struct predicate predicate_integer__arithmetics_xmultiply_3;
static Const struct predinfo predinfo_integer__arithmetics_xmultiply_3 = {
  (unsigned char *)"multiply",
  &predicate_integer__arithmetics_xmultiply_3
};

extern Const struct predicate predicate_integer__arithmetics_xmodulo_3;
static Const struct predinfo predinfo_integer__arithmetics_xmodulo_3 = {
  (unsigned char *)"modulo",
  &predicate_integer__arithmetics_xmodulo_3
};

extern Const struct predicate predicate_integer__arithmetics_xminus_2;
static Const struct predinfo predinfo_integer__arithmetics_xminus_2 = {
  (unsigned char *)"minus",
  &predicate_integer__arithmetics_xminus_2
};

extern Const struct predicate predicate_integer__arithmetics_xexclusive__or_3;
static Const struct predinfo predinfo_integer__arithmetics_xexclusive__or_3 = {
  (unsigned char *)"exclusive_or",
  &predicate_integer__arithmetics_xexclusive__or_3
};

extern Const struct predicate predicate_integer__arithmetics_xdivide_3;
static Const struct predinfo predinfo_integer__arithmetics_xdivide_3 = {
  (unsigned char *)"divide",
  &predicate_integer__arithmetics_xdivide_3
};

extern Const struct predicate predicate_integer__arithmetics_xcomplement_2;
static Const struct predinfo predinfo_integer__arithmetics_xcomplement_2 = {
  (unsigned char *)"complement",
  &predicate_integer__arithmetics_xcomplement_2
};

extern Const struct predicate predicate_integer__arithmetics_xand_3;
static Const struct predinfo predinfo_integer__arithmetics_xand_3 = {
  (unsigned char *)"and",
  &predicate_integer__arithmetics_xand_3
};

extern Const struct predicate predicate_integer__arithmetics_xadd_3;
static Const struct predinfo predinfo_integer__arithmetics_xadd_3 = {
  (unsigned char *)"add",
  &predicate_integer__arithmetics_xadd_3
};

static Const struct predinfo * Const preds_in_integer__arithmetics[] = {
  &predinfo_integer__arithmetics_xsubtract_3,
  &predinfo_integer__arithmetics_xshift__right_3,
  &predinfo_integer__arithmetics_xshift__left_3,
  &predinfo_integer__arithmetics_xplus_2,
  &predinfo_integer__arithmetics_xor_3,
  &predinfo_integer__arithmetics_xmultiply_3,
  &predinfo_integer__arithmetics_xmodulo_3,
  &predinfo_integer__arithmetics_xminus_2,
  &predinfo_integer__arithmetics_xexclusive__or_3,
  &predinfo_integer__arithmetics_xdivide_3,
  &predinfo_integer__arithmetics_xcomplement_2,
  &predinfo_integer__arithmetics_xand_3,
  &predinfo_integer__arithmetics_xadd_3,
  0
};
Const struct modinfo defined_modules[] = {
  (unsigned char *)"unparser",
  preds_in_unparser,
  (unsigned char *)"scanner",
  preds_in_scanner,
  (unsigned char *)"variable",
  preds_in_variable,
  (unsigned char *)"parser",
  preds_in_parser,
  (unsigned char *)"klic_reader",
  preds_in_klic__reader,
  (unsigned char *)"klicio",
  preds_in_klicio,
  (unsigned char *)"util",
  preds_in_util,
  (unsigned char *)"unwrap",
  preds_in_unwrap,
  (unsigned char *)"unix",
  preds_in_unix,
  (unsigned char *)"http",
  preds_in_http,
  (unsigned char *)"html",
  preds_in_html,
  (unsigned char *)"inttostr",
  preds_in_inttostr,
  (unsigned char *)"atom_table",
  preds_in_atom__table,
  (unsigned char *)"tohtml",
  preds_in_tohtml,
  (unsigned char *)"url",
  preds_in_url,
  (unsigned char *)"functor_table",
  preds_in_functor__table,
  (unsigned char *)"builtin",
  preds_in_builtin,
  (unsigned char *)"main",
  preds_in_main,
  (unsigned char *)"generic",
  preds_in_generic,
  (unsigned char *)"unify_term_dcode",
  preds_in_unify__term__dcode,
  (unsigned char *)"integer_arithmetics",
  preds_in_integer__arithmetics,
  0, 0
};
