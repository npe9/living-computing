#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <errno.h>
#include <string.h>

#include "npapi.h"

char *WaitClient(int,char *);

struct 
{
  int nothing;
  int input_port;
  int output_port;
  char host[128];
  char url[128];
  char myurl[128];
  char filename[512];
  FILE *dump;
  FILE *temp;
  int State;
  NPStream *stream;
  int target;
  int desc;
  int new_sd;
  int process;
} This;

#define INITIATE       0
#define LISTEN         1
#define COMPILE        2
#define GETURL         3
#define NEWSTREAM      4
#define WRITESTREAM    5
#define READPAGE       6


main()
{
	FILE *re;
	char b[256];
	int stalecommand = 1;
		char command[256];
		char buffer[256];
		char hst[128];
		FILE *ptr;
		char *reccmd;
		int cnt,reply;
		char stradr[16];
		char finalcommand[512];


	CreatePointofContact(5000,"pippo");

	GetAccept();
	if ((cnt=read(This.new_sd,stradr,10)) < 0)
	  {
	    perror("Error while reading pid: ");
	  }
	stradr[10]='\0';
	This.process = atoi(stradr);
	CloseCommunication();
	
	This.State = LISTEN;

	while (stalecommand)
	  {
	    reccmd = WaitClient(5000,"pippo");
	    reply = DispatchCommand(reccmd,&stalecommand);
	    SendError(reply);
	  }
	
}



int WriteFragment(char *buf, int len)
{
  if (write(This.new_sd,buf,len) < 0)
	{
	  perror("Write Error: ");
	}
}

int zerofill(char *buf,int len)
{
  int i;
  
  for (i = 0 ; (i < len) && (buf[i] == ' '); i++)
    buf[i]=0;
}
  
int GetAccept()
{
  int len;
  struct sockaddr sock;

  This.new_sd = accept(This.desc,(struct sockaddr *)(&sock),&len);
  if (This.new_sd < 0)
	printf("ERROR accept\n");
}

int CloseCommunication()
{
  close(This.new_sd);
}

int SendError (int error)
{
  char buffer[16];

  bzero(buffer,16);
  sprintf(buffer,"%d",error);
  write(This.new_sd,buffer,strlen(buffer));
  close(This.new_sd);
/*   close(desc); */
}

int CreatePointofContact(int iport,char *host)
{
  int len,cnt;
  struct sockaddr_in server;
  struct sockaddr *sock;
  char *buffer;
  struct hostent *hp;

  This.desc = socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
  if (This.desc < 0)
        printf("ERROR socket creation\n");

  memset((void *)&server,0,sizeof(struct sockaddr_in));
  server.sin_family = AF_INET;
  server.sin_addr.s_addr = INADDR_ANY;
  server.sin_port = iport;

  if (bind(This.desc,(struct sockaddr *)(&server),sizeof(struct sockaddr_in)) < 0)
	{
	  printf("ERROR bind\n");
	  perror("Error: ");
	  exit(0);
	}

  if (listen(This.desc, 1024) < 0)
	{
	  printf("ERROR listen\n");
	  perror("Error: ");
	  exit(0);
	}
}



int DispatchCommand(char *command,int *stalecommand)
{
  char *str;
  int status;


  str = index(command,' ');
  str[0] = '\0';
  str = &(str[1]);
  
  if (!strcmp(command,"new_stream"))
	{
	  printf("SENDING NPN NEW STREAM\n");
	  This.State = NEWSTREAM;
	  (*stalecommand)=1;
	}
  else if (!strcmp(command,"write_stream"))
	{
	  printf("SENDING NPN WRITE\n");
	  This.State = WRITESTREAM;
	  (*stalecommand)=1;
	}
  else if (!strcmp(command,"destroy_stream"))
	{
	  printf("SENDING DESTROY STREAM\n");
	  This.State = LISTEN;
	  (*stalecommand) = 1;
	}
  else if (!strcmp(command,"get_url"))
	{
	  char *target;

	  target = index(str,' ');
	  target[0] = '\0';
	  target = &(target[1]);
	  if (atoi(str)== 0)
		{
		  This.State = GETURL;
		  This.target = 0;
		  printf("SENDING GET URL 0 %s\n",target);
		}
	  else
		{
		  This.State = GETURL;
		  This.target = 1;
		  printf("SENDING GET URL 1 %s\n",target);
		}
	  (*stalecommand) = 0;
	}
  return status;
}




char *WaitClient(int iport,char *host)
{
  int len,cnt;
  struct sockaddr_in server;
  struct sockaddr sock;
  char *buffer;
  char *outmsg;
  struct hostent *hp;
  int i,siz,ptr;

  This.new_sd = accept(This.desc,(struct sockaddr *)(&sock),&len);
  if (This.new_sd < 0)
    {
	printf("ERROR accept\n");
	perror("error is ");
    }

  buffer = (char *)malloc(257);
  bzero(buffer,257);

  if ( (cnt = read(This.new_sd,buffer,4)) < 0)
	printf("ERROR read size\n");
  
  buffer[5]='\0';
  
  siz = atoi(buffer);
  printf("SIZE of message: %d\n",siz);
  
  ptr = 0;
  outmsg = (char *)malloc(246*siz);
  for (i=0; i<siz; i++)
	{
	  if ((cnt = read(This.new_sd,buffer,256)) < 0)
		printf("ERROR read fragment %d\n",i);
	  buffer[cnt]='\0';
	  strncpy(&(outmsg[ptr]),buffer,256);
	  
	  printf("Message Received : %s\n", buffer);
	}
  return outmsg;
}

