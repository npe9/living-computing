/* Compiled by KLIC compiler version 3.001 (Thu Jun  5 20:19:10 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"
#include "connect.h"
#include "cio.h"

module module_main();
Const struct predicate predicate_main_xmain_0 =
   { module_main, 0, 0 };
Const struct predicate predicate_main_xgetwebpage_3 =
   { module_main, 1, 3 };
Const struct predicate predicate_main_xgetwebpage_5 =
   { module_main, 2, 5 };
Const struct predicate predicate_main_xgetwebpage_2F5_240_5 =
   { module_main, 3, 5 };
Const struct predicate predicate_main_xgetwebpage_2F5_240_2F5_240_5 =
   { module_main, 4, 5 };
Const struct predicate predicate_main_xgetwebpage_2F5_240_2F5_240_2F5_240_4 =
   { module_main, 5, 4 };
Const struct predicate predicate_main_xno__response__page_1 =
   { module_main, 6, 1 };
Const struct predicate predicate_main_xcheck__body_2 =
   { module_main, 7, 2 };
Const struct predicate predicate_main_xcheck__body_2F2_240_2 =
   { module_main, 8, 2 };
Const struct predicate predicate_main_xform__page_2 =
   { module_main, 9, 2 };
Const struct predicate predicate_main_xget__link__list_2 =
   { module_main, 10, 2 };
Const struct predicate predicate_main_xget__link__list1_2 =
   { module_main, 11, 2 };
Const struct predicate predicate_main_xget__link__list2_2 =
   { module_main, 12, 2 };
Const struct predicate predicate_main_xget__link__list2_3 =
   { module_main, 13, 3 };
Const struct predicate predicate_main_xfind__args_3 =
   { module_main, 14, 3 };
Const struct predicate predicate_main_xfind__args_4 =
   { module_main, 15, 4 };
Const struct predicate predicate_main_xfind__links_3 =
   { module_main, 16, 3 };
Const struct predicate predicate_main_xfind__links1_3 =
   { module_main, 17, 3 };
Const struct predicate predicate_main_xsearch__page_4 =
   { module_main, 18, 4 };
Const struct predicate predicate_main_x_2C_2 =
   { module_main, 19, 2 };
Const struct predicate predicate_main_xsearch__to__depth_7 =
   { module_main, 20, 7 };
Const struct predicate predicate_main_xsearch__to__depth_2F7_240_11 =
   { module_main, 21, 11 };
Const struct predicate predicate_main_xsearch__to__depth_2F7_240_2F11_240_4 =
   { module_main, 22, 4 };
Const struct predicate predicate_main_xfind__base_2 =
   { module_main, 23, 2 };
Const struct predicate predicate_main_xfind__base_2F2_240_3 =
   { module_main, 24, 3 };
Const struct predicate predicate_main_xfind__base_3 =
   { module_main, 25, 3 };
Const struct predicate predicate_main_xfind__base_2F3_240_2 =
   { module_main, 26, 2 };
Const struct predicate predicate_main_xfind__base1_2 =
   { module_main, 27, 2 };
Const struct predicate predicate_main_xfind__base1_2F2_240_3 =
   { module_main, 28, 3 };
Const struct predicate predicate_main_xattach__base_3 =
   { module_main, 29, 3 };
Const struct predicate predicate_main_xcheck__base_3 =
   { module_main, 30, 3 };
Const struct predicate predicate_main_xcheck__base_2F3_240_3 =
   { module_main, 31, 3 };
Const struct predicate predicate_main_xattach__base_4 =
   { module_main, 32, 4 };
Const struct predicate predicate_main_xattach__base_2F4_240_7 =
   { module_main, 33, 7 };
Const struct predicate predicate_main_xform__graph_3 =
   { module_main, 34, 3 };
Const struct predicate predicate_main_xform__graph_4 =
   { module_main, 35, 4 };
extern Const struct predicate predicate_builtin_xprint_1;
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_generic_xgeneric_2;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_url_xpartURL_5;
extern Const struct predicate predicate_tohtml_xtohtml_2;
extern Const struct predicate predicate_http_xpartHeadBody1_4;
extern Const struct predicate predicate_http_xpartHead_2;
extern Const struct predicate predicate_unwrap_xunwrap_2;
extern Const struct predicate predicate_util_xlosToLst_2;
extern Const struct predicate predicate_util_xappend_3;
declare_method_table_of(byte__string);

module module_main(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_0 =
      declare_string_constant_8(0,0);
  static Const unsigned char strconst_body_1[4] =
    "/";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_1 =
      declare_string_constant_8(strconst_body_1,1);
  static Const unsigned char strconst_body_2[4] =
    {'H','T','T','P',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_2 =
      declare_string_constant_8(strconst_body_2,4);
  static Const unsigned char strconst_body_3[44] =
    "http://www.cs.nmsu.edu/~kdeopura/test.html";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_3 =
      declare_string_constant_8(strconst_body_3,42);
  static Const unsigned char strconst_body_4[24] =
    "404 LINK NOT REACHABLE";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_4 =
      declare_string_constant_8(strconst_body_4,22);
  static Const q cons_const_5[] = {
    NILATOM,
    makefunctor(&string_const_4),
  };
  static Const unsigned char strconst_body_6[8] =
    "Error";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_6 =
      declare_string_constant_8(strconst_body_6,5);
  static Const q cons_const_7[] = {
    NILATOM,
    makefunctor(&string_const_6),
  };
  static Const unsigned char strconst_body_8[12] =
    "No Response";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_8 =
      declare_string_constant_8(strconst_body_8,11);
  static Const q cons_const_9[] = {
    NILATOM,
    makefunctor(&string_const_8),
  };
  q a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10;

  q *reasonp;
 module_top:
  switch_on_pred() {
    case_pred(0, main_0_top);
    case_pred(1, getwebpage_3_top);
    case_pred(2, getwebpage_5_top);
    case_pred(3, getwebpage_2F5_240_5_top);
    case_pred(4, getwebpage_2F5_240_2F5_240_5_top);
    case_pred(5, getwebpage_2F5_240_2F5_240_2F5_240_4_top);
    case_pred(6, no__response__page_1_top);
    case_pred(7, check__body_2_top);
    case_pred(8, check__body_2F2_240_2_top);
    case_pred(9, form__page_2_top);
    case_pred(10, get__link__list_2_top);
    case_pred(11, get__link__list1_2_top);
    case_pred(12, get__link__list2_2_top);
    case_pred(13, get__link__list2_3_top);
    case_pred(14, find__args_3_top);
    case_pred(15, find__args_4_top);
    case_pred(16, find__links_3_top);
    case_pred(17, find__links1_3_top);
    case_pred(18, search__page_4_top);
    case_pred(19, _2C_2_top);
    case_pred(20, search__to__depth_7_top);
    case_pred(21, search__to__depth_2F7_240_11_top);
    case_pred(22, search__to__depth_2F7_240_2F11_240_4_top);
    case_pred(23, find__base_2_top);
    case_pred(24, find__base_2F2_240_3_top);
    case_pred(25, find__base_3_top);
    case_pred(26, find__base_2F3_240_2_top);
    case_pred(27, find__base1_2_top);
    case_pred(28, find__base1_2F2_240_3_top);
    case_pred(29, attach__base_3_top);
    case_pred(30, check__base_3_top);
    case_pred(31, check__base_2F3_240_3_top);
    case_pred(32, attach__base_4_top);
    case_pred(33, attach__base_2F4_240_7_top);
    case_pred(34, form__graph_3_top);
    last_case_pred(35, form__graph_4_top);
  }

 main_0_top: {
  q x0, x1;
  qp = qp->next;
 main_0_clear_reason:
  reasonp = reasons;
 main_0_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin_xprint_1);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = (q)(struct goalrec*)&allocp[0];
  allocp[4] = (q)(&predicate_builtin_xprint_1);
  allocp[5] = x1 = makeref(&allocp[5]);
  a0 = makefunctor(&string_const_3);
  a1 = makeint(2L);
  a2 = x1;
  a3 = x0;
  qp = (struct goalrec*)&allocp[3];
  allocp += 6;
  execute(search__page_4_0);
  goto search__page_4_ext_interrupt;
 main_0_ext_interrupt:
  reasonp = 0l;
 main_0_interrupt:
  goto interrupt_0;
 }

 getwebpage_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 getwebpage_3_clear_reason:
  reasonp = reasons;
 getwebpage_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_main_xform__page_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_tohtml_xtohtml_2);
  allocp[6] = x0;
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = (q)(struct goalrec*)&allocp[4];
  allocp[9] = (q)(&predicate_main_xgetwebpage_5);
  allocp[10] = x2 = makeref(&allocp[10]);
  allocp[11] = x3 = makeref(&allocp[11]);
  allocp[12] = x4 = makeref(&allocp[12]);
  allocp[13] = x0;
  allocp[14] = a2;
  allocp[15] = makesym(functor_join_2);
  allocp[16] = x6 = makeref(&allocp[16]);
  allocp[17] = x3;
  x5 = makefunctor(&allocp[15]);
  allocp[18] = (q)(struct goalrec*)&allocp[8];
  allocp[19] = (q)(&predicate_generic_xgeneric_2);
  allocp[20] = x5;
  allocp[21] = makefunctor(&string_const_1);
  allocp[22] = (q)(struct goalrec*)&allocp[18];
  allocp[23] = (q)(&predicate_url_xpartURL_5);
  allocp[24] = a0;
  allocp[25] = x7 = makeref(&allocp[25]);
  allocp[26] = x2;
  allocp[27] = x6;
  allocp[28] = x8 = makeref(&allocp[28]);
  qp = (struct goalrec*)&allocp[22];
  allocp += 29;
  proceed();
 getwebpage_3_ext_interrupt:
  reasonp = 0l;
 getwebpage_3_interrupt:
  toppred = &predicate_main_xgetwebpage_3;
  goto interrupt_3;
 }

 getwebpage_5_top: {
  q x0, x1, x2;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 getwebpage_5_clear_reason:
  reasonp = reasons;
 getwebpage_5_0:
 getwebpage_5_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
 getwebpage_5_2:
  if (!isgobj(a0)) goto getwebpage_5_interrupt;
  if (!isclass(a0,byte__string)) goto getwebpage_5_interrupt;
 getwebpage_5_3:
  switch (ptagof(a1)) {
 case FUNCTOR:
 getwebpage_5_4:
  if (!isgobj(a1)) goto getwebpage_5_interrupt;
  if (!isclass(a1,byte__string)) goto getwebpage_5_interrupt;
  
	{
	char *netloc_ptr = (char *)convert_klic_string_to_c_string(a0);
	char *path_ptr = (char *)convert_klic_string_to_c_string(a1);
	x0 = convert_c_string_to_klic_string(gethtml(netloc_ptr, path_ptr), allocp);
	allocp = heapp;
	}
  allocp[0] = x1 = makeref(&allocp[0]);
  generic_arg[0] = x1;
  call_generic(x0, functor_size_1, 1);
  a0 = x1;
  a1 = x0;
  x2 = a4;
  a4 = a3;
  a3 = x2;
  execute(getwebpage_2F5_240_5_clear_reason);
  goto getwebpage_2F5_240_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,getwebpage_5_3);
  *reasonp++ =  a1;
  goto getwebpage_5_interrupt;
  };
  goto getwebpage_5_interrupt;
 case VARREF:
  deref_and_jump(a0,getwebpage_5_1);
  *reasonp++ =  a0;
  goto getwebpage_5_interrupt;
  };
  goto getwebpage_5_interrupt;
 getwebpage_5_ext_interrupt:
  reasonp = 0l;
 getwebpage_5_interrupt:
  goto interrupt_5;
 }

 getwebpage_2F5_240_5_top: {
  q x0, x1, x2, x3;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 getwebpage_2F5_240_5_clear_reason:
  reasonp = reasons;
 getwebpage_2F5_240_5_0:
 getwebpage_2F5_240_5_1:
  if (!isint(a0)) goto getwebpage_2F5_240_5_2;
  x0 = makeint(3L);
  gblt_greater(a0,x0,getwebpage_2F5_240_5_3);
  x1 = makeint(4L);
  generic_arg[0] = x1;
  allocp[0] = x2 = makeref(&allocp[0]);
  generic_arg[1] = x2;
  allocp[1] = x3 = makeref(&allocp[1]);
  generic_arg[2] = x3;
  call_generic(a1, functor_split_3, 2);
  a0 = x2;
  execute(getwebpage_2F5_240_2F5_240_5_0);
  goto getwebpage_2F5_240_2F5_240_5_ext_interrupt;
 getwebpage_2F5_240_5_2:
  if (!isref(a0)) goto getwebpage_2F5_240_5_3;
  deref_and_jump(a0,getwebpage_2F5_240_5_1);
  *reasonp++ =  a0;
  goto getwebpage_2F5_240_5_3;
 getwebpage_2F5_240_5_3:
  otherwise(getwebpage_2F5_240_5_interrupt);
  x0 = makesym(atom_nok);
  unify_value(a3, x0);
  a0 = a4;
  execute(no__response__page_1_0);
  goto no__response__page_1_ext_interrupt;
 getwebpage_2F5_240_5_ext_interrupt:
  reasonp = 0l;
 getwebpage_2F5_240_5_interrupt:
  toppred = &predicate_main_xgetwebpage_2F5_240_5;
  goto interrupt_5;
 }

 getwebpage_2F5_240_2F5_240_5_top: {
  q x0, x1, x2, x3;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 getwebpage_2F5_240_2F5_240_5_clear_reason:
  reasonp = reasons;
 getwebpage_2F5_240_2F5_240_5_0:
 getwebpage_2F5_240_2F5_240_5_1:
  if (isref(a0)) goto getwebpage_2F5_240_2F5_240_5_4;
 getwebpage_2F5_240_2F5_240_5_2:
  if (isref(a0)) goto getwebpage_2F5_240_2F5_240_5_3;
  x0 = makefunctor(&string_const_2);
  if_not_equal(a0, x0, getwebpage_2F5_240_2F5_240_5_5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_main_xgetwebpage_2F5_240_2F5_240_2F5_240_4);
  allocp[2] = a3;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a4;
  allocp[5] = a2;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_http_xpartHead_2);
  allocp[8] = a2;
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[6];
  allocp[11] = (q)(&predicate_main_xcheck__body_2);
  allocp[12] = x1;
  allocp[13] = a3;
  allocp[14] = NILATOM;
  allocp[15] = a1;
  x3 = makecons(&allocp[14]);
  allocp[16] = (q)(struct goalrec*)&allocp[10];
  allocp[17] = (q)(&predicate_http_xpartHeadBody1_4);
  allocp[18] = x3;
  allocp[19] = makefunctor(&string_const_0);
  allocp[20] = a2;
  allocp[21] = x1;
  qp = (struct goalrec*)&allocp[16];
  allocp += 22;
  proceed();
 getwebpage_2F5_240_2F5_240_5_3:
  deref_and_jump(a0,getwebpage_2F5_240_2F5_240_5_2);
  *reasonp++ =  a0;
  goto getwebpage_2F5_240_2F5_240_5_5;
 getwebpage_2F5_240_2F5_240_5_4:
  deref_and_jump(a0,getwebpage_2F5_240_2F5_240_5_1);
  *reasonp++ =  a0;
  goto getwebpage_2F5_240_2F5_240_5_5;
 getwebpage_2F5_240_2F5_240_5_5:
  otherwise(getwebpage_2F5_240_2F5_240_5_interrupt);
  x0 = makesym(atom_nok);
  unify_value(a3, x0);
  a0 = a4;
  execute(no__response__page_1_0);
  goto no__response__page_1_ext_interrupt;
 getwebpage_2F5_240_2F5_240_5_ext_interrupt:
  reasonp = 0l;
 getwebpage_2F5_240_2F5_240_5_interrupt:
  toppred = &predicate_main_xgetwebpage_2F5_240_2F5_240_5;
  goto interrupt_5;
 }

 getwebpage_2F5_240_2F5_240_2F5_240_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 getwebpage_2F5_240_2F5_240_2F5_240_4_clear_reason:
  reasonp = reasons;
 getwebpage_2F5_240_2F5_240_2F5_240_4_0:
 getwebpage_2F5_240_2F5_240_2F5_240_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_ok)) goto getwebpage_2F5_240_2F5_240_2F5_240_4_2;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unwrap_xunwrap_2);
  allocp[2] = a1;
  allocp[3] = a2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  proceed();
 case VARREF:
  deref_and_jump(a0,getwebpage_2F5_240_2F5_240_2F5_240_4_1);
  *reasonp++ =  a0;
  goto getwebpage_2F5_240_2F5_240_2F5_240_4_2;
  };
  goto getwebpage_2F5_240_2F5_240_2F5_240_4_2;
 getwebpage_2F5_240_2F5_240_2F5_240_4_2:
  otherwise(getwebpage_2F5_240_2F5_240_2F5_240_4_interrupt);
  allocp[0] = makesym(functor_text_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_title_2);
  allocp[3] = NILATOM;
  allocp[4] = x0;
  x2 = makefunctor(&allocp[2]);
  allocp[5] = makesym(functor_head_2);
  allocp[6] = NILATOM;
  allocp[7] = x2;
  x3 = makefunctor(&allocp[5]);
  allocp[8] = makesym(functor_text_1);
  allocp[9] = x5 = makeref(&allocp[9]);
  x4 = makefunctor(&allocp[8]);
  allocp[10] = makesym(functor_body_2);
  allocp[11] = NILATOM;
  allocp[12] = x4;
  x6 = makefunctor(&allocp[10]);
  allocp[13] = makesym(functor_html_3);
  allocp[14] = NILATOM;
  allocp[15] = x3;
  allocp[16] = x6;
  x7 = makefunctor(&allocp[13]);
  allocp += 17;
  unify_value(a2, x7);
  allocp[0] = NILATOM;
  allocp[1] = a3;
  x8 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_util_xlosToLst_2);
  allocp[4] = x8;
  allocp[5] = x5;
  allocp[6] = (q)(struct goalrec*)&allocp[2];
  allocp[7] = (q)(&predicate_util_xlosToLst_2);
  allocp[8] = makecons(cons_const_7);
  allocp[9] = x1;
  qp = (struct goalrec*)&allocp[6];
  allocp += 10;
  proceed();
 getwebpage_2F5_240_2F5_240_2F5_240_4_ext_interrupt:
  reasonp = 0l;
 getwebpage_2F5_240_2F5_240_2F5_240_4_interrupt:
  goto interrupt_4;
 }

 no__response__page_1_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a0 = qp->args[0];
  qp = qp->next;
 no__response__page_1_clear_reason:
  reasonp = reasons;
 no__response__page_1_0:
  allocp[0] = makesym(functor_text_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_title_2);
  allocp[3] = NILATOM;
  allocp[4] = x0;
  x2 = makefunctor(&allocp[2]);
  allocp[5] = makesym(functor_head_2);
  allocp[6] = NILATOM;
  allocp[7] = x2;
  x3 = makefunctor(&allocp[5]);
  allocp[8] = makesym(functor_text_1);
  allocp[9] = x5 = makeref(&allocp[9]);
  x4 = makefunctor(&allocp[8]);
  allocp[10] = makesym(functor_h1_2);
  allocp[11] = NILATOM;
  allocp[12] = x4;
  x6 = makefunctor(&allocp[10]);
  allocp[13] = makesym(functor_body_2);
  allocp[14] = NILATOM;
  allocp[15] = x6;
  x7 = makefunctor(&allocp[13]);
  allocp[16] = makesym(functor_html_3);
  allocp[17] = NILATOM;
  allocp[18] = x3;
  allocp[19] = x7;
  x8 = makefunctor(&allocp[16]);
  allocp += 20;
  unify_value(a0, x8);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_util_xlosToLst_2);
  allocp[2] = makecons(cons_const_5);
  allocp[3] = x5;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_util_xlosToLst_2);
  allocp[6] = makecons(cons_const_9);
  allocp[7] = x1;
  qp = (struct goalrec*)&allocp[4];
  allocp += 8;
  proceed();
 no__response__page_1_ext_interrupt:
  reasonp = 0l;
 no__response__page_1_interrupt:
  toppred = &predicate_main_xno__response__page_1;
  goto interrupt_1;
 }

 check__body_2_top: {
  q x0, x1, x2, x3;
  a0 = qp->args[0];
  a1 = qp->args[1];
  qp = qp->next;
 check__body_2_clear_reason:
  reasonp = reasons;
 check__body_2_0:
 check__body_2_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != NILATOM) goto check__body_2_2;
  x0 = makesym(atom_nok);
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,check__body_2_1);
  *reasonp++ =  a0;
  goto check__body_2_2;
  };
  goto check__body_2_2;
 check__body_2_2:
  otherwise(check__body_2_interrupt);
 check__body_2_3:
  switch (ptagof(a0)) {
 case CONS:
  x0 = cdr_of(a0);
 check__body_2_4:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != NILATOM) goto check__body_2_8;
  x1 = car_of(a0);
 check__body_2_5:
  switch (ptagof(x1)) {
 case FUNCTOR:
 check__body_2_6:
  if (!isgobj(x1)) goto check__body_2_8;
 check__body_2_7:
  gblt_is_string(x1,check__body_2_8);
  gblt_size_of_string(x1,x2,check__body_2_8);
  gblt_element_size_of_string(x1,x3,check__body_2_8);
  a0 = x1;
  execute(check__body_2F2_240_2_0);
  goto check__body_2F2_240_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,check__body_2_5);
  *reasonp++ =  x1;
  goto check__body_2_8;
  };
  goto check__body_2_8;
 case VARREF:
  deref_and_jump(x0,check__body_2_4);
  *reasonp++ =  x0;
  goto check__body_2_8;
  };
  goto check__body_2_8;
 case VARREF:
  deref_and_jump(a0,check__body_2_3);
  *reasonp++ =  a0;
  goto check__body_2_8;
  };
  goto check__body_2_8;
 check__body_2_8:
  otherwise(check__body_2_interrupt);
  x0 = makesym(atom_nok);
  unify_value(a1, x0);
  proceed();
 check__body_2_ext_interrupt:
  reasonp = 0l;
 check__body_2_interrupt:
  goto interrupt_2;
 }

 check__body_2F2_240_2_top: {
  q x0, x1;
  a0 = qp->args[0];
  a1 = qp->args[1];
  qp = qp->next;
 check__body_2F2_240_2_clear_reason:
  reasonp = reasons;
 check__body_2F2_240_2_0:
 check__body_2F2_240_2_1:
  if (isref(a0)) goto check__body_2F2_240_2_4;
 check__body_2F2_240_2_2:
  if (isref(a0)) goto check__body_2F2_240_2_3;
  x0 = makefunctor(&string_const_0);
  if_not_equal(a0, x0, check__body_2F2_240_2_5);
  x1 = makesym(atom_nok);
  unify_value(a1, x1);
  proceed();
 check__body_2F2_240_2_3:
  deref_and_jump(a0,check__body_2F2_240_2_2);
  *reasonp++ =  a0;
  goto check__body_2F2_240_2_5;
 check__body_2F2_240_2_4:
  deref_and_jump(a0,check__body_2F2_240_2_1);
  *reasonp++ =  a0;
  goto check__body_2F2_240_2_5;
 check__body_2F2_240_2_5:
  otherwise(check__body_2F2_240_2_interrupt);
  x0 = makesym(atom_ok);
  unify_value(a1, x0);
  proceed();
 check__body_2F2_240_2_ext_interrupt:
  reasonp = 0l;
 check__body_2F2_240_2_interrupt:
  toppred = &predicate_main_xcheck__body_2F2_240_2;
  goto interrupt_2;
 }

 form__page_2_top: {
  q x0, x1;
  a0 = qp->args[0];
  a1 = qp->args[1];
  qp = qp->next;
 form__page_2_clear_reason:
  reasonp = reasons;
 form__page_2_0:
  allocp[0] = makesym(functor_page_3);
  allocp[1] = a0;
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = NILATOM;
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a1, x0);
  a1 = x1;
  execute(get__link__list_2_0);
  goto get__link__list_2_ext_interrupt;
 form__page_2_ext_interrupt:
  reasonp = 0l;
 form__page_2_interrupt:
  goto interrupt_2;
 }

 get__link__list_2_top: {
  a0 = qp->args[0];
  a1 = qp->args[1];
  qp = qp->next;
 get__link__list_2_clear_reason:
  reasonp = reasons;
 get__link__list_2_0:
  execute(get__link__list1_2_0);
  goto get__link__list1_2_ext_interrupt;
 get__link__list_2_ext_interrupt:
  reasonp = 0l;
 get__link__list_2_interrupt:
  toppred = &predicate_main_xget__link__list_2;
  goto interrupt_2;
 }

 get__link__list1_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a0 = qp->args[0];
  a1 = qp->args[1];
  qp = qp->next;
 get__link__list1_2_clear_reason:
  reasonp = reasons;
 get__link__list1_2_0:
 get__link__list1_2_1:
  if (isref(a0)) goto get__link__list1_2_2;
  gblt_pfunctor(a0,x0,get__link__list1_2_3);
  gblt_arity(a0,x1,get__link__list1_2_3);
  x2 = makeint(0L);
  gblt_greater(x1,x2,get__link__list1_2_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_util_xappend_3);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = x4 = makeref(&allocp[3]);
  allocp[4] = a1;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_main_xget__link__list2_2);
  allocp[7] = x5 = makeref(&allocp[7]);
  allocp[8] = x4;
  allocp[9] = (q)(struct goalrec*)&allocp[5];
  allocp[10] = (q)(&predicate_main_xfind__links_3);
  allocp[11] = x0;
  allocp[12] = x6 = makeref(&allocp[12]);
  allocp[13] = x3;
  allocp[14] = x5;
  allocp[15] = x6;
  x7 = makecons(&allocp[14]);
  a1 = a0;
  a2 = x7;
  a0 = x1;
  qp = (struct goalrec*)&allocp[9];
  allocp += 16;
  execute(find__args_3_0);
  goto find__args_3_ext_interrupt;
 get__link__list1_2_2:
  deref_and_jump(a0,get__link__list1_2_1);
  *reasonp++ =  a0;
  goto get__link__list1_2_3;
 get__link__list1_2_3:
  otherwise(get__link__list1_2_interrupt);
 get__link__list1_2_4:
  if (isref(a0)) goto get__link__list1_2_6;
  gblt_pfunctor(a0,x0,get__link__list1_2_interrupt);
  gblt_arity(a0,x1,get__link__list1_2_interrupt);
 get__link__list1_2_5:
  if (x1 != makeint(0L)) goto get__link__list1_2_interrupt;
  x2 = NILATOM;
  unify_value(a1, x2);
  proceed();
 get__link__list1_2_6:
  deref_and_jump(a0,get__link__list1_2_4);
  *reasonp++ =  a0;
  goto get__link__list1_2_interrupt;
 get__link__list1_2_ext_interrupt:
  reasonp = 0l;
 get__link__list1_2_interrupt:
  toppred = &predicate_main_xget__link__list1_2;
  goto interrupt_2;
 }

 get__link__list2_2_top: {
  q x0, x1;
  a0 = qp->args[0];
  a1 = qp->args[1];
  qp = qp->next;
 get__link__list2_2_clear_reason:
  reasonp = reasons;
 get__link__list2_2_0:
 get__link__list2_2_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != NILATOM) goto get__link__list2_2_2;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,get__link__list2_2_1);
  *reasonp++ =  a0;
  goto get__link__list2_2_2;
  };
  goto get__link__list2_2_2;
 get__link__list2_2_2:
  otherwise(get__link__list2_2_interrupt);
 get__link__list2_2_3:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_main_xget__link__list2_3);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a1;
  a0 = car_of(a0);
  a1 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(get__link__list_2_0);
  goto get__link__list_2_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,get__link__list2_2_3);
  *reasonp++ =  a0;
  goto get__link__list2_2_interrupt;
  };
  goto get__link__list2_2_interrupt;
 get__link__list2_2_ext_interrupt:
  reasonp = 0l;
 get__link__list2_2_interrupt:
  goto interrupt_2;
 }

 get__link__list2_3_top: {
  q x0, x1, x2;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 get__link__list2_3_clear_reason:
  reasonp = reasons;
 get__link__list2_3_0:
 get__link__list2_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != NILATOM) goto get__link__list2_3_2;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,get__link__list2_3_1);
  *reasonp++ =  a0;
  goto get__link__list2_3_2;
  };
  goto get__link__list2_3_2;
 get__link__list2_3_2:
  otherwise(get__link__list2_3_interrupt);
 get__link__list2_3_3:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_main_xget__link__list2_3);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_util_xappend_3);
  allocp[7] = a1;
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = x1;
  a0 = car_of(a0);
  a1 = x2;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  execute(get__link__list_2_0);
  goto get__link__list_2_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,get__link__list2_3_3);
  *reasonp++ =  a0;
  goto get__link__list2_3_interrupt;
  };
  goto get__link__list2_3_interrupt;
 get__link__list2_3_ext_interrupt:
  reasonp = 0l;
 get__link__list2_3_interrupt:
  goto interrupt_3;
 }

 find__args_3_top: {
  q x0, x1, x2;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 find__args_3_clear_reason:
  reasonp = reasons;
 find__args_3_0:
  allocp[0] = NILATOM;
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_main_xfind__args_4);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a1;
  allocp[6] = x0;
  allocp[7] = a2;
  allocp[8] = (q)(struct goalrec*)&allocp[2];
  allocp[9] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[10] = a0;
  allocp[11] = makeint(1L);
  allocp[12] = x2;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_functor__table_xarg_3);
  allocp[15] = a0;
  allocp[16] = a1;
  allocp[17] = x1;
  qp = (struct goalrec*)&allocp[13];
  allocp += 18;
  proceed();
 find__args_3_ext_interrupt:
  reasonp = 0l;
 find__args_3_interrupt:
  toppred = &predicate_main_xfind__args_3;
  goto interrupt_3;
 }

 find__args_4_top: {
  q x0, x1, x2;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 find__args_4_clear_reason:
  reasonp = reasons;
 find__args_4_0:
 find__args_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 find__args_4_2:
  if (a0 != makeint(0L)) goto find__args_4_3;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,find__args_4_1);
  *reasonp++ =  a0;
  goto find__args_4_3;
  };
  goto find__args_4_3;
 find__args_4_3:
  otherwise(find__args_4_interrupt);
  allocp[0] = a2;
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_main_xfind__args_4);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a1;
  allocp[6] = x0;
  allocp[7] = a3;
  allocp[8] = (q)(struct goalrec*)&allocp[2];
  allocp[9] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[10] = a0;
  allocp[11] = makeint(1L);
  allocp[12] = x2;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_functor__table_xarg_3);
  allocp[15] = a0;
  allocp[16] = a1;
  allocp[17] = x1;
  qp = (struct goalrec*)&allocp[13];
  allocp += 18;
  proceed();
 find__args_4_ext_interrupt:
  reasonp = 0l;
 find__args_4_interrupt:
  goto interrupt_4;
 }

 find__links_3_top: {
  q x0;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 find__links_3_clear_reason:
  reasonp = reasons;
 find__links_3_0:
 find__links_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_a)) goto find__links_3_2;
  a0 = makesym(atom_href);
  execute(find__links1_3_0);
  goto find__links1_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,find__links_3_1);
  *reasonp++ =  a0;
  goto find__links_3_2;
  };
  goto find__links_3_2;
 find__links_3_2:
  otherwise(find__links_3_interrupt);
 find__links_3_3:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_img)) goto find__links_3_4;
  a0 = makesym(atom_src);
  execute(find__links1_3_0);
  goto find__links1_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,find__links_3_3);
  *reasonp++ =  a0;
  goto find__links_3_4;
  };
  goto find__links_3_4;
 find__links_3_4:
  otherwise(find__links_3_interrupt);
  x0 = NILATOM;
  unify_value(a2, x0);
  proceed();
 find__links_3_ext_interrupt:
  reasonp = 0l;
 find__links_3_interrupt:
  goto interrupt_3;
 }

 find__links1_3_top: {
  q x0, x1, x2, x3, x4;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 find__links1_3_clear_reason:
  reasonp = reasons;
 find__links1_3_0:
 find__links1_3_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != NILATOM) goto find__links1_3_2;
  x0 = NILATOM;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,find__links1_3_1);
  *reasonp++ =  a1;
  goto find__links1_3_2;
  };
  goto find__links1_3_2;
 find__links1_3_2:
  otherwise(find__links1_3_interrupt);
 find__links1_3_3:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 find__links1_3_4:
  if (isref(x0)) goto find__links1_3_10;
  gblt_pfunctor(x0,x1,find__links1_3_11);
 find__links1_3_5:
  if (isref(x1)) goto find__links1_3_9;
 find__links1_3_6:
  if (isref(x1)) goto find__links1_3_8;
  if_not_equal(x1, a0, find__links1_3_11);
  gblt_arity(x0,x2,find__links1_3_11);
 find__links1_3_7:
  if (x2 != makeint(1L)) goto find__links1_3_11;
  allocp[0] = NILATOM;
  allocp[1] = x4 = makeref(&allocp[1]);
  x3 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(1L);
  allocp[3] = x0;
  allocp[4] = x4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 find__links1_3_8:
  deref_and_jump(x1,find__links1_3_6);
  *reasonp++ =  x1;
  goto find__links1_3_11;
 find__links1_3_9:
  deref_and_jump(x1,find__links1_3_5);
  *reasonp++ =  x1;
  goto find__links1_3_11;
 find__links1_3_10:
  deref_and_jump(x0,find__links1_3_4);
  *reasonp++ =  x0;
  goto find__links1_3_11;
 case VARREF:
  deref_and_jump(a1,find__links1_3_3);
  *reasonp++ =  a1;
  goto find__links1_3_11;
  };
  goto find__links1_3_11;
 find__links1_3_11:
  otherwise(find__links1_3_interrupt);
 find__links1_3_12:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 find__links1_3_13:
  if (isref(x0)) goto find__links1_3_16;
  gblt_pfunctor(x0,x1,find__links1_3_interrupt);
  gblt_arity(x0,x2,find__links1_3_interrupt);
 find__links1_3_14:
  if (isref(a0)) goto find__links1_3_15;
  gblt_diff(x1,a0,find__links1_3_interrupt);
  a1 = cdr_of(a1);
  execute(find__links1_3_0);
  goto find__links1_3_ext_interrupt;
 find__links1_3_15:
  deref_and_jump(a0,find__links1_3_14);
  *reasonp++ =  a0;
  goto find__links1_3_interrupt;
 find__links1_3_16:
  deref_and_jump(x0,find__links1_3_13);
  *reasonp++ =  x0;
  goto find__links1_3_interrupt;
 case VARREF:
  deref_and_jump(a1,find__links1_3_12);
  *reasonp++ =  a1;
  goto find__links1_3_interrupt;
  };
  goto find__links1_3_interrupt;
 find__links1_3_ext_interrupt:
  reasonp = 0l;
 find__links1_3_interrupt:
  toppred = &predicate_main_xfind__links1_3;
  goto interrupt_3;
 }

 search__page_4_top: {
  q x0, x1;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 search__page_4_clear_reason:
  reasonp = reasons;
 search__page_4_0:
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  a0 = x0;
  x1 = a1;
  a4 = NILATOM;
  a5 = a2;
  a6 = a3;
  a3 = x1;
  a2 = NILATOM;
  a1 = NILATOM;
  allocp += 2;
  execute(search__to__depth_7_0);
  goto search__to__depth_7_ext_interrupt;
 search__page_4_ext_interrupt:
  reasonp = 0l;
 search__page_4_interrupt:
  toppred = &predicate_main_xsearch__page_4;
  goto interrupt_4;
 }

 _2C_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20, x21, x22, x23, x24, x25, x26, x27, x28, x29, x30, x31, x32, x33, x34, x35, x36, x37, x38, x39, x40, x41, x42, x43;
  a0 = qp->args[0];
  a1 = qp->args[1];
  qp = qp->next;
 _2C_2_clear_reason:
  reasonp = reasons;
 _2C_2_0:
 _2C_2_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_getwebpage_3)) goto _2C_2_interrupt;
  x0 = arg(a0, 1);
 _2C_2_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_page_3)) goto _2C_2_interrupt;
  x1 = arg(x0, 2);
 _2C_2_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto _2C_2_interrupt;
 _2C_2_4:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor__3B_2)) goto _2C_2_interrupt;
  x2 = arg(a1, 0);
 _2C_2_5:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor__2D_3E_2)) goto _2C_2_interrupt;
  x3 = arg(x2, 0);
 _2C_2_6:
  switch (ptagof(x3)) {
 case FUNCTOR:
  if (functor_of(x3) != makesym(functor__3D_2)) goto _2C_2_interrupt;
  x4 = arg(x3, 0);
 _2C_2_7:
  if (isref(x4)) goto _2C_2_74;
 _2C_2_8:
  if (isref(x4)) goto _2C_2_73;
  x5 = arg(a0, 2);
  if_not_equal(x4, x5, _2C_2_interrupt);
  x6 = arg(x3, 1);
 _2C_2_9:
  switch (ptagof(x6)) {
 case ATOMIC:
  if (x6 != makesym(atom_ok)) goto _2C_2_interrupt;
  x7 = arg(x2, 1);
 _2C_2_10:
  switch (ptagof(x7)) {
 case FUNCTOR:
  if (functor_of(x7) != makesym(functor__2C_2)) goto _2C_2_interrupt;
  x8 = arg(x7, 0);
 _2C_2_11:
  switch (ptagof(x8)) {
 case FUNCTOR:
  if (functor_of(x8) != makesym(functor_find__base_2)) goto _2C_2_interrupt;
  x9 = arg(x8, 0);
 _2C_2_12:
  if (isref(x9)) goto _2C_2_72;
 _2C_2_13:
  if (isref(x9)) goto _2C_2_71;
  x10 = arg(x0, 0);
  if_not_equal(x9, x10, _2C_2_interrupt);
  x11 = arg(x7, 1);
 _2C_2_14:
  switch (ptagof(x11)) {
 case FUNCTOR:
  if (functor_of(x11) != makesym(functor__2C_2)) goto _2C_2_interrupt;
  x12 = arg(x11, 0);
 _2C_2_15:
  switch (ptagof(x12)) {
 case FUNCTOR:
  if (functor_of(x12) != makesym(functor_attach__base_3)) goto _2C_2_interrupt;
  x13 = arg(x12, 0);
 _2C_2_16:
  if (isref(x13)) goto _2C_2_70;
 _2C_2_17:
  if (isref(x13)) goto _2C_2_69;
  x14 = arg(x8, 1);
  if_not_equal(x13, x14, _2C_2_interrupt);
  x15 = arg(x12, 1);
 _2C_2_18:
  if (isref(x15)) goto _2C_2_68;
 _2C_2_19:
  if (isref(x15)) goto _2C_2_67;
  x16 = arg(x0, 1);
  if_not_equal(x15, x16, _2C_2_interrupt);
  x17 = arg(x11, 1);
 _2C_2_20:
  switch (ptagof(x17)) {
 case FUNCTOR:
  if (functor_of(x17) != makesym(functor_search__to__depth_6)) goto _2C_2_interrupt;
  x18 = arg(x17, 0);
 _2C_2_21:
  if (isref(x18)) goto _2C_2_66;
 _2C_2_22:
  if (isref(x18)) goto _2C_2_65;
  x19 = arg(a0, 0);
  if_not_equal(x18, x19, _2C_2_interrupt);
  x20 = arg(x17, 1);
 _2C_2_23:
  switch (ptagof(x20)) {
 case CONS:
  x21 = car_of(x20);
 _2C_2_24:
  switch (ptagof(x21)) {
 case FUNCTOR:
  if (functor_of(x21) != makesym(functor_page_3)) goto _2C_2_interrupt;
  x22 = arg(x21, 0);
 _2C_2_25:
  if (isref(x22)) goto _2C_2_64;
 _2C_2_26:
  if (isref(x22)) goto _2C_2_63;
  if_not_equal(x22, x10, _2C_2_interrupt);
  x23 = arg(x21, 1);
 _2C_2_27:
  if (isref(x23)) goto _2C_2_62;
 _2C_2_28:
  if (isref(x23)) goto _2C_2_61;
  if_not_equal(x23, x16, _2C_2_interrupt);
  x24 = arg(x21, 2);
 _2C_2_29:
  switch (ptagof(x24)) {
 case ATOMIC:
  if (x24 != NILATOM) goto _2C_2_interrupt;
  x25 = cdr_of(x20);
 _2C_2_30:
  switch (ptagof(x25)) {
 case ATOMIC:
  if (x25 != NILATOM) goto _2C_2_interrupt;
  x26 = arg(x17, 2);
 _2C_2_31:
  if (isref(x26)) goto _2C_2_60;
 _2C_2_32:
  if (isref(x26)) goto _2C_2_59;
  x27 = arg(x12, 2);
  if_not_equal(x26, x27, _2C_2_interrupt);
  x28 = arg(a1, 1);
 _2C_2_33:
  switch (ptagof(x28)) {
 case FUNCTOR:
  if (functor_of(x28) != makesym(functor__3B_2)) goto _2C_2_interrupt;
  x29 = arg(x28, 0);
 _2C_2_34:
  switch (ptagof(x29)) {
 case ATOMIC:
  if (x29 != makesym(atom_otherwise)) goto _2C_2_interrupt;
  x30 = arg(x28, 1);
 _2C_2_35:
  switch (ptagof(x30)) {
 case FUNCTOR:
  if (functor_of(x30) != makesym(functor__2D_3E_2)) goto _2C_2_interrupt;
  x31 = arg(x30, 0);
 _2C_2_36:
  switch (ptagof(x31)) {
 case ATOMIC:
  if (x31 != makesym(atom_true)) goto _2C_2_interrupt;
  x32 = arg(x30, 1);
 _2C_2_37:
  switch (ptagof(x32)) {
 case FUNCTOR:
  if (functor_of(x32) != makesym(functor__2C_2)) goto _2C_2_interrupt;
  x33 = arg(x32, 0);
 _2C_2_38:
  switch (ptagof(x33)) {
 case FUNCTOR:
  if (functor_of(x33) != makesym(functor__3D_2)) goto _2C_2_interrupt;
  x34 = arg(x33, 0);
 _2C_2_39:
  if (isref(x34)) goto _2C_2_58;
 _2C_2_40:
  if (isref(x34)) goto _2C_2_57;
  x35 = arg(x17, 4);
  if_not_equal(x34, x35, _2C_2_interrupt);
  x36 = arg(x33, 1);
 _2C_2_41:
  switch (ptagof(x36)) {
 case ATOMIC:
  if (x36 != NILATOM) goto _2C_2_interrupt;
  x37 = arg(x32, 1);
 _2C_2_42:
  switch (ptagof(x37)) {
 case FUNCTOR:
  if (functor_of(x37) != makesym(functor__3D_2)) goto _2C_2_interrupt;
  x38 = arg(x37, 0);
 _2C_2_43:
  if (isref(x38)) goto _2C_2_56;
 _2C_2_44:
  if (isref(x38)) goto _2C_2_55;
  x39 = arg(x17, 5);
  if_not_equal(x38, x39, _2C_2_interrupt);
  x40 = arg(x37, 1);
 _2C_2_45:
  switch (ptagof(x40)) {
 case FUNCTOR:
  if (functor_of(x40) != makesym(functor_page_3)) goto _2C_2_interrupt;
  x41 = arg(x40, 0);
 _2C_2_46:
  if (isref(x41)) goto _2C_2_54;
 _2C_2_47:
  if (isref(x41)) goto _2C_2_53;
  if_not_equal(x41, x10, _2C_2_interrupt);
  x42 = arg(x40, 1);
 _2C_2_48:
  if (isref(x42)) goto _2C_2_52;
 _2C_2_49:
  if (isref(x42)) goto _2C_2_51;
  if_not_equal(x42, x16, _2C_2_interrupt);
  x43 = arg(x40, 2);
 _2C_2_50:
  switch (ptagof(x43)) {
 case ATOMIC:
  if (x43 != NILATOM) goto _2C_2_interrupt;
  proceed();
 case VARREF:
  deref_and_jump(x43,_2C_2_50);
  *reasonp++ =  x43;
  goto _2C_2_interrupt;
  };
  goto _2C_2_interrupt;
 _2C_2_51:
  deref_and_jump(x42,_2C_2_49);
  *reasonp++ =  x42;
  goto _2C_2_interrupt;
 _2C_2_52:
  deref_and_jump(x42,_2C_2_48);
  *reasonp++ =  x42;
  goto _2C_2_interrupt;
 _2C_2_53:
  deref_and_jump(x41,_2C_2_47);
  *reasonp++ =  x41;
  goto _2C_2_interrupt;
 _2C_2_54:
  deref_and_jump(x41,_2C_2_46);
  *reasonp++ =  x41;
  goto _2C_2_interrupt;
 case VARREF:
  deref_and_jump(x40,_2C_2_45);
  *reasonp++ =  x40;
  goto _2C_2_interrupt;
  };
  goto _2C_2_interrupt;
 _2C_2_55:
  deref_and_jump(x38,_2C_2_44);
  *reasonp++ =  x38;
  goto _2C_2_interrupt;
 _2C_2_56:
  deref_and_jump(x38,_2C_2_43);
  *reasonp++ =  x38;
  goto _2C_2_interrupt;
 case VARREF:
  deref_and_jump(x37,_2C_2_42);
  *reasonp++ =  x37;
  goto _2C_2_interrupt;
  };
  goto _2C_2_interrupt;
 case VARREF:
  deref_and_jump(x36,_2C_2_41);
  *reasonp++ =  x36;
  goto _2C_2_interrupt;
  };
  goto _2C_2_interrupt;
 _2C_2_57:
  deref_and_jump(x34,_2C_2_40);
  *reasonp++ =  x34;
  goto _2C_2_interrupt;
 _2C_2_58:
  deref_and_jump(x34,_2C_2_39);
  *reasonp++ =  x34;
  goto _2C_2_interrupt;
 case VARREF:
  deref_and_jump(x33,_2C_2_38);
  *reasonp++ =  x33;
  goto _2C_2_interrupt;
  };
  goto _2C_2_interrupt;
 case VARREF:
  deref_and_jump(x32,_2C_2_37);
  *reasonp++ =  x32;
  goto _2C_2_interrupt;
  };
  goto _2C_2_interrupt;
 case VARREF:
  deref_and_jump(x31,_2C_2_36);
  *reasonp++ =  x31;
  goto _2C_2_interrupt;
  };
  goto _2C_2_interrupt;
 case VARREF:
  deref_and_jump(x30,_2C_2_35);
  *reasonp++ =  x30;
  goto _2C_2_interrupt;
  };
  goto _2C_2_interrupt;
 case VARREF:
  deref_and_jump(x29,_2C_2_34);
  *reasonp++ =  x29;
  goto _2C_2_interrupt;
  };
  goto _2C_2_interrupt;
 case VARREF:
  deref_and_jump(x28,_2C_2_33);
  *reasonp++ =  x28;
  goto _2C_2_interrupt;
  };
  goto _2C_2_interrupt;
 _2C_2_59:
  deref_and_jump(x26,_2C_2_32);
  *reasonp++ =  x26;
  goto _2C_2_interrupt;
 _2C_2_60:
  deref_and_jump(x26,_2C_2_31);
  *reasonp++ =  x26;
  goto _2C_2_interrupt;
 case VARREF:
  deref_and_jump(x25,_2C_2_30);
  *reasonp++ =  x25;
  goto _2C_2_interrupt;
  };
  goto _2C_2_interrupt;
 case VARREF:
  deref_and_jump(x24,_2C_2_29);
  *reasonp++ =  x24;
  goto _2C_2_interrupt;
  };
  goto _2C_2_interrupt;
 _2C_2_61:
  deref_and_jump(x23,_2C_2_28);
  *reasonp++ =  x23;
  goto _2C_2_interrupt;
 _2C_2_62:
  deref_and_jump(x23,_2C_2_27);
  *reasonp++ =  x23;
  goto _2C_2_interrupt;
 _2C_2_63:
  deref_and_jump(x22,_2C_2_26);
  *reasonp++ =  x22;
  goto _2C_2_interrupt;
 _2C_2_64:
  deref_and_jump(x22,_2C_2_25);
  *reasonp++ =  x22;
  goto _2C_2_interrupt;
 case VARREF:
  deref_and_jump(x21,_2C_2_24);
  *reasonp++ =  x21;
  goto _2C_2_interrupt;
  };
  goto _2C_2_interrupt;
 case VARREF:
  deref_and_jump(x20,_2C_2_23);
  *reasonp++ =  x20;
  goto _2C_2_interrupt;
  };
  goto _2C_2_interrupt;
 _2C_2_65:
  deref_and_jump(x18,_2C_2_22);
  *reasonp++ =  x18;
  goto _2C_2_interrupt;
 _2C_2_66:
  deref_and_jump(x18,_2C_2_21);
  *reasonp++ =  x18;
  goto _2C_2_interrupt;
 case VARREF:
  deref_and_jump(x17,_2C_2_20);
  *reasonp++ =  x17;
  goto _2C_2_interrupt;
  };
  goto _2C_2_interrupt;
 _2C_2_67:
  deref_and_jump(x15,_2C_2_19);
  *reasonp++ =  x15;
  goto _2C_2_interrupt;
 _2C_2_68:
  deref_and_jump(x15,_2C_2_18);
  *reasonp++ =  x15;
  goto _2C_2_interrupt;
 _2C_2_69:
  deref_and_jump(x13,_2C_2_17);
  *reasonp++ =  x13;
  goto _2C_2_interrupt;
 _2C_2_70:
  deref_and_jump(x13,_2C_2_16);
  *reasonp++ =  x13;
  goto _2C_2_interrupt;
 case VARREF:
  deref_and_jump(x12,_2C_2_15);
  *reasonp++ =  x12;
  goto _2C_2_interrupt;
  };
  goto _2C_2_interrupt;
 case VARREF:
  deref_and_jump(x11,_2C_2_14);
  *reasonp++ =  x11;
  goto _2C_2_interrupt;
  };
  goto _2C_2_interrupt;
 _2C_2_71:
  deref_and_jump(x9,_2C_2_13);
  *reasonp++ =  x9;
  goto _2C_2_interrupt;
 _2C_2_72:
  deref_and_jump(x9,_2C_2_12);
  *reasonp++ =  x9;
  goto _2C_2_interrupt;
 case VARREF:
  deref_and_jump(x8,_2C_2_11);
  *reasonp++ =  x8;
  goto _2C_2_interrupt;
  };
  goto _2C_2_interrupt;
 case VARREF:
  deref_and_jump(x7,_2C_2_10);
  *reasonp++ =  x7;
  goto _2C_2_interrupt;
  };
  goto _2C_2_interrupt;
 case VARREF:
  deref_and_jump(x6,_2C_2_9);
  *reasonp++ =  x6;
  goto _2C_2_interrupt;
  };
  goto _2C_2_interrupt;
 _2C_2_73:
  deref_and_jump(x4,_2C_2_8);
  *reasonp++ =  x4;
  goto _2C_2_interrupt;
 _2C_2_74:
  deref_and_jump(x4,_2C_2_7);
  *reasonp++ =  x4;
  goto _2C_2_interrupt;
 case VARREF:
  deref_and_jump(x3,_2C_2_6);
  *reasonp++ =  x3;
  goto _2C_2_interrupt;
  };
  goto _2C_2_interrupt;
 case VARREF:
  deref_and_jump(x2,_2C_2_5);
  *reasonp++ =  x2;
  goto _2C_2_interrupt;
  };
  goto _2C_2_interrupt;
 case VARREF:
  deref_and_jump(a1,_2C_2_4);
  *reasonp++ =  a1;
  goto _2C_2_interrupt;
  };
  goto _2C_2_interrupt;
 case VARREF:
  deref_and_jump(x1,_2C_2_3);
  *reasonp++ =  x1;
  goto _2C_2_interrupt;
  };
  goto _2C_2_interrupt;
 case VARREF:
  deref_and_jump(x0,_2C_2_2);
  *reasonp++ =  x0;
  goto _2C_2_interrupt;
  };
  goto _2C_2_interrupt;
 case VARREF:
  deref_and_jump(a0,_2C_2_1);
  *reasonp++ =  a0;
  goto _2C_2_interrupt;
  };
  goto _2C_2_interrupt;
 _2C_2_ext_interrupt:
  reasonp = 0l;
 _2C_2_interrupt:
  goto interrupt_2;
 }

 search__to__depth_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 search__to__depth_7_clear_reason:
  reasonp = reasons;
 search__to__depth_7_0:
 search__to__depth_7_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != NILATOM) goto search__to__depth_7_4;
 search__to__depth_7_2:
  switch (ptagof(a3)) {
 case ATOMIC:
 search__to__depth_7_3:
  if (a3 != makeint(0L)) goto search__to__depth_7_4;
  unify2(a5, a4, a6, a1);
  proceed();
 case VARREF:
  deref_and_jump(a3,search__to__depth_7_2);
  *reasonp++ =  a3;
  goto search__to__depth_7_4;
  };
  goto search__to__depth_7_4;
 case VARREF:
  deref_and_jump(a0,search__to__depth_7_1);
  *reasonp++ =  a0;
  goto search__to__depth_7_4;
  };
  goto search__to__depth_7_4;
 search__to__depth_7_4:
  otherwise(search__to__depth_7_interrupt);
 search__to__depth_7_5:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != NILATOM) goto search__to__depth_7_8;
 search__to__depth_7_6:
  if (!isint(a3)) goto search__to__depth_7_7;
  x0 = makeint(0L);
  gblt_greater(a3,x0,search__to__depth_7_8);
  x1 = makeint(1L);
  bblt_sub_no_check(a3,x1,x2);
  a0 = a2;
  a2 = NILATOM;
  a3 = x2;
  execute(search__to__depth_7_0);
  goto search__to__depth_7_ext_interrupt;
 search__to__depth_7_7:
  if (!isref(a3)) goto search__to__depth_7_8;
  deref_and_jump(a3,search__to__depth_7_6);
  *reasonp++ =  a3;
  goto search__to__depth_7_8;
 case VARREF:
  deref_and_jump(a0,search__to__depth_7_5);
  *reasonp++ =  a0;
  goto search__to__depth_7_8;
  };
  goto search__to__depth_7_8;
 search__to__depth_7_8:
  otherwise(search__to__depth_7_interrupt);
 search__to__depth_7_9:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_main_xsearch__to__depth_2F7_240_11);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  x2 = car_of(a0);
  allocp[4] = x2;
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = a2;
  allocp[7] = a4;
  x4 = cdr_of(a0);
  allocp[8] = x4;
  allocp[9] = x5 = makeref(&allocp[9]);
  allocp[10] = a3;
  allocp[11] = a5;
  allocp[12] = a6;
  allocp[13] = makesym(functor_page_3);
  allocp[14] = x1;
  allocp[15] = x3;
  allocp[16] = NILATOM;
  x6 = makefunctor(&allocp[13]);
  allocp[17] = NILATOM;
  allocp[18] = x6;
  x7 = makecons(&allocp[17]);
  allocp[19] = (q)(struct goalrec*)&allocp[0];
  allocp[20] = (q)(&predicate_util_xappend_3);
  allocp[21] = a1;
  allocp[22] = x7;
  allocp[23] = x5;
  allocp[24] = makesym(functor_page_3);
  allocp[25] = x1;
  allocp[26] = x3;
  allocp[27] = NILATOM;
  x8 = makefunctor(&allocp[24]);
  a0 = x2;
  a1 = x8;
  a2 = x0;
  qp = (struct goalrec*)&allocp[19];
  allocp += 28;
  execute(getwebpage_3_0);
  goto getwebpage_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,search__to__depth_7_9);
  *reasonp++ =  a0;
  goto search__to__depth_7_interrupt;
  };
  goto search__to__depth_7_interrupt;
 search__to__depth_7_ext_interrupt:
  reasonp = 0l;
 search__to__depth_7_interrupt:
  toppred = &predicate_main_xsearch__to__depth_7;
  goto interrupt_7;
 }

 search__to__depth_2F7_240_11_top: {
  q x0, x1, x2, x3, x4;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 search__to__depth_2F7_240_11_clear_reason:
  reasonp = reasons;
 search__to__depth_2F7_240_11_0:
 search__to__depth_2F7_240_11_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_ok)) goto search__to__depth_2F7_240_11_2;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_main_xsearch__to__depth_7);
  allocp[2] = a6;
  allocp[3] = a7;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = a8;
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = a9;
  allocp[8] = a10;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_util_xappend_3);
  allocp[11] = a5;
  allocp[12] = x2 = makeref(&allocp[12]);
  allocp[13] = x1;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_main_xform__graph_3);
  allocp[16] = a2;
  allocp[17] = x3 = makeref(&allocp[17]);
  allocp[18] = x2;
  allocp[19] = (q)(struct goalrec*)&allocp[14];
  allocp[20] = (q)(&predicate_util_xappend_3);
  allocp[21] = a4;
  allocp[22] = x3;
  allocp[23] = x0;
  allocp[24] = (q)(struct goalrec*)&allocp[19];
  allocp[25] = (q)(&predicate_main_xsearch__to__depth_2F7_240_2F11_240_4);
  allocp[26] = x4 = makeref(&allocp[26]);
  allocp[27] = a2;
  allocp[28] = a3;
  allocp[29] = x3;
  a0 = a1;
  a1 = x4;
  qp = (struct goalrec*)&allocp[24];
  allocp += 30;
  execute(find__base_2_0);
  goto find__base_2_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,search__to__depth_2F7_240_11_1);
  *reasonp++ =  a0;
  goto search__to__depth_2F7_240_11_2;
  };
  goto search__to__depth_2F7_240_11_2;
 search__to__depth_2F7_240_11_2:
  otherwise(search__to__depth_2F7_240_11_interrupt);
  a0 = a6;
  a1 = a7;
  a2 = a4;
  a3 = a8;
  a4 = a5;
  a5 = a9;
  a6 = a10;
  execute(search__to__depth_7_0);
  goto search__to__depth_7_ext_interrupt;
 search__to__depth_2F7_240_11_ext_interrupt:
  reasonp = 0l;
 search__to__depth_2F7_240_11_interrupt:
  goto interrupt_11;
 }

 search__to__depth_2F7_240_2F11_240_4_top: {
  q x0;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 search__to__depth_2F7_240_2F11_240_4_clear_reason:
  reasonp = reasons;
 search__to__depth_2F7_240_2F11_240_4_0:
 search__to__depth_2F7_240_2F11_240_4_1:
  if (isref(a0)) goto search__to__depth_2F7_240_2F11_240_4_4;
 search__to__depth_2F7_240_2F11_240_4_2:
  if (isref(a0)) goto search__to__depth_2F7_240_2F11_240_4_3;
  x0 = makefunctor(&string_const_0);
  if_not_equal(a0, x0, search__to__depth_2F7_240_2F11_240_4_5);
  a0 = a1;
  a1 = a2;
  a2 = a3;
  execute(attach__base_3_clear_reason);
  goto attach__base_3_ext_interrupt;
 search__to__depth_2F7_240_2F11_240_4_3:
  deref_and_jump(a0,search__to__depth_2F7_240_2F11_240_4_2);
  *reasonp++ =  a0;
  goto search__to__depth_2F7_240_2F11_240_4_5;
 search__to__depth_2F7_240_2F11_240_4_4:
  deref_and_jump(a0,search__to__depth_2F7_240_2F11_240_4_1);
  *reasonp++ =  a0;
  goto search__to__depth_2F7_240_2F11_240_4_5;
 search__to__depth_2F7_240_2F11_240_4_5:
  otherwise(search__to__depth_2F7_240_2F11_240_4_interrupt);
  a1 = a2;
  a2 = a3;
  execute(attach__base_3_0);
  goto attach__base_3_ext_interrupt;
 search__to__depth_2F7_240_2F11_240_4_ext_interrupt:
  reasonp = 0l;
 search__to__depth_2F7_240_2F11_240_4_interrupt:
  goto interrupt_4;
 }

 find__base_2_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a0 = qp->args[0];
  a1 = qp->args[1];
  qp = qp->next;
 find__base_2_clear_reason:
  reasonp = reasons;
 find__base_2_0:
 find__base_2_1:
  if (isref(a0)) goto find__base_2_3;
  gblt_pfunctor(a0,x0,find__base_2_4);
  gblt_arity(a0,x1,find__base_2_4);
 find__base_2_2:
  if (x1 != makeint(0L)) goto find__base_2_4;
  x2 = makesym(atom_base);
  gblt_diff(x0,x2,find__base_2_4);
  x3 = makefunctor(&string_const_0);
  unify_value(a1, x3);
  proceed();
 find__base_2_3:
  deref_and_jump(a0,find__base_2_1);
  *reasonp++ =  a0;
  goto find__base_2_4;
 find__base_2_4:
  otherwise(find__base_2_interrupt);
 find__base_2_5:
  if (isref(a0)) goto find__base_2_6;
  gblt_pfunctor(a0,x0,find__base_2_interrupt);
  gblt_arity(a0,x1,find__base_2_interrupt);
  x2 = makeint(0L);
  gblt_greater(x1,x2,find__base_2_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_main_xfind__base_2F2_240_3);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = x4 = makeref(&allocp[3]);
  allocp[4] = a1;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_main_xfind__base_3);
  allocp[7] = x0;
  allocp[8] = x5 = makeref(&allocp[8]);
  allocp[9] = x3;
  allocp[10] = x4;
  allocp[11] = x5;
  x6 = makecons(&allocp[10]);
  a1 = a0;
  a2 = x6;
  a0 = x1;
  qp = (struct goalrec*)&allocp[5];
  allocp += 12;
  execute(find__args_3_0);
  goto find__args_3_ext_interrupt;
 find__base_2_6:
  deref_and_jump(a0,find__base_2_5);
  *reasonp++ =  a0;
  goto find__base_2_interrupt;
 find__base_2_ext_interrupt:
  reasonp = 0l;
 find__base_2_interrupt:
  toppred = &predicate_main_xfind__base_2;
  goto interrupt_2;
 }

 find__base_2F2_240_3_top: {
  q x0;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 find__base_2F2_240_3_clear_reason:
  reasonp = reasons;
 find__base_2F2_240_3_0:
 find__base_2F2_240_3_1:
  if (isref(a0)) goto find__base_2F2_240_3_4;
 find__base_2F2_240_3_2:
  if (isref(a0)) goto find__base_2F2_240_3_3;
  x0 = makefunctor(&string_const_0);
  if_not_equal(a0, x0, find__base_2F2_240_3_5);
  a0 = a1;
  a1 = a2;
  execute(find__base1_2_clear_reason);
  goto find__base1_2_ext_interrupt;
 find__base_2F2_240_3_3:
  deref_and_jump(a0,find__base_2F2_240_3_2);
  *reasonp++ =  a0;
  goto find__base_2F2_240_3_5;
 find__base_2F2_240_3_4:
  deref_and_jump(a0,find__base_2F2_240_3_1);
  *reasonp++ =  a0;
  goto find__base_2F2_240_3_5;
 find__base_2F2_240_3_5:
  otherwise(find__base_2F2_240_3_interrupt);
  unify(a2, a0);
  proceed();
 find__base_2F2_240_3_ext_interrupt:
  reasonp = 0l;
 find__base_2F2_240_3_interrupt:
  goto interrupt_3;
 }

 find__base_3_top: {
  q x0;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 find__base_3_clear_reason:
  reasonp = reasons;
 find__base_3_0:
 find__base_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_base)) goto find__base_3_2;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_main_xfind__base_2F3_240_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a2;
  a0 = makesym(atom_href);
  a2 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  execute(find__links1_3_0);
  goto find__links1_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,find__base_3_1);
  *reasonp++ =  a0;
  goto find__base_3_2;
  };
  goto find__base_3_2;
 find__base_3_2:
  otherwise(find__base_3_interrupt);
  x0 = makefunctor(&string_const_0);
  unify_value(a2, x0);
  proceed();
 find__base_3_ext_interrupt:
  reasonp = 0l;
 find__base_3_interrupt:
  goto interrupt_3;
 }

 find__base_2F3_240_2_top: {
  q x0, x1;
  a0 = qp->args[0];
  a1 = qp->args[1];
  qp = qp->next;
 find__base_2F3_240_2_clear_reason:
  reasonp = reasons;
 find__base_2F3_240_2_0:
 find__base_2F3_240_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = cdr_of(a0);
 find__base_2F3_240_2_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != NILATOM) goto find__base_2F3_240_2_interrupt;
  x1 = car_of(a0);
  unify(a1, x1);
  proceed();
 case VARREF:
  deref_and_jump(x0,find__base_2F3_240_2_2);
  *reasonp++ =  x0;
  goto find__base_2F3_240_2_interrupt;
  };
  goto find__base_2F3_240_2_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto find__base_2F3_240_2_interrupt;
  x0 = makefunctor(&string_const_0);
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,find__base_2F3_240_2_1);
  *reasonp++ =  a0;
  goto find__base_2F3_240_2_interrupt;
  };
  goto find__base_2F3_240_2_interrupt;
 find__base_2F3_240_2_ext_interrupt:
  reasonp = 0l;
 find__base_2F3_240_2_interrupt:
  goto interrupt_2;
 }

 find__base1_2_top: {
  q x0, x1;
  a0 = qp->args[0];
  a1 = qp->args[1];
  qp = qp->next;
 find__base1_2_clear_reason:
  reasonp = reasons;
 find__base1_2_0:
 find__base1_2_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != NILATOM) goto find__base1_2_2;
  x0 = makefunctor(&string_const_0);
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,find__base1_2_1);
  *reasonp++ =  a0;
  goto find__base1_2_2;
  };
  goto find__base1_2_2;
 find__base1_2_2:
  otherwise(find__base1_2_interrupt);
 find__base1_2_3:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_main_xfind__base1_2F2_240_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  x1 = cdr_of(a0);
  allocp[3] = x1;
  allocp[4] = a1;
  a0 = car_of(a0);
  a1 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(find__base_2_0);
  goto find__base_2_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,find__base1_2_3);
  *reasonp++ =  a0;
  goto find__base1_2_interrupt;
  };
  goto find__base1_2_interrupt;
 find__base1_2_ext_interrupt:
  reasonp = 0l;
 find__base1_2_interrupt:
  toppred = &predicate_main_xfind__base1_2;
  goto interrupt_2;
 }

 find__base1_2F2_240_3_top: {
  q x0;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 find__base1_2F2_240_3_clear_reason:
  reasonp = reasons;
 find__base1_2F2_240_3_0:
 find__base1_2F2_240_3_1:
  if (isref(a0)) goto find__base1_2F2_240_3_4;
 find__base1_2F2_240_3_2:
  if (isref(a0)) goto find__base1_2F2_240_3_3;
  x0 = makefunctor(&string_const_0);
  if_not_equal(a0, x0, find__base1_2F2_240_3_5);
  a0 = a1;
  a1 = a2;
  execute(find__base1_2_clear_reason);
  goto find__base1_2_ext_interrupt;
 find__base1_2F2_240_3_3:
  deref_and_jump(a0,find__base1_2F2_240_3_2);
  *reasonp++ =  a0;
  goto find__base1_2F2_240_3_5;
 find__base1_2F2_240_3_4:
  deref_and_jump(a0,find__base1_2F2_240_3_1);
  *reasonp++ =  a0;
  goto find__base1_2F2_240_3_5;
 find__base1_2F2_240_3_5:
  otherwise(find__base1_2F2_240_3_interrupt);
  unify(a2, a0);
  proceed();
 find__base1_2F2_240_3_ext_interrupt:
  reasonp = 0l;
 find__base1_2F2_240_3_interrupt:
  goto interrupt_3;
 }

 attach__base_3_top: {
  q x0, x1;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 attach__base_3_clear_reason:
  reasonp = reasons;
 attach__base_3_0:
  allocp[0] = x0 = makeref(&allocp[0]);
  generic_arg[0] = x0;
  call_generic(a0, functor_size_1, 1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_main_xattach__base_4);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = NILATOM;
  allocp[5] = a2;
  a1 = x0;
  a2 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(check__base_3_0);
  goto check__base_3_ext_interrupt;
 attach__base_3_ext_interrupt:
  reasonp = 0l;
 attach__base_3_interrupt:
  toppred = &predicate_main_xattach__base_3;
  goto interrupt_3;
 }

 check__base_3_top: {
  q x0, x1;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 check__base_3_clear_reason:
  reasonp = reasons;
 check__base_3_0:
  generic_arg[0] = a1;
  allocp[0] = x0 = makeref(&allocp[0]);
  generic_arg[1] = x0;
  allocp[1] = x1 = makeref(&allocp[1]);
  generic_arg[2] = x1;
  call_generic(a0, functor_split_3, 2);
  a1 = a2;
  a2 = a0;
  a0 = x0;
  execute(check__base_2F3_240_3_0);
  goto check__base_2F3_240_3_ext_interrupt;
 check__base_3_ext_interrupt:
  reasonp = 0l;
 check__base_3_interrupt:
  toppred = &predicate_main_xcheck__base_3;
  goto interrupt_3;
 }

 check__base_2F3_240_3_top: {
  q x0;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 check__base_2F3_240_3_clear_reason:
  reasonp = reasons;
 check__base_2F3_240_3_0:
 check__base_2F3_240_3_1:
  if (isref(a0)) goto check__base_2F3_240_3_4;
 check__base_2F3_240_3_2:
  if (isref(a0)) goto check__base_2F3_240_3_3;
  x0 = makefunctor(&string_const_1);
  if_not_equal(a0, x0, check__base_2F3_240_3_5);
  unify(a1, a2);
  proceed();
 check__base_2F3_240_3_3:
  deref_and_jump(a0,check__base_2F3_240_3_2);
  *reasonp++ =  a0;
  goto check__base_2F3_240_3_5;
 check__base_2F3_240_3_4:
  deref_and_jump(a0,check__base_2F3_240_3_1);
  *reasonp++ =  a0;
  goto check__base_2F3_240_3_5;
 check__base_2F3_240_3_5:
  otherwise(check__base_2F3_240_3_interrupt);
  x0 = makefunctor(&string_const_1);
  generic_arg[0] = x0;
  generic_arg[1] = a1;
  call_generic(a2, functor_join_2, 0);
  proceed();
 check__base_2F3_240_3_ext_interrupt:
  reasonp = 0l;
 check__base_2F3_240_3_interrupt:
  toppred = &predicate_main_xcheck__base_2F3_240_3;
  goto interrupt_3;
 }

 attach__base_4_top: {
  q x0, x1, x2, x3, x4, x5;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 attach__base_4_clear_reason:
  reasonp = reasons;
 attach__base_4_0:
 attach__base_4_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != NILATOM) goto attach__base_4_2;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a1,attach__base_4_1);
  *reasonp++ =  a1;
  goto attach__base_4_2;
  };
  goto attach__base_4_2;
 attach__base_4_2:
  otherwise(attach__base_4_interrupt);
 attach__base_4_3:
  switch (ptagof(a1)) {
 case CONS:
  x0 = makeint(1L);
  generic_arg[0] = x0;
  allocp[0] = x1 = makeref(&allocp[0]);
  generic_arg[1] = x1;
  allocp[1] = x2 = makeref(&allocp[1]);
  generic_arg[2] = x2;
  x3 = car_of(a1);
  call_generic(x3, functor_split_3, 2);
  x4 = a0;
  x5 = a2;
  a4 = cdr_of(a1);
  a5 = a3;
  a6 = x3;
  a3 = x5;
  a2 = x2;
  a1 = x4;
  a0 = x1;
  execute(attach__base_2F4_240_7_0);
  goto attach__base_2F4_240_7_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,attach__base_4_3);
  *reasonp++ =  a1;
  goto attach__base_4_interrupt;
  };
  goto attach__base_4_interrupt;
 attach__base_4_ext_interrupt:
  reasonp = 0l;
 attach__base_4_interrupt:
  goto interrupt_4;
 }

 attach__base_2F4_240_7_top: {
  q x0, x1, x2, x3;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 attach__base_2F4_240_7_clear_reason:
  reasonp = reasons;
 attach__base_2F4_240_7_0:
 attach__base_2F4_240_7_1:
  if (isref(a0)) goto attach__base_2F4_240_7_4;
 attach__base_2F4_240_7_2:
  if (isref(a0)) goto attach__base_2F4_240_7_3;
  x0 = makefunctor(&string_const_1);
  if_not_equal(a0, x0, attach__base_2F4_240_7_5);
  generic_arg[0] = a2;
  allocp[0] = x1 = makeref(&allocp[0]);
  generic_arg[1] = x1;
  call_generic(a1, functor_join_2, 1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_main_xattach__base_4);
  allocp[2] = a1;
  allocp[3] = a4;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a5;
  allocp[6] = NILATOM;
  allocp[7] = x1;
  x3 = makecons(&allocp[6]);
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_util_xappend_3);
  allocp[10] = a3;
  allocp[11] = x3;
  allocp[12] = x2;
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  proceed();
 attach__base_2F4_240_7_3:
  deref_and_jump(a0,attach__base_2F4_240_7_2);
  *reasonp++ =  a0;
  goto attach__base_2F4_240_7_5;
 attach__base_2F4_240_7_4:
  deref_and_jump(a0,attach__base_2F4_240_7_1);
  *reasonp++ =  a0;
  goto attach__base_2F4_240_7_5;
 attach__base_2F4_240_7_5:
  otherwise(attach__base_2F4_240_7_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_main_xattach__base_4);
  allocp[2] = a1;
  allocp[3] = a4;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = a5;
  allocp[6] = NILATOM;
  allocp[7] = a6;
  x1 = makecons(&allocp[6]);
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_util_xappend_3);
  allocp[10] = a3;
  allocp[11] = x1;
  allocp[12] = x0;
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  proceed();
 attach__base_2F4_240_7_ext_interrupt:
  reasonp = 0l;
 attach__base_2F4_240_7_interrupt:
  toppred = &predicate_main_xattach__base_2F4_240_7;
  goto interrupt_7;
 }

 form__graph_3_top: {
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 form__graph_3_clear_reason:
  reasonp = reasons;
 form__graph_3_0:
  a3 = a2;
  a2 = NILATOM;
  execute(form__graph_4_0);
  goto form__graph_4_ext_interrupt;
 form__graph_3_ext_interrupt:
  reasonp = 0l;
 form__graph_3_interrupt:
  goto interrupt_3;
 }

 form__graph_4_top: {
  q x0, x1, x2, x3, x4;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 form__graph_4_clear_reason:
  reasonp = reasons;
 form__graph_4_0:
 form__graph_4_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != NILATOM) goto form__graph_4_2;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a1,form__graph_4_1);
  *reasonp++ =  a1;
  goto form__graph_4_2;
  };
  goto form__graph_4_2;
 form__graph_4_2:
  otherwise(form__graph_4_interrupt);
 form__graph_4_3:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_main_xform__graph_4);
  allocp[2] = a0;
  x0 = cdr_of(a1);
  allocp[3] = x0;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = makesym(functor_edge_2);
  allocp[7] = a0;
  x3 = car_of(a1);
  allocp[8] = x3;
  x2 = makefunctor(&allocp[6]);
  allocp[9] = NILATOM;
  allocp[10] = x2;
  x4 = makecons(&allocp[9]);
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_util_xappend_3);
  allocp[13] = a2;
  allocp[14] = x4;
  allocp[15] = x1;
  qp = (struct goalrec*)&allocp[11];
  allocp += 16;
  proceed();
 case VARREF:
  deref_and_jump(a1,form__graph_4_3);
  *reasonp++ =  a1;
  goto form__graph_4_interrupt;
  };
  goto form__graph_4_interrupt;
 form__graph_4_ext_interrupt:
  reasonp = 0l;
 form__graph_4_interrupt:
  toppred = &predicate_main_xform__graph_4;
  goto interrupt_4;
 }
 interrupt_11:
  allocp[12] = a10;
 interrupt_10:
  allocp[11] = a9;
 interrupt_9:
  allocp[10] = a8;
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_main);
}
