#include <stdio.h>

main()
{
	FILE *ptr;
/*	char command[512] = "/home/pippo2/Klic/bin/klic -g -o ~/.netscape/cache/a.out /home/pippo1/epontell/.netscape/cache/file07389aaa.kl1;              /bin/rm atom.* funct.* predicates.* klic.db ;                 ~/.netscape/cache/a.out pippo 5000 5001 &"; */
	char command[512]="mkdir ffooooo &";
	char buffer[256];

		if((ptr = popen(command, "r")) != NULL)
		  {
			while (fgets(buffer,200,ptr) != NULL)
			  printf("%s\n",buffer);
			pclose(ptr);
		  }
		else
			printf("FAILED popen\n");
}

