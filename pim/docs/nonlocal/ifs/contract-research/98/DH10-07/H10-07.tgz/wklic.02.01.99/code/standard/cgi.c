/* Compiled by KLIC compiler version 3.001 (Thu Jun  5 20:19:10 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_cgi();
Const struct predicate predicate_cgi_xbind__cgi_2 =
   { module_cgi, 0, 2 };
Const struct predicate predicate_cgi_xbind__cgi_2F2_240_3 =
   { module_cgi, 1, 3 };
Const struct predicate predicate_cgi_xbind__cgi_2F2_240_2F3_240_5 =
   { module_cgi, 2, 5 };
Const struct predicate predicate_cgi_xverify__arguments_3 =
   { module_cgi, 3, 3 };
Const struct predicate predicate_cgi_xverify__arguments_2F3_240_7 =
   { module_cgi, 4, 7 };
Const struct predicate predicate_cgi_xcheck__port_2 =
   { module_cgi, 5, 2 };
Const struct predicate predicate_cgi_xwait__cgi__input_6 =
   { module_cgi, 6, 6 };
Const struct predicate predicate_cgi_xread__cgi__input_3 =
   { module_cgi, 7, 3 };
Const struct predicate predicate_cgi_xdoinput_3 =
   { module_cgi, 8, 3 };
Const struct predicate predicate_cgi_xdoinput_2F3_240_5 =
   { module_cgi, 9, 5 };
Const struct predicate predicate_cgi_xprocess__input_4 =
   { module_cgi, 10, 4 };
Const struct predicate predicate_cgi_xprocess__input_2F4_240_2 =
   { module_cgi, 11, 2 };
Const struct predicate predicate_cgi_xcheck__input_3 =
   { module_cgi, 12, 3 };
Const struct predicate predicate_cgi_xnamevaluepairs_2 =
   { module_cgi, 13, 2 };
Const struct predicate predicate_cgi_xnamevaluepairs_2F2_240_4 =
   { module_cgi, 14, 4 };
Const struct predicate predicate_cgi_xfind__predicate_3 =
   { module_cgi, 15, 3 };
Const struct predicate predicate_cgi_xfind__predicate1_4 =
   { module_cgi, 16, 4 };
Const struct predicate predicate_cgi_xfind__predicate1_2F4_240_6 =
   { module_cgi, 17, 6 };
Const struct predicate predicate_cgi_xfind__predicate1_2F4_240_2F6_240_7 =
   { module_cgi, 18, 7 };
Const struct predicate predicate_cgi_xformterm_2 =
   { module_cgi, 19, 2 };
extern q string_g_new();
extern q module_g_new();
extern q predicate_g_new();
extern Const struct predicate predicate_unix_xunix_1;
extern Const struct predicate predicate_unix_xargc_1;
extern Const struct predicate predicate_unix_xargv_1;
extern Const struct predicate predicate_builtin_xprint_1;
extern Const struct predicate predicate_generic_xgeneric_2;
extern Const struct predicate predicate_functor__table_x_3D_2E_2E_2;
extern Const struct predicate predicate_util_xlosToLst_2;
extern Const struct predicate predicate_util_xatoi_2;
extern Const struct predicate predicate_util_xappend_3;
extern Const struct predicate predicate_atom__table_xmake__atom_2;

module module_cgi(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_0 =
      declare_string_constant_8(0,0);
  static Const unsigned char strconst_body_1[12] =
    "predicate=";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_1 =
      declare_string_constant_8(strconst_body_1,10);
  q a0, a1, a2, a3, a4, a5, a6;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, bind__cgi_2_top);
    case_pred(1, bind__cgi_2F2_240_3_top);
    case_pred(2, bind__cgi_2F2_240_2F3_240_5_top);
    case_pred(3, verify__arguments_3_top);
    case_pred(4, verify__arguments_2F3_240_7_top);
    case_pred(5, check__port_2_top);
    case_pred(6, wait__cgi__input_6_top);
    case_pred(7, read__cgi__input_3_top);
    case_pred(8, doinput_3_top);
    case_pred(9, doinput_2F3_240_5_top);
    case_pred(10, process__input_4_top);
    case_pred(11, process__input_2F4_240_2_top);
    case_pred(12, check__input_3_top);
    case_pred(13, namevaluepairs_2_top);
    case_pred(14, namevaluepairs_2F2_240_4_top);
    case_pred(15, find__predicate_3_top);
    case_pred(16, find__predicate1_4_top);
    case_pred(17, find__predicate1_2F4_240_6_top);
    case_pred(18, find__predicate1_2F4_240_2F6_240_7_top);
    last_case_pred(19, formterm_2_top);
  }

 bind__cgi_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  qp = qp->next;
 bind__cgi_2_clear_reason:
  reasonp = reasons;
 bind__cgi_2_0:
  allocp[0] = makesym(functor_inet_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_normal_1);
  allocp[3] = a1;
  x2 = makefunctor(&allocp[2]);
  allocp[4] = makesym(functor_bind_2);
  allocp[5] = x0;
  allocp[6] = x2;
  x3 = makefunctor(&allocp[4]);
  allocp[7] = NILATOM;
  allocp[8] = x3;
  x4 = makecons(&allocp[7]);
  allocp[9] = (q)qp;
  allocp[10] = (q)(&predicate_unix_xunix_1);
  allocp[11] = x4;
  allocp[12] = makesym(functor_inet_1);
  allocp[13] = x6 = makeref(&allocp[13]);
  x5 = makefunctor(&allocp[12]);
  allocp[14] = makesym(functor_normal_1);
  allocp[15] = a0;
  x7 = makefunctor(&allocp[14]);
  allocp[16] = makesym(functor_bind_2);
  allocp[17] = x5;
  allocp[18] = x7;
  x8 = makefunctor(&allocp[16]);
  allocp[19] = NILATOM;
  allocp[20] = x8;
  x9 = makecons(&allocp[19]);
  allocp[21] = (q)(struct goalrec*)&allocp[9];
  allocp[22] = (q)(&predicate_unix_xunix_1);
  allocp[23] = x9;
  allocp[24] = (q)(struct goalrec*)&allocp[21];
  allocp[25] = (q)(&predicate_cgi_xbind__cgi_2F2_240_3);
  allocp[26] = x10 = makeref(&allocp[26]);
  allocp[27] = x6;
  allocp[28] = x1;
  allocp[29] = (q)(struct goalrec*)&allocp[24];
  allocp[30] = (q)(&predicate_unix_xargc_1);
  allocp[31] = x10;
  qp = (struct goalrec*)&allocp[29];
  allocp += 32;
  proceed();
 bind__cgi_2_ext_interrupt:
  reasonp = 0l;
 bind__cgi_2_interrupt:
  goto interrupt_2;
 }

 bind__cgi_2F2_240_3_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  qp = qp->next;
 bind__cgi_2F2_240_3_clear_reason:
  reasonp = reasons;
 bind__cgi_2F2_240_3_0:
 bind__cgi_2F2_240_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 bind__cgi_2F2_240_3_2:
  if (a0 != makeint(2L)) goto bind__cgi_2F2_240_3_3;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_cgi_xbind__cgi_2F2_240_2F3_240_5);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a2;
  allocp[6] = x2 = makeref(&allocp[6]);
  a0 = x0;
  a1 = x1;
  a2 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(verify__arguments_3_0);
  goto verify__arguments_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,bind__cgi_2F2_240_3_1);
  *reasonp++ =  a0;
  goto bind__cgi_2F2_240_3_3;
  };
  goto bind__cgi_2F2_240_3_3;
 bind__cgi_2F2_240_3_3:
  otherwise(bind__cgi_2F2_240_3_interrupt);
  x0 = makeint(50000L);
  unify_value(a1, x0);
  x1 = makeint(50001L);
  unify_value(a2, x1);
  proceed();
 bind__cgi_2F2_240_3_ext_interrupt:
  reasonp = 0l;
 bind__cgi_2F2_240_3_interrupt:
  goto interrupt_3;
 }

 bind__cgi_2F2_240_2F3_240_5_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 bind__cgi_2F2_240_2F3_240_5_clear_reason:
  reasonp = reasons;
 bind__cgi_2F2_240_2F3_240_5_0:
 bind__cgi_2F2_240_2F3_240_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_ok)) goto bind__cgi_2F2_240_2F3_240_5_2;
  unify2(a1, a2, a3, a4);
  proceed();
 case VARREF:
  deref_and_jump(a0,bind__cgi_2F2_240_2F3_240_5_1);
  *reasonp++ =  a0;
  goto bind__cgi_2F2_240_2F3_240_5_2;
  };
  goto bind__cgi_2F2_240_2F3_240_5_2;
 bind__cgi_2F2_240_2F3_240_5_2:
  otherwise(bind__cgi_2F2_240_2F3_240_5_interrupt);
  x0 = makeint(50000L);
  unify_value(a1, x0);
  x1 = makeint(50001L);
  unify_value(a3, x1);
  proceed();
 bind__cgi_2F2_240_2F3_240_5_ext_interrupt:
  reasonp = 0l;
 bind__cgi_2F2_240_2F3_240_5_interrupt:
  goto interrupt_5;
 }

 verify__arguments_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  a2 = qp->args[2];
  qp = qp->next;
 verify__arguments_3_clear_reason:
  reasonp = reasons;
 verify__arguments_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_cgi_xverify__arguments_2F3_240_7);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a1;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a2;
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = a0;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_cgi_xcheck__port_2);
  allocp[11] = x3;
  allocp[12] = x1;
  allocp[13] = (q)(struct goalrec*)&allocp[9];
  allocp[14] = (q)(&predicate_cgi_xcheck__port_2);
  allocp[15] = x2;
  allocp[16] = x0;
  allocp[17] = (q)(struct goalrec*)&allocp[13];
  allocp[18] = (q)(&predicate_util_xatoi_2);
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = x3;
  allocp[21] = (q)(struct goalrec*)&allocp[17];
  allocp[22] = (q)(&predicate_util_xatoi_2);
  allocp[23] = x5 = makeref(&allocp[23]);
  allocp[24] = x2;
  allocp[25] = NILATOM;
  allocp[26] = x7 = makeref(&allocp[26]);
  x6 = makecons(&allocp[25]);
  allocp[27] = (q)(struct goalrec*)&allocp[21];
  allocp[28] = (q)(&predicate_util_xlosToLst_2);
  allocp[29] = x6;
  allocp[30] = x4;
  allocp[31] = NILATOM;
  allocp[32] = x9 = makeref(&allocp[32]);
  x8 = makecons(&allocp[31]);
  allocp[33] = (q)(struct goalrec*)&allocp[27];
  allocp[34] = (q)(&predicate_util_xlosToLst_2);
  allocp[35] = x8;
  allocp[36] = x5;
  allocp[37] = x11 = makeref(&allocp[37]);
  allocp[38] = x7;
  x10 = makecons(&allocp[37]);
  allocp[39] = x10;
  allocp[40] = x9;
  x12 = makecons(&allocp[39]);
  allocp[41] = (q)(struct goalrec*)&allocp[33];
  allocp[42] = (q)(&predicate_unix_xargv_1);
  allocp[43] = x12;
  qp = (struct goalrec*)&allocp[41];
  allocp += 44;
  proceed();
 verify__arguments_3_ext_interrupt:
  reasonp = 0l;
 verify__arguments_3_interrupt:
  toppred = &predicate_cgi_xverify__arguments_3;
  goto interrupt_3;
 }

 verify__arguments_2F3_240_7_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 verify__arguments_2F3_240_7_clear_reason:
  reasonp = reasons;
 verify__arguments_2F3_240_7_0:
 verify__arguments_2F3_240_7_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_ok)) goto verify__arguments_2F3_240_7_3;
 verify__arguments_2F3_240_7_2:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_ok)) goto verify__arguments_2F3_240_7_3;
  unify2(a2, a3, a4, a5);
  x0 = makesym(atom_ok);
  unify_value(a6, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,verify__arguments_2F3_240_7_2);
  *reasonp++ =  a1;
  goto verify__arguments_2F3_240_7_3;
  };
  goto verify__arguments_2F3_240_7_3;
 case VARREF:
  deref_and_jump(a0,verify__arguments_2F3_240_7_1);
  *reasonp++ =  a0;
  goto verify__arguments_2F3_240_7_3;
  };
  goto verify__arguments_2F3_240_7_3;
 verify__arguments_2F3_240_7_3:
  otherwise(verify__arguments_2F3_240_7_interrupt);
  x0 = makesym(atom_nok);
  unify_value(a6, x0);
  proceed();
 verify__arguments_2F3_240_7_ext_interrupt:
  reasonp = 0l;
 verify__arguments_2F3_240_7_interrupt:
  goto interrupt_7;
 }

 check__port_2_top: {
  q x0, x1;
  qp = qp->next;
 check__port_2_clear_reason:
  reasonp = reasons;
 check__port_2_0:
 check__port_2_1:
  if (!isint(a0)) goto check__port_2_2;
  gblt_integer(a0,check__port_2_3);
  x0 = makeint(15000L);
  gblt_greater(a0,x0,check__port_2_3);
  x1 = makesym(atom_ok);
  unify_value(a1, x1);
  proceed();
 check__port_2_2:
  if (!isref(a0)) goto check__port_2_3;
  deref_and_jump(a0,check__port_2_1);
  *reasonp++ =  a0;
  goto check__port_2_3;
 check__port_2_3:
  otherwise(check__port_2_interrupt);
  x0 = makesym(atom_nok);
  unify_value(a1, x0);
  proceed();
 check__port_2_ext_interrupt:
  reasonp = 0l;
 check__port_2_interrupt:
  goto interrupt_2;
 }

 wait__cgi__input_6_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 wait__cgi__input_6_clear_reason:
  reasonp = reasons;
 wait__cgi__input_6_0:
  allocp[0] = makesym(functor_accept_1);
  allocp[1] = a2;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = a4;
  allocp[3] = x0;
  x1 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a0, x1);
  allocp[0] = makesym(functor_accept_1);
  allocp[1] = a3;
  x2 = makefunctor(&allocp[0]);
  allocp[2] = a5;
  allocp[3] = x2;
  x3 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a1, x3);
  proceed();
 wait__cgi__input_6_ext_interrupt:
  reasonp = 0l;
 wait__cgi__input_6_interrupt:
  goto interrupt_6;
 }

 read__cgi__input_3_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  qp = qp->next;
 read__cgi__input_3_clear_reason:
  reasonp = reasons;
 read__cgi__input_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_cgi_xprocess__input_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_cgi_xcheck__input_3);
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = x3 = makeref(&allocp[9]);
  allocp[10] = x0;
  x4 = makeint(0L);
  generic_arg[0] = x4;
  x5 = makeint(8L);
  generic_arg[1] = x5;
  qp = (struct goalrec*)&allocp[6];
  new_generic(string_g_new, 2, x6, 11);
  unify(x2, x6);
  a1 = x3;
  a2 = x1;
  execute(doinput_3_0);
  goto doinput_3_ext_interrupt;
 read__cgi__input_3_ext_interrupt:
  reasonp = 0l;
 read__cgi__input_3_interrupt:
  goto interrupt_3;
 }

 doinput_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  qp = qp->next;
 doinput_3_clear_reason:
  reasonp = reasons;
 doinput_3_0:
  allocp[0] = makesym(functor_fread_2);
  allocp[1] = makeint(3L);
  allocp[2] = x1 = makeref(&allocp[2]);
  x0 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_feof_1);
  allocp[4] = x3 = makeref(&allocp[4]);
  x2 = makefunctor(&allocp[3]);
  allocp[5] = x5 = makeref(&allocp[5]);
  allocp[6] = x2;
  x4 = makecons(&allocp[5]);
  allocp[7] = x4;
  allocp[8] = x0;
  x6 = makecons(&allocp[7]);
  allocp += 9;
  unify_value(a0, x6);
  a0 = x3;
  x7 = a1;
  a3 = x1;
  a4 = a2;
  a2 = x7;
  a1 = x5;
  execute(doinput_2F3_240_5_0);
  goto doinput_2F3_240_5_ext_interrupt;
 doinput_3_ext_interrupt:
  reasonp = 0l;
 doinput_3_interrupt:
  toppred = &predicate_cgi_xdoinput_3;
  goto interrupt_3;
 }

 doinput_2F3_240_5_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 doinput_2F3_240_5_clear_reason:
  reasonp = reasons;
 doinput_2F3_240_5_0:
 doinput_2F3_240_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 doinput_2F3_240_5_2:
  switch ((unsigned long)a0) {
 case (unsigned long) makeint(1L):
  x0 = NILATOM;
  unify_value(a1, x0);
  allocp[0] = makesym(functor_f_1);
  allocp[1] = a3;
  x1 = makefunctor(&allocp[0]);
  allocp[2] = NILATOM;
  allocp[3] = x1;
  x2 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a2, x2);
  x3 = makesym(atom_ok);
  unify_value(a4, x3);
  proceed();
 case (unsigned long) makeint(0L):
  allocp[0] = makesym(functor_f_1);
  allocp[1] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x0;
  x1 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a2, x1);
  a0 = a1;
  a1 = x2;
  a2 = a4;
  execute(doinput_3_0);
  goto doinput_3_ext_interrupt;
  };
  goto doinput_2F3_240_5_interrupt;
 case VARREF:
  deref_and_jump(a0,doinput_2F3_240_5_1);
  *reasonp++ =  a0;
  goto doinput_2F3_240_5_interrupt;
  };
  goto doinput_2F3_240_5_interrupt;
 doinput_2F3_240_5_ext_interrupt:
  reasonp = 0l;
 doinput_2F3_240_5_interrupt:
  toppred = &predicate_cgi_xdoinput_2F3_240_5;
  goto interrupt_5;
 }

 process__input_4_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 process__input_4_clear_reason:
  reasonp = reasons;
 process__input_4_0:
 process__input_4_1:
  if (isref(a1)) goto process__input_4_2;
  gblt_wait(a1,process__input_4_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_cgi_xprocess__input_2F4_240_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a2;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_cgi_xfind__predicate_3);
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = x0;
  allocp[8] = a3;
  allocp[9] = (q)(struct goalrec*)&allocp[4];
  allocp[10] = (q)(&predicate_builtin_xprint_1);
  allocp[11] = x1;
  allocp[12] = (q)(struct goalrec*)&allocp[9];
  allocp[13] = (q)(&predicate_builtin_xprint_1);
  allocp[14] = a0;
  a1 = x1;
  qp = (struct goalrec*)&allocp[12];
  allocp += 15;
  execute(namevaluepairs_2_0);
  goto namevaluepairs_2_ext_interrupt;
 process__input_4_2:
  deref_and_jump(a1,process__input_4_1);
  *reasonp++ =  a1;
  goto process__input_4_interrupt;
 process__input_4_ext_interrupt:
  reasonp = 0l;
 process__input_4_interrupt:
  goto interrupt_4;
 }

 process__input_2F4_240_2_top: {
  q x0, x1, x2, x3;
  qp = qp->next;
 process__input_2F4_240_2_clear_reason:
  reasonp = reasons;
 process__input_2F4_240_2_0:
 process__input_2F4_240_2_1:
  if (isref(a0)) goto process__input_2F4_240_2_4;
 process__input_2F4_240_2_2:
  if (isref(a0)) goto process__input_2F4_240_2_3;
  x0 = makefunctor(&string_const_0);
  if_not_equal(a0, x0, process__input_2F4_240_2_5);
  x1 = makefunctor(&string_const_0);
  unify_value(a1, x1);
  proceed();
 process__input_2F4_240_2_3:
  deref_and_jump(a0,process__input_2F4_240_2_2);
  *reasonp++ =  a0;
  goto process__input_2F4_240_2_5;
 process__input_2F4_240_2_4:
  deref_and_jump(a0,process__input_2F4_240_2_1);
  *reasonp++ =  a0;
  goto process__input_2F4_240_2_5;
 process__input_2F4_240_2_5:
  otherwise(process__input_2F4_240_2_interrupt);
  x0 = makesym(atom_main);
  generic_arg[0] = x0;
  new_generic(module_g_new, 1, x1, 0);
  generic_arg[0] = x1;
  generic_arg[1] = a0;
  x2 = makeint(2L);
  generic_arg[2] = x2;
  new_generic(predicate_g_new, 3, x3, 0);
  unify(a1, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin_xprint_1);
  allocp[2] = x1;
  allocp[3] = (q)(struct goalrec*)&allocp[0];
  allocp[4] = (q)(&predicate_builtin_xprint_1);
  allocp[5] = a0;
  qp = (struct goalrec*)&allocp[3];
  allocp += 6;
  proceed();
 process__input_2F4_240_2_ext_interrupt:
  reasonp = 0l;
 process__input_2F4_240_2_interrupt:
  goto interrupt_2;
 }

 check__input_3_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  qp = qp->next;
 check__input_3_clear_reason:
  reasonp = reasons;
 check__input_3_0:
 check__input_3_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
 check__input_3_2:
  if (!isgobj(a0)) goto check__input_3_5;
 check__input_3_3:
  gblt_is_string(a0,check__input_3_5);
  gblt_size_of_string(a0,x0,check__input_3_5);
  gblt_element_size_of_string(a0,x1,check__input_3_5);
 check__input_3_4:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != NILATOM) goto check__input_3_5;
  unify_value(a2, a0);
  proceed();
 case VARREF:
  deref_and_jump(a1,check__input_3_4);
  *reasonp++ =  a1;
  goto check__input_3_5;
  };
  goto check__input_3_5;
 case VARREF:
  deref_and_jump(a0,check__input_3_1);
  *reasonp++ =  a0;
  goto check__input_3_5;
  };
  goto check__input_3_5;
 check__input_3_5:
 check__input_3_6:
  switch (ptagof(a1)) {
 case CONS:
 check__input_3_7:
  switch (ptagof(a0)) {
 case FUNCTOR:
 check__input_3_8:
  if (!isgobj(a0)) goto check__input_3_interrupt;
 check__input_3_9:
  gblt_is_string(a0,check__input_3_interrupt);
  gblt_size_of_string(a0,x0,check__input_3_interrupt);
  gblt_element_size_of_string(a0,x1,check__input_3_interrupt);
  x2 = car_of(a1);
 check__input_3_10:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_f_1)) goto check__input_3_interrupt;
  x3 = arg(x2, 0);
  generic_arg[0] = x3;
  allocp[0] = x4 = makeref(&allocp[0]);
  generic_arg[1] = x4;
  call_generic(a0, functor_join_2, 1);
  a0 = x4;
  a1 = cdr_of(a1);
  execute(check__input_3_clear_reason);
  goto check__input_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x2,check__input_3_10);
  *reasonp++ =  x2;
  goto check__input_3_interrupt;
  };
  goto check__input_3_interrupt;
 case VARREF:
  deref_and_jump(a0,check__input_3_7);
  *reasonp++ =  a0;
  goto check__input_3_interrupt;
  };
  goto check__input_3_interrupt;
 case VARREF:
  deref_and_jump(a1,check__input_3_6);
  *reasonp++ =  a1;
  goto check__input_3_interrupt;
  };
  goto check__input_3_interrupt;
 check__input_3_ext_interrupt:
  reasonp = 0l;
 check__input_3_interrupt:
  goto interrupt_3;
 }

 namevaluepairs_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  qp = qp->next;
 namevaluepairs_2_clear_reason:
  reasonp = reasons;
 namevaluepairs_2_0:
 namevaluepairs_2_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
 namevaluepairs_2_2:
  if (!isgobj(a0)) goto namevaluepairs_2_interrupt;
 namevaluepairs_2_3:
  gblt_is_string(a0,namevaluepairs_2_interrupt);
  gblt_size_of_string(a0,x0,namevaluepairs_2_interrupt);
  gblt_element_size_of_string(a0,x1,namevaluepairs_2_interrupt);
  allocp[0] = x2 = makeref(&allocp[0]);
  generic_arg[0] = x2;
  call_generic(a0, functor_size_1, 1);
  x3 = makeint(1L);
  bblt_sub_no_check_y(x2,x3,x4);
  x5 = makeint(0L);
  generic_arg[0] = x5;
  generic_arg[1] = x4;
  x6 = makeint(38L);
  generic_arg[2] = x6;
  allocp[0] = x7 = makeref(&allocp[0]);
  generic_arg[3] = x7;
  call_generic(a0, functor_search__character_4, 1);
  a2 = a0;
  a3 = x4;
  a0 = x7;
  execute(namevaluepairs_2F2_240_4_0);
  goto namevaluepairs_2F2_240_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,namevaluepairs_2_1);
  *reasonp++ =  a0;
  goto namevaluepairs_2_interrupt;
  };
  goto namevaluepairs_2_interrupt;
 namevaluepairs_2_ext_interrupt:
  reasonp = 0l;
 namevaluepairs_2_interrupt:
  toppred = &predicate_cgi_xnamevaluepairs_2;
  goto interrupt_2;
 }

 namevaluepairs_2F2_240_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 namevaluepairs_2F2_240_4_clear_reason:
  reasonp = reasons;
 namevaluepairs_2F2_240_4_0:
 namevaluepairs_2F2_240_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 namevaluepairs_2F2_240_4_2:
  if (a0 != makeint(-1L)) goto namevaluepairs_2F2_240_4_3;
  allocp[0] = NILATOM;
  allocp[1] = a2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,namevaluepairs_2F2_240_4_1);
  *reasonp++ =  a0;
  goto namevaluepairs_2F2_240_4_interrupt;
  };
  goto namevaluepairs_2F2_240_4_3;
 namevaluepairs_2F2_240_4_3:
  x0 = makeint(-1L);
  gblt_diff(a0,x0,namevaluepairs_2F2_240_4_interrupt);
  generic_arg[0] = a0;
  allocp[0] = x1 = makeref(&allocp[0]);
  generic_arg[1] = x1;
  allocp[1] = x2 = makeref(&allocp[1]);
  generic_arg[2] = x2;
  call_generic(a2, functor_split_3, 2);
  allocp[0] = x3 = makeref(&allocp[0]);
  generic_arg[0] = x3;
  call_generic(x1, functor_size_1, 1);
  bblt_sub(a3,x3,x4);
  x5 = makeint(1L);
  generic_arg[0] = x5;
  allocp[0] = x6 = makeref(&allocp[0]);
  generic_arg[1] = x6;
  allocp[1] = x7 = makeref(&allocp[1]);
  generic_arg[2] = x7;
  call_generic(x2, functor_split_3, 2);
  allocp[0] = x9 = makeref(&allocp[0]);
  allocp[1] = x1;
  x8 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x8);
  a0 = x7;
  a1 = x9;
  execute(namevaluepairs_2_0);
  goto namevaluepairs_2_ext_interrupt;
 namevaluepairs_2F2_240_4_ext_interrupt:
  reasonp = 0l;
 namevaluepairs_2F2_240_4_interrupt:
  toppred = &predicate_cgi_xnamevaluepairs_2F2_240_4;
  goto interrupt_4;
 }

 find__predicate_3_top: {
  a2 = qp->args[2];
  qp = qp->next;
 find__predicate_3_clear_reason:
  reasonp = reasons;
 find__predicate_3_0:
  a3 = a2;
  a2 = NILATOM;
  execute(find__predicate1_4_0);
  goto find__predicate1_4_ext_interrupt;
 find__predicate_3_ext_interrupt:
  reasonp = 0l;
 find__predicate_3_interrupt:
  goto interrupt_3;
 }

 find__predicate1_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 find__predicate1_4_clear_reason:
  reasonp = reasons;
 find__predicate1_4_0:
 find__predicate1_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != NILATOM) goto find__predicate1_4_2;
  x0 = makefunctor(&string_const_0);
  unify_value(a1, x0);
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,find__predicate1_4_1);
  *reasonp++ =  a0;
  goto find__predicate1_4_2;
  };
  goto find__predicate1_4_2;
 find__predicate1_4_2:
  otherwise(find__predicate1_4_interrupt);
 find__predicate1_4_3:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 find__predicate1_4_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
 find__predicate1_4_5:
  if (!isgobj(x0)) goto find__predicate1_4_interrupt;
 find__predicate1_4_6:
  gblt_is_string(x0,find__predicate1_4_interrupt);
  gblt_size_of_string(x0,x1,find__predicate1_4_interrupt);
  gblt_element_size_of_string(x0,x2,find__predicate1_4_interrupt);
  allocp[0] = x3 = makeref(&allocp[0]);
  generic_arg[0] = x3;
  call_generic(x0, functor_size_1, 1);
  x4 = makeint(1L);
  bblt_sub_no_check_y(x3,x4,x5);
  x6 = makeint(0L);
  generic_arg[0] = x6;
  generic_arg[1] = x5;
  x7 = makeint(61L);
  generic_arg[2] = x7;
  allocp[0] = x8 = makeref(&allocp[0]);
  generic_arg[3] = x8;
  call_generic(x0, functor_search__character_4, 1);
  x9 = a2;
  a4 = cdr_of(a0);
  a5 = a3;
  a3 = x9;
  a2 = x0;
  a0 = x8;
  execute(find__predicate1_2F4_240_6_0);
  goto find__predicate1_2F4_240_6_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,find__predicate1_4_4);
  *reasonp++ =  x0;
  goto find__predicate1_4_interrupt;
  };
  goto find__predicate1_4_interrupt;
 case VARREF:
  deref_and_jump(a0,find__predicate1_4_3);
  *reasonp++ =  a0;
  goto find__predicate1_4_interrupt;
  };
  goto find__predicate1_4_interrupt;
 find__predicate1_4_ext_interrupt:
  reasonp = 0l;
 find__predicate1_4_interrupt:
  toppred = &predicate_cgi_xfind__predicate1_4;
  goto interrupt_4;
 }

 find__predicate1_2F4_240_6_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 find__predicate1_2F4_240_6_clear_reason:
  reasonp = reasons;
 find__predicate1_2F4_240_6_0:
 find__predicate1_2F4_240_6_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 find__predicate1_2F4_240_6_2:
  if (a0 != makeint(-1L)) goto find__predicate1_2F4_240_6_3;
  x0 = makefunctor(&string_const_0);
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,find__predicate1_2F4_240_6_1);
  *reasonp++ =  a0;
  goto find__predicate1_2F4_240_6_interrupt;
  };
  goto find__predicate1_2F4_240_6_3;
 find__predicate1_2F4_240_6_3:
  x0 = makeint(-1L);
  gblt_diff(a0,x0,find__predicate1_2F4_240_6_interrupt);
  x1 = makeint(1L);
  bblt_add_no_check_y(a0,x1,x2);
  generic_arg[0] = x2;
  allocp[0] = x3 = makeref(&allocp[0]);
  generic_arg[1] = x3;
  allocp[1] = x4 = makeref(&allocp[1]);
  generic_arg[2] = x4;
  call_generic(a2, functor_split_3, 2);
  a0 = x3;
  x5 = a1;
  a6 = a2;
  a2 = x5;
  a1 = x4;
  execute(find__predicate1_2F4_240_2F6_240_7_0);
  goto find__predicate1_2F4_240_2F6_240_7_ext_interrupt;
 find__predicate1_2F4_240_6_ext_interrupt:
  reasonp = 0l;
 find__predicate1_2F4_240_6_interrupt:
  toppred = &predicate_cgi_xfind__predicate1_2F4_240_6;
  goto interrupt_6;
 }

 find__predicate1_2F4_240_2F6_240_7_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 find__predicate1_2F4_240_2F6_240_7_clear_reason:
  reasonp = reasons;
 find__predicate1_2F4_240_2F6_240_7_0:
 find__predicate1_2F4_240_2F6_240_7_1:
  if (isref(a0)) goto find__predicate1_2F4_240_2F6_240_7_4;
 find__predicate1_2F4_240_2F6_240_7_2:
  if (isref(a0)) goto find__predicate1_2F4_240_2F6_240_7_3;
  x0 = makefunctor(&string_const_1);
  if_not_equal(a0, x0, find__predicate1_2F4_240_2F6_240_7_5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_util_xappend_3);
  allocp[2] = a3;
  allocp[3] = a4;
  allocp[4] = a5;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_atom__table_xmake__atom_2);
  allocp[7] = a1;
  allocp[8] = a2;
  qp = (struct goalrec*)&allocp[5];
  allocp += 9;
  proceed();
 find__predicate1_2F4_240_2F6_240_7_3:
  deref_and_jump(a0,find__predicate1_2F4_240_2F6_240_7_2);
  *reasonp++ =  a0;
  goto find__predicate1_2F4_240_2F6_240_7_5;
 find__predicate1_2F4_240_2F6_240_7_4:
  deref_and_jump(a0,find__predicate1_2F4_240_2F6_240_7_1);
  *reasonp++ =  a0;
  goto find__predicate1_2F4_240_2F6_240_7_5;
 find__predicate1_2F4_240_2F6_240_7_5:
  otherwise(find__predicate1_2F4_240_2F6_240_7_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_cgi_xfind__predicate1_4);
  allocp[2] = a4;
  allocp[3] = a2;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = a5;
  allocp[6] = NILATOM;
  allocp[7] = a6;
  x1 = makecons(&allocp[6]);
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_util_xappend_3);
  allocp[10] = a3;
  allocp[11] = x1;
  allocp[12] = x0;
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  proceed();
 find__predicate1_2F4_240_2F6_240_7_ext_interrupt:
  reasonp = 0l;
 find__predicate1_2F4_240_2F6_240_7_interrupt:
  toppred = &predicate_cgi_xfind__predicate1_2F4_240_2F6_240_7;
  goto interrupt_7;
 }

 formterm_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15;
  qp = qp->next;
 formterm_2_clear_reason:
  reasonp = reasons;
 formterm_2_0:
 formterm_2_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
 formterm_2_2:
  if (!isgobj(a0)) goto formterm_2_interrupt;
 formterm_2_3:
  gblt_is_string(a0,formterm_2_interrupt);
  gblt_size_of_string(a0,x0,formterm_2_interrupt);
  gblt_element_size_of_string(a0,x1,formterm_2_interrupt);
  allocp[0] = x2 = makeref(&allocp[0]);
  generic_arg[0] = x2;
  call_generic(a0, functor_size_1, 1);
  x3 = makeint(1L);
  bblt_sub_no_check_y(x2,x3,x4);
  x5 = makeint(0L);
  generic_arg[0] = x5;
  generic_arg[1] = x4;
  x6 = makeint(61L);
  generic_arg[2] = x6;
  allocp[0] = x7 = makeref(&allocp[0]);
  generic_arg[3] = x7;
  call_generic(a0, functor_search__character_4, 1);
  generic_arg[0] = x7;
  allocp[0] = x8 = makeref(&allocp[0]);
  generic_arg[1] = x8;
  allocp[1] = x9 = makeref(&allocp[1]);
  generic_arg[2] = x9;
  call_generic(a0, functor_split_3, 2);
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x10 = makecons(&allocp[0]);
  allocp[2] = x10;
  allocp[3] = x12 = makeref(&allocp[3]);
  x11 = makecons(&allocp[2]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[6] = a1;
  allocp[7] = x11;
  allocp[8] = makesym(functor_split_3);
  allocp[9] = makeint(1L);
  allocp[10] = x14 = makeref(&allocp[10]);
  allocp[11] = x15 = makeref(&allocp[11]);
  x13 = makefunctor(&allocp[8]);
  allocp[12] = (q)(struct goalrec*)&allocp[4];
  allocp[13] = (q)(&predicate_generic_xgeneric_2);
  allocp[14] = x13;
  allocp[15] = x9;
  allocp[16] = (q)(struct goalrec*)&allocp[12];
  allocp[17] = (q)(&predicate_atom__table_xmake__atom_2);
  allocp[18] = x8;
  allocp[19] = x12;
  qp = (struct goalrec*)&allocp[16];
  allocp += 20;
  proceed();
 case VARREF:
  deref_and_jump(a0,formterm_2_1);
  *reasonp++ =  a0;
  goto formterm_2_interrupt;
  };
  goto formterm_2_interrupt;
 formterm_2_ext_interrupt:
  reasonp = 0l;
 formterm_2_interrupt:
  goto interrupt_2;
 }
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_cgi);
}
