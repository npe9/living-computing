#include <stdio.h>
#include <unistd.h>

main ()
{
	char buf[128];

	if (gethostname(buf,127) != -1)
		printf("Name=%s\n",buf);
	else
		printf("unable\n");
}

