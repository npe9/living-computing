/***
    $B%f!<%6%$%s%?%U%'!<%9%7%9%F%`%5!<%P$G;HMQ$5$l$k(B
     $BBP(BKLIC$B@\B3MQ%W%m%0%i%`MQ%W%m%0%i%`!J<u?.MQ!K(B
        Copyright (c) 1999  Fumio Mizoguchi 
***/

/*KLIC$BMQ$N%5!<%P%W%m%0%i%`(B*/
import java.io.*;
import java.net.*;

class KlicReader implements Runnable{
    final int MAX_CHANNELS = 256; // $B:GBg%A%c%M%k?t(B
    KlicChannel channel[] = new KlicChannel[MAX_CHANNELS];  
    ServerSocket serversocket;
    Server server;
    Thread thread = null;
    int port = 17321;

    KlicReader(Server s){
	server = s;
	start();
    }

    public void start() {
        if (thread == null) {
            thread = new Thread(this);
            thread.start();
        }
    }
    
    public void stop() {
        if (thread != null) {
            thread.stop();
            thread = null;
        }
    }

    public void message(String handle){
	int id = get_data(handle);
	String message = get_under(handle);
        server.sendMessage(id,message);
    }


    public static int get_data(String s){
        int k = 0, ov=0;
        int l = 0;
        String ds;
        String str_num = "";

        try{
            for(k = ov; k<s.length(); k++){
                ds = s.substring(k,k+1);
                if (" ".equals(ds) ){
                    return Integer.valueOf(str_num).intValue();
                }
                else str_num = str_num + ds;
            }
        }
        catch(NumberFormatException e ){
            System.out.println("NumberFornatException !!");
            System.out.println("DATA : "+s);
            System.out.println("ov = "+ov+"  ,  "+s.length());
            System.out.println("k = "+k+"  ,  "+str_num+","+str_num.length());
            l = 0;
        }
        return(-1);
    }

    public static String get_under(String s){
        int k = 0, ov=0;
        int l = 0;
        String ds;

        try{
            for(k = ov; k<s.length(); k++){
                ds = s.substring(k,k+1);
                if (" ".equals(ds) ){
                    return s.substring(k+1,s.length());
                }
            }
        }
        catch(NumberFormatException e ){
            System.out.println("NumberFornatException !!");
            l = 0;
        }
        return "-1";
    }




    public void run() {
	int i;
        try {
	    System.out.println("start klicReqder"+port);
            serversocket = new ServerSocket(port);   // $B%a%$%s%5!<%P!<3+J|(B
            while (true) {                     // $B6u$$$F$$$k%A%c%M%k$rC5$9(B
                for (i = 1; i < MAX_CHANNELS; i++) {
                    if (channel[i] == null || channel[i].thread == null) {
                        break;
                    }
                }
                if (i == MAX_CHANNELS)      // $B:GBg$N%/%i%$%"%s%H?t$J$i=*N;(B
                  return;
                Socket socket = serversocket.accept();    // $B@\B3BT$A(B
                channel[i] = new KlicChannel(socket, this);// $B?7%A%c%M%k:n@.(B
            }
        } catch(IOException e) {
            System.out.println("Server Err!");
            return;
        }
    }

}
