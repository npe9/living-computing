/*
 *        Arm Robot mover proglam
 *
 *         Copyright (c) 1999  Fumio Mizoguchi 
 */

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/termio.h>
#include <fcntl.h>
#include <time.h>

/* #include <sys/ioctl.h> */

struct sockaddr_in   sin; 
struct servent       *sp; 
struct hostent       *hp; 


char   buf[1024];

main(argc,argv)
int   argc;
char  *argv[];
{
    int   fromlen;
    int   s,sn1,sn2;
    int   cc;
    int   fd1,x,mode;
    int   s1_port = 12002;
    int   s2_port = 12001;
    struct sockaddr_in   sin,from;
    struct servent *sp;

    
    fd1 = open("/dev/ttya",O_RDWR);

    s = socket(AF_INET, SOCK_STREAM, 0);
    if(s < 0){
 	fprintf(stderr, "rwriteed: socket\n");
	exit(1);
    }
    sin.sin_family = AF_INET;
    sin.sin_port = s1_port;
    sin.sin_addr.s_addr = INADDR_ANY;
    while(bind(s, (caddr_t)&sin, sizeof(sin)) < 0){
	fprintf(stderr, "rwrited: bind\n");
	sleep(5);
    }
    if(listen(s,5) < 0){
	fprintf(stderr, "rwrited: listen\n");
	exit(1);
    }

    fromlen = sizeof(from);
    sn1 = accept(s, &from, &fromlen);
    if(sn1 < 0){
	/* fprintf(stderr, "rwrited: accept\n"); */
	sleep(5);
	exit(-1);
    }
    close(s); 

    printf("accept sn1\n");

    s = socket(AF_INET, SOCK_STREAM, 0);
    if(s < 0){
        fprintf(stderr, "rwriteed: socket\n");
        exit(1);
    }
    sin.sin_family = AF_INET;
    sin.sin_port = s2_port;
    sin.sin_addr.s_addr = INADDR_ANY;
    while(bind(s, (caddr_t)&sin, sizeof(sin)) < 0){
        fprintf(stderr, "rwrited: bind\n");
        sleep(5);
    }
    if(listen(s,5) < 0){
        fprintf(stderr, "rwrited: listen\n");
        exit(1);
    }

    fromlen = sizeof(from);
    sn2 = accept(s, &from, &fromlen);
    if(sn2 < 0){
        /* fprintf(stderr, "rwrited: accept\n"); */
        sleep(5);
	exit(-1);
    }
    close(s);

    printf("accept sn2\n");
    
    for(;;){
	buf[0] = '\0';
	read(sn1,buf,sizeof(buf));
    
	write(fd1,buf,strlen(buf));
	write(fd1,"\015",1);
	printf("%s \n",buf);
	
	wait_time(50); 
	
	x = 1;
	while(x){
	    ioctl(fd1,TIOCMGET,&mode);
	    if(mode == 0x026) x = 0;
	}
	if(write(sn2, "ok\0", 3) < 1) {
	    fprintf(stderr,"rwrite: write\n");
	    exit(1);
	}
    }
}


wait_time(wtime)
int wtime;
{
    clock_t start,finish;
    start = clock();
    
    while((double)(clock()-start) < wtime*10000);

}

