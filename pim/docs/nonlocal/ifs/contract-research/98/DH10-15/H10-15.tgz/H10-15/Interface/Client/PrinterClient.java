/***
      $B%f!<%6%$%s%?%U%'!<%9%7%9%F%`%/%i%$%"%s%H(B
      $B%W%j%s%?%G%j%P%j%5!<%S%9MW5a%"%W%l%C%H(B
        Copyright (c) 1999  Fumio Mizoguchi 
***/

/* Printer $B%A%c%C%HMQ%"%W%l%C%H%W%m%0%i%`(B */

import java.applet.*;
import java.awt.*;

public class PrinterClient extends Applet implements Runnable {
    TextField inputArea;     // $BF~NOMQ%F%-%9%H%U%#!<%k%I(B
    TextArea freeArea;       // $B=PNOMQ%F%-%9%H%(%j%"(B
    Client client = null;    // Client $B%/%i%9(B
    String host = "192.168.1.11";  // $B%[%9%HL>(B
    int port = 17320;              // $B%]!<%HHV9f(B
    //TextField roomNum;

    String roomName;

    Choice roomNum = new Choice();
    Button Callb1 = new Button("Print1 Delivery");
    Button Callb2 = new Button("Print2 Delivery");
    Label room = new Label("Room Number : ");
    Button Connectb = new Button("Connect");
    Button Quitb = new Button("Quit");
    Thread thread = null;    

    public static void main(String args[]) {
        Frame f = new Frame("PrinterClient");
	PrinterClient chatapplet = new PrinterClient();
        chatapplet.init();
        f.add("Center", chatapplet);
        f.setSize(230, 110);
        f.setVisible(true);
    }
 
    public void init() {
	setLayout(null);

	// $B%"%W%l%C%H$N%l%$%"%&%H(B
	roomNum.addItem("P2A");
	roomNum.addItem("P2B");
	roomNum.addItem("P2C");
	roomNum.addItem("P2D");
	roomNum.addItem("P2E");
	roomNum.addItem("P2F");
	roomNum.addItem("P2G");
	roomNum.addItem("P2H");
	roomNum.addItem("P2I");
	roomNum.addItem("P2J");
	roomNum.addItem("P2K");
	roomNum.addItem("P2L");
	roomNum.addItem("PBoard");
	roomNum.addItem("PLiving");
	roomNum.addItem("PLibrary");

	room.setBounds(10,10,100,30);
	roomNum.setBounds(120,10,100,30);
	Callb1.setBounds(10,5,200,30);
	Callb2.setBounds(10,40,200,30);
	Quitb.setBounds(110,50,100,30);
	Connectb.setBounds(10,50,100,30);

	Callb1.setVisible(false);
	Callb2.setVisible(false);
	
	add(Callb1);
	add(Callb2);
	add(room);
	add(roomNum);
	add(Connectb);
	add(Quitb);
    }
    
    public void start() {
        if (thread == null) {
            thread = new Thread(this);
            thread.start();
        }
    }
    
    public void stop() {
        if (thread != null) {
            thread.stop();
            thread = null;
        }
    }

    // $B%/%i%$%"%s%H$N%a%$%s%k!<%A%s(B
    public void run(){
	System.out.println("start");
	String s ;
	while(thread != null) {
	    s = client.read();       // $B%a%C%;!<%8$NFI$_$H$j(B
	    if(s == null)  clientClose();         
	    else freeArea.append(s + "\n"); // $B%F%-%9%H%(%j%"$X=PNO(B
	}
    }

    // $B2s@~$N@\B3$r9T$J$&(B
    public boolean clientOpen(){
	String room = roomNum.getSelectedItem();
	if(client == null && !room.equals("")){
	    client = new Client(host, port);  // Client$B%/%i%9$N8F$S=P$7(B
	    if(client.socket == null) {       // $B@\B3<:GT!)(B
		System.out.println("Connect Err");
		client = null;
		return false;
	    }
	    else {
		roomName = checkRoom(room);
		// client.write(room2);
		System.out.println("connect "+roomName);
		return true;
	    }
	}
	else return false;
    }

    public String checkRoom(String s) {
	String room = null;
	if(s.equals("P2A")) room = "2a";
	else if(s.equals("P2B")) room = "2b";
	else if(s.equals("P2C")) room = "2c";
	else if(s.equals("P2D")) room = "2d";
	else if(s.equals("P2E")) room = "2e";
	else if(s.equals("P2F")) room = "2f";
	else if(s.equals("P2G")) room = "2g";
	else if(s.equals("P2H")) room = "2h";
	else if(s.equals("P2I")) room = "2i";
	else if(s.equals("P2J")) room = "2j";
	else if(s.equals("P2K")) room = "2k";
	else if(s.equals("P2L")) room = "2l";
	else if(s.equals("PBoard")) room = "bd";
	else if(s.equals("PLiving")) room = "lv";
	else if(s.equals("PLibrary")) room = "li";

	return room;
    }

    // $B@\B3$N@ZCG$r9T$J$&(B
    public void clientClose(){
	if(client != null){
	    client.close();
	    client = null;
	    thread = null;
	}
    }

    // $B%$%Y%s%H=hM}(B
    public boolean action(Event e, Object arg) {
        String label = (String)arg;
	if(label.equals("Connect")){    // $B2s@~@\B3$r<B9T(B
	    if(clientOpen()) {
		Callb1.setVisible(true);
		Callb2.setVisible(true);
		Quitb.setVisible(false);
		Connectb.setVisible(false);
		room.setVisible(false);
		roomNum.setVisible(false);
		repaint();
		start();
	    }
	    return true;
	}
	else if(label.equals("Print1 Delivery") && client != null){ // $B2s@~@ZCG$r<B9T(B
	    String Message = "pr 1 "+roomName;
            client.write(Message);
	    return true;
	}
	else if(label.equals("Print2 Delivery") && client != null){ // $B2s@~@ZCG$r<B9T(B
	    System.out.println("check "+roomName);
	    String Message = "pr 2 "+roomName;
            client.write(Message);
	    return true;
	}
	else if(label.equals("Quit")) { // $B%"%W%l%C%H$N=*N;(B
	    clientClose();
	    System.exit(1);
	    return true;
	}
	else return false;
    }
}
