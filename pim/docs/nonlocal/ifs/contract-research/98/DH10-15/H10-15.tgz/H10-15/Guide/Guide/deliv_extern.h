/* %%%                                      %%%
 * %%%   deliv_extern.h                     %%%
 * %%%   Copyright (C) 1999 Fumio Mizoguchi %%%
 * %%%                                      %%%
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>

#define streq(a,b) (!strcmp(a,b))

typedef struct sockaddr_in Sockaddr_In;

typedef struct{

    int point[4];

}Scout_Point;

typedef struct{

    int scale;
    int verbose;
    int port;
    int sv_port;
    int noimage;
    int nonomad;
    int debug;
    int red;
    int blue;
    char *file;
    char *device;
    int nocomm;

}Global_Data;

typedef struct{
    char label[32];
    char IP[16];
    int  port;
}Comm_Data;

typedef struct{
    int sock;
    int named_sock;
    struct hostent *hp;
    struct sockaddr_in sock_in;
}Tcp_Server_Data;

Global_Data globals;
struct conf_data *conf_start;
Comm_Data scout,image,hoge_read,hoge_write;

//extern int error;
static int named1,named2,len1,len2;
static int flag1, flag2,ret,i;
static Sockaddr_In caddr1, caddr2;

/*        prototype definition    */

int  tcp_server_init(int, Tcp_Server_Data *);
//int  client_connect(char *, char *, struct hostent *, struct sockaddr_in *);
int client_connect(char *,char *,int,int *,struct hostent *,struct sockaddr_in *);

int  get_status(Scout_Point *, char *);
void scout_control(Scout_Point *, char *, int *, int *, int *,int *,int *);
void buff_clr(char *, int);
void serv_wait(Tcp_Server_Data *, Tcp_Server_Data *);
void send_message(Tcp_Server_Data *, Tcp_Server_Data *, Scout_Point *);
int  read_conf_file(void);
void getdata(char *);
void set_option(void);
