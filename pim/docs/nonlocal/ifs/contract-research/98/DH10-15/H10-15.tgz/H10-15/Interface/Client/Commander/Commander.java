/***
         $B%3%^%s%IAw?.MQ%"%W%l%C%H%W%m%0%i%`(B 
        Copyright (c) 1999  Fumio Mizoguchi 
***/

import java.applet.*;
import java.awt.*;

public class Commander extends Applet implements Runnable {
    TextField inputArea;     // $BF~NOMQ%F%-%9%H%U%#!<%k%I(B
    TextArea freeArea;       // $B=PNOMQ%F%-%9%H%(%j%"(B
    Client client = null;    // Client $B%/%i%9(B
    String host = "192.168.1.11";  // $B%[%9%HL>(B
    int port = 17320;              // $B%]!<%HHV9f(B
    TextField hostField, portField;
    Thread thread = null;

    public static void main(String args[]) {
        Frame f = new Frame("ChatApplet");
	Commander commander = new Commander();
        commander.init();
        f.add("Center", commander);
        f.setSize(400, 300);
        f.setVisible(true);
    }
 
    public void init() {
	// $B%"%W%l%C%H$N%l%$%"%&%H(B
	setLayout(new BorderLayout());
	Panel p = new Panel();
	Panel p1 = new Panel();
	Panel p2 = new Panel();
	p.setLayout(new BorderLayout());
	p1.setLayout(new GridLayout(1,5,10,10));
	p1.add(new Label("Host = ", Label.RIGHT));
	p1.add(hostField = new TextField(host));
	p1.add(new Label("Port = ", Label.RIGHT));
	p1.add(portField = new TextField(""+port));
	p1.add(new Button("Connect"));
	p2.add(new Button("Close"));
	p2.add(new Button("Quit"));
	p.add("North", p1);
	p.add("Center", p2);


	Panel message = new Panel();
	message.setLayout(new BorderLayout());
	message.add("West", new Label("Send:"));
	message.add("Center", inputArea = new TextField("",30));
	freeArea = new TextArea();
	freeArea.setEditable(false);
	add("North", message);
	add("Center", freeArea);
	add("South", p);
    }
    
    public void start() {
        if (thread == null && client != null) {
            thread = new Thread(this);
            thread.start();
        }
    }
    
    public void stop() {
        if (thread != null) {
            thread.stop();
            thread = null;
        }
    }

    // $B%/%i%$%"%s%H$N%a%$%s%k!<%A%s(B
    public void run(){
	String s ;
	while(thread != null) {
	    s = client.read();       // $B%a%C%;!<%8$NFI$_$H$j(B
	    if(s == null)  clientClose();         
	    else freeArea.append(s + "\n"); // $B%F%-%9%H%(%j%"$X=PNO(B
	}
    }

    // $B2s@~$N@\B3$r9T$J$&(B
    public boolean clientOpen(){
	if(client == null){
	    host = hostField.getText();
	    port = Integer.valueOf(portField.getText()).intValue();;
	    client = new Client(host, port);  // Client$B%/%i%9$N8F$S=P$7(B
	    if(client.socket1 == null) {       // $B@\B3<:GT!)(B
		System.out.println("Connect Err");
		client = null;
		return false;
	    }
	    else {
	      freeArea.setText("");
                return true;
	    }
	}
	else return false;
    }

    // $B@\B3$N@ZCG$r9T$J$&(B
    public void clientClose(){
	if(client != null){
	    client.close();
	    client = null;
	    thread = null;
	}
    }

    // $B%$%Y%s%H=hM}(B
    public boolean action(Event e, Object arg) {
        String label = (String)arg;
	if(label.equals("Connect")){    // $B2s@~@\B3$r<B9T(B
	    if(clientOpen()) start();
	    return true;
	}
	else if(label.equals("Close")){ // $B2s@~@ZCG$r<B9T(B
	    clientClose();
	    return true;
	}
	else if(label.equals("Quit")) { // $B%"%W%l%C%H$N=*N;(B
	    clientClose();
	    System.exit(1);
	    return true;
	}
	else if(e.target == inputArea && client != null) {
	    // $B%F%-%9%H%U%#!<%k%IFb$NJ8;zNs$r%5!<%P!<$XAw?.$9$k(B
	    client.write((String)e.arg);
	    inputArea.setText("");
	    return true;
	}
	else return false;
    }
}
