/***
        $B%f!<%6%$%s%?%U%'!<%9%7%9%F%`%5!<%P(B
        Copyright (c) 1999  Fumio Mizoguchi 
***/

import java.applet.Applet; 
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.Random;
import java.io.*;
import java.net.*;

public class Server extends Applet implements Runnable, ActionListener{
    Image map;    
    Button startb , stopb , exitb;
    int interval = 200 , increase = 0;
    int result = -1;
    boolean thread_ok = false , which = false;

//    SocketConnect sc;
    Button Ab,Bb,Cb,Db,Eb,Fb,Gb,Hb,Ib,Jb,Redb,Isb, Kb, Lb;
    Button Cancelb, Arrivalb;
    Button El,Bd,P1,P2;

    final int MAX_CHANNELS = 256; // $B:GBg%A%c%M%k?t(B
    Channel channel[] = new Channel[MAX_CHANNELS];  
    ServerSocket serversocket;    // $B@\B3<u$1IU$1MQ(BServerSocket
    int port = 17320;                     // $B%]!<%HHV9f(B
    Thread thread;

    KlicReader kr = null;
    KlicSender ks = null;
 
    public void init() {
	kr = new KlicReader(this);
	ks = new KlicSender(this);

	String at = getParameter("port");
        port = (at != null) ? Integer.valueOf(at).intValue() : 17320;

	at = getParameter("label");
        String NameLabel = (at != null) ? at : "Non Name";

        //setTitle("Roulette");
        map = getImage(getDocumentBase(),"media2.gif");
        // sc = new SocketConnect();

        setLayout( new BorderLayout() );
        startb = new Button("Connect");
        stopb = new Button("Stop");
        exitb = new Button("Exit");

        startb.addActionListener(this);
        stopb.addActionListener(this);
        exitb.addActionListener(this);

        Ab = new Button("2A");
        Bb = new Button("2B");
        Cb = new Button("2C");
        Db = new Button("2D");
        Eb = new Button("2E");
        Fb = new Button("2F");
        Gb = new Button("2G");
        Hb = new Button("2H");
        Ib = new Button("2I");
        Jb = new Button("2J");
        Kb = new Button("2K");
        Lb = new Button("2L");
        Redb = new Button("Lounge");
        Isb = new Button("Library");
        El = new Button("Elevator");
        Bd = new Button("Board");
        P1 = new Button("P1");
        P2 = new Button("P2");

        Cancelb = new Button("Cancel");
        Arrivalb = new Button("Acknowledge");

        Ab.addActionListener(this);
        Bb.addActionListener(this);
        Cb.addActionListener(this);
        Db.addActionListener(this);
        Eb.addActionListener(this);
        Fb.addActionListener(this);
        Gb.addActionListener(this);
        Hb.addActionListener(this);
        Ib.addActionListener(this);
        Jb.addActionListener(this);
        Kb.addActionListener(this);
        Lb.addActionListener(this);
        Redb.addActionListener(this);
        Isb.addActionListener(this);
        Cancelb.addActionListener(this);
        Arrivalb.addActionListener(this);
        El.addActionListener(this);
        Bd.addActionListener(this);
        P1.addActionListener(this);
        P2.addActionListener(this);

        int W = 30;
        int H = 30;

        startb.setBounds(100,100,260,80);
        Ab.setBounds(195,45,W,H);
        Bb.setBounds(195,110,W,H);
        Cb.setBounds(255,45,W,H);
        Db.setBounds(255,110,W,H);
        Eb.setBounds(353,45,W,H);
        Fb.setBounds(353,110,W,H);
        Gb.setBounds(413,45,W,H);
        Hb.setBounds(413,110,W,H);
        Ib.setBounds(515,45,W,H);
        Jb.setBounds(515,110,W,H);
        Redb.setBounds(265,260,W+30,H);
        Isb.setBounds(535,260,W+50,H);
//        startb.setBounds(170,200,330,40);
//        Cancelb.setBounds(170,200,165,40);
        Arrivalb.setBounds(250,200,165,40);

        El.setBounds(10,180,W+30,H);
        Bd.setBounds(130,320,W+30,H);
        P1.setBounds(145,45,W,H);
        P2.setBounds(590,320,W,H);
        Kb.setBounds(580,110,W,H);
        Lb.setBounds(655,110,W,H);





//        Cancelb.setVisible(false);
	Arrivalb.setVisible(false);

        add(Ab);
        add(Bb);
        add(Cb);
        add(Db);
        add(Eb);
        add(Fb);
        add(Gb);
        add(Hb);
        add(Ib);
        add(Jb);
        add(Kb);
        add(Lb);
        add(Redb);
        add(Isb);
        add(El);
        add(Bd);
        add(P1);
        add(P2);


//        add(startb);
//        add(Cancelb);
        add(Arrivalb);
//        startb.setVisible(false);

        setSize(700,360);

	Panel pp = new Panel();
	pp.add(new Label(NameLabel));
	add("North", pp);

        repaint();
    }



    public void showTwo(){
//        Cancelb.setVisible(true);
        Arrivalb.setVisible(true);
    }


    // $B%a%$%s%5!<%P!<$N@ZCG$r9T$J$&(B
    public void serverClose() {
	try {
	    System.out.println("Server#Close()");
	    serversocket.close();
	    serversocket = null;
	} catch (IOException e) {e.printStackTrace(System.err);}
    }

    // $BA4%A%c%M%k$N@ZCG$r9T$J$&(B
    public void clientClose() {
	System.out.println("Server#Close "+channel.length);
	for (int i = 0; i < channel.length; i++) {
	    System.out.println("Server#Close("+i+")");
	    channel[i].close();
	    channel[i] = null;
	}
    }
    
    public void quit() {
	clientClose();
	serverClose();
	System.exit(1);
    }
    
    public void start() {
	if (thread == null) {
	    thread = new Thread(this);
	    thread.start();
	}
    }
    
    public void stop() {
	if (thread != null) {
	    thread.stop();
	    thread = null;
	}
    }
    
    public void run() {
	int i;
	try {
	    serversocket = new ServerSocket(port);   // $B%a%$%s%5!<%P!<3+J|(B
	    while (true) {                     // $B6u$$$F$$$k%A%c%M%k$rC5$9(B
		for (i = 1; i < MAX_CHANNELS; i++) {
		    if (channel[i] == null || channel[i].thread == null) {
			break;
		    }
		}
		if (i == MAX_CHANNELS)      // $B:GBg$N%/%i%$%"%s%H?t$J$i=*N;(B
		  return;
		Socket socket = serversocket.accept();    // $B@\B3BT$A(B
		channel[i] = new Channel(socket, this, i);// $B?7%A%c%M%k:n@.(B
		System.out.println("connect "+i);
	    }
	} catch(IOException e) {
	    System.out.println("Server Err!");
	    return;
	}
    }
    
    // $BA4%A%c%M%k$X%V%m!<%I%-%c%9%H(B
    synchronized void broadcast(String message) {
	int i;
	for (i = 1; i < MAX_CHANNELS; i++) {
	    if (channel[i] != null && channel[i].socket != null) {
		channel[i].write(message);
	    }
	}
    }

    synchronized void sendMessage(int i, String message) {
        System.out.println("sendMessage "+i+" : "+message);
	if(i>0) {
	    if (channel[i] != null && channel[i].socket != null) {
		if(message.equals("imc2") || message.equals("imc3"))
		  channel[i].write2(message);
		else 
		  channel[i].write2(message+"\n");
	    }
	    else System.out.println("Client "+i+" is down !!");
	}
	else System.out.println("Own Message "+message);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == Cancelb) {
            message("st");
  //          Cancelb.setVisible(false);
   //         Arrivalb.setVisible(false);
            repaint();
        }
        if (e.getSource() == Arrivalb) {
            message("ar");
     //       Cancelb.setVisible(false);
       //     Arrivalb.setVisible(false);
            repaint();
        }
        if (e.getSource() == Ab) {
            message("go 2a");
            showTwo();
        }
        if (e.getSource() == Bb) {
            message("go 2b");
            showTwo();
        }
        if (e.getSource() == Cb) {
            message("go 2c");
            showTwo();
        }
        if (e.getSource() == Db) {
            message("go 2d");
            showTwo();
        }
        if (e.getSource() == Eb) {
            message("go 2e");
            showTwo();
        }
        if (e.getSource() == Fb) {
            message("go 2f");
            showTwo();
        }
        if (e.getSource() == Gb) {
            message("go 2g");
            showTwo();
        }
        if (e.getSource() == Hb) {
            message("go 2h");
            showTwo();
        }
        if (e.getSource() == Ib) {
            message("go 2i");
            showTwo();
        }
        if (e.getSource() == Jb) {
            message("go 2j");
            showTwo();
        }
        if (e.getSource() == Redb) {
            message("go lv");
            showTwo();
        }
        if (e.getSource() == Isb) {
            message("go li");
            showTwo();
	}
        if (e.getSource() == Kb) {
            message("go 2k");
            showTwo();
        }
        if (e.getSource() == Lb) {
            message("go 2l");
            showTwo();
        }
        if (e.getSource() == El) {
            message("go el");
            showTwo();
        }
        if (e.getSource() == Bd) {
            message("go bd");
            showTwo();
        }
        if (e.getSource() == P1) {
            message("go p1");
            showTwo();
        }
        if (e.getSource() == P2) {
            message("go p2");
            showTwo();
        }
    }

    public void message(int i, String handle){
        String message = handle + " " + i;
	ks.sendMessage(message);
    }
    public void message(String handle){
        String message = handle + " 0";
	ks.sendMessage(message);
    }

    public void update(Graphics g) {
        paint(g);
    }

    Image makeImage( ) {
        Image im = createImage(700,360);
        Graphics g = im.getGraphics();
        int width = 0, height = 0, x = 0 , y = 0;

        g.drawImage( map , 0 , 0 , this);

        return im;
    }

    public void paint(Graphics g) {
        g.drawImage( makeImage( ) , 0 , 0 , this);                         
    }
}






