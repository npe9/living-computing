/* %%%                                      %%%
 * %%%   deliv_scout.c                      %%%
 * %%%   Copyright (C) 1999 Fumio Mizoguchi %%%
 * %%%                                      %%%
 */


#include "deliv_extern.h"

int x_length = 1;
int flag = 2;
int final_trap = 0;
int center_trap = 0;
int dir_flag_r = 1;
int dir_flag_l = 1;
int nishiyama_flag = 1;
int first_trap = 1;
int count = 0;
int p_count = 0;
int left_trap = 0;
int right_trap = 0;
int trap_count = 0;
int position_trap = 0;
int s_flag = 0;
int final_count = 0;
int ctrl_mode = 0;

void scout_control(Scout_Point *scout_point, char *buff, int *v, int *t, int *dat_true, int *cx, int *cy)
{
    int center_x, center_y,red_x,red_y,blue_x, blue_y;
    int mergin = 10;
    int goal_x, goal_y;
    

    goal_x = 80;
    goal_y = 60;

    printf("scout_control function\n");

    red_x = scout_point->point[0];
    red_y = scout_point->point[1];
    blue_x = scout_point->point[2];
    blue_y = scout_point->point[3];

    x_length = sqrt(pow(red_x-blue_x,2)+pow(red_y-blue_y,2));

    fprintf(stderr,"first:%d, center:%d, final:%d, position:%d, count:%d\n",first_trap,center_trap,final_trap,position_trap, count);


    center_x = (red_x+blue_x)/2;
    center_y = (red_y+blue_y)/2;

    *cx = center_x;
    *cy = center_y;

    *dat_true = 1;

/*  $B%m%9%H$7$?$H$-(B */

    if(red_x < 0 || red_y <0 ||  blue_x <0 || blue_y <0){
	fprintf(stderr, "lost scout\n");
	*v = 0;
	*t = 0;
	*dat_true = 0;
	return;
    }

    if(first_trap > 0){
	printf("first trap\n");
	if((red_y-blue_y) > 2){
	    *v = 0;
//	    *t = (abs(red_y-blue_y)+1);
	    if((red_y-blue_y) > 10){
		*t = 30;
	    }
	    *t = 10;
	    printf("now calibration.  [turn to left]\n");
	    first_trap = 1;
	    return;
	}
	else if((blue_y-red_y) > 2){
	    *v = 0;
//	    *t = -1*(abs(red_y-blue_y)+1);
	    if((blue_y-red_y) > 10){
		*t = -30;
	    }
	    *t = -10;
	    printf("now calibration.  [turn to right]\n");
	    first_trap = 1;
	    return;
	}
	else first_trap ++;
	printf("first_trap = %d\n",first_trap);
	*v = 0;
	*t = 0;
	if(first_trap > 5){
	    first_trap = 0;

	}
	return;
    }

    if(final_trap > 0){
	printf("final trap\n");
	if((red_y - blue_y) > 2){
	    *v = 0;
	    *t = 10;
	    printf("final_trap: now calibration.  [turn left] %d\n",final_trap);
	    final_trap = 1;
	    return;
	}
	else if((blue_y-red_y) > 2){
	    *v = 0;
	    *t = -10;
	    printf("final_trap: now calibration.  [turn right] %d\n",final_trap);
	    final_trap = 1;
	    return;
	}
	else final_trap ++;
	printf("final_trap = %d\n",final_trap);
	*v = 0;
	*t = 0;
	if(final_trap > 3){
	    final_trap = 255;
	}
	return;
    }

    if((abs(80-center_x)<20) && (position_trap>0)){
	fprintf(stderr,"position_trap\n");
	if((abs(center_x-goal_x) > 3) && ((center_y-goal_y)<5)){     
	    center_trap = 1;
	    if(center_x < goal_x){
		*v = -2;
	    }
	    else *v = 2;
	    *t = 5;
	    position_trap = 1;
	    return;
	  
	}
	else position_trap++;
	fprintf(stderr,"position_count incriment\n");
	if(position_trap > 3){
	    position_trap = 0;
	    center_trap = 1;
	    *v = 0;
	    *t = 0;
	}
	*v = 0;
	*t = 0;
	return;
    }


    if((abs(80-center_x)<20) && (center_trap>0)){
	fprintf(stderr,"center_trap\n ");
	if((scout_point->point[1]-scout_point->point[3]) > 1){
	    *v = 0;
//	    *t = (abs(red_y-blue_y)+10);
	    if((red_y-blue_y) > 10){
		*t = 30;
	    }
	    *t = 5;
	    printf("center_trap. [turn to left]\n");
	    center_trap = 1;
	    return;
	}
	else if((scout_point->point[3]-scout_point->point[1]) > 1){
	    *v = 0;
//		*t = -1*(abs(red_y-blue_y)+10);
	    if((blue_y-red_y) > 10){
		*t = -30;
	    }
	    *t = -5;
	    printf("center_trap. [turn to right]\n");
	    center_trap = 1;
	    return;
	}
	else {
	    center_trap++;
	}
	*v = 0;
	*t = 0;
	if(center_trap > 4){
	    center_trap = 0;
	}
	return;
    }


    if((abs(80-center_x)<15) && center_y>55){
	fprintf(stderr,"go ahead.\n");
	*v =  (center_y-60) * 0.5;
	*t = 0;
	return;
    }

    if( (80-center_x) > 15){
	fprintf(stderr, "turn to right\n");
	position_trap = 1;
	center_trap = 2;
	*v = (center_y-60) * 0.7;
	*t = -1*abs(80-center_x)*0.5;
	if(*v == 0){
	    *t = 0;
	}
	return;
    }
    if((center_x - 80) >15){
	fprintf(stderr, "turn to left\n");
	position_trap = 1;
	center_trap = 2;
	*v = (center_y-60) * 0.7;
	*t = abs(80-center_x)*0.5;
	if(*v == 0){
	    *t = 0;
	}
	return;
    }  
    if(center_y < 60){
	printf("scout back\n");
	*v = (center_y - 60) * 0.7;
	*t = 0;
	return;
    }
    printf("scout stop.\n");
    *v =0;
    *t = 0;
    return;

}
