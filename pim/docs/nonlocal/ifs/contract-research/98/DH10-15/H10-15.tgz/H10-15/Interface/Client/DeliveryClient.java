/***
      $B%f!<%6%$%s%?%U%'!<%9%7%9%F%`%/%i%$%"%s%H(B
        $BJ8=q%G%j%P%j%5!<%S%9MW5a%"%W%l%C%H(B
        Copyright (c) 1999  Fumio Mizoguchi 
***/
import java.applet.Applet; 
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.Random;
import java.io.*;
import java.net.*;

public class DeliveryClient extends Applet implements ActionListener, Runnable {
    Thread thread = null;
    Image map;    
    String Name, roomName, Goal, Robot;
    int interval = 200 , increase = 0;
    int result = -1;
    boolean thread_ok = false , which = false;

    Client client;
    Button Ab,Bb,Cb,Db,Eb,Fb,Gb,Hb,Ib,Jb,Redb,Isb,Kb,Lb;
    Button Arrivalb;
    Button El,Bd,P1,P2;

    int port;                     // $B%]!<%HHV9f(B
    String host;

    boolean connect = false;

    Choice roomNum = new Choice();
    Label room = new Label("Room Number : ");
    Button Connectb = new Button("Connect");
    Button Quitb = new Button("Quit");
    int priInt = 2;
    int stepDeliver = -1;

    public void init() {
	String at = getParameter("port");
        port = (at != null) ? Integer.valueOf(at).intValue() : 17320;

	at = getParameter("label");
        String NameLabel = (at != null) ? at : "Non Name";

	at = getParameter("host");
        host = (at != null) ? at : "192.168.1.11";

	at = getParameter("name");
        Name = (at != null) ? at : "rob1";

        //setTitle("Roulette");
        map = getImage(getDocumentBase(),"media2.gif");

        setLayout( new BorderLayout() );


	// $B%"%W%l%C%H$N%l%$%"%&%H(B
        roomNum.addItem("2A");
        roomNum.addItem("2B");
        roomNum.addItem("2C");
        roomNum.addItem("2D");
        roomNum.addItem("2E");
        roomNum.addItem("2F");
        roomNum.addItem("2G");
        roomNum.addItem("2H");
        roomNum.addItem("2I");
        roomNum.addItem("2J");
        roomNum.addItem("Living");
        roomNum.addItem("Library");

        room.setBounds(10,10,100,30);
        roomNum.setBounds(120,10,100,30);
        Quitb.setBounds(110,50,100,30);
        Connectb.setBounds(10,50,100,30);

        add(room);
        add(roomNum);
        add(Connectb);
        add(Quitb);

        Arrivalb = new Button("Arrival");
        Ab = new Button("2A");
        Bb = new Button("2B");
        Cb = new Button("2C");
        Db = new Button("2D");
        Eb = new Button("2E");
        Fb = new Button("2F");
        Gb = new Button("2G");
        Hb = new Button("2H");
        Ib = new Button("2I");
        Jb = new Button("2J");
        Redb = new Button("Bench");
        Isb = new Button("Library");
	Kb = new Button("2K");
        Lb = new Button("2L");
	El = new Button("Lift");
        Bd = new Button("Board");
        P1 = new Button("P1");
        P2 = new Button("P2");

        Ab.addActionListener(this);
        Bb.addActionListener(this);
        Cb.addActionListener(this);
        Db.addActionListener(this);
        Eb.addActionListener(this);
        Fb.addActionListener(this);
        Gb.addActionListener(this);
        Hb.addActionListener(this);
        Ib.addActionListener(this);
        Jb.addActionListener(this);
        Redb.addActionListener(this);
        Isb.addActionListener(this);
        Arrivalb.addActionListener(this);
	Kb.addActionListener(this);
        Lb.addActionListener(this);
	El.addActionListener(this);
        Bd.addActionListener(this);
        P1.addActionListener(this);
        P2.addActionListener(this);
        Connectb.addActionListener(this);

        int W = 30;
        int H = 30;

        Ab.setBounds(195,45,W,H);
        Bb.setBounds(195,110,W,H);
        Cb.setBounds(255,45,W,H);
        Db.setBounds(255,110,W,H);
        Eb.setBounds(353,45,W,H);
        Fb.setBounds(353,110,W,H);
        Gb.setBounds(413,45,W,H);
        Hb.setBounds(413,110,W,H);
        Ib.setBounds(515,45,W,H);
        Jb.setBounds(515,110,W,H);
        Redb.setBounds(265,260,W+30,H);
        Isb.setBounds(535,260,W+50,H);
        Arrivalb.setBounds(250,200,165,40);

        El.setBounds(10,180,W+30,H);
        Bd.setBounds(130,320,W+30,H);
        P1.setBounds(145,45,W,H);
        P2.setBounds(590,319,30,30);
        Kb.setBounds(580,110,W,H);
        Lb.setBounds(655,110,W,H);


        Ab.setVisible(false);
        Bb.setVisible(false);
        Cb.setVisible(false);
        Db.setVisible(false);
        Eb.setVisible(false);
        Fb.setVisible(false);
        Gb.setVisible(false);
        Hb.setVisible(false);
        Ib.setVisible(false);
        Jb.setVisible(false);
        Redb.setVisible(false);
        Isb.setVisible(false);
        Arrivalb.setVisible(false);

        El.setVisible(false);
        Bd.setVisible(false);
        P1.setVisible(false);
        P2.setVisible(false);
        Kb.setVisible(false);
        Lb.setVisible(false);



        add(Ab);
        add(Bb);
        add(Cb);
        add(Db);
        add(Eb);
        add(Fb);
        add(Gb);
        add(Hb);
        add(Ib);
        add(Jb);
        add(Redb);
        add(Isb);
	add(Kb);
        add(Lb);
	add(El);
        add(Bd);
        add(P1);
        add(P2);
        add(Arrivalb);

        setSize(700,360);

	Panel pp = new Panel();
	pp.add(new Label(NameLabel));
	add("North", pp);

        repaint();
//	connectServer(host, port);
//	start();
//	showTwo();
    }

    public void start() {
	if(thread == null && connect){
	    thread = new Thread(this);
	    thread.start();
	}
    }

    public void stop() {
        thread = null;
    }



     // $B2s@~$N@\B3$r9T$J$&(B
    public boolean connectServer(String host, int port){
	client = new Client(host, port);  // Client$B%/%i%9$N8F$S=P$7(B
	if(client.socket == null) {       // $B@\B3<:GT!)(B
	    System.out.println("Connect Err");
	    client = null;
	    System.exit(-1);
	    return false;
	}
	else {
	    System.out.println("connect ok");
	    return true;
	}
    }

    public void run() {
        String s;
	while (thread != null) {    // $BF~NOBT$A$N%k!<%W(B 
	    s = client.read();  // $BJ8;zNsF~NO$rBT$D(B
	    if (s == null)  client.close();
                else {
                    // $BA4%/%i%$%"%s%H$K%V%m!<%I%-%c%9%H$9$k(B;
                    // server.message(handle);
                    System.out.println("MobileServer Read Message "+s);
		    
		    if(stepDeliver == 1) {
			if(checkwait(s)) stepDeliver = 2;
			else stepDeliver = -100;
		    }
		    else if(stepDeliver == 2){
			if(receivewait(s)) stepDeliver = 3;
			else stepDeliver = -100;
		    }
		    else if(stepDeliver == 3){
			if(end_push(s)) stepDeliver = 4;
			else stepDeliver = -100;
		    }
		    else if(stepDeliver == 4){
			if(deliver(s)) stepDeliver = -1;
			else stepDeliver = -100;
		    }
                }
	    if(stepDeliver < -99) System.out.println("read err");
	}
    }

    

    public boolean deliver(String s){
        String data[] = new String[20];
        String TIME, Message;  
        int num = get_data(s, data);
	if("push".equals(data[0]) && "ok".equals(data[2])) {
            Message = "put "+data[1];
            client.write(Message);          
            Message = "go "+data[1]+" "+Goal;
            client.write(Message);          
	    return true;
	}
	else return false;
    }

    public boolean end_push(String s){
        String data[] = new String[20];
        String TIME, Message;  
        int num = get_data(s, data);
	if("go".equals(data[0]) && "ok".equals(data[2])) {
            Message = "push "+data[1];
            client.write(Message);          
	    return true;
	}
	else return false;
    }



    public boolean receivewait(String s){
        String data[] = new String[20];
        int num = get_data(s, data);
	if("wait".equals(data[0])) {
	    return true;
	}
	else return false;
    }


    public boolean checkwait(String s){
        String data[] = new String[20];
        String TIME, Message;  
        TIME = "20";
        int num = get_data(s, data);

        if("go".equals(data[0])){
            Message = "wait "+data[1]+" "+TIME;
            client.write(Message);          
	    Robot = data[1];
            return true;
        }
        else return false;
    }


    public int get_data(String s, String data[]){
        int k = 0, ov=0;
        int l = 0;
        String ds;
        String str_num = "";

        try{
            for(k = ov; k<s.length(); k++){
                ds = s.substring(k,k+1);
                if (" ".equals(ds) ){
                    data[l] = str_num;
                    l++;
                    str_num = "";
                }
                else str_num = str_num + ds;
            }
        }
        catch(NumberFormatException e ){
            System.out.println("NumberFornatException !!");
            System.out.println("DATA : "+s);
            System.out.println("ov = "+ov+"  ,  "+s.length());
            System.out.println("k = "+k+"  ,  "+str_num+","+str_num.length());
            l = 0;
        }
        data[l] = str_num;
        l++;
        return l;
    }



    public void showTwo(){ 
        Arrivalb.setVisible(true);
    }

    public void deliver() {
	String Message = "go "+roomName+" "+priInt;
	System.out.println("start deliver "+Message);
	client.write(Message);          
	stepDeliver = 1;
    }





    public void actionPerformed(ActionEvent e) {
//        if (e.getSource() == Cancelb) {
//            message("st");
  //          Cancelb.setVisible(false);
   //         Arrivalb.setVisible(false);
//            repaint();
//        }
        if (e.getSource() == Arrivalb) {
            message("pick "+Name);
     //       Cancelb.setVisible(false);
       //     Arrivalb.setVisible(false);
            repaint();
        }
        if (e.getSource() == Ab && stepDeliver < 0) {
	    Goal = "2a";
	    deliver();
        }
        if (e.getSource() == Bb && stepDeliver < 0) {
	    Goal = "2b";
	    deliver();
        }
        if (e.getSource() == Cb && stepDeliver < 0) {
	    Goal = "2c";
	    deliver();
        }
        if (e.getSource() == Db && stepDeliver < 0) {
	    Goal = "2d";
	    deliver();
        }
        if (e.getSource() == Eb && stepDeliver < 0) {
	    Goal = "2e";
	    deliver();
        }
        if (e.getSource() == Fb && stepDeliver < 0) {
	    Goal = "2f";
	    deliver();
        }
        if (e.getSource() == Gb && stepDeliver < 0) {
	    Goal = "2g";
	    deliver();
        }
        if (e.getSource() == Hb && stepDeliver < 0) {
	    Goal = "2h";
	    deliver();
        }
        if (e.getSource() == Ib && stepDeliver < 0) {
	    Goal = "2i";
	    deliver();
        }
        if (e.getSource() == Jb && stepDeliver < 0) {
	    Goal = "2j";
	    deliver();
        }
        if (e.getSource() == Redb && stepDeliver < 0) {
	    Goal = "lv";
	    deliver();
        }
        if (e.getSource() == Isb && stepDeliver < 0) {
	    Goal = "li";
	    deliver();
        }

	if (e.getSource() == Kb && stepDeliver < 0) {
	    Goal = "2k";
	    deliver();
        }
        if (e.getSource() == Lb && stepDeliver < 0) {
	    Goal = "2l";
	    deliver();
        }
	if (e.getSource() == El && stepDeliver < 0) {
	    Goal = "el";
	    deliver();
        }
        if (e.getSource() == Bd && stepDeliver < 0) {
	    Goal = "bd";
	    deliver();
        }
        if (e.getSource() == P1 && stepDeliver < 0) {
	    Goal = "p1";
	    deliver();
        }
        if (e.getSource() == P2 && stepDeliver < 0) {
	    Goal = "p2";
	    deliver();
        }

	if (e.getSource() == Connectb) {
	    if(	connectServer(host, port)) {
		connect = true;
                Quitb.setVisible(false);
                Connectb.setVisible(false);
                room.setVisible(false);
                roomNum.setVisible(false);
		
		Ab.setVisible(true);
		Bb.setVisible(true);
		Cb.setVisible(true);
		Db.setVisible(true);
		Eb.setVisible(true);
		Fb.setVisible(true);
		Gb.setVisible(true);
		Hb.setVisible(true);
		Ib.setVisible(true);
		Jb.setVisible(true);
		Redb.setVisible(true);
		Isb.setVisible(true);
		Arrivalb.setVisible(true);
		El.setVisible(true);
		Bd.setVisible(true);
		P1.setVisible(true);
		P2.setVisible(true);
		Kb.setVisible(true);
		Lb.setVisible(true);
		
		String room = roomNum.getSelectedItem();
		roomName = checkRoom(room);
                repaint();
                start();
	    }
	}
    }


    public String checkRoom(String s) {
        String room = null;
        if(s.equals("2A")) room = "2a";
        else if(s.equals("2B")) room = "2b";
        else if(s.equals("2C")) room = "2c";
        else if(s.equals("2D")) room = "2d";
        else if(s.equals("2E")) room = "2e";
        else if(s.equals("2F")) room = "2f";
        else if(s.equals("2G")) room = "2g";
        else if(s.equals("2H")) room = "2h";
        else if(s.equals("2I")) room = "2i";
        else if(s.equals("2J")) room = "2j";
        else if(s.equals("Living")) room = "lv";
        else if(s.equals("Library")) room = "li";

        return room;
    }


    public void message(String handle){
	client.write(handle);
	System.out.println("send message = "+handle);
    }

    public void update(Graphics g) {
        paint(g);
    }

    Image makeImage( ) {
        Image im = createImage(700,360);
        Graphics g = im.getGraphics();
        int width = 0, height = 0, x = 0 , y = 0;

        g.drawImage( map , 0 , 0 , this);

        return im;
    }

    public void paint(Graphics g) {
	if(connect)
	  g.drawImage( makeImage( ) , 0 , 0 , this);                         
    }
}






