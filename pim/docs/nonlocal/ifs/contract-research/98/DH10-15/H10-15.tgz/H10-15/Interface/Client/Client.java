/***
      $B%f!<%6%$%s%?%U%'!<%9%7%9%F%`%/%i%$%"%s%H(B
        $B%/%i%$%"%s%H%=%1%C%HDL?.%W%m%0%i%`(B
        Copyright (c) 1999  Fumio Mizoguchi 
***/

import java.io.*;
import java.net.*;

public class Client {
    Socket socket = null;              // $B@\B3MQ(BSocket
    BufferedReader input = null;       // $BF~NOMQ%9%H%j!<%`(B
    OutputStreamWriter output = null;  // $B=PNOMQ%9%H%j!<%`(B
    Thread thread = null;

    public Client(String host, int port){
	try {
	    socket = new Socket(host, port);
	    // $B%=%1%C%H$+$iF~=PNO%9%H%j!<%`$rF@$k(B
            input = new BufferedReader(
                        new InputStreamReader(socket.getInputStream()));
            output = new OutputStreamWriter(socket.getOutputStream());
	} catch(IOException e) {
	    socket = null;
	    System.out.println("Client Err!");
        }
    }

    // $B%a%C%;!<%8Aw?.(B 
    public boolean write(String Message) {
        try {
            output.write(Message + "\r\n");
	    output.flush();
        }
        catch(Exception e) {
	    System.out.println("Miss Send");
            return false;
        }
        return true;
    }

    // $B%a%C%;!<%8<u?.(B 
    public String read() {
        String readString = null;
        try{
            readString = input.readLine();
        }
        catch(Exception e) {
            System.out.println("Can't read message !!!");
        }
        return readString;
    }

    // $B@\B3$r@ZCG$9$k(B
    public void close() {
   //     try {
            System.out.println("Client#Close()");
//             socket.close();    // $B%=%1%C%H$rJD$8$k(B
            socket = null;
     //   } catch (IOException e) {e.printStackTrace(System.err);}
    }
}
