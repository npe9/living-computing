/* %%%                                      %%%
 * %%%   Communicator.java                  %%%
 * %%%   Copyright (C) 1999 Fumio Mizoguchi %%%
 * %%%                                      %%%
 */

public class Communicator {
    SocketConnect socket;

    // $B%3%s%9%H%i%/%?!<!%(B
    public Communicator(){
    }

    public Communicator(String machine, int port){
	socket = new SocketConnect();
        socket.ClientConnect(machine, port);
    }
    
    public void Connect(String machine, int port){
	socket = new SocketConnect();
        socket.ClientConnect(machine, port);
    }
    void sendCommand(String command){
	socket.SendKLIC(command+"\0");
    }

    String readCommand(){
	return socket.ReadKLIC();
    }

    public void connectClose(){
	socket.Close();
    }
}
