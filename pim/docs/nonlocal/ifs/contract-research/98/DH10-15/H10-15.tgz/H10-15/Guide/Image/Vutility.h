/* %%%                                      %%%
 * %%%   Vutility.h                         %%%
 * %%%   Copyright (C) 1999 Fumio Mizoguchi %%%
 * %%%                                      %%%
 */

#define COLOR 0
#define GRAY  1

/*
 * $BBh0lBhFs0z?t$O(B main $B$N$b$N!%(B
 * $BBh;00z?t(B --> COLOR or GRAY $B$GI=<($r$I$A$i$K$9$k$+!%(B
 * $BBh;M0z?t(B --> 1(640*480), 2(320*240), 4(160*120) $B$G%&%$%s%I%&$NBg$-$5(B
 */
void vision_setup(int, char**, int, int);

/*
 * $BBh0l0z?t(B --> COLOR or GRAY $B$G$I$N%G!<%?$r$b$i$&$+!%(B
 * $BJV$jCM(B   --> $B<B:]$N2hA|%G!<%?(B(COLOR : GBRGBRGBR...)
 */
unsigned char *get_vision_data(int);

/*
 * $BBh0l0z?t(B --> $B=hM}8e$N2hA|%G!<%?(B
 */
void set_vision_data(unsigned char*);

