/* %%%                                      %%%
 * %%%   ControlCamera.java                 %%%
 * %%%   Copyright (C) 1999 Fumio Mizoguchi %%%
 * %%%                                      %%%
 */

public class ControlCamera {
	
    public static void main(String args[]) {
	int imageport = 10000;
	int cameraport = 19000;
	int lost_count = 0;
	if(args.length == 1){
	    imageport = Integer.parseInt(args[0]);
	}
	else if(args.length == 2){
	    imageport = Integer.parseInt(args[0]);
	    cameraport = Integer.parseInt(args[1]);
	}
	
	int center[] = new int[4];
	int x = 0, y = -3000, count = 0; 
	int limity = -1890, maxy = -3000;
	String Command;
	limity = -2150;
	
	Communicator com1 = new Communicator();
	Communicator com2 = new Communicator();
		
	com1.Connect("192.168.1.10",cameraport);
	com2.Connect("192.168.1.10",imageport);
	
	
	Command = "MV "+x+","+y;
	com1.sendCommand(Command);
	com1.readCommand();
	
	Command = "ZH";
	com1.sendCommand(Command);
	com1.readCommand();
	
	Command = "ZT";
	com1.sendCommand(Command);
	com1.readCommand();
	try{Thread.sleep(2000);}
	catch(InterruptedException e){
	    System.out.println("miss");
	}
	Command = "ZST";
	com1.sendCommand(Command);
	com1.readCommand();
	// try{Thread.sleep(2000);}
	// catch(InterruptedException e){}
	
	
	while(true) {
	    Command = "data";
	    com2.sendCommand(Command);
	    String S = com2.readCommand();
	    center = getCenter(S);
	    
	    if(center[0] > 2) {
		lost_count = 0;
		if(center[1] < 90) {
		    if(count > 0) {
			count = 0;
			if(y == limity) {}
			else {
			    y +=100;
			    if ( y>limity) {
				y=limity;
			    }
			    Command = "MV "+x+","+y;
				com1.sendCommand(Command);
			    com1.readCommand();
			}
			
			System.out.println("center[2] = "+center[2]+
					   ","+center[3]);
			if(center[2] > 30 && center[3] < 130) {
//			if(center[2] > 20 && center[3] < 140) {
			    Command = "ZT";
			    com1.sendCommand(Command);
			    com1.readCommand();
			    try{Thread.sleep(250);}
			    catch(InterruptedException e){
				System.out.println("miss");
			    }
			    Command = "ZST";
			    com1.sendCommand(Command);
			    com1.readCommand();
			}
		    } else count ++;
		}
		else {
		    count = 0;
		    try{Thread.sleep(100);}
		    catch(InterruptedException e){}
		}
	    } 
	    else {
		System.out.println("lost_count = "+lost_count);
		lost_count++;
		
		if(lost_count > 10){
		    Command = "ZW";
		    com1.sendCommand(Command);
		    com1.readCommand();
		    try{Thread.sleep(100);}
		    catch(InterruptedException e){
			System.out.println("miss");
		    }
		    Command = "ZST";
		    com1.sendCommand(Command);
		    com1.readCommand();
		}
		/*
		   if( (y == limity) || (y == maxy) ) {
		   try{Thread.sleep(100);}
		   catch(InterruptedException e){}
		   System.out.println("y = "+y);
		   }
		   */
		if(y == maxy){
		    try{Thread.sleep(100);}
		    catch(InterruptedException e){}
		    System.out.println("y = "+y);
		}
		else if(lost_count > 15){
		    y -= 50;
		    Command = "MV "+x+","+y;
		    com1.sendCommand(Command);
		    com1.readCommand();
		    try{Thread.sleep(100);}
		    catch(InterruptedException e){}	
		    lost_count = 0;
		}
	    }
	    
	}
    }	
    static int[] getCenter(String S){
	double data[] = new double[10];
	int center[] = new int[4];
	center[2] = 99999;
	center[3] = 0;
	System.out.println(S);
	get_position(S, 5, data);
	System.out.println(data[0]+","+data[1]+","+data[2]+","+data[3]);
	center[0] = (int)data[0] + (int)(data[2]-data[0])/2;
	center[1] = (int)data[1]+ (int)(data[3]-data[1])/2;
	
	if(center[0] < 0) center[0] = center[0] * -1;
	if(center[1] < 0) center[1] = center[1] * -1;
	System.out.println(center[0]+","+center[1]);
	
	for(int i=0; i<4; i++) {
	    if(center[2] > data[i]) center[2] = (int)data[i];
	    if(center[3] < data[i]) center[3] = (int)data[i];
	}
	
	return center;
    }
    
    public static boolean call_waiting(){
	SocketConnect sc = new SocketConnect();
	System.out.println("waiting print deliverly request. (port 18000)");
	if(!sc.ServerConnect(18000)){
	    System.out.println("program terminated.");
	    return(false);
	}
	return(true);
    }
	    
    public static int get_position(String s, int ov, double data[]){
        int k = 0;
        int l = 0;
        String ds;
        String str_num = "";
	
        try{
            for(k = ov; k<s.length(); k++){
                ds = s.substring(k,k+1);
                if (",".equals(ds) ){
                    data[l] = Double.valueOf(str_num).doubleValue();
                    str_num = "";
                    l++;
                }
                else if("\0".equals(ds) || ":".equals(ds))  {
                    data[l] = Double.valueOf(str_num).doubleValue();
                    str_num = "";
                    l++;
                    break;
                }
                else if( k == s.length()-1)  {
                    str_num = str_num + ds;
                    data[l] = Double.valueOf(str_num).doubleValue();
                    str_num = "";
                    l++;
                }
                else str_num = str_num + ds;
            }
        }
        catch(NumberFormatException e ){
            System.out.println("NumberFornatException !!");
            System.out.println("DATA : "+s);
            System.out.println("ov = "+ov+"  ,  "+s.length());
            System.out.println("k = "+k+"  ,  "+str_num+","+str_num.length());
            l = 0;
        }
        return(l);
    }
	
}
