/**********************************************************************/
/*                                                                    */
/*      program of VCclient.h   1996.11.28 (Thu)                      */
/*      Header File for Moving Camera (Hiraishi version)              */
/*                                                                    */
/*      Hironori Hiraishi       Last Modified: 1997.10.27(Mon)        */
/*                                                                    */
/**********************************************************************/

/*
 * Setup Moving Camera.
 * parameter : device name "/dev/ttya".
 * return    : success 1, fail 0.
 */
int VCsetup(char*);


/*
 * Move Home Position.
 * parameter : void.
 * return    : void.
 */
void VChome(void);

/*
 * Stop Moving Camera.
 * parameter : void.
 * return    : void.
 */
void VCstop(void);
void VCmove(int,int);
void VCpoint(int, int);
void VCspeed(int,int);
void VCzmove(int);
void VCzpeed(int);
void VCzstop(void);


