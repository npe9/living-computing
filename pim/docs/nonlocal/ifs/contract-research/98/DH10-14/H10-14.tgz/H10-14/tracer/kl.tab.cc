
/*  A Bison parser, made from kl.rie with Bison version GNU Bison version 1.24
  */

#define YYBISON 1  /* Identify Bison output.  */

#define	Imply	258
#define	Assign	259
#define	Mod	260
#define	Land	261
#define	Lor	262
#define	Nequal	263
#define	Integer	264
#define	Symbol	265
#define	Variable	266
#define	String	267
#define	Opt_define	268
#define	Opt_port	269
#define	Opt_size	270
#define	Opt_point	271
#define	Opt_type	272
#define	Opt_guard	273
#define	Opt_rule	274
#define	Opt_rule_id	275
#define	Opt_mesg	276
#define	Opt_atom	277
#define	Opt_merge	278
#define	Opt_from	279
#define	Opt_into	280
#define	Opt_link	281
#define	Opt_unify	282
#define	Opt_assign	283
#define	Opt_list	284
#define	Opt_proc	285
#define	Opt_begin	286
#define	Opt_proc_part	287
#define	Opt_other_part	288
#define	Opt_end	289
#define	Opt_comment	290
#define	Opt_creator	291
#define	Opt_normal	292
#define	Opt_network	293
#define	Opt_vanishing	294
#define	Opt_continuous	295
#define	Opt_transition	296
#define	Opt_stream	297
#define	Opt_single	298
#define	Opt_left	299
#define	Opt_right	300
#define	Opt_arrange	301
#define	Opt_rightward	302
#define	Opt_downward	303
#define	Opt_show_all	304
#define	Opt_pattern_top	305
#define	Opt_pattern	306
#define	Opt_layout	307
#define	Opt_modifier	308
#define	Opt_dropper	309
#define	Opt_ctime	310
#define	Opt_mtime	311
#define	Opt_dtime	312
#define	Opt_SYMBOL	313
#define	Opt_VARIABLE	314

#line 1 "kl.rie"
// -*- C++ -*-
  // Copyright (C) 1996-1999 Buntarou Shizuki(shizuki@is.titech.ac.jp)
#include "parse.h"

static char *current_module = NULL;

#ifndef YYLTYPE
typedef
  struct yyltype
    {
      int timestamp;
      int first_line;
      int first_column;
      int last_line;
      int last_column;
      char *text;
   }
  yyltype;

#define YYLTYPE yyltype
#endif

#ifndef YYSTYPE
#define YYSTYPE int
#endif
#include <stdio.h>

#ifndef __cplusplus
#ifndef __STDC__
#define const
#endif
#endif

typedef
  union
    {
      struct {
	char	state;
      } rrtr_sub_state;

      struct {
	RSUBGTYPE	g;
      } rrtr_subgoal, rrtr_subgoals;

      struct {
	RSUBGTYPE	sg;
      } rrtr_subgoal_part;

      struct {
	RCONSTYPE	tt;
	RCONSTYPE	th;
      } rrtr_list_elements, rrtr_list_contents;

      struct {
	int	num;
	RTERMTYPE	ts;
      } rrtr_args, rrtr_arg, rrtr_argument;

      struct {
	int	arity;
	NAMETYPE	name;
	NAMETYPE	module;
	RTERMTYPE	t;
      } rrtr_head, rrtr_list, rrtr_functor, rrtr_term;

      struct {
	ActType	act;
      } rrtr_action;

      struct {
	SUBPROCTYPE	sps;
	PORTTYPE	ps;
	int	num;
      } rrt_merge, rrt_assign, rrt_unify, rrt_structure, rrt_vector_elements
      , rrt_vector_contents, rrt_vector, rrt_list_elements, rrt_list_contents, rrt_list
      , rrt_arg, rrt_term_info, rrt_term_body, rrt_term, rrt_args
      , rrt_argument, rrargs, rrargument;

      struct {
	SUBPROCTYPE	sps;
	PORTTYPE	ps;
	int	arity;
	NAMETYPE	name;
	NAMETYPE	module;
      } rrt_functor, rrsubproc_infos, rrsubproc_info;

      struct {
	SUBPROCTYPE	sp;
      } rrsubproc;

      struct {
	int	arity;
	NAMETYPE	name;
      } rrfunctor, rrhead;

      struct {
	RuleType	rt;
      } rrrule_type;

      struct {
	RULETYPE	rule;
      } rrruledef;

      struct {
	ArrangeOption	option;
      } rrarrange_option;

      struct {
	ExpandMethod	arrange;
      } rrarrange_info;

      struct {
	int	h;
	int	w;
	int	t;
	int	l;
	int	lr;
	PortType	type;
	int	id;
	NAMETYPE	name;
      } rrtr_goalid, rrleft_or_right, rrport_type, rrport_info, rrpoint_size
      , rrproc_type;

      struct {
	PROCTYPE	proc;
      } rrprocdef, rrprocess;

      struct {
	NAMETYPE	str;
      } rrString;

      struct {
	NAMETYPE	name;
	NAMETYPE	module;
      } rrOpt_VARIABLE, rrOpt_SYMBOL, rrVariable, rrSymbol;

      struct {
	int	value;
      } rrInteger;

    }
  rrsastype;

typedef
  struct
    {
      PROCTYPE	EC0;
      PROCTYPE	EC1;
      PROCTYPE	EC2;
      PROCTYPE	EC3;
      PROCTYPE	EC4;
      PROCTYPE	EC5;
      PROCTYPE	EC6;
      PROCTYPE	EC7;
      RULETYPE	EC8;
      RULETYPE	EC9;
      PROCTYPE	EC10;
      RULETYPE	EC11;
      RULETYPE	EC12;
      RULETYPE	EC13;
      RULETYPE	EC14;
      RULETYPE	EC15;
      RULETYPE	EC16;
      RULETYPE	EC17;
      RULETYPE	EC18;
      RULETYPE	EC19;
      RULETYPE	EC20;
      RULETYPE	EC21;
      RULETYPE	EC22;
      RULETYPE	EC23;
      RULETYPE	EC24;
      RULETYPE	EC25;
      SUBPROCTYPE	EC26;
      SUBPROCTYPE	EC27;
      CONTEXTTYPE	EC28;
      RULETYPE	EC29;
      RULETYPE	EC30;
      RULETYPE	EC31;
      SUBPROCTYPE	EC32;
      PORTTYPE	EC33;
      int	EC34;
      RULETYPE	EC35;
      SUBPROCTYPE	EC36;
      PORTTYPE	EC37;
      int	EC38;
      RULETYPE	EC39;
      SUBPROCTYPE	EC40;
      PORTTYPE	EC41;
      int	EC42;
      RULETYPE	EC43;
      SUBPROCTYPE	EC44;
      PORTTYPE	EC45;
      int	EC46;
      RULETYPE	EC47;
      SUBPROCTYPE	EC48;
      PORTTYPE	EC49;
      int	EC50;
      RULETYPE	EC51;
      SUBPROCTYPE	EC52;
      PORTTYPE	EC53;
      int	EC54;
      RULETYPE	EC55;
      SUBPROCTYPE	EC56;
      PORTTYPE	EC57;
      int	EC58;
      RULETYPE	EC59;
      SUBPROCTYPE	EC60;
      PORTTYPE	EC61;
      int	EC62;
      RULETYPE	EC63;
      SUBPROCTYPE	EC64;
      PORTTYPE	EC65;
      int	EC66;
      RULETYPE	EC67;
      SUBPROCTYPE	EC68;
      PORTTYPE	EC69;
      int	EC70;
      RULETYPE	EC71;
      SUBPROCTYPE	EC72;
      PORTTYPE	EC73;
      int	EC74;
      RULETYPE	EC75;
      SUBPROCTYPE	EC76;
      PORTTYPE	EC77;
      int	EC78;
      RULETYPE	EC79;
      SUBPROCTYPE	EC80;
      PORTTYPE	EC81;
      int	EC82;
      RULETYPE	EC83;
      SUBPROCTYPE	EC84;
      PORTTYPE	EC85;
      int	EC86;
      RULETYPE	EC87;
      SUBPROCTYPE	EC88;
      PORTTYPE	EC89;
      int	EC90;
      RULETYPE	EC91;
      SUBPROCTYPE	EC92;
      PORTTYPE	EC93;
      int	EC94;
      RULETYPE	EC95;
      SUBPROCTYPE	EC96;
      PORTTYPE	EC97;
      int	EC98;
      RULETYPE	EC99;
      int	EC100;
      RULETYPE	EC101;
      int	EC102;
      RULETYPE	EC103;
      RTERMTYPE	EC104;
      RTERMTYPE	EC105;
      RTERMTYPE	EC106;
      NAMETYPE	EC107;
      NAMETYPE	EC108;
      NAMETYPE	EC109;
    }
  rriastype;

typedef
  struct rrlastype
    {
      union
	{
	  SUBPROCTYPE	sp_68;
	} C0;

      union
	{
	  PORTTYPE	port_128;
	} C1;

      union
	{
	  RCONSTYPE	cell_203;
	} C2;

      union
	{
	  RCONSTYPE	cell_204;
	} C3;

    }
  rrlastype;

#ifndef RIE_SOME_SYNTHESIZE
#define RIE_SOME_SYNTHESIZE
#endif

#ifndef RIE_SOME_INHERIT
#define RIE_SOME_INHERIT
#endif

#ifndef RIE_SOME_LOCAL
#define RIE_SOME_LOCAL
#endif



#define	YYFINAL		388
#define	YYFLAG		-32768
#define	YYNTBASE	80

#define YYTRANSLATE(x) ((unsigned)(x) <= 314 ? yytranslate[x] : 184)

static const char yytranslate[] = {     0,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,    79,     2,     2,     2,     2,     2,     2,    63,
    64,    75,    73,    62,    74,    60,    76,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,    77,     2,    67,
    65,    66,    78,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
    69,     2,    70,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,    71,    61,    72,    68,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     1,     2,     3,     4,     5,
     6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
    16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
    26,    27,    28,    29,    30,    31,    32,    33,    34,    35,
    36,    37,    38,    39,    40,    41,    42,    43,    44,    45,
    46,    47,    48,    49,    50,    51,    52,    53,    54,    55,
    56,    57,    58,    59
};

#if YYDEBUG != 0
static const short yyprhs[] = {     0,
     0,     2,     4,     6,     9,    11,    13,    17,    20,    29,
    36,    37,    40,    43,    44,    46,    47,    49,    51,    53,
    55,    57,    58,    67,    68,    71,    77,    78,    81,    87,
    93,    95,    98,   104,   108,   110,   112,   114,   116,   117,
   120,   122,   124,   125,   130,   132,   134,   138,   142,   144,
   145,   148,   150,   154,   160,   163,   164,   168,   171,   172,
   176,   178,   180,   182,   186,   189,   196,   200,   205,   206,
   209,   211,   216,   221,   222,   225,   227,   233,   235,   237,
   244,   248,   252,   257,   261,   265,   270,   274,   278,   282,
   284,   286,   288,   290,   292,   294,   299,   302,   305,   306,
   310,   312,   316,   318,   322,   323,   325,   329,   331,   335,
   339,   340,   342,   344,   348,   350,   353,   356,   360,   364,
   368,   370,   374,   378,   380,   382,   386,   389,   391,   392,
   394,   396,   398,   400,   402,   404,   406,   408,   413,   417,
   418,   420,   424,   426,   430,   433,   434,   438,   440,   444,
   446,   449,   453,   454,   456,   458,   462,   466,   470,   476,
   483,   494,   506,   513,   521,   528,   536,   539,   542,   545,
   548,   549,   551,   553,   556,   560,   564,   567,   572,   574,
   577,   579,   581,   583,   586,   593,   595,   597,   599,   601,
   603,   605,   607,   610,   611,   615,   617,   621,   623,   627,
   628,   630,   634,   636,   640,   641,   644,   646,   649,   655,
   661,   663
};

static const short yyrhs[] = {   159,
     0,   181,     0,   160,     0,   160,   159,     0,   161,     0,
    80,     0,     3,   162,    60,     0,    10,    10,     0,    81,
    89,    85,    87,    31,    90,    96,    34,     0,    13,    58,
    82,    83,    84,   163,     0,     0,    46,    47,     0,    46,
    48,     0,     0,    49,     0,     0,   116,     0,    36,     0,
    37,     0,    50,     0,    51,     0,     0,    36,    12,    55,
     9,    53,    12,    56,     9,     0,     0,    88,    87,     0,
    52,    12,    15,     9,     9,     0,     0,    86,    85,     0,
    14,    59,   138,   139,   116,     0,    35,    12,    16,     9,
     9,     0,    91,     0,    91,    90,     0,    92,    94,    97,
    98,    60,     0,    19,     9,    93,     0,    38,     0,    39,
     0,    40,     0,    41,     0,     0,    95,    94,     0,   116,
     0,   120,     0,     0,     3,    99,    61,   104,     0,   100,
     0,   101,     0,   101,    62,   100,     0,   114,    18,   102,
     0,   114,     0,     0,   103,   102,     0,   116,     0,   105,
   106,   108,     0,    10,    63,     9,    64,    20,     0,    32,
   107,     0,     0,    62,   111,   107,     0,    33,   109,     0,
     0,    62,   110,   109,     0,   115,     0,   136,     0,   134,
     0,   134,    27,     9,     0,   135,   164,     0,    11,    65,
    11,    26,     9,     9,     0,   120,    23,   140,     0,   120,
    30,    58,   113,     0,     0,   112,   113,     0,   116,     0,
    54,    12,    57,     9,     0,    52,    15,     9,     9,     0,
     0,   165,   164,     0,    28,     0,    10,    63,    11,    64,
    60,     0,   167,     0,   166,     0,    16,     9,     9,    15,
     9,     9,     0,   176,    65,   176,     0,   176,    66,   176,
     0,   176,    66,    65,   176,     0,   176,     8,   176,     0,
   176,     4,   176,     0,   176,    65,    67,   176,     0,   176,
    67,   176,     0,   176,     6,   176,     0,   176,     7,   176,
     0,   117,     0,   168,     0,   170,     0,   173,     0,    12,
     0,     9,     0,    68,    63,   176,    64,     0,    10,   118,
     0,    11,   118,     0,     0,    63,   119,    64,     0,   169,
     0,   169,    62,   119,     0,   167,     0,    69,   171,    70,
     0,     0,   172,     0,   172,    61,   167,     0,   167,     0,
   167,    62,   172,     0,    71,   174,    72,     0,     0,   175,
     0,   167,     0,   167,    62,   175,     0,   177,     0,    73,
   177,     0,    74,   177,     0,   176,    73,   177,     0,   176,
    74,   177,     0,   176,     5,   176,     0,   178,     0,   177,
    75,   178,     0,   177,    76,   178,     0,    11,     0,     9,
     0,    63,   176,    64,     0,   124,   125,     0,   137,     0,
     0,   179,     0,   180,     0,   127,     0,   120,     0,   133,
     0,   130,     0,    11,     0,     9,     0,    68,    63,   176,
    64,     0,    69,   128,    70,     0,     0,   129,     0,   129,
    61,   123,     0,   123,     0,   123,    62,   129,     0,    10,
   121,     0,     0,    63,   122,    64,     0,   126,     0,   126,
    62,   122,     0,   123,     0,    11,   121,     0,    71,   131,
    72,     0,     0,   132,     0,   123,     0,   123,    62,   132,
     0,   123,    65,   123,     0,    11,     4,   176,     0,    14,
    59,     9,   138,   139,     0,    14,    59,     9,   138,   139,
   116,     0,    14,    59,     9,   138,   139,    14,    59,   138,
   139,   116,     0,    14,    59,     9,   138,   139,    14,    59,
     9,   138,   139,   116,     0,   179,    14,    59,   138,   139,
   116,     0,   179,    14,    59,     9,   138,   139,   116,     0,
   180,    14,    59,   138,   139,   116,     0,   180,    14,    59,
     9,   138,   139,   116,     0,    73,    43,     0,    74,    43,
     0,    73,    42,     0,    74,    42,     0,     0,    44,     0,
    45,     0,    22,    12,     0,    22,    12,   116,     0,    21,
    58,   116,     0,    21,    58,     0,    25,     9,    24,   141,
     0,   142,     0,   142,   141,     0,     9,     0,   182,     0,
   183,     0,   183,   182,     0,   143,   144,    77,   153,   154,
    78,     0,   146,     0,     9,     0,    11,     0,   146,     0,
    11,     0,     9,     0,   150,     0,    10,   147,     0,     0,
    63,   149,    64,     0,   148,     0,   148,    62,   149,     0,
   145,     0,    69,   151,    70,     0,     0,   152,     0,   152,
    61,   145,     0,   145,     0,   145,    62,   152,     0,     0,
     3,   155,     0,   156,     0,   156,   155,     0,   143,     9,
    77,   157,   145,     0,   143,     9,    79,   157,   145,     0,
    73,     0,    74,     0
};

#endif

#if YYDEBUG != 0
static const short yyrline[] = { 0,
   165,   166,   171,   172,   174,   175,   181,   183,   198,   206,
   214,   216,   218,   221,   223,   226,   227,   229,   231,   233,
   235,   238,   241,   252,   253,   256,   261,   262,   266,   279,
   284,   286,   289,   295,   299,   301,   303,   305,   309,   310,
   313,   319,   328,   329,   332,   335,   337,   340,   343,   347,
   348,   351,   356,   359,   362,   365,   366,   369,   372,   373,
   376,   378,   383,   388,   396,   405,   409,   417,   434,   436,
   439,   448,   452,   458,   459,   461,   463,   465,   466,   473,
   479,   480,   481,   484,   485,   486,   487,   488,   489,   491,
   492,   493,   494,   495,   496,   497,   499,   503,   505,   507,
   510,   512,   515,   517,   519,   520,   521,   523,   524,   526,
   528,   529,   531,   532,   534,   535,   536,   537,   538,   539,
   541,   542,   543,   545,   546,   547,   550,   554,   570,   572,
   574,   577,   581,   585,   589,   593,   595,   597,   600,   605,
   607,   611,   617,   621,   627,   635,   638,   644,   649,   656,
   682,   687,   692,   694,   699,   703,   709,   715,   723,   732,
   741,   751,   761,   770,   779,   789,   846,   848,   850,   852,
   855,   857,   859,   862,   863,   865,   866,   868,   872,   874,
   877,   885,   889,   890,   892,   907,   911,   916,   920,   924,
   926,   929,   932,   942,   945,   949,   952,   956,   960,   963,
   966,   970,   975,   979,   984,   986,   990,   993,  1001,  1011,
  1022,  1024
};

static const char * const yytname[] = {   "$","error","$undefined.","Imply",
"Assign","Mod","Land","Lor","Nequal","Integer","Symbol","Variable","String",
"Opt_define","Opt_port","Opt_size","Opt_point","Opt_type","Opt_guard","Opt_rule",
"Opt_rule_id","Opt_mesg","Opt_atom","Opt_merge","Opt_from","Opt_into","Opt_link",
"Opt_unify","Opt_assign","Opt_list","Opt_proc","Opt_begin","Opt_proc_part","Opt_other_part",
"Opt_end","Opt_comment","Opt_creator","Opt_normal","Opt_network","Opt_vanishing",
"Opt_continuous","Opt_transition","Opt_stream","Opt_single","Opt_left","Opt_right",
"Opt_arrange","Opt_rightward","Opt_downward","Opt_show_all","Opt_pattern_top",
"Opt_pattern","Opt_layout","Opt_modifier","Opt_dropper","Opt_ctime","Opt_mtime",
"Opt_dtime","Opt_SYMBOL","Opt_VARIABLE","'.'","'|'","','","'('","')'","'='",
"'>'","'<'","'~'","'['","']'","'{'","'}'","'+'","'-'","'*'","'/'","':'","'?'",
"'!'","process","procdef","proc_type","arrange_info","arrange_option","proc_infos",
"proc_info","layout_infos","layout_info","user_info","clauses","clause","ruledef",
"rule_type","rule_infos","rule_info","rule_clause","head","tail","guard","guard_goals",
"guard_goal","guard_infos","guard_info","body","rule_id","subproc_part","subprocs",
"other_part","other_bodies","other_body","subproc","subproc_info","subproc_infos",
"goal","link","point_size","functor","argument","args","t_functor","t_argument",
"t_args","t_term","t_term_body","t_term_info","t_arg","t_list","t_list_contents",
"t_list_elements","t_vector","t_vector_contents","t_vector_elements","t_structure",
"t_unify","t_assign","t_merge","port_info","port_type","left_or_right","merge_info",
"merge_froms","merge_from","tr_goalid","tr_action","tr_term","tr_functor","tr_argument",
"tr_arg","tr_args","tr_list","tr_list_contents","tr_list_elements","tr_head",
"tr_subgoal_part","tr_subgoals","tr_subgoal","tr_sub_state","S","definitions",
"definition","declaration","decl_body","procdef_point_size","assign_infos","assign_info",
"relation","term","structure","arg","list","list_contents","list_elements","vector",
"vector_contents","vector_elements","exp","e_term","e_factor","atom_info","mesg_info",
"tracer","tr_lines","tr_line",""
};
#endif

static const short yyr1[] = {     0,
   158,   158,   159,   159,   160,   160,   161,   162,    80,    81,
    83,    83,    83,    84,    84,   163,   163,    82,    82,    82,
    82,    89,    89,    87,    87,    88,    85,    85,    86,    86,
    90,    90,    91,    92,    93,    93,    93,    93,    94,    94,
    95,    97,    98,    98,    99,   100,   100,   101,   101,   102,
   102,   103,   104,   105,   106,   107,   107,   108,   109,   109,
   110,   110,   110,   110,   110,   115,   136,   111,   113,   113,
   112,   112,   112,   164,   164,   165,    96,   114,   114,   116,
   166,   166,   166,   166,   166,   166,   166,   166,   166,   167,
   167,   167,   167,   167,   167,   167,   117,   168,   118,   118,
   119,   119,   169,   170,   171,   171,   171,   172,   172,   173,
   174,   174,   175,   175,   176,   176,   176,   176,   176,   176,
   177,   177,   177,   178,   178,   178,   123,   125,   125,   125,
   125,   124,   124,   124,   124,   124,   124,   124,   127,   128,
   128,   128,   129,   129,   120,   121,   121,   122,   122,   126,
   133,   130,   131,   131,   132,   132,   134,   135,   137,   137,
   137,   137,   137,   137,   137,   137,   138,   138,   138,   138,
   139,   139,   139,   179,   179,   180,   180,   140,   141,   141,
   142,   181,   182,   182,   183,   153,   143,   144,   145,   145,
   145,   145,   146,   147,   147,   149,   149,   148,   150,   151,
   151,   151,   152,   152,   154,   154,   155,   155,   156,   156,
   157,   157
};

static const short yyr2[] = {     0,
     1,     1,     1,     2,     1,     1,     3,     2,     8,     6,
     0,     2,     2,     0,     1,     0,     1,     1,     1,     1,
     1,     0,     8,     0,     2,     5,     0,     2,     5,     5,
     1,     2,     5,     3,     1,     1,     1,     1,     0,     2,
     1,     1,     0,     4,     1,     1,     3,     3,     1,     0,
     2,     1,     3,     5,     2,     0,     3,     2,     0,     3,
     1,     1,     1,     3,     2,     6,     3,     4,     0,     2,
     1,     4,     4,     0,     2,     1,     5,     1,     1,     6,
     3,     3,     4,     3,     3,     4,     3,     3,     3,     1,
     1,     1,     1,     1,     1,     4,     2,     2,     0,     3,
     1,     3,     1,     3,     0,     1,     3,     1,     3,     3,
     0,     1,     1,     3,     1,     2,     2,     3,     3,     3,
     1,     3,     3,     1,     1,     3,     2,     1,     0,     1,
     1,     1,     1,     1,     1,     1,     1,     4,     3,     0,
     1,     3,     1,     3,     2,     0,     3,     1,     3,     1,
     2,     3,     0,     1,     1,     3,     3,     3,     5,     6,
    10,    11,     6,     7,     6,     7,     2,     2,     2,     2,
     0,     1,     1,     2,     3,     3,     2,     4,     1,     2,
     1,     1,     1,     2,     6,     1,     1,     1,     1,     1,
     1,     1,     2,     0,     3,     1,     3,     1,     3,     0,
     1,     3,     1,     3,     0,     2,     1,     2,     5,     5,
     1,     1
};

static const short yydefact[] = {     0,
     0,   187,     0,     6,    22,     0,     1,     3,     5,     2,
   182,   183,     0,     0,     0,     0,    27,   188,     0,     4,
   184,     8,     7,    18,    19,    20,    21,    11,     0,     0,
     0,    24,    27,     0,     0,    14,     0,     0,     0,     0,
     0,    24,    28,   194,   186,   205,    12,    13,    15,    16,
     0,     0,     0,   171,     0,     0,     0,    25,     0,   193,
     0,     0,     0,    17,    10,     0,   169,   167,   170,   168,
   172,   173,     0,     0,     0,     0,     0,    31,    39,   191,
   190,   200,   198,   189,   196,     0,   192,     0,   206,   207,
   185,     0,     0,    29,    30,     0,     0,     0,     0,    32,
     0,    39,    41,   203,     0,   201,     0,   195,     0,   208,
     0,     0,    26,    35,    36,    37,    38,    34,     0,     9,
   146,    43,    42,    40,     0,   199,     0,   197,     0,     0,
     0,    23,     0,     0,   145,     0,     0,   204,   202,   211,
   212,     0,     0,     0,     0,   137,   136,     0,   140,   153,
   133,     0,   150,   129,   148,   132,   135,   134,   125,    99,
   124,    94,     0,     0,   105,   111,     0,     0,     0,    45,
    46,    49,    90,    79,    78,    91,    92,    93,     0,   115,
   121,    33,   209,   210,    80,    77,   151,     0,   143,     0,
   141,   155,     0,   154,   147,     0,     0,     0,   127,   128,
   130,   131,     0,     0,    97,    98,   125,   124,     0,     0,
    95,    99,   108,     0,   106,   113,     0,   112,   116,   117,
     0,     0,    50,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,   139,     0,     0,
   152,     0,   177,   174,     0,     0,   149,     0,   103,   101,
   126,     0,     0,   104,     0,     0,   110,     0,    44,     0,
    47,    48,    50,    52,    85,   120,    88,    89,    84,     0,
    81,     0,    82,    87,   118,   119,   122,   123,   138,   144,
   142,   156,     0,   176,   175,     0,     0,   100,     0,    96,
   109,   107,   114,     0,    56,     0,    51,    86,    83,   171,
     0,   171,     0,   171,   102,     0,     0,    55,    59,    53,
   159,   171,     0,   171,     0,     0,    56,     0,     0,    58,
     0,   160,     0,   163,     0,   165,    54,    57,     0,   136,
    59,    61,   133,     0,    63,    74,    62,     0,   164,   166,
    69,     0,     0,    60,     0,     0,     0,    76,    65,    74,
     0,   171,     0,     0,    69,    68,    71,   158,     0,     0,
    67,   157,    64,    75,   171,     0,     0,     0,    70,     0,
     0,     0,   161,     0,     0,     0,     0,   162,    73,    72,
    66,   181,   178,   179,   180,     0,     0,     0
};

static const short yydefgoto[] = {     4,
     5,    28,    36,    50,    32,    33,    41,    42,    17,    77,
    78,    79,   118,   101,   102,    99,   122,   137,   169,   170,
   171,   262,   263,   259,   260,   296,   308,   310,   320,   331,
   317,   355,   356,   172,   332,   103,   173,   206,   248,   151,
   187,   152,   153,   154,   199,   155,   156,   190,   191,   157,
   193,   194,   158,   335,   336,   337,   200,    54,    73,   361,
   383,   384,     6,    19,    83,    84,    60,    85,    86,    87,
   105,   106,    46,    62,    89,    90,   142,   386,     7,     8,
     9,    14,    65,   349,   350,   174,   175,   176,   250,   177,
   214,   215,   178,   217,   218,   179,   180,   181,   201,   202,
    10,    11,    12
};

static const short yypact[] = {    50,
    18,-32768,   -22,-32768,     5,    88,-32768,     7,-32768,-32768,
-32768,    52,   125,    62,   126,   128,    -5,-32768,    80,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,   115,   114,   120,
   162,   132,    -5,   179,   -26,   142,   188,    92,   190,   192,
   183,   132,-32768,   157,-32768,   218,-32768,-32768,-32768,   206,
   170,   139,   158,   165,   215,   210,   207,-32768,   123,-32768,
    52,   149,   219,-32768,-32768,   217,-32768,-32768,-32768,-32768,
-32768,-32768,   206,   221,   222,   223,   224,   207,   206,-32768,
-32768,   123,-32768,-32768,   171,   172,-32768,   226,-32768,    52,
-32768,   228,   182,-32768,-32768,   230,   -14,   177,   208,-32768,
   231,   206,-32768,   181,   174,   184,   123,-32768,    33,-32768,
   232,   237,-32768,-32768,-32768,-32768,-32768,-32768,   238,-32768,
   185,   247,-32768,-32768,   123,-32768,   123,-32768,   138,   138,
   242,-32768,   189,   119,-32768,    46,   194,-32768,-32768,-32768,
-32768,   123,   123,   243,   195,-32768,   185,   193,   119,   119,
-32768,   196,-32768,   137,   197,-32768,-32768,-32768,    85,   199,
   -13,-32768,   112,   201,   127,   127,   145,   145,   205,-32768,
   209,   239,-32768,-32768,-32768,-32768,-32768,-32768,     8,   140,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,   112,   212,   198,
   211,   214,   186,-32768,-32768,   220,   225,   255,-32768,-32768,
   256,   263,   119,   127,-32768,-32768,-32768,-32768,    12,   112,
-32768,   199,   216,   227,   229,   233,   213,-32768,   140,   140,
   259,    46,   206,   112,   112,   112,   112,   112,    97,    53,
   112,   145,   145,   145,   145,    14,   119,-32768,   119,   119,
-32768,   271,   206,   206,   234,   235,-32768,   236,-32768,   240,
-32768,    27,   127,-32768,   127,   127,-32768,   241,-32768,   249,
-32768,-32768,   206,-32768,     6,     6,     6,     6,     6,   112,
     6,   112,     6,     6,   140,   140,-32768,-32768,-32768,-32768,
-32768,-32768,    92,-32768,-32768,    51,    68,-32768,   127,-32768,
-32768,-32768,-32768,   273,   244,   251,-32768,     6,     6,   165,
    92,   165,    92,   165,-32768,   245,   231,-32768,   246,-32768,
   164,   165,   206,   165,   206,   266,   244,   257,   134,-32768,
   248,-32768,   206,-32768,   206,-32768,-32768,-32768,   252,    90,
   246,-32768,   265,   250,   262,   264,-32768,    75,-32768,-32768,
   -10,   112,   285,-32768,   274,   119,   289,-32768,-32768,   264,
    92,   165,   286,   291,   -10,-32768,-32768,     6,   287,   302,
-32768,-32768,-32768,-32768,   165,   206,   303,   260,-32768,   305,
   294,   206,-32768,   310,   311,   312,   314,-32768,-32768,-32768,
-32768,-32768,-32768,   314,-32768,   324,   325,-32768
};

static const short yypgoto[] = {-32768,
-32768,-32768,-32768,-32768,   293,-32768,   288,-32768,-32768,   253,
-32768,-32768,-32768,   254,-32768,-32768,-32768,-32768,-32768,   105,
-32768,    65,-32768,-32768,-32768,-32768,    15,-32768,    -2,-32768,
-32768,-32768,   -21,-32768,-32768,   -50,-32768,   173,    47,  -100,
   258,   135,  -147,-32768,-32768,-32768,-32768,-32768,    98,-32768,
-32768,    99,-32768,-32768,-32768,-32768,-32768,  -249,  -269,-32768,
   -47,-32768,   -43,-32768,    25,   306,-32768,-32768,   261,-32768,
-32768,   267,-32768,-32768,   268,-32768,   269,-32768,   333,-32768,
-32768,-32768,-32768,    -8,-32768,-32768,  -158,-32768,-32768,-32768,
-32768,    91,-32768,-32768,    87,  -159,  -128,   -17,-32768,-32768,
-32768,   334,-32768
};


#define	YYLAST		399


static const short yytable[] = {    64,
   123,   189,   192,   209,   -99,    63,   213,   216,    30,     1,
   225,   224,   225,   226,   227,   228,   225,    88,   225,     3,
    47,    48,    94,   114,   115,   116,   117,    13,   236,    31,
   311,   225,   313,   300,   315,    15,   302,   304,   219,   220,
    16,   353,   323,   354,   325,   249,    88,   -99,   -99,   204,
   252,   312,     1,   314,   159,   160,   161,   162,     2,   301,
     2,   207,     3,   208,   265,   266,   267,   268,   269,   271,
   273,   274,   229,   230,   231,   251,   303,   279,   232,   233,
   232,   233,   366,   351,   232,   233,   232,   233,   352,   189,
   290,   281,   192,   342,   213,   372,   292,   216,    18,   232,
   233,   365,   -95,   275,   276,   207,   104,   208,   163,   129,
   298,   130,   299,   164,   165,   163,   166,   272,   167,   168,
   207,    23,   208,    52,    53,   167,   168,   146,   121,   147,
   249,    80,    44,    81,    22,   211,   160,   212,   162,    29,
    52,    53,   146,   121,   330,   -95,   -95,    52,    53,   104,
   196,   139,   134,   207,   343,   208,    34,   197,   198,   163,
    35,    24,    25,   270,    52,    53,   183,   184,    37,   167,
   168,   334,   264,    39,   163,    26,    27,   321,    38,    63,
    67,    68,   358,    40,   167,   168,   148,   149,    44,   150,
    49,    82,   284,   285,   164,   165,    51,   166,   362,    69,
    70,   148,   149,    56,   150,    55,   318,   163,    71,    72,
   140,   141,   264,    57,   234,   235,   277,   278,   333,    59,
    61,    63,    66,    74,    75,    76,    91,    92,    93,    95,
    96,    97,   107,    98,   109,   108,   111,   112,   113,   119,
   121,   120,   125,   126,   127,   132,   131,   134,   133,   136,
   144,   185,   145,   182,   186,   188,   223,   241,   203,   195,
   322,   204,   324,   210,   326,   221,   244,   238,   258,   245,
   222,   239,   339,   237,   340,   240,   246,   253,   242,   283,
   295,   306,   243,   309,   257,   327,   329,   345,   347,   255,
   357,   348,   286,   287,   256,   359,   254,   363,   360,   288,
   367,   289,   368,   294,   357,   307,   338,   319,   316,   341,
   371,   374,   370,   376,   346,   373,   375,   377,   379,   380,
   381,   378,   382,   387,   388,    43,   261,   297,   344,    58,
   100,   328,   205,   369,   280,   305,   385,   247,   282,    45,
    20,   364,   293,   291,     0,    21,     0,     0,     0,     0,
     0,     0,     0,     0,     0,   124,     0,   110,     0,     0,
     0,     0,     0,     0,     0,     0,     0,   128,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,   135,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,   138,     0,     0,     0,     0,     0,     0,   143
};

static const short yycheck[] = {    50,
   101,   149,   150,   163,    18,    16,   165,   166,    14,     3,
     5,     4,     5,     6,     7,     8,     5,    61,     5,    13,
    47,    48,    73,    38,    39,    40,    41,    10,   188,    35,
   300,     5,   302,   283,   304,    58,   286,   287,   167,   168,
    36,    52,   312,    54,   314,   204,    90,    61,    62,    63,
   210,   301,     3,   303,     9,    10,    11,    12,     9,     9,
     9,     9,    13,    11,   224,   225,   226,   227,   228,   229,
   230,   231,    65,    66,    67,    64,     9,    64,    73,    74,
    73,    74,   352,     9,    73,    74,    73,    74,   338,   237,
    64,   239,   240,     4,   253,   365,   255,   256,    11,    73,
    74,   351,    18,   232,   233,     9,    82,    11,    63,    77,
   270,    79,   272,    68,    69,    63,    71,    65,    73,    74,
     9,    60,    11,    73,    74,    73,    74,     9,    10,    11,
   289,     9,    10,    11,    10,     9,    10,    11,    12,    12,
    73,    74,     9,    10,    11,    61,    62,    73,    74,   125,
    14,   127,    63,     9,    65,    11,    77,    21,    22,    63,
    46,    36,    37,    67,    73,    74,   142,   143,    55,    73,
    74,   319,   223,    12,    63,    50,    51,    14,    59,    16,
    42,    43,   342,    52,    73,    74,    68,    69,    10,    71,
    49,    69,   243,   244,    68,    69,     9,    71,   346,    42,
    43,    68,    69,    12,    71,    16,   307,    63,    44,    45,
    73,    74,   263,    31,    75,    76,   234,   235,   319,    63,
     3,    16,    53,     9,    15,    19,    78,     9,    12,     9,
     9,     9,    62,    10,     9,    64,     9,    56,     9,    63,
    10,    34,    62,    70,    61,     9,    15,    63,    11,     3,
     9,     9,    64,    60,    60,    63,    18,    72,    62,    64,
   311,    63,   313,    63,   315,    61,    12,    70,    10,    14,
    62,    61,   323,    62,   325,    62,    14,    62,    59,     9,
    32,     9,    58,    33,    72,    20,    30,    23,    27,    61,
   341,    28,    59,    59,    62,    11,    70,     9,    25,    64,
    15,    62,    12,    63,   355,    62,    59,    62,    64,    58,
     9,     9,    26,     9,    65,   366,    57,    24,     9,     9,
     9,   372,     9,     0,     0,    33,   222,   263,   331,    42,
    78,   317,   160,   355,   237,   289,   384,   203,   240,    34,
     8,   350,   256,   253,    -1,    12,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,   102,    -1,    90,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,   107,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   121,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,   125,    -1,    -1,    -1,    -1,    -1,    -1,   130
};
/* -*-C-*-  Note some compilers choke on comments on `#line' lines.  */
#line 3 "bison.simple"
#line 4 "/usr/local/lib/rie-1.0.6/rie.simple"

/* Skeleton output parser for Rie,
   Copyright (C) 1991-1993 Masataka Sassa, Kazuhiro Kuroishi, Teruhisa Hirai.

This file is part of Rie, A Compiler Compiler Based on ECLR-attributed Grammar.

This file is made with modifying "bison.simple", Bison skeleton parser.
Copyright of "bison.simple" is described below.  */

/* Skeleton output parser for bison,
   Copyright (C) 1984, 1989, 1990 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

#ifndef alloca
#ifdef __GNUC__
#define alloca __builtin_alloca
#else /* not GNU C.  */
#if (!defined (__STDC__) && defined (sparc)) || defined (__sparc__) || defined (__sparc) || defined (__sgi)
#include <alloca.h>
#else /* not sparc */
#if defined (MSDOS) && !defined (__TURBOC__)
#include <malloc.h>
#else /* not MSDOS, or __TURBOC__ */
#if defined(_AIX)
#include <malloc.h>
 #pragma alloca
#else /* not MSDOS, __TURBOC__, or _AIX */
#ifdef __hpux
#ifdef __cplusplus
extern "C" {
void *alloca (unsigned int);
};
#else /* not __cplusplus */
void *alloca ();
#endif /* not __cplusplus */
#endif /* __hpux */
#endif /* not _AIX */
#endif /* not MSDOS, or __TURBOC__ */
#endif /* not sparc.  */
#endif /* not GNU C.  */
#endif /* alloca not defined.  */

/* This is the parser code that is written into each bison parser
  when the %semantic_parser declaration is not specified in the grammar.
  It was written by Richard Stallman by simplifying the hairy parser
  used when %semantic_parser is specified.  */

/* Note: there must be only one dollar sign in this file.
   It is replaced by the list of actions, each action
   as one case of the switch.  */

/* But Rie has three dollar signs.
   The first is for inherited attribute evaluation. 
   The second is for synthesized evaluation.
   And the third is for debugging action and messages.  */

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		-2
#define YYEOF		0
#define YYACCEPT	return(0)
#define YYABORT 	return(1)
#define YYERROR		goto yyerrlab1
/* Like YYERROR except do call yyerror.
   This remains here temporarily to ease the
   transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */
#define YYFAIL		goto yyerrlab
#define YYRECOVERING()  (!!yyerrstatus)
#define YYBACKUP(token, value) \
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    { yychar = (token), yylval = (value);			\
      yychar1 = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { yyerror ("syntax error: cannot back up"); YYERROR; }	\
while (0)

#define YYTERROR	1
#define YYERRCODE	256

#ifndef YYPURE
#define YYLEX		yylex()
#endif

#ifdef YYPURE
#ifdef YYLSP_NEEDED
#ifdef YYLEX_PARAM
#define YYLEX		yylex(&yylval, &yylloc, YYLEX_PARAM)
#else
#define YYLEX		yylex(&yylval, &yylloc)
#endif
#else /* not YYLSP_NEEDED */
#ifdef YYLEX_PARAM
#define YYLEX		yylex(&yylval, YYLEX_PARAM)
#else
#define YYLEX		yylex(&yylval)
#endif
#endif /* not YYLSP_NEEDED */
#endif

/* If nonreentrant, generate the variables here */

#ifndef YYPURE

#ifdef RIE_SOME_SYNTHESIZE
rrsastype rrlval;		/* synthesized attribute returnd by	*/
				/* lexical analyzer. 			*/
#endif

int	yychar;			/*  the lookahead symbol		*/
YYSTYPE	yylval;			/*  the semantic value of the		*/
				/*  lookahead symbol			*/

#ifdef YYLSP_NEEDED
YYLTYPE yylloc;			/*  location data for the lookahead	*/
				/*  symbol				*/
#endif

int yynerrs;			/*  number of parse errors so far       */
#endif  /* not YYPURE */

#if YYDEBUG != 0
int yydebug;			/*  nonzero means print parse trace	*/
/* Since this is uninitialized, it does not stop multiple parsers
   from coexisting.  */
#endif

#if RRDEBUG != 0
int rrdebug;			/*  nonzero means eval debug action	*/
#endif

FILE *rrmessage = stderr;	/* the stream %message write out to	*/

/*  YYINITDEPTH indicates the initial size of the parser's stacks	*/

#ifndef	YYINITDEPTH
#define YYINITDEPTH 200
#endif

/*  YYMAXDEPTH is the maximum size the stacks can grow to
    (effective only if the built-in stack extension method is used).  */

#if YYMAXDEPTH == 0
#undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
#define YYMAXDEPTH 10000
#endif

/* Prevent warning if -Wstrict-prototypes.  */
#ifdef __GNUC__
int yyparse (void);
#endif

/* convenience function  */
void
#ifdef __cplusplus
rroption(int ac, char *av[])
#else
rroption(ac, av)
  int ac;
  char *av[];
#endif
{
  register char c;

  while(--ac > 0 && (*++av)[0] == '-')
    {
      c = *++av[0];
      switch(c)
	{
	case 'y':
	case 'Y':
#if YYDEBUG != 0
	  yydebug = 1;
	  fprintf(rrmessage, "Trace Facility ON\n");
#endif
	  break;

	case 'r':
	case 'R':
#if RRDEBUG != 0
	  rrdebug = 1;
	  fprintf(rrmessage, "Debug Action Facility ON\n");
#endif
	  break;

        default:
	  break;
	}
    }
}

#if __GNUC__ > 1		/* GNU C and GNU C++ define this.  */
#define __yy_memcpy(FROM,TO,COUNT)	__builtin_memcpy(TO,FROM,COUNT)
#else				/* not GNU C or C++ */
#ifndef __cplusplus

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_memcpy (from, to, count)
     char *from;
     char *to;
     int count;
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#else /* __cplusplus */

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_memcpy (char *from, char *to, int count)
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#endif
#endif

#line 260 "bison.simple"
#line 261 "/usr/local/lib/rie-1.0.6/rie.simple"

/* The user can define YYPARSE_PARAM as the name of an argument to be passed
   into yyparse.  The argument should have type void *.
   It should actually point to an object.
   Grammar actions can access the variable by casting it
   to the proper pointer type.  */

#ifdef YYPARSE_PARAM
#define YYPARSE_PARAM_DECL void *YYPARSE_PARAM;
#else
#define YYPARSE_PARAM
#define YYPARSE_PARAM_DECL
#endif

int
yyparse(YYPARSE_PARAM)
     YYPARSE_PARAM_DECL
{
  register int yystate;
  register int yyn;
  register short *yyssp;
#ifdef NOT_RIE
  register YYSTYPE *yyvsp;
#endif
#ifdef RIE_SOME_SYNTHESIZE
  register rrsastype *rrsasp;
#endif

#ifdef RIE_SOME_INHERIT
  register rriastype *rriasp;
#endif

#ifdef RIE_SOME_LOCAL
  register rrlastype *rrlasp;
#endif
  
  int yyerrstatus;	/*  number of tokens to shift before error messages enabled */
  int yychar1 = 0;		/*  lookahead token as an internal (translated) token number */

  short	yyssa[YYINITDEPTH];	/*  the state stack			*/
#ifdef NOT_RIE
  YYSTYPE yyvsa[YYINITDEPTH];	/*  the semantic value stack		*/
#endif

#ifdef RIE_SOME_SYNTHESIZE
  rrsastype rrsas[YYINITDEPTH];	/*  the sythesized attribute statck	*/
#endif

#ifdef RIE_SOME_INHERIT
  rriastype rrias[YYINITDEPTH];	/*  the inherited attribute stack	*/
#endif

#ifdef RIE_SOME_LOCAL
  rrlastype rrlas[YYINITDEPTH];	/*  the local attribute stack		*/
#endif
  
  short *yyss = yyssa;		/*  refer to the stacks thru separate pointers */
#ifdef NOT_RIE
  YYSTYPE *yyvs = yyvsa;	/*  to allow yyoverflow to reallocate them elsewhere */
#endif
#ifdef RIE_SOME_SYNTHESIZE
  rrsastype *rrss = rrsas;
#endif

#ifdef RIE_SOME_INHERIT
  rriastype *rris = rrias;
#endif

#ifdef RIE_SOME_LOCAL
  rrlastype *rrls = rrlas;
#endif

#ifdef YYLSP_NEEDED
  YYLTYPE yylsa[YYINITDEPTH];	/*  the location stack			*/
  YYLTYPE *yyls = yylsa;
  YYLTYPE *yylsp;

#define YYPOPSTACK   (yyvsp--, yyssp--, yylsp--)
#else
#define YYPOPSTACK   (yyvsp--, yyssp--)
#endif

  int yystacksize = YYINITDEPTH;

#ifdef YYPURE
  int yychar;
#ifdef NOT_RIE
  YYSTYPE yylval;
#endif
  int yynerrs;
#ifdef RIE_SOME_SYNTHESIZE
  rrsastype rrlval;
#endif
#ifdef YYLSP_NEEDED
  YYLTYPE yylloc;
#endif
#endif

#ifdef RIE_SOME_SYNTHESIZE
  rrsastype rrval;	/* assigned temprally at synthesized attribute
			   evaluation time.  */
#endif
#ifdef NOT_RIE
  YYSTYPE yyval;		/*  the variable used to return		*/
				/*  semantic values from the action	*/
				/*  routines				*/

#endif
  int yylen;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Starting parse\n");
#endif

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss - 1;
#ifdef NOT_RIE
  yyvsp = yyvs;
#endif
#ifdef RIE_SOME_SYNTHESIZE
  rrsasp = rrss;
#endif

#ifdef RIE_SOME_INHERIT
  rriasp = rris - 1;
#endif

#ifdef RIE_SOME_LOCAL
  rrlasp = rrls - 1;
#endif

#ifdef YYLSP_NEEDED
  yylsp = yyls;
#endif

/* Push a new state, which is found in  yystate  .  */
/* In all cases, when you get here, the value and location stacks
   have just been pushed. so pushing a state here evens the stacks.  */
yynewstate:

  *++yyssp = yystate;

#ifdef RIE_SOME_INHERIT
  ++rriasp;
#endif

#ifdef RIE_SOME_LOCAL
  ++rrlasp;
#endif
 
  /*								*/
  /*  inherited attribute and local attribute evaluation.	*/
  /*								*/
  switch (yystate)
    {
      case 5:
#line 202 "kl.rie"
	rriasp->EC4 = rrsasp->rrprocdef.proc;
	break;

      case 17:
#line 200 "kl.rie"
	rriasp->EC0 = rrsasp[-1].rrprocdef.proc;
#line 263 "kl.rie"
	rriasp->EC1 = rrsasp[-1].rrprocdef.proc;
	break;

      case 32:
#line 201 "kl.rie"
	rriasp->EC2 = rrsasp[-2].rrprocdef.proc;
#line 254 "kl.rie"
	rriasp->EC3 = rrsasp[-2].rrprocdef.proc;
	break;

      case 33:
#line 264 "kl.rie"
	rriasp->EC0 = rriasp[-1].EC0;
#line 263 "kl.rie"
	rriasp->EC1 = rriasp[-1].EC0;
	break;

      case 42:
#line 254 "kl.rie"
	rriasp->EC2 = rriasp[-1].EC2;
#line 254 "kl.rie"
	rriasp->EC3 = rriasp[-1].EC2;
	break;

      case 44:
#line 934 "kl.rie"
	rriasp->EC104 =new term_functor( rrsasp->rrSymbol.module, rrsasp->rrSymbol.name);
	break;

      case 46:
#line 893 "kl.rie"
	rriasp->EC107 = rrsasp->rrtr_head.module;
	break;

      case 57:
#line 203 "kl.rie"
	rriasp->EC5 = rrsasp[-4].rrprocdef.proc;
#line 285 "kl.rie"
	rriasp->EC6 = rrsasp[-4].rrprocdef.proc;
#line 290 "kl.rie"
	rriasp->EC7 = rrsasp[-4].rrprocdef.proc;
	break;

      case 59:
#line 951 "kl.rie"
	rriasp->EC105 = rriasp[-1].EC104;
#line 947 "kl.rie"
	rriasp->EC106 = rriasp[-1].EC104;
	break;

      case 61:
#line 988 "kl.rie"
	rriasp->EC108 = rriasp[-1].EC107;
#line 992 "kl.rie"
	rriasp->EC109 = rriasp[-1].EC107;
	break;

      case 77:
#line 204 "kl.rie"
	rriasp->EC10 = rrsasp[-5].rrprocdef.proc;
	break;

      case 78:
#line 287 "kl.rie"
	rriasp->EC5 = rriasp[-1].EC5;
#line 285 "kl.rie"
	rriasp->EC6 = rriasp[-1].EC5;
#line 290 "kl.rie"
	rriasp->EC7 = rriasp[-1].EC5;
	break;

      case 79:
#line 291 "kl.rie"
	rriasp->EC8 = rrsasp->rrruledef.rule;
#line 311 "kl.rie"
	rriasp->EC9 = rrsasp->rrruledef.rule;
	break;

      case 90:
#line 995 "kl.rie"
	rriasp->EC108 = rriasp[-1].EC108;
#line 992 "kl.rie"
	rriasp->EC109 = rriasp[-1].EC108;
	break;

      case 101:
#line 292 "kl.rie"
	rriasp->EC11 = rrsasp[-1].rrruledef.rule;
#line 320 "kl.rie"
	rriasp->EC31 = rrsasp[-1].rrruledef.rule;
#line 323 "kl.rie"
	rriasp->EC32 =NULL;
#line 324 "kl.rie"
	rriasp->EC33 =NULL;
#line 325 "kl.rie"
	rriasp->EC34 =0;
	break;

      case 102:
#line 311 "kl.rie"
	rriasp->EC8 = rriasp[-1].EC8;
#line 311 "kl.rie"
	rriasp->EC9 = rriasp[-1].EC8;
	break;

      case 107:
#line 951 "kl.rie"
	rriasp->EC105 = rrsasp[-1].rrtr_arg.ts;
#line 954 "kl.rie"
	rriasp->EC106 = rrsasp[-1].rrtr_arg.ts;
	break;

      case 121:
#line 629 "kl.rie"
	rriasp->EC35 = rriasp[-1].EC31;
#line 628 "kl.rie"
	rriasp->EC36 = rriasp[-1].EC32;
#line 628 "kl.rie"
	rriasp->EC37 = rriasp[-1].EC33;
#line 630 "kl.rie"
	rriasp->EC38 = rriasp[-1].EC34+ 1;
	break;

      case 122:
#line 293 "kl.rie"
	rriasp->EC12 = rrsasp[-2].rrruledef.rule;
	break;

      case 134:
#line 583 "kl.rie"
	rriasp->EC31 = rriasp[-1].EC35;
#line 582 "kl.rie"
	rriasp->EC32 = rriasp[-1].EC36;
#line 582 "kl.rie"
	rriasp->EC33 = rriasp[-1].EC37;
#line 584 "kl.rie"
	rriasp->EC34 = rriasp[-1].EC38;
#line 640 "kl.rie"
	rriasp->EC39 = rriasp[-1].EC35;
#line 639 "kl.rie"
	rriasp->EC40 = rriasp[-1].EC36;
#line 639 "kl.rie"
	rriasp->EC41 = rriasp[-1].EC37;
#line 642 "kl.rie"
	rriasp->EC42 = rriasp[-1].EC38;
#line 658 "kl.rie"
	rriasp->EC43 = rriasp[-1].EC35;
#line 657 "kl.rie"
	rriasp->EC44 = rriasp[-1].EC36;
#line 660 "kl.rie"
	rriasp->EC45 = rriasp[-1].EC37;
#line 659 "kl.rie"
	rriasp->EC46 = rriasp[-1].EC38;
#line 552 "kl.rie"
	rriasp->EC47 = rriasp[-1].EC35;
#line 551 "kl.rie"
	rriasp->EC48 = rriasp[-1].EC36;
#line 551 "kl.rie"
	rriasp->EC49 = rriasp[-1].EC37;
#line 552 "kl.rie"
	rriasp->EC50 = rriasp[-1].EC38;
#line 646 "kl.rie"
	rriasp->EC55 = rriasp[-1].EC35;
#line 645 "kl.rie"
	rriasp->EC56 = rriasp[-1].EC36;
#line 645 "kl.rie"
	rriasp->EC57 = rriasp[-1].EC37;
#line 647 "kl.rie"
	rriasp->EC58 = rriasp[-1].EC38;
#line 579 "kl.rie"
	rriasp->EC59 = rriasp[-1].EC35;
#line 578 "kl.rie"
	rriasp->EC60 = rriasp[-1].EC36;
#line 578 "kl.rie"
	rriasp->EC61 = rriasp[-1].EC37;
#line 580 "kl.rie"
	rriasp->EC62 = rriasp[-1].EC38;
#line 591 "kl.rie"
	rriasp->EC71 = rriasp[-1].EC35;
#line 590 "kl.rie"
	rriasp->EC72 = rriasp[-1].EC36;
#line 590 "kl.rie"
	rriasp->EC73 = rriasp[-1].EC37;
#line 592 "kl.rie"
	rriasp->EC74 = rriasp[-1].EC38;
#line 587 "kl.rie"
	rriasp->EC83 = rriasp[-1].EC35;
#line 586 "kl.rie"
	rriasp->EC84 = rriasp[-1].EC36;
#line 586 "kl.rie"
	rriasp->EC85 = rriasp[-1].EC37;
#line 588 "kl.rie"
	rriasp->EC86 = rriasp[-1].EC38;
	break;

      case 136:
#line 330 "kl.rie"
	rriasp->EC13 = rriasp[-1].EC12;
#line 333 "kl.rie"
	rriasp->EC14 = rriasp[-1].EC12;
#line 336 "kl.rie"
	rriasp->EC15 = rriasp[-1].EC12;
#line 342 "kl.rie"
	rriasp->EC28 =con_guard;
#line 341 "kl.rie"
	rriasp->EC29 = rriasp[-1].EC12;
	break;

      case 147:
#line 684 "kl.rie"
	rriasp->EC35 = rriasp[-1].EC83;
#line 683 "kl.rie"
	rriasp->EC36 = rriasp[-1].EC84;
#line 683 "kl.rie"
	rriasp->EC37 = rriasp[-1].EC85;
#line 685 "kl.rie"
	rriasp->EC38 = rriasp[-1].EC86+ 1;
	break;

      case 149:
#line 583 "kl.rie"
	rriasp->EC31 = rriasp[-1].EC59;
#line 582 "kl.rie"
	rriasp->EC32 = rriasp[-1].EC60;
#line 582 "kl.rie"
	rriasp->EC33 = rriasp[-1].EC61;
#line 584 "kl.rie"
	rriasp->EC34 = rriasp[-1].EC62+ 1;
#line 619 "kl.rie"
	rriasp->EC43 = rriasp[-1].EC59;
#line 618 "kl.rie"
	rriasp->EC44 = rriasp[-1].EC60;
#line 618 "kl.rie"
	rriasp->EC45 = rriasp[-1].EC61;
#line 620 "kl.rie"
	rriasp->EC46 = rriasp[-1].EC62+ 1;
#line 552 "kl.rie"
	rriasp->EC47 = rriasp[-1].EC59;
#line 551 "kl.rie"
	rriasp->EC48 = rriasp[-1].EC60;
#line 551 "kl.rie"
	rriasp->EC49 = rriasp[-1].EC61;
#line 552 "kl.rie"
	rriasp->EC50 = rriasp[-1].EC62+ 1;
#line 579 "kl.rie"
	rriasp->EC59 = rriasp[-1].EC59;
#line 578 "kl.rie"
	rriasp->EC60 = rriasp[-1].EC60;
#line 578 "kl.rie"
	rriasp->EC61 = rriasp[-1].EC61;
#line 580 "kl.rie"
	rriasp->EC62 = rriasp[-1].EC62+ 1;
#line 602 "kl.rie"
	rriasp->EC63 = rriasp[-1].EC59;
#line 601 "kl.rie"
	rriasp->EC64 = rriasp[-1].EC60;
#line 601 "kl.rie"
	rriasp->EC65 = rriasp[-1].EC61;
#line 603 "kl.rie"
	rriasp->EC66 = rriasp[-1].EC62+ 1;
#line 609 "kl.rie"
	rriasp->EC67 = rriasp[-1].EC59;
#line 608 "kl.rie"
	rriasp->EC68 = rriasp[-1].EC60;
#line 608 "kl.rie"
	rriasp->EC69 = rriasp[-1].EC61;
#line 610 "kl.rie"
	rriasp->EC70 = rriasp[-1].EC62+ 1;
#line 591 "kl.rie"
	rriasp->EC71 = rriasp[-1].EC59;
#line 590 "kl.rie"
	rriasp->EC72 = rriasp[-1].EC60;
#line 590 "kl.rie"
	rriasp->EC73 = rriasp[-1].EC61;
#line 592 "kl.rie"
	rriasp->EC74 = rriasp[-1].EC62+ 1;
#line 587 "kl.rie"
	rriasp->EC83 = rriasp[-1].EC59;
#line 586 "kl.rie"
	rriasp->EC84 = rriasp[-1].EC60;
#line 586 "kl.rie"
	rriasp->EC85 = rriasp[-1].EC61;
#line 588 "kl.rie"
	rriasp->EC86 = rriasp[-1].EC62+ 1;
	break;

      case 150:
#line 583 "kl.rie"
	rriasp->EC31 = rriasp[-1].EC71;
#line 582 "kl.rie"
	rriasp->EC32 = rriasp[-1].EC72;
#line 582 "kl.rie"
	rriasp->EC33 = rriasp[-1].EC73;
#line 584 "kl.rie"
	rriasp->EC34 = rriasp[-1].EC74+ 1;
#line 701 "kl.rie"
	rriasp->EC43 = rriasp[-1].EC71;
#line 700 "kl.rie"
	rriasp->EC44 = rriasp[-1].EC72;
#line 700 "kl.rie"
	rriasp->EC45 = rriasp[-1].EC73;
#line 702 "kl.rie"
	rriasp->EC46 = rriasp[-1].EC74+ 1;
#line 552 "kl.rie"
	rriasp->EC47 = rriasp[-1].EC71;
#line 551 "kl.rie"
	rriasp->EC48 = rriasp[-1].EC72;
#line 551 "kl.rie"
	rriasp->EC49 = rriasp[-1].EC73;
#line 552 "kl.rie"
	rriasp->EC50 = rriasp[-1].EC74+ 1;
#line 579 "kl.rie"
	rriasp->EC59 = rriasp[-1].EC71;
#line 578 "kl.rie"
	rriasp->EC60 = rriasp[-1].EC72;
#line 578 "kl.rie"
	rriasp->EC61 = rriasp[-1].EC73;
#line 580 "kl.rie"
	rriasp->EC62 = rriasp[-1].EC74+ 1;
#line 591 "kl.rie"
	rriasp->EC71 = rriasp[-1].EC71;
#line 590 "kl.rie"
	rriasp->EC72 = rriasp[-1].EC72;
#line 590 "kl.rie"
	rriasp->EC73 = rriasp[-1].EC73;
#line 592 "kl.rie"
	rriasp->EC74 = rriasp[-1].EC74+ 1;
#line 689 "kl.rie"
	rriasp->EC75 = rriasp[-1].EC71;
#line 688 "kl.rie"
	rriasp->EC76 = rriasp[-1].EC72;
#line 688 "kl.rie"
	rriasp->EC77 = rriasp[-1].EC73;
#line 690 "kl.rie"
	rriasp->EC78 = rriasp[-1].EC74+ 1;
#line 696 "kl.rie"
	rriasp->EC79 = rriasp[-1].EC71;
#line 695 "kl.rie"
	rriasp->EC80 = rriasp[-1].EC72;
#line 695 "kl.rie"
	rriasp->EC81 = rriasp[-1].EC73;
#line 697 "kl.rie"
	rriasp->EC82 = rriasp[-1].EC74+ 1;
#line 587 "kl.rie"
	rriasp->EC83 = rriasp[-1].EC71;
#line 586 "kl.rie"
	rriasp->EC84 = rriasp[-1].EC72;
#line 586 "kl.rie"
	rriasp->EC85 = rriasp[-1].EC73;
#line 588 "kl.rie"
	rriasp->EC86 = rriasp[-1].EC74+ 1;
	break;

      case 154:
#line 556 "kl.rie"
	rrlasp->C1.port_128 =new Port();
#line 552 "kl.rie"
	rriasp->EC51 = rriasp[-1].EC43;
#line 551 "kl.rie"
	rriasp->EC52 = rrsasp->rrt_term_body.sps;
#line 551 "kl.rie"
	rriasp->EC53 = rrsasp->rrt_term_body.ps;
#line 552 "kl.rie"
	rriasp->EC54 = rriasp[-1].EC46;
	break;

      case 203:
#line 583 "kl.rie"
	rriasp->EC31 = rriasp[-2].EC39;
#line 582 "kl.rie"
	rriasp->EC32 = rrsasp[-1].rrt_arg.sps;
#line 582 "kl.rie"
	rriasp->EC33 = rrsasp[-1].rrt_arg.ps;
#line 584 "kl.rie"
	rriasp->EC34 = rriasp[-2].EC42;
#line 651 "kl.rie"
	rriasp->EC39 = rriasp[-2].EC39;
#line 650 "kl.rie"
	rriasp->EC40 = rrsasp[-1].rrt_arg.sps;
#line 650 "kl.rie"
	rriasp->EC41 = rrsasp[-1].rrt_arg.ps;
#line 653 "kl.rie"
	rriasp->EC42 = rriasp[-2].EC42;
#line 658 "kl.rie"
	rriasp->EC43 = rriasp[-2].EC39;
#line 657 "kl.rie"
	rriasp->EC44 = rrsasp[-1].rrt_arg.sps;
#line 660 "kl.rie"
	rriasp->EC45 = rrsasp[-1].rrt_arg.ps;
#line 659 "kl.rie"
	rriasp->EC46 = rriasp[-2].EC42;
#line 552 "kl.rie"
	rriasp->EC47 = rriasp[-2].EC39;
#line 551 "kl.rie"
	rriasp->EC48 = rrsasp[-1].rrt_arg.sps;
#line 551 "kl.rie"
	rriasp->EC49 = rrsasp[-1].rrt_arg.ps;
#line 552 "kl.rie"
	rriasp->EC50 = rriasp[-2].EC42;
#line 646 "kl.rie"
	rriasp->EC55 = rriasp[-2].EC39;
#line 645 "kl.rie"
	rriasp->EC56 = rrsasp[-1].rrt_arg.sps;
#line 645 "kl.rie"
	rriasp->EC57 = rrsasp[-1].rrt_arg.ps;
#line 647 "kl.rie"
	rriasp->EC58 = rriasp[-2].EC42;
#line 579 "kl.rie"
	rriasp->EC59 = rriasp[-2].EC39;
#line 578 "kl.rie"
	rriasp->EC60 = rrsasp[-1].rrt_arg.sps;
#line 578 "kl.rie"
	rriasp->EC61 = rrsasp[-1].rrt_arg.ps;
#line 580 "kl.rie"
	rriasp->EC62 = rriasp[-2].EC42;
#line 591 "kl.rie"
	rriasp->EC71 = rriasp[-2].EC39;
#line 590 "kl.rie"
	rriasp->EC72 = rrsasp[-1].rrt_arg.sps;
#line 590 "kl.rie"
	rriasp->EC73 = rrsasp[-1].rrt_arg.ps;
#line 592 "kl.rie"
	rriasp->EC74 = rriasp[-2].EC42;
#line 587 "kl.rie"
	rriasp->EC83 = rriasp[-2].EC39;
#line 586 "kl.rie"
	rriasp->EC84 = rrsasp[-1].rrt_arg.sps;
#line 586 "kl.rie"
	rriasp->EC85 = rrsasp[-1].rrt_arg.ps;
#line 588 "kl.rie"
	rriasp->EC86 = rriasp[-2].EC42;
	break;

      case 221:
#line 330 "kl.rie"
	rriasp->EC18 = rriasp[-3].EC12;
#line 357 "kl.rie"
	rriasp->EC19 = rriasp[-3].EC12;
	break;

      case 222:
#line 338 "kl.rie"
	rriasp->EC14 = rriasp[-2].EC14;
#line 336 "kl.rie"
	rriasp->EC15 = rriasp[-2].EC14;
#line 342 "kl.rie"
	rriasp->EC28 =con_guard;
#line 341 "kl.rie"
	rriasp->EC29 = rriasp[-2].EC14;
	break;

      case 223:
#line 341 "kl.rie"
	rriasp->EC16 = rriasp[-2].EC15;
#line 349 "kl.rie"
	rriasp->EC17 = rriasp[-2].EC15;
	break;

      case 237:
#line 583 "kl.rie"
	rriasp->EC31 = rriasp[-2].EC67;
#line 582 "kl.rie"
	rriasp->EC32 = rrsasp[-1].rrt_term.sps;
#line 582 "kl.rie"
	rriasp->EC33 = rrsasp[-1].rrt_term.ps;
#line 584 "kl.rie"
	rriasp->EC34 = rriasp[-2].EC70;
#line 619 "kl.rie"
	rriasp->EC43 = rriasp[-2].EC67;
#line 618 "kl.rie"
	rriasp->EC44 = rrsasp[-1].rrt_term.sps;
#line 618 "kl.rie"
	rriasp->EC45 = rrsasp[-1].rrt_term.ps;
#line 620 "kl.rie"
	rriasp->EC46 = rriasp[-2].EC70;
#line 552 "kl.rie"
	rriasp->EC47 = rriasp[-2].EC67;
#line 551 "kl.rie"
	rriasp->EC48 = rrsasp[-1].rrt_term.sps;
#line 551 "kl.rie"
	rriasp->EC49 = rrsasp[-1].rrt_term.ps;
#line 552 "kl.rie"
	rriasp->EC50 = rriasp[-2].EC70;
#line 579 "kl.rie"
	rriasp->EC59 = rriasp[-2].EC67;
#line 578 "kl.rie"
	rriasp->EC60 = rrsasp[-1].rrt_term.sps;
#line 578 "kl.rie"
	rriasp->EC61 = rrsasp[-1].rrt_term.ps;
#line 580 "kl.rie"
	rriasp->EC62 = rriasp[-2].EC70;
#line 623 "kl.rie"
	rriasp->EC67 = rriasp[-2].EC67;
#line 622 "kl.rie"
	rriasp->EC68 = rrsasp[-1].rrt_term.sps;
#line 622 "kl.rie"
	rriasp->EC69 = rrsasp[-1].rrt_term.ps;
#line 625 "kl.rie"
	rriasp->EC70 = rriasp[-2].EC70;
#line 591 "kl.rie"
	rriasp->EC71 = rriasp[-2].EC67;
#line 590 "kl.rie"
	rriasp->EC72 = rrsasp[-1].rrt_term.sps;
#line 590 "kl.rie"
	rriasp->EC73 = rrsasp[-1].rrt_term.ps;
#line 592 "kl.rie"
	rriasp->EC74 = rriasp[-2].EC70;
#line 587 "kl.rie"
	rriasp->EC83 = rriasp[-2].EC67;
#line 586 "kl.rie"
	rriasp->EC84 = rrsasp[-1].rrt_term.sps;
#line 586 "kl.rie"
	rriasp->EC85 = rrsasp[-1].rrt_term.ps;
#line 588 "kl.rie"
	rriasp->EC86 = rriasp[-2].EC70;
	break;

      case 239:
#line 583 "kl.rie"
	rriasp->EC31 = rriasp[-2].EC63;
#line 582 "kl.rie"
	rriasp->EC32 = rrsasp[-1].rrt_list_elements.sps;
#line 582 "kl.rie"
	rriasp->EC33 = rrsasp[-1].rrt_list_elements.ps;
#line 584 "kl.rie"
	rriasp->EC34 = rriasp[-2].EC66;
#line 613 "kl.rie"
	rriasp->EC43 = rriasp[-2].EC63;
#line 612 "kl.rie"
	rriasp->EC44 = rrsasp[-1].rrt_list_elements.sps;
#line 612 "kl.rie"
	rriasp->EC45 = rrsasp[-1].rrt_list_elements.ps;
#line 615 "kl.rie"
	rriasp->EC46 = rriasp[-2].EC66;
#line 552 "kl.rie"
	rriasp->EC47 = rriasp[-2].EC63;
#line 551 "kl.rie"
	rriasp->EC48 = rrsasp[-1].rrt_list_elements.sps;
#line 551 "kl.rie"
	rriasp->EC49 = rrsasp[-1].rrt_list_elements.ps;
#line 552 "kl.rie"
	rriasp->EC50 = rriasp[-2].EC66;
#line 579 "kl.rie"
	rriasp->EC59 = rriasp[-2].EC63;
#line 578 "kl.rie"
	rriasp->EC60 = rrsasp[-1].rrt_list_elements.sps;
#line 578 "kl.rie"
	rriasp->EC61 = rrsasp[-1].rrt_list_elements.ps;
#line 580 "kl.rie"
	rriasp->EC62 = rriasp[-2].EC66;
#line 591 "kl.rie"
	rriasp->EC71 = rriasp[-2].EC63;
#line 590 "kl.rie"
	rriasp->EC72 = rrsasp[-1].rrt_list_elements.sps;
#line 590 "kl.rie"
	rriasp->EC73 = rrsasp[-1].rrt_list_elements.ps;
#line 592 "kl.rie"
	rriasp->EC74 = rriasp[-2].EC66;
#line 587 "kl.rie"
	rriasp->EC83 = rriasp[-2].EC63;
#line 586 "kl.rie"
	rriasp->EC84 = rrsasp[-1].rrt_list_elements.sps;
#line 586 "kl.rie"
	rriasp->EC85 = rrsasp[-1].rrt_list_elements.ps;
#line 588 "kl.rie"
	rriasp->EC86 = rriasp[-2].EC66;
	break;

      case 240:
#line 583 "kl.rie"
	rriasp->EC31 = rriasp[-2].EC79;
#line 582 "kl.rie"
	rriasp->EC32 = rrsasp[-1].rrt_term.sps;
#line 582 "kl.rie"
	rriasp->EC33 = rrsasp[-1].rrt_term.ps;
#line 584 "kl.rie"
	rriasp->EC34 = rriasp[-2].EC82;
#line 701 "kl.rie"
	rriasp->EC43 = rriasp[-2].EC79;
#line 700 "kl.rie"
	rriasp->EC44 = rrsasp[-1].rrt_term.sps;
#line 700 "kl.rie"
	rriasp->EC45 = rrsasp[-1].rrt_term.ps;
#line 702 "kl.rie"
	rriasp->EC46 = rriasp[-2].EC82;
#line 552 "kl.rie"
	rriasp->EC47 = rriasp[-2].EC79;
#line 551 "kl.rie"
	rriasp->EC48 = rrsasp[-1].rrt_term.sps;
#line 551 "kl.rie"
	rriasp->EC49 = rrsasp[-1].rrt_term.ps;
#line 552 "kl.rie"
	rriasp->EC50 = rriasp[-2].EC82;
#line 579 "kl.rie"
	rriasp->EC59 = rriasp[-2].EC79;
#line 578 "kl.rie"
	rriasp->EC60 = rrsasp[-1].rrt_term.sps;
#line 578 "kl.rie"
	rriasp->EC61 = rrsasp[-1].rrt_term.ps;
#line 580 "kl.rie"
	rriasp->EC62 = rriasp[-2].EC82;
#line 591 "kl.rie"
	rriasp->EC71 = rriasp[-2].EC79;
#line 590 "kl.rie"
	rriasp->EC72 = rrsasp[-1].rrt_term.sps;
#line 590 "kl.rie"
	rriasp->EC73 = rrsasp[-1].rrt_term.ps;
#line 592 "kl.rie"
	rriasp->EC74 = rriasp[-2].EC82;
#line 705 "kl.rie"
	rriasp->EC79 = rriasp[-2].EC79;
#line 704 "kl.rie"
	rriasp->EC80 = rrsasp[-1].rrt_term.sps;
#line 704 "kl.rie"
	rriasp->EC81 = rrsasp[-1].rrt_term.ps;
#line 707 "kl.rie"
	rriasp->EC82 = rriasp[-2].EC82;
#line 587 "kl.rie"
	rriasp->EC83 = rriasp[-2].EC79;
#line 586 "kl.rie"
	rriasp->EC84 = rrsasp[-1].rrt_term.sps;
#line 586 "kl.rie"
	rriasp->EC85 = rrsasp[-1].rrt_term.ps;
#line 588 "kl.rie"
	rriasp->EC86 = rriasp[-2].EC82;
	break;

      case 260:
#line 357 "kl.rie"
	rriasp->EC20 = rriasp[-1].EC18;
	break;

      case 263:
#line 349 "kl.rie"
	rriasp->EC16 = rriasp[-1].EC16;
#line 349 "kl.rie"
	rriasp->EC17 = rriasp[-1].EC16;
	break;

      case 295:
#line 363 "kl.rie"
	rriasp->EC21 = rriasp[-1].EC20;
	break;

      case 296:
#line 357 "kl.rie"
	rriasp->EC22 = rriasp[-2].EC18;
	break;

      case 307:
#line 418 "kl.rie"
	rrlasp->C0.sp_68 = rriasp[-1].EC21->NewSubProc();
#line 367 "kl.rie"
	rriasp->EC25 = rriasp[-1].EC21;
#line 419 "kl.rie"
	rriasp->EC31 = rriasp[-1].EC21;
#line 420 "kl.rie"
	rriasp->EC32 = rrlasp->C0.sp_68;
#line 421 "kl.rie"
	rriasp->EC33 =NULL;
#line 424 "kl.rie"
	rriasp->EC34 =0;
	break;

      case 309:
#line 370 "kl.rie"
	rriasp->EC23 = rriasp[-1].EC22;
	break;

      case 317:
#line 367 "kl.rie"
	rriasp->EC21 = rriasp[-2].EC21;
	break;

      case 319:
#line 374 "kl.rie"
	rriasp->EC24 = rriasp[-1].EC23;
#line 377 "kl.rie"
	rriasp->EC30 = rriasp[-1].EC23;
#line 411 "kl.rie"
	rriasp->EC31 = rriasp[-1].EC23;
#line 410 "kl.rie"
	rriasp->EC32 =NULL;
#line 410 "kl.rie"
	rriasp->EC33 =NULL;
#line 412 "kl.rie"
	rriasp->EC34 =99999;
#line 711 "kl.rie"
	rriasp->EC43 = rriasp[-1].EC23;
#line 710 "kl.rie"
	rriasp->EC44 =NULL;
#line 710 "kl.rie"
	rriasp->EC45 =NULL;
#line 712 "kl.rie"
	rriasp->EC46 =99999;
#line 552 "kl.rie"
	rriasp->EC47 = rriasp[-1].EC23;
#line 551 "kl.rie"
	rriasp->EC48 =NULL;
#line 551 "kl.rie"
	rriasp->EC49 =NULL;
#line 552 "kl.rie"
	rriasp->EC50 =99999;
#line 579 "kl.rie"
	rriasp->EC59 = rriasp[-1].EC23;
#line 578 "kl.rie"
	rriasp->EC60 =NULL;
#line 578 "kl.rie"
	rriasp->EC61 =NULL;
#line 580 "kl.rie"
	rriasp->EC62 =99999;
#line 591 "kl.rie"
	rriasp->EC71 = rriasp[-1].EC23;
#line 590 "kl.rie"
	rriasp->EC72 =NULL;
#line 590 "kl.rie"
	rriasp->EC73 =NULL;
#line 592 "kl.rie"
	rriasp->EC74 =99999;
#line 587 "kl.rie"
	rriasp->EC83 = rriasp[-1].EC23;
#line 586 "kl.rie"
	rriasp->EC84 =NULL;
#line 586 "kl.rie"
	rriasp->EC85 =NULL;
#line 588 "kl.rie"
	rriasp->EC86 =99999;
#line 384 "kl.rie"
	rriasp->EC87 = rriasp[-1].EC23;
#line 385 "kl.rie"
	rriasp->EC88 =NULL;
#line 386 "kl.rie"
	rriasp->EC89 =NULL;
#line 387 "kl.rie"
	rriasp->EC90 =99999;
#line 397 "kl.rie"
	rriasp->EC91 = rriasp[-1].EC23;
#line 398 "kl.rie"
	rriasp->EC92 =NULL;
#line 399 "kl.rie"
	rriasp->EC93 =NULL;
#line 400 "kl.rie"
	rriasp->EC94 =99999;
#line 379 "kl.rie"
	rriasp->EC95 = rriasp[-1].EC23;
#line 380 "kl.rie"
	rriasp->EC96 =NULL;
#line 381 "kl.rie"
	rriasp->EC97 =NULL;
#line 382 "kl.rie"
	rriasp->EC98 =99999;
	break;

      case 330:
#line 684 "kl.rie"
	rriasp->EC35 = rriasp[-1].EC83;
#line 683 "kl.rie"
	rriasp->EC36 = rriasp[-1].EC84;
#line 683 "kl.rie"
	rriasp->EC37 = rriasp[-1].EC85;
#line 685 "kl.rie"
	rriasp->EC38 = rriasp[-1].EC86+ 1;
	break;

      case 331:
#line 374 "kl.rie"
	rriasp->EC23 = rriasp[-2].EC23;
	break;

      case 341:
#line 437 "kl.rie"
	rriasp->EC26 = rrsasp[-2].rrt_functor.sps;
#line 422 "kl.rie"
	rriasp->EC27 = rrsasp[-2].rrt_functor.sps;
	break;

      case 345:
#line 411 "kl.rie"
	rriasp->EC99 = rriasp[-2].EC95;
	break;

      case 346:
#line 583 "kl.rie"
	rriasp->EC31 = rriasp[-2].EC87;
#line 582 "kl.rie"
	rriasp->EC32 = rrsasp[-1].rrt_term.sps;
#line 582 "kl.rie"
	rriasp->EC33 = rrsasp[-1].rrt_term.ps;
#line 584 "kl.rie"
	rriasp->EC34 = rriasp[-2].EC90;
#line 711 "kl.rie"
	rriasp->EC43 = rriasp[-2].EC87;
#line 710 "kl.rie"
	rriasp->EC44 = rrsasp[-1].rrt_term.sps;
#line 710 "kl.rie"
	rriasp->EC45 = rrsasp[-1].rrt_term.ps;
#line 713 "kl.rie"
	rriasp->EC46 = rriasp[-2].EC90;
#line 552 "kl.rie"
	rriasp->EC47 = rriasp[-2].EC87;
#line 551 "kl.rie"
	rriasp->EC48 = rrsasp[-1].rrt_term.sps;
#line 551 "kl.rie"
	rriasp->EC49 = rrsasp[-1].rrt_term.ps;
#line 552 "kl.rie"
	rriasp->EC50 = rriasp[-2].EC90;
#line 579 "kl.rie"
	rriasp->EC59 = rriasp[-2].EC87;
#line 578 "kl.rie"
	rriasp->EC60 = rrsasp[-1].rrt_term.sps;
#line 578 "kl.rie"
	rriasp->EC61 = rrsasp[-1].rrt_term.ps;
#line 580 "kl.rie"
	rriasp->EC62 = rriasp[-2].EC90;
#line 591 "kl.rie"
	rriasp->EC71 = rriasp[-2].EC87;
#line 590 "kl.rie"
	rriasp->EC72 = rrsasp[-1].rrt_term.sps;
#line 590 "kl.rie"
	rriasp->EC73 = rrsasp[-1].rrt_term.ps;
#line 592 "kl.rie"
	rriasp->EC74 = rriasp[-2].EC90;
#line 587 "kl.rie"
	rriasp->EC83 = rriasp[-2].EC87;
#line 586 "kl.rie"
	rriasp->EC84 = rrsasp[-1].rrt_term.sps;
#line 586 "kl.rie"
	rriasp->EC85 = rrsasp[-1].rrt_term.ps;
#line 588 "kl.rie"
	rriasp->EC86 = rriasp[-2].EC90;
	break;

      case 355:
#line 437 "kl.rie"
	rriasp->EC26 = rrsasp->rrsubproc_info.sps;
#line 437 "kl.rie"
	rriasp->EC27 = rrsasp->rrsubproc_info.sps;
	break;

      case 377:
#line 870 "kl.rie"
	rriasp->EC100 = rrsasp[-1].rrInteger.value;
#line 869 "kl.rie"
	rriasp->EC101 = rriasp[-3].EC99;
#line 873 "kl.rie"
	rriasp->EC102 = rrsasp[-1].rrInteger.value;
#line 873 "kl.rie"
	rriasp->EC103 = rriasp[-3].EC99;
	break;

      case 384:
#line 875 "kl.rie"
	rriasp->EC100 = rriasp[-1].EC100;
#line 875 "kl.rie"
	rriasp->EC101 = rriasp[-1].EC101;
#line 873 "kl.rie"
	rriasp->EC102 = rriasp[-1].EC100;
#line 873 "kl.rie"
	rriasp->EC103 = rriasp[-1].EC101;
	break;

    }



#line 427 "/usr/local/lib/rie-1.0.6/rie.simple"
  if (yyssp >= yyss + yystacksize - 1)
    {
      /* Give user a chance to reallocate the stack */
      /* Use copies of these so that the &'s don't force the real ones into memory. */
#ifdef NOT_RIE
      YYSTYPE *yyvs1 = yyvs;
#endif
      short *yyss1 = yyss;
#ifdef YYLSP_NEEDED
      YYLTYPE *yyls1 = yyls;
#endif

#ifdef RIE_SOME_SYNTHESIZE
      rrsastype *rrss1 = rrss;
#endif

#ifdef RIE_SOME_INHERIT
      rriastype *rris1 = rris;
#endif

#ifdef RIE_SOME_LOCAL
      rrlastype *rrls1 = rrls;
#endif
      
      /* Get the current used size of the three stacks, in elements.  */
      int size = yyssp - yyss + 1;

#ifdef yyoverflow
      /* Each stack pointer address is followed by the size of
	 the data in use in that stack, in bytes.  */
#ifdef YYLSP_NEEDED
      /* This used to be a conditional around just the two extra args,
	 but that might be undefined if yyoverflow is a macro.  */
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
#ifdef NOT_RIE
		 &yyvs1, size * sizeof (*yyvsp),
#endif
		 &yyls1, size * sizeof (*yylsp),
#ifdef RIE_SOME_SYNTHESIZE
		 &rrss1, size * sizeof (*rrsasp),
#endif
#ifdef RIE_SOME_INHERIT
		 &rris1, size * sizeof (*rriasp),
#endif
#ifdef RIE_SOME_LOCAL
		 &rrls1, size * sizeof (*rrlasp),
#endif
		 &yystacksize);
#else
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
#ifdef NOT_RIE
		 &yyvs1, size * sizeof (*yyvsp),
#endif
#ifdef RIE_SOME_SYNTHESIZE
		 &rrss1, size * sizeof (*rrsasp),
#endif
#ifdef RIE_SOME_INHERIT
		 &rris1, size * sizeof (*rriasp),
#endif
#ifdef RIE_SOME_LOCAL
		 &rrls1, size * sizeof (*rrlasp),
#endif
		 &yystacksize);
#endif

      yyss = yyss1;
#ifdef YYLSP_NEEDED
      yyls = yyls1;
#endif
#ifdef RIE_SOME_SYNTHESIZE
      rrss = rrss1;
#endif
#ifdef RIE_SOME_INHERIT
      rris = rris1;
#endif
#ifdef RIE_SOME_LOCAL
      rrls = rrls1;
#endif

#else /* no yyoverflow */
      /* Extend the stack our own way.  */
      if (yystacksize >= YYMAXDEPTH)
	{
	  yyerror("parser stack overflow");
	  return 2;
	}
      yystacksize *= 2;
      if (yystacksize > YYMAXDEPTH)
	yystacksize = YYMAXDEPTH;
      yyss = (short *) alloca (yystacksize * sizeof (*yyssp));
      __yy_memcpy ((char *)yyss1, (char *)yyss, size * sizeof (*yyssp));
#ifdef NOT_RIE
      yyvs = (YYSTYPE *) alloca (yystacksize * sizeof (*yyvsp));
      __yy_memcpy ((char *)yyvs1, (char *)yyvs, size * sizeof (*yyvsp));
#endif
#ifdef YYLSP_NEEDED
      yyls = (YYLTYPE *) alloca (yystacksize * sizeof (*yylsp));
      __yy_memcpy ((char *)yyls1, (char *)yyls, size * sizeof (*yylsp));
#endif
#ifdef RIE_SOME_SYNTHESIZE
      rrss = (rrsastype *) alloca (yystacksize * sizeof (*rrsasp));
      __yy_memcpy ((char *)rrss1, (char *)rrss, size * sizeof (*rrsasp));
#endif
#ifdef RIE_SOME_INHERIT
      rris = (rriastype *) alloca (yystacksize * sizeof (*rriasp));
      __yy_memcpy ((char *)rris1, (char *)rris, size * sizeof (*rriasp));
#endif
#ifdef RIE_SOME_LOCAL
      rrls = (rrlastype *) alloca (yystacksize * sizeof (*rrlasp));
      __yy_memcpy ((char *)rrls1, (char *)rrls, size * sizeof (*rrlasp));
#endif	/* RIE_SOME_LOCAL */
      	
#endif /* no yyoverflow */

      yyssp = yyss + size - 1;
#ifdef NOT_RIE
      yyvsp = yyvs + size - 1;
#endif
#ifdef YYLSP_NEEDED
      yylsp = yyls + size - 1;
#endif

#ifdef RIE_SOME_SYNTHESIZE
      rrsasp = rrss + size -1;
#endif
#ifdef RIE_SOME_INHERIT
      rriasp = rris + size -1;
#endif
#ifdef RIE_SOME_LOCAL
      rrlasp = rrls + size -1;
#endif	/* RIE_SOME_LOCAL */
       
#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Stack size increased to %d\n", yystacksize);
#endif

      if (yyssp >= yyss + yystacksize - 1)
	YYABORT;
    }

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Entering state %d\n", yystate);
#endif

  goto yybackup;
 yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* yychar is either YYEMPTY or YYEOF
     or a valid token in external form.  */

  if (yychar == YYEMPTY)
    {
#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Reading a token: ");
#endif
      yychar = YYLEX;
    }

  /* Convert token to internal form (in yychar1) for indexing tables with */

  if (yychar <= 0)		/* This means end of input. */
    {
      yychar1 = 0;
      yychar = YYEOF;		/* Don't call YYLEX any more */

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Now at end of input.\n");
#endif
    }
  else
    {
      yychar1 = YYTRANSLATE(yychar);

#if YYDEBUG != 0
      if (yydebug)
	{
	  fprintf (stderr, "Next token is %d (%s", yychar, yytname[yychar1]);
	  /* Give the individual parser a way to print the precise meaning
	     of a token, for further debugging info.  */
#ifdef YYPRINT
	  YYPRINT (stderr, yychar, yylval);
#endif
	  fprintf (stderr, ")\n");
	}
#endif
    }

  yyn += yychar1;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != yychar1)
    goto yydefault;

  yyn = yytable[yyn];

  /* yyn is what to do for this token type in this state.
     Negative => reduce, -yyn is rule number.
     Positive => shift, yyn is new state.
       New state is final state => don't bother to shift,
       just return success.
     0, or most negative number => error.  */

  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrlab;

  if (yyn == YYFINAL)
    {
#ifdef RIE_SOME_SYNTHESIZE
      rrlval = *--rrsasp;	/* return the last synthesized value.  */
#endif
    YYACCEPT;
    }

  /* Shift the lookahead token.  */

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting token %d (%s), ", yychar, yytname[yychar1]);
#endif

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

#ifdef NOT_RIE
  *++yyvsp = yylval;
#endif
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

#ifdef RIE_SOME_SYNTHESIZE
  *++rrsasp = rrlval;	/* 'rrlval' is returned by YYLEX.  */
#endif

  /* count tokens shifted since error; after three, turn off error status.  */
  if (yyerrstatus) yyerrstatus--;

  yystate = yyn;
  goto yynewstate;

/* Do the default action for the current state.  */
yydefault:

  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;

/* Do a reduction.  yyn is the number of a rule to reduce with.  */
yyreduce:
  yylen = yyr2[yyn];
#ifdef NOT_RIE
  if (yylen > 0)
    yyval = yyvsp[1-yylen]; /* implement default value of the action */
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      int i;

      fprintf (stderr, "Reducing via rule %d (line %d), ",
	       yyn, yyrline[yyn]);

      /* Print the symbols being reduced, and their result.  */
      for (i = yyprhs[yyn]; yyrhs[i] > 0; i++)
	fprintf (stderr, "%s ", yytname[yyrhs[i]]);
      fprintf (stderr, " -> %s\n", yytname[yyr1[yyn]]);
    }
#endif

  /*									*/
  /*  synthesized attribute evaluation. 'rrval' is assigned here.	*/
  /*									*/
  switch (yyn)
    {
      case 6:
#line 176 "kl.rie"
	procRegister( rrsasp->rrprocess.proc);
	break;

      case 8:
#line 189 "kl.rie"
	{
		    if ( rrsasp[-1].rrSymbol.name == get_symbol("module")) {
		      current_module =  rrsasp->rrSymbol.name;
		      printf("MODULE = %s\n", current_module);
		    }
		  }
	break;

      case 9:
#line 199 "kl.rie"
	rrval.rrprocess.proc = rrsasp[-7].rrprocdef.proc;
	break;

      case 10:
#line 210 "kl.rie"
	rrval.rrprocdef.proc =new Proc(current_module, rrsasp[-4].rrOpt_SYMBOL.name, rrsasp[-3].rrproc_type.t, rrsasp[-2].rrarrange_info.arrange, rrsasp[-1].rrarrange_option.option);
#line 212 "kl.rie"
	printf("defining %s : %s\n",current_module, rrsasp[-4].rrOpt_SYMBOL.name);
	break;

      case 11:
#line 215 "kl.rie"
	rrval.rrarrange_info.arrange =expand_default;
	break;

      case 12:
#line 217 "kl.rie"
	rrval.rrarrange_info.arrange =expand_rightward;
	break;

      case 13:
#line 219 "kl.rie"
	rrval.rrarrange_info.arrange =expand_downward;
	break;

      case 14:
#line 222 "kl.rie"
	rrval.rrarrange_option.option =arrange_default;
	break;

      case 15:
#line 224 "kl.rie"
	rrval.rrarrange_option.option =arrange_show_all;
	break;

      case 18:
#line 230 "kl.rie"
	rrval.rrproc_type.t =PROC_TYPE_CREATOR;
	break;

      case 19:
#line 232 "kl.rie"
	rrval.rrproc_type.t =PROC_TYPE_NORMAL;
	break;

      case 20:
#line 234 "kl.rie"
	rrval.rrproc_type.t =PROC_TYPE_PATTERN_TOP;
	break;

      case 21:
#line 236 "kl.rie"
	rrval.rrproc_type.t =PROC_TYPE_PATTERN;
	break;

      case 22:
#line 240 "kl.rie"
	{  rriasp->EC4->SetCreator(NULL, 0);
		             rriasp->EC4->SetModifier(NULL, 0); }
	break;

      case 23:
#line 250 "kl.rie"
	{  rriasp[-8].EC4->SetCreator( rrsasp[-6].rrString.str,
						        rrsasp[-4].rrInteger.value);
		            printf("created by %s at %d.\n",
				    rrsasp[-6].rrString.str,  rrsasp[-4].rrInteger.value);
		             rriasp[-8].EC4->SetModifier( rrsasp[-2].rrString.str,
							 rrsasp->rrInteger.value);
			    printf("modified by %s at %d.\n",
				    rrsasp[-2].rrString.str,  rrsasp->rrInteger.value); }
	break;

      case 26:
#line 259 "kl.rie"
	 rriasp[-5].EC3->AddLayoutDef( rrsasp[-3].rrString.str, rrsasp[-1].rrInteger.value, rrsasp->rrInteger.value);
	break;

      case 29:
#line 273 "kl.rie"
	 rriasp[-5].EC1->AddPort((NAMETYPE)get_symbol( rrsasp[-3].rrOpt_VARIABLE.name), rrsasp[-2].rrport_type.type, rrsasp[-1].rrleft_or_right.lr, rrsasp->rrpoint_size.l, rrsasp->rrpoint_size.t, rrsasp->rrpoint_size.w, rrsasp->rrpoint_size.h);
	break;

      case 30:
#line 282 "kl.rie"
	 rriasp[-5].EC1->AddComment( rrsasp[-1].rrInteger.value, rrsasp->rrInteger.value, rrsasp[-3].rrString.str);
	break;

      case 34:
#line 297 "kl.rie"
	rrval.rrruledef.rule = rriasp[-3].EC7->NewRule( rrsasp[-1].rrInteger.value, rrsasp->rrrule_type.rt);
	break;

      case 35:
#line 300 "kl.rie"
	rrval.rrrule_type.rt =rule_network;
	break;

      case 36:
#line 302 "kl.rie"
	rrval.rrrule_type.rt =rule_vanishing;
	break;

      case 37:
#line 304 "kl.rie"
	rrval.rrrule_type.rt =rule_continuous;
	break;

      case 38:
#line 306 "kl.rie"
	rrval.rrrule_type.rt =rule_continuous;
	break;

      case 41:
#line 317 "kl.rie"
	{  rriasp[-1].EC9->SetPoint( rrsasp->rrpoint_size.l,
						      rrsasp->rrpoint_size.t);
			     rriasp[-1].EC9->SetSize( rrsasp->rrpoint_size.w,
						     rrsasp->rrpoint_size.h); }
	break;

      case 42:
#line 322 "kl.rie"
	rrval.rrhead.arity = rrsasp->rrt_functor.arity;
#line 321 "kl.rie"
	rrval.rrhead.name = rrsasp->rrt_functor.name;
	break;

      case 54:
#line 360 "kl.rie"
	 rriasp[-5].EC19->SetRuleNum( rrsasp[-2].rrInteger.value);
	break;

      case 64:
#line 394 "kl.rie"
	 rriasp[-3].EC24->UnifyPorts( rrsasp->rrInteger.value, rrsasp[-2].rrt_unify.ps);
	break;

      case 66:
#line 407 "kl.rie"
	 rriasp[-6].EC30->AddLink( rrsasp[-1].rrInteger.value, rrsasp->rrInteger.value);
	break;

      case 67:
#line 410 "kl.rie"
	rrval.rrt_merge.ps = rrsasp[-2].rrt_functor.ps;
#line 410 "kl.rie"
	rrval.rrt_merge.sps = rrsasp[-2].rrt_functor.sps;
	break;

      case 68:
#line 423 "kl.rie"
	rrval.rrsubproc.sp = rrsasp->rrsubproc_infos.sps;
#line 431 "kl.rie"
	{ if ( rrsasp[-3].rrt_functor.module)
		               rrlasp[-4].C0.sp_68->SetModule( rrsasp[-3].rrt_functor.module);
		            else
		               rrlasp[-4].C0.sp_68->SetModule(current_module);
		             rrlasp[-4].C0.sp_68->SetName( rrsasp[-3].rrt_functor.name);
			     rrlasp[-4].C0.sp_68->SetArity( rrsasp[-3].rrt_functor.arity);
			     rriasp[-4].EC25->AddBody( rrlasp[-4].C0.sp_68); }
	break;

      case 69:
#line 435 "kl.rie"
	rrval.rrsubproc_infos.sps = rriasp->EC27;
	break;

      case 70:
#line 437 "kl.rie"
	rrval.rrsubproc_infos.sps = rrsasp->rrsubproc_infos.sps;
	break;

      case 71:
#line 440 "kl.rie"
	rrval.rrsubproc_info.sps = rriasp[-1].EC26;
#line 444 "kl.rie"
	{  rriasp[-1].EC26->SetPoint( rrsasp->rrpoint_size.l,
						        rrsasp->rrpoint_size.t);
			     rriasp[-1].EC26->SetSize( rrsasp->rrpoint_size.w,
						       rrsasp->rrpoint_size.h); }
	break;

      case 72:
#line 449 "kl.rie"
	rrval.rrsubproc_info.sps = rriasp[-4].EC26;
#line 451 "kl.rie"
	{  rriasp[-4].EC26->SetDropper( rrsasp[-2].rrString.str,
							 rrsasp->rrInteger.value); }
	break;

      case 73:
#line 453 "kl.rie"
	rrval.rrsubproc_info.sps = rriasp[-4].EC26;
#line 455 "kl.rie"
	{  rriasp[-4].EC26->AddLayout( rrsasp[-1].rrInteger.value,
							 rrsasp->rrInteger.value); }
	break;

      case 80:
#line 477 "kl.rie"
	rrval.rrpoint_size.h = rrsasp->rrInteger.value;
#line 476 "kl.rie"
	rrval.rrpoint_size.w = rrsasp[-1].rrInteger.value;
#line 475 "kl.rie"
	rrval.rrpoint_size.t = rrsasp[-3].rrInteger.value;
#line 474 "kl.rie"
	rrval.rrpoint_size.l = rrsasp[-4].rrInteger.value;
	break;

      case 97:
#line 501 "kl.rie"
	rrval.rrfunctor.arity = rrsasp->rrargument.num;
#line 500 "kl.rie"
	rrval.rrfunctor.name = rrsasp[-1].rrSymbol.name;
	break;

      case 99:
#line 506 "kl.rie"
	rrval.rrargument.num =0;
	break;

      case 100:
#line 508 "kl.rie"
	rrval.rrargument.num = rrsasp[-1].rrargs.num;
	break;

      case 101:
#line 511 "kl.rie"
	rrval.rrargs.num =1;
	break;

      case 102:
#line 513 "kl.rie"
	rrval.rrargs.num = rrsasp->rrargs.num+ 1;
	break;

      case 127:
#line 551 "kl.rie"
	rrval.rrt_term.ps = rrsasp->rrt_term_info.ps;
#line 551 "kl.rie"
	rrval.rrt_term.sps = rrsasp->rrt_term_info.sps;
	break;

      case 128:
#line 557 "kl.rie"
	rrval.rrt_term_info.ps = rrlasp[-1].C1.port_128;
#line 555 "kl.rie"
	rrval.rrt_term_info.sps = rriasp[-1].EC52;
#line 568 "kl.rie"
	{ 
		     rrlasp[-1].C1.port_128->name   =  rrsasp->rrport_info.name;
		     rrlasp[-1].C1.port_128->id     =  rrsasp->rrport_info.id;
		     rrlasp[-1].C1.port_128->type   =  rrsasp->rrport_info.type;
		     rrlasp[-1].C1.port_128->lr     =  rrsasp->rrport_info.lr;
		     rrlasp[-1].C1.port_128->left   =  rrsasp->rrport_info.l;
		     rrlasp[-1].C1.port_128->top    =  rrsasp->rrport_info.t;
		     rrlasp[-1].C1.port_128->width  =  rrsasp->rrport_info.w;
		     rrlasp[-1].C1.port_128->height =  rrsasp->rrport_info.h;
		     rrlasp[-1].C1.port_128->next   =  rriasp[-1].EC53; // make list
		  }
	break;

      case 129:
#line 571 "kl.rie"
	rrval.rrt_term_info.ps = rriasp->EC53;
#line 571 "kl.rie"
	rrval.rrt_term_info.sps = rriasp->EC52;
	break;

      case 130:
#line 573 "kl.rie"
	rrval.rrt_term_info.ps = rriasp[-1].EC53;
#line 573 "kl.rie"
	rrval.rrt_term_info.sps = rriasp[-1].EC52;
	break;

      case 131:
#line 575 "kl.rie"
	rrval.rrt_term_info.ps = rriasp[-1].EC53;
#line 575 "kl.rie"
	rrval.rrt_term_info.sps = rriasp[-1].EC52;
	break;

      case 132:
#line 578 "kl.rie"
	rrval.rrt_term_body.ps = rrsasp->rrt_list.ps;
#line 578 "kl.rie"
	rrval.rrt_term_body.sps = rrsasp->rrt_list.sps;
	break;

      case 133:
#line 582 "kl.rie"
	rrval.rrt_term_body.ps = rrsasp->rrt_functor.ps;
#line 582 "kl.rie"
	rrval.rrt_term_body.sps = rrsasp->rrt_functor.sps;
	break;

      case 134:
#line 586 "kl.rie"
	rrval.rrt_term_body.ps = rrsasp->rrt_structure.ps;
#line 586 "kl.rie"
	rrval.rrt_term_body.sps = rrsasp->rrt_structure.sps;
	break;

      case 135:
#line 590 "kl.rie"
	rrval.rrt_term_body.ps = rrsasp->rrt_vector.ps;
#line 590 "kl.rie"
	rrval.rrt_term_body.sps = rrsasp->rrt_vector.sps;
	break;

      case 136:
#line 594 "kl.rie"
	rrval.rrt_term_body.ps = rriasp[-1].EC49;
#line 594 "kl.rie"
	rrval.rrt_term_body.sps = rriasp[-1].EC48;
	break;

      case 137:
#line 596 "kl.rie"
	rrval.rrt_term_body.ps = rriasp[-1].EC49;
#line 596 "kl.rie"
	rrval.rrt_term_body.sps = rriasp[-1].EC48;
	break;

      case 138:
#line 598 "kl.rie"
	rrval.rrt_term_body.ps = rriasp[-4].EC49;
#line 598 "kl.rie"
	rrval.rrt_term_body.sps = rriasp[-4].EC48;
	break;

      case 139:
#line 601 "kl.rie"
	rrval.rrt_list.ps = rrsasp[-1].rrt_list_contents.ps;
#line 601 "kl.rie"
	rrval.rrt_list.sps = rrsasp[-1].rrt_list_contents.sps;
	break;

      case 140:
#line 606 "kl.rie"
	rrval.rrt_list_contents.ps = rriasp->EC65;
#line 606 "kl.rie"
	rrval.rrt_list_contents.sps = rriasp->EC64;
	break;

      case 141:
#line 608 "kl.rie"
	rrval.rrt_list_contents.ps = rrsasp->rrt_list_elements.ps;
#line 608 "kl.rie"
	rrval.rrt_list_contents.sps = rrsasp->rrt_list_elements.sps;
	break;

      case 142:
#line 612 "kl.rie"
	rrval.rrt_list_contents.ps = rrsasp->rrt_term.ps;
#line 612 "kl.rie"
	rrval.rrt_list_contents.sps = rrsasp->rrt_term.sps;
	break;

      case 143:
#line 618 "kl.rie"
	rrval.rrt_list_elements.ps = rrsasp->rrt_term.ps;
#line 618 "kl.rie"
	rrval.rrt_list_elements.sps = rrsasp->rrt_term.sps;
	break;

      case 144:
#line 622 "kl.rie"
	rrval.rrt_list_elements.ps = rrsasp->rrt_list_elements.ps;
#line 622 "kl.rie"
	rrval.rrt_list_elements.sps = rrsasp->rrt_list_elements.sps;
	break;

      case 145:
#line 633 "kl.rie"
	rrval.rrt_functor.arity = rrsasp->rrt_argument.num;
#line 632 "kl.rie"
	rrval.rrt_functor.name = rrsasp[-1].rrSymbol.name;
#line 631 "kl.rie"
	rrval.rrt_functor.module = rrsasp[-1].rrSymbol.module;
#line 628 "kl.rie"
	rrval.rrt_functor.ps = rrsasp->rrt_argument.ps;
#line 628 "kl.rie"
	rrval.rrt_functor.sps = rrsasp->rrt_argument.sps;
	break;

      case 146:
#line 637 "kl.rie"
	rrval.rrt_argument.num =0;
#line 636 "kl.rie"
	rrval.rrt_argument.ps = rriasp->EC37;
#line 636 "kl.rie"
	rrval.rrt_argument.sps = rriasp->EC36;
	break;

      case 147:
#line 641 "kl.rie"
	rrval.rrt_argument.num = rrsasp[-1].rrt_args.num;
#line 639 "kl.rie"
	rrval.rrt_argument.ps = rrsasp[-1].rrt_args.ps;
#line 639 "kl.rie"
	rrval.rrt_argument.sps = rrsasp[-1].rrt_args.sps;
	break;

      case 148:
#line 648 "kl.rie"
	rrval.rrt_args.num =1;
#line 645 "kl.rie"
	rrval.rrt_args.ps = rrsasp->rrt_arg.ps;
#line 645 "kl.rie"
	rrval.rrt_args.sps = rrsasp->rrt_arg.sps;
	break;

      case 149:
#line 654 "kl.rie"
	rrval.rrt_args.num = rrsasp->rrt_args.num+ 1;
#line 650 "kl.rie"
	rrval.rrt_args.ps = rrsasp->rrt_args.ps;
#line 650 "kl.rie"
	rrval.rrt_args.sps = rrsasp->rrt_args.sps;
	break;

      case 150:
#line 661 "kl.rie"
	rrval.rrt_arg.ps =( rriasp[-1].EC58==1)?NULL: rrsasp->rrt_term.ps;
#line 657 "kl.rie"
	rrval.rrt_arg.sps = rrsasp->rrt_term.sps;
#line 679 "kl.rie"
	{
//		    printf("t_arg: t_arg.level = %d, t_term.ps = %x\n",
//			   t_arg.level, t_term.ps);
		    if ( rriasp[-1].EC58 == 1) {
		      int subproc_id;
		      if ( rriasp[-1].EC56 == NULL)
			subproc_id = -1; // in head
		      else
			subproc_id =  rriasp[-1].EC56->GetID();
		      if ( rrsasp->rrt_term.ps != NULL) {
			 rriasp[-1].EC55->AddPort(subproc_id,  rrsasp->rrt_term.ps);
			if ( rrsasp->rrt_term.ps->next != NULL) {
			   rriasp[-1].EC55->UnifyPorts( rrsasp->rrt_term.ps->id,
						  rrsasp->rrt_term.ps->next);
			}
		      }
		    }
		  }
	break;

      case 151:
#line 683 "kl.rie"
	rrval.rrt_structure.ps = rrsasp->rrt_argument.ps;
#line 683 "kl.rie"
	rrval.rrt_structure.sps = rrsasp->rrt_argument.sps;
	break;

      case 152:
#line 688 "kl.rie"
	rrval.rrt_vector.ps = rrsasp[-1].rrt_vector_contents.ps;
#line 688 "kl.rie"
	rrval.rrt_vector.sps = rrsasp[-1].rrt_vector_contents.sps;
	break;

      case 153:
#line 693 "kl.rie"
	rrval.rrt_vector_contents.ps = rriasp->EC77;
#line 693 "kl.rie"
	rrval.rrt_vector_contents.sps = rriasp->EC76;
	break;

      case 154:
#line 695 "kl.rie"
	rrval.rrt_vector_contents.ps = rrsasp->rrt_vector_elements.ps;
#line 695 "kl.rie"
	rrval.rrt_vector_contents.sps = rrsasp->rrt_vector_elements.sps;
	break;

      case 155:
#line 700 "kl.rie"
	rrval.rrt_vector_elements.ps = rrsasp->rrt_term.ps;
#line 700 "kl.rie"
	rrval.rrt_vector_elements.sps = rrsasp->rrt_term.sps;
	break;

      case 156:
#line 704 "kl.rie"
	rrval.rrt_vector_elements.ps = rrsasp->rrt_vector_elements.ps;
#line 704 "kl.rie"
	rrval.rrt_vector_elements.sps = rrsasp->rrt_vector_elements.sps;
	break;

      case 157:
#line 710 "kl.rie"
	rrval.rrt_unify.ps = rrsasp->rrt_term.ps;
#line 710 "kl.rie"
	rrval.rrt_unify.sps = rrsasp->rrt_term.sps;
	break;

      case 158:
#line 716 "kl.rie"
	rrval.rrt_assign.ps = rriasp[-3].EC93;
#line 716 "kl.rie"
	rrval.rrt_assign.sps = rriasp[-3].EC92;
	break;

      case 159:
#line 731 "kl.rie"
	rrval.rrport_info.h =0;
#line 730 "kl.rie"
	rrval.rrport_info.w =0;
#line 729 "kl.rie"
	rrval.rrport_info.t =0;
#line 728 "kl.rie"
	rrval.rrport_info.l =0;
#line 727 "kl.rie"
	rrval.rrport_info.lr = rrsasp->rrleft_or_right.lr;
#line 726 "kl.rie"
	rrval.rrport_info.type = rrsasp[-1].rrport_type.type;
#line 725 "kl.rie"
	rrval.rrport_info.id = rrsasp[-2].rrInteger.value;
#line 724 "kl.rie"
	rrval.rrport_info.name =(NAMETYPE)get_symbol( rrsasp[-3].rrOpt_VARIABLE.name);
	break;

      case 160:
#line 740 "kl.rie"
	rrval.rrport_info.h = rrsasp->rrpoint_size.h;
#line 739 "kl.rie"
	rrval.rrport_info.w = rrsasp->rrpoint_size.w;
#line 738 "kl.rie"
	rrval.rrport_info.t = rrsasp->rrpoint_size.t;
#line 737 "kl.rie"
	rrval.rrport_info.l = rrsasp->rrpoint_size.l;
#line 736 "kl.rie"
	rrval.rrport_info.lr = rrsasp[-1].rrleft_or_right.lr;
#line 735 "kl.rie"
	rrval.rrport_info.type = rrsasp[-2].rrport_type.type;
#line 734 "kl.rie"
	rrval.rrport_info.id = rrsasp[-3].rrInteger.value;
#line 733 "kl.rie"
	rrval.rrport_info.name =(NAMETYPE)get_symbol( rrsasp[-4].rrOpt_VARIABLE.name);
	break;

      case 161:
#line 750 "kl.rie"
	rrval.rrport_info.h = rrsasp->rrpoint_size.h;
#line 749 "kl.rie"
	rrval.rrport_info.w = rrsasp->rrpoint_size.w;
#line 748 "kl.rie"
	rrval.rrport_info.t = rrsasp->rrpoint_size.t;
#line 747 "kl.rie"
	rrval.rrport_info.l = rrsasp->rrpoint_size.l;
#line 746 "kl.rie"
	rrval.rrport_info.lr = rrsasp[-5].rrleft_or_right.lr;
#line 745 "kl.rie"
	rrval.rrport_info.type = rrsasp[-6].rrport_type.type;
#line 744 "kl.rie"
	rrval.rrport_info.id = rrsasp[-7].rrInteger.value;
#line 743 "kl.rie"
	rrval.rrport_info.name =(NAMETYPE)get_symbol( rrsasp[-3].rrOpt_VARIABLE.name);
	break;

      case 162:
#line 760 "kl.rie"
	rrval.rrport_info.h = rrsasp->rrpoint_size.h;
#line 759 "kl.rie"
	rrval.rrport_info.w = rrsasp->rrpoint_size.w;
#line 758 "kl.rie"
	rrval.rrport_info.t = rrsasp->rrpoint_size.t;
#line 757 "kl.rie"
	rrval.rrport_info.l = rrsasp->rrpoint_size.l;
#line 756 "kl.rie"
	rrval.rrport_info.lr = rrsasp[-6].rrleft_or_right.lr;
#line 755 "kl.rie"
	rrval.rrport_info.type = rrsasp[-7].rrport_type.type;
#line 754 "kl.rie"
	rrval.rrport_info.id = rrsasp[-8].rrInteger.value;
#line 753 "kl.rie"
	rrval.rrport_info.name =(NAMETYPE)get_symbol( rrsasp[-4].rrOpt_VARIABLE.name);
	break;

      case 163:
#line 769 "kl.rie"
	rrval.rrport_info.h = rrsasp->rrpoint_size.h;
#line 768 "kl.rie"
	rrval.rrport_info.w = rrsasp->rrpoint_size.w;
#line 767 "kl.rie"
	rrval.rrport_info.t = rrsasp->rrpoint_size.t;
#line 766 "kl.rie"
	rrval.rrport_info.l = rrsasp->rrpoint_size.l;
#line 765 "kl.rie"
	rrval.rrport_info.lr = rrsasp[-1].rrleft_or_right.lr;
#line 764 "kl.rie"
	rrval.rrport_info.type = rrsasp[-2].rrport_type.type;
#line 763 "kl.rie"
	rrval.rrport_info.id =-1;
#line 762 "kl.rie"
	rrval.rrport_info.name =(NAMETYPE)get_symbol( rrsasp[-3].rrOpt_VARIABLE.name);
	break;

      case 164:
#line 778 "kl.rie"
	rrval.rrport_info.h = rrsasp->rrpoint_size.h;
#line 777 "kl.rie"
	rrval.rrport_info.w = rrsasp->rrpoint_size.w;
#line 776 "kl.rie"
	rrval.rrport_info.t = rrsasp->rrpoint_size.t;
#line 775 "kl.rie"
	rrval.rrport_info.l = rrsasp->rrpoint_size.l;
#line 774 "kl.rie"
	rrval.rrport_info.lr = rrsasp[-1].rrleft_or_right.lr;
#line 773 "kl.rie"
	rrval.rrport_info.type = rrsasp[-2].rrport_type.type;
#line 772 "kl.rie"
	rrval.rrport_info.id = rrsasp[-3].rrInteger.value;
#line 771 "kl.rie"
	rrval.rrport_info.name =(NAMETYPE)get_symbol( rrsasp[-4].rrOpt_VARIABLE.name);
	break;

      case 165:
#line 787 "kl.rie"
	rrval.rrport_info.h =0;
#line 786 "kl.rie"
	rrval.rrport_info.w =0;
#line 785 "kl.rie"
	rrval.rrport_info.t =0;
#line 784 "kl.rie"
	rrval.rrport_info.l =0;
#line 783 "kl.rie"
	rrval.rrport_info.lr = rrsasp[-1].rrleft_or_right.lr;
#line 782 "kl.rie"
	rrval.rrport_info.type = rrsasp[-2].rrport_type.type;
#line 781 "kl.rie"
	rrval.rrport_info.id =-1;
#line 780 "kl.rie"
	rrval.rrport_info.name =(NAMETYPE)get_symbol( rrsasp[-3].rrOpt_VARIABLE.name);
	break;

      case 166:
#line 797 "kl.rie"
	rrval.rrport_info.h =0;
#line 796 "kl.rie"
	rrval.rrport_info.w =0;
#line 795 "kl.rie"
	rrval.rrport_info.t =0;
#line 794 "kl.rie"
	rrval.rrport_info.l =0;
#line 793 "kl.rie"
	rrval.rrport_info.lr = rrsasp[-1].rrleft_or_right.lr;
#line 792 "kl.rie"
	rrval.rrport_info.type = rrsasp[-2].rrport_type.type;
#line 791 "kl.rie"
	rrval.rrport_info.id = rrsasp[-3].rrInteger.value;
#line 790 "kl.rie"
	rrval.rrport_info.name =(NAMETYPE)get_symbol( rrsasp[-4].rrOpt_VARIABLE.name);
	break;

      case 167:
#line 847 "kl.rie"
	rrval.rrport_type.type =port_single_in;
	break;

      case 168:
#line 849 "kl.rie"
	rrval.rrport_type.type =port_single_out;
	break;

      case 169:
#line 851 "kl.rie"
	rrval.rrport_type.type =port_stream_in;
	break;

      case 170:
#line 853 "kl.rie"
	rrval.rrport_type.type =port_stream_out;
	break;

      case 171:
#line 856 "kl.rie"
	rrval.rrleft_or_right.lr =Port_Null;
	break;

      case 172:
#line 858 "kl.rie"
	rrval.rrleft_or_right.lr =Port_Left;
	break;

      case 173:
#line 860 "kl.rie"
	rrval.rrleft_or_right.lr =Port_Right;
	break;

      case 181:
#line 879 "kl.rie"
	 rriasp[-1].EC103->AddLink( rriasp[-1].EC102, rrsasp->rrInteger.value);
	break;

      case 182:
#line 887 "kl.rie"
	window_set_state(WINDOW_STATE_DEAD);
	break;

      case 185:
#line 904 "kl.rie"
	{ update( rrsasp[-5].rrtr_goalid.id,
				    rrsasp[-4].rrtr_action.act,
				    rrsasp[-2].rrtr_head.t,
				    rrsasp[-1].rrtr_subgoal_part.sg);
			    free( rrsasp[-1].rrtr_subgoal_part.sg);
			    // printf("ACCEPT(type %s)\n", ActType_to_str(tr_action.act));
			    if (window_get_state() != WINDOW_STATE_RUNNING)
			      return 1;	// XXX
			    if (tracing_mode != TRACE_LOGFILE) // XXX
			      subprocess_send("\n");	       // XXX
			  }
	break;

      case 186:
#line 909 "kl.rie"
	rrval.rrtr_head.module =((term_functor*) rrsasp->rrtr_functor.t)->GetModule();
#line 908 "kl.rie"
	rrval.rrtr_head.t = rrsasp->rrtr_functor.t;
	break;

      case 187:
#line 912 "kl.rie"
	rrval.rrtr_goalid.id = rrsasp->rrInteger.value;
	break;

      case 188:
#line 917 "kl.rie"
	rrval.rrtr_action.act =str_to_ActType( rrsasp->rrVariable.name);
	break;

      case 189:
#line 921 "kl.rie"
	rrval.rrtr_term.t = rrsasp->rrtr_functor.t;
	break;

      case 190:
#line 925 "kl.rie"
	rrval.rrtr_term.t =env_getvar( rrsasp->rrVariable.name);
	break;

      case 191:
#line 928 "kl.rie"
	rrval.rrtr_term.t =alloc_term_integer( rrsasp->rrInteger.value);
	break;

      case 192:
#line 930 "kl.rie"
	rrval.rrtr_term.t = rrsasp->rrtr_list.t;
	break;

      case 193:
#line 938 "kl.rie"
	rrval.rrtr_functor.arity = rrsasp->rrtr_argument.num;
#line 937 "kl.rie"
	rrval.rrtr_functor.name = rrsasp[-1].rrSymbol.name;
#line 936 "kl.rie"
	rrval.rrtr_functor.module = rrsasp[-1].rrSymbol.module;
#line 935 "kl.rie"
	rrval.rrtr_functor.t = rrsasp->rrtr_argument.ts;
#line 939 "kl.rie"
	{ ((RFUNCTYPE)  rrsasp->rrtr_argument.ts)->SetArity( rrsasp->rrtr_argument.num); }
	break;

      case 194:
#line 944 "kl.rie"
	rrval.rrtr_argument.ts = rriasp->EC104;
#line 943 "kl.rie"
	rrval.rrtr_argument.num =0;
	break;

      case 195:
#line 947 "kl.rie"
	rrval.rrtr_argument.ts = rrsasp[-1].rrtr_args.ts;
#line 946 "kl.rie"
	rrval.rrtr_argument.num = rrsasp[-1].rrtr_args.num;
	break;

      case 196:
#line 951 "kl.rie"
	rrval.rrtr_args.ts = rrsasp->rrtr_arg.ts;
#line 950 "kl.rie"
	rrval.rrtr_args.num =1;
	break;

      case 197:
#line 954 "kl.rie"
	rrval.rrtr_args.ts = rrsasp->rrtr_args.ts;
#line 953 "kl.rie"
	rrval.rrtr_args.num = rrsasp->rrtr_args.num+ 1;
	break;

      case 198:
#line 958 "kl.rie"
	rrval.rrtr_arg.ts = rriasp[-1].EC105;
#line 957 "kl.rie"
	{ ((RFUNCTYPE)  rriasp[-1].EC105)->AppendArg( rrsasp->rrtr_term.t);}
	break;

      case 199:
#line 961 "kl.rie"
	rrval.rrtr_list.t = rrsasp[-1].rrtr_list_contents.th;
	break;

      case 200:
#line 965 "kl.rie"
	rrval.rrtr_list_contents.tt =(RCONSTYPE)NIL;
#line 964 "kl.rie"
	rrval.rrtr_list_contents.th =(RCONSTYPE)NIL;
	break;

      case 201:
#line 968 "kl.rie"
	rrval.rrtr_list_contents.tt = rrsasp->rrtr_list_elements.tt;
#line 967 "kl.rie"
	rrval.rrtr_list_contents.th = rrsasp->rrtr_list_elements.th;
#line 969 "kl.rie"
	 rrsasp->rrtr_list_elements.tt->SetCdr(NIL);
	break;

      case 202:
#line 972 "kl.rie"
	rrval.rrtr_list_contents.tt = rrsasp[-2].rrtr_list_elements.tt;
#line 971 "kl.rie"
	rrval.rrtr_list_contents.th = rrsasp[-2].rrtr_list_elements.th;
#line 973 "kl.rie"
	 rrsasp[-2].rrtr_list_elements.tt->SetCdr( rrsasp->rrtr_term.t);
	break;

      case 203:
#line 976 "kl.rie"
	rrlasp->C2.cell_203 =new term_cons( rrsasp->rrtr_term.t,NIL);
#line 978 "kl.rie"
	rrval.rrtr_list_elements.tt = rrlasp->C2.cell_203;
#line 977 "kl.rie"
	rrval.rrtr_list_elements.th = rrlasp->C2.cell_203;
	break;

      case 204:
#line 981 "kl.rie"
	rrlasp->C3.cell_204 =new term_cons( rrsasp[-2].rrtr_term.t, rrsasp->rrtr_list_elements.th);
#line 983 "kl.rie"
	rrval.rrtr_list_elements.tt = rrsasp->rrtr_list_elements.tt;
#line 982 "kl.rie"
	rrval.rrtr_list_elements.th = rrlasp->C3.cell_204;
	break;

      case 205:
#line 985 "kl.rie"
	rrval.rrtr_subgoal_part.sg =NULL;
	break;

      case 206:
#line 987 "kl.rie"
	rrval.rrtr_subgoal_part.sg = rrsasp->rrtr_subgoals.g;
	break;

      case 207:
#line 991 "kl.rie"
	rrval.rrtr_subgoals.g = rrsasp->rrtr_subgoal.g;
	break;

      case 208:
#line 994 "kl.rie"
	rrval.rrtr_subgoals.g = rrsasp[-1].rrtr_subgoal.g;
#line 998 "kl.rie"
	{ //printf("Set next of %d\n", tr_subgoal.g->GetID());
			     rrsasp[-1].rrtr_subgoal.g->SetNext( rrsasp->rrtr_subgoals.g); }
	break;

      case 209:
#line 1006 "kl.rie"
	rrval.rrtr_subgoal.g =new rsubgoal( rrsasp[-4].rrtr_goalid.id, rrsasp[-3].rrInteger.value,':', rrsasp[-1].rrtr_sub_state.state, rrsasp->rrtr_term.t);
#line 1009 "kl.rie"
	{ if (((term_functor*) rrsasp->rrtr_term.t)->GetModule() == NULL) 
		            ((term_functor*) rrsasp->rrtr_term.t)->SetModule( rriasp[-5].EC109);
		  }
	break;

      case 210:
#line 1016 "kl.rie"
	rrval.rrtr_subgoal.g =new rsubgoal( rrsasp[-4].rrtr_goalid.id, rrsasp[-3].rrInteger.value,'!', rrsasp[-1].rrtr_sub_state.state, rrsasp->rrtr_term.t);
#line 1019 "kl.rie"
	{ if (((term_functor *) rrsasp->rrtr_term.t)->GetModule() == NULL) 
		  ((term_functor*) rrsasp->rrtr_term.t)->SetModule( rriasp[-5].EC109);
		  }
	break;

      case 211:
#line 1023 "kl.rie"
	rrval.rrtr_sub_state.state ='+';
	break;

      case 212:
#line 1025 "kl.rie"
	rrval.rrtr_sub_state.state ='-';
	break;

    }


#line 727 "/usr/local/lib/rie-1.0.6/rie.simple"

   /* the action file gets copied in in place of this dollarsign */
#line 730 "bison.simple"
#line 731 "/usr/local/lib/rie-1.0.6/rie.simple"

#ifdef NOT_RIE
  yyvsp -= yylen;
#endif
  yyssp -= yylen;
#ifdef YYLSP_NEEDED
  yylsp -= yylen;
#endif
#ifdef RIE_SOME_SYNTHESIZE
  rrsasp -= yylen;
#endif
#ifdef RIE_SOME_INHERIT
  rriasp -= yylen;
#endif
#ifdef RIE_SOME_LOCAL
  rrlasp -= yylen;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

#ifdef NOT_RIE
  *++yyvsp = yyval;
#endif

#ifdef RIE_SOME_SYNTHESIZE
  *++rrsasp = rrval;
#endif

#ifdef YYLSP_NEEDED
  yylsp++;
  if (yylen == 0)
    {
      yylsp->first_line = yylloc.first_line;
      yylsp->first_column = yylloc.first_column;
      yylsp->last_line = (yylsp-1)->last_line;
      yylsp->last_column = (yylsp-1)->last_column;
      yylsp->text = 0;
    }
  else
    {
      yylsp->last_line = (yylsp+yylen-1)->last_line;
      yylsp->last_column = (yylsp+yylen-1)->last_column;
    }
#endif

  /* Now "shift" the result of the reduction.
     Determine what state that goes to,
     based on the state we popped back to
     and the rule number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTBASE] + *yyssp;
  if (yystate >= 0 && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTBASE];

  goto yynewstate;

yyerrlab:   /* here on detecting error */

  if (! yyerrstatus)
    /* If not already recovering from an error, report this error.  */
    {
      ++yynerrs;

#ifdef YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (yyn > YYFLAG && yyn < YYLAST)
	{
	  int size = 0;
	  char *msg;
	  int x, count;

	  count = 0;
	  /* Start X at -yyn if nec to avoid negative indexes in yycheck.  */
	  for (x = (yyn < 0 ? -yyn : 0);
	       x < (sizeof(yytname) / sizeof(char *)); x++)
	    if (yycheck[x + yyn] == x)
	      size += strlen(yytname[x]) + 15, count++;
	  msg = (char *) malloc(size + 15);
	  if (msg != 0)
	    {
	      strcpy(msg, "parse error");

	      if (count < 5)
		{
		  count = 0;
		  for (x = (yyn < 0 ? -yyn : 0);
		       x < (sizeof(yytname) / sizeof(char *)); x++)
		    if (yycheck[x + yyn] == x)
		      {
			strcat(msg, count == 0 ? ", expecting `" : " or `");
			strcat(msg, yytname[x]);
			strcat(msg, "'");
			count++;
		      }
		}
	      yyerror(msg);
	      free(msg);
	    }
	  else
	    yyerror ("parse error; also virtual memory exceeded");
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror("parse error");
    }

  goto yyerrlab1;
yyerrlab1:   /* here on error raised explicitly by an action */

  if (yyerrstatus == 3)
    {
      /* if just tried and failed to reuse lookahead token after an error, discard it.  */

      /* return failure if at end of input */
      if (yychar == YYEOF)
	YYABORT;

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Discarding token %d (%s).\n", yychar, yytname[yychar1]);
#endif

      yychar = YYEMPTY;
    }

  /* Else will try to reuse lookahead token
     after shifting the error token.  */

  yyerrstatus = 3;		/* Each real token shifted decrements this */

  goto yyerrhandle;

yyerrdefault:  /* current state does not do anything special for the error token. */

#if 0
  /* This is wrong; only states that explicitly want error tokens
     should shift them.  */
  yyn = yydefact[yystate];  /* If its default is to accept any token, ok.  Otherwise pop it.*/
  if (yyn) goto yydefault;
#endif

yyerrpop:   /* pop the current state because it cannot handle the error token */

  if (yyssp == yyss) YYABORT;
#ifdef NOT_RIE
  yyvsp--;
#endif
  yystate = *--yyssp;
#ifdef YYLSP_NEEDED
  yylsp--;
#endif
#ifdef RIE_SOME_SYNTHESIZE
  rrsasp--;
#endif
#ifdef RIE_SOME_INHERIT
  rriasp--;
#endif
#ifdef RIE_SOME_LOCAL
  rrlasp--;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "Error: state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

yyerrhandle:

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yyerrdefault;

  yyn += YYTERROR;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != YYTERROR)
    goto yyerrdefault;

  yyn = yytable[yyn];
  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrpop;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrpop;

  if (yyn == YYFINAL)
    {
#ifdef RIE_SOME_SYNTHESIZE
      rrlval = *--rrsasp;	/* return the last synthesized value.  */
#endif
    YYACCEPT;
    }

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting error token, ");
#endif

#ifdef NOT_RIE
  *++yyvsp = yylval;
#endif
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

#ifdef RIE_SOME_SYNTHESIZE
  *++rrsasp = rrlval;
#endif
  
  yystate = yyn;
  goto yynewstate;
}
#line 1027 "kl.rie"


/* eof */
