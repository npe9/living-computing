// Copyright (C) 1999  Toyoda Masashi (toyoda@is.titech.ac.jp)

extern Am_Object TopItemProto;
extern Am_Object ItemProto;
extern Am_Object TextItemProto;
extern Am_Object LinkInteractor;
extern Am_Object LinkMaker;

EXPORT_SLOT(MochiItems);
EXPORT_SLOT(MId);

extern Am_Object* items;

extern void Initialize_Item(void);
extern void Initialize_Hyperlink(Am_Object top_window);

extern Am_Object Item_Get_Parent(Am_Object item);
extern void Item_Add(Am_Object target, Am_Object obj);
extern void Item_Remove(Am_Object target, Am_Object obj);
extern void Item_Set_LImage(Am_Object item, char* filename);
extern void Item_Set_SImage(Am_Object item, char* filename);
extern void Item_Set_HLink(Am_Object item, Am_Object des);
extern void Item_Remove_Link(Am_Object item);
extern void Item_Retrieve_Link(Am_Object item, Am_Object selection);
extern void Item_Set_Link_Visibility(Am_Object item, bool visible);
extern void Item_Toggle_Link_Visibility(Am_Object item);
extern void Item_Save(char* name);
extern void Item_Load(Am_Object item, char* name);
extern void Item_Save_to_file(Am_Object top_module, ofstream& ofile);
extern void Item_Load_from_file(Am_Object item, ifstream& ifile);


