#ifndef YYSTYPE
#define YYSTYPE int
#endif
typedef
  union
    {
      struct {
	char	state;
      } rrtr_sub_state;

      struct {
	RSUBGTYPE	g;
      } rrtr_subgoal, rrtr_subgoals;

      struct {
	RSUBGTYPE	sg;
      } rrtr_subgoal_part;

      struct {
	RCONSTYPE	tt;
	RCONSTYPE	th;
      } rrtr_list_elements, rrtr_list_contents;

      struct {
	int	num;
	RTERMTYPE	ts;
      } rrtr_args, rrtr_arg, rrtr_argument;

      struct {
	int	arity;
	NAMETYPE	name;
	NAMETYPE	module;
	RTERMTYPE	t;
      } rrtr_head, rrtr_list, rrtr_functor, rrtr_term;

      struct {
	ActType	act;
      } rrtr_action;

      struct {
	SUBPROCTYPE	sps;
	PORTTYPE	ps;
	int	num;
      } rrt_merge, rrt_assign, rrt_unify, rrt_structure, rrt_vector_elements
      , rrt_vector_contents, rrt_vector, rrt_list_elements, rrt_list_contents, rrt_list
      , rrt_arg, rrt_term_info, rrt_term_body, rrt_term, rrt_args
      , rrt_argument, rrargs, rrargument;

      struct {
	SUBPROCTYPE	sps;
	PORTTYPE	ps;
	int	arity;
	NAMETYPE	name;
	NAMETYPE	module;
      } rrt_functor, rrsubproc_infos, rrsubproc_info;

      struct {
	SUBPROCTYPE	sp;
      } rrsubproc;

      struct {
	int	arity;
	NAMETYPE	name;
      } rrfunctor, rrhead;

      struct {
	RuleType	rt;
      } rrrule_type;

      struct {
	RULETYPE	rule;
      } rrruledef;

      struct {
	ArrangeOption	option;
      } rrarrange_option;

      struct {
	ExpandMethod	arrange;
      } rrarrange_info;

      struct {
	int	h;
	int	w;
	int	t;
	int	l;
	int	lr;
	PortType	type;
	int	id;
	NAMETYPE	name;
      } rrtr_goalid, rrleft_or_right, rrport_type, rrport_info, rrpoint_size
      , rrproc_type;

      struct {
	PROCTYPE	proc;
      } rrprocdef, rrprocess;

      struct {
	NAMETYPE	str;
      } rrString;

      struct {
	NAMETYPE	name;
	NAMETYPE	module;
      } rrOpt_VARIABLE, rrOpt_SYMBOL, rrVariable, rrSymbol;

      struct {
	int	value;
      } rrInteger;

    }
  rrsastype;

extern rrsastype rrlval;

#define	Imply	258
#define	Assign	259
#define	Mod	260
#define	Land	261
#define	Lor	262
#define	Nequal	263
#define	Integer	264
#define	Symbol	265
#define	Variable	266
#define	String	267
#define	Opt_define	268
#define	Opt_port	269
#define	Opt_size	270
#define	Opt_point	271
#define	Opt_type	272
#define	Opt_guard	273
#define	Opt_rule	274
#define	Opt_rule_id	275
#define	Opt_mesg	276
#define	Opt_atom	277
#define	Opt_merge	278
#define	Opt_from	279
#define	Opt_into	280
#define	Opt_link	281
#define	Opt_unify	282
#define	Opt_assign	283
#define	Opt_list	284
#define	Opt_proc	285
#define	Opt_begin	286
#define	Opt_proc_part	287
#define	Opt_other_part	288
#define	Opt_end	289
#define	Opt_comment	290
#define	Opt_creator	291
#define	Opt_normal	292
#define	Opt_network	293
#define	Opt_vanishing	294
#define	Opt_continuous	295
#define	Opt_transition	296
#define	Opt_stream	297
#define	Opt_single	298
#define	Opt_left	299
#define	Opt_right	300
#define	Opt_arrange	301
#define	Opt_rightward	302
#define	Opt_downward	303
#define	Opt_show_all	304
#define	Opt_pattern_top	305
#define	Opt_pattern	306
#define	Opt_layout	307
#define	Opt_modifier	308
#define	Opt_dropper	309
#define	Opt_ctime	310
#define	Opt_mtime	311
#define	Opt_dtime	312
#define	Opt_SYMBOL	313
#define	Opt_VARIABLE	314


extern YYSTYPE yylval;
