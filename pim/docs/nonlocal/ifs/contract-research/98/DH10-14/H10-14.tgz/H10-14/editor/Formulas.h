// Copyright (C) 1997,1998  Toyoda Masashi (toyoda@is.titech.ac.jp)

#ifndef _INTERNAL_

// Methods
Am_Define_Method_Type(Drop_Method, bool, (Am_Object, Am_Object, Am_Object));
Am_Define_Method_Type(Bin_Check_Method, bool, (Am_Object, Am_Object));

// Formulas
extern Am_Constraint* Am_From_Sibling_Plus (Am_Slot_Key sibling, Am_Slot_Key key, int diff);
extern Am_Constraint* Am_From_Owner_Plus(Am_Slot_Key key, int diff);
extern Am_Constraint* Am_From_Object(Am_Object& object, Am_Slot_Key key);
extern Am_Formula CenterXForm;
extern Am_Formula CenterYForm;
Am_Constraint* Bellow_Of_Sibling(Am_Slot_Key key);
Am_Constraint* Right_Of_Sibling(Am_Slot_Key key);
extern Am_Formula Fill_To_Bottom;

// Normal Functions
int CenterX(Am_Object obj);
int CenterY(Am_Object obj);
void Center_Of_Object(Am_Object obj, int& cx, int& cy);
void Left_Top_Of_Object_By_Center(Am_Object obj, int cx, int cy, int& left, int& top);
int Distance_Of_Objects(Am_Object obj1, Am_Object obj2);
Am_Object Find_Instance_Of(Am_Object group, int x, int y, Am_Object ref, Am_Object proto);

int Object_List_Index(Am_Value_List list, Am_Object value);
Am_Inter_Location Location_List_Get(Am_Value_List list, int i);
Am_Object Object_List_Get(Am_Value_List list, int i);
Am_Object Object_List_Get_By_Key(Am_Value_List list, Am_Slot_Key key, Am_String s);
int Object_List_Max(Am_Value_List list, Am_Slot_Key key);
int Group_Index(Am_Object obj);
Am_Object Group_Get_By_Index(Am_Object group, int idx);
int String_List_Index(Am_Value_List list, Am_String value);
void Value_List_Slot_Add(Am_Object parent, Am_Slot_Key list_slot, Am_Object obj);
void Value_List_Slot_Remove(Am_Object parent, Am_Slot_Key list_slot, Am_Object obj);

#endif

