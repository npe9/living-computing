// Copyright (C) 1997  Toyoda Masashi (toyoda@is.titech.ac.jp)

#include <amulet.h>
#include INTER_ADVANCED__H 
#include FORMULA_ADVANCED__H

#include <strstream.h>
#include <time.h>

#include "ToyWidgets.h"
#include "Port.h"
#include "Module.h"
#include "Message.h"
#include "Process.h"
#include "Rule.h"
#include "Pattern.h"
#include "Binder.h"

// ------------------------------------------------------------
// Common Slots
// ------------------------------------------------------------

// Models --------
DEFINE_SLOT(Name);
DEFINE_SLOT(ModuleList);
DEFINE_SLOT(ModuleNameList);
DEFINE_SLOT(Process);
DEFINE_SLOT(ProcessList);
DEFINE_SLOT(ProcessNameList);
DEFINE_SLOT(PatternList);
DEFINE_SLOT(PatternNameList);
DEFINE_SLOT(ProcPatternList);
DEFINE_SLOT(ProcPatternNameList);
DEFINE_SLOT(Hole);
DEFINE_SLOT(HoleList);
DEFINE_SLOT(HoleNameList);
DEFINE_SLOT(RuleList);
DEFINE_SLOT(PortList);
DEFINE_SLOT(PortNameList);
DEFINE_SLOT(InnerPortList);
DEFINE_SLOT(InnerPortNameList);
DEFINE_SLOT(GuardList);
DEFINE_SLOT(ValueList);
DEFINE_SLOT(NameList);
DEFINE_SLOT(MainRule);

// Processes
DEFINE_SLOT(Module);
DEFINE_SLOT(ModuleName);
DEFINE_SLOT(RuleVisible);

// Ports
DEFINE_SLOT(Mode);
DEFINE_SLOT(Type);
DEFINE_SLOT(Dir);
DEFINE_SLOT(Age);
DEFINE_SLOT(State);
DEFINE_SLOT(Special);
DEFINE_SLOT(Values);
DEFINE_SLOT(Binders);
DEFINE_SLOT(InputBinders);
DEFINE_SLOT(InnerBinders);
DEFINE_SLOT(OutputBinders);
DEFINE_SLOT(HoleBinders);

// Binders --------
DEFINE_SLOT(SrcPort);
DEFINE_SLOT(DestPort);

// Patterns --------
DEFINE_SLOT(LayoutNameList);
DEFINE_SLOT(LayoutSizeList);

// Views --------
DEFINE_SLOT(Parent);
DEFINE_SLOT(Model);
DEFINE_SLOT(ToCopyModel);
DEFINE_SLOT(FramePart);
DEFINE_SLOT(ContentsPart);
DEFINE_SLOT(NamePart);
DEFINE_SLOT(MarkerPart);
DEFINE_SLOT(IconPart);
DEFINE_SLOT(BindersPart);

DEFINE_SLOT(MenuPopper);
DEFINE_SLOT(NameHeightMax);

// Rename Method
DEFINE_SLOT(NamingMethod);
// Add Methods
DEFINE_SLOT(AddMethod);
DEFINE_SLOT(RemoveMethod);
// Copying Methods
DEFINE_SLOT(NewMethod);
DEFINE_SLOT(CopyMethod);
DEFINE_SLOT(CopyAllMethod);

// For Translator --------
DEFINE_SLOT(Id);
DEFINE_SLOT(NextId);
DEFINE_SLOT(InnerName);
DEFINE_SLOT(InnerNextName);
DEFINE_SLOT(GenOrder);
DEFINE_SLOT(Priority);

// User...
DEFINE_SLOT(User);
DEFINE_SLOT(Creator);
DEFINE_SLOT(CreatedTime);
DEFINE_SLOT(Modifier);
DEFINE_SLOT(ModifiedTime);
DEFINE_SLOT(Dropper);
DEFINE_SLOT(DroppedTime);
DEFINE_SLOT(ReplPatternView);


// ------------------------------------------------------------
// Utility Functions
// ------------------------------------------------------------

// User Utility
// ----------------------------------------------------------------------

void Set_User_Name(Am_Object obj,
		   Am_Slot_Key name_key, Am_String name,
		   Am_Slot_Key time_key, int tm)
{
  if (obj.Get_Slot_Type(name_key) && obj.Get_Slot_Type(time_key)) {
    if (strcmp(name, "") != 0) obj.Set(name_key, name);
    else                       obj.Set(name_key, TopModule.Get(User));

    if (tm != 0) obj.Set(time_key, tm);
    else         obj.Set(time_key, (int)time(NULL));
  }
}


// Path Utility
// A path is a list such as ( type, idx, type, idx, type, idx, ... )
// -----------------------------------------------------------------------

// Path types
#define PathProcess   1
#define PathHole      2
#define PathPort      3
#define PathValue     4
#define PathBinder    5


Am_Object Path_To_Obj(Am_Object root, Am_Value_List path)
{
  Am_Object node = root;
  for (path.Start(); !path.Last(); path.Next()) {
    int type = path.Get();  path.Next();
    int idx  = path.Get();
    Am_Slot_Key list_slot = 0;
    if      (type == PathProcess) list_slot = ProcessList;
    else if (type == PathHole)    list_slot = HoleList;
    else if (type == PathPort)    list_slot = PortList;
    else if (type == PathValue)   list_slot = ValueList;
    else if (type == PathBinder)  list_slot = Binders;
    else return node;
    if (!node.Valid()) return 0;
    Am_Value_List obj_list = node.Get(list_slot);
    node = Object_List_Get(obj_list, idx);
  }
  return node;
}

Am_Value_List Obj_To_Path(Am_Object obj, Am_Object root)
{
  Am_Value_List path = Am_Value_List();
  if (obj == root) return path;
  Am_Object pivot = obj;
  Am_Object parent = obj.Get(Parent);
  while (pivot != root) {
    if (!pivot.Valid() || !parent.Valid()) return 0;
    int type = 0;
    int idx  = 0;
    if (pivot.Is_Instance_Of(ProcessProto) || pivot.Is_Instance_Of(PatternProto)) {
      type = PathProcess;
      idx = Object_List_Index(parent.Get(ProcessList), pivot);
    }
    else if (pivot.Is_Instance_Of(HoleProto)) {
      type = PathHole;
      idx = Object_List_Index(parent.Get(HoleList), pivot);
    }
    else if (parent.Is_Instance_Of(PortProto) || parent.Is_Instance_Of(MessageProto)) {
      type = PathValue;
      idx = Object_List_Index(parent.Get(ValueList), pivot);
    }
    else if (pivot.Is_Instance_Of(PortProto) && !parent.Is_Instance_Of(PortProto)) {
      type = PathPort;
      idx = Object_List_Index(parent.Get(PortList), pivot);
    }
    else if (pivot.Is_Instance_Of(BinderProto)) {
      type = PathBinder;
      idx = Object_List_Index(parent.Get_Part(BindersPart).Get(Am_GRAPHICAL_PARTS), pivot);
    }
    else { cerr << "Obj_To_Path: no such path, " << pivot << parent << endl; }
    path.Add(idx, Am_HEAD);
    path.Add(type, Am_HEAD);
    //    cout << "add " << idx << " " << type << " by " << pivot << parent << endl;
    pivot = parent;
    parent = parent.Get(Parent);
  }
  return path;
}

// Renaming utilities
// -------------------
void Propagate_Rename(Am_Object obj, Am_String name)
{
  Am_Value_List propagate_list = Change_Propagate_List(obj);
  for (propagate_list.Start(); !propagate_list.Last(); propagate_list.Next()) {
    Am_Object o = propagate_list.Get();
    o.Get_Object(Model).Set(Name, name);
  }
  propagate_list.Make_Empty();
}

bool Member_Name(Am_Object obj, Am_Slot_Key list_key, char* name)
{
  Am_Value_List name_list = obj.Get(list_key);
  name_list.Start();
  bool result = name_list.Member(name);
  name_list.Start();
  return result;
}

Am_String Next_Name(Am_Object obj, Am_Slot_Key list_key, char* base)
// base $B$r(Bprefix$B$H$7$?%W%m%;%9Cf$G%f%K!<%/$JL>A0$rJV$9!%(B
{
  char name[1000];
  ostrstream oname(name, 1000);
  Am_Value_List name_list = obj.Get(list_key);
  name_list.Start();
  if (!name_list.Member(base)) {
    oname << base << '\0';
  } else {
    int i = 0; do {
      i = i + 1;
      oname.seekp(0, ios::beg);
      oname << base << i << '\0';
    } while (name_list.Start(), name_list.Member(name));
  }
  name_list.Start();
  return (Am_String)name;
}

/*
void Add_Name(Am_Object obj, Am_Slot_Key list_key, char* name)
{
  obj.Make_Unique(list_key);
  Am_Value_List name_list = obj.Get(list_key);
  if (name_list.Empty()) {
    obj.Set(list_key, name_list.Add(name));
  } else {
    name_list.Add(name, Am_TAIL, false);
    obj.Note_Changed(list_key);
  }
}

void Remove_Name(Am_Object obj, Am_Slot_Key list_key, char* name)
{
  obj.Make_Unique(list_key);
  Am_Value_List name_list = obj.Get(list_key);
  name_list.Start();
  if (name_list.Member(name)) {
    name_list.Delete(false);
    obj.Note_Changed(list_key);
  } else {
    cerr << "No " << name << " in " << obj << endl;
  }
  name_list.Start();
}
*/ 

// Add and Remove utilities
// ------------------------
void Propagate_Add(Am_Object des, Am_Object src)
  // src$B$O%3%T!<:Q$_$N$b$N(B
  // Copy()$B$G%3%T!<$G$-$k$b$N$K8B$k(B(pattern,process$B0J30(B)
  // $B%A%'%C%/$ODL$C$F$$$k$H$_$J$9(B
{
  Am_Value_List propagate_list = Change_Propagate_List(des);
  //  cerr << propagate_list << endl;

  Am_Object copy = src;
  for (propagate_list.Start(); !propagate_list.Last(); propagate_list.Next()) {
    Am_Object d = propagate_list.Get();
    d.Get_Part(ContentsPart).Add_Part(copy);
    if (!propagate_list.Last()) copy = src.Copy();
  }
  propagate_list.Make_Empty();
}

void Propagate_Remove(Am_Object obj)
  // Remove_From_Owner()$B$G:o=|$9$k$N$GCm0U(B
{
  Am_Value_List propagate_list = Change_Propagate_List(obj);

  for (propagate_list.Start(); !propagate_list.Last(); propagate_list.Next()) {
    Am_Object o = propagate_list.Get();
    o.Remove_From_Owner();
  }
  propagate_list.Make_Empty();
}

// $BL>A0$+$i%]!<%H$rC5$9!#(B
// ---------------------
Am_Object Proc_Get_Port(Am_Object process, char* name)
{
  Am_Value_List ports = process.Get(PortList);
  for (ports.Start(); !ports.Last(); ports.Next()) {
    Am_Object pt = ports.Get();
    Am_String port_name = (Am_String)pt.Get_Object(Model).Get(Name);
    if (port_name == name) {
      return pt;
    }
  }
  return 0;
}

// Model$B$N%9%m%C%H$NJ8;zNs$,0lCW$9$k%*%V%8%'%/%H$rC5$9!#(B
Am_Object Object_List_Get_By_Model_Key(Am_Value_List list, Am_Slot_Key key, Am_String s)
{
  for (list.Start(); !list.Last(); list.Next()) {
    Am_Object item = (Am_Object)list.Get();
    Am_Object model = item.Get_Object(Model);
    if (model.Valid()) {
      if ((Am_String)model.Get(key) == s) {
	return item;
      }
    }
  }
  return 0;
}  

Am_Object ObjectListGetByModelKeyForm(Am_Value_List list, Am_Slot_Key key, Am_String s, Am_Constraint_Context& cc)
{
  for (list.Start(); !list.Last(); list.Next()) {
    Am_Object item = (Am_Object)list.Get();
    Am_Object model = item.GV_Object(Model);
    if (model.Valid()) {
      if ((Am_String)model.GV(key) == s) {
	return item;
      }
    }
  }
  return 0;
}  

// $B?F%k!<%k$^$?$O%Q%?!<%s$rC5$9!#(B
bool Is_Network(Am_Object obj)
{
  return obj.Is_Instance_Of(RuleProto) ||
         obj.Is_Instance_Of(PatternProto) ||
         obj.Is_Instance_Of(ReplPatternProto);
}

Am_Object Parent_Rule(Am_Object obj)
{
  Am_Object parent = obj;
  if (parent.Get_Slot_Type(Parent) == Am_NONE) return 0;
  while((parent = parent.Get(Parent)).Valid()) {
    if (Is_Network(parent)) return parent;
    if (parent.Get_Slot_Type(Parent) == Am_NONE) return 0;
  }
  return 0;
}

Am_Object Parent_Rule_In_Form(Am_Constraint_Context& cc, Am_Object& obj)
{
  Am_Object parent = obj;
  if (parent.Get_Slot_Type(Parent) == Am_NONE ||
      parent.Get_Slot_Type(Parent) == Am_UNINIT) return 0;
  while((parent.GV(Parent)).Valid()) {
    //    cout << parent << parent.GV(Parent) << endl;
    parent = parent.GV(Parent);
    if (Is_Network(parent)) return parent;
    if (parent.Get_Slot_Type(Parent) == Am_NONE ||
	parent.Get_Slot_Type(Parent) == Am_UNINIT) return 0;
  }
  return 0;
}

Am_Object Top_Pattern(Am_Object obj)
{
  Am_Object pivot = obj;
  Am_Object parent = obj.Get(Parent);
  while(parent.Valid()) {
    if (pivot.Is_Instance_Of(PatternProto) && !parent.Is_Instance_Of(PatternProto)) return pivot;
    pivot = parent;
    if (parent.Get_Slot_Type(Parent) == Am_NONE) return 0;
    parent = parent.Get(Parent);
  }
  if (pivot.Is_Instance_Of(PatternProto)) return pivot;
  return 0;
}

// Editable Text $B$+$i%$%s%?%i%/%?!<$r>C5n$9$k!#(B
void Remove_Text_Edit_Interactor(Am_Object text_obj)
{
  Am_Object inter = text_obj.Get_Part(TextPart).Get_Part(Am_INTERACTOR);
  inter.Remove_From_Owner();
  inter.Destroy();
}

// $B%*%V%8%'%/%H$NL>A0$NJQ99$rIT2D$K$9$k!#(B
void Disable_Name_Edit(Am_Object obj)
{
  Am_Object name = obj.Get_Part(NamePart);
  Remove_Text_Edit_Interactor(name);
}

// Menu$B$NJQ99!#(B
void Change_Menu(Am_Object obj, Am_Object popper)
{
  Am_Object old_popper = obj.Get_Part(MenuPopper);
  obj.Remove_Part(MenuPopper);
  old_popper.Destroy();
  obj.Add_Part(MenuPopper, popper);
}

// ------------------------------------------------------------
// Methods
// ------------------------------------------------------------



Am_Define_Method_Type(Copy_Method, Am_Object, (Am_Object));
Am_Define_Method_Type_Impl(Copy_Method);

Am_Define_Method_Type(Naming_Method, bool, (Am_Object, Am_String));
Am_Define_Method_Type_Impl(Naming_Method);


/*
Am_Object DropPointFeedback = 0;

void set_commands_for_move(Am_Object widget, Am_Object inter,
			   Am_Value object_modified, Am_Value old_value,
			   Am_Value new_value, int final_left, int final_top) {
  Am_Object inter_command, widget_command;
  inter_command = inter.Get_Part(Am_COMMAND);
  if (inter_command.Valid()) {
    inter_command.Set(Am_OLD_VALUE, old_value);
    inter_command.Set(Am_VALUE, new_value);
    inter_command.Set(Am_OBJECT_MODIFIED, object_modified);
    inter_command.Set(Am_LEFT, final_left);
    inter_command.Set(Am_TOP, final_top);
  }
  widget_command = widget.Get_Part(Am_MOVE_GROW_COMMAND);
  if (widget_command.Valid()) {
    widget_command.Set(Am_OLD_VALUE, old_value);
    widget_command.Set(Am_VALUE, new_value);
    widget_command.Set(Am_OBJECT_MODIFIED, object_modified);
    widget_command.Set(Am_GROWING, false);
  }
}

Am_Define_Method(Am_Current_Location_Method, void, Drag_And_Drop_Do,
		 (Am_Object inter, Am_Object object_modified,
		  Am_Inter_Location data)) {
  Am_Object window = inter.Get(Am_WINDOW);
  Am_Object widget = inter.Get_Owner();

  // get current x and y values w.r.t. window
  bool as_line;
  Am_Object ref;
  int x, y, w, h;
  data.Get_Location(as_line, ref, x, y, w, h);
  //  cout << x << ", " << y << ", " << w << ", " << h << ", " << ref << endl;
  Am_Translate_Coordinates(ref, x, y, window, x, y);
  //  cout << x << ", " << y << endl;

  // investigate destination object under the cursor
  int xoff = inter.Get(Am_X_OFFSET);
  int yoff = inter.Get(Am_Y_OFFSET);
  Am_Object top = widget.Get(Am_OPERATES_ON);
  Am_Value_List droppts = object_modified.Get(DropPoints);
  Am_Object target = Content_Instance_Of(top, x + xoff, y + yoff, window, droppts);

  bool success = false;
  if (target.Valid()) {
    Am_Object feedback;
    feedback = inter.Get(Am_FEEDBACK_OBJECT);
    if (feedback.Valid ()) 
      feedback.Set(Am_VISIBLE, false);
    else if (object_modified.Valid ()) {
      bool growing = inter.Get(Am_GROWING);
      Am_Modify_Object_Pos(object_modified, data, growing, inter);
    }
    DropPointFeedback.Set(Am_VISIBLE, false);

    Am_Object widget = inter.Get_Owner();
    Am_Value objs_value = (Am_Value)object_modified;
    Am_Value old_values_value = inter.Get(Am_OLD_VALUE);
    Am_Value new_values_value = (Am_Value)data;
    int final_left = object_modified.Get(Am_LEFT);
    int final_top = object_modified.Get(Am_TOP);
    set_commands_for_move(widget, inter, objs_value, old_values_value,
			  new_values_value, final_left, final_top);

    // drop $B$9$k%*%V%8%'%/%H$N(BCheckDropMethod$B$G%A%'%C%/$7!"(B
    // drop $B$9$k%*%V%8%'%/%H$N(BDropMethod$B$r<B9T$9$k!#(B
    Bin_Check_Method check_method = object_modified.Get(CheckDropMethod);
    Drop_Method drop_method = object_modified.Get(DropMethod);
    if (check_method.Valid() && drop_method.Valid()) {
      success = check_method.Call(object_modified, target);
      if (success) {
	drop_method.Call(object_modified, target, inter.Get(Am_COMMAND));
      }
    }
  }
  if (!success) {
    Am_Current_Location_Method orig_do = Am_Selection_Widget
      .Get_Part(Am_MOVE_INTERACTOR).Get(Am_DO_METHOD);
    orig_do.Call(inter, object_modified, data);
  }
}

*/
/*
Am_Define_Method(Am_Object_Method, void, DoDragAndDrop, (Am_Object command_obj))
{
  Am_Object inter = command_obj.Get_Owner();
  Am_Object window = inter.Get(Am_WINDOW);
  int xoff = inter.Get(Am_X_OFFSET);
  int yoff = inter.Get(Am_Y_OFFSET);

  Am_Inter_Location final_loc = command_obj.Get(Am_VALUE);
  bool as_line;
  Am_Object ref;
  int x, y, w, h;
  final_loc.Get_Location(as_line, ref, x, y, w, h);
  cout << x << ", " << y << ", " << w << ", " << h << ", " << ref << endl;
  Am_Translate_Coordinates(ref, x, y, window, x, y);
  cout << x << ", " << y << endl;

  Am_Object source = command_obj.Get(Am_OBJECT_MODIFIED);
  Am_Value_List droppts = source.Get(DropPoints);
  Am_Object target = Content_Instance_Of(window, x + xoff, y + yoff, window, droppts);
  if (target.Valid()) {
    Drop_Method drop_method = source.Get(DropMethod);
    if (drop_method.Valid()) drop_method.Call(source, target, command_obj);
  }
}
*/
/*
Am_Define_Method(Am_Object_Method, void, Drag_Interim_Do, (Am_Object command_obj))
{
  Am_Object inter = command_obj.Get_Owner();
  Am_Object window = inter.Get(Am_WINDOW);
  Am_Object widget = inter.Get_Owner();

  // get current x and y values w.r.t. window
  Am_Inter_Location interim_loc = inter.Get(Am_INTERIM_VALUE);
  bool as_line;
  Am_Object ref;
  int x, y, w, h;
  interim_loc.Get_Location(as_line, ref, x, y, w, h);
  Am_Translate_Coordinates(ref, x, y, window, x, y);

  // check whether the moved object has CheckDropMethod
  Am_Object source = inter.Get(Am_OBJECT_MODIFIED);
  Bin_Check_Method check_method = source.Get(CheckDropMethod);
  if (!check_method.Valid()) return;

  // investigate destination object under the cursor
  int xoff = inter.Get(Am_X_OFFSET);
  int yoff = inter.Get(Am_Y_OFFSET);
  Am_Object top = widget.Get(Am_OPERATES_ON);
  Am_Value_List droppts = source.Get(DropPoints);
  Am_Object target = Content_Instance_Of(top, x + xoff, y + yoff, window, droppts);

  if (target.Valid() && check_method.Call(source, target)) {
    // translate coordinates w.r.t. destination owner into ones w.r.t. window
    Am_Object owner = target.Get_Owner();
    int left = target.Get(Am_LEFT);
    int top = target.Get(Am_TOP);
    int width = target.Get(Am_WIDTH);
    int height = target.Get(Am_HEIGHT);
    Am_Translate_Coordinates(owner, left, top, window, left, top);
    // make feedback object visible
    if (!DropPointFeedback.Get_Owner().Valid())
      window.Add_Part(DropPointFeedback);
    DropPointFeedback.Set(Am_VISIBLE, true)
      .Set(Am_LEFT, left)
      .Set(Am_TOP, top)
      .Set(Am_WIDTH, width)
      .Set(Am_HEIGHT, height);
  } else {
    // make feedback object invisible
    DropPointFeedback.Set(Am_VISIBLE, false);
  }
}
*/
Am_Define_Method(Am_Object_Method, void, Name_Edit_Do, (Am_Object command_obj))
{
  Am_Object text_obj = command_obj.Get_Owner().Get_Owner();
  Am_Object owner = text_obj.Get_Owner().Get_Owner();
  if (owner.Get_Slot_Type(Model) != Am_NONE) {
    Am_String new_name = command_obj.Get(Am_VALUE);
    Naming_Method m = owner.Get(NamingMethod);
    if (m.Call(owner, new_name)) {
      owner.Get_Object(Model).Set(Name, new_name);
    } else {
      Am_Abort_Interactor(command_obj.Get_Owner());
    }
  }
}

Am_Define_Method(Am_Object_Method, void, New_Object_Do, (Am_Object command_obj))
{
  Am_Object menu = command_obj.Get_Owner().Get_Owner(); // $B%a%K%e!<(B

  Am_Object target = menu.Get(TargetObj); // $BDI2C@h(B
  Am_Object group = target.Get_Part(ContentsPart);
  int x = menu.Get(XinTarget);  // $B:BI8(B
  int y = menu.Get(YinTarget);
  Am_Translate_Coordinates(target, x, y, group, x, y);

  Am_Object obj = command_obj.Get(Am_LABEL); // $BDI2C$9$k%*%V%8%'%/%H(B
  Am_Object new_obj = ((Copy_Method)obj.Get(NewMethod)).Call(obj);
  new_obj
    .Set(Am_LEFT, x - (int)new_obj.Get(Am_WIDTH) / 2) // $B%+!<%=%k$N0LCV$rCf?4$K(B
    .Set(Am_TOP, y - (int)new_obj.Get(Am_HEIGHT) / 2)
    ;
  if (!((Bin_Check_Method)target.Get(AddMethod)).Call(target, new_obj))
    new_obj.Destroy();
}

Am_Define_Method(Am_Object_Method, void, Delete_Object_Do, (Am_Object command_obj))
{
  Am_Object menu = command_obj.Get_Owner().Get_Owner();
  Am_Object target = menu.Get(TargetObj);
  Am_Object parent = target.Get(Parent);
  ((Bin_Check_Method)parent.Get(RemoveMethod)).Call(parent, target);
}


// ------------------------------------------------------------
// Formulas
// ------------------------------------------------------------

// $B%]!<%H$N$_;D$7$F;D$j$r>C$9$?$a$N(BVisible 
// ---------------------------------------
Am_Define_Formula(bool, ContentsVisibleForm)
{
  Am_Object owner = self.GV_Owner();
  if (!owner.Valid()) return true;
  int w = owner.GV(Am_WIDTH);
  int h = owner.GV(Am_HEIGHT);
  if (w > 100 && h > 100) return true;
  int rw = Get_Required_Width(owner);
  int rh = Get_Required_Height(owner);
  if (w * 2 < rw || h * 2 < rh) return false;
  return true;
}

Am_Define_Formula(bool, SelfVisibleForm)
{
  if (self.Get_Slot_Type(Am_WIDTH) == Am_UNINIT) return false;
  int w = self.GV(Am_WIDTH);
  int h = self.GV(Am_HEIGHT);
  if (w <= 30 || h <= 30) return false;
  return true;
}

// Povl$B$N3,AX$K$*$1$k?F%*%V%8%'%/%H(B
// --------------------------------
Am_Define_Object_Formula(ParentForm)
{
  Am_Object owner_contents = self.GV_Owner();
  if (!owner_contents.Valid()) return 0;
  Am_Object owner = owner_contents.GV_Owner();
  if (!owner.Valid()) return 0;
  return owner;
}

// zoom$B$N%W%m%Q%2!<%7%g%sMQ(B
// ------------------------
Am_Define_Object_Formula(SelfForm)
{
  return self;
}

/*
Am_Define_Formula(int, NumberThresholdForm)
{
  //  return (int)self.GV_Object(propagateParent).GV(numberThreshold);
  Am_Object parent = self.GV(propagateParent);
  if (!parent.Valid()) return 0;
  //  if (parent.Get_Slot_Type(numberThreshold) == Am_NONE) return 50;
  //  if (parent.Get_Slot_Type(numberThreshold) == Am_UNINIT) return 50;
  //  if (!parent.GV(number_threshold).Valid()) return number_threshold;
  return (int)parent.GV(numberThreshold);
}
*/

// $BL>A0$H%U%l!<%`$N9b$5(B
// -------------------
// Parent ----- PovlGroup --+-- NamePart
//                          +-- ContentsPart
//
// $B!&%U%l!<%`$NCf?H$,Bg$-$/$J$C$F%U%l!<%`<+BN$bBg$-$/$J$k>l9g(B
// $B!&A4BN$r%j%5%$%:$9$k>l9g(B
// $BL>A0$N9b$5$O$J$K$K0MB8$9$k$+(B
//	$B!&(BNameHeightMax
//      $B!&(BPovlGroup$B$N(BHeight
//      $B!&(BParent$B$N(BHeight

Am_Define_Formula(int, NameHeightForm)
{
  int max = self.GV(NameHeightMax);

  // PovlGroup$B$K$^$@B0$7$F$$$J$$>l9g(B
  Am_Object named_group = self.GV_Owner();
  if (!named_group.Valid()) return max;
  
  // NameHeightMax > PovlGroup.HEIGHT$B!!$KBP1~(B
  max = imin(max, (int)named_group.GV(Am_HEIGHT));

  // Parent$B$K(BPovlGroup$B$,B0$7$F$$$J$$>l9g(B
  Am_Object parent = named_group.GV_Owner();
  if (!parent.Valid()) return max;

  // NameHeightMax > Parent.HEIGHT - PovlGroup.HEIGHT
  //  max = imin(max, (int)parent.GV(Am_HEIGHT) - (int)named_group.GV(Am_HEIGHT));
  if (max > (int)parent.GV(Am_HEIGHT) - (int)named_group.GV(Am_HEIGHT))
    max = 8;
  return max;
}

Am_Define_Formula(int, NameHeightForm2)
{
  int max = self.GV(NameHeightMax);

  // PovlGroup$B$K$^$@B0$7$F$$$J$$>l9g(B
  Am_Object named_group = self.GV_Owner();
  if (!named_group.Valid()) return max;
  
  // NameHeightMax > PovlGroup.HEIGHT$B!!$KBP1~(B
  max = imin(max, (int)named_group.GV(Am_HEIGHT));
  
  Am_Object contents = self.GV_Sibling(ContentsPart);
  if (!contents.Valid()) return max;
  if (!contents.GV(Am_VISIBLE)) return max;

  // minimum top of children
  Am_Value_List children = contents.GV(Am_GRAPHICAL_PARTS);
  for (children.Start(); !children.Last(); children.Next()) {
    Am_Object ch = children.Get();
    if (ch.GV(Am_VISIBLE)) {
      int top = ch.GV(Am_TOP);
      if (top < max) max = top;
    }
  }
  return max;
}


Am_Define_Formula(int, PovlGroupHeightForm)
{
  Am_Object name_part = self.GV(NamePart);
  Am_Object cont_part = self.GV(ContentsPart);
  if (!name_part.Valid() || !cont_part.Valid()) return 100;

  int name_h = name_part.Get(Am_HEIGHT); 
  int cont_h = cont_part.GV(Am_HEIGHT);
  return name_h + cont_h;
}

// $B%a%K%e!<$N%?%$%H%kMQ(B
// --------------------
Am_Define_String_Formula(TargetNameForm)
{
  Am_Object item = self.GV_Owner();  if (!item.Valid()) return (Am_String)"";
  Am_Object menu = item.GV_Owner();  if (!menu.Valid()) return (Am_String)"";
  Am_Object target = menu.GV_Object(TargetObj);  if (!target.Valid()) return (Am_String)"";
  if (!target.Get_Prototype().Valid()) return (Am_String)"";
  if (target.GV_Part(NamePart).Valid()) {
    Am_Object text = target.GV_Part(NamePart).GV_Part(TextPart);
    if (text.Valid()) return text.GV(Am_TEXT);
  }
  return (Am_String)"";
}

// Model$B$N(BName$B$r;2>H$9$k%F%-%9%H%*%V%8%'%/%HMQ(B
// -------------------------------------------
Am_Define_String_Formula(ModelNameForm)
{
  Am_Object text  = self.GV_Owner();  if ( !text.Valid()) return (Am_String)"";
  Am_Object obj   = text.GV_Owner();  if (  !obj.Valid()) return (Am_String)"";
  Am_Object model = obj.GV(Model);    if (!model.Valid()) return (Am_String)"";
  return model.GV(Name);
}

// contents part list
// ------------------
Am_Define_Value_List_Formula(ContentsListForm)
{
  Am_Object conts = self.GV_Part(ContentsPart);
  if (!conts.Valid())
    return 0;
  else
    return (Am_Value_List)conts.GV(Am_GRAPHICAL_PARTS);
}

// Instance List
// -------------
static void instance_list_procedure (Am_Constraint_Context& cc, Am_Object& self, Am_Value& value) {
  Am_Object* proto = (Am_Object*)cc.Get_Data ();

  Am_Value_List list = Am_Value_List();
  Am_Value_List parts = ContentsListForm(cc, self);
  for (parts.Start(); !parts.Last(); parts.Next()) {
    Am_Object p = parts.Get();
    if (p.Is_Instance_Of(*proto)) list.Add(p);
  }
  value = list;
}

Am_Constraint* InstanceListForm (Am_Object& proto)
{
  Am_Formula_Advanced* formula = (Am_Formula_Advanced*)(Am_Constraint*)
      Am_Formula (instance_list_procedure, "InstanceListForm");
  formula->Set_Data (&proto, 0);
  return formula;
}


// Name List
// ---------
static void name_list_procedure (Am_Constraint_Context& cc, Am_Object& self, Am_Value& value) {
  Am_Slot_Key list_key = (Am_Slot_Key)cc.Get_Data ();

  Am_Value_List names = Am_Value_List();
  Am_Value_List parts = self.GV(list_key);
  for (parts.Start(); !parts.Last(); parts.Next()) {
    Am_Object p = parts.Get();
    names.Add((Am_String)p.GV_Object(Model).GV(Name));
  }
  value = names;
}

Am_Constraint* NameListForm (Am_Slot_Key list_key)
{
  Am_Formula_Advanced* formula = (Am_Formula_Advanced*)(Am_Constraint*)
      Am_Formula (name_list_procedure, "NameListForm");
  formula->Set_Data ((void*)list_key, 0);
  return formula;
}

// ------------------------------------------------------------
// Demons
// ------------------------------------------------------------

void povl_copy_demon(Am_Object self)
{
  // First, execute Am_Group's copy demon
  Am_Object_Advanced proto_adv = (Am_Object_Advanced&)Am_Group;
  Am_Object_Demon* proto_copy = proto_adv.Get_Demons().Get_Object_Demon(Am_COPY_OBJ);
  if (proto_copy) proto_copy(self);

  // self is a copied object.
  // If self has a model, copy the model and set the copy to Model slot.
  if ((bool)self.Get(ToCopyModel) == true && self.Get_Slot_Type(Model) != Am_NONE) {
    Am_Object copied_model = self.Get_Object(Model).Copy();
    self.Set(Model, copied_model);
  }
}

void sequence_povl_copy_demon(Am_Object self)
{
  // First, execute SequenceAlignZoomGroup's copy demon
  Am_Object_Advanced proto_adv = (Am_Object_Advanced&)SequenceAlignZoomGroup;
  Am_Object_Demon* proto_create = proto_adv.Get_Demons().Get_Object_Demon(Am_COPY_OBJ);
  if (proto_create) proto_create(self);

  // self is a copied object.
  // If self has a model, copy the model and set the copy to Model slot.
  if ((bool)self.Get(ToCopyModel) == true && self.Get_Slot_Type(Model) != Am_NONE) {
    Am_Object copied_model = self.Get_Object(Model).Copy();
    self.Set(Model, copied_model);
  }
}


// ------------------------------------------------------------
// Widgets 
// ------------------------------------------------------------

Am_Object PovlSelectionWidget = 0;
Am_Object PovlOrigSizeCmd = 0;
Am_Object PovlEditSizeCmd = 0;

Am_Object EditableZoomingText = 0;

Am_Object NewObjectCmd = 0;
Am_Object RemoveObjectCmd = 0;

Am_Object PovlGroup = 0;
Am_Object SequencePovlGroup = 0;
Am_Object ValueProto = 0;
Am_Object PovlContents = 0;

void InitializeWidgets (void)
{
  PovlSelectionWidget = AlignZoomSelectionWidget.Create()
    //    .Get_Part(Am_MOVE_INTERACTOR)
    //      .Set(Am_DO_METHOD, Drag_And_Drop_Do)
    //      .Get_Part(Am_COMMAND)
    //        .Set(Am_INTERIM_DO_METHOD, Drag_Interim_Do)
    //      .Get_Owner()
    //    .Get_Owner()
    ;

  PovlOrigSizeCmd = OrigSizeCmd.Create(); //.Set(Am_SELECTION_WIDGET, PovlSelectionWidget);
  PovlEditSizeCmd = EditSizeCmd.Create(); //.Set(Am_SELECTION_WIDGET, PovlSelectionWidget);

  EditableZoomingText = ZoomingText.Create()
    .Get_Part(TextPart)
      .Set_Single_Constraint_Mode(Am_TEXT, false)
      .Add_Part(Am_INTERACTOR, Am_Text_Edit_Interactor.Create()
		.Set(Am_START_WHEN, "double_left_down")
		.Set(Am_PRIORITY, 3)
		.Get_Part(Am_COMMAND)
		  .Set(Am_DO_METHOD, Name_Edit_Do)
		.Get_Owner()
		)
    .Get_Owner()
    ;

  NewObjectCmd = MenuCommand.Create()
    .Set(Am_DO_METHOD, New_Object_Do)
    ;

  RemoveObjectCmd = MenuCommand.Create()
    .Set(Am_DO_METHOD, Delete_Object_Do)
    ;

  PovlGroup = Am_Group.Create("PovlGroup")
    .Set(Creator, "")
    .Set(CreatedTime, 0)
    .Set(Modifier, "")
    .Set(ModifiedTime, 0)
    .Set(Dropper, "")
    .Set(DroppedTime, 0)
    .Set(ReplPatternView, 0)
    
    .Set(ToCopyModel, true)
    //    .Set(numberThreshold, 30)
    .Set(propagateChildren, Am_Same_As(ContentsPart))
    .Set(Am_ACTIVE, true)
    .Set_Inherit_Rule(Am_LEFT, Am_COPY)
    .Set_Inherit_Rule(Am_TOP, Am_COPY)
    .Set_Inherit_Rule(Am_WIDTH, Am_COPY)
    .Set_Inherit_Rule(Am_HEIGHT, Am_COPY)
    ;
  Am_Object_Advanced obj_adv = (Am_Object_Advanced&)PovlGroup;
  Am_Demon_Set obj_demon_set(obj_adv.Get_Demons().Copy());
  obj_demon_set.Set_Object_Demon(Am_COPY_OBJ, povl_copy_demon);
  obj_adv.Set_Demons(obj_demon_set);

  SequencePovlGroup = SequenceAlignZoomGroup.Create("SequencePovlGroup")
    .Set(ToCopyModel, true)
    //    .Set(numberThreshold, 30)
    .Set(propagateChildren, Am_Same_As(ContentsPart))
    .Set_Inherit_Rule(Am_LEFT, Am_COPY)
    .Set_Inherit_Rule(Am_TOP, Am_COPY)
    .Set_Inherit_Rule(Am_WIDTH, Am_COPY)
    .Set_Inherit_Rule(Am_HEIGHT, Am_COPY)
    ;
  obj_adv = (Am_Object_Advanced&)SequencePovlGroup;
  Am_Demon_Set obj_demon_set2(obj_adv.Get_Demons().Copy());
  obj_demon_set2.Set_Object_Demon(Am_COPY_OBJ, sequence_povl_copy_demon);
  obj_adv.Set_Demons(obj_demon_set2);

  ValueProto = PovlGroup.Create("ValueProto");

  PovlContents = AlignZoomGroup.Create("PovlContents")
    .Set(propagateParent, PropagateForm)
    //    .Set(numberThreshold, NumberThresholdForm)
    .Set_Single_Constraint_Mode(Am_WIDTH, false)
    .Set_Single_Constraint_Mode(Am_HEIGHT, false)
    ;
}

// ================================================================================
// NG codes
// ================================================================================

// $B%7!<%1%s%9%Q%?!<%s$K;H$*$&$H;W$C$F$$$?$,!"$d$a$?!#(B
// Sequence Layout
// ---------------
/*
Am_Define_Formula(int, SequenceLayoutForm)
{
  int totalw = 0;
  int totalh = 0;
  int maxw = 0;
  int maxh = 0;

  Am_Value_List parts = self.GV(Am_GRAPHICAL_PARTS);
  int length = parts.Length();
  if (length <= 0) return 1;

  for (parts.Start(); !parts.Last(); parts.Next()) {
    Am_Object p = parts.Get();
    int w = p.GV(Am_WIDTH);
    int h = p.GV(Am_HEIGHT);
    totalw += w;
    totalh += h;
    maxw = imax(maxw, w);
    maxh = imax(maxh, h);
  }
  int dir = self.GV(Dir);
  if (dir == LeftRight || dir == RightLeft) {
    space = self.GV(Am_H_SPACING);
    self.Set(Am_WIDTH, totalw + space * (length - 1))
      .Set(Am_HEIGHT, maxh);
    inc_left = true;
  } else {
    space = self.GV(Am_V_SPACING);
    self.Set(Am_WIDTH, maxw)
      .Set(Am_HEIGHT, totalh += space * (length - 1));
    inc_left = false;
  }
  int left = 0;
  int top = 0;
  bool forward = true;
  if (dir == LeftRight || dir == TopBottom) {parts.Start(); forward = true;}
  if (dir == RightLeft || dir == BottomTop) {parts.End(); forward = false;}
  for ( ; !parts.Last() && !parts.First ; ) {
    Am_Object pt = parts.Get();
    int w = pt.Get(Am_WIDTH);
    int h = pt.Get(Am_HEIGHT);
    if (inc_left) top = (maxh - h) / 2;
    else          left = (maxw - w) / 2;
    pt.Set(Am_LEFT, left)
      .Set(Am_TOP,  top)
      ;
    if (inc_left) left += w + space; else top += h + space; 
    if (forward) parts.Next(); else parts.Prev();
  }
}



Am_Define_Formula(int, SequenceLayoutForm)
{
  int width = self.GV(Am_WIDTH);
  int height = self.GV(Am_HEIGHT);

  Am_Value_List parts = self.GV(Am_GRAPHICAL_PARTS);
  int length = parts.Length();
  if (length <= 0) return 1;

  int dir = self.GV(Dir);
  int space = 0;
  int w = width;
  int h = height;
  bool inc_left = true;
  if (dir == LeftRight || dir == RightLeft) {
    space = self.GV(Am_H_SPACING);
    width = width - space * (length - 1);
    w = width / length;
    inc_left = true;
  } else {
    space = self.GV(Am_V_SPACING);
    height = height - space * (length - 1);
    h = height / length;
    inc_left = false;
  }
  int left = 0;
  int top = 0;
  bool forward = true;
  if (dir == LeftRight || dir == TopBottom) {parts.Start(); forward = true;}
  if (dir == RightLeft || dir == BottomTop) {parts.End(); forward = false;}
  for ( ; !parts.Last() && !parts.First ; ) {
    Am_Object pt = parts.Get();
    pt.Set(Am_LEFT, left)
      .Set(Am_TOP,  top)
      .Set(Am_WIDTH,  w)
      .Set(Am_HEIGHT, h)
      ;
    if (inc_left) left += w + space; else top += h + space; 
    if (forward) parts.Next(); else parts.Prev();
  }
}
*/

