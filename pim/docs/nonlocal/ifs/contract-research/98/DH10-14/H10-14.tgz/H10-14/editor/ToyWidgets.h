// Copyright (C) 1997  Toyoda Masashi (toyoda@is.titech.ac.jp)

#define DEFINE_SLOT(x) Am_Slot_Key x = Am_Register_Slot_Name(#x)
#define EXPORT_SLOT(x) extern Am_Slot_Key x

#define CALL1(o, mt, mn) ((mt)o.Get(mn)).Call(o)
#define CALL2(o, mt, nm, a1) ((mt)o.Get(nm)).Call(o, a1)
#define CALL3(o, mt, nm, a1, a2) ((mt)o.Get(nm)).Call(o, a1, a2)

#include "RectangleWidgets.h"
#include "ZoomWidgets.h"
#include "Formulas.h"
#include "PopUpMenu.h"
#include "Arrow.h"

inline int imin(int i1, int i2) {if (i1<i2) return i1; else return i2;}
inline int imax(int i1, int i2) {if (i1>i2) return i1; else return i2;}
inline int iabs(int i1) {if (i1<0) return -i1; else return i1;}
