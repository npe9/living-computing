// Copyright (C) 1999  Toyoda Masashi (toyoda@is.titech.ac.jp)

#include <amulet.h>
#include "ToyWidgets.h"
#include "PovlWidgets.h"
#include "Module.h"
#include "Item.h"

Am_Define_Method(Copy_Method, Am_Object, New_Text_Item, (Am_Object /* module */))
{
  return TextItemProto.Create();
}

void Initialize_Item_Adapter(void)
{
  TextItemProto.Set(NewMethod, New_Text_Item);
}
