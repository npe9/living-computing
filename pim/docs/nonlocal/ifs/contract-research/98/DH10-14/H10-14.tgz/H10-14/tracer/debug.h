// -*-Mode: C++ -*-
// Copyright (C) 1996-1999 Buntarou Shizuki(shizuki@is.titech.ac.jp)

//
// debug.cc
//
extern int debug_czoom_action;
extern int debug_czoom_section;
extern int debug_czoom_resection;
extern int debug_gstore;
extern int debug_link;
extern int debug_port_coordinate;
extern int debug_process_definition;
extern int debug_process_main_draw;
extern int debug_rule;
extern int debug_stream_monitor;
extern int debug_update_call;
extern int debug_variable;
extern int debug_trace;
extern int debug_rproc;
extern int debug_layout;
extern int debug_doi;
extern int debug_make_list;
extern int debug_unify;

/* eof */
