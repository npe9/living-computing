// Copyright (C) 1996-1999 Buntarou Shizuki(shizuki@is.titech.ac.jp)

// global variables for controlling debug messages

#include "parse.h"

int debug_czoom_action = 0;
int debug_czoom_section = 0;
int debug_czoom_resection = 0;
int debug_gstore = 0;
int debug_link = 0;
int debug_port_coordinate = 0;
int debug_process_definition = 0;
int debug_process_main_draw = 0;
int debug_rule = 0;
int debug_stream_monitor = 0;
int debug_update_call = 0;
int debug_variable = 0;
int debug_trace = 0;
int debug_rproc = 0;
int debug_layout = 0;
int debug_doi = 0;
int debug_make_list = 0;
int debug_unify = 0;

// eof
