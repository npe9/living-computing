// Copyright (C) 1997,1998  Toyoda Masashi (toyoda@is.titech.ac.jp)

// Initialize
void Initialize_Arrow(void);

// Formulas
extern Am_Formula ArrowPointListWithVariableWidthForm;

#ifndef _INTERNAL_

// Slots
EXPORT_SLOT(Am_ARROW_H_WIDTH);
EXPORT_SLOT(Am_ARROW_H_HEIGHT);
EXPORT_SLOT(Am_ARROW_WIDTH);
#endif
