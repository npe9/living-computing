// Copyright (C) 1997  Toyoda Masashi (toyoda@is.titech.ac.jp)

// ------------------------------------------------------------
// Objects
// ------------------------------------------------------------

extern Am_Object ModuleModel;

extern Am_Object ModuleProto;
extern Am_Object TopModule;
extern Am_Object MainRuleProto;

// ------------------------------------------------------------
// Functions
// ------------------------------------------------------------

Am_Object Module_Find_Module(Am_String name);
Am_Object Module_Find_Process(Am_Object module, Am_String name);
Am_Object ModuleFindModuleForm(Am_String name, Am_Constraint_Context& cc);
Am_Object ModuleFindProcessForm(Am_Object module, Am_String name, Am_Constraint_Context& cc);

// ------------------------------------------------------------
// Methods
// ------------------------------------------------------------

extern Am_Object_Method New_Module_Do;

// ------------------------------------------------------------
// Initialize
// ------------------------------------------------------------

void InitializeModule(void);
