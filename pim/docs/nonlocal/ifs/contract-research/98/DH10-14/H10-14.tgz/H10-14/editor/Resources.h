// Copyright (C) 1997  Toyoda Masashi (toyoda@is.titech.ac.jp)

// ------------------------------------------------------------
// Objects
// ------------------------------------------------------------

extern Am_Object PovlResources;

// ------------------------------------------------------------
// Formulas
// ------------------------------------------------------------

Am_Constraint* GetResourceForm(Am_Slot_Key key);

// ------------------------------------------------------------
// Resource Slots
// ------------------------------------------------------------

EXPORT_SLOT(ModuleFill);
EXPORT_SLOT(PortNewFill);
EXPORT_SLOT(PortOldFill);
EXPORT_SLOT(PortSpecialFill);
EXPORT_SLOT(PortNewTextFill);
EXPORT_SLOT(PortOldTextFill);
EXPORT_SLOT(PortMarkerOpenFill);
EXPORT_SLOT(PortMarkerCloseFill);
EXPORT_SLOT(PortWidthMargin);
EXPORT_SLOT(PortHeightMargin);
EXPORT_SLOT(ProcessMargin);
EXPORT_SLOT(ProcessFill);
EXPORT_SLOT(ProcessInvalidFill);
EXPORT_SLOT(TransitionRuleFill);
EXPORT_SLOT(AtomFill);
EXPORT_SLOT(AtomWidthMargin);
EXPORT_SLOT(AtomHeightMargin);
EXPORT_SLOT(MessageFill);
EXPORT_SLOT(StructWidthMargin);
EXPORT_SLOT(StructHeightMargin);
EXPORT_SLOT(GuardFill);
EXPORT_SLOT(GuardWidthMargin);
EXPORT_SLOT(GuardHeightMargin);
EXPORT_SLOT(BinderLine);
EXPORT_SLOT(BinderFill);
EXPORT_SLOT(BindMargin);
EXPORT_SLOT(ImplDialogFont);

// ------------------------------------------------------------
// Initialize
// ------------------------------------------------------------

void InitializeResources(void);
