// -*- C++ -*-
// Copyright (C) 1996-1999 Buntarou Shizuki(shizuki@is.titech.ac.jp)

#ifndef _ProcRegister_h
#define _ProcRegister_h

#include <SLList.h>
#include "Object.h"

class ProcRegister {
  SLList<Proc *> ProcList;

public:
  inline ProcRegister() {}	// ??
  inline ~ProcRegister() {}	// ??

  int Count();

  inline Register(Proc *p) { ProcList.append(p); }

  Proc *GetProc(char *module, char *name, int arity);

  void Check();

  // for debugging
  void Dump();
};

//
// ProcRegister.cc
//
void initProcRegister();
void procRegister(Proc *p);
Proc *getProc(char *module, char *name, int arity);
void dumpProcs();

#endif

/* eof */
