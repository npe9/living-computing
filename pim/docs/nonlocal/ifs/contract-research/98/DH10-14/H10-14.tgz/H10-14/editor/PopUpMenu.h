// Copyright (C) 1997  Toyoda Masashi (toyoda@is.titech.ac.jp)

void Initialize_Pop_Up_Menu(void);

#ifndef _MENU_INTERNAL_

extern Am_Object PopUpMenu;
extern Am_Object PopUpMenuInteractor;
extern Am_Object GlobalPopUpMenuInteractor;
extern Am_Object MenuCommand;

EXPORT_SLOT(MenuBody);
EXPORT_SLOT(MenuWindow);
EXPORT_SLOT(TargetObj);
EXPORT_SLOT(XinTarget);
EXPORT_SLOT(YinTarget);
EXPORT_SLOT(ReturnValue);

#endif
