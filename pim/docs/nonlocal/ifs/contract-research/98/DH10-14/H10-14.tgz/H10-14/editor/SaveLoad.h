// Copyright (C) 1997  Toyoda Masashi (toyoda@is.titech.ac.jp)

int save_module(Am_Object window, ofstream& ofile);
int load_module(Am_Object window, ifstream& ifile);

int Save_module(Am_Object module);
int Load_module(Am_Object top_module, Am_String file_name);

int Save_Snapshot(Am_Object top_module, Am_String file_name);
int Load_Snapshot(Am_Object top_module, Am_String file_name);
