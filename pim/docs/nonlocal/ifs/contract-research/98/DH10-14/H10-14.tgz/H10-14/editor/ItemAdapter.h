// Copyright (C) 1999  Toyoda Masashi (toyoda@is.titech.ac.jp)

void Initialize_Item_Adapter(void);
