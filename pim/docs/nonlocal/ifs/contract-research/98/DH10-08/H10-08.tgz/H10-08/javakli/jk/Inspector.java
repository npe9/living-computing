// Copyright (C) 1998,1999 Kazuhisa Iizuka

import java.awt.*;
import java.awt.event.*;

public class Inspector extends TextArea {
  private static Object lock_new_instance = new Object();
  public static InspectorManager manager;

  public String name = "";


  public Inspector() {
    this("no name");
  }

  public Inspector(String name) {
    super(15, 40);
    setEditable(false);

    this.name = name;

    synchronized(lock_new_instance) {
      if (manager == null) {
	manager = new InspectorManager();
      }

      manager.addInspector(this);  // register the Manager
    }
  }

  /**
   * Data ���ɲä���
   */
  public synchronized String insertData(Data d) {
    return insertString(Data.toStr(d));
  }

  /**
   * String ���ɲä���
   */
  public synchronized String insertString(String str) {
    if (getSize().equals(new Dimension(0, 0))) {
      setSize(100, 100);  // Warning:  Name: HorScrollBar �äƸ������顦����
    }

    append(str);

    return str;
  }
}
