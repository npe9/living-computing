import java.lang.*;
import java.awt.*;



class Count {
    int count;
    boolean sus=false;
    boolean redraw=false;
    final int max=5;
    Count(int i){count=i;}
    
    synchronized void inc(GT n){
        while(count>=max || sus){
            try{wait();}catch(InterruptedException e){}
            //if(sus) n.ptm.prv.suspend();
        }
        //if(sus) n.ptm.prv.suspend();
        n.makeTree();
	//System.out.println(n.unparseS_txtF(0));
        count++;
        notifyAll();
    }
    synchronized void dec(PTCanvas ptc,Prove prove){
        boolean flag=true;
        while((count<=1 && prove.isAlive()) || sus){
            if(flag){ptc.flush();flag=false;continue;}                
            try{wait();}catch(InterruptedException e){}
            if(redraw) return;
        }
        //if(sus) prove.pt.suspend();
        count--;
        notifyAll();
    }
    
    synchronized void ntfy(){
        notifyAll();
    }
    
    void sus(){
        sus=true;
    }
    
    void resu(){
        sus=false;
    }
    
    void redraw(){
        redraw=true;
    }
    
    void end_redraw(){
        redraw=false;
    }
}

class GT {
    int ds=0;
//    int cs;
//    int gs;
    GT son;
    GT next;
    GT par;
    float x;float y;
    float L;float W;
    float F;float A;float R;float T;
//    Term atom;
    Color p_color=Color.black;
    Color old_color;
    Model m;
    GT last;
    int bros;
    int gene;
    int born_n;
    static GT root_gt;
    static MGTP ptm;
    static Count sc;
    static int max_gene;
    static boolean redraw_flag;
    static float step;
    static GT curGT;
    //static float max_R;
    
    GT(GTerm a,MGTP mgtp){
        m=new Model(a);
        root_gt=this;bros=1;
	ptm=mgtp;
        sc=new Count(1);
        gene=0;
        max_gene=0;
    }
    
    GT(Model model,GT cgt){
        m=model;
	par=cgt;
	bros=1;
        sc.inc(this);
        //makeTree();
    }
    GT(Model model,GT cgt,int bn){
        m=model;
	par=cgt;
	bros=bn;
        sc.inc(this);
        //makeTree();
    }

  void putcolor(String color){
    if(color=="green") {p_color=Color.green; return;}
    if(color=="blue") {p_color=Color.blue; return;}
    if(color=="pink") {p_color=Color.pink; return;}
  }
    
    void makeTree(){
        
	/*    if(==null){
            if(root_gt.son==null){
                root_gt.son=this;
                born_n=0;
            }else{    
                born_n=root_gt.last.born_n+1;
                root_gt.last.next=this;
            }
            gene=1;
            root_gt.last=this;
        }else{ */
            if(par.son==null){
                par.son=this;
                born_n=0;
            }else{
                born_n=par.last.born_n+1;
                par.last.next=this;
		bros=par.last.bros;
            }
            gene=par.gene+1;
            par.last=this;
	    // }
    }
    
    void position_calc(float left,float width,int height,PTCanvas ptc,GT cur) throws DispModeException{
            if(max_gene<gene){
                step=(float)height/(gene+2);
                max_gene=gene;
                ptc.og.dispose();
                ptc.coordinate_offScr(root_gt);
                root_gt.y_recalc(this,ptc,true);
                ptc.flush();
            }
            //y=(int)(0.5+step*(gene+1));
            y=step*(gene+1);
            L=left;
            //x=L+(int)(0.5+width/2.0);
            x=L+(float)(width/2.0);
            W=width;
            if(born_n==0){
                if(gene>=2) ptc.drawBranch(x,y,W,bros,par.x,par.y);
                else if(gene==1) ptc.drawBranch(x,y,W,bros,root_gt.x,root_gt.y);
            }
            ptc.drawNode(this);
            if(redraw_flag){
                if(cur==this){ 
                    redraw_flag=false;
                    ptm.prv.pt.ptv.dspMenu.setEnabled(true);
                    ptc.flush();
                    if(sc.redraw){
                        sc.end_redraw();
                        sc.dec(ptc,ptm.prv);
                        if(ptm.prv.pt.ptv.disp_mode!='t') {
                            redraw_flag=true;
                            throw new DispModeException(this);
                        } 
                    }
                }
            }else{
                curGT=this;
                if(ptc.zoom_redraw){
                    ptc.ZoomRedraw();
                    ptc.zoom_redraw=false;
                }
                sc.dec(ptc,ptm.prv);
                if(ptm.prv.pt.ptv.disp_mode!='t') {
                    redraw_flag=true;
                    throw new DispModeException(this);
                } 
            }
            if(son!=null) {
                try{
                    son.position_calc(L,(float)(W/son.bros),height,ptc,cur);
                }catch(DispModeException dme1){
                    throw dme1;
                }
            }
            if(next!=null) {
                try{
                    next.position_calc(L+W,W,height,ptc,cur);
                }catch(DispModeException dme2){
                    throw dme2;
                }
            }
    }
    
    boolean y_recalc(GT cur,PTCanvas ptc,boolean draw){
        //y=(int)(0.5+step*(gene+1));
        y=step*(gene+1);
        if(draw){
            if(born_n==0){
                if(gene>=2) ptc.drawBranch(x,y,W,bros,par.x,par.y);
                else if(gene==1) ptc.drawBranch(x,y,W,bros,root_gt.x,root_gt.y);
            }
            ptc.drawNode(this);
        }
        if(son!=null){
            if(son==cur) return true;
            if(son.y_recalc(cur,ptc,draw)) return true;
        }
        if(next!=null){
            if(next==cur) return true;
            if(next.y_recalc(cur,ptc,draw)) return true;
        }
        return false;
    }
    
    void radial_position_calc(float Fk,float width_rad,int height_r,PTCanvas ptc,GT cur)throws DispModeException{
        if(max_gene<gene){
            step=(float)height_r/(gene+1);
            max_gene=gene;
            ptc.og.dispose();
            ptc.coordinate_offScr(root_gt);
            root_gt.r_recalc(this,ptc,true);
            ptc.flush();
        }
        R=step*gene;
        F=Fk;
        A=width_rad;
        T=F+A/2;
        //y=(int)(R*Math.sin(T)+ptc.cvw_height/2.0+0.5);
        //x=(int)(R*Math.cos(T)+ptc.cvw_width/2.0+0.5);
        y=(float)(R*Math.sin(T)+ptc.cvw_height/2.0);
        x=(float)(R*Math.cos(T)+ptc.cvw_width/2.0);
        if(born_n==0){
            if(gene>=2) ptc.rad_drawBranch(x,y,R,T,A,bros,par.x,par.y);
             else if(gene==1) ptc.rad_drawBranch(x,y,R,T,A,bros,root_gt.x,root_gt.y);
        }
        ptc.drawNode(this);
        if(redraw_flag){
            if(cur==this){ 
                redraw_flag=false;
                ptm.prv.pt.ptv.dspMenu.setEnabled(true);
                ptc.flush();
                if(sc.redraw){
                    sc.end_redraw();
                    sc.dec(ptc,ptm.prv);
                    if(ptm.prv.pt.ptv.disp_mode!='r') {
                        redraw_flag=true;
                        throw new DispModeException(this);
                    } 
                }
            }
        }else{
            curGT=this;
            if(ptc.zoom_redraw){
                    ptc.ZoomRedraw();
                    ptc.zoom_redraw=false;
            }
            sc.dec(ptc,ptm.prv);
            if(ptm.prv.pt.ptv.disp_mode!='r') {
                redraw_flag=true;
                throw new DispModeException(this);
            } 
        }
        if(son!=null){
            try{
                son.radial_position_calc(F,A/son.bros,height_r,ptc,cur);
            }catch(DispModeException dme1){
                    throw dme1;
            }
        }
        if(next!=null){
            try{
                next.radial_position_calc(F+A,A,height_r,ptc,cur);
            }catch(DispModeException dme2){
                    throw dme2;
            }
        }
    }
    
    boolean r_recalc(GT cur,PTCanvas ptc,boolean draw){
        R=step*gene;
        if(draw){
            //y=(int)(R*Math.sin(T)+ptc.cvw_height/2.0+0.5);
            //x=(int)(R*Math.cos(T)+ptc.cvw_width/2.0+0.5);
            y=(float)(R*Math.sin(T)+ptc.cvw_height/2.0);
            x=(float)(R*Math.cos(T)+ptc.cvw_width/2.0);
            
            if(born_n==0){
                if(gene>=2) ptc.rad_drawBranch(x,y,R,T,A,bros,par.x,par.y);
                else if(gene==1) ptc.rad_drawBranch(x,y,R,T,A,bros,root_gt.x,root_gt.y);
            }
            ptc.drawNode(this);
        }
        if(son!=null){
            if(son==cur) return true;
            if(son.r_recalc(cur,ptc,draw)) return true;
        }
        if(next!=null){
            if(next==cur) return true;
            if(next.r_recalc(cur,ptc,draw)) return true;
        }
        return false;
    }
    
    void rad_local_position_calc(float Fk,float width_rad,int height_r,PTCanvas ptc,GT cur)throws DispModeException{
        if(max_gene<gene){
            step=(float)height_r/(gene+1);
            max_gene=gene;
            ptc.og.dispose();
            ptc.coordinate_offScr(root_gt);
            root_gt.r_local_recalc(this,ptc,true);
            ptc.flush();
        }
        F=Fk;
        A=width_rad;
        T=F+A/2;
        if(gene>=2){
            //y=m.tail.gt.y+(int)(step*Math.sin(T)+0.5);
            //x=m.tail.gt.x+(int)(step*Math.cos(T)+0.5);
            y=par.y+(float)(step*Math.sin(T));
            x=par.x+(float)(step*Math.cos(T));
            if(born_n==0) ptc.rad_local_drawBranch(x,y,step,T,A,bros,par.x,par.y);
        }else if(gene==1){
            //y=root_gt.y+(int)(step*Math.sin(T)+0.5);
            //x=root_gt.x+(int)(step*Math.cos(T)+0.5);
            y=root_gt.y+(float)(step*Math.sin(T));
            x=root_gt.x+(float)(step*Math.cos(T));
            if(born_n==0){
                ptc.rad_local_drawBranch(x,y,step,T,A,bros,root_gt.x,root_gt.y);
            }
        }else if(gene==0){
            y=(float)(ptc.cvw_height/2.0);
            x=(float)(ptc.cvw_width/2.0);
        }
        ptc.drawNode(this);
        if(redraw_flag){
            if(cur==this){ 
                redraw_flag=false;
                ptm.prv.pt.ptv.dspMenu.setEnabled(true);
                ptc.flush();
                if(sc.redraw){
                    sc.end_redraw();
                    sc.dec(ptc,ptm.prv);
                    if(ptm.prv.pt.ptv.disp_mode!='l') {
                        redraw_flag=true;
                        throw new DispModeException(this);
                    } 
                }
            }
        }else{
            curGT=this;
            if(ptc.zoom_redraw){
                ptc.ZoomRedraw();
                ptc.zoom_redraw=false;
            }
            sc.dec(ptc,ptm.prv);
            if(ptm.prv.pt.ptv.disp_mode!='l') {
                redraw_flag=true;
                throw new DispModeException(this);
            } 
        }
        if(son!=null){
            try{
                son.rad_local_position_calc(F,A/son.bros,height_r,ptc,cur);
            }catch(DispModeException dme1){
                    throw dme1;
            }
        }
        if(next!=null){
            try{
                next.rad_local_position_calc(F+A,A,height_r,ptc,cur);
            }catch(DispModeException dme2){
                    throw dme2;
            }
        }
    }
    
    boolean r_local_recalc(GT cur,PTCanvas ptc,boolean draw){
        if(draw){
            if(gene>=2){
                //y=py+(int)(step*Math.sin(T)+0.5);
                //x=px+(int)(step*Math.cos(T)+0.5);
                y=par.y+(float)(step*Math.sin(T));
                x=par.x+(float)(step*Math.cos(T));
                if(born_n==0) ptc.rad_local_drawBranch(x,y,step,T,A,bros,par.x,par.y);
            }else if(gene==1){
                //y=py+(int)(step*Math.sin(T)+0.5);
                //x=px+(int)(step*Math.cos(T)+0.5);
                y=root_gt.y+(float)(step*Math.sin(T));
                x=root_gt.x+(float)(step*Math.cos(T));
                if(born_n==0) ptc.rad_local_drawBranch(x,y,step,T,A,bros,root_gt.x,root_gt.y);
            }else if(gene==0){
                y=(float)(ptc.cvw_height/2.0);
                x=(float)(ptc.cvw_width/2.0);
            }
            ptc.drawNode(this);
        }
        if(son!=null){
            if(son==cur) return true;
            if(son.r_local_recalc(cur,ptc,draw)) return true;
        }
        if(next!=null){
            if(next==cur) return true;
            if(next.r_local_recalc(cur,ptc,draw)) return true;
        }
        return false;
    }
  
    GT find(float cx,float cy,float dx,float dy){
        GT retn=null;
        GT a;
        if(Math.abs(cx-x)<dx && Math.abs(cy-y)<dy) retn=this;
        if(son!=null){
            a=son.find(cx,cy,dx,dy);
            if(a!=null){
                if(retn==null) retn=a;
                else if((cx-x)*(cx-x)+(cy-y)*(cy-y)>(cx-a.x)*(cx-a.x)+(cy-a.y)*(cy-a.y)) retn=a;
            }
        }
        if(next!=null){ 
            a=next.find(cx,cy,dx,dy);
            if(a!=null){
                if(retn==null) retn=a;
                else if((cx-x)*(cx-x)+(cy-y)*(cy-y)>(cx-a.x)*(cx-a.x)+(cy-a.y)*(cy-a.y)) retn=a;
            }
        }
        return retn;
    }
    
    String unparseS_txtF(int i) {
   	     String s="";
   	    for (int j=0; j<i; j++) s=s+" ";
//   	 s=s+atom.unparse()+"("+ds+","+cs+","+gs+","+x+","+y+","+L+","+W+","+H+","+D+")";
   	    s=s+m.hd+"("+bros+","+gene+","+born_n+","+x+","+y+","+L+","+W+","
   	    +color_inf(p_color)
   	    +")";
//   	 s=s+atom.unparse()+"("+ds+","+cs+","+gs+","+x+","+y+","+color_inf(p_color)+")";
   	    return s;
    }
  
    String color_inf(Color c) {
       if (c==Color.red) {return "r";}
       if (c==Color.green) {return "g";}
       return "b";
    }
    
    int leaf_calc(){
        int par_ds;
        if(son!=null) ds=son.leaf_calc();
        else ds=1;
        if(next!=null) par_ds=ds+next.leaf_calc();
        else par_ds=ds;
        return par_ds;
    }
    
    void weighted_offdraw(float left,int par_ds,float par_width,float width,PTCanvas ptc){
        L=left;
        //x=L+(int)(0.5+width/2.0);
        x=L+(float)(width/2.0);
        W=width;
        if(gene>=2) ptc.PTdrawLine(ptc.og,x,y,par.x,par.y);
        else if(gene==1) ptc.PTdrawLine(ptc.og,x,y,root_gt.x,root_gt.y);
        ptc.drawNode(this);
        if(son!=null) son.weighted_offdraw(L,ds,W,(float)(W*son.ds/ds),ptc);
        if(next!=null) next.weighted_offdraw(L+W,par_ds,par_width,(float)(par_width*next.ds/par_ds),ptc);
    }
    
    void r_weighted_offdraw(float Fk,int par_ds,float par_width,float width_rad,PTCanvas ptc){
        F=Fk;
        A=width_rad;
        T=F+A/2;
        //y=(int)(R*Math.sin(T)+ptc.cvw_height/2.0+0.5);
        //x=(int)(R*Math.cos(T)+ptc.cvw_width/2.0+0.5);
        y=(float)(R*Math.sin(T)+ptc.cvw_height/2.0);
        x=(float)(R*Math.cos(T)+ptc.cvw_width/2.0);
        if(gene>=2) ptc.PTdrawLine(ptc.og,x,y,par.x,par.y);
        else if(gene==1) ptc.PTdrawLine(ptc.og,x,y,root_gt.x,root_gt.y);
        ptc.drawNode(this);
        if(son!=null) son.r_weighted_offdraw(F,ds,A,A*son.ds/ds,ptc);
        if(next!=null) next.r_weighted_offdraw(F+A,par_ds,par_width,par_width*next.ds/par_ds,ptc);
    }
    
    void r_local_weighted_offdraw(float Fk,int par_ds,float par_width,float width_rad,PTCanvas ptc){
        F=Fk;
        A=width_rad;
        T=F+A/2;
        if(gene>=2){
            //y=py+(int)(step*Math.sin(T)+0.5);
            //x=px+(int)(step*Math.cos(T)+0.5);
            y=par.y+(float)(step*Math.sin(T));
            x=par.x+(float)(step*Math.cos(T));
            ptc.PTdrawLine(ptc.og,x,y,par.x,par.y);
        }else if(gene==1){
            y=root_gt.y+(float)(step*Math.sin(T));
            x=root_gt.x+(float)(step*Math.cos(T));            
            ptc.PTdrawLine(ptc.og,x,y,root_gt.x,root_gt.y);
        }else if(gene==0){
            y=(float)(ptc.cvw_height/2.0);
            x=(float)(ptc.cvw_width/2.0);
        }
        ptc.drawNode(this);
        if(son!=null) son.r_local_weighted_offdraw(F,ds,A,A*son.ds/ds,ptc);
        if(next!=null) next.r_local_weighted_offdraw(F+A,par_ds,par_width,par_width*next.ds/par_ds,ptc);
    }
    
    void fixed_recalc(float left,float width,PTCanvas ptc){
        L=left;
        //x=L+(int)(0.5+width/2.0);
        x=L+(float)(width/2.0);
        W=width;
        if(gene>=2) ptc.PTdrawLine(ptc.og,x,y,par.x,par.y);
        else if(gene==1) ptc.PTdrawLine(ptc.og,x,y,root_gt.x,root_gt.y);
        ptc.drawNode(this);
        if(son!=null) son.fixed_recalc(L,(float)(W/son.bros),ptc);
        if(next!=null) next.fixed_recalc(L+W,W,ptc);
    }
    
    void r_fixed_recalc(float Fk,float width_rad,PTCanvas ptc){
        F=Fk;
        A=width_rad;
        T=F+A/2;
        //y=(int)(R*Math.sin(T)+ptc.cvw_height/2.0+0.5);
        //x=(int)(R*Math.cos(T)+ptc.cvw_width/2.0+0.5);
        y=(float)(R*Math.sin(T)+ptc.cvw_height/2.0);
        x=(float)(R*Math.cos(T)+ptc.cvw_width/2.0);
        if(gene>=2) ptc.PTdrawLine(ptc.og,x,y,par.x,par.y);
        else if(gene==1) ptc.PTdrawLine(ptc.og,x,y,root_gt.x,root_gt.y);
        ptc.drawNode(this);
        if(son!=null) son.r_fixed_recalc(F,A/son.bros,ptc);
        if(next!=null) next.r_fixed_recalc(F+A,A,ptc);
    }
    
    void r_local_fixed_recalc(float Fk,float width_rad,PTCanvas ptc){
        F=Fk;
        A=width_rad;
        T=F+A/2;
        if(gene>=2){
            //y=py+(int)(step*Math.sin(T)+0.5);
            //x=px+(int)(step*Math.cos(T)+0.5);
            y=par.y+(float)(step*Math.sin(T));
            x=par.x+(float)(step*Math.cos(T));
            ptc.PTdrawLine(ptc.og,x,y,par.x,par.y);
        }else if(gene==1){
            y=root_gt.y+(float)(step*Math.sin(T));
            x=root_gt.x+(float)(step*Math.cos(T));            
            ptc.PTdrawLine(ptc.og,x,y,root_gt.x,root_gt.y);
        }else if(gene==0){
            y=(float)(ptc.cvw_height/2.0);
            x=(float)(ptc.cvw_width/2.0);
        }
        ptc.drawNode(this);
        if(son!=null) son.r_local_fixed_recalc(F,A/son.bros,ptc);
        if(next!=null) next.r_local_fixed_recalc(F+A,A,ptc);
    }
    
    boolean zoom_Redraw(PTCanvas ptc,GT cur){
        if(gene>=1 && born_n==0){
            if(ptm.prv.pt.ptv.disp_mode=='t') ptc.drawBranch(x,y,W,bros,par.x,par.y);
            else if(ptm.prv.pt.ptv.disp_mode=='r') ptc.rad_drawBranch(x,y,R,T,A,bros,par.x,par.y);
            else if(ptm.prv.pt.ptv.disp_mode=='l') ptc.rad_local_drawBranch(x,y,step,T,A,bros,par.x,par.y);
        }
        ptc.drawNode(this);
        if(this==cur) return true;
        if(son!=null) if(son.zoom_Redraw(ptc,cur)) return true;
        if(next!=null) if(next.zoom_Redraw(ptc,cur)) return true;
        return false;
    }
    
    void zoom_Redraw(PTCanvas ptc){
        if(gene>=1) ptc.PTdrawLine(ptc.og,x,y,par.x,par.y);
        ptc.drawNode(this);
        if(son!=null) son.zoom_Redraw(ptc);
        if(next!=null) next.zoom_Redraw(ptc);
    }
}
