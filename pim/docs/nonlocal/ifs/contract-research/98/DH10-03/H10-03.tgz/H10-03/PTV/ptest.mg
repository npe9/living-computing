-> p.
p -> q;r.
q -> s;t.
r -> u.
u -> .
s -> v.
t -> .
