->fib(0,1),fib(1,1).
fib(N1,F1)|{N0=N1-1},fib(N0,F0),
           {N2=N1+1,F2=F0+F1,println("fib("+N2+","+F2+")")}->fib(N2,F2).
fib(10,F)->.
