dom(A)
->
p(A);p(f(A)) .

p(A),p(f(f(f(f(f(f(f(f(f(f(A)))))))))))
->.

-> dom(a) .

dom(X1)
->
dom(f(X1)) .

