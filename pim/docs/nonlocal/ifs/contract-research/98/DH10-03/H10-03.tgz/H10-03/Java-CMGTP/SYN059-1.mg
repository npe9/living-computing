-> big_f(a).

-> big_g(b).

big_f(X),big_f(Y),big_g(Z) -> big_h(X);big_h(Y).

big_f(X),big_f(Y),big_g(Z) -> big_h(X);big_j(Z).

big_f(X) -> big_h(X);big_f(e);big_g(f).

big_f(X),big_j(f) -> big_h(X);big_f(e).

big_f(X),big_h(e) -> big_h(X);big_g(f).

big_f(X),big_h(e),big_j(f) -> big_h(X).

big_g(X),big_f(Y),big_g(Z) -> big_j(X);big_h(Y).

big_g(X),big_f(Y),big_g(Z) -> big_j(X);big_j(Z).

big_g(X) -> big_j(X);big_f(e);big_g(j).

big_g(X),big_j(f) -> big_j(X);big_f(e).

big_g(X),big_h(e) -> big_j(X);big_g(f).

big_g(X),big_h(e),big_j(f) -> big_j(X).

big_f(X),big_g(Y) -> big_f(c);big_h(X).

big_f(X),big_g(Y) -> big_f(c);big_j(Y).

-> big_f(c);big_f(e);big_g(f).

big_j(f) -> big_f(c);big_f(e).

big_h(e) -> big_f(c);big_g(f).

big_h(e),big_j(f) -> big_f(c).

big_f(X),big_g(Y) -> big_g(d);big_h(X).

big_f(X),big_g(Y) -> big_g(d);big_j(Y).

-> big_g(d);big_f(e);big_g(f).

big_j(f) -> big_g(d);big_f(e).

big_h(e) -> big_g(d);big_g(f).

big_h(e),big_j(f) -> big_g(d).

big_h(c),big_j(d),big_f(X),big_g(Y) -> big_h(X).

big_h(c),big_j(d),big_f(X),big_g(Y) -> big_j(Y).

big_h(c),big_j(d) -> big_f(e);big_g(f).

big_h(c),big_j(d),big_j(f) -> big_f(e).

big_h(c),big_h(e) -> big_j(d);big_g(f).

big_h(c),big_j(d),big_h(e),big_j(f) -> .

