/**
 * EXTermTemp.java 32f3 8-Sep-1998
 * Copyright (C) 1997, 1998 Kyushu University
 */

import java.util.Vector;

class EXTermTemp extends Term {
  int id; Vector vv;
  EXTermTemp(int i, Vector v) {id=i; vv=v;}
  public String toString() {return "EXTermTemp("+id+")";}
}

// eof
