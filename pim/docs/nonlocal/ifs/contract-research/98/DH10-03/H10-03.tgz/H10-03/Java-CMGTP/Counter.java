class Counter {
  //  public static int ground,subs,dmatch,match,matchTM,sat,conf,index,cjm;
  public static int putBuf,ground,groundTM,subs,dmatch,match,sat,conf,cjm,
  accheck,upickup,usubs,usubspass,dsubs,dsubspass,onTM,npickup,
  index,indexBV,matchTM,matchtmBV,nodeFV,nodeFVact,leafProc,leafact,
    indexBVCR;
}
