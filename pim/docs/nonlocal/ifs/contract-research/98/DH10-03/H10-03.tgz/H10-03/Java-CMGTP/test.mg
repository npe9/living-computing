->p1(a),p2(a).
p1(X),p2(X)-> -q(X),r(X);s(X).
