/**
 * AConj.java 32e 2-Sep-1998
 * Copyright (c) 1997, 1998 Kyushu University
 */

class AConj {
  Term hd; AConj tl; MGTP mgtp; TMNode tmn; Cnsq cnsq;
  AConj() {}
  AConj(Term h) {hd=h;}
  AConj(Term h, AConj t) {hd=h; tl=t;}
  /*
  public String toString() {
    String s=""; AConj t=this;
    while (t.tl!=null) {s+=t.hd+"(tmn: "+t.tmn.getClass().getName()+"),\n "; t=t.tl;}
    return s+t.hd+"(tmn: "+t.tmn.getClass().getName()+")";
  }
  */
  public String toString() {
    String s=""; AConj t=this;
    while (t.tl!=null) {s+=t.hd+", "; t=t.tl;}
    return s+t.hd;
  }

  int length() {
    int l=0; AConj c=this;
    while (c!=null) {l++; c=c.tl;}
    return l;
  }
  AConj copy() {
    return (tl==null ? new AConj(hd) : new AConj(hd,tl.copy()));
  }
  AConj moveToHead(int i) {
    AConj prev=null; AConj cur=this;
    while (cur!=null) {
      if (i==0) {
	if (prev!=null) {prev.tl=cur.tl; cur.tl=this;}
	return cur;
      }
      i--;
      prev=cur; cur=cur.tl;
    }
    return null;
  }
}

// eof
