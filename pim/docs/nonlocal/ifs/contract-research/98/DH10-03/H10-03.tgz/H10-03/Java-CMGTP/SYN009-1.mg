p(c,X,Y)
->.

q(X,c,Y)
->.

r(X,Y,c)
->.

-> s(a) .

-> s(b) .

-> s(c) .

s(X),s(Y),s(Z)
->
p(X,Y,Z);q(X,Y,Z);r(X,Y,Z) .

