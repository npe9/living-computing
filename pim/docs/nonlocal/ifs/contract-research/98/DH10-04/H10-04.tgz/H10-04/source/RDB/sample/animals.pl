%%%%
% Copyright (C) 1999 Koichi FURUKAWA
%
% animals

:- set(c,5).

:- modeh(class(+animals,#class)).
:- modeb(has_gills(+animals)).
:- modeb(has_covering(+animals,#cov)).
:- modeb(has_legs(+animals,#legs)).
:- modeb(has_egg(+animals)).
:- modeb(habitat(+animals,#habit)).
:- modeb(has_milk(+animals)).

class(X,Y):- animals(X,Y,_,_,_,_,_,_).
has_gills(X):- animals(X,_,yes,_,_,_,_,_).
has_covering(X,Y):- animals(X,_,_,Y,_,_,_,_).
has_legs(X,Y):- animals(X,_,_,_,Y,_,_,_).
has_egg(X):- animals(X,_,_,_,_,yes,_,_).
habitat(X,Y):- animals(X,_,_,_,_,_,Y,_).
has_milk(X):-animals(X,_,_,_,_,_,_,yes).
