/* Copyright (C) 1999 Koichi FURUKAWA

   Output Class */

import java.awt.*;
class OutPanel extends Panel {
  TextArea ta;

  //Constructor
  OutPanel() {
    ta = new TextArea();
    ta.setEditable(false); //This TextArea is only used for output

    //Position of TextArea
    setLayout(new BorderLayout());
    add("Center", ta);
  }

  //Methods
  void showText(String str) {
    ta.setText(str);
  }

  void addText(String str){
    ta.append(str);
  }
}
