%% Copyright (C) 1999 Koichi FURUKAWA

:- compile(datagol),save_program('datagol.sav'),halt.
