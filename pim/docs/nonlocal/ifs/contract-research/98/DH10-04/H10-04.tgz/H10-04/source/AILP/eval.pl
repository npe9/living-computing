%%%%
% Copyright (C) 1999 Koichi FURUKAWA
%
%eval.pl

'$pos_eval'(Cls, Depth):-
	clause(Cls,true),!,
	retract(Cls),
	('$eval'(Cls,Depth) -> assertz(Cls);(assertz(Cls),!,fail)).

'$pos_eval'(Cls, Depth):-
	'$eval'(Cls,Depth).

'$eval'(H, Depth):- '$eval'(H, Depth, _).
%'$eval'(H,_Depth):-call(H).

'$eval'(H, D, Dz):- D>0, '$eval1'(H, D, Dz).

'$eval1'((H,T), D, Dz):-!, '$eval'(H,D,Dm),'$eval'(T,Dm,Dz).
'$eval1'(H, D, D):- %\+(H = (_,_) ),
	predicate_property(H, built_in),!,call(H).
'$eval1'(H, D, Dz):- %\+(H = (_,_)),
	clause(H,Body), D1 is D-1,
	'$eval'(Body, D1, Dz).


'$peval'(Cls,Lit,Depth,Red):-
	'$peval'(Cls,Cls,Lit,Depth,_, Red,[]).

'$peval'(H,Org,Lit,D,Dz,R,Rz):- D>0, '$peval1'(H,Org,Lit,D,Dz,R,Rz).

'$peval1'((H,T),Org,Lit,D,Dz,R,Rz):-
	'$peval'(H,Org,Lit,D,Dm,R,Rm), '$peval'(T,Org,Lit,Dm,Dz,Rm,Rz).
'$peval1'(H,_Org, _Lit,D,D, R,R):- \+(H=(_,_)),
	predicate_property(H,built_in),!,call(H).

'$peval1'(H,Org, Lit,D,Dz, R,Rz):- \+(H=(_,_)), \+(H==Org),
	clause(H,Body), D1 is D-1,
	'$peval'(Body,Org,Lit,D1,Dz, R,Rz).

'$peval1'(H,Org, Lit,D,Dz, R,Rz):- \+(H=(_,_)), H==Org,
	clause(H,Body),\+(Body=true), 	D1 is D-1,
	'$peval'(Body,Org,Lit,D1,Dz, R,Rz).

'$peval1'(H,_Org,Lit,D,Dz,[H|Rz],Rz):- \+(H=(_,_)),
	H=..[F|A], Lit=..[F|_A],
	'$name_concat'(['*',F], NF), %domain predicate���K�v
	NH =..[NF|A],
	'$eval'(NH, D,Dz).

