//Copyright (C) 1999 Koichi FURUKAWA
drop table animals;
create table animals
(
name varchar(15),
class varchar(15),
gills varchar(5),
covering varchar(10),
legs  integer,
eggs  varchar(15),
habitat varchar(15),
milk varchar(15)
);



insert into animals values ('bat','mammal','no','hair',2,'no','air','yes');
insert into animals values ('cat','mammal','no','no',0,'no','no','yes');
insert into animals values ('crocodile','reptile','no','scales',4,'yes','water','no');
insert into animals values ('dog','mammal','no','hair',4,'no','land','yes');
insert into animals values ('dolphin','mammal','no','none',0,'no','water','yes');
insert into animals values ('eagle','bird','no','feathers',2,'yes','air','no');
insert into animals values ('eel','fish','yes','none',0,'yes','water','no');
insert into animals values ('herring','fish','yes','scales',0,'yes','water','no');
insert into animals values ('lizard','reptile','no','scales',4,'yes','land','no');
insert into animals values ('ostrich','bird','no','feathers',2,'yes','land','no');
insert into animals values ('penguin','bird','no','feathers',2,'yes','water','no');
insert into animals values ('platypus','mammal','no','hair',2,'yes','water','yes');
insert into animals values ('shark','fish','yes','none',0,'yes','water','no');
insert into animals values ('t_rex','reptile','no','scales',4,'yes','land','no');
insert into animals values ('trout','fish','yes','scales',0,'yes','water','no');
insert into animals values ('turtle','reptile','no','scales',4,'yes','water','no');
insert into animals values ('snake','reptile','no','scales',0,'yes','land','no');
