% Copyright (C) 1999 Koichi FURUKAWA
%
% Consult All Files

:-[main].   %MAIN Procedure
:-[msh].    %MSH Construction
:-[search]. %A*-like Search
:-[trans].  %Prolog to SQL Translator
:-[util].   %Utility Program
:-[gui].    %Predicates called from GUI(Java)
:-[rdb].    %Java Prolog Interface.
