%%%%%%%% TEST %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%    window:
      (window/test ::= 
       +[
         -[bu1:button(text->"A",code->a),bu2:button(text->"B",code->b)],
         -[can:canvas(size->(200,150),relief->sunken,background->white)]]).

%%    window:
     (window/test2 ::= 
      +[-[b1:button(text->"Box",code->create_box), 
          b2:button(text->"Message",code->write_emssage), 
          b3:button(text->"EXIT",code->end,background->red)],
        -[l1:label(text->"Input->"),
          e1:entry(relief->sunken,width->25)],
        s-[t1:text(size->(25,4)),sc:scrollbar],
        s-[li:listbox(height->4,selectmode->multiple),sc2:scrollbar],
        s=[c1:canvas(size->(200,150)),sc3:scrollbar,sc4:scrollbar]]).

%%    window:
      (window/sub ::= 
      +[sb1:button(text->"B1",code->sub_1), 
        sb2:button(text->"B2",code->sub_2), 
        sb3:button(text->"B3",code->sub_3,background->green)]).

my_test:-
   init_window,
   create(test,[],WinObj),
   get_parts(WinObj,can,CanObj),
   createBox(CanObj,[10,10,20,20],[fill->red],RedBoxObj),
   createBox(CanObj,[50,10,60,20],[fill->blue],BlueBoxObj),
   flush,
   dragable(RedBoxObj,ok),
   repeat,
   get_event(WinObj,Event),
   (Event==a,move(BlueBoxObj,30,0),fail;
    Event==b,!;
    Event==ok,move(BlueBoxObj,0,30),fail),
   kill(WinObj).

test:-
   init_window,
   create(test2,[],W),
   flush,
   createSubWin(W,sub,Sub),
   flush,
   get_event(W,E1),
   write(E1),nl,
   iconify(Sub),
   get_parts(W,c1,Can),
%redraw_parts(Sub,ptest),
   createBox(Can,[20,20,80,80],[fill->blue],Obj),
   createBox(Can,[120,10,140,30],[fill->red],Obj1),
   createBox(Can,[120,50,140,70],[fill->green],Obj2),
   flush,
   createGroup(G),
   regist(G,[Obj1,Obj2]),
   click_notify(G,click_mouse_from_group),
   click_notify(Obj,click_mouse),
   dragable(Obj,drag_ok),
   dragable(G,drag_group_ok),
   get_parts(W,e1,InP),
   get_text(InP,TXT1),
   puts(TXT1),nl,
   get_parts(W,t1,OutP),
   putl_text(OutP,TXT1),
   get_event(W,E2),
   deiconify(Sub),
   move(G,-90,40),
   write(E2),nl,
   %move(Obj,50,50),
   %get_fig_info(Obj,[coords->V]),
   %puts(V),nl,
   %get_event(W,E3),
   %scale(G,0,70,1.5,1.5),
   %write(E3),nl,
   %invisible(Obj),
   %get_event(W,E4),
   %write(E4),nl,
   %visible(Obj),
   %get_event(W,E5),
   %write(E5),nl,
   %get_text(InP,TXT2),
   %puts(TXT2),nl,
   %putl_text(OutP,TXT2),
   %putl_text(OutP,"1"),
   %putl_text(OutP,"2"),
   %putl_text(OutP,"3"),
   %get_event(W,E6),
   %write(E6),nl,
   %clear_text(OutP),
   %get_parts(W,li,List),
   %set_items(List,[ab,cd,ef,gh,ij,12,34,56]),
   %flush,
   %get_event(W,E7),
   %write(E7),nl,
   %get_items(List,Items),
   %write(Items),nl,
   get_event(W,E8),
   undragable(G),
   get_event(W,_),
   kill(W).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

