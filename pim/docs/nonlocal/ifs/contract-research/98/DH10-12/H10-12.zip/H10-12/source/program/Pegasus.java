//  Copyright (C) 1999 Takeo Igarashi

/*
  Pegasus java version
 */

import java.awt.event.*;
import java.awt.*;
import java.applet.*;

import java.lang.Math.*;

import java.util.Vector;

/** �A�v���b�g */
public class Pegasus extends Applet{

	

    // applet
    public void init() {
	setLayout(new BorderLayout());
	//Panel dp = new Panel();
	DrawPanel dp = new DrawPanel();
	add("Center", dp);
	add("South",new DrawControls(dp, this));
    }

/*
    // independent application
    static Frame f;
    public static void main(String args[]) {
	f = new Frame("pegasus");
	Pegasus pegasus = new Pegasus();
	pegasus.init();
	pegasus.start();

	f.addWindowListener(
	  new WindowAdapter(){
	    public void windowClosing(WindowEvent e) {System.exit(0);}}
        );
	f.addKeyListener(
	  new KeyAdapter(){
	    public void keyPress(KeyEvent e) {
		System.out.println(e.getKeyCode());
		System.out.println(e.VK_C);
		if (e.getKeyCode() == e.VK_C)
		  System.exit(0);}}
        );

	f.add("Center", pegasus);
	f.setSize(400, 300);
	f.show();
    }
*/
	
}
















