//  Copyright (C) 1999 Takeo Igarashi

import java.awt.*;
import java.lang.*;
import java.util.*;


/** ���`����ї\���̌�� */
public class Candidate extends Segment {

	//	segment in the candidates
	public LinkedList related_constraints;

	Candidate(double _x1, double _y1, double _x2, double _y2, LinkedList history){
		super(_x1,_y1,_x2,_y2);
		related_constraints = history;
	}
	Candidate(double _x1, double _y1, double _x2, double _y2){
		super(_x1,_y1,_x2,_y2);
		related_constraints = new LinkedList();
	}
	/*
	Candidate(Segment s){
		super(s.x1, s.y1, s.x2, s.y2);
		related_constraints = new LinkedList();
	}
	*/

}
