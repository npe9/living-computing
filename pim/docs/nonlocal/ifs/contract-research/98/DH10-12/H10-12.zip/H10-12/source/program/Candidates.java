//  Copyright (C) 1999 Takeo Igarashi

import java.awt.*;
import java.lang.*;
import java.lang.Math.*;
import java.util.*;

/** ���`����ї\���̌��W�� */
public class Candidates extends Segments{

  private Candidate primary;


  Candidates(){
	super();
	primary = null;
  }

  public void set_primary(Candidate target){
	primary = target;
  }
  
  public Segment get_primary_segment(){
	return (Segment) primary;
  }
  public Candidate get_primary_candidate(){
	return primary;
  }

  public void clear(){
		segments = new LinkedList();
		primary = null;
  }



 

}
