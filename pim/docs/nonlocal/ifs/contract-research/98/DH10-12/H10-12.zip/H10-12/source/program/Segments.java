//  Copyright (C) 1999 Takeo Igarashi

import java.awt.*;
import java.lang.*;
import java.lang.Math.*;
import java.util.*;
import java.io.*;



/** a collection of segments. linkedlist �̉B�� */
public class Segments implements Serializable{

	//	the collection of segments
	// 	LinkedList segment_list

	public LinkedList segments;

	Segments(){
		segments = new LinkedList();
	}

    public Segment get_closest(double x, double y, double min){

	double current = min;
	double distance;
	Node point = new Node(x, y);
	Segment result = null;
	Segment segment;

	Enumeration e = elements();
      	while (e.hasMoreElements()){
	    segment =  (Segment) e.nextElement();
	    distance = segment.distance(point);
	    if ((current == distance) && (result != null)){
		if (segment.length() < result.length())
		    result = segment;
	    }
	    else if (current >= distance) {
		current = distance;
		result = segment;
	    }		 
	}
	
	return result;

    }










	public boolean contain_identical_segment(Segment segment){
            Enumeration e = elements();
	    while (e.hasMoreElements())
		if (segment.same((Segment) e.nextElement())) return true;
	    return false;
	}
	        



	public void append(Segment segment){
	    if (!Def.negrigible(segment.length()))
		segments.append(segment);
	}
	public void remove(){
		segments.remove();
	}
	public void remove(Object object){
		segments.remove(object);
	}
	public void clear(){
		segments = new LinkedList();
	}
	public int size(){
		return segments.size();
	}
	public Enumeration elements(){
		return segments.elements();
	}


	/** reset the cursor */ 
	public void reset(){
		segments.reset();
	}
	public boolean hasMoreElements(){
		return segments.hasMoreElements();
	}
	public Segment currentElement(){
		return (Segment) segments.currentElement();
	}
	public Segment nextElement(){
		return (Segment) segments.nextElement();
	}
}





