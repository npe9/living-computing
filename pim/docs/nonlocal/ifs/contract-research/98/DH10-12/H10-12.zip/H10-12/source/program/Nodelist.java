//  Copyright (C) 1999 Takeo Igarashi

import java.awt.*;
import java.lang.*;

/** ��ʏ�̓_�̏W�� */
public class Nodelist extends LinkedList {

    public void sort(){
	reset();
	if (!hasMoreElements()) return;
	Node pivot = (Node) nextElement();
	Nodelist lower = new Nodelist();
	Nodelist higher = new Nodelist();
	while (hasMoreElements()){
	    Node node =  (Node) nextElement();
	    // �����_�͈�ɂ܂Ƃ߂�B
	    if (!pivot.same(node)){
	      if (greater(pivot, node))
		lower.append(node);
	      else
		higher.append(node);
	    }
	}
	lower.sort();
	higher.sort();
	lower.append(pivot);
	lower.connect(higher);
	substitute(lower);
    }

    private boolean greater(Node node1, Node node2){
	    if (Def.equal(node1.y, node2.y))
		return (  node1.x > node2.x );
	    else
		return (  node1.y > node2.y );
    }

 
}

