//  Copyright (C) 1999 Takeo Igarashi

import java.awt.*;
import java.lang.*;

/** ��ʒ��̓_ */
public class Node {
	public double x, y;
	Node(double _x, double _y){
	  x = _x;
	  y = _y;
	}

	public double distance(Node node){
	  return Math.sqrt((node.x-x)*(node.x-x)+(node.y-y)*(node.y-y));
	}
	public static double distance(Node n1, Node n2){
	  return Math.sqrt((n1.x-n2.x)*(n1.x-n2.x)+(n1.y-n2.y)*(n1.y-n2.y));
	}

	public boolean same(Node node){
	  //return (distance(node) < Def.ERROR_RANGE);
	  return (Def.equal(node.x, x) && Def.equal(node.y, y));
	}
}

