//  Copyright (C) 1999 Takeo Igarashi

import java.awt.*;
import java.lang.*;
import java.lang.Math.*;
import java.util.*;


/** a colleciton of sements. interval �̊Ǘ�, ��_�ł̕����Ɠ������s�� */
public class Scene extends Segments {

	//	the collection of segments
	// 	LinkedList segment_list

	public LinkedList intervals;	// �������� 0 ����

	Scene(){
		super();
		intervals = new LinkedList();
		intervals.append(new Interval(0, null, null));
	}





	// interval �̊Ǘ��B
	public double get_closest_interval(double interval){
	    double min = interval * 2;
	    double result = 0;	
	    double value;
            Enumeration e = intervals.elements();
	    while (e.hasMoreElements()){
		value = ( (Interval) e.nextElement()).value;
		if (min > Math.abs(interval - value)){
			min = Math.abs(interval - value);
			result = value;
		}
		else return result;   // �P�������̂͂��Ȃ̂ő������������炻�����ŉ��_
	    }
	    return result;   
	}
	
	public void add_new_interval(double interval, Segment segment, Segment segment2){
	    intervals.reset();
	    while (intervals.hasMoreElements()){
		Interval existing_interval = (Interval) intervals.currentElement();
		double value = 	existing_interval.value;
		if (Def.equal(interval,value)){
			existing_interval.add_owner(segment, segment2);
			return;
		}
		if (interval <	value){
		    intervals.insert(new Interval(interval, segment, segment2));
		    return;
		}
		intervals.nextElement();
	    }
	    intervals.append(new Interval(interval, segment, segment2));
 	}
	public void update_intervals(Segment segment){
	    double interval;
	    Segment segment2;
            Enumeration e = segments.elements();
	    while (e.hasMoreElements()){
		segment2 =  (Segment) e.nextElement();
		if (segment2.parallel(segment)){
		    interval = segment2.parallel_interval(segment); 
		    if (interval >=0 )	// overlap �̃`�F�b�N
			add_new_interval(interval, segment, segment2);
		}
	    }

	}

	public void display(){
            Enumeration e = intervals.elements();
	    System.out.print("intervals ");
	    while (e.hasMoreElements())
		System.out.print( ", "+ (int) ((Interval) e.nextElement()).value);
	    System.out.println("");

	}
	

	private void remove_intervals(Segment segment){
	    intervals.reset();
	    while (intervals.hasMoreElements()){
		Interval interval = (Interval) intervals.currentElement();
		boolean no_owner = interval.remove_owner(segment);
		if (no_owner)
		    intervals.remove();
		else 
		  intervals.nextElement();
	    }
	}
	


	/** ���s�����Ԃ̊Ԋu�̊Ǘ� */
	class Interval implements java.io.Serializable{
		public double value;
		public LinkedList owners;
	    Interval(double v, Segment segment1, Segment segment2){
		value = v;
		owners = new LinkedList();
		owners.append(new SegmentPair(segment1, segment2));
	    }
	    public void add_owner(Segment segment1, Segment segment2){
		owners.append(new SegmentPair(segment1, segment2));
	    }		
	    // no_owner?
	    public boolean remove_owner(Segment segment){
	        owners.reset();
	    	while (owners.hasMoreElements()){
		    SegmentPair owner = (SegmentPair) owners.currentElement();
		    if (owner.member(segment))
			owners.remove();
		    else
			owners.nextElement();
		}
		if (owners.size() == 0)
			return true;
		return false;
		
	    }		
	}
	class SegmentPair  implements java.io.Serializable{
		public Segment segment1;
		public Segment segment2;
	    SegmentPair(Segment s1, Segment s2){
		segment1 = s1;
		segment2 = s2;
	    }
	    public boolean member(Segment segment){
		return ((segment1 == segment) || (segment2 == segment));
	    }
	}













	/** �d�Ȃ��Ă�̂��܂Ƃ߂�B 
	    �]���Ȃ̂������āA����������������B(���΂�) */
	private Segment merge_segments(Segment segment){	
		    
	    reset();
	    while (hasMoreElements()){
		Segment old_segment = (Segment) currentElement();
		if ( (segment.same_line(old_segment)) &&
		       (segment.between(old_segment.start_node()) || 
		        segment.between(old_segment.end_node()) ||
		        old_segment.between(segment.start_node()) ||
		        old_segment.between(segment.end_node())) ){
		    // ���꒼����A���d�Ȃ肠��B
		    Nodelist nodelist = new Nodelist();
		    nodelist.append(old_segment.start_node());
		    nodelist.append(old_segment.end_node());
		    nodelist.append(segment.start_node());
		    nodelist.append(segment.end_node());
		    nodelist.sort();
		    // ������Ɨ\���ɕs�s�� segment.configure((Node) nodelist.head(), (Node) nodelist.tail());
		    segment = new Segment((Node) nodelist.head(), (Node) nodelist.tail());
		    _remove();
		  
		}
		else
		  nextElement();
	    }
	    return segment;
	}
	/** ��_�Ő؂�B 
	    �Â��̏����ĐV�����̉�����B */
	private void divide_segments(Segment segment){	

	    Segments created_segments = new Segments();

	    Nodelist nodelist = new Nodelist();
	    nodelist.append(segment.start_node());
	    nodelist.append(segment.end_node());	

	    Node cross_node;
	    reset();
	    while (hasMoreElements()){
		Segment old_segment = (Segment) currentElement();
		if (segment.cross(old_segment)){
		  cross_node  = segment.cross_node(old_segment);
		  if (cross_node == null){ 
    		    // ��_�Ōq�����Ă镽�s���B
		    nextElement();
		  }
		  else{
		    if (   !cross_node.same(old_segment.start_node())
			&& !cross_node.same(old_segment.end_node())  ){
			_remove();
			created_segments.append(new Segment(old_segment.start_node(), cross_node));
			created_segments.append(new Segment(old_segment.end_node(), cross_node));
		    }
		    else
			nextElement();
		    if (   !cross_node.same(segment.start_node())
			&& !cross_node.same(segment.end_node())  ){
			nodelist.append(cross_node);
		    }
		  }
	    	}
		else 
		  nextElement();
	    }	
	
	    // ��������Ăł����Â������̔j�Ђ�������B
	    Enumeration e = created_segments.elements();
	    while (e.hasMoreElements())
		_append((Segment) e.nextElement());
	
	
	    // �������ꂽ�V�����������B
	    nodelist.sort();
	    e = nodelist.elements();
	    Node prev = (Node) e.nextElement();
	    while (e.hasMoreElements()){
		Node next = (Node) e.nextElement();
		_append(new Segment(prev, next));
		prev = next;
	    }
	}
	
	/** remove �Ő����Ȃ��Ȃ������ƁA�c���������Ȃ���B */
	private void merge_segments_after_remove(Segment segment){	
	    Node start = segment.start_node();
	    Node end   = segment.end_node();
		
	    Segments connected_to_start = new Segments();
	    Segments connected_to_end = new Segments();

	    reset();
	    while (hasMoreElements()){
		Segment old_segment = (Segment) nextElement();
		if (start.same(old_segment.start_node()) ||
		    start.same(old_segment.end_node()) )
		    connected_to_start.append(old_segment);
		else if (end.same(old_segment.start_node()) ||
			 end.same(old_segment.end_node()) )
		    connected_to_end.append(old_segment);
	    }
	    merge_segments_after_remove_sub(connected_to_start, start);
	    merge_segments_after_remove_sub(connected_to_end,   end);
	}
	private void merge_segments_after_remove_sub(Segments connected_segments, Node node){	
	    if (connected_segments.size() != 2) return;
	    connected_segments.reset();
	    Segment segment1 = connected_segments.nextElement();
	    Segment segment2 = connected_segments.nextElement();
	    if (!segment1.same_line(segment2)) return;
	    Node start;
	    Node end;
	    if (node.same(segment1.start_node()))
		start = segment1.end_node();
	    else
		start = segment1.start_node();
	    if (node.same(segment2.start_node()))
		end = segment2.end_node();
	    else
		end = segment2.start_node();
	    _remove(segment1);
	    _remove(segment2);
	    _append(new Segment(start, end));
	}
	    





	/** append �̃I�[�o�[���C�g
	   segment �����X�g�։�����B��_���`�F�b�N���ĕ����������s���B */
	public void append(Segment segment){
		Segment merged_segment = merge_segments(segment);// �d�Ȃ��Ă�̂��܂Ƃ߂�B
		divide_segments(merged_segment);		// ��_�Ő؂��Ă��ꂼ����V�[���։�����B
	}


	// segment �����X�g�։�����B ���s�����Ԋu�̃`�F�b�N������B
	private void _append(Segment segment){
		update_intervals(segment);
		segments.append(segment);
	}
	
	/** remove �̃I�[�o�[���C�g
	   ��_���`�F�b�N���ē������s���B */
	public void remove(){
	    Segment segment = (Segment) currentElement();
	    _remove();
	    merge_segments_after_remove(segment);
	}

	// segment �����X�g���珜���B ���s�����Ԋu�̃`�F�b�N������B
	private void _remove(){
		Segment segment = (Segment) currentElement();
		remove_intervals(segment);
		segments.remove();
	}

	private void _remove(Segment segment){
		segments.remove(segment);
	}		
}
















