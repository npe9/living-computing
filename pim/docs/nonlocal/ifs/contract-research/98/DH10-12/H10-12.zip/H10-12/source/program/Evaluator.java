//  Copyright (C) 1999 Takeo Igarashi

import java.awt.*;
import java.lang.*;
import java.lang.Math.*;
import java.util.*;


/** �D��x�ɉ����ď��Ԃ����ւ��� */
public class Evaluator {

	public static Candidates evaluate(Candidates candidates){
		candidates.reset();
		Candidate primary = (Candidate) candidates.currentElement();
		candidates.set_primary(primary);
		return candidates;
	}
}


