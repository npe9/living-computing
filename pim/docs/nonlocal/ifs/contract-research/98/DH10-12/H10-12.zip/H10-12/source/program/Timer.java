//  Copyright (C) 1999 Takeo Igarashi

/** �^�C�}�[ */
final class Timer extends Thread{
	public int time;

	public Timer(int wait_time){
		time = wait_time;
		start();
	}
	public void run(){
            	try { Thread.sleep(time);              // $B0l;~Dd;_(B
            	} catch (InterruptedException e){}
	}
}
