//  Copyright (C) 1999 Takeo Igarashi


import java.io.*;


/**
 *   File Manager
 *
 */
public class File 
{
	public static void save(String filename, Object object)
	{
	  try{
	 	FileOutputStream ostream = new FileOutputStream(filename);
	        ObjectOutputStream p = new ObjectOutputStream(ostream);
        	p.writeObject(object);
	        p.flush();
        	ostream.close();
	  }
	  catch(Exception e)
	  {
		System.out.print("Error: " + e);
	  }			

	}

	public static Object load(String filename)
	{
	  try{
 	        FileInputStream istream = new FileInputStream(filename);
       	 	ObjectInputStream p = new ObjectInputStream(istream);
        	Object object = p.readObject();
        	istream.close();
		return object;
	  }
	  catch(Exception e)
	  {
		System.out.print("Error: " + e);
		return null;
	  }			
 	}

}