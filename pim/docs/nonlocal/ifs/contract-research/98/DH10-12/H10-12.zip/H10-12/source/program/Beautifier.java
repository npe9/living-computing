//  Copyright (C) 1999 Takeo Igarashi

import java.awt.*;
import java.lang.*;
import java.lang.Math.*;
import java.util.*;


/** �X�g���[�N���󂯎���āA���`����Ԃ� 
    new stroke + scene -> candidates         */
public class Beautifier {


	Beautifier(){
	}

	public static Segment beautify(Segment stroke, Scene scene){
		Segment segment = new Segment(
		  stroke.x1 + 10, stroke.y1,
		  stroke.x2 + 10, stroke.y2);

		return segment;
	}

	public static Candidates generate_candidates(Segment stroke, Scene scene, double size){


		Constraints constraints = Inferencer.infer_constraints(stroke, scene, size);
		Candidates candidates = Solver.solve_constraints(constraints, stroke, size);
		
		/*
		Candidates candidates = new Candidates();
		candidates.append(new Candidate(
		  stroke.x1, stroke.y1,
		  stroke.x2, stroke.y2));
		*/

		return Evaluator.evaluate(candidates); 


	}


}


