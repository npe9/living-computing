//
// HiRiseDemo: A Demo Applet for the HiRise Constraint Solver
//
// Copyright (C) 1998-1999 Hiroshi HOSOBE
//
////////////////////////////////////////////////////////////////

import java.awt.*;
import java.awt.event.*;

public class ExtTextField extends TextField implements FocusListener {

	ExtTextField(String text, int columns)
	{
		super(text, columns);
		addFocusListener(this);
	}
	
	public void focusGained(FocusEvent ev)
	{
		selectAll();
	}

	public void focusLost(FocusEvent ev)
	{
		// deselect text
		setText(getText());
	}
	
}
