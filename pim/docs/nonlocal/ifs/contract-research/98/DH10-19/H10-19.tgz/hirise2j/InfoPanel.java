//
// HiRiseDemo: A Demo Applet for the HiRise Constraint Solver
//
// Copyright (C) 1998-1999 Hiroshi HOSOBE
//
////////////////////////////////////////////////////////////////

import java.util.*;
import java.awt.*;

public final class InfoPanel extends Panel {
	
	public static final String info = "HiRiseDemo Version 2.0\n"
		+ "Copyright (C) 1998-1999 Hiroshi Hosobe";

	InfoPanel()
	{
		setLayout(new FlowLayout(FlowLayout.LEFT));
	
		Panel p = new Panel();
		add(p);
		p.setLayout(new GridLayout(2, 1));
		
		StringTokenizer st = new StringTokenizer(info, "\n");
		while (st.hasMoreTokens()) {
			Label l = new Label(st.nextToken());
			p.add(l);
		}
	}
	
}
