/* Compiled by KLIC compiler version 3.002 (Wed Sep 17 15:37:13 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_builtin__deps();
Const struct predicate predicate_builtin__deps_xmake_11 =
   { module_builtin__deps, 0, 11 };
Const struct predicate predicate_builtin__deps_xunify__deps_9 =
   { module_builtin__deps, 1, 9 };
Const struct predicate predicate_builtin__deps_xget__unify__deps_4 =
   { module_builtin__deps, 2, 4 };
Const struct predicate predicate_builtin__deps_xget__unify__deps_7 =
   { module_builtin__deps, 3, 7 };
Const struct predicate predicate_builtin__deps_xget__unify__deps2_7 =
   { module_builtin__deps, 4, 7 };
Const struct predicate predicate_builtin__deps_xget__unify__deps3_7 =
   { module_builtin__deps, 5, 7 };
Const struct predicate predicate_builtin__deps_xget__var_9 =
   { module_builtin__deps, 6, 9 };
Const struct predicate predicate_builtin__deps_xget__var2_4 =
   { module_builtin__deps, 7, 4 };
Const struct predicate predicate_builtin__deps_xget__unify__struct_6 =
   { module_builtin__deps, 8, 6 };
extern Const struct predicate predicate_list_xor__unique_3;
extern Const struct predicate predicate_list_xcheck__include_3;
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_typeset_xget_5;
extern Const struct predicate predicate_typeset_xget__arg__typeset_5;
extern Const struct predicate predicate_typeset_xvalue2typeset_5;
extern Const struct predicate predicate_depset_xdd__arg_4;
extern Const struct predicate predicate_depset_xdd__arg_7;
extern Const struct predicate predicate_dt_xentry__data__dep_4;

module module_builtin__deps(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  q a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  switch_on_pred() {
    case_pred(0, make_11_top);
    case_pred(1, unify__deps_9_top);
    case_pred(2, get__unify__deps_4_top);
    case_pred(3, get__unify__deps_7_top);
    case_pred(4, get__unify__deps2_7_top);
    case_pred(5, get__unify__deps3_7_top);
    case_pred(6, get__var_9_top);
    case_pred(7, get__var2_4_top);
    last_case_pred(8, get__unify__struct_6_top);
  }

 make_11_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13;
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 make_11_clear_reason:
  reasonp = reasons;
 make_11_0:
 make_11_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (isint(a1)) goto make_11_72;
  switch (symval(a1)) {
 case symval(makesym(atom_generic)):
 make_11_2:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (isint(a5)) goto make_11_49;
  switch (symval(a5)) {
 case symval(makesym(atom_new)):
 make_11_3:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_4:
  if (a6 != makeint(3L)) goto make_11_49;
 make_11_5:
  if (isref(a8)) goto make_11_8;
  x1 = makeint(1L);
  gblt_arg(x1,a8,x0,make_11_49);
 make_11_6:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_atom_1)) goto make_11_49;
  x2 = arg(x0, 0);
 make_11_7:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (isint(x2)) goto make_11_49;
  switch (symval(x2)) {
 case symval(makesym(atom_float)):
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x3 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x3;
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = (q)(struct goalrec*)&allocp[5];
  allocp[12] = (q)(&predicate_depset_xdd__arg_4);
  allocp[13] = makesym(atom_i);
  allocp[14] = x5 = makeref(&allocp[14]);
  allocp[15] = x4;
  allocp[16] = a7;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[19] = a0;
  allocp[20] = a2;
  allocp[21] = x6 = makeref(&allocp[21]);
  allocp[22] = a7;
  allocp[23] = x5;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_functor__table_xarg_3);
  allocp[26] = makeint(3L);
  allocp[27] = a8;
  allocp[28] = x6;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 case symval(makesym(atom_vector)):
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x3 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x3;
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = x5 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = makesym(functor_goal_4);
  allocp[12] = a0;
  allocp[13] = a2;
  allocp[14] = a3;
  allocp[15] = a4;
  x6 = makefunctor(&allocp[11]);
  allocp[16] = (q)(struct goalrec*)&allocp[5];
  allocp[17] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[18] = x6;
  allocp[19] = x7 = makeref(&allocp[19]);
  allocp[20] = a9;
  allocp[21] = x5;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_depset_xdd__arg_4);
  allocp[24] = makesym(atom_l);
  allocp[25] = x8 = makeref(&allocp[25]);
  allocp[26] = x4;
  allocp[27] = a7;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_depset_xdd__arg_4);
  allocp[30] = makesym(atom_i);
  allocp[31] = x8;
  allocp[32] = x7;
  allocp[33] = a7;
  allocp[34] = (q)(struct goalrec*)&allocp[28];
  allocp[35] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[36] = a0;
  allocp[37] = a2;
  allocp[38] = x9 = makeref(&allocp[38]);
  allocp[39] = a7;
  allocp[40] = x8;
  allocp[41] = (q)(struct goalrec*)&allocp[34];
  allocp[42] = (q)(&predicate_functor__table_xarg_3);
  allocp[43] = makeint(3L);
  allocp[44] = a8;
  allocp[45] = x9;
  qp = (struct goalrec*)&allocp[41];
  allocp += 46;
  proceed();
  };
  goto make_11_49;
 case VARREF:
  deref_and_jump(x2,make_11_7);
  *reasonp++ =  x2;
  goto make_11_49;
  };
  goto make_11_49;
 case VARREF:
  deref_and_jump(x0,make_11_6);
  *reasonp++ =  x0;
  goto make_11_49;
  };
  goto make_11_49;
 make_11_8:
  deref_and_jump(a8,make_11_5);
  *reasonp++ =  a8;
  goto make_11_49;
 case VARREF:
  deref_and_jump(a6,make_11_3);
  *reasonp++ =  a6;
  goto make_11_49;
  };
  goto make_11_49;
 case symval(makesym(atom_add)):
 make_11_9:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_10:
  if (a6 != makeint(3L)) goto make_11_49;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = makesym(functor_goal_4);
  allocp[12] = a0;
  allocp[13] = a2;
  allocp[14] = a3;
  allocp[15] = a4;
  x3 = makefunctor(&allocp[11]);
  allocp[16] = (q)(struct goalrec*)&allocp[5];
  allocp[17] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[18] = x3;
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = a9;
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_depset_xdd__arg_4);
  allocp[24] = makesym(atom_f);
  allocp[25] = x5 = makeref(&allocp[25]);
  allocp[26] = x1;
  allocp[27] = a7;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_depset_xdd__arg_4);
  allocp[30] = makesym(atom_f);
  allocp[31] = x6 = makeref(&allocp[31]);
  allocp[32] = x4;
  allocp[33] = a7;
  allocp[34] = (q)(struct goalrec*)&allocp[28];
  allocp[35] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[36] = a0;
  allocp[37] = a2;
  allocp[38] = x7 = makeref(&allocp[38]);
  allocp[39] = a7;
  allocp[40] = x5;
  allocp[41] = (q)(struct goalrec*)&allocp[34];
  allocp[42] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[43] = a0;
  allocp[44] = a2;
  allocp[45] = x8 = makeref(&allocp[45]);
  allocp[46] = a7;
  allocp[47] = x6;
  allocp[48] = (q)(struct goalrec*)&allocp[41];
  allocp[49] = (q)(&predicate_functor__table_xarg_3);
  allocp[50] = makeint(2L);
  allocp[51] = a8;
  allocp[52] = x7;
  allocp[53] = (q)(struct goalrec*)&allocp[48];
  allocp[54] = (q)(&predicate_functor__table_xarg_3);
  allocp[55] = makeint(1L);
  allocp[56] = a8;
  allocp[57] = x8;
  qp = (struct goalrec*)&allocp[53];
  allocp += 58;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_9);
  *reasonp++ =  a6;
  goto make_11_49;
  };
  goto make_11_49;
 case symval(makesym(atom_subtract)):
 make_11_11:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_12:
  if (a6 != makeint(3L)) goto make_11_49;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = makesym(functor_goal_4);
  allocp[12] = a0;
  allocp[13] = a2;
  allocp[14] = a3;
  allocp[15] = a4;
  x3 = makefunctor(&allocp[11]);
  allocp[16] = (q)(struct goalrec*)&allocp[5];
  allocp[17] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[18] = x3;
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = a9;
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_depset_xdd__arg_4);
  allocp[24] = makesym(atom_f);
  allocp[25] = x5 = makeref(&allocp[25]);
  allocp[26] = x1;
  allocp[27] = a7;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_depset_xdd__arg_4);
  allocp[30] = makesym(atom_f);
  allocp[31] = x6 = makeref(&allocp[31]);
  allocp[32] = x4;
  allocp[33] = a7;
  allocp[34] = (q)(struct goalrec*)&allocp[28];
  allocp[35] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[36] = a0;
  allocp[37] = a2;
  allocp[38] = x7 = makeref(&allocp[38]);
  allocp[39] = a7;
  allocp[40] = x5;
  allocp[41] = (q)(struct goalrec*)&allocp[34];
  allocp[42] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[43] = a0;
  allocp[44] = a2;
  allocp[45] = x8 = makeref(&allocp[45]);
  allocp[46] = a7;
  allocp[47] = x6;
  allocp[48] = (q)(struct goalrec*)&allocp[41];
  allocp[49] = (q)(&predicate_functor__table_xarg_3);
  allocp[50] = makeint(2L);
  allocp[51] = a8;
  allocp[52] = x7;
  allocp[53] = (q)(struct goalrec*)&allocp[48];
  allocp[54] = (q)(&predicate_functor__table_xarg_3);
  allocp[55] = makeint(1L);
  allocp[56] = a8;
  allocp[57] = x8;
  qp = (struct goalrec*)&allocp[53];
  allocp += 58;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_11);
  *reasonp++ =  a6;
  goto make_11_49;
  };
  goto make_11_49;
 case symval(makesym(atom_multiply)):
 make_11_13:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_14:
  if (a6 != makeint(3L)) goto make_11_49;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = makesym(functor_goal_4);
  allocp[12] = a0;
  allocp[13] = a2;
  allocp[14] = a3;
  allocp[15] = a4;
  x3 = makefunctor(&allocp[11]);
  allocp[16] = (q)(struct goalrec*)&allocp[5];
  allocp[17] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[18] = x3;
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = a9;
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_depset_xdd__arg_4);
  allocp[24] = makesym(atom_f);
  allocp[25] = x5 = makeref(&allocp[25]);
  allocp[26] = x1;
  allocp[27] = a7;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_depset_xdd__arg_4);
  allocp[30] = makesym(atom_f);
  allocp[31] = x6 = makeref(&allocp[31]);
  allocp[32] = x4;
  allocp[33] = a7;
  allocp[34] = (q)(struct goalrec*)&allocp[28];
  allocp[35] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[36] = a0;
  allocp[37] = a2;
  allocp[38] = x7 = makeref(&allocp[38]);
  allocp[39] = a7;
  allocp[40] = x5;
  allocp[41] = (q)(struct goalrec*)&allocp[34];
  allocp[42] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[43] = a0;
  allocp[44] = a2;
  allocp[45] = x8 = makeref(&allocp[45]);
  allocp[46] = a7;
  allocp[47] = x6;
  allocp[48] = (q)(struct goalrec*)&allocp[41];
  allocp[49] = (q)(&predicate_functor__table_xarg_3);
  allocp[50] = makeint(2L);
  allocp[51] = a8;
  allocp[52] = x7;
  allocp[53] = (q)(struct goalrec*)&allocp[48];
  allocp[54] = (q)(&predicate_functor__table_xarg_3);
  allocp[55] = makeint(1L);
  allocp[56] = a8;
  allocp[57] = x8;
  qp = (struct goalrec*)&allocp[53];
  allocp += 58;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_13);
  *reasonp++ =  a6;
  goto make_11_49;
  };
  goto make_11_49;
 case symval(makesym(atom_divide)):
 make_11_15:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_16:
  if (a6 != makeint(3L)) goto make_11_49;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = makesym(functor_goal_4);
  allocp[12] = a0;
  allocp[13] = a2;
  allocp[14] = a3;
  allocp[15] = a4;
  x3 = makefunctor(&allocp[11]);
  allocp[16] = (q)(struct goalrec*)&allocp[5];
  allocp[17] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[18] = x3;
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = a9;
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_depset_xdd__arg_4);
  allocp[24] = makesym(atom_f);
  allocp[25] = x5 = makeref(&allocp[25]);
  allocp[26] = x1;
  allocp[27] = a7;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_depset_xdd__arg_4);
  allocp[30] = makesym(atom_f);
  allocp[31] = x6 = makeref(&allocp[31]);
  allocp[32] = x4;
  allocp[33] = a7;
  allocp[34] = (q)(struct goalrec*)&allocp[28];
  allocp[35] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[36] = a0;
  allocp[37] = a2;
  allocp[38] = x7 = makeref(&allocp[38]);
  allocp[39] = a7;
  allocp[40] = x5;
  allocp[41] = (q)(struct goalrec*)&allocp[34];
  allocp[42] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[43] = a0;
  allocp[44] = a2;
  allocp[45] = x8 = makeref(&allocp[45]);
  allocp[46] = a7;
  allocp[47] = x6;
  allocp[48] = (q)(struct goalrec*)&allocp[41];
  allocp[49] = (q)(&predicate_functor__table_xarg_3);
  allocp[50] = makeint(2L);
  allocp[51] = a8;
  allocp[52] = x7;
  allocp[53] = (q)(struct goalrec*)&allocp[48];
  allocp[54] = (q)(&predicate_functor__table_xarg_3);
  allocp[55] = makeint(1L);
  allocp[56] = a8;
  allocp[57] = x8;
  qp = (struct goalrec*)&allocp[53];
  allocp += 58;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_15);
  *reasonp++ =  a6;
  goto make_11_49;
  };
  goto make_11_49;
 case symval(makesym(atom_pow)):
 make_11_17:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_18:
  if (a6 != makeint(3L)) goto make_11_49;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = makesym(functor_goal_4);
  allocp[12] = a0;
  allocp[13] = a2;
  allocp[14] = a3;
  allocp[15] = a4;
  x3 = makefunctor(&allocp[11]);
  allocp[16] = (q)(struct goalrec*)&allocp[5];
  allocp[17] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[18] = x3;
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = a9;
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_depset_xdd__arg_4);
  allocp[24] = makesym(atom_f);
  allocp[25] = x5 = makeref(&allocp[25]);
  allocp[26] = x1;
  allocp[27] = a7;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_depset_xdd__arg_4);
  allocp[30] = makesym(atom_f);
  allocp[31] = x6 = makeref(&allocp[31]);
  allocp[32] = x4;
  allocp[33] = a7;
  allocp[34] = (q)(struct goalrec*)&allocp[28];
  allocp[35] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[36] = a0;
  allocp[37] = a2;
  allocp[38] = x7 = makeref(&allocp[38]);
  allocp[39] = a7;
  allocp[40] = x5;
  allocp[41] = (q)(struct goalrec*)&allocp[34];
  allocp[42] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[43] = a0;
  allocp[44] = a2;
  allocp[45] = x8 = makeref(&allocp[45]);
  allocp[46] = a7;
  allocp[47] = x6;
  allocp[48] = (q)(struct goalrec*)&allocp[41];
  allocp[49] = (q)(&predicate_functor__table_xarg_3);
  allocp[50] = makeint(2L);
  allocp[51] = a8;
  allocp[52] = x7;
  allocp[53] = (q)(struct goalrec*)&allocp[48];
  allocp[54] = (q)(&predicate_functor__table_xarg_3);
  allocp[55] = makeint(1L);
  allocp[56] = a8;
  allocp[57] = x8;
  qp = (struct goalrec*)&allocp[53];
  allocp += 58;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_17);
  *reasonp++ =  a6;
  goto make_11_49;
  };
  goto make_11_49;
 case symval(makesym(atom_sin)):
 make_11_19:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_20:
  if (a6 != makeint(2L)) goto make_11_49;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = (q)(struct goalrec*)&allocp[5];
  allocp[12] = (q)(&predicate_depset_xdd__arg_4);
  allocp[13] = makesym(atom_f);
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = a7;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[19] = a0;
  allocp[20] = a2;
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = a7;
  allocp[23] = x2;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_functor__table_xarg_3);
  allocp[26] = makeint(1L);
  allocp[27] = a8;
  allocp[28] = x3;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_19);
  *reasonp++ =  a6;
  goto make_11_49;
  };
  goto make_11_49;
 case symval(makesym(atom_cos)):
 make_11_21:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_22:
  if (a6 != makeint(2L)) goto make_11_49;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = (q)(struct goalrec*)&allocp[5];
  allocp[12] = (q)(&predicate_depset_xdd__arg_4);
  allocp[13] = makesym(atom_f);
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = a7;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[19] = a0;
  allocp[20] = a2;
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = a7;
  allocp[23] = x2;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_functor__table_xarg_3);
  allocp[26] = makeint(1L);
  allocp[27] = a8;
  allocp[28] = x3;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_21);
  *reasonp++ =  a6;
  goto make_11_49;
  };
  goto make_11_49;
 case symval(makesym(atom_tan)):
 make_11_23:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_24:
  if (a6 != makeint(2L)) goto make_11_49;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = (q)(struct goalrec*)&allocp[5];
  allocp[12] = (q)(&predicate_depset_xdd__arg_4);
  allocp[13] = makesym(atom_f);
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = a7;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[19] = a0;
  allocp[20] = a2;
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = a7;
  allocp[23] = x2;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_functor__table_xarg_3);
  allocp[26] = makeint(1L);
  allocp[27] = a8;
  allocp[28] = x3;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_23);
  *reasonp++ =  a6;
  goto make_11_49;
  };
  goto make_11_49;
 case symval(makesym(atom_asin)):
 make_11_25:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_26:
  if (a6 != makeint(2L)) goto make_11_49;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = (q)(struct goalrec*)&allocp[5];
  allocp[12] = (q)(&predicate_depset_xdd__arg_4);
  allocp[13] = makesym(atom_f);
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = a7;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[19] = a0;
  allocp[20] = a2;
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = a7;
  allocp[23] = x2;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_functor__table_xarg_3);
  allocp[26] = makeint(1L);
  allocp[27] = a8;
  allocp[28] = x3;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_25);
  *reasonp++ =  a6;
  goto make_11_49;
  };
  goto make_11_49;
 case symval(makesym(atom_acos)):
 make_11_27:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_28:
  if (a6 != makeint(2L)) goto make_11_49;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = (q)(struct goalrec*)&allocp[5];
  allocp[12] = (q)(&predicate_depset_xdd__arg_4);
  allocp[13] = makesym(atom_f);
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = a7;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[19] = a0;
  allocp[20] = a2;
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = a7;
  allocp[23] = x2;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_functor__table_xarg_3);
  allocp[26] = makeint(1L);
  allocp[27] = a8;
  allocp[28] = x3;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_27);
  *reasonp++ =  a6;
  goto make_11_49;
  };
  goto make_11_49;
 case symval(makesym(atom_atan)):
 make_11_29:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_30:
  if (a6 != makeint(2L)) goto make_11_49;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = (q)(struct goalrec*)&allocp[5];
  allocp[12] = (q)(&predicate_depset_xdd__arg_4);
  allocp[13] = makesym(atom_f);
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = a7;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[19] = a0;
  allocp[20] = a2;
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = a7;
  allocp[23] = x2;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_functor__table_xarg_3);
  allocp[26] = makeint(1L);
  allocp[27] = a8;
  allocp[28] = x3;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_29);
  *reasonp++ =  a6;
  goto make_11_49;
  };
  goto make_11_49;
 case symval(makesym(atom_sinh)):
 make_11_31:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_32:
  if (a6 != makeint(2L)) goto make_11_49;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = (q)(struct goalrec*)&allocp[5];
  allocp[12] = (q)(&predicate_depset_xdd__arg_4);
  allocp[13] = makesym(atom_f);
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = a7;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[19] = a0;
  allocp[20] = a2;
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = a7;
  allocp[23] = x2;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_functor__table_xarg_3);
  allocp[26] = makeint(1L);
  allocp[27] = a8;
  allocp[28] = x3;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_31);
  *reasonp++ =  a6;
  goto make_11_49;
  };
  goto make_11_49;
 case symval(makesym(atom_cosh)):
 make_11_33:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_34:
  if (a6 != makeint(2L)) goto make_11_49;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = (q)(struct goalrec*)&allocp[5];
  allocp[12] = (q)(&predicate_depset_xdd__arg_4);
  allocp[13] = makesym(atom_f);
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = a7;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[19] = a0;
  allocp[20] = a2;
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = a7;
  allocp[23] = x2;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_functor__table_xarg_3);
  allocp[26] = makeint(1L);
  allocp[27] = a8;
  allocp[28] = x3;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_33);
  *reasonp++ =  a6;
  goto make_11_49;
  };
  goto make_11_49;
 case symval(makesym(atom_tanh)):
 make_11_35:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_36:
  if (a6 != makeint(2L)) goto make_11_49;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = (q)(struct goalrec*)&allocp[5];
  allocp[12] = (q)(&predicate_depset_xdd__arg_4);
  allocp[13] = makesym(atom_f);
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = a7;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[19] = a0;
  allocp[20] = a2;
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = a7;
  allocp[23] = x2;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_functor__table_xarg_3);
  allocp[26] = makeint(1L);
  allocp[27] = a8;
  allocp[28] = x3;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_35);
  *reasonp++ =  a6;
  goto make_11_49;
  };
  goto make_11_49;
 case symval(makesym(atom_exp)):
 make_11_37:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_38:
  if (a6 != makeint(2L)) goto make_11_49;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = (q)(struct goalrec*)&allocp[5];
  allocp[12] = (q)(&predicate_depset_xdd__arg_4);
  allocp[13] = makesym(atom_f);
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = a7;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[19] = a0;
  allocp[20] = a2;
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = a7;
  allocp[23] = x2;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_functor__table_xarg_3);
  allocp[26] = makeint(1L);
  allocp[27] = a8;
  allocp[28] = x3;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_37);
  *reasonp++ =  a6;
  goto make_11_49;
  };
  goto make_11_49;
 case symval(makesym(atom_log)):
 make_11_39:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_40:
  if (a6 != makeint(2L)) goto make_11_49;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = (q)(struct goalrec*)&allocp[5];
  allocp[12] = (q)(&predicate_depset_xdd__arg_4);
  allocp[13] = makesym(atom_f);
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = a7;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[19] = a0;
  allocp[20] = a2;
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = a7;
  allocp[23] = x2;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_functor__table_xarg_3);
  allocp[26] = makeint(1L);
  allocp[27] = a8;
  allocp[28] = x3;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_39);
  *reasonp++ =  a6;
  goto make_11_49;
  };
  goto make_11_49;
 case symval(makesym(atom_sqrt)):
 make_11_41:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_42:
  if (a6 != makeint(2L)) goto make_11_49;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = (q)(struct goalrec*)&allocp[5];
  allocp[12] = (q)(&predicate_depset_xdd__arg_4);
  allocp[13] = makesym(atom_f);
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = a7;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[19] = a0;
  allocp[20] = a2;
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = a7;
  allocp[23] = x2;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_functor__table_xarg_3);
  allocp[26] = makeint(1L);
  allocp[27] = a8;
  allocp[28] = x3;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_41);
  *reasonp++ =  a6;
  goto make_11_49;
  };
  goto make_11_49;
 case symval(makesym(atom_ceil)):
 make_11_43:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_44:
  if (a6 != makeint(2L)) goto make_11_49;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = (q)(struct goalrec*)&allocp[5];
  allocp[12] = (q)(&predicate_depset_xdd__arg_4);
  allocp[13] = makesym(atom_f);
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = a7;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[19] = a0;
  allocp[20] = a2;
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = a7;
  allocp[23] = x2;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_functor__table_xarg_3);
  allocp[26] = makeint(1L);
  allocp[27] = a8;
  allocp[28] = x3;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_43);
  *reasonp++ =  a6;
  goto make_11_49;
  };
  goto make_11_49;
 case symval(makesym(atom_floor)):
 make_11_45:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_46:
  if (a6 != makeint(2L)) goto make_11_49;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = (q)(struct goalrec*)&allocp[5];
  allocp[12] = (q)(&predicate_depset_xdd__arg_4);
  allocp[13] = makesym(atom_f);
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = a7;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[19] = a0;
  allocp[20] = a2;
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = a7;
  allocp[23] = x2;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_functor__table_xarg_3);
  allocp[26] = makeint(1L);
  allocp[27] = a8;
  allocp[28] = x3;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_45);
  *reasonp++ =  a6;
  goto make_11_49;
  };
  goto make_11_49;
 case symval(makesym(atom_element)):
 make_11_47:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_48:
  if (a6 != makeint(3L)) goto make_11_49;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = makesym(functor_goal_4);
  allocp[12] = a0;
  allocp[13] = a2;
  allocp[14] = a3;
  allocp[15] = a4;
  x3 = makefunctor(&allocp[11]);
  allocp[16] = (q)(struct goalrec*)&allocp[5];
  allocp[17] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[18] = x3;
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = a9;
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_depset_xdd__arg_4);
  allocp[24] = makesym(atom_i);
  allocp[25] = x5 = makeref(&allocp[25]);
  allocp[26] = x1;
  allocp[27] = a7;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_depset_xdd__arg_4);
  allocp[30] = makesym(atom_v);
  allocp[31] = x6 = makeref(&allocp[31]);
  allocp[32] = x4;
  allocp[33] = a7;
  allocp[34] = (q)(struct goalrec*)&allocp[28];
  allocp[35] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[36] = a0;
  allocp[37] = a2;
  allocp[38] = x7 = makeref(&allocp[38]);
  allocp[39] = a7;
  allocp[40] = x5;
  allocp[41] = (q)(struct goalrec*)&allocp[34];
  allocp[42] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[43] = a0;
  allocp[44] = a2;
  allocp[45] = x8 = makeref(&allocp[45]);
  allocp[46] = a7;
  allocp[47] = x6;
  allocp[48] = (q)(struct goalrec*)&allocp[41];
  allocp[49] = (q)(&predicate_functor__table_xarg_3);
  allocp[50] = makeint(2L);
  allocp[51] = a8;
  allocp[52] = x7;
  allocp[53] = (q)(struct goalrec*)&allocp[48];
  allocp[54] = (q)(&predicate_functor__table_xarg_3);
  allocp[55] = makeint(1L);
  allocp[56] = a8;
  allocp[57] = x8;
  qp = (struct goalrec*)&allocp[53];
  allocp += 58;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_47);
  *reasonp++ =  a6;
  goto make_11_49;
  };
  goto make_11_49;
  };
  goto make_11_49;
 case VARREF:
  deref_and_jump(a5,make_11_2);
  *reasonp++ =  a5;
  goto make_11_49;
  };
  goto make_11_49;
 make_11_49:
 make_11_50:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (isint(a3)) goto make_11_72;
  switch (symval(a3)) {
 case symval(makesym(atom_guard)):
 make_11_51:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (isint(a5)) goto make_11_72;
  switch (symval(a5)) {
 case symval(makesym(atom_greater__than)):
 make_11_52:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_53:
  if (a6 != makeint(2L)) goto make_11_72;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = makesym(atom_guard);
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = makesym(functor_goal_4);
  allocp[12] = a0;
  allocp[13] = a2;
  allocp[14] = makesym(atom_guard);
  allocp[15] = a4;
  x3 = makefunctor(&allocp[11]);
  allocp[16] = (q)(struct goalrec*)&allocp[5];
  allocp[17] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[18] = x3;
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = a9;
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_depset_xdd__arg_4);
  allocp[24] = makesym(atom_f);
  allocp[25] = x5 = makeref(&allocp[25]);
  allocp[26] = x1;
  allocp[27] = a7;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_depset_xdd__arg_4);
  allocp[30] = makesym(atom_f);
  allocp[31] = x6 = makeref(&allocp[31]);
  allocp[32] = x4;
  allocp[33] = a7;
  allocp[34] = (q)(struct goalrec*)&allocp[28];
  allocp[35] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[36] = a0;
  allocp[37] = a2;
  allocp[38] = x7 = makeref(&allocp[38]);
  allocp[39] = a7;
  allocp[40] = x5;
  allocp[41] = (q)(struct goalrec*)&allocp[34];
  allocp[42] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[43] = a0;
  allocp[44] = a2;
  allocp[45] = x8 = makeref(&allocp[45]);
  allocp[46] = a7;
  allocp[47] = x6;
  allocp[48] = (q)(struct goalrec*)&allocp[41];
  allocp[49] = (q)(&predicate_functor__table_xarg_3);
  allocp[50] = makeint(2L);
  allocp[51] = a8;
  allocp[52] = x7;
  allocp[53] = (q)(struct goalrec*)&allocp[48];
  allocp[54] = (q)(&predicate_functor__table_xarg_3);
  allocp[55] = makeint(1L);
  allocp[56] = a8;
  allocp[57] = x8;
  qp = (struct goalrec*)&allocp[53];
  allocp += 58;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_52);
  *reasonp++ =  a6;
  goto make_11_72;
  };
  goto make_11_72;
 case symval(makesym(atom_not__less__than)):
 make_11_54:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_55:
  if (a6 != makeint(2L)) goto make_11_72;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = makesym(atom_guard);
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = makesym(functor_goal_4);
  allocp[12] = a0;
  allocp[13] = a2;
  allocp[14] = makesym(atom_guard);
  allocp[15] = a4;
  x3 = makefunctor(&allocp[11]);
  allocp[16] = (q)(struct goalrec*)&allocp[5];
  allocp[17] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[18] = x3;
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = a9;
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_depset_xdd__arg_4);
  allocp[24] = makesym(atom_f);
  allocp[25] = x5 = makeref(&allocp[25]);
  allocp[26] = x1;
  allocp[27] = a7;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_depset_xdd__arg_4);
  allocp[30] = makesym(atom_f);
  allocp[31] = x6 = makeref(&allocp[31]);
  allocp[32] = x4;
  allocp[33] = a7;
  allocp[34] = (q)(struct goalrec*)&allocp[28];
  allocp[35] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[36] = a0;
  allocp[37] = a2;
  allocp[38] = x7 = makeref(&allocp[38]);
  allocp[39] = a7;
  allocp[40] = x5;
  allocp[41] = (q)(struct goalrec*)&allocp[34];
  allocp[42] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[43] = a0;
  allocp[44] = a2;
  allocp[45] = x8 = makeref(&allocp[45]);
  allocp[46] = a7;
  allocp[47] = x6;
  allocp[48] = (q)(struct goalrec*)&allocp[41];
  allocp[49] = (q)(&predicate_functor__table_xarg_3);
  allocp[50] = makeint(2L);
  allocp[51] = a8;
  allocp[52] = x7;
  allocp[53] = (q)(struct goalrec*)&allocp[48];
  allocp[54] = (q)(&predicate_functor__table_xarg_3);
  allocp[55] = makeint(1L);
  allocp[56] = a8;
  allocp[57] = x8;
  qp = (struct goalrec*)&allocp[53];
  allocp += 58;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_54);
  *reasonp++ =  a6;
  goto make_11_72;
  };
  goto make_11_72;
 case symval(makesym(atom_equal)):
 make_11_56:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_57:
  if (a6 != makeint(2L)) goto make_11_72;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = makesym(atom_guard);
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = makesym(functor_goal_4);
  allocp[12] = a0;
  allocp[13] = a2;
  allocp[14] = makesym(atom_guard);
  allocp[15] = a4;
  x3 = makefunctor(&allocp[11]);
  allocp[16] = (q)(struct goalrec*)&allocp[5];
  allocp[17] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[18] = x3;
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = a9;
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_depset_xdd__arg_4);
  allocp[24] = makesym(atom_f);
  allocp[25] = x5 = makeref(&allocp[25]);
  allocp[26] = x1;
  allocp[27] = a7;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_depset_xdd__arg_4);
  allocp[30] = makesym(atom_f);
  allocp[31] = x6 = makeref(&allocp[31]);
  allocp[32] = x4;
  allocp[33] = a7;
  allocp[34] = (q)(struct goalrec*)&allocp[28];
  allocp[35] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[36] = a0;
  allocp[37] = a2;
  allocp[38] = x7 = makeref(&allocp[38]);
  allocp[39] = a7;
  allocp[40] = x5;
  allocp[41] = (q)(struct goalrec*)&allocp[34];
  allocp[42] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[43] = a0;
  allocp[44] = a2;
  allocp[45] = x8 = makeref(&allocp[45]);
  allocp[46] = a7;
  allocp[47] = x6;
  allocp[48] = (q)(struct goalrec*)&allocp[41];
  allocp[49] = (q)(&predicate_functor__table_xarg_3);
  allocp[50] = makeint(2L);
  allocp[51] = a8;
  allocp[52] = x7;
  allocp[53] = (q)(struct goalrec*)&allocp[48];
  allocp[54] = (q)(&predicate_functor__table_xarg_3);
  allocp[55] = makeint(1L);
  allocp[56] = a8;
  allocp[57] = x8;
  qp = (struct goalrec*)&allocp[53];
  allocp += 58;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_56);
  *reasonp++ =  a6;
  goto make_11_72;
  };
  goto make_11_72;
 case symval(makesym(atom_not__equal)):
 make_11_58:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_59:
  if (a6 != makeint(2L)) goto make_11_72;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = makesym(atom_guard);
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = makesym(functor_goal_4);
  allocp[12] = a0;
  allocp[13] = a2;
  allocp[14] = makesym(atom_guard);
  allocp[15] = a4;
  x3 = makefunctor(&allocp[11]);
  allocp[16] = (q)(struct goalrec*)&allocp[5];
  allocp[17] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[18] = x3;
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = a9;
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_depset_xdd__arg_4);
  allocp[24] = makesym(atom_f);
  allocp[25] = x5 = makeref(&allocp[25]);
  allocp[26] = x1;
  allocp[27] = a7;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_depset_xdd__arg_4);
  allocp[30] = makesym(atom_f);
  allocp[31] = x6 = makeref(&allocp[31]);
  allocp[32] = x4;
  allocp[33] = a7;
  allocp[34] = (q)(struct goalrec*)&allocp[28];
  allocp[35] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[36] = a0;
  allocp[37] = a2;
  allocp[38] = x7 = makeref(&allocp[38]);
  allocp[39] = a7;
  allocp[40] = x5;
  allocp[41] = (q)(struct goalrec*)&allocp[34];
  allocp[42] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[43] = a0;
  allocp[44] = a2;
  allocp[45] = x8 = makeref(&allocp[45]);
  allocp[46] = a7;
  allocp[47] = x6;
  allocp[48] = (q)(struct goalrec*)&allocp[41];
  allocp[49] = (q)(&predicate_functor__table_xarg_3);
  allocp[50] = makeint(2L);
  allocp[51] = a8;
  allocp[52] = x7;
  allocp[53] = (q)(struct goalrec*)&allocp[48];
  allocp[54] = (q)(&predicate_functor__table_xarg_3);
  allocp[55] = makeint(1L);
  allocp[56] = a8;
  allocp[57] = x8;
  qp = (struct goalrec*)&allocp[53];
  allocp += 58;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_58);
  *reasonp++ =  a6;
  goto make_11_72;
  };
  goto make_11_72;
 case symval(makesym(atom_not__greater__than)):
 make_11_60:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_61:
  if (a6 != makeint(2L)) goto make_11_72;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = makesym(atom_guard);
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = makesym(functor_goal_4);
  allocp[12] = a0;
  allocp[13] = a2;
  allocp[14] = makesym(atom_guard);
  allocp[15] = a4;
  x3 = makefunctor(&allocp[11]);
  allocp[16] = (q)(struct goalrec*)&allocp[5];
  allocp[17] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[18] = x3;
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = a9;
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_depset_xdd__arg_4);
  allocp[24] = makesym(atom_f);
  allocp[25] = x5 = makeref(&allocp[25]);
  allocp[26] = x1;
  allocp[27] = a7;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_depset_xdd__arg_4);
  allocp[30] = makesym(atom_f);
  allocp[31] = x6 = makeref(&allocp[31]);
  allocp[32] = x4;
  allocp[33] = a7;
  allocp[34] = (q)(struct goalrec*)&allocp[28];
  allocp[35] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[36] = a0;
  allocp[37] = a2;
  allocp[38] = x7 = makeref(&allocp[38]);
  allocp[39] = a7;
  allocp[40] = x5;
  allocp[41] = (q)(struct goalrec*)&allocp[34];
  allocp[42] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[43] = a0;
  allocp[44] = a2;
  allocp[45] = x8 = makeref(&allocp[45]);
  allocp[46] = a7;
  allocp[47] = x6;
  allocp[48] = (q)(struct goalrec*)&allocp[41];
  allocp[49] = (q)(&predicate_functor__table_xarg_3);
  allocp[50] = makeint(2L);
  allocp[51] = a8;
  allocp[52] = x7;
  allocp[53] = (q)(struct goalrec*)&allocp[48];
  allocp[54] = (q)(&predicate_functor__table_xarg_3);
  allocp[55] = makeint(1L);
  allocp[56] = a8;
  allocp[57] = x8;
  qp = (struct goalrec*)&allocp[53];
  allocp += 58;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_60);
  *reasonp++ =  a6;
  goto make_11_72;
  };
  goto make_11_72;
 case symval(makesym(atom_less__than)):
 make_11_62:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_63:
  if (a6 != makeint(2L)) goto make_11_72;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = makesym(atom_guard);
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = makesym(functor_goal_4);
  allocp[12] = a0;
  allocp[13] = a2;
  allocp[14] = makesym(atom_guard);
  allocp[15] = a4;
  x3 = makefunctor(&allocp[11]);
  allocp[16] = (q)(struct goalrec*)&allocp[5];
  allocp[17] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[18] = x3;
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = a9;
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_depset_xdd__arg_4);
  allocp[24] = makesym(atom_f);
  allocp[25] = x5 = makeref(&allocp[25]);
  allocp[26] = x1;
  allocp[27] = a7;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_depset_xdd__arg_4);
  allocp[30] = makesym(atom_f);
  allocp[31] = x6 = makeref(&allocp[31]);
  allocp[32] = x4;
  allocp[33] = a7;
  allocp[34] = (q)(struct goalrec*)&allocp[28];
  allocp[35] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[36] = a0;
  allocp[37] = a2;
  allocp[38] = x7 = makeref(&allocp[38]);
  allocp[39] = a7;
  allocp[40] = x5;
  allocp[41] = (q)(struct goalrec*)&allocp[34];
  allocp[42] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[43] = a0;
  allocp[44] = a2;
  allocp[45] = x8 = makeref(&allocp[45]);
  allocp[46] = a7;
  allocp[47] = x6;
  allocp[48] = (q)(struct goalrec*)&allocp[41];
  allocp[49] = (q)(&predicate_functor__table_xarg_3);
  allocp[50] = makeint(2L);
  allocp[51] = a8;
  allocp[52] = x7;
  allocp[53] = (q)(struct goalrec*)&allocp[48];
  allocp[54] = (q)(&predicate_functor__table_xarg_3);
  allocp[55] = makeint(1L);
  allocp[56] = a8;
  allocp[57] = x8;
  qp = (struct goalrec*)&allocp[53];
  allocp += 58;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_62);
  *reasonp++ =  a6;
  goto make_11_72;
  };
  goto make_11_72;
 case symval(makesym(atom_vector)):
 make_11_64:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_65:
  if (a6 != makeint(2L)) goto make_11_72;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = makesym(atom_guard);
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = (q)(struct goalrec*)&allocp[5];
  allocp[12] = (q)(&predicate_depset_xdd__arg_4);
  allocp[13] = makesym(atom_v);
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = a7;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[19] = a0;
  allocp[20] = a2;
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = a7;
  allocp[23] = x2;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_functor__table_xarg_3);
  allocp[26] = makeint(1L);
  allocp[27] = a8;
  allocp[28] = x3;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_64);
  *reasonp++ =  a6;
  goto make_11_72;
  };
  goto make_11_72;
  };
  goto make_11_72;
 case VARREF:
  deref_and_jump(a5,make_11_51);
  *reasonp++ =  a5;
  goto make_11_72;
  };
  goto make_11_72;
 case symval(makesym(atom_body)):
 make_11_66:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (a5 != makesym(atom_size)) goto make_11_72;
 make_11_67:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_68:
  if (a6 != makeint(2L)) goto make_11_72;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = makesym(atom_guard);
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = (q)(struct goalrec*)&allocp[5];
  allocp[12] = (q)(&predicate_depset_xdd__arg_4);
  allocp[13] = makesym(atom_v);
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = a7;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[19] = a0;
  allocp[20] = a2;
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = a7;
  allocp[23] = x2;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_functor__table_xarg_3);
  allocp[26] = makeint(1L);
  allocp[27] = a8;
  allocp[28] = x3;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_67);
  *reasonp++ =  a6;
  goto make_11_72;
  };
  goto make_11_72;
 case VARREF:
  deref_and_jump(a5,make_11_66);
  *reasonp++ =  a5;
  goto make_11_72;
  };
  goto make_11_72;
  };
  goto make_11_72;
 case VARREF:
  deref_and_jump(a3,make_11_50);
  *reasonp++ =  a3;
  goto make_11_72;
  };
  goto make_11_72;
 case symval(makesym(atom_io)):
 make_11_69:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (a5 != makesym(atom_outstream)) goto make_11_72;
 make_11_70:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_71:
  if (a6 != makeint(1L)) goto make_11_72;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = (q)(struct goalrec*)&allocp[5];
  allocp[12] = (q)(&predicate_depset_xdd__arg_7);
  allocp[13] = makesym(atom_all);
  allocp[14] = makesym(atom_n);
  allocp[15] = x2 = makeref(&allocp[15]);
  allocp[16] = x1;
  allocp[17] = a7;
  allocp[18] = NILATOM;
  allocp[19] = x3 = makeref(&allocp[19]);
  allocp[20] = (q)(struct goalrec*)&allocp[11];
  allocp[21] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[22] = a0;
  allocp[23] = a2;
  allocp[24] = x4 = makeref(&allocp[24]);
  allocp[25] = a7;
  allocp[26] = x2;
  allocp[27] = (q)(struct goalrec*)&allocp[20];
  allocp[28] = (q)(&predicate_functor__table_xarg_3);
  allocp[29] = makeint(1L);
  allocp[30] = a8;
  allocp[31] = x4;
  qp = (struct goalrec*)&allocp[27];
  allocp += 32;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_70);
  *reasonp++ =  a6;
  goto make_11_72;
  };
  goto make_11_72;
 case VARREF:
  deref_and_jump(a5,make_11_69);
  *reasonp++ =  a5;
  goto make_11_72;
  };
  goto make_11_72;
  };
  goto make_11_72;
 case VARREF:
  deref_and_jump(a1,make_11_1);
  *reasonp++ =  a1;
  goto make_11_72;
  };
  goto make_11_72;
 make_11_72:
  otherwise(make_11_interrupt);
 make_11_73:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (isint(a5)) goto make_11_120;
  switch (symval(a5)) {
 case symval(makesym(atom__3D)):
 make_11_74:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_75:
  if (a6 != makeint(2L)) goto make_11_120;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin__deps_xunify__deps_9);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a0;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a7;
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_functor__table_xarg_3);
  allocp[13] = makeint(2L);
  allocp[14] = a8;
  allocp[15] = x1;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_functor__table_xarg_3);
  allocp[18] = makeint(1L);
  allocp[19] = a8;
  allocp[20] = x0;
  qp = (struct goalrec*)&allocp[16];
  allocp += 21;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_74);
  *reasonp++ =  a6;
  goto make_11_120;
  };
  goto make_11_120;
 case symval(makesym(atom__3D_3D)):
 make_11_76:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_77:
  if (a6 != makeint(2L)) goto make_11_120;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin__deps_xunify__deps_9);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a0;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a7;
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_functor__table_xarg_3);
  allocp[13] = makeint(2L);
  allocp[14] = a8;
  allocp[15] = x1;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_functor__table_xarg_3);
  allocp[18] = makeint(1L);
  allocp[19] = a8;
  allocp[20] = x0;
  qp = (struct goalrec*)&allocp[16];
  allocp += 21;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_76);
  *reasonp++ =  a6;
  goto make_11_120;
  };
  goto make_11_120;
 case symval(makesym(atom_make__atom)):
 make_11_78:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_79:
  if (a6 != makeint(2L)) goto make_11_120;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = (q)(struct goalrec*)&allocp[5];
  allocp[12] = (q)(&predicate_depset_xdd__arg_4);
  allocp[13] = makesym(atom_c);
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = a7;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[19] = a0;
  allocp[20] = a2;
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = a7;
  allocp[23] = x2;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_functor__table_xarg_3);
  allocp[26] = makeint(1L);
  allocp[27] = a8;
  allocp[28] = x3;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_78);
  *reasonp++ =  a6;
  goto make_11_120;
  };
  goto make_11_120;
 case symval(makesym(atom_atom__number)):
 make_11_80:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_81:
  if (a6 != makeint(2L)) goto make_11_120;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = (q)(struct goalrec*)&allocp[5];
  allocp[12] = (q)(&predicate_depset_xdd__arg_4);
  allocp[13] = makesym(atom_a);
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = a7;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[19] = a0;
  allocp[20] = a2;
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = a7;
  allocp[23] = x2;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_functor__table_xarg_3);
  allocp[26] = makeint(1L);
  allocp[27] = a8;
  allocp[28] = x3;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_80);
  *reasonp++ =  a6;
  goto make_11_120;
  };
  goto make_11_120;
 case symval(makesym(atom_get__atom__string)):
 make_11_82:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_83:
  if (a6 != makeint(2L)) goto make_11_120;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = (q)(struct goalrec*)&allocp[5];
  allocp[12] = (q)(&predicate_depset_xdd__arg_4);
  allocp[13] = makesym(atom_a);
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = a7;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[19] = a0;
  allocp[20] = a2;
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = a7;
  allocp[23] = x2;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_functor__table_xarg_3);
  allocp[26] = makeint(1L);
  allocp[27] = a8;
  allocp[28] = x3;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_82);
  *reasonp++ =  a6;
  goto make_11_120;
  };
  goto make_11_120;
 case symval(makesym(atom_intern)):
 make_11_84:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_85:
  if (a6 != makeint(2L)) goto make_11_120;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = (q)(struct goalrec*)&allocp[5];
  allocp[12] = (q)(&predicate_depset_xdd__arg_4);
  allocp[13] = makesym(atom_c);
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = a7;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[19] = a0;
  allocp[20] = a2;
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = a7;
  allocp[23] = x2;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_functor__table_xarg_3);
  allocp[26] = makeint(1L);
  allocp[27] = a8;
  allocp[28] = x3;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_84);
  *reasonp++ =  a6;
  goto make_11_120;
  };
  goto make_11_120;
 case symval(makesym(atom_get__atom__name)):
 make_11_86:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_87:
  if (a6 != makeint(2L)) goto make_11_120;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = (q)(struct goalrec*)&allocp[5];
  allocp[12] = (q)(&predicate_depset_xdd__arg_4);
  allocp[13] = makesym(atom_a);
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = a7;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[19] = a0;
  allocp[20] = a2;
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = a7;
  allocp[23] = x2;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_functor__table_xarg_3);
  allocp[26] = makeint(1L);
  allocp[27] = a8;
  allocp[28] = x3;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_86);
  *reasonp++ =  a6;
  goto make_11_120;
  };
  goto make_11_120;
 case symval(makesym(atom_add)):
 make_11_88:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_89:
  if (a6 != makeint(3L)) goto make_11_120;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = makesym(functor_goal_4);
  allocp[12] = a0;
  allocp[13] = a2;
  allocp[14] = a3;
  allocp[15] = a4;
  x3 = makefunctor(&allocp[11]);
  allocp[16] = (q)(struct goalrec*)&allocp[5];
  allocp[17] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[18] = x3;
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = a9;
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_depset_xdd__arg_4);
  allocp[24] = makesym(atom_i);
  allocp[25] = x5 = makeref(&allocp[25]);
  allocp[26] = x1;
  allocp[27] = a7;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_depset_xdd__arg_4);
  allocp[30] = makesym(atom_i);
  allocp[31] = x6 = makeref(&allocp[31]);
  allocp[32] = x4;
  allocp[33] = a7;
  allocp[34] = (q)(struct goalrec*)&allocp[28];
  allocp[35] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[36] = a0;
  allocp[37] = a2;
  allocp[38] = x7 = makeref(&allocp[38]);
  allocp[39] = a7;
  allocp[40] = x5;
  allocp[41] = (q)(struct goalrec*)&allocp[34];
  allocp[42] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[43] = a0;
  allocp[44] = a2;
  allocp[45] = x8 = makeref(&allocp[45]);
  allocp[46] = a7;
  allocp[47] = x6;
  allocp[48] = (q)(struct goalrec*)&allocp[41];
  allocp[49] = (q)(&predicate_functor__table_xarg_3);
  allocp[50] = makeint(2L);
  allocp[51] = a8;
  allocp[52] = x7;
  allocp[53] = (q)(struct goalrec*)&allocp[48];
  allocp[54] = (q)(&predicate_functor__table_xarg_3);
  allocp[55] = makeint(1L);
  allocp[56] = a8;
  allocp[57] = x8;
  qp = (struct goalrec*)&allocp[53];
  allocp += 58;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_88);
  *reasonp++ =  a6;
  goto make_11_120;
  };
  goto make_11_120;
 case symval(makesym(atom_plus)):
 make_11_90:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_91:
  if (a6 != makeint(2L)) goto make_11_120;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = (q)(struct goalrec*)&allocp[5];
  allocp[12] = (q)(&predicate_depset_xdd__arg_4);
  allocp[13] = makesym(atom_i);
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = a7;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[19] = a0;
  allocp[20] = a2;
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = a7;
  allocp[23] = x2;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_functor__table_xarg_3);
  allocp[26] = makeint(1L);
  allocp[27] = a8;
  allocp[28] = x3;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_90);
  *reasonp++ =  a6;
  goto make_11_120;
  };
  goto make_11_120;
 case symval(makesym(atom_subtract)):
 make_11_92:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_93:
  if (a6 != makeint(3L)) goto make_11_120;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = makesym(functor_goal_4);
  allocp[12] = a0;
  allocp[13] = a2;
  allocp[14] = a3;
  allocp[15] = a4;
  x3 = makefunctor(&allocp[11]);
  allocp[16] = (q)(struct goalrec*)&allocp[5];
  allocp[17] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[18] = x3;
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = a9;
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_depset_xdd__arg_4);
  allocp[24] = makesym(atom_i);
  allocp[25] = x5 = makeref(&allocp[25]);
  allocp[26] = x1;
  allocp[27] = a7;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_depset_xdd__arg_4);
  allocp[30] = makesym(atom_i);
  allocp[31] = x6 = makeref(&allocp[31]);
  allocp[32] = x4;
  allocp[33] = a7;
  allocp[34] = (q)(struct goalrec*)&allocp[28];
  allocp[35] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[36] = a0;
  allocp[37] = a2;
  allocp[38] = x7 = makeref(&allocp[38]);
  allocp[39] = a7;
  allocp[40] = x5;
  allocp[41] = (q)(struct goalrec*)&allocp[34];
  allocp[42] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[43] = a0;
  allocp[44] = a2;
  allocp[45] = x8 = makeref(&allocp[45]);
  allocp[46] = a7;
  allocp[47] = x6;
  allocp[48] = (q)(struct goalrec*)&allocp[41];
  allocp[49] = (q)(&predicate_functor__table_xarg_3);
  allocp[50] = makeint(2L);
  allocp[51] = a8;
  allocp[52] = x7;
  allocp[53] = (q)(struct goalrec*)&allocp[48];
  allocp[54] = (q)(&predicate_functor__table_xarg_3);
  allocp[55] = makeint(1L);
  allocp[56] = a8;
  allocp[57] = x8;
  qp = (struct goalrec*)&allocp[53];
  allocp += 58;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_92);
  *reasonp++ =  a6;
  goto make_11_120;
  };
  goto make_11_120;
 case symval(makesym(atom_minus)):
 make_11_94:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_95:
  if (a6 != makeint(2L)) goto make_11_120;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = (q)(struct goalrec*)&allocp[5];
  allocp[12] = (q)(&predicate_depset_xdd__arg_4);
  allocp[13] = makesym(atom_i);
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = a7;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[19] = a0;
  allocp[20] = a2;
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = a7;
  allocp[23] = x2;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_functor__table_xarg_3);
  allocp[26] = makeint(1L);
  allocp[27] = a8;
  allocp[28] = x3;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_94);
  *reasonp++ =  a6;
  goto make_11_120;
  };
  goto make_11_120;
 case symval(makesym(atom_multiply)):
 make_11_96:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_97:
  if (a6 != makeint(3L)) goto make_11_120;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = makesym(functor_goal_4);
  allocp[12] = a0;
  allocp[13] = a2;
  allocp[14] = a3;
  allocp[15] = a4;
  x3 = makefunctor(&allocp[11]);
  allocp[16] = (q)(struct goalrec*)&allocp[5];
  allocp[17] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[18] = x3;
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = a9;
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_depset_xdd__arg_4);
  allocp[24] = makesym(atom_i);
  allocp[25] = x5 = makeref(&allocp[25]);
  allocp[26] = x1;
  allocp[27] = a7;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_depset_xdd__arg_4);
  allocp[30] = makesym(atom_i);
  allocp[31] = x6 = makeref(&allocp[31]);
  allocp[32] = x4;
  allocp[33] = a7;
  allocp[34] = (q)(struct goalrec*)&allocp[28];
  allocp[35] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[36] = a0;
  allocp[37] = a2;
  allocp[38] = x7 = makeref(&allocp[38]);
  allocp[39] = a7;
  allocp[40] = x5;
  allocp[41] = (q)(struct goalrec*)&allocp[34];
  allocp[42] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[43] = a0;
  allocp[44] = a2;
  allocp[45] = x8 = makeref(&allocp[45]);
  allocp[46] = a7;
  allocp[47] = x6;
  allocp[48] = (q)(struct goalrec*)&allocp[41];
  allocp[49] = (q)(&predicate_functor__table_xarg_3);
  allocp[50] = makeint(2L);
  allocp[51] = a8;
  allocp[52] = x7;
  allocp[53] = (q)(struct goalrec*)&allocp[48];
  allocp[54] = (q)(&predicate_functor__table_xarg_3);
  allocp[55] = makeint(1L);
  allocp[56] = a8;
  allocp[57] = x8;
  qp = (struct goalrec*)&allocp[53];
  allocp += 58;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_96);
  *reasonp++ =  a6;
  goto make_11_120;
  };
  goto make_11_120;
 case symval(makesym(atom_divide)):
 make_11_98:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_99:
  if (a6 != makeint(3L)) goto make_11_120;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = makesym(functor_goal_4);
  allocp[12] = a0;
  allocp[13] = a2;
  allocp[14] = a3;
  allocp[15] = a4;
  x3 = makefunctor(&allocp[11]);
  allocp[16] = (q)(struct goalrec*)&allocp[5];
  allocp[17] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[18] = x3;
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = a9;
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_depset_xdd__arg_4);
  allocp[24] = makesym(atom_i);
  allocp[25] = x5 = makeref(&allocp[25]);
  allocp[26] = x1;
  allocp[27] = a7;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_depset_xdd__arg_4);
  allocp[30] = makesym(atom_i);
  allocp[31] = x6 = makeref(&allocp[31]);
  allocp[32] = x4;
  allocp[33] = a7;
  allocp[34] = (q)(struct goalrec*)&allocp[28];
  allocp[35] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[36] = a0;
  allocp[37] = a2;
  allocp[38] = x7 = makeref(&allocp[38]);
  allocp[39] = a7;
  allocp[40] = x5;
  allocp[41] = (q)(struct goalrec*)&allocp[34];
  allocp[42] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[43] = a0;
  allocp[44] = a2;
  allocp[45] = x8 = makeref(&allocp[45]);
  allocp[46] = a7;
  allocp[47] = x6;
  allocp[48] = (q)(struct goalrec*)&allocp[41];
  allocp[49] = (q)(&predicate_functor__table_xarg_3);
  allocp[50] = makeint(2L);
  allocp[51] = a8;
  allocp[52] = x7;
  allocp[53] = (q)(struct goalrec*)&allocp[48];
  allocp[54] = (q)(&predicate_functor__table_xarg_3);
  allocp[55] = makeint(1L);
  allocp[56] = a8;
  allocp[57] = x8;
  qp = (struct goalrec*)&allocp[53];
  allocp += 58;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_98);
  *reasonp++ =  a6;
  goto make_11_120;
  };
  goto make_11_120;
 case symval(makesym(atom_modulo)):
 make_11_100:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_101:
  if (a6 != makeint(3L)) goto make_11_120;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = makesym(functor_goal_4);
  allocp[12] = a0;
  allocp[13] = a2;
  allocp[14] = a3;
  allocp[15] = a4;
  x3 = makefunctor(&allocp[11]);
  allocp[16] = (q)(struct goalrec*)&allocp[5];
  allocp[17] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[18] = x3;
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = a9;
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_depset_xdd__arg_4);
  allocp[24] = makesym(atom_i);
  allocp[25] = x5 = makeref(&allocp[25]);
  allocp[26] = x1;
  allocp[27] = a7;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_depset_xdd__arg_4);
  allocp[30] = makesym(atom_i);
  allocp[31] = x6 = makeref(&allocp[31]);
  allocp[32] = x4;
  allocp[33] = a7;
  allocp[34] = (q)(struct goalrec*)&allocp[28];
  allocp[35] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[36] = a0;
  allocp[37] = a2;
  allocp[38] = x7 = makeref(&allocp[38]);
  allocp[39] = a7;
  allocp[40] = x5;
  allocp[41] = (q)(struct goalrec*)&allocp[34];
  allocp[42] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[43] = a0;
  allocp[44] = a2;
  allocp[45] = x8 = makeref(&allocp[45]);
  allocp[46] = a7;
  allocp[47] = x6;
  allocp[48] = (q)(struct goalrec*)&allocp[41];
  allocp[49] = (q)(&predicate_functor__table_xarg_3);
  allocp[50] = makeint(2L);
  allocp[51] = a8;
  allocp[52] = x7;
  allocp[53] = (q)(struct goalrec*)&allocp[48];
  allocp[54] = (q)(&predicate_functor__table_xarg_3);
  allocp[55] = makeint(1L);
  allocp[56] = a8;
  allocp[57] = x8;
  qp = (struct goalrec*)&allocp[53];
  allocp += 58;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_100);
  *reasonp++ =  a6;
  goto make_11_120;
  };
  goto make_11_120;
 case symval(makesym(atom_complement)):
 make_11_102:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_103:
  if (a6 != makeint(2L)) goto make_11_120;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = (q)(struct goalrec*)&allocp[5];
  allocp[12] = (q)(&predicate_depset_xdd__arg_4);
  allocp[13] = makesym(atom_i);
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = a7;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[19] = a0;
  allocp[20] = a2;
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = a7;
  allocp[23] = x2;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_functor__table_xarg_3);
  allocp[26] = makeint(1L);
  allocp[27] = a8;
  allocp[28] = x3;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_102);
  *reasonp++ =  a6;
  goto make_11_120;
  };
  goto make_11_120;
 case symval(makesym(atom_and)):
 make_11_104:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_105:
  if (a6 != makeint(3L)) goto make_11_120;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = makesym(functor_goal_4);
  allocp[12] = a0;
  allocp[13] = a2;
  allocp[14] = a3;
  allocp[15] = a4;
  x3 = makefunctor(&allocp[11]);
  allocp[16] = (q)(struct goalrec*)&allocp[5];
  allocp[17] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[18] = x3;
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = a9;
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_depset_xdd__arg_4);
  allocp[24] = makesym(atom_i);
  allocp[25] = x5 = makeref(&allocp[25]);
  allocp[26] = x1;
  allocp[27] = a7;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_depset_xdd__arg_4);
  allocp[30] = makesym(atom_i);
  allocp[31] = x6 = makeref(&allocp[31]);
  allocp[32] = x4;
  allocp[33] = a7;
  allocp[34] = (q)(struct goalrec*)&allocp[28];
  allocp[35] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[36] = a0;
  allocp[37] = a2;
  allocp[38] = x7 = makeref(&allocp[38]);
  allocp[39] = a7;
  allocp[40] = x5;
  allocp[41] = (q)(struct goalrec*)&allocp[34];
  allocp[42] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[43] = a0;
  allocp[44] = a2;
  allocp[45] = x8 = makeref(&allocp[45]);
  allocp[46] = a7;
  allocp[47] = x6;
  allocp[48] = (q)(struct goalrec*)&allocp[41];
  allocp[49] = (q)(&predicate_functor__table_xarg_3);
  allocp[50] = makeint(2L);
  allocp[51] = a8;
  allocp[52] = x7;
  allocp[53] = (q)(struct goalrec*)&allocp[48];
  allocp[54] = (q)(&predicate_functor__table_xarg_3);
  allocp[55] = makeint(1L);
  allocp[56] = a8;
  allocp[57] = x8;
  qp = (struct goalrec*)&allocp[53];
  allocp += 58;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_104);
  *reasonp++ =  a6;
  goto make_11_120;
  };
  goto make_11_120;
 case symval(makesym(atom_or)):
 make_11_106:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_107:
  if (a6 != makeint(3L)) goto make_11_120;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = makesym(functor_goal_4);
  allocp[12] = a0;
  allocp[13] = a2;
  allocp[14] = a3;
  allocp[15] = a4;
  x3 = makefunctor(&allocp[11]);
  allocp[16] = (q)(struct goalrec*)&allocp[5];
  allocp[17] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[18] = x3;
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = a9;
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_depset_xdd__arg_4);
  allocp[24] = makesym(atom_i);
  allocp[25] = x5 = makeref(&allocp[25]);
  allocp[26] = x1;
  allocp[27] = a7;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_depset_xdd__arg_4);
  allocp[30] = makesym(atom_i);
  allocp[31] = x6 = makeref(&allocp[31]);
  allocp[32] = x4;
  allocp[33] = a7;
  allocp[34] = (q)(struct goalrec*)&allocp[28];
  allocp[35] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[36] = a0;
  allocp[37] = a2;
  allocp[38] = x7 = makeref(&allocp[38]);
  allocp[39] = a7;
  allocp[40] = x5;
  allocp[41] = (q)(struct goalrec*)&allocp[34];
  allocp[42] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[43] = a0;
  allocp[44] = a2;
  allocp[45] = x8 = makeref(&allocp[45]);
  allocp[46] = a7;
  allocp[47] = x6;
  allocp[48] = (q)(struct goalrec*)&allocp[41];
  allocp[49] = (q)(&predicate_functor__table_xarg_3);
  allocp[50] = makeint(2L);
  allocp[51] = a8;
  allocp[52] = x7;
  allocp[53] = (q)(struct goalrec*)&allocp[48];
  allocp[54] = (q)(&predicate_functor__table_xarg_3);
  allocp[55] = makeint(1L);
  allocp[56] = a8;
  allocp[57] = x8;
  qp = (struct goalrec*)&allocp[53];
  allocp += 58;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_106);
  *reasonp++ =  a6;
  goto make_11_120;
  };
  goto make_11_120;
 case symval(makesym(atom_exclusive__or)):
 make_11_108:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_109:
  if (a6 != makeint(3L)) goto make_11_120;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = makesym(functor_goal_4);
  allocp[12] = a0;
  allocp[13] = a2;
  allocp[14] = a3;
  allocp[15] = a4;
  x3 = makefunctor(&allocp[11]);
  allocp[16] = (q)(struct goalrec*)&allocp[5];
  allocp[17] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[18] = x3;
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = a9;
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_depset_xdd__arg_4);
  allocp[24] = makesym(atom_i);
  allocp[25] = x5 = makeref(&allocp[25]);
  allocp[26] = x1;
  allocp[27] = a7;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_depset_xdd__arg_4);
  allocp[30] = makesym(atom_i);
  allocp[31] = x6 = makeref(&allocp[31]);
  allocp[32] = x4;
  allocp[33] = a7;
  allocp[34] = (q)(struct goalrec*)&allocp[28];
  allocp[35] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[36] = a0;
  allocp[37] = a2;
  allocp[38] = x7 = makeref(&allocp[38]);
  allocp[39] = a7;
  allocp[40] = x5;
  allocp[41] = (q)(struct goalrec*)&allocp[34];
  allocp[42] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[43] = a0;
  allocp[44] = a2;
  allocp[45] = x8 = makeref(&allocp[45]);
  allocp[46] = a7;
  allocp[47] = x6;
  allocp[48] = (q)(struct goalrec*)&allocp[41];
  allocp[49] = (q)(&predicate_functor__table_xarg_3);
  allocp[50] = makeint(2L);
  allocp[51] = a8;
  allocp[52] = x7;
  allocp[53] = (q)(struct goalrec*)&allocp[48];
  allocp[54] = (q)(&predicate_functor__table_xarg_3);
  allocp[55] = makeint(1L);
  allocp[56] = a8;
  allocp[57] = x8;
  qp = (struct goalrec*)&allocp[53];
  allocp += 58;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_108);
  *reasonp++ =  a6;
  goto make_11_120;
  };
  goto make_11_120;
 case symval(makesym(atom_shift__left)):
 make_11_110:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_111:
  if (a6 != makeint(3L)) goto make_11_120;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = makesym(functor_goal_4);
  allocp[12] = a0;
  allocp[13] = a2;
  allocp[14] = a3;
  allocp[15] = a4;
  x3 = makefunctor(&allocp[11]);
  allocp[16] = (q)(struct goalrec*)&allocp[5];
  allocp[17] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[18] = x3;
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = a9;
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_depset_xdd__arg_4);
  allocp[24] = makesym(atom_i);
  allocp[25] = x5 = makeref(&allocp[25]);
  allocp[26] = x1;
  allocp[27] = a7;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_depset_xdd__arg_4);
  allocp[30] = makesym(atom_i);
  allocp[31] = x6 = makeref(&allocp[31]);
  allocp[32] = x4;
  allocp[33] = a7;
  allocp[34] = (q)(struct goalrec*)&allocp[28];
  allocp[35] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[36] = a0;
  allocp[37] = a2;
  allocp[38] = x7 = makeref(&allocp[38]);
  allocp[39] = a7;
  allocp[40] = x5;
  allocp[41] = (q)(struct goalrec*)&allocp[34];
  allocp[42] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[43] = a0;
  allocp[44] = a2;
  allocp[45] = x8 = makeref(&allocp[45]);
  allocp[46] = a7;
  allocp[47] = x6;
  allocp[48] = (q)(struct goalrec*)&allocp[41];
  allocp[49] = (q)(&predicate_functor__table_xarg_3);
  allocp[50] = makeint(2L);
  allocp[51] = a8;
  allocp[52] = x7;
  allocp[53] = (q)(struct goalrec*)&allocp[48];
  allocp[54] = (q)(&predicate_functor__table_xarg_3);
  allocp[55] = makeint(1L);
  allocp[56] = a8;
  allocp[57] = x8;
  qp = (struct goalrec*)&allocp[53];
  allocp += 58;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_110);
  *reasonp++ =  a6;
  goto make_11_120;
  };
  goto make_11_120;
 case symval(makesym(atom_shift__right)):
 make_11_112:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_113:
  if (a6 != makeint(3L)) goto make_11_120;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = makesym(functor_goal_4);
  allocp[12] = a0;
  allocp[13] = a2;
  allocp[14] = a3;
  allocp[15] = a4;
  x3 = makefunctor(&allocp[11]);
  allocp[16] = (q)(struct goalrec*)&allocp[5];
  allocp[17] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[18] = x3;
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = a9;
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_depset_xdd__arg_4);
  allocp[24] = makesym(atom_i);
  allocp[25] = x5 = makeref(&allocp[25]);
  allocp[26] = x1;
  allocp[27] = a7;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_depset_xdd__arg_4);
  allocp[30] = makesym(atom_i);
  allocp[31] = x6 = makeref(&allocp[31]);
  allocp[32] = x4;
  allocp[33] = a7;
  allocp[34] = (q)(struct goalrec*)&allocp[28];
  allocp[35] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[36] = a0;
  allocp[37] = a2;
  allocp[38] = x7 = makeref(&allocp[38]);
  allocp[39] = a7;
  allocp[40] = x5;
  allocp[41] = (q)(struct goalrec*)&allocp[34];
  allocp[42] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[43] = a0;
  allocp[44] = a2;
  allocp[45] = x8 = makeref(&allocp[45]);
  allocp[46] = a7;
  allocp[47] = x6;
  allocp[48] = (q)(struct goalrec*)&allocp[41];
  allocp[49] = (q)(&predicate_functor__table_xarg_3);
  allocp[50] = makeint(2L);
  allocp[51] = a8;
  allocp[52] = x7;
  allocp[53] = (q)(struct goalrec*)&allocp[48];
  allocp[54] = (q)(&predicate_functor__table_xarg_3);
  allocp[55] = makeint(1L);
  allocp[56] = a8;
  allocp[57] = x8;
  qp = (struct goalrec*)&allocp[53];
  allocp += 58;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_112);
  *reasonp++ =  a6;
  goto make_11_120;
  };
  goto make_11_120;
 case symval(makesym(atom_floating__point__to__integer)):
 make_11_114:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_115:
  if (a6 != makeint(2L)) goto make_11_120;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = (q)(struct goalrec*)&allocp[5];
  allocp[12] = (q)(&predicate_depset_xdd__arg_4);
  allocp[13] = makesym(atom_f);
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = a7;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[19] = a0;
  allocp[20] = a2;
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = a7;
  allocp[23] = x2;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_functor__table_xarg_3);
  allocp[26] = makeint(1L);
  allocp[27] = a8;
  allocp[28] = x3;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_114);
  *reasonp++ =  a6;
  goto make_11_120;
  };
  goto make_11_120;
 case symval(makesym(atom_functor)):
 make_11_116:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_117:
  if (a6 != makeint(3L)) goto make_11_120;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = (q)(struct goalrec*)&allocp[5];
  allocp[12] = (q)(&predicate_depset_xdd__arg_4);
  allocp[13] = makesym(atom_s);
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = a7;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[19] = a0;
  allocp[20] = a2;
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = a7;
  allocp[23] = x2;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_functor__table_xarg_3);
  allocp[26] = makeint(1L);
  allocp[27] = a8;
  allocp[28] = x3;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_116);
  *reasonp++ =  a6;
  goto make_11_120;
  };
  goto make_11_120;
 case symval(makesym(atom_arg)):
 make_11_118:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_119:
  if (a6 != makeint(3L)) goto make_11_120;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = makesym(functor_goal_4);
  allocp[12] = a0;
  allocp[13] = a2;
  allocp[14] = a3;
  allocp[15] = a4;
  x3 = makefunctor(&allocp[11]);
  allocp[16] = (q)(struct goalrec*)&allocp[5];
  allocp[17] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[18] = x3;
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = a9;
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_depset_xdd__arg_7);
  allocp[24] = makesym(atom_s);
  allocp[25] = makesym(atom_n);
  allocp[26] = x5 = makeref(&allocp[26]);
  allocp[27] = x1;
  allocp[28] = a7;
  allocp[29] = NILATOM;
  allocp[30] = x6 = makeref(&allocp[30]);
  allocp[31] = (q)(struct goalrec*)&allocp[22];
  allocp[32] = (q)(&predicate_depset_xdd__arg_4);
  allocp[33] = makesym(atom_i);
  allocp[34] = x7 = makeref(&allocp[34]);
  allocp[35] = x4;
  allocp[36] = a7;
  allocp[37] = (q)(struct goalrec*)&allocp[31];
  allocp[38] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[39] = a0;
  allocp[40] = a2;
  allocp[41] = x8 = makeref(&allocp[41]);
  allocp[42] = a7;
  allocp[43] = x5;
  allocp[44] = (q)(struct goalrec*)&allocp[37];
  allocp[45] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[46] = a0;
  allocp[47] = a2;
  allocp[48] = x9 = makeref(&allocp[48]);
  allocp[49] = a7;
  allocp[50] = x7;
  allocp[51] = (q)(struct goalrec*)&allocp[44];
  allocp[52] = (q)(&predicate_functor__table_xarg_3);
  allocp[53] = makeint(2L);
  allocp[54] = a8;
  allocp[55] = x8;
  allocp[56] = (q)(struct goalrec*)&allocp[51];
  allocp[57] = (q)(&predicate_functor__table_xarg_3);
  allocp[58] = makeint(1L);
  allocp[59] = a8;
  allocp[60] = x9;
  qp = (struct goalrec*)&allocp[56];
  allocp += 61;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_118);
  *reasonp++ =  a6;
  goto make_11_120;
  };
  goto make_11_120;
  };
  goto make_11_120;
 case VARREF:
  deref_and_jump(a5,make_11_73);
  *reasonp++ =  a5;
  goto make_11_120;
  };
  goto make_11_120;
 make_11_120:
 make_11_121:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (isint(a3)) goto make_11_162;
  switch (symval(a3)) {
 case symval(makesym(atom_guard)):
 make_11_122:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (isint(a5)) goto make_11_162;
  switch (symval(a5)) {
 case symval(makesym(atom_wait)):
 make_11_123:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_124:
  if (a6 != makeint(1L)) goto make_11_162;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = makesym(atom_guard);
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = (q)(struct goalrec*)&allocp[5];
  allocp[12] = (q)(&predicate_depset_xdd__arg_4);
  allocp[13] = makesym(atom_all);
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = a7;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[19] = a0;
  allocp[20] = a2;
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = a7;
  allocp[23] = x2;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_functor__table_xarg_3);
  allocp[26] = makeint(1L);
  allocp[27] = a8;
  allocp[28] = x3;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_123);
  *reasonp++ =  a6;
  goto make_11_162;
  };
  goto make_11_162;
 case symval(makesym(atom_compare)):
 make_11_125:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_126:
  if (a6 != makeint(3L)) goto make_11_162;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = makesym(atom_guard);
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = makesym(functor_goal_4);
  allocp[12] = a0;
  allocp[13] = a2;
  allocp[14] = makesym(atom_guard);
  allocp[15] = a4;
  x3 = makefunctor(&allocp[11]);
  allocp[16] = (q)(struct goalrec*)&allocp[5];
  allocp[17] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[18] = x3;
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = a9;
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_depset_xdd__arg_7);
  allocp[24] = makesym(atom_all);
  allocp[25] = makesym(atom_n);
  allocp[26] = x5 = makeref(&allocp[26]);
  allocp[27] = x1;
  allocp[28] = a7;
  allocp[29] = NILATOM;
  allocp[30] = x6 = makeref(&allocp[30]);
  allocp[31] = (q)(struct goalrec*)&allocp[22];
  allocp[32] = (q)(&predicate_depset_xdd__arg_7);
  allocp[33] = makesym(atom_all);
  allocp[34] = makesym(atom_n);
  allocp[35] = x7 = makeref(&allocp[35]);
  allocp[36] = x4;
  allocp[37] = a7;
  allocp[38] = NILATOM;
  allocp[39] = x8 = makeref(&allocp[39]);
  allocp[40] = (q)(struct goalrec*)&allocp[31];
  allocp[41] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[42] = a0;
  allocp[43] = a2;
  allocp[44] = x9 = makeref(&allocp[44]);
  allocp[45] = a7;
  allocp[46] = x5;
  allocp[47] = (q)(struct goalrec*)&allocp[40];
  allocp[48] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[49] = a0;
  allocp[50] = a2;
  allocp[51] = x10 = makeref(&allocp[51]);
  allocp[52] = a7;
  allocp[53] = x7;
  allocp[54] = (q)(struct goalrec*)&allocp[47];
  allocp[55] = (q)(&predicate_functor__table_xarg_3);
  allocp[56] = makeint(2L);
  allocp[57] = a8;
  allocp[58] = x9;
  allocp[59] = (q)(struct goalrec*)&allocp[54];
  allocp[60] = (q)(&predicate_functor__table_xarg_3);
  allocp[61] = makeint(1L);
  allocp[62] = a8;
  allocp[63] = x10;
  qp = (struct goalrec*)&allocp[59];
  allocp += 64;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_125);
  *reasonp++ =  a6;
  goto make_11_162;
  };
  goto make_11_162;
 case symval(makesym(atom_diff)):
 make_11_127:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_128:
  if (a6 != makeint(2L)) goto make_11_162;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = makesym(atom_guard);
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = makesym(functor_goal_4);
  allocp[12] = a0;
  allocp[13] = a2;
  allocp[14] = makesym(atom_guard);
  allocp[15] = a4;
  x3 = makefunctor(&allocp[11]);
  allocp[16] = (q)(struct goalrec*)&allocp[5];
  allocp[17] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[18] = x3;
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = a9;
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_depset_xdd__arg_4);
  allocp[24] = makesym(atom_all);
  allocp[25] = x5 = makeref(&allocp[25]);
  allocp[26] = x1;
  allocp[27] = a7;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_depset_xdd__arg_4);
  allocp[30] = makesym(atom_all);
  allocp[31] = x6 = makeref(&allocp[31]);
  allocp[32] = x4;
  allocp[33] = a7;
  allocp[34] = (q)(struct goalrec*)&allocp[28];
  allocp[35] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[36] = a0;
  allocp[37] = a2;
  allocp[38] = x7 = makeref(&allocp[38]);
  allocp[39] = a7;
  allocp[40] = x5;
  allocp[41] = (q)(struct goalrec*)&allocp[34];
  allocp[42] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[43] = a0;
  allocp[44] = a2;
  allocp[45] = x8 = makeref(&allocp[45]);
  allocp[46] = a7;
  allocp[47] = x6;
  allocp[48] = (q)(struct goalrec*)&allocp[41];
  allocp[49] = (q)(&predicate_functor__table_xarg_3);
  allocp[50] = makeint(2L);
  allocp[51] = a8;
  allocp[52] = x7;
  allocp[53] = (q)(struct goalrec*)&allocp[48];
  allocp[54] = (q)(&predicate_functor__table_xarg_3);
  allocp[55] = makeint(1L);
  allocp[56] = a8;
  allocp[57] = x8;
  qp = (struct goalrec*)&allocp[53];
  allocp += 58;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_127);
  *reasonp++ =  a6;
  goto make_11_162;
  };
  goto make_11_162;
 case symval(makesym(atom_hash)):
 make_11_129:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_130:
  if (a6 != makeint(2L)) goto make_11_162;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = makesym(atom_guard);
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = (q)(struct goalrec*)&allocp[5];
  allocp[12] = (q)(&predicate_depset_xdd__arg_7);
  allocp[13] = makesym(atom_all);
  allocp[14] = makesym(atom_n);
  allocp[15] = x2 = makeref(&allocp[15]);
  allocp[16] = x1;
  allocp[17] = a7;
  allocp[18] = NILATOM;
  allocp[19] = x3 = makeref(&allocp[19]);
  allocp[20] = (q)(struct goalrec*)&allocp[11];
  allocp[21] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[22] = a0;
  allocp[23] = a2;
  allocp[24] = x4 = makeref(&allocp[24]);
  allocp[25] = a7;
  allocp[26] = x2;
  allocp[27] = (q)(struct goalrec*)&allocp[20];
  allocp[28] = (q)(&predicate_functor__table_xarg_3);
  allocp[29] = makeint(1L);
  allocp[30] = a8;
  allocp[31] = x4;
  qp = (struct goalrec*)&allocp[27];
  allocp += 32;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_129);
  *reasonp++ =  a6;
  goto make_11_162;
  };
  goto make_11_162;
 case symval(makesym(atom_atomic)):
 make_11_131:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_132:
  if (a6 != makeint(1L)) goto make_11_162;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = makesym(atom_guard);
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = makesym(functor_goal_4);
  allocp[12] = a0;
  allocp[13] = a2;
  allocp[14] = makesym(atom_guard);
  allocp[15] = a4;
  x3 = makefunctor(&allocp[11]);
  allocp[16] = (q)(struct goalrec*)&allocp[5];
  allocp[17] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[18] = x3;
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = a9;
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_depset_xdd__arg_4);
  allocp[24] = makesym(atom_a);
  allocp[25] = x5 = makeref(&allocp[25]);
  allocp[26] = x1;
  allocp[27] = a7;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_depset_xdd__arg_4);
  allocp[30] = makesym(atom_i);
  allocp[31] = x5;
  allocp[32] = x4;
  allocp[33] = a7;
  allocp[34] = (q)(struct goalrec*)&allocp[28];
  allocp[35] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[36] = a0;
  allocp[37] = a2;
  allocp[38] = x6 = makeref(&allocp[38]);
  allocp[39] = a7;
  allocp[40] = x5;
  allocp[41] = (q)(struct goalrec*)&allocp[34];
  allocp[42] = (q)(&predicate_functor__table_xarg_3);
  allocp[43] = makeint(1L);
  allocp[44] = a8;
  allocp[45] = x6;
  qp = (struct goalrec*)&allocp[41];
  allocp += 46;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_131);
  *reasonp++ =  a6;
  goto make_11_162;
  };
  goto make_11_162;
 case symval(makesym(atom_atom)):
 make_11_133:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_134:
  if (a6 != makeint(1L)) goto make_11_162;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = makesym(atom_guard);
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = (q)(struct goalrec*)&allocp[5];
  allocp[12] = (q)(&predicate_depset_xdd__arg_4);
  allocp[13] = makesym(atom_a);
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = a7;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[19] = a0;
  allocp[20] = a2;
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = a7;
  allocp[23] = x2;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_functor__table_xarg_3);
  allocp[26] = makeint(1L);
  allocp[27] = a8;
  allocp[28] = x3;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_133);
  *reasonp++ =  a6;
  goto make_11_162;
  };
  goto make_11_162;
 case symval(makesym(atom_integer)):
 make_11_135:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_136:
  if (a6 != makeint(1L)) goto make_11_162;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = makesym(atom_guard);
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = (q)(struct goalrec*)&allocp[5];
  allocp[12] = (q)(&predicate_depset_xdd__arg_4);
  allocp[13] = makesym(atom_i);
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = a7;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[19] = a0;
  allocp[20] = a2;
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = a7;
  allocp[23] = x2;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_functor__table_xarg_3);
  allocp[26] = makeint(1L);
  allocp[27] = a8;
  allocp[28] = x3;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_135);
  *reasonp++ =  a6;
  goto make_11_162;
  };
  goto make_11_162;
 case symval(makesym(atom_greater__than)):
 make_11_137:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_138:
  if (a6 != makeint(2L)) goto make_11_162;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = makesym(atom_guard);
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = makesym(functor_goal_4);
  allocp[12] = a0;
  allocp[13] = a2;
  allocp[14] = makesym(atom_guard);
  allocp[15] = a4;
  x3 = makefunctor(&allocp[11]);
  allocp[16] = (q)(struct goalrec*)&allocp[5];
  allocp[17] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[18] = x3;
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = a9;
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_depset_xdd__arg_4);
  allocp[24] = makesym(atom_i);
  allocp[25] = x5 = makeref(&allocp[25]);
  allocp[26] = x1;
  allocp[27] = a7;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_depset_xdd__arg_4);
  allocp[30] = makesym(atom_i);
  allocp[31] = x6 = makeref(&allocp[31]);
  allocp[32] = x4;
  allocp[33] = a7;
  allocp[34] = (q)(struct goalrec*)&allocp[28];
  allocp[35] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[36] = a0;
  allocp[37] = a2;
  allocp[38] = x7 = makeref(&allocp[38]);
  allocp[39] = a7;
  allocp[40] = x5;
  allocp[41] = (q)(struct goalrec*)&allocp[34];
  allocp[42] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[43] = a0;
  allocp[44] = a2;
  allocp[45] = x8 = makeref(&allocp[45]);
  allocp[46] = a7;
  allocp[47] = x6;
  allocp[48] = (q)(struct goalrec*)&allocp[41];
  allocp[49] = (q)(&predicate_functor__table_xarg_3);
  allocp[50] = makeint(2L);
  allocp[51] = a8;
  allocp[52] = x7;
  allocp[53] = (q)(struct goalrec*)&allocp[48];
  allocp[54] = (q)(&predicate_functor__table_xarg_3);
  allocp[55] = makeint(1L);
  allocp[56] = a8;
  allocp[57] = x8;
  qp = (struct goalrec*)&allocp[53];
  allocp += 58;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_137);
  *reasonp++ =  a6;
  goto make_11_162;
  };
  goto make_11_162;
 case symval(makesym(atom_not__less__than)):
 make_11_139:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_140:
  if (a6 != makeint(2L)) goto make_11_162;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = makesym(atom_guard);
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = makesym(functor_goal_4);
  allocp[12] = a0;
  allocp[13] = a2;
  allocp[14] = makesym(atom_guard);
  allocp[15] = a4;
  x3 = makefunctor(&allocp[11]);
  allocp[16] = (q)(struct goalrec*)&allocp[5];
  allocp[17] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[18] = x3;
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = a9;
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_depset_xdd__arg_4);
  allocp[24] = makesym(atom_i);
  allocp[25] = x5 = makeref(&allocp[25]);
  allocp[26] = x1;
  allocp[27] = a7;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_depset_xdd__arg_4);
  allocp[30] = makesym(atom_i);
  allocp[31] = x6 = makeref(&allocp[31]);
  allocp[32] = x4;
  allocp[33] = a7;
  allocp[34] = (q)(struct goalrec*)&allocp[28];
  allocp[35] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[36] = a0;
  allocp[37] = a2;
  allocp[38] = x7 = makeref(&allocp[38]);
  allocp[39] = a7;
  allocp[40] = x5;
  allocp[41] = (q)(struct goalrec*)&allocp[34];
  allocp[42] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[43] = a0;
  allocp[44] = a2;
  allocp[45] = x8 = makeref(&allocp[45]);
  allocp[46] = a7;
  allocp[47] = x6;
  allocp[48] = (q)(struct goalrec*)&allocp[41];
  allocp[49] = (q)(&predicate_functor__table_xarg_3);
  allocp[50] = makeint(2L);
  allocp[51] = a8;
  allocp[52] = x7;
  allocp[53] = (q)(struct goalrec*)&allocp[48];
  allocp[54] = (q)(&predicate_functor__table_xarg_3);
  allocp[55] = makeint(1L);
  allocp[56] = a8;
  allocp[57] = x8;
  qp = (struct goalrec*)&allocp[53];
  allocp += 58;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_139);
  *reasonp++ =  a6;
  goto make_11_162;
  };
  goto make_11_162;
 case symval(makesym(atom_equal)):
 make_11_141:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_142:
  if (a6 != makeint(2L)) goto make_11_162;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = makesym(atom_guard);
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = makesym(functor_goal_4);
  allocp[12] = a0;
  allocp[13] = a2;
  allocp[14] = makesym(atom_guard);
  allocp[15] = a4;
  x3 = makefunctor(&allocp[11]);
  allocp[16] = (q)(struct goalrec*)&allocp[5];
  allocp[17] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[18] = x3;
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = a9;
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_depset_xdd__arg_4);
  allocp[24] = makesym(atom_i);
  allocp[25] = x5 = makeref(&allocp[25]);
  allocp[26] = x1;
  allocp[27] = a7;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_depset_xdd__arg_4);
  allocp[30] = makesym(atom_i);
  allocp[31] = x6 = makeref(&allocp[31]);
  allocp[32] = x4;
  allocp[33] = a7;
  allocp[34] = (q)(struct goalrec*)&allocp[28];
  allocp[35] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[36] = a0;
  allocp[37] = a2;
  allocp[38] = x7 = makeref(&allocp[38]);
  allocp[39] = a7;
  allocp[40] = x5;
  allocp[41] = (q)(struct goalrec*)&allocp[34];
  allocp[42] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[43] = a0;
  allocp[44] = a2;
  allocp[45] = x8 = makeref(&allocp[45]);
  allocp[46] = a7;
  allocp[47] = x6;
  allocp[48] = (q)(struct goalrec*)&allocp[41];
  allocp[49] = (q)(&predicate_functor__table_xarg_3);
  allocp[50] = makeint(2L);
  allocp[51] = a8;
  allocp[52] = x7;
  allocp[53] = (q)(struct goalrec*)&allocp[48];
  allocp[54] = (q)(&predicate_functor__table_xarg_3);
  allocp[55] = makeint(1L);
  allocp[56] = a8;
  allocp[57] = x8;
  qp = (struct goalrec*)&allocp[53];
  allocp += 58;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_141);
  *reasonp++ =  a6;
  goto make_11_162;
  };
  goto make_11_162;
 case symval(makesym(atom_not__equal)):
 make_11_143:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_144:
  if (a6 != makeint(2L)) goto make_11_162;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = makesym(atom_guard);
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = makesym(functor_goal_4);
  allocp[12] = a0;
  allocp[13] = a2;
  allocp[14] = makesym(atom_guard);
  allocp[15] = a4;
  x3 = makefunctor(&allocp[11]);
  allocp[16] = (q)(struct goalrec*)&allocp[5];
  allocp[17] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[18] = x3;
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = a9;
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_depset_xdd__arg_4);
  allocp[24] = makesym(atom_i);
  allocp[25] = x5 = makeref(&allocp[25]);
  allocp[26] = x1;
  allocp[27] = a7;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_depset_xdd__arg_4);
  allocp[30] = makesym(atom_i);
  allocp[31] = x6 = makeref(&allocp[31]);
  allocp[32] = x4;
  allocp[33] = a7;
  allocp[34] = (q)(struct goalrec*)&allocp[28];
  allocp[35] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[36] = a0;
  allocp[37] = a2;
  allocp[38] = x7 = makeref(&allocp[38]);
  allocp[39] = a7;
  allocp[40] = x5;
  allocp[41] = (q)(struct goalrec*)&allocp[34];
  allocp[42] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[43] = a0;
  allocp[44] = a2;
  allocp[45] = x8 = makeref(&allocp[45]);
  allocp[46] = a7;
  allocp[47] = x6;
  allocp[48] = (q)(struct goalrec*)&allocp[41];
  allocp[49] = (q)(&predicate_functor__table_xarg_3);
  allocp[50] = makeint(2L);
  allocp[51] = a8;
  allocp[52] = x7;
  allocp[53] = (q)(struct goalrec*)&allocp[48];
  allocp[54] = (q)(&predicate_functor__table_xarg_3);
  allocp[55] = makeint(1L);
  allocp[56] = a8;
  allocp[57] = x8;
  qp = (struct goalrec*)&allocp[53];
  allocp += 58;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_143);
  *reasonp++ =  a6;
  goto make_11_162;
  };
  goto make_11_162;
 case symval(makesym(atom_not__greater__than)):
 make_11_145:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_146:
  if (a6 != makeint(2L)) goto make_11_162;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = makesym(atom_guard);
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = makesym(functor_goal_4);
  allocp[12] = a0;
  allocp[13] = a2;
  allocp[14] = makesym(atom_guard);
  allocp[15] = a4;
  x3 = makefunctor(&allocp[11]);
  allocp[16] = (q)(struct goalrec*)&allocp[5];
  allocp[17] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[18] = x3;
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = a9;
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_depset_xdd__arg_4);
  allocp[24] = makesym(atom_i);
  allocp[25] = x5 = makeref(&allocp[25]);
  allocp[26] = x1;
  allocp[27] = a7;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_depset_xdd__arg_4);
  allocp[30] = makesym(atom_i);
  allocp[31] = x6 = makeref(&allocp[31]);
  allocp[32] = x4;
  allocp[33] = a7;
  allocp[34] = (q)(struct goalrec*)&allocp[28];
  allocp[35] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[36] = a0;
  allocp[37] = a2;
  allocp[38] = x7 = makeref(&allocp[38]);
  allocp[39] = a7;
  allocp[40] = x5;
  allocp[41] = (q)(struct goalrec*)&allocp[34];
  allocp[42] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[43] = a0;
  allocp[44] = a2;
  allocp[45] = x8 = makeref(&allocp[45]);
  allocp[46] = a7;
  allocp[47] = x6;
  allocp[48] = (q)(struct goalrec*)&allocp[41];
  allocp[49] = (q)(&predicate_functor__table_xarg_3);
  allocp[50] = makeint(2L);
  allocp[51] = a8;
  allocp[52] = x7;
  allocp[53] = (q)(struct goalrec*)&allocp[48];
  allocp[54] = (q)(&predicate_functor__table_xarg_3);
  allocp[55] = makeint(1L);
  allocp[56] = a8;
  allocp[57] = x8;
  qp = (struct goalrec*)&allocp[53];
  allocp += 58;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_145);
  *reasonp++ =  a6;
  goto make_11_162;
  };
  goto make_11_162;
 case symval(makesym(atom_less__than)):
 make_11_147:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_148:
  if (a6 != makeint(2L)) goto make_11_162;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = makesym(atom_guard);
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = makesym(functor_goal_4);
  allocp[12] = a0;
  allocp[13] = a2;
  allocp[14] = makesym(atom_guard);
  allocp[15] = a4;
  x3 = makefunctor(&allocp[11]);
  allocp[16] = (q)(struct goalrec*)&allocp[5];
  allocp[17] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[18] = x3;
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = a9;
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_depset_xdd__arg_4);
  allocp[24] = makesym(atom_i);
  allocp[25] = x5 = makeref(&allocp[25]);
  allocp[26] = x1;
  allocp[27] = a7;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_depset_xdd__arg_4);
  allocp[30] = makesym(atom_i);
  allocp[31] = x6 = makeref(&allocp[31]);
  allocp[32] = x4;
  allocp[33] = a7;
  allocp[34] = (q)(struct goalrec*)&allocp[28];
  allocp[35] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[36] = a0;
  allocp[37] = a2;
  allocp[38] = x7 = makeref(&allocp[38]);
  allocp[39] = a7;
  allocp[40] = x5;
  allocp[41] = (q)(struct goalrec*)&allocp[34];
  allocp[42] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[43] = a0;
  allocp[44] = a2;
  allocp[45] = x8 = makeref(&allocp[45]);
  allocp[46] = a7;
  allocp[47] = x6;
  allocp[48] = (q)(struct goalrec*)&allocp[41];
  allocp[49] = (q)(&predicate_functor__table_xarg_3);
  allocp[50] = makeint(2L);
  allocp[51] = a8;
  allocp[52] = x7;
  allocp[53] = (q)(struct goalrec*)&allocp[48];
  allocp[54] = (q)(&predicate_functor__table_xarg_3);
  allocp[55] = makeint(1L);
  allocp[56] = a8;
  allocp[57] = x8;
  qp = (struct goalrec*)&allocp[53];
  allocp += 58;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_147);
  *reasonp++ =  a6;
  goto make_11_162;
  };
  goto make_11_162;
 case symval(makesym(atom_float)):
 make_11_149:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_150:
  if (a6 != makeint(1L)) goto make_11_162;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = makesym(atom_guard);
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = (q)(struct goalrec*)&allocp[5];
  allocp[12] = (q)(&predicate_depset_xdd__arg_4);
  allocp[13] = makesym(atom_f);
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = a7;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[19] = a0;
  allocp[20] = a2;
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = a7;
  allocp[23] = x2;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_functor__table_xarg_3);
  allocp[26] = makeint(1L);
  allocp[27] = a8;
  allocp[28] = x3;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_149);
  *reasonp++ =  a6;
  goto make_11_162;
  };
  goto make_11_162;
 case symval(makesym(atom_list)):
 make_11_151:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_152:
  if (a6 != makeint(1L)) goto make_11_162;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = makesym(atom_guard);
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = (q)(struct goalrec*)&allocp[5];
  allocp[12] = (q)(&predicate_depset_xdd__arg_4);
  allocp[13] = makesym(atom_l);
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = a7;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[19] = a0;
  allocp[20] = a2;
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = a7;
  allocp[23] = x2;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_functor__table_xarg_3);
  allocp[26] = makeint(1L);
  allocp[27] = a8;
  allocp[28] = x3;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_151);
  *reasonp++ =  a6;
  goto make_11_162;
  };
  goto make_11_162;
 case symval(makesym(atom_vector)):
 make_11_153:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_154:
  if (a6 != makeint(2L)) goto make_11_162;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = makesym(atom_guard);
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = (q)(struct goalrec*)&allocp[5];
  allocp[12] = (q)(&predicate_depset_xdd__arg_4);
  allocp[13] = makesym(atom_v);
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = a7;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[19] = a0;
  allocp[20] = a2;
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = a7;
  allocp[23] = x2;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_functor__table_xarg_3);
  allocp[26] = makeint(1L);
  allocp[27] = a8;
  allocp[28] = x3;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_153);
  *reasonp++ =  a6;
  goto make_11_162;
  };
  goto make_11_162;
  };
  goto make_11_162;
 case VARREF:
  deref_and_jump(a5,make_11_122);
  *reasonp++ =  a5;
  goto make_11_162;
  };
  goto make_11_162;
 case symval(makesym(atom_body)):
 make_11_155:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (isint(a5)) goto make_11_162;
  switch (symval(a5)) {
 case symval(makesym(atom_unbound)):
 make_11_156:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_157:
  if (a6 != makeint(2L)) goto make_11_162;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = makesym(atom_body);
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = (q)(struct goalrec*)&allocp[5];
  allocp[12] = (q)(&predicate_depset_xdd__arg_4);
  allocp[13] = makesym(atom_all);
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = a7;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[19] = a0;
  allocp[20] = a2;
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = a7;
  allocp[23] = x2;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_functor__table_xarg_3);
  allocp[26] = makeint(1L);
  allocp[27] = a8;
  allocp[28] = x3;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_156);
  *reasonp++ =  a6;
  goto make_11_162;
  };
  goto make_11_162;
 case symval(makesym(atom_new__functor)):
 make_11_158:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_159:
  if (a6 != makeint(3L)) goto make_11_162;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = makesym(atom_body);
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = makesym(functor_goal_4);
  allocp[12] = a0;
  allocp[13] = a2;
  allocp[14] = makesym(atom_body);
  allocp[15] = a4;
  x3 = makefunctor(&allocp[11]);
  allocp[16] = (q)(struct goalrec*)&allocp[5];
  allocp[17] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[18] = x3;
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = a9;
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_depset_xdd__arg_4);
  allocp[24] = makesym(atom_i);
  allocp[25] = x5 = makeref(&allocp[25]);
  allocp[26] = x1;
  allocp[27] = a7;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_depset_xdd__arg_4);
  allocp[30] = makesym(atom_a);
  allocp[31] = x6 = makeref(&allocp[31]);
  allocp[32] = x4;
  allocp[33] = a7;
  allocp[34] = (q)(struct goalrec*)&allocp[28];
  allocp[35] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[36] = a0;
  allocp[37] = a2;
  allocp[38] = x7 = makeref(&allocp[38]);
  allocp[39] = a7;
  allocp[40] = x5;
  allocp[41] = (q)(struct goalrec*)&allocp[34];
  allocp[42] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[43] = a0;
  allocp[44] = a2;
  allocp[45] = x8 = makeref(&allocp[45]);
  allocp[46] = a7;
  allocp[47] = x6;
  allocp[48] = (q)(struct goalrec*)&allocp[41];
  allocp[49] = (q)(&predicate_functor__table_xarg_3);
  allocp[50] = makeint(3L);
  allocp[51] = a8;
  allocp[52] = x7;
  allocp[53] = (q)(struct goalrec*)&allocp[48];
  allocp[54] = (q)(&predicate_functor__table_xarg_3);
  allocp[55] = makeint(2L);
  allocp[56] = a8;
  allocp[57] = x8;
  qp = (struct goalrec*)&allocp[53];
  allocp += 58;
  proceed();
 case VARREF:
  deref_and_jump(a6,make_11_158);
  *reasonp++ =  a6;
  goto make_11_162;
  };
  goto make_11_162;
 case symval(makesym(atom_setarg)):
 make_11_160:
  switch (ptagof(a6)) {
 case ATOMIC:
 make_11_161:
  switch ((unsigned long)a6) {
 case (unsigned long) makeint(4L):
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = makesym(atom_body);
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = makesym(functor_goal_4);
  allocp[12] = a0;
  allocp[13] = a2;
  allocp[14] = makesym(atom_body);
  allocp[15] = a4;
  x3 = makefunctor(&allocp[11]);
  allocp[16] = (q)(struct goalrec*)&allocp[5];
  allocp[17] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[18] = x3;
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = x5 = makeref(&allocp[20]);
  allocp[21] = x2;
  allocp[22] = makesym(functor_goal_4);
  allocp[23] = a0;
  allocp[24] = a2;
  allocp[25] = makesym(atom_body);
  allocp[26] = a4;
  x6 = makefunctor(&allocp[22]);
  allocp[27] = (q)(struct goalrec*)&allocp[16];
  allocp[28] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[29] = x6;
  allocp[30] = x7 = makeref(&allocp[30]);
  allocp[31] = a9;
  allocp[32] = x5;
  allocp[33] = (q)(struct goalrec*)&allocp[27];
  allocp[34] = (q)(&predicate_depset_xdd__arg_4);
  allocp[35] = makesym(atom_all);
  allocp[36] = x8 = makeref(&allocp[36]);
  allocp[37] = x1;
  allocp[38] = a7;
  allocp[39] = (q)(struct goalrec*)&allocp[33];
  allocp[40] = (q)(&predicate_depset_xdd__arg_4);
  allocp[41] = makesym(atom_s);
  allocp[42] = x9 = makeref(&allocp[42]);
  allocp[43] = x4;
  allocp[44] = a7;
  allocp[45] = (q)(struct goalrec*)&allocp[39];
  allocp[46] = (q)(&predicate_depset_xdd__arg_4);
  allocp[47] = makesym(atom_i);
  allocp[48] = x10 = makeref(&allocp[48]);
  allocp[49] = x7;
  allocp[50] = a7;
  allocp[51] = (q)(struct goalrec*)&allocp[45];
  allocp[52] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[53] = a0;
  allocp[54] = a2;
  allocp[55] = x11 = makeref(&allocp[55]);
  allocp[56] = a7;
  allocp[57] = x8;
  allocp[58] = (q)(struct goalrec*)&allocp[51];
  allocp[59] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[60] = a0;
  allocp[61] = a2;
  allocp[62] = x12 = makeref(&allocp[62]);
  allocp[63] = a7;
  allocp[64] = x9;
  allocp[65] = (q)(struct goalrec*)&allocp[58];
  allocp[66] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[67] = a0;
  allocp[68] = a2;
  allocp[69] = x13 = makeref(&allocp[69]);
  allocp[70] = a7;
  allocp[71] = x10;
  allocp[72] = (q)(struct goalrec*)&allocp[65];
  allocp[73] = (q)(&predicate_functor__table_xarg_3);
  allocp[74] = makeint(3L);
  allocp[75] = a8;
  allocp[76] = x11;
  allocp[77] = (q)(struct goalrec*)&allocp[72];
  allocp[78] = (q)(&predicate_functor__table_xarg_3);
  allocp[79] = makeint(2L);
  allocp[80] = a8;
  allocp[81] = x12;
  allocp[82] = (q)(struct goalrec*)&allocp[77];
  allocp[83] = (q)(&predicate_functor__table_xarg_3);
  allocp[84] = makeint(1L);
  allocp[85] = a8;
  allocp[86] = x13;
  qp = (struct goalrec*)&allocp[82];
  allocp += 87;
  proceed();
 case (unsigned long) makeint(5L):
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = makesym(atom_body);
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = makesym(functor_goal_4);
  allocp[12] = a0;
  allocp[13] = a2;
  allocp[14] = makesym(atom_body);
  allocp[15] = a4;
  x3 = makefunctor(&allocp[11]);
  allocp[16] = (q)(struct goalrec*)&allocp[5];
  allocp[17] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[18] = x3;
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = x5 = makeref(&allocp[20]);
  allocp[21] = x2;
  allocp[22] = makesym(functor_goal_4);
  allocp[23] = a0;
  allocp[24] = a2;
  allocp[25] = makesym(atom_body);
  allocp[26] = a4;
  x6 = makefunctor(&allocp[22]);
  allocp[27] = (q)(struct goalrec*)&allocp[16];
  allocp[28] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[29] = x6;
  allocp[30] = x7 = makeref(&allocp[30]);
  allocp[31] = a9;
  allocp[32] = x5;
  allocp[33] = (q)(struct goalrec*)&allocp[27];
  allocp[34] = (q)(&predicate_depset_xdd__arg_4);
  allocp[35] = makesym(atom_all);
  allocp[36] = x8 = makeref(&allocp[36]);
  allocp[37] = x1;
  allocp[38] = a7;
  allocp[39] = (q)(struct goalrec*)&allocp[33];
  allocp[40] = (q)(&predicate_depset_xdd__arg_4);
  allocp[41] = makesym(atom_s);
  allocp[42] = x9 = makeref(&allocp[42]);
  allocp[43] = x4;
  allocp[44] = a7;
  allocp[45] = (q)(struct goalrec*)&allocp[39];
  allocp[46] = (q)(&predicate_depset_xdd__arg_4);
  allocp[47] = makesym(atom_i);
  allocp[48] = x10 = makeref(&allocp[48]);
  allocp[49] = x7;
  allocp[50] = a7;
  allocp[51] = (q)(struct goalrec*)&allocp[45];
  allocp[52] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[53] = a0;
  allocp[54] = a2;
  allocp[55] = x11 = makeref(&allocp[55]);
  allocp[56] = a7;
  allocp[57] = x8;
  allocp[58] = (q)(struct goalrec*)&allocp[51];
  allocp[59] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[60] = a0;
  allocp[61] = a2;
  allocp[62] = x12 = makeref(&allocp[62]);
  allocp[63] = a7;
  allocp[64] = x9;
  allocp[65] = (q)(struct goalrec*)&allocp[58];
  allocp[66] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[67] = a0;
  allocp[68] = a2;
  allocp[69] = x13 = makeref(&allocp[69]);
  allocp[70] = a7;
  allocp[71] = x10;
  allocp[72] = (q)(struct goalrec*)&allocp[65];
  allocp[73] = (q)(&predicate_functor__table_xarg_3);
  allocp[74] = makeint(4L);
  allocp[75] = a8;
  allocp[76] = x11;
  allocp[77] = (q)(struct goalrec*)&allocp[72];
  allocp[78] = (q)(&predicate_functor__table_xarg_3);
  allocp[79] = makeint(2L);
  allocp[80] = a8;
  allocp[81] = x12;
  allocp[82] = (q)(struct goalrec*)&allocp[77];
  allocp[83] = (q)(&predicate_functor__table_xarg_3);
  allocp[84] = makeint(1L);
  allocp[85] = a8;
  allocp[86] = x13;
  qp = (struct goalrec*)&allocp[82];
  allocp += 87;
  proceed();
  };
  goto make_11_162;
 case VARREF:
  deref_and_jump(a6,make_11_160);
  *reasonp++ =  a6;
  goto make_11_162;
  };
  goto make_11_162;
  };
  goto make_11_162;
 case VARREF:
  deref_and_jump(a5,make_11_155);
  *reasonp++ =  a5;
  goto make_11_162;
  };
  goto make_11_162;
  };
  goto make_11_162;
 case VARREF:
  deref_and_jump(a3,make_11_121);
  *reasonp++ =  a3;
  goto make_11_162;
  };
  goto make_11_162;
 make_11_162:
  otherwise(make_11_interrupt);
  unify(a10, a9);
  proceed();
 make_11_ext_interrupt:
  reasonp = 0l;
 make_11_interrupt:
  goto interrupt_11;
 }

 unify__deps_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 unify__deps_9_clear_reason:
  reasonp = reasons;
 unify__deps_9_0:
 unify__deps_9_1:
  switch (ptagof(a4)) {
 case ATOMIC:
  if (a4 != makesym(atom_guard)) goto unify__deps_9_6;
 unify__deps_9_2:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_variable_3)) goto unify__deps_9_6;
  x0 = arg(a0, 2);
 unify__deps_9_3:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_i)) goto unify__deps_9_6;
 unify__deps_9_4:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_variable_3)) goto unify__deps_9_6;
  x1 = arg(a1, 2);
 unify__deps_9_5:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_i)) goto unify__deps_9_6;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a2;
  allocp[2] = a3;
  allocp[3] = a4;
  allocp[4] = a5;
  x2 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x2;
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = x4 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = makesym(functor_goal_4);
  allocp[12] = a2;
  allocp[13] = a3;
  allocp[14] = a4;
  allocp[15] = a5;
  x5 = makefunctor(&allocp[11]);
  allocp[16] = (q)(struct goalrec*)&allocp[5];
  allocp[17] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[18] = x5;
  allocp[19] = x6 = makeref(&allocp[19]);
  allocp[20] = a7;
  allocp[21] = x4;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_depset_xdd__arg_4);
  allocp[24] = makesym(atom_all);
  allocp[25] = x7 = makeref(&allocp[25]);
  allocp[26] = x3;
  allocp[27] = a6;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_depset_xdd__arg_4);
  allocp[30] = makesym(atom_all);
  allocp[31] = x8 = makeref(&allocp[31]);
  allocp[32] = x6;
  allocp[33] = a6;
  allocp[34] = (q)(struct goalrec*)&allocp[28];
  allocp[35] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[36] = a2;
  allocp[37] = a3;
  allocp[38] = a1;
  allocp[39] = a6;
  allocp[40] = x7;
  allocp[41] = (q)(struct goalrec*)&allocp[34];
  allocp[42] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[43] = a2;
  allocp[44] = a3;
  allocp[45] = a0;
  allocp[46] = a6;
  allocp[47] = x8;
  qp = (struct goalrec*)&allocp[41];
  allocp += 48;
  proceed();
 case VARREF:
  deref_and_jump(x1,unify__deps_9_5);
  *reasonp++ =  x1;
  goto unify__deps_9_6;
  };
  goto unify__deps_9_6;
 case VARREF:
  deref_and_jump(a1,unify__deps_9_4);
  *reasonp++ =  a1;
  goto unify__deps_9_6;
  };
  goto unify__deps_9_6;
 case VARREF:
  deref_and_jump(x0,unify__deps_9_3);
  *reasonp++ =  x0;
  goto unify__deps_9_6;
  };
  goto unify__deps_9_6;
 case VARREF:
  deref_and_jump(a0,unify__deps_9_2);
  *reasonp++ =  a0;
  goto unify__deps_9_6;
  };
  goto unify__deps_9_6;
 case VARREF:
  deref_and_jump(a4,unify__deps_9_1);
  *reasonp++ =  a4;
  goto unify__deps_9_6;
  };
  goto unify__deps_9_6;
 unify__deps_9_6:
  otherwise(unify__deps_9_interrupt);
 unify__deps_9_7:
  switch (ptagof(a4)) {
 case ATOMIC:
  if (a4 != makesym(atom_guard)) goto unify__deps_9_10;
 unify__deps_9_8:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_variable_3)) goto unify__deps_9_10;
 unify__deps_9_9:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_variable_3)) goto unify__deps_9_10;
  unify(a8, a7);
  proceed();
 case VARREF:
  deref_and_jump(a1,unify__deps_9_9);
  *reasonp++ =  a1;
  goto unify__deps_9_10;
  };
  goto unify__deps_9_10;
 case VARREF:
  deref_and_jump(a0,unify__deps_9_8);
  *reasonp++ =  a0;
  goto unify__deps_9_10;
  };
  goto unify__deps_9_10;
 case VARREF:
  deref_and_jump(a4,unify__deps_9_7);
  *reasonp++ =  a4;
  goto unify__deps_9_10;
  };
  goto unify__deps_9_10;
 unify__deps_9_10:
  otherwise(unify__deps_9_interrupt);
 unify__deps_9_11:
  switch (ptagof(a4)) {
 case ATOMIC:
  if (a4 != makesym(atom_guard)) goto unify__deps_9_16;
 unify__deps_9_12:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_variable_3)) goto unify__deps_9_14;
  x0 = arg(a0, 2);
 unify__deps_9_13:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_i)) goto unify__deps_9_14;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a2;
  allocp[2] = a3;
  allocp[3] = a4;
  allocp[4] = a5;
  x1 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[7] = x1;
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[5];
  allocp[12] = (q)(&predicate_builtin__deps_xget__unify__deps_4);
  allocp[13] = x3 = makeref(&allocp[13]);
  allocp[14] = x4 = makeref(&allocp[14]);
  allocp[15] = a6;
  allocp[16] = x2;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_typeset_xvalue2typeset_5);
  allocp[19] = a2;
  allocp[20] = a3;
  allocp[21] = a1;
  allocp[22] = NILATOM;
  allocp[23] = x3;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_typeset_xget_5);
  allocp[26] = a2;
  allocp[27] = a3;
  x5 = arg(a0, 0);
  allocp[28] = x5;
  allocp[29] = x4;
  allocp[30] = a6;
  qp = (struct goalrec*)&allocp[24];
  allocp += 31;
  proceed();
 case VARREF:
  deref_and_jump(x0,unify__deps_9_13);
  *reasonp++ =  x0;
  goto unify__deps_9_14;
  };
  goto unify__deps_9_14;
 case VARREF:
  deref_and_jump(a0,unify__deps_9_12);
  *reasonp++ =  a0;
  goto unify__deps_9_14;
  };
  goto unify__deps_9_14;
 unify__deps_9_14:
 unify__deps_9_15:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_variable_3)) goto unify__deps_9_16;
  x0 = a1;
  a1 = a0;
  a0 = x0;
  execute(unify__deps_9_clear_reason);
  goto unify__deps_9_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,unify__deps_9_15);
  *reasonp++ =  a1;
  goto unify__deps_9_16;
  };
  goto unify__deps_9_16;
 case VARREF:
  deref_and_jump(a4,unify__deps_9_11);
  *reasonp++ =  a4;
  goto unify__deps_9_16;
  };
  goto unify__deps_9_16;
 unify__deps_9_16:
  otherwise(unify__deps_9_interrupt);
  unify(a8, a7);
  proceed();
 unify__deps_9_ext_interrupt:
  reasonp = 0l;
 unify__deps_9_interrupt:
  goto interrupt_9;
 }

 get__unify__deps_4_top: {
  q x0;
  qp = qp->next;
 get__unify__deps_4_clear_reason:
  reasonp = reasons;
 get__unify__deps_4_0:
  a4 = a3;
  a5 = NILATOM;
  allocp[0] = x0 = makeref(&allocp[0]);
  a6 = x0;
  a3 = NILATOM;
  allocp += 1;
  execute(get__unify__deps_7_0);
  goto get__unify__deps_7_ext_interrupt;
 get__unify__deps_4_ext_interrupt:
  reasonp = 0l;
 get__unify__deps_4_interrupt:
  goto interrupt_4;
 }

 get__unify__deps_7_top: {
  q x0, x1, x2;
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 get__unify__deps_7_clear_reason:
  reasonp = reasons;
 get__unify__deps_7_0:
 get__unify__deps_7_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin__deps_xget__unify__deps_7);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = a6;
  a0 = car_of(a0);
  a4 = x1;
  a6 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 9;
  execute(get__unify__deps2_7_0);
  goto get__unify__deps2_7_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto get__unify__deps_7_interrupt;
  unify2(a6, a5, a4, a3);
  proceed();
 case VARREF:
  deref_and_jump(a0,get__unify__deps_7_1);
  *reasonp++ =  a0;
  goto get__unify__deps_7_interrupt;
  };
  goto get__unify__deps_7_interrupt;
 get__unify__deps_7_ext_interrupt:
  reasonp = 0l;
 get__unify__deps_7_interrupt:
  toppred = &predicate_builtin__deps_xget__unify__deps_7;
  goto interrupt_7;
 }

 get__unify__deps2_7_top: {
  q x0, x1, x2;
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 get__unify__deps2_7_clear_reason:
  reasonp = reasons;
 get__unify__deps2_7_0:
 get__unify__deps2_7_1:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin__deps_xget__unify__deps2_7);
  allocp[2] = a0;
  x0 = cdr_of(a1);
  allocp[3] = x0;
  allocp[4] = a2;
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = a6;
  a1 = car_of(a1);
  a4 = x1;
  a6 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 9;
  execute(get__unify__deps3_7_0);
  goto get__unify__deps3_7_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto get__unify__deps2_7_interrupt;
  unify2(a6, a5, a4, a3);
  proceed();
 case VARREF:
  deref_and_jump(a1,get__unify__deps2_7_1);
  *reasonp++ =  a1;
  goto get__unify__deps2_7_interrupt;
  };
  goto get__unify__deps2_7_interrupt;
 get__unify__deps2_7_ext_interrupt:
  reasonp = 0l;
 get__unify__deps2_7_interrupt:
  toppred = &predicate_builtin__deps_xget__unify__deps2_7;
  goto interrupt_7;
 }

 get__unify__deps3_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 get__unify__deps3_7_clear_reason:
  reasonp = reasons;
 get__unify__deps3_7_0:
 get__unify__deps3_7_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom__2A)) goto get__unify__deps3_7_24;
  unify2(a6, a5, a4, a3);
  proceed();
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_t_2)) goto get__unify__deps3_7_24;
 get__unify__deps3_7_2:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_t_2)) goto get__unify__deps3_7_24;
  x0 = arg(a0, 0);
 get__unify__deps3_7_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_s_3)) goto get__unify__deps3_7_24;
  x1 = arg(a1, 0);
 get__unify__deps3_7_4:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_s_3)) goto get__unify__deps3_7_15;
  x2 = arg(x1, 0);
 get__unify__deps3_7_5:
  if (isref(x2)) goto get__unify__deps3_7_14;
 get__unify__deps3_7_6:
  if (isref(x2)) goto get__unify__deps3_7_13;
  x3 = arg(x0, 0);
  if_not_equal(x2, x3, get__unify__deps3_7_15);
  x4 = arg(x1, 1);
 get__unify__deps3_7_7:
  if (isref(x4)) goto get__unify__deps3_7_12;
 get__unify__deps3_7_8:
  if (isref(x4)) goto get__unify__deps3_7_11;
  x5 = arg(x0, 1);
  if_not_equal(x4, x5, get__unify__deps3_7_15);
 get__unify__deps3_7_9:
  if (!isint(x5)) goto get__unify__deps3_7_10;
  gblt_integer(x5,get__unify__deps3_7_15);
  unify(a6, a5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin__deps_xget__unify__struct_6);
  allocp[2] = x5;
  x6 = arg(x0, 2);
  allocp[3] = x6;
  x7 = arg(x1, 2);
  allocp[4] = x7;
  allocp[5] = a2;
  allocp[6] = x8 = makeref(&allocp[6]);
  allocp[7] = a4;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_list_xor__unique_3);
  allocp[10] = a3;
  x9 = arg(a1, 1);
  allocp[11] = x9;
  allocp[12] = x8;
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  proceed();
 get__unify__deps3_7_10:
  if (!isref(x5)) goto get__unify__deps3_7_15;
  deref_and_jump(x5,get__unify__deps3_7_9);
  *reasonp++ =  x5;
  goto get__unify__deps3_7_15;
 get__unify__deps3_7_11:
  deref_and_jump(x4,get__unify__deps3_7_8);
  *reasonp++ =  x4;
  goto get__unify__deps3_7_15;
 get__unify__deps3_7_12:
  deref_and_jump(x4,get__unify__deps3_7_7);
  *reasonp++ =  x4;
  goto get__unify__deps3_7_15;
 get__unify__deps3_7_13:
  deref_and_jump(x2,get__unify__deps3_7_6);
  *reasonp++ =  x2;
  goto get__unify__deps3_7_15;
 get__unify__deps3_7_14:
  deref_and_jump(x2,get__unify__deps3_7_5);
  *reasonp++ =  x2;
  goto get__unify__deps3_7_15;
 case VARREF:
  deref_and_jump(x1,get__unify__deps3_7_4);
  *reasonp++ =  x1;
  goto get__unify__deps3_7_15;
  };
  goto get__unify__deps3_7_15;
 get__unify__deps3_7_15:
  x2 = arg(x0, 1);
 get__unify__deps3_7_16:
  if (!isint(x2)) goto get__unify__deps3_7_23;
  gblt_integer(x2,get__unify__deps3_7_24);
 get__unify__deps3_7_17:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_s_3)) goto get__unify__deps3_7_24;
  x3 = arg(x1, 0);
 get__unify__deps3_7_18:
  if (isref(x3)) goto get__unify__deps3_7_22;
 get__unify__deps3_7_19:
  if (isref(x3)) goto get__unify__deps3_7_21;
  x4 = arg(x0, 0);
  if_not_equal(x3, x4, get__unify__deps3_7_24);
  x5 = arg(x1, 1);
 get__unify__deps3_7_20:
  switch (ptagof(x5)) {
 case ATOMIC:
  if (x5 != makesym(atom__2A)) goto get__unify__deps3_7_24;
  unify(a6, a5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin__deps_xget__unify__struct_6);
  allocp[2] = x2;
  x6 = arg(x0, 2);
  allocp[3] = x6;
  x7 = arg(x1, 2);
  allocp[4] = x7;
  allocp[5] = a2;
  allocp[6] = x8 = makeref(&allocp[6]);
  allocp[7] = a4;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_list_xor__unique_3);
  allocp[10] = a3;
  x9 = arg(a1, 1);
  allocp[11] = x9;
  allocp[12] = x8;
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  proceed();
 case VARREF:
  deref_and_jump(x5,get__unify__deps3_7_20);
  *reasonp++ =  x5;
  goto get__unify__deps3_7_24;
  };
  goto get__unify__deps3_7_24;
 get__unify__deps3_7_21:
  deref_and_jump(x3,get__unify__deps3_7_19);
  *reasonp++ =  x3;
  goto get__unify__deps3_7_24;
 get__unify__deps3_7_22:
  deref_and_jump(x3,get__unify__deps3_7_18);
  *reasonp++ =  x3;
  goto get__unify__deps3_7_24;
 case VARREF:
  deref_and_jump(x1,get__unify__deps3_7_17);
  *reasonp++ =  x1;
  goto get__unify__deps3_7_24;
  };
  goto get__unify__deps3_7_24;
 get__unify__deps3_7_23:
  if (!isref(x2)) goto get__unify__deps3_7_24;
  deref_and_jump(x2,get__unify__deps3_7_16);
  *reasonp++ =  x2;
  goto get__unify__deps3_7_24;
 case VARREF:
  deref_and_jump(x0,get__unify__deps3_7_3);
  *reasonp++ =  x0;
  goto get__unify__deps3_7_24;
  };
  goto get__unify__deps3_7_24;
 case VARREF:
  deref_and_jump(a1,get__unify__deps3_7_2);
  *reasonp++ =  a1;
  goto get__unify__deps3_7_24;
  };
  goto get__unify__deps3_7_24;
 case VARREF:
  deref_and_jump(a0,get__unify__deps3_7_1);
  *reasonp++ =  a0;
  goto get__unify__deps3_7_24;
  };
  goto get__unify__deps3_7_24;
 get__unify__deps3_7_24:
 get__unify__deps3_7_25:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_tv_2)) goto get__unify__deps3_7_27;
  x0 = arg(a1, 0);
 get__unify__deps3_7_26:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_v_4)) goto get__unify__deps3_7_27;
  allocp[0] = makesym(functor_v_3);
  x2 = arg(x0, 0);
  allocp[1] = x2;
  x3 = arg(x0, 1);
  allocp[2] = x3;
  x4 = arg(x0, 2);
  allocp[3] = x4;
  x1 = makefunctor(&allocp[0]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_builtin__deps_xget__var_9);
  allocp[6] = x5 = makeref(&allocp[6]);
  allocp[7] = x1;
  x6 = arg(a1, 1);
  allocp[8] = x6;
  allocp[9] = a0;
  allocp[10] = a2;
  allocp[11] = a3;
  allocp[12] = a4;
  allocp[13] = a5;
  allocp[14] = a6;
  allocp[15] = makesym(functor_v_3);
  x8 = arg(x0, 0);
  allocp[16] = x8;
  x9 = arg(x0, 1);
  allocp[17] = x9;
  x10 = arg(x0, 2);
  allocp[18] = x10;
  x7 = makefunctor(&allocp[15]);
  allocp[19] = (q)(struct goalrec*)&allocp[4];
  allocp[20] = (q)(&predicate_list_xcheck__include_3);
  allocp[21] = x7;
  allocp[22] = a5;
  allocp[23] = x5;
  qp = (struct goalrec*)&allocp[19];
  allocp += 24;
  proceed();
 case VARREF:
  deref_and_jump(x0,get__unify__deps3_7_26);
  *reasonp++ =  x0;
  goto get__unify__deps3_7_27;
  };
  goto get__unify__deps3_7_27;
 case VARREF:
  deref_and_jump(a1,get__unify__deps3_7_25);
  *reasonp++ =  a1;
  goto get__unify__deps3_7_27;
  };
  goto get__unify__deps3_7_27;
 get__unify__deps3_7_27:
  otherwise(get__unify__deps3_7_interrupt);
 get__unify__deps3_7_28:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_t_2)) goto get__unify__deps3_7_38;
 get__unify__deps3_7_29:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_t_2)) goto get__unify__deps3_7_38;
  x0 = arg(a0, 0);
 get__unify__deps3_7_30:
  if (isref(x0)) goto get__unify__deps3_7_37;
  gblt_pfunctor(x0,x1,get__unify__deps3_7_38);
  gblt_arity(x0,x2,get__unify__deps3_7_38);
  x3 = arg(a1, 0);
 get__unify__deps3_7_31:
  if (isref(x3)) goto get__unify__deps3_7_36;
  gblt_pfunctor(x3,x4,get__unify__deps3_7_38);
 get__unify__deps3_7_32:
  if (isref(x4)) goto get__unify__deps3_7_35;
 get__unify__deps3_7_33:
  if (isref(x4)) goto get__unify__deps3_7_34;
  if_not_equal(x4, x1, get__unify__deps3_7_38);
  gblt_arity(x3,x5,get__unify__deps3_7_38);
  unify(a6, a5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_list_xor__unique_3);
  allocp[2] = a3;
  x6 = arg(a1, 1);
  allocp[3] = x6;
  allocp[4] = a4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 get__unify__deps3_7_34:
  deref_and_jump(x4,get__unify__deps3_7_33);
  *reasonp++ =  x4;
  goto get__unify__deps3_7_38;
 get__unify__deps3_7_35:
  deref_and_jump(x4,get__unify__deps3_7_32);
  *reasonp++ =  x4;
  goto get__unify__deps3_7_38;
 get__unify__deps3_7_36:
  deref_and_jump(x3,get__unify__deps3_7_31);
  *reasonp++ =  x3;
  goto get__unify__deps3_7_38;
 get__unify__deps3_7_37:
  deref_and_jump(x0,get__unify__deps3_7_30);
  *reasonp++ =  x0;
  goto get__unify__deps3_7_38;
 case VARREF:
  deref_and_jump(a1,get__unify__deps3_7_29);
  *reasonp++ =  a1;
  goto get__unify__deps3_7_38;
  };
  goto get__unify__deps3_7_38;
 case VARREF:
  deref_and_jump(a0,get__unify__deps3_7_28);
  *reasonp++ =  a0;
  goto get__unify__deps3_7_38;
  };
  goto get__unify__deps3_7_38;
 get__unify__deps3_7_38:
  otherwise(get__unify__deps3_7_interrupt);
  unify2(a6, a5, a4, a3);
  proceed();
 get__unify__deps3_7_ext_interrupt:
  reasonp = 0l;
 get__unify__deps3_7_interrupt:
  toppred = &predicate_builtin__deps_xget__unify__deps3_7;
  goto interrupt_7;
 }

 get__var_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 get__var_9_clear_reason:
  reasonp = reasons;
 get__var_9_0:
 get__var_9_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto get__var_9_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_no)):
 get__var_9_2:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_v_3)) goto get__var_9_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin__deps_xget__var2_4);
  allocp[2] = a5;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a6;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_builtin__deps_xget__unify__deps2_7);
  allocp[8] = a3;
  allocp[9] = x1 = makeref(&allocp[9]);
  allocp[10] = a4;
  allocp[11] = a5;
  allocp[12] = x0;
  allocp[13] = x2 = makeref(&allocp[13]);
  allocp[14] = a8;
  allocp[15] = makesym(functor_v_3);
  x4 = arg(a1, 0);
  allocp[16] = x4;
  x5 = arg(a1, 1);
  allocp[17] = x5;
  x6 = arg(a1, 2);
  allocp[18] = x6;
  x3 = makefunctor(&allocp[15]);
  allocp[19] = a7;
  allocp[20] = x3;
  x7 = makecons(&allocp[19]);
  qp = (struct goalrec*)&allocp[6];
  allocp += 21;
  unify_value(x2, x7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xget_5);
  x8 = arg(a1, 0);
  allocp[2] = x8;
  x9 = arg(a1, 1);
  allocp[3] = x9;
  x10 = arg(a1, 2);
  allocp[4] = x10;
  allocp[5] = x1;
  allocp[6] = a4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  proceed();
 case VARREF:
  deref_and_jump(a1,get__var_9_2);
  *reasonp++ =  a1;
  goto get__var_9_interrupt;
  };
  goto get__var_9_interrupt;
 case symval(makesym(atom_yes)):
  unify2(a8, a7, a6, a5);
  proceed();
  };
  goto get__var_9_interrupt;
 case VARREF:
  deref_and_jump(a0,get__var_9_1);
  *reasonp++ =  a0;
  goto get__var_9_interrupt;
  };
  goto get__var_9_interrupt;
 get__var_9_ext_interrupt:
  reasonp = 0l;
 get__var_9_interrupt:
  goto interrupt_9;
 }

 get__var2_4_top: {
  qp = qp->next;
 get__var2_4_clear_reason:
  reasonp = reasons;
 get__var2_4_0:
 get__var2_4_1:
  if (isref(a0)) goto get__var2_4_4;
 get__var2_4_2:
  if (isref(a0)) goto get__var2_4_3;
  if_not_equal(a0, a1, get__var2_4_5);
  unify(a3, a1);
  proceed();
 get__var2_4_3:
  deref_and_jump(a0,get__var2_4_2);
  *reasonp++ =  a0;
  goto get__var2_4_5;
 get__var2_4_4:
  deref_and_jump(a0,get__var2_4_1);
  *reasonp++ =  a0;
  goto get__var2_4_5;
 get__var2_4_5:
  otherwise(get__var2_4_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_list_xor__unique_3);
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 get__var2_4_ext_interrupt:
  reasonp = 0l;
 get__var2_4_interrupt:
  goto interrupt_4;
 }

 get__unify__struct_6_top: {
  q x0, x1, x2, x3, x4, x5;
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 get__unify__struct_6_clear_reason:
  reasonp = reasons;
 get__unify__struct_6_0:
 get__unify__struct_6_1:
  switch (ptagof(a2)) {
 case CONS:
  gblt_list(a2,get__unify__struct_6_4);
 get__unify__struct_6_2:
  if (!isint(a0)) goto get__unify__struct_6_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,get__unify__struct_6_4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin__deps_xget__unify__struct_6);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[10] = a0;
  allocp[11] = makeint(1L);
  allocp[12] = x1;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_builtin__deps_xget__unify__deps_7);
  allocp[15] = x3 = makeref(&allocp[15]);
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = a4;
  allocp[19] = x2;
  allocp[20] = NILATOM;
  allocp[21] = x4 = makeref(&allocp[21]);
  allocp[22] = (q)(struct goalrec*)&allocp[13];
  allocp[23] = (q)(&predicate_functor__table_xarg_3);
  allocp[24] = a0;
  allocp[25] = a1;
  allocp[26] = x3;
  qp = (struct goalrec*)&allocp[22];
  allocp += 27;
  proceed();
 get__unify__struct_6_3:
  if (!isref(a0)) goto get__unify__struct_6_4;
  deref_and_jump(a0,get__unify__struct_6_2);
  *reasonp++ =  a0;
  goto get__unify__struct_6_4;
 case VARREF:
  deref_and_jump(a2,get__unify__struct_6_1);
  *reasonp++ =  a2;
  goto get__unify__struct_6_4;
  };
  goto get__unify__struct_6_4;
 get__unify__struct_6_4:
  otherwise(get__unify__struct_6_interrupt);
 get__unify__struct_6_5:
  if (!isint(a0)) goto get__unify__struct_6_7;
  x0 = makeint(0L);
  gblt_greater(a0,x0,get__unify__struct_6_6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin__deps_xget__unify__struct_6);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[10] = a0;
  allocp[11] = makeint(1L);
  allocp[12] = x1;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_builtin__deps_xget__unify__deps_7);
  allocp[15] = x3 = makeref(&allocp[15]);
  allocp[16] = x4 = makeref(&allocp[16]);
  allocp[17] = a3;
  allocp[18] = a4;
  allocp[19] = x2;
  allocp[20] = NILATOM;
  allocp[21] = x5 = makeref(&allocp[21]);
  allocp[22] = (q)(struct goalrec*)&allocp[13];
  allocp[23] = (q)(&predicate_functor__table_xarg_3);
  allocp[24] = a0;
  allocp[25] = a2;
  allocp[26] = x4;
  allocp[27] = (q)(struct goalrec*)&allocp[22];
  allocp[28] = (q)(&predicate_functor__table_xarg_3);
  allocp[29] = a0;
  allocp[30] = a1;
  allocp[31] = x3;
  qp = (struct goalrec*)&allocp[27];
  allocp += 32;
  proceed();
 get__unify__struct_6_6:
  if (a0 != makeint(0L)) goto get__unify__struct_6_interrupt;
  unify(a5, a4);
  proceed();
 get__unify__struct_6_7:
  if (!isref(a0)) goto get__unify__struct_6_interrupt;
  deref_and_jump(a0,get__unify__struct_6_5);
  *reasonp++ =  a0;
  goto get__unify__struct_6_interrupt;
 get__unify__struct_6_ext_interrupt:
  reasonp = 0l;
 get__unify__struct_6_interrupt:
  goto interrupt_6;
 }
 interrupt_11:
  allocp[12] = a10;
 interrupt_10:
  allocp[11] = a9;
 interrupt_9:
  allocp[10] = a8;
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_builtin__deps);
}
