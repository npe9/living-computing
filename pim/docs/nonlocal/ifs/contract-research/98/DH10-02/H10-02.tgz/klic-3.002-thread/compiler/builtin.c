/* Compiled by KLIC compiler version 3.002 (Wed Sep 17 15:37:13 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_builtin();
Const struct predicate predicate_builtin_xmake__typeset_14 =
   { module_builtin, 0, 14 };
Const struct predicate predicate_builtin_xbuiltin__unify_10 =
   { module_builtin, 1, 10 };
Const struct predicate predicate_builtin_xunify__builtin__typeset_11 =
   { module_builtin, 2, 11 };
Const struct predicate predicate_builtin_xupdate__newfunctor_4 =
   { module_builtin, 3, 4 };
Const struct predicate predicate_builtin_xupdate__newfunctor__type_4 =
   { module_builtin, 4, 4 };
Const struct predicate predicate_builtin_xstructname_2 =
   { module_builtin, 5, 2 };
Const struct predicate predicate_builtin_xstructarity_2 =
   { module_builtin, 6, 2 };
Const struct predicate predicate_builtin_xupdate__functor__type_4 =
   { module_builtin, 7, 4 };
Const struct predicate predicate_builtin_xupdate__functor__type_5 =
   { module_builtin, 8, 5 };
Const struct predicate predicate_builtin_xupdate__functor__type_6 =
   { module_builtin, 9, 6 };
Const struct predicate predicate_builtin_xupdate__arg__type_4 =
   { module_builtin, 10, 4 };
Const struct predicate predicate_builtin_xupdate__arg__type1_4 =
   { module_builtin, 11, 4 };
Const struct predicate predicate_builtin_xmerge__arg__type_4 =
   { module_builtin, 12, 4 };
Const struct predicate predicate_builtin_xupdate__setarg_6 =
   { module_builtin, 13, 6 };
Const struct predicate predicate_builtin_xupdate__setarg_8 =
   { module_builtin, 14, 8 };
Const struct predicate predicate_builtin_xupdate__setarg2_6 =
   { module_builtin, 15, 6 };
Const struct predicate predicate_builtin_xupdate__newvector_4 =
   { module_builtin, 16, 4 };
Const struct predicate predicate_builtin_xupdate__newvector_5 =
   { module_builtin, 17, 5 };
Const struct predicate predicate_builtin_xupdate__newvector2_5 =
   { module_builtin, 18, 5 };
Const struct predicate predicate_builtin_xupdate__newvector3_3 =
   { module_builtin, 19, 3 };
Const struct predicate predicate_builtin_xupdate__element__type_4 =
   { module_builtin, 20, 4 };
Const struct predicate predicate_builtin_xupdate__element__type1_4 =
   { module_builtin, 21, 4 };
Const struct predicate predicate_builtin_xmerge__updated__element_4 =
   { module_builtin, 22, 4 };
extern Const struct predicate predicate_print_xdata_1;
extern Const struct predicate predicate_functor_xnew__functor__init_4;
extern Const struct predicate predicate_functor_xcreate__functor_3;
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_xsetarg_4;
extern Const struct predicate predicate_typeset_xunify_8;
extern Const struct predicate predicate_typeset_xget__arg__typeset_5;
extern Const struct predicate predicate_typeset_xset_12;
extern Const struct predicate predicate_typeset_xtypeset2int_2;
extern Const struct predicate predicate_typeset_xtypeset2atom_2;
extern Const struct predicate predicate_typeset_xtypeset2structtype_2;
extern Const struct predicate predicate_typeset_xtypeset2list_2;
extern Const struct predicate predicate_typeset_xvalue2typeset_5;
extern Const struct predicate predicate_typeset_xunify__equal_10;
extern Const struct predicate predicate_typeset_xadd__dgoal_4;
extern Const struct predicate predicate_typeset_xor__typeset_3;
extern Const struct predicate predicate_typeset_xget__struct__arg__typeset_3;
extern Const struct predicate predicate_typeset_xset__struct__arg__typeset_4;
extern Const struct predicate predicate_typeset_xlisttype__val_3;
extern Const struct predicate predicate_atom__table_xmake__atom_2;
extern Const struct predicate predicate_atom__table_xget__atom__string_2;

module module_builtin(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  static Const q cons_const_0[] = {
    NILATOM,
    makesym(atom__2A),
  };
  static Const q funct_const_1[] = {
    makesym(functor_t_2),
    makesym(atom_i),
    NILATOM,
  };
  static Const q cons_const_2[] = {
    NILATOM,
    makefunctor(funct_const_1),
  };
  static Const q funct_const_3[] = {
    makesym(functor_i_1),
    makeint(0),
  };
  static Const q funct_const_4[] = {
    makesym(functor_t_2),
    makefunctor(funct_const_3),
    NILATOM,
  };
  static Const q cons_const_5[] = {
    NILATOM,
    makefunctor(funct_const_4),
  };
  static Const q funct_const_6[] = {
    makesym(functor_s_3),
    makesym(atom___v),
    makesym(atom__2A),
    makecons(cons_const_5),
  };
  static Const q funct_const_7[] = {
    makesym(functor_t_2),
    makefunctor(funct_const_6),
    NILATOM,
  };
  static Const q cons_const_8[] = {
    NILATOM,
    makefunctor(funct_const_7),
  };
  static Const q funct_const_9[] = {
    makesym(functor_i_1),
    makeint(0),
  };
  static Const q funct_const_10[] = {
    makesym(functor_t_2),
    makefunctor(funct_const_9),
    NILATOM,
  };
  static Const q cons_const_11[] = {
    NILATOM,
    makefunctor(funct_const_10),
  };
  static Const q funct_const_12[] = {
    makesym(functor_i_1),
    makeint(0),
  };
  q a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, make__typeset_14_top);
    case_pred(1, builtin__unify_10_top);
    case_pred(2, unify__builtin__typeset_11_top);
    case_pred(3, update__newfunctor_4_top);
    case_pred(4, update__newfunctor__type_4_top);
    case_pred(5, structname_2_top);
    case_pred(6, structarity_2_top);
    case_pred(7, update__functor__type_4_top);
    case_pred(8, update__functor__type_5_top);
    case_pred(9, update__functor__type_6_top);
    case_pred(10, update__arg__type_4_top);
    case_pred(11, update__arg__type1_4_top);
    case_pred(12, merge__arg__type_4_top);
    case_pred(13, update__setarg_6_top);
    case_pred(14, update__setarg_8_top);
    case_pred(15, update__setarg2_6_top);
    case_pred(16, update__newvector_4_top);
    case_pred(17, update__newvector_5_top);
    case_pred(18, update__newvector2_5_top);
    case_pred(19, update__newvector3_3_top);
    case_pred(20, update__element__type_4_top);
    case_pred(21, update__element__type1_4_top);
    last_case_pred(22, merge__updated__element_4_top);
  }

 make__typeset_14_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20, x21, x22, x23, x24, x25, x26, x27, x28, x29, x30, x31, x32, x33, x34;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  qp = qp->next;
 make__typeset_14_clear_reason:
  reasonp = reasons;
 make__typeset_14_0:
 make__typeset_14_1:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (a5 != makesym(atom__3D)) goto make__typeset_14_5;
 make__typeset_14_2:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_3:
  if (a6 != makeint(2L)) goto make__typeset_14_5;
 make__typeset_14_4:
  switch (ptagof(a9)) {
 case ATOMIC:
  if (a9 != makesym(atom_init)) goto make__typeset_14_5;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin_xbuiltin__unify_10);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x0 = makeref(&allocp[6]);
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = a10;
  allocp[9] = a11;
  allocp[10] = a12;
  allocp[11] = a13;
  x2 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  unify_value(a8, x2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x1;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x0;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a9,make__typeset_14_4);
  *reasonp++ =  a9;
  goto make__typeset_14_5;
  };
  goto make__typeset_14_5;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_2);
  *reasonp++ =  a6;
  goto make__typeset_14_5;
  };
  goto make__typeset_14_5;
 case VARREF:
  deref_and_jump(a5,make__typeset_14_1);
  *reasonp++ =  a5;
  goto make__typeset_14_5;
  };
  goto make__typeset_14_5;
 make__typeset_14_5:
  otherwise(make__typeset_14_interrupt);
 make__typeset_14_6:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (isint(a5)) goto make__typeset_14_14;
  switch (symval(a5)) {
 case symval(makesym(atom__3D)):
 make__typeset_14_7:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_8:
  if (a6 != makeint(2L)) goto make__typeset_14_14;
 make__typeset_14_9:
  switch (ptagof(a8)) {
 case ATOMIC:
  if (a8 != makesym(atom_builtin)) goto make__typeset_14_14;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin_xunify__builtin__typeset_11);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a4;
  allocp[5] = a1;
  allocp[6] = a2;
  allocp[7] = a3;
  allocp[8] = a9;
  allocp[9] = a10;
  allocp[10] = a11;
  allocp[11] = a12;
  allocp[12] = a13;
  allocp[13] = (q)(struct goalrec*)&allocp[0];
  allocp[14] = (q)(&predicate_functor__table_xarg_3);
  allocp[15] = makeint(2L);
  allocp[16] = a7;
  allocp[17] = x1;
  allocp[18] = (q)(struct goalrec*)&allocp[13];
  allocp[19] = (q)(&predicate_functor__table_xarg_3);
  allocp[20] = makeint(1L);
  allocp[21] = a7;
  allocp[22] = x0;
  qp = (struct goalrec*)&allocp[18];
  allocp += 23;
  proceed();
 case VARREF:
  deref_and_jump(a8,make__typeset_14_9);
  *reasonp++ =  a8;
  goto make__typeset_14_14;
  };
  goto make__typeset_14_14;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_7);
  *reasonp++ =  a6;
  goto make__typeset_14_14;
  };
  goto make__typeset_14_14;
 case symval(makesym(atom__3D_3D)):
 make__typeset_14_10:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_11:
  if (a6 != makeint(2L)) goto make__typeset_14_14;
 make__typeset_14_12:
  switch (ptagof(a9)) {
 case ATOMIC:
  if (a9 != makesym(atom_init)) goto make__typeset_14_14;
 make__typeset_14_13:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_guard)) goto make__typeset_14_14;
  unify2(a13, a12, a11, a10);
  x0 = makesym(atom_builtin);
  unify_value(a8, x0);
  proceed();
 case VARREF:
  deref_and_jump(a2,make__typeset_14_13);
  *reasonp++ =  a2;
  goto make__typeset_14_14;
  };
  goto make__typeset_14_14;
 case VARREF:
  deref_and_jump(a9,make__typeset_14_12);
  *reasonp++ =  a9;
  goto make__typeset_14_14;
  };
  goto make__typeset_14_14;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_10);
  *reasonp++ =  a6;
  goto make__typeset_14_14;
  };
  goto make__typeset_14_14;
  };
  goto make__typeset_14_14;
 case VARREF:
  deref_and_jump(a5,make__typeset_14_6);
  *reasonp++ =  a5;
  goto make__typeset_14_14;
  };
  goto make__typeset_14_14;
 make__typeset_14_14:
  otherwise(make__typeset_14_interrupt);
 make__typeset_14_15:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (isint(a5)) goto make__typeset_14_55;
  switch (symval(a5)) {
 case symval(makesym(atom__3D_3D)):
 make__typeset_14_16:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_17:
  if (a6 != makeint(2L)) goto make__typeset_14_55;
 make__typeset_14_18:
  switch (ptagof(a8)) {
 case ATOMIC:
  if (a8 != makesym(atom_builtin)) goto make__typeset_14_55;
 make__typeset_14_19:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_guard)) goto make__typeset_14_55;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_typeset_xunify_8);
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = x0;
  allocp[10] = a9;
  allocp[11] = a10;
  allocp[12] = a11;
  allocp[13] = a12;
  allocp[14] = a13;
  allocp[15] = (q)(struct goalrec*)&allocp[5];
  allocp[16] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[17] = a0;
  allocp[18] = a1;
  allocp[19] = x3 = makeref(&allocp[19]);
  allocp[20] = a10;
  allocp[21] = x1;
  allocp[22] = (q)(struct goalrec*)&allocp[15];
  allocp[23] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[24] = a0;
  allocp[25] = a1;
  allocp[26] = x4 = makeref(&allocp[26]);
  allocp[27] = a10;
  allocp[28] = x2;
  allocp[29] = (q)(struct goalrec*)&allocp[22];
  allocp[30] = (q)(&predicate_functor__table_xarg_3);
  allocp[31] = makeint(2L);
  allocp[32] = a7;
  allocp[33] = x4;
  allocp[34] = (q)(struct goalrec*)&allocp[29];
  allocp[35] = (q)(&predicate_functor__table_xarg_3);
  allocp[36] = makeint(1L);
  allocp[37] = a7;
  allocp[38] = x3;
  qp = (struct goalrec*)&allocp[34];
  allocp += 39;
  proceed();
 case VARREF:
  deref_and_jump(a2,make__typeset_14_19);
  *reasonp++ =  a2;
  goto make__typeset_14_55;
  };
  goto make__typeset_14_55;
 case VARREF:
  deref_and_jump(a8,make__typeset_14_18);
  *reasonp++ =  a8;
  goto make__typeset_14_55;
  };
  goto make__typeset_14_55;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_16);
  *reasonp++ =  a6;
  goto make__typeset_14_55;
  };
  goto make__typeset_14_55;
 case symval(makesym(atom_wait)):
 make__typeset_14_20:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_21:
  if (a6 != makeint(1L)) goto make__typeset_14_55;
 make__typeset_14_22:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_guard)) goto make__typeset_14_55;
  unify2(a13, a12, a11, a10);
  x0 = makesym(atom_builtin);
  unify_value(a8, x0);
  proceed();
 case VARREF:
  deref_and_jump(a2,make__typeset_14_22);
  *reasonp++ =  a2;
  goto make__typeset_14_55;
  };
  goto make__typeset_14_55;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_20);
  *reasonp++ =  a6;
  goto make__typeset_14_55;
  };
  goto make__typeset_14_55;
 case symval(makesym(atom_compare)):
 make__typeset_14_23:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_24:
  if (a6 != makeint(3L)) goto make__typeset_14_55;
 make__typeset_14_25:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_guard)) goto make__typeset_14_55;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_i);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case VARREF:
  deref_and_jump(a2,make__typeset_14_25);
  *reasonp++ =  a2;
  goto make__typeset_14_55;
  };
  goto make__typeset_14_55;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_23);
  *reasonp++ =  a6;
  goto make__typeset_14_55;
  };
  goto make__typeset_14_55;
 case symval(makesym(atom_diff)):
 make__typeset_14_26:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_27:
  if (a6 != makeint(2L)) goto make__typeset_14_55;
 make__typeset_14_28:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_guard)) goto make__typeset_14_55;
  unify2(a13, a12, a11, a10);
  x0 = makesym(atom_builtin);
  unify_value(a8, x0);
  proceed();
 case VARREF:
  deref_and_jump(a2,make__typeset_14_28);
  *reasonp++ =  a2;
  goto make__typeset_14_55;
  };
  goto make__typeset_14_55;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_26);
  *reasonp++ =  a6;
  goto make__typeset_14_55;
  };
  goto make__typeset_14_55;
 case symval(makesym(atom_hash)):
 make__typeset_14_29:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_30:
  if (a6 != makeint(2L)) goto make__typeset_14_55;
 make__typeset_14_31:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_guard)) goto make__typeset_14_55;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_i);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case VARREF:
  deref_and_jump(a2,make__typeset_14_31);
  *reasonp++ =  a2;
  goto make__typeset_14_55;
  };
  goto make__typeset_14_55;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_29);
  *reasonp++ =  a6;
  goto make__typeset_14_55;
  };
  goto make__typeset_14_55;
 case symval(makesym(atom_current__priority)):
 make__typeset_14_32:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_33:
  if (a6 != makeint(1L)) goto make__typeset_14_55;
 make__typeset_14_34:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_guard)) goto make__typeset_14_55;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_i);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(1L);
  allocp[3] = a7;
  allocp[4] = x4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case VARREF:
  deref_and_jump(a2,make__typeset_14_34);
  *reasonp++ =  a2;
  goto make__typeset_14_55;
  };
  goto make__typeset_14_55;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_32);
  *reasonp++ =  a6;
  goto make__typeset_14_55;
  };
  goto make__typeset_14_55;
 case symval(makesym(atom_current__node)):
 make__typeset_14_35:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_36:
  if (a6 != makeint(2L)) goto make__typeset_14_55;
 make__typeset_14_37:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_body)) goto make__typeset_14_55;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_i);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = x5 = makeref(&allocp[22]);
  allocp[23] = a11;
  allocp[24] = x6 = makeref(&allocp[24]);
  allocp[25] = a13;
  allocp[26] = makesym(functor_goal_4);
  allocp[27] = a0;
  allocp[28] = a1;
  allocp[29] = a2;
  allocp[30] = a3;
  x7 = makefunctor(&allocp[26]);
  allocp[31] = NILATOM;
  allocp[32] = x7;
  x8 = makecons(&allocp[31]);
  allocp[33] = makesym(functor_t_2);
  allocp[34] = makesym(atom_i);
  allocp[35] = x8;
  x9 = makefunctor(&allocp[33]);
  allocp[36] = NILATOM;
  allocp[37] = x9;
  x10 = makecons(&allocp[36]);
  allocp[38] = (q)(struct goalrec*)&allocp[12];
  allocp[39] = (q)(&predicate_typeset_xset_12);
  allocp[40] = a0;
  allocp[41] = a1;
  allocp[42] = a2;
  allocp[43] = a3;
  allocp[44] = x11 = makeref(&allocp[44]);
  allocp[45] = makesym(atom___);
  allocp[46] = x10;
  allocp[47] = makesym(atom_normal);
  allocp[48] = a10;
  allocp[49] = x5;
  allocp[50] = a12;
  allocp[51] = x6;
  x12 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[38];
  allocp += 52;
  unify_value(a8, x12);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x11;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a2,make__typeset_14_37);
  *reasonp++ =  a2;
  goto make__typeset_14_55;
  };
  goto make__typeset_14_55;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_35);
  *reasonp++ =  a6;
  goto make__typeset_14_55;
  };
  goto make__typeset_14_55;
 case symval(makesym(atom_unbound)):
 make__typeset_14_38:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_39:
  if (a6 != makeint(2L)) goto make__typeset_14_55;
 make__typeset_14_40:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_body)) goto make__typeset_14_55;
 make__typeset_14_41:
  if (isref(a7)) goto make__typeset_14_43;
  x1 = makeint(1L);
  gblt_arg(x1,a7,x0,make__typeset_14_55);
  x3 = makeint(2L);
  gblt_arg(x3,a7,x2,make__typeset_14_55);
 make__typeset_14_42:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_variable_3)) goto make__typeset_14_55;
  x4 = makesym(atom_builtin);
  unify_value(a8, x4);
  allocp[0] = makesym(functor_v_4);
  allocp[1] = a0;
  allocp[2] = a1;
  x6 = arg(x0, 0);
  allocp[3] = x6;
  x7 = arg(x0, 1);
  allocp[4] = x7;
  x5 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_tv_2);
  allocp[6] = x5;
  allocp[7] = NILATOM;
  x8 = makefunctor(&allocp[5]);
  allocp[8] = NILATOM;
  allocp[9] = x8;
  x9 = makecons(&allocp[8]);
  allocp[10] = makesym(functor_args_1);
  allocp[11] = x9;
  x10 = makefunctor(&allocp[10]);
  allocp[12] = makesym(functor_s_3);
  allocp[13] = makesym(atom___v);
  allocp[14] = makeint(1L);
  allocp[15] = x10;
  x11 = makefunctor(&allocp[12]);
  allocp[16] = makesym(functor_goal_4);
  allocp[17] = a0;
  allocp[18] = a1;
  allocp[19] = a2;
  allocp[20] = a3;
  x12 = makefunctor(&allocp[16]);
  allocp[21] = NILATOM;
  allocp[22] = x12;
  x13 = makecons(&allocp[21]);
  allocp[23] = makesym(functor_t_2);
  allocp[24] = x11;
  allocp[25] = x13;
  x14 = makefunctor(&allocp[23]);
  allocp[26] = makesym(functor_goal_4);
  allocp[27] = a0;
  allocp[28] = a1;
  allocp[29] = a2;
  allocp[30] = a3;
  x15 = makefunctor(&allocp[26]);
  allocp[31] = NILATOM;
  allocp[32] = x15;
  x16 = makecons(&allocp[31]);
  allocp[33] = makesym(functor_t_2);
  allocp[34] = makesym(atom_i);
  allocp[35] = x16;
  x17 = makefunctor(&allocp[33]);
  allocp[36] = NILATOM;
  allocp[37] = x17;
  x18 = makecons(&allocp[36]);
  allocp[38] = makesym(functor_goal_4);
  allocp[39] = a0;
  allocp[40] = a1;
  allocp[41] = a2;
  allocp[42] = a3;
  x19 = makefunctor(&allocp[38]);
  allocp[43] = NILATOM;
  allocp[44] = x19;
  x20 = makecons(&allocp[43]);
  allocp[45] = makesym(functor_t_2);
  allocp[46] = makesym(atom_i);
  allocp[47] = x20;
  x21 = makefunctor(&allocp[45]);
  allocp[48] = NILATOM;
  allocp[49] = x21;
  x22 = makecons(&allocp[48]);
  allocp[50] = makesym(functor_v_4);
  allocp[51] = a0;
  allocp[52] = a1;
  x24 = arg(x0, 0);
  allocp[53] = x24;
  x25 = arg(x0, 1);
  allocp[54] = x25;
  x23 = makefunctor(&allocp[50]);
  allocp[55] = makesym(functor_tv_2);
  allocp[56] = x23;
  allocp[57] = NILATOM;
  x26 = makefunctor(&allocp[55]);
  allocp[58] = NILATOM;
  allocp[59] = x26;
  x27 = makecons(&allocp[58]);
  allocp[60] = makesym(functor_args_3);
  allocp[61] = x18;
  allocp[62] = x22;
  allocp[63] = x27;
  x28 = makefunctor(&allocp[60]);
  allocp[64] = makesym(functor_s_3);
  allocp[65] = makesym(atom___v);
  allocp[66] = makeint(3L);
  allocp[67] = x28;
  x29 = makefunctor(&allocp[64]);
  allocp[68] = makesym(functor_goal_4);
  allocp[69] = a0;
  allocp[70] = a1;
  allocp[71] = a2;
  allocp[72] = a3;
  x30 = makefunctor(&allocp[68]);
  allocp[73] = NILATOM;
  allocp[74] = x30;
  x31 = makecons(&allocp[73]);
  allocp[75] = makesym(functor_t_2);
  allocp[76] = x29;
  allocp[77] = x31;
  x32 = makefunctor(&allocp[75]);
  allocp[78] = NILATOM;
  allocp[79] = x32;
  x33 = makecons(&allocp[78]);
  allocp[80] = x33;
  allocp[81] = x14;
  x34 = makecons(&allocp[80]);
  allocp[82] = (q)qp;
  allocp[83] = (q)(&predicate_typeset_xset_12);
  allocp[84] = a0;
  allocp[85] = a1;
  allocp[86] = a2;
  allocp[87] = a3;
  allocp[88] = x2;
  allocp[89] = makesym(atom___);
  allocp[90] = x34;
  allocp[91] = makesym(atom_normal);
  allocp[92] = a10;
  allocp[93] = a11;
  allocp[94] = a12;
  allocp[95] = a13;
  qp = (struct goalrec*)&allocp[82];
  allocp += 96;
  proceed();
 case VARREF:
  deref_and_jump(x0,make__typeset_14_42);
  *reasonp++ =  x0;
  goto make__typeset_14_55;
  };
  goto make__typeset_14_55;
 make__typeset_14_43:
  deref_and_jump(a7,make__typeset_14_41);
  *reasonp++ =  a7;
  goto make__typeset_14_55;
 case VARREF:
  deref_and_jump(a2,make__typeset_14_40);
  *reasonp++ =  a2;
  goto make__typeset_14_55;
  };
  goto make__typeset_14_55;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_38);
  *reasonp++ =  a6;
  goto make__typeset_14_55;
  };
  goto make__typeset_14_55;
 case symval(makesym(atom_atomic)):
 make__typeset_14_44:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_45:
  if (a6 != makeint(1L)) goto make__typeset_14_55;
 make__typeset_14_46:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_guard)) goto make__typeset_14_55;
  unify2(a13, a12, a11, a10);
  x0 = makesym(atom_builtin);
  unify_value(a8, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(1L);
  allocp[3] = a7;
  allocp[4] = x1 = makeref(&allocp[4]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case VARREF:
  deref_and_jump(a2,make__typeset_14_46);
  *reasonp++ =  a2;
  goto make__typeset_14_55;
  };
  goto make__typeset_14_55;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_44);
  *reasonp++ =  a6;
  goto make__typeset_14_55;
  };
  goto make__typeset_14_55;
 case symval(makesym(atom_atom)):
 make__typeset_14_47:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_48:
  if (a6 != makeint(1L)) goto make__typeset_14_55;
 make__typeset_14_49:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_guard)) goto make__typeset_14_55;
  unify2(a13, a12, a11, a10);
  x0 = makesym(atom_builtin);
  unify_value(a8, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(1L);
  allocp[3] = a7;
  allocp[4] = x1 = makeref(&allocp[4]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case VARREF:
  deref_and_jump(a2,make__typeset_14_49);
  *reasonp++ =  a2;
  goto make__typeset_14_55;
  };
  goto make__typeset_14_55;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_47);
  *reasonp++ =  a6;
  goto make__typeset_14_55;
  };
  goto make__typeset_14_55;
 case symval(makesym(atom_make__atom)):
 make__typeset_14_50:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_51:
  if (a6 != makeint(2L)) goto make__typeset_14_55;
 make__typeset_14_52:
  if (isref(a7)) goto make__typeset_14_54;
  x1 = makeint(1L);
  gblt_arg(x1,a7,x0,make__typeset_14_55);
  x3 = makeint(1L);
  gblt_arg(x3,a7,x2,make__typeset_14_55);
 make__typeset_14_53:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_string_1)) goto make__typeset_14_55;
  x4 = makesym(atom_builtin);
  unify_value(a8, x4);
  allocp[0] = makesym(functor_a_1);
  allocp[1] = x6 = makeref(&allocp[1]);
  x5 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_goal_4);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  x7 = makefunctor(&allocp[2]);
  allocp[7] = NILATOM;
  allocp[8] = x7;
  x8 = makecons(&allocp[7]);
  allocp[9] = makesym(functor_t_2);
  allocp[10] = x5;
  allocp[11] = x8;
  x9 = makefunctor(&allocp[9]);
  allocp[12] = NILATOM;
  allocp[13] = x9;
  x10 = makecons(&allocp[12]);
  allocp[14] = (q)qp;
  allocp[15] = (q)(&predicate_typeset_xset_12);
  allocp[16] = a0;
  allocp[17] = a1;
  allocp[18] = a2;
  allocp[19] = a3;
  allocp[20] = x2;
  allocp[21] = makesym(atom___);
  allocp[22] = x10;
  allocp[23] = makesym(atom_normal);
  allocp[24] = a10;
  allocp[25] = a11;
  allocp[26] = a12;
  allocp[27] = a13;
  allocp[28] = (q)(struct goalrec*)&allocp[14];
  allocp[29] = (q)(&predicate_atom__table_xmake__atom_2);
  x11 = arg(x2, 0);
  allocp[30] = x11;
  allocp[31] = x6;
  qp = (struct goalrec*)&allocp[28];
  allocp += 32;
  proceed();
 case VARREF:
  deref_and_jump(x2,make__typeset_14_53);
  *reasonp++ =  x2;
  goto make__typeset_14_55;
  };
  goto make__typeset_14_55;
 make__typeset_14_54:
  deref_and_jump(a7,make__typeset_14_52);
  *reasonp++ =  a7;
  goto make__typeset_14_55;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_50);
  *reasonp++ =  a6;
  goto make__typeset_14_55;
  };
  goto make__typeset_14_55;
  };
  goto make__typeset_14_55;
 case VARREF:
  deref_and_jump(a5,make__typeset_14_15);
  *reasonp++ =  a5;
  goto make__typeset_14_55;
  };
  goto make__typeset_14_55;
 make__typeset_14_55:
  otherwise(make__typeset_14_interrupt);
 make__typeset_14_56:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (isint(a5)) goto make__typeset_14_66;
  switch (symval(a5)) {
 case symval(makesym(atom_make__atom)):
 make__typeset_14_57:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_58:
  if (a6 != makeint(2L)) goto make__typeset_14_66;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_a);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x6 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_57);
  *reasonp++ =  a6;
  goto make__typeset_14_66;
  };
  goto make__typeset_14_66;
 case symval(makesym(atom_atom__number)):
 make__typeset_14_59:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_60:
  if (a6 != makeint(2L)) goto make__typeset_14_66;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_i);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x6 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_59);
  *reasonp++ =  a6;
  goto make__typeset_14_66;
  };
  goto make__typeset_14_66;
 case symval(makesym(atom_get__atom__string)):
 make__typeset_14_61:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_62:
  if (a6 != makeint(2L)) goto make__typeset_14_66;
 make__typeset_14_63:
  if (isref(a7)) goto make__typeset_14_65;
  x1 = makeint(1L);
  gblt_arg(x1,a7,x0,make__typeset_14_66);
  x3 = makeint(2L);
  gblt_arg(x3,a7,x2,make__typeset_14_66);
 make__typeset_14_64:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_atom_1)) goto make__typeset_14_66;
  x4 = makesym(atom_builtin);
  unify_value(a8, x4);
  allocp[0] = makesym(functor_c_1);
  allocp[1] = x6 = makeref(&allocp[1]);
  x5 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_goal_4);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  x7 = makefunctor(&allocp[2]);
  allocp[7] = NILATOM;
  allocp[8] = x7;
  x8 = makecons(&allocp[7]);
  allocp[9] = makesym(functor_t_2);
  allocp[10] = x5;
  allocp[11] = x8;
  x9 = makefunctor(&allocp[9]);
  allocp[12] = NILATOM;
  allocp[13] = x9;
  x10 = makecons(&allocp[12]);
  allocp[14] = (q)qp;
  allocp[15] = (q)(&predicate_typeset_xset_12);
  allocp[16] = a0;
  allocp[17] = a1;
  allocp[18] = a2;
  allocp[19] = a3;
  allocp[20] = x2;
  allocp[21] = makesym(atom___);
  allocp[22] = x10;
  allocp[23] = makesym(atom_normal);
  allocp[24] = a10;
  allocp[25] = a11;
  allocp[26] = a12;
  allocp[27] = a13;
  allocp[28] = (q)(struct goalrec*)&allocp[14];
  allocp[29] = (q)(&predicate_atom__table_xget__atom__string_2);
  x11 = arg(x0, 0);
  allocp[30] = x11;
  allocp[31] = x6;
  qp = (struct goalrec*)&allocp[28];
  allocp += 32;
  proceed();
 case VARREF:
  deref_and_jump(x0,make__typeset_14_64);
  *reasonp++ =  x0;
  goto make__typeset_14_66;
  };
  goto make__typeset_14_66;
 make__typeset_14_65:
  deref_and_jump(a7,make__typeset_14_63);
  *reasonp++ =  a7;
  goto make__typeset_14_66;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_61);
  *reasonp++ =  a6;
  goto make__typeset_14_66;
  };
  goto make__typeset_14_66;
  };
  goto make__typeset_14_66;
 case VARREF:
  deref_and_jump(a5,make__typeset_14_56);
  *reasonp++ =  a5;
  goto make__typeset_14_66;
  };
  goto make__typeset_14_66;
 make__typeset_14_66:
  otherwise(make__typeset_14_interrupt);
 make__typeset_14_67:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (isint(a5)) goto make__typeset_14_75;
  switch (symval(a5)) {
 case symval(makesym(atom_get__atom__string)):
 make__typeset_14_68:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_69:
  if (a6 != makeint(2L)) goto make__typeset_14_75;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_c);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x6 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_68);
  *reasonp++ =  a6;
  goto make__typeset_14_75;
  };
  goto make__typeset_14_75;
 case symval(makesym(atom_intern)):
 make__typeset_14_70:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_71:
  if (a6 != makeint(2L)) goto make__typeset_14_75;
 make__typeset_14_72:
  if (isref(a7)) goto make__typeset_14_74;
  x1 = makeint(1L);
  gblt_arg(x1,a7,x0,make__typeset_14_75);
  x3 = makeint(2L);
  gblt_arg(x3,a7,x2,make__typeset_14_75);
 make__typeset_14_73:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_string_1)) goto make__typeset_14_75;
  x4 = makesym(atom_builtin);
  unify_value(a8, x4);
  allocp[0] = makesym(functor_a_1);
  allocp[1] = x6 = makeref(&allocp[1]);
  x5 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_goal_4);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  x7 = makefunctor(&allocp[2]);
  allocp[7] = NILATOM;
  allocp[8] = x7;
  x8 = makecons(&allocp[7]);
  allocp[9] = makesym(functor_t_2);
  allocp[10] = x5;
  allocp[11] = x8;
  x9 = makefunctor(&allocp[9]);
  allocp[12] = NILATOM;
  allocp[13] = x9;
  x10 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_args_1);
  allocp[15] = x10;
  x11 = makefunctor(&allocp[14]);
  allocp[16] = makesym(functor_s_3);
  allocp[17] = makesym(atom_normal);
  allocp[18] = makeint(1L);
  allocp[19] = x11;
  x12 = makefunctor(&allocp[16]);
  allocp[20] = makesym(functor_goal_4);
  allocp[21] = a0;
  allocp[22] = a1;
  allocp[23] = a2;
  allocp[24] = a3;
  x13 = makefunctor(&allocp[20]);
  allocp[25] = NILATOM;
  allocp[26] = x13;
  x14 = makecons(&allocp[25]);
  allocp[27] = makesym(functor_t_2);
  allocp[28] = x12;
  allocp[29] = x14;
  x15 = makefunctor(&allocp[27]);
  allocp[30] = NILATOM;
  allocp[31] = x15;
  x16 = makecons(&allocp[30]);
  allocp[32] = (q)qp;
  allocp[33] = (q)(&predicate_typeset_xset_12);
  allocp[34] = a0;
  allocp[35] = a1;
  allocp[36] = a2;
  allocp[37] = a3;
  allocp[38] = x2;
  allocp[39] = makesym(atom___);
  allocp[40] = x16;
  allocp[41] = makesym(atom_normal);
  allocp[42] = a10;
  allocp[43] = a11;
  allocp[44] = a12;
  allocp[45] = a13;
  allocp[46] = (q)(struct goalrec*)&allocp[32];
  allocp[47] = (q)(&predicate_atom__table_xmake__atom_2);
  x17 = arg(x0, 0);
  allocp[48] = x17;
  allocp[49] = x6;
  qp = (struct goalrec*)&allocp[46];
  allocp += 50;
  proceed();
 case VARREF:
  deref_and_jump(x0,make__typeset_14_73);
  *reasonp++ =  x0;
  goto make__typeset_14_75;
  };
  goto make__typeset_14_75;
 make__typeset_14_74:
  deref_and_jump(a7,make__typeset_14_72);
  *reasonp++ =  a7;
  goto make__typeset_14_75;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_70);
  *reasonp++ =  a6;
  goto make__typeset_14_75;
  };
  goto make__typeset_14_75;
  };
  goto make__typeset_14_75;
 case VARREF:
  deref_and_jump(a5,make__typeset_14_67);
  *reasonp++ =  a5;
  goto make__typeset_14_75;
  };
  goto make__typeset_14_75;
 make__typeset_14_75:
  otherwise(make__typeset_14_interrupt);
 make__typeset_14_76:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (isint(a5)) goto make__typeset_14_84;
  switch (symval(a5)) {
 case symval(makesym(atom_intern)):
 make__typeset_14_77:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_78:
  if (a6 != makeint(2L)) goto make__typeset_14_84;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_a);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = makesym(functor_args_1);
  allocp[13] = x3;
  x4 = makefunctor(&allocp[12]);
  allocp[14] = makesym(functor_s_3);
  allocp[15] = makesym(atom_normal);
  allocp[16] = makeint(1L);
  allocp[17] = x4;
  x5 = makefunctor(&allocp[14]);
  allocp[18] = makesym(functor_goal_4);
  allocp[19] = a0;
  allocp[20] = a1;
  allocp[21] = a2;
  allocp[22] = a3;
  x6 = makefunctor(&allocp[18]);
  allocp[23] = NILATOM;
  allocp[24] = x6;
  x7 = makecons(&allocp[23]);
  allocp[25] = makesym(functor_t_2);
  allocp[26] = x5;
  allocp[27] = x7;
  x8 = makefunctor(&allocp[25]);
  allocp[28] = NILATOM;
  allocp[29] = x8;
  x9 = makecons(&allocp[28]);
  allocp[30] = (q)qp;
  allocp[31] = (q)(&predicate_typeset_xset_12);
  allocp[32] = a0;
  allocp[33] = a1;
  allocp[34] = a2;
  allocp[35] = a3;
  allocp[36] = x10 = makeref(&allocp[36]);
  allocp[37] = makesym(atom___);
  allocp[38] = x9;
  allocp[39] = makesym(atom_normal);
  allocp[40] = a10;
  allocp[41] = a11;
  allocp[42] = a12;
  allocp[43] = a13;
  x11 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[30];
  allocp += 44;
  unify_value(a8, x11);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x10;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x12 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_77);
  *reasonp++ =  a6;
  goto make__typeset_14_84;
  };
  goto make__typeset_14_84;
 case symval(makesym(atom_get__atom__name)):
 make__typeset_14_79:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_80:
  if (a6 != makeint(2L)) goto make__typeset_14_84;
 make__typeset_14_81:
  if (isref(a7)) goto make__typeset_14_83;
  x1 = makeint(1L);
  gblt_arg(x1,a7,x0,make__typeset_14_84);
  x3 = makeint(2L);
  gblt_arg(x3,a7,x2,make__typeset_14_84);
 make__typeset_14_82:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_atom_1)) goto make__typeset_14_84;
  x4 = makesym(atom_builtin);
  unify_value(a8, x4);
  allocp[0] = makesym(functor_c_1);
  allocp[1] = x6 = makeref(&allocp[1]);
  x5 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_goal_4);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  x7 = makefunctor(&allocp[2]);
  allocp[7] = NILATOM;
  allocp[8] = x7;
  x8 = makecons(&allocp[7]);
  allocp[9] = makesym(functor_t_2);
  allocp[10] = x5;
  allocp[11] = x8;
  x9 = makefunctor(&allocp[9]);
  allocp[12] = NILATOM;
  allocp[13] = x9;
  x10 = makecons(&allocp[12]);
  allocp[14] = makesym(functor_args_1);
  allocp[15] = x10;
  x11 = makefunctor(&allocp[14]);
  allocp[16] = makesym(functor_s_3);
  allocp[17] = makesym(atom_normal);
  allocp[18] = makeint(1L);
  allocp[19] = x11;
  x12 = makefunctor(&allocp[16]);
  allocp[20] = makesym(functor_goal_4);
  allocp[21] = a0;
  allocp[22] = a1;
  allocp[23] = a2;
  allocp[24] = a3;
  x13 = makefunctor(&allocp[20]);
  allocp[25] = NILATOM;
  allocp[26] = x13;
  x14 = makecons(&allocp[25]);
  allocp[27] = makesym(functor_t_2);
  allocp[28] = x12;
  allocp[29] = x14;
  x15 = makefunctor(&allocp[27]);
  allocp[30] = NILATOM;
  allocp[31] = x15;
  x16 = makecons(&allocp[30]);
  allocp[32] = (q)qp;
  allocp[33] = (q)(&predicate_typeset_xset_12);
  allocp[34] = a0;
  allocp[35] = a1;
  allocp[36] = a2;
  allocp[37] = a3;
  allocp[38] = x2;
  allocp[39] = makesym(atom___);
  allocp[40] = x16;
  allocp[41] = makesym(atom_normal);
  allocp[42] = a10;
  allocp[43] = a11;
  allocp[44] = a12;
  allocp[45] = a13;
  allocp[46] = (q)(struct goalrec*)&allocp[32];
  allocp[47] = (q)(&predicate_atom__table_xget__atom__string_2);
  x17 = arg(x0, 0);
  allocp[48] = x17;
  allocp[49] = x6;
  qp = (struct goalrec*)&allocp[46];
  allocp += 50;
  proceed();
 case VARREF:
  deref_and_jump(x0,make__typeset_14_82);
  *reasonp++ =  x0;
  goto make__typeset_14_84;
  };
  goto make__typeset_14_84;
 make__typeset_14_83:
  deref_and_jump(a7,make__typeset_14_81);
  *reasonp++ =  a7;
  goto make__typeset_14_84;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_79);
  *reasonp++ =  a6;
  goto make__typeset_14_84;
  };
  goto make__typeset_14_84;
  };
  goto make__typeset_14_84;
 case VARREF:
  deref_and_jump(a5,make__typeset_14_76);
  *reasonp++ =  a5;
  goto make__typeset_14_84;
  };
  goto make__typeset_14_84;
 make__typeset_14_84:
  otherwise(make__typeset_14_interrupt);
 make__typeset_14_85:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (isint(a5)) goto make__typeset_14_159;
  switch (symval(a5)) {
 case symval(makesym(atom_get__atom__name)):
 make__typeset_14_86:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_87:
  if (a6 != makeint(2L)) goto make__typeset_14_159;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_c);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = makesym(functor_args_1);
  allocp[13] = x3;
  x4 = makefunctor(&allocp[12]);
  allocp[14] = makesym(functor_s_3);
  allocp[15] = makesym(atom_normal);
  allocp[16] = makeint(1L);
  allocp[17] = x4;
  x5 = makefunctor(&allocp[14]);
  allocp[18] = makesym(functor_goal_4);
  allocp[19] = a0;
  allocp[20] = a1;
  allocp[21] = a2;
  allocp[22] = a3;
  x6 = makefunctor(&allocp[18]);
  allocp[23] = NILATOM;
  allocp[24] = x6;
  x7 = makecons(&allocp[23]);
  allocp[25] = makesym(functor_t_2);
  allocp[26] = x5;
  allocp[27] = x7;
  x8 = makefunctor(&allocp[25]);
  allocp[28] = NILATOM;
  allocp[29] = x8;
  x9 = makecons(&allocp[28]);
  allocp[30] = (q)qp;
  allocp[31] = (q)(&predicate_typeset_xset_12);
  allocp[32] = a0;
  allocp[33] = a1;
  allocp[34] = a2;
  allocp[35] = a3;
  allocp[36] = x10 = makeref(&allocp[36]);
  allocp[37] = makesym(atom___);
  allocp[38] = x9;
  allocp[39] = makesym(atom_normal);
  allocp[40] = a10;
  allocp[41] = a11;
  allocp[42] = a12;
  allocp[43] = a13;
  x11 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[30];
  allocp += 44;
  unify_value(a8, x11);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x10;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x12 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_86);
  *reasonp++ =  a6;
  goto make__typeset_14_159;
  };
  goto make__typeset_14_159;
 case symval(makesym(atom_integer)):
 make__typeset_14_88:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_89:
  if (a6 != makeint(1L)) goto make__typeset_14_159;
 make__typeset_14_90:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_guard)) goto make__typeset_14_159;
  unify2(a13, a12, a11, a10);
  x0 = makesym(atom_builtin);
  unify_value(a8, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(1L);
  allocp[3] = a7;
  allocp[4] = x1 = makeref(&allocp[4]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case VARREF:
  deref_and_jump(a2,make__typeset_14_90);
  *reasonp++ =  a2;
  goto make__typeset_14_159;
  };
  goto make__typeset_14_159;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_88);
  *reasonp++ =  a6;
  goto make__typeset_14_159;
  };
  goto make__typeset_14_159;
 case symval(makesym(atom_add)):
 make__typeset_14_91:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_92:
  if (a6 != makeint(3L)) goto make__typeset_14_159;
 make__typeset_14_93:
  if (isref(a0)) goto make__typeset_14_96;
 make__typeset_14_94:
  if (isref(a0)) goto make__typeset_14_95;
  if_not_equal(a0, a4, make__typeset_14_159);
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_i);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x7 = makeref(&allocp[14]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 make__typeset_14_95:
  deref_and_jump(a0,make__typeset_14_94);
  *reasonp++ =  a0;
  goto make__typeset_14_159;
 make__typeset_14_96:
  deref_and_jump(a0,make__typeset_14_93);
  *reasonp++ =  a0;
  goto make__typeset_14_159;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_91);
  *reasonp++ =  a6;
  goto make__typeset_14_159;
  };
  goto make__typeset_14_159;
 case symval(makesym(atom_plus)):
 make__typeset_14_97:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_98:
  if (a6 != makeint(2L)) goto make__typeset_14_159;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_i);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x6 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_97);
  *reasonp++ =  a6;
  goto make__typeset_14_159;
  };
  goto make__typeset_14_159;
 case symval(makesym(atom_subtract)):
 make__typeset_14_99:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_100:
  if (a6 != makeint(3L)) goto make__typeset_14_159;
 make__typeset_14_101:
  if (isref(a0)) goto make__typeset_14_104;
 make__typeset_14_102:
  if (isref(a0)) goto make__typeset_14_103;
  if_not_equal(a0, a4, make__typeset_14_159);
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_i);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x7 = makeref(&allocp[14]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 make__typeset_14_103:
  deref_and_jump(a0,make__typeset_14_102);
  *reasonp++ =  a0;
  goto make__typeset_14_159;
 make__typeset_14_104:
  deref_and_jump(a0,make__typeset_14_101);
  *reasonp++ =  a0;
  goto make__typeset_14_159;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_99);
  *reasonp++ =  a6;
  goto make__typeset_14_159;
  };
  goto make__typeset_14_159;
 case symval(makesym(atom_minus)):
 make__typeset_14_105:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_106:
  if (a6 != makeint(2L)) goto make__typeset_14_159;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_i);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x6 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_105);
  *reasonp++ =  a6;
  goto make__typeset_14_159;
  };
  goto make__typeset_14_159;
 case symval(makesym(atom_multiply)):
 make__typeset_14_107:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_108:
  if (a6 != makeint(3L)) goto make__typeset_14_159;
 make__typeset_14_109:
  if (isref(a0)) goto make__typeset_14_112;
 make__typeset_14_110:
  if (isref(a0)) goto make__typeset_14_111;
  if_not_equal(a0, a4, make__typeset_14_159);
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_i);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x7 = makeref(&allocp[14]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 make__typeset_14_111:
  deref_and_jump(a0,make__typeset_14_110);
  *reasonp++ =  a0;
  goto make__typeset_14_159;
 make__typeset_14_112:
  deref_and_jump(a0,make__typeset_14_109);
  *reasonp++ =  a0;
  goto make__typeset_14_159;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_107);
  *reasonp++ =  a6;
  goto make__typeset_14_159;
  };
  goto make__typeset_14_159;
 case symval(makesym(atom_divide)):
 make__typeset_14_113:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_114:
  if (a6 != makeint(3L)) goto make__typeset_14_159;
 make__typeset_14_115:
  if (isref(a0)) goto make__typeset_14_118;
 make__typeset_14_116:
  if (isref(a0)) goto make__typeset_14_117;
  if_not_equal(a0, a4, make__typeset_14_159);
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_i);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x7 = makeref(&allocp[14]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 make__typeset_14_117:
  deref_and_jump(a0,make__typeset_14_116);
  *reasonp++ =  a0;
  goto make__typeset_14_159;
 make__typeset_14_118:
  deref_and_jump(a0,make__typeset_14_115);
  *reasonp++ =  a0;
  goto make__typeset_14_159;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_113);
  *reasonp++ =  a6;
  goto make__typeset_14_159;
  };
  goto make__typeset_14_159;
 case symval(makesym(atom_modulo)):
 make__typeset_14_119:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_120:
  if (a6 != makeint(3L)) goto make__typeset_14_159;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_i);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x7 = makeref(&allocp[14]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_119);
  *reasonp++ =  a6;
  goto make__typeset_14_159;
  };
  goto make__typeset_14_159;
 case symval(makesym(atom_complement)):
 make__typeset_14_121:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_122:
  if (a6 != makeint(2L)) goto make__typeset_14_159;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_i);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x6 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_121);
  *reasonp++ =  a6;
  goto make__typeset_14_159;
  };
  goto make__typeset_14_159;
 case symval(makesym(atom_and)):
 make__typeset_14_123:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_124:
  if (a6 != makeint(3L)) goto make__typeset_14_159;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_i);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x7 = makeref(&allocp[14]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_123);
  *reasonp++ =  a6;
  goto make__typeset_14_159;
  };
  goto make__typeset_14_159;
 case symval(makesym(atom_or)):
 make__typeset_14_125:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_126:
  if (a6 != makeint(3L)) goto make__typeset_14_159;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_i);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x7 = makeref(&allocp[14]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_125);
  *reasonp++ =  a6;
  goto make__typeset_14_159;
  };
  goto make__typeset_14_159;
 case symval(makesym(atom_exclusive__or)):
 make__typeset_14_127:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_128:
  if (a6 != makeint(3L)) goto make__typeset_14_159;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_i);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x7 = makeref(&allocp[14]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_127);
  *reasonp++ =  a6;
  goto make__typeset_14_159;
  };
  goto make__typeset_14_159;
 case symval(makesym(atom_shift__left)):
 make__typeset_14_129:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_130:
  if (a6 != makeint(3L)) goto make__typeset_14_159;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_i);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x7 = makeref(&allocp[14]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_129);
  *reasonp++ =  a6;
  goto make__typeset_14_159;
  };
  goto make__typeset_14_159;
 case symval(makesym(atom_shift__right)):
 make__typeset_14_131:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_132:
  if (a6 != makeint(3L)) goto make__typeset_14_159;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_i);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x7 = makeref(&allocp[14]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_131);
  *reasonp++ =  a6;
  goto make__typeset_14_159;
  };
  goto make__typeset_14_159;
 case symval(makesym(atom_floating__point__to__integer)):
 make__typeset_14_133:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_134:
  if (a6 != makeint(2L)) goto make__typeset_14_159;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_i);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x6 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_133);
  *reasonp++ =  a6;
  goto make__typeset_14_159;
  };
  goto make__typeset_14_159;
 case symval(makesym(atom_greater__than)):
 make__typeset_14_135:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_136:
  if (a6 != makeint(2L)) goto make__typeset_14_159;
 make__typeset_14_137:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_guard)) goto make__typeset_14_159;
  unify2(a13, a12, a11, a10);
  x0 = makesym(atom_builtin);
  unify_value(a8, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x2 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a2,make__typeset_14_137);
  *reasonp++ =  a2;
  goto make__typeset_14_159;
  };
  goto make__typeset_14_159;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_135);
  *reasonp++ =  a6;
  goto make__typeset_14_159;
  };
  goto make__typeset_14_159;
 case symval(makesym(atom_not__less__than)):
 make__typeset_14_138:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_139:
  if (a6 != makeint(2L)) goto make__typeset_14_159;
 make__typeset_14_140:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_guard)) goto make__typeset_14_159;
  unify2(a13, a12, a11, a10);
  x0 = makesym(atom_builtin);
  unify_value(a8, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x2 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a2,make__typeset_14_140);
  *reasonp++ =  a2;
  goto make__typeset_14_159;
  };
  goto make__typeset_14_159;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_138);
  *reasonp++ =  a6;
  goto make__typeset_14_159;
  };
  goto make__typeset_14_159;
 case symval(makesym(atom_equal)):
 make__typeset_14_141:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_142:
  if (a6 != makeint(2L)) goto make__typeset_14_159;
 make__typeset_14_143:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_guard)) goto make__typeset_14_159;
  unify2(a13, a12, a11, a10);
  x0 = makesym(atom_builtin);
  unify_value(a8, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x2 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a2,make__typeset_14_143);
  *reasonp++ =  a2;
  goto make__typeset_14_159;
  };
  goto make__typeset_14_159;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_141);
  *reasonp++ =  a6;
  goto make__typeset_14_159;
  };
  goto make__typeset_14_159;
 case symval(makesym(atom_not__equal)):
 make__typeset_14_144:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_145:
  if (a6 != makeint(2L)) goto make__typeset_14_159;
 make__typeset_14_146:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_guard)) goto make__typeset_14_159;
  unify2(a13, a12, a11, a10);
  x0 = makesym(atom_builtin);
  unify_value(a8, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x2 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a2,make__typeset_14_146);
  *reasonp++ =  a2;
  goto make__typeset_14_159;
  };
  goto make__typeset_14_159;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_144);
  *reasonp++ =  a6;
  goto make__typeset_14_159;
  };
  goto make__typeset_14_159;
 case symval(makesym(atom_not__greater__than)):
 make__typeset_14_147:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_148:
  if (a6 != makeint(2L)) goto make__typeset_14_159;
 make__typeset_14_149:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_guard)) goto make__typeset_14_159;
  unify2(a13, a12, a11, a10);
  x0 = makesym(atom_builtin);
  unify_value(a8, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x2 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a2,make__typeset_14_149);
  *reasonp++ =  a2;
  goto make__typeset_14_159;
  };
  goto make__typeset_14_159;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_147);
  *reasonp++ =  a6;
  goto make__typeset_14_159;
  };
  goto make__typeset_14_159;
 case symval(makesym(atom_less__than)):
 make__typeset_14_150:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_151:
  if (a6 != makeint(2L)) goto make__typeset_14_159;
 make__typeset_14_152:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_guard)) goto make__typeset_14_159;
  unify2(a13, a12, a11, a10);
  x0 = makesym(atom_builtin);
  unify_value(a8, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x2 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a2,make__typeset_14_152);
  *reasonp++ =  a2;
  goto make__typeset_14_159;
  };
  goto make__typeset_14_159;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_150);
  *reasonp++ =  a6;
  goto make__typeset_14_159;
  };
  goto make__typeset_14_159;
 case symval(makesym(atom_float)):
 make__typeset_14_153:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_154:
  if (a6 != makeint(1L)) goto make__typeset_14_159;
 make__typeset_14_155:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_guard)) goto make__typeset_14_159;
  unify2(a13, a12, a11, a10);
  x0 = makesym(atom_builtin);
  unify_value(a8, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(1L);
  allocp[3] = a7;
  allocp[4] = x1 = makeref(&allocp[4]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case VARREF:
  deref_and_jump(a2,make__typeset_14_155);
  *reasonp++ =  a2;
  goto make__typeset_14_159;
  };
  goto make__typeset_14_159;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_153);
  *reasonp++ =  a6;
  goto make__typeset_14_159;
  };
  goto make__typeset_14_159;
 case symval(makesym(atom_functor)):
 make__typeset_14_156:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_157:
  if (a6 != makeint(3L)) goto make__typeset_14_159;
 make__typeset_14_158:
  switch (ptagof(a9)) {
 case ATOMIC:
  if (a9 != makesym(atom_init)) goto make__typeset_14_159;
  unify2(a13, a12, a11, a10);
  x0 = makesym(atom_builtin);
  unify_value(a8, x0);
  proceed();
 case VARREF:
  deref_and_jump(a9,make__typeset_14_158);
  *reasonp++ =  a9;
  goto make__typeset_14_159;
  };
  goto make__typeset_14_159;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_156);
  *reasonp++ =  a6;
  goto make__typeset_14_159;
  };
  goto make__typeset_14_159;
  };
  goto make__typeset_14_159;
 case VARREF:
  deref_and_jump(a5,make__typeset_14_85);
  *reasonp++ =  a5;
  goto make__typeset_14_159;
  };
  goto make__typeset_14_159;
 make__typeset_14_159:
 make__typeset_14_160:
  switch (ptagof(a4)) {
 case ATOMIC:
  if (isint(a4)) goto make__typeset_14_236;
  switch (symval(a4)) {
 case symval(makesym(atom_builtin)):
 make__typeset_14_161:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (isint(a5)) goto make__typeset_14_236;
  switch (symval(a5)) {
 case symval(makesym(atom_add)):
 make__typeset_14_162:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_163:
  if (a6 != makeint(3L)) goto make__typeset_14_236;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_i);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x7 = makeref(&allocp[14]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_162);
  *reasonp++ =  a6;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case symval(makesym(atom_subtract)):
 make__typeset_14_164:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_165:
  if (a6 != makeint(3L)) goto make__typeset_14_236;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_i);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x7 = makeref(&allocp[14]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_164);
  *reasonp++ =  a6;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case symval(makesym(atom_multiply)):
 make__typeset_14_166:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_167:
  if (a6 != makeint(3L)) goto make__typeset_14_236;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_i);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x7 = makeref(&allocp[14]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_166);
  *reasonp++ =  a6;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case symval(makesym(atom_divide)):
 make__typeset_14_168:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_169:
  if (a6 != makeint(3L)) goto make__typeset_14_236;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_i);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x7 = makeref(&allocp[14]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_168);
  *reasonp++ =  a6;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case VARREF:
  deref_and_jump(a5,make__typeset_14_161);
  *reasonp++ =  a5;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case symval(makesym(atom_generic)):
 make__typeset_14_170:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (isint(a5)) goto make__typeset_14_236;
  switch (symval(a5)) {
 case symval(makesym(atom_float)):
 make__typeset_14_171:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_172:
  if (a6 != makeint(1L)) goto make__typeset_14_236;
 make__typeset_14_173:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_guard)) goto make__typeset_14_236;
  unify2(a13, a12, a11, a10);
  x0 = makesym(atom_builtin);
  unify_value(a8, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(1L);
  allocp[3] = a7;
  allocp[4] = x1 = makeref(&allocp[4]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case VARREF:
  deref_and_jump(a2,make__typeset_14_173);
  *reasonp++ =  a2;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_171);
  *reasonp++ =  a6;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case symval(makesym(atom_new)):
 make__typeset_14_174:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_175:
  if (a6 != makeint(3L)) goto make__typeset_14_236;
 make__typeset_14_176:
  if (isref(a7)) goto make__typeset_14_179;
  x1 = makeint(1L);
  gblt_arg(x1,a7,x0,make__typeset_14_236);
 make__typeset_14_177:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_atom_1)) goto make__typeset_14_236;
  x2 = arg(x0, 0);
 make__typeset_14_178:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != makesym(atom_float)) goto make__typeset_14_236;
  x4 = makeint(2L);
  gblt_arg(x4,a7,x3,make__typeset_14_236);
  x6 = makeint(3L);
  gblt_arg(x6,a7,x5,make__typeset_14_236);
  x7 = makesym(atom_builtin);
  unify_value(a8, x7);
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x8 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x8;
  x9 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_f);
  allocp[9] = x9;
  x10 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x10;
  x11 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x3;
  allocp[19] = makesym(atom___);
  allocp[20] = x11;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  proceed();
 case VARREF:
  deref_and_jump(x2,make__typeset_14_178);
  *reasonp++ =  x2;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case VARREF:
  deref_and_jump(x0,make__typeset_14_177);
  *reasonp++ =  x0;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 make__typeset_14_179:
  deref_and_jump(a7,make__typeset_14_176);
  *reasonp++ =  a7;
  goto make__typeset_14_236;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_174);
  *reasonp++ =  a6;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case symval(makesym(atom_add)):
 make__typeset_14_180:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_181:
  if (a6 != makeint(3L)) goto make__typeset_14_236;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_f);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x7 = makeref(&allocp[14]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_180);
  *reasonp++ =  a6;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case symval(makesym(atom_subtract)):
 make__typeset_14_182:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_183:
  if (a6 != makeint(3L)) goto make__typeset_14_236;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_f);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x7 = makeref(&allocp[14]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_182);
  *reasonp++ =  a6;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case symval(makesym(atom_multiply)):
 make__typeset_14_184:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_185:
  if (a6 != makeint(3L)) goto make__typeset_14_236;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_f);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x7 = makeref(&allocp[14]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_184);
  *reasonp++ =  a6;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case symval(makesym(atom_divide)):
 make__typeset_14_186:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_187:
  if (a6 != makeint(3L)) goto make__typeset_14_236;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_f);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x7 = makeref(&allocp[14]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_186);
  *reasonp++ =  a6;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case symval(makesym(atom_pow)):
 make__typeset_14_188:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_189:
  if (a6 != makeint(3L)) goto make__typeset_14_236;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_f);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(3L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(2L);
  allocp[8] = a7;
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a7;
  allocp[14] = x7 = makeref(&allocp[14]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_188);
  *reasonp++ =  a6;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case symval(makesym(atom_sin)):
 make__typeset_14_190:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_191:
  if (a6 != makeint(2L)) goto make__typeset_14_236;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_f);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x6 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_190);
  *reasonp++ =  a6;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case symval(makesym(atom_cos)):
 make__typeset_14_192:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_193:
  if (a6 != makeint(2L)) goto make__typeset_14_236;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_f);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x6 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_192);
  *reasonp++ =  a6;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case symval(makesym(atom_tan)):
 make__typeset_14_194:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_195:
  if (a6 != makeint(2L)) goto make__typeset_14_236;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_f);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x6 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_194);
  *reasonp++ =  a6;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case symval(makesym(atom_asin)):
 make__typeset_14_196:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_197:
  if (a6 != makeint(2L)) goto make__typeset_14_236;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_f);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x6 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_196);
  *reasonp++ =  a6;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case symval(makesym(atom_acos)):
 make__typeset_14_198:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_199:
  if (a6 != makeint(2L)) goto make__typeset_14_236;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_f);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x6 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_198);
  *reasonp++ =  a6;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case symval(makesym(atom_atan)):
 make__typeset_14_200:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_201:
  if (a6 != makeint(2L)) goto make__typeset_14_236;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_f);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x6 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_200);
  *reasonp++ =  a6;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case symval(makesym(atom_sinh)):
 make__typeset_14_202:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_203:
  if (a6 != makeint(2L)) goto make__typeset_14_236;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_f);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x6 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_202);
  *reasonp++ =  a6;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case symval(makesym(atom_cosh)):
 make__typeset_14_204:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_205:
  if (a6 != makeint(2L)) goto make__typeset_14_236;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_f);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x6 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_204);
  *reasonp++ =  a6;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case symval(makesym(atom_tanh)):
 make__typeset_14_206:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_207:
  if (a6 != makeint(2L)) goto make__typeset_14_236;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_f);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x6 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_206);
  *reasonp++ =  a6;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case symval(makesym(atom_exp)):
 make__typeset_14_208:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_209:
  if (a6 != makeint(2L)) goto make__typeset_14_236;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_f);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x6 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_208);
  *reasonp++ =  a6;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case symval(makesym(atom_log)):
 make__typeset_14_210:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_211:
  if (a6 != makeint(2L)) goto make__typeset_14_236;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_f);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x6 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_210);
  *reasonp++ =  a6;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case symval(makesym(atom_sqrt)):
 make__typeset_14_212:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_213:
  if (a6 != makeint(2L)) goto make__typeset_14_236;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_f);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x6 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_212);
  *reasonp++ =  a6;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case symval(makesym(atom_ceil)):
 make__typeset_14_214:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_215:
  if (a6 != makeint(2L)) goto make__typeset_14_236;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_f);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x6 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_214);
  *reasonp++ =  a6;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case symval(makesym(atom_floor)):
 make__typeset_14_216:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_217:
  if (a6 != makeint(2L)) goto make__typeset_14_236;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_f);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = makesym(atom___);
  allocp[20] = x3;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  x5 = makesym(atom_builtin);
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  unify_value(a8, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x6 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_216);
  *reasonp++ =  a6;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case symval(makesym(atom_greater__than)):
 make__typeset_14_218:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_219:
  if (a6 != makeint(2L)) goto make__typeset_14_236;
 make__typeset_14_220:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_guard)) goto make__typeset_14_236;
  unify2(a13, a12, a11, a10);
  x0 = makesym(atom_builtin);
  unify_value(a8, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x2 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a2,make__typeset_14_220);
  *reasonp++ =  a2;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_218);
  *reasonp++ =  a6;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case symval(makesym(atom_not__less__than)):
 make__typeset_14_221:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_222:
  if (a6 != makeint(2L)) goto make__typeset_14_236;
 make__typeset_14_223:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_guard)) goto make__typeset_14_236;
  unify2(a13, a12, a11, a10);
  x0 = makesym(atom_builtin);
  unify_value(a8, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x2 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a2,make__typeset_14_223);
  *reasonp++ =  a2;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_221);
  *reasonp++ =  a6;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case symval(makesym(atom_equal)):
 make__typeset_14_224:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_225:
  if (a6 != makeint(2L)) goto make__typeset_14_236;
 make__typeset_14_226:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_guard)) goto make__typeset_14_236;
  unify2(a13, a12, a11, a10);
  x0 = makesym(atom_builtin);
  unify_value(a8, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x2 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a2,make__typeset_14_226);
  *reasonp++ =  a2;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_224);
  *reasonp++ =  a6;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case symval(makesym(atom_not__equal)):
 make__typeset_14_227:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_228:
  if (a6 != makeint(2L)) goto make__typeset_14_236;
 make__typeset_14_229:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_guard)) goto make__typeset_14_236;
  unify2(a13, a12, a11, a10);
  x0 = makesym(atom_builtin);
  unify_value(a8, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x2 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a2,make__typeset_14_229);
  *reasonp++ =  a2;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_227);
  *reasonp++ =  a6;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case symval(makesym(atom_not__greater__than)):
 make__typeset_14_230:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_231:
  if (a6 != makeint(2L)) goto make__typeset_14_236;
 make__typeset_14_232:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_guard)) goto make__typeset_14_236;
  unify2(a13, a12, a11, a10);
  x0 = makesym(atom_builtin);
  unify_value(a8, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x2 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a2,make__typeset_14_232);
  *reasonp++ =  a2;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_230);
  *reasonp++ =  a6;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case symval(makesym(atom_less__than)):
 make__typeset_14_233:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_234:
  if (a6 != makeint(2L)) goto make__typeset_14_236;
 make__typeset_14_235:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_guard)) goto make__typeset_14_236;
  unify2(a13, a12, a11, a10);
  x0 = makesym(atom_builtin);
  unify_value(a8, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(2L);
  allocp[3] = a7;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = makeint(1L);
  allocp[8] = a7;
  allocp[9] = x2 = makeref(&allocp[9]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a2,make__typeset_14_235);
  *reasonp++ =  a2;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_233);
  *reasonp++ =  a6;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case VARREF:
  deref_and_jump(a5,make__typeset_14_170);
  *reasonp++ =  a5;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 case VARREF:
  deref_and_jump(a4,make__typeset_14_160);
  *reasonp++ =  a4;
  goto make__typeset_14_236;
  };
  goto make__typeset_14_236;
 make__typeset_14_236:
  otherwise(make__typeset_14_interrupt);
 make__typeset_14_237:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (isint(a5)) goto make__typeset_14_244;
  switch (symval(a5)) {
 case symval(makesym(atom_functor)):
 make__typeset_14_238:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_239:
  if (a6 != makeint(3L)) goto make__typeset_14_244;
 make__typeset_14_240:
  switch (ptagof(a8)) {
 case ATOMIC:
  if (a8 != makesym(atom_builtin)) goto make__typeset_14_244;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xset_12);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x0 = makeref(&allocp[6]);
  allocp[7] = makesym(atom___);
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = x2 = makeref(&allocp[10]);
  allocp[11] = a11;
  allocp[12] = x3 = makeref(&allocp[12]);
  allocp[13] = a13;
  allocp[14] = (q)(struct goalrec*)&allocp[0];
  allocp[15] = (q)(&predicate_typeset_xset_12);
  allocp[16] = a0;
  allocp[17] = a1;
  allocp[18] = a2;
  allocp[19] = a3;
  allocp[20] = x4 = makeref(&allocp[20]);
  allocp[21] = makesym(atom___);
  allocp[22] = x5 = makeref(&allocp[22]);
  allocp[23] = a9;
  allocp[24] = a10;
  allocp[25] = x2;
  allocp[26] = a12;
  allocp[27] = x3;
  allocp[28] = makesym(functor_goal_4);
  allocp[29] = a0;
  allocp[30] = a1;
  allocp[31] = a2;
  allocp[32] = a3;
  x6 = makefunctor(&allocp[28]);
  allocp[33] = (q)(struct goalrec*)&allocp[14];
  allocp[34] = (q)(&predicate_builtin_xupdate__functor__type_4);
  allocp[35] = x7 = makeref(&allocp[35]);
  allocp[36] = x5;
  allocp[37] = x1;
  allocp[38] = x6;
  allocp[39] = (q)(struct goalrec*)&allocp[33];
  allocp[40] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[41] = a0;
  allocp[42] = a1;
  allocp[43] = x8 = makeref(&allocp[43]);
  allocp[44] = a10;
  allocp[45] = x7;
  allocp[46] = (q)(struct goalrec*)&allocp[39];
  allocp[47] = (q)(&predicate_functor__table_xarg_3);
  allocp[48] = makeint(3L);
  allocp[49] = a7;
  allocp[50] = x0;
  allocp[51] = (q)(struct goalrec*)&allocp[46];
  allocp[52] = (q)(&predicate_functor__table_xarg_3);
  allocp[53] = makeint(2L);
  allocp[54] = a7;
  allocp[55] = x4;
  allocp[56] = (q)(struct goalrec*)&allocp[51];
  allocp[57] = (q)(&predicate_functor__table_xarg_3);
  allocp[58] = makeint(1L);
  allocp[59] = a7;
  allocp[60] = x8;
  qp = (struct goalrec*)&allocp[56];
  allocp += 61;
  proceed();
 case VARREF:
  deref_and_jump(a8,make__typeset_14_240);
  *reasonp++ =  a8;
  goto make__typeset_14_244;
  };
  goto make__typeset_14_244;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_238);
  *reasonp++ =  a6;
  goto make__typeset_14_244;
  };
  goto make__typeset_14_244;
 case symval(makesym(atom_arg)):
 make__typeset_14_241:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_242:
  if (a6 != makeint(3L)) goto make__typeset_14_244;
 make__typeset_14_243:
  switch (ptagof(a9)) {
 case ATOMIC:
  if (a9 != makesym(atom_init)) goto make__typeset_14_244;
  unify2(a13, a12, a11, a10);
  x0 = makesym(atom_builtin);
  unify_value(a8, x0);
  proceed();
 case VARREF:
  deref_and_jump(a9,make__typeset_14_243);
  *reasonp++ =  a9;
  goto make__typeset_14_244;
  };
  goto make__typeset_14_244;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_241);
  *reasonp++ =  a6;
  goto make__typeset_14_244;
  };
  goto make__typeset_14_244;
  };
  goto make__typeset_14_244;
 case VARREF:
  deref_and_jump(a5,make__typeset_14_237);
  *reasonp++ =  a5;
  goto make__typeset_14_244;
  };
  goto make__typeset_14_244;
 make__typeset_14_244:
  otherwise(make__typeset_14_interrupt);
 make__typeset_14_245:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (isint(a5)) goto make__typeset_14_253;
  switch (symval(a5)) {
 case symval(makesym(atom_arg)):
 make__typeset_14_246:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_247:
  if (a6 != makeint(3L)) goto make__typeset_14_253;
 make__typeset_14_248:
  switch (ptagof(a8)) {
 case ATOMIC:
  if (a8 != makesym(atom_builtin)) goto make__typeset_14_253;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xset_12);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x0 = makeref(&allocp[6]);
  allocp[7] = makesym(atom___);
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = a11;
  allocp[12] = a12;
  allocp[13] = a13;
  allocp[14] = makesym(functor_goal_4);
  allocp[15] = a0;
  allocp[16] = a1;
  allocp[17] = a2;
  allocp[18] = a3;
  x2 = makefunctor(&allocp[14]);
  allocp[19] = (q)(struct goalrec*)&allocp[0];
  allocp[20] = (q)(&predicate_builtin_xupdate__arg__type_4);
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = x4 = makeref(&allocp[22]);
  allocp[23] = x1;
  allocp[24] = x2;
  allocp[25] = (q)(struct goalrec*)&allocp[19];
  allocp[26] = (q)(&predicate_typeset_xtypeset2int_2);
  allocp[27] = x5 = makeref(&allocp[27]);
  allocp[28] = x3;
  allocp[29] = (q)(struct goalrec*)&allocp[25];
  allocp[30] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[31] = a0;
  allocp[32] = a1;
  allocp[33] = x6 = makeref(&allocp[33]);
  allocp[34] = a10;
  allocp[35] = x4;
  allocp[36] = (q)(struct goalrec*)&allocp[29];
  allocp[37] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[38] = a0;
  allocp[39] = a1;
  allocp[40] = x7 = makeref(&allocp[40]);
  allocp[41] = a10;
  allocp[42] = x5;
  allocp[43] = (q)(struct goalrec*)&allocp[36];
  allocp[44] = (q)(&predicate_functor__table_xarg_3);
  allocp[45] = makeint(3L);
  allocp[46] = a7;
  allocp[47] = x0;
  allocp[48] = (q)(struct goalrec*)&allocp[43];
  allocp[49] = (q)(&predicate_functor__table_xarg_3);
  allocp[50] = makeint(2L);
  allocp[51] = a7;
  allocp[52] = x6;
  allocp[53] = (q)(struct goalrec*)&allocp[48];
  allocp[54] = (q)(&predicate_functor__table_xarg_3);
  allocp[55] = makeint(1L);
  allocp[56] = a7;
  allocp[57] = x7;
  qp = (struct goalrec*)&allocp[53];
  allocp += 58;
  proceed();
 case VARREF:
  deref_and_jump(a8,make__typeset_14_248);
  *reasonp++ =  a8;
  goto make__typeset_14_253;
  };
  goto make__typeset_14_253;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_246);
  *reasonp++ =  a6;
  goto make__typeset_14_253;
  };
  goto make__typeset_14_253;
 case symval(makesym(atom_new__functor)):
 make__typeset_14_249:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_250:
  if (a6 != makeint(3L)) goto make__typeset_14_253;
 make__typeset_14_251:
  switch (ptagof(a9)) {
 case ATOMIC:
  if (a9 != makesym(atom_init)) goto make__typeset_14_253;
 make__typeset_14_252:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_body)) goto make__typeset_14_253;
  unify2(a13, a12, a11, a10);
  x0 = makesym(atom_builtin);
  unify_value(a8, x0);
  proceed();
 case VARREF:
  deref_and_jump(a2,make__typeset_14_252);
  *reasonp++ =  a2;
  goto make__typeset_14_253;
  };
  goto make__typeset_14_253;
 case VARREF:
  deref_and_jump(a9,make__typeset_14_251);
  *reasonp++ =  a9;
  goto make__typeset_14_253;
  };
  goto make__typeset_14_253;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_249);
  *reasonp++ =  a6;
  goto make__typeset_14_253;
  };
  goto make__typeset_14_253;
  };
  goto make__typeset_14_253;
 case VARREF:
  deref_and_jump(a5,make__typeset_14_245);
  *reasonp++ =  a5;
  goto make__typeset_14_253;
  };
  goto make__typeset_14_253;
 make__typeset_14_253:
  otherwise(make__typeset_14_interrupt);
 make__typeset_14_254:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (a5 != makesym(atom_new__functor)) goto make__typeset_14_259;
 make__typeset_14_255:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_256:
  if (a6 != makeint(3L)) goto make__typeset_14_259;
 make__typeset_14_257:
  switch (ptagof(a8)) {
 case ATOMIC:
  if (a8 != makesym(atom_builtin)) goto make__typeset_14_259;
 make__typeset_14_258:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_body)) goto make__typeset_14_259;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xset_12);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x0 = makeref(&allocp[6]);
  allocp[7] = makesym(atom___);
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = a11;
  allocp[12] = a12;
  allocp[13] = a13;
  allocp[14] = makesym(functor_goal_4);
  allocp[15] = a0;
  allocp[16] = a1;
  allocp[17] = a2;
  allocp[18] = a3;
  x2 = makefunctor(&allocp[14]);
  allocp[19] = (q)(struct goalrec*)&allocp[0];
  allocp[20] = (q)(&predicate_builtin_xupdate__newfunctor_4);
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = x4 = makeref(&allocp[22]);
  allocp[23] = x1;
  allocp[24] = x2;
  allocp[25] = (q)(struct goalrec*)&allocp[19];
  allocp[26] = (q)(&predicate_typeset_xtypeset2int_2);
  allocp[27] = x5 = makeref(&allocp[27]);
  allocp[28] = x4;
  allocp[29] = (q)(struct goalrec*)&allocp[25];
  allocp[30] = (q)(&predicate_typeset_xtypeset2atom_2);
  allocp[31] = x6 = makeref(&allocp[31]);
  allocp[32] = x3;
  allocp[33] = (q)(struct goalrec*)&allocp[29];
  allocp[34] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[35] = a0;
  allocp[36] = a1;
  allocp[37] = x7 = makeref(&allocp[37]);
  allocp[38] = a10;
  allocp[39] = x5;
  allocp[40] = (q)(struct goalrec*)&allocp[33];
  allocp[41] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[42] = a0;
  allocp[43] = a1;
  allocp[44] = x8 = makeref(&allocp[44]);
  allocp[45] = a10;
  allocp[46] = x6;
  allocp[47] = (q)(struct goalrec*)&allocp[40];
  allocp[48] = (q)(&predicate_functor__table_xarg_3);
  allocp[49] = makeint(3L);
  allocp[50] = a7;
  allocp[51] = x7;
  allocp[52] = (q)(struct goalrec*)&allocp[47];
  allocp[53] = (q)(&predicate_functor__table_xarg_3);
  allocp[54] = makeint(2L);
  allocp[55] = a7;
  allocp[56] = x8;
  allocp[57] = (q)(struct goalrec*)&allocp[52];
  allocp[58] = (q)(&predicate_functor__table_xarg_3);
  allocp[59] = makeint(1L);
  allocp[60] = a7;
  allocp[61] = x0;
  qp = (struct goalrec*)&allocp[57];
  allocp += 62;
  proceed();
 case VARREF:
  deref_and_jump(a2,make__typeset_14_258);
  *reasonp++ =  a2;
  goto make__typeset_14_259;
  };
  goto make__typeset_14_259;
 case VARREF:
  deref_and_jump(a8,make__typeset_14_257);
  *reasonp++ =  a8;
  goto make__typeset_14_259;
  };
  goto make__typeset_14_259;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_255);
  *reasonp++ =  a6;
  goto make__typeset_14_259;
  };
  goto make__typeset_14_259;
 case VARREF:
  deref_and_jump(a5,make__typeset_14_254);
  *reasonp++ =  a5;
  goto make__typeset_14_259;
  };
  goto make__typeset_14_259;
 make__typeset_14_259:
  otherwise(make__typeset_14_interrupt);
 make__typeset_14_260:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (isint(a5)) goto make__typeset_14_268;
  switch (symval(a5)) {
 case symval(makesym(atom_new__functor)):
 make__typeset_14_261:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_262:
  if (a6 != makeint(3L)) goto make__typeset_14_268;
 make__typeset_14_263:
  switch (ptagof(a8)) {
 case ATOMIC:
  if (a8 != makesym(atom_builtin)) goto make__typeset_14_268;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xset_12);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x0 = makeref(&allocp[6]);
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = a11;
  allocp[12] = a12;
  allocp[13] = a13;
  allocp[14] = makesym(functor_variable_3);
  allocp[15] = x0;
  allocp[16] = x1;
  allocp[17] = x4 = makeref(&allocp[17]);
  x3 = makefunctor(&allocp[14]);
  allocp[18] = makesym(functor_goal_4);
  allocp[19] = a0;
  allocp[20] = a1;
  allocp[21] = a2;
  allocp[22] = a3;
  x5 = makefunctor(&allocp[18]);
  allocp[23] = (q)(struct goalrec*)&allocp[0];
  allocp[24] = (q)(&predicate_builtin_xupdate__newfunctor_4);
  allocp[25] = x6 = makeref(&allocp[25]);
  allocp[26] = x7 = makeref(&allocp[26]);
  allocp[27] = x2;
  allocp[28] = x5;
  allocp[29] = (q)(struct goalrec*)&allocp[23];
  allocp[30] = (q)(&predicate_typeset_xtypeset2int_2);
  allocp[31] = x8 = makeref(&allocp[31]);
  allocp[32] = x7;
  allocp[33] = (q)(struct goalrec*)&allocp[29];
  allocp[34] = (q)(&predicate_typeset_xtypeset2atom_2);
  allocp[35] = x9 = makeref(&allocp[35]);
  allocp[36] = x6;
  allocp[37] = (q)(struct goalrec*)&allocp[33];
  allocp[38] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[39] = a0;
  allocp[40] = a1;
  allocp[41] = x10 = makeref(&allocp[41]);
  allocp[42] = a10;
  allocp[43] = x8;
  allocp[44] = (q)(struct goalrec*)&allocp[37];
  allocp[45] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[46] = a0;
  allocp[47] = a1;
  allocp[48] = x11 = makeref(&allocp[48]);
  allocp[49] = a10;
  allocp[50] = x9;
  allocp[51] = (q)(struct goalrec*)&allocp[44];
  allocp[52] = (q)(&predicate_functor__table_xarg_3);
  allocp[53] = makeint(3L);
  allocp[54] = a7;
  allocp[55] = x10;
  allocp[56] = (q)(struct goalrec*)&allocp[51];
  allocp[57] = (q)(&predicate_functor__table_xarg_3);
  allocp[58] = makeint(2L);
  allocp[59] = a7;
  allocp[60] = x11;
  allocp[61] = (q)(struct goalrec*)&allocp[56];
  allocp[62] = (q)(&predicate_functor__table_xarg_3);
  allocp[63] = makeint(1L);
  allocp[64] = a7;
  allocp[65] = x3;
  qp = (struct goalrec*)&allocp[61];
  allocp += 66;
  proceed();
 case VARREF:
  deref_and_jump(a8,make__typeset_14_263);
  *reasonp++ =  a8;
  goto make__typeset_14_268;
  };
  goto make__typeset_14_268;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_261);
  *reasonp++ =  a6;
  goto make__typeset_14_268;
  };
  goto make__typeset_14_268;
 case symval(makesym(atom_setarg)):
 make__typeset_14_264:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_265:
  if (a6 != makeint(4L)) goto make__typeset_14_268;
 make__typeset_14_266:
  switch (ptagof(a9)) {
 case ATOMIC:
  if (a9 != makesym(atom_init)) goto make__typeset_14_268;
 make__typeset_14_267:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_body)) goto make__typeset_14_268;
  unify2(a13, a12, a11, a10);
  x0 = makesym(atom_builtin);
  unify_value(a8, x0);
  proceed();
 case VARREF:
  deref_and_jump(a2,make__typeset_14_267);
  *reasonp++ =  a2;
  goto make__typeset_14_268;
  };
  goto make__typeset_14_268;
 case VARREF:
  deref_and_jump(a9,make__typeset_14_266);
  *reasonp++ =  a9;
  goto make__typeset_14_268;
  };
  goto make__typeset_14_268;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_264);
  *reasonp++ =  a6;
  goto make__typeset_14_268;
  };
  goto make__typeset_14_268;
  };
  goto make__typeset_14_268;
 case VARREF:
  deref_and_jump(a5,make__typeset_14_260);
  *reasonp++ =  a5;
  goto make__typeset_14_268;
  };
  goto make__typeset_14_268;
 make__typeset_14_268:
  otherwise(make__typeset_14_interrupt);
 make__typeset_14_269:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (a5 != makesym(atom_setarg)) goto make__typeset_14_276;
 make__typeset_14_270:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_271:
  switch ((unsigned long)a6) {
 case (unsigned long) makeint(4L):
 make__typeset_14_272:
  switch (ptagof(a8)) {
 case ATOMIC:
  if (a8 != makesym(atom_builtin)) goto make__typeset_14_276;
 make__typeset_14_273:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_body)) goto make__typeset_14_276;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xset_12);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x0 = makeref(&allocp[6]);
  allocp[7] = makesym(atom___);
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = a11;
  allocp[12] = a12;
  allocp[13] = a13;
  allocp[14] = makesym(functor_goal_4);
  allocp[15] = a0;
  allocp[16] = a1;
  allocp[17] = a2;
  allocp[18] = a3;
  x2 = makefunctor(&allocp[14]);
  allocp[19] = (q)(struct goalrec*)&allocp[0];
  allocp[20] = (q)(&predicate_builtin_xupdate__setarg_6);
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = x4 = makeref(&allocp[22]);
  allocp[23] = x5 = makeref(&allocp[23]);
  allocp[24] = x1;
  allocp[25] = x6 = makeref(&allocp[25]);
  allocp[26] = x2;
  allocp[27] = (q)(struct goalrec*)&allocp[19];
  allocp[28] = (q)(&predicate_typeset_xtypeset2structtype_2);
  allocp[29] = x7 = makeref(&allocp[29]);
  allocp[30] = x4;
  allocp[31] = (q)(struct goalrec*)&allocp[27];
  allocp[32] = (q)(&predicate_typeset_xtypeset2int_2);
  allocp[33] = x8 = makeref(&allocp[33]);
  allocp[34] = x3;
  allocp[35] = (q)(struct goalrec*)&allocp[31];
  allocp[36] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[37] = a0;
  allocp[38] = a1;
  allocp[39] = x9 = makeref(&allocp[39]);
  allocp[40] = a10;
  allocp[41] = x5;
  allocp[42] = (q)(struct goalrec*)&allocp[35];
  allocp[43] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[44] = a0;
  allocp[45] = a1;
  allocp[46] = x10 = makeref(&allocp[46]);
  allocp[47] = a10;
  allocp[48] = x7;
  allocp[49] = (q)(struct goalrec*)&allocp[42];
  allocp[50] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[51] = a0;
  allocp[52] = a1;
  allocp[53] = x11 = makeref(&allocp[53]);
  allocp[54] = a10;
  allocp[55] = x8;
  allocp[56] = (q)(struct goalrec*)&allocp[49];
  allocp[57] = (q)(&predicate_functor__table_xarg_3);
  allocp[58] = makeint(4L);
  allocp[59] = a7;
  allocp[60] = x0;
  allocp[61] = (q)(struct goalrec*)&allocp[56];
  allocp[62] = (q)(&predicate_functor__table_xarg_3);
  allocp[63] = makeint(3L);
  allocp[64] = a7;
  allocp[65] = x9;
  allocp[66] = (q)(struct goalrec*)&allocp[61];
  allocp[67] = (q)(&predicate_functor__table_xarg_3);
  allocp[68] = makeint(2L);
  allocp[69] = a7;
  allocp[70] = x10;
  allocp[71] = (q)(struct goalrec*)&allocp[66];
  allocp[72] = (q)(&predicate_functor__table_xarg_3);
  allocp[73] = makeint(1L);
  allocp[74] = a7;
  allocp[75] = x11;
  qp = (struct goalrec*)&allocp[71];
  allocp += 76;
  proceed();
 case VARREF:
  deref_and_jump(a2,make__typeset_14_273);
  *reasonp++ =  a2;
  goto make__typeset_14_276;
  };
  goto make__typeset_14_276;
 case VARREF:
  deref_and_jump(a8,make__typeset_14_272);
  *reasonp++ =  a8;
  goto make__typeset_14_276;
  };
  goto make__typeset_14_276;
 case (unsigned long) makeint(5L):
 make__typeset_14_274:
  switch (ptagof(a9)) {
 case ATOMIC:
  if (a9 != makesym(atom_init)) goto make__typeset_14_276;
 make__typeset_14_275:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_body)) goto make__typeset_14_276;
  unify2(a13, a12, a11, a10);
  x0 = makesym(atom_builtin);
  unify_value(a8, x0);
  proceed();
 case VARREF:
  deref_and_jump(a2,make__typeset_14_275);
  *reasonp++ =  a2;
  goto make__typeset_14_276;
  };
  goto make__typeset_14_276;
 case VARREF:
  deref_and_jump(a9,make__typeset_14_274);
  *reasonp++ =  a9;
  goto make__typeset_14_276;
  };
  goto make__typeset_14_276;
  };
  goto make__typeset_14_276;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_270);
  *reasonp++ =  a6;
  goto make__typeset_14_276;
  };
  goto make__typeset_14_276;
 case VARREF:
  deref_and_jump(a5,make__typeset_14_269);
  *reasonp++ =  a5;
  goto make__typeset_14_276;
  };
  goto make__typeset_14_276;
 make__typeset_14_276:
  otherwise(make__typeset_14_interrupt);
 make__typeset_14_277:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (isint(a5)) goto make__typeset_14_285;
  switch (symval(a5)) {
 case symval(makesym(atom_setarg)):
 make__typeset_14_278:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_279:
  if (a6 != makeint(5L)) goto make__typeset_14_285;
 make__typeset_14_280:
  switch (ptagof(a8)) {
 case ATOMIC:
  if (a8 != makesym(atom_builtin)) goto make__typeset_14_285;
 make__typeset_14_281:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_body)) goto make__typeset_14_285;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xset_12);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x0 = makeref(&allocp[6]);
  allocp[7] = makesym(atom___);
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = x2 = makeref(&allocp[10]);
  allocp[11] = a11;
  allocp[12] = x3 = makeref(&allocp[12]);
  allocp[13] = a13;
  allocp[14] = (q)(struct goalrec*)&allocp[0];
  allocp[15] = (q)(&predicate_typeset_xset_12);
  allocp[16] = a0;
  allocp[17] = a1;
  allocp[18] = a2;
  allocp[19] = a3;
  allocp[20] = x4 = makeref(&allocp[20]);
  allocp[21] = makesym(atom___);
  allocp[22] = x5 = makeref(&allocp[22]);
  allocp[23] = a9;
  allocp[24] = a10;
  allocp[25] = x2;
  allocp[26] = a12;
  allocp[27] = x3;
  allocp[28] = makesym(functor_goal_4);
  allocp[29] = a0;
  allocp[30] = a1;
  allocp[31] = a2;
  allocp[32] = a3;
  x6 = makefunctor(&allocp[28]);
  allocp[33] = (q)(struct goalrec*)&allocp[14];
  allocp[34] = (q)(&predicate_builtin_xupdate__setarg_6);
  allocp[35] = x7 = makeref(&allocp[35]);
  allocp[36] = x8 = makeref(&allocp[36]);
  allocp[37] = x9 = makeref(&allocp[37]);
  allocp[38] = x1;
  allocp[39] = x5;
  allocp[40] = x6;
  allocp[41] = (q)(struct goalrec*)&allocp[33];
  allocp[42] = (q)(&predicate_typeset_xtypeset2structtype_2);
  allocp[43] = x10 = makeref(&allocp[43]);
  allocp[44] = x8;
  allocp[45] = (q)(struct goalrec*)&allocp[41];
  allocp[46] = (q)(&predicate_typeset_xtypeset2int_2);
  allocp[47] = x11 = makeref(&allocp[47]);
  allocp[48] = x7;
  allocp[49] = (q)(struct goalrec*)&allocp[45];
  allocp[50] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[51] = a0;
  allocp[52] = a1;
  allocp[53] = x12 = makeref(&allocp[53]);
  allocp[54] = a10;
  allocp[55] = x9;
  allocp[56] = (q)(struct goalrec*)&allocp[49];
  allocp[57] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[58] = a0;
  allocp[59] = a1;
  allocp[60] = x13 = makeref(&allocp[60]);
  allocp[61] = a10;
  allocp[62] = x10;
  allocp[63] = (q)(struct goalrec*)&allocp[56];
  allocp[64] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[65] = a0;
  allocp[66] = a1;
  allocp[67] = x14 = makeref(&allocp[67]);
  allocp[68] = a10;
  allocp[69] = x11;
  allocp[70] = (q)(struct goalrec*)&allocp[63];
  allocp[71] = (q)(&predicate_functor__table_xarg_3);
  allocp[72] = makeint(5L);
  allocp[73] = a7;
  allocp[74] = x0;
  allocp[75] = (q)(struct goalrec*)&allocp[70];
  allocp[76] = (q)(&predicate_functor__table_xarg_3);
  allocp[77] = makeint(4L);
  allocp[78] = a7;
  allocp[79] = x12;
  allocp[80] = (q)(struct goalrec*)&allocp[75];
  allocp[81] = (q)(&predicate_functor__table_xarg_3);
  allocp[82] = makeint(3L);
  allocp[83] = a7;
  allocp[84] = x4;
  allocp[85] = (q)(struct goalrec*)&allocp[80];
  allocp[86] = (q)(&predicate_functor__table_xarg_3);
  allocp[87] = makeint(2L);
  allocp[88] = a7;
  allocp[89] = x13;
  allocp[90] = (q)(struct goalrec*)&allocp[85];
  allocp[91] = (q)(&predicate_functor__table_xarg_3);
  allocp[92] = makeint(1L);
  allocp[93] = a7;
  allocp[94] = x14;
  qp = (struct goalrec*)&allocp[90];
  allocp += 95;
  proceed();
 case VARREF:
  deref_and_jump(a2,make__typeset_14_281);
  *reasonp++ =  a2;
  goto make__typeset_14_285;
  };
  goto make__typeset_14_285;
 case VARREF:
  deref_and_jump(a8,make__typeset_14_280);
  *reasonp++ =  a8;
  goto make__typeset_14_285;
  };
  goto make__typeset_14_285;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_278);
  *reasonp++ =  a6;
  goto make__typeset_14_285;
  };
  goto make__typeset_14_285;
 case symval(makesym(atom_list)):
 make__typeset_14_282:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_283:
  if (a6 != makeint(1L)) goto make__typeset_14_285;
 make__typeset_14_284:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_guard)) goto make__typeset_14_285;
  unify2(a13, a12, a11, a10);
  x0 = makesym(atom_builtin);
  unify_value(a8, x0);
  proceed();
 case VARREF:
  deref_and_jump(a2,make__typeset_14_284);
  *reasonp++ =  a2;
  goto make__typeset_14_285;
  };
  goto make__typeset_14_285;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_282);
  *reasonp++ =  a6;
  goto make__typeset_14_285;
  };
  goto make__typeset_14_285;
  };
  goto make__typeset_14_285;
 case VARREF:
  deref_and_jump(a5,make__typeset_14_277);
  *reasonp++ =  a5;
  goto make__typeset_14_285;
  };
  goto make__typeset_14_285;
 make__typeset_14_285:
 make__typeset_14_286:
  switch (ptagof(a4)) {
 case ATOMIC:
  if (a4 != makesym(atom_generic)) goto make__typeset_14_295;
 make__typeset_14_287:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (a5 != makesym(atom_new)) goto make__typeset_14_295;
 make__typeset_14_288:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_289:
  if (a6 != makeint(3L)) goto make__typeset_14_295;
 make__typeset_14_290:
  switch (ptagof(a9)) {
 case ATOMIC:
  if (a9 != makesym(atom_init)) goto make__typeset_14_295;
 make__typeset_14_291:
  if (isref(a7)) goto make__typeset_14_294;
  x1 = makeint(1L);
  gblt_arg(x1,a7,x0,make__typeset_14_295);
 make__typeset_14_292:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_atom_1)) goto make__typeset_14_295;
  x2 = arg(x0, 0);
 make__typeset_14_293:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != makesym(atom_vector)) goto make__typeset_14_295;
  unify2(a13, a12, a11, a10);
  x3 = makesym(atom_builtin);
  unify_value(a8, x3);
  proceed();
 case VARREF:
  deref_and_jump(x2,make__typeset_14_293);
  *reasonp++ =  x2;
  goto make__typeset_14_295;
  };
  goto make__typeset_14_295;
 case VARREF:
  deref_and_jump(x0,make__typeset_14_292);
  *reasonp++ =  x0;
  goto make__typeset_14_295;
  };
  goto make__typeset_14_295;
 make__typeset_14_294:
  deref_and_jump(a7,make__typeset_14_291);
  *reasonp++ =  a7;
  goto make__typeset_14_295;
 case VARREF:
  deref_and_jump(a9,make__typeset_14_290);
  *reasonp++ =  a9;
  goto make__typeset_14_295;
  };
  goto make__typeset_14_295;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_288);
  *reasonp++ =  a6;
  goto make__typeset_14_295;
  };
  goto make__typeset_14_295;
 case VARREF:
  deref_and_jump(a5,make__typeset_14_287);
  *reasonp++ =  a5;
  goto make__typeset_14_295;
  };
  goto make__typeset_14_295;
 case VARREF:
  deref_and_jump(a4,make__typeset_14_286);
  *reasonp++ =  a4;
  goto make__typeset_14_295;
  };
  goto make__typeset_14_295;
 make__typeset_14_295:
  otherwise(make__typeset_14_interrupt);
 make__typeset_14_296:
  switch (ptagof(a4)) {
 case ATOMIC:
  if (a4 != makesym(atom_generic)) goto make__typeset_14_318;
 make__typeset_14_297:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (isint(a5)) goto make__typeset_14_318;
  switch (symval(a5)) {
 case symval(makesym(atom_new)):
 make__typeset_14_298:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_299:
  if (a6 != makeint(3L)) goto make__typeset_14_318;
 make__typeset_14_300:
  switch (ptagof(a8)) {
 case ATOMIC:
  if (a8 != makesym(atom_builtin)) goto make__typeset_14_318;
 make__typeset_14_301:
  if (isref(a7)) goto make__typeset_14_304;
  x1 = makeint(1L);
  gblt_arg(x1,a7,x0,make__typeset_14_318);
 make__typeset_14_302:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_atom_1)) goto make__typeset_14_318;
  x2 = arg(x0, 0);
 make__typeset_14_303:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != makesym(atom_vector)) goto make__typeset_14_318;
  x4 = makeint(2L);
  gblt_arg(x4,a7,x3,make__typeset_14_318);
  x6 = makeint(3L);
  gblt_arg(x6,a7,x5,make__typeset_14_318);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xset_12);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x3;
  allocp[7] = makesym(atom___);
  allocp[8] = x7 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = a11;
  allocp[12] = a12;
  allocp[13] = a13;
  allocp[14] = makesym(functor_goal_4);
  allocp[15] = a0;
  allocp[16] = a1;
  allocp[17] = a2;
  allocp[18] = a3;
  x8 = makefunctor(&allocp[14]);
  allocp[19] = (q)(struct goalrec*)&allocp[0];
  allocp[20] = (q)(&predicate_builtin_xupdate__newvector_4);
  allocp[21] = x9 = makeref(&allocp[21]);
  allocp[22] = x10 = makeref(&allocp[22]);
  allocp[23] = x7;
  allocp[24] = x8;
  allocp[25] = (q)(struct goalrec*)&allocp[19];
  allocp[26] = (q)(&predicate_typeset_xtypeset2list_2);
  allocp[27] = x11 = makeref(&allocp[27]);
  allocp[28] = x10;
  allocp[29] = (q)(struct goalrec*)&allocp[25];
  allocp[30] = (q)(&predicate_typeset_xtypeset2int_2);
  allocp[31] = x11;
  allocp[32] = x9;
  allocp[33] = (q)(struct goalrec*)&allocp[29];
  allocp[34] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[35] = a0;
  allocp[36] = a1;
  allocp[37] = x5;
  allocp[38] = a10;
  allocp[39] = x11;
  qp = (struct goalrec*)&allocp[33];
  allocp += 40;
  proceed();
 case VARREF:
  deref_and_jump(x2,make__typeset_14_303);
  *reasonp++ =  x2;
  goto make__typeset_14_318;
  };
  goto make__typeset_14_318;
 case VARREF:
  deref_and_jump(x0,make__typeset_14_302);
  *reasonp++ =  x0;
  goto make__typeset_14_318;
  };
  goto make__typeset_14_318;
 make__typeset_14_304:
  deref_and_jump(a7,make__typeset_14_301);
  *reasonp++ =  a7;
  goto make__typeset_14_318;
 case VARREF:
  deref_and_jump(a8,make__typeset_14_300);
  *reasonp++ =  a8;
  goto make__typeset_14_318;
  };
  goto make__typeset_14_318;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_298);
  *reasonp++ =  a6;
  goto make__typeset_14_318;
  };
  goto make__typeset_14_318;
 case symval(makesym(atom_size)):
 make__typeset_14_305:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_306:
  if (a6 != makeint(2L)) goto make__typeset_14_318;
 make__typeset_14_307:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_body)) goto make__typeset_14_318;
 make__typeset_14_308:
  if (isref(a7)) goto make__typeset_14_309;
  x1 = makeint(1L);
  gblt_arg(x1,a7,x0,make__typeset_14_318);
  x3 = makeint(2L);
  gblt_arg(x3,a7,x2,make__typeset_14_318);
  x4 = makesym(atom_builtin);
  unify_value(a8, x4);
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x5 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x5;
  x6 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_i);
  allocp[9] = x6;
  x7 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x7;
  x8 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x2;
  allocp[19] = makesym(atom___);
  allocp[20] = x8;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  proceed();
 make__typeset_14_309:
  deref_and_jump(a7,make__typeset_14_308);
  *reasonp++ =  a7;
  goto make__typeset_14_318;
 case VARREF:
  deref_and_jump(a2,make__typeset_14_307);
  *reasonp++ =  a2;
  goto make__typeset_14_318;
  };
  goto make__typeset_14_318;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_305);
  *reasonp++ =  a6;
  goto make__typeset_14_318;
  };
  goto make__typeset_14_318;
 case symval(makesym(atom_vector)):
 make__typeset_14_310:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_311:
  if (a6 != makeint(2L)) goto make__typeset_14_318;
 make__typeset_14_312:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_guard)) goto make__typeset_14_318;
 make__typeset_14_313:
  if (isref(a7)) goto make__typeset_14_314;
  x1 = makeint(1L);
  gblt_arg(x1,a7,x0,make__typeset_14_318);
  x3 = makeint(2L);
  gblt_arg(x3,a7,x2,make__typeset_14_318);
  x4 = makesym(atom_builtin);
  unify_value(a8, x4);
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x5 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x5;
  x6 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_i);
  allocp[9] = x6;
  x7 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x7;
  x8 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x2;
  allocp[19] = makesym(atom___);
  allocp[20] = x8;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  proceed();
 make__typeset_14_314:
  deref_and_jump(a7,make__typeset_14_313);
  *reasonp++ =  a7;
  goto make__typeset_14_318;
 case VARREF:
  deref_and_jump(a2,make__typeset_14_312);
  *reasonp++ =  a2;
  goto make__typeset_14_318;
  };
  goto make__typeset_14_318;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_310);
  *reasonp++ =  a6;
  goto make__typeset_14_318;
  };
  goto make__typeset_14_318;
 case symval(makesym(atom_element)):
 make__typeset_14_315:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_316:
  if (a6 != makeint(3L)) goto make__typeset_14_318;
 make__typeset_14_317:
  switch (ptagof(a9)) {
 case ATOMIC:
  if (a9 != makesym(atom_init)) goto make__typeset_14_318;
  unify2(a13, a12, a11, a10);
  x0 = makesym(atom_builtin);
  unify_value(a8, x0);
  proceed();
 case VARREF:
  deref_and_jump(a9,make__typeset_14_317);
  *reasonp++ =  a9;
  goto make__typeset_14_318;
  };
  goto make__typeset_14_318;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_315);
  *reasonp++ =  a6;
  goto make__typeset_14_318;
  };
  goto make__typeset_14_318;
  };
  goto make__typeset_14_318;
 case VARREF:
  deref_and_jump(a5,make__typeset_14_297);
  *reasonp++ =  a5;
  goto make__typeset_14_318;
  };
  goto make__typeset_14_318;
 case VARREF:
  deref_and_jump(a4,make__typeset_14_296);
  *reasonp++ =  a4;
  goto make__typeset_14_318;
  };
  goto make__typeset_14_318;
 make__typeset_14_318:
 make__typeset_14_319:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (a5 != makesym(atom_vector)) goto make__typeset_14_325;
 make__typeset_14_320:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_321:
  if (a6 != makeint(2L)) goto make__typeset_14_325;
 make__typeset_14_322:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_guard)) goto make__typeset_14_325;
 make__typeset_14_323:
  if (isref(a7)) goto make__typeset_14_324;
  x1 = makeint(1L);
  gblt_arg(x1,a7,x0,make__typeset_14_325);
  x3 = makeint(2L);
  gblt_arg(x3,a7,x2,make__typeset_14_325);
  x4 = makesym(atom_builtin);
  unify_value(a8, x4);
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x5 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x5;
  x6 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = makesym(atom_i);
  allocp[9] = x6;
  x7 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x7;
  x8 = makecons(&allocp[10]);
  allocp[12] = (q)qp;
  allocp[13] = (q)(&predicate_typeset_xset_12);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x2;
  allocp[19] = makesym(atom___);
  allocp[20] = x8;
  allocp[21] = makesym(atom_normal);
  allocp[22] = a10;
  allocp[23] = a11;
  allocp[24] = a12;
  allocp[25] = a13;
  qp = (struct goalrec*)&allocp[12];
  allocp += 26;
  proceed();
 make__typeset_14_324:
  deref_and_jump(a7,make__typeset_14_323);
  *reasonp++ =  a7;
  goto make__typeset_14_325;
 case VARREF:
  deref_and_jump(a2,make__typeset_14_322);
  *reasonp++ =  a2;
  goto make__typeset_14_325;
  };
  goto make__typeset_14_325;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_320);
  *reasonp++ =  a6;
  goto make__typeset_14_325;
  };
  goto make__typeset_14_325;
 case VARREF:
  deref_and_jump(a5,make__typeset_14_319);
  *reasonp++ =  a5;
  goto make__typeset_14_325;
  };
  goto make__typeset_14_325;
 make__typeset_14_325:
  otherwise(make__typeset_14_interrupt);
 make__typeset_14_326:
  switch (ptagof(a4)) {
 case ATOMIC:
  if (isint(a4)) goto make__typeset_14_339;
  switch (symval(a4)) {
 case symval(makesym(atom_generic)):
 make__typeset_14_327:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (a5 != makesym(atom_element)) goto make__typeset_14_339;
 make__typeset_14_328:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_329:
  if (a6 != makeint(3L)) goto make__typeset_14_339;
 make__typeset_14_330:
  switch (ptagof(a8)) {
 case ATOMIC:
  if (a8 != makesym(atom_builtin)) goto make__typeset_14_339;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xset_12);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x0 = makeref(&allocp[6]);
  allocp[7] = makesym(atom___);
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = a11;
  allocp[12] = a12;
  allocp[13] = a13;
  allocp[14] = makesym(functor_goal_4);
  allocp[15] = a0;
  allocp[16] = a1;
  allocp[17] = a2;
  allocp[18] = a3;
  x2 = makefunctor(&allocp[14]);
  allocp[19] = (q)(struct goalrec*)&allocp[0];
  allocp[20] = (q)(&predicate_builtin_xupdate__element__type_4);
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = x4 = makeref(&allocp[22]);
  allocp[23] = x1;
  allocp[24] = x2;
  allocp[25] = (q)(struct goalrec*)&allocp[19];
  allocp[26] = (q)(&predicate_typeset_xtypeset2int_2);
  allocp[27] = x5 = makeref(&allocp[27]);
  allocp[28] = x3;
  allocp[29] = (q)(struct goalrec*)&allocp[25];
  allocp[30] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[31] = a0;
  allocp[32] = a1;
  allocp[33] = x6 = makeref(&allocp[33]);
  allocp[34] = a10;
  allocp[35] = x5;
  allocp[36] = (q)(struct goalrec*)&allocp[29];
  allocp[37] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[38] = a0;
  allocp[39] = a1;
  allocp[40] = x7 = makeref(&allocp[40]);
  allocp[41] = a10;
  allocp[42] = x4;
  allocp[43] = (q)(struct goalrec*)&allocp[36];
  allocp[44] = (q)(&predicate_functor__table_xarg_3);
  allocp[45] = makeint(3L);
  allocp[46] = a7;
  allocp[47] = x0;
  allocp[48] = (q)(struct goalrec*)&allocp[43];
  allocp[49] = (q)(&predicate_functor__table_xarg_3);
  allocp[50] = makeint(2L);
  allocp[51] = a7;
  allocp[52] = x6;
  allocp[53] = (q)(struct goalrec*)&allocp[48];
  allocp[54] = (q)(&predicate_functor__table_xarg_3);
  allocp[55] = makeint(1L);
  allocp[56] = a7;
  allocp[57] = x7;
  qp = (struct goalrec*)&allocp[53];
  allocp += 58;
  proceed();
 case VARREF:
  deref_and_jump(a8,make__typeset_14_330);
  *reasonp++ =  a8;
  goto make__typeset_14_339;
  };
  goto make__typeset_14_339;
 case VARREF:
  deref_and_jump(a6,make__typeset_14_328);
  *reasonp++ =  a6;
  goto make__typeset_14_339;
  };
  goto make__typeset_14_339;
 case VARREF:
  deref_and_jump(a5,make__typeset_14_327);
  *reasonp++ =  a5;
  goto make__typeset_14_339;
  };
  goto make__typeset_14_339;
 case symval(makesym(atom_builtin)):
 make__typeset_14_331:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (isint(a5)) goto make__typeset_14_339;
  switch (symval(a5)) {
 case symval(makesym(atom_start__measure)):
 make__typeset_14_332:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_333:
  if (a6 != makeint(0L)) goto make__typeset_14_339;
  unify2(a13, a12, a11, a10);
  x0 = makesym(atom_builtin);
  unify_value(a8, x0);
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_332);
  *reasonp++ =  a6;
  goto make__typeset_14_339;
  };
  goto make__typeset_14_339;
 case symval(makesym(atom_report__measure)):
 make__typeset_14_334:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_335:
  if (a6 != makeint(1L)) goto make__typeset_14_339;
  unify2(a13, a12, a11, a10);
  x0 = makesym(atom_builtin);
  unify_value(a8, x0);
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_334);
  *reasonp++ =  a6;
  goto make__typeset_14_339;
  };
  goto make__typeset_14_339;
  };
  goto make__typeset_14_339;
 case VARREF:
  deref_and_jump(a5,make__typeset_14_331);
  *reasonp++ =  a5;
  goto make__typeset_14_339;
  };
  goto make__typeset_14_339;
 case symval(makesym(atom_io)):
 make__typeset_14_336:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (a5 != makesym(atom_outstream)) goto make__typeset_14_339;
 make__typeset_14_337:
  switch (ptagof(a6)) {
 case ATOMIC:
 make__typeset_14_338:
  if (a6 != makeint(1L)) goto make__typeset_14_339;
  unify2(a13, a12, a11, a10);
  x0 = makesym(atom_builtin);
  unify_value(a8, x0);
  proceed();
 case VARREF:
  deref_and_jump(a6,make__typeset_14_337);
  *reasonp++ =  a6;
  goto make__typeset_14_339;
  };
  goto make__typeset_14_339;
 case VARREF:
  deref_and_jump(a5,make__typeset_14_336);
  *reasonp++ =  a5;
  goto make__typeset_14_339;
  };
  goto make__typeset_14_339;
  };
  goto make__typeset_14_339;
 case VARREF:
  deref_and_jump(a4,make__typeset_14_326);
  *reasonp++ =  a4;
  goto make__typeset_14_339;
  };
  goto make__typeset_14_339;
 make__typeset_14_339:
  otherwise(make__typeset_14_interrupt);
  unify2(a13, a12, a11, a10);
  x0 = makesym(atom_userdef);
  unify_value(a8, x0);
  proceed();
 make__typeset_14_ext_interrupt:
  reasonp = 0l;
 make__typeset_14_interrupt:
  goto interrupt_14;
 }

 builtin__unify_10_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 builtin__unify_10_clear_reason:
  reasonp = reasons;
 builtin__unify_10_0:
 builtin__unify_10_1:
  switch (ptagof(a4)) {
 case FUNCTOR:
  if (functor_of(a4) != makesym(functor_variable_3)) goto builtin__unify_10_3;
 builtin__unify_10_2:
  switch (ptagof(a5)) {
 case FUNCTOR:
  if (functor_of(a5) != makesym(functor_variable_3)) goto builtin__unify_10_3;
  unify2(a9, a8, a7, a6);
  proceed();
 case VARREF:
  deref_and_jump(a5,builtin__unify_10_2);
  *reasonp++ =  a5;
  goto builtin__unify_10_3;
  };
  goto builtin__unify_10_3;
 case VARREF:
  deref_and_jump(a4,builtin__unify_10_1);
  *reasonp++ =  a4;
  goto builtin__unify_10_3;
  };
  goto builtin__unify_10_3;
 builtin__unify_10_3:
  otherwise(builtin__unify_10_interrupt);
 builtin__unify_10_4:
  switch (ptagof(a4)) {
 case FUNCTOR:
  if (functor_of(a4) != makesym(functor_variable_3)) goto builtin__unify_10_6;
 builtin__unify_10_5:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (isint(a2)) goto builtin__unify_10_6;
  switch (symval(a2)) {
 case symval(makesym(atom_guard)):
  unify2(a9, a8, a7, a6);
  proceed();
 case symval(makesym(atom_body)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xset_12);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = makesym(atom___);
  allocp[8] = x0 = makeref(&allocp[8]);
  allocp[9] = makesym(atom_normal);
  allocp[10] = a6;
  allocp[11] = a7;
  allocp[12] = a8;
  allocp[13] = a9;
  allocp[14] = makesym(functor_goal_4);
  allocp[15] = a0;
  allocp[16] = a1;
  allocp[17] = a2;
  allocp[18] = a3;
  x1 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x1;
  x2 = makecons(&allocp[19]);
  allocp[21] = (q)(struct goalrec*)&allocp[0];
  allocp[22] = (q)(&predicate_typeset_xvalue2typeset_5);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a5;
  allocp[26] = x2;
  allocp[27] = x0;
  qp = (struct goalrec*)&allocp[21];
  allocp += 28;
  proceed();
  };
  goto builtin__unify_10_6;
 case VARREF:
  deref_and_jump(a2,builtin__unify_10_5);
  *reasonp++ =  a2;
  goto builtin__unify_10_6;
  };
  goto builtin__unify_10_6;
 case VARREF:
  deref_and_jump(a4,builtin__unify_10_4);
  *reasonp++ =  a4;
  goto builtin__unify_10_6;
  };
  goto builtin__unify_10_6;
 builtin__unify_10_6:
 builtin__unify_10_7:
  switch (ptagof(a5)) {
 case FUNCTOR:
  if (functor_of(a5) != makesym(functor_variable_3)) goto builtin__unify_10_9;
 builtin__unify_10_8:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (isint(a2)) goto builtin__unify_10_9;
  switch (symval(a2)) {
 case symval(makesym(atom_guard)):
  unify2(a9, a8, a7, a6);
  proceed();
 case symval(makesym(atom_body)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xset_12);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a5;
  allocp[7] = makesym(atom___);
  allocp[8] = x0 = makeref(&allocp[8]);
  allocp[9] = makesym(atom_normal);
  allocp[10] = a6;
  allocp[11] = a7;
  allocp[12] = a8;
  allocp[13] = a9;
  allocp[14] = makesym(functor_goal_4);
  allocp[15] = a0;
  allocp[16] = a1;
  allocp[17] = a2;
  allocp[18] = a3;
  x1 = makefunctor(&allocp[14]);
  allocp[19] = NILATOM;
  allocp[20] = x1;
  x2 = makecons(&allocp[19]);
  allocp[21] = (q)(struct goalrec*)&allocp[0];
  allocp[22] = (q)(&predicate_typeset_xvalue2typeset_5);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a4;
  allocp[26] = x2;
  allocp[27] = x0;
  qp = (struct goalrec*)&allocp[21];
  allocp += 28;
  proceed();
  };
  goto builtin__unify_10_9;
 case VARREF:
  deref_and_jump(a2,builtin__unify_10_8);
  *reasonp++ =  a2;
  goto builtin__unify_10_9;
  };
  goto builtin__unify_10_9;
 case VARREF:
  deref_and_jump(a5,builtin__unify_10_7);
  *reasonp++ =  a5;
  goto builtin__unify_10_9;
  };
  goto builtin__unify_10_9;
 builtin__unify_10_9:
  otherwise(builtin__unify_10_interrupt);
  unify2(a9, a8, a7, a6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdata_1);
  allocp[2] = makesym(atom_Value_3DValue_20not_20implemented_2E);
  allocp[3] = (q)(struct goalrec*)&allocp[0];
  allocp[4] = (q)(&predicate_print_xdata_1);
  allocp[5] = makesym(atom_Error_20in_20type__init_3Abuiltin__type__unify);
  qp = (struct goalrec*)&allocp[3];
  allocp += 6;
  proceed();
 builtin__unify_10_ext_interrupt:
  reasonp = 0l;
 builtin__unify_10_interrupt:
  goto interrupt_10;
 }

 unify__builtin__typeset_11_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 unify__builtin__typeset_11_clear_reason:
  reasonp = reasons;
 unify__builtin__typeset_11_0:
 unify__builtin__typeset_11_1:
  switch (ptagof(a4)) {
 case ATOMIC:
  if (isint(a4)) goto unify__builtin__typeset_11_4;
  switch (symval(a4)) {
 case symval(makesym(atom_body)):
 unify__builtin__typeset_11_2:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_variable_3)) goto unify__builtin__typeset_11_4;
 unify__builtin__typeset_11_3:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_variable_3)) goto unify__builtin__typeset_11_4;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a2;
  allocp[2] = a3;
  allocp[3] = a4;
  allocp[4] = a5;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_typeset_xunify__equal_10);
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = x0;
  allocp[10] = a0;
  allocp[11] = a1;
  allocp[12] = a6;
  allocp[13] = a7;
  allocp[14] = a8;
  allocp[15] = a9;
  allocp[16] = a10;
  allocp[17] = (q)(struct goalrec*)&allocp[5];
  allocp[18] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[19] = a2;
  allocp[20] = a3;
  allocp[21] = a1;
  allocp[22] = a7;
  allocp[23] = x2;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[26] = a2;
  allocp[27] = a3;
  allocp[28] = a0;
  allocp[29] = a7;
  allocp[30] = x1;
  qp = (struct goalrec*)&allocp[24];
  allocp += 31;
  proceed();
 case VARREF:
  deref_and_jump(a1,unify__builtin__typeset_11_3);
  *reasonp++ =  a1;
  goto unify__builtin__typeset_11_4;
  };
  goto unify__builtin__typeset_11_4;
 case VARREF:
  deref_and_jump(a0,unify__builtin__typeset_11_2);
  *reasonp++ =  a0;
  goto unify__builtin__typeset_11_4;
  };
  goto unify__builtin__typeset_11_4;
 case symval(makesym(atom_guard)):
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a2;
  allocp[2] = a3;
  allocp[3] = a4;
  allocp[4] = a5;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_typeset_xunify__equal_10);
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = x0;
  allocp[10] = a0;
  allocp[11] = a1;
  allocp[12] = a6;
  allocp[13] = a7;
  allocp[14] = a8;
  allocp[15] = a9;
  allocp[16] = a10;
  allocp[17] = (q)(struct goalrec*)&allocp[5];
  allocp[18] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[19] = a2;
  allocp[20] = a3;
  allocp[21] = a1;
  allocp[22] = a7;
  allocp[23] = x2;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[26] = a2;
  allocp[27] = a3;
  allocp[28] = a0;
  allocp[29] = a7;
  allocp[30] = x1;
  qp = (struct goalrec*)&allocp[24];
  allocp += 31;
  proceed();
  };
  goto unify__builtin__typeset_11_4;
 case VARREF:
  deref_and_jump(a4,unify__builtin__typeset_11_1);
  *reasonp++ =  a4;
  goto unify__builtin__typeset_11_4;
  };
  goto unify__builtin__typeset_11_4;
 unify__builtin__typeset_11_4:
  otherwise(unify__builtin__typeset_11_interrupt);
  unify2(a10, a9, a8, a7);
  proceed();
 unify__builtin__typeset_11_ext_interrupt:
  reasonp = 0l;
 unify__builtin__typeset_11_interrupt:
  goto interrupt_11;
 }

 update__newfunctor_4_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 update__newfunctor_4_clear_reason:
  reasonp = reasons;
 update__newfunctor_4_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin_xupdate__newfunctor__type_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_builtin_xstructarity_2);
  allocp[8] = a1;
  allocp[9] = x1;
  a1 = x0;
  qp = (struct goalrec*)&allocp[6];
  allocp += 10;
  execute(structname_2_0);
  goto structname_2_ext_interrupt;
 update__newfunctor_4_ext_interrupt:
  reasonp = 0l;
 update__newfunctor_4_interrupt:
  goto interrupt_4;
 }

 update__newfunctor__type_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 update__newfunctor__type_4_clear_reason:
  reasonp = reasons;
 update__newfunctor__type_4_0:
 update__newfunctor__type_4_1:
  if (!isint(a1)) goto update__newfunctor__type_4_2;
  gblt_integer(a1,update__newfunctor__type_4_3);
  x0 = makeint(5L);
  gblt_less(a1,x0,update__newfunctor__type_4_3);
  allocp[0] = makesym(functor_s_3);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = x2 = makeref(&allocp[3]);
  x1 = makefunctor(&allocp[0]);
  allocp[4] = NILATOM;
  allocp[5] = a3;
  x3 = makecons(&allocp[4]);
  allocp[6] = makesym(functor_t_2);
  allocp[7] = x1;
  allocp[8] = x3;
  x4 = makefunctor(&allocp[6]);
  allocp[9] = NILATOM;
  allocp[10] = x4;
  x5 = makecons(&allocp[9]);
  allocp += 11;
  unify_value(a2, x5);
  allocp[0] = NILATOM;
  allocp[1] = a3;
  x6 = makecons(&allocp[0]);
  allocp[2] = makesym(functor_t_2);
  allocp[3] = makefunctor(funct_const_12);
  allocp[4] = x6;
  x7 = makefunctor(&allocp[2]);
  allocp[5] = NILATOM;
  allocp[6] = x7;
  x8 = makecons(&allocp[5]);
  allocp[7] = (q)qp;
  allocp[8] = (q)(&predicate_functor_xnew__functor__init_4);
  allocp[9] = makesym(atom_args);
  allocp[10] = a1;
  allocp[11] = x8;
  allocp[12] = x2;
  qp = (struct goalrec*)&allocp[7];
  allocp += 13;
  proceed();
 update__newfunctor__type_4_2:
  if (!isref(a1)) goto update__newfunctor__type_4_3;
  deref_and_jump(a1,update__newfunctor__type_4_1);
  *reasonp++ =  a1;
  goto update__newfunctor__type_4_3;
 update__newfunctor__type_4_3:
  otherwise(update__newfunctor__type_4_interrupt);
 update__newfunctor__type_4_4:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (isint(a1)) goto update__newfunctor__type_4_5;
  if (a1 != makesym(atom__2A)) goto update__newfunctor__type_4_interrupt;
  allocp[0] = NILATOM;
  allocp[1] = a3;
  x0 = makecons(&allocp[0]);
  allocp[2] = makesym(functor_t_2);
  allocp[3] = makefunctor(funct_const_12);
  allocp[4] = x0;
  x1 = makefunctor(&allocp[2]);
  allocp[5] = NILATOM;
  allocp[6] = x1;
  x2 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_s_3);
  allocp[8] = a0;
  allocp[9] = makesym(atom__2A);
  allocp[10] = x2;
  x3 = makefunctor(&allocp[7]);
  allocp[11] = NILATOM;
  allocp[12] = a3;
  x4 = makecons(&allocp[11]);
  allocp[13] = makesym(functor_t_2);
  allocp[14] = x3;
  allocp[15] = x4;
  x5 = makefunctor(&allocp[13]);
  allocp[16] = NILATOM;
  allocp[17] = x5;
  x6 = makecons(&allocp[16]);
  allocp += 18;
  unify_value(a2, x6);
  proceed();
 update__newfunctor__type_4_5:
  gblt_integer(a1,update__newfunctor__type_4_interrupt);
  allocp[0] = NILATOM;
  allocp[1] = a3;
  x0 = makecons(&allocp[0]);
  allocp[2] = makesym(functor_t_2);
  allocp[3] = makefunctor(funct_const_12);
  allocp[4] = x0;
  x1 = makefunctor(&allocp[2]);
  allocp[5] = NILATOM;
  allocp[6] = x1;
  x2 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_s_3);
  allocp[8] = a0;
  allocp[9] = makesym(atom__2A);
  allocp[10] = x2;
  x3 = makefunctor(&allocp[7]);
  allocp[11] = NILATOM;
  allocp[12] = a3;
  x4 = makecons(&allocp[11]);
  allocp[13] = makesym(functor_t_2);
  allocp[14] = x3;
  allocp[15] = x4;
  x5 = makefunctor(&allocp[13]);
  allocp[16] = NILATOM;
  allocp[17] = x5;
  x6 = makecons(&allocp[16]);
  allocp += 18;
  unify_value(a2, x6);
  proceed();
 case VARREF:
  deref_and_jump(a1,update__newfunctor__type_4_4);
  *reasonp++ =  a1;
  goto update__newfunctor__type_4_interrupt;
  };
  goto update__newfunctor__type_4_interrupt;
 update__newfunctor__type_4_ext_interrupt:
  reasonp = 0l;
 update__newfunctor__type_4_interrupt:
  goto interrupt_4;
 }

 structname_2_top: {
  q x0;
  qp = qp->next;
 structname_2_clear_reason:
  reasonp = reasons;
 structname_2_0:
 structname_2_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto structname_2_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom__2A)):
  x0 = makesym(atom__2A);
  unify_value(a1, x0);
  proceed();
 case symval(makesym(atom_a)):
  x0 = makesym(atom__2A);
  unify_value(a1, x0);
  proceed();
  };
  goto structname_2_interrupt;
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_a_1)) goto structname_2_interrupt;
  x0 = arg(a0, 0);
  unify(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,structname_2_1);
  *reasonp++ =  a0;
  goto structname_2_interrupt;
  };
  goto structname_2_interrupt;
 structname_2_ext_interrupt:
  reasonp = 0l;
 structname_2_interrupt:
  toppred = &predicate_builtin_xstructname_2;
  goto interrupt_2;
 }

 structarity_2_top: {
  q x0;
  qp = qp->next;
 structarity_2_clear_reason:
  reasonp = reasons;
 structarity_2_0:
 structarity_2_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto structarity_2_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom__2A)):
  x0 = makesym(atom__2A);
  unify_value(a1, x0);
  proceed();
 case symval(makesym(atom_i)):
  x0 = makesym(atom__2A);
  unify_value(a1, x0);
  proceed();
  };
  goto structarity_2_interrupt;
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_i_1)) goto structarity_2_interrupt;
  x0 = arg(a0, 0);
  unify(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,structarity_2_1);
  *reasonp++ =  a0;
  goto structarity_2_interrupt;
  };
  goto structarity_2_interrupt;
 structarity_2_ext_interrupt:
  reasonp = 0l;
 structarity_2_interrupt:
  goto interrupt_2;
 }

 update__functor__type_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 update__functor__type_4_clear_reason:
  reasonp = reasons;
 update__functor__type_4_0:
 update__functor__type_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 update__functor__type_4_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto update__functor__type_4_4;
  x1 = cdr_of(a0);
 update__functor__type_4_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto update__functor__type_4_4;
  x2 = makecons(cons_const_0);
  unify_value(a1, x2);
  x3 = makecons(cons_const_0);
  unify_value(a2, x3);
  proceed();
 case VARREF:
  deref_and_jump(x1,update__functor__type_4_3);
  *reasonp++ =  x1;
  goto update__functor__type_4_4;
  };
  goto update__functor__type_4_4;
 case VARREF:
  deref_and_jump(x0,update__functor__type_4_2);
  *reasonp++ =  x0;
  goto update__functor__type_4_4;
  };
  goto update__functor__type_4_4;
 case VARREF:
  deref_and_jump(a0,update__functor__type_4_1);
  *reasonp++ =  a0;
  goto update__functor__type_4_4;
  };
  goto update__functor__type_4_4;
 update__functor__type_4_4:
  otherwise(update__functor__type_4_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xadd__dgoal_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a3;
  allocp[4] = a2;
  allocp[5] = makesym(atom_normal);
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_typeset_xadd__dgoal_4);
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a3;
  allocp[10] = a1;
  allocp[11] = makesym(atom_normal);
  a1 = NILATOM;
  a2 = x1;
  a3 = NILATOM;
  a4 = x0;
  qp = (struct goalrec*)&allocp[6];
  allocp += 12;
  execute(update__functor__type_5_0);
  goto update__functor__type_5_ext_interrupt;
 update__functor__type_4_ext_interrupt:
  reasonp = 0l;
 update__functor__type_4_interrupt:
  goto interrupt_4;
 }

 update__functor__type_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 update__functor__type_5_clear_reason:
  reasonp = reasons;
 update__functor__type_5_0:
 update__functor__type_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 update__functor__type_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_2)) goto update__functor__type_5_5;
  x1 = arg(x0, 0);
 update__functor__type_5_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_s_3)) goto update__functor__type_5_5;
  x2 = arg(x1, 0);
 update__functor__type_5_4:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != makesym(atom___v)) goto update__functor__type_5_5;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin_xupdate__functor__type_5);
  x3 = cdr_of(a0);
  allocp[2] = x3;
  allocp[3] = x4 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x5 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[9] = a3;
  allocp[10] = makecons(cons_const_11);
  allocp[11] = x5;
  allocp[12] = makesym(functor_t_2);
  allocp[13] = x1;
  allocp[14] = NILATOM;
  x6 = makefunctor(&allocp[12]);
  allocp[15] = NILATOM;
  allocp[16] = x6;
  x7 = makecons(&allocp[15]);
  allocp[17] = (q)(struct goalrec*)&allocp[7];
  allocp[18] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[19] = a1;
  allocp[20] = x7;
  allocp[21] = x4;
  qp = (struct goalrec*)&allocp[17];
  allocp += 22;
  proceed();
 case VARREF:
  deref_and_jump(x2,update__functor__type_5_4);
  *reasonp++ =  x2;
  goto update__functor__type_5_5;
  };
  goto update__functor__type_5_5;
 case VARREF:
  deref_and_jump(x1,update__functor__type_5_3);
  *reasonp++ =  x1;
  goto update__functor__type_5_5;
  };
  goto update__functor__type_5_5;
 case VARREF:
  deref_and_jump(x0,update__functor__type_5_2);
  *reasonp++ =  x0;
  goto update__functor__type_5_5;
  };
  goto update__functor__type_5_5;
 case VARREF:
  deref_and_jump(a0,update__functor__type_5_1);
  *reasonp++ =  a0;
  goto update__functor__type_5_5;
  };
  goto update__functor__type_5_5;
 update__functor__type_5_5:
  otherwise(update__functor__type_5_interrupt);
 update__functor__type_5_6:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 update__functor__type_5_7:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_2)) goto update__functor__type_5_9;
  x1 = arg(x0, 0);
 update__functor__type_5_8:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_s_3)) goto update__functor__type_5_9;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin_xupdate__functor__type_5);
  x2 = cdr_of(a0);
  allocp[2] = x2;
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x4 = makeref(&allocp[5]);
  allocp[6] = a4;
  a0 = arg(x1, 0);
  x5 = arg(x1, 1);
  a2 = a1;
  a4 = a3;
  a5 = x4;
  a3 = x3;
  a1 = x5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(update__functor__type_6_0);
  goto update__functor__type_6_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,update__functor__type_5_8);
  *reasonp++ =  x1;
  goto update__functor__type_5_9;
  };
  goto update__functor__type_5_9;
 case VARREF:
  deref_and_jump(x0,update__functor__type_5_7);
  *reasonp++ =  x0;
  goto update__functor__type_5_9;
  };
  goto update__functor__type_5_9;
 case VARREF:
  deref_and_jump(a0,update__functor__type_5_6);
  *reasonp++ =  a0;
  goto update__functor__type_5_9;
  };
  goto update__functor__type_5_9;
 update__functor__type_5_9:
  otherwise(update__functor__type_5_interrupt);
 update__functor__type_5_10:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 update__functor__type_5_11:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_t_2:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin_xupdate__functor__type_5);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[9] = a3;
  allocp[10] = makecons(cons_const_11);
  allocp[11] = x3;
  allocp[12] = makesym(functor_t_2);
  x5 = arg(x0, 0);
  allocp[13] = x5;
  allocp[14] = NILATOM;
  x4 = makefunctor(&allocp[12]);
  allocp[15] = NILATOM;
  allocp[16] = x4;
  x6 = makecons(&allocp[15]);
  allocp[17] = (q)(struct goalrec*)&allocp[7];
  allocp[18] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[19] = a1;
  allocp[20] = x6;
  allocp[21] = x2;
  qp = (struct goalrec*)&allocp[17];
  allocp += 22;
  proceed();
 case functor_tv_2:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin_xupdate__functor__type_5);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[9] = a3;
  allocp[10] = makecons(cons_const_11);
  allocp[11] = x3;
  allocp[12] = makesym(functor_tv_2);
  x5 = arg(x0, 0);
  allocp[13] = x5;
  allocp[14] = NILATOM;
  x4 = makefunctor(&allocp[12]);
  allocp[15] = NILATOM;
  allocp[16] = x4;
  x6 = makecons(&allocp[15]);
  allocp[17] = (q)(struct goalrec*)&allocp[7];
  allocp[18] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[19] = a1;
  allocp[20] = x6;
  allocp[21] = x2;
  qp = (struct goalrec*)&allocp[17];
  allocp += 22;
  proceed();
  };
  goto update__functor__type_5_interrupt;
 case VARREF:
  deref_and_jump(x0,update__functor__type_5_11);
  *reasonp++ =  x0;
  goto update__functor__type_5_interrupt;
  };
  goto update__functor__type_5_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto update__functor__type_5_interrupt;
  unify2(a2, a1, a4, a3);
  proceed();
 case VARREF:
  deref_and_jump(a0,update__functor__type_5_10);
  *reasonp++ =  a0;
  goto update__functor__type_5_interrupt;
  };
  goto update__functor__type_5_interrupt;
 update__functor__type_5_ext_interrupt:
  reasonp = 0l;
 update__functor__type_5_interrupt:
  toppred = &predicate_builtin_xupdate__functor__type_5;
  goto interrupt_5;
 }

 update__functor__type_6_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 update__functor__type_6_clear_reason:
  reasonp = reasons;
 update__functor__type_6_0:
 update__functor__type_6_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom__2A)) goto update__functor__type_6_4;
 update__functor__type_6_2:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (isint(a1)) goto update__functor__type_6_3;
  if (a1 != makesym(atom__2A)) goto update__functor__type_6_4;
  unify(a3, a2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[2] = a4;
  allocp[3] = makecons(cons_const_2);
  allocp[4] = a5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 update__functor__type_6_3:
  gblt_integer(a1,update__functor__type_6_4);
  unify(a3, a2);
  allocp[0] = makesym(functor_i_1);
  allocp[1] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_t_2);
  allocp[3] = x0;
  allocp[4] = NILATOM;
  x1 = makefunctor(&allocp[2]);
  allocp[5] = NILATOM;
  allocp[6] = x1;
  x2 = makecons(&allocp[5]);
  allocp[7] = (q)qp;
  allocp[8] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[9] = a4;
  allocp[10] = x2;
  allocp[11] = a5;
  qp = (struct goalrec*)&allocp[7];
  allocp += 12;
  proceed();
 case VARREF:
  deref_and_jump(a1,update__functor__type_6_2);
  *reasonp++ =  a1;
  goto update__functor__type_6_4;
  };
  goto update__functor__type_6_4;
 case VARREF:
  deref_and_jump(a0,update__functor__type_6_1);
  *reasonp++ =  a0;
  goto update__functor__type_6_4;
  };
  goto update__functor__type_6_4;
 update__functor__type_6_4:
  otherwise(update__functor__type_6_interrupt);
 update__functor__type_6_5:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (isint(a1)) goto update__functor__type_6_6;
  if (a1 != makesym(atom__2A)) goto update__functor__type_6_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[2] = a4;
  allocp[3] = makecons(cons_const_2);
  allocp[4] = a5;
  allocp[5] = makesym(functor_a_1);
  allocp[6] = a0;
  x0 = makefunctor(&allocp[5]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = x0;
  allocp[9] = NILATOM;
  x1 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x1;
  x2 = makecons(&allocp[10]);
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[14] = a2;
  allocp[15] = x2;
  allocp[16] = a3;
  qp = (struct goalrec*)&allocp[12];
  allocp += 17;
  proceed();
 update__functor__type_6_6:
  gblt_integer(a1,update__functor__type_6_interrupt);
  allocp[0] = makesym(functor_i_1);
  allocp[1] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_t_2);
  allocp[3] = x0;
  allocp[4] = NILATOM;
  x1 = makefunctor(&allocp[2]);
  allocp[5] = NILATOM;
  allocp[6] = x1;
  x2 = makecons(&allocp[5]);
  allocp[7] = (q)qp;
  allocp[8] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[9] = a4;
  allocp[10] = x2;
  allocp[11] = a5;
  allocp[12] = makesym(functor_a_1);
  allocp[13] = a0;
  x3 = makefunctor(&allocp[12]);
  allocp[14] = makesym(functor_t_2);
  allocp[15] = x3;
  allocp[16] = NILATOM;
  x4 = makefunctor(&allocp[14]);
  allocp[17] = NILATOM;
  allocp[18] = x4;
  x5 = makecons(&allocp[17]);
  allocp[19] = (q)(struct goalrec*)&allocp[7];
  allocp[20] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[21] = a2;
  allocp[22] = x5;
  allocp[23] = a3;
  qp = (struct goalrec*)&allocp[19];
  allocp += 24;
  proceed();
 case VARREF:
  deref_and_jump(a1,update__functor__type_6_5);
  *reasonp++ =  a1;
  goto update__functor__type_6_interrupt;
  };
  goto update__functor__type_6_interrupt;
 update__functor__type_6_ext_interrupt:
  reasonp = 0l;
 update__functor__type_6_interrupt:
  toppred = &predicate_builtin_xupdate__functor__type_6;
  goto interrupt_6;
 }

 update__arg__type_4_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 update__arg__type_4_clear_reason:
  reasonp = reasons;
 update__arg__type_4_0:
 update__arg__type_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom__2A)) goto update__arg__type_4_2;
  x0 = makecons(cons_const_0);
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,update__arg__type_4_1);
  *reasonp++ =  a0;
  goto update__arg__type_4_2;
  };
  goto update__arg__type_4_2;
 update__arg__type_4_2:
 update__arg__type_4_3:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 update__arg__type_4_4:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto update__arg__type_4_6;
  x1 = cdr_of(a1);
 update__arg__type_4_5:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto update__arg__type_4_6;
  x2 = makecons(cons_const_0);
  unify_value(a2, x2);
  proceed();
 case VARREF:
  deref_and_jump(x1,update__arg__type_4_5);
  *reasonp++ =  x1;
  goto update__arg__type_4_6;
  };
  goto update__arg__type_4_6;
 case VARREF:
  deref_and_jump(x0,update__arg__type_4_4);
  *reasonp++ =  x0;
  goto update__arg__type_4_6;
  };
  goto update__arg__type_4_6;
 case VARREF:
  deref_and_jump(a1,update__arg__type_4_3);
  *reasonp++ =  a1;
  goto update__arg__type_4_6;
  };
  goto update__arg__type_4_6;
 update__arg__type_4_6:
  otherwise(update__arg__type_4_interrupt);
 update__arg__type_4_7:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 update__arg__type_4_8:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto update__arg__type_4_9;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = makecons(cons_const_0);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_typeset_xadd__dgoal_4);
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = a3;
  allocp[9] = x1;
  allocp[10] = makesym(atom_normal);
  a2 = NILATOM;
  a3 = x2;
  qp = (struct goalrec*)&allocp[5];
  allocp += 11;
  execute(update__arg__type1_4_0);
  goto update__arg__type1_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,update__arg__type_4_8);
  *reasonp++ =  x0;
  goto update__arg__type_4_9;
  };
  goto update__arg__type_4_9;
 case VARREF:
  deref_and_jump(a1,update__arg__type_4_7);
  *reasonp++ =  a1;
  goto update__arg__type_4_9;
  };
  goto update__arg__type_4_9;
 update__arg__type_4_9:
  otherwise(update__arg__type_4_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xadd__dgoal_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a3;
  allocp[4] = a2;
  allocp[5] = makesym(atom_normal);
  a2 = NILATOM;
  a3 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(update__arg__type1_4_0);
  goto update__arg__type1_4_ext_interrupt;
 update__arg__type_4_ext_interrupt:
  reasonp = 0l;
 update__arg__type_4_interrupt:
  goto interrupt_4;
 }

 update__arg__type1_4_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 update__arg__type1_4_clear_reason:
  reasonp = reasons;
 update__arg__type1_4_0:
 update__arg__type1_4_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 update__arg__type1_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_2)) goto update__arg__type1_4_5;
  x1 = arg(x0, 0);
 update__arg__type1_4_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_s_3)) goto update__arg__type1_4_5;
  x2 = arg(x1, 1);
 update__arg__type1_4_4:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != makesym(atom__2A)) goto update__arg__type1_4_5;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin_xupdate__arg__type1_4);
  allocp[2] = a0;
  x3 = cdr_of(a1);
  allocp[3] = x3;
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[8] = a2;
  x5 = arg(x1, 2);
  allocp[9] = x5;
  allocp[10] = x4;
  qp = (struct goalrec*)&allocp[6];
  allocp += 11;
  proceed();
 case VARREF:
  deref_and_jump(x2,update__arg__type1_4_4);
  *reasonp++ =  x2;
  goto update__arg__type1_4_5;
  };
  goto update__arg__type1_4_5;
 case VARREF:
  deref_and_jump(x1,update__arg__type1_4_3);
  *reasonp++ =  x1;
  goto update__arg__type1_4_5;
  };
  goto update__arg__type1_4_5;
 case VARREF:
  deref_and_jump(x0,update__arg__type1_4_2);
  *reasonp++ =  x0;
  goto update__arg__type1_4_5;
  };
  goto update__arg__type1_4_5;
 case VARREF:
  deref_and_jump(a1,update__arg__type1_4_1);
  *reasonp++ =  a1;
  goto update__arg__type1_4_5;
  };
  goto update__arg__type1_4_5;
 update__arg__type1_4_5:
  otherwise(update__arg__type1_4_interrupt);
 update__arg__type1_4_6:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 update__arg__type1_4_7:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_2)) goto update__arg__type1_4_10;
  x1 = arg(x0, 0);
 update__arg__type1_4_8:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_s_3)) goto update__arg__type1_4_10;
 update__arg__type1_4_9:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_i_1)) goto update__arg__type1_4_10;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin_xupdate__arg__type1_4);
  allocp[2] = a0;
  x2 = cdr_of(a1);
  allocp[3] = x2;
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[8] = a2;
  allocp[9] = x4 = makeref(&allocp[9]);
  allocp[10] = x3;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_functor__table_xarg_3);
  x5 = arg(a0, 0);
  allocp[13] = x5;
  x6 = arg(x1, 2);
  allocp[14] = x6;
  allocp[15] = x4;
  qp = (struct goalrec*)&allocp[11];
  allocp += 16;
  proceed();
 case VARREF:
  deref_and_jump(a0,update__arg__type1_4_9);
  *reasonp++ =  a0;
  goto update__arg__type1_4_10;
  };
  goto update__arg__type1_4_10;
 case VARREF:
  deref_and_jump(x1,update__arg__type1_4_8);
  *reasonp++ =  x1;
  goto update__arg__type1_4_10;
  };
  goto update__arg__type1_4_10;
 case VARREF:
  deref_and_jump(x0,update__arg__type1_4_7);
  *reasonp++ =  x0;
  goto update__arg__type1_4_10;
  };
  goto update__arg__type1_4_10;
 case VARREF:
  deref_and_jump(a1,update__arg__type1_4_6);
  *reasonp++ =  a1;
  goto update__arg__type1_4_10;
  };
  goto update__arg__type1_4_10;
 update__arg__type1_4_10:
  otherwise(update__arg__type1_4_interrupt);
 update__arg__type1_4_11:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 update__arg__type1_4_12:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_2)) goto update__arg__type1_4_14;
  x1 = arg(x0, 0);
 update__arg__type1_4_13:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_s_3)) goto update__arg__type1_4_14;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin_xupdate__arg__type1_4);
  allocp[2] = a0;
  x2 = cdr_of(a1);
  allocp[3] = x2;
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = a3;
  a0 = arg(x1, 1);
  a1 = arg(x1, 2);
  a3 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(merge__arg__type_4_0);
  goto merge__arg__type_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,update__arg__type1_4_13);
  *reasonp++ =  x1;
  goto update__arg__type1_4_14;
  };
  goto update__arg__type1_4_14;
 case VARREF:
  deref_and_jump(x0,update__arg__type1_4_12);
  *reasonp++ =  x0;
  goto update__arg__type1_4_14;
  };
  goto update__arg__type1_4_14;
 case VARREF:
  deref_and_jump(a1,update__arg__type1_4_11);
  *reasonp++ =  a1;
  goto update__arg__type1_4_14;
  };
  goto update__arg__type1_4_14;
 update__arg__type1_4_14:
  otherwise(update__arg__type1_4_interrupt);
 update__arg__type1_4_15:
  switch (ptagof(a1)) {
 case CONS:
  a1 = cdr_of(a1);
  execute(update__arg__type1_4_0);
  goto update__arg__type1_4_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto update__arg__type1_4_interrupt;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a1,update__arg__type1_4_15);
  *reasonp++ =  a1;
  goto update__arg__type1_4_interrupt;
  };
  goto update__arg__type1_4_interrupt;
 update__arg__type1_4_ext_interrupt:
  reasonp = 0l;
 update__arg__type1_4_interrupt:
  toppred = &predicate_builtin_xupdate__arg__type1_4;
  goto interrupt_4;
 }

 merge__arg__type_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 merge__arg__type_4_clear_reason:
  reasonp = reasons;
 merge__arg__type_4_0:
 merge__arg__type_4_1:
  if (!isint(a0)) goto merge__arg__type_4_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,merge__arg__type_4_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin_xmerge__arg__type_4);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x1;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[13] = a2;
  allocp[14] = x3 = makeref(&allocp[14]);
  allocp[15] = x2;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_functor__table_xarg_3);
  allocp[18] = a0;
  allocp[19] = a1;
  allocp[20] = x3;
  qp = (struct goalrec*)&allocp[16];
  allocp += 21;
  proceed();
 merge__arg__type_4_2:
  if (a0 != makeint(0L)) goto merge__arg__type_4_interrupt;
  unify(a3, a2);
  proceed();
 merge__arg__type_4_3:
  if (!isref(a0)) goto merge__arg__type_4_interrupt;
  deref_and_jump(a0,merge__arg__type_4_1);
  *reasonp++ =  a0;
  goto merge__arg__type_4_interrupt;
 merge__arg__type_4_ext_interrupt:
  reasonp = 0l;
 merge__arg__type_4_interrupt:
  toppred = &predicate_builtin_xmerge__arg__type_4;
  goto interrupt_4;
 }

 update__setarg_6_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 update__setarg_6_clear_reason:
  reasonp = reasons;
 update__setarg_6_0:
 update__setarg_6_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom__2A)) goto update__setarg_6_2;
  x0 = makecons(cons_const_0);
  unify_value(a3, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,update__setarg_6_1);
  *reasonp++ =  a0;
  goto update__setarg_6_2;
  };
  goto update__setarg_6_2;
 update__setarg_6_2:
 update__setarg_6_3:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 update__setarg_6_4:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto update__setarg_6_6;
  x1 = cdr_of(a1);
 update__setarg_6_5:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto update__setarg_6_6;
  x2 = makecons(cons_const_0);
  unify_value(a3, x2);
  proceed();
 case VARREF:
  deref_and_jump(x1,update__setarg_6_5);
  *reasonp++ =  x1;
  goto update__setarg_6_6;
  };
  goto update__setarg_6_6;
 case VARREF:
  deref_and_jump(x0,update__setarg_6_4);
  *reasonp++ =  x0;
  goto update__setarg_6_6;
  };
  goto update__setarg_6_6;
 case VARREF:
  deref_and_jump(a1,update__setarg_6_3);
  *reasonp++ =  a1;
  goto update__setarg_6_6;
  };
  goto update__setarg_6_6;
 update__setarg_6_6:
 update__setarg_6_7:
  switch (ptagof(a2)) {
 case CONS:
  x0 = car_of(a2);
 update__setarg_6_8:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto update__setarg_6_10;
  x1 = cdr_of(a2);
 update__setarg_6_9:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto update__setarg_6_10;
  x2 = makecons(cons_const_0);
  unify_value(a3, x2);
  proceed();
 case VARREF:
  deref_and_jump(x1,update__setarg_6_9);
  *reasonp++ =  x1;
  goto update__setarg_6_10;
  };
  goto update__setarg_6_10;
 case VARREF:
  deref_and_jump(x0,update__setarg_6_8);
  *reasonp++ =  x0;
  goto update__setarg_6_10;
  };
  goto update__setarg_6_10;
 case VARREF:
  deref_and_jump(a2,update__setarg_6_7);
  *reasonp++ =  a2;
  goto update__setarg_6_10;
  };
  goto update__setarg_6_10;
 update__setarg_6_10:
  otherwise(update__setarg_6_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xadd__dgoal_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a4;
  allocp[5] = makesym(atom_normal);
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_typeset_xadd__dgoal_4);
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = x1;
  allocp[10] = a3;
  allocp[11] = makesym(atom_normal);
  a3 = NILATOM;
  a4 = x2;
  a5 = NILATOM;
  a6 = x0;
  a7 = x1;
  qp = (struct goalrec*)&allocp[6];
  allocp += 12;
  execute(update__setarg_8_0);
  goto update__setarg_8_ext_interrupt;
 update__setarg_6_ext_interrupt:
  reasonp = 0l;
 update__setarg_6_interrupt:
  goto interrupt_6;
 }

 update__setarg_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 update__setarg_8_clear_reason:
  reasonp = reasons;
 update__setarg_8_0:
 update__setarg_8_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 update__setarg_8_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto update__setarg_8_8;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin_xupdate__setarg_8);
  allocp[2] = a0;
  x1 = cdr_of(a1);
  allocp[3] = x1;
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[12] = a5;
  allocp[13] = makecons(cons_const_0);
  allocp[14] = x3;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[17] = a3;
  allocp[18] = makecons(cons_const_0);
  allocp[19] = x2;
  qp = (struct goalrec*)&allocp[15];
  allocp += 20;
  proceed();
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_2)) goto update__setarg_8_8;
  x1 = arg(x0, 0);
 update__setarg_8_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_s_3)) goto update__setarg_8_8;
 update__setarg_8_4:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_i_1)) goto update__setarg_8_5;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin_xupdate__setarg_8);
  allocp[2] = a0;
  x2 = cdr_of(a1);
  allocp[3] = x2;
  allocp[4] = a2;
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x4 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[12] = a5;
  allocp[13] = x5 = makeref(&allocp[13]);
  allocp[14] = x4;
  allocp[15] = NILATOM;
  allocp[16] = x7 = makeref(&allocp[16]);
  x6 = makecons(&allocp[15]);
  allocp[17] = (q)(struct goalrec*)&allocp[10];
  allocp[18] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[19] = a3;
  allocp[20] = x6;
  allocp[21] = x3;
  allocp[22] = (q)(struct goalrec*)&allocp[17];
  allocp[23] = (q)(&predicate_typeset_xset__struct__arg__typeset_4);
  x8 = arg(a0, 0);
  allocp[24] = x8;
  allocp[25] = x0;
  allocp[26] = x9 = makeref(&allocp[26]);
  allocp[27] = x7;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_typeset_xget__struct__arg__typeset_3);
  allocp[30] = x8;
  allocp[31] = x0;
  allocp[32] = x5;
  qp = (struct goalrec*)&allocp[28];
  allocp += 33;
  proceed();
 case VARREF:
  deref_and_jump(a0,update__setarg_8_4);
  *reasonp++ =  a0;
  goto update__setarg_8_5;
  };
  goto update__setarg_8_5;
 update__setarg_8_5:
  x2 = arg(x1, 1);
 update__setarg_8_6:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != makesym(atom__2A)) goto update__setarg_8_8;
 update__setarg_8_7:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_i)) goto update__setarg_8_8;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin_xupdate__setarg_8);
  allocp[2] = a0;
  x3 = cdr_of(a1);
  allocp[3] = x3;
  allocp[4] = a2;
  allocp[5] = x4 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x5 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[12] = a5;
  x6 = arg(x1, 2);
  allocp[13] = x6;
  allocp[14] = x5;
  allocp[15] = makesym(functor_s_3);
  x8 = arg(x1, 0);
  allocp[16] = x8;
  allocp[17] = makesym(atom__2A);
  allocp[18] = x9 = makeref(&allocp[18]);
  x7 = makefunctor(&allocp[15]);
  allocp[19] = makesym(functor_t_2);
  allocp[20] = x7;
  x11 = arg(x0, 1);
  allocp[21] = x11;
  x10 = makefunctor(&allocp[19]);
  allocp[22] = NILATOM;
  allocp[23] = x10;
  x12 = makecons(&allocp[22]);
  allocp[24] = (q)(struct goalrec*)&allocp[10];
  allocp[25] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[26] = a3;
  allocp[27] = x12;
  allocp[28] = x4;
  allocp[29] = (q)(struct goalrec*)&allocp[24];
  allocp[30] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[31] = x6;
  allocp[32] = a2;
  allocp[33] = x9;
  qp = (struct goalrec*)&allocp[29];
  allocp += 34;
  proceed();
 case VARREF:
  deref_and_jump(a0,update__setarg_8_7);
  *reasonp++ =  a0;
  goto update__setarg_8_8;
  };
  goto update__setarg_8_8;
 case VARREF:
  deref_and_jump(x2,update__setarg_8_6);
  *reasonp++ =  x2;
  goto update__setarg_8_8;
  };
  goto update__setarg_8_8;
 case VARREF:
  deref_and_jump(x1,update__setarg_8_3);
  *reasonp++ =  x1;
  goto update__setarg_8_8;
  };
  goto update__setarg_8_8;
 case VARREF:
  deref_and_jump(x0,update__setarg_8_2);
  *reasonp++ =  x0;
  goto update__setarg_8_8;
  };
  goto update__setarg_8_8;
 case VARREF:
  deref_and_jump(a1,update__setarg_8_1);
  *reasonp++ =  a1;
  goto update__setarg_8_8;
  };
  goto update__setarg_8_8;
 update__setarg_8_8:
  otherwise(update__setarg_8_interrupt);
 update__setarg_8_9:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 update__setarg_8_10:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_2)) goto update__setarg_8_interrupt;
  x1 = arg(x0, 0);
 update__setarg_8_11:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_s_3)) goto update__setarg_8_interrupt;
 update__setarg_8_12:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_i)) goto update__setarg_8_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin_xupdate__setarg_8);
  allocp[2] = a0;
  x2 = cdr_of(a1);
  allocp[3] = x2;
  allocp[4] = a2;
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x4 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = makesym(functor_s_3);
  x6 = arg(x1, 0);
  allocp[11] = x6;
  x7 = arg(x1, 1);
  allocp[12] = x7;
  allocp[13] = x8 = makeref(&allocp[13]);
  x5 = makefunctor(&allocp[10]);
  allocp[14] = makesym(functor_t_2);
  allocp[15] = x5;
  x10 = arg(x0, 1);
  allocp[16] = x10;
  x9 = makefunctor(&allocp[14]);
  allocp[17] = NILATOM;
  allocp[18] = x9;
  x11 = makecons(&allocp[17]);
  allocp[19] = (q)(struct goalrec*)&allocp[0];
  allocp[20] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[21] = a3;
  allocp[22] = x11;
  allocp[23] = x3;
  a0 = arg(x1, 1);
  a1 = a2;
  a2 = arg(x1, 2);
  a3 = x8;
  a4 = a5;
  a5 = x4;
  qp = (struct goalrec*)&allocp[19];
  allocp += 24;
  execute(update__setarg2_6_0);
  goto update__setarg2_6_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,update__setarg_8_12);
  *reasonp++ =  a0;
  goto update__setarg_8_interrupt;
  };
  goto update__setarg_8_interrupt;
 case VARREF:
  deref_and_jump(x1,update__setarg_8_11);
  *reasonp++ =  x1;
  goto update__setarg_8_interrupt;
  };
  goto update__setarg_8_interrupt;
 case VARREF:
  deref_and_jump(x0,update__setarg_8_10);
  *reasonp++ =  x0;
  goto update__setarg_8_interrupt;
  };
  goto update__setarg_8_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto update__setarg_8_interrupt;
  unify2(a4, a3, a6, a5);
  proceed();
 case VARREF:
  deref_and_jump(a1,update__setarg_8_9);
  *reasonp++ =  a1;
  goto update__setarg_8_interrupt;
  };
  goto update__setarg_8_interrupt;
 update__setarg_8_ext_interrupt:
  reasonp = 0l;
 update__setarg_8_interrupt:
  toppred = &predicate_builtin_xupdate__setarg_8;
  goto interrupt_8;
 }

 update__setarg2_6_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 update__setarg2_6_clear_reason:
  reasonp = reasons;
 update__setarg2_6_0:
 update__setarg2_6_1:
  if (!isint(a0)) goto update__setarg2_6_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,update__setarg2_6_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin_xupdate__setarg2_6);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[10] = a0;
  allocp[11] = makeint(1L);
  allocp[12] = x1;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[15] = a0;
  allocp[16] = a2;
  allocp[17] = x4 = makeref(&allocp[17]);
  allocp[18] = x2;
  allocp[19] = (q)(struct goalrec*)&allocp[13];
  allocp[20] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[21] = x5 = makeref(&allocp[21]);
  allocp[22] = a1;
  allocp[23] = x4;
  allocp[24] = (q)(struct goalrec*)&allocp[19];
  allocp[25] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[26] = a4;
  allocp[27] = x5;
  allocp[28] = x3;
  allocp[29] = (q)(struct goalrec*)&allocp[24];
  allocp[30] = (q)(&predicate_functor__table_xarg_3);
  allocp[31] = a0;
  allocp[32] = a2;
  allocp[33] = x5;
  qp = (struct goalrec*)&allocp[29];
  allocp += 34;
  proceed();
 update__setarg2_6_2:
  if (a0 != makeint(0L)) goto update__setarg2_6_interrupt;
  unify2(a3, a2, a5, a4);
  proceed();
 update__setarg2_6_3:
  if (!isref(a0)) goto update__setarg2_6_interrupt;
  deref_and_jump(a0,update__setarg2_6_1);
  *reasonp++ =  a0;
  goto update__setarg2_6_interrupt;
 update__setarg2_6_ext_interrupt:
  reasonp = 0l;
 update__setarg2_6_interrupt:
  toppred = &predicate_builtin_xupdate__setarg2_6;
  goto interrupt_6;
 }

 update__newvector_4_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 update__newvector_4_clear_reason:
  reasonp = reasons;
 update__newvector_4_0:
  x0 = a2;
  a4 = a3;
  a3 = x0;
  a2 = NILATOM;
  execute(update__newvector_5_0);
  goto update__newvector_5_ext_interrupt;
 update__newvector_4_ext_interrupt:
  reasonp = 0l;
 update__newvector_4_interrupt:
  goto interrupt_4;
 }

 update__newvector_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 update__newvector_5_clear_reason:
  reasonp = reasons;
 update__newvector_5_0:
 update__newvector_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom__2A)) goto update__newvector_5_5;
 update__newvector_5_2:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 update__newvector_5_3:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto update__newvector_5_5;
  x1 = cdr_of(a1);
 update__newvector_5_4:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto update__newvector_5_5;
  allocp[0] = a2;
  allocp[1] = makesym(atom__2A);
  x2 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a3, x2);
  proceed();
 case VARREF:
  deref_and_jump(x1,update__newvector_5_4);
  *reasonp++ =  x1;
  goto update__newvector_5_5;
  };
  goto update__newvector_5_5;
 case VARREF:
  deref_and_jump(x0,update__newvector_5_3);
  *reasonp++ =  x0;
  goto update__newvector_5_5;
  };
  goto update__newvector_5_5;
 case ATOMIC:
  if (a1 != NILATOM) goto update__newvector_5_5;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a1,update__newvector_5_2);
  *reasonp++ =  a1;
  goto update__newvector_5_5;
  };
  goto update__newvector_5_5;
 case VARREF:
  deref_and_jump(a0,update__newvector_5_1);
  *reasonp++ =  a0;
  goto update__newvector_5_5;
  };
  goto update__newvector_5_5;
 update__newvector_5_5:
 update__newvector_5_6:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 update__newvector_5_7:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto update__newvector_5_9;
  x1 = cdr_of(a1);
 update__newvector_5_8:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto update__newvector_5_9;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(x1,update__newvector_5_8);
  *reasonp++ =  x1;
  goto update__newvector_5_9;
  };
  goto update__newvector_5_9;
 case VARREF:
  deref_and_jump(x0,update__newvector_5_7);
  *reasonp++ =  x0;
  goto update__newvector_5_9;
  };
  goto update__newvector_5_9;
 case ATOMIC:
  if (a1 != NILATOM) goto update__newvector_5_9;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a1,update__newvector_5_6);
  *reasonp++ =  a1;
  goto update__newvector_5_9;
  };
  goto update__newvector_5_9;
 update__newvector_5_9:
  otherwise(update__newvector_5_interrupt);
 update__newvector_5_10:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_i)) goto update__newvector_5_11;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin_xupdate__newvector_5);
  allocp[2] = NILATOM;
  allocp[3] = a1;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[9] = a2;
  allocp[10] = makecons(cons_const_8);
  allocp[11] = x0;
  qp = (struct goalrec*)&allocp[7];
  allocp += 12;
  proceed();
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_i_1)) goto update__newvector_5_11;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin_xupdate__newvector_5);
  allocp[2] = NILATOM;
  allocp[3] = a1;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = makesym(functor_s_3);
  allocp[8] = makesym(atom___v);
  x2 = arg(a0, 0);
  allocp[9] = x2;
  allocp[10] = x3 = makeref(&allocp[10]);
  x1 = makefunctor(&allocp[7]);
  allocp[11] = NILATOM;
  allocp[12] = a4;
  x4 = makecons(&allocp[11]);
  allocp[13] = makesym(functor_t_2);
  allocp[14] = x1;
  allocp[15] = x4;
  x5 = makefunctor(&allocp[13]);
  allocp[16] = NILATOM;
  allocp[17] = x5;
  x6 = makecons(&allocp[16]);
  allocp[18] = (q)(struct goalrec*)&allocp[0];
  allocp[19] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[20] = a2;
  allocp[21] = x6;
  allocp[22] = x0;
  allocp[23] = NILATOM;
  allocp[24] = a4;
  x7 = makecons(&allocp[23]);
  allocp[25] = makesym(functor_t_2);
  allocp[26] = makefunctor(funct_const_12);
  allocp[27] = x7;
  x8 = makefunctor(&allocp[25]);
  allocp[28] = NILATOM;
  allocp[29] = x8;
  x9 = makecons(&allocp[28]);
  allocp[30] = (q)(struct goalrec*)&allocp[18];
  allocp[31] = (q)(&predicate_functor_xnew__functor__init_4);
  allocp[32] = makesym(atom_arg);
  x10 = arg(a0, 0);
  allocp[33] = x10;
  allocp[34] = x9;
  allocp[35] = x3;
  qp = (struct goalrec*)&allocp[30];
  allocp += 36;
  proceed();
 case VARREF:
  deref_and_jump(a0,update__newvector_5_10);
  *reasonp++ =  a0;
  goto update__newvector_5_11;
  };
  goto update__newvector_5_11;
 update__newvector_5_11:
 update__newvector_5_12:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 update__newvector_5_13:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_2)) goto update__newvector_5_18;
  x1 = arg(x0, 0);
 update__newvector_5_14:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_s_3)) goto update__newvector_5_18;
  x2 = arg(x1, 0);
 update__newvector_5_15:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != PERIODATOM) goto update__newvector_5_18;
  x3 = arg(x1, 1);
 update__newvector_5_16:
  switch (ptagof(x3)) {
 case ATOMIC:
 update__newvector_5_17:
  if (x3 != makeint(2L)) goto update__newvector_5_18;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin_xupdate__newvector_5);
  allocp[2] = a0;
  x4 = cdr_of(a1);
  allocp[3] = x4;
  allocp[4] = x5 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_builtin_xupdate__newvector2_5);
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = x7 = makeref(&allocp[10]);
  allocp[11] = a2;
  allocp[12] = x5;
  allocp[13] = a4;
  allocp[14] = (q)(struct goalrec*)&allocp[7];
  allocp[15] = (q)(&predicate_typeset_xlisttype__val_3);
  allocp[16] = x0;
  allocp[17] = x6;
  allocp[18] = x7;
  qp = (struct goalrec*)&allocp[14];
  allocp += 19;
  proceed();
 case VARREF:
  deref_and_jump(x3,update__newvector_5_16);
  *reasonp++ =  x3;
  goto update__newvector_5_18;
  };
  goto update__newvector_5_18;
 case VARREF:
  deref_and_jump(x2,update__newvector_5_15);
  *reasonp++ =  x2;
  goto update__newvector_5_18;
  };
  goto update__newvector_5_18;
 case VARREF:
  deref_and_jump(x1,update__newvector_5_14);
  *reasonp++ =  x1;
  goto update__newvector_5_18;
  };
  goto update__newvector_5_18;
 case VARREF:
  deref_and_jump(x0,update__newvector_5_13);
  *reasonp++ =  x0;
  goto update__newvector_5_18;
  };
  goto update__newvector_5_18;
 case VARREF:
  deref_and_jump(a1,update__newvector_5_12);
  *reasonp++ =  a1;
  goto update__newvector_5_18;
  };
  goto update__newvector_5_18;
 update__newvector_5_18:
  otherwise(update__newvector_5_interrupt);
  a0 = makesym(atom__2A);
  a1 = makecons(cons_const_0);
  execute(update__newvector_5_0);
  goto update__newvector_5_ext_interrupt;
 update__newvector_5_ext_interrupt:
  reasonp = 0l;
 update__newvector_5_interrupt:
  toppred = &predicate_builtin_xupdate__newvector_5;
  goto interrupt_5;
 }

 update__newvector2_5_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 update__newvector2_5_clear_reason:
  reasonp = reasons;
 update__newvector2_5_0:
 update__newvector2_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto update__newvector2_5_2;
  if (a0 != makesym(atom__2A)) goto update__newvector2_5_interrupt;
  allocp[0] = makesym(functor_s_3);
  allocp[1] = makesym(atom___v);
  allocp[2] = makesym(atom__2A);
  allocp[3] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp[4] = NILATOM;
  allocp[5] = a4;
  x1 = makecons(&allocp[4]);
  allocp[6] = makesym(functor_t_2);
  allocp[7] = x0;
  allocp[8] = x1;
  x2 = makefunctor(&allocp[6]);
  allocp[9] = NILATOM;
  allocp[10] = x2;
  x3 = makecons(&allocp[9]);
  allocp[11] = (q)qp;
  allocp[12] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[13] = a2;
  allocp[14] = x3;
  allocp[15] = a3;
  qp = (struct goalrec*)&allocp[11];
  allocp += 16;
  proceed();
 update__newvector2_5_2:
  gblt_integer(a0,update__newvector2_5_interrupt);
  allocp[0] = makesym(functor_s_3);
  allocp[1] = makesym(atom___v);
  allocp[2] = a0;
  allocp[3] = x1 = makeref(&allocp[3]);
  x0 = makefunctor(&allocp[0]);
  allocp[4] = NILATOM;
  allocp[5] = a4;
  x2 = makecons(&allocp[4]);
  allocp[6] = makesym(functor_t_2);
  allocp[7] = x0;
  allocp[8] = x2;
  x3 = makefunctor(&allocp[6]);
  allocp[9] = NILATOM;
  allocp[10] = x3;
  x4 = makecons(&allocp[9]);
  allocp[11] = (q)qp;
  allocp[12] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[13] = a2;
  allocp[14] = x4;
  allocp[15] = a3;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_functor_xcreate__functor_3);
  allocp[18] = makesym(atom_arg);
  allocp[19] = x5 = makeref(&allocp[19]);
  allocp[20] = x1;
  a0 = a1;
  a1 = a4;
  a2 = x5;
  qp = (struct goalrec*)&allocp[16];
  allocp += 21;
  execute(update__newvector3_3_0);
  goto update__newvector3_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,update__newvector2_5_1);
  *reasonp++ =  a0;
  goto update__newvector2_5_interrupt;
  };
  goto update__newvector2_5_interrupt;
 update__newvector2_5_ext_interrupt:
  reasonp = 0l;
 update__newvector2_5_interrupt:
  goto interrupt_5;
 }

 update__newvector3_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 update__newvector3_3_clear_reason:
  reasonp = reasons;
 update__newvector3_3_0:
 update__newvector3_3_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = a1;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  a0 = cdr_of(a0);
  a2 = x1;
  execute(update__newvector3_3_0);
  goto update__newvector3_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto update__newvector3_3_interrupt;
  x0 = NILATOM;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,update__newvector3_3_1);
  *reasonp++ =  a0;
  goto update__newvector3_3_interrupt;
  };
  goto update__newvector3_3_interrupt;
 update__newvector3_3_ext_interrupt:
  reasonp = 0l;
 update__newvector3_3_interrupt:
  toppred = &predicate_builtin_xupdate__newvector3_3;
  goto interrupt_3;
 }

 update__element__type_4_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 update__element__type_4_clear_reason:
  reasonp = reasons;
 update__element__type_4_0:
 update__element__type_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom__2A)) goto update__element__type_4_2;
  x0 = makecons(cons_const_0);
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,update__element__type_4_1);
  *reasonp++ =  a0;
  goto update__element__type_4_2;
  };
  goto update__element__type_4_2;
 update__element__type_4_2:
 update__element__type_4_3:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 update__element__type_4_4:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto update__element__type_4_6;
  x1 = cdr_of(a1);
 update__element__type_4_5:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto update__element__type_4_6;
  x2 = makecons(cons_const_0);
  unify_value(a2, x2);
  proceed();
 case VARREF:
  deref_and_jump(x1,update__element__type_4_5);
  *reasonp++ =  x1;
  goto update__element__type_4_6;
  };
  goto update__element__type_4_6;
 case VARREF:
  deref_and_jump(x0,update__element__type_4_4);
  *reasonp++ =  x0;
  goto update__element__type_4_6;
  };
  goto update__element__type_4_6;
 case VARREF:
  deref_and_jump(a1,update__element__type_4_3);
  *reasonp++ =  a1;
  goto update__element__type_4_6;
  };
  goto update__element__type_4_6;
 update__element__type_4_6:
  otherwise(update__element__type_4_interrupt);
 update__element__type_4_7:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 update__element__type_4_8:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto update__element__type_4_9;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = makecons(cons_const_0);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_typeset_xadd__dgoal_4);
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = a3;
  allocp[9] = x1;
  allocp[10] = makesym(atom_normal);
  a2 = NILATOM;
  a3 = x2;
  qp = (struct goalrec*)&allocp[5];
  allocp += 11;
  execute(update__element__type1_4_0);
  goto update__element__type1_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,update__element__type_4_8);
  *reasonp++ =  x0;
  goto update__element__type_4_9;
  };
  goto update__element__type_4_9;
 case VARREF:
  deref_and_jump(a1,update__element__type_4_7);
  *reasonp++ =  a1;
  goto update__element__type_4_9;
  };
  goto update__element__type_4_9;
 update__element__type_4_9:
  otherwise(update__element__type_4_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xadd__dgoal_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a3;
  allocp[4] = a2;
  allocp[5] = makesym(atom_normal);
  a2 = NILATOM;
  a3 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(update__element__type1_4_0);
  goto update__element__type1_4_ext_interrupt;
 update__element__type_4_ext_interrupt:
  reasonp = 0l;
 update__element__type_4_interrupt:
  goto interrupt_4;
 }

 update__element__type1_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 update__element__type1_4_clear_reason:
  reasonp = reasons;
 update__element__type1_4_0:
 update__element__type1_4_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 update__element__type1_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_2)) goto update__element__type1_4_5;
  x1 = arg(x0, 0);
 update__element__type1_4_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_s_3)) goto update__element__type1_4_5;
  x2 = arg(x1, 1);
 update__element__type1_4_4:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != makesym(atom__2A)) goto update__element__type1_4_5;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin_xupdate__element__type1_4);
  allocp[2] = a0;
  x3 = cdr_of(a1);
  allocp[3] = x3;
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[8] = a2;
  x5 = arg(x1, 2);
  allocp[9] = x5;
  allocp[10] = x4;
  qp = (struct goalrec*)&allocp[6];
  allocp += 11;
  proceed();
 case VARREF:
  deref_and_jump(x2,update__element__type1_4_4);
  *reasonp++ =  x2;
  goto update__element__type1_4_5;
  };
  goto update__element__type1_4_5;
 case VARREF:
  deref_and_jump(x1,update__element__type1_4_3);
  *reasonp++ =  x1;
  goto update__element__type1_4_5;
  };
  goto update__element__type1_4_5;
 case VARREF:
  deref_and_jump(x0,update__element__type1_4_2);
  *reasonp++ =  x0;
  goto update__element__type1_4_5;
  };
  goto update__element__type1_4_5;
 case VARREF:
  deref_and_jump(a1,update__element__type1_4_1);
  *reasonp++ =  a1;
  goto update__element__type1_4_5;
  };
  goto update__element__type1_4_5;
 update__element__type1_4_5:
  otherwise(update__element__type1_4_interrupt);
 update__element__type1_4_6:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 update__element__type1_4_7:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_2)) goto update__element__type1_4_10;
  x1 = arg(x0, 0);
 update__element__type1_4_8:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_s_3)) goto update__element__type1_4_10;
 update__element__type1_4_9:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_i_1)) goto update__element__type1_4_10;
  x2 = arg(a0, 0);
  x3 = makeint(1L);
  bblt_add_no_check_y(x2,x3,x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin_xupdate__element__type1_4);
  allocp[2] = a0;
  x5 = cdr_of(a1);
  allocp[3] = x5;
  allocp[4] = x6 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[8] = a2;
  allocp[9] = x7 = makeref(&allocp[9]);
  allocp[10] = x6;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_functor__table_xarg_3);
  allocp[13] = x4;
  x8 = arg(x1, 2);
  allocp[14] = x8;
  allocp[15] = x7;
  qp = (struct goalrec*)&allocp[11];
  allocp += 16;
  proceed();
 case VARREF:
  deref_and_jump(a0,update__element__type1_4_9);
  *reasonp++ =  a0;
  goto update__element__type1_4_10;
  };
  goto update__element__type1_4_10;
 case VARREF:
  deref_and_jump(x1,update__element__type1_4_8);
  *reasonp++ =  x1;
  goto update__element__type1_4_10;
  };
  goto update__element__type1_4_10;
 case VARREF:
  deref_and_jump(x0,update__element__type1_4_7);
  *reasonp++ =  x0;
  goto update__element__type1_4_10;
  };
  goto update__element__type1_4_10;
 case VARREF:
  deref_and_jump(a1,update__element__type1_4_6);
  *reasonp++ =  a1;
  goto update__element__type1_4_10;
  };
  goto update__element__type1_4_10;
 update__element__type1_4_10:
  otherwise(update__element__type1_4_interrupt);
 update__element__type1_4_11:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 update__element__type1_4_12:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_2)) goto update__element__type1_4_14;
  x1 = arg(x0, 0);
 update__element__type1_4_13:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_s_3)) goto update__element__type1_4_14;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin_xupdate__element__type1_4);
  allocp[2] = a0;
  x2 = cdr_of(a1);
  allocp[3] = x2;
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = a3;
  a0 = arg(x1, 1);
  a1 = arg(x1, 2);
  a3 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(merge__updated__element_4_0);
  goto merge__updated__element_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,update__element__type1_4_13);
  *reasonp++ =  x1;
  goto update__element__type1_4_14;
  };
  goto update__element__type1_4_14;
 case VARREF:
  deref_and_jump(x0,update__element__type1_4_12);
  *reasonp++ =  x0;
  goto update__element__type1_4_14;
  };
  goto update__element__type1_4_14;
 case VARREF:
  deref_and_jump(a1,update__element__type1_4_11);
  *reasonp++ =  a1;
  goto update__element__type1_4_14;
  };
  goto update__element__type1_4_14;
 update__element__type1_4_14:
  otherwise(update__element__type1_4_interrupt);
 update__element__type1_4_15:
  switch (ptagof(a1)) {
 case CONS:
  a1 = cdr_of(a1);
  execute(update__element__type1_4_0);
  goto update__element__type1_4_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto update__element__type1_4_interrupt;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a1,update__element__type1_4_15);
  *reasonp++ =  a1;
  goto update__element__type1_4_interrupt;
  };
  goto update__element__type1_4_interrupt;
 update__element__type1_4_ext_interrupt:
  reasonp = 0l;
 update__element__type1_4_interrupt:
  toppred = &predicate_builtin_xupdate__element__type1_4;
  goto interrupt_4;
 }

 merge__updated__element_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 merge__updated__element_4_clear_reason:
  reasonp = reasons;
 merge__updated__element_4_0:
 merge__updated__element_4_1:
  if (!isint(a0)) goto merge__updated__element_4_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,merge__updated__element_4_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin_xmerge__updated__element_4);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x1;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[13] = a2;
  allocp[14] = x3 = makeref(&allocp[14]);
  allocp[15] = x2;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_functor__table_xarg_3);
  allocp[18] = a0;
  allocp[19] = a1;
  allocp[20] = x3;
  qp = (struct goalrec*)&allocp[16];
  allocp += 21;
  proceed();
 merge__updated__element_4_2:
  if (a0 != makeint(0L)) goto merge__updated__element_4_interrupt;
  unify(a3, a2);
  proceed();
 merge__updated__element_4_3:
  if (!isref(a0)) goto merge__updated__element_4_interrupt;
  deref_and_jump(a0,merge__updated__element_4_1);
  *reasonp++ =  a0;
  goto merge__updated__element_4_interrupt;
 merge__updated__element_4_ext_interrupt:
  reasonp = 0l;
 merge__updated__element_4_interrupt:
  toppred = &predicate_builtin_xmerge__updated__element_4;
  goto interrupt_4;
 }
 interrupt_14:
  allocp[15] = a13;
 interrupt_13:
  allocp[14] = a12;
 interrupt_12:
  allocp[13] = a11;
 interrupt_11:
  allocp[12] = a10;
 interrupt_10:
  allocp[11] = a9;
 interrupt_9:
  allocp[10] = a8;
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_builtin);
}
