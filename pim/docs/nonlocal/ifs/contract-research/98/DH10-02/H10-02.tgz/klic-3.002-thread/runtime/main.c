/* ----------------------------------------------------------
%                        Copyright (C) 1998
%        Hiroshi Nakashima, Kazuhiko Ohno, Namiyo Sugiyama,
%        and Department of Information and Computer Sciences 
%                 Toyohashi University of Technology
%----------------------------------------------------------- */  

/* ---------------------------------------------------------- 
%   (C)1994 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
%   (C)1996, 1997 Japan Information Processing Development Center
%       (Read COPYRIGHT-JIPDEC for detailed information.)
----------------------------------------------------------- */

extern int klic_main();

/* klic_main $B$NBh(B3$B0z?t$,#1$J$i%9%l%C%I2=(B KL1 */
main(argc, argv)
     int argc;
     char **argv;
{
  return klic_main(argc, argv, 0);
}
