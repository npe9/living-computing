/* Compiled by KLIC compiler version 3.002 (Wed Sep 17 15:37:13 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_lt();
Const struct predicate predicate_lt_xget_2 =
   { module_lt, 0, 2 };
Const struct predicate predicate_lt_xget__subloops_3 =
   { module_lt, 1, 3 };
Const struct predicate predicate_lt_xget__subloops2_5 =
   { module_lt, 2, 5 };
Const struct predicate predicate_lt_xmake__subloops_6 =
   { module_lt, 3, 6 };
Const struct predicate predicate_lt_xmake__subloops2_5 =
   { module_lt, 4, 5 };
Const struct predicate predicate_lt_xmake__subloops3_6 =
   { module_lt, 5, 6 };
Const struct predicate predicate_lt_xmake__subloop_8 =
   { module_lt, 6, 8 };
Const struct predicate predicate_lt_xget__modules_2 =
   { module_lt, 7, 2 };
Const struct predicate predicate_lt_xget__clauses_5 =
   { module_lt, 8, 5 };
Const struct predicate predicate_lt_xget__bodys_4 =
   { module_lt, 9, 4 };
Const struct predicate predicate_lt_xget__body_5 =
   { module_lt, 10, 5 };
Const struct predicate predicate_lt_xget__recursive__goal_4 =
   { module_lt, 11, 4 };
Const struct predicate predicate_lt_xget__entry_4 =
   { module_lt, 12, 4 };
Const struct predicate predicate_lt_xcheck__entry_4 =
   { module_lt, 13, 4 };
Const struct predicate predicate_lt_xcheck__entry_5 =
   { module_lt, 14, 5 };
Const struct predicate predicate_lt_xget__entry_5 =
   { module_lt, 15, 5 };
extern Const struct predicate predicate_functor_xinsert__arg_4;
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_xsetarg_4;
extern Const struct predicate predicate_functor__table_xfunctor_3;
extern Const struct predicate predicate_parse__uty_xget__def__clauses_5;
extern Const struct predicate predicate_parse__uty_xdecode__goalcall_6;

module module_lt(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  q a0, a1, a2, a3, a4, a5, a6, a7;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, get_2_top);
    case_pred(1, get__subloops_3_top);
    case_pred(2, get__subloops2_5_top);
    case_pred(3, make__subloops_6_top);
    case_pred(4, make__subloops2_5_top);
    case_pred(5, make__subloops3_6_top);
    case_pred(6, make__subloop_8_top);
    case_pred(7, get__modules_2_top);
    case_pred(8, get__clauses_5_top);
    case_pred(9, get__bodys_4_top);
    case_pred(10, get__body_5_top);
    case_pred(11, get__recursive__goal_4_top);
    case_pred(12, get__entry_4_top);
    case_pred(13, check__entry_4_top);
    case_pred(14, check__entry_5_top);
    last_case_pred(15, get__entry_5_top);
  }

 get_2_top: {
  q x0;
  qp = qp->next;
 get_2_clear_reason:
  reasonp = reasons;
 get_2_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_lt_xget__subloops_3);
  allocp[2] = a0;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a1;
  a1 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(get__modules_2_0);
  goto get__modules_2_ext_interrupt;
 get_2_ext_interrupt:
  reasonp = 0l;
 get_2_interrupt:
  goto interrupt_2;
 }

 get__subloops_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  qp = qp->next;
 get__subloops_3_clear_reason:
  reasonp = reasons;
 get__subloops_3_0:
 get__subloops_3_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 get__subloops_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto get__subloops_3_4;
  x1 = arg(x0, 1);
 get__subloops_3_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_loops)) goto get__subloops_3_4;
  allocp[0] = makesym(functor_module_2);
  x3 = arg(x0, 0);
  allocp[1] = x3;
  allocp[2] = makesym(atom_loops);
  x2 = makefunctor(&allocp[0]);
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = x2;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a2, x4);
  a1 = cdr_of(a1);
  a2 = x5;
  execute(get__subloops_3_0);
  goto get__subloops_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,get__subloops_3_3);
  *reasonp++ =  x1;
  goto get__subloops_3_4;
  };
  goto get__subloops_3_4;
 case VARREF:
  deref_and_jump(x0,get__subloops_3_2);
  *reasonp++ =  x0;
  goto get__subloops_3_4;
  };
  goto get__subloops_3_4;
 case ATOMIC:
  if (a1 != NILATOM) goto get__subloops_3_4;
  unify_value(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a1,get__subloops_3_1);
  *reasonp++ =  a1;
  goto get__subloops_3_4;
  };
  goto get__subloops_3_4;
 get__subloops_3_4:
  otherwise(get__subloops_3_interrupt);
 get__subloops_3_5:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 get__subloops_3_6:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto get__subloops_3_interrupt;
  allocp[0] = makesym(functor_module_2);
  x2 = arg(x0, 0);
  allocp[1] = x2;
  allocp[2] = x3 = makeref(&allocp[2]);
  x1 = makefunctor(&allocp[0]);
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = x1;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a2, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_lt_xget__subloops_3);
  allocp[2] = a0;
  x6 = cdr_of(a1);
  allocp[3] = x6;
  allocp[4] = x5;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_lt_xget__subloops2_5);
  allocp[7] = x7 = makeref(&allocp[7]);
  x8 = arg(x0, 0);
  allocp[8] = x8;
  x9 = arg(x0, 1);
  allocp[9] = x9;
  allocp[10] = x3;
  allocp[11] = a0;
  allocp[12] = (q)(struct goalrec*)&allocp[5];
  allocp[13] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[14] = x9;
  allocp[15] = x10 = makeref(&allocp[15]);
  allocp[16] = x7;
  qp = (struct goalrec*)&allocp[12];
  allocp += 17;
  proceed();
 case VARREF:
  deref_and_jump(x0,get__subloops_3_6);
  *reasonp++ =  x0;
  goto get__subloops_3_interrupt;
  };
  goto get__subloops_3_interrupt;
 case VARREF:
  deref_and_jump(a1,get__subloops_3_5);
  *reasonp++ =  a1;
  goto get__subloops_3_interrupt;
  };
  goto get__subloops_3_interrupt;
 get__subloops_3_ext_interrupt:
  reasonp = 0l;
 get__subloops_3_interrupt:
  goto interrupt_3;
 }

 get__subloops2_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 get__subloops2_5_clear_reason:
  reasonp = reasons;
 get__subloops2_5_0:
 get__subloops2_5_1:
  if (!isint(a0)) goto get__subloops2_5_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,get__subloops2_5_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_lt_xget__subloops2_5);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[9] = a0;
  allocp[10] = makeint(1L);
  allocp[11] = x1;
  allocp[12] = (q)(struct goalrec*)&allocp[7];
  allocp[13] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[14] = a0;
  allocp[15] = a2;
  allocp[16] = x3 = makeref(&allocp[16]);
  allocp[17] = x2;
  allocp[18] = makesym(functor__2F_2);
  allocp[19] = x5 = makeref(&allocp[19]);
  allocp[20] = x6 = makeref(&allocp[20]);
  x4 = makefunctor(&allocp[18]);
  allocp[21] = makesym(functor_loop_2);
  allocp[22] = x4;
  allocp[23] = x8 = makeref(&allocp[23]);
  x7 = makefunctor(&allocp[21]);
  qp = (struct goalrec*)&allocp[12];
  allocp += 24;
  unify_value(x3, x7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_lt_xmake__subloops_6);
  allocp[2] = a1;
  allocp[3] = x5;
  allocp[4] = x6;
  allocp[5] = a4;
  allocp[6] = x9 = makeref(&allocp[6]);
  allocp[7] = x8;
  allocp[8] = makesym(functor__2F_2);
  allocp[9] = x5;
  allocp[10] = x6;
  x10 = makefunctor(&allocp[8]);
  allocp[11] = makesym(functor_loop_2);
  allocp[12] = x10;
  allocp[13] = x9;
  x11 = makefunctor(&allocp[11]);
  allocp[14] = (q)(struct goalrec*)&allocp[0];
  allocp[15] = (q)(&predicate_functor__table_xarg_3);
  allocp[16] = a0;
  allocp[17] = a2;
  allocp[18] = x11;
  qp = (struct goalrec*)&allocp[14];
  allocp += 19;
  proceed();
 get__subloops2_5_2:
  if (a0 != makeint(0L)) goto get__subloops2_5_interrupt;
  unify(a3, a2);
  proceed();
 get__subloops2_5_3:
  if (!isref(a0)) goto get__subloops2_5_interrupt;
  deref_and_jump(a0,get__subloops2_5_1);
  *reasonp++ =  a0;
  goto get__subloops2_5_interrupt;
 get__subloops2_5_ext_interrupt:
  reasonp = 0l;
 get__subloops2_5_interrupt:
  goto interrupt_5;
 }

 make__subloops_6_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 make__subloops_6_clear_reason:
  reasonp = reasons;
 make__subloops_6_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_lt_xmake__subloops2_5);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a3;
  allocp[5] = a4;
  allocp[6] = a5;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_parse__uty_xget__def__clauses_5);
  allocp[9] = a0;
  allocp[10] = a1;
  allocp[11] = a2;
  allocp[12] = x0;
  allocp[13] = a3;
  qp = (struct goalrec*)&allocp[7];
  allocp += 14;
  proceed();
 make__subloops_6_ext_interrupt:
  reasonp = 0l;
 make__subloops_6_interrupt:
  goto interrupt_6;
 }

 make__subloops2_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 make__subloops2_5_clear_reason:
  reasonp = reasons;
 make__subloops2_5_0:
 make__subloops2_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 make__subloops2_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_cl_2)) goto make__subloops2_5_6;
  x1 = arg(x0, 1);
 make__subloops2_5_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_clause_6)) goto make__subloops2_5_6;
  x2 = arg(x1, 2);
 make__subloops2_5_4:
  if (isref(x2)) goto make__subloops2_5_5;
  gblt_pfunctor(x2,x3,make__subloops2_5_6);
  gblt_arity(x2,x4,make__subloops2_5_6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_lt_xmake__subloops2_5);
  x5 = cdr_of(a0);
  allocp[2] = x5;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x6 = makeref(&allocp[5]);
  allocp[6] = a4;
  a0 = x4;
  x7 = a1;
  x8 = a2;
  a4 = a3;
  a5 = x6;
  a3 = x8;
  a2 = x7;
  a1 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(make__subloops3_6_0);
  goto make__subloops3_6_ext_interrupt;
 make__subloops2_5_5:
  deref_and_jump(x2,make__subloops2_5_4);
  *reasonp++ =  x2;
  goto make__subloops2_5_6;
 case VARREF:
  deref_and_jump(x1,make__subloops2_5_3);
  *reasonp++ =  x1;
  goto make__subloops2_5_6;
  };
  goto make__subloops2_5_6;
 case VARREF:
  deref_and_jump(x0,make__subloops2_5_2);
  *reasonp++ =  x0;
  goto make__subloops2_5_6;
  };
  goto make__subloops2_5_6;
 case VARREF:
  deref_and_jump(a0,make__subloops2_5_1);
  *reasonp++ =  a0;
  goto make__subloops2_5_6;
  };
  goto make__subloops2_5_6;
 make__subloops2_5_6:
  otherwise(make__subloops2_5_interrupt);
 make__subloops2_5_7:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(make__subloops2_5_0);
  goto make__subloops2_5_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto make__subloops2_5_interrupt;
  unify(a4, a3);
  proceed();
 case VARREF:
  deref_and_jump(a0,make__subloops2_5_7);
  *reasonp++ =  a0;
  goto make__subloops2_5_interrupt;
  };
  goto make__subloops2_5_interrupt;
 make__subloops2_5_ext_interrupt:
  reasonp = 0l;
 make__subloops2_5_interrupt:
  goto interrupt_5;
 }

 make__subloops3_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 make__subloops3_6_clear_reason:
  reasonp = reasons;
 make__subloops3_6_0:
 make__subloops3_6_1:
  if (!isint(a0)) goto make__subloops3_6_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,make__subloops3_6_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_lt_xmake__subloops3_6);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[10] = a0;
  allocp[11] = makeint(1L);
  allocp[12] = x1;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_lt_xmake__subloop_8);
  allocp[15] = x3 = makeref(&allocp[15]);
  allocp[16] = x4 = makeref(&allocp[16]);
  allocp[17] = x5 = makeref(&allocp[17]);
  allocp[18] = a2;
  allocp[19] = x6 = makeref(&allocp[19]);
  allocp[20] = a3;
  allocp[21] = a4;
  allocp[22] = x2;
  allocp[23] = (q)(struct goalrec*)&allocp[13];
  allocp[24] = (q)(&predicate_parse__uty_xdecode__goalcall_6);
  allocp[25] = a2;
  allocp[26] = x6;
  allocp[27] = x7 = makeref(&allocp[27]);
  allocp[28] = x5;
  allocp[29] = x3;
  allocp[30] = x4;
  allocp[31] = (q)(struct goalrec*)&allocp[23];
  allocp[32] = (q)(&predicate_functor__table_xarg_3);
  allocp[33] = a0;
  allocp[34] = a1;
  allocp[35] = x7;
  qp = (struct goalrec*)&allocp[31];
  allocp += 36;
  proceed();
 make__subloops3_6_2:
  if (a0 != makeint(0L)) goto make__subloops3_6_interrupt;
  unify(a5, a4);
  proceed();
 make__subloops3_6_3:
  if (!isref(a0)) goto make__subloops3_6_interrupt;
  deref_and_jump(a0,make__subloops3_6_1);
  *reasonp++ =  a0;
  goto make__subloops3_6_interrupt;
 make__subloops3_6_ext_interrupt:
  reasonp = 0l;
 make__subloops3_6_interrupt:
  toppred = &predicate_lt_xmake__subloops3_6;
  goto interrupt_6;
 }

 make__subloop_8_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 make__subloop_8_clear_reason:
  reasonp = reasons;
 make__subloop_8_0:
 make__subloop_8_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_builtin)) goto make__subloop_8_2;
  unify(a7, a6);
  proceed();
 case VARREF:
  deref_and_jump(a1,make__subloop_8_1);
  *reasonp++ =  a1;
  goto make__subloop_8_2;
  };
  goto make__subloop_8_2;
 make__subloop_8_2:
 make__subloop_8_3:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_atom_1)) goto make__subloop_8_11;
  x0 = arg(a0, 0);
 make__subloop_8_4:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (isint(x0)) goto make__subloop_8_11;
  switch (symval(x0)) {
 case symval(makesym(atom_recursive)):
 make__subloop_8_5:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_userdef)) goto make__subloop_8_11;
  unify(a7, a6);
  proceed();
 case VARREF:
  deref_and_jump(a1,make__subloop_8_5);
  *reasonp++ =  a1;
  goto make__subloop_8_11;
  };
  goto make__subloop_8_11;
 case symval(makesym(atom_entry)):
 make__subloop_8_6:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_userdef)) goto make__subloop_8_11;
 make__subloop_8_7:
  if (isref(a4)) goto make__subloop_8_10;
 make__subloop_8_8:
  if (isref(a4)) goto make__subloop_8_9;
  if_not_equal(a4, a3, make__subloop_8_11);
  allocp[0] = makesym(functor_sub_2);
  allocp[1] = x2 = makeref(&allocp[1]);
  allocp[2] = x3 = makeref(&allocp[2]);
  x1 = makefunctor(&allocp[0]);
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = x1;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a7, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_lt_xmake__subloops_6);
  allocp[2] = a3;
  allocp[3] = x2;
  allocp[4] = x3;
  allocp[5] = a5;
  allocp[6] = a6;
  allocp[7] = x5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[10] = a2;
  allocp[11] = x2;
  allocp[12] = x3;
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  proceed();
 make__subloop_8_9:
  deref_and_jump(a4,make__subloop_8_8);
  *reasonp++ =  a4;
  goto make__subloop_8_11;
 make__subloop_8_10:
  deref_and_jump(a4,make__subloop_8_7);
  *reasonp++ =  a4;
  goto make__subloop_8_11;
 case VARREF:
  deref_and_jump(a1,make__subloop_8_6);
  *reasonp++ =  a1;
  goto make__subloop_8_11;
  };
  goto make__subloop_8_11;
  };
  goto make__subloop_8_11;
 case VARREF:
  deref_and_jump(x0,make__subloop_8_4);
  *reasonp++ =  x0;
  goto make__subloop_8_11;
  };
  goto make__subloop_8_11;
 case VARREF:
  deref_and_jump(a0,make__subloop_8_3);
  *reasonp++ =  a0;
  goto make__subloop_8_11;
  };
  goto make__subloop_8_11;
 make__subloop_8_11:
  otherwise(make__subloop_8_interrupt);
 make__subloop_8_12:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_userdef)) goto make__subloop_8_17;
 make__subloop_8_13:
  if (isref(a4)) goto make__subloop_8_16;
 make__subloop_8_14:
  if (isref(a4)) goto make__subloop_8_15;
  if_not_equal(a4, a3, make__subloop_8_17);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_lt_xmake__subloops_6);
  allocp[2] = a3;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a5;
  allocp[6] = a6;
  allocp[7] = a7;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[10] = a2;
  allocp[11] = x0;
  allocp[12] = x1;
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  proceed();
 make__subloop_8_15:
  deref_and_jump(a4,make__subloop_8_14);
  *reasonp++ =  a4;
  goto make__subloop_8_17;
 make__subloop_8_16:
  deref_and_jump(a4,make__subloop_8_13);
  *reasonp++ =  a4;
  goto make__subloop_8_17;
 case VARREF:
  deref_and_jump(a1,make__subloop_8_12);
  *reasonp++ =  a1;
  goto make__subloop_8_17;
  };
  goto make__subloop_8_17;
 make__subloop_8_17:
  otherwise(make__subloop_8_interrupt);
  unify(a7, a6);
  proceed();
 make__subloop_8_ext_interrupt:
  reasonp = 0l;
 make__subloop_8_interrupt:
  goto interrupt_8;
 }

 get__modules_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  qp = qp->next;
 get__modules_2_clear_reason:
  reasonp = reasons;
 get__modules_2_0:
 get__modules_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 get__modules_2_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto get__modules_2_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_lt_xget__modules_2);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = makesym(functor_module_2);
  x4 = arg(x0, 0);
  allocp[5] = x4;
  allocp[6] = x5 = makeref(&allocp[6]);
  x3 = makefunctor(&allocp[4]);
  allocp[7] = x2;
  allocp[8] = x3;
  x6 = makecons(&allocp[7]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 9;
  unify_value(a1, x6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_lt_xget__clauses_5);
  allocp[2] = x7 = makeref(&allocp[2]);
  x8 = arg(x0, 0);
  allocp[3] = x8;
  x9 = arg(x0, 1);
  allocp[4] = x9;
  allocp[5] = makesym(atom_loops);
  allocp[6] = x5;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[9] = x9;
  allocp[10] = x10 = makeref(&allocp[10]);
  allocp[11] = x7;
  qp = (struct goalrec*)&allocp[7];
  allocp += 12;
  proceed();
 case VARREF:
  deref_and_jump(x0,get__modules_2_2);
  *reasonp++ =  x0;
  goto get__modules_2_interrupt;
  };
  goto get__modules_2_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto get__modules_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,get__modules_2_1);
  *reasonp++ =  a0;
  goto get__modules_2_interrupt;
  };
  goto get__modules_2_interrupt;
 get__modules_2_ext_interrupt:
  reasonp = 0l;
 get__modules_2_interrupt:
  toppred = &predicate_lt_xget__modules_2;
  goto interrupt_2;
 }

 get__clauses_5_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 get__clauses_5_clear_reason:
  reasonp = reasons;
 get__clauses_5_0:
 get__clauses_5_1:
  if (!isint(a0)) goto get__clauses_5_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,get__clauses_5_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_lt_xget__clauses_5);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[9] = a0;
  allocp[10] = makeint(1L);
  allocp[11] = x1;
  allocp[12] = (q)(struct goalrec*)&allocp[7];
  allocp[13] = (q)(&predicate_lt_xget__bodys_4);
  allocp[14] = x3 = makeref(&allocp[14]);
  allocp[15] = a1;
  allocp[16] = a3;
  allocp[17] = x2;
  allocp[18] = (q)(struct goalrec*)&allocp[12];
  allocp[19] = (q)(&predicate_functor__table_xarg_3);
  allocp[20] = a0;
  allocp[21] = a2;
  allocp[22] = x3;
  qp = (struct goalrec*)&allocp[18];
  allocp += 23;
  proceed();
 get__clauses_5_2:
  if (a0 != makeint(0L)) goto get__clauses_5_interrupt;
  unify(a4, a3);
  proceed();
 get__clauses_5_3:
  if (!isref(a0)) goto get__clauses_5_interrupt;
  deref_and_jump(a0,get__clauses_5_1);
  *reasonp++ =  a0;
  goto get__clauses_5_interrupt;
 get__clauses_5_ext_interrupt:
  reasonp = 0l;
 get__clauses_5_interrupt:
  goto interrupt_5;
 }

 get__bodys_4_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 get__bodys_4_clear_reason:
  reasonp = reasons;
 get__bodys_4_0:
 get__bodys_4_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_clause_4)) goto get__bodys_4_2;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_lt_xget__body_5);
  allocp[2] = x0 = makeref(&allocp[2]);
  x1 = arg(a0, 2);
  allocp[3] = x1;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[9] = x1;
  allocp[10] = x2 = makeref(&allocp[10]);
  allocp[11] = x0;
  qp = (struct goalrec*)&allocp[7];
  allocp += 12;
  proceed();
 case VARREF:
  deref_and_jump(a0,get__bodys_4_1);
  *reasonp++ =  a0;
  goto get__bodys_4_2;
  };
  goto get__bodys_4_2;
 get__bodys_4_2:
  otherwise(get__bodys_4_interrupt);
  unify(a3, a2);
  proceed();
 get__bodys_4_ext_interrupt:
  reasonp = 0l;
 get__bodys_4_interrupt:
  goto interrupt_4;
 }

 get__body_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 get__body_5_clear_reason:
  reasonp = reasons;
 get__body_5_0:
 get__body_5_1:
  if (!isint(a0)) goto get__body_5_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,get__body_5_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_lt_xget__body_5);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[9] = a0;
  allocp[10] = makeint(1L);
  allocp[11] = x1;
  allocp[12] = (q)(struct goalrec*)&allocp[7];
  allocp[13] = (q)(&predicate_lt_xget__recursive__goal_4);
  allocp[14] = x3 = makeref(&allocp[14]);
  allocp[15] = x4 = makeref(&allocp[15]);
  allocp[16] = a3;
  allocp[17] = x2;
  allocp[18] = (q)(struct goalrec*)&allocp[12];
  allocp[19] = (q)(&predicate_parse__uty_xdecode__goalcall_6);
  allocp[20] = a2;
  allocp[21] = x5 = makeref(&allocp[21]);
  allocp[22] = x6 = makeref(&allocp[22]);
  allocp[23] = x4;
  allocp[24] = x3;
  allocp[25] = x7 = makeref(&allocp[25]);
  allocp[26] = (q)(struct goalrec*)&allocp[18];
  allocp[27] = (q)(&predicate_functor__table_xarg_3);
  allocp[28] = a0;
  allocp[29] = a1;
  allocp[30] = x6;
  qp = (struct goalrec*)&allocp[26];
  allocp += 31;
  proceed();
 get__body_5_2:
  if (a0 != makeint(0L)) goto get__body_5_interrupt;
  unify(a4, a3);
  proceed();
 get__body_5_3:
  if (!isref(a0)) goto get__body_5_interrupt;
  deref_and_jump(a0,get__body_5_1);
  *reasonp++ =  a0;
  goto get__body_5_interrupt;
 get__body_5_ext_interrupt:
  reasonp = 0l;
 get__body_5_interrupt:
  goto interrupt_5;
 }

 get__recursive__goal_4_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 get__recursive__goal_4_clear_reason:
  reasonp = reasons;
 get__recursive__goal_4_0:
 get__recursive__goal_4_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_atom_1)) goto get__recursive__goal_4_3;
  x0 = arg(a0, 0);
 get__recursive__goal_4_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_recursive)) goto get__recursive__goal_4_3;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_lt_xget__entry_4);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[8] = a1;
  allocp[9] = x1;
  allocp[10] = x2;
  qp = (struct goalrec*)&allocp[6];
  allocp += 11;
  proceed();
 case VARREF:
  deref_and_jump(x0,get__recursive__goal_4_2);
  *reasonp++ =  x0;
  goto get__recursive__goal_4_3;
  };
  goto get__recursive__goal_4_3;
 case VARREF:
  deref_and_jump(a0,get__recursive__goal_4_1);
  *reasonp++ =  a0;
  goto get__recursive__goal_4_3;
  };
  goto get__recursive__goal_4_3;
 get__recursive__goal_4_3:
  otherwise(get__recursive__goal_4_interrupt);
  unify(a3, a2);
  proceed();
 get__recursive__goal_4_ext_interrupt:
  reasonp = 0l;
 get__recursive__goal_4_interrupt:
  goto interrupt_4;
 }

 get__entry_4_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 get__entry_4_clear_reason:
  reasonp = reasons;
 get__entry_4_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_lt_xget__entry_5);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  a3 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(check__entry_4_0);
  goto check__entry_4_ext_interrupt;
 get__entry_4_ext_interrupt:
  reasonp = 0l;
 get__entry_4_interrupt:
  goto interrupt_4;
 }

 check__entry_4_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 check__entry_4_clear_reason:
  reasonp = reasons;
 check__entry_4_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_lt_xcheck__entry_5);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[9] = a2;
  allocp[10] = x1 = makeref(&allocp[10]);
  allocp[11] = x0;
  qp = (struct goalrec*)&allocp[7];
  allocp += 12;
  proceed();
 check__entry_4_ext_interrupt:
  reasonp = 0l;
 check__entry_4_interrupt:
  toppred = &predicate_lt_xcheck__entry_4;
  goto interrupt_4;
 }

 check__entry_5_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 check__entry_5_clear_reason:
  reasonp = reasons;
 check__entry_5_0:
 check__entry_5_1:
  if (!isint(a0)) goto check__entry_5_14;
  x0 = makeint(0L);
  gblt_greater(a0,x0,check__entry_5_15);
 check__entry_5_2:
  if (isref(a3)) goto check__entry_5_13;
  gblt_arg(a0,a3,x1,check__entry_5_15);
 check__entry_5_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_loop_2)) goto check__entry_5_15;
  x2 = arg(x1, 0);
 check__entry_5_4:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor__2F_2)) goto check__entry_5_15;
  x3 = arg(x2, 0);
 check__entry_5_5:
  if (isref(x3)) goto check__entry_5_12;
 check__entry_5_6:
  if (isref(x3)) goto check__entry_5_11;
  if_not_equal(x3, a1, check__entry_5_15);
  x4 = arg(x2, 1);
 check__entry_5_7:
  if (isref(x4)) goto check__entry_5_10;
 check__entry_5_8:
  if (isref(x4)) goto check__entry_5_9;
  if_not_equal(x4, a2, check__entry_5_15);
  x5 = makesym(atom_yes);
  unify_value(a4, x5);
  proceed();
 check__entry_5_9:
  deref_and_jump(x4,check__entry_5_8);
  *reasonp++ =  x4;
  goto check__entry_5_15;
 check__entry_5_10:
  deref_and_jump(x4,check__entry_5_7);
  *reasonp++ =  x4;
  goto check__entry_5_15;
 check__entry_5_11:
  deref_and_jump(x3,check__entry_5_6);
  *reasonp++ =  x3;
  goto check__entry_5_15;
 check__entry_5_12:
  deref_and_jump(x3,check__entry_5_5);
  *reasonp++ =  x3;
  goto check__entry_5_15;
 case VARREF:
  deref_and_jump(x2,check__entry_5_4);
  *reasonp++ =  x2;
  goto check__entry_5_15;
  };
  goto check__entry_5_15;
 case VARREF:
  deref_and_jump(x1,check__entry_5_3);
  *reasonp++ =  x1;
  goto check__entry_5_15;
  };
  goto check__entry_5_15;
 check__entry_5_13:
  deref_and_jump(a3,check__entry_5_2);
  *reasonp++ =  a3;
  goto check__entry_5_15;
 check__entry_5_14:
  if (!isref(a0)) goto check__entry_5_15;
  deref_and_jump(a0,check__entry_5_1);
  *reasonp++ =  a0;
  goto check__entry_5_15;
 check__entry_5_15:
  otherwise(check__entry_5_interrupt);
 check__entry_5_16:
  if (!isint(a0)) goto check__entry_5_18;
  x0 = makeint(0L);
  gblt_greater(a0,x0,check__entry_5_17);
  x1 = makeint(1L);
  bblt_sub_no_check(a0,x1,x2);
  a0 = x2;
  execute(check__entry_5_0);
  goto check__entry_5_ext_interrupt;
 check__entry_5_17:
  if (a0 != makeint(0L)) goto check__entry_5_interrupt;
  x3 = makesym(atom_no);
  unify_value(a4, x3);
  proceed();
 check__entry_5_18:
  if (!isref(a0)) goto check__entry_5_interrupt;
  deref_and_jump(a0,check__entry_5_16);
  *reasonp++ =  a0;
  goto check__entry_5_interrupt;
 check__entry_5_ext_interrupt:
  reasonp = 0l;
 check__entry_5_interrupt:
  goto interrupt_5;
 }

 get__entry_5_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 get__entry_5_clear_reason:
  reasonp = reasons;
 get__entry_5_0:
 get__entry_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto get__entry_5_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  unify(a4, a3);
  proceed();
 case symval(makesym(atom_no)):
  allocp[0] = makesym(functor__2F_2);
  allocp[1] = a1;
  allocp[2] = a2;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_loop_2);
  allocp[4] = x0;
  allocp[5] = NILATOM;
  x1 = makefunctor(&allocp[3]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_functor_xinsert__arg_4);
  allocp[8] = makeint(1L);
  allocp[9] = a3;
  allocp[10] = x1;
  allocp[11] = a4;
  qp = (struct goalrec*)&allocp[6];
  allocp += 12;
  proceed();
  };
  goto get__entry_5_interrupt;
 case VARREF:
  deref_and_jump(a0,get__entry_5_1);
  *reasonp++ =  a0;
  goto get__entry_5_interrupt;
  };
  goto get__entry_5_interrupt;
 get__entry_5_ext_interrupt:
  reasonp = 0l;
 get__entry_5_interrupt:
  goto interrupt_5;
 }
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_lt);
}
