/* Compiled by KLIC compiler version 3.002 (Wed Sep 17 15:37:13 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_vt();
Const struct predicate predicate_vt_xread__ts_5 =
   { module_vt, 0, 5 };
Const struct predicate predicate_vt_xwrite__ts_6 =
   { module_vt, 1, 6 };
Const struct predicate predicate_vt_xread__iu_5 =
   { module_vt, 2, 5 };
Const struct predicate predicate_vt_xwrite__iu_6 =
   { module_vt, 3, 6 };
Const struct predicate predicate_vt_xdelete__iu_4 =
   { module_vt, 4, 4 };
Const struct predicate predicate_vt_xdelete__element_3 =
   { module_vt, 5, 3 };
Const struct predicate predicate_vt_xread__av_5 =
   { module_vt, 6, 5 };
Const struct predicate predicate_vt_xwrite__av_6 =
   { module_vt, 7, 6 };
Const struct predicate predicate_vt_xcheck__av_5 =
   { module_vt, 8, 5 };
Const struct predicate predicate_vt_xcheck__av2_5 =
   { module_vt, 9, 5 };
Const struct predicate predicate_vt_xgen__av_5 =
   { module_vt, 10, 5 };
Const struct predicate predicate_vt_xgen__av_3 =
   { module_vt, 11, 3 };
Const struct predicate predicate_vt_xadd__av_8 =
   { module_vt, 12, 8 };
Const struct predicate predicate_vt_xreplace__tv_10 =
   { module_vt, 13, 10 };
Const struct predicate predicate_vt_xreplace__tv_11 =
   { module_vt, 14, 11 };
Const struct predicate predicate_vt_xreplace__tv1_10 =
   { module_vt, 15, 10 };
Const struct predicate predicate_vt_xreplace__tv2_11 =
   { module_vt, 16, 11 };
Const struct predicate predicate_vt_xreplace__tv3_10 =
   { module_vt, 17, 10 };
Const struct predicate predicate_vt_xremove__ds_2 =
   { module_vt, 18, 2 };
Const struct predicate predicate_vt_xremove__ds__clauses_3 =
   { module_vt, 19, 3 };
Const struct predicate predicate_vt_xremove__ds__clause_3 =
   { module_vt, 20, 3 };
extern Const struct predicate predicate_list_xappend_3;
extern Const struct predicate predicate_functor_xinsert__arg_4;
extern Const struct predicate predicate_integer__arithmetics_xadd_3;
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_xsetarg_4;
extern Const struct predicate predicate_functor__table_xfunctor_3;
extern Const struct predicate predicate_typeset_xremove__ds_2;

module module_vt(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  static Const q cons_const_0[] = {
    NILATOM,
    makesym(atom__2A),
  };
  static Const q funct_const_1[] = {
    makesym(functor_v_3),
    makecons(cons_const_0),
    NILATOM,
    NILATOM,
  };
  q a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, read__ts_5_top);
    case_pred(1, write__ts_6_top);
    case_pred(2, read__iu_5_top);
    case_pred(3, write__iu_6_top);
    case_pred(4, delete__iu_4_top);
    case_pred(5, delete__element_3_top);
    case_pred(6, read__av_5_top);
    case_pred(7, write__av_6_top);
    case_pred(8, check__av_5_top);
    case_pred(9, check__av2_5_top);
    case_pred(10, gen__av_5_top);
    case_pred(11, gen__av_3_top);
    case_pred(12, add__av_8_top);
    case_pred(13, replace__tv_10_top);
    case_pred(14, replace__tv_11_top);
    case_pred(15, replace__tv1_10_top);
    case_pred(16, replace__tv2_11_top);
    case_pred(17, replace__tv3_10_top);
    case_pred(18, remove__ds_2_top);
    case_pred(19, remove__ds__clauses_3_top);
    last_case_pred(20, remove__ds__clause_3_top);
  }

 read__ts_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 read__ts_5_clear_reason:
  reasonp = reasons;
 read__ts_5_0:
 read__ts_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 read__ts_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto read__ts_5_7;
  x1 = arg(x0, 0);
 read__ts_5_3:
  if (isref(x1)) goto read__ts_5_6;
 read__ts_5_4:
  if (isref(x1)) goto read__ts_5_5;
  if_not_equal(x1, a1, read__ts_5_7);
  allocp[0] = makesym(functor_v_3);
  allocp[1] = a4;
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = x4 = makeref(&allocp[3]);
  x2 = makefunctor(&allocp[0]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_functor__table_xarg_3);
  allocp[6] = x5 = makeref(&allocp[6]);
  allocp[7] = x6 = makeref(&allocp[7]);
  allocp[8] = x2;
  allocp[9] = (q)(struct goalrec*)&allocp[4];
  allocp[10] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[11] = a3;
  allocp[12] = makeint(1L);
  allocp[13] = x5;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_functor__table_xarg_3);
  allocp[16] = a2;
  x7 = arg(x0, 1);
  allocp[17] = x7;
  allocp[18] = x6;
  qp = (struct goalrec*)&allocp[14];
  allocp += 19;
  proceed();
 read__ts_5_5:
  deref_and_jump(x1,read__ts_5_4);
  *reasonp++ =  x1;
  goto read__ts_5_7;
 read__ts_5_6:
  deref_and_jump(x1,read__ts_5_3);
  *reasonp++ =  x1;
  goto read__ts_5_7;
 case VARREF:
  deref_and_jump(x0,read__ts_5_2);
  *reasonp++ =  x0;
  goto read__ts_5_7;
  };
  goto read__ts_5_7;
 case ATOMIC:
  if (a0 != NILATOM) goto read__ts_5_7;
  x0 = makesym(atom_error);
  x1 = makesym(atom_read__ts);
  unify(x0, x1);
  proceed();
 case VARREF:
  deref_and_jump(a0,read__ts_5_1);
  *reasonp++ =  a0;
  goto read__ts_5_7;
  };
  goto read__ts_5_7;
 read__ts_5_7:
  otherwise(read__ts_5_interrupt);
 read__ts_5_8:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(read__ts_5_0);
  goto read__ts_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,read__ts_5_8);
  *reasonp++ =  a0;
  goto read__ts_5_interrupt;
  };
  goto read__ts_5_interrupt;
 read__ts_5_ext_interrupt:
  reasonp = 0l;
 read__ts_5_interrupt:
  goto interrupt_5;
 }

 write__ts_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 write__ts_6_clear_reason:
  reasonp = reasons;
 write__ts_6_0:
 write__ts_6_1:
  switch (ptagof(a4)) {
 case CONS:
  x0 = car_of(a4);
 write__ts_6_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto write__ts_6_7;
  x1 = arg(x0, 0);
 write__ts_6_3:
  if (isref(x1)) goto write__ts_6_6;
 write__ts_6_4:
  if (isref(x1)) goto write__ts_6_5;
  if_not_equal(x1, a0, write__ts_6_7);
  allocp[0] = makesym(functor_module_2);
  allocp[1] = a0;
  allocp[2] = x3 = makeref(&allocp[2]);
  x2 = makefunctor(&allocp[0]);
  x5 = cdr_of(a4);
  allocp[3] = x5;
  allocp[4] = x2;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a5, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = a1;
  x6 = arg(x0, 1);
  allocp[3] = x6;
  allocp[4] = x7 = makeref(&allocp[4]);
  allocp[5] = x3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[8] = x8 = makeref(&allocp[8]);
  allocp[9] = x9 = makeref(&allocp[9]);
  allocp[10] = x10 = makeref(&allocp[10]);
  allocp[11] = x7;
  allocp[12] = (q)(struct goalrec*)&allocp[6];
  allocp[13] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[14] = a2;
  allocp[15] = makeint(1L);
  allocp[16] = x8;
  allocp[17] = makesym(functor_v_3);
  allocp[18] = a3;
  allocp[19] = x12 = makeref(&allocp[19]);
  allocp[20] = x13 = makeref(&allocp[20]);
  x11 = makefunctor(&allocp[17]);
  qp = (struct goalrec*)&allocp[12];
  allocp += 21;
  unify_value(x10, x11);
  allocp[0] = makesym(functor_v_3);
  allocp[1] = x15 = makeref(&allocp[1]);
  allocp[2] = x12;
  allocp[3] = x13;
  x14 = makefunctor(&allocp[0]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_functor__table_xarg_3);
  allocp[6] = x16 = makeref(&allocp[6]);
  allocp[7] = x9;
  allocp[8] = x14;
  allocp[9] = (q)(struct goalrec*)&allocp[4];
  allocp[10] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[11] = a2;
  allocp[12] = makeint(1L);
  allocp[13] = x16;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_functor__table_xarg_3);
  allocp[16] = a1;
  allocp[17] = x6;
  allocp[18] = x9;
  qp = (struct goalrec*)&allocp[14];
  allocp += 19;
  proceed();
 write__ts_6_5:
  deref_and_jump(x1,write__ts_6_4);
  *reasonp++ =  x1;
  goto write__ts_6_7;
 write__ts_6_6:
  deref_and_jump(x1,write__ts_6_3);
  *reasonp++ =  x1;
  goto write__ts_6_7;
 case VARREF:
  deref_and_jump(x0,write__ts_6_2);
  *reasonp++ =  x0;
  goto write__ts_6_7;
  };
  goto write__ts_6_7;
 case ATOMIC:
  if (a4 != NILATOM) goto write__ts_6_7;
  unify_value(a5, a4);
  x0 = makesym(atom_error);
  x1 = makesym(atom_write__ts);
  unify(x0, x1);
  proceed();
 case VARREF:
  deref_and_jump(a4,write__ts_6_1);
  *reasonp++ =  a4;
  goto write__ts_6_7;
  };
  goto write__ts_6_7;
 write__ts_6_7:
  otherwise(write__ts_6_interrupt);
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = x2 = makeref(&allocp[1]);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a4, x0);
  allocp[0] = x4 = makeref(&allocp[0]);
  allocp[1] = x2;
  x3 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a5, x3);
  a4 = x1;
  a5 = x4;
  execute(write__ts_6_0);
  goto write__ts_6_ext_interrupt;
 write__ts_6_ext_interrupt:
  reasonp = 0l;
 write__ts_6_interrupt:
  goto interrupt_6;
 }

 read__iu_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 read__iu_5_clear_reason:
  reasonp = reasons;
 read__iu_5_0:
 read__iu_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 read__iu_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto read__iu_5_7;
  x1 = arg(x0, 0);
 read__iu_5_3:
  if (isref(x1)) goto read__iu_5_6;
 read__iu_5_4:
  if (isref(x1)) goto read__iu_5_5;
  if_not_equal(x1, a1, read__iu_5_7);
  allocp[0] = makesym(functor_v_3);
  allocp[1] = x3 = makeref(&allocp[1]);
  allocp[2] = a4;
  allocp[3] = x4 = makeref(&allocp[3]);
  x2 = makefunctor(&allocp[0]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_functor__table_xarg_3);
  allocp[6] = x5 = makeref(&allocp[6]);
  allocp[7] = x6 = makeref(&allocp[7]);
  allocp[8] = x2;
  allocp[9] = (q)(struct goalrec*)&allocp[4];
  allocp[10] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[11] = a3;
  allocp[12] = makeint(1L);
  allocp[13] = x5;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_functor__table_xarg_3);
  allocp[16] = a2;
  x7 = arg(x0, 1);
  allocp[17] = x7;
  allocp[18] = x6;
  qp = (struct goalrec*)&allocp[14];
  allocp += 19;
  proceed();
 read__iu_5_5:
  deref_and_jump(x1,read__iu_5_4);
  *reasonp++ =  x1;
  goto read__iu_5_7;
 read__iu_5_6:
  deref_and_jump(x1,read__iu_5_3);
  *reasonp++ =  x1;
  goto read__iu_5_7;
 case VARREF:
  deref_and_jump(x0,read__iu_5_2);
  *reasonp++ =  x0;
  goto read__iu_5_7;
  };
  goto read__iu_5_7;
 case ATOMIC:
  if (a0 != NILATOM) goto read__iu_5_7;
  x0 = makesym(atom_error);
  x1 = makesym(atom_read__iu);
  unify(x0, x1);
  proceed();
 case VARREF:
  deref_and_jump(a0,read__iu_5_1);
  *reasonp++ =  a0;
  goto read__iu_5_7;
  };
  goto read__iu_5_7;
 read__iu_5_7:
  otherwise(read__iu_5_interrupt);
 read__iu_5_8:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(read__iu_5_0);
  goto read__iu_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,read__iu_5_8);
  *reasonp++ =  a0;
  goto read__iu_5_interrupt;
  };
  goto read__iu_5_interrupt;
 read__iu_5_ext_interrupt:
  reasonp = 0l;
 read__iu_5_interrupt:
  toppred = &predicate_vt_xread__iu_5;
  goto interrupt_5;
 }

 write__iu_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 write__iu_6_clear_reason:
  reasonp = reasons;
 write__iu_6_0:
 write__iu_6_1:
  switch (ptagof(a4)) {
 case CONS:
  x0 = car_of(a4);
 write__iu_6_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto write__iu_6_7;
  x1 = arg(x0, 0);
 write__iu_6_3:
  if (isref(x1)) goto write__iu_6_6;
 write__iu_6_4:
  if (isref(x1)) goto write__iu_6_5;
  if_not_equal(x1, a0, write__iu_6_7);
  allocp[0] = makesym(functor_module_2);
  allocp[1] = a0;
  allocp[2] = x3 = makeref(&allocp[2]);
  x2 = makefunctor(&allocp[0]);
  x5 = cdr_of(a4);
  allocp[3] = x5;
  allocp[4] = x2;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a5, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = a1;
  x6 = arg(x0, 1);
  allocp[3] = x6;
  allocp[4] = x7 = makeref(&allocp[4]);
  allocp[5] = x3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[8] = x8 = makeref(&allocp[8]);
  allocp[9] = x9 = makeref(&allocp[9]);
  allocp[10] = x10 = makeref(&allocp[10]);
  allocp[11] = x7;
  allocp[12] = (q)(struct goalrec*)&allocp[6];
  allocp[13] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[14] = a2;
  allocp[15] = makeint(1L);
  allocp[16] = x8;
  allocp[17] = makesym(functor_v_3);
  allocp[18] = x12 = makeref(&allocp[18]);
  allocp[19] = a3;
  allocp[20] = x13 = makeref(&allocp[20]);
  x11 = makefunctor(&allocp[17]);
  qp = (struct goalrec*)&allocp[12];
  allocp += 21;
  unify_value(x10, x11);
  allocp[0] = makesym(functor_v_3);
  allocp[1] = x12;
  allocp[2] = x15 = makeref(&allocp[2]);
  allocp[3] = x13;
  x14 = makefunctor(&allocp[0]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_functor__table_xarg_3);
  allocp[6] = x16 = makeref(&allocp[6]);
  allocp[7] = x9;
  allocp[8] = x14;
  allocp[9] = (q)(struct goalrec*)&allocp[4];
  allocp[10] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[11] = a2;
  allocp[12] = makeint(1L);
  allocp[13] = x16;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_functor__table_xarg_3);
  allocp[16] = a1;
  allocp[17] = x6;
  allocp[18] = x9;
  qp = (struct goalrec*)&allocp[14];
  allocp += 19;
  proceed();
 write__iu_6_5:
  deref_and_jump(x1,write__iu_6_4);
  *reasonp++ =  x1;
  goto write__iu_6_7;
 write__iu_6_6:
  deref_and_jump(x1,write__iu_6_3);
  *reasonp++ =  x1;
  goto write__iu_6_7;
 case VARREF:
  deref_and_jump(x0,write__iu_6_2);
  *reasonp++ =  x0;
  goto write__iu_6_7;
  };
  goto write__iu_6_7;
 case ATOMIC:
  if (a4 != NILATOM) goto write__iu_6_7;
  unify_value(a5, a4);
  x0 = makesym(atom_error);
  x1 = makesym(atom_write__iu);
  unify(x0, x1);
  proceed();
 case VARREF:
  deref_and_jump(a4,write__iu_6_1);
  *reasonp++ =  a4;
  goto write__iu_6_7;
  };
  goto write__iu_6_7;
 write__iu_6_7:
  otherwise(write__iu_6_interrupt);
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = x2 = makeref(&allocp[1]);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a4, x0);
  allocp[0] = x4 = makeref(&allocp[0]);
  allocp[1] = x2;
  x3 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a5, x3);
  a4 = x1;
  a5 = x4;
  execute(write__iu_6_0);
  goto write__iu_6_ext_interrupt;
 write__iu_6_ext_interrupt:
  reasonp = 0l;
 write__iu_6_interrupt:
  goto interrupt_6;
 }

 delete__iu_4_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 delete__iu_4_clear_reason:
  reasonp = reasons;
 delete__iu_4_0:
  allocp[0] = makesym(functor_v_4);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  x0 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a0, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vt_xwrite__iu_6);
  allocp[2] = x1;
  allocp[3] = x2;
  allocp[4] = x3;
  allocp[5] = x5 = makeref(&allocp[5]);
  allocp[6] = a2;
  allocp[7] = a3;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_vt_xdelete__element_3);
  allocp[10] = a1;
  allocp[11] = x6 = makeref(&allocp[11]);
  allocp[12] = x5;
  a0 = a2;
  a1 = x1;
  a2 = x2;
  a3 = x3;
  a4 = x6;
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  execute(read__iu_5_0);
  goto read__iu_5_ext_interrupt;
 delete__iu_4_ext_interrupt:
  reasonp = 0l;
 delete__iu_4_interrupt:
  goto interrupt_4;
 }

 delete__element_3_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  qp = qp->next;
 delete__element_3_clear_reason:
  reasonp = reasons;
 delete__element_3_0:
 delete__element_3_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 delete__element_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_v_4)) goto delete__element_3_16;
 delete__element_3_3:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_v_4)) goto delete__element_3_16;
  x1 = arg(a0, 0);
 delete__element_3_4:
  if (isref(x1)) goto delete__element_3_15;
 delete__element_3_5:
  if (isref(x1)) goto delete__element_3_14;
  x2 = arg(x0, 0);
  if_not_equal(x1, x2, delete__element_3_16);
  x3 = arg(a0, 1);
 delete__element_3_6:
  if (isref(x3)) goto delete__element_3_13;
 delete__element_3_7:
  if (isref(x3)) goto delete__element_3_12;
  x4 = arg(x0, 1);
  if_not_equal(x3, x4, delete__element_3_16);
  x5 = arg(a0, 2);
 delete__element_3_8:
  if (isref(x5)) goto delete__element_3_11;
 delete__element_3_9:
  if (isref(x5)) goto delete__element_3_10;
  x6 = arg(x0, 2);
  if_not_equal(x5, x6, delete__element_3_16);
  a1 = cdr_of(a1);
  execute(delete__element_3_clear_reason);
  goto delete__element_3_ext_interrupt;
 delete__element_3_10:
  deref_and_jump(x5,delete__element_3_9);
  *reasonp++ =  x5;
  goto delete__element_3_16;
 delete__element_3_11:
  deref_and_jump(x5,delete__element_3_8);
  *reasonp++ =  x5;
  goto delete__element_3_16;
 delete__element_3_12:
  deref_and_jump(x3,delete__element_3_7);
  *reasonp++ =  x3;
  goto delete__element_3_16;
 delete__element_3_13:
  deref_and_jump(x3,delete__element_3_6);
  *reasonp++ =  x3;
  goto delete__element_3_16;
 delete__element_3_14:
  deref_and_jump(x1,delete__element_3_5);
  *reasonp++ =  x1;
  goto delete__element_3_16;
 delete__element_3_15:
  deref_and_jump(x1,delete__element_3_4);
  *reasonp++ =  x1;
  goto delete__element_3_16;
 case VARREF:
  deref_and_jump(a0,delete__element_3_3);
  *reasonp++ =  a0;
  goto delete__element_3_16;
  };
  goto delete__element_3_16;
 case VARREF:
  deref_and_jump(x0,delete__element_3_2);
  *reasonp++ =  x0;
  goto delete__element_3_16;
  };
  goto delete__element_3_16;
 case VARREF:
  deref_and_jump(a1,delete__element_3_1);
  *reasonp++ =  a1;
  goto delete__element_3_16;
  };
  goto delete__element_3_16;
 delete__element_3_16:
  otherwise(delete__element_3_interrupt);
 delete__element_3_17:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a1);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  a1 = cdr_of(a1);
  a2 = x1;
  execute(delete__element_3_0);
  goto delete__element_3_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto delete__element_3_interrupt;
  x0 = NILATOM;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,delete__element_3_17);
  *reasonp++ =  a1;
  goto delete__element_3_interrupt;
  };
  goto delete__element_3_interrupt;
 delete__element_3_ext_interrupt:
  reasonp = 0l;
 delete__element_3_interrupt:
  goto interrupt_3;
 }

 read__av_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 read__av_5_clear_reason:
  reasonp = reasons;
 read__av_5_0:
 read__av_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 read__av_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto read__av_5_7;
  x1 = arg(x0, 0);
 read__av_5_3:
  if (isref(x1)) goto read__av_5_6;
 read__av_5_4:
  if (isref(x1)) goto read__av_5_5;
  if_not_equal(x1, a1, read__av_5_7);
  allocp[0] = makesym(functor_v_3);
  allocp[1] = x3 = makeref(&allocp[1]);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = a4;
  x2 = makefunctor(&allocp[0]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_functor__table_xarg_3);
  allocp[6] = x5 = makeref(&allocp[6]);
  allocp[7] = x6 = makeref(&allocp[7]);
  allocp[8] = x2;
  allocp[9] = (q)(struct goalrec*)&allocp[4];
  allocp[10] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[11] = a3;
  allocp[12] = makeint(1L);
  allocp[13] = x5;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_functor__table_xarg_3);
  allocp[16] = a2;
  x7 = arg(x0, 1);
  allocp[17] = x7;
  allocp[18] = x6;
  qp = (struct goalrec*)&allocp[14];
  allocp += 19;
  proceed();
 read__av_5_5:
  deref_and_jump(x1,read__av_5_4);
  *reasonp++ =  x1;
  goto read__av_5_7;
 read__av_5_6:
  deref_and_jump(x1,read__av_5_3);
  *reasonp++ =  x1;
  goto read__av_5_7;
 case VARREF:
  deref_and_jump(x0,read__av_5_2);
  *reasonp++ =  x0;
  goto read__av_5_7;
  };
  goto read__av_5_7;
 case ATOMIC:
  if (a0 != NILATOM) goto read__av_5_7;
  x0 = makesym(atom_error);
  x1 = makesym(atom_read__av);
  unify(x0, x1);
  proceed();
 case VARREF:
  deref_and_jump(a0,read__av_5_1);
  *reasonp++ =  a0;
  goto read__av_5_7;
  };
  goto read__av_5_7;
 read__av_5_7:
  otherwise(read__av_5_interrupt);
 read__av_5_8:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(read__av_5_0);
  goto read__av_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,read__av_5_8);
  *reasonp++ =  a0;
  goto read__av_5_interrupt;
  };
  goto read__av_5_interrupt;
 read__av_5_ext_interrupt:
  reasonp = 0l;
 read__av_5_interrupt:
  toppred = &predicate_vt_xread__av_5;
  goto interrupt_5;
 }

 write__av_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 write__av_6_clear_reason:
  reasonp = reasons;
 write__av_6_0:
 write__av_6_1:
  switch (ptagof(a4)) {
 case CONS:
  x0 = car_of(a4);
 write__av_6_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto write__av_6_7;
  x1 = arg(x0, 0);
 write__av_6_3:
  if (isref(x1)) goto write__av_6_6;
 write__av_6_4:
  if (isref(x1)) goto write__av_6_5;
  if_not_equal(x1, a0, write__av_6_7);
  allocp[0] = makesym(functor_module_2);
  allocp[1] = a0;
  allocp[2] = x3 = makeref(&allocp[2]);
  x2 = makefunctor(&allocp[0]);
  x5 = cdr_of(a4);
  allocp[3] = x5;
  allocp[4] = x2;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a5, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = a1;
  x6 = arg(x0, 1);
  allocp[3] = x6;
  allocp[4] = x7 = makeref(&allocp[4]);
  allocp[5] = x3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[8] = x8 = makeref(&allocp[8]);
  allocp[9] = x9 = makeref(&allocp[9]);
  allocp[10] = x10 = makeref(&allocp[10]);
  allocp[11] = x7;
  allocp[12] = (q)(struct goalrec*)&allocp[6];
  allocp[13] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[14] = a2;
  allocp[15] = makeint(1L);
  allocp[16] = x8;
  allocp[17] = makesym(functor_v_3);
  allocp[18] = x12 = makeref(&allocp[18]);
  allocp[19] = x13 = makeref(&allocp[19]);
  allocp[20] = a3;
  x11 = makefunctor(&allocp[17]);
  qp = (struct goalrec*)&allocp[12];
  allocp += 21;
  unify_value(x10, x11);
  allocp[0] = makesym(functor_v_3);
  allocp[1] = x12;
  allocp[2] = x13;
  allocp[3] = x15 = makeref(&allocp[3]);
  x14 = makefunctor(&allocp[0]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_functor__table_xarg_3);
  allocp[6] = x16 = makeref(&allocp[6]);
  allocp[7] = x9;
  allocp[8] = x14;
  allocp[9] = (q)(struct goalrec*)&allocp[4];
  allocp[10] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[11] = a2;
  allocp[12] = makeint(1L);
  allocp[13] = x16;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_functor__table_xarg_3);
  allocp[16] = a1;
  allocp[17] = x6;
  allocp[18] = x9;
  qp = (struct goalrec*)&allocp[14];
  allocp += 19;
  proceed();
 write__av_6_5:
  deref_and_jump(x1,write__av_6_4);
  *reasonp++ =  x1;
  goto write__av_6_7;
 write__av_6_6:
  deref_and_jump(x1,write__av_6_3);
  *reasonp++ =  x1;
  goto write__av_6_7;
 case VARREF:
  deref_and_jump(x0,write__av_6_2);
  *reasonp++ =  x0;
  goto write__av_6_7;
  };
  goto write__av_6_7;
 case ATOMIC:
  if (a4 != NILATOM) goto write__av_6_7;
  unify_value(a5, a4);
  x0 = makesym(atom_error);
  x1 = makesym(atom_write__av);
  unify(x0, x1);
  proceed();
 case VARREF:
  deref_and_jump(a4,write__av_6_1);
  *reasonp++ =  a4;
  goto write__av_6_7;
  };
  goto write__av_6_7;
 write__av_6_7:
  otherwise(write__av_6_interrupt);
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = x2 = makeref(&allocp[1]);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a4, x0);
  allocp[0] = x4 = makeref(&allocp[0]);
  allocp[1] = x2;
  x3 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a5, x3);
  a4 = x1;
  a5 = x4;
  execute(write__av_6_0);
  goto write__av_6_ext_interrupt;
 write__av_6_ext_interrupt:
  reasonp = 0l;
 write__av_6_interrupt:
  goto interrupt_6;
 }

 check__av_5_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 check__av_5_clear_reason:
  reasonp = reasons;
 check__av_5_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vt_xcheck__av2_5);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  a4 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(read__av_5_0);
  goto read__av_5_ext_interrupt;
 check__av_5_ext_interrupt:
  reasonp = 0l;
 check__av_5_interrupt:
  goto interrupt_5;
 }

 check__av2_5_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 check__av2_5_clear_reason:
  reasonp = reasons;
 check__av2_5_0:
 check__av2_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 check__av2_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_v_3)) goto check__av2_5_15;
  x1 = arg(x0, 0);
 check__av2_5_3:
  if (isref(x1)) goto check__av2_5_14;
 check__av2_5_4:
  if (isref(x1)) goto check__av2_5_13;
  if_not_equal(x1, a1, check__av2_5_15);
  x2 = arg(x0, 1);
 check__av2_5_5:
  if (isref(x2)) goto check__av2_5_12;
 check__av2_5_6:
  if (isref(x2)) goto check__av2_5_11;
  if_not_equal(x2, a2, check__av2_5_15);
 check__av2_5_7:
  if (!isint(a3)) goto check__av2_5_10;
  x3 = arg(x0, 2);
 check__av2_5_8:
  if (!isint(x3)) goto check__av2_5_9;
  gblt_less(a3,x3,check__av2_5_15);
  allocp[0] = makesym(functor_v_4);
  allocp[1] = a1;
  allocp[2] = a2;
  allocp[3] = x3;
  allocp[4] = makeint(-1L);
  x4 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a4, x4);
  proceed();
 check__av2_5_9:
  if (!isref(x3)) goto check__av2_5_15;
  deref_and_jump(x3,check__av2_5_8);
  *reasonp++ =  x3;
  goto check__av2_5_15;
 check__av2_5_10:
  if (!isref(a3)) goto check__av2_5_15;
  deref_and_jump(a3,check__av2_5_7);
  *reasonp++ =  a3;
  goto check__av2_5_15;
 check__av2_5_11:
  deref_and_jump(x2,check__av2_5_6);
  *reasonp++ =  x2;
  goto check__av2_5_15;
 check__av2_5_12:
  deref_and_jump(x2,check__av2_5_5);
  *reasonp++ =  x2;
  goto check__av2_5_15;
 check__av2_5_13:
  deref_and_jump(x1,check__av2_5_4);
  *reasonp++ =  x1;
  goto check__av2_5_15;
 check__av2_5_14:
  deref_and_jump(x1,check__av2_5_3);
  *reasonp++ =  x1;
  goto check__av2_5_15;
 case VARREF:
  deref_and_jump(x0,check__av2_5_2);
  *reasonp++ =  x0;
  goto check__av2_5_15;
  };
  goto check__av2_5_15;
 case VARREF:
  deref_and_jump(a0,check__av2_5_1);
  *reasonp++ =  a0;
  goto check__av2_5_15;
  };
  goto check__av2_5_15;
 check__av2_5_15:
  otherwise(check__av2_5_interrupt);
 check__av2_5_16:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(check__av2_5_0);
  goto check__av2_5_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto check__av2_5_interrupt;
  x0 = makesym(atom_no);
  unify_value(a4, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,check__av2_5_16);
  *reasonp++ =  a0;
  goto check__av2_5_interrupt;
  };
  goto check__av2_5_interrupt;
 check__av2_5_ext_interrupt:
  reasonp = 0l;
 check__av2_5_interrupt:
  goto interrupt_5;
 }

 gen__av_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 gen__av_5_clear_reason:
  reasonp = reasons;
 gen__av_5_0:
 gen__av_5_1:
  switch (ptagof(a3)) {
 case CONS:
  x0 = car_of(a3);
 gen__av_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto gen__av_5_7;
  x1 = arg(x0, 0);
 gen__av_5_3:
  if (isref(x1)) goto gen__av_5_6;
 gen__av_5_4:
  if (isref(x1)) goto gen__av_5_5;
  if_not_equal(x1, a0, gen__av_5_7);
  allocp[0] = makesym(functor_module_2);
  allocp[1] = a0;
  allocp[2] = x3 = makeref(&allocp[2]);
  x2 = makefunctor(&allocp[0]);
  x5 = cdr_of(a3);
  allocp[3] = x5;
  allocp[4] = x2;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a4, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = a1;
  x6 = arg(x0, 1);
  allocp[3] = x6;
  allocp[4] = x7 = makeref(&allocp[4]);
  allocp[5] = x3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor_xinsert__arg_4);
  allocp[8] = x8 = makeref(&allocp[8]);
  allocp[9] = x9 = makeref(&allocp[9]);
  allocp[10] = makefunctor(funct_const_1);
  allocp[11] = x7;
  allocp[12] = (q)(struct goalrec*)&allocp[6];
  allocp[13] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[14] = x10 = makeref(&allocp[14]);
  allocp[15] = makeint(1L);
  allocp[16] = x8;
  qp = (struct goalrec*)&allocp[12];
  allocp += 17;
  unify(a2, x10);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[2] = x9;
  allocp[3] = x11 = makeref(&allocp[3]);
  allocp[4] = x10;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = a1;
  allocp[8] = x6;
  allocp[9] = x9;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 gen__av_5_5:
  deref_and_jump(x1,gen__av_5_4);
  *reasonp++ =  x1;
  goto gen__av_5_7;
 gen__av_5_6:
  deref_and_jump(x1,gen__av_5_3);
  *reasonp++ =  x1;
  goto gen__av_5_7;
 case VARREF:
  deref_and_jump(x0,gen__av_5_2);
  *reasonp++ =  x0;
  goto gen__av_5_7;
  };
  goto gen__av_5_7;
 case VARREF:
  deref_and_jump(a3,gen__av_5_1);
  *reasonp++ =  a3;
  goto gen__av_5_7;
  };
  goto gen__av_5_7;
 gen__av_5_7:
  otherwise(gen__av_5_interrupt);
 gen__av_5_8:
  switch (ptagof(a3)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a3);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a4, x0);
  a3 = cdr_of(a3);
  a4 = x1;
  execute(gen__av_5_0);
  goto gen__av_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a3,gen__av_5_8);
  *reasonp++ =  a3;
  goto gen__av_5_interrupt;
  };
  goto gen__av_5_interrupt;
 gen__av_5_ext_interrupt:
  reasonp = 0l;
 gen__av_5_interrupt:
  goto interrupt_5;
 }

 gen__av_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 gen__av_3_clear_reason:
  reasonp = reasons;
 gen__av_3_0:
  x0 = makesym(atom_error);
  x1 = makesym(atom_gen__av);
  unify(x0, x1);
  proceed();
 gen__av_3_ext_interrupt:
  reasonp = 0l;
 gen__av_3_interrupt:
  goto interrupt_3;
 }

 add__av_8_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 add__av_8_clear_reason:
  reasonp = reasons;
 add__av_8_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vt_xwrite__av_6);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x0 = makeref(&allocp[5]);
  allocp[6] = a6;
  allocp[7] = a7;
  allocp[8] = makesym(functor_v_3);
  allocp[9] = a3;
  allocp[10] = a4;
  allocp[11] = a5;
  x1 = makefunctor(&allocp[8]);
  allocp[12] = NILATOM;
  allocp[13] = x1;
  x2 = makecons(&allocp[12]);
  allocp[14] = (q)(struct goalrec*)&allocp[0];
  allocp[15] = (q)(&predicate_list_xappend_3);
  allocp[16] = x3 = makeref(&allocp[16]);
  allocp[17] = x2;
  allocp[18] = x0;
  x4 = a6;
  x5 = a0;
  x6 = a1;
  a3 = a2;
  a4 = x3;
  a2 = x6;
  a1 = x5;
  a0 = x4;
  qp = (struct goalrec*)&allocp[14];
  allocp += 19;
  execute(read__av_5_0);
  goto read__av_5_ext_interrupt;
 add__av_8_ext_interrupt:
  reasonp = 0l;
 add__av_8_interrupt:
  goto interrupt_8;
 }

 replace__tv_10_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 replace__tv_10_clear_reason:
  reasonp = reasons;
 replace__tv_10_0:
 replace__tv_10_1:
  switch (ptagof(a8)) {
 case CONS:
  x0 = car_of(a8);
 replace__tv_10_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto replace__tv_10_interrupt;
  allocp[0] = makesym(functor_module_2);
  x2 = arg(x0, 0);
  allocp[1] = x2;
  allocp[2] = x3 = makeref(&allocp[2]);
  x1 = makefunctor(&allocp[0]);
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = x1;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a9, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vt_xreplace__tv_10);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  x6 = cdr_of(a8);
  allocp[10] = x6;
  allocp[11] = x5;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_vt_xreplace__tv_11);
  allocp[14] = x7 = makeref(&allocp[14]);
  x8 = arg(x0, 1);
  allocp[15] = x8;
  allocp[16] = x3;
  allocp[17] = a0;
  allocp[18] = a1;
  allocp[19] = a2;
  allocp[20] = a3;
  allocp[21] = a4;
  allocp[22] = a5;
  allocp[23] = a6;
  allocp[24] = a7;
  allocp[25] = (q)(struct goalrec*)&allocp[12];
  allocp[26] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[27] = x8;
  allocp[28] = x9 = makeref(&allocp[28]);
  allocp[29] = x7;
  qp = (struct goalrec*)&allocp[25];
  allocp += 30;
  proceed();
 case VARREF:
  deref_and_jump(x0,replace__tv_10_2);
  *reasonp++ =  x0;
  goto replace__tv_10_interrupt;
  };
  goto replace__tv_10_interrupt;
 case ATOMIC:
  if (a8 != NILATOM) goto replace__tv_10_interrupt;
  unify_value(a9, a8);
  proceed();
 case VARREF:
  deref_and_jump(a8,replace__tv_10_1);
  *reasonp++ =  a8;
  goto replace__tv_10_interrupt;
  };
  goto replace__tv_10_interrupt;
 replace__tv_10_ext_interrupt:
  reasonp = 0l;
 replace__tv_10_interrupt:
  goto interrupt_10;
 }

 replace__tv_11_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 replace__tv_11_clear_reason:
  reasonp = reasons;
 replace__tv_11_0:
 replace__tv_11_1:
  if (!isint(a0)) goto replace__tv_11_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,replace__tv_11_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vt_xreplace__tv_11);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  allocp[12] = a10;
  allocp[13] = (q)(struct goalrec*)&allocp[0];
  allocp[14] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[15] = a0;
  allocp[16] = makeint(1L);
  allocp[17] = x1;
  allocp[18] = (q)(struct goalrec*)&allocp[13];
  allocp[19] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[20] = a0;
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = x4 = makeref(&allocp[22]);
  allocp[23] = x2;
  allocp[24] = (q)(struct goalrec*)&allocp[18];
  allocp[25] = (q)(&predicate_vt_xreplace__tv1_10);
  allocp[26] = x3;
  allocp[27] = x4;
  allocp[28] = a3;
  allocp[29] = a4;
  allocp[30] = a5;
  allocp[31] = a6;
  allocp[32] = a7;
  allocp[33] = a8;
  allocp[34] = a9;
  allocp[35] = a10;
  allocp[36] = (q)(struct goalrec*)&allocp[24];
  allocp[37] = (q)(&predicate_functor__table_xarg_3);
  allocp[38] = a0;
  allocp[39] = a1;
  allocp[40] = x3;
  qp = (struct goalrec*)&allocp[36];
  allocp += 41;
  proceed();
 replace__tv_11_2:
  if (a0 != makeint(0L)) goto replace__tv_11_interrupt;
  unify(a2, a1);
  proceed();
 replace__tv_11_3:
  if (!isref(a0)) goto replace__tv_11_interrupt;
  deref_and_jump(a0,replace__tv_11_1);
  *reasonp++ =  a0;
  goto replace__tv_11_interrupt;
 replace__tv_11_ext_interrupt:
  reasonp = 0l;
 replace__tv_11_interrupt:
  goto interrupt_11;
 }

 replace__tv1_10_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 replace__tv1_10_clear_reason:
  reasonp = reasons;
 replace__tv1_10_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vt_xreplace__tv2_11);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = a8;
  allocp[12] = a9;
  allocp[13] = (q)(struct goalrec*)&allocp[0];
  allocp[14] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[15] = a0;
  allocp[16] = x1 = makeref(&allocp[16]);
  allocp[17] = x0;
  qp = (struct goalrec*)&allocp[13];
  allocp += 18;
  proceed();
 replace__tv1_10_ext_interrupt:
  reasonp = 0l;
 replace__tv1_10_interrupt:
  goto interrupt_10;
 }

 replace__tv2_11_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 replace__tv2_11_clear_reason:
  reasonp = reasons;
 replace__tv2_11_0:
 replace__tv2_11_1:
  if (!isint(a0)) goto replace__tv2_11_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,replace__tv2_11_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vt_xreplace__tv2_11);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  allocp[12] = a10;
  allocp[13] = (q)(struct goalrec*)&allocp[0];
  allocp[14] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[15] = a0;
  allocp[16] = makeint(1L);
  allocp[17] = x1;
  allocp[18] = makesym(functor_v_3);
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = x5 = makeref(&allocp[20]);
  allocp[21] = x6 = makeref(&allocp[21]);
  x3 = makefunctor(&allocp[18]);
  allocp[22] = (q)(struct goalrec*)&allocp[13];
  allocp[23] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[24] = a0;
  allocp[25] = a1;
  allocp[26] = x3;
  allocp[27] = x2;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_vt_xreplace__tv3_10);
  allocp[30] = x7 = makeref(&allocp[30]);
  allocp[31] = x4;
  allocp[32] = a3;
  allocp[33] = a4;
  allocp[34] = a5;
  allocp[35] = a6;
  allocp[36] = a7;
  allocp[37] = a8;
  allocp[38] = a9;
  allocp[39] = a10;
  allocp[40] = makesym(functor_v_3);
  allocp[41] = x7;
  allocp[42] = x5;
  allocp[43] = x6;
  x8 = makefunctor(&allocp[40]);
  allocp[44] = (q)(struct goalrec*)&allocp[28];
  allocp[45] = (q)(&predicate_functor__table_xarg_3);
  allocp[46] = a0;
  allocp[47] = a1;
  allocp[48] = x8;
  qp = (struct goalrec*)&allocp[44];
  allocp += 49;
  proceed();
 replace__tv2_11_2:
  if (a0 != makeint(0L)) goto replace__tv2_11_interrupt;
  unify(a2, a1);
  proceed();
 replace__tv2_11_3:
  if (!isref(a0)) goto replace__tv2_11_interrupt;
  deref_and_jump(a0,replace__tv2_11_1);
  *reasonp++ =  a0;
  goto replace__tv2_11_interrupt;
 replace__tv2_11_ext_interrupt:
  reasonp = 0l;
 replace__tv2_11_interrupt:
  goto interrupt_11;
 }

 replace__tv3_10_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 replace__tv3_10_clear_reason:
  reasonp = reasons;
 replace__tv3_10_0:
 replace__tv3_10_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 replace__tv3_10_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_tv_2)) goto replace__tv3_10_20;
  x1 = arg(x0, 0);
 replace__tv3_10_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_v_4)) goto replace__tv3_10_20;
  x2 = arg(x1, 0);
 replace__tv3_10_4:
  if (isref(x2)) goto replace__tv3_10_19;
 replace__tv3_10_5:
  if (isref(x2)) goto replace__tv3_10_18;
  if_not_equal(x2, a2, replace__tv3_10_20);
  x3 = arg(x1, 1);
 replace__tv3_10_6:
  if (isref(x3)) goto replace__tv3_10_17;
 replace__tv3_10_7:
  if (isref(x3)) goto replace__tv3_10_16;
  if_not_equal(x3, a3, replace__tv3_10_20);
  x4 = arg(x1, 2);
 replace__tv3_10_8:
  if (isref(x4)) goto replace__tv3_10_15;
 replace__tv3_10_9:
  if (isref(x4)) goto replace__tv3_10_14;
  if_not_equal(x4, a4, replace__tv3_10_20);
  x5 = arg(x1, 3);
 replace__tv3_10_10:
  if (isref(x5)) goto replace__tv3_10_13;
 replace__tv3_10_11:
  if (isref(x5)) goto replace__tv3_10_12;
  if_not_equal(x5, a5, replace__tv3_10_20);
  allocp[0] = makesym(functor_v_4);
  allocp[1] = a6;
  allocp[2] = a7;
  allocp[3] = a8;
  allocp[4] = a9;
  x6 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_tv_2);
  allocp[6] = x6;
  x8 = arg(x0, 1);
  allocp[7] = x8;
  x7 = makefunctor(&allocp[5]);
  allocp[8] = x10 = makeref(&allocp[8]);
  allocp[9] = x7;
  x9 = makecons(&allocp[8]);
  allocp += 10;
  unify_value(a1, x9);
  a0 = cdr_of(a0);
  a1 = x10;
  execute(replace__tv3_10_clear_reason);
  goto replace__tv3_10_ext_interrupt;
 replace__tv3_10_12:
  deref_and_jump(x5,replace__tv3_10_11);
  *reasonp++ =  x5;
  goto replace__tv3_10_20;
 replace__tv3_10_13:
  deref_and_jump(x5,replace__tv3_10_10);
  *reasonp++ =  x5;
  goto replace__tv3_10_20;
 replace__tv3_10_14:
  deref_and_jump(x4,replace__tv3_10_9);
  *reasonp++ =  x4;
  goto replace__tv3_10_20;
 replace__tv3_10_15:
  deref_and_jump(x4,replace__tv3_10_8);
  *reasonp++ =  x4;
  goto replace__tv3_10_20;
 replace__tv3_10_16:
  deref_and_jump(x3,replace__tv3_10_7);
  *reasonp++ =  x3;
  goto replace__tv3_10_20;
 replace__tv3_10_17:
  deref_and_jump(x3,replace__tv3_10_6);
  *reasonp++ =  x3;
  goto replace__tv3_10_20;
 replace__tv3_10_18:
  deref_and_jump(x2,replace__tv3_10_5);
  *reasonp++ =  x2;
  goto replace__tv3_10_20;
 replace__tv3_10_19:
  deref_and_jump(x2,replace__tv3_10_4);
  *reasonp++ =  x2;
  goto replace__tv3_10_20;
 case VARREF:
  deref_and_jump(x1,replace__tv3_10_3);
  *reasonp++ =  x1;
  goto replace__tv3_10_20;
  };
  goto replace__tv3_10_20;
 case VARREF:
  deref_and_jump(x0,replace__tv3_10_2);
  *reasonp++ =  x0;
  goto replace__tv3_10_20;
  };
  goto replace__tv3_10_20;
 case VARREF:
  deref_and_jump(a0,replace__tv3_10_1);
  *reasonp++ =  a0;
  goto replace__tv3_10_20;
  };
  goto replace__tv3_10_20;
 replace__tv3_10_20:
  otherwise(replace__tv3_10_interrupt);
 replace__tv3_10_21:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(replace__tv3_10_0);
  goto replace__tv3_10_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto replace__tv3_10_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,replace__tv3_10_21);
  *reasonp++ =  a0;
  goto replace__tv3_10_interrupt;
  };
  goto replace__tv3_10_interrupt;
 replace__tv3_10_ext_interrupt:
  reasonp = 0l;
 replace__tv3_10_interrupt:
  goto interrupt_10;
 }

 remove__ds_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  qp = qp->next;
 remove__ds_2_clear_reason:
  reasonp = reasons;
 remove__ds_2_0:
 remove__ds_2_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = makesym(functor_module_2);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  x0 = makefunctor(&allocp[0]);
  x3 = car_of(a0);
  allocp += 3;
  unify_value(x3, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vt_xremove__ds_2);
  x4 = cdr_of(a0);
  allocp[2] = x4;
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = makesym(functor_module_2);
  allocp[5] = x1;
  allocp[6] = x7 = makeref(&allocp[6]);
  x6 = makefunctor(&allocp[4]);
  allocp[7] = x5;
  allocp[8] = x6;
  x8 = makecons(&allocp[7]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 9;
  unify_value(a1, x8);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vt_xremove__ds__clauses_3);
  allocp[2] = x9 = makeref(&allocp[2]);
  allocp[3] = x2;
  allocp[4] = x7;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[7] = x2;
  allocp[8] = x10 = makeref(&allocp[8]);
  allocp[9] = x9;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case ATOMIC:
  if (a0 != NILATOM) goto remove__ds_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,remove__ds_2_1);
  *reasonp++ =  a0;
  goto remove__ds_2_interrupt;
  };
  goto remove__ds_2_interrupt;
 remove__ds_2_ext_interrupt:
  reasonp = 0l;
 remove__ds_2_interrupt:
  goto interrupt_2;
 }

 remove__ds__clauses_3_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  qp = qp->next;
 remove__ds__clauses_3_clear_reason:
  reasonp = reasons;
 remove__ds__clauses_3_0:
 remove__ds__clauses_3_1:
  if (!isint(a0)) goto remove__ds__clauses_3_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,remove__ds__clauses_3_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vt_xremove__ds__clauses_3);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[7] = a0;
  allocp[8] = makeint(1L);
  allocp[9] = x1;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[12] = a0;
  allocp[13] = a1;
  allocp[14] = x3 = makeref(&allocp[14]);
  allocp[15] = x2;
  allocp[16] = (q)(struct goalrec*)&allocp[10];
  allocp[17] = (q)(&predicate_vt_xremove__ds__clause_3);
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = x5 = makeref(&allocp[19]);
  allocp[20] = x3;
  allocp[21] = (q)(struct goalrec*)&allocp[16];
  allocp[22] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[23] = x5;
  allocp[24] = x6 = makeref(&allocp[24]);
  allocp[25] = x4;
  allocp[26] = (q)(struct goalrec*)&allocp[21];
  allocp[27] = (q)(&predicate_functor__table_xarg_3);
  allocp[28] = a0;
  allocp[29] = a1;
  allocp[30] = x5;
  qp = (struct goalrec*)&allocp[26];
  allocp += 31;
  proceed();
 remove__ds__clauses_3_2:
  if (a0 != makeint(0L)) goto remove__ds__clauses_3_interrupt;
  unify(a2, a1);
  proceed();
 remove__ds__clauses_3_3:
  if (!isref(a0)) goto remove__ds__clauses_3_interrupt;
  deref_and_jump(a0,remove__ds__clauses_3_1);
  *reasonp++ =  a0;
  goto remove__ds__clauses_3_interrupt;
 remove__ds__clauses_3_ext_interrupt:
  reasonp = 0l;
 remove__ds__clauses_3_interrupt:
  goto interrupt_3;
 }

 remove__ds__clause_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  qp = qp->next;
 remove__ds__clause_3_clear_reason:
  reasonp = reasons;
 remove__ds__clause_3_0:
 remove__ds__clause_3_1:
  if (!isint(a0)) goto remove__ds__clause_3_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,remove__ds__clause_3_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vt_xremove__ds__clause_3);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[7] = a0;
  allocp[8] = makeint(1L);
  allocp[9] = x1;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[12] = a0;
  allocp[13] = a1;
  allocp[14] = x3 = makeref(&allocp[14]);
  allocp[15] = x2;
  allocp[16] = makesym(functor_v_3);
  allocp[17] = x5 = makeref(&allocp[17]);
  allocp[18] = x6 = makeref(&allocp[18]);
  allocp[19] = x7 = makeref(&allocp[19]);
  x4 = makefunctor(&allocp[16]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 20;
  unify_value(x3, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xremove__ds_2);
  allocp[2] = x8 = makeref(&allocp[2]);
  allocp[3] = x5;
  allocp[4] = makesym(functor_v_3);
  allocp[5] = x8;
  allocp[6] = x6;
  allocp[7] = x7;
  x9 = makefunctor(&allocp[4]);
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_functor__table_xarg_3);
  allocp[10] = a0;
  allocp[11] = a1;
  allocp[12] = x9;
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  proceed();
 remove__ds__clause_3_2:
  if (a0 != makeint(0L)) goto remove__ds__clause_3_interrupt;
  unify(a2, a1);
  proceed();
 remove__ds__clause_3_3:
  if (!isref(a0)) goto remove__ds__clause_3_interrupt;
  deref_and_jump(a0,remove__ds__clause_3_1);
  *reasonp++ =  a0;
  goto remove__ds__clause_3_interrupt;
 remove__ds__clause_3_ext_interrupt:
  reasonp = 0l;
 remove__ds__clause_3_interrupt:
  goto interrupt_3;
 }
 interrupt_11:
  allocp[12] = a10;
 interrupt_10:
  allocp[11] = a9;
 interrupt_9:
  allocp[10] = a8;
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_vt);
}
