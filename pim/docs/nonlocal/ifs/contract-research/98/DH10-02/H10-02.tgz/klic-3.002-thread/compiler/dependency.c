/* Compiled by KLIC compiler version 3.002 (Wed Sep 17 15:37:13 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_dependency();
Const struct predicate predicate_dependency_xinit__deps_2 =
   { module_dependency, 0, 2 };
Const struct predicate predicate_dependency_xinit__clauses_3 =
   { module_dependency, 1, 3 };
Const struct predicate predicate_dependency_xinit__clause_2 =
   { module_dependency, 2, 2 };
Const struct predicate predicate_dependency_xmake__control__dep_3 =
   { module_dependency, 3, 3 };
Const struct predicate predicate_dependency_xmake__control__modules_8 =
   { module_dependency, 4, 8 };
Const struct predicate predicate_dependency_xmake__control__clauses_9 =
   { module_dependency, 5, 9 };
Const struct predicate predicate_dependency_xmake__depend__guards_4 =
   { module_dependency, 6, 4 };
Const struct predicate predicate_dependency_xmake__control__guards_6 =
   { module_dependency, 7, 6 };
Const struct predicate predicate_dependency_xmake__control__bodys_9 =
   { module_dependency, 8, 9 };
Const struct predicate predicate_dependency_xcall__modules_9 =
   { module_dependency, 9, 9 };
Const struct predicate predicate_dependency_xmake__data__dep_4 =
   { module_dependency, 10, 4 };
Const struct predicate predicate_dependency_xmake__data__dep2_4 =
   { module_dependency, 11, 4 };
Const struct predicate predicate_dependency_xmake__clauses__data_6 =
   { module_dependency, 12, 6 };
Const struct predicate predicate_dependency_xmake__clause__data_6 =
   { module_dependency, 13, 6 };
Const struct predicate predicate_dependency_xmake__goals__data_8 =
   { module_dependency, 14, 8 };
Const struct predicate predicate_dependency_xmake__goals__data1_9 =
   { module_dependency, 15, 9 };
Const struct predicate predicate_dependency_xmake__goal__dependency_10 =
   { module_dependency, 16, 10 };
Const struct predicate predicate_dependency_xcheck__headargs_4 =
   { module_dependency, 17, 4 };
Const struct predicate predicate_dependency_xcheck__headargs2_4 =
   { module_dependency, 18, 4 };
Const struct predicate predicate_dependency_xcheck__headargs3_4 =
   { module_dependency, 19, 4 };
Const struct predicate predicate_dependency_xuserdef_4 =
   { module_dependency, 20, 4 };
Const struct predicate predicate_dependency_xuserdef_5 =
   { module_dependency, 21, 5 };
Const struct predicate predicate_dependency_xuserdef__clauses_7 =
   { module_dependency, 22, 7 };
Const struct predicate predicate_dependency_xuserdef__clause_7 =
   { module_dependency, 23, 7 };
Const struct predicate predicate_dependency_xuserdef__bodys_8 =
   { module_dependency, 24, 8 };
Const struct predicate predicate_dependency_xuserdef__body_7 =
   { module_dependency, 25, 7 };
Const struct predicate predicate_dependency_xget__clauses__ds_5 =
   { module_dependency, 26, 5 };
Const struct predicate predicate_dependency_xindirect_4 =
   { module_dependency, 27, 4 };
Const struct predicate predicate_dependency_xindirect__clause_8 =
   { module_dependency, 28, 8 };
Const struct predicate predicate_dependency_xindirect__goals_9 =
   { module_dependency, 29, 9 };
Const struct predicate predicate_dependency_xindirect__goals1_9 =
   { module_dependency, 30, 9 };
Const struct predicate predicate_dependency_xindirect__goal_7 =
   { module_dependency, 31, 7 };
Const struct predicate predicate_dependency_xexpand__indirect_6 =
   { module_dependency, 32, 6 };
Const struct predicate predicate_dependency_xexpand__indirect_7 =
   { module_dependency, 33, 7 };
extern Const struct predicate predicate_list_xor__unique_3;
extern Const struct predicate predicate_functor_xnew__functor__init_4;
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_xsetarg_4;
extern Const struct predicate predicate_functor__table_xfunctor_3;
extern Const struct predicate predicate_parse__uty_xget__first__clause__info_4;
extern Const struct predicate predicate_parse__uty_xdecode__goalcall_6;
extern Const struct predicate predicate_parse__uty_xdecode__goal_4;
extern Const struct predicate predicate_parse__uty_xget__def__clauses_5;
extern Const struct predicate predicate_parse__uty_xget__clause_4;
extern Const struct predicate predicate_parse__uty_xget__next__clause_6;
extern Const struct predicate predicate_parse__uty_xget__goal_6;
extern Const struct predicate predicate_parse__uty_xupdate__goal_7;
extern Const struct predicate predicate_dt_xentry_5;
extern Const struct predicate predicate_dt_xentry__data__dep_4;
extern Const struct predicate predicate_dt_xget__guard__ds_4;
extern Const struct predicate predicate_dt_xget__deps_4;
extern Const struct predicate predicate_builtin__deps_xmake_11;

module module_dependency(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  static Const q funct_const_0[] = {
    makesym(functor_dep_2),
    NILATOM,
    NILATOM,
  };
  q a0, a1, a2, a3, a4, a5, a6, a7, a8, a9;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, init__deps_2_top);
    case_pred(1, init__clauses_3_top);
    case_pred(2, init__clause_2_top);
    case_pred(3, make__control__dep_3_top);
    case_pred(4, make__control__modules_8_top);
    case_pred(5, make__control__clauses_9_top);
    case_pred(6, make__depend__guards_4_top);
    case_pred(7, make__control__guards_6_top);
    case_pred(8, make__control__bodys_9_top);
    case_pred(9, call__modules_9_top);
    case_pred(10, make__data__dep_4_top);
    case_pred(11, make__data__dep2_4_top);
    case_pred(12, make__clauses__data_6_top);
    case_pred(13, make__clause__data_6_top);
    case_pred(14, make__goals__data_8_top);
    case_pred(15, make__goals__data1_9_top);
    case_pred(16, make__goal__dependency_10_top);
    case_pred(17, check__headargs_4_top);
    case_pred(18, check__headargs2_4_top);
    case_pred(19, check__headargs3_4_top);
    case_pred(20, userdef_4_top);
    case_pred(21, userdef_5_top);
    case_pred(22, userdef__clauses_7_top);
    case_pred(23, userdef__clause_7_top);
    case_pred(24, userdef__bodys_8_top);
    case_pred(25, userdef__body_7_top);
    case_pred(26, get__clauses__ds_5_top);
    case_pred(27, indirect_4_top);
    case_pred(28, indirect__clause_8_top);
    case_pred(29, indirect__goals_9_top);
    case_pred(30, indirect__goals1_9_top);
    case_pred(31, indirect__goal_7_top);
    case_pred(32, expand__indirect_6_top);
    last_case_pred(33, expand__indirect_7_top);
  }

 init__deps_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  qp = qp->next;
 init__deps_2_clear_reason:
  reasonp = reasons;
 init__deps_2_0:
 init__deps_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 init__deps_2_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto init__deps_2_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xinit__deps_2);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = makesym(functor_module_2);
  x4 = arg(x0, 0);
  allocp[5] = x4;
  allocp[6] = x5 = makeref(&allocp[6]);
  x3 = makefunctor(&allocp[4]);
  allocp[7] = x2;
  allocp[8] = x3;
  x6 = makecons(&allocp[7]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 9;
  unify_value(a1, x6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xinit__clauses_3);
  allocp[2] = x7 = makeref(&allocp[2]);
  x8 = arg(x0, 1);
  allocp[3] = x8;
  allocp[4] = x5;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[7] = x8;
  allocp[8] = x9 = makeref(&allocp[8]);
  allocp[9] = x7;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(x0,init__deps_2_2);
  *reasonp++ =  x0;
  goto init__deps_2_interrupt;
  };
  goto init__deps_2_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto init__deps_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,init__deps_2_1);
  *reasonp++ =  a0;
  goto init__deps_2_interrupt;
  };
  goto init__deps_2_interrupt;
 init__deps_2_ext_interrupt:
  reasonp = 0l;
 init__deps_2_interrupt:
  goto interrupt_2;
 }

 init__clauses_3_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  qp = qp->next;
 init__clauses_3_clear_reason:
  reasonp = reasons;
 init__clauses_3_0:
 init__clauses_3_1:
  if (!isint(a0)) goto init__clauses_3_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,init__clauses_3_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xinit__clauses_3);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[7] = a0;
  allocp[8] = makeint(1L);
  allocp[9] = x1;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[12] = a0;
  allocp[13] = a1;
  allocp[14] = x3 = makeref(&allocp[14]);
  allocp[15] = x2;
  allocp[16] = (q)(struct goalrec*)&allocp[10];
  allocp[17] = (q)(&predicate_dependency_xinit__clause_2);
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = x3;
  allocp[20] = (q)(struct goalrec*)&allocp[16];
  allocp[21] = (q)(&predicate_functor__table_xarg_3);
  allocp[22] = a0;
  allocp[23] = a1;
  allocp[24] = x4;
  qp = (struct goalrec*)&allocp[20];
  allocp += 25;
  proceed();
 init__clauses_3_2:
  if (a0 != makeint(0L)) goto init__clauses_3_interrupt;
  unify(a2, a1);
  proceed();
 init__clauses_3_3:
  if (!isref(a0)) goto init__clauses_3_interrupt;
  deref_and_jump(a0,init__clauses_3_1);
  *reasonp++ =  a0;
  goto init__clauses_3_interrupt;
 init__clauses_3_ext_interrupt:
  reasonp = 0l;
 init__clauses_3_interrupt:
  goto interrupt_3;
 }

 init__clause_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  qp = qp->next;
 init__clause_2_clear_reason:
  reasonp = reasons;
 init__clause_2_0:
 init__clause_2_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_clause_4)) goto init__clause_2_2;
  allocp[0] = makesym(functor_deps_2);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  x0 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor_xnew__functor__init_4);
  allocp[2] = makesym(atom_body);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = makefunctor(funct_const_0);
  allocp[5] = x2;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor_xnew__functor__init_4);
  allocp[8] = makesym(atom_guard);
  allocp[9] = x4 = makeref(&allocp[9]);
  allocp[10] = makefunctor(funct_const_0);
  allocp[11] = x1;
  allocp[12] = (q)(struct goalrec*)&allocp[6];
  allocp[13] = (q)(&predicate_functor__table_xfunctor_3);
  x5 = arg(a0, 2);
  allocp[14] = x5;
  allocp[15] = x6 = makeref(&allocp[15]);
  allocp[16] = x3;
  allocp[17] = (q)(struct goalrec*)&allocp[12];
  allocp[18] = (q)(&predicate_functor__table_xfunctor_3);
  x7 = arg(a0, 1);
  allocp[19] = x7;
  allocp[20] = x8 = makeref(&allocp[20]);
  allocp[21] = x4;
  qp = (struct goalrec*)&allocp[17];
  allocp += 22;
  proceed();
 case VARREF:
  deref_and_jump(a0,init__clause_2_1);
  *reasonp++ =  a0;
  goto init__clause_2_2;
  };
  goto init__clause_2_2;
 init__clause_2_2:
  otherwise(init__clause_2_interrupt);
  x0 = makesym(atom_body);
  unify_value(a1, x0);
  proceed();
 init__clause_2_ext_interrupt:
  reasonp = 0l;
 init__clause_2_interrupt:
  goto interrupt_2;
 }

 make__control__dep_3_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  qp = qp->next;
 make__control__dep_3_clear_reason:
  reasonp = reasons;
 make__control__dep_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xmake__control__modules_8);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = makesym(atom_none);
  allocp[6] = a0;
  allocp[7] = a0;
  allocp[8] = a1;
  allocp[9] = a2;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_parse__uty_xget__first__clause__info_4);
  allocp[12] = x0;
  allocp[13] = x1;
  allocp[14] = x2;
  allocp[15] = a0;
  qp = (struct goalrec*)&allocp[10];
  allocp += 16;
  proceed();
 make__control__dep_3_ext_interrupt:
  reasonp = 0l;
 make__control__dep_3_interrupt:
  goto interrupt_3;
 }

 make__control__modules_8_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 make__control__modules_8_clear_reason:
  reasonp = reasons;
 make__control__modules_8_0:
 make__control__modules_8_1:
  switch (ptagof(a4)) {
 case CONS:
  x0 = car_of(a4);
 make__control__modules_8_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto make__control__modules_8_7;
  x1 = arg(x0, 0);
 make__control__modules_8_3:
  if (isref(x1)) goto make__control__modules_8_6;
 make__control__modules_8_4:
  if (isref(x1)) goto make__control__modules_8_5;
  if_not_equal(x1, a0, make__control__modules_8_7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xmake__control__clauses_9);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  x2 = arg(x0, 1);
  allocp[6] = x2;
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[13] = x2;
  allocp[14] = x4 = makeref(&allocp[14]);
  allocp[15] = x3;
  qp = (struct goalrec*)&allocp[11];
  allocp += 16;
  proceed();
 make__control__modules_8_5:
  deref_and_jump(x1,make__control__modules_8_4);
  *reasonp++ =  x1;
  goto make__control__modules_8_7;
 make__control__modules_8_6:
  deref_and_jump(x1,make__control__modules_8_3);
  *reasonp++ =  x1;
  goto make__control__modules_8_7;
 case VARREF:
  deref_and_jump(x0,make__control__modules_8_2);
  *reasonp++ =  x0;
  goto make__control__modules_8_7;
  };
  goto make__control__modules_8_7;
 case VARREF:
  deref_and_jump(a4,make__control__modules_8_1);
  *reasonp++ =  a4;
  goto make__control__modules_8_7;
  };
  goto make__control__modules_8_7;
 make__control__modules_8_7:
  otherwise(make__control__modules_8_interrupt);
 make__control__modules_8_8:
  switch (ptagof(a4)) {
 case CONS:
  a4 = cdr_of(a4);
  execute(make__control__modules_8_0);
  goto make__control__modules_8_ext_interrupt;
 case ATOMIC:
  if (a4 != NILATOM) goto make__control__modules_8_interrupt;
  unify(a7, a6);
  proceed();
 case VARREF:
  deref_and_jump(a4,make__control__modules_8_8);
  *reasonp++ =  a4;
  goto make__control__modules_8_interrupt;
  };
  goto make__control__modules_8_interrupt;
 make__control__modules_8_ext_interrupt:
  reasonp = 0l;
 make__control__modules_8_interrupt:
  toppred = &predicate_dependency_xmake__control__modules_8;
  goto interrupt_8;
 }

 make__control__clauses_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 make__control__clauses_9_clear_reason:
  reasonp = reasons;
 make__control__clauses_9_0:
 make__control__clauses_9_1:
  if (!isint(a5)) goto make__control__clauses_9_16;
  x0 = makeint(0L);
  gblt_greater(a5,x0,make__control__clauses_9_17);
 make__control__clauses_9_2:
  if (isref(a4)) goto make__control__clauses_9_15;
  gblt_arg(a5,a4,x1,make__control__clauses_9_17);
 make__control__clauses_9_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_clause_4)) goto make__control__clauses_9_17;
  x2 = arg(x1, 0);
 make__control__clauses_9_4:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_functor_2)) goto make__control__clauses_9_17;
  x3 = arg(x2, 0);
 make__control__clauses_9_5:
  if (isref(x3)) goto make__control__clauses_9_14;
  gblt_pfunctor(x3,x4,make__control__clauses_9_17);
 make__control__clauses_9_6:
  if (isref(x4)) goto make__control__clauses_9_13;
 make__control__clauses_9_7:
  if (isref(x4)) goto make__control__clauses_9_12;
  if_not_equal(x4, a1, make__control__clauses_9_17);
  gblt_arity(x3,x5,make__control__clauses_9_17);
 make__control__clauses_9_8:
  if (isref(x5)) goto make__control__clauses_9_11;
 make__control__clauses_9_9:
  if (isref(x5)) goto make__control__clauses_9_10;
  if_not_equal(x5, a2, make__control__clauses_9_17);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xmake__control__clauses_9);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x6 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = x7 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[13] = a5;
  allocp[14] = makeint(1L);
  allocp[15] = x6;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_dependency_xmake__control__bodys_9);
  allocp[18] = x8 = makeref(&allocp[18]);
  x9 = arg(x1, 2);
  allocp[19] = x9;
  allocp[20] = a0;
  allocp[21] = a5;
  allocp[22] = a3;
  allocp[23] = x10 = makeref(&allocp[23]);
  allocp[24] = a6;
  allocp[25] = x11 = makeref(&allocp[25]);
  allocp[26] = x7;
  allocp[27] = (q)(struct goalrec*)&allocp[16];
  allocp[28] = (q)(&predicate_dependency_xmake__control__guards_6);
  allocp[29] = x12 = makeref(&allocp[29]);
  allocp[30] = a3;
  allocp[31] = a0;
  allocp[32] = a5;
  allocp[33] = a7;
  allocp[34] = x11;
  allocp[35] = (q)(struct goalrec*)&allocp[27];
  allocp[36] = (q)(&predicate_dependency_xmake__depend__guards_4);
  allocp[37] = x12;
  allocp[38] = a0;
  allocp[39] = a5;
  allocp[40] = x10;
  allocp[41] = (q)(struct goalrec*)&allocp[35];
  allocp[42] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[43] = x9;
  allocp[44] = x13 = makeref(&allocp[44]);
  allocp[45] = x8;
  allocp[46] = (q)(struct goalrec*)&allocp[41];
  allocp[47] = (q)(&predicate_functor__table_xfunctor_3);
  x14 = arg(x1, 1);
  allocp[48] = x14;
  allocp[49] = x15 = makeref(&allocp[49]);
  allocp[50] = x12;
  qp = (struct goalrec*)&allocp[46];
  allocp += 51;
  proceed();
 make__control__clauses_9_10:
  deref_and_jump(x5,make__control__clauses_9_9);
  *reasonp++ =  x5;
  goto make__control__clauses_9_17;
 make__control__clauses_9_11:
  deref_and_jump(x5,make__control__clauses_9_8);
  *reasonp++ =  x5;
  goto make__control__clauses_9_17;
 make__control__clauses_9_12:
  deref_and_jump(x4,make__control__clauses_9_7);
  *reasonp++ =  x4;
  goto make__control__clauses_9_17;
 make__control__clauses_9_13:
  deref_and_jump(x4,make__control__clauses_9_6);
  *reasonp++ =  x4;
  goto make__control__clauses_9_17;
 make__control__clauses_9_14:
  deref_and_jump(x3,make__control__clauses_9_5);
  *reasonp++ =  x3;
  goto make__control__clauses_9_17;
 case VARREF:
  deref_and_jump(x2,make__control__clauses_9_4);
  *reasonp++ =  x2;
  goto make__control__clauses_9_17;
  };
  goto make__control__clauses_9_17;
 case VARREF:
  deref_and_jump(x1,make__control__clauses_9_3);
  *reasonp++ =  x1;
  goto make__control__clauses_9_17;
  };
  goto make__control__clauses_9_17;
 make__control__clauses_9_15:
  deref_and_jump(a4,make__control__clauses_9_2);
  *reasonp++ =  a4;
  goto make__control__clauses_9_17;
 make__control__clauses_9_16:
  if (!isref(a5)) goto make__control__clauses_9_17;
  deref_and_jump(a5,make__control__clauses_9_1);
  *reasonp++ =  a5;
  goto make__control__clauses_9_17;
 make__control__clauses_9_17:
  otherwise(make__control__clauses_9_interrupt);
 make__control__clauses_9_18:
  if (!isint(a5)) goto make__control__clauses_9_20;
  x0 = makeint(0L);
  gblt_greater(a5,x0,make__control__clauses_9_19);
  x1 = makeint(1L);
  bblt_sub_no_check(a5,x1,x2);
  a5 = x2;
  execute(make__control__clauses_9_0);
  goto make__control__clauses_9_ext_interrupt;
 make__control__clauses_9_19:
  if (a5 != makeint(0L)) goto make__control__clauses_9_interrupt;
  unify(a8, a7);
  proceed();
 make__control__clauses_9_20:
  if (!isref(a5)) goto make__control__clauses_9_interrupt;
  deref_and_jump(a5,make__control__clauses_9_18);
  *reasonp++ =  a5;
  goto make__control__clauses_9_interrupt;
 make__control__clauses_9_ext_interrupt:
  reasonp = 0l;
 make__control__clauses_9_interrupt:
  goto interrupt_9;
 }

 make__depend__guards_4_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 make__depend__guards_4_clear_reason:
  reasonp = reasons;
 make__depend__guards_4_0:
 make__depend__guards_4_1:
  if (!isint(a0)) goto make__depend__guards_4_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,make__depend__guards_4_2);
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a1;
  allocp[2] = a2;
  allocp[3] = makesym(atom_guard);
  allocp[4] = a0;
  x1 = makefunctor(&allocp[0]);
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = x1;
  x2 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a3, x2);
  x4 = makeint(1L);
  bblt_sub_no_check(a0,x4,x5);
  a0 = x5;
  a3 = x3;
  execute(make__depend__guards_4_0);
  goto make__depend__guards_4_ext_interrupt;
 make__depend__guards_4_2:
  if (a0 != makeint(0L)) goto make__depend__guards_4_interrupt;
  x6 = NILATOM;
  unify_value(a3, x6);
  proceed();
 make__depend__guards_4_3:
  if (!isref(a0)) goto make__depend__guards_4_interrupt;
  deref_and_jump(a0,make__depend__guards_4_1);
  *reasonp++ =  a0;
  goto make__depend__guards_4_interrupt;
 make__depend__guards_4_ext_interrupt:
  reasonp = 0l;
 make__depend__guards_4_interrupt:
  goto interrupt_4;
 }

 make__control__guards_6_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 make__control__guards_6_clear_reason:
  reasonp = reasons;
 make__control__guards_6_0:
 make__control__guards_6_1:
  if (!isint(a0)) goto make__control__guards_6_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,make__control__guards_6_4);
 make__control__guards_6_2:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_none)) goto make__control__guards_6_4;
  unify(a5, a4);
  proceed();
 case VARREF:
  deref_and_jump(a1,make__control__guards_6_2);
  *reasonp++ =  a1;
  goto make__control__guards_6_4;
  };
  goto make__control__guards_6_4;
 make__control__guards_6_3:
  if (!isref(a0)) goto make__control__guards_6_4;
  deref_and_jump(a0,make__control__guards_6_1);
  *reasonp++ =  a0;
  goto make__control__guards_6_4;
 make__control__guards_6_4:
  otherwise(make__control__guards_6_interrupt);
 make__control__guards_6_5:
  if (!isint(a0)) goto make__control__guards_6_7;
  x0 = makeint(0L);
  gblt_greater(a0,x0,make__control__guards_6_6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xmake__control__guards_6);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[10] = a0;
  allocp[11] = makeint(1L);
  allocp[12] = x1;
  allocp[13] = makesym(functor_goal_4);
  allocp[14] = a2;
  allocp[15] = a3;
  allocp[16] = makesym(atom_guard);
  allocp[17] = a0;
  x3 = makefunctor(&allocp[13]);
  allocp[18] = NILATOM;
  allocp[19] = a1;
  x4 = makecons(&allocp[18]);
  allocp[20] = (q)(struct goalrec*)&allocp[8];
  allocp[21] = (q)(&predicate_dt_xentry_5);
  allocp[22] = makesym(atom_control);
  allocp[23] = x3;
  allocp[24] = x4;
  allocp[25] = a4;
  allocp[26] = x2;
  qp = (struct goalrec*)&allocp[20];
  allocp += 27;
  proceed();
 make__control__guards_6_6:
  if (a0 != makeint(0L)) goto make__control__guards_6_interrupt;
  unify(a5, a4);
  proceed();
 make__control__guards_6_7:
  if (!isref(a0)) goto make__control__guards_6_interrupt;
  deref_and_jump(a0,make__control__guards_6_5);
  *reasonp++ =  a0;
  goto make__control__guards_6_interrupt;
 make__control__guards_6_ext_interrupt:
  reasonp = 0l;
 make__control__guards_6_interrupt:
  goto interrupt_6;
 }

 make__control__bodys_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 make__control__bodys_9_clear_reason:
  reasonp = reasons;
 make__control__bodys_9_0:
 make__control__bodys_9_1:
  if (!isint(a0)) goto make__control__bodys_9_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,make__control__bodys_9_4);
 make__control__bodys_9_2:
  switch (ptagof(a4)) {
 case ATOMIC:
  if (a4 != makesym(atom_none)) goto make__control__bodys_9_4;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xmake__control__bodys_9);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x1;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_dependency_xcall__modules_9);
  allocp[18] = x3 = makeref(&allocp[18]);
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = x5 = makeref(&allocp[20]);
  allocp[21] = x6 = makeref(&allocp[21]);
  allocp[22] = x7 = makeref(&allocp[22]);
  allocp[23] = x8 = makeref(&allocp[23]);
  allocp[24] = a6;
  allocp[25] = x9 = makeref(&allocp[25]);
  allocp[26] = x2;
  allocp[27] = (q)(struct goalrec*)&allocp[16];
  allocp[28] = (q)(&predicate_dt_xentry_5);
  allocp[29] = makesym(atom_control);
  allocp[30] = x6;
  allocp[31] = a5;
  allocp[32] = a7;
  allocp[33] = x9;
  allocp[34] = makesym(functor_goal_4);
  allocp[35] = a2;
  allocp[36] = a3;
  allocp[37] = makesym(atom_body);
  allocp[38] = a0;
  x10 = makefunctor(&allocp[34]);
  qp = (struct goalrec*)&allocp[27];
  allocp += 39;
  unify_value(x6, x10);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[2] = x11 = makeref(&allocp[2]);
  allocp[3] = x4;
  allocp[4] = x5;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_parse__uty_xdecode__goalcall_6);
  allocp[7] = a2;
  allocp[8] = x3;
  allocp[9] = x12 = makeref(&allocp[9]);
  allocp[10] = x11;
  allocp[11] = x7;
  allocp[12] = x8;
  allocp[13] = (q)(struct goalrec*)&allocp[5];
  allocp[14] = (q)(&predicate_functor__table_xarg_3);
  allocp[15] = a0;
  allocp[16] = a1;
  allocp[17] = x12;
  qp = (struct goalrec*)&allocp[13];
  allocp += 18;
  proceed();
 case VARREF:
  deref_and_jump(a4,make__control__bodys_9_2);
  *reasonp++ =  a4;
  goto make__control__bodys_9_4;
  };
  goto make__control__bodys_9_4;
 make__control__bodys_9_3:
  if (!isref(a0)) goto make__control__bodys_9_4;
  deref_and_jump(a0,make__control__bodys_9_1);
  *reasonp++ =  a0;
  goto make__control__bodys_9_4;
 make__control__bodys_9_4:
  otherwise(make__control__bodys_9_interrupt);
 make__control__bodys_9_5:
  if (!isint(a0)) goto make__control__bodys_9_7;
  x0 = makeint(0L);
  gblt_greater(a0,x0,make__control__bodys_9_6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xmake__control__bodys_9);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x1;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_dependency_xcall__modules_9);
  allocp[18] = x3 = makeref(&allocp[18]);
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = x5 = makeref(&allocp[20]);
  allocp[21] = x6 = makeref(&allocp[21]);
  allocp[22] = x7 = makeref(&allocp[22]);
  allocp[23] = x8 = makeref(&allocp[23]);
  allocp[24] = a6;
  allocp[25] = x9 = makeref(&allocp[25]);
  allocp[26] = x2;
  allocp[27] = (q)(struct goalrec*)&allocp[16];
  allocp[28] = (q)(&predicate_dt_xentry_5);
  allocp[29] = makesym(atom_control);
  allocp[30] = x6;
  allocp[31] = x10 = makeref(&allocp[31]);
  allocp[32] = a7;
  allocp[33] = x9;
  allocp[34] = a5;
  allocp[35] = a4;
  x11 = makecons(&allocp[34]);
  qp = (struct goalrec*)&allocp[27];
  allocp += 36;
  unify_value(x10, x11);
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a2;
  allocp[2] = a3;
  allocp[3] = makesym(atom_body);
  allocp[4] = a0;
  x12 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(x6, x12);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[2] = x13 = makeref(&allocp[2]);
  allocp[3] = x4;
  allocp[4] = x5;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_parse__uty_xdecode__goalcall_6);
  allocp[7] = a2;
  allocp[8] = x3;
  allocp[9] = x14 = makeref(&allocp[9]);
  allocp[10] = x13;
  allocp[11] = x7;
  allocp[12] = x8;
  allocp[13] = (q)(struct goalrec*)&allocp[5];
  allocp[14] = (q)(&predicate_functor__table_xarg_3);
  allocp[15] = a0;
  allocp[16] = a1;
  allocp[17] = x14;
  qp = (struct goalrec*)&allocp[13];
  allocp += 18;
  proceed();
 make__control__bodys_9_6:
  if (a0 != makeint(0L)) goto make__control__bodys_9_interrupt;
  unify(a8, a7);
  proceed();
 make__control__bodys_9_7:
  if (!isref(a0)) goto make__control__bodys_9_interrupt;
  deref_and_jump(a0,make__control__bodys_9_5);
  *reasonp++ =  a0;
  goto make__control__bodys_9_interrupt;
 make__control__bodys_9_ext_interrupt:
  reasonp = 0l;
 make__control__bodys_9_interrupt:
  goto interrupt_9;
 }

 call__modules_9_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 call__modules_9_clear_reason:
  reasonp = reasons;
 call__modules_9_0:
 call__modules_9_1:
  switch (ptagof(a4)) {
 case FUNCTOR:
  if (functor_of(a4) != makesym(functor_atom_1)) goto call__modules_9_3;
  x0 = arg(a4, 0);
 call__modules_9_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (isint(x0)) goto call__modules_9_3;
  switch (symval(x0)) {
 case symval(makesym(atom_recursive)):
  unify(a8, a7);
  proceed();
 case symval(makesym(atom_shared)):
  a3 = makesym(atom_none);
  a4 = a6;
  a5 = a6;
  a6 = a7;
  a7 = a8;
  execute(make__control__modules_8_0);
  goto make__control__modules_8_ext_interrupt;
  };
  goto call__modules_9_3;
 case VARREF:
  deref_and_jump(x0,call__modules_9_2);
  *reasonp++ =  x0;
  goto call__modules_9_3;
  };
  goto call__modules_9_3;
 case VARREF:
  deref_and_jump(a4,call__modules_9_1);
  *reasonp++ =  a4;
  goto call__modules_9_3;
  };
  goto call__modules_9_3;
 call__modules_9_3:
 call__modules_9_4:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (a5 != makesym(atom_builtin)) goto call__modules_9_5;
  unify(a8, a7);
  proceed();
 case VARREF:
  deref_and_jump(a5,call__modules_9_4);
  *reasonp++ =  a5;
  goto call__modules_9_5;
  };
  goto call__modules_9_5;
 call__modules_9_5:
  otherwise(call__modules_9_interrupt);
  a4 = a6;
  a5 = a6;
  a6 = a7;
  a7 = a8;
  execute(make__control__modules_8_0);
  goto make__control__modules_8_ext_interrupt;
 call__modules_9_ext_interrupt:
  reasonp = 0l;
 call__modules_9_interrupt:
  goto interrupt_9;
 }

 make__data__dep_4_top: {
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 make__data__dep_4_clear_reason:
  reasonp = reasons;
 make__data__dep_4_0:
  execute(make__data__dep2_4_0);
  goto make__data__dep2_4_ext_interrupt;
 make__data__dep_4_ext_interrupt:
  reasonp = 0l;
 make__data__dep_4_interrupt:
  goto interrupt_4;
 }

 make__data__dep2_4_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 make__data__dep2_4_clear_reason:
  reasonp = reasons;
 make__data__dep2_4_0:
 make__data__dep2_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 make__data__dep2_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto make__data__dep2_4_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xmake__data__dep2_4);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_dependency_xmake__clauses__data_6);
  allocp[8] = x3 = makeref(&allocp[8]);
  x4 = arg(x0, 1);
  allocp[9] = x4;
  x5 = arg(x0, 0);
  allocp[10] = x5;
  allocp[11] = a1;
  allocp[12] = a2;
  allocp[13] = x2;
  allocp[14] = (q)(struct goalrec*)&allocp[6];
  allocp[15] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[16] = x4;
  allocp[17] = x6 = makeref(&allocp[17]);
  allocp[18] = x3;
  qp = (struct goalrec*)&allocp[14];
  allocp += 19;
  proceed();
 case VARREF:
  deref_and_jump(x0,make__data__dep2_4_2);
  *reasonp++ =  x0;
  goto make__data__dep2_4_interrupt;
  };
  goto make__data__dep2_4_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto make__data__dep2_4_interrupt;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,make__data__dep2_4_1);
  *reasonp++ =  a0;
  goto make__data__dep2_4_interrupt;
  };
  goto make__data__dep2_4_interrupt;
 make__data__dep2_4_ext_interrupt:
  reasonp = 0l;
 make__data__dep2_4_interrupt:
  toppred = &predicate_dependency_xmake__data__dep2_4;
  goto interrupt_4;
 }

 make__clauses__data_6_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 make__clauses__data_6_clear_reason:
  reasonp = reasons;
 make__clauses__data_6_0:
 make__clauses__data_6_1:
  if (!isint(a0)) goto make__clauses__data_6_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,make__clauses__data_6_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xmake__clauses__data_6);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[10] = a0;
  allocp[11] = makeint(1L);
  allocp[12] = x1;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_dependency_xmake__clause__data_6);
  allocp[15] = x3 = makeref(&allocp[15]);
  allocp[16] = a2;
  allocp[17] = a0;
  allocp[18] = a3;
  allocp[19] = a4;
  allocp[20] = x2;
  allocp[21] = (q)(struct goalrec*)&allocp[13];
  allocp[22] = (q)(&predicate_functor__table_xarg_3);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = x3;
  qp = (struct goalrec*)&allocp[21];
  allocp += 26;
  proceed();
 make__clauses__data_6_2:
  if (a0 != makeint(0L)) goto make__clauses__data_6_interrupt;
  unify(a5, a4);
  proceed();
 make__clauses__data_6_3:
  if (!isref(a0)) goto make__clauses__data_6_interrupt;
  deref_and_jump(a0,make__clauses__data_6_1);
  *reasonp++ =  a0;
  goto make__clauses__data_6_interrupt;
 make__clauses__data_6_ext_interrupt:
  reasonp = 0l;
 make__clauses__data_6_interrupt:
  goto interrupt_6;
 }

 make__clause__data_6_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 make__clause__data_6_clear_reason:
  reasonp = reasons;
 make__clause__data_6_0:
 make__clause__data_6_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_clause_4)) goto make__clause__data_6_2;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xmake__goals__data_8);
  x0 = arg(a0, 2);
  allocp[2] = x0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = makesym(atom_body);
  allocp[6] = makesym(atom___);
  allocp[7] = a3;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a5;
  x2 = arg(a0, 1);
  x3 = arg(a0, 0);
  a5 = a3;
  a6 = a4;
  a7 = x1;
  a4 = x3;
  a3 = makesym(atom_guard);
  a0 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  execute(make__goals__data_8_0);
  goto make__goals__data_8_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,make__clause__data_6_1);
  *reasonp++ =  a0;
  goto make__clause__data_6_2;
  };
  goto make__clause__data_6_2;
 make__clause__data_6_2:
  otherwise(make__clause__data_6_interrupt);
  unify(a5, a4);
  proceed();
 make__clause__data_6_ext_interrupt:
  reasonp = 0l;
 make__clause__data_6_interrupt:
  goto interrupt_6;
 }

 make__goals__data_8_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 make__goals__data_8_clear_reason:
  reasonp = reasons;
 make__goals__data_8_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xmake__goals__data1_9);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[13] = a0;
  allocp[14] = x1 = makeref(&allocp[14]);
  allocp[15] = x0;
  qp = (struct goalrec*)&allocp[11];
  allocp += 16;
  proceed();
 make__goals__data_8_ext_interrupt:
  reasonp = 0l;
 make__goals__data_8_interrupt:
  toppred = &predicate_dependency_xmake__goals__data_8;
  goto interrupt_8;
 }

 make__goals__data1_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 make__goals__data1_9_clear_reason:
  reasonp = reasons;
 make__goals__data1_9_0:
 make__goals__data1_9_1:
  if (!isint(a0)) goto make__goals__data1_9_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,make__goals__data1_9_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xmake__goals__data1_9);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x1;
  allocp[16] = makesym(functor_goal_4);
  allocp[17] = a2;
  allocp[18] = a3;
  allocp[19] = a4;
  allocp[20] = a0;
  x3 = makefunctor(&allocp[16]);
  allocp[21] = (q)(struct goalrec*)&allocp[11];
  allocp[22] = (q)(&predicate_dependency_xmake__goal__dependency_10);
  allocp[23] = x4 = makeref(&allocp[23]);
  allocp[24] = x5 = makeref(&allocp[24]);
  allocp[25] = x6 = makeref(&allocp[25]);
  allocp[26] = x7 = makeref(&allocp[26]);
  allocp[27] = a6;
  allocp[28] = x3;
  allocp[29] = a5;
  allocp[30] = x8 = makeref(&allocp[30]);
  allocp[31] = a7;
  allocp[32] = x2;
  allocp[33] = (q)(struct goalrec*)&allocp[21];
  allocp[34] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[35] = x8;
  allocp[36] = x6;
  allocp[37] = x7;
  allocp[38] = (q)(struct goalrec*)&allocp[33];
  allocp[39] = (q)(&predicate_parse__uty_xdecode__goalcall_6);
  allocp[40] = a2;
  allocp[41] = x5;
  allocp[42] = x9 = makeref(&allocp[42]);
  allocp[43] = x8;
  allocp[44] = x10 = makeref(&allocp[44]);
  allocp[45] = x4;
  allocp[46] = (q)(struct goalrec*)&allocp[38];
  allocp[47] = (q)(&predicate_functor__table_xarg_3);
  allocp[48] = a0;
  allocp[49] = a1;
  allocp[50] = x9;
  qp = (struct goalrec*)&allocp[46];
  allocp += 51;
  proceed();
 make__goals__data1_9_2:
  if (a0 != makeint(0L)) goto make__goals__data1_9_interrupt;
  unify(a8, a7);
  proceed();
 make__goals__data1_9_3:
  if (!isref(a0)) goto make__goals__data1_9_interrupt;
  deref_and_jump(a0,make__goals__data1_9_1);
  *reasonp++ =  a0;
  goto make__goals__data1_9_interrupt;
 make__goals__data1_9_ext_interrupt:
  reasonp = 0l;
 make__goals__data1_9_interrupt:
  goto interrupt_9;
 }

 make__goal__dependency_10_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 make__goal__dependency_10_clear_reason:
  reasonp = reasons;
 make__goal__dependency_10_0:
 make__goal__dependency_10_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto make__goal__dependency_10_5;
  switch (symval(a0)) {
 case symval(makesym(atom_userdef)):
  unify(a9, a8);
  proceed();
 case symval(makesym(atom_builtin)):
 make__goal__dependency_10_2:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom__3D)) goto make__goal__dependency_10_5;
 make__goal__dependency_10_3:
  switch (ptagof(a3)) {
 case ATOMIC:
 make__goal__dependency_10_4:
  if (a3 != makeint(2L)) goto make__goal__dependency_10_5;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  x0 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a5, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin__deps_xmake_11);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = x2;
  allocp[5] = x3;
  allocp[6] = x4;
  allocp[7] = makesym(atom__3D);
  allocp[8] = makeint(2L);
  allocp[9] = a4;
  allocp[10] = x5 = makeref(&allocp[10]);
  allocp[11] = a8;
  allocp[12] = a9;
  a0 = a6;
  a1 = a7;
  a2 = x5;
  a3 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 13;
  execute(check__headargs_4_0);
  goto check__headargs_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a3,make__goal__dependency_10_3);
  *reasonp++ =  a3;
  goto make__goal__dependency_10_5;
  };
  goto make__goal__dependency_10_5;
 case VARREF:
  deref_and_jump(a2,make__goal__dependency_10_2);
  *reasonp++ =  a2;
  goto make__goal__dependency_10_5;
  };
  goto make__goal__dependency_10_5;
  };
  goto make__goal__dependency_10_5;
 case VARREF:
  deref_and_jump(a0,make__goal__dependency_10_1);
  *reasonp++ =  a0;
  goto make__goal__dependency_10_5;
  };
  goto make__goal__dependency_10_5;
 make__goal__dependency_10_5:
  otherwise(make__goal__dependency_10_interrupt);
 make__goal__dependency_10_6:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_builtin)) goto make__goal__dependency_10_interrupt;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  x0 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a5, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin__deps_xmake_11);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = x2;
  allocp[5] = x3;
  allocp[6] = x4;
  allocp[7] = a2;
  allocp[8] = a3;
  allocp[9] = a4;
  allocp[10] = a7;
  allocp[11] = a8;
  allocp[12] = a9;
  qp = (struct goalrec*)&allocp[0];
  allocp += 13;
  proceed();
 case VARREF:
  deref_and_jump(a0,make__goal__dependency_10_6);
  *reasonp++ =  a0;
  goto make__goal__dependency_10_interrupt;
  };
  goto make__goal__dependency_10_interrupt;
 make__goal__dependency_10_ext_interrupt:
  reasonp = 0l;
 make__goal__dependency_10_interrupt:
  goto interrupt_10;
 }

 check__headargs_4_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 check__headargs_4_clear_reason:
  reasonp = reasons;
 check__headargs_4_0:
 check__headargs_4_1:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (isint(a3)) goto check__headargs_4_interrupt;
  switch (symval(a3)) {
 case symval(makesym(atom_body)):
  unify(a2, a1);
  proceed();
 case symval(makesym(atom_guard)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xcheck__headargs2_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[8] = x1;
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = x0;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_parse__uty_xdecode__goal_4);
  allocp[13] = a0;
  allocp[14] = x1;
  allocp[15] = x3 = makeref(&allocp[15]);
  allocp[16] = x4 = makeref(&allocp[16]);
  qp = (struct goalrec*)&allocp[11];
  allocp += 17;
  proceed();
  };
  goto check__headargs_4_interrupt;
 case VARREF:
  deref_and_jump(a3,check__headargs_4_1);
  *reasonp++ =  a3;
  goto check__headargs_4_interrupt;
  };
  goto check__headargs_4_interrupt;
 check__headargs_4_ext_interrupt:
  reasonp = 0l;
 check__headargs_4_interrupt:
  toppred = &predicate_dependency_xcheck__headargs_4;
  goto interrupt_4;
 }

 check__headargs2_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 check__headargs2_4_clear_reason:
  reasonp = reasons;
 check__headargs2_4_0:
 check__headargs2_4_1:
  if (!isint(a0)) goto check__headargs2_4_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,check__headargs2_4_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xcheck__headargs2_4);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x1;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_dependency_xcheck__headargs3_4);
  allocp[13] = makeint(2L);
  allocp[14] = x3 = makeref(&allocp[14]);
  allocp[15] = a2;
  allocp[16] = x2;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_functor__table_xarg_3);
  allocp[19] = a0;
  allocp[20] = a1;
  allocp[21] = x3;
  qp = (struct goalrec*)&allocp[17];
  allocp += 22;
  proceed();
 check__headargs2_4_2:
  if (a0 != makeint(0L)) goto check__headargs2_4_interrupt;
  unify(a3, a2);
  proceed();
 check__headargs2_4_3:
  if (!isref(a0)) goto check__headargs2_4_interrupt;
  deref_and_jump(a0,check__headargs2_4_1);
  *reasonp++ =  a0;
  goto check__headargs2_4_interrupt;
 check__headargs2_4_ext_interrupt:
  reasonp = 0l;
 check__headargs2_4_interrupt:
  goto interrupt_4;
 }

 check__headargs3_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 check__headargs3_4_clear_reason:
  reasonp = reasons;
 check__headargs3_4_0:
 check__headargs3_4_1:
  if (!isint(a0)) goto check__headargs3_4_11;
  x0 = makeint(0L);
  gblt_greater(a0,x0,check__headargs3_4_12);
 check__headargs3_4_2:
  if (isref(a2)) goto check__headargs3_4_10;
  gblt_arg(a0,a2,x1,check__headargs3_4_12);
 check__headargs3_4_3:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_variable_3)) goto check__headargs3_4_12;
 check__headargs3_4_4:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_variable_3)) goto check__headargs3_4_12;
  x2 = arg(x1, 0);
 check__headargs3_4_5:
  if (isref(x2)) goto check__headargs3_4_9;
 check__headargs3_4_6:
  if (isref(x2)) goto check__headargs3_4_8;
  x3 = arg(a1, 0);
  if_not_equal(x2, x3, check__headargs3_4_12);
  x4 = arg(x1, 2);
 check__headargs3_4_7:
  switch (ptagof(x4)) {
 case ATOMIC:
  if (x4 != makesym(atom__3F)) goto check__headargs3_4_12;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xcheck__headargs3_4);
  allocp[2] = x5 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x6 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x5;
  allocp[11] = makesym(functor_variable_3);
  allocp[12] = x3;
  x8 = arg(x1, 1);
  allocp[13] = x8;
  allocp[14] = makesym(atom_i);
  x7 = makefunctor(&allocp[11]);
  allocp[15] = (q)(struct goalrec*)&allocp[6];
  allocp[16] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[17] = a0;
  allocp[18] = a2;
  allocp[19] = x7;
  allocp[20] = x6;
  qp = (struct goalrec*)&allocp[15];
  allocp += 21;
  proceed();
 case VARREF:
  deref_and_jump(x4,check__headargs3_4_7);
  *reasonp++ =  x4;
  goto check__headargs3_4_12;
  };
  goto check__headargs3_4_12;
 check__headargs3_4_8:
  deref_and_jump(x2,check__headargs3_4_6);
  *reasonp++ =  x2;
  goto check__headargs3_4_12;
 check__headargs3_4_9:
  deref_and_jump(x2,check__headargs3_4_5);
  *reasonp++ =  x2;
  goto check__headargs3_4_12;
 case VARREF:
  deref_and_jump(x1,check__headargs3_4_4);
  *reasonp++ =  x1;
  goto check__headargs3_4_12;
  };
  goto check__headargs3_4_12;
 case VARREF:
  deref_and_jump(a1,check__headargs3_4_3);
  *reasonp++ =  a1;
  goto check__headargs3_4_12;
  };
  goto check__headargs3_4_12;
 check__headargs3_4_10:
  deref_and_jump(a2,check__headargs3_4_2);
  *reasonp++ =  a2;
  goto check__headargs3_4_12;
 check__headargs3_4_11:
  if (!isref(a0)) goto check__headargs3_4_12;
  deref_and_jump(a0,check__headargs3_4_1);
  *reasonp++ =  a0;
  goto check__headargs3_4_12;
 check__headargs3_4_12:
  otherwise(check__headargs3_4_interrupt);
 check__headargs3_4_13:
  if (!isint(a0)) goto check__headargs3_4_15;
  x0 = makeint(0L);
  gblt_greater(a0,x0,check__headargs3_4_14);
  x1 = makeint(1L);
  bblt_sub_no_check(a0,x1,x2);
  a0 = x2;
  execute(check__headargs3_4_0);
  goto check__headargs3_4_ext_interrupt;
 check__headargs3_4_14:
  if (a0 != makeint(0L)) goto check__headargs3_4_interrupt;
  unify(a3, a2);
  proceed();
 check__headargs3_4_15:
  if (!isref(a0)) goto check__headargs3_4_interrupt;
  deref_and_jump(a0,check__headargs3_4_13);
  *reasonp++ =  a0;
  goto check__headargs3_4_interrupt;
 check__headargs3_4_ext_interrupt:
  reasonp = 0l;
 check__headargs3_4_interrupt:
  goto interrupt_4;
 }

 userdef_4_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 userdef_4_clear_reason:
  reasonp = reasons;
 userdef_4_0:
  x0 = a0;
  x1 = a0;
  x2 = a2;
  a4 = a3;
  a3 = x2;
  a2 = x1;
  a0 = x0;
  execute(userdef_5_0);
  goto userdef_5_ext_interrupt;
 userdef_4_ext_interrupt:
  reasonp = 0l;
 userdef_4_interrupt:
  goto interrupt_4;
 }

 userdef_5_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 userdef_5_clear_reason:
  reasonp = reasons;
 userdef_5_0:
 userdef_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 userdef_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto userdef_5_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xuserdef_5);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_dependency_xuserdef__clauses_7);
  allocp[9] = x3 = makeref(&allocp[9]);
  x4 = arg(x0, 1);
  allocp[10] = x4;
  x5 = arg(x0, 0);
  allocp[11] = x5;
  allocp[12] = a2;
  allocp[13] = a1;
  allocp[14] = a3;
  allocp[15] = x2;
  allocp[16] = (q)(struct goalrec*)&allocp[7];
  allocp[17] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[18] = x4;
  allocp[19] = x6 = makeref(&allocp[19]);
  allocp[20] = x3;
  qp = (struct goalrec*)&allocp[16];
  allocp += 21;
  proceed();
 case VARREF:
  deref_and_jump(x0,userdef_5_2);
  *reasonp++ =  x0;
  goto userdef_5_interrupt;
  };
  goto userdef_5_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto userdef_5_interrupt;
  unify(a4, a3);
  proceed();
 case VARREF:
  deref_and_jump(a0,userdef_5_1);
  *reasonp++ =  a0;
  goto userdef_5_interrupt;
  };
  goto userdef_5_interrupt;
 userdef_5_ext_interrupt:
  reasonp = 0l;
 userdef_5_interrupt:
  toppred = &predicate_dependency_xuserdef_5;
  goto interrupt_5;
 }

 userdef__clauses_7_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 userdef__clauses_7_clear_reason:
  reasonp = reasons;
 userdef__clauses_7_0:
 userdef__clauses_7_1:
  if (!isint(a0)) goto userdef__clauses_7_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,userdef__clauses_7_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xuserdef__clauses_7);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[11] = a0;
  allocp[12] = makeint(1L);
  allocp[13] = x1;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_dependency_xuserdef__clause_7);
  allocp[16] = x3 = makeref(&allocp[16]);
  allocp[17] = a2;
  allocp[18] = a0;
  allocp[19] = a3;
  allocp[20] = a4;
  allocp[21] = a5;
  allocp[22] = x2;
  allocp[23] = (q)(struct goalrec*)&allocp[14];
  allocp[24] = (q)(&predicate_functor__table_xarg_3);
  allocp[25] = a0;
  allocp[26] = a1;
  allocp[27] = x3;
  qp = (struct goalrec*)&allocp[23];
  allocp += 28;
  proceed();
 userdef__clauses_7_2:
  if (a0 != makeint(0L)) goto userdef__clauses_7_interrupt;
  unify(a6, a5);
  proceed();
 userdef__clauses_7_3:
  if (!isref(a0)) goto userdef__clauses_7_interrupt;
  deref_and_jump(a0,userdef__clauses_7_1);
  *reasonp++ =  a0;
  goto userdef__clauses_7_interrupt;
 userdef__clauses_7_ext_interrupt:
  reasonp = 0l;
 userdef__clauses_7_interrupt:
  goto interrupt_7;
 }

 userdef__clause_7_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 userdef__clause_7_clear_reason:
  reasonp = reasons;
 userdef__clause_7_0:
 userdef__clause_7_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_clause_4)) goto userdef__clause_7_2;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xuserdef__bodys_8);
  allocp[2] = x0 = makeref(&allocp[2]);
  x1 = arg(a0, 2);
  allocp[3] = x1;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[12] = x1;
  allocp[13] = x2 = makeref(&allocp[13]);
  allocp[14] = x0;
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(a0,userdef__clause_7_1);
  *reasonp++ =  a0;
  goto userdef__clause_7_2;
  };
  goto userdef__clause_7_2;
 userdef__clause_7_2:
  otherwise(userdef__clause_7_interrupt);
  unify(a6, a5);
  proceed();
 userdef__clause_7_ext_interrupt:
  reasonp = 0l;
 userdef__clause_7_interrupt:
  goto interrupt_7;
 }

 userdef__bodys_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 userdef__bodys_8_clear_reason:
  reasonp = reasons;
 userdef__bodys_8_0:
 userdef__bodys_8_1:
  if (!isint(a0)) goto userdef__bodys_8_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,userdef__bodys_8_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xuserdef__bodys_8);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[12] = a0;
  allocp[13] = makeint(1L);
  allocp[14] = x1;
  allocp[15] = makesym(functor_goal_4);
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = makesym(atom_body);
  allocp[19] = a0;
  x3 = makefunctor(&allocp[15]);
  allocp[20] = (q)(struct goalrec*)&allocp[10];
  allocp[21] = (q)(&predicate_dependency_xuserdef__body_7);
  allocp[22] = x4 = makeref(&allocp[22]);
  allocp[23] = x5 = makeref(&allocp[23]);
  allocp[24] = x6 = makeref(&allocp[24]);
  allocp[25] = a4;
  allocp[26] = x3;
  allocp[27] = a6;
  allocp[28] = x2;
  allocp[29] = (q)(struct goalrec*)&allocp[20];
  allocp[30] = (q)(&predicate_parse__uty_xdecode__goalcall_6);
  allocp[31] = a2;
  allocp[32] = x5;
  allocp[33] = x7 = makeref(&allocp[33]);
  allocp[34] = x6;
  allocp[35] = x8 = makeref(&allocp[35]);
  allocp[36] = x4;
  allocp[37] = (q)(struct goalrec*)&allocp[29];
  allocp[38] = (q)(&predicate_functor__table_xarg_3);
  allocp[39] = a0;
  allocp[40] = a1;
  allocp[41] = x7;
  qp = (struct goalrec*)&allocp[37];
  allocp += 42;
  proceed();
 userdef__bodys_8_2:
  if (a0 != makeint(0L)) goto userdef__bodys_8_interrupt;
  unify(a7, a6);
  proceed();
 userdef__bodys_8_3:
  if (!isref(a0)) goto userdef__bodys_8_interrupt;
  deref_and_jump(a0,userdef__bodys_8_1);
  *reasonp++ =  a0;
  goto userdef__bodys_8_interrupt;
 userdef__bodys_8_ext_interrupt:
  reasonp = 0l;
 userdef__bodys_8_interrupt:
  goto interrupt_8;
 }

 userdef__body_7_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 userdef__body_7_clear_reason:
  reasonp = reasons;
 userdef__body_7_0:
 userdef__body_7_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto userdef__body_7_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_builtin)):
  unify(a6, a5);
  proceed();
 case symval(makesym(atom_userdef)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dt_xentry__data__dep_4);
  allocp[2] = a4;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a5;
  allocp[5] = a6;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_dependency_xget__clauses__ds_5);
  allocp[8] = a1;
  allocp[9] = x1 = makeref(&allocp[9]);
  allocp[10] = NILATOM;
  allocp[11] = x0;
  allocp[12] = a5;
  allocp[13] = (q)(struct goalrec*)&allocp[6];
  allocp[14] = (q)(&predicate_parse__uty_xget__def__clauses_5);
  allocp[15] = a1;
  allocp[16] = x2 = makeref(&allocp[16]);
  allocp[17] = x3 = makeref(&allocp[17]);
  allocp[18] = x1;
  allocp[19] = a3;
  allocp[20] = (q)(struct goalrec*)&allocp[13];
  allocp[21] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[22] = a2;
  allocp[23] = x2;
  allocp[24] = x3;
  qp = (struct goalrec*)&allocp[20];
  allocp += 25;
  proceed();
  };
  goto userdef__body_7_interrupt;
 case VARREF:
  deref_and_jump(a0,userdef__body_7_1);
  *reasonp++ =  a0;
  goto userdef__body_7_interrupt;
  };
  goto userdef__body_7_interrupt;
 userdef__body_7_ext_interrupt:
  reasonp = 0l;
 userdef__body_7_interrupt:
  goto interrupt_7;
 }

 get__clauses__ds_5_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 get__clauses__ds_5_clear_reason:
  reasonp = reasons;
 get__clauses__ds_5_0:
 get__clauses__ds_5_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 get__clauses__ds_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_cl_2)) goto get__clauses__ds_5_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xget__clauses__ds_5);
  allocp[2] = a0;
  x1 = cdr_of(a1);
  allocp[3] = x1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_list_xor__unique_3);
  allocp[9] = a2;
  allocp[10] = x3 = makeref(&allocp[10]);
  allocp[11] = x2;
  allocp[12] = (q)(struct goalrec*)&allocp[7];
  allocp[13] = (q)(&predicate_dt_xget__guard__ds_4);
  allocp[14] = a0;
  x4 = arg(x0, 0);
  allocp[15] = x4;
  allocp[16] = x3;
  allocp[17] = a4;
  qp = (struct goalrec*)&allocp[12];
  allocp += 18;
  proceed();
 case VARREF:
  deref_and_jump(x0,get__clauses__ds_5_2);
  *reasonp++ =  x0;
  goto get__clauses__ds_5_interrupt;
  };
  goto get__clauses__ds_5_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto get__clauses__ds_5_interrupt;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a1,get__clauses__ds_5_1);
  *reasonp++ =  a1;
  goto get__clauses__ds_5_interrupt;
  };
  goto get__clauses__ds_5_interrupt;
 get__clauses__ds_5_ext_interrupt:
  reasonp = 0l;
 get__clauses__ds_5_interrupt:
  goto interrupt_5;
 }

 indirect_4_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 indirect_4_clear_reason:
  reasonp = reasons;
 indirect_4_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xindirect__clause_8);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = makeint(1L);
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a1;
  allocp[6] = a0;
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = a2;
  allocp[9] = a3;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_parse__uty_xget__clause_4);
  allocp[12] = x0;
  allocp[13] = makeint(1L);
  allocp[14] = x1;
  allocp[15] = a0;
  allocp[16] = (q)(struct goalrec*)&allocp[10];
  allocp[17] = (q)(&predicate_parse__uty_xget__first__clause__info_4);
  allocp[18] = x0;
  allocp[19] = x3 = makeref(&allocp[19]);
  allocp[20] = x4 = makeref(&allocp[20]);
  allocp[21] = a0;
  qp = (struct goalrec*)&allocp[16];
  allocp += 22;
  proceed();
 indirect_4_ext_interrupt:
  reasonp = 0l;
 indirect_4_interrupt:
  goto interrupt_4;
 }

 indirect__clause_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 indirect__clause_8_clear_reason:
  reasonp = reasons;
 indirect__clause_8_0:
 indirect__clause_8_1:
  switch (ptagof(a1)) {
 case ATOMIC:
 indirect__clause_8_2:
  if (a1 != makeint(0L)) goto indirect__clause_8_3;
  unify2(a7, a6, a5, a4);
  proceed();
 case VARREF:
  deref_and_jump(a1,indirect__clause_8_1);
  *reasonp++ =  a1;
  goto indirect__clause_8_3;
  };
  goto indirect__clause_8_3;
 indirect__clause_8_3:
  otherwise(indirect__clause_8_interrupt);
 indirect__clause_8_4:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_clause_4)) goto indirect__clause_8_5;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xindirect__clause_8);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_parse__uty_xget__next__clause_6);
  allocp[12] = a0;
  allocp[13] = a1;
  allocp[14] = x0;
  allocp[15] = x1;
  allocp[16] = x3;
  allocp[17] = x2;
  allocp[18] = (q)(struct goalrec*)&allocp[10];
  allocp[19] = (q)(&predicate_dependency_xindirect__goals_9);
  x5 = arg(a2, 2);
  allocp[20] = x5;
  allocp[21] = makesym(atom_body);
  allocp[22] = a0;
  allocp[23] = a1;
  allocp[24] = a3;
  allocp[25] = x6 = makeref(&allocp[25]);
  allocp[26] = x3;
  allocp[27] = x7 = makeref(&allocp[27]);
  allocp[28] = x4;
  x8 = arg(a2, 1);
  a2 = a0;
  x9 = a1;
  x10 = a3;
  a5 = a4;
  a7 = a6;
  a8 = x7;
  a6 = x6;
  a4 = x10;
  a3 = x9;
  a1 = makesym(atom_guard);
  a0 = x8;
  qp = (struct goalrec*)&allocp[18];
  allocp += 29;
  execute(indirect__goals_9_0);
  goto indirect__goals_9_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,indirect__clause_8_4);
  *reasonp++ =  a2;
  goto indirect__clause_8_5;
  };
  goto indirect__clause_8_5;
 indirect__clause_8_5:
  otherwise(indirect__clause_8_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xindirect__clause_8);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_parse__uty_xget__next__clause_6);
  allocp[12] = a0;
  allocp[13] = a1;
  allocp[14] = x0;
  allocp[15] = x1;
  allocp[16] = a4;
  allocp[17] = x2;
  qp = (struct goalrec*)&allocp[10];
  allocp += 18;
  proceed();
 indirect__clause_8_ext_interrupt:
  reasonp = 0l;
 indirect__clause_8_interrupt:
  goto interrupt_8;
 }

 indirect__goals_9_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 indirect__goals_9_clear_reason:
  reasonp = reasons;
 indirect__goals_9_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xindirect__goals1_9);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[13] = a0;
  allocp[14] = x1 = makeref(&allocp[14]);
  allocp[15] = x0;
  qp = (struct goalrec*)&allocp[11];
  allocp += 16;
  proceed();
 indirect__goals_9_ext_interrupt:
  reasonp = 0l;
 indirect__goals_9_interrupt:
  toppred = &predicate_dependency_xindirect__goals_9;
  goto interrupt_9;
 }

 indirect__goals1_9_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 indirect__goals1_9_clear_reason:
  reasonp = reasons;
 indirect__goals1_9_0:
 indirect__goals1_9_1:
  if (!isint(a0)) goto indirect__goals1_9_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,indirect__goals1_9_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xindirect__goals1_9);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = x3 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x1;
  allocp[16] = makesym(functor_goal_4);
  allocp[17] = a2;
  allocp[18] = a3;
  allocp[19] = a1;
  allocp[20] = a0;
  x4 = makefunctor(&allocp[16]);
  allocp[21] = (q)(struct goalrec*)&allocp[11];
  allocp[22] = (q)(&predicate_dependency_xindirect__goal_7);
  allocp[23] = x4;
  allocp[24] = x5 = makeref(&allocp[24]);
  allocp[25] = x6 = makeref(&allocp[25]);
  allocp[26] = a5;
  allocp[27] = x2;
  allocp[28] = a7;
  allocp[29] = x3;
  allocp[30] = (q)(struct goalrec*)&allocp[21];
  allocp[31] = (q)(&predicate_parse__uty_xget__goal_6);
  allocp[32] = a2;
  allocp[33] = a3;
  allocp[34] = a0;
  allocp[35] = a1;
  allocp[36] = x5;
  allocp[37] = a5;
  qp = (struct goalrec*)&allocp[30];
  allocp += 38;
  proceed();
 indirect__goals1_9_2:
  if (a0 != makeint(0L)) goto indirect__goals1_9_interrupt;
  unify2(a8, a7, a6, a5);
  proceed();
 indirect__goals1_9_3:
  if (!isref(a0)) goto indirect__goals1_9_interrupt;
  deref_and_jump(a0,indirect__goals1_9_1);
  *reasonp++ =  a0;
  goto indirect__goals1_9_interrupt;
 indirect__goals1_9_ext_interrupt:
  reasonp = 0l;
 indirect__goals1_9_interrupt:
  goto interrupt_9;
 }

 indirect__goal_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 indirect__goal_7_clear_reason:
  reasonp = reasons;
 indirect__goal_7_0:
 indirect__goal_7_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_done)) goto indirect__goal_7_2;
  unify2(a6, a5, a4, a3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dt_xget__deps_4);
  allocp[2] = makesym(atom_execute);
  allocp[3] = a0;
  allocp[4] = a2;
  allocp[5] = a5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  proceed();
 case VARREF:
  deref_and_jump(a1,indirect__goal_7_1);
  *reasonp++ =  a1;
  goto indirect__goal_7_2;
  };
  goto indirect__goal_7_2;
 indirect__goal_7_2:
  otherwise(indirect__goal_7_interrupt);
 indirect__goal_7_3:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_goal_4)) goto indirect__goal_7_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_list_xor__unique_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_dt_xentry_5);
  allocp[7] = makesym(atom_data);
  allocp[8] = a0;
  allocp[9] = x1;
  allocp[10] = x2 = makeref(&allocp[10]);
  allocp[11] = a6;
  allocp[12] = (q)(struct goalrec*)&allocp[5];
  allocp[13] = (q)(&predicate_dt_xentry_5);
  allocp[14] = makesym(atom_control);
  allocp[15] = a0;
  allocp[16] = x0;
  allocp[17] = x3 = makeref(&allocp[17]);
  allocp[18] = x2;
  allocp[19] = (q)(struct goalrec*)&allocp[12];
  allocp[20] = (q)(&predicate_dependency_xexpand__indirect_6);
  allocp[21] = x4 = makeref(&allocp[21]);
  allocp[22] = x1;
  allocp[23] = x5 = makeref(&allocp[23]);
  allocp[24] = a4;
  allocp[25] = x6 = makeref(&allocp[25]);
  allocp[26] = x3;
  allocp[27] = (q)(struct goalrec*)&allocp[19];
  allocp[28] = (q)(&predicate_dependency_xexpand__indirect_6);
  allocp[29] = x7 = makeref(&allocp[29]);
  allocp[30] = x0;
  allocp[31] = x8 = makeref(&allocp[31]);
  allocp[32] = x5;
  allocp[33] = a5;
  allocp[34] = x6;
  allocp[35] = (q)(struct goalrec*)&allocp[27];
  allocp[36] = (q)(&predicate_dt_xget__deps_4);
  allocp[37] = makesym(atom_data);
  allocp[38] = a0;
  allocp[39] = x4;
  allocp[40] = a5;
  allocp[41] = (q)(struct goalrec*)&allocp[35];
  allocp[42] = (q)(&predicate_dt_xget__deps_4);
  allocp[43] = makesym(atom_control);
  allocp[44] = a0;
  allocp[45] = x7;
  allocp[46] = a5;
  allocp[47] = (q)(struct goalrec*)&allocp[41];
  allocp[48] = (q)(&predicate_parse__uty_xupdate__goal_7);
  x9 = arg(a0, 0);
  allocp[49] = x9;
  x10 = arg(a0, 1);
  allocp[50] = x10;
  x11 = arg(a0, 3);
  allocp[51] = x11;
  x12 = arg(a0, 2);
  allocp[52] = x12;
  allocp[53] = makesym(atom_done);
  allocp[54] = a3;
  allocp[55] = x8;
  qp = (struct goalrec*)&allocp[47];
  allocp += 56;
  proceed();
 case VARREF:
  deref_and_jump(a0,indirect__goal_7_3);
  *reasonp++ =  a0;
  goto indirect__goal_7_interrupt;
  };
  goto indirect__goal_7_interrupt;
 indirect__goal_7_ext_interrupt:
  reasonp = 0l;
 indirect__goal_7_interrupt:
  goto interrupt_7;
 }

 expand__indirect_6_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 expand__indirect_6_clear_reason:
  reasonp = reasons;
 expand__indirect_6_0:
  x0 = a0;
  x1 = a0;
  x2 = a1;
  x3 = a2;
  x4 = a3;
  x5 = a4;
  a6 = a5;
  a5 = x5;
  a4 = x4;
  a3 = x3;
  a2 = x2;
  a1 = x1;
  a0 = x0;
  execute(expand__indirect_7_0);
  goto expand__indirect_7_ext_interrupt;
 expand__indirect_6_ext_interrupt:
  reasonp = 0l;
 expand__indirect_6_interrupt:
  goto interrupt_6;
 }

 expand__indirect_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 expand__indirect_7_clear_reason:
  reasonp = reasons;
 expand__indirect_7_0:
 expand__indirect_7_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 expand__indirect_7_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_goal_4)) goto expand__indirect_7_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dependency_xexpand__indirect_7);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x4 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_list_xor__unique_3);
  allocp[11] = a1;
  allocp[12] = x5 = makeref(&allocp[12]);
  allocp[13] = x2;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_dependency_xindirect__goal_7);
  allocp[16] = x0;
  allocp[17] = x6 = makeref(&allocp[17]);
  allocp[18] = x5;
  allocp[19] = a3;
  allocp[20] = x3;
  allocp[21] = a5;
  allocp[22] = x4;
  allocp[23] = (q)(struct goalrec*)&allocp[14];
  allocp[24] = (q)(&predicate_parse__uty_xget__goal_6);
  x7 = arg(x0, 0);
  allocp[25] = x7;
  x8 = arg(x0, 1);
  allocp[26] = x8;
  x9 = arg(x0, 3);
  allocp[27] = x9;
  x10 = arg(x0, 2);
  allocp[28] = x10;
  allocp[29] = x6;
  allocp[30] = a3;
  qp = (struct goalrec*)&allocp[23];
  allocp += 31;
  proceed();
 case VARREF:
  deref_and_jump(x0,expand__indirect_7_2);
  *reasonp++ =  x0;
  goto expand__indirect_7_interrupt;
  };
  goto expand__indirect_7_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto expand__indirect_7_interrupt;
  unify3(a6, a5, a2, a1, a4, a3);
  proceed();
 case VARREF:
  deref_and_jump(a0,expand__indirect_7_1);
  *reasonp++ =  a0;
  goto expand__indirect_7_interrupt;
  };
  goto expand__indirect_7_interrupt;
 expand__indirect_7_ext_interrupt:
  reasonp = 0l;
 expand__indirect_7_interrupt:
  toppred = &predicate_dependency_xexpand__indirect_7;
  goto interrupt_7;
 }
 interrupt_10:
  allocp[11] = a9;
 interrupt_9:
  allocp[10] = a8;
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_dependency);
}
