/* Compiled by KLIC compiler version 3.002 (Wed Sep 17 15:37:13 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_functor();
Const struct predicate predicate_functor_xget__arg__pos_3 =
   { module_functor, 0, 3 };
Const struct predicate predicate_functor_xget__arg__pos1_4 =
   { module_functor, 1, 4 };
Const struct predicate predicate_functor_xinsert__arg_4 =
   { module_functor, 2, 4 };
Const struct predicate predicate_functor_xinsert__arg__args_7 =
   { module_functor, 3, 7 };
Const struct predicate predicate_functor_xdelete__arg_3 =
   { module_functor, 4, 3 };
Const struct predicate predicate_functor_xdelete__arg__args_6 =
   { module_functor, 5, 6 };
Const struct predicate predicate_functor_xnew__functor__init_4 =
   { module_functor, 6, 4 };
Const struct predicate predicate_functor_xnew__functor__init1_4 =
   { module_functor, 7, 4 };
Const struct predicate predicate_functor_xcreate__functor_3 =
   { module_functor, 8, 3 };
Const struct predicate predicate_functor_xcreate__functor1_4 =
   { module_functor, 9, 4 };
Const struct predicate predicate_functor_xsearch__functorname_3 =
   { module_functor, 10, 3 };
Const struct predicate predicate_functor_xsearch__functorname_4 =
   { module_functor, 11, 4 };
extern Const struct predicate predicate_list_xcount__element_2;
extern Const struct predicate predicate_integer__arithmetics_xadd_3;
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_xsetarg_4;
extern Const struct predicate predicate_functor__table_xfunctor_3;
extern Const struct predicate predicate_functor__table_xnew__functor_3;

module module_functor(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  q a0, a1, a2, a3, a4, a5, a6;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  switch_on_pred() {
    case_pred(0, get__arg__pos_3_top);
    case_pred(1, get__arg__pos1_4_top);
    case_pred(2, insert__arg_4_top);
    case_pred(3, insert__arg__args_7_top);
    case_pred(4, delete__arg_3_top);
    case_pred(5, delete__arg__args_6_top);
    case_pred(6, new__functor__init_4_top);
    case_pred(7, new__functor__init1_4_top);
    case_pred(8, create__functor_3_top);
    case_pred(9, create__functor1_4_top);
    case_pred(10, search__functorname_3_top);
    last_case_pred(11, search__functorname_4_top);
  }

 get__arg__pos_3_top: {
  q x0, x1;
  qp = qp->next;
 get__arg__pos_3_clear_reason:
  reasonp = reasons;
 get__arg__pos_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor_xget__arg__pos1_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[8] = a0;
  allocp[9] = x1 = makeref(&allocp[9]);
  allocp[10] = x0;
  qp = (struct goalrec*)&allocp[6];
  allocp += 11;
  proceed();
 get__arg__pos_3_ext_interrupt:
  reasonp = 0l;
 get__arg__pos_3_interrupt:
  goto interrupt_3;
 }

 get__arg__pos1_4_top: {
  q x0, x1, x2, x3;
  a3 = qp->args[3];
  qp = qp->next;
 get__arg__pos1_4_clear_reason:
  reasonp = reasons;
 get__arg__pos1_4_0:
 get__arg__pos1_4_1:
  if (!isint(a0)) goto get__arg__pos1_4_8;
  x0 = makeint(0L);
  gblt_greater(a0,x0,get__arg__pos1_4_9);
 get__arg__pos1_4_2:
  if (isref(a1)) goto get__arg__pos1_4_7;
  gblt_arg(a0,a1,x1,get__arg__pos1_4_9);
 get__arg__pos1_4_3:
  if (isref(x1)) goto get__arg__pos1_4_6;
 get__arg__pos1_4_4:
  if (isref(x1)) goto get__arg__pos1_4_5;
  if_not_equal(x1, a2, get__arg__pos1_4_9);
  unify_value(a3, a0);
  proceed();
 get__arg__pos1_4_5:
  deref_and_jump(x1,get__arg__pos1_4_4);
  *reasonp++ =  x1;
  goto get__arg__pos1_4_9;
 get__arg__pos1_4_6:
  deref_and_jump(x1,get__arg__pos1_4_3);
  *reasonp++ =  x1;
  goto get__arg__pos1_4_9;
 get__arg__pos1_4_7:
  deref_and_jump(a1,get__arg__pos1_4_2);
  *reasonp++ =  a1;
  goto get__arg__pos1_4_9;
 get__arg__pos1_4_8:
  if (!isref(a0)) goto get__arg__pos1_4_9;
  deref_and_jump(a0,get__arg__pos1_4_1);
  *reasonp++ =  a0;
  goto get__arg__pos1_4_9;
 get__arg__pos1_4_9:
  otherwise(get__arg__pos1_4_interrupt);
 get__arg__pos1_4_10:
  if (!isint(a0)) goto get__arg__pos1_4_12;
  x0 = makeint(0L);
  gblt_greater(a0,x0,get__arg__pos1_4_11);
  x1 = makeint(1L);
  bblt_sub_no_check(a0,x1,x2);
  a0 = x2;
  execute(get__arg__pos1_4_0);
  goto get__arg__pos1_4_ext_interrupt;
 get__arg__pos1_4_11:
  if (a0 != makeint(0L)) goto get__arg__pos1_4_interrupt;
  x3 = makeint(0L);
  unify_value(a3, x3);
  proceed();
 get__arg__pos1_4_12:
  if (!isref(a0)) goto get__arg__pos1_4_interrupt;
  deref_and_jump(a0,get__arg__pos1_4_10);
  *reasonp++ =  a0;
  goto get__arg__pos1_4_interrupt;
 get__arg__pos1_4_ext_interrupt:
  reasonp = 0l;
 get__arg__pos1_4_interrupt:
  goto interrupt_4;
 }

 insert__arg_4_top: {
  q x0, x1, x2, x3, x4;
  a3 = qp->args[3];
  qp = qp->next;
 insert__arg_4_clear_reason:
  reasonp = reasons;
 insert__arg_4_0:
 insert__arg_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 insert__arg_4_2:
  if (a0 != makeint(1L)) goto insert__arg_4_5;
 insert__arg_4_3:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (isint(a1)) goto insert__arg_4_5;
 insert__arg_4_4:
  gblt_atom(a1,insert__arg_4_5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = makeint(1L);
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xnew__functor_3);
  allocp[8] = x0;
  allocp[9] = a1;
  allocp[10] = makeint(1L);
  qp = (struct goalrec*)&allocp[6];
  allocp += 11;
  proceed();
 case VARREF:
  deref_and_jump(a1,insert__arg_4_3);
  *reasonp++ =  a1;
  goto insert__arg_4_5;
  };
  goto insert__arg_4_5;
 case VARREF:
  deref_and_jump(a0,insert__arg_4_1);
  *reasonp++ =  a0;
  goto insert__arg_4_5;
  };
  goto insert__arg_4_5;
 insert__arg_4_5:
  otherwise(insert__arg_4_interrupt);
 insert__arg_4_6:
  if (!isint(a0)) goto insert__arg_4_7;
  x0 = makeint(0L);
  gblt_less(a0,x0,insert__arg_4_8);
  x1 = NILATOM;
  unify_value(a3, x1);
  proceed();
 insert__arg_4_7:
  if (!isref(a0)) goto insert__arg_4_8;
  deref_and_jump(a0,insert__arg_4_6);
  *reasonp++ =  a0;
  goto insert__arg_4_8;
 insert__arg_4_8:
 insert__arg_4_9:
  if (isref(a1)) goto insert__arg_4_12;
  gblt_pfunctor(a1,x0,insert__arg_4_13);
  gblt_arity(a1,x1,insert__arg_4_13);
  x3 = makeint(1L);
  gblt_add(x1,x3,x2,insert__arg_4_13);
 insert__arg_4_10:
  if (!isint(a0)) goto insert__arg_4_11;
  gblt_greater(a0,x2,insert__arg_4_13);
  x4 = NILATOM;
  unify_value(a3, x4);
  proceed();
 insert__arg_4_11:
  if (!isref(a0)) goto insert__arg_4_13;
  deref_and_jump(a0,insert__arg_4_10);
  *reasonp++ =  a0;
  goto insert__arg_4_13;
 insert__arg_4_12:
  deref_and_jump(a1,insert__arg_4_9);
  *reasonp++ =  a1;
  goto insert__arg_4_13;
 insert__arg_4_13:
  otherwise(insert__arg_4_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor_xinsert__arg__args_7);
  allocp[2] = makeint(1L);
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a0;
  allocp[5] = a2;
  allocp[6] = a1;
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = a3;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_functor__table_xnew__functor_3);
  allocp[11] = x1;
  allocp[12] = x2 = makeref(&allocp[12]);
  allocp[13] = x0;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[16] = x3 = makeref(&allocp[16]);
  allocp[17] = makeint(1L);
  allocp[18] = x0;
  allocp[19] = (q)(struct goalrec*)&allocp[14];
  allocp[20] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[21] = a1;
  allocp[22] = x2;
  allocp[23] = x3;
  qp = (struct goalrec*)&allocp[19];
  allocp += 24;
  proceed();
 insert__arg_4_ext_interrupt:
  reasonp = 0l;
 insert__arg_4_interrupt:
  goto interrupt_4;
 }

 insert__arg__args_7_top: {
  q x0, x1, x2, x3, x4;
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 insert__arg__args_7_clear_reason:
  reasonp = reasons;
 insert__arg__args_7_0:
 insert__arg__args_7_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (!isint(a0)) goto insert__arg__args_7_11;
 insert__arg__args_7_2:
 insert__arg__args_7_3:
  if (!isint(a2)) goto insert__arg__args_7_7;
  gblt_less(a0,a2,insert__arg__args_7_4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor_xinsert__arg__args_7);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[11] = a0;
  allocp[12] = makeint(1L);
  allocp[13] = x0;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[16] = a0;
  allocp[17] = a5;
  allocp[18] = x2 = makeref(&allocp[18]);
  allocp[19] = x1;
  allocp[20] = (q)(struct goalrec*)&allocp[14];
  allocp[21] = (q)(&predicate_functor__table_xarg_3);
  allocp[22] = a0;
  allocp[23] = a4;
  allocp[24] = x2;
  qp = (struct goalrec*)&allocp[20];
  allocp += 25;
  proceed();
 insert__arg__args_7_4:
  gblt_greater(a0,a2,insert__arg__args_7_8);
 insert__arg__args_7_5:
  if (!isint(a1)) goto insert__arg__args_7_6;
  gblt_less_or_eq(a0,a1,insert__arg__args_7_8);
  x0 = makeint(1L);
  bblt_sub_no_check(a0,x0,x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor_xinsert__arg__args_7);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[11] = a0;
  allocp[12] = makeint(1L);
  allocp[13] = x2;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[16] = a0;
  allocp[17] = a5;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = x3;
  allocp[20] = (q)(struct goalrec*)&allocp[14];
  allocp[21] = (q)(&predicate_functor__table_xarg_3);
  allocp[22] = x1;
  allocp[23] = a4;
  allocp[24] = x4;
  qp = (struct goalrec*)&allocp[20];
  allocp += 25;
  proceed();
 insert__arg__args_7_6:
  if (!isref(a1)) goto insert__arg__args_7_8;
  deref_and_jump(a1,insert__arg__args_7_5);
  *reasonp++ =  a1;
  goto insert__arg__args_7_8;
 insert__arg__args_7_7:
  if (!isref(a2)) goto insert__arg__args_7_8;
  deref_and_jump(a2,insert__arg__args_7_3);
  *reasonp++ =  a2;
  goto insert__arg__args_7_8;
 insert__arg__args_7_8:
 insert__arg__args_7_9:
  if (!isint(a1)) goto insert__arg__args_7_10;
  gblt_greater(a0,a1,insert__arg__args_7_11);
  unify(a6, a5);
  proceed();
 insert__arg__args_7_10:
  if (!isref(a1)) goto insert__arg__args_7_11;
  deref_and_jump(a1,insert__arg__args_7_9);
  *reasonp++ =  a1;
  goto insert__arg__args_7_11;
 case VARREF:
  deref_and_jump(a0,insert__arg__args_7_1);
  *reasonp++ =  a0;
  goto insert__arg__args_7_interrupt;
  };
  goto insert__arg__args_7_11;
 insert__arg__args_7_11:
 insert__arg__args_7_12:
  if (isref(a0)) goto insert__arg__args_7_13;
  if_not_equal(a0, a2, insert__arg__args_7_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor_xinsert__arg__args_7);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[11] = a0;
  allocp[12] = makeint(1L);
  allocp[13] = x0;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[16] = a0;
  allocp[17] = a5;
  allocp[18] = a3;
  allocp[19] = x1;
  qp = (struct goalrec*)&allocp[14];
  allocp += 20;
  proceed();
 insert__arg__args_7_13:
  deref_and_jump(a0,insert__arg__args_7_12);
  *reasonp++ =  a0;
  goto insert__arg__args_7_interrupt;
 insert__arg__args_7_ext_interrupt:
  reasonp = 0l;
 insert__arg__args_7_interrupt:
  goto interrupt_7;
 }

 delete__arg_3_top: {
  q x0, x1, x2, x3;
  qp = qp->next;
 delete__arg_3_clear_reason:
  reasonp = reasons;
 delete__arg_3_0:
 delete__arg_3_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (isint(a1)) goto delete__arg_3_3;
 delete__arg_3_2:
  gblt_atom(a1,delete__arg_3_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = makeint(1L);
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a2;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xnew__functor_3);
  allocp[8] = x0;
  allocp[9] = a1;
  allocp[10] = makeint(1L);
  qp = (struct goalrec*)&allocp[6];
  allocp += 11;
  proceed();
 case VARREF:
  deref_and_jump(a1,delete__arg_3_1);
  *reasonp++ =  a1;
  goto delete__arg_3_3;
  };
  goto delete__arg_3_3;
 delete__arg_3_3:
  otherwise(delete__arg_3_interrupt);
 delete__arg_3_4:
  if (!isint(a0)) goto delete__arg_3_5;
  x0 = makeint(0L);
  gblt_less(a0,x0,delete__arg_3_6);
  x1 = NILATOM;
  unify_value(a2, x1);
  proceed();
 delete__arg_3_5:
  if (!isref(a0)) goto delete__arg_3_6;
  deref_and_jump(a0,delete__arg_3_4);
  *reasonp++ =  a0;
  goto delete__arg_3_6;
 delete__arg_3_6:
 delete__arg_3_7:
  if (isref(a1)) goto delete__arg_3_10;
  gblt_pfunctor(a1,x0,delete__arg_3_11);
  gblt_arity(a1,x1,delete__arg_3_11);
 delete__arg_3_8:
  if (!isint(a0)) goto delete__arg_3_9;
  gblt_greater(a0,x1,delete__arg_3_11);
  x2 = NILATOM;
  unify_value(a2, x2);
  proceed();
 delete__arg_3_9:
  if (!isref(a0)) goto delete__arg_3_11;
  deref_and_jump(a0,delete__arg_3_8);
  *reasonp++ =  a0;
  goto delete__arg_3_11;
 delete__arg_3_10:
  deref_and_jump(a1,delete__arg_3_7);
  *reasonp++ =  a1;
  goto delete__arg_3_11;
 delete__arg_3_11:
  otherwise(delete__arg_3_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor_xdelete__arg__args_6);
  allocp[2] = makeint(1L);
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a0;
  allocp[5] = a1;
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = a2;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_functor__table_xnew__functor_3);
  allocp[10] = x1;
  allocp[11] = x2 = makeref(&allocp[11]);
  allocp[12] = x0;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[15] = x3 = makeref(&allocp[15]);
  allocp[16] = makeint(1L);
  allocp[17] = x0;
  allocp[18] = (q)(struct goalrec*)&allocp[13];
  allocp[19] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[20] = a1;
  allocp[21] = x2;
  allocp[22] = x3;
  qp = (struct goalrec*)&allocp[18];
  allocp += 23;
  proceed();
 delete__arg_3_ext_interrupt:
  reasonp = 0l;
 delete__arg_3_interrupt:
  goto interrupt_3;
 }

 delete__arg__args_6_top: {
  q x0, x1, x2, x3, x4;
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 delete__arg__args_6_clear_reason:
  reasonp = reasons;
 delete__arg__args_6_0:
 delete__arg__args_6_1:
  if (!isint(a0)) goto delete__arg__args_6_10;
 delete__arg__args_6_2:
  if (!isint(a2)) goto delete__arg__args_6_6;
  gblt_less(a0,a2,delete__arg__args_6_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor_xdelete__arg__args_6);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[10] = a0;
  allocp[11] = makeint(1L);
  allocp[12] = x0;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[15] = a0;
  allocp[16] = a4;
  allocp[17] = x2 = makeref(&allocp[17]);
  allocp[18] = x1;
  allocp[19] = (q)(struct goalrec*)&allocp[13];
  allocp[20] = (q)(&predicate_functor__table_xarg_3);
  allocp[21] = a0;
  allocp[22] = a3;
  allocp[23] = x2;
  qp = (struct goalrec*)&allocp[19];
  allocp += 24;
  proceed();
 delete__arg__args_6_3:
  gblt_greater_or_eq(a0,a2,delete__arg__args_6_7);
 delete__arg__args_6_4:
  if (!isint(a1)) goto delete__arg__args_6_5;
  gblt_less_or_eq(a0,a1,delete__arg__args_6_7);
  x0 = makeint(1L);
  bblt_add_no_check(a0,x0,x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor_xdelete__arg__args_6);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[10] = a0;
  allocp[11] = makeint(1L);
  allocp[12] = x2;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[15] = a0;
  allocp[16] = a4;
  allocp[17] = x4 = makeref(&allocp[17]);
  allocp[18] = x3;
  allocp[19] = (q)(struct goalrec*)&allocp[13];
  allocp[20] = (q)(&predicate_functor__table_xarg_3);
  allocp[21] = x1;
  allocp[22] = a3;
  allocp[23] = x4;
  qp = (struct goalrec*)&allocp[19];
  allocp += 24;
  proceed();
 delete__arg__args_6_5:
  if (!isref(a1)) goto delete__arg__args_6_7;
  deref_and_jump(a1,delete__arg__args_6_4);
  *reasonp++ =  a1;
  goto delete__arg__args_6_7;
 delete__arg__args_6_6:
  if (!isref(a2)) goto delete__arg__args_6_7;
  deref_and_jump(a2,delete__arg__args_6_2);
  *reasonp++ =  a2;
  goto delete__arg__args_6_7;
 delete__arg__args_6_7:
 delete__arg__args_6_8:
  if (!isint(a1)) goto delete__arg__args_6_9;
  gblt_greater(a0,a1,delete__arg__args_6_interrupt);
  unify(a5, a4);
  proceed();
 delete__arg__args_6_9:
  if (!isref(a1)) goto delete__arg__args_6_interrupt;
  deref_and_jump(a1,delete__arg__args_6_8);
  *reasonp++ =  a1;
  goto delete__arg__args_6_interrupt;
 delete__arg__args_6_10:
  if (!isref(a0)) goto delete__arg__args_6_interrupt;
  deref_and_jump(a0,delete__arg__args_6_1);
  *reasonp++ =  a0;
  goto delete__arg__args_6_interrupt;
 delete__arg__args_6_ext_interrupt:
  reasonp = 0l;
 delete__arg__args_6_interrupt:
  goto interrupt_6;
 }

 new__functor__init_4_top: {
  q x0;
  a3 = qp->args[3];
  qp = qp->next;
 new__functor__init_4_clear_reason:
  reasonp = reasons;
 new__functor__init_4_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor_xnew__functor__init1_4);
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xnew__functor_3);
  allocp[8] = x0;
  allocp[9] = a0;
  allocp[10] = a1;
  qp = (struct goalrec*)&allocp[6];
  allocp += 11;
  proceed();
 new__functor__init_4_ext_interrupt:
  reasonp = 0l;
 new__functor__init_4_interrupt:
  goto interrupt_4;
 }

 new__functor__init1_4_top: {
  q x0, x1, x2;
  a3 = qp->args[3];
  qp = qp->next;
 new__functor__init1_4_clear_reason:
  reasonp = reasons;
 new__functor__init1_4_0:
 new__functor__init1_4_1:
  if (!isint(a0)) goto new__functor__init1_4_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,new__functor__init1_4_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor_xnew__functor__init1_4);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x1;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[13] = a0;
  allocp[14] = a2;
  allocp[15] = a1;
  allocp[16] = x2;
  qp = (struct goalrec*)&allocp[11];
  allocp += 17;
  proceed();
 new__functor__init1_4_2:
  if (a0 != makeint(0L)) goto new__functor__init1_4_interrupt;
  unify(a3, a2);
  proceed();
 new__functor__init1_4_3:
  if (!isref(a0)) goto new__functor__init1_4_interrupt;
  deref_and_jump(a0,new__functor__init1_4_1);
  *reasonp++ =  a0;
  goto new__functor__init1_4_interrupt;
 new__functor__init1_4_ext_interrupt:
  reasonp = 0l;
 new__functor__init1_4_interrupt:
  goto interrupt_4;
 }

 create__functor_3_top: {
  q x0, x1;
  qp = qp->next;
 create__functor_3_clear_reason:
  reasonp = reasons;
 create__functor_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor_xcreate__functor1_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = makeint(1L);
  allocp[5] = a2;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xnew__functor_3);
  allocp[8] = x0;
  allocp[9] = a0;
  allocp[10] = x1 = makeref(&allocp[10]);
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_list_xcount__element_2);
  allocp[13] = a1;
  allocp[14] = x1;
  qp = (struct goalrec*)&allocp[11];
  allocp += 15;
  proceed();
 create__functor_3_ext_interrupt:
  reasonp = 0l;
 create__functor_3_interrupt:
  goto interrupt_3;
 }

 create__functor1_4_top: {
  q x0, x1, x2, x3;
  a3 = qp->args[3];
  qp = qp->next;
 create__functor1_4_clear_reason:
  reasonp = reasons;
 create__functor1_4_0:
 create__functor1_4_1:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor_xcreate__functor1_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  x1 = cdr_of(a1);
  allocp[3] = x1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[8] = a2;
  allocp[9] = makeint(1L);
  allocp[10] = x2;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[13] = a2;
  allocp[14] = a0;
  x3 = car_of(a1);
  allocp[15] = x3;
  allocp[16] = x0;
  qp = (struct goalrec*)&allocp[11];
  allocp += 17;
  proceed();
 case ATOMIC:
  if (a1 != NILATOM) goto create__functor1_4_interrupt;
  unify(a3, a0);
  proceed();
 case VARREF:
  deref_and_jump(a1,create__functor1_4_1);
  *reasonp++ =  a1;
  goto create__functor1_4_interrupt;
  };
  goto create__functor1_4_interrupt;
 create__functor1_4_ext_interrupt:
  reasonp = 0l;
 create__functor1_4_interrupt:
  goto interrupt_4;
 }

 search__functorname_3_top: {
  q x0, x1;
  qp = qp->next;
 search__functorname_3_clear_reason:
  reasonp = reasons;
 search__functorname_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor_xsearch__functorname_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[8] = a1;
  allocp[9] = x1 = makeref(&allocp[9]);
  allocp[10] = x0;
  qp = (struct goalrec*)&allocp[6];
  allocp += 11;
  proceed();
 search__functorname_3_ext_interrupt:
  reasonp = 0l;
 search__functorname_3_interrupt:
  goto interrupt_3;
 }

 search__functorname_4_top: {
  q x0, x1, x2, x3, x4;
  a3 = qp->args[3];
  qp = qp->next;
 search__functorname_4_clear_reason:
  reasonp = reasons;
 search__functorname_4_0:
 search__functorname_4_1:
  if (!isint(a0)) goto search__functorname_4_10;
  x0 = makeint(0L);
  gblt_greater(a0,x0,search__functorname_4_11);
 search__functorname_4_2:
  if (isref(a2)) goto search__functorname_4_9;
  gblt_arg(a0,a2,x1,search__functorname_4_11);
 search__functorname_4_3:
  if (isref(x1)) goto search__functorname_4_8;
  gblt_pfunctor(x1,x2,search__functorname_4_11);
 search__functorname_4_4:
  if (isref(x2)) goto search__functorname_4_7;
 search__functorname_4_5:
  if (isref(x2)) goto search__functorname_4_6;
  if_not_equal(x2, a1, search__functorname_4_11);
  gblt_arity(x1,x3,search__functorname_4_11);
  x4 = makesym(atom_yes);
  unify_value(a3, x4);
  proceed();
 search__functorname_4_6:
  deref_and_jump(x2,search__functorname_4_5);
  *reasonp++ =  x2;
  goto search__functorname_4_11;
 search__functorname_4_7:
  deref_and_jump(x2,search__functorname_4_4);
  *reasonp++ =  x2;
  goto search__functorname_4_11;
 search__functorname_4_8:
  deref_and_jump(x1,search__functorname_4_3);
  *reasonp++ =  x1;
  goto search__functorname_4_11;
 search__functorname_4_9:
  deref_and_jump(a2,search__functorname_4_2);
  *reasonp++ =  a2;
  goto search__functorname_4_11;
 search__functorname_4_10:
  if (!isref(a0)) goto search__functorname_4_11;
  deref_and_jump(a0,search__functorname_4_1);
  *reasonp++ =  a0;
  goto search__functorname_4_11;
 search__functorname_4_11:
  otherwise(search__functorname_4_interrupt);
 search__functorname_4_12:
  if (!isint(a0)) goto search__functorname_4_14;
  x0 = makeint(0L);
  gblt_greater(a0,x0,search__functorname_4_13);
  x1 = makeint(1L);
  bblt_sub_no_check(a0,x1,x2);
  a0 = x2;
  execute(search__functorname_4_0);
  goto search__functorname_4_ext_interrupt;
 search__functorname_4_13:
  if (a0 != makeint(0L)) goto search__functorname_4_interrupt;
  x3 = makesym(atom_no);
  unify_value(a3, x3);
  proceed();
 search__functorname_4_14:
  if (!isref(a0)) goto search__functorname_4_interrupt;
  deref_and_jump(a0,search__functorname_4_12);
  *reasonp++ =  a0;
  goto search__functorname_4_interrupt;
 search__functorname_4_ext_interrupt:
  reasonp = 0l;
 search__functorname_4_interrupt:
  goto interrupt_4;
 }
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_functor);
}
