/*  $B%W%m%0%i%`A4BN$r2r@O(B    */
#define FULL_ANALYSIS

%#define PRINT
%#define PRINT_SCHEDULE

/* unix$B%b%8%e!<%k;XDj$,%^%/%m$H2r<a$5$l$k$N$rKI$0(B */
#undef unix

%       $B:GE,2=$N@_Dj(B
%   $B%4!<%k4V$ND>@\%8%c%s%W:GE,2=$rM-8z$K$9$k(B
%#define ENABLE_DIRECT_GO

%       $B%R%e!<%j%9%F%#%C%/Dj?t(B
%   new_functor/3$B$G8GDjD99=B$%G!<%?7?$r:n$k(BArity$B$N>e8B(B
#define NEW_FUNCTOR_MAXSIZE 5
