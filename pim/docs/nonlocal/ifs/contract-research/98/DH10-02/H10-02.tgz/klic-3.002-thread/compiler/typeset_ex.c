/* Compiled by KLIC compiler version 3.002 (Wed Sep 17 15:37:13 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_typeset__ex();
Const struct predicate predicate_typeset__ex_xextend__typeset_4 =
   { module_typeset__ex, 0, 4 };
Const struct predicate predicate_typeset__ex_xextend__typeset_6 =
   { module_typeset__ex, 1, 6 };
Const struct predicate predicate_typeset__ex_xextend__ts__clauses_8 =
   { module_typeset__ex, 2, 8 };
Const struct predicate predicate_typeset__ex_xextend__ts__clause_8 =
   { module_typeset__ex, 3, 8 };
Const struct predicate predicate_typeset__ex_xextend__ts__head_8 =
   { module_typeset__ex, 4, 8 };
Const struct predicate predicate_typeset__ex_xextend__ts__head2_11 =
   { module_typeset__ex, 5, 11 };
Const struct predicate predicate_typeset__ex_xextend__ts__headarg_11 =
   { module_typeset__ex, 6, 11 };
Const struct predicate predicate_typeset__ex_xextend__ts_16 =
   { module_typeset__ex, 7, 16 };
Const struct predicate predicate_typeset__ex_xextend__ts__bodys_9 =
   { module_typeset__ex, 8, 9 };
Const struct predicate predicate_typeset__ex_xextend__ts__body_11 =
   { module_typeset__ex, 9, 11 };
Const struct predicate predicate_typeset__ex_xextend__ts__body2_12 =
   { module_typeset__ex, 10, 12 };
Const struct predicate predicate_typeset__ex_xextend__ts__bodyarg_12 =
   { module_typeset__ex, 11, 12 };
Const struct predicate predicate_typeset__ex_xanalyze_5 =
   { module_typeset__ex, 12, 5 };
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_xfunctor_3;
extern Const struct predicate predicate_parse__uty_xdecode__goal_4;
extern Const struct predicate predicate_parse__uty_xdecode__goalcall_6;
extern Const struct predicate predicate_parse__uty_xget__info_7;
extern Const struct predicate predicate_typeset_xget_5;
extern Const struct predicate predicate_typeset_xset_12;
extern Const struct predicate predicate_typeset_xor__typeset_3;
extern Const struct predicate predicate_hb_xread__mode_6;
extern Const struct predicate predicate_hb_xget__typeset_12;
extern Const struct predicate predicate_analyze__type_xanalyze__typeset_7;
extern Const struct predicate predicate_analyze__type_xindirect__unify_6;
extern Const struct predicate predicate_analyze__type_xinterclause__modules_15;

module module_typeset__ex(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  q a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  switch_on_pred() {
    case_pred(0, extend__typeset_4_top);
    case_pred(1, extend__typeset_6_top);
    case_pred(2, extend__ts__clauses_8_top);
    case_pred(3, extend__ts__clause_8_top);
    case_pred(4, extend__ts__head_8_top);
    case_pred(5, extend__ts__head2_11_top);
    case_pred(6, extend__ts__headarg_11_top);
    case_pred(7, extend__ts_16_top);
    case_pred(8, extend__ts__bodys_9_top);
    case_pred(9, extend__ts__body_11_top);
    case_pred(10, extend__ts__body2_12_top);
    case_pred(11, extend__ts__bodyarg_12_top);
    last_case_pred(12, analyze_5_top);
  }

 extend__typeset_4_top: {
  q x0, x1;
  qp = qp->next;
 extend__typeset_4_clear_reason:
  reasonp = reasons;
 extend__typeset_4_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset__ex_xanalyze_5);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = a3;
  a3 = x1;
  a4 = NILATOM;
  a5 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(extend__typeset_6_0);
  goto extend__typeset_6_ext_interrupt;
 extend__typeset_4_ext_interrupt:
  reasonp = 0l;
 extend__typeset_4_interrupt:
  goto interrupt_4;
 }

 extend__typeset_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 extend__typeset_6_clear_reason:
  reasonp = reasons;
 extend__typeset_6_0:
 extend__typeset_6_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 extend__typeset_6_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto extend__typeset_6_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset__ex_xextend__typeset_6);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_typeset__ex_xextend__ts__clauses_8);
  allocp[10] = x4 = makeref(&allocp[10]);
  x5 = arg(x0, 1);
  allocp[11] = x5;
  x6 = arg(x0, 0);
  allocp[12] = x6;
  allocp[13] = a1;
  allocp[14] = a2;
  allocp[15] = x2;
  allocp[16] = a4;
  allocp[17] = x3;
  allocp[18] = (q)(struct goalrec*)&allocp[8];
  allocp[19] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[20] = x5;
  allocp[21] = x7 = makeref(&allocp[21]);
  allocp[22] = x4;
  qp = (struct goalrec*)&allocp[18];
  allocp += 23;
  proceed();
 case VARREF:
  deref_and_jump(x0,extend__typeset_6_2);
  *reasonp++ =  x0;
  goto extend__typeset_6_interrupt;
  };
  goto extend__typeset_6_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto extend__typeset_6_interrupt;
  unify2(a5, a4, a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,extend__typeset_6_1);
  *reasonp++ =  a0;
  goto extend__typeset_6_interrupt;
  };
  goto extend__typeset_6_interrupt;
 extend__typeset_6_ext_interrupt:
  reasonp = 0l;
 extend__typeset_6_interrupt:
  toppred = &predicate_typeset__ex_xextend__typeset_6;
  goto interrupt_6;
 }

 extend__ts__clauses_8_top: {
  q x0, x1, x2, x3, x4;
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 extend__ts__clauses_8_clear_reason:
  reasonp = reasons;
 extend__ts__clauses_8_0:
 extend__ts__clauses_8_1:
  if (!isint(a0)) goto extend__ts__clauses_8_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,extend__ts__clauses_8_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset__ex_xextend__ts__clauses_8);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[12] = a0;
  allocp[13] = makeint(1L);
  allocp[14] = x1;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_typeset__ex_xextend__ts__clause_8);
  allocp[17] = x4 = makeref(&allocp[17]);
  allocp[18] = a2;
  allocp[19] = a0;
  allocp[20] = a3;
  allocp[21] = a4;
  allocp[22] = x2;
  allocp[23] = a6;
  allocp[24] = x3;
  allocp[25] = (q)(struct goalrec*)&allocp[15];
  allocp[26] = (q)(&predicate_functor__table_xarg_3);
  allocp[27] = a0;
  allocp[28] = a1;
  allocp[29] = x4;
  qp = (struct goalrec*)&allocp[25];
  allocp += 30;
  proceed();
 extend__ts__clauses_8_2:
  if (a0 != makeint(0L)) goto extend__ts__clauses_8_interrupt;
  unify2(a7, a6, a5, a4);
  proceed();
 extend__ts__clauses_8_3:
  if (!isref(a0)) goto extend__ts__clauses_8_interrupt;
  deref_and_jump(a0,extend__ts__clauses_8_1);
  *reasonp++ =  a0;
  goto extend__ts__clauses_8_interrupt;
 extend__ts__clauses_8_ext_interrupt:
  reasonp = 0l;
 extend__ts__clauses_8_interrupt:
  goto interrupt_8;
 }

 extend__ts__clause_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 extend__ts__clause_8_clear_reason:
  reasonp = reasons;
 extend__ts__clause_8_0:
 extend__ts__clause_8_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_clause_4)) goto extend__ts__clause_8_2;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset__ex_xextend__ts__bodys_9);
  allocp[2] = x0 = makeref(&allocp[2]);
  x1 = arg(a0, 2);
  allocp[3] = x1;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = a5;
  allocp[9] = x3 = makeref(&allocp[9]);
  allocp[10] = a7;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[13] = x1;
  allocp[14] = x4 = makeref(&allocp[14]);
  allocp[15] = x0;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_typeset__ex_xextend__ts__head_8);
  allocp[18] = x5 = makeref(&allocp[18]);
  allocp[19] = a1;
  allocp[20] = a2;
  allocp[21] = a3;
  allocp[22] = a4;
  allocp[23] = x2;
  allocp[24] = a6;
  allocp[25] = x3;
  allocp[26] = (q)(struct goalrec*)&allocp[16];
  allocp[27] = (q)(&predicate_parse__uty_xdecode__goal_4);
  x6 = arg(a0, 0);
  allocp[28] = x6;
  allocp[29] = x5;
  allocp[30] = x7 = makeref(&allocp[30]);
  allocp[31] = x8 = makeref(&allocp[31]);
  qp = (struct goalrec*)&allocp[26];
  allocp += 32;
  proceed();
 case VARREF:
  deref_and_jump(a0,extend__ts__clause_8_1);
  *reasonp++ =  a0;
  goto extend__ts__clause_8_2;
  };
  goto extend__ts__clause_8_2;
 extend__ts__clause_8_2:
  otherwise(extend__ts__clause_8_interrupt);
  unify2(a7, a6, a5, a4);
  proceed();
 extend__ts__clause_8_ext_interrupt:
  reasonp = 0l;
 extend__ts__clause_8_interrupt:
  goto interrupt_8;
 }

 extend__ts__head_8_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 extend__ts__head_8_clear_reason:
  reasonp = reasons;
 extend__ts__head_8_0:
 extend__ts__head_8_1:
  if (isref(a0)) goto extend__ts__head_8_2;
  gblt_pfunctor(a0,x0,extend__ts__head_8_interrupt);
  gblt_arity(a0,x1,extend__ts__head_8_interrupt);
  x2 = a0;
  x3 = a1;
  x4 = a2;
  x5 = a3;
  x6 = a4;
  a8 = a5;
  a9 = a6;
  a10 = a7;
  a7 = x6;
  a6 = x5;
  a5 = x4;
  a4 = x3;
  a3 = x1;
  a2 = x0;
  a1 = x2;
  a0 = x1;
  execute(extend__ts__head2_11_0);
  goto extend__ts__head2_11_ext_interrupt;
 extend__ts__head_8_2:
  deref_and_jump(a0,extend__ts__head_8_1);
  *reasonp++ =  a0;
  goto extend__ts__head_8_interrupt;
 extend__ts__head_8_ext_interrupt:
  reasonp = 0l;
 extend__ts__head_8_interrupt:
  goto interrupt_8;
 }

 extend__ts__head2_11_top: {
  q x0, x1, x2, x3, x4;
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 extend__ts__head2_11_clear_reason:
  reasonp = reasons;
 extend__ts__head2_11_0:
 extend__ts__head2_11_1:
  if (!isint(a0)) goto extend__ts__head2_11_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,extend__ts__head2_11_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset__ex_xextend__ts__head2_11);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = x3 = makeref(&allocp[11]);
  allocp[12] = a10;
  allocp[13] = (q)(struct goalrec*)&allocp[0];
  allocp[14] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[15] = a0;
  allocp[16] = makeint(1L);
  allocp[17] = x1;
  allocp[18] = (q)(struct goalrec*)&allocp[13];
  allocp[19] = (q)(&predicate_typeset__ex_xextend__ts__headarg_11);
  allocp[20] = x4 = makeref(&allocp[20]);
  allocp[21] = a4;
  allocp[22] = a5;
  allocp[23] = a2;
  allocp[24] = a3;
  allocp[25] = a0;
  allocp[26] = a6;
  allocp[27] = a7;
  allocp[28] = x2;
  allocp[29] = a9;
  allocp[30] = x3;
  allocp[31] = (q)(struct goalrec*)&allocp[18];
  allocp[32] = (q)(&predicate_functor__table_xarg_3);
  allocp[33] = a0;
  allocp[34] = a1;
  allocp[35] = x4;
  qp = (struct goalrec*)&allocp[31];
  allocp += 36;
  proceed();
 extend__ts__head2_11_2:
  if (a0 != makeint(0L)) goto extend__ts__head2_11_interrupt;
  unify2(a10, a9, a8, a7);
  proceed();
 extend__ts__head2_11_3:
  if (!isref(a0)) goto extend__ts__head2_11_interrupt;
  deref_and_jump(a0,extend__ts__head2_11_1);
  *reasonp++ =  a0;
  goto extend__ts__head2_11_interrupt;
 extend__ts__head2_11_ext_interrupt:
  reasonp = 0l;
 extend__ts__head2_11_interrupt:
  toppred = &predicate_typeset__ex_xextend__ts__head2_11;
  goto interrupt_11;
 }

 extend__ts__headarg_11_top: {
  q x0, x1, x2, x3;
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 extend__ts__headarg_11_clear_reason:
  reasonp = reasons;
 extend__ts__headarg_11_0:
 extend__ts__headarg_11_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_variable_3)) goto extend__ts__headarg_11_2;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset__ex_xextend__ts_16);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = makesym(atom_head);
  allocp[7] = makeint(1L);
  x2 = arg(a0, 0);
  allocp[8] = x2;
  x3 = arg(a0, 1);
  allocp[9] = x3;
  allocp[10] = a3;
  allocp[11] = a4;
  allocp[12] = a5;
  allocp[13] = a6;
  allocp[14] = a7;
  allocp[15] = a8;
  allocp[16] = a9;
  allocp[17] = a10;
  allocp[18] = (q)(struct goalrec*)&allocp[0];
  allocp[19] = (q)(&predicate_hb_xread__mode_6);
  allocp[20] = a1;
  allocp[21] = a3;
  allocp[22] = a4;
  allocp[23] = a5;
  allocp[24] = x1;
  allocp[25] = a6;
  allocp[26] = (q)(struct goalrec*)&allocp[18];
  allocp[27] = (q)(&predicate_typeset_xget_5);
  allocp[28] = a1;
  allocp[29] = a2;
  allocp[30] = x2;
  allocp[31] = x0;
  allocp[32] = a7;
  qp = (struct goalrec*)&allocp[26];
  allocp += 33;
  proceed();
 case VARREF:
  deref_and_jump(a0,extend__ts__headarg_11_1);
  *reasonp++ =  a0;
  goto extend__ts__headarg_11_2;
  };
  goto extend__ts__headarg_11_2;
 extend__ts__headarg_11_2:
  otherwise(extend__ts__headarg_11_interrupt);
  unify2(a10, a9, a8, a7);
  proceed();
 extend__ts__headarg_11_ext_interrupt:
  reasonp = 0l;
 extend__ts__headarg_11_interrupt:
  goto interrupt_11;
 }

 extend__ts_16_top: {
  q x0, x1, x2, x3, x4;
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  qp = qp->next;
 extend__ts_16_clear_reason:
  reasonp = reasons;
 extend__ts_16_0:
 extend__ts_16_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 extend__ts_16_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto extend__ts_16_5;
  x1 = cdr_of(a0);
 extend__ts_16_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto extend__ts_16_5;
 extend__ts_16_4:
  switch (ptagof(a4)) {
 case ATOMIC:
  if (isint(a4)) goto extend__ts_16_5;
  switch (symval(a4)) {
 case symval(makesym(atom_head)):
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a2;
  allocp[2] = a3;
  allocp[3] = a4;
  allocp[4] = a5;
  x2 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_tt_3);
  allocp[6] = x2;
  allocp[7] = a10;
  allocp[8] = NILATOM;
  x3 = makefunctor(&allocp[5]);
  allocp[9] = NILATOM;
  allocp[10] = x3;
  x4 = makecons(&allocp[9]);
  allocp[11] = (q)qp;
  allocp[12] = (q)(&predicate_typeset_xset_12);
  allocp[13] = a2;
  allocp[14] = a3;
  allocp[15] = a4;
  allocp[16] = a5;
  allocp[17] = a6;
  allocp[18] = a7;
  allocp[19] = x4;
  allocp[20] = makesym(atom_normal);
  allocp[21] = a12;
  allocp[22] = a13;
  allocp[23] = a14;
  allocp[24] = a15;
  qp = (struct goalrec*)&allocp[11];
  allocp += 25;
  proceed();
 case symval(makesym(atom_body)):
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a2;
  allocp[2] = a3;
  allocp[3] = a4;
  allocp[4] = a5;
  x2 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_tt_3);
  allocp[6] = x2;
  allocp[7] = a10;
  allocp[8] = NILATOM;
  x3 = makefunctor(&allocp[5]);
  allocp[9] = NILATOM;
  allocp[10] = x3;
  x4 = makecons(&allocp[9]);
  allocp[11] = (q)qp;
  allocp[12] = (q)(&predicate_typeset_xset_12);
  allocp[13] = a2;
  allocp[14] = a3;
  allocp[15] = a4;
  allocp[16] = a5;
  allocp[17] = a6;
  allocp[18] = a7;
  allocp[19] = x4;
  allocp[20] = makesym(atom_normal);
  allocp[21] = a12;
  allocp[22] = a13;
  allocp[23] = a14;
  allocp[24] = a15;
  qp = (struct goalrec*)&allocp[11];
  allocp += 25;
  proceed();
  };
  goto extend__ts_16_5;
 case VARREF:
  deref_and_jump(a4,extend__ts_16_4);
  *reasonp++ =  a4;
  goto extend__ts_16_5;
  };
  goto extend__ts_16_5;
 case VARREF:
  deref_and_jump(x1,extend__ts_16_3);
  *reasonp++ =  x1;
  goto extend__ts_16_5;
  };
  goto extend__ts_16_5;
 case VARREF:
  deref_and_jump(x0,extend__ts_16_2);
  *reasonp++ =  x0;
  goto extend__ts_16_5;
  };
  goto extend__ts_16_5;
 case VARREF:
  deref_and_jump(a0,extend__ts_16_1);
  *reasonp++ =  a0;
  goto extend__ts_16_5;
  };
  goto extend__ts_16_5;
 extend__ts_16_5:
  otherwise(extend__ts_16_interrupt);
 extend__ts_16_6:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_i)) goto extend__ts_16_10;
 extend__ts_16_7:
  switch (ptagof(a4)) {
 case ATOMIC:
  if (a4 != makesym(atom_head)) goto extend__ts_16_10;
 extend__ts_16_8:
  switch (ptagof(a5)) {
 case ATOMIC:
 extend__ts_16_9:
  if (a5 != makeint(1L)) goto extend__ts_16_10;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xset_12);
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = makesym(atom_head);
  allocp[5] = makeint(1L);
  allocp[6] = a6;
  allocp[7] = a7;
  allocp[8] = x0 = makeref(&allocp[8]);
  allocp[9] = makesym(atom_normal);
  allocp[10] = a12;
  allocp[11] = a13;
  allocp[12] = a14;
  allocp[13] = a15;
  allocp[14] = makesym(functor_goal_4);
  allocp[15] = a2;
  allocp[16] = a3;
  allocp[17] = makesym(atom_head);
  allocp[18] = makeint(1L);
  x1 = makefunctor(&allocp[14]);
  allocp[19] = makesym(functor_tt_3);
  allocp[20] = x1;
  allocp[21] = a10;
  allocp[22] = NILATOM;
  x2 = makefunctor(&allocp[19]);
  allocp[23] = NILATOM;
  allocp[24] = x2;
  x3 = makecons(&allocp[23]);
  allocp[25] = (q)(struct goalrec*)&allocp[0];
  allocp[26] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[27] = a0;
  allocp[28] = x3;
  allocp[29] = x0;
  qp = (struct goalrec*)&allocp[25];
  allocp += 30;
  proceed();
 case VARREF:
  deref_and_jump(a5,extend__ts_16_8);
  *reasonp++ =  a5;
  goto extend__ts_16_10;
  };
  goto extend__ts_16_10;
 case VARREF:
  deref_and_jump(a4,extend__ts_16_7);
  *reasonp++ =  a4;
  goto extend__ts_16_10;
  };
  goto extend__ts_16_10;
 case VARREF:
  deref_and_jump(a1,extend__ts_16_6);
  *reasonp++ =  a1;
  goto extend__ts_16_10;
  };
  goto extend__ts_16_10;
 extend__ts_16_10:
  otherwise(extend__ts_16_interrupt);
  unify2(a15, a14, a13, a12);
  proceed();
 extend__ts_16_ext_interrupt:
  reasonp = 0l;
 extend__ts_16_interrupt:
  goto interrupt_16;
 }

 extend__ts__bodys_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 extend__ts__bodys_9_clear_reason:
  reasonp = reasons;
 extend__ts__bodys_9_0:
 extend__ts__bodys_9_1:
  if (!isint(a0)) goto extend__ts__bodys_9_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,extend__ts__bodys_9_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset__ex_xextend__ts__bodys_9);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = x3 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x1;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_typeset__ex_xextend__ts__body_11);
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = a2;
  allocp[20] = x5 = makeref(&allocp[20]);
  allocp[21] = a3;
  allocp[22] = a0;
  allocp[23] = x6 = makeref(&allocp[23]);
  allocp[24] = a4;
  allocp[25] = a5;
  allocp[26] = x2;
  allocp[27] = a7;
  allocp[28] = x3;
  allocp[29] = (q)(struct goalrec*)&allocp[16];
  allocp[30] = (q)(&predicate_parse__uty_xdecode__goalcall_6);
  allocp[31] = a2;
  allocp[32] = x5;
  allocp[33] = x7 = makeref(&allocp[33]);
  allocp[34] = x4;
  allocp[35] = x8 = makeref(&allocp[35]);
  allocp[36] = x6;
  allocp[37] = (q)(struct goalrec*)&allocp[29];
  allocp[38] = (q)(&predicate_functor__table_xarg_3);
  allocp[39] = a0;
  allocp[40] = a1;
  allocp[41] = x7;
  qp = (struct goalrec*)&allocp[37];
  allocp += 42;
  proceed();
 extend__ts__bodys_9_2:
  if (a0 != makeint(0L)) goto extend__ts__bodys_9_interrupt;
  unify2(a8, a7, a6, a5);
  proceed();
 extend__ts__bodys_9_3:
  if (!isref(a0)) goto extend__ts__bodys_9_interrupt;
  deref_and_jump(a0,extend__ts__bodys_9_1);
  *reasonp++ =  a0;
  goto extend__ts__bodys_9_interrupt;
 extend__ts__bodys_9_ext_interrupt:
  reasonp = 0l;
 extend__ts__bodys_9_interrupt:
  goto interrupt_9;
 }

 extend__ts__body_11_top: {
  q x0, x1;
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 extend__ts__body_11_clear_reason:
  reasonp = reasons;
 extend__ts__body_11_0:
 extend__ts__body_11_1:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (a5 != makesym(atom_builtin)) goto extend__ts__body_11_2;
  unify2(a10, a9, a8, a7);
  proceed();
 case VARREF:
  deref_and_jump(a5,extend__ts__body_11_1);
  *reasonp++ =  a5;
  goto extend__ts__body_11_2;
  };
  goto extend__ts__body_11_2;
 extend__ts__body_11_2:
 extend__ts__body_11_3:
  if (isref(a1)) goto extend__ts__body_11_6;
 extend__ts__body_11_4:
  if (isref(a1)) goto extend__ts__body_11_5;
  if_not_equal(a1, a2, extend__ts__body_11_7);
  unify2(a10, a9, a8, a7);
  proceed();
 extend__ts__body_11_5:
  deref_and_jump(a1,extend__ts__body_11_4);
  *reasonp++ =  a1;
  goto extend__ts__body_11_7;
 extend__ts__body_11_6:
  deref_and_jump(a1,extend__ts__body_11_3);
  *reasonp++ =  a1;
  goto extend__ts__body_11_7;
 extend__ts__body_11_7:
  otherwise(extend__ts__body_11_interrupt);
 extend__ts__body_11_8:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (a5 != makesym(atom_userdef)) goto extend__ts__body_11_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset__ex_xextend__ts__body2_12);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = x0;
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = a8;
  allocp[12] = a9;
  allocp[13] = a10;
  allocp[14] = (q)(struct goalrec*)&allocp[0];
  allocp[15] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[16] = a0;
  allocp[17] = x1;
  allocp[18] = x0;
  qp = (struct goalrec*)&allocp[14];
  allocp += 19;
  proceed();
 case VARREF:
  deref_and_jump(a5,extend__ts__body_11_8);
  *reasonp++ =  a5;
  goto extend__ts__body_11_interrupt;
  };
  goto extend__ts__body_11_interrupt;
 extend__ts__body_11_ext_interrupt:
  reasonp = 0l;
 extend__ts__body_11_interrupt:
  goto interrupt_11;
 }

 extend__ts__body2_12_top: {
  q x0, x1, x2, x3, x4;
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 extend__ts__body2_12_clear_reason:
  reasonp = reasons;
 extend__ts__body2_12_0:
 extend__ts__body2_12_1:
  if (!isint(a0)) goto extend__ts__body2_12_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,extend__ts__body2_12_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset__ex_xextend__ts__body2_12);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = x2 = makeref(&allocp[10]);
  allocp[11] = a9;
  allocp[12] = x3 = makeref(&allocp[12]);
  allocp[13] = a11;
  allocp[14] = (q)(struct goalrec*)&allocp[0];
  allocp[15] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[16] = a0;
  allocp[17] = makeint(1L);
  allocp[18] = x1;
  allocp[19] = (q)(struct goalrec*)&allocp[14];
  allocp[20] = (q)(&predicate_typeset__ex_xextend__ts__bodyarg_12);
  allocp[21] = x4 = makeref(&allocp[21]);
  allocp[22] = a2;
  allocp[23] = a3;
  allocp[24] = a4;
  allocp[25] = a5;
  allocp[26] = a6;
  allocp[27] = a0;
  allocp[28] = a7;
  allocp[29] = a8;
  allocp[30] = x2;
  allocp[31] = a10;
  allocp[32] = x3;
  allocp[33] = (q)(struct goalrec*)&allocp[19];
  allocp[34] = (q)(&predicate_functor__table_xarg_3);
  allocp[35] = a0;
  allocp[36] = a1;
  allocp[37] = x4;
  qp = (struct goalrec*)&allocp[33];
  allocp += 38;
  proceed();
 extend__ts__body2_12_2:
  if (a0 != makeint(0L)) goto extend__ts__body2_12_interrupt;
  unify2(a11, a10, a9, a8);
  proceed();
 extend__ts__body2_12_3:
  if (!isref(a0)) goto extend__ts__body2_12_interrupt;
  deref_and_jump(a0,extend__ts__body2_12_1);
  *reasonp++ =  a0;
  goto extend__ts__body2_12_interrupt;
 extend__ts__body2_12_ext_interrupt:
  reasonp = 0l;
 extend__ts__body2_12_interrupt:
  goto interrupt_12;
 }

 extend__ts__bodyarg_12_top: {
  q x0, x1, x2;
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 extend__ts__bodyarg_12_clear_reason:
  reasonp = reasons;
 extend__ts__bodyarg_12_0:
 extend__ts__bodyarg_12_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_variable_3)) goto extend__ts__bodyarg_12_2;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset__ex_xextend__ts_16);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = makesym(atom_dummy);
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = makesym(atom_body);
  allocp[7] = a3;
  x1 = arg(a0, 0);
  allocp[8] = x1;
  x2 = arg(a0, 1);
  allocp[9] = x2;
  allocp[10] = a4;
  allocp[11] = a5;
  allocp[12] = a6;
  allocp[13] = a7;
  allocp[14] = a8;
  allocp[15] = a9;
  allocp[16] = a10;
  allocp[17] = a11;
  allocp[18] = (q)(struct goalrec*)&allocp[0];
  allocp[19] = (q)(&predicate_typeset_xget_5);
  allocp[20] = a1;
  allocp[21] = a2;
  allocp[22] = x1;
  allocp[23] = x0;
  allocp[24] = a8;
  qp = (struct goalrec*)&allocp[18];
  allocp += 25;
  proceed();
 case VARREF:
  deref_and_jump(a0,extend__ts__bodyarg_12_1);
  *reasonp++ =  a0;
  goto extend__ts__bodyarg_12_2;
  };
  goto extend__ts__bodyarg_12_2;
 extend__ts__bodyarg_12_2:
  otherwise(extend__ts__bodyarg_12_interrupt);
  unify2(a11, a10, a9, a8);
  proceed();
 extend__ts__bodyarg_12_ext_interrupt:
  reasonp = 0l;
 extend__ts__bodyarg_12_interrupt:
  goto interrupt_12;
 }

 analyze_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16;
  a4 = qp->args[4];
  qp = qp->next;
 analyze_5_clear_reason:
  reasonp = reasons;
 analyze_5_0:
 analyze_5_1:
  switch (ptagof(a2)) {
 case CONS:
  x0 = car_of(a2);
 analyze_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_var_6)) goto analyze_5_5;
  x1 = arg(x0, 2);
 analyze_5_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom___)) goto analyze_5_5;
  x2 = arg(x0, 3);
 analyze_5_4:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != makesym(atom___)) goto analyze_5_5;
  x4 = cdr_of(a2);
  allocp[0] = x4;
  allocp[1] = x5 = makeref(&allocp[1]);
  x3 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_typeset__ex_xanalyze_5);
  allocp[4] = a0;
  allocp[5] = a1;
  allocp[6] = x3;
  allocp[7] = a3;
  allocp[8] = a4;
  allocp[9] = makesym(functor_var_6);
  x7 = arg(x0, 0);
  allocp[10] = x7;
  x8 = arg(x0, 1);
  allocp[11] = x8;
  allocp[12] = x9 = makeref(&allocp[12]);
  allocp[13] = x10 = makeref(&allocp[13]);
  x11 = arg(x0, 4);
  allocp[14] = x11;
  x12 = arg(x0, 5);
  allocp[15] = x12;
  x6 = makefunctor(&allocp[9]);
  qp = (struct goalrec*)&allocp[2];
  allocp += 16;
  unify_value(x5, x6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_parse__uty_xget__info_7);
  x13 = arg(x0, 0);
  allocp[2] = x13;
  x14 = arg(x0, 1);
  allocp[3] = x14;
  allocp[4] = x9;
  allocp[5] = x10;
  x15 = arg(x0, 4);
  allocp[6] = x15;
  x16 = arg(x0, 5);
  allocp[7] = x16;
  allocp[8] = a0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 9;
  proceed();
 case VARREF:
  deref_and_jump(x2,analyze_5_4);
  *reasonp++ =  x2;
  goto analyze_5_5;
  };
  goto analyze_5_5;
 case VARREF:
  deref_and_jump(x1,analyze_5_3);
  *reasonp++ =  x1;
  goto analyze_5_5;
  };
  goto analyze_5_5;
 case VARREF:
  deref_and_jump(x0,analyze_5_2);
  *reasonp++ =  x0;
  goto analyze_5_5;
  };
  goto analyze_5_5;
 case ATOMIC:
  if (a2 != NILATOM) goto analyze_5_5;
  unify(a4, a3);
  proceed();
 case VARREF:
  deref_and_jump(a2,analyze_5_1);
  *reasonp++ =  a2;
  goto analyze_5_5;
  };
  goto analyze_5_5;
 analyze_5_5:
  otherwise(analyze_5_interrupt);
 analyze_5_6:
  switch (ptagof(a2)) {
 case CONS:
  x0 = car_of(a2);
 analyze_5_7:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_userdef_5)) goto analyze_5_8;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset__ex_xanalyze_5);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_analyze__type_xindirect__unify_6);
  allocp[9] = a0;
  allocp[10] = makesym(atom_expand);
  allocp[11] = x3 = makeref(&allocp[11]);
  allocp[12] = x2;
  allocp[13] = x4 = makeref(&allocp[13]);
  allocp[14] = x1;
  allocp[15] = (q)(struct goalrec*)&allocp[7];
  allocp[16] = (q)(&predicate_analyze__type_xinterclause__modules_15);
  allocp[17] = a0;
  x5 = arg(x0, 0);
  allocp[18] = x5;
  x6 = arg(x0, 1);
  allocp[19] = x6;
  x7 = arg(x0, 2);
  allocp[20] = x7;
  x8 = arg(x0, 3);
  allocp[21] = x8;
  allocp[22] = x9 = makeref(&allocp[22]);
  allocp[23] = x10 = makeref(&allocp[23]);
  x11 = arg(x0, 4);
  allocp[24] = x11;
  allocp[25] = makesym(atom_expand);
  allocp[26] = a1;
  allocp[27] = x12 = makeref(&allocp[27]);
  allocp[28] = x13 = makeref(&allocp[28]);
  allocp[29] = x3;
  x14 = cdr_of(a2);
  allocp[30] = x14;
  allocp[31] = x4;
  allocp[32] = (q)(struct goalrec*)&allocp[15];
  allocp[33] = (q)(&predicate_hb_xget__typeset_12);
  allocp[34] = a1;
  allocp[35] = x5;
  allocp[36] = x6;
  allocp[37] = x7;
  allocp[38] = x8;
  allocp[39] = x9;
  allocp[40] = x10;
  allocp[41] = x11;
  allocp[42] = a0;
  allocp[43] = makesym(atom_expand);
  allocp[44] = a3;
  allocp[45] = x13;
  qp = (struct goalrec*)&allocp[32];
  allocp += 46;
  proceed();
 case VARREF:
  deref_and_jump(x0,analyze_5_7);
  *reasonp++ =  x0;
  goto analyze_5_interrupt;
  };
  goto analyze_5_8;
 analyze_5_8:
  gblt_pfunctor(x0,x1,analyze_5_interrupt);
  if (x1 != makesym(atom_var)) goto analyze_5_interrupt;
  gblt_arity(x0,x2,analyze_5_interrupt);
 analyze_5_9:
  if (x2 != makeint(6L)) goto analyze_5_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset__ex_xanalyze_5);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = x4 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_analyze__type_xindirect__unify_6);
  allocp[9] = a0;
  allocp[10] = makesym(atom_expand);
  allocp[11] = x5 = makeref(&allocp[11]);
  allocp[12] = x4;
  allocp[13] = x6 = makeref(&allocp[13]);
  allocp[14] = x3;
  allocp[15] = (q)(struct goalrec*)&allocp[7];
  allocp[16] = (q)(&predicate_analyze__type_xanalyze__typeset_7);
  allocp[17] = x0;
  allocp[18] = a0;
  allocp[19] = makesym(atom_expand);
  allocp[20] = a3;
  allocp[21] = x5;
  x7 = cdr_of(a2);
  allocp[22] = x7;
  allocp[23] = x6;
  qp = (struct goalrec*)&allocp[15];
  allocp += 24;
  proceed();
 case VARREF:
  deref_and_jump(a2,analyze_5_6);
  *reasonp++ =  a2;
  goto analyze_5_interrupt;
  };
  goto analyze_5_interrupt;
 analyze_5_ext_interrupt:
  reasonp = 0l;
 analyze_5_interrupt:
  goto interrupt_5;
 }
 interrupt_16:
  allocp[17] = a15;
 interrupt_15:
  allocp[16] = a14;
 interrupt_14:
  allocp[15] = a13;
 interrupt_13:
  allocp[14] = a12;
 interrupt_12:
  allocp[13] = a11;
 interrupt_11:
  allocp[12] = a10;
 interrupt_10:
  allocp[11] = a9;
 interrupt_9:
  allocp[10] = a8;
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_typeset__ex);
}
