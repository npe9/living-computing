/* Compiled by KLIC compiler version 3.002 (Wed Sep 17 15:37:13 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_dt();
Const struct predicate predicate_dt_xget_4 =
   { module_dt, 0, 4 };
Const struct predicate predicate_dt_xget__deps__goals_2 =
   { module_dt, 1, 2 };
Const struct predicate predicate_dt_xget__deps__goals_4 =
   { module_dt, 2, 4 };
Const struct predicate predicate_dt_xget__guard__ds_4 =
   { module_dt, 3, 4 };
Const struct predicate predicate_dt_xget__guard__ds2_4 =
   { module_dt, 4, 4 };
Const struct predicate predicate_dt_xget__deps_4 =
   { module_dt, 5, 4 };
Const struct predicate predicate_dt_xget__deps_3 =
   { module_dt, 6, 3 };
Const struct predicate predicate_dt_xentry__data__dep_4 =
   { module_dt, 7, 4 };
Const struct predicate predicate_dt_xdeps__filter_3 =
   { module_dt, 8, 3 };
Const struct predicate predicate_dt_xentry__loops_4 =
   { module_dt, 9, 4 };
Const struct predicate predicate_dt_xdelete__ds_4 =
   { module_dt, 10, 4 };
Const struct predicate predicate_dt_xentry_5 =
   { module_dt, 11, 5 };
Const struct predicate predicate_dt_xset_5 =
   { module_dt, 12, 5 };
Const struct predicate predicate_dt_xset__entry_6 =
   { module_dt, 13, 6 };
Const struct predicate predicate_dt_xset__dep_4 =
   { module_dt, 14, 4 };
extern Const struct predicate predicate_list_xor__unique_3;
extern Const struct predicate predicate_list_xdelete__elements_3;
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_xsetarg_4;
extern Const struct predicate predicate_functor__table_xfunctor_3;

module module_dt(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  q a0, a1, a2, a3, a4, a5;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, get_4_top);
    case_pred(1, get__deps__goals_2_top);
    case_pred(2, get__deps__goals_4_top);
    case_pred(3, get__guard__ds_4_top);
    case_pred(4, get__guard__ds2_4_top);
    case_pred(5, get__deps_4_top);
    case_pred(6, get__deps_3_top);
    case_pred(7, entry__data__dep_4_top);
    case_pred(8, deps__filter_3_top);
    case_pred(9, entry__loops_4_top);
    case_pred(10, delete__ds_4_top);
    case_pred(11, entry_5_top);
    case_pred(12, set_5_top);
    case_pred(13, set__entry_6_top);
    last_case_pred(14, set__dep_4_top);
  }

 get_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 get_4_clear_reason:
  reasonp = reasons;
 get_4_0:
 get_4_1:
  switch (ptagof(a3)) {
 case CONS:
  x0 = car_of(a3);
 get_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto get_4_7;
  x1 = arg(x0, 0);
 get_4_3:
  if (isref(x1)) goto get_4_6;
 get_4_4:
  if (isref(x1)) goto get_4_5;
  if_not_equal(x1, a0, get_4_7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_list_xor__unique_3);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_dt_xget__deps__goals_2);
  allocp[7] = x4 = makeref(&allocp[7]);
  allocp[8] = x3;
  allocp[9] = (q)(struct goalrec*)&allocp[5];
  allocp[10] = (q)(&predicate_dt_xget__deps__goals_2);
  allocp[11] = x5 = makeref(&allocp[11]);
  allocp[12] = x2;
  allocp[13] = makesym(functor_deps_2);
  allocp[14] = x5;
  allocp[15] = x4;
  x6 = makefunctor(&allocp[13]);
  allocp[16] = (q)(struct goalrec*)&allocp[9];
  allocp[17] = (q)(&predicate_functor__table_xarg_3);
  allocp[18] = a1;
  x7 = arg(x0, 1);
  allocp[19] = x7;
  allocp[20] = x6;
  qp = (struct goalrec*)&allocp[16];
  allocp += 21;
  proceed();
 get_4_5:
  deref_and_jump(x1,get_4_4);
  *reasonp++ =  x1;
  goto get_4_7;
 get_4_6:
  deref_and_jump(x1,get_4_3);
  *reasonp++ =  x1;
  goto get_4_7;
 case VARREF:
  deref_and_jump(x0,get_4_2);
  *reasonp++ =  x0;
  goto get_4_7;
  };
  goto get_4_7;
 case VARREF:
  deref_and_jump(a3,get_4_1);
  *reasonp++ =  a3;
  goto get_4_7;
  };
  goto get_4_7;
 get_4_7:
  otherwise(get_4_interrupt);
 get_4_8:
  switch (ptagof(a3)) {
 case CONS:
  a3 = cdr_of(a3);
  execute(get_4_0);
  goto get_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a3,get_4_8);
  *reasonp++ =  a3;
  goto get_4_interrupt;
  };
  goto get_4_interrupt;
 get_4_ext_interrupt:
  reasonp = 0l;
 get_4_interrupt:
  goto interrupt_4;
 }

 get__deps__goals_2_top: {
  q x0, x1;
  qp = qp->next;
 get__deps__goals_2_clear_reason:
  reasonp = reasons;
 get__deps__goals_2_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dt_xget__deps__goals_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = NILATOM;
  allocp[5] = a1;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[8] = a0;
  allocp[9] = x1 = makeref(&allocp[9]);
  allocp[10] = x0;
  qp = (struct goalrec*)&allocp[6];
  allocp += 11;
  proceed();
 get__deps__goals_2_ext_interrupt:
  reasonp = 0l;
 get__deps__goals_2_interrupt:
  goto interrupt_2;
 }

 get__deps__goals_4_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 get__deps__goals_4_clear_reason:
  reasonp = reasons;
 get__deps__goals_4_0:
 get__deps__goals_4_1:
  if (!isint(a0)) goto get__deps__goals_4_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,get__deps__goals_4_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dt_xget__deps__goals_4);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x1;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_list_xor__unique_3);
  allocp[13] = a2;
  allocp[14] = x3 = makeref(&allocp[14]);
  allocp[15] = x2;
  allocp[16] = makesym(functor_dep_2);
  allocp[17] = x5 = makeref(&allocp[17]);
  allocp[18] = x3;
  x4 = makefunctor(&allocp[16]);
  allocp[19] = (q)(struct goalrec*)&allocp[11];
  allocp[20] = (q)(&predicate_functor__table_xarg_3);
  allocp[21] = a0;
  allocp[22] = a1;
  allocp[23] = x4;
  qp = (struct goalrec*)&allocp[19];
  allocp += 24;
  proceed();
 get__deps__goals_4_2:
  if (a0 != makeint(0L)) goto get__deps__goals_4_interrupt;
  unify(a3, a2);
  proceed();
 get__deps__goals_4_3:
  if (!isref(a0)) goto get__deps__goals_4_interrupt;
  deref_and_jump(a0,get__deps__goals_4_1);
  *reasonp++ =  a0;
  goto get__deps__goals_4_interrupt;
 get__deps__goals_4_ext_interrupt:
  reasonp = 0l;
 get__deps__goals_4_interrupt:
  goto interrupt_4;
 }

 get__guard__ds_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 get__guard__ds_4_clear_reason:
  reasonp = reasons;
 get__guard__ds_4_0:
 get__guard__ds_4_1:
  switch (ptagof(a3)) {
 case CONS:
  x0 = car_of(a3);
 get__guard__ds_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto get__guard__ds_4_7;
  x1 = arg(x0, 0);
 get__guard__ds_4_3:
  if (isref(x1)) goto get__guard__ds_4_6;
 get__guard__ds_4_4:
  if (isref(x1)) goto get__guard__ds_4_5;
  if_not_equal(x1, a0, get__guard__ds_4_7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dt_xget__guard__ds2_4);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = NILATOM;
  allocp[5] = a2;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[8] = x3;
  allocp[9] = x4 = makeref(&allocp[9]);
  allocp[10] = x2;
  allocp[11] = makesym(functor_deps_2);
  allocp[12] = x3;
  allocp[13] = x6 = makeref(&allocp[13]);
  x5 = makefunctor(&allocp[11]);
  allocp[14] = (q)(struct goalrec*)&allocp[6];
  allocp[15] = (q)(&predicate_functor__table_xarg_3);
  allocp[16] = a1;
  x7 = arg(x0, 1);
  allocp[17] = x7;
  allocp[18] = x5;
  qp = (struct goalrec*)&allocp[14];
  allocp += 19;
  proceed();
 get__guard__ds_4_5:
  deref_and_jump(x1,get__guard__ds_4_4);
  *reasonp++ =  x1;
  goto get__guard__ds_4_7;
 get__guard__ds_4_6:
  deref_and_jump(x1,get__guard__ds_4_3);
  *reasonp++ =  x1;
  goto get__guard__ds_4_7;
 case VARREF:
  deref_and_jump(x0,get__guard__ds_4_2);
  *reasonp++ =  x0;
  goto get__guard__ds_4_7;
  };
  goto get__guard__ds_4_7;
 case VARREF:
  deref_and_jump(a3,get__guard__ds_4_1);
  *reasonp++ =  a3;
  goto get__guard__ds_4_7;
  };
  goto get__guard__ds_4_7;
 get__guard__ds_4_7:
  otherwise(get__guard__ds_4_interrupt);
 get__guard__ds_4_8:
  switch (ptagof(a3)) {
 case CONS:
  a3 = cdr_of(a3);
  execute(get__guard__ds_4_0);
  goto get__guard__ds_4_ext_interrupt;
 case ATOMIC:
  if (a3 != NILATOM) goto get__guard__ds_4_interrupt;
  x0 = makesym(atom_error);
  x1 = makesym(atom_get__guard__ds);
  unify(x0, x1);
  proceed();
 case VARREF:
  deref_and_jump(a3,get__guard__ds_4_8);
  *reasonp++ =  a3;
  goto get__guard__ds_4_interrupt;
  };
  goto get__guard__ds_4_interrupt;
 get__guard__ds_4_ext_interrupt:
  reasonp = 0l;
 get__guard__ds_4_interrupt:
  goto interrupt_4;
 }

 get__guard__ds2_4_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 get__guard__ds2_4_clear_reason:
  reasonp = reasons;
 get__guard__ds2_4_0:
 get__guard__ds2_4_1:
  if (!isint(a0)) goto get__guard__ds2_4_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,get__guard__ds2_4_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dt_xget__guard__ds2_4);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x1;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_list_xor__unique_3);
  allocp[13] = a2;
  allocp[14] = x3 = makeref(&allocp[14]);
  allocp[15] = x2;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_list_xor__unique_3);
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = x5 = makeref(&allocp[19]);
  allocp[20] = x3;
  allocp[21] = makesym(functor_dep_2);
  allocp[22] = x4;
  allocp[23] = x5;
  x6 = makefunctor(&allocp[21]);
  allocp[24] = (q)(struct goalrec*)&allocp[16];
  allocp[25] = (q)(&predicate_functor__table_xarg_3);
  allocp[26] = a0;
  allocp[27] = a1;
  allocp[28] = x6;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 get__guard__ds2_4_2:
  if (a0 != makeint(0L)) goto get__guard__ds2_4_interrupt;
  unify(a3, a2);
  proceed();
 get__guard__ds2_4_3:
  if (!isref(a0)) goto get__guard__ds2_4_interrupt;
  deref_and_jump(a0,get__guard__ds2_4_1);
  *reasonp++ =  a0;
  goto get__guard__ds2_4_interrupt;
 get__guard__ds2_4_ext_interrupt:
  reasonp = 0l;
 get__guard__ds2_4_interrupt:
  goto interrupt_4;
 }

 get__deps_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 get__deps_4_clear_reason:
  reasonp = reasons;
 get__deps_4_0:
 get__deps_4_1:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_goal_4)) goto get__deps_4_15;
  x0 = arg(a1, 2);
 get__deps_4_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (isint(x0)) goto get__deps_4_15;
  switch (symval(x0)) {
 case symval(makesym(atom_guard)):
 get__deps_4_3:
  switch (ptagof(a3)) {
 case CONS:
  x1 = car_of(a3);
 get__deps_4_4:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_module_2)) goto get__deps_4_15;
  x2 = arg(x1, 0);
 get__deps_4_5:
  if (isref(x2)) goto get__deps_4_8;
 get__deps_4_6:
  if (isref(x2)) goto get__deps_4_7;
  x3 = arg(a1, 0);
  if_not_equal(x2, x3, get__deps_4_15);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dt_xget__deps_3);
  allocp[2] = a0;
  allocp[3] = x4 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  x5 = arg(a1, 3);
  allocp[7] = x5;
  allocp[8] = x6 = makeref(&allocp[8]);
  allocp[9] = x4;
  allocp[10] = makesym(functor_deps_2);
  allocp[11] = x6;
  allocp[12] = x8 = makeref(&allocp[12]);
  x7 = makefunctor(&allocp[10]);
  allocp[13] = (q)(struct goalrec*)&allocp[5];
  allocp[14] = (q)(&predicate_functor__table_xarg_3);
  x9 = arg(a1, 1);
  allocp[15] = x9;
  x10 = arg(x1, 1);
  allocp[16] = x10;
  allocp[17] = x7;
  qp = (struct goalrec*)&allocp[13];
  allocp += 18;
  proceed();
 get__deps_4_7:
  deref_and_jump(x2,get__deps_4_6);
  *reasonp++ =  x2;
  goto get__deps_4_15;
 get__deps_4_8:
  deref_and_jump(x2,get__deps_4_5);
  *reasonp++ =  x2;
  goto get__deps_4_15;
 case VARREF:
  deref_and_jump(x1,get__deps_4_4);
  *reasonp++ =  x1;
  goto get__deps_4_15;
  };
  goto get__deps_4_15;
 case VARREF:
  deref_and_jump(a3,get__deps_4_3);
  *reasonp++ =  a3;
  goto get__deps_4_15;
  };
  goto get__deps_4_15;
 case symval(makesym(atom_body)):
 get__deps_4_9:
  switch (ptagof(a3)) {
 case CONS:
  x1 = car_of(a3);
 get__deps_4_10:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_module_2)) goto get__deps_4_15;
  x2 = arg(x1, 0);
 get__deps_4_11:
  if (isref(x2)) goto get__deps_4_14;
 get__deps_4_12:
  if (isref(x2)) goto get__deps_4_13;
  x3 = arg(a1, 0);
  if_not_equal(x2, x3, get__deps_4_15);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dt_xget__deps_3);
  allocp[2] = a0;
  allocp[3] = x4 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  x5 = arg(a1, 3);
  allocp[7] = x5;
  allocp[8] = x6 = makeref(&allocp[8]);
  allocp[9] = x4;
  allocp[10] = makesym(functor_deps_2);
  allocp[11] = x8 = makeref(&allocp[11]);
  allocp[12] = x6;
  x7 = makefunctor(&allocp[10]);
  allocp[13] = (q)(struct goalrec*)&allocp[5];
  allocp[14] = (q)(&predicate_functor__table_xarg_3);
  x9 = arg(a1, 1);
  allocp[15] = x9;
  x10 = arg(x1, 1);
  allocp[16] = x10;
  allocp[17] = x7;
  qp = (struct goalrec*)&allocp[13];
  allocp += 18;
  proceed();
 get__deps_4_13:
  deref_and_jump(x2,get__deps_4_12);
  *reasonp++ =  x2;
  goto get__deps_4_15;
 get__deps_4_14:
  deref_and_jump(x2,get__deps_4_11);
  *reasonp++ =  x2;
  goto get__deps_4_15;
 case VARREF:
  deref_and_jump(x1,get__deps_4_10);
  *reasonp++ =  x1;
  goto get__deps_4_15;
  };
  goto get__deps_4_15;
 case VARREF:
  deref_and_jump(a3,get__deps_4_9);
  *reasonp++ =  a3;
  goto get__deps_4_15;
  };
  goto get__deps_4_15;
  };
  goto get__deps_4_15;
 case VARREF:
  deref_and_jump(x0,get__deps_4_2);
  *reasonp++ =  x0;
  goto get__deps_4_15;
  };
  goto get__deps_4_15;
 case VARREF:
  deref_and_jump(a1,get__deps_4_1);
  *reasonp++ =  a1;
  goto get__deps_4_15;
  };
  goto get__deps_4_15;
 get__deps_4_15:
  otherwise(get__deps_4_interrupt);
 get__deps_4_16:
  switch (ptagof(a3)) {
 case CONS:
  a3 = cdr_of(a3);
  execute(get__deps_4_0);
  goto get__deps_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a3,get__deps_4_16);
  *reasonp++ =  a3;
  goto get__deps_4_interrupt;
  };
  goto get__deps_4_interrupt;
 get__deps_4_ext_interrupt:
  reasonp = 0l;
 get__deps_4_interrupt:
  toppred = &predicate_dt_xget__deps_4;
  goto interrupt_4;
 }

 get__deps_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 get__deps_3_clear_reason:
  reasonp = reasons;
 get__deps_3_0:
 get__deps_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto get__deps_3_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_control)):
 get__deps_3_2:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_dep_2)) goto get__deps_3_interrupt;
  x0 = arg(a1, 0);
  unify(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,get__deps_3_2);
  *reasonp++ =  a1;
  goto get__deps_3_interrupt;
  };
  goto get__deps_3_interrupt;
 case symval(makesym(atom_data)):
 get__deps_3_3:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_dep_2)) goto get__deps_3_interrupt;
  x0 = arg(a1, 1);
  unify(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,get__deps_3_3);
  *reasonp++ =  a1;
  goto get__deps_3_interrupt;
  };
  goto get__deps_3_interrupt;
 case symval(makesym(atom_execute)):
 get__deps_3_4:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_dep_2)) goto get__deps_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_list_xor__unique_3);
  x0 = arg(a1, 0);
  allocp[2] = x0;
  x1 = arg(a1, 1);
  allocp[3] = x1;
  allocp[4] = a2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case VARREF:
  deref_and_jump(a1,get__deps_3_4);
  *reasonp++ =  a1;
  goto get__deps_3_interrupt;
  };
  goto get__deps_3_interrupt;
  };
  goto get__deps_3_interrupt;
 case VARREF:
  deref_and_jump(a0,get__deps_3_1);
  *reasonp++ =  a0;
  goto get__deps_3_interrupt;
  };
  goto get__deps_3_interrupt;
 get__deps_3_ext_interrupt:
  reasonp = 0l;
 get__deps_3_interrupt:
  goto interrupt_3;
 }

 entry__data__dep_4_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 entry__data__dep_4_clear_reason:
  reasonp = reasons;
 entry__data__dep_4_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dt_xentry__loops_4);
  allocp[2] = a0;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_dt_xentry_5);
  allocp[8] = makesym(atom_data);
  allocp[9] = a0;
  allocp[10] = x2 = makeref(&allocp[10]);
  allocp[11] = a2;
  allocp[12] = x1;
  a0 = a1;
  a1 = x0;
  a2 = x2;
  qp = (struct goalrec*)&allocp[6];
  allocp += 13;
  execute(deps__filter_3_0);
  goto deps__filter_3_ext_interrupt;
 entry__data__dep_4_ext_interrupt:
  reasonp = 0l;
 entry__data__dep_4_interrupt:
  toppred = &predicate_dt_xentry__data__dep_4;
  goto interrupt_4;
 }

 deps__filter_3_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  qp = qp->next;
 deps__filter_3_clear_reason:
  reasonp = reasons;
 deps__filter_3_0:
 deps__filter_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 deps__filter_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_goal_4)) goto deps__filter_3_3;
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = x0;
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x1);
  a0 = cdr_of(a0);
  a2 = x2;
  execute(deps__filter_3_0);
  goto deps__filter_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,deps__filter_3_2);
  *reasonp++ =  x0;
  goto deps__filter_3_interrupt;
  };
  goto deps__filter_3_3;
 deps__filter_3_3:
  gblt_pfunctor(x0,x1,deps__filter_3_interrupt);
  gblt_arity(x0,x2,deps__filter_3_interrupt);
 deps__filter_3_4:
  if (x2 != makeint(3L)) goto deps__filter_3_interrupt;
  allocp[0] = x4 = makeref(&allocp[0]);
  allocp[1] = x0;
  x3 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x3);
  a0 = cdr_of(a0);
  a1 = x4;
  execute(deps__filter_3_0);
  goto deps__filter_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto deps__filter_3_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  x1 = NILATOM;
  unify_value(a2, x1);
  proceed();
 case VARREF:
  deref_and_jump(a0,deps__filter_3_1);
  *reasonp++ =  a0;
  goto deps__filter_3_interrupt;
  };
  goto deps__filter_3_interrupt;
 deps__filter_3_ext_interrupt:
  reasonp = 0l;
 deps__filter_3_interrupt:
  toppred = &predicate_dt_xdeps__filter_3;
  goto interrupt_3;
 }

 entry__loops_4_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 entry__loops_4_clear_reason:
  reasonp = reasons;
 entry__loops_4_0:
 entry__loops_4_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 entry__loops_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_entry_3:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dt_xentry__loops_4);
  allocp[2] = a0;
  x1 = cdr_of(a1);
  allocp[3] = x1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_dt_xdelete__ds_4);
  allocp[8] = a0;
  x3 = arg(x0, 2);
  allocp[9] = x3;
  allocp[10] = x4 = makeref(&allocp[10]);
  allocp[11] = x2;
  a0 = arg(x0, 0);
  a1 = x3;
  a3 = x4;
  qp = (struct goalrec*)&allocp[6];
  allocp += 12;
  execute(entry__data__dep_4_0);
  goto entry__data__dep_4_ext_interrupt;
 case functor_recursive_3:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dt_xentry__loops_4);
  allocp[2] = a0;
  x1 = cdr_of(a1);
  allocp[3] = x1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_dt_xdelete__ds_4);
  allocp[8] = a0;
  x3 = arg(x0, 2);
  allocp[9] = x3;
  allocp[10] = x4 = makeref(&allocp[10]);
  allocp[11] = x2;
  a0 = arg(x0, 0);
  a1 = x3;
  a3 = x4;
  qp = (struct goalrec*)&allocp[6];
  allocp += 12;
  execute(entry__data__dep_4_0);
  goto entry__data__dep_4_ext_interrupt;
 case functor_shared_3:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dt_xentry__loops_4);
  allocp[2] = a0;
  x1 = cdr_of(a1);
  allocp[3] = x1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_dt_xdelete__ds_4);
  allocp[8] = a0;
  x3 = arg(x0, 2);
  allocp[9] = x3;
  allocp[10] = x4 = makeref(&allocp[10]);
  allocp[11] = x2;
  a0 = arg(x0, 0);
  a1 = x3;
  a3 = x4;
  qp = (struct goalrec*)&allocp[6];
  allocp += 12;
  execute(entry__data__dep_4_0);
  goto entry__data__dep_4_ext_interrupt;
  };
  goto entry__loops_4_interrupt;
 case VARREF:
  deref_and_jump(x0,entry__loops_4_2);
  *reasonp++ =  x0;
  goto entry__loops_4_interrupt;
  };
  goto entry__loops_4_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto entry__loops_4_interrupt;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a1,entry__loops_4_1);
  *reasonp++ =  a1;
  goto entry__loops_4_interrupt;
  };
  goto entry__loops_4_interrupt;
 entry__loops_4_ext_interrupt:
  reasonp = 0l;
 entry__loops_4_interrupt:
  goto interrupt_4;
 }

 delete__ds_4_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 delete__ds_4_clear_reason:
  reasonp = reasons;
 delete__ds_4_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dt_xset_5);
  allocp[2] = makesym(atom_data);
  allocp[3] = a0;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_list_xdelete__elements_3);
  allocp[9] = a1;
  allocp[10] = x1 = makeref(&allocp[10]);
  allocp[11] = x0;
  a1 = a0;
  a3 = a2;
  a2 = x1;
  a0 = makesym(atom_data);
  qp = (struct goalrec*)&allocp[7];
  allocp += 12;
  execute(get__deps_4_0);
  goto get__deps_4_ext_interrupt;
 delete__ds_4_ext_interrupt:
  reasonp = 0l;
 delete__ds_4_interrupt:
  goto interrupt_4;
 }

 entry_5_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 entry_5_clear_reason:
  reasonp = reasons;
 entry_5_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dt_xset_5);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_list_xor__unique_3);
  allocp[9] = x1 = makeref(&allocp[9]);
  allocp[10] = a2;
  allocp[11] = x0;
  a2 = x1;
  qp = (struct goalrec*)&allocp[7];
  allocp += 12;
  execute(get__deps_4_0);
  goto get__deps_4_ext_interrupt;
 entry_5_ext_interrupt:
  reasonp = 0l;
 entry_5_interrupt:
  goto interrupt_5;
 }

 set_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 set_5_clear_reason:
  reasonp = reasons;
 set_5_0:
 set_5_1:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_goal_4)) goto set_5_8;
 set_5_2:
  switch (ptagof(a3)) {
 case CONS:
  x0 = car_of(a3);
 set_5_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto set_5_8;
  x1 = arg(x0, 0);
 set_5_4:
  if (isref(x1)) goto set_5_7;
 set_5_5:
  if (isref(x1)) goto set_5_6;
  x2 = arg(a1, 0);
  if_not_equal(x1, x2, set_5_8);
  allocp[0] = makesym(functor_module_2);
  allocp[1] = x2;
  allocp[2] = x4 = makeref(&allocp[2]);
  x3 = makefunctor(&allocp[0]);
  x6 = cdr_of(a3);
  allocp[3] = x6;
  allocp[4] = x3;
  x5 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a4, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  x7 = arg(a1, 1);
  allocp[2] = x7;
  x8 = arg(x0, 1);
  allocp[3] = x8;
  allocp[4] = x9 = makeref(&allocp[4]);
  allocp[5] = x4;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_dt_xset__entry_6);
  allocp[8] = a0;
  x10 = arg(a1, 2);
  allocp[9] = x10;
  x11 = arg(a1, 3);
  allocp[10] = x11;
  allocp[11] = a2;
  allocp[12] = x12 = makeref(&allocp[12]);
  allocp[13] = x9;
  allocp[14] = (q)(struct goalrec*)&allocp[6];
  allocp[15] = (q)(&predicate_functor__table_xarg_3);
  allocp[16] = x7;
  allocp[17] = x8;
  allocp[18] = x12;
  qp = (struct goalrec*)&allocp[14];
  allocp += 19;
  proceed();
 set_5_6:
  deref_and_jump(x1,set_5_5);
  *reasonp++ =  x1;
  goto set_5_8;
 set_5_7:
  deref_and_jump(x1,set_5_4);
  *reasonp++ =  x1;
  goto set_5_8;
 case VARREF:
  deref_and_jump(x0,set_5_3);
  *reasonp++ =  x0;
  goto set_5_8;
  };
  goto set_5_8;
 case VARREF:
  deref_and_jump(a3,set_5_2);
  *reasonp++ =  a3;
  goto set_5_8;
  };
  goto set_5_8;
 case VARREF:
  deref_and_jump(a1,set_5_1);
  *reasonp++ =  a1;
  goto set_5_8;
  };
  goto set_5_8;
 set_5_8:
  otherwise(set_5_interrupt);
 set_5_9:
  switch (ptagof(a3)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a3);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a4, x0);
  a3 = cdr_of(a3);
  a4 = x1;
  execute(set_5_0);
  goto set_5_ext_interrupt;
 case ATOMIC:
  if (a3 != NILATOM) goto set_5_interrupt;
  unify_value(a4, a3);
  x0 = makesym(atom_error);
  x1 = makesym(atom_set);
  unify(x0, x1);
  proceed();
 case VARREF:
  deref_and_jump(a3,set_5_9);
  *reasonp++ =  a3;
  goto set_5_interrupt;
  };
  goto set_5_interrupt;
 set_5_ext_interrupt:
  reasonp = 0l;
 set_5_interrupt:
  goto interrupt_5;
 }

 set__entry_6_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 set__entry_6_clear_reason:
  reasonp = reasons;
 set__entry_6_0:
 set__entry_6_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (isint(a1)) goto set__entry_6_interrupt;
  switch (symval(a1)) {
 case symval(makesym(atom_guard)):
  allocp[0] = makesym(functor_deps_2);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  x0 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a4, x0);
  allocp[0] = makesym(functor_deps_2);
  allocp[1] = x4 = makeref(&allocp[1]);
  allocp[2] = x2;
  x3 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a5, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = a2;
  allocp[3] = x1;
  allocp[4] = x5 = makeref(&allocp[4]);
  allocp[5] = x4;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_dt_xset__dep_4);
  allocp[8] = a0;
  allocp[9] = a3;
  allocp[10] = x6 = makeref(&allocp[10]);
  allocp[11] = x5;
  allocp[12] = (q)(struct goalrec*)&allocp[6];
  allocp[13] = (q)(&predicate_functor__table_xarg_3);
  allocp[14] = a2;
  allocp[15] = x1;
  allocp[16] = x6;
  qp = (struct goalrec*)&allocp[12];
  allocp += 17;
  proceed();
 case symval(makesym(atom_body)):
  allocp[0] = makesym(functor_deps_2);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  x0 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a4, x0);
  allocp[0] = makesym(functor_deps_2);
  allocp[1] = x1;
  allocp[2] = x4 = makeref(&allocp[2]);
  x3 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a5, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = a2;
  allocp[3] = x2;
  allocp[4] = x5 = makeref(&allocp[4]);
  allocp[5] = x4;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_dt_xset__dep_4);
  allocp[8] = a0;
  allocp[9] = a3;
  allocp[10] = x6 = makeref(&allocp[10]);
  allocp[11] = x5;
  allocp[12] = (q)(struct goalrec*)&allocp[6];
  allocp[13] = (q)(&predicate_functor__table_xarg_3);
  allocp[14] = a2;
  allocp[15] = x2;
  allocp[16] = x6;
  qp = (struct goalrec*)&allocp[12];
  allocp += 17;
  proceed();
  };
  goto set__entry_6_interrupt;
 case VARREF:
  deref_and_jump(a1,set__entry_6_1);
  *reasonp++ =  a1;
  goto set__entry_6_interrupt;
  };
  goto set__entry_6_interrupt;
 set__entry_6_ext_interrupt:
  reasonp = 0l;
 set__entry_6_interrupt:
  goto interrupt_6;
 }

 set__dep_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 set__dep_4_clear_reason:
  reasonp = reasons;
 set__dep_4_0:
 set__dep_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto set__dep_4_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_control)):
  allocp[0] = makesym(functor_dep_2);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  x0 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a2, x0);
  allocp[0] = makesym(functor_dep_2);
  allocp[1] = a1;
  allocp[2] = x2;
  x3 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a3, x3);
  proceed();
 case symval(makesym(atom_data)):
  allocp[0] = makesym(functor_dep_2);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  x0 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a2, x0);
  allocp[0] = makesym(functor_dep_2);
  allocp[1] = x1;
  allocp[2] = a1;
  x3 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a3, x3);
  proceed();
  };
  goto set__dep_4_interrupt;
 case VARREF:
  deref_and_jump(a0,set__dep_4_1);
  *reasonp++ =  a0;
  goto set__dep_4_interrupt;
  };
  goto set__dep_4_interrupt;
 set__dep_4_ext_interrupt:
  reasonp = 0l;
 set__dep_4_interrupt:
  goto interrupt_4;
 }
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_dt);
}
