/* Compiled by KLIC compiler version 3.002 (Wed Sep 17 15:37:13 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_list();
Const struct predicate predicate_list_xcount__element_2 =
   { module_list, 0, 2 };
Const struct predicate predicate_list_xcount__element1_3 =
   { module_list, 1, 3 };
Const struct predicate predicate_list_xappend_3 =
   { module_list, 2, 3 };
Const struct predicate predicate_list_xdoublelist2list_2 =
   { module_list, 3, 2 };
Const struct predicate predicate_list_xnth__element_3 =
   { module_list, 4, 3 };
Const struct predicate predicate_list_xsplit__nth_4 =
   { module_list, 5, 4 };
Const struct predicate predicate_list_xinsert__nth__element_4 =
   { module_list, 6, 4 };
Const struct predicate predicate_list_xmake__unique_2 =
   { module_list, 7, 2 };
Const struct predicate predicate_list_xmake__unique1_3 =
   { module_list, 8, 3 };
Const struct predicate predicate_list_xdelete__elements_3 =
   { module_list, 9, 3 };
Const struct predicate predicate_list_xdelete__element_3 =
   { module_list, 10, 3 };
Const struct predicate predicate_list_xor__unique_3 =
   { module_list, 11, 3 };
Const struct predicate predicate_list_xand__unique_3 =
   { module_list, 12, 3 };
Const struct predicate predicate_list_xand__unique1_4 =
   { module_list, 13, 4 };
Const struct predicate predicate_list_xentry__unique__data_3 =
   { module_list, 14, 3 };
Const struct predicate predicate_list_xcheck__include_3 =
   { module_list, 15, 3 };
Const struct predicate predicate_list_xcheck__subset_3 =
   { module_list, 16, 3 };
Const struct predicate predicate_list_xcheck__subset1_4 =
   { module_list, 17, 4 };
Const struct predicate predicate_list_xcheck__elements_3 =
   { module_list, 18, 3 };
Const struct predicate predicate_list_xcheck__elements1_4 =
   { module_list, 19, 4 };
Const struct predicate predicate_list_xdelete__incomplete__element_3 =
   { module_list, 20, 3 };
Const struct predicate predicate_list_xdelete__incomplete__element1_5 =
   { module_list, 21, 5 };
Const struct predicate predicate_list_xdelete__incomplete__element__match_3 =
   { module_list, 22, 3 };
Const struct predicate predicate_list_xdelete__incomplete__element__match__args_4 =
   { module_list, 23, 4 };
Const struct predicate predicate_list_xdelete__incomplete__element__match__args1_5 =
   { module_list, 24, 5 };
Const struct predicate predicate_list_xsort__int__up_2 =
   { module_list, 25, 2 };
Const struct predicate predicate_list_xsort__int__split_4 =
   { module_list, 26, 4 };
Const struct predicate predicate_list_xsplit_4 =
   { module_list, 27, 4 };

module module_list(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  q a0, a1, a2, a3, a4;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, count__element_2_top);
    case_pred(1, count__element1_3_top);
    case_pred(2, append_3_top);
    case_pred(3, doublelist2list_2_top);
    case_pred(4, nth__element_3_top);
    case_pred(5, split__nth_4_top);
    case_pred(6, insert__nth__element_4_top);
    case_pred(7, make__unique_2_top);
    case_pred(8, make__unique1_3_top);
    case_pred(9, delete__elements_3_top);
    case_pred(10, delete__element_3_top);
    case_pred(11, or__unique_3_top);
    case_pred(12, and__unique_3_top);
    case_pred(13, and__unique1_4_top);
    case_pred(14, entry__unique__data_3_top);
    case_pred(15, check__include_3_top);
    case_pred(16, check__subset_3_top);
    case_pred(17, check__subset1_4_top);
    case_pred(18, check__elements_3_top);
    case_pred(19, check__elements1_4_top);
    case_pred(20, delete__incomplete__element_3_top);
    case_pred(21, delete__incomplete__element1_5_top);
    case_pred(22, delete__incomplete__element__match_3_top);
    case_pred(23, delete__incomplete__element__match__args_4_top);
    case_pred(24, delete__incomplete__element__match__args1_5_top);
    case_pred(25, sort__int__up_2_top);
    case_pred(26, sort__int__split_4_top);
    last_case_pred(27, split_4_top);
  }

 count__element_2_top: {
  qp = qp->next;
 count__element_2_clear_reason:
  reasonp = reasons;
 count__element_2_0:
  a2 = a1;
  a1 = makeint(0L);
  execute(count__element1_3_0);
  goto count__element1_3_ext_interrupt;
 count__element_2_ext_interrupt:
  reasonp = 0l;
 count__element_2_interrupt:
  goto interrupt_2;
 }

 count__element1_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 count__element1_3_clear_reason:
  reasonp = reasons;
 count__element1_3_0:
 count__element1_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = makeint(1L);
  bblt_add_no_check_y(a1,x0,x1);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(count__element1_3_0);
  goto count__element1_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto count__element1_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,count__element1_3_1);
  *reasonp++ =  a0;
  goto count__element1_3_interrupt;
  };
  goto count__element1_3_interrupt;
 count__element1_3_ext_interrupt:
  reasonp = 0l;
 count__element1_3_interrupt:
  toppred = &predicate_list_xcount__element1_3;
  goto interrupt_3;
 }

 append_3_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  qp = qp->next;
 append_3_clear_reason:
  reasonp = reasons;
 append_3_0:
 append_3_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  a0 = cdr_of(a0);
  a2 = x1;
  execute(append_3_0);
  goto append_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto append_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,append_3_1);
  *reasonp++ =  a0;
  goto append_3_interrupt;
  };
  goto append_3_interrupt;
 append_3_ext_interrupt:
  reasonp = 0l;
 append_3_interrupt:
  toppred = &predicate_list_xappend_3;
  goto interrupt_3;
 }

 doublelist2list_2_top: {
  q x0, x1;
  qp = qp->next;
 doublelist2list_2_clear_reason:
  reasonp = reasons;
 doublelist2list_2_0:
 doublelist2list_2_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_list_xdoublelist2list_2);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  a0 = car_of(a0);
  a2 = a1;
  a1 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  execute(append_3_0);
  goto append_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto doublelist2list_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,doublelist2list_2_1);
  *reasonp++ =  a0;
  goto doublelist2list_2_interrupt;
  };
  goto doublelist2list_2_interrupt;
 doublelist2list_2_ext_interrupt:
  reasonp = 0l;
 doublelist2list_2_interrupt:
  goto interrupt_2;
 }

 nth__element_3_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  qp = qp->next;
 nth__element_3_clear_reason:
  reasonp = reasons;
 nth__element_3_0:
 nth__element_3_1:
  switch (ptagof(a1)) {
 case CONS:
 nth__element_3_2:
  if (!isint(a0)) goto nth__element_3_4;
  x0 = makeint(1L);
  gblt_greater(a0,x0,nth__element_3_3);
  x1 = makeint(1L);
  bblt_sub_no_check(a0,x1,x2);
  a0 = x2;
  a1 = cdr_of(a1);
  execute(nth__element_3_0);
  goto nth__element_3_ext_interrupt;
 nth__element_3_3:
  if (a0 != makeint(1L)) goto nth__element_3_interrupt;
  x3 = car_of(a1);
  unify(a2, x3);
  proceed();
 nth__element_3_4:
  if (!isref(a0)) goto nth__element_3_interrupt;
  deref_and_jump(a0,nth__element_3_2);
  *reasonp++ =  a0;
  goto nth__element_3_interrupt;
 case VARREF:
  deref_and_jump(a1,nth__element_3_1);
  *reasonp++ =  a1;
  goto nth__element_3_interrupt;
  };
  goto nth__element_3_interrupt;
 nth__element_3_ext_interrupt:
  reasonp = 0l;
 nth__element_3_interrupt:
  goto interrupt_3;
 }

 split__nth_4_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 split__nth_4_clear_reason:
  reasonp = reasons;
 split__nth_4_0:
 split__nth_4_1:
  switch (ptagof(a1)) {
 case CONS:
 split__nth_4_2:
  if (!isint(a0)) goto split__nth_4_3;
  x0 = makeint(1L);
  gblt_greater(a0,x0,split__nth_4_4);
  allocp[0] = x2 = makeref(&allocp[0]);
  x3 = car_of(a1);
  allocp[1] = x3;
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x1);
  x4 = makeint(1L);
  bblt_sub_no_check(a0,x4,x5);
  a0 = x5;
  a1 = cdr_of(a1);
  a2 = x2;
  execute(split__nth_4_0);
  goto split__nth_4_ext_interrupt;
 split__nth_4_3:
  if (!isref(a0)) goto split__nth_4_4;
  deref_and_jump(a0,split__nth_4_2);
  *reasonp++ =  a0;
  goto split__nth_4_4;
 case VARREF:
  deref_and_jump(a1,split__nth_4_1);
  *reasonp++ =  a1;
  goto split__nth_4_4;
  };
  goto split__nth_4_4;
 split__nth_4_4:
 split__nth_4_5:
  switch (ptagof(a0)) {
 case ATOMIC:
 split__nth_4_6:
  if (a0 != makeint(1L)) goto split__nth_4_interrupt;
  x0 = NILATOM;
  unify_value(a2, x0);
  unify(a3, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,split__nth_4_5);
  *reasonp++ =  a0;
  goto split__nth_4_interrupt;
  };
  goto split__nth_4_interrupt;
 split__nth_4_ext_interrupt:
  reasonp = 0l;
 split__nth_4_interrupt:
  goto interrupt_4;
 }

 insert__nth__element_4_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 insert__nth__element_4_clear_reason:
  reasonp = reasons;
 insert__nth__element_4_0:
 insert__nth__element_4_1:
  switch (ptagof(a2)) {
 case CONS:
 insert__nth__element_4_2:
  if (!isint(a0)) goto insert__nth__element_4_3;
  x0 = makeint(1L);
  gblt_greater(a0,x0,insert__nth__element_4_4);
  allocp[0] = x2 = makeref(&allocp[0]);
  x3 = car_of(a2);
  allocp[1] = x3;
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a3, x1);
  x4 = makeint(1L);
  bblt_sub_no_check(a0,x4,x5);
  a0 = x5;
  a2 = cdr_of(a2);
  a3 = x2;
  execute(insert__nth__element_4_0);
  goto insert__nth__element_4_ext_interrupt;
 insert__nth__element_4_3:
  if (!isref(a0)) goto insert__nth__element_4_4;
  deref_and_jump(a0,insert__nth__element_4_2);
  *reasonp++ =  a0;
  goto insert__nth__element_4_4;
 case VARREF:
  deref_and_jump(a2,insert__nth__element_4_1);
  *reasonp++ =  a2;
  goto insert__nth__element_4_4;
  };
  goto insert__nth__element_4_4;
 insert__nth__element_4_4:
 insert__nth__element_4_5:
  switch (ptagof(a0)) {
 case ATOMIC:
 insert__nth__element_4_6:
  if (a0 != makeint(1L)) goto insert__nth__element_4_interrupt;
  allocp[0] = a2;
  allocp[1] = a1;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a3, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,insert__nth__element_4_5);
  *reasonp++ =  a0;
  goto insert__nth__element_4_interrupt;
  };
  goto insert__nth__element_4_interrupt;
 insert__nth__element_4_ext_interrupt:
  reasonp = 0l;
 insert__nth__element_4_interrupt:
  goto interrupt_4;
 }

 make__unique_2_top: {
  q x0, x1, x2, x3, x4;
  qp = qp->next;
 make__unique_2_clear_reason:
  reasonp = reasons;
 make__unique_2_0:
 make__unique_2_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_list_xmake__unique_2);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = x1;
  x4 = car_of(a0);
  a1 = cdr_of(a0);
  a2 = x3;
  a0 = x4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  execute(make__unique1_3_0);
  goto make__unique1_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto make__unique_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,make__unique_2_1);
  *reasonp++ =  a0;
  goto make__unique_2_interrupt;
  };
  goto make__unique_2_interrupt;
 make__unique_2_ext_interrupt:
  reasonp = 0l;
 make__unique_2_interrupt:
  goto interrupt_2;
 }

 make__unique1_3_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  qp = qp->next;
 make__unique1_3_clear_reason:
  reasonp = reasons;
 make__unique1_3_0:
 make__unique1_3_1:
  switch (ptagof(a1)) {
 case CONS:
 make__unique1_3_2:
  if (isref(a0)) goto make__unique1_3_5;
 make__unique1_3_3:
  if (isref(a0)) goto make__unique1_3_4;
  x0 = car_of(a1);
  if_not_equal(a0, x0, make__unique1_3_6);
  a1 = cdr_of(a1);
  execute(make__unique1_3_clear_reason);
  goto make__unique1_3_ext_interrupt;
 make__unique1_3_4:
  deref_and_jump(a0,make__unique1_3_3);
  *reasonp++ =  a0;
  goto make__unique1_3_6;
 make__unique1_3_5:
  deref_and_jump(a0,make__unique1_3_2);
  *reasonp++ =  a0;
  goto make__unique1_3_6;
 case VARREF:
  deref_and_jump(a1,make__unique1_3_1);
  *reasonp++ =  a1;
  goto make__unique1_3_6;
  };
  goto make__unique1_3_6;
 make__unique1_3_6:
  otherwise(make__unique1_3_interrupt);
 make__unique1_3_7:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a1);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  a1 = cdr_of(a1);
  a2 = x1;
  execute(make__unique1_3_0);
  goto make__unique1_3_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto make__unique1_3_interrupt;
  x0 = NILATOM;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,make__unique1_3_7);
  *reasonp++ =  a1;
  goto make__unique1_3_interrupt;
  };
  goto make__unique1_3_interrupt;
 make__unique1_3_ext_interrupt:
  reasonp = 0l;
 make__unique1_3_interrupt:
  toppred = &predicate_list_xmake__unique1_3;
  goto interrupt_3;
 }

 delete__elements_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 delete__elements_3_clear_reason:
  reasonp = reasons;
 delete__elements_3_0:
 delete__elements_3_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_list_xdelete__elements_3);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  a0 = car_of(a0);
  a2 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(delete__element_3_0);
  goto delete__element_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto delete__elements_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,delete__elements_3_1);
  *reasonp++ =  a0;
  goto delete__elements_3_interrupt;
  };
  goto delete__elements_3_interrupt;
 delete__elements_3_ext_interrupt:
  reasonp = 0l;
 delete__elements_3_interrupt:
  goto interrupt_3;
 }

 delete__element_3_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  qp = qp->next;
 delete__element_3_clear_reason:
  reasonp = reasons;
 delete__element_3_0:
 delete__element_3_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 delete__element_3_2:
  if (isref(x0)) goto delete__element_3_5;
 delete__element_3_3:
  if (isref(x0)) goto delete__element_3_4;
  if_not_equal(x0, a0, delete__element_3_6);
  a1 = cdr_of(a1);
  execute(delete__element_3_clear_reason);
  goto delete__element_3_ext_interrupt;
 delete__element_3_4:
  deref_and_jump(x0,delete__element_3_3);
  *reasonp++ =  x0;
  goto delete__element_3_6;
 delete__element_3_5:
  deref_and_jump(x0,delete__element_3_2);
  *reasonp++ =  x0;
  goto delete__element_3_6;
 case VARREF:
  deref_and_jump(a1,delete__element_3_1);
  *reasonp++ =  a1;
  goto delete__element_3_6;
  };
  goto delete__element_3_6;
 delete__element_3_6:
  otherwise(delete__element_3_interrupt);
 delete__element_3_7:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a1);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  a1 = cdr_of(a1);
  a2 = x1;
  execute(delete__element_3_0);
  goto delete__element_3_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto delete__element_3_interrupt;
  x0 = NILATOM;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,delete__element_3_7);
  *reasonp++ =  a1;
  goto delete__element_3_interrupt;
  };
  goto delete__element_3_interrupt;
 delete__element_3_ext_interrupt:
  reasonp = 0l;
 delete__element_3_interrupt:
  toppred = &predicate_list_xdelete__element_3;
  goto interrupt_3;
 }

 or__unique_3_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  qp = qp->next;
 or__unique_3_clear_reason:
  reasonp = reasons;
 or__unique_3_0:
 or__unique_3_1:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_list_xor__unique_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  x1 = cdr_of(a1);
  allocp[3] = x1;
  allocp[4] = a2;
  x2 = car_of(a1);
  a1 = a0;
  a2 = x0;
  a0 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(entry__unique__data_3_0);
  goto entry__unique__data_3_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto or__unique_3_interrupt;
  unify(a2, a0);
  proceed();
 case VARREF:
  deref_and_jump(a1,or__unique_3_1);
  *reasonp++ =  a1;
  goto or__unique_3_interrupt;
  };
  goto or__unique_3_interrupt;
 or__unique_3_ext_interrupt:
  reasonp = 0l;
 or__unique_3_interrupt:
  goto interrupt_3;
 }

 and__unique_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 and__unique_3_clear_reason:
  reasonp = reasons;
 and__unique_3_0:
 and__unique_3_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_list_xand__unique_3);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = a1;
  allocp[4] = x1 = makeref(&allocp[4]);
  a0 = car_of(a0);
  a3 = a2;
  a2 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(and__unique1_4_0);
  goto and__unique1_4_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto and__unique_3_interrupt;
  x0 = NILATOM;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,and__unique_3_1);
  *reasonp++ =  a0;
  goto and__unique_3_interrupt;
  };
  goto and__unique_3_interrupt;
 and__unique_3_ext_interrupt:
  reasonp = 0l;
 and__unique_3_interrupt:
  goto interrupt_3;
 }

 and__unique1_4_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 and__unique1_4_clear_reason:
  reasonp = reasons;
 and__unique1_4_0:
 and__unique1_4_1:
  switch (ptagof(a1)) {
 case CONS:
 and__unique1_4_2:
  if (isref(a0)) goto and__unique1_4_5;
 and__unique1_4_3:
  if (isref(a0)) goto and__unique1_4_4;
  x0 = car_of(a1);
  if_not_equal(a0, x0, and__unique1_4_6);
  allocp[0] = a2;
  allocp[1] = a0;
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a3, x1);
  proceed();
 and__unique1_4_4:
  deref_and_jump(a0,and__unique1_4_3);
  *reasonp++ =  a0;
  goto and__unique1_4_6;
 and__unique1_4_5:
  deref_and_jump(a0,and__unique1_4_2);
  *reasonp++ =  a0;
  goto and__unique1_4_6;
 case VARREF:
  deref_and_jump(a1,and__unique1_4_1);
  *reasonp++ =  a1;
  goto and__unique1_4_6;
  };
  goto and__unique1_4_6;
 and__unique1_4_6:
  otherwise(and__unique1_4_interrupt);
 and__unique1_4_7:
  switch (ptagof(a1)) {
 case CONS:
  a1 = cdr_of(a1);
  execute(and__unique1_4_0);
  goto and__unique1_4_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto and__unique1_4_interrupt;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a1,and__unique1_4_7);
  *reasonp++ =  a1;
  goto and__unique1_4_interrupt;
  };
  goto and__unique1_4_interrupt;
 and__unique1_4_ext_interrupt:
  reasonp = 0l;
 and__unique1_4_interrupt:
  toppred = &predicate_list_xand__unique1_4;
  goto interrupt_4;
 }

 entry__unique__data_3_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  qp = qp->next;
 entry__unique__data_3_clear_reason:
  reasonp = reasons;
 entry__unique__data_3_0:
 entry__unique__data_3_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 entry__unique__data_3_2:
  if (isref(x0)) goto entry__unique__data_3_5;
 entry__unique__data_3_3:
  if (isref(x0)) goto entry__unique__data_3_4;
  if_not_equal(x0, a0, entry__unique__data_3_6);
  unify_value(a2, a1);
  proceed();
 entry__unique__data_3_4:
  deref_and_jump(x0,entry__unique__data_3_3);
  *reasonp++ =  x0;
  goto entry__unique__data_3_6;
 entry__unique__data_3_5:
  deref_and_jump(x0,entry__unique__data_3_2);
  *reasonp++ =  x0;
  goto entry__unique__data_3_6;
 case VARREF:
  deref_and_jump(a1,entry__unique__data_3_1);
  *reasonp++ =  a1;
  goto entry__unique__data_3_6;
  };
  goto entry__unique__data_3_6;
 entry__unique__data_3_6:
  otherwise(entry__unique__data_3_interrupt);
 entry__unique__data_3_7:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a1);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  a1 = cdr_of(a1);
  a2 = x1;
  execute(entry__unique__data_3_0);
  goto entry__unique__data_3_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto entry__unique__data_3_interrupt;
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,entry__unique__data_3_7);
  *reasonp++ =  a1;
  goto entry__unique__data_3_interrupt;
  };
  goto entry__unique__data_3_interrupt;
 entry__unique__data_3_ext_interrupt:
  reasonp = 0l;
 entry__unique__data_3_interrupt:
  toppred = &predicate_list_xentry__unique__data_3;
  goto interrupt_3;
 }

 check__include_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 check__include_3_clear_reason:
  reasonp = reasons;
 check__include_3_0:
 check__include_3_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 check__include_3_2:
  if (isref(x0)) goto check__include_3_5;
 check__include_3_3:
  if (isref(x0)) goto check__include_3_4;
  if_not_equal(x0, a0, check__include_3_6);
  x1 = makesym(atom_yes);
  unify_value(a2, x1);
  proceed();
 check__include_3_4:
  deref_and_jump(x0,check__include_3_3);
  *reasonp++ =  x0;
  goto check__include_3_6;
 check__include_3_5:
  deref_and_jump(x0,check__include_3_2);
  *reasonp++ =  x0;
  goto check__include_3_6;
 case VARREF:
  deref_and_jump(a1,check__include_3_1);
  *reasonp++ =  a1;
  goto check__include_3_6;
  };
  goto check__include_3_6;
 check__include_3_6:
  otherwise(check__include_3_interrupt);
 check__include_3_7:
  switch (ptagof(a1)) {
 case CONS:
  a1 = cdr_of(a1);
  execute(check__include_3_0);
  goto check__include_3_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto check__include_3_interrupt;
  x0 = makesym(atom_no);
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,check__include_3_7);
  *reasonp++ =  a1;
  goto check__include_3_interrupt;
  };
  goto check__include_3_interrupt;
 check__include_3_ext_interrupt:
  reasonp = 0l;
 check__include_3_interrupt:
  toppred = &predicate_list_xcheck__include_3;
  goto interrupt_3;
 }

 check__subset_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 check__subset_3_clear_reason:
  reasonp = reasons;
 check__subset_3_0:
 check__subset_3_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_list_xcheck__subset1_4);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = a1;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a2;
  a0 = car_of(a0);
  a2 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(check__include_3_0);
  goto check__include_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto check__subset_3_interrupt;
  x0 = makesym(atom_yes);
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,check__subset_3_1);
  *reasonp++ =  a0;
  goto check__subset_3_interrupt;
  };
  goto check__subset_3_interrupt;
 check__subset_3_ext_interrupt:
  reasonp = 0l;
 check__subset_3_interrupt:
  toppred = &predicate_list_xcheck__subset_3;
  goto interrupt_3;
 }

 check__subset1_4_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 check__subset1_4_clear_reason:
  reasonp = reasons;
 check__subset1_4_0:
 check__subset1_4_1:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (isint(a2)) goto check__subset1_4_interrupt;
  switch (symval(a2)) {
 case symval(makesym(atom_yes)):
  a2 = a3;
  execute(check__subset_3_0);
  goto check__subset_3_ext_interrupt;
 case symval(makesym(atom_no)):
  x0 = makesym(atom_no);
  unify_value(a3, x0);
  proceed();
  };
  goto check__subset1_4_interrupt;
 case VARREF:
  deref_and_jump(a2,check__subset1_4_1);
  *reasonp++ =  a2;
  goto check__subset1_4_interrupt;
  };
  goto check__subset1_4_interrupt;
 check__subset1_4_ext_interrupt:
  reasonp = 0l;
 check__subset1_4_interrupt:
  goto interrupt_4;
 }

 check__elements_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 check__elements_3_clear_reason:
  reasonp = reasons;
 check__elements_3_0:
 check__elements_3_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != NILATOM) goto check__elements_3_2;
  x0 = makesym(atom_no);
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,check__elements_3_1);
  *reasonp++ =  a1;
  goto check__elements_3_2;
  };
  goto check__elements_3_2;
 check__elements_3_2:
 check__elements_3_3:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_list_xcheck__elements1_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  x1 = cdr_of(a0);
  allocp[3] = x1;
  allocp[4] = a1;
  allocp[5] = a2;
  a0 = car_of(a0);
  a2 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(check__include_3_clear_reason);
  goto check__include_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto check__elements_3_interrupt;
  x0 = makesym(atom_no);
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,check__elements_3_3);
  *reasonp++ =  a0;
  goto check__elements_3_interrupt;
  };
  goto check__elements_3_interrupt;
 check__elements_3_ext_interrupt:
  reasonp = 0l;
 check__elements_3_interrupt:
  toppred = &predicate_list_xcheck__elements_3;
  goto interrupt_3;
 }

 check__elements1_4_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 check__elements1_4_clear_reason:
  reasonp = reasons;
 check__elements1_4_0:
 check__elements1_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto check__elements1_4_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  x0 = makesym(atom_yes);
  unify_value(a3, x0);
  proceed();
 case symval(makesym(atom_no)):
  a0 = a1;
  a1 = a2;
  a2 = a3;
  execute(check__elements_3_0);
  goto check__elements_3_ext_interrupt;
  };
  goto check__elements1_4_interrupt;
 case VARREF:
  deref_and_jump(a0,check__elements1_4_1);
  *reasonp++ =  a0;
  goto check__elements1_4_interrupt;
  };
  goto check__elements1_4_interrupt;
 check__elements1_4_ext_interrupt:
  reasonp = 0l;
 check__elements1_4_interrupt:
  goto interrupt_4;
 }

 delete__incomplete__element_3_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  qp = qp->next;
 delete__incomplete__element_3_clear_reason:
  reasonp = reasons;
 delete__incomplete__element_3_0:
 delete__incomplete__element_3_1:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_list_xdelete__incomplete__element1_5);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  x1 = car_of(a1);
  allocp[4] = x1;
  x2 = cdr_of(a1);
  allocp[5] = x2;
  allocp[6] = a2;
  a1 = x1;
  a2 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(delete__incomplete__element__match_3_0);
  goto delete__incomplete__element__match_3_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto delete__incomplete__element_3_interrupt;
  x0 = NILATOM;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,delete__incomplete__element_3_1);
  *reasonp++ =  a1;
  goto delete__incomplete__element_3_interrupt;
  };
  goto delete__incomplete__element_3_interrupt;
 delete__incomplete__element_3_ext_interrupt:
  reasonp = 0l;
 delete__incomplete__element_3_interrupt:
  toppred = &predicate_list_xdelete__incomplete__element_3;
  goto interrupt_3;
 }

 delete__incomplete__element1_5_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 delete__incomplete__element1_5_clear_reason:
  reasonp = reasons;
 delete__incomplete__element1_5_0:
 delete__incomplete__element1_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto delete__incomplete__element1_5_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  a0 = a1;
  a1 = a3;
  a2 = a4;
  execute(delete__incomplete__element_3_0);
  goto delete__incomplete__element_3_ext_interrupt;
 case symval(makesym(atom_no)):
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = a2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a4, x0);
  a0 = a1;
  a1 = a3;
  a2 = x1;
  execute(delete__incomplete__element_3_0);
  goto delete__incomplete__element_3_ext_interrupt;
  };
  goto delete__incomplete__element1_5_interrupt;
 case VARREF:
  deref_and_jump(a0,delete__incomplete__element1_5_1);
  *reasonp++ =  a0;
  goto delete__incomplete__element1_5_interrupt;
  };
  goto delete__incomplete__element1_5_interrupt;
 delete__incomplete__element1_5_ext_interrupt:
  reasonp = 0l;
 delete__incomplete__element1_5_interrupt:
  goto interrupt_5;
 }

 delete__incomplete__element__match_3_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  qp = qp->next;
 delete__incomplete__element__match_3_clear_reason:
  reasonp = reasons;
 delete__incomplete__element__match_3_0:
 delete__incomplete__element__match_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 delete__incomplete__element__match_3_2:
  gblt_atomic(a0,delete__incomplete__element__match_3_7);
 delete__incomplete__element__match_3_3:
  if (isref(a0)) goto delete__incomplete__element__match_3_6;
 delete__incomplete__element__match_3_4:
  if (isref(a0)) goto delete__incomplete__element__match_3_5;
  if_not_equal(a0, a1, delete__incomplete__element__match_3_7);
  x0 = makesym(atom_yes);
  unify_value(a2, x0);
  proceed();
 delete__incomplete__element__match_3_5:
  deref_and_jump(a0,delete__incomplete__element__match_3_4);
  *reasonp++ =  a0;
  goto delete__incomplete__element__match_3_7;
 delete__incomplete__element__match_3_6:
  deref_and_jump(a0,delete__incomplete__element__match_3_3);
  *reasonp++ =  a0;
  goto delete__incomplete__element__match_3_7;
 case VARREF:
  deref_and_jump(a0,delete__incomplete__element__match_3_1);
  *reasonp++ =  a0;
  goto delete__incomplete__element__match_3_7;
  };
  goto delete__incomplete__element__match_3_7;
 delete__incomplete__element__match_3_7:
  otherwise(delete__incomplete__element__match_3_interrupt);
 delete__incomplete__element__match_3_8:
  switch (ptagof(a0)) {
 case ATOMIC:
 delete__incomplete__element__match_3_9:
  gblt_atomic(a0,delete__incomplete__element__match_3_10);
  x0 = makesym(atom_no);
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,delete__incomplete__element__match_3_8);
  *reasonp++ =  a0;
  goto delete__incomplete__element__match_3_10;
  };
  goto delete__incomplete__element__match_3_10;
 delete__incomplete__element__match_3_10:
  otherwise(delete__incomplete__element__match_3_interrupt);
 delete__incomplete__element__match_3_11:
  if (isref(a0)) goto delete__incomplete__element__match_3_22;
  gblt_pfunctor(a0,x0,delete__incomplete__element__match_3_23);
  gblt_arity(a0,x1,delete__incomplete__element__match_3_23);
 delete__incomplete__element__match_3_12:
  if (isref(a1)) goto delete__incomplete__element__match_3_21;
  gblt_pfunctor(a1,x2,delete__incomplete__element__match_3_23);
 delete__incomplete__element__match_3_13:
  if (isref(x2)) goto delete__incomplete__element__match_3_20;
 delete__incomplete__element__match_3_14:
  if (isref(x2)) goto delete__incomplete__element__match_3_19;
  if_not_equal(x2, x0, delete__incomplete__element__match_3_23);
  gblt_arity(a1,x3,delete__incomplete__element__match_3_23);
 delete__incomplete__element__match_3_15:
  if (isref(x3)) goto delete__incomplete__element__match_3_18;
 delete__incomplete__element__match_3_16:
  if (isref(x3)) goto delete__incomplete__element__match_3_17;
  if_not_equal(x3, x1, delete__incomplete__element__match_3_23);
  x4 = a0;
  x5 = a1;
  a3 = a2;
  a2 = x5;
  a1 = x4;
  a0 = x1;
  execute(delete__incomplete__element__match__args_4_clear_reason);
  goto delete__incomplete__element__match__args_4_ext_interrupt;
 delete__incomplete__element__match_3_17:
  deref_and_jump(x3,delete__incomplete__element__match_3_16);
  *reasonp++ =  x3;
  goto delete__incomplete__element__match_3_23;
 delete__incomplete__element__match_3_18:
  deref_and_jump(x3,delete__incomplete__element__match_3_15);
  *reasonp++ =  x3;
  goto delete__incomplete__element__match_3_23;
 delete__incomplete__element__match_3_19:
  deref_and_jump(x2,delete__incomplete__element__match_3_14);
  *reasonp++ =  x2;
  goto delete__incomplete__element__match_3_23;
 delete__incomplete__element__match_3_20:
  deref_and_jump(x2,delete__incomplete__element__match_3_13);
  *reasonp++ =  x2;
  goto delete__incomplete__element__match_3_23;
 delete__incomplete__element__match_3_21:
  deref_and_jump(a1,delete__incomplete__element__match_3_12);
  *reasonp++ =  a1;
  goto delete__incomplete__element__match_3_23;
 delete__incomplete__element__match_3_22:
  deref_and_jump(a0,delete__incomplete__element__match_3_11);
  *reasonp++ =  a0;
  goto delete__incomplete__element__match_3_23;
 delete__incomplete__element__match_3_23:
  otherwise(delete__incomplete__element__match_3_interrupt);
  x0 = makesym(atom_no);
  unify_value(a2, x0);
  proceed();
 delete__incomplete__element__match_3_ext_interrupt:
  reasonp = 0l;
 delete__incomplete__element__match_3_interrupt:
  toppred = &predicate_list_xdelete__incomplete__element__match_3;
  goto interrupt_3;
 }

 delete__incomplete__element__match__args_4_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 delete__incomplete__element__match__args_4_clear_reason:
  reasonp = reasons;
 delete__incomplete__element__match__args_4_0:
 delete__incomplete__element__match__args_4_1:
  if (!isint(a0)) goto delete__incomplete__element__match__args_4_5;
  x0 = makeint(0L);
  gblt_greater(a0,x0,delete__incomplete__element__match__args_4_6);
 delete__incomplete__element__match__args_4_2:
  if (isref(a1)) goto delete__incomplete__element__match__args_4_4;
  gblt_arg(a0,a1,x1,delete__incomplete__element__match__args_4_6);
 delete__incomplete__element__match__args_4_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom___)) goto delete__incomplete__element__match__args_4_6;
  x2 = makeint(1L);
  bblt_sub_no_check(a0,x2,x3);
  a0 = x3;
  execute(delete__incomplete__element__match__args_4_0);
  goto delete__incomplete__element__match__args_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,delete__incomplete__element__match__args_4_3);
  *reasonp++ =  x1;
  goto delete__incomplete__element__match__args_4_6;
  };
  goto delete__incomplete__element__match__args_4_6;
 delete__incomplete__element__match__args_4_4:
  deref_and_jump(a1,delete__incomplete__element__match__args_4_2);
  *reasonp++ =  a1;
  goto delete__incomplete__element__match__args_4_6;
 delete__incomplete__element__match__args_4_5:
  if (!isref(a0)) goto delete__incomplete__element__match__args_4_6;
  deref_and_jump(a0,delete__incomplete__element__match__args_4_1);
  *reasonp++ =  a0;
  goto delete__incomplete__element__match__args_4_6;
 delete__incomplete__element__match__args_4_6:
  otherwise(delete__incomplete__element__match__args_4_interrupt);
 delete__incomplete__element__match__args_4_7:
  if (!isint(a0)) goto delete__incomplete__element__match__args_4_13;
  x0 = makeint(0L);
  gblt_greater(a0,x0,delete__incomplete__element__match__args_4_12);
 delete__incomplete__element__match__args_4_8:
  if (isref(a1)) goto delete__incomplete__element__match__args_4_11;
  gblt_arg(a0,a1,x1,delete__incomplete__element__match__args_4_12);
 delete__incomplete__element__match__args_4_9:
  if (isref(a2)) goto delete__incomplete__element__match__args_4_10;
  gblt_arg(a0,a2,x2,delete__incomplete__element__match__args_4_12);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_list_xdelete__incomplete__element__match__args1_5);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  a0 = x1;
  a1 = x2;
  a2 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(delete__incomplete__element__match_3_0);
  goto delete__incomplete__element__match_3_ext_interrupt;
 delete__incomplete__element__match__args_4_10:
  deref_and_jump(a2,delete__incomplete__element__match__args_4_9);
  *reasonp++ =  a2;
  goto delete__incomplete__element__match__args_4_12;
 delete__incomplete__element__match__args_4_11:
  deref_and_jump(a1,delete__incomplete__element__match__args_4_8);
  *reasonp++ =  a1;
  goto delete__incomplete__element__match__args_4_12;
 delete__incomplete__element__match__args_4_12:
  if (a0 != makeint(0L)) goto delete__incomplete__element__match__args_4_interrupt;
  x4 = makesym(atom_yes);
  unify_value(a3, x4);
  proceed();
 delete__incomplete__element__match__args_4_13:
  if (!isref(a0)) goto delete__incomplete__element__match__args_4_interrupt;
  deref_and_jump(a0,delete__incomplete__element__match__args_4_7);
  *reasonp++ =  a0;
  goto delete__incomplete__element__match__args_4_interrupt;
 delete__incomplete__element__match__args_4_ext_interrupt:
  reasonp = 0l;
 delete__incomplete__element__match__args_4_interrupt:
  toppred = &predicate_list_xdelete__incomplete__element__match__args_4;
  goto interrupt_4;
 }

 delete__incomplete__element__match__args1_5_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 delete__incomplete__element__match__args1_5_clear_reason:
  reasonp = reasons;
 delete__incomplete__element__match__args1_5_0:
 delete__incomplete__element__match__args1_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto delete__incomplete__element__match__args1_5_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  x0 = makeint(1L);
  bblt_sub_no_check_y(a1,x0,x1);
  a0 = x1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  execute(delete__incomplete__element__match__args_4_0);
  goto delete__incomplete__element__match__args_4_ext_interrupt;
 case symval(makesym(atom_no)):
  x0 = makesym(atom_no);
  unify_value(a4, x0);
  proceed();
  };
  goto delete__incomplete__element__match__args1_5_interrupt;
 case VARREF:
  deref_and_jump(a0,delete__incomplete__element__match__args1_5_1);
  *reasonp++ =  a0;
  goto delete__incomplete__element__match__args1_5_interrupt;
  };
  goto delete__incomplete__element__match__args1_5_interrupt;
 delete__incomplete__element__match__args1_5_ext_interrupt:
  reasonp = 0l;
 delete__incomplete__element__match__args1_5_interrupt:
  goto interrupt_5;
 }

 sort__int__up_2_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  qp = qp->next;
 sort__int__up_2_clear_reason:
  reasonp = reasons;
 sort__int__up_2_0:
 sort__int__up_2_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_list_xappend_3);
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = x0;
  allocp[6] = a1;
  allocp[7] = (q)(struct goalrec*)&allocp[2];
  allocp[8] = (q)(&predicate_list_xsort__int__up_2);
  allocp[9] = x4 = makeref(&allocp[9]);
  allocp[10] = x1;
  allocp[11] = (q)(struct goalrec*)&allocp[7];
  allocp[12] = (q)(&predicate_list_xsort__int__up_2);
  allocp[13] = x5 = makeref(&allocp[13]);
  allocp[14] = x3;
  x6 = car_of(a0);
  a1 = cdr_of(a0);
  a2 = x5;
  a3 = x4;
  a0 = x6;
  qp = (struct goalrec*)&allocp[11];
  allocp += 15;
  execute(sort__int__split_4_0);
  goto sort__int__split_4_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto sort__int__up_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,sort__int__up_2_1);
  *reasonp++ =  a0;
  goto sort__int__up_2_interrupt;
  };
  goto sort__int__up_2_interrupt;
 sort__int__up_2_ext_interrupt:
  reasonp = 0l;
 sort__int__up_2_interrupt:
  goto interrupt_2;
 }

 sort__int__split_4_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 sort__int__split_4_clear_reason:
  reasonp = reasons;
 sort__int__split_4_0:
 sort__int__split_4_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 sort__int__split_4_2:
  if (!isint(x0)) goto sort__int__split_4_6;
 sort__int__split_4_3:
  if (!isint(a0)) goto sort__int__split_4_5;
  gblt_less(x0,a0,sort__int__split_4_4);
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = x0;
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x1);
  a1 = cdr_of(a1);
  a2 = x2;
  execute(sort__int__split_4_0);
  goto sort__int__split_4_ext_interrupt;
 sort__int__split_4_4:
  gblt_greater_or_eq(x0,a0,sort__int__split_4_interrupt);
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = x0;
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a3, x1);
  a1 = cdr_of(a1);
  a3 = x2;
  execute(sort__int__split_4_0);
  goto sort__int__split_4_ext_interrupt;
 sort__int__split_4_5:
  if (!isref(a0)) goto sort__int__split_4_interrupt;
  deref_and_jump(a0,sort__int__split_4_3);
  *reasonp++ =  a0;
  goto sort__int__split_4_interrupt;
 sort__int__split_4_6:
  if (!isref(x0)) goto sort__int__split_4_interrupt;
  deref_and_jump(x0,sort__int__split_4_2);
  *reasonp++ =  x0;
  goto sort__int__split_4_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto sort__int__split_4_interrupt;
  x0 = NILATOM;
  unify_value(a2, x0);
  x1 = NILATOM;
  unify_value(a3, x1);
  proceed();
 case VARREF:
  deref_and_jump(a1,sort__int__split_4_1);
  *reasonp++ =  a1;
  goto sort__int__split_4_interrupt;
  };
  goto sort__int__split_4_interrupt;
 sort__int__split_4_ext_interrupt:
  reasonp = 0l;
 sort__int__split_4_interrupt:
  toppred = &predicate_list_xsort__int__split_4;
  goto interrupt_4;
 }

 split_4_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 split_4_clear_reason:
  reasonp = reasons;
 split_4_0:
 split_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 split_4_2:
  if (isref(x0)) goto split_4_5;
 split_4_3:
  if (isref(x0)) goto split_4_4;
  if_not_equal(x0, a1, split_4_6);
  allocp[0] = NILATOM;
  allocp[1] = x0;
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x1);
  x2 = cdr_of(a0);
  unify(a3, x2);
  proceed();
 split_4_4:
  deref_and_jump(x0,split_4_3);
  *reasonp++ =  x0;
  goto split_4_6;
 split_4_5:
  deref_and_jump(x0,split_4_2);
  *reasonp++ =  x0;
  goto split_4_6;
 case VARREF:
  deref_and_jump(a0,split_4_1);
  *reasonp++ =  a0;
  goto split_4_6;
  };
  goto split_4_6;
 split_4_6:
  otherwise(split_4_interrupt);
 split_4_7:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  a0 = cdr_of(a0);
  a2 = x1;
  execute(split_4_0);
  goto split_4_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto split_4_interrupt;
  x0 = NILATOM;
  unify_value(a2, x0);
  x1 = NILATOM;
  unify_value(a3, x1);
  proceed();
 case VARREF:
  deref_and_jump(a0,split_4_7);
  *reasonp++ =  a0;
  goto split_4_interrupt;
  };
  goto split_4_interrupt;
 split_4_ext_interrupt:
  reasonp = 0l;
 split_4_interrupt:
  goto interrupt_4;
 }
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_list);
}
