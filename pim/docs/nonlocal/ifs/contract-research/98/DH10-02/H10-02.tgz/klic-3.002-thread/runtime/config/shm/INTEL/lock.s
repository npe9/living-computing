	.file	"lock.c"
	.version	"01.01"
	.ident	"hc1.0b -O3 -pentium -on GLOBALS_VOLATILE lock.c\n"
	.text
	.align	4
.L00TEXT:

/====================
/ s_lock
/--------------------
	.align	16
	.globl	s_lock
s_lock:
	movl	4(%esp),%eax
loop1:
        movl    $-1,%ecx
__AIR_s_lock:
	xchgl	(%eax),%ecx
        incl    %ecx
        je      loop1
	ret	
	.type	s_lock,@function
	.size	s_lock,.-s_lock

/====================
/ s_unlock
/--------------------
	.align	16
	.globl	s_unlock
s_unlock:
	movl	4(%esp),%eax
__AIR_s_unlock:	movl	$0,(%eax)
	ret	
	.type	s_unlock,@function
	.size	s_unlock,.-s_unlock
