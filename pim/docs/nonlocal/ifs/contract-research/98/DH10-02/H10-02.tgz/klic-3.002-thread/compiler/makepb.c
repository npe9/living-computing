/* Compiled by KLIC compiler version 3.002 (Wed Sep 17 15:37:13 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_makepb();
Const struct predicate predicate_makepb_xmakepb_3 =
   { module_makepb, 0, 3 };
Const struct predicate predicate_makepb_xmakepb1_7 =
   { module_makepb, 1, 7 };
Const struct predicate predicate_makepb_xadd__clause_4 =
   { module_makepb, 2, 4 };
Const struct predicate predicate_makepb_xsame__check_4 =
   { module_makepb, 3, 4 };
Const struct predicate predicate_makepb_xadd__bodyG_8 =
   { module_makepb, 4, 8 };
Const struct predicate predicate_makepb_xadd__bodyG__1_10 =
   { module_makepb, 5, 10 };
Const struct predicate predicate_makepb_xadd__bodyG__2_10 =
   { module_makepb, 6, 10 };
Const struct predicate predicate_makepb_xsearch__module_3 =
   { module_makepb, 7, 3 };
Const struct predicate predicate_makepb_xsearch__pred_4 =
   { module_makepb, 8, 4 };
Const struct predicate predicate_makepb_xsearch__BArgs_6 =
   { module_makepb, 9, 6 };
Const struct predicate predicate_makepb_xsearch__Entries1_8 =
   { module_makepb, 10, 8 };
extern Const struct predicate predicate_integer__arithmetics_xadd_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_xfunctor_3;
extern Const struct predicate predicate_parse__uty_xget__next__clause_6;
extern Const struct predicate predicate_parse__uty_xdecode__goal_4;
extern Const struct predicate predicate_hb_xcheck__infile_6;

module module_makepb(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  q a0, a1, a2, a3, a4, a5, a6, a7, a8, a9;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  switch_on_pred() {
    case_pred(0, makepb_3_top);
    case_pred(1, makepb1_7_top);
    case_pred(2, add__clause_4_top);
    case_pred(3, same__check_4_top);
    case_pred(4, add__bodyG_8_top);
    case_pred(5, add__bodyG__1_10_top);
    case_pred(6, add__bodyG__2_10_top);
    case_pred(7, search__module_3_top);
    case_pred(8, search__pred_4_top);
    case_pred(9, search__BArgs_6_top);
    last_case_pred(10, search__Entries1_8_top);
  }

 makepb_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  qp = qp->next;
 makepb_3_clear_reason:
  reasonp = reasons;
 makepb_3_0:
  allocp[0] = makesym(functor_module_2);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  x0 = makefunctor(&allocp[0]);
  allocp[3] = x4 = makeref(&allocp[3]);
  allocp[4] = x0;
  x3 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a0, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_makepb_xmakepb1_7);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x5 = makeref(&allocp[5]);
  allocp[6] = x6 = makeref(&allocp[6]);
  allocp[7] = x7 = makeref(&allocp[7]);
  allocp[8] = NILATOM;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_parse__uty_xget__next__clause_6);
  allocp[11] = x1;
  allocp[12] = makeint(0L);
  allocp[13] = x5;
  allocp[14] = x6;
  allocp[15] = a0;
  allocp[16] = x7;
  qp = (struct goalrec*)&allocp[9];
  allocp += 17;
  proceed();
 makepb_3_ext_interrupt:
  reasonp = 0l;
 makepb_3_interrupt:
  goto interrupt_3;
 }

 makepb1_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 makepb1_7_clear_reason:
  reasonp = reasons;
 makepb1_7_0:
 makepb1_7_1:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (a5 != makesym(atom_dummy)) goto makepb1_7_2;
  unify(a1, a6);
  proceed();
 case VARREF:
  deref_and_jump(a5,makepb1_7_1);
  *reasonp++ =  a5;
  goto makepb1_7_2;
  };
  goto makepb1_7_2;
 makepb1_7_2:
  otherwise(makepb1_7_interrupt);
  allocp[0] = makesym(functor_clause_4);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  x0 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a5, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_makepb_xmakepb1_7);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x5 = makeref(&allocp[5]);
  allocp[6] = x6 = makeref(&allocp[6]);
  allocp[7] = x7 = makeref(&allocp[7]);
  allocp[8] = x8 = makeref(&allocp[8]);
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_parse__uty_xget__next__clause_6);
  allocp[11] = a3;
  allocp[12] = a4;
  allocp[13] = x5;
  allocp[14] = x6;
  allocp[15] = a0;
  allocp[16] = x7;
  allocp[17] = (q)(struct goalrec*)&allocp[9];
  allocp[18] = (q)(&predicate_makepb_xadd__bodyG_8);
  allocp[19] = x3;
  allocp[20] = x9 = makeref(&allocp[20]);
  allocp[21] = a3;
  allocp[22] = a2;
  allocp[23] = a4;
  allocp[24] = x10 = makeref(&allocp[24]);
  allocp[25] = x8;
  allocp[26] = makeint(1L);
  allocp[27] = (q)(struct goalrec*)&allocp[17];
  allocp[28] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[29] = x3;
  allocp[30] = x11 = makeref(&allocp[30]);
  allocp[31] = x9;
  a0 = x1;
  a1 = a6;
  a2 = a3;
  a3 = x10;
  qp = (struct goalrec*)&allocp[27];
  allocp += 32;
  execute(add__clause_4_0);
  goto add__clause_4_ext_interrupt;
 makepb1_7_ext_interrupt:
  reasonp = 0l;
 makepb1_7_interrupt:
  goto interrupt_7;
 }

 add__clause_4_top: {
  q x0, x1, x2, x3, x4, x5;
  a3 = qp->args[3];
  qp = qp->next;
 add__clause_4_clear_reason:
  reasonp = reasons;
 add__clause_4_0:
  allocp[0] = makesym(functor_functor_2);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  x0 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a0, x0);
  allocp[0] = makesym(functor_pred_3);
  allocp[1] = a2;
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = x5 = makeref(&allocp[3]);
  x3 = makefunctor(&allocp[0]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_makepb_xsame__check_4);
  allocp[6] = a1;
  allocp[7] = a1;
  allocp[8] = a3;
  allocp[9] = x3;
  allocp[10] = (q)(struct goalrec*)&allocp[4];
  allocp[11] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[12] = x1;
  allocp[13] = x4;
  allocp[14] = x5;
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 add__clause_4_ext_interrupt:
  reasonp = 0l;
 add__clause_4_interrupt:
  toppred = &predicate_makepb_xadd__clause_4;
  goto interrupt_4;
 }

 same__check_4_top: {
  q x0, x1, x2;
  a3 = qp->args[3];
  qp = qp->next;
 same__check_4_clear_reason:
  reasonp = reasons;
 same__check_4_0:
 same__check_4_1:
  switch (ptagof(a3)) {
 case FUNCTOR:
  if (functor_of(a3) != makesym(functor_pred_3)) goto same__check_4_6;
  x0 = arg(a3, 0);
 same__check_4_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_main)) goto same__check_4_6;
  x1 = arg(a3, 1);
 same__check_4_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_main)) goto same__check_4_6;
  x2 = arg(a3, 2);
 same__check_4_4:
  switch (ptagof(x2)) {
 case ATOMIC:
 same__check_4_5:
  if (x2 != makeint(0L)) goto same__check_4_6;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(x2,same__check_4_4);
  *reasonp++ =  x2;
  goto same__check_4_6;
  };
  goto same__check_4_6;
 case VARREF:
  deref_and_jump(x1,same__check_4_3);
  *reasonp++ =  x1;
  goto same__check_4_6;
  };
  goto same__check_4_6;
 case VARREF:
  deref_and_jump(x0,same__check_4_2);
  *reasonp++ =  x0;
  goto same__check_4_6;
  };
  goto same__check_4_6;
 case VARREF:
  deref_and_jump(a3,same__check_4_1);
  *reasonp++ =  a3;
  goto same__check_4_6;
  };
  goto same__check_4_6;
 same__check_4_6:
  otherwise(same__check_4_interrupt);
 same__check_4_7:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 same__check_4_8:
  if (isref(x0)) goto same__check_4_11;
 same__check_4_9:
  if (isref(x0)) goto same__check_4_10;
  if_not_equal(x0, a3, same__check_4_12);
  unify(a2, a1);
  proceed();
 same__check_4_10:
  deref_and_jump(x0,same__check_4_9);
  *reasonp++ =  x0;
  goto same__check_4_12;
 same__check_4_11:
  deref_and_jump(x0,same__check_4_8);
  *reasonp++ =  x0;
  goto same__check_4_12;
 case ATOMIC:
  if (a0 != NILATOM) goto same__check_4_12;
  allocp[0] = a1;
  allocp[1] = a3;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,same__check_4_7);
  *reasonp++ =  a0;
  goto same__check_4_12;
  };
  goto same__check_4_12;
 same__check_4_12:
  otherwise(same__check_4_interrupt);
 same__check_4_13:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(same__check_4_0);
  goto same__check_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,same__check_4_13);
  *reasonp++ =  a0;
  goto same__check_4_interrupt;
  };
  goto same__check_4_interrupt;
 same__check_4_ext_interrupt:
  reasonp = 0l;
 same__check_4_interrupt:
  goto interrupt_4;
 }

 add__bodyG_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 add__bodyG_8_clear_reason:
  reasonp = reasons;
 add__bodyG_8_0:
 add__bodyG_8_1:
  if (!isint(a1)) goto add__bodyG_8_5;
 add__bodyG_8_2:
  if (!isint(a7)) goto add__bodyG_8_3;
  gblt_less(a1,a7,add__bodyG_8_4);
  unify(a5, a6);
  proceed();
 add__bodyG_8_3:
  if (!isref(a7)) goto add__bodyG_8_4;
  deref_and_jump(a7,add__bodyG_8_2);
  *reasonp++ =  a7;
  goto add__bodyG_8_4;
 add__bodyG_8_4:
  if (a1 != makeint(0L)) goto add__bodyG_8_6;
  unify(a5, a6);
  proceed();
 add__bodyG_8_5:
  if (!isref(a1)) goto add__bodyG_8_6;
  deref_and_jump(a1,add__bodyG_8_1);
  *reasonp++ =  a1;
  goto add__bodyG_8_6;
 add__bodyG_8_6:
  otherwise(add__bodyG_8_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_makepb_xadd__bodyG_8);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x0 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = x1 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[12] = a7;
  allocp[13] = makeint(1L);
  allocp[14] = x1;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_makepb_xadd__bodyG__1_10);
  allocp[17] = x2 = makeref(&allocp[17]);
  allocp[18] = a0;
  allocp[19] = a2;
  allocp[20] = a3;
  allocp[21] = a4;
  allocp[22] = a5;
  allocp[23] = x0;
  allocp[24] = x3 = makeref(&allocp[24]);
  allocp[25] = x4 = makeref(&allocp[25]);
  allocp[26] = x5 = makeref(&allocp[26]);
  allocp[27] = (q)(struct goalrec*)&allocp[15];
  allocp[28] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[29] = x6 = makeref(&allocp[29]);
  allocp[30] = x4;
  allocp[31] = x5;
  allocp[32] = makesym(functor_options_2);
  allocp[33] = x3;
  allocp[34] = x8 = makeref(&allocp[34]);
  x7 = makefunctor(&allocp[32]);
  allocp[35] = (q)(struct goalrec*)&allocp[27];
  allocp[36] = (q)(&predicate_parse__uty_xdecode__goal_4);
  allocp[37] = x9 = makeref(&allocp[37]);
  allocp[38] = x6;
  allocp[39] = x2;
  allocp[40] = x7;
  allocp[41] = (q)(struct goalrec*)&allocp[35];
  allocp[42] = (q)(&predicate_functor__table_xarg_3);
  allocp[43] = a7;
  allocp[44] = a0;
  allocp[45] = x9;
  qp = (struct goalrec*)&allocp[41];
  allocp += 46;
  proceed();
 add__bodyG_8_ext_interrupt:
  reasonp = 0l;
 add__bodyG_8_interrupt:
  goto interrupt_8;
 }

 add__bodyG__1_10_top: {
  q x0, x1;
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 add__bodyG__1_10_clear_reason:
  reasonp = reasons;
 add__bodyG__1_10_0:
 add__bodyG__1_10_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_userdef)) goto add__bodyG__1_10_4;
 add__bodyG__1_10_2:
  if (isref(a7)) goto add__bodyG__1_10_3;
  x0 = makesym(atom___);
  gblt_diff(a7,x0,add__bodyG__1_10_4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_makepb_xadd__bodyG__2_10);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_hb_xcheck__infile_6);
  allocp[14] = a7;
  allocp[15] = a8;
  allocp[16] = a9;
  allocp[17] = makesym(atom_head);
  allocp[18] = a3;
  allocp[19] = x1;
  qp = (struct goalrec*)&allocp[12];
  allocp += 20;
  proceed();
 add__bodyG__1_10_3:
  deref_and_jump(a7,add__bodyG__1_10_2);
  *reasonp++ =  a7;
  goto add__bodyG__1_10_4;
 case VARREF:
  deref_and_jump(a0,add__bodyG__1_10_1);
  *reasonp++ =  a0;
  goto add__bodyG__1_10_4;
  };
  goto add__bodyG__1_10_4;
 add__bodyG__1_10_4:
  otherwise(add__bodyG__1_10_interrupt);
  unify(a6, a5);
  proceed();
 add__bodyG__1_10_ext_interrupt:
  reasonp = 0l;
 add__bodyG__1_10_interrupt:
  goto interrupt_10;
 }

 add__bodyG__2_10_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 add__bodyG__2_10_clear_reason:
  reasonp = reasons;
 add__bodyG__2_10_0:
 add__bodyG__2_10_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto add__bodyG__2_10_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_no)):
  allocp[0] = makesym(functor_body__r_5);
  allocp[1] = a7;
  allocp[2] = a8;
  allocp[3] = a9;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = x2 = makeref(&allocp[5]);
  x0 = makefunctor(&allocp[0]);
  allocp[6] = a5;
  allocp[7] = x0;
  x3 = makecons(&allocp[6]);
  allocp += 8;
  unify_value(a6, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_makepb_xsearch__BArgs_6);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = x1;
  allocp[4] = x2;
  allocp[5] = a2;
  allocp[6] = a4;
  allocp[7] = x5 = makeref(&allocp[7]);
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[10] = x4;
  allocp[11] = x6 = makeref(&allocp[11]);
  allocp[12] = x5;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_makepb_xsearch__pred_4);
  allocp[15] = x4;
  allocp[16] = x7 = makeref(&allocp[16]);
  allocp[17] = a8;
  allocp[18] = a9;
  a0 = x7;
  a1 = a3;
  a2 = a7;
  qp = (struct goalrec*)&allocp[13];
  allocp += 19;
  execute(search__module_3_0);
  goto search__module_3_ext_interrupt;
 case symval(makesym(atom_yes)):
  unify(a6, a5);
  proceed();
  };
  goto add__bodyG__2_10_interrupt;
 case VARREF:
  deref_and_jump(a0,add__bodyG__2_10_1);
  *reasonp++ =  a0;
  goto add__bodyG__2_10_interrupt;
  };
  goto add__bodyG__2_10_interrupt;
 add__bodyG__2_10_ext_interrupt:
  reasonp = 0l;
 add__bodyG__2_10_interrupt:
  goto interrupt_10;
 }

 search__module_3_top: {
  q x0, x1, x2;
  qp = qp->next;
 search__module_3_clear_reason:
  reasonp = reasons;
 search__module_3_0:
 search__module_3_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 search__module_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto search__module_3_7;
  x1 = arg(x0, 0);
 search__module_3_3:
  if (isref(x1)) goto search__module_3_6;
 search__module_3_4:
  if (isref(x1)) goto search__module_3_5;
  if_not_equal(x1, a2, search__module_3_7);
  x2 = arg(x0, 1);
  unify(a0, x2);
  proceed();
 search__module_3_5:
  deref_and_jump(x1,search__module_3_4);
  *reasonp++ =  x1;
  goto search__module_3_7;
 search__module_3_6:
  deref_and_jump(x1,search__module_3_3);
  *reasonp++ =  x1;
  goto search__module_3_7;
 case VARREF:
  deref_and_jump(x0,search__module_3_2);
  *reasonp++ =  x0;
  goto search__module_3_7;
  };
  goto search__module_3_7;
 case ATOMIC:
  if (a1 != NILATOM) goto search__module_3_7;
  x0 = NILATOM;
  unify_value(a0, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,search__module_3_1);
  *reasonp++ =  a1;
  goto search__module_3_7;
  };
  goto search__module_3_7;
 search__module_3_7:
  otherwise(search__module_3_interrupt);
 search__module_3_8:
  switch (ptagof(a1)) {
 case CONS:
  a1 = cdr_of(a1);
  execute(search__module_3_0);
  goto search__module_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,search__module_3_8);
  *reasonp++ =  a1;
  goto search__module_3_interrupt;
  };
  goto search__module_3_interrupt;
 search__module_3_ext_interrupt:
  reasonp = 0l;
 search__module_3_interrupt:
  toppred = &predicate_makepb_xsearch__module_3;
  goto interrupt_3;
 }

 search__pred_4_top: {
  q x0, x1, x2;
  a3 = qp->args[3];
  qp = qp->next;
 search__pred_4_clear_reason:
  reasonp = reasons;
 search__pred_4_0:
 search__pred_4_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 search__pred_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_7)) goto search__pred_4_7;
  x1 = arg(x0, 0);
 search__pred_4_3:
  if (isref(x1)) goto search__pred_4_6;
 search__pred_4_4:
  if (isref(x1)) goto search__pred_4_5;
  if_not_equal(x1, a2, search__pred_4_7);
  x2 = arg(x0, 4);
  unify(x2, a0);
  proceed();
 search__pred_4_5:
  deref_and_jump(x1,search__pred_4_4);
  *reasonp++ =  x1;
  goto search__pred_4_7;
 search__pred_4_6:
  deref_and_jump(x1,search__pred_4_3);
  *reasonp++ =  x1;
  goto search__pred_4_7;
 case VARREF:
  deref_and_jump(x0,search__pred_4_2);
  *reasonp++ =  x0;
  goto search__pred_4_7;
  };
  goto search__pred_4_7;
 case ATOMIC:
  if (a1 != NILATOM) goto search__pred_4_7;
  x0 = NILATOM;
  unify_value(a0, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,search__pred_4_1);
  *reasonp++ =  a1;
  goto search__pred_4_7;
  };
  goto search__pred_4_7;
 search__pred_4_7:
  otherwise(search__pred_4_interrupt);
 search__pred_4_8:
  switch (ptagof(a1)) {
 case CONS:
  a1 = cdr_of(a1);
  execute(search__pred_4_0);
  goto search__pred_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,search__pred_4_8);
  *reasonp++ =  a1;
  goto search__pred_4_interrupt;
  };
  goto search__pred_4_interrupt;
 search__pred_4_ext_interrupt:
  reasonp = 0l;
 search__pred_4_interrupt:
  goto interrupt_4;
 }

 search__BArgs_6_top: {
  q x0, x1, x2, x3;
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 search__BArgs_6_clear_reason:
  reasonp = reasons;
 search__BArgs_6_0:
 search__BArgs_6_1:
  switch (ptagof(a5)) {
 case ATOMIC:
 search__BArgs_6_2:
  if (a5 != makeint(0L)) goto search__BArgs_6_3;
  x0 = makeint(0L);
  unify_value(a1, x0);
  x1 = makesym(atom_goal);
  unify_value(a2, x1);
  proceed();
 case VARREF:
  deref_and_jump(a5,search__BArgs_6_1);
  *reasonp++ =  a5;
  goto search__BArgs_6_3;
  };
  goto search__BArgs_6_3;
 search__BArgs_6_3:
  otherwise(search__BArgs_6_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_makepb_xsearch__Entries1_8);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = makeint(1L);
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = x0;
  allocp[14] = x1;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[17] = x0;
  allocp[18] = x3 = makeref(&allocp[18]);
  allocp[19] = x2;
  allocp[20] = (q)(struct goalrec*)&allocp[15];
  allocp[21] = (q)(&predicate_functor__table_xarg_3);
  allocp[22] = makeint(1L);
  allocp[23] = a0;
  allocp[24] = x0;
  qp = (struct goalrec*)&allocp[20];
  allocp += 25;
  proceed();
 search__BArgs_6_ext_interrupt:
  reasonp = 0l;
 search__BArgs_6_interrupt:
  goto interrupt_6;
 }

 search__Entries1_8_top: {
  q x0, x1, x2, x3;
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 search__Entries1_8_clear_reason:
  reasonp = reasons;
 search__Entries1_8_0:
 search__Entries1_8_1:
  if (!isint(a6)) goto search__Entries1_8_4;
 search__Entries1_8_2:
  if (!isint(a7)) goto search__Entries1_8_3;
  gblt_less(a6,a7,search__Entries1_8_5);
  x0 = makeint(0L);
  unify_value(a2, x0);
  x1 = makesym(atom_err);
  unify_value(a3, x1);
  proceed();
 search__Entries1_8_3:
  if (!isref(a7)) goto search__Entries1_8_5;
  deref_and_jump(a7,search__Entries1_8_2);
  *reasonp++ =  a7;
  goto search__Entries1_8_5;
 search__Entries1_8_4:
  if (!isref(a6)) goto search__Entries1_8_5;
  deref_and_jump(a6,search__Entries1_8_1);
  *reasonp++ =  a6;
  goto search__Entries1_8_5;
 search__Entries1_8_5:
  otherwise(search__Entries1_8_interrupt);
 search__Entries1_8_6:
  if (isref(a1)) goto search__Entries1_8_16;
  x1 = makeint(1L);
  gblt_arg(x1,a1,x0,search__Entries1_8_17);
 search__Entries1_8_7:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_goal_4)) goto search__Entries1_8_17;
  x2 = arg(x0, 0);
 search__Entries1_8_8:
  if (isref(x2)) goto search__Entries1_8_15;
 search__Entries1_8_9:
  if (isref(x2)) goto search__Entries1_8_14;
  if_not_equal(x2, a4, search__Entries1_8_17);
  x3 = arg(x0, 1);
 search__Entries1_8_10:
  if (isref(x3)) goto search__Entries1_8_13;
 search__Entries1_8_11:
  if (isref(x3)) goto search__Entries1_8_12;
  if_not_equal(x3, a5, search__Entries1_8_17);
  unify_value(a3, x0);
  unify(a2, a7);
  proceed();
 search__Entries1_8_12:
  deref_and_jump(x3,search__Entries1_8_11);
  *reasonp++ =  x3;
  goto search__Entries1_8_17;
 search__Entries1_8_13:
  deref_and_jump(x3,search__Entries1_8_10);
  *reasonp++ =  x3;
  goto search__Entries1_8_17;
 search__Entries1_8_14:
  deref_and_jump(x2,search__Entries1_8_9);
  *reasonp++ =  x2;
  goto search__Entries1_8_17;
 search__Entries1_8_15:
  deref_and_jump(x2,search__Entries1_8_8);
  *reasonp++ =  x2;
  goto search__Entries1_8_17;
 case VARREF:
  deref_and_jump(x0,search__Entries1_8_7);
  *reasonp++ =  x0;
  goto search__Entries1_8_17;
  };
  goto search__Entries1_8_17;
 search__Entries1_8_16:
  deref_and_jump(a1,search__Entries1_8_6);
  *reasonp++ =  a1;
  goto search__Entries1_8_17;
 search__Entries1_8_17:
  otherwise(search__Entries1_8_interrupt);
  x0 = makeint(1L);
  bblt_add_no_check_y(a7,x0,x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_makepb_xsearch__Entries1_8);
  allocp[2] = a0;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = x1;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[12] = a0;
  allocp[13] = x1;
  allocp[14] = x2;
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 search__Entries1_8_ext_interrupt:
  reasonp = 0l;
 search__Entries1_8_interrupt:
  goto interrupt_8;
 }
 interrupt_10:
  allocp[11] = a9;
 interrupt_9:
  allocp[10] = a8;
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_makepb);
}
