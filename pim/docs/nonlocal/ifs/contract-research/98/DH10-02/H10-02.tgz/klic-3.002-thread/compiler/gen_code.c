/* Compiled by KLIC compiler version 3.002 (Wed Sep 17 15:37:13 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_gen__code();
Const struct predicate predicate_gen__code_xmain_2 =
   { module_gen__code, 0, 2 };
Const struct predicate predicate_gen__code_xmodules_2 =
   { module_gen__code, 1, 2 };
Const struct predicate predicate_gen__code_xclauses_4 =
   { module_gen__code, 2, 4 };
Const struct predicate predicate_gen__code_xclause_2 =
   { module_gen__code, 3, 2 };
Const struct predicate predicate_gen__code_xgoals_4 =
   { module_gen__code, 4, 4 };
Const struct predicate predicate_gen__code_xremove__pragma_2 =
   { module_gen__code, 5, 2 };
extern Const struct predicate predicate_integer__arithmetics_xadd_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_xsetarg_4;
extern Const struct predicate predicate_functor__table_xfunctor_3;
extern Const struct predicate predicate_parse__uty_xdecode__goal_4;
extern Const struct predicate predicate_parse__uty_xencode__goal_4;
extern Const struct predicate predicate_io_xoutstream_1;

module module_gen__code(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  static Const q cons_const_0[] = {
    NILATOM,
    makesym(atom_nl),
  };
  static Const q funct_const_1[] = {
    makesym(functor_print_1),
    makesym(atom__40thread),
  };
  static Const q cons_const_2[] = {
    makecons(cons_const_0),
    makefunctor(funct_const_1),
  };
  q a0, a1, a2, a3;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, main_2_top);
    case_pred(1, modules_2_top);
    case_pred(2, clauses_4_top);
    case_pred(3, clause_2_top);
    case_pred(4, goals_4_top);
    last_case_pred(5, remove__pragma_2_top);
  }

 main_2_top: {
  qp = qp->next;
 main_2_clear_reason:
  reasonp = reasons;
 main_2_0:
  execute(modules_2_0);
  goto modules_2_ext_interrupt;
 main_2_ext_interrupt:
  reasonp = 0l;
 main_2_interrupt:
  goto interrupt_2;
 }

 modules_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  qp = qp->next;
 modules_2_clear_reason:
  reasonp = reasons;
 modules_2_0:
 modules_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 modules_2_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto modules_2_interrupt;
  allocp[0] = makesym(functor_module_2);
  x2 = arg(x0, 0);
  allocp[1] = x2;
  allocp[2] = x3 = makeref(&allocp[2]);
  x1 = makefunctor(&allocp[0]);
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = x1;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a1, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_gen__code_xmodules_2);
  x6 = cdr_of(a0);
  allocp[2] = x6;
  allocp[3] = x5;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_gen__code_xclauses_4);
  allocp[6] = makeint(1L);
  allocp[7] = x7 = makeref(&allocp[7]);
  x8 = arg(x0, 1);
  allocp[8] = x8;
  allocp[9] = x3;
  allocp[10] = (q)(struct goalrec*)&allocp[4];
  allocp[11] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[12] = x8;
  allocp[13] = x9 = makeref(&allocp[13]);
  allocp[14] = x7;
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(x0,modules_2_2);
  *reasonp++ =  x0;
  goto modules_2_interrupt;
  };
  goto modules_2_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto modules_2_interrupt;
  unify_value(a1, a0);
  proceed();
 case VARREF:
  deref_and_jump(a0,modules_2_1);
  *reasonp++ =  a0;
  goto modules_2_interrupt;
  };
  goto modules_2_interrupt;
 modules_2_ext_interrupt:
  reasonp = 0l;
 modules_2_interrupt:
  toppred = &predicate_gen__code_xmodules_2;
  goto interrupt_2;
 }

 clauses_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 clauses_4_clear_reason:
  reasonp = reasons;
 clauses_4_0:
 clauses_4_1:
  if (!isint(a0)) goto clauses_4_5;
 clauses_4_2:
  if (!isint(a1)) goto clauses_4_4;
  gblt_less_or_eq(a0,a1,clauses_4_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_gen__code_xclauses_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x0;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[13] = a0;
  allocp[14] = a2;
  allocp[15] = x2 = makeref(&allocp[15]);
  allocp[16] = x1;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_gen__code_xclause_2);
  allocp[19] = x3 = makeref(&allocp[19]);
  allocp[20] = x2;
  allocp[21] = (q)(struct goalrec*)&allocp[17];
  allocp[22] = (q)(&predicate_functor__table_xarg_3);
  allocp[23] = a0;
  allocp[24] = a2;
  allocp[25] = x3;
  qp = (struct goalrec*)&allocp[21];
  allocp += 26;
  proceed();
 clauses_4_3:
  gblt_greater(a0,a1,clauses_4_interrupt);
  unify(a3, a2);
  proceed();
 clauses_4_4:
  if (!isref(a1)) goto clauses_4_interrupt;
  deref_and_jump(a1,clauses_4_2);
  *reasonp++ =  a1;
  goto clauses_4_interrupt;
 clauses_4_5:
  if (!isref(a0)) goto clauses_4_interrupt;
  deref_and_jump(a0,clauses_4_1);
  *reasonp++ =  a0;
  goto clauses_4_interrupt;
 clauses_4_ext_interrupt:
  reasonp = 0l;
 clauses_4_interrupt:
  goto interrupt_4;
 }

 clause_2_top: {
  q x0, x1, x2, x3;
  qp = qp->next;
 clause_2_clear_reason:
  reasonp = reasons;
 clause_2_0:
 clause_2_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_clause_4)) goto clause_2_2;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = makeint(3L);
  allocp[3] = a0;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = a1;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_gen__code_xgoals_4);
  allocp[8] = makeint(1L);
  allocp[9] = x1 = makeref(&allocp[9]);
  x2 = arg(a0, 2);
  allocp[10] = x2;
  allocp[11] = x0;
  allocp[12] = (q)(struct goalrec*)&allocp[6];
  allocp[13] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[14] = x2;
  allocp[15] = x3 = makeref(&allocp[15]);
  allocp[16] = x1;
  qp = (struct goalrec*)&allocp[12];
  allocp += 17;
  proceed();
 case VARREF:
  deref_and_jump(a0,clause_2_1);
  *reasonp++ =  a0;
  goto clause_2_2;
  };
  goto clause_2_2;
 clause_2_2:
  otherwise(clause_2_interrupt);
  unify(a1, a0);
  proceed();
 clause_2_ext_interrupt:
  reasonp = 0l;
 clause_2_interrupt:
  goto interrupt_2;
 }

 goals_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 goals_4_clear_reason:
  reasonp = reasons;
 goals_4_0:
 goals_4_1:
  if (!isint(a0)) goto goals_4_5;
 goals_4_2:
  if (!isint(a1)) goto goals_4_4;
  gblt_less_or_eq(a0,a1,goals_4_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_gen__code_xgoals_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x0;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[13] = a0;
  allocp[14] = a2;
  allocp[15] = x2 = makeref(&allocp[15]);
  allocp[16] = x1;
  allocp[17] = makesym(functor_options_2);
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = x5 = makeref(&allocp[19]);
  x3 = makefunctor(&allocp[17]);
  allocp[20] = (q)(struct goalrec*)&allocp[11];
  allocp[21] = (q)(&predicate_parse__uty_xencode__goal_4);
  allocp[22] = x6 = makeref(&allocp[22]);
  allocp[23] = x7 = makeref(&allocp[23]);
  allocp[24] = x3;
  allocp[25] = x2;
  allocp[26] = (q)(struct goalrec*)&allocp[20];
  allocp[27] = (q)(&predicate_gen__code_xremove__pragma_2);
  allocp[28] = x8 = makeref(&allocp[28]);
  allocp[29] = x5;
  allocp[30] = makesym(functor_options_2);
  allocp[31] = x4;
  allocp[32] = x8;
  x9 = makefunctor(&allocp[30]);
  allocp[33] = (q)(struct goalrec*)&allocp[26];
  allocp[34] = (q)(&predicate_parse__uty_xdecode__goal_4);
  allocp[35] = x10 = makeref(&allocp[35]);
  allocp[36] = x6;
  allocp[37] = x7;
  allocp[38] = x9;
  allocp[39] = (q)(struct goalrec*)&allocp[33];
  allocp[40] = (q)(&predicate_functor__table_xarg_3);
  allocp[41] = a0;
  allocp[42] = a2;
  allocp[43] = x10;
  qp = (struct goalrec*)&allocp[39];
  allocp += 44;
  proceed();
 goals_4_3:
  gblt_greater(a0,a1,goals_4_interrupt);
  unify(a3, a2);
  proceed();
 goals_4_4:
  if (!isref(a1)) goto goals_4_interrupt;
  deref_and_jump(a1,goals_4_2);
  *reasonp++ =  a1;
  goto goals_4_interrupt;
 goals_4_5:
  if (!isref(a0)) goto goals_4_interrupt;
  deref_and_jump(a0,goals_4_1);
  *reasonp++ =  a0;
  goto goals_4_interrupt;
 goals_4_ext_interrupt:
  reasonp = 0l;
 goals_4_interrupt:
  goto interrupt_4;
 }

 remove__pragma_2_top: {
  q x0;
  qp = qp->next;
 remove__pragma_2_clear_reason:
  reasonp = reasons;
 remove__pragma_2_0:
 remove__pragma_2_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_functor_1:
  x0 = arg(a0, 0);
 remove__pragma_2_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_lower__priority)) goto remove__pragma_2_4;
  unify_value(a1, a0);
  proceed();
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_node_1:
  unify_value(a1, a0);
  proceed();
 case functor_priority_1:
  unify_value(a1, a0);
  proceed();
 case functor_lower__priority_1:
  unify_value(a1, a0);
  proceed();
  };
  goto remove__pragma_2_4;
 case VARREF:
  deref_and_jump(x0,remove__pragma_2_2);
  *reasonp++ =  x0;
  goto remove__pragma_2_4;
  };
  goto remove__pragma_2_4;
 case functor_atom_1:
  x0 = arg(a0, 0);
 remove__pragma_2_3:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (isint(x0)) goto remove__pragma_2_4;
  switch (symval(x0)) {
 case symval(makesym(atom_sequential)):
  unify_value(a1, a0);
  proceed();
 case symval(makesym(atom_thread)):
  unify_value(a1, a0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_io_xoutstream_1);
  allocp[2] = makecons(cons_const_2);
  qp = (struct goalrec*)&allocp[0];
  allocp += 3;
  proceed();
  };
  goto remove__pragma_2_4;
 case VARREF:
  deref_and_jump(x0,remove__pragma_2_3);
  *reasonp++ =  x0;
  goto remove__pragma_2_4;
  };
  goto remove__pragma_2_4;
  };
  goto remove__pragma_2_4;
 case VARREF:
  deref_and_jump(a0,remove__pragma_2_1);
  *reasonp++ =  a0;
  goto remove__pragma_2_4;
  };
  goto remove__pragma_2_4;
 remove__pragma_2_4:
  otherwise(remove__pragma_2_interrupt);
  x0 = makesym(atom___);
  unify_value(a1, x0);
  proceed();
 remove__pragma_2_ext_interrupt:
  reasonp = 0l;
 remove__pragma_2_interrupt:
  goto interrupt_2;
 }
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_gen__code);
}
