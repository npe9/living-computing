/* Compiled by KLIC compiler version 3.002 (Wed Sep 17 15:37:13 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"
#include <ctype.h>

module module_klic__comp__write();
Const struct predicate predicate_klic__comp__write_xwrite__KTH__declare__external_2 =
   { module_klic__comp__write, 0, 2 };
Const struct predicate predicate_klic__comp__write_xwrite__KTH__call__native_2 =
   { module_klic__comp__write, 1, 2 };
Const struct predicate predicate_klic__comp__write_xwrite__out_3 =
   { module_klic__comp__write, 2, 3 };
Const struct predicate predicate_klic__comp__write_xdeclare__const_5 =
   { module_klic__comp__write, 3, 5 };
Const struct predicate predicate_klic__comp__write_xdeclare__const_6 =
   { module_klic__comp__write, 4, 6 };
Const struct predicate predicate_klic__comp__write_xdeclare__const__list_6 =
   { module_klic__comp__write, 5, 6 };
Const struct predicate predicate_klic__comp__write_xwrite__const__elems_3 =
   { module_klic__comp__write, 6, 3 };
Const struct predicate predicate_klic__comp__write_xwrite__const__elem_3 =
   { module_klic__comp__write, 7, 3 };
Const struct predicate predicate_klic__comp__write_xwrite__string__body_4 =
   { module_klic__comp__write, 8, 4 };
Const struct predicate predicate_klic__comp__write_xwrite__character__constants_5 =
   { module_klic__comp__write, 9, 5 };
Const struct predicate predicate_klic__comp__write_xwrite__string__elements_5 =
   { module_klic__comp__write, 10, 5 };
Const struct predicate predicate_klic__comp__write_xwrite__string__element_3 =
   { module_klic__comp__write, 11, 3 };
Const struct predicate predicate_klic__comp__write_xtake__seqnum_4 =
   { module_klic__comp__write, 12, 4 };
Const struct predicate predicate_klic__comp__write_xtake__seqnum_5 =
   { module_klic__comp__write, 13, 5 };
Const struct predicate predicate_klic__comp__write_xwrite__native__pred__structs_5 =
   { module_klic__comp__write, 14, 5 };
Const struct predicate predicate_klic__comp__write_xwrite__pred__structs_4 =
   { module_klic__comp__write, 15, 4 };
Const struct predicate predicate_klic__comp__write_xdeclare__externals_3 =
   { module_klic__comp__write, 16, 3 };
Const struct predicate predicate_klic__comp__write_xdeclare__one__external_3 =
   { module_klic__comp__write, 17, 3 };
Const struct predicate predicate_klic__comp__write_xpred__min__max_5 =
   { module_klic__comp__write, 18, 5 };
Const struct predicate predicate_klic__comp__write_xdeclare__registers_4 =
   { module_klic__comp__write, 19, 4 };
Const struct predicate predicate_klic__comp__write_xwrite__comma__list_5 =
   { module_klic__comp__write, 20, 5 };
Const struct predicate predicate_klic__comp__write_xwrite__comma__list1_5 =
   { module_klic__comp__write, 21, 5 };
Const struct predicate predicate_klic__comp__write_xwrite__native__pred__dispatch_4 =
   { module_klic__comp__write, 22, 4 };
Const struct predicate predicate_klic__comp__write_xwrite__pred__dispatch_3 =
   { module_klic__comp__write, 23, 3 };
Const struct predicate predicate_klic__comp__write_xwrite__call__native__pred_3 =
   { module_klic__comp__write, 24, 3 };
Const struct predicate predicate_klic__comp__write_xwrite__predicates_6 =
   { module_klic__comp__write, 25, 6 };
Const struct predicate predicate_klic__comp__write_xwrite__predicates__1_6 =
   { module_klic__comp__write, 26, 6 };
Const struct predicate predicate_klic__comp__write_xwrite__get__args_4 =
   { module_klic__comp__write, 27, 4 };
Const struct predicate predicate_klic__comp__write_xwrite__get__args__stack_4 =
   { module_klic__comp__write, 28, 4 };
Const struct predicate predicate_klic__comp__write_xwrite__interrupt__call_4 =
   { module_klic__comp__write, 29, 4 };
Const struct predicate predicate_klic__comp__write_xwrite__header__file_3 =
   { module_klic__comp__write, 30, 3 };
Const struct predicate predicate_klic__comp__write_xwrite__ext__entries_3 =
   { module_klic__comp__write, 31, 3 };
Const struct predicate predicate_klic__comp__write_xwrite__ext__entry_3 =
   { module_klic__comp__write, 32, 3 };
Const struct predicate predicate_klic__comp__write_xwrite__defined__preds_4 =
   { module_klic__comp__write, 33, 4 };
Const struct predicate predicate_klic__comp__write_xwrite__atom_3 =
   { module_klic__comp__write, 34, 3 };
Const struct predicate predicate_klic__comp__write_xwrite__funct__name_4 =
   { module_klic__comp__write, 35, 4 };
Const struct predicate predicate_klic__comp__write_xwrite__pred__name_5 =
   { module_klic__comp__write, 36, 5 };
Const struct predicate predicate_klic__comp__write_xsort__info_2 =
   { module_klic__comp__write, 37, 2 };
Const struct predicate predicate_klic__comp__write_xsort__info_3 =
   { module_klic__comp__write, 38, 3 };
Const struct predicate predicate_klic__comp__write_xpartition_4 =
   { module_klic__comp__write, 39, 4 };
extern Const struct predicate predicate_integer__arithmetics_xadd_3;
extern Const struct predicate predicate_klic__comp__obj_xklicformat_3;
extern Const struct predicate predicate_klic__comp__obj_xklicformat_4;
extern Const struct predicate predicate_klic__comp__obj_xwrite__object_4;
extern Const struct predicate predicate_klic__comp__util_xvector__to__list_2;
extern Const struct predicate predicate_klic__comp__util_xuniv_2;
extern Const struct predicate predicate_klic__comp__util_xmin_3;
extern Const struct predicate predicate_klic__comp__util_xmax_3;
extern Const struct predicate predicate_klic__comp__util_xmember_3;
extern Const struct predicate predicate_klic__comp__util_xqsort_2;
extern Const struct predicate predicate_klic__comp__extern_xmake__ext__table_3;
declare_method_table_of(vector);

module module_klic__comp__write(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  static Const unsigned char strconst_body_0[28] =
    {'\n',' ',' ','q',' ','*','r','e','a','s','o','n','p',';','\n',' ','m','o','d','u','l','e','_','t','o','p',':','\n',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_0 =
      declare_string_constant_8(strconst_body_0,28);
  static Const unsigned char strconst_body_1[56] =
    {' ',' ',' ',' ','c','a','s','e','_','p','r','e','d','(','~','d',',',' ','c','a','l','l','_','n','a','t','i','v','e','_','p','r','e','d','i','c','a','t','e','_','~','q','_','x','~','q','_','~','d','_','t','o','p',')',';','\n',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_1 =
      declare_string_constant_8(strconst_body_1,56);
  static Const unsigned char strconst_body_2[32] =
    "    case_pred(~d, ~q_~d_top);\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_2 =
      declare_string_constant_8(strconst_body_2,30);
  static Const unsigned char strconst_body_3[36] =
    "    last_case_pred(~d, ~q_~d_top);\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_3 =
      declare_string_constant_8(strconst_body_3,35);
  static Const unsigned char strconst_body_4[32] =
    "    makecons(cons_const_~d),\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_4 =
      declare_string_constant_8(strconst_body_4,29);
  static Const unsigned char strconst_body_5[32] =
    "    makefloat(float_const_~d),\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_5 =
      declare_string_constant_8(strconst_body_5,31);
  static Const unsigned char strconst_body_6[36] =
    "    makefunctor(&string_const_~d),\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_6 =
      declare_string_constant_8(strconst_body_6,35);
  static Const unsigned char strconst_body_7[36] =
    "    makefunctor(&vector_const_~d),\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_7 =
      declare_string_constant_8(strconst_body_7,35);
  static Const unsigned char strconst_body_8[36] =
    "    makefunctor(funct_const_~d),\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_8 =
      declare_string_constant_8(strconst_body_8,33);
  static Const unsigned char strconst_body_9[20] =
    "    makeint(~d),\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_9 =
      declare_string_constant_8(strconst_body_9,17);
  static Const unsigned char strconst_body_10[28] =
    {' ',' ',' ',' ','m','a','k','e','p','r','e','d','(','m','o','d','_','c','o','n','s','t','_','~','d',')',',','\n',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_10 =
      declare_string_constant_8(strconst_body_10,28);
  static Const unsigned char strconst_body_11[32] =
    "    makepred(pred_const_~d),\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_11 =
      declare_string_constant_8(strconst_body_11,29);
  static Const unsigned char strconst_body_12[8] =
    {' ',' ',' ',' ','~','a',',','\n',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_12 =
      declare_string_constant_8(strconst_body_12,8);
  static Const unsigned char strconst_body_13[24] =
    "  KTH_declare_local;\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_13 =
      declare_string_constant_8(strconst_body_13,21);
  static Const unsigned char strconst_body_14[24] =
    "  a~d = qp->args[~d];\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_14 =
      declare_string_constant_8(strconst_body_14,22);
  static Const unsigned char strconst_body_15[20] =
    {' ',' ','a','~','d',' ','=',' ','s','t','a','c','k','p','[','~','d',']',';','\n',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_15 =
      declare_string_constant_8(strconst_body_15,20);
  static Const unsigned char strconst_body_16[140] =
    "  declare_method_table_of(byte__string);\n  static Const string_structure_type_~d string_const_~d =\n      declare_string_constant_~d(0,0);\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_16 =
      declare_string_constant_8(strconst_body_16,138);
  static Const unsigned char strconst_body_17[156] =
    "  declare_method_table_of(byte__string);\n  static Const string_structure_type_~d string_const_~d =\n      declare_string_constant_~d(strconst_body_~d,~d);\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_17 =
      declare_string_constant_8(strconst_body_17,154);
  static Const unsigned char strconst_body_18[120] =
    "  declare_method_table_of(float);\n  static Const float_structure_type float_const_~d =\n    declare_float_constant(~g);\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_18 =
      declare_string_constant_8(strconst_body_18,119);
  static Const unsigned char strconst_body_19[160] =
    {' ',' ','d','e','c','l','a','r','e','_','m','e','t','h','o','d','_','t','a','b','l','e','_','o','f','(','m','o','d','u','l','e',')',';','\n',' ',' ','e','x','t','e','r','n',' ','m','o','d','u','l','e',' ','m','o','d','u','l','e','_','~','q','(',')',';','\n',' ',' ','s','t','a','t','i','c',' ','C','o','n','s','t',' ','m','o','d','u','l','e','_','s','t','r','u','c','t','u','r','e','_','t','y','p','e',' ','m','o','d','_','c','o','n','s','t','_','~','d',' ','=','\n',' ',' ',' ',' ','d','e','c','l','a','r','e','_','m','o','d','u','l','e','_','c','o','n','s','t','a','n','t','(','m','o','d','u','l','e','_','~','q',',',' ','~','a',')',';','\n',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_19 =
      declare_string_constant_8(strconst_body_19,160);
  static Const unsigned char strconst_body_20[144] =
    "  declare_method_table_of(predicate);\n  static Const predicate_structure_type pred_const_~d =\n    declare_pred_constant(~p, mod_const_~d, ~a);\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_20 =
      declare_string_constant_8(strconst_body_20,143);
  static Const unsigned char strconst_body_21[128] =
    "  declare_method_table_of(vector);\n  static Const vector_structure_type vector_const_~d =\n      declare_vector_constant(0,0);\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_21 =
      declare_string_constant_8(strconst_body_21,126);
  static Const unsigned char strconst_body_22[144] =
    "  declare_method_table_of(vector);\n  static Const vector_structure_type vector_const_~d =\n      declare_vector_constant(vectconst_body_~d,~d);\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_22 =
      declare_string_constant_8(strconst_body_22,143);
  static Const unsigned char strconst_body_23[24] =
    {' ',' ','g','o','t','o',' ','i','n','t','e','r','r','u','p','t','_','~','d',';','\n',' ','}','\n',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_23 =
      declare_string_constant_8(strconst_body_23,24);
  static Const unsigned char strconst_body_24[4] =
    {' ',' ','q',' ',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_24 =
      declare_string_constant_8(strconst_body_24,4);
  static Const unsigned char strconst_body_25[16] =
    {' ',' ','s','t','a','c','k','p',' ','-','=',' ','~','d',';','\n',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_25 =
      declare_string_constant_8(strconst_body_25,16);
  static Const unsigned char strconst_body_26[40] =
    "  static Const q cons_const_~d[] = {\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_26 =
      declare_string_constant_8(strconst_body_26,37);
  static Const unsigned char strconst_body_27[56] =
    "  static Const q funct_const_~d[] = {\n    makesym(~f),\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_27 =
      declare_string_constant_8(strconst_body_27,55);
  static Const unsigned char strconst_body_28[44] =
    "  static Const q vectconst_body_~d[] = {\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_28 =
      declare_string_constant_8(strconst_body_28,41);
  static Const unsigned char strconst_body_29[56] =
    {' ',' ','s','t','a','t','i','c',' ','C','o','n','s','t',' ','u','n','s','i','g','n','e','d',' ','c','h','a','r',' ','s','t','r','c','o','n','s','t','_','b','o','d','y','_','~','d','[','~','d',']',' ','=','\n',' ',' ',' ',' ',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_29 =
      declare_string_constant_8(strconst_body_29,56);
  static Const unsigned char strconst_body_30[24] =
    "  switch_on_pred() {\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_30 =
      declare_string_constant_8(strconst_body_30,21);
  static Const unsigned char strconst_body_31[20] =
    "  toppred = &~p;\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_31 =
      declare_string_constant_8(strconst_body_31,17);
  static Const unsigned char strconst_body_32[4] =
    {' ',' ','}','\n',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_32 =
      declare_string_constant_8(strconst_body_32,4);
  static Const unsigned char strconst_body_33[8] =
    "  };\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_33 =
      declare_string_constant_8(strconst_body_33,5);
  static Const unsigned char strconst_body_34[488] =
    {' ','c','a','l','l','_','n','a','t','i','v','e','_','p','r','e','d','i','c','a','t','e','_','~','q','_','x','~','q','_','~','d','_','t','o','p',':','{','\n',' ','i','n','t',' ','t',' ','=',' ','K','T','H','_','c','u','r','r','e','n','t','_','t','h','r','e','a','d',';','\n',' ','i','n','t',' ','i',';','\n',' ','a','l','l','o','c','p','[','0',']',' ','=',' ','(','q',')','q','p',';','\n',' ','a','l','l','o','c','p','[','1',']',' ','=',' ','(','q',')','(','&','K','T','H','_','c','o','n','t','i','n','u','e','_','t','h','r','e','a','d','_','p','r','e','d',')',';','\n',' ','a','l','l','o','c','p','[','2',']',' ','=',' ','m','a','k','e','i','n','t','(','t',')',';','\n',' ','a','l','l','o','c','p','[','3',']',' ','=',' ','(','q',')','(','s','t','r','u','c','t',' ','g','o','a','l','r','e','c','*',')','&','a','l','l','o','c','p','[','0',']',';','\n',' ','a','l','l','o','c','p','[','4',']',' ','=',' ','(','q',')','(','&','p','r','e','d','i','c','a','t','e','_','~','q','_','x','~','q','_','~','d',')',';','\n',' ','q','p',' ','=',' ','c','u','r','r','e','n','t','_','q','u','e','u','e',' ','=',' ','(','s','t','r','u','c','t',' ','g','o','a','l','r','e','c','*',')','(','&','a','l','l','o','c','p','[','3',']',')',';','\n',' ','a','l','l','o','c','p','+','=','5',';','\n',' ',' ','f','o','r','(','i','=','0',';','i',' ','<',' ','~','d',';','i','+','+',')',' ','*','a','l','l','o','c','p','+','+',' ','=',' ','s','t','a','c','k','p','[','-','~','d',' ','+',' ','i',']',';','\n',' ','K','T','H','_','t','h','r','e','a','d','_','t','a','b','l','e','[','t',']','.','s','t','a','c','k','p',' ','=',' ','s','t','a','c','k','p',' ','-',' ','~','d',';','\n',' ','K','T','H','_','c','u','r','r','e','n','t','_','s','t','a','c','k','p',' ','=',' ','(','q','*',')','0',';','\n',' ','h','e','a','p','p','=','a','l','l','o','c','p',';',' ','r','e','t','u','r','n',' ','(','m','o','d','u','l','e',')','(','q','p','-','>','p','r','e','d','-','>','f','u','n','c',')',';','}','\n',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_34 =
      declare_string_constant_8(strconst_body_34,488);
  static Const unsigned char strconst_body_35[40] =
    " interrupt_0:\n  KTH_interrupt_goal();\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_35 =
      declare_string_constant_8(strconst_body_35,38);
  static Const unsigned char strconst_body_36[36] =
    " interrupt_~d:\n  stackp[~d] = a~d;\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_36 =
      declare_string_constant_8(strconst_body_36,35);
  static Const unsigned char strconst_body_37[56] =
    " proceed_label:\n  KTH_loop_within_module(module_~q);\n}\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_37 =
      declare_string_constant_8(strconst_body_37,55);
  static Const unsigned char strconst_body_38[44] =
    " ~q_~d_clear_reason:\n  reasonp = reasons;\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_38 =
      declare_string_constant_8(strconst_body_38,42);
  static Const unsigned char strconst_body_39[56] =
    {' ','~','q','_','~','d','_','e','x','t','_','i','n','t','e','r','r','u','p','t',':','\n',' ',' ','r','e','a','s','o','n','p',' ','=',' ','0','l',';','\n',' ','~','q','_','~','d','_','i','n','t','e','r','r','u','p','t',':','\n',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_39 =
      declare_string_constant_8(strconst_body_39,56);
  static Const unsigned char strconst_body_40[16] =
    " ~q_~d_top: {\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_40 =
      declare_string_constant_8(strconst_body_40,14);
  static Const unsigned char strconst_body_41[84] =
    "Const struct predicate call_native_predicate_~q_x~q_~d =\n  { module_~q, ~d, ~d };\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_41 =
      declare_string_constant_8(strconst_body_41,82);
  static Const unsigned char strconst_body_42[56] =
    "Const struct predicate ~p =\n   { module_~q, ~d, ~d };\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_42 =
      declare_string_constant_8(strconst_body_42,54);
  static Const unsigned char strconst_body_43[20] =
    "KTH_call_native;\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_43 =
      declare_string_constant_8(strconst_body_43,17);
  static Const unsigned char strconst_body_44[24] =
    "KTH_declare_external;\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_44 =
      declare_string_constant_8(strconst_body_44,22);
  static Const unsigned char strconst_body_45[4] =
    "a";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_45 =
      declare_string_constant_8(strconst_body_45,1);
  static Const unsigned char strconst_body_46[8] =
    {'a','t','o','m','_','~','q','\n',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_46 =
      declare_string_constant_8(strconst_body_46,8);
  static Const unsigned char strconst_body_47[32] =
    "declare_method_table_of(~q);\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_47 =
      declare_string_constant_8(strconst_body_47,29);
  static Const unsigned char strconst_body_48[36] =
    "extern Const struct predicate ~p;\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_48 =
      declare_string_constant_8(strconst_body_48,34);
  static Const unsigned char strconst_body_49[24] =
    "extern q ~q_g_new();\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_49 =
      declare_string_constant_8(strconst_body_49,21);
  static Const unsigned char strconst_body_50[16] =
    "functor_~q_~d";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_50 =
      declare_string_constant_8(strconst_body_50,13);
  static Const unsigned char strconst_body_51[12] =
    {'m','a','k','e','i','n','t','(','~','d','L',')',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_51 =
      declare_string_constant_8(strconst_body_51,12);
  static Const unsigned char strconst_body_52[16] =
    {'m','a','k','e','s','y','m','(','a','t','o','m','_','~','q',')',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_52 =
      declare_string_constant_8(strconst_body_52,16);
  static Const unsigned char strconst_body_53[20] =
    {'m','o','d','u','l','e',' ','m','o','d','u','l','e','_','~','q','(',')',';','\n',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_53 =
      declare_string_constant_8(strconst_body_53,20);
  static Const unsigned char strconst_body_54[160] =
    "module module_~q(glbl, qp, allocp, toppred)\n  struct global_variables *glbl;\n  struct goalrec *qp;\n  register q *allocp;\n  Const struct predicate *toppred;\n{\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_54 =
      declare_string_constant_8(strconst_body_54,158);
  static Const unsigned char strconst_body_55[12] =
    "module_~q\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_55 =
      declare_string_constant_8(strconst_body_55,10);
  static Const unsigned char strconst_body_56[20] =
    "predicate_~q_x~q_~d";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_56 =
      declare_string_constant_8(strconst_body_56,19);
  static Const unsigned char strconst_body_57[16] =
    "ref_class_~q\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_57 =
      declare_string_constant_8(strconst_body_57,13);
  static Const unsigned char strconst_body_58[16] =
    "ref_module_~q\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_58 =
      declare_string_constant_8(strconst_body_58,14);
  static Const unsigned char strconst_body_59[4] =
    "x";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_59 =
      declare_string_constant_8(strconst_body_59,1);
  static Const unsigned char strconst_body_60[4] =
    "~p\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_60 =
      declare_string_constant_8(strconst_body_60,3);
  static Const unsigned char strconst_body_61[4] =
    "~s";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_61 =
      declare_string_constant_8(strconst_body_61,2);
  static Const unsigned char strconst_body_62[4] =
    {'~','s','~','d',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_62 =
      declare_string_constant_8(strconst_body_62,4);
  static Const unsigned char strconst_body_63[8] =
    "~s~d, ";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_63 =
      declare_string_constant_8(strconst_body_63,6);
  static Const unsigned char strconst_body_64[4] =
    "\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_64 =
      declare_string_constant_8(strconst_body_64,1);
  static Const q funct_const_65[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_64),
  };
  static Const unsigned char strconst_body_66[4] =
    " ";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_66 =
      declare_string_constant_8(strconst_body_66,1);
  static Const q funct_const_67[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_66),
  };
  static Const unsigned char strconst_body_68[8] =
    "  };\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_68 =
      declare_string_constant_8(strconst_body_68,5);
  static Const q funct_const_69[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_68),
  };
  static Const unsigned char strconst_body_70[4] =
    "\"";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_70 =
      declare_string_constant_8(strconst_body_70,1);
  static Const q funct_const_71[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_70),
  };
  static Const unsigned char strconst_body_72[4] =
    "\'";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_72 =
      declare_string_constant_8(strconst_body_72,1);
  static Const q funct_const_73[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_72),
  };
  static Const unsigned char strconst_body_74[4] =
    "\',";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_74 =
      declare_string_constant_8(strconst_body_74,2);
  static Const q funct_const_75[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_74),
  };
  static Const unsigned char strconst_body_76[4] =
    ";\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_76 =
      declare_string_constant_8(strconst_body_76,2);
  static Const q funct_const_77[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_76),
  };
  static Const unsigned char strconst_body_78[8] =
    "NILATOM";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_78 =
      declare_string_constant_8(strconst_body_78,7);
  static Const q funct_const_79[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_78),
  };
  static Const unsigned char strconst_body_80[12] =
    "PERIODATOM";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_80 =
      declare_string_constant_8(strconst_body_80,10);
  static Const q funct_const_81[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_80),
  };
  static Const unsigned char strconst_body_82[4] =
    "\\\"";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_82 =
      declare_string_constant_8(strconst_body_82,2);
  static Const q funct_const_83[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_82),
  };
  static Const unsigned char strconst_body_84[4] =
    "\\\'";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_84 =
      declare_string_constant_8(strconst_body_84,2);
  static Const q funct_const_85[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_84),
  };
  static Const unsigned char strconst_body_86[4] =
    "\\\\";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_86 =
      declare_string_constant_8(strconst_body_86,2);
  static Const q funct_const_87[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_86),
  };
  static Const unsigned char strconst_body_88[4] =
    "\\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_88 =
      declare_string_constant_8(strconst_body_88,2);
  static Const q funct_const_89[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_88),
  };
  static Const unsigned char strconst_body_90[4] =
    "\\t";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_90 =
      declare_string_constant_8(strconst_body_90,2);
  static Const q funct_const_91[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_90),
  };
  static Const unsigned char strconst_body_92[4] =
    "{";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_92 =
      declare_string_constant_8(strconst_body_92,1);
  static Const q funct_const_93[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_92),
  };
  static Const unsigned char strconst_body_94[4] =
    "}";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_94 =
      declare_string_constant_8(strconst_body_94,1);
  static Const q funct_const_95[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_94),
  };
  q a0, a1, a2, a3, a4, a5;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, write__KTH__declare__external_2_top);
    case_pred(1, write__KTH__call__native_2_top);
    case_pred(2, write__out_3_top);
    case_pred(3, declare__const_5_top);
    case_pred(4, declare__const_6_top);
    case_pred(5, declare__const__list_6_top);
    case_pred(6, write__const__elems_3_top);
    case_pred(7, write__const__elem_3_top);
    case_pred(8, write__string__body_4_top);
    case_pred(9, write__character__constants_5_top);
    case_pred(10, write__string__elements_5_top);
    case_pred(11, write__string__element_3_top);
    case_pred(12, take__seqnum_4_top);
    case_pred(13, take__seqnum_5_top);
    case_pred(14, write__native__pred__structs_5_top);
    case_pred(15, write__pred__structs_4_top);
    case_pred(16, declare__externals_3_top);
    case_pred(17, declare__one__external_3_top);
    case_pred(18, pred__min__max_5_top);
    case_pred(19, declare__registers_4_top);
    case_pred(20, write__comma__list_5_top);
    case_pred(21, write__comma__list1_5_top);
    case_pred(22, write__native__pred__dispatch_4_top);
    case_pred(23, write__pred__dispatch_3_top);
    case_pred(24, write__call__native__pred_3_top);
    case_pred(25, write__predicates_6_top);
    case_pred(26, write__predicates__1_6_top);
    case_pred(27, write__get__args_4_top);
    case_pred(28, write__get__args__stack_4_top);
    case_pred(29, write__interrupt__call_4_top);
    case_pred(30, write__header__file_3_top);
    case_pred(31, write__ext__entries_3_top);
    case_pred(32, write__ext__entry_3_top);
    case_pred(33, write__defined__preds_4_top);
    case_pred(34, write__atom_3_top);
    case_pred(35, write__funct__name_4_top);
    case_pred(36, write__pred__name_5_top);
    case_pred(37, sort__info_2_top);
    case_pred(38, sort__info_3_top);
    last_case_pred(39, partition_4_top);
  }

 write__KTH__declare__external_2_top: {
  qp = qp->next;
 write__KTH__declare__external_2_clear_reason:
  reasonp = reasons;
 write__KTH__declare__external_2_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__obj_xklicformat_3);
  allocp[2] = makefunctor(&string_const_44);
  allocp[3] = a0;
  allocp[4] = a1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 write__KTH__declare__external_2_ext_interrupt:
  reasonp = 0l;
 write__KTH__declare__external_2_interrupt:
  goto interrupt_2;
 }

 write__KTH__call__native_2_top: {
  qp = qp->next;
 write__KTH__call__native_2_clear_reason:
  reasonp = reasons;
 write__KTH__call__native_2_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__obj_xklicformat_3);
  allocp[2] = makefunctor(&string_const_43);
  allocp[3] = a0;
  allocp[4] = a1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 write__KTH__call__native_2_ext_interrupt:
  reasonp = 0l;
 write__KTH__call__native_2_interrupt:
  goto interrupt_2;
 }

 write__out_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20, x21, x22, x23, x24, x25, x26, x27, x28, x29;
  a2 = qp->args[2];
  qp = qp->next;
 write__out_3_clear_reason:
  reasonp = reasons;
 write__out_3_0:
 write__out_3_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_module_3)) goto write__out_3_interrupt;
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_37);
  allocp[5] = x0;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a2;
  allocp[8] = (q)(struct goalrec*)&allocp[2];
  allocp[9] = (q)(&predicate_klic__comp__write_xwrite__interrupt__call_4);
  allocp[10] = x3 = makeref(&allocp[10]);
  allocp[11] = x3;
  allocp[12] = x4 = makeref(&allocp[12]);
  allocp[13] = x2;
  allocp[14] = (q)(struct goalrec*)&allocp[8];
  allocp[15] = (q)(&predicate_klic__comp__write_xwrite__call__native__pred_3);
  allocp[16] = x5 = makeref(&allocp[16]);
  allocp[17] = x6 = makeref(&allocp[17]);
  allocp[18] = x4;
  allocp[19] = (q)(struct goalrec*)&allocp[14];
  allocp[20] = (q)(&predicate_klic__comp__write_xwrite__predicates_6);
  x7 = arg(a0, 1);
  allocp[21] = x7;
  x8 = arg(a0, 0);
  allocp[22] = x8;
  allocp[23] = makeint(0L);
  x9 = arg(a0, 2);
  allocp[24] = x9;
  allocp[25] = x10 = makeref(&allocp[25]);
  allocp[26] = x6;
  allocp[27] = (q)(struct goalrec*)&allocp[19];
  allocp[28] = (q)(&predicate_klic__comp__obj_xklicformat_3);
  allocp[29] = makefunctor(&string_const_32);
  allocp[30] = x11 = makeref(&allocp[30]);
  allocp[31] = x10;
  allocp[32] = (q)(struct goalrec*)&allocp[27];
  allocp[33] = (q)(&predicate_klic__comp__write_xwrite__pred__dispatch_3);
  allocp[34] = x7;
  allocp[35] = x12 = makeref(&allocp[35]);
  allocp[36] = x11;
  allocp[37] = (q)(struct goalrec*)&allocp[32];
  allocp[38] = (q)(&predicate_klic__comp__obj_xklicformat_3);
  allocp[39] = makefunctor(&string_const_30);
  allocp[40] = x13 = makeref(&allocp[40]);
  allocp[41] = x12;
  allocp[42] = (q)(struct goalrec*)&allocp[37];
  allocp[43] = (q)(&predicate_klic__comp__obj_xklicformat_3);
  allocp[44] = makefunctor(&string_const_0);
  allocp[45] = x14 = makeref(&allocp[45]);
  allocp[46] = x13;
  allocp[47] = (q)(struct goalrec*)&allocp[42];
  allocp[48] = (q)(&predicate_klic__comp__write_xdeclare__registers_4);
  allocp[49] = x3;
  allocp[50] = makefunctor(&string_const_45);
  allocp[51] = x15 = makeref(&allocp[51]);
  allocp[52] = x14;
  allocp[53] = (q)(struct goalrec*)&allocp[47];
  allocp[54] = (q)(&predicate_klic__comp__obj_xklicformat_3);
  allocp[55] = makefunctor(&string_const_13);
  allocp[56] = x16 = makeref(&allocp[56]);
  allocp[57] = x15;
  allocp[58] = (q)(struct goalrec*)&allocp[53];
  allocp[59] = (q)(&predicate_klic__comp__write_xpred__min__max_5);
  allocp[60] = x7;
  allocp[61] = makeint(99999L);
  allocp[62] = x17 = makeref(&allocp[62]);
  allocp[63] = makeint(0L);
  allocp[64] = x3;
  allocp[65] = (q)(struct goalrec*)&allocp[58];
  allocp[66] = (q)(&predicate_klic__comp__write_xdeclare__const_5);
  allocp[67] = x5;
  allocp[68] = makeint(0L);
  allocp[69] = x18 = makeref(&allocp[69]);
  allocp[70] = x19 = makeref(&allocp[70]);
  allocp[71] = x16;
  allocp[72] = NILATOM;
  allocp[73] = x8;
  x20 = makecons(&allocp[72]);
  allocp[74] = (q)(struct goalrec*)&allocp[65];
  allocp[75] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[76] = makefunctor(&string_const_54);
  allocp[77] = x20;
  allocp[78] = x21 = makeref(&allocp[78]);
  allocp[79] = x19;
  allocp[80] = x21;
  allocp[81] = makeint(10L);
  x22 = makecons(&allocp[80]);
  allocp[82] = (q)(struct goalrec*)&allocp[74];
  allocp[83] = (q)(&predicate_klic__comp__obj_xklicformat_3);
  allocp[84] = makefunctor(&string_const_44);
  allocp[85] = x23 = makeref(&allocp[85]);
  allocp[86] = x22;
  allocp[87] = (q)(struct goalrec*)&allocp[82];
  allocp[88] = (q)(&predicate_klic__comp__write_xdeclare__externals_3);
  allocp[89] = x5;
  allocp[90] = x24 = makeref(&allocp[90]);
  allocp[91] = x23;
  allocp[92] = (q)(struct goalrec*)&allocp[87];
  allocp[93] = (q)(&predicate_klic__comp__write_xwrite__native__pred__structs_5);
  allocp[94] = x5;
  allocp[95] = x8;
  allocp[96] = x25 = makeref(&allocp[96]);
  allocp[97] = x26 = makeref(&allocp[97]);
  allocp[98] = x24;
  allocp[99] = (q)(struct goalrec*)&allocp[92];
  allocp[100] = (q)(&predicate_klic__comp__write_xtake__seqnum_4);
  allocp[101] = x7;
  allocp[102] = x25;
  allocp[103] = x27 = makeref(&allocp[103]);
  allocp[104] = x26;
  allocp[105] = (q)(struct goalrec*)&allocp[99];
  allocp[106] = (q)(&predicate_klic__comp__write_xsort__info_2);
  allocp[107] = x9;
  allocp[108] = x5;
  allocp[109] = (q)(struct goalrec*)&allocp[105];
  allocp[110] = (q)(&predicate_klic__comp__write_xwrite__pred__structs_4);
  allocp[111] = x7;
  allocp[112] = x8;
  allocp[113] = x28 = makeref(&allocp[113]);
  allocp[114] = x27;
  allocp[115] = NILATOM;
  allocp[116] = x8;
  x29 = makecons(&allocp[115]);
  allocp[117] = (q)(struct goalrec*)&allocp[109];
  allocp[118] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[119] = makefunctor(&string_const_53);
  allocp[120] = x29;
  allocp[121] = a1;
  allocp[122] = x28;
  qp = (struct goalrec*)&allocp[117];
  allocp += 123;
  proceed();
 case VARREF:
  deref_and_jump(a0,write__out_3_1);
  *reasonp++ =  a0;
  goto write__out_3_interrupt;
  };
  goto write__out_3_interrupt;
 write__out_3_ext_interrupt:
  reasonp = 0l;
 write__out_3_interrupt:
  goto interrupt_3;
 }

 declare__const_5_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 declare__const_5_clear_reason:
  reasonp = reasons;
 declare__const_5_0:
 declare__const_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 declare__const_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_const_2)) goto declare__const_5_3;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xdeclare__const_5);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = a4;
  a0 = arg(x0, 1);
  x4 = arg(x0, 0);
  a2 = a1;
  a4 = a3;
  a5 = x3;
  a3 = x2;
  a1 = x4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(declare__const_6_0);
  goto declare__const_6_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,declare__const_5_2);
  *reasonp++ =  x0;
  goto declare__const_5_3;
  };
  goto declare__const_5_3;
 case ATOMIC:
  if (a0 != NILATOM) goto declare__const_5_3;
  unify2(a4, a3, a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,declare__const_5_1);
  *reasonp++ =  a0;
  goto declare__const_5_3;
  };
  goto declare__const_5_3;
 declare__const_5_3:
  otherwise(declare__const_5_interrupt);
 declare__const_5_4:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(declare__const_5_0);
  goto declare__const_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,declare__const_5_4);
  *reasonp++ =  a0;
  goto declare__const_5_interrupt;
  };
  goto declare__const_5_interrupt;
 declare__const_5_ext_interrupt:
  reasonp = 0l;
 declare__const_5_interrupt:
  goto interrupt_5;
 }

 declare__const_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20, x21;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 declare__const_6_clear_reason:
  reasonp = reasons;
 declare__const_6_0:
 declare__const_6_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_string_1:
  x0 = arg(a0, 0);
 declare__const_6_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
 declare__const_6_3:
  if (!isgobj(x0)) goto declare__const_6_12;
 declare__const_6_4:
  gblt_is_string(x0,declare__const_6_12);
  gblt_size_of_string(x0,x1,declare__const_6_12);
  gblt_element_size_of_string(x0,x2,declare__const_6_12);
  x3 = makeint(0L);
  gblt_less_or_eq(x1,x3,declare__const_6_5);
  allocp[0] = makesym(functor_string_1);
  allocp[1] = a2;
  x4 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[2] = a2;
  allocp[3] = makeint(1L);
  allocp[4] = a3;
  allocp[5] = NILATOM;
  allocp[6] = x2;
  x5 = makecons(&allocp[5]);
  allocp[7] = x5;
  allocp[8] = a2;
  x6 = makecons(&allocp[7]);
  allocp[9] = x6;
  allocp[10] = x2;
  x7 = makecons(&allocp[9]);
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[13] = makefunctor(&string_const_16);
  allocp[14] = x7;
  allocp[15] = a4;
  allocp[16] = a5;
  qp = (struct goalrec*)&allocp[11];
  allocp += 17;
  proceed();
 declare__const_6_5:
  x4 = makeint(0L);
  gblt_greater(x1,x4,declare__const_6_12);
  allocp[0] = makesym(functor_string_1);
  allocp[1] = a2;
  x5 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x5);
  x6 = makeint(3L);
  bblt_add_no_check(x1,x6,x7);
  x8 = makeint(4L);
  bblt_div_no_check(x7,x8,x9);
  x10 = makeint(4L);
  bblt_mult_no_check(x9,x10,x11);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[2] = a2;
  allocp[3] = makeint(1L);
  allocp[4] = a3;
  allocp[5] = NILATOM;
  allocp[6] = x1;
  x12 = makecons(&allocp[5]);
  allocp[7] = x12;
  allocp[8] = a2;
  x13 = makecons(&allocp[7]);
  allocp[9] = x13;
  allocp[10] = x2;
  x14 = makecons(&allocp[9]);
  allocp[11] = x14;
  allocp[12] = a2;
  x15 = makecons(&allocp[11]);
  allocp[13] = x15;
  allocp[14] = x2;
  x16 = makecons(&allocp[13]);
  allocp[15] = (q)(struct goalrec*)&allocp[0];
  allocp[16] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[17] = makefunctor(&string_const_17);
  allocp[18] = x16;
  allocp[19] = x17 = makeref(&allocp[19]);
  allocp[20] = a5;
  allocp[21] = x17;
  allocp[22] = makefunctor(funct_const_77);
  x18 = makecons(&allocp[21]);
  allocp[23] = (q)(struct goalrec*)&allocp[15];
  allocp[24] = (q)(&predicate_klic__comp__write_xwrite__string__body_4);
  allocp[25] = x1;
  allocp[26] = x0;
  allocp[27] = x19 = makeref(&allocp[27]);
  allocp[28] = x18;
  allocp[29] = NILATOM;
  allocp[30] = x11;
  x20 = makecons(&allocp[29]);
  allocp[31] = x20;
  allocp[32] = a2;
  x21 = makecons(&allocp[31]);
  allocp[33] = (q)(struct goalrec*)&allocp[23];
  allocp[34] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[35] = makefunctor(&string_const_29);
  allocp[36] = x21;
  allocp[37] = a4;
  allocp[38] = x19;
  qp = (struct goalrec*)&allocp[33];
  allocp += 39;
  proceed();
 case VARREF:
  deref_and_jump(x0,declare__const_6_2);
  *reasonp++ =  x0;
  goto declare__const_6_12;
  };
  goto declare__const_6_12;
 case functor_vector_1:
  x0 = arg(a0, 0);
 declare__const_6_6:
  switch (ptagof(x0)) {
 case FUNCTOR:
 declare__const_6_7:
  if (!isgobj(x0)) goto declare__const_6_12;
  if (!isclass(x0,vector)) goto declare__const_6_12;
  gblt_size_of_vector(x0,x1,declare__const_6_12);
  x2 = makeint(0L);
  gblt_less_or_eq(x1,x2,declare__const_6_8);
  allocp[0] = makesym(functor_vector_1);
  allocp[1] = a2;
  x3 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[2] = a2;
  allocp[3] = makeint(1L);
  allocp[4] = a3;
  allocp[5] = NILATOM;
  allocp[6] = a2;
  x4 = makecons(&allocp[5]);
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[9] = makefunctor(&string_const_21);
  allocp[10] = x4;
  allocp[11] = a4;
  allocp[12] = a5;
  qp = (struct goalrec*)&allocp[7];
  allocp += 13;
  proceed();
 declare__const_6_8:
  x3 = makeint(0L);
  gblt_greater(x1,x3,declare__const_6_12);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = makeint(1L);
  allocp[4] = a3;
  allocp[5] = NILATOM;
  allocp[6] = x1;
  x5 = makecons(&allocp[5]);
  allocp[7] = x5;
  allocp[8] = x4;
  x6 = makecons(&allocp[7]);
  allocp[9] = x6;
  allocp[10] = x4;
  x7 = makecons(&allocp[9]);
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[13] = makefunctor(&string_const_22);
  allocp[14] = x7;
  allocp[15] = x8 = makeref(&allocp[15]);
  allocp[16] = a5;
  allocp[17] = x8;
  allocp[18] = makefunctor(funct_const_69);
  x9 = makecons(&allocp[17]);
  allocp[19] = (q)(struct goalrec*)&allocp[11];
  allocp[20] = (q)(&predicate_klic__comp__write_xwrite__const__elems_3);
  allocp[21] = x10 = makeref(&allocp[21]);
  allocp[22] = x11 = makeref(&allocp[22]);
  allocp[23] = x9;
  allocp[24] = NILATOM;
  allocp[25] = x4;
  x12 = makecons(&allocp[24]);
  allocp[26] = (q)(struct goalrec*)&allocp[19];
  allocp[27] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[28] = makefunctor(&string_const_28);
  allocp[29] = x12;
  allocp[30] = x13 = makeref(&allocp[30]);
  allocp[31] = x11;
  allocp[32] = makesym(functor_vector_1);
  allocp[33] = x4;
  x14 = makefunctor(&allocp[32]);
  qp = (struct goalrec*)&allocp[26];
  allocp += 34;
  unify_value(a1, x14);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xdeclare__const__list_6);
  allocp[2] = x15 = makeref(&allocp[2]);
  allocp[3] = x10;
  allocp[4] = a2;
  allocp[5] = x4;
  allocp[6] = a4;
  allocp[7] = x13;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_klic__comp__util_xvector__to__list_2);
  allocp[10] = x0;
  allocp[11] = x15;
  qp = (struct goalrec*)&allocp[8];
  allocp += 12;
  proceed();
 case VARREF:
  deref_and_jump(x0,declare__const_6_6);
  *reasonp++ =  x0;
  goto declare__const_6_12;
  };
  goto declare__const_6_12;
 case functor_float_1:
  allocp[0] = makesym(functor_float_1);
  allocp[1] = a2;
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[2] = a2;
  allocp[3] = makeint(1L);
  allocp[4] = a3;
  allocp[5] = NILATOM;
  x2 = arg(a0, 0);
  allocp[6] = x2;
  x1 = makecons(&allocp[5]);
  allocp[7] = x1;
  allocp[8] = a2;
  x3 = makecons(&allocp[7]);
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[11] = makefunctor(&string_const_18);
  allocp[12] = x3;
  allocp[13] = a4;
  allocp[14] = a5;
  qp = (struct goalrec*)&allocp[9];
  allocp += 15;
  proceed();
 case functor_module_1:
  allocp[0] = makesym(functor_module_1);
  allocp[1] = a2;
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[2] = a2;
  allocp[3] = makeint(1L);
  allocp[4] = a3;
  allocp[5] = NILATOM;
  x2 = arg(a0, 0);
  allocp[6] = x2;
  x1 = makecons(&allocp[5]);
  allocp[7] = x1;
  x4 = arg(a0, 0);
  allocp[8] = x4;
  x3 = makecons(&allocp[7]);
  allocp[9] = x3;
  allocp[10] = a2;
  x5 = makecons(&allocp[9]);
  allocp[11] = x5;
  x7 = arg(a0, 0);
  allocp[12] = x7;
  x6 = makecons(&allocp[11]);
  allocp[13] = (q)(struct goalrec*)&allocp[0];
  allocp[14] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[15] = makefunctor(&string_const_19);
  allocp[16] = x6;
  allocp[17] = a4;
  allocp[18] = a5;
  qp = (struct goalrec*)&allocp[13];
  allocp += 19;
  proceed();
 case functor_predicate_3:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = makeint(1L);
  allocp[4] = a3;
  allocp[5] = NILATOM;
  x2 = arg(a0, 1);
  allocp[6] = x2;
  x1 = makecons(&allocp[5]);
  allocp[7] = x1;
  allocp[8] = x4 = makeref(&allocp[8]);
  x3 = makecons(&allocp[7]);
  allocp[9] = x3;
  x6 = arg(a0, 2);
  allocp[10] = x6;
  x5 = makecons(&allocp[9]);
  allocp[11] = x5;
  x8 = arg(a0, 1);
  allocp[12] = x8;
  x7 = makecons(&allocp[11]);
  allocp[13] = x7;
  x10 = arg(a0, 0);
  allocp[14] = x10;
  x9 = makecons(&allocp[13]);
  allocp[15] = x9;
  allocp[16] = x0;
  x11 = makecons(&allocp[15]);
  allocp[17] = (q)(struct goalrec*)&allocp[0];
  allocp[18] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[19] = makefunctor(&string_const_20);
  allocp[20] = x11;
  allocp[21] = x12 = makeref(&allocp[21]);
  allocp[22] = a5;
  allocp[23] = makesym(functor_predicate_1);
  allocp[24] = x0;
  x13 = makefunctor(&allocp[23]);
  qp = (struct goalrec*)&allocp[17];
  allocp += 25;
  unify_value(a1, x13);
  allocp[0] = makesym(functor_module_1);
  x15 = arg(a0, 0);
  allocp[1] = x15;
  x14 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_module_1);
  allocp[3] = x4;
  x16 = makefunctor(&allocp[2]);
  a0 = x14;
  a1 = x16;
  a3 = x0;
  a5 = x12;
  allocp += 4;
  execute(declare__const_6_0);
  goto declare__const_6_ext_interrupt;
 case functor_list_1:
  x0 = arg(a0, 0);
 declare__const_6_9:
  switch (ptagof(x0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = makeint(1L);
  allocp[4] = a3;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_klic__comp__obj_xklicformat_3);
  allocp[7] = makefunctor(&string_const_33);
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = a5;
  allocp[10] = NILATOM;
  allocp[11] = x4 = makeref(&allocp[11]);
  x3 = makecons(&allocp[10]);
  allocp[12] = x3;
  allocp[13] = x6 = makeref(&allocp[13]);
  x5 = makecons(&allocp[12]);
  allocp[14] = (q)(struct goalrec*)&allocp[5];
  allocp[15] = (q)(&predicate_klic__comp__write_xwrite__const__elems_3);
  allocp[16] = x5;
  allocp[17] = x7 = makeref(&allocp[17]);
  allocp[18] = x2;
  allocp[19] = NILATOM;
  allocp[20] = x1;
  x8 = makecons(&allocp[19]);
  allocp[21] = (q)(struct goalrec*)&allocp[14];
  allocp[22] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[23] = makefunctor(&string_const_26);
  allocp[24] = x8;
  allocp[25] = x9 = makeref(&allocp[25]);
  allocp[26] = x7;
  allocp[27] = makesym(functor_list_1);
  allocp[28] = x1;
  x10 = makefunctor(&allocp[27]);
  qp = (struct goalrec*)&allocp[21];
  allocp += 29;
  unify_value(a1, x10);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xdeclare__const_6);
  x11 = car_of(x0);
  allocp[2] = x11;
  allocp[3] = x4;
  allocp[4] = x12 = makeref(&allocp[4]);
  allocp[5] = x1;
  allocp[6] = x13 = makeref(&allocp[6]);
  allocp[7] = x9;
  a0 = cdr_of(x0);
  a1 = x6;
  a3 = x12;
  a5 = x13;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  execute(declare__const_6_0);
  goto declare__const_6_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,declare__const_6_9);
  *reasonp++ =  x0;
  goto declare__const_6_12;
  };
  goto declare__const_6_12;
 case functor_functor_1:
  x0 = arg(a0, 0);
 declare__const_6_10:
  if (isref(x0)) goto declare__const_6_11;
  gblt_pfunctor(x0,x1,declare__const_6_12);
  gblt_arity(x0,x2,declare__const_6_12);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = makeint(1L);
  allocp[4] = a3;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_klic__comp__obj_xklicformat_3);
  allocp[7] = makefunctor(&string_const_33);
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = a5;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_klic__comp__write_xwrite__const__elems_3);
  allocp[12] = x5 = makeref(&allocp[12]);
  allocp[13] = x6 = makeref(&allocp[13]);
  allocp[14] = x4;
  allocp[15] = makesym(functor__2F_2);
  allocp[16] = x1;
  allocp[17] = x2;
  x7 = makefunctor(&allocp[15]);
  allocp[18] = NILATOM;
  allocp[19] = x7;
  x8 = makecons(&allocp[18]);
  allocp[20] = x8;
  allocp[21] = x3;
  x9 = makecons(&allocp[20]);
  allocp[22] = (q)(struct goalrec*)&allocp[10];
  allocp[23] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[24] = makefunctor(&string_const_27);
  allocp[25] = x9;
  allocp[26] = x10 = makeref(&allocp[26]);
  allocp[27] = x6;
  allocp[28] = makesym(functor_functor_1);
  allocp[29] = x3;
  x11 = makefunctor(&allocp[28]);
  qp = (struct goalrec*)&allocp[22];
  allocp += 30;
  unify_value(a1, x11);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xdeclare__const__list_6);
  allocp[2] = x12 = makeref(&allocp[2]);
  allocp[3] = x5;
  allocp[4] = a2;
  allocp[5] = x3;
  allocp[6] = a4;
  allocp[7] = x10;
  allocp[8] = x12;
  allocp[9] = x1;
  x13 = makecons(&allocp[8]);
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_klic__comp__util_xuniv_2);
  allocp[12] = x0;
  allocp[13] = x13;
  qp = (struct goalrec*)&allocp[10];
  allocp += 14;
  proceed();
 declare__const_6_11:
  deref_and_jump(x0,declare__const_6_10);
  *reasonp++ =  x0;
  goto declare__const_6_12;
  };
  goto declare__const_6_12;
 case VARREF:
  deref_and_jump(a0,declare__const_6_1);
  *reasonp++ =  a0;
  goto declare__const_6_12;
  };
  goto declare__const_6_12;
 declare__const_6_12:
  otherwise(declare__const_6_interrupt);
  unify3(a5, a4, a3, a2, a1, a0);
  proceed();
 declare__const_6_ext_interrupt:
  reasonp = 0l;
 declare__const_6_interrupt:
  toppred = &predicate_klic__comp__write_xdeclare__const_6;
  goto interrupt_6;
 }

 declare__const__list_6_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 declare__const__list_6_clear_reason:
  reasonp = reasons;
 declare__const__list_6_0:
 declare__const__list_6_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = x2 = makeref(&allocp[1]);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xdeclare__const__list_6);
  x3 = cdr_of(a0);
  allocp[2] = x3;
  allocp[3] = x1;
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x5 = makeref(&allocp[6]);
  allocp[7] = a5;
  a0 = car_of(a0);
  a1 = x2;
  a3 = x4;
  a5 = x5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  execute(declare__const_6_0);
  goto declare__const_6_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto declare__const__list_6_interrupt;
  unify2(a5, a4, a3, a2);
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,declare__const__list_6_1);
  *reasonp++ =  a0;
  goto declare__const__list_6_interrupt;
  };
  goto declare__const__list_6_interrupt;
 declare__const__list_6_ext_interrupt:
  reasonp = 0l;
 declare__const__list_6_interrupt:
  goto interrupt_6;
 }

 write__const__elems_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 write__const__elems_3_clear_reason:
  reasonp = reasons;
 write__const__elems_3_0:
 write__const__elems_3_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xwrite__const__elems_3);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  a0 = car_of(a0);
  a2 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(write__const__elem_3_0);
  goto write__const__elem_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto write__const__elems_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,write__const__elems_3_1);
  *reasonp++ =  a0;
  goto write__const__elems_3_interrupt;
  };
  goto write__const__elems_3_interrupt;
 write__const__elems_3_ext_interrupt:
  reasonp = 0l;
 write__const__elems_3_interrupt:
  goto interrupt_3;
 }

 write__const__elem_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 write__const__elem_3_clear_reason:
  reasonp = reasons;
 write__const__elem_3_0:
 write__const__elem_3_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_atom_1:
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_12);
  allocp[5] = x0;
  allocp[6] = a1;
  allocp[7] = a2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 case functor_integer_1:
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_9);
  allocp[5] = x0;
  allocp[6] = a1;
  allocp[7] = a2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 case functor_float_1:
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_5);
  allocp[5] = x0;
  allocp[6] = a1;
  allocp[7] = a2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 case functor_predicate_1:
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_11);
  allocp[5] = x0;
  allocp[6] = a1;
  allocp[7] = a2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 case functor_module_1:
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_10);
  allocp[5] = x0;
  allocp[6] = a1;
  allocp[7] = a2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 case functor_list_1:
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_4);
  allocp[5] = x0;
  allocp[6] = a1;
  allocp[7] = a2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 case functor_functor_1:
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_8);
  allocp[5] = x0;
  allocp[6] = a1;
  allocp[7] = a2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 case functor_string_1:
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_6);
  allocp[5] = x0;
  allocp[6] = a1;
  allocp[7] = a2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 case functor_vector_1:
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_7);
  allocp[5] = x0;
  allocp[6] = a1;
  allocp[7] = a2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
  };
  goto write__const__elem_3_interrupt;
 case VARREF:
  deref_and_jump(a0,write__const__elem_3_1);
  *reasonp++ =  a0;
  goto write__const__elem_3_interrupt;
  };
  goto write__const__elem_3_interrupt;
 write__const__elem_3_ext_interrupt:
  reasonp = 0l;
 write__const__elem_3_interrupt:
  toppred = &predicate_klic__comp__write_xwrite__const__elem_3;
  goto interrupt_3;
 }

 write__string__body_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 write__string__body_4_clear_reason:
  reasonp = reasons;
 write__string__body_4_0:
 write__string__body_4_1:
  if (!isint(a0)) goto write__string__body_4_3;
  x1 = makeint(4L);
  gblt_modulo(a0,x1,x0,write__string__body_4_interrupt);
  x2 = makeint(0L);
  gblt_not_eq(x0,x2,write__string__body_4_2);
  allocp[0] = x4 = makeref(&allocp[0]);
  allocp[1] = makefunctor(funct_const_71);
  x3 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x3);
  allocp[0] = a3;
  allocp[1] = makefunctor(funct_const_71);
  x5 = makecons(&allocp[0]);
  x6 = a0;
  a2 = a1;
  a3 = x4;
  a4 = x5;
  a1 = x6;
  a0 = makeint(0L);
  allocp += 2;
  execute(write__string__elements_5_0);
  goto write__string__elements_5_ext_interrupt;
 write__string__body_4_2:
  x3 = makeint(0L);
  gblt_eq(x0,x3,write__string__body_4_interrupt);
  allocp[0] = x5 = makeref(&allocp[0]);
  allocp[1] = makefunctor(funct_const_93);
  x4 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x4);
  allocp[0] = a3;
  allocp[1] = makefunctor(funct_const_95);
  x6 = makecons(&allocp[0]);
  x7 = a0;
  a2 = a1;
  a3 = x5;
  a4 = x6;
  a1 = x7;
  a0 = makeint(0L);
  allocp += 2;
  execute(write__character__constants_5_0);
  goto write__character__constants_5_ext_interrupt;
 write__string__body_4_3:
  if (!isref(a0)) goto write__string__body_4_interrupt;
  deref_and_jump(a0,write__string__body_4_1);
  *reasonp++ =  a0;
  goto write__string__body_4_interrupt;
 write__string__body_4_ext_interrupt:
  reasonp = 0l;
 write__string__body_4_interrupt:
  goto interrupt_4;
 }

 write__character__constants_5_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 write__character__constants_5_clear_reason:
  reasonp = reasons;
 write__character__constants_5_0:
 write__character__constants_5_1:
  if (!isint(a0)) goto write__character__constants_5_8;
 write__character__constants_5_2:
  if (!isint(a1)) goto write__character__constants_5_7;
  gblt_greater_or_eq(a0,a1,write__character__constants_5_3);
  unify(a4, a3);
  proceed();
 write__character__constants_5_3:
  gblt_less(a0,a1,write__character__constants_5_interrupt);
 write__character__constants_5_4:
  switch (ptagof(a2)) {
 case FUNCTOR:
 write__character__constants_5_5:
  if (!isgobj(a2)) goto write__character__constants_5_interrupt;
 write__character__constants_5_6:
  gblt_is_string(a2,write__character__constants_5_interrupt);
  gblt_element_of_string(a2,a0,x0,write__character__constants_5_interrupt);
  x2 = makeint(1L);
  gblt_add(a0,x2,x1,write__character__constants_5_interrupt);
  allocp[0] = x4 = makeref(&allocp[0]);
  allocp[1] = makefunctor(funct_const_73);
  x3 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a3, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xwrite__character__constants_5);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x5 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x5;
  allocp[8] = makefunctor(funct_const_75);
  x6 = makecons(&allocp[7]);
  a0 = x0;
  a1 = x4;
  a2 = x6;
  qp = (struct goalrec*)&allocp[0];
  allocp += 9;
  execute(write__string__element_3_0);
  goto write__string__element_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,write__character__constants_5_4);
  *reasonp++ =  a2;
  goto write__character__constants_5_interrupt;
  };
  goto write__character__constants_5_interrupt;
 write__character__constants_5_7:
  if (!isref(a1)) goto write__character__constants_5_interrupt;
  deref_and_jump(a1,write__character__constants_5_2);
  *reasonp++ =  a1;
  goto write__character__constants_5_interrupt;
 write__character__constants_5_8:
  if (!isref(a0)) goto write__character__constants_5_interrupt;
  deref_and_jump(a0,write__character__constants_5_1);
  *reasonp++ =  a0;
  goto write__character__constants_5_interrupt;
 write__character__constants_5_ext_interrupt:
  reasonp = 0l;
 write__character__constants_5_interrupt:
  toppred = &predicate_klic__comp__write_xwrite__character__constants_5;
  goto interrupt_5;
 }

 write__string__elements_5_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 write__string__elements_5_clear_reason:
  reasonp = reasons;
 write__string__elements_5_0:
 write__string__elements_5_1:
  if (!isint(a0)) goto write__string__elements_5_8;
 write__string__elements_5_2:
  if (!isint(a1)) goto write__string__elements_5_7;
  gblt_greater_or_eq(a0,a1,write__string__elements_5_3);
  unify(a4, a3);
  proceed();
 write__string__elements_5_3:
  gblt_less(a0,a1,write__string__elements_5_interrupt);
 write__string__elements_5_4:
  switch (ptagof(a2)) {
 case FUNCTOR:
 write__string__elements_5_5:
  if (!isgobj(a2)) goto write__string__elements_5_interrupt;
 write__string__elements_5_6:
  gblt_is_string(a2,write__string__elements_5_interrupt);
  gblt_element_of_string(a2,a0,x0,write__string__elements_5_interrupt);
  x2 = makeint(1L);
  gblt_add(a0,x2,x1,write__string__elements_5_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xwrite__string__elements_5);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = a4;
  a0 = x0;
  a1 = a3;
  a2 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(write__string__element_3_0);
  goto write__string__element_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,write__string__elements_5_4);
  *reasonp++ =  a2;
  goto write__string__elements_5_interrupt;
  };
  goto write__string__elements_5_interrupt;
 write__string__elements_5_7:
  if (!isref(a1)) goto write__string__elements_5_interrupt;
  deref_and_jump(a1,write__string__elements_5_2);
  *reasonp++ =  a1;
  goto write__string__elements_5_interrupt;
 write__string__elements_5_8:
  if (!isref(a0)) goto write__string__elements_5_interrupt;
  deref_and_jump(a0,write__string__elements_5_1);
  *reasonp++ =  a0;
  goto write__string__elements_5_interrupt;
 write__string__elements_5_ext_interrupt:
  reasonp = 0l;
 write__string__elements_5_interrupt:
  toppred = &predicate_klic__comp__write_xwrite__string__elements_5;
  goto interrupt_5;
 }

 write__string__element_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18;
  a2 = qp->args[2];
  qp = qp->next;
 write__string__element_3_clear_reason:
  reasonp = reasons;
 write__string__element_3_0:
 write__string__element_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 write__string__element_3_2:
  switch ((unsigned long)a0) {
 case (unsigned long) makeint(34L):
  allocp[0] = a2;
  allocp[1] = makefunctor(funct_const_83);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  proceed();
 case (unsigned long) makeint(39L):
  allocp[0] = a2;
  allocp[1] = makefunctor(funct_const_85);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  proceed();
 case (unsigned long) makeint(92L):
  allocp[0] = a2;
  allocp[1] = makefunctor(funct_const_87);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  proceed();
 case (unsigned long) makeint(10L):
  allocp[0] = a2;
  allocp[1] = makefunctor(funct_const_89);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  proceed();
 case (unsigned long) makeint(9L):
  allocp[0] = a2;
  allocp[1] = makefunctor(funct_const_91);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  proceed();
 case (unsigned long) makeint(32L):
  allocp[0] = a2;
  allocp[1] = makefunctor(funct_const_67);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  proceed();
  };
  goto write__string__element_3_3;
 case VARREF:
  deref_and_jump(a0,write__string__element_3_1);
  *reasonp++ =  a0;
  goto write__string__element_3_3;
  };
  goto write__string__element_3_3;
 write__string__element_3_3:
  otherwise(write__string__element_3_interrupt);
 write__string__element_3_4:
  if (!isint(a0)) goto write__string__element_3_5;
  
{
   long c = intval(a0);
   if (!isgraph(c)) goto write__string__element_3_6;
}
  allocp[0] = a2;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  proceed();
 write__string__element_3_5:
  if (!isref(a0)) goto write__string__element_3_6;
  deref_and_jump(a0,write__string__element_3_4);
  *reasonp++ =  a0;
  goto write__string__element_3_6;
 write__string__element_3_6:
  otherwise(write__string__element_3_interrupt);
 write__string__element_3_7:
  if (!isint(a0)) goto write__string__element_3_8;
  x1 = makeint(6L);
  gblt_rshift(a0,x1,x0,write__string__element_3_interrupt);
  x3 = makeint(48L);
  gblt_add(x0,x3,x2,write__string__element_3_interrupt);
  x5 = makeint(3L);
  gblt_rshift(a0,x5,x4,write__string__element_3_interrupt);
  x7 = makeint(7L);
  gblt_and(x4,x7,x6,write__string__element_3_interrupt);
  x9 = makeint(48L);
  gblt_add(x6,x9,x8,write__string__element_3_interrupt);
  x11 = makeint(7L);
  gblt_and(a0,x11,x10,write__string__element_3_interrupt);
  x13 = makeint(48L);
  gblt_add(x10,x13,x12,write__string__element_3_interrupt);
  allocp[0] = x15 = makeref(&allocp[0]);
  allocp[1] = x12;
  x14 = makecons(&allocp[0]);
  allocp[2] = x14;
  allocp[3] = x8;
  x16 = makecons(&allocp[2]);
  allocp[4] = x16;
  allocp[5] = x2;
  x17 = makecons(&allocp[4]);
  allocp[6] = x17;
  allocp[7] = makeint(92L);
  x18 = makecons(&allocp[6]);
  allocp += 8;
  unify_value(a1, x18);
  unify(a2, x15);
  proceed();
 write__string__element_3_8:
  if (!isref(a0)) goto write__string__element_3_interrupt;
  deref_and_jump(a0,write__string__element_3_7);
  *reasonp++ =  a0;
  goto write__string__element_3_interrupt;
 write__string__element_3_ext_interrupt:
  reasonp = 0l;
 write__string__element_3_interrupt:
  toppred = &predicate_klic__comp__write_xwrite__string__element_3;
  goto interrupt_3;
 }

 take__seqnum_4_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 take__seqnum_4_clear_reason:
  reasonp = reasons;
 take__seqnum_4_0:
  x0 = a2;
  a4 = a3;
  a3 = x0;
  a2 = makeint(0L);
  execute(take__seqnum_5_0);
  goto take__seqnum_5_ext_interrupt;
 take__seqnum_4_ext_interrupt:
  reasonp = 0l;
 take__seqnum_4_interrupt:
  goto interrupt_4;
 }

 take__seqnum_5_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 take__seqnum_5_clear_reason:
  reasonp = reasons;
 take__seqnum_5_0:
 take__seqnum_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 take__seqnum_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_5)) goto take__seqnum_5_3;
  x1 = arg(x0, 2);
  a0 = cdr_of(a0);
  a2 = x1;
  execute(take__seqnum_5_0);
  goto take__seqnum_5_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,take__seqnum_5_2);
  *reasonp++ =  x0;
  goto take__seqnum_5_3;
  };
  goto take__seqnum_5_3;
 case ATOMIC:
  if (a0 != NILATOM) goto take__seqnum_5_3;
  unify2(a4, a3, a1, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,take__seqnum_5_1);
  *reasonp++ =  a0;
  goto take__seqnum_5_3;
  };
  goto take__seqnum_5_3;
 take__seqnum_5_3:
  otherwise(take__seqnum_5_interrupt);
 take__seqnum_5_4:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(take__seqnum_5_0);
  goto take__seqnum_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,take__seqnum_5_4);
  *reasonp++ =  a0;
  goto take__seqnum_5_interrupt;
  };
  goto take__seqnum_5_interrupt;
 take__seqnum_5_ext_interrupt:
  reasonp = 0l;
 take__seqnum_5_interrupt:
  toppred = &predicate_klic__comp__write_xtake__seqnum_5;
  goto interrupt_5;
 }

 write__native__pred__structs_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 write__native__pred__structs_5_clear_reason:
  reasonp = reasons;
 write__native__pred__structs_5_0:
 write__native__pred__structs_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 write__native__pred__structs_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_native__exec_3)) goto write__native__pred__structs_5_3;
  x1 = makeint(1L);
  bblt_add_no_check_y(a2,x1,x2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xwrite__native__pred__structs_5);
  x3 = cdr_of(a0);
  allocp[2] = x3;
  allocp[3] = a1;
  allocp[4] = x2;
  allocp[5] = x4 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = NILATOM;
  x6 = arg(x0, 2);
  allocp[8] = x6;
  x5 = makecons(&allocp[7]);
  allocp[9] = x5;
  allocp[10] = x2;
  x7 = makecons(&allocp[9]);
  allocp[11] = x7;
  allocp[12] = a1;
  x8 = makecons(&allocp[11]);
  allocp[13] = x8;
  x10 = arg(x0, 2);
  allocp[14] = x10;
  x9 = makecons(&allocp[13]);
  allocp[15] = x9;
  x12 = arg(x0, 1);
  allocp[16] = x12;
  x11 = makecons(&allocp[15]);
  allocp[17] = x11;
  x14 = arg(x0, 0);
  allocp[18] = x14;
  x13 = makecons(&allocp[17]);
  allocp[19] = (q)(struct goalrec*)&allocp[0];
  allocp[20] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[21] = makefunctor(&string_const_41);
  allocp[22] = x13;
  allocp[23] = a3;
  allocp[24] = x4;
  qp = (struct goalrec*)&allocp[19];
  allocp += 25;
  proceed();
 case VARREF:
  deref_and_jump(x0,write__native__pred__structs_5_2);
  *reasonp++ =  x0;
  goto write__native__pred__structs_5_3;
  };
  goto write__native__pred__structs_5_3;
 case ATOMIC:
  if (a0 != NILATOM) goto write__native__pred__structs_5_3;
  unify(a4, a3);
  proceed();
 case VARREF:
  deref_and_jump(a0,write__native__pred__structs_5_1);
  *reasonp++ =  a0;
  goto write__native__pred__structs_5_3;
  };
  goto write__native__pred__structs_5_3;
 write__native__pred__structs_5_3:
  otherwise(write__native__pred__structs_5_interrupt);
 write__native__pred__structs_5_4:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(write__native__pred__structs_5_0);
  goto write__native__pred__structs_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,write__native__pred__structs_5_4);
  *reasonp++ =  a0;
  goto write__native__pred__structs_5_interrupt;
  };
  goto write__native__pred__structs_5_interrupt;
 write__native__pred__structs_5_ext_interrupt:
  reasonp = 0l;
 write__native__pred__structs_5_interrupt:
  goto interrupt_5;
 }

 write__pred__structs_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 write__pred__structs_4_clear_reason:
  reasonp = reasons;
 write__pred__structs_4_0:
 write__pred__structs_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 write__pred__structs_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_5)) goto write__pred__structs_4_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xwrite__pred__structs_4);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = NILATOM;
  x4 = arg(x0, 1);
  allocp[7] = x4;
  x3 = makecons(&allocp[6]);
  allocp[8] = x3;
  x6 = arg(x0, 2);
  allocp[9] = x6;
  x5 = makecons(&allocp[8]);
  allocp[10] = x5;
  allocp[11] = a1;
  x7 = makecons(&allocp[10]);
  allocp[12] = x7;
  x9 = arg(x0, 1);
  allocp[13] = x9;
  x8 = makecons(&allocp[12]);
  allocp[14] = x8;
  x11 = arg(x0, 0);
  allocp[15] = x11;
  x10 = makecons(&allocp[14]);
  allocp[16] = x10;
  allocp[17] = a1;
  x12 = makecons(&allocp[16]);
  allocp[18] = (q)(struct goalrec*)&allocp[0];
  allocp[19] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[20] = makefunctor(&string_const_42);
  allocp[21] = x12;
  allocp[22] = a2;
  allocp[23] = x2;
  qp = (struct goalrec*)&allocp[18];
  allocp += 24;
  proceed();
 case VARREF:
  deref_and_jump(x0,write__pred__structs_4_2);
  *reasonp++ =  x0;
  goto write__pred__structs_4_interrupt;
  };
  goto write__pred__structs_4_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto write__pred__structs_4_interrupt;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,write__pred__structs_4_1);
  *reasonp++ =  a0;
  goto write__pred__structs_4_interrupt;
  };
  goto write__pred__structs_4_interrupt;
 write__pred__structs_4_ext_interrupt:
  reasonp = 0l;
 write__pred__structs_4_interrupt:
  goto interrupt_4;
 }

 declare__externals_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 declare__externals_3_clear_reason:
  reasonp = reasons;
 declare__externals_3_0:
 declare__externals_3_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xdeclare__externals_3);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  a0 = car_of(a0);
  a2 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(declare__one__external_3_0);
  goto declare__one__external_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto declare__externals_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,declare__externals_3_1);
  *reasonp++ =  a0;
  goto declare__externals_3_interrupt;
  };
  goto declare__externals_3_interrupt;
 declare__externals_3_ext_interrupt:
  reasonp = 0l;
 declare__externals_3_interrupt:
  goto interrupt_3;
 }

 declare__one__external_3_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  qp = qp->next;
 declare__one__external_3_clear_reason:
  reasonp = reasons;
 declare__one__external_3_0:
 declare__one__external_3_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_ext_3:
  allocp[0] = NILATOM;
  x1 = arg(a0, 2);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  x3 = arg(a0, 1);
  allocp[3] = x3;
  x2 = makecons(&allocp[2]);
  allocp[4] = x2;
  x5 = arg(a0, 0);
  allocp[5] = x5;
  x4 = makecons(&allocp[4]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[8] = makefunctor(&string_const_48);
  allocp[9] = x4;
  allocp[10] = a1;
  allocp[11] = a2;
  qp = (struct goalrec*)&allocp[6];
  allocp += 12;
  proceed();
 case functor_gnew_1:
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_49);
  allocp[5] = x0;
  allocp[6] = a1;
  allocp[7] = a2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 case functor_guse_1:
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_47);
  allocp[5] = x0;
  allocp[6] = a1;
  allocp[7] = a2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
  };
  goto declare__one__external_3_2;
 case VARREF:
  deref_and_jump(a0,declare__one__external_3_1);
  *reasonp++ =  a0;
  goto declare__one__external_3_2;
  };
  goto declare__one__external_3_2;
 declare__one__external_3_2:
  otherwise(declare__one__external_3_interrupt);
  unify(a2, a1);
  proceed();
 declare__one__external_3_ext_interrupt:
  reasonp = 0l;
 declare__one__external_3_interrupt:
  toppred = &predicate_klic__comp__write_xdeclare__one__external_3;
  goto interrupt_3;
 }

 pred__min__max_5_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 pred__min__max_5_clear_reason:
  reasonp = reasons;
 pred__min__max_5_0:
 pred__min__max_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 pred__min__max_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_5)) goto pred__min__max_5_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xpred__min__max_5);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_klic__comp__util_xmax_3);
  x4 = arg(x0, 1);
  allocp[9] = x4;
  allocp[10] = a3;
  allocp[11] = x3;
  allocp[12] = (q)(struct goalrec*)&allocp[7];
  allocp[13] = (q)(&predicate_klic__comp__util_xmin_3);
  allocp[14] = x4;
  allocp[15] = a1;
  allocp[16] = x2;
  qp = (struct goalrec*)&allocp[12];
  allocp += 17;
  proceed();
 case VARREF:
  deref_and_jump(x0,pred__min__max_5_2);
  *reasonp++ =  x0;
  goto pred__min__max_5_interrupt;
  };
  goto pred__min__max_5_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto pred__min__max_5_interrupt;
  unify2(a2, a1, a4, a3);
  proceed();
 case VARREF:
  deref_and_jump(a0,pred__min__max_5_1);
  *reasonp++ =  a0;
  goto pred__min__max_5_interrupt;
  };
  goto pred__min__max_5_interrupt;
 pred__min__max_5_ext_interrupt:
  reasonp = 0l;
 pred__min__max_5_interrupt:
  goto interrupt_5;
 }

 declare__registers_4_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 declare__registers_4_clear_reason:
  reasonp = reasons;
 declare__registers_4_0:
 declare__registers_4_1:
  if (!isint(a0)) goto declare__registers_4_3;
  x0 = makeint(0L);
  gblt_less_or_eq(a0,x0,declare__registers_4_2);
  unify(a3, a2);
  proceed();
 declare__registers_4_2:
  x1 = makeint(0L);
  gblt_greater(a0,x1,declare__registers_4_interrupt);
  allocp[0] = a3;
  allocp[1] = makefunctor(funct_const_77);
  x2 = makecons(&allocp[0]);
  a3 = a2;
  a4 = x2;
  a2 = makefunctor(&string_const_24);
  allocp += 2;
  execute(write__comma__list_5_0);
  goto write__comma__list_5_ext_interrupt;
 declare__registers_4_3:
  if (!isref(a0)) goto declare__registers_4_interrupt;
  deref_and_jump(a0,declare__registers_4_1);
  *reasonp++ =  a0;
  goto declare__registers_4_interrupt;
 declare__registers_4_ext_interrupt:
  reasonp = 0l;
 declare__registers_4_interrupt:
  goto interrupt_4;
 }

 write__comma__list_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 write__comma__list_5_clear_reason:
  reasonp = reasons;
 write__comma__list_5_0:
 write__comma__list_5_1:
  if (!isint(a0)) goto write__comma__list_5_3;
  x0 = makeint(0L);
  gblt_less_or_eq(a0,x0,write__comma__list_5_2);
  unify(a4, a3);
  proceed();
 write__comma__list_5_2:
  x1 = makeint(0L);
  gblt_greater(a0,x1,write__comma__list_5_interrupt);
  x2 = makeint(1L);
  bblt_sub_no_check(a0,x2,x3);
  allocp[0] = NILATOM;
  allocp[1] = x3;
  x4 = makecons(&allocp[0]);
  allocp[2] = x4;
  allocp[3] = a1;
  x5 = makecons(&allocp[2]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[6] = makefunctor(&string_const_62);
  allocp[7] = x5;
  allocp[8] = x6 = makeref(&allocp[8]);
  allocp[9] = a4;
  allocp[10] = (q)(struct goalrec*)&allocp[4];
  allocp[11] = (q)(&predicate_klic__comp__write_xwrite__comma__list1_5);
  allocp[12] = makeint(0L);
  allocp[13] = x3;
  allocp[14] = a1;
  allocp[15] = x7 = makeref(&allocp[15]);
  allocp[16] = x6;
  allocp[17] = NILATOM;
  allocp[18] = a2;
  x8 = makecons(&allocp[17]);
  allocp[19] = (q)(struct goalrec*)&allocp[10];
  allocp[20] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[21] = makefunctor(&string_const_61);
  allocp[22] = x8;
  allocp[23] = a3;
  allocp[24] = x7;
  qp = (struct goalrec*)&allocp[19];
  allocp += 25;
  proceed();
 write__comma__list_5_3:
  if (!isref(a0)) goto write__comma__list_5_interrupt;
  deref_and_jump(a0,write__comma__list_5_1);
  *reasonp++ =  a0;
  goto write__comma__list_5_interrupt;
 write__comma__list_5_ext_interrupt:
  reasonp = 0l;
 write__comma__list_5_interrupt:
  toppred = &predicate_klic__comp__write_xwrite__comma__list_5;
  goto interrupt_5;
 }

 write__comma__list1_5_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 write__comma__list1_5_clear_reason:
  reasonp = reasons;
 write__comma__list1_5_0:
 write__comma__list1_5_1:
  if (!isint(a0)) goto write__comma__list1_5_5;
 write__comma__list1_5_2:
  if (!isint(a1)) goto write__comma__list1_5_4;
  gblt_greater_or_eq(a0,a1,write__comma__list1_5_3);
  unify(a4, a3);
  proceed();
 write__comma__list1_5_3:
  gblt_less(a0,a1,write__comma__list1_5_interrupt);
  x0 = makeint(1L);
  bblt_add_no_check(a0,x0,x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xwrite__comma__list1_5);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = NILATOM;
  allocp[8] = a0;
  x3 = makecons(&allocp[7]);
  allocp[9] = x3;
  allocp[10] = a2;
  x4 = makecons(&allocp[9]);
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[13] = makefunctor(&string_const_63);
  allocp[14] = x4;
  allocp[15] = a3;
  allocp[16] = x2;
  qp = (struct goalrec*)&allocp[11];
  allocp += 17;
  proceed();
 write__comma__list1_5_4:
  if (!isref(a1)) goto write__comma__list1_5_interrupt;
  deref_and_jump(a1,write__comma__list1_5_2);
  *reasonp++ =  a1;
  goto write__comma__list1_5_interrupt;
 write__comma__list1_5_5:
  if (!isref(a0)) goto write__comma__list1_5_interrupt;
  deref_and_jump(a0,write__comma__list1_5_1);
  *reasonp++ =  a0;
  goto write__comma__list1_5_interrupt;
 write__comma__list1_5_ext_interrupt:
  reasonp = 0l;
 write__comma__list1_5_interrupt:
  goto interrupt_5;
 }

 write__native__pred__dispatch_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 write__native__pred__dispatch_4_clear_reason:
  reasonp = reasons;
 write__native__pred__dispatch_4_0:
 write__native__pred__dispatch_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 write__native__pred__dispatch_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_native__exec_3)) goto write__native__pred__dispatch_4_3;
  x1 = makeint(1L);
  bblt_add_no_check_y(a1,x1,x2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xwrite__native__pred__dispatch_4);
  x3 = cdr_of(a0);
  allocp[2] = x3;
  allocp[3] = x2;
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = NILATOM;
  x6 = arg(x0, 2);
  allocp[7] = x6;
  x5 = makecons(&allocp[6]);
  allocp[8] = x5;
  x8 = arg(x0, 1);
  allocp[9] = x8;
  x7 = makecons(&allocp[8]);
  allocp[10] = x7;
  x10 = arg(x0, 0);
  allocp[11] = x10;
  x9 = makecons(&allocp[10]);
  allocp[12] = x9;
  allocp[13] = x2;
  x11 = makecons(&allocp[12]);
  allocp[14] = (q)(struct goalrec*)&allocp[0];
  allocp[15] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[16] = makefunctor(&string_const_1);
  allocp[17] = x11;
  allocp[18] = a2;
  allocp[19] = x4;
  qp = (struct goalrec*)&allocp[14];
  allocp += 20;
  proceed();
 case VARREF:
  deref_and_jump(x0,write__native__pred__dispatch_4_2);
  *reasonp++ =  x0;
  goto write__native__pred__dispatch_4_3;
  };
  goto write__native__pred__dispatch_4_3;
 case ATOMIC:
  if (a0 != NILATOM) goto write__native__pred__dispatch_4_3;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,write__native__pred__dispatch_4_1);
  *reasonp++ =  a0;
  goto write__native__pred__dispatch_4_3;
  };
  goto write__native__pred__dispatch_4_3;
 write__native__pred__dispatch_4_3:
  otherwise(write__native__pred__dispatch_4_interrupt);
 write__native__pred__dispatch_4_4:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(write__native__pred__dispatch_4_0);
  goto write__native__pred__dispatch_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,write__native__pred__dispatch_4_4);
  *reasonp++ =  a0;
  goto write__native__pred__dispatch_4_interrupt;
  };
  goto write__native__pred__dispatch_4_interrupt;
 write__native__pred__dispatch_4_ext_interrupt:
  reasonp = 0l;
 write__native__pred__dispatch_4_interrupt:
  goto interrupt_4;
 }

 write__pred__dispatch_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  qp = qp->next;
 write__pred__dispatch_3_clear_reason:
  reasonp = reasons;
 write__pred__dispatch_3_0:
 write__pred__dispatch_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 write__pred__dispatch_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_5)) goto write__pred__dispatch_3_interrupt;
  x1 = cdr_of(a0);
 write__pred__dispatch_3_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto write__pred__dispatch_3_4;
  allocp[0] = NILATOM;
  x3 = arg(x0, 1);
  allocp[1] = x3;
  x2 = makecons(&allocp[0]);
  allocp[2] = x2;
  x5 = arg(x0, 0);
  allocp[3] = x5;
  x4 = makecons(&allocp[2]);
  allocp[4] = x4;
  x7 = arg(x0, 2);
  allocp[5] = x7;
  x6 = makecons(&allocp[4]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[8] = makefunctor(&string_const_3);
  allocp[9] = x6;
  allocp[10] = a1;
  allocp[11] = a2;
  qp = (struct goalrec*)&allocp[6];
  allocp += 12;
  proceed();
 case VARREF:
  deref_and_jump(x1,write__pred__dispatch_3_3);
  *reasonp++ =  x1;
  goto write__pred__dispatch_3_interrupt;
  };
  goto write__pred__dispatch_3_4;
 write__pred__dispatch_3_4:
  x2 = NILATOM;
  gblt_diff(x1,x2,write__pred__dispatch_3_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xwrite__pred__dispatch_3);
  allocp[2] = x1;
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = NILATOM;
  x5 = arg(x0, 1);
  allocp[6] = x5;
  x4 = makecons(&allocp[5]);
  allocp[7] = x4;
  x7 = arg(x0, 0);
  allocp[8] = x7;
  x6 = makecons(&allocp[7]);
  allocp[9] = x6;
  x9 = arg(x0, 2);
  allocp[10] = x9;
  x8 = makecons(&allocp[9]);
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[13] = makefunctor(&string_const_2);
  allocp[14] = x8;
  allocp[15] = a1;
  allocp[16] = x3;
  qp = (struct goalrec*)&allocp[11];
  allocp += 17;
  proceed();
 case VARREF:
  deref_and_jump(x0,write__pred__dispatch_3_2);
  *reasonp++ =  x0;
  goto write__pred__dispatch_3_interrupt;
  };
  goto write__pred__dispatch_3_interrupt;
 case VARREF:
  deref_and_jump(a0,write__pred__dispatch_3_1);
  *reasonp++ =  a0;
  goto write__pred__dispatch_3_interrupt;
  };
  goto write__pred__dispatch_3_interrupt;
 write__pred__dispatch_3_ext_interrupt:
  reasonp = 0l;
 write__pred__dispatch_3_interrupt:
  goto interrupt_3;
 }

 write__call__native__pred_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20;
  a2 = qp->args[2];
  qp = qp->next;
 write__call__native__pred_3_clear_reason:
  reasonp = reasons;
 write__call__native__pred_3_0:
 write__call__native__pred_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 write__call__native__pred_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_native__exec_3)) goto write__call__native__pred_3_3;
  x1 = arg(x0, 2);
  x2 = makeint(1L);
  bblt_add_no_check_y(x1,x2,x3);
  x4 = makeint(1L);
  bblt_add_no_check_y(x1,x4,x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xwrite__call__native__pred_3);
  x6 = cdr_of(a0);
  allocp[2] = x6;
  allocp[3] = x7 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = NILATOM;
  allocp[6] = x5;
  x8 = makecons(&allocp[5]);
  allocp[7] = x8;
  allocp[8] = x3;
  x9 = makecons(&allocp[7]);
  allocp[9] = x9;
  allocp[10] = x1;
  x10 = makecons(&allocp[9]);
  allocp[11] = x10;
  allocp[12] = x1;
  x11 = makecons(&allocp[11]);
  allocp[13] = x11;
  x13 = arg(x0, 1);
  allocp[14] = x13;
  x12 = makecons(&allocp[13]);
  allocp[15] = x12;
  x15 = arg(x0, 0);
  allocp[16] = x15;
  x14 = makecons(&allocp[15]);
  allocp[17] = x14;
  allocp[18] = x1;
  x16 = makecons(&allocp[17]);
  allocp[19] = x16;
  x18 = arg(x0, 1);
  allocp[20] = x18;
  x17 = makecons(&allocp[19]);
  allocp[21] = x17;
  x20 = arg(x0, 0);
  allocp[22] = x20;
  x19 = makecons(&allocp[21]);
  allocp[23] = (q)(struct goalrec*)&allocp[0];
  allocp[24] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[25] = makefunctor(&string_const_34);
  allocp[26] = x19;
  allocp[27] = a1;
  allocp[28] = x7;
  qp = (struct goalrec*)&allocp[23];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(x0,write__call__native__pred_3_2);
  *reasonp++ =  x0;
  goto write__call__native__pred_3_3;
  };
  goto write__call__native__pred_3_3;
 case ATOMIC:
  if (a0 != NILATOM) goto write__call__native__pred_3_3;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,write__call__native__pred_3_1);
  *reasonp++ =  a0;
  goto write__call__native__pred_3_3;
  };
  goto write__call__native__pred_3_3;
 write__call__native__pred_3_3:
  otherwise(write__call__native__pred_3_interrupt);
 write__call__native__pred_3_4:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(write__call__native__pred_3_0);
  goto write__call__native__pred_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,write__call__native__pred_3_4);
  *reasonp++ =  a0;
  goto write__call__native__pred_3_interrupt;
  };
  goto write__call__native__pred_3_interrupt;
 write__call__native__pred_3_ext_interrupt:
  reasonp = 0l;
 write__call__native__pred_3_interrupt:
  goto interrupt_3;
 }

 write__predicates_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20, x21, x22, x23, x24, x25, x26, x27, x28, x29, x30, x31, x32;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 write__predicates_6_clear_reason:
  reasonp = reasons;
 write__predicates_6_0:
 write__predicates_6_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 write__predicates_6_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_5)) goto write__predicates_6_interrupt;
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = makefunctor(funct_const_65);
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a4, x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xwrite__predicates_6);
  x3 = cdr_of(a0);
  allocp[2] = x3;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x4 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = NILATOM;
  x6 = arg(x0, 1);
  allocp[9] = x6;
  x5 = makecons(&allocp[8]);
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[12] = makefunctor(&string_const_23);
  allocp[13] = x5;
  allocp[14] = x7 = makeref(&allocp[14]);
  allocp[15] = x4;
  allocp[16] = (q)(struct goalrec*)&allocp[10];
  allocp[17] = (q)(&predicate_klic__comp__write_xwrite__predicates__1_6);
  allocp[18] = x8 = makeref(&allocp[18]);
  allocp[19] = a1;
  x9 = arg(x0, 0);
  allocp[20] = x9;
  x10 = arg(x0, 1);
  allocp[21] = x10;
  allocp[22] = x11 = makeref(&allocp[22]);
  allocp[23] = x7;
  allocp[24] = makesym(functor__2F_2);
  allocp[25] = x9;
  allocp[26] = x10;
  x12 = makefunctor(&allocp[24]);
  allocp[27] = makesym(functor_exec_1);
  allocp[28] = x12;
  x13 = makefunctor(&allocp[27]);
  allocp[29] = (q)(struct goalrec*)&allocp[16];
  allocp[30] = (q)(&predicate_klic__comp__util_xmember_3);
  allocp[31] = a3;
  allocp[32] = x13;
  allocp[33] = x8;
  allocp[34] = NILATOM;
  allocp[35] = x10;
  x14 = makecons(&allocp[34]);
  allocp[36] = x14;
  allocp[37] = x9;
  x15 = makecons(&allocp[36]);
  allocp[38] = x15;
  allocp[39] = x10;
  x16 = makecons(&allocp[38]);
  allocp[40] = x16;
  allocp[41] = x9;
  x17 = makecons(&allocp[40]);
  allocp[42] = (q)(struct goalrec*)&allocp[29];
  allocp[43] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[44] = makefunctor(&string_const_39);
  allocp[45] = x17;
  allocp[46] = x18 = makeref(&allocp[46]);
  allocp[47] = x11;
  allocp[48] = makesym(functor_info_3);
  allocp[49] = a1;
  allocp[50] = x9;
  allocp[51] = x10;
  x19 = makefunctor(&allocp[48]);
  allocp[52] = (q)(struct goalrec*)&allocp[42];
  allocp[53] = (q)(&predicate_klic__comp__obj_xwrite__object_4);
  x20 = arg(x0, 4);
  allocp[54] = x20;
  allocp[55] = x19;
  allocp[56] = x21 = makeref(&allocp[56]);
  allocp[57] = x18;
  allocp[58] = NILATOM;
  allocp[59] = x10;
  x22 = makecons(&allocp[58]);
  allocp[60] = x22;
  allocp[61] = x9;
  x23 = makecons(&allocp[60]);
  allocp[62] = (q)(struct goalrec*)&allocp[52];
  allocp[63] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[64] = makefunctor(&string_const_38);
  allocp[65] = x23;
  allocp[66] = x24 = makeref(&allocp[66]);
  allocp[67] = x21;
  allocp[68] = NILATOM;
  allocp[69] = x26 = makeref(&allocp[69]);
  x25 = makecons(&allocp[68]);
  allocp[70] = (q)(struct goalrec*)&allocp[62];
  allocp[71] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[72] = makefunctor(&string_const_25);
  allocp[73] = x25;
  allocp[74] = x27 = makeref(&allocp[74]);
  allocp[75] = x24;
  allocp[76] = (q)(struct goalrec*)&allocp[70];
  allocp[77] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[78] = makeint(1L);
  allocp[79] = x10;
  allocp[80] = x26;
  allocp[81] = (q)(struct goalrec*)&allocp[76];
  allocp[82] = (q)(&predicate_klic__comp__write_xwrite__get__args__stack_4);
  allocp[83] = a2;
  allocp[84] = x10;
  allocp[85] = x28 = makeref(&allocp[85]);
  allocp[86] = x27;
  allocp[87] = (q)(struct goalrec*)&allocp[81];
  allocp[88] = (q)(&predicate_klic__comp__write_xdeclare__registers_4);
  x29 = arg(x0, 3);
  allocp[89] = x29;
  allocp[90] = makefunctor(&string_const_59);
  allocp[91] = x30 = makeref(&allocp[91]);
  allocp[92] = x28;
  allocp[93] = NILATOM;
  allocp[94] = x10;
  x31 = makecons(&allocp[93]);
  allocp[95] = x31;
  allocp[96] = x9;
  x32 = makecons(&allocp[95]);
  allocp[97] = (q)(struct goalrec*)&allocp[87];
  allocp[98] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[99] = makefunctor(&string_const_40);
  allocp[100] = x32;
  allocp[101] = x2;
  allocp[102] = x30;
  qp = (struct goalrec*)&allocp[97];
  allocp += 103;
  proceed();
 case VARREF:
  deref_and_jump(x0,write__predicates_6_2);
  *reasonp++ =  x0;
  goto write__predicates_6_interrupt;
  };
  goto write__predicates_6_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto write__predicates_6_interrupt;
  unify(a5, a4);
  proceed();
 case VARREF:
  deref_and_jump(a0,write__predicates_6_1);
  *reasonp++ =  a0;
  goto write__predicates_6_interrupt;
  };
  goto write__predicates_6_interrupt;
 write__predicates_6_ext_interrupt:
  reasonp = 0l;
 write__predicates_6_interrupt:
  goto interrupt_6;
 }

 write__predicates__1_6_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 write__predicates__1_6_clear_reason:
  reasonp = reasons;
 write__predicates__1_6_0:
 write__predicates__1_6_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto write__predicates__1_6_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  allocp[0] = NILATOM;
  allocp[1] = a3;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a2;
  x1 = makecons(&allocp[2]);
  allocp[4] = x1;
  allocp[5] = a1;
  x2 = makecons(&allocp[4]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[8] = makefunctor(&string_const_31);
  allocp[9] = x2;
  allocp[10] = a4;
  allocp[11] = a5;
  qp = (struct goalrec*)&allocp[6];
  allocp += 12;
  proceed();
 case symval(makesym(atom_no)):
  unify(a5, a4);
  proceed();
  };
  goto write__predicates__1_6_interrupt;
 case VARREF:
  deref_and_jump(a0,write__predicates__1_6_1);
  *reasonp++ =  a0;
  goto write__predicates__1_6_interrupt;
  };
  goto write__predicates__1_6_interrupt;
 write__predicates__1_6_ext_interrupt:
  reasonp = 0l;
 write__predicates__1_6_interrupt:
  goto interrupt_6;
 }

 write__get__args_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 write__get__args_4_clear_reason:
  reasonp = reasons;
 write__get__args_4_0:
 write__get__args_4_1:
  if (!isint(a0)) goto write__get__args_4_5;
 write__get__args_4_2:
  if (!isint(a1)) goto write__get__args_4_4;
  gblt_eq(a0,a1,write__get__args_4_3);
  unify(a3, a2);
  proceed();
 write__get__args_4_3:
  gblt_less(a0,a1,write__get__args_4_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xwrite__get__args_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x0;
  allocp[11] = NILATOM;
  allocp[12] = a0;
  x2 = makecons(&allocp[11]);
  allocp[13] = x2;
  allocp[14] = a0;
  x3 = makecons(&allocp[13]);
  allocp[15] = (q)(struct goalrec*)&allocp[6];
  allocp[16] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[17] = makefunctor(&string_const_14);
  allocp[18] = x3;
  allocp[19] = a2;
  allocp[20] = x1;
  qp = (struct goalrec*)&allocp[15];
  allocp += 21;
  proceed();
 write__get__args_4_4:
  if (!isref(a1)) goto write__get__args_4_interrupt;
  deref_and_jump(a1,write__get__args_4_2);
  *reasonp++ =  a1;
  goto write__get__args_4_interrupt;
 write__get__args_4_5:
  if (!isref(a0)) goto write__get__args_4_interrupt;
  deref_and_jump(a0,write__get__args_4_1);
  *reasonp++ =  a0;
  goto write__get__args_4_interrupt;
 write__get__args_4_ext_interrupt:
  reasonp = 0l;
 write__get__args_4_interrupt:
  goto interrupt_4;
 }

 write__get__args__stack_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 write__get__args__stack_4_clear_reason:
  reasonp = reasons;
 write__get__args__stack_4_0:
 write__get__args__stack_4_1:
  if (!isint(a0)) goto write__get__args__stack_4_5;
 write__get__args__stack_4_2:
  if (!isint(a1)) goto write__get__args__stack_4_4;
  gblt_eq(a0,a1,write__get__args__stack_4_3);
  unify(a3, a2);
  proceed();
 write__get__args__stack_4_3:
  gblt_less(a0,a1,write__get__args__stack_4_interrupt);
  bblt_sub_no_check(a1,a0,x0);
  x1 = makeint(1L);
  bblt_add_no_check(x0,x1,x2);
  bblt_minus_no_check(x2,x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xwrite__get__args__stack_4);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x5 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x4;
  allocp[11] = NILATOM;
  allocp[12] = x3;
  x6 = makecons(&allocp[11]);
  allocp[13] = x6;
  allocp[14] = a0;
  x7 = makecons(&allocp[13]);
  allocp[15] = (q)(struct goalrec*)&allocp[6];
  allocp[16] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[17] = makefunctor(&string_const_15);
  allocp[18] = x7;
  allocp[19] = a2;
  allocp[20] = x5;
  qp = (struct goalrec*)&allocp[15];
  allocp += 21;
  proceed();
 write__get__args__stack_4_4:
  if (!isref(a1)) goto write__get__args__stack_4_interrupt;
  deref_and_jump(a1,write__get__args__stack_4_2);
  *reasonp++ =  a1;
  goto write__get__args__stack_4_interrupt;
 write__get__args__stack_4_5:
  if (!isref(a0)) goto write__get__args__stack_4_interrupt;
  deref_and_jump(a0,write__get__args__stack_4_1);
  *reasonp++ =  a0;
  goto write__get__args__stack_4_interrupt;
 write__get__args__stack_4_ext_interrupt:
  reasonp = 0l;
 write__get__args__stack_4_interrupt:
  goto interrupt_4;
 }

 write__interrupt__call_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 write__interrupt__call_4_clear_reason:
  reasonp = reasons;
 write__interrupt__call_4_0:
 write__interrupt__call_4_1:
  if (!isint(a0)) goto write__interrupt__call_4_3;
  x0 = makeint(0L);
  gblt_less_or_eq(a0,x0,write__interrupt__call_4_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__obj_xklicformat_3);
  allocp[2] = makefunctor(&string_const_35);
  allocp[3] = a2;
  allocp[4] = a3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 write__interrupt__call_4_2:
  x1 = makeint(0L);
  gblt_greater(a0,x1,write__interrupt__call_4_interrupt);
  x2 = makeint(1L);
  bblt_sub_no_check(a0,x2,x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xwrite__interrupt__call_4);
  allocp[2] = x3;
  allocp[3] = a1;
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = NILATOM;
  allocp[7] = x3;
  x5 = makecons(&allocp[6]);
  allocp[8] = x5;
  allocp[9] = x3;
  x6 = makecons(&allocp[8]);
  allocp[10] = x6;
  allocp[11] = a0;
  x7 = makecons(&allocp[10]);
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[14] = makefunctor(&string_const_36);
  allocp[15] = x7;
  allocp[16] = a2;
  allocp[17] = x4;
  qp = (struct goalrec*)&allocp[12];
  allocp += 18;
  proceed();
 write__interrupt__call_4_3:
  if (!isref(a0)) goto write__interrupt__call_4_interrupt;
  deref_and_jump(a0,write__interrupt__call_4_1);
  *reasonp++ =  a0;
  goto write__interrupt__call_4_interrupt;
 write__interrupt__call_4_ext_interrupt:
  reasonp = 0l;
 write__interrupt__call_4_interrupt:
  goto interrupt_4;
 }

 write__header__file_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  qp = qp->next;
 write__header__file_3_clear_reason:
  reasonp = reasons;
 write__header__file_3_0:
 write__header__file_3_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_module_3)) goto write__header__file_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xwrite__ext__entries_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_klic__comp__util_xqsort_2);
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = x0;
  allocp[9] = (q)(struct goalrec*)&allocp[5];
  allocp[10] = (q)(&predicate_klic__comp__extern_xmake__ext__table_3);
  x3 = arg(a0, 2);
  allocp[11] = x3;
  allocp[12] = x2;
  allocp[13] = NILATOM;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_klic__comp__write_xwrite__defined__preds_4);
  x4 = arg(a0, 1);
  allocp[16] = x4;
  x5 = arg(a0, 0);
  allocp[17] = x5;
  allocp[18] = x6 = makeref(&allocp[18]);
  allocp[19] = x1;
  allocp[20] = NILATOM;
  allocp[21] = x5;
  x7 = makecons(&allocp[20]);
  allocp[22] = (q)(struct goalrec*)&allocp[14];
  allocp[23] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[24] = makefunctor(&string_const_55);
  allocp[25] = x7;
  allocp[26] = a1;
  allocp[27] = x6;
  qp = (struct goalrec*)&allocp[22];
  allocp += 28;
  proceed();
 case VARREF:
  deref_and_jump(a0,write__header__file_3_1);
  *reasonp++ =  a0;
  goto write__header__file_3_interrupt;
  };
  goto write__header__file_3_interrupt;
 write__header__file_3_ext_interrupt:
  reasonp = 0l;
 write__header__file_3_interrupt:
  goto interrupt_3;
 }

 write__ext__entries_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 write__ext__entries_3_clear_reason:
  reasonp = reasons;
 write__ext__entries_3_0:
 write__ext__entries_3_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xwrite__ext__entries_3);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  a0 = car_of(a0);
  a2 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(write__ext__entry_3_0);
  goto write__ext__entry_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto write__ext__entries_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,write__ext__entries_3_1);
  *reasonp++ =  a0;
  goto write__ext__entries_3_interrupt;
  };
  goto write__ext__entries_3_interrupt;
 write__ext__entries_3_ext_interrupt:
  reasonp = 0l;
 write__ext__entries_3_interrupt:
  goto interrupt_3;
 }

 write__ext__entry_3_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  qp = qp->next;
 write__ext__entry_3_clear_reason:
  reasonp = reasons;
 write__ext__entry_3_0:
 write__ext__entry_3_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_atom_1:
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_46);
  allocp[5] = x0;
  allocp[6] = a1;
  allocp[7] = a2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 case functor_funct_1:
  x0 = arg(a0, 0);
 write__ext__entry_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__2F_2)) goto write__ext__entry_3_interrupt;
  allocp[0] = a2;
  allocp[1] = makeint(10L);
  x1 = makecons(&allocp[0]);
  a0 = arg(x0, 0);
  x2 = arg(x0, 1);
  a2 = a1;
  a3 = x1;
  a1 = x2;
  allocp += 2;
  execute(write__funct__name_4_0);
  goto write__funct__name_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,write__ext__entry_3_2);
  *reasonp++ =  x0;
  goto write__ext__entry_3_interrupt;
  };
  goto write__ext__entry_3_interrupt;
 case functor_module_1:
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_58);
  allocp[5] = x0;
  allocp[6] = a1;
  allocp[7] = a2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 case functor_class_1:
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_57);
  allocp[5] = x0;
  allocp[6] = a1;
  allocp[7] = a2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
  };
  goto write__ext__entry_3_interrupt;
 case VARREF:
  deref_and_jump(a0,write__ext__entry_3_1);
  *reasonp++ =  a0;
  goto write__ext__entry_3_interrupt;
  };
  goto write__ext__entry_3_interrupt;
 write__ext__entry_3_ext_interrupt:
  reasonp = 0l;
 write__ext__entry_3_interrupt:
  toppred = &predicate_klic__comp__write_xwrite__ext__entry_3;
  goto interrupt_3;
 }

 write__defined__preds_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 write__defined__preds_4_clear_reason:
  reasonp = reasons;
 write__defined__preds_4_0:
 write__defined__preds_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 write__defined__preds_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_5)) goto write__defined__preds_4_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xwrite__defined__preds_4);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = NILATOM;
  x4 = arg(x0, 1);
  allocp[7] = x4;
  x3 = makecons(&allocp[6]);
  allocp[8] = x3;
  x6 = arg(x0, 0);
  allocp[9] = x6;
  x5 = makecons(&allocp[8]);
  allocp[10] = x5;
  allocp[11] = a1;
  x7 = makecons(&allocp[10]);
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[14] = makefunctor(&string_const_60);
  allocp[15] = x7;
  allocp[16] = a2;
  allocp[17] = x2;
  qp = (struct goalrec*)&allocp[12];
  allocp += 18;
  proceed();
 case VARREF:
  deref_and_jump(x0,write__defined__preds_4_2);
  *reasonp++ =  x0;
  goto write__defined__preds_4_interrupt;
  };
  goto write__defined__preds_4_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto write__defined__preds_4_interrupt;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,write__defined__preds_4_1);
  *reasonp++ =  a0;
  goto write__defined__preds_4_interrupt;
  };
  goto write__defined__preds_4_interrupt;
 write__defined__preds_4_ext_interrupt:
  reasonp = 0l;
 write__defined__preds_4_interrupt:
  goto interrupt_4;
 }

 write__atom_3_top: {
  q x0;
  a2 = qp->args[2];
  qp = qp->next;
 write__atom_3_clear_reason:
  reasonp = reasons;
 write__atom_3_0:
 write__atom_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto write__atom_3_2;
  switch (symval(a0)) {
 case symval(NILATOM):
  allocp[0] = a2;
  allocp[1] = makefunctor(funct_const_79);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  proceed();
 case symval(PERIODATOM):
  allocp[0] = a2;
  allocp[1] = makefunctor(funct_const_81);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  proceed();
  };
  goto write__atom_3_3;
 write__atom_3_2:
  gblt_integer(a0,write__atom_3_3);
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_51);
  allocp[5] = x0;
  allocp[6] = a1;
  allocp[7] = a2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 case VARREF:
  deref_and_jump(a0,write__atom_3_1);
  *reasonp++ =  a0;
  goto write__atom_3_3;
  };
  goto write__atom_3_3;
 write__atom_3_3:
  otherwise(write__atom_3_interrupt);
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_52);
  allocp[5] = x0;
  allocp[6] = a1;
  allocp[7] = a2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 write__atom_3_ext_interrupt:
  reasonp = 0l;
 write__atom_3_interrupt:
  goto interrupt_3;
 }

 write__funct__name_4_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 write__funct__name_4_clear_reason:
  reasonp = reasons;
 write__funct__name_4_0:
  allocp[0] = NILATOM;
  allocp[1] = a1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a0;
  x1 = makecons(&allocp[2]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[6] = makefunctor(&string_const_50);
  allocp[7] = x1;
  allocp[8] = a2;
  allocp[9] = a3;
  qp = (struct goalrec*)&allocp[4];
  allocp += 10;
  proceed();
 write__funct__name_4_ext_interrupt:
  reasonp = 0l;
 write__funct__name_4_interrupt:
  toppred = &predicate_klic__comp__write_xwrite__funct__name_4;
  goto interrupt_4;
 }

 write__pred__name_5_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 write__pred__name_5_clear_reason:
  reasonp = reasons;
 write__pred__name_5_0:
  allocp[0] = NILATOM;
  allocp[1] = a2;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a1;
  x1 = makecons(&allocp[2]);
  allocp[4] = x1;
  allocp[5] = a0;
  x2 = makecons(&allocp[4]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[8] = makefunctor(&string_const_56);
  allocp[9] = x2;
  allocp[10] = a3;
  allocp[11] = a4;
  qp = (struct goalrec*)&allocp[6];
  allocp += 12;
  proceed();
 write__pred__name_5_ext_interrupt:
  reasonp = 0l;
 write__pred__name_5_interrupt:
  goto interrupt_5;
 }

 sort__info_2_top: {
  qp = qp->next;
 sort__info_2_clear_reason:
  reasonp = reasons;
 sort__info_2_0:
  a2 = NILATOM;
  execute(sort__info_3_0);
  goto sort__info_3_ext_interrupt;
 sort__info_2_ext_interrupt:
  reasonp = 0l;
 sort__info_2_interrupt:
  goto interrupt_2;
 }

 sort__info_3_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  qp = qp->next;
 sort__info_3_clear_reason:
  reasonp = reasons;
 sort__info_3_0:
 sort__info_3_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__write_xsort__info_3);
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = a1;
  allocp[6] = x0;
  allocp[7] = (q)(struct goalrec*)&allocp[2];
  allocp[8] = (q)(&predicate_klic__comp__write_xsort__info_3);
  allocp[9] = x4 = makeref(&allocp[9]);
  allocp[10] = x1;
  allocp[11] = a2;
  x5 = cdr_of(a0);
  a1 = car_of(a0);
  a2 = x3;
  a3 = x4;
  a0 = x5;
  qp = (struct goalrec*)&allocp[7];
  allocp += 12;
  execute(partition_4_0);
  goto partition_4_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto sort__info_3_interrupt;
  unify(a1, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,sort__info_3_1);
  *reasonp++ =  a0;
  goto sort__info_3_interrupt;
  };
  goto sort__info_3_interrupt;
 sort__info_3_ext_interrupt:
  reasonp = 0l;
 sort__info_3_interrupt:
  toppred = &predicate_klic__comp__write_xsort__info_3;
  goto interrupt_3;
 }

 partition_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 partition_4_clear_reason:
  reasonp = reasons;
 partition_4_0:
 partition_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 partition_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_const_2)) goto partition_4_12;
 partition_4_3:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_const_2)) goto partition_4_12;
  x1 = arg(x0, 1);
 partition_4_4:
  if (isref(x1)) goto partition_4_11;
 partition_4_5:
  if (isref(x1)) goto partition_4_6;
  x2 = arg(a1, 1);
  if_not_equal(x1, x2, partition_4_7);
  x3 = arg(x0, 0);
  x4 = arg(a1, 0);
  unify(x3, x4);
  a0 = cdr_of(a0);
  execute(partition_4_clear_reason);
  goto partition_4_ext_interrupt;
 partition_4_6:
  deref_and_jump(x1,partition_4_5);
  *reasonp++ =  x1;
  goto partition_4_7;
 partition_4_7:
  x2 = arg(a1, 1);
 partition_4_8:
  if (isref(x2)) goto partition_4_10;
  gblt_compare(x1,x2,x3,partition_4_12);
  x4 = makeint(0L);
  gblt_less(x3,x4,partition_4_9);
  allocp[0] = x6 = makeref(&allocp[0]);
  allocp[1] = x0;
  x5 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x5);
  a0 = cdr_of(a0);
  a2 = x6;
  execute(partition_4_clear_reason);
  goto partition_4_ext_interrupt;
 partition_4_9:
  x5 = makeint(0L);
  gblt_greater(x3,x5,partition_4_12);
  allocp[0] = x7 = makeref(&allocp[0]);
  allocp[1] = x0;
  x6 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a3, x6);
  a0 = cdr_of(a0);
  a3 = x7;
  execute(partition_4_clear_reason);
  goto partition_4_ext_interrupt;
 partition_4_10:
  deref_and_jump(x2,partition_4_8);
  *reasonp++ =  x2;
  goto partition_4_12;
 partition_4_11:
  deref_and_jump(x1,partition_4_4);
  *reasonp++ =  x1;
  goto partition_4_12;
 case VARREF:
  deref_and_jump(a1,partition_4_3);
  *reasonp++ =  a1;
  goto partition_4_12;
  };
  goto partition_4_12;
 case VARREF:
  deref_and_jump(x0,partition_4_2);
  *reasonp++ =  x0;
  goto partition_4_interrupt;
  };
  goto partition_4_12;
 partition_4_12:
 partition_4_13:
  if (isref(x0)) goto partition_4_14;
  if_not_equal(x0, a1, partition_4_15);
  a0 = cdr_of(a0);
  execute(partition_4_clear_reason);
  goto partition_4_ext_interrupt;
 partition_4_14:
  deref_and_jump(x0,partition_4_13);
  *reasonp++ =  x0;
  goto partition_4_15;
 partition_4_15:
 partition_4_16:
  if (isref(a1)) goto partition_4_18;
  gblt_compare(x0,a1,x1,partition_4_interrupt);
  x2 = makeint(0L);
  gblt_less(x1,x2,partition_4_17);
  allocp[0] = x4 = makeref(&allocp[0]);
  allocp[1] = x0;
  x3 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x3);
  a0 = cdr_of(a0);
  a2 = x4;
  execute(partition_4_clear_reason);
  goto partition_4_ext_interrupt;
 partition_4_17:
  x3 = makeint(0L);
  gblt_greater(x1,x3,partition_4_interrupt);
  allocp[0] = x5 = makeref(&allocp[0]);
  allocp[1] = x0;
  x4 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a3, x4);
  a0 = cdr_of(a0);
  a3 = x5;
  execute(partition_4_clear_reason);
  goto partition_4_ext_interrupt;
 partition_4_18:
  deref_and_jump(a1,partition_4_16);
  *reasonp++ =  a1;
  goto partition_4_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto partition_4_interrupt;
  x0 = NILATOM;
  unify_value(a2, x0);
  x1 = NILATOM;
  unify_value(a3, x1);
  proceed();
 case VARREF:
  deref_and_jump(a0,partition_4_1);
  *reasonp++ =  a0;
  goto partition_4_interrupt;
  };
  goto partition_4_interrupt;
 partition_4_ext_interrupt:
  reasonp = 0l;
 partition_4_interrupt:
  toppred = &predicate_klic__comp__write_xpartition_4;
  goto interrupt_4;
 }
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_klic__comp__write);
}
