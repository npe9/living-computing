/* Compiled by KLIC compiler version 3.002 (Wed Sep 17 15:37:13 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_adg();
Const struct predicate predicate_adg_xmake__vio_3 =
   { module_adg, 0, 3 };
Const struct predicate predicate_adg_xmake__vio_4 =
   { module_adg, 1, 4 };
Const struct predicate predicate_adg_xmake_6 =
   { module_adg, 2, 6 };
Const struct predicate predicate_adg_xinit_2 =
   { module_adg, 3, 2 };
Const struct predicate predicate_adg_xinit__pred_2 =
   { module_adg, 4, 2 };
Const struct predicate predicate_adg_xinit__pred__headbody_3 =
   { module_adg, 5, 3 };
Const struct predicate predicate_adg_xvdg2adg_7 =
   { module_adg, 6, 7 };
Const struct predicate predicate_adg_xmake__adg__body__r_11 =
   { module_adg, 7, 11 };
Const struct predicate predicate_adg_xmake__adg__body__r1_10 =
   { module_adg, 8, 10 };
Const struct predicate predicate_adg_xexpand__userdef_11 =
   { module_adg, 9, 11 };
Const struct predicate predicate_adg_xmake__adg__pred_9 =
   { module_adg, 10, 9 };
Const struct predicate predicate_adg_xmake__adg__head__r_12 =
   { module_adg, 11, 12 };
Const struct predicate predicate_adg_xmake__adg__pred__r_9 =
   { module_adg, 12, 9 };
Const struct predicate predicate_adg_xmake__adg__bodys__r_11 =
   { module_adg, 13, 11 };
Const struct predicate predicate_adg_xmake__adg__heads_12 =
   { module_adg, 14, 12 };
Const struct predicate predicate_adg_xmake__bodys__adg_7 =
   { module_adg, 15, 7 };
Const struct predicate predicate_adg_xmake__bodys__adg1_10 =
   { module_adg, 16, 10 };
Const struct predicate predicate_adg_xmake__body__adg_14 =
   { module_adg, 17, 14 };
Const struct predicate predicate_adg_xmake__adg__body_12 =
   { module_adg, 18, 12 };
Const struct predicate predicate_adg_xpred2body_10 =
   { module_adg, 19, 10 };
Const struct predicate predicate_adg_xmake__adg__entry__head_15 =
   { module_adg, 20, 15 };
Const struct predicate predicate_adg_xmake__adg__entry__body__r_15 =
   { module_adg, 21, 15 };
Const struct predicate predicate_adg_xmake__ad_15 =
   { module_adg, 22, 15 };
Const struct predicate predicate_adg_xmake__ad0_12 =
   { module_adg, 23, 12 };
Const struct predicate predicate_adg_xmake__ad1_11 =
   { module_adg, 24, 11 };
Const struct predicate predicate_adg_xexpand__vd_11 =
   { module_adg, 25, 11 };
Const struct predicate predicate_adg_xexpand__vd1_10 =
   { module_adg, 26, 10 };
Const struct predicate predicate_adg_xexpand__vd__direct_3 =
   { module_adg, 27, 3 };
Const struct predicate predicate_adg_xexpand__b_10 =
   { module_adg, 28, 10 };
Const struct predicate predicate_adg_xexpand__b1_13 =
   { module_adg, 29, 13 };
Const struct predicate predicate_adg_xreplace__ti_12 =
   { module_adg, 30, 12 };
Const struct predicate predicate_adg_xreplace__ti1_6 =
   { module_adg, 31, 6 };
Const struct predicate predicate_adg_xreplace__ti2_9 =
   { module_adg, 32, 9 };
Const struct predicate predicate_adg_xreplace__ti__userdefs_12 =
   { module_adg, 33, 12 };
Const struct predicate predicate_adg_xreplace__ti__userdef_13 =
   { module_adg, 34, 13 };
Const struct predicate predicate_adg_xreplace__ti__userdef__arg_17 =
   { module_adg, 35, 17 };
Const struct predicate predicate_adg_xreplace__ti__userdef__arg1_18 =
   { module_adg, 36, 18 };
Const struct predicate predicate_adg_xreplace__ti__adg_11 =
   { module_adg, 37, 11 };
Const struct predicate predicate_adg_xreplace__ti__adg1_5 =
   { module_adg, 38, 5 };
Const struct predicate predicate_adg_xreplace__ti__vd_5 =
   { module_adg, 39, 5 };
Const struct predicate predicate_adg_xreplace__ti__vd1_7 =
   { module_adg, 40, 7 };
Const struct predicate predicate_adg_xentry__ad_8 =
   { module_adg, 41, 8 };
Const struct predicate predicate_adg_xentry__ad__entries_7 =
   { module_adg, 42, 7 };
Const struct predicate predicate_adg_xget__ad_7 =
   { module_adg, 43, 7 };
Const struct predicate predicate_adg_xget__ad__entries_6 =
   { module_adg, 44, 6 };
Const struct predicate predicate_adg_xheads2pred_7 =
   { module_adg, 45, 7 };
Const struct predicate predicate_adg_xheads2pred1_11 =
   { module_adg, 46, 11 };
Const struct predicate predicate_adg_xpredr2headr_10 =
   { module_adg, 47, 10 };
Const struct predicate predicate_adg_xbodysr2predr_7 =
   { module_adg, 48, 7 };
Const struct predicate predicate_adg_xbodysr2pred1_11 =
   { module_adg, 49, 11 };
Const struct predicate predicate_adg_xbodys2pred1_11 =
   { module_adg, 50, 11 };
Const struct predicate predicate_adg_xad__v2a_3 =
   { module_adg, 51, 3 };
Const struct predicate predicate_adg_xv2a_3 =
   { module_adg, 52, 3 };
Const struct predicate predicate_adg_xv2a1_6 =
   { module_adg, 53, 6 };
Const struct predicate predicate_adg_xvd__v2a_3 =
   { module_adg, 54, 3 };
Const struct predicate predicate_adg_xb__v2a_3 =
   { module_adg, 55, 3 };
Const struct predicate predicate_adg_xad__a2v_5 =
   { module_adg, 56, 5 };
Const struct predicate predicate_adg_xa2v_5 =
   { module_adg, 57, 5 };
Const struct predicate predicate_adg_xvd__a2v_5 =
   { module_adg, 58, 5 };
Const struct predicate predicate_adg_xb__a2v_5 =
   { module_adg, 59, 5 };
Const struct predicate predicate_adg_xgid2goal_3 =
   { module_adg, 60, 3 };
Const struct predicate predicate_adg_xget__ogoal_14 =
   { module_adg, 61, 14 };
Const struct predicate predicate_adg_xget__ogoal__goals_18 =
   { module_adg, 62, 18 };
Const struct predicate predicate_adg_xget__ogoal__goal_18 =
   { module_adg, 63, 18 };
Const struct predicate predicate_adg_xget__ogoal__goal1_20 =
   { module_adg, 64, 20 };
Const struct predicate predicate_adg_xget__ogoal__userdef_21 =
   { module_adg, 65, 21 };
Const struct predicate predicate_adg_xget__ogoal__builtin_19 =
   { module_adg, 66, 19 };
Const struct predicate predicate_adg_xget__ogoal__builtin1_22 =
   { module_adg, 67, 22 };
Const struct predicate predicate_adg_xget__ogoal__unify_18 =
   { module_adg, 68, 18 };
Const struct predicate predicate_adg_xget__ogoal__unify0_20 =
   { module_adg, 69, 20 };
Const struct predicate predicate_adg_xget__ogoal__unify1_15 =
   { module_adg, 70, 15 };
Const struct predicate predicate_adg_xget__ogoal__its_5 =
   { module_adg, 71, 5 };
Const struct predicate predicate_adg_xget__builtin__ioargs_4 =
   { module_adg, 72, 4 };
Const struct predicate predicate_adg_xcheck__ta__in__ad_11 =
   { module_adg, 73, 11 };
Const struct predicate predicate_adg_xcheck__ta__in__ad1_12 =
   { module_adg, 74, 12 };
Const struct predicate predicate_adg_xcheck__ta__in__ad2_4 =
   { module_adg, 75, 4 };
Const struct predicate predicate_adg_xcheck__ta__in__ad__b_4 =
   { module_adg, 76, 4 };
Const struct predicate predicate_adg_xappend__tavd_11 =
   { module_adg, 77, 11 };
Const struct predicate predicate_adg_xappend__tavd__iarg_18 =
   { module_adg, 78, 18 };
Const struct predicate predicate_adg_xtavd__make__vd_3 =
   { module_adg, 79, 3 };
Const struct predicate predicate_adg_xget__vars__in__struct_4 =
   { module_adg, 80, 4 };
Const struct predicate predicate_adg_xget__vars__in__struct_5 =
   { module_adg, 81, 5 };
Const struct predicate predicate_adg_xget__vars__in__struct__struct_6 =
   { module_adg, 82, 6 };
extern Const struct predicate predicate_list_xor__unique_3;
extern Const struct predicate predicate_list_xcheck__include_3;
extern Const struct predicate predicate_list_xappend_3;
extern Const struct predicate predicate_functor_xnew__functor__init_4;
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_xsetarg_4;
extern Const struct predicate predicate_functor__table_xfunctor_3;
extern Const struct predicate predicate_hb_xmake__io_3;
extern Const struct predicate predicate_hb_xget__bio_5;
extern Const struct predicate predicate_hb_xget__hio_5;
extern Const struct predicate predicate_hb_xget__gids_6;
extern Const struct predicate predicate_hb_xget__pn_7;
extern Const struct predicate predicate_hb_xread__mode_6;
extern Const struct predicate predicate_hb_xget__pnmax_6;
extern Const struct predicate predicate_hb_xget__modes_5;
extern Const struct predicate predicate_parse__uty_xget__goal_6;
extern Const struct predicate predicate_parse__uty_xget__clause_4;
extern Const struct predicate predicate_parse__uty_xdecode__goalcall_5;
extern Const struct predicate predicate_parse__uty_xdecode__goalcall_6;
extern Const struct predicate predicate_parse__uty_xdecode__goal_4;
extern Const struct predicate predicate_typeset_xget_5;
extern Const struct predicate predicate_typeset_xvars2vs3_4;
extern Const struct predicate predicate_typeset_xcheck__same__type_4;
extern Const struct predicate predicate_typeset_xget__ds_5;
extern Const struct predicate predicate_typeset_xvalue2typeset_5;
extern Const struct predicate predicate_vdg_xread__vd_5;

module module_adg(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  static Const q funct_const_0[] = {
    makesym(functor_t_2),
    makesym(atom__2A),
    NILATOM,
  };
  static Const q cons_const_1[] = {
    NILATOM,
    makefunctor(funct_const_0),
  };
  static Const q funct_const_2[] = {
    makesym(functor_t_2),
    makesym(atom_i),
    NILATOM,
  };
  static Const q cons_const_3[] = {
    NILATOM,
    makefunctor(funct_const_2),
  };
  static Const q funct_const_4[] = {
    makesym(functor_t_2),
    makesym(atom_i),
    NILATOM,
  };
  static Const q cons_const_5[] = {
    makecons(cons_const_3),
    makefunctor(funct_const_4),
  };
  static Const q funct_const_6[] = {
    makesym(functor_pred_1),
    NILATOM,
  };
  static Const q funct_const_7[] = {
    makesym(functor_pred__r_1),
    NILATOM,
  };
  q a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17, a18, a19, a20, a21;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, make__vio_3_top);
    case_pred(1, make__vio_4_top);
    case_pred(2, make_6_top);
    case_pred(3, init_2_top);
    case_pred(4, init__pred_2_top);
    case_pred(5, init__pred__headbody_3_top);
    case_pred(6, vdg2adg_7_top);
    case_pred(7, make__adg__body__r_11_top);
    case_pred(8, make__adg__body__r1_10_top);
    case_pred(9, expand__userdef_11_top);
    case_pred(10, make__adg__pred_9_top);
    case_pred(11, make__adg__head__r_12_top);
    case_pred(12, make__adg__pred__r_9_top);
    case_pred(13, make__adg__bodys__r_11_top);
    case_pred(14, make__adg__heads_12_top);
    case_pred(15, make__bodys__adg_7_top);
    case_pred(16, make__bodys__adg1_10_top);
    case_pred(17, make__body__adg_14_top);
    case_pred(18, make__adg__body_12_top);
    case_pred(19, pred2body_10_top);
    case_pred(20, make__adg__entry__head_15_top);
    case_pred(21, make__adg__entry__body__r_15_top);
    case_pred(22, make__ad_15_top);
    case_pred(23, make__ad0_12_top);
    case_pred(24, make__ad1_11_top);
    case_pred(25, expand__vd_11_top);
    case_pred(26, expand__vd1_10_top);
    case_pred(27, expand__vd__direct_3_top);
    case_pred(28, expand__b_10_top);
    case_pred(29, expand__b1_13_top);
    case_pred(30, replace__ti_12_top);
    case_pred(31, replace__ti1_6_top);
    case_pred(32, replace__ti2_9_top);
    case_pred(33, replace__ti__userdefs_12_top);
    case_pred(34, replace__ti__userdef_13_top);
    case_pred(35, replace__ti__userdef__arg_17_top);
    case_pred(36, replace__ti__userdef__arg1_18_top);
    case_pred(37, replace__ti__adg_11_top);
    case_pred(38, replace__ti__adg1_5_top);
    case_pred(39, replace__ti__vd_5_top);
    case_pred(40, replace__ti__vd1_7_top);
    case_pred(41, entry__ad_8_top);
    case_pred(42, entry__ad__entries_7_top);
    case_pred(43, get__ad_7_top);
    case_pred(44, get__ad__entries_6_top);
    case_pred(45, heads2pred_7_top);
    case_pred(46, heads2pred1_11_top);
    case_pred(47, predr2headr_10_top);
    case_pred(48, bodysr2predr_7_top);
    case_pred(49, bodysr2pred1_11_top);
    case_pred(50, bodys2pred1_11_top);
    case_pred(51, ad__v2a_3_top);
    case_pred(52, v2a_3_top);
    case_pred(53, v2a1_6_top);
    case_pred(54, vd__v2a_3_top);
    case_pred(55, b__v2a_3_top);
    case_pred(56, ad__a2v_5_top);
    case_pred(57, a2v_5_top);
    case_pred(58, vd__a2v_5_top);
    case_pred(59, b__a2v_5_top);
    case_pred(60, gid2goal_3_top);
    case_pred(61, get__ogoal_14_top);
    case_pred(62, get__ogoal__goals_18_top);
    case_pred(63, get__ogoal__goal_18_top);
    case_pred(64, get__ogoal__goal1_20_top);
    case_pred(65, get__ogoal__userdef_21_top);
    case_pred(66, get__ogoal__builtin_19_top);
    case_pred(67, get__ogoal__builtin1_22_top);
    case_pred(68, get__ogoal__unify_18_top);
    case_pred(69, get__ogoal__unify0_20_top);
    case_pred(70, get__ogoal__unify1_15_top);
    case_pred(71, get__ogoal__its_5_top);
    case_pred(72, get__builtin__ioargs_4_top);
    case_pred(73, check__ta__in__ad_11_top);
    case_pred(74, check__ta__in__ad1_12_top);
    case_pred(75, check__ta__in__ad2_4_top);
    case_pred(76, check__ta__in__ad__b_4_top);
    case_pred(77, append__tavd_11_top);
    case_pred(78, append__tavd__iarg_18_top);
    case_pred(79, tavd__make__vd_3_top);
    case_pred(80, get__vars__in__struct_4_top);
    case_pred(81, get__vars__in__struct_5_top);
    last_case_pred(82, get__vars__in__struct__struct_6_top);
  }

 make__vio_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 make__vio_3_clear_reason:
  reasonp = reasons;
 make__vio_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xmake__vio_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[8] = a0;
  allocp[9] = x1 = makeref(&allocp[9]);
  allocp[10] = x0;
  qp = (struct goalrec*)&allocp[6];
  allocp += 11;
  proceed();
 make__vio_3_ext_interrupt:
  reasonp = 0l;
 make__vio_3_interrupt:
  goto interrupt_3;
 }

 make__vio_4_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 make__vio_4_clear_reason:
  reasonp = reasons;
 make__vio_4_0:
 make__vio_4_1:
  if (!isint(a0)) goto make__vio_4_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,make__vio_4_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xmake__vio_4);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x1;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[13] = a0;
  allocp[14] = a2;
  allocp[15] = x3 = makeref(&allocp[15]);
  allocp[16] = x2;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_hb_xmake__io_3);
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = x5 = makeref(&allocp[20]);
  allocp[21] = x3;
  allocp[22] = (q)(struct goalrec*)&allocp[17];
  allocp[23] = (q)(&predicate_functor__table_xarg_3);
  allocp[24] = a0;
  allocp[25] = a2;
  allocp[26] = x5;
  allocp[27] = (q)(struct goalrec*)&allocp[22];
  allocp[28] = (q)(&predicate_functor__table_xarg_3);
  allocp[29] = a0;
  allocp[30] = a1;
  allocp[31] = x4;
  qp = (struct goalrec*)&allocp[27];
  allocp += 32;
  proceed();
 make__vio_4_2:
  if (a0 != makeint(0L)) goto make__vio_4_interrupt;
  unify(a3, a2);
  proceed();
 make__vio_4_3:
  if (!isref(a0)) goto make__vio_4_interrupt;
  deref_and_jump(a0,make__vio_4_1);
  *reasonp++ =  a0;
  goto make__vio_4_interrupt;
 make__vio_4_ext_interrupt:
  reasonp = 0l;
 make__vio_4_interrupt:
  goto interrupt_4;
 }

 make_6_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 make_6_clear_reason:
  reasonp = reasons;
 make_6_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xvdg2adg_7);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a4;
  allocp[6] = a3;
  allocp[7] = x0 = makeref(&allocp[7]);
  allocp[8] = a5;
  a0 = x0;
  a1 = a4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 9;
  execute(init_2_0);
  goto init_2_ext_interrupt;
 make_6_ext_interrupt:
  reasonp = 0l;
 make_6_interrupt:
  goto interrupt_6;
 }

 init_2_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  qp = qp->next;
 init_2_clear_reason:
  reasonp = reasons;
 init_2_0:
 init_2_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 init_2_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto init_2_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xinit_2);
  allocp[2] = x1 = makeref(&allocp[2]);
  x2 = cdr_of(a1);
  allocp[3] = x2;
  allocp[4] = makesym(functor_module_2);
  x4 = arg(x0, 0);
  allocp[5] = x4;
  allocp[6] = x5 = makeref(&allocp[6]);
  x3 = makefunctor(&allocp[4]);
  allocp[7] = x1;
  allocp[8] = x3;
  x6 = makecons(&allocp[7]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 9;
  unify_value(a0, x6);
  a0 = arg(x0, 1);
  a1 = x5;
  execute(init__pred_2_0);
  goto init__pred_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,init_2_2);
  *reasonp++ =  x0;
  goto init_2_interrupt;
  };
  goto init_2_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto init_2_interrupt;
  x0 = NILATOM;
  unify_value(a0, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,init_2_1);
  *reasonp++ =  a1;
  goto init_2_interrupt;
  };
  goto init_2_interrupt;
 init_2_ext_interrupt:
  reasonp = 0l;
 init_2_interrupt:
  toppred = &predicate_adg_xinit_2;
  goto interrupt_2;
 }

 init__pred_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  qp = qp->next;
 init__pred_2_clear_reason:
  reasonp = reasons;
 init__pred_2_0:
 init__pred_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 init__pred_2_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_7)) goto init__pred_2_6;
  x1 = arg(x0, 3);
 init__pred_2_3:
  if (isref(x1)) goto init__pred_2_5;
  gblt_pfunctor(x1,x2,init__pred_2_6);
  gblt_arity(x1,x3,init__pred_2_6);
 init__pred_2_4:
  if (x3 != makeint(0L)) goto init__pred_2_6;
  allocp[0] = makesym(functor_entry_8);
  x5 = arg(x0, 0);
  allocp[1] = x5;
  x6 = arg(x0, 1);
  allocp[2] = x6;
  allocp[3] = makesym(atom_pred);
  allocp[4] = makesym(atom_pred__r);
  allocp[5] = makesym(atom_heads);
  allocp[6] = makesym(atom_heads__r);
  allocp[7] = makesym(atom_bodys);
  allocp[8] = makesym(atom_bodys__r);
  x4 = makefunctor(&allocp[0]);
  allocp[9] = x8 = makeref(&allocp[9]);
  allocp[10] = x4;
  x7 = makecons(&allocp[9]);
  allocp += 11;
  unify_value(a1, x7);
  a0 = cdr_of(a0);
  a1 = x8;
  execute(init__pred_2_0);
  goto init__pred_2_ext_interrupt;
 init__pred_2_5:
  deref_and_jump(x1,init__pred_2_3);
  *reasonp++ =  x1;
  goto init__pred_2_6;
 case VARREF:
  deref_and_jump(x0,init__pred_2_2);
  *reasonp++ =  x0;
  goto init__pred_2_6;
  };
  goto init__pred_2_6;
 case VARREF:
  deref_and_jump(a0,init__pred_2_1);
  *reasonp++ =  a0;
  goto init__pred_2_6;
  };
  goto init__pred_2_6;
 init__pred_2_6:
  otherwise(init__pred_2_interrupt);
 init__pred_2_7:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 init__pred_2_8:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_7)) goto init__pred_2_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xinit__pred_2);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = makesym(functor_entry_8);
  x4 = arg(x0, 0);
  allocp[5] = x4;
  x5 = arg(x0, 1);
  allocp[6] = x5;
  allocp[7] = makefunctor(funct_const_6);
  allocp[8] = makefunctor(funct_const_7);
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = x7 = makeref(&allocp[10]);
  allocp[11] = x8 = makeref(&allocp[11]);
  allocp[12] = x9 = makeref(&allocp[12]);
  x3 = makefunctor(&allocp[4]);
  allocp[13] = x2;
  allocp[14] = x3;
  x10 = makecons(&allocp[13]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 15;
  unify_value(a1, x10);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xinit__pred__headbody_3);
  x11 = arg(x0, 4);
  allocp[2] = x11;
  allocp[3] = makesym(atom_bodys__r);
  allocp[4] = x9;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_adg_xinit__pred__headbody_3);
  allocp[7] = x11;
  allocp[8] = makesym(atom_bodys);
  allocp[9] = x8;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_adg_xinit__pred__headbody_3);
  x12 = arg(x0, 3);
  allocp[12] = x12;
  allocp[13] = makesym(atom_heads__r);
  allocp[14] = x7;
  a0 = x12;
  a1 = makesym(atom_heads);
  a2 = x6;
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  execute(init__pred__headbody_3_0);
  goto init__pred__headbody_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,init__pred_2_8);
  *reasonp++ =  x0;
  goto init__pred_2_interrupt;
  };
  goto init__pred_2_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto init__pred_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,init__pred_2_7);
  *reasonp++ =  a0;
  goto init__pred_2_interrupt;
  };
  goto init__pred_2_interrupt;
 init__pred_2_ext_interrupt:
  reasonp = 0l;
 init__pred_2_interrupt:
  toppred = &predicate_adg_xinit__pred_2;
  goto interrupt_2;
 }

 init__pred__headbody_3_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  qp = qp->next;
 init__pred__headbody_3_clear_reason:
  reasonp = reasons;
 init__pred__headbody_3_0:
 init__pred__headbody_3_1:
  if (isref(a0)) goto init__pred__headbody_3_4;
  x1 = makeint(1L);
  gblt_arg(x1,a0,x0,init__pred__headbody_3_interrupt);
 init__pred__headbody_3_2:
  if (isref(x0)) goto init__pred__headbody_3_3;
  gblt_pfunctor(x0,x2,init__pred__headbody_3_interrupt);
  gblt_arity(x0,x3,init__pred__headbody_3_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor_xnew__functor__init_4);
  allocp[2] = a1;
  allocp[3] = x3;
  allocp[4] = NILATOM;
  allocp[5] = a2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  proceed();
 init__pred__headbody_3_3:
  deref_and_jump(x0,init__pred__headbody_3_2);
  *reasonp++ =  x0;
  goto init__pred__headbody_3_interrupt;
 init__pred__headbody_3_4:
  deref_and_jump(a0,init__pred__headbody_3_1);
  *reasonp++ =  a0;
  goto init__pred__headbody_3_interrupt;
 init__pred__headbody_3_ext_interrupt:
  reasonp = 0l;
 init__pred__headbody_3_interrupt:
  toppred = &predicate_adg_xinit__pred__headbody_3;
  goto interrupt_3;
 }

 vdg2adg_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 vdg2adg_7_clear_reason:
  reasonp = reasons;
 vdg2adg_7_0:
 vdg2adg_7_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 vdg2adg_7_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_pred_3:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xvdg2adg_7);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = a6;
  a0 = arg(x0, 0);
  x3 = arg(x0, 1);
  x4 = arg(x0, 2);
  x5 = a1;
  x6 = a2;
  x7 = a3;
  a6 = a4;
  a7 = a5;
  a8 = x2;
  a5 = x7;
  a4 = x6;
  a3 = x5;
  a2 = x4;
  a1 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 9;
  execute(make__adg__pred_9_0);
  goto make__adg__pred_9_ext_interrupt;
 case functor_body__r_5:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xvdg2adg_7);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = a6;
  a0 = arg(x0, 0);
  x3 = arg(x0, 1);
  x4 = arg(x0, 2);
  x5 = arg(x0, 3);
  x6 = arg(x0, 4);
  x7 = a1;
  a6 = a2;
  a7 = a3;
  a8 = a4;
  a9 = a5;
  a10 = x2;
  a5 = x7;
  a4 = x6;
  a3 = x5;
  a2 = x4;
  a1 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 9;
  execute(make__adg__body__r_11_0);
  goto make__adg__body__r_11_ext_interrupt;
  };
  goto vdg2adg_7_interrupt;
 case VARREF:
  deref_and_jump(x0,vdg2adg_7_2);
  *reasonp++ =  x0;
  goto vdg2adg_7_interrupt;
  };
  goto vdg2adg_7_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto vdg2adg_7_interrupt;
  unify(a6, a5);
  proceed();
 case VARREF:
  deref_and_jump(a0,vdg2adg_7_1);
  *reasonp++ =  a0;
  goto vdg2adg_7_interrupt;
  };
  goto vdg2adg_7_interrupt;
 vdg2adg_7_ext_interrupt:
  reasonp = 0l;
 vdg2adg_7_interrupt:
  goto interrupt_7;
 }

 make__adg__body__r_11_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 make__adg__body__r_11_clear_reason:
  reasonp = reasons;
 make__adg__body__r_11_0:
 make__adg__body__r_11_1:
  switch (ptagof(a4)) {
 case FUNCTOR:
  if (functor_of(a4) != makesym(functor_goal_4)) goto make__adg__body__r_11_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xmake__adg__entry__body__r_15);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  x2 = arg(a4, 0);
  allocp[4] = x2;
  allocp[5] = a1;
  allocp[6] = a2;
  allocp[7] = a3;
  allocp[8] = a4;
  allocp[9] = a5;
  allocp[10] = x3 = makeref(&allocp[10]);
  allocp[11] = x4 = makeref(&allocp[11]);
  allocp[12] = a6;
  allocp[13] = a7;
  allocp[14] = a8;
  allocp[15] = x5 = makeref(&allocp[15]);
  allocp[16] = a10;
  allocp[17] = makesym(functor_clause_4);
  allocp[18] = x3;
  allocp[19] = x7 = makeref(&allocp[19]);
  allocp[20] = x4;
  allocp[21] = x8 = makeref(&allocp[21]);
  x6 = makefunctor(&allocp[17]);
  allocp[22] = (q)(struct goalrec*)&allocp[0];
  allocp[23] = (q)(&predicate_parse__uty_xget__clause_4);
  allocp[24] = x2;
  x9 = arg(a4, 1);
  allocp[25] = x9;
  allocp[26] = x6;
  allocp[27] = a8;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_adg_xmake__adg__body__r1_10);
  allocp[30] = x0;
  allocp[31] = x1;
  allocp[32] = x2;
  allocp[33] = x9;
  allocp[34] = a6;
  allocp[35] = a7;
  allocp[36] = a8;
  allocp[37] = a5;
  allocp[38] = a9;
  allocp[39] = x5;
  allocp[40] = (q)(struct goalrec*)&allocp[28];
  allocp[41] = (q)(&predicate_parse__uty_xget__goal_6);
  allocp[42] = x2;
  allocp[43] = x9;
  x10 = arg(a4, 3);
  allocp[44] = x10;
  allocp[45] = makesym(atom_body);
  allocp[46] = x11 = makeref(&allocp[46]);
  allocp[47] = a8;
  allocp[48] = makesym(functor_io_2);
  allocp[49] = x0;
  allocp[50] = x1;
  x12 = makefunctor(&allocp[48]);
  allocp[51] = (q)(struct goalrec*)&allocp[40];
  allocp[52] = (q)(&predicate_functor__table_xarg_3);
  allocp[53] = a3;
  allocp[54] = x13 = makeref(&allocp[54]);
  allocp[55] = x12;
  allocp[56] = (q)(struct goalrec*)&allocp[51];
  allocp[57] = (q)(&predicate_hb_xget__bio_5);
  allocp[58] = a7;
  allocp[59] = a0;
  allocp[60] = a1;
  allocp[61] = a2;
  allocp[62] = x13;
  qp = (struct goalrec*)&allocp[56];
  allocp += 63;
  proceed();
 case VARREF:
  deref_and_jump(a4,make__adg__body__r_11_1);
  *reasonp++ =  a4;
  goto make__adg__body__r_11_interrupt;
  };
  goto make__adg__body__r_11_interrupt;
 make__adg__body__r_11_ext_interrupt:
  reasonp = 0l;
 make__adg__body__r_11_interrupt:
  toppred = &predicate_adg_xmake__adg__body__r_11;
  goto interrupt_11;
 }

 make__adg__body__r1_10_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 make__adg__body__r1_10_clear_reason:
  reasonp = reasons;
 make__adg__body__r1_10_0:
 make__adg__body__r1_10_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 make__adg__body__r1_10_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_v_3)) goto make__adg__body__r1_10_3;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xmake__adg__body__r1_10);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = x2 = makeref(&allocp[10]);
  allocp[11] = a9;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_adg_xexpand__userdef_11);
  allocp[14] = x3 = makeref(&allocp[14]);
  allocp[15] = x4 = makeref(&allocp[15]);
  allocp[16] = x5 = makeref(&allocp[16]);
  allocp[17] = x6 = makeref(&allocp[17]);
  allocp[18] = x7 = makeref(&allocp[18]);
  allocp[19] = a4;
  allocp[20] = a5;
  allocp[21] = a6;
  allocp[22] = a7;
  allocp[23] = a8;
  allocp[24] = x2;
  allocp[25] = (q)(struct goalrec*)&allocp[12];
  allocp[26] = (q)(&predicate_list_xor__unique_3);
  x8 = cdr_of(a0);
  allocp[27] = x8;
  allocp[28] = x9 = makeref(&allocp[28]);
  allocp[29] = x1;
  allocp[30] = (q)(struct goalrec*)&allocp[25];
  allocp[31] = (q)(&predicate_typeset_xvars2vs3_4);
  allocp[32] = a2;
  allocp[33] = a3;
  allocp[34] = x10 = makeref(&allocp[34]);
  allocp[35] = x9;
  a0 = a2;
  a1 = a3;
  a2 = arg(x0, 2);
  a3 = a4;
  a4 = a5;
  a5 = a6;
  a6 = x4;
  a7 = x5;
  a8 = x6;
  a9 = x7;
  a10 = x10;
  allocp[36] = x11 = makeref(&allocp[36]);
  a11 = x11;
  allocp[37] = x12 = makeref(&allocp[37]);
  a12 = x12;
  a13 = x3;
  qp = (struct goalrec*)&allocp[30];
  allocp += 38;
  execute(get__ogoal_14_0);
  goto get__ogoal_14_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,make__adg__body__r1_10_2);
  *reasonp++ =  x0;
  goto make__adg__body__r1_10_3;
  };
  goto make__adg__body__r1_10_3;
 case VARREF:
  deref_and_jump(a0,make__adg__body__r1_10_1);
  *reasonp++ =  a0;
  goto make__adg__body__r1_10_3;
  };
  goto make__adg__body__r1_10_3;
 make__adg__body__r1_10_3:
  otherwise(make__adg__body__r1_10_interrupt);
 make__adg__body__r1_10_4:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(make__adg__body__r1_10_0);
  goto make__adg__body__r1_10_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto make__adg__body__r1_10_interrupt;
  unify(a9, a8);
  proceed();
 case VARREF:
  deref_and_jump(a0,make__adg__body__r1_10_4);
  *reasonp++ =  a0;
  goto make__adg__body__r1_10_interrupt;
  };
  goto make__adg__body__r1_10_interrupt;
 make__adg__body__r1_10_ext_interrupt:
  reasonp = 0l;
 make__adg__body__r1_10_interrupt:
  goto interrupt_10;
 }

 expand__userdef_11_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 expand__userdef_11_clear_reason:
  reasonp = reasons;
 expand__userdef_11_0:
 expand__userdef_11_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto expand__userdef_11_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_builtin)):
  unify(a10, a9);
  proceed();
 case symval(makesym(atom_userdef)):
 expand__userdef_11_2:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_goal_4)) goto expand__userdef_11_interrupt;
  x0 = arg(a1, 2);
 expand__userdef_11_3:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (isint(x0)) goto expand__userdef_11_interrupt;
  switch (symval(x0)) {
 case symval(makesym(atom_head)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xmake__adg__head__r_12);
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  allocp[5] = a1;
  allocp[6] = x1 = makeref(&allocp[6]);
  x2 = arg(a1, 1);
  allocp[7] = x2;
  allocp[8] = a8;
  allocp[9] = a5;
  allocp[10] = a6;
  allocp[11] = a7;
  allocp[12] = a9;
  allocp[13] = a10;
  allocp[14] = (q)(struct goalrec*)&allocp[0];
  allocp[15] = (q)(&predicate_parse__uty_xdecode__goalcall_6);
  x3 = arg(a1, 0);
  allocp[16] = x3;
  allocp[17] = x4 = makeref(&allocp[17]);
  allocp[18] = x5 = makeref(&allocp[18]);
  allocp[19] = x1;
  allocp[20] = x6 = makeref(&allocp[20]);
  allocp[21] = x7 = makeref(&allocp[21]);
  allocp[22] = (q)(struct goalrec*)&allocp[14];
  allocp[23] = (q)(&predicate_parse__uty_xget__goal_6);
  allocp[24] = x3;
  allocp[25] = x2;
  x8 = arg(a1, 3);
  allocp[26] = x8;
  allocp[27] = makesym(atom_head);
  allocp[28] = x5;
  allocp[29] = a7;
  qp = (struct goalrec*)&allocp[22];
  allocp += 30;
  proceed();
 case symval(makesym(atom_body)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xmake__adg__body_12);
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  allocp[5] = a1;
  allocp[6] = x1 = makeref(&allocp[6]);
  x2 = arg(a1, 1);
  allocp[7] = x2;
  allocp[8] = a8;
  allocp[9] = a5;
  allocp[10] = a6;
  allocp[11] = a7;
  allocp[12] = a9;
  allocp[13] = a10;
  allocp[14] = (q)(struct goalrec*)&allocp[0];
  allocp[15] = (q)(&predicate_parse__uty_xdecode__goalcall_5);
  x3 = arg(a1, 0);
  allocp[16] = x3;
  allocp[17] = x4 = makeref(&allocp[17]);
  allocp[18] = x5 = makeref(&allocp[18]);
  allocp[19] = x1;
  allocp[20] = x6 = makeref(&allocp[20]);
  allocp[21] = (q)(struct goalrec*)&allocp[14];
  allocp[22] = (q)(&predicate_parse__uty_xget__goal_6);
  allocp[23] = x3;
  allocp[24] = x2;
  x7 = arg(a1, 3);
  allocp[25] = x7;
  allocp[26] = x0;
  allocp[27] = x5;
  allocp[28] = a7;
  qp = (struct goalrec*)&allocp[21];
  allocp += 29;
  proceed();
  };
  goto expand__userdef_11_interrupt;
 case VARREF:
  deref_and_jump(x0,expand__userdef_11_3);
  *reasonp++ =  x0;
  goto expand__userdef_11_interrupt;
  };
  goto expand__userdef_11_interrupt;
 case VARREF:
  deref_and_jump(a1,expand__userdef_11_2);
  *reasonp++ =  a1;
  goto expand__userdef_11_interrupt;
  };
  goto expand__userdef_11_interrupt;
  };
  goto expand__userdef_11_interrupt;
 case VARREF:
  deref_and_jump(a0,expand__userdef_11_1);
  *reasonp++ =  a0;
  goto expand__userdef_11_interrupt;
  };
  goto expand__userdef_11_interrupt;
 expand__userdef_11_ext_interrupt:
  reasonp = 0l;
 expand__userdef_11_interrupt:
  goto interrupt_11;
 }

 make__adg__pred_9_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 make__adg__pred_9_clear_reason:
  reasonp = reasons;
 make__adg__pred_9_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xheads2pred_7);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a5;
  allocp[6] = a6;
  allocp[7] = x0 = makeref(&allocp[7]);
  allocp[8] = a8;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_adg_xmake__adg__heads_12);
  allocp[11] = x1 = makeref(&allocp[11]);
  allocp[12] = x2 = makeref(&allocp[12]);
  allocp[13] = a0;
  allocp[14] = a1;
  allocp[15] = a2;
  allocp[16] = x3 = makeref(&allocp[16]);
  allocp[17] = a3;
  allocp[18] = a4;
  allocp[19] = a5;
  allocp[20] = a6;
  allocp[21] = a7;
  allocp[22] = x0;
  allocp[23] = (q)(struct goalrec*)&allocp[9];
  allocp[24] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[25] = x2;
  allocp[26] = x4 = makeref(&allocp[26]);
  allocp[27] = x1;
  allocp[28] = (q)(struct goalrec*)&allocp[23];
  allocp[29] = (q)(&predicate_hb_xget__gids_6);
  allocp[30] = a5;
  allocp[31] = a0;
  allocp[32] = a1;
  allocp[33] = a2;
  allocp[34] = makesym(atom_head);
  allocp[35] = x3;
  allocp[36] = (q)(struct goalrec*)&allocp[28];
  allocp[37] = (q)(&predicate_hb_xget__hio_5);
  allocp[38] = a5;
  allocp[39] = a0;
  allocp[40] = a1;
  allocp[41] = a2;
  allocp[42] = x2;
  qp = (struct goalrec*)&allocp[36];
  allocp += 43;
  proceed();
 make__adg__pred_9_ext_interrupt:
  reasonp = 0l;
 make__adg__pred_9_interrupt:
  toppred = &predicate_adg_xmake__adg__pred_9;
  goto interrupt_9;
 }

 make__adg__head__r_12_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 make__adg__head__r_12_clear_reason:
  reasonp = reasons;
 make__adg__head__r_12_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xpredr2headr_10);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x0 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a8;
  allocp[9] = a9;
  allocp[10] = x1 = makeref(&allocp[10]);
  allocp[11] = a11;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_hb_xget__pn_7);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = makesym(atom_head);
  allocp[18] = a3;
  allocp[19] = x0;
  allocp[20] = a8;
  a3 = a6;
  a4 = a7;
  a5 = a8;
  a6 = a9;
  a7 = a10;
  a8 = x1;
  qp = (struct goalrec*)&allocp[12];
  allocp += 21;
  execute(make__adg__pred__r_9_0);
  goto make__adg__pred__r_9_ext_interrupt;
 make__adg__head__r_12_ext_interrupt:
  reasonp = 0l;
 make__adg__head__r_12_interrupt:
  goto interrupt_12;
 }

 make__adg__pred__r_9_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 make__adg__pred__r_9_clear_reason:
  reasonp = reasons;
 make__adg__pred__r_9_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xbodysr2predr_7);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a5;
  allocp[6] = a6;
  allocp[7] = x0 = makeref(&allocp[7]);
  allocp[8] = a8;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[11] = x1 = makeref(&allocp[11]);
  allocp[12] = x2 = makeref(&allocp[12]);
  allocp[13] = x3 = makeref(&allocp[13]);
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_adg_xmake__adg__bodys__r_11);
  allocp[16] = x3;
  allocp[17] = a0;
  allocp[18] = a1;
  allocp[19] = a2;
  allocp[20] = x1;
  allocp[21] = a3;
  allocp[22] = a4;
  allocp[23] = a5;
  allocp[24] = a6;
  allocp[25] = a7;
  allocp[26] = x0;
  allocp[27] = (q)(struct goalrec*)&allocp[14];
  allocp[28] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[29] = x1;
  allocp[30] = x4 = makeref(&allocp[30]);
  allocp[31] = x3;
  allocp[32] = (q)(struct goalrec*)&allocp[27];
  allocp[33] = (q)(&predicate_hb_xget__gids_6);
  allocp[34] = a5;
  allocp[35] = a0;
  allocp[36] = a1;
  allocp[37] = a2;
  allocp[38] = makesym(atom_body);
  allocp[39] = x1;
  qp = (struct goalrec*)&allocp[32];
  allocp += 40;
  proceed();
 make__adg__pred__r_9_ext_interrupt:
  reasonp = 0l;
 make__adg__pred__r_9_interrupt:
  toppred = &predicate_adg_xmake__adg__pred__r_9;
  goto interrupt_9;
 }

 make__adg__bodys__r_11_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 make__adg__bodys__r_11_clear_reason:
  reasonp = reasons;
 make__adg__bodys__r_11_0:
 make__adg__bodys__r_11_1:
  if (!isint(a0)) goto make__adg__bodys__r_11_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,make__adg__bodys__r_11_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xmake__adg__bodys__r_11);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = x2 = makeref(&allocp[11]);
  allocp[12] = a10;
  allocp[13] = (q)(struct goalrec*)&allocp[0];
  allocp[14] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[15] = a0;
  allocp[16] = makeint(1L);
  allocp[17] = x1;
  allocp[18] = (q)(struct goalrec*)&allocp[13];
  allocp[19] = (q)(&predicate_adg_xmake__adg__body__r_11);
  allocp[20] = a1;
  allocp[21] = a2;
  allocp[22] = a3;
  allocp[23] = a0;
  allocp[24] = x3 = makeref(&allocp[24]);
  allocp[25] = a5;
  allocp[26] = a6;
  allocp[27] = a7;
  allocp[28] = a8;
  allocp[29] = a9;
  allocp[30] = x2;
  allocp[31] = (q)(struct goalrec*)&allocp[18];
  allocp[32] = (q)(&predicate_functor__table_xarg_3);
  allocp[33] = a0;
  allocp[34] = a4;
  allocp[35] = x3;
  qp = (struct goalrec*)&allocp[31];
  allocp += 36;
  proceed();
 make__adg__bodys__r_11_2:
  if (a0 != makeint(0L)) goto make__adg__bodys__r_11_interrupt;
  unify(a10, a9);
  proceed();
 make__adg__bodys__r_11_3:
  if (!isref(a0)) goto make__adg__bodys__r_11_interrupt;
  deref_and_jump(a0,make__adg__bodys__r_11_1);
  *reasonp++ =  a0;
  goto make__adg__bodys__r_11_interrupt;
 make__adg__bodys__r_11_ext_interrupt:
  reasonp = 0l;
 make__adg__bodys__r_11_interrupt:
  goto interrupt_11;
 }

 make__adg__heads_12_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 make__adg__heads_12_clear_reason:
  reasonp = reasons;
 make__adg__heads_12_0:
 make__adg__heads_12_1:
  if (!isint(a0)) goto make__adg__heads_12_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,make__adg__heads_12_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xmake__adg__heads_12);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  allocp[12] = x2 = makeref(&allocp[12]);
  allocp[13] = a11;
  allocp[14] = (q)(struct goalrec*)&allocp[0];
  allocp[15] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[16] = a0;
  allocp[17] = makeint(1L);
  allocp[18] = x1;
  allocp[19] = (q)(struct goalrec*)&allocp[14];
  allocp[20] = (q)(&predicate_adg_xmake__adg__entry__head_15);
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = x4 = makeref(&allocp[22]);
  allocp[23] = a2;
  allocp[24] = a3;
  allocp[25] = a4;
  allocp[26] = a0;
  allocp[27] = x5 = makeref(&allocp[27]);
  allocp[28] = a6;
  allocp[29] = x6 = makeref(&allocp[29]);
  allocp[30] = x7 = makeref(&allocp[30]);
  allocp[31] = a7;
  allocp[32] = a8;
  allocp[33] = a9;
  allocp[34] = x8 = makeref(&allocp[34]);
  allocp[35] = x2;
  allocp[36] = makesym(functor_clause_4);
  allocp[37] = x6;
  allocp[38] = x10 = makeref(&allocp[38]);
  allocp[39] = x7;
  allocp[40] = x11 = makeref(&allocp[40]);
  x9 = makefunctor(&allocp[36]);
  allocp[41] = (q)(struct goalrec*)&allocp[19];
  allocp[42] = (q)(&predicate_parse__uty_xget__clause_4);
  allocp[43] = a2;
  allocp[44] = x12 = makeref(&allocp[44]);
  allocp[45] = x9;
  allocp[46] = a9;
  allocp[47] = (q)(struct goalrec*)&allocp[41];
  allocp[48] = (q)(&predicate_adg_xmake__bodys__adg_7);
  allocp[49] = x5;
  allocp[50] = a6;
  allocp[51] = a7;
  allocp[52] = a8;
  allocp[53] = a9;
  allocp[54] = a10;
  allocp[55] = x8;
  allocp[56] = makesym(functor_goal_4);
  allocp[57] = x14 = makeref(&allocp[57]);
  allocp[58] = x12;
  allocp[59] = x15 = makeref(&allocp[59]);
  allocp[60] = x16 = makeref(&allocp[60]);
  x13 = makefunctor(&allocp[56]);
  qp = (struct goalrec*)&allocp[47];
  allocp += 61;
  unify_value(x5, x13);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = a0;
  allocp[3] = a5;
  allocp[4] = x5;
  allocp[5] = makesym(functor_io_2);
  allocp[6] = x3;
  allocp[7] = x4;
  x17 = makefunctor(&allocp[5]);
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_functor__table_xarg_3);
  allocp[10] = a0;
  allocp[11] = a1;
  allocp[12] = x17;
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  proceed();
 make__adg__heads_12_2:
  if (a0 != makeint(0L)) goto make__adg__heads_12_interrupt;
  unify(a11, a10);
  proceed();
 make__adg__heads_12_3:
  if (!isref(a0)) goto make__adg__heads_12_interrupt;
  deref_and_jump(a0,make__adg__heads_12_1);
  *reasonp++ =  a0;
  goto make__adg__heads_12_interrupt;
 make__adg__heads_12_ext_interrupt:
  reasonp = 0l;
 make__adg__heads_12_interrupt:
  goto interrupt_12;
 }

 make__bodys__adg_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 make__bodys__adg_7_clear_reason:
  reasonp = reasons;
 make__bodys__adg_7_0:
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  x0 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a0, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xmake__bodys__adg1_10);
  allocp[2] = x5 = makeref(&allocp[2]);
  allocp[3] = x6 = makeref(&allocp[3]);
  allocp[4] = x1;
  allocp[5] = x2;
  allocp[6] = a1;
  allocp[7] = a2;
  allocp[8] = a3;
  allocp[9] = a4;
  allocp[10] = a5;
  allocp[11] = a6;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[14] = x6;
  allocp[15] = x7 = makeref(&allocp[15]);
  allocp[16] = x5;
  allocp[17] = makesym(functor_clause_4);
  allocp[18] = x9 = makeref(&allocp[18]);
  allocp[19] = x10 = makeref(&allocp[19]);
  allocp[20] = x6;
  allocp[21] = x11 = makeref(&allocp[21]);
  x8 = makefunctor(&allocp[17]);
  allocp[22] = (q)(struct goalrec*)&allocp[12];
  allocp[23] = (q)(&predicate_parse__uty_xget__clause_4);
  allocp[24] = x1;
  allocp[25] = x2;
  allocp[26] = x8;
  allocp[27] = a4;
  qp = (struct goalrec*)&allocp[22];
  allocp += 28;
  proceed();
 make__bodys__adg_7_ext_interrupt:
  reasonp = 0l;
 make__bodys__adg_7_interrupt:
  goto interrupt_7;
 }

 make__bodys__adg1_10_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 make__bodys__adg1_10_clear_reason:
  reasonp = reasons;
 make__bodys__adg1_10_0:
 make__bodys__adg1_10_1:
  if (!isint(a0)) goto make__bodys__adg1_10_5;
  x0 = makeint(0L);
  gblt_greater(a0,x0,make__bodys__adg1_10_4);
 make__bodys__adg1_10_2:
  if (isref(a1)) goto make__bodys__adg1_10_3;
  gblt_arg(a0,a1,x1,make__bodys__adg1_10_4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xmake__bodys__adg1_10);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = x3 = makeref(&allocp[10]);
  allocp[11] = a9;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[14] = a0;
  allocp[15] = makeint(1L);
  allocp[16] = x2;
  allocp[17] = makesym(functor_goal_4);
  allocp[18] = a2;
  allocp[19] = a3;
  allocp[20] = makesym(atom_body);
  allocp[21] = a0;
  x4 = makefunctor(&allocp[17]);
  allocp[22] = (q)(struct goalrec*)&allocp[12];
  allocp[23] = (q)(&predicate_adg_xmake__body__adg_14);
  allocp[24] = x5 = makeref(&allocp[24]);
  allocp[25] = x6 = makeref(&allocp[25]);
  allocp[26] = x7 = makeref(&allocp[26]);
  allocp[27] = x8 = makeref(&allocp[27]);
  allocp[28] = x9 = makeref(&allocp[28]);
  allocp[29] = x4;
  allocp[30] = x10 = makeref(&allocp[30]);
  allocp[31] = a3;
  allocp[32] = a4;
  allocp[33] = a5;
  allocp[34] = a6;
  allocp[35] = a7;
  allocp[36] = a8;
  allocp[37] = x3;
  allocp[38] = (q)(struct goalrec*)&allocp[22];
  allocp[39] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[40] = x10;
  allocp[41] = x6;
  allocp[42] = x7;
  allocp[43] = (q)(struct goalrec*)&allocp[38];
  allocp[44] = (q)(&predicate_parse__uty_xdecode__goalcall_6);
  allocp[45] = a2;
  allocp[46] = x5;
  allocp[47] = x1;
  allocp[48] = x10;
  allocp[49] = x9;
  allocp[50] = x8;
  qp = (struct goalrec*)&allocp[43];
  allocp += 51;
  proceed();
 make__bodys__adg1_10_3:
  deref_and_jump(a1,make__bodys__adg1_10_2);
  *reasonp++ =  a1;
  goto make__bodys__adg1_10_4;
 make__bodys__adg1_10_4:
  if (a0 != makeint(0L)) goto make__bodys__adg1_10_interrupt;
  unify(a9, a8);
  proceed();
 make__bodys__adg1_10_5:
  if (!isref(a0)) goto make__bodys__adg1_10_interrupt;
  deref_and_jump(a0,make__bodys__adg1_10_1);
  *reasonp++ =  a0;
  goto make__bodys__adg1_10_interrupt;
 make__bodys__adg1_10_ext_interrupt:
  reasonp = 0l;
 make__bodys__adg1_10_interrupt:
  goto interrupt_10;
 }

 make__body__adg_14_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  qp = qp->next;
 make__body__adg_14_clear_reason:
  reasonp = reasons;
 make__body__adg_14_0:
 make__body__adg_14_1:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (isint(a3)) goto make__body__adg_14_4;
  switch (symval(a3)) {
 case symval(makesym(atom_builtin)):
  unify(a13, a12);
  proceed();
 case symval(makesym(atom_userdef)):
 make__body__adg_14_2:
  switch (ptagof(a4)) {
 case FUNCTOR:
  if (functor_of(a4) != makesym(functor_atom_1)) goto make__body__adg_14_4;
  x0 = arg(a4, 0);
 make__body__adg_14_3:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_recursive)) goto make__body__adg_14_4;
  unify(a13, a12);
  proceed();
 case VARREF:
  deref_and_jump(x0,make__body__adg_14_3);
  *reasonp++ =  x0;
  goto make__body__adg_14_4;
  };
  goto make__body__adg_14_4;
 case VARREF:
  deref_and_jump(a4,make__body__adg_14_2);
  *reasonp++ =  a4;
  goto make__body__adg_14_4;
  };
  goto make__body__adg_14_4;
  };
  goto make__body__adg_14_4;
 case VARREF:
  deref_and_jump(a3,make__body__adg_14_1);
  *reasonp++ =  a3;
  goto make__body__adg_14_4;
  };
  goto make__body__adg_14_4;
 make__body__adg_14_4:
  otherwise(make__body__adg_14_interrupt);
 make__body__adg_14_5:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_userdef)) goto make__body__adg_14_interrupt;
  a3 = a5;
  a4 = a6;
  a5 = a7;
  a6 = a8;
  a7 = a9;
  a8 = a10;
  a9 = a11;
  a10 = a12;
  a11 = a13;
  execute(make__adg__body_12_0);
  goto make__adg__body_12_ext_interrupt;
 case VARREF:
  deref_and_jump(a3,make__body__adg_14_5);
  *reasonp++ =  a3;
  goto make__body__adg_14_interrupt;
  };
  goto make__body__adg_14_interrupt;
 make__body__adg_14_ext_interrupt:
  reasonp = 0l;
 make__body__adg_14_interrupt:
  goto interrupt_14;
 }

 make__adg__body_12_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 make__adg__body_12_clear_reason:
  reasonp = reasons;
 make__adg__body_12_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xpred2body_10);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x0 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a8;
  allocp[9] = a9;
  allocp[10] = x1 = makeref(&allocp[10]);
  allocp[11] = a11;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_hb_xget__pn_7);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = makesym(atom_body);
  allocp[18] = a3;
  allocp[19] = x0;
  allocp[20] = a8;
  a3 = a6;
  a4 = a7;
  a5 = a8;
  a6 = a9;
  a7 = a10;
  a8 = x1;
  qp = (struct goalrec*)&allocp[12];
  allocp += 21;
  execute(make__adg__pred_9_0);
  goto make__adg__pred_9_ext_interrupt;
 make__adg__body_12_ext_interrupt:
  reasonp = 0l;
 make__adg__body_12_interrupt:
  toppred = &predicate_adg_xmake__adg__body_12;
  goto interrupt_12;
 }

 pred2body_10_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 pred2body_10_clear_reason:
  reasonp = reasons;
 pred2body_10_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xentry__ad_8);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = makesym(atom_body);
  allocp[6] = a3;
  allocp[7] = x0 = makeref(&allocp[7]);
  allocp[8] = a8;
  allocp[9] = a9;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_adg_xad__a2v_5);
  allocp[12] = x1 = makeref(&allocp[12]);
  allocp[13] = x0;
  allocp[14] = a0;
  allocp[15] = a5;
  allocp[16] = a4;
  a3 = makesym(atom_pred);
  a4 = makeint(1L);
  a5 = x1;
  a6 = a8;
  qp = (struct goalrec*)&allocp[10];
  allocp += 17;
  execute(get__ad_7_0);
  goto get__ad_7_ext_interrupt;
 pred2body_10_ext_interrupt:
  reasonp = 0l;
 pred2body_10_interrupt:
  goto interrupt_10;
 }

 make__adg__entry__head_15_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  qp = qp->next;
 make__adg__entry__head_15_clear_reason:
  reasonp = reasons;
 make__adg__entry__head_15_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xentry__ad_8);
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  allocp[5] = makesym(atom_head);
  allocp[6] = a5;
  allocp[7] = x0 = makeref(&allocp[7]);
  allocp[8] = a13;
  allocp[9] = a14;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_adg_xcheck__ta__in__ad_11);
  allocp[12] = a6;
  allocp[13] = x1 = makeref(&allocp[13]);
  allocp[14] = x0;
  allocp[15] = a0;
  allocp[16] = a7;
  allocp[17] = a13;
  allocp[18] = a8;
  allocp[19] = a9;
  allocp[20] = a10;
  allocp[21] = a11;
  allocp[22] = a12;
  x2 = a1;
  a1 = a0;
  x3 = a6;
  a6 = a5;
  x4 = a7;
  x5 = a13;
  x6 = a8;
  x7 = a9;
  x8 = a10;
  a13 = a11;
  a14 = a12;
  a12 = x8;
  a11 = x7;
  a10 = x6;
  a9 = x5;
  a8 = x4;
  a7 = x1;
  a5 = x3;
  a0 = x2;
  qp = (struct goalrec*)&allocp[10];
  allocp += 23;
  execute(make__ad_15_0);
  goto make__ad_15_ext_interrupt;
 make__adg__entry__head_15_ext_interrupt:
  reasonp = 0l;
 make__adg__entry__head_15_interrupt:
  goto interrupt_15;
 }

 make__adg__entry__body__r_15_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  qp = qp->next;
 make__adg__entry__body__r_15_clear_reason:
  reasonp = reasons;
 make__adg__entry__body__r_15_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xentry__ad_8);
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  allocp[5] = makesym(atom_body__r);
  allocp[6] = a5;
  allocp[7] = x0 = makeref(&allocp[7]);
  allocp[8] = a13;
  allocp[9] = a14;
  x1 = a6;
  a6 = a5;
  x2 = a7;
  x3 = a13;
  x4 = a8;
  x5 = a9;
  x6 = a10;
  a13 = a11;
  a14 = a12;
  a12 = x6;
  a11 = x5;
  a10 = x4;
  a9 = x3;
  a8 = x2;
  a7 = x0;
  a5 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  execute(make__ad_15_0);
  goto make__ad_15_ext_interrupt;
 make__adg__entry__body__r_15_ext_interrupt:
  reasonp = 0l;
 make__adg__entry__body__r_15_interrupt:
  goto interrupt_15;
 }

 make__ad_15_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  qp = qp->next;
 make__ad_15_clear_reason:
  reasonp = reasons;
 make__ad_15_0:
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  x0 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a5, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xmake__ad0_12);
  allocp[2] = x5 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a5;
  allocp[6] = a7;
  allocp[7] = a8;
  allocp[8] = a9;
  allocp[9] = a10;
  allocp[10] = a11;
  allocp[11] = a12;
  allocp[12] = a13;
  allocp[13] = a14;
  a0 = a2;
  a1 = a3;
  a2 = a4;
  a3 = x3;
  a4 = a6;
  a5 = x5;
  a6 = a9;
  qp = (struct goalrec*)&allocp[0];
  allocp += 14;
  execute(get__ad_7_0);
  goto get__ad_7_ext_interrupt;
 make__ad_15_ext_interrupt:
  reasonp = 0l;
 make__ad_15_interrupt:
  toppred = &predicate_adg_xmake__ad_15;
  goto interrupt_15;
 }

 make__ad0_12_top: {
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 make__ad0_12_clear_reason:
  reasonp = reasons;
 make__ad0_12_0:
 make__ad0_12_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != NILATOM) goto make__ad0_12_2;
  a0 = a1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  a5 = a6;
  a6 = a7;
  a7 = a8;
  a8 = a9;
  a9 = a10;
  a10 = a11;
  execute(make__ad1_11_0);
  goto make__ad1_11_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,make__ad0_12_1);
  *reasonp++ =  a0;
  goto make__ad0_12_2;
  };
  goto make__ad0_12_2;
 make__ad0_12_2:
  otherwise(make__ad0_12_interrupt);
  unify(a4, a0);
  proceed();
 make__ad0_12_ext_interrupt:
  reasonp = 0l;
 make__ad0_12_interrupt:
  goto interrupt_12;
 }

 make__ad1_11_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 make__ad1_11_clear_reason:
  reasonp = reasons;
 make__ad1_11_0:
 make__ad1_11_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 make__ad1_11_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_v_3)) goto make__ad1_11_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xmake__ad1_11);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  allocp[12] = a10;
  allocp[13] = makesym(functor_v_3);
  x4 = arg(x0, 0);
  allocp[14] = x4;
  x5 = arg(x0, 1);
  allocp[15] = x5;
  x6 = arg(x0, 2);
  allocp[16] = x6;
  x3 = makefunctor(&allocp[13]);
  allocp[17] = makesym(functor_vd_2);
  allocp[18] = x3;
  allocp[19] = x8 = makeref(&allocp[19]);
  x7 = makefunctor(&allocp[17]);
  allocp[20] = x2;
  allocp[21] = x7;
  x9 = makecons(&allocp[20]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 22;
  unify_value(a3, x9);
  allocp[0] = makesym(functor_v_3);
  x11 = arg(x0, 0);
  allocp[1] = x11;
  x12 = arg(x0, 1);
  allocp[2] = x12;
  x13 = arg(x0, 2);
  allocp[3] = x13;
  x10 = makefunctor(&allocp[0]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_adg_xexpand__vd_11);
  allocp[6] = x10;
  allocp[7] = x14 = makeref(&allocp[7]);
  allocp[8] = x8;
  allocp[9] = a1;
  allocp[10] = a4;
  allocp[11] = a5;
  allocp[12] = a6;
  allocp[13] = a7;
  allocp[14] = a8;
  allocp[15] = a9;
  allocp[16] = a10;
  allocp[17] = (q)(struct goalrec*)&allocp[4];
  allocp[18] = (q)(&predicate_vdg_xread__vd_5);
  x15 = arg(x0, 0);
  allocp[19] = x15;
  x16 = arg(x0, 1);
  allocp[20] = x16;
  x17 = arg(x0, 2);
  allocp[21] = x17;
  allocp[22] = x14;
  allocp[23] = a4;
  qp = (struct goalrec*)&allocp[17];
  allocp += 24;
  proceed();
 case VARREF:
  deref_and_jump(x0,make__ad1_11_2);
  *reasonp++ =  x0;
  goto make__ad1_11_interrupt;
  };
  goto make__ad1_11_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto make__ad1_11_interrupt;
  x0 = NILATOM;
  unify_value(a3, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,make__ad1_11_1);
  *reasonp++ =  a0;
  goto make__ad1_11_interrupt;
  };
  goto make__ad1_11_interrupt;
 make__ad1_11_ext_interrupt:
  reasonp = 0l;
 make__ad1_11_interrupt:
  toppred = &predicate_adg_xmake__ad1_11;
  goto interrupt_11;
 }

 expand__vd_11_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 expand__vd_11_clear_reason:
  reasonp = reasons;
 expand__vd_11_0:
 expand__vd_11_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != NILATOM) goto expand__vd_11_2;
  allocp[0] = makesym(functor_v_3);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a0, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xexpand__vd1_10);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = a2;
  allocp[4] = a3;
  allocp[5] = a4;
  allocp[6] = a5;
  allocp[7] = a6;
  allocp[8] = a7;
  allocp[9] = a8;
  allocp[10] = a9;
  allocp[11] = a10;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_adg_xexpand__vd__direct_3);
  allocp[14] = x5 = makeref(&allocp[14]);
  allocp[15] = a0;
  allocp[16] = x4;
  allocp[17] = (q)(struct goalrec*)&allocp[12];
  allocp[18] = (q)(&predicate_typeset_xget_5);
  allocp[19] = x1;
  allocp[20] = x2;
  allocp[21] = x3;
  allocp[22] = x5;
  allocp[23] = a8;
  qp = (struct goalrec*)&allocp[17];
  allocp += 24;
  proceed();
 case VARREF:
  deref_and_jump(a1,expand__vd_11_1);
  *reasonp++ =  a1;
  goto expand__vd_11_2;
  };
  goto expand__vd_11_2;
 expand__vd_11_2:
  otherwise(expand__vd_11_interrupt);
 expand__vd_11_3:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != NILATOM) goto expand__vd_11_5;
 expand__vd_11_4:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_ad_5)) goto expand__vd_11_5;
  x0 = makesym(atom_error);
  x1 = makesym(atom_expand__vd);
  unify(x0, x1);
  proceed();
 case VARREF:
  deref_and_jump(a0,expand__vd_11_4);
  *reasonp++ =  a0;
  goto expand__vd_11_5;
  };
  goto expand__vd_11_5;
 case VARREF:
  deref_and_jump(a1,expand__vd_11_3);
  *reasonp++ =  a1;
  goto expand__vd_11_5;
  };
  goto expand__vd_11_5;
 expand__vd_11_5:
  otherwise(expand__vd_11_interrupt);
  a0 = a1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  a5 = a6;
  a6 = a7;
  a7 = a8;
  a8 = a9;
  a9 = a10;
  execute(expand__vd1_10_0);
  goto expand__vd1_10_ext_interrupt;
 expand__vd_11_ext_interrupt:
  reasonp = 0l;
 expand__vd_11_interrupt:
  goto interrupt_11;
 }

 expand__vd1_10_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 expand__vd1_10_clear_reason:
  reasonp = reasons;
 expand__vd1_10_0:
 expand__vd1_10_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 expand__vd1_10_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_to_2)) goto expand__vd1_10_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xexpand__vd1_10);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  allocp[12] = makesym(functor_to_2);
  x4 = arg(x0, 0);
  allocp[13] = x4;
  allocp[14] = x5 = makeref(&allocp[14]);
  x3 = makefunctor(&allocp[12]);
  allocp[15] = x2;
  allocp[16] = x3;
  x6 = makecons(&allocp[15]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 17;
  unify_value(a1, x6);
  a0 = arg(x0, 1);
  a1 = x5;
  execute(expand__b_10_0);
  goto expand__b_10_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,expand__vd1_10_2);
  *reasonp++ =  x0;
  goto expand__vd1_10_interrupt;
  };
  goto expand__vd1_10_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto expand__vd1_10_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,expand__vd1_10_1);
  *reasonp++ =  a0;
  goto expand__vd1_10_interrupt;
  };
  goto expand__vd1_10_interrupt;
 expand__vd1_10_ext_interrupt:
  reasonp = 0l;
 expand__vd1_10_interrupt:
  toppred = &predicate_adg_xexpand__vd1_10;
  goto interrupt_10;
 }

 expand__vd__direct_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  qp = qp->next;
 expand__vd__direct_3_clear_reason:
  reasonp = reasons;
 expand__vd__direct_3_0:
 expand__vd__direct_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 expand__vd__direct_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_t_2:
  allocp[0] = makesym(functor_ti_2);
  allocp[1] = a1;
  x2 = arg(x0, 0);
  allocp[2] = x2;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = NILATOM;
  allocp[4] = x1;
  x3 = makecons(&allocp[3]);
  allocp[5] = makesym(functor_to_2);
  x5 = arg(x0, 0);
  allocp[6] = x5;
  allocp[7] = x3;
  x4 = makefunctor(&allocp[5]);
  allocp[8] = x7 = makeref(&allocp[8]);
  allocp[9] = x4;
  x6 = makecons(&allocp[8]);
  allocp += 10;
  unify_value(a2, x6);
  a0 = cdr_of(a0);
  a2 = x7;
  execute(expand__vd__direct_3_0);
  goto expand__vd__direct_3_ext_interrupt;
 case functor_te_4:
  a0 = cdr_of(a0);
  execute(expand__vd__direct_3_0);
  goto expand__vd__direct_3_ext_interrupt;
  };
  goto expand__vd__direct_3_interrupt;
 case VARREF:
  deref_and_jump(x0,expand__vd__direct_3_2);
  *reasonp++ =  x0;
  goto expand__vd__direct_3_interrupt;
  };
  goto expand__vd__direct_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto expand__vd__direct_3_interrupt;
  x0 = NILATOM;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,expand__vd__direct_3_1);
  *reasonp++ =  a0;
  goto expand__vd__direct_3_interrupt;
  };
  goto expand__vd__direct_3_interrupt;
 expand__vd__direct_3_ext_interrupt:
  reasonp = 0l;
 expand__vd__direct_3_interrupt:
  goto interrupt_3;
 }

 expand__b_10_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 expand__b_10_clear_reason:
  reasonp = reasons;
 expand__b_10_0:
 expand__b_10_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 expand__b_10_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_ti_2:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xexpand__b1_13);
  allocp[2] = x1 = makeref(&allocp[2]);
  x2 = arg(x0, 0);
  allocp[3] = x2;
  x3 = arg(x0, 1);
  allocp[4] = x3;
  x4 = cdr_of(a0);
  allocp[5] = x4;
  allocp[6] = a1;
  allocp[7] = a2;
  allocp[8] = a3;
  allocp[9] = a4;
  allocp[10] = a5;
  allocp[11] = a6;
  allocp[12] = a7;
  allocp[13] = a8;
  allocp[14] = a9;
  allocp[15] = (q)(struct goalrec*)&allocp[0];
  allocp[16] = (q)(&predicate_list_xcheck__include_3);
  allocp[17] = x2;
  allocp[18] = a2;
  allocp[19] = x1;
  qp = (struct goalrec*)&allocp[15];
  allocp += 20;
  proceed();
 case functor_ta_2:
  allocp[0] = makesym(functor_ta_2);
  x2 = arg(x0, 0);
  allocp[1] = x2;
  x3 = arg(x0, 1);
  allocp[2] = x3;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = x1;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a1, x4);
  a0 = cdr_of(a0);
  a1 = x5;
  execute(expand__b_10_0);
  goto expand__b_10_ext_interrupt;
  };
  goto expand__b_10_interrupt;
 case VARREF:
  deref_and_jump(x0,expand__b_10_2);
  *reasonp++ =  x0;
  goto expand__b_10_interrupt;
  };
  goto expand__b_10_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto expand__b_10_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,expand__b_10_1);
  *reasonp++ =  a0;
  goto expand__b_10_interrupt;
  };
  goto expand__b_10_interrupt;
 expand__b_10_ext_interrupt:
  reasonp = 0l;
 expand__b_10_interrupt:
  toppred = &predicate_adg_xexpand__b_10;
  goto interrupt_10;
 }

 expand__b1_13_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  qp = qp->next;
 expand__b1_13_clear_reason:
  reasonp = reasons;
 expand__b1_13_0:
 expand__b1_13_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto expand__b1_13_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  allocp[0] = makesym(functor_ti_2);
  allocp[1] = a1;
  allocp[2] = a2;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = x0;
  x1 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a4, x1);
  a0 = a3;
  a1 = x2;
  a2 = a5;
  a3 = a6;
  a4 = a7;
  a5 = a8;
  a6 = a9;
  a7 = a10;
  a8 = a11;
  a9 = a12;
  execute(expand__b_10_0);
  goto expand__b_10_ext_interrupt;
 case symval(makesym(atom_no)):
 expand__b1_13_2:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_v_3)) goto expand__b1_13_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xexpand__b_10);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a4;
  allocp[4] = a5;
  allocp[5] = a6;
  allocp[6] = a7;
  allocp[7] = a8;
  allocp[8] = a9;
  allocp[9] = a10;
  allocp[10] = a11;
  allocp[11] = a12;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_adg_xreplace__ti_12);
  allocp[14] = x1 = makeref(&allocp[14]);
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a3;
  allocp[18] = x0;
  allocp[19] = a6;
  allocp[20] = a7;
  allocp[21] = a8;
  allocp[22] = a9;
  allocp[23] = a10;
  allocp[24] = a11;
  allocp[25] = a12;
  allocp[26] = (q)(struct goalrec*)&allocp[12];
  allocp[27] = (q)(&predicate_vdg_xread__vd_5);
  x2 = arg(a1, 0);
  allocp[28] = x2;
  x3 = arg(a1, 1);
  allocp[29] = x3;
  x4 = arg(a1, 2);
  allocp[30] = x4;
  allocp[31] = x1;
  allocp[32] = a6;
  qp = (struct goalrec*)&allocp[26];
  allocp += 33;
  proceed();
 case VARREF:
  deref_and_jump(a1,expand__b1_13_2);
  *reasonp++ =  a1;
  goto expand__b1_13_interrupt;
  };
  goto expand__b1_13_interrupt;
  };
  goto expand__b1_13_interrupt;
 case VARREF:
  deref_and_jump(a0,expand__b1_13_1);
  *reasonp++ =  a0;
  goto expand__b1_13_interrupt;
  };
  goto expand__b1_13_interrupt;
 expand__b1_13_ext_interrupt:
  reasonp = 0l;
 expand__b1_13_interrupt:
  goto interrupt_13;
 }

 replace__ti_12_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 replace__ti_12_clear_reason:
  reasonp = reasons;
 replace__ti_12_0:
 replace__ti_12_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != NILATOM) goto replace__ti_12_2;
  allocp[0] = makesym(functor_v_3);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xreplace__ti__userdefs_12);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = a8;
  allocp[4] = makesym(atom_body);
  allocp[5] = a1;
  allocp[6] = a2;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a9;
  allocp[10] = a10;
  allocp[11] = a11;
  allocp[12] = x5 = makeref(&allocp[12]);
  allocp[13] = a4;
  allocp[14] = (q)(struct goalrec*)&allocp[0];
  allocp[15] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[16] = a8;
  allocp[17] = x6 = makeref(&allocp[17]);
  allocp[18] = x4;
  a0 = makeint(1L);
  x7 = a7;
  a4 = a1;
  x8 = a2;
  x9 = a5;
  a7 = a6;
  a8 = a9;
  a9 = a10;
  a10 = a11;
  a11 = a3;
  a12 = x5;
  a6 = x9;
  a5 = x8;
  a3 = makesym(atom_head);
  a2 = x7;
  a1 = x1;
  qp = (struct goalrec*)&allocp[14];
  allocp += 19;
  execute(replace__ti__userdef_13_0);
  goto replace__ti__userdef_13_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,replace__ti_12_1);
  *reasonp++ =  a0;
  goto replace__ti_12_2;
  };
  goto replace__ti_12_2;
 replace__ti_12_2:
  otherwise(replace__ti_12_interrupt);
  execute(replace__ti1_6_0);
  goto replace__ti1_6_ext_interrupt;
 replace__ti_12_ext_interrupt:
  reasonp = 0l;
 replace__ti_12_interrupt:
  goto interrupt_12;
 }

 replace__ti1_6_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 replace__ti1_6_clear_reason:
  reasonp = reasons;
 replace__ti1_6_0:
 replace__ti1_6_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 replace__ti1_6_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_to_2)) goto replace__ti1_6_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xreplace__ti2_9);
  allocp[2] = x1 = makeref(&allocp[2]);
  x2 = cdr_of(a0);
  allocp[3] = x2;
  x3 = arg(x0, 0);
  allocp[4] = x3;
  x4 = arg(x0, 1);
  allocp[5] = x4;
  allocp[6] = a1;
  allocp[7] = a2;
  allocp[8] = a3;
  allocp[9] = a4;
  allocp[10] = a5;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_typeset_xcheck__same__type_4);
  allocp[13] = x3;
  allocp[14] = a2;
  allocp[15] = x5 = makeref(&allocp[15]);
  allocp[16] = x1;
  qp = (struct goalrec*)&allocp[11];
  allocp += 17;
  proceed();
 case VARREF:
  deref_and_jump(x0,replace__ti1_6_2);
  *reasonp++ =  x0;
  goto replace__ti1_6_interrupt;
  };
  goto replace__ti1_6_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto replace__ti1_6_interrupt;
  unify(a4, a3);
  proceed();
 case VARREF:
  deref_and_jump(a0,replace__ti1_6_1);
  *reasonp++ =  a0;
  goto replace__ti1_6_interrupt;
  };
  goto replace__ti1_6_interrupt;
 replace__ti1_6_ext_interrupt:
  reasonp = 0l;
 replace__ti1_6_interrupt:
  toppred = &predicate_adg_xreplace__ti1_6;
  goto interrupt_6;
 }

 replace__ti2_9_top: {
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 replace__ti2_9_clear_reason:
  reasonp = reasons;
 replace__ti2_9_0:
 replace__ti2_9_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto replace__ti2_9_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_list_xappend_3);
  allocp[2] = a6;
  allocp[3] = a3;
  allocp[4] = a7;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case symval(makesym(atom_no)):
  a0 = a1;
  a1 = a4;
  a2 = a5;
  a3 = a6;
  a4 = a7;
  a5 = a8;
  execute(replace__ti1_6_0);
  goto replace__ti1_6_ext_interrupt;
  };
  goto replace__ti2_9_interrupt;
 case VARREF:
  deref_and_jump(a0,replace__ti2_9_1);
  *reasonp++ =  a0;
  goto replace__ti2_9_interrupt;
  };
  goto replace__ti2_9_interrupt;
 replace__ti2_9_ext_interrupt:
  reasonp = 0l;
 replace__ti2_9_interrupt:
  goto interrupt_9;
 }

 replace__ti__userdefs_12_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 replace__ti__userdefs_12_clear_reason:
  reasonp = reasons;
 replace__ti__userdefs_12_0:
 replace__ti__userdefs_12_1:
  if (!isint(a0)) goto replace__ti__userdefs_12_4;
  x0 = makeint(0L);
  gblt_greater(a0,x0,replace__ti__userdefs_12_3);
 replace__ti__userdefs_12_2:
  switch (ptagof(a3)) {
 case FUNCTOR:
  if (functor_of(a3) != makesym(functor_v_3)) goto replace__ti__userdefs_12_3;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xreplace__ti__userdefs_12);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  allocp[12] = x2 = makeref(&allocp[12]);
  allocp[13] = a11;
  allocp[14] = (q)(struct goalrec*)&allocp[0];
  allocp[15] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[16] = a0;
  allocp[17] = makeint(1L);
  allocp[18] = x1;
  allocp[19] = (q)(struct goalrec*)&allocp[14];
  allocp[20] = (q)(&predicate_adg_xreplace__ti__userdef_13);
  allocp[21] = a0;
  x3 = arg(a3, 0);
  allocp[22] = x3;
  allocp[23] = x4 = makeref(&allocp[23]);
  allocp[24] = a2;
  allocp[25] = a3;
  allocp[26] = a4;
  allocp[27] = a5;
  allocp[28] = a6;
  allocp[29] = a7;
  allocp[30] = a8;
  allocp[31] = a9;
  allocp[32] = a10;
  allocp[33] = x2;
  allocp[34] = (q)(struct goalrec*)&allocp[19];
  allocp[35] = (q)(&predicate_functor__table_xarg_3);
  allocp[36] = a0;
  allocp[37] = a1;
  allocp[38] = x4;
  qp = (struct goalrec*)&allocp[34];
  allocp += 39;
  proceed();
 case VARREF:
  deref_and_jump(a3,replace__ti__userdefs_12_2);
  *reasonp++ =  a3;
  goto replace__ti__userdefs_12_3;
  };
  goto replace__ti__userdefs_12_3;
 replace__ti__userdefs_12_3:
  if (a0 != makeint(0L)) goto replace__ti__userdefs_12_interrupt;
  unify(a11, a10);
  proceed();
 replace__ti__userdefs_12_4:
  if (!isref(a0)) goto replace__ti__userdefs_12_interrupt;
  deref_and_jump(a0,replace__ti__userdefs_12_1);
  *reasonp++ =  a0;
  goto replace__ti__userdefs_12_interrupt;
 replace__ti__userdefs_12_ext_interrupt:
  reasonp = 0l;
 replace__ti__userdefs_12_interrupt:
  goto interrupt_12;
 }

 replace__ti__userdef_13_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  qp = qp->next;
 replace__ti__userdef_13_clear_reason:
  reasonp = reasons;
 replace__ti__userdef_13_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xreplace__ti__userdef__arg_17);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a3;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a1;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = a0;
  allocp[9] = x4 = makeref(&allocp[9]);
  allocp[10] = a5;
  allocp[11] = x5 = makeref(&allocp[11]);
  allocp[12] = a6;
  allocp[13] = a7;
  allocp[14] = a8;
  allocp[15] = a9;
  allocp[16] = a10;
  allocp[17] = a11;
  allocp[18] = a12;
  allocp[19] = makesym(functor_v_3);
  allocp[20] = x7 = makeref(&allocp[20]);
  allocp[21] = x3;
  allocp[22] = x4;
  x6 = makefunctor(&allocp[19]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 23;
  unify_value(a4, x6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[2] = x1;
  allocp[3] = x8 = makeref(&allocp[3]);
  allocp[4] = x0;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_parse__uty_xdecode__goalcall_6);
  allocp[7] = a1;
  allocp[8] = x2;
  allocp[9] = a2;
  allocp[10] = x1;
  allocp[11] = x5;
  allocp[12] = x9 = makeref(&allocp[12]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 13;
  proceed();
 replace__ti__userdef_13_ext_interrupt:
  reasonp = 0l;
 replace__ti__userdef_13_interrupt:
  toppred = &predicate_adg_xreplace__ti__userdef_13;
  goto interrupt_13;
 }

 replace__ti__userdef__arg_17_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  qp = qp->next;
 replace__ti__userdef__arg_17_clear_reason:
  reasonp = reasons;
 replace__ti__userdef__arg_17_0:
 replace__ti__userdef__arg_17_1:
  if (!isint(a0)) goto replace__ti__userdef__arg_17_9;
  x0 = makeint(0L);
  gblt_greater(a0,x0,replace__ti__userdef__arg_17_10);
 replace__ti__userdef__arg_17_2:
  if (isref(a2)) goto replace__ti__userdef__arg_17_8;
  gblt_arg(a0,a2,x1,replace__ti__userdef__arg_17_10);
 replace__ti__userdef__arg_17_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_variable_3)) goto replace__ti__userdef__arg_17_10;
  x2 = arg(x1, 0);
 replace__ti__userdef__arg_17_4:
  if (isref(x2)) goto replace__ti__userdef__arg_17_7;
 replace__ti__userdef__arg_17_5:
  if (isref(x2)) goto replace__ti__userdef__arg_17_6;
  if_not_equal(x2, a7, replace__ti__userdef__arg_17_10);
  gblt_pfunctor(a2,x3,replace__ti__userdef__arg_17_10);
  gblt_arity(a2,x4,replace__ti__userdef__arg_17_10);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xreplace__ti__userdef__arg1_18);
  allocp[2] = x5 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a0;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = a8;
  allocp[12] = a9;
  allocp[13] = a10;
  allocp[14] = a11;
  allocp[15] = a12;
  allocp[16] = a13;
  allocp[17] = a14;
  allocp[18] = a15;
  allocp[19] = a16;
  allocp[20] = (q)(struct goalrec*)&allocp[0];
  allocp[21] = (q)(&predicate_hb_xread__mode_6);
  allocp[22] = a4;
  allocp[23] = x3;
  allocp[24] = x4;
  allocp[25] = a0;
  allocp[26] = x5;
  allocp[27] = a13;
  qp = (struct goalrec*)&allocp[20];
  allocp += 28;
  proceed();
 replace__ti__userdef__arg_17_6:
  deref_and_jump(x2,replace__ti__userdef__arg_17_5);
  *reasonp++ =  x2;
  goto replace__ti__userdef__arg_17_10;
 replace__ti__userdef__arg_17_7:
  deref_and_jump(x2,replace__ti__userdef__arg_17_4);
  *reasonp++ =  x2;
  goto replace__ti__userdef__arg_17_10;
 case VARREF:
  deref_and_jump(x1,replace__ti__userdef__arg_17_3);
  *reasonp++ =  x1;
  goto replace__ti__userdef__arg_17_10;
  };
  goto replace__ti__userdef__arg_17_10;
 replace__ti__userdef__arg_17_8:
  deref_and_jump(a2,replace__ti__userdef__arg_17_2);
  *reasonp++ =  a2;
  goto replace__ti__userdef__arg_17_10;
 replace__ti__userdef__arg_17_9:
  if (!isref(a0)) goto replace__ti__userdef__arg_17_10;
  deref_and_jump(a0,replace__ti__userdef__arg_17_1);
  *reasonp++ =  a0;
  goto replace__ti__userdef__arg_17_10;
 replace__ti__userdef__arg_17_10:
  otherwise(replace__ti__userdef__arg_17_interrupt);
 replace__ti__userdef__arg_17_11:
  if (!isint(a0)) goto replace__ti__userdef__arg_17_13;
  x0 = makeint(0L);
  gblt_greater(a0,x0,replace__ti__userdef__arg_17_12);
  x1 = makeint(1L);
  bblt_sub_no_check(a0,x1,x2);
  a0 = x2;
  execute(replace__ti__userdef__arg_17_0);
  goto replace__ti__userdef__arg_17_ext_interrupt;
 replace__ti__userdef__arg_17_12:
  if (a0 != makeint(0L)) goto replace__ti__userdef__arg_17_interrupt;
  unify(a16, a15);
  proceed();
 replace__ti__userdef__arg_17_13:
  if (!isref(a0)) goto replace__ti__userdef__arg_17_interrupt;
  deref_and_jump(a0,replace__ti__userdef__arg_17_11);
  *reasonp++ =  a0;
  goto replace__ti__userdef__arg_17_interrupt;
 replace__ti__userdef__arg_17_ext_interrupt:
  reasonp = 0l;
 replace__ti__userdef__arg_17_interrupt:
  toppred = &predicate_adg_xreplace__ti__userdef__arg_17;
  goto interrupt_17;
 }

 replace__ti__userdef__arg1_18_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  qp = qp->next;
 replace__ti__userdef__arg1_18_clear_reason:
  reasonp = reasons;
 replace__ti__userdef__arg1_18_0:
 replace__ti__userdef__arg1_18_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto replace__ti__userdef__arg1_18_4;
  switch (symval(a0)) {
 case symval(makesym(atom_o)):
 replace__ti__userdef__arg1_18_2:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_body)) goto replace__ti__userdef__arg1_18_4;
  allocp[0] = makesym(functor_v_3);
  allocp[1] = a4;
  allocp[2] = a6;
  allocp[3] = a8;
  x0 = makefunctor(&allocp[0]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_adg_xreplace__ti__adg_11);
  allocp[6] = a10;
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = x3 = makeref(&allocp[9]);
  allocp[10] = a2;
  allocp[11] = x4 = makeref(&allocp[11]);
  allocp[12] = x0;
  allocp[13] = a9;
  allocp[14] = a15;
  allocp[15] = a16;
  allocp[16] = a17;
  allocp[17] = (q)(struct goalrec*)&allocp[4];
  allocp[18] = (q)(&predicate_adg_xget__ad_7);
  allocp[19] = a4;
  allocp[20] = x2;
  allocp[21] = x3;
  allocp[22] = makesym(atom_body);
  allocp[23] = x5 = makeref(&allocp[23]);
  allocp[24] = x4;
  allocp[25] = a12;
  allocp[26] = (q)(struct goalrec*)&allocp[17];
  allocp[27] = (q)(&predicate_hb_xget__pn_7);
  allocp[28] = a4;
  allocp[29] = x2;
  allocp[30] = x3;
  allocp[31] = makesym(atom_body);
  allocp[32] = x1;
  allocp[33] = x5;
  allocp[34] = a14;
  allocp[35] = makesym(functor_goal_4);
  allocp[36] = a4;
  allocp[37] = a6;
  allocp[38] = makesym(atom_body);
  allocp[39] = a7;
  x6 = makefunctor(&allocp[35]);
  qp = (struct goalrec*)&allocp[26];
  allocp += 40;
  unify_value(x1, x6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[2] = a3;
  allocp[3] = x2;
  allocp[4] = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case VARREF:
  deref_and_jump(a1,replace__ti__userdef__arg1_18_2);
  *reasonp++ =  a1;
  goto replace__ti__userdef__arg1_18_4;
  };
  goto replace__ti__userdef__arg1_18_4;
 case symval(makesym(atom_i)):
 replace__ti__userdef__arg1_18_3:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_head)) goto replace__ti__userdef__arg1_18_4;
  allocp[0] = makesym(functor_v_3);
  allocp[1] = a4;
  allocp[2] = a6;
  allocp[3] = a8;
  x0 = makefunctor(&allocp[0]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_adg_xreplace__ti__adg_11);
  allocp[6] = a10;
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = x3 = makeref(&allocp[9]);
  allocp[10] = a2;
  allocp[11] = x4 = makeref(&allocp[11]);
  allocp[12] = x0;
  allocp[13] = a9;
  allocp[14] = a15;
  allocp[15] = a16;
  allocp[16] = a17;
  allocp[17] = (q)(struct goalrec*)&allocp[4];
  allocp[18] = (q)(&predicate_adg_xget__ad_7);
  allocp[19] = a4;
  allocp[20] = x2;
  allocp[21] = x3;
  allocp[22] = makesym(atom_head__r);
  allocp[23] = x5 = makeref(&allocp[23]);
  allocp[24] = x4;
  allocp[25] = a12;
  allocp[26] = (q)(struct goalrec*)&allocp[17];
  allocp[27] = (q)(&predicate_hb_xget__pn_7);
  allocp[28] = a4;
  allocp[29] = x2;
  allocp[30] = x3;
  allocp[31] = makesym(atom_head);
  allocp[32] = x1;
  allocp[33] = x5;
  allocp[34] = a14;
  allocp[35] = makesym(functor_goal_4);
  allocp[36] = a4;
  allocp[37] = a6;
  allocp[38] = makesym(atom_head);
  allocp[39] = a7;
  x6 = makefunctor(&allocp[35]);
  qp = (struct goalrec*)&allocp[26];
  allocp += 40;
  unify_value(x1, x6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[2] = a3;
  allocp[3] = x2;
  allocp[4] = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case VARREF:
  deref_and_jump(a1,replace__ti__userdef__arg1_18_3);
  *reasonp++ =  a1;
  goto replace__ti__userdef__arg1_18_4;
  };
  goto replace__ti__userdef__arg1_18_4;
  };
  goto replace__ti__userdef__arg1_18_4;
 case VARREF:
  deref_and_jump(a0,replace__ti__userdef__arg1_18_1);
  *reasonp++ =  a0;
  goto replace__ti__userdef__arg1_18_4;
  };
  goto replace__ti__userdef__arg1_18_4;
 replace__ti__userdef__arg1_18_4:
  otherwise(replace__ti__userdef__arg1_18_interrupt);
  x0 = makeint(1L);
  bblt_sub_no_check_y(a2,x0,x1);
  a0 = x1;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  a5 = a6;
  a6 = a7;
  a7 = a8;
  a8 = a9;
  a9 = a10;
  a10 = a11;
  a11 = a12;
  a12 = a13;
  a13 = a14;
  a14 = a15;
  a15 = a16;
  a16 = a17;
  execute(replace__ti__userdef__arg_17_0);
  goto replace__ti__userdef__arg_17_ext_interrupt;
 replace__ti__userdef__arg1_18_ext_interrupt:
  reasonp = 0l;
 replace__ti__userdef__arg1_18_interrupt:
  goto interrupt_18;
 }

 replace__ti__adg_11_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 replace__ti__adg_11_clear_reason:
  reasonp = reasons;
 replace__ti__adg_11_0:
 replace__ti__adg_11_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_atom_1)) goto replace__ti__adg_11_3;
  x0 = arg(a0, 0);
 replace__ti__adg_11_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_recursive)) goto replace__ti__adg_11_3;
  allocp[0] = makesym(functor_v_3);
  allocp[1] = x2 = makeref(&allocp[1]);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = x4 = makeref(&allocp[3]);
  x1 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a6, x1);
  allocp[0] = makesym(functor_ad_5);
  allocp[1] = a1;
  allocp[2] = x2;
  allocp[3] = a2;
  allocp[4] = a3;
  allocp[5] = a4;
  x5 = makefunctor(&allocp[0]);
  allocp[6] = makesym(functor_ta_2);
  allocp[7] = x5;
  allocp[8] = a7;
  x6 = makefunctor(&allocp[6]);
  allocp[9] = a9;
  allocp[10] = x6;
  x7 = makecons(&allocp[9]);
  allocp += 11;
  unify_value(a10, x7);
  proceed();
 case VARREF:
  deref_and_jump(x0,replace__ti__adg_11_2);
  *reasonp++ =  x0;
  goto replace__ti__adg_11_3;
  };
  goto replace__ti__adg_11_3;
 case VARREF:
  deref_and_jump(a0,replace__ti__adg_11_1);
  *reasonp++ =  a0;
  goto replace__ti__adg_11_3;
  };
  goto replace__ti__adg_11_3;
 replace__ti__adg_11_3:
  otherwise(replace__ti__adg_11_interrupt);
  a0 = a5;
  a1 = a6;
  a2 = a7;
  a3 = a9;
  a4 = a10;
  execute(replace__ti__adg1_5_0);
  goto replace__ti__adg1_5_ext_interrupt;
 replace__ti__adg_11_ext_interrupt:
  reasonp = 0l;
 replace__ti__adg_11_interrupt:
  goto interrupt_11;
 }

 replace__ti__adg1_5_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 replace__ti__adg1_5_clear_reason:
  reasonp = reasons;
 replace__ti__adg1_5_0:
 replace__ti__adg1_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 replace__ti__adg1_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_vd_2)) goto replace__ti__adg1_5_7;
  x1 = arg(x0, 0);
 replace__ti__adg1_5_3:
  if (isref(x1)) goto replace__ti__adg1_5_6;
 replace__ti__adg1_5_4:
  if (isref(x1)) goto replace__ti__adg1_5_5;
  if_not_equal(x1, a1, replace__ti__adg1_5_7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xreplace__ti__adg1_5);
  x2 = cdr_of(a0);
  allocp[2] = x2;
  allocp[3] = x1;
  allocp[4] = a2;
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = a4;
  a0 = arg(x0, 1);
  a1 = x1;
  a4 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(replace__ti__vd_5_clear_reason);
  goto replace__ti__vd_5_ext_interrupt;
 replace__ti__adg1_5_5:
  deref_and_jump(x1,replace__ti__adg1_5_4);
  *reasonp++ =  x1;
  goto replace__ti__adg1_5_7;
 replace__ti__adg1_5_6:
  deref_and_jump(x1,replace__ti__adg1_5_3);
  *reasonp++ =  x1;
  goto replace__ti__adg1_5_7;
 case VARREF:
  deref_and_jump(x0,replace__ti__adg1_5_2);
  *reasonp++ =  x0;
  goto replace__ti__adg1_5_7;
  };
  goto replace__ti__adg1_5_7;
 case VARREF:
  deref_and_jump(a0,replace__ti__adg1_5_1);
  *reasonp++ =  a0;
  goto replace__ti__adg1_5_7;
  };
  goto replace__ti__adg1_5_7;
 replace__ti__adg1_5_7:
  otherwise(replace__ti__adg1_5_interrupt);
 replace__ti__adg1_5_8:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(replace__ti__adg1_5_0);
  goto replace__ti__adg1_5_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto replace__ti__adg1_5_interrupt;
  unify(a4, a3);
  proceed();
 case VARREF:
  deref_and_jump(a0,replace__ti__adg1_5_8);
  *reasonp++ =  a0;
  goto replace__ti__adg1_5_interrupt;
  };
  goto replace__ti__adg1_5_interrupt;
 replace__ti__adg1_5_ext_interrupt:
  reasonp = 0l;
 replace__ti__adg1_5_interrupt:
  toppred = &predicate_adg_xreplace__ti__adg1_5;
  goto interrupt_5;
 }

 replace__ti__vd_5_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 replace__ti__vd_5_clear_reason:
  reasonp = reasons;
 replace__ti__vd_5_0:
 replace__ti__vd_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 replace__ti__vd_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_to_2)) goto replace__ti__vd_5_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xreplace__ti__vd1_7);
  allocp[2] = x1 = makeref(&allocp[2]);
  x2 = arg(x0, 1);
  allocp[3] = x2;
  x3 = cdr_of(a0);
  allocp[4] = x3;
  allocp[5] = a1;
  allocp[6] = x4 = makeref(&allocp[6]);
  allocp[7] = a3;
  allocp[8] = a4;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_typeset_xcheck__same__type_4);
  x5 = arg(x0, 0);
  allocp[11] = x5;
  allocp[12] = a2;
  allocp[13] = x4;
  allocp[14] = x1;
  qp = (struct goalrec*)&allocp[9];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(x0,replace__ti__vd_5_2);
  *reasonp++ =  x0;
  goto replace__ti__vd_5_interrupt;
  };
  goto replace__ti__vd_5_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto replace__ti__vd_5_interrupt;
  unify(a4, a3);
  proceed();
 case VARREF:
  deref_and_jump(a0,replace__ti__vd_5_1);
  *reasonp++ =  a0;
  goto replace__ti__vd_5_interrupt;
  };
  goto replace__ti__vd_5_interrupt;
 replace__ti__vd_5_ext_interrupt:
  reasonp = 0l;
 replace__ti__vd_5_interrupt:
  toppred = &predicate_adg_xreplace__ti__vd_5;
  goto interrupt_5;
 }

 replace__ti__vd1_7_top: {
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 replace__ti__vd1_7_clear_reason:
  reasonp = reasons;
 replace__ti__vd1_7_0:
 replace__ti__vd1_7_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto replace__ti__vd1_7_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_list_xor__unique_3);
  allocp[2] = a5;
  allocp[3] = a1;
  allocp[4] = a6;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case symval(makesym(atom_no)):
  a0 = a2;
  a1 = a3;
  a2 = a4;
  a3 = a5;
  a4 = a6;
  execute(replace__ti__vd_5_0);
  goto replace__ti__vd_5_ext_interrupt;
  };
  goto replace__ti__vd1_7_interrupt;
 case VARREF:
  deref_and_jump(a0,replace__ti__vd1_7_1);
  *reasonp++ =  a0;
  goto replace__ti__vd1_7_interrupt;
  };
  goto replace__ti__vd1_7_interrupt;
 replace__ti__vd1_7_ext_interrupt:
  reasonp = 0l;
 replace__ti__vd1_7_interrupt:
  goto interrupt_7;
 }

 entry__ad_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 entry__ad_8_clear_reason:
  reasonp = reasons;
 entry__ad_8_0:
 entry__ad_8_1:
  switch (ptagof(a6)) {
 case CONS:
  x0 = car_of(a6);
 entry__ad_8_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto entry__ad_8_7;
  x1 = arg(x0, 0);
 entry__ad_8_3:
  if (isref(x1)) goto entry__ad_8_6;
 entry__ad_8_4:
  if (isref(x1)) goto entry__ad_8_5;
  if_not_equal(x1, a0, entry__ad_8_7);
  allocp[0] = makesym(functor_module_2);
  allocp[1] = a0;
  allocp[2] = x3 = makeref(&allocp[2]);
  x2 = makefunctor(&allocp[0]);
  x5 = cdr_of(a6);
  allocp[3] = x5;
  allocp[4] = x2;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a7, x4);
  a0 = arg(x0, 1);
  x6 = a1;
  x7 = a2;
  x8 = a3;
  x9 = a4;
  a6 = a5;
  a5 = x9;
  a4 = x8;
  a3 = x7;
  a2 = x6;
  a1 = x3;
  execute(entry__ad__entries_7_clear_reason);
  goto entry__ad__entries_7_ext_interrupt;
 entry__ad_8_5:
  deref_and_jump(x1,entry__ad_8_4);
  *reasonp++ =  x1;
  goto entry__ad_8_7;
 entry__ad_8_6:
  deref_and_jump(x1,entry__ad_8_3);
  *reasonp++ =  x1;
  goto entry__ad_8_7;
 case VARREF:
  deref_and_jump(x0,entry__ad_8_2);
  *reasonp++ =  x0;
  goto entry__ad_8_7;
  };
  goto entry__ad_8_7;
 case VARREF:
  deref_and_jump(a6,entry__ad_8_1);
  *reasonp++ =  a6;
  goto entry__ad_8_7;
  };
  goto entry__ad_8_7;
 entry__ad_8_7:
  otherwise(entry__ad_8_interrupt);
 entry__ad_8_8:
  switch (ptagof(a6)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a6);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a7, x0);
  a6 = cdr_of(a6);
  a7 = x1;
  execute(entry__ad_8_0);
  goto entry__ad_8_ext_interrupt;
 case VARREF:
  deref_and_jump(a6,entry__ad_8_8);
  *reasonp++ =  a6;
  goto entry__ad_8_interrupt;
  };
  goto entry__ad_8_interrupt;
 entry__ad_8_ext_interrupt:
  reasonp = 0l;
 entry__ad_8_interrupt:
  goto interrupt_8;
 }

 entry__ad__entries_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 entry__ad__entries_7_clear_reason:
  reasonp = reasons;
 entry__ad__entries_7_0:
 entry__ad__entries_7_1:
  switch (ptagof(a0)) {
 case CONS:
 entry__ad__entries_7_2:
  switch (ptagof(a4)) {
 case ATOMIC:
  if (isint(a4)) goto entry__ad__entries_7_57;
  switch (symval(a4)) {
 case symval(makesym(atom_pred)):
  x0 = car_of(a0);
 entry__ad__entries_7_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_entry_8)) goto entry__ad__entries_7_57;
  x1 = arg(x0, 0);
 entry__ad__entries_7_4:
  if (isref(x1)) goto entry__ad__entries_7_11;
 entry__ad__entries_7_5:
  if (isref(x1)) goto entry__ad__entries_7_10;
  if_not_equal(x1, a2, entry__ad__entries_7_57);
  x2 = arg(x0, 1);
 entry__ad__entries_7_6:
  if (isref(x2)) goto entry__ad__entries_7_9;
 entry__ad__entries_7_7:
  if (isref(x2)) goto entry__ad__entries_7_8;
  if_not_equal(x2, a3, entry__ad__entries_7_57);
  x4 = cdr_of(a0);
  allocp[0] = x4;
  allocp[1] = x5 = makeref(&allocp[1]);
  x3 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = makeint(3L);
  allocp[3] = x0;
  allocp[4] = x6 = makeref(&allocp[4]);
  allocp[5] = x5;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[8] = makeint(1L);
  x7 = arg(x0, 2);
  allocp[9] = x7;
  allocp[10] = a6;
  allocp[11] = x6;
  qp = (struct goalrec*)&allocp[6];
  allocp += 12;
  proceed();
 entry__ad__entries_7_8:
  deref_and_jump(x2,entry__ad__entries_7_7);
  *reasonp++ =  x2;
  goto entry__ad__entries_7_57;
 entry__ad__entries_7_9:
  deref_and_jump(x2,entry__ad__entries_7_6);
  *reasonp++ =  x2;
  goto entry__ad__entries_7_57;
 entry__ad__entries_7_10:
  deref_and_jump(x1,entry__ad__entries_7_5);
  *reasonp++ =  x1;
  goto entry__ad__entries_7_57;
 entry__ad__entries_7_11:
  deref_and_jump(x1,entry__ad__entries_7_4);
  *reasonp++ =  x1;
  goto entry__ad__entries_7_57;
 case VARREF:
  deref_and_jump(x0,entry__ad__entries_7_3);
  *reasonp++ =  x0;
  goto entry__ad__entries_7_57;
  };
  goto entry__ad__entries_7_57;
 case symval(makesym(atom_pred__r)):
  x0 = car_of(a0);
 entry__ad__entries_7_12:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_entry_8)) goto entry__ad__entries_7_57;
  x1 = arg(x0, 0);
 entry__ad__entries_7_13:
  if (isref(x1)) goto entry__ad__entries_7_20;
 entry__ad__entries_7_14:
  if (isref(x1)) goto entry__ad__entries_7_19;
  if_not_equal(x1, a2, entry__ad__entries_7_57);
  x2 = arg(x0, 1);
 entry__ad__entries_7_15:
  if (isref(x2)) goto entry__ad__entries_7_18;
 entry__ad__entries_7_16:
  if (isref(x2)) goto entry__ad__entries_7_17;
  if_not_equal(x2, a3, entry__ad__entries_7_57);
  x4 = cdr_of(a0);
  allocp[0] = x4;
  allocp[1] = x5 = makeref(&allocp[1]);
  x3 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = makeint(4L);
  allocp[3] = x0;
  allocp[4] = x6 = makeref(&allocp[4]);
  allocp[5] = x5;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[8] = makeint(1L);
  x7 = arg(x0, 3);
  allocp[9] = x7;
  allocp[10] = a6;
  allocp[11] = x6;
  qp = (struct goalrec*)&allocp[6];
  allocp += 12;
  proceed();
 entry__ad__entries_7_17:
  deref_and_jump(x2,entry__ad__entries_7_16);
  *reasonp++ =  x2;
  goto entry__ad__entries_7_57;
 entry__ad__entries_7_18:
  deref_and_jump(x2,entry__ad__entries_7_15);
  *reasonp++ =  x2;
  goto entry__ad__entries_7_57;
 entry__ad__entries_7_19:
  deref_and_jump(x1,entry__ad__entries_7_14);
  *reasonp++ =  x1;
  goto entry__ad__entries_7_57;
 entry__ad__entries_7_20:
  deref_and_jump(x1,entry__ad__entries_7_13);
  *reasonp++ =  x1;
  goto entry__ad__entries_7_57;
 case VARREF:
  deref_and_jump(x0,entry__ad__entries_7_12);
  *reasonp++ =  x0;
  goto entry__ad__entries_7_57;
  };
  goto entry__ad__entries_7_57;
 case symval(makesym(atom_head)):
  x0 = car_of(a0);
 entry__ad__entries_7_21:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_entry_8)) goto entry__ad__entries_7_57;
  x1 = arg(x0, 0);
 entry__ad__entries_7_22:
  if (isref(x1)) goto entry__ad__entries_7_29;
 entry__ad__entries_7_23:
  if (isref(x1)) goto entry__ad__entries_7_28;
  if_not_equal(x1, a2, entry__ad__entries_7_57);
  x2 = arg(x0, 1);
 entry__ad__entries_7_24:
  if (isref(x2)) goto entry__ad__entries_7_27;
 entry__ad__entries_7_25:
  if (isref(x2)) goto entry__ad__entries_7_26;
  if_not_equal(x2, a3, entry__ad__entries_7_57);
  x4 = cdr_of(a0);
  allocp[0] = x4;
  allocp[1] = x5 = makeref(&allocp[1]);
  x3 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = makeint(5L);
  allocp[3] = x0;
  allocp[4] = x6 = makeref(&allocp[4]);
  allocp[5] = x5;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[8] = a5;
  x7 = arg(x0, 4);
  allocp[9] = x7;
  allocp[10] = a6;
  allocp[11] = x6;
  qp = (struct goalrec*)&allocp[6];
  allocp += 12;
  proceed();
 entry__ad__entries_7_26:
  deref_and_jump(x2,entry__ad__entries_7_25);
  *reasonp++ =  x2;
  goto entry__ad__entries_7_57;
 entry__ad__entries_7_27:
  deref_and_jump(x2,entry__ad__entries_7_24);
  *reasonp++ =  x2;
  goto entry__ad__entries_7_57;
 entry__ad__entries_7_28:
  deref_and_jump(x1,entry__ad__entries_7_23);
  *reasonp++ =  x1;
  goto entry__ad__entries_7_57;
 entry__ad__entries_7_29:
  deref_and_jump(x1,entry__ad__entries_7_22);
  *reasonp++ =  x1;
  goto entry__ad__entries_7_57;
 case VARREF:
  deref_and_jump(x0,entry__ad__entries_7_21);
  *reasonp++ =  x0;
  goto entry__ad__entries_7_57;
  };
  goto entry__ad__entries_7_57;
 case symval(makesym(atom_head__r)):
  x0 = car_of(a0);
 entry__ad__entries_7_30:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_entry_8)) goto entry__ad__entries_7_57;
  x1 = arg(x0, 0);
 entry__ad__entries_7_31:
  if (isref(x1)) goto entry__ad__entries_7_38;
 entry__ad__entries_7_32:
  if (isref(x1)) goto entry__ad__entries_7_37;
  if_not_equal(x1, a2, entry__ad__entries_7_57);
  x2 = arg(x0, 1);
 entry__ad__entries_7_33:
  if (isref(x2)) goto entry__ad__entries_7_36;
 entry__ad__entries_7_34:
  if (isref(x2)) goto entry__ad__entries_7_35;
  if_not_equal(x2, a3, entry__ad__entries_7_57);
  x4 = cdr_of(a0);
  allocp[0] = x4;
  allocp[1] = x5 = makeref(&allocp[1]);
  x3 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = makeint(6L);
  allocp[3] = x0;
  allocp[4] = x6 = makeref(&allocp[4]);
  allocp[5] = x5;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[8] = a5;
  x7 = arg(x0, 5);
  allocp[9] = x7;
  allocp[10] = a6;
  allocp[11] = x6;
  qp = (struct goalrec*)&allocp[6];
  allocp += 12;
  proceed();
 entry__ad__entries_7_35:
  deref_and_jump(x2,entry__ad__entries_7_34);
  *reasonp++ =  x2;
  goto entry__ad__entries_7_57;
 entry__ad__entries_7_36:
  deref_and_jump(x2,entry__ad__entries_7_33);
  *reasonp++ =  x2;
  goto entry__ad__entries_7_57;
 entry__ad__entries_7_37:
  deref_and_jump(x1,entry__ad__entries_7_32);
  *reasonp++ =  x1;
  goto entry__ad__entries_7_57;
 entry__ad__entries_7_38:
  deref_and_jump(x1,entry__ad__entries_7_31);
  *reasonp++ =  x1;
  goto entry__ad__entries_7_57;
 case VARREF:
  deref_and_jump(x0,entry__ad__entries_7_30);
  *reasonp++ =  x0;
  goto entry__ad__entries_7_57;
  };
  goto entry__ad__entries_7_57;
 case symval(makesym(atom_body)):
  x0 = car_of(a0);
 entry__ad__entries_7_39:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_entry_8)) goto entry__ad__entries_7_57;
  x1 = arg(x0, 0);
 entry__ad__entries_7_40:
  if (isref(x1)) goto entry__ad__entries_7_47;
 entry__ad__entries_7_41:
  if (isref(x1)) goto entry__ad__entries_7_46;
  if_not_equal(x1, a2, entry__ad__entries_7_57);
  x2 = arg(x0, 1);
 entry__ad__entries_7_42:
  if (isref(x2)) goto entry__ad__entries_7_45;
 entry__ad__entries_7_43:
  if (isref(x2)) goto entry__ad__entries_7_44;
  if_not_equal(x2, a3, entry__ad__entries_7_57);
  x4 = cdr_of(a0);
  allocp[0] = x4;
  allocp[1] = x5 = makeref(&allocp[1]);
  x3 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = makeint(7L);
  allocp[3] = x0;
  allocp[4] = x6 = makeref(&allocp[4]);
  allocp[5] = x5;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[8] = a5;
  x7 = arg(x0, 6);
  allocp[9] = x7;
  allocp[10] = a6;
  allocp[11] = x6;
  qp = (struct goalrec*)&allocp[6];
  allocp += 12;
  proceed();
 entry__ad__entries_7_44:
  deref_and_jump(x2,entry__ad__entries_7_43);
  *reasonp++ =  x2;
  goto entry__ad__entries_7_57;
 entry__ad__entries_7_45:
  deref_and_jump(x2,entry__ad__entries_7_42);
  *reasonp++ =  x2;
  goto entry__ad__entries_7_57;
 entry__ad__entries_7_46:
  deref_and_jump(x1,entry__ad__entries_7_41);
  *reasonp++ =  x1;
  goto entry__ad__entries_7_57;
 entry__ad__entries_7_47:
  deref_and_jump(x1,entry__ad__entries_7_40);
  *reasonp++ =  x1;
  goto entry__ad__entries_7_57;
 case VARREF:
  deref_and_jump(x0,entry__ad__entries_7_39);
  *reasonp++ =  x0;
  goto entry__ad__entries_7_57;
  };
  goto entry__ad__entries_7_57;
 case symval(makesym(atom_body__r)):
  x0 = car_of(a0);
 entry__ad__entries_7_48:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_entry_8)) goto entry__ad__entries_7_57;
  x1 = arg(x0, 0);
 entry__ad__entries_7_49:
  if (isref(x1)) goto entry__ad__entries_7_56;
 entry__ad__entries_7_50:
  if (isref(x1)) goto entry__ad__entries_7_55;
  if_not_equal(x1, a2, entry__ad__entries_7_57);
  x2 = arg(x0, 1);
 entry__ad__entries_7_51:
  if (isref(x2)) goto entry__ad__entries_7_54;
 entry__ad__entries_7_52:
  if (isref(x2)) goto entry__ad__entries_7_53;
  if_not_equal(x2, a3, entry__ad__entries_7_57);
  x4 = cdr_of(a0);
  allocp[0] = x4;
  allocp[1] = x5 = makeref(&allocp[1]);
  x3 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = makeint(8L);
  allocp[3] = x0;
  allocp[4] = x6 = makeref(&allocp[4]);
  allocp[5] = x5;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[8] = a5;
  x7 = arg(x0, 7);
  allocp[9] = x7;
  allocp[10] = a6;
  allocp[11] = x6;
  qp = (struct goalrec*)&allocp[6];
  allocp += 12;
  proceed();
 entry__ad__entries_7_53:
  deref_and_jump(x2,entry__ad__entries_7_52);
  *reasonp++ =  x2;
  goto entry__ad__entries_7_57;
 entry__ad__entries_7_54:
  deref_and_jump(x2,entry__ad__entries_7_51);
  *reasonp++ =  x2;
  goto entry__ad__entries_7_57;
 entry__ad__entries_7_55:
  deref_and_jump(x1,entry__ad__entries_7_50);
  *reasonp++ =  x1;
  goto entry__ad__entries_7_57;
 entry__ad__entries_7_56:
  deref_and_jump(x1,entry__ad__entries_7_49);
  *reasonp++ =  x1;
  goto entry__ad__entries_7_57;
 case VARREF:
  deref_and_jump(x0,entry__ad__entries_7_48);
  *reasonp++ =  x0;
  goto entry__ad__entries_7_57;
  };
  goto entry__ad__entries_7_57;
  };
  goto entry__ad__entries_7_57;
 case VARREF:
  deref_and_jump(a4,entry__ad__entries_7_2);
  *reasonp++ =  a4;
  goto entry__ad__entries_7_57;
  };
  goto entry__ad__entries_7_57;
 case VARREF:
  deref_and_jump(a0,entry__ad__entries_7_1);
  *reasonp++ =  a0;
  goto entry__ad__entries_7_57;
  };
  goto entry__ad__entries_7_57;
 entry__ad__entries_7_57:
  otherwise(entry__ad__entries_7_interrupt);
 entry__ad__entries_7_58:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(entry__ad__entries_7_0);
  goto entry__ad__entries_7_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto entry__ad__entries_7_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,entry__ad__entries_7_58);
  *reasonp++ =  a0;
  goto entry__ad__entries_7_interrupt;
  };
  goto entry__ad__entries_7_interrupt;
 entry__ad__entries_7_ext_interrupt:
  reasonp = 0l;
 entry__ad__entries_7_interrupt:
  toppred = &predicate_adg_xentry__ad__entries_7;
  goto interrupt_7;
 }

 get__ad_7_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 get__ad_7_clear_reason:
  reasonp = reasons;
 get__ad_7_0:
 get__ad_7_1:
  switch (ptagof(a6)) {
 case CONS:
  x0 = car_of(a6);
 get__ad_7_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto get__ad_7_7;
  x1 = arg(x0, 0);
 get__ad_7_3:
  if (isref(x1)) goto get__ad_7_6;
 get__ad_7_4:
  if (isref(x1)) goto get__ad_7_5;
  if_not_equal(x1, a0, get__ad_7_7);
  a0 = arg(x0, 1);
  execute(get__ad__entries_6_clear_reason);
  goto get__ad__entries_6_ext_interrupt;
 get__ad_7_5:
  deref_and_jump(x1,get__ad_7_4);
  *reasonp++ =  x1;
  goto get__ad_7_7;
 get__ad_7_6:
  deref_and_jump(x1,get__ad_7_3);
  *reasonp++ =  x1;
  goto get__ad_7_7;
 case VARREF:
  deref_and_jump(x0,get__ad_7_2);
  *reasonp++ =  x0;
  goto get__ad_7_7;
  };
  goto get__ad_7_7;
 case VARREF:
  deref_and_jump(a6,get__ad_7_1);
  *reasonp++ =  a6;
  goto get__ad_7_7;
  };
  goto get__ad_7_7;
 get__ad_7_7:
  otherwise(get__ad_7_interrupt);
 get__ad_7_8:
  switch (ptagof(a6)) {
 case CONS:
  a6 = cdr_of(a6);
  execute(get__ad_7_0);
  goto get__ad_7_ext_interrupt;
 case VARREF:
  deref_and_jump(a6,get__ad_7_8);
  *reasonp++ =  a6;
  goto get__ad_7_interrupt;
  };
  goto get__ad_7_interrupt;
 get__ad_7_ext_interrupt:
  reasonp = 0l;
 get__ad_7_interrupt:
  toppred = &predicate_adg_xget__ad_7;
  goto interrupt_7;
 }

 get__ad__entries_6_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 get__ad__entries_6_clear_reason:
  reasonp = reasons;
 get__ad__entries_6_0:
 get__ad__entries_6_1:
  switch (ptagof(a0)) {
 case CONS:
 get__ad__entries_6_2:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (isint(a3)) goto get__ad__entries_6_57;
  switch (symval(a3)) {
 case symval(makesym(atom_pred)):
  x0 = car_of(a0);
 get__ad__entries_6_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_entry_8)) goto get__ad__entries_6_57;
  x1 = arg(x0, 0);
 get__ad__entries_6_4:
  if (isref(x1)) goto get__ad__entries_6_11;
 get__ad__entries_6_5:
  if (isref(x1)) goto get__ad__entries_6_10;
  if_not_equal(x1, a1, get__ad__entries_6_57);
  x2 = arg(x0, 1);
 get__ad__entries_6_6:
  if (isref(x2)) goto get__ad__entries_6_9;
 get__ad__entries_6_7:
  if (isref(x2)) goto get__ad__entries_6_8;
  if_not_equal(x2, a2, get__ad__entries_6_57);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(1L);
  x3 = arg(x0, 2);
  allocp[3] = x3;
  allocp[4] = a5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 get__ad__entries_6_8:
  deref_and_jump(x2,get__ad__entries_6_7);
  *reasonp++ =  x2;
  goto get__ad__entries_6_57;
 get__ad__entries_6_9:
  deref_and_jump(x2,get__ad__entries_6_6);
  *reasonp++ =  x2;
  goto get__ad__entries_6_57;
 get__ad__entries_6_10:
  deref_and_jump(x1,get__ad__entries_6_5);
  *reasonp++ =  x1;
  goto get__ad__entries_6_57;
 get__ad__entries_6_11:
  deref_and_jump(x1,get__ad__entries_6_4);
  *reasonp++ =  x1;
  goto get__ad__entries_6_57;
 case VARREF:
  deref_and_jump(x0,get__ad__entries_6_3);
  *reasonp++ =  x0;
  goto get__ad__entries_6_57;
  };
  goto get__ad__entries_6_57;
 case symval(makesym(atom_pred__r)):
  x0 = car_of(a0);
 get__ad__entries_6_12:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_entry_8)) goto get__ad__entries_6_57;
  x1 = arg(x0, 0);
 get__ad__entries_6_13:
  if (isref(x1)) goto get__ad__entries_6_20;
 get__ad__entries_6_14:
  if (isref(x1)) goto get__ad__entries_6_19;
  if_not_equal(x1, a1, get__ad__entries_6_57);
  x2 = arg(x0, 1);
 get__ad__entries_6_15:
  if (isref(x2)) goto get__ad__entries_6_18;
 get__ad__entries_6_16:
  if (isref(x2)) goto get__ad__entries_6_17;
  if_not_equal(x2, a2, get__ad__entries_6_57);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(1L);
  x3 = arg(x0, 3);
  allocp[3] = x3;
  allocp[4] = a5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 get__ad__entries_6_17:
  deref_and_jump(x2,get__ad__entries_6_16);
  *reasonp++ =  x2;
  goto get__ad__entries_6_57;
 get__ad__entries_6_18:
  deref_and_jump(x2,get__ad__entries_6_15);
  *reasonp++ =  x2;
  goto get__ad__entries_6_57;
 get__ad__entries_6_19:
  deref_and_jump(x1,get__ad__entries_6_14);
  *reasonp++ =  x1;
  goto get__ad__entries_6_57;
 get__ad__entries_6_20:
  deref_and_jump(x1,get__ad__entries_6_13);
  *reasonp++ =  x1;
  goto get__ad__entries_6_57;
 case VARREF:
  deref_and_jump(x0,get__ad__entries_6_12);
  *reasonp++ =  x0;
  goto get__ad__entries_6_57;
  };
  goto get__ad__entries_6_57;
 case symval(makesym(atom_head)):
  x0 = car_of(a0);
 get__ad__entries_6_21:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_entry_8)) goto get__ad__entries_6_57;
  x1 = arg(x0, 0);
 get__ad__entries_6_22:
  if (isref(x1)) goto get__ad__entries_6_29;
 get__ad__entries_6_23:
  if (isref(x1)) goto get__ad__entries_6_28;
  if_not_equal(x1, a1, get__ad__entries_6_57);
  x2 = arg(x0, 1);
 get__ad__entries_6_24:
  if (isref(x2)) goto get__ad__entries_6_27;
 get__ad__entries_6_25:
  if (isref(x2)) goto get__ad__entries_6_26;
  if_not_equal(x2, a2, get__ad__entries_6_57);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = a4;
  x3 = arg(x0, 4);
  allocp[3] = x3;
  allocp[4] = a5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 get__ad__entries_6_26:
  deref_and_jump(x2,get__ad__entries_6_25);
  *reasonp++ =  x2;
  goto get__ad__entries_6_57;
 get__ad__entries_6_27:
  deref_and_jump(x2,get__ad__entries_6_24);
  *reasonp++ =  x2;
  goto get__ad__entries_6_57;
 get__ad__entries_6_28:
  deref_and_jump(x1,get__ad__entries_6_23);
  *reasonp++ =  x1;
  goto get__ad__entries_6_57;
 get__ad__entries_6_29:
  deref_and_jump(x1,get__ad__entries_6_22);
  *reasonp++ =  x1;
  goto get__ad__entries_6_57;
 case VARREF:
  deref_and_jump(x0,get__ad__entries_6_21);
  *reasonp++ =  x0;
  goto get__ad__entries_6_57;
  };
  goto get__ad__entries_6_57;
 case symval(makesym(atom_head__r)):
  x0 = car_of(a0);
 get__ad__entries_6_30:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_entry_8)) goto get__ad__entries_6_57;
  x1 = arg(x0, 0);
 get__ad__entries_6_31:
  if (isref(x1)) goto get__ad__entries_6_38;
 get__ad__entries_6_32:
  if (isref(x1)) goto get__ad__entries_6_37;
  if_not_equal(x1, a1, get__ad__entries_6_57);
  x2 = arg(x0, 1);
 get__ad__entries_6_33:
  if (isref(x2)) goto get__ad__entries_6_36;
 get__ad__entries_6_34:
  if (isref(x2)) goto get__ad__entries_6_35;
  if_not_equal(x2, a2, get__ad__entries_6_57);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = a4;
  x3 = arg(x0, 5);
  allocp[3] = x3;
  allocp[4] = a5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 get__ad__entries_6_35:
  deref_and_jump(x2,get__ad__entries_6_34);
  *reasonp++ =  x2;
  goto get__ad__entries_6_57;
 get__ad__entries_6_36:
  deref_and_jump(x2,get__ad__entries_6_33);
  *reasonp++ =  x2;
  goto get__ad__entries_6_57;
 get__ad__entries_6_37:
  deref_and_jump(x1,get__ad__entries_6_32);
  *reasonp++ =  x1;
  goto get__ad__entries_6_57;
 get__ad__entries_6_38:
  deref_and_jump(x1,get__ad__entries_6_31);
  *reasonp++ =  x1;
  goto get__ad__entries_6_57;
 case VARREF:
  deref_and_jump(x0,get__ad__entries_6_30);
  *reasonp++ =  x0;
  goto get__ad__entries_6_57;
  };
  goto get__ad__entries_6_57;
 case symval(makesym(atom_body)):
  x0 = car_of(a0);
 get__ad__entries_6_39:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_entry_8)) goto get__ad__entries_6_57;
  x1 = arg(x0, 0);
 get__ad__entries_6_40:
  if (isref(x1)) goto get__ad__entries_6_47;
 get__ad__entries_6_41:
  if (isref(x1)) goto get__ad__entries_6_46;
  if_not_equal(x1, a1, get__ad__entries_6_57);
  x2 = arg(x0, 1);
 get__ad__entries_6_42:
  if (isref(x2)) goto get__ad__entries_6_45;
 get__ad__entries_6_43:
  if (isref(x2)) goto get__ad__entries_6_44;
  if_not_equal(x2, a2, get__ad__entries_6_57);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = a4;
  x3 = arg(x0, 6);
  allocp[3] = x3;
  allocp[4] = a5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 get__ad__entries_6_44:
  deref_and_jump(x2,get__ad__entries_6_43);
  *reasonp++ =  x2;
  goto get__ad__entries_6_57;
 get__ad__entries_6_45:
  deref_and_jump(x2,get__ad__entries_6_42);
  *reasonp++ =  x2;
  goto get__ad__entries_6_57;
 get__ad__entries_6_46:
  deref_and_jump(x1,get__ad__entries_6_41);
  *reasonp++ =  x1;
  goto get__ad__entries_6_57;
 get__ad__entries_6_47:
  deref_and_jump(x1,get__ad__entries_6_40);
  *reasonp++ =  x1;
  goto get__ad__entries_6_57;
 case VARREF:
  deref_and_jump(x0,get__ad__entries_6_39);
  *reasonp++ =  x0;
  goto get__ad__entries_6_57;
  };
  goto get__ad__entries_6_57;
 case symval(makesym(atom_body__r)):
  x0 = car_of(a0);
 get__ad__entries_6_48:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_entry_8)) goto get__ad__entries_6_57;
  x1 = arg(x0, 0);
 get__ad__entries_6_49:
  if (isref(x1)) goto get__ad__entries_6_56;
 get__ad__entries_6_50:
  if (isref(x1)) goto get__ad__entries_6_55;
  if_not_equal(x1, a1, get__ad__entries_6_57);
  x2 = arg(x0, 1);
 get__ad__entries_6_51:
  if (isref(x2)) goto get__ad__entries_6_54;
 get__ad__entries_6_52:
  if (isref(x2)) goto get__ad__entries_6_53;
  if_not_equal(x2, a2, get__ad__entries_6_57);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = a4;
  x3 = arg(x0, 7);
  allocp[3] = x3;
  allocp[4] = a5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 get__ad__entries_6_53:
  deref_and_jump(x2,get__ad__entries_6_52);
  *reasonp++ =  x2;
  goto get__ad__entries_6_57;
 get__ad__entries_6_54:
  deref_and_jump(x2,get__ad__entries_6_51);
  *reasonp++ =  x2;
  goto get__ad__entries_6_57;
 get__ad__entries_6_55:
  deref_and_jump(x1,get__ad__entries_6_50);
  *reasonp++ =  x1;
  goto get__ad__entries_6_57;
 get__ad__entries_6_56:
  deref_and_jump(x1,get__ad__entries_6_49);
  *reasonp++ =  x1;
  goto get__ad__entries_6_57;
 case VARREF:
  deref_and_jump(x0,get__ad__entries_6_48);
  *reasonp++ =  x0;
  goto get__ad__entries_6_57;
  };
  goto get__ad__entries_6_57;
  };
  goto get__ad__entries_6_57;
 case VARREF:
  deref_and_jump(a3,get__ad__entries_6_2);
  *reasonp++ =  a3;
  goto get__ad__entries_6_57;
  };
  goto get__ad__entries_6_57;
 case VARREF:
  deref_and_jump(a0,get__ad__entries_6_1);
  *reasonp++ =  a0;
  goto get__ad__entries_6_57;
  };
  goto get__ad__entries_6_57;
 get__ad__entries_6_57:
  otherwise(get__ad__entries_6_interrupt);
 get__ad__entries_6_58:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(get__ad__entries_6_0);
  goto get__ad__entries_6_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto get__ad__entries_6_interrupt;
  x0 = NILATOM;
  unify_value(a5, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,get__ad__entries_6_58);
  *reasonp++ =  a0;
  goto get__ad__entries_6_interrupt;
  };
  goto get__ad__entries_6_interrupt;
 get__ad__entries_6_ext_interrupt:
  reasonp = 0l;
 get__ad__entries_6_interrupt:
  toppred = &predicate_adg_xget__ad__entries_6;
  goto interrupt_6;
 }

 heads2pred_7_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 heads2pred_7_clear_reason:
  reasonp = reasons;
 heads2pred_7_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xentry__ad_8);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = makesym(atom_pred);
  allocp[6] = makeint(1L);
  allocp[7] = x0 = makeref(&allocp[7]);
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a6;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_adg_xheads2pred1_11);
  allocp[12] = x2 = makeref(&allocp[12]);
  allocp[13] = a0;
  allocp[14] = a1;
  allocp[15] = a2;
  allocp[16] = a3;
  allocp[17] = x3 = makeref(&allocp[17]);
  allocp[18] = a4;
  allocp[19] = NILATOM;
  allocp[20] = x0;
  allocp[21] = a5;
  allocp[22] = x1;
  allocp[23] = (q)(struct goalrec*)&allocp[10];
  allocp[24] = (q)(&predicate_hb_xget__gids_6);
  allocp[25] = a3;
  allocp[26] = a0;
  allocp[27] = a1;
  allocp[28] = a2;
  allocp[29] = makesym(atom_head);
  allocp[30] = x3;
  allocp[31] = (q)(struct goalrec*)&allocp[23];
  allocp[32] = (q)(&predicate_hb_xget__pnmax_6);
  allocp[33] = a0;
  allocp[34] = a1;
  allocp[35] = a2;
  allocp[36] = makesym(atom_head);
  allocp[37] = x2;
  allocp[38] = a3;
  qp = (struct goalrec*)&allocp[31];
  allocp += 39;
  proceed();
 heads2pred_7_ext_interrupt:
  reasonp = 0l;
 heads2pred_7_interrupt:
  goto interrupt_7;
 }

 heads2pred1_11_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 heads2pred1_11_clear_reason:
  reasonp = reasons;
 heads2pred1_11_0:
 heads2pred1_11_1:
  if (!isint(a0)) goto heads2pred1_11_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,heads2pred1_11_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xheads2pred1_11);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = a9;
  allocp[12] = a10;
  allocp[13] = (q)(struct goalrec*)&allocp[0];
  allocp[14] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[15] = a0;
  allocp[16] = makeint(1L);
  allocp[17] = x1;
  allocp[18] = (q)(struct goalrec*)&allocp[13];
  allocp[19] = (q)(&predicate_list_xor__unique_3);
  allocp[20] = a7;
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = x2;
  allocp[23] = (q)(struct goalrec*)&allocp[18];
  allocp[24] = (q)(&predicate_adg_xad__v2a_3);
  allocp[25] = x4 = makeref(&allocp[25]);
  allocp[26] = x3;
  allocp[27] = x5 = makeref(&allocp[27]);
  allocp[28] = (q)(struct goalrec*)&allocp[23];
  allocp[29] = (q)(&predicate_adg_xgid2goal_3);
  allocp[30] = x6 = makeref(&allocp[30]);
  allocp[31] = x5;
  allocp[32] = a6;
  allocp[33] = (q)(struct goalrec*)&allocp[28];
  allocp[34] = (q)(&predicate_functor__table_xarg_3);
  allocp[35] = a0;
  allocp[36] = a5;
  allocp[37] = x6;
  x7 = a1;
  a1 = a2;
  a2 = a3;
  a3 = makesym(atom_head);
  a4 = a0;
  a5 = x4;
  a6 = a9;
  a0 = x7;
  qp = (struct goalrec*)&allocp[33];
  allocp += 38;
  execute(get__ad_7_0);
  goto get__ad_7_ext_interrupt;
 heads2pred1_11_2:
  if (a0 != makeint(0L)) goto heads2pred1_11_interrupt;
  unify2(a10, a9, a8, a7);
  proceed();
 heads2pred1_11_3:
  if (!isref(a0)) goto heads2pred1_11_interrupt;
  deref_and_jump(a0,heads2pred1_11_1);
  *reasonp++ =  a0;
  goto heads2pred1_11_interrupt;
 heads2pred1_11_ext_interrupt:
  reasonp = 0l;
 heads2pred1_11_interrupt:
  goto interrupt_11;
 }

 predr2headr_10_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 predr2headr_10_clear_reason:
  reasonp = reasons;
 predr2headr_10_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xentry__ad_8);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = makesym(atom_head__r);
  allocp[6] = a3;
  allocp[7] = x0 = makeref(&allocp[7]);
  allocp[8] = a8;
  allocp[9] = a9;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_adg_xad__a2v_5);
  allocp[12] = x1 = makeref(&allocp[12]);
  allocp[13] = x0;
  allocp[14] = a0;
  allocp[15] = a5;
  allocp[16] = a4;
  a3 = makesym(atom_pred__r);
  a4 = makeint(1L);
  a5 = x1;
  a6 = a8;
  qp = (struct goalrec*)&allocp[10];
  allocp += 17;
  execute(get__ad_7_0);
  goto get__ad_7_ext_interrupt;
 predr2headr_10_ext_interrupt:
  reasonp = 0l;
 predr2headr_10_interrupt:
  goto interrupt_10;
 }

 bodysr2predr_7_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 bodysr2predr_7_clear_reason:
  reasonp = reasons;
 bodysr2predr_7_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xentry__ad_8);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = makesym(atom_pred__r);
  allocp[6] = makeint(1L);
  allocp[7] = x0 = makeref(&allocp[7]);
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a6;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_adg_xbodysr2pred1_11);
  allocp[12] = x2 = makeref(&allocp[12]);
  allocp[13] = a0;
  allocp[14] = a1;
  allocp[15] = a2;
  allocp[16] = a3;
  allocp[17] = x3 = makeref(&allocp[17]);
  allocp[18] = a4;
  allocp[19] = NILATOM;
  allocp[20] = x0;
  allocp[21] = a5;
  allocp[22] = x1;
  allocp[23] = (q)(struct goalrec*)&allocp[10];
  allocp[24] = (q)(&predicate_hb_xget__gids_6);
  allocp[25] = a3;
  allocp[26] = a0;
  allocp[27] = a1;
  allocp[28] = a2;
  allocp[29] = makesym(atom_body);
  allocp[30] = x3;
  allocp[31] = (q)(struct goalrec*)&allocp[23];
  allocp[32] = (q)(&predicate_hb_xget__pnmax_6);
  allocp[33] = a0;
  allocp[34] = a1;
  allocp[35] = a2;
  allocp[36] = makesym(atom_body);
  allocp[37] = x2;
  allocp[38] = a3;
  qp = (struct goalrec*)&allocp[31];
  allocp += 39;
  proceed();
 bodysr2predr_7_ext_interrupt:
  reasonp = 0l;
 bodysr2predr_7_interrupt:
  goto interrupt_7;
 }

 bodysr2pred1_11_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 bodysr2pred1_11_clear_reason:
  reasonp = reasons;
 bodysr2pred1_11_0:
 bodysr2pred1_11_1:
  if (!isint(a0)) goto bodysr2pred1_11_2;
  x0 = makeint(0L);
  gblt_greater(a0,x0,bodysr2pred1_11_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xbodys2pred1_11);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = a9;
  allocp[12] = a10;
  allocp[13] = (q)(struct goalrec*)&allocp[0];
  allocp[14] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[15] = a0;
  allocp[16] = makeint(1L);
  allocp[17] = x1;
  allocp[18] = (q)(struct goalrec*)&allocp[13];
  allocp[19] = (q)(&predicate_list_xor__unique_3);
  allocp[20] = a7;
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = x2;
  allocp[23] = (q)(struct goalrec*)&allocp[18];
  allocp[24] = (q)(&predicate_adg_xad__v2a_3);
  allocp[25] = x4 = makeref(&allocp[25]);
  allocp[26] = x3;
  allocp[27] = x5 = makeref(&allocp[27]);
  allocp[28] = (q)(struct goalrec*)&allocp[23];
  allocp[29] = (q)(&predicate_adg_xgid2goal_3);
  allocp[30] = x6 = makeref(&allocp[30]);
  allocp[31] = x5;
  allocp[32] = a6;
  allocp[33] = (q)(struct goalrec*)&allocp[28];
  allocp[34] = (q)(&predicate_functor__table_xarg_3);
  allocp[35] = a0;
  allocp[36] = a5;
  allocp[37] = x6;
  x7 = a1;
  a1 = a2;
  a2 = a3;
  a3 = makesym(atom_body__r);
  a4 = a0;
  a5 = x4;
  a6 = a9;
  a0 = x7;
  qp = (struct goalrec*)&allocp[33];
  allocp += 38;
  execute(get__ad_7_0);
  goto get__ad_7_ext_interrupt;
 bodysr2pred1_11_2:
  if (!isref(a0)) goto bodysr2pred1_11_interrupt;
  deref_and_jump(a0,bodysr2pred1_11_1);
  *reasonp++ =  a0;
  goto bodysr2pred1_11_interrupt;
 bodysr2pred1_11_ext_interrupt:
  reasonp = 0l;
 bodysr2pred1_11_interrupt:
  goto interrupt_11;
 }

 bodys2pred1_11_top: {
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 bodys2pred1_11_clear_reason:
  reasonp = reasons;
 bodys2pred1_11_0:
 bodys2pred1_11_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 bodys2pred1_11_2:
  if (a0 != makeint(0L)) goto bodys2pred1_11_interrupt;
  unify2(a10, a9, a8, a7);
  proceed();
 case VARREF:
  deref_and_jump(a0,bodys2pred1_11_1);
  *reasonp++ =  a0;
  goto bodys2pred1_11_interrupt;
  };
  goto bodys2pred1_11_interrupt;
 bodys2pred1_11_ext_interrupt:
  reasonp = 0l;
 bodys2pred1_11_interrupt:
  goto interrupt_11;
 }

 ad__v2a_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  qp = qp->next;
 ad__v2a_3_clear_reason:
  reasonp = reasons;
 ad__v2a_3_0:
 ad__v2a_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 ad__v2a_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_vd_2)) goto ad__v2a_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xad__v2a_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = makesym(functor_vd_2);
  allocp[6] = x4 = makeref(&allocp[6]);
  allocp[7] = x5 = makeref(&allocp[7]);
  x3 = makefunctor(&allocp[5]);
  allocp[8] = x2;
  allocp[9] = x3;
  x6 = makecons(&allocp[8]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  unify_value(a1, x6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xvd__v2a_3);
  x7 = arg(x0, 1);
  allocp[2] = x7;
  allocp[3] = x5;
  allocp[4] = a2;
  a0 = arg(x0, 0);
  a1 = x4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(v2a_3_0);
  goto v2a_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,ad__v2a_3_2);
  *reasonp++ =  x0;
  goto ad__v2a_3_interrupt;
  };
  goto ad__v2a_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto ad__v2a_3_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,ad__v2a_3_1);
  *reasonp++ =  a0;
  goto ad__v2a_3_interrupt;
  };
  goto ad__v2a_3_interrupt;
 ad__v2a_3_ext_interrupt:
  reasonp = 0l;
 ad__v2a_3_interrupt:
  goto interrupt_3;
 }

 v2a_3_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  qp = qp->next;
 v2a_3_clear_reason:
  reasonp = reasons;
 v2a_3_0:
 v2a_3_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_v_3)) goto v2a_3_2;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xv2a1_6);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a2;
  x1 = arg(a0, 0);
  allocp[4] = x1;
  x2 = arg(a0, 1);
  allocp[5] = x2;
  x3 = arg(a0, 2);
  allocp[6] = x3;
  allocp[7] = a1;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[10] = a2;
  allocp[11] = x4 = makeref(&allocp[11]);
  allocp[12] = x0;
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  proceed();
 case VARREF:
  deref_and_jump(a0,v2a_3_1);
  *reasonp++ =  a0;
  goto v2a_3_2;
  };
  goto v2a_3_2;
 v2a_3_2:
  otherwise(v2a_3_interrupt);
  unify(a1, a0);
  proceed();
 v2a_3_ext_interrupt:
  reasonp = 0l;
 v2a_3_interrupt:
  toppred = &predicate_adg_xv2a_3;
  goto interrupt_3;
 }

 v2a1_6_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 v2a1_6_clear_reason:
  reasonp = reasons;
 v2a1_6_0:
 v2a1_6_1:
  if (!isint(a0)) goto v2a1_6_9;
  x0 = makeint(0L);
  gblt_greater(a0,x0,v2a1_6_10);
 v2a1_6_2:
  if (isref(a1)) goto v2a1_6_8;
  gblt_arg(a0,a1,x1,v2a1_6_10);
 v2a1_6_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_variable_3)) goto v2a1_6_10;
  x2 = arg(x1, 0);
 v2a1_6_4:
  if (isref(x2)) goto v2a1_6_7;
 v2a1_6_5:
  if (isref(x2)) goto v2a1_6_6;
  if_not_equal(x2, a4, v2a1_6_10);
  allocp[0] = makesym(functor_a_1);
  allocp[1] = a0;
  x3 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a5, x3);
  proceed();
 v2a1_6_6:
  deref_and_jump(x2,v2a1_6_5);
  *reasonp++ =  x2;
  goto v2a1_6_10;
 v2a1_6_7:
  deref_and_jump(x2,v2a1_6_4);
  *reasonp++ =  x2;
  goto v2a1_6_10;
 case VARREF:
  deref_and_jump(x1,v2a1_6_3);
  *reasonp++ =  x1;
  goto v2a1_6_10;
  };
  goto v2a1_6_10;
 v2a1_6_8:
  deref_and_jump(a1,v2a1_6_2);
  *reasonp++ =  a1;
  goto v2a1_6_10;
 v2a1_6_9:
  if (!isref(a0)) goto v2a1_6_10;
  deref_and_jump(a0,v2a1_6_1);
  *reasonp++ =  a0;
  goto v2a1_6_10;
 v2a1_6_10:
  otherwise(v2a1_6_interrupt);
 v2a1_6_11:
  if (!isint(a0)) goto v2a1_6_13;
  x0 = makeint(0L);
  gblt_greater(a0,x0,v2a1_6_12);
  x1 = makeint(1L);
  bblt_sub_no_check(a0,x1,x2);
  a0 = x2;
  execute(v2a1_6_0);
  goto v2a1_6_ext_interrupt;
 v2a1_6_12:
  if (a0 != makeint(0L)) goto v2a1_6_interrupt;
  allocp[0] = makesym(functor_v_3);
  allocp[1] = a2;
  allocp[2] = a3;
  allocp[3] = a4;
  x3 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a5, x3);
  proceed();
 v2a1_6_13:
  if (!isref(a0)) goto v2a1_6_interrupt;
  deref_and_jump(a0,v2a1_6_11);
  *reasonp++ =  a0;
  goto v2a1_6_interrupt;
 v2a1_6_ext_interrupt:
  reasonp = 0l;
 v2a1_6_interrupt:
  goto interrupt_6;
 }

 vd__v2a_3_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  qp = qp->next;
 vd__v2a_3_clear_reason:
  reasonp = reasons;
 vd__v2a_3_0:
 vd__v2a_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 vd__v2a_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_to_2)) goto vd__v2a_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xvd__v2a_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = makesym(functor_to_2);
  x4 = arg(x0, 0);
  allocp[6] = x4;
  allocp[7] = x5 = makeref(&allocp[7]);
  x3 = makefunctor(&allocp[5]);
  allocp[8] = x2;
  allocp[9] = x3;
  x6 = makecons(&allocp[8]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  unify_value(a1, x6);
  a0 = arg(x0, 1);
  a1 = x5;
  execute(b__v2a_3_0);
  goto b__v2a_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,vd__v2a_3_2);
  *reasonp++ =  x0;
  goto vd__v2a_3_interrupt;
  };
  goto vd__v2a_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto vd__v2a_3_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,vd__v2a_3_1);
  *reasonp++ =  a0;
  goto vd__v2a_3_interrupt;
  };
  goto vd__v2a_3_interrupt;
 vd__v2a_3_ext_interrupt:
  reasonp = 0l;
 vd__v2a_3_interrupt:
  goto interrupt_3;
 }

 b__v2a_3_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  qp = qp->next;
 b__v2a_3_clear_reason:
  reasonp = reasons;
 b__v2a_3_0:
 b__v2a_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 b__v2a_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_ti_2:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xb__v2a_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = makesym(functor_ti_2);
  allocp[6] = x4 = makeref(&allocp[6]);
  x5 = arg(x0, 1);
  allocp[7] = x5;
  x3 = makefunctor(&allocp[5]);
  allocp[8] = x2;
  allocp[9] = x3;
  x6 = makecons(&allocp[8]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  unify_value(a1, x6);
  a0 = arg(x0, 0);
  a1 = x4;
  execute(v2a_3_0);
  goto v2a_3_ext_interrupt;
 case functor_ta_2:
  allocp[0] = makesym(functor_ta_2);
  x2 = arg(x0, 0);
  allocp[1] = x2;
  x3 = arg(x0, 1);
  allocp[2] = x3;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = x1;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a1, x4);
  a0 = cdr_of(a0);
  a1 = x5;
  execute(b__v2a_3_0);
  goto b__v2a_3_ext_interrupt;
  };
  goto b__v2a_3_interrupt;
 case VARREF:
  deref_and_jump(x0,b__v2a_3_2);
  *reasonp++ =  x0;
  goto b__v2a_3_interrupt;
  };
  goto b__v2a_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto b__v2a_3_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,b__v2a_3_1);
  *reasonp++ =  a0;
  goto b__v2a_3_interrupt;
  };
  goto b__v2a_3_interrupt;
 b__v2a_3_ext_interrupt:
  reasonp = 0l;
 b__v2a_3_interrupt:
  toppred = &predicate_adg_xb__v2a_3;
  goto interrupt_3;
 }

 ad__a2v_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 ad__a2v_5_clear_reason:
  reasonp = reasons;
 ad__a2v_5_0:
 ad__a2v_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 ad__a2v_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_vd_2)) goto ad__a2v_5_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xad__a2v_5);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = makesym(functor_vd_2);
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = x5 = makeref(&allocp[9]);
  x3 = makefunctor(&allocp[7]);
  allocp[10] = x2;
  allocp[11] = x3;
  x6 = makecons(&allocp[10]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  unify_value(a1, x6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xvd__a2v_5);
  x7 = arg(x0, 1);
  allocp[2] = x7;
  allocp[3] = x5;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  a0 = arg(x0, 0);
  a1 = x4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(a2v_5_0);
  goto a2v_5_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,ad__a2v_5_2);
  *reasonp++ =  x0;
  goto ad__a2v_5_interrupt;
  };
  goto ad__a2v_5_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto ad__a2v_5_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,ad__a2v_5_1);
  *reasonp++ =  a0;
  goto ad__a2v_5_interrupt;
  };
  goto ad__a2v_5_interrupt;
 ad__a2v_5_ext_interrupt:
  reasonp = 0l;
 ad__a2v_5_interrupt:
  goto interrupt_5;
 }

 a2v_5_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 a2v_5_clear_reason:
  reasonp = reasons;
 a2v_5_0:
 a2v_5_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_a_1)) goto a2v_5_7;
  x0 = arg(a0, 0);
 a2v_5_2:
  if (!isint(x0)) goto a2v_5_6;
 a2v_5_3:
  if (isref(a4)) goto a2v_5_5;
  gblt_arg(x0,a4,x1,a2v_5_7);
 a2v_5_4:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_variable_3)) goto a2v_5_7;
  allocp[0] = makesym(functor_v_3);
  allocp[1] = a2;
  allocp[2] = a3;
  x3 = arg(x1, 0);
  allocp[3] = x3;
  x2 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a1, x2);
  proceed();
 case VARREF:
  deref_and_jump(x1,a2v_5_4);
  *reasonp++ =  x1;
  goto a2v_5_7;
  };
  goto a2v_5_7;
 a2v_5_5:
  deref_and_jump(a4,a2v_5_3);
  *reasonp++ =  a4;
  goto a2v_5_7;
 a2v_5_6:
  if (!isref(x0)) goto a2v_5_7;
  deref_and_jump(x0,a2v_5_2);
  *reasonp++ =  x0;
  goto a2v_5_7;
 case VARREF:
  deref_and_jump(a0,a2v_5_1);
  *reasonp++ =  a0;
  goto a2v_5_7;
  };
  goto a2v_5_7;
 a2v_5_7:
  otherwise(a2v_5_interrupt);
  unify(a1, a0);
  proceed();
 a2v_5_ext_interrupt:
  reasonp = 0l;
 a2v_5_interrupt:
  toppred = &predicate_adg_xa2v_5;
  goto interrupt_5;
 }

 vd__a2v_5_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 vd__a2v_5_clear_reason:
  reasonp = reasons;
 vd__a2v_5_0:
 vd__a2v_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 vd__a2v_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_to_2)) goto vd__a2v_5_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xvd__a2v_5);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = makesym(functor_to_2);
  x4 = arg(x0, 0);
  allocp[8] = x4;
  allocp[9] = x5 = makeref(&allocp[9]);
  x3 = makefunctor(&allocp[7]);
  allocp[10] = x2;
  allocp[11] = x3;
  x6 = makecons(&allocp[10]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  unify_value(a1, x6);
  a0 = arg(x0, 1);
  a1 = x5;
  execute(b__a2v_5_0);
  goto b__a2v_5_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,vd__a2v_5_2);
  *reasonp++ =  x0;
  goto vd__a2v_5_interrupt;
  };
  goto vd__a2v_5_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto vd__a2v_5_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,vd__a2v_5_1);
  *reasonp++ =  a0;
  goto vd__a2v_5_interrupt;
  };
  goto vd__a2v_5_interrupt;
 vd__a2v_5_ext_interrupt:
  reasonp = 0l;
 vd__a2v_5_interrupt:
  goto interrupt_5;
 }

 b__a2v_5_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 b__a2v_5_clear_reason:
  reasonp = reasons;
 b__a2v_5_0:
 b__a2v_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 b__a2v_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_ti_2:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xb__a2v_5);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = makesym(functor_ti_2);
  allocp[8] = x4 = makeref(&allocp[8]);
  x5 = arg(x0, 1);
  allocp[9] = x5;
  x3 = makefunctor(&allocp[7]);
  allocp[10] = x2;
  allocp[11] = x3;
  x6 = makecons(&allocp[10]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  unify_value(a1, x6);
  a0 = arg(x0, 0);
  a1 = x4;
  execute(a2v_5_0);
  goto a2v_5_ext_interrupt;
 case functor_ta_2:
  allocp[0] = makesym(functor_ta_2);
  x2 = arg(x0, 0);
  allocp[1] = x2;
  x3 = arg(x0, 1);
  allocp[2] = x3;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = x1;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a1, x4);
  a0 = cdr_of(a0);
  a1 = x5;
  execute(b__a2v_5_0);
  goto b__a2v_5_ext_interrupt;
  };
  goto b__a2v_5_interrupt;
 case VARREF:
  deref_and_jump(x0,b__a2v_5_2);
  *reasonp++ =  x0;
  goto b__a2v_5_interrupt;
  };
  goto b__a2v_5_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto b__a2v_5_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,b__a2v_5_1);
  *reasonp++ =  a0;
  goto b__a2v_5_interrupt;
  };
  goto b__a2v_5_interrupt;
 b__a2v_5_ext_interrupt:
  reasonp = 0l;
 b__a2v_5_interrupt:
  toppred = &predicate_adg_xb__a2v_5;
  goto interrupt_5;
 }

 gid2goal_3_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  qp = qp->next;
 gid2goal_3_clear_reason:
  reasonp = reasons;
 gid2goal_3_0:
 gid2goal_3_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_goal_4)) goto gid2goal_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_parse__uty_xdecode__goal_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_parse__uty_xget__goal_6);
  x3 = arg(a0, 0);
  allocp[8] = x3;
  x4 = arg(a0, 1);
  allocp[9] = x4;
  x5 = arg(a0, 3);
  allocp[10] = x5;
  x6 = arg(a0, 2);
  allocp[11] = x6;
  allocp[12] = x0;
  allocp[13] = a2;
  qp = (struct goalrec*)&allocp[6];
  allocp += 14;
  proceed();
 case VARREF:
  deref_and_jump(a0,gid2goal_3_1);
  *reasonp++ =  a0;
  goto gid2goal_3_interrupt;
  };
  goto gid2goal_3_interrupt;
 gid2goal_3_ext_interrupt:
  reasonp = 0l;
 gid2goal_3_interrupt:
  goto interrupt_3;
 }

 get__ogoal_14_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  qp = qp->next;
 get__ogoal_14_clear_reason:
  reasonp = reasons;
 get__ogoal_14_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xget__ogoal__goals_18);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = makesym(atom_body);
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = a0;
  allocp[8] = a1;
  allocp[9] = a2;
  allocp[10] = a6;
  allocp[11] = a7;
  allocp[12] = a8;
  allocp[13] = a9;
  allocp[14] = a10;
  allocp[15] = a11;
  allocp[16] = a12;
  allocp[17] = a13;
  allocp[18] = a3;
  allocp[19] = a4;
  allocp[20] = (q)(struct goalrec*)&allocp[0];
  allocp[21] = (q)(&predicate_adg_xget__ogoal__goals_18);
  allocp[22] = x4 = makeref(&allocp[22]);
  allocp[23] = x0;
  allocp[24] = x5 = makeref(&allocp[24]);
  allocp[25] = makesym(atom_guard);
  allocp[26] = x6 = makeref(&allocp[26]);
  allocp[27] = a0;
  allocp[28] = a1;
  allocp[29] = a2;
  allocp[30] = a6;
  allocp[31] = a7;
  allocp[32] = a8;
  allocp[33] = a9;
  allocp[34] = a10;
  allocp[35] = a11;
  allocp[36] = a12;
  allocp[37] = a13;
  allocp[38] = a3;
  allocp[39] = a4;
  allocp[40] = (q)(struct goalrec*)&allocp[20];
  allocp[41] = (q)(&predicate_adg_xget__ogoal__goal_18);
  allocp[42] = makesym(atom_no);
  allocp[43] = x4;
  allocp[44] = x7 = makeref(&allocp[44]);
  allocp[45] = makesym(atom_head);
  allocp[46] = makeint(1L);
  allocp[47] = a0;
  allocp[48] = a1;
  allocp[49] = a2;
  allocp[50] = a6;
  allocp[51] = a7;
  allocp[52] = a8;
  allocp[53] = a9;
  allocp[54] = a10;
  allocp[55] = a11;
  allocp[56] = a12;
  allocp[57] = a13;
  allocp[58] = a3;
  allocp[59] = a4;
  allocp[60] = (q)(struct goalrec*)&allocp[40];
  allocp[61] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[62] = x2;
  allocp[63] = x8 = makeref(&allocp[63]);
  allocp[64] = x3;
  allocp[65] = (q)(struct goalrec*)&allocp[60];
  allocp[66] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[67] = x5;
  allocp[68] = x9 = makeref(&allocp[68]);
  allocp[69] = x6;
  allocp[70] = makesym(functor_clause_4);
  allocp[71] = x7;
  allocp[72] = x5;
  allocp[73] = x2;
  allocp[74] = x11 = makeref(&allocp[74]);
  x10 = makefunctor(&allocp[70]);
  allocp[75] = (q)(struct goalrec*)&allocp[65];
  allocp[76] = (q)(&predicate_parse__uty_xget__clause_4);
  allocp[77] = a0;
  allocp[78] = a1;
  allocp[79] = x10;
  allocp[80] = a5;
  qp = (struct goalrec*)&allocp[75];
  allocp += 81;
  proceed();
 get__ogoal_14_ext_interrupt:
  reasonp = 0l;
 get__ogoal_14_interrupt:
  toppred = &predicate_adg_xget__ogoal_14;
  goto interrupt_14;
 }

 get__ogoal__goals_18_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  qp = qp->next;
 get__ogoal__goals_18_clear_reason:
  reasonp = reasons;
 get__ogoal__goals_18_0:
 get__ogoal__goals_18_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_yes)) goto get__ogoal__goals_18_2;
  x0 = makesym(atom_yes);
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,get__ogoal__goals_18_1);
  *reasonp++ =  a0;
  goto get__ogoal__goals_18_2;
  };
  goto get__ogoal__goals_18_2;
 get__ogoal__goals_18_2:
  otherwise(get__ogoal__goals_18_interrupt);
 get__ogoal__goals_18_3:
  if (!isint(a4)) goto get__ogoal__goals_18_5;
  x0 = makeint(0L);
  gblt_greater(a4,x0,get__ogoal__goals_18_4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xget__ogoal__goals_18);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  allocp[12] = a10;
  allocp[13] = a11;
  allocp[14] = a12;
  allocp[15] = a13;
  allocp[16] = a14;
  allocp[17] = a15;
  allocp[18] = a16;
  allocp[19] = a17;
  allocp[20] = (q)(struct goalrec*)&allocp[0];
  allocp[21] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[22] = a4;
  allocp[23] = makeint(1L);
  allocp[24] = x2;
  allocp[25] = (q)(struct goalrec*)&allocp[20];
  allocp[26] = (q)(&predicate_adg_xget__ogoal__goal_18);
  allocp[27] = a0;
  allocp[28] = x1;
  allocp[29] = x3 = makeref(&allocp[29]);
  allocp[30] = a3;
  allocp[31] = a4;
  allocp[32] = a5;
  allocp[33] = a6;
  allocp[34] = a7;
  allocp[35] = a8;
  allocp[36] = a9;
  allocp[37] = a10;
  allocp[38] = a11;
  allocp[39] = a12;
  allocp[40] = a13;
  allocp[41] = a14;
  allocp[42] = a15;
  allocp[43] = a16;
  allocp[44] = a17;
  allocp[45] = (q)(struct goalrec*)&allocp[25];
  allocp[46] = (q)(&predicate_functor__table_xarg_3);
  allocp[47] = a4;
  allocp[48] = a2;
  allocp[49] = x3;
  qp = (struct goalrec*)&allocp[45];
  allocp += 50;
  proceed();
 get__ogoal__goals_18_4:
  if (a4 != makeint(0L)) goto get__ogoal__goals_18_interrupt;
  unify(a1, a0);
  proceed();
 get__ogoal__goals_18_5:
  if (!isref(a4)) goto get__ogoal__goals_18_interrupt;
  deref_and_jump(a4,get__ogoal__goals_18_3);
  *reasonp++ =  a4;
  goto get__ogoal__goals_18_interrupt;
 get__ogoal__goals_18_ext_interrupt:
  reasonp = 0l;
 get__ogoal__goals_18_interrupt:
  goto interrupt_18;
 }

 get__ogoal__goal_18_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  qp = qp->next;
 get__ogoal__goal_18_clear_reason:
  reasonp = reasons;
 get__ogoal__goal_18_0:
 get__ogoal__goal_18_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto get__ogoal__goal_18_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  x0 = makesym(atom_yes);
  unify_value(a1, x0);
  proceed();
 case symval(makesym(atom_no)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xget__ogoal__goal1_20);
  allocp[2] = makesym(atom_no);
  allocp[3] = a1;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = x2 = makeref(&allocp[11]);
  allocp[12] = a8;
  allocp[13] = a9;
  allocp[14] = a10;
  allocp[15] = a11;
  allocp[16] = a12;
  allocp[17] = a13;
  allocp[18] = a14;
  allocp[19] = a15;
  allocp[20] = a16;
  allocp[21] = a17;
  allocp[22] = (q)(struct goalrec*)&allocp[0];
  allocp[23] = (q)(&predicate_parse__uty_xdecode__goalcall_6);
  allocp[24] = a5;
  allocp[25] = x2;
  allocp[26] = a2;
  allocp[27] = x1;
  allocp[28] = x3 = makeref(&allocp[28]);
  allocp[29] = x0;
  qp = (struct goalrec*)&allocp[22];
  allocp += 30;
  proceed();
  };
  goto get__ogoal__goal_18_interrupt;
 case VARREF:
  deref_and_jump(a0,get__ogoal__goal_18_1);
  *reasonp++ =  a0;
  goto get__ogoal__goal_18_interrupt;
  };
  goto get__ogoal__goal_18_interrupt;
 get__ogoal__goal_18_ext_interrupt:
  reasonp = 0l;
 get__ogoal__goal_18_interrupt:
  goto interrupt_18;
 }

 get__ogoal__goal1_20_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  a18 = qp->args[18];
  a19 = qp->args[19];
  qp = qp->next;
 get__ogoal__goal1_20_clear_reason:
  reasonp = reasons;
 get__ogoal__goal1_20_0:
 get__ogoal__goal1_20_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_yes)) goto get__ogoal__goal1_20_2;
  x0 = makesym(atom_yes);
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,get__ogoal__goal1_20_1);
  *reasonp++ =  a0;
  goto get__ogoal__goal1_20_2;
  };
  goto get__ogoal__goal1_20_2;
 get__ogoal__goal1_20_2:
  otherwise(get__ogoal__goal1_20_interrupt);
 get__ogoal__goal1_20_3:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_no)) goto get__ogoal__goal1_20_interrupt;
 get__ogoal__goal1_20_4:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (isint(a2)) goto get__ogoal__goal1_20_interrupt;
  switch (symval(a2)) {
 case symval(makesym(atom_builtin)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xget__ogoal__builtin_19);
  allocp[2] = makesym(atom_no);
  allocp[3] = a1;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = a3;
  allocp[7] = a6;
  allocp[8] = a7;
  allocp[9] = a4;
  allocp[10] = a5;
  allocp[11] = a8;
  allocp[12] = a9;
  allocp[13] = a10;
  allocp[14] = a11;
  allocp[15] = a12;
  allocp[16] = a13;
  allocp[17] = a14;
  allocp[18] = a15;
  allocp[19] = a17;
  allocp[20] = a18;
  allocp[21] = (q)(struct goalrec*)&allocp[0];
  allocp[22] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[23] = a3;
  allocp[24] = x0;
  allocp[25] = x1;
  qp = (struct goalrec*)&allocp[21];
  allocp += 26;
  proceed();
 case symval(makesym(atom_userdef)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xget__ogoal__userdef_21);
  allocp[2] = makesym(atom_no);
  allocp[3] = a1;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = a6;
  allocp[8] = a7;
  allocp[9] = a4;
  allocp[10] = a5;
  allocp[11] = a8;
  allocp[12] = a9;
  allocp[13] = x2 = makeref(&allocp[13]);
  allocp[14] = x0;
  allocp[15] = a10;
  allocp[16] = a11;
  allocp[17] = a12;
  allocp[18] = a13;
  allocp[19] = a14;
  allocp[20] = a15;
  allocp[21] = a16;
  allocp[22] = a17;
  allocp[23] = (q)(struct goalrec*)&allocp[0];
  allocp[24] = (q)(&predicate_hb_xget__modes_5);
  allocp[25] = a19;
  allocp[26] = a9;
  allocp[27] = x2;
  allocp[28] = x0;
  allocp[29] = x1;
  allocp[30] = (q)(struct goalrec*)&allocp[23];
  allocp[31] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[32] = a3;
  allocp[33] = x2;
  allocp[34] = x0;
  qp = (struct goalrec*)&allocp[30];
  allocp += 35;
  proceed();
  };
  goto get__ogoal__goal1_20_interrupt;
 case VARREF:
  deref_and_jump(a2,get__ogoal__goal1_20_4);
  *reasonp++ =  a2;
  goto get__ogoal__goal1_20_interrupt;
  };
  goto get__ogoal__goal1_20_interrupt;
 case VARREF:
  deref_and_jump(a0,get__ogoal__goal1_20_3);
  *reasonp++ =  a0;
  goto get__ogoal__goal1_20_interrupt;
  };
  goto get__ogoal__goal1_20_interrupt;
 get__ogoal__goal1_20_ext_interrupt:
  reasonp = 0l;
 get__ogoal__goal1_20_interrupt:
  goto interrupt_20;
 }

 get__ogoal__userdef_21_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  a18 = qp->args[18];
  a19 = qp->args[19];
  a20 = qp->args[20];
  qp = qp->next;
 get__ogoal__userdef_21_clear_reason:
  reasonp = reasons;
 get__ogoal__userdef_21_0:
 get__ogoal__userdef_21_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_yes)) goto get__ogoal__userdef_21_6;
 get__ogoal__userdef_21_2:
  if (isref(a2)) goto get__ogoal__userdef_21_5;
 get__ogoal__userdef_21_3:
  if (isref(a2)) goto get__ogoal__userdef_21_4;
  if_not_equal(a2, a12, get__ogoal__userdef_21_6);
  x0 = makesym(atom_yes);
  unify_value(a1, x0);
  proceed();
 get__ogoal__userdef_21_4:
  deref_and_jump(a2,get__ogoal__userdef_21_3);
  *reasonp++ =  a2;
  goto get__ogoal__userdef_21_6;
 get__ogoal__userdef_21_5:
  deref_and_jump(a2,get__ogoal__userdef_21_2);
  *reasonp++ =  a2;
  goto get__ogoal__userdef_21_6;
 case VARREF:
  deref_and_jump(a0,get__ogoal__userdef_21_1);
  *reasonp++ =  a0;
  goto get__ogoal__userdef_21_6;
  };
  goto get__ogoal__userdef_21_6;
 get__ogoal__userdef_21_6:
  otherwise(get__ogoal__userdef_21_interrupt);
 get__ogoal__userdef_21_7:
  if (!isint(a2)) goto get__ogoal__userdef_21_19;
  x0 = makeint(0L);
  gblt_greater(a2,x0,get__ogoal__userdef_21_20);
 get__ogoal__userdef_21_8:
  switch (ptagof(a7)) {
 case ATOMIC:
  if (a7 != makesym(atom_head)) goto get__ogoal__userdef_21_20;
 get__ogoal__userdef_21_9:
  if (isref(a3)) goto get__ogoal__userdef_21_18;
  gblt_arg(a2,a3,x1,get__ogoal__userdef_21_20);
 get__ogoal__userdef_21_10:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_variable_3)) goto get__ogoal__userdef_21_20;
  x2 = arg(x1, 0);
 get__ogoal__userdef_21_11:
  if (isref(x2)) goto get__ogoal__userdef_21_17;
 get__ogoal__userdef_21_12:
  if (isref(x2)) goto get__ogoal__userdef_21_16;
  if_not_equal(x2, a9, get__ogoal__userdef_21_20);
 get__ogoal__userdef_21_13:
  if (isref(a4)) goto get__ogoal__userdef_21_15;
  gblt_arg(a2,a4,x3,get__ogoal__userdef_21_20);
 get__ogoal__userdef_21_14:
  switch (ptagof(x3)) {
 case ATOMIC:
  if (x3 != makesym(atom_i)) goto get__ogoal__userdef_21_20;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a5;
  allocp[2] = a6;
  allocp[3] = a7;
  allocp[4] = a8;
  x4 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a13, x4);
  unify3(a14, a10, a15, a11, a16, a12);
  x5 = NILATOM;
  unify_value(a17, x5);
  x6 = NILATOM;
  unify_value(a18, x6);
  unify_value(a19, a2);
  x7 = makesym(atom_userdef);
  unify_value(a20, x7);
  x8 = makesym(atom_yes);
  unify_value(a1, x8);
  proceed();
 case VARREF:
  deref_and_jump(x3,get__ogoal__userdef_21_14);
  *reasonp++ =  x3;
  goto get__ogoal__userdef_21_20;
  };
  goto get__ogoal__userdef_21_20;
 get__ogoal__userdef_21_15:
  deref_and_jump(a4,get__ogoal__userdef_21_13);
  *reasonp++ =  a4;
  goto get__ogoal__userdef_21_20;
 get__ogoal__userdef_21_16:
  deref_and_jump(x2,get__ogoal__userdef_21_12);
  *reasonp++ =  x2;
  goto get__ogoal__userdef_21_20;
 get__ogoal__userdef_21_17:
  deref_and_jump(x2,get__ogoal__userdef_21_11);
  *reasonp++ =  x2;
  goto get__ogoal__userdef_21_20;
 case VARREF:
  deref_and_jump(x1,get__ogoal__userdef_21_10);
  *reasonp++ =  x1;
  goto get__ogoal__userdef_21_20;
  };
  goto get__ogoal__userdef_21_20;
 get__ogoal__userdef_21_18:
  deref_and_jump(a3,get__ogoal__userdef_21_9);
  *reasonp++ =  a3;
  goto get__ogoal__userdef_21_20;
 case VARREF:
  deref_and_jump(a7,get__ogoal__userdef_21_8);
  *reasonp++ =  a7;
  goto get__ogoal__userdef_21_20;
  };
  goto get__ogoal__userdef_21_20;
 get__ogoal__userdef_21_19:
  if (!isref(a2)) goto get__ogoal__userdef_21_20;
  deref_and_jump(a2,get__ogoal__userdef_21_7);
  *reasonp++ =  a2;
  goto get__ogoal__userdef_21_20;
 get__ogoal__userdef_21_20:
  otherwise(get__ogoal__userdef_21_interrupt);
 get__ogoal__userdef_21_21:
  if (!isint(a2)) goto get__ogoal__userdef_21_23;
  x0 = makeint(0L);
  gblt_greater(a2,x0,get__ogoal__userdef_21_24);
 get__ogoal__userdef_21_22:
  switch (ptagof(a7)) {
 case ATOMIC:
  if (a7 != makesym(atom_head)) goto get__ogoal__userdef_21_24;
  x1 = makeint(1L);
  bblt_sub_no_check(a2,x1,x2);
  a2 = x2;
  execute(get__ogoal__userdef_21_0);
  goto get__ogoal__userdef_21_ext_interrupt;
 case VARREF:
  deref_and_jump(a7,get__ogoal__userdef_21_22);
  *reasonp++ =  a7;
  goto get__ogoal__userdef_21_24;
  };
  goto get__ogoal__userdef_21_24;
 get__ogoal__userdef_21_23:
  if (!isref(a2)) goto get__ogoal__userdef_21_24;
  deref_and_jump(a2,get__ogoal__userdef_21_21);
  *reasonp++ =  a2;
  goto get__ogoal__userdef_21_24;
 get__ogoal__userdef_21_24:
  otherwise(get__ogoal__userdef_21_interrupt);
 get__ogoal__userdef_21_25:
  if (!isint(a2)) goto get__ogoal__userdef_21_36;
  x0 = makeint(0L);
  gblt_greater(a2,x0,get__ogoal__userdef_21_37);
 get__ogoal__userdef_21_26:
  if (isref(a3)) goto get__ogoal__userdef_21_35;
  gblt_arg(a2,a3,x1,get__ogoal__userdef_21_37);
 get__ogoal__userdef_21_27:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_variable_3)) goto get__ogoal__userdef_21_37;
  x2 = arg(x1, 0);
 get__ogoal__userdef_21_28:
  if (isref(x2)) goto get__ogoal__userdef_21_34;
 get__ogoal__userdef_21_29:
  if (isref(x2)) goto get__ogoal__userdef_21_33;
  if_not_equal(x2, a9, get__ogoal__userdef_21_37);
 get__ogoal__userdef_21_30:
  if (isref(a4)) goto get__ogoal__userdef_21_32;
  gblt_arg(a2,a4,x3,get__ogoal__userdef_21_37);
 get__ogoal__userdef_21_31:
  switch (ptagof(x3)) {
 case ATOMIC:
  if (x3 != makesym(atom_o)) goto get__ogoal__userdef_21_37;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a5;
  allocp[2] = a6;
  allocp[3] = a7;
  allocp[4] = a8;
  x4 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a13, x4);
  unify3(a14, a10, a15, a11, a16, a12);
  x5 = NILATOM;
  unify_value(a17, x5);
  x6 = NILATOM;
  unify_value(a18, x6);
  unify_value(a19, a2);
  x7 = makesym(atom_userdef);
  unify_value(a20, x7);
  x8 = makesym(atom_yes);
  unify_value(a1, x8);
  proceed();
 case VARREF:
  deref_and_jump(x3,get__ogoal__userdef_21_31);
  *reasonp++ =  x3;
  goto get__ogoal__userdef_21_37;
  };
  goto get__ogoal__userdef_21_37;
 get__ogoal__userdef_21_32:
  deref_and_jump(a4,get__ogoal__userdef_21_30);
  *reasonp++ =  a4;
  goto get__ogoal__userdef_21_37;
 get__ogoal__userdef_21_33:
  deref_and_jump(x2,get__ogoal__userdef_21_29);
  *reasonp++ =  x2;
  goto get__ogoal__userdef_21_37;
 get__ogoal__userdef_21_34:
  deref_and_jump(x2,get__ogoal__userdef_21_28);
  *reasonp++ =  x2;
  goto get__ogoal__userdef_21_37;
 case VARREF:
  deref_and_jump(x1,get__ogoal__userdef_21_27);
  *reasonp++ =  x1;
  goto get__ogoal__userdef_21_37;
  };
  goto get__ogoal__userdef_21_37;
 get__ogoal__userdef_21_35:
  deref_and_jump(a3,get__ogoal__userdef_21_26);
  *reasonp++ =  a3;
  goto get__ogoal__userdef_21_37;
 get__ogoal__userdef_21_36:
  if (!isref(a2)) goto get__ogoal__userdef_21_37;
  deref_and_jump(a2,get__ogoal__userdef_21_25);
  *reasonp++ =  a2;
  goto get__ogoal__userdef_21_37;
 get__ogoal__userdef_21_37:
  otherwise(get__ogoal__userdef_21_interrupt);
 get__ogoal__userdef_21_38:
  if (!isint(a2)) goto get__ogoal__userdef_21_40;
  x0 = makeint(0L);
  gblt_greater(a2,x0,get__ogoal__userdef_21_39);
  x1 = makeint(1L);
  bblt_sub_no_check(a2,x1,x2);
  a2 = x2;
  execute(get__ogoal__userdef_21_0);
  goto get__ogoal__userdef_21_ext_interrupt;
 get__ogoal__userdef_21_39:
  if (a2 != makeint(0L)) goto get__ogoal__userdef_21_interrupt;
  unify(a1, a0);
  proceed();
 get__ogoal__userdef_21_40:
  if (!isref(a2)) goto get__ogoal__userdef_21_interrupt;
  deref_and_jump(a2,get__ogoal__userdef_21_38);
  *reasonp++ =  a2;
  goto get__ogoal__userdef_21_interrupt;
 get__ogoal__userdef_21_ext_interrupt:
  reasonp = 0l;
 get__ogoal__userdef_21_interrupt:
  goto interrupt_21;
 }

 get__ogoal__builtin_19_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  a18 = qp->args[18];
  qp = qp->next;
 get__ogoal__builtin_19_clear_reason:
  reasonp = reasons;
 get__ogoal__builtin_19_0:
 get__ogoal__builtin_19_1:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom__3D)) goto get__ogoal__builtin_19_4;
 get__ogoal__builtin_19_2:
  switch (ptagof(a3)) {
 case ATOMIC:
 get__ogoal__builtin_19_3:
  if (a3 != makeint(2L)) goto get__ogoal__builtin_19_4;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xget__ogoal__unify_18);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = a5;
  allocp[7] = a6;
  allocp[8] = a7;
  allocp[9] = a8;
  allocp[10] = a9;
  allocp[11] = a10;
  allocp[12] = a11;
  allocp[13] = a12;
  allocp[14] = a13;
  allocp[15] = a14;
  allocp[16] = a15;
  allocp[17] = a16;
  allocp[18] = a17;
  allocp[19] = a18;
  allocp[20] = (q)(struct goalrec*)&allocp[0];
  allocp[21] = (q)(&predicate_functor__table_xarg_3);
  allocp[22] = makeint(2L);
  allocp[23] = a4;
  allocp[24] = x1;
  allocp[25] = (q)(struct goalrec*)&allocp[20];
  allocp[26] = (q)(&predicate_functor__table_xarg_3);
  allocp[27] = makeint(1L);
  allocp[28] = a4;
  allocp[29] = x0;
  qp = (struct goalrec*)&allocp[25];
  allocp += 30;
  proceed();
 case VARREF:
  deref_and_jump(a3,get__ogoal__builtin_19_2);
  *reasonp++ =  a3;
  goto get__ogoal__builtin_19_4;
  };
  goto get__ogoal__builtin_19_4;
 case VARREF:
  deref_and_jump(a2,get__ogoal__builtin_19_1);
  *reasonp++ =  a2;
  goto get__ogoal__builtin_19_4;
  };
  goto get__ogoal__builtin_19_4;
 get__ogoal__builtin_19_4:
  otherwise(get__ogoal__builtin_19_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xget__ogoal__builtin1_22);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = a8;
  allocp[12] = a9;
  allocp[13] = a10;
  allocp[14] = a11;
  allocp[15] = a12;
  allocp[16] = a13;
  allocp[17] = a14;
  allocp[18] = x1 = makeref(&allocp[18]);
  allocp[19] = a15;
  allocp[20] = x2 = makeref(&allocp[20]);
  allocp[21] = a16;
  allocp[22] = a17;
  allocp[23] = a18;
  allocp[24] = makesym(functor_v_3);
  allocp[25] = a5;
  allocp[26] = a6;
  allocp[27] = a9;
  x3 = makefunctor(&allocp[24]);
  allocp[28] = (q)(struct goalrec*)&allocp[0];
  allocp[29] = (q)(&predicate_list_xcheck__include_3);
  allocp[30] = x3;
  allocp[31] = x4 = makeref(&allocp[31]);
  allocp[32] = x0;
  allocp[33] = (q)(struct goalrec*)&allocp[28];
  allocp[34] = (q)(&predicate_typeset_xvars2vs3_4);
  allocp[35] = a5;
  allocp[36] = a6;
  allocp[37] = x5 = makeref(&allocp[37]);
  allocp[38] = x4;
  allocp[39] = (q)(struct goalrec*)&allocp[33];
  allocp[40] = (q)(&predicate_typeset_xvars2vs3_4);
  allocp[41] = a5;
  allocp[42] = a6;
  allocp[43] = x1;
  allocp[44] = x6 = makeref(&allocp[44]);
  a0 = a4;
  a1 = x1;
  a2 = x5;
  a3 = x2;
  qp = (struct goalrec*)&allocp[39];
  allocp += 45;
  execute(get__builtin__ioargs_4_0);
  goto get__builtin__ioargs_4_ext_interrupt;
 get__ogoal__builtin_19_ext_interrupt:
  reasonp = 0l;
 get__ogoal__builtin_19_interrupt:
  goto interrupt_19;
 }

 get__ogoal__builtin1_22_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  a18 = qp->args[18];
  a19 = qp->args[19];
  a20 = qp->args[20];
  a21 = qp->args[21];
  qp = qp->next;
 get__ogoal__builtin1_22_clear_reason:
  reasonp = reasons;
 get__ogoal__builtin1_22_0:
 get__ogoal__builtin1_22_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto get__ogoal__builtin1_22_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_no)):
  unify(a2, a1);
  proceed();
 case symval(makesym(atom_yes)):
  x0 = makesym(atom_yes);
  unify_value(a2, x0);
  unify3(a13, a11, a14, a3, a15, a4);
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a6;
  allocp[2] = a7;
  allocp[3] = a8;
  allocp[4] = a9;
  x1 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a12, x1);
  unify2(a17, a16, a19, a18);
  x2 = makesym(atom_builtin);
  unify_value(a20, x2);
  proceed();
  };
  goto get__ogoal__builtin1_22_interrupt;
 case VARREF:
  deref_and_jump(a0,get__ogoal__builtin1_22_1);
  *reasonp++ =  a0;
  goto get__ogoal__builtin1_22_interrupt;
  };
  goto get__ogoal__builtin1_22_interrupt;
 get__ogoal__builtin1_22_ext_interrupt:
  reasonp = 0l;
 get__ogoal__builtin1_22_interrupt:
  goto interrupt_22;
 }

 get__ogoal__unify_18_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  qp = qp->next;
 get__ogoal__unify_18_clear_reason:
  reasonp = reasons;
 get__ogoal__unify_18_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xget__ogoal__unify0_20);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = a2;
  allocp[7] = a3;
  allocp[8] = a4;
  allocp[9] = a5;
  allocp[10] = a6;
  allocp[11] = a7;
  allocp[12] = a8;
  allocp[13] = a9;
  allocp[14] = a10;
  allocp[15] = a11;
  allocp[16] = a12;
  allocp[17] = a13;
  allocp[18] = a14;
  allocp[19] = a15;
  allocp[20] = a16;
  allocp[21] = a17;
  allocp[22] = makesym(functor_v_3);
  allocp[23] = a4;
  allocp[24] = a5;
  allocp[25] = a8;
  x2 = makefunctor(&allocp[22]);
  allocp[26] = (q)(struct goalrec*)&allocp[0];
  allocp[27] = (q)(&predicate_list_xcheck__include_3);
  allocp[28] = x2;
  allocp[29] = x3 = makeref(&allocp[29]);
  allocp[30] = x1;
  allocp[31] = makesym(functor_v_3);
  allocp[32] = a4;
  allocp[33] = a5;
  allocp[34] = a8;
  x4 = makefunctor(&allocp[31]);
  allocp[35] = (q)(struct goalrec*)&allocp[26];
  allocp[36] = (q)(&predicate_list_xcheck__include_3);
  allocp[37] = x4;
  allocp[38] = x5 = makeref(&allocp[38]);
  allocp[39] = x0;
  allocp[40] = (q)(struct goalrec*)&allocp[35];
  allocp[41] = (q)(&predicate_adg_xget__vars__in__struct_4);
  allocp[42] = a4;
  allocp[43] = a5;
  allocp[44] = a3;
  allocp[45] = x3;
  a0 = a4;
  a1 = a5;
  a3 = x5;
  qp = (struct goalrec*)&allocp[40];
  allocp += 46;
  execute(get__vars__in__struct_4_0);
  goto get__vars__in__struct_4_ext_interrupt;
 get__ogoal__unify_18_ext_interrupt:
  reasonp = 0l;
 get__ogoal__unify_18_interrupt:
  goto interrupt_18;
 }

 get__ogoal__unify0_20_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  a18 = qp->args[18];
  a19 = qp->args[19];
  qp = qp->next;
 get__ogoal__unify0_20_clear_reason:
  reasonp = reasons;
 get__ogoal__unify0_20_0:
 get__ogoal__unify0_20_1:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_no)) goto get__ogoal__unify0_20_3;
 get__ogoal__unify0_20_2:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_no)) goto get__ogoal__unify0_20_3;
  unify(a1, a0);
  proceed();
 case VARREF:
  deref_and_jump(a3,get__ogoal__unify0_20_2);
  *reasonp++ =  a3;
  goto get__ogoal__unify0_20_3;
  };
  goto get__ogoal__unify0_20_3;
 case VARREF:
  deref_and_jump(a2,get__ogoal__unify0_20_1);
  *reasonp++ =  a2;
  goto get__ogoal__unify0_20_3;
  };
  goto get__ogoal__unify0_20_3;
 get__ogoal__unify0_20_3:
  otherwise(get__ogoal__unify0_20_interrupt);
 get__ogoal__unify0_20_4:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (isint(a2)) goto get__ogoal__unify0_20_7;
  switch (symval(a2)) {
 case symval(makesym(atom_yes)):
 get__ogoal__unify0_20_5:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_no)) goto get__ogoal__unify0_20_7;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a6;
  allocp[2] = a7;
  allocp[3] = a8;
  allocp[4] = a9;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_adg_xget__ogoal__unify1_15);
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a5;
  allocp[11] = a10;
  allocp[12] = x0;
  allocp[13] = a12;
  allocp[14] = a11;
  allocp[15] = a13;
  allocp[16] = a14;
  allocp[17] = a15;
  allocp[18] = a16;
  allocp[19] = a17;
  allocp[20] = a18;
  allocp[21] = a19;
  allocp[22] = (q)(struct goalrec*)&allocp[5];
  allocp[23] = (q)(&predicate_list_xcheck__include_3);
  allocp[24] = x0;
  allocp[25] = x2 = makeref(&allocp[25]);
  allocp[26] = x1;
  allocp[27] = (q)(struct goalrec*)&allocp[22];
  allocp[28] = (q)(&predicate_typeset_xget__ds_5);
  allocp[29] = a6;
  allocp[30] = a7;
  allocp[31] = a10;
  allocp[32] = x2;
  allocp[33] = a19;
  qp = (struct goalrec*)&allocp[27];
  allocp += 34;
  proceed();
 case VARREF:
  deref_and_jump(a3,get__ogoal__unify0_20_5);
  *reasonp++ =  a3;
  goto get__ogoal__unify0_20_7;
  };
  goto get__ogoal__unify0_20_7;
 case symval(makesym(atom_no)):
 get__ogoal__unify0_20_6:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_yes)) goto get__ogoal__unify0_20_7;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a6;
  allocp[2] = a7;
  allocp[3] = a8;
  allocp[4] = a9;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_adg_xget__ogoal__unify1_15);
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a4;
  allocp[11] = a10;
  allocp[12] = x0;
  allocp[13] = a12;
  allocp[14] = a11;
  allocp[15] = a13;
  allocp[16] = a14;
  allocp[17] = a15;
  allocp[18] = a16;
  allocp[19] = a17;
  allocp[20] = a18;
  allocp[21] = a19;
  allocp[22] = (q)(struct goalrec*)&allocp[5];
  allocp[23] = (q)(&predicate_list_xcheck__include_3);
  allocp[24] = x0;
  allocp[25] = x2 = makeref(&allocp[25]);
  allocp[26] = x1;
  allocp[27] = (q)(struct goalrec*)&allocp[22];
  allocp[28] = (q)(&predicate_typeset_xget__ds_5);
  allocp[29] = a6;
  allocp[30] = a7;
  allocp[31] = a10;
  allocp[32] = x2;
  allocp[33] = a19;
  qp = (struct goalrec*)&allocp[27];
  allocp += 34;
  proceed();
 case VARREF:
  deref_and_jump(a3,get__ogoal__unify0_20_6);
  *reasonp++ =  a3;
  goto get__ogoal__unify0_20_7;
  };
  goto get__ogoal__unify0_20_7;
  };
  goto get__ogoal__unify0_20_7;
 case VARREF:
  deref_and_jump(a2,get__ogoal__unify0_20_4);
  *reasonp++ =  a2;
  goto get__ogoal__unify0_20_7;
  };
  goto get__ogoal__unify0_20_7;
 get__ogoal__unify0_20_7:
  otherwise(get__ogoal__unify0_20_interrupt);
 get__ogoal__unify0_20_8:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_yes)) goto get__ogoal__unify0_20_interrupt;
 get__ogoal__unify0_20_9:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_yes)) goto get__ogoal__unify0_20_interrupt;
  x0 = makesym(atom_err);
  x1 = makesym(atom_ogoal__unify0);
  unify(x0, x1);
  proceed();
 case VARREF:
  deref_and_jump(a3,get__ogoal__unify0_20_9);
  *reasonp++ =  a3;
  goto get__ogoal__unify0_20_interrupt;
  };
  goto get__ogoal__unify0_20_interrupt;
 case VARREF:
  deref_and_jump(a2,get__ogoal__unify0_20_8);
  *reasonp++ =  a2;
  goto get__ogoal__unify0_20_interrupt;
  };
  goto get__ogoal__unify0_20_interrupt;
 get__ogoal__unify0_20_ext_interrupt:
  reasonp = 0l;
 get__ogoal__unify0_20_interrupt:
  goto interrupt_20;
 }

 get__ogoal__unify1_15_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  qp = qp->next;
 get__ogoal__unify1_15_clear_reason:
  reasonp = reasons;
 get__ogoal__unify1_15_0:
 get__ogoal__unify1_15_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto get__ogoal__unify1_15_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_no)):
  unify(a2, a1);
  proceed();
 case symval(makesym(atom_yes)):
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  x0 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a5, x0);
  x5 = makesym(atom_yes);
  unify_value(a2, x5);
  allocp[0] = NILATOM;
  allocp[1] = a3;
  x6 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a11, x6);
  x7 = makesym(atom_builtin);
  unify_value(a13, x7);
  x8 = makeint(2L);
  unify_value(a10, x8);
  x9 = makesym(atom__3D);
  unify_value(a9, x9);
  unify2(a8, a7, a6, a5);
  allocp[0] = NILATOM;
  allocp[1] = x11 = makeref(&allocp[1]);
  x10 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a12, x10);
  allocp[0] = makesym(functor_variable_3);
  allocp[1] = a4;
  allocp[2] = makeint(-1L);
  allocp[3] = makeint(-1L);
  x12 = makefunctor(&allocp[0]);
  a0 = x1;
  a1 = x2;
  a2 = x12;
  a3 = x11;
  a4 = a14;
  allocp += 4;
  execute(get__ogoal__its_5_0);
  goto get__ogoal__its_5_ext_interrupt;
  };
  goto get__ogoal__unify1_15_interrupt;
 case VARREF:
  deref_and_jump(a0,get__ogoal__unify1_15_1);
  *reasonp++ =  a0;
  goto get__ogoal__unify1_15_interrupt;
  };
  goto get__ogoal__unify1_15_interrupt;
 get__ogoal__unify1_15_ext_interrupt:
  reasonp = 0l;
 get__ogoal__unify1_15_interrupt:
  goto interrupt_15;
 }

 get__ogoal__its_5_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 get__ogoal__its_5_clear_reason:
  reasonp = reasons;
 get__ogoal__its_5_0:
 get__ogoal__its_5_1:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_variable_3)) goto get__ogoal__its_5_2;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xget_5);
  allocp[2] = a0;
  allocp[3] = a1;
  x0 = arg(a2, 0);
  allocp[4] = x0;
  allocp[5] = a3;
  allocp[6] = a4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  proceed();
 case VARREF:
  deref_and_jump(a2,get__ogoal__its_5_1);
  *reasonp++ =  a2;
  goto get__ogoal__its_5_2;
  };
  goto get__ogoal__its_5_2;
 get__ogoal__its_5_2:
  otherwise(get__ogoal__its_5_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xvalue2typeset_5);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = NILATOM;
  allocp[6] = a3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  proceed();
 get__ogoal__its_5_ext_interrupt:
  reasonp = 0l;
 get__ogoal__its_5_interrupt:
  toppred = &predicate_adg_xget__ogoal__its_5;
  goto interrupt_5;
 }

 get__builtin__ioargs_4_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 get__builtin__ioargs_4_clear_reason:
  reasonp = reasons;
 get__builtin__ioargs_4_0:
 get__builtin__ioargs_4_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_add_3:
  allocp[0] = NILATOM;
  x1 = arg(a0, 1);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  x3 = arg(a0, 0);
  allocp[3] = x3;
  x2 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a1, x2);
  allocp[0] = NILATOM;
  x5 = arg(a0, 2);
  allocp[1] = x5;
  x4 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x4);
  x6 = makecons(cons_const_5);
  unify_value(a3, x6);
  proceed();
 case functor_subtract_3:
  allocp[0] = NILATOM;
  x1 = arg(a0, 1);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  x3 = arg(a0, 0);
  allocp[3] = x3;
  x2 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a1, x2);
  allocp[0] = NILATOM;
  x5 = arg(a0, 2);
  allocp[1] = x5;
  x4 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x4);
  x6 = makecons(cons_const_5);
  unify_value(a3, x6);
  proceed();
 case functor_multiply_3:
  allocp[0] = NILATOM;
  x1 = arg(a0, 1);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  x3 = arg(a0, 0);
  allocp[3] = x3;
  x2 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a1, x2);
  allocp[0] = NILATOM;
  x5 = arg(a0, 2);
  allocp[1] = x5;
  x4 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x4);
  x6 = makecons(cons_const_5);
  unify_value(a3, x6);
  proceed();
 case functor_divide_3:
  allocp[0] = NILATOM;
  x1 = arg(a0, 1);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  x3 = arg(a0, 0);
  allocp[3] = x3;
  x2 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a1, x2);
  allocp[0] = NILATOM;
  x5 = arg(a0, 2);
  allocp[1] = x5;
  x4 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x4);
  x6 = makecons(cons_const_5);
  unify_value(a3, x6);
  proceed();
 case functor_less__than_2:
  allocp[0] = NILATOM;
  x1 = arg(a0, 1);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  x3 = arg(a0, 0);
  allocp[3] = x3;
  x2 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a1, x2);
  x4 = NILATOM;
  unify_value(a2, x4);
  x5 = makecons(cons_const_5);
  unify_value(a3, x5);
  proceed();
 case functor_not__greater__than_2:
  allocp[0] = NILATOM;
  x1 = arg(a0, 1);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  x3 = arg(a0, 0);
  allocp[3] = x3;
  x2 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a1, x2);
  x4 = NILATOM;
  unify_value(a2, x4);
  x5 = makecons(cons_const_5);
  unify_value(a3, x5);
  proceed();
 case functor_not__less__than_2:
  allocp[0] = NILATOM;
  x1 = arg(a0, 1);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  x3 = arg(a0, 0);
  allocp[3] = x3;
  x2 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a1, x2);
  x4 = NILATOM;
  unify_value(a2, x4);
  x5 = makecons(cons_const_5);
  unify_value(a3, x5);
  proceed();
 case functor_greater__than_2:
  allocp[0] = NILATOM;
  x1 = arg(a0, 1);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  x3 = arg(a0, 0);
  allocp[3] = x3;
  x2 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a1, x2);
  x4 = NILATOM;
  unify_value(a2, x4);
  x5 = makecons(cons_const_5);
  unify_value(a3, x5);
  proceed();
 case functor_equal_2:
  allocp[0] = NILATOM;
  x1 = arg(a0, 1);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  x3 = arg(a0, 0);
  allocp[3] = x3;
  x2 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a1, x2);
  x4 = NILATOM;
  unify_value(a2, x4);
  x5 = makecons(cons_const_5);
  unify_value(a3, x5);
  proceed();
 case functor_not__equal_2:
  allocp[0] = NILATOM;
  x1 = arg(a0, 1);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  x3 = arg(a0, 0);
  allocp[3] = x3;
  x2 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a1, x2);
  x4 = NILATOM;
  unify_value(a2, x4);
  x5 = makecons(cons_const_5);
  unify_value(a3, x5);
  proceed();
 case functor_outstream_1:
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  x2 = NILATOM;
  unify_value(a2, x2);
  x3 = makecons(cons_const_1);
  unify_value(a3, x3);
  proceed();
 case functor_modulo_3:
  allocp[0] = NILATOM;
  x1 = arg(a0, 1);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  x3 = arg(a0, 0);
  allocp[3] = x3;
  x2 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a1, x2);
  allocp[0] = NILATOM;
  x5 = arg(a0, 2);
  allocp[1] = x5;
  x4 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x4);
  x6 = makecons(cons_const_5);
  unify_value(a3, x6);
  proceed();
  };
  goto get__builtin__ioargs_4_2;
 case VARREF:
  deref_and_jump(a0,get__builtin__ioargs_4_1);
  *reasonp++ =  a0;
  goto get__builtin__ioargs_4_2;
  };
  goto get__builtin__ioargs_4_2;
 get__builtin__ioargs_4_2:
  otherwise(get__builtin__ioargs_4_interrupt);
  x0 = makesym(atom_unknown__builtin);
  x1 = makesym(atom_get__builtin__ioargs);
  unify(x0, x1);
  proceed();
 get__builtin__ioargs_4_ext_interrupt:
  reasonp = 0l;
 get__builtin__ioargs_4_interrupt:
  toppred = &predicate_adg_xget__builtin__ioargs_4;
  goto interrupt_4;
 }

 check__ta__in__ad_11_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 check__ta__in__ad_11_clear_reason:
  reasonp = reasons;
 check__ta__in__ad_11_0:
  x0 = a0;
  x1 = a1;
  x2 = a2;
  x3 = a3;
  x4 = a4;
  x5 = a5;
  x6 = a6;
  x7 = a7;
  x8 = a8;
  x9 = a9;
  a11 = a10;
  a10 = x9;
  a9 = x8;
  a8 = x7;
  a7 = x6;
  a6 = x5;
  a5 = x4;
  a4 = x3;
  a3 = x2;
  a2 = x1;
  a1 = x0;
  a0 = NILATOM;
  execute(check__ta__in__ad1_12_0);
  goto check__ta__in__ad1_12_ext_interrupt;
 check__ta__in__ad_11_ext_interrupt:
  reasonp = 0l;
 check__ta__in__ad_11_interrupt:
  goto interrupt_11;
 }

 check__ta__in__ad1_12_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 check__ta__in__ad1_12_clear_reason:
  reasonp = reasons;
 check__ta__in__ad1_12_0:
 check__ta__in__ad1_12_1:
  switch (ptagof(a2)) {
 case CONS:
  x0 = car_of(a2);
 check__ta__in__ad1_12_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_vd_2)) goto check__ta__in__ad1_12_3;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xcheck__ta__in__ad1_12);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  x2 = cdr_of(a2);
  allocp[4] = x2;
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  allocp[12] = a10;
  allocp[13] = a11;
  allocp[14] = makesym(functor_vd_2);
  x5 = arg(x0, 0);
  allocp[15] = x5;
  x6 = arg(x0, 1);
  allocp[16] = x6;
  x4 = makefunctor(&allocp[14]);
  allocp[17] = x3;
  allocp[18] = x4;
  x7 = makecons(&allocp[17]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 19;
  unify_value(a3, x7);
  x8 = arg(x0, 1);
  a1 = a0;
  a2 = x1;
  a3 = a10;
  a0 = x8;
  execute(check__ta__in__ad2_4_0);
  goto check__ta__in__ad2_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,check__ta__in__ad1_12_2);
  *reasonp++ =  x0;
  goto check__ta__in__ad1_12_3;
  };
  goto check__ta__in__ad1_12_3;
 case VARREF:
  deref_and_jump(a2,check__ta__in__ad1_12_1);
  *reasonp++ =  a2;
  goto check__ta__in__ad1_12_3;
  };
  goto check__ta__in__ad1_12_3;
 check__ta__in__ad1_12_3:
 check__ta__in__ad1_12_4:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != NILATOM) goto check__ta__in__ad1_12_6;
 check__ta__in__ad1_12_5:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != NILATOM) goto check__ta__in__ad1_12_6;
  x0 = NILATOM;
  unify_value(a3, x0);
  proceed();
 case VARREF:
  deref_and_jump(a2,check__ta__in__ad1_12_5);
  *reasonp++ =  a2;
  goto check__ta__in__ad1_12_6;
  };
  goto check__ta__in__ad1_12_6;
 case VARREF:
  deref_and_jump(a0,check__ta__in__ad1_12_4);
  *reasonp++ =  a0;
  goto check__ta__in__ad1_12_6;
  };
  goto check__ta__in__ad1_12_6;
 check__ta__in__ad1_12_6:
  otherwise(check__ta__in__ad1_12_interrupt);
 check__ta__in__ad1_12_7:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != NILATOM) goto check__ta__in__ad1_12_interrupt;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  a5 = a6;
  a6 = a7;
  a7 = a8;
  a8 = a9;
  a9 = a10;
  a10 = a11;
  execute(append__tavd_11_0);
  goto append__tavd_11_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,check__ta__in__ad1_12_7);
  *reasonp++ =  a2;
  goto check__ta__in__ad1_12_interrupt;
  };
  goto check__ta__in__ad1_12_interrupt;
 check__ta__in__ad1_12_ext_interrupt:
  reasonp = 0l;
 check__ta__in__ad1_12_interrupt:
  toppred = &predicate_adg_xcheck__ta__in__ad1_12;
  goto interrupt_12;
 }

 check__ta__in__ad2_4_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 check__ta__in__ad2_4_clear_reason:
  reasonp = reasons;
 check__ta__in__ad2_4_0:
 check__ta__in__ad2_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 check__ta__in__ad2_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_to_2)) goto check__ta__in__ad2_4_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xcheck__ta__in__ad2_4);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  a0 = arg(x0, 1);
  a2 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(check__ta__in__ad__b_4_0);
  goto check__ta__in__ad__b_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,check__ta__in__ad2_4_2);
  *reasonp++ =  x0;
  goto check__ta__in__ad2_4_interrupt;
  };
  goto check__ta__in__ad2_4_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto check__ta__in__ad2_4_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,check__ta__in__ad2_4_1);
  *reasonp++ =  a0;
  goto check__ta__in__ad2_4_interrupt;
  };
  goto check__ta__in__ad2_4_interrupt;
 check__ta__in__ad2_4_ext_interrupt:
  reasonp = 0l;
 check__ta__in__ad2_4_interrupt:
  toppred = &predicate_adg_xcheck__ta__in__ad2_4;
  goto interrupt_4;
 }

 check__ta__in__ad__b_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 check__ta__in__ad__b_4_clear_reason:
  reasonp = reasons;
 check__ta__in__ad__b_4_0:
 check__ta__in__ad__b_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 check__ta__in__ad__b_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_ti_2:
  a0 = cdr_of(a0);
  execute(check__ta__in__ad__b_4_0);
  goto check__ta__in__ad__b_4_ext_interrupt;
 case functor_ta_2:
  x1 = arg(x0, 0);
 check__ta__in__ad__b_4_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_ad_5)) goto check__ta__in__ad__b_4_interrupt;
  allocp[0] = makesym(functor_g_5);
  x3 = arg(x1, 0);
  allocp[1] = x3;
  x4 = arg(x1, 1);
  allocp[2] = x4;
  x5 = arg(x1, 2);
  allocp[3] = x5;
  x6 = arg(x1, 3);
  allocp[4] = x6;
  x7 = arg(x1, 4);
  allocp[5] = x7;
  x2 = makefunctor(&allocp[0]);
  allocp[6] = a1;
  allocp[7] = x2;
  x8 = makecons(&allocp[6]);
  a0 = cdr_of(a0);
  a1 = x8;
  allocp += 8;
  execute(check__ta__in__ad__b_4_0);
  goto check__ta__in__ad__b_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,check__ta__in__ad__b_4_3);
  *reasonp++ =  x1;
  goto check__ta__in__ad__b_4_interrupt;
  };
  goto check__ta__in__ad__b_4_interrupt;
  };
  goto check__ta__in__ad__b_4_interrupt;
 case VARREF:
  deref_and_jump(x0,check__ta__in__ad__b_4_2);
  *reasonp++ =  x0;
  goto check__ta__in__ad__b_4_interrupt;
  };
  goto check__ta__in__ad__b_4_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto check__ta__in__ad__b_4_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,check__ta__in__ad__b_4_1);
  *reasonp++ =  a0;
  goto check__ta__in__ad__b_4_interrupt;
  };
  goto check__ta__in__ad__b_4_interrupt;
 check__ta__in__ad__b_4_ext_interrupt:
  reasonp = 0l;
 check__ta__in__ad__b_4_interrupt:
  toppred = &predicate_adg_xcheck__ta__in__ad__b_4;
  goto interrupt_4;
 }

 append__tavd_11_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 append__tavd_11_clear_reason:
  reasonp = reasons;
 append__tavd_11_0:
 append__tavd_11_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 append__tavd_11_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_g_5)) goto append__tavd_11_14;
  x1 = arg(x0, 0);
 append__tavd_11_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_goal_4)) goto append__tavd_11_14;
  x2 = arg(x1, 2);
 append__tavd_11_4:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != makesym(atom_body)) goto append__tavd_11_14;
 append__tavd_11_5:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_goal_4)) goto append__tavd_11_14;
  x3 = arg(a1, 0);
 append__tavd_11_6:
  if (isref(x3)) goto append__tavd_11_13;
 append__tavd_11_7:
  if (isref(x3)) goto append__tavd_11_12;
  x4 = arg(x1, 0);
  if_not_equal(x3, x4, append__tavd_11_14);
  x5 = arg(a1, 1);
 append__tavd_11_8:
  if (isref(x5)) goto append__tavd_11_11;
 append__tavd_11_9:
  if (isref(x5)) goto append__tavd_11_10;
  x6 = arg(x1, 1);
  if_not_equal(x5, x6, append__tavd_11_14);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xappend__tavd_11);
  x7 = cdr_of(a0);
  allocp[2] = x7;
  allocp[3] = a1;
  allocp[4] = x8 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  allocp[12] = a10;
  allocp[13] = (q)(struct goalrec*)&allocp[0];
  allocp[14] = (q)(&predicate_adg_xappend__tavd__iarg_18);
  x9 = arg(x0, 3);
  allocp[15] = x9;
  allocp[16] = x10 = makeref(&allocp[16]);
  allocp[17] = x11 = makeref(&allocp[17]);
  allocp[18] = x1;
  x12 = arg(x0, 1);
  allocp[19] = x12;
  x13 = arg(x0, 2);
  allocp[20] = x13;
  allocp[21] = x9;
  x14 = arg(x0, 4);
  allocp[22] = x14;
  allocp[23] = x8;
  allocp[24] = a2;
  allocp[25] = a3;
  allocp[26] = a4;
  allocp[27] = a5;
  allocp[28] = a6;
  allocp[29] = a7;
  allocp[30] = a8;
  allocp[31] = a9;
  allocp[32] = a10;
  allocp[33] = (q)(struct goalrec*)&allocp[13];
  allocp[34] = (q)(&predicate_hb_xget__modes_5);
  allocp[35] = a9;
  allocp[36] = x12;
  allocp[37] = x13;
  allocp[38] = x9;
  allocp[39] = x11;
  allocp[40] = (q)(struct goalrec*)&allocp[33];
  allocp[41] = (q)(&predicate_parse__uty_xdecode__goalcall_6);
  allocp[42] = x4;
  allocp[43] = x15 = makeref(&allocp[43]);
  allocp[44] = x16 = makeref(&allocp[44]);
  allocp[45] = x10;
  allocp[46] = x17 = makeref(&allocp[46]);
  allocp[47] = x18 = makeref(&allocp[47]);
  allocp[48] = (q)(struct goalrec*)&allocp[40];
  allocp[49] = (q)(&predicate_parse__uty_xget__goal_6);
  allocp[50] = x4;
  allocp[51] = x6;
  x19 = arg(x1, 3);
  allocp[52] = x19;
  allocp[53] = makesym(atom_body);
  allocp[54] = x16;
  allocp[55] = a10;
  qp = (struct goalrec*)&allocp[48];
  allocp += 56;
  proceed();
 append__tavd_11_10:
  deref_and_jump(x5,append__tavd_11_9);
  *reasonp++ =  x5;
  goto append__tavd_11_14;
 append__tavd_11_11:
  deref_and_jump(x5,append__tavd_11_8);
  *reasonp++ =  x5;
  goto append__tavd_11_14;
 append__tavd_11_12:
  deref_and_jump(x3,append__tavd_11_7);
  *reasonp++ =  x3;
  goto append__tavd_11_14;
 append__tavd_11_13:
  deref_and_jump(x3,append__tavd_11_6);
  *reasonp++ =  x3;
  goto append__tavd_11_14;
 case VARREF:
  deref_and_jump(a1,append__tavd_11_5);
  *reasonp++ =  a1;
  goto append__tavd_11_14;
  };
  goto append__tavd_11_14;
 case VARREF:
  deref_and_jump(x2,append__tavd_11_4);
  *reasonp++ =  x2;
  goto append__tavd_11_14;
  };
  goto append__tavd_11_14;
 case VARREF:
  deref_and_jump(x1,append__tavd_11_3);
  *reasonp++ =  x1;
  goto append__tavd_11_14;
  };
  goto append__tavd_11_14;
 case VARREF:
  deref_and_jump(x0,append__tavd_11_2);
  *reasonp++ =  x0;
  goto append__tavd_11_14;
  };
  goto append__tavd_11_14;
 case VARREF:
  deref_and_jump(a0,append__tavd_11_1);
  *reasonp++ =  a0;
  goto append__tavd_11_14;
  };
  goto append__tavd_11_14;
 append__tavd_11_14:
  otherwise(append__tavd_11_interrupt);
 append__tavd_11_15:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(append__tavd_11_0);
  goto append__tavd_11_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto append__tavd_11_interrupt;
  x0 = NILATOM;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,append__tavd_11_15);
  *reasonp++ =  a0;
  goto append__tavd_11_interrupt;
  };
  goto append__tavd_11_interrupt;
 append__tavd_11_ext_interrupt:
  reasonp = 0l;
 append__tavd_11_interrupt:
  toppred = &predicate_adg_xappend__tavd_11;
  goto interrupt_11;
 }

 append__tavd__iarg_18_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  qp = qp->next;
 append__tavd__iarg_18_clear_reason:
  reasonp = reasons;
 append__tavd__iarg_18_0:
 append__tavd__iarg_18_1:
  if (!isint(a0)) goto append__tavd__iarg_18_8;
  x0 = makeint(0L);
  gblt_greater(a0,x0,append__tavd__iarg_18_9);
 append__tavd__iarg_18_2:
  if (isref(a2)) goto append__tavd__iarg_18_7;
  gblt_arg(a0,a2,x1,append__tavd__iarg_18_9);
 append__tavd__iarg_18_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_i)) goto append__tavd__iarg_18_9;
 append__tavd__iarg_18_4:
  if (isref(a1)) goto append__tavd__iarg_18_6;
  gblt_arg(a0,a1,x2,append__tavd__iarg_18_9);
 append__tavd__iarg_18_5:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_variable_3)) goto append__tavd__iarg_18_9;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = x4 = makeref(&allocp[1]);
  allocp[2] = x5 = makeref(&allocp[2]);
  allocp[3] = x6 = makeref(&allocp[3]);
  allocp[4] = x7 = makeref(&allocp[4]);
  x3 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a3, x3);
  allocp[0] = makesym(functor_ad_5);
  allocp[1] = a3;
  allocp[2] = a4;
  allocp[3] = a5;
  allocp[4] = a6;
  allocp[5] = a0;
  x8 = makefunctor(&allocp[0]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_adg_xappend__tavd__iarg_18);
  allocp[8] = x9 = makeref(&allocp[8]);
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  allocp[12] = a4;
  allocp[13] = a5;
  allocp[14] = a6;
  allocp[15] = a7;
  allocp[16] = x10 = makeref(&allocp[16]);
  allocp[17] = a9;
  allocp[18] = a10;
  allocp[19] = a11;
  allocp[20] = a12;
  allocp[21] = a13;
  allocp[22] = a14;
  allocp[23] = a15;
  allocp[24] = a16;
  allocp[25] = a17;
  allocp[26] = (q)(struct goalrec*)&allocp[6];
  allocp[27] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[28] = a0;
  allocp[29] = makeint(1L);
  allocp[30] = x9;
  allocp[31] = makesym(functor_vd_2);
  allocp[32] = x8;
  allocp[33] = x12 = makeref(&allocp[33]);
  x11 = makefunctor(&allocp[31]);
  allocp[34] = a8;
  allocp[35] = x11;
  x13 = makecons(&allocp[34]);
  qp = (struct goalrec*)&allocp[26];
  allocp += 36;
  unify_value(x10, x13);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xexpand__vd_11);
  allocp[2] = x8;
  allocp[3] = x14 = makeref(&allocp[3]);
  allocp[4] = x12;
  allocp[5] = a10;
  allocp[6] = a11;
  allocp[7] = a12;
  allocp[8] = a13;
  allocp[9] = a14;
  allocp[10] = a15;
  allocp[11] = a16;
  allocp[12] = a17;
  allocp[13] = makesym(functor_v_3);
  allocp[14] = x4;
  allocp[15] = x5;
  x16 = arg(x2, 0);
  allocp[16] = x16;
  x15 = makefunctor(&allocp[13]);
  allocp[17] = (q)(struct goalrec*)&allocp[0];
  allocp[18] = (q)(&predicate_adg_xtavd__make__vd_3);
  allocp[19] = x17 = makeref(&allocp[19]);
  allocp[20] = x15;
  allocp[21] = x14;
  allocp[22] = (q)(struct goalrec*)&allocp[17];
  allocp[23] = (q)(&predicate_typeset_xget_5);
  allocp[24] = x4;
  allocp[25] = x5;
  x18 = arg(x2, 0);
  allocp[26] = x18;
  allocp[27] = x17;
  allocp[28] = a15;
  qp = (struct goalrec*)&allocp[22];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(x2,append__tavd__iarg_18_5);
  *reasonp++ =  x2;
  goto append__tavd__iarg_18_9;
  };
  goto append__tavd__iarg_18_9;
 append__tavd__iarg_18_6:
  deref_and_jump(a1,append__tavd__iarg_18_4);
  *reasonp++ =  a1;
  goto append__tavd__iarg_18_9;
 case VARREF:
  deref_and_jump(x1,append__tavd__iarg_18_3);
  *reasonp++ =  x1;
  goto append__tavd__iarg_18_9;
  };
  goto append__tavd__iarg_18_9;
 append__tavd__iarg_18_7:
  deref_and_jump(a2,append__tavd__iarg_18_2);
  *reasonp++ =  a2;
  goto append__tavd__iarg_18_9;
 append__tavd__iarg_18_8:
  if (!isref(a0)) goto append__tavd__iarg_18_9;
  deref_and_jump(a0,append__tavd__iarg_18_1);
  *reasonp++ =  a0;
  goto append__tavd__iarg_18_9;
 append__tavd__iarg_18_9:
  otherwise(append__tavd__iarg_18_interrupt);
 append__tavd__iarg_18_10:
  if (!isint(a0)) goto append__tavd__iarg_18_17;
  x0 = makeint(0L);
  gblt_greater(a0,x0,append__tavd__iarg_18_16);
 append__tavd__iarg_18_11:
  if (isref(a2)) goto append__tavd__iarg_18_15;
  gblt_arg(a0,a2,x1,append__tavd__iarg_18_16);
 append__tavd__iarg_18_12:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (isint(x1)) goto append__tavd__iarg_18_16;
  switch (symval(x1)) {
 case symval(makesym(atom_i)):
 append__tavd__iarg_18_13:
  if (isref(a1)) goto append__tavd__iarg_18_14;
  gblt_arg(a0,a1,x2,append__tavd__iarg_18_16);
  x3 = makeint(1L);
  bblt_sub_no_check(a0,x3,x4);
  a0 = x4;
  execute(append__tavd__iarg_18_0);
  goto append__tavd__iarg_18_ext_interrupt;
 append__tavd__iarg_18_14:
  deref_and_jump(a1,append__tavd__iarg_18_13);
  *reasonp++ =  a1;
  goto append__tavd__iarg_18_16;
 case symval(makesym(atom_o)):
  x2 = makeint(1L);
  bblt_sub_no_check(a0,x2,x3);
  a0 = x3;
  execute(append__tavd__iarg_18_0);
  goto append__tavd__iarg_18_ext_interrupt;
  };
  goto append__tavd__iarg_18_16;
 case VARREF:
  deref_and_jump(x1,append__tavd__iarg_18_12);
  *reasonp++ =  x1;
  goto append__tavd__iarg_18_16;
  };
  goto append__tavd__iarg_18_16;
 append__tavd__iarg_18_15:
  deref_and_jump(a2,append__tavd__iarg_18_11);
  *reasonp++ =  a2;
  goto append__tavd__iarg_18_16;
 append__tavd__iarg_18_16:
  if (a0 != makeint(0L)) goto append__tavd__iarg_18_interrupt;
  unify(a9, a8);
  proceed();
 append__tavd__iarg_18_17:
  if (!isref(a0)) goto append__tavd__iarg_18_interrupt;
  deref_and_jump(a0,append__tavd__iarg_18_10);
  *reasonp++ =  a0;
  goto append__tavd__iarg_18_interrupt;
 append__tavd__iarg_18_ext_interrupt:
  reasonp = 0l;
 append__tavd__iarg_18_interrupt:
  goto interrupt_18;
 }

 tavd__make__vd_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  qp = qp->next;
 tavd__make__vd_3_clear_reason:
  reasonp = reasons;
 tavd__make__vd_3_0:
 tavd__make__vd_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 tavd__make__vd_3_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto tavd__make__vd_3_interrupt;
  a0 = cdr_of(a0);
  execute(tavd__make__vd_3_0);
  goto tavd__make__vd_3_ext_interrupt;
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_2)) goto tavd__make__vd_3_interrupt;
  allocp[0] = makesym(functor_ti_2);
  allocp[1] = a1;
  x2 = arg(x0, 0);
  allocp[2] = x2;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = NILATOM;
  allocp[4] = x1;
  x3 = makecons(&allocp[3]);
  allocp[5] = makesym(functor_to_2);
  x5 = arg(x0, 0);
  allocp[6] = x5;
  allocp[7] = x3;
  x4 = makefunctor(&allocp[5]);
  allocp[8] = x7 = makeref(&allocp[8]);
  allocp[9] = x4;
  x6 = makecons(&allocp[8]);
  allocp += 10;
  unify_value(a2, x6);
  a0 = cdr_of(a0);
  a2 = x7;
  execute(tavd__make__vd_3_0);
  goto tavd__make__vd_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,tavd__make__vd_3_2);
  *reasonp++ =  x0;
  goto tavd__make__vd_3_interrupt;
  };
  goto tavd__make__vd_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto tavd__make__vd_3_interrupt;
  x0 = NILATOM;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,tavd__make__vd_3_1);
  *reasonp++ =  a0;
  goto tavd__make__vd_3_interrupt;
  };
  goto tavd__make__vd_3_interrupt;
 tavd__make__vd_3_ext_interrupt:
  reasonp = 0l;
 tavd__make__vd_3_interrupt:
  goto interrupt_3;
 }

 get__vars__in__struct_4_top: {
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 get__vars__in__struct_4_clear_reason:
  reasonp = reasons;
 get__vars__in__struct_4_0:
  a4 = a3;
  a3 = NILATOM;
  execute(get__vars__in__struct_5_0);
  goto get__vars__in__struct_5_ext_interrupt;
 get__vars__in__struct_4_ext_interrupt:
  reasonp = 0l;
 get__vars__in__struct_4_interrupt:
  toppred = &predicate_adg_xget__vars__in__struct_4;
  goto interrupt_4;
 }

 get__vars__in__struct_5_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 get__vars__in__struct_5_clear_reason:
  reasonp = reasons;
 get__vars__in__struct_5_0:
 get__vars__in__struct_5_1:
  switch (ptagof(a2)) {
 case FUNCTOR:
  switch (symval(functor_of(a2))) {
 case functor_variable_3:
  allocp[0] = makesym(functor_v_3);
  allocp[1] = a0;
  allocp[2] = a1;
  x1 = arg(a2, 0);
  allocp[3] = x1;
  x0 = makefunctor(&allocp[0]);
  allocp[4] = a3;
  allocp[5] = x0;
  x2 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a4, x2);
  proceed();
 case functor_list_1:
  x0 = arg(a2, 0);
 get__vars__in__struct_5_2:
  switch (ptagof(x0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xget__vars__in__struct_5);
  allocp[2] = a0;
  allocp[3] = a1;
  x1 = cdr_of(x0);
  allocp[4] = x1;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  a2 = car_of(x0);
  a4 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(get__vars__in__struct_5_0);
  goto get__vars__in__struct_5_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,get__vars__in__struct_5_2);
  *reasonp++ =  x0;
  goto get__vars__in__struct_5_5;
  };
  goto get__vars__in__struct_5_5;
 case functor_functor_1:
  x0 = arg(a2, 0);
 get__vars__in__struct_5_3:
  if (isref(x0)) goto get__vars__in__struct_5_4;
  gblt_pfunctor(x0,x1,get__vars__in__struct_5_5);
  if (x1 != makesym(atom_functor)) goto get__vars__in__struct_5_5;
  gblt_arity(x0,x2,get__vars__in__struct_5_5);
  x3 = a0;
  a2 = a1;
  x4 = a3;
  a5 = a4;
  a4 = x4;
  a3 = x0;
  a1 = x3;
  a0 = x2;
  execute(get__vars__in__struct__struct_6_0);
  goto get__vars__in__struct__struct_6_ext_interrupt;
 get__vars__in__struct_5_4:
  deref_and_jump(x0,get__vars__in__struct_5_3);
  *reasonp++ =  x0;
  goto get__vars__in__struct_5_5;
  };
  goto get__vars__in__struct_5_5;
 case VARREF:
  deref_and_jump(a2,get__vars__in__struct_5_1);
  *reasonp++ =  a2;
  goto get__vars__in__struct_5_5;
  };
  goto get__vars__in__struct_5_5;
 get__vars__in__struct_5_5:
  otherwise(get__vars__in__struct_5_interrupt);
  unify(a4, a3);
  proceed();
 get__vars__in__struct_5_ext_interrupt:
  reasonp = 0l;
 get__vars__in__struct_5_interrupt:
  toppred = &predicate_adg_xget__vars__in__struct_5;
  goto interrupt_5;
 }

 get__vars__in__struct__struct_6_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 get__vars__in__struct__struct_6_clear_reason:
  reasonp = reasons;
 get__vars__in__struct__struct_6_0:
 get__vars__in__struct__struct_6_1:
  if (!isint(a0)) goto get__vars__in__struct__struct_6_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,get__vars__in__struct__struct_6_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_adg_xget__vars__in__struct__struct_6);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[10] = a0;
  allocp[11] = makeint(1L);
  allocp[12] = x1;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_adg_xget__vars__in__struct_5);
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = x3 = makeref(&allocp[17]);
  allocp[18] = a4;
  allocp[19] = x2;
  allocp[20] = (q)(struct goalrec*)&allocp[13];
  allocp[21] = (q)(&predicate_functor__table_xarg_3);
  allocp[22] = a0;
  allocp[23] = a3;
  allocp[24] = x3;
  qp = (struct goalrec*)&allocp[20];
  allocp += 25;
  proceed();
 get__vars__in__struct__struct_6_2:
  if (a0 != makeint(0L)) goto get__vars__in__struct__struct_6_interrupt;
  unify(a5, a4);
  proceed();
 get__vars__in__struct__struct_6_3:
  if (!isref(a0)) goto get__vars__in__struct__struct_6_interrupt;
  deref_and_jump(a0,get__vars__in__struct__struct_6_1);
  *reasonp++ =  a0;
  goto get__vars__in__struct__struct_6_interrupt;
 get__vars__in__struct__struct_6_ext_interrupt:
  reasonp = 0l;
 get__vars__in__struct__struct_6_interrupt:
  toppred = &predicate_adg_xget__vars__in__struct__struct_6;
  goto interrupt_6;
 }
 interrupt_22:
  allocp[23] = a21;
 interrupt_21:
  allocp[22] = a20;
 interrupt_20:
  allocp[21] = a19;
 interrupt_19:
  allocp[20] = a18;
 interrupt_18:
  allocp[19] = a17;
 interrupt_17:
  allocp[18] = a16;
 interrupt_16:
  allocp[17] = a15;
 interrupt_15:
  allocp[16] = a14;
 interrupt_14:
  allocp[15] = a13;
 interrupt_13:
  allocp[14] = a12;
 interrupt_12:
  allocp[13] = a11;
 interrupt_11:
  allocp[12] = a10;
 interrupt_10:
  allocp[11] = a9;
 interrupt_9:
  allocp[10] = a8;
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_adg);
}
