/*
  Copyright 1994, 1995 Institute for New Generation Computer Technology
  Read COPYRIGHT for detailed information

  KLIC System Configuration Setting
  This file was created by KLIC configuration script.
  Date of Confuguration: Wed Jun 28 16:51:50 JST 1995
  Configured by: fujise
*/

/* CPU name for locking shared-memory parallel */

#define Unknown_cpu

/* Directories for installation */

#define KLICBIN "/home2/fujise/test/bin"
#define KLICLIB "/home2/fujise/test/lib"
#define KLICINCLUDE "/home2/fujise/test/include"
#define KLIC_COMPILER "/home2/fujise/test/lib/klic/kl1cmp"
#define KLIC_DBMAKER "/home2/fujise/test/lib/klic/klicdb"

/* Laguage and program processing systems */

#define CC "gcc"
#define LD "gcc"
#define RANLIB "ranlib"

/* Additional CC flags for optimized compilation of KL1 programs */

#define UOPTFLAGS "-fomit-frame-pointer"

/* Additional flags for LD */

#define LIBRARIES "-lklic -L/usr/local/lib -L/usr/lib -L/lib   -lm -lnsl"
#define LIBRARIES_T "-lklict -L/usr/local/lib -L/usr/lib -L/lib   -lm -lnsl"
#define LIBRARIES_D "-lklicd -L/usr/local/lib -L/usr/lib -L/lib   -lm -lnsl"
#define LIBRARIES_S "-lklics -L/usr/local/lib -L/usr/lib -L/lib   -lm -lnsl"
#define KLIC_CC_OPTIONS "-pipe"
#define KLIC_LD_OPTIONS ""

/* Usual C macros depending on availability */

#define ASYNCIO
#define STRINGH
#define STDDEFH
#define SETLINEBUF
#define USELOCKF
#define USESIG
#define GETRUSAGE
#define USEBCMP
#define USEBCOPY
#define USEBZERO
#define USESTRCHR
#define USEUSLEEP
#define USEULIMIT
#define USEGETDTABLESIZE
#define USETIMER
#define NRAND48
#undef USESTREAMINCLUDEDIR
#undef USEPROCBIND
#undef XTERM

#ifdef USEBCMP
#define BCMP(x,y,len)		bcmp(x,y,len)
#else
#define BCMP(x,y,len)		memcmp(x,y,len)
#endif

#ifdef USEBCOPY
#define BCOPY(from,to,len)	bcopy(from,to,len)
#else
#define BCOPY(from,to,len)	memcpy(to,from,len)
#endif

#ifdef USEBZERO
#define BZERO(from,len)		bzero(from,len)
#else
#define BZERO(from,len)		memset(from,0,len)
#endif

#ifdef USESTRCHR
#define STRCHR			strchr
#else
#define STRCHR			index
#endif
