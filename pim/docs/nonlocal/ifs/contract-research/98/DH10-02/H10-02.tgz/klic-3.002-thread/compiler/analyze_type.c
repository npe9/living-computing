/* Compiled by KLIC compiler version 3.002 (Wed Sep 17 15:37:13 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_analyze__type();
Const struct predicate predicate_analyze__type_xmain_8 =
   { module_analyze__type, 0, 8 };
Const struct predicate predicate_analyze__type_xappend__direct__value_3 =
   { module_analyze__type, 1, 3 };
Const struct predicate predicate_analyze__type_xappend__clauses_4 =
   { module_analyze__type, 2, 4 };
Const struct predicate predicate_analyze__type_xappend__clause_5 =
   { module_analyze__type, 3, 5 };
Const struct predicate predicate_analyze__type_xappend__to__uv_5 =
   { module_analyze__type, 4, 5 };
Const struct predicate predicate_analyze__type_xmake__typeset_2 =
   { module_analyze__type, 5, 2 };
Const struct predicate predicate_analyze__type_xmake__typeset_4 =
   { module_analyze__type, 6, 4 };
Const struct predicate predicate_analyze__type_xcheck__vars_2 =
   { module_analyze__type, 7, 2 };
Const struct predicate predicate_analyze__type_xdetermine__typeset_6 =
   { module_analyze__type, 8, 6 };
Const struct predicate predicate_analyze__type_xinterclause__modules_15 =
   { module_analyze__type, 9, 15 };
Const struct predicate predicate_analyze__type_xinterclause__clauses_18 =
   { module_analyze__type, 10, 18 };
Const struct predicate predicate_analyze__type_xinterclause__clause_17 =
   { module_analyze__type, 11, 17 };
Const struct predicate predicate_analyze__type_xset__typeset_16 =
   { module_analyze__type, 12, 16 };
Const struct predicate predicate_analyze__type_xset__goals__typeset_15 =
   { module_analyze__type, 13, 15 };
Const struct predicate predicate_analyze__type_xset__goals__typeset_16 =
   { module_analyze__type, 14, 16 };
Const struct predicate predicate_analyze__type_xset__goal__typeset_16 =
   { module_analyze__type, 15, 16 };
Const struct predicate predicate_analyze__type_xset__goal__typeset1_18 =
   { module_analyze__type, 16, 18 };
Const struct predicate predicate_analyze__type_xset__arg__typeset_11 =
   { module_analyze__type, 17, 11 };
Const struct predicate predicate_analyze__type_xdetermine__typeset1_6 =
   { module_analyze__type, 18, 6 };
Const struct predicate predicate_analyze__type_xanalyze__typeset_7 =
   { module_analyze__type, 19, 7 };
Const struct predicate predicate_analyze__type_xanalyze__clause__typeset_7 =
   { module_analyze__type, 20, 7 };
Const struct predicate predicate_analyze__type_xapply__goals__typeset_8 =
   { module_analyze__type, 21, 8 };
Const struct predicate predicate_analyze__type_xapply__goals__type_9 =
   { module_analyze__type, 22, 9 };
Const struct predicate predicate_analyze__type_xapply__goal__typeset_9 =
   { module_analyze__type, 23, 9 };
Const struct predicate predicate_analyze__type_xapply__goal__type_11 =
   { module_analyze__type, 24, 11 };
Const struct predicate predicate_analyze__type_xapply__goal__type2_13 =
   { module_analyze__type, 25, 13 };
Const struct predicate predicate_analyze__type_xget__call__modulename_3 =
   { module_analyze__type, 26, 3 };
Const struct predicate predicate_analyze__type_xapply__typeset_15 =
   { module_analyze__type, 27, 15 };
Const struct predicate predicate_analyze__type_xcheck__args_4 =
   { module_analyze__type, 28, 4 };
Const struct predicate predicate_analyze__type_xcheck__args2_5 =
   { module_analyze__type, 29, 5 };
Const struct predicate predicate_analyze__type_xapply__typeset__equal_16 =
   { module_analyze__type, 30, 16 };
Const struct predicate predicate_analyze__type_xuserdef__typeset_9 =
   { module_analyze__type, 31, 9 };
Const struct predicate predicate_analyze__type_xindirect__unify_6 =
   { module_analyze__type, 32, 6 };
Const struct predicate predicate_analyze__type_xindirect__unify__clauses_10 =
   { module_analyze__type, 33, 10 };
Const struct predicate predicate_analyze__type_xindirect__unify__clause_9 =
   { module_analyze__type, 34, 9 };
Const struct predicate predicate_analyze__type_xindirect__unify__goals_10 =
   { module_analyze__type, 35, 10 };
Const struct predicate predicate_analyze__type_xindirect__unify__goals_12 =
   { module_analyze__type, 36, 12 };
Const struct predicate predicate_analyze__type_xindirect__unify__goal_11 =
   { module_analyze__type, 37, 11 };
Const struct predicate predicate_analyze__type_xindirect__unify__args_14 =
   { module_analyze__type, 38, 14 };
Const struct predicate predicate_analyze__type_xindirect__unify__args2_14 =
   { module_analyze__type, 39, 14 };
Const struct predicate predicate_analyze__type_xdetermine__typeset2_14 =
   { module_analyze__type, 40, 14 };
Const struct predicate predicate_analyze__type_xindirect__unify1_17 =
   { module_analyze__type, 41, 17 };
extern Const struct predicate predicate_list_xappend_3;
extern Const struct predicate predicate_builtin_xmake__typeset_14;
extern Const struct predicate predicate_integer__arithmetics_xadd_3;
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_xfunctor_3;
extern Const struct predicate predicate_typeset__ex_xextend__typeset_4;
extern Const struct predicate predicate_typeset_xget_5;
extern Const struct predicate predicate_typeset_xvalue2typeset_5;
extern Const struct predicate predicate_typeset_xor__typeset_3;
extern Const struct predicate predicate_typeset_xmake__shared__ts_8;
extern Const struct predicate predicate_typeset_xset_12;
extern Const struct predicate predicate_typeset_xadd__dgoal_4;
extern Const struct predicate predicate_parse__uty_xget__info_7;
extern Const struct predicate predicate_parse__uty_xdecode__goalcall_6;
extern Const struct predicate predicate_parse__uty_xdecode__goal_4;
extern Const struct predicate predicate_hb_xget__typeset_12;
extern Const struct predicate predicate_hb_xwrite__mode_7;
extern Const struct predicate predicate_vt_xread__iu_5;

module module_analyze__type(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  static Const q cons_const_0[] = {
    NILATOM,
    makesym(atom__2A),
  };
  q a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, main_8_top);
    case_pred(1, append__direct__value_3_top);
    case_pred(2, append__clauses_4_top);
    case_pred(3, append__clause_5_top);
    case_pred(4, append__to__uv_5_top);
    case_pred(5, make__typeset_2_top);
    case_pred(6, make__typeset_4_top);
    case_pred(7, check__vars_2_top);
    case_pred(8, determine__typeset_6_top);
    case_pred(9, interclause__modules_15_top);
    case_pred(10, interclause__clauses_18_top);
    case_pred(11, interclause__clause_17_top);
    case_pred(12, set__typeset_16_top);
    case_pred(13, set__goals__typeset_15_top);
    case_pred(14, set__goals__typeset_16_top);
    case_pred(15, set__goal__typeset_16_top);
    case_pred(16, set__goal__typeset1_18_top);
    case_pred(17, set__arg__typeset_11_top);
    case_pred(18, determine__typeset1_6_top);
    case_pred(19, analyze__typeset_7_top);
    case_pred(20, analyze__clause__typeset_7_top);
    case_pred(21, apply__goals__typeset_8_top);
    case_pred(22, apply__goals__type_9_top);
    case_pred(23, apply__goal__typeset_9_top);
    case_pred(24, apply__goal__type_11_top);
    case_pred(25, apply__goal__type2_13_top);
    case_pred(26, get__call__modulename_3_top);
    case_pred(27, apply__typeset_15_top);
    case_pred(28, check__args_4_top);
    case_pred(29, check__args2_5_top);
    case_pred(30, apply__typeset__equal_16_top);
    case_pred(31, userdef__typeset_9_top);
    case_pred(32, indirect__unify_6_top);
    case_pred(33, indirect__unify__clauses_10_top);
    case_pred(34, indirect__unify__clause_9_top);
    case_pred(35, indirect__unify__goals_10_top);
    case_pred(36, indirect__unify__goals_12_top);
    case_pred(37, indirect__unify__goal_11_top);
    case_pred(38, indirect__unify__args_14_top);
    case_pred(39, indirect__unify__args2_14_top);
    case_pred(40, determine__typeset2_14_top);
    last_case_pred(41, indirect__unify1_17_top);
  }

 main_8_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 main_8_clear_reason:
  reasonp = reasons;
 main_8_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset__ex_xextend__typeset_4);
  allocp[2] = a0;
  allocp[3] = a7;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_analyze__type_xdetermine__typeset_6);
  allocp[8] = a5;
  allocp[9] = a0;
  allocp[10] = a2;
  allocp[11] = x0;
  allocp[12] = a6;
  allocp[13] = a7;
  a0 = a6;
  a1 = a4;
  a2 = a5;
  qp = (struct goalrec*)&allocp[6];
  allocp += 14;
  execute(append__direct__value_3_0);
  goto append__direct__value_3_ext_interrupt;
 main_8_ext_interrupt:
  reasonp = 0l;
 main_8_interrupt:
  goto interrupt_8;
 }

 append__direct__value_3_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  qp = qp->next;
 append__direct__value_3_clear_reason:
  reasonp = reasons;
 append__direct__value_3_0:
 append__direct__value_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 append__direct__value_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto append__direct__value_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xappend__direct__value_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  a0 = arg(x0, 0);
  x3 = arg(x0, 1);
  a2 = a1;
  a3 = x2;
  a1 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(append__clauses_4_0);
  goto append__clauses_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,append__direct__value_3_2);
  *reasonp++ =  x0;
  goto append__direct__value_3_interrupt;
  };
  goto append__direct__value_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto append__direct__value_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,append__direct__value_3_1);
  *reasonp++ =  a0;
  goto append__direct__value_3_interrupt;
  };
  goto append__direct__value_3_interrupt;
 append__direct__value_3_ext_interrupt:
  reasonp = 0l;
 append__direct__value_3_interrupt:
  toppred = &predicate_analyze__type_xappend__direct__value_3;
  goto interrupt_3;
 }

 append__clauses_4_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 append__clauses_4_clear_reason:
  reasonp = reasons;
 append__clauses_4_0:
 append__clauses_4_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 append__clauses_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_7)) goto append__clauses_4_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xappend__clauses_4);
  allocp[2] = a0;
  x1 = cdr_of(a1);
  allocp[3] = x1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = makesym(functor_pred_3);
  allocp[7] = a0;
  x4 = arg(x0, 0);
  allocp[8] = x4;
  x5 = arg(x0, 1);
  allocp[9] = x5;
  x3 = makefunctor(&allocp[6]);
  a0 = x3;
  a1 = arg(x0, 1);
  x6 = arg(x0, 4);
  a3 = a2;
  a4 = x2;
  a2 = x6;
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  execute(append__clause_5_0);
  goto append__clause_5_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,append__clauses_4_2);
  *reasonp++ =  x0;
  goto append__clauses_4_interrupt;
  };
  goto append__clauses_4_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto append__clauses_4_interrupt;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a1,append__clauses_4_1);
  *reasonp++ =  a1;
  goto append__clauses_4_interrupt;
  };
  goto append__clauses_4_interrupt;
 append__clauses_4_ext_interrupt:
  reasonp = 0l;
 append__clauses_4_interrupt:
  toppred = &predicate_analyze__type_xappend__clauses_4;
  goto interrupt_4;
 }

 append__clause_5_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 append__clause_5_clear_reason:
  reasonp = reasons;
 append__clause_5_0:
 append__clause_5_1:
  if (!isint(a1)) goto append__clause_5_3;
  x0 = makeint(0L);
  gblt_greater(a1,x0,append__clause_5_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xappend__clause_5);
  allocp[2] = a0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[9] = a1;
  allocp[10] = makeint(1L);
  allocp[11] = x1;
  allocp[12] = (q)(struct goalrec*)&allocp[7];
  allocp[13] = (q)(&predicate_analyze__type_xappend__to__uv_5);
  allocp[14] = a0;
  allocp[15] = x3 = makeref(&allocp[15]);
  allocp[16] = a1;
  allocp[17] = a3;
  allocp[18] = x2;
  allocp[19] = (q)(struct goalrec*)&allocp[12];
  allocp[20] = (q)(&predicate_analyze__type_xcheck__vars_2);
  allocp[21] = x4 = makeref(&allocp[21]);
  allocp[22] = x3;
  allocp[23] = (q)(struct goalrec*)&allocp[19];
  allocp[24] = (q)(&predicate_analyze__type_xmake__typeset_2);
  allocp[25] = x5 = makeref(&allocp[25]);
  allocp[26] = x4;
  allocp[27] = (q)(struct goalrec*)&allocp[23];
  allocp[28] = (q)(&predicate_functor__table_xarg_3);
  allocp[29] = a1;
  allocp[30] = a2;
  allocp[31] = x5;
  qp = (struct goalrec*)&allocp[27];
  allocp += 32;
  proceed();
 append__clause_5_2:
  if (a1 != makeint(0L)) goto append__clause_5_interrupt;
  unify(a4, a3);
  proceed();
 append__clause_5_3:
  if (!isref(a1)) goto append__clause_5_interrupt;
  deref_and_jump(a1,append__clause_5_1);
  *reasonp++ =  a1;
  goto append__clause_5_interrupt;
 append__clause_5_ext_interrupt:
  reasonp = 0l;
 append__clause_5_interrupt:
  toppred = &predicate_analyze__type_xappend__clause_5;
  goto interrupt_5;
 }

 append__to__uv_5_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 append__to__uv_5_clear_reason:
  reasonp = reasons;
 append__to__uv_5_0:
 append__to__uv_5_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 append__to__uv_5_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto append__to__uv_5_4;
  x1 = cdr_of(a1);
 append__to__uv_5_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto append__to__uv_5_4;
  unify(a4, a3);
  proceed();
 case VARREF:
  deref_and_jump(x1,append__to__uv_5_3);
  *reasonp++ =  x1;
  goto append__to__uv_5_4;
  };
  goto append__to__uv_5_4;
 case VARREF:
  deref_and_jump(x0,append__to__uv_5_2);
  *reasonp++ =  x0;
  goto append__to__uv_5_4;
  };
  goto append__to__uv_5_4;
 case VARREF:
  deref_and_jump(a1,append__to__uv_5_1);
  *reasonp++ =  a1;
  goto append__to__uv_5_4;
  };
  goto append__to__uv_5_4;
 append__to__uv_5_4:
  otherwise(append__to__uv_5_interrupt);
  allocp[0] = makesym(functor_pred_3);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a0, x0);
  allocp[0] = makesym(functor_userdef_5);
  allocp[1] = x1;
  allocp[2] = x2;
  allocp[3] = x3;
  allocp[4] = a2;
  allocp[5] = makesym(atom__2B);
  x4 = makefunctor(&allocp[0]);
  allocp[6] = NILATOM;
  allocp[7] = x4;
  x5 = makecons(&allocp[6]);
  allocp[8] = (q)qp;
  allocp[9] = (q)(&predicate_list_xappend_3);
  allocp[10] = a3;
  allocp[11] = x5;
  allocp[12] = a4;
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  proceed();
 append__to__uv_5_ext_interrupt:
  reasonp = 0l;
 append__to__uv_5_interrupt:
  goto interrupt_5;
 }

 make__typeset_2_top: {
  q x0, x1;
  qp = qp->next;
 make__typeset_2_clear_reason:
  reasonp = reasons;
 make__typeset_2_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xmake__typeset_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = NILATOM;
  allocp[5] = a1;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[8] = a0;
  allocp[9] = x1 = makeref(&allocp[9]);
  allocp[10] = x0;
  qp = (struct goalrec*)&allocp[6];
  allocp += 11;
  proceed();
 make__typeset_2_ext_interrupt:
  reasonp = 0l;
 make__typeset_2_interrupt:
  goto interrupt_2;
 }

 make__typeset_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 make__typeset_4_clear_reason:
  reasonp = reasons;
 make__typeset_4_0:
 make__typeset_4_1:
  if (!isint(a0)) goto make__typeset_4_13;
  x0 = makeint(0L);
  gblt_greater(a0,x0,make__typeset_4_14);
 make__typeset_4_2:
  if (isref(a1)) goto make__typeset_4_12;
  gblt_arg(a0,a1,x1,make__typeset_4_14);
 make__typeset_4_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  switch (symval(functor_of(x1))) {
 case functor_arg_2:
  x2 = arg(x1, 0);
 make__typeset_4_4:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_goal_4)) goto make__typeset_4_14;
  x3 = arg(x1, 1);
 make__typeset_4_5:
  switch (ptagof(x3)) {
 case FUNCTOR:
  if (functor_of(x3) != makesym(functor_variable_3)) goto make__typeset_4_14;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xmake__typeset_4);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x5 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x4;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[13] = a2;
  allocp[14] = x6 = makeref(&allocp[14]);
  allocp[15] = x5;
  allocp[16] = makesym(functor_variable_3);
  x8 = arg(x3, 0);
  allocp[17] = x8;
  x9 = arg(x3, 1);
  allocp[18] = x9;
  allocp[19] = makesym(atom_i);
  x7 = makefunctor(&allocp[16]);
  allocp[20] = (q)(struct goalrec*)&allocp[11];
  allocp[21] = (q)(&predicate_typeset_xvalue2typeset_5);
  x10 = arg(x2, 0);
  allocp[22] = x10;
  x11 = arg(x2, 1);
  allocp[23] = x11;
  allocp[24] = x7;
  allocp[25] = NILATOM;
  allocp[26] = x6;
  qp = (struct goalrec*)&allocp[20];
  allocp += 27;
  proceed();
 case VARREF:
  deref_and_jump(x3,make__typeset_4_5);
  *reasonp++ =  x3;
  goto make__typeset_4_14;
  };
  goto make__typeset_4_14;
 case VARREF:
  deref_and_jump(x2,make__typeset_4_4);
  *reasonp++ =  x2;
  goto make__typeset_4_14;
  };
  goto make__typeset_4_14;
 case functor_recursivearg_2:
  x2 = arg(x1, 0);
 make__typeset_4_6:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_goal_4)) goto make__typeset_4_14;
  x3 = arg(x1, 1);
 make__typeset_4_7:
  switch (ptagof(x3)) {
 case FUNCTOR:
  if (functor_of(x3) != makesym(functor_variable_3)) goto make__typeset_4_14;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xmake__typeset_4);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x5 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x4;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[13] = a2;
  allocp[14] = x6 = makeref(&allocp[14]);
  allocp[15] = x5;
  allocp[16] = makesym(functor_variable_3);
  x8 = arg(x3, 0);
  allocp[17] = x8;
  x9 = arg(x3, 1);
  allocp[18] = x9;
  allocp[19] = makesym(atom_i);
  x7 = makefunctor(&allocp[16]);
  allocp[20] = (q)(struct goalrec*)&allocp[11];
  allocp[21] = (q)(&predicate_typeset_xvalue2typeset_5);
  x10 = arg(x2, 0);
  allocp[22] = x10;
  x11 = arg(x2, 1);
  allocp[23] = x11;
  allocp[24] = x7;
  allocp[25] = NILATOM;
  allocp[26] = x6;
  qp = (struct goalrec*)&allocp[20];
  allocp += 27;
  proceed();
 case VARREF:
  deref_and_jump(x3,make__typeset_4_7);
  *reasonp++ =  x3;
  goto make__typeset_4_14;
  };
  goto make__typeset_4_14;
 case VARREF:
  deref_and_jump(x2,make__typeset_4_6);
  *reasonp++ =  x2;
  goto make__typeset_4_14;
  };
  goto make__typeset_4_14;
 case functor_entryarg_2:
  x2 = arg(x1, 0);
 make__typeset_4_8:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_goal_4)) goto make__typeset_4_14;
  x3 = arg(x1, 1);
 make__typeset_4_9:
  switch (ptagof(x3)) {
 case FUNCTOR:
  if (functor_of(x3) != makesym(functor_variable_3)) goto make__typeset_4_14;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xmake__typeset_4);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x5 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x4;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[13] = a2;
  allocp[14] = x6 = makeref(&allocp[14]);
  allocp[15] = x5;
  allocp[16] = makesym(functor_variable_3);
  x8 = arg(x3, 0);
  allocp[17] = x8;
  x9 = arg(x3, 1);
  allocp[18] = x9;
  allocp[19] = makesym(atom_i);
  x7 = makefunctor(&allocp[16]);
  allocp[20] = (q)(struct goalrec*)&allocp[11];
  allocp[21] = (q)(&predicate_typeset_xvalue2typeset_5);
  x10 = arg(x2, 0);
  allocp[22] = x10;
  x11 = arg(x2, 1);
  allocp[23] = x11;
  allocp[24] = x7;
  allocp[25] = NILATOM;
  allocp[26] = x6;
  qp = (struct goalrec*)&allocp[20];
  allocp += 27;
  proceed();
 case VARREF:
  deref_and_jump(x3,make__typeset_4_9);
  *reasonp++ =  x3;
  goto make__typeset_4_14;
  };
  goto make__typeset_4_14;
 case VARREF:
  deref_and_jump(x2,make__typeset_4_8);
  *reasonp++ =  x2;
  goto make__typeset_4_14;
  };
  goto make__typeset_4_14;
 case functor_sharedarg_2:
  x2 = arg(x1, 0);
 make__typeset_4_10:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_goal_4)) goto make__typeset_4_14;
  x3 = arg(x1, 1);
 make__typeset_4_11:
  switch (ptagof(x3)) {
 case FUNCTOR:
  if (functor_of(x3) != makesym(functor_variable_3)) goto make__typeset_4_14;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xmake__typeset_4);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x5 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x4;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[13] = a2;
  allocp[14] = x6 = makeref(&allocp[14]);
  allocp[15] = x5;
  allocp[16] = makesym(functor_variable_3);
  x8 = arg(x3, 0);
  allocp[17] = x8;
  x9 = arg(x3, 1);
  allocp[18] = x9;
  allocp[19] = makesym(atom_i);
  x7 = makefunctor(&allocp[16]);
  allocp[20] = (q)(struct goalrec*)&allocp[11];
  allocp[21] = (q)(&predicate_typeset_xvalue2typeset_5);
  x10 = arg(x2, 0);
  allocp[22] = x10;
  x11 = arg(x2, 1);
  allocp[23] = x11;
  allocp[24] = x7;
  allocp[25] = NILATOM;
  allocp[26] = x6;
  qp = (struct goalrec*)&allocp[20];
  allocp += 27;
  proceed();
 case VARREF:
  deref_and_jump(x3,make__typeset_4_11);
  *reasonp++ =  x3;
  goto make__typeset_4_14;
  };
  goto make__typeset_4_14;
 case VARREF:
  deref_and_jump(x2,make__typeset_4_10);
  *reasonp++ =  x2;
  goto make__typeset_4_14;
  };
  goto make__typeset_4_14;
  };
  goto make__typeset_4_14;
 case VARREF:
  deref_and_jump(x1,make__typeset_4_3);
  *reasonp++ =  x1;
  goto make__typeset_4_14;
  };
  goto make__typeset_4_14;
 make__typeset_4_12:
  deref_and_jump(a1,make__typeset_4_2);
  *reasonp++ =  a1;
  goto make__typeset_4_14;
 make__typeset_4_13:
  if (!isref(a0)) goto make__typeset_4_14;
  deref_and_jump(a0,make__typeset_4_1);
  *reasonp++ =  a0;
  goto make__typeset_4_14;
 make__typeset_4_14:
  otherwise(make__typeset_4_interrupt);
 make__typeset_4_15:
  if (!isint(a0)) goto make__typeset_4_24;
  x0 = makeint(0L);
  gblt_greater(a0,x0,make__typeset_4_23);
 make__typeset_4_16:
  if (isref(a1)) goto make__typeset_4_22;
  gblt_arg(a0,a1,x1,make__typeset_4_23);
 make__typeset_4_17:
  switch (ptagof(x1)) {
 case FUNCTOR:
  switch (symval(functor_of(x1))) {
 case functor_arg_2:
  x2 = arg(x1, 0);
 make__typeset_4_18:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_goal_4)) goto make__typeset_4_23;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xmake__typeset_4);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x3;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[13] = a2;
  allocp[14] = x5 = makeref(&allocp[14]);
  allocp[15] = x4;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_typeset_xvalue2typeset_5);
  x6 = arg(x2, 0);
  allocp[18] = x6;
  x7 = arg(x2, 1);
  allocp[19] = x7;
  x8 = arg(x1, 1);
  allocp[20] = x8;
  allocp[21] = NILATOM;
  allocp[22] = x5;
  qp = (struct goalrec*)&allocp[16];
  allocp += 23;
  proceed();
 case VARREF:
  deref_and_jump(x2,make__typeset_4_18);
  *reasonp++ =  x2;
  goto make__typeset_4_23;
  };
  goto make__typeset_4_23;
 case functor_recursivearg_2:
  x2 = arg(x1, 0);
 make__typeset_4_19:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_goal_4)) goto make__typeset_4_23;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xmake__typeset_4);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x3;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[13] = a2;
  allocp[14] = x5 = makeref(&allocp[14]);
  allocp[15] = x4;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_typeset_xvalue2typeset_5);
  x6 = arg(x2, 0);
  allocp[18] = x6;
  x7 = arg(x2, 1);
  allocp[19] = x7;
  x8 = arg(x1, 1);
  allocp[20] = x8;
  allocp[21] = NILATOM;
  allocp[22] = x5;
  qp = (struct goalrec*)&allocp[16];
  allocp += 23;
  proceed();
 case VARREF:
  deref_and_jump(x2,make__typeset_4_19);
  *reasonp++ =  x2;
  goto make__typeset_4_23;
  };
  goto make__typeset_4_23;
 case functor_entryarg_2:
  x2 = arg(x1, 0);
 make__typeset_4_20:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_goal_4)) goto make__typeset_4_23;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xmake__typeset_4);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x3;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[13] = a2;
  allocp[14] = x5 = makeref(&allocp[14]);
  allocp[15] = x4;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_typeset_xvalue2typeset_5);
  x6 = arg(x2, 0);
  allocp[18] = x6;
  x7 = arg(x2, 1);
  allocp[19] = x7;
  x8 = arg(x1, 1);
  allocp[20] = x8;
  allocp[21] = NILATOM;
  allocp[22] = x5;
  qp = (struct goalrec*)&allocp[16];
  allocp += 23;
  proceed();
 case VARREF:
  deref_and_jump(x2,make__typeset_4_20);
  *reasonp++ =  x2;
  goto make__typeset_4_23;
  };
  goto make__typeset_4_23;
 case functor_sharedarg_2:
  x2 = arg(x1, 0);
 make__typeset_4_21:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_goal_4)) goto make__typeset_4_23;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xmake__typeset_4);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x3;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[13] = a2;
  allocp[14] = x5 = makeref(&allocp[14]);
  allocp[15] = x4;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_typeset_xvalue2typeset_5);
  x6 = arg(x2, 0);
  allocp[18] = x6;
  x7 = arg(x2, 1);
  allocp[19] = x7;
  x8 = arg(x1, 1);
  allocp[20] = x8;
  allocp[21] = NILATOM;
  allocp[22] = x5;
  qp = (struct goalrec*)&allocp[16];
  allocp += 23;
  proceed();
 case VARREF:
  deref_and_jump(x2,make__typeset_4_21);
  *reasonp++ =  x2;
  goto make__typeset_4_23;
  };
  goto make__typeset_4_23;
  };
  goto make__typeset_4_23;
 case VARREF:
  deref_and_jump(x1,make__typeset_4_17);
  *reasonp++ =  x1;
  goto make__typeset_4_23;
  };
  goto make__typeset_4_23;
 make__typeset_4_22:
  deref_and_jump(a1,make__typeset_4_16);
  *reasonp++ =  a1;
  goto make__typeset_4_23;
 make__typeset_4_23:
  if (a0 != makeint(0L)) goto make__typeset_4_interrupt;
  unify(a3, a2);
  proceed();
 make__typeset_4_24:
  if (!isref(a0)) goto make__typeset_4_interrupt;
  deref_and_jump(a0,make__typeset_4_15);
  *reasonp++ =  a0;
  goto make__typeset_4_interrupt;
 make__typeset_4_ext_interrupt:
  reasonp = 0l;
 make__typeset_4_interrupt:
  goto interrupt_4;
 }

 check__vars_2_top: {
  q x0, x1, x2;
  qp = qp->next;
 check__vars_2_clear_reason:
  reasonp = reasons;
 check__vars_2_0:
 check__vars_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 check__vars_2_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto check__vars_2_interrupt;
  a0 = cdr_of(a0);
  execute(check__vars_2_0);
  goto check__vars_2_ext_interrupt;
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_tv_2:
  a0 = cdr_of(a0);
  execute(check__vars_2_0);
  goto check__vars_2_ext_interrupt;
 case functor_t_2:
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = x0;
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x1);
  a0 = cdr_of(a0);
  a1 = x2;
  execute(check__vars_2_0);
  goto check__vars_2_ext_interrupt;
  };
  goto check__vars_2_interrupt;
 case VARREF:
  deref_and_jump(x0,check__vars_2_2);
  *reasonp++ =  x0;
  goto check__vars_2_interrupt;
  };
  goto check__vars_2_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto check__vars_2_interrupt;
  x0 = makecons(cons_const_0);
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,check__vars_2_1);
  *reasonp++ =  a0;
  goto check__vars_2_interrupt;
  };
  goto check__vars_2_interrupt;
 check__vars_2_ext_interrupt:
  reasonp = 0l;
 check__vars_2_interrupt:
  goto interrupt_2;
 }

 determine__typeset_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 determine__typeset_6_clear_reason:
  reasonp = reasons;
 determine__typeset_6_0:
 determine__typeset_6_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 determine__typeset_6_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_var_6)) goto determine__typeset_6_5;
  x1 = arg(x0, 2);
 determine__typeset_6_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom___)) goto determine__typeset_6_5;
  x2 = arg(x0, 3);
 determine__typeset_6_4:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != makesym(atom___)) goto determine__typeset_6_5;
  x4 = cdr_of(a0);
  allocp[0] = x4;
  allocp[1] = x5 = makeref(&allocp[1]);
  x3 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_analyze__type_xdetermine__typeset_6);
  allocp[4] = x3;
  allocp[5] = a1;
  allocp[6] = a2;
  allocp[7] = a3;
  allocp[8] = a4;
  allocp[9] = a5;
  allocp[10] = makesym(functor_var_6);
  x7 = arg(x0, 0);
  allocp[11] = x7;
  x8 = arg(x0, 1);
  allocp[12] = x8;
  allocp[13] = x9 = makeref(&allocp[13]);
  allocp[14] = x10 = makeref(&allocp[14]);
  x11 = arg(x0, 4);
  allocp[15] = x11;
  x12 = arg(x0, 5);
  allocp[16] = x12;
  x6 = makefunctor(&allocp[10]);
  qp = (struct goalrec*)&allocp[2];
  allocp += 17;
  unify_value(x5, x6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_parse__uty_xget__info_7);
  x13 = arg(x0, 0);
  allocp[2] = x13;
  x14 = arg(x0, 1);
  allocp[3] = x14;
  allocp[4] = x9;
  allocp[5] = x10;
  x15 = arg(x0, 4);
  allocp[6] = x15;
  x16 = arg(x0, 5);
  allocp[7] = x16;
  allocp[8] = a1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 9;
  proceed();
 case VARREF:
  deref_and_jump(x2,determine__typeset_6_4);
  *reasonp++ =  x2;
  goto determine__typeset_6_5;
  };
  goto determine__typeset_6_5;
 case VARREF:
  deref_and_jump(x1,determine__typeset_6_3);
  *reasonp++ =  x1;
  goto determine__typeset_6_5;
  };
  goto determine__typeset_6_5;
 case VARREF:
  deref_and_jump(x0,determine__typeset_6_2);
  *reasonp++ =  x0;
  goto determine__typeset_6_5;
  };
  goto determine__typeset_6_5;
 case VARREF:
  deref_and_jump(a0,determine__typeset_6_1);
  *reasonp++ =  a0;
  goto determine__typeset_6_5;
  };
  goto determine__typeset_6_5;
 determine__typeset_6_5:
  otherwise(determine__typeset_6_interrupt);
 determine__typeset_6_6:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 determine__typeset_6_7:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_var_6:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xdetermine__typeset1_6);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  a3 = a2;
  a4 = x2;
  a5 = cdr_of(a0);
  a6 = x1;
  a2 = makesym(atom_normal);
  a0 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  execute(analyze__typeset_7_0);
  goto analyze__typeset_7_ext_interrupt;
 case functor_userdef_5:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xdetermine__typeset1_6);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_analyze__type_xinterclause__modules_15);
  allocp[10] = a1;
  x4 = arg(x0, 0);
  allocp[11] = x4;
  x5 = arg(x0, 1);
  allocp[12] = x5;
  x6 = arg(x0, 2);
  allocp[13] = x6;
  x7 = arg(x0, 3);
  allocp[14] = x7;
  allocp[15] = x8 = makeref(&allocp[15]);
  allocp[16] = x9 = makeref(&allocp[16]);
  x10 = arg(x0, 4);
  allocp[17] = x10;
  allocp[18] = makesym(atom_normal);
  allocp[19] = a4;
  allocp[20] = x3;
  allocp[21] = x11 = makeref(&allocp[21]);
  allocp[22] = x2;
  x12 = cdr_of(a0);
  allocp[23] = x12;
  allocp[24] = x1;
  allocp[25] = (q)(struct goalrec*)&allocp[8];
  allocp[26] = (q)(&predicate_hb_xget__typeset_12);
  allocp[27] = a4;
  allocp[28] = x4;
  allocp[29] = x5;
  allocp[30] = x6;
  allocp[31] = x7;
  allocp[32] = x8;
  allocp[33] = x9;
  allocp[34] = x10;
  allocp[35] = a1;
  allocp[36] = makesym(atom_normal);
  allocp[37] = a2;
  allocp[38] = x11;
  qp = (struct goalrec*)&allocp[25];
  allocp += 39;
  proceed();
  };
  goto determine__typeset_6_interrupt;
 case VARREF:
  deref_and_jump(x0,determine__typeset_6_7);
  *reasonp++ =  x0;
  goto determine__typeset_6_interrupt;
  };
  goto determine__typeset_6_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto determine__typeset_6_interrupt;
  unify2(a5, a4, a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,determine__typeset_6_6);
  *reasonp++ =  a0;
  goto determine__typeset_6_interrupt;
  };
  goto determine__typeset_6_interrupt;
 determine__typeset_6_ext_interrupt:
  reasonp = 0l;
 determine__typeset_6_interrupt:
  goto interrupt_6;
 }

 interclause__modules_15_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  qp = qp->next;
 interclause__modules_15_clear_reason:
  reasonp = reasons;
 interclause__modules_15_0:
 interclause__modules_15_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 interclause__modules_15_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto interclause__modules_15_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xinterclause__modules_15);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = x2 = makeref(&allocp[11]);
  allocp[12] = a10;
  allocp[13] = x3 = makeref(&allocp[13]);
  allocp[14] = a12;
  allocp[15] = x4 = makeref(&allocp[15]);
  allocp[16] = a14;
  allocp[17] = (q)(struct goalrec*)&allocp[0];
  allocp[18] = (q)(&predicate_analyze__type_xinterclause__clauses_18);
  allocp[19] = makeint(1L);
  allocp[20] = x5 = makeref(&allocp[20]);
  x6 = arg(x0, 1);
  allocp[21] = x6;
  x7 = arg(x0, 0);
  allocp[22] = x7;
  allocp[23] = a1;
  allocp[24] = a2;
  allocp[25] = a3;
  allocp[26] = a4;
  allocp[27] = a5;
  allocp[28] = a6;
  allocp[29] = a7;
  allocp[30] = a8;
  allocp[31] = a9;
  allocp[32] = x2;
  allocp[33] = a11;
  allocp[34] = x3;
  allocp[35] = a13;
  allocp[36] = x4;
  allocp[37] = (q)(struct goalrec*)&allocp[17];
  allocp[38] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[39] = x6;
  allocp[40] = x8 = makeref(&allocp[40]);
  allocp[41] = x5;
  qp = (struct goalrec*)&allocp[37];
  allocp += 42;
  proceed();
 case VARREF:
  deref_and_jump(x0,interclause__modules_15_2);
  *reasonp++ =  x0;
  goto interclause__modules_15_interrupt;
  };
  goto interclause__modules_15_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto interclause__modules_15_interrupt;
  unify3(a14, a13, a12, a11, a10, a9);
  proceed();
 case VARREF:
  deref_and_jump(a0,interclause__modules_15_1);
  *reasonp++ =  a0;
  goto interclause__modules_15_interrupt;
  };
  goto interclause__modules_15_interrupt;
 interclause__modules_15_ext_interrupt:
  reasonp = 0l;
 interclause__modules_15_interrupt:
  goto interrupt_15;
 }

 interclause__clauses_18_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  qp = qp->next;
 interclause__clauses_18_clear_reason:
  reasonp = reasons;
 interclause__clauses_18_0:
 interclause__clauses_18_1:
  if (!isint(a0)) goto interclause__clauses_18_5;
 interclause__clauses_18_2:
  if (!isint(a1)) goto interclause__clauses_18_4;
  gblt_less_or_eq(a0,a1,interclause__clauses_18_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xinterclause__clauses_18);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  allocp[12] = a10;
  allocp[13] = a11;
  allocp[14] = x1 = makeref(&allocp[14]);
  allocp[15] = a13;
  allocp[16] = x2 = makeref(&allocp[16]);
  allocp[17] = a15;
  allocp[18] = x3 = makeref(&allocp[18]);
  allocp[19] = a17;
  allocp[20] = (q)(struct goalrec*)&allocp[0];
  allocp[21] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[22] = a0;
  allocp[23] = makeint(1L);
  allocp[24] = x0;
  allocp[25] = (q)(struct goalrec*)&allocp[20];
  allocp[26] = (q)(&predicate_analyze__type_xinterclause__clause_17);
  allocp[27] = x4 = makeref(&allocp[27]);
  allocp[28] = a3;
  allocp[29] = a0;
  allocp[30] = a4;
  allocp[31] = a5;
  allocp[32] = a6;
  allocp[33] = a7;
  allocp[34] = a8;
  allocp[35] = a9;
  allocp[36] = a10;
  allocp[37] = a11;
  allocp[38] = a12;
  allocp[39] = x1;
  allocp[40] = a14;
  allocp[41] = x2;
  allocp[42] = a16;
  allocp[43] = x3;
  allocp[44] = (q)(struct goalrec*)&allocp[25];
  allocp[45] = (q)(&predicate_functor__table_xarg_3);
  allocp[46] = a0;
  allocp[47] = a2;
  allocp[48] = x4;
  qp = (struct goalrec*)&allocp[44];
  allocp += 49;
  proceed();
 interclause__clauses_18_3:
  gblt_greater(a0,a1,interclause__clauses_18_interrupt);
  unify3(a17, a16, a15, a14, a13, a12);
  proceed();
 interclause__clauses_18_4:
  if (!isref(a1)) goto interclause__clauses_18_interrupt;
  deref_and_jump(a1,interclause__clauses_18_2);
  *reasonp++ =  a1;
  goto interclause__clauses_18_interrupt;
 interclause__clauses_18_5:
  if (!isref(a0)) goto interclause__clauses_18_interrupt;
  deref_and_jump(a0,interclause__clauses_18_1);
  *reasonp++ =  a0;
  goto interclause__clauses_18_interrupt;
 interclause__clauses_18_ext_interrupt:
  reasonp = 0l;
 interclause__clauses_18_interrupt:
  goto interrupt_18;
 }

 interclause__clause_17_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  qp = qp->next;
 interclause__clause_17_clear_reason:
  reasonp = reasons;
 interclause__clause_17_0:
 interclause__clause_17_1:
  switch (ptagof(a9)) {
 case ATOMIC:
  if (isint(a9)) goto interclause__clause_17_6;
  switch (symval(a9)) {
 case symval(makesym(atom__2B)):
 interclause__clause_17_2:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_clause_4)) goto interclause__clause_17_6;
 interclause__clause_17_3:
  switch (ptagof(a10)) {
 case ATOMIC:
  if (isint(a10)) goto interclause__clause_17_6;
  switch (symval(a10)) {
 case symval(makesym(atom_normal)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xset__typeset_16);
  allocp[2] = makesym(atom__2B);
  allocp[3] = a1;
  allocp[4] = a2;
  x0 = arg(a0, 0);
  allocp[5] = x0;
  x1 = arg(a0, 2);
  allocp[6] = x1;
  allocp[7] = a7;
  allocp[8] = a8;
  allocp[9] = a3;
  allocp[10] = a4;
  allocp[11] = a5;
  allocp[12] = a6;
  allocp[13] = a10;
  allocp[14] = a13;
  allocp[15] = a14;
  allocp[16] = a15;
  allocp[17] = a16;
  allocp[18] = (q)(struct goalrec*)&allocp[0];
  allocp[19] = (q)(&predicate_hb_xwrite__mode_7);
  allocp[20] = a3;
  allocp[21] = a4;
  allocp[22] = a5;
  allocp[23] = a6;
  allocp[24] = makesym(atom_i);
  allocp[25] = a11;
  allocp[26] = a12;
  qp = (struct goalrec*)&allocp[18];
  allocp += 27;
  proceed();
 case symval(makesym(atom_expand)):
  unify(a12, a11);
  x0 = arg(a0, 0);
  x1 = arg(a0, 2);
  x2 = a7;
  x3 = a8;
  a7 = a3;
  a8 = a4;
  a9 = a5;
  x4 = a6;
  a11 = a10;
  a12 = a13;
  a13 = a14;
  a14 = a15;
  a15 = a16;
  a10 = x4;
  a6 = x3;
  a5 = x2;
  a4 = x1;
  a3 = x0;
  a0 = makesym(atom__2B);
  execute(set__typeset_16_0);
  goto set__typeset_16_ext_interrupt;
  };
  goto interclause__clause_17_6;
 case VARREF:
  deref_and_jump(a10,interclause__clause_17_3);
  *reasonp++ =  a10;
  goto interclause__clause_17_6;
  };
  goto interclause__clause_17_6;
 case VARREF:
  deref_and_jump(a0,interclause__clause_17_2);
  *reasonp++ =  a0;
  goto interclause__clause_17_6;
  };
  goto interclause__clause_17_6;
 case symval(makesym(atom__2D)):
 interclause__clause_17_4:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_clause_4)) goto interclause__clause_17_6;
 interclause__clause_17_5:
  switch (ptagof(a10)) {
 case ATOMIC:
  if (isint(a10)) goto interclause__clause_17_6;
  switch (symval(a10)) {
 case symval(makesym(atom_normal)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xset__typeset_16);
  allocp[2] = makesym(atom__2D);
  allocp[3] = a1;
  allocp[4] = a2;
  x0 = arg(a0, 0);
  allocp[5] = x0;
  x1 = arg(a0, 2);
  allocp[6] = x1;
  allocp[7] = a7;
  allocp[8] = a8;
  allocp[9] = a3;
  allocp[10] = a4;
  allocp[11] = a5;
  allocp[12] = a6;
  allocp[13] = a10;
  allocp[14] = a13;
  allocp[15] = a14;
  allocp[16] = a15;
  allocp[17] = a16;
  allocp[18] = (q)(struct goalrec*)&allocp[0];
  allocp[19] = (q)(&predicate_hb_xwrite__mode_7);
  allocp[20] = a3;
  allocp[21] = a4;
  allocp[22] = a5;
  allocp[23] = a6;
  allocp[24] = makesym(atom_o);
  allocp[25] = a11;
  allocp[26] = a12;
  qp = (struct goalrec*)&allocp[18];
  allocp += 27;
  proceed();
 case symval(makesym(atom_expand)):
  unify(a12, a11);
  x0 = arg(a0, 0);
  x1 = arg(a0, 2);
  x2 = a7;
  x3 = a8;
  a7 = a3;
  a8 = a4;
  a9 = a5;
  x4 = a6;
  a11 = a10;
  a12 = a13;
  a13 = a14;
  a14 = a15;
  a15 = a16;
  a10 = x4;
  a6 = x3;
  a5 = x2;
  a4 = x1;
  a3 = x0;
  a0 = makesym(atom__2D);
  execute(set__typeset_16_0);
  goto set__typeset_16_ext_interrupt;
  };
  goto interclause__clause_17_6;
 case VARREF:
  deref_and_jump(a10,interclause__clause_17_5);
  *reasonp++ =  a10;
  goto interclause__clause_17_6;
  };
  goto interclause__clause_17_6;
 case VARREF:
  deref_and_jump(a0,interclause__clause_17_4);
  *reasonp++ =  a0;
  goto interclause__clause_17_6;
  };
  goto interclause__clause_17_6;
  };
  goto interclause__clause_17_6;
 case VARREF:
  deref_and_jump(a9,interclause__clause_17_1);
  *reasonp++ =  a9;
  goto interclause__clause_17_6;
  };
  goto interclause__clause_17_6;
 interclause__clause_17_6:
  otherwise(interclause__clause_17_interrupt);
  unify3(a16, a15, a14, a13, a12, a11);
  proceed();
 interclause__clause_17_ext_interrupt:
  reasonp = 0l;
 interclause__clause_17_interrupt:
  goto interrupt_17;
 }

 set__typeset_16_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  qp = qp->next;
 set__typeset_16_clear_reason:
  reasonp = reasons;
 set__typeset_16_0:
 set__typeset_16_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto set__typeset_16_2;
  switch (symval(a0)) {
 case symval(makesym(atom__2B)):
  a0 = a1;
  a1 = a2;
  a2 = makesym(atom_head);
  a4 = a3;
  a5 = a7;
  x0 = a8;
  a7 = a9;
  a8 = a10;
  a9 = a6;
  a10 = makesym(atom__2B);
  a6 = x0;
  a3 = makeint(1L);
  execute(set__goal__typeset_16_0);
  goto set__goal__typeset_16_ext_interrupt;
 case symval(makesym(atom__2D)):
  a0 = a1;
  a1 = a2;
  a2 = makesym(atom_body);
  a3 = a4;
  a4 = a7;
  x0 = a8;
  a6 = a9;
  a7 = a10;
  a8 = a5;
  a9 = makesym(atom__2D);
  a10 = a11;
  a11 = a12;
  a12 = a13;
  a13 = a14;
  a14 = a15;
  a5 = x0;
  execute(set__goals__typeset_15_0);
  goto set__goals__typeset_15_ext_interrupt;
  };
  goto set__typeset_16_2;
 case VARREF:
  deref_and_jump(a0,set__typeset_16_1);
  *reasonp++ =  a0;
  goto set__typeset_16_2;
  };
  goto set__typeset_16_2;
 set__typeset_16_2:
  otherwise(set__typeset_16_interrupt);
  unify2(a15, a14, a13, a12);
  proceed();
 set__typeset_16_ext_interrupt:
  reasonp = 0l;
 set__typeset_16_interrupt:
  toppred = &predicate_analyze__type_xset__typeset_16;
  goto interrupt_16;
 }

 set__goals__typeset_15_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  qp = qp->next;
 set__goals__typeset_15_clear_reason:
  reasonp = reasons;
 set__goals__typeset_15_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xset__goals__typeset_16);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = a8;
  allocp[12] = a9;
  allocp[13] = a10;
  allocp[14] = a11;
  allocp[15] = a12;
  allocp[16] = a13;
  allocp[17] = a14;
  allocp[18] = (q)(struct goalrec*)&allocp[0];
  allocp[19] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[20] = a3;
  allocp[21] = x1 = makeref(&allocp[21]);
  allocp[22] = x0;
  qp = (struct goalrec*)&allocp[18];
  allocp += 23;
  proceed();
 set__goals__typeset_15_ext_interrupt:
  reasonp = 0l;
 set__goals__typeset_15_interrupt:
  toppred = &predicate_analyze__type_xset__goals__typeset_15;
  goto interrupt_15;
 }

 set__goals__typeset_16_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  qp = qp->next;
 set__goals__typeset_16_clear_reason:
  reasonp = reasons;
 set__goals__typeset_16_0:
 set__goals__typeset_16_1:
  if (!isint(a0)) goto set__goals__typeset_16_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,set__goals__typeset_16_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xset__goals__typeset_16);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  allocp[12] = a10;
  allocp[13] = a11;
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = a13;
  allocp[16] = x3 = makeref(&allocp[16]);
  allocp[17] = a15;
  allocp[18] = (q)(struct goalrec*)&allocp[0];
  allocp[19] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[20] = a0;
  allocp[21] = makeint(1L);
  allocp[22] = x1;
  allocp[23] = (q)(struct goalrec*)&allocp[18];
  allocp[24] = (q)(&predicate_analyze__type_xset__goal__typeset_16);
  allocp[25] = a1;
  allocp[26] = a2;
  allocp[27] = a3;
  allocp[28] = a0;
  allocp[29] = x4 = makeref(&allocp[29]);
  allocp[30] = a5;
  allocp[31] = a6;
  allocp[32] = a7;
  allocp[33] = a8;
  allocp[34] = a9;
  allocp[35] = a10;
  allocp[36] = a11;
  allocp[37] = a12;
  allocp[38] = x2;
  allocp[39] = a14;
  allocp[40] = x3;
  allocp[41] = (q)(struct goalrec*)&allocp[23];
  allocp[42] = (q)(&predicate_functor__table_xarg_3);
  allocp[43] = a0;
  allocp[44] = a4;
  allocp[45] = x4;
  qp = (struct goalrec*)&allocp[41];
  allocp += 46;
  proceed();
 set__goals__typeset_16_2:
  if (a0 != makeint(0L)) goto set__goals__typeset_16_interrupt;
  unify2(a15, a14, a13, a12);
  proceed();
 set__goals__typeset_16_3:
  if (!isref(a0)) goto set__goals__typeset_16_interrupt;
  deref_and_jump(a0,set__goals__typeset_16_1);
  *reasonp++ =  a0;
  goto set__goals__typeset_16_interrupt;
 set__goals__typeset_16_ext_interrupt:
  reasonp = 0l;
 set__goals__typeset_16_interrupt:
  goto interrupt_16;
 }

 set__goal__typeset_16_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  qp = qp->next;
 set__goal__typeset_16_clear_reason:
  reasonp = reasons;
 set__goal__typeset_16_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xset__goal__typeset1_18);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a1;
  allocp[6] = a2;
  allocp[7] = a3;
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = a5;
  allocp[10] = a6;
  allocp[11] = a7;
  allocp[12] = a8;
  allocp[13] = a9;
  allocp[14] = a10;
  allocp[15] = a11;
  allocp[16] = a12;
  allocp[17] = a13;
  allocp[18] = a14;
  allocp[19] = a15;
  allocp[20] = (q)(struct goalrec*)&allocp[0];
  allocp[21] = (q)(&predicate_parse__uty_xdecode__goalcall_6);
  allocp[22] = a0;
  allocp[23] = x1;
  allocp[24] = a4;
  allocp[25] = x2;
  allocp[26] = x0;
  allocp[27] = x3 = makeref(&allocp[27]);
  qp = (struct goalrec*)&allocp[20];
  allocp += 28;
  proceed();
 set__goal__typeset_16_ext_interrupt:
  reasonp = 0l;
 set__goal__typeset_16_interrupt:
  toppred = &predicate_analyze__type_xset__goal__typeset_16;
  goto interrupt_16;
 }

 set__goal__typeset1_18_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  qp = qp->next;
 set__goal__typeset1_18_clear_reason:
  reasonp = reasons;
 set__goal__typeset1_18_0:
 set__goal__typeset1_18_1:
  switch (ptagof(a12)) {
 case ATOMIC:
  if (a12 != makesym(atom__2D)) goto set__goal__typeset1_18_48;
 set__goal__typeset1_18_2:
  if (isref(a2)) goto set__goal__typeset1_18_47;
 set__goal__typeset1_18_3:
  if (isref(a2)) goto set__goal__typeset1_18_46;
  if_not_equal(a2, a1, set__goal__typeset1_18_16);
 set__goal__typeset1_18_4:
  if (isref(a6)) goto set__goal__typeset1_18_15;
  gblt_pfunctor(a6,x0,set__goal__typeset1_18_16);
 set__goal__typeset1_18_5:
  if (isref(x0)) goto set__goal__typeset1_18_14;
 set__goal__typeset1_18_6:
  if (isref(x0)) goto set__goal__typeset1_18_13;
  if_not_equal(x0, a8, set__goal__typeset1_18_16);
  gblt_arity(a6,x1,set__goal__typeset1_18_16);
 set__goal__typeset1_18_7:
  if (isref(x1)) goto set__goal__typeset1_18_12;
 set__goal__typeset1_18_8:
  if (isref(x1)) goto set__goal__typeset1_18_11;
  if_not_equal(x1, a9, set__goal__typeset1_18_16);
 set__goal__typeset1_18_9:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_atom_1)) goto set__goal__typeset1_18_16;
  x2 = arg(a0, 0);
 set__goal__typeset1_18_10:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != makesym(atom_recursive)) goto set__goal__typeset1_18_16;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xset__arg__typeset_11);
  allocp[2] = a1;
  allocp[3] = a3;
  allocp[4] = a4;
  allocp[5] = a5;
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = x4 = makeref(&allocp[7]);
  allocp[8] = a13;
  allocp[9] = x5 = makeref(&allocp[9]);
  allocp[10] = a15;
  allocp[11] = a16;
  allocp[12] = a17;
  allocp[13] = (q)(struct goalrec*)&allocp[0];
  allocp[14] = (q)(&predicate_functor__table_xarg_3);
  allocp[15] = a10;
  allocp[16] = a6;
  allocp[17] = x3;
  allocp[18] = makesym(functor_goal_4);
  allocp[19] = a7;
  allocp[20] = a3;
  allocp[21] = a4;
  allocp[22] = a5;
  x6 = makefunctor(&allocp[18]);
  allocp[23] = (q)(struct goalrec*)&allocp[13];
  allocp[24] = (q)(&predicate_typeset_xmake__shared__ts_8);
  allocp[25] = makesym(atom__2D);
  allocp[26] = makesym(atom_recursive);
  allocp[27] = a11;
  allocp[28] = x4;
  allocp[29] = x6;
  allocp[30] = a13;
  allocp[31] = a14;
  allocp[32] = x5;
  qp = (struct goalrec*)&allocp[23];
  allocp += 33;
  proceed();
 case VARREF:
  deref_and_jump(x2,set__goal__typeset1_18_10);
  *reasonp++ =  x2;
  goto set__goal__typeset1_18_16;
  };
  goto set__goal__typeset1_18_16;
 case VARREF:
  deref_and_jump(a0,set__goal__typeset1_18_9);
  *reasonp++ =  a0;
  goto set__goal__typeset1_18_16;
  };
  goto set__goal__typeset1_18_16;
 set__goal__typeset1_18_11:
  deref_and_jump(x1,set__goal__typeset1_18_8);
  *reasonp++ =  x1;
  goto set__goal__typeset1_18_16;
 set__goal__typeset1_18_12:
  deref_and_jump(x1,set__goal__typeset1_18_7);
  *reasonp++ =  x1;
  goto set__goal__typeset1_18_16;
 set__goal__typeset1_18_13:
  deref_and_jump(x0,set__goal__typeset1_18_6);
  *reasonp++ =  x0;
  goto set__goal__typeset1_18_16;
 set__goal__typeset1_18_14:
  deref_and_jump(x0,set__goal__typeset1_18_5);
  *reasonp++ =  x0;
  goto set__goal__typeset1_18_16;
 set__goal__typeset1_18_15:
  deref_and_jump(a6,set__goal__typeset1_18_4);
  *reasonp++ =  a6;
  goto set__goal__typeset1_18_16;
 set__goal__typeset1_18_16:
 set__goal__typeset1_18_17:
  if (isref(a2)) goto set__goal__typeset1_18_45;
  if_not_equal(a2, a1, set__goal__typeset1_18_30);
 set__goal__typeset1_18_18:
  if (isref(a6)) goto set__goal__typeset1_18_29;
  gblt_pfunctor(a6,x0,set__goal__typeset1_18_30);
 set__goal__typeset1_18_19:
  if (isref(x0)) goto set__goal__typeset1_18_28;
 set__goal__typeset1_18_20:
  if (isref(x0)) goto set__goal__typeset1_18_27;
  if_not_equal(x0, a8, set__goal__typeset1_18_30);
  gblt_arity(a6,x1,set__goal__typeset1_18_30);
 set__goal__typeset1_18_21:
  if (isref(x1)) goto set__goal__typeset1_18_26;
 set__goal__typeset1_18_22:
  if (isref(x1)) goto set__goal__typeset1_18_25;
  if_not_equal(x1, a9, set__goal__typeset1_18_30);
 set__goal__typeset1_18_23:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_atom_1)) goto set__goal__typeset1_18_30;
  x2 = arg(a0, 0);
 set__goal__typeset1_18_24:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != makesym(atom_entry)) goto set__goal__typeset1_18_30;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xset__arg__typeset_11);
  allocp[2] = a1;
  allocp[3] = a3;
  allocp[4] = a4;
  allocp[5] = a5;
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = x4 = makeref(&allocp[7]);
  allocp[8] = a13;
  allocp[9] = x5 = makeref(&allocp[9]);
  allocp[10] = a15;
  allocp[11] = a16;
  allocp[12] = a17;
  allocp[13] = (q)(struct goalrec*)&allocp[0];
  allocp[14] = (q)(&predicate_functor__table_xarg_3);
  allocp[15] = a10;
  allocp[16] = a6;
  allocp[17] = x3;
  allocp[18] = makesym(functor_goal_4);
  allocp[19] = a7;
  allocp[20] = a3;
  allocp[21] = a4;
  allocp[22] = a5;
  x6 = makefunctor(&allocp[18]);
  allocp[23] = (q)(struct goalrec*)&allocp[13];
  allocp[24] = (q)(&predicate_typeset_xmake__shared__ts_8);
  allocp[25] = makesym(atom__2D);
  allocp[26] = makesym(atom_entry);
  allocp[27] = a11;
  allocp[28] = x4;
  allocp[29] = x6;
  allocp[30] = a13;
  allocp[31] = a14;
  allocp[32] = x5;
  qp = (struct goalrec*)&allocp[23];
  allocp += 33;
  proceed();
 case VARREF:
  deref_and_jump(x2,set__goal__typeset1_18_24);
  *reasonp++ =  x2;
  goto set__goal__typeset1_18_30;
  };
  goto set__goal__typeset1_18_30;
 case VARREF:
  deref_and_jump(a0,set__goal__typeset1_18_23);
  *reasonp++ =  a0;
  goto set__goal__typeset1_18_30;
  };
  goto set__goal__typeset1_18_30;
 set__goal__typeset1_18_25:
  deref_and_jump(x1,set__goal__typeset1_18_22);
  *reasonp++ =  x1;
  goto set__goal__typeset1_18_30;
 set__goal__typeset1_18_26:
  deref_and_jump(x1,set__goal__typeset1_18_21);
  *reasonp++ =  x1;
  goto set__goal__typeset1_18_30;
 set__goal__typeset1_18_27:
  deref_and_jump(x0,set__goal__typeset1_18_20);
  *reasonp++ =  x0;
  goto set__goal__typeset1_18_30;
 set__goal__typeset1_18_28:
  deref_and_jump(x0,set__goal__typeset1_18_19);
  *reasonp++ =  x0;
  goto set__goal__typeset1_18_30;
 set__goal__typeset1_18_29:
  deref_and_jump(a6,set__goal__typeset1_18_18);
  *reasonp++ =  a6;
  goto set__goal__typeset1_18_30;
 set__goal__typeset1_18_30:
 set__goal__typeset1_18_31:
  if (isref(a2)) goto set__goal__typeset1_18_44;
  if_not_equal(a2, a7, set__goal__typeset1_18_48);
 set__goal__typeset1_18_32:
  if (isref(a6)) goto set__goal__typeset1_18_43;
  gblt_pfunctor(a6,x0,set__goal__typeset1_18_48);
 set__goal__typeset1_18_33:
  if (isref(x0)) goto set__goal__typeset1_18_42;
 set__goal__typeset1_18_34:
  if (isref(x0)) goto set__goal__typeset1_18_41;
  if_not_equal(x0, a8, set__goal__typeset1_18_48);
  gblt_arity(a6,x1,set__goal__typeset1_18_48);
 set__goal__typeset1_18_35:
  if (isref(x1)) goto set__goal__typeset1_18_40;
 set__goal__typeset1_18_36:
  if (isref(x1)) goto set__goal__typeset1_18_39;
  if_not_equal(x1, a9, set__goal__typeset1_18_48);
 set__goal__typeset1_18_37:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_atom_1)) goto set__goal__typeset1_18_48;
  x2 = arg(a0, 0);
 set__goal__typeset1_18_38:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != makesym(atom_shared)) goto set__goal__typeset1_18_48;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xset__arg__typeset_11);
  allocp[2] = a1;
  allocp[3] = a3;
  allocp[4] = a4;
  allocp[5] = a5;
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = x4 = makeref(&allocp[7]);
  allocp[8] = a13;
  allocp[9] = x5 = makeref(&allocp[9]);
  allocp[10] = a15;
  allocp[11] = a16;
  allocp[12] = a17;
  allocp[13] = (q)(struct goalrec*)&allocp[0];
  allocp[14] = (q)(&predicate_functor__table_xarg_3);
  allocp[15] = a10;
  allocp[16] = a6;
  allocp[17] = x3;
  allocp[18] = makesym(functor_goal_4);
  allocp[19] = a7;
  allocp[20] = a3;
  allocp[21] = a4;
  allocp[22] = a5;
  x6 = makefunctor(&allocp[18]);
  allocp[23] = (q)(struct goalrec*)&allocp[13];
  allocp[24] = (q)(&predicate_typeset_xmake__shared__ts_8);
  allocp[25] = makesym(atom__2D);
  allocp[26] = makesym(atom_shared);
  allocp[27] = a11;
  allocp[28] = x4;
  allocp[29] = x6;
  allocp[30] = a13;
  allocp[31] = a14;
  allocp[32] = x5;
  qp = (struct goalrec*)&allocp[23];
  allocp += 33;
  proceed();
 case VARREF:
  deref_and_jump(x2,set__goal__typeset1_18_38);
  *reasonp++ =  x2;
  goto set__goal__typeset1_18_48;
  };
  goto set__goal__typeset1_18_48;
 case VARREF:
  deref_and_jump(a0,set__goal__typeset1_18_37);
  *reasonp++ =  a0;
  goto set__goal__typeset1_18_48;
  };
  goto set__goal__typeset1_18_48;
 set__goal__typeset1_18_39:
  deref_and_jump(x1,set__goal__typeset1_18_36);
  *reasonp++ =  x1;
  goto set__goal__typeset1_18_48;
 set__goal__typeset1_18_40:
  deref_and_jump(x1,set__goal__typeset1_18_35);
  *reasonp++ =  x1;
  goto set__goal__typeset1_18_48;
 set__goal__typeset1_18_41:
  deref_and_jump(x0,set__goal__typeset1_18_34);
  *reasonp++ =  x0;
  goto set__goal__typeset1_18_48;
 set__goal__typeset1_18_42:
  deref_and_jump(x0,set__goal__typeset1_18_33);
  *reasonp++ =  x0;
  goto set__goal__typeset1_18_48;
 set__goal__typeset1_18_43:
  deref_and_jump(a6,set__goal__typeset1_18_32);
  *reasonp++ =  a6;
  goto set__goal__typeset1_18_48;
 set__goal__typeset1_18_44:
  deref_and_jump(a2,set__goal__typeset1_18_31);
  *reasonp++ =  a2;
  goto set__goal__typeset1_18_48;
 set__goal__typeset1_18_45:
  deref_and_jump(a2,set__goal__typeset1_18_17);
  *reasonp++ =  a2;
  goto set__goal__typeset1_18_48;
 set__goal__typeset1_18_46:
  deref_and_jump(a2,set__goal__typeset1_18_3);
  *reasonp++ =  a2;
  goto set__goal__typeset1_18_48;
 set__goal__typeset1_18_47:
  deref_and_jump(a2,set__goal__typeset1_18_2);
  *reasonp++ =  a2;
  goto set__goal__typeset1_18_48;
 case VARREF:
  deref_and_jump(a12,set__goal__typeset1_18_1);
  *reasonp++ =  a12;
  goto set__goal__typeset1_18_48;
  };
  goto set__goal__typeset1_18_48;
 set__goal__typeset1_18_48:
  otherwise(set__goal__typeset1_18_interrupt);
 set__goal__typeset1_18_49:
  if (isref(a2)) goto set__goal__typeset1_18_62;
 set__goal__typeset1_18_50:
  if (isref(a2)) goto set__goal__typeset1_18_61;
  if_not_equal(a2, a7, set__goal__typeset1_18_63);
 set__goal__typeset1_18_51:
  if (isref(a6)) goto set__goal__typeset1_18_60;
  gblt_pfunctor(a6,x0,set__goal__typeset1_18_63);
 set__goal__typeset1_18_52:
  if (isref(x0)) goto set__goal__typeset1_18_59;
 set__goal__typeset1_18_53:
  if (isref(x0)) goto set__goal__typeset1_18_58;
  if_not_equal(x0, a8, set__goal__typeset1_18_63);
  gblt_arity(a6,x1,set__goal__typeset1_18_63);
 set__goal__typeset1_18_54:
  if (isref(x1)) goto set__goal__typeset1_18_57;
 set__goal__typeset1_18_55:
  if (isref(x1)) goto set__goal__typeset1_18_56;
  if_not_equal(x1, a9, set__goal__typeset1_18_63);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xset__arg__typeset_11);
  allocp[2] = a1;
  allocp[3] = a3;
  allocp[4] = a4;
  allocp[5] = a5;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a11;
  allocp[8] = a13;
  allocp[9] = a14;
  allocp[10] = a15;
  allocp[11] = a16;
  allocp[12] = a17;
  allocp[13] = (q)(struct goalrec*)&allocp[0];
  allocp[14] = (q)(&predicate_functor__table_xarg_3);
  allocp[15] = a10;
  allocp[16] = a6;
  allocp[17] = x2;
  qp = (struct goalrec*)&allocp[13];
  allocp += 18;
  proceed();
 set__goal__typeset1_18_56:
  deref_and_jump(x1,set__goal__typeset1_18_55);
  *reasonp++ =  x1;
  goto set__goal__typeset1_18_63;
 set__goal__typeset1_18_57:
  deref_and_jump(x1,set__goal__typeset1_18_54);
  *reasonp++ =  x1;
  goto set__goal__typeset1_18_63;
 set__goal__typeset1_18_58:
  deref_and_jump(x0,set__goal__typeset1_18_53);
  *reasonp++ =  x0;
  goto set__goal__typeset1_18_63;
 set__goal__typeset1_18_59:
  deref_and_jump(x0,set__goal__typeset1_18_52);
  *reasonp++ =  x0;
  goto set__goal__typeset1_18_63;
 set__goal__typeset1_18_60:
  deref_and_jump(a6,set__goal__typeset1_18_51);
  *reasonp++ =  a6;
  goto set__goal__typeset1_18_63;
 set__goal__typeset1_18_61:
  deref_and_jump(a2,set__goal__typeset1_18_50);
  *reasonp++ =  a2;
  goto set__goal__typeset1_18_63;
 set__goal__typeset1_18_62:
  deref_and_jump(a2,set__goal__typeset1_18_49);
  *reasonp++ =  a2;
  goto set__goal__typeset1_18_63;
 set__goal__typeset1_18_63:
  otherwise(set__goal__typeset1_18_interrupt);
  unify2(a17, a16, a15, a14);
  proceed();
 set__goal__typeset1_18_ext_interrupt:
  reasonp = 0l;
 set__goal__typeset1_18_interrupt:
  goto interrupt_18;
 }

 set__arg__typeset_11_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 set__arg__typeset_11_clear_reason:
  reasonp = reasons;
 set__arg__typeset_11_0:
 set__arg__typeset_11_1:
  switch (ptagof(a4)) {
 case FUNCTOR:
  if (functor_of(a4) != makesym(functor_variable_3)) goto set__arg__typeset_11_2;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xset_12);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  x0 = arg(a4, 0);
  allocp[6] = x0;
  x1 = arg(a4, 1);
  allocp[7] = x1;
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = a8;
  allocp[12] = a9;
  allocp[13] = a10;
  qp = (struct goalrec*)&allocp[0];
  allocp += 14;
  proceed();
 case VARREF:
  deref_and_jump(a4,set__arg__typeset_11_1);
  *reasonp++ =  a4;
  goto set__arg__typeset_11_2;
  };
  goto set__arg__typeset_11_2;
 set__arg__typeset_11_2:
  otherwise(set__arg__typeset_11_interrupt);
  unify2(a10, a9, a8, a7);
  proceed();
 set__arg__typeset_11_ext_interrupt:
  reasonp = 0l;
 set__arg__typeset_11_interrupt:
  goto interrupt_11;
 }

 determine__typeset1_6_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 determine__typeset1_6_clear_reason:
  reasonp = reasons;
 determine__typeset1_6_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xdetermine__typeset_6);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  x2 = a1;
  a1 = makesym(atom_normal);
  a3 = x1;
  a4 = a0;
  a5 = x0;
  a0 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  execute(indirect__unify_6_0);
  goto indirect__unify_6_ext_interrupt;
 determine__typeset1_6_ext_interrupt:
  reasonp = 0l;
 determine__typeset1_6_interrupt:
  goto interrupt_6;
 }

 analyze__typeset_7_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 analyze__typeset_7_clear_reason:
  reasonp = reasons;
 analyze__typeset_7_0:
 analyze__typeset_7_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 analyze__typeset_7_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto analyze__typeset_7_8;
 analyze__typeset_7_3:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_var_6)) goto analyze__typeset_7_8;
  x1 = arg(a0, 0);
 analyze__typeset_7_4:
  if (isref(x1)) goto analyze__typeset_7_7;
 analyze__typeset_7_5:
  if (isref(x1)) goto analyze__typeset_7_6;
  x2 = arg(x0, 0);
  if_not_equal(x1, x2, analyze__typeset_7_8);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xanalyze__clause__typeset_7);
  allocp[2] = a0;
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_functor__table_xarg_3);
  x4 = arg(a0, 1);
  allocp[11] = x4;
  x5 = arg(x0, 1);
  allocp[12] = x5;
  allocp[13] = x3;
  qp = (struct goalrec*)&allocp[9];
  allocp += 14;
  proceed();
 analyze__typeset_7_6:
  deref_and_jump(x1,analyze__typeset_7_5);
  *reasonp++ =  x1;
  goto analyze__typeset_7_8;
 analyze__typeset_7_7:
  deref_and_jump(x1,analyze__typeset_7_4);
  *reasonp++ =  x1;
  goto analyze__typeset_7_8;
 case VARREF:
  deref_and_jump(a0,analyze__typeset_7_3);
  *reasonp++ =  a0;
  goto analyze__typeset_7_8;
  };
  goto analyze__typeset_7_8;
 case VARREF:
  deref_and_jump(x0,analyze__typeset_7_2);
  *reasonp++ =  x0;
  goto analyze__typeset_7_8;
  };
  goto analyze__typeset_7_8;
 case VARREF:
  deref_and_jump(a1,analyze__typeset_7_1);
  *reasonp++ =  a1;
  goto analyze__typeset_7_8;
  };
  goto analyze__typeset_7_8;
 analyze__typeset_7_8:
  otherwise(analyze__typeset_7_interrupt);
 analyze__typeset_7_9:
  switch (ptagof(a1)) {
 case CONS:
  a1 = cdr_of(a1);
  execute(analyze__typeset_7_0);
  goto analyze__typeset_7_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,analyze__typeset_7_9);
  *reasonp++ =  a1;
  goto analyze__typeset_7_10;
  };
  goto analyze__typeset_7_10;
 analyze__typeset_7_10:
  otherwise(analyze__typeset_7_interrupt);
 analyze__typeset_7_11:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != NILATOM) goto analyze__typeset_7_interrupt;
  unify2(a6, a5, a4, a3);
  x0 = makesym(atom_error);
  x1 = makesym(atom_analyze__typeset);
  unify(x0, x1);
  proceed();
 case VARREF:
  deref_and_jump(a1,analyze__typeset_7_11);
  *reasonp++ =  a1;
  goto analyze__typeset_7_interrupt;
  };
  goto analyze__typeset_7_interrupt;
 analyze__typeset_7_ext_interrupt:
  reasonp = 0l;
 analyze__typeset_7_interrupt:
  toppred = &predicate_analyze__type_xanalyze__typeset_7;
  goto interrupt_7;
 }

 analyze__clause__typeset_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 analyze__clause__typeset_7_clear_reason:
  reasonp = reasons;
 analyze__clause__typeset_7_0:
 analyze__clause__typeset_7_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (isint(a1)) goto analyze__clause__typeset_7_interrupt;
 analyze__clause__typeset_7_2:
  gblt_atom(a1,analyze__clause__typeset_7_interrupt);
  unify2(a6, a5, a4, a3);
  proceed();
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_clause_4)) goto analyze__clause__typeset_7_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xapply__goals__typeset_8);
  x0 = arg(a1, 2);
  allocp[2] = x0;
  allocp[3] = a0;
  allocp[4] = makesym(atom_body);
  allocp[5] = a2;
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = a4;
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = a6;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_analyze__type_xapply__goals__typeset_8);
  x3 = arg(a1, 1);
  allocp[12] = x3;
  allocp[13] = a0;
  allocp[14] = makesym(atom_guard);
  allocp[15] = a2;
  allocp[16] = x4 = makeref(&allocp[16]);
  allocp[17] = x1;
  allocp[18] = x5 = makeref(&allocp[18]);
  allocp[19] = x2;
  x6 = arg(a1, 0);
  a1 = a0;
  a4 = a2;
  x7 = a3;
  a6 = x4;
  a7 = a5;
  a8 = x5;
  a5 = x7;
  a3 = makesym(atom_head);
  a2 = makeint(1L);
  a0 = x6;
  qp = (struct goalrec*)&allocp[10];
  allocp += 20;
  execute(apply__goal__typeset_9_0);
  goto apply__goal__typeset_9_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,analyze__clause__typeset_7_1);
  *reasonp++ =  a1;
  goto analyze__clause__typeset_7_interrupt;
  };
  goto analyze__clause__typeset_7_interrupt;
 analyze__clause__typeset_7_ext_interrupt:
  reasonp = 0l;
 analyze__clause__typeset_7_interrupt:
  goto interrupt_7;
 }

 apply__goals__typeset_8_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 apply__goals__typeset_8_clear_reason:
  reasonp = reasons;
 apply__goals__typeset_8_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xapply__goals__type_9);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[13] = a0;
  allocp[14] = x1 = makeref(&allocp[14]);
  allocp[15] = x0;
  qp = (struct goalrec*)&allocp[11];
  allocp += 16;
  proceed();
 apply__goals__typeset_8_ext_interrupt:
  reasonp = 0l;
 apply__goals__typeset_8_interrupt:
  goto interrupt_8;
 }

 apply__goals__type_9_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 apply__goals__type_9_clear_reason:
  reasonp = reasons;
 apply__goals__type_9_0:
 apply__goals__type_9_1:
  if (!isint(a0)) goto apply__goals__type_9_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,apply__goals__type_9_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xapply__goals__type_9);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = x3 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x1;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_analyze__type_xapply__goal__typeset_9);
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = a2;
  allocp[20] = a0;
  allocp[21] = a3;
  allocp[22] = a4;
  allocp[23] = a5;
  allocp[24] = x2;
  allocp[25] = a7;
  allocp[26] = x3;
  allocp[27] = (q)(struct goalrec*)&allocp[16];
  allocp[28] = (q)(&predicate_functor__table_xarg_3);
  allocp[29] = a0;
  allocp[30] = a1;
  allocp[31] = x4;
  qp = (struct goalrec*)&allocp[27];
  allocp += 32;
  proceed();
 apply__goals__type_9_2:
  if (a0 != makeint(0L)) goto apply__goals__type_9_interrupt;
  unify2(a8, a7, a6, a5);
  proceed();
 apply__goals__type_9_3:
  if (!isref(a0)) goto apply__goals__type_9_interrupt;
  deref_and_jump(a0,apply__goals__type_9_1);
  *reasonp++ =  a0;
  goto apply__goals__type_9_interrupt;
 apply__goals__type_9_ext_interrupt:
  reasonp = 0l;
 apply__goals__type_9_interrupt:
  goto interrupt_9;
 }

 apply__goal__typeset_9_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 apply__goal__typeset_9_clear_reason:
  reasonp = reasons;
 apply__goal__typeset_9_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xapply__goal__type_11);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a1;
  allocp[6] = a2;
  allocp[7] = a3;
  allocp[8] = a4;
  allocp[9] = a5;
  allocp[10] = a6;
  allocp[11] = a7;
  allocp[12] = a8;
  allocp[13] = (q)(struct goalrec*)&allocp[0];
  allocp[14] = (q)(&predicate_parse__uty_xdecode__goal_4);
  allocp[15] = a0;
  allocp[16] = x0;
  allocp[17] = x1;
  allocp[18] = x2;
  qp = (struct goalrec*)&allocp[13];
  allocp += 19;
  proceed();
 apply__goal__typeset_9_ext_interrupt:
  reasonp = 0l;
 apply__goal__typeset_9_interrupt:
  toppred = &predicate_analyze__type_xapply__goal__typeset_9;
  goto interrupt_9;
 }

 apply__goal__type_11_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 apply__goal__type_11_clear_reason:
  reasonp = reasons;
 apply__goal__type_11_0:
 apply__goal__type_11_1:
  switch (ptagof(a3)) {
 case FUNCTOR:
  if (functor_of(a3) != makesym(functor_var_6)) goto apply__goal__type_11_10;
  x0 = arg(a3, 2);
 apply__goal__type_11_2:
  if (isref(x0)) goto apply__goal__type_11_9;
 apply__goal__type_11_3:
  if (isref(x0)) goto apply__goal__type_11_8;
  if_not_equal(x0, a5, apply__goal__type_11_10);
  x1 = arg(a3, 3);
 apply__goal__type_11_4:
  if (isref(x1)) goto apply__goal__type_11_7;
 apply__goal__type_11_5:
  if (isref(x1)) goto apply__goal__type_11_6;
  if_not_equal(x1, a4, apply__goal__type_11_10);
  unify2(a10, a9, a8, a7);
  proceed();
 apply__goal__type_11_6:
  deref_and_jump(x1,apply__goal__type_11_5);
  *reasonp++ =  x1;
  goto apply__goal__type_11_10;
 apply__goal__type_11_7:
  deref_and_jump(x1,apply__goal__type_11_4);
  *reasonp++ =  x1;
  goto apply__goal__type_11_10;
 apply__goal__type_11_8:
  deref_and_jump(x0,apply__goal__type_11_3);
  *reasonp++ =  x0;
  goto apply__goal__type_11_10;
 apply__goal__type_11_9:
  deref_and_jump(x0,apply__goal__type_11_2);
  *reasonp++ =  x0;
  goto apply__goal__type_11_10;
 case VARREF:
  deref_and_jump(a3,apply__goal__type_11_1);
  *reasonp++ =  a3;
  goto apply__goal__type_11_10;
  };
  goto apply__goal__type_11_10;
 apply__goal__type_11_10:
  otherwise(apply__goal__type_11_interrupt);
 apply__goal__type_11_11:
  switch (ptagof(a3)) {
 case FUNCTOR:
  if (functor_of(a3) != makesym(functor_var_6)) goto apply__goal__type_11_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xapply__goal__type2_13);
  allocp[2] = x0 = makeref(&allocp[2]);
  x1 = arg(a3, 0);
  allocp[3] = x1;
  x2 = arg(a3, 1);
  allocp[4] = x2;
  allocp[5] = a5;
  allocp[6] = a4;
  allocp[7] = a0;
  allocp[8] = a3;
  allocp[9] = a1;
  allocp[10] = a6;
  allocp[11] = a7;
  allocp[12] = a8;
  allocp[13] = a9;
  allocp[14] = a10;
  a0 = a2;
  a1 = x1;
  a2 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 15;
  execute(get__call__modulename_3_0);
  goto get__call__modulename_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a3,apply__goal__type_11_11);
  *reasonp++ =  a3;
  goto apply__goal__type_11_interrupt;
  };
  goto apply__goal__type_11_interrupt;
 apply__goal__type_11_ext_interrupt:
  reasonp = 0l;
 apply__goal__type_11_interrupt:
  goto interrupt_11;
 }

 apply__goal__type2_13_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  qp = qp->next;
 apply__goal__type2_13_clear_reason:
  reasonp = reasons;
 apply__goal__type2_13_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xapply__typeset_15);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x0 = makeref(&allocp[7]);
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a6;
  allocp[10] = a5;
  allocp[11] = a7;
  allocp[12] = a8;
  allocp[13] = a9;
  allocp[14] = a10;
  allocp[15] = a11;
  allocp[16] = a12;
  allocp[17] = (q)(struct goalrec*)&allocp[0];
  allocp[18] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[19] = a5;
  allocp[20] = x0;
  allocp[21] = x1;
  qp = (struct goalrec*)&allocp[17];
  allocp += 22;
  proceed();
 apply__goal__type2_13_ext_interrupt:
  reasonp = 0l;
 apply__goal__type2_13_interrupt:
  goto interrupt_13;
 }

 get__call__modulename_3_top: {
  q x0;
  a2 = qp->args[2];
  qp = qp->next;
 get__call__modulename_3_clear_reason:
  reasonp = reasons;
 get__call__modulename_3_0:
 get__call__modulename_3_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_options_2)) goto get__call__modulename_3_3;
  x0 = arg(a0, 0);
 get__call__modulename_3_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (isint(x0)) goto get__call__modulename_3_3;
  switch (symval(x0)) {
 case symval(makesym(atom___)):
  unify(a2, a1);
  proceed();
 case symval(makesym(atom_functor__table)):
  unify(a2, a1);
  proceed();
  };
  goto get__call__modulename_3_3;
 case VARREF:
  deref_and_jump(x0,get__call__modulename_3_2);
  *reasonp++ =  x0;
  goto get__call__modulename_3_3;
  };
  goto get__call__modulename_3_3;
 case VARREF:
  deref_and_jump(a0,get__call__modulename_3_1);
  *reasonp++ =  a0;
  goto get__call__modulename_3_3;
  };
  goto get__call__modulename_3_3;
 get__call__modulename_3_3:
  otherwise(get__call__modulename_3_interrupt);
 get__call__modulename_3_4:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_options_2)) goto get__call__modulename_3_interrupt;
  x0 = arg(a0, 0);
  unify(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,get__call__modulename_3_4);
  *reasonp++ =  a0;
  goto get__call__modulename_3_interrupt;
  };
  goto get__call__modulename_3_interrupt;
 get__call__modulename_3_ext_interrupt:
  reasonp = 0l;
 get__call__modulename_3_interrupt:
  toppred = &predicate_analyze__type_xget__call__modulename_3;
  goto interrupt_3;
 }

 apply__typeset_15_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  qp = qp->next;
 apply__typeset_15_clear_reason:
  reasonp = reasons;
 apply__typeset_15_0:
 apply__typeset_15_1:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (a5 != makesym(atom__3D)) goto apply__typeset_15_5;
 apply__typeset_15_2:
  switch (ptagof(a6)) {
 case ATOMIC:
 apply__typeset_15_3:
  if (a6 != makeint(2L)) goto apply__typeset_15_5;
 apply__typeset_15_4:
  switch (ptagof(a9)) {
 case ATOMIC:
  if (a9 != makesym(atom_builtin)) goto apply__typeset_15_5;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xapply__typeset__equal_16);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = makesym(atom__3D);
  allocp[9] = makeint(2L);
  allocp[10] = a7;
  allocp[11] = a8;
  allocp[12] = makesym(atom_builtin);
  allocp[13] = a10;
  allocp[14] = a11;
  allocp[15] = a12;
  allocp[16] = a13;
  allocp[17] = a14;
  a0 = makeint(2L);
  a1 = a7;
  a2 = a8;
  a3 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 18;
  execute(check__args_4_0);
  goto check__args_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a9,apply__typeset_15_4);
  *reasonp++ =  a9;
  goto apply__typeset_15_5;
  };
  goto apply__typeset_15_5;
 case VARREF:
  deref_and_jump(a6,apply__typeset_15_2);
  *reasonp++ =  a6;
  goto apply__typeset_15_5;
  };
  goto apply__typeset_15_5;
 case VARREF:
  deref_and_jump(a5,apply__typeset_15_1);
  *reasonp++ =  a5;
  goto apply__typeset_15_5;
  };
  goto apply__typeset_15_5;
 apply__typeset_15_5:
  otherwise(apply__typeset_15_interrupt);
 apply__typeset_15_6:
  switch (ptagof(a9)) {
 case ATOMIC:
  if (isint(a9)) goto apply__typeset_15_interrupt;
  switch (symval(a9)) {
 case symval(makesym(atom_builtin)):
  allocp[0] = makesym(functor_var_6);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = x5 = makeref(&allocp[5]);
  allocp[6] = x6 = makeref(&allocp[6]);
  x0 = makefunctor(&allocp[0]);
  allocp += 7;
  unify_value(a7, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin_xmake__typeset_14);
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  allocp[5] = a4;
  allocp[6] = a0;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a8;
  allocp[10] = makesym(atom_builtin);
  allocp[11] = a10;
  allocp[12] = a11;
  allocp[13] = a12;
  allocp[14] = a13;
  allocp[15] = a14;
  qp = (struct goalrec*)&allocp[0];
  allocp += 16;
  proceed();
 case symval(makesym(atom_userdef)):
  unify(a12, a11);
  allocp[0] = makesym(functor_var_6);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = x5 = makeref(&allocp[5]);
  allocp[6] = x6 = makeref(&allocp[6]);
  x0 = makefunctor(&allocp[0]);
  allocp += 7;
  unify_value(a7, x0);
  x7 = a6;
  a1 = a8;
  a2 = x5;
  x8 = a0;
  a4 = a5;
  a5 = a6;
  a6 = a3;
  a7 = a13;
  a8 = a14;
  a3 = x8;
  a0 = x7;
  execute(userdef__typeset_9_0);
  goto userdef__typeset_9_ext_interrupt;
  };
  goto apply__typeset_15_interrupt;
 case VARREF:
  deref_and_jump(a9,apply__typeset_15_6);
  *reasonp++ =  a9;
  goto apply__typeset_15_interrupt;
  };
  goto apply__typeset_15_interrupt;
 apply__typeset_15_ext_interrupt:
  reasonp = 0l;
 apply__typeset_15_interrupt:
  goto interrupt_15;
 }

 check__args_4_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 check__args_4_clear_reason:
  reasonp = reasons;
 check__args_4_0:
 check__args_4_1:
  if (!isint(a0)) goto check__args_4_12;
  x0 = makeint(0L);
  gblt_greater(a0,x0,check__args_4_13);
 check__args_4_2:
  if (isref(a2)) goto check__args_4_11;
  gblt_arg(a0,a2,x1,check__args_4_13);
 check__args_4_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  switch (symval(functor_of(x1))) {
 case functor_variable_3:
 check__args_4_4:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_var_6)) goto check__args_4_10;
  x2 = arg(a1, 4);
 check__args_4_5:
  if (isref(x2)) goto check__args_4_8;
 check__args_4_6:
  if (isref(x2)) goto check__args_4_7;
  x3 = arg(x1, 0);
  if_not_equal(x2, x3, check__args_4_10);
  x4 = makesym(atom_yes);
  unify_value(a3, x4);
  proceed();
 check__args_4_7:
  deref_and_jump(x2,check__args_4_6);
  *reasonp++ =  x2;
  goto check__args_4_10;
 check__args_4_8:
  deref_and_jump(x2,check__args_4_5);
  *reasonp++ =  x2;
  goto check__args_4_10;
 case VARREF:
  deref_and_jump(a1,check__args_4_4);
  *reasonp++ =  a1;
  goto check__args_4_10;
  };
  goto check__args_4_10;
 case functor_functor_1:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xcheck__args2_5);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_analyze__type_xcheck__args_4);
  allocp[9] = x3 = makeref(&allocp[9]);
  allocp[10] = a1;
  x4 = arg(x1, 0);
  allocp[11] = x4;
  allocp[12] = x2;
  allocp[13] = (q)(struct goalrec*)&allocp[7];
  allocp[14] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[15] = x4;
  allocp[16] = x5 = makeref(&allocp[16]);
  allocp[17] = x3;
  qp = (struct goalrec*)&allocp[13];
  allocp += 18;
  proceed();
 case functor_list_1:
  x2 = arg(x1, 0);
 check__args_4_9:
  switch (ptagof(x2)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xcheck__args2_5);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = makesym(functor_list_2);
  x5 = car_of(x2);
  allocp[8] = x5;
  x6 = cdr_of(x2);
  allocp[9] = x6;
  x4 = makefunctor(&allocp[7]);
  a0 = makeint(2L);
  a2 = x4;
  a3 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  execute(check__args_4_0);
  goto check__args_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x2,check__args_4_9);
  *reasonp++ =  x2;
  goto check__args_4_10;
  };
  goto check__args_4_10;
  };
  goto check__args_4_10;
 case VARREF:
  deref_and_jump(x1,check__args_4_3);
  *reasonp++ =  x1;
  goto check__args_4_13;
  };
  goto check__args_4_10;
 check__args_4_10:
  gblt_pfunctor(x1,x2,check__args_4_13);
  if (x2 != makesym(atom_vector)) goto check__args_4_13;
  gblt_arity(x1,x3,check__args_4_13);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xcheck__args2_5);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  a0 = x3;
  a2 = x1;
  a3 = x4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(check__args_4_0);
  goto check__args_4_ext_interrupt;
 check__args_4_11:
  deref_and_jump(a2,check__args_4_2);
  *reasonp++ =  a2;
  goto check__args_4_13;
 check__args_4_12:
  if (!isref(a0)) goto check__args_4_13;
  deref_and_jump(a0,check__args_4_1);
  *reasonp++ =  a0;
  goto check__args_4_13;
 check__args_4_13:
  otherwise(check__args_4_interrupt);
 check__args_4_14:
  if (!isint(a0)) goto check__args_4_16;
  x0 = makeint(0L);
  gblt_greater(a0,x0,check__args_4_15);
  x1 = makeint(1L);
  bblt_sub_no_check(a0,x1,x2);
  a0 = x2;
  execute(check__args_4_0);
  goto check__args_4_ext_interrupt;
 check__args_4_15:
  if (a0 != makeint(0L)) goto check__args_4_interrupt;
  x3 = makesym(atom_no);
  unify_value(a3, x3);
  proceed();
 check__args_4_16:
  if (!isref(a0)) goto check__args_4_interrupt;
  deref_and_jump(a0,check__args_4_14);
  *reasonp++ =  a0;
  goto check__args_4_interrupt;
 check__args_4_ext_interrupt:
  reasonp = 0l;
 check__args_4_interrupt:
  toppred = &predicate_analyze__type_xcheck__args_4;
  goto interrupt_4;
 }

 check__args2_5_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 check__args2_5_clear_reason:
  reasonp = reasons;
 check__args2_5_0:
 check__args2_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto check__args2_5_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  x0 = makesym(atom_yes);
  unify_value(a4, x0);
  proceed();
 case symval(makesym(atom_no)):
  x0 = makeint(1L);
  bblt_sub_no_check_y(a1,x0,x1);
  a0 = x1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  execute(check__args_4_0);
  goto check__args_4_ext_interrupt;
  };
  goto check__args2_5_interrupt;
 case VARREF:
  deref_and_jump(a0,check__args2_5_1);
  *reasonp++ =  a0;
  goto check__args2_5_interrupt;
  };
  goto check__args2_5_interrupt;
 check__args2_5_ext_interrupt:
  reasonp = 0l;
 check__args2_5_interrupt:
  goto interrupt_5;
 }

 apply__typeset__equal_16_top: {
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  qp = qp->next;
 apply__typeset__equal_16_clear_reason:
  reasonp = reasons;
 apply__typeset__equal_16_0:
 apply__typeset__equal_16_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto apply__typeset__equal_16_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_no)):
 apply__typeset__equal_16_2:
  switch (ptagof(a10)) {
 case ATOMIC:
  if (a10 != makesym(atom_builtin)) goto apply__typeset__equal_16_interrupt;
  unify2(a15, a14, a13, a12);
  proceed();
 case VARREF:
  deref_and_jump(a10,apply__typeset__equal_16_2);
  *reasonp++ =  a10;
  goto apply__typeset__equal_16_interrupt;
  };
  goto apply__typeset__equal_16_interrupt;
 case symval(makesym(atom_yes)):
 apply__typeset__equal_16_3:
  switch (ptagof(a10)) {
 case ATOMIC:
  if (a10 != makesym(atom_builtin)) goto apply__typeset__equal_16_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin_xmake__typeset_14);
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  allocp[5] = a5;
  allocp[6] = a1;
  allocp[7] = a6;
  allocp[8] = a7;
  allocp[9] = a9;
  allocp[10] = makesym(atom_builtin);
  allocp[11] = a11;
  allocp[12] = a12;
  allocp[13] = a13;
  allocp[14] = a14;
  allocp[15] = a15;
  qp = (struct goalrec*)&allocp[0];
  allocp += 16;
  proceed();
 case VARREF:
  deref_and_jump(a10,apply__typeset__equal_16_3);
  *reasonp++ =  a10;
  goto apply__typeset__equal_16_interrupt;
  };
  goto apply__typeset__equal_16_interrupt;
  };
  goto apply__typeset__equal_16_interrupt;
 case VARREF:
  deref_and_jump(a0,apply__typeset__equal_16_1);
  *reasonp++ =  a0;
  goto apply__typeset__equal_16_interrupt;
  };
  goto apply__typeset__equal_16_interrupt;
 apply__typeset__equal_16_ext_interrupt:
  reasonp = 0l;
 apply__typeset__equal_16_interrupt:
  goto interrupt_16;
 }

 userdef__typeset_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 userdef__typeset_9_clear_reason:
  reasonp = reasons;
 userdef__typeset_9_0:
 userdef__typeset_9_1:
  if (!isint(a0)) goto userdef__typeset_9_10;
  x0 = makeint(0L);
  gblt_greater(a0,x0,userdef__typeset_9_11);
 userdef__typeset_9_2:
  switch (ptagof(a6)) {
 case ATOMIC:
  if (a6 != makesym(atom_head)) goto userdef__typeset_9_11;
 userdef__typeset_9_3:
  if (isref(a1)) goto userdef__typeset_9_9;
  gblt_arg(a0,a1,x1,userdef__typeset_9_11);
 userdef__typeset_9_4:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_variable_3)) goto userdef__typeset_9_11;
  x2 = arg(x1, 0);
 userdef__typeset_9_5:
  if (isref(x2)) goto userdef__typeset_9_8;
 userdef__typeset_9_6:
  if (isref(x2)) goto userdef__typeset_9_7;
  if_not_equal(x2, a2, userdef__typeset_9_11);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xuserdef__typeset_9);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x4 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = x5 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x3;
  allocp[16] = makesym(functor_userdef_5);
  allocp[17] = a3;
  allocp[18] = a4;
  allocp[19] = a5;
  allocp[20] = a0;
  allocp[21] = makesym(atom__2D);
  x6 = makefunctor(&allocp[16]);
  allocp[22] = NILATOM;
  allocp[23] = x6;
  x7 = makecons(&allocp[22]);
  allocp[24] = (q)(struct goalrec*)&allocp[11];
  allocp[25] = (q)(&predicate_list_xappend_3);
  allocp[26] = a7;
  allocp[27] = x7;
  allocp[28] = x5;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 userdef__typeset_9_7:
  deref_and_jump(x2,userdef__typeset_9_6);
  *reasonp++ =  x2;
  goto userdef__typeset_9_11;
 userdef__typeset_9_8:
  deref_and_jump(x2,userdef__typeset_9_5);
  *reasonp++ =  x2;
  goto userdef__typeset_9_11;
 case VARREF:
  deref_and_jump(x1,userdef__typeset_9_4);
  *reasonp++ =  x1;
  goto userdef__typeset_9_11;
  };
  goto userdef__typeset_9_11;
 userdef__typeset_9_9:
  deref_and_jump(a1,userdef__typeset_9_3);
  *reasonp++ =  a1;
  goto userdef__typeset_9_11;
 case VARREF:
  deref_and_jump(a6,userdef__typeset_9_2);
  *reasonp++ =  a6;
  goto userdef__typeset_9_11;
  };
  goto userdef__typeset_9_11;
 userdef__typeset_9_10:
  if (!isref(a0)) goto userdef__typeset_9_11;
  deref_and_jump(a0,userdef__typeset_9_1);
  *reasonp++ =  a0;
  goto userdef__typeset_9_11;
 userdef__typeset_9_11:
  otherwise(userdef__typeset_9_interrupt);
 userdef__typeset_9_12:
  if (!isint(a0)) goto userdef__typeset_9_20;
  x0 = makeint(0L);
  gblt_greater(a0,x0,userdef__typeset_9_21);
 userdef__typeset_9_13:
  if (isref(a1)) goto userdef__typeset_9_19;
  gblt_arg(a0,a1,x1,userdef__typeset_9_21);
 userdef__typeset_9_14:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_variable_3)) goto userdef__typeset_9_21;
  x2 = arg(x1, 0);
 userdef__typeset_9_15:
  if (isref(x2)) goto userdef__typeset_9_18;
 userdef__typeset_9_16:
  if (isref(x2)) goto userdef__typeset_9_17;
  if_not_equal(x2, a2, userdef__typeset_9_21);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xuserdef__typeset_9);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = x4 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x3;
  allocp[16] = makesym(functor_userdef_5);
  allocp[17] = a3;
  allocp[18] = a4;
  allocp[19] = a5;
  allocp[20] = a0;
  allocp[21] = makesym(atom__2B);
  x5 = makefunctor(&allocp[16]);
  allocp[22] = NILATOM;
  allocp[23] = x5;
  x6 = makecons(&allocp[22]);
  allocp[24] = (q)(struct goalrec*)&allocp[11];
  allocp[25] = (q)(&predicate_list_xappend_3);
  allocp[26] = a7;
  allocp[27] = x6;
  allocp[28] = x4;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 userdef__typeset_9_17:
  deref_and_jump(x2,userdef__typeset_9_16);
  *reasonp++ =  x2;
  goto userdef__typeset_9_21;
 userdef__typeset_9_18:
  deref_and_jump(x2,userdef__typeset_9_15);
  *reasonp++ =  x2;
  goto userdef__typeset_9_21;
 case VARREF:
  deref_and_jump(x1,userdef__typeset_9_14);
  *reasonp++ =  x1;
  goto userdef__typeset_9_21;
  };
  goto userdef__typeset_9_21;
 userdef__typeset_9_19:
  deref_and_jump(a1,userdef__typeset_9_13);
  *reasonp++ =  a1;
  goto userdef__typeset_9_21;
 userdef__typeset_9_20:
  if (!isref(a0)) goto userdef__typeset_9_21;
  deref_and_jump(a0,userdef__typeset_9_12);
  *reasonp++ =  a0;
  goto userdef__typeset_9_21;
 userdef__typeset_9_21:
  otherwise(userdef__typeset_9_interrupt);
 userdef__typeset_9_22:
  if (!isint(a0)) goto userdef__typeset_9_24;
  x0 = makeint(0L);
  gblt_greater(a0,x0,userdef__typeset_9_23);
  x1 = makeint(1L);
  bblt_sub_no_check(a0,x1,x2);
  a0 = x2;
  execute(userdef__typeset_9_0);
  goto userdef__typeset_9_ext_interrupt;
 userdef__typeset_9_23:
  if (a0 != makeint(0L)) goto userdef__typeset_9_interrupt;
  unify(a8, a7);
  proceed();
 userdef__typeset_9_24:
  if (!isref(a0)) goto userdef__typeset_9_interrupt;
  deref_and_jump(a0,userdef__typeset_9_22);
  *reasonp++ =  a0;
  goto userdef__typeset_9_interrupt;
 userdef__typeset_9_ext_interrupt:
  reasonp = 0l;
 userdef__typeset_9_interrupt:
  toppred = &predicate_analyze__type_xuserdef__typeset_9;
  goto interrupt_9;
 }

 indirect__unify_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 indirect__unify_6_clear_reason:
  reasonp = reasons;
 indirect__unify_6_0:
 indirect__unify_6_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 indirect__unify_6_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto indirect__unify_6_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xindirect__unify_6);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_analyze__type_xindirect__unify__clauses_10);
  allocp[10] = makeint(1L);
  allocp[11] = x4 = makeref(&allocp[11]);
  x5 = arg(x0, 0);
  allocp[12] = x5;
  x6 = arg(x0, 1);
  allocp[13] = x6;
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = x2;
  allocp[18] = a4;
  allocp[19] = x3;
  allocp[20] = (q)(struct goalrec*)&allocp[8];
  allocp[21] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[22] = x6;
  allocp[23] = x7 = makeref(&allocp[23]);
  allocp[24] = x4;
  qp = (struct goalrec*)&allocp[20];
  allocp += 25;
  proceed();
 case VARREF:
  deref_and_jump(x0,indirect__unify_6_2);
  *reasonp++ =  x0;
  goto indirect__unify_6_interrupt;
  };
  goto indirect__unify_6_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto indirect__unify_6_interrupt;
  unify2(a5, a4, a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,indirect__unify_6_1);
  *reasonp++ =  a0;
  goto indirect__unify_6_interrupt;
  };
  goto indirect__unify_6_interrupt;
 indirect__unify_6_ext_interrupt:
  reasonp = 0l;
 indirect__unify_6_interrupt:
  toppred = &predicate_analyze__type_xindirect__unify_6;
  goto interrupt_6;
 }

 indirect__unify__clauses_10_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 indirect__unify__clauses_10_clear_reason:
  reasonp = reasons;
 indirect__unify__clauses_10_0:
 indirect__unify__clauses_10_1:
  if (!isint(a0)) goto indirect__unify__clauses_10_5;
 indirect__unify__clauses_10_2:
  if (!isint(a1)) goto indirect__unify__clauses_10_4;
  gblt_less_or_eq(a0,a1,indirect__unify__clauses_10_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xindirect__unify__clauses_10);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x2 = makeref(&allocp[10]);
  allocp[11] = a9;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[14] = a0;
  allocp[15] = makeint(1L);
  allocp[16] = x0;
  allocp[17] = (q)(struct goalrec*)&allocp[12];
  allocp[18] = (q)(&predicate_analyze__type_xindirect__unify__clause_9);
  allocp[19] = a2;
  allocp[20] = a0;
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = a4;
  allocp[23] = a5;
  allocp[24] = a6;
  allocp[25] = x1;
  allocp[26] = a8;
  allocp[27] = x2;
  allocp[28] = (q)(struct goalrec*)&allocp[17];
  allocp[29] = (q)(&predicate_functor__table_xarg_3);
  allocp[30] = a0;
  allocp[31] = a3;
  allocp[32] = x3;
  qp = (struct goalrec*)&allocp[28];
  allocp += 33;
  proceed();
 indirect__unify__clauses_10_3:
  gblt_greater(a0,a1,indirect__unify__clauses_10_interrupt);
  unify2(a9, a8, a7, a6);
  proceed();
 indirect__unify__clauses_10_4:
  if (!isref(a1)) goto indirect__unify__clauses_10_interrupt;
  deref_and_jump(a1,indirect__unify__clauses_10_2);
  *reasonp++ =  a1;
  goto indirect__unify__clauses_10_interrupt;
 indirect__unify__clauses_10_5:
  if (!isref(a0)) goto indirect__unify__clauses_10_interrupt;
  deref_and_jump(a0,indirect__unify__clauses_10_1);
  *reasonp++ =  a0;
  goto indirect__unify__clauses_10_interrupt;
 indirect__unify__clauses_10_ext_interrupt:
  reasonp = 0l;
 indirect__unify__clauses_10_interrupt:
  goto interrupt_10;
 }

 indirect__unify__clause_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 indirect__unify__clause_9_clear_reason:
  reasonp = reasons;
 indirect__unify__clause_9_0:
 indirect__unify__clause_9_1:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (isint(a2)) goto indirect__unify__clause_9_interrupt;
 indirect__unify__clause_9_2:
  gblt_atom(a2,indirect__unify__clause_9_interrupt);
  unify2(a8, a7, a6, a5);
  proceed();
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_clause_4)) goto indirect__unify__clause_9_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xindirect__unify__goals_10);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = makesym(atom_body);
  x0 = arg(a2, 2);
  allocp[5] = x0;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a6;
  allocp[10] = x2 = makeref(&allocp[10]);
  allocp[11] = a8;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_analyze__type_xindirect__unify__goals_10);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = makesym(atom_guard);
  x3 = arg(a2, 1);
  allocp[17] = x3;
  allocp[18] = a3;
  allocp[19] = a4;
  allocp[20] = x4 = makeref(&allocp[20]);
  allocp[21] = x1;
  allocp[22] = x5 = makeref(&allocp[22]);
  allocp[23] = x2;
  x6 = arg(a2, 0);
  x7 = a3;
  a6 = a4;
  x8 = a5;
  a8 = x4;
  a9 = a7;
  a10 = x5;
  a7 = x8;
  a5 = x7;
  a4 = x6;
  a3 = makeint(1L);
  a2 = makesym(atom_head);
  qp = (struct goalrec*)&allocp[12];
  allocp += 24;
  execute(indirect__unify__goal_11_0);
  goto indirect__unify__goal_11_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,indirect__unify__clause_9_1);
  *reasonp++ =  a2;
  goto indirect__unify__clause_9_interrupt;
  };
  goto indirect__unify__clause_9_interrupt;
 indirect__unify__clause_9_ext_interrupt:
  reasonp = 0l;
 indirect__unify__clause_9_interrupt:
  goto interrupt_9;
 }

 indirect__unify__goals_10_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 indirect__unify__goals_10_clear_reason:
  reasonp = reasons;
 indirect__unify__goals_10_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xindirect__unify__goals_12);
  allocp[2] = makeint(1L);
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a3;
  allocp[5] = a0;
  allocp[6] = a1;
  allocp[7] = a2;
  allocp[8] = a4;
  allocp[9] = a5;
  allocp[10] = a6;
  allocp[11] = a7;
  allocp[12] = a8;
  allocp[13] = a9;
  allocp[14] = (q)(struct goalrec*)&allocp[0];
  allocp[15] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[16] = a3;
  allocp[17] = x1 = makeref(&allocp[17]);
  allocp[18] = x0;
  qp = (struct goalrec*)&allocp[14];
  allocp += 19;
  proceed();
 indirect__unify__goals_10_ext_interrupt:
  reasonp = 0l;
 indirect__unify__goals_10_interrupt:
  goto interrupt_10;
 }

 indirect__unify__goals_12_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 indirect__unify__goals_12_clear_reason:
  reasonp = reasons;
 indirect__unify__goals_12_0:
 indirect__unify__goals_12_1:
  if (!isint(a0)) goto indirect__unify__goals_12_5;
 indirect__unify__goals_12_2:
  if (!isint(a1)) goto indirect__unify__goals_12_4;
  gblt_less_or_eq(a0,a1,indirect__unify__goals_12_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xindirect__unify__goals_12);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = x1 = makeref(&allocp[10]);
  allocp[11] = a9;
  allocp[12] = x2 = makeref(&allocp[12]);
  allocp[13] = a11;
  allocp[14] = (q)(struct goalrec*)&allocp[0];
  allocp[15] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[16] = a0;
  allocp[17] = makeint(1L);
  allocp[18] = x0;
  allocp[19] = (q)(struct goalrec*)&allocp[14];
  allocp[20] = (q)(&predicate_analyze__type_xindirect__unify__goal_11);
  allocp[21] = a3;
  allocp[22] = a4;
  allocp[23] = a5;
  allocp[24] = a0;
  allocp[25] = x3 = makeref(&allocp[25]);
  allocp[26] = a6;
  allocp[27] = a7;
  allocp[28] = a8;
  allocp[29] = x1;
  allocp[30] = a10;
  allocp[31] = x2;
  allocp[32] = (q)(struct goalrec*)&allocp[19];
  allocp[33] = (q)(&predicate_functor__table_xarg_3);
  allocp[34] = a0;
  allocp[35] = a2;
  allocp[36] = x3;
  qp = (struct goalrec*)&allocp[32];
  allocp += 37;
  proceed();
 indirect__unify__goals_12_3:
  gblt_greater(a0,a1,indirect__unify__goals_12_interrupt);
  unify2(a11, a10, a9, a8);
  proceed();
 indirect__unify__goals_12_4:
  if (!isref(a1)) goto indirect__unify__goals_12_interrupt;
  deref_and_jump(a1,indirect__unify__goals_12_2);
  *reasonp++ =  a1;
  goto indirect__unify__goals_12_interrupt;
 indirect__unify__goals_12_5:
  if (!isref(a0)) goto indirect__unify__goals_12_interrupt;
  deref_and_jump(a0,indirect__unify__goals_12_1);
  *reasonp++ =  a0;
  goto indirect__unify__goals_12_interrupt;
 indirect__unify__goals_12_ext_interrupt:
  reasonp = 0l;
 indirect__unify__goals_12_interrupt:
  goto interrupt_12;
 }

 indirect__unify__goal_11_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 indirect__unify__goal_11_clear_reason:
  reasonp = reasons;
 indirect__unify__goal_11_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xindirect__unify__args_14);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a0;
  allocp[5] = a1;
  allocp[6] = a2;
  allocp[7] = a3;
  allocp[8] = a4;
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a5;
  allocp[11] = a6;
  allocp[12] = a7;
  allocp[13] = a8;
  allocp[14] = a9;
  allocp[15] = a10;
  allocp[16] = (q)(struct goalrec*)&allocp[0];
  allocp[17] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[18] = x3 = makeref(&allocp[18]);
  allocp[19] = x2;
  allocp[20] = x1;
  allocp[21] = (q)(struct goalrec*)&allocp[16];
  allocp[22] = (q)(&predicate_parse__uty_xdecode__goal_4);
  allocp[23] = a4;
  allocp[24] = x3;
  allocp[25] = x0;
  allocp[26] = x4 = makeref(&allocp[26]);
  qp = (struct goalrec*)&allocp[21];
  allocp += 27;
  proceed();
 indirect__unify__goal_11_ext_interrupt:
  reasonp = 0l;
 indirect__unify__goal_11_interrupt:
  toppred = &predicate_analyze__type_xindirect__unify__goal_11;
  goto interrupt_11;
 }

 indirect__unify__args_14_top: {
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  qp = qp->next;
 indirect__unify__args_14_clear_reason:
  reasonp = reasons;
 indirect__unify__args_14_0:
 indirect__unify__args_14_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto indirect__unify__args_14_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_builtin)):
  a0 = makeint(1L);
  execute(indirect__unify__args2_14_0);
  goto indirect__unify__args2_14_ext_interrupt;
 case symval(makesym(atom_userdef)):
  a0 = makeint(1L);
  execute(indirect__unify__args2_14_0);
  goto indirect__unify__args2_14_ext_interrupt;
  };
  goto indirect__unify__args_14_interrupt;
 case VARREF:
  deref_and_jump(a0,indirect__unify__args_14_1);
  *reasonp++ =  a0;
  goto indirect__unify__args_14_interrupt;
  };
  goto indirect__unify__args_14_interrupt;
 indirect__unify__args_14_ext_interrupt:
  reasonp = 0l;
 indirect__unify__args_14_interrupt:
  goto interrupt_14;
 }

 indirect__unify__args2_14_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  qp = qp->next;
 indirect__unify__args2_14_clear_reason:
  reasonp = reasons;
 indirect__unify__args2_14_0:
 indirect__unify__args2_14_1:
  if (!isint(a0)) goto indirect__unify__args2_14_8;
 indirect__unify__args2_14_2:
  if (!isint(a1)) goto indirect__unify__args2_14_7;
  gblt_less_or_eq(a0,a1,indirect__unify__args2_14_6);
 indirect__unify__args2_14_3:
  if (isref(a6)) goto indirect__unify__args2_14_5;
  gblt_arg(a0,a6,x0,indirect__unify__args2_14_6);
 indirect__unify__args2_14_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_variable_3)) goto indirect__unify__args2_14_6;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xindirect__unify__args2_14);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  allocp[12] = x2 = makeref(&allocp[12]);
  allocp[13] = a11;
  allocp[14] = x3 = makeref(&allocp[14]);
  allocp[15] = a13;
  allocp[16] = (q)(struct goalrec*)&allocp[0];
  allocp[17] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[18] = a0;
  allocp[19] = makeint(1L);
  allocp[20] = x1;
  allocp[21] = makesym(functor_goal_4);
  allocp[22] = a2;
  allocp[23] = a7;
  allocp[24] = a1;
  allocp[25] = a0;
  x4 = makefunctor(&allocp[21]);
  allocp[26] = (q)(struct goalrec*)&allocp[16];
  allocp[27] = (q)(&predicate_analyze__type_xdetermine__typeset2_14);
  allocp[28] = a2;
  allocp[29] = a3;
  allocp[30] = a4;
  allocp[31] = a5;
  x5 = arg(x0, 0);
  allocp[32] = x5;
  x6 = arg(x0, 1);
  allocp[33] = x6;
  allocp[34] = x7 = makeref(&allocp[34]);
  allocp[35] = x4;
  allocp[36] = a8;
  allocp[37] = a9;
  allocp[38] = a10;
  allocp[39] = x2;
  allocp[40] = a12;
  allocp[41] = x3;
  allocp[42] = (q)(struct goalrec*)&allocp[26];
  allocp[43] = (q)(&predicate_vt_xread__iu_5);
  allocp[44] = a10;
  allocp[45] = a2;
  allocp[46] = a3;
  allocp[47] = x5;
  allocp[48] = x7;
  qp = (struct goalrec*)&allocp[42];
  allocp += 49;
  proceed();
 case VARREF:
  deref_and_jump(x0,indirect__unify__args2_14_4);
  *reasonp++ =  x0;
  goto indirect__unify__args2_14_6;
  };
  goto indirect__unify__args2_14_6;
 indirect__unify__args2_14_5:
  deref_and_jump(a6,indirect__unify__args2_14_3);
  *reasonp++ =  a6;
  goto indirect__unify__args2_14_6;
 indirect__unify__args2_14_6:
  gblt_greater(a0,a1,indirect__unify__args2_14_9);
  unify2(a13, a12, a11, a10);
  proceed();
 indirect__unify__args2_14_7:
  if (!isref(a1)) goto indirect__unify__args2_14_9;
  deref_and_jump(a1,indirect__unify__args2_14_2);
  *reasonp++ =  a1;
  goto indirect__unify__args2_14_9;
 indirect__unify__args2_14_8:
  if (!isref(a0)) goto indirect__unify__args2_14_9;
  deref_and_jump(a0,indirect__unify__args2_14_1);
  *reasonp++ =  a0;
  goto indirect__unify__args2_14_9;
 indirect__unify__args2_14_9:
  otherwise(indirect__unify__args2_14_interrupt);
 indirect__unify__args2_14_10:
  if (!isint(a0)) goto indirect__unify__args2_14_13;
 indirect__unify__args2_14_11:
  if (!isint(a1)) goto indirect__unify__args2_14_12;
  gblt_less_or_eq(a0,a1,indirect__unify__args2_14_interrupt);
  x0 = makeint(1L);
  bblt_add_no_check(a0,x0,x1);
  a0 = x1;
  execute(indirect__unify__args2_14_0);
  goto indirect__unify__args2_14_ext_interrupt;
 indirect__unify__args2_14_12:
  if (!isref(a1)) goto indirect__unify__args2_14_interrupt;
  deref_and_jump(a1,indirect__unify__args2_14_11);
  *reasonp++ =  a1;
  goto indirect__unify__args2_14_interrupt;
 indirect__unify__args2_14_13:
  if (!isref(a0)) goto indirect__unify__args2_14_interrupt;
  deref_and_jump(a0,indirect__unify__args2_14_10);
  *reasonp++ =  a0;
  goto indirect__unify__args2_14_interrupt;
 indirect__unify__args2_14_ext_interrupt:
  reasonp = 0l;
 indirect__unify__args2_14_interrupt:
  toppred = &predicate_analyze__type_xindirect__unify__args2_14;
  goto interrupt_14;
 }

 determine__typeset2_14_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  qp = qp->next;
 determine__typeset2_14_clear_reason:
  reasonp = reasons;
 determine__typeset2_14_0:
 determine__typeset2_14_1:
  switch (ptagof(a6)) {
 case CONS:
  x0 = car_of(a6);
 determine__typeset2_14_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_v_4)) goto determine__typeset2_14_3;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type_xdetermine__typeset2_14);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  x1 = cdr_of(a6);
  allocp[8] = x1;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  allocp[12] = x2 = makeref(&allocp[12]);
  allocp[13] = a11;
  allocp[14] = x3 = makeref(&allocp[14]);
  allocp[15] = a13;
  allocp[16] = (q)(struct goalrec*)&allocp[0];
  allocp[17] = (q)(&predicate_analyze__type_xindirect__unify1_17);
  allocp[18] = a0;
  x4 = arg(x0, 0);
  allocp[19] = x4;
  allocp[20] = a1;
  x5 = arg(x0, 1);
  allocp[21] = x5;
  allocp[22] = a4;
  x6 = arg(x0, 2);
  allocp[23] = x6;
  allocp[24] = a5;
  x7 = arg(x0, 3);
  allocp[25] = x7;
  allocp[26] = a3;
  allocp[27] = x8 = makeref(&allocp[27]);
  allocp[28] = a2;
  allocp[29] = x9 = makeref(&allocp[29]);
  allocp[30] = a9;
  allocp[31] = a10;
  allocp[32] = x2;
  allocp[33] = a12;
  allocp[34] = x3;
  allocp[35] = (q)(struct goalrec*)&allocp[16];
  allocp[36] = (q)(&predicate_parse__uty_xget__info_7);
  allocp[37] = x4;
  allocp[38] = x5;
  allocp[39] = x9;
  allocp[40] = x8;
  allocp[41] = x6;
  allocp[42] = x7;
  allocp[43] = a8;
  qp = (struct goalrec*)&allocp[35];
  allocp += 44;
  proceed();
 case VARREF:
  deref_and_jump(x0,determine__typeset2_14_2);
  *reasonp++ =  x0;
  goto determine__typeset2_14_3;
  };
  goto determine__typeset2_14_3;
 case VARREF:
  deref_and_jump(a6,determine__typeset2_14_1);
  *reasonp++ =  a6;
  goto determine__typeset2_14_3;
  };
  goto determine__typeset2_14_3;
 determine__typeset2_14_3:
  otherwise(determine__typeset2_14_interrupt);
 determine__typeset2_14_4:
  switch (ptagof(a6)) {
 case ATOMIC:
  if (a6 != NILATOM) goto determine__typeset2_14_interrupt;
  unify2(a13, a12, a11, a10);
  proceed();
 case VARREF:
  deref_and_jump(a6,determine__typeset2_14_4);
  *reasonp++ =  a6;
  goto determine__typeset2_14_interrupt;
  };
  goto determine__typeset2_14_interrupt;
 determine__typeset2_14_ext_interrupt:
  reasonp = 0l;
 determine__typeset2_14_interrupt:
  goto interrupt_14;
 }

 indirect__unify1_17_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  qp = qp->next;
 indirect__unify1_17_clear_reason:
  reasonp = reasons;
 indirect__unify1_17_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xset_12);
  allocp[2] = a1;
  allocp[3] = a3;
  allocp[4] = a11;
  allocp[5] = a9;
  allocp[6] = a5;
  allocp[7] = a7;
  allocp[8] = x0 = makeref(&allocp[8]);
  allocp[9] = a12;
  allocp[10] = a13;
  allocp[11] = a14;
  allocp[12] = a15;
  allocp[13] = a16;
  allocp[14] = makesym(functor_goal_4);
  allocp[15] = a0;
  allocp[16] = a2;
  allocp[17] = a10;
  allocp[18] = a8;
  x1 = makefunctor(&allocp[14]);
  allocp[19] = (q)(struct goalrec*)&allocp[0];
  allocp[20] = (q)(&predicate_typeset_xadd__dgoal_4);
  allocp[21] = x2 = makeref(&allocp[21]);
  allocp[22] = x1;
  allocp[23] = x0;
  allocp[24] = a12;
  allocp[25] = (q)(struct goalrec*)&allocp[19];
  allocp[26] = (q)(&predicate_typeset_xget_5);
  allocp[27] = a0;
  allocp[28] = a2;
  allocp[29] = a4;
  allocp[30] = x2;
  allocp[31] = a13;
  qp = (struct goalrec*)&allocp[25];
  allocp += 32;
  proceed();
 indirect__unify1_17_ext_interrupt:
  reasonp = 0l;
 indirect__unify1_17_interrupt:
  goto interrupt_17;
 }
 interrupt_18:
  allocp[19] = a17;
 interrupt_17:
  allocp[18] = a16;
 interrupt_16:
  allocp[17] = a15;
 interrupt_15:
  allocp[16] = a14;
 interrupt_14:
  allocp[15] = a13;
 interrupt_13:
  allocp[14] = a12;
 interrupt_12:
  allocp[13] = a11;
 interrupt_11:
  allocp[12] = a10;
 interrupt_10:
  allocp[11] = a9;
 interrupt_9:
  allocp[10] = a8;
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_analyze__type);
}
