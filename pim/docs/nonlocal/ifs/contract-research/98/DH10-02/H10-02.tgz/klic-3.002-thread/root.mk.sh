# Copyright 1993, 1994, 1995 Institute for New Generation Computer Technology
# Read COPYRIGHT for detailed information
# (C)1996, 1997 Japan Information Processing Development Center
# (Read COPYRIGHT-JIPDEC for detailed information.)
#
# Machine-specific definitions
#

cat <<GAZONK >>Makefile

KL1SELFCOMP=kl1cmp

all:	self

install:	install-basics

GAZONK
