/* Compiled by KLIC compiler version 3.002 (Wed Sep 17 15:37:13 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_builtin__type();
Const struct predicate predicate_builtin__type_xinit_5 =
   { module_builtin__type, 0, 5 };
Const struct predicate predicate_builtin__type_xinit_6 =
   { module_builtin__type, 1, 6 };
Const struct predicate predicate_builtin__type_xinit__clauses_7 =
   { module_builtin__type, 2, 7 };
Const struct predicate predicate_builtin__type_xinit__clauses_9 =
   { module_builtin__type, 3, 9 };
Const struct predicate predicate_builtin__type_xinit__clause_8 =
   { module_builtin__type, 4, 8 };
Const struct predicate predicate_builtin__type_xinit__goals_9 =
   { module_builtin__type, 5, 9 };
Const struct predicate predicate_builtin__type_xinit__goals1_11 =
   { module_builtin__type, 6, 11 };
Const struct predicate predicate_builtin__type_xinit__goal_10 =
   { module_builtin__type, 7, 10 };
Const struct predicate predicate_builtin__type_xinit__goal1_11 =
   { module_builtin__type, 8, 11 };
extern Const struct predicate predicate_builtin_xmake__typeset_14;
extern Const struct predicate predicate_integer__arithmetics_xadd_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_xsetarg_4;
extern Const struct predicate predicate_parse__uty_xdecode__goal_3;
extern Const struct predicate predicate_parse__uty_xencode__goal_4;

module module_builtin__type(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  q a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  switch_on_pred() {
    case_pred(0, init_5_top);
    case_pred(1, init_6_top);
    case_pred(2, init__clauses_7_top);
    case_pred(3, init__clauses_9_top);
    case_pred(4, init__clause_8_top);
    case_pred(5, init__goals_9_top);
    case_pred(6, init__goals1_11_top);
    case_pred(7, init__goal_10_top);
    last_case_pred(8, init__goal1_11_top);
  }

 init_5_top: {
  q x0;
  qp = qp->next;
 init_5_clear_reason:
  reasonp = reasons;
 init_5_0:
  x0 = a3;
  a3 = a4;
  a4 = NILATOM;
  a5 = a2;
  a2 = x0;
  execute(init_6_0);
  goto init_6_ext_interrupt;
 init_5_ext_interrupt:
  reasonp = 0l;
 init_5_interrupt:
  goto interrupt_5;
 }

 init_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a5 = qp->args[5];
  qp = qp->next;
 init_6_clear_reason:
  reasonp = reasons;
 init_6_0:
 init_6_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 init_6_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto init_6_interrupt;
  allocp[0] = makesym(functor_module_2);
  x2 = arg(x0, 0);
  allocp[1] = x2;
  allocp[2] = x3 = makeref(&allocp[2]);
  x1 = makefunctor(&allocp[0]);
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = x1;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a1, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin__type_xinit_6);
  x6 = cdr_of(a0);
  allocp[2] = x6;
  allocp[3] = x5;
  allocp[4] = x7 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x8 = makeref(&allocp[6]);
  allocp[7] = a5;
  a0 = arg(x0, 0);
  a1 = arg(x0, 1);
  a3 = a2;
  a5 = a4;
  a6 = x8;
  a4 = x7;
  a2 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  execute(init__clauses_7_0);
  goto init__clauses_7_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,init_6_2);
  *reasonp++ =  x0;
  goto init_6_interrupt;
  };
  goto init_6_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto init_6_interrupt;
  unify2(a5, a4, a3, a2);
  unify_value(a1, a0);
  proceed();
 case VARREF:
  deref_and_jump(a0,init_6_1);
  *reasonp++ =  a0;
  goto init_6_interrupt;
  };
  goto init_6_interrupt;
 init_6_ext_interrupt:
  reasonp = 0l;
 init_6_interrupt:
  toppred = &predicate_builtin__type_xinit_6;
  goto interrupt_6;
 }

 init__clauses_7_top: {
  q x0, x1, x2, x3;
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 init__clauses_7_clear_reason:
  reasonp = reasons;
 init__clauses_7_0:
 init__clauses_7_1:
  if (isref(a1)) goto init__clauses_7_2;
  gblt_pfunctor(a1,x0,init__clauses_7_interrupt);
  gblt_arity(a1,x1,init__clauses_7_interrupt);
  x2 = a3;
  x3 = a4;
  a7 = a5;
  a8 = a6;
  a6 = x3;
  a5 = x2;
  a4 = x1;
  a3 = makeint(1L);
  execute(init__clauses_9_0);
  goto init__clauses_9_ext_interrupt;
 init__clauses_7_2:
  deref_and_jump(a1,init__clauses_7_1);
  *reasonp++ =  a1;
  goto init__clauses_7_interrupt;
 init__clauses_7_ext_interrupt:
  reasonp = 0l;
 init__clauses_7_interrupt:
  toppred = &predicate_builtin__type_xinit__clauses_7;
  goto interrupt_7;
 }

 init__clauses_9_top: {
  q x0, x1, x2, x3, x4, x5;
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 init__clauses_9_clear_reason:
  reasonp = reasons;
 init__clauses_9_0:
 init__clauses_9_1:
  if (!isint(a3)) goto init__clauses_9_5;
 init__clauses_9_2:
  if (!isint(a4)) goto init__clauses_9_4;
  gblt_less_or_eq(a3,a4,init__clauses_9_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin__type_xinit__clauses_9);
  allocp[2] = a0;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = x3 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[13] = a3;
  allocp[14] = makeint(1L);
  allocp[15] = x1;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[18] = a3;
  allocp[19] = a1;
  allocp[20] = x4 = makeref(&allocp[20]);
  allocp[21] = x0;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_builtin__type_xinit__clause_8);
  allocp[24] = a0;
  allocp[25] = a3;
  allocp[26] = x5 = makeref(&allocp[26]);
  allocp[27] = x4;
  allocp[28] = a5;
  allocp[29] = x2;
  allocp[30] = a7;
  allocp[31] = x3;
  allocp[32] = (q)(struct goalrec*)&allocp[22];
  allocp[33] = (q)(&predicate_functor__table_xarg_3);
  allocp[34] = a3;
  allocp[35] = a1;
  allocp[36] = x5;
  qp = (struct goalrec*)&allocp[32];
  allocp += 37;
  proceed();
 init__clauses_9_3:
  gblt_greater(a3,a4,init__clauses_9_interrupt);
  unify3(a8, a7, a6, a5, a2, a1);
  proceed();
 init__clauses_9_4:
  if (!isref(a4)) goto init__clauses_9_interrupt;
  deref_and_jump(a4,init__clauses_9_2);
  *reasonp++ =  a4;
  goto init__clauses_9_interrupt;
 init__clauses_9_5:
  if (!isref(a3)) goto init__clauses_9_interrupt;
  deref_and_jump(a3,init__clauses_9_1);
  *reasonp++ =  a3;
  goto init__clauses_9_interrupt;
 init__clauses_9_ext_interrupt:
  reasonp = 0l;
 init__clauses_9_interrupt:
  toppred = &predicate_builtin__type_xinit__clauses_9;
  goto interrupt_9;
 }

 init__clause_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 init__clause_8_clear_reason:
  reasonp = reasons;
 init__clause_8_0:
 init__clause_8_1:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (isint(a2)) goto init__clause_8_interrupt;
 init__clause_8_2:
  gblt_atom(a2,init__clause_8_interrupt);
  unify2(a7, a6, a5, a4);
  unify_value(a3, a2);
  proceed();
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_clause_4)) goto init__clause_8_interrupt;
  allocp[0] = makesym(functor_functor_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  x2 = arg(a2, 0);
  allocp += 2;
  unify_value(x2, x0);
  allocp[0] = makesym(functor_functor_2);
  allocp[1] = x1;
  allocp[2] = makesym(atom_userdef);
  x3 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_clause_4);
  allocp[4] = x3;
  allocp[5] = x5 = makeref(&allocp[5]);
  allocp[6] = x6 = makeref(&allocp[6]);
  x7 = arg(a2, 3);
  allocp[7] = x7;
  x4 = makefunctor(&allocp[3]);
  allocp += 8;
  unify_value(a3, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin__type_xinit__goals_9);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = makesym(atom_body);
  x8 = arg(a2, 2);
  allocp[5] = x8;
  allocp[6] = x6;
  allocp[7] = x9 = makeref(&allocp[7]);
  allocp[8] = a5;
  allocp[9] = x10 = makeref(&allocp[9]);
  allocp[10] = a7;
  a3 = arg(a2, 1);
  a5 = a4;
  a7 = a6;
  a8 = x10;
  a6 = x9;
  a4 = x5;
  a2 = makesym(atom_guard);
  qp = (struct goalrec*)&allocp[0];
  allocp += 11;
  execute(init__goals_9_0);
  goto init__goals_9_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,init__clause_8_1);
  *reasonp++ =  a2;
  goto init__clause_8_interrupt;
  };
  goto init__clause_8_interrupt;
 init__clause_8_ext_interrupt:
  reasonp = 0l;
 init__clause_8_interrupt:
  goto interrupt_8;
 }

 init__goals_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 init__goals_9_clear_reason:
  reasonp = reasons;
 init__goals_9_0:
 init__goals_9_1:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (isint(a3)) goto init__goals_9_3;
 init__goals_9_2:
  gblt_atom(a3,init__goals_9_3);
  unify2(a8, a7, a6, a5);
  unify_value(a4, a3);
  proceed();
 case VARREF:
  deref_and_jump(a3,init__goals_9_1);
  *reasonp++ =  a3;
  goto init__goals_9_interrupt;
  };
  goto init__goals_9_3;
 init__goals_9_3:
  gblt_pfunctor(a3,x0,init__goals_9_interrupt);
  gblt_arity(a3,x1,init__goals_9_interrupt);
  x2 = a0;
  x3 = a1;
  x4 = a2;
  x5 = a3;
  x6 = a4;
  x7 = a5;
  x8 = a6;
  a9 = a7;
  a10 = a8;
  a8 = x8;
  a7 = x7;
  a6 = x6;
  a5 = x5;
  a4 = x4;
  a3 = x3;
  a2 = x2;
  a1 = x1;
  a0 = makeint(1L);
  execute(init__goals1_11_0);
  goto init__goals1_11_ext_interrupt;
 init__goals_9_ext_interrupt:
  reasonp = 0l;
 init__goals_9_interrupt:
  toppred = &predicate_builtin__type_xinit__goals_9;
  goto interrupt_9;
 }

 init__goals1_11_top: {
  q x0, x1, x2, x3, x4, x5;
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 init__goals1_11_clear_reason:
  reasonp = reasons;
 init__goals1_11_0:
 init__goals1_11_1:
  if (!isint(a0)) goto init__goals1_11_5;
 init__goals1_11_2:
  if (!isint(a1)) goto init__goals1_11_4;
  gblt_less_or_eq(a0,a1,init__goals1_11_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin__type_xinit__goals1_11);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = x3 = makeref(&allocp[11]);
  allocp[12] = a10;
  allocp[13] = (q)(struct goalrec*)&allocp[0];
  allocp[14] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[15] = a0;
  allocp[16] = makeint(1L);
  allocp[17] = x0;
  allocp[18] = (q)(struct goalrec*)&allocp[13];
  allocp[19] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[20] = a0;
  allocp[21] = a5;
  allocp[22] = x4 = makeref(&allocp[22]);
  allocp[23] = x1;
  allocp[24] = (q)(struct goalrec*)&allocp[18];
  allocp[25] = (q)(&predicate_builtin__type_xinit__goal_10);
  allocp[26] = a2;
  allocp[27] = a3;
  allocp[28] = a0;
  allocp[29] = a4;
  allocp[30] = x5 = makeref(&allocp[30]);
  allocp[31] = x4;
  allocp[32] = a7;
  allocp[33] = x2;
  allocp[34] = a9;
  allocp[35] = x3;
  allocp[36] = (q)(struct goalrec*)&allocp[24];
  allocp[37] = (q)(&predicate_functor__table_xarg_3);
  allocp[38] = a0;
  allocp[39] = a5;
  allocp[40] = x5;
  qp = (struct goalrec*)&allocp[36];
  allocp += 41;
  proceed();
 init__goals1_11_3:
  gblt_greater(a0,a1,init__goals1_11_interrupt);
  unify3(a10, a9, a8, a7, a6, a5);
  proceed();
 init__goals1_11_4:
  if (!isref(a1)) goto init__goals1_11_interrupt;
  deref_and_jump(a1,init__goals1_11_2);
  *reasonp++ =  a1;
  goto init__goals1_11_interrupt;
 init__goals1_11_5:
  if (!isref(a0)) goto init__goals1_11_interrupt;
  deref_and_jump(a0,init__goals1_11_1);
  *reasonp++ =  a0;
  goto init__goals1_11_interrupt;
 init__goals1_11_ext_interrupt:
  reasonp = 0l;
 init__goals1_11_interrupt:
  toppred = &predicate_builtin__type_xinit__goals1_11;
  goto interrupt_11;
 }

 init__goal_10_top: {
  q x0, x1, x2;
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 init__goal_10_clear_reason:
  reasonp = reasons;
 init__goal_10_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_parse__uty_xencode__goal_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a5;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_builtin__type_xinit__goal1_11);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  allocp[12] = x0;
  allocp[13] = x2;
  allocp[14] = x1;
  allocp[15] = a6;
  allocp[16] = a7;
  allocp[17] = a8;
  allocp[18] = a9;
  allocp[19] = (q)(struct goalrec*)&allocp[6];
  allocp[20] = (q)(&predicate_parse__uty_xdecode__goal_3);
  allocp[21] = a4;
  allocp[22] = x0;
  allocp[23] = x2;
  qp = (struct goalrec*)&allocp[19];
  allocp += 24;
  proceed();
 init__goal_10_ext_interrupt:
  reasonp = 0l;
 init__goal_10_interrupt:
  goto interrupt_10;
 }

 init__goal1_11_top: {
  q x0, x1, x2;
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 init__goal1_11_clear_reason:
  reasonp = reasons;
 init__goal1_11_0:
 init__goal1_11_1:
  switch (ptagof(a5)) {
 case FUNCTOR:
  if (functor_of(a5) != makesym(functor_options_2)) goto init__goal1_11_5;
  x0 = arg(a5, 0);
 init__goal1_11_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom___)) goto init__goal1_11_5;
 init__goal1_11_3:
  if (isref(a4)) goto init__goal1_11_4;
  gblt_pfunctor(a4,x1,init__goal1_11_5);
  gblt_arity(a4,x2,init__goal1_11_5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin_xmake__typeset_14);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a3;
  allocp[5] = a2;
  allocp[6] = a0;
  allocp[7] = x1;
  allocp[8] = x2;
  allocp[9] = a4;
  allocp[10] = a6;
  allocp[11] = makesym(atom_init);
  allocp[12] = a7;
  allocp[13] = a8;
  allocp[14] = a9;
  allocp[15] = a10;
  qp = (struct goalrec*)&allocp[0];
  allocp += 16;
  proceed();
 init__goal1_11_4:
  deref_and_jump(a4,init__goal1_11_3);
  *reasonp++ =  a4;
  goto init__goal1_11_5;
 case VARREF:
  deref_and_jump(x0,init__goal1_11_2);
  *reasonp++ =  x0;
  goto init__goal1_11_5;
  };
  goto init__goal1_11_5;
 case VARREF:
  deref_and_jump(a5,init__goal1_11_1);
  *reasonp++ =  a5;
  goto init__goal1_11_5;
  };
  goto init__goal1_11_5;
 init__goal1_11_5:
  otherwise(init__goal1_11_interrupt);
 init__goal1_11_6:
  switch (ptagof(a5)) {
 case FUNCTOR:
  if (functor_of(a5) != makesym(functor_options_2)) goto init__goal1_11_interrupt;
 init__goal1_11_7:
  if (isref(a4)) goto init__goal1_11_8;
  gblt_pfunctor(a4,x0,init__goal1_11_interrupt);
  gblt_arity(a4,x1,init__goal1_11_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_builtin_xmake__typeset_14);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a3;
  allocp[5] = a2;
  x2 = arg(a5, 0);
  allocp[6] = x2;
  allocp[7] = x0;
  allocp[8] = x1;
  allocp[9] = a4;
  allocp[10] = a6;
  allocp[11] = makesym(atom_init);
  allocp[12] = a7;
  allocp[13] = a8;
  allocp[14] = a9;
  allocp[15] = a10;
  qp = (struct goalrec*)&allocp[0];
  allocp += 16;
  proceed();
 init__goal1_11_8:
  deref_and_jump(a4,init__goal1_11_7);
  *reasonp++ =  a4;
  goto init__goal1_11_interrupt;
 case VARREF:
  deref_and_jump(a5,init__goal1_11_6);
  *reasonp++ =  a5;
  goto init__goal1_11_interrupt;
  };
  goto init__goal1_11_interrupt;
 init__goal1_11_ext_interrupt:
  reasonp = 0l;
 init__goal1_11_interrupt:
  goto interrupt_11;
 }
 interrupt_11:
  allocp[12] = a10;
 interrupt_10:
  allocp[11] = a9;
 interrupt_9:
  allocp[10] = a8;
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_builtin__type);
}
