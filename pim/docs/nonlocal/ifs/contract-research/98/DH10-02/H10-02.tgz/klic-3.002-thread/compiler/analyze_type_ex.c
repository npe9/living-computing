/* Compiled by KLIC compiler version 3.002 (Wed Sep 17 15:37:13 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_analyze__type__ex();
Const struct predicate predicate_analyze__type__ex_xdetermine_5 =
   { module_analyze__type__ex, 0, 5 };
Const struct predicate predicate_analyze__type__ex_xdetermine__clauses_7 =
   { module_analyze__type__ex, 1, 7 };
Const struct predicate predicate_analyze__type__ex_xdetermine__clause_7 =
   { module_analyze__type__ex, 2, 7 };
Const struct predicate predicate_analyze__type__ex_xdetermine__goals_9 =
   { module_analyze__type__ex, 3, 9 };
Const struct predicate predicate_analyze__type__ex_xdetermine__goal_9 =
   { module_analyze__type__ex, 4, 9 };
Const struct predicate predicate_analyze__type__ex_xdetermine__goal2_11 =
   { module_analyze__type__ex, 5, 11 };
Const struct predicate predicate_analyze__type__ex_xdetermine__goal3_13 =
   { module_analyze__type__ex, 6, 13 };
Const struct predicate predicate_analyze__type__ex_xadd__dep_12 =
   { module_analyze__type__ex, 7, 12 };
Const struct predicate predicate_analyze__type__ex_xadd__dep2_13 =
   { module_analyze__type__ex, 8, 13 };
Const struct predicate predicate_analyze__type__ex_xadd__dep__te_7 =
   { module_analyze__type__ex, 9, 7 };
Const struct predicate predicate_analyze__type__ex_xadd__dep__te2_3 =
   { module_analyze__type__ex, 10, 3 };
Const struct predicate predicate_analyze__type__ex_xget__ts_7 =
   { module_analyze__type__ex, 11, 7 };
Const struct predicate predicate_analyze__type__ex_xget__ts2_6 =
   { module_analyze__type__ex, 12, 6 };
Const struct predicate predicate_analyze__type__ex_xget__ds_7 =
   { module_analyze__type__ex, 13, 7 };
Const struct predicate predicate_analyze__type__ex_xget__ds2_6 =
   { module_analyze__type__ex, 14, 6 };
Const struct predicate predicate_analyze__type__ex_xget__ds3_4 =
   { module_analyze__type__ex, 15, 4 };
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_xfunctor_3;
extern Const struct predicate predicate_parse__uty_xdecode__goalcall_6;
extern Const struct predicate predicate_hb_xcheck__infile_6;
extern Const struct predicate predicate_adg_xget__ad_7;
extern Const struct predicate predicate_vt_xread__ts_5;
extern Const struct predicate predicate_vt_xwrite__ts_6;
extern Const struct predicate predicate_typeset_xadd__dgoals_4;
extern Const struct predicate predicate_typeset_xor__typeset_3;
extern Const struct predicate predicate_depset_xor__depset_3;

module module_analyze__type__ex(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  q a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  switch_on_pred() {
    case_pred(0, determine_5_top);
    case_pred(1, determine__clauses_7_top);
    case_pred(2, determine__clause_7_top);
    case_pred(3, determine__goals_9_top);
    case_pred(4, determine__goal_9_top);
    case_pred(5, determine__goal2_11_top);
    case_pred(6, determine__goal3_13_top);
    case_pred(7, add__dep_12_top);
    case_pred(8, add__dep2_13_top);
    case_pred(9, add__dep__te_7_top);
    case_pred(10, add__dep__te2_3_top);
    case_pred(11, get__ts_7_top);
    case_pred(12, get__ts2_6_top);
    case_pred(13, get__ds_7_top);
    case_pred(14, get__ds2_6_top);
    last_case_pred(15, get__ds3_4_top);
  }

 determine_5_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 determine_5_clear_reason:
  reasonp = reasons;
 determine_5_0:
 determine_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 determine_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto determine_5_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type__ex_xdetermine_5);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_analyze__type__ex_xdetermine__clauses_7);
  allocp[9] = x3 = makeref(&allocp[9]);
  x4 = arg(x0, 1);
  allocp[10] = x4;
  x5 = arg(x0, 0);
  allocp[11] = x5;
  allocp[12] = a1;
  allocp[13] = a2;
  allocp[14] = a3;
  allocp[15] = x2;
  allocp[16] = (q)(struct goalrec*)&allocp[7];
  allocp[17] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[18] = x4;
  allocp[19] = x6 = makeref(&allocp[19]);
  allocp[20] = x3;
  qp = (struct goalrec*)&allocp[16];
  allocp += 21;
  proceed();
 case VARREF:
  deref_and_jump(x0,determine_5_2);
  *reasonp++ =  x0;
  goto determine_5_interrupt;
  };
  goto determine_5_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto determine_5_interrupt;
  unify(a4, a3);
  proceed();
 case VARREF:
  deref_and_jump(a0,determine_5_1);
  *reasonp++ =  a0;
  goto determine_5_interrupt;
  };
  goto determine_5_interrupt;
 determine_5_ext_interrupt:
  reasonp = 0l;
 determine_5_interrupt:
  goto interrupt_5;
 }

 determine__clauses_7_top: {
  q x0, x1, x2, x3;
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 determine__clauses_7_clear_reason:
  reasonp = reasons;
 determine__clauses_7_0:
 determine__clauses_7_1:
  if (!isint(a0)) goto determine__clauses_7_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,determine__clauses_7_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type__ex_xdetermine__clauses_7);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[11] = a0;
  allocp[12] = makeint(1L);
  allocp[13] = x1;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_analyze__type__ex_xdetermine__clause_7);
  allocp[16] = x3 = makeref(&allocp[16]);
  allocp[17] = a2;
  allocp[18] = a0;
  allocp[19] = a3;
  allocp[20] = a4;
  allocp[21] = a5;
  allocp[22] = x2;
  allocp[23] = (q)(struct goalrec*)&allocp[14];
  allocp[24] = (q)(&predicate_functor__table_xarg_3);
  allocp[25] = a0;
  allocp[26] = a1;
  allocp[27] = x3;
  qp = (struct goalrec*)&allocp[23];
  allocp += 28;
  proceed();
 determine__clauses_7_2:
  if (a0 != makeint(0L)) goto determine__clauses_7_interrupt;
  unify(a6, a5);
  proceed();
 determine__clauses_7_3:
  if (!isref(a0)) goto determine__clauses_7_interrupt;
  deref_and_jump(a0,determine__clauses_7_1);
  *reasonp++ =  a0;
  goto determine__clauses_7_interrupt;
 determine__clauses_7_ext_interrupt:
  reasonp = 0l;
 determine__clauses_7_interrupt:
  goto interrupt_7;
 }

 determine__clause_7_top: {
  q x0, x1, x2;
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 determine__clause_7_clear_reason:
  reasonp = reasons;
 determine__clause_7_0:
 determine__clause_7_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_clause_4)) goto determine__clause_7_2;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type__ex_xdetermine__goals_9);
  allocp[2] = x0 = makeref(&allocp[2]);
  x1 = arg(a0, 2);
  allocp[3] = x1;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = makesym(atom_body);
  allocp[7] = a3;
  allocp[8] = a4;
  allocp[9] = a5;
  allocp[10] = a6;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[13] = x1;
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x0;
  qp = (struct goalrec*)&allocp[11];
  allocp += 16;
  proceed();
 case VARREF:
  deref_and_jump(a0,determine__clause_7_1);
  *reasonp++ =  a0;
  goto determine__clause_7_2;
  };
  goto determine__clause_7_2;
 determine__clause_7_2:
  otherwise(determine__clause_7_interrupt);
  unify(a6, a5);
  proceed();
 determine__clause_7_ext_interrupt:
  reasonp = 0l;
 determine__clause_7_interrupt:
  goto interrupt_7;
 }

 determine__goals_9_top: {
  q x0, x1, x2, x3;
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 determine__goals_9_clear_reason:
  reasonp = reasons;
 determine__goals_9_0:
 determine__goals_9_1:
  if (!isint(a0)) goto determine__goals_9_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,determine__goals_9_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type__ex_xdetermine__goals_9);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x1;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_analyze__type__ex_xdetermine__goal_9);
  allocp[18] = x3 = makeref(&allocp[18]);
  allocp[19] = a2;
  allocp[20] = a3;
  allocp[21] = a4;
  allocp[22] = a0;
  allocp[23] = a5;
  allocp[24] = a6;
  allocp[25] = a7;
  allocp[26] = x2;
  allocp[27] = (q)(struct goalrec*)&allocp[16];
  allocp[28] = (q)(&predicate_functor__table_xarg_3);
  allocp[29] = a0;
  allocp[30] = a1;
  allocp[31] = x3;
  qp = (struct goalrec*)&allocp[27];
  allocp += 32;
  proceed();
 determine__goals_9_2:
  if (a0 != makeint(0L)) goto determine__goals_9_interrupt;
  unify(a8, a7);
  proceed();
 determine__goals_9_3:
  if (!isref(a0)) goto determine__goals_9_interrupt;
  deref_and_jump(a0,determine__goals_9_1);
  *reasonp++ =  a0;
  goto determine__goals_9_interrupt;
 determine__goals_9_ext_interrupt:
  reasonp = 0l;
 determine__goals_9_interrupt:
  goto interrupt_9;
 }

 determine__goal_9_top: {
  q x0, x1, x2, x3;
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 determine__goal_9_clear_reason:
  reasonp = reasons;
 determine__goal_9_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type__ex_xdetermine__goal2_11);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = a5;
  allocp[10] = a6;
  allocp[11] = a7;
  allocp[12] = a8;
  allocp[13] = (q)(struct goalrec*)&allocp[0];
  allocp[14] = (q)(&predicate_parse__uty_xdecode__goalcall_6);
  allocp[15] = a1;
  allocp[16] = x1;
  allocp[17] = a0;
  allocp[18] = x0;
  allocp[19] = x3 = makeref(&allocp[19]);
  allocp[20] = x2;
  qp = (struct goalrec*)&allocp[13];
  allocp += 21;
  proceed();
 determine__goal_9_ext_interrupt:
  reasonp = 0l;
 determine__goal_9_interrupt:
  goto interrupt_9;
 }

 determine__goal2_11_top: {
  q x0, x1, x2;
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 determine__goal2_11_clear_reason:
  reasonp = reasons;
 determine__goal2_11_0:
 determine__goal2_11_1:
  switch (ptagof(a6)) {
 case ATOMIC:
  if (a6 != makesym(atom_builtin)) goto determine__goal2_11_2;
  unify(a10, a9);
  proceed();
 case VARREF:
  deref_and_jump(a6,determine__goal2_11_1);
  *reasonp++ =  a6;
  goto determine__goal2_11_2;
  };
  goto determine__goal2_11_2;
 determine__goal2_11_2:
 determine__goal2_11_3:
  if (isref(a1)) goto determine__goal2_11_6;
 determine__goal2_11_4:
  if (isref(a1)) goto determine__goal2_11_5;
  if_not_equal(a1, a5, determine__goal2_11_7);
  unify(a10, a9);
  proceed();
 determine__goal2_11_5:
  deref_and_jump(a1,determine__goal2_11_4);
  *reasonp++ =  a1;
  goto determine__goal2_11_7;
 determine__goal2_11_6:
  deref_and_jump(a1,determine__goal2_11_3);
  *reasonp++ =  a1;
  goto determine__goal2_11_7;
 determine__goal2_11_7:
  otherwise(determine__goal2_11_interrupt);
 determine__goal2_11_8:
  switch (ptagof(a6)) {
 case ATOMIC:
  if (a6 != makesym(atom_userdef)) goto determine__goal2_11_interrupt;
 determine__goal2_11_9:
  if (isref(a1)) goto determine__goal2_11_12;
 determine__goal2_11_10:
  if (isref(a5)) goto determine__goal2_11_11;
  gblt_diff(a1,a5,determine__goal2_11_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type__ex_xdetermine__goal3_13);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = x1 = makeref(&allocp[9]);
  allocp[10] = x2 = makeref(&allocp[10]);
  allocp[11] = a7;
  allocp[12] = a8;
  allocp[13] = a9;
  allocp[14] = a10;
  allocp[15] = (q)(struct goalrec*)&allocp[0];
  allocp[16] = (q)(&predicate_hb_xcheck__infile_6);
  allocp[17] = a5;
  allocp[18] = x1;
  allocp[19] = x2;
  allocp[20] = makesym(atom_head);
  allocp[21] = a7;
  allocp[22] = x0;
  allocp[23] = (q)(struct goalrec*)&allocp[15];
  allocp[24] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[25] = a0;
  allocp[26] = x1;
  allocp[27] = x2;
  qp = (struct goalrec*)&allocp[23];
  allocp += 28;
  proceed();
 determine__goal2_11_11:
  deref_and_jump(a5,determine__goal2_11_10);
  *reasonp++ =  a5;
  goto determine__goal2_11_interrupt;
 determine__goal2_11_12:
  deref_and_jump(a1,determine__goal2_11_9);
  *reasonp++ =  a1;
  goto determine__goal2_11_interrupt;
 case VARREF:
  deref_and_jump(a6,determine__goal2_11_8);
  *reasonp++ =  a6;
  goto determine__goal2_11_interrupt;
  };
  goto determine__goal2_11_interrupt;
 determine__goal2_11_ext_interrupt:
  reasonp = 0l;
 determine__goal2_11_interrupt:
  goto interrupt_11;
 }

 determine__goal3_13_top: {
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  qp = qp->next;
 determine__goal3_13_clear_reason:
  reasonp = reasons;
 determine__goal3_13_0:
 determine__goal3_13_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto determine__goal3_13_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  unify(a12, a11);
  proceed();
 case symval(makesym(atom_no)):
  a0 = a1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  a5 = a6;
  a6 = a7;
  a7 = a8;
  a8 = a9;
  a9 = a10;
  a10 = a11;
  a11 = a12;
  execute(add__dep_12_0);
  goto add__dep_12_ext_interrupt;
  };
  goto determine__goal3_13_interrupt;
 case VARREF:
  deref_and_jump(a0,determine__goal3_13_1);
  *reasonp++ =  a0;
  goto determine__goal3_13_interrupt;
  };
  goto determine__goal3_13_interrupt;
 determine__goal3_13_ext_interrupt:
  reasonp = 0l;
 determine__goal3_13_interrupt:
  goto interrupt_13;
 }

 add__dep_12_top: {
  q x0, x1, x2, x3, x4;
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 add__dep_12_clear_reason:
  reasonp = reasons;
 add__dep_12_0:
  x0 = a7;
  x1 = a7;
  x2 = a8;
  x3 = a9;
  x4 = a10;
  a12 = a11;
  a11 = x4;
  a10 = x3;
  a9 = x2;
  a8 = x1;
  a7 = x0;
  execute(add__dep2_13_0);
  goto add__dep2_13_ext_interrupt;
 add__dep_12_ext_interrupt:
  reasonp = 0l;
 add__dep_12_interrupt:
  toppred = &predicate_analyze__type__ex_xadd__dep_12;
  goto interrupt_12;
 }

 add__dep2_13_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  qp = qp->next;
 add__dep2_13_clear_reason:
  reasonp = reasons;
 add__dep2_13_0:
 add__dep2_13_1:
  if (!isint(a8)) goto add__dep2_13_7;
  x0 = makeint(0L);
  gblt_greater(a8,x0,add__dep2_13_8);
 add__dep2_13_2:
  if (isref(a0)) goto add__dep2_13_6;
  gblt_arg(a8,a0,x1,add__dep2_13_8);
 add__dep2_13_3:
  if (isref(x1)) goto add__dep2_13_5;
  gblt_pfunctor(x1,x2,add__dep2_13_8);
  if (x2 != makesym(atom_variable)) goto add__dep2_13_8;
  gblt_arity(x1,x3,add__dep2_13_8);
 add__dep2_13_4:
  if (x3 != makeint(3L)) goto add__dep2_13_8;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type__ex_xadd__dep2_13);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = x4 = makeref(&allocp[10]);
  allocp[11] = a9;
  allocp[12] = a10;
  allocp[13] = x5 = makeref(&allocp[13]);
  allocp[14] = a12;
  allocp[15] = (q)(struct goalrec*)&allocp[0];
  allocp[16] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[17] = a8;
  allocp[18] = makeint(1L);
  allocp[19] = x4;
  allocp[20] = (q)(struct goalrec*)&allocp[15];
  allocp[21] = (q)(&predicate_analyze__type__ex_xadd__dep__te_7);
  allocp[22] = a1;
  allocp[23] = a2;
  allocp[24] = x1;
  allocp[25] = a8;
  allocp[26] = x6 = makeref(&allocp[26]);
  allocp[27] = a11;
  allocp[28] = x5;
  allocp[29] = (q)(struct goalrec*)&allocp[20];
  allocp[30] = (q)(&predicate_analyze__type__ex_xget__ts_7);
  allocp[31] = a1;
  allocp[32] = a2;
  allocp[33] = a8;
  allocp[34] = x7 = makeref(&allocp[34]);
  allocp[35] = a0;
  allocp[36] = x6;
  allocp[37] = a11;
  allocp[38] = (q)(struct goalrec*)&allocp[29];
  allocp[39] = (q)(&predicate_adg_xget__ad_7);
  allocp[40] = a5;
  allocp[41] = a6;
  allocp[42] = a7;
  allocp[43] = makesym(atom_pred);
  allocp[44] = a8;
  allocp[45] = x7;
  allocp[46] = a10;
  qp = (struct goalrec*)&allocp[38];
  allocp += 47;
  proceed();
 add__dep2_13_5:
  deref_and_jump(x1,add__dep2_13_3);
  *reasonp++ =  x1;
  goto add__dep2_13_8;
 add__dep2_13_6:
  deref_and_jump(a0,add__dep2_13_2);
  *reasonp++ =  a0;
  goto add__dep2_13_8;
 add__dep2_13_7:
  if (!isref(a8)) goto add__dep2_13_8;
  deref_and_jump(a8,add__dep2_13_1);
  *reasonp++ =  a8;
  goto add__dep2_13_8;
 add__dep2_13_8:
  otherwise(add__dep2_13_interrupt);
 add__dep2_13_9:
  if (!isint(a8)) goto add__dep2_13_11;
  x0 = makeint(0L);
  gblt_greater(a8,x0,add__dep2_13_10);
  x1 = makeint(1L);
  bblt_sub_no_check(a8,x1,x2);
  a8 = x2;
  execute(add__dep2_13_0);
  goto add__dep2_13_ext_interrupt;
 add__dep2_13_10:
  if (a8 != makeint(0L)) goto add__dep2_13_interrupt;
  unify(a12, a11);
  proceed();
 add__dep2_13_11:
  if (!isref(a8)) goto add__dep2_13_interrupt;
  deref_and_jump(a8,add__dep2_13_9);
  *reasonp++ =  a8;
  goto add__dep2_13_interrupt;
 add__dep2_13_ext_interrupt:
  reasonp = 0l;
 add__dep2_13_interrupt:
  toppred = &predicate_analyze__type__ex_xadd__dep2_13;
  goto interrupt_13;
 }

 add__dep__te_7_top: {
  q x0, x1, x2;
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 add__dep__te_7_clear_reason:
  reasonp = reasons;
 add__dep__te_7_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vt_xwrite__ts_6);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = a5;
  allocp[7] = a6;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_analyze__type__ex_xadd__dep__te2_3);
  allocp[10] = x2 = makeref(&allocp[10]);
  allocp[11] = x1;
  allocp[12] = a4;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_vt_xread__ts_5);
  allocp[15] = a5;
  allocp[16] = a0;
  allocp[17] = a1;
  allocp[18] = x0;
  allocp[19] = x2;
  allocp[20] = (q)(struct goalrec*)&allocp[13];
  allocp[21] = (q)(&predicate_functor__table_xarg_3);
  allocp[22] = makeint(1L);
  allocp[23] = a2;
  allocp[24] = x0;
  qp = (struct goalrec*)&allocp[20];
  allocp += 25;
  proceed();
 add__dep__te_7_ext_interrupt:
  reasonp = 0l;
 add__dep__te_7_interrupt:
  goto interrupt_7;
 }

 add__dep__te2_3_top: {
  q x0, x1, x2, x3;
  qp = qp->next;
 add__dep__te2_3_clear_reason:
  reasonp = reasons;
 add__dep__te2_3_0:
 add__dep__te2_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 add__dep__te2_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_te_4)) goto add__dep__te2_3_3;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xor__typeset_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a1;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_typeset_xadd__dgoals_4);
  allocp[7] = a2;
  x3 = arg(x0, 3);
  allocp[8] = x3;
  allocp[9] = x2;
  allocp[10] = makesym(atom_normal);
  qp = (struct goalrec*)&allocp[5];
  allocp += 11;
  proceed();
 case VARREF:
  deref_and_jump(x0,add__dep__te2_3_2);
  *reasonp++ =  x0;
  goto add__dep__te2_3_3;
  };
  goto add__dep__te2_3_3;
 case VARREF:
  deref_and_jump(a0,add__dep__te2_3_1);
  *reasonp++ =  a0;
  goto add__dep__te2_3_3;
  };
  goto add__dep__te2_3_3;
 add__dep__te2_3_3:
  otherwise(add__dep__te2_3_interrupt);
 add__dep__te2_3_4:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(add__dep__te2_3_0);
  goto add__dep__te2_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto add__dep__te2_3_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,add__dep__te2_3_4);
  *reasonp++ =  a0;
  goto add__dep__te2_3_interrupt;
  };
  goto add__dep__te2_3_interrupt;
 add__dep__te2_3_ext_interrupt:
  reasonp = 0l;
 add__dep__te2_3_interrupt:
  goto interrupt_3;
 }

 get__ts_7_top: {
  q x0, x1, x2;
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 get__ts_7_clear_reason:
  reasonp = reasons;
 get__ts_7_0:
 get__ts_7_1:
  switch (ptagof(a3)) {
 case CONS:
  x0 = car_of(a3);
 get__ts_7_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_vd_2)) goto get__ts_7_8;
  x1 = arg(x0, 0);
 get__ts_7_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_a_1)) goto get__ts_7_8;
  x2 = arg(x1, 0);
 get__ts_7_4:
  if (isref(x2)) goto get__ts_7_7;
 get__ts_7_5:
  if (isref(x2)) goto get__ts_7_6;
  if_not_equal(x2, a2, get__ts_7_8);
  a2 = arg(x0, 1);
  a3 = a4;
  a4 = a5;
  a5 = a6;
  execute(get__ts2_6_clear_reason);
  goto get__ts2_6_ext_interrupt;
 get__ts_7_6:
  deref_and_jump(x2,get__ts_7_5);
  *reasonp++ =  x2;
  goto get__ts_7_8;
 get__ts_7_7:
  deref_and_jump(x2,get__ts_7_4);
  *reasonp++ =  x2;
  goto get__ts_7_8;
 case VARREF:
  deref_and_jump(x1,get__ts_7_3);
  *reasonp++ =  x1;
  goto get__ts_7_8;
  };
  goto get__ts_7_8;
 case VARREF:
  deref_and_jump(x0,get__ts_7_2);
  *reasonp++ =  x0;
  goto get__ts_7_8;
  };
  goto get__ts_7_8;
 case VARREF:
  deref_and_jump(a3,get__ts_7_1);
  *reasonp++ =  a3;
  goto get__ts_7_8;
  };
  goto get__ts_7_8;
 get__ts_7_8:
  otherwise(get__ts_7_interrupt);
 get__ts_7_9:
  switch (ptagof(a3)) {
 case CONS:
  a3 = cdr_of(a3);
  execute(get__ts_7_0);
  goto get__ts_7_ext_interrupt;
 case ATOMIC:
  if (a3 != NILATOM) goto get__ts_7_interrupt;
  x0 = NILATOM;
  unify_value(a5, x0);
  proceed();
 case VARREF:
  deref_and_jump(a3,get__ts_7_9);
  *reasonp++ =  a3;
  goto get__ts_7_interrupt;
  };
  goto get__ts_7_interrupt;
 get__ts_7_ext_interrupt:
  reasonp = 0l;
 get__ts_7_interrupt:
  goto interrupt_7;
 }

 get__ts2_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 get__ts2_6_clear_reason:
  reasonp = reasons;
 get__ts2_6_0:
 get__ts2_6_1:
  switch (ptagof(a2)) {
 case CONS:
  x0 = car_of(a2);
 get__ts2_6_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_to_2)) goto get__ts2_6_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type__ex_xget__ts2_6);
  allocp[2] = a0;
  allocp[3] = a1;
  x1 = cdr_of(a2);
  allocp[4] = x1;
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = makesym(functor_t_2);
  x4 = arg(x0, 0);
  allocp[9] = x4;
  allocp[10] = x5 = makeref(&allocp[10]);
  x3 = makefunctor(&allocp[8]);
  allocp[11] = x2;
  allocp[12] = x3;
  x6 = makecons(&allocp[11]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 13;
  unify_value(a4, x6);
  x7 = arg(x0, 1);
  x8 = a0;
  a2 = a1;
  a4 = a5;
  a5 = NILATOM;
  a6 = x5;
  a1 = x8;
  a0 = x7;
  execute(get__ds_7_0);
  goto get__ds_7_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,get__ts2_6_2);
  *reasonp++ =  x0;
  goto get__ts2_6_interrupt;
  };
  goto get__ts2_6_interrupt;
 case ATOMIC:
  if (a2 != NILATOM) goto get__ts2_6_interrupt;
  x0 = NILATOM;
  unify_value(a4, x0);
  proceed();
 case VARREF:
  deref_and_jump(a2,get__ts2_6_1);
  *reasonp++ =  a2;
  goto get__ts2_6_interrupt;
  };
  goto get__ts2_6_interrupt;
 get__ts2_6_ext_interrupt:
  reasonp = 0l;
 get__ts2_6_interrupt:
  toppred = &predicate_analyze__type__ex_xget__ts2_6;
  goto interrupt_6;
 }

 get__ds_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 get__ds_7_clear_reason:
  reasonp = reasons;
 get__ds_7_0:
 get__ds_7_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 get__ds_7_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_ti_2)) goto get__ds_7_interrupt;
  x1 = arg(x0, 0);
 get__ds_7_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_a_1)) goto get__ds_7_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type__ex_xget__ds_7);
  x2 = cdr_of(a0);
  allocp[2] = x2;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_depset_xor__depset_3);
  allocp[11] = a5;
  allocp[12] = x4 = makeref(&allocp[12]);
  allocp[13] = x3;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_analyze__type__ex_xget__ds2_6);
  x5 = arg(x0, 1);
  allocp[16] = x5;
  allocp[17] = a1;
  allocp[18] = a2;
  allocp[19] = x6 = makeref(&allocp[19]);
  allocp[20] = a4;
  allocp[21] = x4;
  allocp[22] = (q)(struct goalrec*)&allocp[14];
  allocp[23] = (q)(&predicate_functor__table_xarg_3);
  x7 = arg(x1, 0);
  allocp[24] = x7;
  allocp[25] = a3;
  allocp[26] = x6;
  qp = (struct goalrec*)&allocp[22];
  allocp += 27;
  proceed();
 case VARREF:
  deref_and_jump(x1,get__ds_7_3);
  *reasonp++ =  x1;
  goto get__ds_7_interrupt;
  };
  goto get__ds_7_interrupt;
 case VARREF:
  deref_and_jump(x0,get__ds_7_2);
  *reasonp++ =  x0;
  goto get__ds_7_interrupt;
  };
  goto get__ds_7_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto get__ds_7_interrupt;
  unify(a6, a5);
  proceed();
 case VARREF:
  deref_and_jump(a0,get__ds_7_1);
  *reasonp++ =  a0;
  goto get__ds_7_interrupt;
  };
  goto get__ds_7_interrupt;
 get__ds_7_ext_interrupt:
  reasonp = 0l;
 get__ds_7_interrupt:
  toppred = &predicate_analyze__type__ex_xget__ds_7;
  goto interrupt_7;
 }

 get__ds2_6_top: {
  q x0, x1, x2;
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 get__ds2_6_clear_reason:
  reasonp = reasons;
 get__ds2_6_0:
 get__ds2_6_1:
  switch (ptagof(a3)) {
 case FUNCTOR:
  if (functor_of(a3) != makesym(functor_variable_3)) goto get__ds2_6_3;
  x0 = arg(a3, 2);
 get__ds2_6_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__3F)) goto get__ds2_6_3;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type__ex_xget__ds3_4);
  allocp[2] = a0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = NILATOM;
  allocp[5] = a5;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_vt_xread__ts_5);
  allocp[8] = a4;
  allocp[9] = a1;
  allocp[10] = a2;
  x2 = arg(a3, 0);
  allocp[11] = x2;
  allocp[12] = x1;
  qp = (struct goalrec*)&allocp[6];
  allocp += 13;
  proceed();
 case VARREF:
  deref_and_jump(x0,get__ds2_6_2);
  *reasonp++ =  x0;
  goto get__ds2_6_3;
  };
  goto get__ds2_6_3;
 case VARREF:
  deref_and_jump(a3,get__ds2_6_1);
  *reasonp++ =  a3;
  goto get__ds2_6_3;
  };
  goto get__ds2_6_3;
 get__ds2_6_3:
  otherwise(get__ds2_6_interrupt);
  x0 = NILATOM;
  unify_value(a5, x0);
  proceed();
 get__ds2_6_ext_interrupt:
  reasonp = 0l;
 get__ds2_6_interrupt:
  goto interrupt_6;
 }

 get__ds3_4_top: {
  q x0, x1, x2, x3, x4;
  a3 = qp->args[3];
  qp = qp->next;
 get__ds3_4_clear_reason:
  reasonp = reasons;
 get__ds3_4_0:
 get__ds3_4_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 get__ds3_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_2)) goto get__ds3_4_7;
  x1 = arg(x0, 0);
 get__ds3_4_3:
  if (isref(x1)) goto get__ds3_4_6;
 get__ds3_4_4:
  if (isref(x1)) goto get__ds3_4_5;
  if_not_equal(x1, a0, get__ds3_4_7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyze__type__ex_xget__ds3_4);
  allocp[2] = a0;
  x2 = cdr_of(a1);
  allocp[3] = x2;
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_depset_xor__depset_3);
  allocp[8] = a2;
  x4 = arg(x0, 1);
  allocp[9] = x4;
  allocp[10] = x3;
  qp = (struct goalrec*)&allocp[6];
  allocp += 11;
  proceed();
 get__ds3_4_5:
  deref_and_jump(x1,get__ds3_4_4);
  *reasonp++ =  x1;
  goto get__ds3_4_7;
 get__ds3_4_6:
  deref_and_jump(x1,get__ds3_4_3);
  *reasonp++ =  x1;
  goto get__ds3_4_7;
 case VARREF:
  deref_and_jump(x0,get__ds3_4_2);
  *reasonp++ =  x0;
  goto get__ds3_4_7;
  };
  goto get__ds3_4_7;
 case VARREF:
  deref_and_jump(a1,get__ds3_4_1);
  *reasonp++ =  a1;
  goto get__ds3_4_7;
  };
  goto get__ds3_4_7;
 get__ds3_4_7:
  otherwise(get__ds3_4_interrupt);
 get__ds3_4_8:
  switch (ptagof(a1)) {
 case CONS:
  a1 = cdr_of(a1);
  execute(get__ds3_4_0);
  goto get__ds3_4_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto get__ds3_4_interrupt;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a1,get__ds3_4_8);
  *reasonp++ =  a1;
  goto get__ds3_4_interrupt;
  };
  goto get__ds3_4_interrupt;
 get__ds3_4_ext_interrupt:
  reasonp = 0l;
 get__ds3_4_interrupt:
  goto interrupt_4;
 }
 interrupt_13:
  allocp[14] = a12;
 interrupt_12:
  allocp[13] = a11;
 interrupt_11:
  allocp[12] = a10;
 interrupt_10:
  allocp[11] = a9;
 interrupt_9:
  allocp[10] = a8;
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_analyze__type__ex);
}
