/* Compiled by KLIC compiler version 3.002 (Wed Sep 17 15:37:13 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_print();
Const struct predicate predicate_print_xdata_1 =
   { module_print, 0, 1 };
Const struct predicate predicate_print_xdatan_1 =
   { module_print, 1, 1 };
Const struct predicate predicate_print_xdata_2 =
   { module_print, 2, 2 };
Const struct predicate predicate_print_xdatan_2 =
   { module_print, 3, 2 };
Const struct predicate predicate_print_xlist_2 =
   { module_print, 4, 2 };
Const struct predicate predicate_print_xlist_1 =
   { module_print, 5, 1 };
Const struct predicate predicate_print_xdeps_1 =
   { module_print, 6, 1 };
Const struct predicate predicate_print_xdeps__modules_1 =
   { module_print, 7, 1 };
Const struct predicate predicate_print_xdeps__clauses_3 =
   { module_print, 8, 3 };
Const struct predicate predicate_print_xdeps__goals_1 =
   { module_print, 9, 1 };
Const struct predicate predicate_print_xdeps__goals_3 =
   { module_print, 10, 3 };
Const struct predicate predicate_print_xmodules98_2 =
   { module_print, 11, 2 };
Const struct predicate predicate_print_xclauses98_2 =
   { module_print, 12, 2 };
Const struct predicate predicate_print_xclause98_4 =
   { module_print, 13, 4 };
Const struct predicate predicate_print_xgoal98_2 =
   { module_print, 14, 2 };
Const struct predicate predicate_print_xguards98_2 =
   { module_print, 15, 2 };
Const struct predicate predicate_print_xguards98__a1_4 =
   { module_print, 16, 4 };
Const struct predicate predicate_print_xbodys98_2 =
   { module_print, 17, 2 };
Const struct predicate predicate_print_xbodys98__a1_4 =
   { module_print, 18, 4 };
Const struct predicate predicate_print_xvt__table_2 =
   { module_print, 19, 2 };
Const struct predicate predicate_print_xvt__modules_2 =
   { module_print, 20, 2 };
Const struct predicate predicate_print_xvt__clauses_2 =
   { module_print, 21, 2 };
Const struct predicate predicate_print_xvt__clauses1_4 =
   { module_print, 22, 4 };
Const struct predicate predicate_print_xvt__clause_3 =
   { module_print, 23, 3 };
Const struct predicate predicate_print_xvt__clause1_4 =
   { module_print, 24, 4 };
Const struct predicate predicate_print_xhb__table_2 =
   { module_print, 25, 2 };
Const struct predicate predicate_print_xhb__modules_2 =
   { module_print, 26, 2 };
Const struct predicate predicate_print_xhb__clauses_2 =
   { module_print, 27, 2 };
Const struct predicate predicate_print_xgvt_1 =
   { module_print, 28, 1 };
Const struct predicate predicate_print_xgvt_3 =
   { module_print, 29, 3 };
Const struct predicate predicate_print_xghb_1 =
   { module_print, 30, 1 };
Const struct predicate predicate_print_xghb_3 =
   { module_print, 31, 3 };
Const struct predicate predicate_print_xgea_1 =
   { module_print, 32, 1 };
Const struct predicate predicate_print_xgea_3 =
   { module_print, 33, 3 };
Const struct predicate predicate_print_xvdg_1 =
   { module_print, 34, 1 };
Const struct predicate predicate_print_xvdg__clauses_3 =
   { module_print, 35, 3 };
Const struct predicate predicate_print_xvdg__clause_3 =
   { module_print, 36, 3 };
Const struct predicate predicate_print_xadg_1 =
   { module_print, 37, 1 };
Const struct predicate predicate_print_xadg__preds_1 =
   { module_print, 38, 1 };
extern Const struct predicate predicate_print_xdata_1;
extern Const struct predicate predicate_integer__arithmetics_xadd_3;
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_xfunctor_3;
extern Const struct predicate predicate_io_xoutstream_1;

module module_print(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  static Const q cons_const_0[] = {
    NILATOM,
    makesym(atom_nl),
  };
  static Const q funct_const_1[] = {
    makesym(functor_print_1),
    makesym(atom__20),
  };
  static Const q cons_const_2[] = {
    NILATOM,
    makefunctor(funct_const_1),
  };
  q a0, a1, a2, a3;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  switch_on_pred() {
    case_pred(0, data_1_top);
    case_pred(1, datan_1_top);
    case_pred(2, data_2_top);
    case_pred(3, datan_2_top);
    case_pred(4, list_2_top);
    case_pred(5, list_1_top);
    case_pred(6, deps_1_top);
    case_pred(7, deps__modules_1_top);
    case_pred(8, deps__clauses_3_top);
    case_pred(9, deps__goals_1_top);
    case_pred(10, deps__goals_3_top);
    case_pred(11, modules98_2_top);
    case_pred(12, clauses98_2_top);
    case_pred(13, clause98_4_top);
    case_pred(14, goal98_2_top);
    case_pred(15, guards98_2_top);
    case_pred(16, guards98__a1_4_top);
    case_pred(17, bodys98_2_top);
    case_pred(18, bodys98__a1_4_top);
    case_pred(19, vt__table_2_top);
    case_pred(20, vt__modules_2_top);
    case_pred(21, vt__clauses_2_top);
    case_pred(22, vt__clauses1_4_top);
    case_pred(23, vt__clause_3_top);
    case_pred(24, vt__clause1_4_top);
    case_pred(25, hb__table_2_top);
    case_pred(26, hb__modules_2_top);
    case_pred(27, hb__clauses_2_top);
    case_pred(28, gvt_1_top);
    case_pred(29, gvt_3_top);
    case_pred(30, ghb_1_top);
    case_pred(31, ghb_3_top);
    case_pred(32, gea_1_top);
    case_pred(33, gea_3_top);
    case_pred(34, vdg_1_top);
    case_pred(35, vdg__clauses_3_top);
    case_pred(36, vdg__clause_3_top);
    case_pred(37, adg_1_top);
    last_case_pred(38, adg__preds_1_top);
  }

 data_1_top: {
  q x0, x1;
  qp = qp->next;
 data_1_clear_reason:
  reasonp = reasons;
 data_1_0:
  allocp[0] = makesym(functor_print_1);
  allocp[1] = a0;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = NILATOM;
  allocp[3] = x0;
  x1 = makecons(&allocp[2]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_io_xoutstream_1);
  allocp[6] = x1;
  qp = (struct goalrec*)&allocp[4];
  allocp += 7;
  proceed();
 data_1_ext_interrupt:
  reasonp = 0l;
 data_1_interrupt:
  toppred = &predicate_print_xdata_1;
  goto interrupt_1;
 }

 datan_1_top: {
  q x0, x1;
  qp = qp->next;
 datan_1_clear_reason:
  reasonp = reasons;
 datan_1_0:
  allocp[0] = makesym(functor_print_1);
  allocp[1] = a0;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makecons(cons_const_0);
  allocp[3] = x0;
  x1 = makecons(&allocp[2]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_io_xoutstream_1);
  allocp[6] = x1;
  qp = (struct goalrec*)&allocp[4];
  allocp += 7;
  proceed();
 datan_1_ext_interrupt:
  reasonp = 0l;
 datan_1_interrupt:
  toppred = &predicate_print_xdatan_1;
  goto interrupt_1;
 }

 data_2_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  qp = qp->next;
 data_2_clear_reason:
  reasonp = reasons;
 data_2_0:
 data_2_1:
  if (!isint(a0)) goto data_2_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,data_2_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdata_2);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[6] = a0;
  allocp[7] = makeint(1L);
  allocp[8] = x1;
  allocp[9] = (q)(struct goalrec*)&allocp[4];
  allocp[10] = (q)(&predicate_io_xoutstream_1);
  allocp[11] = makecons(cons_const_2);
  qp = (struct goalrec*)&allocp[9];
  allocp += 12;
  proceed();
 data_2_2:
  if (a0 != makeint(0L)) goto data_2_interrupt;
  allocp[0] = makesym(functor_print_1);
  allocp[1] = a1;
  x2 = makefunctor(&allocp[0]);
  allocp[2] = NILATOM;
  allocp[3] = x2;
  x3 = makecons(&allocp[2]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_io_xoutstream_1);
  allocp[6] = x3;
  qp = (struct goalrec*)&allocp[4];
  allocp += 7;
  proceed();
 data_2_3:
  if (!isref(a0)) goto data_2_interrupt;
  deref_and_jump(a0,data_2_1);
  *reasonp++ =  a0;
  goto data_2_interrupt;
 data_2_ext_interrupt:
  reasonp = 0l;
 data_2_interrupt:
  toppred = &predicate_print_xdata_2;
  goto interrupt_2;
 }

 datan_2_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  qp = qp->next;
 datan_2_clear_reason:
  reasonp = reasons;
 datan_2_0:
 datan_2_1:
  if (!isint(a0)) goto datan_2_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,datan_2_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdatan_2);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[6] = a0;
  allocp[7] = makeint(1L);
  allocp[8] = x1;
  allocp[9] = (q)(struct goalrec*)&allocp[4];
  allocp[10] = (q)(&predicate_io_xoutstream_1);
  allocp[11] = makecons(cons_const_2);
  qp = (struct goalrec*)&allocp[9];
  allocp += 12;
  proceed();
 datan_2_2:
  if (a0 != makeint(0L)) goto datan_2_interrupt;
  allocp[0] = makesym(functor_print_1);
  allocp[1] = a1;
  x2 = makefunctor(&allocp[0]);
  allocp[2] = makecons(cons_const_0);
  allocp[3] = x2;
  x3 = makecons(&allocp[2]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_io_xoutstream_1);
  allocp[6] = x3;
  qp = (struct goalrec*)&allocp[4];
  allocp += 7;
  proceed();
 datan_2_3:
  if (!isref(a0)) goto datan_2_interrupt;
  deref_and_jump(a0,datan_2_1);
  *reasonp++ =  a0;
  goto datan_2_interrupt;
 datan_2_ext_interrupt:
  reasonp = 0l;
 datan_2_interrupt:
  toppred = &predicate_print_xdatan_2;
  goto interrupt_2;
 }

 list_2_top: {
  a1 = qp->args[1];
  qp = qp->next;
 list_2_clear_reason:
  reasonp = reasons;
 list_2_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xlist_1);
  allocp[2] = a1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 3;
  execute(datan_1_0);
  goto datan_1_ext_interrupt;
 list_2_ext_interrupt:
  reasonp = 0l;
 list_2_interrupt:
  goto interrupt_2;
 }

 list_1_top: {
  q x0, x1;
  qp = qp->next;
 list_1_clear_reason:
  reasonp = reasons;
 list_1_0:
 list_1_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xlist_1);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = (q)(struct goalrec*)&allocp[0];
  allocp[4] = (q)(&predicate_print_xdatan_1);
  x1 = car_of(a0);
  allocp[5] = x1;
  a0 = makesym(atom__20_20);
  qp = (struct goalrec*)&allocp[3];
  allocp += 6;
  execute(data_1_0);
  goto data_1_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto list_1_interrupt;
  proceed();
 case VARREF:
  deref_and_jump(a0,list_1_1);
  *reasonp++ =  a0;
  goto list_1_interrupt;
  };
  goto list_1_interrupt;
 list_1_ext_interrupt:
  reasonp = 0l;
 list_1_interrupt:
  goto interrupt_1;
 }

 deps_1_top: {
  qp = qp->next;
 deps_1_clear_reason:
  reasonp = reasons;
 deps_1_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdatan_1);
  allocp[2] = makesym(atom__2D_2D_2D_2D_2D_20Dependencies_20END_20_2D_2D_2D_2D_2D);
  allocp[3] = (q)(struct goalrec*)&allocp[0];
  allocp[4] = (q)(&predicate_print_xdeps__modules_1);
  allocp[5] = a0;
  a0 = makesym(atom__2D_2D_2D_2D_2D_20Dependencies_20BEGIN_20_2D_2D_2D_2D_2D);
  qp = (struct goalrec*)&allocp[3];
  allocp += 6;
  execute(datan_1_0);
  goto datan_1_ext_interrupt;
 deps_1_ext_interrupt:
  reasonp = 0l;
 deps_1_interrupt:
  goto interrupt_1;
 }

 deps__modules_1_top: {
  q x0, x1, x2, x3, x4, x5;
  qp = qp->next;
 deps__modules_1_clear_reason:
  reasonp = reasons;
 deps__modules_1_0:
 deps__modules_1_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 deps__modules_1_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto deps__modules_1_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdeps__modules_1);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = (q)(struct goalrec*)&allocp[0];
  allocp[4] = (q)(&predicate_print_xdeps__clauses_3);
  allocp[5] = makeint(1L);
  allocp[6] = x2 = makeref(&allocp[6]);
  x3 = arg(x0, 1);
  allocp[7] = x3;
  allocp[8] = (q)(struct goalrec*)&allocp[3];
  allocp[9] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[10] = x3;
  allocp[11] = x4 = makeref(&allocp[11]);
  allocp[12] = x2;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_print_xdatan_1);
  x5 = arg(x0, 0);
  allocp[15] = x5;
  a0 = makesym(atom_module_3A);
  qp = (struct goalrec*)&allocp[13];
  allocp += 16;
  execute(data_1_0);
  goto data_1_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,deps__modules_1_2);
  *reasonp++ =  x0;
  goto deps__modules_1_interrupt;
  };
  goto deps__modules_1_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto deps__modules_1_interrupt;
  proceed();
 case VARREF:
  deref_and_jump(a0,deps__modules_1_1);
  *reasonp++ =  a0;
  goto deps__modules_1_interrupt;
  };
  goto deps__modules_1_interrupt;
 deps__modules_1_ext_interrupt:
  reasonp = 0l;
 deps__modules_1_interrupt:
  goto interrupt_1;
 }

 deps__clauses_3_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 deps__clauses_3_clear_reason:
  reasonp = reasons;
 deps__clauses_3_0:
 deps__clauses_3_1:
  if (!isint(a0)) goto deps__clauses_3_7;
 deps__clauses_3_2:
  if (!isint(a1)) goto deps__clauses_3_6;
  gblt_less_or_eq(a0,a1,deps__clauses_3_8);
 deps__clauses_3_3:
  if (isref(a2)) goto deps__clauses_3_5;
  gblt_arg(a0,a2,x0,deps__clauses_3_8);
 deps__clauses_3_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_deps_2)) goto deps__clauses_3_8;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdeps__clauses_3);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[7] = a0;
  allocp[8] = makeint(1L);
  allocp[9] = x1;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_print_xdeps__goals_1);
  x2 = arg(x0, 1);
  allocp[12] = x2;
  allocp[13] = (q)(struct goalrec*)&allocp[10];
  allocp[14] = (q)(&predicate_print_xdatan_1);
  allocp[15] = makesym(atom__20_20_20_20body);
  allocp[16] = (q)(struct goalrec*)&allocp[13];
  allocp[17] = (q)(&predicate_print_xdeps__goals_1);
  x3 = arg(x0, 0);
  allocp[18] = x3;
  allocp[19] = (q)(struct goalrec*)&allocp[16];
  allocp[20] = (q)(&predicate_print_xdatan_1);
  allocp[21] = makesym(atom__20guard);
  qp = (struct goalrec*)&allocp[19];
  allocp += 22;
  execute(data_1_0);
  goto data_1_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,deps__clauses_3_4);
  *reasonp++ =  x0;
  goto deps__clauses_3_8;
  };
  goto deps__clauses_3_8;
 deps__clauses_3_5:
  deref_and_jump(a2,deps__clauses_3_3);
  *reasonp++ =  a2;
  goto deps__clauses_3_8;
 deps__clauses_3_6:
  if (!isref(a1)) goto deps__clauses_3_8;
  deref_and_jump(a1,deps__clauses_3_2);
  *reasonp++ =  a1;
  goto deps__clauses_3_8;
 deps__clauses_3_7:
  if (!isref(a0)) goto deps__clauses_3_8;
  deref_and_jump(a0,deps__clauses_3_1);
  *reasonp++ =  a0;
  goto deps__clauses_3_8;
 deps__clauses_3_8:
  otherwise(deps__clauses_3_interrupt);
 deps__clauses_3_9:
  if (!isint(a0)) goto deps__clauses_3_13;
 deps__clauses_3_10:
  if (!isint(a1)) goto deps__clauses_3_12;
  gblt_less_or_eq(a0,a1,deps__clauses_3_11);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdeps__clauses_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[7] = a0;
  allocp[8] = makeint(1L);
  allocp[9] = x0;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_print_xdatan_1);
  allocp[12] = makesym(atom__20otherwise);
  qp = (struct goalrec*)&allocp[10];
  allocp += 13;
  execute(data_1_0);
  goto data_1_ext_interrupt;
 deps__clauses_3_11:
  gblt_greater(a0,a1,deps__clauses_3_interrupt);
  proceed();
 deps__clauses_3_12:
  if (!isref(a1)) goto deps__clauses_3_interrupt;
  deref_and_jump(a1,deps__clauses_3_10);
  *reasonp++ =  a1;
  goto deps__clauses_3_interrupt;
 deps__clauses_3_13:
  if (!isref(a0)) goto deps__clauses_3_interrupt;
  deref_and_jump(a0,deps__clauses_3_9);
  *reasonp++ =  a0;
  goto deps__clauses_3_interrupt;
 deps__clauses_3_ext_interrupt:
  reasonp = 0l;
 deps__clauses_3_interrupt:
  goto interrupt_3;
 }

 deps__goals_1_top: {
  q x0, x1;
  qp = qp->next;
 deps__goals_1_clear_reason:
  reasonp = reasons;
 deps__goals_1_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdeps__goals_3);
  allocp[2] = makeint(1L);
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a0;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[7] = a0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x0;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 deps__goals_1_ext_interrupt:
  reasonp = 0l;
 deps__goals_1_interrupt:
  goto interrupt_1;
 }

 deps__goals_3_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 deps__goals_3_clear_reason:
  reasonp = reasons;
 deps__goals_3_0:
 deps__goals_3_1:
  if (!isint(a0)) goto deps__goals_3_5;
 deps__goals_3_2:
  if (!isint(a1)) goto deps__goals_3_4;
  gblt_less_or_eq(a0,a1,deps__goals_3_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdeps__goals_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[7] = a0;
  allocp[8] = makeint(1L);
  allocp[9] = x0;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_print_xdatan_1);
  allocp[12] = x1 = makeref(&allocp[12]);
  allocp[13] = (q)(struct goalrec*)&allocp[10];
  allocp[14] = (q)(&predicate_print_xdata_1);
  allocp[15] = makesym(atom__20_20_20_20_20_20);
  allocp[16] = (q)(struct goalrec*)&allocp[13];
  allocp[17] = (q)(&predicate_functor__table_xarg_3);
  allocp[18] = a0;
  allocp[19] = a2;
  allocp[20] = x1;
  qp = (struct goalrec*)&allocp[16];
  allocp += 21;
  proceed();
 deps__goals_3_3:
  gblt_greater(a0,a1,deps__goals_3_interrupt);
  proceed();
 deps__goals_3_4:
  if (!isref(a1)) goto deps__goals_3_interrupt;
  deref_and_jump(a1,deps__goals_3_2);
  *reasonp++ =  a1;
  goto deps__goals_3_interrupt;
 deps__goals_3_5:
  if (!isref(a0)) goto deps__goals_3_interrupt;
  deref_and_jump(a0,deps__goals_3_1);
  *reasonp++ =  a0;
  goto deps__goals_3_interrupt;
 deps__goals_3_ext_interrupt:
  reasonp = 0l;
 deps__goals_3_interrupt:
  goto interrupt_3;
 }

 modules98_2_top: {
  q x0, x1, x2, x3, x4;
  a1 = qp->args[1];
  qp = qp->next;
 modules98_2_clear_reason:
  reasonp = reasons;
 modules98_2_0:
 modules98_2_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 modules98_2_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto modules98_2_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xmodules98_2);
  allocp[2] = a0;
  x1 = cdr_of(a1);
  allocp[3] = x1;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_print_xclauses98_2);
  allocp[6] = x2 = makeref(&allocp[6]);
  x3 = arg(x0, 1);
  allocp[7] = x3;
  allocp[8] = (q)(struct goalrec*)&allocp[4];
  allocp[9] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[10] = a0;
  allocp[11] = makeint(2L);
  allocp[12] = x2;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_print_xdatan_1);
  x4 = arg(x0, 0);
  allocp[15] = x4;
  a1 = makesym(atom_A__MODULE_3A);
  qp = (struct goalrec*)&allocp[13];
  allocp += 16;
  execute(data_2_0);
  goto data_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,modules98_2_2);
  *reasonp++ =  x0;
  goto modules98_2_interrupt;
  };
  goto modules98_2_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto modules98_2_interrupt;
  proceed();
 case VARREF:
  deref_and_jump(a1,modules98_2_1);
  *reasonp++ =  a1;
  goto modules98_2_interrupt;
  };
  goto modules98_2_interrupt;
 modules98_2_ext_interrupt:
  reasonp = 0l;
 modules98_2_interrupt:
  goto interrupt_2;
 }

 clauses98_2_top: {
  q x0, x1;
  a1 = qp->args[1];
  qp = qp->next;
 clauses98_2_clear_reason:
  reasonp = reasons;
 clauses98_2_0:
 clauses98_2_1:
  if (isref(a1)) goto clauses98_2_2;
  gblt_pfunctor(a1,x0,clauses98_2_interrupt);
  gblt_arity(a1,x1,clauses98_2_interrupt);
  a2 = makeint(1L);
  a3 = x1;
  execute(clause98_4_0);
  goto clause98_4_ext_interrupt;
 clauses98_2_2:
  deref_and_jump(a1,clauses98_2_1);
  *reasonp++ =  a1;
  goto clauses98_2_interrupt;
 clauses98_2_ext_interrupt:
  reasonp = 0l;
 clauses98_2_interrupt:
  goto interrupt_2;
 }

 clause98_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 clause98_4_clear_reason:
  reasonp = reasons;
 clause98_4_0:
 clause98_4_1:
  if (!isint(a2)) goto clause98_4_9;
 clause98_4_2:
  if (!isint(a3)) goto clause98_4_8;
  gblt_less_or_eq(a2,a3,clause98_4_7);
 clause98_4_3:
  if (isref(a1)) goto clause98_4_6;
  gblt_arg(a2,a1,x0,clause98_4_7);
 clause98_4_4:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (isint(x0)) goto clause98_4_7;
 clause98_4_5:
  gblt_atom(x0,clause98_4_7);
  x1 = makeint(2L);
  bblt_sub_no_check_y(a0,x1,x2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xclause98_4);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[8] = a2;
  allocp[9] = makeint(1L);
  allocp[10] = x3;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_print_xdatan_2);
  allocp[13] = a0;
  allocp[14] = x0;
  allocp[15] = (q)(struct goalrec*)&allocp[11];
  allocp[16] = (q)(&predicate_print_xdata_1);
  allocp[17] = makesym(atom__20);
  a0 = x2;
  a1 = a2;
  qp = (struct goalrec*)&allocp[15];
  allocp += 18;
  execute(data_2_0);
  goto data_2_ext_interrupt;
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_clause_4)) goto clause98_4_7;
  x1 = makeint(2L);
  bblt_sub_no_check_y(a0,x1,x2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xclause98_4);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[8] = a2;
  allocp[9] = makeint(1L);
  allocp[10] = x3;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_print_xdatan_2);
  allocp[13] = x4 = makeref(&allocp[13]);
  x5 = arg(x0, 3);
  allocp[14] = x5;
  allocp[15] = (q)(struct goalrec*)&allocp[11];
  allocp[16] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[17] = a0;
  allocp[18] = makeint(8L);
  allocp[19] = x4;
  allocp[20] = (q)(struct goalrec*)&allocp[15];
  allocp[21] = (q)(&predicate_print_xbodys98_2);
  allocp[22] = a0;
  x6 = arg(x0, 2);
  allocp[23] = x6;
  allocp[24] = (q)(struct goalrec*)&allocp[20];
  allocp[25] = (q)(&predicate_print_xguards98_2);
  allocp[26] = a0;
  x7 = arg(x0, 1);
  allocp[27] = x7;
  allocp[28] = (q)(struct goalrec*)&allocp[24];
  allocp[29] = (q)(&predicate_print_xgoal98_2);
  allocp[30] = a0;
  x8 = arg(x0, 0);
  allocp[31] = x8;
  allocp[32] = (q)(struct goalrec*)&allocp[28];
  allocp[33] = (q)(&predicate_print_xdata_1);
  allocp[34] = makesym(atom__20);
  a0 = x2;
  a1 = a2;
  qp = (struct goalrec*)&allocp[32];
  allocp += 35;
  execute(data_2_0);
  goto data_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,clause98_4_4);
  *reasonp++ =  x0;
  goto clause98_4_7;
  };
  goto clause98_4_7;
 clause98_4_6:
  deref_and_jump(a1,clause98_4_3);
  *reasonp++ =  a1;
  goto clause98_4_7;
 clause98_4_7:
  gblt_greater(a2,a3,clause98_4_interrupt);
  proceed();
 clause98_4_8:
  if (!isref(a3)) goto clause98_4_interrupt;
  deref_and_jump(a3,clause98_4_2);
  *reasonp++ =  a3;
  goto clause98_4_interrupt;
 clause98_4_9:
  if (!isref(a2)) goto clause98_4_interrupt;
  deref_and_jump(a2,clause98_4_1);
  *reasonp++ =  a2;
  goto clause98_4_interrupt;
 clause98_4_ext_interrupt:
  reasonp = 0l;
 clause98_4_interrupt:
  toppred = &predicate_print_xclause98_4;
  goto interrupt_4;
 }

 goal98_2_top: {
  q x0;
  a1 = qp->args[1];
  qp = qp->next;
 goal98_2_clear_reason:
  reasonp = reasons;
 goal98_2_0:
 goal98_2_1:
  switch (ptagof(a1)) {
 case FUNCTOR:
  switch (symval(functor_of(a1))) {
 case functor_atom_1:
  a1 = arg(a1, 0);
  execute(datan_2_0);
  goto datan_2_ext_interrupt;
 case functor_functor_1:
  a1 = arg(a1, 0);
  execute(datan_2_0);
  goto datan_2_ext_interrupt;
 case functor_functor_2:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdatan_1);
  allocp[2] = makesym(atom_);
  allocp[3] = (q)(struct goalrec*)&allocp[0];
  allocp[4] = (q)(&predicate_print_xdata_1);
  x0 = arg(a1, 1);
  allocp[5] = x0;
  allocp[6] = (q)(struct goalrec*)&allocp[3];
  allocp[7] = (q)(&predicate_print_xdata_1);
  allocp[8] = makesym(atom__2F);
  a1 = arg(a1, 0);
  qp = (struct goalrec*)&allocp[6];
  allocp += 9;
  execute(data_2_0);
  goto data_2_ext_interrupt;
  };
  goto goal98_2_interrupt;
 case VARREF:
  deref_and_jump(a1,goal98_2_1);
  *reasonp++ =  a1;
  goto goal98_2_interrupt;
  };
  goto goal98_2_interrupt;
 goal98_2_ext_interrupt:
  reasonp = 0l;
 goal98_2_interrupt:
  goto interrupt_2;
 }

 guards98_2_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  qp = qp->next;
 guards98_2_clear_reason:
  reasonp = reasons;
 guards98_2_0:
 guards98_2_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (isint(a1)) goto guards98_2_3;
 guards98_2_2:
  gblt_atom(a1,guards98_2_3);
  a1 = makesym(atom__20_3A_2D_20true);
  execute(datan_2_0);
  goto datan_2_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,guards98_2_1);
  *reasonp++ =  a1;
  goto guards98_2_interrupt;
  };
  goto guards98_2_3;
 guards98_2_3:
  gblt_pfunctor(a1,x0,guards98_2_interrupt);
  gblt_arity(a1,x1,guards98_2_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xguards98__a1_4);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = makeint(2L);
  allocp[5] = x1;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[8] = a0;
  allocp[9] = makeint(4L);
  allocp[10] = x2;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_print_xgoal98_2);
  allocp[13] = makeint(0L);
  allocp[14] = x3 = makeref(&allocp[14]);
  allocp[15] = (q)(struct goalrec*)&allocp[11];
  allocp[16] = (q)(&predicate_functor__table_xarg_3);
  allocp[17] = makeint(1L);
  allocp[18] = a1;
  allocp[19] = x3;
  a1 = makesym(atom__20_3A_2D_20);
  qp = (struct goalrec*)&allocp[15];
  allocp += 20;
  execute(data_2_0);
  goto data_2_ext_interrupt;
 guards98_2_ext_interrupt:
  reasonp = 0l;
 guards98_2_interrupt:
  goto interrupt_2;
 }

 guards98__a1_4_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 guards98__a1_4_clear_reason:
  reasonp = reasons;
 guards98__a1_4_0:
 guards98__a1_4_1:
  if (!isint(a2)) goto guards98__a1_4_5;
 guards98__a1_4_2:
  if (!isint(a3)) goto guards98__a1_4_4;
  gblt_less_or_eq(a2,a3,guards98__a1_4_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xguards98__a1_4);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[8] = a2;
  allocp[9] = makeint(1L);
  allocp[10] = x0;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_print_xgoal98_2);
  allocp[13] = a0;
  allocp[14] = x1 = makeref(&allocp[14]);
  allocp[15] = (q)(struct goalrec*)&allocp[11];
  allocp[16] = (q)(&predicate_functor__table_xarg_3);
  allocp[17] = a2;
  allocp[18] = a1;
  allocp[19] = x1;
  qp = (struct goalrec*)&allocp[15];
  allocp += 20;
  proceed();
 guards98__a1_4_3:
  gblt_greater(a2,a3,guards98__a1_4_interrupt);
  proceed();
 guards98__a1_4_4:
  if (!isref(a3)) goto guards98__a1_4_interrupt;
  deref_and_jump(a3,guards98__a1_4_2);
  *reasonp++ =  a3;
  goto guards98__a1_4_interrupt;
 guards98__a1_4_5:
  if (!isref(a2)) goto guards98__a1_4_interrupt;
  deref_and_jump(a2,guards98__a1_4_1);
  *reasonp++ =  a2;
  goto guards98__a1_4_interrupt;
 guards98__a1_4_ext_interrupt:
  reasonp = 0l;
 guards98__a1_4_interrupt:
  goto interrupt_4;
 }

 bodys98_2_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  qp = qp->next;
 bodys98_2_clear_reason:
  reasonp = reasons;
 bodys98_2_0:
 bodys98_2_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (isint(a1)) goto bodys98_2_3;
 bodys98_2_2:
  gblt_atom(a1,bodys98_2_3);
  a1 = makesym(atom__20_20_7C_20true);
  execute(datan_2_0);
  goto datan_2_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,bodys98_2_1);
  *reasonp++ =  a1;
  goto bodys98_2_interrupt;
  };
  goto bodys98_2_3;
 bodys98_2_3:
  gblt_pfunctor(a1,x0,bodys98_2_interrupt);
  gblt_arity(a1,x1,bodys98_2_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xbodys98__a1_4);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = makeint(2L);
  allocp[5] = x1;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[8] = a0;
  allocp[9] = makeint(4L);
  allocp[10] = x2;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_print_xgoal98_2);
  allocp[13] = makeint(0L);
  allocp[14] = x3 = makeref(&allocp[14]);
  allocp[15] = (q)(struct goalrec*)&allocp[11];
  allocp[16] = (q)(&predicate_functor__table_xarg_3);
  allocp[17] = makeint(1L);
  allocp[18] = a1;
  allocp[19] = x3;
  a1 = makesym(atom__20_20_7C_20);
  qp = (struct goalrec*)&allocp[15];
  allocp += 20;
  execute(data_2_0);
  goto data_2_ext_interrupt;
 bodys98_2_ext_interrupt:
  reasonp = 0l;
 bodys98_2_interrupt:
  goto interrupt_2;
 }

 bodys98__a1_4_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 bodys98__a1_4_clear_reason:
  reasonp = reasons;
 bodys98__a1_4_0:
 bodys98__a1_4_1:
  if (!isint(a2)) goto bodys98__a1_4_5;
 bodys98__a1_4_2:
  if (!isint(a3)) goto bodys98__a1_4_4;
  gblt_less_or_eq(a2,a3,bodys98__a1_4_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xbodys98__a1_4);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[8] = a2;
  allocp[9] = makeint(1L);
  allocp[10] = x0;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_print_xgoal98_2);
  allocp[13] = a0;
  allocp[14] = x1 = makeref(&allocp[14]);
  allocp[15] = (q)(struct goalrec*)&allocp[11];
  allocp[16] = (q)(&predicate_functor__table_xarg_3);
  allocp[17] = a2;
  allocp[18] = a1;
  allocp[19] = x1;
  qp = (struct goalrec*)&allocp[15];
  allocp += 20;
  proceed();
 bodys98__a1_4_3:
  gblt_greater(a2,a3,bodys98__a1_4_interrupt);
  proceed();
 bodys98__a1_4_4:
  if (!isref(a3)) goto bodys98__a1_4_interrupt;
  deref_and_jump(a3,bodys98__a1_4_2);
  *reasonp++ =  a3;
  goto bodys98__a1_4_interrupt;
 bodys98__a1_4_5:
  if (!isref(a2)) goto bodys98__a1_4_interrupt;
  deref_and_jump(a2,bodys98__a1_4_1);
  *reasonp++ =  a2;
  goto bodys98__a1_4_interrupt;
 bodys98__a1_4_ext_interrupt:
  reasonp = 0l;
 bodys98__a1_4_interrupt:
  goto interrupt_4;
 }

 vt__table_2_top: {
  a1 = qp->args[1];
  qp = qp->next;
 vt__table_2_clear_reason:
  reasonp = reasons;
 vt__table_2_0:
  execute(vt__modules_2_0);
  goto vt__modules_2_ext_interrupt;
 vt__table_2_ext_interrupt:
  reasonp = 0l;
 vt__table_2_interrupt:
  goto interrupt_2;
 }

 vt__modules_2_top: {
  q x0, x1, x2, x3, x4;
  a1 = qp->args[1];
  qp = qp->next;
 vt__modules_2_clear_reason:
  reasonp = reasons;
 vt__modules_2_0:
 vt__modules_2_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 vt__modules_2_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto vt__modules_2_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xvt__modules_2);
  allocp[2] = a0;
  x1 = cdr_of(a1);
  allocp[3] = x1;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_print_xvt__clauses_2);
  allocp[6] = x2 = makeref(&allocp[6]);
  x3 = arg(x0, 1);
  allocp[7] = x3;
  allocp[8] = (q)(struct goalrec*)&allocp[4];
  allocp[9] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[10] = a0;
  allocp[11] = makeint(2L);
  allocp[12] = x2;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_print_xdatan_1);
  x4 = arg(x0, 0);
  allocp[15] = x4;
  a0 = makesym(atom_MODULE_3A);
  qp = (struct goalrec*)&allocp[13];
  allocp += 16;
  execute(data_1_0);
  goto data_1_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,vt__modules_2_2);
  *reasonp++ =  x0;
  goto vt__modules_2_interrupt;
  };
  goto vt__modules_2_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto vt__modules_2_interrupt;
  proceed();
 case VARREF:
  deref_and_jump(a1,vt__modules_2_1);
  *reasonp++ =  a1;
  goto vt__modules_2_interrupt;
  };
  goto vt__modules_2_interrupt;
 vt__modules_2_ext_interrupt:
  reasonp = 0l;
 vt__modules_2_interrupt:
  toppred = &predicate_print_xvt__modules_2;
  goto interrupt_2;
 }

 vt__clauses_2_top: {
  q x0, x1;
  a1 = qp->args[1];
  qp = qp->next;
 vt__clauses_2_clear_reason:
  reasonp = reasons;
 vt__clauses_2_0:
 vt__clauses_2_1:
  if (isref(a1)) goto vt__clauses_2_2;
  gblt_pfunctor(a1,x0,vt__clauses_2_interrupt);
  if (x0 != makesym(atom_clauses)) goto vt__clauses_2_interrupt;
  gblt_arity(a1,x1,vt__clauses_2_interrupt);
  a2 = makeint(1L);
  a3 = x1;
  execute(vt__clauses1_4_0);
  goto vt__clauses1_4_ext_interrupt;
 vt__clauses_2_2:
  deref_and_jump(a1,vt__clauses_2_1);
  *reasonp++ =  a1;
  goto vt__clauses_2_interrupt;
 vt__clauses_2_ext_interrupt:
  reasonp = 0l;
 vt__clauses_2_interrupt:
  goto interrupt_2;
 }

 vt__clauses1_4_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 vt__clauses1_4_clear_reason:
  reasonp = reasons;
 vt__clauses1_4_0:
 vt__clauses1_4_1:
  if (!isint(a2)) goto vt__clauses1_4_5;
 vt__clauses1_4_2:
  if (!isint(a3)) goto vt__clauses1_4_4;
  gblt_less_or_eq(a2,a3,vt__clauses1_4_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xvt__clauses1_4);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[8] = a2;
  allocp[9] = makeint(1L);
  allocp[10] = x0;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_print_xvt__clause_3);
  allocp[13] = a0;
  allocp[14] = x1 = makeref(&allocp[14]);
  allocp[15] = a2;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_functor__table_xarg_3);
  allocp[18] = a2;
  allocp[19] = a1;
  allocp[20] = x1;
  qp = (struct goalrec*)&allocp[16];
  allocp += 21;
  proceed();
 vt__clauses1_4_3:
  gblt_greater(a2,a3,vt__clauses1_4_interrupt);
  proceed();
 vt__clauses1_4_4:
  if (!isref(a3)) goto vt__clauses1_4_interrupt;
  deref_and_jump(a3,vt__clauses1_4_2);
  *reasonp++ =  a3;
  goto vt__clauses1_4_interrupt;
 vt__clauses1_4_5:
  if (!isref(a2)) goto vt__clauses1_4_interrupt;
  deref_and_jump(a2,vt__clauses1_4_1);
  *reasonp++ =  a2;
  goto vt__clauses1_4_interrupt;
 vt__clauses1_4_ext_interrupt:
  reasonp = 0l;
 vt__clauses1_4_interrupt:
  toppred = &predicate_print_xvt__clauses1_4;
  goto interrupt_4;
 }

 vt__clause_3_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 vt__clause_3_clear_reason:
  reasonp = reasons;
 vt__clause_3_0:
 vt__clause_3_1:
  if (isref(a1)) goto vt__clause_3_2;
  gblt_pfunctor(a1,x0,vt__clause_3_interrupt);
  gblt_arity(a1,x1,vt__clause_3_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xvt__clause1_4);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = makeint(1L);
  allocp[5] = x1;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[8] = a0;
  allocp[9] = makeint(2L);
  allocp[10] = x2;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_print_xdatan_1);
  allocp[13] = a2;
  a1 = makesym(atom_clause_20);
  qp = (struct goalrec*)&allocp[11];
  allocp += 14;
  execute(data_2_0);
  goto data_2_ext_interrupt;
 vt__clause_3_2:
  deref_and_jump(a1,vt__clause_3_1);
  *reasonp++ =  a1;
  goto vt__clause_3_interrupt;
 vt__clause_3_ext_interrupt:
  reasonp = 0l;
 vt__clause_3_interrupt:
  goto interrupt_3;
 }

 vt__clause1_4_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 vt__clause1_4_clear_reason:
  reasonp = reasons;
 vt__clause1_4_0:
 vt__clause1_4_1:
  if (!isint(a2)) goto vt__clause1_4_5;
 vt__clause1_4_2:
  if (!isint(a3)) goto vt__clause1_4_4;
  gblt_less_or_eq(a2,a3,vt__clause1_4_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xvt__clause1_4);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[8] = a2;
  allocp[9] = makeint(1L);
  allocp[10] = x0;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_print_xdatan_1);
  allocp[13] = x1 = makeref(&allocp[13]);
  allocp[14] = (q)(struct goalrec*)&allocp[11];
  allocp[15] = (q)(&predicate_print_xdata_1);
  allocp[16] = makesym(atom__3A);
  allocp[17] = (q)(struct goalrec*)&allocp[14];
  allocp[18] = (q)(&predicate_print_xdata_1);
  allocp[19] = x2 = makeref(&allocp[19]);
  allocp[20] = (q)(struct goalrec*)&allocp[17];
  allocp[21] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[22] = a2;
  allocp[23] = makeint(1L);
  allocp[24] = x2;
  allocp[25] = (q)(struct goalrec*)&allocp[20];
  allocp[26] = (q)(&predicate_print_xdata_2);
  allocp[27] = a0;
  allocp[28] = makesym(atom_V);
  allocp[29] = (q)(struct goalrec*)&allocp[25];
  allocp[30] = (q)(&predicate_functor__table_xarg_3);
  allocp[31] = a2;
  allocp[32] = a1;
  allocp[33] = x1;
  qp = (struct goalrec*)&allocp[29];
  allocp += 34;
  proceed();
 vt__clause1_4_3:
  gblt_greater(a2,a3,vt__clause1_4_interrupt);
  proceed();
 vt__clause1_4_4:
  if (!isref(a3)) goto vt__clause1_4_interrupt;
  deref_and_jump(a3,vt__clause1_4_2);
  *reasonp++ =  a3;
  goto vt__clause1_4_interrupt;
 vt__clause1_4_5:
  if (!isref(a2)) goto vt__clause1_4_interrupt;
  deref_and_jump(a2,vt__clause1_4_1);
  *reasonp++ =  a2;
  goto vt__clause1_4_interrupt;
 vt__clause1_4_ext_interrupt:
  reasonp = 0l;
 vt__clause1_4_interrupt:
  goto interrupt_4;
 }

 hb__table_2_top: {
  a1 = qp->args[1];
  qp = qp->next;
 hb__table_2_clear_reason:
  reasonp = reasons;
 hb__table_2_0:
  execute(hb__modules_2_0);
  goto hb__modules_2_ext_interrupt;
 hb__table_2_ext_interrupt:
  reasonp = 0l;
 hb__table_2_interrupt:
  goto interrupt_2;
 }

 hb__modules_2_top: {
  q x0, x1, x2, x3, x4;
  a1 = qp->args[1];
  qp = qp->next;
 hb__modules_2_clear_reason:
  reasonp = reasons;
 hb__modules_2_0:
 hb__modules_2_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 hb__modules_2_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto hb__modules_2_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xhb__modules_2);
  allocp[2] = a0;
  x1 = cdr_of(a1);
  allocp[3] = x1;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_print_xhb__clauses_2);
  allocp[6] = x2 = makeref(&allocp[6]);
  x3 = arg(x0, 1);
  allocp[7] = x3;
  allocp[8] = (q)(struct goalrec*)&allocp[4];
  allocp[9] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[10] = a0;
  allocp[11] = makeint(2L);
  allocp[12] = x2;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_print_xdatan_1);
  x4 = arg(x0, 0);
  allocp[15] = x4;
  a1 = makesym(atom_Module_3A);
  qp = (struct goalrec*)&allocp[13];
  allocp += 16;
  execute(data_2_0);
  goto data_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,hb__modules_2_2);
  *reasonp++ =  x0;
  goto hb__modules_2_interrupt;
  };
  goto hb__modules_2_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto hb__modules_2_interrupt;
  proceed();
 case VARREF:
  deref_and_jump(a1,hb__modules_2_1);
  *reasonp++ =  a1;
  goto hb__modules_2_interrupt;
  };
  goto hb__modules_2_interrupt;
 hb__modules_2_ext_interrupt:
  reasonp = 0l;
 hb__modules_2_interrupt:
  toppred = &predicate_print_xhb__modules_2;
  goto interrupt_2;
 }

 hb__clauses_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14;
  a1 = qp->args[1];
  qp = qp->next;
 hb__clauses_2_clear_reason:
  reasonp = reasons;
 hb__clauses_2_0:
 hb__clauses_2_1:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = makesym(functor_pred_7);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = x5 = makeref(&allocp[5]);
  allocp[6] = x6 = makeref(&allocp[6]);
  allocp[7] = x7 = makeref(&allocp[7]);
  x0 = makefunctor(&allocp[0]);
  x8 = car_of(a1);
  allocp += 8;
  unify_value(x8, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xhb__clauses_2);
  allocp[2] = a0;
  x9 = cdr_of(a1);
  allocp[3] = x9;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_print_xdatan_2);
  allocp[6] = x10 = makeref(&allocp[6]);
  allocp[7] = x7;
  allocp[8] = (q)(struct goalrec*)&allocp[4];
  allocp[9] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[10] = a0;
  allocp[11] = makeint(2L);
  allocp[12] = x10;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_print_xdatan_2);
  allocp[15] = x11 = makeref(&allocp[15]);
  allocp[16] = x6;
  allocp[17] = (q)(struct goalrec*)&allocp[13];
  allocp[18] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[19] = a0;
  allocp[20] = makeint(2L);
  allocp[21] = x11;
  allocp[22] = (q)(struct goalrec*)&allocp[17];
  allocp[23] = (q)(&predicate_print_xdatan_2);
  allocp[24] = x12 = makeref(&allocp[24]);
  allocp[25] = x5;
  allocp[26] = (q)(struct goalrec*)&allocp[22];
  allocp[27] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[28] = a0;
  allocp[29] = makeint(2L);
  allocp[30] = x12;
  allocp[31] = (q)(struct goalrec*)&allocp[26];
  allocp[32] = (q)(&predicate_print_xdatan_2);
  allocp[33] = x13 = makeref(&allocp[33]);
  allocp[34] = x4;
  allocp[35] = (q)(struct goalrec*)&allocp[31];
  allocp[36] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[37] = a0;
  allocp[38] = makeint(2L);
  allocp[39] = x13;
  allocp[40] = (q)(struct goalrec*)&allocp[35];
  allocp[41] = (q)(&predicate_print_xdatan_2);
  allocp[42] = x14 = makeref(&allocp[42]);
  allocp[43] = x3;
  allocp[44] = (q)(struct goalrec*)&allocp[40];
  allocp[45] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[46] = a0;
  allocp[47] = makeint(2L);
  allocp[48] = x14;
  allocp[49] = (q)(struct goalrec*)&allocp[44];
  allocp[50] = (q)(&predicate_print_xdatan_1);
  allocp[51] = x2;
  allocp[52] = (q)(struct goalrec*)&allocp[49];
  allocp[53] = (q)(&predicate_print_xdata_1);
  allocp[54] = makesym(atom__2F);
  a1 = x1;
  qp = (struct goalrec*)&allocp[52];
  allocp += 55;
  execute(data_2_0);
  goto data_2_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto hb__clauses_2_interrupt;
  proceed();
 case VARREF:
  deref_and_jump(a1,hb__clauses_2_1);
  *reasonp++ =  a1;
  goto hb__clauses_2_interrupt;
  };
  goto hb__clauses_2_interrupt;
 hb__clauses_2_ext_interrupt:
  reasonp = 0l;
 hb__clauses_2_interrupt:
  goto interrupt_2;
 }

 gvt_1_top: {
  q x0, x1;
  qp = qp->next;
 gvt_1_clear_reason:
  reasonp = reasons;
 gvt_1_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xgvt_3);
  allocp[2] = makeint(1L);
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a0;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[7] = a0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x0;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 gvt_1_ext_interrupt:
  reasonp = 0l;
 gvt_1_interrupt:
  goto interrupt_1;
 }

 gvt_3_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 gvt_3_clear_reason:
  reasonp = reasons;
 gvt_3_0:
 gvt_3_1:
  if (!isint(a0)) goto gvt_3_5;
 gvt_3_2:
  if (!isint(a1)) goto gvt_3_4;
  gblt_less_or_eq(a0,a1,gvt_3_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xgvt_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[7] = a0;
  allocp[8] = makeint(1L);
  allocp[9] = x0;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_print_xvt__table_2);
  allocp[12] = makeint(0L);
  allocp[13] = x1 = makeref(&allocp[13]);
  allocp[14] = (q)(struct goalrec*)&allocp[10];
  allocp[15] = (q)(&predicate_functor__table_xarg_3);
  allocp[16] = a0;
  allocp[17] = a2;
  allocp[18] = x1;
  qp = (struct goalrec*)&allocp[14];
  allocp += 19;
  proceed();
 gvt_3_3:
  gblt_greater(a0,a1,gvt_3_interrupt);
  proceed();
 gvt_3_4:
  if (!isref(a1)) goto gvt_3_interrupt;
  deref_and_jump(a1,gvt_3_2);
  *reasonp++ =  a1;
  goto gvt_3_interrupt;
 gvt_3_5:
  if (!isref(a0)) goto gvt_3_interrupt;
  deref_and_jump(a0,gvt_3_1);
  *reasonp++ =  a0;
  goto gvt_3_interrupt;
 gvt_3_ext_interrupt:
  reasonp = 0l;
 gvt_3_interrupt:
  goto interrupt_3;
 }

 ghb_1_top: {
  q x0, x1;
  qp = qp->next;
 ghb_1_clear_reason:
  reasonp = reasons;
 ghb_1_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xghb_3);
  allocp[2] = makeint(1L);
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a0;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[7] = a0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x0;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 ghb_1_ext_interrupt:
  reasonp = 0l;
 ghb_1_interrupt:
  goto interrupt_1;
 }

 ghb_3_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 ghb_3_clear_reason:
  reasonp = reasons;
 ghb_3_0:
 ghb_3_1:
  if (!isint(a0)) goto ghb_3_5;
 ghb_3_2:
  if (!isint(a1)) goto ghb_3_4;
  gblt_less_or_eq(a0,a1,ghb_3_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xghb_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[7] = a0;
  allocp[8] = makeint(1L);
  allocp[9] = x0;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_print_xhb__table_2);
  allocp[12] = makeint(0L);
  allocp[13] = x1 = makeref(&allocp[13]);
  allocp[14] = (q)(struct goalrec*)&allocp[10];
  allocp[15] = (q)(&predicate_functor__table_xarg_3);
  allocp[16] = a0;
  allocp[17] = a2;
  allocp[18] = x1;
  qp = (struct goalrec*)&allocp[14];
  allocp += 19;
  proceed();
 ghb_3_3:
  gblt_greater(a0,a1,ghb_3_interrupt);
  proceed();
 ghb_3_4:
  if (!isref(a1)) goto ghb_3_interrupt;
  deref_and_jump(a1,ghb_3_2);
  *reasonp++ =  a1;
  goto ghb_3_interrupt;
 ghb_3_5:
  if (!isref(a0)) goto ghb_3_interrupt;
  deref_and_jump(a0,ghb_3_1);
  *reasonp++ =  a0;
  goto ghb_3_interrupt;
 ghb_3_ext_interrupt:
  reasonp = 0l;
 ghb_3_interrupt:
  goto interrupt_3;
 }

 gea_1_top: {
  q x0, x1;
  qp = qp->next;
 gea_1_clear_reason:
  reasonp = reasons;
 gea_1_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xgea_3);
  allocp[2] = makeint(1L);
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a0;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[7] = a0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x0;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 gea_1_ext_interrupt:
  reasonp = 0l;
 gea_1_interrupt:
  goto interrupt_1;
 }

 gea_3_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 gea_3_clear_reason:
  reasonp = reasons;
 gea_3_0:
 gea_3_1:
  if (!isint(a0)) goto gea_3_5;
 gea_3_2:
  if (!isint(a1)) goto gea_3_4;
  gblt_less_or_eq(a0,a1,gea_3_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xgea_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[7] = a0;
  allocp[8] = makeint(1L);
  allocp[9] = x0;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_print_xdatan_1);
  allocp[12] = x1 = makeref(&allocp[12]);
  allocp[13] = (q)(struct goalrec*)&allocp[10];
  allocp[14] = (q)(&predicate_functor__table_xarg_3);
  allocp[15] = a0;
  allocp[16] = a2;
  allocp[17] = x1;
  qp = (struct goalrec*)&allocp[13];
  allocp += 18;
  proceed();
 gea_3_3:
  gblt_greater(a0,a1,gea_3_interrupt);
  proceed();
 gea_3_4:
  if (!isref(a1)) goto gea_3_interrupt;
  deref_and_jump(a1,gea_3_2);
  *reasonp++ =  a1;
  goto gea_3_interrupt;
 gea_3_5:
  if (!isref(a0)) goto gea_3_interrupt;
  deref_and_jump(a0,gea_3_1);
  *reasonp++ =  a0;
  goto gea_3_interrupt;
 gea_3_ext_interrupt:
  reasonp = 0l;
 gea_3_interrupt:
  goto interrupt_3;
 }

 vdg_1_top: {
  q x0, x1, x2, x3, x4, x5;
  qp = qp->next;
 vdg_1_clear_reason:
  reasonp = reasons;
 vdg_1_0:
 vdg_1_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 vdg_1_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto vdg_1_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xvdg_1);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = (q)(struct goalrec*)&allocp[0];
  allocp[4] = (q)(&predicate_print_xvdg__clauses_3);
  allocp[5] = makeint(1L);
  allocp[6] = x2 = makeref(&allocp[6]);
  x3 = arg(x0, 1);
  allocp[7] = x3;
  allocp[8] = (q)(struct goalrec*)&allocp[3];
  allocp[9] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[10] = x3;
  allocp[11] = x4 = makeref(&allocp[11]);
  allocp[12] = x2;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_print_xdatan_1);
  x5 = arg(x0, 0);
  allocp[15] = x5;
  allocp[16] = (q)(struct goalrec*)&allocp[13];
  allocp[17] = (q)(&predicate_print_xdata_1);
  allocp[18] = makesym(atom_MODULE_3A);
  qp = (struct goalrec*)&allocp[16];
  allocp += 19;
  proceed();
 case VARREF:
  deref_and_jump(x0,vdg_1_2);
  *reasonp++ =  x0;
  goto vdg_1_interrupt;
  };
  goto vdg_1_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto vdg_1_interrupt;
  proceed();
 case VARREF:
  deref_and_jump(a0,vdg_1_1);
  *reasonp++ =  a0;
  goto vdg_1_interrupt;
  };
  goto vdg_1_interrupt;
 vdg_1_ext_interrupt:
  reasonp = 0l;
 vdg_1_interrupt:
  goto interrupt_1;
 }

 vdg__clauses_3_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 vdg__clauses_3_clear_reason:
  reasonp = reasons;
 vdg__clauses_3_0:
 vdg__clauses_3_1:
  if (!isint(a0)) goto vdg__clauses_3_5;
 vdg__clauses_3_2:
  if (!isint(a1)) goto vdg__clauses_3_4;
  gblt_less_or_eq(a0,a1,vdg__clauses_3_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xvdg__clauses_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[7] = a0;
  allocp[8] = makeint(1L);
  allocp[9] = x0;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_print_xvdg__clause_3);
  allocp[12] = makeint(1L);
  allocp[13] = x1 = makeref(&allocp[13]);
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[17] = x2;
  allocp[18] = x3 = makeref(&allocp[18]);
  allocp[19] = x1;
  allocp[20] = (q)(struct goalrec*)&allocp[15];
  allocp[21] = (q)(&predicate_print_xdatan_1);
  allocp[22] = a0;
  allocp[23] = (q)(struct goalrec*)&allocp[20];
  allocp[24] = (q)(&predicate_print_xdata_1);
  allocp[25] = makesym(atom__20_20);
  allocp[26] = (q)(struct goalrec*)&allocp[23];
  allocp[27] = (q)(&predicate_functor__table_xarg_3);
  allocp[28] = a0;
  allocp[29] = a2;
  allocp[30] = x2;
  qp = (struct goalrec*)&allocp[26];
  allocp += 31;
  proceed();
 vdg__clauses_3_3:
  gblt_greater(a0,a1,vdg__clauses_3_interrupt);
  proceed();
 vdg__clauses_3_4:
  if (!isref(a1)) goto vdg__clauses_3_interrupt;
  deref_and_jump(a1,vdg__clauses_3_2);
  *reasonp++ =  a1;
  goto vdg__clauses_3_interrupt;
 vdg__clauses_3_5:
  if (!isref(a0)) goto vdg__clauses_3_interrupt;
  deref_and_jump(a0,vdg__clauses_3_1);
  *reasonp++ =  a0;
  goto vdg__clauses_3_interrupt;
 vdg__clauses_3_ext_interrupt:
  reasonp = 0l;
 vdg__clauses_3_interrupt:
  goto interrupt_3;
 }

 vdg__clause_3_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 vdg__clause_3_clear_reason:
  reasonp = reasons;
 vdg__clause_3_0:
 vdg__clause_3_1:
  if (!isint(a0)) goto vdg__clause_3_5;
 vdg__clause_3_2:
  if (!isint(a1)) goto vdg__clause_3_4;
  gblt_less_or_eq(a0,a1,vdg__clause_3_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xvdg__clause_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[7] = a0;
  allocp[8] = makeint(1L);
  allocp[9] = x0;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_print_xdatan_1);
  allocp[12] = x1 = makeref(&allocp[12]);
  allocp[13] = (q)(struct goalrec*)&allocp[10];
  allocp[14] = (q)(&predicate_functor__table_xarg_3);
  allocp[15] = a0;
  allocp[16] = a2;
  allocp[17] = x1;
  allocp[18] = (q)(struct goalrec*)&allocp[13];
  allocp[19] = (q)(&predicate_print_xdata_1);
  allocp[20] = makesym(atom__29_3A);
  allocp[21] = (q)(struct goalrec*)&allocp[18];
  allocp[22] = (q)(&predicate_print_xdata_1);
  allocp[23] = x2 = makeref(&allocp[23]);
  allocp[24] = (q)(struct goalrec*)&allocp[21];
  allocp[25] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[26] = a0;
  allocp[27] = makeint(1L);
  allocp[28] = x2;
  a0 = makesym(atom__20_20_20_20variable_28);
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  execute(data_1_0);
  goto data_1_ext_interrupt;
 vdg__clause_3_3:
  gblt_greater(a0,a1,vdg__clause_3_interrupt);
  proceed();
 vdg__clause_3_4:
  if (!isref(a1)) goto vdg__clause_3_interrupt;
  deref_and_jump(a1,vdg__clause_3_2);
  *reasonp++ =  a1;
  goto vdg__clause_3_interrupt;
 vdg__clause_3_5:
  if (!isref(a0)) goto vdg__clause_3_interrupt;
  deref_and_jump(a0,vdg__clause_3_1);
  *reasonp++ =  a0;
  goto vdg__clause_3_interrupt;
 vdg__clause_3_ext_interrupt:
  reasonp = 0l;
 vdg__clause_3_interrupt:
  goto interrupt_3;
 }

 adg_1_top: {
  q x0, x1, x2, x3;
  qp = qp->next;
 adg_1_clear_reason:
  reasonp = reasons;
 adg_1_0:
 adg_1_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 adg_1_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto adg_1_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xadg_1);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = (q)(struct goalrec*)&allocp[0];
  allocp[4] = (q)(&predicate_print_xadg__preds_1);
  x2 = arg(x0, 1);
  allocp[5] = x2;
  allocp[6] = (q)(struct goalrec*)&allocp[3];
  allocp[7] = (q)(&predicate_print_xdatan_1);
  x3 = arg(x0, 0);
  allocp[8] = x3;
  a0 = makesym(atom_MODULE_3A);
  qp = (struct goalrec*)&allocp[6];
  allocp += 9;
  execute(data_1_0);
  goto data_1_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,adg_1_2);
  *reasonp++ =  x0;
  goto adg_1_interrupt;
  };
  goto adg_1_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto adg_1_interrupt;
  proceed();
 case VARREF:
  deref_and_jump(a0,adg_1_1);
  *reasonp++ =  a0;
  goto adg_1_interrupt;
  };
  goto adg_1_interrupt;
 adg_1_ext_interrupt:
  reasonp = 0l;
 adg_1_interrupt:
  goto interrupt_1;
 }

 adg__preds_1_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  qp = qp->next;
 adg__preds_1_clear_reason:
  reasonp = reasons;
 adg__preds_1_0:
 adg__preds_1_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 adg__preds_1_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_entry_8)) goto adg__preds_1_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xadg__preds_1);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = (q)(struct goalrec*)&allocp[0];
  allocp[4] = (q)(&predicate_print_xdatan_1);
  x2 = arg(x0, 7);
  allocp[5] = x2;
  allocp[6] = (q)(struct goalrec*)&allocp[3];
  allocp[7] = (q)(&predicate_print_xdata_1);
  allocp[8] = makesym(atom__20_20_20_20);
  allocp[9] = (q)(struct goalrec*)&allocp[6];
  allocp[10] = (q)(&predicate_print_xdatan_1);
  x3 = arg(x0, 6);
  allocp[11] = x3;
  allocp[12] = (q)(struct goalrec*)&allocp[9];
  allocp[13] = (q)(&predicate_print_xdata_1);
  allocp[14] = makesym(atom__20_20_20_20);
  allocp[15] = (q)(struct goalrec*)&allocp[12];
  allocp[16] = (q)(&predicate_print_xdatan_1);
  x4 = arg(x0, 5);
  allocp[17] = x4;
  allocp[18] = (q)(struct goalrec*)&allocp[15];
  allocp[19] = (q)(&predicate_print_xdata_1);
  allocp[20] = makesym(atom__20_20_20_20);
  allocp[21] = (q)(struct goalrec*)&allocp[18];
  allocp[22] = (q)(&predicate_print_xdatan_1);
  x5 = arg(x0, 4);
  allocp[23] = x5;
  allocp[24] = (q)(struct goalrec*)&allocp[21];
  allocp[25] = (q)(&predicate_print_xdata_1);
  allocp[26] = makesym(atom__20_20_20_20);
  allocp[27] = (q)(struct goalrec*)&allocp[24];
  allocp[28] = (q)(&predicate_print_xdatan_1);
  x6 = arg(x0, 3);
  allocp[29] = x6;
  allocp[30] = (q)(struct goalrec*)&allocp[27];
  allocp[31] = (q)(&predicate_print_xdata_1);
  allocp[32] = makesym(atom__20_20_20_20);
  allocp[33] = (q)(struct goalrec*)&allocp[30];
  allocp[34] = (q)(&predicate_print_xdatan_1);
  x7 = arg(x0, 2);
  allocp[35] = x7;
  allocp[36] = (q)(struct goalrec*)&allocp[33];
  allocp[37] = (q)(&predicate_print_xdata_1);
  allocp[38] = makesym(atom__20_20_20_20);
  allocp[39] = (q)(struct goalrec*)&allocp[36];
  allocp[40] = (q)(&predicate_print_xdatan_1);
  x8 = arg(x0, 1);
  allocp[41] = x8;
  allocp[42] = (q)(struct goalrec*)&allocp[39];
  allocp[43] = (q)(&predicate_print_xdata_1);
  allocp[44] = makesym(atom__2F);
  allocp[45] = (q)(struct goalrec*)&allocp[42];
  allocp[46] = (q)(&predicate_print_xdata_1);
  x9 = arg(x0, 0);
  allocp[47] = x9;
  a0 = makesym(atom__20_20);
  qp = (struct goalrec*)&allocp[45];
  allocp += 48;
  execute(data_1_0);
  goto data_1_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,adg__preds_1_2);
  *reasonp++ =  x0;
  goto adg__preds_1_interrupt;
  };
  goto adg__preds_1_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto adg__preds_1_interrupt;
  proceed();
 case VARREF:
  deref_and_jump(a0,adg__preds_1_1);
  *reasonp++ =  a0;
  goto adg__preds_1_interrupt;
  };
  goto adg__preds_1_interrupt;
 adg__preds_1_ext_interrupt:
  reasonp = 0l;
 adg__preds_1_interrupt:
  goto interrupt_1;
 }
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_print);
}
