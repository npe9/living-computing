/* Compiled by KLIC compiler version 3.002 (Wed Sep 17 15:37:13 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_kl1cmp1();
Const struct predicate predicate_kl1cmp1_xklcmp_2 =
   { module_kl1cmp1, 0, 2 };
Const struct predicate predicate_kl1cmp1_xklcmp_2F2_240_4 =
   { module_kl1cmp1, 1, 4 };
Const struct predicate predicate_kl1cmp1_xklcmp1_4 =
   { module_kl1cmp1, 2, 4 };
Const struct predicate predicate_kl1cmp1_xcompile_3 =
   { module_kl1cmp1, 3, 3 };
Const struct predicate predicate_kl1cmp1_xcompile1_3 =
   { module_kl1cmp1, 4, 3 };
Const struct predicate predicate_kl1cmp1_xclose__streams_1 =
   { module_kl1cmp1, 5, 1 };
Const struct predicate predicate_kl1cmp1_xread__in_5 =
   { module_kl1cmp1, 6, 5 };
Const struct predicate predicate_kl1cmp1_xread__inline_7 =
   { module_kl1cmp1, 7, 7 };
Const struct predicate predicate_kl1cmp1_xread__all_6 =
   { module_kl1cmp1, 8, 6 };
Const struct predicate predicate_kl1cmp1_xread__all__1_6 =
   { module_kl1cmp1, 9, 6 };
Const struct predicate predicate_kl1cmp1_xread__one__module_7 =
   { module_kl1cmp1, 10, 7 };
Const struct predicate predicate_kl1cmp1_xhandle__exception_1 =
   { module_kl1cmp1, 11, 1 };
Const struct predicate predicate_kl1cmp1_xhandle__exception_3 =
   { module_kl1cmp1, 12, 3 };
Const struct predicate predicate_kl1cmp1_xcomplain__tokens_6 =
   { module_kl1cmp1, 13, 6 };
Const struct predicate predicate_kl1cmp1_xcomplain__tokens_3 =
   { module_kl1cmp1, 14, 3 };
Const struct predicate predicate_kl1cmp1_xcomplain__token_3 =
   { module_kl1cmp1, 15, 3 };
Const struct predicate predicate_kl1cmp1_xcomplain__string_3 =
   { module_kl1cmp1, 16, 3 };
Const struct predicate predicate_kl1cmp1_xcomplain__words_3 =
   { module_kl1cmp1, 17, 3 };
extern Const struct predicate predicate_integer__arithmetics_xadd_3;
extern Const struct predicate predicate_klic__comp__message_xreport__error_2;
extern Const struct predicate predicate_klic__comp__message_xsee_2;
extern Const struct predicate predicate_klic__comp__message_xtell_2;
extern Const struct predicate predicate_klic__comp__message_xcompilation__error_1;
extern Const struct predicate predicate_keyed__set_xcreate_1;
extern Const struct predicate predicate_analyzer_xanalyzer1_3;
extern Const struct predicate predicate_file__op_xmake__mid_2;
extern Const struct predicate predicate_klic__comp__cmacro_xinsDefs_3;
extern Const struct predicate predicate_klic__comp__cmacro_xreplaceClause_4;
extern Const struct predicate predicate_klic__comp__macro_xmacro_2;
extern Const struct predicate predicate_klic__comp__obj_xflush_3;
extern Const struct predicate predicate_klic__comp__obj_xklicformat_3;
extern Const struct predicate predicate_klic__comp__obj_xklicformat_4;
extern Const struct predicate predicate_klic__comp__util_xstring__to__char__list_2;
declare_method_table_of(vector);

module module_kl1cmp1(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_0 =
      declare_string_constant_8(0,0);
  static Const unsigned char strconst_body_1[16] =
    "\n*** Here ***\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_1 =
      declare_string_constant_8(strconst_body_1,14);
  static Const unsigned char strconst_body_2[40] =
    "!! Error !!\nTL = ~w\nReason = ~wPs = \n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_2 =
      declare_string_constant_8(strconst_body_2,37);
  static Const unsigned char strconst_body_3[4] =
    ".\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_3 =
      declare_string_constant_8(strconst_body_3,2);
  static Const unsigned char strconst_body_4[4] =
    {'.','k','l','1',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_4 =
      declare_string_constant_8(strconst_body_4,4);
  static Const unsigned char strconst_body_5[40] =
    "File name extension of ~s is not kl1\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_5 =
      declare_string_constant_8(strconst_body_5,37);
  static Const unsigned char strconst_body_6[32] =
    "Module declaration is not found";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_6 =
      declare_string_constant_8(strconst_body_6,31);
  static Const unsigned char strconst_body_7[32] =
    "Module name is not an atom :~w";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_7 =
      declare_string_constant_8(strconst_body_7,30);
  static Const unsigned char strconst_body_8[16] =
    "Syntax error: ";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_8 =
      declare_string_constant_8(strconst_body_8,14);
  static Const unsigned char strconst_body_9[4] =
    "\\\"";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_9 =
      declare_string_constant_8(strconst_body_9,2);
  static Const unsigned char strconst_body_10[4] =
    "~c";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_10 =
      declare_string_constant_8(strconst_body_10,2);
  static Const unsigned char strconst_body_11[4] =
    "~s";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_11 =
      declare_string_constant_8(strconst_body_11,2);
  static Const unsigned char strconst_body_12[4] =
    "~w";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_12 =
      declare_string_constant_8(strconst_body_12,2);
  static Const unsigned char strconst_body_13[4] =
    "~w\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_13 =
      declare_string_constant_8(strconst_body_13,3);
  static Const unsigned char strconst_body_14[4] =
    "~w(";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_14 =
      declare_string_constant_8(strconst_body_14,3);
  static Const unsigned char strconst_body_15[4] =
    {'~','w','~','c',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_15 =
      declare_string_constant_8(strconst_body_15,4);
  static Const q cons_const_16[] = {
    NILATOM,
    makeint(32),
  };
  static Const q cons_const_17[] = {
    NILATOM,
    makesym(atom_found),
  };
  static Const q cons_const_18[] = {
    makecons(cons_const_17),
    makesym(atom_was),
  };
  static Const q cons_const_19[] = {
    makecons(cons_const_18),
    makesym(atom_token),
  };
  static Const q cons_const_20[] = {
    makecons(cons_const_19),
    makesym(atom_ambiguous),
  };
  q a0, a1, a2, a3, a4, a5, a6;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  switch_on_pred() {
    case_pred(0, klcmp_2_top);
    case_pred(1, klcmp_2F2_240_4_top);
    case_pred(2, klcmp1_4_top);
    case_pred(3, compile_3_top);
    case_pred(4, compile1_3_top);
    case_pred(5, close__streams_1_top);
    case_pred(6, read__in_5_top);
    case_pred(7, read__inline_7_top);
    case_pred(8, read__all_6_top);
    case_pred(9, read__all__1_6_top);
    case_pred(10, read__one__module_7_top);
    case_pred(11, handle__exception_1_top);
    case_pred(12, handle__exception_3_top);
    case_pred(13, complain__tokens_6_top);
    case_pred(14, complain__tokens_3_top);
    case_pred(15, complain__token_3_top);
    case_pred(16, complain__string_3_top);
    last_case_pred(17, complain__words_3_top);
  }

 klcmp_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a1 = qp->args[1];
  qp = qp->next;
 klcmp_2_clear_reason:
  reasonp = reasons;
 klcmp_2_0:
 klcmp_2_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
 klcmp_2_2:
  if (!isgobj(a0)) goto klcmp_2_4;
 klcmp_2_3:
  gblt_is_string(a0,klcmp_2_4);
  gblt_size_of_string(a0,x0,klcmp_2_4);
  gblt_element_size_of_string(a0,x1,klcmp_2_4);
  x2 = makeint(1L);
  bblt_sub_no_check(x0,x2,x3);
  generic_arg[0] = x3;
  x4 = makeint(1L);
  generic_arg[1] = x4;
  x5 = makeint(46L);
  generic_arg[2] = x5;
  allocp[0] = x6 = makeref(&allocp[0]);
  generic_arg[3] = x6;
  call_generic(a0, functor_search__character_4, 1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_kl1cmp1_xklcmp1_4);
  allocp[2] = a0;
  allocp[3] = x7 = makeref(&allocp[3]);
  allocp[4] = x8 = makeref(&allocp[4]);
  allocp[5] = a1;
  a1 = a0;
  a2 = x7;
  a3 = x8;
  a0 = x6;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(klcmp_2F2_240_4_0);
  goto klcmp_2F2_240_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,klcmp_2_1);
  *reasonp++ =  a0;
  goto klcmp_2_4;
  };
  goto klcmp_2_4;
 klcmp_2_4:
  otherwise(klcmp_2_interrupt);
  allocp[0] = makesym(functor_abnormal_2);
  allocp[1] = makesym(atom_inputfile);
  allocp[2] = a0;
  x0 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a1, x0);
  proceed();
 klcmp_2_ext_interrupt:
  reasonp = 0l;
 klcmp_2_interrupt:
  goto interrupt_2;
 }

 klcmp_2F2_240_4_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 klcmp_2F2_240_4_clear_reason:
  reasonp = reasons;
 klcmp_2F2_240_4_0:
 klcmp_2F2_240_4_1:
  if (!isint(a0)) goto klcmp_2F2_240_4_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,klcmp_2F2_240_4_2);
  generic_arg[0] = a0;
  generic_arg[1] = a2;
  generic_arg[2] = a3;
  call_generic(a1, functor_split_3, 0);
  proceed();
 klcmp_2F2_240_4_2:
  x1 = makeint(0L);
  gblt_less_or_eq(a0,x1,klcmp_2F2_240_4_interrupt);
  unify(a2, a1);
  x2 = makefunctor(&string_const_0);
  unify_value(a3, x2);
  proceed();
 klcmp_2F2_240_4_3:
  if (!isref(a0)) goto klcmp_2F2_240_4_interrupt;
  deref_and_jump(a0,klcmp_2F2_240_4_1);
  *reasonp++ =  a0;
  goto klcmp_2F2_240_4_interrupt;
 klcmp_2F2_240_4_ext_interrupt:
  reasonp = 0l;
 klcmp_2F2_240_4_interrupt:
  toppred = &predicate_kl1cmp1_xklcmp_2F2_240_4;
  goto interrupt_4;
 }

 klcmp1_4_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 klcmp1_4_clear_reason:
  reasonp = reasons;
 klcmp1_4_0:
 klcmp1_4_1:
  if (isref(a2)) goto klcmp1_4_4;
 klcmp1_4_2:
  if (isref(a2)) goto klcmp1_4_3;
  x0 = makefunctor(&string_const_4);
  if_not_equal(a2, x0, klcmp1_4_5);
  x1 = a3;
  a2 = a1;
  a1 = x1;
  execute(compile_3_clear_reason);
  goto compile_3_ext_interrupt;
 klcmp1_4_3:
  deref_and_jump(a2,klcmp1_4_2);
  *reasonp++ =  a2;
  goto klcmp1_4_5;
 klcmp1_4_4:
  deref_and_jump(a2,klcmp1_4_1);
  *reasonp++ =  a2;
  goto klcmp1_4_5;
 klcmp1_4_5:
  otherwise(klcmp1_4_interrupt);
  allocp[0] = makesym(functor_abnormal_2);
  allocp[1] = makesym(atom_inputfile);
  allocp[2] = a0;
  x0 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a3, x0);
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x1 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__message_xreport__error_2);
  allocp[4] = makefunctor(&string_const_5);
  allocp[5] = x1;
  qp = (struct goalrec*)&allocp[2];
  allocp += 6;
  proceed();
 klcmp1_4_ext_interrupt:
  reasonp = 0l;
 klcmp1_4_interrupt:
  goto interrupt_4;
 }

 compile_3_top: {
  q x0;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 compile_3_clear_reason:
  reasonp = reasons;
 compile_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_kl1cmp1_xcompile1_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_klic__comp__message_xsee_2);
  allocp[7] = a0;
  allocp[8] = x0;
  qp = (struct goalrec*)&allocp[5];
  allocp += 9;
  proceed();
 compile_3_ext_interrupt:
  reasonp = 0l;
 compile_3_interrupt:
  toppred = &predicate_kl1cmp1_xcompile_3;
  goto interrupt_3;
 }

 compile1_3_top: {
  q x0, x1, x2, x3, x4;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 compile1_3_clear_reason:
  reasonp = reasons;
 compile1_3_0:
 compile1_3_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_normal_1)) goto compile1_3_2;
  x0 = makesym(atom_normal);
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xmake__mid_2);
  allocp[2] = a2;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_analyzer_xanalyzer1_3);
  allocp[6] = a2;
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = x1;
  allocp[9] = (q)(struct goalrec*)&allocp[4];
  allocp[10] = (q)(&predicate_kl1cmp1_xread__in_5);
  allocp[11] = x2;
  x3 = arg(a0, 0);
  allocp[12] = x3;
  allocp[13] = NILATOM;
  allocp[14] = x4 = makeref(&allocp[14]);
  allocp[15] = NILATOM;
  allocp[16] = (q)(struct goalrec*)&allocp[9];
  allocp[17] = (q)(&predicate_keyed__set_xcreate_1);
  allocp[18] = x4;
  qp = (struct goalrec*)&allocp[16];
  allocp += 19;
  proceed();
 case VARREF:
  deref_and_jump(a0,compile1_3_1);
  *reasonp++ =  a0;
  goto compile1_3_2;
  };
  goto compile1_3_2;
 compile1_3_2:
  otherwise(compile1_3_interrupt);
  allocp[0] = makesym(functor_abnormal_2);
  allocp[1] = makesym(atom_fileopen);
  allocp[2] = a0;
  x0 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a1, x0);
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x1 = makecons(&allocp[0]);
  a0 = x1;
  allocp += 2;
  execute(close__streams_1_0);
  goto close__streams_1_ext_interrupt;
 compile1_3_ext_interrupt:
  reasonp = 0l;
 compile1_3_interrupt:
  goto interrupt_3;
 }

 close__streams_1_top: {
  q x0, x1, x2;
  qp = qp->next;
 close__streams_1_clear_reason:
  reasonp = reasons;
 close__streams_1_0:
 close__streams_1_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 close__streams_1_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_normal_1)) goto close__streams_1_3;
  x1 = arg(x0, 0);
  x2 = NILATOM;
  unify_value(x1, x2);
  a0 = cdr_of(a0);
  execute(close__streams_1_0);
  goto close__streams_1_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,close__streams_1_2);
  *reasonp++ =  x0;
  goto close__streams_1_3;
  };
  goto close__streams_1_3;
 case ATOMIC:
  if (a0 != NILATOM) goto close__streams_1_3;
  proceed();
 case VARREF:
  deref_and_jump(a0,close__streams_1_1);
  *reasonp++ =  a0;
  goto close__streams_1_3;
  };
  goto close__streams_1_3;
 close__streams_1_3:
  otherwise(close__streams_1_interrupt);
 close__streams_1_4:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(close__streams_1_0);
  goto close__streams_1_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,close__streams_1_4);
  *reasonp++ =  a0;
  goto close__streams_1_interrupt;
  };
  goto close__streams_1_interrupt;
 close__streams_1_ext_interrupt:
  reasonp = 0l;
 close__streams_1_interrupt:
  toppred = &predicate_kl1cmp1_xclose__streams_1;
  goto interrupt_1;
 }

 read__in_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 read__in_5_clear_reason:
  reasonp = reasons;
 read__in_5_0:
  allocp[0] = makesym(functor_normal_2);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  x0 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a0, x0);
  allocp[0] = makesym(functor_getwt_1);
  allocp[1] = x4 = makeref(&allocp[1]);
  x3 = makefunctor(&allocp[0]);
  allocp[2] = x6 = makeref(&allocp[2]);
  allocp[3] = x3;
  x5 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a1, x5);
  a0 = x4;
  a1 = x2;
  x7 = a2;
  a5 = a3;
  a6 = a4;
  a4 = x7;
  a3 = x6;
  a2 = x1;
  execute(read__inline_7_0);
  goto read__inline_7_ext_interrupt;
 read__in_5_ext_interrupt:
  reasonp = 0l;
 read__in_5_interrupt:
  goto interrupt_5;
 }

 read__inline_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 read__inline_7_clear_reason:
  reasonp = reasons;
 read__inline_7_0:
 read__inline_7_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_normal_1)) goto read__inline_7_8;
  x0 = arg(a0, 0);
 read__inline_7_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_functor_1)) goto read__inline_7_8;
  x1 = arg(x0, 0);
 read__inline_7_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor__3A_2D_1)) goto read__inline_7_8;
  x2 = arg(x1, 0);
 read__inline_7_4:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_functor_1)) goto read__inline_7_8;
  x3 = arg(x2, 0);
 read__inline_7_5:
  switch (ptagof(x3)) {
 case FUNCTOR:
  if (functor_of(x3) != makesym(functor__3A_2)) goto read__inline_7_8;
  x4 = arg(x3, 0);
 read__inline_7_6:
  switch (ptagof(x4)) {
 case FUNCTOR:
  if (functor_of(x4) != makesym(functor_atom_1)) goto read__inline_7_8;
  x5 = arg(x4, 0);
 read__inline_7_7:
  switch (ptagof(x5)) {
 case ATOMIC:
  if (x5 != makesym(atom_inline)) goto read__inline_7_8;
  allocp[0] = x7 = makeref(&allocp[0]);
  x8 = arg(x3, 1);
  allocp[1] = x8;
  x6 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x6);
  allocp[0] = makesym(functor_getwt_1);
  allocp[1] = x10 = makeref(&allocp[1]);
  x9 = makefunctor(&allocp[0]);
  allocp[2] = x12 = makeref(&allocp[2]);
  allocp[3] = x9;
  x11 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a3, x11);
  a0 = x10;
  a1 = x7;
  a3 = x12;
  execute(read__inline_7_0);
  goto read__inline_7_ext_interrupt;
 case VARREF:
  deref_and_jump(x5,read__inline_7_7);
  *reasonp++ =  x5;
  goto read__inline_7_8;
  };
  goto read__inline_7_8;
 case VARREF:
  deref_and_jump(x4,read__inline_7_6);
  *reasonp++ =  x4;
  goto read__inline_7_8;
  };
  goto read__inline_7_8;
 case VARREF:
  deref_and_jump(x3,read__inline_7_5);
  *reasonp++ =  x3;
  goto read__inline_7_8;
  };
  goto read__inline_7_8;
 case VARREF:
  deref_and_jump(x2,read__inline_7_4);
  *reasonp++ =  x2;
  goto read__inline_7_8;
  };
  goto read__inline_7_8;
 case VARREF:
  deref_and_jump(x1,read__inline_7_3);
  *reasonp++ =  x1;
  goto read__inline_7_8;
  };
  goto read__inline_7_8;
 case VARREF:
  deref_and_jump(x0,read__inline_7_2);
  *reasonp++ =  x0;
  goto read__inline_7_8;
  };
  goto read__inline_7_8;
 case VARREF:
  deref_and_jump(a0,read__inline_7_1);
  *reasonp++ =  a0;
  goto read__inline_7_8;
  };
  goto read__inline_7_8;
 read__inline_7_8:
  otherwise(read__inline_7_interrupt);
 read__inline_7_9:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_normal_1)) goto read__inline_7_10;
  x0 = NILATOM;
  unify_value(a1, x0);
  a0 = arg(a0, 0);
  a1 = a2;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  a5 = a6;
  execute(read__all_6_0);
  goto read__all_6_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,read__inline_7_9);
  *reasonp++ =  a0;
  goto read__inline_7_10;
  };
  goto read__inline_7_10;
 read__inline_7_10:
  otherwise(read__inline_7_interrupt);
  unify2(a6, a5, a4, a3);
  execute(handle__exception_1_0);
  goto handle__exception_1_ext_interrupt;
 read__inline_7_ext_interrupt:
  reasonp = 0l;
 read__inline_7_interrupt:
  toppred = &predicate_kl1cmp1_xread__inline_7;
  goto interrupt_7;
 }

 read__all_6_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 read__all_6_clear_reason:
  reasonp = reasons;
 read__all_6_0:
 read__all_6_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto read__all_6_5;
  switch (symval(a0)) {
 case symval(makesym(atom_end__of__file)):
  unify2(a5, a4, a3, a2);
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case symval(makesym(atom_empty)):
  unify2(a5, a4, a3, a2);
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
  };
  goto read__all_6_5;
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_functor_1)) goto read__all_6_5;
  x0 = arg(a0, 0);
 read__all_6_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__3A_2D_1)) goto read__all_6_5;
  x1 = arg(x0, 0);
 read__all_6_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_functor_1)) goto read__all_6_5;
  x2 = arg(x1, 0);
 read__all_6_4:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_module_1)) goto read__all_6_5;
  a0 = arg(x2, 0);
  execute(read__all__1_6_0);
  goto read__all__1_6_ext_interrupt;
 case VARREF:
  deref_and_jump(x2,read__all_6_4);
  *reasonp++ =  x2;
  goto read__all_6_5;
  };
  goto read__all_6_5;
 case VARREF:
  deref_and_jump(x1,read__all_6_3);
  *reasonp++ =  x1;
  goto read__all_6_5;
  };
  goto read__all_6_5;
 case VARREF:
  deref_and_jump(x0,read__all_6_2);
  *reasonp++ =  x0;
  goto read__all_6_5;
  };
  goto read__all_6_5;
 case VARREF:
  deref_and_jump(a0,read__all_6_1);
  *reasonp++ =  a0;
  goto read__all_6_5;
  };
  goto read__all_6_5;
 read__all_6_5:
  otherwise(read__all_6_interrupt);
  unify2(a5, a4, a3, a2);
  x0 = NILATOM;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__message_xreport__error_2);
  allocp[2] = makefunctor(&string_const_6);
  allocp[3] = NILATOM;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  proceed();
 read__all_6_ext_interrupt:
  reasonp = 0l;
 read__all_6_interrupt:
  toppred = &predicate_kl1cmp1_xread__all_6;
  goto interrupt_6;
 }

 read__all__1_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 read__all__1_6_clear_reason:
  reasonp = reasons;
 read__all__1_6_0:
 read__all__1_6_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_atom_1)) goto read__all__1_6_2;
  allocp[0] = makesym(functor_module_2);
  x1 = arg(a0, 0);
  allocp[1] = x1;
  allocp[2] = x2 = makeref(&allocp[2]);
  x0 = makefunctor(&allocp[0]);
  allocp[3] = x4 = makeref(&allocp[3]);
  allocp[4] = x0;
  x3 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a1, x3);
  allocp[0] = makesym(functor_getwt_1);
  allocp[1] = x6 = makeref(&allocp[1]);
  x5 = makefunctor(&allocp[0]);
  allocp[2] = x8 = makeref(&allocp[2]);
  allocp[3] = x5;
  x7 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a2, x7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_kl1cmp1_xread__all_6);
  allocp[2] = x9 = makeref(&allocp[2]);
  allocp[3] = x4;
  allocp[4] = x10 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x11 = makeref(&allocp[6]);
  allocp[7] = a5;
  a0 = x6;
  a1 = x2;
  a2 = x9;
  a3 = x8;
  a5 = a4;
  a6 = x11;
  a4 = x10;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  execute(read__one__module_7_0);
  goto read__one__module_7_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,read__all__1_6_1);
  *reasonp++ =  a0;
  goto read__all__1_6_2;
  };
  goto read__all__1_6_2;
 read__all__1_6_2:
  otherwise(read__all__1_6_interrupt);
  unify2(a5, a4, a3, a2);
  x0 = NILATOM;
  unify_value(a1, x0);
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x1 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__message_xreport__error_2);
  allocp[4] = makefunctor(&string_const_7);
  allocp[5] = x1;
  qp = (struct goalrec*)&allocp[2];
  allocp += 6;
  proceed();
 read__all__1_6_ext_interrupt:
  reasonp = 0l;
 read__all__1_6_interrupt:
  toppred = &predicate_kl1cmp1_xread__all__1_6;
  goto interrupt_6;
 }

 read__one__module_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 read__one__module_7_clear_reason:
  reasonp = reasons;
 read__one__module_7_0:
 read__one__module_7_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_normal_1)) goto read__one__module_7_7;
  x0 = arg(a0, 0);
 read__one__module_7_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (isint(x0)) goto read__one__module_7_7;
  switch (symval(x0)) {
 case symval(makesym(atom_end__of__file)):
  unify2(a6, a5, a4, a3);
  x1 = NILATOM;
  unify_value(a1, x1);
  x2 = makesym(atom_end__of__file);
  unify_value(a2, x2);
  proceed();
 case symval(makesym(atom_empty)):
  unify2(a6, a5, a4, a3);
  x1 = NILATOM;
  unify_value(a1, x1);
  x2 = makesym(atom_end__of__file);
  unify_value(a2, x2);
  proceed();
  };
  goto read__one__module_7_7;
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_functor_1)) goto read__one__module_7_7;
  x1 = arg(x0, 0);
 read__one__module_7_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor__3A_2D_1)) goto read__one__module_7_7;
  x2 = arg(x1, 0);
 read__one__module_7_4:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_functor_1)) goto read__one__module_7_7;
  x3 = arg(x2, 0);
 read__one__module_7_5:
  switch (ptagof(x3)) {
 case FUNCTOR:
  switch (symval(functor_of(x3))) {
 case functor_module_1:
  x4 = arg(x3, 0);
 read__one__module_7_6:
  switch (ptagof(x4)) {
 case FUNCTOR:
  if (functor_of(x4) != makesym(functor_atom_1)) goto read__one__module_7_7;
  unify2(a6, a5, a4, a3);
  x5 = NILATOM;
  unify_value(a1, x5);
  allocp[0] = makesym(functor_atom_1);
  x7 = arg(x4, 0);
  allocp[1] = x7;
  x6 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_module_1);
  allocp[3] = x6;
  x8 = makefunctor(&allocp[2]);
  allocp[4] = makesym(functor_functor_1);
  allocp[5] = x8;
  x9 = makefunctor(&allocp[4]);
  allocp[6] = makesym(functor__3A_2D_1);
  allocp[7] = x9;
  x10 = makefunctor(&allocp[6]);
  allocp[8] = makesym(functor_functor_1);
  allocp[9] = x10;
  x11 = makefunctor(&allocp[8]);
  allocp += 10;
  unify_value(a2, x11);
  proceed();
 case VARREF:
  deref_and_jump(x4,read__one__module_7_6);
  *reasonp++ =  x4;
  goto read__one__module_7_7;
  };
  goto read__one__module_7_7;
 case functor_with_1:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_kl1cmp1_xread__one__module_7);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x5 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x6 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = makesym(functor_getwt_1);
  allocp[10] = x4;
  x7 = makefunctor(&allocp[9]);
  allocp[11] = x5;
  allocp[12] = x7;
  x8 = makecons(&allocp[11]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 13;
  unify_value(a3, x8);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__cmacro_xinsDefs_3);
  x9 = arg(x3, 0);
  allocp[2] = x9;
  allocp[3] = a5;
  allocp[4] = x6;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
  };
  goto read__one__module_7_7;
 case VARREF:
  deref_and_jump(x3,read__one__module_7_5);
  *reasonp++ =  x3;
  goto read__one__module_7_7;
  };
  goto read__one__module_7_7;
 case VARREF:
  deref_and_jump(x2,read__one__module_7_4);
  *reasonp++ =  x2;
  goto read__one__module_7_7;
  };
  goto read__one__module_7_7;
 case VARREF:
  deref_and_jump(x1,read__one__module_7_3);
  *reasonp++ =  x1;
  goto read__one__module_7_7;
  };
  goto read__one__module_7_7;
 case VARREF:
  deref_and_jump(x0,read__one__module_7_2);
  *reasonp++ =  x0;
  goto read__one__module_7_7;
  };
  goto read__one__module_7_7;
 case VARREF:
  deref_and_jump(a0,read__one__module_7_1);
  *reasonp++ =  a0;
  goto read__one__module_7_7;
  };
  goto read__one__module_7_7;
 read__one__module_7_7:
  otherwise(read__one__module_7_interrupt);
 read__one__module_7_8:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_normal_1)) goto read__one__module_7_11;
  x0 = arg(a0, 0);
 read__one__module_7_9:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_functor_1)) goto read__one__module_7_11;
  x1 = arg(x0, 0);
 read__one__module_7_10:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor__3A_2D_1)) goto read__one__module_7_11;
  allocp[0] = makesym(functor_getwt_1);
  allocp[1] = x3 = makeref(&allocp[1]);
  x2 = makefunctor(&allocp[0]);
  allocp[2] = x5 = makeref(&allocp[2]);
  allocp[3] = x2;
  x4 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a3, x4);
  a0 = x3;
  a3 = x5;
  execute(read__one__module_7_0);
  goto read__one__module_7_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,read__one__module_7_10);
  *reasonp++ =  x1;
  goto read__one__module_7_11;
  };
  goto read__one__module_7_11;
 case VARREF:
  deref_and_jump(x0,read__one__module_7_9);
  *reasonp++ =  x0;
  goto read__one__module_7_11;
  };
  goto read__one__module_7_11;
 case VARREF:
  deref_and_jump(a0,read__one__module_7_8);
  *reasonp++ =  a0;
  goto read__one__module_7_11;
  };
  goto read__one__module_7_11;
 read__one__module_7_11:
  otherwise(read__one__module_7_interrupt);
 read__one__module_7_12:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_normal_1)) goto read__one__module_7_13;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_kl1cmp1_xread__one__module_7);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = makesym(functor_getwt_1);
  allocp[10] = x0;
  x4 = makefunctor(&allocp[9]);
  allocp[11] = x2;
  allocp[12] = x4;
  x5 = makecons(&allocp[11]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 13;
  unify_value(a3, x5);
  allocp[0] = x1;
  allocp[1] = x7 = makeref(&allocp[1]);
  x6 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__macro_xmacro_2);
  allocp[2] = x8 = makeref(&allocp[2]);
  allocp[3] = x7;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_klic__comp__cmacro_xreplaceClause_4);
  x9 = arg(a0, 0);
  allocp[6] = x9;
  allocp[7] = x8;
  allocp[8] = a5;
  allocp[9] = x3;
  qp = (struct goalrec*)&allocp[4];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a0,read__one__module_7_12);
  *reasonp++ =  a0;
  goto read__one__module_7_13;
  };
  goto read__one__module_7_13;
 read__one__module_7_13:
  otherwise(read__one__module_7_interrupt);
  unify2(a6, a5, a4, a3);
  execute(handle__exception_1_0);
  goto handle__exception_1_ext_interrupt;
 read__one__module_7_ext_interrupt:
  reasonp = 0l;
 read__one__module_7_interrupt:
  toppred = &predicate_kl1cmp1_xread__one__module_7;
  goto interrupt_7;
 }

 handle__exception_1_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15;
  qp = qp->next;
 handle__exception_1_clear_reason:
  reasonp = reasons;
 handle__exception_1_0:
 handle__exception_1_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_abnormal_1)) goto handle__exception_1_6;
  x0 = arg(a0, 0);
 handle__exception_1_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_error_2:
  a0 = arg(x0, 0);
  a1 = arg(x0, 1);
  a2 = NILATOM;
  execute(handle__exception_3_0);
  goto handle__exception_3_ext_interrupt;
 case functor_ambiguous_2:
  a0 = arg(x0, 0);
  a1 = arg(x0, 1);
  a2 = makecons(cons_const_20);
  execute(handle__exception_3_0);
  goto handle__exception_3_ext_interrupt;
 case functor_error_1:
  x1 = arg(x0, 0);
 handle__exception_1_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
 handle__exception_1_4:
  if (!isgobj(x1)) goto handle__exception_1_6;
  if (!isclass(x1,vector)) goto handle__exception_1_6;
  gblt_size_of_vector(x1,x2,handle__exception_1_6);
 handle__exception_1_5:
  if (x2 != makeint(3L)) goto handle__exception_1_6;
  x4 = makeint(0L);
  gblt_element_of_vector(x1,x4,x3,handle__exception_1_6);
  x6 = makeint(1L);
  gblt_element_of_vector(x1,x6,x5,handle__exception_1_6);
  x8 = makeint(2L);
  gblt_element_of_vector(x1,x8,x7,handle__exception_1_6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__message_xcompilation__error_1);
  allocp[2] = x9 = makeref(&allocp[2]);
  x10 = NILATOM;
  allocp[3] = (q)(struct goalrec*)&allocp[0];
  allocp[4] = (q)(&predicate_klic__comp__obj_xflush_3);
  allocp[5] = x9;
  allocp[6] = x11 = makeref(&allocp[6]);
  allocp[7] = x10;
  allocp[8] = NILATOM;
  allocp[9] = x7;
  x12 = makecons(&allocp[8]);
  allocp[10] = x12;
  allocp[11] = x5;
  x13 = makecons(&allocp[10]);
  allocp[12] = x13;
  allocp[13] = x3;
  x14 = makecons(&allocp[12]);
  allocp[14] = (q)(struct goalrec*)&allocp[3];
  allocp[15] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[16] = makefunctor(&string_const_2);
  allocp[17] = x14;
  allocp[18] = x15 = makeref(&allocp[18]);
  allocp[19] = x11;
  allocp[20] = (q)(struct goalrec*)&allocp[14];
  allocp[21] = (q)(&predicate_klic__comp__message_xtell_2);
  allocp[22] = makesym(atom_user__error);
  allocp[23] = x15;
  qp = (struct goalrec*)&allocp[20];
  allocp += 24;
  proceed();
 case VARREF:
  deref_and_jump(x1,handle__exception_1_3);
  *reasonp++ =  x1;
  goto handle__exception_1_6;
  };
  goto handle__exception_1_6;
  };
  goto handle__exception_1_6;
 case VARREF:
  deref_and_jump(x0,handle__exception_1_2);
  *reasonp++ =  x0;
  goto handle__exception_1_6;
  };
  goto handle__exception_1_6;
 case VARREF:
  deref_and_jump(a0,handle__exception_1_1);
  *reasonp++ =  a0;
  goto handle__exception_1_6;
  };
  goto handle__exception_1_6;
 handle__exception_1_6:
  otherwise(handle__exception_1_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__message_xcompilation__error_1);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = (q)(struct goalrec*)&allocp[0];
  allocp[4] = (q)(&predicate_klic__comp__obj_xflush_3);
  allocp[5] = x0;
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = NILATOM;
  allocp[8] = NILATOM;
  allocp[9] = a0;
  x2 = makecons(&allocp[8]);
  allocp[10] = (q)(struct goalrec*)&allocp[3];
  allocp[11] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[12] = makefunctor(&string_const_13);
  allocp[13] = x2;
  allocp[14] = x3 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = (q)(struct goalrec*)&allocp[10];
  allocp[17] = (q)(&predicate_klic__comp__message_xtell_2);
  allocp[18] = makesym(atom_user__error);
  allocp[19] = x3;
  qp = (struct goalrec*)&allocp[16];
  allocp += 20;
  proceed();
 handle__exception_1_ext_interrupt:
  reasonp = 0l;
 handle__exception_1_interrupt:
  toppred = &predicate_kl1cmp1_xhandle__exception_1;
  goto interrupt_1;
 }

 handle__exception_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 handle__exception_3_clear_reason:
  reasonp = reasons;
 handle__exception_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__message_xcompilation__error_1);
  allocp[2] = x0 = makeref(&allocp[2]);
  x1 = NILATOM;
  allocp[3] = (q)(struct goalrec*)&allocp[0];
  allocp[4] = (q)(&predicate_klic__comp__obj_xflush_3);
  allocp[5] = x0;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = x1;
  allocp[8] = x2;
  allocp[9] = makeint(10L);
  x3 = makecons(&allocp[8]);
  allocp[10] = (q)(struct goalrec*)&allocp[3];
  allocp[11] = (q)(&predicate_kl1cmp1_xcomplain__tokens_3);
  allocp[12] = x4 = makeref(&allocp[12]);
  allocp[13] = x5 = makeref(&allocp[13]);
  allocp[14] = x3;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_klic__comp__obj_xklicformat_3);
  allocp[17] = makefunctor(&string_const_1);
  allocp[18] = x6 = makeref(&allocp[18]);
  allocp[19] = x5;
  allocp[20] = (q)(struct goalrec*)&allocp[15];
  allocp[21] = (q)(&predicate_kl1cmp1_xcomplain__tokens_6);
  allocp[22] = makeint(0L);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = x4;
  allocp[26] = x7 = makeref(&allocp[26]);
  allocp[27] = x6;
  allocp[28] = x7;
  allocp[29] = makeint(10L);
  x8 = makecons(&allocp[28]);
  allocp[30] = (q)(struct goalrec*)&allocp[20];
  allocp[31] = (q)(&predicate_kl1cmp1_xcomplain__words_3);
  allocp[32] = a2;
  allocp[33] = x9 = makeref(&allocp[33]);
  allocp[34] = x8;
  allocp[35] = (q)(struct goalrec*)&allocp[30];
  allocp[36] = (q)(&predicate_klic__comp__obj_xklicformat_3);
  allocp[37] = makefunctor(&string_const_8);
  allocp[38] = x10 = makeref(&allocp[38]);
  allocp[39] = x9;
  allocp[40] = (q)(struct goalrec*)&allocp[35];
  allocp[41] = (q)(&predicate_klic__comp__message_xtell_2);
  allocp[42] = makesym(atom_user__error);
  allocp[43] = x10;
  qp = (struct goalrec*)&allocp[40];
  allocp += 44;
  proceed();
 handle__exception_3_ext_interrupt:
  reasonp = 0l;
 handle__exception_3_interrupt:
  toppred = &predicate_kl1cmp1_xhandle__exception_3;
  goto interrupt_3;
 }

 complain__tokens_6_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 complain__tokens_6_clear_reason:
  reasonp = reasons;
 complain__tokens_6_0:
 complain__tokens_6_1:
  if (isref(a0)) goto complain__tokens_6_4;
 complain__tokens_6_2:
  if (isref(a0)) goto complain__tokens_6_3;
  if_not_equal(a0, a1, complain__tokens_6_5);
  unify2(a3, a2, a5, a4);
  proceed();
 complain__tokens_6_3:
  deref_and_jump(a0,complain__tokens_6_2);
  *reasonp++ =  a0;
  goto complain__tokens_6_5;
 complain__tokens_6_4:
  deref_and_jump(a0,complain__tokens_6_1);
  *reasonp++ =  a0;
  goto complain__tokens_6_5;
 complain__tokens_6_5:
  otherwise(complain__tokens_6_interrupt);
 complain__tokens_6_6:
  switch (ptagof(a2)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_kl1cmp1_xcomplain__tokens_6);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  x1 = cdr_of(a2);
  allocp[4] = x1;
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[10] = a0;
  allocp[11] = makeint(1L);
  allocp[12] = x0;
  a0 = car_of(a2);
  a1 = a4;
  a2 = x2;
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  execute(complain__token_3_0);
  goto complain__token_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,complain__tokens_6_6);
  *reasonp++ =  a2;
  goto complain__tokens_6_interrupt;
  };
  goto complain__tokens_6_interrupt;
 complain__tokens_6_ext_interrupt:
  reasonp = 0l;
 complain__tokens_6_interrupt:
  goto interrupt_6;
 }

 complain__tokens_3_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 complain__tokens_3_clear_reason:
  reasonp = reasons;
 complain__tokens_3_0:
 complain__tokens_3_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_kl1cmp1_xcomplain__tokens_3);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  a0 = car_of(a0);
  a2 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(complain__token_3_0);
  goto complain__token_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto complain__tokens_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,complain__tokens_3_1);
  *reasonp++ =  a0;
  goto complain__tokens_3_interrupt;
  };
  goto complain__tokens_3_interrupt;
 complain__tokens_3_ext_interrupt:
  reasonp = 0l;
 complain__tokens_3_interrupt:
  goto interrupt_3;
 }

 complain__token_3_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 complain__token_3_clear_reason:
  reasonp = reasons;
 complain__token_3_0:
 complain__token_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_end)) goto complain__token_3_2;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__obj_xklicformat_3);
  allocp[2] = makefunctor(&string_const_3);
  allocp[3] = a1;
  allocp[4] = a2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_atom_1:
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_12);
  allocp[5] = x0;
  allocp[6] = a1;
  allocp[7] = a2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 case functor_integer_1:
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_12);
  allocp[5] = x0;
  allocp[6] = a1;
  allocp[7] = a2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 case functor_string_1:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_kl1cmp1_xcomplain__string_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_klic__comp__util_xstring__to__char__list_2);
  x1 = arg(a0, 0);
  allocp[7] = x1;
  allocp[8] = x0;
  qp = (struct goalrec*)&allocp[5];
  allocp += 9;
  proceed();
 case functor__24VAR_2:
  allocp[0] = NILATOM;
  x1 = arg(a0, 1);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_11);
  allocp[5] = x0;
  allocp[6] = a1;
  allocp[7] = a2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 case functor_open_1:
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_14);
  allocp[5] = x0;
  allocp[6] = a1;
  allocp[7] = a2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
  };
  goto complain__token_3_2;
 case VARREF:
  deref_and_jump(a0,complain__token_3_1);
  *reasonp++ =  a0;
  goto complain__token_3_2;
  };
  goto complain__token_3_2;
 complain__token_3_2:
  otherwise(complain__token_3_interrupt);
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_12);
  allocp[5] = x0;
  allocp[6] = a1;
  allocp[7] = a2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 complain__token_3_ext_interrupt:
  reasonp = 0l;
 complain__token_3_interrupt:
  toppred = &predicate_kl1cmp1_xcomplain__token_3;
  goto interrupt_3;
 }

 complain__string_3_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 complain__string_3_clear_reason:
  reasonp = reasons;
 complain__string_3_0:
 complain__string_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 complain__string_3_2:
  switch (ptagof(x0)) {
 case ATOMIC:
 complain__string_3_3:
  if (x0 != makeint(34L)) goto complain__string_3_4;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_kl1cmp1_xcomplain__string_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_klic__comp__obj_xklicformat_3);
  allocp[7] = makefunctor(&string_const_9);
  allocp[8] = a1;
  allocp[9] = x2;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(x0,complain__string_3_2);
  *reasonp++ =  x0;
  goto complain__string_3_4;
  };
  goto complain__string_3_4;
 case ATOMIC:
  if (a0 != NILATOM) goto complain__string_3_4;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,complain__string_3_1);
  *reasonp++ =  a0;
  goto complain__string_3_4;
  };
  goto complain__string_3_4;
 complain__string_3_4:
  otherwise(complain__string_3_interrupt);
 complain__string_3_5:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_kl1cmp1_xcomplain__string_3);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = NILATOM;
  x3 = car_of(a0);
  allocp[6] = x3;
  x2 = makecons(&allocp[5]);
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[9] = makefunctor(&string_const_10);
  allocp[10] = x2;
  allocp[11] = a1;
  allocp[12] = x1;
  qp = (struct goalrec*)&allocp[7];
  allocp += 13;
  proceed();
 case VARREF:
  deref_and_jump(a0,complain__string_3_5);
  *reasonp++ =  a0;
  goto complain__string_3_interrupt;
  };
  goto complain__string_3_interrupt;
 complain__string_3_ext_interrupt:
  reasonp = 0l;
 complain__string_3_interrupt:
  goto interrupt_3;
 }

 complain__words_3_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 complain__words_3_clear_reason:
  reasonp = reasons;
 complain__words_3_0:
 complain__words_3_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_kl1cmp1_xcomplain__words_3);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = makecons(cons_const_16);
  x3 = car_of(a0);
  allocp[6] = x3;
  x2 = makecons(&allocp[5]);
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[9] = makefunctor(&string_const_15);
  allocp[10] = x2;
  allocp[11] = a1;
  allocp[12] = x1;
  qp = (struct goalrec*)&allocp[7];
  allocp += 13;
  proceed();
 case ATOMIC:
  if (a0 != NILATOM) goto complain__words_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,complain__words_3_1);
  *reasonp++ =  a0;
  goto complain__words_3_interrupt;
  };
  goto complain__words_3_interrupt;
 complain__words_3_ext_interrupt:
  reasonp = 0l;
 complain__words_3_interrupt:
  goto interrupt_3;
 }
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_kl1cmp1);
}
