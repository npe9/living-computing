/* Compiled by KLIC compiler version 3.002 (Wed Sep 17 15:37:13 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_loop();
Const struct predicate predicate_loop_xcheck_2 =
   { module_loop, 0, 2 };
Const struct predicate predicate_loop_xcheck__loop_7 =
   { module_loop, 1, 7 };
Const struct predicate predicate_loop_xcheck__loop1_7 =
   { module_loop, 2, 7 };
Const struct predicate predicate_loop_xcheck__module__loop_7 =
   { module_loop, 3, 7 };
Const struct predicate predicate_loop_xcheck__clauses__loop_7 =
   { module_loop, 4, 7 };
Const struct predicate predicate_loop_xcheck__clauses__loop_9 =
   { module_loop, 5, 9 };
Const struct predicate predicate_loop_xcheck__bodys__loop_6 =
   { module_loop, 6, 6 };
Const struct predicate predicate_loop_xcheck__bodys__loop_8 =
   { module_loop, 7, 8 };
Const struct predicate predicate_loop_xcheck__body__loop_8 =
   { module_loop, 8, 8 };
Const struct predicate predicate_loop_xcheck__body__loop_5 =
   { module_loop, 9, 5 };
Const struct predicate predicate_loop_xcheck__ancestors_5 =
   { module_loop, 10, 5 };
extern Const struct predicate predicate_integer__arithmetics_xadd_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_xsetarg_4;
extern Const struct predicate predicate_functor__table_xfunctor_3;
extern Const struct predicate predicate_parse__uty_xget__first__clause__info_4;
extern Const struct predicate predicate_parse__uty_xupdate__clause_5;
extern Const struct predicate predicate_parse__uty_xdecode__goal_3;
extern Const struct predicate predicate_parse__uty_xencode__goal_3;

module module_loop(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  static Const q funct_const_0[] = {
    makesym(functor_atom_1),
    makesym(atom_recursive),
  };
  q a0, a1, a2, a3, a4, a5, a6, a7, a8;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, check_2_top);
    case_pred(1, check__loop_7_top);
    case_pred(2, check__loop1_7_top);
    case_pred(3, check__module__loop_7_top);
    case_pred(4, check__clauses__loop_7_top);
    case_pred(5, check__clauses__loop_9_top);
    case_pred(6, check__bodys__loop_6_top);
    case_pred(7, check__bodys__loop_8_top);
    case_pred(8, check__body__loop_8_top);
    case_pred(9, check__body__loop_5_top);
    last_case_pred(10, check__ancestors_5_top);
  }

 check_2_top: {
  q x0, x1, x2, x3;
  qp = qp->next;
 check_2_clear_reason:
  reasonp = reasons;
 check_2_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_loop_xcheck__loop_7);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = NILATOM;
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = a0;
  allocp[8] = a1;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_parse__uty_xget__first__clause__info_4);
  allocp[11] = x0;
  allocp[12] = x1;
  allocp[13] = x2;
  allocp[14] = a0;
  qp = (struct goalrec*)&allocp[9];
  allocp += 15;
  proceed();
 check_2_ext_interrupt:
  reasonp = 0l;
 check_2_interrupt:
  goto interrupt_2;
 }

 check__loop_7_top: {
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 check__loop_7_clear_reason:
  reasonp = reasons;
 check__loop_7_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_loop_xcheck__loop1_7);
  allocp[2] = a4;
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a5;
  allocp[8] = a6;
  qp = (struct goalrec*)&allocp[0];
  allocp += 9;
  execute(check__ancestors_5_0);
  goto check__ancestors_5_ext_interrupt;
 check__loop_7_ext_interrupt:
  reasonp = 0l;
 check__loop_7_interrupt:
  toppred = &predicate_loop_xcheck__loop_7;
  goto interrupt_7;
 }

 check__loop1_7_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 check__loop1_7_clear_reason:
  reasonp = reasons;
 check__loop1_7_0:
 check__loop1_7_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto check__loop1_7_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  unify(a6, a5);
  proceed();
 case symval(makesym(atom_no)):
  allocp[0] = makesym(functor_ancestor_3);
  allocp[1] = a1;
  allocp[2] = a2;
  allocp[3] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[4] = a4;
  allocp[5] = x0;
  x1 = makecons(&allocp[4]);
  a0 = a1;
  a1 = a2;
  a2 = a3;
  a3 = x1;
  a4 = a5;
  allocp += 6;
  execute(check__module__loop_7_0);
  goto check__module__loop_7_ext_interrupt;
  };
  goto check__loop1_7_interrupt;
 case VARREF:
  deref_and_jump(a0,check__loop1_7_1);
  *reasonp++ =  a0;
  goto check__loop1_7_interrupt;
  };
  goto check__loop1_7_interrupt;
 check__loop1_7_ext_interrupt:
  reasonp = 0l;
 check__loop1_7_interrupt:
  goto interrupt_7;
 }

 check__module__loop_7_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 check__module__loop_7_clear_reason:
  reasonp = reasons;
 check__module__loop_7_0:
 check__module__loop_7_1:
  switch (ptagof(a4)) {
 case CONS:
  x0 = car_of(a4);
 check__module__loop_7_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto check__module__loop_7_7;
  x1 = arg(x0, 0);
 check__module__loop_7_3:
  if (isref(x1)) goto check__module__loop_7_6;
 check__module__loop_7_4:
  if (isref(x1)) goto check__module__loop_7_5;
  if_not_equal(x1, a0, check__module__loop_7_7);
  a4 = arg(x0, 1);
  execute(check__clauses__loop_7_clear_reason);
  goto check__clauses__loop_7_ext_interrupt;
 check__module__loop_7_5:
  deref_and_jump(x1,check__module__loop_7_4);
  *reasonp++ =  x1;
  goto check__module__loop_7_7;
 check__module__loop_7_6:
  deref_and_jump(x1,check__module__loop_7_3);
  *reasonp++ =  x1;
  goto check__module__loop_7_7;
 case VARREF:
  deref_and_jump(x0,check__module__loop_7_2);
  *reasonp++ =  x0;
  goto check__module__loop_7_7;
  };
  goto check__module__loop_7_7;
 case VARREF:
  deref_and_jump(a4,check__module__loop_7_1);
  *reasonp++ =  a4;
  goto check__module__loop_7_7;
  };
  goto check__module__loop_7_7;
 check__module__loop_7_7:
  otherwise(check__module__loop_7_interrupt);
 check__module__loop_7_8:
  switch (ptagof(a4)) {
 case CONS:
  a4 = cdr_of(a4);
  execute(check__module__loop_7_0);
  goto check__module__loop_7_ext_interrupt;
 case ATOMIC:
  if (a4 != NILATOM) goto check__module__loop_7_interrupt;
  unify(a6, a5);
  proceed();
 case VARREF:
  deref_and_jump(a4,check__module__loop_7_8);
  *reasonp++ =  a4;
  goto check__module__loop_7_interrupt;
  };
  goto check__module__loop_7_interrupt;
 check__module__loop_7_ext_interrupt:
  reasonp = 0l;
 check__module__loop_7_interrupt:
  toppred = &predicate_loop_xcheck__module__loop_7;
  goto interrupt_7;
 }

 check__clauses__loop_7_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 check__clauses__loop_7_clear_reason:
  reasonp = reasons;
 check__clauses__loop_7_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_loop_xcheck__clauses__loop_9);
  allocp[2] = makeint(1L);
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a0;
  allocp[5] = a1;
  allocp[6] = a2;
  allocp[7] = a3;
  allocp[8] = a4;
  allocp[9] = a5;
  allocp[10] = a6;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[13] = a4;
  allocp[14] = x1 = makeref(&allocp[14]);
  allocp[15] = x0;
  qp = (struct goalrec*)&allocp[11];
  allocp += 16;
  proceed();
 check__clauses__loop_7_ext_interrupt:
  reasonp = 0l;
 check__clauses__loop_7_interrupt:
  toppred = &predicate_loop_xcheck__clauses__loop_7;
  goto interrupt_7;
 }

 check__clauses__loop_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 check__clauses__loop_9_clear_reason:
  reasonp = reasons;
 check__clauses__loop_9_0:
 check__clauses__loop_9_1:
  if (!isint(a0)) goto check__clauses__loop_9_18;
 check__clauses__loop_9_2:
  if (!isint(a1)) goto check__clauses__loop_9_17;
  gblt_less_or_eq(a0,a1,check__clauses__loop_9_19);
 check__clauses__loop_9_3:
  if (isref(a6)) goto check__clauses__loop_9_16;
  gblt_arg(a0,a6,x0,check__clauses__loop_9_19);
 check__clauses__loop_9_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_clause_4)) goto check__clauses__loop_9_19;
  x1 = arg(x0, 0);
 check__clauses__loop_9_5:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_functor_1)) goto check__clauses__loop_9_19;
  x2 = arg(x1, 0);
 check__clauses__loop_9_6:
  if (isref(x2)) goto check__clauses__loop_9_15;
  gblt_pfunctor(x2,x3,check__clauses__loop_9_19);
 check__clauses__loop_9_7:
  if (isref(x3)) goto check__clauses__loop_9_14;
 check__clauses__loop_9_8:
  if (isref(x3)) goto check__clauses__loop_9_13;
  if_not_equal(x3, a3, check__clauses__loop_9_19);
  gblt_arity(x2,x4,check__clauses__loop_9_19);
 check__clauses__loop_9_9:
  if (isref(x4)) goto check__clauses__loop_9_12;
 check__clauses__loop_9_10:
  if (isref(x4)) goto check__clauses__loop_9_11;
  if_not_equal(x4, a4, check__clauses__loop_9_19);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_loop_xcheck__clauses__loop_9);
  allocp[2] = x5 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x5;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_parse__uty_xupdate__clause_5);
  allocp[18] = a2;
  allocp[19] = a0;
  allocp[20] = x7 = makeref(&allocp[20]);
  allocp[21] = x8 = makeref(&allocp[21]);
  allocp[22] = x6;
  allocp[23] = (q)(struct goalrec*)&allocp[16];
  allocp[24] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[25] = makeint(3L);
  allocp[26] = x0;
  allocp[27] = x9 = makeref(&allocp[27]);
  allocp[28] = x7;
  a0 = a2;
  a1 = arg(x0, 2);
  a2 = x9;
  a3 = a5;
  a4 = a7;
  a5 = x8;
  qp = (struct goalrec*)&allocp[23];
  allocp += 29;
  execute(check__bodys__loop_6_clear_reason);
  goto check__bodys__loop_6_ext_interrupt;
 check__clauses__loop_9_11:
  deref_and_jump(x4,check__clauses__loop_9_10);
  *reasonp++ =  x4;
  goto check__clauses__loop_9_19;
 check__clauses__loop_9_12:
  deref_and_jump(x4,check__clauses__loop_9_9);
  *reasonp++ =  x4;
  goto check__clauses__loop_9_19;
 check__clauses__loop_9_13:
  deref_and_jump(x3,check__clauses__loop_9_8);
  *reasonp++ =  x3;
  goto check__clauses__loop_9_19;
 check__clauses__loop_9_14:
  deref_and_jump(x3,check__clauses__loop_9_7);
  *reasonp++ =  x3;
  goto check__clauses__loop_9_19;
 check__clauses__loop_9_15:
  deref_and_jump(x2,check__clauses__loop_9_6);
  *reasonp++ =  x2;
  goto check__clauses__loop_9_19;
 case VARREF:
  deref_and_jump(x1,check__clauses__loop_9_5);
  *reasonp++ =  x1;
  goto check__clauses__loop_9_19;
  };
  goto check__clauses__loop_9_19;
 case VARREF:
  deref_and_jump(x0,check__clauses__loop_9_4);
  *reasonp++ =  x0;
  goto check__clauses__loop_9_19;
  };
  goto check__clauses__loop_9_19;
 check__clauses__loop_9_16:
  deref_and_jump(a6,check__clauses__loop_9_3);
  *reasonp++ =  a6;
  goto check__clauses__loop_9_19;
 check__clauses__loop_9_17:
  if (!isref(a1)) goto check__clauses__loop_9_19;
  deref_and_jump(a1,check__clauses__loop_9_2);
  *reasonp++ =  a1;
  goto check__clauses__loop_9_19;
 check__clauses__loop_9_18:
  if (!isref(a0)) goto check__clauses__loop_9_19;
  deref_and_jump(a0,check__clauses__loop_9_1);
  *reasonp++ =  a0;
  goto check__clauses__loop_9_19;
 check__clauses__loop_9_19:
  otherwise(check__clauses__loop_9_interrupt);
 check__clauses__loop_9_20:
  if (!isint(a0)) goto check__clauses__loop_9_24;
 check__clauses__loop_9_21:
  if (!isint(a1)) goto check__clauses__loop_9_23;
  gblt_less_or_eq(a0,a1,check__clauses__loop_9_22);
  x0 = makeint(1L);
  bblt_add_no_check(a0,x0,x1);
  a0 = x1;
  execute(check__clauses__loop_9_0);
  goto check__clauses__loop_9_ext_interrupt;
 check__clauses__loop_9_22:
  gblt_greater(a0,a1,check__clauses__loop_9_interrupt);
  unify(a8, a7);
  proceed();
 check__clauses__loop_9_23:
  if (!isref(a1)) goto check__clauses__loop_9_interrupt;
  deref_and_jump(a1,check__clauses__loop_9_21);
  *reasonp++ =  a1;
  goto check__clauses__loop_9_interrupt;
 check__clauses__loop_9_24:
  if (!isref(a0)) goto check__clauses__loop_9_interrupt;
  deref_and_jump(a0,check__clauses__loop_9_20);
  *reasonp++ =  a0;
  goto check__clauses__loop_9_interrupt;
 check__clauses__loop_9_ext_interrupt:
  reasonp = 0l;
 check__clauses__loop_9_interrupt:
  goto interrupt_9;
 }

 check__bodys__loop_6_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 check__bodys__loop_6_clear_reason:
  reasonp = reasons;
 check__bodys__loop_6_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_loop_xcheck__bodys__loop_8);
  allocp[2] = makeint(1L);
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a0;
  allocp[5] = a1;
  allocp[6] = a2;
  allocp[7] = a3;
  allocp[8] = a4;
  allocp[9] = a5;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[12] = a1;
  allocp[13] = x1 = makeref(&allocp[13]);
  allocp[14] = x0;
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 check__bodys__loop_6_ext_interrupt:
  reasonp = 0l;
 check__bodys__loop_6_interrupt:
  toppred = &predicate_loop_xcheck__bodys__loop_6;
  goto interrupt_6;
 }

 check__bodys__loop_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 check__bodys__loop_8_clear_reason:
  reasonp = reasons;
 check__bodys__loop_8_0:
 check__bodys__loop_8_1:
  if (!isint(a0)) goto check__bodys__loop_8_5;
 check__bodys__loop_8_2:
  if (!isint(a1)) goto check__bodys__loop_8_4;
  gblt_less_or_eq(a0,a1,check__bodys__loop_8_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_loop_xcheck__bodys__loop_8);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[12] = a0;
  allocp[13] = makeint(1L);
  allocp[14] = x0;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[17] = a0;
  allocp[18] = a3;
  allocp[19] = x3 = makeref(&allocp[19]);
  allocp[20] = x1;
  allocp[21] = (q)(struct goalrec*)&allocp[15];
  allocp[22] = (q)(&predicate_loop_xcheck__body__loop_8);
  allocp[23] = a2;
  allocp[24] = x4 = makeref(&allocp[24]);
  allocp[25] = x5 = makeref(&allocp[25]);
  allocp[26] = x6 = makeref(&allocp[26]);
  allocp[27] = x3;
  allocp[28] = a5;
  allocp[29] = a6;
  allocp[30] = x2;
  allocp[31] = makesym(functor_options_2);
  allocp[32] = x4;
  allocp[33] = x5;
  x7 = makefunctor(&allocp[31]);
  allocp[34] = (q)(struct goalrec*)&allocp[21];
  allocp[35] = (q)(&predicate_parse__uty_xdecode__goal_3);
  allocp[36] = x8 = makeref(&allocp[36]);
  allocp[37] = x6;
  allocp[38] = x7;
  allocp[39] = (q)(struct goalrec*)&allocp[34];
  allocp[40] = (q)(&predicate_functor__table_xarg_3);
  allocp[41] = a0;
  allocp[42] = a3;
  allocp[43] = x8;
  qp = (struct goalrec*)&allocp[39];
  allocp += 44;
  proceed();
 check__bodys__loop_8_3:
  gblt_greater(a0,a1,check__bodys__loop_8_interrupt);
  unify2(a7, a6, a4, a3);
  proceed();
 check__bodys__loop_8_4:
  if (!isref(a1)) goto check__bodys__loop_8_interrupt;
  deref_and_jump(a1,check__bodys__loop_8_2);
  *reasonp++ =  a1;
  goto check__bodys__loop_8_interrupt;
 check__bodys__loop_8_5:
  if (!isref(a0)) goto check__bodys__loop_8_interrupt;
  deref_and_jump(a0,check__bodys__loop_8_1);
  *reasonp++ =  a0;
  goto check__bodys__loop_8_interrupt;
 check__bodys__loop_8_ext_interrupt:
  reasonp = 0l;
 check__bodys__loop_8_interrupt:
  goto interrupt_8;
 }

 check__body__loop_8_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 check__body__loop_8_clear_reason:
  reasonp = reasons;
 check__body__loop_8_0:
 check__body__loop_8_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom___)) goto check__body__loop_8_4;
 check__body__loop_8_2:
  if (isref(a3)) goto check__body__loop_8_3;
  gblt_pfunctor(a3,x0,check__body__loop_8_4);
  gblt_arity(a3,x1,check__body__loop_8_4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_loop_xcheck__body__loop_5);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = makesym(atom___);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  a1 = x0;
  a2 = x1;
  a3 = a5;
  a4 = x2;
  a5 = a6;
  a6 = a7;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(check__loop_7_0);
  goto check__loop_7_ext_interrupt;
 check__body__loop_8_3:
  deref_and_jump(a3,check__body__loop_8_2);
  *reasonp++ =  a3;
  goto check__body__loop_8_4;
 case VARREF:
  deref_and_jump(a1,check__body__loop_8_1);
  *reasonp++ =  a1;
  goto check__body__loop_8_4;
  };
  goto check__body__loop_8_4;
 check__body__loop_8_4:
  otherwise(check__body__loop_8_interrupt);
 check__body__loop_8_5:
  if (isref(a3)) goto check__body__loop_8_6;
  gblt_pfunctor(a3,x0,check__body__loop_8_interrupt);
  gblt_arity(a3,x1,check__body__loop_8_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_loop_xcheck__body__loop_5);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  a0 = a1;
  a1 = x0;
  a2 = x1;
  a3 = a5;
  a4 = x2;
  a5 = a6;
  a6 = a7;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(check__loop_7_0);
  goto check__loop_7_ext_interrupt;
 check__body__loop_8_6:
  deref_and_jump(a3,check__body__loop_8_5);
  *reasonp++ =  a3;
  goto check__body__loop_8_interrupt;
 check__body__loop_8_ext_interrupt:
  reasonp = 0l;
 check__body__loop_8_interrupt:
  goto interrupt_8;
 }

 check__body__loop_5_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 check__body__loop_5_clear_reason:
  reasonp = reasons;
 check__body__loop_5_0:
 check__body__loop_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto check__body__loop_5_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
 check__body__loop_5_2:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom___)) goto check__body__loop_5_interrupt;
  allocp[0] = makesym(functor_options_2);
  allocp[1] = a1;
  allocp[2] = makefunctor(funct_const_0);
  x0 = makefunctor(&allocp[0]);
  allocp[3] = (q)qp;
  allocp[4] = (q)(&predicate_parse__uty_xencode__goal_3);
  allocp[5] = a3;
  allocp[6] = x0;
  allocp[7] = a4;
  qp = (struct goalrec*)&allocp[3];
  allocp += 8;
  proceed();
 case FUNCTOR:
  switch (symval(functor_of(a2))) {
 case functor_atom_1:
  x0 = arg(a2, 0);
 check__body__loop_5_3:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_recursive)) goto check__body__loop_5_interrupt;
  allocp[0] = makesym(functor_options_2);
  allocp[1] = a1;
  allocp[2] = a2;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = (q)qp;
  allocp[4] = (q)(&predicate_parse__uty_xencode__goal_3);
  allocp[5] = a3;
  allocp[6] = x1;
  allocp[7] = a4;
  qp = (struct goalrec*)&allocp[3];
  allocp += 8;
  proceed();
 case VARREF:
  deref_and_jump(x0,check__body__loop_5_3);
  *reasonp++ =  x0;
  goto check__body__loop_5_interrupt;
  };
  goto check__body__loop_5_interrupt;
 case functor_functor_1:
  x0 = arg(a2, 0);
 check__body__loop_5_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_node_1)) goto check__body__loop_5_interrupt;
  allocp[0] = makesym(functor_options_2);
  allocp[1] = a1;
  allocp[2] = a2;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = (q)qp;
  allocp[4] = (q)(&predicate_parse__uty_xencode__goal_3);
  allocp[5] = a3;
  allocp[6] = x1;
  allocp[7] = a4;
  qp = (struct goalrec*)&allocp[3];
  allocp += 8;
  proceed();
 case VARREF:
  deref_and_jump(x0,check__body__loop_5_4);
  *reasonp++ =  x0;
  goto check__body__loop_5_interrupt;
  };
  goto check__body__loop_5_interrupt;
  };
  goto check__body__loop_5_interrupt;
 case VARREF:
  deref_and_jump(a2,check__body__loop_5_2);
  *reasonp++ =  a2;
  goto check__body__loop_5_interrupt;
  };
  goto check__body__loop_5_interrupt;
 case symval(makesym(atom_no)):
  allocp[0] = makesym(functor_options_2);
  allocp[1] = a1;
  allocp[2] = a2;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = (q)qp;
  allocp[4] = (q)(&predicate_parse__uty_xencode__goal_3);
  allocp[5] = a3;
  allocp[6] = x0;
  allocp[7] = a4;
  qp = (struct goalrec*)&allocp[3];
  allocp += 8;
  proceed();
  };
  goto check__body__loop_5_interrupt;
 case VARREF:
  deref_and_jump(a0,check__body__loop_5_1);
  *reasonp++ =  a0;
  goto check__body__loop_5_interrupt;
  };
  goto check__body__loop_5_interrupt;
 check__body__loop_5_ext_interrupt:
  reasonp = 0l;
 check__body__loop_5_interrupt:
  goto interrupt_5;
 }

 check__ancestors_5_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 check__ancestors_5_clear_reason:
  reasonp = reasons;
 check__ancestors_5_0:
 check__ancestors_5_1:
  switch (ptagof(a3)) {
 case CONS:
  x0 = car_of(a3);
 check__ancestors_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_ancestor_3)) goto check__ancestors_5_15;
  x1 = arg(x0, 0);
 check__ancestors_5_3:
  if (isref(x1)) goto check__ancestors_5_14;
 check__ancestors_5_4:
  if (isref(x1)) goto check__ancestors_5_13;
  if_not_equal(x1, a0, check__ancestors_5_15);
  x2 = arg(x0, 1);
 check__ancestors_5_5:
  if (isref(x2)) goto check__ancestors_5_12;
 check__ancestors_5_6:
  if (isref(x2)) goto check__ancestors_5_11;
  if_not_equal(x2, a1, check__ancestors_5_15);
  x3 = arg(x0, 2);
 check__ancestors_5_7:
  if (isref(x3)) goto check__ancestors_5_10;
 check__ancestors_5_8:
  if (isref(x3)) goto check__ancestors_5_9;
  if_not_equal(x3, a2, check__ancestors_5_15);
  x4 = makesym(atom_yes);
  unify_value(a4, x4);
  proceed();
 check__ancestors_5_9:
  deref_and_jump(x3,check__ancestors_5_8);
  *reasonp++ =  x3;
  goto check__ancestors_5_15;
 check__ancestors_5_10:
  deref_and_jump(x3,check__ancestors_5_7);
  *reasonp++ =  x3;
  goto check__ancestors_5_15;
 check__ancestors_5_11:
  deref_and_jump(x2,check__ancestors_5_6);
  *reasonp++ =  x2;
  goto check__ancestors_5_15;
 check__ancestors_5_12:
  deref_and_jump(x2,check__ancestors_5_5);
  *reasonp++ =  x2;
  goto check__ancestors_5_15;
 check__ancestors_5_13:
  deref_and_jump(x1,check__ancestors_5_4);
  *reasonp++ =  x1;
  goto check__ancestors_5_15;
 check__ancestors_5_14:
  deref_and_jump(x1,check__ancestors_5_3);
  *reasonp++ =  x1;
  goto check__ancestors_5_15;
 case VARREF:
  deref_and_jump(x0,check__ancestors_5_2);
  *reasonp++ =  x0;
  goto check__ancestors_5_15;
  };
  goto check__ancestors_5_15;
 case VARREF:
  deref_and_jump(a3,check__ancestors_5_1);
  *reasonp++ =  a3;
  goto check__ancestors_5_15;
  };
  goto check__ancestors_5_15;
 check__ancestors_5_15:
  otherwise(check__ancestors_5_interrupt);
 check__ancestors_5_16:
  switch (ptagof(a3)) {
 case CONS:
  a3 = cdr_of(a3);
  execute(check__ancestors_5_0);
  goto check__ancestors_5_ext_interrupt;
 case ATOMIC:
  if (a3 != NILATOM) goto check__ancestors_5_interrupt;
  x0 = makesym(atom_no);
  unify_value(a4, x0);
  proceed();
 case VARREF:
  deref_and_jump(a3,check__ancestors_5_16);
  *reasonp++ =  a3;
  goto check__ancestors_5_interrupt;
  };
  goto check__ancestors_5_interrupt;
 check__ancestors_5_ext_interrupt:
  reasonp = 0l;
 check__ancestors_5_interrupt:
  toppred = &predicate_loop_xcheck__ancestors_5;
  goto interrupt_5;
 }
 interrupt_9:
  allocp[10] = a8;
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_loop);
}
