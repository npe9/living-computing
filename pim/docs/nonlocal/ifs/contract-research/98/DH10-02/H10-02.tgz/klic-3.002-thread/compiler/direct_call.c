/* Compiled by KLIC compiler version 3.002 (Wed Sep 17 15:37:13 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_direct__call();
Const struct predicate predicate_direct__call_xmain_2 =
   { module_direct__call, 0, 2 };
Const struct predicate predicate_direct__call_xcheck__call_8 =
   { module_direct__call, 1, 8 };
Const struct predicate predicate_direct__call_xcheck__clauses_7 =
   { module_direct__call, 2, 7 };
Const struct predicate predicate_direct__call_xadd__go_7 =
   { module_direct__call, 3, 7 };
Const struct predicate predicate_direct__call_xadd__go_9 =
   { module_direct__call, 4, 9 };
Const struct predicate predicate_direct__call_xcheck__nextgoal_3 =
   { module_direct__call, 5, 3 };
Const struct predicate predicate_direct__call_xcheck__builtins_3 =
   { module_direct__call, 6, 3 };
Const struct predicate predicate_direct__call_xcheck__nextgoal_6 =
   { module_direct__call, 7, 6 };
Const struct predicate predicate_direct__call_xcreate__nextgoal__builtin_5 =
   { module_direct__call, 8, 5 };
Const struct predicate predicate_direct__call_xcreate__nextgoal__builtin2_5 =
   { module_direct__call, 9, 5 };
Const struct predicate predicate_direct__call_xcreate__nextgoal__builtin3_6 =
   { module_direct__call, 10, 6 };
Const struct predicate predicate_direct__call_xcheck__subset__thru_3 =
   { module_direct__call, 11, 3 };
Const struct predicate predicate_direct__call_xcheck__subset__thru2_5 =
   { module_direct__call, 12, 5 };
Const struct predicate predicate_direct__call_xsee__nextgoal_4 =
   { module_direct__call, 13, 4 };
Const struct predicate predicate_direct__call_xcheck__nextgoal2_6 =
   { module_direct__call, 14, 6 };
Const struct predicate predicate_direct__call_xget__nextgoals_5 =
   { module_direct__call, 15, 5 };
Const struct predicate predicate_direct__call_xcheck__nextgoal4_7 =
   { module_direct__call, 16, 7 };
Const struct predicate predicate_direct__call_xcheck__nextgoal3_4 =
   { module_direct__call, 17, 4 };
Const struct predicate predicate_direct__call_xcreate__nextgoal_4 =
   { module_direct__call, 18, 4 };
Const struct predicate predicate_direct__call_xcheck__brothergoals_3 =
   { module_direct__call, 19, 3 };
Const struct predicate predicate_direct__call_xcheck__brothergoals_4 =
   { module_direct__call, 20, 4 };
Const struct predicate predicate_direct__call_xcheck__cyclic_4 =
   { module_direct__call, 21, 4 };
Const struct predicate predicate_direct__call_xcheck__cyclic2_5 =
   { module_direct__call, 22, 5 };
Const struct predicate predicate_direct__call_xcheck__cyclic_3 =
   { module_direct__call, 23, 3 };
Const struct predicate predicate_direct__call_xsee__cyclic_5 =
   { module_direct__call, 24, 5 };
Const struct predicate predicate_direct__call_xcheck__include_3 =
   { module_direct__call, 25, 3 };
Const struct predicate predicate_direct__call_xcheck__include_4 =
   { module_direct__call, 26, 4 };
Const struct predicate predicate_direct__call_xsee__cyclic2_6 =
   { module_direct__call, 27, 6 };
Const struct predicate predicate_direct__call_xsee__cyclic__bodys_5 =
   { module_direct__call, 28, 5 };
Const struct predicate predicate_direct__call_xsee__cyclic__body_6 =
   { module_direct__call, 29, 6 };
Const struct predicate predicate_direct__call_xcheck__brothergoals2_5 =
   { module_direct__call, 30, 5 };
Const struct predicate predicate_direct__call_xcheck__brothergoal_3 =
   { module_direct__call, 31, 3 };
Const struct predicate predicate_direct__call_xcheck__brothers_9 =
   { module_direct__call, 32, 9 };
Const struct predicate predicate_direct__call_xcheck__brothers2_10 =
   { module_direct__call, 33, 10 };
Const struct predicate predicate_direct__call_xcheck__brothers3_11 =
   { module_direct__call, 34, 11 };
Const struct predicate predicate_direct__call_xcheck__brothers4_11 =
   { module_direct__call, 35, 11 };
Const struct predicate predicate_direct__call_xcheck__childgoals_8 =
   { module_direct__call, 36, 8 };
Const struct predicate predicate_direct__call_xcheck__childgoals2_9 =
   { module_direct__call, 37, 9 };
Const struct predicate predicate_direct__call_xadd__go2_6 =
   { module_direct__call, 38, 6 };
Const struct predicate predicate_direct__call_xcheck__builtin_4 =
   { module_direct__call, 39, 4 };
Const struct predicate predicate_direct__call_xcheck__builtin_6 =
   { module_direct__call, 40, 6 };
Const struct predicate predicate_direct__call_xrecursive__bodys_9 =
   { module_direct__call, 41, 9 };
Const struct predicate predicate_direct__call_xrecursive__bodys1_9 =
   { module_direct__call, 42, 9 };
Const struct predicate predicate_direct__call_xrecursive__body_13 =
   { module_direct__call, 43, 13 };
Const struct predicate predicate_direct__call_xmake__newthru_3 =
   { module_direct__call, 44, 3 };
Const struct predicate predicate_direct__call_xrecursive__body2_10 =
   { module_direct__call, 45, 10 };
Const struct predicate predicate_direct__call_xmake__nextgoal_10 =
   { module_direct__call, 46, 10 };
Const struct predicate predicate_direct__call_xmove__preds_5 =
   { module_direct__call, 47, 5 };
Const struct predicate predicate_direct__call_xmove__clauses_7 =
   { module_direct__call, 48, 7 };
Const struct predicate predicate_direct__call_xmove__clause_7 =
   { module_direct__call, 49, 7 };
Const struct predicate predicate_direct__call_xmove__bodys_9 =
   { module_direct__call, 50, 9 };
Const struct predicate predicate_direct__call_xmove__body_8 =
   { module_direct__call, 51, 8 };
Const struct predicate predicate_direct__call_xcheck__cn_4 =
   { module_direct__call, 52, 4 };
Const struct predicate predicate_direct__call_xcheck__cn2_3 =
   { module_direct__call, 53, 3 };
Const struct predicate predicate_direct__call_xcheck__cn3_5 =
   { module_direct__call, 54, 5 };
Const struct predicate predicate_direct__call_xcheck__cn4_4 =
   { module_direct__call, 55, 4 };
Const struct predicate predicate_direct__call_xcheck__cn5_3 =
   { module_direct__call, 56, 3 };
Const struct predicate predicate_direct__call_xcheck__movedgoal_4 =
   { module_direct__call, 57, 4 };
Const struct predicate predicate_direct__call_xreplace__thru_4 =
   { module_direct__call, 58, 4 };
Const struct predicate predicate_direct__call_xreplace__thru2_3 =
   { module_direct__call, 59, 3 };
Const struct predicate predicate_direct__call_xcheck__movedgoal2_4 =
   { module_direct__call, 60, 4 };
Const struct predicate predicate_direct__call_xrename__thru_3 =
   { module_direct__call, 61, 3 };
Const struct predicate predicate_direct__call_xrename__thru2_3 =
   { module_direct__call, 62, 3 };
Const struct predicate predicate_direct__call_xreplace_6 =
   { module_direct__call, 63, 6 };
Const struct predicate predicate_direct__call_xcheck__head_3 =
   { module_direct__call, 64, 3 };
Const struct predicate predicate_direct__call_xcheck__head2_5 =
   { module_direct__call, 65, 5 };
Const struct predicate predicate_direct__call_xreplace2_5 =
   { module_direct__call, 66, 5 };
Const struct predicate predicate_direct__call_xreplace__report__measure_4 =
   { module_direct__call, 67, 4 };
Const struct predicate predicate_direct__call_xreplace__report__measure2_4 =
   { module_direct__call, 68, 4 };
Const struct predicate predicate_direct__call_xreplace__report__measure__from_4 =
   { module_direct__call, 69, 4 };
Const struct predicate predicate_direct__call_xreplace__report__measure__to_5 =
   { module_direct__call, 70, 5 };
Const struct predicate predicate_direct__call_xmake__newbodys_4 =
   { module_direct__call, 71, 4 };
Const struct predicate predicate_direct__call_xmake__newbody_5 =
   { module_direct__call, 72, 5 };
Const struct predicate predicate_direct__call_xmake__newbody2_5 =
   { module_direct__call, 73, 5 };
Const struct predicate predicate_direct__call_xmake__newgoal_4 =
   { module_direct__call, 74, 4 };
Const struct predicate predicate_direct__call_xreplace3_3 =
   { module_direct__call, 75, 3 };
Const struct predicate predicate_direct__call_xreplace4_5 =
   { module_direct__call, 76, 5 };
Const struct predicate predicate_direct__call_xreplace4_6 =
   { module_direct__call, 77, 6 };
Const struct predicate predicate_direct__call_xreplace__clauses2_5 =
   { module_direct__call, 78, 5 };
Const struct predicate predicate_direct__call_xreplace__clauses_7 =
   { module_direct__call, 79, 7 };
Const struct predicate predicate_direct__call_xget__movegoal_3 =
   { module_direct__call, 80, 3 };
Const struct predicate predicate_direct__call_xreplace__clause_9 =
   { module_direct__call, 81, 9 };
Const struct predicate predicate_direct__call_xreplace__head_7 =
   { module_direct__call, 82, 7 };
Const struct predicate predicate_direct__call_xremake__functor_3 =
   { module_direct__call, 83, 3 };
Const struct predicate predicate_direct__call_xrename_4 =
   { module_direct__call, 84, 4 };
Const struct predicate predicate_direct__call_xremake__args_4 =
   { module_direct__call, 85, 4 };
Const struct predicate predicate_direct__call_xreplace__head2_6 =
   { module_direct__call, 86, 6 };
Const struct predicate predicate_direct__call_xcreate__newgoal_4 =
   { module_direct__call, 87, 4 };
Const struct predicate predicate_direct__call_xcreate__newgoal2_5 =
   { module_direct__call, 88, 5 };
Const struct predicate predicate_direct__call_xcreate__newbodys_3 =
   { module_direct__call, 89, 3 };
Const struct predicate predicate_direct__call_xcreate__newvar_3 =
   { module_direct__call, 90, 3 };
Const struct predicate predicate_direct__call_xget__vars_4 =
   { module_direct__call, 91, 4 };
Const struct predicate predicate_direct__call_xappend__variables_4 =
   { module_direct__call, 92, 4 };
Const struct predicate predicate_direct__call_xreplace__bodys_7 =
   { module_direct__call, 93, 7 };
Const struct predicate predicate_direct__call_xreplace__body_6 =
   { module_direct__call, 94, 6 };
Const struct predicate predicate_direct__call_xreplace__body2_4 =
   { module_direct__call, 95, 4 };
Const struct predicate predicate_direct__call_xget__max__vn_2 =
   { module_direct__call, 96, 2 };
Const struct predicate predicate_direct__call_xget__max__goals_3 =
   { module_direct__call, 97, 3 };
Const struct predicate predicate_direct__call_xget__max__goals2_4 =
   { module_direct__call, 98, 4 };
Const struct predicate predicate_direct__call_xget__max__goal_3 =
   { module_direct__call, 99, 3 };
Const struct predicate predicate_direct__call_xget__max__goal2_4 =
   { module_direct__call, 100, 4 };
Const struct predicate predicate_direct__call_xget__max__arg_3 =
   { module_direct__call, 101, 3 };
Const struct predicate predicate_direct__call_xremove__dummy_2 =
   { module_direct__call, 102, 2 };
Const struct predicate predicate_direct__call_xremove__dummy__clauses_3 =
   { module_direct__call, 103, 3 };
Const struct predicate predicate_direct__call_xremove__dummy__clause_2 =
   { module_direct__call, 104, 2 };
Const struct predicate predicate_direct__call_xremove__dummy__bodys_4 =
   { module_direct__call, 105, 4 };
extern Const struct predicate predicate_list_xsplit_4;
extern Const struct predicate predicate_list_xcheck__subset_3;
extern Const struct predicate predicate_list_xcheck__include_3;
extern Const struct predicate predicate_list_xappend_3;
extern Const struct predicate predicate_list_xcheck__elements_3;
extern Const struct predicate predicate_list_xmake__unique_2;
extern Const struct predicate predicate_functor_xinsert__arg_4;
extern Const struct predicate predicate_functor_xdelete__arg_3;
extern Const struct predicate predicate_integer__arithmetics_xadd_3;
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_generic_xgeneric_2;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_xsetarg_4;
extern Const struct predicate predicate_functor__table_xfunctor_3;
extern Const struct predicate predicate_parse__uty_xget__first__clause__info_4;
extern Const struct predicate predicate_parse__uty_xget__def__clauses_5;
extern Const struct predicate predicate_parse__uty_xupdate__clause_5;
extern Const struct predicate predicate_parse__uty_xdecode__goal_4;
extern Const struct predicate predicate_parse__uty_xdecode__goalcall_6;
extern Const struct predicate predicate_parse__uty_xget__clause_4;
extern Const struct predicate predicate_parse__uty_xencode__goal_4;
extern Const struct predicate predicate_atom__table_xget__atom__string_2;
extern Const struct predicate predicate_atom__table_xmake__atom_2;
extern Const struct predicate predicate_uty_xmax_3;

module module_direct__call(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  static Const unsigned char strconst_body_0[8] =
    "_dcall";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_0 =
      declare_string_constant_8(strconst_body_0,6);
  static Const q cons_const_1[] = {
    NILATOM,
    makesym(atom_dummy),
  };
  static Const q funct_const_2[] = {
    makesym(functor_functor_2),
    makesym(atom_dummy),
    makesym(atom_builtin),
  };
  static Const q funct_const_3[] = {
    makesym(functor_functor_1),
    makesym(atom_no__go),
  };
  static Const q funct_const_4[] = {
    makesym(functor__40_2),
    makefunctor(funct_const_2),
    makefunctor(funct_const_3),
  };
  static Const q funct_const_5[] = {
    makesym(functor_functor_1),
    makefunctor(funct_const_4),
  };
  static Const q funct_const_6[] = {
    makesym(functor_functor_2),
    makesym(atom_dummy),
    makesym(atom_builtin),
  };
  static Const q funct_const_7[] = {
    makesym(functor_atom_1),
    makesym(atom_dummy),
  };
  static Const q funct_const_8[] = {
    makesym(functor_options_2),
    makesym(atom___),
    makefunctor(funct_const_7),
  };
  q a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, main_2_top);
    case_pred(1, check__call_8_top);
    case_pred(2, check__clauses_7_top);
    case_pred(3, add__go_7_top);
    case_pred(4, add__go_9_top);
    case_pred(5, check__nextgoal_3_top);
    case_pred(6, check__builtins_3_top);
    case_pred(7, check__nextgoal_6_top);
    case_pred(8, create__nextgoal__builtin_5_top);
    case_pred(9, create__nextgoal__builtin2_5_top);
    case_pred(10, create__nextgoal__builtin3_6_top);
    case_pred(11, check__subset__thru_3_top);
    case_pred(12, check__subset__thru2_5_top);
    case_pred(13, see__nextgoal_4_top);
    case_pred(14, check__nextgoal2_6_top);
    case_pred(15, get__nextgoals_5_top);
    case_pred(16, check__nextgoal4_7_top);
    case_pred(17, check__nextgoal3_4_top);
    case_pred(18, create__nextgoal_4_top);
    case_pred(19, check__brothergoals_3_top);
    case_pred(20, check__brothergoals_4_top);
    case_pred(21, check__cyclic_4_top);
    case_pred(22, check__cyclic2_5_top);
    case_pred(23, check__cyclic_3_top);
    case_pred(24, see__cyclic_5_top);
    case_pred(25, check__include_3_top);
    case_pred(26, check__include_4_top);
    case_pred(27, see__cyclic2_6_top);
    case_pred(28, see__cyclic__bodys_5_top);
    case_pred(29, see__cyclic__body_6_top);
    case_pred(30, check__brothergoals2_5_top);
    case_pred(31, check__brothergoal_3_top);
    case_pred(32, check__brothers_9_top);
    case_pred(33, check__brothers2_10_top);
    case_pred(34, check__brothers3_11_top);
    case_pred(35, check__brothers4_11_top);
    case_pred(36, check__childgoals_8_top);
    case_pred(37, check__childgoals2_9_top);
    case_pred(38, add__go2_6_top);
    case_pred(39, check__builtin_4_top);
    case_pred(40, check__builtin_6_top);
    case_pred(41, recursive__bodys_9_top);
    case_pred(42, recursive__bodys1_9_top);
    case_pred(43, recursive__body_13_top);
    case_pred(44, make__newthru_3_top);
    case_pred(45, recursive__body2_10_top);
    case_pred(46, make__nextgoal_10_top);
    case_pred(47, move__preds_5_top);
    case_pred(48, move__clauses_7_top);
    case_pred(49, move__clause_7_top);
    case_pred(50, move__bodys_9_top);
    case_pred(51, move__body_8_top);
    case_pred(52, check__cn_4_top);
    case_pred(53, check__cn2_3_top);
    case_pred(54, check__cn3_5_top);
    case_pred(55, check__cn4_4_top);
    case_pred(56, check__cn5_3_top);
    case_pred(57, check__movedgoal_4_top);
    case_pred(58, replace__thru_4_top);
    case_pred(59, replace__thru2_3_top);
    case_pred(60, check__movedgoal2_4_top);
    case_pred(61, rename__thru_3_top);
    case_pred(62, rename__thru2_3_top);
    case_pred(63, replace_6_top);
    case_pred(64, check__head_3_top);
    case_pred(65, check__head2_5_top);
    case_pred(66, replace2_5_top);
    case_pred(67, replace__report__measure_4_top);
    case_pred(68, replace__report__measure2_4_top);
    case_pred(69, replace__report__measure__from_4_top);
    case_pred(70, replace__report__measure__to_5_top);
    case_pred(71, make__newbodys_4_top);
    case_pred(72, make__newbody_5_top);
    case_pred(73, make__newbody2_5_top);
    case_pred(74, make__newgoal_4_top);
    case_pred(75, replace3_3_top);
    case_pred(76, replace4_5_top);
    case_pred(77, replace4_6_top);
    case_pred(78, replace__clauses2_5_top);
    case_pred(79, replace__clauses_7_top);
    case_pred(80, get__movegoal_3_top);
    case_pred(81, replace__clause_9_top);
    case_pred(82, replace__head_7_top);
    case_pred(83, remake__functor_3_top);
    case_pred(84, rename_4_top);
    case_pred(85, remake__args_4_top);
    case_pred(86, replace__head2_6_top);
    case_pred(87, create__newgoal_4_top);
    case_pred(88, create__newgoal2_5_top);
    case_pred(89, create__newbodys_3_top);
    case_pred(90, create__newvar_3_top);
    case_pred(91, get__vars_4_top);
    case_pred(92, append__variables_4_top);
    case_pred(93, replace__bodys_7_top);
    case_pred(94, replace__body_6_top);
    case_pred(95, replace__body2_4_top);
    case_pred(96, get__max__vn_2_top);
    case_pred(97, get__max__goals_3_top);
    case_pred(98, get__max__goals2_4_top);
    case_pred(99, get__max__goal_3_top);
    case_pred(100, get__max__goal2_4_top);
    case_pred(101, get__max__arg_3_top);
    case_pred(102, remove__dummy_2_top);
    case_pred(103, remove__dummy__clauses_3_top);
    case_pred(104, remove__dummy__clause_2_top);
    last_case_pred(105, remove__dummy__bodys_4_top);
  }

 main_2_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  qp = qp->next;
 main_2_clear_reason:
  reasonp = reasons;
 main_2_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xremove__dummy_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_direct__call_xmove__preds_5);
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = x1;
  allocp[8] = x0;
  allocp[9] = NILATOM;
  allocp[10] = x2 = makeref(&allocp[10]);
  allocp[11] = (q)(struct goalrec*)&allocp[4];
  allocp[12] = (q)(&predicate_direct__call_xcheck__call_8);
  allocp[13] = x3 = makeref(&allocp[13]);
  allocp[14] = x4 = makeref(&allocp[14]);
  allocp[15] = x5 = makeref(&allocp[15]);
  allocp[16] = makesym(atom___);
  allocp[17] = a0;
  allocp[18] = x1;
  allocp[19] = NILATOM;
  allocp[20] = x6 = makeref(&allocp[20]);
  allocp[21] = (q)(struct goalrec*)&allocp[11];
  allocp[22] = (q)(&predicate_parse__uty_xget__first__clause__info_4);
  allocp[23] = x3;
  allocp[24] = x4;
  allocp[25] = x5;
  allocp[26] = a0;
  qp = (struct goalrec*)&allocp[21];
  allocp += 27;
  proceed();
 main_2_ext_interrupt:
  reasonp = 0l;
 main_2_interrupt:
  goto interrupt_2;
 }

 check__call_8_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 check__call_8_clear_reason:
  reasonp = reasons;
 check__call_8_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xcheck__clauses_7);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a3;
  allocp[5] = a4;
  allocp[6] = a5;
  allocp[7] = a6;
  allocp[8] = a7;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_parse__uty_xget__def__clauses_5);
  allocp[11] = a0;
  allocp[12] = a1;
  allocp[13] = a2;
  allocp[14] = x0;
  allocp[15] = a4;
  qp = (struct goalrec*)&allocp[9];
  allocp += 16;
  proceed();
 check__call_8_ext_interrupt:
  reasonp = 0l;
 check__call_8_interrupt:
  toppred = &predicate_direct__call_xcheck__call_8;
  goto interrupt_8;
 }

 check__clauses_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 check__clauses_7_clear_reason:
  reasonp = reasons;
 check__clauses_7_0:
 check__clauses_7_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 check__clauses_7_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_cl_2)) goto check__clauses_7_interrupt;
  x1 = arg(x0, 1);
 check__clauses_7_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_clause_4)) goto check__clauses_7_interrupt;
  x2 = arg(x1, 2);
 check__clauses_7_4:
  if (isref(x2)) goto check__clauses_7_5;
  gblt_pfunctor(x2,x3,check__clauses_7_interrupt);
  gblt_arity(x2,x4,check__clauses_7_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xcheck__clauses_7);
  x5 = cdr_of(a0);
  allocp[2] = x5;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x6 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x7 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_direct__call_xrecursive__bodys_9);
  allocp[11] = x8 = makeref(&allocp[11]);
  allocp[12] = x9 = makeref(&allocp[12]);
  allocp[13] = a1;
  x10 = arg(x0, 0);
  allocp[14] = x10;
  allocp[15] = a2;
  allocp[16] = x11 = makeref(&allocp[16]);
  allocp[17] = x6;
  allocp[18] = a5;
  allocp[19] = x7;
  allocp[20] = (q)(struct goalrec*)&allocp[9];
  allocp[21] = (q)(&predicate_parse__uty_xupdate__clause_5);
  allocp[22] = a1;
  allocp[23] = x10;
  allocp[24] = x12 = makeref(&allocp[24]);
  allocp[25] = a3;
  allocp[26] = x11;
  allocp[27] = (q)(struct goalrec*)&allocp[20];
  allocp[28] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[29] = makeint(3L);
  allocp[30] = x1;
  allocp[31] = x9;
  allocp[32] = x12;
  a0 = x4;
  x13 = a1;
  a4 = a2;
  a5 = a3;
  a6 = x8;
  a3 = x13;
  a2 = x9;
  a1 = x2;
  qp = (struct goalrec*)&allocp[27];
  allocp += 33;
  execute(add__go_7_0);
  goto add__go_7_ext_interrupt;
 check__clauses_7_5:
  deref_and_jump(x2,check__clauses_7_4);
  *reasonp++ =  x2;
  goto check__clauses_7_interrupt;
 case VARREF:
  deref_and_jump(x1,check__clauses_7_3);
  *reasonp++ =  x1;
  goto check__clauses_7_interrupt;
  };
  goto check__clauses_7_interrupt;
 case VARREF:
  deref_and_jump(x0,check__clauses_7_2);
  *reasonp++ =  x0;
  goto check__clauses_7_interrupt;
  };
  goto check__clauses_7_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto check__clauses_7_interrupt;
  unify2(a6, a5, a4, a3);
  proceed();
 case VARREF:
  deref_and_jump(a0,check__clauses_7_1);
  *reasonp++ =  a0;
  goto check__clauses_7_interrupt;
  };
  goto check__clauses_7_interrupt;
 check__clauses_7_ext_interrupt:
  reasonp = 0l;
 check__clauses_7_interrupt:
  goto interrupt_7;
 }

 add__go_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 add__go_7_clear_reason:
  reasonp = reasons;
 add__go_7_0:
 add__go_7_1:
  if (!isint(a0)) goto add__go_7_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,add__go_7_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xadd__go_9);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = a0;
  allocp[6] = a1;
  allocp[7] = a2;
  allocp[8] = a4;
  allocp[9] = a5;
  allocp[10] = a6;
  allocp[11] = makesym(functor_options_2);
  allocp[12] = x5 = makeref(&allocp[12]);
  allocp[13] = x2;
  x4 = makefunctor(&allocp[11]);
  allocp[14] = (q)(struct goalrec*)&allocp[0];
  allocp[15] = (q)(&predicate_parse__uty_xdecode__goal_4);
  allocp[16] = x6 = makeref(&allocp[16]);
  allocp[17] = x3;
  allocp[18] = x7 = makeref(&allocp[18]);
  allocp[19] = x4;
  allocp[20] = (q)(struct goalrec*)&allocp[14];
  allocp[21] = (q)(&predicate_functor__table_xarg_3);
  allocp[22] = a0;
  allocp[23] = a1;
  allocp[24] = x6;
  x8 = a3;
  x9 = a0;
  a2 = a1;
  a3 = x1;
  a1 = x9;
  a0 = x8;
  qp = (struct goalrec*)&allocp[20];
  allocp += 25;
  execute(check__builtin_4_0);
  goto check__builtin_4_ext_interrupt;
 add__go_7_2:
  if (a0 != makeint(0L)) goto add__go_7_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xadd__go_9);
  allocp[2] = x10 = makeref(&allocp[2]);
  allocp[3] = makesym(atom___);
  allocp[4] = makesym(atom___);
  allocp[5] = makeint(0L);
  allocp[6] = a1;
  allocp[7] = a2;
  allocp[8] = a4;
  allocp[9] = a5;
  allocp[10] = a6;
  x11 = a3;
  x12 = a0;
  a2 = a1;
  a3 = x10;
  a1 = x12;
  a0 = x11;
  qp = (struct goalrec*)&allocp[0];
  allocp += 11;
  execute(check__builtin_4_0);
  goto check__builtin_4_ext_interrupt;
 add__go_7_3:
  if (!isref(a0)) goto add__go_7_interrupt;
  deref_and_jump(a0,add__go_7_1);
  *reasonp++ =  a0;
  goto add__go_7_interrupt;
 add__go_7_ext_interrupt:
  reasonp = 0l;
 add__go_7_interrupt:
  toppred = &predicate_direct__call_xadd__go_7;
  goto interrupt_7;
 }

 add__go_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 add__go_9_clear_reason:
  reasonp = reasons;
 add__go_9_0:
 add__go_9_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_yes)) goto add__go_9_4;
 add__go_9_2:
  switch (ptagof(a6)) {
 case ATOMIC:
  if (a6 != makesym(atom___)) goto add__go_9_4;
 add__go_9_3:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_dummy)) goto add__go_9_4;
  x0 = makesym(atom_no);
  unify_value(a8, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = a3;
  allocp[3] = a4;
  allocp[4] = makefunctor(funct_const_5);
  allocp[5] = a5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  proceed();
 case VARREF:
  deref_and_jump(a2,add__go_9_3);
  *reasonp++ =  a2;
  goto add__go_9_4;
  };
  goto add__go_9_4;
 case VARREF:
  deref_and_jump(a6,add__go_9_2);
  *reasonp++ =  a6;
  goto add__go_9_4;
  };
  goto add__go_9_4;
 case VARREF:
  deref_and_jump(a0,add__go_9_1);
  *reasonp++ =  a0;
  goto add__go_9_4;
  };
  goto add__go_9_4;
 add__go_9_4:
  otherwise(add__go_9_interrupt);
 add__go_9_5:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_yes)) goto add__go_9_14;
 add__go_9_6:
  switch (ptagof(a6)) {
 case ATOMIC:
  if (a6 != makesym(atom___)) goto add__go_9_7;
  x0 = makeint(1L);
  bblt_add_no_check_y(a3,x0,x1);
  x2 = makesym(atom_no);
  unify_value(a8, x2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor_xinsert__arg_4);
  allocp[2] = x1;
  allocp[3] = a4;
  allocp[4] = makefunctor(funct_const_5);
  allocp[5] = a5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  proceed();
 case VARREF:
  deref_and_jump(a6,add__go_9_6);
  *reasonp++ =  a6;
  goto add__go_9_14;
  };
  goto add__go_9_7;
 add__go_9_7:
  gblt_pfunctor(a6,x0,add__go_9_14);
  if (x0 != makesym(atom_go)) goto add__go_9_14;
  gblt_arity(a6,x1,add__go_9_14);
 add__go_9_8:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_dummy)) goto add__go_9_14;
 add__go_9_9:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_functor_1)) goto add__go_9_14;
  x2 = arg(a1, 0);
 add__go_9_10:
  if (isref(x2)) goto add__go_9_13;
 add__go_9_11:
  if (isref(x2)) goto add__go_9_12;
  if_not_equal(x2, a6, add__go_9_14);
  x3 = makesym(atom_no);
  unify_value(a8, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xadd__go2_6);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = a2;
  allocp[4] = a3;
  allocp[5] = a4;
  allocp[6] = a6;
  allocp[7] = a5;
  a0 = a6;
  a1 = a7;
  a2 = x4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  execute(check__brothergoals_3_clear_reason);
  goto check__brothergoals_3_ext_interrupt;
 add__go_9_12:
  deref_and_jump(x2,add__go_9_11);
  *reasonp++ =  x2;
  goto add__go_9_14;
 add__go_9_13:
  deref_and_jump(x2,add__go_9_10);
  *reasonp++ =  x2;
  goto add__go_9_14;
 case VARREF:
  deref_and_jump(a1,add__go_9_9);
  *reasonp++ =  a1;
  goto add__go_9_14;
  };
  goto add__go_9_14;
 case VARREF:
  deref_and_jump(a2,add__go_9_8);
  *reasonp++ =  a2;
  goto add__go_9_14;
  };
  goto add__go_9_14;
 case VARREF:
  deref_and_jump(a0,add__go_9_5);
  *reasonp++ =  a0;
  goto add__go_9_14;
  };
  goto add__go_9_14;
 add__go_9_14:
  otherwise(add__go_9_interrupt);
 add__go_9_15:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_yes)) goto add__go_9_19;
 add__go_9_16:
  if (isref(a6)) goto add__go_9_18;
  gblt_pfunctor(a6,x0,add__go_9_19);
  if (x0 != makesym(atom_go)) goto add__go_9_19;
  gblt_arity(a6,x1,add__go_9_19);
 add__go_9_17:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_dummy)) goto add__go_9_19;
  allocp[0] = makesym(functor_functor_1);
  allocp[1] = x3 = makeref(&allocp[1]);
  x2 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x2);
  x4 = makesym(atom_no);
  unify_value(a8, x4);
  allocp[0] = makesym(functor_functor_1);
  allocp[1] = x6 = makeref(&allocp[1]);
  x5 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__40_2);
  allocp[3] = makefunctor(funct_const_6);
  allocp[4] = x5;
  x7 = makefunctor(&allocp[2]);
  allocp[5] = makesym(functor_functor_1);
  allocp[6] = x7;
  x8 = makefunctor(&allocp[5]);
  allocp[7] = (q)qp;
  allocp[8] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[9] = a3;
  allocp[10] = a4;
  allocp[11] = x8;
  allocp[12] = a5;
  a0 = a6;
  a1 = x3;
  a2 = x6;
  qp = (struct goalrec*)&allocp[7];
  allocp += 13;
  execute(check__nextgoal_3_0);
  goto check__nextgoal_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,add__go_9_17);
  *reasonp++ =  a2;
  goto add__go_9_19;
  };
  goto add__go_9_19;
 add__go_9_18:
  deref_and_jump(a6,add__go_9_16);
  *reasonp++ =  a6;
  goto add__go_9_19;
 case VARREF:
  deref_and_jump(a0,add__go_9_15);
  *reasonp++ =  a0;
  goto add__go_9_19;
  };
  goto add__go_9_19;
 add__go_9_19:
  otherwise(add__go_9_interrupt);
 add__go_9_20:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto add__go_9_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
 add__go_9_21:
  if (isref(a6)) goto add__go_9_22;
  gblt_pfunctor(a6,x0,add__go_9_interrupt);
  if (x0 != makesym(atom_go)) goto add__go_9_interrupt;
  gblt_arity(a6,x1,add__go_9_interrupt);
  x2 = makesym(atom_no);
  unify_value(a8, x2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xadd__go2_6);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = a2;
  allocp[4] = a3;
  allocp[5] = a4;
  allocp[6] = a6;
  allocp[7] = a5;
  a0 = a6;
  a1 = a7;
  a2 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  execute(check__brothergoals_3_0);
  goto check__brothergoals_3_ext_interrupt;
 add__go_9_22:
  deref_and_jump(a6,add__go_9_21);
  *reasonp++ =  a6;
  goto add__go_9_interrupt;
 case symval(makesym(atom_no)):
  unify(a5, a4);
  x0 = makesym(atom_yes);
  unify_value(a8, x0);
  proceed();
  };
  goto add__go_9_interrupt;
 case VARREF:
  deref_and_jump(a0,add__go_9_20);
  *reasonp++ =  a0;
  goto add__go_9_interrupt;
  };
  goto add__go_9_interrupt;
 add__go_9_ext_interrupt:
  reasonp = 0l;
 add__go_9_interrupt:
  goto interrupt_9;
 }

 check__nextgoal_3_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  qp = qp->next;
 check__nextgoal_3_clear_reason:
  reasonp = reasons;
 check__nextgoal_3_0:
 check__nextgoal_3_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_no__go)) goto check__nextgoal_3_2;
  x0 = makesym(atom_no__go);
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,check__nextgoal_3_1);
  *reasonp++ =  a1;
  goto check__nextgoal_3_2;
  };
  goto check__nextgoal_3_2;
 check__nextgoal_3_2:
 check__nextgoal_3_3:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_go_1)) goto check__nextgoal_3_11;
  x0 = arg(a0, 0);
 check__nextgoal_3_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_goal_7)) goto check__nextgoal_3_11;
 check__nextgoal_3_5:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_go_1)) goto check__nextgoal_3_11;
  x1 = arg(a1, 0);
 check__nextgoal_3_6:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_goal_7)) goto check__nextgoal_3_11;
  x2 = arg(x0, 5);
 check__nextgoal_3_7:
  if (isref(x2)) goto check__nextgoal_3_10;
  x3 = arg(x1, 5);
 check__nextgoal_3_8:
  if (isref(x3)) goto check__nextgoal_3_9;
  gblt_diff(x2,x3,check__nextgoal_3_11);
  x4 = makesym(atom_no__go);
  unify_value(a2, x4);
  proceed();
 check__nextgoal_3_9:
  deref_and_jump(x3,check__nextgoal_3_8);
  *reasonp++ =  x3;
  goto check__nextgoal_3_11;
 check__nextgoal_3_10:
  deref_and_jump(x2,check__nextgoal_3_7);
  *reasonp++ =  x2;
  goto check__nextgoal_3_11;
 case VARREF:
  deref_and_jump(x1,check__nextgoal_3_6);
  *reasonp++ =  x1;
  goto check__nextgoal_3_11;
  };
  goto check__nextgoal_3_11;
 case VARREF:
  deref_and_jump(a1,check__nextgoal_3_5);
  *reasonp++ =  a1;
  goto check__nextgoal_3_11;
  };
  goto check__nextgoal_3_11;
 case VARREF:
  deref_and_jump(x0,check__nextgoal_3_4);
  *reasonp++ =  x0;
  goto check__nextgoal_3_11;
  };
  goto check__nextgoal_3_11;
 case VARREF:
  deref_and_jump(a0,check__nextgoal_3_3);
  *reasonp++ =  a0;
  goto check__nextgoal_3_11;
  };
  goto check__nextgoal_3_11;
 check__nextgoal_3_11:
  otherwise(check__nextgoal_3_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xcheck__nextgoal_6);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a0;
  allocp[6] = a1;
  allocp[7] = a2;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_direct__call_xcheck__builtins_3);
  allocp[10] = x2;
  allocp[11] = a1;
  allocp[12] = x0;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[15] = a1;
  allocp[16] = x3 = makeref(&allocp[16]);
  allocp[17] = x2;
  allocp[18] = (q)(struct goalrec*)&allocp[13];
  allocp[19] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[20] = a0;
  allocp[21] = x4 = makeref(&allocp[21]);
  allocp[22] = x1;
  qp = (struct goalrec*)&allocp[18];
  allocp += 23;
  proceed();
 check__nextgoal_3_ext_interrupt:
  reasonp = 0l;
 check__nextgoal_3_interrupt:
  toppred = &predicate_direct__call_xcheck__nextgoal_3;
  goto interrupt_3;
 }

 check__builtins_3_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  qp = qp->next;
 check__builtins_3_clear_reason:
  reasonp = reasons;
 check__builtins_3_0:
 check__builtins_3_1:
  if (!isint(a0)) goto check__builtins_3_7;
  x0 = makeint(0L);
  gblt_greater(a0,x0,check__builtins_3_8);
 check__builtins_3_2:
  if (isref(a1)) goto check__builtins_3_6;
  gblt_arg(a0,a1,x1,check__builtins_3_8);
 check__builtins_3_3:
  if (isref(x1)) goto check__builtins_3_5;
  x3 = makeint(6L);
  gblt_arg(x3,x1,x2,check__builtins_3_8);
 check__builtins_3_4:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != makesym(atom_builtin)) goto check__builtins_3_8;
  x4 = makeint(1L);
  bblt_sub_no_check(a0,x4,x5);
  a0 = x5;
  execute(check__builtins_3_0);
  goto check__builtins_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x2,check__builtins_3_4);
  *reasonp++ =  x2;
  goto check__builtins_3_8;
  };
  goto check__builtins_3_8;
 check__builtins_3_5:
  deref_and_jump(x1,check__builtins_3_3);
  *reasonp++ =  x1;
  goto check__builtins_3_8;
 check__builtins_3_6:
  deref_and_jump(a1,check__builtins_3_2);
  *reasonp++ =  a1;
  goto check__builtins_3_8;
 check__builtins_3_7:
  if (!isref(a0)) goto check__builtins_3_8;
  deref_and_jump(a0,check__builtins_3_1);
  *reasonp++ =  a0;
  goto check__builtins_3_8;
 check__builtins_3_8:
  otherwise(check__builtins_3_interrupt);
 check__builtins_3_9:
  if (!isint(a0)) goto check__builtins_3_11;
  x0 = makeint(0L);
  gblt_greater(a0,x0,check__builtins_3_10);
  x1 = makesym(atom_no);
  unify_value(a2, x1);
  proceed();
 check__builtins_3_10:
  if (a0 != makeint(0L)) goto check__builtins_3_interrupt;
  x2 = makesym(atom_yes);
  unify_value(a2, x2);
  proceed();
 check__builtins_3_11:
  if (!isref(a0)) goto check__builtins_3_interrupt;
  deref_and_jump(a0,check__builtins_3_9);
  *reasonp++ =  a0;
  goto check__builtins_3_interrupt;
 check__builtins_3_ext_interrupt:
  reasonp = 0l;
 check__builtins_3_interrupt:
  goto interrupt_3;
 }

 check__nextgoal_6_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 check__nextgoal_6_clear_reason:
  reasonp = reasons;
 check__nextgoal_6_0:
 check__nextgoal_6_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto check__nextgoal_6_17;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
 check__nextgoal_6_2:
  if (isref(a1)) goto check__nextgoal_6_8;
 check__nextgoal_6_3:
  if (isref(a2)) goto check__nextgoal_6_4;
  gblt_diff(a1,a2,check__nextgoal_6_5);
  x0 = makesym(atom_no__go);
  unify_value(a5, x0);
  proceed();
 check__nextgoal_6_4:
  deref_and_jump(a2,check__nextgoal_6_3);
  *reasonp++ =  a2;
  goto check__nextgoal_6_5;
 check__nextgoal_6_5:
 check__nextgoal_6_6:
  if (isref(a1)) goto check__nextgoal_6_7;
  if_not_equal(a1, a2, check__nextgoal_6_17);
  a0 = a1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  execute(create__nextgoal__builtin_5_clear_reason);
  goto create__nextgoal__builtin_5_ext_interrupt;
 check__nextgoal_6_7:
  deref_and_jump(a1,check__nextgoal_6_6);
  *reasonp++ =  a1;
  goto check__nextgoal_6_17;
 check__nextgoal_6_8:
  deref_and_jump(a1,check__nextgoal_6_2);
  *reasonp++ =  a1;
  goto check__nextgoal_6_17;
 case symval(makesym(atom_no)):
 check__nextgoal_6_9:
  if (!isint(a1)) goto check__nextgoal_6_16;
  x0 = makeint(2L);
  gblt_greater_or_eq(a1,x0,check__nextgoal_6_13);
 check__nextgoal_6_10:
  if (!isint(a2)) goto check__nextgoal_6_12;
  gblt_modulo(a2,a1,x1,check__nextgoal_6_13);
 check__nextgoal_6_11:
  if (x1 != makeint(0L)) goto check__nextgoal_6_13;
  a0 = a1;
  a1 = makeint(1L);
  execute(check__nextgoal2_6_0);
  goto check__nextgoal2_6_ext_interrupt;
 check__nextgoal_6_12:
  if (!isref(a2)) goto check__nextgoal_6_13;
  deref_and_jump(a2,check__nextgoal_6_10);
  *reasonp++ =  a2;
  goto check__nextgoal_6_13;
 check__nextgoal_6_13:
  if (a1 != makeint(1L)) goto check__nextgoal_6_17;
 check__nextgoal_6_14:
  if (!isint(a2)) goto check__nextgoal_6_15;
  x2 = makeint(0L);
  gblt_greater(a2,x2,check__nextgoal_6_17);
  a0 = a2;
  a1 = a3;
  a2 = a4;
  a3 = a5;
  execute(see__nextgoal_4_0);
  goto see__nextgoal_4_ext_interrupt;
 check__nextgoal_6_15:
  if (!isref(a2)) goto check__nextgoal_6_17;
  deref_and_jump(a2,check__nextgoal_6_14);
  *reasonp++ =  a2;
  goto check__nextgoal_6_17;
 check__nextgoal_6_16:
  if (!isref(a1)) goto check__nextgoal_6_17;
  deref_and_jump(a1,check__nextgoal_6_9);
  *reasonp++ =  a1;
  goto check__nextgoal_6_17;
  };
  goto check__nextgoal_6_17;
 case VARREF:
  deref_and_jump(a0,check__nextgoal_6_1);
  *reasonp++ =  a0;
  goto check__nextgoal_6_17;
  };
  goto check__nextgoal_6_17;
 check__nextgoal_6_17:
  otherwise(check__nextgoal_6_interrupt);
 check__nextgoal_6_18:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_no)) goto check__nextgoal_6_interrupt;
  x0 = makesym(atom_no__go);
  unify_value(a5, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,check__nextgoal_6_18);
  *reasonp++ =  a0;
  goto check__nextgoal_6_interrupt;
  };
  goto check__nextgoal_6_interrupt;
 check__nextgoal_6_ext_interrupt:
  reasonp = 0l;
 check__nextgoal_6_interrupt:
  goto interrupt_6;
 }

 create__nextgoal__builtin_5_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 create__nextgoal__builtin_5_clear_reason:
  reasonp = reasons;
 create__nextgoal__builtin_5_0:
 create__nextgoal__builtin_5_1:
  if (!isint(a0)) goto create__nextgoal__builtin_5_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,create__nextgoal__builtin_5_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xcreate__nextgoal__builtin3_6);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a4;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_direct__call_xcreate__nextgoal__builtin2_5);
  allocp[10] = a1;
  allocp[11] = a3;
  allocp[12] = x3 = makeref(&allocp[12]);
  allocp[13] = x2;
  allocp[14] = x1;
  allocp[15] = (q)(struct goalrec*)&allocp[8];
  allocp[16] = (q)(&predicate_functor__table_xarg_3);
  allocp[17] = a0;
  allocp[18] = a2;
  allocp[19] = x3;
  qp = (struct goalrec*)&allocp[15];
  allocp += 20;
  proceed();
 create__nextgoal__builtin_5_2:
  if (a0 != makeint(0L)) goto create__nextgoal__builtin_5_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xcreate__nextgoal_4);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = a2;
  allocp[4] = a3;
  allocp[5] = a4;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[8] = a2;
  allocp[9] = x5 = makeref(&allocp[9]);
  allocp[10] = x4;
  qp = (struct goalrec*)&allocp[6];
  allocp += 11;
  proceed();
 create__nextgoal__builtin_5_3:
  if (!isref(a0)) goto create__nextgoal__builtin_5_interrupt;
  deref_and_jump(a0,create__nextgoal__builtin_5_1);
  *reasonp++ =  a0;
  goto create__nextgoal__builtin_5_interrupt;
 create__nextgoal__builtin_5_ext_interrupt:
  reasonp = 0l;
 create__nextgoal__builtin_5_interrupt:
  toppred = &predicate_direct__call_xcreate__nextgoal__builtin_5;
  goto interrupt_5;
 }

 create__nextgoal__builtin2_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 create__nextgoal__builtin2_5_clear_reason:
  reasonp = reasons;
 create__nextgoal__builtin2_5_0:
 create__nextgoal__builtin2_5_1:
  if (!isint(a0)) goto create__nextgoal__builtin2_5_22;
  x0 = makeint(0L);
  gblt_greater(a0,x0,create__nextgoal__builtin2_5_23);
 create__nextgoal__builtin2_5_2:
  if (isref(a1)) goto create__nextgoal__builtin2_5_21;
  gblt_arg(a0,a1,x1,create__nextgoal__builtin2_5_23);
 create__nextgoal__builtin2_5_3:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_goal_7)) goto create__nextgoal__builtin2_5_23;
 create__nextgoal__builtin2_5_4:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_goal_7)) goto create__nextgoal__builtin2_5_23;
  x2 = arg(x1, 0);
 create__nextgoal__builtin2_5_5:
  if (isref(x2)) goto create__nextgoal__builtin2_5_20;
 create__nextgoal__builtin2_5_6:
  if (isref(x2)) goto create__nextgoal__builtin2_5_19;
  x3 = arg(a2, 0);
  if_not_equal(x2, x3, create__nextgoal__builtin2_5_23);
  x4 = arg(x1, 3);
 create__nextgoal__builtin2_5_7:
  if (isref(x4)) goto create__nextgoal__builtin2_5_18;
 create__nextgoal__builtin2_5_8:
  if (isref(x4)) goto create__nextgoal__builtin2_5_17;
  x5 = arg(a2, 3);
  if_not_equal(x4, x5, create__nextgoal__builtin2_5_23);
  x6 = arg(x1, 4);
 create__nextgoal__builtin2_5_9:
  if (isref(x6)) goto create__nextgoal__builtin2_5_16;
 create__nextgoal__builtin2_5_10:
  if (isref(x6)) goto create__nextgoal__builtin2_5_15;
  x7 = arg(a2, 4);
  if_not_equal(x6, x7, create__nextgoal__builtin2_5_23);
  x8 = arg(x1, 5);
 create__nextgoal__builtin2_5_11:
  if (isref(x8)) goto create__nextgoal__builtin2_5_14;
 create__nextgoal__builtin2_5_12:
  if (isref(x8)) goto create__nextgoal__builtin2_5_13;
  x9 = arg(a2, 5);
  if_not_equal(x8, x9, create__nextgoal__builtin2_5_23);
  x10 = makesym(atom_yes);
  unify_value(a4, x10);
  allocp[0] = makesym(functor_goal_7);
  allocp[1] = x3;
  x12 = arg(x1, 1);
  allocp[2] = x12;
  x13 = arg(x1, 2);
  allocp[3] = x13;
  allocp[4] = x5;
  allocp[5] = x7;
  allocp[6] = x9;
  allocp[7] = x14 = makeref(&allocp[7]);
  x11 = makefunctor(&allocp[0]);
  allocp[8] = (q)qp;
  allocp[9] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[10] = a0;
  allocp[11] = a1;
  allocp[12] = x11;
  allocp[13] = a3;
  a0 = arg(a2, 6);
  a1 = arg(x1, 6);
  a2 = x14;
  qp = (struct goalrec*)&allocp[8];
  allocp += 14;
  execute(check__subset__thru_3_clear_reason);
  goto check__subset__thru_3_ext_interrupt;
 create__nextgoal__builtin2_5_13:
  deref_and_jump(x8,create__nextgoal__builtin2_5_12);
  *reasonp++ =  x8;
  goto create__nextgoal__builtin2_5_23;
 create__nextgoal__builtin2_5_14:
  deref_and_jump(x8,create__nextgoal__builtin2_5_11);
  *reasonp++ =  x8;
  goto create__nextgoal__builtin2_5_23;
 create__nextgoal__builtin2_5_15:
  deref_and_jump(x6,create__nextgoal__builtin2_5_10);
  *reasonp++ =  x6;
  goto create__nextgoal__builtin2_5_23;
 create__nextgoal__builtin2_5_16:
  deref_and_jump(x6,create__nextgoal__builtin2_5_9);
  *reasonp++ =  x6;
  goto create__nextgoal__builtin2_5_23;
 create__nextgoal__builtin2_5_17:
  deref_and_jump(x4,create__nextgoal__builtin2_5_8);
  *reasonp++ =  x4;
  goto create__nextgoal__builtin2_5_23;
 create__nextgoal__builtin2_5_18:
  deref_and_jump(x4,create__nextgoal__builtin2_5_7);
  *reasonp++ =  x4;
  goto create__nextgoal__builtin2_5_23;
 create__nextgoal__builtin2_5_19:
  deref_and_jump(x2,create__nextgoal__builtin2_5_6);
  *reasonp++ =  x2;
  goto create__nextgoal__builtin2_5_23;
 create__nextgoal__builtin2_5_20:
  deref_and_jump(x2,create__nextgoal__builtin2_5_5);
  *reasonp++ =  x2;
  goto create__nextgoal__builtin2_5_23;
 case VARREF:
  deref_and_jump(x1,create__nextgoal__builtin2_5_4);
  *reasonp++ =  x1;
  goto create__nextgoal__builtin2_5_23;
  };
  goto create__nextgoal__builtin2_5_23;
 case VARREF:
  deref_and_jump(a2,create__nextgoal__builtin2_5_3);
  *reasonp++ =  a2;
  goto create__nextgoal__builtin2_5_23;
  };
  goto create__nextgoal__builtin2_5_23;
 create__nextgoal__builtin2_5_21:
  deref_and_jump(a1,create__nextgoal__builtin2_5_2);
  *reasonp++ =  a1;
  goto create__nextgoal__builtin2_5_23;
 create__nextgoal__builtin2_5_22:
  if (!isref(a0)) goto create__nextgoal__builtin2_5_23;
  deref_and_jump(a0,create__nextgoal__builtin2_5_1);
  *reasonp++ =  a0;
  goto create__nextgoal__builtin2_5_23;
 create__nextgoal__builtin2_5_23:
  otherwise(create__nextgoal__builtin2_5_interrupt);
 create__nextgoal__builtin2_5_24:
  if (!isint(a0)) goto create__nextgoal__builtin2_5_26;
  x0 = makeint(0L);
  gblt_greater(a0,x0,create__nextgoal__builtin2_5_25);
  x1 = makeint(1L);
  bblt_sub_no_check(a0,x1,x2);
  a0 = x2;
  execute(create__nextgoal__builtin2_5_0);
  goto create__nextgoal__builtin2_5_ext_interrupt;
 create__nextgoal__builtin2_5_25:
  if (a0 != makeint(0L)) goto create__nextgoal__builtin2_5_interrupt;
  unify(a3, a1);
  x3 = makesym(atom_no);
  unify_value(a4, x3);
  proceed();
 create__nextgoal__builtin2_5_26:
  if (!isref(a0)) goto create__nextgoal__builtin2_5_interrupt;
  deref_and_jump(a0,create__nextgoal__builtin2_5_24);
  *reasonp++ =  a0;
  goto create__nextgoal__builtin2_5_interrupt;
 create__nextgoal__builtin2_5_ext_interrupt:
  reasonp = 0l;
 create__nextgoal__builtin2_5_interrupt:
  goto interrupt_5;
 }

 create__nextgoal__builtin3_6_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 create__nextgoal__builtin3_6_clear_reason:
  reasonp = reasons;
 create__nextgoal__builtin3_6_0:
 create__nextgoal__builtin3_6_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto create__nextgoal__builtin3_6_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xcreate__nextgoal__builtin_5);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a2;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a4;
  allocp[6] = a5;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[9] = a1;
  allocp[10] = makeint(1L);
  allocp[11] = x0;
  allocp[12] = (q)(struct goalrec*)&allocp[7];
  allocp[13] = (q)(&predicate_functor_xdelete__arg_3);
  allocp[14] = a1;
  allocp[15] = a3;
  allocp[16] = x1;
  qp = (struct goalrec*)&allocp[12];
  allocp += 17;
  proceed();
 case symval(makesym(atom_no)):
  x0 = makeint(1L);
  bblt_sub_no_check_y(a1,x0,x1);
  a0 = x1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  execute(create__nextgoal__builtin_5_0);
  goto create__nextgoal__builtin_5_ext_interrupt;
  };
  goto create__nextgoal__builtin3_6_interrupt;
 case VARREF:
  deref_and_jump(a0,create__nextgoal__builtin3_6_1);
  *reasonp++ =  a0;
  goto create__nextgoal__builtin3_6_interrupt;
  };
  goto create__nextgoal__builtin3_6_interrupt;
 create__nextgoal__builtin3_6_ext_interrupt:
  reasonp = 0l;
 create__nextgoal__builtin3_6_interrupt:
  goto interrupt_6;
 }

 check__subset__thru_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 check__subset__thru_3_clear_reason:
  reasonp = reasons;
 check__subset__thru_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xcheck__subset__thru2_5);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a0;
  allocp[5] = a1;
  allocp[6] = a2;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_list_xcheck__subset_3);
  allocp[9] = a1;
  allocp[10] = a0;
  allocp[11] = x1;
  allocp[12] = (q)(struct goalrec*)&allocp[7];
  allocp[13] = (q)(&predicate_list_xcheck__subset_3);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = x0;
  qp = (struct goalrec*)&allocp[12];
  allocp += 17;
  proceed();
 check__subset__thru_3_ext_interrupt:
  reasonp = 0l;
 check__subset__thru_3_interrupt:
  toppred = &predicate_direct__call_xcheck__subset__thru_3;
  goto interrupt_3;
 }

 check__subset__thru2_5_top: {
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 check__subset__thru2_5_clear_reason:
  reasonp = reasons;
 check__subset__thru2_5_0:
 check__subset__thru2_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto check__subset__thru2_5_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
 check__subset__thru2_5_2:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (isint(a1)) goto check__subset__thru2_5_interrupt;
  switch (symval(a1)) {
 case symval(makesym(atom_no)):
  unify(a4, a3);
  proceed();
 case symval(makesym(atom_yes)):
  unify(a4, a3);
  proceed();
  };
  goto check__subset__thru2_5_interrupt;
 case VARREF:
  deref_and_jump(a1,check__subset__thru2_5_2);
  *reasonp++ =  a1;
  goto check__subset__thru2_5_interrupt;
  };
  goto check__subset__thru2_5_interrupt;
 case symval(makesym(atom_no)):
 check__subset__thru2_5_3:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_yes)) goto check__subset__thru2_5_interrupt;
  unify(a4, a2);
  proceed();
 case VARREF:
  deref_and_jump(a1,check__subset__thru2_5_3);
  *reasonp++ =  a1;
  goto check__subset__thru2_5_interrupt;
  };
  goto check__subset__thru2_5_interrupt;
  };
  goto check__subset__thru2_5_interrupt;
 case VARREF:
  deref_and_jump(a0,check__subset__thru2_5_1);
  *reasonp++ =  a0;
  goto check__subset__thru2_5_interrupt;
  };
  goto check__subset__thru2_5_interrupt;
 check__subset__thru2_5_ext_interrupt:
  reasonp = 0l;
 check__subset__thru2_5_interrupt:
  goto interrupt_5;
 }

 see__nextgoal_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 see__nextgoal_4_clear_reason:
  reasonp = reasons;
 see__nextgoal_4_0:
 see__nextgoal_4_1:
  if (!isint(a0)) goto see__nextgoal_4_32;
  x0 = makeint(0L);
  gblt_greater(a0,x0,see__nextgoal_4_33);
 see__nextgoal_4_2:
  if (isref(a1)) goto see__nextgoal_4_31;
  x2 = makeint(1L);
  gblt_arg(x2,a1,x1,see__nextgoal_4_33);
 see__nextgoal_4_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_goal_7)) goto see__nextgoal_4_33;
 see__nextgoal_4_4:
  if (isref(a2)) goto see__nextgoal_4_30;
  gblt_arg(a0,a2,x3,see__nextgoal_4_33);
 see__nextgoal_4_5:
  switch (ptagof(x3)) {
 case FUNCTOR:
  if (functor_of(x3) != makesym(functor_goal_7)) goto see__nextgoal_4_33;
  x4 = arg(x3, 0);
 see__nextgoal_4_6:
  if (isref(x4)) goto see__nextgoal_4_29;
 see__nextgoal_4_7:
  if (isref(x4)) goto see__nextgoal_4_28;
  x5 = arg(x1, 0);
  if_not_equal(x4, x5, see__nextgoal_4_33);
  x6 = arg(x3, 1);
 see__nextgoal_4_8:
  if (isref(x6)) goto see__nextgoal_4_27;
 see__nextgoal_4_9:
  if (isref(x6)) goto see__nextgoal_4_26;
  x7 = arg(x1, 1);
  if_not_equal(x6, x7, see__nextgoal_4_33);
  x8 = arg(x3, 2);
 see__nextgoal_4_10:
  if (isref(x8)) goto see__nextgoal_4_25;
 see__nextgoal_4_11:
  if (isref(x8)) goto see__nextgoal_4_24;
  x9 = arg(x1, 2);
  if_not_equal(x8, x9, see__nextgoal_4_33);
  x10 = arg(x3, 3);
 see__nextgoal_4_12:
  if (isref(x10)) goto see__nextgoal_4_23;
 see__nextgoal_4_13:
  if (isref(x10)) goto see__nextgoal_4_22;
  x11 = arg(x1, 3);
  if_not_equal(x10, x11, see__nextgoal_4_33);
  x12 = arg(x3, 4);
 see__nextgoal_4_14:
  if (isref(x12)) goto see__nextgoal_4_21;
 see__nextgoal_4_15:
  if (isref(x12)) goto see__nextgoal_4_20;
  x13 = arg(x1, 4);
  if_not_equal(x12, x13, see__nextgoal_4_33);
  x14 = arg(x3, 5);
 see__nextgoal_4_16:
  if (isref(x14)) goto see__nextgoal_4_19;
 see__nextgoal_4_17:
  if (isref(x14)) goto see__nextgoal_4_18;
  x15 = arg(x1, 5);
  if_not_equal(x14, x15, see__nextgoal_4_33);
  allocp[0] = makesym(functor_goal_7);
  allocp[1] = x5;
  allocp[2] = x7;
  allocp[3] = x9;
  allocp[4] = x11;
  allocp[5] = x13;
  allocp[6] = x15;
  allocp[7] = x17 = makeref(&allocp[7]);
  x16 = makefunctor(&allocp[0]);
  allocp[8] = (q)qp;
  allocp[9] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[10] = a0;
  allocp[11] = a2;
  allocp[12] = x16;
  allocp[13] = a3;
  a0 = arg(x1, 6);
  a1 = arg(x3, 6);
  a2 = x17;
  qp = (struct goalrec*)&allocp[8];
  allocp += 14;
  execute(check__subset__thru_3_clear_reason);
  goto check__subset__thru_3_ext_interrupt;
 see__nextgoal_4_18:
  deref_and_jump(x14,see__nextgoal_4_17);
  *reasonp++ =  x14;
  goto see__nextgoal_4_33;
 see__nextgoal_4_19:
  deref_and_jump(x14,see__nextgoal_4_16);
  *reasonp++ =  x14;
  goto see__nextgoal_4_33;
 see__nextgoal_4_20:
  deref_and_jump(x12,see__nextgoal_4_15);
  *reasonp++ =  x12;
  goto see__nextgoal_4_33;
 see__nextgoal_4_21:
  deref_and_jump(x12,see__nextgoal_4_14);
  *reasonp++ =  x12;
  goto see__nextgoal_4_33;
 see__nextgoal_4_22:
  deref_and_jump(x10,see__nextgoal_4_13);
  *reasonp++ =  x10;
  goto see__nextgoal_4_33;
 see__nextgoal_4_23:
  deref_and_jump(x10,see__nextgoal_4_12);
  *reasonp++ =  x10;
  goto see__nextgoal_4_33;
 see__nextgoal_4_24:
  deref_and_jump(x8,see__nextgoal_4_11);
  *reasonp++ =  x8;
  goto see__nextgoal_4_33;
 see__nextgoal_4_25:
  deref_and_jump(x8,see__nextgoal_4_10);
  *reasonp++ =  x8;
  goto see__nextgoal_4_33;
 see__nextgoal_4_26:
  deref_and_jump(x6,see__nextgoal_4_9);
  *reasonp++ =  x6;
  goto see__nextgoal_4_33;
 see__nextgoal_4_27:
  deref_and_jump(x6,see__nextgoal_4_8);
  *reasonp++ =  x6;
  goto see__nextgoal_4_33;
 see__nextgoal_4_28:
  deref_and_jump(x4,see__nextgoal_4_7);
  *reasonp++ =  x4;
  goto see__nextgoal_4_33;
 see__nextgoal_4_29:
  deref_and_jump(x4,see__nextgoal_4_6);
  *reasonp++ =  x4;
  goto see__nextgoal_4_33;
 case VARREF:
  deref_and_jump(x3,see__nextgoal_4_5);
  *reasonp++ =  x3;
  goto see__nextgoal_4_33;
  };
  goto see__nextgoal_4_33;
 see__nextgoal_4_30:
  deref_and_jump(a2,see__nextgoal_4_4);
  *reasonp++ =  a2;
  goto see__nextgoal_4_33;
 case VARREF:
  deref_and_jump(x1,see__nextgoal_4_3);
  *reasonp++ =  x1;
  goto see__nextgoal_4_33;
  };
  goto see__nextgoal_4_33;
 see__nextgoal_4_31:
  deref_and_jump(a1,see__nextgoal_4_2);
  *reasonp++ =  a1;
  goto see__nextgoal_4_33;
 see__nextgoal_4_32:
  if (!isref(a0)) goto see__nextgoal_4_33;
  deref_and_jump(a0,see__nextgoal_4_1);
  *reasonp++ =  a0;
  goto see__nextgoal_4_33;
 see__nextgoal_4_33:
  otherwise(see__nextgoal_4_interrupt);
 see__nextgoal_4_34:
  if (!isint(a0)) goto see__nextgoal_4_61;
  x0 = makeint(0L);
  gblt_greater(a0,x0,see__nextgoal_4_62);
 see__nextgoal_4_35:
  if (isref(a1)) goto see__nextgoal_4_60;
  x2 = makeint(1L);
  gblt_arg(x2,a1,x1,see__nextgoal_4_62);
 see__nextgoal_4_36:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_goal_7)) goto see__nextgoal_4_62;
 see__nextgoal_4_37:
  if (isref(a2)) goto see__nextgoal_4_59;
  gblt_arg(a0,a2,x3,see__nextgoal_4_62);
 see__nextgoal_4_38:
  switch (ptagof(x3)) {
 case FUNCTOR:
  if (functor_of(x3) != makesym(functor_goal_7)) goto see__nextgoal_4_62;
  x4 = arg(x3, 0);
 see__nextgoal_4_39:
  if (isref(x4)) goto see__nextgoal_4_58;
 see__nextgoal_4_40:
  if (isref(x4)) goto see__nextgoal_4_57;
  x5 = arg(x1, 0);
  if_not_equal(x4, x5, see__nextgoal_4_62);
  x6 = arg(x3, 3);
 see__nextgoal_4_41:
  if (isref(x6)) goto see__nextgoal_4_56;
 see__nextgoal_4_42:
  if (isref(x6)) goto see__nextgoal_4_55;
  x7 = arg(x1, 3);
  if_not_equal(x6, x7, see__nextgoal_4_62);
  x8 = arg(x3, 4);
 see__nextgoal_4_43:
  if (isref(x8)) goto see__nextgoal_4_54;
 see__nextgoal_4_44:
  if (isref(x8)) goto see__nextgoal_4_53;
  x9 = arg(x1, 4);
  if_not_equal(x8, x9, see__nextgoal_4_62);
  x10 = arg(x3, 5);
 see__nextgoal_4_45:
  if (isref(x10)) goto see__nextgoal_4_52;
 see__nextgoal_4_46:
  if (isref(x10)) goto see__nextgoal_4_51;
  x11 = arg(x1, 5);
  if_not_equal(x10, x11, see__nextgoal_4_62);
  x12 = arg(x3, 6);
 see__nextgoal_4_47:
  if (isref(x12)) goto see__nextgoal_4_50;
 see__nextgoal_4_48:
  if (isref(x12)) goto see__nextgoal_4_49;
  x13 = arg(x1, 6);
  if_not_equal(x12, x13, see__nextgoal_4_62);
  x14 = makeint(1L);
  bblt_sub_no_check(a0,x14,x15);
  a0 = x15;
  execute(see__nextgoal_4_clear_reason);
  goto see__nextgoal_4_ext_interrupt;
 see__nextgoal_4_49:
  deref_and_jump(x12,see__nextgoal_4_48);
  *reasonp++ =  x12;
  goto see__nextgoal_4_62;
 see__nextgoal_4_50:
  deref_and_jump(x12,see__nextgoal_4_47);
  *reasonp++ =  x12;
  goto see__nextgoal_4_62;
 see__nextgoal_4_51:
  deref_and_jump(x10,see__nextgoal_4_46);
  *reasonp++ =  x10;
  goto see__nextgoal_4_62;
 see__nextgoal_4_52:
  deref_and_jump(x10,see__nextgoal_4_45);
  *reasonp++ =  x10;
  goto see__nextgoal_4_62;
 see__nextgoal_4_53:
  deref_and_jump(x8,see__nextgoal_4_44);
  *reasonp++ =  x8;
  goto see__nextgoal_4_62;
 see__nextgoal_4_54:
  deref_and_jump(x8,see__nextgoal_4_43);
  *reasonp++ =  x8;
  goto see__nextgoal_4_62;
 see__nextgoal_4_55:
  deref_and_jump(x6,see__nextgoal_4_42);
  *reasonp++ =  x6;
  goto see__nextgoal_4_62;
 see__nextgoal_4_56:
  deref_and_jump(x6,see__nextgoal_4_41);
  *reasonp++ =  x6;
  goto see__nextgoal_4_62;
 see__nextgoal_4_57:
  deref_and_jump(x4,see__nextgoal_4_40);
  *reasonp++ =  x4;
  goto see__nextgoal_4_62;
 see__nextgoal_4_58:
  deref_and_jump(x4,see__nextgoal_4_39);
  *reasonp++ =  x4;
  goto see__nextgoal_4_62;
 case VARREF:
  deref_and_jump(x3,see__nextgoal_4_38);
  *reasonp++ =  x3;
  goto see__nextgoal_4_62;
  };
  goto see__nextgoal_4_62;
 see__nextgoal_4_59:
  deref_and_jump(a2,see__nextgoal_4_37);
  *reasonp++ =  a2;
  goto see__nextgoal_4_62;
 case VARREF:
  deref_and_jump(x1,see__nextgoal_4_36);
  *reasonp++ =  x1;
  goto see__nextgoal_4_62;
  };
  goto see__nextgoal_4_62;
 see__nextgoal_4_60:
  deref_and_jump(a1,see__nextgoal_4_35);
  *reasonp++ =  a1;
  goto see__nextgoal_4_62;
 see__nextgoal_4_61:
  if (!isref(a0)) goto see__nextgoal_4_62;
  deref_and_jump(a0,see__nextgoal_4_34);
  *reasonp++ =  a0;
  goto see__nextgoal_4_62;
 see__nextgoal_4_62:
  otherwise(see__nextgoal_4_interrupt);
 see__nextgoal_4_63:
  if (!isint(a0)) goto see__nextgoal_4_65;
  x0 = makeint(0L);
  gblt_greater(a0,x0,see__nextgoal_4_64);
  x1 = makesym(atom_no__go);
  unify_value(a3, x1);
  proceed();
 see__nextgoal_4_64:
  if (a0 != makeint(0L)) goto see__nextgoal_4_interrupt;
  a0 = makeint(1L);
  execute(create__nextgoal_4_0);
  goto create__nextgoal_4_ext_interrupt;
 see__nextgoal_4_65:
  if (!isref(a0)) goto see__nextgoal_4_interrupt;
  deref_and_jump(a0,see__nextgoal_4_63);
  *reasonp++ =  a0;
  goto see__nextgoal_4_interrupt;
 see__nextgoal_4_ext_interrupt:
  reasonp = 0l;
 see__nextgoal_4_interrupt:
  toppred = &predicate_direct__call_xsee__nextgoal_4;
  goto interrupt_4;
 }

 check__nextgoal2_6_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 check__nextgoal2_6_clear_reason:
  reasonp = reasons;
 check__nextgoal2_6_0:
 check__nextgoal2_6_1:
  if (!isint(a1)) goto check__nextgoal2_6_5;
 check__nextgoal2_6_2:
  if (!isint(a2)) goto check__nextgoal2_6_4;
  gblt_less_or_eq(a1,a2,check__nextgoal2_6_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xcheck__nextgoal4_7);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_direct__call_xcheck__nextgoal3_4);
  allocp[11] = a0;
  allocp[12] = a3;
  allocp[13] = x1 = makeref(&allocp[13]);
  allocp[14] = x0;
  a2 = a4;
  a3 = makesym(atom_go);
  a4 = x1;
  qp = (struct goalrec*)&allocp[9];
  allocp += 15;
  execute(get__nextgoals_5_0);
  goto get__nextgoals_5_ext_interrupt;
 check__nextgoal2_6_3:
  gblt_greater(a1,a2,check__nextgoal2_6_interrupt);
  a1 = a3;
  a2 = a4;
  a3 = a5;
  execute(create__nextgoal_4_0);
  goto create__nextgoal_4_ext_interrupt;
 check__nextgoal2_6_4:
  if (!isref(a2)) goto check__nextgoal2_6_interrupt;
  deref_and_jump(a2,check__nextgoal2_6_2);
  *reasonp++ =  a2;
  goto check__nextgoal2_6_interrupt;
 check__nextgoal2_6_5:
  if (!isref(a1)) goto check__nextgoal2_6_interrupt;
  deref_and_jump(a1,check__nextgoal2_6_1);
  *reasonp++ =  a1;
  goto check__nextgoal2_6_interrupt;
 check__nextgoal2_6_ext_interrupt:
  reasonp = 0l;
 check__nextgoal2_6_interrupt:
  toppred = &predicate_direct__call_xcheck__nextgoal2_6;
  goto interrupt_6;
 }

 get__nextgoals_5_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 get__nextgoals_5_clear_reason:
  reasonp = reasons;
 get__nextgoals_5_0:
 get__nextgoals_5_1:
  if (!isint(a0)) goto get__nextgoals_5_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,get__nextgoals_5_2);
  bblt_add_no_check_x(a0,a1,x1);
  x2 = makeint(1L);
  bblt_sub_no_check_y(x1,x2,x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xget__nextgoals_5);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x5 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[9] = a0;
  allocp[10] = makeint(1L);
  allocp[11] = x4;
  allocp[12] = (q)(struct goalrec*)&allocp[7];
  allocp[13] = (q)(&predicate_functor_xinsert__arg_4);
  allocp[14] = makeint(1L);
  allocp[15] = a3;
  allocp[16] = x6 = makeref(&allocp[16]);
  allocp[17] = x5;
  allocp[18] = (q)(struct goalrec*)&allocp[12];
  allocp[19] = (q)(&predicate_functor__table_xarg_3);
  allocp[20] = x3;
  allocp[21] = a2;
  allocp[22] = x6;
  qp = (struct goalrec*)&allocp[18];
  allocp += 23;
  proceed();
 get__nextgoals_5_2:
  if (a0 != makeint(0L)) goto get__nextgoals_5_interrupt;
  unify(a4, a3);
  proceed();
 get__nextgoals_5_3:
  if (!isref(a0)) goto get__nextgoals_5_interrupt;
  deref_and_jump(a0,get__nextgoals_5_1);
  *reasonp++ =  a0;
  goto get__nextgoals_5_interrupt;
 get__nextgoals_5_ext_interrupt:
  reasonp = 0l;
 get__nextgoals_5_interrupt:
  toppred = &predicate_direct__call_xget__nextgoals_5;
  goto interrupt_5;
 }

 check__nextgoal4_7_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 check__nextgoal4_7_clear_reason:
  reasonp = reasons;
 check__nextgoal4_7_0:
 check__nextgoal4_7_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto check__nextgoal4_7_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  bblt_add(a2,a1,x0);
  a0 = a1;
  a1 = x0;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  a5 = a6;
  execute(check__nextgoal2_6_0);
  goto check__nextgoal2_6_ext_interrupt;
 case symval(makesym(atom_no__go)):
  x0 = makesym(atom_no__go);
  unify_value(a6, x0);
  proceed();
  };
  goto check__nextgoal4_7_interrupt;
 case VARREF:
  deref_and_jump(a0,check__nextgoal4_7_1);
  *reasonp++ =  a0;
  goto check__nextgoal4_7_interrupt;
  };
  goto check__nextgoal4_7_interrupt;
 check__nextgoal4_7_ext_interrupt:
  reasonp = 0l;
 check__nextgoal4_7_interrupt:
  goto interrupt_7;
 }

 check__nextgoal3_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 check__nextgoal3_4_clear_reason:
  reasonp = reasons;
 check__nextgoal3_4_0:
 check__nextgoal3_4_1:
  if (!isint(a0)) goto check__nextgoal3_4_32;
  x0 = makeint(0L);
  gblt_greater(a0,x0,check__nextgoal3_4_33);
 check__nextgoal3_4_2:
  if (isref(a1)) goto check__nextgoal3_4_31;
  gblt_arg(a0,a1,x1,check__nextgoal3_4_33);
 check__nextgoal3_4_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_goal_7)) goto check__nextgoal3_4_33;
 check__nextgoal3_4_4:
  if (isref(a2)) goto check__nextgoal3_4_30;
  gblt_arg(a0,a2,x2,check__nextgoal3_4_33);
 check__nextgoal3_4_5:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_goal_7)) goto check__nextgoal3_4_33;
  x3 = arg(x2, 0);
 check__nextgoal3_4_6:
  if (isref(x3)) goto check__nextgoal3_4_29;
 check__nextgoal3_4_7:
  if (isref(x3)) goto check__nextgoal3_4_28;
  x4 = arg(x1, 0);
  if_not_equal(x3, x4, check__nextgoal3_4_33);
  x5 = arg(x2, 1);
 check__nextgoal3_4_8:
  if (isref(x5)) goto check__nextgoal3_4_27;
 check__nextgoal3_4_9:
  if (isref(x5)) goto check__nextgoal3_4_26;
  x6 = arg(x1, 1);
  if_not_equal(x5, x6, check__nextgoal3_4_33);
  x7 = arg(x2, 2);
 check__nextgoal3_4_10:
  if (isref(x7)) goto check__nextgoal3_4_25;
 check__nextgoal3_4_11:
  if (isref(x7)) goto check__nextgoal3_4_24;
  x8 = arg(x1, 2);
  if_not_equal(x7, x8, check__nextgoal3_4_33);
  x9 = arg(x2, 3);
 check__nextgoal3_4_12:
  if (isref(x9)) goto check__nextgoal3_4_23;
 check__nextgoal3_4_13:
  if (isref(x9)) goto check__nextgoal3_4_22;
  x10 = arg(x1, 3);
  if_not_equal(x9, x10, check__nextgoal3_4_33);
  x11 = arg(x2, 4);
 check__nextgoal3_4_14:
  if (isref(x11)) goto check__nextgoal3_4_21;
 check__nextgoal3_4_15:
  if (isref(x11)) goto check__nextgoal3_4_20;
  x12 = arg(x1, 4);
  if_not_equal(x11, x12, check__nextgoal3_4_33);
  x13 = arg(x2, 5);
 check__nextgoal3_4_16:
  if (isref(x13)) goto check__nextgoal3_4_19;
 check__nextgoal3_4_17:
  if (isref(x13)) goto check__nextgoal3_4_18;
  x14 = arg(x1, 5);
  if_not_equal(x13, x14, check__nextgoal3_4_33);
  allocp[0] = makesym(functor_goal_7);
  allocp[1] = x4;
  allocp[2] = x6;
  allocp[3] = x8;
  allocp[4] = x10;
  allocp[5] = x12;
  allocp[6] = x14;
  allocp[7] = x16 = makeref(&allocp[7]);
  x15 = makefunctor(&allocp[0]);
  allocp[8] = (q)qp;
  allocp[9] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[10] = a0;
  allocp[11] = a2;
  allocp[12] = x15;
  allocp[13] = a3;
  a0 = arg(x1, 6);
  a1 = arg(x2, 6);
  a2 = x16;
  qp = (struct goalrec*)&allocp[8];
  allocp += 14;
  execute(check__subset__thru_3_clear_reason);
  goto check__subset__thru_3_ext_interrupt;
 check__nextgoal3_4_18:
  deref_and_jump(x13,check__nextgoal3_4_17);
  *reasonp++ =  x13;
  goto check__nextgoal3_4_33;
 check__nextgoal3_4_19:
  deref_and_jump(x13,check__nextgoal3_4_16);
  *reasonp++ =  x13;
  goto check__nextgoal3_4_33;
 check__nextgoal3_4_20:
  deref_and_jump(x11,check__nextgoal3_4_15);
  *reasonp++ =  x11;
  goto check__nextgoal3_4_33;
 check__nextgoal3_4_21:
  deref_and_jump(x11,check__nextgoal3_4_14);
  *reasonp++ =  x11;
  goto check__nextgoal3_4_33;
 check__nextgoal3_4_22:
  deref_and_jump(x9,check__nextgoal3_4_13);
  *reasonp++ =  x9;
  goto check__nextgoal3_4_33;
 check__nextgoal3_4_23:
  deref_and_jump(x9,check__nextgoal3_4_12);
  *reasonp++ =  x9;
  goto check__nextgoal3_4_33;
 check__nextgoal3_4_24:
  deref_and_jump(x7,check__nextgoal3_4_11);
  *reasonp++ =  x7;
  goto check__nextgoal3_4_33;
 check__nextgoal3_4_25:
  deref_and_jump(x7,check__nextgoal3_4_10);
  *reasonp++ =  x7;
  goto check__nextgoal3_4_33;
 check__nextgoal3_4_26:
  deref_and_jump(x5,check__nextgoal3_4_9);
  *reasonp++ =  x5;
  goto check__nextgoal3_4_33;
 check__nextgoal3_4_27:
  deref_and_jump(x5,check__nextgoal3_4_8);
  *reasonp++ =  x5;
  goto check__nextgoal3_4_33;
 check__nextgoal3_4_28:
  deref_and_jump(x3,check__nextgoal3_4_7);
  *reasonp++ =  x3;
  goto check__nextgoal3_4_33;
 check__nextgoal3_4_29:
  deref_and_jump(x3,check__nextgoal3_4_6);
  *reasonp++ =  x3;
  goto check__nextgoal3_4_33;
 case VARREF:
  deref_and_jump(x2,check__nextgoal3_4_5);
  *reasonp++ =  x2;
  goto check__nextgoal3_4_33;
  };
  goto check__nextgoal3_4_33;
 check__nextgoal3_4_30:
  deref_and_jump(a2,check__nextgoal3_4_4);
  *reasonp++ =  a2;
  goto check__nextgoal3_4_33;
 case VARREF:
  deref_and_jump(x1,check__nextgoal3_4_3);
  *reasonp++ =  x1;
  goto check__nextgoal3_4_33;
  };
  goto check__nextgoal3_4_33;
 check__nextgoal3_4_31:
  deref_and_jump(a1,check__nextgoal3_4_2);
  *reasonp++ =  a1;
  goto check__nextgoal3_4_33;
 check__nextgoal3_4_32:
  if (!isref(a0)) goto check__nextgoal3_4_33;
  deref_and_jump(a0,check__nextgoal3_4_1);
  *reasonp++ =  a0;
  goto check__nextgoal3_4_33;
 check__nextgoal3_4_33:
  otherwise(check__nextgoal3_4_interrupt);
 check__nextgoal3_4_34:
  if (!isint(a0)) goto check__nextgoal3_4_61;
  x0 = makeint(0L);
  gblt_greater(a0,x0,check__nextgoal3_4_62);
 check__nextgoal3_4_35:
  if (isref(a1)) goto check__nextgoal3_4_60;
  gblt_arg(a0,a1,x1,check__nextgoal3_4_62);
 check__nextgoal3_4_36:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_goal_7)) goto check__nextgoal3_4_62;
 check__nextgoal3_4_37:
  if (isref(a2)) goto check__nextgoal3_4_59;
  gblt_arg(a0,a2,x2,check__nextgoal3_4_62);
 check__nextgoal3_4_38:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_goal_7)) goto check__nextgoal3_4_62;
  x3 = arg(x2, 0);
 check__nextgoal3_4_39:
  if (isref(x3)) goto check__nextgoal3_4_58;
 check__nextgoal3_4_40:
  if (isref(x3)) goto check__nextgoal3_4_57;
  x4 = arg(x1, 0);
  if_not_equal(x3, x4, check__nextgoal3_4_62);
  x5 = arg(x2, 3);
 check__nextgoal3_4_41:
  if (isref(x5)) goto check__nextgoal3_4_56;
 check__nextgoal3_4_42:
  if (isref(x5)) goto check__nextgoal3_4_55;
  x6 = arg(x1, 3);
  if_not_equal(x5, x6, check__nextgoal3_4_62);
  x7 = arg(x2, 4);
 check__nextgoal3_4_43:
  if (isref(x7)) goto check__nextgoal3_4_54;
 check__nextgoal3_4_44:
  if (isref(x7)) goto check__nextgoal3_4_53;
  x8 = arg(x1, 4);
  if_not_equal(x7, x8, check__nextgoal3_4_62);
  x9 = arg(x2, 5);
 check__nextgoal3_4_45:
  if (isref(x9)) goto check__nextgoal3_4_52;
 check__nextgoal3_4_46:
  if (isref(x9)) goto check__nextgoal3_4_51;
  x10 = arg(x1, 5);
  if_not_equal(x9, x10, check__nextgoal3_4_62);
  x11 = arg(x2, 6);
 check__nextgoal3_4_47:
  if (isref(x11)) goto check__nextgoal3_4_50;
 check__nextgoal3_4_48:
  if (isref(x11)) goto check__nextgoal3_4_49;
  x12 = arg(x1, 6);
  if_not_equal(x11, x12, check__nextgoal3_4_62);
  x13 = makeint(1L);
  bblt_sub_no_check(a0,x13,x14);
  a0 = x14;
  execute(check__nextgoal3_4_clear_reason);
  goto check__nextgoal3_4_ext_interrupt;
 check__nextgoal3_4_49:
  deref_and_jump(x11,check__nextgoal3_4_48);
  *reasonp++ =  x11;
  goto check__nextgoal3_4_62;
 check__nextgoal3_4_50:
  deref_and_jump(x11,check__nextgoal3_4_47);
  *reasonp++ =  x11;
  goto check__nextgoal3_4_62;
 check__nextgoal3_4_51:
  deref_and_jump(x9,check__nextgoal3_4_46);
  *reasonp++ =  x9;
  goto check__nextgoal3_4_62;
 check__nextgoal3_4_52:
  deref_and_jump(x9,check__nextgoal3_4_45);
  *reasonp++ =  x9;
  goto check__nextgoal3_4_62;
 check__nextgoal3_4_53:
  deref_and_jump(x7,check__nextgoal3_4_44);
  *reasonp++ =  x7;
  goto check__nextgoal3_4_62;
 check__nextgoal3_4_54:
  deref_and_jump(x7,check__nextgoal3_4_43);
  *reasonp++ =  x7;
  goto check__nextgoal3_4_62;
 check__nextgoal3_4_55:
  deref_and_jump(x5,check__nextgoal3_4_42);
  *reasonp++ =  x5;
  goto check__nextgoal3_4_62;
 check__nextgoal3_4_56:
  deref_and_jump(x5,check__nextgoal3_4_41);
  *reasonp++ =  x5;
  goto check__nextgoal3_4_62;
 check__nextgoal3_4_57:
  deref_and_jump(x3,check__nextgoal3_4_40);
  *reasonp++ =  x3;
  goto check__nextgoal3_4_62;
 check__nextgoal3_4_58:
  deref_and_jump(x3,check__nextgoal3_4_39);
  *reasonp++ =  x3;
  goto check__nextgoal3_4_62;
 case VARREF:
  deref_and_jump(x2,check__nextgoal3_4_38);
  *reasonp++ =  x2;
  goto check__nextgoal3_4_62;
  };
  goto check__nextgoal3_4_62;
 check__nextgoal3_4_59:
  deref_and_jump(a2,check__nextgoal3_4_37);
  *reasonp++ =  a2;
  goto check__nextgoal3_4_62;
 case VARREF:
  deref_and_jump(x1,check__nextgoal3_4_36);
  *reasonp++ =  x1;
  goto check__nextgoal3_4_62;
  };
  goto check__nextgoal3_4_62;
 check__nextgoal3_4_60:
  deref_and_jump(a1,check__nextgoal3_4_35);
  *reasonp++ =  a1;
  goto check__nextgoal3_4_62;
 check__nextgoal3_4_61:
  if (!isref(a0)) goto check__nextgoal3_4_62;
  deref_and_jump(a0,check__nextgoal3_4_34);
  *reasonp++ =  a0;
  goto check__nextgoal3_4_62;
 check__nextgoal3_4_62:
  otherwise(check__nextgoal3_4_interrupt);
 check__nextgoal3_4_63:
  if (!isint(a0)) goto check__nextgoal3_4_65;
  x0 = makeint(0L);
  gblt_greater(a0,x0,check__nextgoal3_4_64);
  x1 = makesym(atom_no__go);
  unify_value(a3, x1);
  proceed();
 check__nextgoal3_4_64:
  if (a0 != makeint(0L)) goto check__nextgoal3_4_interrupt;
  x2 = makesym(atom_yes);
  unify_value(a3, x2);
  proceed();
 check__nextgoal3_4_65:
  if (!isref(a0)) goto check__nextgoal3_4_interrupt;
  deref_and_jump(a0,check__nextgoal3_4_63);
  *reasonp++ =  a0;
  goto check__nextgoal3_4_interrupt;
 check__nextgoal3_4_ext_interrupt:
  reasonp = 0l;
 check__nextgoal3_4_interrupt:
  goto interrupt_4;
 }

 create__nextgoal_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 create__nextgoal_4_clear_reason:
  reasonp = reasons;
 create__nextgoal_4_0:
 create__nextgoal_4_1:
  if (!isint(a0)) goto create__nextgoal_4_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,create__nextgoal_4_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xcreate__nextgoal_4);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x1;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_functor_xinsert__arg_4);
  allocp[13] = makeint(1L);
  allocp[14] = a2;
  allocp[15] = x3 = makeref(&allocp[15]);
  allocp[16] = x2;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_functor__table_xarg_3);
  allocp[19] = a0;
  allocp[20] = a1;
  allocp[21] = x3;
  qp = (struct goalrec*)&allocp[17];
  allocp += 22;
  proceed();
 create__nextgoal_4_2:
  if (a0 != makeint(0L)) goto create__nextgoal_4_interrupt;
  unify(a3, a2);
  proceed();
 create__nextgoal_4_3:
  if (!isref(a0)) goto create__nextgoal_4_interrupt;
  deref_and_jump(a0,create__nextgoal_4_1);
  *reasonp++ =  a0;
  goto create__nextgoal_4_interrupt;
 create__nextgoal_4_ext_interrupt:
  reasonp = 0l;
 create__nextgoal_4_interrupt:
  toppred = &predicate_direct__call_xcreate__nextgoal_4;
  goto interrupt_4;
 }

 check__brothergoals_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 check__brothergoals_3_clear_reason:
  reasonp = reasons;
 check__brothergoals_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xcheck__brothergoals_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[8] = a0;
  allocp[9] = x1 = makeref(&allocp[9]);
  allocp[10] = x0;
  qp = (struct goalrec*)&allocp[6];
  allocp += 11;
  proceed();
 check__brothergoals_3_ext_interrupt:
  reasonp = 0l;
 check__brothergoals_3_interrupt:
  toppred = &predicate_direct__call_xcheck__brothergoals_3;
  goto interrupt_3;
 }

 check__brothergoals_4_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 check__brothergoals_4_clear_reason:
  reasonp = reasons;
 check__brothergoals_4_0:
 check__brothergoals_4_1:
  if (!isint(a0)) goto check__brothergoals_4_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,check__brothergoals_4_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xcheck__brothergoals2_5);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_direct__call_xcheck__brothergoal_3);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a2;
  allocp[11] = x1;
  allocp[12] = (q)(struct goalrec*)&allocp[7];
  allocp[13] = (q)(&predicate_functor__table_xarg_3);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = x2;
  qp = (struct goalrec*)&allocp[12];
  allocp += 17;
  proceed();
 check__brothergoals_4_2:
  if (a0 != makeint(0L)) goto check__brothergoals_4_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xcheck__cyclic_4);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[8] = a1;
  allocp[9] = x4 = makeref(&allocp[9]);
  allocp[10] = x3;
  qp = (struct goalrec*)&allocp[6];
  allocp += 11;
  proceed();
 check__brothergoals_4_3:
  if (!isref(a0)) goto check__brothergoals_4_interrupt;
  deref_and_jump(a0,check__brothergoals_4_1);
  *reasonp++ =  a0;
  goto check__brothergoals_4_interrupt;
 check__brothergoals_4_ext_interrupt:
  reasonp = 0l;
 check__brothergoals_4_interrupt:
  toppred = &predicate_direct__call_xcheck__brothergoals_4;
  goto interrupt_4;
 }

 check__cyclic_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 check__cyclic_4_clear_reason:
  reasonp = reasons;
 check__cyclic_4_0:
 check__cyclic_4_1:
  if (!isint(a0)) goto check__cyclic_4_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,check__cyclic_4_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xcheck__cyclic2_5);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_direct__call_xcheck__cyclic_3);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a2;
  allocp[11] = x1;
  allocp[12] = makesym(functor_goal_7);
  allocp[13] = x4 = makeref(&allocp[13]);
  allocp[14] = x5 = makeref(&allocp[14]);
  allocp[15] = x6 = makeref(&allocp[15]);
  allocp[16] = x7 = makeref(&allocp[16]);
  allocp[17] = x8 = makeref(&allocp[17]);
  allocp[18] = x9 = makeref(&allocp[18]);
  allocp[19] = x2;
  x3 = makefunctor(&allocp[12]);
  allocp[20] = (q)(struct goalrec*)&allocp[7];
  allocp[21] = (q)(&predicate_functor__table_xarg_3);
  allocp[22] = a0;
  allocp[23] = a1;
  allocp[24] = x3;
  qp = (struct goalrec*)&allocp[20];
  allocp += 25;
  proceed();
 check__cyclic_4_2:
  if (a0 != makeint(0L)) goto check__cyclic_4_interrupt;
  x10 = makesym(atom_yes);
  unify_value(a3, x10);
  proceed();
 check__cyclic_4_3:
  if (!isref(a0)) goto check__cyclic_4_interrupt;
  deref_and_jump(a0,check__cyclic_4_1);
  *reasonp++ =  a0;
  goto check__cyclic_4_interrupt;
 check__cyclic_4_ext_interrupt:
  reasonp = 0l;
 check__cyclic_4_interrupt:
  toppred = &predicate_direct__call_xcheck__cyclic_4;
  goto interrupt_4;
 }

 check__cyclic2_5_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 check__cyclic2_5_clear_reason:
  reasonp = reasons;
 check__cyclic2_5_0:
 check__cyclic2_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto check__cyclic2_5_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  x0 = makeint(1L);
  bblt_sub_no_check_y(a1,x0,x1);
  a0 = x1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  execute(check__cyclic_4_0);
  goto check__cyclic_4_ext_interrupt;
 case symval(makesym(atom_no)):
  x0 = makesym(atom_no);
  unify_value(a4, x0);
  proceed();
  };
  goto check__cyclic2_5_interrupt;
 case VARREF:
  deref_and_jump(a0,check__cyclic2_5_1);
  *reasonp++ =  a0;
  goto check__cyclic2_5_interrupt;
  };
  goto check__cyclic2_5_interrupt;
 check__cyclic2_5_ext_interrupt:
  reasonp = 0l;
 check__cyclic2_5_interrupt:
  goto interrupt_5;
 }

 check__cyclic_3_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  qp = qp->next;
 check__cyclic_3_clear_reason:
  reasonp = reasons;
 check__cyclic_3_0:
 check__cyclic_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 check__cyclic_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_thru_3)) goto check__cyclic_3_4;
  x1 = cdr_of(a0);
 check__cyclic_3_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto check__cyclic_3_4;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xsee__cyclic_5);
  allocp[2] = x2 = makeref(&allocp[2]);
  x3 = arg(x0, 0);
  allocp[3] = x3;
  x4 = arg(x0, 1);
  allocp[4] = x4;
  x5 = arg(x0, 2);
  allocp[5] = x5;
  allocp[6] = a2;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_parse__uty_xget__def__clauses_5);
  allocp[9] = x3;
  allocp[10] = x4;
  allocp[11] = x5;
  allocp[12] = x2;
  allocp[13] = a1;
  qp = (struct goalrec*)&allocp[7];
  allocp += 14;
  proceed();
 case VARREF:
  deref_and_jump(x1,check__cyclic_3_3);
  *reasonp++ =  x1;
  goto check__cyclic_3_4;
  };
  goto check__cyclic_3_4;
 case VARREF:
  deref_and_jump(x0,check__cyclic_3_2);
  *reasonp++ =  x0;
  goto check__cyclic_3_4;
  };
  goto check__cyclic_3_4;
 case VARREF:
  deref_and_jump(a0,check__cyclic_3_1);
  *reasonp++ =  a0;
  goto check__cyclic_3_4;
  };
  goto check__cyclic_3_4;
 check__cyclic_3_4:
  otherwise(check__cyclic_3_interrupt);
 check__cyclic_3_5:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(check__cyclic_3_0);
  goto check__cyclic_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto check__cyclic_3_interrupt;
  x0 = makesym(atom_yes);
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,check__cyclic_3_5);
  *reasonp++ =  a0;
  goto check__cyclic_3_interrupt;
  };
  goto check__cyclic_3_interrupt;
 check__cyclic_3_ext_interrupt:
  reasonp = 0l;
 check__cyclic_3_interrupt:
  goto interrupt_3;
 }

 see__cyclic_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 see__cyclic_5_clear_reason:
  reasonp = reasons;
 see__cyclic_5_0:
 see__cyclic_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 see__cyclic_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_cl_2)) goto see__cyclic_5_interrupt;
  x1 = arg(x0, 1);
 see__cyclic_5_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_clause_4)) goto see__cyclic_5_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xsee__cyclic2_6);
  allocp[2] = x2 = makeref(&allocp[2]);
  x3 = cdr_of(a0);
  allocp[3] = x3;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = makesym(functor_pred_3);
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  x4 = makefunctor(&allocp[8]);
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_direct__call_xcheck__include_3);
  allocp[14] = x4;
  allocp[15] = x5 = makeref(&allocp[15]);
  allocp[16] = x2;
  allocp[17] = (q)(struct goalrec*)&allocp[12];
  allocp[18] = (q)(&predicate_direct__call_xsee__cyclic__bodys_5);
  allocp[19] = x6 = makeref(&allocp[19]);
  x7 = arg(x1, 2);
  allocp[20] = x7;
  allocp[21] = a1;
  allocp[22] = NILATOM;
  allocp[23] = x5;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[26] = x7;
  allocp[27] = x8 = makeref(&allocp[27]);
  allocp[28] = x6;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(x1,see__cyclic_5_3);
  *reasonp++ =  x1;
  goto see__cyclic_5_interrupt;
  };
  goto see__cyclic_5_interrupt;
 case VARREF:
  deref_and_jump(x0,see__cyclic_5_2);
  *reasonp++ =  x0;
  goto see__cyclic_5_interrupt;
  };
  goto see__cyclic_5_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto see__cyclic_5_interrupt;
  x0 = makesym(atom_yes);
  unify_value(a4, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,see__cyclic_5_1);
  *reasonp++ =  a0;
  goto see__cyclic_5_interrupt;
  };
  goto see__cyclic_5_interrupt;
 see__cyclic_5_ext_interrupt:
  reasonp = 0l;
 see__cyclic_5_interrupt:
  toppred = &predicate_direct__call_xsee__cyclic_5;
  goto interrupt_5;
 }

 check__include_3_top: {
  q x0;
  a2 = qp->args[2];
  qp = qp->next;
 check__include_3_clear_reason:
  reasonp = reasons;
 check__include_3_0:
 check__include_3_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != NILATOM) goto check__include_3_2;
  x0 = makesym(atom_yes);
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,check__include_3_1);
  *reasonp++ =  a1;
  goto check__include_3_2;
  };
  goto check__include_3_2;
 check__include_3_2:
  otherwise(check__include_3_interrupt);
  a3 = a2;
  a2 = makeint(0L);
  execute(check__include_4_0);
  goto check__include_4_ext_interrupt;
 check__include_3_ext_interrupt:
  reasonp = 0l;
 check__include_3_interrupt:
  goto interrupt_3;
 }

 check__include_4_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 check__include_4_clear_reason:
  reasonp = reasons;
 check__include_4_0:
 check__include_4_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 check__include_4_2:
  if (isref(x0)) goto check__include_4_5;
 check__include_4_3:
  if (isref(x0)) goto check__include_4_4;
  if_not_equal(x0, a0, check__include_4_6);
  x1 = makeint(1L);
  bblt_add_no_check_y(a2,x1,x2);
  a1 = cdr_of(a1);
  a2 = x2;
  execute(check__include_4_clear_reason);
  goto check__include_4_ext_interrupt;
 check__include_4_4:
  deref_and_jump(x0,check__include_4_3);
  *reasonp++ =  x0;
  goto check__include_4_6;
 check__include_4_5:
  deref_and_jump(x0,check__include_4_2);
  *reasonp++ =  x0;
  goto check__include_4_6;
 case VARREF:
  deref_and_jump(a1,check__include_4_1);
  *reasonp++ =  a1;
  goto check__include_4_6;
  };
  goto check__include_4_6;
 check__include_4_6:
  otherwise(check__include_4_interrupt);
 check__include_4_7:
  switch (ptagof(a1)) {
 case CONS:
  a1 = cdr_of(a1);
  execute(check__include_4_0);
  goto check__include_4_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto check__include_4_10;
 check__include_4_8:
  switch (ptagof(a2)) {
 case ATOMIC:
 check__include_4_9:
  if (a2 != makeint(1L)) goto check__include_4_10;
  x0 = makesym(atom_yes);
  unify_value(a3, x0);
  proceed();
 case VARREF:
  deref_and_jump(a2,check__include_4_8);
  *reasonp++ =  a2;
  goto check__include_4_10;
  };
  goto check__include_4_10;
 case VARREF:
  deref_and_jump(a1,check__include_4_7);
  *reasonp++ =  a1;
  goto check__include_4_10;
  };
  goto check__include_4_10;
 check__include_4_10:
  otherwise(check__include_4_interrupt);
 check__include_4_11:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != NILATOM) goto check__include_4_interrupt;
  x0 = makesym(atom_no);
  unify_value(a3, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,check__include_4_11);
  *reasonp++ =  a1;
  goto check__include_4_interrupt;
  };
  goto check__include_4_interrupt;
 check__include_4_ext_interrupt:
  reasonp = 0l;
 check__include_4_interrupt:
  toppred = &predicate_direct__call_xcheck__include_4;
  goto interrupt_4;
 }

 see__cyclic2_6_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 see__cyclic2_6_clear_reason:
  reasonp = reasons;
 see__cyclic2_6_0:
 see__cyclic2_6_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto see__cyclic2_6_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  a0 = a1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  execute(see__cyclic_5_0);
  goto see__cyclic_5_ext_interrupt;
 case symval(makesym(atom_no)):
  x0 = makesym(atom_no);
  unify_value(a5, x0);
  proceed();
  };
  goto see__cyclic2_6_interrupt;
 case VARREF:
  deref_and_jump(a0,see__cyclic2_6_1);
  *reasonp++ =  a0;
  goto see__cyclic2_6_interrupt;
  };
  goto see__cyclic2_6_interrupt;
 see__cyclic2_6_ext_interrupt:
  reasonp = 0l;
 see__cyclic2_6_interrupt:
  goto interrupt_6;
 }

 see__cyclic__bodys_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 see__cyclic__bodys_5_clear_reason:
  reasonp = reasons;
 see__cyclic__bodys_5_0:
 see__cyclic__bodys_5_1:
  if (!isint(a0)) goto see__cyclic__bodys_5_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,see__cyclic__bodys_5_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xsee__cyclic__bodys_5);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[9] = a0;
  allocp[10] = makeint(1L);
  allocp[11] = x1;
  allocp[12] = (q)(struct goalrec*)&allocp[7];
  allocp[13] = (q)(&predicate_direct__call_xsee__cyclic__body_6);
  allocp[14] = x3 = makeref(&allocp[14]);
  allocp[15] = a2;
  allocp[16] = x4 = makeref(&allocp[16]);
  allocp[17] = x5 = makeref(&allocp[17]);
  allocp[18] = a3;
  allocp[19] = x2;
  allocp[20] = (q)(struct goalrec*)&allocp[12];
  allocp[21] = (q)(&predicate_parse__uty_xdecode__goalcall_6);
  allocp[22] = a2;
  allocp[23] = x4;
  allocp[24] = x6 = makeref(&allocp[24]);
  allocp[25] = x5;
  allocp[26] = x7 = makeref(&allocp[26]);
  allocp[27] = x3;
  allocp[28] = (q)(struct goalrec*)&allocp[20];
  allocp[29] = (q)(&predicate_functor__table_xarg_3);
  allocp[30] = a0;
  allocp[31] = a1;
  allocp[32] = x6;
  qp = (struct goalrec*)&allocp[28];
  allocp += 33;
  proceed();
 see__cyclic__bodys_5_2:
  if (a0 != makeint(0L)) goto see__cyclic__bodys_5_interrupt;
  unify(a4, a3);
  proceed();
 see__cyclic__bodys_5_3:
  if (!isref(a0)) goto see__cyclic__bodys_5_interrupt;
  deref_and_jump(a0,see__cyclic__bodys_5_1);
  *reasonp++ =  a0;
  goto see__cyclic__bodys_5_interrupt;
 see__cyclic__bodys_5_ext_interrupt:
  reasonp = 0l;
 see__cyclic__bodys_5_interrupt:
  goto interrupt_5;
 }

 see__cyclic__body_6_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 see__cyclic__body_6_clear_reason:
  reasonp = reasons;
 see__cyclic__body_6_0:
 see__cyclic__body_6_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto see__cyclic__body_6_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_builtin)):
  unify(a5, a4);
  proceed();
 case symval(makesym(atom_userdef)):
 see__cyclic__body_6_2:
  if (isref(a1)) goto see__cyclic__body_6_5;
 see__cyclic__body_6_3:
  if (isref(a1)) goto see__cyclic__body_6_4;
  if_not_equal(a1, a2, see__cyclic__body_6_interrupt);
  allocp[0] = makesym(functor_pred_3);
  allocp[1] = a1;
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = x2 = makeref(&allocp[3]);
  x0 = makefunctor(&allocp[0]);
  allocp[4] = a4;
  allocp[5] = x0;
  x3 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a5, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[2] = a3;
  allocp[3] = x1;
  allocp[4] = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 see__cyclic__body_6_4:
  deref_and_jump(a1,see__cyclic__body_6_3);
  *reasonp++ =  a1;
  goto see__cyclic__body_6_interrupt;
 see__cyclic__body_6_5:
  deref_and_jump(a1,see__cyclic__body_6_2);
  *reasonp++ =  a1;
  goto see__cyclic__body_6_interrupt;
  };
  goto see__cyclic__body_6_interrupt;
 case VARREF:
  deref_and_jump(a0,see__cyclic__body_6_1);
  *reasonp++ =  a0;
  goto see__cyclic__body_6_interrupt;
  };
  goto see__cyclic__body_6_interrupt;
 see__cyclic__body_6_ext_interrupt:
  reasonp = 0l;
 see__cyclic__body_6_interrupt:
  goto interrupt_6;
 }

 check__brothergoals2_5_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 check__brothergoals2_5_clear_reason:
  reasonp = reasons;
 check__brothergoals2_5_0:
 check__brothergoals2_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto check__brothergoals2_5_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  x0 = makeint(1L);
  bblt_sub_no_check_y(a1,x0,x1);
  a0 = x1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  execute(check__brothergoals_4_0);
  goto check__brothergoals_4_ext_interrupt;
 case symval(makesym(atom_no)):
  x0 = makesym(atom_no);
  unify_value(a4, x0);
  proceed();
  };
  goto check__brothergoals2_5_interrupt;
 case VARREF:
  deref_and_jump(a0,check__brothergoals2_5_1);
  *reasonp++ =  a0;
  goto check__brothergoals2_5_interrupt;
  };
  goto check__brothergoals2_5_interrupt;
 check__brothergoals2_5_ext_interrupt:
  reasonp = 0l;
 check__brothergoals2_5_interrupt:
  goto interrupt_5;
 }

 check__brothergoal_3_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  qp = qp->next;
 check__brothergoal_3_clear_reason:
  reasonp = reasons;
 check__brothergoal_3_0:
 check__brothergoal_3_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_goal_7)) goto check__brothergoal_3_interrupt;
  x0 = arg(a0, 5);
 check__brothergoal_3_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (isint(x0)) goto check__brothergoal_3_interrupt;
  switch (symval(x0)) {
 case symval(makesym(atom_builtin)):
  x1 = makesym(atom_yes);
  unify_value(a2, x1);
  proceed();
 case symval(makesym(atom_userdef)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xcheck__brothers_9);
  x1 = arg(a0, 0);
  allocp[2] = x1;
  x2 = arg(a0, 1);
  allocp[3] = x2;
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = x1;
  allocp[6] = x2;
  x4 = arg(a0, 2);
  allocp[7] = x4;
  allocp[8] = NILATOM;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_parse__uty_xget__clause_4);
  allocp[13] = x1;
  allocp[14] = x2;
  allocp[15] = x3;
  allocp[16] = a1;
  qp = (struct goalrec*)&allocp[11];
  allocp += 17;
  proceed();
  };
  goto check__brothergoal_3_interrupt;
 case VARREF:
  deref_and_jump(x0,check__brothergoal_3_2);
  *reasonp++ =  x0;
  goto check__brothergoal_3_interrupt;
  };
  goto check__brothergoal_3_interrupt;
 case VARREF:
  deref_and_jump(a0,check__brothergoal_3_1);
  *reasonp++ =  a0;
  goto check__brothergoal_3_interrupt;
  };
  goto check__brothergoal_3_interrupt;
 check__brothergoal_3_ext_interrupt:
  reasonp = 0l;
 check__brothergoal_3_interrupt:
  goto interrupt_3;
 }

 check__brothers_9_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 check__brothers_9_clear_reason:
  reasonp = reasons;
 check__brothers_9_0:
 check__brothers_9_1:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_clause_4)) goto check__brothers_9_2;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xcheck__brothers2_10);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = x0 = makeref(&allocp[4]);
  x1 = arg(a2, 2);
  allocp[5] = x1;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = a8;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[14] = x1;
  allocp[15] = x2 = makeref(&allocp[15]);
  allocp[16] = x0;
  qp = (struct goalrec*)&allocp[12];
  allocp += 17;
  proceed();
 case VARREF:
  deref_and_jump(a2,check__brothers_9_1);
  *reasonp++ =  a2;
  goto check__brothers_9_2;
  };
  goto check__brothers_9_2;
 check__brothers_9_2:
  otherwise(check__brothers_9_interrupt);
  x0 = makesym(atom_yes);
  unify_value(a8, x0);
  proceed();
 check__brothers_9_ext_interrupt:
  reasonp = 0l;
 check__brothers_9_interrupt:
  toppred = &predicate_direct__call_xcheck__brothers_9;
  goto interrupt_9;
 }

 check__brothers2_10_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 check__brothers2_10_clear_reason:
  reasonp = reasons;
 check__brothers2_10_0:
 check__brothers2_10_1:
  if (!isint(a2)) goto check__brothers2_10_5;
 check__brothers2_10_2:
  if (!isint(a6)) goto check__brothers2_10_3;
  gblt_greater_or_eq(a2,a6,check__brothers2_10_4);
  x0 = makeint(1L);
  bblt_sub_no_check(a2,x0,x1);
  a2 = x1;
  execute(check__brothers2_10_0);
  goto check__brothers2_10_ext_interrupt;
 check__brothers2_10_3:
  if (!isref(a6)) goto check__brothers2_10_4;
  deref_and_jump(a6,check__brothers2_10_2);
  *reasonp++ =  a6;
  goto check__brothers2_10_4;
 check__brothers2_10_4:
  if (a2 != makeint(0L)) goto check__brothers2_10_6;
  x2 = makesym(atom_yes);
  unify_value(a9, x2);
  proceed();
 check__brothers2_10_5:
  if (!isref(a2)) goto check__brothers2_10_6;
  deref_and_jump(a2,check__brothers2_10_1);
  *reasonp++ =  a2;
  goto check__brothers2_10_6;
 check__brothers2_10_6:
  otherwise(check__brothers2_10_interrupt);
 check__brothers2_10_7:
  if (!isint(a2)) goto check__brothers2_10_10;
 check__brothers2_10_8:
  if (!isint(a6)) goto check__brothers2_10_9;
  gblt_less(a2,a6,check__brothers2_10_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xcheck__brothers4_11);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = a8;
  allocp[12] = a9;
  allocp[13] = (q)(struct goalrec*)&allocp[0];
  allocp[14] = (q)(&predicate_direct__call_xcheck__brothers3_11);
  allocp[15] = x1 = makeref(&allocp[15]);
  allocp[16] = a0;
  allocp[17] = a1;
  allocp[18] = a2;
  allocp[19] = x2 = makeref(&allocp[19]);
  allocp[20] = a4;
  allocp[21] = a5;
  allocp[22] = a6;
  allocp[23] = a7;
  allocp[24] = a8;
  allocp[25] = x0;
  allocp[26] = makesym(functor_options_2);
  allocp[27] = x4 = makeref(&allocp[27]);
  allocp[28] = x1;
  x3 = makefunctor(&allocp[26]);
  allocp[29] = (q)(struct goalrec*)&allocp[13];
  allocp[30] = (q)(&predicate_parse__uty_xdecode__goal_4);
  allocp[31] = x5 = makeref(&allocp[31]);
  allocp[32] = x2;
  allocp[33] = x6 = makeref(&allocp[33]);
  allocp[34] = x3;
  allocp[35] = (q)(struct goalrec*)&allocp[29];
  allocp[36] = (q)(&predicate_functor__table_xarg_3);
  allocp[37] = a2;
  allocp[38] = a3;
  allocp[39] = x5;
  qp = (struct goalrec*)&allocp[35];
  allocp += 40;
  proceed();
 check__brothers2_10_9:
  if (!isref(a6)) goto check__brothers2_10_interrupt;
  deref_and_jump(a6,check__brothers2_10_8);
  *reasonp++ =  a6;
  goto check__brothers2_10_interrupt;
 check__brothers2_10_10:
  if (!isref(a2)) goto check__brothers2_10_interrupt;
  deref_and_jump(a2,check__brothers2_10_7);
  *reasonp++ =  a2;
  goto check__brothers2_10_interrupt;
 check__brothers2_10_ext_interrupt:
  reasonp = 0l;
 check__brothers2_10_interrupt:
  toppred = &predicate_direct__call_xcheck__brothers2_10;
  goto interrupt_10;
 }

 check__brothers3_11_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 check__brothers3_11_clear_reason:
  reasonp = reasons;
 check__brothers3_11_0:
 check__brothers3_11_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_atom_1)) goto check__brothers3_11_3;
  x0 = arg(a0, 0);
 check__brothers3_11_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (isint(x0)) goto check__brothers3_11_3;
  switch (symval(x0)) {
 case symval(makesym(atom_entry)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xcheck__childgoals_8);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a5;
  allocp[5] = a6;
  allocp[6] = a7;
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = a9;
  allocp[9] = a10;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_parse__uty_xget__def__clauses_5);
  allocp[12] = a1;
  allocp[13] = x3 = makeref(&allocp[13]);
  allocp[14] = x4 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = a9;
  allocp[17] = makesym(functor_sub_2);
  allocp[18] = x3;
  allocp[19] = x4;
  x5 = makefunctor(&allocp[17]);
  allocp[20] = a8;
  allocp[21] = x5;
  x6 = makecons(&allocp[20]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 22;
  unify_value(x2, x6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[2] = a4;
  allocp[3] = x3;
  allocp[4] = x4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case symval(makesym(atom_recursive)):
  allocp[0] = makesym(functor_sub_2);
  allocp[1] = x2 = makeref(&allocp[1]);
  allocp[2] = x3 = makeref(&allocp[2]);
  x1 = makefunctor(&allocp[0]);
  allocp[3] = (q)qp;
  allocp[4] = (q)(&predicate_list_xcheck__include_3);
  allocp[5] = x1;
  allocp[6] = a8;
  allocp[7] = a10;
  allocp[8] = (q)(struct goalrec*)&allocp[3];
  allocp[9] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[10] = a4;
  allocp[11] = x2;
  allocp[12] = x3;
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  proceed();
  };
  goto check__brothers3_11_3;
 case VARREF:
  deref_and_jump(x0,check__brothers3_11_2);
  *reasonp++ =  x0;
  goto check__brothers3_11_3;
  };
  goto check__brothers3_11_3;
 case VARREF:
  deref_and_jump(a0,check__brothers3_11_1);
  *reasonp++ =  a0;
  goto check__brothers3_11_3;
  };
  goto check__brothers3_11_3;
 check__brothers3_11_3:
  otherwise(check__brothers3_11_interrupt);
  x0 = makesym(atom_yes);
  unify_value(a10, x0);
  proceed();
 check__brothers3_11_ext_interrupt:
  reasonp = 0l;
 check__brothers3_11_interrupt:
  goto interrupt_11;
 }

 check__brothers4_11_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 check__brothers4_11_clear_reason:
  reasonp = reasons;
 check__brothers4_11_0:
 check__brothers4_11_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto check__brothers4_11_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  x0 = makeint(1L);
  bblt_sub_no_check_y(a3,x0,x1);
  a0 = a1;
  a1 = a2;
  a2 = x1;
  a3 = a4;
  a4 = a5;
  a5 = a6;
  a6 = a7;
  a7 = a8;
  a8 = a9;
  a9 = a10;
  execute(check__brothers2_10_0);
  goto check__brothers2_10_ext_interrupt;
 case symval(makesym(atom_no)):
  x0 = makesym(atom_no);
  unify_value(a10, x0);
  proceed();
  };
  goto check__brothers4_11_interrupt;
 case VARREF:
  deref_and_jump(a0,check__brothers4_11_1);
  *reasonp++ =  a0;
  goto check__brothers4_11_interrupt;
  };
  goto check__brothers4_11_interrupt;
 check__brothers4_11_ext_interrupt:
  reasonp = 0l;
 check__brothers4_11_interrupt:
  goto interrupt_11;
 }

 check__childgoals_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 check__childgoals_8_clear_reason:
  reasonp = reasons;
 check__childgoals_8_0:
 check__childgoals_8_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 check__childgoals_8_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_cl_2)) goto check__childgoals_8_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xcheck__childgoals2_9);
  allocp[2] = x1 = makeref(&allocp[2]);
  x2 = cdr_of(a0);
  allocp[3] = x2;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = a7;
  a0 = a1;
  a1 = arg(x0, 0);
  x3 = arg(x0, 1);
  x4 = a2;
  x5 = a3;
  x6 = a4;
  x7 = a5;
  a7 = a6;
  a8 = x1;
  a6 = x7;
  a5 = x6;
  a4 = x5;
  a3 = x4;
  a2 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 11;
  execute(check__brothers_9_0);
  goto check__brothers_9_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,check__childgoals_8_2);
  *reasonp++ =  x0;
  goto check__childgoals_8_interrupt;
  };
  goto check__childgoals_8_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto check__childgoals_8_interrupt;
  x0 = makesym(atom_yes);
  unify_value(a7, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,check__childgoals_8_1);
  *reasonp++ =  a0;
  goto check__childgoals_8_interrupt;
  };
  goto check__childgoals_8_interrupt;
 check__childgoals_8_ext_interrupt:
  reasonp = 0l;
 check__childgoals_8_interrupt:
  toppred = &predicate_direct__call_xcheck__childgoals_8;
  goto interrupt_8;
 }

 check__childgoals2_9_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 check__childgoals2_9_clear_reason:
  reasonp = reasons;
 check__childgoals2_9_0:
 check__childgoals2_9_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto check__childgoals2_9_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  a0 = a1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  a5 = a6;
  a6 = a7;
  a7 = a8;
  execute(check__childgoals_8_0);
  goto check__childgoals_8_ext_interrupt;
 case symval(makesym(atom_no)):
  x0 = makesym(atom_no);
  unify_value(a8, x0);
  proceed();
  };
  goto check__childgoals2_9_interrupt;
 case VARREF:
  deref_and_jump(a0,check__childgoals2_9_1);
  *reasonp++ =  a0;
  goto check__childgoals2_9_interrupt;
  };
  goto check__childgoals2_9_interrupt;
 check__childgoals2_9_ext_interrupt:
  reasonp = 0l;
 check__childgoals2_9_interrupt:
  goto interrupt_9;
 }

 add__go2_6_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 add__go2_6_clear_reason:
  reasonp = reasons;
 add__go2_6_0:
 add__go2_6_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_yes)) goto add__go2_6_3;
 add__go2_6_2:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_dummy)) goto add__go2_6_3;
  unify(a5, a3);
  proceed();
 case VARREF:
  deref_and_jump(a1,add__go2_6_2);
  *reasonp++ =  a1;
  goto add__go2_6_3;
  };
  goto add__go2_6_3;
 case VARREF:
  deref_and_jump(a0,add__go2_6_1);
  *reasonp++ =  a0;
  goto add__go2_6_3;
  };
  goto add__go2_6_3;
 add__go2_6_3:
  otherwise(add__go2_6_interrupt);
 add__go2_6_4:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto add__go2_6_6;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  x0 = makeint(1L);
  bblt_add_no_check_y(a2,x0,x1);
  allocp[0] = makesym(functor_functor_1);
  allocp[1] = a4;
  x2 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__40_2);
  allocp[3] = makefunctor(funct_const_6);
  allocp[4] = x2;
  x3 = makefunctor(&allocp[2]);
  allocp[5] = makesym(functor_functor_1);
  allocp[6] = x3;
  x4 = makefunctor(&allocp[5]);
  allocp[7] = (q)qp;
  allocp[8] = (q)(&predicate_functor_xinsert__arg_4);
  allocp[9] = x1;
  allocp[10] = a3;
  allocp[11] = x4;
  allocp[12] = a5;
  qp = (struct goalrec*)&allocp[7];
  allocp += 13;
  proceed();
 case symval(makesym(atom_no)):
 add__go2_6_5:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_dummy)) goto add__go2_6_6;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = makefunctor(funct_const_5);
  allocp[5] = a5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  proceed();
 case VARREF:
  deref_and_jump(a1,add__go2_6_5);
  *reasonp++ =  a1;
  goto add__go2_6_6;
  };
  goto add__go2_6_6;
  };
  goto add__go2_6_6;
 case VARREF:
  deref_and_jump(a0,add__go2_6_4);
  *reasonp++ =  a0;
  goto add__go2_6_6;
  };
  goto add__go2_6_6;
 add__go2_6_6:
  otherwise(add__go2_6_interrupt);
 add__go2_6_7:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_no)) goto add__go2_6_interrupt;
  x0 = makeint(1L);
  bblt_add_no_check_y(a2,x0,x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor_xinsert__arg_4);
  allocp[2] = x1;
  allocp[3] = a3;
  allocp[4] = makefunctor(funct_const_5);
  allocp[5] = a5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  proceed();
 case VARREF:
  deref_and_jump(a0,add__go2_6_7);
  *reasonp++ =  a0;
  goto add__go2_6_interrupt;
  };
  goto add__go2_6_interrupt;
 add__go2_6_ext_interrupt:
  reasonp = 0l;
 add__go2_6_interrupt:
  goto interrupt_6;
 }

 check__builtin_4_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 check__builtin_4_clear_reason:
  reasonp = reasons;
 check__builtin_4_0:
 check__builtin_4_1:
  if (!isint(a1)) goto check__builtin_4_3;
  x0 = makeint(0L);
  gblt_greater(a1,x0,check__builtin_4_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xcheck__builtin_6);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a1;
  allocp[6] = a2;
  allocp[7] = a3;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_parse__uty_xdecode__goalcall_6);
  allocp[10] = a0;
  allocp[11] = x2;
  allocp[12] = x3 = makeref(&allocp[12]);
  allocp[13] = x4 = makeref(&allocp[13]);
  allocp[14] = x5 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = (q)(struct goalrec*)&allocp[8];
  allocp[17] = (q)(&predicate_functor__table_xarg_3);
  allocp[18] = a1;
  allocp[19] = a2;
  allocp[20] = x3;
  qp = (struct goalrec*)&allocp[16];
  allocp += 21;
  proceed();
 check__builtin_4_2:
  if (a1 != makeint(0L)) goto check__builtin_4_interrupt;
  x6 = makesym(atom_yes);
  unify_value(a3, x6);
  proceed();
 check__builtin_4_3:
  if (!isref(a1)) goto check__builtin_4_interrupt;
  deref_and_jump(a1,check__builtin_4_1);
  *reasonp++ =  a1;
  goto check__builtin_4_interrupt;
 check__builtin_4_ext_interrupt:
  reasonp = 0l;
 check__builtin_4_interrupt:
  toppred = &predicate_direct__call_xcheck__builtin_4;
  goto interrupt_4;
 }

 check__builtin_6_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 check__builtin_6_clear_reason:
  reasonp = reasons;
 check__builtin_6_0:
 check__builtin_6_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto check__builtin_6_6;
  switch (symval(a0)) {
 case symval(makesym(atom_userdef)):
  x0 = makesym(atom_no);
  unify_value(a5, x0);
  proceed();
 case symval(makesym(atom_builtin)):
 check__builtin_6_2:
  if (isref(a1)) goto check__builtin_6_5;
 check__builtin_6_3:
  if (isref(a1)) goto check__builtin_6_4;
  if_not_equal(a1, a2, check__builtin_6_6);
  x0 = makeint(1L);
  bblt_sub_no_check_y(a3,x0,x1);
  a0 = a1;
  a1 = x1;
  a2 = a4;
  a3 = a5;
  execute(check__builtin_4_clear_reason);
  goto check__builtin_4_ext_interrupt;
 check__builtin_6_4:
  deref_and_jump(a1,check__builtin_6_3);
  *reasonp++ =  a1;
  goto check__builtin_6_6;
 check__builtin_6_5:
  deref_and_jump(a1,check__builtin_6_2);
  *reasonp++ =  a1;
  goto check__builtin_6_6;
  };
  goto check__builtin_6_6;
 case VARREF:
  deref_and_jump(a0,check__builtin_6_1);
  *reasonp++ =  a0;
  goto check__builtin_6_6;
  };
  goto check__builtin_6_6;
 check__builtin_6_6:
  otherwise(check__builtin_6_interrupt);
 check__builtin_6_7:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_builtin)) goto check__builtin_6_interrupt;
  x0 = makesym(atom_no);
  unify_value(a5, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,check__builtin_6_7);
  *reasonp++ =  a0;
  goto check__builtin_6_interrupt;
  };
  goto check__builtin_6_interrupt;
 check__builtin_6_ext_interrupt:
  reasonp = 0l;
 check__builtin_6_interrupt:
  goto interrupt_6;
 }

 recursive__bodys_9_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 recursive__bodys_9_clear_reason:
  reasonp = reasons;
 recursive__bodys_9_0:
 recursive__bodys_9_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto recursive__bodys_9_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_no)):
  unify2(a8, a7, a6, a5);
  proceed();
 case symval(makesym(atom_yes)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xrecursive__bodys1_9);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[13] = a1;
  allocp[14] = x1 = makeref(&allocp[14]);
  allocp[15] = x0;
  qp = (struct goalrec*)&allocp[11];
  allocp += 16;
  proceed();
  };
  goto recursive__bodys_9_interrupt;
 case VARREF:
  deref_and_jump(a0,recursive__bodys_9_1);
  *reasonp++ =  a0;
  goto recursive__bodys_9_interrupt;
  };
  goto recursive__bodys_9_interrupt;
 recursive__bodys_9_ext_interrupt:
  reasonp = 0l;
 recursive__bodys_9_interrupt:
  goto interrupt_9;
 }

 recursive__bodys1_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 recursive__bodys1_9_clear_reason:
  reasonp = reasons;
 recursive__bodys1_9_0:
 recursive__bodys1_9_1:
  if (!isint(a0)) goto recursive__bodys1_9_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,recursive__bodys1_9_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xrecursive__bodys1_9);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = x4 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x1;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_direct__call_xmake__nextgoal_10);
  allocp[18] = a2;
  allocp[19] = x5 = makeref(&allocp[19]);
  allocp[20] = a3;
  allocp[21] = a0;
  allocp[22] = x6 = makeref(&allocp[22]);
  allocp[23] = x7 = makeref(&allocp[23]);
  allocp[24] = x8 = makeref(&allocp[24]);
  allocp[25] = x9 = makeref(&allocp[25]);
  allocp[26] = a4;
  allocp[27] = x2;
  allocp[28] = (q)(struct goalrec*)&allocp[16];
  allocp[29] = (q)(&predicate_direct__call_xrecursive__body_13);
  allocp[30] = x9;
  allocp[31] = x8;
  allocp[32] = a2;
  allocp[33] = x5;
  allocp[34] = a3;
  allocp[35] = a0;
  allocp[36] = x6;
  allocp[37] = x7;
  allocp[38] = a4;
  allocp[39] = a5;
  allocp[40] = x3;
  allocp[41] = a7;
  allocp[42] = x4;
  allocp[43] = (q)(struct goalrec*)&allocp[28];
  allocp[44] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[45] = x10 = makeref(&allocp[45]);
  allocp[46] = x6;
  allocp[47] = x7;
  allocp[48] = (q)(struct goalrec*)&allocp[43];
  allocp[49] = (q)(&predicate_parse__uty_xdecode__goalcall_6);
  allocp[50] = a2;
  allocp[51] = x5;
  allocp[52] = x11 = makeref(&allocp[52]);
  allocp[53] = x10;
  allocp[54] = x8;
  allocp[55] = x9;
  allocp[56] = (q)(struct goalrec*)&allocp[48];
  allocp[57] = (q)(&predicate_functor__table_xarg_3);
  allocp[58] = a0;
  allocp[59] = a1;
  allocp[60] = x11;
  qp = (struct goalrec*)&allocp[56];
  allocp += 61;
  proceed();
 recursive__bodys1_9_2:
  if (a0 != makeint(0L)) goto recursive__bodys1_9_interrupt;
  unify2(a8, a7, a6, a5);
  proceed();
 recursive__bodys1_9_3:
  if (!isref(a0)) goto recursive__bodys1_9_interrupt;
  deref_and_jump(a0,recursive__bodys1_9_1);
  *reasonp++ =  a0;
  goto recursive__bodys1_9_interrupt;
 recursive__bodys1_9_ext_interrupt:
  reasonp = 0l;
 recursive__bodys1_9_interrupt:
  goto interrupt_9;
 }

 recursive__body_13_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  qp = qp->next;
 recursive__body_13_clear_reason:
  reasonp = reasons;
 recursive__body_13_0:
 recursive__body_13_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto recursive__body_13_8;
  switch (symval(a0)) {
 case symval(makesym(atom_builtin)):
  unify2(a12, a11, a10, a9);
  proceed();
 case symval(makesym(atom_userdef)):
 recursive__body_13_2:
  if (isref(a2)) goto recursive__body_13_7;
 recursive__body_13_3:
  if (isref(a2)) goto recursive__body_13_6;
  if_not_equal(a2, a3, recursive__body_13_8);
 recursive__body_13_4:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_atom_1)) goto recursive__body_13_8;
  x0 = arg(a1, 0);
 recursive__body_13_5:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_recursive)) goto recursive__body_13_8;
  allocp[0] = makesym(functor_loop_5);
  allocp[1] = a2;
  allocp[2] = a4;
  allocp[3] = a5;
  allocp[4] = a6;
  allocp[5] = a7;
  x1 = makefunctor(&allocp[0]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_direct__call_xrecursive__body2_10);
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = a2;
  allocp[10] = a6;
  allocp[11] = a7;
  allocp[12] = a8;
  allocp[13] = x1;
  allocp[14] = a9;
  allocp[15] = a10;
  allocp[16] = a11;
  allocp[17] = a12;
  allocp[18] = (q)(struct goalrec*)&allocp[6];
  allocp[19] = (q)(&predicate_list_xcheck__include_3);
  allocp[20] = x1;
  allocp[21] = a11;
  allocp[22] = x2;
  qp = (struct goalrec*)&allocp[18];
  allocp += 23;
  proceed();
 case VARREF:
  deref_and_jump(x0,recursive__body_13_5);
  *reasonp++ =  x0;
  goto recursive__body_13_8;
  };
  goto recursive__body_13_8;
 case VARREF:
  deref_and_jump(a1,recursive__body_13_4);
  *reasonp++ =  a1;
  goto recursive__body_13_8;
  };
  goto recursive__body_13_8;
 recursive__body_13_6:
  deref_and_jump(a2,recursive__body_13_3);
  *reasonp++ =  a2;
  goto recursive__body_13_8;
 recursive__body_13_7:
  deref_and_jump(a2,recursive__body_13_2);
  *reasonp++ =  a2;
  goto recursive__body_13_8;
  };
  goto recursive__body_13_8;
 case VARREF:
  deref_and_jump(a0,recursive__body_13_1);
  *reasonp++ =  a0;
  goto recursive__body_13_8;
  };
  goto recursive__body_13_8;
 recursive__body_13_8:
 recursive__body_13_9:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_atom_1)) goto recursive__body_13_16;
  x0 = arg(a1, 0);
 recursive__body_13_10:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_thread)) goto recursive__body_13_16;
 recursive__body_13_11:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_userdef)) goto recursive__body_13_16;
 recursive__body_13_12:
  if (isref(a2)) goto recursive__body_13_15;
 recursive__body_13_13:
  if (isref(a2)) goto recursive__body_13_14;
  if_not_equal(a2, a3, recursive__body_13_16);
  allocp[0] = makesym(functor_loop_5);
  allocp[1] = a2;
  allocp[2] = a4;
  allocp[3] = a5;
  allocp[4] = a6;
  allocp[5] = a7;
  x1 = makefunctor(&allocp[0]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_direct__call_xrecursive__body2_10);
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = a2;
  allocp[10] = a6;
  allocp[11] = a7;
  allocp[12] = a8;
  allocp[13] = x1;
  allocp[14] = a9;
  allocp[15] = a10;
  allocp[16] = a11;
  allocp[17] = a12;
  allocp[18] = (q)(struct goalrec*)&allocp[6];
  allocp[19] = (q)(&predicate_list_xcheck__include_3);
  allocp[20] = x1;
  allocp[21] = a11;
  allocp[22] = x2;
  qp = (struct goalrec*)&allocp[18];
  allocp += 23;
  proceed();
 recursive__body_13_14:
  deref_and_jump(a2,recursive__body_13_13);
  *reasonp++ =  a2;
  goto recursive__body_13_16;
 recursive__body_13_15:
  deref_and_jump(a2,recursive__body_13_12);
  *reasonp++ =  a2;
  goto recursive__body_13_16;
 case VARREF:
  deref_and_jump(a0,recursive__body_13_11);
  *reasonp++ =  a0;
  goto recursive__body_13_16;
  };
  goto recursive__body_13_16;
 case VARREF:
  deref_and_jump(x0,recursive__body_13_10);
  *reasonp++ =  x0;
  goto recursive__body_13_16;
  };
  goto recursive__body_13_16;
 case VARREF:
  deref_and_jump(a1,recursive__body_13_9);
  *reasonp++ =  a1;
  goto recursive__body_13_16;
  };
  goto recursive__body_13_16;
 recursive__body_13_16:
  otherwise(recursive__body_13_interrupt);
 recursive__body_13_17:
  if (isref(a2)) goto recursive__body_13_22;
 recursive__body_13_18:
  if (isref(a2)) goto recursive__body_13_21;
  if_not_equal(a2, a3, recursive__body_13_23);
 recursive__body_13_19:
  if (isref(a8)) goto recursive__body_13_20;
  gblt_pfunctor(a8,x0,recursive__body_13_23);
  if (x0 != makesym(atom_go)) goto recursive__body_13_23;
  gblt_arity(a8,x1,recursive__body_13_23);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xcheck__call_8);
  allocp[2] = a3;
  allocp[3] = a6;
  allocp[4] = a7;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a9;
  allocp[7] = a10;
  allocp[8] = a11;
  allocp[9] = a12;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_direct__call_xmake__newthru_3);
  allocp[12] = x1;
  allocp[13] = x3 = makeref(&allocp[13]);
  allocp[14] = x2;
  allocp[15] = makesym(functor_goal_7);
  allocp[16] = x5 = makeref(&allocp[16]);
  allocp[17] = x6 = makeref(&allocp[17]);
  allocp[18] = x7 = makeref(&allocp[18]);
  allocp[19] = x8 = makeref(&allocp[19]);
  allocp[20] = x9 = makeref(&allocp[20]);
  allocp[21] = x10 = makeref(&allocp[21]);
  allocp[22] = x11 = makeref(&allocp[22]);
  x4 = makefunctor(&allocp[15]);
  allocp[23] = (q)(struct goalrec*)&allocp[10];
  allocp[24] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[25] = makeint(1L);
  allocp[26] = a8;
  allocp[27] = x4;
  allocp[28] = x3;
  allocp[29] = makesym(functor_thru_3);
  allocp[30] = a3;
  allocp[31] = a6;
  allocp[32] = a7;
  x12 = makefunctor(&allocp[29]);
  allocp[33] = NILATOM;
  allocp[34] = x12;
  x13 = makecons(&allocp[33]);
  allocp[35] = (q)(struct goalrec*)&allocp[23];
  allocp[36] = (q)(&predicate_list_xappend_3);
  allocp[37] = x14 = makeref(&allocp[37]);
  allocp[38] = x13;
  allocp[39] = x11;
  allocp[40] = makesym(functor_goal_7);
  allocp[41] = x5;
  allocp[42] = x6;
  allocp[43] = x7;
  allocp[44] = x8;
  allocp[45] = x9;
  allocp[46] = x10;
  allocp[47] = x14;
  x15 = makefunctor(&allocp[40]);
  allocp[48] = (q)(struct goalrec*)&allocp[35];
  allocp[49] = (q)(&predicate_functor__table_xarg_3);
  allocp[50] = makeint(1L);
  allocp[51] = a8;
  allocp[52] = x15;
  qp = (struct goalrec*)&allocp[48];
  allocp += 53;
  proceed();
 recursive__body_13_20:
  deref_and_jump(a8,recursive__body_13_19);
  *reasonp++ =  a8;
  goto recursive__body_13_23;
 recursive__body_13_21:
  deref_and_jump(a2,recursive__body_13_18);
  *reasonp++ =  a2;
  goto recursive__body_13_23;
 recursive__body_13_22:
  deref_and_jump(a2,recursive__body_13_17);
  *reasonp++ =  a2;
  goto recursive__body_13_23;
 recursive__body_13_23:
  otherwise(recursive__body_13_interrupt);
  a0 = a3;
  a1 = a6;
  a2 = a7;
  a3 = makesym(atom___);
  a4 = a9;
  a5 = a10;
  a6 = a11;
  a7 = a12;
  execute(check__call_8_0);
  goto check__call_8_ext_interrupt;
 recursive__body_13_ext_interrupt:
  reasonp = 0l;
 recursive__body_13_interrupt:
  goto interrupt_13;
 }

 make__newthru_3_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  qp = qp->next;
 make__newthru_3_clear_reason:
  reasonp = reasons;
 make__newthru_3_0:
 make__newthru_3_1:
  if (!isint(a0)) goto make__newthru_3_3;
  x0 = makeint(1L);
  gblt_greater(a0,x0,make__newthru_3_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xmake__newthru_3);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[7] = a0;
  allocp[8] = makeint(1L);
  allocp[9] = x1;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[12] = a0;
  allocp[13] = a1;
  allocp[14] = x3 = makeref(&allocp[14]);
  allocp[15] = x2;
  allocp[16] = (q)(struct goalrec*)&allocp[10];
  allocp[17] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[18] = makeint(7L);
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = x5 = makeref(&allocp[20]);
  allocp[21] = x3;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_functor__table_xarg_3);
  allocp[24] = makeint(7L);
  allocp[25] = x6 = makeref(&allocp[25]);
  allocp[26] = x5;
  allocp[27] = (q)(struct goalrec*)&allocp[22];
  allocp[28] = (q)(&predicate_functor__table_xarg_3);
  allocp[29] = makeint(1L);
  allocp[30] = a1;
  allocp[31] = x6;
  allocp[32] = (q)(struct goalrec*)&allocp[27];
  allocp[33] = (q)(&predicate_functor__table_xarg_3);
  allocp[34] = a0;
  allocp[35] = a1;
  allocp[36] = x4;
  qp = (struct goalrec*)&allocp[32];
  allocp += 37;
  proceed();
 make__newthru_3_2:
  if (a0 != makeint(1L)) goto make__newthru_3_interrupt;
  unify(a2, a1);
  proceed();
 make__newthru_3_3:
  if (!isref(a0)) goto make__newthru_3_interrupt;
  deref_and_jump(a0,make__newthru_3_1);
  *reasonp++ =  a0;
  goto make__newthru_3_interrupt;
 make__newthru_3_ext_interrupt:
  reasonp = 0l;
 make__newthru_3_interrupt:
  goto interrupt_3;
 }

 recursive__body2_10_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 recursive__body2_10_clear_reason:
  reasonp = reasons;
 recursive__body2_10_0:
 recursive__body2_10_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto recursive__body2_10_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  unify2(a9, a8, a7, a6);
  proceed();
 case symval(makesym(atom_no)):
  allocp[0] = a8;
  allocp[1] = a5;
  x0 = makecons(&allocp[0]);
  a0 = a1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  a4 = a6;
  a5 = a7;
  a6 = x0;
  a7 = a9;
  allocp += 2;
  execute(check__call_8_0);
  goto check__call_8_ext_interrupt;
  };
  goto recursive__body2_10_interrupt;
 case VARREF:
  deref_and_jump(a0,recursive__body2_10_1);
  *reasonp++ =  a0;
  goto recursive__body2_10_interrupt;
  };
  goto recursive__body2_10_interrupt;
 recursive__body2_10_ext_interrupt:
  reasonp = 0l;
 recursive__body2_10_interrupt:
  goto interrupt_10;
 }

 make__nextgoal_10_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 make__nextgoal_10_clear_reason:
  reasonp = reasons;
 make__nextgoal_10_0:
 make__nextgoal_10_1:
  switch (ptagof(a7)) {
 case ATOMIC:
  if (a7 != makesym(atom_userdef)) goto make__nextgoal_10_27;
 make__nextgoal_10_2:
  if (isref(a0)) goto make__nextgoal_10_26;
 make__nextgoal_10_3:
  if (isref(a0)) goto make__nextgoal_10_25;
  if_not_equal(a0, a1, make__nextgoal_10_5);
 make__nextgoal_10_4:
  switch (ptagof(a6)) {
 case ATOMIC:
  if (a6 != makesym(atom___)) goto make__nextgoal_10_5;
  allocp[0] = makesym(functor_goal_7);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  allocp[5] = a5;
  allocp[6] = makesym(atom_userdef);
  allocp[7] = NILATOM;
  x0 = makefunctor(&allocp[0]);
  allocp[8] = makesym(functor_go_1);
  allocp[9] = x0;
  x1 = makefunctor(&allocp[8]);
  allocp += 10;
  unify_value(a9, x1);
  proceed();
 case VARREF:
  deref_and_jump(a6,make__nextgoal_10_4);
  *reasonp++ =  a6;
  goto make__nextgoal_10_5;
  };
  goto make__nextgoal_10_5;
 make__nextgoal_10_5:
 make__nextgoal_10_6:
  if (isref(a0)) goto make__nextgoal_10_24;
  if_not_equal(a0, a1, make__nextgoal_10_9);
 make__nextgoal_10_7:
  switch (ptagof(a6)) {
 case FUNCTOR:
  if (functor_of(a6) != makesym(functor_atom_1)) goto make__nextgoal_10_9;
  x0 = arg(a6, 0);
 make__nextgoal_10_8:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_shared)) goto make__nextgoal_10_9;
  allocp[0] = makesym(functor_goal_7);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  allocp[5] = a5;
  allocp[6] = makesym(atom_userdef);
  allocp[7] = NILATOM;
  x1 = makefunctor(&allocp[0]);
  allocp[8] = makesym(functor_go_1);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[8]);
  allocp += 10;
  unify_value(a9, x2);
  proceed();
 case VARREF:
  deref_and_jump(x0,make__nextgoal_10_8);
  *reasonp++ =  x0;
  goto make__nextgoal_10_9;
  };
  goto make__nextgoal_10_9;
 case VARREF:
  deref_and_jump(a6,make__nextgoal_10_7);
  *reasonp++ =  a6;
  goto make__nextgoal_10_9;
  };
  goto make__nextgoal_10_9;
 make__nextgoal_10_9:
 make__nextgoal_10_10:
  if (isref(a0)) goto make__nextgoal_10_23;
  if_not_equal(a0, a1, make__nextgoal_10_13);
 make__nextgoal_10_11:
  switch (ptagof(a6)) {
 case FUNCTOR:
  if (functor_of(a6) != makesym(functor_atom_1)) goto make__nextgoal_10_13;
  x0 = arg(a6, 0);
 make__nextgoal_10_12:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_recursive)) goto make__nextgoal_10_13;
  allocp[0] = makesym(functor_goal_7);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  allocp[5] = a5;
  allocp[6] = makesym(atom_userdef);
  allocp[7] = NILATOM;
  x1 = makefunctor(&allocp[0]);
  allocp[8] = makesym(functor_go_1);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[8]);
  allocp += 10;
  unify_value(a9, x2);
  proceed();
 case VARREF:
  deref_and_jump(x0,make__nextgoal_10_12);
  *reasonp++ =  x0;
  goto make__nextgoal_10_13;
  };
  goto make__nextgoal_10_13;
 case VARREF:
  deref_and_jump(a6,make__nextgoal_10_11);
  *reasonp++ =  a6;
  goto make__nextgoal_10_13;
  };
  goto make__nextgoal_10_13;
 make__nextgoal_10_13:
 make__nextgoal_10_14:
  if (isref(a0)) goto make__nextgoal_10_22;
  if_not_equal(a0, a1, make__nextgoal_10_17);
 make__nextgoal_10_15:
  switch (ptagof(a6)) {
 case FUNCTOR:
  if (functor_of(a6) != makesym(functor_atom_1)) goto make__nextgoal_10_17;
  x0 = arg(a6, 0);
 make__nextgoal_10_16:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_entry)) goto make__nextgoal_10_17;
  allocp[0] = makesym(functor_goal_7);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  allocp[5] = a5;
  allocp[6] = makesym(atom_userdef);
  allocp[7] = NILATOM;
  x1 = makefunctor(&allocp[0]);
  allocp[8] = makesym(functor_go_1);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[8]);
  allocp += 10;
  unify_value(a9, x2);
  proceed();
 case VARREF:
  deref_and_jump(x0,make__nextgoal_10_16);
  *reasonp++ =  x0;
  goto make__nextgoal_10_17;
  };
  goto make__nextgoal_10_17;
 case VARREF:
  deref_and_jump(a6,make__nextgoal_10_15);
  *reasonp++ =  a6;
  goto make__nextgoal_10_17;
  };
  goto make__nextgoal_10_17;
 make__nextgoal_10_17:
 make__nextgoal_10_18:
  if (isref(a0)) goto make__nextgoal_10_21;
  if_not_equal(a0, a1, make__nextgoal_10_27);
 make__nextgoal_10_19:
  switch (ptagof(a6)) {
 case FUNCTOR:
  if (functor_of(a6) != makesym(functor_atom_1)) goto make__nextgoal_10_27;
  x0 = arg(a6, 0);
 make__nextgoal_10_20:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_thread)) goto make__nextgoal_10_27;
  allocp[0] = makesym(functor_goal_7);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  allocp[5] = a5;
  allocp[6] = makesym(atom_userdef);
  allocp[7] = NILATOM;
  x1 = makefunctor(&allocp[0]);
  allocp[8] = makesym(functor_go_1);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[8]);
  allocp += 10;
  unify_value(a9, x2);
  proceed();
 case VARREF:
  deref_and_jump(x0,make__nextgoal_10_20);
  *reasonp++ =  x0;
  goto make__nextgoal_10_27;
  };
  goto make__nextgoal_10_27;
 case VARREF:
  deref_and_jump(a6,make__nextgoal_10_19);
  *reasonp++ =  a6;
  goto make__nextgoal_10_27;
  };
  goto make__nextgoal_10_27;
 make__nextgoal_10_21:
  deref_and_jump(a0,make__nextgoal_10_18);
  *reasonp++ =  a0;
  goto make__nextgoal_10_27;
 make__nextgoal_10_22:
  deref_and_jump(a0,make__nextgoal_10_14);
  *reasonp++ =  a0;
  goto make__nextgoal_10_27;
 make__nextgoal_10_23:
  deref_and_jump(a0,make__nextgoal_10_10);
  *reasonp++ =  a0;
  goto make__nextgoal_10_27;
 make__nextgoal_10_24:
  deref_and_jump(a0,make__nextgoal_10_6);
  *reasonp++ =  a0;
  goto make__nextgoal_10_27;
 make__nextgoal_10_25:
  deref_and_jump(a0,make__nextgoal_10_3);
  *reasonp++ =  a0;
  goto make__nextgoal_10_27;
 make__nextgoal_10_26:
  deref_and_jump(a0,make__nextgoal_10_2);
  *reasonp++ =  a0;
  goto make__nextgoal_10_27;
 case VARREF:
  deref_and_jump(a7,make__nextgoal_10_1);
  *reasonp++ =  a7;
  goto make__nextgoal_10_27;
  };
  goto make__nextgoal_10_27;
 make__nextgoal_10_27:
 make__nextgoal_10_28:
  if (isref(a8)) goto make__nextgoal_10_30;
  gblt_pfunctor(a8,x0,make__nextgoal_10_31);
  if (x0 != makesym(atom_go)) goto make__nextgoal_10_31;
  gblt_arity(a8,x1,make__nextgoal_10_31);
 make__nextgoal_10_29:
  switch (ptagof(a7)) {
 case ATOMIC:
  if (a7 != makesym(atom_builtin)) goto make__nextgoal_10_31;
  allocp[0] = makesym(functor_goal_7);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  allocp[5] = a5;
  allocp[6] = makesym(atom_builtin);
  allocp[7] = NILATOM;
  x2 = makefunctor(&allocp[0]);
  allocp[8] = (q)qp;
  allocp[9] = (q)(&predicate_functor_xinsert__arg_4);
  allocp[10] = makeint(1L);
  allocp[11] = a8;
  allocp[12] = x2;
  allocp[13] = a9;
  qp = (struct goalrec*)&allocp[8];
  allocp += 14;
  proceed();
 case VARREF:
  deref_and_jump(a7,make__nextgoal_10_29);
  *reasonp++ =  a7;
  goto make__nextgoal_10_31;
  };
  goto make__nextgoal_10_31;
 make__nextgoal_10_30:
  deref_and_jump(a8,make__nextgoal_10_28);
  *reasonp++ =  a8;
  goto make__nextgoal_10_31;
 make__nextgoal_10_31:
  otherwise(make__nextgoal_10_interrupt);
 make__nextgoal_10_32:
  switch (ptagof(a7)) {
 case ATOMIC:
  if (a7 != makesym(atom_builtin)) goto make__nextgoal_10_33;
  allocp[0] = makesym(functor_goal_7);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  allocp[5] = a5;
  allocp[6] = makesym(atom_builtin);
  allocp[7] = NILATOM;
  x0 = makefunctor(&allocp[0]);
  allocp[8] = makesym(functor_go_1);
  allocp[9] = x0;
  x1 = makefunctor(&allocp[8]);
  allocp += 10;
  unify_value(a9, x1);
  proceed();
 case VARREF:
  deref_and_jump(a7,make__nextgoal_10_32);
  *reasonp++ =  a7;
  goto make__nextgoal_10_33;
  };
  goto make__nextgoal_10_33;
 make__nextgoal_10_33:
  otherwise(make__nextgoal_10_interrupt);
  x0 = makesym(atom___);
  unify_value(a9, x0);
  proceed();
 make__nextgoal_10_ext_interrupt:
  reasonp = 0l;
 make__nextgoal_10_interrupt:
  goto interrupt_10;
 }

 move__preds_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 move__preds_5_clear_reason:
  reasonp = reasons;
 move__preds_5_0:
 move__preds_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 move__preds_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto move__preds_5_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xmove__preds_5);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_direct__call_xmove__clauses_7);
  allocp[9] = x4 = makeref(&allocp[9]);
  x5 = arg(x0, 1);
  allocp[10] = x5;
  x6 = arg(x0, 0);
  allocp[11] = x6;
  allocp[12] = a1;
  allocp[13] = x2;
  allocp[14] = a3;
  allocp[15] = x3;
  allocp[16] = (q)(struct goalrec*)&allocp[7];
  allocp[17] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[18] = x5;
  allocp[19] = x7 = makeref(&allocp[19]);
  allocp[20] = x4;
  qp = (struct goalrec*)&allocp[16];
  allocp += 21;
  proceed();
 case VARREF:
  deref_and_jump(x0,move__preds_5_2);
  *reasonp++ =  x0;
  goto move__preds_5_interrupt;
  };
  goto move__preds_5_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto move__preds_5_interrupt;
  unify2(a4, a3, a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,move__preds_5_1);
  *reasonp++ =  a0;
  goto move__preds_5_interrupt;
  };
  goto move__preds_5_interrupt;
 move__preds_5_ext_interrupt:
  reasonp = 0l;
 move__preds_5_interrupt:
  goto interrupt_5;
 }

 move__clauses_7_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 move__clauses_7_clear_reason:
  reasonp = reasons;
 move__clauses_7_0:
 move__clauses_7_1:
  if (!isint(a0)) goto move__clauses_7_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,move__clauses_7_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xmove__clauses_7);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[11] = a0;
  allocp[12] = makeint(1L);
  allocp[13] = x1;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_direct__call_xmove__clause_7);
  allocp[16] = x4 = makeref(&allocp[16]);
  allocp[17] = a2;
  allocp[18] = a0;
  allocp[19] = a3;
  allocp[20] = x2;
  allocp[21] = a5;
  allocp[22] = x3;
  allocp[23] = (q)(struct goalrec*)&allocp[14];
  allocp[24] = (q)(&predicate_functor__table_xarg_3);
  allocp[25] = a0;
  allocp[26] = a1;
  allocp[27] = x4;
  qp = (struct goalrec*)&allocp[23];
  allocp += 28;
  proceed();
 move__clauses_7_2:
  if (a0 != makeint(0L)) goto move__clauses_7_interrupt;
  unify2(a6, a5, a4, a3);
  proceed();
 move__clauses_7_3:
  if (!isref(a0)) goto move__clauses_7_interrupt;
  deref_and_jump(a0,move__clauses_7_1);
  *reasonp++ =  a0;
  goto move__clauses_7_interrupt;
 move__clauses_7_ext_interrupt:
  reasonp = 0l;
 move__clauses_7_interrupt:
  goto interrupt_7;
 }

 move__clause_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 move__clause_7_clear_reason:
  reasonp = reasons;
 move__clause_7_0:
 move__clause_7_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_clause_4)) goto move__clause_7_4;
  x0 = arg(a0, 2);
 move__clause_7_2:
  if (isref(x0)) goto move__clause_7_3;
  gblt_pfunctor(x0,x1,move__clause_7_4);
  gblt_arity(x0,x2,move__clause_7_4);
  x3 = makeint(0L);
  gblt_greater(x2,x3,move__clause_7_4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xmove__bodys_9);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = a1;
  allocp[5] = a2;
  x6 = arg(a0, 0);
  allocp[6] = x6;
  allocp[7] = a3;
  allocp[8] = a4;
  allocp[9] = a5;
  allocp[10] = a6;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[13] = x7 = makeref(&allocp[13]);
  allocp[14] = x5;
  allocp[15] = x8 = makeref(&allocp[15]);
  allocp[16] = makesym(functor_options_2);
  allocp[17] = x10 = makeref(&allocp[17]);
  allocp[18] = x4;
  x9 = makefunctor(&allocp[16]);
  allocp[19] = (q)(struct goalrec*)&allocp[11];
  allocp[20] = (q)(&predicate_parse__uty_xdecode__goal_4);
  allocp[21] = x11 = makeref(&allocp[21]);
  allocp[22] = x7;
  allocp[23] = x12 = makeref(&allocp[23]);
  allocp[24] = x9;
  allocp[25] = (q)(struct goalrec*)&allocp[19];
  allocp[26] = (q)(&predicate_functor__table_xarg_3);
  allocp[27] = x2;
  allocp[28] = x0;
  allocp[29] = x11;
  qp = (struct goalrec*)&allocp[25];
  allocp += 30;
  proceed();
 move__clause_7_3:
  deref_and_jump(x0,move__clause_7_2);
  *reasonp++ =  x0;
  goto move__clause_7_4;
 case VARREF:
  deref_and_jump(a0,move__clause_7_1);
  *reasonp++ =  a0;
  goto move__clause_7_4;
  };
  goto move__clause_7_4;
 move__clause_7_4:
  otherwise(move__clause_7_interrupt);
  unify2(a6, a5, a4, a3);
  proceed();
 move__clause_7_ext_interrupt:
  reasonp = 0l;
 move__clause_7_interrupt:
  goto interrupt_7;
 }

 move__bodys_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 move__bodys_9_clear_reason:
  reasonp = reasons;
 move__bodys_9_0:
 move__bodys_9_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_functor_1)) goto move__bodys_9_6;
  x0 = arg(a0, 0);
 move__bodys_9_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_no__go)) goto move__bodys_9_4;
 move__bodys_9_3:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_dummy)) goto move__bodys_9_4;
  unify2(a8, a7, a6, a5);
  proceed();
 case VARREF:
  deref_and_jump(a1,move__bodys_9_3);
  *reasonp++ =  a1;
  goto move__bodys_9_4;
  };
  goto move__bodys_9_4;
 case VARREF:
  deref_and_jump(x0,move__bodys_9_2);
  *reasonp++ =  x0;
  goto move__bodys_9_4;
  };
  goto move__bodys_9_4;
 move__bodys_9_4:
 move__bodys_9_5:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_dummy)) goto move__bodys_9_6;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a2;
  allocp[2] = a3;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = x3 = makeref(&allocp[4]);
  x1 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_direct__call_xmove__body_8);
  allocp[7] = makeint(1L);
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = x1;
  allocp[10] = x0;
  allocp[11] = a5;
  allocp[12] = a6;
  allocp[13] = a7;
  allocp[14] = a8;
  allocp[15] = (q)(struct goalrec*)&allocp[5];
  allocp[16] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[17] = x5 = makeref(&allocp[17]);
  allocp[18] = x2;
  allocp[19] = x3;
  allocp[20] = (q)(struct goalrec*)&allocp[15];
  allocp[21] = (q)(&predicate_parse__uty_xdecode__goal_4);
  allocp[22] = a4;
  allocp[23] = x5;
  allocp[24] = x6 = makeref(&allocp[24]);
  allocp[25] = x7 = makeref(&allocp[25]);
  allocp[26] = (q)(struct goalrec*)&allocp[20];
  allocp[27] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[28] = x0;
  allocp[29] = x8 = makeref(&allocp[29]);
  allocp[30] = x4;
  qp = (struct goalrec*)&allocp[26];
  allocp += 31;
  proceed();
 case VARREF:
  deref_and_jump(a1,move__bodys_9_5);
  *reasonp++ =  a1;
  goto move__bodys_9_6;
  };
  goto move__bodys_9_6;
 case VARREF:
  deref_and_jump(a0,move__bodys_9_1);
  *reasonp++ =  a0;
  goto move__bodys_9_6;
  };
  goto move__bodys_9_6;
 move__bodys_9_6:
  otherwise(move__bodys_9_interrupt);
  unify2(a8, a7, a6, a5);
  proceed();
 move__bodys_9_ext_interrupt:
  reasonp = 0l;
 move__bodys_9_interrupt:
  goto interrupt_9;
 }

 move__body_8_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 move__body_8_clear_reason:
  reasonp = reasons;
 move__body_8_0:
 move__body_8_1:
  if (!isint(a0)) goto move__body_8_5;
 move__body_8_2:
  if (!isint(a1)) goto move__body_8_4;
  gblt_less_or_eq(a0,a1,move__body_8_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xmove__body_8);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[12] = a0;
  allocp[13] = makeint(1L);
  allocp[14] = x0;
  allocp[15] = a6;
  allocp[16] = x4 = makeref(&allocp[16]);
  x3 = makecons(&allocp[15]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 17;
  unify_value(x2, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xreplace_6);
  allocp[2] = a2;
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = x4;
  allocp[5] = a6;
  allocp[6] = a4;
  allocp[7] = x1;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_functor__table_xarg_3);
  allocp[10] = a0;
  allocp[11] = a3;
  allocp[12] = x5;
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  proceed();
 move__body_8_3:
  gblt_greater(a0,a1,move__body_8_interrupt);
  unify2(a7, a6, a5, a4);
  proceed();
 move__body_8_4:
  if (!isref(a1)) goto move__body_8_interrupt;
  deref_and_jump(a1,move__body_8_2);
  *reasonp++ =  a1;
  goto move__body_8_interrupt;
 move__body_8_5:
  if (!isref(a0)) goto move__body_8_interrupt;
  deref_and_jump(a0,move__body_8_1);
  *reasonp++ =  a0;
  goto move__body_8_interrupt;
 move__body_8_ext_interrupt:
  reasonp = 0l;
 move__body_8_interrupt:
  goto interrupt_8;
 }

 check__cn_4_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 check__cn_4_clear_reason:
  reasonp = reasons;
 check__cn_4_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xcheck__cn3_5);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  a2 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(check__cn2_3_0);
  goto check__cn2_3_ext_interrupt;
 check__cn_4_ext_interrupt:
  reasonp = 0l;
 check__cn_4_interrupt:
  toppred = &predicate_direct__call_xcheck__cn_4;
  goto interrupt_4;
 }

 check__cn2_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 check__cn2_3_clear_reason:
  reasonp = reasons;
 check__cn2_3_0:
 check__cn2_3_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 check__cn2_3_2:
  if (isref(x0)) goto check__cn2_3_5;
 check__cn2_3_3:
  if (isref(x0)) goto check__cn2_3_4;
  if_not_equal(x0, a0, check__cn2_3_6);
  x1 = makesym(atom_yes);
  unify_value(a2, x1);
  proceed();
 check__cn2_3_4:
  deref_and_jump(x0,check__cn2_3_3);
  *reasonp++ =  x0;
  goto check__cn2_3_6;
 check__cn2_3_5:
  deref_and_jump(x0,check__cn2_3_2);
  *reasonp++ =  x0;
  goto check__cn2_3_6;
 case VARREF:
  deref_and_jump(a1,check__cn2_3_1);
  *reasonp++ =  a1;
  goto check__cn2_3_6;
  };
  goto check__cn2_3_6;
 check__cn2_3_6:
  otherwise(check__cn2_3_interrupt);
 check__cn2_3_7:
  switch (ptagof(a1)) {
 case CONS:
  a1 = cdr_of(a1);
  execute(check__cn2_3_0);
  goto check__cn2_3_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto check__cn2_3_interrupt;
  x0 = makesym(atom_no);
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,check__cn2_3_7);
  *reasonp++ =  a1;
  goto check__cn2_3_interrupt;
  };
  goto check__cn2_3_interrupt;
 check__cn2_3_ext_interrupt:
  reasonp = 0l;
 check__cn2_3_interrupt:
  toppred = &predicate_direct__call_xcheck__cn2_3;
  goto interrupt_3;
 }

 check__cn3_5_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 check__cn3_5_clear_reason:
  reasonp = reasons;
 check__cn3_5_0:
 check__cn3_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto check__cn3_5_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  unify(a3, a1);
  x0 = makesym(atom_done__before);
  unify_value(a4, x0);
  proceed();
 case symval(makesym(atom_no)):
  a0 = a1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  execute(check__cn4_4_0);
  goto check__cn4_4_ext_interrupt;
  };
  goto check__cn3_5_interrupt;
 case VARREF:
  deref_and_jump(a0,check__cn3_5_1);
  *reasonp++ =  a0;
  goto check__cn3_5_interrupt;
  };
  goto check__cn3_5_interrupt;
 check__cn3_5_ext_interrupt:
  reasonp = 0l;
 check__cn3_5_interrupt:
  goto interrupt_5;
 }

 check__cn4_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 check__cn4_4_clear_reason:
  reasonp = reasons;
 check__cn4_4_0:
 check__cn4_4_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_goal_7)) goto check__cn4_4_40;
 check__cn4_4_2:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 check__cn4_4_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_goal_7)) goto check__cn4_4_40;
  x1 = arg(x0, 1);
 check__cn4_4_4:
  if (isref(x1)) goto check__cn4_4_18;
 check__cn4_4_5:
  if (isref(x1)) goto check__cn4_4_17;
  x2 = arg(a0, 1);
  if_not_equal(x1, x2, check__cn4_4_10);
  x3 = arg(a0, 2);
 check__cn4_4_6:
  if (!isint(x3)) goto check__cn4_4_9;
  x4 = arg(x0, 2);
 check__cn4_4_7:
  if (!isint(x4)) goto check__cn4_4_8;
  gblt_greater(x3,x4,check__cn4_4_10);
  x5 = makeint(1L);
  bblt_sub_no_check(x3,x5,x6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xcheck__cn4_4);
  allocp[2] = x7 = makeref(&allocp[2]);
  x8 = cdr_of(a1);
  allocp[3] = x8;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = makesym(functor_goal_7);
  x10 = arg(a0, 0);
  allocp[7] = x10;
  allocp[8] = x2;
  allocp[9] = x6;
  x11 = arg(a0, 3);
  allocp[10] = x11;
  x12 = arg(a0, 4);
  allocp[11] = x12;
  x13 = arg(a0, 5);
  allocp[12] = x13;
  x14 = arg(a0, 6);
  allocp[13] = x14;
  x9 = makefunctor(&allocp[6]);
  a0 = x9;
  a1 = x0;
  a2 = x7;
  qp = (struct goalrec*)&allocp[0];
  allocp += 14;
  execute(check__cn5_3_clear_reason);
  goto check__cn5_3_ext_interrupt;
 check__cn4_4_8:
  if (!isref(x4)) goto check__cn4_4_10;
  deref_and_jump(x4,check__cn4_4_7);
  *reasonp++ =  x4;
  goto check__cn4_4_10;
 check__cn4_4_9:
  if (!isref(x3)) goto check__cn4_4_10;
  deref_and_jump(x3,check__cn4_4_6);
  *reasonp++ =  x3;
  goto check__cn4_4_10;
 check__cn4_4_10:
 check__cn4_4_11:
  if (isref(x1)) goto check__cn4_4_16;
  if_not_equal(x1, x2, check__cn4_4_19);
  x3 = arg(a0, 2);
 check__cn4_4_12:
  if (!isint(x3)) goto check__cn4_4_15;
  x4 = arg(x0, 2);
 check__cn4_4_13:
  if (!isint(x4)) goto check__cn4_4_14;
  gblt_less(x3,x4,check__cn4_4_19);
  x5 = arg(a0, 4);
  x6 = arg(x0, 4);
  bblt_add(x5,x6,x7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xcheck__cn4_4);
  allocp[2] = x8 = makeref(&allocp[2]);
  x9 = cdr_of(a1);
  allocp[3] = x9;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = makesym(functor_goal_7);
  x11 = arg(a0, 0);
  allocp[7] = x11;
  allocp[8] = x2;
  allocp[9] = x3;
  x12 = arg(a0, 3);
  allocp[10] = x12;
  allocp[11] = x7;
  x13 = arg(a0, 5);
  allocp[12] = x13;
  x14 = arg(a0, 6);
  allocp[13] = x14;
  x10 = makefunctor(&allocp[6]);
  a0 = x10;
  a1 = x0;
  a2 = x8;
  qp = (struct goalrec*)&allocp[0];
  allocp += 14;
  execute(check__cn5_3_clear_reason);
  goto check__cn5_3_ext_interrupt;
 check__cn4_4_14:
  if (!isref(x4)) goto check__cn4_4_19;
  deref_and_jump(x4,check__cn4_4_13);
  *reasonp++ =  x4;
  goto check__cn4_4_19;
 check__cn4_4_15:
  if (!isref(x3)) goto check__cn4_4_19;
  deref_and_jump(x3,check__cn4_4_12);
  *reasonp++ =  x3;
  goto check__cn4_4_19;
 check__cn4_4_16:
  deref_and_jump(x1,check__cn4_4_11);
  *reasonp++ =  x1;
  goto check__cn4_4_19;
 check__cn4_4_17:
  deref_and_jump(x1,check__cn4_4_5);
  *reasonp++ =  x1;
  goto check__cn4_4_19;
 check__cn4_4_18:
  deref_and_jump(x1,check__cn4_4_4);
  *reasonp++ =  x1;
  goto check__cn4_4_19;
 check__cn4_4_19:
  x2 = arg(x0, 0);
 check__cn4_4_20:
  if (isref(x2)) goto check__cn4_4_39;
 check__cn4_4_21:
  if (isref(x2)) goto check__cn4_4_38;
  x3 = arg(a0, 0);
  if_not_equal(x2, x3, check__cn4_4_40);
  x4 = arg(x0, 3);
 check__cn4_4_22:
  if (isref(x4)) goto check__cn4_4_37;
 check__cn4_4_23:
  if (isref(x4)) goto check__cn4_4_36;
  x5 = arg(a0, 3);
  if_not_equal(x4, x5, check__cn4_4_40);
  x6 = arg(x0, 4);
 check__cn4_4_24:
  if (isref(x6)) goto check__cn4_4_35;
 check__cn4_4_25:
  if (isref(x6)) goto check__cn4_4_34;
  x7 = arg(a0, 4);
  if_not_equal(x6, x7, check__cn4_4_40);
  x8 = arg(x0, 5);
 check__cn4_4_26:
  if (isref(x8)) goto check__cn4_4_33;
 check__cn4_4_27:
  if (isref(x8)) goto check__cn4_4_32;
  x9 = arg(a0, 5);
  if_not_equal(x8, x9, check__cn4_4_40);
  x10 = arg(x0, 6);
 check__cn4_4_28:
  if (isref(x10)) goto check__cn4_4_31;
 check__cn4_4_29:
  if (isref(x10)) goto check__cn4_4_30;
  x11 = arg(a0, 6);
  if_not_equal(x10, x11, check__cn4_4_40);
  allocp[0] = makesym(functor_goal_7);
  allocp[1] = x3;
  x13 = arg(a0, 1);
  allocp[2] = x13;
  x14 = arg(a0, 2);
  allocp[3] = x14;
  allocp[4] = x5;
  allocp[5] = x7;
  allocp[6] = x9;
  allocp[7] = x11;
  x12 = makefunctor(&allocp[0]);
  allocp += 8;
  unify_value(a2, x12);
  x15 = makesym(atom_done);
  unify_value(a3, x15);
  proceed();
 check__cn4_4_30:
  deref_and_jump(x10,check__cn4_4_29);
  *reasonp++ =  x10;
  goto check__cn4_4_40;
 check__cn4_4_31:
  deref_and_jump(x10,check__cn4_4_28);
  *reasonp++ =  x10;
  goto check__cn4_4_40;
 check__cn4_4_32:
  deref_and_jump(x8,check__cn4_4_27);
  *reasonp++ =  x8;
  goto check__cn4_4_40;
 check__cn4_4_33:
  deref_and_jump(x8,check__cn4_4_26);
  *reasonp++ =  x8;
  goto check__cn4_4_40;
 check__cn4_4_34:
  deref_and_jump(x6,check__cn4_4_25);
  *reasonp++ =  x6;
  goto check__cn4_4_40;
 check__cn4_4_35:
  deref_and_jump(x6,check__cn4_4_24);
  *reasonp++ =  x6;
  goto check__cn4_4_40;
 check__cn4_4_36:
  deref_and_jump(x4,check__cn4_4_23);
  *reasonp++ =  x4;
  goto check__cn4_4_40;
 check__cn4_4_37:
  deref_and_jump(x4,check__cn4_4_22);
  *reasonp++ =  x4;
  goto check__cn4_4_40;
 check__cn4_4_38:
  deref_and_jump(x2,check__cn4_4_21);
  *reasonp++ =  x2;
  goto check__cn4_4_40;
 check__cn4_4_39:
  deref_and_jump(x2,check__cn4_4_20);
  *reasonp++ =  x2;
  goto check__cn4_4_40;
 case VARREF:
  deref_and_jump(x0,check__cn4_4_3);
  *reasonp++ =  x0;
  goto check__cn4_4_40;
  };
  goto check__cn4_4_40;
 case VARREF:
  deref_and_jump(a1,check__cn4_4_2);
  *reasonp++ =  a1;
  goto check__cn4_4_40;
  };
  goto check__cn4_4_40;
 case VARREF:
  deref_and_jump(a0,check__cn4_4_1);
  *reasonp++ =  a0;
  goto check__cn4_4_40;
  };
  goto check__cn4_4_40;
 check__cn4_4_40:
  otherwise(check__cn4_4_interrupt);
 check__cn4_4_41:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xcheck__cn4_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  x1 = cdr_of(a1);
  allocp[3] = x1;
  allocp[4] = a2;
  allocp[5] = a3;
  a1 = car_of(a1);
  a2 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(check__cn5_3_0);
  goto check__cn5_3_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto check__cn4_4_interrupt;
  unify(a2, a0);
  x0 = makesym(atom_undone);
  unify_value(a3, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,check__cn4_4_41);
  *reasonp++ =  a1;
  goto check__cn4_4_interrupt;
  };
  goto check__cn4_4_interrupt;
 check__cn4_4_ext_interrupt:
  reasonp = 0l;
 check__cn4_4_interrupt:
  toppred = &predicate_direct__call_xcheck__cn4_4;
  goto interrupt_4;
 }

 check__cn5_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  qp = qp->next;
 check__cn5_3_clear_reason:
  reasonp = reasons;
 check__cn5_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xcheck__movedgoal_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_list_xcheck__elements_3);
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = x0;
  allocp[11] = makesym(functor_goal_7);
  allocp[12] = x4 = makeref(&allocp[12]);
  allocp[13] = x5 = makeref(&allocp[13]);
  allocp[14] = x6 = makeref(&allocp[14]);
  allocp[15] = x7 = makeref(&allocp[15]);
  allocp[16] = x8 = makeref(&allocp[16]);
  allocp[17] = x9 = makeref(&allocp[17]);
  allocp[18] = x1;
  x3 = makefunctor(&allocp[11]);
  qp = (struct goalrec*)&allocp[6];
  allocp += 19;
  unify_value(a1, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(7L);
  allocp[3] = a0;
  allocp[4] = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 check__cn5_3_ext_interrupt:
  reasonp = 0l;
 check__cn5_3_interrupt:
  toppred = &predicate_direct__call_xcheck__cn5_3;
  goto interrupt_3;
 }

 check__movedgoal_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 check__movedgoal_4_clear_reason:
  reasonp = reasons;
 check__movedgoal_4_0:
 check__movedgoal_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto check__movedgoal_4_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = makeint(7L);
  allocp[3] = a1;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_direct__call_xreplace__thru_4);
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a2;
  allocp[10] = NILATOM;
  allocp[11] = x0;
  allocp[12] = (q)(struct goalrec*)&allocp[6];
  allocp[13] = (q)(&predicate_functor__table_xarg_3);
  allocp[14] = makeint(7L);
  allocp[15] = a1;
  allocp[16] = x1;
  qp = (struct goalrec*)&allocp[12];
  allocp += 17;
  proceed();
 case symval(makesym(atom_no)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xcheck__movedgoal2_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = makesym(functor_thru_3);
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = x4 = makeref(&allocp[9]);
  x1 = makefunctor(&allocp[6]);
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_list_xcheck__include_3);
  allocp[12] = x1;
  allocp[13] = x5 = makeref(&allocp[13]);
  allocp[14] = x0;
  allocp[15] = makesym(functor_goal_7);
  allocp[16] = x2;
  allocp[17] = x7 = makeref(&allocp[17]);
  allocp[18] = x8 = makeref(&allocp[18]);
  allocp[19] = x3;
  allocp[20] = x4;
  allocp[21] = x9 = makeref(&allocp[21]);
  allocp[22] = x10 = makeref(&allocp[22]);
  x6 = makefunctor(&allocp[15]);
  qp = (struct goalrec*)&allocp[10];
  allocp += 23;
  unify_value(a2, x6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(7L);
  allocp[3] = a1;
  allocp[4] = x5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
  };
  goto check__movedgoal_4_interrupt;
 case VARREF:
  deref_and_jump(a0,check__movedgoal_4_1);
  *reasonp++ =  a0;
  goto check__movedgoal_4_interrupt;
  };
  goto check__movedgoal_4_interrupt;
 check__movedgoal_4_ext_interrupt:
  reasonp = 0l;
 check__movedgoal_4_interrupt:
  goto interrupt_4;
 }

 replace__thru_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 replace__thru_4_clear_reason:
  reasonp = reasons;
 replace__thru_4_0:
 replace__thru_4_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xreplace__thru_4);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = a1;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_list_xmake__unique_2);
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = x1;
  allocp[10] = (q)(struct goalrec*)&allocp[6];
  allocp[11] = (q)(&predicate_list_xappend_3);
  allocp[12] = a2;
  allocp[13] = x3 = makeref(&allocp[13]);
  allocp[14] = x2;
  a0 = car_of(a0);
  a2 = x3;
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  execute(replace__thru2_3_0);
  goto replace__thru2_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto replace__thru_4_interrupt;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,replace__thru_4_1);
  *reasonp++ =  a0;
  goto replace__thru_4_interrupt;
  };
  goto replace__thru_4_interrupt;
 replace__thru_4_ext_interrupt:
  reasonp = 0l;
 replace__thru_4_interrupt:
  goto interrupt_4;
 }

 replace__thru2_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  qp = qp->next;
 replace__thru2_3_clear_reason:
  reasonp = reasons;
 replace__thru2_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xrename__thru_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_list_xsplit_4);
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = a0;
  allocp[9] = x1;
  allocp[10] = x3 = makeref(&allocp[10]);
  allocp[11] = makesym(functor_goal_7);
  allocp[12] = x5 = makeref(&allocp[12]);
  allocp[13] = x6 = makeref(&allocp[13]);
  allocp[14] = x7 = makeref(&allocp[14]);
  allocp[15] = x8 = makeref(&allocp[15]);
  allocp[16] = x0;
  allocp[17] = x9 = makeref(&allocp[17]);
  allocp[18] = x10 = makeref(&allocp[18]);
  x4 = makefunctor(&allocp[11]);
  qp = (struct goalrec*)&allocp[5];
  allocp += 19;
  unify_value(a1, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = makeint(7L);
  allocp[3] = a1;
  allocp[4] = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 replace__thru2_3_ext_interrupt:
  reasonp = 0l;
 replace__thru2_3_interrupt:
  toppred = &predicate_direct__call_xreplace__thru2_3;
  goto interrupt_3;
 }

 check__movedgoal2_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 check__movedgoal2_4_clear_reason:
  reasonp = reasons;
 check__movedgoal2_4_0:
 check__movedgoal2_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto check__movedgoal2_4_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  allocp[0] = makesym(functor_goal_7);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = x5 = makeref(&allocp[5]);
  allocp[6] = x6 = makeref(&allocp[6]);
  allocp[7] = x7 = makeref(&allocp[7]);
  x0 = makefunctor(&allocp[0]);
  allocp += 8;
  unify_value(a2, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = makeint(7L);
  allocp[3] = a1;
  allocp[4] = x8 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_list_xappend_3);
  allocp[8] = x9 = makeref(&allocp[8]);
  allocp[9] = x10 = makeref(&allocp[9]);
  allocp[10] = x8;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_functor__table_xarg_3);
  allocp[13] = makeint(7L);
  allocp[14] = a1;
  allocp[15] = x10;
  a0 = x5;
  a1 = x7;
  a2 = x9;
  qp = (struct goalrec*)&allocp[11];
  allocp += 16;
  execute(rename__thru_3_0);
  goto rename__thru_3_ext_interrupt;
 case symval(makesym(atom_no)):
  unify(a3, a1);
  proceed();
  };
  goto check__movedgoal2_4_interrupt;
 case VARREF:
  deref_and_jump(a0,check__movedgoal2_4_1);
  *reasonp++ =  a0;
  goto check__movedgoal2_4_interrupt;
  };
  goto check__movedgoal2_4_interrupt;
 check__movedgoal2_4_ext_interrupt:
  reasonp = 0l;
 check__movedgoal2_4_interrupt:
  goto interrupt_4;
 }

 rename__thru_3_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  qp = qp->next;
 rename__thru_3_clear_reason:
  reasonp = reasons;
 rename__thru_3_0:
 rename__thru_3_1:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xrename__thru_3);
  allocp[2] = a0;
  x0 = cdr_of(a1);
  allocp[3] = x0;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = x1;
  allocp[6] = x3 = makeref(&allocp[6]);
  x2 = makecons(&allocp[5]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  unify_value(a2, x2);
  a1 = car_of(a1);
  a2 = x3;
  execute(rename__thru2_3_0);
  goto rename__thru2_3_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto rename__thru_3_interrupt;
  x0 = NILATOM;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,rename__thru_3_1);
  *reasonp++ =  a1;
  goto rename__thru_3_interrupt;
  };
  goto rename__thru_3_interrupt;
 rename__thru_3_ext_interrupt:
  reasonp = 0l;
 rename__thru_3_interrupt:
  toppred = &predicate_direct__call_xrename__thru_3;
  goto interrupt_3;
 }

 rename__thru2_3_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  qp = qp->next;
 rename__thru2_3_clear_reason:
  reasonp = reasons;
 rename__thru2_3_0:
 rename__thru2_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 rename__thru2_3_2:
  if (a0 != makeint(0L)) goto rename__thru2_3_4;
 rename__thru2_3_3:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_thru_3)) goto rename__thru2_3_4;
  allocp[0] = makesym(functor_thru_3);
  x1 = arg(a1, 0);
  allocp[1] = x1;
  x2 = arg(a1, 1);
  allocp[2] = x2;
  x3 = arg(a1, 2);
  allocp[3] = x3;
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,rename__thru2_3_3);
  *reasonp++ =  a1;
  goto rename__thru2_3_4;
  };
  goto rename__thru2_3_4;
 case VARREF:
  deref_and_jump(a0,rename__thru2_3_1);
  *reasonp++ =  a0;
  goto rename__thru2_3_4;
  };
  goto rename__thru2_3_4;
 rename__thru2_3_4:
 rename__thru2_3_5:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_thru_3)) goto rename__thru2_3_interrupt;
 rename__thru2_3_6:
  if (!isint(a0)) goto rename__thru2_3_7;
  x0 = makeint(0L);
  gblt_greater(a0,x0,rename__thru2_3_interrupt);
  allocp[0] = makesym(functor_thru_3);
  x2 = arg(a1, 0);
  allocp[1] = x2;
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = x4 = makeref(&allocp[3]);
  x1 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a2, x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[2] = a0;
  x5 = arg(a1, 2);
  allocp[3] = x5;
  allocp[4] = x4;
  a0 = arg(a1, 1);
  a1 = makefunctor(&string_const_0);
  a2 = x3;
  a3 = makecons(cons_const_1);
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(rename_4_clear_reason);
  goto rename_4_ext_interrupt;
 rename__thru2_3_7:
  if (!isref(a0)) goto rename__thru2_3_interrupt;
  deref_and_jump(a0,rename__thru2_3_6);
  *reasonp++ =  a0;
  goto rename__thru2_3_interrupt;
 case VARREF:
  deref_and_jump(a1,rename__thru2_3_5);
  *reasonp++ =  a1;
  goto rename__thru2_3_interrupt;
  };
  goto rename__thru2_3_interrupt;
 rename__thru2_3_ext_interrupt:
  reasonp = 0l;
 rename__thru2_3_interrupt:
  toppred = &predicate_direct__call_xrename__thru2_3;
  goto interrupt_3;
 }

 replace_6_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 replace_6_clear_reason:
  reasonp = reasons;
 replace_6_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xreplace2_5);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a4;
  allocp[6] = a5;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_direct__call_xcheck__head_3);
  allocp[9] = a0;
  allocp[10] = a3;
  allocp[11] = x1;
  a0 = a1;
  a1 = a3;
  a3 = x0;
  qp = (struct goalrec*)&allocp[7];
  allocp += 12;
  execute(check__cn_4_0);
  goto check__cn_4_ext_interrupt;
 replace_6_ext_interrupt:
  reasonp = 0l;
 replace_6_interrupt:
  goto interrupt_6;
 }

 check__head_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  qp = qp->next;
 check__head_3_clear_reason:
  reasonp = reasons;
 check__head_3_0:
 check__head_3_1:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  x0 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a0, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xcheck__head2_5);
  allocp[2] = x5 = makeref(&allocp[2]);
  allocp[3] = a0;
  x6 = car_of(a1);
  allocp[4] = x6;
  x7 = cdr_of(a1);
  allocp[5] = x7;
  allocp[6] = a2;
  allocp[7] = makesym(functor_thru_3);
  allocp[8] = x1;
  allocp[9] = x3;
  allocp[10] = x4;
  x8 = makefunctor(&allocp[7]);
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_list_xcheck__include_3);
  allocp[13] = x8;
  allocp[14] = x9 = makeref(&allocp[14]);
  allocp[15] = x5;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_functor__table_xarg_3);
  allocp[18] = makeint(7L);
  allocp[19] = x6;
  allocp[20] = x9;
  qp = (struct goalrec*)&allocp[16];
  allocp += 21;
  proceed();
 case ATOMIC:
  if (a1 != NILATOM) goto check__head_3_interrupt;
  unify(a2, a0);
  proceed();
 case VARREF:
  deref_and_jump(a1,check__head_3_1);
  *reasonp++ =  a1;
  goto check__head_3_interrupt;
  };
  goto check__head_3_interrupt;
 check__head_3_ext_interrupt:
  reasonp = 0l;
 check__head_3_interrupt:
  toppred = &predicate_direct__call_xcheck__head_3;
  goto interrupt_3;
 }

 check__head2_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 check__head2_5_clear_reason:
  reasonp = reasons;
 check__head2_5_0:
 check__head2_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto check__head2_5_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  x0 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a1, x0);
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = x1;
  allocp[2] = x2;
  allocp[3] = x6 = makeref(&allocp[3]);
  allocp[4] = x7 = makeref(&allocp[4]);
  x5 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a4, x5);
  allocp[0] = makesym(functor_thru_3);
  allocp[1] = x9 = makeref(&allocp[1]);
  allocp[2] = x6;
  allocp[3] = x7;
  x8 = makefunctor(&allocp[0]);
  allocp[4] = makesym(functor_thru_3);
  allocp[5] = x1;
  allocp[6] = x3;
  allocp[7] = x4;
  x10 = makefunctor(&allocp[4]);
  allocp[8] = (q)qp;
  allocp[9] = (q)(&predicate_direct__call_xrename__thru2_3);
  allocp[10] = x11 = makeref(&allocp[10]);
  allocp[11] = x10;
  allocp[12] = x8;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_functor__table_xarg_3);
  allocp[15] = makeint(5L);
  allocp[16] = a2;
  allocp[17] = x11;
  qp = (struct goalrec*)&allocp[13];
  allocp += 18;
  proceed();
 case symval(makesym(atom_no)):
  a0 = a1;
  a1 = a3;
  a2 = a4;
  execute(check__head_3_0);
  goto check__head_3_ext_interrupt;
  };
  goto check__head2_5_interrupt;
 case VARREF:
  deref_and_jump(a0,check__head2_5_1);
  *reasonp++ =  a0;
  goto check__head2_5_interrupt;
  };
  goto check__head2_5_interrupt;
 check__head2_5_ext_interrupt:
  reasonp = 0l;
 check__head2_5_interrupt:
  goto interrupt_5;
 }

 replace2_5_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 replace2_5_clear_reason:
  reasonp = reasons;
 replace2_5_0:
 replace2_5_1:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_goal_7)) goto replace2_5_6;
  x0 = arg(a2, 3);
 replace2_5_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_report__measure)) goto replace2_5_6;
  x1 = arg(a2, 4);
 replace2_5_3:
  switch (ptagof(x1)) {
 case ATOMIC:
 replace2_5_4:
  if (x1 != makeint(1L)) goto replace2_5_6;
  x2 = arg(a2, 5);
 replace2_5_5:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != makesym(atom_builtin)) goto replace2_5_6;
  a0 = a1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  execute(replace__report__measure_4_0);
  goto replace__report__measure_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x2,replace2_5_5);
  *reasonp++ =  x2;
  goto replace2_5_6;
  };
  goto replace2_5_6;
 case VARREF:
  deref_and_jump(x1,replace2_5_3);
  *reasonp++ =  x1;
  goto replace2_5_6;
  };
  goto replace2_5_6;
 case VARREF:
  deref_and_jump(x0,replace2_5_2);
  *reasonp++ =  x0;
  goto replace2_5_6;
  };
  goto replace2_5_6;
 case VARREF:
  deref_and_jump(a2,replace2_5_1);
  *reasonp++ =  a2;
  goto replace2_5_6;
  };
  goto replace2_5_6;
 replace2_5_6:
  otherwise(replace2_5_interrupt);
 replace2_5_7:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto replace2_5_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_undone)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xreplace4_5);
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_direct__call_xreplace3_3);
  allocp[9] = a2;
  allocp[10] = a3;
  allocp[11] = x1;
  a0 = a3;
  a1 = a2;
  a2 = x0;
  qp = (struct goalrec*)&allocp[7];
  allocp += 12;
  execute(get__movegoal_3_0);
  goto get__movegoal_3_ext_interrupt;
 case symval(makesym(atom_done)):
  a0 = a2;
  a1 = a3;
  a2 = a4;
  execute(replace3_3_0);
  goto replace3_3_ext_interrupt;
 case symval(makesym(atom_done__before)):
  a0 = a1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  execute(make__newbodys_4_0);
  goto make__newbodys_4_ext_interrupt;
  };
  goto replace2_5_interrupt;
 case VARREF:
  deref_and_jump(a0,replace2_5_7);
  *reasonp++ =  a0;
  goto replace2_5_interrupt;
  };
  goto replace2_5_interrupt;
 replace2_5_ext_interrupt:
  reasonp = 0l;
 replace2_5_interrupt:
  goto interrupt_5;
 }

 replace__report__measure_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 replace__report__measure_4_clear_reason:
  reasonp = reasons;
 replace__report__measure_4_0:
 replace__report__measure_4_1:
  if (isref(a1)) goto replace__report__measure_4_5;
  x1 = makeint(7L);
  gblt_arg(x1,a1,x0,replace__report__measure_4_6);
 replace__report__measure_4_2:
  switch (ptagof(x0)) {
 case CONS:
  x2 = car_of(x0);
 replace__report__measure_4_3:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_thru_3)) goto replace__report__measure_4_6;
  x3 = cdr_of(x0);
 replace__report__measure_4_4:
  switch (ptagof(x3)) {
 case ATOMIC:
  if (x3 != NILATOM) goto replace__report__measure_4_6;
  execute(replace__report__measure2_4_0);
  goto replace__report__measure2_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x3,replace__report__measure_4_4);
  *reasonp++ =  x3;
  goto replace__report__measure_4_6;
  };
  goto replace__report__measure_4_6;
 case VARREF:
  deref_and_jump(x2,replace__report__measure_4_3);
  *reasonp++ =  x2;
  goto replace__report__measure_4_6;
  };
  goto replace__report__measure_4_6;
 case VARREF:
  deref_and_jump(x0,replace__report__measure_4_2);
  *reasonp++ =  x0;
  goto replace__report__measure_4_6;
  };
  goto replace__report__measure_4_6;
 replace__report__measure_4_5:
  deref_and_jump(a1,replace__report__measure_4_1);
  *reasonp++ =  a1;
  goto replace__report__measure_4_6;
 replace__report__measure_4_6:
  otherwise(replace__report__measure_4_interrupt);
 replace__report__measure_4_7:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_goal_7)) goto replace__report__measure_4_interrupt;
  x0 = arg(a1, 6);
 replace__report__measure_4_8:
  switch (ptagof(x0)) {
 case CONS:
  allocp[0] = makesym(functor_goal_7);
  x2 = arg(a1, 0);
  allocp[1] = x2;
  x3 = arg(a1, 1);
  allocp[2] = x3;
  x4 = arg(a1, 2);
  allocp[3] = x4;
  x5 = arg(a1, 3);
  allocp[4] = x5;
  x6 = arg(a1, 4);
  allocp[5] = x6;
  x7 = arg(a1, 5);
  allocp[6] = x7;
  x8 = cdr_of(x0);
  allocp[7] = x8;
  x1 = makefunctor(&allocp[0]);
  a1 = x1;
  allocp += 8;
  execute(replace__report__measure_4_0);
  goto replace__report__measure_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,replace__report__measure_4_8);
  *reasonp++ =  x0;
  goto replace__report__measure_4_interrupt;
  };
  goto replace__report__measure_4_interrupt;
 case VARREF:
  deref_and_jump(a1,replace__report__measure_4_7);
  *reasonp++ =  a1;
  goto replace__report__measure_4_interrupt;
  };
  goto replace__report__measure_4_interrupt;
 replace__report__measure_4_ext_interrupt:
  reasonp = 0l;
 replace__report__measure_4_interrupt:
  toppred = &predicate_direct__call_xreplace__report__measure_4;
  goto interrupt_4;
 }

 replace__report__measure2_4_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 replace__report__measure2_4_clear_reason:
  reasonp = reasons;
 replace__report__measure2_4_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xreplace__report__measure__to_5);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = a3;
  a0 = a1;
  a1 = x0;
  a3 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(replace__report__measure__from_4_0);
  goto replace__report__measure__from_4_ext_interrupt;
 replace__report__measure2_4_ext_interrupt:
  reasonp = 0l;
 replace__report__measure2_4_interrupt:
  toppred = &predicate_direct__call_xreplace__report__measure2_4;
  goto interrupt_4;
 }

 replace__report__measure__from_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 replace__report__measure__from_4_clear_reason:
  reasonp = reasons;
 replace__report__measure__from_4_0:
 replace__report__measure__from_4_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_goal_7)) goto replace__report__measure__from_4_11;
  x0 = arg(a0, 4);
 replace__report__measure__from_4_2:
  switch (ptagof(x0)) {
 case ATOMIC:
 replace__report__measure__from_4_3:
  if (x0 != makeint(1L)) goto replace__report__measure__from_4_11;
  x1 = arg(a0, 5);
 replace__report__measure__from_4_4:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_builtin)) goto replace__report__measure__from_4_11;
 replace__report__measure__from_4_5:
  switch (ptagof(a2)) {
 case CONS:
  x2 = car_of(a2);
 replace__report__measure__from_4_6:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_module_2)) goto replace__report__measure__from_4_11;
  x3 = arg(x2, 0);
 replace__report__measure__from_4_7:
  if (isref(x3)) goto replace__report__measure__from_4_10;
 replace__report__measure__from_4_8:
  if (isref(x3)) goto replace__report__measure__from_4_9;
  x4 = arg(a0, 0);
  if_not_equal(x3, x4, replace__report__measure__from_4_11);
  allocp[0] = makesym(functor_module_2);
  allocp[1] = x4;
  allocp[2] = x6 = makeref(&allocp[2]);
  x5 = makefunctor(&allocp[0]);
  x8 = cdr_of(a2);
  allocp[3] = x8;
  allocp[4] = x5;
  x7 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a3, x7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  x9 = arg(a0, 1);
  allocp[2] = x9;
  x10 = arg(x2, 1);
  allocp[3] = x10;
  allocp[4] = x11 = makeref(&allocp[4]);
  allocp[5] = x6;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[8] = makeint(3L);
  allocp[9] = x12 = makeref(&allocp[9]);
  allocp[10] = x13 = makeref(&allocp[10]);
  allocp[11] = x11;
  allocp[12] = (q)(struct goalrec*)&allocp[6];
  allocp[13] = (q)(&predicate_functor_xdelete__arg_3);
  x14 = arg(a0, 2);
  allocp[14] = x14;
  allocp[15] = x15 = makeref(&allocp[15]);
  allocp[16] = x13;
  allocp[17] = (q)(struct goalrec*)&allocp[12];
  allocp[18] = (q)(&predicate_functor__table_xarg_3);
  allocp[19] = x14;
  allocp[20] = x15;
  allocp[21] = a1;
  allocp[22] = makesym(functor_clause_4);
  allocp[23] = x17 = makeref(&allocp[23]);
  allocp[24] = x18 = makeref(&allocp[24]);
  allocp[25] = x15;
  allocp[26] = x19 = makeref(&allocp[26]);
  x16 = makefunctor(&allocp[22]);
  qp = (struct goalrec*)&allocp[17];
  allocp += 27;
  unify_value(x12, x16);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = x9;
  allocp[3] = x10;
  allocp[4] = x12;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 replace__report__measure__from_4_9:
  deref_and_jump(x3,replace__report__measure__from_4_8);
  *reasonp++ =  x3;
  goto replace__report__measure__from_4_11;
 replace__report__measure__from_4_10:
  deref_and_jump(x3,replace__report__measure__from_4_7);
  *reasonp++ =  x3;
  goto replace__report__measure__from_4_11;
 case VARREF:
  deref_and_jump(x2,replace__report__measure__from_4_6);
  *reasonp++ =  x2;
  goto replace__report__measure__from_4_11;
  };
  goto replace__report__measure__from_4_11;
 case VARREF:
  deref_and_jump(a2,replace__report__measure__from_4_5);
  *reasonp++ =  a2;
  goto replace__report__measure__from_4_11;
  };
  goto replace__report__measure__from_4_11;
 case VARREF:
  deref_and_jump(x1,replace__report__measure__from_4_4);
  *reasonp++ =  x1;
  goto replace__report__measure__from_4_11;
  };
  goto replace__report__measure__from_4_11;
 case VARREF:
  deref_and_jump(x0,replace__report__measure__from_4_2);
  *reasonp++ =  x0;
  goto replace__report__measure__from_4_11;
  };
  goto replace__report__measure__from_4_11;
 case VARREF:
  deref_and_jump(a0,replace__report__measure__from_4_1);
  *reasonp++ =  a0;
  goto replace__report__measure__from_4_11;
  };
  goto replace__report__measure__from_4_11;
 replace__report__measure__from_4_11:
  otherwise(replace__report__measure__from_4_interrupt);
 replace__report__measure__from_4_12:
  switch (ptagof(a2)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a2);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a3, x0);
  a2 = cdr_of(a2);
  a3 = x1;
  execute(replace__report__measure__from_4_0);
  goto replace__report__measure__from_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,replace__report__measure__from_4_12);
  *reasonp++ =  a2;
  goto replace__report__measure__from_4_interrupt;
  };
  goto replace__report__measure__from_4_interrupt;
 replace__report__measure__from_4_ext_interrupt:
  reasonp = 0l;
 replace__report__measure__from_4_interrupt:
  toppred = &predicate_direct__call_xreplace__report__measure__from_4;
  goto interrupt_4;
 }

 replace__report__measure__to_5_top: {
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 replace__report__measure__to_5_clear_reason:
  reasonp = reasons;
 replace__report__measure__to_5_0:
  execute(replace4_5_0);
  goto replace4_5_ext_interrupt;
 replace__report__measure__to_5_ext_interrupt:
  reasonp = 0l;
 replace__report__measure__to_5_interrupt:
  goto interrupt_5;
 }

 make__newbodys_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 make__newbodys_4_clear_reason:
  reasonp = reasons;
 make__newbodys_4_0:
 make__newbodys_4_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_goal_4)) goto make__newbodys_4_8;
 make__newbodys_4_2:
  switch (ptagof(a2)) {
 case CONS:
  x0 = car_of(a2);
 make__newbodys_4_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto make__newbodys_4_8;
  x1 = arg(x0, 0);
 make__newbodys_4_4:
  if (isref(x1)) goto make__newbodys_4_7;
 make__newbodys_4_5:
  if (isref(x1)) goto make__newbodys_4_6;
  x2 = arg(a0, 0);
  if_not_equal(x1, x2, make__newbodys_4_8);
  allocp[0] = makesym(functor_module_2);
  allocp[1] = x2;
  allocp[2] = x4 = makeref(&allocp[2]);
  x3 = makefunctor(&allocp[0]);
  x6 = cdr_of(a2);
  allocp[3] = x6;
  allocp[4] = x3;
  x5 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a3, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  x7 = arg(a0, 1);
  allocp[2] = x7;
  x8 = arg(x0, 1);
  allocp[3] = x8;
  allocp[4] = x9 = makeref(&allocp[4]);
  allocp[5] = x4;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[8] = makeint(3L);
  allocp[9] = x10 = makeref(&allocp[9]);
  allocp[10] = x11 = makeref(&allocp[10]);
  allocp[11] = x9;
  allocp[12] = (q)(struct goalrec*)&allocp[6];
  allocp[13] = (q)(&predicate_direct__call_xmake__newbody_5);
  allocp[14] = x12 = makeref(&allocp[14]);
  allocp[15] = x2;
  allocp[16] = a1;
  allocp[17] = x13 = makeref(&allocp[17]);
  allocp[18] = x11;
  allocp[19] = (q)(struct goalrec*)&allocp[12];
  allocp[20] = (q)(&predicate_direct__call_xget__max__vn_2);
  allocp[21] = x10;
  allocp[22] = x12;
  allocp[23] = makesym(functor_clause_4);
  allocp[24] = x15 = makeref(&allocp[24]);
  allocp[25] = x16 = makeref(&allocp[25]);
  allocp[26] = x13;
  allocp[27] = x17 = makeref(&allocp[27]);
  x14 = makefunctor(&allocp[23]);
  qp = (struct goalrec*)&allocp[19];
  allocp += 28;
  unify_value(x10, x14);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = x7;
  allocp[3] = x8;
  allocp[4] = x10;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 make__newbodys_4_6:
  deref_and_jump(x1,make__newbodys_4_5);
  *reasonp++ =  x1;
  goto make__newbodys_4_8;
 make__newbodys_4_7:
  deref_and_jump(x1,make__newbodys_4_4);
  *reasonp++ =  x1;
  goto make__newbodys_4_8;
 case VARREF:
  deref_and_jump(x0,make__newbodys_4_3);
  *reasonp++ =  x0;
  goto make__newbodys_4_8;
  };
  goto make__newbodys_4_8;
 case VARREF:
  deref_and_jump(a2,make__newbodys_4_2);
  *reasonp++ =  a2;
  goto make__newbodys_4_8;
  };
  goto make__newbodys_4_8;
 case VARREF:
  deref_and_jump(a0,make__newbodys_4_1);
  *reasonp++ =  a0;
  goto make__newbodys_4_8;
  };
  goto make__newbodys_4_8;
 make__newbodys_4_8:
  otherwise(make__newbodys_4_interrupt);
 make__newbodys_4_9:
  switch (ptagof(a2)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a2);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a3, x0);
  a2 = cdr_of(a2);
  a3 = x1;
  execute(make__newbodys_4_0);
  goto make__newbodys_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,make__newbodys_4_9);
  *reasonp++ =  a2;
  goto make__newbodys_4_interrupt;
  };
  goto make__newbodys_4_interrupt;
 make__newbodys_4_ext_interrupt:
  reasonp = 0l;
 make__newbodys_4_interrupt:
  toppred = &predicate_direct__call_xmake__newbodys_4;
  goto interrupt_4;
 }

 make__newbody_5_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 make__newbody_5_clear_reason:
  reasonp = reasons;
 make__newbody_5_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xmake__newbody2_5);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_direct__call_xcheck__builtin_4);
  allocp[9] = a1;
  allocp[10] = x1 = makeref(&allocp[10]);
  allocp[11] = a3;
  allocp[12] = x0;
  allocp[13] = (q)(struct goalrec*)&allocp[7];
  allocp[14] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[15] = a3;
  allocp[16] = x2 = makeref(&allocp[16]);
  allocp[17] = x1;
  qp = (struct goalrec*)&allocp[13];
  allocp += 18;
  proceed();
 make__newbody_5_ext_interrupt:
  reasonp = 0l;
 make__newbody_5_interrupt:
  goto interrupt_5;
 }

 make__newbody2_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 make__newbody2_5_clear_reason:
  reasonp = reasons;
 make__newbody2_5_0:
 make__newbody2_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto make__newbody2_5_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_no)):
  unify(a4, a3);
  proceed();
 case symval(makesym(atom_yes)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor_xinsert__arg_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a3;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a4;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_parse__uty_xencode__goal_4);
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = makesym(atom_userdef);
  allocp[10] = makefunctor(funct_const_8);
  allocp[11] = x1;
  allocp[12] = (q)(struct goalrec*)&allocp[6];
  allocp[13] = (q)(&predicate_direct__call_xmake__newgoal_4);
  allocp[14] = x3 = makeref(&allocp[14]);
  allocp[15] = makeint(1L);
  allocp[16] = x4 = makeref(&allocp[16]);
  allocp[17] = x2;
  allocp[18] = (q)(struct goalrec*)&allocp[12];
  allocp[19] = (q)(&predicate_direct__call_xcreate__newvar_3);
  allocp[20] = x5 = makeref(&allocp[20]);
  allocp[21] = x3;
  allocp[22] = a1;
  allocp[23] = makesym(functor_goal_7);
  allocp[24] = x7 = makeref(&allocp[24]);
  allocp[25] = x8 = makeref(&allocp[25]);
  allocp[26] = x9 = makeref(&allocp[26]);
  allocp[27] = x4;
  allocp[28] = x5;
  allocp[29] = x10 = makeref(&allocp[29]);
  allocp[30] = x11 = makeref(&allocp[30]);
  x6 = makefunctor(&allocp[23]);
  qp = (struct goalrec*)&allocp[18];
  allocp += 31;
  unify_value(a2, x6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[2] = a3;
  allocp[3] = x12 = makeref(&allocp[3]);
  allocp[4] = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
  };
  goto make__newbody2_5_interrupt;
 case VARREF:
  deref_and_jump(a0,make__newbody2_5_1);
  *reasonp++ =  a0;
  goto make__newbody2_5_interrupt;
  };
  goto make__newbody2_5_interrupt;
 make__newbody2_5_ext_interrupt:
  reasonp = 0l;
 make__newbody2_5_interrupt:
  goto interrupt_5;
 }

 make__newgoal_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 make__newgoal_4_clear_reason:
  reasonp = reasons;
 make__newgoal_4_0:
 make__newgoal_4_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xmake__newgoal_4);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[8] = a1;
  allocp[9] = makeint(1L);
  allocp[10] = x1;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_functor_xinsert__arg_4);
  allocp[13] = a1;
  allocp[14] = a2;
  x3 = car_of(a0);
  allocp[15] = x3;
  allocp[16] = x2;
  qp = (struct goalrec*)&allocp[11];
  allocp += 17;
  proceed();
 case ATOMIC:
  if (a0 != NILATOM) goto make__newgoal_4_interrupt;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,make__newgoal_4_1);
  *reasonp++ =  a0;
  goto make__newgoal_4_interrupt;
  };
  goto make__newgoal_4_interrupt;
 make__newgoal_4_ext_interrupt:
  reasonp = 0l;
 make__newgoal_4_interrupt:
  goto interrupt_4;
 }

 replace3_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15;
  a2 = qp->args[2];
  qp = qp->next;
 replace3_3_clear_reason:
  reasonp = reasons;
 replace3_3_0:
 replace3_3_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_goal_7)) goto replace3_3_interrupt;
 replace3_3_2:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 replace3_3_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto replace3_3_interrupt;
  x1 = arg(x0, 0);
 replace3_3_4:
  if (isref(x1)) goto replace3_3_7;
 replace3_3_5:
  if (isref(x1)) goto replace3_3_6;
  x2 = arg(a0, 0);
  if_not_equal(x1, x2, replace3_3_interrupt);
  allocp[0] = makesym(functor_module_2);
  allocp[1] = x2;
  allocp[2] = x4 = makeref(&allocp[2]);
  x3 = makefunctor(&allocp[0]);
  x6 = cdr_of(a1);
  allocp[3] = x6;
  allocp[4] = x3;
  x5 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a2, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  x7 = arg(a0, 1);
  allocp[2] = x7;
  x8 = arg(x0, 1);
  allocp[3] = x8;
  allocp[4] = x9 = makeref(&allocp[4]);
  allocp[5] = x4;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_direct__call_xreplace__clause_9);
  allocp[8] = x2;
  allocp[9] = x7;
  allocp[10] = x10 = makeref(&allocp[10]);
  allocp[11] = x9;
  allocp[12] = makesym(atom___);
  allocp[13] = a0;
  allocp[14] = makesym(atom___);
  allocp[15] = makeint(0L);
  allocp[16] = NILATOM;
  allocp[17] = makesym(functor_clause_4);
  allocp[18] = x12 = makeref(&allocp[18]);
  allocp[19] = x13 = makeref(&allocp[19]);
  allocp[20] = x14 = makeref(&allocp[20]);
  allocp[21] = x15 = makeref(&allocp[21]);
  x11 = makefunctor(&allocp[17]);
  qp = (struct goalrec*)&allocp[6];
  allocp += 22;
  unify_value(x10, x11);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = x7;
  allocp[3] = x8;
  allocp[4] = x10;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 replace3_3_6:
  deref_and_jump(x1,replace3_3_5);
  *reasonp++ =  x1;
  goto replace3_3_interrupt;
 replace3_3_7:
  deref_and_jump(x1,replace3_3_4);
  *reasonp++ =  x1;
  goto replace3_3_interrupt;
 case VARREF:
  deref_and_jump(x0,replace3_3_3);
  *reasonp++ =  x0;
  goto replace3_3_interrupt;
  };
  goto replace3_3_interrupt;
 case VARREF:
  deref_and_jump(a1,replace3_3_2);
  *reasonp++ =  a1;
  goto replace3_3_interrupt;
  };
  goto replace3_3_interrupt;
 case VARREF:
  deref_and_jump(a0,replace3_3_1);
  *reasonp++ =  a0;
  goto replace3_3_interrupt;
  };
  goto replace3_3_interrupt;
 replace3_3_ext_interrupt:
  reasonp = 0l;
 replace3_3_interrupt:
  toppred = &predicate_direct__call_xreplace3_3;
  goto interrupt_3;
 }

 replace4_5_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 replace4_5_clear_reason:
  reasonp = reasons;
 replace4_5_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xreplace4_6);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x0 = makeref(&allocp[5]);
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_functor__table_xarg_3);
  allocp[10] = makeint(7L);
  allocp[11] = a1;
  allocp[12] = x0;
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  proceed();
 replace4_5_ext_interrupt:
  reasonp = 0l;
 replace4_5_interrupt:
  toppred = &predicate_direct__call_xreplace4_5;
  goto interrupt_5;
 }

 replace4_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 replace4_6_clear_reason:
  reasonp = reasons;
 replace4_6_0:
 replace4_6_1:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_goal_7)) goto replace4_6_5;
  x0 = arg(a1, 6);
 replace4_6_2:
  switch (ptagof(x0)) {
 case CONS:
  x1 = car_of(x0);
 replace4_6_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_thru_3)) goto replace4_6_5;
  x2 = cdr_of(x0);
 replace4_6_4:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != NILATOM) goto replace4_6_5;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xreplace__clauses_7);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_parse__uty_xget__def__clauses_5);
  x4 = arg(x1, 0);
  allocp[11] = x4;
  x5 = arg(x1, 1);
  allocp[12] = x5;
  x6 = arg(x1, 2);
  allocp[13] = x6;
  allocp[14] = x3;
  allocp[15] = a4;
  qp = (struct goalrec*)&allocp[9];
  allocp += 16;
  proceed();
 case VARREF:
  deref_and_jump(x2,replace4_6_4);
  *reasonp++ =  x2;
  goto replace4_6_5;
  };
  goto replace4_6_5;
 case VARREF:
  deref_and_jump(x1,replace4_6_3);
  *reasonp++ =  x1;
  goto replace4_6_5;
  };
  goto replace4_6_5;
 case VARREF:
  deref_and_jump(x0,replace4_6_2);
  *reasonp++ =  x0;
  goto replace4_6_5;
  };
  goto replace4_6_5;
 case VARREF:
  deref_and_jump(a1,replace4_6_1);
  *reasonp++ =  a1;
  goto replace4_6_5;
  };
  goto replace4_6_5;
 replace4_6_5:
  otherwise(replace4_6_interrupt);
 replace4_6_6:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_goal_7)) goto replace4_6_interrupt;
  x0 = arg(a1, 6);
 replace4_6_7:
  switch (ptagof(x0)) {
 case CONS:
  x1 = car_of(x0);
 replace4_6_8:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_thru_3)) goto replace4_6_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xreplace4_6);
  allocp[2] = a0;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = makesym(functor_goal_7);
  x5 = arg(a1, 0);
  allocp[9] = x5;
  x6 = arg(a1, 1);
  allocp[10] = x6;
  x7 = arg(a1, 2);
  allocp[11] = x7;
  x8 = arg(a1, 3);
  allocp[12] = x8;
  x9 = arg(a1, 4);
  allocp[13] = x9;
  x10 = arg(a1, 5);
  allocp[14] = x10;
  x11 = cdr_of(x0);
  allocp[15] = x11;
  x4 = makefunctor(&allocp[8]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 16;
  unify_value(x2, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xreplace__clauses2_5);
  allocp[2] = x12 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a3;
  allocp[5] = a4;
  allocp[6] = x3;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_parse__uty_xget__def__clauses_5);
  x13 = arg(x1, 0);
  allocp[9] = x13;
  x14 = arg(x1, 1);
  allocp[10] = x14;
  x15 = arg(x1, 2);
  allocp[11] = x15;
  allocp[12] = x12;
  allocp[13] = a4;
  qp = (struct goalrec*)&allocp[7];
  allocp += 14;
  proceed();
 case VARREF:
  deref_and_jump(x1,replace4_6_8);
  *reasonp++ =  x1;
  goto replace4_6_interrupt;
  };
  goto replace4_6_interrupt;
 case VARREF:
  deref_and_jump(x0,replace4_6_7);
  *reasonp++ =  x0;
  goto replace4_6_interrupt;
  };
  goto replace4_6_interrupt;
 case VARREF:
  deref_and_jump(a1,replace4_6_6);
  *reasonp++ =  a1;
  goto replace4_6_interrupt;
  };
  goto replace4_6_interrupt;
 replace4_6_ext_interrupt:
  reasonp = 0l;
 replace4_6_interrupt:
  goto interrupt_6;
 }

 replace__clauses2_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 replace__clauses2_5_clear_reason:
  reasonp = reasons;
 replace__clauses2_5_0:
 replace__clauses2_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 replace__clauses2_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_cl_2)) goto replace__clauses2_5_interrupt;
 replace__clauses2_5_3:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_goal_7)) goto replace__clauses2_5_interrupt;
  x1 = arg(a1, 6);
 replace__clauses2_5_4:
  switch (ptagof(x1)) {
 case CONS:
  x2 = car_of(x1);
 replace__clauses2_5_5:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_thru_3)) goto replace__clauses2_5_interrupt;
  x3 = cdr_of(x1);
 replace__clauses2_5_6:
  switch (ptagof(x3)) {
 case CONS:
  x4 = car_of(x3);
 replace__clauses2_5_7:
  switch (ptagof(x4)) {
 case FUNCTOR:
  if (functor_of(x4) != makesym(functor_thru_3)) goto replace__clauses2_5_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xreplace__clauses2_5);
  x5 = cdr_of(a0);
  allocp[2] = x5;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x6 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_parse__uty_xupdate__clause_5);
  x7 = arg(x2, 0);
  allocp[9] = x7;
  x8 = arg(x0, 0);
  allocp[10] = x8;
  allocp[11] = x9 = makeref(&allocp[11]);
  allocp[12] = a3;
  allocp[13] = x6;
  allocp[14] = makesym(functor_thru_3);
  allocp[15] = x7;
  x11 = arg(x2, 1);
  allocp[16] = x11;
  x12 = arg(x2, 2);
  allocp[17] = x12;
  x10 = makefunctor(&allocp[14]);
  allocp[18] = makesym(functor_thru_3);
  x14 = arg(x4, 0);
  allocp[19] = x14;
  x15 = arg(x4, 1);
  allocp[20] = x15;
  x16 = arg(x4, 2);
  allocp[21] = x16;
  x13 = makefunctor(&allocp[18]);
  allocp[22] = (q)(struct goalrec*)&allocp[7];
  allocp[23] = (q)(&predicate_direct__call_xreplace__clause_9);
  allocp[24] = x7;
  x17 = arg(a1, 4);
  allocp[25] = x17;
  x18 = arg(x0, 1);
  allocp[26] = x18;
  allocp[27] = x9;
  allocp[28] = x10;
  allocp[29] = x13;
  allocp[30] = makesym(atom___);
  allocp[31] = x19 = makeref(&allocp[31]);
  allocp[32] = a2;
  a0 = x18;
  a1 = x19;
  qp = (struct goalrec*)&allocp[22];
  allocp += 33;
  execute(get__max__vn_2_0);
  goto get__max__vn_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x4,replace__clauses2_5_7);
  *reasonp++ =  x4;
  goto replace__clauses2_5_interrupt;
  };
  goto replace__clauses2_5_interrupt;
 case VARREF:
  deref_and_jump(x3,replace__clauses2_5_6);
  *reasonp++ =  x3;
  goto replace__clauses2_5_interrupt;
  };
  goto replace__clauses2_5_interrupt;
 case VARREF:
  deref_and_jump(x2,replace__clauses2_5_5);
  *reasonp++ =  x2;
  goto replace__clauses2_5_interrupt;
  };
  goto replace__clauses2_5_interrupt;
 case VARREF:
  deref_and_jump(x1,replace__clauses2_5_4);
  *reasonp++ =  x1;
  goto replace__clauses2_5_interrupt;
  };
  goto replace__clauses2_5_interrupt;
 case VARREF:
  deref_and_jump(a1,replace__clauses2_5_3);
  *reasonp++ =  a1;
  goto replace__clauses2_5_interrupt;
  };
  goto replace__clauses2_5_interrupt;
 case VARREF:
  deref_and_jump(x0,replace__clauses2_5_2);
  *reasonp++ =  x0;
  goto replace__clauses2_5_interrupt;
  };
  goto replace__clauses2_5_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto replace__clauses2_5_interrupt;
  unify(a4, a3);
  proceed();
 case VARREF:
  deref_and_jump(a0,replace__clauses2_5_1);
  *reasonp++ =  a0;
  goto replace__clauses2_5_interrupt;
  };
  goto replace__clauses2_5_interrupt;
 replace__clauses2_5_ext_interrupt:
  reasonp = 0l;
 replace__clauses2_5_interrupt:
  goto interrupt_5;
 }

 replace__clauses_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 replace__clauses_7_clear_reason:
  reasonp = reasons;
 replace__clauses_7_0:
 replace__clauses_7_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 replace__clauses_7_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_cl_2)) goto replace__clauses_7_interrupt;
 replace__clauses_7_3:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_goal_7)) goto replace__clauses_7_interrupt;
  x1 = arg(a2, 6);
 replace__clauses_7_4:
  switch (ptagof(x1)) {
 case CONS:
  x2 = car_of(x1);
 replace__clauses_7_5:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_thru_3)) goto replace__clauses_7_interrupt;
  x3 = cdr_of(x1);
 replace__clauses_7_6:
  switch (ptagof(x3)) {
 case ATOMIC:
  if (x3 != NILATOM) goto replace__clauses_7_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xreplace__clauses_7);
  x4 = cdr_of(a0);
  allocp[2] = x4;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x5 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_parse__uty_xupdate__clause_5);
  x6 = arg(x2, 0);
  allocp[11] = x6;
  x7 = arg(x0, 0);
  allocp[12] = x7;
  allocp[13] = x8 = makeref(&allocp[13]);
  allocp[14] = a5;
  allocp[15] = x5;
  allocp[16] = (q)(struct goalrec*)&allocp[9];
  allocp[17] = (q)(&predicate_direct__call_xreplace__clause_9);
  allocp[18] = x6;
  allocp[19] = x7;
  x9 = arg(x0, 1);
  allocp[20] = x9;
  allocp[21] = x8;
  allocp[22] = a1;
  allocp[23] = a2;
  allocp[24] = a3;
  allocp[25] = x10 = makeref(&allocp[25]);
  allocp[26] = a4;
  a0 = x9;
  a1 = x10;
  qp = (struct goalrec*)&allocp[16];
  allocp += 27;
  execute(get__max__vn_2_0);
  goto get__max__vn_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x3,replace__clauses_7_6);
  *reasonp++ =  x3;
  goto replace__clauses_7_interrupt;
  };
  goto replace__clauses_7_interrupt;
 case VARREF:
  deref_and_jump(x2,replace__clauses_7_5);
  *reasonp++ =  x2;
  goto replace__clauses_7_interrupt;
  };
  goto replace__clauses_7_interrupt;
 case VARREF:
  deref_and_jump(x1,replace__clauses_7_4);
  *reasonp++ =  x1;
  goto replace__clauses_7_interrupt;
  };
  goto replace__clauses_7_interrupt;
 case VARREF:
  deref_and_jump(a2,replace__clauses_7_3);
  *reasonp++ =  a2;
  goto replace__clauses_7_interrupt;
  };
  goto replace__clauses_7_interrupt;
 case VARREF:
  deref_and_jump(x0,replace__clauses_7_2);
  *reasonp++ =  x0;
  goto replace__clauses_7_interrupt;
  };
  goto replace__clauses_7_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto replace__clauses_7_interrupt;
  unify(a6, a5);
  proceed();
 case VARREF:
  deref_and_jump(a0,replace__clauses_7_1);
  *reasonp++ =  a0;
  goto replace__clauses_7_interrupt;
  };
  goto replace__clauses_7_interrupt;
 replace__clauses_7_ext_interrupt:
  reasonp = 0l;
 replace__clauses_7_interrupt:
  goto interrupt_7;
 }

 get__movegoal_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  qp = qp->next;
 get__movegoal_3_clear_reason:
  reasonp = reasons;
 get__movegoal_3_0:
 get__movegoal_3_1:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_goal_7)) goto get__movegoal_3_8;
 get__movegoal_3_2:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 get__movegoal_3_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto get__movegoal_3_8;
  x1 = arg(x0, 0);
 get__movegoal_3_4:
  if (isref(x1)) goto get__movegoal_3_7;
 get__movegoal_3_5:
  if (isref(x1)) goto get__movegoal_3_6;
  x2 = arg(a1, 0);
  if_not_equal(x1, x2, get__movegoal_3_8);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  x3 = arg(a1, 2);
  allocp[2] = x3;
  allocp[3] = x4 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = makesym(functor_clause_4);
  allocp[6] = x6 = makeref(&allocp[6]);
  allocp[7] = x7 = makeref(&allocp[7]);
  allocp[8] = x4;
  allocp[9] = x8 = makeref(&allocp[9]);
  x5 = makefunctor(&allocp[5]);
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  x9 = arg(a1, 1);
  allocp[12] = x9;
  x10 = arg(x0, 1);
  allocp[13] = x10;
  allocp[14] = x5;
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 get__movegoal_3_6:
  deref_and_jump(x1,get__movegoal_3_5);
  *reasonp++ =  x1;
  goto get__movegoal_3_8;
 get__movegoal_3_7:
  deref_and_jump(x1,get__movegoal_3_4);
  *reasonp++ =  x1;
  goto get__movegoal_3_8;
 case VARREF:
  deref_and_jump(x0,get__movegoal_3_3);
  *reasonp++ =  x0;
  goto get__movegoal_3_8;
  };
  goto get__movegoal_3_8;
 case VARREF:
  deref_and_jump(a0,get__movegoal_3_2);
  *reasonp++ =  a0;
  goto get__movegoal_3_8;
  };
  goto get__movegoal_3_8;
 case VARREF:
  deref_and_jump(a1,get__movegoal_3_1);
  *reasonp++ =  a1;
  goto get__movegoal_3_8;
  };
  goto get__movegoal_3_8;
 get__movegoal_3_8:
  otherwise(get__movegoal_3_interrupt);
 get__movegoal_3_9:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(get__movegoal_3_0);
  goto get__movegoal_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto get__movegoal_3_interrupt;
  x0 = makesym(atom___);
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,get__movegoal_3_9);
  *reasonp++ =  a0;
  goto get__movegoal_3_interrupt;
  };
  goto get__movegoal_3_interrupt;
 get__movegoal_3_ext_interrupt:
  reasonp = 0l;
 get__movegoal_3_interrupt:
  toppred = &predicate_direct__call_xget__movegoal_3;
  goto interrupt_3;
 }

 replace__clause_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 replace__clause_9_clear_reason:
  reasonp = reasons;
 replace__clause_9_0:
 replace__clause_9_1:
  switch (ptagof(a4)) {
 case FUNCTOR:
  switch (symval(functor_of(a4))) {
 case functor_goal_4:
  x0 = arg(a4, 0);
 replace__clause_9_2:
  if (isref(x0)) goto replace__clause_9_13;
 replace__clause_9_3:
  if (isref(x0)) goto replace__clause_9_12;
  if_not_equal(x0, a0, replace__clause_9_19);
  x1 = arg(a4, 1);
 replace__clause_9_4:
  if (isref(x1)) goto replace__clause_9_11;
 replace__clause_9_5:
  if (isref(x1)) goto replace__clause_9_10;
  if_not_equal(x1, a1, replace__clause_9_19);
 replace__clause_9_6:
  if (isref(a5)) goto replace__clause_9_9;
  x3 = makeint(4L);
  gblt_arg(x3,a5,x2,replace__clause_9_19);
 replace__clause_9_7:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != makesym(atom_report__measure)) goto replace__clause_9_19;
 replace__clause_9_8:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_clause_4)) goto replace__clause_9_19;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = makeint(3L);
  allocp[3] = a2;
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor_xinsert__arg_4);
  allocp[8] = x5 = makeref(&allocp[8]);
  x6 = arg(a2, 2);
  allocp[9] = x6;
  allocp[10] = x7 = makeref(&allocp[10]);
  allocp[11] = x4;
  allocp[12] = (q)(struct goalrec*)&allocp[6];
  allocp[13] = (q)(&predicate_parse__uty_xencode__goal_4);
  allocp[14] = x8 = makeref(&allocp[14]);
  allocp[15] = x9 = makeref(&allocp[15]);
  allocp[16] = x10 = makeref(&allocp[16]);
  allocp[17] = x7;
  allocp[18] = makesym(functor_variable_3);
  allocp[19] = x12 = makeref(&allocp[19]);
  allocp[20] = makeint(-1L);
  allocp[21] = makesym(atom__3F);
  x11 = makefunctor(&allocp[18]);
  allocp[22] = (q)(struct goalrec*)&allocp[12];
  allocp[23] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[24] = makeint(1L);
  allocp[25] = x13 = makeref(&allocp[25]);
  allocp[26] = x11;
  allocp[27] = x8;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[30] = a7;
  allocp[31] = makeint(1L);
  allocp[32] = x12;
  allocp[33] = (q)(struct goalrec*)&allocp[28];
  allocp[34] = (q)(&predicate_parse__uty_xdecode__goal_4);
  allocp[35] = a6;
  allocp[36] = x13;
  allocp[37] = x9;
  allocp[38] = x10;
  allocp[39] = (q)(struct goalrec*)&allocp[33];
  allocp[40] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[41] = x6;
  allocp[42] = x14 = makeref(&allocp[42]);
  allocp[43] = x5;
  qp = (struct goalrec*)&allocp[39];
  allocp += 44;
  proceed();
 case VARREF:
  deref_and_jump(a2,replace__clause_9_8);
  *reasonp++ =  a2;
  goto replace__clause_9_19;
  };
  goto replace__clause_9_19;
 case VARREF:
  deref_and_jump(x2,replace__clause_9_7);
  *reasonp++ =  x2;
  goto replace__clause_9_19;
  };
  goto replace__clause_9_19;
 replace__clause_9_9:
  deref_and_jump(a5,replace__clause_9_6);
  *reasonp++ =  a5;
  goto replace__clause_9_19;
 replace__clause_9_10:
  deref_and_jump(x1,replace__clause_9_5);
  *reasonp++ =  x1;
  goto replace__clause_9_19;
 replace__clause_9_11:
  deref_and_jump(x1,replace__clause_9_4);
  *reasonp++ =  x1;
  goto replace__clause_9_19;
 replace__clause_9_12:
  deref_and_jump(x0,replace__clause_9_3);
  *reasonp++ =  x0;
  goto replace__clause_9_19;
 replace__clause_9_13:
  deref_and_jump(x0,replace__clause_9_2);
  *reasonp++ =  x0;
  goto replace__clause_9_19;
 case functor_thru_3:
 replace__clause_9_14:
  switch (ptagof(a5)) {
 case FUNCTOR:
  if (functor_of(a5) != makesym(functor_thru_3)) goto replace__clause_9_19;
 replace__clause_9_15:
  switch (ptagof(a6)) {
 case ATOMIC:
  if (a6 != makesym(atom___)) goto replace__clause_9_19;
 replace__clause_9_16:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_clause_4)) goto replace__clause_9_19;
  x0 = arg(a2, 2);
 replace__clause_9_17:
  if (isref(x0)) goto replace__clause_9_18;
  gblt_pfunctor(x0,x1,replace__clause_9_19);
  gblt_arity(x0,x2,replace__clause_9_19);
  x3 = makeint(0L);
  gblt_greater(x2,x3,replace__clause_9_19);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = makeint(3L);
  allocp[3] = x4 = makeref(&allocp[3]);
  allocp[4] = x5 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[8] = makeint(1L);
  allocp[9] = a2;
  allocp[10] = x6 = makeref(&allocp[10]);
  allocp[11] = x4;
  allocp[12] = makesym(functor_goal_4);
  x8 = arg(a5, 0);
  allocp[13] = x8;
  allocp[14] = makesym(atom___);
  x9 = arg(a5, 1);
  allocp[15] = x9;
  x10 = arg(a5, 2);
  allocp[16] = x10;
  x7 = makefunctor(&allocp[12]);
  allocp[17] = (q)(struct goalrec*)&allocp[6];
  allocp[18] = (q)(&predicate_direct__call_xreplace__bodys_7);
  allocp[19] = a0;
  allocp[20] = x2;
  allocp[21] = x0;
  allocp[22] = x5;
  allocp[23] = x7;
  allocp[24] = x11 = makeref(&allocp[24]);
  allocp[25] = a8;
  allocp[26] = makesym(functor_goal_4);
  x13 = arg(a4, 0);
  allocp[27] = x13;
  allocp[28] = makesym(atom___);
  x14 = arg(a4, 1);
  allocp[29] = x14;
  x15 = arg(a4, 2);
  allocp[30] = x15;
  x12 = makefunctor(&allocp[26]);
  x16 = arg(a2, 0);
  a2 = x6;
  a3 = x12;
  a4 = a1;
  a5 = x11;
  a6 = a7;
  a1 = x16;
  qp = (struct goalrec*)&allocp[17];
  allocp += 31;
  execute(replace__head_7_0);
  goto replace__head_7_ext_interrupt;
 replace__clause_9_18:
  deref_and_jump(x0,replace__clause_9_17);
  *reasonp++ =  x0;
  goto replace__clause_9_19;
 case VARREF:
  deref_and_jump(a2,replace__clause_9_16);
  *reasonp++ =  a2;
  goto replace__clause_9_19;
  };
  goto replace__clause_9_19;
 case VARREF:
  deref_and_jump(a6,replace__clause_9_15);
  *reasonp++ =  a6;
  goto replace__clause_9_19;
  };
  goto replace__clause_9_19;
 case VARREF:
  deref_and_jump(a5,replace__clause_9_14);
  *reasonp++ =  a5;
  goto replace__clause_9_19;
  };
  goto replace__clause_9_19;
  };
  goto replace__clause_9_19;
 case VARREF:
  deref_and_jump(a4,replace__clause_9_1);
  *reasonp++ =  a4;
  goto replace__clause_9_19;
  };
  goto replace__clause_9_19;
 replace__clause_9_19:
  otherwise(replace__clause_9_interrupt);
 replace__clause_9_20:
  switch (ptagof(a4)) {
 case FUNCTOR:
  if (functor_of(a4) != makesym(functor_goal_4)) goto replace__clause_9_33;
  x0 = arg(a4, 0);
 replace__clause_9_21:
  if (isref(x0)) goto replace__clause_9_32;
 replace__clause_9_22:
  if (isref(x0)) goto replace__clause_9_31;
  if_not_equal(x0, a0, replace__clause_9_33);
  x1 = arg(a4, 1);
 replace__clause_9_23:
  if (isref(x1)) goto replace__clause_9_30;
 replace__clause_9_24:
  if (isref(x1)) goto replace__clause_9_29;
  if_not_equal(x1, a1, replace__clause_9_33);
 replace__clause_9_25:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_clause_4)) goto replace__clause_9_33;
 replace__clause_9_26:
  switch (ptagof(a5)) {
 case FUNCTOR:
  if (functor_of(a5) != makesym(functor_goal_7)) goto replace__clause_9_33;
  x2 = arg(a5, 3);
 replace__clause_9_27:
  if (isref(x2)) goto replace__clause_9_28;
  x3 = makesym(atom_report__measure);
  gblt_diff(x2,x3,replace__clause_9_33);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = makeint(3L);
  allocp[3] = x4 = makeref(&allocp[3]);
  allocp[4] = x5 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[8] = makeint(1L);
  allocp[9] = a2;
  allocp[10] = x6 = makeref(&allocp[10]);
  allocp[11] = x4;
  allocp[12] = (q)(struct goalrec*)&allocp[6];
  allocp[13] = (q)(&predicate_functor_xinsert__arg_4);
  allocp[14] = x7 = makeref(&allocp[14]);
  x8 = arg(a2, 2);
  allocp[15] = x8;
  allocp[16] = x9 = makeref(&allocp[16]);
  allocp[17] = x5;
  allocp[18] = (q)(struct goalrec*)&allocp[12];
  allocp[19] = (q)(&predicate_direct__call_xcreate__newgoal_4);
  x10 = arg(a5, 4);
  allocp[20] = x10;
  allocp[21] = a6;
  allocp[22] = x11 = makeref(&allocp[22]);
  allocp[23] = x9;
  allocp[24] = makesym(functor_goal_4);
  allocp[25] = a0;
  allocp[26] = a1;
  x13 = arg(a4, 2);
  allocp[27] = x13;
  x14 = arg(a4, 3);
  allocp[28] = x14;
  x12 = makefunctor(&allocp[24]);
  allocp[29] = (q)(struct goalrec*)&allocp[18];
  allocp[30] = (q)(&predicate_direct__call_xreplace__head_7);
  allocp[31] = a0;
  x15 = arg(a2, 0);
  allocp[32] = x15;
  allocp[33] = x6;
  allocp[34] = x12;
  allocp[35] = x10;
  allocp[36] = x11;
  allocp[37] = a7;
  allocp[38] = (q)(struct goalrec*)&allocp[29];
  allocp[39] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[40] = x8;
  allocp[41] = x16 = makeref(&allocp[41]);
  allocp[42] = x7;
  qp = (struct goalrec*)&allocp[38];
  allocp += 43;
  proceed();
 replace__clause_9_28:
  deref_and_jump(x2,replace__clause_9_27);
  *reasonp++ =  x2;
  goto replace__clause_9_33;
 case VARREF:
  deref_and_jump(a5,replace__clause_9_26);
  *reasonp++ =  a5;
  goto replace__clause_9_33;
  };
  goto replace__clause_9_33;
 case VARREF:
  deref_and_jump(a2,replace__clause_9_25);
  *reasonp++ =  a2;
  goto replace__clause_9_33;
  };
  goto replace__clause_9_33;
 replace__clause_9_29:
  deref_and_jump(x1,replace__clause_9_24);
  *reasonp++ =  x1;
  goto replace__clause_9_33;
 replace__clause_9_30:
  deref_and_jump(x1,replace__clause_9_23);
  *reasonp++ =  x1;
  goto replace__clause_9_33;
 replace__clause_9_31:
  deref_and_jump(x0,replace__clause_9_22);
  *reasonp++ =  x0;
  goto replace__clause_9_33;
 replace__clause_9_32:
  deref_and_jump(x0,replace__clause_9_21);
  *reasonp++ =  x0;
  goto replace__clause_9_33;
 case VARREF:
  deref_and_jump(a4,replace__clause_9_20);
  *reasonp++ =  a4;
  goto replace__clause_9_33;
  };
  goto replace__clause_9_33;
 replace__clause_9_33:
 replace__clause_9_34:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_clause_4)) goto replace__clause_9_46;
 replace__clause_9_35:
  switch (ptagof(a5)) {
 case FUNCTOR:
  if (functor_of(a5) != makesym(functor_goal_7)) goto replace__clause_9_46;
  x0 = arg(a5, 0);
 replace__clause_9_36:
  if (isref(x0)) goto replace__clause_9_45;
 replace__clause_9_37:
  if (isref(x0)) goto replace__clause_9_44;
  if_not_equal(x0, a0, replace__clause_9_46);
  x1 = arg(a5, 1);
 replace__clause_9_38:
  if (isref(x1)) goto replace__clause_9_43;
 replace__clause_9_39:
  if (isref(x1)) goto replace__clause_9_42;
  if_not_equal(x1, a1, replace__clause_9_46);
  x2 = arg(a5, 3);
 replace__clause_9_40:
  if (isref(x2)) goto replace__clause_9_41;
  x3 = makesym(atom_report__measure);
  gblt_diff(x2,x3,replace__clause_9_46);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = makeint(3L);
  allocp[3] = a2;
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_direct__call_xcreate__newbodys_3);
  x5 = arg(a2, 2);
  allocp[8] = x5;
  allocp[9] = x4;
  allocp[10] = a5;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[13] = x5;
  allocp[14] = x6 = makeref(&allocp[14]);
  allocp[15] = x7 = makeref(&allocp[15]);
  qp = (struct goalrec*)&allocp[11];
  allocp += 16;
  proceed();
 replace__clause_9_41:
  deref_and_jump(x2,replace__clause_9_40);
  *reasonp++ =  x2;
  goto replace__clause_9_46;
 replace__clause_9_42:
  deref_and_jump(x1,replace__clause_9_39);
  *reasonp++ =  x1;
  goto replace__clause_9_46;
 replace__clause_9_43:
  deref_and_jump(x1,replace__clause_9_38);
  *reasonp++ =  x1;
  goto replace__clause_9_46;
 replace__clause_9_44:
  deref_and_jump(x0,replace__clause_9_37);
  *reasonp++ =  x0;
  goto replace__clause_9_46;
 replace__clause_9_45:
  deref_and_jump(x0,replace__clause_9_36);
  *reasonp++ =  x0;
  goto replace__clause_9_46;
 case VARREF:
  deref_and_jump(a5,replace__clause_9_35);
  *reasonp++ =  a5;
  goto replace__clause_9_46;
  };
  goto replace__clause_9_46;
 case VARREF:
  deref_and_jump(a2,replace__clause_9_34);
  *reasonp++ =  a2;
  goto replace__clause_9_46;
  };
  goto replace__clause_9_46;
 replace__clause_9_46:
  otherwise(replace__clause_9_interrupt);
 replace__clause_9_47:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_clause_4)) goto replace__clause_9_53;
  x0 = arg(a2, 2);
 replace__clause_9_48:
  if (isref(x0)) goto replace__clause_9_52;
  gblt_pfunctor(x0,x1,replace__clause_9_53);
  gblt_arity(x0,x2,replace__clause_9_53);
  x3 = makeint(0L);
  gblt_greater(x2,x3,replace__clause_9_53);
 replace__clause_9_49:
  switch (ptagof(a5)) {
 case FUNCTOR:
  if (functor_of(a5) != makesym(functor_goal_7)) goto replace__clause_9_53;
  x4 = arg(a5, 3);
 replace__clause_9_50:
  if (isref(x4)) goto replace__clause_9_51;
  x5 = makesym(atom_report__measure);
  gblt_diff(x4,x5,replace__clause_9_53);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = makeint(3L);
  allocp[3] = x6 = makeref(&allocp[3]);
  allocp[4] = x7 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[8] = makeint(1L);
  allocp[9] = a2;
  allocp[10] = x8 = makeref(&allocp[10]);
  allocp[11] = x6;
  allocp[12] = (q)(struct goalrec*)&allocp[6];
  allocp[13] = (q)(&predicate_direct__call_xreplace__bodys_7);
  allocp[14] = a0;
  allocp[15] = x2;
  allocp[16] = x0;
  allocp[17] = x7;
  allocp[18] = a4;
  allocp[19] = x9 = makeref(&allocp[19]);
  allocp[20] = a8;
  a1 = arg(a2, 0);
  a2 = x8;
  a3 = a4;
  a4 = arg(a5, 4);
  a5 = x9;
  a6 = a7;
  qp = (struct goalrec*)&allocp[12];
  allocp += 21;
  execute(replace__head_7_0);
  goto replace__head_7_ext_interrupt;
 replace__clause_9_51:
  deref_and_jump(x4,replace__clause_9_50);
  *reasonp++ =  x4;
  goto replace__clause_9_53;
 case VARREF:
  deref_and_jump(a5,replace__clause_9_49);
  *reasonp++ =  a5;
  goto replace__clause_9_53;
  };
  goto replace__clause_9_53;
 replace__clause_9_52:
  deref_and_jump(x0,replace__clause_9_48);
  *reasonp++ =  x0;
  goto replace__clause_9_53;
 case VARREF:
  deref_and_jump(a2,replace__clause_9_47);
  *reasonp++ =  a2;
  goto replace__clause_9_53;
  };
  goto replace__clause_9_53;
 replace__clause_9_53:
  otherwise(replace__clause_9_interrupt);
  unify(a3, a2);
  proceed();
 replace__clause_9_ext_interrupt:
  reasonp = 0l;
 replace__clause_9_interrupt:
  goto interrupt_9;
 }

 replace__head_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 replace__head_7_clear_reason:
  reasonp = reasons;
 replace__head_7_0:
 replace__head_7_1:
  switch (ptagof(a3)) {
 case FUNCTOR:
  if (functor_of(a3) != makesym(functor_goal_4)) goto replace__head_7_6;
  x0 = arg(a3, 0);
 replace__head_7_2:
  if (isref(x0)) goto replace__head_7_5;
 replace__head_7_3:
  if (isref(x0)) goto replace__head_7_4;
  if_not_equal(x0, a0, replace__head_7_6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_parse__uty_xencode__goal_4);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = a2;
  allocp[6] = makesym(functor_goal_4);
  allocp[7] = a0;
  x5 = arg(a3, 1);
  allocp[8] = x5;
  x6 = arg(a3, 2);
  allocp[9] = x6;
  x7 = arg(a3, 3);
  allocp[10] = x7;
  x4 = makefunctor(&allocp[6]);
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_direct__call_xreplace__head2_6);
  allocp[13] = a6;
  allocp[14] = x8 = makeref(&allocp[14]);
  allocp[15] = x1;
  allocp[16] = x4;
  allocp[17] = a4;
  allocp[18] = a5;
  allocp[19] = (q)(struct goalrec*)&allocp[11];
  allocp[20] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[21] = x8;
  allocp[22] = x9 = makeref(&allocp[22]);
  allocp[23] = x10 = makeref(&allocp[23]);
  allocp[24] = (q)(struct goalrec*)&allocp[19];
  allocp[25] = (q)(&predicate_parse__uty_xdecode__goal_4);
  allocp[26] = a1;
  allocp[27] = x8;
  allocp[28] = x2;
  allocp[29] = x3;
  qp = (struct goalrec*)&allocp[24];
  allocp += 30;
  proceed();
 replace__head_7_4:
  deref_and_jump(x0,replace__head_7_3);
  *reasonp++ =  x0;
  goto replace__head_7_6;
 replace__head_7_5:
  deref_and_jump(x0,replace__head_7_2);
  *reasonp++ =  x0;
  goto replace__head_7_6;
 case VARREF:
  deref_and_jump(a3,replace__head_7_1);
  *reasonp++ =  a3;
  goto replace__head_7_6;
  };
  goto replace__head_7_6;
 replace__head_7_6:
  otherwise(replace__head_7_interrupt);
  unify(a2, a1);
  proceed();
 replace__head_7_ext_interrupt:
  reasonp = 0l;
 replace__head_7_interrupt:
  toppred = &predicate_direct__call_xreplace__head_7;
  goto interrupt_7;
 }

 remake__functor_3_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  qp = qp->next;
 remake__functor_3_clear_reason:
  reasonp = reasons;
 remake__functor_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xappend__variables_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a1;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = makeint(1L);
  allocp[10] = x0;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_direct__call_xremake__args_4);
  allocp[13] = x2;
  allocp[14] = a0;
  allocp[15] = x3 = makeref(&allocp[15]);
  allocp[16] = x1;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_direct__call_xrename_4);
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = makefunctor(&string_const_0);
  allocp[21] = x3;
  allocp[22] = a1;
  allocp[23] = (q)(struct goalrec*)&allocp[17];
  allocp[24] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[25] = a0;
  allocp[26] = x4;
  allocp[27] = x2;
  qp = (struct goalrec*)&allocp[23];
  allocp += 28;
  proceed();
 remake__functor_3_ext_interrupt:
  reasonp = 0l;
 remake__functor_3_interrupt:
  toppred = &predicate_direct__call_xremake__functor_3;
  goto interrupt_3;
 }

 rename_4_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 rename_4_clear_reason:
  reasonp = reasons;
 rename_4_0:
 rename_4_1:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != NILATOM) goto rename_4_2;
  unify(a2, a0);
  proceed();
 case VARREF:
  deref_and_jump(a3,rename_4_1);
  *reasonp++ =  a3;
  goto rename_4_2;
  };
  goto rename_4_2;
 rename_4_2:
  otherwise(rename_4_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_atom__table_xmake__atom_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a2;
  allocp[4] = makesym(functor_join_2);
  allocp[5] = a1;
  allocp[6] = x0;
  x1 = makefunctor(&allocp[4]);
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_generic_xgeneric_2);
  allocp[9] = x1;
  allocp[10] = x2 = makeref(&allocp[10]);
  allocp[11] = (q)(struct goalrec*)&allocp[7];
  allocp[12] = (q)(&predicate_atom__table_xget__atom__string_2);
  allocp[13] = a0;
  allocp[14] = x2;
  qp = (struct goalrec*)&allocp[11];
  allocp += 15;
  proceed();
 rename_4_ext_interrupt:
  reasonp = 0l;
 rename_4_interrupt:
  toppred = &predicate_direct__call_xrename_4;
  goto interrupt_4;
 }

 remake__args_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 remake__args_4_clear_reason:
  reasonp = reasons;
 remake__args_4_0:
 remake__args_4_1:
  if (!isint(a0)) goto remake__args_4_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,remake__args_4_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xremake__args_4);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x1;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_functor_xinsert__arg_4);
  allocp[13] = makeint(1L);
  allocp[14] = a2;
  allocp[15] = x3 = makeref(&allocp[15]);
  allocp[16] = x2;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_functor__table_xarg_3);
  allocp[19] = a0;
  allocp[20] = a1;
  allocp[21] = x3;
  qp = (struct goalrec*)&allocp[17];
  allocp += 22;
  proceed();
 remake__args_4_2:
  if (a0 != makeint(0L)) goto remake__args_4_interrupt;
  unify(a3, a2);
  proceed();
 remake__args_4_3:
  if (!isref(a0)) goto remake__args_4_interrupt;
  deref_and_jump(a0,remake__args_4_1);
  *reasonp++ =  a0;
  goto remake__args_4_interrupt;
 remake__args_4_ext_interrupt:
  reasonp = 0l;
 remake__args_4_interrupt:
  goto interrupt_4;
 }

 replace__head2_6_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 replace__head2_6_clear_reason:
  reasonp = reasons;
 replace__head2_6_0:
 replace__head2_6_1:
  switch (ptagof(a3)) {
 case FUNCTOR:
  if (functor_of(a3) != makesym(functor_goal_4)) goto replace__head2_6_12;
 replace__head2_6_2:
  if (isref(a1)) goto replace__head2_6_11;
  gblt_pfunctor(a1,x0,replace__head2_6_12);
 replace__head2_6_3:
  if (isref(x0)) goto replace__head2_6_10;
 replace__head2_6_4:
  if (isref(x0)) goto replace__head2_6_9;
  x1 = arg(a3, 2);
  if_not_equal(x0, x1, replace__head2_6_12);
  gblt_arity(a1,x2,replace__head2_6_12);
 replace__head2_6_5:
  if (isref(x2)) goto replace__head2_6_8;
 replace__head2_6_6:
  if (isref(x2)) goto replace__head2_6_7;
  x3 = arg(a3, 3);
  if_not_equal(x2, x3, replace__head2_6_12);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xremake__functor_3);
  allocp[2] = a1;
  allocp[3] = a5;
  allocp[4] = a2;
  x4 = a4;
  a1 = a5;
  a2 = a0;
  a0 = x4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(create__newvar_3_clear_reason);
  goto create__newvar_3_ext_interrupt;
 replace__head2_6_7:
  deref_and_jump(x2,replace__head2_6_6);
  *reasonp++ =  x2;
  goto replace__head2_6_12;
 replace__head2_6_8:
  deref_and_jump(x2,replace__head2_6_5);
  *reasonp++ =  x2;
  goto replace__head2_6_12;
 replace__head2_6_9:
  deref_and_jump(x0,replace__head2_6_4);
  *reasonp++ =  x0;
  goto replace__head2_6_12;
 replace__head2_6_10:
  deref_and_jump(x0,replace__head2_6_3);
  *reasonp++ =  x0;
  goto replace__head2_6_12;
 replace__head2_6_11:
  deref_and_jump(a1,replace__head2_6_2);
  *reasonp++ =  a1;
  goto replace__head2_6_12;
 case VARREF:
  deref_and_jump(a3,replace__head2_6_1);
  *reasonp++ =  a3;
  goto replace__head2_6_12;
  };
  goto replace__head2_6_12;
 replace__head2_6_12:
  otherwise(replace__head2_6_interrupt);
  unify(a2, a1);
  x0 = NILATOM;
  unify_value(a5, x0);
  proceed();
 replace__head2_6_ext_interrupt:
  reasonp = 0l;
 replace__head2_6_interrupt:
  goto interrupt_6;
 }

 create__newgoal_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 create__newgoal_4_clear_reason:
  reasonp = reasons;
 create__newgoal_4_0:
 create__newgoal_4_1:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != NILATOM) goto create__newgoal_4_2;
  unify(a3, a1);
  proceed();
 case VARREF:
  deref_and_jump(a2,create__newgoal_4_1);
  *reasonp++ =  a2;
  goto create__newgoal_4_2;
  };
  goto create__newgoal_4_2;
 create__newgoal_4_2:
  otherwise(create__newgoal_4_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_parse__uty_xencode__goal_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_direct__call_xcreate__newgoal2_5);
  allocp[8] = makeint(1L);
  allocp[9] = a0;
  allocp[10] = x3 = makeref(&allocp[10]);
  allocp[11] = x0;
  allocp[12] = a2;
  allocp[13] = (q)(struct goalrec*)&allocp[6];
  allocp[14] = (q)(&predicate_parse__uty_xdecode__goal_4);
  allocp[15] = a1;
  allocp[16] = x3;
  allocp[17] = x1;
  allocp[18] = x2;
  qp = (struct goalrec*)&allocp[13];
  allocp += 19;
  proceed();
 create__newgoal_4_ext_interrupt:
  reasonp = 0l;
 create__newgoal_4_interrupt:
  goto interrupt_4;
 }

 create__newgoal2_5_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 create__newgoal2_5_clear_reason:
  reasonp = reasons;
 create__newgoal2_5_0:
 create__newgoal2_5_1:
  if (!isint(a0)) goto create__newgoal2_5_6;
 create__newgoal2_5_2:
  if (!isint(a1)) goto create__newgoal2_5_5;
  gblt_less_or_eq(a0,a1,create__newgoal2_5_4);
 create__newgoal2_5_3:
  switch (ptagof(a4)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xcreate__newgoal2_5);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a3;
  x2 = cdr_of(a4);
  allocp[6] = x2;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[9] = a0;
  allocp[10] = makeint(1L);
  allocp[11] = x0;
  allocp[12] = (q)(struct goalrec*)&allocp[7];
  allocp[13] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[14] = a0;
  allocp[15] = a2;
  x3 = car_of(a4);
  allocp[16] = x3;
  allocp[17] = x1;
  qp = (struct goalrec*)&allocp[12];
  allocp += 18;
  proceed();
 case VARREF:
  deref_and_jump(a4,create__newgoal2_5_3);
  *reasonp++ =  a4;
  goto create__newgoal2_5_4;
  };
  goto create__newgoal2_5_4;
 create__newgoal2_5_4:
  gblt_greater(a0,a1,create__newgoal2_5_interrupt);
  unify(a3, a2);
  proceed();
 create__newgoal2_5_5:
  if (!isref(a1)) goto create__newgoal2_5_interrupt;
  deref_and_jump(a1,create__newgoal2_5_2);
  *reasonp++ =  a1;
  goto create__newgoal2_5_interrupt;
 create__newgoal2_5_6:
  if (!isref(a0)) goto create__newgoal2_5_interrupt;
  deref_and_jump(a0,create__newgoal2_5_1);
  *reasonp++ =  a0;
  goto create__newgoal2_5_interrupt;
 create__newgoal2_5_ext_interrupt:
  reasonp = 0l;
 create__newgoal2_5_interrupt:
  goto interrupt_5;
 }

 create__newbodys_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17;
  a2 = qp->args[2];
  qp = qp->next;
 create__newbodys_3_clear_reason:
  reasonp = reasons;
 create__newbodys_3_0:
 create__newbodys_3_1:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_goal_7)) goto create__newbodys_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor_xdelete__arg_3);
  x0 = arg(a2, 2);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a1;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = a0;
  allocp[9] = x3 = makeref(&allocp[9]);
  allocp[10] = x1;
  allocp[11] = (q)(struct goalrec*)&allocp[5];
  allocp[12] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[13] = x0;
  allocp[14] = makeint(1L);
  allocp[15] = x2;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_parse__uty_xencode__goal_4);
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = x5 = makeref(&allocp[19]);
  allocp[20] = x6 = makeref(&allocp[20]);
  allocp[21] = x3;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_direct__call_xremake__functor_3);
  allocp[24] = x7 = makeref(&allocp[24]);
  allocp[25] = x8 = makeref(&allocp[25]);
  allocp[26] = x4;
  allocp[27] = (q)(struct goalrec*)&allocp[22];
  allocp[28] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[29] = x7;
  allocp[30] = x9 = makeref(&allocp[30]);
  allocp[31] = x10 = makeref(&allocp[31]);
  allocp[32] = (q)(struct goalrec*)&allocp[27];
  allocp[33] = (q)(&predicate_parse__uty_xdecode__goal_4);
  allocp[34] = x11 = makeref(&allocp[34]);
  allocp[35] = x7;
  allocp[36] = x5;
  allocp[37] = x6;
  allocp[38] = (q)(struct goalrec*)&allocp[32];
  allocp[39] = (q)(&predicate_functor__table_xarg_3);
  allocp[40] = x12 = makeref(&allocp[40]);
  allocp[41] = a0;
  allocp[42] = x11;
  allocp[43] = (q)(struct goalrec*)&allocp[38];
  allocp[44] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[45] = x0;
  allocp[46] = makeint(1L);
  allocp[47] = x12;
  allocp[48] = (q)(struct goalrec*)&allocp[43];
  allocp[49] = (q)(&predicate_direct__call_xget__vars_4);
  allocp[50] = makeint(1L);
  x13 = arg(a2, 4);
  allocp[51] = x13;
  allocp[52] = x14 = makeref(&allocp[52]);
  allocp[53] = x8;
  allocp[54] = (q)(struct goalrec*)&allocp[48];
  allocp[55] = (q)(&predicate_parse__uty_xdecode__goal_4);
  allocp[56] = x15 = makeref(&allocp[56]);
  allocp[57] = x14;
  allocp[58] = x16 = makeref(&allocp[58]);
  allocp[59] = x17 = makeref(&allocp[59]);
  allocp[60] = (q)(struct goalrec*)&allocp[54];
  allocp[61] = (q)(&predicate_functor__table_xarg_3);
  allocp[62] = x0;
  allocp[63] = a0;
  allocp[64] = x15;
  qp = (struct goalrec*)&allocp[60];
  allocp += 65;
  proceed();
 case VARREF:
  deref_and_jump(a2,create__newbodys_3_1);
  *reasonp++ =  a2;
  goto create__newbodys_3_interrupt;
  };
  goto create__newbodys_3_interrupt;
 create__newbodys_3_ext_interrupt:
  reasonp = 0l;
 create__newbodys_3_interrupt:
  goto interrupt_3;
 }

 create__newvar_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  qp = qp->next;
 create__newvar_3_clear_reason:
  reasonp = reasons;
 create__newvar_3_0:
 create__newvar_3_1:
  if (!isint(a0)) goto create__newvar_3_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,create__newvar_3_2);
  bblt_add_no_check_x(a0,a2,x1);
  allocp[0] = makesym(functor_variable_3);
  allocp[1] = x1;
  allocp[2] = makeint(-1L);
  allocp[3] = makesym(atom__3F);
  x2 = makefunctor(&allocp[0]);
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = x2;
  x3 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a1, x3);
  x5 = makeint(1L);
  bblt_sub_no_check(a0,x5,x6);
  a0 = x6;
  a1 = x4;
  execute(create__newvar_3_0);
  goto create__newvar_3_ext_interrupt;
 create__newvar_3_2:
  if (a0 != makeint(0L)) goto create__newvar_3_interrupt;
  x7 = NILATOM;
  unify_value(a1, x7);
  proceed();
 create__newvar_3_3:
  if (!isref(a0)) goto create__newvar_3_interrupt;
  deref_and_jump(a0,create__newvar_3_1);
  *reasonp++ =  a0;
  goto create__newvar_3_interrupt;
 create__newvar_3_ext_interrupt:
  reasonp = 0l;
 create__newvar_3_interrupt:
  toppred = &predicate_direct__call_xcreate__newvar_3;
  goto interrupt_3;
 }

 get__vars_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 get__vars_4_clear_reason:
  reasonp = reasons;
 get__vars_4_0:
 get__vars_4_1:
  if (!isint(a0)) goto get__vars_4_5;
 get__vars_4_2:
  if (!isint(a1)) goto get__vars_4_4;
  gblt_less_or_eq(a0,a1,get__vars_4_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xget__vars_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x0;
  allocp[11] = x1;
  allocp[12] = x3 = makeref(&allocp[12]);
  x2 = makecons(&allocp[11]);
  qp = (struct goalrec*)&allocp[6];
  allocp += 13;
  unify_value(a3, x2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = a0;
  allocp[3] = a2;
  allocp[4] = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 get__vars_4_3:
  gblt_greater(a0,a1,get__vars_4_interrupt);
  x0 = NILATOM;
  unify_value(a3, x0);
  proceed();
 get__vars_4_4:
  if (!isref(a1)) goto get__vars_4_interrupt;
  deref_and_jump(a1,get__vars_4_2);
  *reasonp++ =  a1;
  goto get__vars_4_interrupt;
 get__vars_4_5:
  if (!isref(a0)) goto get__vars_4_interrupt;
  deref_and_jump(a0,get__vars_4_1);
  *reasonp++ =  a0;
  goto get__vars_4_interrupt;
 get__vars_4_ext_interrupt:
  reasonp = 0l;
 get__vars_4_interrupt:
  goto interrupt_4;
 }

 append__variables_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 append__variables_4_clear_reason:
  reasonp = reasons;
 append__variables_4_0:
 append__variables_4_1:
  switch (ptagof(a3)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xappend__variables_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  x2 = cdr_of(a3);
  allocp[5] = x2;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x0;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_functor_xinsert__arg_4);
  allocp[13] = a0;
  allocp[14] = a1;
  x3 = car_of(a3);
  allocp[15] = x3;
  allocp[16] = x1;
  qp = (struct goalrec*)&allocp[11];
  allocp += 17;
  proceed();
 case ATOMIC:
  if (a3 != NILATOM) goto append__variables_4_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a3,append__variables_4_1);
  *reasonp++ =  a3;
  goto append__variables_4_interrupt;
  };
  goto append__variables_4_interrupt;
 append__variables_4_ext_interrupt:
  reasonp = 0l;
 append__variables_4_interrupt:
  goto interrupt_4;
 }

 replace__bodys_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 replace__bodys_7_clear_reason:
  reasonp = reasons;
 replace__bodys_7_0:
 replace__bodys_7_1:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (a5 != NILATOM) goto replace__bodys_7_2;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a5,replace__bodys_7_1);
  *reasonp++ =  a5;
  goto replace__bodys_7_2;
  };
  goto replace__bodys_7_2;
 replace__bodys_7_2:
  otherwise(replace__bodys_7_interrupt);
 replace__bodys_7_3:
  if (!isint(a1)) goto replace__bodys_7_5;
  x0 = makeint(0L);
  gblt_greater(a1,x0,replace__bodys_7_4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xreplace__bodys_7);
  allocp[2] = a0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[11] = a1;
  allocp[12] = makeint(1L);
  allocp[13] = x1;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[16] = a1;
  allocp[17] = a2;
  allocp[18] = x3 = makeref(&allocp[18]);
  allocp[19] = x2;
  allocp[20] = (q)(struct goalrec*)&allocp[14];
  allocp[21] = (q)(&predicate_parse__uty_xencode__goal_4);
  allocp[22] = x4 = makeref(&allocp[22]);
  allocp[23] = x5 = makeref(&allocp[23]);
  allocp[24] = x6 = makeref(&allocp[24]);
  allocp[25] = x3;
  allocp[26] = (q)(struct goalrec*)&allocp[20];
  allocp[27] = (q)(&predicate_direct__call_xreplace__body_6);
  allocp[28] = a0;
  allocp[29] = x7 = makeref(&allocp[29]);
  allocp[30] = x4;
  allocp[31] = a4;
  allocp[32] = a5;
  allocp[33] = a6;
  allocp[34] = (q)(struct goalrec*)&allocp[26];
  allocp[35] = (q)(&predicate_parse__uty_xdecode__goal_4);
  allocp[36] = x8 = makeref(&allocp[36]);
  allocp[37] = x7;
  allocp[38] = x5;
  allocp[39] = x6;
  allocp[40] = (q)(struct goalrec*)&allocp[34];
  allocp[41] = (q)(&predicate_functor__table_xarg_3);
  allocp[42] = a1;
  allocp[43] = a2;
  allocp[44] = x8;
  qp = (struct goalrec*)&allocp[40];
  allocp += 45;
  proceed();
 replace__bodys_7_4:
  if (a1 != makeint(0L)) goto replace__bodys_7_interrupt;
  unify(a3, a2);
  proceed();
 replace__bodys_7_5:
  if (!isref(a1)) goto replace__bodys_7_interrupt;
  deref_and_jump(a1,replace__bodys_7_3);
  *reasonp++ =  a1;
  goto replace__bodys_7_interrupt;
 replace__bodys_7_ext_interrupt:
  reasonp = 0l;
 replace__bodys_7_interrupt:
  goto interrupt_7;
 }

 replace__body_6_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 replace__body_6_clear_reason:
  reasonp = reasons;
 replace__body_6_0:
 replace__body_6_1:
  switch (ptagof(a3)) {
 case FUNCTOR:
  if (functor_of(a3) != makesym(functor_goal_4)) goto replace__body_6_16;
  x0 = arg(a3, 0);
 replace__body_6_2:
  if (isref(x0)) goto replace__body_6_15;
 replace__body_6_3:
  if (isref(x0)) goto replace__body_6_14;
  if_not_equal(x0, a0, replace__body_6_16);
 replace__body_6_4:
  if (isref(a1)) goto replace__body_6_13;
  gblt_pfunctor(a1,x1,replace__body_6_16);
 replace__body_6_5:
  if (isref(x1)) goto replace__body_6_12;
 replace__body_6_6:
  if (isref(x1)) goto replace__body_6_11;
  x2 = arg(a3, 2);
  if_not_equal(x1, x2, replace__body_6_16);
  gblt_arity(a1,x3,replace__body_6_16);
 replace__body_6_7:
  if (isref(x3)) goto replace__body_6_10;
 replace__body_6_8:
  if (isref(x3)) goto replace__body_6_9;
  x4 = arg(a3, 3);
  if_not_equal(x3, x4, replace__body_6_16);
  a0 = a1;
  a1 = a4;
  execute(remake__functor_3_clear_reason);
  goto remake__functor_3_ext_interrupt;
 replace__body_6_9:
  deref_and_jump(x3,replace__body_6_8);
  *reasonp++ =  x3;
  goto replace__body_6_16;
 replace__body_6_10:
  deref_and_jump(x3,replace__body_6_7);
  *reasonp++ =  x3;
  goto replace__body_6_16;
 replace__body_6_11:
  deref_and_jump(x1,replace__body_6_6);
  *reasonp++ =  x1;
  goto replace__body_6_16;
 replace__body_6_12:
  deref_and_jump(x1,replace__body_6_5);
  *reasonp++ =  x1;
  goto replace__body_6_16;
 replace__body_6_13:
  deref_and_jump(a1,replace__body_6_4);
  *reasonp++ =  a1;
  goto replace__body_6_16;
 replace__body_6_14:
  deref_and_jump(x0,replace__body_6_3);
  *reasonp++ =  x0;
  goto replace__body_6_16;
 replace__body_6_15:
  deref_and_jump(x0,replace__body_6_2);
  *reasonp++ =  x0;
  goto replace__body_6_16;
 case VARREF:
  deref_and_jump(a3,replace__body_6_1);
  *reasonp++ =  a3;
  goto replace__body_6_16;
  };
  goto replace__body_6_16;
 replace__body_6_16:
  otherwise(replace__body_6_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xreplace__body2_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a4;
  allocp[6] = makesym(functor_thru_3);
  allocp[7] = a0;
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = x3 = makeref(&allocp[9]);
  x1 = makefunctor(&allocp[6]);
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_list_xcheck__include_3);
  allocp[12] = x1;
  allocp[13] = a5;
  allocp[14] = x0;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[17] = a1;
  allocp[18] = x2;
  allocp[19] = x3;
  qp = (struct goalrec*)&allocp[15];
  allocp += 20;
  proceed();
 replace__body_6_ext_interrupt:
  reasonp = 0l;
 replace__body_6_interrupt:
  goto interrupt_6;
 }

 replace__body2_4_top: {
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 replace__body2_4_clear_reason:
  reasonp = reasons;
 replace__body2_4_0:
 replace__body2_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto replace__body2_4_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  a0 = a1;
  a1 = a3;
  execute(remake__functor_3_0);
  goto remake__functor_3_ext_interrupt;
 case symval(makesym(atom_no)):
  unify(a2, a1);
  proceed();
  };
  goto replace__body2_4_interrupt;
 case VARREF:
  deref_and_jump(a0,replace__body2_4_1);
  *reasonp++ =  a0;
  goto replace__body2_4_interrupt;
  };
  goto replace__body2_4_interrupt;
 replace__body2_4_ext_interrupt:
  reasonp = 0l;
 replace__body2_4_interrupt:
  goto interrupt_4;
 }

 get__max__vn_2_top: {
  q x0, x1;
  qp = qp->next;
 get__max__vn_2_clear_reason:
  reasonp = reasons;
 get__max__vn_2_0:
 get__max__vn_2_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_clause_4)) goto get__max__vn_2_2;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xget__max__goals_3);
  x0 = arg(a0, 2);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a1;
  a0 = arg(a0, 1);
  a1 = makeint(0L);
  a2 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(get__max__goals_3_0);
  goto get__max__goals_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,get__max__vn_2_1);
  *reasonp++ =  a0;
  goto get__max__vn_2_2;
  };
  goto get__max__vn_2_2;
 get__max__vn_2_2:
  otherwise(get__max__vn_2_interrupt);
  x0 = makeint(0L);
  unify_value(a1, x0);
  proceed();
 get__max__vn_2_ext_interrupt:
  reasonp = 0l;
 get__max__vn_2_interrupt:
  toppred = &predicate_direct__call_xget__max__vn_2;
  goto interrupt_2;
 }

 get__max__goals_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 get__max__goals_3_clear_reason:
  reasonp = reasons;
 get__max__goals_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xget__max__goals2_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[8] = a0;
  allocp[9] = x1 = makeref(&allocp[9]);
  allocp[10] = x0;
  qp = (struct goalrec*)&allocp[6];
  allocp += 11;
  proceed();
 get__max__goals_3_ext_interrupt:
  reasonp = 0l;
 get__max__goals_3_interrupt:
  toppred = &predicate_direct__call_xget__max__goals_3;
  goto interrupt_3;
 }

 get__max__goals2_4_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 get__max__goals2_4_clear_reason:
  reasonp = reasons;
 get__max__goals2_4_0:
 get__max__goals2_4_1:
  if (!isint(a0)) goto get__max__goals2_4_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,get__max__goals2_4_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xget__max__goals2_4);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x1;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_direct__call_xget__max__goal_3);
  allocp[13] = x3 = makeref(&allocp[13]);
  allocp[14] = a2;
  allocp[15] = x2;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_parse__uty_xdecode__goal_4);
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = x3;
  allocp[20] = x5 = makeref(&allocp[20]);
  allocp[21] = x6 = makeref(&allocp[21]);
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_functor__table_xarg_3);
  allocp[24] = a0;
  allocp[25] = a1;
  allocp[26] = x4;
  qp = (struct goalrec*)&allocp[22];
  allocp += 27;
  proceed();
 get__max__goals2_4_2:
  if (a0 != makeint(0L)) goto get__max__goals2_4_interrupt;
  unify(a3, a2);
  proceed();
 get__max__goals2_4_3:
  if (!isref(a0)) goto get__max__goals2_4_interrupt;
  deref_and_jump(a0,get__max__goals2_4_1);
  *reasonp++ =  a0;
  goto get__max__goals2_4_interrupt;
 get__max__goals2_4_ext_interrupt:
  reasonp = 0l;
 get__max__goals2_4_interrupt:
  goto interrupt_4;
 }

 get__max__goal_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 get__max__goal_3_clear_reason:
  reasonp = reasons;
 get__max__goal_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xget__max__goal2_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[8] = a0;
  allocp[9] = x1 = makeref(&allocp[9]);
  allocp[10] = x0;
  qp = (struct goalrec*)&allocp[6];
  allocp += 11;
  proceed();
 get__max__goal_3_ext_interrupt:
  reasonp = 0l;
 get__max__goal_3_interrupt:
  toppred = &predicate_direct__call_xget__max__goal_3;
  goto interrupt_3;
 }

 get__max__goal2_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 get__max__goal2_4_clear_reason:
  reasonp = reasons;
 get__max__goal2_4_0:
 get__max__goal2_4_1:
  if (!isint(a0)) goto get__max__goal2_4_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,get__max__goal2_4_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xget__max__goal2_4);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x1;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_direct__call_xget__max__arg_3);
  allocp[13] = x3 = makeref(&allocp[13]);
  allocp[14] = a2;
  allocp[15] = x2;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_functor__table_xarg_3);
  allocp[18] = a0;
  allocp[19] = a1;
  allocp[20] = x3;
  qp = (struct goalrec*)&allocp[16];
  allocp += 21;
  proceed();
 get__max__goal2_4_2:
  if (a0 != makeint(0L)) goto get__max__goal2_4_interrupt;
  unify(a3, a2);
  proceed();
 get__max__goal2_4_3:
  if (!isref(a0)) goto get__max__goal2_4_interrupt;
  deref_and_jump(a0,get__max__goal2_4_1);
  *reasonp++ =  a0;
  goto get__max__goal2_4_interrupt;
 get__max__goal2_4_ext_interrupt:
  reasonp = 0l;
 get__max__goal2_4_interrupt:
  goto interrupt_4;
 }

 get__max__arg_3_top: {
  q x0;
  a2 = qp->args[2];
  qp = qp->next;
 get__max__arg_3_clear_reason:
  reasonp = reasons;
 get__max__arg_3_0:
 get__max__arg_3_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_variable_3)) goto get__max__arg_3_2;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_uty_xmax_3);
  allocp[2] = a1;
  x0 = arg(a0, 0);
  allocp[3] = x0;
  allocp[4] = a2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case VARREF:
  deref_and_jump(a0,get__max__arg_3_1);
  *reasonp++ =  a0;
  goto get__max__arg_3_2;
  };
  goto get__max__arg_3_2;
 get__max__arg_3_2:
  otherwise(get__max__arg_3_interrupt);
  execute(get__max__goal_3_0);
  goto get__max__goal_3_ext_interrupt;
 get__max__arg_3_ext_interrupt:
  reasonp = 0l;
 get__max__arg_3_interrupt:
  goto interrupt_3;
 }

 remove__dummy_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  qp = qp->next;
 remove__dummy_2_clear_reason:
  reasonp = reasons;
 remove__dummy_2_0:
 remove__dummy_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 remove__dummy_2_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto remove__dummy_2_interrupt;
  allocp[0] = makesym(functor_module_2);
  x2 = arg(x0, 0);
  allocp[1] = x2;
  allocp[2] = x3 = makeref(&allocp[2]);
  x1 = makefunctor(&allocp[0]);
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = x1;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a1, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xremove__dummy_2);
  x6 = cdr_of(a0);
  allocp[2] = x6;
  allocp[3] = x5;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_direct__call_xremove__dummy__clauses_3);
  allocp[6] = x7 = makeref(&allocp[6]);
  x8 = arg(x0, 1);
  allocp[7] = x8;
  allocp[8] = x3;
  allocp[9] = (q)(struct goalrec*)&allocp[4];
  allocp[10] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[11] = x8;
  allocp[12] = x9 = makeref(&allocp[12]);
  allocp[13] = x7;
  qp = (struct goalrec*)&allocp[9];
  allocp += 14;
  proceed();
 case VARREF:
  deref_and_jump(x0,remove__dummy_2_2);
  *reasonp++ =  x0;
  goto remove__dummy_2_interrupt;
  };
  goto remove__dummy_2_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto remove__dummy_2_interrupt;
  unify_value(a1, a0);
  proceed();
 case VARREF:
  deref_and_jump(a0,remove__dummy_2_1);
  *reasonp++ =  a0;
  goto remove__dummy_2_interrupt;
  };
  goto remove__dummy_2_interrupt;
 remove__dummy_2_ext_interrupt:
  reasonp = 0l;
 remove__dummy_2_interrupt:
  goto interrupt_2;
 }

 remove__dummy__clauses_3_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  qp = qp->next;
 remove__dummy__clauses_3_clear_reason:
  reasonp = reasons;
 remove__dummy__clauses_3_0:
 remove__dummy__clauses_3_1:
  if (!isint(a0)) goto remove__dummy__clauses_3_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,remove__dummy__clauses_3_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_direct__call_xremove__dummy__clauses_3);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[7] = a0;
  allocp[8] = makeint(1L);
  allocp[9] = x1;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[12] = a0;
  allocp[13] = a1;
  allocp[14] = x3 = makeref(&allocp[14]);
  allocp[15] = x2;
  allocp[16] = (q)(struct goalrec*)&allocp[10];
  allocp[17] = (q)(&predicate_direct__call_xremove__dummy__clause_2);
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = x3;
  allocp[20] = (q)(struct goalrec*)&allocp[16];
  allocp[21] = (q)(&predicate_functor__table_xarg_3);
  allocp[22] = a0;
  allocp[23] = a1;
  allocp[24] = x4;
  qp = (struct goalrec*)&allocp[20];
  allocp += 25;
  proceed();
 remove__dummy__clauses_3_2:
  if (a0 != makeint(0L)) goto remove__dummy__clauses_3_interrupt;
  unify(a2, a1);
  proceed();
 remove__dummy__clauses_3_3:
  if (!isref(a0)) goto remove__dummy__clauses_3_interrupt;
  deref_and_jump(a0,remove__dummy__clauses_3_1);
  *reasonp++ =  a0;
  goto remove__dummy__clauses_3_interrupt;
 remove__dummy__clauses_3_ext_interrupt:
  reasonp = 0l;
 remove__dummy__clauses_3_interrupt:
  goto interrupt_3;
 }

 remove__dummy__clause_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  qp = qp->next;
 remove__dummy__clause_2_clear_reason:
  reasonp = reasons;
 remove__dummy__clause_2_0:
 remove__dummy__clause_2_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_clause_4)) goto remove__dummy__clause_2_4;
  x0 = arg(a0, 2);
 remove__dummy__clause_2_2:
  if (isref(x0)) goto remove__dummy__clause_2_3;
  gblt_pfunctor(x0,x1,remove__dummy__clause_2_4);
  gblt_arity(x0,x2,remove__dummy__clause_2_4);
  x3 = makeint(0L);
  gblt_greater(x2,x3,remove__dummy__clause_2_4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = makeint(3L);
  allocp[3] = a0;
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = a1;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_direct__call_xremove__dummy__bodys_4);
  allocp[8] = x5 = makeref(&allocp[8]);
  allocp[9] = x2;
  allocp[10] = x0;
  allocp[11] = x4;
  allocp[12] = (q)(struct goalrec*)&allocp[6];
  allocp[13] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[14] = x6 = makeref(&allocp[14]);
  allocp[15] = x5;
  allocp[16] = x7 = makeref(&allocp[16]);
  allocp[17] = (q)(struct goalrec*)&allocp[12];
  allocp[18] = (q)(&predicate_parse__uty_xdecode__goal_4);
  allocp[19] = x8 = makeref(&allocp[19]);
  allocp[20] = x6;
  allocp[21] = x9 = makeref(&allocp[21]);
  allocp[22] = x10 = makeref(&allocp[22]);
  allocp[23] = (q)(struct goalrec*)&allocp[17];
  allocp[24] = (q)(&predicate_functor__table_xarg_3);
  allocp[25] = x2;
  allocp[26] = x0;
  allocp[27] = x8;
  qp = (struct goalrec*)&allocp[23];
  allocp += 28;
  proceed();
 remove__dummy__clause_2_3:
  deref_and_jump(x0,remove__dummy__clause_2_2);
  *reasonp++ =  x0;
  goto remove__dummy__clause_2_4;
 case VARREF:
  deref_and_jump(a0,remove__dummy__clause_2_1);
  *reasonp++ =  a0;
  goto remove__dummy__clause_2_4;
  };
  goto remove__dummy__clause_2_4;
 remove__dummy__clause_2_4:
  otherwise(remove__dummy__clause_2_interrupt);
  unify(a1, a0);
  proceed();
 remove__dummy__clause_2_ext_interrupt:
  reasonp = 0l;
 remove__dummy__clause_2_interrupt:
  goto interrupt_2;
 }

 remove__dummy__bodys_4_top: {
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 remove__dummy__bodys_4_clear_reason:
  reasonp = reasons;
 remove__dummy__bodys_4_0:
 remove__dummy__bodys_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_dummy)) goto remove__dummy__bodys_4_2;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor_xdelete__arg_3);
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case VARREF:
  deref_and_jump(a0,remove__dummy__bodys_4_1);
  *reasonp++ =  a0;
  goto remove__dummy__bodys_4_2;
  };
  goto remove__dummy__bodys_4_2;
 remove__dummy__bodys_4_2:
  otherwise(remove__dummy__bodys_4_interrupt);
  unify(a3, a2);
  proceed();
 remove__dummy__bodys_4_ext_interrupt:
  reasonp = 0l;
 remove__dummy__bodys_4_interrupt:
  goto interrupt_4;
 }
 interrupt_13:
  allocp[14] = a12;
 interrupt_12:
  allocp[13] = a11;
 interrupt_11:
  allocp[12] = a10;
 interrupt_10:
  allocp[11] = a9;
 interrupt_9:
  allocp[10] = a8;
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_direct__call);
}
