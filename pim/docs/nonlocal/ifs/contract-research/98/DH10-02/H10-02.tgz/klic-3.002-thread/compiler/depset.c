/* Compiled by KLIC compiler version 3.002 (Wed Sep 17 15:37:13 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_depset();
Const struct predicate predicate_depset_xor__depset_3 =
   { module_depset, 0, 3 };
Const struct predicate predicate_depset_xor__depset2_3 =
   { module_depset, 1, 3 };
Const struct predicate predicate_depset_xmake__nest_5 =
   { module_depset, 2, 5 };
Const struct predicate predicate_depset_xcheck__nest_3 =
   { module_depset, 3, 3 };
Const struct predicate predicate_depset_xmake__nest1_5 =
   { module_depset, 4, 5 };
Const struct predicate predicate_depset_xmerge__depset_3 =
   { module_depset, 5, 3 };
Const struct predicate predicate_depset_xmerge__dg_3 =
   { module_depset, 6, 3 };
Const struct predicate predicate_depset_xmerge__loopgoals_5 =
   { module_depset, 7, 5 };
Const struct predicate predicate_depset_xdd__arg_4 =
   { module_depset, 8, 4 };
Const struct predicate predicate_depset_xdd__arg2_7 =
   { module_depset, 9, 7 };
Const struct predicate predicate_depset_xdd__arg_7 =
   { module_depset, 10, 7 };
Const struct predicate predicate_depset_xdd__arg_8 =
   { module_depset, 11, 8 };
Const struct predicate predicate_depset_xget__var_11 =
   { module_depset, 12, 11 };
Const struct predicate predicate_depset_xget__var2_4 =
   { module_depset, 13, 4 };
Const struct predicate predicate_depset_xget__struct_8 =
   { module_depset, 14, 8 };
Const struct predicate predicate_depset_xcheck__include_3 =
   { module_depset, 15, 3 };
extern Const struct predicate predicate_list_xor__unique_3;
extern Const struct predicate predicate_list_xcheck__include_3;
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_typeset_xget_5;

module module_depset(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  q a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  switch_on_pred() {
    case_pred(0, or__depset_3_top);
    case_pred(1, or__depset2_3_top);
    case_pred(2, make__nest_5_top);
    case_pred(3, check__nest_3_top);
    case_pred(4, make__nest1_5_top);
    case_pred(5, merge__depset_3_top);
    case_pred(6, merge__dg_3_top);
    case_pred(7, merge__loopgoals_5_top);
    case_pred(8, dd__arg_4_top);
    case_pred(9, dd__arg2_7_top);
    case_pred(10, dd__arg_7_top);
    case_pred(11, dd__arg_8_top);
    case_pred(12, get__var_11_top);
    case_pred(13, get__var2_4_top);
    case_pred(14, get__struct_8_top);
    last_case_pred(15, check__include_3_top);
  }

 or__depset_3_top: {
  q x0, x1;
  qp = qp->next;
 or__depset_3_clear_reason:
  reasonp = reasons;
 or__depset_3_0:
 or__depset_3_1:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xor__depset_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  x1 = cdr_of(a1);
  allocp[3] = x1;
  allocp[4] = a2;
  a1 = car_of(a1);
  a2 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(or__depset2_3_0);
  goto or__depset2_3_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto or__depset_3_interrupt;
  unify(a2, a0);
  proceed();
 case VARREF:
  deref_and_jump(a1,or__depset_3_1);
  *reasonp++ =  a1;
  goto or__depset_3_interrupt;
  };
  goto or__depset_3_interrupt;
 or__depset_3_ext_interrupt:
  reasonp = 0l;
 or__depset_3_interrupt:
  toppred = &predicate_depset_xor__depset_3;
  goto interrupt_3;
 }

 or__depset2_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  qp = qp->next;
 or__depset2_3_clear_reason:
  reasonp = reasons;
 or__depset2_3_0:
 or__depset2_3_1:
  switch (ptagof(a0)) {
 case CONS:
 or__depset2_3_2:
  switch (ptagof(a1)) {
 case FUNCTOR:
  switch (symval(functor_of(a1))) {
 case functor_goal_4:
  x0 = car_of(a0);
 or__depset2_3_3:
  if (isref(x0)) goto or__depset2_3_6;
 or__depset2_3_4:
  if (isref(x0)) goto or__depset2_3_5;
  if_not_equal(x0, a1, or__depset2_3_34);
  x2 = cdr_of(a0);
  allocp[0] = x2;
  allocp[1] = x0;
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x1);
  proceed();
 or__depset2_3_5:
  deref_and_jump(x0,or__depset2_3_4);
  *reasonp++ =  x0;
  goto or__depset2_3_34;
 or__depset2_3_6:
  deref_and_jump(x0,or__depset2_3_3);
  *reasonp++ =  x0;
  goto or__depset2_3_34;
 case functor_entry_3:
  x0 = car_of(a0);
 or__depset2_3_7:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_entry_3)) goto or__depset2_3_34;
  x1 = arg(x0, 0);
 or__depset2_3_8:
  if (isref(x1)) goto or__depset2_3_15;
 or__depset2_3_9:
  if (isref(x1)) goto or__depset2_3_14;
  x2 = arg(a1, 0);
  if_not_equal(x1, x2, or__depset2_3_34);
  x3 = arg(x0, 1);
 or__depset2_3_10:
  if (isref(x3)) goto or__depset2_3_13;
 or__depset2_3_11:
  if (isref(x3)) goto or__depset2_3_12;
  x4 = arg(a1, 1);
  if_not_equal(x3, x4, or__depset2_3_34);
  allocp[0] = makesym(functor_entry_3);
  allocp[1] = x2;
  allocp[2] = x4;
  allocp[3] = x6 = makeref(&allocp[3]);
  x5 = makefunctor(&allocp[0]);
  x8 = cdr_of(a0);
  allocp[4] = x8;
  allocp[5] = x5;
  x7 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a2, x7);
  a0 = arg(a1, 2);
  a1 = arg(x0, 2);
  a2 = x6;
  execute(or__depset_3_clear_reason);
  goto or__depset_3_ext_interrupt;
 or__depset2_3_12:
  deref_and_jump(x3,or__depset2_3_11);
  *reasonp++ =  x3;
  goto or__depset2_3_34;
 or__depset2_3_13:
  deref_and_jump(x3,or__depset2_3_10);
  *reasonp++ =  x3;
  goto or__depset2_3_34;
 or__depset2_3_14:
  deref_and_jump(x1,or__depset2_3_9);
  *reasonp++ =  x1;
  goto or__depset2_3_34;
 or__depset2_3_15:
  deref_and_jump(x1,or__depset2_3_8);
  *reasonp++ =  x1;
  goto or__depset2_3_34;
 case VARREF:
  deref_and_jump(x0,or__depset2_3_7);
  *reasonp++ =  x0;
  goto or__depset2_3_34;
  };
  goto or__depset2_3_34;
 case functor_recursive_3:
  x0 = car_of(a0);
 or__depset2_3_16:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_recursive_3)) goto or__depset2_3_34;
  x1 = arg(x0, 0);
 or__depset2_3_17:
  if (isref(x1)) goto or__depset2_3_24;
 or__depset2_3_18:
  if (isref(x1)) goto or__depset2_3_23;
  x2 = arg(a1, 0);
  if_not_equal(x1, x2, or__depset2_3_34);
  x3 = arg(x0, 1);
 or__depset2_3_19:
  if (isref(x3)) goto or__depset2_3_22;
 or__depset2_3_20:
  if (isref(x3)) goto or__depset2_3_21;
  x4 = arg(a1, 1);
  if_not_equal(x3, x4, or__depset2_3_34);
  allocp[0] = makesym(functor_recursive_3);
  allocp[1] = x2;
  allocp[2] = x4;
  allocp[3] = x6 = makeref(&allocp[3]);
  x5 = makefunctor(&allocp[0]);
  x8 = cdr_of(a0);
  allocp[4] = x8;
  allocp[5] = x5;
  x7 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a2, x7);
  a0 = arg(a1, 2);
  a1 = arg(x0, 2);
  a2 = x6;
  execute(or__depset_3_clear_reason);
  goto or__depset_3_ext_interrupt;
 or__depset2_3_21:
  deref_and_jump(x3,or__depset2_3_20);
  *reasonp++ =  x3;
  goto or__depset2_3_34;
 or__depset2_3_22:
  deref_and_jump(x3,or__depset2_3_19);
  *reasonp++ =  x3;
  goto or__depset2_3_34;
 or__depset2_3_23:
  deref_and_jump(x1,or__depset2_3_18);
  *reasonp++ =  x1;
  goto or__depset2_3_34;
 or__depset2_3_24:
  deref_and_jump(x1,or__depset2_3_17);
  *reasonp++ =  x1;
  goto or__depset2_3_34;
 case VARREF:
  deref_and_jump(x0,or__depset2_3_16);
  *reasonp++ =  x0;
  goto or__depset2_3_34;
  };
  goto or__depset2_3_34;
 case functor_shared_3:
  x0 = car_of(a0);
 or__depset2_3_25:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_shared_3)) goto or__depset2_3_34;
  x1 = arg(x0, 0);
 or__depset2_3_26:
  if (isref(x1)) goto or__depset2_3_33;
 or__depset2_3_27:
  if (isref(x1)) goto or__depset2_3_32;
  x2 = arg(a1, 0);
  if_not_equal(x1, x2, or__depset2_3_34);
  x3 = arg(x0, 1);
 or__depset2_3_28:
  if (isref(x3)) goto or__depset2_3_31;
 or__depset2_3_29:
  if (isref(x3)) goto or__depset2_3_30;
  x4 = arg(a1, 1);
  if_not_equal(x3, x4, or__depset2_3_34);
  allocp[0] = makesym(functor_shared_3);
  allocp[1] = x2;
  allocp[2] = x4;
  allocp[3] = x6 = makeref(&allocp[3]);
  x5 = makefunctor(&allocp[0]);
  x8 = cdr_of(a0);
  allocp[4] = x8;
  allocp[5] = x5;
  x7 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a2, x7);
  a0 = arg(a1, 2);
  a1 = arg(x0, 2);
  a2 = x6;
  execute(or__depset_3_clear_reason);
  goto or__depset_3_ext_interrupt;
 or__depset2_3_30:
  deref_and_jump(x3,or__depset2_3_29);
  *reasonp++ =  x3;
  goto or__depset2_3_34;
 or__depset2_3_31:
  deref_and_jump(x3,or__depset2_3_28);
  *reasonp++ =  x3;
  goto or__depset2_3_34;
 or__depset2_3_32:
  deref_and_jump(x1,or__depset2_3_27);
  *reasonp++ =  x1;
  goto or__depset2_3_34;
 or__depset2_3_33:
  deref_and_jump(x1,or__depset2_3_26);
  *reasonp++ =  x1;
  goto or__depset2_3_34;
 case VARREF:
  deref_and_jump(x0,or__depset2_3_25);
  *reasonp++ =  x0;
  goto or__depset2_3_34;
  };
  goto or__depset2_3_34;
  };
  goto or__depset2_3_34;
 case VARREF:
  deref_and_jump(a1,or__depset2_3_2);
  *reasonp++ =  a1;
  goto or__depset2_3_34;
  };
  goto or__depset2_3_34;
 case VARREF:
  deref_and_jump(a0,or__depset2_3_1);
  *reasonp++ =  a0;
  goto or__depset2_3_34;
  };
  goto or__depset2_3_34;
 or__depset2_3_34:
  otherwise(or__depset2_3_interrupt);
 or__depset2_3_35:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  a0 = cdr_of(a0);
  a2 = x1;
  execute(or__depset2_3_0);
  goto or__depset2_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto or__depset2_3_interrupt;
  allocp[0] = NILATOM;
  allocp[1] = a1;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,or__depset2_3_35);
  *reasonp++ =  a0;
  goto or__depset2_3_interrupt;
  };
  goto or__depset2_3_interrupt;
 or__depset2_3_ext_interrupt:
  reasonp = 0l;
 or__depset2_3_interrupt:
  toppred = &predicate_depset_xor__depset2_3;
  goto interrupt_3;
 }

 make__nest_5_top: {
  q x0, x1, x2, x3;
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 make__nest_5_clear_reason:
  reasonp = reasons;
 make__nest_5_0:
 make__nest_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto make__nest_5_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_entry)):
  allocp[0] = makesym(functor_entry_3);
  allocp[1] = a1;
  allocp[2] = a2;
  allocp[3] = x1 = makeref(&allocp[3]);
  x0 = makefunctor(&allocp[0]);
  allocp[4] = NILATOM;
  allocp[5] = x0;
  x2 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a4, x2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xcheck__nest_3);
  allocp[2] = a1;
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x1;
  a0 = a1;
  a1 = a2;
  a2 = a3;
  a3 = NILATOM;
  a4 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(make__nest1_5_0);
  goto make__nest1_5_ext_interrupt;
 case symval(makesym(atom_recursive)):
  allocp[0] = makesym(functor_recursive_3);
  allocp[1] = a1;
  allocp[2] = a2;
  allocp[3] = x1 = makeref(&allocp[3]);
  x0 = makefunctor(&allocp[0]);
  allocp[4] = NILATOM;
  allocp[5] = x0;
  x2 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a4, x2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xcheck__nest_3);
  allocp[2] = a1;
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x1;
  a0 = a1;
  a1 = a2;
  a2 = a3;
  a3 = NILATOM;
  a4 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(make__nest1_5_0);
  goto make__nest1_5_ext_interrupt;
 case symval(makesym(atom_shared)):
  allocp[0] = makesym(functor_shared_3);
  allocp[1] = a1;
  allocp[2] = a2;
  allocp[3] = x1 = makeref(&allocp[3]);
  x0 = makefunctor(&allocp[0]);
  allocp[4] = NILATOM;
  allocp[5] = x0;
  x2 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a4, x2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xcheck__nest_3);
  allocp[2] = a1;
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x1;
  a0 = a1;
  a1 = a2;
  a2 = a3;
  a3 = NILATOM;
  a4 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(make__nest1_5_0);
  goto make__nest1_5_ext_interrupt;
  };
  goto make__nest_5_interrupt;
 case VARREF:
  deref_and_jump(a0,make__nest_5_1);
  *reasonp++ =  a0;
  goto make__nest_5_interrupt;
  };
  goto make__nest_5_interrupt;
 make__nest_5_ext_interrupt:
  reasonp = 0l;
 make__nest_5_interrupt:
  goto interrupt_5;
 }

 check__nest_3_top: {
  q x0, x1, x2, x3, x4;
  qp = qp->next;
 check__nest_3_clear_reason:
  reasonp = reasons;
 check__nest_3_0:
 check__nest_3_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 check__nest_3_2:
  if (isref(x0)) goto check__nest_3_4;
  gblt_pfunctor(x0,x1,check__nest_3_5);
  gblt_arity(x0,x2,check__nest_3_5);
 check__nest_3_3:
  if (x2 != makeint(3L)) goto check__nest_3_5;
  x4 = makeint(1L);
  gblt_arg(x4,x0,x3,check__nest_3_5);
  a1 = cdr_of(a1);
  execute(check__nest_3_0);
  goto check__nest_3_ext_interrupt;
 check__nest_3_4:
  deref_and_jump(x0,check__nest_3_2);
  *reasonp++ =  x0;
  goto check__nest_3_5;
 case VARREF:
  deref_and_jump(a1,check__nest_3_1);
  *reasonp++ =  a1;
  goto check__nest_3_5;
  };
  goto check__nest_3_5;
 check__nest_3_5:
  otherwise(check__nest_3_interrupt);
 check__nest_3_6:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a1);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  a1 = cdr_of(a1);
  a2 = x1;
  execute(check__nest_3_0);
  goto check__nest_3_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto check__nest_3_interrupt;
  x0 = NILATOM;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,check__nest_3_6);
  *reasonp++ =  a1;
  goto check__nest_3_interrupt;
  };
  goto check__nest_3_interrupt;
 check__nest_3_ext_interrupt:
  reasonp = 0l;
 check__nest_3_interrupt:
  goto interrupt_3;
 }

 make__nest1_5_top: {
  q x0, x1, x2, x3, x4;
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 make__nest1_5_clear_reason:
  reasonp = reasons;
 make__nest1_5_0:
 make__nest1_5_1:
  switch (ptagof(a2)) {
 case CONS:
  x0 = car_of(a2);
 make__nest1_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_entry_3:
  x1 = arg(x0, 0);
 make__nest1_5_3:
  if (isref(x1)) goto make__nest1_5_10;
 make__nest1_5_4:
  if (isref(x1)) goto make__nest1_5_9;
  if_not_equal(x1, a0, make__nest1_5_27);
  x2 = arg(x0, 1);
 make__nest1_5_5:
  if (isref(x2)) goto make__nest1_5_8;
 make__nest1_5_6:
  if (isref(x2)) goto make__nest1_5_7;
  if_not_equal(x2, a1, make__nest1_5_27);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xmake__nest1_5);
  allocp[2] = a0;
  allocp[3] = a1;
  x3 = cdr_of(a2);
  allocp[4] = x3;
  allocp[5] = x4 = makeref(&allocp[5]);
  allocp[6] = a4;
  a0 = a3;
  a1 = arg(x0, 2);
  a2 = x4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(or__depset_3_clear_reason);
  goto or__depset_3_ext_interrupt;
 make__nest1_5_7:
  deref_and_jump(x2,make__nest1_5_6);
  *reasonp++ =  x2;
  goto make__nest1_5_27;
 make__nest1_5_8:
  deref_and_jump(x2,make__nest1_5_5);
  *reasonp++ =  x2;
  goto make__nest1_5_27;
 make__nest1_5_9:
  deref_and_jump(x1,make__nest1_5_4);
  *reasonp++ =  x1;
  goto make__nest1_5_27;
 make__nest1_5_10:
  deref_and_jump(x1,make__nest1_5_3);
  *reasonp++ =  x1;
  goto make__nest1_5_27;
 case functor_recursive_3:
  x1 = arg(x0, 0);
 make__nest1_5_11:
  if (isref(x1)) goto make__nest1_5_18;
 make__nest1_5_12:
  if (isref(x1)) goto make__nest1_5_17;
  if_not_equal(x1, a0, make__nest1_5_27);
  x2 = arg(x0, 1);
 make__nest1_5_13:
  if (isref(x2)) goto make__nest1_5_16;
 make__nest1_5_14:
  if (isref(x2)) goto make__nest1_5_15;
  if_not_equal(x2, a1, make__nest1_5_27);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xmake__nest1_5);
  allocp[2] = a0;
  allocp[3] = a1;
  x3 = cdr_of(a2);
  allocp[4] = x3;
  allocp[5] = x4 = makeref(&allocp[5]);
  allocp[6] = a4;
  a0 = a3;
  a1 = arg(x0, 2);
  a2 = x4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(or__depset_3_clear_reason);
  goto or__depset_3_ext_interrupt;
 make__nest1_5_15:
  deref_and_jump(x2,make__nest1_5_14);
  *reasonp++ =  x2;
  goto make__nest1_5_27;
 make__nest1_5_16:
  deref_and_jump(x2,make__nest1_5_13);
  *reasonp++ =  x2;
  goto make__nest1_5_27;
 make__nest1_5_17:
  deref_and_jump(x1,make__nest1_5_12);
  *reasonp++ =  x1;
  goto make__nest1_5_27;
 make__nest1_5_18:
  deref_and_jump(x1,make__nest1_5_11);
  *reasonp++ =  x1;
  goto make__nest1_5_27;
 case functor_shared_3:
  x1 = arg(x0, 0);
 make__nest1_5_19:
  if (isref(x1)) goto make__nest1_5_26;
 make__nest1_5_20:
  if (isref(x1)) goto make__nest1_5_25;
  if_not_equal(x1, a0, make__nest1_5_27);
  x2 = arg(x0, 1);
 make__nest1_5_21:
  if (isref(x2)) goto make__nest1_5_24;
 make__nest1_5_22:
  if (isref(x2)) goto make__nest1_5_23;
  if_not_equal(x2, a1, make__nest1_5_27);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xmake__nest1_5);
  allocp[2] = a0;
  allocp[3] = a1;
  x3 = cdr_of(a2);
  allocp[4] = x3;
  allocp[5] = x4 = makeref(&allocp[5]);
  allocp[6] = a4;
  a0 = a3;
  a1 = arg(x0, 2);
  a2 = x4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(or__depset_3_clear_reason);
  goto or__depset_3_ext_interrupt;
 make__nest1_5_23:
  deref_and_jump(x2,make__nest1_5_22);
  *reasonp++ =  x2;
  goto make__nest1_5_27;
 make__nest1_5_24:
  deref_and_jump(x2,make__nest1_5_21);
  *reasonp++ =  x2;
  goto make__nest1_5_27;
 make__nest1_5_25:
  deref_and_jump(x1,make__nest1_5_20);
  *reasonp++ =  x1;
  goto make__nest1_5_27;
 make__nest1_5_26:
  deref_and_jump(x1,make__nest1_5_19);
  *reasonp++ =  x1;
  goto make__nest1_5_27;
  };
  goto make__nest1_5_27;
 case VARREF:
  deref_and_jump(x0,make__nest1_5_2);
  *reasonp++ =  x0;
  goto make__nest1_5_27;
  };
  goto make__nest1_5_27;
 case VARREF:
  deref_and_jump(a2,make__nest1_5_1);
  *reasonp++ =  a2;
  goto make__nest1_5_27;
  };
  goto make__nest1_5_27;
 make__nest1_5_27:
  otherwise(make__nest1_5_interrupt);
 make__nest1_5_28:
  switch (ptagof(a2)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xmake__nest1_5);
  allocp[2] = a0;
  allocp[3] = a1;
  x0 = cdr_of(a2);
  allocp[4] = x0;
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = NILATOM;
  x3 = car_of(a2);
  allocp[8] = x3;
  x2 = makecons(&allocp[7]);
  a0 = a3;
  a1 = x2;
  a2 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 9;
  execute(or__depset_3_0);
  goto or__depset_3_ext_interrupt;
 case ATOMIC:
  if (a2 != NILATOM) goto make__nest1_5_interrupt;
  unify(a4, a3);
  proceed();
 case VARREF:
  deref_and_jump(a2,make__nest1_5_28);
  *reasonp++ =  a2;
  goto make__nest1_5_interrupt;
  };
  goto make__nest1_5_interrupt;
 make__nest1_5_ext_interrupt:
  reasonp = 0l;
 make__nest1_5_interrupt:
  toppred = &predicate_depset_xmake__nest1_5;
  goto interrupt_5;
 }

 merge__depset_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  qp = qp->next;
 merge__depset_3_clear_reason:
  reasonp = reasons;
 merge__depset_3_0:
 merge__depset_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 merge__depset_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_goal_4:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xmerge__depset_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = x3;
  allocp[6] = x0;
  x4 = makecons(&allocp[5]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  unify_value(a2, x4);
  a0 = x0;
  a2 = x2;
  execute(merge__dg_3_0);
  goto merge__dg_3_ext_interrupt;
 case functor_entry_3:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xmerge__depset_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = makesym(functor_entry_3);
  x5 = arg(x0, 0);
  allocp[6] = x5;
  x6 = arg(x0, 1);
  allocp[7] = x6;
  allocp[8] = x7 = makeref(&allocp[8]);
  x4 = makefunctor(&allocp[5]);
  allocp[9] = x3;
  allocp[10] = x4;
  x8 = makecons(&allocp[9]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 11;
  unify_value(a2, x8);
  a0 = arg(x0, 0);
  x9 = arg(x0, 2);
  a2 = x7;
  a3 = a1;
  a4 = x2;
  a1 = x9;
  execute(merge__loopgoals_5_0);
  goto merge__loopgoals_5_ext_interrupt;
 case functor_recursive_3:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xmerge__depset_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = makesym(functor_recursive_3);
  x5 = arg(x0, 0);
  allocp[6] = x5;
  x6 = arg(x0, 1);
  allocp[7] = x6;
  allocp[8] = x7 = makeref(&allocp[8]);
  x4 = makefunctor(&allocp[5]);
  allocp[9] = x3;
  allocp[10] = x4;
  x8 = makecons(&allocp[9]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 11;
  unify_value(a2, x8);
  a0 = arg(x0, 0);
  x9 = arg(x0, 2);
  a2 = x7;
  a3 = a1;
  a4 = x2;
  a1 = x9;
  execute(merge__loopgoals_5_0);
  goto merge__loopgoals_5_ext_interrupt;
 case functor_shared_3:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xmerge__depset_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = makesym(functor_shared_3);
  x5 = arg(x0, 0);
  allocp[6] = x5;
  x6 = arg(x0, 1);
  allocp[7] = x6;
  allocp[8] = x7 = makeref(&allocp[8]);
  x4 = makefunctor(&allocp[5]);
  allocp[9] = x3;
  allocp[10] = x4;
  x8 = makecons(&allocp[9]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 11;
  unify_value(a2, x8);
  a0 = arg(x0, 0);
  x9 = arg(x0, 2);
  a2 = x7;
  a3 = a1;
  a4 = x2;
  a1 = x9;
  execute(merge__loopgoals_5_0);
  goto merge__loopgoals_5_ext_interrupt;
  };
  goto merge__depset_3_interrupt;
 case VARREF:
  deref_and_jump(x0,merge__depset_3_2);
  *reasonp++ =  x0;
  goto merge__depset_3_interrupt;
  };
  goto merge__depset_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto merge__depset_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,merge__depset_3_1);
  *reasonp++ =  a0;
  goto merge__depset_3_interrupt;
  };
  goto merge__depset_3_interrupt;
 merge__depset_3_ext_interrupt:
  reasonp = 0l;
 merge__depset_3_interrupt:
  toppred = &predicate_depset_xmerge__depset_3;
  goto interrupt_3;
 }

 merge__dg_3_top: {
  q x0, x1, x2;
  qp = qp->next;
 merge__dg_3_clear_reason:
  reasonp = reasons;
 merge__dg_3_0:
 merge__dg_3_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 merge__dg_3_2:
  if (isref(x0)) goto merge__dg_3_5;
 merge__dg_3_3:
  if (isref(x0)) goto merge__dg_3_4;
  if_not_equal(x0, a0, merge__dg_3_6);
  a1 = cdr_of(a1);
  execute(merge__dg_3_clear_reason);
  goto merge__dg_3_ext_interrupt;
 merge__dg_3_4:
  deref_and_jump(x0,merge__dg_3_3);
  *reasonp++ =  x0;
  goto merge__dg_3_6;
 merge__dg_3_5:
  deref_and_jump(x0,merge__dg_3_2);
  *reasonp++ =  x0;
  goto merge__dg_3_6;
 case VARREF:
  deref_and_jump(a1,merge__dg_3_1);
  *reasonp++ =  a1;
  goto merge__dg_3_6;
  };
  goto merge__dg_3_6;
 merge__dg_3_6:
  otherwise(merge__dg_3_interrupt);
 merge__dg_3_7:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a1);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  a1 = cdr_of(a1);
  a2 = x1;
  execute(merge__dg_3_0);
  goto merge__dg_3_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto merge__dg_3_interrupt;
  x0 = NILATOM;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,merge__dg_3_7);
  *reasonp++ =  a1;
  goto merge__dg_3_interrupt;
  };
  goto merge__dg_3_interrupt;
 merge__dg_3_ext_interrupt:
  reasonp = 0l;
 merge__dg_3_interrupt:
  toppred = &predicate_depset_xmerge__dg_3;
  goto interrupt_3;
 }

 merge__loopgoals_5_top: {
  q x0, x1, x2, x3;
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 merge__loopgoals_5_clear_reason:
  reasonp = reasons;
 merge__loopgoals_5_0:
 merge__loopgoals_5_1:
  switch (ptagof(a3)) {
 case CONS:
  x0 = car_of(a3);
 merge__loopgoals_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_entry_3:
  x1 = arg(x0, 0);
 merge__loopgoals_5_3:
  if (isref(x1)) goto merge__loopgoals_5_6;
 merge__loopgoals_5_4:
  if (isref(x1)) goto merge__loopgoals_5_5;
  if_not_equal(x1, a0, merge__loopgoals_5_15);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xmerge__loopgoals_5);
  allocp[2] = a0;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  x3 = cdr_of(a3);
  allocp[5] = x3;
  allocp[6] = a4;
  a0 = a1;
  a1 = arg(x0, 2);
  a2 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(merge__depset_3_clear_reason);
  goto merge__depset_3_ext_interrupt;
 merge__loopgoals_5_5:
  deref_and_jump(x1,merge__loopgoals_5_4);
  *reasonp++ =  x1;
  goto merge__loopgoals_5_15;
 merge__loopgoals_5_6:
  deref_and_jump(x1,merge__loopgoals_5_3);
  *reasonp++ =  x1;
  goto merge__loopgoals_5_15;
 case functor_recursive_3:
  x1 = arg(x0, 0);
 merge__loopgoals_5_7:
  if (isref(x1)) goto merge__loopgoals_5_10;
 merge__loopgoals_5_8:
  if (isref(x1)) goto merge__loopgoals_5_9;
  if_not_equal(x1, a0, merge__loopgoals_5_15);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xmerge__loopgoals_5);
  allocp[2] = a0;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  x3 = cdr_of(a3);
  allocp[5] = x3;
  allocp[6] = a4;
  a0 = a1;
  a1 = arg(x0, 2);
  a2 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(merge__depset_3_clear_reason);
  goto merge__depset_3_ext_interrupt;
 merge__loopgoals_5_9:
  deref_and_jump(x1,merge__loopgoals_5_8);
  *reasonp++ =  x1;
  goto merge__loopgoals_5_15;
 merge__loopgoals_5_10:
  deref_and_jump(x1,merge__loopgoals_5_7);
  *reasonp++ =  x1;
  goto merge__loopgoals_5_15;
 case functor_shared_3:
  x1 = arg(x0, 0);
 merge__loopgoals_5_11:
  if (isref(x1)) goto merge__loopgoals_5_14;
 merge__loopgoals_5_12:
  if (isref(x1)) goto merge__loopgoals_5_13;
  if_not_equal(x1, a0, merge__loopgoals_5_15);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xmerge__loopgoals_5);
  allocp[2] = a0;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  x3 = cdr_of(a3);
  allocp[5] = x3;
  allocp[6] = a4;
  a0 = a1;
  a1 = arg(x0, 2);
  a2 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(merge__depset_3_clear_reason);
  goto merge__depset_3_ext_interrupt;
 merge__loopgoals_5_13:
  deref_and_jump(x1,merge__loopgoals_5_12);
  *reasonp++ =  x1;
  goto merge__loopgoals_5_15;
 merge__loopgoals_5_14:
  deref_and_jump(x1,merge__loopgoals_5_11);
  *reasonp++ =  x1;
  goto merge__loopgoals_5_15;
  };
  goto merge__loopgoals_5_15;
 case VARREF:
  deref_and_jump(x0,merge__loopgoals_5_2);
  *reasonp++ =  x0;
  goto merge__loopgoals_5_15;
  };
  goto merge__loopgoals_5_15;
 case VARREF:
  deref_and_jump(a3,merge__loopgoals_5_1);
  *reasonp++ =  a3;
  goto merge__loopgoals_5_15;
  };
  goto merge__loopgoals_5_15;
 merge__loopgoals_5_15:
  otherwise(merge__loopgoals_5_interrupt);
 merge__loopgoals_5_16:
  switch (ptagof(a3)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a3);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a4, x0);
  a3 = cdr_of(a3);
  a4 = x1;
  execute(merge__loopgoals_5_0);
  goto merge__loopgoals_5_ext_interrupt;
 case ATOMIC:
  if (a3 != NILATOM) goto merge__loopgoals_5_interrupt;
  unify(a2, a1);
  x0 = NILATOM;
  unify_value(a4, x0);
  proceed();
 case VARREF:
  deref_and_jump(a3,merge__loopgoals_5_16);
  *reasonp++ =  a3;
  goto merge__loopgoals_5_interrupt;
  };
  goto merge__loopgoals_5_interrupt;
 merge__loopgoals_5_ext_interrupt:
  reasonp = 0l;
 merge__loopgoals_5_interrupt:
  toppred = &predicate_depset_xmerge__loopgoals_5;
  goto interrupt_5;
 }

 dd__arg_4_top: {
  q x0, x1;
  a3 = qp->args[3];
  qp = qp->next;
 dd__arg_4_clear_reason:
  reasonp = reasons;
 dd__arg_4_0:
  x0 = a2;
  a4 = a3;
  a5 = NILATOM;
  allocp[0] = x1 = makeref(&allocp[0]);
  a6 = x1;
  a3 = x0;
  a2 = NILATOM;
  allocp += 1;
  execute(dd__arg2_7_0);
  goto dd__arg2_7_ext_interrupt;
 dd__arg_4_ext_interrupt:
  reasonp = 0l;
 dd__arg_4_interrupt:
  goto interrupt_4;
 }

 dd__arg2_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 dd__arg2_7_clear_reason:
  reasonp = reasons;
 dd__arg2_7_0:
 dd__arg2_7_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto dd__arg2_7_31;
  switch (symval(a0)) {
 case symval(makesym(atom_all)):
 dd__arg2_7_2:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 dd__arg2_7_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_t_2:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xdd__arg2_7);
  allocp[2] = makesym(atom_all);
  x1 = cdr_of(a1);
  allocp[3] = x1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_list_xor__unique_3);
  allocp[11] = a2;
  x3 = arg(x0, 1);
  allocp[12] = x3;
  allocp[13] = x2;
  qp = (struct goalrec*)&allocp[9];
  allocp += 14;
  proceed();
 case functor_te_4:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xdd__arg2_7);
  allocp[2] = makesym(atom_all);
  x1 = cdr_of(a1);
  allocp[3] = x1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_list_xor__unique_3);
  allocp[11] = a2;
  x3 = arg(x0, 3);
  allocp[12] = x3;
  allocp[13] = x2;
  qp = (struct goalrec*)&allocp[9];
  allocp += 14;
  proceed();
  };
  goto dd__arg2_7_31;
 case VARREF:
  deref_and_jump(x0,dd__arg2_7_3);
  *reasonp++ =  x0;
  goto dd__arg2_7_31;
  };
  goto dd__arg2_7_31;
 case VARREF:
  deref_and_jump(a1,dd__arg2_7_2);
  *reasonp++ =  a1;
  goto dd__arg2_7_31;
  };
  goto dd__arg2_7_31;
 case symval(makesym(atom_i)):
 dd__arg2_7_4:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 dd__arg2_7_5:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_2)) goto dd__arg2_7_31;
  x1 = arg(x0, 0);
 dd__arg2_7_6:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_i)) goto dd__arg2_7_31;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xdd__arg2_7);
  allocp[2] = makesym(atom_i);
  x2 = cdr_of(a1);
  allocp[3] = x2;
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_list_xor__unique_3);
  allocp[11] = a2;
  x4 = arg(x0, 1);
  allocp[12] = x4;
  allocp[13] = x3;
  qp = (struct goalrec*)&allocp[9];
  allocp += 14;
  proceed();
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_i_1)) goto dd__arg2_7_31;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xdd__arg2_7);
  allocp[2] = makesym(atom_i);
  x2 = cdr_of(a1);
  allocp[3] = x2;
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_list_xor__unique_3);
  allocp[11] = a2;
  x4 = arg(x0, 1);
  allocp[12] = x4;
  allocp[13] = x3;
  qp = (struct goalrec*)&allocp[9];
  allocp += 14;
  proceed();
 case VARREF:
  deref_and_jump(x1,dd__arg2_7_6);
  *reasonp++ =  x1;
  goto dd__arg2_7_31;
  };
  goto dd__arg2_7_31;
 case VARREF:
  deref_and_jump(x0,dd__arg2_7_5);
  *reasonp++ =  x0;
  goto dd__arg2_7_31;
  };
  goto dd__arg2_7_31;
 case VARREF:
  deref_and_jump(a1,dd__arg2_7_4);
  *reasonp++ =  a1;
  goto dd__arg2_7_31;
  };
  goto dd__arg2_7_31;
 case symval(makesym(atom_f)):
 dd__arg2_7_7:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 dd__arg2_7_8:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_2)) goto dd__arg2_7_31;
  x1 = arg(x0, 0);
 dd__arg2_7_9:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_f)) goto dd__arg2_7_31;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xdd__arg2_7);
  allocp[2] = makesym(atom_f);
  x2 = cdr_of(a1);
  allocp[3] = x2;
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_list_xor__unique_3);
  allocp[11] = a2;
  x4 = arg(x0, 1);
  allocp[12] = x4;
  allocp[13] = x3;
  qp = (struct goalrec*)&allocp[9];
  allocp += 14;
  proceed();
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_f_1)) goto dd__arg2_7_31;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xdd__arg2_7);
  allocp[2] = makesym(atom_f);
  x2 = cdr_of(a1);
  allocp[3] = x2;
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_list_xor__unique_3);
  allocp[11] = a2;
  x4 = arg(x0, 1);
  allocp[12] = x4;
  allocp[13] = x3;
  qp = (struct goalrec*)&allocp[9];
  allocp += 14;
  proceed();
 case VARREF:
  deref_and_jump(x1,dd__arg2_7_9);
  *reasonp++ =  x1;
  goto dd__arg2_7_31;
  };
  goto dd__arg2_7_31;
 case VARREF:
  deref_and_jump(x0,dd__arg2_7_8);
  *reasonp++ =  x0;
  goto dd__arg2_7_31;
  };
  goto dd__arg2_7_31;
 case VARREF:
  deref_and_jump(a1,dd__arg2_7_7);
  *reasonp++ =  a1;
  goto dd__arg2_7_31;
  };
  goto dd__arg2_7_31;
 case symval(makesym(atom_a)):
 dd__arg2_7_10:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 dd__arg2_7_11:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_2)) goto dd__arg2_7_31;
  x1 = arg(x0, 0);
 dd__arg2_7_12:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_a)) goto dd__arg2_7_31;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xdd__arg2_7);
  allocp[2] = makesym(atom_a);
  x2 = cdr_of(a1);
  allocp[3] = x2;
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_list_xor__unique_3);
  allocp[11] = a2;
  x4 = arg(x0, 1);
  allocp[12] = x4;
  allocp[13] = x3;
  qp = (struct goalrec*)&allocp[9];
  allocp += 14;
  proceed();
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_a_1)) goto dd__arg2_7_31;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xdd__arg2_7);
  allocp[2] = makesym(atom_a);
  x2 = cdr_of(a1);
  allocp[3] = x2;
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_list_xor__unique_3);
  allocp[11] = a2;
  x4 = arg(x0, 1);
  allocp[12] = x4;
  allocp[13] = x3;
  qp = (struct goalrec*)&allocp[9];
  allocp += 14;
  proceed();
 case VARREF:
  deref_and_jump(x1,dd__arg2_7_12);
  *reasonp++ =  x1;
  goto dd__arg2_7_31;
  };
  goto dd__arg2_7_31;
 case VARREF:
  deref_and_jump(x0,dd__arg2_7_11);
  *reasonp++ =  x0;
  goto dd__arg2_7_31;
  };
  goto dd__arg2_7_31;
 case VARREF:
  deref_and_jump(a1,dd__arg2_7_10);
  *reasonp++ =  a1;
  goto dd__arg2_7_31;
  };
  goto dd__arg2_7_31;
 case symval(makesym(atom_c)):
 dd__arg2_7_13:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 dd__arg2_7_14:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_2)) goto dd__arg2_7_31;
  x1 = arg(x0, 0);
 dd__arg2_7_15:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_c)) goto dd__arg2_7_31;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xdd__arg2_7);
  allocp[2] = makesym(atom_c);
  x2 = cdr_of(a1);
  allocp[3] = x2;
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_list_xor__unique_3);
  allocp[11] = a2;
  x4 = arg(x0, 1);
  allocp[12] = x4;
  allocp[13] = x3;
  qp = (struct goalrec*)&allocp[9];
  allocp += 14;
  proceed();
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_c_1)) goto dd__arg2_7_31;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xdd__arg2_7);
  allocp[2] = makesym(atom_c);
  x2 = cdr_of(a1);
  allocp[3] = x2;
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_list_xor__unique_3);
  allocp[11] = a2;
  x4 = arg(x0, 1);
  allocp[12] = x4;
  allocp[13] = x3;
  qp = (struct goalrec*)&allocp[9];
  allocp += 14;
  proceed();
 case VARREF:
  deref_and_jump(x1,dd__arg2_7_15);
  *reasonp++ =  x1;
  goto dd__arg2_7_31;
  };
  goto dd__arg2_7_31;
 case VARREF:
  deref_and_jump(x0,dd__arg2_7_14);
  *reasonp++ =  x0;
  goto dd__arg2_7_31;
  };
  goto dd__arg2_7_31;
 case VARREF:
  deref_and_jump(a1,dd__arg2_7_13);
  *reasonp++ =  a1;
  goto dd__arg2_7_31;
  };
  goto dd__arg2_7_31;
 case symval(makesym(atom_s)):
 dd__arg2_7_16:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 dd__arg2_7_17:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_2)) goto dd__arg2_7_31;
  x1 = arg(x0, 0);
 dd__arg2_7_18:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_s_3)) goto dd__arg2_7_31;
  x2 = arg(x1, 0);
 dd__arg2_7_19:
  if (isref(x2)) goto dd__arg2_7_20;
  x3 = PERIODATOM;
  gblt_diff(x2,x3,dd__arg2_7_31);
  x4 = makesym(atom___vector);
  gblt_diff(x2,x4,dd__arg2_7_31);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xdd__arg2_7);
  allocp[2] = makesym(atom_s);
  x5 = cdr_of(a1);
  allocp[3] = x5;
  allocp[4] = x6 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_list_xor__unique_3);
  allocp[11] = a2;
  x7 = arg(x0, 1);
  allocp[12] = x7;
  allocp[13] = x6;
  qp = (struct goalrec*)&allocp[9];
  allocp += 14;
  proceed();
 dd__arg2_7_20:
  deref_and_jump(x2,dd__arg2_7_19);
  *reasonp++ =  x2;
  goto dd__arg2_7_31;
 case VARREF:
  deref_and_jump(x1,dd__arg2_7_18);
  *reasonp++ =  x1;
  goto dd__arg2_7_31;
  };
  goto dd__arg2_7_31;
 case VARREF:
  deref_and_jump(x0,dd__arg2_7_17);
  *reasonp++ =  x0;
  goto dd__arg2_7_31;
  };
  goto dd__arg2_7_31;
 case VARREF:
  deref_and_jump(a1,dd__arg2_7_16);
  *reasonp++ =  a1;
  goto dd__arg2_7_31;
  };
  goto dd__arg2_7_31;
 case symval(makesym(atom_l)):
 dd__arg2_7_21:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 dd__arg2_7_22:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_2)) goto dd__arg2_7_31;
  x1 = arg(x0, 0);
 dd__arg2_7_23:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_s_3)) goto dd__arg2_7_31;
  x2 = arg(x1, 0);
 dd__arg2_7_24:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != PERIODATOM) goto dd__arg2_7_31;
  x3 = arg(x1, 1);
 dd__arg2_7_25:
  switch (ptagof(x3)) {
 case ATOMIC:
 dd__arg2_7_26:
  if (x3 != makeint(2L)) goto dd__arg2_7_31;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xdd__arg2_7);
  allocp[2] = makesym(atom_l);
  x4 = cdr_of(a1);
  allocp[3] = x4;
  allocp[4] = x5 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_list_xor__unique_3);
  allocp[11] = a2;
  x6 = arg(x0, 1);
  allocp[12] = x6;
  allocp[13] = x5;
  qp = (struct goalrec*)&allocp[9];
  allocp += 14;
  proceed();
 case VARREF:
  deref_and_jump(x3,dd__arg2_7_25);
  *reasonp++ =  x3;
  goto dd__arg2_7_31;
  };
  goto dd__arg2_7_31;
 case VARREF:
  deref_and_jump(x2,dd__arg2_7_24);
  *reasonp++ =  x2;
  goto dd__arg2_7_31;
  };
  goto dd__arg2_7_31;
 case VARREF:
  deref_and_jump(x1,dd__arg2_7_23);
  *reasonp++ =  x1;
  goto dd__arg2_7_31;
  };
  goto dd__arg2_7_31;
 case VARREF:
  deref_and_jump(x0,dd__arg2_7_22);
  *reasonp++ =  x0;
  goto dd__arg2_7_31;
  };
  goto dd__arg2_7_31;
 case VARREF:
  deref_and_jump(a1,dd__arg2_7_21);
  *reasonp++ =  a1;
  goto dd__arg2_7_31;
  };
  goto dd__arg2_7_31;
 case symval(makesym(atom_v)):
 dd__arg2_7_27:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 dd__arg2_7_28:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_2)) goto dd__arg2_7_31;
  x1 = arg(x0, 0);
 dd__arg2_7_29:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_s_3)) goto dd__arg2_7_31;
  x2 = arg(x1, 0);
 dd__arg2_7_30:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != makesym(atom___vector)) goto dd__arg2_7_31;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xdd__arg2_7);
  allocp[2] = makesym(atom_v);
  x3 = cdr_of(a1);
  allocp[3] = x3;
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_list_xor__unique_3);
  allocp[11] = a2;
  x5 = arg(x0, 1);
  allocp[12] = x5;
  allocp[13] = x4;
  qp = (struct goalrec*)&allocp[9];
  allocp += 14;
  proceed();
 case VARREF:
  deref_and_jump(x2,dd__arg2_7_30);
  *reasonp++ =  x2;
  goto dd__arg2_7_31;
  };
  goto dd__arg2_7_31;
 case VARREF:
  deref_and_jump(x1,dd__arg2_7_29);
  *reasonp++ =  x1;
  goto dd__arg2_7_31;
  };
  goto dd__arg2_7_31;
 case VARREF:
  deref_and_jump(x0,dd__arg2_7_28);
  *reasonp++ =  x0;
  goto dd__arg2_7_31;
  };
  goto dd__arg2_7_31;
 case VARREF:
  deref_and_jump(a1,dd__arg2_7_27);
  *reasonp++ =  a1;
  goto dd__arg2_7_31;
  };
  goto dd__arg2_7_31;
  };
  goto dd__arg2_7_31;
 case VARREF:
  deref_and_jump(a0,dd__arg2_7_1);
  *reasonp++ =  a0;
  goto dd__arg2_7_31;
  };
  goto dd__arg2_7_31;
 dd__arg2_7_31:
 dd__arg2_7_32:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 dd__arg2_7_33:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_tv_2)) goto dd__arg2_7_35;
  x1 = arg(x0, 0);
 dd__arg2_7_34:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_v_4)) goto dd__arg2_7_35;
  allocp[0] = makesym(functor_v_3);
  x3 = arg(x1, 0);
  allocp[1] = x3;
  x4 = arg(x1, 1);
  allocp[2] = x4;
  x5 = arg(x1, 2);
  allocp[3] = x5;
  x2 = makefunctor(&allocp[0]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_depset_xget__var_11);
  allocp[6] = x6 = makeref(&allocp[6]);
  allocp[7] = x2;
  x7 = arg(x0, 1);
  allocp[8] = x7;
  allocp[9] = a0;
  allocp[10] = makesym(atom_none);
  x8 = cdr_of(a1);
  allocp[11] = x8;
  allocp[12] = a2;
  allocp[13] = a3;
  allocp[14] = a4;
  allocp[15] = a5;
  allocp[16] = a6;
  allocp[17] = makesym(functor_v_3);
  x10 = arg(x1, 0);
  allocp[18] = x10;
  x11 = arg(x1, 1);
  allocp[19] = x11;
  x12 = arg(x1, 2);
  allocp[20] = x12;
  x9 = makefunctor(&allocp[17]);
  allocp[21] = (q)(struct goalrec*)&allocp[4];
  allocp[22] = (q)(&predicate_list_xcheck__include_3);
  allocp[23] = x9;
  allocp[24] = a5;
  allocp[25] = x6;
  qp = (struct goalrec*)&allocp[21];
  allocp += 26;
  proceed();
 case VARREF:
  deref_and_jump(x1,dd__arg2_7_34);
  *reasonp++ =  x1;
  goto dd__arg2_7_35;
  };
  goto dd__arg2_7_35;
 case VARREF:
  deref_and_jump(x0,dd__arg2_7_33);
  *reasonp++ =  x0;
  goto dd__arg2_7_35;
  };
  goto dd__arg2_7_35;
 case VARREF:
  deref_and_jump(a1,dd__arg2_7_32);
  *reasonp++ =  a1;
  goto dd__arg2_7_35;
  };
  goto dd__arg2_7_35;
 dd__arg2_7_35:
  otherwise(dd__arg2_7_interrupt);
 dd__arg2_7_36:
  switch (ptagof(a1)) {
 case CONS:
  a1 = cdr_of(a1);
  execute(dd__arg2_7_0);
  goto dd__arg2_7_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto dd__arg2_7_interrupt;
  unify2(a6, a5, a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a1,dd__arg2_7_36);
  *reasonp++ =  a1;
  goto dd__arg2_7_interrupt;
  };
  goto dd__arg2_7_interrupt;
 dd__arg2_7_ext_interrupt:
  reasonp = 0l;
 dd__arg2_7_interrupt:
  toppred = &predicate_depset_xdd__arg2_7;
  goto interrupt_7;
 }

 dd__arg_7_top: {
  q x0, x1, x2;
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 dd__arg_7_clear_reason:
  reasonp = reasons;
 dd__arg_7_0:
 dd__arg_7_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_n)) goto dd__arg_7_interrupt;
  a1 = makesym(atom_n);
  x0 = a3;
  x1 = a4;
  x2 = a5;
  a7 = a6;
  a6 = x2;
  a5 = x1;
  a4 = x0;
  a3 = NILATOM;
  execute(dd__arg_8_0);
  goto dd__arg_8_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,dd__arg_7_1);
  *reasonp++ =  a1;
  goto dd__arg_7_interrupt;
  };
  goto dd__arg_7_interrupt;
 dd__arg_7_ext_interrupt:
  reasonp = 0l;
 dd__arg_7_interrupt:
  goto interrupt_7;
 }

 dd__arg_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 dd__arg_8_clear_reason:
  reasonp = reasons;
 dd__arg_8_0:
 dd__arg_8_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_n)) goto dd__arg_8_8;
 dd__arg_8_2:
  switch (ptagof(a2)) {
 case CONS:
  x0 = car_of(a2);
 dd__arg_8_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_t_2:
  x1 = arg(x0, 0);
 dd__arg_8_4:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_s_3)) goto dd__arg_8_8;
  x2 = arg(x1, 1);
 dd__arg_8_5:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (isint(x2)) goto dd__arg_8_6;
  if (x2 != makesym(atom__2A)) goto dd__arg_8_8;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xdd__arg_8);
  allocp[2] = a0;
  allocp[3] = makesym(atom_n);
  x3 = cdr_of(a2);
  allocp[4] = x3;
  allocp[5] = x4 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = x5 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_depset_xdd__arg_8);
  allocp[12] = a0;
  allocp[13] = makesym(atom_n);
  x6 = arg(x1, 2);
  allocp[14] = x6;
  allocp[15] = x7 = makeref(&allocp[15]);
  allocp[16] = x4;
  allocp[17] = a5;
  allocp[18] = x8 = makeref(&allocp[18]);
  allocp[19] = x5;
  allocp[20] = NILATOM;
  allocp[21] = x0;
  x9 = makecons(&allocp[20]);
  a1 = x9;
  a2 = a3;
  a3 = x7;
  a4 = a5;
  a5 = a6;
  a6 = x8;
  qp = (struct goalrec*)&allocp[10];
  allocp += 22;
  execute(dd__arg2_7_0);
  goto dd__arg2_7_ext_interrupt;
 dd__arg_8_6:
  gblt_integer(x2,dd__arg_8_8);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xdd__arg_8);
  allocp[2] = a0;
  allocp[3] = makesym(atom_n);
  x3 = cdr_of(a2);
  allocp[4] = x3;
  allocp[5] = x4 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = x5 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_depset_xget__struct_8);
  allocp[12] = x2;
  x6 = arg(x1, 2);
  allocp[13] = x6;
  allocp[14] = a0;
  allocp[15] = x7 = makeref(&allocp[15]);
  allocp[16] = x4;
  allocp[17] = a5;
  allocp[18] = x8 = makeref(&allocp[18]);
  allocp[19] = x5;
  allocp[20] = NILATOM;
  allocp[21] = x0;
  x9 = makecons(&allocp[20]);
  a1 = x9;
  a2 = a3;
  a3 = x7;
  a4 = a5;
  a5 = a6;
  a6 = x8;
  qp = (struct goalrec*)&allocp[10];
  allocp += 22;
  execute(dd__arg2_7_0);
  goto dd__arg2_7_ext_interrupt;
 case VARREF:
  deref_and_jump(x2,dd__arg_8_5);
  *reasonp++ =  x2;
  goto dd__arg_8_8;
  };
  goto dd__arg_8_8;
 case VARREF:
  deref_and_jump(x1,dd__arg_8_4);
  *reasonp++ =  x1;
  goto dd__arg_8_8;
  };
  goto dd__arg_8_8;
 case functor_tv_2:
  x1 = arg(x0, 0);
 dd__arg_8_7:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_v_4)) goto dd__arg_8_8;
  allocp[0] = makesym(functor_v_3);
  x3 = arg(x1, 0);
  allocp[1] = x3;
  x4 = arg(x1, 1);
  allocp[2] = x4;
  x5 = arg(x1, 2);
  allocp[3] = x5;
  x2 = makefunctor(&allocp[0]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_depset_xget__var_11);
  allocp[6] = x6 = makeref(&allocp[6]);
  allocp[7] = x2;
  x7 = arg(x0, 1);
  allocp[8] = x7;
  allocp[9] = a0;
  allocp[10] = makesym(atom_n);
  x8 = cdr_of(a2);
  allocp[11] = x8;
  allocp[12] = a3;
  allocp[13] = a4;
  allocp[14] = a5;
  allocp[15] = a6;
  allocp[16] = a7;
  allocp[17] = makesym(functor_v_3);
  x10 = arg(x1, 0);
  allocp[18] = x10;
  x11 = arg(x1, 1);
  allocp[19] = x11;
  x12 = arg(x1, 2);
  allocp[20] = x12;
  x9 = makefunctor(&allocp[17]);
  allocp[21] = (q)(struct goalrec*)&allocp[4];
  allocp[22] = (q)(&predicate_list_xcheck__include_3);
  allocp[23] = x9;
  allocp[24] = a6;
  allocp[25] = x6;
  qp = (struct goalrec*)&allocp[21];
  allocp += 26;
  proceed();
 case VARREF:
  deref_and_jump(x1,dd__arg_8_7);
  *reasonp++ =  x1;
  goto dd__arg_8_8;
  };
  goto dd__arg_8_8;
  };
  goto dd__arg_8_8;
 case VARREF:
  deref_and_jump(x0,dd__arg_8_3);
  *reasonp++ =  x0;
  goto dd__arg_8_8;
  };
  goto dd__arg_8_8;
 case VARREF:
  deref_and_jump(a2,dd__arg_8_2);
  *reasonp++ =  a2;
  goto dd__arg_8_8;
  };
  goto dd__arg_8_8;
 case VARREF:
  deref_and_jump(a1,dd__arg_8_1);
  *reasonp++ =  a1;
  goto dd__arg_8_8;
  };
  goto dd__arg_8_8;
 dd__arg_8_8:
  otherwise(dd__arg_8_interrupt);
 dd__arg_8_9:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_n)) goto dd__arg_8_interrupt;
 dd__arg_8_10:
  switch (ptagof(a2)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xdd__arg_8);
  allocp[2] = a0;
  allocp[3] = makesym(atom_n);
  x0 = cdr_of(a2);
  allocp[4] = x0;
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = NILATOM;
  x4 = car_of(a2);
  allocp[11] = x4;
  x3 = makecons(&allocp[10]);
  a1 = x3;
  a2 = a3;
  a3 = x1;
  a4 = a5;
  a5 = a6;
  a6 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  execute(dd__arg2_7_0);
  goto dd__arg2_7_ext_interrupt;
 case ATOMIC:
  if (a2 != NILATOM) goto dd__arg_8_interrupt;
  unify2(a7, a6, a4, a3);
  proceed();
 case VARREF:
  deref_and_jump(a2,dd__arg_8_10);
  *reasonp++ =  a2;
  goto dd__arg_8_interrupt;
  };
  goto dd__arg_8_interrupt;
 case VARREF:
  deref_and_jump(a1,dd__arg_8_9);
  *reasonp++ =  a1;
  goto dd__arg_8_interrupt;
  };
  goto dd__arg_8_interrupt;
 dd__arg_8_ext_interrupt:
  reasonp = 0l;
 dd__arg_8_interrupt:
  toppred = &predicate_depset_xdd__arg_8;
  goto interrupt_8;
 }

 get__var_11_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 get__var_11_clear_reason:
  reasonp = reasons;
 get__var_11_0:
 get__var_11_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto get__var_11_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  unify2(a10, a9, a7, a6);
  proceed();
 case symval(makesym(atom_no)):
 get__var_11_2:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_v_3)) goto get__var_11_interrupt;
 get__var_11_3:
  switch (ptagof(a4)) {
 case ATOMIC:
  if (isint(a4)) goto get__var_11_interrupt;
  switch (symval(a4)) {
 case symval(makesym(atom_n)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xdd__arg_8);
  allocp[2] = a3;
  allocp[3] = makesym(atom_n);
  allocp[4] = a5;
  allocp[5] = x0 = makeref(&allocp[5]);
  allocp[6] = a7;
  allocp[7] = a8;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a10;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_depset_xget__var2_4);
  allocp[12] = a6;
  allocp[13] = x2 = makeref(&allocp[13]);
  allocp[14] = a2;
  allocp[15] = x0;
  allocp[16] = (q)(struct goalrec*)&allocp[10];
  allocp[17] = (q)(&predicate_depset_xdd__arg_8);
  allocp[18] = a3;
  allocp[19] = makesym(atom_n);
  allocp[20] = x3 = makeref(&allocp[20]);
  allocp[21] = a6;
  allocp[22] = x2;
  allocp[23] = a8;
  allocp[24] = x4 = makeref(&allocp[24]);
  allocp[25] = x1;
  allocp[26] = makesym(functor_v_3);
  x6 = arg(a1, 0);
  allocp[27] = x6;
  x7 = arg(a1, 1);
  allocp[28] = x7;
  x8 = arg(a1, 2);
  allocp[29] = x8;
  x5 = makefunctor(&allocp[26]);
  allocp[30] = a9;
  allocp[31] = x5;
  x9 = makecons(&allocp[30]);
  qp = (struct goalrec*)&allocp[16];
  allocp += 32;
  unify_value(x4, x9);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xget_5);
  x10 = arg(a1, 0);
  allocp[2] = x10;
  x11 = arg(a1, 1);
  allocp[3] = x11;
  x12 = arg(a1, 2);
  allocp[4] = x12;
  allocp[5] = x3;
  allocp[6] = a8;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  proceed();
 case symval(makesym(atom_none)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xdd__arg2_7);
  allocp[2] = a3;
  allocp[3] = a5;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = a7;
  allocp[6] = a8;
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = a10;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_depset_xget__var2_4);
  allocp[11] = a6;
  allocp[12] = x2 = makeref(&allocp[12]);
  allocp[13] = a2;
  allocp[14] = x0;
  allocp[15] = (q)(struct goalrec*)&allocp[9];
  allocp[16] = (q)(&predicate_depset_xdd__arg2_7);
  allocp[17] = a3;
  allocp[18] = x3 = makeref(&allocp[18]);
  allocp[19] = a6;
  allocp[20] = x2;
  allocp[21] = a8;
  allocp[22] = x4 = makeref(&allocp[22]);
  allocp[23] = x1;
  allocp[24] = makesym(functor_v_3);
  x6 = arg(a1, 0);
  allocp[25] = x6;
  x7 = arg(a1, 1);
  allocp[26] = x7;
  x8 = arg(a1, 2);
  allocp[27] = x8;
  x5 = makefunctor(&allocp[24]);
  allocp[28] = a9;
  allocp[29] = x5;
  x9 = makecons(&allocp[28]);
  qp = (struct goalrec*)&allocp[15];
  allocp += 30;
  unify_value(x4, x9);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xget_5);
  x10 = arg(a1, 0);
  allocp[2] = x10;
  x11 = arg(a1, 1);
  allocp[3] = x11;
  x12 = arg(a1, 2);
  allocp[4] = x12;
  allocp[5] = x3;
  allocp[6] = a8;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  proceed();
  };
  goto get__var_11_interrupt;
 case VARREF:
  deref_and_jump(a4,get__var_11_3);
  *reasonp++ =  a4;
  goto get__var_11_interrupt;
  };
  goto get__var_11_interrupt;
 case VARREF:
  deref_and_jump(a1,get__var_11_2);
  *reasonp++ =  a1;
  goto get__var_11_interrupt;
  };
  goto get__var_11_interrupt;
  };
  goto get__var_11_interrupt;
 case VARREF:
  deref_and_jump(a0,get__var_11_1);
  *reasonp++ =  a0;
  goto get__var_11_interrupt;
  };
  goto get__var_11_interrupt;
 get__var_11_ext_interrupt:
  reasonp = 0l;
 get__var_11_interrupt:
  goto interrupt_11;
 }

 get__var2_4_top: {
  a3 = qp->args[3];
  qp = qp->next;
 get__var2_4_clear_reason:
  reasonp = reasons;
 get__var2_4_0:
 get__var2_4_1:
  if (isref(a0)) goto get__var2_4_4;
 get__var2_4_2:
  if (isref(a0)) goto get__var2_4_3;
  if_not_equal(a0, a1, get__var2_4_5);
  unify(a3, a1);
  proceed();
 get__var2_4_3:
  deref_and_jump(a0,get__var2_4_2);
  *reasonp++ =  a0;
  goto get__var2_4_5;
 get__var2_4_4:
  deref_and_jump(a0,get__var2_4_1);
  *reasonp++ =  a0;
  goto get__var2_4_5;
 get__var2_4_5:
  otherwise(get__var2_4_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_list_xor__unique_3);
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 get__var2_4_ext_interrupt:
  reasonp = 0l;
 get__var2_4_interrupt:
  goto interrupt_4;
 }

 get__struct_8_top: {
  q x0, x1, x2, x3, x4;
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 get__struct_8_clear_reason:
  reasonp = reasons;
 get__struct_8_0:
 get__struct_8_1:
  if (!isint(a0)) goto get__struct_8_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,get__struct_8_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xget__struct_8);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[12] = a0;
  allocp[13] = makeint(1L);
  allocp[14] = x1;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_depset_xdd__arg_8);
  allocp[17] = a2;
  allocp[18] = makesym(atom_n);
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = a3;
  allocp[21] = x2;
  allocp[22] = a5;
  allocp[23] = a6;
  allocp[24] = x3;
  allocp[25] = (q)(struct goalrec*)&allocp[15];
  allocp[26] = (q)(&predicate_functor__table_xarg_3);
  allocp[27] = a0;
  allocp[28] = a1;
  allocp[29] = x4;
  qp = (struct goalrec*)&allocp[25];
  allocp += 30;
  proceed();
 get__struct_8_2:
  if (a0 != makeint(0L)) goto get__struct_8_interrupt;
  unify2(a7, a6, a4, a3);
  proceed();
 get__struct_8_3:
  if (!isref(a0)) goto get__struct_8_interrupt;
  deref_and_jump(a0,get__struct_8_1);
  *reasonp++ =  a0;
  goto get__struct_8_interrupt;
 get__struct_8_ext_interrupt:
  reasonp = 0l;
 get__struct_8_interrupt:
  goto interrupt_8;
 }

 check__include_3_top: {
  q x0, x1, x2;
  qp = qp->next;
 check__include_3_clear_reason:
  reasonp = reasons;
 check__include_3_0:
 check__include_3_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 check__include_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_entry_3:
  x1 = arg(x0, 0);
 check__include_3_3:
  if (isref(x1)) goto check__include_3_6;
 check__include_3_4:
  if (isref(x1)) goto check__include_3_5;
  if_not_equal(x1, a0, check__include_3_15);
  x2 = makesym(atom_yes);
  unify_value(a2, x2);
  proceed();
 check__include_3_5:
  deref_and_jump(x1,check__include_3_4);
  *reasonp++ =  x1;
  goto check__include_3_15;
 check__include_3_6:
  deref_and_jump(x1,check__include_3_3);
  *reasonp++ =  x1;
  goto check__include_3_15;
 case functor_recursive_3:
  x1 = arg(x0, 0);
 check__include_3_7:
  if (isref(x1)) goto check__include_3_10;
 check__include_3_8:
  if (isref(x1)) goto check__include_3_9;
  if_not_equal(x1, a0, check__include_3_15);
  x2 = makesym(atom_yes);
  unify_value(a2, x2);
  proceed();
 check__include_3_9:
  deref_and_jump(x1,check__include_3_8);
  *reasonp++ =  x1;
  goto check__include_3_15;
 check__include_3_10:
  deref_and_jump(x1,check__include_3_7);
  *reasonp++ =  x1;
  goto check__include_3_15;
 case functor_shared_3:
  x1 = arg(x0, 0);
 check__include_3_11:
  if (isref(x1)) goto check__include_3_14;
 check__include_3_12:
  if (isref(x1)) goto check__include_3_13;
  if_not_equal(x1, a0, check__include_3_15);
  x2 = makesym(atom_yes);
  unify_value(a2, x2);
  proceed();
 check__include_3_13:
  deref_and_jump(x1,check__include_3_12);
  *reasonp++ =  x1;
  goto check__include_3_15;
 check__include_3_14:
  deref_and_jump(x1,check__include_3_11);
  *reasonp++ =  x1;
  goto check__include_3_15;
  };
  goto check__include_3_15;
 case VARREF:
  deref_and_jump(x0,check__include_3_2);
  *reasonp++ =  x0;
  goto check__include_3_18;
  };
  goto check__include_3_15;
 check__include_3_15:
 check__include_3_16:
  if (isref(x0)) goto check__include_3_17;
  if_not_equal(x0, a0, check__include_3_18);
  x1 = makesym(atom_yes);
  unify_value(a2, x1);
  proceed();
 check__include_3_17:
  deref_and_jump(x0,check__include_3_16);
  *reasonp++ =  x0;
  goto check__include_3_18;
 case VARREF:
  deref_and_jump(a1,check__include_3_1);
  *reasonp++ =  a1;
  goto check__include_3_18;
  };
  goto check__include_3_18;
 check__include_3_18:
  otherwise(check__include_3_interrupt);
 check__include_3_19:
  switch (ptagof(a1)) {
 case CONS:
  a1 = cdr_of(a1);
  execute(check__include_3_0);
  goto check__include_3_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto check__include_3_interrupt;
  x0 = makesym(atom_no);
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,check__include_3_19);
  *reasonp++ =  a1;
  goto check__include_3_interrupt;
  };
  goto check__include_3_interrupt;
 check__include_3_ext_interrupt:
  reasonp = 0l;
 check__include_3_interrupt:
  goto interrupt_3;
 }
 interrupt_11:
  allocp[12] = a10;
 interrupt_10:
  allocp[11] = a9;
 interrupt_9:
  allocp[10] = a8;
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_depset);
}
