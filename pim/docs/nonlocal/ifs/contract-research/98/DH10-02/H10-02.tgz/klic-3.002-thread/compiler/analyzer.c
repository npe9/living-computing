/* Compiled by KLIC compiler version 3.002 (Wed Sep 17 15:37:13 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"
q opt_trace_atom_value = makeint(1);
q opt_analyze_dependency = makeint(1);

module module_analyzer();
Const struct predicate predicate_analyzer_xanalyzer1_3 =
   { module_analyzer, 0, 3 };
Const struct predicate predicate_analyzer_xanalyzer2_2 =
   { module_analyzer, 1, 2 };
Const struct predicate predicate_analyzer_xanalyzer3_3 =
   { module_analyzer, 2, 3 };
extern Const struct predicate predicate_print_xdatan_1;
extern Const struct predicate predicate_converter_xconvert_3;
extern Const struct predicate predicate_converter_xreplace_2;
extern Const struct predicate predicate_loop_xcheck_2;
extern Const struct predicate predicate_hb_xmake_2;
extern Const struct predicate predicate_hb_xcheck__shared_4;
extern Const struct predicate predicate_hb_xmake__extern_3;
extern Const struct predicate predicate_builtin__type_xinit_5;
extern Const struct predicate predicate_lt_xget_2;
extern Const struct predicate predicate_ea_xmake_2;
extern Const struct predicate predicate_analyze__type_xmain_8;
extern Const struct predicate predicate_file__op_xmake__ai0_5;
extern Const struct predicate predicate_file__op_xread__mid_2;
extern Const struct predicate predicate_file__op_xmake__ai2_4;
extern Const struct predicate predicate_file__op_xread__ai2_4;
extern Const struct predicate predicate_global__op_xread__aifiles_8;
extern Const struct predicate predicate_global__op_xget__localfile_4;
extern Const struct predicate predicate_global__op_xfunc2list_2;
extern Const struct predicate predicate_makepb_xmakepb_3;
extern Const struct predicate predicate_adg_xmake_6;
extern Const struct predicate predicate_adg_xmake__vio_3;
extern Const struct predicate predicate_vdg_xmake_5;
extern Const struct predicate predicate_analyze__type__ex_xdetermine_5;
extern Const struct predicate predicate_dependency_xinit__deps_2;
extern Const struct predicate predicate_dependency_xmake__control__dep_3;
extern Const struct predicate predicate_dependency_xmake__data__dep_4;
extern Const struct predicate predicate_dependency_xindirect_4;
extern Const struct predicate predicate_schedule_xmain_3;
extern Const struct predicate predicate_direct__call_xmain_2;
extern Const struct predicate predicate_native__goal_xcheck__sequential_2;
extern Const struct predicate predicate_gen__code_xmain_2;

module module_analyzer(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  static Const unsigned char strconst_body_0[4] =
    {'.','a','i','1',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_0 =
      declare_string_constant_8(strconst_body_0,4);
  q a0, a1, a2;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, analyzer1_3_top);
    case_pred(1, analyzer2_2_top);
    last_case_pred(2, analyzer3_3_top);
  }

 analyzer1_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17;
  a2 = qp->args[2];
  qp = qp->next;
 analyzer1_3_clear_reason:
  reasonp = reasons;
 analyzer1_3_0:
 analyzer1_3_1:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_normal_2)) goto analyzer1_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdatan_1);
  allocp[2] = makesym(atom__3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_20Analysis_20End_20_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D);
  allocp[3] = makesym(functor_normal_2);
  allocp[4] = x1 = makeref(&allocp[4]);
  x2 = arg(a1, 1);
  allocp[5] = x2;
  x0 = makefunctor(&allocp[3]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  unify_value(a2, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xmake__ai0_5);
  allocp[2] = a0;
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = x5 = makeref(&allocp[5]);
  allocp[6] = x6 = makeref(&allocp[6]);
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_print_xdatan_1);
  allocp[9] = makesym(atom__2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_20Writing_20ai0_20File_20_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B);
  allocp[10] = (q)(struct goalrec*)&allocp[7];
  allocp[11] = (q)(&predicate_analyze__type_xmain_8);
  allocp[12] = x1;
  allocp[13] = x5;
  allocp[14] = x7 = makeref(&allocp[14]);
  allocp[15] = x3;
  allocp[16] = x8 = makeref(&allocp[16]);
  allocp[17] = x9 = makeref(&allocp[17]);
  allocp[18] = x10 = makeref(&allocp[18]);
  allocp[19] = x4;
  allocp[20] = (q)(struct goalrec*)&allocp[10];
  allocp[21] = (q)(&predicate_hb_xmake__extern_3);
  allocp[22] = x1;
  allocp[23] = x11 = makeref(&allocp[23]);
  allocp[24] = x10;
  allocp[25] = (q)(struct goalrec*)&allocp[20];
  allocp[26] = (q)(&predicate_ea_xmake_2);
  allocp[27] = x1;
  allocp[28] = x5;
  allocp[29] = (q)(struct goalrec*)&allocp[25];
  allocp[30] = (q)(&predicate_lt_xget_2);
  allocp[31] = x1;
  allocp[32] = x6;
  allocp[33] = (q)(struct goalrec*)&allocp[29];
  allocp[34] = (q)(&predicate_builtin__type_xinit_5);
  allocp[35] = x12 = makeref(&allocp[35]);
  allocp[36] = x1;
  allocp[37] = x8;
  allocp[38] = x13 = makeref(&allocp[38]);
  allocp[39] = x7;
  allocp[40] = (q)(struct goalrec*)&allocp[33];
  allocp[41] = (q)(&predicate_print_xdatan_1);
  allocp[42] = makesym(atom__2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_20Analyzing_20Variable_20Types_20_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B);
  allocp[43] = (q)(struct goalrec*)&allocp[40];
  allocp[44] = (q)(&predicate_hb_xcheck__shared_4);
  allocp[45] = x14 = makeref(&allocp[45]);
  allocp[46] = x12;
  allocp[47] = x15 = makeref(&allocp[47]);
  allocp[48] = x11;
  allocp[49] = (q)(struct goalrec*)&allocp[43];
  allocp[50] = (q)(&predicate_hb_xmake_2);
  allocp[51] = x14;
  allocp[52] = x15;
  allocp[53] = (q)(struct goalrec*)&allocp[49];
  allocp[54] = (q)(&predicate_loop_xcheck_2);
  allocp[55] = x16 = makeref(&allocp[55]);
  allocp[56] = x14;
  allocp[57] = (q)(struct goalrec*)&allocp[53];
  allocp[58] = (q)(&predicate_converter_xconvert_3);
  x17 = arg(a1, 0);
  allocp[59] = x17;
  allocp[60] = x16;
  allocp[61] = x13;
  allocp[62] = (q)(struct goalrec*)&allocp[57];
  allocp[63] = (q)(&predicate_print_xdatan_1);
  allocp[64] = makesym(atom__2B_2B_2B_2B_2B_2B_2B_2B_2B_20Analyzing_20Program_20Structure_20_2B_2B_2B_2B_2B_2B_2B_2B);
  allocp[65] = (q)(struct goalrec*)&allocp[62];
  allocp[66] = (q)(&predicate_print_xdatan_1);
  allocp[67] = makesym(atom__3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_20Analysis_20Start_20_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D);
  qp = (struct goalrec*)&allocp[65];
  allocp += 68;
  proceed();
 case VARREF:
  deref_and_jump(a1,analyzer1_3_1);
  *reasonp++ =  a1;
  goto analyzer1_3_interrupt;
  };
  goto analyzer1_3_interrupt;
 analyzer1_3_ext_interrupt:
  reasonp = 0l;
 analyzer1_3_interrupt:
  goto interrupt_3;
 }

 analyzer2_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17;
  qp = qp->next;
 analyzer2_2_clear_reason:
  reasonp = reasons;
 analyzer2_2_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdatan_1);
  allocp[2] = makesym(atom__3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_20Analysis_20End_20_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D);
  allocp[3] = (q)(struct goalrec*)&allocp[0];
  allocp[4] = (q)(&predicate_file__op_xmake__ai2_4);
  allocp[5] = a0;
  allocp[6] = x0 = makeref(&allocp[6]);
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = (q)(struct goalrec*)&allocp[3];
  allocp[10] = (q)(&predicate_print_xdatan_1);
  allocp[11] = makesym(atom__2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_20Writing_20ai2_20Files_20_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B);
  allocp[12] = (q)(struct goalrec*)&allocp[9];
  allocp[13] = (q)(&predicate_global__op_xget__localfile_4);
  allocp[14] = a0;
  allocp[15] = x3 = makeref(&allocp[15]);
  allocp[16] = x4 = makeref(&allocp[16]);
  allocp[17] = x1;
  allocp[18] = (q)(struct goalrec*)&allocp[12];
  allocp[19] = (q)(&predicate_global__op_xget__localfile_4);
  allocp[20] = a0;
  allocp[21] = x3;
  allocp[22] = x5 = makeref(&allocp[22]);
  allocp[23] = x0;
  allocp[24] = (q)(struct goalrec*)&allocp[18];
  allocp[25] = (q)(&predicate_adg_xmake_6);
  allocp[26] = x6 = makeref(&allocp[26]);
  allocp[27] = x7 = makeref(&allocp[27]);
  allocp[28] = x8 = makeref(&allocp[28]);
  allocp[29] = x9 = makeref(&allocp[29]);
  allocp[30] = x10 = makeref(&allocp[30]);
  allocp[31] = x2;
  allocp[32] = (q)(struct goalrec*)&allocp[24];
  allocp[33] = (q)(&predicate_vdg_xmake_5);
  allocp[34] = x6;
  allocp[35] = x7;
  allocp[36] = x8;
  allocp[37] = x9;
  allocp[38] = x10;
  allocp[39] = (q)(struct goalrec*)&allocp[32];
  allocp[40] = (q)(&predicate_global__op_xfunc2list_2);
  allocp[41] = x5;
  allocp[42] = x8;
  allocp[43] = (q)(struct goalrec*)&allocp[39];
  allocp[44] = (q)(&predicate_global__op_xfunc2list_2);
  allocp[45] = x4;
  allocp[46] = x10;
  allocp[47] = (q)(struct goalrec*)&allocp[43];
  allocp[48] = (q)(&predicate_adg_xmake__vio_3);
  allocp[49] = x5;
  allocp[50] = x11 = makeref(&allocp[50]);
  allocp[51] = x4;
  allocp[52] = (q)(struct goalrec*)&allocp[47];
  allocp[53] = (q)(&predicate_makepb_xmakepb_3);
  allocp[54] = x9;
  allocp[55] = x6;
  allocp[56] = x12 = makeref(&allocp[56]);
  allocp[57] = (q)(struct goalrec*)&allocp[52];
  allocp[58] = (q)(&predicate_global__op_xget__localfile_4);
  allocp[59] = a0;
  allocp[60] = x3;
  allocp[61] = x11;
  allocp[62] = x12;
  allocp[63] = (q)(struct goalrec*)&allocp[57];
  allocp[64] = (q)(&predicate_print_xdatan_1);
  allocp[65] = makesym(atom__2B_2B_2B_2B_2B_2B_2B_20Analyzing_20Variables_27_20Dependency_20_2B_2B_2B_2B_2B_2B);
  allocp[66] = (q)(struct goalrec*)&allocp[63];
  allocp[67] = (q)(&predicate_global__op_xread__aifiles_8);
  allocp[68] = makefunctor(&string_const_0);
  allocp[69] = a1;
  allocp[70] = x5;
  allocp[71] = x11;
  allocp[72] = x13 = makeref(&allocp[72]);
  allocp[73] = x14 = makeref(&allocp[73]);
  allocp[74] = x3;
  allocp[75] = x15 = makeref(&allocp[75]);
  allocp[76] = (q)(struct goalrec*)&allocp[66];
  allocp[77] = (q)(&predicate_print_xdatan_1);
  allocp[78] = makesym(atom__2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_20Reading_20ai1_20Files_20_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B);
  allocp[79] = makesym(functor_normal_2);
  allocp[80] = x9;
  allocp[81] = x17 = makeref(&allocp[81]);
  x16 = makefunctor(&allocp[79]);
  allocp[82] = (q)(struct goalrec*)&allocp[76];
  allocp[83] = (q)(&predicate_file__op_xread__mid_2);
  allocp[84] = a0;
  allocp[85] = x16;
  allocp[86] = (q)(struct goalrec*)&allocp[82];
  allocp[87] = (q)(&predicate_print_xdatan_1);
  allocp[88] = makesym(atom__3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_20Analysis_20Start_20_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D);
  qp = (struct goalrec*)&allocp[86];
  allocp += 89;
  proceed();
 analyzer2_2_ext_interrupt:
  reasonp = 0l;
 analyzer2_2_interrupt:
  goto interrupt_2;
 }

 analyzer3_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15;
  a2 = qp->args[2];
  qp = qp->next;
 analyzer3_3_clear_reason:
  reasonp = reasons;
 analyzer3_3_0:
 analyzer3_3_1:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_normal_2)) goto analyzer3_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdatan_1);
  allocp[2] = makesym(atom__3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_20Analysis_20End_20_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D);
  allocp[3] = makesym(functor_normal_2);
  allocp[4] = x1 = makeref(&allocp[4]);
  x2 = arg(a1, 1);
  allocp[5] = x2;
  x0 = makefunctor(&allocp[3]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  unify_value(a2, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_converter_xreplace_2);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = x1;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_gen__code_xmain_2);
  allocp[6] = x4 = makeref(&allocp[6]);
  allocp[7] = x3;
  allocp[8] = (q)(struct goalrec*)&allocp[4];
  allocp[9] = (q)(&predicate_native__goal_xcheck__sequential_2);
  allocp[10] = x5 = makeref(&allocp[10]);
  allocp[11] = x4;
  allocp[12] = (q)(struct goalrec*)&allocp[8];
  allocp[13] = (q)(&predicate_direct__call_xmain_2);
  allocp[14] = x6 = makeref(&allocp[14]);
  allocp[15] = x5;
  allocp[16] = (q)(struct goalrec*)&allocp[12];
  allocp[17] = (q)(&predicate_print_xdatan_1);
  allocp[18] = makesym(atom__2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_20Optimizing_20Goals_20_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B);
  allocp[19] = (q)(struct goalrec*)&allocp[16];
  allocp[20] = (q)(&predicate_schedule_xmain_3);
  x7 = arg(a1, 0);
  allocp[21] = x7;
  allocp[22] = x6;
  allocp[23] = x8 = makeref(&allocp[23]);
  allocp[24] = (q)(struct goalrec*)&allocp[19];
  allocp[25] = (q)(&predicate_print_xdatan_1);
  allocp[26] = makesym(atom__2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_20Scheduling_20Goals_20_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B);
  allocp[27] = (q)(struct goalrec*)&allocp[24];
  allocp[28] = (q)(&predicate_dependency_xindirect_4);
  allocp[29] = x7;
  allocp[30] = x9 = makeref(&allocp[30]);
  allocp[31] = x10 = makeref(&allocp[31]);
  allocp[32] = x8;
  allocp[33] = (q)(struct goalrec*)&allocp[27];
  allocp[34] = (q)(&predicate_dependency_xmake__data__dep_4);
  allocp[35] = x7;
  allocp[36] = x9;
  allocp[37] = x11 = makeref(&allocp[37]);
  allocp[38] = x10;
  allocp[39] = (q)(struct goalrec*)&allocp[33];
  allocp[40] = (q)(&predicate_dependency_xmake__control__dep_3);
  allocp[41] = x7;
  allocp[42] = x12 = makeref(&allocp[42]);
  allocp[43] = x11;
  allocp[44] = (q)(struct goalrec*)&allocp[39];
  allocp[45] = (q)(&predicate_dependency_xinit__deps_2);
  allocp[46] = x7;
  allocp[47] = x12;
  allocp[48] = (q)(struct goalrec*)&allocp[44];
  allocp[49] = (q)(&predicate_print_xdatan_1);
  allocp[50] = makesym(atom__2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_20Making_20Dependency_20_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B);
  allocp[51] = (q)(struct goalrec*)&allocp[48];
  allocp[52] = (q)(&predicate_analyze__type__ex_xdetermine_5);
  allocp[53] = x7;
  allocp[54] = x13 = makeref(&allocp[54]);
  allocp[55] = x14 = makeref(&allocp[55]);
  allocp[56] = x15 = makeref(&allocp[56]);
  allocp[57] = x9;
  allocp[58] = (q)(struct goalrec*)&allocp[51];
  allocp[59] = (q)(&predicate_file__op_xread__ai2_4);
  allocp[60] = a0;
  allocp[61] = x15;
  allocp[62] = x13;
  allocp[63] = x14;
  allocp[64] = (q)(struct goalrec*)&allocp[58];
  allocp[65] = (q)(&predicate_print_xdatan_1);
  allocp[66] = makesym(atom__2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_20Reading_20ai2_20File_20_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B);
  allocp[67] = (q)(struct goalrec*)&allocp[64];
  allocp[68] = (q)(&predicate_print_xdatan_1);
  allocp[69] = makesym(atom__3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_20Analysis_20Start_20_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D);
  qp = (struct goalrec*)&allocp[67];
  allocp += 70;
  proceed();
 case VARREF:
  deref_and_jump(a1,analyzer3_3_1);
  *reasonp++ =  a1;
  goto analyzer3_3_interrupt;
  };
  goto analyzer3_3_interrupt;
 analyzer3_3_ext_interrupt:
  reasonp = 0l;
 analyzer3_3_interrupt:
  goto interrupt_3;
 }
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_analyzer);
}
