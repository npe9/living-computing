char *runtime_version = "3.002";
char *runtime_date = "Wed Sep 17 15:37:13 JST 1997";
