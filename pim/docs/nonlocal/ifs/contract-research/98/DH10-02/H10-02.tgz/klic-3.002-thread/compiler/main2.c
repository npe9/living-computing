/* Compiled by KLIC compiler version 3.002 (Wed Sep 17 15:37:13 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_main();
Const struct predicate predicate_main_xmain_0 =
   { module_main, 0, 0 };
Const struct predicate predicate_main_xkl1cmps_2 =
   { module_main, 1, 2 };
Const struct predicate predicate_main_xkl1cmps_2F2_240_4 =
   { module_main, 2, 4 };
Const struct predicate predicate_main_xkl1cmp2_5 =
   { module_main, 3, 5 };
extern Const struct predicate predicate_unix_xargv_1;
extern Const struct predicate predicate_unix_xexit_1;
extern Const struct predicate predicate_analyzer_xanalyzer2_2;
extern Const struct predicate predicate_klic__comp__message_xreport__error_2;

module module_main(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_0 =
      declare_string_constant_8(0,0);
  static Const unsigned char strconst_body_1[4] =
    {'.','m','i','d',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_1 =
      declare_string_constant_8(strconst_body_1,4);
  static Const unsigned char strconst_body_2[40] =
    "File name extension of ~s is not mid\n";
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_2 =
      declare_string_constant_8(strconst_body_2,37);
  q a0, a1, a2, a3, a4;

  q *reasonp;
 module_top:
  switch_on_pred() {
    case_pred(0, main_0_top);
    case_pred(1, kl1cmps_2_top);
    case_pred(2, kl1cmps_2F2_240_4_top);
    last_case_pred(3, kl1cmp2_5_top);
  }

 main_0_top: {
  q x0;
  qp = qp->next;
 main_0_clear_reason:
  reasonp = reasons;
 main_0_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_main_xkl1cmps_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = makesym(atom_normal);
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_unix_xargv_1);
  allocp[6] = x0;
  qp = (struct goalrec*)&allocp[4];
  allocp += 7;
  proceed();
 main_0_ext_interrupt:
  reasonp = 0l;
 main_0_interrupt:
  goto interrupt_0;
 }

 kl1cmps_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13;
  a0 = qp->args[0];
  a1 = qp->args[1];
  qp = qp->next;
 kl1cmps_2_clear_reason:
  reasonp = reasons;
 kl1cmps_2_0:
 kl1cmps_2_1:
  switch (ptagof(a0)) {
 case CONS:
 kl1cmps_2_2:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_normal)) goto kl1cmps_2_7;
  x0 = car_of(a0);
 kl1cmps_2_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
 kl1cmps_2_4:
  if (!isgobj(x0)) goto kl1cmps_2_7;
 kl1cmps_2_5:
  gblt_is_string(x0,kl1cmps_2_7);
  gblt_size_of_string(x0,x1,kl1cmps_2_7);
  gblt_element_size_of_string(x0,x2,kl1cmps_2_7);
  x3 = makeint(1L);
  bblt_sub_no_check(x1,x3,x4);
  generic_arg[0] = x4;
  x5 = makeint(1L);
  generic_arg[1] = x5;
  x6 = makeint(46L);
  generic_arg[2] = x6;
  allocp[0] = x7 = makeref(&allocp[0]);
  generic_arg[3] = x7;
  call_generic(x0, functor_search__character_4, 1);
  allocp[1] = (q)(&predicate_main_xkl1cmps_2);
  allocp[2] = NILATOM;
  allocp[3] = x8 = makeref(&allocp[3]);
  x9 = (q)qp;
  x10 = (q)(struct goalrec*)&allocp[0];
  enqueue_at_lower_priority_no_check(makeint(1L),x9,x10);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_main_xkl1cmp2_5);
  allocp[6] = x0;
  x11 = cdr_of(a0);
  allocp[7] = x11;
  allocp[8] = x12 = makeref(&allocp[8]);
  allocp[9] = x13 = makeref(&allocp[9]);
  allocp[10] = x8;
  a0 = x7;
  a1 = x0;
  a2 = x12;
  a3 = x13;
  qp = (struct goalrec*)&allocp[4];
  allocp += 11;
  execute(kl1cmps_2F2_240_4_0);
  goto kl1cmps_2F2_240_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,kl1cmps_2_3);
  *reasonp++ =  x0;
  goto kl1cmps_2_7;
  };
  goto kl1cmps_2_7;
 case VARREF:
  deref_and_jump(a1,kl1cmps_2_2);
  *reasonp++ =  a1;
  goto kl1cmps_2_7;
  };
  goto kl1cmps_2_7;
 case ATOMIC:
  if (a0 != NILATOM) goto kl1cmps_2_7;
 kl1cmps_2_6:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_normal)) goto kl1cmps_2_7;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unix_xexit_1);
  allocp[2] = makeint(0L);
  qp = (struct goalrec*)&allocp[0];
  allocp += 3;
  proceed();
 case VARREF:
  deref_and_jump(a1,kl1cmps_2_6);
  *reasonp++ =  a1;
  goto kl1cmps_2_7;
  };
  goto kl1cmps_2_7;
 case VARREF:
  deref_and_jump(a0,kl1cmps_2_1);
  *reasonp++ =  a0;
  goto kl1cmps_2_7;
  };
  goto kl1cmps_2_7;
 kl1cmps_2_7:
  otherwise(kl1cmps_2_interrupt);
 kl1cmps_2_8:
  if (isref(a1)) goto kl1cmps_2_9;
  gblt_wait(a1,kl1cmps_2_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unix_xexit_1);
  allocp[2] = makeint(-1L);
  qp = (struct goalrec*)&allocp[0];
  allocp += 3;
  proceed();
 kl1cmps_2_9:
  deref_and_jump(a1,kl1cmps_2_8);
  *reasonp++ =  a1;
  goto kl1cmps_2_interrupt;
 kl1cmps_2_ext_interrupt:
  reasonp = 0l;
 kl1cmps_2_interrupt:
  goto interrupt_2;
 }

 kl1cmps_2F2_240_4_top: {
  q x0, x1, x2;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 kl1cmps_2F2_240_4_clear_reason:
  reasonp = reasons;
 kl1cmps_2F2_240_4_0:
 kl1cmps_2F2_240_4_1:
  if (!isint(a0)) goto kl1cmps_2F2_240_4_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,kl1cmps_2F2_240_4_2);
  generic_arg[0] = a0;
  generic_arg[1] = a2;
  generic_arg[2] = a3;
  call_generic(a1, functor_split_3, 0);
  proceed();
 kl1cmps_2F2_240_4_2:
  x1 = makeint(0L);
  gblt_less_or_eq(a0,x1,kl1cmps_2F2_240_4_interrupt);
  unify(a2, a1);
  x2 = makefunctor(&string_const_0);
  unify_value(a3, x2);
  proceed();
 kl1cmps_2F2_240_4_3:
  if (!isref(a0)) goto kl1cmps_2F2_240_4_interrupt;
  deref_and_jump(a0,kl1cmps_2F2_240_4_1);
  *reasonp++ =  a0;
  goto kl1cmps_2F2_240_4_interrupt;
 kl1cmps_2F2_240_4_ext_interrupt:
  reasonp = 0l;
 kl1cmps_2F2_240_4_interrupt:
  toppred = &predicate_main_xkl1cmps_2F2_240_4;
  goto interrupt_4;
 }

 kl1cmp2_5_top: {
  q x0, x1;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 kl1cmp2_5_clear_reason:
  reasonp = reasons;
 kl1cmp2_5_0:
 kl1cmp2_5_1:
  if (isref(a3)) goto kl1cmp2_5_4;
 kl1cmp2_5_2:
  if (isref(a3)) goto kl1cmp2_5_3;
  x0 = makefunctor(&string_const_1);
  if_not_equal(a3, x0, kl1cmp2_5_5);
  x1 = makesym(atom_normal);
  unify_value(a4, x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_analyzer_xanalyzer2_2);
  allocp[2] = a2;
  allocp[3] = a1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  proceed();
 kl1cmp2_5_3:
  deref_and_jump(a3,kl1cmp2_5_2);
  *reasonp++ =  a3;
  goto kl1cmp2_5_5;
 kl1cmp2_5_4:
  deref_and_jump(a3,kl1cmp2_5_1);
  *reasonp++ =  a3;
  goto kl1cmp2_5_5;
 kl1cmp2_5_5:
  otherwise(kl1cmp2_5_interrupt);
  allocp[0] = makesym(functor_abnormal_2);
  allocp[1] = makesym(atom_inputfile);
  allocp[2] = a0;
  x0 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a4, x0);
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x1 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__message_xreport__error_2);
  allocp[4] = makefunctor(&string_const_2);
  allocp[5] = x1;
  qp = (struct goalrec*)&allocp[2];
  allocp += 6;
  proceed();
 kl1cmp2_5_ext_interrupt:
  reasonp = 0l;
 kl1cmp2_5_interrupt:
  goto interrupt_5;
 }
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_main);
}
