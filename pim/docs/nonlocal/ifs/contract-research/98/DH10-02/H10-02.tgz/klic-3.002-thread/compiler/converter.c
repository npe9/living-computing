/* Compiled by KLIC compiler version 3.002 (Wed Sep 17 15:37:13 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_converter();
Const struct predicate predicate_converter_xconvert_3 =
   { module_converter, 0, 3 };
Const struct predicate predicate_converter_xconvert__modules_3 =
   { module_converter, 1, 3 };
Const struct predicate predicate_converter_xconvert__clauses_3 =
   { module_converter, 2, 3 };
Const struct predicate predicate_converter_xconvert__clause_3 =
   { module_converter, 3, 3 };
Const struct predicate predicate_converter_xcount__variables_8 =
   { module_converter, 4, 8 };
Const struct predicate predicate_converter_xget__vn__goallist_8 =
   { module_converter, 5, 8 };
Const struct predicate predicate_converter_xget__vn__goal_8 =
   { module_converter, 6, 8 };
Const struct predicate predicate_converter_xget__vn__functor_9 =
   { module_converter, 7, 9 };
Const struct predicate predicate_converter_xget__vn__arg_8 =
   { module_converter, 8, 8 };
Const struct predicate predicate_converter_xreplace_2 =
   { module_converter, 9, 2 };
Const struct predicate predicate_converter_xreplace__modules_2 =
   { module_converter, 10, 2 };
Const struct predicate predicate_converter_xreplace__clauses_4 =
   { module_converter, 11, 4 };
Const struct predicate predicate_converter_xreplace__clause_2 =
   { module_converter, 12, 2 };
Const struct predicate predicate_converter_xreplace__goals_3 =
   { module_converter, 13, 3 };
Const struct predicate predicate_converter_xreplace__goals_5 =
   { module_converter, 14, 5 };
Const struct predicate predicate_converter_xreplace__goal_3 =
   { module_converter, 15, 3 };
Const struct predicate predicate_converter_xreplace__funtor_3 =
   { module_converter, 16, 3 };
Const struct predicate predicate_converter_xreplace__functor_3 =
   { module_converter, 17, 3 };
Const struct predicate predicate_converter_xreplace__args_4 =
   { module_converter, 18, 4 };
Const struct predicate predicate_converter_xreplace__modulename_4 =
   { module_converter, 19, 4 };
Const struct predicate predicate_converter_xreplace__pragma_3 =
   { module_converter, 20, 3 };
extern Const struct predicate predicate_functor_xcreate__functor_3;
extern Const struct predicate predicate_functor_xnew__functor__init_4;
extern Const struct predicate predicate_integer__arithmetics_xadd_3;
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_xsetarg_4;
extern Const struct predicate predicate_functor__table_xfunctor_3;
extern Const struct predicate predicate_uty_xmax_3;
extern Const struct predicate predicate_parse__uty_xdecode__goal_4;

module module_converter(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  static Const q cons_const_0[] = {
    NILATOM,
    makesym(atom__2A),
  };
  static Const q funct_const_1[] = {
    makesym(functor_v_3),
    makecons(cons_const_0),
    NILATOM,
    NILATOM,
  };
  q a0, a1, a2, a3, a4, a5, a6, a7, a8;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, convert_3_top);
    case_pred(1, convert__modules_3_top);
    case_pred(2, convert__clauses_3_top);
    case_pred(3, convert__clause_3_top);
    case_pred(4, count__variables_8_top);
    case_pred(5, get__vn__goallist_8_top);
    case_pred(6, get__vn__goal_8_top);
    case_pred(7, get__vn__functor_9_top);
    case_pred(8, get__vn__arg_8_top);
    case_pred(9, replace_2_top);
    case_pred(10, replace__modules_2_top);
    case_pred(11, replace__clauses_4_top);
    case_pred(12, replace__clause_2_top);
    case_pred(13, replace__goals_3_top);
    case_pred(14, replace__goals_5_top);
    case_pred(15, replace__goal_3_top);
    case_pred(16, replace__funtor_3_top);
    case_pred(17, replace__functor_3_top);
    case_pred(18, replace__args_4_top);
    case_pred(19, replace__modulename_4_top);
    last_case_pred(20, replace__pragma_3_top);
  }

 convert_3_top: {
  a2 = qp->args[2];
  qp = qp->next;
 convert_3_clear_reason:
  reasonp = reasons;
 convert_3_0:
  execute(convert__modules_3_0);
  goto convert__modules_3_ext_interrupt;
 convert_3_ext_interrupt:
  reasonp = 0l;
 convert_3_interrupt:
  goto interrupt_3;
 }

 convert__modules_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13;
  a2 = qp->args[2];
  qp = qp->next;
 convert__modules_3_clear_reason:
  reasonp = reasons;
 convert__modules_3_0:
 convert__modules_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 convert__modules_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto convert__modules_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_converter_xconvert__modules_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = makesym(functor_module_2);
  x5 = arg(x0, 0);
  allocp[6] = x5;
  allocp[7] = x6 = makeref(&allocp[7]);
  x4 = makefunctor(&allocp[5]);
  allocp[8] = x3;
  allocp[9] = x4;
  x7 = makecons(&allocp[8]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  unify_value(a2, x7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor_xcreate__functor_3);
  allocp[2] = makesym(atom_clauses);
  allocp[3] = x8 = makeref(&allocp[3]);
  allocp[4] = x6;
  allocp[5] = makesym(functor_module_2);
  x10 = arg(x0, 0);
  allocp[6] = x10;
  allocp[7] = x11 = makeref(&allocp[7]);
  x9 = makefunctor(&allocp[5]);
  allocp[8] = x2;
  allocp[9] = x9;
  x12 = makecons(&allocp[8]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  unify_value(a1, x12);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor_xcreate__functor_3);
  allocp[2] = makesym(atom_clauses);
  allocp[3] = x13 = makeref(&allocp[3]);
  allocp[4] = x11;
  a0 = arg(x0, 1);
  a1 = x13;
  a2 = x8;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(convert__clauses_3_0);
  goto convert__clauses_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,convert__modules_3_2);
  *reasonp++ =  x0;
  goto convert__modules_3_interrupt;
  };
  goto convert__modules_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto convert__modules_3_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  x1 = NILATOM;
  unify_value(a2, x1);
  proceed();
 case VARREF:
  deref_and_jump(a0,convert__modules_3_1);
  *reasonp++ =  a0;
  goto convert__modules_3_interrupt;
  };
  goto convert__modules_3_interrupt;
 convert__modules_3_ext_interrupt:
  reasonp = 0l;
 convert__modules_3_interrupt:
  toppred = &predicate_converter_xconvert__modules_3;
  goto interrupt_3;
 }

 convert__clauses_3_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  qp = qp->next;
 convert__clauses_3_clear_reason:
  reasonp = reasons;
 convert__clauses_3_0:
 convert__clauses_3_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_converter_xconvert__clauses_3);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = x1;
  allocp[6] = x4 = makeref(&allocp[6]);
  x3 = makecons(&allocp[5]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  unify_value(a1, x3);
  allocp[0] = x2;
  allocp[1] = x6 = makeref(&allocp[1]);
  x5 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x5);
  a0 = car_of(a0);
  a1 = x4;
  a2 = x6;
  execute(convert__clause_3_0);
  goto convert__clause_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto convert__clauses_3_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  x1 = NILATOM;
  unify_value(a2, x1);
  proceed();
 case VARREF:
  deref_and_jump(a0,convert__clauses_3_1);
  *reasonp++ =  a0;
  goto convert__clauses_3_interrupt;
  };
  goto convert__clauses_3_interrupt;
 convert__clauses_3_ext_interrupt:
  reasonp = 0l;
 convert__clauses_3_interrupt:
  toppred = &predicate_converter_xconvert__clauses_3;
  goto interrupt_3;
 }

 convert__clause_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  qp = qp->next;
 convert__clause_3_clear_reason:
  reasonp = reasons;
 convert__clause_3_0:
 convert__clause_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto convert__clause_3_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_otherwise)):
  x0 = makesym(atom_clause);
  unify_value(a2, x0);
  unify_value(a1, a0);
  proceed();
 case symval(makesym(atom_alternatively)):
  x0 = makesym(atom_clause);
  unify_value(a2, x0);
  unify_value(a1, a0);
  proceed();
  };
  goto convert__clause_3_interrupt;
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_clause_4)) goto convert__clause_3_interrupt;
  allocp[0] = makesym(functor_clause_4);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  x4 = arg(a0, 3);
  allocp[4] = x4;
  x0 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor_xcreate__functor_3);
  allocp[2] = makesym(atom_bodys);
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = x3;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor_xcreate__functor_3);
  allocp[7] = makesym(atom_guards);
  allocp[8] = x6 = makeref(&allocp[8]);
  allocp[9] = x2;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor_xnew__functor__init_4);
  allocp[12] = makesym(atom_clause);
  allocp[13] = x7 = makeref(&allocp[13]);
  allocp[14] = makefunctor(funct_const_1);
  allocp[15] = a2;
  x8 = arg(a0, 0);
  a1 = x1;
  a2 = arg(a0, 1);
  a3 = x6;
  a4 = arg(a0, 2);
  a5 = x5;
  a6 = x7;
  allocp[16] = x9 = makeref(&allocp[16]);
  a7 = x9;
  a0 = x8;
  qp = (struct goalrec*)&allocp[10];
  allocp += 17;
  execute(count__variables_8_0);
  goto count__variables_8_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,convert__clause_3_1);
  *reasonp++ =  a0;
  goto convert__clause_3_interrupt;
  };
  goto convert__clause_3_interrupt;
 convert__clause_3_ext_interrupt:
  reasonp = 0l;
 convert__clause_3_interrupt:
  toppred = &predicate_converter_xconvert__clause_3;
  goto interrupt_3;
 }

 count__variables_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 count__variables_8_clear_reason:
  reasonp = reasons;
 count__variables_8_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = makeint(1L);
  allocp[4] = a6;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_uty_xmax_3);
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = x0;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_converter_xget__vn__goallist_8);
  allocp[12] = makeint(-1L);
  allocp[13] = a4;
  allocp[14] = a5;
  allocp[15] = x2;
  allocp[16] = x3 = makeref(&allocp[16]);
  allocp[17] = a7;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = x5 = makeref(&allocp[19]);
  allocp[20] = (q)(struct goalrec*)&allocp[10];
  allocp[21] = (q)(&predicate_converter_xget__vn__goallist_8);
  allocp[22] = makeint(-1L);
  allocp[23] = a2;
  allocp[24] = a3;
  allocp[25] = x1;
  allocp[26] = x6 = makeref(&allocp[26]);
  allocp[27] = x3;
  allocp[28] = x7 = makeref(&allocp[28]);
  allocp[29] = x4;
  x8 = a0;
  a2 = a1;
  allocp[30] = x9 = makeref(&allocp[30]);
  a3 = x9;
  a4 = NILATOM;
  a5 = x6;
  a6 = makeint(0L);
  a7 = x7;
  a1 = x8;
  a0 = makeint(-1L);
  qp = (struct goalrec*)&allocp[20];
  allocp += 31;
  execute(get__vn__goal_8_0);
  goto get__vn__goal_8_ext_interrupt;
 count__variables_8_ext_interrupt:
  reasonp = 0l;
 count__variables_8_interrupt:
  toppred = &predicate_converter_xcount__variables_8;
  goto interrupt_8;
 }

 get__vn__goallist_8_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 get__vn__goallist_8_clear_reason:
  reasonp = reasons;
 get__vn__goallist_8_0:
 get__vn__goallist_8_1:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_converter_xget__vn__goallist_8);
  allocp[2] = x0 = makeref(&allocp[2]);
  x1 = cdr_of(a1);
  allocp[3] = x1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x2;
  allocp[11] = x6 = makeref(&allocp[11]);
  x5 = makecons(&allocp[10]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  unify_value(a2, x5);
  a1 = car_of(a1);
  a2 = x6;
  a3 = x0;
  a5 = x3;
  a7 = x4;
  execute(get__vn__goal_8_0);
  goto get__vn__goal_8_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto get__vn__goallist_8_interrupt;
  x0 = NILATOM;
  unify_value(a2, x0);
  unify3(a3, a0, a5, a4, a7, a6);
  proceed();
 case VARREF:
  deref_and_jump(a1,get__vn__goallist_8_1);
  *reasonp++ =  a1;
  goto get__vn__goallist_8_interrupt;
  };
  goto get__vn__goallist_8_interrupt;
 get__vn__goallist_8_ext_interrupt:
  reasonp = 0l;
 get__vn__goallist_8_interrupt:
  goto interrupt_8;
 }

 get__vn__goal_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 get__vn__goal_8_clear_reason:
  reasonp = reasons;
 get__vn__goal_8_0:
 get__vn__goal_8_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (isint(a1)) goto get__vn__goal_8_3;
 get__vn__goal_8_2:
  gblt_atom(a1,get__vn__goal_8_3);
  unify_value(a2, a1);
  unify3(a3, a0, a5, a4, a7, a6);
  proceed();
 case VARREF:
  deref_and_jump(a1,get__vn__goal_8_1);
  *reasonp++ =  a1;
  goto get__vn__goal_8_interrupt;
  };
  goto get__vn__goal_8_3;
 get__vn__goal_8_3:
  gblt_pfunctor(a1,x0,get__vn__goal_8_interrupt);
  gblt_arity(a1,x1,get__vn__goal_8_interrupt);
  x2 = a0;
  x3 = a3;
  a3 = a1;
  x4 = a2;
  x5 = a4;
  x6 = a5;
  x7 = a6;
  a8 = a7;
  a7 = x7;
  a6 = x6;
  a5 = x5;
  a4 = x4;
  a2 = x3;
  a1 = x2;
  a0 = x1;
  execute(get__vn__functor_9_0);
  goto get__vn__functor_9_ext_interrupt;
 get__vn__goal_8_ext_interrupt:
  reasonp = 0l;
 get__vn__goal_8_interrupt:
  toppred = &predicate_converter_xget__vn__goal_8;
  goto interrupt_8;
 }

 get__vn__functor_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 get__vn__functor_9_clear_reason:
  reasonp = reasons;
 get__vn__functor_9_0:
 get__vn__functor_9_1:
  if (!isint(a0)) goto get__vn__functor_9_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,get__vn__functor_9_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_converter_xget__vn__functor_9);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x4 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = x5 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x1;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[18] = a0;
  allocp[19] = a3;
  allocp[20] = x6 = makeref(&allocp[20]);
  allocp[21] = x3;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_converter_xget__vn__arg_8);
  allocp[24] = a1;
  allocp[25] = x2;
  allocp[26] = x7 = makeref(&allocp[26]);
  allocp[27] = x6;
  allocp[28] = a5;
  allocp[29] = x4;
  allocp[30] = a7;
  allocp[31] = x5;
  allocp[32] = (q)(struct goalrec*)&allocp[22];
  allocp[33] = (q)(&predicate_functor__table_xarg_3);
  allocp[34] = a0;
  allocp[35] = a3;
  allocp[36] = x7;
  qp = (struct goalrec*)&allocp[32];
  allocp += 37;
  proceed();
 get__vn__functor_9_2:
  if (a0 != makeint(0L)) goto get__vn__functor_9_interrupt;
  unify4(a4, a3, a2, a1, a6, a5, a8, a7);
  proceed();
 get__vn__functor_9_3:
  if (!isref(a0)) goto get__vn__functor_9_interrupt;
  deref_and_jump(a0,get__vn__functor_9_1);
  *reasonp++ =  a0;
  goto get__vn__functor_9_interrupt;
 get__vn__functor_9_ext_interrupt:
  reasonp = 0l;
 get__vn__functor_9_interrupt:
  toppred = &predicate_converter_xget__vn__functor_9;
  goto interrupt_9;
 }

 get__vn__arg_8_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 get__vn__arg_8_clear_reason:
  reasonp = reasons;
 get__vn__arg_8_0:
 get__vn__arg_8_1:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_variable_1)) goto get__vn__arg_8_2;
  allocp[0] = a4;
  x1 = arg(a2, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a5, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[2] = a6;
  allocp[3] = makeint(1L);
  allocp[4] = a7;
  allocp[5] = makesym(functor_variable_3);
  x3 = arg(a2, 0);
  allocp[6] = x3;
  allocp[7] = a6;
  allocp[8] = makesym(atom__3F);
  x2 = makefunctor(&allocp[5]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 9;
  unify_value(a3, x2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_uty_xmax_3);
  allocp[2] = a0;
  x4 = arg(a2, 0);
  allocp[3] = x4;
  allocp[4] = a1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case VARREF:
  deref_and_jump(a2,get__vn__arg_8_1);
  *reasonp++ =  a2;
  goto get__vn__arg_8_2;
  };
  goto get__vn__arg_8_2;
 get__vn__arg_8_2:
  otherwise(get__vn__arg_8_interrupt);
  x0 = a2;
  a2 = a3;
  a3 = a1;
  a1 = x0;
  execute(get__vn__goal_8_0);
  goto get__vn__goal_8_ext_interrupt;
 get__vn__arg_8_ext_interrupt:
  reasonp = 0l;
 get__vn__arg_8_interrupt:
  goto interrupt_8;
 }

 replace_2_top: {
  qp = qp->next;
 replace_2_clear_reason:
  reasonp = reasons;
 replace_2_0:
  execute(replace__modules_2_0);
  goto replace__modules_2_ext_interrupt;
 replace_2_ext_interrupt:
  reasonp = 0l;
 replace_2_interrupt:
  goto interrupt_2;
 }

 replace__modules_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  qp = qp->next;
 replace__modules_2_clear_reason:
  reasonp = reasons;
 replace__modules_2_0:
 replace__modules_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 replace__modules_2_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto replace__modules_2_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_converter_xreplace__modules_2);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = makesym(functor_module_2);
  x4 = arg(x0, 0);
  allocp[5] = x4;
  allocp[6] = x5 = makeref(&allocp[6]);
  x3 = makefunctor(&allocp[4]);
  allocp[7] = x2;
  allocp[8] = x3;
  x6 = makecons(&allocp[7]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 9;
  unify_value(a1, x6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_converter_xreplace__clauses_4);
  allocp[2] = makeint(1L);
  allocp[3] = x7 = makeref(&allocp[3]);
  x8 = arg(x0, 1);
  allocp[4] = x8;
  allocp[5] = x5;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[8] = x8;
  allocp[9] = x9 = makeref(&allocp[9]);
  allocp[10] = x7;
  qp = (struct goalrec*)&allocp[6];
  allocp += 11;
  proceed();
 case VARREF:
  deref_and_jump(x0,replace__modules_2_2);
  *reasonp++ =  x0;
  goto replace__modules_2_interrupt;
  };
  goto replace__modules_2_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto replace__modules_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,replace__modules_2_1);
  *reasonp++ =  a0;
  goto replace__modules_2_interrupt;
  };
  goto replace__modules_2_interrupt;
 replace__modules_2_ext_interrupt:
  reasonp = 0l;
 replace__modules_2_interrupt:
  toppred = &predicate_converter_xreplace__modules_2;
  goto interrupt_2;
 }

 replace__clauses_4_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 replace__clauses_4_clear_reason:
  reasonp = reasons;
 replace__clauses_4_0:
 replace__clauses_4_1:
  if (!isint(a0)) goto replace__clauses_4_7;
 replace__clauses_4_2:
  if (!isint(a1)) goto replace__clauses_4_6;
  gblt_less_or_eq(a0,a1,replace__clauses_4_5);
 replace__clauses_4_3:
  if (isref(a2)) goto replace__clauses_4_4;
  gblt_arg(a0,a2,x0,replace__clauses_4_5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_converter_xreplace__clauses_4);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x1;
  allocp[11] = x2;
  allocp[12] = x4 = makeref(&allocp[12]);
  x3 = makecons(&allocp[11]);
  qp = (struct goalrec*)&allocp[6];
  allocp += 13;
  unify_value(a3, x3);
  a0 = x0;
  a1 = x4;
  execute(replace__clause_2_0);
  goto replace__clause_2_ext_interrupt;
 replace__clauses_4_4:
  deref_and_jump(a2,replace__clauses_4_3);
  *reasonp++ =  a2;
  goto replace__clauses_4_5;
 replace__clauses_4_5:
  gblt_greater(a0,a1,replace__clauses_4_interrupt);
  x0 = NILATOM;
  unify_value(a3, x0);
  proceed();
 replace__clauses_4_6:
  if (!isref(a1)) goto replace__clauses_4_interrupt;
  deref_and_jump(a1,replace__clauses_4_2);
  *reasonp++ =  a1;
  goto replace__clauses_4_interrupt;
 replace__clauses_4_7:
  if (!isref(a0)) goto replace__clauses_4_interrupt;
  deref_and_jump(a0,replace__clauses_4_1);
  *reasonp++ =  a0;
  goto replace__clauses_4_interrupt;
 replace__clauses_4_ext_interrupt:
  reasonp = 0l;
 replace__clauses_4_interrupt:
  goto interrupt_4;
 }

 replace__clause_2_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  qp = qp->next;
 replace__clause_2_clear_reason:
  reasonp = reasons;
 replace__clause_2_0:
 replace__clause_2_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto replace__clause_2_interrupt;
 replace__clause_2_2:
  gblt_atom(a0,replace__clause_2_interrupt);
  unify_value(a1, a0);
  proceed();
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_clause_4)) goto replace__clause_2_interrupt;
  allocp[0] = makesym(functor_clause_4);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  x4 = arg(a0, 3);
  allocp[4] = x4;
  x0 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_converter_xreplace__goals_3);
  allocp[2] = makesym(atom_body);
  x5 = arg(a0, 2);
  allocp[3] = x5;
  allocp[4] = x3;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_converter_xreplace__goals_3);
  allocp[7] = makesym(atom_guard);
  x6 = arg(a0, 1);
  allocp[8] = x6;
  allocp[9] = x2;
  a1 = arg(a0, 0);
  a2 = x1;
  a0 = makesym(atom_head);
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  execute(replace__goal_3_0);
  goto replace__goal_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,replace__clause_2_1);
  *reasonp++ =  a0;
  goto replace__clause_2_interrupt;
  };
  goto replace__clause_2_interrupt;
 replace__clause_2_ext_interrupt:
  reasonp = 0l;
 replace__clause_2_interrupt:
  toppred = &predicate_converter_xreplace__clause_2;
  goto interrupt_2;
 }

 replace__goals_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 replace__goals_3_clear_reason:
  reasonp = reasons;
 replace__goals_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_converter_xreplace__goals_5);
  allocp[2] = makeint(1L);
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a0;
  allocp[5] = a1;
  allocp[6] = a2;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[9] = a1;
  allocp[10] = x1 = makeref(&allocp[10]);
  allocp[11] = x0;
  qp = (struct goalrec*)&allocp[7];
  allocp += 12;
  proceed();
 replace__goals_3_ext_interrupt:
  reasonp = 0l;
 replace__goals_3_interrupt:
  goto interrupt_3;
 }

 replace__goals_5_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 replace__goals_5_clear_reason:
  reasonp = reasons;
 replace__goals_5_0:
 replace__goals_5_1:
  if (!isint(a0)) goto replace__goals_5_5;
 replace__goals_5_2:
  if (!isint(a1)) goto replace__goals_5_4;
  gblt_less_or_eq(a0,a1,replace__goals_5_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_converter_xreplace__goals_5);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[9] = a0;
  allocp[10] = makeint(1L);
  allocp[11] = x0;
  allocp[12] = x1;
  allocp[13] = x3 = makeref(&allocp[13]);
  x2 = makecons(&allocp[12]);
  qp = (struct goalrec*)&allocp[7];
  allocp += 14;
  unify_value(a4, x2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_converter_xreplace__goal_3);
  allocp[2] = a2;
  allocp[3] = x4 = makeref(&allocp[3]);
  allocp[4] = x3;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = a0;
  allocp[8] = a3;
  allocp[9] = x4;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 replace__goals_5_3:
  gblt_greater(a0,a1,replace__goals_5_interrupt);
  x0 = NILATOM;
  unify_value(a4, x0);
  proceed();
 replace__goals_5_4:
  if (!isref(a1)) goto replace__goals_5_interrupt;
  deref_and_jump(a1,replace__goals_5_2);
  *reasonp++ =  a1;
  goto replace__goals_5_interrupt;
 replace__goals_5_5:
  if (!isref(a0)) goto replace__goals_5_interrupt;
  deref_and_jump(a0,replace__goals_5_1);
  *reasonp++ =  a0;
  goto replace__goals_5_interrupt;
 replace__goals_5_ext_interrupt:
  reasonp = 0l;
 replace__goals_5_interrupt:
  goto interrupt_5;
 }

 replace__goal_3_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  qp = qp->next;
 replace__goal_3_clear_reason:
  reasonp = reasons;
 replace__goal_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_converter_xreplace__modulename_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a2;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_converter_xreplace__functor_3);
  allocp[8] = a0;
  allocp[9] = x3 = makeref(&allocp[9]);
  allocp[10] = x0;
  allocp[11] = makesym(functor_options_2);
  allocp[12] = x1;
  allocp[13] = x2;
  x4 = makefunctor(&allocp[11]);
  allocp[14] = (q)(struct goalrec*)&allocp[6];
  allocp[15] = (q)(&predicate_parse__uty_xdecode__goal_4);
  allocp[16] = a1;
  allocp[17] = x3;
  allocp[18] = x5 = makeref(&allocp[18]);
  allocp[19] = x4;
  qp = (struct goalrec*)&allocp[14];
  allocp += 20;
  proceed();
 replace__goal_3_ext_interrupt:
  reasonp = 0l;
 replace__goal_3_interrupt:
  toppred = &predicate_converter_xreplace__goal_3;
  goto interrupt_3;
 }

 replace__funtor_3_top: {
  a2 = qp->args[2];
  qp = qp->next;
 replace__funtor_3_clear_reason:
  reasonp = reasons;
 replace__funtor_3_0:
 replace__funtor_3_1:
  switch (ptagof(a1)) {
 case ATOMIC:
 replace__funtor_3_2:
  gblt_atomic(a1,replace__funtor_3_interrupt);
  unify_value(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a1,replace__funtor_3_1);
  *reasonp++ =  a1;
  goto replace__funtor_3_interrupt;
  };
  goto replace__funtor_3_interrupt;
 replace__funtor_3_ext_interrupt:
  reasonp = 0l;
 replace__funtor_3_interrupt:
  goto interrupt_3;
 }

 replace__functor_3_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  qp = qp->next;
 replace__functor_3_clear_reason:
  reasonp = reasons;
 replace__functor_3_0:
 replace__functor_3_1:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_variable_3)) goto replace__functor_3_2;
  allocp[0] = makesym(functor_variable_1);
  x1 = arg(a1, 0);
  allocp[1] = x1;
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,replace__functor_3_1);
  *reasonp++ =  a1;
  goto replace__functor_3_2;
  };
  goto replace__functor_3_2;
 replace__functor_3_2:
  otherwise(replace__functor_3_interrupt);
 replace__functor_3_3:
  if (isref(a1)) goto replace__functor_3_4;
  gblt_pfunctor(a1,x0,replace__functor_3_interrupt);
  gblt_arity(a1,x1,replace__functor_3_interrupt);
  x2 = a1;
  a3 = a2;
  a2 = x2;
  a1 = x1;
  execute(replace__args_4_0);
  goto replace__args_4_ext_interrupt;
 replace__functor_3_4:
  deref_and_jump(a1,replace__functor_3_3);
  *reasonp++ =  a1;
  goto replace__functor_3_interrupt;
 replace__functor_3_ext_interrupt:
  reasonp = 0l;
 replace__functor_3_interrupt:
  goto interrupt_3;
 }

 replace__args_4_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 replace__args_4_clear_reason:
  reasonp = reasons;
 replace__args_4_0:
 replace__args_4_1:
  if (!isint(a1)) goto replace__args_4_3;
  x0 = makeint(0L);
  gblt_greater(a1,x0,replace__args_4_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_converter_xreplace__args_4);
  allocp[2] = a0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a1;
  allocp[9] = makeint(1L);
  allocp[10] = x1;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[13] = a1;
  allocp[14] = a2;
  allocp[15] = x3 = makeref(&allocp[15]);
  allocp[16] = x2;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_converter_xreplace__functor_3);
  allocp[19] = a0;
  allocp[20] = x4 = makeref(&allocp[20]);
  allocp[21] = x3;
  allocp[22] = (q)(struct goalrec*)&allocp[17];
  allocp[23] = (q)(&predicate_functor__table_xarg_3);
  allocp[24] = a1;
  allocp[25] = a2;
  allocp[26] = x4;
  qp = (struct goalrec*)&allocp[22];
  allocp += 27;
  proceed();
 replace__args_4_2:
  if (a1 != makeint(0L)) goto replace__args_4_interrupt;
  unify(a3, a2);
  proceed();
 replace__args_4_3:
  if (!isref(a1)) goto replace__args_4_interrupt;
  deref_and_jump(a1,replace__args_4_1);
  *reasonp++ =  a1;
  goto replace__args_4_interrupt;
 replace__args_4_ext_interrupt:
  reasonp = 0l;
 replace__args_4_interrupt:
  toppred = &predicate_converter_xreplace__args_4;
  goto interrupt_4;
 }

 replace__modulename_4_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 replace__modulename_4_clear_reason:
  reasonp = reasons;
 replace__modulename_4_0:
 replace__modulename_4_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom___)) goto replace__modulename_4_5;
 replace__modulename_4_2:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto replace__modulename_4_4;
 replace__modulename_4_3:
  gblt_atom(a0,replace__modulename_4_4);
  allocp[0] = makesym(functor_functor_1);
  allocp[1] = a0;
  x0 = makefunctor(&allocp[0]);
  a0 = x0;
  a1 = a2;
  a2 = a3;
  allocp += 2;
  execute(replace__pragma_3_0);
  goto replace__pragma_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,replace__modulename_4_2);
  *reasonp++ =  a0;
  goto replace__modulename_4_5;
  };
  goto replace__modulename_4_4;
 replace__modulename_4_4:
  gblt_pfunctor(a0,x0,replace__modulename_4_5);
  gblt_arity(a0,x1,replace__modulename_4_5);
  allocp[0] = makesym(functor_functor_1);
  allocp[1] = a0;
  x2 = makefunctor(&allocp[0]);
  a0 = x2;
  a1 = a2;
  a2 = a3;
  allocp += 2;
  execute(replace__pragma_3_0);
  goto replace__pragma_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,replace__modulename_4_1);
  *reasonp++ =  a1;
  goto replace__modulename_4_5;
  };
  goto replace__modulename_4_5;
 replace__modulename_4_5:
  otherwise(replace__modulename_4_interrupt);
 replace__modulename_4_6:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto replace__modulename_4_8;
 replace__modulename_4_7:
  gblt_atom(a0,replace__modulename_4_8);
  allocp[0] = makesym(functor_atom_1);
  allocp[1] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_functor_1);
  allocp[3] = a0;
  x1 = makefunctor(&allocp[2]);
  allocp[4] = makesym(functor__3A_2);
  allocp[5] = x0;
  allocp[6] = x1;
  x2 = makefunctor(&allocp[4]);
  allocp[7] = makesym(functor_functor_1);
  allocp[8] = x2;
  x3 = makefunctor(&allocp[7]);
  a0 = x3;
  a1 = a2;
  a2 = a3;
  allocp += 9;
  execute(replace__pragma_3_0);
  goto replace__pragma_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,replace__modulename_4_6);
  *reasonp++ =  a0;
  goto replace__modulename_4_interrupt;
  };
  goto replace__modulename_4_8;
 replace__modulename_4_8:
  gblt_pfunctor(a0,x0,replace__modulename_4_interrupt);
  gblt_arity(a0,x1,replace__modulename_4_interrupt);
  allocp[0] = makesym(functor_atom_1);
  allocp[1] = a1;
  x2 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_functor_1);
  allocp[3] = a0;
  x3 = makefunctor(&allocp[2]);
  allocp[4] = makesym(functor__3A_2);
  allocp[5] = x2;
  allocp[6] = x3;
  x4 = makefunctor(&allocp[4]);
  allocp[7] = makesym(functor_functor_1);
  allocp[8] = x4;
  x5 = makefunctor(&allocp[7]);
  a0 = x5;
  a1 = a2;
  a2 = a3;
  allocp += 9;
  execute(replace__pragma_3_0);
  goto replace__pragma_3_ext_interrupt;
 replace__modulename_4_ext_interrupt:
  reasonp = 0l;
 replace__modulename_4_interrupt:
  goto interrupt_4;
 }

 replace__pragma_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 replace__pragma_3_clear_reason:
  reasonp = reasons;
 replace__pragma_3_0:
 replace__pragma_3_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom___)) goto replace__pragma_3_3;
  unify(a2, a0);
  proceed();
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_atom_1)) goto replace__pragma_3_3;
  x0 = arg(a1, 0);
 replace__pragma_3_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_shared)) goto replace__pragma_3_3;
  unify(a2, a0);
  proceed();
 case VARREF:
  deref_and_jump(x0,replace__pragma_3_2);
  *reasonp++ =  x0;
  goto replace__pragma_3_3;
  };
  goto replace__pragma_3_3;
 case VARREF:
  deref_and_jump(a1,replace__pragma_3_1);
  *reasonp++ =  a1;
  goto replace__pragma_3_3;
  };
  goto replace__pragma_3_3;
 replace__pragma_3_3:
  otherwise(replace__pragma_3_interrupt);
  allocp[0] = makesym(functor__40_2);
  allocp[1] = a0;
  allocp[2] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_functor_1);
  allocp[4] = x0;
  x1 = makefunctor(&allocp[3]);
  allocp += 5;
  unify_value(a2, x1);
  proceed();
 replace__pragma_3_ext_interrupt:
  reasonp = 0l;
 replace__pragma_3_interrupt:
  toppred = &predicate_converter_xreplace__pragma_3;
  goto interrupt_3;
 }
 interrupt_9:
  allocp[10] = a8;
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_converter);
}
