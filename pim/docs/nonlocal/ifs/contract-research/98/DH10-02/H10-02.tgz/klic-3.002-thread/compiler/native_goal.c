/* Compiled by KLIC compiler version 3.002 (Wed Sep 17 15:37:13 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_native__goal();
Const struct predicate predicate_native__goal_xcheck__sequential_2 =
   { module_native__goal, 0, 2 };
Const struct predicate predicate_native__goal_xmodules_3 =
   { module_native__goal, 1, 3 };
Const struct predicate predicate_native__goal_xclauses_4 =
   { module_native__goal, 2, 4 };
Const struct predicate predicate_native__goal_xclause_3 =
   { module_native__goal, 3, 3 };
Const struct predicate predicate_native__goal_xbodys_6 =
   { module_native__goal, 4, 6 };
Const struct predicate predicate_native__goal_xbody_6 =
   { module_native__goal, 5, 6 };
Const struct predicate predicate_native__goal_xcheck__builtin_8 =
   { module_native__goal, 6, 8 };
Const struct predicate predicate_native__goal_xcheck__sequential__builtin_3 =
   { module_native__goal, 7, 3 };
Const struct predicate predicate_native__goal_xcheck__list_3 =
   { module_native__goal, 8, 3 };
extern Const struct predicate predicate_integer__arithmetics_xadd_3;
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_xsetarg_4;
extern Const struct predicate predicate_functor__table_xfunctor_3;
extern Const struct predicate predicate_parse__uty_xdecode__goal_4;
extern Const struct predicate predicate_parse__uty_xencode__goal_4;

module module_native__goal(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  static Const q funct_const_0[] = {
    makesym(functor_pred_2),
    makesym(atom_report__measure),
    makeint(1),
  };
  static Const q cons_const_1[] = {
    NILATOM,
    makefunctor(funct_const_0),
  };
  static Const q funct_const_2[] = {
    makesym(functor_pred_2),
    makesym(atom_start__measure),
    makeint(0),
  };
  static Const q cons_const_3[] = {
    makecons(cons_const_1),
    makefunctor(funct_const_2),
  };
  static Const q funct_const_4[] = {
    makesym(functor_pred_2),
    makesym(atom_divide),
    makeint(3),
  };
  static Const q cons_const_5[] = {
    makecons(cons_const_3),
    makefunctor(funct_const_4),
  };
  static Const q funct_const_6[] = {
    makesym(functor_pred_2),
    makesym(atom_multiply),
    makeint(3),
  };
  static Const q cons_const_7[] = {
    makecons(cons_const_5),
    makefunctor(funct_const_6),
  };
  static Const q funct_const_8[] = {
    makesym(functor_pred_2),
    makesym(atom_subtract),
    makeint(3),
  };
  static Const q cons_const_9[] = {
    makecons(cons_const_7),
    makefunctor(funct_const_8),
  };
  static Const q funct_const_10[] = {
    makesym(functor_pred_2),
    makesym(atom_add),
    makeint(3),
  };
  static Const q cons_const_11[] = {
    makecons(cons_const_9),
    makefunctor(funct_const_10),
  };
  static Const q funct_const_12[] = {
    makesym(functor_pred_2),
    makesym(atom_outstream),
    makeint(1),
  };
  static Const q cons_const_13[] = {
    makecons(cons_const_11),
    makefunctor(funct_const_12),
  };
  static Const q funct_const_14[] = {
    makesym(functor_atom_1),
    makesym(atom_sequential),
  };
  q a0, a1, a2, a3, a4, a5, a6, a7;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, check__sequential_2_top);
    case_pred(1, modules_3_top);
    case_pred(2, clauses_4_top);
    case_pred(3, clause_3_top);
    case_pred(4, bodys_6_top);
    case_pred(5, body_6_top);
    case_pred(6, check__builtin_8_top);
    case_pred(7, check__sequential__builtin_3_top);
    last_case_pred(8, check__list_3_top);
  }

 check__sequential_2_top: {
  q x0;
  qp = qp->next;
 check__sequential_2_clear_reason:
  reasonp = reasons;
 check__sequential_2_0:
  x0 = makecons(cons_const_13);
  a2 = x0;
  execute(modules_3_0);
  goto modules_3_ext_interrupt;
 check__sequential_2_ext_interrupt:
  reasonp = 0l;
 check__sequential_2_interrupt:
  goto interrupt_2;
 }

 modules_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  qp = qp->next;
 modules_3_clear_reason:
  reasonp = reasons;
 modules_3_0:
 modules_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 modules_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto modules_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_native__goal_xmodules_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = makesym(functor_module_2);
  x4 = arg(x0, 0);
  allocp[6] = x4;
  allocp[7] = x5 = makeref(&allocp[7]);
  x3 = makefunctor(&allocp[5]);
  allocp[8] = x2;
  allocp[9] = x3;
  x6 = makecons(&allocp[8]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  unify_value(a1, x6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_native__goal_xclauses_4);
  allocp[2] = x7 = makeref(&allocp[2]);
  x8 = arg(x0, 1);
  allocp[3] = x8;
  allocp[4] = x5;
  allocp[5] = a2;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[8] = x8;
  allocp[9] = x9 = makeref(&allocp[9]);
  allocp[10] = x7;
  qp = (struct goalrec*)&allocp[6];
  allocp += 11;
  proceed();
 case VARREF:
  deref_and_jump(x0,modules_3_2);
  *reasonp++ =  x0;
  goto modules_3_interrupt;
  };
  goto modules_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto modules_3_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,modules_3_1);
  *reasonp++ =  a0;
  goto modules_3_interrupt;
  };
  goto modules_3_interrupt;
 modules_3_ext_interrupt:
  reasonp = 0l;
 modules_3_interrupt:
  toppred = &predicate_native__goal_xmodules_3;
  goto interrupt_3;
 }

 clauses_4_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 clauses_4_clear_reason:
  reasonp = reasons;
 clauses_4_0:
 clauses_4_1:
  if (!isint(a0)) goto clauses_4_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,clauses_4_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_native__goal_xclauses_4);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x1;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[13] = a0;
  allocp[14] = a1;
  allocp[15] = x3 = makeref(&allocp[15]);
  allocp[16] = x2;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_native__goal_xclause_3);
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = x3;
  allocp[21] = a3;
  allocp[22] = (q)(struct goalrec*)&allocp[17];
  allocp[23] = (q)(&predicate_functor__table_xarg_3);
  allocp[24] = a0;
  allocp[25] = a1;
  allocp[26] = x4;
  qp = (struct goalrec*)&allocp[22];
  allocp += 27;
  proceed();
 clauses_4_2:
  if (a0 != makeint(0L)) goto clauses_4_interrupt;
  unify(a2, a1);
  proceed();
 clauses_4_3:
  if (!isref(a0)) goto clauses_4_interrupt;
  deref_and_jump(a0,clauses_4_1);
  *reasonp++ =  a0;
  goto clauses_4_interrupt;
 clauses_4_ext_interrupt:
  reasonp = 0l;
 clauses_4_interrupt:
  goto interrupt_4;
 }

 clause_3_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  qp = qp->next;
 clause_3_clear_reason:
  reasonp = reasons;
 clause_3_0:
 clause_3_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_clause_4)) goto clause_3_2;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = makeint(3L);
  allocp[3] = a0;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = a1;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_native__goal_xbodys_6);
  allocp[8] = makeint(1L);
  allocp[9] = makesym(atom_no);
  allocp[10] = x1 = makeref(&allocp[10]);
  x2 = arg(a0, 2);
  allocp[11] = x2;
  allocp[12] = x0;
  allocp[13] = a2;
  allocp[14] = (q)(struct goalrec*)&allocp[6];
  allocp[15] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[16] = x2;
  allocp[17] = x3 = makeref(&allocp[17]);
  allocp[18] = x1;
  qp = (struct goalrec*)&allocp[14];
  allocp += 19;
  proceed();
 case VARREF:
  deref_and_jump(a0,clause_3_1);
  *reasonp++ =  a0;
  goto clause_3_2;
  };
  goto clause_3_2;
 clause_3_2:
  otherwise(clause_3_interrupt);
  unify(a1, a0);
  proceed();
 clause_3_ext_interrupt:
  reasonp = 0l;
 clause_3_interrupt:
  goto interrupt_3;
 }

 bodys_6_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 bodys_6_clear_reason:
  reasonp = reasons;
 bodys_6_0:
 bodys_6_1:
  if (!isint(a0)) goto bodys_6_5;
 bodys_6_2:
  if (!isint(a2)) goto bodys_6_4;
  gblt_less_or_eq(a0,a2,bodys_6_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_native__goal_xbodys_6);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[10] = a0;
  allocp[11] = makeint(1L);
  allocp[12] = x0;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[15] = a0;
  allocp[16] = a3;
  allocp[17] = x3 = makeref(&allocp[17]);
  allocp[18] = x2;
  allocp[19] = (q)(struct goalrec*)&allocp[13];
  allocp[20] = (q)(&predicate_native__goal_xbody_6);
  allocp[21] = x4 = makeref(&allocp[21]);
  allocp[22] = x3;
  allocp[23] = a1;
  allocp[24] = x1;
  allocp[25] = a5;
  allocp[26] = a0;
  allocp[27] = (q)(struct goalrec*)&allocp[19];
  allocp[28] = (q)(&predicate_functor__table_xarg_3);
  allocp[29] = a0;
  allocp[30] = a3;
  allocp[31] = x4;
  qp = (struct goalrec*)&allocp[27];
  allocp += 32;
  proceed();
 bodys_6_3:
  gblt_greater(a0,a2,bodys_6_interrupt);
  unify(a4, a3);
  proceed();
 bodys_6_4:
  if (!isref(a2)) goto bodys_6_interrupt;
  deref_and_jump(a2,bodys_6_2);
  *reasonp++ =  a2;
  goto bodys_6_interrupt;
 bodys_6_5:
  if (!isref(a0)) goto bodys_6_interrupt;
  deref_and_jump(a0,bodys_6_1);
  *reasonp++ =  a0;
  goto bodys_6_interrupt;
 bodys_6_ext_interrupt:
  reasonp = 0l;
 bodys_6_interrupt:
  goto interrupt_6;
 }

 body_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 body_6_clear_reason:
  reasonp = reasons;
 body_6_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_parse__uty_xencode__goal_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a1;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[8] = makeint(2L);
  allocp[9] = x3 = makeref(&allocp[9]);
  allocp[10] = x4 = makeref(&allocp[10]);
  allocp[11] = x2;
  allocp[12] = (q)(struct goalrec*)&allocp[6];
  allocp[13] = (q)(&predicate_native__goal_xcheck__builtin_8);
  allocp[14] = x0;
  allocp[15] = x5 = makeref(&allocp[15]);
  allocp[16] = x6 = makeref(&allocp[16]);
  allocp[17] = x4;
  allocp[18] = a2;
  allocp[19] = a3;
  allocp[20] = a4;
  allocp[21] = a5;
  allocp[22] = makesym(functor_options_2);
  allocp[23] = x8 = makeref(&allocp[23]);
  allocp[24] = x6;
  x7 = makefunctor(&allocp[22]);
  qp = (struct goalrec*)&allocp[12];
  allocp += 25;
  unify_value(x3, x7);
  unify(x1, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_parse__uty_xdecode__goal_4);
  allocp[2] = a0;
  allocp[3] = x0;
  allocp[4] = x1;
  allocp[5] = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  proceed();
 body_6_ext_interrupt:
  reasonp = 0l;
 body_6_interrupt:
  goto interrupt_6;
 }

 check__builtin_8_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 check__builtin_8_clear_reason:
  reasonp = reasons;
 check__builtin_8_0:
 check__builtin_8_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (isint(a1)) goto check__builtin_8_4;
  switch (symval(a1)) {
 case symval(makesym(atom_userdef)):
  unify(a3, a2);
  x0 = makesym(atom_yes);
  unify_value(a5, x0);
  proceed();
 case symval(makesym(atom_builtin)):
 check__builtin_8_2:
  switch (ptagof(a4)) {
 case ATOMIC:
  if (a4 != makesym(atom_yes)) goto check__builtin_8_4;
 check__builtin_8_3:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom___)) goto check__builtin_8_4;
  unify_value(a5, a4);
  a1 = a3;
  a2 = a6;
  execute(check__sequential__builtin_3_0);
  goto check__sequential__builtin_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,check__builtin_8_3);
  *reasonp++ =  a2;
  goto check__builtin_8_4;
  };
  goto check__builtin_8_4;
 case VARREF:
  deref_and_jump(a4,check__builtin_8_2);
  *reasonp++ =  a4;
  goto check__builtin_8_4;
  };
  goto check__builtin_8_4;
  };
  goto check__builtin_8_4;
 case VARREF:
  deref_and_jump(a1,check__builtin_8_1);
  *reasonp++ =  a1;
  goto check__builtin_8_4;
  };
  goto check__builtin_8_4;
 check__builtin_8_4:
  otherwise(check__builtin_8_interrupt);
  unify2(a3, a2, a5, a4);
  proceed();
 check__builtin_8_ext_interrupt:
  reasonp = 0l;
 check__builtin_8_interrupt:
  goto interrupt_8;
 }

 check__sequential__builtin_3_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  qp = qp->next;
 check__sequential__builtin_3_clear_reason:
  reasonp = reasons;
 check__sequential__builtin_3_0:
 check__sequential__builtin_3_1:
  if (isref(a0)) goto check__sequential__builtin_3_2;
  gblt_pfunctor(a0,x0,check__sequential__builtin_3_interrupt);
  gblt_arity(a0,x1,check__sequential__builtin_3_interrupt);
  allocp[0] = makesym(functor_pred_2);
  allocp[1] = x0;
  allocp[2] = x1;
  x2 = makefunctor(&allocp[0]);
  a0 = a2;
  a2 = a1;
  a1 = x2;
  allocp += 3;
  execute(check__list_3_0);
  goto check__list_3_ext_interrupt;
 check__sequential__builtin_3_2:
  deref_and_jump(a0,check__sequential__builtin_3_1);
  *reasonp++ =  a0;
  goto check__sequential__builtin_3_interrupt;
 check__sequential__builtin_3_ext_interrupt:
  reasonp = 0l;
 check__sequential__builtin_3_interrupt:
  toppred = &predicate_native__goal_xcheck__sequential__builtin_3;
  goto interrupt_3;
 }

 check__list_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 check__list_3_clear_reason:
  reasonp = reasons;
 check__list_3_0:
 check__list_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 check__list_3_2:
  if (isref(x0)) goto check__list_3_5;
 check__list_3_3:
  if (isref(x0)) goto check__list_3_4;
  if_not_equal(x0, a1, check__list_3_6);
  x1 = makefunctor(funct_const_14);
  unify_value(a2, x1);
  proceed();
 check__list_3_4:
  deref_and_jump(x0,check__list_3_3);
  *reasonp++ =  x0;
  goto check__list_3_6;
 check__list_3_5:
  deref_and_jump(x0,check__list_3_2);
  *reasonp++ =  x0;
  goto check__list_3_6;
 case VARREF:
  deref_and_jump(a0,check__list_3_1);
  *reasonp++ =  a0;
  goto check__list_3_6;
  };
  goto check__list_3_6;
 check__list_3_6:
  otherwise(check__list_3_interrupt);
 check__list_3_7:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(check__list_3_0);
  goto check__list_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto check__list_3_interrupt;
  x0 = makesym(atom___);
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,check__list_3_7);
  *reasonp++ =  a0;
  goto check__list_3_interrupt;
  };
  goto check__list_3_interrupt;
 check__list_3_ext_interrupt:
  reasonp = 0l;
 check__list_3_interrupt:
  toppred = &predicate_native__goal_xcheck__list_3;
  goto interrupt_3;
 }
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_native__goal);
}
