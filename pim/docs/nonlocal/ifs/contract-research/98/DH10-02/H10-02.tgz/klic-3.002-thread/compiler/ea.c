/* Compiled by KLIC compiler version 3.002 (Wed Sep 17 15:37:13 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_ea();
Const struct predicate predicate_ea_xmake_2 =
   { module_ea, 0, 2 };
Const struct predicate predicate_ea_xmake__heads_3 =
   { module_ea, 1, 3 };
Const struct predicate predicate_ea_xmake__heads__clauses_5 =
   { module_ea, 2, 5 };
Const struct predicate predicate_ea_xadd__pred_3 =
   { module_ea, 3, 3 };
Const struct predicate predicate_ea_xcheck__mn_3 =
   { module_ea, 4, 3 };
Const struct predicate predicate_ea_xcheck__mn2_3 =
   { module_ea, 5, 3 };
Const struct predicate predicate_ea_xmake_3 =
   { module_ea, 6, 3 };
Const struct predicate predicate_ea_xmake__clauses_5 =
   { module_ea, 7, 5 };
Const struct predicate predicate_ea_xmake__bodys_6 =
   { module_ea, 8, 6 };
Const struct predicate predicate_ea_xmake__body_8 =
   { module_ea, 9, 8 };
Const struct predicate predicate_ea_xcheck__ea_9 =
   { module_ea, 10, 9 };
Const struct predicate predicate_ea_xcheck__pred_8 =
   { module_ea, 11, 8 };
Const struct predicate predicate_ea_xmake__entry_7 =
   { module_ea, 12, 7 };
Const struct predicate predicate_ea_xmake__args_4 =
   { module_ea, 13, 4 };
extern Const struct predicate predicate_functor_xinsert__arg_4;
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_xfunctor_3;
extern Const struct predicate predicate_parse__uty_xdecode__goal_4;
extern Const struct predicate predicate_parse__uty_xdecode__goalcall_6;

module module_ea(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  q a0, a1, a2, a3, a4, a5, a6, a7, a8;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, make_2_top);
    case_pred(1, make__heads_3_top);
    case_pred(2, make__heads__clauses_5_top);
    case_pred(3, add__pred_3_top);
    case_pred(4, check__mn_3_top);
    case_pred(5, check__mn2_3_top);
    case_pred(6, make_3_top);
    case_pred(7, make__clauses_5_top);
    case_pred(8, make__bodys_6_top);
    case_pred(9, make__body_8_top);
    case_pred(10, check__ea_9_top);
    case_pred(11, check__pred_8_top);
    case_pred(12, make__entry_7_top);
    last_case_pred(13, make__args_4_top);
  }

 make_2_top: {
  q x0, x1;
  qp = qp->next;
 make_2_clear_reason:
  reasonp = reasons;
 make_2_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ea_xmake__heads_3);
  allocp[2] = a0;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a1;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_ea_xcheck__mn_3);
  allocp[7] = a0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x0;
  a1 = NILATOM;
  a2 = x1;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  execute(make_3_0);
  goto make_3_ext_interrupt;
 make_2_ext_interrupt:
  reasonp = 0l;
 make_2_interrupt:
  goto interrupt_2;
 }

 make__heads_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  qp = qp->next;
 make__heads_3_clear_reason:
  reasonp = reasons;
 make__heads_3_0:
 make__heads_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 make__heads_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto make__heads_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ea_xmake__heads_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = makesym(functor_module_3);
  x4 = arg(x0, 0);
  allocp[6] = x4;
  allocp[7] = x5 = makeref(&allocp[7]);
  allocp[8] = NILATOM;
  x3 = makefunctor(&allocp[5]);
  allocp[9] = a1;
  allocp[10] = x3;
  x6 = makecons(&allocp[9]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 11;
  unify_value(x2, x6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ea_xmake__heads__clauses_5);
  allocp[2] = x7 = makeref(&allocp[2]);
  x8 = arg(x0, 1);
  allocp[3] = x8;
  x9 = arg(x0, 0);
  allocp[4] = x9;
  allocp[5] = NILATOM;
  allocp[6] = x5;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[9] = x8;
  allocp[10] = x10 = makeref(&allocp[10]);
  allocp[11] = x7;
  qp = (struct goalrec*)&allocp[7];
  allocp += 12;
  proceed();
 case VARREF:
  deref_and_jump(x0,make__heads_3_2);
  *reasonp++ =  x0;
  goto make__heads_3_interrupt;
  };
  goto make__heads_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto make__heads_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,make__heads_3_1);
  *reasonp++ =  a0;
  goto make__heads_3_interrupt;
  };
  goto make__heads_3_interrupt;
 make__heads_3_ext_interrupt:
  reasonp = 0l;
 make__heads_3_interrupt:
  goto interrupt_3;
 }

 make__heads__clauses_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 make__heads__clauses_5_clear_reason:
  reasonp = reasons;
 make__heads__clauses_5_0:
 make__heads__clauses_5_1:
  if (!isint(a0)) goto make__heads__clauses_5_5;
 make__heads__clauses_5_2:
  if (isref(a1)) goto make__heads__clauses_5_4;
  gblt_arg(a0,a1,x0,make__heads__clauses_5_6);
 make__heads__clauses_5_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_clause_4)) goto make__heads__clauses_5_6;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ea_xmake__heads__clauses_5);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[9] = a0;
  allocp[10] = makeint(1L);
  allocp[11] = x1;
  allocp[12] = makesym(functor_entries_1);
  allocp[13] = x4 = makeref(&allocp[13]);
  x3 = makefunctor(&allocp[12]);
  allocp[14] = makesym(functor_pred_3);
  allocp[15] = x6 = makeref(&allocp[15]);
  allocp[16] = x7 = makeref(&allocp[16]);
  allocp[17] = x3;
  x5 = makefunctor(&allocp[14]);
  allocp[18] = (q)(struct goalrec*)&allocp[7];
  allocp[19] = (q)(&predicate_ea_xadd__pred_3);
  allocp[20] = x5;
  allocp[21] = a3;
  allocp[22] = x2;
  allocp[23] = (q)(struct goalrec*)&allocp[18];
  allocp[24] = (q)(&predicate_ea_xmake__entry_7);
  allocp[25] = x7;
  allocp[26] = a2;
  allocp[27] = a0;
  allocp[28] = makesym(atom_head);
  allocp[29] = makeint(1L);
  allocp[30] = x8 = makeref(&allocp[30]);
  allocp[31] = x4;
  allocp[32] = (q)(struct goalrec*)&allocp[23];
  allocp[33] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[34] = x8;
  allocp[35] = x6;
  allocp[36] = x7;
  allocp[37] = (q)(struct goalrec*)&allocp[32];
  allocp[38] = (q)(&predicate_parse__uty_xdecode__goal_4);
  x9 = arg(x0, 0);
  allocp[39] = x9;
  allocp[40] = x8;
  allocp[41] = x10 = makeref(&allocp[41]);
  allocp[42] = x11 = makeref(&allocp[42]);
  qp = (struct goalrec*)&allocp[37];
  allocp += 43;
  proceed();
 case VARREF:
  deref_and_jump(x0,make__heads__clauses_5_3);
  *reasonp++ =  x0;
  goto make__heads__clauses_5_6;
  };
  goto make__heads__clauses_5_6;
 make__heads__clauses_5_4:
  deref_and_jump(a1,make__heads__clauses_5_2);
  *reasonp++ =  a1;
  goto make__heads__clauses_5_6;
 make__heads__clauses_5_5:
  if (!isref(a0)) goto make__heads__clauses_5_6;
  deref_and_jump(a0,make__heads__clauses_5_1);
  *reasonp++ =  a0;
  goto make__heads__clauses_5_6;
 make__heads__clauses_5_6:
  otherwise(make__heads__clauses_5_interrupt);
 make__heads__clauses_5_7:
  if (!isint(a0)) goto make__heads__clauses_5_9;
  x0 = makeint(0L);
  gblt_greater(a0,x0,make__heads__clauses_5_8);
  x1 = makeint(1L);
  bblt_sub_no_check(a0,x1,x2);
  a0 = x2;
  execute(make__heads__clauses_5_0);
  goto make__heads__clauses_5_ext_interrupt;
 make__heads__clauses_5_8:
  if (a0 != makeint(0L)) goto make__heads__clauses_5_interrupt;
  unify(a4, a3);
  proceed();
 make__heads__clauses_5_9:
  if (!isref(a0)) goto make__heads__clauses_5_interrupt;
  deref_and_jump(a0,make__heads__clauses_5_7);
  *reasonp++ =  a0;
  goto make__heads__clauses_5_interrupt;
 make__heads__clauses_5_ext_interrupt:
  reasonp = 0l;
 make__heads__clauses_5_interrupt:
  goto interrupt_5;
 }

 add__pred_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a2 = qp->args[2];
  qp = qp->next;
 add__pred_3_clear_reason:
  reasonp = reasons;
 add__pred_3_0:
 add__pred_3_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_pred_3)) goto add__pred_3_13;
  x0 = arg(a0, 2);
 add__pred_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_entries_1)) goto add__pred_3_13;
 add__pred_3_3:
  switch (ptagof(a1)) {
 case CONS:
  x1 = car_of(a1);
 add__pred_3_4:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_pred_3)) goto add__pred_3_13;
  x2 = arg(x1, 0);
 add__pred_3_5:
  if (isref(x2)) goto add__pred_3_12;
 add__pred_3_6:
  if (isref(x2)) goto add__pred_3_11;
  x3 = arg(a0, 0);
  if_not_equal(x2, x3, add__pred_3_13);
  x4 = arg(x1, 1);
 add__pred_3_7:
  if (isref(x4)) goto add__pred_3_10;
 add__pred_3_8:
  if (isref(x4)) goto add__pred_3_9;
  x5 = arg(a0, 1);
  if_not_equal(x4, x5, add__pred_3_13);
  allocp[0] = makesym(functor_pred_3);
  allocp[1] = x3;
  allocp[2] = x5;
  allocp[3] = x7 = makeref(&allocp[3]);
  x6 = makefunctor(&allocp[0]);
  x9 = cdr_of(a1);
  allocp[4] = x9;
  allocp[5] = x6;
  x8 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a2, x8);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor_xinsert__arg_4);
  allocp[2] = makeint(1L);
  x10 = arg(x1, 2);
  allocp[3] = x10;
  x11 = arg(x0, 0);
  allocp[4] = x11;
  allocp[5] = x7;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  proceed();
 add__pred_3_9:
  deref_and_jump(x4,add__pred_3_8);
  *reasonp++ =  x4;
  goto add__pred_3_13;
 add__pred_3_10:
  deref_and_jump(x4,add__pred_3_7);
  *reasonp++ =  x4;
  goto add__pred_3_13;
 add__pred_3_11:
  deref_and_jump(x2,add__pred_3_6);
  *reasonp++ =  x2;
  goto add__pred_3_13;
 add__pred_3_12:
  deref_and_jump(x2,add__pred_3_5);
  *reasonp++ =  x2;
  goto add__pred_3_13;
 case VARREF:
  deref_and_jump(x1,add__pred_3_4);
  *reasonp++ =  x1;
  goto add__pred_3_13;
  };
  goto add__pred_3_13;
 case VARREF:
  deref_and_jump(a1,add__pred_3_3);
  *reasonp++ =  a1;
  goto add__pred_3_13;
  };
  goto add__pred_3_13;
 case VARREF:
  deref_and_jump(x0,add__pred_3_2);
  *reasonp++ =  x0;
  goto add__pred_3_13;
  };
  goto add__pred_3_13;
 case VARREF:
  deref_and_jump(a0,add__pred_3_1);
  *reasonp++ =  a0;
  goto add__pred_3_13;
  };
  goto add__pred_3_13;
 add__pred_3_13:
  otherwise(add__pred_3_interrupt);
 add__pred_3_14:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a1);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  a1 = cdr_of(a1);
  a2 = x1;
  execute(add__pred_3_0);
  goto add__pred_3_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto add__pred_3_interrupt;
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,add__pred_3_14);
  *reasonp++ =  a1;
  goto add__pred_3_interrupt;
  };
  goto add__pred_3_interrupt;
 add__pred_3_ext_interrupt:
  reasonp = 0l;
 add__pred_3_interrupt:
  goto interrupt_3;
 }

 check__mn_3_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  qp = qp->next;
 check__mn_3_clear_reason:
  reasonp = reasons;
 check__mn_3_0:
 check__mn_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 check__mn_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto check__mn_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ea_xcheck__mn_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  a0 = arg(x0, 0);
  a2 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(check__mn2_3_0);
  goto check__mn2_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,check__mn_3_2);
  *reasonp++ =  x0;
  goto check__mn_3_interrupt;
  };
  goto check__mn_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto check__mn_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,check__mn_3_1);
  *reasonp++ =  a0;
  goto check__mn_3_interrupt;
  };
  goto check__mn_3_interrupt;
 check__mn_3_ext_interrupt:
  reasonp = 0l;
 check__mn_3_interrupt:
  goto interrupt_3;
 }

 check__mn2_3_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  qp = qp->next;
 check__mn2_3_clear_reason:
  reasonp = reasons;
 check__mn2_3_0:
 check__mn2_3_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 check__mn2_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_3)) goto check__mn2_3_7;
  x1 = arg(x0, 0);
 check__mn2_3_3:
  if (isref(x1)) goto check__mn2_3_6;
 check__mn2_3_4:
  if (isref(x1)) goto check__mn2_3_5;
  if_not_equal(x1, a0, check__mn2_3_7);
  a1 = cdr_of(a1);
  execute(check__mn2_3_clear_reason);
  goto check__mn2_3_ext_interrupt;
 check__mn2_3_5:
  deref_and_jump(x1,check__mn2_3_4);
  *reasonp++ =  x1;
  goto check__mn2_3_7;
 check__mn2_3_6:
  deref_and_jump(x1,check__mn2_3_3);
  *reasonp++ =  x1;
  goto check__mn2_3_7;
 case VARREF:
  deref_and_jump(x0,check__mn2_3_2);
  *reasonp++ =  x0;
  goto check__mn2_3_7;
  };
  goto check__mn2_3_7;
 case VARREF:
  deref_and_jump(a1,check__mn2_3_1);
  *reasonp++ =  a1;
  goto check__mn2_3_7;
  };
  goto check__mn2_3_7;
 check__mn2_3_7:
  otherwise(check__mn2_3_interrupt);
 check__mn2_3_8:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a1);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  a1 = cdr_of(a1);
  a2 = x1;
  execute(check__mn2_3_0);
  goto check__mn2_3_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto check__mn2_3_interrupt;
  unify_value(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a1,check__mn2_3_8);
  *reasonp++ =  a1;
  goto check__mn2_3_interrupt;
  };
  goto check__mn2_3_interrupt;
 check__mn2_3_ext_interrupt:
  reasonp = 0l;
 check__mn2_3_interrupt:
  toppred = &predicate_ea_xcheck__mn2_3;
  goto interrupt_3;
 }

 make_3_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  qp = qp->next;
 make_3_clear_reason:
  reasonp = reasons;
 make_3_0:
 make_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 make_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto make_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ea_xmake_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_ea_xmake__clauses_5);
  allocp[7] = x3 = makeref(&allocp[7]);
  x4 = arg(x0, 1);
  allocp[8] = x4;
  x5 = arg(x0, 0);
  allocp[9] = x5;
  allocp[10] = a1;
  allocp[11] = x2;
  allocp[12] = (q)(struct goalrec*)&allocp[5];
  allocp[13] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[14] = x4;
  allocp[15] = x6 = makeref(&allocp[15]);
  allocp[16] = x3;
  qp = (struct goalrec*)&allocp[12];
  allocp += 17;
  proceed();
 case VARREF:
  deref_and_jump(x0,make_3_2);
  *reasonp++ =  x0;
  goto make_3_interrupt;
  };
  goto make_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto make_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,make_3_1);
  *reasonp++ =  a0;
  goto make_3_interrupt;
  };
  goto make_3_interrupt;
 make_3_ext_interrupt:
  reasonp = 0l;
 make_3_interrupt:
  toppred = &predicate_ea_xmake_3;
  goto interrupt_3;
 }

 make__clauses_5_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 make__clauses_5_clear_reason:
  reasonp = reasons;
 make__clauses_5_0:
 make__clauses_5_1:
  if (!isint(a0)) goto make__clauses_5_7;
  x0 = makeint(0L);
  gblt_greater(a0,x0,make__clauses_5_6);
 make__clauses_5_2:
  if (isref(a1)) goto make__clauses_5_5;
  gblt_arg(a0,a1,x1,make__clauses_5_6);
 make__clauses_5_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (isint(x1)) goto make__clauses_5_6;
 make__clauses_5_4:
  gblt_atom(x1,make__clauses_5_6);
  x2 = makeint(1L);
  bblt_sub_no_check(a0,x2,x3);
  a0 = x3;
  execute(make__clauses_5_0);
  goto make__clauses_5_ext_interrupt;
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_clause_4)) goto make__clauses_5_6;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ea_xmake__clauses_5);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[9] = a0;
  allocp[10] = makeint(1L);
  allocp[11] = x2;
  allocp[12] = (q)(struct goalrec*)&allocp[7];
  allocp[13] = (q)(&predicate_ea_xmake__bodys_6);
  allocp[14] = x4 = makeref(&allocp[14]);
  x5 = arg(x1, 2);
  allocp[15] = x5;
  allocp[16] = a2;
  allocp[17] = a0;
  allocp[18] = a3;
  allocp[19] = x3;
  allocp[20] = (q)(struct goalrec*)&allocp[12];
  allocp[21] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[22] = x5;
  allocp[23] = x6 = makeref(&allocp[23]);
  allocp[24] = x4;
  qp = (struct goalrec*)&allocp[20];
  allocp += 25;
  proceed();
 case VARREF:
  deref_and_jump(x1,make__clauses_5_3);
  *reasonp++ =  x1;
  goto make__clauses_5_6;
  };
  goto make__clauses_5_6;
 make__clauses_5_5:
  deref_and_jump(a1,make__clauses_5_2);
  *reasonp++ =  a1;
  goto make__clauses_5_6;
 make__clauses_5_6:
  if (a0 != makeint(0L)) goto make__clauses_5_interrupt;
  unify(a4, a3);
  proceed();
 make__clauses_5_7:
  if (!isref(a0)) goto make__clauses_5_interrupt;
  deref_and_jump(a0,make__clauses_5_1);
  *reasonp++ =  a0;
  goto make__clauses_5_interrupt;
 make__clauses_5_ext_interrupt:
  reasonp = 0l;
 make__clauses_5_interrupt:
  goto interrupt_5;
 }

 make__bodys_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 make__bodys_6_clear_reason:
  reasonp = reasons;
 make__bodys_6_0:
 make__bodys_6_1:
  if (!isint(a0)) goto make__bodys_6_5;
  x0 = makeint(0L);
  gblt_greater(a0,x0,make__bodys_6_4);
 make__bodys_6_2:
  if (isref(a1)) goto make__bodys_6_3;
  gblt_arg(a0,a1,x1,make__bodys_6_4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ea_xmake__bodys_6);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[10] = a0;
  allocp[11] = makeint(1L);
  allocp[12] = x2;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_ea_xmake__body_8);
  allocp[15] = x4 = makeref(&allocp[15]);
  allocp[16] = x5 = makeref(&allocp[16]);
  allocp[17] = a2;
  allocp[18] = a3;
  allocp[19] = a0;
  allocp[20] = x6 = makeref(&allocp[20]);
  allocp[21] = a4;
  allocp[22] = x3;
  allocp[23] = (q)(struct goalrec*)&allocp[13];
  allocp[24] = (q)(&predicate_parse__uty_xdecode__goalcall_6);
  allocp[25] = a2;
  allocp[26] = x5;
  allocp[27] = x1;
  allocp[28] = x6;
  allocp[29] = x7 = makeref(&allocp[29]);
  allocp[30] = x4;
  qp = (struct goalrec*)&allocp[23];
  allocp += 31;
  proceed();
 make__bodys_6_3:
  deref_and_jump(a1,make__bodys_6_2);
  *reasonp++ =  a1;
  goto make__bodys_6_4;
 make__bodys_6_4:
  if (a0 != makeint(0L)) goto make__bodys_6_interrupt;
  unify(a5, a4);
  proceed();
 make__bodys_6_5:
  if (!isref(a0)) goto make__bodys_6_interrupt;
  deref_and_jump(a0,make__bodys_6_1);
  *reasonp++ =  a0;
  goto make__bodys_6_interrupt;
 make__bodys_6_ext_interrupt:
  reasonp = 0l;
 make__bodys_6_interrupt:
  goto interrupt_6;
 }

 make__body_8_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 make__body_8_clear_reason:
  reasonp = reasons;
 make__body_8_0:
 make__body_8_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto make__body_8_6;
  switch (symval(a0)) {
 case symval(makesym(atom_builtin)):
  unify(a7, a6);
  proceed();
 case symval(makesym(atom_userdef)):
 make__body_8_2:
  if (isref(a1)) goto make__body_8_5;
 make__body_8_3:
  if (isref(a1)) goto make__body_8_4;
  if_not_equal(a1, a2, make__body_8_6);
  unify(a7, a6);
  proceed();
 make__body_8_4:
  deref_and_jump(a1,make__body_8_3);
  *reasonp++ =  a1;
  goto make__body_8_6;
 make__body_8_5:
  deref_and_jump(a1,make__body_8_2);
  *reasonp++ =  a1;
  goto make__body_8_6;
  };
  goto make__body_8_6;
 case VARREF:
  deref_and_jump(a0,make__body_8_1);
  *reasonp++ =  a0;
  goto make__body_8_6;
  };
  goto make__body_8_6;
 make__body_8_6:
  otherwise(make__body_8_interrupt);
 make__body_8_7:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_userdef)) goto make__body_8_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ea_xcheck__ea_9);
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  allocp[5] = a4;
  allocp[6] = a5;
  allocp[7] = x0 = makeref(&allocp[7]);
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[13] = a5;
  allocp[14] = x0;
  allocp[15] = x1;
  qp = (struct goalrec*)&allocp[11];
  allocp += 16;
  proceed();
 case VARREF:
  deref_and_jump(a0,make__body_8_7);
  *reasonp++ =  a0;
  goto make__body_8_interrupt;
  };
  goto make__body_8_interrupt;
 make__body_8_ext_interrupt:
  reasonp = 0l;
 make__body_8_interrupt:
  goto interrupt_8;
 }

 check__ea_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 check__ea_9_clear_reason:
  reasonp = reasons;
 check__ea_9_0:
 check__ea_9_1:
  switch (ptagof(a7)) {
 case CONS:
  x0 = car_of(a7);
 check__ea_9_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_3)) goto check__ea_9_7;
  x1 = arg(x0, 0);
 check__ea_9_3:
  if (isref(x1)) goto check__ea_9_6;
 check__ea_9_4:
  if (isref(x1)) goto check__ea_9_5;
  if_not_equal(x1, a0, check__ea_9_7);
  allocp[0] = makesym(functor_module_3);
  allocp[1] = a0;
  x3 = arg(x0, 1);
  allocp[2] = x3;
  allocp[3] = x4 = makeref(&allocp[3]);
  x2 = makefunctor(&allocp[0]);
  x6 = cdr_of(a7);
  allocp[4] = x6;
  allocp[5] = x2;
  x5 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a8, x5);
  a0 = arg(x0, 2);
  x7 = a1;
  x8 = a2;
  x9 = a3;
  x10 = a4;
  x11 = a5;
  a7 = a6;
  a6 = x11;
  a5 = x10;
  a4 = x9;
  a3 = x8;
  a2 = x7;
  a1 = x4;
  execute(check__pred_8_clear_reason);
  goto check__pred_8_ext_interrupt;
 check__ea_9_5:
  deref_and_jump(x1,check__ea_9_4);
  *reasonp++ =  x1;
  goto check__ea_9_7;
 check__ea_9_6:
  deref_and_jump(x1,check__ea_9_3);
  *reasonp++ =  x1;
  goto check__ea_9_7;
 case VARREF:
  deref_and_jump(x0,check__ea_9_2);
  *reasonp++ =  x0;
  goto check__ea_9_7;
  };
  goto check__ea_9_7;
 case ATOMIC:
  if (a7 != NILATOM) goto check__ea_9_7;
  allocp[0] = makesym(functor_entries_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_pred_3);
  allocp[3] = a5;
  allocp[4] = a6;
  allocp[5] = x0;
  x2 = makefunctor(&allocp[2]);
  allocp[6] = NILATOM;
  allocp[7] = x2;
  x3 = makecons(&allocp[6]);
  allocp[8] = makesym(functor_module_3);
  allocp[9] = a0;
  allocp[10] = NILATOM;
  allocp[11] = x3;
  x4 = makefunctor(&allocp[8]);
  allocp[12] = NILATOM;
  allocp[13] = x4;
  x5 = makecons(&allocp[12]);
  allocp += 14;
  unify_value(a8, x5);
  a0 = a6;
  x6 = a3;
  a5 = a4;
  a6 = x1;
  a4 = x6;
  a3 = makesym(atom_body);
  execute(make__entry_7_0);
  goto make__entry_7_ext_interrupt;
 case VARREF:
  deref_and_jump(a7,check__ea_9_1);
  *reasonp++ =  a7;
  goto check__ea_9_7;
  };
  goto check__ea_9_7;
 check__ea_9_7:
  otherwise(check__ea_9_interrupt);
 check__ea_9_8:
  switch (ptagof(a7)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a7);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a8, x0);
  a7 = cdr_of(a7);
  a8 = x1;
  execute(check__ea_9_0);
  goto check__ea_9_ext_interrupt;
 case VARREF:
  deref_and_jump(a7,check__ea_9_8);
  *reasonp++ =  a7;
  goto check__ea_9_interrupt;
  };
  goto check__ea_9_interrupt;
 check__ea_9_ext_interrupt:
  reasonp = 0l;
 check__ea_9_interrupt:
  goto interrupt_9;
 }

 check__pred_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 check__pred_8_clear_reason:
  reasonp = reasons;
 check__pred_8_0:
 check__pred_8_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 check__pred_8_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_3)) goto check__pred_8_11;
  x1 = arg(x0, 0);
 check__pred_8_3:
  if (isref(x1)) goto check__pred_8_10;
 check__pred_8_4:
  if (isref(x1)) goto check__pred_8_9;
  if_not_equal(x1, a6, check__pred_8_11);
  x2 = arg(x0, 1);
 check__pred_8_5:
  if (isref(x2)) goto check__pred_8_8;
 check__pred_8_6:
  if (isref(x2)) goto check__pred_8_7;
  if_not_equal(x2, a7, check__pred_8_11);
  allocp[0] = makesym(functor_pred_3);
  allocp[1] = a6;
  allocp[2] = a7;
  allocp[3] = x4 = makeref(&allocp[3]);
  x3 = makefunctor(&allocp[0]);
  x6 = cdr_of(a0);
  allocp[4] = x6;
  allocp[5] = x3;
  x5 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a1, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor_xinsert__arg_4);
  allocp[2] = makeint(1L);
  x7 = arg(x0, 2);
  allocp[3] = x7;
  allocp[4] = x8 = makeref(&allocp[4]);
  allocp[5] = x4;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_ea_xmake__entry_7);
  allocp[8] = a7;
  allocp[9] = a2;
  allocp[10] = a3;
  allocp[11] = makesym(atom_body);
  allocp[12] = a4;
  allocp[13] = a5;
  allocp[14] = x8;
  allocp[15] = (q)(struct goalrec*)&allocp[6];
  allocp[16] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[17] = x7;
  allocp[18] = x9 = makeref(&allocp[18]);
  allocp[19] = x10 = makeref(&allocp[19]);
  qp = (struct goalrec*)&allocp[15];
  allocp += 20;
  proceed();
 check__pred_8_7:
  deref_and_jump(x2,check__pred_8_6);
  *reasonp++ =  x2;
  goto check__pred_8_11;
 check__pred_8_8:
  deref_and_jump(x2,check__pred_8_5);
  *reasonp++ =  x2;
  goto check__pred_8_11;
 check__pred_8_9:
  deref_and_jump(x1,check__pred_8_4);
  *reasonp++ =  x1;
  goto check__pred_8_11;
 check__pred_8_10:
  deref_and_jump(x1,check__pred_8_3);
  *reasonp++ =  x1;
  goto check__pred_8_11;
 case VARREF:
  deref_and_jump(x0,check__pred_8_2);
  *reasonp++ =  x0;
  goto check__pred_8_11;
  };
  goto check__pred_8_11;
 case VARREF:
  deref_and_jump(a0,check__pred_8_1);
  *reasonp++ =  a0;
  goto check__pred_8_11;
  };
  goto check__pred_8_11;
 check__pred_8_11:
  otherwise(check__pred_8_interrupt);
 check__pred_8_12:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(check__pred_8_0);
  goto check__pred_8_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto check__pred_8_interrupt;
  allocp[0] = makesym(functor_entries_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_pred_3);
  allocp[3] = a6;
  allocp[4] = a7;
  allocp[5] = x0;
  x2 = makefunctor(&allocp[2]);
  allocp[6] = NILATOM;
  allocp[7] = x2;
  x3 = makecons(&allocp[6]);
  allocp += 8;
  unify_value(a1, x3);
  a0 = a7;
  a1 = a2;
  a2 = a3;
  a3 = makesym(atom_body);
  a6 = x1;
  execute(make__entry_7_0);
  goto make__entry_7_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,check__pred_8_12);
  *reasonp++ =  a0;
  goto check__pred_8_interrupt;
  };
  goto check__pred_8_interrupt;
 check__pred_8_ext_interrupt:
  reasonp = 0l;
 check__pred_8_interrupt:
  toppred = &predicate_ea_xcheck__pred_8;
  goto interrupt_8;
 }

 make__entry_7_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 make__entry_7_clear_reason:
  reasonp = reasons;
 make__entry_7_0:
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a1;
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_entry_2);
  allocp[6] = x0;
  allocp[7] = x2 = makeref(&allocp[7]);
  x1 = makefunctor(&allocp[5]);
  allocp += 8;
  unify_value(a6, x1);
  a1 = a5;
  a2 = makesym(atom_args);
  a3 = x2;
  execute(make__args_4_0);
  goto make__args_4_ext_interrupt;
 make__entry_7_ext_interrupt:
  reasonp = 0l;
 make__entry_7_interrupt:
  toppred = &predicate_ea_xmake__entry_7;
  goto interrupt_7;
 }

 make__args_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 make__args_4_clear_reason:
  reasonp = reasons;
 make__args_4_0:
 make__args_4_1:
  if (!isint(a0)) goto make__args_4_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,make__args_4_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ea_xmake__args_4);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x1;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_functor_xinsert__arg_4);
  allocp[13] = makeint(1L);
  allocp[14] = a2;
  allocp[15] = x3 = makeref(&allocp[15]);
  allocp[16] = x2;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_functor__table_xarg_3);
  allocp[19] = a0;
  allocp[20] = a1;
  allocp[21] = x3;
  qp = (struct goalrec*)&allocp[17];
  allocp += 22;
  proceed();
 make__args_4_2:
  if (a0 != makeint(0L)) goto make__args_4_interrupt;
  unify(a2, a3);
  proceed();
 make__args_4_3:
  if (!isref(a0)) goto make__args_4_interrupt;
  deref_and_jump(a0,make__args_4_1);
  *reasonp++ =  a0;
  goto make__args_4_interrupt;
 make__args_4_ext_interrupt:
  reasonp = 0l;
 make__args_4_interrupt:
  toppred = &predicate_ea_xmake__args_4;
  goto interrupt_4;
 }
 interrupt_9:
  allocp[10] = a8;
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_ea);
}
