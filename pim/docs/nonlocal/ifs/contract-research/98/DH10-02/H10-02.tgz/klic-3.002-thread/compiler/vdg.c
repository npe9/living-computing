/* Compiled by KLIC compiler version 3.002 (Wed Sep 17 15:37:13 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_vdg();
Const struct predicate predicate_vdg_xmake_5 =
   { module_vdg, 0, 5 };
Const struct predicate predicate_vdg_xtrue_0 =
   { module_vdg, 1, 0 };
Const struct predicate predicate_vdg_xinit__vd_2 =
   { module_vdg, 2, 2 };
Const struct predicate predicate_vdg_xinit__vd__clauses_2 =
   { module_vdg, 3, 2 };
Const struct predicate predicate_vdg_xinit__vd__clauses1_3 =
   { module_vdg, 4, 3 };
Const struct predicate predicate_vdg_xinit__vd__clause_2 =
   { module_vdg, 5, 2 };
Const struct predicate predicate_vdg_xmake__vp_3 =
   { module_vdg, 6, 3 };
Const struct predicate predicate_vdg_xmake__vp1_4 =
   { module_vdg, 7, 4 };
Const struct predicate predicate_vdg_xmake__vp__head_6 =
   { module_vdg, 8, 6 };
Const struct predicate predicate_vdg_xmake__vp__head1_5 =
   { module_vdg, 9, 5 };
Const struct predicate predicate_vdg_xmake__vp__entry_4 =
   { module_vdg, 10, 4 };
Const struct predicate predicate_vdg_xmake__vp__body__r_8 =
   { module_vdg, 11, 8 };
Const struct predicate predicate_vdg_xmake__vp__body__r1_5 =
   { module_vdg, 12, 5 };
Const struct predicate predicate_vdg_xentry__vp_4 =
   { module_vdg, 13, 4 };
Const struct predicate predicate_vdg_xexpand__vdg_8 =
   { module_vdg, 14, 8 };
Const struct predicate predicate_vdg_xexpand__vdg1_14 =
   { module_vdg, 15, 14 };
Const struct predicate predicate_vdg_xcheck__ogoal_14 =
   { module_vdg, 16, 14 };
Const struct predicate predicate_vdg_xcheck__guard__dependency_14 =
   { module_vdg, 17, 14 };
Const struct predicate predicate_vdg_xcheck__guard__dependency__vd_5 =
   { module_vdg, 18, 5 };
Const struct predicate predicate_vdg_xcheck__guard__dependency__vd1_6 =
   { module_vdg, 19, 6 };
Const struct predicate predicate_vdg_xappend__gd2vd_7 =
   { module_vdg, 20, 7 };
Const struct predicate predicate_vdg_xcheck__guard__dependency1_13 =
   { module_vdg, 21, 13 };
Const struct predicate predicate_vdg_xcheck__guard__dependency2_13 =
   { module_vdg, 22, 13 };
Const struct predicate predicate_vdg_xcheck__guard__dependency3_13 =
   { module_vdg, 23, 13 };
Const struct predicate predicate_vdg_xcheck__ogoal1_21 =
   { module_vdg, 24, 21 };
Const struct predicate predicate_vdg_xentry__ivars__builtin_13 =
   { module_vdg, 25, 13 };
Const struct predicate predicate_vdg_xentry__ivars__builtin1_13 =
   { module_vdg, 26, 13 };
Const struct predicate predicate_vdg_xentry__ivar__vd__unify_12 =
   { module_vdg, 27, 12 };
Const struct predicate predicate_vdg_xentry__ivar__vd__unify2_12 =
   { module_vdg, 28, 12 };
Const struct predicate predicate_vdg_xentry__ivar__vd__unify1_12 =
   { module_vdg, 29, 12 };
Const struct predicate predicate_vdg_xentry__ivar__vd_13 =
   { module_vdg, 30, 13 };
Const struct predicate predicate_vdg_xcheck__dgoal__unify_15 =
   { module_vdg, 31, 15 };
Const struct predicate predicate_vdg_xentry__vd_7 =
   { module_vdg, 32, 7 };
Const struct predicate predicate_vdg_xentry__gd_6 =
   { module_vdg, 33, 6 };
Const struct predicate predicate_vdg_xread__vd_5 =
   { module_vdg, 34, 5 };
Const struct predicate predicate_vdg_xread__gd_4 =
   { module_vdg, 35, 4 };
Const struct predicate predicate_vdg_xcheck__and__entry__vp_7 =
   { module_vdg, 36, 7 };
Const struct predicate predicate_vdg_xcheck__and__entry__vp1_7 =
   { module_vdg, 37, 7 };
Const struct predicate predicate_vdg_xdelete__searching__var_3 =
   { module_vdg, 38, 3 };
Const struct predicate predicate_vdg_xexpand__u_8 =
   { module_vdg, 39, 8 };
Const struct predicate predicate_vdg_xexpand__hb_11 =
   { module_vdg, 40, 11 };
Const struct predicate predicate_vdg_xexpand__hb__pred_10 =
   { module_vdg, 41, 10 };
Const struct predicate predicate_vdg_xexpand__hb__entry__args_6 =
   { module_vdg, 42, 6 };
Const struct predicate predicate_vdg_xexpand__hb__entry__args1_7 =
   { module_vdg, 43, 7 };
Const struct predicate predicate_vdg_xmerge__vd_3 =
   { module_vdg, 44, 3 };
Const struct predicate predicate_vdg_xmerge__vd1_4 =
   { module_vdg, 45, 4 };
Const struct predicate predicate_vdg_xmerge__vd2_8 =
   { module_vdg, 46, 8 };
extern Const struct predicate predicate_list_xor__unique_3;
extern Const struct predicate predicate_list_xcheck__include_3;
extern Const struct predicate predicate_functor_xnew__functor__init_4;
extern Const struct predicate predicate_integer__arithmetics_xadd_3;
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_xsetarg_4;
extern Const struct predicate predicate_functor__table_xfunctor_3;
extern Const struct predicate predicate_hb_xget__hio_5;
extern Const struct predicate predicate_hb_xget__gids_6;
extern Const struct predicate predicate_hb_xget__bio_5;
extern Const struct predicate predicate_parse__uty_xget__clause_4;
extern Const struct predicate predicate_parse__uty_xdecode__goalcall_6;
extern Const struct predicate predicate_parse__uty_xget__goal_6;
extern Const struct predicate predicate_adg_xget__ogoal_14;
extern Const struct predicate predicate_adg_xget__builtin__ioargs_4;
extern Const struct predicate predicate_typeset_xvalue2typeset_5;
extern Const struct predicate predicate_typeset_xcheck__same__type_4;
extern Const struct predicate predicate_vt_xread__ts_5;

module module_vdg(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  q a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17, a18, a19, a20;

  q *reasonp;
 module_top:
  switch_on_pred() {
    case_pred(0, make_5_top);
    case_pred(1, true_0_top);
    case_pred(2, init__vd_2_top);
    case_pred(3, init__vd__clauses_2_top);
    case_pred(4, init__vd__clauses1_3_top);
    case_pred(5, init__vd__clause_2_top);
    case_pred(6, make__vp_3_top);
    case_pred(7, make__vp1_4_top);
    case_pred(8, make__vp__head_6_top);
    case_pred(9, make__vp__head1_5_top);
    case_pred(10, make__vp__entry_4_top);
    case_pred(11, make__vp__body__r_8_top);
    case_pred(12, make__vp__body__r1_5_top);
    case_pred(13, entry__vp_4_top);
    case_pred(14, expand__vdg_8_top);
    case_pred(15, expand__vdg1_14_top);
    case_pred(16, check__ogoal_14_top);
    case_pred(17, check__guard__dependency_14_top);
    case_pred(18, check__guard__dependency__vd_5_top);
    case_pred(19, check__guard__dependency__vd1_6_top);
    case_pred(20, append__gd2vd_7_top);
    case_pred(21, check__guard__dependency1_13_top);
    case_pred(22, check__guard__dependency2_13_top);
    case_pred(23, check__guard__dependency3_13_top);
    case_pred(24, check__ogoal1_21_top);
    case_pred(25, entry__ivars__builtin_13_top);
    case_pred(26, entry__ivars__builtin1_13_top);
    case_pred(27, entry__ivar__vd__unify_12_top);
    case_pred(28, entry__ivar__vd__unify2_12_top);
    case_pred(29, entry__ivar__vd__unify1_12_top);
    case_pred(30, entry__ivar__vd_13_top);
    case_pred(31, check__dgoal__unify_15_top);
    case_pred(32, entry__vd_7_top);
    case_pred(33, entry__gd_6_top);
    case_pred(34, read__vd_5_top);
    case_pred(35, read__gd_4_top);
    case_pred(36, check__and__entry__vp_7_top);
    case_pred(37, check__and__entry__vp1_7_top);
    case_pred(38, delete__searching__var_3_top);
    case_pred(39, expand__u_8_top);
    case_pred(40, expand__hb_11_top);
    case_pred(41, expand__hb__pred_10_top);
    case_pred(42, expand__hb__entry__args_6_top);
    case_pred(43, expand__hb__entry__args1_7_top);
    case_pred(44, merge__vd_3_top);
    case_pred(45, merge__vd1_4_top);
    last_case_pred(46, merge__vd2_8_top);
  }

 make_5_top: {
  q x0, x1;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 make_5_clear_reason:
  reasonp = reasons;
 make_5_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vdg_xexpand__vdg_8);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = NILATOM;
  allocp[4] = NILATOM;
  allocp[5] = a3;
  allocp[6] = a2;
  allocp[7] = a4;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a1;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_vdg_xmake__vp_3);
  allocp[12] = a0;
  allocp[13] = a4;
  allocp[14] = x0;
  a0 = x1;
  a1 = a2;
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  execute(init__vd_2_0);
  goto init__vd_2_ext_interrupt;
 make_5_ext_interrupt:
  reasonp = 0l;
 make_5_interrupt:
  goto interrupt_5;
 }

 true_0_top: {
  qp = qp->next;
 true_0_clear_reason:
  reasonp = reasons;
 true_0_0:
  proceed();
 true_0_ext_interrupt:
  reasonp = 0l;
 true_0_interrupt:
  goto interrupt_0;
 }

 init__vd_2_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a0 = qp->args[0];
  a1 = qp->args[1];
  qp = qp->next;
 init__vd_2_clear_reason:
  reasonp = reasons;
 init__vd_2_0:
 init__vd_2_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 init__vd_2_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto init__vd_2_interrupt;
  allocp[0] = makesym(functor_module_2);
  x2 = arg(x0, 0);
  allocp[1] = x2;
  allocp[2] = x3 = makeref(&allocp[2]);
  x1 = makefunctor(&allocp[0]);
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = x1;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a0, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vdg_xinit__vd_2);
  allocp[2] = x5;
  x6 = cdr_of(a1);
  allocp[3] = x6;
  a0 = arg(x0, 1);
  a1 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  execute(init__vd__clauses_2_0);
  goto init__vd__clauses_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,init__vd_2_2);
  *reasonp++ =  x0;
  goto init__vd_2_interrupt;
  };
  goto init__vd_2_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto init__vd_2_interrupt;
  x0 = NILATOM;
  unify_value(a0, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,init__vd_2_1);
  *reasonp++ =  a1;
  goto init__vd_2_interrupt;
  };
  goto init__vd_2_interrupt;
 init__vd_2_ext_interrupt:
  reasonp = 0l;
 init__vd_2_interrupt:
  toppred = &predicate_vdg_xinit__vd_2;
  goto interrupt_2;
 }

 init__vd__clauses_2_top: {
  q x0, x1;
  a0 = qp->args[0];
  a1 = qp->args[1];
  qp = qp->next;
 init__vd__clauses_2_clear_reason:
  reasonp = reasons;
 init__vd__clauses_2_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vdg_xinit__vd__clauses1_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[7] = a0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x0;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 init__vd__clauses_2_ext_interrupt:
  reasonp = 0l;
 init__vd__clauses_2_interrupt:
  toppred = &predicate_vdg_xinit__vd__clauses_2;
  goto interrupt_2;
 }

 init__vd__clauses1_3_top: {
  q x0, x1, x2, x3, x4;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 init__vd__clauses1_3_clear_reason:
  reasonp = reasons;
 init__vd__clauses1_3_0:
 init__vd__clauses1_3_1:
  if (!isint(a0)) goto init__vd__clauses1_3_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,init__vd__clauses1_3_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vdg_xinit__vd__clauses1_3);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[7] = a0;
  allocp[8] = makeint(1L);
  allocp[9] = x1;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[12] = a0;
  allocp[13] = a1;
  allocp[14] = x3 = makeref(&allocp[14]);
  allocp[15] = x2;
  allocp[16] = (q)(struct goalrec*)&allocp[10];
  allocp[17] = (q)(&predicate_vdg_xinit__vd__clause_2);
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = x3;
  allocp[20] = (q)(struct goalrec*)&allocp[16];
  allocp[21] = (q)(&predicate_functor__table_xarg_3);
  allocp[22] = a0;
  allocp[23] = a1;
  allocp[24] = x4;
  qp = (struct goalrec*)&allocp[20];
  allocp += 25;
  proceed();
 init__vd__clauses1_3_2:
  if (a0 != makeint(0L)) goto init__vd__clauses1_3_interrupt;
  unify(a2, a1);
  proceed();
 init__vd__clauses1_3_3:
  if (!isref(a0)) goto init__vd__clauses1_3_interrupt;
  deref_and_jump(a0,init__vd__clauses1_3_1);
  *reasonp++ =  a0;
  goto init__vd__clauses1_3_interrupt;
 init__vd__clauses1_3_ext_interrupt:
  reasonp = 0l;
 init__vd__clauses1_3_interrupt:
  goto interrupt_3;
 }

 init__vd__clause_2_top: {
  q x0, x1, x2, x3;
  a0 = qp->args[0];
  a1 = qp->args[1];
  qp = qp->next;
 init__vd__clause_2_clear_reason:
  reasonp = reasons;
 init__vd__clause_2_0:
  allocp[0] = makesym(functor_clause_2);
  allocp[1] = NILATOM;
  allocp[2] = x1 = makeref(&allocp[2]);
  x0 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor_xnew__functor__init_4);
  allocp[2] = makesym(atom_vds);
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = NILATOM;
  allocp[5] = x1;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[8] = a0;
  allocp[9] = x3 = makeref(&allocp[9]);
  allocp[10] = x2;
  qp = (struct goalrec*)&allocp[6];
  allocp += 11;
  proceed();
 init__vd__clause_2_ext_interrupt:
  reasonp = 0l;
 init__vd__clause_2_interrupt:
  goto interrupt_2;
 }

 make__vp_3_top: {
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 make__vp_3_clear_reason:
  reasonp = reasons;
 make__vp_3_0:
  a3 = a2;
  a2 = NILATOM;
  execute(make__vp1_4_0);
  goto make__vp1_4_ext_interrupt;
 make__vp_3_ext_interrupt:
  reasonp = 0l;
 make__vp_3_interrupt:
  goto interrupt_3;
 }

 make__vp1_4_top: {
  q x0, x1, x2, x3, x4;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 make__vp1_4_clear_reason:
  reasonp = reasons;
 make__vp1_4_0:
 make__vp1_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 make__vp1_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_pred_3:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vdg_xmake__vp1_4);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  a0 = arg(x0, 0);
  x3 = arg(x0, 1);
  x4 = arg(x0, 2);
  a3 = a1;
  a4 = a2;
  a5 = x2;
  a2 = x4;
  a1 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(make__vp__head_6_0);
  goto make__vp__head_6_ext_interrupt;
 case functor_body__r_5:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vdg_xmake__vp1_4);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  a0 = arg(x0, 0);
  x3 = arg(x0, 1);
  x4 = arg(x0, 2);
  a3 = arg(x0, 3);
  a4 = arg(x0, 4);
  a5 = a1;
  a6 = a2;
  a7 = x2;
  a2 = x4;
  a1 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(make__vp__body__r_8_0);
  goto make__vp__body__r_8_ext_interrupt;
  };
  goto make__vp1_4_interrupt;
 case VARREF:
  deref_and_jump(x0,make__vp1_4_2);
  *reasonp++ =  x0;
  goto make__vp1_4_interrupt;
  };
  goto make__vp1_4_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto make__vp1_4_interrupt;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,make__vp1_4_1);
  *reasonp++ =  a0;
  goto make__vp1_4_interrupt;
  };
  goto make__vp1_4_interrupt;
 make__vp1_4_ext_interrupt:
  reasonp = 0l;
 make__vp1_4_interrupt:
  toppred = &predicate_vdg_xmake__vp1_4;
  goto interrupt_4;
 }

 make__vp__head_6_top: {
  q x0, x1, x2, x3;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 make__vp__head_6_clear_reason:
  reasonp = reasons;
 make__vp__head_6_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vdg_xmake__vp__head1_5);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a4;
  allocp[6] = a5;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[9] = x1;
  allocp[10] = x3 = makeref(&allocp[10]);
  allocp[11] = x0;
  allocp[12] = (q)(struct goalrec*)&allocp[7];
  allocp[13] = (q)(&predicate_hb_xget__gids_6);
  allocp[14] = a3;
  allocp[15] = a0;
  allocp[16] = a1;
  allocp[17] = a2;
  allocp[18] = makesym(atom_head);
  allocp[19] = x1;
  allocp[20] = (q)(struct goalrec*)&allocp[12];
  allocp[21] = (q)(&predicate_hb_xget__hio_5);
  allocp[22] = a3;
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a2;
  allocp[26] = x2;
  qp = (struct goalrec*)&allocp[20];
  allocp += 27;
  proceed();
 make__vp__head_6_ext_interrupt:
  reasonp = 0l;
 make__vp__head_6_interrupt:
  toppred = &predicate_vdg_xmake__vp__head_6;
  goto interrupt_6;
 }

 make__vp__head1_5_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 make__vp__head1_5_clear_reason:
  reasonp = reasons;
 make__vp__head1_5_0:
 make__vp__head1_5_1:
  if (!isint(a0)) goto make__vp__head1_5_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,make__vp__head1_5_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vdg_xmake__vp__head1_5);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[9] = a0;
  allocp[10] = makeint(1L);
  allocp[11] = x1;
  allocp[12] = (q)(struct goalrec*)&allocp[7];
  allocp[13] = (q)(&predicate_vdg_xmake__vp__entry_4);
  allocp[14] = x3 = makeref(&allocp[14]);
  allocp[15] = x4 = makeref(&allocp[15]);
  allocp[16] = a3;
  allocp[17] = x2;
  allocp[18] = makesym(functor_io_2);
  allocp[19] = x6 = makeref(&allocp[19]);
  allocp[20] = x3;
  x5 = makefunctor(&allocp[18]);
  allocp[21] = (q)(struct goalrec*)&allocp[12];
  allocp[22] = (q)(&predicate_functor__table_xarg_3);
  allocp[23] = a0;
  allocp[24] = a2;
  allocp[25] = x5;
  allocp[26] = (q)(struct goalrec*)&allocp[21];
  allocp[27] = (q)(&predicate_functor__table_xarg_3);
  allocp[28] = a0;
  allocp[29] = a1;
  allocp[30] = x4;
  qp = (struct goalrec*)&allocp[26];
  allocp += 31;
  proceed();
 make__vp__head1_5_2:
  if (a0 != makeint(0L)) goto make__vp__head1_5_interrupt;
  unify(a4, a3);
  proceed();
 make__vp__head1_5_3:
  if (!isref(a0)) goto make__vp__head1_5_interrupt;
  deref_and_jump(a0,make__vp__head1_5_1);
  *reasonp++ =  a0;
  goto make__vp__head1_5_interrupt;
 make__vp__head1_5_ext_interrupt:
  reasonp = 0l;
 make__vp__head1_5_interrupt:
  goto interrupt_5;
 }

 make__vp__entry_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 make__vp__entry_4_clear_reason:
  reasonp = reasons;
 make__vp__entry_4_0:
 make__vp__entry_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 make__vp__entry_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_v_3)) goto make__vp__entry_4_interrupt;
  allocp[0] = makesym(functor_v_4);
  x2 = arg(x0, 0);
  allocp[1] = x2;
  x3 = arg(x0, 1);
  allocp[2] = x3;
  x4 = arg(x0, 2);
  allocp[3] = x4;
  allocp[4] = makeint(-1L);
  x1 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_entry_2);
  allocp[6] = x1;
  allocp[7] = a1;
  x5 = makefunctor(&allocp[5]);
  allocp[8] = x7 = makeref(&allocp[8]);
  allocp[9] = x5;
  x6 = makecons(&allocp[8]);
  allocp += 10;
  unify_value(a3, x6);
  a0 = cdr_of(a0);
  a3 = x7;
  execute(make__vp__entry_4_0);
  goto make__vp__entry_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,make__vp__entry_4_2);
  *reasonp++ =  x0;
  goto make__vp__entry_4_interrupt;
  };
  goto make__vp__entry_4_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto make__vp__entry_4_interrupt;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,make__vp__entry_4_1);
  *reasonp++ =  a0;
  goto make__vp__entry_4_interrupt;
  };
  goto make__vp__entry_4_interrupt;
 make__vp__entry_4_ext_interrupt:
  reasonp = 0l;
 make__vp__entry_4_interrupt:
  goto interrupt_4;
 }

 make__vp__body__r_8_top: {
  q x0, x1, x2, x3;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 make__vp__body__r_8_clear_reason:
  reasonp = reasons;
 make__vp__body__r_8_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vdg_xmake__vp__body__r1_5);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a6;
  allocp[6] = a7;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[9] = x1;
  allocp[10] = x3 = makeref(&allocp[10]);
  allocp[11] = x0;
  allocp[12] = (q)(struct goalrec*)&allocp[7];
  allocp[13] = (q)(&predicate_hb_xget__gids_6);
  allocp[14] = a5;
  allocp[15] = a0;
  allocp[16] = a1;
  allocp[17] = a2;
  allocp[18] = makesym(atom_body);
  allocp[19] = x1;
  allocp[20] = (q)(struct goalrec*)&allocp[12];
  allocp[21] = (q)(&predicate_hb_xget__bio_5);
  allocp[22] = a5;
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a2;
  allocp[26] = x2;
  qp = (struct goalrec*)&allocp[20];
  allocp += 27;
  proceed();
 make__vp__body__r_8_ext_interrupt:
  reasonp = 0l;
 make__vp__body__r_8_interrupt:
  toppred = &predicate_vdg_xmake__vp__body__r_8;
  goto interrupt_8;
 }

 make__vp__body__r1_5_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 make__vp__body__r1_5_clear_reason:
  reasonp = reasons;
 make__vp__body__r1_5_0:
 make__vp__body__r1_5_1:
  if (!isint(a0)) goto make__vp__body__r1_5_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,make__vp__body__r1_5_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vdg_xmake__vp__body__r1_5);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[9] = a0;
  allocp[10] = makeint(1L);
  allocp[11] = x1;
  allocp[12] = (q)(struct goalrec*)&allocp[7];
  allocp[13] = (q)(&predicate_vdg_xmake__vp__entry_4);
  allocp[14] = x3 = makeref(&allocp[14]);
  allocp[15] = x4 = makeref(&allocp[15]);
  allocp[16] = a3;
  allocp[17] = x2;
  allocp[18] = makesym(functor_io_2);
  allocp[19] = x3;
  allocp[20] = x6 = makeref(&allocp[20]);
  x5 = makefunctor(&allocp[18]);
  allocp[21] = (q)(struct goalrec*)&allocp[12];
  allocp[22] = (q)(&predicate_functor__table_xarg_3);
  allocp[23] = a0;
  allocp[24] = a2;
  allocp[25] = x5;
  allocp[26] = (q)(struct goalrec*)&allocp[21];
  allocp[27] = (q)(&predicate_functor__table_xarg_3);
  allocp[28] = a0;
  allocp[29] = a1;
  allocp[30] = x4;
  qp = (struct goalrec*)&allocp[26];
  allocp += 31;
  proceed();
 make__vp__body__r1_5_2:
  if (a0 != makeint(0L)) goto make__vp__body__r1_5_interrupt;
  unify(a4, a3);
  proceed();
 make__vp__body__r1_5_3:
  if (!isref(a0)) goto make__vp__body__r1_5_interrupt;
  deref_and_jump(a0,make__vp__body__r1_5_1);
  *reasonp++ =  a0;
  goto make__vp__body__r1_5_interrupt;
 make__vp__body__r1_5_ext_interrupt:
  reasonp = 0l;
 make__vp__body__r1_5_interrupt:
  goto interrupt_5;
 }

 entry__vp_4_top: {
  q x0, x1;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 entry__vp_4_clear_reason:
  reasonp = reasons;
 entry__vp_4_0:
  allocp[0] = makesym(functor_entry_2);
  allocp[1] = a0;
  allocp[2] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = a2;
  allocp[4] = x0;
  x1 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a3, x1);
  proceed();
 entry__vp_4_ext_interrupt:
  reasonp = 0l;
 entry__vp_4_interrupt:
  toppred = &predicate_vdg_xentry__vp_4;
  goto interrupt_4;
 }

 expand__vdg_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 expand__vdg_8_clear_reason:
  reasonp = reasons;
 expand__vdg_8_0:
 expand__vdg_8_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 expand__vdg_8_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_entry_2)) goto expand__vdg_8_interrupt;
  x1 = arg(x0, 0);
 expand__vdg_8_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_v_4)) goto expand__vdg_8_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vdg_xexpand__vdg1_14);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x1;
  x3 = arg(x1, 0);
  allocp[4] = x3;
  x4 = arg(x1, 1);
  allocp[5] = x4;
  x5 = arg(x1, 2);
  allocp[6] = x5;
  x6 = arg(x0, 1);
  allocp[7] = x6;
  x7 = cdr_of(a0);
  allocp[8] = x7;
  allocp[9] = a1;
  allocp[10] = x8 = makeref(&allocp[10]);
  allocp[11] = a3;
  allocp[12] = a4;
  allocp[13] = a5;
  allocp[14] = a6;
  allocp[15] = a7;
  allocp[16] = (q)(struct goalrec*)&allocp[0];
  allocp[17] = (q)(&predicate_vdg_xread__vd_5);
  allocp[18] = x3;
  allocp[19] = x4;
  allocp[20] = x5;
  allocp[21] = x2;
  allocp[22] = a6;
  a0 = x1;
  a1 = a2;
  a2 = x8;
  qp = (struct goalrec*)&allocp[16];
  allocp += 23;
  execute(delete__searching__var_3_0);
  goto delete__searching__var_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,expand__vdg_8_3);
  *reasonp++ =  x1;
  goto expand__vdg_8_interrupt;
  };
  goto expand__vdg_8_interrupt;
 case VARREF:
  deref_and_jump(x0,expand__vdg_8_2);
  *reasonp++ =  x0;
  goto expand__vdg_8_interrupt;
  };
  goto expand__vdg_8_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto expand__vdg_8_interrupt;
  unify(a7, a6);
  proceed();
 case VARREF:
  deref_and_jump(a0,expand__vdg_8_1);
  *reasonp++ =  a0;
  goto expand__vdg_8_interrupt;
  };
  goto expand__vdg_8_interrupt;
 expand__vdg_8_ext_interrupt:
  reasonp = 0l;
 expand__vdg_8_interrupt:
  toppred = &predicate_vdg_xexpand__vdg_8;
  goto interrupt_8;
 }

 expand__vdg1_14_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  qp = qp->next;
 expand__vdg1_14_clear_reason:
  reasonp = reasons;
 expand__vdg1_14_0:
 expand__vdg1_14_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != NILATOM) goto expand__vdg1_14_2;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vdg_xexpand__vdg_8);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a9;
  allocp[6] = a10;
  allocp[7] = a11;
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = a13;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_vdg_xexpand__u_8);
  allocp[12] = x4 = makeref(&allocp[12]);
  allocp[13] = x1;
  allocp[14] = a11;
  allocp[15] = a9;
  allocp[16] = x5 = makeref(&allocp[16]);
  allocp[17] = x0;
  allocp[18] = x6 = makeref(&allocp[18]);
  allocp[19] = x2;
  allocp[20] = (q)(struct goalrec*)&allocp[10];
  allocp[21] = (q)(&predicate_vdg_xcheck__ogoal_14);
  allocp[22] = a1;
  allocp[23] = x7 = makeref(&allocp[23]);
  allocp[24] = a5;
  allocp[25] = a10;
  allocp[26] = a11;
  allocp[27] = a9;
  allocp[28] = a7;
  allocp[29] = x4;
  allocp[30] = a8;
  allocp[31] = x6;
  allocp[32] = a6;
  allocp[33] = x5;
  allocp[34] = a12;
  allocp[35] = x3;
  allocp[36] = (q)(struct goalrec*)&allocp[20];
  allocp[37] = (q)(&predicate_parse__uty_xget__clause_4);
  allocp[38] = a2;
  allocp[39] = a3;
  allocp[40] = x7;
  allocp[41] = a9;
  qp = (struct goalrec*)&allocp[36];
  allocp += 42;
  proceed();
 case VARREF:
  deref_and_jump(a0,expand__vdg1_14_1);
  *reasonp++ =  a0;
  goto expand__vdg1_14_2;
  };
  goto expand__vdg1_14_2;
 expand__vdg1_14_2:
  otherwise(expand__vdg1_14_interrupt);
  a0 = a6;
  a1 = a7;
  a2 = a8;
  a3 = a9;
  a4 = a10;
  a5 = a11;
  a6 = a12;
  a7 = a13;
  execute(expand__vdg_8_0);
  goto expand__vdg_8_ext_interrupt;
 expand__vdg1_14_ext_interrupt:
  reasonp = 0l;
 expand__vdg1_14_interrupt:
  goto interrupt_14;
 }

 check__ogoal_14_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20, x21;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  qp = qp->next;
 check__ogoal_14_clear_reason:
  reasonp = reasons;
 check__ogoal_14_0:
 check__ogoal_14_1:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_clause_4)) goto check__ogoal_14_interrupt;
  x0 = arg(a1, 0);
 check__ogoal_14_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_functor_2)) goto check__ogoal_14_interrupt;
  x1 = arg(a1, 1);
 check__ogoal_14_3:
  if (isref(x1)) goto check__ogoal_14_7;
  gblt_pfunctor(x1,x2,check__ogoal_14_interrupt);
  gblt_arity(x1,x3,check__ogoal_14_interrupt);
  x4 = arg(a1, 2);
 check__ogoal_14_4:
  if (isref(x4)) goto check__ogoal_14_6;
  gblt_pfunctor(x4,x5,check__ogoal_14_interrupt);
  gblt_arity(x4,x6,check__ogoal_14_interrupt);
 check__ogoal_14_5:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_v_4)) goto check__ogoal_14_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vdg_xcheck__guard__dependency_14);
  allocp[2] = x7 = makeref(&allocp[2]);
  x8 = arg(a0, 0);
  allocp[3] = x8;
  x9 = arg(a0, 1);
  allocp[4] = x9;
  x10 = arg(a0, 2);
  allocp[5] = x10;
  allocp[6] = a5;
  allocp[7] = a2;
  allocp[8] = x11 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x12 = makeref(&allocp[10]);
  allocp[11] = a9;
  allocp[12] = x13 = makeref(&allocp[12]);
  allocp[13] = a11;
  allocp[14] = x14 = makeref(&allocp[14]);
  allocp[15] = a13;
  allocp[16] = (q)(struct goalrec*)&allocp[0];
  allocp[17] = (q)(&predicate_vdg_xcheck__ogoal1_21);
  allocp[18] = x15 = makeref(&allocp[18]);
  allocp[19] = x16 = makeref(&allocp[19]);
  allocp[20] = x17 = makeref(&allocp[20]);
  allocp[21] = x18 = makeref(&allocp[21]);
  allocp[22] = x8;
  allocp[23] = x9;
  allocp[24] = x10;
  allocp[25] = x19 = makeref(&allocp[25]);
  allocp[26] = x20 = makeref(&allocp[26]);
  allocp[27] = x21 = makeref(&allocp[27]);
  allocp[28] = x7;
  allocp[29] = a2;
  allocp[30] = a3;
  allocp[31] = a6;
  allocp[32] = x11;
  allocp[33] = a8;
  allocp[34] = x12;
  allocp[35] = a10;
  allocp[36] = x13;
  allocp[37] = a12;
  allocp[38] = x14;
  allocp[39] = (q)(struct goalrec*)&allocp[16];
  allocp[40] = (q)(&predicate_adg_xget__ogoal_14);
  allocp[41] = x8;
  allocp[42] = x9;
  allocp[43] = x10;
  allocp[44] = a3;
  allocp[45] = a4;
  allocp[46] = a5;
  allocp[47] = x7;
  allocp[48] = x16;
  allocp[49] = x17;
  allocp[50] = x18;
  allocp[51] = x19;
  allocp[52] = x20;
  allocp[53] = x21;
  allocp[54] = x15;
  qp = (struct goalrec*)&allocp[39];
  allocp += 55;
  proceed();
 case VARREF:
  deref_and_jump(a0,check__ogoal_14_5);
  *reasonp++ =  a0;
  goto check__ogoal_14_interrupt;
  };
  goto check__ogoal_14_interrupt;
 check__ogoal_14_6:
  deref_and_jump(x4,check__ogoal_14_4);
  *reasonp++ =  x4;
  goto check__ogoal_14_interrupt;
 check__ogoal_14_7:
  deref_and_jump(x1,check__ogoal_14_3);
  *reasonp++ =  x1;
  goto check__ogoal_14_interrupt;
 case VARREF:
  deref_and_jump(x0,check__ogoal_14_2);
  *reasonp++ =  x0;
  goto check__ogoal_14_interrupt;
  };
  goto check__ogoal_14_interrupt;
 case VARREF:
  deref_and_jump(a1,check__ogoal_14_1);
  *reasonp++ =  a1;
  goto check__ogoal_14_interrupt;
  };
  goto check__ogoal_14_interrupt;
 check__ogoal_14_ext_interrupt:
  reasonp = 0l;
 check__ogoal_14_interrupt:
  goto interrupt_14;
 }

 check__guard__dependency_14_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  qp = qp->next;
 check__guard__dependency_14_clear_reason:
  reasonp = reasons;
 check__guard__dependency_14_0:
 check__guard__dependency_14_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_goal_4)) goto check__guard__dependency_14_3;
  x0 = arg(a0, 2);
 check__guard__dependency_14_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_body)) goto check__guard__dependency_14_3;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vdg_xcheck__guard__dependency__vd_5);
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = a13;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_vdg_xcheck__guard__dependency1_13);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a1;
  allocp[11] = a2;
  allocp[12] = x3 = makeref(&allocp[12]);
  allocp[13] = a5;
  allocp[14] = a6;
  allocp[15] = a7;
  allocp[16] = a8;
  allocp[17] = a9;
  allocp[18] = a10;
  allocp[19] = a11;
  allocp[20] = a12;
  allocp[21] = x1;
  allocp[22] = (q)(struct goalrec*)&allocp[7];
  allocp[23] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[24] = x3;
  allocp[25] = x4 = makeref(&allocp[25]);
  allocp[26] = x2;
  allocp[27] = makesym(functor_clause_4);
  allocp[28] = x6 = makeref(&allocp[28]);
  allocp[29] = x3;
  allocp[30] = x7 = makeref(&allocp[30]);
  allocp[31] = x8 = makeref(&allocp[31]);
  x5 = makefunctor(&allocp[27]);
  allocp[32] = (q)(struct goalrec*)&allocp[22];
  allocp[33] = (q)(&predicate_parse__uty_xget__clause_4);
  allocp[34] = a1;
  allocp[35] = a2;
  allocp[36] = x5;
  allocp[37] = a4;
  qp = (struct goalrec*)&allocp[32];
  allocp += 38;
  proceed();
 case VARREF:
  deref_and_jump(x0,check__guard__dependency_14_2);
  *reasonp++ =  x0;
  goto check__guard__dependency_14_3;
  };
  goto check__guard__dependency_14_3;
 case VARREF:
  deref_and_jump(a0,check__guard__dependency_14_1);
  *reasonp++ =  a0;
  goto check__guard__dependency_14_3;
  };
  goto check__guard__dependency_14_3;
 check__guard__dependency_14_3:
  otherwise(check__guard__dependency_14_interrupt);
  unify4(a13, a12, a11, a10, a9, a8, a7, a6);
  proceed();
 check__guard__dependency_14_ext_interrupt:
  reasonp = 0l;
 check__guard__dependency_14_interrupt:
  goto interrupt_14;
 }

 check__guard__dependency__vd_5_top: {
  q x0;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 check__guard__dependency__vd_5_clear_reason:
  reasonp = reasons;
 check__guard__dependency__vd_5_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vdg_xcheck__guard__dependency__vd1_6);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x0 = makeref(&allocp[5]);
  allocp[6] = a3;
  allocp[7] = a4;
  a2 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  execute(read__gd_4_0);
  goto read__gd_4_ext_interrupt;
 check__guard__dependency__vd_5_ext_interrupt:
  reasonp = 0l;
 check__guard__dependency__vd_5_interrupt:
  goto interrupt_5;
 }

 check__guard__dependency__vd1_6_top: {
  q x0;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 check__guard__dependency__vd1_6_clear_reason:
  reasonp = reasons;
 check__guard__dependency__vd1_6_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vdg_xappend__gd2vd_7);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  a3 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 9;
  execute(read__vd_5_0);
  goto read__vd_5_ext_interrupt;
 check__guard__dependency__vd1_6_ext_interrupt:
  reasonp = 0l;
 check__guard__dependency__vd1_6_interrupt:
  goto interrupt_6;
 }

 append__gd2vd_7_top: {
  q x0, x1, x2;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 append__gd2vd_7_clear_reason:
  reasonp = reasons;
 append__gd2vd_7_0:
 append__gd2vd_7_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 append__gd2vd_7_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_to_2)) goto append__gd2vd_7_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vdg_xappend__gd2vd_7);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = a6;
  a0 = a1;
  a1 = a2;
  a2 = a3;
  a3 = arg(x0, 0);
  a6 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 9;
  execute(entry__vd_7_0);
  goto entry__vd_7_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,append__gd2vd_7_2);
  *reasonp++ =  x0;
  goto append__gd2vd_7_interrupt;
  };
  goto append__gd2vd_7_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto append__gd2vd_7_interrupt;
  unify(a6, a5);
  proceed();
 case VARREF:
  deref_and_jump(a0,append__gd2vd_7_1);
  *reasonp++ =  a0;
  goto append__gd2vd_7_interrupt;
  };
  goto append__gd2vd_7_interrupt;
 append__gd2vd_7_ext_interrupt:
  reasonp = 0l;
 append__gd2vd_7_interrupt:
  goto interrupt_7;
 }

 check__guard__dependency1_13_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  qp = qp->next;
 check__guard__dependency1_13_clear_reason:
  reasonp = reasons;
 check__guard__dependency1_13_0:
 check__guard__dependency1_13_1:
  if (!isint(a0)) goto check__guard__dependency1_13_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,check__guard__dependency1_13_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vdg_xcheck__guard__dependency1_13);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = x3 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = x4 = makeref(&allocp[11]);
  allocp[12] = a10;
  allocp[13] = x5 = makeref(&allocp[13]);
  allocp[14] = a12;
  allocp[15] = (q)(struct goalrec*)&allocp[0];
  allocp[16] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[17] = a0;
  allocp[18] = makeint(1L);
  allocp[19] = x1;
  allocp[20] = (q)(struct goalrec*)&allocp[15];
  allocp[21] = (q)(&predicate_vdg_xcheck__guard__dependency2_13);
  allocp[22] = x6 = makeref(&allocp[22]);
  allocp[23] = a1;
  allocp[24] = a2;
  allocp[25] = x7 = makeref(&allocp[25]);
  allocp[26] = a4;
  allocp[27] = a5;
  allocp[28] = x2;
  allocp[29] = a7;
  allocp[30] = x3;
  allocp[31] = a9;
  allocp[32] = x4;
  allocp[33] = a11;
  allocp[34] = x5;
  allocp[35] = (q)(struct goalrec*)&allocp[20];
  allocp[36] = (q)(&predicate_parse__uty_xdecode__goalcall_6);
  allocp[37] = a1;
  allocp[38] = x7;
  allocp[39] = x8 = makeref(&allocp[39]);
  allocp[40] = x6;
  allocp[41] = x9 = makeref(&allocp[41]);
  allocp[42] = x10 = makeref(&allocp[42]);
  allocp[43] = (q)(struct goalrec*)&allocp[35];
  allocp[44] = (q)(&predicate_functor__table_xarg_3);
  allocp[45] = a0;
  allocp[46] = a3;
  allocp[47] = x8;
  qp = (struct goalrec*)&allocp[43];
  allocp += 48;
  proceed();
 check__guard__dependency1_13_2:
  if (a0 != makeint(0L)) goto check__guard__dependency1_13_interrupt;
  unify4(a12, a11, a10, a9, a8, a7, a6, a5);
  proceed();
 check__guard__dependency1_13_3:
  if (!isref(a0)) goto check__guard__dependency1_13_interrupt;
  deref_and_jump(a0,check__guard__dependency1_13_1);
  *reasonp++ =  a0;
  goto check__guard__dependency1_13_interrupt;
 check__guard__dependency1_13_ext_interrupt:
  reasonp = 0l;
 check__guard__dependency1_13_interrupt:
  goto interrupt_13;
 }

 check__guard__dependency2_13_top: {
  q x0, x1, x2, x3;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  qp = qp->next;
 check__guard__dependency2_13_clear_reason:
  reasonp = reasons;
 check__guard__dependency2_13_0:
 check__guard__dependency2_13_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor__3D_2)) goto check__guard__dependency2_13_4;
  x0 = arg(a0, 0);
 check__guard__dependency2_13_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_variable_3)) goto check__guard__dependency2_13_4;
  x1 = arg(a0, 1);
 check__guard__dependency2_13_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_variable_3)) goto check__guard__dependency2_13_4;
  unify4(a12, a11, a10, a9, a8, a7, a6, a5);
  proceed();
 case VARREF:
  deref_and_jump(x1,check__guard__dependency2_13_3);
  *reasonp++ =  x1;
  goto check__guard__dependency2_13_4;
  };
  goto check__guard__dependency2_13_4;
 case VARREF:
  deref_and_jump(x0,check__guard__dependency2_13_2);
  *reasonp++ =  x0;
  goto check__guard__dependency2_13_4;
  };
  goto check__guard__dependency2_13_4;
 case VARREF:
  deref_and_jump(a0,check__guard__dependency2_13_1);
  *reasonp++ =  a0;
  goto check__guard__dependency2_13_4;
  };
  goto check__guard__dependency2_13_4;
 check__guard__dependency2_13_4:
  otherwise(check__guard__dependency2_13_interrupt);
 check__guard__dependency2_13_5:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor__3D_2)) goto check__guard__dependency2_13_9;
  x0 = arg(a0, 0);
 check__guard__dependency2_13_6:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_variable_3)) goto check__guard__dependency2_13_7;
  allocp[0] = NILATOM;
  allocp[1] = x0;
  x1 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_vdg_xcheck__guard__dependency3_13);
  allocp[4] = x1;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a1;
  allocp[7] = a2;
  allocp[8] = a4;
  allocp[9] = a5;
  allocp[10] = a6;
  allocp[11] = a7;
  allocp[12] = a8;
  allocp[13] = a9;
  allocp[14] = a10;
  allocp[15] = a11;
  allocp[16] = a12;
  allocp[17] = (q)(struct goalrec*)&allocp[2];
  allocp[18] = (q)(&predicate_typeset_xvalue2typeset_5);
  allocp[19] = a1;
  allocp[20] = a2;
  x3 = arg(a0, 1);
  allocp[21] = x3;
  allocp[22] = NILATOM;
  allocp[23] = x2;
  qp = (struct goalrec*)&allocp[17];
  allocp += 24;
  proceed();
 case VARREF:
  deref_and_jump(x0,check__guard__dependency2_13_6);
  *reasonp++ =  x0;
  goto check__guard__dependency2_13_7;
  };
  goto check__guard__dependency2_13_7;
 check__guard__dependency2_13_7:
  x1 = arg(a0, 1);
 check__guard__dependency2_13_8:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_variable_3)) goto check__guard__dependency2_13_9;
  allocp[0] = NILATOM;
  allocp[1] = x1;
  x2 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_vdg_xcheck__guard__dependency3_13);
  allocp[4] = x2;
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = a1;
  allocp[7] = a2;
  allocp[8] = a4;
  allocp[9] = a5;
  allocp[10] = a6;
  allocp[11] = a7;
  allocp[12] = a8;
  allocp[13] = a9;
  allocp[14] = a10;
  allocp[15] = a11;
  allocp[16] = a12;
  allocp[17] = (q)(struct goalrec*)&allocp[2];
  allocp[18] = (q)(&predicate_typeset_xvalue2typeset_5);
  allocp[19] = a1;
  allocp[20] = a2;
  allocp[21] = x0;
  allocp[22] = NILATOM;
  allocp[23] = x3;
  qp = (struct goalrec*)&allocp[17];
  allocp += 24;
  proceed();
 case VARREF:
  deref_and_jump(x1,check__guard__dependency2_13_8);
  *reasonp++ =  x1;
  goto check__guard__dependency2_13_9;
  };
  goto check__guard__dependency2_13_9;
 case VARREF:
  deref_and_jump(a0,check__guard__dependency2_13_5);
  *reasonp++ =  a0;
  goto check__guard__dependency2_13_9;
  };
  goto check__guard__dependency2_13_9;
 check__guard__dependency2_13_9:
  otherwise(check__guard__dependency2_13_interrupt);
 check__guard__dependency2_13_10:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor__3D_2)) goto check__guard__dependency2_13_11;
  unify4(a12, a11, a10, a9, a8, a7, a6, a5);
  x0 = makesym(atom_error);
  x1 = makesym(atom_check__guard__dependency2);
  unify(x0, x1);
  proceed();
 case VARREF:
  deref_and_jump(a0,check__guard__dependency2_13_10);
  *reasonp++ =  a0;
  goto check__guard__dependency2_13_11;
  };
  goto check__guard__dependency2_13_11;
 check__guard__dependency2_13_11:
  otherwise(check__guard__dependency2_13_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vdg_xcheck__guard__dependency3_13);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  allocp[12] = a10;
  allocp[13] = a11;
  allocp[14] = a12;
  allocp[15] = (q)(struct goalrec*)&allocp[0];
  allocp[16] = (q)(&predicate_adg_xget__builtin__ioargs_4);
  allocp[17] = a0;
  allocp[18] = x0;
  allocp[19] = x2 = makeref(&allocp[19]);
  allocp[20] = x1;
  qp = (struct goalrec*)&allocp[15];
  allocp += 21;
  proceed();
 check__guard__dependency2_13_ext_interrupt:
  reasonp = 0l;
 check__guard__dependency2_13_interrupt:
  goto interrupt_13;
 }

 check__guard__dependency3_13_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  qp = qp->next;
 check__guard__dependency3_13_clear_reason:
  reasonp = reasons;
 check__guard__dependency3_13_0:
 check__guard__dependency3_13_1:
  switch (ptagof(a0)) {
 case CONS:
 check__guard__dependency3_13_2:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 check__guard__dependency3_13_3:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto check__guard__dependency3_13_6;
  x1 = car_of(a0);
 check__guard__dependency3_13_4:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_variable_3)) goto check__guard__dependency3_13_6;
  a0 = cdr_of(a0);
  a1 = cdr_of(a1);
  execute(check__guard__dependency3_13_0);
  goto check__guard__dependency3_13_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,check__guard__dependency3_13_4);
  *reasonp++ =  x1;
  goto check__guard__dependency3_13_6;
  };
  goto check__guard__dependency3_13_6;
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_2)) goto check__guard__dependency3_13_6;
  x1 = car_of(a0);
 check__guard__dependency3_13_5:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_variable_3)) goto check__guard__dependency3_13_6;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vdg_xcheck__guard__dependency3_13);
  x2 = cdr_of(a0);
  allocp[2] = x2;
  x3 = cdr_of(a1);
  allocp[3] = x3;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = x4 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = x5 = makeref(&allocp[11]);
  allocp[12] = a10;
  allocp[13] = x6 = makeref(&allocp[13]);
  allocp[14] = a12;
  allocp[15] = makesym(functor_v_4);
  allocp[16] = a2;
  allocp[17] = a3;
  x8 = arg(x1, 0);
  allocp[18] = x8;
  allocp[19] = makeint(-1L);
  x7 = makefunctor(&allocp[15]);
  allocp[20] = (q)(struct goalrec*)&allocp[0];
  allocp[21] = (q)(&predicate_vdg_xcheck__and__entry__vp_7);
  allocp[22] = x9 = makeref(&allocp[22]);
  allocp[23] = x7;
  allocp[24] = a4;
  allocp[25] = a7;
  allocp[26] = x4;
  allocp[27] = a9;
  allocp[28] = x5;
  allocp[29] = (q)(struct goalrec*)&allocp[20];
  allocp[30] = (q)(&predicate_vdg_xread__vd_5);
  allocp[31] = a2;
  allocp[32] = a3;
  x10 = arg(x1, 0);
  allocp[33] = x10;
  allocp[34] = x9;
  allocp[35] = x6;
  a0 = a2;
  a1 = a3;
  a2 = x10;
  a3 = arg(x0, 0);
  a4 = a11;
  a5 = x6;
  qp = (struct goalrec*)&allocp[29];
  allocp += 36;
  execute(entry__gd_6_0);
  goto entry__gd_6_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,check__guard__dependency3_13_5);
  *reasonp++ =  x1;
  goto check__guard__dependency3_13_6;
  };
  goto check__guard__dependency3_13_6;
 case VARREF:
  deref_and_jump(x0,check__guard__dependency3_13_3);
  *reasonp++ =  x0;
  goto check__guard__dependency3_13_6;
  };
  goto check__guard__dependency3_13_6;
 case VARREF:
  deref_and_jump(a1,check__guard__dependency3_13_2);
  *reasonp++ =  a1;
  goto check__guard__dependency3_13_6;
  };
  goto check__guard__dependency3_13_6;
 case VARREF:
  deref_and_jump(a0,check__guard__dependency3_13_1);
  *reasonp++ =  a0;
  goto check__guard__dependency3_13_6;
  };
  goto check__guard__dependency3_13_6;
 check__guard__dependency3_13_6:
  otherwise(check__guard__dependency3_13_interrupt);
 check__guard__dependency3_13_7:
  switch (ptagof(a0)) {
 case CONS:
 check__guard__dependency3_13_8:
  switch (ptagof(a1)) {
 case CONS:
  a0 = cdr_of(a0);
  a1 = cdr_of(a1);
  execute(check__guard__dependency3_13_0);
  goto check__guard__dependency3_13_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,check__guard__dependency3_13_8);
  *reasonp++ =  a1;
  goto check__guard__dependency3_13_interrupt;
  };
  goto check__guard__dependency3_13_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto check__guard__dependency3_13_interrupt;
 check__guard__dependency3_13_9:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != NILATOM) goto check__guard__dependency3_13_interrupt;
  unify4(a12, a11, a10, a9, a8, a7, a6, a5);
  proceed();
 case VARREF:
  deref_and_jump(a1,check__guard__dependency3_13_9);
  *reasonp++ =  a1;
  goto check__guard__dependency3_13_interrupt;
  };
  goto check__guard__dependency3_13_interrupt;
 case VARREF:
  deref_and_jump(a0,check__guard__dependency3_13_7);
  *reasonp++ =  a0;
  goto check__guard__dependency3_13_interrupt;
  };
  goto check__guard__dependency3_13_interrupt;
 check__guard__dependency3_13_ext_interrupt:
  reasonp = 0l;
 check__guard__dependency3_13_interrupt:
  goto interrupt_13;
 }

 check__ogoal1_21_top: {
  q x0, x1, x2;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  a18 = qp->args[18];
  a19 = qp->args[19];
  a20 = qp->args[20];
  qp = qp->next;
 check__ogoal1_21_clear_reason:
  reasonp = reasons;
 check__ogoal1_21_0:
 check__ogoal1_21_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_builtin)) goto check__ogoal1_21_5;
 check__ogoal1_21_2:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom__3D)) goto check__ogoal1_21_5;
 check__ogoal1_21_3:
  switch (ptagof(a3)) {
 case ATOMIC:
 check__ogoal1_21_4:
  if (a3 != makeint(2L)) goto check__ogoal1_21_5;
  unify(a14, a13);
  a0 = a7;
  a1 = a4;
  a2 = a5;
  a3 = a6;
  a4 = a8;
  a5 = a11;
  a6 = a15;
  a7 = a16;
  a8 = a17;
  a9 = a18;
  a10 = a19;
  a11 = a20;
  execute(entry__ivar__vd__unify_12_0);
  goto entry__ivar__vd__unify_12_ext_interrupt;
 case VARREF:
  deref_and_jump(a3,check__ogoal1_21_3);
  *reasonp++ =  a3;
  goto check__ogoal1_21_5;
  };
  goto check__ogoal1_21_5;
 case VARREF:
  deref_and_jump(a2,check__ogoal1_21_2);
  *reasonp++ =  a2;
  goto check__ogoal1_21_5;
  };
  goto check__ogoal1_21_5;
 case VARREF:
  deref_and_jump(a0,check__ogoal1_21_1);
  *reasonp++ =  a0;
  goto check__ogoal1_21_5;
  };
  goto check__ogoal1_21_5;
 check__ogoal1_21_5:
  otherwise(check__ogoal1_21_interrupt);
 check__ogoal1_21_6:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto check__ogoal1_21_11;
  switch (symval(a0)) {
 case symval(makesym(atom_builtin)):
  unify(a14, a13);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vdg_xentry__ivars__builtin_13);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a7;
  allocp[4] = a8;
  allocp[5] = a4;
  allocp[6] = a5;
  allocp[7] = a6;
  allocp[8] = a11;
  allocp[9] = a15;
  allocp[10] = a16;
  allocp[11] = a17;
  allocp[12] = a18;
  allocp[13] = a19;
  allocp[14] = a20;
  allocp[15] = (q)(struct goalrec*)&allocp[0];
  allocp[16] = (q)(&predicate_vt_xread__ts_5);
  allocp[17] = a12;
  allocp[18] = a4;
  allocp[19] = a5;
  allocp[20] = a6;
  allocp[21] = x0;
  qp = (struct goalrec*)&allocp[15];
  allocp += 22;
  proceed();
 case symval(makesym(atom_userdef)):
 check__ogoal1_21_7:
  if (isref(a10)) goto check__ogoal1_21_10;
 check__ogoal1_21_8:
  if (isref(a10)) goto check__ogoal1_21_9;
  if_not_equal(a10, a11, check__ogoal1_21_11);
  unify4(a20, a19, a18, a17, a16, a15, a14, a13);
  proceed();
 check__ogoal1_21_9:
  deref_and_jump(a10,check__ogoal1_21_8);
  *reasonp++ =  a10;
  goto check__ogoal1_21_11;
 check__ogoal1_21_10:
  deref_and_jump(a10,check__ogoal1_21_7);
  *reasonp++ =  a10;
  goto check__ogoal1_21_11;
  };
  goto check__ogoal1_21_11;
 case VARREF:
  deref_and_jump(a0,check__ogoal1_21_6);
  *reasonp++ =  a0;
  goto check__ogoal1_21_11;
  };
  goto check__ogoal1_21_11;
 check__ogoal1_21_11:
  otherwise(check__ogoal1_21_interrupt);
 check__ogoal1_21_12:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_userdef)) goto check__ogoal1_21_interrupt;
  unify3(a20, a19, a18, a17, a16, a15);
  allocp[0] = makesym(functor_v_4);
  allocp[1] = a4;
  allocp[2] = a5;
  allocp[3] = a6;
  allocp[4] = makeint(-1L);
  x0 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_entry_4);
  allocp[6] = x0;
  allocp[7] = a10;
  allocp[8] = a11;
  allocp[9] = a9;
  x1 = makefunctor(&allocp[5]);
  allocp[10] = a13;
  allocp[11] = x1;
  x2 = makecons(&allocp[10]);
  allocp += 12;
  unify_value(a14, x2);
  proceed();
 case VARREF:
  deref_and_jump(a0,check__ogoal1_21_12);
  *reasonp++ =  a0;
  goto check__ogoal1_21_interrupt;
  };
  goto check__ogoal1_21_interrupt;
 check__ogoal1_21_ext_interrupt:
  reasonp = 0l;
 check__ogoal1_21_interrupt:
  goto interrupt_21;
 }

 entry__ivars__builtin_13_top: {
  q x0, x1, x2, x3, x4;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  qp = qp->next;
 entry__ivars__builtin_13_clear_reason:
  reasonp = reasons;
 entry__ivars__builtin_13_0:
 entry__ivars__builtin_13_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 entry__ivars__builtin_13_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_2)) goto entry__ivars__builtin_13_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vdg_xentry__ivars__builtin_13);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = x3 = makeref(&allocp[11]);
  allocp[12] = a10;
  allocp[13] = x4 = makeref(&allocp[13]);
  allocp[14] = a12;
  a0 = arg(x0, 0);
  a8 = x2;
  a10 = x3;
  a12 = x4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 15;
  execute(entry__ivars__builtin1_13_0);
  goto entry__ivars__builtin1_13_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,entry__ivars__builtin_13_2);
  *reasonp++ =  x0;
  goto entry__ivars__builtin_13_interrupt;
  };
  goto entry__ivars__builtin_13_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto entry__ivars__builtin_13_interrupt;
  unify3(a12, a11, a10, a9, a8, a7);
  proceed();
 case VARREF:
  deref_and_jump(a0,entry__ivars__builtin_13_1);
  *reasonp++ =  a0;
  goto entry__ivars__builtin_13_interrupt;
  };
  goto entry__ivars__builtin_13_interrupt;
 entry__ivars__builtin_13_ext_interrupt:
  reasonp = 0l;
 entry__ivars__builtin_13_interrupt:
  goto interrupt_13;
 }

 entry__ivars__builtin1_13_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  qp = qp->next;
 entry__ivars__builtin1_13_clear_reason:
  reasonp = reasons;
 entry__ivars__builtin1_13_0:
 entry__ivars__builtin1_13_1:
  switch (ptagof(a1)) {
 case CONS:
 entry__ivars__builtin1_13_2:
  switch (ptagof(a2)) {
 case CONS:
  x0 = car_of(a2);
 entry__ivars__builtin1_13_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_2)) goto entry__ivars__builtin1_13_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vdg_xentry__ivars__builtin1_13);
  allocp[2] = a0;
  x1 = cdr_of(a1);
  allocp[3] = x1;
  x2 = cdr_of(a2);
  allocp[4] = x2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = x3 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = x4 = makeref(&allocp[11]);
  allocp[12] = a10;
  allocp[13] = x5 = makeref(&allocp[13]);
  allocp[14] = a12;
  x6 = car_of(a1);
  a1 = arg(x0, 0);
  a2 = a3;
  a3 = a4;
  a4 = a5;
  a5 = a0;
  a8 = x3;
  a10 = x4;
  a12 = x5;
  a0 = x6;
  qp = (struct goalrec*)&allocp[0];
  allocp += 15;
  execute(entry__ivar__vd_13_0);
  goto entry__ivar__vd_13_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,entry__ivars__builtin1_13_3);
  *reasonp++ =  x0;
  goto entry__ivars__builtin1_13_interrupt;
  };
  goto entry__ivars__builtin1_13_interrupt;
 case VARREF:
  deref_and_jump(a2,entry__ivars__builtin1_13_2);
  *reasonp++ =  a2;
  goto entry__ivars__builtin1_13_interrupt;
  };
  goto entry__ivars__builtin1_13_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto entry__ivars__builtin1_13_interrupt;
 entry__ivars__builtin1_13_4:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != NILATOM) goto entry__ivars__builtin1_13_interrupt;
  unify3(a12, a11, a10, a9, a8, a7);
  proceed();
 case VARREF:
  deref_and_jump(a2,entry__ivars__builtin1_13_4);
  *reasonp++ =  a2;
  goto entry__ivars__builtin1_13_interrupt;
  };
  goto entry__ivars__builtin1_13_interrupt;
 case VARREF:
  deref_and_jump(a1,entry__ivars__builtin1_13_1);
  *reasonp++ =  a1;
  goto entry__ivars__builtin1_13_interrupt;
  };
  goto entry__ivars__builtin1_13_interrupt;
 entry__ivars__builtin1_13_ext_interrupt:
  reasonp = 0l;
 entry__ivars__builtin1_13_interrupt:
  toppred = &predicate_vdg_xentry__ivars__builtin1_13;
  goto interrupt_13;
 }

 entry__ivar__vd__unify_12_top: {
  q x0, x1, x2;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 entry__ivar__vd__unify_12_clear_reason:
  reasonp = reasons;
 entry__ivar__vd__unify_12_0:
 entry__ivar__vd__unify_12_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = cdr_of(a0);
 entry__ivar__vd__unify_12_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != NILATOM) goto entry__ivar__vd__unify_12_6;
 entry__ivar__vd__unify_12_3:
  switch (ptagof(a4)) {
 case CONS:
  x1 = cdr_of(a4);
 entry__ivar__vd__unify_12_4:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto entry__ivar__vd__unify_12_6;
  x2 = car_of(a0);
 entry__ivar__vd__unify_12_5:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_variable_3)) goto entry__ivar__vd__unify_12_6;
  a0 = car_of(a4);
  a4 = x2;
  execute(entry__ivar__vd__unify1_12_0);
  goto entry__ivar__vd__unify1_12_ext_interrupt;
 case VARREF:
  deref_and_jump(x2,entry__ivar__vd__unify_12_5);
  *reasonp++ =  x2;
  goto entry__ivar__vd__unify_12_6;
  };
  goto entry__ivar__vd__unify_12_6;
 case VARREF:
  deref_and_jump(x1,entry__ivar__vd__unify_12_4);
  *reasonp++ =  x1;
  goto entry__ivar__vd__unify_12_6;
  };
  goto entry__ivar__vd__unify_12_6;
 case VARREF:
  deref_and_jump(a4,entry__ivar__vd__unify_12_3);
  *reasonp++ =  a4;
  goto entry__ivar__vd__unify_12_6;
  };
  goto entry__ivar__vd__unify_12_6;
 case VARREF:
  deref_and_jump(x0,entry__ivar__vd__unify_12_2);
  *reasonp++ =  x0;
  goto entry__ivar__vd__unify_12_6;
  };
  goto entry__ivar__vd__unify_12_6;
 case VARREF:
  deref_and_jump(a0,entry__ivar__vd__unify_12_1);
  *reasonp++ =  a0;
  goto entry__ivar__vd__unify_12_6;
  };
  goto entry__ivar__vd__unify_12_6;
 entry__ivar__vd__unify_12_6:
  otherwise(entry__ivar__vd__unify_12_interrupt);
 entry__ivar__vd__unify_12_7:
  switch (ptagof(a0)) {
 case CONS:
  x0 = cdr_of(a0);
 entry__ivar__vd__unify_12_8:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != NILATOM) goto entry__ivar__vd__unify_12_interrupt;
 entry__ivar__vd__unify_12_9:
  switch (ptagof(a4)) {
 case CONS:
  x1 = cdr_of(a4);
 entry__ivar__vd__unify_12_10:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto entry__ivar__vd__unify_12_interrupt;
  x2 = car_of(a4);
  a4 = car_of(a0);
  a0 = x2;
  execute(entry__ivar__vd__unify1_12_0);
  goto entry__ivar__vd__unify1_12_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,entry__ivar__vd__unify_12_10);
  *reasonp++ =  x1;
  goto entry__ivar__vd__unify_12_interrupt;
  };
  goto entry__ivar__vd__unify_12_interrupt;
 case VARREF:
  deref_and_jump(a4,entry__ivar__vd__unify_12_9);
  *reasonp++ =  a4;
  goto entry__ivar__vd__unify_12_interrupt;
  };
  goto entry__ivar__vd__unify_12_interrupt;
 case VARREF:
  deref_and_jump(x0,entry__ivar__vd__unify_12_8);
  *reasonp++ =  x0;
  goto entry__ivar__vd__unify_12_interrupt;
  };
  goto entry__ivar__vd__unify_12_interrupt;
 case VARREF:
  deref_and_jump(a0,entry__ivar__vd__unify_12_7);
  *reasonp++ =  a0;
  goto entry__ivar__vd__unify_12_interrupt;
  };
  goto entry__ivar__vd__unify_12_interrupt;
 entry__ivar__vd__unify_12_ext_interrupt:
  reasonp = 0l;
 entry__ivar__vd__unify_12_interrupt:
  toppred = &predicate_vdg_xentry__ivar__vd__unify_12;
  goto interrupt_12;
 }

 entry__ivar__vd__unify2_12_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 entry__ivar__vd__unify2_12_clear_reason:
  reasonp = reasons;
 entry__ivar__vd__unify2_12_0:
 entry__ivar__vd__unify2_12_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 entry__ivar__vd__unify2_12_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto entry__ivar__vd__unify2_12_interrupt;
  a0 = cdr_of(a0);
  execute(entry__ivar__vd__unify2_12_0);
  goto entry__ivar__vd__unify2_12_ext_interrupt;
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_t_2:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vdg_xentry__ivar__vd__unify2_12);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x3 = makeref(&allocp[10]);
  allocp[11] = a9;
  allocp[12] = x4 = makeref(&allocp[12]);
  allocp[13] = a11;
  a0 = a1;
  a1 = arg(x0, 0);
  x5 = arg(x0, 0);
  x6 = a5;
  a7 = a6;
  a9 = a8;
  a11 = a10;
  a12 = x4;
  a10 = x3;
  a8 = x2;
  a6 = x6;
  a5 = x5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 14;
  execute(entry__ivar__vd_13_0);
  goto entry__ivar__vd_13_ext_interrupt;
 case functor_tv_2:
  a0 = cdr_of(a0);
  execute(entry__ivar__vd__unify2_12_0);
  goto entry__ivar__vd__unify2_12_ext_interrupt;
 case functor_te_4:
  a0 = cdr_of(a0);
  execute(entry__ivar__vd__unify2_12_0);
  goto entry__ivar__vd__unify2_12_ext_interrupt;
  };
  goto entry__ivar__vd__unify2_12_interrupt;
 case VARREF:
  deref_and_jump(x0,entry__ivar__vd__unify2_12_2);
  *reasonp++ =  x0;
  goto entry__ivar__vd__unify2_12_interrupt;
  };
  goto entry__ivar__vd__unify2_12_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto entry__ivar__vd__unify2_12_interrupt;
  unify3(a11, a10, a9, a8, a7, a6);
  proceed();
 case VARREF:
  deref_and_jump(a0,entry__ivar__vd__unify2_12_1);
  *reasonp++ =  a0;
  goto entry__ivar__vd__unify2_12_interrupt;
  };
  goto entry__ivar__vd__unify2_12_interrupt;
 entry__ivar__vd__unify2_12_ext_interrupt:
  reasonp = 0l;
 entry__ivar__vd__unify2_12_interrupt:
  goto interrupt_12;
 }

 entry__ivar__vd__unify1_12_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 entry__ivar__vd__unify1_12_clear_reason:
  reasonp = reasons;
 entry__ivar__vd__unify1_12_0:
 entry__ivar__vd__unify1_12_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 entry__ivar__vd__unify1_12_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto entry__ivar__vd__unify1_12_interrupt;
  a0 = cdr_of(a0);
  execute(entry__ivar__vd__unify1_12_0);
  goto entry__ivar__vd__unify1_12_ext_interrupt;
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_t_2:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vdg_xentry__ivar__vd__unify1_12);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x3 = makeref(&allocp[10]);
  allocp[11] = a9;
  allocp[12] = x4 = makeref(&allocp[12]);
  allocp[13] = a11;
  a0 = a4;
  x5 = arg(x0, 0);
  x6 = a1;
  x7 = a2;
  a4 = a3;
  x8 = arg(x0, 0);
  x9 = a5;
  a7 = a6;
  a9 = a8;
  a11 = a10;
  a12 = x4;
  a10 = x3;
  a8 = x2;
  a6 = x9;
  a5 = x8;
  a3 = x7;
  a2 = x6;
  a1 = x5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 14;
  execute(entry__ivar__vd_13_0);
  goto entry__ivar__vd_13_ext_interrupt;
 case functor_tv_2:
  a0 = cdr_of(a0);
  execute(entry__ivar__vd__unify1_12_0);
  goto entry__ivar__vd__unify1_12_ext_interrupt;
 case functor_te_4:
  a0 = cdr_of(a0);
  execute(entry__ivar__vd__unify1_12_0);
  goto entry__ivar__vd__unify1_12_ext_interrupt;
  };
  goto entry__ivar__vd__unify1_12_interrupt;
 case VARREF:
  deref_and_jump(x0,entry__ivar__vd__unify1_12_2);
  *reasonp++ =  x0;
  goto entry__ivar__vd__unify1_12_interrupt;
  };
  goto entry__ivar__vd__unify1_12_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto entry__ivar__vd__unify1_12_interrupt;
  unify3(a11, a10, a9, a8, a7, a6);
  proceed();
 case VARREF:
  deref_and_jump(a0,entry__ivar__vd__unify1_12_1);
  *reasonp++ =  a0;
  goto entry__ivar__vd__unify1_12_interrupt;
  };
  goto entry__ivar__vd__unify1_12_interrupt;
 entry__ivar__vd__unify1_12_ext_interrupt:
  reasonp = 0l;
 entry__ivar__vd__unify1_12_interrupt:
  toppred = &predicate_vdg_xentry__ivar__vd__unify1_12;
  goto interrupt_12;
 }

 entry__ivar__vd_13_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  qp = qp->next;
 entry__ivar__vd_13_clear_reason:
  reasonp = reasons;
 entry__ivar__vd_13_0:
 entry__ivar__vd_13_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_variable_3)) goto entry__ivar__vd_13_2;
  allocp[0] = makesym(functor_v_4);
  allocp[1] = a2;
  allocp[2] = a3;
  x1 = arg(a0, 0);
  allocp[3] = x1;
  x2 = arg(a0, 1);
  allocp[4] = x2;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_v_3);
  allocp[6] = a2;
  allocp[7] = a3;
  x4 = arg(a0, 0);
  allocp[8] = x4;
  x3 = makefunctor(&allocp[5]);
  allocp[9] = makesym(functor_ti_2);
  allocp[10] = x3;
  allocp[11] = a1;
  x5 = makefunctor(&allocp[9]);
  allocp[12] = NILATOM;
  allocp[13] = x5;
  x6 = makecons(&allocp[12]);
  allocp[14] = (q)qp;
  allocp[15] = (q)(&predicate_vdg_xcheck__and__entry__vp_7);
  allocp[16] = x7 = makeref(&allocp[16]);
  allocp[17] = x0;
  allocp[18] = a6;
  allocp[19] = a7;
  allocp[20] = a8;
  allocp[21] = a9;
  allocp[22] = a10;
  allocp[23] = (q)(struct goalrec*)&allocp[14];
  allocp[24] = (q)(&predicate_vdg_xread__vd_5);
  allocp[25] = a2;
  allocp[26] = a3;
  x8 = arg(a0, 0);
  allocp[27] = x8;
  allocp[28] = x7;
  allocp[29] = a12;
  a0 = a2;
  a1 = a3;
  a2 = a4;
  a3 = a5;
  a4 = x6;
  a5 = a11;
  a6 = a12;
  qp = (struct goalrec*)&allocp[23];
  allocp += 30;
  execute(entry__vd_7_0);
  goto entry__vd_7_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,entry__ivar__vd_13_1);
  *reasonp++ =  a0;
  goto entry__ivar__vd_13_2;
  };
  goto entry__ivar__vd_13_2;
 entry__ivar__vd_13_2:
  otherwise(entry__ivar__vd_13_interrupt);
  unify2(a10, a9, a8, a7);
  a0 = a2;
  a1 = a3;
  a2 = a4;
  a3 = a5;
  a4 = NILATOM;
  a5 = a11;
  a6 = a12;
  execute(entry__vd_7_0);
  goto entry__vd_7_ext_interrupt;
 entry__ivar__vd_13_ext_interrupt:
  reasonp = 0l;
 entry__ivar__vd_13_interrupt:
  toppred = &predicate_vdg_xentry__ivar__vd_13;
  goto interrupt_13;
 }

 check__dgoal__unify_15_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  qp = qp->next;
 check__dgoal__unify_15_clear_reason:
  reasonp = reasons;
 check__dgoal__unify_15_0:
 check__dgoal__unify_15_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_variable_3)) goto check__dgoal__unify_15_13;
  x0 = arg(a0, 0);
 check__dgoal__unify_15_2:
  if (isref(x0)) goto check__dgoal__unify_15_6;
 check__dgoal__unify_15_3:
  if (isref(x0)) goto check__dgoal__unify_15_5;
  if_not_equal(x0, a5, check__dgoal__unify_15_7);
 check__dgoal__unify_15_4:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_variable_3)) goto check__dgoal__unify_15_7;
  allocp[0] = makesym(functor_v_4);
  allocp[1] = a3;
  allocp[2] = a4;
  x2 = arg(a1, 0);
  allocp[3] = x2;
  x3 = arg(a1, 1);
  allocp[4] = x3;
  x1 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_v_3);
  allocp[6] = a3;
  allocp[7] = a4;
  x5 = arg(a1, 0);
  allocp[8] = x5;
  x4 = makefunctor(&allocp[5]);
  allocp[9] = makesym(functor_ti_2);
  allocp[10] = x4;
  allocp[11] = a2;
  x6 = makefunctor(&allocp[9]);
  allocp[12] = NILATOM;
  allocp[13] = x6;
  x7 = makecons(&allocp[12]);
  x8 = makesym(atom_yes);
  allocp += 14;
  unify_value(a8, x8);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vdg_xcheck__and__entry__vp_7);
  allocp[2] = x9 = makeref(&allocp[2]);
  allocp[3] = x1;
  allocp[4] = a6;
  allocp[5] = a9;
  allocp[6] = a10;
  allocp[7] = a11;
  allocp[8] = a12;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_vdg_xread__vd_5);
  allocp[11] = a3;
  allocp[12] = a4;
  x10 = arg(a1, 0);
  allocp[13] = x10;
  allocp[14] = x9;
  allocp[15] = a14;
  a0 = a3;
  a1 = a4;
  x11 = a5;
  a3 = a2;
  a4 = x7;
  a5 = a13;
  a6 = a14;
  a2 = x11;
  qp = (struct goalrec*)&allocp[9];
  allocp += 16;
  execute(entry__vd_7_clear_reason);
  goto entry__vd_7_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,check__dgoal__unify_15_4);
  *reasonp++ =  a1;
  goto check__dgoal__unify_15_7;
  };
  goto check__dgoal__unify_15_7;
 check__dgoal__unify_15_5:
  deref_and_jump(x0,check__dgoal__unify_15_3);
  *reasonp++ =  x0;
  goto check__dgoal__unify_15_7;
 check__dgoal__unify_15_6:
  deref_and_jump(x0,check__dgoal__unify_15_2);
  *reasonp++ =  x0;
  goto check__dgoal__unify_15_7;
 check__dgoal__unify_15_7:
 check__dgoal__unify_15_8:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_variable_3)) goto check__dgoal__unify_15_13;
  x1 = arg(a1, 0);
 check__dgoal__unify_15_9:
  if (isref(x1)) goto check__dgoal__unify_15_12;
 check__dgoal__unify_15_10:
  if (isref(x1)) goto check__dgoal__unify_15_11;
  if_not_equal(x1, a5, check__dgoal__unify_15_13);
  allocp[0] = makesym(functor_v_4);
  allocp[1] = a3;
  allocp[2] = a4;
  allocp[3] = x0;
  x3 = arg(a0, 1);
  allocp[4] = x3;
  x2 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_v_3);
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = x0;
  x4 = makefunctor(&allocp[5]);
  allocp[9] = makesym(functor_ti_2);
  allocp[10] = x4;
  allocp[11] = a2;
  x5 = makefunctor(&allocp[9]);
  allocp[12] = NILATOM;
  allocp[13] = x5;
  x6 = makecons(&allocp[12]);
  x7 = makesym(atom_yes);
  allocp += 14;
  unify_value(a8, x7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vdg_xcheck__and__entry__vp_7);
  allocp[2] = x8 = makeref(&allocp[2]);
  allocp[3] = x2;
  allocp[4] = a6;
  allocp[5] = a9;
  allocp[6] = a10;
  allocp[7] = a11;
  allocp[8] = a12;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_vdg_xread__vd_5);
  allocp[11] = a3;
  allocp[12] = a4;
  allocp[13] = x0;
  allocp[14] = x8;
  allocp[15] = a14;
  a0 = a3;
  a1 = a4;
  x9 = a5;
  a3 = a2;
  a4 = x6;
  a5 = a13;
  a6 = a14;
  a2 = x9;
  qp = (struct goalrec*)&allocp[9];
  allocp += 16;
  execute(entry__vd_7_clear_reason);
  goto entry__vd_7_ext_interrupt;
 check__dgoal__unify_15_11:
  deref_and_jump(x1,check__dgoal__unify_15_10);
  *reasonp++ =  x1;
  goto check__dgoal__unify_15_13;
 check__dgoal__unify_15_12:
  deref_and_jump(x1,check__dgoal__unify_15_9);
  *reasonp++ =  x1;
  goto check__dgoal__unify_15_13;
 case VARREF:
  deref_and_jump(a1,check__dgoal__unify_15_8);
  *reasonp++ =  a1;
  goto check__dgoal__unify_15_13;
  };
  goto check__dgoal__unify_15_13;
 case VARREF:
  deref_and_jump(a0,check__dgoal__unify_15_1);
  *reasonp++ =  a0;
  goto check__dgoal__unify_15_13;
  };
  goto check__dgoal__unify_15_13;
 check__dgoal__unify_15_13:
  otherwise(check__dgoal__unify_15_interrupt);
 check__dgoal__unify_15_14:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_variable_3)) goto check__dgoal__unify_15_19;
  x0 = arg(a0, 0);
 check__dgoal__unify_15_15:
  if (isref(x0)) goto check__dgoal__unify_15_18;
 check__dgoal__unify_15_16:
  if (isref(x0)) goto check__dgoal__unify_15_17;
  if_not_equal(x0, a5, check__dgoal__unify_15_19);
  unify2(a12, a11, a10, a9);
  x1 = NILATOM;
  x2 = makesym(atom_yes);
  unify_value(a8, x2);
  a0 = a3;
  a1 = a4;
  x3 = a5;
  a3 = a2;
  a4 = x1;
  a5 = a13;
  a6 = a14;
  a2 = x3;
  execute(entry__vd_7_clear_reason);
  goto entry__vd_7_ext_interrupt;
 check__dgoal__unify_15_17:
  deref_and_jump(x0,check__dgoal__unify_15_16);
  *reasonp++ =  x0;
  goto check__dgoal__unify_15_19;
 check__dgoal__unify_15_18:
  deref_and_jump(x0,check__dgoal__unify_15_15);
  *reasonp++ =  x0;
  goto check__dgoal__unify_15_19;
 case VARREF:
  deref_and_jump(a0,check__dgoal__unify_15_14);
  *reasonp++ =  a0;
  goto check__dgoal__unify_15_19;
  };
  goto check__dgoal__unify_15_19;
 check__dgoal__unify_15_19:
 check__dgoal__unify_15_20:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_variable_3)) goto check__dgoal__unify_15_25;
  x0 = arg(a1, 0);
 check__dgoal__unify_15_21:
  if (isref(x0)) goto check__dgoal__unify_15_24;
 check__dgoal__unify_15_22:
  if (isref(x0)) goto check__dgoal__unify_15_23;
  if_not_equal(x0, a5, check__dgoal__unify_15_25);
  unify2(a12, a11, a10, a9);
  x1 = NILATOM;
  x2 = makesym(atom_yes);
  unify_value(a8, x2);
  a0 = a3;
  a1 = a4;
  x3 = a5;
  a3 = a2;
  a4 = x1;
  a5 = a13;
  a6 = a14;
  a2 = x3;
  execute(entry__vd_7_clear_reason);
  goto entry__vd_7_ext_interrupt;
 check__dgoal__unify_15_23:
  deref_and_jump(x0,check__dgoal__unify_15_22);
  *reasonp++ =  x0;
  goto check__dgoal__unify_15_25;
 check__dgoal__unify_15_24:
  deref_and_jump(x0,check__dgoal__unify_15_21);
  *reasonp++ =  x0;
  goto check__dgoal__unify_15_25;
 case VARREF:
  deref_and_jump(a1,check__dgoal__unify_15_20);
  *reasonp++ =  a1;
  goto check__dgoal__unify_15_25;
  };
  goto check__dgoal__unify_15_25;
 check__dgoal__unify_15_25:
  otherwise(check__dgoal__unify_15_interrupt);
  unify3(a14, a13, a12, a11, a10, a9);
  x0 = makesym(atom_no);
  unify_value(a8, x0);
  proceed();
 check__dgoal__unify_15_ext_interrupt:
  reasonp = 0l;
 check__dgoal__unify_15_interrupt:
  goto interrupt_15;
 }

 entry__vd_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 entry__vd_7_clear_reason:
  reasonp = reasons;
 entry__vd_7_0:
 entry__vd_7_1:
  switch (ptagof(a5)) {
 case CONS:
  x0 = car_of(a5);
 entry__vd_7_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto entry__vd_7_7;
  x1 = arg(x0, 0);
 entry__vd_7_3:
  if (isref(x1)) goto entry__vd_7_6;
 entry__vd_7_4:
  if (isref(x1)) goto entry__vd_7_5;
  if_not_equal(x1, a0, entry__vd_7_7);
  allocp[0] = makesym(functor_module_2);
  allocp[1] = a0;
  allocp[2] = x3 = makeref(&allocp[2]);
  x2 = makefunctor(&allocp[0]);
  x5 = cdr_of(a5);
  allocp[3] = x5;
  allocp[4] = x2;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a6, x4);
  allocp[0] = makesym(functor_clause_2);
  allocp[1] = x7 = makeref(&allocp[1]);
  allocp[2] = x8 = makeref(&allocp[2]);
  x6 = makefunctor(&allocp[0]);
  allocp[3] = (q)qp;
  allocp[4] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[5] = a1;
  x9 = arg(x0, 1);
  allocp[6] = x9;
  allocp[7] = x6;
  allocp[8] = x3;
  allocp[9] = (q)(struct goalrec*)&allocp[3];
  allocp[10] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[11] = x10 = makeref(&allocp[11]);
  allocp[12] = x11 = makeref(&allocp[12]);
  allocp[13] = x12 = makeref(&allocp[13]);
  allocp[14] = x8;
  allocp[15] = (q)(struct goalrec*)&allocp[9];
  allocp[16] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[17] = a2;
  allocp[18] = makeint(1L);
  allocp[19] = x10;
  allocp[20] = makesym(functor_to_2);
  allocp[21] = a3;
  allocp[22] = a4;
  x13 = makefunctor(&allocp[20]);
  allocp[23] = NILATOM;
  allocp[24] = x13;
  x14 = makecons(&allocp[23]);
  allocp[25] = (q)(struct goalrec*)&allocp[15];
  allocp[26] = (q)(&predicate_vdg_xmerge__vd_3);
  allocp[27] = x15 = makeref(&allocp[27]);
  allocp[28] = x14;
  allocp[29] = x12;
  allocp[30] = (q)(struct goalrec*)&allocp[25];
  allocp[31] = (q)(&predicate_functor__table_xarg_3);
  allocp[32] = x16 = makeref(&allocp[32]);
  allocp[33] = x11;
  allocp[34] = x15;
  allocp[35] = (q)(struct goalrec*)&allocp[30];
  allocp[36] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[37] = a2;
  allocp[38] = makeint(1L);
  allocp[39] = x16;
  allocp[40] = makesym(functor_clause_2);
  allocp[41] = x7;
  allocp[42] = x11;
  x17 = makefunctor(&allocp[40]);
  allocp[43] = (q)(struct goalrec*)&allocp[35];
  allocp[44] = (q)(&predicate_functor__table_xarg_3);
  allocp[45] = a1;
  allocp[46] = x9;
  allocp[47] = x17;
  qp = (struct goalrec*)&allocp[43];
  allocp += 48;
  proceed();
 entry__vd_7_5:
  deref_and_jump(x1,entry__vd_7_4);
  *reasonp++ =  x1;
  goto entry__vd_7_7;
 entry__vd_7_6:
  deref_and_jump(x1,entry__vd_7_3);
  *reasonp++ =  x1;
  goto entry__vd_7_7;
 case VARREF:
  deref_and_jump(x0,entry__vd_7_2);
  *reasonp++ =  x0;
  goto entry__vd_7_7;
  };
  goto entry__vd_7_7;
 case VARREF:
  deref_and_jump(a5,entry__vd_7_1);
  *reasonp++ =  a5;
  goto entry__vd_7_7;
  };
  goto entry__vd_7_7;
 entry__vd_7_7:
  otherwise(entry__vd_7_interrupt);
 entry__vd_7_8:
  switch (ptagof(a5)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a5);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a6, x0);
  a5 = cdr_of(a5);
  a6 = x1;
  execute(entry__vd_7_0);
  goto entry__vd_7_ext_interrupt;
 case VARREF:
  deref_and_jump(a5,entry__vd_7_8);
  *reasonp++ =  a5;
  goto entry__vd_7_interrupt;
  };
  goto entry__vd_7_interrupt;
 entry__vd_7_ext_interrupt:
  reasonp = 0l;
 entry__vd_7_interrupt:
  toppred = &predicate_vdg_xentry__vd_7;
  goto interrupt_7;
 }

 entry__gd_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 entry__gd_6_clear_reason:
  reasonp = reasons;
 entry__gd_6_0:
 entry__gd_6_1:
  switch (ptagof(a4)) {
 case CONS:
  x0 = car_of(a4);
 entry__gd_6_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto entry__gd_6_7;
  x1 = arg(x0, 0);
 entry__gd_6_3:
  if (isref(x1)) goto entry__gd_6_6;
 entry__gd_6_4:
  if (isref(x1)) goto entry__gd_6_5;
  if_not_equal(x1, a0, entry__gd_6_7);
  allocp[0] = makesym(functor_module_2);
  allocp[1] = a0;
  allocp[2] = x3 = makeref(&allocp[2]);
  x2 = makefunctor(&allocp[0]);
  x5 = cdr_of(a4);
  allocp[3] = x5;
  allocp[4] = x2;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a5, x4);
  allocp[0] = makesym(functor_clause_2);
  allocp[1] = x7 = makeref(&allocp[1]);
  allocp[2] = x8 = makeref(&allocp[2]);
  x6 = makefunctor(&allocp[0]);
  allocp[3] = (q)qp;
  allocp[4] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[5] = a1;
  x9 = arg(x0, 1);
  allocp[6] = x9;
  allocp[7] = x6;
  allocp[8] = x3;
  allocp[9] = makesym(functor_v_3);
  allocp[10] = a0;
  allocp[11] = a1;
  allocp[12] = a2;
  x10 = makefunctor(&allocp[9]);
  allocp[13] = makesym(functor_ti_2);
  allocp[14] = x10;
  allocp[15] = a3;
  x11 = makefunctor(&allocp[13]);
  allocp[16] = NILATOM;
  allocp[17] = x11;
  x12 = makecons(&allocp[16]);
  allocp[18] = (q)(struct goalrec*)&allocp[3];
  allocp[19] = (q)(&predicate_list_xor__unique_3);
  allocp[20] = x13 = makeref(&allocp[20]);
  allocp[21] = x12;
  allocp[22] = x7;
  allocp[23] = makesym(functor_clause_2);
  allocp[24] = x13;
  allocp[25] = x8;
  x14 = makefunctor(&allocp[23]);
  allocp[26] = (q)(struct goalrec*)&allocp[18];
  allocp[27] = (q)(&predicate_functor__table_xarg_3);
  allocp[28] = a1;
  allocp[29] = x9;
  allocp[30] = x14;
  qp = (struct goalrec*)&allocp[26];
  allocp += 31;
  proceed();
 entry__gd_6_5:
  deref_and_jump(x1,entry__gd_6_4);
  *reasonp++ =  x1;
  goto entry__gd_6_7;
 entry__gd_6_6:
  deref_and_jump(x1,entry__gd_6_3);
  *reasonp++ =  x1;
  goto entry__gd_6_7;
 case VARREF:
  deref_and_jump(x0,entry__gd_6_2);
  *reasonp++ =  x0;
  goto entry__gd_6_7;
  };
  goto entry__gd_6_7;
 case VARREF:
  deref_and_jump(a4,entry__gd_6_1);
  *reasonp++ =  a4;
  goto entry__gd_6_7;
  };
  goto entry__gd_6_7;
 entry__gd_6_7:
  otherwise(entry__gd_6_interrupt);
 entry__gd_6_8:
  switch (ptagof(a4)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a4);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a5, x0);
  allocp[0] = x4 = makeref(&allocp[0]);
  x3 = x4;
  x5 = a2;
  x6 = a3;
  a5 = cdr_of(a4);
  a6 = x1;
  a4 = x6;
  a3 = x5;
  a2 = x3;
  allocp += 1;
  execute(entry__vd_7_0);
  goto entry__vd_7_ext_interrupt;
 case VARREF:
  deref_and_jump(a4,entry__gd_6_8);
  *reasonp++ =  a4;
  goto entry__gd_6_interrupt;
  };
  goto entry__gd_6_interrupt;
 entry__gd_6_ext_interrupt:
  reasonp = 0l;
 entry__gd_6_interrupt:
  toppred = &predicate_vdg_xentry__gd_6;
  goto interrupt_6;
 }

 read__vd_5_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 read__vd_5_clear_reason:
  reasonp = reasons;
 read__vd_5_0:
 read__vd_5_1:
  switch (ptagof(a4)) {
 case CONS:
  x0 = car_of(a4);
 read__vd_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto read__vd_5_7;
  x1 = arg(x0, 0);
 read__vd_5_3:
  if (isref(x1)) goto read__vd_5_6;
 read__vd_5_4:
  if (isref(x1)) goto read__vd_5_5;
  if_not_equal(x1, a0, read__vd_5_7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = a3;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[7] = a2;
  allocp[8] = makeint(1L);
  allocp[9] = x2;
  allocp[10] = makesym(functor_clause_2);
  allocp[11] = x5 = makeref(&allocp[11]);
  allocp[12] = x3;
  x4 = makefunctor(&allocp[10]);
  allocp[13] = (q)(struct goalrec*)&allocp[5];
  allocp[14] = (q)(&predicate_functor__table_xarg_3);
  allocp[15] = a1;
  x6 = arg(x0, 1);
  allocp[16] = x6;
  allocp[17] = x4;
  qp = (struct goalrec*)&allocp[13];
  allocp += 18;
  proceed();
 read__vd_5_5:
  deref_and_jump(x1,read__vd_5_4);
  *reasonp++ =  x1;
  goto read__vd_5_7;
 read__vd_5_6:
  deref_and_jump(x1,read__vd_5_3);
  *reasonp++ =  x1;
  goto read__vd_5_7;
 case VARREF:
  deref_and_jump(x0,read__vd_5_2);
  *reasonp++ =  x0;
  goto read__vd_5_7;
  };
  goto read__vd_5_7;
 case VARREF:
  deref_and_jump(a4,read__vd_5_1);
  *reasonp++ =  a4;
  goto read__vd_5_7;
  };
  goto read__vd_5_7;
 read__vd_5_7:
  otherwise(read__vd_5_interrupt);
 read__vd_5_8:
  switch (ptagof(a4)) {
 case CONS:
  a4 = cdr_of(a4);
  execute(read__vd_5_0);
  goto read__vd_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a4,read__vd_5_8);
  *reasonp++ =  a4;
  goto read__vd_5_interrupt;
  };
  goto read__vd_5_interrupt;
 read__vd_5_ext_interrupt:
  reasonp = 0l;
 read__vd_5_interrupt:
  toppred = &predicate_vdg_xread__vd_5;
  goto interrupt_5;
 }

 read__gd_4_top: {
  q x0, x1, x2, x3, x4;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 read__gd_4_clear_reason:
  reasonp = reasons;
 read__gd_4_0:
 read__gd_4_1:
  switch (ptagof(a3)) {
 case CONS:
  x0 = car_of(a3);
 read__gd_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto read__gd_4_7;
  x1 = arg(x0, 0);
 read__gd_4_3:
  if (isref(x1)) goto read__gd_4_6;
 read__gd_4_4:
  if (isref(x1)) goto read__gd_4_5;
  if_not_equal(x1, a0, read__gd_4_7);
  allocp[0] = makesym(functor_clause_2);
  allocp[1] = a2;
  allocp[2] = x3 = makeref(&allocp[2]);
  x2 = makefunctor(&allocp[0]);
  allocp[3] = (q)qp;
  allocp[4] = (q)(&predicate_functor__table_xarg_3);
  allocp[5] = a1;
  x4 = arg(x0, 1);
  allocp[6] = x4;
  allocp[7] = x2;
  qp = (struct goalrec*)&allocp[3];
  allocp += 8;
  proceed();
 read__gd_4_5:
  deref_and_jump(x1,read__gd_4_4);
  *reasonp++ =  x1;
  goto read__gd_4_7;
 read__gd_4_6:
  deref_and_jump(x1,read__gd_4_3);
  *reasonp++ =  x1;
  goto read__gd_4_7;
 case VARREF:
  deref_and_jump(x0,read__gd_4_2);
  *reasonp++ =  x0;
  goto read__gd_4_7;
  };
  goto read__gd_4_7;
 case VARREF:
  deref_and_jump(a3,read__gd_4_1);
  *reasonp++ =  a3;
  goto read__gd_4_7;
  };
  goto read__gd_4_7;
 read__gd_4_7:
  otherwise(read__gd_4_interrupt);
 read__gd_4_8:
  switch (ptagof(a3)) {
 case CONS:
  a3 = cdr_of(a3);
  execute(read__gd_4_0);
  goto read__gd_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a3,read__gd_4_8);
  *reasonp++ =  a3;
  goto read__gd_4_interrupt;
  };
  goto read__gd_4_interrupt;
 read__gd_4_ext_interrupt:
  reasonp = 0l;
 read__gd_4_interrupt:
  toppred = &predicate_vdg_xread__gd_4;
  goto interrupt_4;
 }

 check__and__entry__vp_7_top: {
  q x0;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 check__and__entry__vp_7_clear_reason:
  reasonp = reasons;
 check__and__entry__vp_7_0:
 check__and__entry__vp_7_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != NILATOM) goto check__and__entry__vp_7_2;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vdg_xcheck__and__entry__vp1_7);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_list_xcheck__include_3);
  allocp[11] = a1;
  allocp[12] = a3;
  allocp[13] = x0;
  qp = (struct goalrec*)&allocp[9];
  allocp += 14;
  proceed();
 case VARREF:
  deref_and_jump(a0,check__and__entry__vp_7_1);
  *reasonp++ =  a0;
  goto check__and__entry__vp_7_2;
  };
  goto check__and__entry__vp_7_2;
 check__and__entry__vp_7_2:
  otherwise(check__and__entry__vp_7_interrupt);
  unify2(a6, a5, a4, a3);
  proceed();
 check__and__entry__vp_7_ext_interrupt:
  reasonp = 0l;
 check__and__entry__vp_7_interrupt:
  goto interrupt_7;
 }

 check__and__entry__vp1_7_top: {
  q x0;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 check__and__entry__vp1_7_clear_reason:
  reasonp = reasons;
 check__and__entry__vp1_7_0:
 check__and__entry__vp1_7_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto check__and__entry__vp1_7_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  unify2(a6, a5, a4, a3);
  proceed();
 case symval(makesym(atom_no)):
  allocp[0] = a3;
  allocp[1] = a1;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a4, x0);
  a0 = a1;
  a1 = a2;
  a2 = a5;
  a3 = a6;
  execute(entry__vp_4_0);
  goto entry__vp_4_ext_interrupt;
  };
  goto check__and__entry__vp1_7_interrupt;
 case VARREF:
  deref_and_jump(a0,check__and__entry__vp1_7_1);
  *reasonp++ =  a0;
  goto check__and__entry__vp1_7_interrupt;
  };
  goto check__and__entry__vp1_7_interrupt;
 check__and__entry__vp1_7_ext_interrupt:
  reasonp = 0l;
 check__and__entry__vp1_7_interrupt:
  goto interrupt_7;
 }

 delete__searching__var_3_top: {
  q x0, x1, x2;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 delete__searching__var_3_clear_reason:
  reasonp = reasons;
 delete__searching__var_3_0:
 delete__searching__var_3_1:
  switch (ptagof(a1)) {
 case CONS:
 delete__searching__var_3_2:
  if (isref(a0)) goto delete__searching__var_3_5;
 delete__searching__var_3_3:
  if (isref(a0)) goto delete__searching__var_3_4;
  x0 = car_of(a1);
  if_not_equal(a0, x0, delete__searching__var_3_6);
  x1 = cdr_of(a1);
  unify(a2, x1);
  proceed();
 delete__searching__var_3_4:
  deref_and_jump(a0,delete__searching__var_3_3);
  *reasonp++ =  a0;
  goto delete__searching__var_3_6;
 delete__searching__var_3_5:
  deref_and_jump(a0,delete__searching__var_3_2);
  *reasonp++ =  a0;
  goto delete__searching__var_3_6;
 case VARREF:
  deref_and_jump(a1,delete__searching__var_3_1);
  *reasonp++ =  a1;
  goto delete__searching__var_3_6;
  };
  goto delete__searching__var_3_6;
 delete__searching__var_3_6:
  otherwise(delete__searching__var_3_interrupt);
 delete__searching__var_3_7:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a1);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  a1 = cdr_of(a1);
  a2 = x1;
  execute(delete__searching__var_3_0);
  goto delete__searching__var_3_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto delete__searching__var_3_interrupt;
  x0 = NILATOM;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,delete__searching__var_3_7);
  *reasonp++ =  a1;
  goto delete__searching__var_3_interrupt;
  };
  goto delete__searching__var_3_interrupt;
 delete__searching__var_3_ext_interrupt:
  reasonp = 0l;
 delete__searching__var_3_interrupt:
  toppred = &predicate_vdg_xdelete__searching__var_3;
  goto interrupt_3;
 }

 expand__u_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 expand__u_8_clear_reason:
  reasonp = reasons;
 expand__u_8_0:
 expand__u_8_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 expand__u_8_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_entry_4)) goto expand__u_8_interrupt;
  x1 = arg(x0, 1);
 expand__u_8_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_goal_4)) goto expand__u_8_interrupt;
  x2 = arg(x1, 2);
 expand__u_8_4:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (isint(x2)) goto expand__u_8_interrupt;
  switch (symval(x2)) {
 case symval(makesym(atom_head)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vdg_xexpand__u_8);
  x3 = cdr_of(a0);
  allocp[2] = x3;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x4 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x5 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_vdg_xexpand__hb_11);
  allocp[12] = a2;
  x6 = arg(x1, 0);
  allocp[13] = x6;
  allocp[14] = x7 = makeref(&allocp[14]);
  allocp[15] = x8 = makeref(&allocp[15]);
  allocp[16] = makesym(atom_head);
  x9 = arg(x0, 3);
  allocp[17] = x9;
  x10 = arg(x0, 2);
  allocp[18] = x10;
  allocp[19] = a4;
  allocp[20] = x4;
  allocp[21] = a6;
  allocp[22] = x5;
  allocp[23] = (q)(struct goalrec*)&allocp[10];
  allocp[24] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[25] = x11 = makeref(&allocp[25]);
  allocp[26] = x7;
  allocp[27] = x8;
  allocp[28] = makesym(functor_functor_2);
  allocp[29] = x11;
  allocp[30] = x13 = makeref(&allocp[30]);
  x12 = makefunctor(&allocp[28]);
  allocp[31] = makesym(functor_clause_4);
  allocp[32] = x12;
  allocp[33] = x15 = makeref(&allocp[33]);
  allocp[34] = x16 = makeref(&allocp[34]);
  allocp[35] = x17 = makeref(&allocp[35]);
  x14 = makefunctor(&allocp[31]);
  allocp[36] = (q)(struct goalrec*)&allocp[23];
  allocp[37] = (q)(&predicate_parse__uty_xget__clause_4);
  allocp[38] = x6;
  x18 = arg(x1, 1);
  allocp[39] = x18;
  allocp[40] = x14;
  allocp[41] = a3;
  qp = (struct goalrec*)&allocp[36];
  allocp += 42;
  proceed();
 case symval(makesym(atom_body)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vdg_xexpand__u_8);
  x3 = cdr_of(a0);
  allocp[2] = x3;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x4 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x5 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_vdg_xexpand__hb_11);
  allocp[12] = a2;
  allocp[13] = x6 = makeref(&allocp[13]);
  allocp[14] = x7 = makeref(&allocp[14]);
  allocp[15] = x8 = makeref(&allocp[15]);
  allocp[16] = makesym(atom_body);
  x9 = arg(x0, 3);
  allocp[17] = x9;
  x10 = arg(x0, 2);
  allocp[18] = x10;
  allocp[19] = a4;
  allocp[20] = x4;
  allocp[21] = a6;
  allocp[22] = x5;
  allocp[23] = (q)(struct goalrec*)&allocp[10];
  allocp[24] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[25] = x11 = makeref(&allocp[25]);
  allocp[26] = x7;
  allocp[27] = x8;
  allocp[28] = (q)(struct goalrec*)&allocp[23];
  allocp[29] = (q)(&predicate_parse__uty_xdecode__goalcall_6);
  x12 = arg(x1, 0);
  allocp[30] = x12;
  allocp[31] = x6;
  allocp[32] = x13 = makeref(&allocp[32]);
  allocp[33] = x11;
  allocp[34] = x14 = makeref(&allocp[34]);
  allocp[35] = x15 = makeref(&allocp[35]);
  allocp[36] = (q)(struct goalrec*)&allocp[28];
  allocp[37] = (q)(&predicate_parse__uty_xget__goal_6);
  allocp[38] = x12;
  x16 = arg(x1, 1);
  allocp[39] = x16;
  x17 = arg(x1, 3);
  allocp[40] = x17;
  allocp[41] = makesym(atom_body);
  allocp[42] = x13;
  allocp[43] = a3;
  qp = (struct goalrec*)&allocp[36];
  allocp += 44;
  proceed();
  };
  goto expand__u_8_interrupt;
 case VARREF:
  deref_and_jump(x2,expand__u_8_4);
  *reasonp++ =  x2;
  goto expand__u_8_interrupt;
  };
  goto expand__u_8_interrupt;
 case VARREF:
  deref_and_jump(x1,expand__u_8_3);
  *reasonp++ =  x1;
  goto expand__u_8_interrupt;
  };
  goto expand__u_8_interrupt;
 case VARREF:
  deref_and_jump(x0,expand__u_8_2);
  *reasonp++ =  x0;
  goto expand__u_8_interrupt;
  };
  goto expand__u_8_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto expand__u_8_interrupt;
  unify2(a7, a6, a5, a4);
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,expand__u_8_1);
  *reasonp++ =  a0;
  goto expand__u_8_interrupt;
  };
  goto expand__u_8_interrupt;
 expand__u_8_ext_interrupt:
  reasonp = 0l;
 expand__u_8_interrupt:
  goto interrupt_8;
 }

 expand__hb_11_top: {
  q x0, x1;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 expand__hb_11_clear_reason:
  reasonp = reasons;
 expand__hb_11_0:
 expand__hb_11_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 expand__hb_11_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto expand__hb_11_7;
  x1 = arg(x0, 0);
 expand__hb_11_3:
  if (isref(x1)) goto expand__hb_11_6;
 expand__hb_11_4:
  if (isref(x1)) goto expand__hb_11_5;
  if_not_equal(x1, a1, expand__hb_11_7);
  a0 = arg(x0, 1);
  a1 = a2;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  a5 = a6;
  a6 = a7;
  a7 = a8;
  a8 = a9;
  a9 = a10;
  execute(expand__hb__pred_10_clear_reason);
  goto expand__hb__pred_10_ext_interrupt;
 expand__hb_11_5:
  deref_and_jump(x1,expand__hb_11_4);
  *reasonp++ =  x1;
  goto expand__hb_11_7;
 expand__hb_11_6:
  deref_and_jump(x1,expand__hb_11_3);
  *reasonp++ =  x1;
  goto expand__hb_11_7;
 case VARREF:
  deref_and_jump(x0,expand__hb_11_2);
  *reasonp++ =  x0;
  goto expand__hb_11_7;
  };
  goto expand__hb_11_7;
 case VARREF:
  deref_and_jump(a0,expand__hb_11_1);
  *reasonp++ =  a0;
  goto expand__hb_11_7;
  };
  goto expand__hb_11_7;
 expand__hb_11_7:
  otherwise(expand__hb_11_interrupt);
 expand__hb_11_8:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(expand__hb_11_0);
  goto expand__hb_11_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,expand__hb_11_8);
  *reasonp++ =  a0;
  goto expand__hb_11_interrupt;
  };
  goto expand__hb_11_interrupt;
 expand__hb_11_ext_interrupt:
  reasonp = 0l;
 expand__hb_11_interrupt:
  goto interrupt_11;
 }

 expand__hb__pred_10_top: {
  q x0, x1, x2, x3, x4;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 expand__hb__pred_10_clear_reason:
  reasonp = reasons;
 expand__hb__pred_10_0:
 expand__hb__pred_10_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 expand__hb__pred_10_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_7)) goto expand__hb__pred_10_20;
  x1 = arg(x0, 0);
 expand__hb__pred_10_3:
  if (isref(x1)) goto expand__hb__pred_10_19;
 expand__hb__pred_10_4:
  if (isref(x1)) goto expand__hb__pred_10_18;
  if_not_equal(x1, a1, expand__hb__pred_10_10);
  x2 = arg(x0, 1);
 expand__hb__pred_10_5:
  if (isref(x2)) goto expand__hb__pred_10_9;
 expand__hb__pred_10_6:
  if (isref(x2)) goto expand__hb__pred_10_8;
  if_not_equal(x2, a2, expand__hb__pred_10_10);
 expand__hb__pred_10_7:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_head)) goto expand__hb__pred_10_10;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vdg_xexpand__hb__entry__args_6);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = a5;
  allocp[4] = a6;
  allocp[5] = a7;
  allocp[6] = a8;
  allocp[7] = a9;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_functor__table_xarg_3);
  allocp[10] = a4;
  x4 = arg(x0, 4);
  allocp[11] = x4;
  allocp[12] = x3;
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  proceed();
 case VARREF:
  deref_and_jump(a3,expand__hb__pred_10_7);
  *reasonp++ =  a3;
  goto expand__hb__pred_10_10;
  };
  goto expand__hb__pred_10_10;
 expand__hb__pred_10_8:
  deref_and_jump(x2,expand__hb__pred_10_6);
  *reasonp++ =  x2;
  goto expand__hb__pred_10_10;
 expand__hb__pred_10_9:
  deref_and_jump(x2,expand__hb__pred_10_5);
  *reasonp++ =  x2;
  goto expand__hb__pred_10_10;
 expand__hb__pred_10_10:
 expand__hb__pred_10_11:
  if (isref(x1)) goto expand__hb__pred_10_17;
  if_not_equal(x1, a1, expand__hb__pred_10_20);
  x2 = arg(x0, 1);
 expand__hb__pred_10_12:
  if (isref(x2)) goto expand__hb__pred_10_16;
 expand__hb__pred_10_13:
  if (isref(x2)) goto expand__hb__pred_10_15;
  if_not_equal(x2, a2, expand__hb__pred_10_20);
 expand__hb__pred_10_14:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_body)) goto expand__hb__pred_10_20;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vdg_xexpand__hb__entry__args_6);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = a5;
  allocp[4] = a6;
  allocp[5] = a7;
  allocp[6] = a8;
  allocp[7] = a9;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_functor__table_xarg_3);
  allocp[10] = a4;
  x4 = arg(x0, 3);
  allocp[11] = x4;
  allocp[12] = x3;
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  proceed();
 case VARREF:
  deref_and_jump(a3,expand__hb__pred_10_14);
  *reasonp++ =  a3;
  goto expand__hb__pred_10_20;
  };
  goto expand__hb__pred_10_20;
 expand__hb__pred_10_15:
  deref_and_jump(x2,expand__hb__pred_10_13);
  *reasonp++ =  x2;
  goto expand__hb__pred_10_20;
 expand__hb__pred_10_16:
  deref_and_jump(x2,expand__hb__pred_10_12);
  *reasonp++ =  x2;
  goto expand__hb__pred_10_20;
 expand__hb__pred_10_17:
  deref_and_jump(x1,expand__hb__pred_10_11);
  *reasonp++ =  x1;
  goto expand__hb__pred_10_20;
 expand__hb__pred_10_18:
  deref_and_jump(x1,expand__hb__pred_10_4);
  *reasonp++ =  x1;
  goto expand__hb__pred_10_20;
 expand__hb__pred_10_19:
  deref_and_jump(x1,expand__hb__pred_10_3);
  *reasonp++ =  x1;
  goto expand__hb__pred_10_20;
 case VARREF:
  deref_and_jump(x0,expand__hb__pred_10_2);
  *reasonp++ =  x0;
  goto expand__hb__pred_10_20;
  };
  goto expand__hb__pred_10_20;
 case VARREF:
  deref_and_jump(a0,expand__hb__pred_10_1);
  *reasonp++ =  a0;
  goto expand__hb__pred_10_20;
  };
  goto expand__hb__pred_10_20;
 expand__hb__pred_10_20:
  otherwise(expand__hb__pred_10_interrupt);
 expand__hb__pred_10_21:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(expand__hb__pred_10_0);
  goto expand__hb__pred_10_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,expand__hb__pred_10_21);
  *reasonp++ =  a0;
  goto expand__hb__pred_10_interrupt;
  };
  goto expand__hb__pred_10_interrupt;
 expand__hb__pred_10_ext_interrupt:
  reasonp = 0l;
 expand__hb__pred_10_interrupt:
  toppred = &predicate_vdg_xexpand__hb__pred_10;
  goto interrupt_10;
 }

 expand__hb__entry__args_6_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 expand__hb__entry__args_6_clear_reason:
  reasonp = reasons;
 expand__hb__entry__args_6_0:
 expand__hb__entry__args_6_1:
  if (isref(a0)) goto expand__hb__entry__args_6_2;
  gblt_pfunctor(a0,x0,expand__hb__entry__args_6_interrupt);
  gblt_arity(a0,x1,expand__hb__entry__args_6_interrupt);
  x2 = a0;
  x3 = a1;
  x4 = a2;
  x5 = a3;
  x6 = a4;
  a6 = a5;
  a5 = x6;
  a4 = x5;
  a3 = x4;
  a2 = x3;
  a1 = x2;
  a0 = x1;
  execute(expand__hb__entry__args1_7_0);
  goto expand__hb__entry__args1_7_ext_interrupt;
 expand__hb__entry__args_6_2:
  deref_and_jump(a0,expand__hb__entry__args_6_1);
  *reasonp++ =  a0;
  goto expand__hb__entry__args_6_interrupt;
 expand__hb__entry__args_6_ext_interrupt:
  reasonp = 0l;
 expand__hb__entry__args_6_interrupt:
  goto interrupt_6;
 }

 expand__hb__entry__args1_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 expand__hb__entry__args1_7_clear_reason:
  reasonp = reasons;
 expand__hb__entry__args1_7_0:
 expand__hb__entry__args1_7_1:
  if (!isint(a0)) goto expand__hb__entry__args1_7_15;
  x0 = makeint(0L);
  gblt_greater(a0,x0,expand__hb__entry__args1_7_16);
 expand__hb__entry__args1_7_2:
  if (isref(a1)) goto expand__hb__entry__args1_7_14;
  gblt_arg(a0,a1,x1,expand__hb__entry__args1_7_16);
 expand__hb__entry__args1_7_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  switch (symval(functor_of(x1))) {
 case functor_arg_2:
  x2 = arg(x1, 0);
 expand__hb__entry__args1_7_4:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_goal_4)) goto expand__hb__entry__args1_7_16;
  x3 = arg(x1, 1);
 expand__hb__entry__args1_7_5:
  switch (ptagof(x3)) {
 case FUNCTOR:
  if (functor_of(x3) != makesym(functor_variable_3)) goto expand__hb__entry__args1_7_16;
  allocp[0] = makesym(functor_v_4);
  x5 = arg(x2, 0);
  allocp[1] = x5;
  x6 = arg(x2, 1);
  allocp[2] = x6;
  x7 = arg(x3, 0);
  allocp[3] = x7;
  x8 = arg(x3, 1);
  allocp[4] = x8;
  x4 = makefunctor(&allocp[0]);
  allocp[5] = a5;
  allocp[6] = x4;
  x9 = makecons(&allocp[5]);
  allocp[7] = (q)qp;
  allocp[8] = (q)(&predicate_vdg_xexpand__hb__entry__args1_7);
  allocp[9] = x10 = makeref(&allocp[9]);
  allocp[10] = a1;
  allocp[11] = a2;
  allocp[12] = x11 = makeref(&allocp[12]);
  allocp[13] = a4;
  allocp[14] = x9;
  allocp[15] = a6;
  allocp[16] = (q)(struct goalrec*)&allocp[7];
  allocp[17] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[18] = a0;
  allocp[19] = makeint(1L);
  allocp[20] = x10;
  a0 = x4;
  a1 = a2;
  a2 = a3;
  a3 = x11;
  qp = (struct goalrec*)&allocp[16];
  allocp += 21;
  execute(entry__vp_4_0);
  goto entry__vp_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x3,expand__hb__entry__args1_7_5);
  *reasonp++ =  x3;
  goto expand__hb__entry__args1_7_16;
  };
  goto expand__hb__entry__args1_7_16;
 case VARREF:
  deref_and_jump(x2,expand__hb__entry__args1_7_4);
  *reasonp++ =  x2;
  goto expand__hb__entry__args1_7_16;
  };
  goto expand__hb__entry__args1_7_16;
 case functor_sharedarg_2:
  x2 = arg(x1, 0);
 expand__hb__entry__args1_7_6:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_goal_4)) goto expand__hb__entry__args1_7_16;
  x3 = arg(x1, 1);
 expand__hb__entry__args1_7_7:
  switch (ptagof(x3)) {
 case FUNCTOR:
  if (functor_of(x3) != makesym(functor_variable_3)) goto expand__hb__entry__args1_7_16;
  allocp[0] = makesym(functor_v_4);
  x5 = arg(x2, 0);
  allocp[1] = x5;
  x6 = arg(x2, 1);
  allocp[2] = x6;
  x7 = arg(x3, 0);
  allocp[3] = x7;
  x8 = arg(x3, 1);
  allocp[4] = x8;
  x4 = makefunctor(&allocp[0]);
  allocp[5] = a5;
  allocp[6] = x4;
  x9 = makecons(&allocp[5]);
  allocp[7] = (q)qp;
  allocp[8] = (q)(&predicate_vdg_xexpand__hb__entry__args1_7);
  allocp[9] = x10 = makeref(&allocp[9]);
  allocp[10] = a1;
  allocp[11] = a2;
  allocp[12] = x11 = makeref(&allocp[12]);
  allocp[13] = a4;
  allocp[14] = x9;
  allocp[15] = a6;
  allocp[16] = (q)(struct goalrec*)&allocp[7];
  allocp[17] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[18] = a0;
  allocp[19] = makeint(1L);
  allocp[20] = x10;
  a0 = x4;
  a1 = a2;
  a2 = a3;
  a3 = x11;
  qp = (struct goalrec*)&allocp[16];
  allocp += 21;
  execute(entry__vp_4_0);
  goto entry__vp_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x3,expand__hb__entry__args1_7_7);
  *reasonp++ =  x3;
  goto expand__hb__entry__args1_7_16;
  };
  goto expand__hb__entry__args1_7_16;
 case VARREF:
  deref_and_jump(x2,expand__hb__entry__args1_7_6);
  *reasonp++ =  x2;
  goto expand__hb__entry__args1_7_16;
  };
  goto expand__hb__entry__args1_7_16;
 case functor_looparg_2:
  x2 = arg(x1, 0);
 expand__hb__entry__args1_7_8:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_goal_4)) goto expand__hb__entry__args1_7_16;
  x3 = arg(x1, 1);
 expand__hb__entry__args1_7_9:
  switch (ptagof(x3)) {
 case FUNCTOR:
  if (functor_of(x3) != makesym(functor_variable_3)) goto expand__hb__entry__args1_7_16;
  allocp[0] = makesym(functor_v_4);
  x5 = arg(x2, 0);
  allocp[1] = x5;
  x6 = arg(x2, 1);
  allocp[2] = x6;
  x7 = arg(x3, 0);
  allocp[3] = x7;
  x8 = arg(x3, 1);
  allocp[4] = x8;
  x4 = makefunctor(&allocp[0]);
  allocp[5] = a5;
  allocp[6] = x4;
  x9 = makecons(&allocp[5]);
  allocp[7] = (q)qp;
  allocp[8] = (q)(&predicate_vdg_xexpand__hb__entry__args1_7);
  allocp[9] = x10 = makeref(&allocp[9]);
  allocp[10] = a1;
  allocp[11] = a2;
  allocp[12] = x11 = makeref(&allocp[12]);
  allocp[13] = a4;
  allocp[14] = x9;
  allocp[15] = a6;
  allocp[16] = (q)(struct goalrec*)&allocp[7];
  allocp[17] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[18] = a0;
  allocp[19] = makeint(1L);
  allocp[20] = x10;
  a0 = x4;
  a1 = a2;
  a2 = a3;
  a3 = x11;
  qp = (struct goalrec*)&allocp[16];
  allocp += 21;
  execute(entry__vp_4_0);
  goto entry__vp_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x3,expand__hb__entry__args1_7_9);
  *reasonp++ =  x3;
  goto expand__hb__entry__args1_7_16;
  };
  goto expand__hb__entry__args1_7_16;
 case VARREF:
  deref_and_jump(x2,expand__hb__entry__args1_7_8);
  *reasonp++ =  x2;
  goto expand__hb__entry__args1_7_16;
  };
  goto expand__hb__entry__args1_7_16;
 case functor_entryarg_2:
  x2 = arg(x1, 0);
 expand__hb__entry__args1_7_10:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_goal_4)) goto expand__hb__entry__args1_7_16;
  x3 = arg(x1, 1);
 expand__hb__entry__args1_7_11:
  switch (ptagof(x3)) {
 case FUNCTOR:
  if (functor_of(x3) != makesym(functor_variable_3)) goto expand__hb__entry__args1_7_16;
  allocp[0] = makesym(functor_v_4);
  x5 = arg(x2, 0);
  allocp[1] = x5;
  x6 = arg(x2, 1);
  allocp[2] = x6;
  x7 = arg(x3, 0);
  allocp[3] = x7;
  x8 = arg(x3, 1);
  allocp[4] = x8;
  x4 = makefunctor(&allocp[0]);
  allocp[5] = a5;
  allocp[6] = x4;
  x9 = makecons(&allocp[5]);
  allocp[7] = (q)qp;
  allocp[8] = (q)(&predicate_vdg_xexpand__hb__entry__args1_7);
  allocp[9] = x10 = makeref(&allocp[9]);
  allocp[10] = a1;
  allocp[11] = a2;
  allocp[12] = x11 = makeref(&allocp[12]);
  allocp[13] = a4;
  allocp[14] = x9;
  allocp[15] = a6;
  allocp[16] = (q)(struct goalrec*)&allocp[7];
  allocp[17] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[18] = a0;
  allocp[19] = makeint(1L);
  allocp[20] = x10;
  a0 = x4;
  a1 = a2;
  a2 = a3;
  a3 = x11;
  qp = (struct goalrec*)&allocp[16];
  allocp += 21;
  execute(entry__vp_4_0);
  goto entry__vp_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x3,expand__hb__entry__args1_7_11);
  *reasonp++ =  x3;
  goto expand__hb__entry__args1_7_16;
  };
  goto expand__hb__entry__args1_7_16;
 case VARREF:
  deref_and_jump(x2,expand__hb__entry__args1_7_10);
  *reasonp++ =  x2;
  goto expand__hb__entry__args1_7_16;
  };
  goto expand__hb__entry__args1_7_16;
 case functor_recursivearg_2:
  x2 = arg(x1, 0);
 expand__hb__entry__args1_7_12:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_goal_4)) goto expand__hb__entry__args1_7_16;
  x3 = arg(x1, 1);
 expand__hb__entry__args1_7_13:
  switch (ptagof(x3)) {
 case FUNCTOR:
  if (functor_of(x3) != makesym(functor_variable_3)) goto expand__hb__entry__args1_7_16;
  allocp[0] = makesym(functor_v_4);
  x5 = arg(x2, 0);
  allocp[1] = x5;
  x6 = arg(x2, 1);
  allocp[2] = x6;
  x7 = arg(x3, 0);
  allocp[3] = x7;
  x8 = arg(x3, 1);
  allocp[4] = x8;
  x4 = makefunctor(&allocp[0]);
  allocp[5] = a5;
  allocp[6] = x4;
  x9 = makecons(&allocp[5]);
  allocp[7] = (q)qp;
  allocp[8] = (q)(&predicate_vdg_xexpand__hb__entry__args1_7);
  allocp[9] = x10 = makeref(&allocp[9]);
  allocp[10] = a1;
  allocp[11] = a2;
  allocp[12] = x11 = makeref(&allocp[12]);
  allocp[13] = a4;
  allocp[14] = x9;
  allocp[15] = a6;
  allocp[16] = (q)(struct goalrec*)&allocp[7];
  allocp[17] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[18] = a0;
  allocp[19] = makeint(1L);
  allocp[20] = x10;
  a0 = x4;
  a1 = a2;
  a2 = a3;
  a3 = x11;
  qp = (struct goalrec*)&allocp[16];
  allocp += 21;
  execute(entry__vp_4_0);
  goto entry__vp_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x3,expand__hb__entry__args1_7_13);
  *reasonp++ =  x3;
  goto expand__hb__entry__args1_7_16;
  };
  goto expand__hb__entry__args1_7_16;
 case VARREF:
  deref_and_jump(x2,expand__hb__entry__args1_7_12);
  *reasonp++ =  x2;
  goto expand__hb__entry__args1_7_16;
  };
  goto expand__hb__entry__args1_7_16;
  };
  goto expand__hb__entry__args1_7_16;
 case VARREF:
  deref_and_jump(x1,expand__hb__entry__args1_7_3);
  *reasonp++ =  x1;
  goto expand__hb__entry__args1_7_16;
  };
  goto expand__hb__entry__args1_7_16;
 expand__hb__entry__args1_7_14:
  deref_and_jump(a1,expand__hb__entry__args1_7_2);
  *reasonp++ =  a1;
  goto expand__hb__entry__args1_7_16;
 expand__hb__entry__args1_7_15:
  if (!isref(a0)) goto expand__hb__entry__args1_7_16;
  deref_and_jump(a0,expand__hb__entry__args1_7_1);
  *reasonp++ =  a0;
  goto expand__hb__entry__args1_7_16;
 expand__hb__entry__args1_7_16:
  otherwise(expand__hb__entry__args1_7_interrupt);
 expand__hb__entry__args1_7_17:
  if (!isint(a0)) goto expand__hb__entry__args1_7_19;
  x0 = makeint(0L);
  gblt_greater(a0,x0,expand__hb__entry__args1_7_18);
  x1 = makeint(1L);
  bblt_sub_no_check(a0,x1,x2);
  a0 = x2;
  execute(expand__hb__entry__args1_7_0);
  goto expand__hb__entry__args1_7_ext_interrupt;
 expand__hb__entry__args1_7_18:
  if (a0 != makeint(0L)) goto expand__hb__entry__args1_7_interrupt;
  unify2(a6, a5, a4, a3);
  proceed();
 expand__hb__entry__args1_7_19:
  if (!isref(a0)) goto expand__hb__entry__args1_7_interrupt;
  deref_and_jump(a0,expand__hb__entry__args1_7_17);
  *reasonp++ =  a0;
  goto expand__hb__entry__args1_7_interrupt;
 expand__hb__entry__args1_7_ext_interrupt:
  reasonp = 0l;
 expand__hb__entry__args1_7_interrupt:
  toppred = &predicate_vdg_xexpand__hb__entry__args1_7;
  goto interrupt_7;
 }

 merge__vd_3_top: {
  q x0, x1, x2, x3;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 merge__vd_3_clear_reason:
  reasonp = reasons;
 merge__vd_3_0:
 merge__vd_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 merge__vd_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_to_2)) goto merge__vd_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vdg_xmerge__vd_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  a0 = arg(x0, 0);
  x3 = arg(x0, 1);
  a2 = a1;
  a3 = x2;
  a1 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(merge__vd1_4_0);
  goto merge__vd1_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,merge__vd_3_2);
  *reasonp++ =  x0;
  goto merge__vd_3_interrupt;
  };
  goto merge__vd_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto merge__vd_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,merge__vd_3_1);
  *reasonp++ =  a0;
  goto merge__vd_3_interrupt;
  };
  goto merge__vd_3_interrupt;
 merge__vd_3_ext_interrupt:
  reasonp = 0l;
 merge__vd_3_interrupt:
  goto interrupt_3;
 }

 merge__vd1_4_top: {
  q x0, x1, x2, x3, x4, x5;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 merge__vd1_4_clear_reason:
  reasonp = reasons;
 merge__vd1_4_0:
 merge__vd1_4_1:
  switch (ptagof(a2)) {
 case CONS:
  x0 = car_of(a2);
 merge__vd1_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_to_2)) goto merge__vd1_4_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vdg_xmerge__vd2_8);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a0;
  x2 = arg(x0, 0);
  allocp[4] = x2;
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = a1;
  x4 = arg(x0, 1);
  allocp[7] = x4;
  x5 = cdr_of(a2);
  allocp[8] = x5;
  allocp[9] = a3;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_typeset_xcheck__same__type_4);
  allocp[12] = a0;
  allocp[13] = x2;
  allocp[14] = x3;
  allocp[15] = x1;
  qp = (struct goalrec*)&allocp[10];
  allocp += 16;
  proceed();
 case VARREF:
  deref_and_jump(x0,merge__vd1_4_2);
  *reasonp++ =  x0;
  goto merge__vd1_4_interrupt;
  };
  goto merge__vd1_4_interrupt;
 case ATOMIC:
  if (a2 != NILATOM) goto merge__vd1_4_interrupt;
  allocp[0] = makesym(functor_to_2);
  allocp[1] = a0;
  allocp[2] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = NILATOM;
  allocp[4] = x0;
  x1 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a3, x1);
  proceed();
 case VARREF:
  deref_and_jump(a2,merge__vd1_4_1);
  *reasonp++ =  a2;
  goto merge__vd1_4_interrupt;
  };
  goto merge__vd1_4_interrupt;
 merge__vd1_4_ext_interrupt:
  reasonp = 0l;
 merge__vd1_4_interrupt:
  toppred = &predicate_vdg_xmerge__vd1_4;
  goto interrupt_4;
 }

 merge__vd2_8_top: {
  q x0, x1, x2;
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 merge__vd2_8_clear_reason:
  reasonp = reasons;
 merge__vd2_8_0:
 merge__vd2_8_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto merge__vd2_8_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  allocp[0] = makesym(functor_to_2);
  allocp[1] = a1;
  allocp[2] = x1 = makeref(&allocp[2]);
  x0 = makefunctor(&allocp[0]);
  allocp[3] = a6;
  allocp[4] = x0;
  x2 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a7, x2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_list_xor__unique_3);
  allocp[2] = a4;
  allocp[3] = a5;
  allocp[4] = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case symval(makesym(atom_no)):
  allocp[0] = makesym(functor_to_2);
  allocp[1] = a2;
  allocp[2] = a5;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = x0;
  x1 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a7, x1);
  a0 = a1;
  a1 = a4;
  a2 = a6;
  a3 = x2;
  execute(merge__vd1_4_0);
  goto merge__vd1_4_ext_interrupt;
  };
  goto merge__vd2_8_interrupt;
 case VARREF:
  deref_and_jump(a0,merge__vd2_8_1);
  *reasonp++ =  a0;
  goto merge__vd2_8_interrupt;
  };
  goto merge__vd2_8_interrupt;
 merge__vd2_8_ext_interrupt:
  reasonp = 0l;
 merge__vd2_8_interrupt:
  goto interrupt_8;
 }
 interrupt_21:
  allocp[22] = a20;
 interrupt_20:
  allocp[21] = a19;
 interrupt_19:
  allocp[20] = a18;
 interrupt_18:
  allocp[19] = a17;
 interrupt_17:
  allocp[18] = a16;
 interrupt_16:
  allocp[17] = a15;
 interrupt_15:
  allocp[16] = a14;
 interrupt_14:
  allocp[15] = a13;
 interrupt_13:
  allocp[14] = a12;
 interrupt_12:
  allocp[13] = a11;
 interrupt_11:
  allocp[12] = a10;
 interrupt_10:
  allocp[11] = a9;
 interrupt_9:
  allocp[10] = a8;
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_vdg);
}
