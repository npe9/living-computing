/* Compiled by KLIC compiler version 3.002 (Wed Sep 17 15:37:13 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_file__op();
Const struct predicate predicate_file__op_xmake__ai0_5 =
   { module_file__op, 0, 5 };
Const struct predicate predicate_file__op_xread__ai_6 =
   { module_file__op, 1, 6 };
Const struct predicate predicate_file__op_xmake__ai1_5 =
   { module_file__op, 2, 5 };
Const struct predicate predicate_file__op_xread__ai1_5 =
   { module_file__op, 3, 5 };
Const struct predicate predicate_file__op_xmake__ai2_4 =
   { module_file__op, 4, 4 };
Const struct predicate predicate_file__op_xread__ai2_4 =
   { module_file__op, 5, 4 };
Const struct predicate predicate_file__op_xmake__mid_2 =
   { module_file__op, 6, 2 };
Const struct predicate predicate_file__op_xread__mid_2 =
   { module_file__op, 7, 2 };
Const struct predicate predicate_file__op_xstart__output_3 =
   { module_file__op, 8, 3 };
Const struct predicate predicate_file__op_xfinish__output_2 =
   { module_file__op, 9, 2 };
Const struct predicate predicate_file__op_xwrite__word_3 =
   { module_file__op, 10, 3 };
Const struct predicate predicate_file__op_xstart__readin_3 =
   { module_file__op, 11, 3 };
Const struct predicate predicate_file__op_xfinish__readin_2 =
   { module_file__op, 12, 2 };
Const struct predicate predicate_file__op_xread__word_3 =
   { module_file__op, 13, 3 };
Const struct predicate predicate_file__op_xwriteout__vt_3 =
   { module_file__op, 14, 3 };
Const struct predicate predicate_file__op_xwriteout__vt__clauses_3 =
   { module_file__op, 15, 3 };
Const struct predicate predicate_file__op_xwriteout__vt__clauses1_5 =
   { module_file__op, 16, 5 };
Const struct predicate predicate_file__op_xwriteout__vt__clause_3 =
   { module_file__op, 17, 3 };
Const struct predicate predicate_file__op_xwriteout__vt__clause1_5 =
   { module_file__op, 18, 5 };
Const struct predicate predicate_file__op_xreadin__vt_3 =
   { module_file__op, 19, 3 };
Const struct predicate predicate_file__op_xreadin__vt_4 =
   { module_file__op, 20, 4 };
Const struct predicate predicate_file__op_xreadin__vt__clauses_6 =
   { module_file__op, 21, 6 };
Const struct predicate predicate_file__op_xreadin__vt__clause_6 =
   { module_file__op, 22, 6 };
Const struct predicate predicate_file__op_xwriteout__hb_3 =
   { module_file__op, 23, 3 };
Const struct predicate predicate_file__op_xwriteout__hb__clauses_3 =
   { module_file__op, 24, 3 };
Const struct predicate predicate_file__op_xreadin__hb_3 =
   { module_file__op, 25, 3 };
Const struct predicate predicate_file__op_xreadin__hb_4 =
   { module_file__op, 26, 4 };
Const struct predicate predicate_file__op_xreadin__preds_4 =
   { module_file__op, 27, 4 };
Const struct predicate predicate_file__op_xwriteout__ea_3 =
   { module_file__op, 28, 3 };
Const struct predicate predicate_file__op_xreadin__ea_3 =
   { module_file__op, 29, 3 };
Const struct predicate predicate_file__op_xreadin__ea_4 =
   { module_file__op, 30, 4 };
Const struct predicate predicate_file__op_xwriteout__lt_3 =
   { module_file__op, 31, 3 };
Const struct predicate predicate_file__op_xreadin__lt_3 =
   { module_file__op, 32, 3 };
Const struct predicate predicate_file__op_xreadin__lt_4 =
   { module_file__op, 33, 4 };
Const struct predicate predicate_file__op_xwriteout__modules_3 =
   { module_file__op, 34, 3 };
Const struct predicate predicate_file__op_xwriteout__modules2_3 =
   { module_file__op, 35, 3 };
Const struct predicate predicate_file__op_xwriteout__clauses_5 =
   { module_file__op, 36, 5 };
Const struct predicate predicate_file__op_xwriteout__clause_3 =
   { module_file__op, 37, 3 };
Const struct predicate predicate_file__op_xwriteout__goals_5 =
   { module_file__op, 38, 5 };
Const struct predicate predicate_file__op_xreadin__modules_3 =
   { module_file__op, 39, 3 };
Const struct predicate predicate_file__op_xreadin__modules_4 =
   { module_file__op, 40, 4 };
Const struct predicate predicate_file__op_xreadin__clauses_6 =
   { module_file__op, 41, 6 };
Const struct predicate predicate_file__op_xreadin__clause_4 =
   { module_file__op, 42, 4 };
Const struct predicate predicate_file__op_xreadin__goals_6 =
   { module_file__op, 43, 6 };
Const struct predicate predicate_file__op_xwriteout__adg_3 =
   { module_file__op, 44, 3 };
Const struct predicate predicate_file__op_xwrite__adg__entry_3 =
   { module_file__op, 45, 3 };
Const struct predicate predicate_file__op_xreadin__adg_3 =
   { module_file__op, 46, 3 };
Const struct predicate predicate_file__op_xreadin__adg_4 =
   { module_file__op, 47, 4 };
Const struct predicate predicate_file__op_xread__adg__entry_4 =
   { module_file__op, 48, 4 };
extern Const struct predicate predicate_variable_xwrap_2;
extern Const struct predicate predicate_variable_xunwrap_2;
extern Const struct predicate predicate_functor_xinsert__arg_4;
extern Const struct predicate predicate_integer__arithmetics_xadd_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_xfunctor_3;
extern Const struct predicate predicate_klicio_xklicio_1;
extern Const struct predicate predicate_klic__comp__message_xsee_2;

module module_file__op(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  static Const unsigned char strconst_body_0[4] =
    {'.','a','i','0',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_0 =
      declare_string_constant_8(strconst_body_0,4);
  static Const unsigned char strconst_body_1[4] =
    {'.','a','i','1',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_1 =
      declare_string_constant_8(strconst_body_1,4);
  static Const unsigned char strconst_body_2[4] =
    {'.','a','i','2',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_2 =
      declare_string_constant_8(strconst_body_2,4);
  static Const unsigned char strconst_body_3[4] =
    {'.','m','i','d',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_3 =
      declare_string_constant_8(strconst_body_3,4);
  static Const q funct_const_4[] = {
    makesym(functor_putc_1),
    makeint(46),
  };
  q a0, a1, a2, a3, a4, a5;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, make__ai0_5_top);
    case_pred(1, read__ai_6_top);
    case_pred(2, make__ai1_5_top);
    case_pred(3, read__ai1_5_top);
    case_pred(4, make__ai2_4_top);
    case_pred(5, read__ai2_4_top);
    case_pred(6, make__mid_2_top);
    case_pred(7, read__mid_2_top);
    case_pred(8, start__output_3_top);
    case_pred(9, finish__output_2_top);
    case_pred(10, write__word_3_top);
    case_pred(11, start__readin_3_top);
    case_pred(12, finish__readin_2_top);
    case_pred(13, read__word_3_top);
    case_pred(14, writeout__vt_3_top);
    case_pred(15, writeout__vt__clauses_3_top);
    case_pred(16, writeout__vt__clauses1_5_top);
    case_pred(17, writeout__vt__clause_3_top);
    case_pred(18, writeout__vt__clause1_5_top);
    case_pred(19, readin__vt_3_top);
    case_pred(20, readin__vt_4_top);
    case_pred(21, readin__vt__clauses_6_top);
    case_pred(22, readin__vt__clause_6_top);
    case_pred(23, writeout__hb_3_top);
    case_pred(24, writeout__hb__clauses_3_top);
    case_pred(25, readin__hb_3_top);
    case_pred(26, readin__hb_4_top);
    case_pred(27, readin__preds_4_top);
    case_pred(28, writeout__ea_3_top);
    case_pred(29, readin__ea_3_top);
    case_pred(30, readin__ea_4_top);
    case_pred(31, writeout__lt_3_top);
    case_pred(32, readin__lt_3_top);
    case_pred(33, readin__lt_4_top);
    case_pred(34, writeout__modules_3_top);
    case_pred(35, writeout__modules2_3_top);
    case_pred(36, writeout__clauses_5_top);
    case_pred(37, writeout__clause_3_top);
    case_pred(38, writeout__goals_5_top);
    case_pred(39, readin__modules_3_top);
    case_pred(40, readin__modules_4_top);
    case_pred(41, readin__clauses_6_top);
    case_pred(42, readin__clause_4_top);
    case_pred(43, readin__goals_6_top);
    case_pred(44, writeout__adg_3_top);
    case_pred(45, write__adg__entry_3_top);
    case_pred(46, readin__adg_3_top);
    case_pred(47, readin__adg_4_top);
    last_case_pred(48, read__adg__entry_4_top);
  }

 make__ai0_5_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 make__ai0_5_clear_reason:
  reasonp = reasons;
 make__ai0_5_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xfinish__output_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = NILATOM;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_file__op_xwriteout__lt_3);
  allocp[6] = a4;
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = x0;
  allocp[9] = (q)(struct goalrec*)&allocp[4];
  allocp[10] = (q)(&predicate_file__op_xwriteout__ea_3);
  allocp[11] = a3;
  allocp[12] = x2 = makeref(&allocp[12]);
  allocp[13] = x1;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_file__op_xwriteout__hb_3);
  allocp[16] = a2;
  allocp[17] = x3 = makeref(&allocp[17]);
  allocp[18] = x2;
  allocp[19] = (q)(struct goalrec*)&allocp[14];
  allocp[20] = (q)(&predicate_file__op_xwriteout__vt_3);
  allocp[21] = a1;
  allocp[22] = x4 = makeref(&allocp[22]);
  allocp[23] = x3;
  a1 = makefunctor(&string_const_0);
  a2 = x4;
  qp = (struct goalrec*)&allocp[19];
  allocp += 24;
  execute(start__output_3_0);
  goto start__output_3_ext_interrupt;
 make__ai0_5_ext_interrupt:
  reasonp = 0l;
 make__ai0_5_interrupt:
  goto interrupt_5;
 }

 read__ai_6_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 read__ai_6_clear_reason:
  reasonp = reasons;
 read__ai_6_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xfinish__readin_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = NILATOM;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_file__op_xreadin__lt_3);
  allocp[6] = a5;
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = x0;
  allocp[9] = (q)(struct goalrec*)&allocp[4];
  allocp[10] = (q)(&predicate_file__op_xreadin__ea_3);
  allocp[11] = a4;
  allocp[12] = x2 = makeref(&allocp[12]);
  allocp[13] = x1;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_file__op_xreadin__hb_3);
  allocp[16] = a3;
  allocp[17] = x3 = makeref(&allocp[17]);
  allocp[18] = x2;
  allocp[19] = (q)(struct goalrec*)&allocp[14];
  allocp[20] = (q)(&predicate_file__op_xreadin__vt_3);
  allocp[21] = a2;
  allocp[22] = x4 = makeref(&allocp[22]);
  allocp[23] = x3;
  a2 = x4;
  qp = (struct goalrec*)&allocp[19];
  allocp += 24;
  execute(start__readin_3_0);
  goto start__readin_3_ext_interrupt;
 read__ai_6_ext_interrupt:
  reasonp = 0l;
 read__ai_6_interrupt:
  goto interrupt_6;
 }

 make__ai1_5_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 make__ai1_5_clear_reason:
  reasonp = reasons;
 make__ai1_5_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xfinish__output_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = NILATOM;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_file__op_xwriteout__lt_3);
  allocp[6] = a4;
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = x0;
  allocp[9] = (q)(struct goalrec*)&allocp[4];
  allocp[10] = (q)(&predicate_file__op_xwriteout__ea_3);
  allocp[11] = a3;
  allocp[12] = x2 = makeref(&allocp[12]);
  allocp[13] = x1;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_file__op_xwriteout__hb_3);
  allocp[16] = a2;
  allocp[17] = x3 = makeref(&allocp[17]);
  allocp[18] = x2;
  allocp[19] = (q)(struct goalrec*)&allocp[14];
  allocp[20] = (q)(&predicate_file__op_xwriteout__vt_3);
  allocp[21] = a1;
  allocp[22] = x4 = makeref(&allocp[22]);
  allocp[23] = x3;
  a1 = makefunctor(&string_const_1);
  a2 = x4;
  qp = (struct goalrec*)&allocp[19];
  allocp += 24;
  execute(start__output_3_0);
  goto start__output_3_ext_interrupt;
 make__ai1_5_ext_interrupt:
  reasonp = 0l;
 make__ai1_5_interrupt:
  goto interrupt_5;
 }

 read__ai1_5_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 read__ai1_5_clear_reason:
  reasonp = reasons;
 read__ai1_5_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xfinish__readin_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = NILATOM;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_file__op_xreadin__lt_3);
  allocp[6] = a4;
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = x0;
  allocp[9] = (q)(struct goalrec*)&allocp[4];
  allocp[10] = (q)(&predicate_file__op_xreadin__ea_3);
  allocp[11] = a3;
  allocp[12] = x2 = makeref(&allocp[12]);
  allocp[13] = x1;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_file__op_xreadin__hb_3);
  allocp[16] = a2;
  allocp[17] = x3 = makeref(&allocp[17]);
  allocp[18] = x2;
  allocp[19] = (q)(struct goalrec*)&allocp[14];
  allocp[20] = (q)(&predicate_file__op_xreadin__vt_3);
  allocp[21] = a1;
  allocp[22] = x4 = makeref(&allocp[22]);
  allocp[23] = x3;
  a1 = makefunctor(&string_const_1);
  a2 = x4;
  qp = (struct goalrec*)&allocp[19];
  allocp += 24;
  execute(start__readin_3_0);
  goto start__readin_3_ext_interrupt;
 read__ai1_5_ext_interrupt:
  reasonp = 0l;
 read__ai1_5_interrupt:
  goto interrupt_5;
 }

 make__ai2_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 make__ai2_4_clear_reason:
  reasonp = reasons;
 make__ai2_4_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xfinish__output_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = NILATOM;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_file__op_xwriteout__adg_3);
  allocp[6] = a3;
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = x0;
  allocp[9] = (q)(struct goalrec*)&allocp[4];
  allocp[10] = (q)(&predicate_file__op_xwriteout__hb_3);
  allocp[11] = a2;
  allocp[12] = x2 = makeref(&allocp[12]);
  allocp[13] = x1;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_file__op_xwriteout__vt_3);
  allocp[16] = a1;
  allocp[17] = x3 = makeref(&allocp[17]);
  allocp[18] = x2;
  a1 = makefunctor(&string_const_2);
  a2 = x3;
  qp = (struct goalrec*)&allocp[14];
  allocp += 19;
  execute(start__output_3_0);
  goto start__output_3_ext_interrupt;
 make__ai2_4_ext_interrupt:
  reasonp = 0l;
 make__ai2_4_interrupt:
  goto interrupt_4;
 }

 read__ai2_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 read__ai2_4_clear_reason:
  reasonp = reasons;
 read__ai2_4_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xfinish__readin_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = NILATOM;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_file__op_xreadin__adg_3);
  allocp[6] = a3;
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = x0;
  allocp[9] = (q)(struct goalrec*)&allocp[4];
  allocp[10] = (q)(&predicate_file__op_xreadin__hb_3);
  allocp[11] = a2;
  allocp[12] = x2 = makeref(&allocp[12]);
  allocp[13] = x1;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_file__op_xreadin__vt_3);
  allocp[16] = a1;
  allocp[17] = x3 = makeref(&allocp[17]);
  allocp[18] = x2;
  a1 = makefunctor(&string_const_2);
  a2 = x3;
  qp = (struct goalrec*)&allocp[14];
  allocp += 19;
  execute(start__readin_3_0);
  goto start__readin_3_ext_interrupt;
 read__ai2_4_ext_interrupt:
  reasonp = 0l;
 read__ai2_4_interrupt:
  goto interrupt_4;
 }

 make__mid_2_top: {
  q x0, x1;
  qp = qp->next;
 make__mid_2_clear_reason:
  reasonp = reasons;
 make__mid_2_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xfinish__output_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = NILATOM;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_file__op_xwriteout__modules_3);
  allocp[6] = a1;
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = x0;
  a1 = makefunctor(&string_const_3);
  a2 = x1;
  qp = (struct goalrec*)&allocp[4];
  allocp += 9;
  execute(start__output_3_0);
  goto start__output_3_ext_interrupt;
 make__mid_2_ext_interrupt:
  reasonp = 0l;
 make__mid_2_interrupt:
  goto interrupt_2;
 }

 read__mid_2_top: {
  q x0, x1;
  qp = qp->next;
 read__mid_2_clear_reason:
  reasonp = reasons;
 read__mid_2_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xfinish__readin_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = NILATOM;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_file__op_xreadin__modules_3);
  allocp[6] = a1;
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = x0;
  a1 = makefunctor(&string_const_3);
  a2 = x1;
  qp = (struct goalrec*)&allocp[4];
  allocp += 9;
  execute(start__readin_3_0);
  goto start__readin_3_ext_interrupt;
 read__mid_2_ext_interrupt:
  reasonp = 0l;
 read__mid_2_interrupt:
  goto interrupt_2;
 }

 start__output_3_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  qp = qp->next;
 start__output_3_clear_reason:
  reasonp = reasons;
 start__output_3_0:
  generic_arg[0] = a1;
  allocp[0] = x0 = makeref(&allocp[0]);
  generic_arg[1] = x0;
  call_generic(a0, functor_join_2, 1);
  allocp[0] = makesym(functor_normal_1);
  allocp[1] = a2;
  x1 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_write__open_2);
  allocp[3] = x0;
  allocp[4] = x1;
  x2 = makefunctor(&allocp[2]);
  allocp[5] = NILATOM;
  allocp[6] = x2;
  x3 = makecons(&allocp[5]);
  allocp[7] = (q)qp;
  allocp[8] = (q)(&predicate_klicio_xklicio_1);
  allocp[9] = x3;
  qp = (struct goalrec*)&allocp[7];
  allocp += 10;
  proceed();
 start__output_3_ext_interrupt:
  reasonp = 0l;
 start__output_3_interrupt:
  toppred = &predicate_file__op_xstart__output_3;
  goto interrupt_3;
 }

 finish__output_2_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  qp = qp->next;
 finish__output_2_clear_reason:
  reasonp = reasons;
 finish__output_2_0:
  allocp[0] = makesym(functor_fflush_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = x0;
  x2 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a0, x2);
  allocp[0] = makesym(functor_fclose_1);
  allocp[1] = x5 = makeref(&allocp[1]);
  x4 = makefunctor(&allocp[0]);
  allocp[2] = a1;
  allocp[3] = x4;
  x6 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(x3, x6);
  proceed();
 finish__output_2_ext_interrupt:
  reasonp = 0l;
 finish__output_2_interrupt:
  goto interrupt_2;
 }

 write__word_3_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  qp = qp->next;
 write__word_3_clear_reason:
  reasonp = reasons;
 write__word_3_0:
  allocp[0] = a2;
  allocp[1] = makesym(atom_nl);
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = makefunctor(funct_const_4);
  x1 = makecons(&allocp[2]);
  allocp[4] = makesym(functor_putt_1);
  allocp[5] = x3 = makeref(&allocp[5]);
  x2 = makefunctor(&allocp[4]);
  allocp[6] = x1;
  allocp[7] = x2;
  x4 = makecons(&allocp[6]);
  allocp += 8;
  unify_value(a1, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_variable_xwrap_2);
  allocp[2] = a0;
  allocp[3] = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  proceed();
 write__word_3_ext_interrupt:
  reasonp = 0l;
 write__word_3_interrupt:
  toppred = &predicate_file__op_xwrite__word_3;
  goto interrupt_3;
 }

 start__readin_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 start__readin_3_clear_reason:
  reasonp = reasons;
 start__readin_3_0:
  generic_arg[0] = a1;
  allocp[0] = x0 = makeref(&allocp[0]);
  generic_arg[1] = x0;
  call_generic(a0, functor_join_2, 1);
  allocp[0] = makesym(functor_normal_1);
  allocp[1] = a2;
  x1 = makefunctor(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__message_xsee_2);
  allocp[4] = x0;
  allocp[5] = x1;
  qp = (struct goalrec*)&allocp[2];
  allocp += 6;
  proceed();
 start__readin_3_ext_interrupt:
  reasonp = 0l;
 start__readin_3_interrupt:
  toppred = &predicate_file__op_xstart__readin_3;
  goto interrupt_3;
 }

 finish__readin_2_top: {
  q x0, x1, x2;
  qp = qp->next;
 finish__readin_2_clear_reason:
  reasonp = reasons;
 finish__readin_2_0:
  allocp[0] = makesym(functor_fclose_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = a1;
  allocp[3] = x0;
  x2 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a0, x2);
  proceed();
 finish__readin_2_ext_interrupt:
  reasonp = 0l;
 finish__readin_2_interrupt:
  goto interrupt_2;
 }

 read__word_3_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  qp = qp->next;
 read__word_3_clear_reason:
  reasonp = reasons;
 read__word_3_0:
  allocp[0] = makesym(functor_gett_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = a2;
  allocp[3] = x0;
  x2 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a1, x2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_variable_xunwrap_2);
  allocp[2] = x1;
  allocp[3] = a0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  proceed();
 read__word_3_ext_interrupt:
  reasonp = 0l;
 read__word_3_interrupt:
  toppred = &predicate_file__op_xread__word_3;
  goto interrupt_3;
 }

 writeout__vt_3_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  qp = qp->next;
 writeout__vt_3_clear_reason:
  reasonp = reasons;
 writeout__vt_3_0:
 writeout__vt_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 writeout__vt_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto writeout__vt_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xwriteout__vt_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_file__op_xwriteout__vt__clauses_3);
  x3 = arg(x0, 1);
  allocp[7] = x3;
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = x2;
  a0 = arg(x0, 0);
  a2 = x4;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  execute(write__word_3_0);
  goto write__word_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,writeout__vt_3_2);
  *reasonp++ =  x0;
  goto writeout__vt_3_interrupt;
  };
  goto writeout__vt_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto writeout__vt_3_interrupt;
  a0 = makesym(atom_end__of__vt);
  execute(write__word_3_0);
  goto write__word_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,writeout__vt_3_1);
  *reasonp++ =  a0;
  goto writeout__vt_3_interrupt;
  };
  goto writeout__vt_3_interrupt;
 writeout__vt_3_ext_interrupt:
  reasonp = 0l;
 writeout__vt_3_interrupt:
  goto interrupt_3;
 }

 writeout__vt__clauses_3_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  qp = qp->next;
 writeout__vt__clauses_3_clear_reason:
  reasonp = reasons;
 writeout__vt__clauses_3_0:
 writeout__vt__clauses_3_1:
  if (isref(a0)) goto writeout__vt__clauses_3_2;
  gblt_pfunctor(a0,x0,writeout__vt__clauses_3_interrupt);
  if (x0 != makesym(atom_clauses)) goto writeout__vt__clauses_3_interrupt;
  gblt_arity(a0,x1,writeout__vt__clauses_3_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xwriteout__vt__clauses1_5);
  allocp[2] = a0;
  allocp[3] = makeint(1L);
  allocp[4] = x1;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a2;
  a0 = x1;
  a2 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(write__word_3_0);
  goto write__word_3_ext_interrupt;
 writeout__vt__clauses_3_2:
  deref_and_jump(a0,writeout__vt__clauses_3_1);
  *reasonp++ =  a0;
  goto writeout__vt__clauses_3_interrupt;
 writeout__vt__clauses_3_ext_interrupt:
  reasonp = 0l;
 writeout__vt__clauses_3_interrupt:
  goto interrupt_3;
 }

 writeout__vt__clauses1_5_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 writeout__vt__clauses1_5_clear_reason:
  reasonp = reasons;
 writeout__vt__clauses1_5_0:
 writeout__vt__clauses1_5_1:
  if (!isint(a1)) goto writeout__vt__clauses1_5_5;
 writeout__vt__clauses1_5_2:
  if (!isint(a2)) goto writeout__vt__clauses1_5_4;
  gblt_less_or_eq(a1,a2,writeout__vt__clauses1_5_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xwriteout__vt__clauses1_5);
  allocp[2] = a0;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[9] = a1;
  allocp[10] = makeint(1L);
  allocp[11] = x0;
  allocp[12] = (q)(struct goalrec*)&allocp[7];
  allocp[13] = (q)(&predicate_file__op_xwriteout__vt__clause_3);
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = a3;
  allocp[16] = x1;
  allocp[17] = (q)(struct goalrec*)&allocp[12];
  allocp[18] = (q)(&predicate_functor__table_xarg_3);
  allocp[19] = a1;
  allocp[20] = a0;
  allocp[21] = x2;
  qp = (struct goalrec*)&allocp[17];
  allocp += 22;
  proceed();
 writeout__vt__clauses1_5_3:
  gblt_greater(a1,a2,writeout__vt__clauses1_5_interrupt);
  unify(a4, a3);
  proceed();
 writeout__vt__clauses1_5_4:
  if (!isref(a2)) goto writeout__vt__clauses1_5_interrupt;
  deref_and_jump(a2,writeout__vt__clauses1_5_2);
  *reasonp++ =  a2;
  goto writeout__vt__clauses1_5_interrupt;
 writeout__vt__clauses1_5_5:
  if (!isref(a1)) goto writeout__vt__clauses1_5_interrupt;
  deref_and_jump(a1,writeout__vt__clauses1_5_1);
  *reasonp++ =  a1;
  goto writeout__vt__clauses1_5_interrupt;
 writeout__vt__clauses1_5_ext_interrupt:
  reasonp = 0l;
 writeout__vt__clauses1_5_interrupt:
  goto interrupt_5;
 }

 writeout__vt__clause_3_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  qp = qp->next;
 writeout__vt__clause_3_clear_reason:
  reasonp = reasons;
 writeout__vt__clause_3_0:
 writeout__vt__clause_3_1:
  if (isref(a0)) goto writeout__vt__clause_3_2;
  gblt_pfunctor(a0,x0,writeout__vt__clause_3_interrupt);
  gblt_arity(a0,x1,writeout__vt__clause_3_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xwriteout__vt__clause1_5);
  allocp[2] = a0;
  allocp[3] = makeint(1L);
  allocp[4] = x1;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a2;
  a0 = x1;
  a2 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(write__word_3_0);
  goto write__word_3_ext_interrupt;
 writeout__vt__clause_3_2:
  deref_and_jump(a0,writeout__vt__clause_3_1);
  *reasonp++ =  a0;
  goto writeout__vt__clause_3_interrupt;
 writeout__vt__clause_3_ext_interrupt:
  reasonp = 0l;
 writeout__vt__clause_3_interrupt:
  goto interrupt_3;
 }

 writeout__vt__clause1_5_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 writeout__vt__clause1_5_clear_reason:
  reasonp = reasons;
 writeout__vt__clause1_5_0:
 writeout__vt__clause1_5_1:
  if (!isint(a1)) goto writeout__vt__clause1_5_5;
 writeout__vt__clause1_5_2:
  if (!isint(a2)) goto writeout__vt__clause1_5_4;
  gblt_less_or_eq(a1,a2,writeout__vt__clause1_5_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xwriteout__vt__clause1_5);
  allocp[2] = a0;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[9] = a1;
  allocp[10] = makeint(1L);
  allocp[11] = x0;
  allocp[12] = (q)(struct goalrec*)&allocp[7];
  allocp[13] = (q)(&predicate_file__op_xwrite__word_3);
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = a3;
  allocp[16] = x1;
  allocp[17] = (q)(struct goalrec*)&allocp[12];
  allocp[18] = (q)(&predicate_functor__table_xarg_3);
  allocp[19] = a1;
  allocp[20] = a0;
  allocp[21] = x2;
  qp = (struct goalrec*)&allocp[17];
  allocp += 22;
  proceed();
 writeout__vt__clause1_5_3:
  gblt_greater(a1,a2,writeout__vt__clause1_5_interrupt);
  unify(a4, a3);
  proceed();
 writeout__vt__clause1_5_4:
  if (!isref(a2)) goto writeout__vt__clause1_5_interrupt;
  deref_and_jump(a2,writeout__vt__clause1_5_2);
  *reasonp++ =  a2;
  goto writeout__vt__clause1_5_interrupt;
 writeout__vt__clause1_5_5:
  if (!isref(a1)) goto writeout__vt__clause1_5_interrupt;
  deref_and_jump(a1,writeout__vt__clause1_5_1);
  *reasonp++ =  a1;
  goto writeout__vt__clause1_5_interrupt;
 writeout__vt__clause1_5_ext_interrupt:
  reasonp = 0l;
 writeout__vt__clause1_5_interrupt:
  goto interrupt_5;
 }

 readin__vt_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 readin__vt_3_clear_reason:
  reasonp = reasons;
 readin__vt_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xreadin__vt_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a2;
  a0 = x0;
  a2 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(read__word_3_0);
  goto read__word_3_ext_interrupt;
 readin__vt_3_ext_interrupt:
  reasonp = 0l;
 readin__vt_3_interrupt:
  goto interrupt_3;
 }

 readin__vt_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 readin__vt_4_clear_reason:
  reasonp = reasons;
 readin__vt_4_0:
 readin__vt_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_end__of__vt)) goto readin__vt_4_2;
  unify(a3, a2);
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,readin__vt_4_1);
  *reasonp++ =  a0;
  goto readin__vt_4_2;
  };
  goto readin__vt_4_2;
 readin__vt_4_2:
  otherwise(readin__vt_4_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xreadin__vt_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_file__op_xread__word_3);
  allocp[8] = x0;
  allocp[9] = x3 = makeref(&allocp[9]);
  allocp[10] = x2;
  allocp[11] = makesym(functor_module_2);
  allocp[12] = a0;
  allocp[13] = x5 = makeref(&allocp[13]);
  x4 = makefunctor(&allocp[11]);
  allocp[14] = x1;
  allocp[15] = x4;
  x6 = makecons(&allocp[14]);
  qp = (struct goalrec*)&allocp[6];
  allocp += 16;
  unify_value(a1, x6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xreadin__vt__clauses_6);
  allocp[2] = makeint(1L);
  allocp[3] = x7 = makeref(&allocp[3]);
  allocp[4] = makesym(atom_clauses);
  allocp[5] = x5;
  allocp[6] = x8 = makeref(&allocp[6]);
  allocp[7] = x3;
  a0 = x7;
  a1 = a2;
  a2 = x8;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  execute(read__word_3_0);
  goto read__word_3_ext_interrupt;
 readin__vt_4_ext_interrupt:
  reasonp = 0l;
 readin__vt_4_interrupt:
  goto interrupt_4;
 }

 readin__vt__clauses_6_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 readin__vt__clauses_6_clear_reason:
  reasonp = reasons;
 readin__vt__clauses_6_0:
 readin__vt__clauses_6_1:
  if (!isint(a0)) goto readin__vt__clauses_6_5;
 readin__vt__clauses_6_2:
  if (!isint(a1)) goto readin__vt__clauses_6_4;
  gblt_less_or_eq(a0,a1,readin__vt__clauses_6_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xreadin__vt__clauses_6);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[10] = a0;
  allocp[11] = makeint(1L);
  allocp[12] = x0;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_functor_xinsert__arg_4);
  allocp[15] = a0;
  allocp[16] = a2;
  allocp[17] = x3 = makeref(&allocp[17]);
  allocp[18] = x1;
  allocp[19] = (q)(struct goalrec*)&allocp[13];
  allocp[20] = (q)(&predicate_file__op_xreadin__vt__clause_6);
  allocp[21] = makeint(1L);
  allocp[22] = x4 = makeref(&allocp[22]);
  allocp[23] = makesym(atom_clause);
  allocp[24] = x3;
  allocp[25] = x5 = makeref(&allocp[25]);
  allocp[26] = x2;
  a0 = x4;
  a1 = a4;
  a2 = x5;
  qp = (struct goalrec*)&allocp[19];
  allocp += 27;
  execute(read__word_3_0);
  goto read__word_3_ext_interrupt;
 readin__vt__clauses_6_3:
  gblt_greater(a0,a1,readin__vt__clauses_6_interrupt);
  unify2(a5, a4, a3, a2);
  proceed();
 readin__vt__clauses_6_4:
  if (!isref(a1)) goto readin__vt__clauses_6_interrupt;
  deref_and_jump(a1,readin__vt__clauses_6_2);
  *reasonp++ =  a1;
  goto readin__vt__clauses_6_interrupt;
 readin__vt__clauses_6_5:
  if (!isref(a0)) goto readin__vt__clauses_6_interrupt;
  deref_and_jump(a0,readin__vt__clauses_6_1);
  *reasonp++ =  a0;
  goto readin__vt__clauses_6_interrupt;
 readin__vt__clauses_6_ext_interrupt:
  reasonp = 0l;
 readin__vt__clauses_6_interrupt:
  goto interrupt_6;
 }

 readin__vt__clause_6_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 readin__vt__clause_6_clear_reason:
  reasonp = reasons;
 readin__vt__clause_6_0:
 readin__vt__clause_6_1:
  if (!isint(a0)) goto readin__vt__clause_6_5;
 readin__vt__clause_6_2:
  if (!isint(a1)) goto readin__vt__clause_6_4;
  gblt_less_or_eq(a0,a1,readin__vt__clause_6_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xreadin__vt__clause_6);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[10] = a0;
  allocp[11] = makeint(1L);
  allocp[12] = x0;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_functor_xinsert__arg_4);
  allocp[15] = a0;
  allocp[16] = a2;
  allocp[17] = x3 = makeref(&allocp[17]);
  allocp[18] = x1;
  a0 = x3;
  a1 = a4;
  a2 = x2;
  qp = (struct goalrec*)&allocp[13];
  allocp += 19;
  execute(read__word_3_0);
  goto read__word_3_ext_interrupt;
 readin__vt__clause_6_3:
  gblt_greater(a0,a1,readin__vt__clause_6_interrupt);
  unify2(a5, a4, a3, a2);
  proceed();
 readin__vt__clause_6_4:
  if (!isref(a1)) goto readin__vt__clause_6_interrupt;
  deref_and_jump(a1,readin__vt__clause_6_2);
  *reasonp++ =  a1;
  goto readin__vt__clause_6_interrupt;
 readin__vt__clause_6_5:
  if (!isref(a0)) goto readin__vt__clause_6_interrupt;
  deref_and_jump(a0,readin__vt__clause_6_1);
  *reasonp++ =  a0;
  goto readin__vt__clause_6_interrupt;
 readin__vt__clause_6_ext_interrupt:
  reasonp = 0l;
 readin__vt__clause_6_interrupt:
  goto interrupt_6;
 }

 writeout__hb_3_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  qp = qp->next;
 writeout__hb_3_clear_reason:
  reasonp = reasons;
 writeout__hb_3_0:
 writeout__hb_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 writeout__hb_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto writeout__hb_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xwriteout__hb_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_file__op_xwriteout__hb__clauses_3);
  x3 = arg(x0, 1);
  allocp[7] = x3;
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = x2;
  a0 = arg(x0, 0);
  a2 = x4;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  execute(write__word_3_0);
  goto write__word_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,writeout__hb_3_2);
  *reasonp++ =  x0;
  goto writeout__hb_3_interrupt;
  };
  goto writeout__hb_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto writeout__hb_3_interrupt;
  a0 = makesym(atom_end__of__hb);
  execute(write__word_3_0);
  goto write__word_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,writeout__hb_3_1);
  *reasonp++ =  a0;
  goto writeout__hb_3_interrupt;
  };
  goto writeout__hb_3_interrupt;
 writeout__hb_3_ext_interrupt:
  reasonp = 0l;
 writeout__hb_3_interrupt:
  goto interrupt_3;
 }

 writeout__hb__clauses_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16;
  a2 = qp->args[2];
  qp = qp->next;
 writeout__hb__clauses_3_clear_reason:
  reasonp = reasons;
 writeout__hb__clauses_3_0:
 writeout__hb__clauses_3_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = makesym(functor_pred_7);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = x5 = makeref(&allocp[5]);
  allocp[6] = x6 = makeref(&allocp[6]);
  allocp[7] = x7 = makeref(&allocp[7]);
  x0 = makefunctor(&allocp[0]);
  x8 = car_of(a0);
  allocp += 8;
  unify_value(x8, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xwriteout__hb__clauses_3);
  x9 = cdr_of(a0);
  allocp[2] = x9;
  allocp[3] = x10 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_file__op_xwrite__word_3);
  allocp[7] = x7;
  allocp[8] = x11 = makeref(&allocp[8]);
  allocp[9] = x10;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_file__op_xwrite__word_3);
  allocp[12] = x6;
  allocp[13] = x12 = makeref(&allocp[13]);
  allocp[14] = x11;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_file__op_xwrite__word_3);
  allocp[17] = x5;
  allocp[18] = x13 = makeref(&allocp[18]);
  allocp[19] = x12;
  allocp[20] = (q)(struct goalrec*)&allocp[15];
  allocp[21] = (q)(&predicate_file__op_xwrite__word_3);
  allocp[22] = x4;
  allocp[23] = x14 = makeref(&allocp[23]);
  allocp[24] = x13;
  allocp[25] = (q)(struct goalrec*)&allocp[20];
  allocp[26] = (q)(&predicate_file__op_xwrite__word_3);
  allocp[27] = x3;
  allocp[28] = x15 = makeref(&allocp[28]);
  allocp[29] = x14;
  allocp[30] = (q)(struct goalrec*)&allocp[25];
  allocp[31] = (q)(&predicate_file__op_xwrite__word_3);
  allocp[32] = x2;
  allocp[33] = x16 = makeref(&allocp[33]);
  allocp[34] = x15;
  a0 = x1;
  a2 = x16;
  qp = (struct goalrec*)&allocp[30];
  allocp += 35;
  execute(write__word_3_0);
  goto write__word_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto writeout__hb__clauses_3_interrupt;
  a0 = makesym(atom_end__of__hb__preds);
  execute(write__word_3_0);
  goto write__word_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,writeout__hb__clauses_3_1);
  *reasonp++ =  a0;
  goto writeout__hb__clauses_3_interrupt;
  };
  goto writeout__hb__clauses_3_interrupt;
 writeout__hb__clauses_3_ext_interrupt:
  reasonp = 0l;
 writeout__hb__clauses_3_interrupt:
  goto interrupt_3;
 }

 readin__hb_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 readin__hb_3_clear_reason:
  reasonp = reasons;
 readin__hb_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xreadin__hb_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a2;
  a0 = x0;
  a2 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(read__word_3_0);
  goto read__word_3_ext_interrupt;
 readin__hb_3_ext_interrupt:
  reasonp = 0l;
 readin__hb_3_interrupt:
  goto interrupt_3;
 }

 readin__hb_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 readin__hb_4_clear_reason:
  reasonp = reasons;
 readin__hb_4_0:
 readin__hb_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_end__of__hb)) goto readin__hb_4_2;
  unify(a3, a2);
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,readin__hb_4_1);
  *reasonp++ =  a0;
  goto readin__hb_4_2;
  };
  goto readin__hb_4_2;
 readin__hb_4_2:
  otherwise(readin__hb_4_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xreadin__hb_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_file__op_xread__word_3);
  allocp[8] = x0;
  allocp[9] = x3 = makeref(&allocp[9]);
  allocp[10] = x2;
  allocp[11] = makesym(functor_module_2);
  allocp[12] = a0;
  allocp[13] = x5 = makeref(&allocp[13]);
  x4 = makefunctor(&allocp[11]);
  allocp[14] = x1;
  allocp[15] = x4;
  x6 = makecons(&allocp[14]);
  qp = (struct goalrec*)&allocp[6];
  allocp += 16;
  unify_value(a1, x6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xreadin__preds_4);
  allocp[2] = x7 = makeref(&allocp[2]);
  allocp[3] = x5;
  allocp[4] = x8 = makeref(&allocp[4]);
  allocp[5] = x3;
  a0 = x7;
  a1 = a2;
  a2 = x8;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(read__word_3_0);
  goto read__word_3_ext_interrupt;
 readin__hb_4_ext_interrupt:
  reasonp = 0l;
 readin__hb_4_interrupt:
  goto interrupt_4;
 }

 readin__preds_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 readin__preds_4_clear_reason:
  reasonp = reasons;
 readin__preds_4_0:
 readin__preds_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_end__of__hb__preds)) goto readin__preds_4_2;
  unify(a3, a2);
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,readin__preds_4_1);
  *reasonp++ =  a0;
  goto readin__preds_4_2;
  };
  goto readin__preds_4_2;
 readin__preds_4_2:
  otherwise(readin__preds_4_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xreadin__preds_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_file__op_xread__word_3);
  allocp[8] = x0;
  allocp[9] = x3 = makeref(&allocp[9]);
  allocp[10] = x2;
  allocp[11] = makesym(functor_pred_7);
  allocp[12] = a0;
  allocp[13] = x5 = makeref(&allocp[13]);
  allocp[14] = x6 = makeref(&allocp[14]);
  allocp[15] = x7 = makeref(&allocp[15]);
  allocp[16] = x8 = makeref(&allocp[16]);
  allocp[17] = x9 = makeref(&allocp[17]);
  allocp[18] = x10 = makeref(&allocp[18]);
  x4 = makefunctor(&allocp[11]);
  allocp[19] = x1;
  allocp[20] = x4;
  x11 = makecons(&allocp[19]);
  qp = (struct goalrec*)&allocp[6];
  allocp += 21;
  unify_value(a1, x11);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xread__word_3);
  allocp[2] = x10;
  allocp[3] = x12 = makeref(&allocp[3]);
  allocp[4] = x3;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_file__op_xread__word_3);
  allocp[7] = x9;
  allocp[8] = x13 = makeref(&allocp[8]);
  allocp[9] = x12;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_file__op_xread__word_3);
  allocp[12] = x8;
  allocp[13] = x14 = makeref(&allocp[13]);
  allocp[14] = x13;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_file__op_xread__word_3);
  allocp[17] = x7;
  allocp[18] = x15 = makeref(&allocp[18]);
  allocp[19] = x14;
  allocp[20] = (q)(struct goalrec*)&allocp[15];
  allocp[21] = (q)(&predicate_file__op_xread__word_3);
  allocp[22] = x6;
  allocp[23] = x16 = makeref(&allocp[23]);
  allocp[24] = x15;
  a0 = x5;
  a1 = a2;
  a2 = x16;
  qp = (struct goalrec*)&allocp[20];
  allocp += 25;
  execute(read__word_3_0);
  goto read__word_3_ext_interrupt;
 readin__preds_4_ext_interrupt:
  reasonp = 0l;
 readin__preds_4_interrupt:
  goto interrupt_4;
 }

 writeout__ea_3_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  qp = qp->next;
 writeout__ea_3_clear_reason:
  reasonp = reasons;
 writeout__ea_3_0:
 writeout__ea_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 writeout__ea_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_3)) goto writeout__ea_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xwriteout__ea_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_file__op_xwrite__word_3);
  x3 = arg(x0, 2);
  allocp[7] = x3;
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = x2;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_file__op_xwrite__word_3);
  x5 = arg(x0, 1);
  allocp[12] = x5;
  allocp[13] = x6 = makeref(&allocp[13]);
  allocp[14] = x4;
  a0 = arg(x0, 0);
  a2 = x6;
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  execute(write__word_3_0);
  goto write__word_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,writeout__ea_3_2);
  *reasonp++ =  x0;
  goto writeout__ea_3_interrupt;
  };
  goto writeout__ea_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto writeout__ea_3_interrupt;
  a0 = makesym(atom_end__of__ea);
  execute(write__word_3_0);
  goto write__word_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,writeout__ea_3_1);
  *reasonp++ =  a0;
  goto writeout__ea_3_interrupt;
  };
  goto writeout__ea_3_interrupt;
 writeout__ea_3_ext_interrupt:
  reasonp = 0l;
 writeout__ea_3_interrupt:
  goto interrupt_3;
 }

 readin__ea_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 readin__ea_3_clear_reason:
  reasonp = reasons;
 readin__ea_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xreadin__ea_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a2;
  a0 = x0;
  a2 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(read__word_3_0);
  goto read__word_3_ext_interrupt;
 readin__ea_3_ext_interrupt:
  reasonp = 0l;
 readin__ea_3_interrupt:
  goto interrupt_3;
 }

 readin__ea_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 readin__ea_4_clear_reason:
  reasonp = reasons;
 readin__ea_4_0:
 readin__ea_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_end__of__ea)) goto readin__ea_4_2;
  unify(a3, a2);
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,readin__ea_4_1);
  *reasonp++ =  a0;
  goto readin__ea_4_2;
  };
  goto readin__ea_4_2;
 readin__ea_4_2:
  otherwise(readin__ea_4_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xreadin__ea_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_file__op_xread__word_3);
  allocp[8] = x0;
  allocp[9] = x3 = makeref(&allocp[9]);
  allocp[10] = x2;
  allocp[11] = makesym(functor_module_3);
  allocp[12] = a0;
  allocp[13] = x5 = makeref(&allocp[13]);
  allocp[14] = x6 = makeref(&allocp[14]);
  x4 = makefunctor(&allocp[11]);
  allocp[15] = x1;
  allocp[16] = x4;
  x7 = makecons(&allocp[15]);
  qp = (struct goalrec*)&allocp[6];
  allocp += 17;
  unify_value(a1, x7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xread__word_3);
  allocp[2] = x6;
  allocp[3] = x8 = makeref(&allocp[3]);
  allocp[4] = x3;
  a0 = x5;
  a1 = a2;
  a2 = x8;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(read__word_3_0);
  goto read__word_3_ext_interrupt;
 readin__ea_4_ext_interrupt:
  reasonp = 0l;
 readin__ea_4_interrupt:
  goto interrupt_4;
 }

 writeout__lt_3_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  qp = qp->next;
 writeout__lt_3_clear_reason:
  reasonp = reasons;
 writeout__lt_3_0:
 writeout__lt_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 writeout__lt_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto writeout__lt_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xwriteout__lt_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_file__op_xwrite__word_3);
  x3 = arg(x0, 1);
  allocp[7] = x3;
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = x2;
  a0 = arg(x0, 0);
  a2 = x4;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  execute(write__word_3_0);
  goto write__word_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,writeout__lt_3_2);
  *reasonp++ =  x0;
  goto writeout__lt_3_interrupt;
  };
  goto writeout__lt_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto writeout__lt_3_interrupt;
  a0 = makesym(atom_end__of__lt);
  execute(write__word_3_0);
  goto write__word_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,writeout__lt_3_1);
  *reasonp++ =  a0;
  goto writeout__lt_3_interrupt;
  };
  goto writeout__lt_3_interrupt;
 writeout__lt_3_ext_interrupt:
  reasonp = 0l;
 writeout__lt_3_interrupt:
  goto interrupt_3;
 }

 readin__lt_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 readin__lt_3_clear_reason:
  reasonp = reasons;
 readin__lt_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xreadin__lt_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a2;
  a0 = x0;
  a2 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(read__word_3_0);
  goto read__word_3_ext_interrupt;
 readin__lt_3_ext_interrupt:
  reasonp = 0l;
 readin__lt_3_interrupt:
  goto interrupt_3;
 }

 readin__lt_4_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 readin__lt_4_clear_reason:
  reasonp = reasons;
 readin__lt_4_0:
 readin__lt_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_end__of__lt)) goto readin__lt_4_2;
  unify(a3, a2);
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,readin__lt_4_1);
  *reasonp++ =  a0;
  goto readin__lt_4_2;
  };
  goto readin__lt_4_2;
 readin__lt_4_2:
  otherwise(readin__lt_4_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xreadin__lt_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_file__op_xread__word_3);
  allocp[8] = x0;
  allocp[9] = x3 = makeref(&allocp[9]);
  allocp[10] = x2;
  allocp[11] = makesym(functor_module_2);
  allocp[12] = a0;
  allocp[13] = x5 = makeref(&allocp[13]);
  x4 = makefunctor(&allocp[11]);
  allocp[14] = x1;
  allocp[15] = x4;
  x6 = makecons(&allocp[14]);
  qp = (struct goalrec*)&allocp[6];
  allocp += 16;
  unify_value(a1, x6);
  a0 = x5;
  a1 = a2;
  a2 = x3;
  execute(read__word_3_0);
  goto read__word_3_ext_interrupt;
 readin__lt_4_ext_interrupt:
  reasonp = 0l;
 readin__lt_4_interrupt:
  goto interrupt_4;
 }

 writeout__modules_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 writeout__modules_3_clear_reason:
  reasonp = reasons;
 writeout__modules_3_0:
 writeout__modules_3_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_normal_2)) goto writeout__modules_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xwrite__word_3);
  x0 = arg(a0, 1);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  a0 = arg(a0, 0);
  a2 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(writeout__modules2_3_0);
  goto writeout__modules2_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,writeout__modules_3_1);
  *reasonp++ =  a0;
  goto writeout__modules_3_interrupt;
  };
  goto writeout__modules_3_interrupt;
 writeout__modules_3_ext_interrupt:
  reasonp = 0l;
 writeout__modules_3_interrupt:
  goto interrupt_3;
 }

 writeout__modules2_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  qp = qp->next;
 writeout__modules2_3_clear_reason:
  reasonp = reasons;
 writeout__modules2_3_0:
 writeout__modules2_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 writeout__modules2_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto writeout__modules2_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xwriteout__modules2_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_file__op_xwriteout__clauses_5);
  allocp[7] = makeint(1L);
  allocp[8] = x3 = makeref(&allocp[8]);
  x4 = arg(x0, 1);
  allocp[9] = x4;
  allocp[10] = x5 = makeref(&allocp[10]);
  allocp[11] = x2;
  allocp[12] = (q)(struct goalrec*)&allocp[5];
  allocp[13] = (q)(&predicate_file__op_xwrite__word_3);
  allocp[14] = x3;
  allocp[15] = x6 = makeref(&allocp[15]);
  allocp[16] = x5;
  allocp[17] = (q)(struct goalrec*)&allocp[12];
  allocp[18] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[19] = x4;
  allocp[20] = x7 = makeref(&allocp[20]);
  allocp[21] = x3;
  a0 = arg(x0, 0);
  a2 = x6;
  qp = (struct goalrec*)&allocp[17];
  allocp += 22;
  execute(write__word_3_0);
  goto write__word_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,writeout__modules2_3_2);
  *reasonp++ =  x0;
  goto writeout__modules2_3_interrupt;
  };
  goto writeout__modules2_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto writeout__modules2_3_interrupt;
  a0 = makesym(atom_end__of__modules);
  execute(write__word_3_0);
  goto write__word_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,writeout__modules2_3_1);
  *reasonp++ =  a0;
  goto writeout__modules2_3_interrupt;
  };
  goto writeout__modules2_3_interrupt;
 writeout__modules2_3_ext_interrupt:
  reasonp = 0l;
 writeout__modules2_3_interrupt:
  toppred = &predicate_file__op_xwriteout__modules2_3;
  goto interrupt_3;
 }

 writeout__clauses_5_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 writeout__clauses_5_clear_reason:
  reasonp = reasons;
 writeout__clauses_5_0:
 writeout__clauses_5_1:
  if (!isint(a0)) goto writeout__clauses_5_5;
 writeout__clauses_5_2:
  if (!isint(a1)) goto writeout__clauses_5_4;
  gblt_less_or_eq(a0,a1,writeout__clauses_5_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xwriteout__clauses_5);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[9] = a0;
  allocp[10] = makeint(1L);
  allocp[11] = x0;
  allocp[12] = (q)(struct goalrec*)&allocp[7];
  allocp[13] = (q)(&predicate_file__op_xwriteout__clause_3);
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = a3;
  allocp[16] = x1;
  allocp[17] = (q)(struct goalrec*)&allocp[12];
  allocp[18] = (q)(&predicate_functor__table_xarg_3);
  allocp[19] = a0;
  allocp[20] = a2;
  allocp[21] = x2;
  qp = (struct goalrec*)&allocp[17];
  allocp += 22;
  proceed();
 writeout__clauses_5_3:
  gblt_greater(a0,a1,writeout__clauses_5_interrupt);
  unify(a4, a3);
  proceed();
 writeout__clauses_5_4:
  if (!isref(a1)) goto writeout__clauses_5_interrupt;
  deref_and_jump(a1,writeout__clauses_5_2);
  *reasonp++ =  a1;
  goto writeout__clauses_5_interrupt;
 writeout__clauses_5_5:
  if (!isref(a0)) goto writeout__clauses_5_interrupt;
  deref_and_jump(a0,writeout__clauses_5_1);
  *reasonp++ =  a0;
  goto writeout__clauses_5_interrupt;
 writeout__clauses_5_ext_interrupt:
  reasonp = 0l;
 writeout__clauses_5_interrupt:
  goto interrupt_5;
 }

 writeout__clause_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13;
  a2 = qp->args[2];
  qp = qp->next;
 writeout__clause_3_clear_reason:
  reasonp = reasons;
 writeout__clause_3_0:
 writeout__clause_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto writeout__clause_3_interrupt;
 writeout__clause_3_2:
  gblt_atom(a0,writeout__clause_3_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xwrite__word_3);
  allocp[2] = a0;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a2;
  a0 = makesym(atom_atom);
  a2 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(write__word_3_0);
  goto write__word_3_ext_interrupt;
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_clause_4)) goto writeout__clause_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xwrite__word_3);
  x0 = arg(a0, 3);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_file__op_xwriteout__goals_5);
  allocp[7] = makeint(1L);
  allocp[8] = x2 = makeref(&allocp[8]);
  x3 = arg(a0, 2);
  allocp[9] = x3;
  allocp[10] = x4 = makeref(&allocp[10]);
  allocp[11] = x1;
  allocp[12] = (q)(struct goalrec*)&allocp[5];
  allocp[13] = (q)(&predicate_file__op_xwrite__word_3);
  allocp[14] = x2;
  allocp[15] = x5 = makeref(&allocp[15]);
  allocp[16] = x4;
  allocp[17] = (q)(struct goalrec*)&allocp[12];
  allocp[18] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[19] = x3;
  allocp[20] = x6 = makeref(&allocp[20]);
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[17];
  allocp[23] = (q)(&predicate_file__op_xwriteout__goals_5);
  allocp[24] = makeint(1L);
  allocp[25] = x7 = makeref(&allocp[25]);
  x8 = arg(a0, 1);
  allocp[26] = x8;
  allocp[27] = x9 = makeref(&allocp[27]);
  allocp[28] = x5;
  allocp[29] = (q)(struct goalrec*)&allocp[22];
  allocp[30] = (q)(&predicate_file__op_xwrite__word_3);
  allocp[31] = x7;
  allocp[32] = x10 = makeref(&allocp[32]);
  allocp[33] = x9;
  allocp[34] = (q)(struct goalrec*)&allocp[29];
  allocp[35] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[36] = x8;
  allocp[37] = x11 = makeref(&allocp[37]);
  allocp[38] = x7;
  allocp[39] = (q)(struct goalrec*)&allocp[34];
  allocp[40] = (q)(&predicate_file__op_xwrite__word_3);
  x12 = arg(a0, 0);
  allocp[41] = x12;
  allocp[42] = x13 = makeref(&allocp[42]);
  allocp[43] = x10;
  a0 = makesym(atom_clause);
  a2 = x13;
  qp = (struct goalrec*)&allocp[39];
  allocp += 44;
  execute(write__word_3_0);
  goto write__word_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,writeout__clause_3_1);
  *reasonp++ =  a0;
  goto writeout__clause_3_interrupt;
  };
  goto writeout__clause_3_interrupt;
 writeout__clause_3_ext_interrupt:
  reasonp = 0l;
 writeout__clause_3_interrupt:
  goto interrupt_3;
 }

 writeout__goals_5_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 writeout__goals_5_clear_reason:
  reasonp = reasons;
 writeout__goals_5_0:
 writeout__goals_5_1:
  if (!isint(a0)) goto writeout__goals_5_5;
 writeout__goals_5_2:
  if (!isint(a1)) goto writeout__goals_5_4;
  gblt_less_or_eq(a0,a1,writeout__goals_5_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xwriteout__goals_5);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[9] = a0;
  allocp[10] = makeint(1L);
  allocp[11] = x0;
  allocp[12] = (q)(struct goalrec*)&allocp[7];
  allocp[13] = (q)(&predicate_file__op_xwrite__word_3);
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = a3;
  allocp[16] = x1;
  allocp[17] = (q)(struct goalrec*)&allocp[12];
  allocp[18] = (q)(&predicate_functor__table_xarg_3);
  allocp[19] = a0;
  allocp[20] = a2;
  allocp[21] = x2;
  qp = (struct goalrec*)&allocp[17];
  allocp += 22;
  proceed();
 writeout__goals_5_3:
  gblt_greater(a0,a1,writeout__goals_5_interrupt);
  unify(a4, a3);
  proceed();
 writeout__goals_5_4:
  if (!isref(a1)) goto writeout__goals_5_interrupt;
  deref_and_jump(a1,writeout__goals_5_2);
  *reasonp++ =  a1;
  goto writeout__goals_5_interrupt;
 writeout__goals_5_5:
  if (!isref(a0)) goto writeout__goals_5_interrupt;
  deref_and_jump(a0,writeout__goals_5_1);
  *reasonp++ =  a0;
  goto writeout__goals_5_interrupt;
 writeout__goals_5_ext_interrupt:
  reasonp = 0l;
 writeout__goals_5_interrupt:
  goto interrupt_5;
 }

 readin__modules_3_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  qp = qp->next;
 readin__modules_3_clear_reason:
  reasonp = reasons;
 readin__modules_3_0:
  allocp[0] = makesym(functor_normal_2);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  x0 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a0, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xread__word_3);
  allocp[2] = x2;
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_file__op_xreadin__modules_4);
  allocp[7] = x4 = makeref(&allocp[7]);
  allocp[8] = x1;
  allocp[9] = x5 = makeref(&allocp[9]);
  allocp[10] = x3;
  a0 = x4;
  a2 = x5;
  qp = (struct goalrec*)&allocp[5];
  allocp += 11;
  execute(read__word_3_0);
  goto read__word_3_ext_interrupt;
 readin__modules_3_ext_interrupt:
  reasonp = 0l;
 readin__modules_3_interrupt:
  goto interrupt_3;
 }

 readin__modules_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 readin__modules_4_clear_reason:
  reasonp = reasons;
 readin__modules_4_0:
 readin__modules_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_end__of__modules)) goto readin__modules_4_2;
  unify(a3, a2);
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,readin__modules_4_1);
  *reasonp++ =  a0;
  goto readin__modules_4_2;
  };
  goto readin__modules_4_2;
 readin__modules_4_2:
  otherwise(readin__modules_4_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xreadin__modules_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_file__op_xread__word_3);
  allocp[8] = x0;
  allocp[9] = x3 = makeref(&allocp[9]);
  allocp[10] = x2;
  allocp[11] = makesym(functor_module_2);
  allocp[12] = a0;
  allocp[13] = x5 = makeref(&allocp[13]);
  x4 = makefunctor(&allocp[11]);
  allocp[14] = x1;
  allocp[15] = x4;
  x6 = makecons(&allocp[14]);
  qp = (struct goalrec*)&allocp[6];
  allocp += 16;
  unify_value(a1, x6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xreadin__clauses_6);
  allocp[2] = makeint(1L);
  allocp[3] = x7 = makeref(&allocp[3]);
  allocp[4] = makesym(atom_clauses);
  allocp[5] = x5;
  allocp[6] = x8 = makeref(&allocp[6]);
  allocp[7] = x3;
  a0 = x7;
  a1 = a2;
  a2 = x8;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  execute(read__word_3_0);
  goto read__word_3_ext_interrupt;
 readin__modules_4_ext_interrupt:
  reasonp = 0l;
 readin__modules_4_interrupt:
  goto interrupt_4;
 }

 readin__clauses_6_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 readin__clauses_6_clear_reason:
  reasonp = reasons;
 readin__clauses_6_0:
 readin__clauses_6_1:
  if (!isint(a0)) goto readin__clauses_6_5;
 readin__clauses_6_2:
  if (!isint(a1)) goto readin__clauses_6_4;
  gblt_less_or_eq(a0,a1,readin__clauses_6_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xreadin__clauses_6);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[10] = a0;
  allocp[11] = makeint(1L);
  allocp[12] = x0;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_functor_xinsert__arg_4);
  allocp[15] = a0;
  allocp[16] = a2;
  allocp[17] = x3 = makeref(&allocp[17]);
  allocp[18] = x1;
  allocp[19] = (q)(struct goalrec*)&allocp[13];
  allocp[20] = (q)(&predicate_file__op_xreadin__clause_4);
  allocp[21] = x4 = makeref(&allocp[21]);
  allocp[22] = x3;
  allocp[23] = x5 = makeref(&allocp[23]);
  allocp[24] = x2;
  a0 = x4;
  a1 = a4;
  a2 = x5;
  qp = (struct goalrec*)&allocp[19];
  allocp += 25;
  execute(read__word_3_0);
  goto read__word_3_ext_interrupt;
 readin__clauses_6_3:
  gblt_greater(a0,a1,readin__clauses_6_interrupt);
  unify2(a5, a4, a3, a2);
  proceed();
 readin__clauses_6_4:
  if (!isref(a1)) goto readin__clauses_6_interrupt;
  deref_and_jump(a1,readin__clauses_6_2);
  *reasonp++ =  a1;
  goto readin__clauses_6_interrupt;
 readin__clauses_6_5:
  if (!isref(a0)) goto readin__clauses_6_interrupt;
  deref_and_jump(a0,readin__clauses_6_1);
  *reasonp++ =  a0;
  goto readin__clauses_6_interrupt;
 readin__clauses_6_ext_interrupt:
  reasonp = 0l;
 readin__clauses_6_interrupt:
  goto interrupt_6;
 }

 readin__clause_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 readin__clause_4_clear_reason:
  reasonp = reasons;
 readin__clause_4_0:
 readin__clause_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto readin__clause_4_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_clause)):
  allocp[0] = makesym(functor_clause_4);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  x0 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xread__word_3);
  allocp[2] = x4;
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = a3;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_file__op_xreadin__goals_6);
  allocp[7] = makeint(1L);
  allocp[8] = x6 = makeref(&allocp[8]);
  allocp[9] = makesym(atom_bodys);
  allocp[10] = x3;
  allocp[11] = x7 = makeref(&allocp[11]);
  allocp[12] = x5;
  allocp[13] = (q)(struct goalrec*)&allocp[5];
  allocp[14] = (q)(&predicate_file__op_xread__word_3);
  allocp[15] = x6;
  allocp[16] = x8 = makeref(&allocp[16]);
  allocp[17] = x7;
  allocp[18] = (q)(struct goalrec*)&allocp[13];
  allocp[19] = (q)(&predicate_file__op_xreadin__goals_6);
  allocp[20] = makeint(1L);
  allocp[21] = x9 = makeref(&allocp[21]);
  allocp[22] = makesym(atom_guards);
  allocp[23] = x2;
  allocp[24] = x10 = makeref(&allocp[24]);
  allocp[25] = x8;
  allocp[26] = (q)(struct goalrec*)&allocp[18];
  allocp[27] = (q)(&predicate_file__op_xread__word_3);
  allocp[28] = x9;
  allocp[29] = x11 = makeref(&allocp[29]);
  allocp[30] = x10;
  a0 = x1;
  a1 = a2;
  a2 = x11;
  qp = (struct goalrec*)&allocp[26];
  allocp += 31;
  execute(read__word_3_0);
  goto read__word_3_ext_interrupt;
 case symval(makesym(atom_atom)):
  a0 = a1;
  a1 = a2;
  a2 = a3;
  execute(read__word_3_0);
  goto read__word_3_ext_interrupt;
  };
  goto readin__clause_4_interrupt;
 case VARREF:
  deref_and_jump(a0,readin__clause_4_1);
  *reasonp++ =  a0;
  goto readin__clause_4_interrupt;
  };
  goto readin__clause_4_interrupt;
 readin__clause_4_ext_interrupt:
  reasonp = 0l;
 readin__clause_4_interrupt:
  goto interrupt_4;
 }

 readin__goals_6_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 readin__goals_6_clear_reason:
  reasonp = reasons;
 readin__goals_6_0:
 readin__goals_6_1:
  if (!isint(a0)) goto readin__goals_6_5;
 readin__goals_6_2:
  if (!isint(a1)) goto readin__goals_6_4;
  gblt_less_or_eq(a0,a1,readin__goals_6_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xreadin__goals_6);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[10] = a0;
  allocp[11] = makeint(1L);
  allocp[12] = x0;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_functor_xinsert__arg_4);
  allocp[15] = a0;
  allocp[16] = a2;
  allocp[17] = x3 = makeref(&allocp[17]);
  allocp[18] = x1;
  a0 = x3;
  a1 = a4;
  a2 = x2;
  qp = (struct goalrec*)&allocp[13];
  allocp += 19;
  execute(read__word_3_0);
  goto read__word_3_ext_interrupt;
 readin__goals_6_3:
  gblt_greater(a0,a1,readin__goals_6_interrupt);
  unify2(a5, a4, a3, a2);
  proceed();
 readin__goals_6_4:
  if (!isref(a1)) goto readin__goals_6_interrupt;
  deref_and_jump(a1,readin__goals_6_2);
  *reasonp++ =  a1;
  goto readin__goals_6_interrupt;
 readin__goals_6_5:
  if (!isref(a0)) goto readin__goals_6_interrupt;
  deref_and_jump(a0,readin__goals_6_1);
  *reasonp++ =  a0;
  goto readin__goals_6_interrupt;
 readin__goals_6_ext_interrupt:
  reasonp = 0l;
 readin__goals_6_interrupt:
  goto interrupt_6;
 }

 writeout__adg_3_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  qp = qp->next;
 writeout__adg_3_clear_reason:
  reasonp = reasons;
 writeout__adg_3_0:
 writeout__adg_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 writeout__adg_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto writeout__adg_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xwriteout__adg_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_file__op_xwrite__adg__entry_3);
  x3 = arg(x0, 1);
  allocp[7] = x3;
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = x2;
  a0 = arg(x0, 0);
  a2 = x4;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  execute(write__word_3_0);
  goto write__word_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,writeout__adg_3_2);
  *reasonp++ =  x0;
  goto writeout__adg_3_interrupt;
  };
  goto writeout__adg_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto writeout__adg_3_interrupt;
  a0 = makesym(atom_end__of__adg);
  execute(write__word_3_0);
  goto write__word_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,writeout__adg_3_1);
  *reasonp++ =  a0;
  goto writeout__adg_3_interrupt;
  };
  goto writeout__adg_3_interrupt;
 writeout__adg_3_ext_interrupt:
  reasonp = 0l;
 writeout__adg_3_interrupt:
  goto interrupt_3;
 }

 write__adg__entry_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18;
  a2 = qp->args[2];
  qp = qp->next;
 write__adg__entry_3_clear_reason:
  reasonp = reasons;
 write__adg__entry_3_0:
 write__adg__entry_3_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = makesym(functor_entry_8);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = x5 = makeref(&allocp[5]);
  allocp[6] = x6 = makeref(&allocp[6]);
  allocp[7] = x7 = makeref(&allocp[7]);
  allocp[8] = x8 = makeref(&allocp[8]);
  x0 = makefunctor(&allocp[0]);
  x9 = car_of(a0);
  allocp += 9;
  unify_value(x9, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xwrite__adg__entry_3);
  x10 = cdr_of(a0);
  allocp[2] = x10;
  allocp[3] = x11 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_file__op_xwrite__word_3);
  allocp[7] = x8;
  allocp[8] = x12 = makeref(&allocp[8]);
  allocp[9] = x11;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_file__op_xwrite__word_3);
  allocp[12] = x7;
  allocp[13] = x13 = makeref(&allocp[13]);
  allocp[14] = x12;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_file__op_xwrite__word_3);
  allocp[17] = x6;
  allocp[18] = x14 = makeref(&allocp[18]);
  allocp[19] = x13;
  allocp[20] = (q)(struct goalrec*)&allocp[15];
  allocp[21] = (q)(&predicate_file__op_xwrite__word_3);
  allocp[22] = x5;
  allocp[23] = x15 = makeref(&allocp[23]);
  allocp[24] = x14;
  allocp[25] = (q)(struct goalrec*)&allocp[20];
  allocp[26] = (q)(&predicate_file__op_xwrite__word_3);
  allocp[27] = x4;
  allocp[28] = x16 = makeref(&allocp[28]);
  allocp[29] = x15;
  allocp[30] = (q)(struct goalrec*)&allocp[25];
  allocp[31] = (q)(&predicate_file__op_xwrite__word_3);
  allocp[32] = x3;
  allocp[33] = x17 = makeref(&allocp[33]);
  allocp[34] = x16;
  allocp[35] = (q)(struct goalrec*)&allocp[30];
  allocp[36] = (q)(&predicate_file__op_xwrite__word_3);
  allocp[37] = x2;
  allocp[38] = x18 = makeref(&allocp[38]);
  allocp[39] = x17;
  a0 = x1;
  a2 = x18;
  qp = (struct goalrec*)&allocp[35];
  allocp += 40;
  execute(write__word_3_0);
  goto write__word_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto write__adg__entry_3_interrupt;
  a0 = makesym(atom_end__of__adg__entry);
  execute(write__word_3_0);
  goto write__word_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,write__adg__entry_3_1);
  *reasonp++ =  a0;
  goto write__adg__entry_3_interrupt;
  };
  goto write__adg__entry_3_interrupt;
 write__adg__entry_3_ext_interrupt:
  reasonp = 0l;
 write__adg__entry_3_interrupt:
  goto interrupt_3;
 }

 readin__adg_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 readin__adg_3_clear_reason:
  reasonp = reasons;
 readin__adg_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xreadin__adg_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a2;
  a0 = x0;
  a2 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(read__word_3_0);
  goto read__word_3_ext_interrupt;
 readin__adg_3_ext_interrupt:
  reasonp = 0l;
 readin__adg_3_interrupt:
  goto interrupt_3;
 }

 readin__adg_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 readin__adg_4_clear_reason:
  reasonp = reasons;
 readin__adg_4_0:
 readin__adg_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_end__of__adg)) goto readin__adg_4_2;
  unify(a3, a2);
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,readin__adg_4_1);
  *reasonp++ =  a0;
  goto readin__adg_4_2;
  };
  goto readin__adg_4_2;
 readin__adg_4_2:
  otherwise(readin__adg_4_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xreadin__adg_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_file__op_xread__word_3);
  allocp[8] = x0;
  allocp[9] = x3 = makeref(&allocp[9]);
  allocp[10] = x2;
  allocp[11] = makesym(functor_module_2);
  allocp[12] = a0;
  allocp[13] = x5 = makeref(&allocp[13]);
  x4 = makefunctor(&allocp[11]);
  allocp[14] = x1;
  allocp[15] = x4;
  x6 = makecons(&allocp[14]);
  qp = (struct goalrec*)&allocp[6];
  allocp += 16;
  unify_value(a1, x6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xread__adg__entry_4);
  allocp[2] = x7 = makeref(&allocp[2]);
  allocp[3] = x5;
  allocp[4] = x8 = makeref(&allocp[4]);
  allocp[5] = x3;
  a0 = x7;
  a1 = a2;
  a2 = x8;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(read__word_3_0);
  goto read__word_3_ext_interrupt;
 readin__adg_4_ext_interrupt:
  reasonp = 0l;
 readin__adg_4_interrupt:
  goto interrupt_4;
 }

 read__adg__entry_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 read__adg__entry_4_clear_reason:
  reasonp = reasons;
 read__adg__entry_4_0:
 read__adg__entry_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_end__of__adg__entry)) goto read__adg__entry_4_2;
  unify(a3, a2);
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,read__adg__entry_4_1);
  *reasonp++ =  a0;
  goto read__adg__entry_4_2;
  };
  goto read__adg__entry_4_2;
 read__adg__entry_4_2:
  otherwise(read__adg__entry_4_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xread__adg__entry_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_file__op_xread__word_3);
  allocp[8] = x0;
  allocp[9] = x3 = makeref(&allocp[9]);
  allocp[10] = x2;
  allocp[11] = makesym(functor_entry_8);
  allocp[12] = a0;
  allocp[13] = x5 = makeref(&allocp[13]);
  allocp[14] = x6 = makeref(&allocp[14]);
  allocp[15] = x7 = makeref(&allocp[15]);
  allocp[16] = x8 = makeref(&allocp[16]);
  allocp[17] = x9 = makeref(&allocp[17]);
  allocp[18] = x10 = makeref(&allocp[18]);
  allocp[19] = x11 = makeref(&allocp[19]);
  x4 = makefunctor(&allocp[11]);
  allocp[20] = x1;
  allocp[21] = x4;
  x12 = makecons(&allocp[20]);
  qp = (struct goalrec*)&allocp[6];
  allocp += 22;
  unify_value(a1, x12);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_file__op_xread__word_3);
  allocp[2] = x11;
  allocp[3] = x13 = makeref(&allocp[3]);
  allocp[4] = x3;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_file__op_xread__word_3);
  allocp[7] = x10;
  allocp[8] = x14 = makeref(&allocp[8]);
  allocp[9] = x13;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_file__op_xread__word_3);
  allocp[12] = x9;
  allocp[13] = x15 = makeref(&allocp[13]);
  allocp[14] = x14;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_file__op_xread__word_3);
  allocp[17] = x8;
  allocp[18] = x16 = makeref(&allocp[18]);
  allocp[19] = x15;
  allocp[20] = (q)(struct goalrec*)&allocp[15];
  allocp[21] = (q)(&predicate_file__op_xread__word_3);
  allocp[22] = x7;
  allocp[23] = x17 = makeref(&allocp[23]);
  allocp[24] = x16;
  allocp[25] = (q)(struct goalrec*)&allocp[20];
  allocp[26] = (q)(&predicate_file__op_xread__word_3);
  allocp[27] = x6;
  allocp[28] = x18 = makeref(&allocp[28]);
  allocp[29] = x17;
  a0 = x5;
  a1 = a2;
  a2 = x18;
  qp = (struct goalrec*)&allocp[25];
  allocp += 30;
  execute(read__word_3_0);
  goto read__word_3_ext_interrupt;
 read__adg__entry_4_ext_interrupt:
  reasonp = 0l;
 read__adg__entry_4_interrupt:
  goto interrupt_4;
 }
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_file__op);
}
