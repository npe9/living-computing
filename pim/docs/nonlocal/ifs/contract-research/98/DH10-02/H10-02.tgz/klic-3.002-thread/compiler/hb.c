/* Compiled by KLIC compiler version 3.002 (Wed Sep 17 15:37:13 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_hb();
Const struct predicate predicate_hb_xmake_2 =
   { module_hb, 0, 2 };
Const struct predicate predicate_hb_xmake__extern_3 =
   { module_hb, 1, 3 };
Const struct predicate predicate_hb_xmake__extern__clauses_5 =
   { module_hb, 2, 5 };
Const struct predicate predicate_hb_xmake__extern__clause_5 =
   { module_hb, 3, 5 };
Const struct predicate predicate_hb_xmake__extern__goals_7 =
   { module_hb, 4, 7 };
Const struct predicate predicate_hb_xmake__extern__goal_9 =
   { module_hb, 5, 9 };
Const struct predicate predicate_hb_xinsert_6 =
   { module_hb, 6, 6 };
Const struct predicate predicate_hb_xinsert__preds_6 =
   { module_hb, 7, 6 };
Const struct predicate predicate_hb_xinsert__pred_5 =
   { module_hb, 8, 5 };
Const struct predicate predicate_hb_xinsert__args_4 =
   { module_hb, 9, 4 };
Const struct predicate predicate_hb_xmake__entries_5 =
   { module_hb, 10, 5 };
Const struct predicate predicate_hb_xmake__headargs_2 =
   { module_hb, 11, 2 };
Const struct predicate predicate_hb_xmake__clauses_5 =
   { module_hb, 12, 5 };
Const struct predicate predicate_hb_xmake__headlist_9 =
   { module_hb, 13, 9 };
Const struct predicate predicate_hb_xmake__args_7 =
   { module_hb, 14, 7 };
Const struct predicate predicate_hb_xmake__bodyargs_3 =
   { module_hb, 15, 3 };
Const struct predicate predicate_hb_xcheck__clauses_4 =
   { module_hb, 16, 4 };
Const struct predicate predicate_hb_xsearch__modules_6 =
   { module_hb, 17, 6 };
Const struct predicate predicate_hb_xsearch__clauses_9 =
   { module_hb, 18, 9 };
Const struct predicate predicate_hb_xsearch__bodys_10 =
   { module_hb, 19, 10 };
Const struct predicate predicate_hb_xsearch__body_10 =
   { module_hb, 20, 10 };
Const struct predicate predicate_hb_xsearch__body1_11 =
   { module_hb, 21, 11 };
Const struct predicate predicate_hb_xcheck__args_9 =
   { module_hb, 22, 9 };
Const struct predicate predicate_hb_xget__typeset_12 =
   { module_hb, 23, 12 };
Const struct predicate predicate_hb_xget__namelist_13 =
   { module_hb, 24, 13 };
Const struct predicate predicate_hb_xget__bodylist_9 =
   { module_hb, 25, 9 };
Const struct predicate predicate_hb_xexpand__loopgoal_8 =
   { module_hb, 26, 8 };
Const struct predicate predicate_hb_xget__headlist_9 =
   { module_hb, 27, 9 };
Const struct predicate predicate_hb_xcheck__shared_4 =
   { module_hb, 28, 4 };
Const struct predicate predicate_hb_xcheck__hb_4 =
   { module_hb, 29, 4 };
Const struct predicate predicate_hb_xcheck__shared__bodys_6 =
   { module_hb, 30, 6 };
Const struct predicate predicate_hb_xcheck__shared__bodys1_7 =
   { module_hb, 31, 7 };
Const struct predicate predicate_hb_xcheck__shared__bodys2_7 =
   { module_hb, 32, 7 };
Const struct predicate predicate_hb_xcheck__shared__bodys3_5 =
   { module_hb, 33, 5 };
Const struct predicate predicate_hb_xcheck__shared__bodys4_6 =
   { module_hb, 34, 6 };
Const struct predicate predicate_hb_xcheck__headargs_3 =
   { module_hb, 35, 3 };
Const struct predicate predicate_hb_xcheck__headargs_4 =
   { module_hb, 36, 4 };
Const struct predicate predicate_hb_xadd__shared_7 =
   { module_hb, 37, 7 };
Const struct predicate predicate_hb_xadd__entry_7 =
   { module_hb, 38, 7 };
Const struct predicate predicate_hb_xread__mode_6 =
   { module_hb, 39, 6 };
Const struct predicate predicate_hb_xread__mode__preds_5 =
   { module_hb, 40, 5 };
Const struct predicate predicate_hb_xwrite__mode_7 =
   { module_hb, 41, 7 };
Const struct predicate predicate_hb_xwrite__mode__preds_6 =
   { module_hb, 42, 6 };
Const struct predicate predicate_hb_xor__typeset_9 =
   { module_hb, 43, 9 };
Const struct predicate predicate_hb_xor__typeset1_9 =
   { module_hb, 44, 9 };
Const struct predicate predicate_hb_xor__typeset2_12 =
   { module_hb, 45, 12 };
Const struct predicate predicate_hb_xget__info_9 =
   { module_hb, 46, 9 };
Const struct predicate predicate_hb_xget__info__preds_9 =
   { module_hb, 47, 9 };
Const struct predicate predicate_hb_xget__info__preds2_10 =
   { module_hb, 48, 10 };
Const struct predicate predicate_hb_xget__info__args_10 =
   { module_hb, 49, 10 };
Const struct predicate predicate_hb_xget__info__args2_11 =
   { module_hb, 50, 11 };
Const struct predicate predicate_hb_xget__info__entry_10 =
   { module_hb, 51, 10 };
Const struct predicate predicate_hb_xget__info__entry2_14 =
   { module_hb, 52, 14 };
Const struct predicate predicate_hb_xget__info__term_4 =
   { module_hb, 53, 4 };
Const struct predicate predicate_hb_xget__info__func_5 =
   { module_hb, 54, 5 };
Const struct predicate predicate_hb_xget__info__func2_6 =
   { module_hb, 55, 6 };
Const struct predicate predicate_hb_xwrite__io_7 =
   { module_hb, 56, 7 };
Const struct predicate predicate_hb_xwrite__io__preds_6 =
   { module_hb, 57, 6 };
Const struct predicate predicate_hb_xmake__io_3 =
   { module_hb, 58, 3 };
Const struct predicate predicate_hb_xmake__io__preds_3 =
   { module_hb, 59, 3 };
Const struct predicate predicate_hb_xmake__io__graph_7 =
   { module_hb, 60, 7 };
Const struct predicate predicate_hb_xmake__io__graphs_7 =
   { module_hb, 61, 7 };
Const struct predicate predicate_hb_xget__arg_5 =
   { module_hb, 62, 5 };
Const struct predicate predicate_hb_xmake__io__graph2_5 =
   { module_hb, 63, 5 };
Const struct predicate predicate_hb_xmake__io__graph3_8 =
   { module_hb, 64, 8 };
Const struct predicate predicate_hb_xmake__io__struct_10 =
   { module_hb, 65, 10 };
Const struct predicate predicate_hb_xmake__io__func_11 =
   { module_hb, 66, 11 };
Const struct predicate predicate_hb_xmake__io__struct2_9 =
   { module_hb, 67, 9 };
Const struct predicate predicate_hb_xmake__io__args_10 =
   { module_hb, 68, 10 };
Const struct predicate predicate_hb_xmake__io__arg_9 =
   { module_hb, 69, 9 };
Const struct predicate predicate_hb_xmake__io__struct3_11 =
   { module_hb, 70, 11 };
Const struct predicate predicate_hb_xmake__io__arg2_6 =
   { module_hb, 71, 6 };
Const struct predicate predicate_hb_xget__pred_5 =
   { module_hb, 72, 5 };
Const struct predicate predicate_hb_xget__pred1_4 =
   { module_hb, 73, 4 };
Const struct predicate predicate_hb_xget__modes_5 =
   { module_hb, 74, 5 };
Const struct predicate predicate_hb_xget__modes1_4 =
   { module_hb, 75, 4 };
Const struct predicate predicate_hb_xget__hio_5 =
   { module_hb, 76, 5 };
Const struct predicate predicate_hb_xget__hio1_4 =
   { module_hb, 77, 4 };
Const struct predicate predicate_hb_xget__bio_5 =
   { module_hb, 78, 5 };
Const struct predicate predicate_hb_xget__bio1_4 =
   { module_hb, 79, 4 };
Const struct predicate predicate_hb_xget__gids_6 =
   { module_hb, 80, 6 };
Const struct predicate predicate_hb_xget__gids1_5 =
   { module_hb, 81, 5 };
Const struct predicate predicate_hb_xget__gids2_2 =
   { module_hb, 82, 2 };
Const struct predicate predicate_hb_xget__gids3_4 =
   { module_hb, 83, 4 };
Const struct predicate predicate_hb_xget__pnmax_6 =
   { module_hb, 84, 6 };
Const struct predicate predicate_hb_xget__pn_7 =
   { module_hb, 85, 7 };
Const struct predicate predicate_hb_xget__pn1_6 =
   { module_hb, 86, 6 };
Const struct predicate predicate_hb_xget__pn2_4 =
   { module_hb, 87, 4 };
Const struct predicate predicate_hb_xcheck__infile_6 =
   { module_hb, 88, 6 };
Const struct predicate predicate_hb_xcheck__infile__preds_5 =
   { module_hb, 89, 5 };
Const struct predicate predicate_hb_xcheck__infile__args_3 =
   { module_hb, 90, 3 };
Const struct predicate predicate_hb_xcheck__infile2_7 =
   { module_hb, 91, 7 };
extern Const struct predicate predicate_list_xcheck__include_3;
extern Const struct predicate predicate_list_xor__unique_3;
extern Const struct predicate predicate_functor_xnew__functor__init_4;
extern Const struct predicate predicate_functor_xinsert__arg_4;
extern Const struct predicate predicate_functor_xsearch__functorname_3;
extern Const struct predicate predicate_integer__arithmetics_xadd_3;
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_xsetarg_4;
extern Const struct predicate predicate_functor__table_xfunctor_3;
extern Const struct predicate predicate_functor__table_xnew__functor_3;
extern Const struct predicate predicate_parse__uty_xdecode__goalcall_6;
extern Const struct predicate predicate_parse__uty_xget__goal_6;
extern Const struct predicate predicate_parse__uty_xdecode__goal_3;
extern Const struct predicate predicate_parse__uty_xencode__goal_3;
extern Const struct predicate predicate_parse__uty_xupdate__goal_7;
extern Const struct predicate predicate_typeset_xget_5;
extern Const struct predicate predicate_typeset_xor__typeset_3;
extern Const struct predicate predicate_typeset_xvalue2typeset_5;
extern Const struct predicate predicate_typeset_xmake__shared__ts_8;
extern Const struct predicate predicate_typeset_xcheck__dg_4;

module module_hb(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  static Const q cons_const_0[] = {
    NILATOM,
    makesym(atom__2A),
  };
  static Const q funct_const_1[] = {
    makesym(functor_atom_1),
    makesym(atom_entry),
  };
  static Const q funct_const_2[] = {
    makesym(functor_atom_1),
    makesym(atom_shared),
  };
  q a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, make_2_top);
    case_pred(1, make__extern_3_top);
    case_pred(2, make__extern__clauses_5_top);
    case_pred(3, make__extern__clause_5_top);
    case_pred(4, make__extern__goals_7_top);
    case_pred(5, make__extern__goal_9_top);
    case_pred(6, insert_6_top);
    case_pred(7, insert__preds_6_top);
    case_pred(8, insert__pred_5_top);
    case_pred(9, insert__args_4_top);
    case_pred(10, make__entries_5_top);
    case_pred(11, make__headargs_2_top);
    case_pred(12, make__clauses_5_top);
    case_pred(13, make__headlist_9_top);
    case_pred(14, make__args_7_top);
    case_pred(15, make__bodyargs_3_top);
    case_pred(16, check__clauses_4_top);
    case_pred(17, search__modules_6_top);
    case_pred(18, search__clauses_9_top);
    case_pred(19, search__bodys_10_top);
    case_pred(20, search__body_10_top);
    case_pred(21, search__body1_11_top);
    case_pred(22, check__args_9_top);
    case_pred(23, get__typeset_12_top);
    case_pred(24, get__namelist_13_top);
    case_pred(25, get__bodylist_9_top);
    case_pred(26, expand__loopgoal_8_top);
    case_pred(27, get__headlist_9_top);
    case_pred(28, check__shared_4_top);
    case_pred(29, check__hb_4_top);
    case_pred(30, check__shared__bodys_6_top);
    case_pred(31, check__shared__bodys1_7_top);
    case_pred(32, check__shared__bodys2_7_top);
    case_pred(33, check__shared__bodys3_5_top);
    case_pred(34, check__shared__bodys4_6_top);
    case_pred(35, check__headargs_3_top);
    case_pred(36, check__headargs_4_top);
    case_pred(37, add__shared_7_top);
    case_pred(38, add__entry_7_top);
    case_pred(39, read__mode_6_top);
    case_pred(40, read__mode__preds_5_top);
    case_pred(41, write__mode_7_top);
    case_pred(42, write__mode__preds_6_top);
    case_pred(43, or__typeset_9_top);
    case_pred(44, or__typeset1_9_top);
    case_pred(45, or__typeset2_12_top);
    case_pred(46, get__info_9_top);
    case_pred(47, get__info__preds_9_top);
    case_pred(48, get__info__preds2_10_top);
    case_pred(49, get__info__args_10_top);
    case_pred(50, get__info__args2_11_top);
    case_pred(51, get__info__entry_10_top);
    case_pred(52, get__info__entry2_14_top);
    case_pred(53, get__info__term_4_top);
    case_pred(54, get__info__func_5_top);
    case_pred(55, get__info__func2_6_top);
    case_pred(56, write__io_7_top);
    case_pred(57, write__io__preds_6_top);
    case_pred(58, make__io_3_top);
    case_pred(59, make__io__preds_3_top);
    case_pred(60, make__io__graph_7_top);
    case_pred(61, make__io__graphs_7_top);
    case_pred(62, get__arg_5_top);
    case_pred(63, make__io__graph2_5_top);
    case_pred(64, make__io__graph3_8_top);
    case_pred(65, make__io__struct_10_top);
    case_pred(66, make__io__func_11_top);
    case_pred(67, make__io__struct2_9_top);
    case_pred(68, make__io__args_10_top);
    case_pred(69, make__io__arg_9_top);
    case_pred(70, make__io__struct3_11_top);
    case_pred(71, make__io__arg2_6_top);
    case_pred(72, get__pred_5_top);
    case_pred(73, get__pred1_4_top);
    case_pred(74, get__modes_5_top);
    case_pred(75, get__modes1_4_top);
    case_pred(76, get__hio_5_top);
    case_pred(77, get__hio1_4_top);
    case_pred(78, get__bio_5_top);
    case_pred(79, get__bio1_4_top);
    case_pred(80, get__gids_6_top);
    case_pred(81, get__gids1_5_top);
    case_pred(82, get__gids2_2_top);
    case_pred(83, get__gids3_4_top);
    case_pred(84, get__pnmax_6_top);
    case_pred(85, get__pn_7_top);
    case_pred(86, get__pn1_6_top);
    case_pred(87, get__pn2_4_top);
    case_pred(88, check__infile_6_top);
    case_pred(89, check__infile__preds_5_top);
    case_pred(90, check__infile__args_3_top);
    last_case_pred(91, check__infile2_7_top);
  }

 make_2_top: {
  q x0;
  qp = qp->next;
 make_2_clear_reason:
  reasonp = reasons;
 make_2_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xmake__bodyargs_3);
  allocp[2] = a0;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a1;
  a1 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(make__headargs_2_0);
  goto make__headargs_2_ext_interrupt;
 make_2_ext_interrupt:
  reasonp = 0l;
 make_2_interrupt:
  goto interrupt_2;
 }

 make__extern_3_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  qp = qp->next;
 make__extern_3_clear_reason:
  reasonp = reasons;
 make__extern_3_0:
 make__extern_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 make__extern_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto make__extern_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xmake__extern_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_hb_xmake__extern__clauses_5);
  allocp[7] = x3 = makeref(&allocp[7]);
  x4 = arg(x0, 1);
  allocp[8] = x4;
  x5 = arg(x0, 0);
  allocp[9] = x5;
  allocp[10] = a1;
  allocp[11] = x2;
  allocp[12] = (q)(struct goalrec*)&allocp[5];
  allocp[13] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[14] = x4;
  allocp[15] = x6 = makeref(&allocp[15]);
  allocp[16] = x3;
  qp = (struct goalrec*)&allocp[12];
  allocp += 17;
  proceed();
 case VARREF:
  deref_and_jump(x0,make__extern_3_2);
  *reasonp++ =  x0;
  goto make__extern_3_interrupt;
  };
  goto make__extern_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto make__extern_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,make__extern_3_1);
  *reasonp++ =  a0;
  goto make__extern_3_interrupt;
  };
  goto make__extern_3_interrupt;
 make__extern_3_ext_interrupt:
  reasonp = 0l;
 make__extern_3_interrupt:
  goto interrupt_3;
 }

 make__extern__clauses_5_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 make__extern__clauses_5_clear_reason:
  reasonp = reasons;
 make__extern__clauses_5_0:
 make__extern__clauses_5_1:
  if (!isint(a0)) goto make__extern__clauses_5_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,make__extern__clauses_5_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xmake__extern__clauses_5);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[9] = a0;
  allocp[10] = makeint(1L);
  allocp[11] = x1;
  allocp[12] = (q)(struct goalrec*)&allocp[7];
  allocp[13] = (q)(&predicate_hb_xmake__extern__clause_5);
  allocp[14] = x3 = makeref(&allocp[14]);
  allocp[15] = a2;
  allocp[16] = a0;
  allocp[17] = a3;
  allocp[18] = x2;
  allocp[19] = (q)(struct goalrec*)&allocp[12];
  allocp[20] = (q)(&predicate_functor__table_xarg_3);
  allocp[21] = a0;
  allocp[22] = a1;
  allocp[23] = x3;
  qp = (struct goalrec*)&allocp[19];
  allocp += 24;
  proceed();
 make__extern__clauses_5_2:
  if (a0 != makeint(0L)) goto make__extern__clauses_5_interrupt;
  unify(a4, a3);
  proceed();
 make__extern__clauses_5_3:
  if (!isref(a0)) goto make__extern__clauses_5_interrupt;
  deref_and_jump(a0,make__extern__clauses_5_1);
  *reasonp++ =  a0;
  goto make__extern__clauses_5_interrupt;
 make__extern__clauses_5_ext_interrupt:
  reasonp = 0l;
 make__extern__clauses_5_interrupt:
  goto interrupt_5;
 }

 make__extern__clause_5_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 make__extern__clause_5_clear_reason:
  reasonp = reasons;
 make__extern__clause_5_0:
 make__extern__clause_5_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_clause_4)) goto make__extern__clause_5_2;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xmake__extern__goals_7);
  allocp[2] = x0 = makeref(&allocp[2]);
  x1 = arg(a0, 2);
  allocp[3] = x1;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = makesym(atom_body);
  allocp[7] = a3;
  allocp[8] = a4;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[11] = x1;
  allocp[12] = x2 = makeref(&allocp[12]);
  allocp[13] = x0;
  qp = (struct goalrec*)&allocp[9];
  allocp += 14;
  proceed();
 case VARREF:
  deref_and_jump(a0,make__extern__clause_5_1);
  *reasonp++ =  a0;
  goto make__extern__clause_5_2;
  };
  goto make__extern__clause_5_2;
 make__extern__clause_5_2:
  otherwise(make__extern__clause_5_interrupt);
  unify(a4, a3);
  proceed();
 make__extern__clause_5_ext_interrupt:
  reasonp = 0l;
 make__extern__clause_5_interrupt:
  goto interrupt_5;
 }

 make__extern__goals_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 make__extern__goals_7_clear_reason:
  reasonp = reasons;
 make__extern__goals_7_0:
 make__extern__goals_7_1:
  if (!isint(a0)) goto make__extern__goals_7_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,make__extern__goals_7_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xmake__extern__goals_7);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[11] = a0;
  allocp[12] = makeint(1L);
  allocp[13] = x1;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_hb_xmake__extern__goal_9);
  allocp[16] = x3 = makeref(&allocp[16]);
  allocp[17] = x4 = makeref(&allocp[17]);
  allocp[18] = a2;
  allocp[19] = x5 = makeref(&allocp[19]);
  allocp[20] = a3;
  allocp[21] = a4;
  allocp[22] = a0;
  allocp[23] = a5;
  allocp[24] = x2;
  allocp[25] = (q)(struct goalrec*)&allocp[14];
  allocp[26] = (q)(&predicate_parse__uty_xdecode__goalcall_6);
  allocp[27] = a2;
  allocp[28] = x5;
  allocp[29] = x6 = makeref(&allocp[29]);
  allocp[30] = x4;
  allocp[31] = x7 = makeref(&allocp[31]);
  allocp[32] = x3;
  allocp[33] = (q)(struct goalrec*)&allocp[25];
  allocp[34] = (q)(&predicate_functor__table_xarg_3);
  allocp[35] = a0;
  allocp[36] = a1;
  allocp[37] = x6;
  qp = (struct goalrec*)&allocp[33];
  allocp += 38;
  proceed();
 make__extern__goals_7_2:
  if (a0 != makeint(0L)) goto make__extern__goals_7_interrupt;
  unify(a6, a5);
  proceed();
 make__extern__goals_7_3:
  if (!isref(a0)) goto make__extern__goals_7_interrupt;
  deref_and_jump(a0,make__extern__goals_7_1);
  *reasonp++ =  a0;
  goto make__extern__goals_7_interrupt;
 make__extern__goals_7_ext_interrupt:
  reasonp = 0l;
 make__extern__goals_7_interrupt:
  goto interrupt_7;
 }

 make__extern__goal_9_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 make__extern__goal_9_clear_reason:
  reasonp = reasons;
 make__extern__goal_9_0:
 make__extern__goal_9_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto make__extern__goal_9_6;
  switch (symval(a0)) {
 case symval(makesym(atom_builtin)):
  unify(a8, a7);
  proceed();
 case symval(makesym(atom_userdef)):
 make__extern__goal_9_2:
  if (isref(a2)) goto make__extern__goal_9_5;
 make__extern__goal_9_3:
  if (isref(a2)) goto make__extern__goal_9_4;
  if_not_equal(a2, a3, make__extern__goal_9_6);
  unify(a8, a7);
  proceed();
 make__extern__goal_9_4:
  deref_and_jump(a2,make__extern__goal_9_3);
  *reasonp++ =  a2;
  goto make__extern__goal_9_6;
 make__extern__goal_9_5:
  deref_and_jump(a2,make__extern__goal_9_2);
  *reasonp++ =  a2;
  goto make__extern__goal_9_6;
  };
  goto make__extern__goal_9_6;
 case VARREF:
  deref_and_jump(a0,make__extern__goal_9_1);
  *reasonp++ =  a0;
  goto make__extern__goal_9_6;
  };
  goto make__extern__goal_9_6;
 make__extern__goal_9_6:
  otherwise(make__extern__goal_9_interrupt);
 make__extern__goal_9_7:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_userdef)) goto make__extern__goal_9_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xinsert_6);
  allocp[2] = a3;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a7;
  allocp[7] = a8;
  allocp[8] = makesym(functor_goal_4);
  allocp[9] = a2;
  allocp[10] = a4;
  allocp[11] = a5;
  allocp[12] = a6;
  x3 = makefunctor(&allocp[8]);
  allocp[13] = (q)(struct goalrec*)&allocp[0];
  allocp[14] = (q)(&predicate_hb_xmake__entries_5);
  allocp[15] = x1;
  allocp[16] = a1;
  allocp[17] = makesym(atom_bodyargs);
  allocp[18] = x3;
  allocp[19] = x2;
  allocp[20] = (q)(struct goalrec*)&allocp[13];
  allocp[21] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[22] = a1;
  allocp[23] = x0;
  allocp[24] = x1;
  qp = (struct goalrec*)&allocp[20];
  allocp += 25;
  proceed();
 case VARREF:
  deref_and_jump(a0,make__extern__goal_9_7);
  *reasonp++ =  a0;
  goto make__extern__goal_9_interrupt;
  };
  goto make__extern__goal_9_interrupt;
 make__extern__goal_9_ext_interrupt:
  reasonp = 0l;
 make__extern__goal_9_interrupt:
  goto interrupt_9;
 }

 insert_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 insert_6_clear_reason:
  reasonp = reasons;
 insert_6_0:
 insert_6_1:
  switch (ptagof(a4)) {
 case CONS:
  x0 = car_of(a4);
 insert_6_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto insert_6_7;
  x1 = arg(x0, 0);
 insert_6_3:
  if (isref(x1)) goto insert_6_6;
 insert_6_4:
  if (isref(x1)) goto insert_6_5;
  if_not_equal(x1, a0, insert_6_7);
  allocp[0] = makesym(functor_module_2);
  allocp[1] = a0;
  allocp[2] = x3 = makeref(&allocp[2]);
  x2 = makefunctor(&allocp[0]);
  x5 = cdr_of(a4);
  allocp[3] = x5;
  allocp[4] = x2;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a5, x4);
  x6 = arg(x0, 1);
  x7 = a0;
  x8 = a1;
  a4 = a2;
  a5 = a3;
  a3 = x8;
  a2 = x7;
  a1 = x3;
  a0 = x6;
  execute(insert__preds_6_clear_reason);
  goto insert__preds_6_ext_interrupt;
 insert_6_5:
  deref_and_jump(x1,insert_6_4);
  *reasonp++ =  x1;
  goto insert_6_7;
 insert_6_6:
  deref_and_jump(x1,insert_6_3);
  *reasonp++ =  x1;
  goto insert_6_7;
 case VARREF:
  deref_and_jump(x0,insert_6_2);
  *reasonp++ =  x0;
  goto insert_6_7;
  };
  goto insert_6_7;
 case VARREF:
  deref_and_jump(a4,insert_6_1);
  *reasonp++ =  a4;
  goto insert_6_7;
  };
  goto insert_6_7;
 insert_6_7:
  otherwise(insert_6_interrupt);
 insert_6_8:
  switch (ptagof(a4)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a4);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a5, x0);
  a4 = cdr_of(a4);
  a5 = x1;
  execute(insert_6_0);
  goto insert_6_ext_interrupt;
 case ATOMIC:
  if (a4 != NILATOM) goto insert_6_interrupt;
  allocp[0] = makesym(functor_module_2);
  allocp[1] = a0;
  allocp[2] = x1 = makeref(&allocp[2]);
  x0 = makefunctor(&allocp[0]);
  allocp[3] = a4;
  allocp[4] = x0;
  x2 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a5, x2);
  x3 = a0;
  x4 = a1;
  a4 = a2;
  a5 = a3;
  a3 = x4;
  a2 = x3;
  a1 = x1;
  a0 = NILATOM;
  execute(insert__preds_6_0);
  goto insert__preds_6_ext_interrupt;
 case VARREF:
  deref_and_jump(a4,insert_6_8);
  *reasonp++ =  a4;
  goto insert_6_interrupt;
  };
  goto insert_6_interrupt;
 insert_6_ext_interrupt:
  reasonp = 0l;
 insert_6_interrupt:
  goto interrupt_6;
 }

 insert__preds_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 insert__preds_6_clear_reason:
  reasonp = reasons;
 insert__preds_6_0:
 insert__preds_6_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != NILATOM) goto insert__preds_6_2;
  allocp[0] = makesym(functor_pred_7);
  allocp[1] = a3;
  allocp[2] = a4;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = NILATOM;
  allocp[7] = NILATOM;
  x0 = makefunctor(&allocp[0]);
  allocp[8] = NILATOM;
  allocp[9] = x0;
  x4 = makecons(&allocp[8]);
  allocp += 10;
  unify_value(a1, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor_xnew__functor__init_4);
  allocp[2] = makesym(atom_modes);
  allocp[3] = a4;
  allocp[4] = makesym(atom__3F);
  allocp[5] = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  unify(x3, a5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor_xnew__functor__init_4);
  allocp[2] = makesym(atom_headargs);
  allocp[3] = a4;
  allocp[4] = makesym(atom_entries);
  allocp[5] = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  proceed();
 case VARREF:
  deref_and_jump(a0,insert__preds_6_1);
  *reasonp++ =  a0;
  goto insert__preds_6_2;
  };
  goto insert__preds_6_2;
 insert__preds_6_2:
  otherwise(insert__preds_6_interrupt);
 insert__preds_6_3:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 insert__preds_6_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_7)) goto insert__preds_6_13;
  x1 = arg(x0, 0);
 insert__preds_6_5:
  if (isref(x1)) goto insert__preds_6_12;
 insert__preds_6_6:
  if (isref(x1)) goto insert__preds_6_11;
  if_not_equal(x1, a3, insert__preds_6_13);
  x2 = arg(x0, 1);
 insert__preds_6_7:
  if (isref(x2)) goto insert__preds_6_10;
 insert__preds_6_8:
  if (isref(x2)) goto insert__preds_6_9;
  if_not_equal(x2, a4, insert__preds_6_13);
  allocp[0] = makesym(functor_pred_7);
  allocp[1] = a3;
  allocp[2] = a4;
  x4 = arg(x0, 2);
  allocp[3] = x4;
  x5 = arg(x0, 3);
  allocp[4] = x5;
  allocp[5] = x6 = makeref(&allocp[5]);
  x7 = arg(x0, 5);
  allocp[6] = x7;
  x8 = arg(x0, 6);
  allocp[7] = x8;
  x3 = makefunctor(&allocp[0]);
  x10 = cdr_of(a0);
  allocp[8] = x10;
  allocp[9] = x3;
  x9 = makecons(&allocp[8]);
  allocp += 10;
  unify_value(a1, x9);
  a0 = a4;
  a1 = arg(x0, 3);
  a2 = arg(x0, 4);
  a3 = x6;
  a4 = a5;
  execute(insert__pred_5_clear_reason);
  goto insert__pred_5_ext_interrupt;
 insert__preds_6_9:
  deref_and_jump(x2,insert__preds_6_8);
  *reasonp++ =  x2;
  goto insert__preds_6_13;
 insert__preds_6_10:
  deref_and_jump(x2,insert__preds_6_7);
  *reasonp++ =  x2;
  goto insert__preds_6_13;
 insert__preds_6_11:
  deref_and_jump(x1,insert__preds_6_6);
  *reasonp++ =  x1;
  goto insert__preds_6_13;
 insert__preds_6_12:
  deref_and_jump(x1,insert__preds_6_5);
  *reasonp++ =  x1;
  goto insert__preds_6_13;
 case VARREF:
  deref_and_jump(x0,insert__preds_6_4);
  *reasonp++ =  x0;
  goto insert__preds_6_13;
  };
  goto insert__preds_6_13;
 case VARREF:
  deref_and_jump(a0,insert__preds_6_3);
  *reasonp++ =  a0;
  goto insert__preds_6_13;
  };
  goto insert__preds_6_13;
 insert__preds_6_13:
  otherwise(insert__preds_6_interrupt);
 insert__preds_6_14:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(insert__preds_6_0);
  goto insert__preds_6_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,insert__preds_6_14);
  *reasonp++ =  a0;
  goto insert__preds_6_interrupt;
  };
  goto insert__preds_6_interrupt;
 insert__preds_6_ext_interrupt:
  reasonp = 0l;
 insert__preds_6_interrupt:
  toppred = &predicate_hb_xinsert__preds_6;
  goto interrupt_6;
 }

 insert__pred_5_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 insert__pred_5_clear_reason:
  reasonp = reasons;
 insert__pred_5_0:
 insert__pred_5_1:
  if (isref(a1)) goto insert__pred_5_3;
  x1 = makeint(1L);
  gblt_arg(x1,a1,x0,insert__pred_5_4);
 insert__pred_5_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_entries)) goto insert__pred_5_4;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  execute(insert__args_4_0);
  goto insert__args_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,insert__pred_5_2);
  *reasonp++ =  x0;
  goto insert__pred_5_4;
  };
  goto insert__pred_5_4;
 insert__pred_5_3:
  deref_and_jump(a1,insert__pred_5_1);
  *reasonp++ =  a1;
  goto insert__pred_5_4;
 insert__pred_5_4:
  otherwise(insert__pred_5_interrupt);
  unify(a3, a2);
  proceed();
 insert__pred_5_ext_interrupt:
  reasonp = 0l;
 insert__pred_5_interrupt:
  toppred = &predicate_hb_xinsert__pred_5;
  goto interrupt_5;
 }

 insert__args_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 insert__args_4_clear_reason:
  reasonp = reasons;
 insert__args_4_0:
 insert__args_4_1:
  if (!isint(a0)) goto insert__args_4_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,insert__args_4_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xinsert__args_4);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x1;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[13] = a0;
  allocp[14] = a1;
  allocp[15] = x3 = makeref(&allocp[15]);
  allocp[16] = x2;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_functor_xinsert__arg_4);
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = x5 = makeref(&allocp[20]);
  allocp[21] = x6 = makeref(&allocp[21]);
  allocp[22] = x3;
  allocp[23] = (q)(struct goalrec*)&allocp[17];
  allocp[24] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[25] = x7 = makeref(&allocp[25]);
  allocp[26] = makeint(1L);
  allocp[27] = x4;
  allocp[28] = (q)(struct goalrec*)&allocp[23];
  allocp[29] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[30] = x5;
  allocp[31] = x8 = makeref(&allocp[31]);
  allocp[32] = x7;
  allocp[33] = makesym(functor_entries_1);
  allocp[34] = x6;
  x9 = makefunctor(&allocp[33]);
  allocp[35] = (q)(struct goalrec*)&allocp[28];
  allocp[36] = (q)(&predicate_functor__table_xarg_3);
  allocp[37] = a0;
  allocp[38] = a3;
  allocp[39] = x9;
  allocp[40] = (q)(struct goalrec*)&allocp[35];
  allocp[41] = (q)(&predicate_functor__table_xarg_3);
  allocp[42] = a0;
  allocp[43] = a1;
  allocp[44] = x5;
  qp = (struct goalrec*)&allocp[40];
  allocp += 45;
  proceed();
 insert__args_4_2:
  if (a0 != makeint(0L)) goto insert__args_4_interrupt;
  unify(a2, a1);
  proceed();
 insert__args_4_3:
  if (!isref(a0)) goto insert__args_4_interrupt;
  deref_and_jump(a0,insert__args_4_1);
  *reasonp++ =  a0;
  goto insert__args_4_interrupt;
 insert__args_4_ext_interrupt:
  reasonp = 0l;
 insert__args_4_interrupt:
  toppred = &predicate_hb_xinsert__args_4;
  goto interrupt_4;
 }

 make__entries_5_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 make__entries_5_clear_reason:
  reasonp = reasons;
 make__entries_5_0:
 make__entries_5_1:
  if (!isint(a0)) goto make__entries_5_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,make__entries_5_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xmake__entries_5);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[9] = a0;
  allocp[10] = makeint(1L);
  allocp[11] = x1;
  allocp[12] = makesym(functor_arg_2);
  allocp[13] = a3;
  allocp[14] = x4 = makeref(&allocp[14]);
  x3 = makefunctor(&allocp[12]);
  allocp[15] = makesym(functor_entries_1);
  allocp[16] = x3;
  x5 = makefunctor(&allocp[15]);
  allocp[17] = (q)(struct goalrec*)&allocp[7];
  allocp[18] = (q)(&predicate_functor_xinsert__arg_4);
  allocp[19] = makeint(1L);
  allocp[20] = a2;
  allocp[21] = x5;
  allocp[22] = x2;
  allocp[23] = (q)(struct goalrec*)&allocp[17];
  allocp[24] = (q)(&predicate_functor__table_xarg_3);
  allocp[25] = a0;
  allocp[26] = a1;
  allocp[27] = x4;
  qp = (struct goalrec*)&allocp[23];
  allocp += 28;
  proceed();
 make__entries_5_2:
  if (a0 != makeint(0L)) goto make__entries_5_interrupt;
  unify(a4, a2);
  proceed();
 make__entries_5_3:
  if (!isref(a0)) goto make__entries_5_interrupt;
  deref_and_jump(a0,make__entries_5_1);
  *reasonp++ =  a0;
  goto make__entries_5_interrupt;
 make__entries_5_ext_interrupt:
  reasonp = 0l;
 make__entries_5_interrupt:
  goto interrupt_5;
 }

 make__headargs_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  qp = qp->next;
 make__headargs_2_clear_reason:
  reasonp = reasons;
 make__headargs_2_0:
 make__headargs_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 make__headargs_2_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto make__headargs_2_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xmake__headargs_2);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = makesym(functor_module_2);
  x4 = arg(x0, 0);
  allocp[5] = x4;
  allocp[6] = x5 = makeref(&allocp[6]);
  x3 = makefunctor(&allocp[4]);
  allocp[7] = x2;
  allocp[8] = x3;
  x6 = makecons(&allocp[7]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 9;
  unify_value(a1, x6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xmake__clauses_5);
  allocp[2] = makeint(1L);
  allocp[3] = x7 = makeref(&allocp[3]);
  x8 = arg(x0, 0);
  allocp[4] = x8;
  x9 = arg(x0, 1);
  allocp[5] = x9;
  allocp[6] = x5;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[9] = x9;
  allocp[10] = x10 = makeref(&allocp[10]);
  allocp[11] = x7;
  qp = (struct goalrec*)&allocp[7];
  allocp += 12;
  proceed();
 case VARREF:
  deref_and_jump(x0,make__headargs_2_2);
  *reasonp++ =  x0;
  goto make__headargs_2_interrupt;
  };
  goto make__headargs_2_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto make__headargs_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,make__headargs_2_1);
  *reasonp++ =  a0;
  goto make__headargs_2_interrupt;
  };
  goto make__headargs_2_interrupt;
 make__headargs_2_ext_interrupt:
  reasonp = 0l;
 make__headargs_2_interrupt:
  toppred = &predicate_hb_xmake__headargs_2;
  goto interrupt_2;
 }

 make__clauses_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 make__clauses_5_clear_reason:
  reasonp = reasons;
 make__clauses_5_0:
 make__clauses_5_1:
  if (!isint(a0)) goto make__clauses_5_8;
 make__clauses_5_2:
  if (!isint(a1)) goto make__clauses_5_7;
  gblt_less_or_eq(a0,a1,make__clauses_5_interrupt);
 make__clauses_5_3:
  if (isref(a3)) goto make__clauses_5_6;
  gblt_arg(a0,a3,x0,make__clauses_5_interrupt);
 make__clauses_5_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_clause_4)) goto make__clauses_5_interrupt;
  x1 = arg(x0, 0);
 make__clauses_5_5:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_functor_1)) goto make__clauses_5_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xmake__headlist_9);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = x5 = makeref(&allocp[9]);
  allocp[10] = x6 = makeref(&allocp[10]);
  allocp[11] = makesym(functor_pred_7);
  allocp[12] = x2;
  allocp[13] = x3;
  allocp[14] = x8 = makeref(&allocp[14]);
  allocp[15] = x5;
  allocp[16] = x9 = makeref(&allocp[16]);
  allocp[17] = NILATOM;
  allocp[18] = NILATOM;
  x7 = makefunctor(&allocp[11]);
  allocp[19] = x6;
  allocp[20] = x7;
  x10 = makecons(&allocp[19]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 21;
  unify_value(a4, x10);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor_xnew__functor__init_4);
  allocp[2] = makesym(atom_modes);
  allocp[3] = x3;
  allocp[4] = makesym(atom__3F);
  allocp[5] = x8;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor_xnew__functor__init_4);
  allocp[8] = makesym(atom_bodyargs);
  allocp[9] = x3;
  allocp[10] = makesym(atom_entries);
  allocp[11] = x9;
  allocp[12] = (q)(struct goalrec*)&allocp[6];
  allocp[13] = (q)(&predicate_functor_xnew__functor__init_4);
  allocp[14] = makesym(atom_headargs);
  allocp[15] = x3;
  allocp[16] = makesym(atom_entries);
  allocp[17] = x4;
  allocp[18] = (q)(struct goalrec*)&allocp[12];
  allocp[19] = (q)(&predicate_functor__table_xfunctor_3);
  x11 = arg(x1, 0);
  allocp[20] = x11;
  allocp[21] = x2;
  allocp[22] = x3;
  qp = (struct goalrec*)&allocp[18];
  allocp += 23;
  proceed();
 case VARREF:
  deref_and_jump(x1,make__clauses_5_5);
  *reasonp++ =  x1;
  goto make__clauses_5_interrupt;
  };
  goto make__clauses_5_interrupt;
 case VARREF:
  deref_and_jump(x0,make__clauses_5_4);
  *reasonp++ =  x0;
  goto make__clauses_5_interrupt;
  };
  goto make__clauses_5_interrupt;
 make__clauses_5_6:
  deref_and_jump(a3,make__clauses_5_3);
  *reasonp++ =  a3;
  goto make__clauses_5_interrupt;
 make__clauses_5_7:
  if (!isref(a1)) goto make__clauses_5_interrupt;
  deref_and_jump(a1,make__clauses_5_2);
  *reasonp++ =  a1;
  goto make__clauses_5_interrupt;
 make__clauses_5_8:
  if (!isref(a0)) goto make__clauses_5_interrupt;
  deref_and_jump(a0,make__clauses_5_1);
  *reasonp++ =  a0;
  goto make__clauses_5_interrupt;
 make__clauses_5_ext_interrupt:
  reasonp = 0l;
 make__clauses_5_interrupt:
  toppred = &predicate_hb_xmake__clauses_5;
  goto interrupt_5;
 }

 make__headlist_9_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 make__headlist_9_clear_reason:
  reasonp = reasons;
 make__headlist_9_0:
 make__headlist_9_1:
  if (!isint(a0)) goto make__headlist_9_18;
 make__headlist_9_2:
  if (!isint(a1)) goto make__headlist_9_17;
  gblt_less_or_eq(a0,a1,make__headlist_9_19);
 make__headlist_9_3:
  if (isref(a3)) goto make__headlist_9_16;
  gblt_arg(a0,a3,x0,make__headlist_9_19);
 make__headlist_9_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_clause_4)) goto make__headlist_9_19;
  x1 = arg(x0, 0);
 make__headlist_9_5:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_functor_1)) goto make__headlist_9_19;
  x2 = arg(x1, 0);
 make__headlist_9_6:
  if (isref(x2)) goto make__headlist_9_15;
  gblt_pfunctor(x2,x3,make__headlist_9_19);
 make__headlist_9_7:
  if (isref(x3)) goto make__headlist_9_14;
 make__headlist_9_8:
  if (isref(x3)) goto make__headlist_9_13;
  if_not_equal(x3, a4, make__headlist_9_19);
  gblt_arity(x2,x4,make__headlist_9_19);
 make__headlist_9_9:
  if (isref(x4)) goto make__headlist_9_12;
 make__headlist_9_10:
  if (isref(x4)) goto make__headlist_9_11;
  if_not_equal(x4, a5, make__headlist_9_19);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xmake__headlist_9);
  allocp[2] = x5 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = x6 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x5;
  a1 = a5;
  a3 = a0;
  a4 = a2;
  a5 = a6;
  a6 = x6;
  a2 = x2;
  a0 = makeint(1L);
  qp = (struct goalrec*)&allocp[11];
  allocp += 16;
  execute(make__args_7_clear_reason);
  goto make__args_7_ext_interrupt;
 make__headlist_9_11:
  deref_and_jump(x4,make__headlist_9_10);
  *reasonp++ =  x4;
  goto make__headlist_9_19;
 make__headlist_9_12:
  deref_and_jump(x4,make__headlist_9_9);
  *reasonp++ =  x4;
  goto make__headlist_9_19;
 make__headlist_9_13:
  deref_and_jump(x3,make__headlist_9_8);
  *reasonp++ =  x3;
  goto make__headlist_9_19;
 make__headlist_9_14:
  deref_and_jump(x3,make__headlist_9_7);
  *reasonp++ =  x3;
  goto make__headlist_9_19;
 make__headlist_9_15:
  deref_and_jump(x2,make__headlist_9_6);
  *reasonp++ =  x2;
  goto make__headlist_9_19;
 case VARREF:
  deref_and_jump(x1,make__headlist_9_5);
  *reasonp++ =  x1;
  goto make__headlist_9_19;
  };
  goto make__headlist_9_19;
 case VARREF:
  deref_and_jump(x0,make__headlist_9_4);
  *reasonp++ =  x0;
  goto make__headlist_9_19;
  };
  goto make__headlist_9_19;
 make__headlist_9_16:
  deref_and_jump(a3,make__headlist_9_3);
  *reasonp++ =  a3;
  goto make__headlist_9_19;
 make__headlist_9_17:
  if (!isref(a1)) goto make__headlist_9_19;
  deref_and_jump(a1,make__headlist_9_2);
  *reasonp++ =  a1;
  goto make__headlist_9_19;
 make__headlist_9_18:
  if (!isref(a0)) goto make__headlist_9_19;
  deref_and_jump(a0,make__headlist_9_1);
  *reasonp++ =  a0;
  goto make__headlist_9_19;
 make__headlist_9_19:
  otherwise(make__headlist_9_interrupt);
 make__headlist_9_20:
  if (!isint(a0)) goto make__headlist_9_27;
 make__headlist_9_21:
  if (!isint(a1)) goto make__headlist_9_26;
  gblt_less_or_eq(a0,a1,make__headlist_9_28);
 make__headlist_9_22:
  if (isref(a3)) goto make__headlist_9_25;
  gblt_arg(a0,a3,x0,make__headlist_9_28);
 make__headlist_9_23:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (isint(x0)) goto make__headlist_9_28;
 make__headlist_9_24:
  gblt_atom(x0,make__headlist_9_28);
  x1 = makeint(1L);
  bblt_add_no_check(a0,x1,x2);
  a0 = x2;
  execute(make__headlist_9_0);
  goto make__headlist_9_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,make__headlist_9_23);
  *reasonp++ =  x0;
  goto make__headlist_9_28;
  };
  goto make__headlist_9_28;
 make__headlist_9_25:
  deref_and_jump(a3,make__headlist_9_22);
  *reasonp++ =  a3;
  goto make__headlist_9_28;
 make__headlist_9_26:
  if (!isref(a1)) goto make__headlist_9_28;
  deref_and_jump(a1,make__headlist_9_21);
  *reasonp++ =  a1;
  goto make__headlist_9_28;
 make__headlist_9_27:
  if (!isref(a0)) goto make__headlist_9_28;
  deref_and_jump(a0,make__headlist_9_20);
  *reasonp++ =  a0;
  goto make__headlist_9_28;
 make__headlist_9_28:
  otherwise(make__headlist_9_interrupt);
 make__headlist_9_29:
  if (!isint(a0)) goto make__headlist_9_33;
 make__headlist_9_30:
  if (!isint(a1)) goto make__headlist_9_32;
  gblt_less_or_eq(a0,a1,make__headlist_9_31);
  unify(a7, a6);
  a4 = a8;
  execute(make__clauses_5_0);
  goto make__clauses_5_ext_interrupt;
 make__headlist_9_31:
  gblt_greater(a0,a1,make__headlist_9_interrupt);
  unify(a7, a6);
  x0 = NILATOM;
  unify_value(a8, x0);
  proceed();
 make__headlist_9_32:
  if (!isref(a1)) goto make__headlist_9_interrupt;
  deref_and_jump(a1,make__headlist_9_30);
  *reasonp++ =  a1;
  goto make__headlist_9_interrupt;
 make__headlist_9_33:
  if (!isref(a0)) goto make__headlist_9_interrupt;
  deref_and_jump(a0,make__headlist_9_29);
  *reasonp++ =  a0;
  goto make__headlist_9_interrupt;
 make__headlist_9_ext_interrupt:
  reasonp = 0l;
 make__headlist_9_interrupt:
  goto interrupt_9;
 }

 make__args_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 make__args_7_clear_reason:
  reasonp = reasons;
 make__args_7_0:
 make__args_7_1:
  if (!isint(a0)) goto make__args_7_5;
 make__args_7_2:
  if (!isint(a1)) goto make__args_7_4;
  gblt_less_or_eq(a0,a1,make__args_7_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xmake__args_7);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[11] = a0;
  allocp[12] = makeint(1L);
  allocp[13] = x0;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[16] = a0;
  allocp[17] = a5;
  allocp[18] = x2 = makeref(&allocp[18]);
  allocp[19] = x1;
  allocp[20] = makesym(functor_arg_2);
  allocp[21] = x4 = makeref(&allocp[21]);
  allocp[22] = x5 = makeref(&allocp[22]);
  x3 = makefunctor(&allocp[20]);
  allocp[23] = (q)(struct goalrec*)&allocp[14];
  allocp[24] = (q)(&predicate_functor_xinsert__arg_4);
  allocp[25] = x6 = makeref(&allocp[25]);
  allocp[26] = x7 = makeref(&allocp[26]);
  allocp[27] = x3;
  allocp[28] = x2;
  allocp[29] = (q)(struct goalrec*)&allocp[23];
  allocp[30] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[31] = x8 = makeref(&allocp[31]);
  allocp[32] = makeint(1L);
  allocp[33] = x6;
  allocp[34] = makesym(functor_goal_4);
  allocp[35] = a4;
  allocp[36] = a3;
  allocp[37] = makesym(atom_head);
  allocp[38] = makeint(1L);
  x9 = makefunctor(&allocp[34]);
  qp = (struct goalrec*)&allocp[29];
  allocp += 39;
  unify_value(x4, x9);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[2] = x7;
  allocp[3] = x10 = makeref(&allocp[3]);
  allocp[4] = x8;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = a0;
  allocp[8] = a5;
  allocp[9] = x7;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = a0;
  allocp[13] = a2;
  allocp[14] = x5;
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 make__args_7_3:
  gblt_greater(a0,a1,make__args_7_interrupt);
  unify(a6, a5);
  proceed();
 make__args_7_4:
  if (!isref(a1)) goto make__args_7_interrupt;
  deref_and_jump(a1,make__args_7_2);
  *reasonp++ =  a1;
  goto make__args_7_interrupt;
 make__args_7_5:
  if (!isref(a0)) goto make__args_7_interrupt;
  deref_and_jump(a0,make__args_7_1);
  *reasonp++ =  a0;
  goto make__args_7_interrupt;
 make__args_7_ext_interrupt:
  reasonp = 0l;
 make__args_7_interrupt:
  toppred = &predicate_hb_xmake__args_7;
  goto interrupt_7;
 }

 make__bodyargs_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  qp = qp->next;
 make__bodyargs_3_clear_reason:
  reasonp = reasons;
 make__bodyargs_3_0:
 make__bodyargs_3_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 make__bodyargs_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto make__bodyargs_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xmake__bodyargs_3);
  allocp[2] = a0;
  x1 = cdr_of(a1);
  allocp[3] = x1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = makesym(functor_module_2);
  x4 = arg(x0, 0);
  allocp[6] = x4;
  allocp[7] = x5 = makeref(&allocp[7]);
  x3 = makefunctor(&allocp[5]);
  allocp[8] = x2;
  allocp[9] = x3;
  x6 = makecons(&allocp[8]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  unify_value(a2, x6);
  x7 = arg(x0, 0);
  a1 = a0;
  a2 = arg(x0, 1);
  a3 = x5;
  a0 = x7;
  execute(check__clauses_4_0);
  goto check__clauses_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,make__bodyargs_3_2);
  *reasonp++ =  x0;
  goto make__bodyargs_3_interrupt;
  };
  goto make__bodyargs_3_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto make__bodyargs_3_interrupt;
  x0 = NILATOM;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,make__bodyargs_3_1);
  *reasonp++ =  a1;
  goto make__bodyargs_3_interrupt;
  };
  goto make__bodyargs_3_interrupt;
 make__bodyargs_3_ext_interrupt:
  reasonp = 0l;
 make__bodyargs_3_interrupt:
  goto interrupt_3;
 }

 check__clauses_4_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 check__clauses_4_clear_reason:
  reasonp = reasons;
 check__clauses_4_0:
 check__clauses_4_1:
  switch (ptagof(a2)) {
 case CONS:
  x0 = car_of(a2);
 check__clauses_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_7)) goto check__clauses_4_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xcheck__clauses_4);
  allocp[2] = a0;
  allocp[3] = a1;
  x1 = cdr_of(a2);
  allocp[4] = x1;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = x2;
  allocp[7] = x4 = makeref(&allocp[7]);
  x3 = makecons(&allocp[6]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  unify_value(a3, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = makeint(5L);
  allocp[3] = x0;
  allocp[4] = x5 = makeref(&allocp[4]);
  allocp[5] = x4;
  x6 = arg(x0, 0);
  a2 = arg(x0, 1);
  a3 = a1;
  a4 = arg(x0, 4);
  a5 = x5;
  a1 = x6;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(search__modules_6_0);
  goto search__modules_6_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,check__clauses_4_2);
  *reasonp++ =  x0;
  goto check__clauses_4_interrupt;
  };
  goto check__clauses_4_interrupt;
 case ATOMIC:
  if (a2 != NILATOM) goto check__clauses_4_interrupt;
  x0 = NILATOM;
  unify_value(a3, x0);
  proceed();
 case VARREF:
  deref_and_jump(a2,check__clauses_4_1);
  *reasonp++ =  a2;
  goto check__clauses_4_interrupt;
  };
  goto check__clauses_4_interrupt;
 check__clauses_4_ext_interrupt:
  reasonp = 0l;
 check__clauses_4_interrupt:
  toppred = &predicate_hb_xcheck__clauses_4;
  goto interrupt_4;
 }

 search__modules_6_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 search__modules_6_clear_reason:
  reasonp = reasons;
 search__modules_6_0:
 search__modules_6_1:
  switch (ptagof(a3)) {
 case CONS:
  x0 = car_of(a3);
 search__modules_6_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto search__modules_6_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xsearch__modules_6);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  x1 = cdr_of(a3);
  allocp[5] = x1;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_hb_xsearch__clauses_9);
  allocp[10] = makeint(1L);
  allocp[11] = x3 = makeref(&allocp[11]);
  x4 = arg(x0, 1);
  allocp[12] = x4;
  allocp[13] = a0;
  x5 = arg(x0, 0);
  allocp[14] = x5;
  allocp[15] = a1;
  allocp[16] = a2;
  allocp[17] = a4;
  allocp[18] = x2;
  allocp[19] = (q)(struct goalrec*)&allocp[8];
  allocp[20] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[21] = x4;
  allocp[22] = x6 = makeref(&allocp[22]);
  allocp[23] = x3;
  qp = (struct goalrec*)&allocp[19];
  allocp += 24;
  proceed();
 case VARREF:
  deref_and_jump(x0,search__modules_6_2);
  *reasonp++ =  x0;
  goto search__modules_6_interrupt;
  };
  goto search__modules_6_interrupt;
 case ATOMIC:
  if (a3 != NILATOM) goto search__modules_6_interrupt;
  unify(a5, a4);
  proceed();
 case VARREF:
  deref_and_jump(a3,search__modules_6_1);
  *reasonp++ =  a3;
  goto search__modules_6_interrupt;
  };
  goto search__modules_6_interrupt;
 search__modules_6_ext_interrupt:
  reasonp = 0l;
 search__modules_6_interrupt:
  toppred = &predicate_hb_xsearch__modules_6;
  goto interrupt_6;
 }

 search__clauses_9_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 search__clauses_9_clear_reason:
  reasonp = reasons;
 search__clauses_9_0:
 search__clauses_9_1:
  if (!isint(a0)) goto search__clauses_9_9;
 search__clauses_9_2:
  if (!isint(a1)) goto search__clauses_9_8;
  gblt_less_or_eq(a0,a1,search__clauses_9_7);
 search__clauses_9_3:
  if (isref(a2)) goto search__clauses_9_6;
  gblt_arg(a0,a2,x0,search__clauses_9_7);
 search__clauses_9_4:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (isint(x0)) goto search__clauses_9_7;
 search__clauses_9_5:
  gblt_atom(x0,search__clauses_9_7);
  x1 = makeint(1L);
  bblt_add_no_check(a0,x1,x2);
  a0 = x2;
  execute(search__clauses_9_0);
  goto search__clauses_9_ext_interrupt;
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_clause_4)) goto search__clauses_9_7;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xsearch__clauses_9);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x1;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_hb_xsearch__bodys_10);
  allocp[18] = makeint(1L);
  allocp[19] = x3 = makeref(&allocp[19]);
  x4 = arg(x0, 2);
  allocp[20] = x4;
  allocp[21] = a0;
  allocp[22] = a3;
  allocp[23] = a4;
  allocp[24] = a5;
  allocp[25] = a6;
  allocp[26] = a7;
  allocp[27] = x2;
  allocp[28] = (q)(struct goalrec*)&allocp[16];
  allocp[29] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[30] = x4;
  allocp[31] = x5 = makeref(&allocp[31]);
  allocp[32] = x3;
  qp = (struct goalrec*)&allocp[28];
  allocp += 33;
  proceed();
 case VARREF:
  deref_and_jump(x0,search__clauses_9_4);
  *reasonp++ =  x0;
  goto search__clauses_9_7;
  };
  goto search__clauses_9_7;
 search__clauses_9_6:
  deref_and_jump(a2,search__clauses_9_3);
  *reasonp++ =  a2;
  goto search__clauses_9_7;
 search__clauses_9_7:
  gblt_greater(a0,a1,search__clauses_9_interrupt);
  unify(a8, a7);
  proceed();
 search__clauses_9_8:
  if (!isref(a1)) goto search__clauses_9_interrupt;
  deref_and_jump(a1,search__clauses_9_2);
  *reasonp++ =  a1;
  goto search__clauses_9_interrupt;
 search__clauses_9_9:
  if (!isref(a0)) goto search__clauses_9_interrupt;
  deref_and_jump(a0,search__clauses_9_1);
  *reasonp++ =  a0;
  goto search__clauses_9_interrupt;
 search__clauses_9_ext_interrupt:
  reasonp = 0l;
 search__clauses_9_interrupt:
  goto interrupt_9;
 }

 search__bodys_10_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 search__bodys_10_clear_reason:
  reasonp = reasons;
 search__bodys_10_0:
 search__bodys_10_1:
  if (!isint(a0)) goto search__bodys_10_7;
 search__bodys_10_2:
  if (!isint(a1)) goto search__bodys_10_6;
  gblt_less_or_eq(a0,a1,search__bodys_10_5);
 search__bodys_10_3:
  if (isref(a2)) goto search__bodys_10_4;
  gblt_arg(a0,a2,x0,search__bodys_10_5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xsearch__bodys_10);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = x2 = makeref(&allocp[10]);
  allocp[11] = a9;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[14] = a0;
  allocp[15] = makeint(1L);
  allocp[16] = x1;
  x3 = a5;
  a1 = a5;
  a2 = a3;
  a3 = a0;
  x4 = a6;
  a5 = a7;
  a6 = x0;
  a7 = a4;
  a9 = x2;
  a4 = x4;
  a0 = x3;
  qp = (struct goalrec*)&allocp[12];
  allocp += 17;
  execute(search__body_10_0);
  goto search__body_10_ext_interrupt;
 search__bodys_10_4:
  deref_and_jump(a2,search__bodys_10_3);
  *reasonp++ =  a2;
  goto search__bodys_10_5;
 search__bodys_10_5:
  gblt_greater(a0,a1,search__bodys_10_interrupt);
  unify(a9, a8);
  proceed();
 search__bodys_10_6:
  if (!isref(a1)) goto search__bodys_10_interrupt;
  deref_and_jump(a1,search__bodys_10_2);
  *reasonp++ =  a1;
  goto search__bodys_10_interrupt;
 search__bodys_10_7:
  if (!isref(a0)) goto search__bodys_10_interrupt;
  deref_and_jump(a0,search__bodys_10_1);
  *reasonp++ =  a0;
  goto search__bodys_10_interrupt;
 search__bodys_10_ext_interrupt:
  reasonp = 0l;
 search__bodys_10_interrupt:
  goto interrupt_10;
 }

 search__body_10_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 search__body_10_clear_reason:
  reasonp = reasons;
 search__body_10_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xsearch__body1_11);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = a0;
  allocp[10] = a7;
  allocp[11] = a8;
  allocp[12] = a9;
  allocp[13] = (q)(struct goalrec*)&allocp[0];
  allocp[14] = (q)(&predicate_parse__uty_xdecode__goalcall_6);
  allocp[15] = a0;
  allocp[16] = x1;
  allocp[17] = a6;
  allocp[18] = x2;
  allocp[19] = x0;
  allocp[20] = x3 = makeref(&allocp[20]);
  qp = (struct goalrec*)&allocp[13];
  allocp += 21;
  proceed();
 search__body_10_ext_interrupt:
  reasonp = 0l;
 search__body_10_interrupt:
  toppred = &predicate_hb_xsearch__body_10;
  goto interrupt_10;
 }

 search__body1_11_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 search__body1_11_clear_reason:
  reasonp = reasons;
 search__body1_11_0:
 search__body1_11_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_atom_1)) goto search__body1_11_17;
  x0 = arg(a0, 0);
 search__body1_11_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_recursive)) goto search__body1_11_17;
 search__body1_11_3:
  if (isref(a1)) goto search__body1_11_16;
 search__body1_11_4:
  if (isref(a1)) goto search__body1_11_15;
  if_not_equal(a1, a8, search__body1_11_17);
 search__body1_11_5:
  if (isref(a6)) goto search__body1_11_14;
  gblt_pfunctor(a6,x1,search__body1_11_17);
 search__body1_11_6:
  if (isref(x1)) goto search__body1_11_13;
 search__body1_11_7:
  if (isref(x1)) goto search__body1_11_12;
  if_not_equal(x1, a4, search__body1_11_17);
  gblt_arity(a6,x2,search__body1_11_17);
 search__body1_11_8:
  if (isref(x2)) goto search__body1_11_11;
 search__body1_11_9:
  if (isref(x2)) goto search__body1_11_10;
  if_not_equal(x2, a5, search__body1_11_17);
  a0 = makeint(1L);
  a1 = a5;
  x3 = a6;
  a4 = a7;
  a5 = a2;
  a6 = a3;
  a7 = a9;
  a8 = a10;
  a3 = x3;
  a2 = makesym(atom_recursive);
  execute(check__args_9_clear_reason);
  goto check__args_9_ext_interrupt;
 search__body1_11_10:
  deref_and_jump(x2,search__body1_11_9);
  *reasonp++ =  x2;
  goto search__body1_11_17;
 search__body1_11_11:
  deref_and_jump(x2,search__body1_11_8);
  *reasonp++ =  x2;
  goto search__body1_11_17;
 search__body1_11_12:
  deref_and_jump(x1,search__body1_11_7);
  *reasonp++ =  x1;
  goto search__body1_11_17;
 search__body1_11_13:
  deref_and_jump(x1,search__body1_11_6);
  *reasonp++ =  x1;
  goto search__body1_11_17;
 search__body1_11_14:
  deref_and_jump(a6,search__body1_11_5);
  *reasonp++ =  a6;
  goto search__body1_11_17;
 search__body1_11_15:
  deref_and_jump(a1,search__body1_11_4);
  *reasonp++ =  a1;
  goto search__body1_11_17;
 search__body1_11_16:
  deref_and_jump(a1,search__body1_11_3);
  *reasonp++ =  a1;
  goto search__body1_11_17;
 case VARREF:
  deref_and_jump(x0,search__body1_11_2);
  *reasonp++ =  x0;
  goto search__body1_11_17;
  };
  goto search__body1_11_17;
 case VARREF:
  deref_and_jump(a0,search__body1_11_1);
  *reasonp++ =  a0;
  goto search__body1_11_17;
  };
  goto search__body1_11_17;
 search__body1_11_17:
  otherwise(search__body1_11_interrupt);
 search__body1_11_18:
  if (isref(a1)) goto search__body1_11_31;
 search__body1_11_19:
  if (isref(a1)) goto search__body1_11_30;
  if_not_equal(a1, a8, search__body1_11_32);
 search__body1_11_20:
  if (isref(a6)) goto search__body1_11_29;
  gblt_pfunctor(a6,x0,search__body1_11_32);
 search__body1_11_21:
  if (isref(x0)) goto search__body1_11_28;
 search__body1_11_22:
  if (isref(x0)) goto search__body1_11_27;
  if_not_equal(x0, a4, search__body1_11_32);
  gblt_arity(a6,x1,search__body1_11_32);
 search__body1_11_23:
  if (isref(x1)) goto search__body1_11_26;
 search__body1_11_24:
  if (isref(x1)) goto search__body1_11_25;
  if_not_equal(x1, a5, search__body1_11_32);
  a0 = makeint(1L);
  a1 = a5;
  x2 = a6;
  a4 = a7;
  a5 = a2;
  a6 = a3;
  a7 = a9;
  a8 = a10;
  a3 = x2;
  a2 = makesym(atom_nonloop);
  execute(check__args_9_clear_reason);
  goto check__args_9_ext_interrupt;
 search__body1_11_25:
  deref_and_jump(x1,search__body1_11_24);
  *reasonp++ =  x1;
  goto search__body1_11_32;
 search__body1_11_26:
  deref_and_jump(x1,search__body1_11_23);
  *reasonp++ =  x1;
  goto search__body1_11_32;
 search__body1_11_27:
  deref_and_jump(x0,search__body1_11_22);
  *reasonp++ =  x0;
  goto search__body1_11_32;
 search__body1_11_28:
  deref_and_jump(x0,search__body1_11_21);
  *reasonp++ =  x0;
  goto search__body1_11_32;
 search__body1_11_29:
  deref_and_jump(a6,search__body1_11_20);
  *reasonp++ =  a6;
  goto search__body1_11_32;
 search__body1_11_30:
  deref_and_jump(a1,search__body1_11_19);
  *reasonp++ =  a1;
  goto search__body1_11_32;
 search__body1_11_31:
  deref_and_jump(a1,search__body1_11_18);
  *reasonp++ =  a1;
  goto search__body1_11_32;
 search__body1_11_32:
  otherwise(search__body1_11_interrupt);
  unify(a10, a9);
  proceed();
 search__body1_11_ext_interrupt:
  reasonp = 0l;
 search__body1_11_interrupt:
  goto interrupt_11;
 }

 check__args_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 check__args_9_clear_reason:
  reasonp = reasons;
 check__args_9_0:
 check__args_9_1:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (isint(a2)) goto check__args_9_10;
  switch (symval(a2)) {
 case symval(makesym(atom_recursive)):
 check__args_9_2:
  if (!isint(a0)) goto check__args_9_5;
 check__args_9_3:
  if (!isint(a1)) goto check__args_9_4;
  gblt_less_or_eq(a0,a1,check__args_9_10);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xcheck__args_9);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = makesym(atom_recursive);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = x1 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x0;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[18] = a0;
  allocp[19] = a7;
  allocp[20] = x2 = makeref(&allocp[20]);
  allocp[21] = x1;
  allocp[22] = makesym(functor_recursivearg_2);
  allocp[23] = x4 = makeref(&allocp[23]);
  allocp[24] = x5 = makeref(&allocp[24]);
  x3 = makefunctor(&allocp[22]);
  allocp[25] = (q)(struct goalrec*)&allocp[16];
  allocp[26] = (q)(&predicate_functor_xinsert__arg_4);
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = x7 = makeref(&allocp[28]);
  allocp[29] = x3;
  allocp[30] = x2;
  allocp[31] = (q)(struct goalrec*)&allocp[25];
  allocp[32] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[33] = x8 = makeref(&allocp[33]);
  allocp[34] = makeint(1L);
  allocp[35] = x6;
  allocp[36] = makesym(functor_goal_4);
  allocp[37] = a4;
  allocp[38] = a5;
  allocp[39] = makesym(atom_body);
  allocp[40] = a6;
  x9 = makefunctor(&allocp[36]);
  qp = (struct goalrec*)&allocp[31];
  allocp += 41;
  unify_value(x4, x9);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[2] = x7;
  allocp[3] = x10 = makeref(&allocp[3]);
  allocp[4] = x8;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = a0;
  allocp[8] = a7;
  allocp[9] = x7;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = a0;
  allocp[13] = a3;
  allocp[14] = x5;
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 check__args_9_4:
  if (!isref(a1)) goto check__args_9_10;
  deref_and_jump(a1,check__args_9_3);
  *reasonp++ =  a1;
  goto check__args_9_10;
 check__args_9_5:
  if (!isref(a0)) goto check__args_9_10;
  deref_and_jump(a0,check__args_9_2);
  *reasonp++ =  a0;
  goto check__args_9_10;
 case symval(makesym(atom_nonloop)):
 check__args_9_6:
  if (!isint(a0)) goto check__args_9_9;
 check__args_9_7:
  if (!isint(a1)) goto check__args_9_8;
  gblt_less_or_eq(a0,a1,check__args_9_10);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xcheck__args_9);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = makesym(atom_nonloop);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = x1 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x0;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[18] = a0;
  allocp[19] = a7;
  allocp[20] = x2 = makeref(&allocp[20]);
  allocp[21] = x1;
  allocp[22] = makesym(functor_arg_2);
  allocp[23] = x4 = makeref(&allocp[23]);
  allocp[24] = x5 = makeref(&allocp[24]);
  x3 = makefunctor(&allocp[22]);
  allocp[25] = (q)(struct goalrec*)&allocp[16];
  allocp[26] = (q)(&predicate_functor_xinsert__arg_4);
  allocp[27] = x6 = makeref(&allocp[27]);
  allocp[28] = x7 = makeref(&allocp[28]);
  allocp[29] = x3;
  allocp[30] = x2;
  allocp[31] = (q)(struct goalrec*)&allocp[25];
  allocp[32] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[33] = x8 = makeref(&allocp[33]);
  allocp[34] = makeint(1L);
  allocp[35] = x6;
  allocp[36] = makesym(functor_goal_4);
  allocp[37] = a4;
  allocp[38] = a5;
  allocp[39] = makesym(atom_body);
  allocp[40] = a6;
  x9 = makefunctor(&allocp[36]);
  qp = (struct goalrec*)&allocp[31];
  allocp += 41;
  unify_value(x4, x9);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[2] = x7;
  allocp[3] = x10 = makeref(&allocp[3]);
  allocp[4] = x8;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xarg_3);
  allocp[7] = a0;
  allocp[8] = a7;
  allocp[9] = x7;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = a0;
  allocp[13] = a3;
  allocp[14] = x5;
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 check__args_9_8:
  if (!isref(a1)) goto check__args_9_10;
  deref_and_jump(a1,check__args_9_7);
  *reasonp++ =  a1;
  goto check__args_9_10;
 check__args_9_9:
  if (!isref(a0)) goto check__args_9_10;
  deref_and_jump(a0,check__args_9_6);
  *reasonp++ =  a0;
  goto check__args_9_10;
  };
  goto check__args_9_10;
 case VARREF:
  deref_and_jump(a2,check__args_9_1);
  *reasonp++ =  a2;
  goto check__args_9_10;
  };
  goto check__args_9_10;
 check__args_9_10:
 check__args_9_11:
  if (!isint(a0)) goto check__args_9_14;
 check__args_9_12:
  if (!isint(a1)) goto check__args_9_13;
  gblt_greater(a0,a1,check__args_9_interrupt);
  unify(a8, a7);
  proceed();
 check__args_9_13:
  if (!isref(a1)) goto check__args_9_interrupt;
  deref_and_jump(a1,check__args_9_12);
  *reasonp++ =  a1;
  goto check__args_9_interrupt;
 check__args_9_14:
  if (!isref(a0)) goto check__args_9_interrupt;
  deref_and_jump(a0,check__args_9_11);
  *reasonp++ =  a0;
  goto check__args_9_interrupt;
 check__args_9_ext_interrupt:
  reasonp = 0l;
 check__args_9_interrupt:
  toppred = &predicate_hb_xcheck__args_9;
  goto interrupt_9;
 }

 get__typeset_12_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 get__typeset_12_clear_reason:
  reasonp = reasons;
 get__typeset_12_0:
 get__typeset_12_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 get__typeset_12_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto get__typeset_12_7;
  x1 = arg(x0, 0);
 get__typeset_12_3:
  if (isref(x1)) goto get__typeset_12_6;
 get__typeset_12_4:
  if (isref(x1)) goto get__typeset_12_5;
  if_not_equal(x1, a1, get__typeset_12_7);
  x2 = arg(x0, 1);
  x3 = a0;
  x4 = a9;
  x5 = a10;
  a12 = a11;
  a11 = x5;
  a10 = x4;
  a9 = x3;
  a0 = x2;
  execute(get__namelist_13_clear_reason);
  goto get__namelist_13_ext_interrupt;
 get__typeset_12_5:
  deref_and_jump(x1,get__typeset_12_4);
  *reasonp++ =  x1;
  goto get__typeset_12_7;
 get__typeset_12_6:
  deref_and_jump(x1,get__typeset_12_3);
  *reasonp++ =  x1;
  goto get__typeset_12_7;
 case VARREF:
  deref_and_jump(x0,get__typeset_12_2);
  *reasonp++ =  x0;
  goto get__typeset_12_7;
  };
  goto get__typeset_12_7;
 case VARREF:
  deref_and_jump(a0,get__typeset_12_1);
  *reasonp++ =  a0;
  goto get__typeset_12_7;
  };
  goto get__typeset_12_7;
 get__typeset_12_7:
  otherwise(get__typeset_12_interrupt);
 get__typeset_12_8:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(get__typeset_12_0);
  goto get__typeset_12_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto get__typeset_12_interrupt;
  unify(a11, a10);
  x0 = makesym(atom_error);
  x1 = makesym(atom_get__typeset);
  unify(x0, x1);
  proceed();
 case VARREF:
  deref_and_jump(a0,get__typeset_12_8);
  *reasonp++ =  a0;
  goto get__typeset_12_interrupt;
  };
  goto get__typeset_12_interrupt;
 get__typeset_12_ext_interrupt:
  reasonp = 0l;
 get__typeset_12_interrupt:
  goto interrupt_12;
 }

 get__namelist_13_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  qp = qp->next;
 get__namelist_13_clear_reason:
  reasonp = reasons;
 get__namelist_13_0:
 get__namelist_13_1:
  switch (ptagof(a7)) {
 case ATOMIC:
  if (isint(a7)) goto get__namelist_13_22;
  switch (symval(a7)) {
 case symval(makesym(atom__2B)):
 get__namelist_13_2:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 get__namelist_13_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_7)) goto get__namelist_13_22;
  x1 = arg(x0, 0);
 get__namelist_13_4:
  if (isref(x1)) goto get__namelist_13_11;
 get__namelist_13_5:
  if (isref(x1)) goto get__namelist_13_10;
  if_not_equal(x1, a2, get__namelist_13_22);
  x2 = arg(x0, 1);
 get__namelist_13_6:
  if (isref(x2)) goto get__namelist_13_9;
 get__namelist_13_7:
  if (isref(x2)) goto get__namelist_13_8;
  if_not_equal(x2, a3, get__namelist_13_22);
  x3 = makecons(cons_const_0);
  unify_value(a5, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xget__bodylist_9);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = NILATOM;
  allocp[5] = a6;
  allocp[6] = a8;
  allocp[7] = a9;
  allocp[8] = a10;
  allocp[9] = a11;
  allocp[10] = a12;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[13] = x5;
  allocp[14] = x6 = makeref(&allocp[14]);
  allocp[15] = x4;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_functor__table_xarg_3);
  allocp[18] = a4;
  x7 = arg(x0, 4);
  allocp[19] = x7;
  allocp[20] = x5;
  qp = (struct goalrec*)&allocp[16];
  allocp += 21;
  proceed();
 get__namelist_13_8:
  deref_and_jump(x2,get__namelist_13_7);
  *reasonp++ =  x2;
  goto get__namelist_13_22;
 get__namelist_13_9:
  deref_and_jump(x2,get__namelist_13_6);
  *reasonp++ =  x2;
  goto get__namelist_13_22;
 get__namelist_13_10:
  deref_and_jump(x1,get__namelist_13_5);
  *reasonp++ =  x1;
  goto get__namelist_13_22;
 get__namelist_13_11:
  deref_and_jump(x1,get__namelist_13_4);
  *reasonp++ =  x1;
  goto get__namelist_13_22;
 case VARREF:
  deref_and_jump(x0,get__namelist_13_3);
  *reasonp++ =  x0;
  goto get__namelist_13_22;
  };
  goto get__namelist_13_22;
 case VARREF:
  deref_and_jump(a0,get__namelist_13_2);
  *reasonp++ =  a0;
  goto get__namelist_13_22;
  };
  goto get__namelist_13_22;
 case symval(makesym(atom__2D)):
 get__namelist_13_12:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 get__namelist_13_13:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_7)) goto get__namelist_13_22;
  x1 = arg(x0, 0);
 get__namelist_13_14:
  if (isref(x1)) goto get__namelist_13_21;
 get__namelist_13_15:
  if (isref(x1)) goto get__namelist_13_20;
  if_not_equal(x1, a2, get__namelist_13_22);
  x2 = arg(x0, 1);
 get__namelist_13_16:
  if (isref(x2)) goto get__namelist_13_19;
 get__namelist_13_17:
  if (isref(x2)) goto get__namelist_13_18;
  if_not_equal(x2, a3, get__namelist_13_22);
  x3 = makecons(cons_const_0);
  unify_value(a6, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xget__headlist_9);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = NILATOM;
  allocp[5] = a5;
  allocp[6] = a8;
  allocp[7] = a9;
  allocp[8] = a10;
  allocp[9] = a11;
  allocp[10] = a12;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[13] = x5;
  allocp[14] = x6 = makeref(&allocp[14]);
  allocp[15] = x4;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_functor__table_xarg_3);
  allocp[18] = a4;
  x7 = arg(x0, 3);
  allocp[19] = x7;
  allocp[20] = x5;
  qp = (struct goalrec*)&allocp[16];
  allocp += 21;
  proceed();
 get__namelist_13_18:
  deref_and_jump(x2,get__namelist_13_17);
  *reasonp++ =  x2;
  goto get__namelist_13_22;
 get__namelist_13_19:
  deref_and_jump(x2,get__namelist_13_16);
  *reasonp++ =  x2;
  goto get__namelist_13_22;
 get__namelist_13_20:
  deref_and_jump(x1,get__namelist_13_15);
  *reasonp++ =  x1;
  goto get__namelist_13_22;
 get__namelist_13_21:
  deref_and_jump(x1,get__namelist_13_14);
  *reasonp++ =  x1;
  goto get__namelist_13_22;
 case VARREF:
  deref_and_jump(x0,get__namelist_13_13);
  *reasonp++ =  x0;
  goto get__namelist_13_22;
  };
  goto get__namelist_13_22;
 case VARREF:
  deref_and_jump(a0,get__namelist_13_12);
  *reasonp++ =  a0;
  goto get__namelist_13_22;
  };
  goto get__namelist_13_22;
  };
  goto get__namelist_13_22;
 case VARREF:
  deref_and_jump(a7,get__namelist_13_1);
  *reasonp++ =  a7;
  goto get__namelist_13_22;
  };
  goto get__namelist_13_22;
 get__namelist_13_22:
  otherwise(get__namelist_13_interrupt);
 get__namelist_13_23:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(get__namelist_13_0);
  goto get__namelist_13_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto get__namelist_13_interrupt;
  unify(a12, a11);
  x0 = makecons(cons_const_0);
  unify_value(a5, x0);
  x1 = makecons(cons_const_0);
  unify_value(a6, x1);
  proceed();
 case VARREF:
  deref_and_jump(a0,get__namelist_13_23);
  *reasonp++ =  a0;
  goto get__namelist_13_interrupt;
  };
  goto get__namelist_13_interrupt;
 get__namelist_13_ext_interrupt:
  reasonp = 0l;
 get__namelist_13_interrupt:
  toppred = &predicate_hb_xget__namelist_13;
  goto interrupt_13;
 }

 get__bodylist_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 get__bodylist_9_clear_reason:
  reasonp = reasons;
 get__bodylist_9_0:
 get__bodylist_9_1:
  if (!isint(a0)) goto get__bodylist_9_13;
  x0 = makeint(0L);
  gblt_greater(a0,x0,get__bodylist_9_14);
 get__bodylist_9_2:
  if (isref(a1)) goto get__bodylist_9_12;
  gblt_arg(a0,a1,x1,get__bodylist_9_14);
 get__bodylist_9_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  switch (symval(functor_of(x1))) {
 case functor_arg_2:
  x2 = arg(x1, 0);
 get__bodylist_9_4:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_goal_4)) goto get__bodylist_9_14;
  x3 = arg(x1, 1);
 get__bodylist_9_5:
  switch (ptagof(x3)) {
 case FUNCTOR:
  if (functor_of(x3) != makesym(functor_variable_3)) goto get__bodylist_9_14;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xget__bodylist_9);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x5 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x4;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[18] = a2;
  allocp[19] = x6 = makeref(&allocp[19]);
  allocp[20] = x5;
  allocp[21] = (q)(struct goalrec*)&allocp[16];
  allocp[22] = (q)(&predicate_typeset_xget_5);
  x7 = arg(x2, 0);
  allocp[23] = x7;
  x8 = arg(x2, 1);
  allocp[24] = x8;
  x9 = arg(x3, 0);
  allocp[25] = x9;
  allocp[26] = x6;
  allocp[27] = a7;
  qp = (struct goalrec*)&allocp[21];
  allocp += 28;
  proceed();
 case VARREF:
  deref_and_jump(x3,get__bodylist_9_5);
  *reasonp++ =  x3;
  goto get__bodylist_9_14;
  };
  goto get__bodylist_9_14;
 case VARREF:
  deref_and_jump(x2,get__bodylist_9_4);
  *reasonp++ =  x2;
  goto get__bodylist_9_14;
  };
  goto get__bodylist_9_14;
 case functor_recursivearg_2:
  x2 = arg(x1, 0);
 get__bodylist_9_6:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_goal_4)) goto get__bodylist_9_14;
  x3 = arg(x1, 1);
 get__bodylist_9_7:
  switch (ptagof(x3)) {
 case FUNCTOR:
  if (functor_of(x3) != makesym(functor_variable_3)) goto get__bodylist_9_14;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xget__bodylist_9);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x5 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x4;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_hb_xor__typeset_9);
  allocp[18] = makesym(atom__2B);
  allocp[19] = x7 = makeref(&allocp[19]);
  allocp[20] = a2;
  allocp[21] = x5;
  allocp[22] = a4;
  allocp[23] = a5;
  allocp[24] = a6;
  allocp[25] = x8 = makeref(&allocp[25]);
  allocp[26] = x6;
  allocp[27] = makesym(functor_goal_4);
  x10 = arg(x2, 0);
  allocp[28] = x10;
  x11 = arg(x2, 1);
  allocp[29] = x11;
  allocp[30] = makesym(atom_body);
  x12 = arg(x2, 3);
  allocp[31] = x12;
  x9 = makefunctor(&allocp[27]);
  allocp[32] = (q)(struct goalrec*)&allocp[16];
  allocp[33] = (q)(&predicate_hb_xexpand__loopgoal_8);
  allocp[34] = makesym(atom__2B);
  allocp[35] = makesym(atom_recursive);
  allocp[36] = x9;
  allocp[37] = x13 = makeref(&allocp[37]);
  allocp[38] = x7;
  allocp[39] = a6;
  allocp[40] = a7;
  allocp[41] = x8;
  allocp[42] = (q)(struct goalrec*)&allocp[32];
  allocp[43] = (q)(&predicate_typeset_xget_5);
  x14 = arg(x2, 0);
  allocp[44] = x14;
  x15 = arg(x2, 1);
  allocp[45] = x15;
  x16 = arg(x3, 0);
  allocp[46] = x16;
  allocp[47] = x13;
  allocp[48] = a7;
  qp = (struct goalrec*)&allocp[42];
  allocp += 49;
  proceed();
 case VARREF:
  deref_and_jump(x3,get__bodylist_9_7);
  *reasonp++ =  x3;
  goto get__bodylist_9_14;
  };
  goto get__bodylist_9_14;
 case VARREF:
  deref_and_jump(x2,get__bodylist_9_6);
  *reasonp++ =  x2;
  goto get__bodylist_9_14;
  };
  goto get__bodylist_9_14;
 case functor_entryarg_2:
  x2 = arg(x1, 0);
 get__bodylist_9_8:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_goal_4)) goto get__bodylist_9_14;
  x3 = arg(x1, 1);
 get__bodylist_9_9:
  switch (ptagof(x3)) {
 case FUNCTOR:
  if (functor_of(x3) != makesym(functor_variable_3)) goto get__bodylist_9_14;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xget__bodylist_9);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x5 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x4;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[18] = a2;
  allocp[19] = x7 = makeref(&allocp[19]);
  allocp[20] = x5;
  allocp[21] = makesym(functor_goal_4);
  x9 = arg(x2, 0);
  allocp[22] = x9;
  x10 = arg(x2, 1);
  allocp[23] = x10;
  allocp[24] = makesym(atom_body);
  x11 = arg(x2, 3);
  allocp[25] = x11;
  x8 = makefunctor(&allocp[21]);
  allocp[26] = (q)(struct goalrec*)&allocp[16];
  allocp[27] = (q)(&predicate_hb_xexpand__loopgoal_8);
  allocp[28] = makesym(atom__2B);
  allocp[29] = makesym(atom_entry);
  allocp[30] = x8;
  allocp[31] = x12 = makeref(&allocp[31]);
  allocp[32] = x7;
  allocp[33] = a6;
  allocp[34] = a7;
  allocp[35] = x6;
  allocp[36] = (q)(struct goalrec*)&allocp[26];
  allocp[37] = (q)(&predicate_typeset_xget_5);
  x13 = arg(x2, 0);
  allocp[38] = x13;
  x14 = arg(x2, 1);
  allocp[39] = x14;
  x15 = arg(x3, 0);
  allocp[40] = x15;
  allocp[41] = x12;
  allocp[42] = a7;
  qp = (struct goalrec*)&allocp[36];
  allocp += 43;
  proceed();
 case VARREF:
  deref_and_jump(x3,get__bodylist_9_9);
  *reasonp++ =  x3;
  goto get__bodylist_9_14;
  };
  goto get__bodylist_9_14;
 case VARREF:
  deref_and_jump(x2,get__bodylist_9_8);
  *reasonp++ =  x2;
  goto get__bodylist_9_14;
  };
  goto get__bodylist_9_14;
 case functor_sharedarg_2:
  x2 = arg(x1, 0);
 get__bodylist_9_10:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_goal_4)) goto get__bodylist_9_14;
  x3 = arg(x1, 1);
 get__bodylist_9_11:
  switch (ptagof(x3)) {
 case FUNCTOR:
  if (functor_of(x3) != makesym(functor_variable_3)) goto get__bodylist_9_14;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xget__bodylist_9);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x5 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x4;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_hb_xor__typeset_9);
  allocp[18] = makesym(atom__2B);
  allocp[19] = x7 = makeref(&allocp[19]);
  allocp[20] = a2;
  allocp[21] = x5;
  allocp[22] = a4;
  allocp[23] = a5;
  allocp[24] = a6;
  allocp[25] = x8 = makeref(&allocp[25]);
  allocp[26] = x6;
  allocp[27] = makesym(functor_goal_4);
  x10 = arg(x2, 0);
  allocp[28] = x10;
  x11 = arg(x2, 1);
  allocp[29] = x11;
  allocp[30] = makesym(atom_body);
  x12 = arg(x2, 3);
  allocp[31] = x12;
  x9 = makefunctor(&allocp[27]);
  allocp[32] = (q)(struct goalrec*)&allocp[16];
  allocp[33] = (q)(&predicate_hb_xexpand__loopgoal_8);
  allocp[34] = makesym(atom__2B);
  allocp[35] = makesym(atom_shared);
  allocp[36] = x9;
  allocp[37] = x13 = makeref(&allocp[37]);
  allocp[38] = x7;
  allocp[39] = a6;
  allocp[40] = a7;
  allocp[41] = x8;
  allocp[42] = (q)(struct goalrec*)&allocp[32];
  allocp[43] = (q)(&predicate_typeset_xget_5);
  x14 = arg(x2, 0);
  allocp[44] = x14;
  x15 = arg(x2, 1);
  allocp[45] = x15;
  x16 = arg(x3, 0);
  allocp[46] = x16;
  allocp[47] = x13;
  allocp[48] = a7;
  qp = (struct goalrec*)&allocp[42];
  allocp += 49;
  proceed();
 case VARREF:
  deref_and_jump(x3,get__bodylist_9_11);
  *reasonp++ =  x3;
  goto get__bodylist_9_14;
  };
  goto get__bodylist_9_14;
 case VARREF:
  deref_and_jump(x2,get__bodylist_9_10);
  *reasonp++ =  x2;
  goto get__bodylist_9_14;
  };
  goto get__bodylist_9_14;
  };
  goto get__bodylist_9_14;
 case VARREF:
  deref_and_jump(x1,get__bodylist_9_3);
  *reasonp++ =  x1;
  goto get__bodylist_9_14;
  };
  goto get__bodylist_9_14;
 get__bodylist_9_12:
  deref_and_jump(a1,get__bodylist_9_2);
  *reasonp++ =  a1;
  goto get__bodylist_9_14;
 get__bodylist_9_13:
  if (!isref(a0)) goto get__bodylist_9_14;
  deref_and_jump(a0,get__bodylist_9_1);
  *reasonp++ =  a0;
  goto get__bodylist_9_14;
 get__bodylist_9_14:
  otherwise(get__bodylist_9_interrupt);
 get__bodylist_9_15:
  if (!isint(a0)) goto get__bodylist_9_24;
  x0 = makeint(0L);
  gblt_greater(a0,x0,get__bodylist_9_23);
 get__bodylist_9_16:
  if (isref(a1)) goto get__bodylist_9_22;
  gblt_arg(a0,a1,x1,get__bodylist_9_23);
 get__bodylist_9_17:
  switch (ptagof(x1)) {
 case FUNCTOR:
  switch (symval(functor_of(x1))) {
 case functor_arg_2:
  x2 = arg(x1, 0);
 get__bodylist_9_18:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_goal_4)) goto get__bodylist_9_23;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xget__bodylist_9);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x3;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[18] = a2;
  allocp[19] = x5 = makeref(&allocp[19]);
  allocp[20] = x4;
  allocp[21] = makesym(functor_goal_4);
  x7 = arg(x2, 0);
  allocp[22] = x7;
  x8 = arg(x2, 1);
  allocp[23] = x8;
  x9 = arg(x2, 2);
  allocp[24] = x9;
  x10 = arg(x2, 3);
  allocp[25] = x10;
  x6 = makefunctor(&allocp[21]);
  allocp[26] = NILATOM;
  allocp[27] = x6;
  x11 = makecons(&allocp[26]);
  allocp[28] = (q)(struct goalrec*)&allocp[16];
  allocp[29] = (q)(&predicate_typeset_xvalue2typeset_5);
  x12 = arg(x2, 0);
  allocp[30] = x12;
  x13 = arg(x2, 1);
  allocp[31] = x13;
  x14 = arg(x1, 1);
  allocp[32] = x14;
  allocp[33] = x11;
  allocp[34] = x5;
  qp = (struct goalrec*)&allocp[28];
  allocp += 35;
  proceed();
 case VARREF:
  deref_and_jump(x2,get__bodylist_9_18);
  *reasonp++ =  x2;
  goto get__bodylist_9_23;
  };
  goto get__bodylist_9_23;
 case functor_recursivearg_2:
  x2 = arg(x1, 0);
 get__bodylist_9_19:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_goal_4)) goto get__bodylist_9_23;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xget__bodylist_9);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x3;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[18] = a2;
  allocp[19] = x5 = makeref(&allocp[19]);
  allocp[20] = x4;
  allocp[21] = makesym(functor_goal_4);
  x7 = arg(x2, 0);
  allocp[22] = x7;
  x8 = arg(x2, 1);
  allocp[23] = x8;
  x9 = arg(x2, 2);
  allocp[24] = x9;
  x10 = arg(x2, 3);
  allocp[25] = x10;
  x6 = makefunctor(&allocp[21]);
  allocp[26] = NILATOM;
  allocp[27] = x6;
  x11 = makecons(&allocp[26]);
  allocp[28] = (q)(struct goalrec*)&allocp[16];
  allocp[29] = (q)(&predicate_typeset_xvalue2typeset_5);
  x12 = arg(x2, 0);
  allocp[30] = x12;
  x13 = arg(x2, 1);
  allocp[31] = x13;
  x14 = arg(x1, 1);
  allocp[32] = x14;
  allocp[33] = x11;
  allocp[34] = x5;
  qp = (struct goalrec*)&allocp[28];
  allocp += 35;
  proceed();
 case VARREF:
  deref_and_jump(x2,get__bodylist_9_19);
  *reasonp++ =  x2;
  goto get__bodylist_9_23;
  };
  goto get__bodylist_9_23;
 case functor_entryarg_2:
  x2 = arg(x1, 0);
 get__bodylist_9_20:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_goal_4)) goto get__bodylist_9_23;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xget__bodylist_9);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x3;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[18] = a2;
  allocp[19] = x5 = makeref(&allocp[19]);
  allocp[20] = x4;
  allocp[21] = makesym(functor_goal_4);
  x7 = arg(x2, 0);
  allocp[22] = x7;
  x8 = arg(x2, 1);
  allocp[23] = x8;
  x9 = arg(x2, 2);
  allocp[24] = x9;
  x10 = arg(x2, 3);
  allocp[25] = x10;
  x6 = makefunctor(&allocp[21]);
  allocp[26] = NILATOM;
  allocp[27] = x6;
  x11 = makecons(&allocp[26]);
  allocp[28] = (q)(struct goalrec*)&allocp[16];
  allocp[29] = (q)(&predicate_typeset_xvalue2typeset_5);
  x12 = arg(x2, 0);
  allocp[30] = x12;
  x13 = arg(x2, 1);
  allocp[31] = x13;
  x14 = arg(x1, 1);
  allocp[32] = x14;
  allocp[33] = x11;
  allocp[34] = x5;
  qp = (struct goalrec*)&allocp[28];
  allocp += 35;
  proceed();
 case VARREF:
  deref_and_jump(x2,get__bodylist_9_20);
  *reasonp++ =  x2;
  goto get__bodylist_9_23;
  };
  goto get__bodylist_9_23;
 case functor_sharedarg_2:
  x2 = arg(x1, 0);
 get__bodylist_9_21:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_goal_4)) goto get__bodylist_9_23;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xget__bodylist_9);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x3;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[18] = a2;
  allocp[19] = x5 = makeref(&allocp[19]);
  allocp[20] = x4;
  allocp[21] = makesym(functor_goal_4);
  x7 = arg(x2, 0);
  allocp[22] = x7;
  x8 = arg(x2, 1);
  allocp[23] = x8;
  x9 = arg(x2, 2);
  allocp[24] = x9;
  x10 = arg(x2, 3);
  allocp[25] = x10;
  x6 = makefunctor(&allocp[21]);
  allocp[26] = NILATOM;
  allocp[27] = x6;
  x11 = makecons(&allocp[26]);
  allocp[28] = (q)(struct goalrec*)&allocp[16];
  allocp[29] = (q)(&predicate_typeset_xvalue2typeset_5);
  x12 = arg(x2, 0);
  allocp[30] = x12;
  x13 = arg(x2, 1);
  allocp[31] = x13;
  x14 = arg(x1, 1);
  allocp[32] = x14;
  allocp[33] = x11;
  allocp[34] = x5;
  qp = (struct goalrec*)&allocp[28];
  allocp += 35;
  proceed();
 case VARREF:
  deref_and_jump(x2,get__bodylist_9_21);
  *reasonp++ =  x2;
  goto get__bodylist_9_23;
  };
  goto get__bodylist_9_23;
  };
  goto get__bodylist_9_23;
 case VARREF:
  deref_and_jump(x1,get__bodylist_9_17);
  *reasonp++ =  x1;
  goto get__bodylist_9_23;
  };
  goto get__bodylist_9_23;
 get__bodylist_9_22:
  deref_and_jump(a1,get__bodylist_9_16);
  *reasonp++ =  a1;
  goto get__bodylist_9_23;
 get__bodylist_9_23:
  if (a0 != makeint(0L)) goto get__bodylist_9_interrupt;
  unify2(a8, a7, a3, a2);
  proceed();
 get__bodylist_9_24:
  if (!isref(a0)) goto get__bodylist_9_interrupt;
  deref_and_jump(a0,get__bodylist_9_15);
  *reasonp++ =  a0;
  goto get__bodylist_9_interrupt;
 get__bodylist_9_ext_interrupt:
  reasonp = 0l;
 get__bodylist_9_interrupt:
  goto interrupt_9;
 }

 expand__loopgoal_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 expand__loopgoal_8_clear_reason:
  reasonp = reasons;
 expand__loopgoal_8_0:
 expand__loopgoal_8_1:
  switch (ptagof(a3)) {
 case CONS:
  x0 = car_of(a3);
 expand__loopgoal_8_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto expand__loopgoal_8_3;
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = makesym(atom__2A);
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a4, x1);
  a3 = cdr_of(a3);
  a4 = x2;
  execute(expand__loopgoal_8_0);
  goto expand__loopgoal_8_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,expand__loopgoal_8_2);
  *reasonp++ =  x0;
  goto expand__loopgoal_8_3;
  };
  goto expand__loopgoal_8_3;
 case ATOMIC:
  if (a3 != NILATOM) goto expand__loopgoal_8_3;
  unify(a7, a6);
  x0 = NILATOM;
  unify_value(a4, x0);
  proceed();
 case VARREF:
  deref_and_jump(a3,expand__loopgoal_8_1);
  *reasonp++ =  a3;
  goto expand__loopgoal_8_3;
  };
  goto expand__loopgoal_8_3;
 expand__loopgoal_8_3:
  otherwise(expand__loopgoal_8_interrupt);
 expand__loopgoal_8_4:
  switch (ptagof(a3)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xexpand__loopgoal_8);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  x0 = cdr_of(a3);
  allocp[5] = x0;
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x1;
  allocp[11] = x4 = makeref(&allocp[11]);
  x3 = makecons(&allocp[10]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  unify_value(a4, x3);
  allocp[0] = NILATOM;
  x6 = car_of(a3);
  allocp[1] = x6;
  x5 = makecons(&allocp[0]);
  allocp[2] = NILATOM;
  allocp[3] = x4;
  x7 = makecons(&allocp[2]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_typeset_xmake__shared__ts_8);
  allocp[6] = a0;
  allocp[7] = a1;
  allocp[8] = x5;
  allocp[9] = x7;
  allocp[10] = a2;
  allocp[11] = a5;
  allocp[12] = a6;
  allocp[13] = x2;
  qp = (struct goalrec*)&allocp[4];
  allocp += 14;
  proceed();
 case VARREF:
  deref_and_jump(a3,expand__loopgoal_8_4);
  *reasonp++ =  a3;
  goto expand__loopgoal_8_interrupt;
  };
  goto expand__loopgoal_8_interrupt;
 expand__loopgoal_8_ext_interrupt:
  reasonp = 0l;
 expand__loopgoal_8_interrupt:
  toppred = &predicate_hb_xexpand__loopgoal_8;
  goto interrupt_8;
 }

 get__headlist_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 get__headlist_9_clear_reason:
  reasonp = reasons;
 get__headlist_9_0:
 get__headlist_9_1:
  if (!isint(a0)) goto get__headlist_9_12;
  x0 = makeint(0L);
  gblt_greater(a0,x0,get__headlist_9_11);
 get__headlist_9_2:
  if (isref(a1)) goto get__headlist_9_10;
  gblt_arg(a0,a1,x1,get__headlist_9_11);
 get__headlist_9_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  switch (symval(functor_of(x1))) {
 case functor_arg_2:
  x2 = arg(x1, 0);
 get__headlist_9_4:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_goal_4)) goto get__headlist_9_11;
  x3 = arg(x1, 1);
 get__headlist_9_5:
  switch (ptagof(x3)) {
 case FUNCTOR:
  if (functor_of(x3) != makesym(functor_variable_3)) goto get__headlist_9_11;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xget__headlist_9);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x5 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x4;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_hb_xor__typeset_9);
  allocp[18] = makesym(atom__2D);
  allocp[19] = x7 = makeref(&allocp[19]);
  allocp[20] = a2;
  allocp[21] = x5;
  allocp[22] = a4;
  allocp[23] = a5;
  allocp[24] = a6;
  allocp[25] = a7;
  allocp[26] = x6;
  allocp[27] = (q)(struct goalrec*)&allocp[16];
  allocp[28] = (q)(&predicate_typeset_xget_5);
  x8 = arg(x2, 0);
  allocp[29] = x8;
  x9 = arg(x2, 1);
  allocp[30] = x9;
  x10 = arg(x3, 0);
  allocp[31] = x10;
  allocp[32] = x7;
  allocp[33] = a7;
  qp = (struct goalrec*)&allocp[27];
  allocp += 34;
  proceed();
 case VARREF:
  deref_and_jump(x3,get__headlist_9_5);
  *reasonp++ =  x3;
  goto get__headlist_9_11;
  };
  goto get__headlist_9_11;
 case VARREF:
  deref_and_jump(x2,get__headlist_9_4);
  *reasonp++ =  x2;
  goto get__headlist_9_11;
  };
  goto get__headlist_9_11;
 case functor_looparg_2:
  x2 = arg(x1, 0);
 get__headlist_9_6:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_goal_4)) goto get__headlist_9_11;
  x3 = arg(x1, 1);
 get__headlist_9_7:
  switch (ptagof(x3)) {
 case FUNCTOR:
  if (functor_of(x3) != makesym(functor_variable_3)) goto get__headlist_9_11;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xget__headlist_9);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x5 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x4;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_hb_xor__typeset_9);
  allocp[18] = makesym(atom__2D);
  allocp[19] = x7 = makeref(&allocp[19]);
  allocp[20] = a2;
  allocp[21] = x5;
  allocp[22] = a4;
  allocp[23] = a5;
  allocp[24] = a6;
  allocp[25] = a7;
  allocp[26] = x6;
  allocp[27] = (q)(struct goalrec*)&allocp[16];
  allocp[28] = (q)(&predicate_typeset_xget_5);
  x8 = arg(x2, 0);
  allocp[29] = x8;
  x9 = arg(x2, 1);
  allocp[30] = x9;
  x10 = arg(x3, 0);
  allocp[31] = x10;
  allocp[32] = x7;
  allocp[33] = a7;
  qp = (struct goalrec*)&allocp[27];
  allocp += 34;
  proceed();
 case VARREF:
  deref_and_jump(x3,get__headlist_9_7);
  *reasonp++ =  x3;
  goto get__headlist_9_11;
  };
  goto get__headlist_9_11;
 case VARREF:
  deref_and_jump(x2,get__headlist_9_6);
  *reasonp++ =  x2;
  goto get__headlist_9_11;
  };
  goto get__headlist_9_11;
 case functor_sharedarg_2:
  x2 = arg(x1, 0);
 get__headlist_9_8:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_goal_4)) goto get__headlist_9_11;
  x3 = arg(x1, 1);
 get__headlist_9_9:
  switch (ptagof(x3)) {
 case FUNCTOR:
  if (functor_of(x3) != makesym(functor_variable_3)) goto get__headlist_9_11;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xget__headlist_9);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x5 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x4;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_hb_xor__typeset_9);
  allocp[18] = makesym(atom__2D);
  allocp[19] = x7 = makeref(&allocp[19]);
  allocp[20] = a2;
  allocp[21] = x5;
  allocp[22] = a4;
  allocp[23] = a5;
  allocp[24] = a6;
  allocp[25] = a7;
  allocp[26] = x6;
  allocp[27] = (q)(struct goalrec*)&allocp[16];
  allocp[28] = (q)(&predicate_typeset_xget_5);
  x8 = arg(x2, 0);
  allocp[29] = x8;
  x9 = arg(x2, 1);
  allocp[30] = x9;
  x10 = arg(x3, 0);
  allocp[31] = x10;
  allocp[32] = x7;
  allocp[33] = a7;
  qp = (struct goalrec*)&allocp[27];
  allocp += 34;
  proceed();
 case VARREF:
  deref_and_jump(x3,get__headlist_9_9);
  *reasonp++ =  x3;
  goto get__headlist_9_11;
  };
  goto get__headlist_9_11;
 case VARREF:
  deref_and_jump(x2,get__headlist_9_8);
  *reasonp++ =  x2;
  goto get__headlist_9_11;
  };
  goto get__headlist_9_11;
  };
  goto get__headlist_9_11;
 case VARREF:
  deref_and_jump(x1,get__headlist_9_3);
  *reasonp++ =  x1;
  goto get__headlist_9_11;
  };
  goto get__headlist_9_11;
 get__headlist_9_10:
  deref_and_jump(a1,get__headlist_9_2);
  *reasonp++ =  a1;
  goto get__headlist_9_11;
 get__headlist_9_11:
  if (a0 != makeint(0L)) goto get__headlist_9_interrupt;
  unify2(a8, a7, a3, a2);
  proceed();
 get__headlist_9_12:
  if (!isref(a0)) goto get__headlist_9_interrupt;
  deref_and_jump(a0,get__headlist_9_1);
  *reasonp++ =  a0;
  goto get__headlist_9_interrupt;
 get__headlist_9_ext_interrupt:
  reasonp = 0l;
 get__headlist_9_interrupt:
  goto interrupt_9;
 }

 check__shared_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 check__shared_4_clear_reason:
  reasonp = reasons;
 check__shared_4_0:
 check__shared_4_1:
  switch (ptagof(a2)) {
 case CONS:
  x0 = car_of(a2);
 check__shared_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto check__shared_4_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xcheck__shared_4);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  x2 = cdr_of(a2);
  allocp[4] = x2;
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = makesym(functor_module_2);
  x5 = arg(x0, 0);
  allocp[7] = x5;
  allocp[8] = x6 = makeref(&allocp[8]);
  x4 = makefunctor(&allocp[6]);
  allocp[9] = x3;
  allocp[10] = x4;
  x7 = makecons(&allocp[9]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 11;
  unify_value(a3, x7);
  x8 = arg(x0, 1);
  a1 = x6;
  a2 = a0;
  a3 = x1;
  a0 = x8;
  execute(check__hb_4_0);
  goto check__hb_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,check__shared_4_2);
  *reasonp++ =  x0;
  goto check__shared_4_interrupt;
  };
  goto check__shared_4_interrupt;
 case ATOMIC:
  if (a2 != NILATOM) goto check__shared_4_interrupt;
  unify(a1, a0);
  x0 = NILATOM;
  unify_value(a3, x0);
  proceed();
 case VARREF:
  deref_and_jump(a2,check__shared_4_1);
  *reasonp++ =  a2;
  goto check__shared_4_interrupt;
  };
  goto check__shared_4_interrupt;
 check__shared_4_ext_interrupt:
  reasonp = 0l;
 check__shared_4_interrupt:
  goto interrupt_4;
 }

 check__hb_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 check__hb_4_clear_reason:
  reasonp = reasons;
 check__hb_4_0:
 check__hb_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 check__hb_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_7)) goto check__hb_4_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xcheck__hb_4);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x2;
  allocp[7] = x5 = makeref(&allocp[7]);
  x4 = makecons(&allocp[6]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  unify_value(a1, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = makeint(5L);
  allocp[3] = x6 = makeref(&allocp[3]);
  allocp[4] = x7 = makeref(&allocp[4]);
  allocp[5] = x5;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[8] = makeint(4L);
  allocp[9] = x0;
  allocp[10] = x8 = makeref(&allocp[10]);
  allocp[11] = x6;
  a0 = arg(x0, 3);
  a1 = x8;
  x9 = arg(x0, 4);
  a3 = x7;
  a4 = a2;
  a5 = x3;
  a2 = x9;
  qp = (struct goalrec*)&allocp[6];
  allocp += 12;
  execute(check__shared__bodys_6_0);
  goto check__shared__bodys_6_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,check__hb_4_2);
  *reasonp++ =  x0;
  goto check__hb_4_interrupt;
  };
  goto check__hb_4_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto check__hb_4_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,check__hb_4_1);
  *reasonp++ =  a0;
  goto check__hb_4_interrupt;
  };
  goto check__hb_4_interrupt;
 check__hb_4_ext_interrupt:
  reasonp = 0l;
 check__hb_4_interrupt:
  toppred = &predicate_hb_xcheck__hb_4;
  goto interrupt_4;
 }

 check__shared__bodys_6_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 check__shared__bodys_6_clear_reason:
  reasonp = reasons;
 check__shared__bodys_6_0:
 check__shared__bodys_6_1:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_bodyargs)) goto check__shared__bodys_6_2;
  unify(a1, a0);
  x0 = makesym(atom_bodyargs);
  unify_value(a3, x0);
  unify(a5, a4);
  proceed();
 case VARREF:
  deref_and_jump(a2,check__shared__bodys_6_1);
  *reasonp++ =  a2;
  goto check__shared__bodys_6_2;
  };
  goto check__shared__bodys_6_2;
 check__shared__bodys_6_2:
  otherwise(check__shared__bodys_6_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xcheck__shared__bodys1_7);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[11] = a2;
  allocp[12] = x1 = makeref(&allocp[12]);
  allocp[13] = x0;
  qp = (struct goalrec*)&allocp[9];
  allocp += 14;
  proceed();
 check__shared__bodys_6_ext_interrupt:
  reasonp = 0l;
 check__shared__bodys_6_interrupt:
  toppred = &predicate_hb_xcheck__shared__bodys_6;
  goto interrupt_6;
 }

 check__shared__bodys1_7_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 check__shared__bodys1_7_clear_reason:
  reasonp = reasons;
 check__shared__bodys1_7_0:
 check__shared__bodys1_7_1:
  if (!isint(a0)) goto check__shared__bodys1_7_6;
  x0 = makeint(0L);
  gblt_greater(a0,x0,check__shared__bodys1_7_7);
 check__shared__bodys1_7_2:
  if (isref(a3)) goto check__shared__bodys1_7_5;
  gblt_arg(a0,a3,x1,check__shared__bodys1_7_7);
 check__shared__bodys1_7_3:
  if (isref(x1)) goto check__shared__bodys1_7_4;
  gblt_pfunctor(x1,x2,check__shared__bodys1_7_7);
  gblt_arity(x1,x3,check__shared__bodys1_7_7);
  x4 = makeint(2L);
  gblt_greater_or_eq(x3,x4,check__shared__bodys1_7_7);
  execute(check__shared__bodys2_7_0);
  goto check__shared__bodys2_7_ext_interrupt;
 check__shared__bodys1_7_4:
  deref_and_jump(x1,check__shared__bodys1_7_3);
  *reasonp++ =  x1;
  goto check__shared__bodys1_7_7;
 check__shared__bodys1_7_5:
  deref_and_jump(a3,check__shared__bodys1_7_2);
  *reasonp++ =  a3;
  goto check__shared__bodys1_7_7;
 check__shared__bodys1_7_6:
  if (!isref(a0)) goto check__shared__bodys1_7_7;
  deref_and_jump(a0,check__shared__bodys1_7_1);
  *reasonp++ =  a0;
  goto check__shared__bodys1_7_7;
 check__shared__bodys1_7_7:
  otherwise(check__shared__bodys1_7_interrupt);
 check__shared__bodys1_7_8:
  switch (ptagof(a0)) {
 case ATOMIC:
 check__shared__bodys1_7_9:
  if (a0 != makeint(0L)) goto check__shared__bodys1_7_10;
  unify3(a2, a1, a4, a3, a6, a5);
  proceed();
 case VARREF:
  deref_and_jump(a0,check__shared__bodys1_7_8);
  *reasonp++ =  a0;
  goto check__shared__bodys1_7_10;
  };
  goto check__shared__bodys1_7_10;
 check__shared__bodys1_7_10:
  otherwise(check__shared__bodys1_7_interrupt);
 check__shared__bodys1_7_11:
  if (!isint(a0)) goto check__shared__bodys1_7_12;
  x0 = makeint(0L);
  gblt_greater(a0,x0,check__shared__bodys1_7_interrupt);
  x1 = makeint(1L);
  bblt_sub_no_check(a0,x1,x2);
  a0 = x2;
  execute(check__shared__bodys1_7_0);
  goto check__shared__bodys1_7_ext_interrupt;
 check__shared__bodys1_7_12:
  if (!isref(a0)) goto check__shared__bodys1_7_interrupt;
  deref_and_jump(a0,check__shared__bodys1_7_11);
  *reasonp++ =  a0;
  goto check__shared__bodys1_7_interrupt;
 check__shared__bodys1_7_ext_interrupt:
  reasonp = 0l;
 check__shared__bodys1_7_interrupt:
  goto interrupt_7;
 }

 check__shared__bodys2_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 check__shared__bodys2_7_clear_reason:
  reasonp = reasons;
 check__shared__bodys2_7_0:
 check__shared__bodys2_7_1:
  if (!isint(a0)) goto check__shared__bodys2_7_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,check__shared__bodys2_7_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xcheck__shared__bodys1_7);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x4 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[11] = a0;
  allocp[12] = makeint(1L);
  allocp[13] = x1;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[16] = a0;
  allocp[17] = a3;
  allocp[18] = x5 = makeref(&allocp[18]);
  allocp[19] = x3;
  allocp[20] = (q)(struct goalrec*)&allocp[14];
  allocp[21] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[22] = a0;
  allocp[23] = a1;
  allocp[24] = x6 = makeref(&allocp[24]);
  allocp[25] = x2;
  allocp[26] = (q)(struct goalrec*)&allocp[20];
  allocp[27] = (q)(&predicate_hb_xcheck__headargs_3);
  allocp[28] = x7 = makeref(&allocp[28]);
  allocp[29] = x8 = makeref(&allocp[29]);
  allocp[30] = x6;
  allocp[31] = (q)(struct goalrec*)&allocp[26];
  allocp[32] = (q)(&predicate_hb_xcheck__shared__bodys3_5);
  allocp[33] = x7;
  allocp[34] = x9 = makeref(&allocp[34]);
  allocp[35] = x5;
  allocp[36] = a5;
  allocp[37] = x4;
  allocp[38] = (q)(struct goalrec*)&allocp[31];
  allocp[39] = (q)(&predicate_functor_xsearch__functorname_3);
  allocp[40] = makesym(atom_recursivearg);
  allocp[41] = x9;
  allocp[42] = x7;
  allocp[43] = (q)(struct goalrec*)&allocp[38];
  allocp[44] = (q)(&predicate_functor__table_xarg_3);
  allocp[45] = a0;
  allocp[46] = a3;
  allocp[47] = x9;
  allocp[48] = (q)(struct goalrec*)&allocp[43];
  allocp[49] = (q)(&predicate_functor__table_xarg_3);
  allocp[50] = a0;
  allocp[51] = a1;
  allocp[52] = x8;
  qp = (struct goalrec*)&allocp[48];
  allocp += 53;
  proceed();
 check__shared__bodys2_7_2:
  if (a0 != makeint(0L)) goto check__shared__bodys2_7_interrupt;
  unify3(a2, a1, a4, a3, a6, a5);
  proceed();
 check__shared__bodys2_7_3:
  if (!isref(a0)) goto check__shared__bodys2_7_interrupt;
  deref_and_jump(a0,check__shared__bodys2_7_1);
  *reasonp++ =  a0;
  goto check__shared__bodys2_7_interrupt;
 check__shared__bodys2_7_ext_interrupt:
  reasonp = 0l;
 check__shared__bodys2_7_interrupt:
  toppred = &predicate_hb_xcheck__shared__bodys2_7;
  goto interrupt_7;
 }

 check__shared__bodys3_5_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 check__shared__bodys3_5_clear_reason:
  reasonp = reasons;
 check__shared__bodys3_5_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xcheck__shared__bodys4_6);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[10] = a1;
  allocp[11] = x1 = makeref(&allocp[11]);
  allocp[12] = x0;
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  proceed();
 check__shared__bodys3_5_ext_interrupt:
  reasonp = 0l;
 check__shared__bodys3_5_interrupt:
  goto interrupt_5;
 }

 check__shared__bodys4_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 check__shared__bodys4_6_clear_reason:
  reasonp = reasons;
 check__shared__bodys4_6_0:
 check__shared__bodys4_6_1:
  if (!isint(a0)) goto check__shared__bodys4_6_6;
  x0 = makeint(0L);
  gblt_greater(a0,x0,check__shared__bodys4_6_5);
 check__shared__bodys4_6_2:
  if (isref(a2)) goto check__shared__bodys4_6_4;
  gblt_arg(a0,a2,x1,check__shared__bodys4_6_5);
 check__shared__bodys4_6_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_recursivearg_2)) goto check__shared__bodys4_6_5;
  x2 = makeint(1L);
  bblt_sub_no_check(a0,x2,x3);
  a0 = x3;
  execute(check__shared__bodys4_6_0);
  goto check__shared__bodys4_6_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,check__shared__bodys4_6_3);
  *reasonp++ =  x1;
  goto check__shared__bodys4_6_5;
  };
  goto check__shared__bodys4_6_5;
 check__shared__bodys4_6_4:
  deref_and_jump(a2,check__shared__bodys4_6_2);
  *reasonp++ =  a2;
  goto check__shared__bodys4_6_5;
 check__shared__bodys4_6_5:
  if (a0 != makeint(0L)) goto check__shared__bodys4_6_7;
  unify2(a3, a2, a5, a4);
  proceed();
 check__shared__bodys4_6_6:
  if (!isref(a0)) goto check__shared__bodys4_6_7;
  deref_and_jump(a0,check__shared__bodys4_6_1);
  *reasonp++ =  a0;
  goto check__shared__bodys4_6_7;
 check__shared__bodys4_6_7:
  otherwise(check__shared__bodys4_6_interrupt);
 check__shared__bodys4_6_8:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (isint(a1)) goto check__shared__bodys4_6_interrupt;
  switch (symval(a1)) {
 case symval(makesym(atom_yes)):
 check__shared__bodys4_6_9:
  if (!isint(a0)) goto check__shared__bodys4_6_10;
  x0 = makeint(0L);
  gblt_greater(a0,x0,check__shared__bodys4_6_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xcheck__shared__bodys4_6);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = makesym(atom_yes);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[10] = a0;
  allocp[11] = makeint(1L);
  allocp[12] = x1;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_hb_xadd__entry_7);
  allocp[15] = x4 = makeref(&allocp[15]);
  allocp[16] = x5 = makeref(&allocp[16]);
  allocp[17] = x6 = makeref(&allocp[17]);
  allocp[18] = x7 = makeref(&allocp[18]);
  allocp[19] = x8 = makeref(&allocp[19]);
  allocp[20] = a4;
  allocp[21] = x3;
  allocp[22] = (q)(struct goalrec*)&allocp[13];
  allocp[23] = (q)(&predicate_parse__uty_xdecode__goal_3);
  allocp[24] = x9 = makeref(&allocp[24]);
  allocp[25] = x7;
  allocp[26] = x8;
  allocp[27] = (q)(struct goalrec*)&allocp[22];
  allocp[28] = (q)(&predicate_parse__uty_xget__goal_6);
  allocp[29] = x4;
  allocp[30] = x5;
  allocp[31] = x6;
  allocp[32] = makesym(atom_body);
  allocp[33] = x9;
  allocp[34] = a4;
  allocp[35] = (q)(struct goalrec*)&allocp[27];
  allocp[36] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[37] = a0;
  allocp[38] = a2;
  allocp[39] = x10 = makeref(&allocp[39]);
  allocp[40] = x2;
  allocp[41] = makesym(functor_goal_4);
  allocp[42] = x4;
  allocp[43] = x5;
  allocp[44] = makesym(atom_body);
  allocp[45] = x6;
  x11 = makefunctor(&allocp[41]);
  allocp[46] = makesym(functor_entryarg_2);
  allocp[47] = x11;
  allocp[48] = x13 = makeref(&allocp[48]);
  x12 = makefunctor(&allocp[46]);
  qp = (struct goalrec*)&allocp[35];
  allocp += 49;
  unify_value(x10, x12);
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = x4;
  allocp[2] = x5;
  allocp[3] = makesym(atom_body);
  allocp[4] = x6;
  x14 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_arg_2);
  allocp[6] = x14;
  allocp[7] = x13;
  x15 = makefunctor(&allocp[5]);
  allocp[8] = (q)qp;
  allocp[9] = (q)(&predicate_functor__table_xarg_3);
  allocp[10] = a0;
  allocp[11] = a2;
  allocp[12] = x15;
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  proceed();
 check__shared__bodys4_6_10:
  if (!isref(a0)) goto check__shared__bodys4_6_interrupt;
  deref_and_jump(a0,check__shared__bodys4_6_9);
  *reasonp++ =  a0;
  goto check__shared__bodys4_6_interrupt;
 case symval(makesym(atom_no)):
 check__shared__bodys4_6_11:
  if (!isint(a0)) goto check__shared__bodys4_6_12;
  x0 = makeint(0L);
  gblt_greater(a0,x0,check__shared__bodys4_6_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xcheck__shared__bodys4_6);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = makesym(atom_no);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[10] = a0;
  allocp[11] = makeint(1L);
  allocp[12] = x1;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_hb_xadd__shared_7);
  allocp[15] = x4 = makeref(&allocp[15]);
  allocp[16] = x5 = makeref(&allocp[16]);
  allocp[17] = x6 = makeref(&allocp[17]);
  allocp[18] = x7 = makeref(&allocp[18]);
  allocp[19] = x8 = makeref(&allocp[19]);
  allocp[20] = a4;
  allocp[21] = x3;
  allocp[22] = (q)(struct goalrec*)&allocp[13];
  allocp[23] = (q)(&predicate_parse__uty_xdecode__goal_3);
  allocp[24] = x9 = makeref(&allocp[24]);
  allocp[25] = x7;
  allocp[26] = x8;
  allocp[27] = (q)(struct goalrec*)&allocp[22];
  allocp[28] = (q)(&predicate_parse__uty_xget__goal_6);
  allocp[29] = x4;
  allocp[30] = x5;
  allocp[31] = x6;
  allocp[32] = makesym(atom_body);
  allocp[33] = x9;
  allocp[34] = a4;
  allocp[35] = (q)(struct goalrec*)&allocp[27];
  allocp[36] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[37] = a0;
  allocp[38] = a2;
  allocp[39] = x10 = makeref(&allocp[39]);
  allocp[40] = x2;
  allocp[41] = makesym(functor_goal_4);
  allocp[42] = x4;
  allocp[43] = x5;
  allocp[44] = makesym(atom_body);
  allocp[45] = x6;
  x11 = makefunctor(&allocp[41]);
  allocp[46] = makesym(functor_sharedarg_2);
  allocp[47] = x11;
  allocp[48] = x13 = makeref(&allocp[48]);
  x12 = makefunctor(&allocp[46]);
  qp = (struct goalrec*)&allocp[35];
  allocp += 49;
  unify_value(x10, x12);
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = x4;
  allocp[2] = x5;
  allocp[3] = makesym(atom_body);
  allocp[4] = x6;
  x14 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_arg_2);
  allocp[6] = x14;
  allocp[7] = x13;
  x15 = makefunctor(&allocp[5]);
  allocp[8] = (q)qp;
  allocp[9] = (q)(&predicate_functor__table_xarg_3);
  allocp[10] = a0;
  allocp[11] = a2;
  allocp[12] = x15;
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  proceed();
 check__shared__bodys4_6_12:
  if (!isref(a0)) goto check__shared__bodys4_6_interrupt;
  deref_and_jump(a0,check__shared__bodys4_6_11);
  *reasonp++ =  a0;
  goto check__shared__bodys4_6_interrupt;
  };
  goto check__shared__bodys4_6_interrupt;
 case VARREF:
  deref_and_jump(a1,check__shared__bodys4_6_8);
  *reasonp++ =  a1;
  goto check__shared__bodys4_6_interrupt;
  };
  goto check__shared__bodys4_6_interrupt;
 check__shared__bodys4_6_ext_interrupt:
  reasonp = 0l;
 check__shared__bodys4_6_interrupt:
  goto interrupt_6;
 }

 check__headargs_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 check__headargs_3_clear_reason:
  reasonp = reasons;
 check__headargs_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xcheck__headargs_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[8] = a1;
  allocp[9] = x1 = makeref(&allocp[9]);
  allocp[10] = x0;
  qp = (struct goalrec*)&allocp[6];
  allocp += 11;
  proceed();
 check__headargs_3_ext_interrupt:
  reasonp = 0l;
 check__headargs_3_interrupt:
  goto interrupt_3;
 }

 check__headargs_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 check__headargs_4_clear_reason:
  reasonp = reasons;
 check__headargs_4_0:
 check__headargs_4_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (isint(a1)) goto check__headargs_4_6;
  switch (symval(a1)) {
 case symval(makesym(atom_yes)):
 check__headargs_4_2:
  if (!isint(a0)) goto check__headargs_4_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,check__headargs_4_6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xcheck__headargs_4);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = makesym(atom_yes);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x1;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[13] = a0;
  allocp[14] = a2;
  allocp[15] = x3 = makeref(&allocp[15]);
  allocp[16] = x2;
  allocp[17] = makesym(functor_looparg_2);
  allocp[18] = x5 = makeref(&allocp[18]);
  allocp[19] = x6 = makeref(&allocp[19]);
  x4 = makefunctor(&allocp[17]);
  qp = (struct goalrec*)&allocp[11];
  allocp += 20;
  unify_value(x3, x4);
  allocp[0] = makesym(functor_arg_2);
  allocp[1] = x5;
  allocp[2] = x6;
  x7 = makefunctor(&allocp[0]);
  allocp[3] = (q)qp;
  allocp[4] = (q)(&predicate_functor__table_xarg_3);
  allocp[5] = a0;
  allocp[6] = a2;
  allocp[7] = x7;
  qp = (struct goalrec*)&allocp[3];
  allocp += 8;
  proceed();
 check__headargs_4_3:
  if (!isref(a0)) goto check__headargs_4_6;
  deref_and_jump(a0,check__headargs_4_2);
  *reasonp++ =  a0;
  goto check__headargs_4_6;
 case symval(makesym(atom_no)):
 check__headargs_4_4:
  if (!isint(a0)) goto check__headargs_4_5;
  x0 = makeint(0L);
  gblt_greater(a0,x0,check__headargs_4_6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xcheck__headargs_4);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = makesym(atom_no);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x1;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[13] = a0;
  allocp[14] = a2;
  allocp[15] = x3 = makeref(&allocp[15]);
  allocp[16] = x2;
  allocp[17] = makesym(functor_sharedarg_2);
  allocp[18] = x5 = makeref(&allocp[18]);
  allocp[19] = x6 = makeref(&allocp[19]);
  x4 = makefunctor(&allocp[17]);
  qp = (struct goalrec*)&allocp[11];
  allocp += 20;
  unify_value(x3, x4);
  allocp[0] = makesym(functor_arg_2);
  allocp[1] = x5;
  allocp[2] = x6;
  x7 = makefunctor(&allocp[0]);
  allocp[3] = (q)qp;
  allocp[4] = (q)(&predicate_functor__table_xarg_3);
  allocp[5] = a0;
  allocp[6] = a2;
  allocp[7] = x7;
  qp = (struct goalrec*)&allocp[3];
  allocp += 8;
  proceed();
 check__headargs_4_5:
  if (!isref(a0)) goto check__headargs_4_6;
  deref_and_jump(a0,check__headargs_4_4);
  *reasonp++ =  a0;
  goto check__headargs_4_6;
  };
  goto check__headargs_4_6;
 case VARREF:
  deref_and_jump(a1,check__headargs_4_1);
  *reasonp++ =  a1;
  goto check__headargs_4_6;
  };
  goto check__headargs_4_6;
 check__headargs_4_6:
  otherwise(check__headargs_4_interrupt);
 check__headargs_4_7:
  switch (ptagof(a0)) {
 case ATOMIC:
 check__headargs_4_8:
  if (a0 != makeint(0L)) goto check__headargs_4_interrupt;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,check__headargs_4_7);
  *reasonp++ =  a0;
  goto check__headargs_4_interrupt;
  };
  goto check__headargs_4_interrupt;
 check__headargs_4_ext_interrupt:
  reasonp = 0l;
 check__headargs_4_interrupt:
  goto interrupt_4;
 }

 add__shared_7_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 add__shared_7_clear_reason:
  reasonp = reasons;
 add__shared_7_0:
 add__shared_7_1:
  switch (ptagof(a4)) {
 case FUNCTOR:
  if (functor_of(a4) != makesym(functor_options_2)) goto add__shared_7_3;
  x0 = arg(a4, 1);
 add__shared_7_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom___)) goto add__shared_7_3;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_parse__uty_xupdate__goal_7);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = makesym(atom_body);
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_parse__uty_xencode__goal_3);
  allocp[11] = a3;
  allocp[12] = x2 = makeref(&allocp[12]);
  allocp[13] = x1;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[16] = makeint(2L);
  allocp[17] = a4;
  allocp[18] = makefunctor(funct_const_2);
  allocp[19] = x2;
  qp = (struct goalrec*)&allocp[14];
  allocp += 20;
  proceed();
 case VARREF:
  deref_and_jump(x0,add__shared_7_2);
  *reasonp++ =  x0;
  goto add__shared_7_3;
  };
  goto add__shared_7_3;
 case VARREF:
  deref_and_jump(a4,add__shared_7_1);
  *reasonp++ =  a4;
  goto add__shared_7_3;
  };
  goto add__shared_7_3;
 add__shared_7_3:
  otherwise(add__shared_7_interrupt);
  unify(a6, a5);
  proceed();
 add__shared_7_ext_interrupt:
  reasonp = 0l;
 add__shared_7_interrupt:
  goto interrupt_7;
 }

 add__entry_7_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 add__entry_7_clear_reason:
  reasonp = reasons;
 add__entry_7_0:
 add__entry_7_1:
  switch (ptagof(a4)) {
 case FUNCTOR:
  if (functor_of(a4) != makesym(functor_options_2)) goto add__entry_7_4;
  x0 = arg(a4, 1);
 add__entry_7_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom___)) goto add__entry_7_4;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_parse__uty_xupdate__goal_7);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = makesym(atom_body);
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_parse__uty_xencode__goal_3);
  allocp[11] = a3;
  allocp[12] = x2 = makeref(&allocp[12]);
  allocp[13] = x1;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[16] = makeint(2L);
  allocp[17] = a4;
  allocp[18] = makefunctor(funct_const_1);
  allocp[19] = x2;
  qp = (struct goalrec*)&allocp[14];
  allocp += 20;
  proceed();
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_atom_1)) goto add__entry_7_4;
  x1 = arg(x0, 0);
 add__entry_7_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_shared)) goto add__entry_7_4;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_parse__uty_xupdate__goal_7);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = makesym(atom_body);
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_parse__uty_xencode__goal_3);
  allocp[11] = a3;
  allocp[12] = x3 = makeref(&allocp[12]);
  allocp[13] = x2;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[16] = makeint(2L);
  allocp[17] = a4;
  allocp[18] = makefunctor(funct_const_1);
  allocp[19] = x3;
  qp = (struct goalrec*)&allocp[14];
  allocp += 20;
  proceed();
 case VARREF:
  deref_and_jump(x1,add__entry_7_3);
  *reasonp++ =  x1;
  goto add__entry_7_4;
  };
  goto add__entry_7_4;
 case VARREF:
  deref_and_jump(x0,add__entry_7_2);
  *reasonp++ =  x0;
  goto add__entry_7_4;
  };
  goto add__entry_7_4;
 case VARREF:
  deref_and_jump(a4,add__entry_7_1);
  *reasonp++ =  a4;
  goto add__entry_7_4;
  };
  goto add__entry_7_4;
 add__entry_7_4:
  otherwise(add__entry_7_interrupt);
  unify(a6, a5);
  proceed();
 add__entry_7_ext_interrupt:
  reasonp = 0l;
 add__entry_7_interrupt:
  goto interrupt_7;
 }

 read__mode_6_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 read__mode_6_clear_reason:
  reasonp = reasons;
 read__mode_6_0:
 read__mode_6_1:
  switch (ptagof(a5)) {
 case CONS:
  x0 = car_of(a5);
 read__mode_6_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto read__mode_6_7;
  x1 = arg(x0, 0);
 read__mode_6_3:
  if (isref(x1)) goto read__mode_6_6;
 read__mode_6_4:
  if (isref(x1)) goto read__mode_6_5;
  if_not_equal(x1, a0, read__mode_6_7);
  a0 = arg(x0, 1);
  execute(read__mode__preds_5_clear_reason);
  goto read__mode__preds_5_ext_interrupt;
 read__mode_6_5:
  deref_and_jump(x1,read__mode_6_4);
  *reasonp++ =  x1;
  goto read__mode_6_7;
 read__mode_6_6:
  deref_and_jump(x1,read__mode_6_3);
  *reasonp++ =  x1;
  goto read__mode_6_7;
 case VARREF:
  deref_and_jump(x0,read__mode_6_2);
  *reasonp++ =  x0;
  goto read__mode_6_7;
  };
  goto read__mode_6_7;
 case VARREF:
  deref_and_jump(a5,read__mode_6_1);
  *reasonp++ =  a5;
  goto read__mode_6_7;
  };
  goto read__mode_6_7;
 read__mode_6_7:
  otherwise(read__mode_6_interrupt);
 read__mode_6_8:
  switch (ptagof(a5)) {
 case CONS:
  a5 = cdr_of(a5);
  execute(read__mode_6_0);
  goto read__mode_6_ext_interrupt;
 case ATOMIC:
  if (a5 != NILATOM) goto read__mode_6_interrupt;
  x0 = makesym(atom__3F);
  unify_value(a4, x0);
  proceed();
 case VARREF:
  deref_and_jump(a5,read__mode_6_8);
  *reasonp++ =  a5;
  goto read__mode_6_interrupt;
  };
  goto read__mode_6_interrupt;
 read__mode_6_ext_interrupt:
  reasonp = 0l;
 read__mode_6_interrupt:
  goto interrupt_6;
 }

 read__mode__preds_5_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 read__mode__preds_5_clear_reason:
  reasonp = reasons;
 read__mode__preds_5_0:
 read__mode__preds_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 read__mode__preds_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_7)) goto read__mode__preds_5_11;
  x1 = arg(x0, 0);
 read__mode__preds_5_3:
  if (isref(x1)) goto read__mode__preds_5_10;
 read__mode__preds_5_4:
  if (isref(x1)) goto read__mode__preds_5_9;
  if_not_equal(x1, a1, read__mode__preds_5_11);
  x2 = arg(x0, 1);
 read__mode__preds_5_5:
  if (isref(x2)) goto read__mode__preds_5_8;
 read__mode__preds_5_6:
  if (isref(x2)) goto read__mode__preds_5_7;
  if_not_equal(x2, a2, read__mode__preds_5_11);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = a3;
  x3 = arg(x0, 2);
  allocp[3] = x3;
  allocp[4] = a4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 read__mode__preds_5_7:
  deref_and_jump(x2,read__mode__preds_5_6);
  *reasonp++ =  x2;
  goto read__mode__preds_5_11;
 read__mode__preds_5_8:
  deref_and_jump(x2,read__mode__preds_5_5);
  *reasonp++ =  x2;
  goto read__mode__preds_5_11;
 read__mode__preds_5_9:
  deref_and_jump(x1,read__mode__preds_5_4);
  *reasonp++ =  x1;
  goto read__mode__preds_5_11;
 read__mode__preds_5_10:
  deref_and_jump(x1,read__mode__preds_5_3);
  *reasonp++ =  x1;
  goto read__mode__preds_5_11;
 case VARREF:
  deref_and_jump(x0,read__mode__preds_5_2);
  *reasonp++ =  x0;
  goto read__mode__preds_5_11;
  };
  goto read__mode__preds_5_11;
 case VARREF:
  deref_and_jump(a0,read__mode__preds_5_1);
  *reasonp++ =  a0;
  goto read__mode__preds_5_11;
  };
  goto read__mode__preds_5_11;
 read__mode__preds_5_11:
  otherwise(read__mode__preds_5_interrupt);
 read__mode__preds_5_12:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(read__mode__preds_5_0);
  goto read__mode__preds_5_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto read__mode__preds_5_interrupt;
  x0 = makesym(atom__3F);
  unify_value(a4, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,read__mode__preds_5_12);
  *reasonp++ =  a0;
  goto read__mode__preds_5_interrupt;
  };
  goto read__mode__preds_5_interrupt;
 read__mode__preds_5_ext_interrupt:
  reasonp = 0l;
 read__mode__preds_5_interrupt:
  toppred = &predicate_hb_xread__mode__preds_5;
  goto interrupt_5;
 }

 write__mode_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 write__mode_7_clear_reason:
  reasonp = reasons;
 write__mode_7_0:
 write__mode_7_1:
  switch (ptagof(a5)) {
 case CONS:
  x0 = car_of(a5);
 write__mode_7_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto write__mode_7_7;
  x1 = arg(x0, 0);
 write__mode_7_3:
  if (isref(x1)) goto write__mode_7_6;
 write__mode_7_4:
  if (isref(x1)) goto write__mode_7_5;
  if_not_equal(x1, a0, write__mode_7_7);
  allocp[0] = makesym(functor_module_2);
  allocp[1] = a0;
  allocp[2] = x3 = makeref(&allocp[2]);
  x2 = makefunctor(&allocp[0]);
  x5 = cdr_of(a5);
  allocp[3] = x5;
  allocp[4] = x2;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a6, x4);
  a0 = arg(x0, 1);
  x6 = a1;
  x7 = a2;
  x8 = a3;
  a5 = a4;
  a4 = x8;
  a3 = x7;
  a2 = x6;
  a1 = x3;
  execute(write__mode__preds_6_clear_reason);
  goto write__mode__preds_6_ext_interrupt;
 write__mode_7_5:
  deref_and_jump(x1,write__mode_7_4);
  *reasonp++ =  x1;
  goto write__mode_7_7;
 write__mode_7_6:
  deref_and_jump(x1,write__mode_7_3);
  *reasonp++ =  x1;
  goto write__mode_7_7;
 case VARREF:
  deref_and_jump(x0,write__mode_7_2);
  *reasonp++ =  x0;
  goto write__mode_7_7;
  };
  goto write__mode_7_7;
 case VARREF:
  deref_and_jump(a5,write__mode_7_1);
  *reasonp++ =  a5;
  goto write__mode_7_7;
  };
  goto write__mode_7_7;
 write__mode_7_7:
  otherwise(write__mode_7_interrupt);
 write__mode_7_8:
  switch (ptagof(a5)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a5);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a6, x0);
  a5 = cdr_of(a5);
  a6 = x1;
  execute(write__mode_7_0);
  goto write__mode_7_ext_interrupt;
 case ATOMIC:
  if (a5 != NILATOM) goto write__mode_7_interrupt;
  unify_value(a6, a5);
  proceed();
 case VARREF:
  deref_and_jump(a5,write__mode_7_8);
  *reasonp++ =  a5;
  goto write__mode_7_interrupt;
  };
  goto write__mode_7_interrupt;
 write__mode_7_ext_interrupt:
  reasonp = 0l;
 write__mode_7_interrupt:
  goto interrupt_7;
 }

 write__mode__preds_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 write__mode__preds_6_clear_reason:
  reasonp = reasons;
 write__mode__preds_6_0:
 write__mode__preds_6_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 write__mode__preds_6_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_7)) goto write__mode__preds_6_32;
  x1 = arg(x0, 0);
 write__mode__preds_6_3:
  if (isref(x1)) goto write__mode__preds_6_31;
 write__mode__preds_6_4:
  if (isref(x1)) goto write__mode__preds_6_30;
  if_not_equal(x1, a2, write__mode__preds_6_16);
  x2 = arg(x0, 1);
 write__mode__preds_6_5:
  if (isref(x2)) goto write__mode__preds_6_15;
 write__mode__preds_6_6:
  if (isref(x2)) goto write__mode__preds_6_14;
  if_not_equal(x2, a3, write__mode__preds_6_16);
 write__mode__preds_6_7:
  if (isref(a5)) goto write__mode__preds_6_13;
  x3 = makesym(atom__3F);
  gblt_diff(a5,x3,write__mode__preds_6_16);
 write__mode__preds_6_8:
  if (!isint(a4)) goto write__mode__preds_6_12;
  x4 = arg(x0, 2);
 write__mode__preds_6_9:
  if (isref(x4)) goto write__mode__preds_6_11;
  gblt_arg(a4,x4,x5,write__mode__preds_6_16);
 write__mode__preds_6_10:
  switch (ptagof(x5)) {
 case ATOMIC:
  if (x5 != makesym(atom_i)) goto write__mode__preds_6_16;
  unify_value(a1, a0);
  proceed();
 case VARREF:
  deref_and_jump(x5,write__mode__preds_6_10);
  *reasonp++ =  x5;
  goto write__mode__preds_6_16;
  };
  goto write__mode__preds_6_16;
 write__mode__preds_6_11:
  deref_and_jump(x4,write__mode__preds_6_9);
  *reasonp++ =  x4;
  goto write__mode__preds_6_16;
 write__mode__preds_6_12:
  if (!isref(a4)) goto write__mode__preds_6_16;
  deref_and_jump(a4,write__mode__preds_6_8);
  *reasonp++ =  a4;
  goto write__mode__preds_6_16;
 write__mode__preds_6_13:
  deref_and_jump(a5,write__mode__preds_6_7);
  *reasonp++ =  a5;
  goto write__mode__preds_6_16;
 write__mode__preds_6_14:
  deref_and_jump(x2,write__mode__preds_6_6);
  *reasonp++ =  x2;
  goto write__mode__preds_6_16;
 write__mode__preds_6_15:
  deref_and_jump(x2,write__mode__preds_6_5);
  *reasonp++ =  x2;
  goto write__mode__preds_6_16;
 write__mode__preds_6_16:
 write__mode__preds_6_17:
  if (isref(x1)) goto write__mode__preds_6_29;
  if_not_equal(x1, a2, write__mode__preds_6_32);
  x2 = arg(x0, 1);
 write__mode__preds_6_18:
  if (isref(x2)) goto write__mode__preds_6_28;
 write__mode__preds_6_19:
  if (isref(x2)) goto write__mode__preds_6_27;
  if_not_equal(x2, a3, write__mode__preds_6_32);
 write__mode__preds_6_20:
  if (isref(a5)) goto write__mode__preds_6_26;
  x3 = makesym(atom__3F);
  gblt_diff(a5,x3,write__mode__preds_6_32);
 write__mode__preds_6_21:
  if (!isint(a4)) goto write__mode__preds_6_25;
  x4 = arg(x0, 2);
 write__mode__preds_6_22:
  if (isref(x4)) goto write__mode__preds_6_24;
  gblt_arg(a4,x4,x5,write__mode__preds_6_32);
 write__mode__preds_6_23:
  switch (ptagof(x5)) {
 case ATOMIC:
  if (x5 != makesym(atom_o)) goto write__mode__preds_6_32;
  unify_value(a1, a0);
  proceed();
 case VARREF:
  deref_and_jump(x5,write__mode__preds_6_23);
  *reasonp++ =  x5;
  goto write__mode__preds_6_32;
  };
  goto write__mode__preds_6_32;
 write__mode__preds_6_24:
  deref_and_jump(x4,write__mode__preds_6_22);
  *reasonp++ =  x4;
  goto write__mode__preds_6_32;
 write__mode__preds_6_25:
  if (!isref(a4)) goto write__mode__preds_6_32;
  deref_and_jump(a4,write__mode__preds_6_21);
  *reasonp++ =  a4;
  goto write__mode__preds_6_32;
 write__mode__preds_6_26:
  deref_and_jump(a5,write__mode__preds_6_20);
  *reasonp++ =  a5;
  goto write__mode__preds_6_32;
 write__mode__preds_6_27:
  deref_and_jump(x2,write__mode__preds_6_19);
  *reasonp++ =  x2;
  goto write__mode__preds_6_32;
 write__mode__preds_6_28:
  deref_and_jump(x2,write__mode__preds_6_18);
  *reasonp++ =  x2;
  goto write__mode__preds_6_32;
 write__mode__preds_6_29:
  deref_and_jump(x1,write__mode__preds_6_17);
  *reasonp++ =  x1;
  goto write__mode__preds_6_32;
 write__mode__preds_6_30:
  deref_and_jump(x1,write__mode__preds_6_4);
  *reasonp++ =  x1;
  goto write__mode__preds_6_32;
 write__mode__preds_6_31:
  deref_and_jump(x1,write__mode__preds_6_3);
  *reasonp++ =  x1;
  goto write__mode__preds_6_32;
 case VARREF:
  deref_and_jump(x0,write__mode__preds_6_2);
  *reasonp++ =  x0;
  goto write__mode__preds_6_32;
  };
  goto write__mode__preds_6_32;
 case VARREF:
  deref_and_jump(a0,write__mode__preds_6_1);
  *reasonp++ =  a0;
  goto write__mode__preds_6_32;
  };
  goto write__mode__preds_6_32;
 write__mode__preds_6_32:
  otherwise(write__mode__preds_6_interrupt);
 write__mode__preds_6_33:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 write__mode__preds_6_34:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_7)) goto write__mode__preds_6_43;
  x1 = arg(x0, 0);
 write__mode__preds_6_35:
  if (isref(x1)) goto write__mode__preds_6_42;
 write__mode__preds_6_36:
  if (isref(x1)) goto write__mode__preds_6_41;
  if_not_equal(x1, a2, write__mode__preds_6_43);
  x2 = arg(x0, 1);
 write__mode__preds_6_37:
  if (isref(x2)) goto write__mode__preds_6_40;
 write__mode__preds_6_38:
  if (isref(x2)) goto write__mode__preds_6_39;
  if_not_equal(x2, a3, write__mode__preds_6_43);
  allocp[0] = makesym(functor_pred_7);
  allocp[1] = a2;
  allocp[2] = a3;
  allocp[3] = x4 = makeref(&allocp[3]);
  x5 = arg(x0, 3);
  allocp[4] = x5;
  x6 = arg(x0, 4);
  allocp[5] = x6;
  x7 = arg(x0, 5);
  allocp[6] = x7;
  x8 = arg(x0, 6);
  allocp[7] = x8;
  x3 = makefunctor(&allocp[0]);
  x10 = cdr_of(a0);
  allocp[8] = x10;
  allocp[9] = x3;
  x9 = makecons(&allocp[8]);
  allocp += 10;
  unify_value(a1, x9);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = a4;
  x11 = arg(x0, 2);
  allocp[3] = x11;
  allocp[4] = a5;
  allocp[5] = x4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  proceed();
 write__mode__preds_6_39:
  deref_and_jump(x2,write__mode__preds_6_38);
  *reasonp++ =  x2;
  goto write__mode__preds_6_43;
 write__mode__preds_6_40:
  deref_and_jump(x2,write__mode__preds_6_37);
  *reasonp++ =  x2;
  goto write__mode__preds_6_43;
 write__mode__preds_6_41:
  deref_and_jump(x1,write__mode__preds_6_36);
  *reasonp++ =  x1;
  goto write__mode__preds_6_43;
 write__mode__preds_6_42:
  deref_and_jump(x1,write__mode__preds_6_35);
  *reasonp++ =  x1;
  goto write__mode__preds_6_43;
 case VARREF:
  deref_and_jump(x0,write__mode__preds_6_34);
  *reasonp++ =  x0;
  goto write__mode__preds_6_43;
  };
  goto write__mode__preds_6_43;
 case VARREF:
  deref_and_jump(a0,write__mode__preds_6_33);
  *reasonp++ =  a0;
  goto write__mode__preds_6_43;
  };
  goto write__mode__preds_6_43;
 write__mode__preds_6_43:
  otherwise(write__mode__preds_6_interrupt);
 write__mode__preds_6_44:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(write__mode__preds_6_0);
  goto write__mode__preds_6_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto write__mode__preds_6_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,write__mode__preds_6_44);
  *reasonp++ =  a0;
  goto write__mode__preds_6_interrupt;
  };
  goto write__mode__preds_6_interrupt;
 write__mode__preds_6_ext_interrupt:
  reasonp = 0l;
 write__mode__preds_6_interrupt:
  toppred = &predicate_hb_xwrite__mode__preds_6;
  goto interrupt_6;
 }

 or__typeset_9_top: {
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 or__typeset_9_clear_reason:
  reasonp = reasons;
 or__typeset_9_0:
  a4 = a3;
  a3 = NILATOM;
  execute(or__typeset1_9_0);
  goto or__typeset1_9_ext_interrupt;
 or__typeset_9_ext_interrupt:
  reasonp = 0l;
 or__typeset_9_interrupt:
  goto interrupt_9;
 }

 or__typeset1_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 or__typeset1_9_clear_reason:
  reasonp = reasons;
 or__typeset1_9_0:
 or__typeset1_9_1:
  switch (ptagof(a6)) {
 case ATOMIC:
  if (a6 != makesym(atom_expand)) goto or__typeset1_9_2;
  unify(a8, a7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[2] = a3;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[7] = a1;
  allocp[8] = a2;
  allocp[9] = x0;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case VARREF:
  deref_and_jump(a6,or__typeset1_9_1);
  *reasonp++ =  a6;
  goto or__typeset1_9_2;
  };
  goto or__typeset1_9_2;
 or__typeset1_9_2:
  otherwise(or__typeset1_9_interrupt);
 or__typeset1_9_3:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 or__typeset1_9_4:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto or__typeset1_9_7;
  x1 = cdr_of(a1);
 or__typeset1_9_5:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto or__typeset1_9_7;
  unify(a8, a7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case VARREF:
  deref_and_jump(x1,or__typeset1_9_5);
  *reasonp++ =  x1;
  goto or__typeset1_9_7;
  };
  goto or__typeset1_9_7;
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_tv_2)) goto or__typeset1_9_7;
  x1 = arg(x0, 0);
 or__typeset1_9_6:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_v_4)) goto or__typeset1_9_7;
  allocp[0] = makesym(functor_goal_4);
  x3 = arg(x1, 0);
  allocp[1] = x3;
  x4 = arg(x1, 1);
  allocp[2] = x4;
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = x6 = makeref(&allocp[4]);
  x2 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_hb_xor__typeset2_12);
  allocp[7] = a0;
  allocp[8] = x2;
  allocp[9] = x7 = makeref(&allocp[9]);
  allocp[10] = x8 = makeref(&allocp[10]);
  x9 = cdr_of(a1);
  allocp[11] = x9;
  allocp[12] = a2;
  allocp[13] = a3;
  allocp[14] = a4;
  allocp[15] = a5;
  allocp[16] = a6;
  allocp[17] = a7;
  allocp[18] = a8;
  allocp[19] = (q)(struct goalrec*)&allocp[5];
  allocp[20] = (q)(&predicate_hb_xget__info_9);
  x10 = arg(x1, 0);
  allocp[21] = x10;
  x11 = arg(x1, 1);
  allocp[22] = x11;
  x12 = arg(x1, 2);
  allocp[23] = x12;
  x13 = arg(x1, 3);
  allocp[24] = x13;
  allocp[25] = x5;
  allocp[26] = x6;
  allocp[27] = a0;
  allocp[28] = x7;
  allocp[29] = a5;
  allocp[30] = (q)(struct goalrec*)&allocp[19];
  allocp[31] = (q)(&predicate_typeset_xget_5);
  allocp[32] = x10;
  allocp[33] = x11;
  allocp[34] = x12;
  allocp[35] = x8;
  allocp[36] = a7;
  qp = (struct goalrec*)&allocp[30];
  allocp += 37;
  proceed();
 case VARREF:
  deref_and_jump(x1,or__typeset1_9_6);
  *reasonp++ =  x1;
  goto or__typeset1_9_7;
  };
  goto or__typeset1_9_7;
 case VARREF:
  deref_and_jump(x0,or__typeset1_9_4);
  *reasonp++ =  x0;
  goto or__typeset1_9_7;
  };
  goto or__typeset1_9_7;
 case VARREF:
  deref_and_jump(a1,or__typeset1_9_3);
  *reasonp++ =  a1;
  goto or__typeset1_9_7;
  };
  goto or__typeset1_9_7;
 or__typeset1_9_7:
  otherwise(or__typeset1_9_interrupt);
 or__typeset1_9_8:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xor__typeset1_9);
  allocp[2] = a0;
  x0 = cdr_of(a1);
  allocp[3] = x0;
  allocp[4] = a2;
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[13] = x2 = makeref(&allocp[13]);
  allocp[14] = a3;
  allocp[15] = x1;
  allocp[16] = NILATOM;
  x4 = car_of(a1);
  allocp[17] = x4;
  x3 = makecons(&allocp[16]);
  allocp[18] = (q)(struct goalrec*)&allocp[11];
  allocp[19] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[20] = x3;
  allocp[21] = a2;
  allocp[22] = x2;
  qp = (struct goalrec*)&allocp[18];
  allocp += 23;
  proceed();
 case ATOMIC:
  if (a1 != NILATOM) goto or__typeset1_9_interrupt;
  unify(a8, a7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case VARREF:
  deref_and_jump(a1,or__typeset1_9_8);
  *reasonp++ =  a1;
  goto or__typeset1_9_interrupt;
  };
  goto or__typeset1_9_interrupt;
 or__typeset1_9_ext_interrupt:
  reasonp = 0l;
 or__typeset1_9_interrupt:
  toppred = &predicate_hb_xor__typeset1_9;
  goto interrupt_9;
 }

 or__typeset2_12_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 or__typeset2_12_clear_reason:
  reasonp = reasons;
 or__typeset2_12_0:
 or__typeset2_12_1:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_goal_4)) goto or__typeset2_12_5;
  x0 = arg(a1, 2);
 or__typeset2_12_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_dummy)) goto or__typeset2_12_5;
  x1 = arg(a1, 3);
 or__typeset2_12_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_dummy)) goto or__typeset2_12_5;
 or__typeset2_12_4:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_dummy)) goto or__typeset2_12_5;
  a1 = a4;
  a2 = a5;
  a3 = a6;
  a4 = a7;
  a5 = a8;
  a6 = a9;
  a7 = a10;
  a8 = a11;
  execute(or__typeset1_9_0);
  goto or__typeset1_9_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,or__typeset2_12_4);
  *reasonp++ =  a2;
  goto or__typeset2_12_5;
  };
  goto or__typeset2_12_5;
 case VARREF:
  deref_and_jump(x1,or__typeset2_12_3);
  *reasonp++ =  x1;
  goto or__typeset2_12_5;
  };
  goto or__typeset2_12_5;
 case VARREF:
  deref_and_jump(x0,or__typeset2_12_2);
  *reasonp++ =  x0;
  goto or__typeset2_12_5;
  };
  goto or__typeset2_12_5;
 case VARREF:
  deref_and_jump(a1,or__typeset2_12_1);
  *reasonp++ =  a1;
  goto or__typeset2_12_5;
  };
  goto or__typeset2_12_5;
 or__typeset2_12_5:
  otherwise(or__typeset2_12_interrupt);
 or__typeset2_12_6:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto or__typeset2_12_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom__2B)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xor__typeset1_9);
  allocp[2] = makesym(atom__2B);
  allocp[3] = a4;
  allocp[4] = a5;
  allocp[5] = x0 = makeref(&allocp[5]);
  allocp[6] = a7;
  allocp[7] = a8;
  allocp[8] = a9;
  allocp[9] = x1 = makeref(&allocp[9]);
  allocp[10] = a11;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[13] = a6;
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x0;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[18] = x3 = makeref(&allocp[18]);
  allocp[19] = a5;
  allocp[20] = x2;
  a0 = makesym(atom__2B);
  x4 = a2;
  a2 = a1;
  a4 = x3;
  a5 = a9;
  a6 = a10;
  a7 = x1;
  a1 = x4;
  qp = (struct goalrec*)&allocp[16];
  allocp += 21;
  execute(expand__loopgoal_8_0);
  goto expand__loopgoal_8_ext_interrupt;
 case symval(makesym(atom__2D)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xor__typeset1_9);
  allocp[2] = makesym(atom__2D);
  allocp[3] = a4;
  allocp[4] = a5;
  allocp[5] = x0 = makeref(&allocp[5]);
  allocp[6] = a7;
  allocp[7] = a8;
  allocp[8] = a9;
  allocp[9] = x1 = makeref(&allocp[9]);
  allocp[10] = a11;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[13] = a6;
  allocp[14] = x2 = makeref(&allocp[14]);
  allocp[15] = x0;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[18] = x3 = makeref(&allocp[18]);
  allocp[19] = a5;
  allocp[20] = x2;
  allocp[21] = makesym(functor_goal_4);
  allocp[22] = x5 = makeref(&allocp[22]);
  allocp[23] = x6 = makeref(&allocp[23]);
  allocp[24] = x7 = makeref(&allocp[24]);
  allocp[25] = x8 = makeref(&allocp[25]);
  x4 = makefunctor(&allocp[21]);
  allocp[26] = (q)(struct goalrec*)&allocp[16];
  allocp[27] = (q)(&predicate_typeset_xmake__shared__ts_8);
  allocp[28] = makesym(atom__2D);
  allocp[29] = a2;
  allocp[30] = a3;
  allocp[31] = x3;
  allocp[32] = x4;
  allocp[33] = a9;
  allocp[34] = a10;
  allocp[35] = x1;
  qp = (struct goalrec*)&allocp[26];
  allocp += 36;
  proceed();
  };
  goto or__typeset2_12_interrupt;
 case VARREF:
  deref_and_jump(a0,or__typeset2_12_6);
  *reasonp++ =  a0;
  goto or__typeset2_12_interrupt;
  };
  goto or__typeset2_12_interrupt;
 or__typeset2_12_ext_interrupt:
  reasonp = 0l;
 or__typeset2_12_interrupt:
  goto interrupt_12;
 }

 get__info_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 get__info_9_clear_reason:
  reasonp = reasons;
 get__info_9_0:
 get__info_9_1:
  switch (ptagof(a8)) {
 case CONS:
  x0 = car_of(a8);
 get__info_9_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto get__info_9_7;
  x1 = arg(x0, 0);
 get__info_9_3:
  if (isref(x1)) goto get__info_9_6;
 get__info_9_4:
  if (isref(x1)) goto get__info_9_5;
  if_not_equal(x1, a0, get__info_9_7);
  x2 = arg(x0, 1);
  x3 = a0;
  x4 = a1;
  x5 = a2;
  x6 = a3;
  x7 = a4;
  x8 = a5;
  x9 = a6;
  a8 = a7;
  a7 = x9;
  a6 = x8;
  a5 = x7;
  a4 = x6;
  a3 = x5;
  a2 = x4;
  a1 = x3;
  a0 = x2;
  execute(get__info__preds_9_clear_reason);
  goto get__info__preds_9_ext_interrupt;
 get__info_9_5:
  deref_and_jump(x1,get__info_9_4);
  *reasonp++ =  x1;
  goto get__info_9_7;
 get__info_9_6:
  deref_and_jump(x1,get__info_9_3);
  *reasonp++ =  x1;
  goto get__info_9_7;
 case VARREF:
  deref_and_jump(x0,get__info_9_2);
  *reasonp++ =  x0;
  goto get__info_9_7;
  };
  goto get__info_9_7;
 case VARREF:
  deref_and_jump(a8,get__info_9_1);
  *reasonp++ =  a8;
  goto get__info_9_7;
  };
  goto get__info_9_7;
 get__info_9_7:
  otherwise(get__info_9_interrupt);
 get__info_9_8:
  switch (ptagof(a8)) {
 case CONS:
  a8 = cdr_of(a8);
  execute(get__info_9_0);
  goto get__info_9_ext_interrupt;
 case VARREF:
  deref_and_jump(a8,get__info_9_8);
  *reasonp++ =  a8;
  goto get__info_9_interrupt;
  };
  goto get__info_9_interrupt;
 get__info_9_ext_interrupt:
  reasonp = 0l;
 get__info_9_interrupt:
  goto interrupt_9;
 }

 get__info__preds_9_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 get__info__preds_9_clear_reason:
  reasonp = reasons;
 get__info__preds_9_0:
 get__info__preds_9_1:
  switch (ptagof(a0)) {
 case CONS:
 get__info__preds_9_2:
  switch (ptagof(a7)) {
 case ATOMIC:
  if (isint(a7)) goto get__info__preds_9_interrupt;
  switch (symval(a7)) {
 case symval(makesym(atom__2B)):
  x0 = car_of(a0);
 get__info__preds_9_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_7)) goto get__info__preds_9_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xget__info__preds2_10);
  allocp[2] = x1 = makeref(&allocp[2]);
  x2 = cdr_of(a0);
  allocp[3] = x2;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = makesym(atom__2B);
  allocp[11] = a8;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_hb_xget__info__args_10);
  allocp[14] = x3 = makeref(&allocp[14]);
  x4 = arg(x0, 4);
  allocp[15] = x4;
  allocp[16] = a1;
  allocp[17] = a2;
  allocp[18] = a3;
  allocp[19] = a4;
  allocp[20] = a5;
  allocp[21] = a6;
  allocp[22] = a8;
  allocp[23] = x1;
  allocp[24] = (q)(struct goalrec*)&allocp[12];
  allocp[25] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[26] = x4;
  allocp[27] = x5 = makeref(&allocp[27]);
  allocp[28] = x3;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(x0,get__info__preds_9_3);
  *reasonp++ =  x0;
  goto get__info__preds_9_interrupt;
  };
  goto get__info__preds_9_interrupt;
 case symval(makesym(atom__2D)):
  x0 = car_of(a0);
 get__info__preds_9_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_7)) goto get__info__preds_9_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xget__info__preds2_10);
  allocp[2] = x1 = makeref(&allocp[2]);
  x2 = cdr_of(a0);
  allocp[3] = x2;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = makesym(atom__2D);
  allocp[11] = a8;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_hb_xget__info__args_10);
  allocp[14] = x3 = makeref(&allocp[14]);
  x4 = arg(x0, 3);
  allocp[15] = x4;
  allocp[16] = a1;
  allocp[17] = a2;
  allocp[18] = a3;
  allocp[19] = a4;
  allocp[20] = a5;
  allocp[21] = a6;
  allocp[22] = a8;
  allocp[23] = x1;
  allocp[24] = (q)(struct goalrec*)&allocp[12];
  allocp[25] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[26] = x4;
  allocp[27] = x5 = makeref(&allocp[27]);
  allocp[28] = x3;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(x0,get__info__preds_9_4);
  *reasonp++ =  x0;
  goto get__info__preds_9_interrupt;
  };
  goto get__info__preds_9_interrupt;
  };
  goto get__info__preds_9_interrupt;
 case VARREF:
  deref_and_jump(a7,get__info__preds_9_2);
  *reasonp++ =  a7;
  goto get__info__preds_9_interrupt;
  };
  goto get__info__preds_9_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto get__info__preds_9_interrupt;
  x0 = makesym(atom_dummy);
  unify_value(a5, x0);
  x1 = makesym(atom_dummy);
  unify_value(a6, x1);
  x2 = makesym(atom_dummy);
  unify_value(a8, x2);
  proceed();
 case VARREF:
  deref_and_jump(a0,get__info__preds_9_1);
  *reasonp++ =  a0;
  goto get__info__preds_9_interrupt;
  };
  goto get__info__preds_9_interrupt;
 get__info__preds_9_ext_interrupt:
  reasonp = 0l;
 get__info__preds_9_interrupt:
  toppred = &predicate_hb_xget__info__preds_9;
  goto interrupt_9;
 }

 get__info__preds2_10_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 get__info__preds2_10_clear_reason:
  reasonp = reasons;
 get__info__preds2_10_0:
 get__info__preds2_10_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_no)) goto get__info__preds2_10_interrupt;
  a0 = a1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  a5 = a6;
  a6 = a7;
  a7 = a8;
  a8 = a9;
  execute(get__info__preds_9_0);
  goto get__info__preds_9_ext_interrupt;
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_yes_3)) goto get__info__preds2_10_interrupt;
  x0 = arg(a0, 0);
  unify(a6, x0);
  x1 = arg(a0, 1);
  unify(a7, x1);
  x2 = arg(a0, 2);
  unify(a9, x2);
  proceed();
 case VARREF:
  deref_and_jump(a0,get__info__preds2_10_1);
  *reasonp++ =  a0;
  goto get__info__preds2_10_interrupt;
  };
  goto get__info__preds2_10_interrupt;
 get__info__preds2_10_ext_interrupt:
  reasonp = 0l;
 get__info__preds2_10_interrupt:
  goto interrupt_10;
 }

 get__info__args_10_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 get__info__args_10_clear_reason:
  reasonp = reasons;
 get__info__args_10_0:
 get__info__args_10_1:
  if (!isint(a0)) goto get__info__args_10_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,get__info__args_10_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xget__info__args2_11);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = a8;
  allocp[12] = a9;
  allocp[13] = (q)(struct goalrec*)&allocp[0];
  allocp[14] = (q)(&predicate_hb_xget__info__entry_10);
  allocp[15] = x2 = makeref(&allocp[15]);
  allocp[16] = x3 = makeref(&allocp[16]);
  allocp[17] = a2;
  allocp[18] = a3;
  allocp[19] = a4;
  allocp[20] = a5;
  allocp[21] = a6;
  allocp[22] = a7;
  allocp[23] = a8;
  allocp[24] = x1;
  allocp[25] = (q)(struct goalrec*)&allocp[13];
  allocp[26] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[27] = x3;
  allocp[28] = x4 = makeref(&allocp[28]);
  allocp[29] = x2;
  allocp[30] = (q)(struct goalrec*)&allocp[25];
  allocp[31] = (q)(&predicate_functor__table_xarg_3);
  allocp[32] = a0;
  allocp[33] = a1;
  allocp[34] = x3;
  qp = (struct goalrec*)&allocp[30];
  allocp += 35;
  proceed();
 get__info__args_10_2:
  if (a0 != makeint(0L)) goto get__info__args_10_interrupt;
  x5 = makesym(atom_no);
  unify_value(a9, x5);
  proceed();
 get__info__args_10_3:
  if (!isref(a0)) goto get__info__args_10_interrupt;
  deref_and_jump(a0,get__info__args_10_1);
  *reasonp++ =  a0;
  goto get__info__args_10_interrupt;
 get__info__args_10_ext_interrupt:
  reasonp = 0l;
 get__info__args_10_interrupt:
  toppred = &predicate_hb_xget__info__args_10;
  goto interrupt_10;
 }

 get__info__args2_11_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 get__info__args2_11_clear_reason:
  reasonp = reasons;
 get__info__args2_11_0:
 get__info__args2_11_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_no)) goto get__info__args2_11_2;
  x0 = makeint(1L);
  bblt_sub_no_check_y(a1,x0,x1);
  a0 = x1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  a5 = a6;
  a6 = a7;
  a7 = a8;
  a8 = a9;
  a9 = a10;
  execute(get__info__args_10_0);
  goto get__info__args_10_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,get__info__args2_11_1);
  *reasonp++ =  a0;
  goto get__info__args2_11_2;
  };
  goto get__info__args2_11_2;
 get__info__args2_11_2:
  otherwise(get__info__args2_11_interrupt);
  unify(a10, a0);
  proceed();
 get__info__args2_11_ext_interrupt:
  reasonp = 0l;
 get__info__args2_11_interrupt:
  goto interrupt_11;
 }

 get__info__entry_10_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 get__info__entry_10_clear_reason:
  reasonp = reasons;
 get__info__entry_10_0:
 get__info__entry_10_1:
  if (!isint(a0)) goto get__info__entry_10_41;
  x0 = makeint(0L);
  gblt_greater(a0,x0,get__info__entry_10_42);
 get__info__entry_10_2:
  if (isref(a1)) goto get__info__entry_10_40;
  gblt_arg(a0,a1,x1,get__info__entry_10_42);
 get__info__entry_10_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  switch (symval(functor_of(x1))) {
 case functor_entryarg_2:
  x2 = arg(x1, 0);
 get__info__entry_10_4:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_goal_4)) goto get__info__entry_10_42;
  x3 = arg(x2, 0);
 get__info__entry_10_5:
  if (isref(x3)) goto get__info__entry_10_12;
 get__info__entry_10_6:
  if (isref(x3)) goto get__info__entry_10_11;
  if_not_equal(x3, a2, get__info__entry_10_42);
  x4 = arg(x2, 1);
 get__info__entry_10_7:
  if (isref(x4)) goto get__info__entry_10_10;
 get__info__entry_10_8:
  if (isref(x4)) goto get__info__entry_10_9;
  if_not_equal(x4, a3, get__info__entry_10_42);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xget__info__entry2_14);
  allocp[2] = x5 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = a6;
  x6 = arg(x2, 2);
  allocp[10] = x6;
  allocp[11] = a7;
  x7 = arg(x2, 3);
  allocp[12] = x7;
  allocp[13] = a8;
  allocp[14] = makesym(atom_entry);
  allocp[15] = a9;
  a0 = arg(x1, 1);
  a1 = a4;
  a2 = a5;
  a3 = x5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 16;
  execute(get__info__term_4_clear_reason);
  goto get__info__term_4_ext_interrupt;
 get__info__entry_10_9:
  deref_and_jump(x4,get__info__entry_10_8);
  *reasonp++ =  x4;
  goto get__info__entry_10_42;
 get__info__entry_10_10:
  deref_and_jump(x4,get__info__entry_10_7);
  *reasonp++ =  x4;
  goto get__info__entry_10_42;
 get__info__entry_10_11:
  deref_and_jump(x3,get__info__entry_10_6);
  *reasonp++ =  x3;
  goto get__info__entry_10_42;
 get__info__entry_10_12:
  deref_and_jump(x3,get__info__entry_10_5);
  *reasonp++ =  x3;
  goto get__info__entry_10_42;
 case VARREF:
  deref_and_jump(x2,get__info__entry_10_4);
  *reasonp++ =  x2;
  goto get__info__entry_10_42;
  };
  goto get__info__entry_10_42;
 case functor_recursivearg_2:
  x2 = arg(x1, 0);
 get__info__entry_10_13:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_goal_4)) goto get__info__entry_10_42;
  x3 = arg(x2, 0);
 get__info__entry_10_14:
  if (isref(x3)) goto get__info__entry_10_21;
 get__info__entry_10_15:
  if (isref(x3)) goto get__info__entry_10_20;
  if_not_equal(x3, a2, get__info__entry_10_42);
  x4 = arg(x2, 1);
 get__info__entry_10_16:
  if (isref(x4)) goto get__info__entry_10_19;
 get__info__entry_10_17:
  if (isref(x4)) goto get__info__entry_10_18;
  if_not_equal(x4, a3, get__info__entry_10_42);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xget__info__entry2_14);
  allocp[2] = x5 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = a6;
  x6 = arg(x2, 2);
  allocp[10] = x6;
  allocp[11] = a7;
  x7 = arg(x2, 3);
  allocp[12] = x7;
  allocp[13] = a8;
  allocp[14] = makesym(atom_recursive);
  allocp[15] = a9;
  a0 = arg(x1, 1);
  a1 = a4;
  a2 = a5;
  a3 = x5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 16;
  execute(get__info__term_4_clear_reason);
  goto get__info__term_4_ext_interrupt;
 get__info__entry_10_18:
  deref_and_jump(x4,get__info__entry_10_17);
  *reasonp++ =  x4;
  goto get__info__entry_10_42;
 get__info__entry_10_19:
  deref_and_jump(x4,get__info__entry_10_16);
  *reasonp++ =  x4;
  goto get__info__entry_10_42;
 get__info__entry_10_20:
  deref_and_jump(x3,get__info__entry_10_15);
  *reasonp++ =  x3;
  goto get__info__entry_10_42;
 get__info__entry_10_21:
  deref_and_jump(x3,get__info__entry_10_14);
  *reasonp++ =  x3;
  goto get__info__entry_10_42;
 case VARREF:
  deref_and_jump(x2,get__info__entry_10_13);
  *reasonp++ =  x2;
  goto get__info__entry_10_42;
  };
  goto get__info__entry_10_42;
 case functor_sharedarg_2:
  x2 = arg(x1, 0);
 get__info__entry_10_22:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_goal_4)) goto get__info__entry_10_42;
  x3 = arg(x2, 0);
 get__info__entry_10_23:
  if (isref(x3)) goto get__info__entry_10_30;
 get__info__entry_10_24:
  if (isref(x3)) goto get__info__entry_10_29;
  if_not_equal(x3, a2, get__info__entry_10_42);
  x4 = arg(x2, 1);
 get__info__entry_10_25:
  if (isref(x4)) goto get__info__entry_10_28;
 get__info__entry_10_26:
  if (isref(x4)) goto get__info__entry_10_27;
  if_not_equal(x4, a3, get__info__entry_10_42);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xget__info__entry2_14);
  allocp[2] = x5 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = a6;
  x6 = arg(x2, 2);
  allocp[10] = x6;
  allocp[11] = a7;
  x7 = arg(x2, 3);
  allocp[12] = x7;
  allocp[13] = a8;
  allocp[14] = makesym(atom_shared);
  allocp[15] = a9;
  a0 = arg(x1, 1);
  a1 = a4;
  a2 = a5;
  a3 = x5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 16;
  execute(get__info__term_4_clear_reason);
  goto get__info__term_4_ext_interrupt;
 get__info__entry_10_27:
  deref_and_jump(x4,get__info__entry_10_26);
  *reasonp++ =  x4;
  goto get__info__entry_10_42;
 get__info__entry_10_28:
  deref_and_jump(x4,get__info__entry_10_25);
  *reasonp++ =  x4;
  goto get__info__entry_10_42;
 get__info__entry_10_29:
  deref_and_jump(x3,get__info__entry_10_24);
  *reasonp++ =  x3;
  goto get__info__entry_10_42;
 get__info__entry_10_30:
  deref_and_jump(x3,get__info__entry_10_23);
  *reasonp++ =  x3;
  goto get__info__entry_10_42;
 case VARREF:
  deref_and_jump(x2,get__info__entry_10_22);
  *reasonp++ =  x2;
  goto get__info__entry_10_42;
  };
  goto get__info__entry_10_42;
 case functor_looparg_2:
  x2 = arg(x1, 0);
 get__info__entry_10_31:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_goal_4)) goto get__info__entry_10_42;
  x3 = arg(x2, 0);
 get__info__entry_10_32:
  if (isref(x3)) goto get__info__entry_10_39;
 get__info__entry_10_33:
  if (isref(x3)) goto get__info__entry_10_38;
  if_not_equal(x3, a2, get__info__entry_10_42);
  x4 = arg(x2, 1);
 get__info__entry_10_34:
  if (isref(x4)) goto get__info__entry_10_37;
 get__info__entry_10_35:
  if (isref(x4)) goto get__info__entry_10_36;
  if_not_equal(x4, a3, get__info__entry_10_42);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xget__info__entry2_14);
  allocp[2] = x5 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = a6;
  x6 = arg(x2, 2);
  allocp[10] = x6;
  allocp[11] = a7;
  x7 = arg(x2, 3);
  allocp[12] = x7;
  allocp[13] = a8;
  allocp[14] = makesym(atom_recursive);
  allocp[15] = a9;
  a0 = arg(x1, 1);
  a1 = a4;
  a2 = a5;
  a3 = x5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 16;
  execute(get__info__term_4_clear_reason);
  goto get__info__term_4_ext_interrupt;
 get__info__entry_10_36:
  deref_and_jump(x4,get__info__entry_10_35);
  *reasonp++ =  x4;
  goto get__info__entry_10_42;
 get__info__entry_10_37:
  deref_and_jump(x4,get__info__entry_10_34);
  *reasonp++ =  x4;
  goto get__info__entry_10_42;
 get__info__entry_10_38:
  deref_and_jump(x3,get__info__entry_10_33);
  *reasonp++ =  x3;
  goto get__info__entry_10_42;
 get__info__entry_10_39:
  deref_and_jump(x3,get__info__entry_10_32);
  *reasonp++ =  x3;
  goto get__info__entry_10_42;
 case VARREF:
  deref_and_jump(x2,get__info__entry_10_31);
  *reasonp++ =  x2;
  goto get__info__entry_10_42;
  };
  goto get__info__entry_10_42;
  };
  goto get__info__entry_10_42;
 case VARREF:
  deref_and_jump(x1,get__info__entry_10_3);
  *reasonp++ =  x1;
  goto get__info__entry_10_42;
  };
  goto get__info__entry_10_42;
 get__info__entry_10_40:
  deref_and_jump(a1,get__info__entry_10_2);
  *reasonp++ =  a1;
  goto get__info__entry_10_42;
 get__info__entry_10_41:
  if (!isref(a0)) goto get__info__entry_10_42;
  deref_and_jump(a0,get__info__entry_10_1);
  *reasonp++ =  a0;
  goto get__info__entry_10_42;
 get__info__entry_10_42:
  otherwise(get__info__entry_10_interrupt);
 get__info__entry_10_43:
  if (!isint(a0)) goto get__info__entry_10_45;
  x0 = makeint(0L);
  gblt_greater(a0,x0,get__info__entry_10_44);
  x1 = makeint(1L);
  bblt_sub_no_check(a0,x1,x2);
  a0 = x2;
  execute(get__info__entry_10_0);
  goto get__info__entry_10_ext_interrupt;
 get__info__entry_10_44:
  if (a0 != makeint(0L)) goto get__info__entry_10_interrupt;
  x3 = makesym(atom_no);
  unify_value(a9, x3);
  proceed();
 get__info__entry_10_45:
  if (!isref(a0)) goto get__info__entry_10_interrupt;
  deref_and_jump(a0,get__info__entry_10_43);
  *reasonp++ =  a0;
  goto get__info__entry_10_interrupt;
 get__info__entry_10_ext_interrupt:
  reasonp = 0l;
 get__info__entry_10_interrupt:
  toppred = &predicate_hb_xget__info__entry_10;
  goto interrupt_10;
 }

 get__info__entry2_14_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  qp = qp->next;
 get__info__entry2_14_clear_reason:
  reasonp = reasons;
 get__info__entry2_14_0:
 get__info__entry2_14_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto get__info__entry2_14_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  allocp[0] = makesym(functor_yes_3);
  allocp[1] = a8;
  allocp[2] = a10;
  allocp[3] = a12;
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a13, x0);
  proceed();
 case symval(makesym(atom_no)):
  x0 = makeint(1L);
  bblt_sub_no_check_y(a1,x0,x1);
  a0 = x1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  a5 = a6;
  a6 = a7;
  a7 = a9;
  a8 = a11;
  a9 = a13;
  execute(get__info__entry_10_0);
  goto get__info__entry_10_ext_interrupt;
  };
  goto get__info__entry2_14_interrupt;
 case VARREF:
  deref_and_jump(a0,get__info__entry2_14_1);
  *reasonp++ =  a0;
  goto get__info__entry2_14_interrupt;
  };
  goto get__info__entry2_14_interrupt;
 get__info__entry2_14_ext_interrupt:
  reasonp = 0l;
 get__info__entry2_14_interrupt:
  goto interrupt_14;
 }

 get__info__term_4_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 get__info__term_4_clear_reason:
  reasonp = reasons;
 get__info__term_4_0:
 get__info__term_4_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_variable_3:
  x0 = arg(a0, 0);
 get__info__term_4_2:
  if (isref(x0)) goto get__info__term_4_9;
 get__info__term_4_3:
  if (isref(x0)) goto get__info__term_4_8;
  if_not_equal(x0, a1, get__info__term_4_11);
  x1 = arg(a0, 1);
 get__info__term_4_4:
  if (isref(x1)) goto get__info__term_4_7;
 get__info__term_4_5:
  if (isref(x1)) goto get__info__term_4_6;
  if_not_equal(x1, a2, get__info__term_4_11);
  x2 = makesym(atom_yes);
  unify_value(a3, x2);
  proceed();
 get__info__term_4_6:
  deref_and_jump(x1,get__info__term_4_5);
  *reasonp++ =  x1;
  goto get__info__term_4_11;
 get__info__term_4_7:
  deref_and_jump(x1,get__info__term_4_4);
  *reasonp++ =  x1;
  goto get__info__term_4_11;
 get__info__term_4_8:
  deref_and_jump(x0,get__info__term_4_3);
  *reasonp++ =  x0;
  goto get__info__term_4_11;
 get__info__term_4_9:
  deref_and_jump(x0,get__info__term_4_2);
  *reasonp++ =  x0;
  goto get__info__term_4_11;
 case functor_list_1:
  x0 = arg(a0, 0);
 get__info__term_4_10:
  switch (ptagof(x0)) {
 case CONS:
  allocp[0] = makesym(functor_list_2);
  x2 = car_of(x0);
  allocp[1] = x2;
  x3 = cdr_of(x0);
  allocp[2] = x3;
  x1 = makefunctor(&allocp[0]);
  a0 = makeint(2L);
  x4 = a1;
  x5 = a2;
  a4 = a3;
  a3 = x5;
  a2 = x4;
  a1 = x1;
  allocp += 3;
  execute(get__info__func_5_0);
  goto get__info__func_5_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,get__info__term_4_10);
  *reasonp++ =  x0;
  goto get__info__term_4_11;
  };
  goto get__info__term_4_11;
 case functor_functor_1:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xget__info__func_5);
  allocp[2] = x0 = makeref(&allocp[2]);
  x1 = arg(a0, 0);
  allocp[3] = x1;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[9] = x1;
  allocp[10] = x2 = makeref(&allocp[10]);
  allocp[11] = x0;
  qp = (struct goalrec*)&allocp[7];
  allocp += 12;
  proceed();
  };
  goto get__info__term_4_11;
 case VARREF:
  deref_and_jump(a0,get__info__term_4_1);
  *reasonp++ =  a0;
  goto get__info__term_4_11;
  };
  goto get__info__term_4_11;
 get__info__term_4_11:
  otherwise(get__info__term_4_interrupt);
  x0 = makesym(atom_no);
  unify_value(a3, x0);
  proceed();
 get__info__term_4_ext_interrupt:
  reasonp = 0l;
 get__info__term_4_interrupt:
  toppred = &predicate_hb_xget__info__term_4;
  goto interrupt_4;
 }

 get__info__func_5_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 get__info__func_5_clear_reason:
  reasonp = reasons;
 get__info__func_5_0:
 get__info__func_5_1:
  if (!isint(a0)) goto get__info__func_5_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,get__info__func_5_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xget__info__func2_6);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_hb_xget__info__term_4);
  allocp[10] = x2 = makeref(&allocp[10]);
  allocp[11] = a2;
  allocp[12] = a3;
  allocp[13] = x1;
  allocp[14] = (q)(struct goalrec*)&allocp[8];
  allocp[15] = (q)(&predicate_functor__table_xarg_3);
  allocp[16] = a0;
  allocp[17] = a1;
  allocp[18] = x2;
  qp = (struct goalrec*)&allocp[14];
  allocp += 19;
  proceed();
 get__info__func_5_2:
  if (a0 != makeint(0L)) goto get__info__func_5_interrupt;
  x3 = makesym(atom_no);
  unify_value(a4, x3);
  proceed();
 get__info__func_5_3:
  if (!isref(a0)) goto get__info__func_5_interrupt;
  deref_and_jump(a0,get__info__func_5_1);
  *reasonp++ =  a0;
  goto get__info__func_5_interrupt;
 get__info__func_5_ext_interrupt:
  reasonp = 0l;
 get__info__func_5_interrupt:
  toppred = &predicate_hb_xget__info__func_5;
  goto interrupt_5;
 }

 get__info__func2_6_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 get__info__func2_6_clear_reason:
  reasonp = reasons;
 get__info__func2_6_0:
 get__info__func2_6_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto get__info__func2_6_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  x0 = makesym(atom_yes);
  unify_value(a5, x0);
  proceed();
 case symval(makesym(atom_no)):
  x0 = makeint(1L);
  bblt_sub_no_check_y(a1,x0,x1);
  a0 = x1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  execute(get__info__func_5_0);
  goto get__info__func_5_ext_interrupt;
  };
  goto get__info__func2_6_interrupt;
 case VARREF:
  deref_and_jump(a0,get__info__func2_6_1);
  *reasonp++ =  a0;
  goto get__info__func2_6_interrupt;
  };
  goto get__info__func2_6_interrupt;
 get__info__func2_6_ext_interrupt:
  reasonp = 0l;
 get__info__func2_6_interrupt:
  goto interrupt_6;
 }

 write__io_7_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 write__io_7_clear_reason:
  reasonp = reasons;
 write__io_7_0:
 write__io_7_1:
  switch (ptagof(a5)) {
 case CONS:
  x0 = car_of(a5);
 write__io_7_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto write__io_7_7;
  x1 = arg(x0, 0);
 write__io_7_3:
  if (isref(x1)) goto write__io_7_6;
 write__io_7_4:
  if (isref(x1)) goto write__io_7_5;
  if_not_equal(x1, a0, write__io_7_7);
  allocp[0] = makesym(functor_module_2);
  allocp[1] = a0;
  allocp[2] = x3 = makeref(&allocp[2]);
  x2 = makefunctor(&allocp[0]);
  x5 = cdr_of(a5);
  allocp[3] = x5;
  allocp[4] = x2;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a6, x4);
  a0 = a1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  a4 = arg(x0, 1);
  a5 = x3;
  execute(write__io__preds_6_clear_reason);
  goto write__io__preds_6_ext_interrupt;
 write__io_7_5:
  deref_and_jump(x1,write__io_7_4);
  *reasonp++ =  x1;
  goto write__io_7_7;
 write__io_7_6:
  deref_and_jump(x1,write__io_7_3);
  *reasonp++ =  x1;
  goto write__io_7_7;
 case VARREF:
  deref_and_jump(x0,write__io_7_2);
  *reasonp++ =  x0;
  goto write__io_7_7;
  };
  goto write__io_7_7;
 case VARREF:
  deref_and_jump(a5,write__io_7_1);
  *reasonp++ =  a5;
  goto write__io_7_7;
  };
  goto write__io_7_7;
 write__io_7_7:
  otherwise(write__io_7_interrupt);
 write__io_7_8:
  switch (ptagof(a5)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a5);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a6, x0);
  a5 = cdr_of(a5);
  a6 = x1;
  execute(write__io_7_0);
  goto write__io_7_ext_interrupt;
 case VARREF:
  deref_and_jump(a5,write__io_7_8);
  *reasonp++ =  a5;
  goto write__io_7_interrupt;
  };
  goto write__io_7_interrupt;
 write__io_7_ext_interrupt:
  reasonp = 0l;
 write__io_7_interrupt:
  goto interrupt_7;
 }

 write__io__preds_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 write__io__preds_6_clear_reason:
  reasonp = reasons;
 write__io__preds_6_0:
 write__io__preds_6_1:
  switch (ptagof(a4)) {
 case CONS:
  x0 = car_of(a4);
 write__io__preds_6_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_7)) goto write__io__preds_6_11;
  x1 = arg(x0, 0);
 write__io__preds_6_3:
  if (isref(x1)) goto write__io__preds_6_10;
 write__io__preds_6_4:
  if (isref(x1)) goto write__io__preds_6_9;
  if_not_equal(x1, a0, write__io__preds_6_11);
  x2 = arg(x0, 1);
 write__io__preds_6_5:
  if (isref(x2)) goto write__io__preds_6_8;
 write__io__preds_6_6:
  if (isref(x2)) goto write__io__preds_6_7;
  if_not_equal(x2, a1, write__io__preds_6_11);
  allocp[0] = makesym(functor_pred_6);
  allocp[1] = a0;
  allocp[2] = a1;
  x4 = arg(x0, 3);
  allocp[3] = x4;
  x5 = arg(x0, 4);
  allocp[4] = x5;
  allocp[5] = a2;
  allocp[6] = a3;
  x3 = makefunctor(&allocp[0]);
  x7 = cdr_of(a4);
  allocp[7] = x7;
  allocp[8] = x3;
  x6 = makecons(&allocp[7]);
  allocp += 9;
  unify_value(a5, x6);
  proceed();
 write__io__preds_6_7:
  deref_and_jump(x2,write__io__preds_6_6);
  *reasonp++ =  x2;
  goto write__io__preds_6_11;
 write__io__preds_6_8:
  deref_and_jump(x2,write__io__preds_6_5);
  *reasonp++ =  x2;
  goto write__io__preds_6_11;
 write__io__preds_6_9:
  deref_and_jump(x1,write__io__preds_6_4);
  *reasonp++ =  x1;
  goto write__io__preds_6_11;
 write__io__preds_6_10:
  deref_and_jump(x1,write__io__preds_6_3);
  *reasonp++ =  x1;
  goto write__io__preds_6_11;
 case VARREF:
  deref_and_jump(x0,write__io__preds_6_2);
  *reasonp++ =  x0;
  goto write__io__preds_6_11;
  };
  goto write__io__preds_6_11;
 case VARREF:
  deref_and_jump(a4,write__io__preds_6_1);
  *reasonp++ =  a4;
  goto write__io__preds_6_11;
  };
  goto write__io__preds_6_11;
 write__io__preds_6_11:
  otherwise(write__io__preds_6_interrupt);
 write__io__preds_6_12:
  switch (ptagof(a4)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a4);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a5, x0);
  a4 = cdr_of(a4);
  a5 = x1;
  execute(write__io__preds_6_0);
  goto write__io__preds_6_ext_interrupt;
 case VARREF:
  deref_and_jump(a4,write__io__preds_6_12);
  *reasonp++ =  a4;
  goto write__io__preds_6_interrupt;
  };
  goto write__io__preds_6_interrupt;
 write__io__preds_6_ext_interrupt:
  reasonp = 0l;
 write__io__preds_6_interrupt:
  toppred = &predicate_hb_xwrite__io__preds_6;
  goto interrupt_6;
 }

 make__io_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  qp = qp->next;
 make__io_3_clear_reason:
  reasonp = reasons;
 make__io_3_0:
 make__io_3_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 make__io_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto make__io_3_interrupt;
  allocp[0] = makesym(functor_module_2);
  x2 = arg(x0, 0);
  allocp[1] = x2;
  allocp[2] = x3 = makeref(&allocp[2]);
  x1 = makefunctor(&allocp[0]);
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = x1;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a2, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xmake__io_3);
  allocp[2] = a0;
  x6 = cdr_of(a1);
  allocp[3] = x6;
  allocp[4] = x5;
  x7 = arg(x0, 1);
  a1 = x3;
  a2 = a0;
  a0 = x7;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(make__io__preds_3_0);
  goto make__io__preds_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,make__io_3_2);
  *reasonp++ =  x0;
  goto make__io_3_interrupt;
  };
  goto make__io_3_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto make__io_3_interrupt;
  unify_value(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a1,make__io_3_1);
  *reasonp++ =  a1;
  goto make__io_3_interrupt;
  };
  goto make__io_3_interrupt;
 make__io_3_ext_interrupt:
  reasonp = 0l;
 make__io_3_interrupt:
  goto interrupt_3;
 }

 make__io__preds_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20, x21;
  a2 = qp->args[2];
  qp = qp->next;
 make__io__preds_3_clear_reason:
  reasonp = reasons;
 make__io__preds_3_0:
 make__io__preds_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 make__io__preds_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_7)) goto make__io__preds_3_interrupt;
  x1 = arg(x0, 5);
 make__io__preds_3_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto make__io__preds_3_interrupt;
  x2 = arg(x0, 6);
 make__io__preds_3_4:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != NILATOM) goto make__io__preds_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xmake__io__preds_3);
  x3 = cdr_of(a0);
  allocp[2] = x3;
  allocp[3] = x4 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = makesym(functor_pred_7);
  x6 = arg(x0, 0);
  allocp[6] = x6;
  x7 = arg(x0, 1);
  allocp[7] = x7;
  x8 = arg(x0, 2);
  allocp[8] = x8;
  x9 = arg(x0, 3);
  allocp[9] = x9;
  x10 = arg(x0, 4);
  allocp[10] = x10;
  allocp[11] = x11 = makeref(&allocp[11]);
  allocp[12] = x12 = makeref(&allocp[12]);
  x5 = makefunctor(&allocp[5]);
  allocp[13] = x4;
  allocp[14] = x5;
  x13 = makecons(&allocp[13]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 15;
  unify_value(a1, x13);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xmake__io__graph_7);
  allocp[2] = x14 = makeref(&allocp[2]);
  x15 = arg(x0, 1);
  allocp[3] = x15;
  x16 = arg(x0, 2);
  allocp[4] = x16;
  x17 = arg(x0, 4);
  allocp[5] = x17;
  allocp[6] = makesym(atom_bio);
  allocp[7] = x12;
  allocp[8] = a2;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[11] = x17;
  allocp[12] = x18 = makeref(&allocp[12]);
  allocp[13] = x14;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_hb_xmake__io__graph_7);
  allocp[16] = x19 = makeref(&allocp[16]);
  allocp[17] = x15;
  allocp[18] = x16;
  x20 = arg(x0, 3);
  allocp[19] = x20;
  allocp[20] = makesym(atom_hio);
  allocp[21] = x11;
  allocp[22] = a2;
  allocp[23] = (q)(struct goalrec*)&allocp[14];
  allocp[24] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[25] = x20;
  allocp[26] = x21 = makeref(&allocp[26]);
  allocp[27] = x19;
  qp = (struct goalrec*)&allocp[23];
  allocp += 28;
  proceed();
 case VARREF:
  deref_and_jump(x2,make__io__preds_3_4);
  *reasonp++ =  x2;
  goto make__io__preds_3_interrupt;
  };
  goto make__io__preds_3_interrupt;
 case VARREF:
  deref_and_jump(x1,make__io__preds_3_3);
  *reasonp++ =  x1;
  goto make__io__preds_3_interrupt;
  };
  goto make__io__preds_3_interrupt;
 case VARREF:
  deref_and_jump(x0,make__io__preds_3_2);
  *reasonp++ =  x0;
  goto make__io__preds_3_interrupt;
  };
  goto make__io__preds_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto make__io__preds_3_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,make__io__preds_3_1);
  *reasonp++ =  a0;
  goto make__io__preds_3_interrupt;
  };
  goto make__io__preds_3_interrupt;
 make__io__preds_3_ext_interrupt:
  reasonp = 0l;
 make__io__preds_3_interrupt:
  toppred = &predicate_hb_xmake__io__preds_3;
  goto interrupt_3;
 }

 make__io__graph_7_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 make__io__graph_7_clear_reason:
  reasonp = reasons;
 make__io__graph_7_0:
 make__io__graph_7_1:
  if (!isint(a0)) goto make__io__graph_7_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,make__io__graph_7_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xmake__io__graphs_7);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[11] = x2 = makeref(&allocp[11]);
  allocp[12] = x3 = makeref(&allocp[12]);
  allocp[13] = x1;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_functor__table_xarg_3);
  allocp[16] = makeint(1L);
  allocp[17] = a3;
  allocp[18] = x2;
  qp = (struct goalrec*)&allocp[14];
  allocp += 19;
  proceed();
 make__io__graph_7_2:
  if (a0 != makeint(0L)) goto make__io__graph_7_interrupt;
  unify(a4, a5);
  proceed();
 make__io__graph_7_3:
  if (!isref(a0)) goto make__io__graph_7_interrupt;
  deref_and_jump(a0,make__io__graph_7_1);
  *reasonp++ =  a0;
  goto make__io__graph_7_interrupt;
 make__io__graph_7_ext_interrupt:
  reasonp = 0l;
 make__io__graph_7_interrupt:
  goto interrupt_7;
 }

 make__io__graphs_7_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 make__io__graphs_7_clear_reason:
  reasonp = reasons;
 make__io__graphs_7_0:
 make__io__graphs_7_1:
  if (!isint(a0)) goto make__io__graphs_7_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,make__io__graphs_7_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xmake__io__graphs_7);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[11] = a0;
  allocp[12] = makeint(1L);
  allocp[13] = x1;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_functor_xinsert__arg_4);
  allocp[16] = makeint(1L);
  allocp[17] = a4;
  allocp[18] = x3 = makeref(&allocp[18]);
  allocp[19] = x2;
  allocp[20] = (q)(struct goalrec*)&allocp[14];
  allocp[21] = (q)(&predicate_hb_xmake__io__graph2_5);
  allocp[22] = a1;
  allocp[23] = a2;
  allocp[24] = x4 = makeref(&allocp[24]);
  allocp[25] = x3;
  allocp[26] = a6;
  a2 = a3;
  a3 = makesym(atom_arg);
  a4 = x4;
  qp = (struct goalrec*)&allocp[20];
  allocp += 27;
  execute(get__arg_5_0);
  goto get__arg_5_ext_interrupt;
 make__io__graphs_7_2:
  if (a0 != makeint(0L)) goto make__io__graphs_7_interrupt;
  unify(a5, a4);
  proceed();
 make__io__graphs_7_3:
  if (!isref(a0)) goto make__io__graphs_7_interrupt;
  deref_and_jump(a0,make__io__graphs_7_1);
  *reasonp++ =  a0;
  goto make__io__graphs_7_interrupt;
 make__io__graphs_7_ext_interrupt:
  reasonp = 0l;
 make__io__graphs_7_interrupt:
  goto interrupt_7;
 }

 get__arg_5_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 get__arg_5_clear_reason:
  reasonp = reasons;
 get__arg_5_0:
 get__arg_5_1:
  if (!isint(a1)) goto get__arg_5_3;
  x0 = makeint(0L);
  gblt_greater(a1,x0,get__arg_5_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xget__arg_5);
  allocp[2] = a0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[9] = a1;
  allocp[10] = makeint(1L);
  allocp[11] = x1;
  allocp[12] = (q)(struct goalrec*)&allocp[7];
  allocp[13] = (q)(&predicate_functor_xinsert__arg_4);
  allocp[14] = makeint(1L);
  allocp[15] = a3;
  allocp[16] = x3 = makeref(&allocp[16]);
  allocp[17] = x2;
  allocp[18] = (q)(struct goalrec*)&allocp[12];
  allocp[19] = (q)(&predicate_functor__table_xarg_3);
  allocp[20] = a0;
  allocp[21] = x4 = makeref(&allocp[21]);
  allocp[22] = x3;
  allocp[23] = (q)(struct goalrec*)&allocp[18];
  allocp[24] = (q)(&predicate_functor__table_xarg_3);
  allocp[25] = a1;
  allocp[26] = a2;
  allocp[27] = x4;
  qp = (struct goalrec*)&allocp[23];
  allocp += 28;
  proceed();
 get__arg_5_2:
  if (a1 != makeint(0L)) goto get__arg_5_interrupt;
  unify(a4, a3);
  proceed();
 get__arg_5_3:
  if (!isref(a1)) goto get__arg_5_interrupt;
  deref_and_jump(a1,get__arg_5_1);
  *reasonp++ =  a1;
  goto get__arg_5_interrupt;
 get__arg_5_ext_interrupt:
  reasonp = 0l;
 get__arg_5_interrupt:
  toppred = &predicate_hb_xget__arg_5;
  goto interrupt_5;
 }

 make__io__graph2_5_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 make__io__graph2_5_clear_reason:
  reasonp = reasons;
 make__io__graph2_5_0:
  allocp[0] = makesym(functor_io_2);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  x0 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a3, x0);
  a3 = NILATOM;
  a5 = NILATOM;
  a6 = x2;
  a7 = a4;
  a4 = x1;
  execute(make__io__graph3_8_0);
  goto make__io__graph3_8_ext_interrupt;
 make__io__graph2_5_ext_interrupt:
  reasonp = 0l;
 make__io__graph2_5_interrupt:
  goto interrupt_5;
 }

 make__io__graph3_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 make__io__graph3_8_clear_reason:
  reasonp = reasons;
 make__io__graph3_8_0:
 make__io__graph3_8_1:
  if (!isint(a0)) goto make__io__graph3_8_19;
  x0 = makeint(0L);
  gblt_greater(a0,x0,make__io__graph3_8_20);
 make__io__graph3_8_2:
  if (isref(a1)) goto make__io__graph3_8_18;
  gblt_arg(a0,a1,x1,make__io__graph3_8_20);
 make__io__graph3_8_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (isint(x1)) goto make__io__graph3_8_20;
  switch (symval(x1)) {
 case symval(makesym(atom_i)):
 make__io__graph3_8_4:
  if (isref(a2)) goto make__io__graph3_8_10;
  gblt_arg(a0,a2,x2,make__io__graph3_8_20);
 make__io__graph3_8_5:
  if (isref(x2)) goto make__io__graph3_8_9;
  x4 = makeint(1L);
  gblt_arg(x4,x2,x3,make__io__graph3_8_20);
 make__io__graph3_8_6:
  switch (ptagof(x3)) {
 case FUNCTOR:
  if (functor_of(x3) != makesym(functor_goal_4)) goto make__io__graph3_8_20;
  x6 = makeint(2L);
  gblt_arg(x6,x2,x5,make__io__graph3_8_20);
 make__io__graph3_8_7:
  switch (ptagof(x5)) {
 case FUNCTOR:
  if (functor_of(x5) != makesym(functor_variable_3)) goto make__io__graph3_8_20;
  x7 = arg(x5, 2);
 make__io__graph3_8_8:
  switch (ptagof(x7)) {
 case ATOMIC:
  if (x7 != makesym(atom__3F)) goto make__io__graph3_8_20;
  allocp[0] = makesym(functor_v_3);
  x9 = arg(x3, 0);
  allocp[1] = x9;
  x10 = arg(x3, 1);
  allocp[2] = x10;
  x11 = arg(x5, 0);
  allocp[3] = x11;
  x8 = makefunctor(&allocp[0]);
  allocp[4] = a3;
  allocp[5] = x8;
  x12 = makecons(&allocp[4]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_hb_xmake__io__graph3_8);
  allocp[8] = x13 = makeref(&allocp[8]);
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = x14 = makeref(&allocp[11]);
  allocp[12] = a4;
  allocp[13] = x15 = makeref(&allocp[13]);
  allocp[14] = a6;
  allocp[15] = a7;
  allocp[16] = (q)(struct goalrec*)&allocp[6];
  allocp[17] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[18] = a0;
  allocp[19] = makeint(1L);
  allocp[20] = x13;
  allocp[21] = makesym(functor_variable_3);
  x17 = arg(x5, 0);
  allocp[22] = x17;
  x18 = arg(x5, 1);
  allocp[23] = x18;
  allocp[24] = makesym(atom__3F);
  x16 = makefunctor(&allocp[21]);
  a0 = arg(x3, 0);
  a1 = arg(x3, 1);
  a2 = arg(x3, 2);
  a3 = arg(x3, 3);
  a4 = x16;
  a6 = x14;
  x19 = a5;
  a8 = x15;
  a9 = a7;
  a7 = x19;
  a5 = x12;
  qp = (struct goalrec*)&allocp[16];
  allocp += 25;
  execute(make__io__struct_10_0);
  goto make__io__struct_10_ext_interrupt;
 case VARREF:
  deref_and_jump(x7,make__io__graph3_8_8);
  *reasonp++ =  x7;
  goto make__io__graph3_8_20;
  };
  goto make__io__graph3_8_20;
 case VARREF:
  deref_and_jump(x5,make__io__graph3_8_7);
  *reasonp++ =  x5;
  goto make__io__graph3_8_20;
  };
  goto make__io__graph3_8_20;
 case VARREF:
  deref_and_jump(x3,make__io__graph3_8_6);
  *reasonp++ =  x3;
  goto make__io__graph3_8_20;
  };
  goto make__io__graph3_8_20;
 make__io__graph3_8_9:
  deref_and_jump(x2,make__io__graph3_8_5);
  *reasonp++ =  x2;
  goto make__io__graph3_8_20;
 make__io__graph3_8_10:
  deref_and_jump(a2,make__io__graph3_8_4);
  *reasonp++ =  a2;
  goto make__io__graph3_8_20;
 case symval(makesym(atom_o)):
 make__io__graph3_8_11:
  if (isref(a2)) goto make__io__graph3_8_17;
  gblt_arg(a0,a2,x2,make__io__graph3_8_20);
 make__io__graph3_8_12:
  if (isref(x2)) goto make__io__graph3_8_16;
  x4 = makeint(1L);
  gblt_arg(x4,x2,x3,make__io__graph3_8_20);
 make__io__graph3_8_13:
  switch (ptagof(x3)) {
 case FUNCTOR:
  if (functor_of(x3) != makesym(functor_goal_4)) goto make__io__graph3_8_20;
  x6 = makeint(2L);
  gblt_arg(x6,x2,x5,make__io__graph3_8_20);
 make__io__graph3_8_14:
  switch (ptagof(x5)) {
 case FUNCTOR:
  if (functor_of(x5) != makesym(functor_variable_3)) goto make__io__graph3_8_20;
  x7 = arg(x5, 2);
 make__io__graph3_8_15:
  switch (ptagof(x7)) {
 case ATOMIC:
  if (x7 != makesym(atom__3F)) goto make__io__graph3_8_20;
  allocp[0] = makesym(functor_v_3);
  x9 = arg(x3, 0);
  allocp[1] = x9;
  x10 = arg(x3, 1);
  allocp[2] = x10;
  x11 = arg(x5, 0);
  allocp[3] = x11;
  x8 = makefunctor(&allocp[0]);
  allocp[4] = a5;
  allocp[5] = x8;
  x12 = makecons(&allocp[4]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_hb_xmake__io__graph3_8);
  allocp[8] = x13 = makeref(&allocp[8]);
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = x14 = makeref(&allocp[11]);
  allocp[12] = a4;
  allocp[13] = x15 = makeref(&allocp[13]);
  allocp[14] = a6;
  allocp[15] = a7;
  allocp[16] = (q)(struct goalrec*)&allocp[6];
  allocp[17] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[18] = a0;
  allocp[19] = makeint(1L);
  allocp[20] = x13;
  allocp[21] = makesym(functor_variable_3);
  x17 = arg(x5, 0);
  allocp[22] = x17;
  x18 = arg(x5, 1);
  allocp[23] = x18;
  allocp[24] = makesym(atom__3F);
  x16 = makefunctor(&allocp[21]);
  a0 = arg(x3, 0);
  a1 = arg(x3, 1);
  a2 = arg(x3, 2);
  x19 = arg(x3, 3);
  a4 = x16;
  a5 = a3;
  a6 = x14;
  a8 = x15;
  a9 = a7;
  a7 = x12;
  a3 = x19;
  qp = (struct goalrec*)&allocp[16];
  allocp += 25;
  execute(make__io__struct_10_0);
  goto make__io__struct_10_ext_interrupt;
 case VARREF:
  deref_and_jump(x7,make__io__graph3_8_15);
  *reasonp++ =  x7;
  goto make__io__graph3_8_20;
  };
  goto make__io__graph3_8_20;
 case VARREF:
  deref_and_jump(x5,make__io__graph3_8_14);
  *reasonp++ =  x5;
  goto make__io__graph3_8_20;
  };
  goto make__io__graph3_8_20;
 case VARREF:
  deref_and_jump(x3,make__io__graph3_8_13);
  *reasonp++ =  x3;
  goto make__io__graph3_8_20;
  };
  goto make__io__graph3_8_20;
 make__io__graph3_8_16:
  deref_and_jump(x2,make__io__graph3_8_12);
  *reasonp++ =  x2;
  goto make__io__graph3_8_20;
 make__io__graph3_8_17:
  deref_and_jump(a2,make__io__graph3_8_11);
  *reasonp++ =  a2;
  goto make__io__graph3_8_20;
  };
  goto make__io__graph3_8_20;
 case VARREF:
  deref_and_jump(x1,make__io__graph3_8_3);
  *reasonp++ =  x1;
  goto make__io__graph3_8_20;
  };
  goto make__io__graph3_8_20;
 make__io__graph3_8_18:
  deref_and_jump(a1,make__io__graph3_8_2);
  *reasonp++ =  a1;
  goto make__io__graph3_8_20;
 make__io__graph3_8_19:
  if (!isref(a0)) goto make__io__graph3_8_20;
  deref_and_jump(a0,make__io__graph3_8_1);
  *reasonp++ =  a0;
  goto make__io__graph3_8_20;
 make__io__graph3_8_20:
  otherwise(make__io__graph3_8_interrupt);
 make__io__graph3_8_21:
  if (!isint(a0)) goto make__io__graph3_8_28;
  x0 = makeint(0L);
  gblt_greater(a0,x0,make__io__graph3_8_27);
 make__io__graph3_8_22:
  if (isref(a2)) goto make__io__graph3_8_26;
  gblt_arg(a0,a2,x1,make__io__graph3_8_27);
 make__io__graph3_8_23:
  if (isref(x1)) goto make__io__graph3_8_25;
  x3 = makeint(1L);
  gblt_arg(x3,x1,x2,make__io__graph3_8_27);
 make__io__graph3_8_24:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_goal_4)) goto make__io__graph3_8_27;
  x5 = makeint(2L);
  gblt_arg(x5,x1,x4,make__io__graph3_8_27);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xmake__io__graph3_8);
  allocp[2] = x6 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x7 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x8 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[12] = a0;
  allocp[13] = makeint(1L);
  allocp[14] = x6;
  a0 = arg(x2, 0);
  a1 = arg(x2, 1);
  a2 = arg(x2, 2);
  x9 = arg(x2, 3);
  a4 = x4;
  x10 = a3;
  a6 = x7;
  x11 = a5;
  a8 = x8;
  a9 = a7;
  a7 = x11;
  a5 = x10;
  a3 = x9;
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  execute(make__io__struct_10_0);
  goto make__io__struct_10_ext_interrupt;
 case VARREF:
  deref_and_jump(x2,make__io__graph3_8_24);
  *reasonp++ =  x2;
  goto make__io__graph3_8_27;
  };
  goto make__io__graph3_8_27;
 make__io__graph3_8_25:
  deref_and_jump(x1,make__io__graph3_8_23);
  *reasonp++ =  x1;
  goto make__io__graph3_8_27;
 make__io__graph3_8_26:
  deref_and_jump(a2,make__io__graph3_8_22);
  *reasonp++ =  a2;
  goto make__io__graph3_8_27;
 make__io__graph3_8_27:
  if (a0 != makeint(0L)) goto make__io__graph3_8_interrupt;
  unify2(a4, a3, a6, a5);
  proceed();
 make__io__graph3_8_28:
  if (!isref(a0)) goto make__io__graph3_8_interrupt;
  deref_and_jump(a0,make__io__graph3_8_21);
  *reasonp++ =  a0;
  goto make__io__graph3_8_interrupt;
 make__io__graph3_8_ext_interrupt:
  reasonp = 0l;
 make__io__graph3_8_interrupt:
  toppred = &predicate_hb_xmake__io__graph3_8;
  goto interrupt_8;
 }

 make__io__struct_10_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 make__io__struct_10_clear_reason:
  reasonp = reasons;
 make__io__struct_10_0:
 make__io__struct_10_1:
  switch (ptagof(a4)) {
 case FUNCTOR:
  if (functor_of(a4) != makesym(functor_variable_3)) goto make__io__struct_10_2;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_hb_xmake__io__struct2_9);
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = x0;
  allocp[9] = a5;
  allocp[10] = a6;
  allocp[11] = a7;
  allocp[12] = a8;
  allocp[13] = a9;
  allocp[14] = NILATOM;
  allocp[15] = x2 = makeref(&allocp[15]);
  allocp[16] = (q)(struct goalrec*)&allocp[5];
  allocp[17] = (q)(&predicate_typeset_xget_5);
  allocp[18] = a0;
  allocp[19] = a1;
  x3 = arg(a4, 0);
  allocp[20] = x3;
  allocp[21] = x1;
  allocp[22] = a9;
  qp = (struct goalrec*)&allocp[16];
  allocp += 23;
  proceed();
 case VARREF:
  deref_and_jump(a4,make__io__struct_10_1);
  *reasonp++ =  a4;
  goto make__io__struct_10_2;
  };
  goto make__io__struct_10_2;
 make__io__struct_10_2:
  otherwise(make__io__struct_10_interrupt);
 make__io__struct_10_3:
  if (isref(a4)) goto make__io__struct_10_4;
  gblt_pfunctor(a4,x0,make__io__struct_10_5);
  gblt_arity(a4,x1,make__io__struct_10_5);
  x2 = a0;
  x3 = a1;
  x4 = a2;
  x5 = a3;
  x6 = a4;
  x7 = a5;
  x8 = a6;
  x9 = a7;
  x10 = a8;
  a10 = a9;
  a9 = x10;
  a8 = x9;
  a7 = x8;
  a6 = x7;
  a5 = x6;
  a4 = x5;
  a3 = x4;
  a2 = x3;
  a1 = x2;
  a0 = x1;
  execute(make__io__func_11_0);
  goto make__io__func_11_ext_interrupt;
 make__io__struct_10_4:
  deref_and_jump(a4,make__io__struct_10_3);
  *reasonp++ =  a4;
  goto make__io__struct_10_5;
 make__io__struct_10_5:
  otherwise(make__io__struct_10_interrupt);
  unify2(a6, a5, a8, a7);
  proceed();
 make__io__struct_10_ext_interrupt:
  reasonp = 0l;
 make__io__struct_10_interrupt:
  toppred = &predicate_hb_xmake__io__struct_10;
  goto interrupt_10;
 }

 make__io__func_11_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 make__io__func_11_clear_reason:
  reasonp = reasons;
 make__io__func_11_0:
 make__io__func_11_1:
  if (!isint(a0)) goto make__io__func_11_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,make__io__func_11_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xmake__io__func_11);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x3 = makeref(&allocp[10]);
  allocp[11] = a9;
  allocp[12] = a10;
  allocp[13] = (q)(struct goalrec*)&allocp[0];
  allocp[14] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[15] = a0;
  allocp[16] = makeint(1L);
  allocp[17] = x1;
  allocp[18] = (q)(struct goalrec*)&allocp[13];
  allocp[19] = (q)(&predicate_hb_xmake__io__struct_10);
  allocp[20] = a1;
  allocp[21] = a2;
  allocp[22] = a3;
  allocp[23] = a4;
  allocp[24] = x4 = makeref(&allocp[24]);
  allocp[25] = a6;
  allocp[26] = x2;
  allocp[27] = a8;
  allocp[28] = x3;
  allocp[29] = a10;
  allocp[30] = (q)(struct goalrec*)&allocp[18];
  allocp[31] = (q)(&predicate_functor__table_xarg_3);
  allocp[32] = a0;
  allocp[33] = a5;
  allocp[34] = x4;
  qp = (struct goalrec*)&allocp[30];
  allocp += 35;
  proceed();
 make__io__func_11_2:
  if (a0 != makeint(0L)) goto make__io__func_11_interrupt;
  unify2(a7, a6, a9, a8);
  proceed();
 make__io__func_11_3:
  if (!isref(a0)) goto make__io__func_11_interrupt;
  deref_and_jump(a0,make__io__func_11_1);
  *reasonp++ =  a0;
  goto make__io__func_11_interrupt;
 make__io__func_11_ext_interrupt:
  reasonp = 0l;
 make__io__func_11_interrupt:
  toppred = &predicate_hb_xmake__io__func_11;
  goto interrupt_11;
 }

 make__io__struct2_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 make__io__struct2_9_clear_reason:
  reasonp = reasons;
 make__io__struct2_9_0:
 make__io__struct2_9_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 make__io__struct2_9_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_2)) goto make__io__struct2_9_4;
  x1 = arg(x0, 0);
 make__io__struct2_9_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_s_3)) goto make__io__struct2_9_4;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xmake__io__struct2_9);
  x2 = cdr_of(a0);
  allocp[2] = x2;
  allocp[3] = a1;
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x4 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = x5 = makeref(&allocp[9]);
  allocp[10] = a8;
  a0 = arg(x1, 1);
  x6 = arg(x1, 2);
  x7 = a1;
  a3 = a2;
  a5 = a4;
  x8 = a6;
  a8 = a7;
  a9 = x5;
  a7 = x8;
  a6 = x4;
  a4 = x3;
  a2 = x7;
  a1 = x6;
  qp = (struct goalrec*)&allocp[0];
  allocp += 11;
  execute(make__io__args_10_0);
  goto make__io__args_10_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,make__io__struct2_9_3);
  *reasonp++ =  x1;
  goto make__io__struct2_9_4;
  };
  goto make__io__struct2_9_4;
 case VARREF:
  deref_and_jump(x0,make__io__struct2_9_2);
  *reasonp++ =  x0;
  goto make__io__struct2_9_4;
  };
  goto make__io__struct2_9_4;
 case VARREF:
  deref_and_jump(a0,make__io__struct2_9_1);
  *reasonp++ =  a0;
  goto make__io__struct2_9_4;
  };
  goto make__io__struct2_9_4;
 make__io__struct2_9_4:
  otherwise(make__io__struct2_9_interrupt);
 make__io__struct2_9_5:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(make__io__struct2_9_0);
  goto make__io__struct2_9_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto make__io__struct2_9_interrupt;
  unify3(a8, a7, a3, a2, a5, a4);
  proceed();
 case VARREF:
  deref_and_jump(a0,make__io__struct2_9_5);
  *reasonp++ =  a0;
  goto make__io__struct2_9_interrupt;
  };
  goto make__io__struct2_9_interrupt;
 make__io__struct2_9_ext_interrupt:
  reasonp = 0l;
 make__io__struct2_9_interrupt:
  toppred = &predicate_hb_xmake__io__struct2_9;
  goto interrupt_9;
 }

 make__io__args_10_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 make__io__args_10_clear_reason:
  reasonp = reasons;
 make__io__args_10_0:
 make__io__args_10_1:
  if (!isint(a0)) goto make__io__args_10_2;
  gblt_integer(a0,make__io__args_10_3);
  x0 = makeint(0L);
  gblt_greater(a0,x0,make__io__args_10_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xmake__io__args_10);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = x4 = makeref(&allocp[10]);
  allocp[11] = a9;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[14] = a0;
  allocp[15] = makeint(1L);
  allocp[16] = x1;
  allocp[17] = (q)(struct goalrec*)&allocp[12];
  allocp[18] = (q)(&predicate_hb_xmake__io__arg_9);
  allocp[19] = x5 = makeref(&allocp[19]);
  allocp[20] = a2;
  allocp[21] = a3;
  allocp[22] = x2;
  allocp[23] = a5;
  allocp[24] = x3;
  allocp[25] = a7;
  allocp[26] = a8;
  allocp[27] = x4;
  allocp[28] = (q)(struct goalrec*)&allocp[17];
  allocp[29] = (q)(&predicate_functor__table_xarg_3);
  allocp[30] = a0;
  allocp[31] = a1;
  allocp[32] = x5;
  qp = (struct goalrec*)&allocp[28];
  allocp += 33;
  proceed();
 make__io__args_10_2:
  if (!isref(a0)) goto make__io__args_10_3;
  deref_and_jump(a0,make__io__args_10_1);
  *reasonp++ =  a0;
  goto make__io__args_10_3;
 make__io__args_10_3:
  otherwise(make__io__args_10_interrupt);
 make__io__args_10_4:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto make__io__args_10_6;
  if (a0 != makesym(atom__2A)) goto make__io__args_10_interrupt;
 make__io__args_10_5:
  switch (ptagof(a1)) {
 case CONS:
  gblt_list(a1,make__io__args_10_interrupt);
  a0 = a1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  a5 = a6;
  a6 = a7;
  a7 = a8;
  a8 = a9;
  execute(make__io__struct2_9_0);
  goto make__io__struct2_9_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,make__io__args_10_5);
  *reasonp++ =  a1;
  goto make__io__args_10_interrupt;
  };
  goto make__io__args_10_interrupt;
 make__io__args_10_6:
  if (a0 != makeint(0L)) goto make__io__args_10_interrupt;
  unify3(a9, a8, a4, a3, a6, a5);
  proceed();
 case VARREF:
  deref_and_jump(a0,make__io__args_10_4);
  *reasonp++ =  a0;
  goto make__io__args_10_interrupt;
  };
  goto make__io__args_10_interrupt;
 make__io__args_10_ext_interrupt:
  reasonp = 0l;
 make__io__args_10_interrupt:
  toppred = &predicate_hb_xmake__io__args_10;
  goto interrupt_10;
 }

 make__io__arg_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20, x21, x22, x23, x24, x25, x26, x27, x28;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 make__io__arg_9_clear_reason:
  reasonp = reasons;
 make__io__arg_9_0:
 make__io__arg_9_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 make__io__arg_9_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_tv_2)) goto make__io__arg_9_4;
  x1 = arg(x0, 0);
 make__io__arg_9_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_v_4)) goto make__io__arg_9_4;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xmake__io__arg_9);
  x2 = cdr_of(a0);
  allocp[2] = x2;
  allocp[3] = a1;
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x4 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = x5 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = makesym(functor_v_3);
  x7 = arg(x1, 0);
  allocp[12] = x7;
  x8 = arg(x1, 1);
  allocp[13] = x8;
  x9 = arg(x1, 2);
  allocp[14] = x9;
  x6 = makefunctor(&allocp[11]);
  allocp[15] = makesym(functor_goal_4);
  x11 = arg(x1, 0);
  allocp[16] = x11;
  x12 = arg(x1, 1);
  allocp[17] = x12;
  allocp[18] = makesym(atom___);
  allocp[19] = makesym(atom___);
  x10 = makefunctor(&allocp[15]);
  allocp[20] = (q)(struct goalrec*)&allocp[0];
  allocp[21] = (q)(&predicate_hb_xmake__io__struct3_11);
  allocp[22] = x13 = makeref(&allocp[22]);
  allocp[23] = x6;
  allocp[24] = x14 = makeref(&allocp[24]);
  allocp[25] = x10;
  allocp[26] = x15 = makeref(&allocp[26]);
  allocp[27] = x3;
  allocp[28] = x16 = makeref(&allocp[28]);
  allocp[29] = x4;
  allocp[30] = a6;
  allocp[31] = a7;
  allocp[32] = x5;
  allocp[33] = makesym(functor_v_3);
  x18 = arg(x1, 0);
  allocp[34] = x18;
  x19 = arg(x1, 1);
  allocp[35] = x19;
  x20 = arg(x1, 2);
  allocp[36] = x20;
  x17 = makefunctor(&allocp[33]);
  allocp[37] = (q)(struct goalrec*)&allocp[20];
  allocp[38] = (q)(&predicate_hb_xmake__io__arg2_6);
  allocp[39] = x21 = makeref(&allocp[39]);
  allocp[40] = x17;
  allocp[41] = a2;
  allocp[42] = x15;
  allocp[43] = a4;
  allocp[44] = x16;
  allocp[45] = makesym(functor_v_3);
  x23 = arg(x1, 0);
  allocp[46] = x23;
  x24 = arg(x1, 1);
  allocp[47] = x24;
  x25 = arg(x1, 2);
  allocp[48] = x25;
  x22 = makefunctor(&allocp[45]);
  allocp[49] = (q)(struct goalrec*)&allocp[37];
  allocp[50] = (q)(&predicate_list_xcheck__include_3);
  allocp[51] = x22;
  allocp[52] = a7;
  allocp[53] = x13;
  allocp[54] = (q)(struct goalrec*)&allocp[49];
  allocp[55] = (q)(&predicate_typeset_xcheck__dg_4);
  allocp[56] = a1;
  allocp[57] = x14;
  allocp[58] = x21;
  allocp[59] = makesym(atom_normal);
  allocp[60] = (q)(struct goalrec*)&allocp[54];
  allocp[61] = (q)(&predicate_typeset_xget_5);
  x26 = arg(x1, 0);
  allocp[62] = x26;
  x27 = arg(x1, 1);
  allocp[63] = x27;
  x28 = arg(x1, 2);
  allocp[64] = x28;
  allocp[65] = x14;
  allocp[66] = a6;
  qp = (struct goalrec*)&allocp[60];
  allocp += 67;
  proceed();
 case VARREF:
  deref_and_jump(x1,make__io__arg_9_3);
  *reasonp++ =  x1;
  goto make__io__arg_9_4;
  };
  goto make__io__arg_9_4;
 case VARREF:
  deref_and_jump(x0,make__io__arg_9_2);
  *reasonp++ =  x0;
  goto make__io__arg_9_4;
  };
  goto make__io__arg_9_4;
 case VARREF:
  deref_and_jump(a0,make__io__arg_9_1);
  *reasonp++ =  a0;
  goto make__io__arg_9_4;
  };
  goto make__io__arg_9_4;
 make__io__arg_9_4:
  otherwise(make__io__arg_9_interrupt);
 make__io__arg_9_5:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(make__io__arg_9_0);
  goto make__io__arg_9_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto make__io__arg_9_interrupt;
  unify3(a8, a7, a3, a2, a5, a4);
  proceed();
 case VARREF:
  deref_and_jump(a0,make__io__arg_9_5);
  *reasonp++ =  a0;
  goto make__io__arg_9_interrupt;
  };
  goto make__io__arg_9_interrupt;
 make__io__arg_9_ext_interrupt:
  reasonp = 0l;
 make__io__arg_9_interrupt:
  goto interrupt_9;
 }

 make__io__struct3_11_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 make__io__struct3_11_clear_reason:
  reasonp = reasons;
 make__io__struct3_11_0:
 make__io__struct3_11_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto make__io__struct3_11_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  unify3(a10, a9, a5, a4, a7, a6);
  proceed();
 case symval(makesym(atom_no)):
  allocp[0] = a9;
  allocp[1] = a1;
  x0 = makecons(&allocp[0]);
  a0 = a2;
  a1 = a3;
  a2 = a4;
  a3 = a5;
  a4 = a6;
  a5 = a7;
  a6 = a8;
  a7 = x0;
  a8 = a10;
  allocp += 2;
  execute(make__io__struct2_9_0);
  goto make__io__struct2_9_ext_interrupt;
  };
  goto make__io__struct3_11_interrupt;
 case VARREF:
  deref_and_jump(a0,make__io__struct3_11_1);
  *reasonp++ =  a0;
  goto make__io__struct3_11_interrupt;
  };
  goto make__io__struct3_11_interrupt;
 make__io__struct3_11_ext_interrupt:
  reasonp = 0l;
 make__io__struct3_11_interrupt:
  goto interrupt_11;
 }

 make__io__arg2_6_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 make__io__arg2_6_clear_reason:
  reasonp = reasons;
 make__io__arg2_6_0:
 make__io__arg2_6_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto make__io__arg2_6_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  unify(a3, a2);
  allocp[0] = NILATOM;
  allocp[1] = a1;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_list_xor__unique_3);
  allocp[4] = a4;
  allocp[5] = x0;
  allocp[6] = a5;
  qp = (struct goalrec*)&allocp[2];
  allocp += 7;
  proceed();
 case symval(makesym(atom_no)):
  unify(a5, a4);
  allocp[0] = NILATOM;
  allocp[1] = a1;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_list_xor__unique_3);
  allocp[4] = a2;
  allocp[5] = x0;
  allocp[6] = a3;
  qp = (struct goalrec*)&allocp[2];
  allocp += 7;
  proceed();
  };
  goto make__io__arg2_6_interrupt;
 case VARREF:
  deref_and_jump(a0,make__io__arg2_6_1);
  *reasonp++ =  a0;
  goto make__io__arg2_6_interrupt;
  };
  goto make__io__arg2_6_interrupt;
 make__io__arg2_6_ext_interrupt:
  reasonp = 0l;
 make__io__arg2_6_interrupt:
  goto interrupt_6;
 }

 get__pred_5_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 get__pred_5_clear_reason:
  reasonp = reasons;
 get__pred_5_0:
 get__pred_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 get__pred_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto get__pred_5_7;
  x1 = arg(x0, 0);
 get__pred_5_3:
  if (isref(x1)) goto get__pred_5_6;
 get__pred_5_4:
  if (isref(x1)) goto get__pred_5_5;
  if_not_equal(x1, a1, get__pred_5_7);
  a0 = arg(x0, 1);
  a1 = a2;
  a2 = a3;
  a3 = a4;
  execute(get__pred1_4_clear_reason);
  goto get__pred1_4_ext_interrupt;
 get__pred_5_5:
  deref_and_jump(x1,get__pred_5_4);
  *reasonp++ =  x1;
  goto get__pred_5_7;
 get__pred_5_6:
  deref_and_jump(x1,get__pred_5_3);
  *reasonp++ =  x1;
  goto get__pred_5_7;
 case VARREF:
  deref_and_jump(x0,get__pred_5_2);
  *reasonp++ =  x0;
  goto get__pred_5_7;
  };
  goto get__pred_5_7;
 case VARREF:
  deref_and_jump(a0,get__pred_5_1);
  *reasonp++ =  a0;
  goto get__pred_5_7;
  };
  goto get__pred_5_7;
 get__pred_5_7:
  otherwise(get__pred_5_interrupt);
 get__pred_5_8:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 get__pred_5_9:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto get__pred_5_interrupt;
  a0 = cdr_of(a0);
  execute(get__pred_5_0);
  goto get__pred_5_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,get__pred_5_9);
  *reasonp++ =  x0;
  goto get__pred_5_interrupt;
  };
  goto get__pred_5_interrupt;
 case VARREF:
  deref_and_jump(a0,get__pred_5_8);
  *reasonp++ =  a0;
  goto get__pred_5_interrupt;
  };
  goto get__pred_5_interrupt;
 get__pred_5_ext_interrupt:
  reasonp = 0l;
 get__pred_5_interrupt:
  goto interrupt_5;
 }

 get__pred1_4_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 get__pred1_4_clear_reason:
  reasonp = reasons;
 get__pred1_4_0:
 get__pred1_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 get__pred1_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_7)) goto get__pred1_4_11;
  x1 = arg(x0, 0);
 get__pred1_4_3:
  if (isref(x1)) goto get__pred1_4_10;
 get__pred1_4_4:
  if (isref(x1)) goto get__pred1_4_9;
  if_not_equal(x1, a1, get__pred1_4_11);
  x2 = arg(x0, 1);
 get__pred1_4_5:
  if (isref(x2)) goto get__pred1_4_8;
 get__pred1_4_6:
  if (isref(x2)) goto get__pred1_4_7;
  if_not_equal(x2, a2, get__pred1_4_11);
  unify_value(a3, x0);
  proceed();
 get__pred1_4_7:
  deref_and_jump(x2,get__pred1_4_6);
  *reasonp++ =  x2;
  goto get__pred1_4_11;
 get__pred1_4_8:
  deref_and_jump(x2,get__pred1_4_5);
  *reasonp++ =  x2;
  goto get__pred1_4_11;
 get__pred1_4_9:
  deref_and_jump(x1,get__pred1_4_4);
  *reasonp++ =  x1;
  goto get__pred1_4_11;
 get__pred1_4_10:
  deref_and_jump(x1,get__pred1_4_3);
  *reasonp++ =  x1;
  goto get__pred1_4_11;
 case VARREF:
  deref_and_jump(x0,get__pred1_4_2);
  *reasonp++ =  x0;
  goto get__pred1_4_11;
  };
  goto get__pred1_4_11;
 case VARREF:
  deref_and_jump(a0,get__pred1_4_1);
  *reasonp++ =  a0;
  goto get__pred1_4_11;
  };
  goto get__pred1_4_11;
 get__pred1_4_11:
  otherwise(get__pred1_4_interrupt);
 get__pred1_4_12:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(get__pred1_4_0);
  goto get__pred1_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,get__pred1_4_12);
  *reasonp++ =  a0;
  goto get__pred1_4_interrupt;
  };
  goto get__pred1_4_interrupt;
 get__pred1_4_ext_interrupt:
  reasonp = 0l;
 get__pred1_4_interrupt:
  toppred = &predicate_hb_xget__pred1_4;
  goto interrupt_4;
 }

 get__modes_5_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 get__modes_5_clear_reason:
  reasonp = reasons;
 get__modes_5_0:
 get__modes_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 get__modes_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto get__modes_5_7;
  x1 = arg(x0, 0);
 get__modes_5_3:
  if (isref(x1)) goto get__modes_5_6;
 get__modes_5_4:
  if (isref(x1)) goto get__modes_5_5;
  if_not_equal(x1, a1, get__modes_5_7);
  a0 = arg(x0, 1);
  a1 = a2;
  a2 = a3;
  a3 = a4;
  execute(get__modes1_4_clear_reason);
  goto get__modes1_4_ext_interrupt;
 get__modes_5_5:
  deref_and_jump(x1,get__modes_5_4);
  *reasonp++ =  x1;
  goto get__modes_5_7;
 get__modes_5_6:
  deref_and_jump(x1,get__modes_5_3);
  *reasonp++ =  x1;
  goto get__modes_5_7;
 case VARREF:
  deref_and_jump(x0,get__modes_5_2);
  *reasonp++ =  x0;
  goto get__modes_5_7;
  };
  goto get__modes_5_7;
 case VARREF:
  deref_and_jump(a0,get__modes_5_1);
  *reasonp++ =  a0;
  goto get__modes_5_7;
  };
  goto get__modes_5_7;
 get__modes_5_7:
  otherwise(get__modes_5_interrupt);
 get__modes_5_8:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 get__modes_5_9:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto get__modes_5_interrupt;
  a0 = cdr_of(a0);
  execute(get__modes_5_0);
  goto get__modes_5_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,get__modes_5_9);
  *reasonp++ =  x0;
  goto get__modes_5_interrupt;
  };
  goto get__modes_5_interrupt;
 case VARREF:
  deref_and_jump(a0,get__modes_5_8);
  *reasonp++ =  a0;
  goto get__modes_5_interrupt;
  };
  goto get__modes_5_interrupt;
 get__modes_5_ext_interrupt:
  reasonp = 0l;
 get__modes_5_interrupt:
  goto interrupt_5;
 }

 get__modes1_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 get__modes1_4_clear_reason:
  reasonp = reasons;
 get__modes1_4_0:
 get__modes1_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 get__modes1_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_7)) goto get__modes1_4_11;
  x1 = arg(x0, 0);
 get__modes1_4_3:
  if (isref(x1)) goto get__modes1_4_10;
 get__modes1_4_4:
  if (isref(x1)) goto get__modes1_4_9;
  if_not_equal(x1, a1, get__modes1_4_11);
  x2 = arg(x0, 1);
 get__modes1_4_5:
  if (isref(x2)) goto get__modes1_4_8;
 get__modes1_4_6:
  if (isref(x2)) goto get__modes1_4_7;
  if_not_equal(x2, a2, get__modes1_4_11);
  x3 = arg(x0, 2);
  unify(a3, x3);
  proceed();
 get__modes1_4_7:
  deref_and_jump(x2,get__modes1_4_6);
  *reasonp++ =  x2;
  goto get__modes1_4_11;
 get__modes1_4_8:
  deref_and_jump(x2,get__modes1_4_5);
  *reasonp++ =  x2;
  goto get__modes1_4_11;
 get__modes1_4_9:
  deref_and_jump(x1,get__modes1_4_4);
  *reasonp++ =  x1;
  goto get__modes1_4_11;
 get__modes1_4_10:
  deref_and_jump(x1,get__modes1_4_3);
  *reasonp++ =  x1;
  goto get__modes1_4_11;
 case VARREF:
  deref_and_jump(x0,get__modes1_4_2);
  *reasonp++ =  x0;
  goto get__modes1_4_11;
  };
  goto get__modes1_4_11;
 case VARREF:
  deref_and_jump(a0,get__modes1_4_1);
  *reasonp++ =  a0;
  goto get__modes1_4_11;
  };
  goto get__modes1_4_11;
 get__modes1_4_11:
  otherwise(get__modes1_4_interrupt);
 get__modes1_4_12:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(get__modes1_4_0);
  goto get__modes1_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,get__modes1_4_12);
  *reasonp++ =  a0;
  goto get__modes1_4_interrupt;
  };
  goto get__modes1_4_interrupt;
 get__modes1_4_ext_interrupt:
  reasonp = 0l;
 get__modes1_4_interrupt:
  toppred = &predicate_hb_xget__modes1_4;
  goto interrupt_4;
 }

 get__hio_5_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 get__hio_5_clear_reason:
  reasonp = reasons;
 get__hio_5_0:
 get__hio_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 get__hio_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto get__hio_5_7;
  x1 = arg(x0, 0);
 get__hio_5_3:
  if (isref(x1)) goto get__hio_5_6;
 get__hio_5_4:
  if (isref(x1)) goto get__hio_5_5;
  if_not_equal(x1, a1, get__hio_5_7);
  a0 = arg(x0, 1);
  a1 = a2;
  a2 = a3;
  a3 = a4;
  execute(get__hio1_4_clear_reason);
  goto get__hio1_4_ext_interrupt;
 get__hio_5_5:
  deref_and_jump(x1,get__hio_5_4);
  *reasonp++ =  x1;
  goto get__hio_5_7;
 get__hio_5_6:
  deref_and_jump(x1,get__hio_5_3);
  *reasonp++ =  x1;
  goto get__hio_5_7;
 case VARREF:
  deref_and_jump(x0,get__hio_5_2);
  *reasonp++ =  x0;
  goto get__hio_5_7;
  };
  goto get__hio_5_7;
 case VARREF:
  deref_and_jump(a0,get__hio_5_1);
  *reasonp++ =  a0;
  goto get__hio_5_7;
  };
  goto get__hio_5_7;
 get__hio_5_7:
  otherwise(get__hio_5_interrupt);
 get__hio_5_8:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 get__hio_5_9:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto get__hio_5_interrupt;
  a0 = cdr_of(a0);
  execute(get__hio_5_0);
  goto get__hio_5_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,get__hio_5_9);
  *reasonp++ =  x0;
  goto get__hio_5_interrupt;
  };
  goto get__hio_5_interrupt;
 case VARREF:
  deref_and_jump(a0,get__hio_5_8);
  *reasonp++ =  a0;
  goto get__hio_5_interrupt;
  };
  goto get__hio_5_interrupt;
 get__hio_5_ext_interrupt:
  reasonp = 0l;
 get__hio_5_interrupt:
  toppred = &predicate_hb_xget__hio_5;
  goto interrupt_5;
 }

 get__hio1_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 get__hio1_4_clear_reason:
  reasonp = reasons;
 get__hio1_4_0:
 get__hio1_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 get__hio1_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_7)) goto get__hio1_4_11;
  x1 = arg(x0, 0);
 get__hio1_4_3:
  if (isref(x1)) goto get__hio1_4_10;
 get__hio1_4_4:
  if (isref(x1)) goto get__hio1_4_9;
  if_not_equal(x1, a1, get__hio1_4_11);
  x2 = arg(x0, 1);
 get__hio1_4_5:
  if (isref(x2)) goto get__hio1_4_8;
 get__hio1_4_6:
  if (isref(x2)) goto get__hio1_4_7;
  if_not_equal(x2, a2, get__hio1_4_11);
  x3 = arg(x0, 5);
  unify(a3, x3);
  proceed();
 get__hio1_4_7:
  deref_and_jump(x2,get__hio1_4_6);
  *reasonp++ =  x2;
  goto get__hio1_4_11;
 get__hio1_4_8:
  deref_and_jump(x2,get__hio1_4_5);
  *reasonp++ =  x2;
  goto get__hio1_4_11;
 get__hio1_4_9:
  deref_and_jump(x1,get__hio1_4_4);
  *reasonp++ =  x1;
  goto get__hio1_4_11;
 get__hio1_4_10:
  deref_and_jump(x1,get__hio1_4_3);
  *reasonp++ =  x1;
  goto get__hio1_4_11;
 case VARREF:
  deref_and_jump(x0,get__hio1_4_2);
  *reasonp++ =  x0;
  goto get__hio1_4_11;
  };
  goto get__hio1_4_11;
 case VARREF:
  deref_and_jump(a0,get__hio1_4_1);
  *reasonp++ =  a0;
  goto get__hio1_4_11;
  };
  goto get__hio1_4_11;
 get__hio1_4_11:
  otherwise(get__hio1_4_interrupt);
 get__hio1_4_12:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(get__hio1_4_0);
  goto get__hio1_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,get__hio1_4_12);
  *reasonp++ =  a0;
  goto get__hio1_4_interrupt;
  };
  goto get__hio1_4_interrupt;
 get__hio1_4_ext_interrupt:
  reasonp = 0l;
 get__hio1_4_interrupt:
  toppred = &predicate_hb_xget__hio1_4;
  goto interrupt_4;
 }

 get__bio_5_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 get__bio_5_clear_reason:
  reasonp = reasons;
 get__bio_5_0:
 get__bio_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 get__bio_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto get__bio_5_7;
  x1 = arg(x0, 0);
 get__bio_5_3:
  if (isref(x1)) goto get__bio_5_6;
 get__bio_5_4:
  if (isref(x1)) goto get__bio_5_5;
  if_not_equal(x1, a1, get__bio_5_7);
  a0 = arg(x0, 1);
  a1 = a2;
  a2 = a3;
  a3 = a4;
  execute(get__bio1_4_clear_reason);
  goto get__bio1_4_ext_interrupt;
 get__bio_5_5:
  deref_and_jump(x1,get__bio_5_4);
  *reasonp++ =  x1;
  goto get__bio_5_7;
 get__bio_5_6:
  deref_and_jump(x1,get__bio_5_3);
  *reasonp++ =  x1;
  goto get__bio_5_7;
 case VARREF:
  deref_and_jump(x0,get__bio_5_2);
  *reasonp++ =  x0;
  goto get__bio_5_7;
  };
  goto get__bio_5_7;
 case VARREF:
  deref_and_jump(a0,get__bio_5_1);
  *reasonp++ =  a0;
  goto get__bio_5_7;
  };
  goto get__bio_5_7;
 get__bio_5_7:
  otherwise(get__bio_5_interrupt);
 get__bio_5_8:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 get__bio_5_9:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto get__bio_5_interrupt;
  a0 = cdr_of(a0);
  execute(get__bio_5_0);
  goto get__bio_5_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,get__bio_5_9);
  *reasonp++ =  x0;
  goto get__bio_5_interrupt;
  };
  goto get__bio_5_interrupt;
 case VARREF:
  deref_and_jump(a0,get__bio_5_8);
  *reasonp++ =  a0;
  goto get__bio_5_interrupt;
  };
  goto get__bio_5_interrupt;
 get__bio_5_ext_interrupt:
  reasonp = 0l;
 get__bio_5_interrupt:
  toppred = &predicate_hb_xget__bio_5;
  goto interrupt_5;
 }

 get__bio1_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 get__bio1_4_clear_reason:
  reasonp = reasons;
 get__bio1_4_0:
 get__bio1_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 get__bio1_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_7)) goto get__bio1_4_11;
  x1 = arg(x0, 0);
 get__bio1_4_3:
  if (isref(x1)) goto get__bio1_4_10;
 get__bio1_4_4:
  if (isref(x1)) goto get__bio1_4_9;
  if_not_equal(x1, a1, get__bio1_4_11);
  x2 = arg(x0, 1);
 get__bio1_4_5:
  if (isref(x2)) goto get__bio1_4_8;
 get__bio1_4_6:
  if (isref(x2)) goto get__bio1_4_7;
  if_not_equal(x2, a2, get__bio1_4_11);
  x3 = arg(x0, 6);
  unify(a3, x3);
  proceed();
 get__bio1_4_7:
  deref_and_jump(x2,get__bio1_4_6);
  *reasonp++ =  x2;
  goto get__bio1_4_11;
 get__bio1_4_8:
  deref_and_jump(x2,get__bio1_4_5);
  *reasonp++ =  x2;
  goto get__bio1_4_11;
 get__bio1_4_9:
  deref_and_jump(x1,get__bio1_4_4);
  *reasonp++ =  x1;
  goto get__bio1_4_11;
 get__bio1_4_10:
  deref_and_jump(x1,get__bio1_4_3);
  *reasonp++ =  x1;
  goto get__bio1_4_11;
 case VARREF:
  deref_and_jump(x0,get__bio1_4_2);
  *reasonp++ =  x0;
  goto get__bio1_4_11;
  };
  goto get__bio1_4_11;
 case VARREF:
  deref_and_jump(a0,get__bio1_4_1);
  *reasonp++ =  a0;
  goto get__bio1_4_11;
  };
  goto get__bio1_4_11;
 get__bio1_4_11:
  otherwise(get__bio1_4_interrupt);
 get__bio1_4_12:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(get__bio1_4_0);
  goto get__bio1_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,get__bio1_4_12);
  *reasonp++ =  a0;
  goto get__bio1_4_interrupt;
  };
  goto get__bio1_4_interrupt;
 get__bio1_4_ext_interrupt:
  reasonp = 0l;
 get__bio1_4_interrupt:
  toppred = &predicate_hb_xget__bio1_4;
  goto interrupt_4;
 }

 get__gids_6_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 get__gids_6_clear_reason:
  reasonp = reasons;
 get__gids_6_0:
 get__gids_6_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 get__gids_6_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto get__gids_6_7;
  x1 = arg(x0, 0);
 get__gids_6_3:
  if (isref(x1)) goto get__gids_6_6;
 get__gids_6_4:
  if (isref(x1)) goto get__gids_6_5;
  if_not_equal(x1, a1, get__gids_6_7);
  a0 = arg(x0, 1);
  a1 = a2;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  execute(get__gids1_5_clear_reason);
  goto get__gids1_5_ext_interrupt;
 get__gids_6_5:
  deref_and_jump(x1,get__gids_6_4);
  *reasonp++ =  x1;
  goto get__gids_6_7;
 get__gids_6_6:
  deref_and_jump(x1,get__gids_6_3);
  *reasonp++ =  x1;
  goto get__gids_6_7;
 case VARREF:
  deref_and_jump(x0,get__gids_6_2);
  *reasonp++ =  x0;
  goto get__gids_6_7;
  };
  goto get__gids_6_7;
 case VARREF:
  deref_and_jump(a0,get__gids_6_1);
  *reasonp++ =  a0;
  goto get__gids_6_7;
  };
  goto get__gids_6_7;
 get__gids_6_7:
  otherwise(get__gids_6_interrupt);
 get__gids_6_8:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 get__gids_6_9:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto get__gids_6_interrupt;
  a0 = cdr_of(a0);
  execute(get__gids_6_0);
  goto get__gids_6_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,get__gids_6_9);
  *reasonp++ =  x0;
  goto get__gids_6_interrupt;
  };
  goto get__gids_6_interrupt;
 case VARREF:
  deref_and_jump(a0,get__gids_6_8);
  *reasonp++ =  a0;
  goto get__gids_6_interrupt;
  };
  goto get__gids_6_interrupt;
 get__gids_6_ext_interrupt:
  reasonp = 0l;
 get__gids_6_interrupt:
  goto interrupt_6;
 }

 get__gids1_5_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 get__gids1_5_clear_reason:
  reasonp = reasons;
 get__gids1_5_0:
 get__gids1_5_1:
  switch (ptagof(a0)) {
 case CONS:
 get__gids1_5_2:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (isint(a3)) goto get__gids1_5_21;
  switch (symval(a3)) {
 case symval(makesym(atom_head)):
  x0 = car_of(a0);
 get__gids1_5_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_7)) goto get__gids1_5_21;
  x1 = arg(x0, 0);
 get__gids1_5_4:
  if (isref(x1)) goto get__gids1_5_11;
 get__gids1_5_5:
  if (isref(x1)) goto get__gids1_5_10;
  if_not_equal(x1, a1, get__gids1_5_21);
  x2 = arg(x0, 1);
 get__gids1_5_6:
  if (isref(x2)) goto get__gids1_5_9;
 get__gids1_5_7:
  if (isref(x2)) goto get__gids1_5_8;
  if_not_equal(x2, a2, get__gids1_5_21);
  a0 = arg(x0, 3);
  a1 = a4;
  execute(get__gids2_2_clear_reason);
  goto get__gids2_2_ext_interrupt;
 get__gids1_5_8:
  deref_and_jump(x2,get__gids1_5_7);
  *reasonp++ =  x2;
  goto get__gids1_5_21;
 get__gids1_5_9:
  deref_and_jump(x2,get__gids1_5_6);
  *reasonp++ =  x2;
  goto get__gids1_5_21;
 get__gids1_5_10:
  deref_and_jump(x1,get__gids1_5_5);
  *reasonp++ =  x1;
  goto get__gids1_5_21;
 get__gids1_5_11:
  deref_and_jump(x1,get__gids1_5_4);
  *reasonp++ =  x1;
  goto get__gids1_5_21;
 case VARREF:
  deref_and_jump(x0,get__gids1_5_3);
  *reasonp++ =  x0;
  goto get__gids1_5_21;
  };
  goto get__gids1_5_21;
 case symval(makesym(atom_body)):
  x0 = car_of(a0);
 get__gids1_5_12:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_7)) goto get__gids1_5_21;
  x1 = arg(x0, 0);
 get__gids1_5_13:
  if (isref(x1)) goto get__gids1_5_20;
 get__gids1_5_14:
  if (isref(x1)) goto get__gids1_5_19;
  if_not_equal(x1, a1, get__gids1_5_21);
  x2 = arg(x0, 1);
 get__gids1_5_15:
  if (isref(x2)) goto get__gids1_5_18;
 get__gids1_5_16:
  if (isref(x2)) goto get__gids1_5_17;
  if_not_equal(x2, a2, get__gids1_5_21);
  a0 = arg(x0, 4);
  a1 = a4;
  execute(get__gids2_2_clear_reason);
  goto get__gids2_2_ext_interrupt;
 get__gids1_5_17:
  deref_and_jump(x2,get__gids1_5_16);
  *reasonp++ =  x2;
  goto get__gids1_5_21;
 get__gids1_5_18:
  deref_and_jump(x2,get__gids1_5_15);
  *reasonp++ =  x2;
  goto get__gids1_5_21;
 get__gids1_5_19:
  deref_and_jump(x1,get__gids1_5_14);
  *reasonp++ =  x1;
  goto get__gids1_5_21;
 get__gids1_5_20:
  deref_and_jump(x1,get__gids1_5_13);
  *reasonp++ =  x1;
  goto get__gids1_5_21;
 case VARREF:
  deref_and_jump(x0,get__gids1_5_12);
  *reasonp++ =  x0;
  goto get__gids1_5_21;
  };
  goto get__gids1_5_21;
  };
  goto get__gids1_5_21;
 case VARREF:
  deref_and_jump(a3,get__gids1_5_2);
  *reasonp++ =  a3;
  goto get__gids1_5_21;
  };
  goto get__gids1_5_21;
 case VARREF:
  deref_and_jump(a0,get__gids1_5_1);
  *reasonp++ =  a0;
  goto get__gids1_5_21;
  };
  goto get__gids1_5_21;
 get__gids1_5_21:
  otherwise(get__gids1_5_interrupt);
 get__gids1_5_22:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(get__gids1_5_0);
  goto get__gids1_5_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto get__gids1_5_interrupt;
  x0 = NILATOM;
  unify_value(a4, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,get__gids1_5_22);
  *reasonp++ =  a0;
  goto get__gids1_5_interrupt;
  };
  goto get__gids1_5_interrupt;
 get__gids1_5_ext_interrupt:
  reasonp = 0l;
 get__gids1_5_interrupt:
  toppred = &predicate_hb_xget__gids1_5;
  goto interrupt_5;
 }

 get__gids2_2_top: {
  q x0, x1, x2, x3;
  qp = qp->next;
 get__gids2_2_clear_reason:
  reasonp = reasons;
 get__gids2_2_0:
 get__gids2_2_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto get__gids2_2_3;
 get__gids2_2_2:
  gblt_atom(a0,get__gids2_2_3);
  x0 = makesym(atom_gid);
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,get__gids2_2_1);
  *reasonp++ =  a0;
  goto get__gids2_2_3;
  };
  goto get__gids2_2_3;
 get__gids2_2_3:
  otherwise(get__gids2_2_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xget__gids3_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a1;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xnew__functor_3);
  allocp[8] = x2;
  allocp[9] = makesym(atom_gid);
  allocp[10] = x0;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[13] = x1;
  allocp[14] = x3 = makeref(&allocp[14]);
  allocp[15] = x0;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_functor__table_xarg_3);
  allocp[18] = makeint(1L);
  allocp[19] = a0;
  allocp[20] = x1;
  qp = (struct goalrec*)&allocp[16];
  allocp += 21;
  proceed();
 get__gids2_2_ext_interrupt:
  reasonp = 0l;
 get__gids2_2_interrupt:
  toppred = &predicate_hb_xget__gids2_2;
  goto interrupt_2;
 }

 get__gids3_4_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 get__gids3_4_clear_reason:
  reasonp = reasons;
 get__gids3_4_0:
 get__gids3_4_1:
  if (!isint(a0)) goto get__gids3_4_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,get__gids3_4_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xget__gids3_4);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x1;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[13] = a0;
  allocp[14] = a2;
  allocp[15] = x3 = makeref(&allocp[15]);
  allocp[16] = x2;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_functor__table_xarg_3);
  allocp[19] = makeint(1L);
  allocp[20] = x4 = makeref(&allocp[20]);
  allocp[21] = x3;
  allocp[22] = (q)(struct goalrec*)&allocp[17];
  allocp[23] = (q)(&predicate_functor__table_xarg_3);
  allocp[24] = a0;
  allocp[25] = a1;
  allocp[26] = x4;
  qp = (struct goalrec*)&allocp[22];
  allocp += 27;
  proceed();
 get__gids3_4_2:
  if (a0 != makeint(0L)) goto get__gids3_4_interrupt;
  unify(a3, a2);
  proceed();
 get__gids3_4_3:
  if (!isref(a0)) goto get__gids3_4_interrupt;
  deref_and_jump(a0,get__gids3_4_1);
  *reasonp++ =  a0;
  goto get__gids3_4_interrupt;
 get__gids3_4_ext_interrupt:
  reasonp = 0l;
 get__gids3_4_interrupt:
  goto interrupt_4;
 }

 get__pnmax_6_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 get__pnmax_6_clear_reason:
  reasonp = reasons;
 get__pnmax_6_0:
 get__pnmax_6_1:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (isint(a3)) goto get__pnmax_6_interrupt;
  switch (symval(a3)) {
 case symval(makesym(atom_head)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a4;
  x2 = a5;
  x3 = a0;
  x4 = a1;
  a3 = a2;
  a4 = x0;
  a2 = x4;
  a1 = x3;
  a0 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(get__hio_5_0);
  goto get__hio_5_ext_interrupt;
 case symval(makesym(atom_body)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a4;
  x2 = a5;
  x3 = a0;
  x4 = a1;
  a3 = a2;
  a4 = x0;
  a2 = x4;
  a1 = x3;
  a0 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(get__bio_5_0);
  goto get__bio_5_ext_interrupt;
  };
  goto get__pnmax_6_interrupt;
 case VARREF:
  deref_and_jump(a3,get__pnmax_6_1);
  *reasonp++ =  a3;
  goto get__pnmax_6_interrupt;
  };
  goto get__pnmax_6_interrupt;
 get__pnmax_6_ext_interrupt:
  reasonp = 0l;
 get__pnmax_6_interrupt:
  goto interrupt_6;
 }

 get__pn_7_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 get__pn_7_clear_reason:
  reasonp = reasons;
 get__pn_7_0:
 get__pn_7_1:
  switch (ptagof(a6)) {
 case CONS:
  x0 = car_of(a6);
 get__pn_7_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto get__pn_7_7;
  x1 = arg(x0, 0);
 get__pn_7_3:
  if (isref(x1)) goto get__pn_7_6;
 get__pn_7_4:
  if (isref(x1)) goto get__pn_7_5;
  if_not_equal(x1, a0, get__pn_7_7);
  a0 = arg(x0, 1);
  execute(get__pn1_6_clear_reason);
  goto get__pn1_6_ext_interrupt;
 get__pn_7_5:
  deref_and_jump(x1,get__pn_7_4);
  *reasonp++ =  x1;
  goto get__pn_7_7;
 get__pn_7_6:
  deref_and_jump(x1,get__pn_7_3);
  *reasonp++ =  x1;
  goto get__pn_7_7;
 case VARREF:
  deref_and_jump(x0,get__pn_7_2);
  *reasonp++ =  x0;
  goto get__pn_7_7;
  };
  goto get__pn_7_7;
 case VARREF:
  deref_and_jump(a6,get__pn_7_1);
  *reasonp++ =  a6;
  goto get__pn_7_7;
  };
  goto get__pn_7_7;
 get__pn_7_7:
  otherwise(get__pn_7_interrupt);
 get__pn_7_8:
  switch (ptagof(a6)) {
 case CONS:
  a6 = cdr_of(a6);
  execute(get__pn_7_0);
  goto get__pn_7_ext_interrupt;
 case VARREF:
  deref_and_jump(a6,get__pn_7_8);
  *reasonp++ =  a6;
  goto get__pn_7_interrupt;
  };
  goto get__pn_7_interrupt;
 get__pn_7_ext_interrupt:
  reasonp = 0l;
 get__pn_7_interrupt:
  goto interrupt_7;
 }

 get__pn1_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 get__pn1_6_clear_reason:
  reasonp = reasons;
 get__pn1_6_0:
 get__pn1_6_1:
  switch (ptagof(a0)) {
 case CONS:
 get__pn1_6_2:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (isint(a3)) goto get__pn1_6_25;
  switch (symval(a3)) {
 case symval(makesym(atom_head)):
  x0 = car_of(a0);
 get__pn1_6_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_7)) goto get__pn1_6_25;
  x1 = arg(x0, 0);
 get__pn1_6_4:
  if (isref(x1)) goto get__pn1_6_13;
 get__pn1_6_5:
  if (isref(x1)) goto get__pn1_6_12;
  if_not_equal(x1, a1, get__pn1_6_25);
  x2 = arg(x0, 1);
 get__pn1_6_6:
  if (isref(x2)) goto get__pn1_6_11;
 get__pn1_6_7:
  if (isref(x2)) goto get__pn1_6_10;
  if_not_equal(x2, a2, get__pn1_6_25);
  x3 = arg(x0, 3);
 get__pn1_6_8:
  if (isref(x3)) goto get__pn1_6_9;
  x5 = makeint(1L);
  gblt_arg(x5,x3,x4,get__pn1_6_25);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xget__pn2_4);
  allocp[2] = x6 = makeref(&allocp[2]);
  allocp[3] = x4;
  allocp[4] = a4;
  allocp[5] = a5;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[8] = x4;
  allocp[9] = x7 = makeref(&allocp[9]);
  allocp[10] = x6;
  qp = (struct goalrec*)&allocp[6];
  allocp += 11;
  proceed();
 get__pn1_6_9:
  deref_and_jump(x3,get__pn1_6_8);
  *reasonp++ =  x3;
  goto get__pn1_6_25;
 get__pn1_6_10:
  deref_and_jump(x2,get__pn1_6_7);
  *reasonp++ =  x2;
  goto get__pn1_6_25;
 get__pn1_6_11:
  deref_and_jump(x2,get__pn1_6_6);
  *reasonp++ =  x2;
  goto get__pn1_6_25;
 get__pn1_6_12:
  deref_and_jump(x1,get__pn1_6_5);
  *reasonp++ =  x1;
  goto get__pn1_6_25;
 get__pn1_6_13:
  deref_and_jump(x1,get__pn1_6_4);
  *reasonp++ =  x1;
  goto get__pn1_6_25;
 case VARREF:
  deref_and_jump(x0,get__pn1_6_3);
  *reasonp++ =  x0;
  goto get__pn1_6_25;
  };
  goto get__pn1_6_25;
 case symval(makesym(atom_body)):
  x0 = car_of(a0);
 get__pn1_6_14:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_7)) goto get__pn1_6_25;
  x1 = arg(x0, 0);
 get__pn1_6_15:
  if (isref(x1)) goto get__pn1_6_24;
 get__pn1_6_16:
  if (isref(x1)) goto get__pn1_6_23;
  if_not_equal(x1, a1, get__pn1_6_25);
  x2 = arg(x0, 1);
 get__pn1_6_17:
  if (isref(x2)) goto get__pn1_6_22;
 get__pn1_6_18:
  if (isref(x2)) goto get__pn1_6_21;
  if_not_equal(x2, a2, get__pn1_6_25);
  x3 = arg(x0, 4);
 get__pn1_6_19:
  if (isref(x3)) goto get__pn1_6_20;
  x5 = makeint(1L);
  gblt_arg(x5,x3,x4,get__pn1_6_25);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xget__pn2_4);
  allocp[2] = x6 = makeref(&allocp[2]);
  allocp[3] = x4;
  allocp[4] = a4;
  allocp[5] = a5;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[8] = x4;
  allocp[9] = x7 = makeref(&allocp[9]);
  allocp[10] = x6;
  qp = (struct goalrec*)&allocp[6];
  allocp += 11;
  proceed();
 get__pn1_6_20:
  deref_and_jump(x3,get__pn1_6_19);
  *reasonp++ =  x3;
  goto get__pn1_6_25;
 get__pn1_6_21:
  deref_and_jump(x2,get__pn1_6_18);
  *reasonp++ =  x2;
  goto get__pn1_6_25;
 get__pn1_6_22:
  deref_and_jump(x2,get__pn1_6_17);
  *reasonp++ =  x2;
  goto get__pn1_6_25;
 get__pn1_6_23:
  deref_and_jump(x1,get__pn1_6_16);
  *reasonp++ =  x1;
  goto get__pn1_6_25;
 get__pn1_6_24:
  deref_and_jump(x1,get__pn1_6_15);
  *reasonp++ =  x1;
  goto get__pn1_6_25;
 case VARREF:
  deref_and_jump(x0,get__pn1_6_14);
  *reasonp++ =  x0;
  goto get__pn1_6_25;
  };
  goto get__pn1_6_25;
  };
  goto get__pn1_6_25;
 case VARREF:
  deref_and_jump(a3,get__pn1_6_2);
  *reasonp++ =  a3;
  goto get__pn1_6_25;
  };
  goto get__pn1_6_25;
 case VARREF:
  deref_and_jump(a0,get__pn1_6_1);
  *reasonp++ =  a0;
  goto get__pn1_6_25;
  };
  goto get__pn1_6_25;
 get__pn1_6_25:
  otherwise(get__pn1_6_interrupt);
 get__pn1_6_26:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(get__pn1_6_0);
  goto get__pn1_6_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,get__pn1_6_26);
  *reasonp++ =  a0;
  goto get__pn1_6_interrupt;
  };
  goto get__pn1_6_interrupt;
 get__pn1_6_ext_interrupt:
  reasonp = 0l;
 get__pn1_6_interrupt:
  toppred = &predicate_hb_xget__pn1_6;
  goto interrupt_6;
 }

 get__pn2_4_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 get__pn2_4_clear_reason:
  reasonp = reasons;
 get__pn2_4_0:
 get__pn2_4_1:
  if (!isint(a0)) goto get__pn2_4_21;
  x0 = makeint(0L);
  gblt_greater(a0,x0,get__pn2_4_22);
 get__pn2_4_2:
  if (isref(a1)) goto get__pn2_4_20;
  gblt_arg(a0,a1,x1,get__pn2_4_22);
 get__pn2_4_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  switch (symval(functor_of(x1))) {
 case functor_arg_2:
  x2 = arg(x1, 0);
 get__pn2_4_4:
  if (isref(x2)) goto get__pn2_4_7;
 get__pn2_4_5:
  if (isref(x2)) goto get__pn2_4_6;
  if_not_equal(x2, a2, get__pn2_4_22);
  unify_value(a3, a0);
  proceed();
 get__pn2_4_6:
  deref_and_jump(x2,get__pn2_4_5);
  *reasonp++ =  x2;
  goto get__pn2_4_22;
 get__pn2_4_7:
  deref_and_jump(x2,get__pn2_4_4);
  *reasonp++ =  x2;
  goto get__pn2_4_22;
 case functor_sharedarg_2:
  x2 = arg(x1, 0);
 get__pn2_4_8:
  if (isref(x2)) goto get__pn2_4_11;
 get__pn2_4_9:
  if (isref(x2)) goto get__pn2_4_10;
  if_not_equal(x2, a2, get__pn2_4_22);
  unify_value(a3, a0);
  proceed();
 get__pn2_4_10:
  deref_and_jump(x2,get__pn2_4_9);
  *reasonp++ =  x2;
  goto get__pn2_4_22;
 get__pn2_4_11:
  deref_and_jump(x2,get__pn2_4_8);
  *reasonp++ =  x2;
  goto get__pn2_4_22;
 case functor_entryarg_2:
  x2 = arg(x1, 0);
 get__pn2_4_12:
  if (isref(x2)) goto get__pn2_4_15;
 get__pn2_4_13:
  if (isref(x2)) goto get__pn2_4_14;
  if_not_equal(x2, a2, get__pn2_4_22);
  unify_value(a3, a0);
  proceed();
 get__pn2_4_14:
  deref_and_jump(x2,get__pn2_4_13);
  *reasonp++ =  x2;
  goto get__pn2_4_22;
 get__pn2_4_15:
  deref_and_jump(x2,get__pn2_4_12);
  *reasonp++ =  x2;
  goto get__pn2_4_22;
 case functor_recursivearg_2:
  x2 = arg(x1, 0);
 get__pn2_4_16:
  if (isref(x2)) goto get__pn2_4_19;
 get__pn2_4_17:
  if (isref(x2)) goto get__pn2_4_18;
  if_not_equal(x2, a2, get__pn2_4_22);
  unify_value(a3, a0);
  proceed();
 get__pn2_4_18:
  deref_and_jump(x2,get__pn2_4_17);
  *reasonp++ =  x2;
  goto get__pn2_4_22;
 get__pn2_4_19:
  deref_and_jump(x2,get__pn2_4_16);
  *reasonp++ =  x2;
  goto get__pn2_4_22;
  };
  goto get__pn2_4_22;
 case VARREF:
  deref_and_jump(x1,get__pn2_4_3);
  *reasonp++ =  x1;
  goto get__pn2_4_22;
  };
  goto get__pn2_4_22;
 get__pn2_4_20:
  deref_and_jump(a1,get__pn2_4_2);
  *reasonp++ =  a1;
  goto get__pn2_4_22;
 get__pn2_4_21:
  if (!isref(a0)) goto get__pn2_4_22;
  deref_and_jump(a0,get__pn2_4_1);
  *reasonp++ =  a0;
  goto get__pn2_4_22;
 get__pn2_4_22:
  otherwise(get__pn2_4_interrupt);
 get__pn2_4_23:
  if (!isint(a0)) goto get__pn2_4_24;
  x0 = makeint(0L);
  gblt_greater(a0,x0,get__pn2_4_interrupt);
  x1 = makeint(1L);
  bblt_sub_no_check(a0,x1,x2);
  a0 = x2;
  execute(get__pn2_4_0);
  goto get__pn2_4_ext_interrupt;
 get__pn2_4_24:
  if (!isref(a0)) goto get__pn2_4_interrupt;
  deref_and_jump(a0,get__pn2_4_23);
  *reasonp++ =  a0;
  goto get__pn2_4_interrupt;
 get__pn2_4_ext_interrupt:
  reasonp = 0l;
 get__pn2_4_interrupt:
  goto interrupt_4;
 }

 check__infile_6_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 check__infile_6_clear_reason:
  reasonp = reasons;
 check__infile_6_0:
 check__infile_6_1:
  switch (ptagof(a4)) {
 case CONS:
  x0 = car_of(a4);
 check__infile_6_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto check__infile_6_7;
  x1 = arg(x0, 0);
 check__infile_6_3:
  if (isref(x1)) goto check__infile_6_6;
 check__infile_6_4:
  if (isref(x1)) goto check__infile_6_5;
  if_not_equal(x1, a0, check__infile_6_7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xcheck__infile2_7);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  x3 = cdr_of(a4);
  allocp[7] = x3;
  allocp[8] = a5;
  a0 = arg(x0, 1);
  a4 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 9;
  execute(check__infile__preds_5_clear_reason);
  goto check__infile__preds_5_ext_interrupt;
 check__infile_6_5:
  deref_and_jump(x1,check__infile_6_4);
  *reasonp++ =  x1;
  goto check__infile_6_7;
 check__infile_6_6:
  deref_and_jump(x1,check__infile_6_3);
  *reasonp++ =  x1;
  goto check__infile_6_7;
 case VARREF:
  deref_and_jump(x0,check__infile_6_2);
  *reasonp++ =  x0;
  goto check__infile_6_7;
  };
  goto check__infile_6_7;
 case VARREF:
  deref_and_jump(a4,check__infile_6_1);
  *reasonp++ =  a4;
  goto check__infile_6_7;
  };
  goto check__infile_6_7;
 check__infile_6_7:
  otherwise(check__infile_6_interrupt);
 check__infile_6_8:
  switch (ptagof(a4)) {
 case CONS:
  a4 = cdr_of(a4);
  execute(check__infile_6_0);
  goto check__infile_6_ext_interrupt;
 case ATOMIC:
  if (a4 != NILATOM) goto check__infile_6_interrupt;
  x0 = makesym(atom_no);
  unify_value(a5, x0);
  proceed();
 case VARREF:
  deref_and_jump(a4,check__infile_6_8);
  *reasonp++ =  a4;
  goto check__infile_6_interrupt;
  };
  goto check__infile_6_interrupt;
 check__infile_6_ext_interrupt:
  reasonp = 0l;
 check__infile_6_interrupt:
  toppred = &predicate_hb_xcheck__infile_6;
  goto interrupt_6;
 }

 check__infile__preds_5_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 check__infile__preds_5_clear_reason:
  reasonp = reasons;
 check__infile__preds_5_0:
 check__infile__preds_5_1:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (isint(a3)) goto check__infile__preds_5_22;
  switch (symval(a3)) {
 case symval(makesym(atom_body)):
 check__infile__preds_5_2:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 check__infile__preds_5_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_7)) goto check__infile__preds_5_22;
  x1 = arg(x0, 0);
 check__infile__preds_5_4:
  if (isref(x1)) goto check__infile__preds_5_11;
 check__infile__preds_5_5:
  if (isref(x1)) goto check__infile__preds_5_10;
  if_not_equal(x1, a1, check__infile__preds_5_22);
  x2 = arg(x0, 1);
 check__infile__preds_5_6:
  if (isref(x2)) goto check__infile__preds_5_9;
 check__infile__preds_5_7:
  if (isref(x2)) goto check__infile__preds_5_8;
  if_not_equal(x2, a2, check__infile__preds_5_22);
  a0 = a2;
  a1 = arg(x0, 4);
  a2 = a4;
  execute(check__infile__args_3_clear_reason);
  goto check__infile__args_3_ext_interrupt;
 check__infile__preds_5_8:
  deref_and_jump(x2,check__infile__preds_5_7);
  *reasonp++ =  x2;
  goto check__infile__preds_5_22;
 check__infile__preds_5_9:
  deref_and_jump(x2,check__infile__preds_5_6);
  *reasonp++ =  x2;
  goto check__infile__preds_5_22;
 check__infile__preds_5_10:
  deref_and_jump(x1,check__infile__preds_5_5);
  *reasonp++ =  x1;
  goto check__infile__preds_5_22;
 check__infile__preds_5_11:
  deref_and_jump(x1,check__infile__preds_5_4);
  *reasonp++ =  x1;
  goto check__infile__preds_5_22;
 case VARREF:
  deref_and_jump(x0,check__infile__preds_5_3);
  *reasonp++ =  x0;
  goto check__infile__preds_5_22;
  };
  goto check__infile__preds_5_22;
 case VARREF:
  deref_and_jump(a0,check__infile__preds_5_2);
  *reasonp++ =  a0;
  goto check__infile__preds_5_22;
  };
  goto check__infile__preds_5_22;
 case symval(makesym(atom_head)):
 check__infile__preds_5_12:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 check__infile__preds_5_13:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_7)) goto check__infile__preds_5_22;
  x1 = arg(x0, 0);
 check__infile__preds_5_14:
  if (isref(x1)) goto check__infile__preds_5_21;
 check__infile__preds_5_15:
  if (isref(x1)) goto check__infile__preds_5_20;
  if_not_equal(x1, a1, check__infile__preds_5_22);
  x2 = arg(x0, 1);
 check__infile__preds_5_16:
  if (isref(x2)) goto check__infile__preds_5_19;
 check__infile__preds_5_17:
  if (isref(x2)) goto check__infile__preds_5_18;
  if_not_equal(x2, a2, check__infile__preds_5_22);
  a0 = a2;
  a1 = arg(x0, 3);
  a2 = a4;
  execute(check__infile__args_3_clear_reason);
  goto check__infile__args_3_ext_interrupt;
 check__infile__preds_5_18:
  deref_and_jump(x2,check__infile__preds_5_17);
  *reasonp++ =  x2;
  goto check__infile__preds_5_22;
 check__infile__preds_5_19:
  deref_and_jump(x2,check__infile__preds_5_16);
  *reasonp++ =  x2;
  goto check__infile__preds_5_22;
 check__infile__preds_5_20:
  deref_and_jump(x1,check__infile__preds_5_15);
  *reasonp++ =  x1;
  goto check__infile__preds_5_22;
 check__infile__preds_5_21:
  deref_and_jump(x1,check__infile__preds_5_14);
  *reasonp++ =  x1;
  goto check__infile__preds_5_22;
 case VARREF:
  deref_and_jump(x0,check__infile__preds_5_13);
  *reasonp++ =  x0;
  goto check__infile__preds_5_22;
  };
  goto check__infile__preds_5_22;
 case VARREF:
  deref_and_jump(a0,check__infile__preds_5_12);
  *reasonp++ =  a0;
  goto check__infile__preds_5_22;
  };
  goto check__infile__preds_5_22;
  };
  goto check__infile__preds_5_22;
 case VARREF:
  deref_and_jump(a3,check__infile__preds_5_1);
  *reasonp++ =  a3;
  goto check__infile__preds_5_22;
  };
  goto check__infile__preds_5_22;
 check__infile__preds_5_22:
  otherwise(check__infile__preds_5_interrupt);
 check__infile__preds_5_23:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(check__infile__preds_5_0);
  goto check__infile__preds_5_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto check__infile__preds_5_interrupt;
  x0 = makesym(atom_no);
  unify_value(a4, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,check__infile__preds_5_23);
  *reasonp++ =  a0;
  goto check__infile__preds_5_interrupt;
  };
  goto check__infile__preds_5_interrupt;
 check__infile__preds_5_ext_interrupt:
  reasonp = 0l;
 check__infile__preds_5_interrupt:
  toppred = &predicate_hb_xcheck__infile__preds_5;
  goto interrupt_5;
 }

 check__infile__args_3_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  qp = qp->next;
 check__infile__args_3_clear_reason:
  reasonp = reasons;
 check__infile__args_3_0:
 check__infile__args_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 check__infile__args_3_2:
  if (a0 != makeint(0L)) goto check__infile__args_3_3;
  x0 = makesym(atom_yes);
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,check__infile__args_3_1);
  *reasonp++ =  a0;
  goto check__infile__args_3_3;
  };
  goto check__infile__args_3_3;
 check__infile__args_3_3:
  otherwise(check__infile__args_3_interrupt);
 check__infile__args_3_4:
  if (isref(a1)) goto check__infile__args_3_10;
  x1 = makeint(1L);
  gblt_arg(x1,a1,x0,check__infile__args_3_11);
 check__infile__args_3_5:
  if (isref(x0)) goto check__infile__args_3_9;
  x3 = makeint(1L);
  gblt_arg(x3,x0,x2,check__infile__args_3_11);
 check__infile__args_3_6:
  if (isref(x2)) goto check__infile__args_3_8;
  gblt_pfunctor(x2,x4,check__infile__args_3_11);
  gblt_arity(x2,x5,check__infile__args_3_11);
 check__infile__args_3_7:
  if (x5 != makeint(2L)) goto check__infile__args_3_11;
  x6 = makesym(atom_yes);
  unify_value(a2, x6);
  proceed();
 check__infile__args_3_8:
  deref_and_jump(x2,check__infile__args_3_6);
  *reasonp++ =  x2;
  goto check__infile__args_3_11;
 check__infile__args_3_9:
  deref_and_jump(x0,check__infile__args_3_5);
  *reasonp++ =  x0;
  goto check__infile__args_3_11;
 check__infile__args_3_10:
  deref_and_jump(a1,check__infile__args_3_4);
  *reasonp++ =  a1;
  goto check__infile__args_3_11;
 check__infile__args_3_11:
  otherwise(check__infile__args_3_interrupt);
  x0 = makesym(atom_no);
  unify_value(a2, x0);
  proceed();
 check__infile__args_3_ext_interrupt:
  reasonp = 0l;
 check__infile__args_3_interrupt:
  toppred = &predicate_hb_xcheck__infile__args_3;
  goto interrupt_3;
 }

 check__infile2_7_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 check__infile2_7_clear_reason:
  reasonp = reasons;
 check__infile2_7_0:
 check__infile2_7_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto check__infile2_7_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  x0 = makesym(atom_yes);
  unify_value(a6, x0);
  proceed();
 case symval(makesym(atom_no)):
  a0 = a1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  a5 = a6;
  execute(check__infile_6_0);
  goto check__infile_6_ext_interrupt;
  };
  goto check__infile2_7_interrupt;
 case VARREF:
  deref_and_jump(a0,check__infile2_7_1);
  *reasonp++ =  a0;
  goto check__infile2_7_interrupt;
  };
  goto check__infile2_7_interrupt;
 check__infile2_7_ext_interrupt:
  reasonp = 0l;
 check__infile2_7_interrupt:
  goto interrupt_7;
 }
 interrupt_14:
  allocp[15] = a13;
 interrupt_13:
  allocp[14] = a12;
 interrupt_12:
  allocp[13] = a11;
 interrupt_11:
  allocp[12] = a10;
 interrupt_10:
  allocp[11] = a9;
 interrupt_9:
  allocp[10] = a8;
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_hb);
}
