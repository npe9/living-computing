/* Compiled by KLIC compiler version 3.002 (Wed Sep 17 15:37:13 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_main();
Const struct predicate predicate_main_xmain_0 =
   { module_main, 0, 0 };
extern Const struct predicate predicate_unix_xargv_1;
extern Const struct predicate predicate_ganalyzer_xmain_2;

module module_main(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{

  q *reasonp;
 module_top:
  switch_on_pred() {
    last_case_pred(0, main_0_top);
  }

 main_0_top: {
  q x0;
  qp = qp->next;
 main_0_clear_reason:
  reasonp = reasons;
 main_0_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xmain_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = makesym(atom_normal);
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_unix_xargv_1);
  allocp[6] = x0;
  qp = (struct goalrec*)&allocp[4];
  allocp += 7;
  proceed();
 main_0_ext_interrupt:
  reasonp = 0l;
 main_0_interrupt:
  goto interrupt_0;
 }
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_main);
}
