/* Compiled by KLIC compiler version 3.002 (Wed Sep 17 15:37:13 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_ganalyzer();
Const struct predicate predicate_ganalyzer_xmain_2 =
   { module_ganalyzer, 0, 2 };
Const struct predicate predicate_ganalyzer_xmerge__gea_3 =
   { module_ganalyzer, 1, 3 };
Const struct predicate predicate_ganalyzer_xinit__gea_2 =
   { module_ganalyzer, 2, 2 };
Const struct predicate predicate_ganalyzer_xmerge__gea_4 =
   { module_ganalyzer, 3, 4 };
Const struct predicate predicate_ganalyzer_xmerge__gea_5 =
   { module_ganalyzer, 4, 5 };
Const struct predicate predicate_ganalyzer_xmake__gea_4 =
   { module_ganalyzer, 5, 4 };
Const struct predicate predicate_ganalyzer_xinsert__ea_3 =
   { module_ganalyzer, 6, 3 };
Const struct predicate predicate_ganalyzer_xinsert__preds_3 =
   { module_ganalyzer, 7, 3 };
Const struct predicate predicate_ganalyzer_xinsert__pred_3 =
   { module_ganalyzer, 8, 3 };
Const struct predicate predicate_ganalyzer_xinsert__entries_4 =
   { module_ganalyzer, 9, 4 };
Const struct predicate predicate_ganalyzer_xfix__type_7 =
   { module_ganalyzer, 10, 7 };
Const struct predicate predicate_ganalyzer_xfix__type2_8 =
   { module_ganalyzer, 11, 8 };
Const struct predicate predicate_ganalyzer_xfix__type_9 =
   { module_ganalyzer, 12, 9 };
Const struct predicate predicate_ganalyzer_xfix__type_10 =
   { module_ganalyzer, 13, 10 };
Const struct predicate predicate_ganalyzer_xfix__type__modules_9 =
   { module_ganalyzer, 14, 9 };
Const struct predicate predicate_ganalyzer_xfix__type__preds_11 =
   { module_ganalyzer, 15, 11 };
Const struct predicate predicate_ganalyzer_xfix__type__pred_11 =
   { module_ganalyzer, 16, 11 };
Const struct predicate predicate_ganalyzer_xfix__type__entries_13 =
   { module_ganalyzer, 17, 13 };
Const struct predicate predicate_ganalyzer_xfix__type__entries_14 =
   { module_ganalyzer, 18, 14 };
Const struct predicate predicate_ganalyzer_xfix__type__arg_16 =
   { module_ganalyzer, 19, 16 };
Const struct predicate predicate_ganalyzer_xfix__type__arg_21 =
   { module_ganalyzer, 20, 21 };
Const struct predicate predicate_ganalyzer_xremove__tt_5 =
   { module_ganalyzer, 21, 5 };
Const struct predicate predicate_ganalyzer_xremove__tt2_4 =
   { module_ganalyzer, 22, 4 };
Const struct predicate predicate_ganalyzer_xremove__tt3_6 =
   { module_ganalyzer, 23, 6 };
Const struct predicate predicate_ganalyzer_xcheck__position_3 =
   { module_ganalyzer, 24, 3 };
Const struct predicate predicate_ganalyzer_xmake__outposition_4 =
   { module_ganalyzer, 25, 4 };
Const struct predicate predicate_ganalyzer_xreplace__tt_7 =
   { module_ganalyzer, 26, 7 };
Const struct predicate predicate_ganalyzer_xreplace__tt2_7 =
   { module_ganalyzer, 27, 7 };
Const struct predicate predicate_ganalyzer_xreplace__tt__gvt_6 =
   { module_ganalyzer, 28, 6 };
Const struct predicate predicate_ganalyzer_xreplace__tt__vt_5 =
   { module_ganalyzer, 29, 5 };
Const struct predicate predicate_ganalyzer_xreplace__tt__vt__clauses_6 =
   { module_ganalyzer, 30, 6 };
Const struct predicate predicate_ganalyzer_xreplace__tt__vt__clause_6 =
   { module_ganalyzer, 31, 6 };
Const struct predicate predicate_ganalyzer_xreplace__tt__te_5 =
   { module_ganalyzer, 32, 5 };
Const struct predicate predicate_ganalyzer_xreplace__tt__te_6 =
   { module_ganalyzer, 33, 6 };
Const struct predicate predicate_ganalyzer_xmake__te_5 =
   { module_ganalyzer, 34, 5 };
Const struct predicate predicate_ganalyzer_xmake__te_6 =
   { module_ganalyzer, 35, 6 };
Const struct predicate predicate_ganalyzer_xmake__te1_5 =
   { module_ganalyzer, 36, 5 };
Const struct predicate predicate_ganalyzer_xcond1_12 =
   { module_ganalyzer, 37, 12 };
Const struct predicate predicate_ganalyzer_xcheck__ts_3 =
   { module_ganalyzer, 38, 3 };
Const struct predicate predicate_ganalyzer_xsplit__ts_5 =
   { module_ganalyzer, 39, 5 };
Const struct predicate predicate_ganalyzer_xcheck__ts2_3 =
   { module_ganalyzer, 40, 3 };
Const struct predicate predicate_ganalyzer_xread__arg__ts_5 =
   { module_ganalyzer, 41, 5 };
Const struct predicate predicate_ganalyzer_xread__arg__ts_6 =
   { module_ganalyzer, 42, 6 };
Const struct predicate predicate_ganalyzer_xread__arg__ts_7 =
   { module_ganalyzer, 43, 7 };
Const struct predicate predicate_ganalyzer_xwrite__arg__ts_6 =
   { module_ganalyzer, 44, 6 };
Const struct predicate predicate_ganalyzer_xwrite__arg__ts_7 =
   { module_ganalyzer, 45, 7 };
Const struct predicate predicate_ganalyzer_xget__same__pred__head_4 =
   { module_ganalyzer, 46, 4 };
Const struct predicate predicate_ganalyzer_xremove__all__tt_2 =
   { module_ganalyzer, 47, 2 };
Const struct predicate predicate_ganalyzer_xremove__all__tt_3 =
   { module_ganalyzer, 48, 3 };
Const struct predicate predicate_ganalyzer_xremove__all__tt__vt_2 =
   { module_ganalyzer, 49, 2 };
Const struct predicate predicate_ganalyzer_xremove__all__tt__clauses_3 =
   { module_ganalyzer, 50, 3 };
Const struct predicate predicate_ganalyzer_xremove__all__tt__clause_3 =
   { module_ganalyzer, 51, 3 };
Const struct predicate predicate_ganalyzer_xremove__all__tt__ts_2 =
   { module_ganalyzer, 52, 2 };
Const struct predicate predicate_ganalyzer_xremove__all__tt__ts2_2 =
   { module_ganalyzer, 53, 2 };
Const struct predicate predicate_ganalyzer_xwrite__extern__mode_9 =
   { module_ganalyzer, 54, 9 };
Const struct predicate predicate_ganalyzer_xwrite__extern__mode_10 =
   { module_ganalyzer, 55, 10 };
Const struct predicate predicate_ganalyzer_xfix__mode_5 =
   { module_ganalyzer, 56, 5 };
Const struct predicate predicate_ganalyzer_xfix__mode_6 =
   { module_ganalyzer, 57, 6 };
Const struct predicate predicate_ganalyzer_xfix__mode__module_5 =
   { module_ganalyzer, 58, 5 };
Const struct predicate predicate_ganalyzer_xfix__mode__preds_6 =
   { module_ganalyzer, 59, 6 };
Const struct predicate predicate_ganalyzer_xfix__mode__pred_11 =
   { module_ganalyzer, 60, 11 };
Const struct predicate predicate_ganalyzer_xfix__mode__args_10 =
   { module_ganalyzer, 61, 10 };
Const struct predicate predicate_ganalyzer_xget__ds_6 =
   { module_ganalyzer, 62, 6 };
Const struct predicate predicate_ganalyzer_xremove__ds_3 =
   { module_ganalyzer, 63, 3 };
Const struct predicate predicate_ganalyzer_xremove__ds2_5 =
   { module_ganalyzer, 64, 5 };
Const struct predicate predicate_ganalyzer_xget__new__mode_3 =
   { module_ganalyzer, 65, 3 };
extern Const struct predicate predicate_print_xdatan_1;
extern Const struct predicate predicate_list_xor__unique_3;
extern Const struct predicate predicate_list_xcheck__include_3;
extern Const struct predicate predicate_functor_xnew__functor__init_4;
extern Const struct predicate predicate_functor_xinsert__arg_4;
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_xsetarg_4;
extern Const struct predicate predicate_functor__table_xfunctor_3;
extern Const struct predicate predicate_global__op_xread__aifiles_8;
extern Const struct predicate predicate_global__op_xwrite__ai1_5;
extern Const struct predicate predicate_global__op_xget__fileno_3;
extern Const struct predicate predicate_global__op_xread__mode_7;
extern Const struct predicate predicate_global__op_xwrite__mode_8;
extern Const struct predicate predicate_global__op_xread__ts_6;
extern Const struct predicate predicate_global__op_xwrite__ts_7;
extern Const struct predicate predicate_typeset_xadd__dgoals_4;
extern Const struct predicate predicate_typeset_xadd__dgoal_4;
extern Const struct predicate predicate_typeset_xor__typeset_3;
extern Const struct predicate predicate_typeset_xget__ds_5;
extern Const struct predicate predicate_hb_xwrite__mode_7;

module module_ganalyzer(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  static Const unsigned char strconst_body_0[4] =
    {'.','a','i','0',};
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_0 =
      declare_string_constant_8(strconst_body_0,4);
  static Const q cons_const_1[] = {
    NILATOM,
    makesym(atom__2A),
  };
  q a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17, a18, a19, a20;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, main_2_top);
    case_pred(1, merge__gea_3_top);
    case_pred(2, init__gea_2_top);
    case_pred(3, merge__gea_4_top);
    case_pred(4, merge__gea_5_top);
    case_pred(5, make__gea_4_top);
    case_pred(6, insert__ea_3_top);
    case_pred(7, insert__preds_3_top);
    case_pred(8, insert__pred_3_top);
    case_pred(9, insert__entries_4_top);
    case_pred(10, fix__type_7_top);
    case_pred(11, fix__type2_8_top);
    case_pred(12, fix__type_9_top);
    case_pred(13, fix__type_10_top);
    case_pred(14, fix__type__modules_9_top);
    case_pred(15, fix__type__preds_11_top);
    case_pred(16, fix__type__pred_11_top);
    case_pred(17, fix__type__entries_13_top);
    case_pred(18, fix__type__entries_14_top);
    case_pred(19, fix__type__arg_16_top);
    case_pred(20, fix__type__arg_21_top);
    case_pred(21, remove__tt_5_top);
    case_pred(22, remove__tt2_4_top);
    case_pred(23, remove__tt3_6_top);
    case_pred(24, check__position_3_top);
    case_pred(25, make__outposition_4_top);
    case_pred(26, replace__tt_7_top);
    case_pred(27, replace__tt2_7_top);
    case_pred(28, replace__tt__gvt_6_top);
    case_pred(29, replace__tt__vt_5_top);
    case_pred(30, replace__tt__vt__clauses_6_top);
    case_pred(31, replace__tt__vt__clause_6_top);
    case_pred(32, replace__tt__te_5_top);
    case_pred(33, replace__tt__te_6_top);
    case_pred(34, make__te_5_top);
    case_pred(35, make__te_6_top);
    case_pred(36, make__te1_5_top);
    case_pred(37, cond1_12_top);
    case_pred(38, check__ts_3_top);
    case_pred(39, split__ts_5_top);
    case_pred(40, check__ts2_3_top);
    case_pred(41, read__arg__ts_5_top);
    case_pred(42, read__arg__ts_6_top);
    case_pred(43, read__arg__ts_7_top);
    case_pred(44, write__arg__ts_6_top);
    case_pred(45, write__arg__ts_7_top);
    case_pred(46, get__same__pred__head_4_top);
    case_pred(47, remove__all__tt_2_top);
    case_pred(48, remove__all__tt_3_top);
    case_pred(49, remove__all__tt__vt_2_top);
    case_pred(50, remove__all__tt__clauses_3_top);
    case_pred(51, remove__all__tt__clause_3_top);
    case_pred(52, remove__all__tt__ts_2_top);
    case_pred(53, remove__all__tt__ts2_2_top);
    case_pred(54, write__extern__mode_9_top);
    case_pred(55, write__extern__mode_10_top);
    case_pred(56, fix__mode_5_top);
    case_pred(57, fix__mode_6_top);
    case_pred(58, fix__mode__module_5_top);
    case_pred(59, fix__mode__preds_6_top);
    case_pred(60, fix__mode__pred_11_top);
    case_pred(61, fix__mode__args_10_top);
    case_pred(62, get__ds_6_top);
    case_pred(63, remove__ds_3_top);
    case_pred(64, remove__ds2_5_top);
    last_case_pred(65, get__new__mode_3_top);
  }

 main_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  qp = qp->next;
 main_2_clear_reason:
  reasonp = reasons;
 main_2_0:
 main_2_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_normal)) goto main_2_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_print_xdatan_1);
  allocp[2] = makesym(atom__3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_20Global_20Analysis_20End_20_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D);
  allocp[3] = (q)(struct goalrec*)&allocp[0];
  allocp[4] = (q)(&predicate_global__op_xwrite__ai1_5);
  allocp[5] = x0 = makeref(&allocp[5]);
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = x4 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[3];
  allocp[11] = (q)(&predicate_print_xdatan_1);
  allocp[12] = makesym(atom__2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_20Writing_20ai1_20Files_20_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B);
  allocp[13] = (q)(struct goalrec*)&allocp[10];
  allocp[14] = (q)(&predicate_ganalyzer_xfix__mode_5);
  allocp[15] = x5 = makeref(&allocp[15]);
  allocp[16] = x0;
  allocp[17] = x6 = makeref(&allocp[17]);
  allocp[18] = x5;
  allocp[19] = x1;
  allocp[20] = (q)(struct goalrec*)&allocp[13];
  allocp[21] = (q)(&predicate_ganalyzer_xremove__all__tt_2);
  allocp[22] = x7 = makeref(&allocp[22]);
  allocp[23] = x0;
  allocp[24] = (q)(struct goalrec*)&allocp[20];
  allocp[25] = (q)(&predicate_ganalyzer_xfix__type_7);
  allocp[26] = x6;
  allocp[27] = x4;
  allocp[28] = x8 = makeref(&allocp[28]);
  allocp[29] = x9 = makeref(&allocp[29]);
  allocp[30] = x7;
  allocp[31] = x10 = makeref(&allocp[31]);
  allocp[32] = x5;
  allocp[33] = (q)(struct goalrec*)&allocp[24];
  allocp[34] = (q)(&predicate_print_xdatan_1);
  allocp[35] = makesym(atom__2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_20Fixing_20Variable_20Types_20_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B);
  allocp[36] = (q)(struct goalrec*)&allocp[33];
  allocp[37] = (q)(&predicate_ganalyzer_xmerge__gea_3);
  allocp[38] = x2;
  allocp[39] = x6;
  allocp[40] = x8;
  allocp[41] = (q)(struct goalrec*)&allocp[36];
  allocp[42] = (q)(&predicate_global__op_xread__aifiles_8);
  allocp[43] = makefunctor(&string_const_0);
  allocp[44] = a0;
  allocp[45] = x9;
  allocp[46] = x10;
  allocp[47] = x2;
  allocp[48] = x3;
  allocp[49] = x4;
  allocp[50] = x6;
  allocp[51] = (q)(struct goalrec*)&allocp[41];
  allocp[52] = (q)(&predicate_print_xdatan_1);
  allocp[53] = makesym(atom__2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_20Reading_20ai0_20Files_20_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B_2B);
  allocp[54] = (q)(struct goalrec*)&allocp[51];
  allocp[55] = (q)(&predicate_print_xdatan_1);
  allocp[56] = makesym(atom__3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_20Global_20Analysis_20Start_20_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D_3D);
  qp = (struct goalrec*)&allocp[54];
  allocp += 57;
  proceed();
 case VARREF:
  deref_and_jump(a1,main_2_1);
  *reasonp++ =  a1;
  goto main_2_interrupt;
  };
  goto main_2_interrupt;
 main_2_ext_interrupt:
  reasonp = 0l;
 main_2_interrupt:
  goto interrupt_2;
 }

 merge__gea_3_top: {
  q x0;
  a2 = qp->args[2];
  qp = qp->next;
 merge__gea_3_clear_reason:
  reasonp = reasons;
 merge__gea_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xmerge__gea_4);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = a2;
  a1 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(init__gea_2_0);
  goto init__gea_2_ext_interrupt;
 merge__gea_3_ext_interrupt:
  reasonp = 0l;
 merge__gea_3_interrupt:
  goto interrupt_3;
 }

 init__gea_2_top: {
  q x0, x1;
  qp = qp->next;
 init__gea_2_clear_reason:
  reasonp = reasons;
 init__gea_2_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor_xnew__functor__init_4);
  allocp[2] = makesym(atom_gea);
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = NILATOM;
  allocp[5] = a1;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[8] = a0;
  allocp[9] = x1 = makeref(&allocp[9]);
  allocp[10] = x0;
  qp = (struct goalrec*)&allocp[6];
  allocp += 11;
  proceed();
 init__gea_2_ext_interrupt:
  reasonp = 0l;
 init__gea_2_interrupt:
  toppred = &predicate_ganalyzer_xinit__gea_2;
  goto interrupt_2;
 }

 merge__gea_4_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 merge__gea_4_clear_reason:
  reasonp = reasons;
 merge__gea_4_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xmerge__gea_5);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[9] = a0;
  allocp[10] = x1 = makeref(&allocp[10]);
  allocp[11] = x0;
  qp = (struct goalrec*)&allocp[7];
  allocp += 12;
  proceed();
 merge__gea_4_ext_interrupt:
  reasonp = 0l;
 merge__gea_4_interrupt:
  goto interrupt_4;
 }

 merge__gea_5_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 merge__gea_5_clear_reason:
  reasonp = reasons;
 merge__gea_5_0:
 merge__gea_5_1:
  if (!isint(a0)) goto merge__gea_5_6;
  x0 = makeint(0L);
  gblt_greater(a0,x0,merge__gea_5_5);
 merge__gea_5_2:
  if (isref(a1)) goto merge__gea_5_4;
  gblt_arg(a0,a1,x1,merge__gea_5_5);
 merge__gea_5_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto merge__gea_5_5;
  x2 = makeint(1L);
  bblt_sub_no_check(a0,x2,x3);
  a0 = x3;
  execute(merge__gea_5_0);
  goto merge__gea_5_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,merge__gea_5_3);
  *reasonp++ =  x1;
  goto merge__gea_5_5;
  };
  goto merge__gea_5_5;
 merge__gea_5_4:
  deref_and_jump(a1,merge__gea_5_2);
  *reasonp++ =  a1;
  goto merge__gea_5_5;
 merge__gea_5_5:
  if (a0 != makeint(0L)) goto merge__gea_5_7;
  unify(a4, a3);
  proceed();
 merge__gea_5_6:
  if (!isref(a0)) goto merge__gea_5_7;
  deref_and_jump(a0,merge__gea_5_1);
  *reasonp++ =  a0;
  goto merge__gea_5_7;
 merge__gea_5_7:
  otherwise(merge__gea_5_interrupt);
 merge__gea_5_8:
  if (!isint(a0)) goto merge__gea_5_11;
  x0 = makeint(0L);
  gblt_greater(a0,x0,merge__gea_5_interrupt);
 merge__gea_5_9:
  if (isref(a1)) goto merge__gea_5_10;
  gblt_arg(a0,a1,x1,merge__gea_5_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xmerge__gea_5);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[9] = a0;
  allocp[10] = makeint(1L);
  allocp[11] = x2;
  a0 = x1;
  a1 = a2;
  a2 = a3;
  a3 = x3;
  qp = (struct goalrec*)&allocp[7];
  allocp += 12;
  execute(make__gea_4_0);
  goto make__gea_4_ext_interrupt;
 merge__gea_5_10:
  deref_and_jump(a1,merge__gea_5_9);
  *reasonp++ =  a1;
  goto merge__gea_5_interrupt;
 merge__gea_5_11:
  if (!isref(a0)) goto merge__gea_5_interrupt;
  deref_and_jump(a0,merge__gea_5_8);
  *reasonp++ =  a0;
  goto merge__gea_5_interrupt;
 merge__gea_5_ext_interrupt:
  reasonp = 0l;
 merge__gea_5_interrupt:
  goto interrupt_5;
 }

 make__gea_4_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 make__gea_4_clear_reason:
  reasonp = reasons;
 make__gea_4_0:
 make__gea_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 make__gea_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_3)) goto make__gea_4_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xmake__gea_4);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = a2;
  allocp[10] = x4 = makeref(&allocp[10]);
  allocp[11] = x2;
  allocp[12] = (q)(struct goalrec*)&allocp[6];
  allocp[13] = (q)(&predicate_ganalyzer_xinsert__ea_3);
  allocp[14] = x0;
  allocp[15] = x5 = makeref(&allocp[15]);
  allocp[16] = x4;
  allocp[17] = (q)(struct goalrec*)&allocp[12];
  allocp[18] = (q)(&predicate_functor__table_xarg_3);
  allocp[19] = x3;
  allocp[20] = a2;
  allocp[21] = x5;
  allocp[22] = (q)(struct goalrec*)&allocp[17];
  allocp[23] = (q)(&predicate_global__op_xget__fileno_3);
  x6 = arg(x0, 0);
  allocp[24] = x6;
  allocp[25] = a1;
  allocp[26] = x3;
  qp = (struct goalrec*)&allocp[22];
  allocp += 27;
  proceed();
 case VARREF:
  deref_and_jump(x0,make__gea_4_2);
  *reasonp++ =  x0;
  goto make__gea_4_interrupt;
  };
  goto make__gea_4_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto make__gea_4_interrupt;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,make__gea_4_1);
  *reasonp++ =  a0;
  goto make__gea_4_interrupt;
  };
  goto make__gea_4_interrupt;
 make__gea_4_ext_interrupt:
  reasonp = 0l;
 make__gea_4_interrupt:
  toppred = &predicate_ganalyzer_xmake__gea_4;
  goto interrupt_4;
 }

 insert__ea_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  qp = qp->next;
 insert__ea_3_clear_reason:
  reasonp = reasons;
 insert__ea_3_0:
 insert__ea_3_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_module_3)) goto insert__ea_3_3;
 insert__ea_3_2:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != NILATOM) goto insert__ea_3_3;
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,insert__ea_3_2);
  *reasonp++ =  a1;
  goto insert__ea_3_3;
  };
  goto insert__ea_3_3;
 case VARREF:
  deref_and_jump(a0,insert__ea_3_1);
  *reasonp++ =  a0;
  goto insert__ea_3_3;
  };
  goto insert__ea_3_3;
 insert__ea_3_3:
 insert__ea_3_4:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 insert__ea_3_5:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_3)) goto insert__ea_3_11;
 insert__ea_3_6:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_module_3)) goto insert__ea_3_11;
  x1 = arg(a0, 0);
 insert__ea_3_7:
  if (isref(x1)) goto insert__ea_3_10;
 insert__ea_3_8:
  if (isref(x1)) goto insert__ea_3_9;
  x2 = arg(x0, 0);
  if_not_equal(x1, x2, insert__ea_3_11);
  allocp[0] = makesym(functor_module_3);
  allocp[1] = x2;
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = x5 = makeref(&allocp[3]);
  x3 = makefunctor(&allocp[0]);
  x7 = cdr_of(a1);
  allocp[4] = x7;
  allocp[5] = x3;
  x6 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a2, x6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xinsert__preds_3);
  x8 = arg(a0, 2);
  allocp[2] = x8;
  x9 = arg(x0, 2);
  allocp[3] = x9;
  allocp[4] = x5;
  a0 = arg(a0, 1);
  a1 = arg(x0, 1);
  a2 = x4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(insert__preds_3_clear_reason);
  goto insert__preds_3_ext_interrupt;
 insert__ea_3_9:
  deref_and_jump(x1,insert__ea_3_8);
  *reasonp++ =  x1;
  goto insert__ea_3_11;
 insert__ea_3_10:
  deref_and_jump(x1,insert__ea_3_7);
  *reasonp++ =  x1;
  goto insert__ea_3_11;
 case VARREF:
  deref_and_jump(a0,insert__ea_3_6);
  *reasonp++ =  a0;
  goto insert__ea_3_11;
  };
  goto insert__ea_3_11;
 case VARREF:
  deref_and_jump(x0,insert__ea_3_5);
  *reasonp++ =  x0;
  goto insert__ea_3_11;
  };
  goto insert__ea_3_11;
 case VARREF:
  deref_and_jump(a1,insert__ea_3_4);
  *reasonp++ =  a1;
  goto insert__ea_3_11;
  };
  goto insert__ea_3_11;
 insert__ea_3_11:
  otherwise(insert__ea_3_interrupt);
 insert__ea_3_12:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a1);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  a1 = cdr_of(a1);
  a2 = x1;
  execute(insert__ea_3_0);
  goto insert__ea_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,insert__ea_3_12);
  *reasonp++ =  a1;
  goto insert__ea_3_interrupt;
  };
  goto insert__ea_3_interrupt;
 insert__ea_3_ext_interrupt:
  reasonp = 0l;
 insert__ea_3_interrupt:
  goto interrupt_3;
 }

 insert__preds_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 insert__preds_3_clear_reason:
  reasonp = reasons;
 insert__preds_3_0:
 insert__preds_3_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xinsert__preds_3);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  a0 = car_of(a0);
  a2 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(insert__pred_3_0);
  goto insert__pred_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto insert__preds_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,insert__preds_3_1);
  *reasonp++ =  a0;
  goto insert__preds_3_interrupt;
  };
  goto insert__preds_3_interrupt;
 insert__preds_3_ext_interrupt:
  reasonp = 0l;
 insert__preds_3_interrupt:
  toppred = &predicate_ganalyzer_xinsert__preds_3;
  goto interrupt_3;
 }

 insert__pred_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  a2 = qp->args[2];
  qp = qp->next;
 insert__pred_3_clear_reason:
  reasonp = reasons;
 insert__pred_3_0:
 insert__pred_3_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_pred_3)) goto insert__pred_3_12;
 insert__pred_3_2:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 insert__pred_3_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_3)) goto insert__pred_3_12;
  x1 = arg(x0, 0);
 insert__pred_3_4:
  if (isref(x1)) goto insert__pred_3_11;
 insert__pred_3_5:
  if (isref(x1)) goto insert__pred_3_10;
  x2 = arg(a0, 0);
  if_not_equal(x1, x2, insert__pred_3_12);
  x3 = arg(x0, 1);
 insert__pred_3_6:
  if (isref(x3)) goto insert__pred_3_9;
 insert__pred_3_7:
  if (isref(x3)) goto insert__pred_3_8;
  x4 = arg(a0, 1);
  if_not_equal(x3, x4, insert__pred_3_12);
  allocp[0] = makesym(functor_pred_3);
  allocp[1] = x2;
  allocp[2] = x4;
  allocp[3] = x6 = makeref(&allocp[3]);
  x5 = makefunctor(&allocp[0]);
  x8 = cdr_of(a1);
  allocp[4] = x8;
  allocp[5] = x5;
  x7 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a2, x7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xinsert__entries_4);
  allocp[2] = x9 = makeref(&allocp[2]);
  x10 = arg(a0, 2);
  allocp[3] = x10;
  x11 = arg(x0, 2);
  allocp[4] = x11;
  allocp[5] = x6;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[8] = x10;
  allocp[9] = x12 = makeref(&allocp[9]);
  allocp[10] = x9;
  qp = (struct goalrec*)&allocp[6];
  allocp += 11;
  proceed();
 insert__pred_3_8:
  deref_and_jump(x3,insert__pred_3_7);
  *reasonp++ =  x3;
  goto insert__pred_3_12;
 insert__pred_3_9:
  deref_and_jump(x3,insert__pred_3_6);
  *reasonp++ =  x3;
  goto insert__pred_3_12;
 insert__pred_3_10:
  deref_and_jump(x1,insert__pred_3_5);
  *reasonp++ =  x1;
  goto insert__pred_3_12;
 insert__pred_3_11:
  deref_and_jump(x1,insert__pred_3_4);
  *reasonp++ =  x1;
  goto insert__pred_3_12;
 case VARREF:
  deref_and_jump(x0,insert__pred_3_3);
  *reasonp++ =  x0;
  goto insert__pred_3_12;
  };
  goto insert__pred_3_12;
 case VARREF:
  deref_and_jump(a1,insert__pred_3_2);
  *reasonp++ =  a1;
  goto insert__pred_3_12;
  };
  goto insert__pred_3_12;
 case VARREF:
  deref_and_jump(a0,insert__pred_3_1);
  *reasonp++ =  a0;
  goto insert__pred_3_12;
  };
  goto insert__pred_3_12;
 insert__pred_3_12:
  otherwise(insert__pred_3_interrupt);
 insert__pred_3_13:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a1);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  a1 = cdr_of(a1);
  a2 = x1;
  execute(insert__pred_3_0);
  goto insert__pred_3_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto insert__pred_3_interrupt;
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,insert__pred_3_13);
  *reasonp++ =  a1;
  goto insert__pred_3_interrupt;
  };
  goto insert__pred_3_interrupt;
 insert__pred_3_ext_interrupt:
  reasonp = 0l;
 insert__pred_3_interrupt:
  toppred = &predicate_ganalyzer_xinsert__pred_3;
  goto interrupt_3;
 }

 insert__entries_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 insert__entries_4_clear_reason:
  reasonp = reasons;
 insert__entries_4_0:
 insert__entries_4_1:
  if (!isint(a0)) goto insert__entries_4_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,insert__entries_4_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xinsert__entries_4);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x1;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_functor_xinsert__arg_4);
  allocp[13] = makeint(1L);
  allocp[14] = a2;
  allocp[15] = x3 = makeref(&allocp[15]);
  allocp[16] = x2;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_functor__table_xarg_3);
  allocp[19] = a0;
  allocp[20] = a1;
  allocp[21] = x3;
  qp = (struct goalrec*)&allocp[17];
  allocp += 22;
  proceed();
 insert__entries_4_2:
  if (a0 != makeint(0L)) goto insert__entries_4_interrupt;
  unify(a3, a2);
  proceed();
 insert__entries_4_3:
  if (!isref(a0)) goto insert__entries_4_interrupt;
  deref_and_jump(a0,insert__entries_4_1);
  *reasonp++ =  a0;
  goto insert__entries_4_interrupt;
 insert__entries_4_ext_interrupt:
  reasonp = 0l;
 insert__entries_4_interrupt:
  goto interrupt_4;
 }

 fix__type_7_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 fix__type_7_clear_reason:
  reasonp = reasons;
 fix__type_7_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xfix__type2_8);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = a4;
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = a6;
  a4 = x1;
  a6 = x2;
  a7 = NILATOM;
  a8 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  execute(fix__type_9_0);
  goto fix__type_9_ext_interrupt;
 fix__type_7_ext_interrupt:
  reasonp = 0l;
 fix__type_7_interrupt:
  toppred = &predicate_ganalyzer_xfix__type_7;
  goto interrupt_7;
 }

 fix__type2_8_top: {
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 fix__type2_8_clear_reason:
  reasonp = reasons;
 fix__type2_8_0:
 fix__type2_8_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != NILATOM) goto fix__type2_8_2;
  unify2(a7, a6, a5, a4);
  proceed();
 case VARREF:
  deref_and_jump(a0,fix__type2_8_1);
  *reasonp++ =  a0;
  goto fix__type2_8_2;
  };
  goto fix__type2_8_2;
 fix__type2_8_2:
  otherwise(fix__type2_8_interrupt);
  a0 = a1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  a5 = a6;
  a6 = a7;
  execute(fix__type_7_0);
  goto fix__type_7_ext_interrupt;
 fix__type2_8_ext_interrupt:
  reasonp = 0l;
 fix__type2_8_interrupt:
  goto interrupt_8;
 }

 fix__type_9_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 fix__type_9_clear_reason:
  reasonp = reasons;
 fix__type_9_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xfix__type_10);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = a8;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[14] = a2;
  allocp[15] = x1 = makeref(&allocp[15]);
  allocp[16] = x0;
  qp = (struct goalrec*)&allocp[12];
  allocp += 17;
  proceed();
 fix__type_9_ext_interrupt:
  reasonp = 0l;
 fix__type_9_interrupt:
  toppred = &predicate_ganalyzer_xfix__type_9;
  goto interrupt_9;
 }

 fix__type_10_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 fix__type_10_clear_reason:
  reasonp = reasons;
 fix__type_10_0:
 fix__type_10_1:
  if (!isint(a0)) goto fix__type_10_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,fix__type_10_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xfix__type_10);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x4 = makeref(&allocp[10]);
  allocp[11] = a9;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[14] = a0;
  allocp[15] = makeint(1L);
  allocp[16] = x1;
  allocp[17] = (q)(struct goalrec*)&allocp[12];
  allocp[18] = (q)(&predicate_ganalyzer_xfix__type__modules_9);
  allocp[19] = x5 = makeref(&allocp[19]);
  allocp[20] = a1;
  allocp[21] = a2;
  allocp[22] = a4;
  allocp[23] = x2;
  allocp[24] = a6;
  allocp[25] = x3;
  allocp[26] = a8;
  allocp[27] = x4;
  allocp[28] = (q)(struct goalrec*)&allocp[17];
  allocp[29] = (q)(&predicate_functor__table_xarg_3);
  allocp[30] = a0;
  allocp[31] = a3;
  allocp[32] = x5;
  qp = (struct goalrec*)&allocp[28];
  allocp += 33;
  proceed();
 fix__type_10_2:
  if (a0 != makeint(0L)) goto fix__type_10_interrupt;
  unify3(a9, a8, a7, a6, a5, a4);
  proceed();
 fix__type_10_3:
  if (!isref(a0)) goto fix__type_10_interrupt;
  deref_and_jump(a0,fix__type_10_1);
  *reasonp++ =  a0;
  goto fix__type_10_interrupt;
 fix__type_10_ext_interrupt:
  reasonp = 0l;
 fix__type_10_interrupt:
  goto interrupt_10;
 }

 fix__type__modules_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 fix__type__modules_9_clear_reason:
  reasonp = reasons;
 fix__type__modules_9_0:
 fix__type__modules_9_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 fix__type__modules_9_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_3)) goto fix__type__modules_9_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xfix__type__modules_9);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = x4 = makeref(&allocp[9]);
  allocp[10] = a8;
  a0 = arg(x0, 0);
  x5 = arg(x0, 1);
  x6 = arg(x0, 2);
  x7 = a1;
  a4 = a2;
  x8 = a3;
  a6 = x2;
  x9 = a5;
  a8 = x3;
  a9 = a7;
  a10 = x4;
  a7 = x9;
  a5 = x8;
  a3 = x7;
  a2 = x6;
  a1 = x5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 11;
  execute(fix__type__preds_11_0);
  goto fix__type__preds_11_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,fix__type__modules_9_2);
  *reasonp++ =  x0;
  goto fix__type__modules_9_interrupt;
  };
  goto fix__type__modules_9_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto fix__type__modules_9_interrupt;
  unify3(a8, a7, a6, a5, a4, a3);
  proceed();
 case VARREF:
  deref_and_jump(a0,fix__type__modules_9_1);
  *reasonp++ =  a0;
  goto fix__type__modules_9_interrupt;
  };
  goto fix__type__modules_9_interrupt;
 fix__type__modules_9_ext_interrupt:
  reasonp = 0l;
 fix__type__modules_9_interrupt:
  goto interrupt_9;
 }

 fix__type__preds_11_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 fix__type__preds_11_clear_reason:
  reasonp = reasons;
 fix__type__preds_11_0:
 fix__type__preds_11_1:
  switch (ptagof(a2)) {
 case CONS:
  x0 = car_of(a2);
 fix__type__preds_11_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_3)) goto fix__type__preds_11_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xfix__type__preds_11);
  allocp[2] = a0;
  allocp[3] = a1;
  x1 = cdr_of(a2);
  allocp[4] = x1;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = x3 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = x4 = makeref(&allocp[11]);
  allocp[12] = a10;
  allocp[13] = makesym(functor_pred_3);
  x6 = arg(x0, 0);
  allocp[14] = x6;
  x7 = arg(x0, 1);
  allocp[15] = x7;
  x8 = arg(x0, 2);
  allocp[16] = x8;
  x5 = makefunctor(&allocp[13]);
  allocp[17] = (q)(struct goalrec*)&allocp[0];
  allocp[18] = (q)(&predicate_ganalyzer_xfix__type__pred_11);
  allocp[19] = a0;
  allocp[20] = x9 = makeref(&allocp[20]);
  allocp[21] = x5;
  allocp[22] = a3;
  allocp[23] = a4;
  allocp[24] = a5;
  allocp[25] = x2;
  allocp[26] = a7;
  allocp[27] = x3;
  allocp[28] = a9;
  allocp[29] = x4;
  a0 = arg(x0, 0);
  x10 = arg(x0, 1);
  a2 = a1;
  a3 = x9;
  a1 = x10;
  qp = (struct goalrec*)&allocp[17];
  allocp += 30;
  execute(get__same__pred__head_4_0);
  goto get__same__pred__head_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,fix__type__preds_11_2);
  *reasonp++ =  x0;
  goto fix__type__preds_11_interrupt;
  };
  goto fix__type__preds_11_interrupt;
 case ATOMIC:
  if (a2 != NILATOM) goto fix__type__preds_11_interrupt;
  unify3(a10, a9, a8, a7, a6, a5);
  proceed();
 case VARREF:
  deref_and_jump(a2,fix__type__preds_11_1);
  *reasonp++ =  a2;
  goto fix__type__preds_11_interrupt;
  };
  goto fix__type__preds_11_interrupt;
 fix__type__preds_11_ext_interrupt:
  reasonp = 0l;
 fix__type__preds_11_interrupt:
  toppred = &predicate_ganalyzer_xfix__type__preds_11;
  goto interrupt_11;
 }

 fix__type__pred_11_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 fix__type__pred_11_clear_reason:
  reasonp = reasons;
 fix__type__pred_11_0:
 fix__type__pred_11_1:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_pred_3)) goto fix__type__pred_11_interrupt;
 fix__type__pred_11_2:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_pred_3)) goto fix__type__pred_11_interrupt;
  x0 = arg(a2, 0);
 fix__type__pred_11_3:
  if (isref(x0)) goto fix__type__pred_11_10;
 fix__type__pred_11_4:
  if (isref(x0)) goto fix__type__pred_11_9;
  x1 = arg(a1, 0);
  if_not_equal(x0, x1, fix__type__pred_11_interrupt);
  x2 = arg(a2, 1);
 fix__type__pred_11_5:
  if (isref(x2)) goto fix__type__pred_11_8;
 fix__type__pred_11_6:
  if (isref(x2)) goto fix__type__pred_11_7;
  x3 = arg(a1, 1);
  if_not_equal(x2, x3, fix__type__pred_11_interrupt);
  x4 = arg(a1, 2);
  x5 = arg(a2, 2);
  x6 = a3;
  x7 = a4;
  x8 = a5;
  x9 = a6;
  x10 = a7;
  x11 = a8;
  a11 = a9;
  a12 = a10;
  a10 = x11;
  a9 = x10;
  a8 = x9;
  a7 = x8;
  a6 = x7;
  a5 = x6;
  a4 = x5;
  a3 = x4;
  a2 = x3;
  a1 = x1;
  execute(fix__type__entries_13_clear_reason);
  goto fix__type__entries_13_ext_interrupt;
 fix__type__pred_11_7:
  deref_and_jump(x2,fix__type__pred_11_6);
  *reasonp++ =  x2;
  goto fix__type__pred_11_interrupt;
 fix__type__pred_11_8:
  deref_and_jump(x2,fix__type__pred_11_5);
  *reasonp++ =  x2;
  goto fix__type__pred_11_interrupt;
 fix__type__pred_11_9:
  deref_and_jump(x0,fix__type__pred_11_4);
  *reasonp++ =  x0;
  goto fix__type__pred_11_interrupt;
 fix__type__pred_11_10:
  deref_and_jump(x0,fix__type__pred_11_3);
  *reasonp++ =  x0;
  goto fix__type__pred_11_interrupt;
 case VARREF:
  deref_and_jump(a2,fix__type__pred_11_2);
  *reasonp++ =  a2;
  goto fix__type__pred_11_interrupt;
  };
  goto fix__type__pred_11_interrupt;
 case VARREF:
  deref_and_jump(a1,fix__type__pred_11_1);
  *reasonp++ =  a1;
  goto fix__type__pred_11_interrupt;
  };
  goto fix__type__pred_11_interrupt;
 fix__type__pred_11_ext_interrupt:
  reasonp = 0l;
 fix__type__pred_11_interrupt:
  goto interrupt_11;
 }

 fix__type__entries_13_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  qp = qp->next;
 fix__type__entries_13_clear_reason:
  reasonp = reasons;
 fix__type__entries_13_0:
  x0 = a2;
  x1 = a2;
  x2 = a3;
  x3 = a4;
  x4 = a5;
  x5 = a6;
  x6 = a7;
  x7 = a8;
  x8 = a9;
  x9 = a10;
  x10 = a11;
  a13 = a12;
  a12 = x10;
  a11 = x9;
  a10 = x8;
  a9 = x7;
  a8 = x6;
  a7 = x5;
  a6 = x4;
  a5 = x3;
  a4 = x2;
  a3 = x1;
  a2 = x0;
  execute(fix__type__entries_14_0);
  goto fix__type__entries_14_ext_interrupt;
 fix__type__entries_13_ext_interrupt:
  reasonp = 0l;
 fix__type__entries_13_interrupt:
  toppred = &predicate_ganalyzer_xfix__type__entries_13;
  goto interrupt_13;
 }

 fix__type__entries_14_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  qp = qp->next;
 fix__type__entries_14_clear_reason:
  reasonp = reasons;
 fix__type__entries_14_0:
 fix__type__entries_14_1:
  if (!isint(a3)) goto fix__type__entries_14_3;
  x0 = makeint(0L);
  gblt_greater(a3,x0,fix__type__entries_14_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xfix__type__entries_14);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = x2 = makeref(&allocp[10]);
  allocp[11] = a9;
  allocp[12] = x3 = makeref(&allocp[12]);
  allocp[13] = a11;
  allocp[14] = x4 = makeref(&allocp[14]);
  allocp[15] = a13;
  allocp[16] = (q)(struct goalrec*)&allocp[0];
  allocp[17] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[18] = a3;
  allocp[19] = makeint(1L);
  allocp[20] = x1;
  allocp[21] = (q)(struct goalrec*)&allocp[16];
  allocp[22] = (q)(&predicate_ganalyzer_xfix__type__arg_16);
  allocp[23] = a0;
  allocp[24] = a1;
  allocp[25] = a2;
  allocp[26] = a3;
  allocp[27] = x5 = makeref(&allocp[27]);
  allocp[28] = x6 = makeref(&allocp[28]);
  allocp[29] = a4;
  allocp[30] = a5;
  allocp[31] = a6;
  allocp[32] = a7;
  allocp[33] = a8;
  allocp[34] = x2;
  allocp[35] = a10;
  allocp[36] = x3;
  allocp[37] = a12;
  allocp[38] = x4;
  allocp[39] = (q)(struct goalrec*)&allocp[21];
  allocp[40] = (q)(&predicate_ganalyzer_xread__arg__ts_5);
  allocp[41] = a3;
  allocp[42] = a5;
  allocp[43] = x6;
  allocp[44] = a6;
  allocp[45] = a8;
  a0 = a3;
  a1 = a4;
  a2 = x5;
  a3 = a6;
  a4 = a8;
  qp = (struct goalrec*)&allocp[39];
  allocp += 46;
  execute(read__arg__ts_5_0);
  goto read__arg__ts_5_ext_interrupt;
 fix__type__entries_14_2:
  if (a3 != makeint(0L)) goto fix__type__entries_14_interrupt;
  unify3(a13, a12, a11, a10, a9, a8);
  proceed();
 fix__type__entries_14_3:
  if (!isref(a3)) goto fix__type__entries_14_interrupt;
  deref_and_jump(a3,fix__type__entries_14_1);
  *reasonp++ =  a3;
  goto fix__type__entries_14_interrupt;
 fix__type__entries_14_ext_interrupt:
  reasonp = 0l;
 fix__type__entries_14_interrupt:
  toppred = &predicate_ganalyzer_xfix__type__entries_14;
  goto interrupt_14;
 }

 fix__type__arg_16_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  qp = qp->next;
 fix__type__arg_16_clear_reason:
  reasonp = reasons;
 fix__type__arg_16_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xfix__type__arg_21);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = x4 = makeref(&allocp[6]);
  allocp[7] = a0;
  allocp[8] = a1;
  allocp[9] = a2;
  allocp[10] = a3;
  allocp[11] = a4;
  allocp[12] = a5;
  allocp[13] = a6;
  allocp[14] = a7;
  allocp[15] = a8;
  allocp[16] = a9;
  allocp[17] = a10;
  allocp[18] = a11;
  allocp[19] = a12;
  allocp[20] = a13;
  allocp[21] = a14;
  allocp[22] = a15;
  allocp[23] = (q)(struct goalrec*)&allocp[0];
  allocp[24] = (q)(&predicate_global__op_xread__mode_7);
  allocp[25] = a0;
  allocp[26] = a1;
  allocp[27] = a2;
  allocp[28] = a3;
  allocp[29] = x4;
  allocp[30] = a8;
  allocp[31] = a12;
  allocp[32] = (q)(struct goalrec*)&allocp[23];
  allocp[33] = (q)(&predicate_ganalyzer_xcheck__ts_3);
  allocp[34] = a5;
  allocp[35] = x2;
  allocp[36] = x3;
  a0 = a4;
  a1 = x0;
  a2 = x1;
  qp = (struct goalrec*)&allocp[32];
  allocp += 37;
  execute(check__ts_3_0);
  goto check__ts_3_ext_interrupt;
 fix__type__arg_16_ext_interrupt:
  reasonp = 0l;
 fix__type__arg_16_interrupt:
  goto interrupt_16;
 }

 fix__type__arg_21_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  a18 = qp->args[18];
  a19 = qp->args[19];
  a20 = qp->args[20];
  qp = qp->next;
 fix__type__arg_21_clear_reason:
  reasonp = reasons;
 fix__type__arg_21_0:
 fix__type__arg_21_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto fix__type__arg_21_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_kakutei)):
 fix__type__arg_21_2:
  switch (ptagof(a1)) {
 case ATOMIC:
 fix__type__arg_21_3:
  if (a1 != makeint(0L)) goto fix__type__arg_21_interrupt;
 fix__type__arg_21_4:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (isint(a2)) goto fix__type__arg_21_interrupt;
  switch (symval(a2)) {
 case symval(makesym(atom_kakutei)):
 fix__type__arg_21_5:
  switch (ptagof(a3)) {
 case ATOMIC:
 fix__type__arg_21_6:
  if (a3 != makeint(0L)) goto fix__type__arg_21_interrupt;
 fix__type__arg_21_7:
  switch (ptagof(a4)) {
 case ATOMIC:
  if (isint(a4)) goto fix__type__arg_21_interrupt;
  switch (symval(a4)) {
 case symval(makesym(atom_o)):
  unify(a20, a19);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xwrite__arg__ts_6);
  allocp[2] = a8;
  allocp[3] = a12;
  allocp[4] = makecons(cons_const_1);
  allocp[5] = a13;
  allocp[6] = x0 = makeref(&allocp[6]);
  allocp[7] = a16;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_ganalyzer_xwrite__arg__ts_6);
  allocp[10] = a8;
  allocp[11] = a11;
  allocp[12] = makecons(cons_const_1);
  allocp[13] = a13;
  allocp[14] = a15;
  allocp[15] = x0;
  allocp[16] = (q)(struct goalrec*)&allocp[8];
  allocp[17] = (q)(&predicate_ganalyzer_xwrite__extern__mode_9);
  allocp[18] = a12;
  allocp[19] = a5;
  allocp[20] = a6;
  allocp[21] = a7;
  allocp[22] = a8;
  allocp[23] = makesym(atom_i);
  allocp[24] = a13;
  allocp[25] = x1 = makeref(&allocp[25]);
  allocp[26] = a18;
  allocp[27] = (q)(struct goalrec*)&allocp[16];
  allocp[28] = (q)(&predicate_ganalyzer_xwrite__extern__mode_9);
  allocp[29] = a12;
  allocp[30] = a5;
  allocp[31] = a6;
  allocp[32] = a7;
  allocp[33] = a8;
  allocp[34] = makesym(atom__3F);
  allocp[35] = a13;
  allocp[36] = x2 = makeref(&allocp[36]);
  allocp[37] = x1;
  allocp[38] = (q)(struct goalrec*)&allocp[27];
  allocp[39] = (q)(&predicate_global__op_xwrite__mode_8);
  allocp[40] = a5;
  allocp[41] = a6;
  allocp[42] = a7;
  allocp[43] = a8;
  allocp[44] = makesym(atom_i);
  allocp[45] = a13;
  allocp[46] = x3 = makeref(&allocp[46]);
  allocp[47] = x2;
  allocp[48] = (q)(struct goalrec*)&allocp[38];
  allocp[49] = (q)(&predicate_global__op_xwrite__mode_8);
  allocp[50] = a5;
  allocp[51] = a6;
  allocp[52] = a7;
  allocp[53] = a8;
  allocp[54] = makesym(atom__3F);
  allocp[55] = a13;
  allocp[56] = a17;
  allocp[57] = x3;
  qp = (struct goalrec*)&allocp[48];
  allocp += 58;
  proceed();
 case symval(makesym(atom_i)):
  unify(a20, a19);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xreplace__tt_7);
  allocp[2] = a8;
  allocp[3] = a11;
  allocp[4] = a12;
  allocp[5] = a13;
  allocp[6] = a14;
  allocp[7] = a15;
  allocp[8] = a16;
  a0 = a12;
  a1 = a5;
  a2 = a6;
  a3 = a7;
  a4 = a8;
  a5 = makesym(atom_i);
  a6 = a13;
  a7 = a17;
  a8 = a18;
  qp = (struct goalrec*)&allocp[0];
  allocp += 9;
  execute(write__extern__mode_9_0);
  goto write__extern__mode_9_ext_interrupt;
  };
  goto fix__type__arg_21_interrupt;
 case VARREF:
  deref_and_jump(a4,fix__type__arg_21_7);
  *reasonp++ =  a4;
  goto fix__type__arg_21_interrupt;
  };
  goto fix__type__arg_21_interrupt;
 case VARREF:
  deref_and_jump(a3,fix__type__arg_21_5);
  *reasonp++ =  a3;
  goto fix__type__arg_21_interrupt;
  };
  goto fix__type__arg_21_interrupt;
 case symval(makesym(atom_zantei)):
 fix__type__arg_21_8:
  switch (ptagof(a4)) {
 case ATOMIC:
  if (isint(a4)) goto fix__type__arg_21_interrupt;
  switch (symval(a4)) {
 case symval(makesym(atom_i)):
  unify(a20, a19);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xcond1_12);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a5;
  allocp[4] = a6;
  allocp[5] = a7;
  allocp[6] = a8;
  allocp[7] = a11;
  allocp[8] = a12;
  allocp[9] = a13;
  allocp[10] = a15;
  allocp[11] = a16;
  allocp[12] = a17;
  allocp[13] = a18;
  a0 = makesym(atom_same);
  a1 = a8;
  a2 = a10;
  a3 = a11;
  a4 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 14;
  execute(remove__tt_5_0);
  goto remove__tt_5_ext_interrupt;
 case symval(makesym(atom_o)):
  unify(a20, a19);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xreplace__tt_7);
  allocp[2] = a8;
  allocp[3] = a12;
  allocp[4] = a11;
  allocp[5] = a13;
  allocp[6] = a14;
  allocp[7] = x0 = makeref(&allocp[7]);
  allocp[8] = a16;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_ganalyzer_xwrite__arg__ts_6);
  allocp[11] = a8;
  allocp[12] = a12;
  allocp[13] = x1 = makeref(&allocp[13]);
  allocp[14] = a13;
  allocp[15] = a15;
  allocp[16] = x0;
  allocp[17] = (q)(struct goalrec*)&allocp[9];
  allocp[18] = (q)(&predicate_ganalyzer_xremove__tt_5);
  allocp[19] = makesym(atom_not__same);
  allocp[20] = a8;
  allocp[21] = a10;
  allocp[22] = a12;
  allocp[23] = x1;
  a0 = a12;
  a1 = a5;
  a2 = a6;
  a3 = a7;
  a4 = a8;
  a5 = makesym(atom_o);
  a6 = a13;
  a7 = a17;
  a8 = a18;
  qp = (struct goalrec*)&allocp[17];
  allocp += 24;
  execute(write__extern__mode_9_0);
  goto write__extern__mode_9_ext_interrupt;
  };
  goto fix__type__arg_21_interrupt;
 case VARREF:
  deref_and_jump(a4,fix__type__arg_21_8);
  *reasonp++ =  a4;
  goto fix__type__arg_21_interrupt;
  };
  goto fix__type__arg_21_interrupt;
  };
  goto fix__type__arg_21_interrupt;
 case VARREF:
  deref_and_jump(a2,fix__type__arg_21_4);
  *reasonp++ =  a2;
  goto fix__type__arg_21_interrupt;
  };
  goto fix__type__arg_21_interrupt;
 case VARREF:
  deref_and_jump(a1,fix__type__arg_21_2);
  *reasonp++ =  a1;
  goto fix__type__arg_21_interrupt;
  };
  goto fix__type__arg_21_interrupt;
 case symval(makesym(atom_zantei)):
 fix__type__arg_21_9:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (isint(a2)) goto fix__type__arg_21_interrupt;
  switch (symval(a2)) {
 case symval(makesym(atom_kakutei)):
 fix__type__arg_21_10:
  switch (ptagof(a3)) {
 case ATOMIC:
 fix__type__arg_21_11:
  if (a3 != makeint(0L)) goto fix__type__arg_21_interrupt;
  unify(a20, a19);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xreplace__tt_7);
  allocp[2] = a8;
  allocp[3] = a11;
  allocp[4] = a12;
  allocp[5] = a13;
  allocp[6] = a14;
  allocp[7] = x0 = makeref(&allocp[7]);
  allocp[8] = a16;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_ganalyzer_xwrite__arg__ts_6);
  allocp[11] = a8;
  allocp[12] = a11;
  allocp[13] = x1 = makeref(&allocp[13]);
  allocp[14] = a13;
  allocp[15] = a15;
  allocp[16] = x0;
  allocp[17] = (q)(struct goalrec*)&allocp[9];
  allocp[18] = (q)(&predicate_ganalyzer_xremove__tt_5);
  allocp[19] = makesym(atom_not__same);
  allocp[20] = a8;
  allocp[21] = a9;
  allocp[22] = a11;
  allocp[23] = x1;
  allocp[24] = (q)(struct goalrec*)&allocp[17];
  allocp[25] = (q)(&predicate_ganalyzer_xwrite__extern__mode_9);
  allocp[26] = a12;
  allocp[27] = a5;
  allocp[28] = a6;
  allocp[29] = a7;
  allocp[30] = a8;
  allocp[31] = makesym(atom_i);
  allocp[32] = a13;
  allocp[33] = x2 = makeref(&allocp[33]);
  allocp[34] = a18;
  allocp[35] = (q)(struct goalrec*)&allocp[24];
  allocp[36] = (q)(&predicate_global__op_xwrite__mode_8);
  allocp[37] = a5;
  allocp[38] = a6;
  allocp[39] = a7;
  allocp[40] = a8;
  allocp[41] = makesym(atom_i);
  allocp[42] = a13;
  allocp[43] = a17;
  allocp[44] = x2;
  qp = (struct goalrec*)&allocp[35];
  allocp += 45;
  proceed();
 case VARREF:
  deref_and_jump(a3,fix__type__arg_21_10);
  *reasonp++ =  a3;
  goto fix__type__arg_21_interrupt;
  };
  goto fix__type__arg_21_interrupt;
 case symval(makesym(atom_zantei)):
  unify2(a18, a17, a16, a15);
  allocp[0] = makesym(functor_undone_4);
  allocp[1] = a5;
  allocp[2] = a6;
  allocp[3] = a7;
  allocp[4] = a8;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = a19;
  allocp[6] = x0;
  x1 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a20, x1);
  proceed();
  };
  goto fix__type__arg_21_interrupt;
 case VARREF:
  deref_and_jump(a2,fix__type__arg_21_9);
  *reasonp++ =  a2;
  goto fix__type__arg_21_interrupt;
  };
  goto fix__type__arg_21_interrupt;
  };
  goto fix__type__arg_21_interrupt;
 case VARREF:
  deref_and_jump(a0,fix__type__arg_21_1);
  *reasonp++ =  a0;
  goto fix__type__arg_21_interrupt;
  };
  goto fix__type__arg_21_interrupt;
 fix__type__arg_21_ext_interrupt:
  reasonp = 0l;
 fix__type__arg_21_interrupt:
  goto interrupt_21;
 }

 remove__tt_5_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 remove__tt_5_clear_reason:
  reasonp = reasons;
 remove__tt_5_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xremove__tt2_4);
  allocp[2] = a0;
  allocp[3] = a2;
  allocp[4] = a4;
  allocp[5] = x0 = makeref(&allocp[5]);
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_ganalyzer_xmake__outposition_4);
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a3;
  allocp[10] = a1;
  allocp[11] = x0;
  allocp[12] = (q)(struct goalrec*)&allocp[6];
  allocp[13] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[14] = a3;
  allocp[15] = x2 = makeref(&allocp[15]);
  allocp[16] = x1;
  qp = (struct goalrec*)&allocp[12];
  allocp += 17;
  proceed();
 remove__tt_5_ext_interrupt:
  reasonp = 0l;
 remove__tt_5_interrupt:
  toppred = &predicate_ganalyzer_xremove__tt_5;
  goto interrupt_5;
 }

 remove__tt2_4_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 remove__tt2_4_clear_reason:
  reasonp = reasons;
 remove__tt2_4_0:
 remove__tt2_4_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 remove__tt2_4_2:
  if (isref(x0)) goto remove__tt2_4_4;
  gblt_pfunctor(x0,x1,remove__tt2_4_5);
  if (x1 != makesym(atom_tt)) goto remove__tt2_4_5;
  gblt_arity(x0,x2,remove__tt2_4_5);
 remove__tt2_4_3:
  if (x2 != makeint(3L)) goto remove__tt2_4_5;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xremove__tt3_6);
  allocp[2] = a0;
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x0;
  x4 = cdr_of(a1);
  allocp[5] = x4;
  allocp[6] = a2;
  allocp[7] = a3;
  a0 = a3;
  a1 = x0;
  a2 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  execute(check__position_3_0);
  goto check__position_3_ext_interrupt;
 remove__tt2_4_4:
  deref_and_jump(x0,remove__tt2_4_2);
  *reasonp++ =  x0;
  goto remove__tt2_4_5;
 case VARREF:
  deref_and_jump(a1,remove__tt2_4_1);
  *reasonp++ =  a1;
  goto remove__tt2_4_5;
  };
  goto remove__tt2_4_5;
 remove__tt2_4_5:
  otherwise(remove__tt2_4_interrupt);
 remove__tt2_4_6:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a1);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  a1 = cdr_of(a1);
  a2 = x1;
  execute(remove__tt2_4_0);
  goto remove__tt2_4_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto remove__tt2_4_interrupt;
  x0 = NILATOM;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,remove__tt2_4_6);
  *reasonp++ =  a1;
  goto remove__tt2_4_interrupt;
  };
  goto remove__tt2_4_interrupt;
 remove__tt2_4_ext_interrupt:
  reasonp = 0l;
 remove__tt2_4_interrupt:
  toppred = &predicate_ganalyzer_xremove__tt2_4;
  goto interrupt_4;
 }

 remove__tt3_6_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 remove__tt3_6_clear_reason:
  reasonp = reasons;
 remove__tt3_6_0:
 remove__tt3_6_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto remove__tt3_6_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_not__same)):
 remove__tt3_6_2:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (isint(a1)) goto remove__tt3_6_interrupt;
  switch (symval(a1)) {
 case symval(makesym(atom_yes)):
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = a2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a4, x0);
  a0 = makesym(atom_not__same);
  a1 = a3;
  a2 = x1;
  a3 = a5;
  execute(remove__tt2_4_0);
  goto remove__tt2_4_ext_interrupt;
 case symval(makesym(atom_no)):
  a0 = makesym(atom_not__same);
  a1 = a3;
  a2 = a4;
  a3 = a5;
  execute(remove__tt2_4_0);
  goto remove__tt2_4_ext_interrupt;
  };
  goto remove__tt3_6_interrupt;
 case VARREF:
  deref_and_jump(a1,remove__tt3_6_2);
  *reasonp++ =  a1;
  goto remove__tt3_6_interrupt;
  };
  goto remove__tt3_6_interrupt;
 case symval(makesym(atom_same)):
 remove__tt3_6_3:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (isint(a1)) goto remove__tt3_6_interrupt;
  switch (symval(a1)) {
 case symval(makesym(atom_yes)):
  a0 = makesym(atom_same);
  a1 = a3;
  a2 = a4;
  a3 = a5;
  execute(remove__tt2_4_0);
  goto remove__tt2_4_ext_interrupt;
 case symval(makesym(atom_no)):
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = a2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a4, x0);
  a0 = makesym(atom_same);
  a1 = a3;
  a2 = x1;
  allocp[0] = x2 = makeref(&allocp[0]);
  a3 = x2;
  allocp += 1;
  execute(remove__tt2_4_0);
  goto remove__tt2_4_ext_interrupt;
  };
  goto remove__tt3_6_interrupt;
 case VARREF:
  deref_and_jump(a1,remove__tt3_6_3);
  *reasonp++ =  a1;
  goto remove__tt3_6_interrupt;
  };
  goto remove__tt3_6_interrupt;
  };
  goto remove__tt3_6_interrupt;
 case VARREF:
  deref_and_jump(a0,remove__tt3_6_1);
  *reasonp++ =  a0;
  goto remove__tt3_6_interrupt;
  };
  goto remove__tt3_6_interrupt;
 remove__tt3_6_ext_interrupt:
  reasonp = 0l;
 remove__tt3_6_interrupt:
  goto interrupt_6;
 }

 check__position_3_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  qp = qp->next;
 check__position_3_clear_reason:
  reasonp = reasons;
 check__position_3_0:
 check__position_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 check__position_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_posi_2)) goto check__position_3_12;
 check__position_3_3:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_tt_3)) goto check__position_3_12;
  x1 = arg(a1, 0);
 check__position_3_4:
  if (isref(x1)) goto check__position_3_11;
 check__position_3_5:
  if (isref(x1)) goto check__position_3_10;
  x2 = arg(x0, 0);
  if_not_equal(x1, x2, check__position_3_12);
  x3 = arg(a1, 1);
 check__position_3_6:
  if (isref(x3)) goto check__position_3_9;
 check__position_3_7:
  if (isref(x3)) goto check__position_3_8;
  x4 = arg(x0, 1);
  if_not_equal(x3, x4, check__position_3_12);
  x5 = makesym(atom_yes);
  unify_value(a2, x5);
  proceed();
 check__position_3_8:
  deref_and_jump(x3,check__position_3_7);
  *reasonp++ =  x3;
  goto check__position_3_12;
 check__position_3_9:
  deref_and_jump(x3,check__position_3_6);
  *reasonp++ =  x3;
  goto check__position_3_12;
 check__position_3_10:
  deref_and_jump(x1,check__position_3_5);
  *reasonp++ =  x1;
  goto check__position_3_12;
 check__position_3_11:
  deref_and_jump(x1,check__position_3_4);
  *reasonp++ =  x1;
  goto check__position_3_12;
 case VARREF:
  deref_and_jump(a1,check__position_3_3);
  *reasonp++ =  a1;
  goto check__position_3_12;
  };
  goto check__position_3_12;
 case VARREF:
  deref_and_jump(x0,check__position_3_2);
  *reasonp++ =  x0;
  goto check__position_3_12;
  };
  goto check__position_3_12;
 case VARREF:
  deref_and_jump(a0,check__position_3_1);
  *reasonp++ =  a0;
  goto check__position_3_12;
  };
  goto check__position_3_12;
 check__position_3_12:
  otherwise(check__position_3_interrupt);
 check__position_3_13:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(check__position_3_0);
  goto check__position_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto check__position_3_interrupt;
  x0 = makesym(atom_no);
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,check__position_3_13);
  *reasonp++ =  a0;
  goto check__position_3_interrupt;
  };
  goto check__position_3_interrupt;
 check__position_3_ext_interrupt:
  reasonp = 0l;
 check__position_3_interrupt:
  toppred = &predicate_ganalyzer_xcheck__position_3;
  goto interrupt_3;
 }

 make__outposition_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 make__outposition_4_clear_reason:
  reasonp = reasons;
 make__outposition_4_0:
 make__outposition_4_1:
  if (!isint(a0)) goto make__outposition_4_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,make__outposition_4_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xmake__outposition_4);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x1;
  allocp[11] = makesym(functor_posi_2);
  allocp[12] = x4 = makeref(&allocp[12]);
  allocp[13] = a2;
  x3 = makefunctor(&allocp[11]);
  allocp[14] = x2;
  allocp[15] = x3;
  x5 = makecons(&allocp[14]);
  qp = (struct goalrec*)&allocp[6];
  allocp += 16;
  unify_value(a3, x5);
  allocp[0] = makesym(functor_entry_2);
  allocp[1] = x4;
  allocp[2] = x7 = makeref(&allocp[2]);
  x6 = makefunctor(&allocp[0]);
  allocp[3] = (q)qp;
  allocp[4] = (q)(&predicate_functor__table_xarg_3);
  allocp[5] = a0;
  allocp[6] = a1;
  allocp[7] = x6;
  qp = (struct goalrec*)&allocp[3];
  allocp += 8;
  proceed();
 make__outposition_4_2:
  if (a0 != makeint(0L)) goto make__outposition_4_interrupt;
  x8 = NILATOM;
  unify_value(a3, x8);
  proceed();
 make__outposition_4_3:
  if (!isref(a0)) goto make__outposition_4_interrupt;
  deref_and_jump(a0,make__outposition_4_1);
  *reasonp++ =  a0;
  goto make__outposition_4_interrupt;
 make__outposition_4_ext_interrupt:
  reasonp = 0l;
 make__outposition_4_interrupt:
  goto interrupt_4;
 }

 replace__tt_7_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 replace__tt_7_clear_reason:
  reasonp = reasons;
 replace__tt_7_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xreplace__tt2_7);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = a3;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[11] = a1;
  allocp[12] = x2 = makeref(&allocp[12]);
  allocp[13] = x0;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  a4 = x1;
  qp = (struct goalrec*)&allocp[9];
  allocp += 14;
  execute(make__te_5_0);
  goto make__te_5_ext_interrupt;
 replace__tt_7_ext_interrupt:
  reasonp = 0l;
 replace__tt_7_interrupt:
  goto interrupt_7;
 }

 replace__tt2_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 replace__tt2_7_clear_reason:
  reasonp = reasons;
 replace__tt2_7_0:
 replace__tt2_7_1:
  if (!isint(a0)) goto replace__tt2_7_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,replace__tt2_7_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xreplace__tt2_7);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[11] = a0;
  allocp[12] = makeint(1L);
  allocp[13] = x1;
  allocp[14] = makesym(functor_goal_4);
  allocp[15] = x4 = makeref(&allocp[15]);
  allocp[16] = x5 = makeref(&allocp[16]);
  allocp[17] = x6 = makeref(&allocp[17]);
  allocp[18] = x7 = makeref(&allocp[18]);
  x3 = makefunctor(&allocp[14]);
  allocp[19] = (q)(struct goalrec*)&allocp[9];
  allocp[20] = (q)(&predicate_ganalyzer_xreplace__tt__gvt_6);
  allocp[21] = x3;
  allocp[22] = a1;
  allocp[23] = a3;
  allocp[24] = a4;
  allocp[25] = a5;
  allocp[26] = x2;
  allocp[27] = makesym(functor_goal_4);
  allocp[28] = x4;
  allocp[29] = x5;
  allocp[30] = x6;
  allocp[31] = x7;
  x8 = makefunctor(&allocp[27]);
  allocp[32] = makesym(functor_entry_2);
  allocp[33] = x8;
  allocp[34] = x10 = makeref(&allocp[34]);
  x9 = makefunctor(&allocp[32]);
  allocp[35] = (q)(struct goalrec*)&allocp[19];
  allocp[36] = (q)(&predicate_functor__table_xarg_3);
  allocp[37] = a0;
  allocp[38] = a2;
  allocp[39] = x9;
  qp = (struct goalrec*)&allocp[35];
  allocp += 40;
  proceed();
 replace__tt2_7_2:
  if (a0 != makeint(0L)) goto replace__tt2_7_interrupt;
  unify(a6, a5);
  proceed();
 replace__tt2_7_3:
  if (!isref(a0)) goto replace__tt2_7_interrupt;
  deref_and_jump(a0,replace__tt2_7_1);
  *reasonp++ =  a0;
  goto replace__tt2_7_interrupt;
 replace__tt2_7_ext_interrupt:
  reasonp = 0l;
 replace__tt2_7_interrupt:
  goto interrupt_7;
 }

 replace__tt__gvt_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 replace__tt__gvt_6_clear_reason:
  reasonp = reasons;
 replace__tt__gvt_6_0:
 replace__tt__gvt_6_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_goal_4)) goto replace__tt__gvt_6_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a4;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a5;
  allocp[6] = makesym(functor_goal_4);
  x3 = arg(a0, 0);
  allocp[7] = x3;
  x4 = arg(a0, 1);
  allocp[8] = x4;
  x5 = arg(a0, 2);
  allocp[9] = x5;
  x6 = arg(a0, 3);
  allocp[10] = x6;
  x2 = makefunctor(&allocp[6]);
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_ganalyzer_xreplace__tt__vt_5);
  allocp[13] = x2;
  allocp[14] = a1;
  allocp[15] = a2;
  allocp[16] = x7 = makeref(&allocp[16]);
  allocp[17] = x1;
  allocp[18] = (q)(struct goalrec*)&allocp[11];
  allocp[19] = (q)(&predicate_functor__table_xarg_3);
  allocp[20] = x0;
  allocp[21] = a4;
  allocp[22] = x7;
  allocp[23] = (q)(struct goalrec*)&allocp[18];
  allocp[24] = (q)(&predicate_global__op_xget__fileno_3);
  x8 = arg(a0, 0);
  allocp[25] = x8;
  allocp[26] = a3;
  allocp[27] = x0;
  qp = (struct goalrec*)&allocp[23];
  allocp += 28;
  proceed();
 case VARREF:
  deref_and_jump(a0,replace__tt__gvt_6_1);
  *reasonp++ =  a0;
  goto replace__tt__gvt_6_interrupt;
  };
  goto replace__tt__gvt_6_interrupt;
 replace__tt__gvt_6_ext_interrupt:
  reasonp = 0l;
 replace__tt__gvt_6_interrupt:
  goto interrupt_6;
 }

 replace__tt__vt_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 replace__tt__vt_5_clear_reason:
  reasonp = reasons;
 replace__tt__vt_5_0:
 replace__tt__vt_5_1:
  switch (ptagof(a3)) {
 case CONS:
  x0 = car_of(a3);
 replace__tt__vt_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto replace__tt__vt_5_interrupt;
  allocp[0] = makesym(functor_module_2);
  x2 = arg(x0, 0);
  allocp[1] = x2;
  allocp[2] = x3 = makeref(&allocp[2]);
  x1 = makefunctor(&allocp[0]);
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = x1;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a4, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xreplace__tt__vt_5);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  x6 = cdr_of(a3);
  allocp[5] = x6;
  allocp[6] = x5;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_ganalyzer_xreplace__tt__vt__clauses_6);
  allocp[9] = x7 = makeref(&allocp[9]);
  x8 = arg(x0, 1);
  allocp[10] = x8;
  allocp[11] = x3;
  allocp[12] = a0;
  allocp[13] = a1;
  allocp[14] = a2;
  allocp[15] = (q)(struct goalrec*)&allocp[7];
  allocp[16] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[17] = x8;
  allocp[18] = x9 = makeref(&allocp[18]);
  allocp[19] = x7;
  qp = (struct goalrec*)&allocp[15];
  allocp += 20;
  proceed();
 case VARREF:
  deref_and_jump(x0,replace__tt__vt_5_2);
  *reasonp++ =  x0;
  goto replace__tt__vt_5_interrupt;
  };
  goto replace__tt__vt_5_interrupt;
 case ATOMIC:
  if (a3 != NILATOM) goto replace__tt__vt_5_interrupt;
  unify_value(a4, a3);
  proceed();
 case VARREF:
  deref_and_jump(a3,replace__tt__vt_5_1);
  *reasonp++ =  a3;
  goto replace__tt__vt_5_interrupt;
  };
  goto replace__tt__vt_5_interrupt;
 replace__tt__vt_5_ext_interrupt:
  reasonp = 0l;
 replace__tt__vt_5_interrupt:
  goto interrupt_5;
 }

 replace__tt__vt__clauses_6_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 replace__tt__vt__clauses_6_clear_reason:
  reasonp = reasons;
 replace__tt__vt__clauses_6_0:
 replace__tt__vt__clauses_6_1:
  if (!isint(a0)) goto replace__tt__vt__clauses_6_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,replace__tt__vt__clauses_6_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xreplace__tt__vt__clauses_6);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[10] = a0;
  allocp[11] = makeint(1L);
  allocp[12] = x1;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[15] = a0;
  allocp[16] = a1;
  allocp[17] = x3 = makeref(&allocp[17]);
  allocp[18] = x2;
  allocp[19] = (q)(struct goalrec*)&allocp[13];
  allocp[20] = (q)(&predicate_ganalyzer_xreplace__tt__vt__clause_6);
  allocp[21] = x4 = makeref(&allocp[21]);
  allocp[22] = x5 = makeref(&allocp[22]);
  allocp[23] = x3;
  allocp[24] = a3;
  allocp[25] = a4;
  allocp[26] = a5;
  allocp[27] = (q)(struct goalrec*)&allocp[19];
  allocp[28] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[29] = x5;
  allocp[30] = x6 = makeref(&allocp[30]);
  allocp[31] = x4;
  allocp[32] = (q)(struct goalrec*)&allocp[27];
  allocp[33] = (q)(&predicate_functor__table_xarg_3);
  allocp[34] = a0;
  allocp[35] = a1;
  allocp[36] = x5;
  qp = (struct goalrec*)&allocp[32];
  allocp += 37;
  proceed();
 replace__tt__vt__clauses_6_2:
  if (a0 != makeint(0L)) goto replace__tt__vt__clauses_6_interrupt;
  unify(a2, a1);
  proceed();
 replace__tt__vt__clauses_6_3:
  if (!isref(a0)) goto replace__tt__vt__clauses_6_interrupt;
  deref_and_jump(a0,replace__tt__vt__clauses_6_1);
  *reasonp++ =  a0;
  goto replace__tt__vt__clauses_6_interrupt;
 replace__tt__vt__clauses_6_ext_interrupt:
  reasonp = 0l;
 replace__tt__vt__clauses_6_interrupt:
  goto interrupt_6;
 }

 replace__tt__vt__clause_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 replace__tt__vt__clause_6_clear_reason:
  reasonp = reasons;
 replace__tt__vt__clause_6_0:
 replace__tt__vt__clause_6_1:
  if (!isint(a0)) goto replace__tt__vt__clause_6_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,replace__tt__vt__clause_6_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xreplace__tt__vt__clause_6);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[10] = a0;
  allocp[11] = makeint(1L);
  allocp[12] = x1;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[15] = a0;
  allocp[16] = a1;
  allocp[17] = x3 = makeref(&allocp[17]);
  allocp[18] = x2;
  allocp[19] = makesym(functor_v_3);
  allocp[20] = x5 = makeref(&allocp[20]);
  allocp[21] = x6 = makeref(&allocp[21]);
  allocp[22] = x7 = makeref(&allocp[22]);
  x4 = makefunctor(&allocp[19]);
  qp = (struct goalrec*)&allocp[13];
  allocp += 23;
  unify_value(x3, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xreplace__tt__te_5);
  allocp[2] = x8 = makeref(&allocp[2]);
  allocp[3] = x5;
  allocp[4] = a3;
  allocp[5] = a4;
  allocp[6] = a5;
  allocp[7] = makesym(functor_v_3);
  allocp[8] = x8;
  allocp[9] = x6;
  allocp[10] = x7;
  x9 = makefunctor(&allocp[7]);
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_functor__table_xarg_3);
  allocp[13] = a0;
  allocp[14] = a1;
  allocp[15] = x9;
  qp = (struct goalrec*)&allocp[11];
  allocp += 16;
  proceed();
 replace__tt__vt__clause_6_2:
  if (a0 != makeint(0L)) goto replace__tt__vt__clause_6_interrupt;
  unify(a2, a1);
  proceed();
 replace__tt__vt__clause_6_3:
  if (!isref(a0)) goto replace__tt__vt__clause_6_interrupt;
  deref_and_jump(a0,replace__tt__vt__clause_6_1);
  *reasonp++ =  a0;
  goto replace__tt__vt__clause_6_interrupt;
 replace__tt__vt__clause_6_ext_interrupt:
  reasonp = 0l;
 replace__tt__vt__clause_6_interrupt:
  goto interrupt_6;
 }

 replace__tt__te_5_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 replace__tt__te_5_clear_reason:
  reasonp = reasons;
 replace__tt__te_5_0:
  x0 = a1;
  x1 = a2;
  x2 = a3;
  a5 = a4;
  a4 = x2;
  a3 = x1;
  a2 = x0;
  a1 = NILATOM;
  execute(replace__tt__te_6_0);
  goto replace__tt__te_6_ext_interrupt;
 replace__tt__te_5_ext_interrupt:
  reasonp = 0l;
 replace__tt__te_5_interrupt:
  goto interrupt_5;
 }

 replace__tt__te_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 replace__tt__te_6_clear_reason:
  reasonp = reasons;
 replace__tt__te_6_0:
 replace__tt__te_6_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 replace__tt__te_6_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_tt_3)) goto replace__tt__te_6_14;
  x1 = arg(x0, 0);
 replace__tt__te_6_3:
  if (isref(x1)) goto replace__tt__te_6_13;
 replace__tt__te_6_4:
  if (isref(x1)) goto replace__tt__te_6_12;
  if_not_equal(x1, a3, replace__tt__te_6_14);
  x2 = arg(x0, 1);
 replace__tt__te_6_5:
  if (isref(x2)) goto replace__tt__te_6_11;
 replace__tt__te_6_6:
  if (isref(x2)) goto replace__tt__te_6_10;
  if_not_equal(x2, a4, replace__tt__te_6_14);
 replace__tt__te_6_7:
  if (isref(a3)) goto replace__tt__te_6_9;
  x4 = makeint(3L);
  gblt_arg(x4,a3,x3,replace__tt__te_6_14);
 replace__tt__te_6_8:
  switch (ptagof(x3)) {
 case ATOMIC:
  if (x3 != makesym(atom_body)) goto replace__tt__te_6_14;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xreplace__tt__te_6);
  x5 = cdr_of(a0);
  allocp[2] = x5;
  allocp[3] = x6 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[10] = a1;
  allocp[11] = x7 = makeref(&allocp[11]);
  allocp[12] = x6;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_typeset_xadd__dgoal_4);
  allocp[15] = x8 = makeref(&allocp[15]);
  allocp[16] = a3;
  allocp[17] = x7;
  allocp[18] = makesym(atom_expand);
  allocp[19] = (q)(struct goalrec*)&allocp[13];
  allocp[20] = (q)(&predicate_typeset_xadd__dgoals_4);
  allocp[21] = a5;
  x9 = arg(x0, 2);
  allocp[22] = x9;
  allocp[23] = x8;
  allocp[24] = makesym(atom_expand);
  qp = (struct goalrec*)&allocp[19];
  allocp += 25;
  proceed();
 case VARREF:
  deref_and_jump(x3,replace__tt__te_6_8);
  *reasonp++ =  x3;
  goto replace__tt__te_6_14;
  };
  goto replace__tt__te_6_14;
 replace__tt__te_6_9:
  deref_and_jump(a3,replace__tt__te_6_7);
  *reasonp++ =  a3;
  goto replace__tt__te_6_14;
 replace__tt__te_6_10:
  deref_and_jump(x2,replace__tt__te_6_6);
  *reasonp++ =  x2;
  goto replace__tt__te_6_14;
 replace__tt__te_6_11:
  deref_and_jump(x2,replace__tt__te_6_5);
  *reasonp++ =  x2;
  goto replace__tt__te_6_14;
 replace__tt__te_6_12:
  deref_and_jump(x1,replace__tt__te_6_4);
  *reasonp++ =  x1;
  goto replace__tt__te_6_14;
 replace__tt__te_6_13:
  deref_and_jump(x1,replace__tt__te_6_3);
  *reasonp++ =  x1;
  goto replace__tt__te_6_14;
 case VARREF:
  deref_and_jump(x0,replace__tt__te_6_2);
  *reasonp++ =  x0;
  goto replace__tt__te_6_14;
  };
  goto replace__tt__te_6_14;
 case VARREF:
  deref_and_jump(a0,replace__tt__te_6_1);
  *reasonp++ =  a0;
  goto replace__tt__te_6_14;
  };
  goto replace__tt__te_6_14;
 replace__tt__te_6_14:
  otherwise(replace__tt__te_6_interrupt);
 replace__tt__te_6_15:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 replace__tt__te_6_16:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_tt_3)) goto replace__tt__te_6_25;
  x1 = arg(x0, 0);
 replace__tt__te_6_17:
  if (isref(x1)) goto replace__tt__te_6_24;
 replace__tt__te_6_18:
  if (isref(x1)) goto replace__tt__te_6_23;
  if_not_equal(x1, a3, replace__tt__te_6_25);
  x2 = arg(x0, 1);
 replace__tt__te_6_19:
  if (isref(x2)) goto replace__tt__te_6_22;
 replace__tt__te_6_20:
  if (isref(x2)) goto replace__tt__te_6_21;
  if_not_equal(x2, a4, replace__tt__te_6_25);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xreplace__tt__te_6);
  x3 = cdr_of(a0);
  allocp[2] = x3;
  allocp[3] = x4 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[10] = a1;
  allocp[11] = x5 = makeref(&allocp[11]);
  allocp[12] = x4;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_typeset_xadd__dgoals_4);
  allocp[15] = a5;
  x6 = arg(x0, 2);
  allocp[16] = x6;
  allocp[17] = x5;
  allocp[18] = makesym(atom_expand);
  qp = (struct goalrec*)&allocp[13];
  allocp += 19;
  proceed();
 replace__tt__te_6_21:
  deref_and_jump(x2,replace__tt__te_6_20);
  *reasonp++ =  x2;
  goto replace__tt__te_6_25;
 replace__tt__te_6_22:
  deref_and_jump(x2,replace__tt__te_6_19);
  *reasonp++ =  x2;
  goto replace__tt__te_6_25;
 replace__tt__te_6_23:
  deref_and_jump(x1,replace__tt__te_6_18);
  *reasonp++ =  x1;
  goto replace__tt__te_6_25;
 replace__tt__te_6_24:
  deref_and_jump(x1,replace__tt__te_6_17);
  *reasonp++ =  x1;
  goto replace__tt__te_6_25;
 case VARREF:
  deref_and_jump(x0,replace__tt__te_6_16);
  *reasonp++ =  x0;
  goto replace__tt__te_6_25;
  };
  goto replace__tt__te_6_25;
 case VARREF:
  deref_and_jump(a0,replace__tt__te_6_15);
  *reasonp++ =  a0;
  goto replace__tt__te_6_25;
  };
  goto replace__tt__te_6_25;
 replace__tt__te_6_25:
  otherwise(replace__tt__te_6_interrupt);
 replace__tt__te_6_26:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xreplace__tt__te_6);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = NILATOM;
  x3 = car_of(a0);
  allocp[9] = x3;
  x2 = makecons(&allocp[8]);
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[12] = a1;
  allocp[13] = x2;
  allocp[14] = x1;
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 case ATOMIC:
  if (a0 != NILATOM) goto replace__tt__te_6_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,replace__tt__te_6_26);
  *reasonp++ =  a0;
  goto replace__tt__te_6_interrupt;
  };
  goto replace__tt__te_6_interrupt;
 replace__tt__te_6_ext_interrupt:
  reasonp = 0l;
 replace__tt__te_6_interrupt:
  toppred = &predicate_ganalyzer_xreplace__tt__te_6;
  goto interrupt_6;
 }

 make__te_5_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 make__te_5_clear_reason:
  reasonp = reasons;
 make__te_5_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xmake__te_6);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a0;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[10] = a1;
  allocp[11] = x1 = makeref(&allocp[11]);
  allocp[12] = x0;
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  proceed();
 make__te_5_ext_interrupt:
  reasonp = 0l;
 make__te_5_interrupt:
  toppred = &predicate_ganalyzer_xmake__te_5;
  goto interrupt_5;
 }

 make__te_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 make__te_6_clear_reason:
  reasonp = reasons;
 make__te_6_0:
 make__te_6_1:
  if (!isint(a0)) goto make__te_6_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,make__te_6_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xmake__te_6);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[10] = a0;
  allocp[11] = makeint(1L);
  allocp[12] = x1;
  allocp[13] = x2;
  allocp[14] = x4 = makeref(&allocp[14]);
  x3 = makecons(&allocp[13]);
  qp = (struct goalrec*)&allocp[8];
  allocp += 15;
  unify_value(a5, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xmake__te1_5);
  allocp[2] = x5 = makeref(&allocp[2]);
  allocp[3] = a2;
  allocp[4] = a3;
  allocp[5] = a4;
  allocp[6] = x4;
  allocp[7] = makesym(functor_entry_2);
  allocp[8] = x5;
  allocp[9] = x7 = makeref(&allocp[9]);
  x6 = makefunctor(&allocp[7]);
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = a0;
  allocp[13] = a1;
  allocp[14] = x6;
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 make__te_6_2:
  if (a0 != makeint(0L)) goto make__te_6_interrupt;
  x8 = NILATOM;
  unify_value(a5, x8);
  proceed();
 make__te_6_3:
  if (!isref(a0)) goto make__te_6_interrupt;
  deref_and_jump(a0,make__te_6_1);
  *reasonp++ =  a0;
  goto make__te_6_interrupt;
 make__te_6_ext_interrupt:
  reasonp = 0l;
 make__te_6_interrupt:
  goto interrupt_6;
 }

 make__te1_5_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 make__te1_5_clear_reason:
  reasonp = reasons;
 make__te1_5_0:
  allocp[0] = makesym(functor_te_4);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = NILATOM;
  x0 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a4, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = a3;
  allocp[4] = x1;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_global__op_xget__fileno_3);
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = a2;
  allocp[9] = x2;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(1L);
  allocp[13] = a0;
  allocp[14] = x3;
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 make__te1_5_ext_interrupt:
  reasonp = 0l;
 make__te1_5_interrupt:
  goto interrupt_5;
 }

 cond1_12_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 cond1_12_clear_reason:
  reasonp = reasons;
 cond1_12_0:
 cond1_12_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != NILATOM) goto cond1_12_2;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xwrite__arg__ts_6);
  allocp[2] = a4;
  allocp[3] = a6;
  allocp[4] = makecons(cons_const_1);
  allocp[5] = a7;
  allocp[6] = x0 = makeref(&allocp[6]);
  allocp[7] = a9;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_ganalyzer_xwrite__arg__ts_6);
  allocp[10] = a4;
  allocp[11] = a5;
  allocp[12] = makecons(cons_const_1);
  allocp[13] = a7;
  allocp[14] = a8;
  allocp[15] = x0;
  allocp[16] = (q)(struct goalrec*)&allocp[8];
  allocp[17] = (q)(&predicate_ganalyzer_xwrite__extern__mode_9);
  allocp[18] = a6;
  allocp[19] = a1;
  allocp[20] = a2;
  allocp[21] = a3;
  allocp[22] = a4;
  allocp[23] = makesym(atom_o);
  allocp[24] = a7;
  allocp[25] = x1 = makeref(&allocp[25]);
  allocp[26] = a11;
  allocp[27] = (q)(struct goalrec*)&allocp[16];
  allocp[28] = (q)(&predicate_ganalyzer_xwrite__extern__mode_9);
  allocp[29] = a6;
  allocp[30] = a1;
  allocp[31] = a2;
  allocp[32] = a3;
  allocp[33] = a4;
  allocp[34] = makesym(atom__3F);
  allocp[35] = a7;
  allocp[36] = x2 = makeref(&allocp[36]);
  allocp[37] = x1;
  allocp[38] = (q)(struct goalrec*)&allocp[27];
  allocp[39] = (q)(&predicate_global__op_xwrite__mode_8);
  allocp[40] = a1;
  allocp[41] = a2;
  allocp[42] = a3;
  allocp[43] = a4;
  allocp[44] = makesym(atom_o);
  allocp[45] = a7;
  allocp[46] = x3 = makeref(&allocp[46]);
  allocp[47] = x2;
  allocp[48] = (q)(struct goalrec*)&allocp[38];
  allocp[49] = (q)(&predicate_global__op_xwrite__mode_8);
  allocp[50] = a1;
  allocp[51] = a2;
  allocp[52] = a3;
  allocp[53] = a4;
  allocp[54] = makesym(atom__3F);
  allocp[55] = a7;
  allocp[56] = a10;
  allocp[57] = x3;
  qp = (struct goalrec*)&allocp[48];
  allocp += 58;
  proceed();
 case VARREF:
  deref_and_jump(a0,cond1_12_1);
  *reasonp++ =  a0;
  goto cond1_12_2;
  };
  goto cond1_12_2;
 cond1_12_2:
  otherwise(cond1_12_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xwrite__extern__mode_9);
  allocp[2] = a6;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = makesym(atom_i);
  allocp[8] = a7;
  allocp[9] = a10;
  allocp[10] = a11;
  x0 = a4;
  a1 = a6;
  a2 = a0;
  a3 = a7;
  a4 = a8;
  a5 = a9;
  a0 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 11;
  execute(write__arg__ts_6_0);
  goto write__arg__ts_6_ext_interrupt;
 cond1_12_ext_interrupt:
  reasonp = 0l;
 cond1_12_interrupt:
  goto interrupt_12;
 }

 check__ts_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 check__ts_3_clear_reason:
  reasonp = reasons;
 check__ts_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xcheck__ts2_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a1;
  a1 = x0;
  a3 = makeint(0L);
  a4 = a2;
  a2 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(split__ts_5_0);
  goto split__ts_5_ext_interrupt;
 check__ts_3_ext_interrupt:
  reasonp = 0l;
 check__ts_3_interrupt:
  toppred = &predicate_ganalyzer_xcheck__ts_3;
  goto interrupt_3;
 }

 split__ts_5_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 split__ts_5_clear_reason:
  reasonp = reasons;
 split__ts_5_0:
 split__ts_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 split__ts_5_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto split__ts_5_3;
  a0 = cdr_of(a0);
  execute(split__ts_5_0);
  goto split__ts_5_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,split__ts_5_2);
  *reasonp++ =  x0;
  goto split__ts_5_5;
  };
  goto split__ts_5_3;
 split__ts_5_3:
  gblt_pfunctor(x0,x1,split__ts_5_5);
  if (x1 != makesym(atom_tt)) goto split__ts_5_5;
  gblt_arity(x0,x2,split__ts_5_5);
 split__ts_5_4:
  if (x2 != makeint(3L)) goto split__ts_5_5;
  allocp[0] = x4 = makeref(&allocp[0]);
  allocp[1] = x0;
  x3 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x3);
  x5 = makeint(1L);
  bblt_add_no_check_y(a3,x5,x6);
  a0 = cdr_of(a0);
  a2 = x4;
  a3 = x6;
  execute(split__ts_5_0);
  goto split__ts_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,split__ts_5_1);
  *reasonp++ =  a0;
  goto split__ts_5_5;
  };
  goto split__ts_5_5;
 split__ts_5_5:
  otherwise(split__ts_5_interrupt);
 split__ts_5_6:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(split__ts_5_0);
  goto split__ts_5_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto split__ts_5_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  x1 = NILATOM;
  unify_value(a2, x1);
  unify(a4, a3);
  proceed();
 case VARREF:
  deref_and_jump(a0,split__ts_5_6);
  *reasonp++ =  a0;
  goto split__ts_5_interrupt;
  };
  goto split__ts_5_interrupt;
 split__ts_5_ext_interrupt:
  reasonp = 0l;
 split__ts_5_interrupt:
  toppred = &predicate_ganalyzer_xsplit__ts_5;
  goto interrupt_5;
 }

 check__ts2_3_top: {
  q x0;
  a2 = qp->args[2];
  qp = qp->next;
 check__ts2_3_clear_reason:
  reasonp = reasons;
 check__ts2_3_0:
 check__ts2_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != NILATOM) goto check__ts2_3_2;
  x0 = makesym(atom_zantei);
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,check__ts2_3_1);
  *reasonp++ =  a0;
  goto check__ts2_3_2;
  };
  goto check__ts2_3_2;
 check__ts2_3_2:
 check__ts2_3_3:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != NILATOM) goto check__ts2_3_4;
  x0 = makesym(atom_kakutei);
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,check__ts2_3_3);
  *reasonp++ =  a1;
  goto check__ts2_3_4;
  };
  goto check__ts2_3_4;
 check__ts2_3_4:
  otherwise(check__ts2_3_interrupt);
  x0 = makesym(atom_zantei);
  unify_value(a2, x0);
  proceed();
 check__ts2_3_ext_interrupt:
  reasonp = 0l;
 check__ts2_3_interrupt:
  goto interrupt_3;
 }

 read__arg__ts_5_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 read__arg__ts_5_clear_reason:
  reasonp = reasons;
 read__arg__ts_5_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xread__arg__ts_6);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[10] = a1;
  allocp[11] = x1 = makeref(&allocp[11]);
  allocp[12] = x0;
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  proceed();
 read__arg__ts_5_ext_interrupt:
  reasonp = 0l;
 read__arg__ts_5_interrupt:
  toppred = &predicate_ganalyzer_xread__arg__ts_5;
  goto interrupt_5;
 }

 read__arg__ts_6_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 read__arg__ts_6_clear_reason:
  reasonp = reasons;
 read__arg__ts_6_0:
  x0 = a3;
  x1 = a4;
  a6 = a5;
  a5 = x1;
  a4 = x0;
  a3 = NILATOM;
  execute(read__arg__ts_7_0);
  goto read__arg__ts_7_ext_interrupt;
 read__arg__ts_6_ext_interrupt:
  reasonp = 0l;
 read__arg__ts_6_interrupt:
  goto interrupt_6;
 }

 read__arg__ts_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 read__arg__ts_7_clear_reason:
  reasonp = reasons;
 read__arg__ts_7_0:
 read__arg__ts_7_1:
  if (!isint(a0)) goto read__arg__ts_7_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,read__arg__ts_7_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xread__arg__ts_7);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[11] = a0;
  allocp[12] = makeint(1L);
  allocp[13] = x1;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[16] = a3;
  allocp[17] = x3 = makeref(&allocp[17]);
  allocp[18] = x2;
  allocp[19] = (q)(struct goalrec*)&allocp[14];
  allocp[20] = (q)(&predicate_global__op_xread__ts_6);
  allocp[21] = x4 = makeref(&allocp[21]);
  allocp[22] = x5 = makeref(&allocp[22]);
  allocp[23] = x6 = makeref(&allocp[23]);
  allocp[24] = a5;
  allocp[25] = a6;
  allocp[26] = x3;
  allocp[27] = (q)(struct goalrec*)&allocp[19];
  allocp[28] = (q)(&predicate_functor__table_xarg_3);
  allocp[29] = a1;
  allocp[30] = x7 = makeref(&allocp[30]);
  allocp[31] = x6;
  allocp[32] = makesym(functor_goal_4);
  allocp[33] = x4;
  allocp[34] = x5;
  allocp[35] = x9 = makeref(&allocp[35]);
  allocp[36] = x10 = makeref(&allocp[36]);
  x8 = makefunctor(&allocp[32]);
  allocp[37] = makesym(functor_entry_2);
  allocp[38] = x8;
  allocp[39] = x7;
  x11 = makefunctor(&allocp[37]);
  allocp[40] = (q)(struct goalrec*)&allocp[27];
  allocp[41] = (q)(&predicate_functor__table_xarg_3);
  allocp[42] = a0;
  allocp[43] = a2;
  allocp[44] = x11;
  qp = (struct goalrec*)&allocp[40];
  allocp += 45;
  proceed();
 read__arg__ts_7_2:
  if (a0 != makeint(0L)) goto read__arg__ts_7_interrupt;
  unify(a4, a3);
  proceed();
 read__arg__ts_7_3:
  if (!isref(a0)) goto read__arg__ts_7_interrupt;
  deref_and_jump(a0,read__arg__ts_7_1);
  *reasonp++ =  a0;
  goto read__arg__ts_7_interrupt;
 read__arg__ts_7_ext_interrupt:
  reasonp = 0l;
 read__arg__ts_7_interrupt:
  toppred = &predicate_ganalyzer_xread__arg__ts_7;
  goto interrupt_7;
 }

 write__arg__ts_6_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 write__arg__ts_6_clear_reason:
  reasonp = reasons;
 write__arg__ts_6_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xwrite__arg__ts_7);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[11] = a1;
  allocp[12] = x1 = makeref(&allocp[12]);
  allocp[13] = x0;
  qp = (struct goalrec*)&allocp[9];
  allocp += 14;
  proceed();
 write__arg__ts_6_ext_interrupt:
  reasonp = 0l;
 write__arg__ts_6_interrupt:
  toppred = &predicate_ganalyzer_xwrite__arg__ts_6;
  goto interrupt_6;
 }

 write__arg__ts_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 write__arg__ts_7_clear_reason:
  reasonp = reasons;
 write__arg__ts_7_0:
 write__arg__ts_7_1:
  if (!isint(a0)) goto write__arg__ts_7_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,write__arg__ts_7_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xwrite__arg__ts_7);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[11] = a0;
  allocp[12] = makeint(1L);
  allocp[13] = x1;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_global__op_xwrite__ts_7);
  allocp[16] = x3 = makeref(&allocp[16]);
  allocp[17] = x4 = makeref(&allocp[17]);
  allocp[18] = x5 = makeref(&allocp[18]);
  allocp[19] = a3;
  allocp[20] = a4;
  allocp[21] = a5;
  allocp[22] = x2;
  allocp[23] = (q)(struct goalrec*)&allocp[14];
  allocp[24] = (q)(&predicate_functor__table_xarg_3);
  allocp[25] = a1;
  allocp[26] = x6 = makeref(&allocp[26]);
  allocp[27] = x5;
  allocp[28] = makesym(functor_goal_4);
  allocp[29] = x3;
  allocp[30] = x4;
  allocp[31] = x8 = makeref(&allocp[31]);
  allocp[32] = x9 = makeref(&allocp[32]);
  x7 = makefunctor(&allocp[28]);
  allocp[33] = makesym(functor_entry_2);
  allocp[34] = x7;
  allocp[35] = x6;
  x10 = makefunctor(&allocp[33]);
  allocp[36] = (q)(struct goalrec*)&allocp[23];
  allocp[37] = (q)(&predicate_functor__table_xarg_3);
  allocp[38] = a0;
  allocp[39] = a2;
  allocp[40] = x10;
  qp = (struct goalrec*)&allocp[36];
  allocp += 41;
  proceed();
 write__arg__ts_7_2:
  if (a0 != makeint(0L)) goto write__arg__ts_7_interrupt;
  unify(a6, a5);
  proceed();
 write__arg__ts_7_3:
  if (!isref(a0)) goto write__arg__ts_7_interrupt;
  deref_and_jump(a0,write__arg__ts_7_1);
  *reasonp++ =  a0;
  goto write__arg__ts_7_interrupt;
 write__arg__ts_7_ext_interrupt:
  reasonp = 0l;
 write__arg__ts_7_interrupt:
  goto interrupt_7;
 }

 get__same__pred__head_4_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 get__same__pred__head_4_clear_reason:
  reasonp = reasons;
 get__same__pred__head_4_0:
 get__same__pred__head_4_1:
  switch (ptagof(a2)) {
 case CONS:
  x0 = car_of(a2);
 get__same__pred__head_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_3)) goto get__same__pred__head_4_11;
  x1 = arg(x0, 0);
 get__same__pred__head_4_3:
  if (isref(x1)) goto get__same__pred__head_4_10;
 get__same__pred__head_4_4:
  if (isref(x1)) goto get__same__pred__head_4_9;
  if_not_equal(x1, a0, get__same__pred__head_4_11);
  x2 = arg(x0, 1);
 get__same__pred__head_4_5:
  if (isref(x2)) goto get__same__pred__head_4_8;
 get__same__pred__head_4_6:
  if (isref(x2)) goto get__same__pred__head_4_7;
  if_not_equal(x2, a1, get__same__pred__head_4_11);
  allocp[0] = makesym(functor_pred_3);
  allocp[1] = a0;
  allocp[2] = a1;
  x4 = arg(x0, 2);
  allocp[3] = x4;
  x3 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a3, x3);
  proceed();
 get__same__pred__head_4_7:
  deref_and_jump(x2,get__same__pred__head_4_6);
  *reasonp++ =  x2;
  goto get__same__pred__head_4_11;
 get__same__pred__head_4_8:
  deref_and_jump(x2,get__same__pred__head_4_5);
  *reasonp++ =  x2;
  goto get__same__pred__head_4_11;
 get__same__pred__head_4_9:
  deref_and_jump(x1,get__same__pred__head_4_4);
  *reasonp++ =  x1;
  goto get__same__pred__head_4_11;
 get__same__pred__head_4_10:
  deref_and_jump(x1,get__same__pred__head_4_3);
  *reasonp++ =  x1;
  goto get__same__pred__head_4_11;
 case VARREF:
  deref_and_jump(x0,get__same__pred__head_4_2);
  *reasonp++ =  x0;
  goto get__same__pred__head_4_11;
  };
  goto get__same__pred__head_4_11;
 case VARREF:
  deref_and_jump(a2,get__same__pred__head_4_1);
  *reasonp++ =  a2;
  goto get__same__pred__head_4_11;
  };
  goto get__same__pred__head_4_11;
 get__same__pred__head_4_11:
  otherwise(get__same__pred__head_4_interrupt);
 get__same__pred__head_4_12:
  switch (ptagof(a2)) {
 case CONS:
  a2 = cdr_of(a2);
  execute(get__same__pred__head_4_0);
  goto get__same__pred__head_4_ext_interrupt;
 case ATOMIC:
  if (a2 != NILATOM) goto get__same__pred__head_4_interrupt;
  x0 = makesym(atom_error);
  x1 = makesym(atom_get__same__pred__head);
  unify(x0, x1);
  proceed();
 case VARREF:
  deref_and_jump(a2,get__same__pred__head_4_12);
  *reasonp++ =  a2;
  goto get__same__pred__head_4_interrupt;
  };
  goto get__same__pred__head_4_interrupt;
 get__same__pred__head_4_ext_interrupt:
  reasonp = 0l;
 get__same__pred__head_4_interrupt:
  toppred = &predicate_ganalyzer_xget__same__pred__head_4;
  goto interrupt_4;
 }

 remove__all__tt_2_top: {
  q x0, x1;
  qp = qp->next;
 remove__all__tt_2_clear_reason:
  reasonp = reasons;
 remove__all__tt_2_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xremove__all__tt_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[7] = a0;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x0;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 remove__all__tt_2_ext_interrupt:
  reasonp = 0l;
 remove__all__tt_2_interrupt:
  goto interrupt_2;
 }

 remove__all__tt_3_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  qp = qp->next;
 remove__all__tt_3_clear_reason:
  reasonp = reasons;
 remove__all__tt_3_0:
 remove__all__tt_3_1:
  if (!isint(a0)) goto remove__all__tt_3_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,remove__all__tt_3_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xremove__all__tt_3);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[7] = a0;
  allocp[8] = makeint(1L);
  allocp[9] = x1;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[12] = a0;
  allocp[13] = a1;
  allocp[14] = x3 = makeref(&allocp[14]);
  allocp[15] = x2;
  allocp[16] = (q)(struct goalrec*)&allocp[10];
  allocp[17] = (q)(&predicate_ganalyzer_xremove__all__tt__vt_2);
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = x3;
  allocp[20] = (q)(struct goalrec*)&allocp[16];
  allocp[21] = (q)(&predicate_functor__table_xarg_3);
  allocp[22] = a0;
  allocp[23] = a1;
  allocp[24] = x4;
  qp = (struct goalrec*)&allocp[20];
  allocp += 25;
  proceed();
 remove__all__tt_3_2:
  if (a0 != makeint(0L)) goto remove__all__tt_3_interrupt;
  unify(a2, a1);
  proceed();
 remove__all__tt_3_3:
  if (!isref(a0)) goto remove__all__tt_3_interrupt;
  deref_and_jump(a0,remove__all__tt_3_1);
  *reasonp++ =  a0;
  goto remove__all__tt_3_interrupt;
 remove__all__tt_3_ext_interrupt:
  reasonp = 0l;
 remove__all__tt_3_interrupt:
  goto interrupt_3;
 }

 remove__all__tt__vt_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  qp = qp->next;
 remove__all__tt__vt_2_clear_reason:
  reasonp = reasons;
 remove__all__tt__vt_2_0:
 remove__all__tt__vt_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 remove__all__tt__vt_2_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto remove__all__tt__vt_2_interrupt;
  allocp[0] = makesym(functor_module_2);
  x2 = arg(x0, 0);
  allocp[1] = x2;
  allocp[2] = x3 = makeref(&allocp[2]);
  x1 = makefunctor(&allocp[0]);
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = x1;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a1, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xremove__all__tt__vt_2);
  x6 = cdr_of(a0);
  allocp[2] = x6;
  allocp[3] = x5;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_ganalyzer_xremove__all__tt__clauses_3);
  allocp[6] = x7 = makeref(&allocp[6]);
  x8 = arg(x0, 1);
  allocp[7] = x8;
  allocp[8] = x3;
  allocp[9] = (q)(struct goalrec*)&allocp[4];
  allocp[10] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[11] = x8;
  allocp[12] = x9 = makeref(&allocp[12]);
  allocp[13] = x7;
  qp = (struct goalrec*)&allocp[9];
  allocp += 14;
  proceed();
 case VARREF:
  deref_and_jump(x0,remove__all__tt__vt_2_2);
  *reasonp++ =  x0;
  goto remove__all__tt__vt_2_interrupt;
  };
  goto remove__all__tt__vt_2_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto remove__all__tt__vt_2_interrupt;
  unify_value(a1, a0);
  proceed();
 case VARREF:
  deref_and_jump(a0,remove__all__tt__vt_2_1);
  *reasonp++ =  a0;
  goto remove__all__tt__vt_2_interrupt;
  };
  goto remove__all__tt__vt_2_interrupt;
 remove__all__tt__vt_2_ext_interrupt:
  reasonp = 0l;
 remove__all__tt__vt_2_interrupt:
  goto interrupt_2;
 }

 remove__all__tt__clauses_3_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  qp = qp->next;
 remove__all__tt__clauses_3_clear_reason:
  reasonp = reasons;
 remove__all__tt__clauses_3_0:
 remove__all__tt__clauses_3_1:
  if (!isint(a0)) goto remove__all__tt__clauses_3_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,remove__all__tt__clauses_3_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xremove__all__tt__clauses_3);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[7] = a0;
  allocp[8] = makeint(1L);
  allocp[9] = x1;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[12] = a0;
  allocp[13] = a1;
  allocp[14] = x3 = makeref(&allocp[14]);
  allocp[15] = x2;
  allocp[16] = (q)(struct goalrec*)&allocp[10];
  allocp[17] = (q)(&predicate_ganalyzer_xremove__all__tt__clause_3);
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = x5 = makeref(&allocp[19]);
  allocp[20] = x3;
  allocp[21] = (q)(struct goalrec*)&allocp[16];
  allocp[22] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[23] = x5;
  allocp[24] = x6 = makeref(&allocp[24]);
  allocp[25] = x4;
  allocp[26] = (q)(struct goalrec*)&allocp[21];
  allocp[27] = (q)(&predicate_functor__table_xarg_3);
  allocp[28] = a0;
  allocp[29] = a1;
  allocp[30] = x5;
  qp = (struct goalrec*)&allocp[26];
  allocp += 31;
  proceed();
 remove__all__tt__clauses_3_2:
  if (a0 != makeint(0L)) goto remove__all__tt__clauses_3_interrupt;
  unify(a2, a1);
  proceed();
 remove__all__tt__clauses_3_3:
  if (!isref(a0)) goto remove__all__tt__clauses_3_interrupt;
  deref_and_jump(a0,remove__all__tt__clauses_3_1);
  *reasonp++ =  a0;
  goto remove__all__tt__clauses_3_interrupt;
 remove__all__tt__clauses_3_ext_interrupt:
  reasonp = 0l;
 remove__all__tt__clauses_3_interrupt:
  goto interrupt_3;
 }

 remove__all__tt__clause_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  qp = qp->next;
 remove__all__tt__clause_3_clear_reason:
  reasonp = reasons;
 remove__all__tt__clause_3_0:
 remove__all__tt__clause_3_1:
  if (!isint(a0)) goto remove__all__tt__clause_3_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,remove__all__tt__clause_3_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xremove__all__tt__clause_3);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[7] = a0;
  allocp[8] = makeint(1L);
  allocp[9] = x1;
  allocp[10] = makesym(functor_v_3);
  allocp[11] = x4 = makeref(&allocp[11]);
  allocp[12] = x5 = makeref(&allocp[12]);
  allocp[13] = x6 = makeref(&allocp[13]);
  x3 = makefunctor(&allocp[10]);
  allocp[14] = (q)(struct goalrec*)&allocp[5];
  allocp[15] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[16] = a0;
  allocp[17] = a1;
  allocp[18] = x3;
  allocp[19] = x2;
  allocp[20] = (q)(struct goalrec*)&allocp[14];
  allocp[21] = (q)(&predicate_ganalyzer_xremove__all__tt__ts2_2);
  allocp[22] = x7 = makeref(&allocp[22]);
  allocp[23] = x4;
  allocp[24] = (q)(struct goalrec*)&allocp[20];
  allocp[25] = (q)(&predicate_ganalyzer_xremove__all__tt__ts_2);
  allocp[26] = x8 = makeref(&allocp[26]);
  allocp[27] = x7;
  allocp[28] = makesym(functor_v_3);
  allocp[29] = x8;
  allocp[30] = x5;
  allocp[31] = x6;
  x9 = makefunctor(&allocp[28]);
  allocp[32] = (q)(struct goalrec*)&allocp[24];
  allocp[33] = (q)(&predicate_functor__table_xarg_3);
  allocp[34] = a0;
  allocp[35] = a1;
  allocp[36] = x9;
  qp = (struct goalrec*)&allocp[32];
  allocp += 37;
  proceed();
 remove__all__tt__clause_3_2:
  if (a0 != makeint(0L)) goto remove__all__tt__clause_3_interrupt;
  unify(a2, a1);
  proceed();
 remove__all__tt__clause_3_3:
  if (!isref(a0)) goto remove__all__tt__clause_3_interrupt;
  deref_and_jump(a0,remove__all__tt__clause_3_1);
  *reasonp++ =  a0;
  goto remove__all__tt__clause_3_interrupt;
 remove__all__tt__clause_3_ext_interrupt:
  reasonp = 0l;
 remove__all__tt__clause_3_interrupt:
  goto interrupt_3;
 }

 remove__all__tt__ts_2_top: {
  q x0, x1, x2;
  qp = qp->next;
 remove__all__tt__ts_2_clear_reason:
  reasonp = reasons;
 remove__all__tt__ts_2_0:
 remove__all__tt__ts_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 remove__all__tt__ts_2_2:
  if (isref(x0)) goto remove__all__tt__ts_2_4;
  gblt_pfunctor(x0,x1,remove__all__tt__ts_2_5);
  if (x1 != makesym(atom_tt)) goto remove__all__tt__ts_2_5;
  gblt_arity(x0,x2,remove__all__tt__ts_2_5);
 remove__all__tt__ts_2_3:
  if (x2 != makeint(3L)) goto remove__all__tt__ts_2_5;
  a0 = cdr_of(a0);
  execute(remove__all__tt__ts_2_0);
  goto remove__all__tt__ts_2_ext_interrupt;
 remove__all__tt__ts_2_4:
  deref_and_jump(x0,remove__all__tt__ts_2_2);
  *reasonp++ =  x0;
  goto remove__all__tt__ts_2_5;
 case VARREF:
  deref_and_jump(a0,remove__all__tt__ts_2_1);
  *reasonp++ =  a0;
  goto remove__all__tt__ts_2_5;
  };
  goto remove__all__tt__ts_2_5;
 remove__all__tt__ts_2_5:
  otherwise(remove__all__tt__ts_2_interrupt);
 remove__all__tt__ts_2_6:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(remove__all__tt__ts_2_0);
  goto remove__all__tt__ts_2_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto remove__all__tt__ts_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,remove__all__tt__ts_2_6);
  *reasonp++ =  a0;
  goto remove__all__tt__ts_2_interrupt;
  };
  goto remove__all__tt__ts_2_interrupt;
 remove__all__tt__ts_2_ext_interrupt:
  reasonp = 0l;
 remove__all__tt__ts_2_interrupt:
  goto interrupt_2;
 }

 remove__all__tt__ts2_2_top: {
  q x0;
  qp = qp->next;
 remove__all__tt__ts2_2_clear_reason:
  reasonp = reasons;
 remove__all__tt__ts2_2_0:
 remove__all__tt__ts2_2_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != NILATOM) goto remove__all__tt__ts2_2_2;
  x0 = makecons(cons_const_1);
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,remove__all__tt__ts2_2_1);
  *reasonp++ =  a0;
  goto remove__all__tt__ts2_2_2;
  };
  goto remove__all__tt__ts2_2_2;
 remove__all__tt__ts2_2_2:
  otherwise(remove__all__tt__ts2_2_interrupt);
  unify(a1, a0);
  proceed();
 remove__all__tt__ts2_2_ext_interrupt:
  reasonp = 0l;
 remove__all__tt__ts2_2_interrupt:
  goto interrupt_2;
 }

 write__extern__mode_9_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 write__extern__mode_9_clear_reason:
  reasonp = reasons;
 write__extern__mode_9_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xwrite__extern__mode_10);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = a8;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[14] = a0;
  allocp[15] = x1 = makeref(&allocp[15]);
  allocp[16] = x0;
  qp = (struct goalrec*)&allocp[12];
  allocp += 17;
  proceed();
 write__extern__mode_9_ext_interrupt:
  reasonp = 0l;
 write__extern__mode_9_interrupt:
  toppred = &predicate_ganalyzer_xwrite__extern__mode_9;
  goto interrupt_9;
 }

 write__extern__mode_10_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 write__extern__mode_10_clear_reason:
  reasonp = reasons;
 write__extern__mode_10_0:
 write__extern__mode_10_1:
  if (!isint(a0)) goto write__extern__mode_10_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,write__extern__mode_10_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xwrite__extern__mode_10);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = x2 = makeref(&allocp[10]);
  allocp[11] = a9;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[14] = a0;
  allocp[15] = makeint(1L);
  allocp[16] = x1;
  allocp[17] = (q)(struct goalrec*)&allocp[12];
  allocp[18] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[19] = x3 = makeref(&allocp[19]);
  allocp[20] = a8;
  allocp[21] = x4 = makeref(&allocp[21]);
  allocp[22] = x2;
  allocp[23] = (q)(struct goalrec*)&allocp[17];
  allocp[24] = (q)(&predicate_hb_xwrite__mode_7);
  allocp[25] = a2;
  allocp[26] = a3;
  allocp[27] = a4;
  allocp[28] = a5;
  allocp[29] = a6;
  allocp[30] = x5 = makeref(&allocp[30]);
  allocp[31] = x4;
  allocp[32] = (q)(struct goalrec*)&allocp[23];
  allocp[33] = (q)(&predicate_functor__table_xarg_3);
  allocp[34] = x3;
  allocp[35] = a8;
  allocp[36] = x5;
  allocp[37] = (q)(struct goalrec*)&allocp[32];
  allocp[38] = (q)(&predicate_global__op_xget__fileno_3);
  allocp[39] = x6 = makeref(&allocp[39]);
  allocp[40] = a7;
  allocp[41] = x3;
  allocp[42] = makesym(functor_goal_4);
  allocp[43] = x6;
  allocp[44] = x8 = makeref(&allocp[44]);
  allocp[45] = x9 = makeref(&allocp[45]);
  allocp[46] = x10 = makeref(&allocp[46]);
  x7 = makefunctor(&allocp[42]);
  allocp[47] = makesym(functor_entry_2);
  allocp[48] = x7;
  allocp[49] = x12 = makeref(&allocp[49]);
  x11 = makefunctor(&allocp[47]);
  allocp[50] = (q)(struct goalrec*)&allocp[37];
  allocp[51] = (q)(&predicate_functor__table_xarg_3);
  allocp[52] = a0;
  allocp[53] = a1;
  allocp[54] = x11;
  qp = (struct goalrec*)&allocp[50];
  allocp += 55;
  proceed();
 write__extern__mode_10_2:
  if (a0 != makeint(0L)) goto write__extern__mode_10_interrupt;
  unify(a9, a8);
  proceed();
 write__extern__mode_10_3:
  if (!isref(a0)) goto write__extern__mode_10_interrupt;
  deref_and_jump(a0,write__extern__mode_10_1);
  *reasonp++ =  a0;
  goto write__extern__mode_10_interrupt;
 write__extern__mode_10_ext_interrupt:
  reasonp = 0l;
 write__extern__mode_10_interrupt:
  goto interrupt_10;
 }

 fix__mode_5_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 fix__mode_5_clear_reason:
  reasonp = reasons;
 fix__mode_5_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xfix__mode_6);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[10] = a0;
  allocp[11] = x1 = makeref(&allocp[11]);
  allocp[12] = x0;
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  proceed();
 fix__mode_5_ext_interrupt:
  reasonp = 0l;
 fix__mode_5_interrupt:
  goto interrupt_5;
 }

 fix__mode_6_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 fix__mode_6_clear_reason:
  reasonp = reasons;
 fix__mode_6_0:
 fix__mode_6_1:
  if (!isint(a0)) goto fix__mode_6_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,fix__mode_6_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xfix__mode_6);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[10] = a0;
  allocp[11] = makeint(1L);
  allocp[12] = x1;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_ganalyzer_xfix__mode__module_5);
  allocp[15] = x3 = makeref(&allocp[15]);
  allocp[16] = x4 = makeref(&allocp[16]);
  allocp[17] = a3;
  allocp[18] = a4;
  allocp[19] = x2;
  allocp[20] = (q)(struct goalrec*)&allocp[13];
  allocp[21] = (q)(&predicate_functor__table_xarg_3);
  allocp[22] = a0;
  allocp[23] = a2;
  allocp[24] = x4;
  allocp[25] = (q)(struct goalrec*)&allocp[20];
  allocp[26] = (q)(&predicate_functor__table_xarg_3);
  allocp[27] = a0;
  allocp[28] = a1;
  allocp[29] = x3;
  qp = (struct goalrec*)&allocp[25];
  allocp += 30;
  proceed();
 fix__mode_6_2:
  if (a0 != makeint(0L)) goto fix__mode_6_interrupt;
  unify(a5, a4);
  proceed();
 fix__mode_6_3:
  if (!isref(a0)) goto fix__mode_6_interrupt;
  deref_and_jump(a0,fix__mode_6_1);
  *reasonp++ =  a0;
  goto fix__mode_6_interrupt;
 fix__mode_6_ext_interrupt:
  reasonp = 0l;
 fix__mode_6_interrupt:
  goto interrupt_6;
 }

 fix__mode__module_5_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 fix__mode__module_5_clear_reason:
  reasonp = reasons;
 fix__mode__module_5_0:
 fix__mode__module_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 fix__mode__module_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto fix__mode__module_5_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xfix__mode__module_5);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  a0 = arg(x0, 1);
  x3 = arg(x0, 0);
  x4 = a1;
  x5 = a2;
  a4 = a3;
  a5 = x2;
  a3 = x5;
  a2 = x4;
  a1 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(fix__mode__preds_6_0);
  goto fix__mode__preds_6_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,fix__mode__module_5_2);
  *reasonp++ =  x0;
  goto fix__mode__module_5_interrupt;
  };
  goto fix__mode__module_5_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto fix__mode__module_5_interrupt;
  unify(a4, a3);
  proceed();
 case VARREF:
  deref_and_jump(a0,fix__mode__module_5_1);
  *reasonp++ =  a0;
  goto fix__mode__module_5_interrupt;
  };
  goto fix__mode__module_5_interrupt;
 fix__mode__module_5_ext_interrupt:
  reasonp = 0l;
 fix__mode__module_5_interrupt:
  goto interrupt_5;
 }

 fix__mode__preds_6_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 fix__mode__preds_6_clear_reason:
  reasonp = reasons;
 fix__mode__preds_6_0:
 fix__mode__preds_6_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 fix__mode__preds_6_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_7)) goto fix__mode__preds_6_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xfix__mode__preds_6);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  a0 = arg(x0, 1);
  x3 = arg(x0, 0);
  x4 = arg(x0, 1);
  x5 = arg(x0, 2);
  a5 = arg(x0, 3);
  a6 = arg(x0, 4);
  a7 = a2;
  a8 = a3;
  a9 = a4;
  a10 = x2;
  a4 = x5;
  a3 = x4;
  a2 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  execute(fix__mode__pred_11_0);
  goto fix__mode__pred_11_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,fix__mode__preds_6_2);
  *reasonp++ =  x0;
  goto fix__mode__preds_6_interrupt;
  };
  goto fix__mode__preds_6_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto fix__mode__preds_6_interrupt;
  unify(a5, a4);
  proceed();
 case VARREF:
  deref_and_jump(a0,fix__mode__preds_6_1);
  *reasonp++ =  a0;
  goto fix__mode__preds_6_interrupt;
  };
  goto fix__mode__preds_6_interrupt;
 fix__mode__preds_6_ext_interrupt:
  reasonp = 0l;
 fix__mode__preds_6_interrupt:
  toppred = &predicate_ganalyzer_xfix__mode__preds_6;
  goto interrupt_6;
 }

 fix__mode__pred_11_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 fix__mode__pred_11_clear_reason:
  reasonp = reasons;
 fix__mode__pred_11_0:
 fix__mode__pred_11_1:
  if (!isint(a0)) goto fix__mode__pred_11_6;
  x0 = makeint(0L);
  gblt_greater(a0,x0,fix__mode__pred_11_5);
 fix__mode__pred_11_2:
  if (isref(a4)) goto fix__mode__pred_11_4;
  gblt_arg(a0,a4,x1,fix__mode__pred_11_5);
 fix__mode__pred_11_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (isint(x1)) goto fix__mode__pred_11_5;
  switch (symval(x1)) {
 case symval(makesym(atom_i)):
  x2 = makeint(1L);
  bblt_sub_no_check(a0,x2,x3);
  a0 = x3;
  execute(fix__mode__pred_11_0);
  goto fix__mode__pred_11_ext_interrupt;
 case symval(makesym(atom_o)):
  x2 = makeint(1L);
  bblt_sub_no_check(a0,x2,x3);
  a0 = x3;
  execute(fix__mode__pred_11_0);
  goto fix__mode__pred_11_ext_interrupt;
 case symval(makesym(atom__3F)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xfix__mode__pred_11);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = x3 = makeref(&allocp[11]);
  allocp[12] = a10;
  allocp[13] = (q)(struct goalrec*)&allocp[0];
  allocp[14] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[15] = a0;
  allocp[16] = makeint(1L);
  allocp[17] = x2;
  allocp[18] = (q)(struct goalrec*)&allocp[13];
  allocp[19] = (q)(&predicate_ganalyzer_xfix__mode__args_10);
  allocp[20] = x4 = makeref(&allocp[20]);
  allocp[21] = x5 = makeref(&allocp[21]);
  allocp[22] = a1;
  allocp[23] = a2;
  allocp[24] = a3;
  allocp[25] = a0;
  allocp[26] = a7;
  allocp[27] = a8;
  allocp[28] = a9;
  allocp[29] = x3;
  allocp[30] = (q)(struct goalrec*)&allocp[18];
  allocp[31] = (q)(&predicate_functor__table_xarg_3);
  allocp[32] = a0;
  allocp[33] = a6;
  allocp[34] = x5;
  allocp[35] = (q)(struct goalrec*)&allocp[30];
  allocp[36] = (q)(&predicate_functor__table_xarg_3);
  allocp[37] = a0;
  allocp[38] = a5;
  allocp[39] = x4;
  qp = (struct goalrec*)&allocp[35];
  allocp += 40;
  proceed();
  };
  goto fix__mode__pred_11_5;
 case VARREF:
  deref_and_jump(x1,fix__mode__pred_11_3);
  *reasonp++ =  x1;
  goto fix__mode__pred_11_5;
  };
  goto fix__mode__pred_11_5;
 fix__mode__pred_11_4:
  deref_and_jump(a4,fix__mode__pred_11_2);
  *reasonp++ =  a4;
  goto fix__mode__pred_11_5;
 fix__mode__pred_11_5:
  if (a0 != makeint(0L)) goto fix__mode__pred_11_interrupt;
  unify(a10, a9);
  proceed();
 fix__mode__pred_11_6:
  if (!isref(a0)) goto fix__mode__pred_11_interrupt;
  deref_and_jump(a0,fix__mode__pred_11_1);
  *reasonp++ =  a0;
  goto fix__mode__pred_11_interrupt;
 fix__mode__pred_11_ext_interrupt:
  reasonp = 0l;
 fix__mode__pred_11_interrupt:
  toppred = &predicate_ganalyzer_xfix__mode__pred_11;
  goto interrupt_11;
 }

 fix__mode__args_10_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 fix__mode__args_10_clear_reason:
  reasonp = reasons;
 fix__mode__args_10_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_global__op_xwrite__mode_8);
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  allocp[5] = a5;
  allocp[6] = x0 = makeref(&allocp[6]);
  allocp[7] = a7;
  allocp[8] = a8;
  allocp[9] = a9;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_ganalyzer_xget__new__mode_3);
  allocp[12] = x1 = makeref(&allocp[12]);
  allocp[13] = x2 = makeref(&allocp[13]);
  allocp[14] = x0;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_ganalyzer_xremove__ds_3);
  allocp[17] = x3 = makeref(&allocp[17]);
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = x2;
  allocp[20] = (q)(struct goalrec*)&allocp[15];
  allocp[21] = (q)(&predicate_ganalyzer_xget__ds_6);
  allocp[22] = x5 = makeref(&allocp[22]);
  allocp[23] = a1;
  allocp[24] = x3;
  allocp[25] = NILATOM;
  allocp[26] = x4;
  allocp[27] = a6;
  allocp[28] = (q)(struct goalrec*)&allocp[20];
  allocp[29] = (q)(&predicate_ganalyzer_xremove__ds_3);
  allocp[30] = x6 = makeref(&allocp[30]);
  allocp[31] = x7 = makeref(&allocp[31]);
  allocp[32] = x1;
  allocp[33] = (q)(struct goalrec*)&allocp[28];
  allocp[34] = (q)(&predicate_ganalyzer_xget__ds_6);
  allocp[35] = x8 = makeref(&allocp[35]);
  allocp[36] = a0;
  allocp[37] = x6;
  allocp[38] = NILATOM;
  allocp[39] = x7;
  allocp[40] = a6;
  allocp[41] = (q)(struct goalrec*)&allocp[33];
  allocp[42] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[43] = a1;
  allocp[44] = x9 = makeref(&allocp[44]);
  allocp[45] = x5;
  allocp[46] = (q)(struct goalrec*)&allocp[41];
  allocp[47] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[48] = a0;
  allocp[49] = x10 = makeref(&allocp[49]);
  allocp[50] = x8;
  qp = (struct goalrec*)&allocp[46];
  allocp += 51;
  proceed();
 fix__mode__args_10_ext_interrupt:
  reasonp = 0l;
 fix__mode__args_10_interrupt:
  goto interrupt_10;
 }

 get__ds_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 get__ds_6_clear_reason:
  reasonp = reasons;
 get__ds_6_0:
 get__ds_6_1:
  if (!isint(a0)) goto get__ds_6_8;
  x0 = makeint(0L);
  gblt_greater(a0,x0,get__ds_6_9);
 get__ds_6_2:
  if (isref(a1)) goto get__ds_6_7;
  gblt_arg(a0,a1,x1,get__ds_6_9);
 get__ds_6_3:
  if (isref(x1)) goto get__ds_6_6;
  x3 = makeint(1L);
  gblt_arg(x3,x1,x2,get__ds_6_9);
 get__ds_6_4:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_goal_4)) goto get__ds_6_9;
  x5 = makeint(2L);
  gblt_arg(x5,x1,x4,get__ds_6_9);
 get__ds_6_5:
  switch (ptagof(x4)) {
 case FUNCTOR:
  if (functor_of(x4) != makesym(functor_variable_3)) goto get__ds_6_9;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xget__ds_6);
  allocp[2] = x6 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x7 = makeref(&allocp[4]);
  allocp[5] = x8 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[10] = a0;
  allocp[11] = makeint(1L);
  allocp[12] = x6;
  allocp[13] = x7;
  x10 = arg(x2, 1);
  allocp[14] = x10;
  x9 = makecons(&allocp[13]);
  qp = (struct goalrec*)&allocp[8];
  allocp += 15;
  unify_value(a2, x9);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_list_xor__unique_3);
  allocp[2] = a3;
  allocp[3] = x11 = makeref(&allocp[3]);
  allocp[4] = x8;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_typeset_xget__ds_5);
  x12 = arg(x2, 0);
  allocp[7] = x12;
  x13 = arg(x2, 1);
  allocp[8] = x13;
  x14 = arg(x4, 0);
  allocp[9] = x14;
  allocp[10] = x11;
  allocp[11] = a5;
  qp = (struct goalrec*)&allocp[5];
  allocp += 12;
  proceed();
 case VARREF:
  deref_and_jump(x4,get__ds_6_5);
  *reasonp++ =  x4;
  goto get__ds_6_9;
  };
  goto get__ds_6_9;
 case VARREF:
  deref_and_jump(x2,get__ds_6_4);
  *reasonp++ =  x2;
  goto get__ds_6_9;
  };
  goto get__ds_6_9;
 get__ds_6_6:
  deref_and_jump(x1,get__ds_6_3);
  *reasonp++ =  x1;
  goto get__ds_6_9;
 get__ds_6_7:
  deref_and_jump(a1,get__ds_6_2);
  *reasonp++ =  a1;
  goto get__ds_6_9;
 get__ds_6_8:
  if (!isref(a0)) goto get__ds_6_9;
  deref_and_jump(a0,get__ds_6_1);
  *reasonp++ =  a0;
  goto get__ds_6_9;
 get__ds_6_9:
  otherwise(get__ds_6_interrupt);
 get__ds_6_10:
  if (!isint(a0)) goto get__ds_6_12;
  x0 = makeint(0L);
  gblt_greater(a0,x0,get__ds_6_11);
  x1 = makeint(1L);
  bblt_sub_no_check(a0,x1,x2);
  a0 = x2;
  execute(get__ds_6_0);
  goto get__ds_6_ext_interrupt;
 get__ds_6_11:
  if (a0 != makeint(0L)) goto get__ds_6_interrupt;
  x3 = NILATOM;
  unify_value(a2, x3);
  unify(a4, a3);
  proceed();
 get__ds_6_12:
  if (!isref(a0)) goto get__ds_6_interrupt;
  deref_and_jump(a0,get__ds_6_10);
  *reasonp++ =  a0;
  goto get__ds_6_interrupt;
 get__ds_6_ext_interrupt:
  reasonp = 0l;
 get__ds_6_interrupt:
  goto interrupt_6;
 }

 remove__ds_3_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  qp = qp->next;
 remove__ds_3_clear_reason:
  reasonp = reasons;
 remove__ds_3_0:
 remove__ds_3_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 remove__ds_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_goal_4)) goto remove__ds_3_3;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_ganalyzer_xremove__ds2_5);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = x0;
  x2 = cdr_of(a1);
  allocp[5] = x2;
  allocp[6] = a2;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_list_xcheck__include_3);
  x3 = arg(x0, 1);
  allocp[9] = x3;
  allocp[10] = a0;
  allocp[11] = x1;
  qp = (struct goalrec*)&allocp[7];
  allocp += 12;
  proceed();
 case VARREF:
  deref_and_jump(x0,remove__ds_3_2);
  *reasonp++ =  x0;
  goto remove__ds_3_3;
  };
  goto remove__ds_3_3;
 case VARREF:
  deref_and_jump(a1,remove__ds_3_1);
  *reasonp++ =  a1;
  goto remove__ds_3_3;
  };
  goto remove__ds_3_3;
 remove__ds_3_3:
  otherwise(remove__ds_3_interrupt);
 remove__ds_3_4:
  switch (ptagof(a1)) {
 case CONS:
  a1 = cdr_of(a1);
  execute(remove__ds_3_0);
  goto remove__ds_3_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto remove__ds_3_interrupt;
  x0 = NILATOM;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,remove__ds_3_4);
  *reasonp++ =  a1;
  goto remove__ds_3_interrupt;
  };
  goto remove__ds_3_interrupt;
 remove__ds_3_ext_interrupt:
  reasonp = 0l;
 remove__ds_3_interrupt:
  toppred = &predicate_ganalyzer_xremove__ds_3;
  goto interrupt_3;
 }

 remove__ds2_5_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 remove__ds2_5_clear_reason:
  reasonp = reasons;
 remove__ds2_5_0:
 remove__ds2_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto remove__ds2_5_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = a2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a4, x0);
  a0 = a1;
  a1 = a3;
  a2 = x1;
  execute(remove__ds_3_0);
  goto remove__ds_3_ext_interrupt;
 case symval(makesym(atom_no)):
  a0 = a1;
  a1 = a3;
  a2 = a4;
  execute(remove__ds_3_0);
  goto remove__ds_3_ext_interrupt;
  };
  goto remove__ds2_5_interrupt;
 case VARREF:
  deref_and_jump(a0,remove__ds2_5_1);
  *reasonp++ =  a0;
  goto remove__ds2_5_interrupt;
  };
  goto remove__ds2_5_interrupt;
 remove__ds2_5_ext_interrupt:
  reasonp = 0l;
 remove__ds2_5_interrupt:
  goto interrupt_5;
 }

 get__new__mode_3_top: {
  q x0;
  a2 = qp->args[2];
  qp = qp->next;
 get__new__mode_3_clear_reason:
  reasonp = reasons;
 get__new__mode_3_0:
 get__new__mode_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != NILATOM) goto get__new__mode_3_2;
  x0 = makesym(atom_i);
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,get__new__mode_3_1);
  *reasonp++ =  a0;
  goto get__new__mode_3_2;
  };
  goto get__new__mode_3_2;
 get__new__mode_3_2:
  otherwise(get__new__mode_3_interrupt);
 get__new__mode_3_3:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != NILATOM) goto get__new__mode_3_interrupt;
  x0 = makesym(atom_o);
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,get__new__mode_3_3);
  *reasonp++ =  a1;
  goto get__new__mode_3_interrupt;
  };
  goto get__new__mode_3_interrupt;
 get__new__mode_3_ext_interrupt:
  reasonp = 0l;
 get__new__mode_3_interrupt:
  goto interrupt_3;
 }
 interrupt_21:
  allocp[22] = a20;
 interrupt_20:
  allocp[21] = a19;
 interrupt_19:
  allocp[20] = a18;
 interrupt_18:
  allocp[19] = a17;
 interrupt_17:
  allocp[18] = a16;
 interrupt_16:
  allocp[17] = a15;
 interrupt_15:
  allocp[16] = a14;
 interrupt_14:
  allocp[15] = a13;
 interrupt_13:
  allocp[14] = a12;
 interrupt_12:
  allocp[13] = a11;
 interrupt_11:
  allocp[12] = a10;
 interrupt_10:
  allocp[11] = a9;
 interrupt_9:
  allocp[10] = a8;
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_ganalyzer);
}
