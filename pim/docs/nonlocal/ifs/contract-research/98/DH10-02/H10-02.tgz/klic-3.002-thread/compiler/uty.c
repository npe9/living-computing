/* Compiled by KLIC compiler version 3.002 (Wed Sep 17 15:37:13 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_uty();
Const struct predicate predicate_uty_xmax_3 =
   { module_uty, 0, 3 };

module module_uty(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  q a0, a1, a2;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  switch_on_pred() {
    last_case_pred(0, max_3_top);
  }

 max_3_top: {
  qp = qp->next;
 max_3_clear_reason:
  reasonp = reasons;
 max_3_0:
 max_3_1:
  if (!isint(a0)) goto max_3_5;
 max_3_2:
  if (!isint(a1)) goto max_3_4;
  gblt_greater_or_eq(a0,a1,max_3_3);
  unify_value(a2, a0);
  proceed();
 max_3_3:
  gblt_less(a0,a1,max_3_interrupt);
  unify_value(a2, a1);
  proceed();
 max_3_4:
  if (!isref(a1)) goto max_3_interrupt;
  deref_and_jump(a1,max_3_2);
  *reasonp++ =  a1;
  goto max_3_interrupt;
 max_3_5:
  if (!isref(a0)) goto max_3_interrupt;
  deref_and_jump(a0,max_3_1);
  *reasonp++ =  a0;
  goto max_3_interrupt;
 max_3_ext_interrupt:
  reasonp = 0l;
 max_3_interrupt:
  goto interrupt_3;
 }
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_uty);
}
