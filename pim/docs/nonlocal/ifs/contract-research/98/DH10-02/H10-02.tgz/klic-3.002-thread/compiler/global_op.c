/* Compiled by KLIC compiler version 3.002 (Wed Sep 17 15:37:13 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_global__op();
Const struct predicate predicate_global__op_xread__aifiles_8 =
   { module_global__op, 0, 8 };
Const struct predicate predicate_global__op_xread__aifiles_15 =
   { module_global__op, 1, 15 };
Const struct predicate predicate_global__op_xread__aifiles_2F15_240_4 =
   { module_global__op, 2, 4 };
Const struct predicate predicate_global__op_xread__aifiles__2_16 =
   { module_global__op, 3, 16 };
Const struct predicate predicate_global__op_xmake__mf__entry_3 =
   { module_global__op, 4, 3 };
Const struct predicate predicate_global__op_xwrite__ai1_5 =
   { module_global__op, 5, 5 };
Const struct predicate predicate_global__op_xwrite__ai1_6 =
   { module_global__op, 6, 6 };
Const struct predicate predicate_global__op_xget__fileno_3 =
   { module_global__op, 7, 3 };
Const struct predicate predicate_global__op_xfileno_3 =
   { module_global__op, 8, 3 };
Const struct predicate predicate_global__op_xfileno2_4 =
   { module_global__op, 9, 4 };
Const struct predicate predicate_global__op_xget__localfile_4 =
   { module_global__op, 10, 4 };
Const struct predicate predicate_global__op_xfunc2list_2 =
   { module_global__op, 11, 2 };
Const struct predicate predicate_global__op_xfunc2list2_5 =
   { module_global__op, 12, 5 };
Const struct predicate predicate_global__op_xread__ts_6 =
   { module_global__op, 13, 6 };
Const struct predicate predicate_global__op_xwrite__ts_7 =
   { module_global__op, 14, 7 };
Const struct predicate predicate_global__op_xread__mode_7 =
   { module_global__op, 15, 7 };
Const struct predicate predicate_global__op_xwrite__mode_8 =
   { module_global__op, 16, 8 };
extern Const struct predicate predicate_list_xappend_3;
extern Const struct predicate predicate_functor_xinsert__arg_4;
extern Const struct predicate predicate_integer__arithmetics_xadd_3;
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_xsetarg_4;
extern Const struct predicate predicate_functor__table_xfunctor_3;
extern Const struct predicate predicate_file__op_xread__ai_6;
extern Const struct predicate predicate_file__op_xmake__ai1_5;
extern Const struct predicate predicate_typeset_xget__arg__typeset_5;
extern Const struct predicate predicate_vt_xwrite__ts_6;
extern Const struct predicate predicate_hb_xread__mode_6;
extern Const struct predicate predicate_hb_xwrite__mode_7;

module module_global__op(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  declare_method_table_of(byte__string);
  static Const string_structure_type_8 string_const_0 =
      declare_string_constant_8(0,0);
  q a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, read__aifiles_8_top);
    case_pred(1, read__aifiles_15_top);
    case_pred(2, read__aifiles_2F15_240_4_top);
    case_pred(3, read__aifiles__2_16_top);
    case_pred(4, make__mf__entry_3_top);
    case_pred(5, write__ai1_5_top);
    case_pred(6, write__ai1_6_top);
    case_pred(7, get__fileno_3_top);
    case_pred(8, fileno_3_top);
    case_pred(9, fileno2_4_top);
    case_pred(10, get__localfile_4_top);
    case_pred(11, func2list_2_top);
    case_pred(12, func2list2_5_top);
    case_pred(13, read__ts_6_top);
    case_pred(14, write__ts_7_top);
    case_pred(15, read__mode_7_top);
    last_case_pred(16, write__mode_8_top);
  }

 read__aifiles_8_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 read__aifiles_8_clear_reason:
  reasonp = reasons;
 read__aifiles_8_0:
 read__aifiles_8_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != NILATOM) goto read__aifiles_8_2;
  x0 = makesym(atom_gvt);
  unify_value(a2, x0);
  x1 = makesym(atom_ghb);
  unify_value(a3, x1);
  x2 = makesym(atom_eas);
  unify_value(a4, x2);
  x3 = makesym(atom_glt);
  unify_value(a5, x3);
  x4 = makesym(atom_filename);
  unify_value(a6, x4);
  x5 = NILATOM;
  unify_value(a7, x5);
  proceed();
 case VARREF:
  deref_and_jump(a1,read__aifiles_8_1);
  *reasonp++ =  a1;
  goto read__aifiles_8_2;
  };
  goto read__aifiles_8_2;
 read__aifiles_8_2:
  otherwise(read__aifiles_8_interrupt);
  x0 = a1;
  x1 = a2;
  x2 = a3;
  a8 = a4;
  a9 = makesym(atom_glt);
  a10 = a5;
  a11 = makesym(atom_filename);
  a12 = a6;
  a13 = NILATOM;
  a14 = a7;
  a7 = makesym(atom_eas);
  a6 = x2;
  a5 = makesym(atom_ghb);
  a4 = x1;
  a3 = makesym(atom_gvt);
  a2 = x0;
  a1 = makeint(1L);
  execute(read__aifiles_15_0);
  goto read__aifiles_15_ext_interrupt;
 read__aifiles_8_ext_interrupt:
  reasonp = 0l;
 read__aifiles_8_interrupt:
  goto interrupt_8;
 }

 read__aifiles_15_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  qp = qp->next;
 read__aifiles_15_clear_reason:
  reasonp = reasons;
 read__aifiles_15_0:
 read__aifiles_15_1:
  switch (ptagof(a2)) {
 case CONS:
  x0 = car_of(a2);
 read__aifiles_15_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
 read__aifiles_15_3:
  if (!isgobj(x0)) goto read__aifiles_15_interrupt;
 read__aifiles_15_4:
  gblt_is_string(x0,read__aifiles_15_interrupt);
  gblt_size_of_string(x0,x1,read__aifiles_15_interrupt);
  gblt_element_size_of_string(x0,x2,read__aifiles_15_interrupt);
  x3 = makeint(1L);
  bblt_sub_no_check(x1,x3,x4);
  generic_arg[0] = x4;
  x5 = makeint(1L);
  generic_arg[1] = x5;
  x6 = makeint(46L);
  generic_arg[2] = x6;
  allocp[0] = x7 = makeref(&allocp[0]);
  generic_arg[3] = x7;
  call_generic(x0, functor_search__character_4, 1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_global__op_xread__aifiles_15);
  allocp[2] = a0;
  allocp[3] = x8 = makeref(&allocp[3]);
  x9 = cdr_of(a2);
  allocp[4] = x9;
  allocp[5] = x10 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x11 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = x12 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = x13 = makeref(&allocp[11]);
  allocp[12] = a10;
  allocp[13] = x14 = makeref(&allocp[13]);
  allocp[14] = a12;
  allocp[15] = x15 = makeref(&allocp[15]);
  allocp[16] = a14;
  allocp[17] = (q)(struct goalrec*)&allocp[0];
  allocp[18] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[19] = a1;
  allocp[20] = makeint(1L);
  allocp[21] = x8;
  allocp[22] = (q)(struct goalrec*)&allocp[17];
  allocp[23] = (q)(&predicate_global__op_xread__aifiles__2_16);
  allocp[24] = a0;
  allocp[25] = a1;
  allocp[26] = x16 = makeref(&allocp[26]);
  allocp[27] = x17 = makeref(&allocp[27]);
  allocp[28] = a3;
  allocp[29] = x10;
  allocp[30] = a5;
  allocp[31] = x11;
  allocp[32] = a7;
  allocp[33] = x12;
  allocp[34] = a9;
  allocp[35] = x13;
  allocp[36] = a11;
  allocp[37] = x14;
  allocp[38] = a13;
  allocp[39] = x15;
  a0 = x7;
  a1 = x0;
  a2 = x16;
  a3 = x17;
  qp = (struct goalrec*)&allocp[22];
  allocp += 40;
  execute(read__aifiles_2F15_240_4_0);
  goto read__aifiles_2F15_240_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,read__aifiles_15_2);
  *reasonp++ =  x0;
  goto read__aifiles_15_interrupt;
  };
  goto read__aifiles_15_interrupt;
 case ATOMIC:
  if (a2 != NILATOM) goto read__aifiles_15_interrupt;
  unify4(a4, a3, a6, a5, a8, a7, a10, a9);
  unify2(a12, a11, a14, a13);
  proceed();
 case VARREF:
  deref_and_jump(a2,read__aifiles_15_1);
  *reasonp++ =  a2;
  goto read__aifiles_15_interrupt;
  };
  goto read__aifiles_15_interrupt;
 read__aifiles_15_ext_interrupt:
  reasonp = 0l;
 read__aifiles_15_interrupt:
  toppred = &predicate_global__op_xread__aifiles_15;
  goto interrupt_15;
 }

 read__aifiles_2F15_240_4_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 read__aifiles_2F15_240_4_clear_reason:
  reasonp = reasons;
 read__aifiles_2F15_240_4_0:
 read__aifiles_2F15_240_4_1:
  if (!isint(a0)) goto read__aifiles_2F15_240_4_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,read__aifiles_2F15_240_4_2);
  generic_arg[0] = a0;
  generic_arg[1] = a2;
  generic_arg[2] = a3;
  call_generic(a1, functor_split_3, 0);
  proceed();
 read__aifiles_2F15_240_4_2:
  x1 = makeint(0L);
  gblt_less_or_eq(a0,x1,read__aifiles_2F15_240_4_interrupt);
  x2 = makefunctor(&string_const_0);
  unify_value(a3, x2);
  proceed();
 read__aifiles_2F15_240_4_3:
  if (!isref(a0)) goto read__aifiles_2F15_240_4_interrupt;
  deref_and_jump(a0,read__aifiles_2F15_240_4_1);
  *reasonp++ =  a0;
  goto read__aifiles_2F15_240_4_interrupt;
 read__aifiles_2F15_240_4_ext_interrupt:
  reasonp = 0l;
 read__aifiles_2F15_240_4_interrupt:
  toppred = &predicate_global__op_xread__aifiles_2F15_240_4;
  goto interrupt_4;
 }

 read__aifiles__2_16_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  qp = qp->next;
 read__aifiles__2_16_clear_reason:
  reasonp = reasons;
 read__aifiles__2_16_0:
 read__aifiles__2_16_1:
  if (isref(a0)) goto read__aifiles__2_16_4;
 read__aifiles__2_16_2:
  if (isref(a0)) goto read__aifiles__2_16_3;
  if_not_equal(a0, a3, read__aifiles__2_16_5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_list_xappend_3);
  allocp[2] = a14;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a15;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_global__op_xmake__mf__entry_3);
  allocp[7] = a1;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x0;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor_xinsert__arg_4);
  allocp[12] = a1;
  allocp[13] = a12;
  allocp[14] = a2;
  allocp[15] = a13;
  allocp[16] = (q)(struct goalrec*)&allocp[10];
  allocp[17] = (q)(&predicate_functor_xinsert__arg_4);
  allocp[18] = a1;
  allocp[19] = a10;
  allocp[20] = x2 = makeref(&allocp[20]);
  allocp[21] = a11;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_functor_xinsert__arg_4);
  allocp[24] = a1;
  allocp[25] = a8;
  allocp[26] = x3 = makeref(&allocp[26]);
  allocp[27] = a9;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_functor_xinsert__arg_4);
  allocp[30] = a1;
  allocp[31] = a6;
  allocp[32] = x4 = makeref(&allocp[32]);
  allocp[33] = a7;
  allocp[34] = (q)(struct goalrec*)&allocp[28];
  allocp[35] = (q)(&predicate_functor_xinsert__arg_4);
  allocp[36] = a1;
  allocp[37] = a4;
  allocp[38] = x1;
  allocp[39] = a5;
  allocp[40] = (q)(struct goalrec*)&allocp[34];
  allocp[41] = (q)(&predicate_file__op_xread__ai_6);
  allocp[42] = a2;
  allocp[43] = a0;
  allocp[44] = x1;
  allocp[45] = x4;
  allocp[46] = x3;
  allocp[47] = x2;
  qp = (struct goalrec*)&allocp[40];
  allocp += 48;
  proceed();
 read__aifiles__2_16_3:
  deref_and_jump(a0,read__aifiles__2_16_2);
  *reasonp++ =  a0;
  goto read__aifiles__2_16_5;
 read__aifiles__2_16_4:
  deref_and_jump(a0,read__aifiles__2_16_1);
  *reasonp++ =  a0;
  goto read__aifiles__2_16_5;
 read__aifiles__2_16_5:
  otherwise(read__aifiles__2_16_interrupt);
  x0 = makesym(atom_error);
  x1 = makesym(atom_read__aifiles__2);
  unify(x0, x1);
  proceed();
 read__aifiles__2_16_ext_interrupt:
  reasonp = 0l;
 read__aifiles__2_16_interrupt:
  goto interrupt_16;
 }

 make__mf__entry_3_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  qp = qp->next;
 make__mf__entry_3_clear_reason:
  reasonp = reasons;
 make__mf__entry_3_0:
 make__mf__entry_3_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 make__mf__entry_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_module_2)) goto make__mf__entry_3_interrupt;
  allocp[0] = makesym(functor_entry_2);
  x2 = arg(x0, 0);
  allocp[1] = x2;
  allocp[2] = a0;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = x4 = makeref(&allocp[3]);
  allocp[4] = x1;
  x3 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a2, x3);
  a1 = cdr_of(a1);
  a2 = x4;
  execute(make__mf__entry_3_0);
  goto make__mf__entry_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,make__mf__entry_3_2);
  *reasonp++ =  x0;
  goto make__mf__entry_3_interrupt;
  };
  goto make__mf__entry_3_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto make__mf__entry_3_interrupt;
  x0 = NILATOM;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,make__mf__entry_3_1);
  *reasonp++ =  a1;
  goto make__mf__entry_3_interrupt;
  };
  goto make__mf__entry_3_interrupt;
 make__mf__entry_3_ext_interrupt:
  reasonp = 0l;
 make__mf__entry_3_interrupt:
  goto interrupt_3;
 }

 write__ai1_5_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 write__ai1_5_clear_reason:
  reasonp = reasons;
 write__ai1_5_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_global__op_xwrite__ai1_6);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[10] = a4;
  allocp[11] = x1 = makeref(&allocp[11]);
  allocp[12] = x0;
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  proceed();
 write__ai1_5_ext_interrupt:
  reasonp = 0l;
 write__ai1_5_interrupt:
  goto interrupt_5;
 }

 write__ai1_6_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 write__ai1_6_clear_reason:
  reasonp = reasons;
 write__ai1_6_0:
 write__ai1_6_1:
  if (!isint(a0)) goto write__ai1_6_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,write__ai1_6_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_global__op_xwrite__ai1_6);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[10] = a0;
  allocp[11] = makeint(1L);
  allocp[12] = x1;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_file__op_xmake__ai1_5);
  allocp[15] = x2 = makeref(&allocp[15]);
  allocp[16] = x3 = makeref(&allocp[16]);
  allocp[17] = x4 = makeref(&allocp[17]);
  allocp[18] = x5 = makeref(&allocp[18]);
  allocp[19] = x6 = makeref(&allocp[19]);
  allocp[20] = (q)(struct goalrec*)&allocp[13];
  allocp[21] = (q)(&predicate_functor__table_xarg_3);
  allocp[22] = a0;
  allocp[23] = a4;
  allocp[24] = x6;
  allocp[25] = (q)(struct goalrec*)&allocp[20];
  allocp[26] = (q)(&predicate_functor__table_xarg_3);
  allocp[27] = a0;
  allocp[28] = a3;
  allocp[29] = x5;
  allocp[30] = (q)(struct goalrec*)&allocp[25];
  allocp[31] = (q)(&predicate_functor__table_xarg_3);
  allocp[32] = a0;
  allocp[33] = a2;
  allocp[34] = x4;
  allocp[35] = (q)(struct goalrec*)&allocp[30];
  allocp[36] = (q)(&predicate_functor__table_xarg_3);
  allocp[37] = a0;
  allocp[38] = a1;
  allocp[39] = x3;
  allocp[40] = (q)(struct goalrec*)&allocp[35];
  allocp[41] = (q)(&predicate_functor__table_xarg_3);
  allocp[42] = a0;
  allocp[43] = a5;
  allocp[44] = x2;
  qp = (struct goalrec*)&allocp[40];
  allocp += 45;
  proceed();
 write__ai1_6_2:
  if (a0 != makeint(0L)) goto write__ai1_6_interrupt;
  proceed();
 write__ai1_6_3:
  if (!isref(a0)) goto write__ai1_6_interrupt;
  deref_and_jump(a0,write__ai1_6_1);
  *reasonp++ =  a0;
  goto write__ai1_6_interrupt;
 write__ai1_6_ext_interrupt:
  reasonp = 0l;
 write__ai1_6_interrupt:
  goto interrupt_6;
 }

 get__fileno_3_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  qp = qp->next;
 get__fileno_3_clear_reason:
  reasonp = reasons;
 get__fileno_3_0:
 get__fileno_3_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 get__fileno_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_entry_2)) goto get__fileno_3_7;
  x1 = arg(x0, 0);
 get__fileno_3_3:
  if (isref(x1)) goto get__fileno_3_6;
 get__fileno_3_4:
  if (isref(x1)) goto get__fileno_3_5;
  if_not_equal(x1, a0, get__fileno_3_7);
  x2 = arg(x0, 1);
  unify(a2, x2);
  proceed();
 get__fileno_3_5:
  deref_and_jump(x1,get__fileno_3_4);
  *reasonp++ =  x1;
  goto get__fileno_3_7;
 get__fileno_3_6:
  deref_and_jump(x1,get__fileno_3_3);
  *reasonp++ =  x1;
  goto get__fileno_3_7;
 case VARREF:
  deref_and_jump(x0,get__fileno_3_2);
  *reasonp++ =  x0;
  goto get__fileno_3_7;
  };
  goto get__fileno_3_7;
 case VARREF:
  deref_and_jump(a1,get__fileno_3_1);
  *reasonp++ =  a1;
  goto get__fileno_3_7;
  };
  goto get__fileno_3_7;
 get__fileno_3_7:
  otherwise(get__fileno_3_interrupt);
 get__fileno_3_8:
  switch (ptagof(a1)) {
 case CONS:
  a1 = cdr_of(a1);
  execute(get__fileno_3_0);
  goto get__fileno_3_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto get__fileno_3_interrupt;
  x0 = makesym(atom_error);
  x1 = makesym(atom_get__fileno);
  unify(x0, x1);
  proceed();
 case VARREF:
  deref_and_jump(a1,get__fileno_3_8);
  *reasonp++ =  a1;
  goto get__fileno_3_interrupt;
  };
  goto get__fileno_3_interrupt;
 get__fileno_3_ext_interrupt:
  reasonp = 0l;
 get__fileno_3_interrupt:
  toppred = &predicate_global__op_xget__fileno_3;
  goto interrupt_3;
 }

 fileno_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 fileno_3_clear_reason:
  reasonp = reasons;
 fileno_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_global__op_xfileno2_4);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = a2;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[8] = a1;
  allocp[9] = x1 = makeref(&allocp[9]);
  allocp[10] = x0;
  qp = (struct goalrec*)&allocp[6];
  allocp += 11;
  proceed();
 fileno_3_ext_interrupt:
  reasonp = 0l;
 fileno_3_interrupt:
  toppred = &predicate_global__op_xfileno_3;
  goto interrupt_3;
 }

 fileno2_4_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 fileno2_4_clear_reason:
  reasonp = reasons;
 fileno2_4_0:
 fileno2_4_1:
  if (!isint(a2)) goto fileno2_4_8;
 fileno2_4_2:
  if (isref(a1)) goto fileno2_4_7;
  gblt_arg(a2,a1,x0,fileno2_4_9);
 fileno2_4_3:
  if (isref(x0)) goto fileno2_4_6;
 fileno2_4_4:
  if (isref(x0)) goto fileno2_4_5;
  if_not_equal(x0, a0, fileno2_4_9);
  unify_value(a3, a2);
  proceed();
 fileno2_4_5:
  deref_and_jump(x0,fileno2_4_4);
  *reasonp++ =  x0;
  goto fileno2_4_9;
 fileno2_4_6:
  deref_and_jump(x0,fileno2_4_3);
  *reasonp++ =  x0;
  goto fileno2_4_9;
 fileno2_4_7:
  deref_and_jump(a1,fileno2_4_2);
  *reasonp++ =  a1;
  goto fileno2_4_9;
 fileno2_4_8:
  if (!isref(a2)) goto fileno2_4_9;
  deref_and_jump(a2,fileno2_4_1);
  *reasonp++ =  a2;
  goto fileno2_4_9;
 fileno2_4_9:
  otherwise(fileno2_4_interrupt);
 fileno2_4_10:
  if (!isint(a2)) goto fileno2_4_12;
  x0 = makeint(0L);
  gblt_greater(a2,x0,fileno2_4_11);
  x1 = makeint(1L);
  bblt_sub_no_check(a2,x1,x2);
  a2 = x2;
  execute(fileno2_4_0);
  goto fileno2_4_ext_interrupt;
 fileno2_4_11:
  if (a2 != makeint(0L)) goto fileno2_4_interrupt;
  x3 = makesym(atom_error);
  x4 = makesym(atom_fileno2);
  unify(x3, x4);
  proceed();
 fileno2_4_12:
  if (!isref(a2)) goto fileno2_4_interrupt;
  deref_and_jump(a2,fileno2_4_10);
  *reasonp++ =  a2;
  goto fileno2_4_interrupt;
 fileno2_4_ext_interrupt:
  reasonp = 0l;
 fileno2_4_interrupt:
  goto interrupt_4;
 }

 get__localfile_4_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 get__localfile_4_clear_reason:
  reasonp = reasons;
 get__localfile_4_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a2;
  allocp[4] = a3;
  a2 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(fileno_3_0);
  goto fileno_3_ext_interrupt;
 get__localfile_4_ext_interrupt:
  reasonp = 0l;
 get__localfile_4_interrupt:
  goto interrupt_4;
 }

 func2list_2_top: {
  q x0, x1;
  qp = qp->next;
 func2list_2_clear_reason:
  reasonp = reasons;
 func2list_2_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_global__op_xfunc2list2_5);
  allocp[2] = makeint(1L);
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a0;
  allocp[5] = NILATOM;
  allocp[6] = a1;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[9] = a0;
  allocp[10] = x1 = makeref(&allocp[10]);
  allocp[11] = x0;
  qp = (struct goalrec*)&allocp[7];
  allocp += 12;
  proceed();
 func2list_2_ext_interrupt:
  reasonp = 0l;
 func2list_2_interrupt:
  goto interrupt_2;
 }

 func2list2_5_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 func2list2_5_clear_reason:
  reasonp = reasons;
 func2list2_5_0:
 func2list2_5_1:
  if (!isint(a0)) goto func2list2_5_5;
 func2list2_5_2:
  if (!isint(a1)) goto func2list2_5_4;
  gblt_less_or_eq(a0,a1,func2list2_5_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_global__op_xfunc2list2_5);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[9] = a0;
  allocp[10] = makeint(1L);
  allocp[11] = x0;
  allocp[12] = (q)(struct goalrec*)&allocp[7];
  allocp[13] = (q)(&predicate_list_xappend_3);
  allocp[14] = a3;
  allocp[15] = x2 = makeref(&allocp[15]);
  allocp[16] = x1;
  allocp[17] = (q)(struct goalrec*)&allocp[12];
  allocp[18] = (q)(&predicate_functor__table_xarg_3);
  allocp[19] = a0;
  allocp[20] = a2;
  allocp[21] = x2;
  qp = (struct goalrec*)&allocp[17];
  allocp += 22;
  proceed();
 func2list2_5_3:
  gblt_greater(a0,a1,func2list2_5_interrupt);
  unify(a4, a3);
  proceed();
 func2list2_5_4:
  if (!isref(a1)) goto func2list2_5_interrupt;
  deref_and_jump(a1,func2list2_5_2);
  *reasonp++ =  a1;
  goto func2list2_5_interrupt;
 func2list2_5_5:
  if (!isref(a0)) goto func2list2_5_interrupt;
  deref_and_jump(a0,func2list2_5_1);
  *reasonp++ =  a0;
  goto func2list2_5_interrupt;
 func2list2_5_ext_interrupt:
  reasonp = 0l;
 func2list2_5_interrupt:
  goto interrupt_5;
 }

 read__ts_6_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 read__ts_6_clear_reason:
  reasonp = reasons;
 read__ts_6_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xget__arg__typeset_5);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x0 = makeref(&allocp[5]);
  allocp[6] = a5;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_functor__table_xarg_3);
  allocp[9] = x1 = makeref(&allocp[9]);
  allocp[10] = a4;
  allocp[11] = x0;
  a1 = a3;
  a2 = x1;
  qp = (struct goalrec*)&allocp[7];
  allocp += 12;
  execute(get__fileno_3_0);
  goto get__fileno_3_ext_interrupt;
 read__ts_6_ext_interrupt:
  reasonp = 0l;
 read__ts_6_interrupt:
  goto interrupt_6;
 }

 write__ts_7_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 write__ts_7_clear_reason:
  reasonp = reasons;
 write__ts_7_0:
 write__ts_7_1:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_variable_3)) goto write__ts_7_2;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a5;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a6;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_vt_xwrite__ts_6);
  allocp[8] = a0;
  allocp[9] = a1;
  x2 = arg(a2, 0);
  allocp[10] = x2;
  allocp[11] = a3;
  allocp[12] = x3 = makeref(&allocp[12]);
  allocp[13] = x1;
  allocp[14] = (q)(struct goalrec*)&allocp[6];
  allocp[15] = (q)(&predicate_functor__table_xarg_3);
  allocp[16] = x0;
  allocp[17] = a5;
  allocp[18] = x3;
  a1 = a4;
  a2 = x0;
  qp = (struct goalrec*)&allocp[14];
  allocp += 19;
  execute(get__fileno_3_0);
  goto get__fileno_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,write__ts_7_1);
  *reasonp++ =  a2;
  goto write__ts_7_2;
  };
  goto write__ts_7_2;
 write__ts_7_2:
  otherwise(write__ts_7_interrupt);
  unify(a6, a5);
  proceed();
 write__ts_7_ext_interrupt:
  reasonp = 0l;
 write__ts_7_interrupt:
  goto interrupt_7;
 }

 read__mode_7_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 read__mode_7_clear_reason:
  reasonp = reasons;
 read__mode_7_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_hb_xread__mode_6);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x0 = makeref(&allocp[7]);
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_functor__table_xarg_3);
  allocp[10] = x1 = makeref(&allocp[10]);
  allocp[11] = a6;
  allocp[12] = x0;
  a1 = a5;
  a2 = x1;
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  execute(get__fileno_3_0);
  goto get__fileno_3_ext_interrupt;
 read__mode_7_ext_interrupt:
  reasonp = 0l;
 read__mode_7_interrupt:
  goto interrupt_7;
 }

 write__mode_8_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 write__mode_8_clear_reason:
  reasonp = reasons;
 write__mode_8_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a6;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a7;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_hb_xwrite__mode_7);
  allocp[8] = a0;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  allocp[12] = a4;
  allocp[13] = x2 = makeref(&allocp[13]);
  allocp[14] = x1;
  allocp[15] = (q)(struct goalrec*)&allocp[6];
  allocp[16] = (q)(&predicate_functor__table_xarg_3);
  allocp[17] = x0;
  allocp[18] = a6;
  allocp[19] = x2;
  a1 = a5;
  a2 = x0;
  qp = (struct goalrec*)&allocp[15];
  allocp += 20;
  execute(get__fileno_3_0);
  goto get__fileno_3_ext_interrupt;
 write__mode_8_ext_interrupt:
  reasonp = 0l;
 write__mode_8_interrupt:
  goto interrupt_8;
 }
 interrupt_16:
  allocp[17] = a15;
 interrupt_15:
  allocp[16] = a14;
 interrupt_14:
  allocp[15] = a13;
 interrupt_13:
  allocp[14] = a12;
 interrupt_12:
  allocp[13] = a11;
 interrupt_11:
  allocp[12] = a10;
 interrupt_10:
  allocp[11] = a9;
 interrupt_9:
  allocp[10] = a8;
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_global__op);
}
