/* ----------------------------------------------------------
%                        Copyright (C) 1999
%               Hiroshi Nakashima, Kazuhiko Ohno
%              Namiyo Sugiyama, Kiyokazu Yokoishi
%        and Department of Information and Computer Sciences 
%                 Toyohashi University of Technology
%----------------------------------------------------------- */  

/* ----------------------------------------------------------
%                        Copyright (C) 1998
%        Hiroshi Nakashima, Kazuhiko Ohno, Namiyo Sugiyama,
%        and Department of Information and Computer Sciences 
%                 Toyohashi University of Technology
%----------------------------------------------------------- */  

#define KTH_READ
/*
  The following #define should be commented out (or deleted) for final
  version 
*/
/*
#define KTH_DEBUG
*/
#ifdef  KTH_DEBUG
#define KTH_printf(A) printf A
#else
#define KTH_printf(A)
#endif

#define KTH_THREAD_TABLE_SIZE 32
#define KTH_STACK_MARGIN      32
#define KTH_STACK_SIZE        64
#define KTH_STACK_SIZE2       64
extern q *KTH_do_unify();

struct KTH_thread_table_entry {
  q* stack_top;
  q* stackp;
  q* slimit;
  int prev;
  int next;
  int stack_state;
};



#define KTH_declare_external \
extern Const struct predicate KTH_continue_thread_pred; \
extern Const struct predicate KTH_terminate_thread_pred; \
extern Const struct predicate KTH_create_thread_pred;\
extern Const struct predicate predicate_main_xcall__native_0


#define KTH_declare_local \
q* stackp = KTH_current_stackp; \
q* slimit = KTH_current_slimit; \
module (*func)()


/* org code
#define KTH_declare_local \
q* stackp = KTH_current_stackp; \
q* slimit = KTH_current_slimit; \
*/


#define KTH_execute(label) \
{ \
  if (allocp < heaplimit && stackp < slimit) goto label; \
}
/*
#define KTH_within_stack(s) \
    ((unsigned long)(s) - (unsigned long)heaptop >= \
     (unsigned long)real_heapbytesize) \
*/

#define KTH_within_stack(s) \
    (((unsigned long)(s) < (unsigned long)heaptop)\
     ||\
     ((unsigned long)heapbottom) <\
      (unsigned long)(s))\

/*
#define KTH_confirm_non_stack_var(x, h)\
{\
  if (isref(x) && KTH_within_stack(x)) {\
    if (x == *((q*)x)) {\
      *((q*)x) = h = makeref(&h);\
                      }\
    else {\
      h = *((q*)x);\
      x = h;\
    }\
  }\
  else {\
    h = x;\
  }\
}
*/
#define KTH_confirm_non_stack_var(x, h)\
{\
  if (isref(x) && KTH_within_stack(x)) {\
    if (x == *((q*)x)) {\
      *((q*)x) = h = makeref(&h);\
                      }\
    else {\
      h = *((q*)x);\
    }\
  }\
  else {\
    h = x;\
  }\
}


#define KTH_unify(x, y) \
{ allocp = KTH_do_unify(allocp, (x), (y)); }



/* for running thread first (KTH_interrupt_goal ,KTH_loop_within_module) */

#define KTH_interrupt_goal() \
{ \
    int thid = KTH_current_thread; \
    stackp += toppred->arity + 1; \
    stackp[-1] = (q)toppred; \
    allocp[2] = makeint(thid); \
    KTH_thread_table[thid].stackp = KTH_current_stackp =stackp; \
    allocp = interrupt_goal(allocp, &KTH_continue_thread_pred, reasonp); \
}\
 interrupt_exit_label: {\
  int thid = KTH_current_thread; \
  KTH_thread_table[thid].stackp = stackp; \
  allocp = klic_interrupt(allocp, qp); \
  qp = current_queue;\
  if (stackp >= slimit) \
    KTH_extend_stack();        \
  stackp = (q*)0; \
  func = qp->pred->func; \
  goto module_exit_label; \
}


#define KTH_loop_within_module(f) \
{ \
    if (allocp >= heaplimit) {\
      int thid = KTH_current_thread; \
      qp = (struct goalrec*)enqueue_resumed_goals(qp); \
      allocp[0] = (q)qp; \
      allocp[1] = (q)(&KTH_continue_thread_pred); \
      allocp[2] = makeint(thid); \
      qp = (struct goalrec*)&allocp[0]; \
      allocp += 3; \
      goto interrupt_exit_label;\
    } \
    toppred = (struct predicate*)stackp[-1]; \
    if ((func = toppred->func) == (f)) goto module_top; \
} \
 module_exit_label: {\
  heapp = allocp; \
  current_queue = qp; \
  KTH_current_stackp = stackp; \
  return (module)(func);\
}


/* for resumption first */

/*
#define KTH_interrupt_goal() \
{ \
    int thid = KTH_current_thread; \
    stackp += toppred->arity + 1; \
    stackp[-1] = (q)toppred; \
    allocp[2] = makeint(thid); \
    KTH_thread_table[thid].stackp = KTH_current_stackp =stackp; \
    if (stackp > slimit) KTH_extend_stack(); \
    stackp = (q*)0; \
    allocp = interrupt_goal(allocp, &KTH_continue_thread_pred, reasonp); \
} 

#define KTH_loop_within_module(f) \
{ \
    module (*func)(); \
    if (allocp >= heaplimit) {\
       if (stackp != (q*)0) {\
	  int thid = KTH_current_thread; \
	  allocp[0] = (q)qp; \
	  allocp[1] = (q)(&KTH_continue_thread_pred); \
	  allocp[2] = makeint(thid); \
	  qp = (struct goalrec*)&allocp[0]; \
	  allocp += 3; \
	  KTH_thread_table[thid].stackp = KTH_current_stackp=stackp; \
	  stackp = (q*)0; \
       } \
       allocp = klic_interrupt(allocp, qp); \
       qp = current_queue; \
    } \
    if (stackp != (q*)0) {\
       toppred = (struct predicate*)stackp[-1]; \
       if ((func = toppred->func) == (f)) goto module_top; \
    } \
    else { \
	func = qp->pred->func; \
    } \
    heapp = allocp; \
    current_queue = qp; \
    KTH_current_stackp = stackp; \
    return (module)(func); \
}
*/

#define KTH_proceed()    \
{   \
      int thid = KTH_current_thread; \
      allocp[0] = (q)qp->next; \
      allocp[1] = (q)(&KTH_continue_thread_pred); \
      allocp[2] = makeint(thid); \
      qp->next = (struct goalrec*)&allocp[0]; \
      allocp += 3; \
      goto interrupt_exit_label;\
  }

/*
#define KTH_userdef_proceed() \
{ \
    allocp[0] = (q)qp; \
    allocp[1] = stackp[-1]; \
    allocp[2] = (q)stackp; \
    qp = (struct goalrec*)&allocp[0]; \
    allocp += 3; \
printf("KTH_userdef_proceed\n"); \
    goto interrupt_exit_label; \
}
*/
