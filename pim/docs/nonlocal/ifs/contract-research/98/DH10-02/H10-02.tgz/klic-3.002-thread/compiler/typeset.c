/* Compiled by KLIC compiler version 3.002 (Wed Sep 17 15:37:13 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"
extern q opt_trace_atom_value;
extern q opt_analyze_dependency;

module module_typeset();
Const struct predicate predicate_typeset_xor__typeset_3 =
   { module_typeset, 0, 3 };
Const struct predicate predicate_typeset_xor__typeset2_3 =
   { module_typeset, 1, 3 };
Const struct predicate predicate_typeset_xor__typeset3_6 =
   { module_typeset, 2, 6 };
Const struct predicate predicate_typeset_xor__type_4 =
   { module_typeset, 3, 4 };
Const struct predicate predicate_typeset_xor__structtype_4 =
   { module_typeset, 4, 4 };
Const struct predicate predicate_typeset_xor__structtype2_7 =
   { module_typeset, 5, 7 };
Const struct predicate predicate_typeset_xor__args_4 =
   { module_typeset, 6, 4 };
Const struct predicate predicate_typeset_xor__argslist_4 =
   { module_typeset, 7, 4 };
Const struct predicate predicate_typeset_xunify__equal_10 =
   { module_typeset, 8, 10 };
Const struct predicate predicate_typeset_xunify__typeset_12 =
   { module_typeset, 9, 12 };
Const struct predicate predicate_typeset_xunify_8 =
   { module_typeset, 10, 8 };
Const struct predicate predicate_typeset_xunify_10 =
   { module_typeset, 11, 10 };
Const struct predicate predicate_typeset_xunify2_10 =
   { module_typeset, 12, 10 };
Const struct predicate predicate_typeset_xunify__type_10 =
   { module_typeset, 13, 10 };
Const struct predicate predicate_typeset_xcondition1_11 =
   { module_typeset, 14, 11 };
Const struct predicate predicate_typeset_xcondition2_14 =
   { module_typeset, 15, 14 };
Const struct predicate predicate_typeset_xcondition3_12 =
   { module_typeset, 16, 12 };
Const struct predicate predicate_typeset_xunify__struct_9 =
   { module_typeset, 17, 9 };
Const struct predicate predicate_typeset_xentry__unifyset_4 =
   { module_typeset, 18, 4 };
Const struct predicate predicate_typeset_xentry__unifyset_6 =
   { module_typeset, 19, 6 };
Const struct predicate predicate_typeset_xadd__dgoals_4 =
   { module_typeset, 20, 4 };
Const struct predicate predicate_typeset_xadd__dgoal_4 =
   { module_typeset, 21, 4 };
Const struct predicate predicate_typeset_xadd__dgoal__struct_5 =
   { module_typeset, 22, 5 };
Const struct predicate predicate_typeset_xget__arg__typeset_5 =
   { module_typeset, 23, 5 };
Const struct predicate predicate_typeset_xget_5 =
   { module_typeset, 24, 5 };
Const struct predicate predicate_typeset_xset_12 =
   { module_typeset, 25, 12 };
Const struct predicate predicate_typeset_xset__type_12 =
   { module_typeset, 26, 12 };
Const struct predicate predicate_typeset_xset__type2_13 =
   { module_typeset, 27, 13 };
Const struct predicate predicate_typeset_xset__type3_13 =
   { module_typeset, 28, 13 };
Const struct predicate predicate_typeset_xcheck__normal__ts_2 =
   { module_typeset, 29, 2 };
Const struct predicate predicate_typeset_xdelete__ts_3 =
   { module_typeset, 30, 3 };
Const struct predicate predicate_typeset_xentry__update_10 =
   { module_typeset, 31, 10 };
Const struct predicate predicate_typeset_xvalue2typeset_5 =
   { module_typeset, 32, 5 };
Const struct predicate predicate_typeset_xvalue2typeset__functor_7 =
   { module_typeset, 33, 7 };
Const struct predicate predicate_typeset_xvalue2typeset__vector_7 =
   { module_typeset, 34, 7 };
Const struct predicate predicate_typeset_xtypeset2atom_2 =
   { module_typeset, 35, 2 };
Const struct predicate predicate_typeset_xtypeset2int_2 =
   { module_typeset, 36, 2 };
Const struct predicate predicate_typeset_xtypeset2list_2 =
   { module_typeset, 37, 2 };
Const struct predicate predicate_typeset_xtypeset2list1_2 =
   { module_typeset, 38, 2 };
Const struct predicate predicate_typeset_xtypeset2structtype_2 =
   { module_typeset, 39, 2 };
Const struct predicate predicate_typeset_xtypeset2structtype1_3 =
   { module_typeset, 40, 3 };
Const struct predicate predicate_typeset_xmerge__atomic_4 =
   { module_typeset, 41, 4 };
Const struct predicate predicate_typeset_xget__struct__arg__typeset_3 =
   { module_typeset, 42, 3 };
Const struct predicate predicate_typeset_xset__struct__arg__typeset_4 =
   { module_typeset, 43, 4 };
Const struct predicate predicate_typeset_xlisttype__val_3 =
   { module_typeset, 44, 3 };
Const struct predicate predicate_typeset_xlisttype__val1_4 =
   { module_typeset, 45, 4 };
Const struct predicate predicate_typeset_xlisttype__val2_4 =
   { module_typeset, 46, 4 };
Const struct predicate predicate_typeset_xlisttype__val__merge_3 =
   { module_typeset, 47, 3 };
Const struct predicate predicate_typeset_xlisttype__val__merge1_3 =
   { module_typeset, 48, 3 };
Const struct predicate predicate_typeset_xcheck__dg_4 =
   { module_typeset, 49, 4 };
Const struct predicate predicate_typeset_xcheck__dg2_5 =
   { module_typeset, 50, 5 };
Const struct predicate predicate_typeset_xremove__ds_2 =
   { module_typeset, 51, 2 };
Const struct predicate predicate_typeset_xremove__ds__struct_3 =
   { module_typeset, 52, 3 };
Const struct predicate predicate_typeset_xmake__shared__ts_8 =
   { module_typeset, 53, 8 };
Const struct predicate predicate_typeset_xmake__shared__ts2_8 =
   { module_typeset, 54, 8 };
Const struct predicate predicate_typeset_xmake__shared__type_8 =
   { module_typeset, 55, 8 };
Const struct predicate predicate_typeset_xmake__struct__ts_9 =
   { module_typeset, 56, 9 };
Const struct predicate predicate_typeset_xremove__ds_3 =
   { module_typeset, 57, 3 };
Const struct predicate predicate_typeset_xremove__ds_4 =
   { module_typeset, 58, 4 };
Const struct predicate predicate_typeset_xremove__ds2_4 =
   { module_typeset, 59, 4 };
Const struct predicate predicate_typeset_xremove__struct__ds_5 =
   { module_typeset, 60, 5 };
Const struct predicate predicate_typeset_xget__loopds_2 =
   { module_typeset, 61, 2 };
Const struct predicate predicate_typeset_xget__loopds_3 =
   { module_typeset, 62, 3 };
Const struct predicate predicate_typeset_xcheck__same__type_4 =
   { module_typeset, 63, 4 };
Const struct predicate predicate_typeset_xget__ds_5 =
   { module_typeset, 64, 5 };
Const struct predicate predicate_typeset_xget__ds1_3 =
   { module_typeset, 65, 3 };
Const struct predicate predicate_typeset_xvar2v3_4 =
   { module_typeset, 66, 4 };
Const struct predicate predicate_typeset_xvars2vs3_4 =
   { module_typeset, 67, 4 };
Const struct predicate predicate_typeset_xsplit__tt_3 =
   { module_typeset, 68, 3 };
Const struct predicate predicate_typeset_xmake__expand__ts_4 =
   { module_typeset, 69, 4 };
Const struct predicate predicate_typeset_xmake__expand__ts2_6 =
   { module_typeset, 70, 6 };
Const struct predicate predicate_typeset_xmake__expand__ts3_6 =
   { module_typeset, 71, 6 };
Const struct predicate predicate_typeset_xinclude__tt_3 =
   { module_typeset, 72, 3 };
extern Const struct predicate predicate_list_xappend_3;
extern Const struct predicate predicate_functor_xcreate__functor_3;
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_xsetarg_4;
extern Const struct predicate predicate_functor__table_xfunctor_3;
extern Const struct predicate predicate_depset_xor__depset_3;
extern Const struct predicate predicate_depset_xcheck__include_3;
extern Const struct predicate predicate_depset_xmake__nest_5;
extern Const struct predicate predicate_depset_xmerge__depset_3;
extern Const struct predicate predicate_vt_xdelete__iu_4;
extern Const struct predicate predicate_vt_xread__iu_5;
extern Const struct predicate predicate_vt_xwrite__iu_6;
extern Const struct predicate predicate_vt_xread__ts_5;
extern Const struct predicate predicate_vt_xwrite__ts_6;
declare_method_table_of(vector);

module module_typeset(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  static Const q cons_const_0[] = {
    NILATOM,
    makesym(atom__2A),
  };
  q a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, or__typeset_3_top);
    case_pred(1, or__typeset2_3_top);
    case_pred(2, or__typeset3_6_top);
    case_pred(3, or__type_4_top);
    case_pred(4, or__structtype_4_top);
    case_pred(5, or__structtype2_7_top);
    case_pred(6, or__args_4_top);
    case_pred(7, or__argslist_4_top);
    case_pred(8, unify__equal_10_top);
    case_pred(9, unify__typeset_12_top);
    case_pred(10, unify_8_top);
    case_pred(11, unify_10_top);
    case_pred(12, unify2_10_top);
    case_pred(13, unify__type_10_top);
    case_pred(14, condition1_11_top);
    case_pred(15, condition2_14_top);
    case_pred(16, condition3_12_top);
    case_pred(17, unify__struct_9_top);
    case_pred(18, entry__unifyset_4_top);
    case_pred(19, entry__unifyset_6_top);
    case_pred(20, add__dgoals_4_top);
    case_pred(21, add__dgoal_4_top);
    case_pred(22, add__dgoal__struct_5_top);
    case_pred(23, get__arg__typeset_5_top);
    case_pred(24, get_5_top);
    case_pred(25, set_12_top);
    case_pred(26, set__type_12_top);
    case_pred(27, set__type2_13_top);
    case_pred(28, set__type3_13_top);
    case_pred(29, check__normal__ts_2_top);
    case_pred(30, delete__ts_3_top);
    case_pred(31, entry__update_10_top);
    case_pred(32, value2typeset_5_top);
    case_pred(33, value2typeset__functor_7_top);
    case_pred(34, value2typeset__vector_7_top);
    case_pred(35, typeset2atom_2_top);
    case_pred(36, typeset2int_2_top);
    case_pred(37, typeset2list_2_top);
    case_pred(38, typeset2list1_2_top);
    case_pred(39, typeset2structtype_2_top);
    case_pred(40, typeset2structtype1_3_top);
    case_pred(41, merge__atomic_4_top);
    case_pred(42, get__struct__arg__typeset_3_top);
    case_pred(43, set__struct__arg__typeset_4_top);
    case_pred(44, listtype__val_3_top);
    case_pred(45, listtype__val1_4_top);
    case_pred(46, listtype__val2_4_top);
    case_pred(47, listtype__val__merge_3_top);
    case_pred(48, listtype__val__merge1_3_top);
    case_pred(49, check__dg_4_top);
    case_pred(50, check__dg2_5_top);
    case_pred(51, remove__ds_2_top);
    case_pred(52, remove__ds__struct_3_top);
    case_pred(53, make__shared__ts_8_top);
    case_pred(54, make__shared__ts2_8_top);
    case_pred(55, make__shared__type_8_top);
    case_pred(56, make__struct__ts_9_top);
    case_pred(57, remove__ds_3_top);
    case_pred(58, remove__ds_4_top);
    case_pred(59, remove__ds2_4_top);
    case_pred(60, remove__struct__ds_5_top);
    case_pred(61, get__loopds_2_top);
    case_pred(62, get__loopds_3_top);
    case_pred(63, check__same__type_4_top);
    case_pred(64, get__ds_5_top);
    case_pred(65, get__ds1_3_top);
    case_pred(66, var2v3_4_top);
    case_pred(67, vars2vs3_4_top);
    case_pred(68, split__tt_3_top);
    case_pred(69, make__expand__ts_4_top);
    case_pred(70, make__expand__ts2_6_top);
    case_pred(71, make__expand__ts3_6_top);
    last_case_pred(72, include__tt_3_top);
  }

 or__typeset_3_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  qp = qp->next;
 or__typeset_3_clear_reason:
  reasonp = reasons;
 or__typeset_3_0:
 or__typeset_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 or__typeset_3_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto or__typeset_3_5;
 or__typeset_3_3:
  switch (ptagof(a1)) {
 case CONS:
  x1 = car_of(a1);
 or__typeset_3_4:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom__2A)) goto or__typeset_3_5;
  allocp[0] = x3 = makeref(&allocp[0]);
  allocp[1] = makesym(atom__2A);
  x2 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x2);
  a0 = cdr_of(a0);
  a1 = cdr_of(a1);
  a2 = x3;
  execute(or__typeset_3_0);
  goto or__typeset_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,or__typeset_3_4);
  *reasonp++ =  x1;
  goto or__typeset_3_5;
  };
  goto or__typeset_3_5;
 case VARREF:
  deref_and_jump(a1,or__typeset_3_3);
  *reasonp++ =  a1;
  goto or__typeset_3_5;
  };
  goto or__typeset_3_5;
 case VARREF:
  deref_and_jump(x0,or__typeset_3_2);
  *reasonp++ =  x0;
  goto or__typeset_3_5;
  };
  goto or__typeset_3_5;
 case ATOMIC:
  if (a0 != NILATOM) goto or__typeset_3_5;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,or__typeset_3_1);
  *reasonp++ =  a0;
  goto or__typeset_3_5;
  };
  goto or__typeset_3_5;
 or__typeset_3_5:
 or__typeset_3_6:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != NILATOM) goto or__typeset_3_7;
  unify(a2, a0);
  proceed();
 case VARREF:
  deref_and_jump(a1,or__typeset_3_6);
  *reasonp++ =  a1;
  goto or__typeset_3_7;
  };
  goto or__typeset_3_7;
 or__typeset_3_7:
  otherwise(or__typeset_3_interrupt);
 or__typeset_3_8:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 or__typeset_3_9:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto or__typeset_3_10;
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = makesym(atom__2A);
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x1);
  a0 = cdr_of(a0);
  a2 = x2;
  execute(or__typeset_3_0);
  goto or__typeset_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,or__typeset_3_9);
  *reasonp++ =  x0;
  goto or__typeset_3_10;
  };
  goto or__typeset_3_10;
 case VARREF:
  deref_and_jump(a0,or__typeset_3_8);
  *reasonp++ =  a0;
  goto or__typeset_3_10;
  };
  goto or__typeset_3_10;
 or__typeset_3_10:
 or__typeset_3_11:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 or__typeset_3_12:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto or__typeset_3_13;
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = makesym(atom__2A);
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x1);
  a1 = cdr_of(a1);
  a2 = x2;
  execute(or__typeset_3_clear_reason);
  goto or__typeset_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,or__typeset_3_12);
  *reasonp++ =  x0;
  goto or__typeset_3_13;
  };
  goto or__typeset_3_13;
 case VARREF:
  deref_and_jump(a1,or__typeset_3_11);
  *reasonp++ =  a1;
  goto or__typeset_3_13;
  };
  goto or__typeset_3_13;
 or__typeset_3_13:
  otherwise(or__typeset_3_interrupt);
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = x2 = makeref(&allocp[1]);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a0, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[2] = x1;
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = a2;
  a0 = x2;
  a2 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(or__typeset2_3_0);
  goto or__typeset2_3_ext_interrupt;
 or__typeset_3_ext_interrupt:
  reasonp = 0l;
 or__typeset_3_interrupt:
  toppred = &predicate_typeset_xor__typeset_3;
  goto interrupt_3;
 }

 or__typeset2_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a2 = qp->args[2];
  qp = qp->next;
 or__typeset2_3_clear_reason:
  reasonp = reasons;
 or__typeset2_3_0:
 or__typeset2_3_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_t_2:
 or__typeset2_3_2:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 or__typeset2_3_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_2)) goto or__typeset2_3_10;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xor__typeset3_6);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = x0;
  allocp[5] = x2 = makeref(&allocp[5]);
  x3 = cdr_of(a1);
  allocp[6] = x3;
  allocp[7] = a2;
  a0 = arg(a0, 0);
  a1 = arg(x0, 0);
  a2 = x2;
  a3 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  execute(or__type_4_0);
  goto or__type_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,or__typeset2_3_3);
  *reasonp++ =  x0;
  goto or__typeset2_3_10;
  };
  goto or__typeset2_3_10;
 case VARREF:
  deref_and_jump(a1,or__typeset2_3_2);
  *reasonp++ =  a1;
  goto or__typeset2_3_10;
  };
  goto or__typeset2_3_10;
 case functor_tv_2:
 or__typeset2_3_4:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 or__typeset2_3_5:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_tv_2)) goto or__typeset2_3_10;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xor__typeset3_6);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = x0;
  allocp[5] = x2 = makeref(&allocp[5]);
  x3 = cdr_of(a1);
  allocp[6] = x3;
  allocp[7] = a2;
  a0 = arg(a0, 0);
  a1 = arg(x0, 0);
  a2 = x2;
  a3 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  execute(or__type_4_0);
  goto or__type_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,or__typeset2_3_5);
  *reasonp++ =  x0;
  goto or__typeset2_3_10;
  };
  goto or__typeset2_3_10;
 case VARREF:
  deref_and_jump(a1,or__typeset2_3_4);
  *reasonp++ =  a1;
  goto or__typeset2_3_10;
  };
  goto or__typeset2_3_10;
 case functor_tt_3:
 or__typeset2_3_6:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 or__typeset2_3_7:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_tt_3)) goto or__typeset2_3_10;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xor__typeset3_6);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = x0;
  allocp[5] = x2 = makeref(&allocp[5]);
  x3 = cdr_of(a1);
  allocp[6] = x3;
  allocp[7] = a2;
  allocp[8] = makesym(functor_tt_2);
  x5 = arg(a0, 0);
  allocp[9] = x5;
  x6 = arg(a0, 1);
  allocp[10] = x6;
  x4 = makefunctor(&allocp[8]);
  allocp[11] = makesym(functor_tt_2);
  x8 = arg(x0, 0);
  allocp[12] = x8;
  x9 = arg(x0, 1);
  allocp[13] = x9;
  x7 = makefunctor(&allocp[11]);
  a0 = x4;
  a1 = x7;
  a2 = x2;
  a3 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 14;
  execute(or__type_4_0);
  goto or__type_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,or__typeset2_3_7);
  *reasonp++ =  x0;
  goto or__typeset2_3_10;
  };
  goto or__typeset2_3_10;
 case VARREF:
  deref_and_jump(a1,or__typeset2_3_6);
  *reasonp++ =  a1;
  goto or__typeset2_3_10;
  };
  goto or__typeset2_3_10;
 case functor_te_4:
 or__typeset2_3_8:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 or__typeset2_3_9:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_te_4)) goto or__typeset2_3_10;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xor__typeset3_6);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = x0;
  allocp[5] = x2 = makeref(&allocp[5]);
  x3 = cdr_of(a1);
  allocp[6] = x3;
  allocp[7] = a2;
  allocp[8] = makesym(functor_te_3);
  x5 = arg(a0, 0);
  allocp[9] = x5;
  x6 = arg(a0, 1);
  allocp[10] = x6;
  x7 = arg(a0, 2);
  allocp[11] = x7;
  x4 = makefunctor(&allocp[8]);
  allocp[12] = makesym(functor_te_3);
  x9 = arg(x0, 0);
  allocp[13] = x9;
  x10 = arg(x0, 1);
  allocp[14] = x10;
  x11 = arg(x0, 2);
  allocp[15] = x11;
  x8 = makefunctor(&allocp[12]);
  a0 = x4;
  a1 = x8;
  a2 = x2;
  a3 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 16;
  execute(or__type_4_0);
  goto or__type_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,or__typeset2_3_9);
  *reasonp++ =  x0;
  goto or__typeset2_3_10;
  };
  goto or__typeset2_3_10;
 case VARREF:
  deref_and_jump(a1,or__typeset2_3_8);
  *reasonp++ =  a1;
  goto or__typeset2_3_10;
  };
  goto or__typeset2_3_10;
  };
  goto or__typeset2_3_10;
 case VARREF:
  deref_and_jump(a0,or__typeset2_3_1);
  *reasonp++ =  a0;
  goto or__typeset2_3_10;
  };
  goto or__typeset2_3_10;
 or__typeset2_3_10:
 or__typeset2_3_11:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != NILATOM) goto or__typeset2_3_12;
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,or__typeset2_3_11);
  *reasonp++ =  a1;
  goto or__typeset2_3_12;
  };
  goto or__typeset2_3_12;
 or__typeset2_3_12:
  otherwise(or__typeset2_3_interrupt);
 or__typeset2_3_13:
  switch (ptagof(a1)) {
 case CONS:
  x0 = a0;
  x1 = car_of(a1);
  a3 = makesym(atom_dmy);
  a4 = cdr_of(a1);
  a5 = a2;
  a2 = x1;
  a1 = x0;
  a0 = makesym(atom_no);
  execute(or__typeset3_6_0);
  goto or__typeset3_6_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,or__typeset2_3_13);
  *reasonp++ =  a1;
  goto or__typeset2_3_interrupt;
  };
  goto or__typeset2_3_interrupt;
 or__typeset2_3_ext_interrupt:
  reasonp = 0l;
 or__typeset2_3_interrupt:
  toppred = &predicate_typeset_xor__typeset2_3;
  goto interrupt_3;
 }

 or__typeset3_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 or__typeset3_6_clear_reason:
  reasonp = reasons;
 or__typeset3_6_0:
 or__typeset3_6_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto or__typeset3_6_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_no)):
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = a2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a5, x0);
  a0 = a1;
  a1 = a4;
  a2 = x1;
  execute(or__typeset2_3_0);
  goto or__typeset2_3_ext_interrupt;
 case symval(makesym(atom_yes)):
 or__typeset3_6_2:
  switch (ptagof(a1)) {
 case FUNCTOR:
  switch (symval(functor_of(a1))) {
 case functor_t_2:
 or__typeset3_6_3:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_t_2)) goto or__typeset3_6_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xor__typeset2_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a4;
  allocp[4] = a5;
  allocp[5] = makesym(functor_t_2);
  allocp[6] = a3;
  allocp[7] = x2 = makeref(&allocp[7]);
  x1 = makefunctor(&allocp[5]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  unify_value(x0, x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xor__depset_3);
  x3 = arg(a1, 1);
  allocp[2] = x3;
  x4 = arg(a2, 1);
  allocp[3] = x4;
  allocp[4] = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case VARREF:
  deref_and_jump(a2,or__typeset3_6_3);
  *reasonp++ =  a2;
  goto or__typeset3_6_interrupt;
  };
  goto or__typeset3_6_interrupt;
 case functor_tv_2:
 or__typeset3_6_4:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_tv_2)) goto or__typeset3_6_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xor__typeset2_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a4;
  allocp[4] = a5;
  allocp[5] = makesym(functor_tv_2);
  allocp[6] = a3;
  allocp[7] = x2 = makeref(&allocp[7]);
  x1 = makefunctor(&allocp[5]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  unify_value(x0, x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xor__depset_3);
  x3 = arg(a1, 1);
  allocp[2] = x3;
  x4 = arg(a2, 1);
  allocp[3] = x4;
  allocp[4] = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case VARREF:
  deref_and_jump(a2,or__typeset3_6_4);
  *reasonp++ =  a2;
  goto or__typeset3_6_interrupt;
  };
  goto or__typeset3_6_interrupt;
 case functor_tt_3:
 or__typeset3_6_5:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_tt_3)) goto or__typeset3_6_interrupt;
  x0 = arg(a2, 0);
 or__typeset3_6_6:
  if (isref(x0)) goto or__typeset3_6_13;
 or__typeset3_6_7:
  if (isref(x0)) goto or__typeset3_6_12;
  x1 = arg(a1, 0);
  if_not_equal(x0, x1, or__typeset3_6_interrupt);
  x2 = arg(a2, 1);
 or__typeset3_6_8:
  if (isref(x2)) goto or__typeset3_6_11;
 or__typeset3_6_9:
  if (isref(x2)) goto or__typeset3_6_10;
  x3 = arg(a1, 1);
  if_not_equal(x2, x3, or__typeset3_6_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xor__typeset2_3);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = a4;
  allocp[4] = a5;
  allocp[5] = makesym(functor_tt_3);
  allocp[6] = x1;
  allocp[7] = x3;
  allocp[8] = x6 = makeref(&allocp[8]);
  x5 = makefunctor(&allocp[5]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 9;
  unify_value(x4, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xor__depset_3);
  x7 = arg(a1, 2);
  allocp[2] = x7;
  x8 = arg(a2, 2);
  allocp[3] = x8;
  allocp[4] = x6;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 or__typeset3_6_10:
  deref_and_jump(x2,or__typeset3_6_9);
  *reasonp++ =  x2;
  goto or__typeset3_6_interrupt;
 or__typeset3_6_11:
  deref_and_jump(x2,or__typeset3_6_8);
  *reasonp++ =  x2;
  goto or__typeset3_6_interrupt;
 or__typeset3_6_12:
  deref_and_jump(x0,or__typeset3_6_7);
  *reasonp++ =  x0;
  goto or__typeset3_6_interrupt;
 or__typeset3_6_13:
  deref_and_jump(x0,or__typeset3_6_6);
  *reasonp++ =  x0;
  goto or__typeset3_6_interrupt;
 case VARREF:
  deref_and_jump(a2,or__typeset3_6_5);
  *reasonp++ =  a2;
  goto or__typeset3_6_interrupt;
  };
  goto or__typeset3_6_interrupt;
 case functor_te_4:
 or__typeset3_6_14:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_te_4)) goto or__typeset3_6_interrupt;
  x0 = arg(a2, 0);
 or__typeset3_6_15:
  if (isref(x0)) goto or__typeset3_6_26;
 or__typeset3_6_16:
  if (isref(x0)) goto or__typeset3_6_25;
  x1 = arg(a1, 0);
  if_not_equal(x0, x1, or__typeset3_6_interrupt);
  x2 = arg(a2, 1);
 or__typeset3_6_17:
  if (isref(x2)) goto or__typeset3_6_24;
 or__typeset3_6_18:
  if (isref(x2)) goto or__typeset3_6_23;
  x3 = arg(a1, 1);
  if_not_equal(x2, x3, or__typeset3_6_interrupt);
  x4 = arg(a2, 2);
 or__typeset3_6_19:
  if (isref(x4)) goto or__typeset3_6_22;
 or__typeset3_6_20:
  if (isref(x4)) goto or__typeset3_6_21;
  x5 = arg(a1, 2);
  if_not_equal(x4, x5, or__typeset3_6_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xor__typeset2_3);
  allocp[2] = x6 = makeref(&allocp[2]);
  allocp[3] = a4;
  allocp[4] = a5;
  allocp[5] = makesym(functor_te_4);
  allocp[6] = x1;
  allocp[7] = x3;
  allocp[8] = x5;
  allocp[9] = x8 = makeref(&allocp[9]);
  x7 = makefunctor(&allocp[5]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  unify_value(x6, x7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xor__depset_3);
  x9 = arg(a1, 3);
  allocp[2] = x9;
  x10 = arg(a2, 3);
  allocp[3] = x10;
  allocp[4] = x8;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 or__typeset3_6_21:
  deref_and_jump(x4,or__typeset3_6_20);
  *reasonp++ =  x4;
  goto or__typeset3_6_interrupt;
 or__typeset3_6_22:
  deref_and_jump(x4,or__typeset3_6_19);
  *reasonp++ =  x4;
  goto or__typeset3_6_interrupt;
 or__typeset3_6_23:
  deref_and_jump(x2,or__typeset3_6_18);
  *reasonp++ =  x2;
  goto or__typeset3_6_interrupt;
 or__typeset3_6_24:
  deref_and_jump(x2,or__typeset3_6_17);
  *reasonp++ =  x2;
  goto or__typeset3_6_interrupt;
 or__typeset3_6_25:
  deref_and_jump(x0,or__typeset3_6_16);
  *reasonp++ =  x0;
  goto or__typeset3_6_interrupt;
 or__typeset3_6_26:
  deref_and_jump(x0,or__typeset3_6_15);
  *reasonp++ =  x0;
  goto or__typeset3_6_interrupt;
 case VARREF:
  deref_and_jump(a2,or__typeset3_6_14);
  *reasonp++ =  a2;
  goto or__typeset3_6_interrupt;
  };
  goto or__typeset3_6_interrupt;
  };
  goto or__typeset3_6_interrupt;
 case VARREF:
  deref_and_jump(a1,or__typeset3_6_2);
  *reasonp++ =  a1;
  goto or__typeset3_6_interrupt;
  };
  goto or__typeset3_6_interrupt;
  };
  goto or__typeset3_6_interrupt;
 case VARREF:
  deref_and_jump(a0,or__typeset3_6_1);
  *reasonp++ =  a0;
  goto or__typeset3_6_interrupt;
  };
  goto or__typeset3_6_interrupt;
 or__typeset3_6_ext_interrupt:
  reasonp = 0l;
 or__typeset3_6_interrupt:
  toppred = &predicate_typeset_xor__typeset3_6;
  goto interrupt_6;
 }

 or__type_4_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 or__type_4_clear_reason:
  reasonp = reasons;
 or__type_4_0:
 or__type_4_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_s_3:
 or__type_4_2:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_s_3)) goto or__type_4_16;
  execute(or__structtype_4_0);
  goto or__structtype_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,or__type_4_2);
  *reasonp++ =  a1;
  goto or__type_4_16;
  };
  goto or__type_4_16;
 case functor_v_4:
 or__type_4_3:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_v_4)) goto or__type_4_16;
  x0 = arg(a1, 0);
 or__type_4_4:
  if (isref(x0)) goto or__type_4_15;
 or__type_4_5:
  if (isref(x0)) goto or__type_4_14;
  x1 = arg(a0, 0);
  if_not_equal(x0, x1, or__type_4_16);
  x2 = arg(a1, 1);
 or__type_4_6:
  if (isref(x2)) goto or__type_4_13;
 or__type_4_7:
  if (isref(x2)) goto or__type_4_12;
  x3 = arg(a0, 1);
  if_not_equal(x2, x3, or__type_4_16);
  x4 = arg(a1, 2);
 or__type_4_8:
  if (isref(x4)) goto or__type_4_11;
 or__type_4_9:
  if (isref(x4)) goto or__type_4_10;
  x5 = arg(a0, 2);
  if_not_equal(x4, x5, or__type_4_16);
  unify_value(a2, a0);
  x6 = makesym(atom_yes);
  unify_value(a3, x6);
  proceed();
 or__type_4_10:
  deref_and_jump(x4,or__type_4_9);
  *reasonp++ =  x4;
  goto or__type_4_16;
 or__type_4_11:
  deref_and_jump(x4,or__type_4_8);
  *reasonp++ =  x4;
  goto or__type_4_16;
 or__type_4_12:
  deref_and_jump(x2,or__type_4_7);
  *reasonp++ =  x2;
  goto or__type_4_16;
 or__type_4_13:
  deref_and_jump(x2,or__type_4_6);
  *reasonp++ =  x2;
  goto or__type_4_16;
 or__type_4_14:
  deref_and_jump(x0,or__type_4_5);
  *reasonp++ =  x0;
  goto or__type_4_16;
 or__type_4_15:
  deref_and_jump(x0,or__type_4_4);
  *reasonp++ =  x0;
  goto or__type_4_16;
 case VARREF:
  deref_and_jump(a1,or__type_4_3);
  *reasonp++ =  a1;
  goto or__type_4_16;
  };
  goto or__type_4_16;
  };
  goto or__type_4_16;
 case VARREF:
  deref_and_jump(a0,or__type_4_1);
  *reasonp++ =  a0;
  goto or__type_4_37;
  };
  goto or__type_4_16;
 or__type_4_16:
  gblt_pfunctor(a0,x0,or__type_4_37);
  if (isint(x0)) goto or__type_4_37;
  switch (symval(x0)) {
 case symval(makesym(atom_a)):
  gblt_arity(a0,x1,or__type_4_37);
 or__type_4_17:
  if (isref(a1)) goto or__type_4_18;
  gblt_pfunctor(a1,x2,or__type_4_37);
  if (x2 != makesym(atom_a)) goto or__type_4_37;
  gblt_arity(a1,x3,or__type_4_37);
  x4 = makesym(atom_yes);
  unify_value(a3, x4);
  x5 = a0;
  x6 = a1;
  a3 = a2;
  a2 = x6;
  a1 = x5;
  a0 = makesym(atom_or);
  execute(merge__atomic_4_0);
  goto merge__atomic_4_ext_interrupt;
 or__type_4_18:
  deref_and_jump(a1,or__type_4_17);
  *reasonp++ =  a1;
  goto or__type_4_37;
 case symval(makesym(atom_i)):
  gblt_arity(a0,x1,or__type_4_37);
 or__type_4_19:
  if (isref(a1)) goto or__type_4_20;
  gblt_pfunctor(a1,x2,or__type_4_37);
  if (x2 != makesym(atom_i)) goto or__type_4_37;
  gblt_arity(a1,x3,or__type_4_37);
  x4 = makesym(atom_yes);
  unify_value(a3, x4);
  x5 = a0;
  x6 = a1;
  a3 = a2;
  a2 = x6;
  a1 = x5;
  a0 = makesym(atom_or);
  execute(merge__atomic_4_0);
  goto merge__atomic_4_ext_interrupt;
 or__type_4_20:
  deref_and_jump(a1,or__type_4_19);
  *reasonp++ =  a1;
  goto or__type_4_37;
 case symval(makesym(atom_f)):
  gblt_arity(a0,x1,or__type_4_37);
 or__type_4_21:
  if (isref(a1)) goto or__type_4_22;
  gblt_pfunctor(a1,x2,or__type_4_37);
  if (x2 != makesym(atom_f)) goto or__type_4_37;
  gblt_arity(a1,x3,or__type_4_37);
  x4 = makesym(atom_yes);
  unify_value(a3, x4);
  x5 = a0;
  x6 = a1;
  a3 = a2;
  a2 = x6;
  a1 = x5;
  a0 = makesym(atom_or);
  execute(merge__atomic_4_0);
  goto merge__atomic_4_ext_interrupt;
 or__type_4_22:
  deref_and_jump(a1,or__type_4_21);
  *reasonp++ =  a1;
  goto or__type_4_37;
 case symval(makesym(atom_c)):
  gblt_arity(a0,x1,or__type_4_37);
 or__type_4_23:
  if (isref(a1)) goto or__type_4_24;
  gblt_pfunctor(a1,x2,or__type_4_37);
  if (x2 != makesym(atom_c)) goto or__type_4_37;
  gblt_arity(a1,x3,or__type_4_37);
  x4 = makesym(atom_yes);
  unify_value(a3, x4);
  x5 = a0;
  x6 = a1;
  a3 = a2;
  a2 = x6;
  a1 = x5;
  a0 = makesym(atom_or);
  execute(merge__atomic_4_0);
  goto merge__atomic_4_ext_interrupt;
 or__type_4_24:
  deref_and_jump(a1,or__type_4_23);
  *reasonp++ =  a1;
  goto or__type_4_37;
 case symval(makesym(atom_tt)):
  gblt_arity(a0,x1,or__type_4_37);
 or__type_4_25:
  if (isref(a1)) goto or__type_4_30;
  gblt_pfunctor(a1,x2,or__type_4_37);
  if (x2 != makesym(atom_tt)) goto or__type_4_37;
  gblt_arity(a1,x3,or__type_4_37);
 or__type_4_26:
  if (isref(a0)) goto or__type_4_29;
 or__type_4_27:
  if (isref(a0)) goto or__type_4_28;
  if_not_equal(a0, a1, or__type_4_37);
  unify_value(a2, a0);
  x4 = makesym(atom_yes);
  unify_value(a3, x4);
  proceed();
 or__type_4_28:
  deref_and_jump(a0,or__type_4_27);
  *reasonp++ =  a0;
  goto or__type_4_37;
 or__type_4_29:
  deref_and_jump(a0,or__type_4_26);
  *reasonp++ =  a0;
  goto or__type_4_37;
 or__type_4_30:
  deref_and_jump(a1,or__type_4_25);
  *reasonp++ =  a1;
  goto or__type_4_37;
 case symval(makesym(atom_te)):
  gblt_arity(a0,x1,or__type_4_37);
 or__type_4_31:
  if (isref(a1)) goto or__type_4_36;
  gblt_pfunctor(a1,x2,or__type_4_37);
  if (x2 != makesym(atom_te)) goto or__type_4_37;
  gblt_arity(a1,x3,or__type_4_37);
 or__type_4_32:
  if (isref(a0)) goto or__type_4_35;
 or__type_4_33:
  if (isref(a0)) goto or__type_4_34;
  if_not_equal(a0, a1, or__type_4_37);
  unify_value(a2, a0);
  x4 = makesym(atom_yes);
  unify_value(a3, x4);
  proceed();
 or__type_4_34:
  deref_and_jump(a0,or__type_4_33);
  *reasonp++ =  a0;
  goto or__type_4_37;
 or__type_4_35:
  deref_and_jump(a0,or__type_4_32);
  *reasonp++ =  a0;
  goto or__type_4_37;
 or__type_4_36:
  deref_and_jump(a1,or__type_4_31);
  *reasonp++ =  a1;
  goto or__type_4_37;
  };
  goto or__type_4_37;
 or__type_4_37:
  otherwise(or__type_4_interrupt);
  x0 = makesym(atom_dmy);
  unify_value(a2, x0);
  x1 = makesym(atom_no);
  unify_value(a3, x1);
  proceed();
 or__type_4_ext_interrupt:
  reasonp = 0l;
 or__type_4_interrupt:
  toppred = &predicate_typeset_xor__type_4;
  goto interrupt_4;
 }

 or__structtype_4_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 or__structtype_4_clear_reason:
  reasonp = reasons;
 or__structtype_4_0:
 or__structtype_4_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_s_3)) goto or__structtype_4_4;
  x0 = arg(a0, 0);
 or__structtype_4_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto or__structtype_4_4;
 or__structtype_4_3:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_s_3)) goto or__structtype_4_4;
  x1 = arg(a0, 1);
  x2 = arg(a1, 1);
  x3 = arg(a0, 2);
  a4 = arg(a1, 2);
  a5 = a2;
  a6 = a3;
  a3 = x3;
  a2 = x2;
  a1 = x1;
  a0 = makesym(atom__2A);
  execute(or__structtype2_7_0);
  goto or__structtype2_7_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,or__structtype_4_3);
  *reasonp++ =  a1;
  goto or__structtype_4_4;
  };
  goto or__structtype_4_4;
 case VARREF:
  deref_and_jump(x0,or__structtype_4_2);
  *reasonp++ =  x0;
  goto or__structtype_4_4;
  };
  goto or__structtype_4_4;
 case VARREF:
  deref_and_jump(a0,or__structtype_4_1);
  *reasonp++ =  a0;
  goto or__structtype_4_4;
  };
  goto or__structtype_4_4;
 or__structtype_4_4:
  otherwise(or__structtype_4_interrupt);
 or__structtype_4_5:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_s_3)) goto or__structtype_4_8;
 or__structtype_4_6:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_s_3)) goto or__structtype_4_8;
  x0 = arg(a1, 0);
 or__structtype_4_7:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto or__structtype_4_8;
  x1 = arg(a0, 1);
  x2 = arg(a1, 1);
  x3 = arg(a0, 2);
  a4 = arg(a1, 2);
  a5 = a2;
  a6 = a3;
  a3 = x3;
  a2 = x2;
  a1 = x1;
  a0 = makesym(atom__2A);
  execute(or__structtype2_7_0);
  goto or__structtype2_7_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,or__structtype_4_7);
  *reasonp++ =  x0;
  goto or__structtype_4_8;
  };
  goto or__structtype_4_8;
 case VARREF:
  deref_and_jump(a1,or__structtype_4_6);
  *reasonp++ =  a1;
  goto or__structtype_4_8;
  };
  goto or__structtype_4_8;
 case VARREF:
  deref_and_jump(a0,or__structtype_4_5);
  *reasonp++ =  a0;
  goto or__structtype_4_8;
  };
  goto or__structtype_4_8;
 or__structtype_4_8:
  otherwise(or__structtype_4_interrupt);
 or__structtype_4_9:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_s_3)) goto or__structtype_4_15;
 or__structtype_4_10:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_s_3)) goto or__structtype_4_15;
  x0 = arg(a1, 0);
 or__structtype_4_11:
  if (isref(x0)) goto or__structtype_4_14;
 or__structtype_4_12:
  if (isref(x0)) goto or__structtype_4_13;
  x1 = arg(a0, 0);
  if_not_equal(x0, x1, or__structtype_4_15);
  x2 = arg(a0, 1);
  x3 = arg(a1, 1);
  x4 = arg(a0, 2);
  a4 = arg(a1, 2);
  a5 = a2;
  a6 = a3;
  a3 = x4;
  a2 = x3;
  a1 = x2;
  a0 = x1;
  execute(or__structtype2_7_clear_reason);
  goto or__structtype2_7_ext_interrupt;
 or__structtype_4_13:
  deref_and_jump(x0,or__structtype_4_12);
  *reasonp++ =  x0;
  goto or__structtype_4_15;
 or__structtype_4_14:
  deref_and_jump(x0,or__structtype_4_11);
  *reasonp++ =  x0;
  goto or__structtype_4_15;
 case VARREF:
  deref_and_jump(a1,or__structtype_4_10);
  *reasonp++ =  a1;
  goto or__structtype_4_15;
  };
  goto or__structtype_4_15;
 case VARREF:
  deref_and_jump(a0,or__structtype_4_9);
  *reasonp++ =  a0;
  goto or__structtype_4_15;
  };
  goto or__structtype_4_15;
 or__structtype_4_15:
  otherwise(or__structtype_4_interrupt);
  x0 = makesym(atom_no);
  unify_value(a3, x0);
  x1 = makesym(atom_dmy);
  unify_value(a2, x1);
  proceed();
 or__structtype_4_ext_interrupt:
  reasonp = 0l;
 or__structtype_4_interrupt:
  toppred = &predicate_typeset_xor__structtype_4;
  goto interrupt_4;
 }

 or__structtype2_7_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 or__structtype2_7_clear_reason:
  reasonp = reasons;
 or__structtype2_7_0:
 or__structtype2_7_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom__2A)) goto or__structtype2_7_3;
 or__structtype2_7_2:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom__2A)) goto or__structtype2_7_3;
  x0 = makesym(atom_yes);
  unify_value(a6, x0);
  allocp[0] = makesym(functor_s_3);
  allocp[1] = a0;
  allocp[2] = makesym(atom__2A);
  allocp[3] = x2 = makeref(&allocp[3]);
  x1 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a5, x1);
  a0 = a3;
  a1 = a4;
  a2 = x2;
  execute(or__typeset_3_0);
  goto or__typeset_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,or__structtype2_7_2);
  *reasonp++ =  a2;
  goto or__structtype2_7_3;
  };
  goto or__structtype2_7_3;
 case VARREF:
  deref_and_jump(a1,or__structtype2_7_1);
  *reasonp++ =  a1;
  goto or__structtype2_7_3;
  };
  goto or__structtype2_7_3;
 or__structtype2_7_3:
  otherwise(or__structtype2_7_interrupt);
 or__structtype2_7_4:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom__2A)) goto or__structtype2_7_7;
 or__structtype2_7_5:
  if (!isint(a2)) goto or__structtype2_7_6;
  gblt_integer(a2,or__structtype2_7_7);
  x0 = makesym(atom_yes);
  unify_value(a6, x0);
  allocp[0] = makesym(functor_s_3);
  allocp[1] = a0;
  allocp[2] = makesym(atom__2A);
  allocp[3] = x2 = makeref(&allocp[3]);
  x1 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a5, x1);
  a0 = a2;
  a1 = a4;
  a2 = a3;
  a3 = x2;
  execute(or__argslist_4_0);
  goto or__argslist_4_ext_interrupt;
 or__structtype2_7_6:
  if (!isref(a2)) goto or__structtype2_7_7;
  deref_and_jump(a2,or__structtype2_7_5);
  *reasonp++ =  a2;
  goto or__structtype2_7_7;
 case VARREF:
  deref_and_jump(a1,or__structtype2_7_4);
  *reasonp++ =  a1;
  goto or__structtype2_7_12;
  };
  goto or__structtype2_7_7;
 or__structtype2_7_7:
 or__structtype2_7_8:
  if (isref(a1)) goto or__structtype2_7_11;
  if_not_equal(a1, a2, or__structtype2_7_12);
 or__structtype2_7_9:
  if (!isint(a1)) goto or__structtype2_7_10;
  gblt_integer(a1,or__structtype2_7_12);
  x0 = makesym(atom_yes);
  unify_value(a6, x0);
  allocp[0] = makesym(functor_s_3);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = x2 = makeref(&allocp[3]);
  x1 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a5, x1);
  a0 = a1;
  a1 = a3;
  a2 = a4;
  a3 = x2;
  execute(or__args_4_clear_reason);
  goto or__args_4_ext_interrupt;
 or__structtype2_7_10:
  if (!isref(a1)) goto or__structtype2_7_12;
  deref_and_jump(a1,or__structtype2_7_9);
  *reasonp++ =  a1;
  goto or__structtype2_7_12;
 or__structtype2_7_11:
  deref_and_jump(a1,or__structtype2_7_8);
  *reasonp++ =  a1;
  goto or__structtype2_7_12;
 or__structtype2_7_12:
 or__structtype2_7_13:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom__2A)) goto or__structtype2_7_16;
 or__structtype2_7_14:
  if (!isint(a1)) goto or__structtype2_7_15;
  gblt_integer(a1,or__structtype2_7_16);
  x0 = makesym(atom_yes);
  unify_value(a6, x0);
  allocp[0] = makesym(functor_s_3);
  allocp[1] = a0;
  allocp[2] = makesym(atom__2A);
  allocp[3] = x2 = makeref(&allocp[3]);
  x1 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a5, x1);
  a0 = a1;
  a1 = a3;
  a2 = a4;
  a3 = x2;
  execute(or__argslist_4_clear_reason);
  goto or__argslist_4_ext_interrupt;
 or__structtype2_7_15:
  if (!isref(a1)) goto or__structtype2_7_16;
  deref_and_jump(a1,or__structtype2_7_14);
  *reasonp++ =  a1;
  goto or__structtype2_7_16;
 case VARREF:
  deref_and_jump(a2,or__structtype2_7_13);
  *reasonp++ =  a2;
  goto or__structtype2_7_16;
  };
  goto or__structtype2_7_16;
 or__structtype2_7_16:
  otherwise(or__structtype2_7_interrupt);
  x0 = makesym(atom_dmy);
  unify_value(a5, x0);
  x1 = makesym(atom_no);
  unify_value(a6, x1);
  proceed();
 or__structtype2_7_ext_interrupt:
  reasonp = 0l;
 or__structtype2_7_interrupt:
  toppred = &predicate_typeset_xor__structtype2_7;
  goto interrupt_7;
 }

 or__args_4_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 or__args_4_clear_reason:
  reasonp = reasons;
 or__args_4_0:
 or__args_4_1:
  if (!isint(a0)) goto or__args_4_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,or__args_4_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xor__args_4);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x1;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[13] = a0;
  allocp[14] = a1;
  allocp[15] = x3 = makeref(&allocp[15]);
  allocp[16] = x2;
  allocp[17] = (q)(struct goalrec*)&allocp[11];
  allocp[18] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[19] = x4 = makeref(&allocp[19]);
  allocp[20] = x5 = makeref(&allocp[20]);
  allocp[21] = x3;
  allocp[22] = (q)(struct goalrec*)&allocp[17];
  allocp[23] = (q)(&predicate_functor__table_xarg_3);
  allocp[24] = a0;
  allocp[25] = a2;
  allocp[26] = x5;
  allocp[27] = (q)(struct goalrec*)&allocp[22];
  allocp[28] = (q)(&predicate_functor__table_xarg_3);
  allocp[29] = a0;
  allocp[30] = a1;
  allocp[31] = x4;
  qp = (struct goalrec*)&allocp[27];
  allocp += 32;
  proceed();
 or__args_4_2:
  if (a0 != makeint(0L)) goto or__args_4_interrupt;
  unify(a3, a1);
  proceed();
 or__args_4_3:
  if (!isref(a0)) goto or__args_4_interrupt;
  deref_and_jump(a0,or__args_4_1);
  *reasonp++ =  a0;
  goto or__args_4_interrupt;
 or__args_4_ext_interrupt:
  reasonp = 0l;
 or__args_4_interrupt:
  toppred = &predicate_typeset_xor__args_4;
  goto interrupt_4;
 }

 or__argslist_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 or__argslist_4_clear_reason:
  reasonp = reasons;
 or__argslist_4_0:
 or__argslist_4_1:
  if (!isint(a0)) goto or__argslist_4_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,or__argslist_4_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xor__argslist_4);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x1;
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[13] = a2;
  allocp[14] = x3 = makeref(&allocp[14]);
  allocp[15] = x2;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_functor__table_xarg_3);
  allocp[18] = a0;
  allocp[19] = a1;
  allocp[20] = x3;
  qp = (struct goalrec*)&allocp[16];
  allocp += 21;
  proceed();
 or__argslist_4_2:
  if (a0 != makeint(0L)) goto or__argslist_4_interrupt;
  unify(a3, a2);
  proceed();
 or__argslist_4_3:
  if (!isref(a0)) goto or__argslist_4_interrupt;
  deref_and_jump(a0,or__argslist_4_1);
  *reasonp++ =  a0;
  goto or__argslist_4_interrupt;
 or__argslist_4_ext_interrupt:
  reasonp = 0l;
 or__argslist_4_interrupt:
  toppred = &predicate_typeset_xor__argslist_4;
  goto interrupt_4;
 }

 unify__equal_10_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20, x21;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 unify__equal_10_clear_reason:
  reasonp = reasons;
 unify__equal_10_0:
 unify__equal_10_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 unify__equal_10_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto unify__equal_10_6;
  x1 = cdr_of(a1);
 unify__equal_10_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto unify__equal_10_6;
 unify__equal_10_4:
  switch (ptagof(a3)) {
 case FUNCTOR:
  if (functor_of(a3) != makesym(functor_variable_3)) goto unify__equal_10_6;
 unify__equal_10_5:
  switch (ptagof(a4)) {
 case FUNCTOR:
  if (functor_of(a4) != makesym(functor_variable_3)) goto unify__equal_10_6;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = x3 = makeref(&allocp[1]);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = x6 = makeref(&allocp[4]);
  x2 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a2, x2);
  allocp[0] = makesym(functor_v_4);
  allocp[1] = x3;
  allocp[2] = x4;
  x8 = arg(a4, 0);
  allocp[3] = x8;
  x9 = arg(a4, 1);
  allocp[4] = x9;
  x7 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_v_4);
  allocp[6] = x3;
  allocp[7] = x4;
  x11 = arg(a3, 0);
  allocp[8] = x11;
  x12 = arg(a3, 1);
  allocp[9] = x12;
  x10 = makefunctor(&allocp[5]);
  allocp[10] = (q)qp;
  allocp[11] = (q)(&predicate_vt_xdelete__iu_4);
  allocp[12] = x7;
  allocp[13] = x10;
  allocp[14] = x13 = makeref(&allocp[14]);
  allocp[15] = a7;
  allocp[16] = (q)(struct goalrec*)&allocp[10];
  allocp[17] = (q)(&predicate_typeset_xset_12);
  allocp[18] = x3;
  allocp[19] = x4;
  allocp[20] = x5;
  allocp[21] = x6;
  x14 = arg(a4, 0);
  allocp[22] = x14;
  x15 = arg(a4, 1);
  allocp[23] = x15;
  allocp[24] = x16 = makeref(&allocp[24]);
  allocp[25] = a5;
  allocp[26] = x17 = makeref(&allocp[26]);
  allocp[27] = x13;
  allocp[28] = a8;
  allocp[29] = a9;
  allocp[30] = makesym(functor_v_4);
  allocp[31] = x3;
  allocp[32] = x4;
  x19 = arg(a3, 0);
  allocp[33] = x19;
  x20 = arg(a3, 1);
  allocp[34] = x20;
  x18 = makefunctor(&allocp[30]);
  allocp[35] = makesym(functor_v_4);
  allocp[36] = x3;
  allocp[37] = x4;
  allocp[38] = x14;
  allocp[39] = x15;
  x21 = makefunctor(&allocp[35]);
  allocp[40] = (q)(struct goalrec*)&allocp[16];
  allocp[41] = (q)(&predicate_typeset_xentry__unifyset_4);
  allocp[42] = x18;
  allocp[43] = x21;
  allocp[44] = a6;
  allocp[45] = x17;
  a1 = a2;
  a2 = x16;
  a3 = a5;
  qp = (struct goalrec*)&allocp[40];
  allocp += 46;
  execute(add__dgoal_4_0);
  goto add__dgoal_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a4,unify__equal_10_5);
  *reasonp++ =  a4;
  goto unify__equal_10_6;
  };
  goto unify__equal_10_6;
 case VARREF:
  deref_and_jump(a3,unify__equal_10_4);
  *reasonp++ =  a3;
  goto unify__equal_10_6;
  };
  goto unify__equal_10_6;
 case VARREF:
  deref_and_jump(x1,unify__equal_10_3);
  *reasonp++ =  x1;
  goto unify__equal_10_6;
  };
  goto unify__equal_10_6;
 case VARREF:
  deref_and_jump(x0,unify__equal_10_2);
  *reasonp++ =  x0;
  goto unify__equal_10_6;
  };
  goto unify__equal_10_6;
 case VARREF:
  deref_and_jump(a1,unify__equal_10_1);
  *reasonp++ =  a1;
  goto unify__equal_10_6;
  };
  goto unify__equal_10_6;
 unify__equal_10_6:
 unify__equal_10_7:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 unify__equal_10_8:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto unify__equal_10_12;
  x1 = cdr_of(a0);
 unify__equal_10_9:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto unify__equal_10_12;
 unify__equal_10_10:
  switch (ptagof(a3)) {
 case FUNCTOR:
  if (functor_of(a3) != makesym(functor_variable_3)) goto unify__equal_10_12;
 unify__equal_10_11:
  switch (ptagof(a4)) {
 case FUNCTOR:
  if (functor_of(a4) != makesym(functor_variable_3)) goto unify__equal_10_12;
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = x3 = makeref(&allocp[1]);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = x6 = makeref(&allocp[4]);
  x2 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a2, x2);
  allocp[0] = makesym(functor_v_4);
  allocp[1] = x3;
  allocp[2] = x4;
  x8 = arg(a3, 0);
  allocp[3] = x8;
  x9 = arg(a3, 1);
  allocp[4] = x9;
  x7 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_v_4);
  allocp[6] = x3;
  allocp[7] = x4;
  x11 = arg(a4, 0);
  allocp[8] = x11;
  x12 = arg(a4, 1);
  allocp[9] = x12;
  x10 = makefunctor(&allocp[5]);
  allocp[10] = (q)qp;
  allocp[11] = (q)(&predicate_vt_xdelete__iu_4);
  allocp[12] = x7;
  allocp[13] = x10;
  allocp[14] = x13 = makeref(&allocp[14]);
  allocp[15] = a7;
  allocp[16] = (q)(struct goalrec*)&allocp[10];
  allocp[17] = (q)(&predicate_typeset_xset_12);
  allocp[18] = x3;
  allocp[19] = x4;
  allocp[20] = x5;
  allocp[21] = x6;
  x14 = arg(a3, 0);
  allocp[22] = x14;
  x15 = arg(a3, 1);
  allocp[23] = x15;
  allocp[24] = x16 = makeref(&allocp[24]);
  allocp[25] = a5;
  allocp[26] = x17 = makeref(&allocp[26]);
  allocp[27] = x13;
  allocp[28] = a8;
  allocp[29] = a9;
  allocp[30] = makesym(functor_v_4);
  allocp[31] = x3;
  allocp[32] = x4;
  allocp[33] = x14;
  allocp[34] = x15;
  x18 = makefunctor(&allocp[30]);
  allocp[35] = makesym(functor_v_4);
  allocp[36] = x3;
  allocp[37] = x4;
  x20 = arg(a4, 0);
  allocp[38] = x20;
  x21 = arg(a4, 1);
  allocp[39] = x21;
  x19 = makefunctor(&allocp[35]);
  allocp[40] = (q)(struct goalrec*)&allocp[16];
  allocp[41] = (q)(&predicate_typeset_xentry__unifyset_4);
  allocp[42] = x18;
  allocp[43] = x19;
  allocp[44] = a6;
  allocp[45] = x17;
  a0 = a1;
  a1 = a2;
  a2 = x16;
  a3 = a5;
  qp = (struct goalrec*)&allocp[40];
  allocp += 46;
  execute(add__dgoal_4_clear_reason);
  goto add__dgoal_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a4,unify__equal_10_11);
  *reasonp++ =  a4;
  goto unify__equal_10_12;
  };
  goto unify__equal_10_12;
 case VARREF:
  deref_and_jump(a3,unify__equal_10_10);
  *reasonp++ =  a3;
  goto unify__equal_10_12;
  };
  goto unify__equal_10_12;
 case VARREF:
  deref_and_jump(x1,unify__equal_10_9);
  *reasonp++ =  x1;
  goto unify__equal_10_12;
  };
  goto unify__equal_10_12;
 case VARREF:
  deref_and_jump(x0,unify__equal_10_8);
  *reasonp++ =  x0;
  goto unify__equal_10_12;
  };
  goto unify__equal_10_12;
 case VARREF:
  deref_and_jump(a0,unify__equal_10_7);
  *reasonp++ =  a0;
  goto unify__equal_10_12;
  };
  goto unify__equal_10_12;
 unify__equal_10_12:
  otherwise(unify__equal_10_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xunify__typeset_12);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a0;
  allocp[5] = a1;
  allocp[6] = a2;
  allocp[7] = a3;
  allocp[8] = a4;
  allocp[9] = a5;
  allocp[10] = a6;
  allocp[11] = a7;
  allocp[12] = a8;
  allocp[13] = a9;
  allocp[14] = (q)(struct goalrec*)&allocp[0];
  allocp[15] = (q)(&predicate_typeset_xcheck__dg_4);
  allocp[16] = a2;
  allocp[17] = a1;
  allocp[18] = x1;
  allocp[19] = a5;
  x2 = a2;
  a1 = a0;
  a2 = x0;
  a3 = a5;
  a0 = x2;
  qp = (struct goalrec*)&allocp[14];
  allocp += 20;
  execute(check__dg_4_0);
  goto check__dg_4_ext_interrupt;
 unify__equal_10_ext_interrupt:
  reasonp = 0l;
 unify__equal_10_interrupt:
  goto interrupt_10;
 }

 unify__typeset_12_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 unify__typeset_12_clear_reason:
  reasonp = reasons;
 unify__typeset_12_0:
 unify__typeset_12_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto unify__typeset_12_12;
  switch (symval(a0)) {
 case symval(makesym(atom_no)):
 unify__typeset_12_2:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_yes)) goto unify__typeset_12_12;
 unify__typeset_12_3:
  switch (ptagof(a7)) {
 case ATOMIC:
  if (a7 != makesym(atom_normal)) goto unify__typeset_12_12;
 unify__typeset_12_4:
  switch (ptagof(a4)) {
 case FUNCTOR:
  if (functor_of(a4) != makesym(functor_goal_4)) goto unify__typeset_12_12;
 unify__typeset_12_5:
  switch (ptagof(a5)) {
 case FUNCTOR:
  if (functor_of(a5) != makesym(functor_variable_3)) goto unify__typeset_12_12;
 unify__typeset_12_6:
  switch (ptagof(a6)) {
 case FUNCTOR:
  if (functor_of(a6) != makesym(functor_variable_3)) goto unify__typeset_12_12;
  allocp[0] = makesym(functor_v_4);
  x1 = arg(a4, 0);
  allocp[1] = x1;
  x2 = arg(a4, 1);
  allocp[2] = x2;
  x3 = arg(a6, 0);
  allocp[3] = x3;
  x4 = arg(a6, 1);
  allocp[4] = x4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_v_4);
  x6 = arg(a4, 0);
  allocp[6] = x6;
  x7 = arg(a4, 1);
  allocp[7] = x7;
  x8 = arg(a5, 0);
  allocp[8] = x8;
  x9 = arg(a5, 1);
  allocp[9] = x9;
  x5 = makefunctor(&allocp[5]);
  allocp[10] = (q)qp;
  allocp[11] = (q)(&predicate_vt_xdelete__iu_4);
  allocp[12] = x0;
  allocp[13] = x5;
  allocp[14] = x10 = makeref(&allocp[14]);
  allocp[15] = a9;
  allocp[16] = (q)(struct goalrec*)&allocp[10];
  allocp[17] = (q)(&predicate_typeset_xset_12);
  x11 = arg(a4, 0);
  allocp[18] = x11;
  x12 = arg(a4, 1);
  allocp[19] = x12;
  x13 = arg(a4, 2);
  allocp[20] = x13;
  x14 = arg(a4, 3);
  allocp[21] = x14;
  x15 = arg(a6, 0);
  allocp[22] = x15;
  x16 = arg(a6, 1);
  allocp[23] = x16;
  allocp[24] = x17 = makeref(&allocp[24]);
  allocp[25] = a7;
  allocp[26] = a8;
  allocp[27] = x10;
  allocp[28] = a10;
  allocp[29] = a11;
  a0 = a2;
  a1 = a4;
  a2 = x17;
  a3 = a7;
  qp = (struct goalrec*)&allocp[16];
  allocp += 30;
  execute(add__dgoal_4_0);
  goto add__dgoal_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a6,unify__typeset_12_6);
  *reasonp++ =  a6;
  goto unify__typeset_12_12;
  };
  goto unify__typeset_12_12;
 case VARREF:
  deref_and_jump(a5,unify__typeset_12_5);
  *reasonp++ =  a5;
  goto unify__typeset_12_12;
  };
  goto unify__typeset_12_12;
 case VARREF:
  deref_and_jump(a4,unify__typeset_12_4);
  *reasonp++ =  a4;
  goto unify__typeset_12_12;
  };
  goto unify__typeset_12_12;
 case VARREF:
  deref_and_jump(a7,unify__typeset_12_3);
  *reasonp++ =  a7;
  goto unify__typeset_12_12;
  };
  goto unify__typeset_12_12;
 case VARREF:
  deref_and_jump(a1,unify__typeset_12_2);
  *reasonp++ =  a1;
  goto unify__typeset_12_12;
  };
  goto unify__typeset_12_12;
 case symval(makesym(atom_yes)):
 unify__typeset_12_7:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_no)) goto unify__typeset_12_12;
 unify__typeset_12_8:
  switch (ptagof(a7)) {
 case ATOMIC:
  if (a7 != makesym(atom_normal)) goto unify__typeset_12_12;
 unify__typeset_12_9:
  switch (ptagof(a4)) {
 case FUNCTOR:
  if (functor_of(a4) != makesym(functor_goal_4)) goto unify__typeset_12_12;
 unify__typeset_12_10:
  switch (ptagof(a5)) {
 case FUNCTOR:
  if (functor_of(a5) != makesym(functor_variable_3)) goto unify__typeset_12_12;
 unify__typeset_12_11:
  switch (ptagof(a6)) {
 case FUNCTOR:
  if (functor_of(a6) != makesym(functor_variable_3)) goto unify__typeset_12_12;
  allocp[0] = makesym(functor_v_4);
  x1 = arg(a4, 0);
  allocp[1] = x1;
  x2 = arg(a4, 1);
  allocp[2] = x2;
  x3 = arg(a5, 0);
  allocp[3] = x3;
  x4 = arg(a5, 1);
  allocp[4] = x4;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_v_4);
  x6 = arg(a4, 0);
  allocp[6] = x6;
  x7 = arg(a4, 1);
  allocp[7] = x7;
  x8 = arg(a6, 0);
  allocp[8] = x8;
  x9 = arg(a6, 1);
  allocp[9] = x9;
  x5 = makefunctor(&allocp[5]);
  allocp[10] = (q)qp;
  allocp[11] = (q)(&predicate_vt_xdelete__iu_4);
  allocp[12] = x0;
  allocp[13] = x5;
  allocp[14] = x10 = makeref(&allocp[14]);
  allocp[15] = a9;
  allocp[16] = (q)(struct goalrec*)&allocp[10];
  allocp[17] = (q)(&predicate_typeset_xset_12);
  x11 = arg(a4, 0);
  allocp[18] = x11;
  x12 = arg(a4, 1);
  allocp[19] = x12;
  x13 = arg(a4, 2);
  allocp[20] = x13;
  x14 = arg(a4, 3);
  allocp[21] = x14;
  x15 = arg(a5, 0);
  allocp[22] = x15;
  x16 = arg(a5, 1);
  allocp[23] = x16;
  allocp[24] = x17 = makeref(&allocp[24]);
  allocp[25] = a7;
  allocp[26] = a8;
  allocp[27] = x10;
  allocp[28] = a10;
  allocp[29] = a11;
  a0 = a3;
  a1 = a4;
  a2 = x17;
  a3 = a7;
  qp = (struct goalrec*)&allocp[16];
  allocp += 30;
  execute(add__dgoal_4_0);
  goto add__dgoal_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a6,unify__typeset_12_11);
  *reasonp++ =  a6;
  goto unify__typeset_12_12;
  };
  goto unify__typeset_12_12;
 case VARREF:
  deref_and_jump(a5,unify__typeset_12_10);
  *reasonp++ =  a5;
  goto unify__typeset_12_12;
  };
  goto unify__typeset_12_12;
 case VARREF:
  deref_and_jump(a4,unify__typeset_12_9);
  *reasonp++ =  a4;
  goto unify__typeset_12_12;
  };
  goto unify__typeset_12_12;
 case VARREF:
  deref_and_jump(a7,unify__typeset_12_8);
  *reasonp++ =  a7;
  goto unify__typeset_12_12;
  };
  goto unify__typeset_12_12;
 case VARREF:
  deref_and_jump(a1,unify__typeset_12_7);
  *reasonp++ =  a1;
  goto unify__typeset_12_12;
  };
  goto unify__typeset_12_12;
  };
  goto unify__typeset_12_12;
 case VARREF:
  deref_and_jump(a0,unify__typeset_12_1);
  *reasonp++ =  a0;
  goto unify__typeset_12_12;
  };
  goto unify__typeset_12_12;
 unify__typeset_12_12:
  otherwise(unify__typeset_12_interrupt);
 unify__typeset_12_13:
  switch (ptagof(a7)) {
 case ATOMIC:
  if (a7 != makesym(atom_expand)) goto unify__typeset_12_17;
 unify__typeset_12_14:
  switch (ptagof(a4)) {
 case FUNCTOR:
  if (functor_of(a4) != makesym(functor_goal_4)) goto unify__typeset_12_17;
 unify__typeset_12_15:
  switch (ptagof(a5)) {
 case FUNCTOR:
  if (functor_of(a5) != makesym(functor_variable_3)) goto unify__typeset_12_17;
 unify__typeset_12_16:
  switch (ptagof(a6)) {
 case FUNCTOR:
  if (functor_of(a6) != makesym(functor_variable_3)) goto unify__typeset_12_17;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xset_12);
  x0 = arg(a4, 0);
  allocp[2] = x0;
  x1 = arg(a4, 1);
  allocp[3] = x1;
  x2 = arg(a4, 2);
  allocp[4] = x2;
  x3 = arg(a4, 3);
  allocp[5] = x3;
  x4 = arg(a6, 0);
  allocp[6] = x4;
  x5 = arg(a6, 1);
  allocp[7] = x5;
  allocp[8] = x6 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x7 = makeref(&allocp[10]);
  allocp[11] = a9;
  allocp[12] = x8 = makeref(&allocp[12]);
  allocp[13] = a11;
  allocp[14] = (q)(struct goalrec*)&allocp[0];
  allocp[15] = (q)(&predicate_typeset_xset_12);
  allocp[16] = x0;
  allocp[17] = x1;
  allocp[18] = x2;
  allocp[19] = x3;
  x9 = arg(a5, 0);
  allocp[20] = x9;
  x10 = arg(a5, 1);
  allocp[21] = x10;
  allocp[22] = x11 = makeref(&allocp[22]);
  allocp[23] = a7;
  allocp[24] = a8;
  allocp[25] = x7;
  allocp[26] = a10;
  allocp[27] = x8;
  allocp[28] = (q)(struct goalrec*)&allocp[14];
  allocp[29] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[30] = a3;
  allocp[31] = x12 = makeref(&allocp[31]);
  allocp[32] = x6;
  allocp[33] = (q)(struct goalrec*)&allocp[28];
  allocp[34] = (q)(&predicate_typeset_xor__typeset_3);
  allocp[35] = a2;
  allocp[36] = x13 = makeref(&allocp[36]);
  allocp[37] = x11;
  allocp[38] = (q)(struct goalrec*)&allocp[33];
  allocp[39] = (q)(&predicate_typeset_xmake__expand__ts_4);
  allocp[40] = x14 = makeref(&allocp[40]);
  allocp[41] = x15 = makeref(&allocp[41]);
  allocp[42] = a4;
  allocp[43] = x13;
  allocp[44] = (q)(struct goalrec*)&allocp[38];
  allocp[45] = (q)(&predicate_typeset_xmake__expand__ts_4);
  allocp[46] = x15;
  allocp[47] = x14;
  allocp[48] = a4;
  allocp[49] = x12;
  allocp[50] = (q)(struct goalrec*)&allocp[44];
  allocp[51] = (q)(&predicate_typeset_xsplit__tt_3);
  allocp[52] = a3;
  allocp[53] = x15;
  allocp[54] = x16 = makeref(&allocp[54]);
  a0 = a2;
  a1 = x14;
  allocp[55] = x17 = makeref(&allocp[55]);
  a2 = x17;
  qp = (struct goalrec*)&allocp[50];
  allocp += 56;
  execute(split__tt_3_0);
  goto split__tt_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a6,unify__typeset_12_16);
  *reasonp++ =  a6;
  goto unify__typeset_12_17;
  };
  goto unify__typeset_12_17;
 case VARREF:
  deref_and_jump(a5,unify__typeset_12_15);
  *reasonp++ =  a5;
  goto unify__typeset_12_17;
  };
  goto unify__typeset_12_17;
 case VARREF:
  deref_and_jump(a4,unify__typeset_12_14);
  *reasonp++ =  a4;
  goto unify__typeset_12_17;
  };
  goto unify__typeset_12_17;
 case VARREF:
  deref_and_jump(a7,unify__typeset_12_13);
  *reasonp++ =  a7;
  goto unify__typeset_12_17;
  };
  goto unify__typeset_12_17;
 unify__typeset_12_17:
  otherwise(unify__typeset_12_interrupt);
 unify__typeset_12_18:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_no)) goto unify__typeset_12_20;
 unify__typeset_12_19:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_no)) goto unify__typeset_12_20;
  a0 = a2;
  a1 = a3;
  a2 = a4;
  a3 = a7;
  a4 = a8;
  a5 = a9;
  a6 = a10;
  a7 = a11;
  execute(unify_8_0);
  goto unify_8_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,unify__typeset_12_19);
  *reasonp++ =  a1;
  goto unify__typeset_12_20;
  };
  goto unify__typeset_12_20;
 case VARREF:
  deref_and_jump(a0,unify__typeset_12_18);
  *reasonp++ =  a0;
  goto unify__typeset_12_20;
  };
  goto unify__typeset_12_20;
 unify__typeset_12_20:
  otherwise(unify__typeset_12_interrupt);
 unify__typeset_12_21:
  if (isref(a5)) goto unify__typeset_12_29;
  gblt_pfunctor(a5,x0,unify__typeset_12_interrupt);
  if (x0 != makesym(atom_variable)) goto unify__typeset_12_25;
  gblt_arity(a5,x1,unify__typeset_12_25);
 unify__typeset_12_22:
  if (x1 != makeint(3L)) goto unify__typeset_12_25;
 unify__typeset_12_23:
  if (isref(a6)) goto unify__typeset_12_24;
  gblt_pfunctor(a6,x2,unify__typeset_12_25);
  gblt_arity(a6,x3,unify__typeset_12_25);
  x4 = makesym(atom_variable);
  gblt_diff(x2,x4,unify__typeset_12_25);
  x5 = makeint(3L);
  gblt_not_eq(x3,x5,unify__typeset_12_25);
  a0 = a2;
  a1 = a3;
  a2 = a4;
  a3 = a7;
  a4 = a8;
  a5 = a9;
  a6 = a10;
  a7 = a11;
  execute(unify_8_0);
  goto unify_8_ext_interrupt;
 unify__typeset_12_24:
  deref_and_jump(a6,unify__typeset_12_23);
  *reasonp++ =  a6;
  goto unify__typeset_12_25;
 unify__typeset_12_25:
  gblt_arity(a5,x6,unify__typeset_12_interrupt);
  x7 = makesym(atom_variable);
  gblt_diff(x0,x7,unify__typeset_12_interrupt);
  x8 = makeint(3L);
  gblt_not_eq(x6,x8,unify__typeset_12_interrupt);
 unify__typeset_12_26:
  if (isref(a6)) goto unify__typeset_12_28;
  gblt_pfunctor(a6,x9,unify__typeset_12_interrupt);
  if (x9 != makesym(atom_variable)) goto unify__typeset_12_interrupt;
  gblt_arity(a6,x10,unify__typeset_12_interrupt);
 unify__typeset_12_27:
  if (x10 != makeint(3L)) goto unify__typeset_12_interrupt;
  a0 = a2;
  a1 = a3;
  a2 = a4;
  a3 = a7;
  a4 = a8;
  a5 = a9;
  a6 = a10;
  a7 = a11;
  execute(unify_8_clear_reason);
  goto unify_8_ext_interrupt;
 unify__typeset_12_28:
  deref_and_jump(a6,unify__typeset_12_26);
  *reasonp++ =  a6;
  goto unify__typeset_12_interrupt;
 unify__typeset_12_29:
  deref_and_jump(a5,unify__typeset_12_21);
  *reasonp++ =  a5;
  goto unify__typeset_12_interrupt;
 unify__typeset_12_ext_interrupt:
  reasonp = 0l;
 unify__typeset_12_interrupt:
  goto interrupt_12;
 }

 unify_8_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 unify_8_clear_reason:
  reasonp = reasons;
 unify_8_0:
  x0 = a0;
  x1 = a1;
  x2 = a0;
  x3 = a1;
  x4 = a3;
  x5 = a4;
  x6 = a5;
  a8 = a6;
  a9 = a7;
  a7 = x6;
  a6 = x5;
  a5 = x4;
  a4 = x3;
  a3 = x2;
  a1 = x1;
  a0 = x0;
  execute(unify_10_0);
  goto unify_10_ext_interrupt;
 unify_8_ext_interrupt:
  reasonp = 0l;
 unify_8_interrupt:
  toppred = &predicate_typeset_xunify_8;
  goto interrupt_8;
 }

 unify_10_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 unify_10_clear_reason:
  reasonp = reasons;
 unify_10_0:
 unify_10_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xunify_10);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x2 = makeref(&allocp[10]);
  allocp[11] = a9;
  a0 = car_of(a0);
  a7 = x1;
  a9 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  execute(unify2_10_0);
  goto unify2_10_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto unify_10_interrupt;
  unify2(a9, a8, a7, a6);
  proceed();
 case VARREF:
  deref_and_jump(a0,unify_10_1);
  *reasonp++ =  a0;
  goto unify_10_interrupt;
  };
  goto unify_10_interrupt;
 unify_10_ext_interrupt:
  reasonp = 0l;
 unify_10_interrupt:
  toppred = &predicate_typeset_xunify_10;
  goto interrupt_10;
 }

 unify2_10_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 unify2_10_clear_reason:
  reasonp = reasons;
 unify2_10_0:
 unify2_10_1:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xunify2_10);
  allocp[2] = a0;
  x0 = cdr_of(a1);
  allocp[3] = x0;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x2 = makeref(&allocp[10]);
  allocp[11] = a9;
  a1 = car_of(a1);
  a7 = x1;
  a9 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  execute(unify__type_10_0);
  goto unify__type_10_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto unify2_10_interrupt;
  unify2(a9, a8, a7, a6);
  proceed();
 case VARREF:
  deref_and_jump(a1,unify2_10_1);
  *reasonp++ =  a1;
  goto unify2_10_interrupt;
  };
  goto unify2_10_interrupt;
 unify2_10_ext_interrupt:
  reasonp = 0l;
 unify2_10_interrupt:
  toppred = &predicate_typeset_xunify2_10;
  goto interrupt_10;
 }

 unify__type_10_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 unify__type_10_clear_reason:
  reasonp = reasons;
 unify__type_10_0:
 unify__type_10_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_t_2:
 unify__type_10_2:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_t_2)) goto unify__type_10_22;
  x0 = arg(a1, 0);
 unify__type_10_3:
  if (isref(x0)) goto unify__type_10_6;
 unify__type_10_4:
  if (isref(x0)) goto unify__type_10_5;
  x1 = arg(a0, 0);
  if_not_equal(x0, x1, unify__type_10_22);
  unify2(a9, a8, a7, a6);
  proceed();
 unify__type_10_5:
  deref_and_jump(x0,unify__type_10_4);
  *reasonp++ =  x0;
  goto unify__type_10_22;
 unify__type_10_6:
  deref_and_jump(x0,unify__type_10_3);
  *reasonp++ =  x0;
  goto unify__type_10_22;
 case VARREF:
  deref_and_jump(a1,unify__type_10_2);
  *reasonp++ =  a1;
  goto unify__type_10_22;
  };
  goto unify__type_10_22;
 case functor_tv_2:
  x0 = arg(a0, 0);
 unify__type_10_7:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_v_4)) goto unify__type_10_22;
 unify__type_10_8:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_tv_2)) goto unify__type_10_22;
  x1 = arg(a1, 0);
 unify__type_10_9:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_v_4)) goto unify__type_10_22;
  x2 = arg(x1, 0);
 unify__type_10_10:
  if (isref(x2)) goto unify__type_10_21;
 unify__type_10_11:
  if (isref(x2)) goto unify__type_10_20;
  x3 = arg(x0, 0);
  if_not_equal(x2, x3, unify__type_10_22);
  x4 = arg(x1, 1);
 unify__type_10_12:
  if (isref(x4)) goto unify__type_10_19;
 unify__type_10_13:
  if (isref(x4)) goto unify__type_10_18;
  x5 = arg(x0, 1);
  if_not_equal(x4, x5, unify__type_10_22);
  x6 = arg(x1, 2);
 unify__type_10_14:
  if (isref(x6)) goto unify__type_10_17;
 unify__type_10_15:
  if (isref(x6)) goto unify__type_10_16;
  x7 = arg(x0, 2);
  if_not_equal(x6, x7, unify__type_10_22);
  unify2(a9, a8, a7, a6);
  proceed();
 unify__type_10_16:
  deref_and_jump(x6,unify__type_10_15);
  *reasonp++ =  x6;
  goto unify__type_10_22;
 unify__type_10_17:
  deref_and_jump(x6,unify__type_10_14);
  *reasonp++ =  x6;
  goto unify__type_10_22;
 unify__type_10_18:
  deref_and_jump(x4,unify__type_10_13);
  *reasonp++ =  x4;
  goto unify__type_10_22;
 unify__type_10_19:
  deref_and_jump(x4,unify__type_10_12);
  *reasonp++ =  x4;
  goto unify__type_10_22;
 unify__type_10_20:
  deref_and_jump(x2,unify__type_10_11);
  *reasonp++ =  x2;
  goto unify__type_10_22;
 unify__type_10_21:
  deref_and_jump(x2,unify__type_10_10);
  *reasonp++ =  x2;
  goto unify__type_10_22;
 case VARREF:
  deref_and_jump(x1,unify__type_10_9);
  *reasonp++ =  x1;
  goto unify__type_10_22;
  };
  goto unify__type_10_22;
 case VARREF:
  deref_and_jump(a1,unify__type_10_8);
  *reasonp++ =  a1;
  goto unify__type_10_22;
  };
  goto unify__type_10_22;
 case VARREF:
  deref_and_jump(x0,unify__type_10_7);
  *reasonp++ =  x0;
  goto unify__type_10_22;
  };
  goto unify__type_10_22;
  };
  goto unify__type_10_22;
 case VARREF:
  deref_and_jump(a0,unify__type_10_1);
  *reasonp++ =  a0;
  goto unify__type_10_22;
  };
  goto unify__type_10_22;
 unify__type_10_22:
  otherwise(unify__type_10_interrupt);
 unify__type_10_23:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (a5 != makesym(atom_normal)) goto unify__type_10_47;
 unify__type_10_24:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_t_2)) goto unify__type_10_47;
  x0 = arg(a0, 0);
 unify__type_10_25:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_s_3)) goto unify__type_10_47;
  x1 = arg(x0, 1);
 unify__type_10_26:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom__2A)) goto unify__type_10_34;
 unify__type_10_27:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_t_2)) goto unify__type_10_34;
  x2 = arg(a1, 0);
 unify__type_10_28:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_s_3)) goto unify__type_10_34;
  x3 = arg(x2, 0);
 unify__type_10_29:
  if (isref(x3)) goto unify__type_10_33;
 unify__type_10_30:
  if (isref(x3)) goto unify__type_10_32;
  x4 = arg(x0, 0);
  if_not_equal(x3, x4, unify__type_10_34);
  x5 = arg(x2, 1);
 unify__type_10_31:
  switch (ptagof(x5)) {
 case ATOMIC:
  if (x5 != makesym(atom__2A)) goto unify__type_10_34;
  a0 = arg(x0, 2);
  a1 = arg(x2, 2);
  a3 = a5;
  a4 = a6;
  a5 = a7;
  a6 = a8;
  a7 = a9;
  execute(unify_8_clear_reason);
  goto unify_8_ext_interrupt;
 case VARREF:
  deref_and_jump(x5,unify__type_10_31);
  *reasonp++ =  x5;
  goto unify__type_10_34;
  };
  goto unify__type_10_34;
 unify__type_10_32:
  deref_and_jump(x3,unify__type_10_30);
  *reasonp++ =  x3;
  goto unify__type_10_34;
 unify__type_10_33:
  deref_and_jump(x3,unify__type_10_29);
  *reasonp++ =  x3;
  goto unify__type_10_34;
 case VARREF:
  deref_and_jump(x2,unify__type_10_28);
  *reasonp++ =  x2;
  goto unify__type_10_34;
  };
  goto unify__type_10_34;
 case VARREF:
  deref_and_jump(a1,unify__type_10_27);
  *reasonp++ =  a1;
  goto unify__type_10_34;
  };
  goto unify__type_10_34;
 case VARREF:
  deref_and_jump(x1,unify__type_10_26);
  *reasonp++ =  x1;
  goto unify__type_10_34;
  };
  goto unify__type_10_34;
 unify__type_10_34:
 unify__type_10_35:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_t_2)) goto unify__type_10_47;
  x2 = arg(a1, 0);
 unify__type_10_36:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_s_3)) goto unify__type_10_47;
  x3 = arg(x2, 0);
 unify__type_10_37:
  if (isref(x3)) goto unify__type_10_46;
 unify__type_10_38:
  if (isref(x3)) goto unify__type_10_45;
  x4 = arg(x0, 0);
  if_not_equal(x3, x4, unify__type_10_47);
  x5 = arg(x2, 1);
 unify__type_10_39:
  if (isref(x5)) goto unify__type_10_44;
 unify__type_10_40:
  if (isref(x5)) goto unify__type_10_43;
  if_not_equal(x5, x1, unify__type_10_47);
 unify__type_10_41:
  if (!isint(x1)) goto unify__type_10_42;
  gblt_integer(x1,unify__type_10_47);
  a0 = x1;
  a1 = arg(x0, 2);
  x6 = arg(x2, 2);
  a3 = a2;
  a4 = a5;
  a5 = a6;
  a6 = a7;
  a7 = a8;
  a8 = a9;
  a2 = x6;
  execute(unify__struct_9_clear_reason);
  goto unify__struct_9_ext_interrupt;
 unify__type_10_42:
  if (!isref(x1)) goto unify__type_10_47;
  deref_and_jump(x1,unify__type_10_41);
  *reasonp++ =  x1;
  goto unify__type_10_47;
 unify__type_10_43:
  deref_and_jump(x5,unify__type_10_40);
  *reasonp++ =  x5;
  goto unify__type_10_47;
 unify__type_10_44:
  deref_and_jump(x5,unify__type_10_39);
  *reasonp++ =  x5;
  goto unify__type_10_47;
 unify__type_10_45:
  deref_and_jump(x3,unify__type_10_38);
  *reasonp++ =  x3;
  goto unify__type_10_47;
 unify__type_10_46:
  deref_and_jump(x3,unify__type_10_37);
  *reasonp++ =  x3;
  goto unify__type_10_47;
 case VARREF:
  deref_and_jump(x2,unify__type_10_36);
  *reasonp++ =  x2;
  goto unify__type_10_47;
  };
  goto unify__type_10_47;
 case VARREF:
  deref_and_jump(a1,unify__type_10_35);
  *reasonp++ =  a1;
  goto unify__type_10_47;
  };
  goto unify__type_10_47;
 case VARREF:
  deref_and_jump(x0,unify__type_10_25);
  *reasonp++ =  x0;
  goto unify__type_10_47;
  };
  goto unify__type_10_47;
 case VARREF:
  deref_and_jump(a0,unify__type_10_24);
  *reasonp++ =  a0;
  goto unify__type_10_47;
  };
  goto unify__type_10_47;
 case VARREF:
  deref_and_jump(a5,unify__type_10_23);
  *reasonp++ =  a5;
  goto unify__type_10_47;
  };
  goto unify__type_10_47;
 unify__type_10_47:
  otherwise(unify__type_10_interrupt);
 unify__type_10_48:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (a5 != makesym(atom_normal)) goto unify__type_10_56;
 unify__type_10_49:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_tv_2:
 unify__type_10_50:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_t_2)) goto unify__type_10_51;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xcondition1_11);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = a8;
  allocp[12] = a9;
  allocp[13] = (q)(struct goalrec*)&allocp[0];
  allocp[14] = (q)(&predicate_depset_xcheck__include_3);
  allocp[15] = a2;
  x1 = arg(a1, 1);
  allocp[16] = x1;
  allocp[17] = x0;
  qp = (struct goalrec*)&allocp[13];
  allocp += 18;
  proceed();
 case VARREF:
  deref_and_jump(a1,unify__type_10_50);
  *reasonp++ =  a1;
  goto unify__type_10_51;
  };
  goto unify__type_10_51;
 unify__type_10_51:
  x0 = arg(a0, 0);
 unify__type_10_52:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_v_4)) goto unify__type_10_56;
 unify__type_10_53:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_tv_2)) goto unify__type_10_56;
  x1 = arg(a1, 0);
 unify__type_10_54:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_v_4)) goto unify__type_10_56;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xcondition2_14);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = a0;
  allocp[5] = a1;
  allocp[6] = x4 = makeref(&allocp[6]);
  allocp[7] = x5 = makeref(&allocp[7]);
  allocp[8] = a2;
  allocp[9] = a3;
  allocp[10] = a4;
  allocp[11] = a5;
  allocp[12] = a6;
  allocp[13] = a7;
  allocp[14] = a8;
  allocp[15] = a9;
  allocp[16] = (q)(struct goalrec*)&allocp[0];
  allocp[17] = (q)(&predicate_typeset_xcheck__dg_4);
  allocp[18] = a2;
  allocp[19] = x5;
  allocp[20] = x3;
  allocp[21] = a5;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_typeset_xcheck__dg_4);
  allocp[24] = a2;
  allocp[25] = x4;
  allocp[26] = x2;
  allocp[27] = a5;
  allocp[28] = (q)(struct goalrec*)&allocp[22];
  allocp[29] = (q)(&predicate_typeset_xget_5);
  x6 = arg(x1, 0);
  allocp[30] = x6;
  x7 = arg(x1, 1);
  allocp[31] = x7;
  x8 = arg(x1, 2);
  allocp[32] = x8;
  allocp[33] = x5;
  allocp[34] = a6;
  a0 = arg(x0, 0);
  a1 = arg(x0, 1);
  a2 = arg(x0, 2);
  a3 = x4;
  a4 = a6;
  qp = (struct goalrec*)&allocp[28];
  allocp += 35;
  execute(get_5_clear_reason);
  goto get_5_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,unify__type_10_54);
  *reasonp++ =  x1;
  goto unify__type_10_56;
  };
  goto unify__type_10_56;
 case VARREF:
  deref_and_jump(a1,unify__type_10_53);
  *reasonp++ =  a1;
  goto unify__type_10_56;
  };
  goto unify__type_10_56;
 case VARREF:
  deref_and_jump(x0,unify__type_10_52);
  *reasonp++ =  x0;
  goto unify__type_10_56;
  };
  goto unify__type_10_56;
 case functor_t_2:
 unify__type_10_55:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_tv_2)) goto unify__type_10_56;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xcondition1_11);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a0;
  allocp[5] = a2;
  allocp[6] = a4;
  allocp[7] = a3;
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = a8;
  allocp[12] = a9;
  allocp[13] = (q)(struct goalrec*)&allocp[0];
  allocp[14] = (q)(&predicate_depset_xcheck__include_3);
  allocp[15] = a2;
  x1 = arg(a0, 1);
  allocp[16] = x1;
  allocp[17] = x0;
  qp = (struct goalrec*)&allocp[13];
  allocp += 18;
  proceed();
 case VARREF:
  deref_and_jump(a1,unify__type_10_55);
  *reasonp++ =  a1;
  goto unify__type_10_56;
  };
  goto unify__type_10_56;
  };
  goto unify__type_10_56;
 case VARREF:
  deref_and_jump(a0,unify__type_10_49);
  *reasonp++ =  a0;
  goto unify__type_10_56;
  };
  goto unify__type_10_56;
 case VARREF:
  deref_and_jump(a5,unify__type_10_48);
  *reasonp++ =  a5;
  goto unify__type_10_56;
  };
  goto unify__type_10_56;
 unify__type_10_56:
  otherwise(unify__type_10_interrupt);
  unify2(a9, a8, a7, a6);
  proceed();
 unify__type_10_ext_interrupt:
  reasonp = 0l;
 unify__type_10_interrupt:
  toppred = &predicate_typeset_xunify__type_10;
  goto interrupt_10;
 }

 condition1_11_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 condition1_11_clear_reason:
  reasonp = reasons;
 condition1_11_0:
 condition1_11_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto condition1_11_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  unify2(a10, a9, a8, a7);
  proceed();
 case symval(makesym(atom_no)):
  allocp[0] = makesym(functor_v_4);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  x0 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_tv_2);
  allocp[6] = x0;
  allocp[7] = x6 = makeref(&allocp[7]);
  x5 = makefunctor(&allocp[5]);
  allocp += 8;
  unify_value(a1, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xset_12);
  allocp[2] = x1;
  allocp[3] = x2;
  allocp[4] = makesym(atom___);
  allocp[5] = makesym(atom___);
  allocp[6] = x3;
  allocp[7] = x4;
  allocp[8] = x7 = makeref(&allocp[8]);
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = a8;
  allocp[12] = a9;
  allocp[13] = a10;
  a0 = a5;
  a1 = a3;
  a2 = x7;
  a3 = a6;
  qp = (struct goalrec*)&allocp[0];
  allocp += 14;
  execute(add__dgoal_4_0);
  goto add__dgoal_4_ext_interrupt;
  };
  goto condition1_11_interrupt;
 case VARREF:
  deref_and_jump(a0,condition1_11_1);
  *reasonp++ =  a0;
  goto condition1_11_interrupt;
  };
  goto condition1_11_interrupt;
 condition1_11_ext_interrupt:
  reasonp = 0l;
 condition1_11_interrupt:
  goto interrupt_11;
 }

 condition2_14_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20, x21, x22;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  qp = qp->next;
 condition2_14_clear_reason:
  reasonp = reasons;
 condition2_14_0:
 condition2_14_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_no)) goto condition2_14_9;
 condition2_14_2:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_no)) goto condition2_14_9;
 condition2_14_3:
  switch (ptagof(a4)) {
 case CONS:
  x0 = car_of(a4);
 condition2_14_4:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto condition2_14_9;
  x1 = cdr_of(a4);
 condition2_14_5:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto condition2_14_9;
 condition2_14_6:
  switch (ptagof(a5)) {
 case CONS:
  x2 = car_of(a5);
 condition2_14_7:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != makesym(atom__2A)) goto condition2_14_9;
  x3 = cdr_of(a5);
 condition2_14_8:
  switch (ptagof(x3)) {
 case ATOMIC:
  if (x3 != NILATOM) goto condition2_14_9;
  unify2(a13, a12, a11, a10);
  proceed();
 case VARREF:
  deref_and_jump(x3,condition2_14_8);
  *reasonp++ =  x3;
  goto condition2_14_9;
  };
  goto condition2_14_9;
 case VARREF:
  deref_and_jump(x2,condition2_14_7);
  *reasonp++ =  x2;
  goto condition2_14_9;
  };
  goto condition2_14_9;
 case VARREF:
  deref_and_jump(a5,condition2_14_6);
  *reasonp++ =  a5;
  goto condition2_14_9;
  };
  goto condition2_14_9;
 case VARREF:
  deref_and_jump(x1,condition2_14_5);
  *reasonp++ =  x1;
  goto condition2_14_9;
  };
  goto condition2_14_9;
 case VARREF:
  deref_and_jump(x0,condition2_14_4);
  *reasonp++ =  x0;
  goto condition2_14_9;
  };
  goto condition2_14_9;
 case VARREF:
  deref_and_jump(a4,condition2_14_3);
  *reasonp++ =  a4;
  goto condition2_14_9;
  };
  goto condition2_14_9;
 case VARREF:
  deref_and_jump(a1,condition2_14_2);
  *reasonp++ =  a1;
  goto condition2_14_9;
  };
  goto condition2_14_9;
 case VARREF:
  deref_and_jump(a0,condition2_14_1);
  *reasonp++ =  a0;
  goto condition2_14_9;
  };
  goto condition2_14_9;
 condition2_14_9:
  otherwise(condition2_14_interrupt);
 condition2_14_10:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_no)) goto condition2_14_19;
 condition2_14_11:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_no)) goto condition2_14_19;
 condition2_14_12:
  switch (ptagof(a5)) {
 case CONS:
  x0 = car_of(a5);
 condition2_14_13:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto condition2_14_15;
  x1 = cdr_of(a5);
 condition2_14_14:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto condition2_14_15;
  allocp[0] = makesym(functor_v_4);
  allocp[1] = x3 = makeref(&allocp[1]);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = x6 = makeref(&allocp[4]);
  x2 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_tv_2);
  allocp[6] = x2;
  allocp[7] = x8 = makeref(&allocp[7]);
  x7 = makefunctor(&allocp[5]);
  allocp += 8;
  unify_value(a2, x7);
  allocp[0] = makesym(functor_v_4);
  allocp[1] = x10 = makeref(&allocp[1]);
  allocp[2] = x11 = makeref(&allocp[2]);
  allocp[3] = x12 = makeref(&allocp[3]);
  allocp[4] = x13 = makeref(&allocp[4]);
  x9 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_tv_2);
  allocp[6] = x9;
  allocp[7] = x15 = makeref(&allocp[7]);
  x14 = makefunctor(&allocp[5]);
  allocp += 8;
  unify_value(a3, x14);
  allocp[0] = makesym(functor_v_4);
  allocp[1] = x10;
  allocp[2] = x11;
  allocp[3] = x12;
  allocp[4] = x13;
  x16 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_v_4);
  allocp[6] = x3;
  allocp[7] = x4;
  allocp[8] = x5;
  allocp[9] = x6;
  x17 = makefunctor(&allocp[5]);
  allocp[10] = (q)qp;
  allocp[11] = (q)(&predicate_vt_xdelete__iu_4);
  allocp[12] = x16;
  allocp[13] = x17;
  allocp[14] = x18 = makeref(&allocp[14]);
  allocp[15] = a11;
  allocp[16] = (q)(struct goalrec*)&allocp[10];
  allocp[17] = (q)(&predicate_typeset_xset_12);
  allocp[18] = x10;
  allocp[19] = x11;
  allocp[20] = makesym(atom___);
  allocp[21] = makesym(atom___);
  allocp[22] = x12;
  allocp[23] = x13;
  allocp[24] = x19 = makeref(&allocp[24]);
  allocp[25] = a9;
  allocp[26] = x20 = makeref(&allocp[26]);
  allocp[27] = x18;
  allocp[28] = a12;
  allocp[29] = a13;
  allocp[30] = makesym(functor_v_4);
  allocp[31] = x3;
  allocp[32] = x4;
  allocp[33] = x5;
  allocp[34] = x6;
  x21 = makefunctor(&allocp[30]);
  allocp[35] = makesym(functor_v_4);
  allocp[36] = x10;
  allocp[37] = x11;
  allocp[38] = x12;
  allocp[39] = x13;
  x22 = makefunctor(&allocp[35]);
  allocp[40] = (q)(struct goalrec*)&allocp[16];
  allocp[41] = (q)(&predicate_typeset_xentry__unifyset_4);
  allocp[42] = x21;
  allocp[43] = x22;
  allocp[44] = a10;
  allocp[45] = x20;
  a0 = a7;
  a1 = a6;
  a2 = x19;
  a3 = a9;
  qp = (struct goalrec*)&allocp[40];
  allocp += 46;
  execute(add__dgoal_4_0);
  goto add__dgoal_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,condition2_14_14);
  *reasonp++ =  x1;
  goto condition2_14_15;
  };
  goto condition2_14_15;
 case VARREF:
  deref_and_jump(x0,condition2_14_13);
  *reasonp++ =  x0;
  goto condition2_14_15;
  };
  goto condition2_14_15;
 case VARREF:
  deref_and_jump(a5,condition2_14_12);
  *reasonp++ =  a5;
  goto condition2_14_15;
  };
  goto condition2_14_15;
 condition2_14_15:
 condition2_14_16:
  switch (ptagof(a4)) {
 case CONS:
  x0 = car_of(a4);
 condition2_14_17:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto condition2_14_19;
  x1 = cdr_of(a4);
 condition2_14_18:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto condition2_14_19;
  allocp[0] = makesym(functor_v_4);
  allocp[1] = x3 = makeref(&allocp[1]);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = x6 = makeref(&allocp[4]);
  x2 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_tv_2);
  allocp[6] = x2;
  allocp[7] = x8 = makeref(&allocp[7]);
  x7 = makefunctor(&allocp[5]);
  allocp += 8;
  unify_value(a2, x7);
  allocp[0] = makesym(functor_v_4);
  allocp[1] = x10 = makeref(&allocp[1]);
  allocp[2] = x11 = makeref(&allocp[2]);
  allocp[3] = x12 = makeref(&allocp[3]);
  allocp[4] = x13 = makeref(&allocp[4]);
  x9 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_tv_2);
  allocp[6] = x9;
  allocp[7] = x15 = makeref(&allocp[7]);
  x14 = makefunctor(&allocp[5]);
  allocp += 8;
  unify_value(a3, x14);
  allocp[0] = makesym(functor_v_4);
  allocp[1] = x3;
  allocp[2] = x4;
  allocp[3] = x5;
  allocp[4] = x6;
  x16 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_v_4);
  allocp[6] = x10;
  allocp[7] = x11;
  allocp[8] = x12;
  allocp[9] = x13;
  x17 = makefunctor(&allocp[5]);
  allocp[10] = (q)qp;
  allocp[11] = (q)(&predicate_vt_xdelete__iu_4);
  allocp[12] = x16;
  allocp[13] = x17;
  allocp[14] = x18 = makeref(&allocp[14]);
  allocp[15] = a11;
  allocp[16] = (q)(struct goalrec*)&allocp[10];
  allocp[17] = (q)(&predicate_typeset_xset_12);
  allocp[18] = x3;
  allocp[19] = x4;
  allocp[20] = makesym(atom___);
  allocp[21] = makesym(atom___);
  allocp[22] = x5;
  allocp[23] = x6;
  allocp[24] = x19 = makeref(&allocp[24]);
  allocp[25] = a9;
  allocp[26] = x20 = makeref(&allocp[26]);
  allocp[27] = x18;
  allocp[28] = a12;
  allocp[29] = a13;
  allocp[30] = makesym(functor_v_4);
  allocp[31] = x3;
  allocp[32] = x4;
  allocp[33] = x5;
  allocp[34] = x6;
  x21 = makefunctor(&allocp[30]);
  allocp[35] = makesym(functor_v_4);
  allocp[36] = x10;
  allocp[37] = x11;
  allocp[38] = x12;
  allocp[39] = x13;
  x22 = makefunctor(&allocp[35]);
  allocp[40] = (q)(struct goalrec*)&allocp[16];
  allocp[41] = (q)(&predicate_typeset_xentry__unifyset_4);
  allocp[42] = x21;
  allocp[43] = x22;
  allocp[44] = a10;
  allocp[45] = x20;
  a0 = a8;
  a1 = a6;
  a2 = x19;
  a3 = a9;
  qp = (struct goalrec*)&allocp[40];
  allocp += 46;
  execute(add__dgoal_4_clear_reason);
  goto add__dgoal_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,condition2_14_18);
  *reasonp++ =  x1;
  goto condition2_14_19;
  };
  goto condition2_14_19;
 case VARREF:
  deref_and_jump(x0,condition2_14_17);
  *reasonp++ =  x0;
  goto condition2_14_19;
  };
  goto condition2_14_19;
 case VARREF:
  deref_and_jump(a4,condition2_14_16);
  *reasonp++ =  a4;
  goto condition2_14_19;
  };
  goto condition2_14_19;
 case VARREF:
  deref_and_jump(a1,condition2_14_11);
  *reasonp++ =  a1;
  goto condition2_14_19;
  };
  goto condition2_14_19;
 case VARREF:
  deref_and_jump(a0,condition2_14_10);
  *reasonp++ =  a0;
  goto condition2_14_19;
  };
  goto condition2_14_19;
 condition2_14_19:
  otherwise(condition2_14_interrupt);
  a4 = a6;
  a5 = a7;
  a6 = a8;
  a7 = a9;
  a8 = a10;
  a9 = a11;
  a10 = a12;
  a11 = a13;
  execute(condition3_12_0);
  goto condition3_12_ext_interrupt;
 condition2_14_ext_interrupt:
  reasonp = 0l;
 condition2_14_interrupt:
  goto interrupt_14;
 }

 condition3_12_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 condition3_12_clear_reason:
  reasonp = reasons;
 condition3_12_0:
 condition3_12_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto condition3_12_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
 condition3_12_2:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (isint(a1)) goto condition3_12_interrupt;
  switch (symval(a1)) {
 case symval(makesym(atom_no)):
  allocp[0] = makesym(functor_v_4);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  x0 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_tv_2);
  allocp[6] = x0;
  allocp[7] = x6 = makeref(&allocp[7]);
  x5 = makefunctor(&allocp[5]);
  allocp += 8;
  unify_value(a2, x5);
  allocp[0] = makesym(functor_v_4);
  allocp[1] = x8 = makeref(&allocp[1]);
  allocp[2] = x9 = makeref(&allocp[2]);
  allocp[3] = x10 = makeref(&allocp[3]);
  allocp[4] = x11 = makeref(&allocp[4]);
  x7 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_tv_2);
  allocp[6] = x7;
  allocp[7] = x13 = makeref(&allocp[7]);
  x12 = makefunctor(&allocp[5]);
  allocp += 8;
  unify_value(a3, x12);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xset_12);
  allocp[2] = x1;
  allocp[3] = x2;
  allocp[4] = makesym(atom___);
  allocp[5] = makesym(atom___);
  allocp[6] = x3;
  allocp[7] = x4;
  allocp[8] = x14 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x15 = makeref(&allocp[10]);
  allocp[11] = a9;
  allocp[12] = a10;
  allocp[13] = a11;
  allocp[14] = makesym(functor_v_4);
  allocp[15] = x1;
  allocp[16] = x2;
  allocp[17] = x3;
  allocp[18] = x4;
  x16 = makefunctor(&allocp[14]);
  allocp[19] = makesym(functor_v_4);
  allocp[20] = x8;
  allocp[21] = x9;
  allocp[22] = x10;
  allocp[23] = x11;
  x17 = makefunctor(&allocp[19]);
  allocp[24] = (q)(struct goalrec*)&allocp[0];
  allocp[25] = (q)(&predicate_vt_xdelete__iu_4);
  allocp[26] = x16;
  allocp[27] = x17;
  allocp[28] = a8;
  allocp[29] = x15;
  a0 = a6;
  a1 = a4;
  a2 = x14;
  a3 = a7;
  qp = (struct goalrec*)&allocp[24];
  allocp += 30;
  execute(add__dgoal_4_0);
  goto add__dgoal_4_ext_interrupt;
 case symval(makesym(atom_yes)):
 condition3_12_3:
  switch (ptagof(a7)) {
 case ATOMIC:
  if (a7 != makesym(atom_expand)) goto condition3_12_interrupt;
  allocp[0] = makesym(functor_v_4);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  x0 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_tv_2);
  allocp[6] = x0;
  allocp[7] = x6 = makeref(&allocp[7]);
  x5 = makefunctor(&allocp[5]);
  allocp += 8;
  unify_value(a2, x5);
  allocp[0] = makesym(functor_v_4);
  allocp[1] = x8 = makeref(&allocp[1]);
  allocp[2] = x9 = makeref(&allocp[2]);
  allocp[3] = x10 = makeref(&allocp[3]);
  allocp[4] = x11 = makeref(&allocp[4]);
  x7 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_tv_2);
  allocp[6] = x7;
  allocp[7] = x13 = makeref(&allocp[7]);
  x12 = makefunctor(&allocp[5]);
  allocp += 8;
  unify_value(a3, x12);
  allocp[0] = makesym(functor_v_4);
  allocp[1] = x1;
  allocp[2] = x2;
  allocp[3] = x3;
  allocp[4] = x4;
  x14 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_v_4);
  allocp[6] = x8;
  allocp[7] = x9;
  allocp[8] = x10;
  allocp[9] = x11;
  x15 = makefunctor(&allocp[5]);
  allocp[10] = (q)qp;
  allocp[11] = (q)(&predicate_typeset_xentry__unifyset_4);
  allocp[12] = x14;
  allocp[13] = x15;
  allocp[14] = x16 = makeref(&allocp[14]);
  allocp[15] = a9;
  allocp[16] = (q)(struct goalrec*)&allocp[10];
  allocp[17] = (q)(&predicate_typeset_xset_12);
  allocp[18] = x8;
  allocp[19] = x9;
  allocp[20] = makesym(atom___);
  allocp[21] = makesym(atom___);
  allocp[22] = x10;
  allocp[23] = x11;
  allocp[24] = x17 = makeref(&allocp[24]);
  allocp[25] = makesym(atom_expand);
  allocp[26] = x18 = makeref(&allocp[26]);
  allocp[27] = x16;
  allocp[28] = x19 = makeref(&allocp[28]);
  allocp[29] = a11;
  allocp[30] = (q)(struct goalrec*)&allocp[16];
  allocp[31] = (q)(&predicate_typeset_xset_12);
  allocp[32] = x1;
  allocp[33] = x2;
  allocp[34] = makesym(atom___);
  allocp[35] = makesym(atom___);
  allocp[36] = x3;
  allocp[37] = x4;
  allocp[38] = x20 = makeref(&allocp[38]);
  allocp[39] = makesym(atom_expand);
  allocp[40] = a8;
  allocp[41] = x18;
  allocp[42] = a10;
  allocp[43] = x19;
  allocp[44] = (q)(struct goalrec*)&allocp[30];
  allocp[45] = (q)(&predicate_typeset_xadd__dgoal_4);
  allocp[46] = a5;
  allocp[47] = a4;
  allocp[48] = x17;
  allocp[49] = makesym(atom_expand);
  a0 = a6;
  a1 = a4;
  a2 = x20;
  a3 = makesym(atom_expand);
  qp = (struct goalrec*)&allocp[44];
  allocp += 50;
  execute(add__dgoal_4_0);
  goto add__dgoal_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a7,condition3_12_3);
  *reasonp++ =  a7;
  goto condition3_12_interrupt;
  };
  goto condition3_12_interrupt;
  };
  goto condition3_12_interrupt;
 case VARREF:
  deref_and_jump(a1,condition3_12_2);
  *reasonp++ =  a1;
  goto condition3_12_interrupt;
  };
  goto condition3_12_interrupt;
 case symval(makesym(atom_no)):
 condition3_12_4:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_yes)) goto condition3_12_interrupt;
  allocp[0] = makesym(functor_v_4);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  x0 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_tv_2);
  allocp[6] = x0;
  allocp[7] = x6 = makeref(&allocp[7]);
  x5 = makefunctor(&allocp[5]);
  allocp += 8;
  unify_value(a2, x5);
  allocp[0] = makesym(functor_v_4);
  allocp[1] = x8 = makeref(&allocp[1]);
  allocp[2] = x9 = makeref(&allocp[2]);
  allocp[3] = x10 = makeref(&allocp[3]);
  allocp[4] = x11 = makeref(&allocp[4]);
  x7 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_tv_2);
  allocp[6] = x7;
  allocp[7] = x13 = makeref(&allocp[7]);
  x12 = makefunctor(&allocp[5]);
  allocp += 8;
  unify_value(a3, x12);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xset_12);
  allocp[2] = x8;
  allocp[3] = x9;
  allocp[4] = makesym(atom___);
  allocp[5] = makesym(atom___);
  allocp[6] = x10;
  allocp[7] = x11;
  allocp[8] = x14 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x15 = makeref(&allocp[10]);
  allocp[11] = a9;
  allocp[12] = a10;
  allocp[13] = a11;
  allocp[14] = makesym(functor_v_4);
  allocp[15] = x8;
  allocp[16] = x9;
  allocp[17] = x10;
  allocp[18] = x11;
  x16 = makefunctor(&allocp[14]);
  allocp[19] = makesym(functor_v_4);
  allocp[20] = x1;
  allocp[21] = x2;
  allocp[22] = x3;
  allocp[23] = x4;
  x17 = makefunctor(&allocp[19]);
  allocp[24] = (q)(struct goalrec*)&allocp[0];
  allocp[25] = (q)(&predicate_vt_xdelete__iu_4);
  allocp[26] = x16;
  allocp[27] = x17;
  allocp[28] = a8;
  allocp[29] = x15;
  a0 = a5;
  a1 = a4;
  a2 = x14;
  a3 = a7;
  qp = (struct goalrec*)&allocp[24];
  allocp += 30;
  execute(add__dgoal_4_0);
  goto add__dgoal_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,condition3_12_4);
  *reasonp++ =  a1;
  goto condition3_12_interrupt;
  };
  goto condition3_12_interrupt;
  };
  goto condition3_12_interrupt;
 case VARREF:
  deref_and_jump(a0,condition3_12_1);
  *reasonp++ =  a0;
  goto condition3_12_interrupt;
  };
  goto condition3_12_interrupt;
 condition3_12_ext_interrupt:
  reasonp = 0l;
 condition3_12_interrupt:
  toppred = &predicate_typeset_xcondition3_12;
  goto interrupt_12;
 }

 unify__struct_9_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 unify__struct_9_clear_reason:
  reasonp = reasons;
 unify__struct_9_0:
 unify__struct_9_1:
  if (!isint(a0)) goto unify__struct_9_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,unify__struct_9_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xunify__struct_9);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = x3 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[13] = a0;
  allocp[14] = makeint(1L);
  allocp[15] = x1;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_typeset_xunify_8);
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = x5 = makeref(&allocp[19]);
  allocp[20] = a3;
  allocp[21] = a4;
  allocp[22] = a5;
  allocp[23] = x2;
  allocp[24] = a7;
  allocp[25] = x3;
  allocp[26] = (q)(struct goalrec*)&allocp[16];
  allocp[27] = (q)(&predicate_functor__table_xarg_3);
  allocp[28] = a0;
  allocp[29] = a2;
  allocp[30] = x5;
  allocp[31] = (q)(struct goalrec*)&allocp[26];
  allocp[32] = (q)(&predicate_functor__table_xarg_3);
  allocp[33] = a0;
  allocp[34] = a1;
  allocp[35] = x4;
  qp = (struct goalrec*)&allocp[31];
  allocp += 36;
  proceed();
 unify__struct_9_2:
  if (a0 != makeint(0L)) goto unify__struct_9_interrupt;
  unify2(a8, a7, a6, a5);
  proceed();
 unify__struct_9_3:
  if (!isref(a0)) goto unify__struct_9_interrupt;
  deref_and_jump(a0,unify__struct_9_1);
  *reasonp++ =  a0;
  goto unify__struct_9_interrupt;
 unify__struct_9_ext_interrupt:
  reasonp = 0l;
 unify__struct_9_interrupt:
  toppred = &predicate_typeset_xunify__struct_9;
  goto interrupt_9;
 }

 entry__unifyset_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 entry__unifyset_4_clear_reason:
  reasonp = reasons;
 entry__unifyset_4_0:
 entry__unifyset_4_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_v_4)) goto entry__unifyset_4_interrupt;
 entry__unifyset_4_2:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_v_4)) goto entry__unifyset_4_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vt_xwrite__iu_6);
  x0 = arg(a1, 0);
  allocp[2] = x0;
  x1 = arg(a1, 1);
  allocp[3] = x1;
  x2 = arg(a1, 2);
  allocp[4] = x2;
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = x4 = makeref(&allocp[6]);
  allocp[7] = a3;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_vt_xwrite__iu_6);
  x5 = arg(a0, 0);
  allocp[10] = x5;
  x6 = arg(a0, 1);
  allocp[11] = x6;
  x7 = arg(a0, 2);
  allocp[12] = x7;
  allocp[13] = x8 = makeref(&allocp[13]);
  allocp[14] = x9 = makeref(&allocp[14]);
  allocp[15] = x4;
  allocp[16] = (q)(struct goalrec*)&allocp[8];
  allocp[17] = (q)(&predicate_typeset_xentry__unifyset_6);
  allocp[18] = a1;
  allocp[19] = a0;
  allocp[20] = x10 = makeref(&allocp[20]);
  allocp[21] = x3;
  allocp[22] = x11 = makeref(&allocp[22]);
  allocp[23] = x9;
  allocp[24] = (q)(struct goalrec*)&allocp[16];
  allocp[25] = (q)(&predicate_typeset_xentry__unifyset_6);
  allocp[26] = a0;
  allocp[27] = a1;
  allocp[28] = x12 = makeref(&allocp[28]);
  allocp[29] = x8;
  allocp[30] = a2;
  allocp[31] = x11;
  allocp[32] = (q)(struct goalrec*)&allocp[24];
  allocp[33] = (q)(&predicate_vt_xread__iu_5);
  allocp[34] = a2;
  allocp[35] = x0;
  allocp[36] = x1;
  allocp[37] = x2;
  allocp[38] = x10;
  allocp[39] = (q)(struct goalrec*)&allocp[32];
  allocp[40] = (q)(&predicate_vt_xread__iu_5);
  allocp[41] = a2;
  allocp[42] = x5;
  allocp[43] = x6;
  allocp[44] = x7;
  allocp[45] = x12;
  qp = (struct goalrec*)&allocp[39];
  allocp += 46;
  proceed();
 case VARREF:
  deref_and_jump(a1,entry__unifyset_4_2);
  *reasonp++ =  a1;
  goto entry__unifyset_4_interrupt;
  };
  goto entry__unifyset_4_interrupt;
 case VARREF:
  deref_and_jump(a0,entry__unifyset_4_1);
  *reasonp++ =  a0;
  goto entry__unifyset_4_interrupt;
  };
  goto entry__unifyset_4_interrupt;
 entry__unifyset_4_ext_interrupt:
  reasonp = 0l;
 entry__unifyset_4_interrupt:
  goto interrupt_4;
 }

 entry__unifyset_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 entry__unifyset_6_clear_reason:
  reasonp = reasons;
 entry__unifyset_6_0:
 entry__unifyset_6_1:
  switch (ptagof(a2)) {
 case CONS:
 entry__unifyset_6_2:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_v_4)) goto entry__unifyset_6_20;
  x0 = car_of(a2);
 entry__unifyset_6_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_v_4)) goto entry__unifyset_6_20;
  x1 = arg(x0, 0);
 entry__unifyset_6_4:
  if (isref(x1)) goto entry__unifyset_6_19;
 entry__unifyset_6_5:
  if (isref(x1)) goto entry__unifyset_6_18;
  x2 = arg(a1, 0);
  if_not_equal(x1, x2, entry__unifyset_6_20);
  x3 = arg(x0, 1);
 entry__unifyset_6_6:
  if (isref(x3)) goto entry__unifyset_6_17;
 entry__unifyset_6_7:
  if (isref(x3)) goto entry__unifyset_6_16;
  x4 = arg(a1, 1);
  if_not_equal(x3, x4, entry__unifyset_6_20);
  x5 = arg(x0, 2);
 entry__unifyset_6_8:
  if (isref(x5)) goto entry__unifyset_6_15;
 entry__unifyset_6_9:
  if (isref(x5)) goto entry__unifyset_6_14;
  x6 = arg(a1, 2);
  if_not_equal(x5, x6, entry__unifyset_6_20);
  x7 = arg(x0, 3);
 entry__unifyset_6_10:
  if (isref(x7)) goto entry__unifyset_6_13;
 entry__unifyset_6_11:
  if (isref(x7)) goto entry__unifyset_6_12;
  x8 = arg(a1, 3);
  if_not_equal(x7, x8, entry__unifyset_6_20);
  unify(a5, a4);
  x10 = cdr_of(a2);
  allocp[0] = x10;
  allocp[1] = x0;
  x9 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a3, x9);
  proceed();
 entry__unifyset_6_12:
  deref_and_jump(x7,entry__unifyset_6_11);
  *reasonp++ =  x7;
  goto entry__unifyset_6_20;
 entry__unifyset_6_13:
  deref_and_jump(x7,entry__unifyset_6_10);
  *reasonp++ =  x7;
  goto entry__unifyset_6_20;
 entry__unifyset_6_14:
  deref_and_jump(x5,entry__unifyset_6_9);
  *reasonp++ =  x5;
  goto entry__unifyset_6_20;
 entry__unifyset_6_15:
  deref_and_jump(x5,entry__unifyset_6_8);
  *reasonp++ =  x5;
  goto entry__unifyset_6_20;
 entry__unifyset_6_16:
  deref_and_jump(x3,entry__unifyset_6_7);
  *reasonp++ =  x3;
  goto entry__unifyset_6_20;
 entry__unifyset_6_17:
  deref_and_jump(x3,entry__unifyset_6_6);
  *reasonp++ =  x3;
  goto entry__unifyset_6_20;
 entry__unifyset_6_18:
  deref_and_jump(x1,entry__unifyset_6_5);
  *reasonp++ =  x1;
  goto entry__unifyset_6_20;
 entry__unifyset_6_19:
  deref_and_jump(x1,entry__unifyset_6_4);
  *reasonp++ =  x1;
  goto entry__unifyset_6_20;
 case VARREF:
  deref_and_jump(x0,entry__unifyset_6_3);
  *reasonp++ =  x0;
  goto entry__unifyset_6_20;
  };
  goto entry__unifyset_6_20;
 case VARREF:
  deref_and_jump(a1,entry__unifyset_6_2);
  *reasonp++ =  a1;
  goto entry__unifyset_6_20;
  };
  goto entry__unifyset_6_20;
 case VARREF:
  deref_and_jump(a2,entry__unifyset_6_1);
  *reasonp++ =  a2;
  goto entry__unifyset_6_20;
  };
  goto entry__unifyset_6_20;
 entry__unifyset_6_20:
  otherwise(entry__unifyset_6_interrupt);
 entry__unifyset_6_21:
  switch (ptagof(a2)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a2);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a3, x0);
  a2 = cdr_of(a2);
  a3 = x1;
  execute(entry__unifyset_6_0);
  goto entry__unifyset_6_ext_interrupt;
 case ATOMIC:
  if (a2 != NILATOM) goto entry__unifyset_6_interrupt;
  unify(a5, a4);
  allocp[0] = makesym(functor_v_4);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  x0 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a1, x0);
  allocp[0] = makesym(functor_v_4);
  allocp[1] = x1;
  allocp[2] = x2;
  allocp[3] = x3;
  allocp[4] = x4;
  x5 = makefunctor(&allocp[0]);
  allocp[5] = NILATOM;
  allocp[6] = x5;
  x6 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a3, x6);
  proceed();
 case VARREF:
  deref_and_jump(a2,entry__unifyset_6_21);
  *reasonp++ =  a2;
  goto entry__unifyset_6_interrupt;
  };
  goto entry__unifyset_6_interrupt;
 entry__unifyset_6_ext_interrupt:
  reasonp = 0l;
 entry__unifyset_6_interrupt:
  goto interrupt_6;
 }

 add__dgoals_4_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 add__dgoals_4_clear_reason:
  reasonp = reasons;
 add__dgoals_4_0:
 add__dgoals_4_1:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xadd__dgoals_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  x1 = cdr_of(a1);
  allocp[3] = x1;
  allocp[4] = a2;
  allocp[5] = a3;
  a1 = car_of(a1);
  a2 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(add__dgoal_4_0);
  goto add__dgoal_4_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto add__dgoals_4_interrupt;
  unify(a2, a0);
  proceed();
 case VARREF:
  deref_and_jump(a1,add__dgoals_4_1);
  *reasonp++ =  a1;
  goto add__dgoals_4_interrupt;
  };
  goto add__dgoals_4_interrupt;
 add__dgoals_4_ext_interrupt:
  reasonp = 0l;
 add__dgoals_4_interrupt:
  goto interrupt_4;
 }

 add__dgoal_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 add__dgoal_4_clear_reason:
  reasonp = reasons;
 add__dgoal_4_0:
 add__dgoal_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 add__dgoal_4_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto add__dgoal_4_3;
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = makesym(atom__2A);
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x1);
  a0 = cdr_of(a0);
  a2 = x2;
  execute(add__dgoal_4_0);
  goto add__dgoal_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,add__dgoal_4_2);
  *reasonp++ =  x0;
  goto add__dgoal_4_3;
  };
  goto add__dgoal_4_3;
 case VARREF:
  deref_and_jump(a0,add__dgoal_4_1);
  *reasonp++ =  a0;
  goto add__dgoal_4_3;
  };
  goto add__dgoal_4_3;
 add__dgoal_4_3:
 add__dgoal_4_4:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_normal)) goto add__dgoal_4_8;
 add__dgoal_4_5:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 add__dgoal_4_6:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_2)) goto add__dgoal_4_8;
  x1 = arg(x0, 0);
 add__dgoal_4_7:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_s_3)) goto add__dgoal_4_8;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xadd__dgoal_4);
  x2 = cdr_of(a0);
  allocp[2] = x2;
  allocp[3] = a1;
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = makesym(atom_normal);
  allocp[6] = makesym(functor_s_3);
  x5 = arg(x1, 0);
  allocp[7] = x5;
  x6 = arg(x1, 1);
  allocp[8] = x6;
  allocp[9] = x7 = makeref(&allocp[9]);
  x4 = makefunctor(&allocp[6]);
  allocp[10] = makesym(functor_t_2);
  allocp[11] = x4;
  allocp[12] = x9 = makeref(&allocp[12]);
  x8 = makefunctor(&allocp[10]);
  allocp[13] = x3;
  allocp[14] = x8;
  x10 = makecons(&allocp[13]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 15;
  unify_value(a2, x10);
  allocp[0] = NILATOM;
  allocp[1] = a1;
  x11 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_depset_xor__depset_3);
  allocp[4] = x11;
  x12 = arg(x0, 1);
  allocp[5] = x12;
  allocp[6] = x9;
  a0 = arg(x1, 1);
  x13 = arg(x1, 2);
  a2 = a1;
  a3 = x7;
  a4 = makesym(atom_normal);
  a1 = x13;
  qp = (struct goalrec*)&allocp[2];
  allocp += 7;
  execute(add__dgoal__struct_5_clear_reason);
  goto add__dgoal__struct_5_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,add__dgoal_4_7);
  *reasonp++ =  x1;
  goto add__dgoal_4_8;
  };
  goto add__dgoal_4_8;
 case VARREF:
  deref_and_jump(x0,add__dgoal_4_6);
  *reasonp++ =  x0;
  goto add__dgoal_4_8;
  };
  goto add__dgoal_4_8;
 case VARREF:
  deref_and_jump(a0,add__dgoal_4_5);
  *reasonp++ =  a0;
  goto add__dgoal_4_8;
  };
  goto add__dgoal_4_8;
 case VARREF:
  deref_and_jump(a3,add__dgoal_4_4);
  *reasonp++ =  a3;
  goto add__dgoal_4_8;
  };
  goto add__dgoal_4_8;
 add__dgoal_4_8:
  otherwise(add__dgoal_4_interrupt);
 add__dgoal_4_9:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_normal)) goto add__dgoal_4_12;
 add__dgoal_4_10:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 add__dgoal_4_11:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_t_2:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xadd__dgoal_4);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = makesym(atom_normal);
  allocp[6] = makesym(functor_t_2);
  x4 = arg(x0, 0);
  allocp[7] = x4;
  allocp[8] = x5 = makeref(&allocp[8]);
  x3 = makefunctor(&allocp[6]);
  allocp[9] = x2;
  allocp[10] = x3;
  x6 = makecons(&allocp[9]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 11;
  unify_value(a2, x6);
  allocp[0] = NILATOM;
  allocp[1] = a1;
  x7 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_depset_xor__depset_3);
  allocp[4] = x7;
  x8 = arg(x0, 1);
  allocp[5] = x8;
  allocp[6] = x5;
  qp = (struct goalrec*)&allocp[2];
  allocp += 7;
  proceed();
 case functor_tv_2:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xadd__dgoal_4);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = makesym(atom_normal);
  allocp[6] = makesym(functor_tv_2);
  x4 = arg(x0, 0);
  allocp[7] = x4;
  allocp[8] = x5 = makeref(&allocp[8]);
  x3 = makefunctor(&allocp[6]);
  allocp[9] = x2;
  allocp[10] = x3;
  x6 = makecons(&allocp[9]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 11;
  unify_value(a2, x6);
  allocp[0] = NILATOM;
  allocp[1] = a1;
  x7 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_depset_xor__depset_3);
  allocp[4] = x7;
  x8 = arg(x0, 1);
  allocp[5] = x8;
  allocp[6] = x5;
  qp = (struct goalrec*)&allocp[2];
  allocp += 7;
  proceed();
  };
  goto add__dgoal_4_12;
 case VARREF:
  deref_and_jump(x0,add__dgoal_4_11);
  *reasonp++ =  x0;
  goto add__dgoal_4_12;
  };
  goto add__dgoal_4_12;
 case VARREF:
  deref_and_jump(a0,add__dgoal_4_10);
  *reasonp++ =  a0;
  goto add__dgoal_4_12;
  };
  goto add__dgoal_4_12;
 case VARREF:
  deref_and_jump(a3,add__dgoal_4_9);
  *reasonp++ =  a3;
  goto add__dgoal_4_12;
  };
  goto add__dgoal_4_12;
 add__dgoal_4_12:
 add__dgoal_4_13:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 add__dgoal_4_14:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_tt_3:
 add__dgoal_4_15:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_expand)) goto add__dgoal_4_17;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xadd__dgoal_4);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = makesym(atom_expand);
  allocp[6] = makesym(functor_tt_3);
  x4 = arg(x0, 0);
  allocp[7] = x4;
  x5 = arg(x0, 1);
  allocp[8] = x5;
  allocp[9] = x6 = makeref(&allocp[9]);
  x3 = makefunctor(&allocp[6]);
  allocp[10] = x2;
  allocp[11] = x3;
  x7 = makecons(&allocp[10]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  unify_value(a2, x7);
  allocp[0] = NILATOM;
  allocp[1] = a1;
  x8 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_depset_xor__depset_3);
  allocp[4] = x8;
  x9 = arg(x0, 2);
  allocp[5] = x9;
  allocp[6] = x6;
  qp = (struct goalrec*)&allocp[2];
  allocp += 7;
  proceed();
 case VARREF:
  deref_and_jump(a3,add__dgoal_4_15);
  *reasonp++ =  a3;
  goto add__dgoal_4_17;
  };
  goto add__dgoal_4_17;
 case functor_te_4:
 add__dgoal_4_16:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_expand)) goto add__dgoal_4_17;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xadd__dgoal_4);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = makesym(atom_expand);
  allocp[6] = makesym(functor_te_4);
  x4 = arg(x0, 0);
  allocp[7] = x4;
  x5 = arg(x0, 1);
  allocp[8] = x5;
  x6 = arg(x0, 2);
  allocp[9] = x6;
  allocp[10] = x7 = makeref(&allocp[10]);
  x3 = makefunctor(&allocp[6]);
  allocp[11] = x2;
  allocp[12] = x3;
  x8 = makecons(&allocp[11]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 13;
  unify_value(a2, x8);
  allocp[0] = NILATOM;
  allocp[1] = a1;
  x9 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_depset_xor__depset_3);
  allocp[4] = x9;
  x10 = arg(x0, 3);
  allocp[5] = x10;
  allocp[6] = x7;
  qp = (struct goalrec*)&allocp[2];
  allocp += 7;
  proceed();
 case VARREF:
  deref_and_jump(a3,add__dgoal_4_16);
  *reasonp++ =  a3;
  goto add__dgoal_4_17;
  };
  goto add__dgoal_4_17;
  };
  goto add__dgoal_4_17;
 case VARREF:
  deref_and_jump(x0,add__dgoal_4_14);
  *reasonp++ =  x0;
  goto add__dgoal_4_17;
  };
  goto add__dgoal_4_17;
 case ATOMIC:
  if (a0 != NILATOM) goto add__dgoal_4_17;
  x0 = NILATOM;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,add__dgoal_4_13);
  *reasonp++ =  a0;
  goto add__dgoal_4_17;
  };
  goto add__dgoal_4_17;
 add__dgoal_4_17:
  otherwise(add__dgoal_4_interrupt);
 add__dgoal_4_18:
  switch (ptagof(a0)) {
 case CONS:
 add__dgoal_4_19:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_expand)) goto add__dgoal_4_interrupt;
  x0 = car_of(a0);
 add__dgoal_4_20:
  if (isref(x0)) goto add__dgoal_4_22;
  gblt_pfunctor(x0,x1,add__dgoal_4_interrupt);
  gblt_arity(x0,x2,add__dgoal_4_interrupt);
 add__dgoal_4_21:
  if (x2 != makeint(2L)) goto add__dgoal_4_interrupt;
  allocp[0] = x4 = makeref(&allocp[0]);
  allocp[1] = x0;
  x3 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x3);
  a0 = cdr_of(a0);
  a2 = x4;
  a3 = makesym(atom_expand);
  execute(add__dgoal_4_0);
  goto add__dgoal_4_ext_interrupt;
 add__dgoal_4_22:
  deref_and_jump(x0,add__dgoal_4_20);
  *reasonp++ =  x0;
  goto add__dgoal_4_interrupt;
 case VARREF:
  deref_and_jump(a3,add__dgoal_4_19);
  *reasonp++ =  a3;
  goto add__dgoal_4_interrupt;
  };
  goto add__dgoal_4_interrupt;
 case VARREF:
  deref_and_jump(a0,add__dgoal_4_18);
  *reasonp++ =  a0;
  goto add__dgoal_4_interrupt;
  };
  goto add__dgoal_4_interrupt;
 add__dgoal_4_ext_interrupt:
  reasonp = 0l;
 add__dgoal_4_interrupt:
  toppred = &predicate_typeset_xadd__dgoal_4;
  goto interrupt_4;
 }

 add__dgoal__struct_5_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 add__dgoal__struct_5_clear_reason:
  reasonp = reasons;
 add__dgoal__struct_5_0:
 add__dgoal__struct_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto add__dgoal__struct_5_2;
  if (a0 != makesym(atom__2A)) goto add__dgoal__struct_5_interrupt;
  a0 = a1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  execute(add__dgoal_4_0);
  goto add__dgoal_4_ext_interrupt;
 add__dgoal__struct_5_2:
  if (a0 != makeint(0L)) goto add__dgoal__struct_5_3;
  unify(a3, a1);
  proceed();
 add__dgoal__struct_5_3:
  gblt_integer(a0,add__dgoal__struct_5_interrupt);
  x0 = makeint(0L);
  gblt_greater(a0,x0,add__dgoal__struct_5_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xadd__dgoal__struct_5);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[9] = a0;
  allocp[10] = makeint(1L);
  allocp[11] = x1;
  allocp[12] = (q)(struct goalrec*)&allocp[7];
  allocp[13] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = x3 = makeref(&allocp[16]);
  allocp[17] = x2;
  allocp[18] = (q)(struct goalrec*)&allocp[12];
  allocp[19] = (q)(&predicate_typeset_xadd__dgoal_4);
  allocp[20] = x4 = makeref(&allocp[20]);
  allocp[21] = a2;
  allocp[22] = x3;
  allocp[23] = a4;
  allocp[24] = (q)(struct goalrec*)&allocp[18];
  allocp[25] = (q)(&predicate_functor__table_xarg_3);
  allocp[26] = a0;
  allocp[27] = a1;
  allocp[28] = x4;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 case VARREF:
  deref_and_jump(a0,add__dgoal__struct_5_1);
  *reasonp++ =  a0;
  goto add__dgoal__struct_5_interrupt;
  };
  goto add__dgoal__struct_5_interrupt;
 add__dgoal__struct_5_ext_interrupt:
  reasonp = 0l;
 add__dgoal__struct_5_interrupt:
  toppred = &predicate_typeset_xadd__dgoal__struct_5;
  goto interrupt_5;
 }

 get__arg__typeset_5_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 get__arg__typeset_5_clear_reason:
  reasonp = reasons;
 get__arg__typeset_5_0:
 get__arg__typeset_5_1:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_variable_3)) goto get__arg__typeset_5_2;
  a2 = arg(a2, 0);
  x0 = a4;
  a4 = a3;
  a3 = x0;
  execute(get_5_0);
  goto get_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,get__arg__typeset_5_1);
  *reasonp++ =  a2;
  goto get__arg__typeset_5_2;
  };
  goto get__arg__typeset_5_2;
 get__arg__typeset_5_2:
  otherwise(get__arg__typeset_5_interrupt);
  a3 = NILATOM;
  execute(value2typeset_5_0);
  goto value2typeset_5_ext_interrupt;
 get__arg__typeset_5_ext_interrupt:
  reasonp = 0l;
 get__arg__typeset_5_interrupt:
  goto interrupt_5;
 }

 get_5_top: {
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 get_5_clear_reason:
  reasonp = reasons;
 get_5_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_vt_xread__ts_5);
  allocp[2] = a4;
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  proceed();
 get_5_ext_interrupt:
  reasonp = 0l;
 get_5_interrupt:
  toppred = &predicate_typeset_xget_5;
  goto interrupt_5;
 }

 set_12_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 set_12_clear_reason:
  reasonp = reasons;
 set_12_0:
 set_12_1:
  switch (ptagof(a4)) {
 case FUNCTOR:
  if (functor_of(a4) != makesym(functor_variable_3)) goto set_12_2;
  x0 = arg(a4, 0);
  a5 = arg(a4, 1);
  a4 = x0;
  execute(set_12_0);
  goto set_12_ext_interrupt;
 case VARREF:
  deref_and_jump(a4,set_12_1);
  *reasonp++ =  a4;
  goto set_12_2;
  };
  goto set_12_2;
 set_12_2:
 set_12_3:
  switch (ptagof(a7)) {
 case ATOMIC:
  if (isint(a7)) goto set_12_8;
  switch (symval(a7)) {
 case symval(makesym(atom_normal)):
 set_12_4:
  if (!isint(a4)) goto set_12_5;
  gblt_integer(a4,set_12_8);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xset__type_12);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = x0 = makeref(&allocp[8]);
  allocp[9] = makesym(atom_normal);
  allocp[10] = a8;
  allocp[11] = a9;
  allocp[12] = a10;
  allocp[13] = a11;
  allocp[14] = makesym(functor_v_3);
  allocp[15] = a0;
  allocp[16] = a1;
  allocp[17] = a4;
  x1 = makefunctor(&allocp[14]);
  a0 = x1;
  a1 = a6;
  a2 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 18;
  execute(delete__ts_3_clear_reason);
  goto delete__ts_3_ext_interrupt;
 set_12_5:
  if (!isref(a4)) goto set_12_8;
  deref_and_jump(a4,set_12_4);
  *reasonp++ =  a4;
  goto set_12_8;
 case symval(makesym(atom_expand)):
 set_12_6:
  if (!isint(a4)) goto set_12_7;
  gblt_integer(a4,set_12_8);
  a7 = makesym(atom_expand);
  execute(set__type_12_clear_reason);
  goto set__type_12_ext_interrupt;
 set_12_7:
  if (!isref(a4)) goto set_12_8;
  deref_and_jump(a4,set_12_6);
  *reasonp++ =  a4;
  goto set_12_8;
  };
  goto set_12_8;
 case VARREF:
  deref_and_jump(a7,set_12_3);
  *reasonp++ =  a7;
  goto set_12_8;
  };
  goto set_12_8;
 set_12_8:
  otherwise(set_12_interrupt);
  unify2(a11, a10, a9, a8);
  proceed();
 set_12_ext_interrupt:
  reasonp = 0l;
 set_12_interrupt:
  goto interrupt_12;
 }

 set__type_12_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 set__type_12_clear_reason:
  reasonp = reasons;
 set__type_12_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xset__type2_13);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = x0 = makeref(&allocp[8]);
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = a8;
  allocp[12] = a9;
  allocp[13] = a10;
  allocp[14] = a11;
  allocp[15] = (q)(struct goalrec*)&allocp[0];
  allocp[16] = (q)(&predicate_vt_xread__ts_5);
  allocp[17] = a8;
  allocp[18] = a0;
  allocp[19] = a1;
  allocp[20] = a4;
  allocp[21] = x0;
  qp = (struct goalrec*)&allocp[15];
  allocp += 22;
  proceed();
 set__type_12_ext_interrupt:
  reasonp = 0l;
 set__type_12_interrupt:
  toppred = &predicate_typeset_xset__type_12;
  goto interrupt_12;
 }

 set__type2_13_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  qp = qp->next;
 set__type2_13_clear_reason:
  reasonp = reasons;
 set__type2_13_0:
 set__type2_13_1:
  switch (ptagof(a8)) {
 case ATOMIC:
  if (isint(a8)) goto set__type2_13_interrupt;
  switch (symval(a8)) {
 case symval(makesym(atom_normal)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xentry__update_10);
  allocp[2] = a6;
  allocp[3] = a7;
  allocp[4] = a0;
  allocp[5] = a1;
  allocp[6] = a2;
  allocp[7] = a3;
  allocp[8] = a4;
  allocp[9] = a5;
  allocp[10] = a11;
  allocp[11] = a12;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_vt_xwrite__ts_6);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = a4;
  allocp[17] = a7;
  allocp[18] = a9;
  allocp[19] = a10;
  qp = (struct goalrec*)&allocp[12];
  allocp += 20;
  proceed();
 case symval(makesym(atom_expand)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xset__type3_13);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = a9;
  allocp[12] = a10;
  allocp[13] = a11;
  allocp[14] = a12;
  a0 = a6;
  a1 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 15;
  execute(check__normal__ts_2_0);
  goto check__normal__ts_2_ext_interrupt;
  };
  goto set__type2_13_interrupt;
 case VARREF:
  deref_and_jump(a8,set__type2_13_1);
  *reasonp++ =  a8;
  goto set__type2_13_interrupt;
  };
  goto set__type2_13_interrupt;
 set__type2_13_ext_interrupt:
  reasonp = 0l;
 set__type2_13_interrupt:
  goto interrupt_13;
 }

 set__type3_13_top: {
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  qp = qp->next;
 set__type3_13_clear_reason:
  reasonp = reasons;
 set__type3_13_0:
 set__type3_13_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto set__type3_13_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  unify2(a12, a11, a10, a9);
  proceed();
 case symval(makesym(atom_no)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xentry__update_10);
  allocp[2] = a7;
  allocp[3] = a8;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = a11;
  allocp[11] = a12;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_vt_xwrite__ts_6);
  allocp[14] = a1;
  allocp[15] = a2;
  allocp[16] = a5;
  allocp[17] = a8;
  allocp[18] = a9;
  allocp[19] = a10;
  qp = (struct goalrec*)&allocp[12];
  allocp += 20;
  proceed();
  };
  goto set__type3_13_interrupt;
 case VARREF:
  deref_and_jump(a0,set__type3_13_1);
  *reasonp++ =  a0;
  goto set__type3_13_interrupt;
  };
  goto set__type3_13_interrupt;
 set__type3_13_ext_interrupt:
  reasonp = 0l;
 set__type3_13_interrupt:
  goto interrupt_13;
 }

 check__normal__ts_2_top: {
  q x0, x1, x2, x3;
  qp = qp->next;
 check__normal__ts_2_clear_reason:
  reasonp = reasons;
 check__normal__ts_2_0:
 check__normal__ts_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 check__normal__ts_2_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto check__normal__ts_2_4;
  x1 = cdr_of(a0);
 check__normal__ts_2_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto check__normal__ts_2_4;
  x2 = makesym(atom_no);
  unify_value(a1, x2);
  proceed();
 case VARREF:
  deref_and_jump(x1,check__normal__ts_2_3);
  *reasonp++ =  x1;
  goto check__normal__ts_2_4;
  };
  goto check__normal__ts_2_4;
 case VARREF:
  deref_and_jump(x0,check__normal__ts_2_2);
  *reasonp++ =  x0;
  goto check__normal__ts_2_4;
  };
  goto check__normal__ts_2_4;
 case VARREF:
  deref_and_jump(a0,check__normal__ts_2_1);
  *reasonp++ =  a0;
  goto check__normal__ts_2_4;
  };
  goto check__normal__ts_2_4;
 check__normal__ts_2_4:
  otherwise(check__normal__ts_2_interrupt);
 check__normal__ts_2_5:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 check__normal__ts_2_6:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto check__normal__ts_2_7;
  a0 = cdr_of(a0);
  execute(check__normal__ts_2_0);
  goto check__normal__ts_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,check__normal__ts_2_6);
  *reasonp++ =  x0;
  goto check__normal__ts_2_interrupt;
  };
  goto check__normal__ts_2_7;
 check__normal__ts_2_7:
  gblt_pfunctor(x0,x1,check__normal__ts_2_interrupt);
  if (isint(x1)) goto check__normal__ts_2_interrupt;
  switch (symval(x1)) {
 case symval(makesym(atom_tv)):
  gblt_arity(x0,x2,check__normal__ts_2_interrupt);
 check__normal__ts_2_8:
  if (x2 != makeint(2L)) goto check__normal__ts_2_interrupt;
  a0 = cdr_of(a0);
  execute(check__normal__ts_2_0);
  goto check__normal__ts_2_ext_interrupt;
 case symval(makesym(atom_t)):
  gblt_arity(x0,x2,check__normal__ts_2_interrupt);
 check__normal__ts_2_9:
  if (x2 != makeint(2L)) goto check__normal__ts_2_interrupt;
  a0 = cdr_of(a0);
  execute(check__normal__ts_2_0);
  goto check__normal__ts_2_ext_interrupt;
 case symval(makesym(atom_tt)):
  gblt_arity(x0,x2,check__normal__ts_2_interrupt);
 check__normal__ts_2_10:
  if (x2 != makeint(3L)) goto check__normal__ts_2_interrupt;
  x3 = makesym(atom_no);
  unify_value(a1, x3);
  proceed();
  };
  goto check__normal__ts_2_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto check__normal__ts_2_interrupt;
  x0 = makesym(atom_yes);
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,check__normal__ts_2_5);
  *reasonp++ =  a0;
  goto check__normal__ts_2_interrupt;
  };
  goto check__normal__ts_2_interrupt;
 check__normal__ts_2_ext_interrupt:
  reasonp = 0l;
 check__normal__ts_2_interrupt:
  toppred = &predicate_typeset_xcheck__normal__ts_2;
  goto interrupt_2;
 }

 delete__ts_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  qp = qp->next;
 delete__ts_3_clear_reason:
  reasonp = reasons;
 delete__ts_3_0:
 delete__ts_3_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 delete__ts_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_tv_2)) goto delete__ts_3_17;
  x1 = arg(x0, 0);
 delete__ts_3_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_v_4)) goto delete__ts_3_17;
 delete__ts_3_4:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_v_3)) goto delete__ts_3_17;
  x2 = arg(a0, 0);
 delete__ts_3_5:
  if (isref(x2)) goto delete__ts_3_16;
 delete__ts_3_6:
  if (isref(x2)) goto delete__ts_3_15;
  x3 = arg(x1, 0);
  if_not_equal(x2, x3, delete__ts_3_17);
  x4 = arg(a0, 1);
 delete__ts_3_7:
  if (isref(x4)) goto delete__ts_3_14;
 delete__ts_3_8:
  if (isref(x4)) goto delete__ts_3_13;
  x5 = arg(x1, 1);
  if_not_equal(x4, x5, delete__ts_3_17);
  x6 = arg(a0, 2);
 delete__ts_3_9:
  if (isref(x6)) goto delete__ts_3_12;
 delete__ts_3_10:
  if (isref(x6)) goto delete__ts_3_11;
  x7 = arg(x1, 2);
  if_not_equal(x6, x7, delete__ts_3_17);
  a1 = cdr_of(a1);
  execute(delete__ts_3_clear_reason);
  goto delete__ts_3_ext_interrupt;
 delete__ts_3_11:
  deref_and_jump(x6,delete__ts_3_10);
  *reasonp++ =  x6;
  goto delete__ts_3_17;
 delete__ts_3_12:
  deref_and_jump(x6,delete__ts_3_9);
  *reasonp++ =  x6;
  goto delete__ts_3_17;
 delete__ts_3_13:
  deref_and_jump(x4,delete__ts_3_8);
  *reasonp++ =  x4;
  goto delete__ts_3_17;
 delete__ts_3_14:
  deref_and_jump(x4,delete__ts_3_7);
  *reasonp++ =  x4;
  goto delete__ts_3_17;
 delete__ts_3_15:
  deref_and_jump(x2,delete__ts_3_6);
  *reasonp++ =  x2;
  goto delete__ts_3_17;
 delete__ts_3_16:
  deref_and_jump(x2,delete__ts_3_5);
  *reasonp++ =  x2;
  goto delete__ts_3_17;
 case VARREF:
  deref_and_jump(a0,delete__ts_3_4);
  *reasonp++ =  a0;
  goto delete__ts_3_17;
  };
  goto delete__ts_3_17;
 case VARREF:
  deref_and_jump(x1,delete__ts_3_3);
  *reasonp++ =  x1;
  goto delete__ts_3_17;
  };
  goto delete__ts_3_17;
 case VARREF:
  deref_and_jump(x0,delete__ts_3_2);
  *reasonp++ =  x0;
  goto delete__ts_3_17;
  };
  goto delete__ts_3_17;
 case VARREF:
  deref_and_jump(a1,delete__ts_3_1);
  *reasonp++ =  a1;
  goto delete__ts_3_17;
  };
  goto delete__ts_3_17;
 delete__ts_3_17:
  otherwise(delete__ts_3_interrupt);
 delete__ts_3_18:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a1);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  a1 = cdr_of(a1);
  a2 = x1;
  execute(delete__ts_3_0);
  goto delete__ts_3_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto delete__ts_3_interrupt;
  x0 = NILATOM;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,delete__ts_3_18);
  *reasonp++ =  a1;
  goto delete__ts_3_interrupt;
  };
  goto delete__ts_3_interrupt;
 delete__ts_3_ext_interrupt:
  reasonp = 0l;
 delete__ts_3_interrupt:
  toppred = &predicate_typeset_xdelete__ts_3;
  goto interrupt_3;
 }

 entry__update_10_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 entry__update_10_clear_reason:
  reasonp = reasons;
 entry__update_10_0:
 entry__update_10_1:
  if (isref(a0)) goto entry__update_10_4;
 entry__update_10_2:
  if (isref(a0)) goto entry__update_10_3;
  if_not_equal(a0, a1, entry__update_10_5);
  unify(a9, a8);
  proceed();
 entry__update_10_3:
  deref_and_jump(a0,entry__update_10_2);
  *reasonp++ =  a0;
  goto entry__update_10_5;
 entry__update_10_4:
  deref_and_jump(a0,entry__update_10_1);
  *reasonp++ =  a0;
  goto entry__update_10_5;
 entry__update_10_5:
  otherwise(entry__update_10_interrupt);
  allocp[0] = makesym(functor_var_6);
  allocp[1] = a2;
  allocp[2] = a3;
  allocp[3] = a4;
  allocp[4] = a5;
  allocp[5] = a6;
  allocp[6] = a7;
  x0 = makefunctor(&allocp[0]);
  allocp[7] = NILATOM;
  allocp[8] = x0;
  x1 = makecons(&allocp[7]);
  allocp[9] = (q)qp;
  allocp[10] = (q)(&predicate_list_xappend_3);
  allocp[11] = a8;
  allocp[12] = x1;
  allocp[13] = a9;
  qp = (struct goalrec*)&allocp[9];
  allocp += 14;
  proceed();
 entry__update_10_ext_interrupt:
  reasonp = 0l;
 entry__update_10_interrupt:
  goto interrupt_10;
 }

 value2typeset_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 value2typeset_5_clear_reason:
  reasonp = reasons;
 value2typeset_5_0:
 value2typeset_5_1:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (isint(a2)) goto value2typeset_5_5;
  switch (symval(a2)) {
 case symval(makesym(atom_integer)):
  allocp[0] = makesym(functor_t_2);
  allocp[1] = makesym(atom_i);
  allocp[2] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = NILATOM;
  allocp[4] = x0;
  x1 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a4, x1);
  proceed();
 case symval(makesym(atom_float)):
  allocp[0] = makesym(functor_t_2);
  allocp[1] = makesym(atom_f);
  allocp[2] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = NILATOM;
  allocp[4] = x0;
  x1 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a4, x1);
  proceed();
 case symval(makesym(atom_atom)):
  allocp[0] = makesym(functor_t_2);
  allocp[1] = makesym(atom_a);
  allocp[2] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = NILATOM;
  allocp[4] = x0;
  x1 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a4, x1);
  proceed();
 case symval(makesym(atom_string)):
  allocp[0] = makesym(functor_t_2);
  allocp[1] = makesym(atom_c);
  allocp[2] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = NILATOM;
  allocp[4] = x0;
  x1 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a4, x1);
  proceed();
  };
  goto value2typeset_5_5;
 case FUNCTOR:
  switch (symval(functor_of(a2))) {
 case functor_integer_1:
  allocp[0] = makesym(functor_i_1);
  x1 = arg(a2, 0);
  allocp[1] = x1;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_t_2);
  allocp[3] = x0;
  allocp[4] = a3;
  x2 = makefunctor(&allocp[2]);
  allocp[5] = NILATOM;
  allocp[6] = x2;
  x3 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a4, x3);
  proceed();
 case functor_float_1:
  allocp[0] = makesym(functor_f_1);
  x1 = arg(a2, 0);
  allocp[1] = x1;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_t_2);
  allocp[3] = x0;
  allocp[4] = a3;
  x2 = makefunctor(&allocp[2]);
  allocp[5] = NILATOM;
  allocp[6] = x2;
  x3 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a4, x3);
  proceed();
 case functor_atom_1:
  allocp[0] = makesym(functor_a_1);
  x1 = arg(a2, 0);
  allocp[1] = x1;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_t_2);
  allocp[3] = x0;
  allocp[4] = a3;
  x2 = makefunctor(&allocp[2]);
  allocp[5] = NILATOM;
  allocp[6] = x2;
  x3 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a4, x3);
  proceed();
 case functor_string_1:
  allocp[0] = makesym(functor_c_1);
  x1 = arg(a2, 0);
  allocp[1] = x1;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_t_2);
  allocp[3] = x0;
  allocp[4] = a3;
  x2 = makefunctor(&allocp[2]);
  allocp[5] = NILATOM;
  allocp[6] = x2;
  x3 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a4, x3);
  proceed();
 case functor_functor_1:
  allocp[0] = makesym(functor_s_3);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  x0 = makefunctor(&allocp[0]);
  allocp[4] = makesym(functor_t_2);
  allocp[5] = x0;
  allocp[6] = a3;
  x4 = makefunctor(&allocp[4]);
  allocp[7] = NILATOM;
  allocp[8] = x4;
  x5 = makecons(&allocp[7]);
  allocp += 9;
  unify_value(a4, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xvalue2typeset__functor_7);
  allocp[2] = a0;
  allocp[3] = a1;
  x6 = arg(a2, 0);
  allocp[4] = x6;
  allocp[5] = x2;
  allocp[6] = a3;
  allocp[7] = NILATOM;
  allocp[8] = x3;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[11] = x6;
  allocp[12] = x1;
  allocp[13] = x2;
  qp = (struct goalrec*)&allocp[9];
  allocp += 14;
  proceed();
 case functor_list_1:
  x0 = arg(a2, 0);
 value2typeset_5_2:
  switch (ptagof(x0)) {
 case CONS:
  allocp[0] = makesym(functor_args_2);
  allocp[1] = x2 = makeref(&allocp[1]);
  allocp[2] = x3 = makeref(&allocp[2]);
  x1 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_s_3);
  allocp[4] = PERIODATOM;
  allocp[5] = makeint(2L);
  allocp[6] = x1;
  x4 = makefunctor(&allocp[3]);
  allocp[7] = makesym(functor_t_2);
  allocp[8] = x4;
  allocp[9] = a3;
  x5 = makefunctor(&allocp[7]);
  allocp[10] = NILATOM;
  allocp[11] = x5;
  x6 = makecons(&allocp[10]);
  allocp += 12;
  unify_value(a4, x6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xvalue2typeset_5);
  allocp[2] = a0;
  allocp[3] = a1;
  x7 = cdr_of(x0);
  allocp[4] = x7;
  allocp[5] = a3;
  allocp[6] = x3;
  a2 = car_of(x0);
  a4 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(value2typeset_5_0);
  goto value2typeset_5_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,value2typeset_5_2);
  *reasonp++ =  x0;
  goto value2typeset_5_5;
  };
  goto value2typeset_5_5;
 case functor_vector_1:
  x0 = arg(a2, 0);
 value2typeset_5_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
 value2typeset_5_4:
  if (!isgobj(x0)) goto value2typeset_5_5;
  if (!isclass(x0,vector)) goto value2typeset_5_5;
  gblt_size_of_vector(x0,x1,value2typeset_5_5);
  x2 = makeint(1L);
  bblt_sub_no_check(x1,x2,x3);
  allocp[0] = makesym(functor_s_3);
  allocp[1] = makesym(atom___v);
  allocp[2] = x1;
  allocp[3] = x5 = makeref(&allocp[3]);
  x4 = makefunctor(&allocp[0]);
  allocp[4] = makesym(functor_t_2);
  allocp[5] = x4;
  allocp[6] = a3;
  x6 = makefunctor(&allocp[4]);
  allocp[7] = NILATOM;
  allocp[8] = x6;
  x7 = makecons(&allocp[7]);
  allocp += 9;
  unify_value(a4, x7);
  a2 = x0;
  a4 = a3;
  a5 = NILATOM;
  a6 = x5;
  a3 = x3;
  execute(value2typeset__vector_7_0);
  goto value2typeset__vector_7_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,value2typeset_5_3);
  *reasonp++ =  x0;
  goto value2typeset_5_5;
  };
  goto value2typeset_5_5;
 case functor_variable_3:
  allocp[0] = makesym(functor_v_4);
  allocp[1] = a0;
  allocp[2] = a1;
  x1 = arg(a2, 0);
  allocp[3] = x1;
  x2 = arg(a2, 1);
  allocp[4] = x2;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = makesym(functor_tv_2);
  allocp[6] = x0;
  allocp[7] = a3;
  x3 = makefunctor(&allocp[5]);
  allocp[8] = NILATOM;
  allocp[9] = x3;
  x4 = makecons(&allocp[8]);
  allocp += 10;
  unify_value(a4, x4);
  proceed();
  };
  goto value2typeset_5_5;
 case VARREF:
  deref_and_jump(a2,value2typeset_5_1);
  *reasonp++ =  a2;
  goto value2typeset_5_5;
  };
  goto value2typeset_5_5;
 value2typeset_5_5:
  otherwise(value2typeset_5_interrupt);
  x0 = makecons(cons_const_0);
  unify_value(a4, x0);
  proceed();
 value2typeset_5_ext_interrupt:
  reasonp = 0l;
 value2typeset_5_interrupt:
  toppred = &predicate_typeset_xvalue2typeset_5;
  goto interrupt_5;
 }

 value2typeset__functor_7_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 value2typeset__functor_7_clear_reason:
  reasonp = reasons;
 value2typeset__functor_7_0:
 value2typeset__functor_7_1:
  if (!isint(a3)) goto value2typeset__functor_7_3;
  x0 = makeint(0L);
  gblt_greater(a3,x0,value2typeset__functor_7_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xvalue2typeset__functor_7);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[11] = a3;
  allocp[12] = makeint(1L);
  allocp[13] = x1;
  allocp[14] = a5;
  allocp[15] = x4 = makeref(&allocp[15]);
  x3 = makecons(&allocp[14]);
  qp = (struct goalrec*)&allocp[9];
  allocp += 16;
  unify_value(x2, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xvalue2typeset_5);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = x5 = makeref(&allocp[4]);
  allocp[5] = a4;
  allocp[6] = x4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_functor__table_xarg_3);
  allocp[9] = a3;
  allocp[10] = a2;
  allocp[11] = x5;
  qp = (struct goalrec*)&allocp[7];
  allocp += 12;
  proceed();
 value2typeset__functor_7_2:
  if (a3 != makeint(0L)) goto value2typeset__functor_7_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor_xcreate__functor_3);
  allocp[2] = makesym(atom_args);
  allocp[3] = a5;
  allocp[4] = a6;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 value2typeset__functor_7_3:
  if (!isref(a3)) goto value2typeset__functor_7_interrupt;
  deref_and_jump(a3,value2typeset__functor_7_1);
  *reasonp++ =  a3;
  goto value2typeset__functor_7_interrupt;
 value2typeset__functor_7_ext_interrupt:
  reasonp = 0l;
 value2typeset__functor_7_interrupt:
  goto interrupt_7;
 }

 value2typeset__vector_7_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 value2typeset__vector_7_clear_reason:
  reasonp = reasons;
 value2typeset__vector_7_0:
 value2typeset__vector_7_1:
  if (!isint(a3)) goto value2typeset__vector_7_3;
  x0 = makeint(0L);
  gblt_greater_or_eq(a3,x0,value2typeset__vector_7_2);
  generic_arg[0] = a3;
  allocp[0] = x1 = makeref(&allocp[0]);
  generic_arg[1] = x1;
  call_generic(a2, functor_element_2, 1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xvalue2typeset__vector_7);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[11] = a3;
  allocp[12] = makeint(1L);
  allocp[13] = x2;
  allocp[14] = a5;
  allocp[15] = x5 = makeref(&allocp[15]);
  x4 = makecons(&allocp[14]);
  qp = (struct goalrec*)&allocp[9];
  allocp += 16;
  unify_value(x3, x4);
  a2 = x1;
  a3 = a4;
  a4 = x5;
  execute(value2typeset_5_0);
  goto value2typeset_5_ext_interrupt;
 value2typeset__vector_7_2:
  x1 = makeint(0L);
  gblt_less(a3,x1,value2typeset__vector_7_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor_xcreate__functor_3);
  allocp[2] = makesym(atom_args);
  allocp[3] = a5;
  allocp[4] = a6;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 value2typeset__vector_7_3:
  if (!isref(a3)) goto value2typeset__vector_7_interrupt;
  deref_and_jump(a3,value2typeset__vector_7_1);
  *reasonp++ =  a3;
  goto value2typeset__vector_7_interrupt;
 value2typeset__vector_7_ext_interrupt:
  reasonp = 0l;
 value2typeset__vector_7_interrupt:
  toppred = &predicate_typeset_xvalue2typeset__vector_7;
  goto interrupt_7;
 }

 typeset2atom_2_top: {
  q x0, x1, x2, x3;
  qp = qp->next;
 typeset2atom_2_clear_reason:
  reasonp = reasons;
 typeset2atom_2_0:
 typeset2atom_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 typeset2atom_2_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto typeset2atom_2_4;
  x1 = makesym(atom__2A);
  unify_value(a1, x1);
  proceed();
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_2)) goto typeset2atom_2_4;
  x1 = arg(x0, 0);
 typeset2atom_2_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_a)) goto typeset2atom_2_4;
  x2 = makesym(atom_a);
  unify_value(a1, x2);
  proceed();
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_a_1)) goto typeset2atom_2_4;
  allocp[0] = makesym(functor_a_1);
  x3 = arg(x1, 0);
  allocp[1] = x3;
  x2 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x2);
  proceed();
 case VARREF:
  deref_and_jump(x1,typeset2atom_2_3);
  *reasonp++ =  x1;
  goto typeset2atom_2_4;
  };
  goto typeset2atom_2_4;
 case VARREF:
  deref_and_jump(x0,typeset2atom_2_2);
  *reasonp++ =  x0;
  goto typeset2atom_2_4;
  };
  goto typeset2atom_2_4;
 case VARREF:
  deref_and_jump(a0,typeset2atom_2_1);
  *reasonp++ =  a0;
  goto typeset2atom_2_4;
  };
  goto typeset2atom_2_4;
 typeset2atom_2_4:
  otherwise(typeset2atom_2_interrupt);
 typeset2atom_2_5:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(typeset2atom_2_0);
  goto typeset2atom_2_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto typeset2atom_2_interrupt;
  x0 = makesym(atom__2A);
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,typeset2atom_2_5);
  *reasonp++ =  a0;
  goto typeset2atom_2_interrupt;
  };
  goto typeset2atom_2_interrupt;
 typeset2atom_2_ext_interrupt:
  reasonp = 0l;
 typeset2atom_2_interrupt:
  goto interrupt_2;
 }

 typeset2int_2_top: {
  q x0, x1, x2, x3;
  qp = qp->next;
 typeset2int_2_clear_reason:
  reasonp = reasons;
 typeset2int_2_0:
 typeset2int_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 typeset2int_2_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto typeset2int_2_4;
  x1 = makesym(atom__2A);
  unify_value(a1, x1);
  proceed();
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_2)) goto typeset2int_2_4;
  x1 = arg(x0, 0);
 typeset2int_2_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_i)) goto typeset2int_2_4;
  x2 = makesym(atom_i);
  unify_value(a1, x2);
  proceed();
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_i_1)) goto typeset2int_2_4;
  allocp[0] = makesym(functor_i_1);
  x3 = arg(x1, 0);
  allocp[1] = x3;
  x2 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x2);
  proceed();
 case VARREF:
  deref_and_jump(x1,typeset2int_2_3);
  *reasonp++ =  x1;
  goto typeset2int_2_4;
  };
  goto typeset2int_2_4;
 case VARREF:
  deref_and_jump(x0,typeset2int_2_2);
  *reasonp++ =  x0;
  goto typeset2int_2_4;
  };
  goto typeset2int_2_4;
 case VARREF:
  deref_and_jump(a0,typeset2int_2_1);
  *reasonp++ =  a0;
  goto typeset2int_2_4;
  };
  goto typeset2int_2_4;
 typeset2int_2_4:
  otherwise(typeset2int_2_interrupt);
 typeset2int_2_5:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(typeset2int_2_0);
  goto typeset2int_2_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto typeset2int_2_interrupt;
  x0 = makesym(atom__2A);
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,typeset2int_2_5);
  *reasonp++ =  a0;
  goto typeset2int_2_interrupt;
  };
  goto typeset2int_2_interrupt;
 typeset2int_2_ext_interrupt:
  reasonp = 0l;
 typeset2int_2_interrupt:
  goto interrupt_2;
 }

 typeset2list_2_top: {
  q x0;
  qp = qp->next;
 typeset2list_2_clear_reason:
  reasonp = reasons;
 typeset2list_2_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xtypeset2list1_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  a1 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  execute(typeset2structtype_2_0);
  goto typeset2structtype_2_ext_interrupt;
 typeset2list_2_ext_interrupt:
  reasonp = 0l;
 typeset2list_2_interrupt:
  goto interrupt_2;
 }

 typeset2list1_2_top: {
  q x0, x1, x2, x3, x4, x5;
  qp = qp->next;
 typeset2list1_2_clear_reason:
  reasonp = reasons;
 typeset2list1_2_0:
 typeset2list1_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 typeset2list1_2_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto typeset2list1_2_7;
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = makesym(atom__2A);
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x1);
  a0 = cdr_of(a0);
  a1 = x2;
  execute(typeset2list1_2_0);
  goto typeset2list1_2_ext_interrupt;
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_2)) goto typeset2list1_2_7;
  x1 = arg(x0, 0);
 typeset2list1_2_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_s_3)) goto typeset2list1_2_7;
  x2 = arg(x1, 0);
 typeset2list1_2_4:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != PERIODATOM) goto typeset2list1_2_7;
  x3 = arg(x1, 1);
 typeset2list1_2_5:
  switch (ptagof(x3)) {
 case ATOMIC:
 typeset2list1_2_6:
  if (x3 != makeint(2L)) goto typeset2list1_2_7;
  allocp[0] = x5 = makeref(&allocp[0]);
  allocp[1] = x0;
  x4 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x4);
  a0 = cdr_of(a0);
  a1 = x5;
  execute(typeset2list1_2_0);
  goto typeset2list1_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x3,typeset2list1_2_5);
  *reasonp++ =  x3;
  goto typeset2list1_2_7;
  };
  goto typeset2list1_2_7;
 case VARREF:
  deref_and_jump(x2,typeset2list1_2_4);
  *reasonp++ =  x2;
  goto typeset2list1_2_7;
  };
  goto typeset2list1_2_7;
 case VARREF:
  deref_and_jump(x1,typeset2list1_2_3);
  *reasonp++ =  x1;
  goto typeset2list1_2_7;
  };
  goto typeset2list1_2_7;
 case VARREF:
  deref_and_jump(x0,typeset2list1_2_2);
  *reasonp++ =  x0;
  goto typeset2list1_2_7;
  };
  goto typeset2list1_2_7;
 case VARREF:
  deref_and_jump(a0,typeset2list1_2_1);
  *reasonp++ =  a0;
  goto typeset2list1_2_7;
  };
  goto typeset2list1_2_7;
 typeset2list1_2_7:
  otherwise(typeset2list1_2_interrupt);
 typeset2list1_2_8:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(typeset2list1_2_0);
  goto typeset2list1_2_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto typeset2list1_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,typeset2list1_2_8);
  *reasonp++ =  a0;
  goto typeset2list1_2_interrupt;
  };
  goto typeset2list1_2_interrupt;
 typeset2list1_2_ext_interrupt:
  reasonp = 0l;
 typeset2list1_2_interrupt:
  goto interrupt_2;
 }

 typeset2structtype_2_top: {
  qp = qp->next;
 typeset2structtype_2_clear_reason:
  reasonp = reasons;
 typeset2structtype_2_0:
  a2 = a1;
  a1 = NILATOM;
  execute(typeset2structtype1_3_0);
  goto typeset2structtype1_3_ext_interrupt;
 typeset2structtype_2_ext_interrupt:
  reasonp = 0l;
 typeset2structtype_2_interrupt:
  toppred = &predicate_typeset_xtypeset2structtype_2;
  goto interrupt_2;
 }

 typeset2structtype1_3_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  qp = qp->next;
 typeset2structtype1_3_clear_reason:
  reasonp = reasons;
 typeset2structtype1_3_0:
 typeset2structtype1_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 typeset2structtype1_3_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto typeset2structtype1_3_4;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xtypeset2structtype1_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  a0 = a1;
  a1 = makecons(cons_const_0);
  a2 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(or__typeset_3_0);
  goto or__typeset_3_ext_interrupt;
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_2)) goto typeset2structtype1_3_4;
  x1 = arg(x0, 0);
 typeset2structtype1_3_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_s_3)) goto typeset2structtype1_3_4;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xtypeset2structtype1_3);
  x2 = cdr_of(a0);
  allocp[2] = x2;
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = NILATOM;
  allocp[6] = x0;
  x5 = makecons(&allocp[5]);
  a0 = a1;
  a1 = x5;
  a2 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(or__typeset_3_0);
  goto or__typeset_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,typeset2structtype1_3_3);
  *reasonp++ =  x1;
  goto typeset2structtype1_3_4;
  };
  goto typeset2structtype1_3_4;
 case VARREF:
  deref_and_jump(x0,typeset2structtype1_3_2);
  *reasonp++ =  x0;
  goto typeset2structtype1_3_4;
  };
  goto typeset2structtype1_3_4;
 case VARREF:
  deref_and_jump(a0,typeset2structtype1_3_1);
  *reasonp++ =  a0;
  goto typeset2structtype1_3_4;
  };
  goto typeset2structtype1_3_4;
 typeset2structtype1_3_4:
  otherwise(typeset2structtype1_3_interrupt);
 typeset2structtype1_3_5:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(typeset2structtype1_3_0);
  goto typeset2structtype1_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto typeset2structtype1_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,typeset2structtype1_3_5);
  *reasonp++ =  a0;
  goto typeset2structtype1_3_interrupt;
  };
  goto typeset2structtype1_3_interrupt;
 typeset2structtype1_3_ext_interrupt:
  reasonp = 0l;
 typeset2structtype1_3_interrupt:
  toppred = &predicate_typeset_xtypeset2structtype1_3;
  goto interrupt_3;
 }

 merge__atomic_4_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 merge__atomic_4_clear_reason:
  reasonp = reasons;
 merge__atomic_4_0:
 merge__atomic_4_1:
  switch (ptagof(a1)) {
 case FUNCTOR:
  switch (symval(functor_of(a1))) {
 case functor_a_1:
 merge__atomic_4_2:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_a_1)) goto merge__atomic_4_22;
  x0 = arg(a2, 0);
 merge__atomic_4_3:
  if (isref(x0)) goto merge__atomic_4_6;
 merge__atomic_4_4:
  if (isref(x0)) goto merge__atomic_4_5;
  x1 = arg(a1, 0);
  if_not_equal(x0, x1, merge__atomic_4_22);
  unify_value(a3, a1);
  proceed();
 merge__atomic_4_5:
  deref_and_jump(x0,merge__atomic_4_4);
  *reasonp++ =  x0;
  goto merge__atomic_4_22;
 merge__atomic_4_6:
  deref_and_jump(x0,merge__atomic_4_3);
  *reasonp++ =  x0;
  goto merge__atomic_4_22;
 case VARREF:
  deref_and_jump(a2,merge__atomic_4_2);
  *reasonp++ =  a2;
  goto merge__atomic_4_22;
  };
  goto merge__atomic_4_22;
 case functor_i_1:
 merge__atomic_4_7:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_i_1)) goto merge__atomic_4_22;
  x0 = arg(a2, 0);
 merge__atomic_4_8:
  if (isref(x0)) goto merge__atomic_4_11;
 merge__atomic_4_9:
  if (isref(x0)) goto merge__atomic_4_10;
  x1 = arg(a1, 0);
  if_not_equal(x0, x1, merge__atomic_4_22);
  unify_value(a3, a1);
  proceed();
 merge__atomic_4_10:
  deref_and_jump(x0,merge__atomic_4_9);
  *reasonp++ =  x0;
  goto merge__atomic_4_22;
 merge__atomic_4_11:
  deref_and_jump(x0,merge__atomic_4_8);
  *reasonp++ =  x0;
  goto merge__atomic_4_22;
 case VARREF:
  deref_and_jump(a2,merge__atomic_4_7);
  *reasonp++ =  a2;
  goto merge__atomic_4_22;
  };
  goto merge__atomic_4_22;
 case functor_f_1:
 merge__atomic_4_12:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_f_1)) goto merge__atomic_4_22;
  x0 = arg(a2, 0);
 merge__atomic_4_13:
  if (isref(x0)) goto merge__atomic_4_16;
 merge__atomic_4_14:
  if (isref(x0)) goto merge__atomic_4_15;
  x1 = arg(a1, 0);
  if_not_equal(x0, x1, merge__atomic_4_22);
  unify_value(a3, a1);
  proceed();
 merge__atomic_4_15:
  deref_and_jump(x0,merge__atomic_4_14);
  *reasonp++ =  x0;
  goto merge__atomic_4_22;
 merge__atomic_4_16:
  deref_and_jump(x0,merge__atomic_4_13);
  *reasonp++ =  x0;
  goto merge__atomic_4_22;
 case VARREF:
  deref_and_jump(a2,merge__atomic_4_12);
  *reasonp++ =  a2;
  goto merge__atomic_4_22;
  };
  goto merge__atomic_4_22;
 case functor_c_1:
 merge__atomic_4_17:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_c_1)) goto merge__atomic_4_22;
  x0 = arg(a2, 0);
 merge__atomic_4_18:
  if (isref(x0)) goto merge__atomic_4_21;
 merge__atomic_4_19:
  if (isref(x0)) goto merge__atomic_4_20;
  x1 = arg(a1, 0);
  if_not_equal(x0, x1, merge__atomic_4_22);
  unify_value(a3, a1);
  proceed();
 merge__atomic_4_20:
  deref_and_jump(x0,merge__atomic_4_19);
  *reasonp++ =  x0;
  goto merge__atomic_4_22;
 merge__atomic_4_21:
  deref_and_jump(x0,merge__atomic_4_18);
  *reasonp++ =  x0;
  goto merge__atomic_4_22;
 case VARREF:
  deref_and_jump(a2,merge__atomic_4_17);
  *reasonp++ =  a2;
  goto merge__atomic_4_22;
  };
  goto merge__atomic_4_22;
  };
  goto merge__atomic_4_22;
 case VARREF:
  deref_and_jump(a1,merge__atomic_4_1);
  *reasonp++ =  a1;
  goto merge__atomic_4_22;
  };
  goto merge__atomic_4_22;
 merge__atomic_4_22:
 merge__atomic_4_23:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_and)) goto merge__atomic_4_33;
 merge__atomic_4_24:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (isint(a1)) goto merge__atomic_4_33;
  switch (symval(a1)) {
 case symval(makesym(atom_a)):
 merge__atomic_4_25:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_a_1)) goto merge__atomic_4_33;
  unify_value(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a2,merge__atomic_4_25);
  *reasonp++ =  a2;
  goto merge__atomic_4_33;
  };
  goto merge__atomic_4_33;
 case symval(makesym(atom_i)):
 merge__atomic_4_26:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_i_1)) goto merge__atomic_4_33;
  unify_value(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a2,merge__atomic_4_26);
  *reasonp++ =  a2;
  goto merge__atomic_4_33;
  };
  goto merge__atomic_4_33;
 case symval(makesym(atom_f)):
 merge__atomic_4_27:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_f_1)) goto merge__atomic_4_33;
  unify_value(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a2,merge__atomic_4_27);
  *reasonp++ =  a2;
  goto merge__atomic_4_33;
  };
  goto merge__atomic_4_33;
 case symval(makesym(atom_c)):
 merge__atomic_4_28:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_c_1)) goto merge__atomic_4_33;
  unify_value(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a2,merge__atomic_4_28);
  *reasonp++ =  a2;
  goto merge__atomic_4_33;
  };
  goto merge__atomic_4_33;
  };
  goto merge__atomic_4_33;
 case FUNCTOR:
  switch (symval(functor_of(a1))) {
 case functor_a_1:
 merge__atomic_4_29:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_a)) goto merge__atomic_4_33;
  unify_value(a3, a1);
  proceed();
 case VARREF:
  deref_and_jump(a2,merge__atomic_4_29);
  *reasonp++ =  a2;
  goto merge__atomic_4_33;
  };
  goto merge__atomic_4_33;
 case functor_i_1:
 merge__atomic_4_30:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_i)) goto merge__atomic_4_33;
  unify_value(a3, a1);
  proceed();
 case VARREF:
  deref_and_jump(a2,merge__atomic_4_30);
  *reasonp++ =  a2;
  goto merge__atomic_4_33;
  };
  goto merge__atomic_4_33;
 case functor_f_1:
 merge__atomic_4_31:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_f)) goto merge__atomic_4_33;
  unify_value(a3, a1);
  proceed();
 case VARREF:
  deref_and_jump(a2,merge__atomic_4_31);
  *reasonp++ =  a2;
  goto merge__atomic_4_33;
  };
  goto merge__atomic_4_33;
 case functor_c_1:
 merge__atomic_4_32:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_c)) goto merge__atomic_4_33;
  unify_value(a3, a1);
  proceed();
 case VARREF:
  deref_and_jump(a2,merge__atomic_4_32);
  *reasonp++ =  a2;
  goto merge__atomic_4_33;
  };
  goto merge__atomic_4_33;
  };
  goto merge__atomic_4_33;
 case VARREF:
  deref_and_jump(a1,merge__atomic_4_24);
  *reasonp++ =  a1;
  goto merge__atomic_4_33;
  };
  goto merge__atomic_4_33;
 case VARREF:
  deref_and_jump(a0,merge__atomic_4_23);
  *reasonp++ =  a0;
  goto merge__atomic_4_33;
  };
  goto merge__atomic_4_33;
 merge__atomic_4_33:
  otherwise(merge__atomic_4_interrupt);
 merge__atomic_4_34:
  if (isref(a1)) goto merge__atomic_4_43;
  gblt_pfunctor(a1,x0,merge__atomic_4_interrupt);
  if (isint(x0)) goto merge__atomic_4_interrupt;
  switch (symval(x0)) {
 case symval(makesym(atom_a)):
  gblt_arity(a1,x1,merge__atomic_4_interrupt);
 merge__atomic_4_35:
  if (isref(a2)) goto merge__atomic_4_36;
  gblt_pfunctor(a2,x2,merge__atomic_4_interrupt);
  if (x2 != makesym(atom_a)) goto merge__atomic_4_interrupt;
  gblt_arity(a2,x3,merge__atomic_4_interrupt);
  x4 = makesym(atom_a);
  unify_value(a3, x4);
  proceed();
 merge__atomic_4_36:
  deref_and_jump(a2,merge__atomic_4_35);
  *reasonp++ =  a2;
  goto merge__atomic_4_interrupt;
 case symval(makesym(atom_i)):
  gblt_arity(a1,x1,merge__atomic_4_interrupt);
 merge__atomic_4_37:
  if (isref(a2)) goto merge__atomic_4_38;
  gblt_pfunctor(a2,x2,merge__atomic_4_interrupt);
  if (x2 != makesym(atom_i)) goto merge__atomic_4_interrupt;
  gblt_arity(a2,x3,merge__atomic_4_interrupt);
  x4 = makesym(atom_i);
  unify_value(a3, x4);
  proceed();
 merge__atomic_4_38:
  deref_and_jump(a2,merge__atomic_4_37);
  *reasonp++ =  a2;
  goto merge__atomic_4_interrupt;
 case symval(makesym(atom_f)):
  gblt_arity(a1,x1,merge__atomic_4_interrupt);
 merge__atomic_4_39:
  if (isref(a2)) goto merge__atomic_4_40;
  gblt_pfunctor(a2,x2,merge__atomic_4_interrupt);
  if (x2 != makesym(atom_f)) goto merge__atomic_4_interrupt;
  gblt_arity(a2,x3,merge__atomic_4_interrupt);
  x4 = makesym(atom_f);
  unify_value(a3, x4);
  proceed();
 merge__atomic_4_40:
  deref_and_jump(a2,merge__atomic_4_39);
  *reasonp++ =  a2;
  goto merge__atomic_4_interrupt;
 case symval(makesym(atom_c)):
  gblt_arity(a1,x1,merge__atomic_4_interrupt);
 merge__atomic_4_41:
  if (isref(a2)) goto merge__atomic_4_42;
  gblt_pfunctor(a2,x2,merge__atomic_4_interrupt);
  if (x2 != makesym(atom_c)) goto merge__atomic_4_interrupt;
  gblt_arity(a2,x3,merge__atomic_4_interrupt);
  x4 = makesym(atom_c);
  unify_value(a3, x4);
  proceed();
 merge__atomic_4_42:
  deref_and_jump(a2,merge__atomic_4_41);
  *reasonp++ =  a2;
  goto merge__atomic_4_interrupt;
  };
  goto merge__atomic_4_interrupt;
 merge__atomic_4_43:
  deref_and_jump(a1,merge__atomic_4_34);
  *reasonp++ =  a1;
  goto merge__atomic_4_interrupt;
 merge__atomic_4_ext_interrupt:
  reasonp = 0l;
 merge__atomic_4_interrupt:
  toppred = &predicate_typeset_xmerge__atomic_4;
  goto interrupt_4;
 }

 get__struct__arg__typeset_3_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  qp = qp->next;
 get__struct__arg__typeset_3_clear_reason:
  reasonp = reasons;
 get__struct__arg__typeset_3_0:
 get__struct__arg__typeset_3_1:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_t_2)) goto get__struct__arg__typeset_3_4;
  x0 = arg(a1, 0);
 get__struct__arg__typeset_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_s_3)) goto get__struct__arg__typeset_3_4;
  x1 = arg(x0, 1);
 get__struct__arg__typeset_3_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom__2A)) goto get__struct__arg__typeset_3_4;
  x2 = arg(x0, 2);
  unify(a2, x2);
  proceed();
 case VARREF:
  deref_and_jump(x1,get__struct__arg__typeset_3_3);
  *reasonp++ =  x1;
  goto get__struct__arg__typeset_3_4;
  };
  goto get__struct__arg__typeset_3_4;
 case VARREF:
  deref_and_jump(x0,get__struct__arg__typeset_3_2);
  *reasonp++ =  x0;
  goto get__struct__arg__typeset_3_4;
  };
  goto get__struct__arg__typeset_3_4;
 case VARREF:
  deref_and_jump(a1,get__struct__arg__typeset_3_1);
  *reasonp++ =  a1;
  goto get__struct__arg__typeset_3_4;
  };
  goto get__struct__arg__typeset_3_4;
 get__struct__arg__typeset_3_4:
  otherwise(get__struct__arg__typeset_3_interrupt);
 get__struct__arg__typeset_3_5:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_t_2)) goto get__struct__arg__typeset_3_interrupt;
  x0 = arg(a1, 0);
 get__struct__arg__typeset_3_6:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_s_3)) goto get__struct__arg__typeset_3_interrupt;
  x1 = arg(x0, 1);
 get__struct__arg__typeset_3_7:
  if (!isint(x1)) goto get__struct__arg__typeset_3_11;
 get__struct__arg__typeset_3_8:
  if (!isint(a0)) goto get__struct__arg__typeset_3_10;
  gblt_less(x1,a0,get__struct__arg__typeset_3_9);
  x2 = makecons(cons_const_0);
  unify_value(a2, x2);
  proceed();
 get__struct__arg__typeset_3_9:
  gblt_greater_or_eq(x1,a0,get__struct__arg__typeset_3_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xarg_3);
  allocp[2] = a0;
  x2 = arg(x0, 2);
  allocp[3] = x2;
  allocp[4] = a2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 get__struct__arg__typeset_3_10:
  if (!isref(a0)) goto get__struct__arg__typeset_3_interrupt;
  deref_and_jump(a0,get__struct__arg__typeset_3_8);
  *reasonp++ =  a0;
  goto get__struct__arg__typeset_3_interrupt;
 get__struct__arg__typeset_3_11:
  if (!isref(x1)) goto get__struct__arg__typeset_3_interrupt;
  deref_and_jump(x1,get__struct__arg__typeset_3_7);
  *reasonp++ =  x1;
  goto get__struct__arg__typeset_3_interrupt;
 case VARREF:
  deref_and_jump(x0,get__struct__arg__typeset_3_6);
  *reasonp++ =  x0;
  goto get__struct__arg__typeset_3_interrupt;
  };
  goto get__struct__arg__typeset_3_interrupt;
 case VARREF:
  deref_and_jump(a1,get__struct__arg__typeset_3_5);
  *reasonp++ =  a1;
  goto get__struct__arg__typeset_3_interrupt;
  };
  goto get__struct__arg__typeset_3_interrupt;
 get__struct__arg__typeset_3_ext_interrupt:
  reasonp = 0l;
 get__struct__arg__typeset_3_interrupt:
  goto interrupt_3;
 }

 set__struct__arg__typeset_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 set__struct__arg__typeset_4_clear_reason:
  reasonp = reasons;
 set__struct__arg__typeset_4_0:
 set__struct__arg__typeset_4_1:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_t_2)) goto set__struct__arg__typeset_4_4;
  x0 = arg(a1, 0);
 set__struct__arg__typeset_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_s_3)) goto set__struct__arg__typeset_4_4;
  x1 = arg(x0, 1);
 set__struct__arg__typeset_4_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom__2A)) goto set__struct__arg__typeset_4_4;
  allocp[0] = makesym(functor_s_3);
  x3 = arg(x0, 0);
  allocp[1] = x3;
  allocp[2] = makesym(atom__2A);
  allocp[3] = x4 = makeref(&allocp[3]);
  x2 = makefunctor(&allocp[0]);
  allocp[4] = makesym(functor_t_2);
  allocp[5] = x2;
  x6 = arg(a1, 1);
  allocp[6] = x6;
  x5 = makefunctor(&allocp[4]);
  a0 = arg(x0, 2);
  a1 = a2;
  a2 = x4;
  allocp += 7;
  execute(or__typeset_3_0);
  goto or__typeset_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,set__struct__arg__typeset_4_3);
  *reasonp++ =  x1;
  goto set__struct__arg__typeset_4_4;
  };
  goto set__struct__arg__typeset_4_4;
 case VARREF:
  deref_and_jump(x0,set__struct__arg__typeset_4_2);
  *reasonp++ =  x0;
  goto set__struct__arg__typeset_4_4;
  };
  goto set__struct__arg__typeset_4_4;
 case VARREF:
  deref_and_jump(a1,set__struct__arg__typeset_4_1);
  *reasonp++ =  a1;
  goto set__struct__arg__typeset_4_4;
  };
  goto set__struct__arg__typeset_4_4;
 set__struct__arg__typeset_4_4:
  otherwise(set__struct__arg__typeset_4_interrupt);
 set__struct__arg__typeset_4_5:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_t_2)) goto set__struct__arg__typeset_4_interrupt;
  x0 = arg(a1, 0);
 set__struct__arg__typeset_4_6:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_s_3)) goto set__struct__arg__typeset_4_interrupt;
  x1 = arg(x0, 1);
 set__struct__arg__typeset_4_7:
  if (!isint(x1)) goto set__struct__arg__typeset_4_11;
 set__struct__arg__typeset_4_8:
  if (!isint(a0)) goto set__struct__arg__typeset_4_10;
  gblt_less(x1,a0,set__struct__arg__typeset_4_9);
  unify_value(a3, a1);
  proceed();
 set__struct__arg__typeset_4_9:
  gblt_greater_or_eq(x1,a0,set__struct__arg__typeset_4_interrupt);
  allocp[0] = makesym(functor_s_3);
  x3 = arg(x0, 0);
  allocp[1] = x3;
  allocp[2] = x1;
  allocp[3] = x4 = makeref(&allocp[3]);
  x2 = makefunctor(&allocp[0]);
  allocp[4] = makesym(functor_t_2);
  allocp[5] = x2;
  x6 = arg(a1, 1);
  allocp[6] = x6;
  x5 = makefunctor(&allocp[4]);
  allocp += 7;
  unify_value(a3, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[2] = a0;
  x7 = arg(x0, 2);
  allocp[3] = x7;
  allocp[4] = a2;
  allocp[5] = x4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  proceed();
 set__struct__arg__typeset_4_10:
  if (!isref(a0)) goto set__struct__arg__typeset_4_interrupt;
  deref_and_jump(a0,set__struct__arg__typeset_4_8);
  *reasonp++ =  a0;
  goto set__struct__arg__typeset_4_interrupt;
 set__struct__arg__typeset_4_11:
  if (!isref(x1)) goto set__struct__arg__typeset_4_interrupt;
  deref_and_jump(x1,set__struct__arg__typeset_4_7);
  *reasonp++ =  x1;
  goto set__struct__arg__typeset_4_interrupt;
 case VARREF:
  deref_and_jump(x0,set__struct__arg__typeset_4_6);
  *reasonp++ =  x0;
  goto set__struct__arg__typeset_4_interrupt;
  };
  goto set__struct__arg__typeset_4_interrupt;
 case VARREF:
  deref_and_jump(a1,set__struct__arg__typeset_4_5);
  *reasonp++ =  a1;
  goto set__struct__arg__typeset_4_interrupt;
  };
  goto set__struct__arg__typeset_4_interrupt;
 set__struct__arg__typeset_4_ext_interrupt:
  reasonp = 0l;
 set__struct__arg__typeset_4_interrupt:
  goto interrupt_4;
 }

 listtype__val_3_top: {
  q x0;
  a2 = qp->args[2];
  qp = qp->next;
 listtype__val_3_clear_reason:
  reasonp = reasons;
 listtype__val_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xlisttype__val__merge_3);
  allocp[2] = a1;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a2;
  a2 = a1;
  a3 = x0;
  a1 = makeint(0L);
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(listtype__val1_4_0);
  goto listtype__val1_4_ext_interrupt;
 listtype__val_3_ext_interrupt:
  reasonp = 0l;
 listtype__val_3_interrupt:
  goto interrupt_3;
 }

 listtype__val1_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 listtype__val1_4_clear_reason:
  reasonp = reasons;
 listtype__val1_4_0:
 listtype__val1_4_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_t_2)) goto listtype__val1_4_7;
  x0 = arg(a0, 0);
 listtype__val1_4_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_a)) goto listtype__val1_4_7;
  x1 = NILATOM;
  unify_value(a3, x1);
  unify(a2, a1);
  proceed();
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_s_3:
  x1 = arg(x0, 0);
 listtype__val1_4_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != PERIODATOM) goto listtype__val1_4_7;
  x2 = arg(x0, 1);
 listtype__val1_4_4:
  switch (ptagof(x2)) {
 case ATOMIC:
 listtype__val1_4_5:
  if (x2 != makeint(2L)) goto listtype__val1_4_7;
  x3 = arg(x0, 2);
 listtype__val1_4_6:
  switch (ptagof(x3)) {
 case FUNCTOR:
  if (functor_of(x3) != makesym(functor_args_2)) goto listtype__val1_4_7;
  allocp[0] = x5 = makeref(&allocp[0]);
  x6 = arg(x3, 0);
  allocp[1] = x6;
  x4 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a3, x4);
  x7 = makeint(1L);
  bblt_add_no_check_y(a1,x7,x8);
  a0 = arg(x3, 1);
  a1 = x8;
  a3 = x5;
  execute(listtype__val2_4_0);
  goto listtype__val2_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x3,listtype__val1_4_6);
  *reasonp++ =  x3;
  goto listtype__val1_4_7;
  };
  goto listtype__val1_4_7;
 case VARREF:
  deref_and_jump(x2,listtype__val1_4_4);
  *reasonp++ =  x2;
  goto listtype__val1_4_7;
  };
  goto listtype__val1_4_7;
 case VARREF:
  deref_and_jump(x1,listtype__val1_4_3);
  *reasonp++ =  x1;
  goto listtype__val1_4_7;
  };
  goto listtype__val1_4_7;
 case functor_a_1:
  x1 = NILATOM;
  unify_value(a3, x1);
  unify(a2, a1);
  proceed();
  };
  goto listtype__val1_4_7;
 case VARREF:
  deref_and_jump(x0,listtype__val1_4_2);
  *reasonp++ =  x0;
  goto listtype__val1_4_7;
  };
  goto listtype__val1_4_7;
 case VARREF:
  deref_and_jump(a0,listtype__val1_4_1);
  *reasonp++ =  a0;
  goto listtype__val1_4_7;
  };
  goto listtype__val1_4_7;
 listtype__val1_4_7:
  otherwise(listtype__val1_4_interrupt);
  x0 = NILATOM;
  unify_value(a3, x0);
  x1 = makesym(atom__2A);
  unify_value(a2, x1);
  proceed();
 listtype__val1_4_ext_interrupt:
  reasonp = 0l;
 listtype__val1_4_interrupt:
  toppred = &predicate_typeset_xlisttype__val1_4;
  goto interrupt_4;
 }

 listtype__val2_4_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 listtype__val2_4_clear_reason:
  reasonp = reasons;
 listtype__val2_4_0:
 listtype__val2_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = cdr_of(a0);
 listtype__val2_4_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != NILATOM) goto listtype__val2_4_interrupt;
  a0 = car_of(a0);
  execute(listtype__val1_4_0);
  goto listtype__val1_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,listtype__val2_4_2);
  *reasonp++ =  x0;
  goto listtype__val2_4_interrupt;
  };
  goto listtype__val2_4_interrupt;
 case VARREF:
  deref_and_jump(a0,listtype__val2_4_1);
  *reasonp++ =  a0;
  goto listtype__val2_4_interrupt;
  };
  goto listtype__val2_4_interrupt;
 listtype__val2_4_ext_interrupt:
  reasonp = 0l;
 listtype__val2_4_interrupt:
  toppred = &predicate_typeset_xlisttype__val2_4;
  goto interrupt_4;
 }

 listtype__val__merge_3_top: {
  a2 = qp->args[2];
  qp = qp->next;
 listtype__val__merge_3_clear_reason:
  reasonp = reasons;
 listtype__val__merge_3_0:
 listtype__val__merge_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto listtype__val__merge_3_2;
  if (a0 != makesym(atom__2A)) goto listtype__val__merge_3_interrupt;
  a0 = NILATOM;
  execute(listtype__val__merge1_3_0);
  goto listtype__val__merge1_3_ext_interrupt;
 listtype__val__merge_3_2:
  gblt_integer(a0,listtype__val__merge_3_interrupt);
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,listtype__val__merge_3_1);
  *reasonp++ =  a0;
  goto listtype__val__merge_3_interrupt;
  };
  goto listtype__val__merge_3_interrupt;
 listtype__val__merge_3_ext_interrupt:
  reasonp = 0l;
 listtype__val__merge_3_interrupt:
  goto interrupt_3;
 }

 listtype__val__merge1_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 listtype__val__merge1_3_clear_reason:
  reasonp = reasons;
 listtype__val__merge1_3_0:
 listtype__val__merge1_3_1:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xlisttype__val__merge1_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  x1 = cdr_of(a1);
  allocp[3] = x1;
  allocp[4] = a2;
  a1 = car_of(a1);
  a2 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(or__typeset_3_0);
  goto or__typeset_3_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto listtype__val__merge1_3_interrupt;
  unify(a2, a0);
  proceed();
 case VARREF:
  deref_and_jump(a1,listtype__val__merge1_3_1);
  *reasonp++ =  a1;
  goto listtype__val__merge1_3_interrupt;
  };
  goto listtype__val__merge1_3_interrupt;
 listtype__val__merge1_3_ext_interrupt:
  reasonp = 0l;
 listtype__val__merge1_3_interrupt:
  toppred = &predicate_typeset_xlisttype__val__merge1_3;
  goto interrupt_3;
 }

 check__dg_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 check__dg_4_clear_reason:
  reasonp = reasons;
 check__dg_4_0:
 check__dg_4_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 check__dg_4_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto check__dg_4_4;
  x1 = cdr_of(a1);
 check__dg_4_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto check__dg_4_4;
  x2 = makesym(atom_no);
  unify_value(a2, x2);
  proceed();
 case VARREF:
  deref_and_jump(x1,check__dg_4_3);
  *reasonp++ =  x1;
  goto check__dg_4_4;
  };
  goto check__dg_4_4;
 case VARREF:
  deref_and_jump(x0,check__dg_4_2);
  *reasonp++ =  x0;
  goto check__dg_4_4;
  };
  goto check__dg_4_4;
 case VARREF:
  deref_and_jump(a1,check__dg_4_1);
  *reasonp++ =  a1;
  goto check__dg_4_4;
  };
  goto check__dg_4_4;
 check__dg_4_4:
  otherwise(check__dg_4_interrupt);
 check__dg_4_5:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 check__dg_4_6:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto check__dg_4_10;
  a1 = cdr_of(a1);
  execute(check__dg_4_0);
  goto check__dg_4_ext_interrupt;
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_t_2:
 check__dg_4_7:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_normal)) goto check__dg_4_10;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xcheck__dg2_5);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a0;
  x2 = cdr_of(a1);
  allocp[4] = x2;
  allocp[5] = a2;
  allocp[6] = makesym(atom_normal);
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_depset_xcheck__include_3);
  allocp[9] = a0;
  x3 = arg(x0, 1);
  allocp[10] = x3;
  allocp[11] = x1;
  qp = (struct goalrec*)&allocp[7];
  allocp += 12;
  proceed();
 case VARREF:
  deref_and_jump(a3,check__dg_4_7);
  *reasonp++ =  a3;
  goto check__dg_4_10;
  };
  goto check__dg_4_10;
 case functor_tv_2:
 check__dg_4_8:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_normal)) goto check__dg_4_10;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xcheck__dg2_5);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a0;
  x2 = cdr_of(a1);
  allocp[4] = x2;
  allocp[5] = a2;
  allocp[6] = makesym(atom_normal);
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_depset_xcheck__include_3);
  allocp[9] = a0;
  x3 = arg(x0, 1);
  allocp[10] = x3;
  allocp[11] = x1;
  qp = (struct goalrec*)&allocp[7];
  allocp += 12;
  proceed();
 case VARREF:
  deref_and_jump(a3,check__dg_4_8);
  *reasonp++ =  a3;
  goto check__dg_4_10;
  };
  goto check__dg_4_10;
 case functor_tt_3:
 check__dg_4_9:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_expand)) goto check__dg_4_10;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xcheck__dg2_5);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a0;
  x2 = cdr_of(a1);
  allocp[4] = x2;
  allocp[5] = a2;
  allocp[6] = makesym(atom_expand);
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_depset_xcheck__include_3);
  allocp[9] = a0;
  x3 = arg(x0, 2);
  allocp[10] = x3;
  allocp[11] = x1;
  qp = (struct goalrec*)&allocp[7];
  allocp += 12;
  proceed();
 case VARREF:
  deref_and_jump(a3,check__dg_4_9);
  *reasonp++ =  a3;
  goto check__dg_4_10;
  };
  goto check__dg_4_10;
  };
  goto check__dg_4_10;
 case VARREF:
  deref_and_jump(x0,check__dg_4_6);
  *reasonp++ =  x0;
  goto check__dg_4_10;
  };
  goto check__dg_4_10;
 check__dg_4_10:
 check__dg_4_11:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_expand)) goto check__dg_4_interrupt;
 check__dg_4_12:
  if (isref(x0)) goto check__dg_4_14;
  gblt_pfunctor(x0,x1,check__dg_4_interrupt);
  gblt_arity(x0,x2,check__dg_4_interrupt);
 check__dg_4_13:
  if (x2 != makeint(2L)) goto check__dg_4_interrupt;
  a1 = cdr_of(a1);
  a3 = makesym(atom_expand);
  execute(check__dg_4_clear_reason);
  goto check__dg_4_ext_interrupt;
 check__dg_4_14:
  deref_and_jump(x0,check__dg_4_12);
  *reasonp++ =  x0;
  goto check__dg_4_interrupt;
 case VARREF:
  deref_and_jump(a3,check__dg_4_11);
  *reasonp++ =  a3;
  goto check__dg_4_interrupt;
  };
  goto check__dg_4_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto check__dg_4_interrupt;
  x0 = makesym(atom_yes);
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,check__dg_4_5);
  *reasonp++ =  a1;
  goto check__dg_4_interrupt;
  };
  goto check__dg_4_interrupt;
 check__dg_4_ext_interrupt:
  reasonp = 0l;
 check__dg_4_interrupt:
  toppred = &predicate_typeset_xcheck__dg_4;
  goto interrupt_4;
 }

 check__dg2_5_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 check__dg2_5_clear_reason:
  reasonp = reasons;
 check__dg2_5_0:
 check__dg2_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto check__dg2_5_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  a0 = a1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  execute(check__dg_4_0);
  goto check__dg_4_ext_interrupt;
 case symval(makesym(atom_no)):
  x0 = makesym(atom_no);
  unify_value(a3, x0);
  proceed();
  };
  goto check__dg2_5_interrupt;
 case VARREF:
  deref_and_jump(a0,check__dg2_5_1);
  *reasonp++ =  a0;
  goto check__dg2_5_interrupt;
  };
  goto check__dg2_5_interrupt;
 check__dg2_5_ext_interrupt:
  reasonp = 0l;
 check__dg2_5_interrupt:
  goto interrupt_5;
 }

 remove__ds_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  qp = qp->next;
 remove__ds_2_clear_reason:
  reasonp = reasons;
 remove__ds_2_0:
 remove__ds_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 remove__ds_2_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_t_2)) goto remove__ds_2_4;
  x1 = arg(x0, 0);
 remove__ds_2_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_s_3)) goto remove__ds_2_4;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xremove__ds_2);
  x2 = cdr_of(a0);
  allocp[2] = x2;
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = makesym(functor_s_3);
  x5 = arg(x1, 0);
  allocp[5] = x5;
  x6 = arg(x1, 1);
  allocp[6] = x6;
  allocp[7] = x7 = makeref(&allocp[7]);
  x4 = makefunctor(&allocp[4]);
  allocp[8] = makesym(functor_t_2);
  allocp[9] = x4;
  allocp[10] = NILATOM;
  x8 = makefunctor(&allocp[8]);
  allocp[11] = x3;
  allocp[12] = x8;
  x9 = makecons(&allocp[11]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 13;
  unify_value(a1, x9);
  a0 = arg(x1, 1);
  a1 = arg(x1, 2);
  a2 = x7;
  execute(remove__ds__struct_3_0);
  goto remove__ds__struct_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,remove__ds_2_3);
  *reasonp++ =  x1;
  goto remove__ds_2_4;
  };
  goto remove__ds_2_4;
 case VARREF:
  deref_and_jump(x0,remove__ds_2_2);
  *reasonp++ =  x0;
  goto remove__ds_2_4;
  };
  goto remove__ds_2_4;
 case VARREF:
  deref_and_jump(a0,remove__ds_2_1);
  *reasonp++ =  a0;
  goto remove__ds_2_4;
  };
  goto remove__ds_2_4;
 remove__ds_2_4:
  otherwise(remove__ds_2_interrupt);
 remove__ds_2_5:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 remove__ds_2_6:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto remove__ds_2_interrupt;
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = makesym(atom__2A);
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x1);
  a0 = cdr_of(a0);
  a1 = x2;
  execute(remove__ds_2_0);
  goto remove__ds_2_ext_interrupt;
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_t_2:
  allocp[0] = makesym(functor_t_2);
  x2 = arg(x0, 0);
  allocp[1] = x2;
  allocp[2] = NILATOM;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = x4 = makeref(&allocp[3]);
  allocp[4] = x1;
  x3 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a1, x3);
  a0 = cdr_of(a0);
  a1 = x4;
  execute(remove__ds_2_0);
  goto remove__ds_2_ext_interrupt;
 case functor_tv_2:
  allocp[0] = makesym(functor_tv_2);
  x2 = arg(x0, 0);
  allocp[1] = x2;
  allocp[2] = NILATOM;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = x4 = makeref(&allocp[3]);
  allocp[4] = x1;
  x3 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a1, x3);
  a0 = cdr_of(a0);
  a1 = x4;
  execute(remove__ds_2_0);
  goto remove__ds_2_ext_interrupt;
 case functor_tt_3:
  allocp[0] = makesym(functor_tt_3);
  x2 = arg(x0, 0);
  allocp[1] = x2;
  x3 = arg(x0, 1);
  allocp[2] = x3;
  allocp[3] = NILATOM;
  x1 = makefunctor(&allocp[0]);
  allocp[4] = x5 = makeref(&allocp[4]);
  allocp[5] = x1;
  x4 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a1, x4);
  a0 = cdr_of(a0);
  a1 = x5;
  execute(remove__ds_2_0);
  goto remove__ds_2_ext_interrupt;
 case functor_te_4:
  allocp[0] = makesym(functor_te_4);
  x2 = arg(x0, 0);
  allocp[1] = x2;
  x3 = arg(x0, 1);
  allocp[2] = x3;
  x4 = arg(x0, 2);
  allocp[3] = x4;
  allocp[4] = NILATOM;
  x1 = makefunctor(&allocp[0]);
  allocp[5] = x6 = makeref(&allocp[5]);
  allocp[6] = x1;
  x5 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a1, x5);
  a0 = cdr_of(a0);
  a1 = x6;
  execute(remove__ds_2_0);
  goto remove__ds_2_ext_interrupt;
  };
  goto remove__ds_2_interrupt;
 case VARREF:
  deref_and_jump(x0,remove__ds_2_6);
  *reasonp++ =  x0;
  goto remove__ds_2_interrupt;
  };
  goto remove__ds_2_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto remove__ds_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,remove__ds_2_5);
  *reasonp++ =  a0;
  goto remove__ds_2_interrupt;
  };
  goto remove__ds_2_interrupt;
 remove__ds_2_ext_interrupt:
  reasonp = 0l;
 remove__ds_2_interrupt:
  toppred = &predicate_typeset_xremove__ds_2;
  goto interrupt_2;
 }

 remove__ds__struct_3_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  qp = qp->next;
 remove__ds__struct_3_clear_reason:
  reasonp = reasons;
 remove__ds__struct_3_0:
 remove__ds__struct_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto remove__ds__struct_3_2;
  if (a0 != makesym(atom__2A)) goto remove__ds__struct_3_interrupt;
  a0 = a1;
  a1 = a2;
  execute(remove__ds_2_0);
  goto remove__ds_2_ext_interrupt;
 remove__ds__struct_3_2:
  if (a0 != makeint(0L)) goto remove__ds__struct_3_3;
  unify(a2, a1);
  proceed();
 remove__ds__struct_3_3:
  gblt_integer(a0,remove__ds__struct_3_interrupt);
  x0 = makeint(0L);
  gblt_greater(a0,x0,remove__ds__struct_3_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xremove__ds__struct_3);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[7] = a0;
  allocp[8] = makeint(1L);
  allocp[9] = x1;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[12] = a0;
  allocp[13] = a1;
  allocp[14] = x3 = makeref(&allocp[14]);
  allocp[15] = x2;
  allocp[16] = (q)(struct goalrec*)&allocp[10];
  allocp[17] = (q)(&predicate_typeset_xremove__ds_2);
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = x3;
  allocp[20] = (q)(struct goalrec*)&allocp[16];
  allocp[21] = (q)(&predicate_functor__table_xarg_3);
  allocp[22] = a0;
  allocp[23] = a1;
  allocp[24] = x4;
  qp = (struct goalrec*)&allocp[20];
  allocp += 25;
  proceed();
 case VARREF:
  deref_and_jump(a0,remove__ds__struct_3_1);
  *reasonp++ =  a0;
  goto remove__ds__struct_3_interrupt;
  };
  goto remove__ds__struct_3_interrupt;
 remove__ds__struct_3_ext_interrupt:
  reasonp = 0l;
 remove__ds__struct_3_interrupt:
  toppred = &predicate_typeset_xremove__ds__struct_3;
  goto interrupt_3;
 }

 make__shared__ts_8_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 make__shared__ts_8_clear_reason:
  reasonp = reasons;
 make__shared__ts_8_0:
 make__shared__ts_8_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto make__shared__ts_8_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom__2D)):
  unify(a7, a6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xadd__dgoal_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a4;
  allocp[4] = a3;
  allocp[5] = a5;
  a0 = a2;
  a1 = x0;
  allocp[6] = x1 = makeref(&allocp[6]);
  a2 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(remove__ds_3_0);
  goto remove__ds_3_ext_interrupt;
 case symval(makesym(atom__2B)):
  a0 = makesym(atom__2B);
  execute(make__shared__ts2_8_0);
  goto make__shared__ts2_8_ext_interrupt;
  };
  goto make__shared__ts_8_interrupt;
 case VARREF:
  deref_and_jump(a0,make__shared__ts_8_1);
  *reasonp++ =  a0;
  goto make__shared__ts_8_interrupt;
  };
  goto make__shared__ts_8_interrupt;
 make__shared__ts_8_ext_interrupt:
  reasonp = 0l;
 make__shared__ts_8_interrupt:
  toppred = &predicate_typeset_xmake__shared__ts_8;
  goto interrupt_8;
 }

 make__shared__ts2_8_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 make__shared__ts2_8_clear_reason:
  reasonp = reasons;
 make__shared__ts2_8_0:
 make__shared__ts2_8_1:
  switch (ptagof(a2)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xmake__shared__ts2_8);
  allocp[2] = a0;
  allocp[3] = a1;
  x0 = cdr_of(a2);
  allocp[4] = x0;
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x1;
  allocp[11] = x4 = makeref(&allocp[11]);
  x3 = makecons(&allocp[10]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  unify_value(a3, x3);
  a2 = car_of(a2);
  a3 = x4;
  a7 = x2;
  execute(make__shared__type_8_0);
  goto make__shared__type_8_ext_interrupt;
 case ATOMIC:
  if (a2 != NILATOM) goto make__shared__ts2_8_interrupt;
  unify(a7, a6);
  x0 = NILATOM;
  unify_value(a3, x0);
  proceed();
 case VARREF:
  deref_and_jump(a2,make__shared__ts2_8_1);
  *reasonp++ =  a2;
  goto make__shared__ts2_8_interrupt;
  };
  goto make__shared__ts2_8_interrupt;
 make__shared__ts2_8_ext_interrupt:
  reasonp = 0l;
 make__shared__ts2_8_interrupt:
  toppred = &predicate_typeset_xmake__shared__ts2_8;
  goto interrupt_8;
 }

 make__shared__type_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 make__shared__type_8_clear_reason:
  reasonp = reasons;
 make__shared__type_8_0:
 make__shared__type_8_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom__2B)) goto make__shared__type_8_7;
 make__shared__type_8_2:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (a5 != makesym(atom_normal)) goto make__shared__type_8_7;
 make__shared__type_8_3:
  switch (ptagof(a2)) {
 case FUNCTOR:
  switch (symval(functor_of(a2))) {
 case functor_t_2:
  x0 = arg(a2, 0);
 make__shared__type_8_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_s_3)) goto make__shared__type_8_7;
  x1 = arg(x0, 1);
 make__shared__type_8_5:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (isint(x1)) goto make__shared__type_8_6;
  if (x1 != makesym(atom__2A)) goto make__shared__type_8_7;
  allocp[0] = makesym(functor_s_3);
  x3 = arg(x0, 0);
  allocp[1] = x3;
  allocp[2] = makesym(atom__2A);
  allocp[3] = x4 = makeref(&allocp[3]);
  x2 = makefunctor(&allocp[0]);
  allocp[4] = makesym(functor_t_2);
  allocp[5] = x2;
  allocp[6] = x6 = makeref(&allocp[6]);
  x5 = makefunctor(&allocp[4]);
  allocp += 7;
  unify_value(a3, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xmake__nest_5);
  allocp[2] = a1;
  allocp[3] = a4;
  allocp[4] = makesym(atom__2B);
  x7 = arg(a2, 1);
  allocp[5] = x7;
  allocp[6] = x6;
  a0 = makesym(atom__2B);
  a2 = arg(x0, 2);
  a3 = x4;
  a5 = makesym(atom_normal);
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(make__shared__ts_8_0);
  goto make__shared__ts_8_ext_interrupt;
 make__shared__type_8_6:
  gblt_integer(x1,make__shared__type_8_7);
  allocp[0] = makesym(functor_s_3);
  x3 = arg(x0, 0);
  allocp[1] = x3;
  allocp[2] = x1;
  allocp[3] = x4 = makeref(&allocp[3]);
  x2 = makefunctor(&allocp[0]);
  allocp[4] = makesym(functor_t_2);
  allocp[5] = x2;
  allocp[6] = x6 = makeref(&allocp[6]);
  x5 = makefunctor(&allocp[4]);
  allocp += 7;
  unify_value(a3, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xmake__nest_5);
  allocp[2] = a1;
  allocp[3] = a4;
  allocp[4] = makesym(atom__2B);
  x7 = arg(a2, 1);
  allocp[5] = x7;
  allocp[6] = x6;
  a0 = makesym(atom__2B);
  a2 = x1;
  a3 = arg(x0, 2);
  a5 = a4;
  x8 = a6;
  a8 = a7;
  a7 = x8;
  a6 = makesym(atom_normal);
  a4 = x4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(make__struct__ts_9_0);
  goto make__struct__ts_9_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,make__shared__type_8_5);
  *reasonp++ =  x1;
  goto make__shared__type_8_7;
  };
  goto make__shared__type_8_7;
 case VARREF:
  deref_and_jump(x0,make__shared__type_8_4);
  *reasonp++ =  x0;
  goto make__shared__type_8_7;
  };
  goto make__shared__type_8_7;
 case functor_tv_2:
  unify(a7, a6);
  allocp[0] = makesym(functor_tv_2);
  x1 = arg(a2, 0);
  allocp[1] = x1;
  allocp[2] = x2 = makeref(&allocp[2]);
  x0 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a3, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xmake__nest_5);
  allocp[2] = a1;
  allocp[3] = a4;
  allocp[4] = makesym(atom__2B);
  x3 = arg(a2, 1);
  allocp[5] = x3;
  allocp[6] = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  proceed();
  };
  goto make__shared__type_8_7;
 case VARREF:
  deref_and_jump(a2,make__shared__type_8_3);
  *reasonp++ =  a2;
  goto make__shared__type_8_7;
  };
  goto make__shared__type_8_7;
 case VARREF:
  deref_and_jump(a5,make__shared__type_8_2);
  *reasonp++ =  a5;
  goto make__shared__type_8_7;
  };
  goto make__shared__type_8_7;
 case VARREF:
  deref_and_jump(a0,make__shared__type_8_1);
  *reasonp++ =  a0;
  goto make__shared__type_8_7;
  };
  goto make__shared__type_8_7;
 make__shared__type_8_7:
  otherwise(make__shared__type_8_interrupt);
 make__shared__type_8_8:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom__2B)) goto make__shared__type_8_12;
 make__shared__type_8_9:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (isint(a5)) goto make__shared__type_8_12;
  switch (symval(a5)) {
 case symval(makesym(atom_normal)):
 make__shared__type_8_10:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_t_2)) goto make__shared__type_8_12;
  unify(a7, a6);
  allocp[0] = makesym(functor_t_2);
  x1 = arg(a2, 0);
  allocp[1] = x1;
  allocp[2] = x2 = makeref(&allocp[2]);
  x0 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a3, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xmake__nest_5);
  allocp[2] = a1;
  allocp[3] = a4;
  allocp[4] = makesym(atom__2B);
  x3 = arg(a2, 1);
  allocp[5] = x3;
  allocp[6] = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  proceed();
 case VARREF:
  deref_and_jump(a2,make__shared__type_8_10);
  *reasonp++ =  a2;
  goto make__shared__type_8_12;
  };
  goto make__shared__type_8_12;
 case symval(makesym(atom_expand)):
 make__shared__type_8_11:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_tt_3)) goto make__shared__type_8_12;
  unify(a7, a6);
  allocp[0] = makesym(functor_tt_3);
  x1 = arg(a2, 0);
  allocp[1] = x1;
  x2 = arg(a2, 1);
  allocp[2] = x2;
  allocp[3] = x3 = makeref(&allocp[3]);
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a3, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xmake__nest_5);
  allocp[2] = a1;
  allocp[3] = a4;
  allocp[4] = makesym(atom__2B);
  x4 = arg(a2, 2);
  allocp[5] = x4;
  allocp[6] = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  proceed();
 case VARREF:
  deref_and_jump(a2,make__shared__type_8_11);
  *reasonp++ =  a2;
  goto make__shared__type_8_12;
  };
  goto make__shared__type_8_12;
  };
  goto make__shared__type_8_12;
 case VARREF:
  deref_and_jump(a5,make__shared__type_8_9);
  *reasonp++ =  a5;
  goto make__shared__type_8_12;
  };
  goto make__shared__type_8_12;
 case VARREF:
  deref_and_jump(a0,make__shared__type_8_8);
  *reasonp++ =  a0;
  goto make__shared__type_8_12;
  };
  goto make__shared__type_8_12;
 make__shared__type_8_12:
  otherwise(make__shared__type_8_interrupt);
  unify2(a7, a6, a3, a2);
  proceed();
 make__shared__type_8_ext_interrupt:
  reasonp = 0l;
 make__shared__type_8_interrupt:
  toppred = &predicate_typeset_xmake__shared__type_8;
  goto interrupt_8;
 }

 make__struct__ts_9_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 make__struct__ts_9_clear_reason:
  reasonp = reasons;
 make__struct__ts_9_0:
 make__struct__ts_9_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom__2B)) goto make__struct__ts_9_4;
 make__struct__ts_9_2:
  if (!isint(a2)) goto make__struct__ts_9_3;
  x0 = makeint(0L);
  gblt_greater(a2,x0,make__struct__ts_9_4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xmake__struct__ts_9);
  allocp[2] = makesym(atom__2B);
  allocp[3] = a1;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = x3 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[13] = a2;
  allocp[14] = makeint(1L);
  allocp[15] = x1;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[18] = a2;
  allocp[19] = a3;
  allocp[20] = x4 = makeref(&allocp[20]);
  allocp[21] = x2;
  allocp[22] = (q)(struct goalrec*)&allocp[16];
  allocp[23] = (q)(&predicate_typeset_xmake__shared__ts_8);
  allocp[24] = makesym(atom__2B);
  allocp[25] = a1;
  allocp[26] = x5 = makeref(&allocp[26]);
  allocp[27] = x4;
  allocp[28] = a5;
  allocp[29] = a6;
  allocp[30] = a7;
  allocp[31] = x3;
  allocp[32] = (q)(struct goalrec*)&allocp[22];
  allocp[33] = (q)(&predicate_functor__table_xarg_3);
  allocp[34] = a2;
  allocp[35] = a3;
  allocp[36] = x5;
  qp = (struct goalrec*)&allocp[32];
  allocp += 37;
  proceed();
 make__struct__ts_9_3:
  if (!isref(a2)) goto make__struct__ts_9_4;
  deref_and_jump(a2,make__struct__ts_9_2);
  *reasonp++ =  a2;
  goto make__struct__ts_9_4;
 case VARREF:
  deref_and_jump(a0,make__struct__ts_9_1);
  *reasonp++ =  a0;
  goto make__struct__ts_9_4;
  };
  goto make__struct__ts_9_4;
 make__struct__ts_9_4:
 make__struct__ts_9_5:
  switch (ptagof(a2)) {
 case ATOMIC:
 make__struct__ts_9_6:
  if (a2 != makeint(0L)) goto make__struct__ts_9_interrupt;
  unify2(a8, a7, a4, a3);
  proceed();
 case VARREF:
  deref_and_jump(a2,make__struct__ts_9_5);
  *reasonp++ =  a2;
  goto make__struct__ts_9_interrupt;
  };
  goto make__struct__ts_9_interrupt;
 make__struct__ts_9_ext_interrupt:
  reasonp = 0l;
 make__struct__ts_9_interrupt:
  toppred = &predicate_typeset_xmake__struct__ts_9;
  goto interrupt_9;
 }

 remove__ds_3_top: {
  a2 = qp->args[2];
  qp = qp->next;
 remove__ds_3_clear_reason:
  reasonp = reasons;
 remove__ds_3_0:
  a3 = a2;
  a2 = NILATOM;
  execute(remove__ds_4_0);
  goto remove__ds_4_ext_interrupt;
 remove__ds_3_ext_interrupt:
  reasonp = 0l;
 remove__ds_3_interrupt:
  toppred = &predicate_typeset_xremove__ds_3;
  goto interrupt_3;
 }

 remove__ds_4_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 remove__ds_4_clear_reason:
  reasonp = reasons;
 remove__ds_4_0:
 remove__ds_4_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xremove__ds_4);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x1;
  allocp[7] = x4 = makeref(&allocp[7]);
  x3 = makecons(&allocp[6]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  unify_value(a1, x3);
  a0 = car_of(a0);
  a1 = x4;
  a3 = x2;
  execute(remove__ds2_4_0);
  goto remove__ds2_4_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto remove__ds_4_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,remove__ds_4_1);
  *reasonp++ =  a0;
  goto remove__ds_4_interrupt;
  };
  goto remove__ds_4_interrupt;
 remove__ds_4_ext_interrupt:
  reasonp = 0l;
 remove__ds_4_interrupt:
  toppred = &predicate_typeset_xremove__ds_4;
  goto interrupt_4;
 }

 remove__ds2_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 remove__ds2_4_clear_reason:
  reasonp = reasons;
 remove__ds2_4_0:
 remove__ds2_4_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_t_2:
  x0 = arg(a0, 0);
 remove__ds2_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_s_3)) goto remove__ds2_4_5;
  x1 = arg(x0, 1);
 remove__ds2_4_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (isint(x1)) goto remove__ds2_4_4;
  if (x1 != makesym(atom__2A)) goto remove__ds2_4_5;
  allocp[0] = makesym(functor_s_3);
  x3 = arg(x0, 0);
  allocp[1] = x3;
  allocp[2] = makesym(atom__2A);
  allocp[3] = x4 = makeref(&allocp[3]);
  x2 = makefunctor(&allocp[0]);
  allocp[4] = makesym(functor_t_2);
  allocp[5] = x2;
  allocp[6] = NILATOM;
  x5 = makefunctor(&allocp[4]);
  allocp += 7;
  unify_value(a1, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xremove__ds_4);
  x6 = arg(x0, 2);
  allocp[2] = x6;
  allocp[3] = x4;
  allocp[4] = x7 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_depset_xmerge__depset_3);
  allocp[8] = x8 = makeref(&allocp[8]);
  allocp[9] = a2;
  allocp[10] = x7;
  a0 = arg(a0, 1);
  a1 = x8;
  qp = (struct goalrec*)&allocp[6];
  allocp += 11;
  execute(get__loopds_2_0);
  goto get__loopds_2_ext_interrupt;
 remove__ds2_4_4:
  gblt_integer(x1,remove__ds2_4_5);
  allocp[0] = makesym(functor_s_3);
  x3 = arg(x0, 0);
  allocp[1] = x3;
  allocp[2] = x1;
  allocp[3] = x4 = makeref(&allocp[3]);
  x2 = makefunctor(&allocp[0]);
  allocp[4] = makesym(functor_t_2);
  allocp[5] = x2;
  allocp[6] = NILATOM;
  x5 = makefunctor(&allocp[4]);
  allocp += 7;
  unify_value(a1, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xremove__struct__ds_5);
  allocp[2] = x1;
  x6 = arg(x0, 2);
  allocp[3] = x6;
  allocp[4] = x4;
  allocp[5] = x7 = makeref(&allocp[5]);
  allocp[6] = a3;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_depset_xmerge__depset_3);
  allocp[9] = x8 = makeref(&allocp[9]);
  allocp[10] = a2;
  allocp[11] = x7;
  a0 = arg(a0, 1);
  a1 = x8;
  qp = (struct goalrec*)&allocp[7];
  allocp += 12;
  execute(get__loopds_2_0);
  goto get__loopds_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,remove__ds2_4_3);
  *reasonp++ =  x1;
  goto remove__ds2_4_5;
  };
  goto remove__ds2_4_5;
 case VARREF:
  deref_and_jump(x0,remove__ds2_4_2);
  *reasonp++ =  x0;
  goto remove__ds2_4_5;
  };
  goto remove__ds2_4_5;
 case functor_tv_2:
  allocp[0] = makesym(functor_tv_2);
  x1 = arg(a0, 0);
  allocp[1] = x1;
  allocp[2] = NILATOM;
  x0 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xmerge__depset_3);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = a2;
  allocp[4] = a3;
  a0 = arg(a0, 1);
  a1 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(get__loopds_2_0);
  goto get__loopds_2_ext_interrupt;
  };
  goto remove__ds2_4_5;
 case VARREF:
  deref_and_jump(a0,remove__ds2_4_1);
  *reasonp++ =  a0;
  goto remove__ds2_4_5;
  };
  goto remove__ds2_4_5;
 remove__ds2_4_5:
  otherwise(remove__ds2_4_interrupt);
 remove__ds2_4_6:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom__2A)) goto remove__ds2_4_interrupt;
  x0 = makesym(atom__2A);
  unify_value(a1, x0);
  unify(a3, a2);
  proceed();
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_t_2:
  allocp[0] = makesym(functor_t_2);
  x1 = arg(a0, 0);
  allocp[1] = x1;
  allocp[2] = NILATOM;
  x0 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xmerge__depset_3);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = a2;
  allocp[4] = a3;
  a0 = arg(a0, 1);
  a1 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(get__loopds_2_0);
  goto get__loopds_2_ext_interrupt;
 case functor_tt_3:
  allocp[0] = makesym(functor_tt_3);
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x2 = arg(a0, 1);
  allocp[2] = x2;
  allocp[3] = NILATOM;
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_depset_xmerge__depset_3);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = a2;
  allocp[4] = a3;
  a0 = arg(a0, 2);
  a1 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(get__loopds_2_0);
  goto get__loopds_2_ext_interrupt;
  };
  goto remove__ds2_4_interrupt;
 case VARREF:
  deref_and_jump(a0,remove__ds2_4_6);
  *reasonp++ =  a0;
  goto remove__ds2_4_interrupt;
  };
  goto remove__ds2_4_interrupt;
 remove__ds2_4_ext_interrupt:
  reasonp = 0l;
 remove__ds2_4_interrupt:
  toppred = &predicate_typeset_xremove__ds2_4;
  goto interrupt_4;
 }

 remove__struct__ds_5_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 remove__struct__ds_5_clear_reason:
  reasonp = reasons;
 remove__struct__ds_5_0:
 remove__struct__ds_5_1:
  if (!isint(a0)) goto remove__struct__ds_5_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,remove__struct__ds_5_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xremove__struct__ds_5);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[9] = a0;
  allocp[10] = makeint(1L);
  allocp[11] = x1;
  allocp[12] = (q)(struct goalrec*)&allocp[7];
  allocp[13] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[14] = a0;
  allocp[15] = a1;
  allocp[16] = x4 = makeref(&allocp[16]);
  allocp[17] = x2;
  allocp[18] = (q)(struct goalrec*)&allocp[12];
  allocp[19] = (q)(&predicate_typeset_xremove__ds_4);
  allocp[20] = x5 = makeref(&allocp[20]);
  allocp[21] = x4;
  allocp[22] = a3;
  allocp[23] = x3;
  allocp[24] = (q)(struct goalrec*)&allocp[18];
  allocp[25] = (q)(&predicate_functor__table_xarg_3);
  allocp[26] = a0;
  allocp[27] = a1;
  allocp[28] = x5;
  qp = (struct goalrec*)&allocp[24];
  allocp += 29;
  proceed();
 remove__struct__ds_5_2:
  if (a0 != makeint(0L)) goto remove__struct__ds_5_interrupt;
  unify2(a2, a1, a4, a3);
  proceed();
 remove__struct__ds_5_3:
  if (!isref(a0)) goto remove__struct__ds_5_interrupt;
  deref_and_jump(a0,remove__struct__ds_5_1);
  *reasonp++ =  a0;
  goto remove__struct__ds_5_interrupt;
 remove__struct__ds_5_ext_interrupt:
  reasonp = 0l;
 remove__struct__ds_5_interrupt:
  goto interrupt_5;
 }

 get__loopds_2_top: {
  qp = qp->next;
 get__loopds_2_clear_reason:
  reasonp = reasons;
 get__loopds_2_0:
  a2 = a1;
  a1 = NILATOM;
  execute(get__loopds_3_0);
  goto get__loopds_3_ext_interrupt;
 get__loopds_2_ext_interrupt:
  reasonp = 0l;
 get__loopds_2_interrupt:
  toppred = &predicate_typeset_xget__loopds_2;
  goto interrupt_2;
 }

 get__loopds_3_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  qp = qp->next;
 get__loopds_3_clear_reason:
  reasonp = reasons;
 get__loopds_3_0:
 get__loopds_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 get__loopds_3_2:
  if (isref(x0)) goto get__loopds_3_6;
  gblt_pfunctor(x0,x1,get__loopds_3_interrupt);
  if (x1 != makesym(atom_goal)) goto get__loopds_3_4;
  gblt_arity(x0,x2,get__loopds_3_4);
 get__loopds_3_3:
  if (x2 != makeint(4L)) goto get__loopds_3_4;
  a0 = cdr_of(a0);
  execute(get__loopds_3_0);
  goto get__loopds_3_ext_interrupt;
 get__loopds_3_4:
  gblt_arity(x0,x3,get__loopds_3_interrupt);
 get__loopds_3_5:
  if (x3 != makeint(3L)) goto get__loopds_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xget__loopds_3);
  x4 = cdr_of(a0);
  allocp[2] = x4;
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_depset_xmerge__depset_3);
  allocp[7] = x6 = makeref(&allocp[7]);
  allocp[8] = a1;
  allocp[9] = x5;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_functor__table_xarg_3);
  allocp[12] = makeint(3L);
  allocp[13] = x0;
  allocp[14] = x6;
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  proceed();
 get__loopds_3_6:
  deref_and_jump(x0,get__loopds_3_2);
  *reasonp++ =  x0;
  goto get__loopds_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto get__loopds_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,get__loopds_3_1);
  *reasonp++ =  a0;
  goto get__loopds_3_interrupt;
  };
  goto get__loopds_3_interrupt;
 get__loopds_3_ext_interrupt:
  reasonp = 0l;
 get__loopds_3_interrupt:
  toppred = &predicate_typeset_xget__loopds_3;
  goto interrupt_3;
 }

 check__same__type_4_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 check__same__type_4_clear_reason:
  reasonp = reasons;
 check__same__type_4_0:
 check__same__type_4_1:
  if (isref(a0)) goto check__same__type_4_4;
 check__same__type_4_2:
  if (isref(a0)) goto check__same__type_4_3;
  if_not_equal(a0, a1, check__same__type_4_5);
  unify_value(a2, a0);
  x0 = makesym(atom_yes);
  unify_value(a3, x0);
  proceed();
 check__same__type_4_3:
  deref_and_jump(a0,check__same__type_4_2);
  *reasonp++ =  a0;
  goto check__same__type_4_5;
 check__same__type_4_4:
  deref_and_jump(a0,check__same__type_4_1);
  *reasonp++ =  a0;
  goto check__same__type_4_5;
 check__same__type_4_5:
  otherwise(check__same__type_4_interrupt);
 check__same__type_4_6:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto check__same__type_4_11;
  switch (symval(a0)) {
 case symval(makesym(atom_i)):
 check__same__type_4_7:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_i_1)) goto check__same__type_4_11;
  x0 = makesym(atom_i);
  unify_value(a2, x0);
  x1 = makesym(atom_yes);
  unify_value(a3, x1);
  proceed();
 case VARREF:
  deref_and_jump(a1,check__same__type_4_7);
  *reasonp++ =  a1;
  goto check__same__type_4_11;
  };
  goto check__same__type_4_11;
 case symval(makesym(atom_a)):
 check__same__type_4_8:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_a_1)) goto check__same__type_4_11;
  x0 = makesym(atom_a);
  unify_value(a2, x0);
  x1 = makesym(atom_yes);
  unify_value(a3, x1);
  proceed();
 case VARREF:
  deref_and_jump(a1,check__same__type_4_8);
  *reasonp++ =  a1;
  goto check__same__type_4_11;
  };
  goto check__same__type_4_11;
  };
  goto check__same__type_4_11;
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_i_1:
 check__same__type_4_9:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_i)) goto check__same__type_4_11;
  x0 = makesym(atom_i);
  unify_value(a2, x0);
  x1 = makesym(atom_yes);
  unify_value(a3, x1);
  proceed();
 case VARREF:
  deref_and_jump(a1,check__same__type_4_9);
  *reasonp++ =  a1;
  goto check__same__type_4_11;
  };
  goto check__same__type_4_11;
 case functor_a_1:
 check__same__type_4_10:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_a)) goto check__same__type_4_11;
  x0 = makesym(atom_a);
  unify_value(a2, x0);
  x1 = makesym(atom_yes);
  unify_value(a3, x1);
  proceed();
 case VARREF:
  deref_and_jump(a1,check__same__type_4_10);
  *reasonp++ =  a1;
  goto check__same__type_4_11;
  };
  goto check__same__type_4_11;
  };
  goto check__same__type_4_11;
 case VARREF:
  deref_and_jump(a0,check__same__type_4_6);
  *reasonp++ =  a0;
  goto check__same__type_4_11;
  };
  goto check__same__type_4_11;
 check__same__type_4_11:
  otherwise(check__same__type_4_interrupt);
  unify(a2, a0);
  x0 = makesym(atom_no);
  unify_value(a3, x0);
  proceed();
 check__same__type_4_ext_interrupt:
  reasonp = 0l;
 check__same__type_4_interrupt:
  goto interrupt_4;
 }

 get__ds_5_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 get__ds_5_clear_reason:
  reasonp = reasons;
 get__ds_5_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xget__ds1_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = NILATOM;
  allocp[4] = a3;
  a3 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(get_5_0);
  goto get_5_ext_interrupt;
 get__ds_5_ext_interrupt:
  reasonp = 0l;
 get__ds_5_interrupt:
  goto interrupt_5;
 }

 get__ds1_3_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  qp = qp->next;
 get__ds1_3_clear_reason:
  reasonp = reasons;
 get__ds1_3_0:
 get__ds1_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 get__ds1_3_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom__2A)) goto get__ds1_3_interrupt;
  a0 = cdr_of(a0);
  execute(get__ds1_3_0);
  goto get__ds1_3_ext_interrupt;
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_t_2:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xget__ds1_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_depset_xor__depset_3);
  allocp[7] = a1;
  x3 = arg(x0, 1);
  allocp[8] = x3;
  allocp[9] = x2;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case functor_tv_2:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xget__ds1_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_depset_xor__depset_3);
  allocp[7] = a1;
  x3 = arg(x0, 1);
  allocp[8] = x3;
  allocp[9] = x2;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case functor_tt_3:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xget__ds1_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_depset_xor__depset_3);
  allocp[7] = a1;
  x3 = arg(x0, 2);
  allocp[8] = x3;
  allocp[9] = x2;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
 case functor_te_4:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xget__ds1_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_depset_xor__depset_3);
  allocp[7] = a1;
  x3 = arg(x0, 3);
  allocp[8] = x3;
  allocp[9] = x2;
  qp = (struct goalrec*)&allocp[5];
  allocp += 10;
  proceed();
  };
  goto get__ds1_3_interrupt;
 case VARREF:
  deref_and_jump(x0,get__ds1_3_2);
  *reasonp++ =  x0;
  goto get__ds1_3_interrupt;
  };
  goto get__ds1_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto get__ds1_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,get__ds1_3_1);
  *reasonp++ =  a0;
  goto get__ds1_3_interrupt;
  };
  goto get__ds1_3_interrupt;
 get__ds1_3_ext_interrupt:
  reasonp = 0l;
 get__ds1_3_interrupt:
  goto interrupt_3;
 }

 var2v3_4_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 var2v3_4_clear_reason:
  reasonp = reasons;
 var2v3_4_0:
 var2v3_4_1:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_variable_3)) goto var2v3_4_2;
  allocp[0] = makesym(functor_v_3);
  allocp[1] = a0;
  allocp[2] = a1;
  x1 = arg(a2, 0);
  allocp[3] = x1;
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a3, x0);
  proceed();
 case VARREF:
  deref_and_jump(a2,var2v3_4_1);
  *reasonp++ =  a2;
  goto var2v3_4_2;
  };
  goto var2v3_4_2;
 var2v3_4_2:
  otherwise(var2v3_4_interrupt);
  unify(a3, a2);
  proceed();
 var2v3_4_ext_interrupt:
  reasonp = 0l;
 var2v3_4_interrupt:
  toppred = &predicate_typeset_xvar2v3_4;
  goto interrupt_4;
 }

 vars2vs3_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 vars2vs3_4_clear_reason:
  reasonp = reasons;
 vars2vs3_4_0:
 vars2vs3_4_1:
  switch (ptagof(a2)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xvars2vs3_4);
  allocp[2] = a0;
  allocp[3] = a1;
  x0 = cdr_of(a2);
  allocp[4] = x0;
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = x1;
  allocp[7] = x3 = makeref(&allocp[7]);
  x2 = makecons(&allocp[6]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  unify_value(a3, x2);
  a2 = car_of(a2);
  a3 = x3;
  execute(var2v3_4_0);
  goto var2v3_4_ext_interrupt;
 case ATOMIC:
  if (a2 != NILATOM) goto vars2vs3_4_interrupt;
  x0 = NILATOM;
  unify_value(a3, x0);
  proceed();
 case VARREF:
  deref_and_jump(a2,vars2vs3_4_1);
  *reasonp++ =  a2;
  goto vars2vs3_4_interrupt;
  };
  goto vars2vs3_4_interrupt;
 vars2vs3_4_ext_interrupt:
  reasonp = 0l;
 vars2vs3_4_interrupt:
  goto interrupt_4;
 }

 split__tt_3_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  qp = qp->next;
 split__tt_3_clear_reason:
  reasonp = reasons;
 split__tt_3_0:
 split__tt_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 split__tt_3_2:
  if (isref(x0)) goto split__tt_3_4;
  gblt_pfunctor(x0,x1,split__tt_3_5);
  if (x1 != makesym(atom_tt)) goto split__tt_3_5;
  gblt_arity(x0,x2,split__tt_3_5);
 split__tt_3_3:
  if (x2 != makeint(3L)) goto split__tt_3_5;
  allocp[0] = x4 = makeref(&allocp[0]);
  allocp[1] = x0;
  x3 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x3);
  a0 = cdr_of(a0);
  a1 = x4;
  execute(split__tt_3_0);
  goto split__tt_3_ext_interrupt;
 split__tt_3_4:
  deref_and_jump(x0,split__tt_3_2);
  *reasonp++ =  x0;
  goto split__tt_3_5;
 case VARREF:
  deref_and_jump(a0,split__tt_3_1);
  *reasonp++ =  a0;
  goto split__tt_3_5;
  };
  goto split__tt_3_5;
 split__tt_3_5:
  otherwise(split__tt_3_interrupt);
 split__tt_3_6:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  a0 = cdr_of(a0);
  a2 = x1;
  execute(split__tt_3_0);
  goto split__tt_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto split__tt_3_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  x1 = NILATOM;
  unify_value(a2, x1);
  proceed();
 case VARREF:
  deref_and_jump(a0,split__tt_3_6);
  *reasonp++ =  a0;
  goto split__tt_3_interrupt;
  };
  goto split__tt_3_interrupt;
 split__tt_3_ext_interrupt:
  reasonp = 0l;
 split__tt_3_interrupt:
  toppred = &predicate_typeset_xsplit__tt_3;
  goto interrupt_3;
 }

 make__expand__ts_4_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 make__expand__ts_4_clear_reason:
  reasonp = reasons;
 make__expand__ts_4_0:
 make__expand__ts_4_1:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xmake__expand__ts2_6);
  allocp[2] = x0 = makeref(&allocp[2]);
  x1 = car_of(a1);
  allocp[3] = x1;
  allocp[4] = a0;
  x2 = cdr_of(a1);
  allocp[5] = x2;
  allocp[6] = a2;
  allocp[7] = a3;
  a1 = x1;
  a2 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  execute(include__tt_3_0);
  goto include__tt_3_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto make__expand__ts_4_interrupt;
  x0 = NILATOM;
  unify_value(a3, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,make__expand__ts_4_1);
  *reasonp++ =  a1;
  goto make__expand__ts_4_interrupt;
  };
  goto make__expand__ts_4_interrupt;
 make__expand__ts_4_ext_interrupt:
  reasonp = 0l;
 make__expand__ts_4_interrupt:
  toppred = &predicate_typeset_xmake__expand__ts_4;
  goto interrupt_4;
 }

 make__expand__ts2_6_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 make__expand__ts2_6_clear_reason:
  reasonp = reasons;
 make__expand__ts2_6_0:
 make__expand__ts2_6_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto make__expand__ts2_6_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xmake__expand__ts3_6);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = NILATOM;
  allocp[9] = a1;
  x1 = makecons(&allocp[8]);
  a0 = a4;
  a1 = x1;
  a2 = x0;
  a3 = makesym(atom_expand);
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  execute(check__dg_4_0);
  goto check__dg_4_ext_interrupt;
 case symval(makesym(atom_no)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xmake__expand__ts_4);
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  allocp[5] = x0 = makeref(&allocp[5]);
  allocp[6] = x0;
  allocp[7] = x2 = makeref(&allocp[7]);
  x1 = makecons(&allocp[6]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  unify_value(a5, x1);
  allocp[0] = NILATOM;
  allocp[1] = a1;
  x3 = makecons(&allocp[0]);
  allocp[2] = NILATOM;
  allocp[3] = x2;
  x4 = makecons(&allocp[2]);
  a0 = x3;
  a1 = a4;
  a2 = x4;
  a3 = makesym(atom_expand);
  allocp += 4;
  execute(add__dgoal_4_0);
  goto add__dgoal_4_ext_interrupt;
  };
  goto make__expand__ts2_6_interrupt;
 case VARREF:
  deref_and_jump(a0,make__expand__ts2_6_1);
  *reasonp++ =  a0;
  goto make__expand__ts2_6_interrupt;
  };
  goto make__expand__ts2_6_interrupt;
 make__expand__ts2_6_ext_interrupt:
  reasonp = 0l;
 make__expand__ts2_6_interrupt:
  goto interrupt_6;
 }

 make__expand__ts3_6_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 make__expand__ts3_6_clear_reason:
  reasonp = reasons;
 make__expand__ts3_6_0:
 make__expand__ts3_6_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto make__expand__ts3_6_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  a0 = a2;
  a1 = a3;
  a2 = a4;
  a3 = a5;
  execute(make__expand__ts_4_0);
  goto make__expand__ts_4_ext_interrupt;
 case symval(makesym(atom_no)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_typeset_xmake__expand__ts_4);
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  allocp[5] = x0 = makeref(&allocp[5]);
  allocp[6] = x0;
  allocp[7] = x2 = makeref(&allocp[7]);
  x1 = makecons(&allocp[6]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  unify_value(a5, x1);
  allocp[0] = NILATOM;
  allocp[1] = a1;
  x3 = makecons(&allocp[0]);
  allocp[2] = NILATOM;
  allocp[3] = x2;
  x4 = makecons(&allocp[2]);
  a0 = x3;
  a1 = a4;
  a2 = x4;
  a3 = makesym(atom_expand);
  allocp += 4;
  execute(add__dgoal_4_0);
  goto add__dgoal_4_ext_interrupt;
  };
  goto make__expand__ts3_6_interrupt;
 case VARREF:
  deref_and_jump(a0,make__expand__ts3_6_1);
  *reasonp++ =  a0;
  goto make__expand__ts3_6_interrupt;
  };
  goto make__expand__ts3_6_interrupt;
 make__expand__ts3_6_ext_interrupt:
  reasonp = 0l;
 make__expand__ts3_6_interrupt:
  goto interrupt_6;
 }

 include__tt_3_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  qp = qp->next;
 include__tt_3_clear_reason:
  reasonp = reasons;
 include__tt_3_0:
 include__tt_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 include__tt_3_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_tt_3)) goto include__tt_3_12;
 include__tt_3_3:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_tt_3)) goto include__tt_3_12;
  x1 = arg(a1, 0);
 include__tt_3_4:
  if (isref(x1)) goto include__tt_3_11;
 include__tt_3_5:
  if (isref(x1)) goto include__tt_3_10;
  x2 = arg(x0, 0);
  if_not_equal(x1, x2, include__tt_3_12);
  x3 = arg(a1, 1);
 include__tt_3_6:
  if (isref(x3)) goto include__tt_3_9;
 include__tt_3_7:
  if (isref(x3)) goto include__tt_3_8;
  x4 = arg(x0, 1);
  if_not_equal(x3, x4, include__tt_3_12);
  x5 = makesym(atom_yes);
  unify_value(a2, x5);
  proceed();
 include__tt_3_8:
  deref_and_jump(x3,include__tt_3_7);
  *reasonp++ =  x3;
  goto include__tt_3_12;
 include__tt_3_9:
  deref_and_jump(x3,include__tt_3_6);
  *reasonp++ =  x3;
  goto include__tt_3_12;
 include__tt_3_10:
  deref_and_jump(x1,include__tt_3_5);
  *reasonp++ =  x1;
  goto include__tt_3_12;
 include__tt_3_11:
  deref_and_jump(x1,include__tt_3_4);
  *reasonp++ =  x1;
  goto include__tt_3_12;
 case VARREF:
  deref_and_jump(a1,include__tt_3_3);
  *reasonp++ =  a1;
  goto include__tt_3_12;
  };
  goto include__tt_3_12;
 case VARREF:
  deref_and_jump(x0,include__tt_3_2);
  *reasonp++ =  x0;
  goto include__tt_3_12;
  };
  goto include__tt_3_12;
 case VARREF:
  deref_and_jump(a0,include__tt_3_1);
  *reasonp++ =  a0;
  goto include__tt_3_12;
  };
  goto include__tt_3_12;
 include__tt_3_12:
  otherwise(include__tt_3_interrupt);
 include__tt_3_13:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(include__tt_3_0);
  goto include__tt_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto include__tt_3_interrupt;
  x0 = makesym(atom_no);
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,include__tt_3_13);
  *reasonp++ =  a0;
  goto include__tt_3_interrupt;
  };
  goto include__tt_3_interrupt;
 include__tt_3_ext_interrupt:
  reasonp = 0l;
 include__tt_3_interrupt:
  toppred = &predicate_typeset_xinclude__tt_3;
  goto interrupt_3;
 }
 interrupt_14:
  allocp[15] = a13;
 interrupt_13:
  allocp[14] = a12;
 interrupt_12:
  allocp[13] = a11;
 interrupt_11:
  allocp[12] = a10;
 interrupt_10:
  allocp[11] = a9;
 interrupt_9:
  allocp[10] = a8;
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_typeset);
}
