/* Compiled by KLIC compiler version 3.002 (Wed Sep 17 15:37:13 JST 1997) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_schedule();
Const struct predicate predicate_schedule_xmain_3 =
   { module_schedule, 0, 3 };
Const struct predicate predicate_schedule_xschedule__predicates_8 =
   { module_schedule, 1, 8 };
Const struct predicate predicate_schedule_xschedule__def__clauses_9 =
   { module_schedule, 2, 9 };
Const struct predicate predicate_schedule_xschedule__clause_9 =
   { module_schedule, 3, 9 };
Const struct predicate predicate_schedule_xapply__schedule__bodys_8 =
   { module_schedule, 4, 8 };
Const struct predicate predicate_schedule_xapply__schedule__body_13 =
   { module_schedule, 5, 13 };
Const struct predicate predicate_schedule_xschedule__bodys_5 =
   { module_schedule, 6, 5 };
Const struct predicate predicate_schedule_xmake__deps_7 =
   { module_schedule, 7, 7 };
Const struct predicate predicate_schedule_xmake__gk_4 =
   { module_schedule, 8, 4 };
Const struct predicate predicate_schedule_xmake__brother__deps_5 =
   { module_schedule, 9, 5 };
Const struct predicate predicate_schedule_xmake__order_2 =
   { module_schedule, 10, 2 };
Const struct predicate predicate_schedule_xappend__nodegoal_3 =
   { module_schedule, 11, 3 };
Const struct predicate predicate_schedule_xmake__order_3 =
   { module_schedule, 12, 3 };
Const struct predicate predicate_schedule_xentry__depsets_3 =
   { module_schedule, 13, 3 };
Const struct predicate predicate_schedule_xentry__depsets_4 =
   { module_schedule, 14, 4 };
Const struct predicate predicate_schedule_xentry__depset_4 =
   { module_schedule, 15, 4 };
Const struct predicate predicate_schedule_xentry__depset_6 =
   { module_schedule, 16, 6 };
Const struct predicate predicate_schedule_xinsert__entry_5 =
   { module_schedule, 17, 5 };
Const struct predicate predicate_schedule_xinsert__entry_8 =
   { module_schedule, 18, 8 };
Const struct predicate predicate_schedule_xget__pos__dep__from__entry_3 =
   { module_schedule, 19, 3 };
Const struct predicate predicate_schedule_xget__pos__dep__from__entry_4 =
   { module_schedule, 20, 4 };
Const struct predicate predicate_schedule_xget__pos__dep_5 =
   { module_schedule, 21, 5 };
Const struct predicate predicate_schedule_xget__pos__dep__to__entry_3 =
   { module_schedule, 22, 3 };
Const struct predicate predicate_schedule_xget__pos__dep__to__entry_4 =
   { module_schedule, 23, 4 };
Const struct predicate predicate_schedule_xget__pos__dep__to__entry_5 =
   { module_schedule, 24, 5 };
Const struct predicate predicate_schedule_xget__depset__pos_3 =
   { module_schedule, 25, 3 };
Const struct predicate predicate_schedule_xget__depset__pos_4 =
   { module_schedule, 26, 4 };
Const struct predicate predicate_schedule_xdepsets2numsets_2 =
   { module_schedule, 27, 2 };
Const struct predicate predicate_schedule_xdepset2numset_2 =
   { module_schedule, 28, 2 };
Const struct predicate predicate_schedule_xsplit__goals_4 =
   { module_schedule, 29, 4 };
Const struct predicate predicate_schedule_xsort__numset__size_2 =
   { module_schedule, 30, 2 };
Const struct predicate predicate_schedule_xsort__numset__size_5 =
   { module_schedule, 31, 5 };
Const struct predicate predicate_schedule_xsort__numset__size_7 =
   { module_schedule, 32, 7 };
Const struct predicate predicate_schedule_xchange__order_3 =
   { module_schedule, 33, 3 };
Const struct predicate predicate_schedule_xchange__order_6 =
   { module_schedule, 34, 6 };
Const struct predicate predicate_schedule_xchange__order_7 =
   { module_schedule, 35, 7 };
Const struct predicate predicate_schedule_xadd__thread_4 =
   { module_schedule, 36, 4 };
extern Const struct predicate predicate_list_xor__unique_3;
extern Const struct predicate predicate_list_xappend_3;
extern Const struct predicate predicate_list_xsplit__nth_4;
extern Const struct predicate predicate_list_xinsert__nth__element_4;
extern Const struct predicate predicate_list_xcheck__include_3;
extern Const struct predicate predicate_list_xcount__element_2;
extern Const struct predicate predicate_integer__arithmetics_xadd_3;
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_functor__table_xsetarg_4;
extern Const struct predicate predicate_functor__table_xfunctor_3;
extern Const struct predicate predicate_parse__uty_xget__first__clause__info_4;
extern Const struct predicate predicate_parse__uty_xget__def__clauses_5;
extern Const struct predicate predicate_parse__uty_xupdate__def__clauses_4;
extern Const struct predicate predicate_parse__uty_xdecode__goalcall_6;
extern Const struct predicate predicate_parse__uty_xdecode__goal_4;
extern Const struct predicate predicate_parse__uty_xencode__goal_4;
extern Const struct predicate predicate_dt_xget_4;
extern Const struct predicate predicate_dt_xget__deps_4;
extern Const struct predicate predicate_dt_xentry_5;

module module_schedule(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  static Const q cons_const_0[] = {
    NILATOM,
    NILATOM,
  };
  static Const q cons_const_1[] = {
    NILATOM,
    makeint(1),
  };
  static Const q cons_const_2[] = {
    NILATOM,
    makecons(cons_const_1),
  };
  static Const q funct_const_3[] = {
    makesym(functor_atom_1),
    makesym(atom_thread),
  };
  q a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, main_3_top);
    case_pred(1, schedule__predicates_8_top);
    case_pred(2, schedule__def__clauses_9_top);
    case_pred(3, schedule__clause_9_top);
    case_pred(4, apply__schedule__bodys_8_top);
    case_pred(5, apply__schedule__body_13_top);
    case_pred(6, schedule__bodys_5_top);
    case_pred(7, make__deps_7_top);
    case_pred(8, make__gk_4_top);
    case_pred(9, make__brother__deps_5_top);
    case_pred(10, make__order_2_top);
    case_pred(11, append__nodegoal_3_top);
    case_pred(12, make__order_3_top);
    case_pred(13, entry__depsets_3_top);
    case_pred(14, entry__depsets_4_top);
    case_pred(15, entry__depset_4_top);
    case_pred(16, entry__depset_6_top);
    case_pred(17, insert__entry_5_top);
    case_pred(18, insert__entry_8_top);
    case_pred(19, get__pos__dep__from__entry_3_top);
    case_pred(20, get__pos__dep__from__entry_4_top);
    case_pred(21, get__pos__dep_5_top);
    case_pred(22, get__pos__dep__to__entry_3_top);
    case_pred(23, get__pos__dep__to__entry_4_top);
    case_pred(24, get__pos__dep__to__entry_5_top);
    case_pred(25, get__depset__pos_3_top);
    case_pred(26, get__depset__pos_4_top);
    case_pred(27, depsets2numsets_2_top);
    case_pred(28, depset2numset_2_top);
    case_pred(29, split__goals_4_top);
    case_pred(30, sort__numset__size_2_top);
    case_pred(31, sort__numset__size_5_top);
    case_pred(32, sort__numset__size_7_top);
    case_pred(33, change__order_3_top);
    case_pred(34, change__order_6_top);
    case_pred(35, change__order_7_top);
    last_case_pred(36, add__thread_4_top);
  }

 main_3_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  qp = qp->next;
 main_3_clear_reason:
  reasonp = reasons;
 main_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_schedule_xschedule__predicates_8);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = a0;
  allocp[7] = a1;
  allocp[8] = a2;
  allocp[9] = x4 = makeref(&allocp[9]);
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_parse__uty_xget__first__clause__info_4);
  allocp[12] = x0;
  allocp[13] = x1;
  allocp[14] = x2;
  allocp[15] = a0;
  qp = (struct goalrec*)&allocp[10];
  allocp += 16;
  proceed();
 main_3_ext_interrupt:
  reasonp = 0l;
 main_3_interrupt:
  goto interrupt_3;
 }

 schedule__predicates_8_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 schedule__predicates_8_clear_reason:
  reasonp = reasons;
 schedule__predicates_8_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_parse__uty_xupdate__def__clauses_4);
  allocp[2] = a0;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a5;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_schedule_xschedule__def__clauses_9);
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = x0;
  allocp[10] = a0;
  allocp[11] = NILATOM;
  allocp[12] = a3;
  allocp[13] = a4;
  allocp[14] = x1;
  allocp[15] = a6;
  allocp[16] = a7;
  allocp[17] = (q)(struct goalrec*)&allocp[6];
  allocp[18] = (q)(&predicate_parse__uty_xget__def__clauses_5);
  allocp[19] = a0;
  allocp[20] = a1;
  allocp[21] = a2;
  allocp[22] = x2;
  allocp[23] = a4;
  qp = (struct goalrec*)&allocp[17];
  allocp += 24;
  proceed();
 schedule__predicates_8_ext_interrupt:
  reasonp = 0l;
 schedule__predicates_8_interrupt:
  toppred = &predicate_schedule_xschedule__predicates_8;
  goto interrupt_8;
 }

 schedule__def__clauses_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 schedule__def__clauses_9_clear_reason:
  reasonp = reasons;
 schedule__def__clauses_9_0:
 schedule__def__clauses_9_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 schedule__def__clauses_9_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_cl_2)) goto schedule__def__clauses_9_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_schedule_xschedule__def__clauses_9);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x4 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = x5 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_list_xor__unique_3);
  allocp[13] = a3;
  allocp[14] = x6 = makeref(&allocp[14]);
  allocp[15] = x3;
  allocp[16] = makesym(functor_cl_2);
  x8 = arg(x0, 0);
  allocp[17] = x8;
  allocp[18] = x9 = makeref(&allocp[18]);
  x7 = makefunctor(&allocp[16]);
  allocp[19] = x2;
  allocp[20] = x7;
  x10 = makecons(&allocp[19]);
  qp = (struct goalrec*)&allocp[11];
  allocp += 21;
  unify_value(a1, x10);
  a0 = arg(x0, 1);
  a1 = x9;
  a3 = arg(x0, 0);
  a4 = x6;
  a6 = x4;
  a8 = x5;
  execute(schedule__clause_9_0);
  goto schedule__clause_9_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,schedule__def__clauses_9_2);
  *reasonp++ =  x0;
  goto schedule__def__clauses_9_interrupt;
  };
  goto schedule__def__clauses_9_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto schedule__def__clauses_9_interrupt;
  unify2(a8, a7, a6, a5);
  x0 = NILATOM;
  unify_value(a1, x0);
  unify(a4, a3);
  proceed();
 case VARREF:
  deref_and_jump(a0,schedule__def__clauses_9_1);
  *reasonp++ =  a0;
  goto schedule__def__clauses_9_interrupt;
  };
  goto schedule__def__clauses_9_interrupt;
 schedule__def__clauses_9_ext_interrupt:
  reasonp = 0l;
 schedule__def__clauses_9_interrupt:
  goto interrupt_9;
 }

 schedule__clause_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 schedule__clause_9_clear_reason:
  reasonp = reasons;
 schedule__clause_9_0:
 schedule__clause_9_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_clause_4)) goto schedule__clause_9_4;
  x0 = arg(a0, 0);
 schedule__clause_9_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_functor_2)) goto schedule__clause_9_4;
  x1 = arg(x0, 1);
 schedule__clause_9_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (isint(x1)) goto schedule__clause_9_4;
  switch (symval(x1)) {
 case symval(makesym(atom_userdef)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dt_xget_4);
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  allocp[5] = a8;
  allocp[6] = makesym(functor_functor_2);
  x3 = arg(x0, 0);
  allocp[7] = x3;
  allocp[8] = makesym(atom_done);
  x2 = makefunctor(&allocp[6]);
  allocp[9] = makesym(functor_clause_4);
  allocp[10] = x2;
  x5 = arg(a0, 1);
  allocp[11] = x5;
  allocp[12] = x6 = makeref(&allocp[12]);
  x7 = arg(a0, 3);
  allocp[13] = x7;
  x4 = makefunctor(&allocp[9]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 14;
  unify_value(a1, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_schedule_xschedule__bodys_5);
  x8 = arg(a0, 2);
  allocp[2] = x8;
  allocp[3] = x6;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a8;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_schedule_xapply__schedule__bodys_8);
  allocp[9] = x9 = makeref(&allocp[9]);
  allocp[10] = x8;
  allocp[11] = a2;
  allocp[12] = a3;
  allocp[13] = a5;
  allocp[14] = a6;
  allocp[15] = a7;
  allocp[16] = a8;
  allocp[17] = (q)(struct goalrec*)&allocp[7];
  allocp[18] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[19] = x8;
  allocp[20] = x10 = makeref(&allocp[20]);
  allocp[21] = x9;
  qp = (struct goalrec*)&allocp[17];
  allocp += 22;
  proceed();
 case symval(makesym(atom_done)):
  unify2(a8, a7, a6, a5);
  unify_value(a1, a0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_dt_xget_4);
  allocp[2] = a2;
  allocp[3] = a3;
  allocp[4] = a4;
  allocp[5] = a7;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  proceed();
  };
  goto schedule__clause_9_4;
 case VARREF:
  deref_and_jump(x1,schedule__clause_9_3);
  *reasonp++ =  x1;
  goto schedule__clause_9_4;
  };
  goto schedule__clause_9_4;
 case VARREF:
  deref_and_jump(x0,schedule__clause_9_2);
  *reasonp++ =  x0;
  goto schedule__clause_9_4;
  };
  goto schedule__clause_9_4;
 case VARREF:
  deref_and_jump(a0,schedule__clause_9_1);
  *reasonp++ =  a0;
  goto schedule__clause_9_4;
  };
  goto schedule__clause_9_4;
 schedule__clause_9_4:
  otherwise(schedule__clause_9_interrupt);
  unify3(a8, a7, a6, a5, a1, a0);
  proceed();
 schedule__clause_9_ext_interrupt:
  reasonp = 0l;
 schedule__clause_9_interrupt:
  toppred = &predicate_schedule_xschedule__clause_9;
  goto interrupt_9;
 }

 apply__schedule__bodys_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 apply__schedule__bodys_8_clear_reason:
  reasonp = reasons;
 apply__schedule__bodys_8_0:
 apply__schedule__bodys_8_1:
  if (!isint(a0)) goto apply__schedule__bodys_8_3;
  x0 = makeint(0L);
  gblt_greater(a0,x0,apply__schedule__bodys_8_2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_schedule_xapply__schedule__bodys_8);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[12] = a0;
  allocp[13] = makeint(1L);
  allocp[14] = x1;
  allocp[15] = (q)(struct goalrec*)&allocp[10];
  allocp[16] = (q)(&predicate_schedule_xapply__schedule__body_13);
  allocp[17] = x4 = makeref(&allocp[17]);
  allocp[18] = x5 = makeref(&allocp[18]);
  allocp[19] = x6 = makeref(&allocp[19]);
  allocp[20] = x7 = makeref(&allocp[20]);
  allocp[21] = x8 = makeref(&allocp[21]);
  allocp[22] = x9 = makeref(&allocp[22]);
  allocp[23] = a2;
  allocp[24] = a3;
  allocp[25] = a0;
  allocp[26] = a4;
  allocp[27] = x2;
  allocp[28] = a6;
  allocp[29] = x3;
  allocp[30] = (q)(struct goalrec*)&allocp[15];
  allocp[31] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[32] = x7;
  allocp[33] = x5;
  allocp[34] = x6;
  allocp[35] = (q)(struct goalrec*)&allocp[30];
  allocp[36] = (q)(&predicate_parse__uty_xdecode__goalcall_6);
  allocp[37] = a2;
  allocp[38] = x4;
  allocp[39] = x10 = makeref(&allocp[39]);
  allocp[40] = x7;
  allocp[41] = x9;
  allocp[42] = x8;
  allocp[43] = (q)(struct goalrec*)&allocp[35];
  allocp[44] = (q)(&predicate_functor__table_xarg_3);
  allocp[45] = a0;
  allocp[46] = a1;
  allocp[47] = x10;
  qp = (struct goalrec*)&allocp[43];
  allocp += 48;
  proceed();
 apply__schedule__bodys_8_2:
  if (a0 != makeint(0L)) goto apply__schedule__bodys_8_interrupt;
  unify2(a7, a6, a5, a4);
  proceed();
 apply__schedule__bodys_8_3:
  if (!isref(a0)) goto apply__schedule__bodys_8_interrupt;
  deref_and_jump(a0,apply__schedule__bodys_8_1);
  *reasonp++ =  a0;
  goto apply__schedule__bodys_8_interrupt;
 apply__schedule__bodys_8_ext_interrupt:
  reasonp = 0l;
 apply__schedule__bodys_8_interrupt:
  goto interrupt_8;
 }

 apply__schedule__body_13_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  qp = qp->next;
 apply__schedule__body_13_clear_reason:
  reasonp = reasons;
 apply__schedule__body_13_0:
 apply__schedule__body_13_1:
  switch (ptagof(a4)) {
 case ATOMIC:
  if (a4 != makesym(atom_userdef)) goto apply__schedule__body_13_5;
 apply__schedule__body_13_2:
  switch (ptagof(a5)) {
 case FUNCTOR:
  switch (symval(functor_of(a5))) {
 case functor_atom_1:
  x0 = arg(a5, 0);
 apply__schedule__body_13_3:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (isint(x0)) goto apply__schedule__body_13_5;
  switch (symval(x0)) {
 case symval(makesym(atom_recursive)):
  unify(a10, a9);
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a6;
  allocp[2] = a7;
  allocp[3] = makesym(atom_body);
  allocp[4] = a8;
  x1 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry_5);
  allocp[7] = makesym(atom_data);
  allocp[8] = x1;
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a11;
  allocp[11] = a12;
  allocp[12] = makesym(functor_goal_4);
  allocp[13] = a6;
  allocp[14] = a7;
  allocp[15] = makesym(atom_body);
  allocp[16] = a8;
  x3 = makefunctor(&allocp[12]);
  allocp[17] = (q)(struct goalrec*)&allocp[5];
  allocp[18] = (q)(&predicate_dt_xget__deps_4);
  allocp[19] = makesym(atom_data);
  allocp[20] = x3;
  allocp[21] = x2;
  allocp[22] = a11;
  qp = (struct goalrec*)&allocp[17];
  allocp += 23;
  proceed();
 case symval(makesym(atom_shared)):
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a6;
  allocp[2] = a7;
  allocp[3] = makesym(atom_body);
  allocp[4] = a8;
  x1 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry_5);
  allocp[7] = makesym(atom_data);
  allocp[8] = x1;
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = x3 = makeref(&allocp[10]);
  allocp[11] = a12;
  a3 = x2;
  a4 = a9;
  a5 = a10;
  a6 = a11;
  a7 = x3;
  qp = (struct goalrec*)&allocp[5];
  allocp += 12;
  execute(schedule__predicates_8_0);
  goto schedule__predicates_8_ext_interrupt;
  };
  goto apply__schedule__body_13_5;
 case VARREF:
  deref_and_jump(x0,apply__schedule__body_13_3);
  *reasonp++ =  x0;
  goto apply__schedule__body_13_5;
  };
  goto apply__schedule__body_13_5;
 case functor_functor_1:
  x0 = arg(a5, 0);
 apply__schedule__body_13_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_node_1)) goto apply__schedule__body_13_5;
  allocp[0] = x1 = makeref(&allocp[0]);
  a3 = x1;
  a4 = a9;
  a5 = a10;
  a6 = a11;
  a7 = a12;
  allocp += 1;
  execute(schedule__predicates_8_0);
  goto schedule__predicates_8_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,apply__schedule__body_13_4);
  *reasonp++ =  x0;
  goto apply__schedule__body_13_5;
  };
  goto apply__schedule__body_13_5;
  };
  goto apply__schedule__body_13_5;
 case VARREF:
  deref_and_jump(a5,apply__schedule__body_13_2);
  *reasonp++ =  a5;
  goto apply__schedule__body_13_5;
  };
  goto apply__schedule__body_13_5;
 case VARREF:
  deref_and_jump(a4,apply__schedule__body_13_1);
  *reasonp++ =  a4;
  goto apply__schedule__body_13_5;
  };
  goto apply__schedule__body_13_5;
 apply__schedule__body_13_5:
  otherwise(apply__schedule__body_13_interrupt);
 apply__schedule__body_13_6:
  switch (ptagof(a4)) {
 case ATOMIC:
  if (isint(a4)) goto apply__schedule__body_13_interrupt;
  switch (symval(a4)) {
 case symval(makesym(atom_userdef)):
  allocp[0] = makesym(functor_goal_4);
  allocp[1] = a6;
  allocp[2] = a7;
  allocp[3] = makesym(atom_body);
  allocp[4] = a8;
  x0 = makefunctor(&allocp[0]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_dt_xentry_5);
  allocp[7] = makesym(atom_data);
  allocp[8] = x0;
  allocp[9] = x1 = makeref(&allocp[9]);
  allocp[10] = x2 = makeref(&allocp[10]);
  allocp[11] = a12;
  a3 = x1;
  a4 = a9;
  a5 = a10;
  a6 = a11;
  a7 = x2;
  qp = (struct goalrec*)&allocp[5];
  allocp += 12;
  execute(schedule__predicates_8_0);
  goto schedule__predicates_8_ext_interrupt;
 case symval(makesym(atom_builtin)):
  unify2(a12, a11, a10, a9);
  proceed();
  };
  goto apply__schedule__body_13_interrupt;
 case VARREF:
  deref_and_jump(a4,apply__schedule__body_13_6);
  *reasonp++ =  a4;
  goto apply__schedule__body_13_interrupt;
  };
  goto apply__schedule__body_13_interrupt;
 apply__schedule__body_13_ext_interrupt:
  reasonp = 0l;
 apply__schedule__body_13_interrupt:
  goto interrupt_13;
 }

 schedule__bodys_5_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 schedule__bodys_5_clear_reason:
  reasonp = reasons;
 schedule__bodys_5_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_schedule_xchange__order_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_schedule_xmake__order_2);
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = x0;
  allocp[9] = (q)(struct goalrec*)&allocp[5];
  allocp[10] = (q)(&predicate_schedule_xmake__deps_7);
  allocp[11] = makeint(1L);
  allocp[12] = x2 = makeref(&allocp[12]);
  allocp[13] = a0;
  allocp[14] = a2;
  allocp[15] = a3;
  allocp[16] = x1;
  allocp[17] = a4;
  allocp[18] = (q)(struct goalrec*)&allocp[9];
  allocp[19] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[20] = a0;
  allocp[21] = x3 = makeref(&allocp[21]);
  allocp[22] = x2;
  qp = (struct goalrec*)&allocp[18];
  allocp += 23;
  proceed();
 schedule__bodys_5_ext_interrupt:
  reasonp = 0l;
 schedule__bodys_5_interrupt:
  goto interrupt_5;
 }

 make__deps_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 make__deps_7_clear_reason:
  reasonp = reasons;
 make__deps_7_0:
 make__deps_7_1:
  if (!isint(a0)) goto make__deps_7_5;
 make__deps_7_2:
  if (!isint(a1)) goto make__deps_7_4;
  gblt_less_or_eq(a0,a1,make__deps_7_3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_schedule_xmake__deps_7);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[11] = a0;
  allocp[12] = makeint(1L);
  allocp[13] = x0;
  allocp[14] = makesym(functor_dep_3);
  allocp[15] = a0;
  allocp[16] = x3 = makeref(&allocp[16]);
  allocp[17] = x4 = makeref(&allocp[17]);
  x2 = makefunctor(&allocp[14]);
  allocp[18] = x1;
  allocp[19] = x2;
  x5 = makecons(&allocp[18]);
  qp = (struct goalrec*)&allocp[9];
  allocp += 20;
  unify_value(a5, x5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_schedule_xmake__gk_4);
  allocp[2] = x6 = makeref(&allocp[2]);
  allocp[3] = x7 = makeref(&allocp[3]);
  allocp[4] = x8 = makeref(&allocp[4]);
  allocp[5] = x3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_functor__table_xfunctor_3);
  allocp[8] = x9 = makeref(&allocp[8]);
  allocp[9] = x6;
  allocp[10] = x10 = makeref(&allocp[10]);
  allocp[11] = (q)(struct goalrec*)&allocp[6];
  allocp[12] = (q)(&predicate_schedule_xmake__brother__deps_5);
  allocp[13] = a3;
  allocp[14] = a4;
  allocp[15] = a0;
  allocp[16] = x11 = makeref(&allocp[16]);
  allocp[17] = x4;
  allocp[18] = makesym(functor_goal_4);
  allocp[19] = a3;
  allocp[20] = a4;
  allocp[21] = makesym(atom_body);
  allocp[22] = a0;
  x12 = makefunctor(&allocp[18]);
  allocp[23] = (q)(struct goalrec*)&allocp[11];
  allocp[24] = (q)(&predicate_dt_xget__deps_4);
  allocp[25] = makesym(atom_data);
  allocp[26] = x12;
  allocp[27] = x11;
  allocp[28] = a6;
  allocp[29] = (q)(struct goalrec*)&allocp[23];
  allocp[30] = (q)(&predicate_parse__uty_xdecode__goalcall_6);
  allocp[31] = a3;
  allocp[32] = x13 = makeref(&allocp[32]);
  allocp[33] = x14 = makeref(&allocp[33]);
  allocp[34] = x9;
  allocp[35] = x7;
  allocp[36] = x8;
  allocp[37] = (q)(struct goalrec*)&allocp[29];
  allocp[38] = (q)(&predicate_functor__table_xarg_3);
  allocp[39] = a0;
  allocp[40] = a2;
  allocp[41] = x14;
  qp = (struct goalrec*)&allocp[37];
  allocp += 42;
  proceed();
 make__deps_7_3:
  gblt_greater(a0,a1,make__deps_7_interrupt);
  x0 = NILATOM;
  unify_value(a5, x0);
  proceed();
 make__deps_7_4:
  if (!isref(a1)) goto make__deps_7_interrupt;
  deref_and_jump(a1,make__deps_7_2);
  *reasonp++ =  a1;
  goto make__deps_7_interrupt;
 make__deps_7_5:
  if (!isref(a0)) goto make__deps_7_interrupt;
  deref_and_jump(a0,make__deps_7_1);
  *reasonp++ =  a0;
  goto make__deps_7_interrupt;
 make__deps_7_ext_interrupt:
  reasonp = 0l;
 make__deps_7_interrupt:
  goto interrupt_7;
 }

 make__gk_4_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 make__gk_4_clear_reason:
  reasonp = reasons;
 make__gk_4_0:
 make__gk_4_1:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_functor_1)) goto make__gk_4_3;
  x0 = arg(a1, 0);
 make__gk_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_node_1)) goto make__gk_4_3;
  x1 = makesym(atom_node);
  unify_value(a3, x1);
  proceed();
 case VARREF:
  deref_and_jump(x0,make__gk_4_2);
  *reasonp++ =  x0;
  goto make__gk_4_3;
  };
  goto make__gk_4_3;
 case VARREF:
  deref_and_jump(a1,make__gk_4_1);
  *reasonp++ =  a1;
  goto make__gk_4_3;
  };
  goto make__gk_4_3;
 make__gk_4_3:
 make__gk_4_4:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto make__gk_4_7;
  switch (symval(a0)) {
 case symval(makesym(atom_start__measure)):
 make__gk_4_5:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_builtin)) goto make__gk_4_7;
  x0 = makesym(atom_userdef);
  unify_value(a3, x0);
  proceed();
 case VARREF:
  deref_and_jump(a2,make__gk_4_5);
  *reasonp++ =  a2;
  goto make__gk_4_7;
  };
  goto make__gk_4_7;
 case symval(makesym(atom_report__measure)):
 make__gk_4_6:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_builtin)) goto make__gk_4_7;
  x0 = makesym(atom_userdef);
  unify_value(a3, x0);
  proceed();
 case VARREF:
  deref_and_jump(a2,make__gk_4_6);
  *reasonp++ =  a2;
  goto make__gk_4_7;
  };
  goto make__gk_4_7;
  };
  goto make__gk_4_7;
 case VARREF:
  deref_and_jump(a0,make__gk_4_4);
  *reasonp++ =  a0;
  goto make__gk_4_7;
  };
  goto make__gk_4_7;
 make__gk_4_7:
  otherwise(make__gk_4_interrupt);
  unify(a3, a2);
  proceed();
 make__gk_4_ext_interrupt:
  reasonp = 0l;
 make__gk_4_interrupt:
  goto interrupt_4;
 }

 make__brother__deps_5_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 make__brother__deps_5_clear_reason:
  reasonp = reasons;
 make__brother__deps_5_0:
 make__brother__deps_5_1:
  switch (ptagof(a3)) {
 case CONS:
  x0 = car_of(a3);
 make__brother__deps_5_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_goal_4)) goto make__brother__deps_5_16;
  x1 = arg(x0, 0);
 make__brother__deps_5_3:
  if (isref(x1)) goto make__brother__deps_5_15;
 make__brother__deps_5_4:
  if (isref(x1)) goto make__brother__deps_5_14;
  if_not_equal(x1, a0, make__brother__deps_5_16);
  x2 = arg(x0, 1);
 make__brother__deps_5_5:
  if (isref(x2)) goto make__brother__deps_5_13;
 make__brother__deps_5_6:
  if (isref(x2)) goto make__brother__deps_5_12;
  if_not_equal(x2, a1, make__brother__deps_5_16);
  x3 = arg(x0, 2);
 make__brother__deps_5_7:
  switch (ptagof(x3)) {
 case ATOMIC:
  if (x3 != makesym(atom_body)) goto make__brother__deps_5_16;
  x4 = arg(x0, 3);
 make__brother__deps_5_8:
  if (isref(x4)) goto make__brother__deps_5_11;
 make__brother__deps_5_9:
  if (isref(x4)) goto make__brother__deps_5_10;
  if_not_equal(x4, a2, make__brother__deps_5_16);
  a3 = cdr_of(a3);
  execute(make__brother__deps_5_clear_reason);
  goto make__brother__deps_5_ext_interrupt;
 make__brother__deps_5_10:
  deref_and_jump(x4,make__brother__deps_5_9);
  *reasonp++ =  x4;
  goto make__brother__deps_5_16;
 make__brother__deps_5_11:
  deref_and_jump(x4,make__brother__deps_5_8);
  *reasonp++ =  x4;
  goto make__brother__deps_5_16;
 case VARREF:
  deref_and_jump(x3,make__brother__deps_5_7);
  *reasonp++ =  x3;
  goto make__brother__deps_5_16;
  };
  goto make__brother__deps_5_16;
 make__brother__deps_5_12:
  deref_and_jump(x2,make__brother__deps_5_6);
  *reasonp++ =  x2;
  goto make__brother__deps_5_16;
 make__brother__deps_5_13:
  deref_and_jump(x2,make__brother__deps_5_5);
  *reasonp++ =  x2;
  goto make__brother__deps_5_16;
 make__brother__deps_5_14:
  deref_and_jump(x1,make__brother__deps_5_4);
  *reasonp++ =  x1;
  goto make__brother__deps_5_16;
 make__brother__deps_5_15:
  deref_and_jump(x1,make__brother__deps_5_3);
  *reasonp++ =  x1;
  goto make__brother__deps_5_16;
 case VARREF:
  deref_and_jump(x0,make__brother__deps_5_2);
  *reasonp++ =  x0;
  goto make__brother__deps_5_16;
  };
  goto make__brother__deps_5_16;
 case VARREF:
  deref_and_jump(a3,make__brother__deps_5_1);
  *reasonp++ =  a3;
  goto make__brother__deps_5_16;
  };
  goto make__brother__deps_5_16;
 make__brother__deps_5_16:
  otherwise(make__brother__deps_5_interrupt);
 make__brother__deps_5_17:
  switch (ptagof(a3)) {
 case CONS:
  x0 = car_of(a3);
 make__brother__deps_5_18:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_goal_4)) goto make__brother__deps_5_28;
  x1 = arg(x0, 0);
 make__brother__deps_5_19:
  if (isref(x1)) goto make__brother__deps_5_27;
 make__brother__deps_5_20:
  if (isref(x1)) goto make__brother__deps_5_26;
  if_not_equal(x1, a0, make__brother__deps_5_28);
  x2 = arg(x0, 1);
 make__brother__deps_5_21:
  if (isref(x2)) goto make__brother__deps_5_25;
 make__brother__deps_5_22:
  if (isref(x2)) goto make__brother__deps_5_24;
  if_not_equal(x2, a1, make__brother__deps_5_28);
  x3 = arg(x0, 2);
 make__brother__deps_5_23:
  switch (ptagof(x3)) {
 case ATOMIC:
  if (x3 != makesym(atom_body)) goto make__brother__deps_5_28;
  allocp[0] = x5 = makeref(&allocp[0]);
  x6 = arg(x0, 3);
  allocp[1] = x6;
  x4 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a4, x4);
  a3 = cdr_of(a3);
  a4 = x5;
  execute(make__brother__deps_5_clear_reason);
  goto make__brother__deps_5_ext_interrupt;
 case VARREF:
  deref_and_jump(x3,make__brother__deps_5_23);
  *reasonp++ =  x3;
  goto make__brother__deps_5_28;
  };
  goto make__brother__deps_5_28;
 make__brother__deps_5_24:
  deref_and_jump(x2,make__brother__deps_5_22);
  *reasonp++ =  x2;
  goto make__brother__deps_5_28;
 make__brother__deps_5_25:
  deref_and_jump(x2,make__brother__deps_5_21);
  *reasonp++ =  x2;
  goto make__brother__deps_5_28;
 make__brother__deps_5_26:
  deref_and_jump(x1,make__brother__deps_5_20);
  *reasonp++ =  x1;
  goto make__brother__deps_5_28;
 make__brother__deps_5_27:
  deref_and_jump(x1,make__brother__deps_5_19);
  *reasonp++ =  x1;
  goto make__brother__deps_5_28;
 case VARREF:
  deref_and_jump(x0,make__brother__deps_5_18);
  *reasonp++ =  x0;
  goto make__brother__deps_5_28;
  };
  goto make__brother__deps_5_28;
 case VARREF:
  deref_and_jump(a3,make__brother__deps_5_17);
  *reasonp++ =  a3;
  goto make__brother__deps_5_28;
  };
  goto make__brother__deps_5_28;
 make__brother__deps_5_28:
  otherwise(make__brother__deps_5_interrupt);
 make__brother__deps_5_29:
  switch (ptagof(a3)) {
 case CONS:
  a3 = cdr_of(a3);
  execute(make__brother__deps_5_0);
  goto make__brother__deps_5_ext_interrupt;
 case ATOMIC:
  if (a3 != NILATOM) goto make__brother__deps_5_interrupt;
  x0 = NILATOM;
  unify_value(a4, x0);
  proceed();
 case VARREF:
  deref_and_jump(a3,make__brother__deps_5_29);
  *reasonp++ =  a3;
  goto make__brother__deps_5_interrupt;
  };
  goto make__brother__deps_5_interrupt;
 make__brother__deps_5_ext_interrupt:
  reasonp = 0l;
 make__brother__deps_5_interrupt:
  goto interrupt_5;
 }

 make__order_2_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  qp = qp->next;
 make__order_2_clear_reason:
  reasonp = reasons;
 make__order_2_0:
 make__order_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = cdr_of(a0);
 make__order_2_2:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != NILATOM) goto make__order_2_3;
  x1 = makecons(cons_const_2);
  unify_value(a1, x1);
  proceed();
 case VARREF:
  deref_and_jump(x0,make__order_2_2);
  *reasonp++ =  x0;
  goto make__order_2_3;
  };
  goto make__order_2_3;
 case ATOMIC:
  if (a0 != NILATOM) goto make__order_2_3;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,make__order_2_1);
  *reasonp++ =  a0;
  goto make__order_2_3;
  };
  goto make__order_2_3;
 make__order_2_3:
  otherwise(make__order_2_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_schedule_xsort__numset__size_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_schedule_xdepsets2numsets_2);
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = x0;
  allocp[8] = (q)(struct goalrec*)&allocp[4];
  allocp[9] = (q)(&predicate_schedule_xappend__nodegoal_3);
  allocp[10] = x2 = makeref(&allocp[10]);
  allocp[11] = x3 = makeref(&allocp[11]);
  allocp[12] = x1;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_schedule_xmake__order_3);
  allocp[15] = x4 = makeref(&allocp[15]);
  allocp[16] = x5 = makeref(&allocp[16]);
  allocp[17] = x2;
  allocp[18] = (q)(struct goalrec*)&allocp[13];
  allocp[19] = (q)(&predicate_schedule_xmake__order_3);
  allocp[20] = x6 = makeref(&allocp[20]);
  allocp[21] = makecons(cons_const_0);
  allocp[22] = x5;
  a1 = x4;
  a2 = x6;
  a3 = x3;
  qp = (struct goalrec*)&allocp[18];
  allocp += 23;
  execute(split__goals_4_0);
  goto split__goals_4_ext_interrupt;
 make__order_2_ext_interrupt:
  reasonp = 0l;
 make__order_2_interrupt:
  goto interrupt_2;
 }

 append__nodegoal_3_top: {
  q x0;
  a2 = qp->args[2];
  qp = qp->next;
 append__nodegoal_3_clear_reason:
  reasonp = reasons;
 append__nodegoal_3_0:
 append__nodegoal_3_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != NILATOM) goto append__nodegoal_3_2;
  unify(a2, a0);
  proceed();
 case VARREF:
  deref_and_jump(a1,append__nodegoal_3_1);
  *reasonp++ =  a1;
  goto append__nodegoal_3_2;
  };
  goto append__nodegoal_3_2;
 append__nodegoal_3_2:
  otherwise(append__nodegoal_3_interrupt);
  allocp[0] = NILATOM;
  allocp[1] = a1;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_list_xappend_3);
  allocp[4] = a0;
  allocp[5] = x0;
  allocp[6] = a2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 7;
  proceed();
 append__nodegoal_3_ext_interrupt:
  reasonp = 0l;
 append__nodegoal_3_interrupt:
  goto interrupt_3;
 }

 make__order_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 make__order_3_clear_reason:
  reasonp = reasons;
 make__order_3_0:
 make__order_3_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_schedule_xmake__order_3);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  a0 = car_of(a0);
  a2 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(entry__depsets_3_0);
  goto entry__depsets_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto make__order_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,make__order_3_1);
  *reasonp++ =  a0;
  goto make__order_3_interrupt;
  };
  goto make__order_3_interrupt;
 make__order_3_ext_interrupt:
  reasonp = 0l;
 make__order_3_interrupt:
  goto interrupt_3;
 }

 entry__depsets_3_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  qp = qp->next;
 entry__depsets_3_clear_reason:
  reasonp = reasons;
 entry__depsets_3_0:
 entry__depsets_3_1:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_schedule_xentry__depsets_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  x1 = cdr_of(a1);
  allocp[4] = x1;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = x2;
  allocp[7] = x4 = makeref(&allocp[7]);
  x3 = makecons(&allocp[6]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  unify_value(a2, x3);
  a1 = car_of(a1);
  a2 = x4;
  a3 = x0;
  execute(entry__depset_4_0);
  goto entry__depset_4_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto entry__depsets_3_interrupt;
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  allocp[2] = NILATOM;
  allocp[3] = x0;
  x1 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a2, x1);
  proceed();
 case VARREF:
  deref_and_jump(a1,entry__depsets_3_1);
  *reasonp++ =  a1;
  goto entry__depsets_3_interrupt;
  };
  goto entry__depsets_3_interrupt;
 entry__depsets_3_ext_interrupt:
  reasonp = 0l;
 entry__depsets_3_interrupt:
  toppred = &predicate_schedule_xentry__depsets_3;
  goto interrupt_3;
 }

 entry__depsets_4_top: {
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 entry__depsets_4_clear_reason:
  reasonp = reasons;
 entry__depsets_4_0:
 entry__depsets_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto entry__depsets_4_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  unify(a3, a2);
  proceed();
 case symval(makesym(atom_no)):
  a0 = a1;
  a1 = a2;
  a2 = a3;
  execute(entry__depsets_3_0);
  goto entry__depsets_3_ext_interrupt;
  };
  goto entry__depsets_4_interrupt;
 case VARREF:
  deref_and_jump(a0,entry__depsets_4_1);
  *reasonp++ =  a0;
  goto entry__depsets_4_interrupt;
  };
  goto entry__depsets_4_interrupt;
 entry__depsets_4_ext_interrupt:
  reasonp = 0l;
 entry__depsets_4_interrupt:
  goto interrupt_4;
 }

 entry__depset_4_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 entry__depset_4_clear_reason:
  reasonp = reasons;
 entry__depset_4_0:
 entry__depset_4_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_dep_3)) goto entry__depset_4_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_schedule_xentry__depset_6);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a0;
  allocp[5] = a1;
  allocp[6] = a2;
  allocp[7] = a3;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_schedule_xget__pos__dep__to__entry_3);
  x2 = arg(a0, 0);
  allocp[10] = x2;
  allocp[11] = a1;
  allocp[12] = x1;
  a0 = arg(a0, 2);
  a2 = x0;
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  execute(get__pos__dep__from__entry_3_0);
  goto get__pos__dep__from__entry_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,entry__depset_4_1);
  *reasonp++ =  a0;
  goto entry__depset_4_interrupt;
  };
  goto entry__depset_4_interrupt;
 entry__depset_4_ext_interrupt:
  reasonp = 0l;
 entry__depset_4_interrupt:
  toppred = &predicate_schedule_xentry__depset_4;
  goto interrupt_4;
 }

 entry__depset_6_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 entry__depset_6_clear_reason:
  reasonp = reasons;
 entry__depset_6_0:
 entry__depset_6_1:
  if (!isint(a0)) goto entry__depset_6_5;
 entry__depset_6_2:
  if (!isint(a1)) goto entry__depset_6_4;
  gblt_greater_or_eq(a0,a1,entry__depset_6_3);
  x0 = makesym(atom_no);
  unify_value(a5, x0);
  unify(a4, a3);
  proceed();
 entry__depset_6_3:
  gblt_less(a0,a1,entry__depset_6_interrupt);
  x0 = makesym(atom_yes);
  unify_value(a5, x0);
  x1 = makeint(1L);
  bblt_add_no_check(a0,x1,x2);
  a0 = x2;
  execute(insert__entry_5_0);
  goto insert__entry_5_ext_interrupt;
 entry__depset_6_4:
  if (!isref(a1)) goto entry__depset_6_interrupt;
  deref_and_jump(a1,entry__depset_6_2);
  *reasonp++ =  a1;
  goto entry__depset_6_interrupt;
 entry__depset_6_5:
  if (!isref(a0)) goto entry__depset_6_interrupt;
  deref_and_jump(a0,entry__depset_6_1);
  *reasonp++ =  a0;
  goto entry__depset_6_interrupt;
 entry__depset_6_ext_interrupt:
  reasonp = 0l;
 entry__depset_6_interrupt:
  goto interrupt_6;
 }

 insert__entry_5_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 insert__entry_5_clear_reason:
  reasonp = reasons;
 insert__entry_5_0:
 insert__entry_5_1:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != NILATOM) goto insert__entry_5_2;
  allocp[0] = NILATOM;
  allocp[1] = a2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a4, x0);
  proceed();
 case VARREF:
  deref_and_jump(a3,insert__entry_5_1);
  *reasonp++ =  a3;
  goto insert__entry_5_2;
  };
  goto insert__entry_5_2;
 insert__entry_5_2:
  otherwise(insert__entry_5_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_schedule_xinsert__entry_8);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x0 = makeref(&allocp[5]);
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = a3;
  allocp[9] = a4;
  allocp[10] = makesym(functor_dep_3);
  allocp[11] = x0;
  allocp[12] = x1;
  allocp[13] = x4 = makeref(&allocp[13]);
  x3 = makefunctor(&allocp[10]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 14;
  unify_value(a2, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_list_xsplit__nth_4);
  allocp[2] = a0;
  allocp[3] = a3;
  allocp[4] = x5 = makeref(&allocp[4]);
  allocp[5] = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  proceed();
 insert__entry_5_ext_interrupt:
  reasonp = 0l;
 insert__entry_5_interrupt:
  toppred = &predicate_schedule_xinsert__entry_5;
  goto interrupt_5;
 }

 insert__entry_8_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 insert__entry_8_clear_reason:
  reasonp = reasons;
 insert__entry_8_0:
 insert__entry_8_1:
  if (isref(a0)) goto insert__entry_8_4;
 insert__entry_8_2:
  if (isref(a0)) goto insert__entry_8_3;
  if_not_equal(a0, a1, insert__entry_8_5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_list_xinsert__nth__element_4);
  allocp[2] = a0;
  allocp[3] = a2;
  allocp[4] = a6;
  allocp[5] = a7;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  proceed();
 insert__entry_8_3:
  deref_and_jump(a0,insert__entry_8_2);
  *reasonp++ =  a0;
  goto insert__entry_8_5;
 insert__entry_8_4:
  deref_and_jump(a0,insert__entry_8_1);
  *reasonp++ =  a0;
  goto insert__entry_8_5;
 insert__entry_8_5:
 insert__entry_8_6:
  switch (ptagof(a5)) {
 case CONS:
 insert__entry_8_7:
  if (!isint(a0)) goto insert__entry_8_13;
 insert__entry_8_8:
  if (!isint(a1)) goto insert__entry_8_12;
  gblt_less(a0,a1,insert__entry_8_14);
  x0 = car_of(a5);
 insert__entry_8_9:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_dep_3)) goto insert__entry_8_14;
 insert__entry_8_10:
  switch (ptagof(a4)) {
 case ATOMIC:
  if (a4 != makesym(atom_builtin)) goto insert__entry_8_14;
  x1 = arg(x0, 1);
 insert__entry_8_11:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_userdef)) goto insert__entry_8_14;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_list_xinsert__nth__element_4);
  allocp[2] = a0;
  allocp[3] = a2;
  allocp[4] = a6;
  allocp[5] = a7;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  proceed();
 case VARREF:
  deref_and_jump(x1,insert__entry_8_11);
  *reasonp++ =  x1;
  goto insert__entry_8_14;
  };
  goto insert__entry_8_14;
 case VARREF:
  deref_and_jump(a4,insert__entry_8_10);
  *reasonp++ =  a4;
  goto insert__entry_8_14;
  };
  goto insert__entry_8_14;
 case VARREF:
  deref_and_jump(x0,insert__entry_8_9);
  *reasonp++ =  x0;
  goto insert__entry_8_14;
  };
  goto insert__entry_8_14;
 insert__entry_8_12:
  if (!isref(a1)) goto insert__entry_8_14;
  deref_and_jump(a1,insert__entry_8_8);
  *reasonp++ =  a1;
  goto insert__entry_8_14;
 insert__entry_8_13:
  if (!isref(a0)) goto insert__entry_8_14;
  deref_and_jump(a0,insert__entry_8_7);
  *reasonp++ =  a0;
  goto insert__entry_8_14;
 case VARREF:
  deref_and_jump(a5,insert__entry_8_6);
  *reasonp++ =  a5;
  goto insert__entry_8_14;
  };
  goto insert__entry_8_14;
 insert__entry_8_14:
  otherwise(insert__entry_8_interrupt);
 insert__entry_8_15:
  switch (ptagof(a5)) {
 case CONS:
 insert__entry_8_16:
  if (!isint(a0)) goto insert__entry_8_24;
 insert__entry_8_17:
  if (!isint(a1)) goto insert__entry_8_23;
  gblt_less(a0,a1,insert__entry_8_25);
  x0 = car_of(a5);
 insert__entry_8_18:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_dep_3)) goto insert__entry_8_25;
 insert__entry_8_19:
  if (!isint(a3)) goto insert__entry_8_22;
  x1 = arg(x0, 0);
 insert__entry_8_20:
  if (!isint(x1)) goto insert__entry_8_21;
  gblt_less(a3,x1,insert__entry_8_25);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_list_xinsert__nth__element_4);
  allocp[2] = a0;
  allocp[3] = a2;
  allocp[4] = a6;
  allocp[5] = a7;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  proceed();
 insert__entry_8_21:
  if (!isref(x1)) goto insert__entry_8_25;
  deref_and_jump(x1,insert__entry_8_20);
  *reasonp++ =  x1;
  goto insert__entry_8_25;
 insert__entry_8_22:
  if (!isref(a3)) goto insert__entry_8_25;
  deref_and_jump(a3,insert__entry_8_19);
  *reasonp++ =  a3;
  goto insert__entry_8_25;
 case VARREF:
  deref_and_jump(x0,insert__entry_8_18);
  *reasonp++ =  x0;
  goto insert__entry_8_25;
  };
  goto insert__entry_8_25;
 insert__entry_8_23:
  if (!isref(a1)) goto insert__entry_8_25;
  deref_and_jump(a1,insert__entry_8_17);
  *reasonp++ =  a1;
  goto insert__entry_8_25;
 insert__entry_8_24:
  if (!isref(a0)) goto insert__entry_8_25;
  deref_and_jump(a0,insert__entry_8_16);
  *reasonp++ =  a0;
  goto insert__entry_8_25;
 case VARREF:
  deref_and_jump(a5,insert__entry_8_15);
  *reasonp++ =  a5;
  goto insert__entry_8_25;
  };
  goto insert__entry_8_25;
 insert__entry_8_25:
  otherwise(insert__entry_8_interrupt);
 insert__entry_8_26:
  switch (ptagof(a5)) {
 case CONS:
  x0 = makeint(1L);
  bblt_add_no_check_y(a0,x0,x1);
  a0 = x1;
  a5 = cdr_of(a5);
  execute(insert__entry_8_0);
  goto insert__entry_8_ext_interrupt;
 case VARREF:
  deref_and_jump(a5,insert__entry_8_26);
  *reasonp++ =  a5;
  goto insert__entry_8_interrupt;
  };
  goto insert__entry_8_interrupt;
 insert__entry_8_ext_interrupt:
  reasonp = 0l;
 insert__entry_8_interrupt:
  goto interrupt_8;
 }

 get__pos__dep__from__entry_3_top: {
  a2 = qp->args[2];
  qp = qp->next;
 get__pos__dep__from__entry_3_clear_reason:
  reasonp = reasons;
 get__pos__dep__from__entry_3_0:
  a3 = a2;
  a2 = makeint(0L);
  execute(get__pos__dep__from__entry_4_0);
  goto get__pos__dep__from__entry_4_ext_interrupt;
 get__pos__dep__from__entry_3_ext_interrupt:
  reasonp = 0l;
 get__pos__dep__from__entry_3_interrupt:
  toppred = &predicate_schedule_xget__pos__dep__from__entry_3;
  goto interrupt_3;
 }

 get__pos__dep__from__entry_4_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 get__pos__dep__from__entry_4_clear_reason:
  reasonp = reasons;
 get__pos__dep__from__entry_4_0:
 get__pos__dep__from__entry_4_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_schedule_xget__pos__dep_5);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = a1;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a2;
  allocp[6] = a3;
  a0 = car_of(a0);
  a2 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(get__depset__pos_3_0);
  goto get__depset__pos_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto get__pos__dep__from__entry_4_interrupt;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,get__pos__dep__from__entry_4_1);
  *reasonp++ =  a0;
  goto get__pos__dep__from__entry_4_interrupt;
  };
  goto get__pos__dep__from__entry_4_interrupt;
 get__pos__dep__from__entry_4_ext_interrupt:
  reasonp = 0l;
 get__pos__dep__from__entry_4_interrupt:
  toppred = &predicate_schedule_xget__pos__dep__from__entry_4;
  goto interrupt_4;
 }

 get__pos__dep_5_top: {
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 get__pos__dep_5_clear_reason:
  reasonp = reasons;
 get__pos__dep_5_0:
 get__pos__dep_5_1:
  if (!isint(a2)) goto get__pos__dep_5_5;
 get__pos__dep_5_2:
  if (!isint(a3)) goto get__pos__dep_5_4;
  gblt_greater(a2,a3,get__pos__dep_5_3);
  a3 = a4;
  execute(get__pos__dep__from__entry_4_0);
  goto get__pos__dep__from__entry_4_ext_interrupt;
 get__pos__dep_5_3:
  gblt_less_or_eq(a2,a3,get__pos__dep_5_interrupt);
  a2 = a3;
  a3 = a4;
  execute(get__pos__dep__from__entry_4_0);
  goto get__pos__dep__from__entry_4_ext_interrupt;
 get__pos__dep_5_4:
  if (!isref(a3)) goto get__pos__dep_5_interrupt;
  deref_and_jump(a3,get__pos__dep_5_2);
  *reasonp++ =  a3;
  goto get__pos__dep_5_interrupt;
 get__pos__dep_5_5:
  if (!isref(a2)) goto get__pos__dep_5_interrupt;
  deref_and_jump(a2,get__pos__dep_5_1);
  *reasonp++ =  a2;
  goto get__pos__dep_5_interrupt;
 get__pos__dep_5_ext_interrupt:
  reasonp = 0l;
 get__pos__dep_5_interrupt:
  goto interrupt_5;
 }

 get__pos__dep__to__entry_3_top: {
  a2 = qp->args[2];
  qp = qp->next;
 get__pos__dep__to__entry_3_clear_reason:
  reasonp = reasons;
 get__pos__dep__to__entry_3_0:
  a3 = a2;
  a2 = makeint(1L);
  execute(get__pos__dep__to__entry_4_0);
  goto get__pos__dep__to__entry_4_ext_interrupt;
 get__pos__dep__to__entry_3_ext_interrupt:
  reasonp = 0l;
 get__pos__dep__to__entry_3_interrupt:
  goto interrupt_3;
 }

 get__pos__dep__to__entry_4_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 get__pos__dep__to__entry_4_clear_reason:
  reasonp = reasons;
 get__pos__dep__to__entry_4_0:
 get__pos__dep__to__entry_4_1:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = makesym(functor_dep_3);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  x0 = makefunctor(&allocp[0]);
  x4 = car_of(a1);
  allocp += 4;
  unify_value(x4, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_schedule_xget__pos__dep__to__entry_5);
  allocp[2] = x5 = makeref(&allocp[2]);
  allocp[3] = a0;
  x6 = cdr_of(a1);
  allocp[4] = x6;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_list_xcheck__include_3);
  allocp[9] = a0;
  allocp[10] = x3;
  allocp[11] = x5;
  qp = (struct goalrec*)&allocp[7];
  allocp += 12;
  proceed();
 case ATOMIC:
  if (a1 != NILATOM) goto get__pos__dep__to__entry_4_interrupt;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a1,get__pos__dep__to__entry_4_1);
  *reasonp++ =  a1;
  goto get__pos__dep__to__entry_4_interrupt;
  };
  goto get__pos__dep__to__entry_4_interrupt;
 get__pos__dep__to__entry_4_ext_interrupt:
  reasonp = 0l;
 get__pos__dep__to__entry_4_interrupt:
  toppred = &predicate_schedule_xget__pos__dep__to__entry_4;
  goto interrupt_4;
 }

 get__pos__dep__to__entry_5_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 get__pos__dep__to__entry_5_clear_reason:
  reasonp = reasons;
 get__pos__dep__to__entry_5_0:
 get__pos__dep__to__entry_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto get__pos__dep__to__entry_5_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  unify(a4, a3);
  proceed();
 case symval(makesym(atom_no)):
  x0 = makeint(1L);
  bblt_add_no_check_y(a3,x0,x1);
  a0 = a1;
  a1 = a2;
  a2 = x1;
  a3 = a4;
  execute(get__pos__dep__to__entry_4_0);
  goto get__pos__dep__to__entry_4_ext_interrupt;
  };
  goto get__pos__dep__to__entry_5_interrupt;
 case VARREF:
  deref_and_jump(a0,get__pos__dep__to__entry_5_1);
  *reasonp++ =  a0;
  goto get__pos__dep__to__entry_5_interrupt;
  };
  goto get__pos__dep__to__entry_5_interrupt;
 get__pos__dep__to__entry_5_ext_interrupt:
  reasonp = 0l;
 get__pos__dep__to__entry_5_interrupt:
  goto interrupt_5;
 }

 get__depset__pos_3_top: {
  a2 = qp->args[2];
  qp = qp->next;
 get__depset__pos_3_clear_reason:
  reasonp = reasons;
 get__depset__pos_3_0:
  a3 = a2;
  a2 = makeint(1L);
  execute(get__depset__pos_4_0);
  goto get__depset__pos_4_ext_interrupt;
 get__depset__pos_3_ext_interrupt:
  reasonp = 0l;
 get__depset__pos_3_interrupt:
  toppred = &predicate_schedule_xget__depset__pos_3;
  goto interrupt_3;
 }

 get__depset__pos_4_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 get__depset__pos_4_clear_reason:
  reasonp = reasons;
 get__depset__pos_4_0:
 get__depset__pos_4_1:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 get__depset__pos_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_dep_3)) goto get__depset__pos_4_7;
  x1 = arg(x0, 0);
 get__depset__pos_4_3:
  if (isref(x1)) goto get__depset__pos_4_6;
 get__depset__pos_4_4:
  if (isref(x1)) goto get__depset__pos_4_5;
  if_not_equal(x1, a0, get__depset__pos_4_7);
  unify(a3, a2);
  proceed();
 get__depset__pos_4_5:
  deref_and_jump(x1,get__depset__pos_4_4);
  *reasonp++ =  x1;
  goto get__depset__pos_4_7;
 get__depset__pos_4_6:
  deref_and_jump(x1,get__depset__pos_4_3);
  *reasonp++ =  x1;
  goto get__depset__pos_4_7;
 case VARREF:
  deref_and_jump(x0,get__depset__pos_4_2);
  *reasonp++ =  x0;
  goto get__depset__pos_4_7;
  };
  goto get__depset__pos_4_7;
 case VARREF:
  deref_and_jump(a1,get__depset__pos_4_1);
  *reasonp++ =  a1;
  goto get__depset__pos_4_7;
  };
  goto get__depset__pos_4_7;
 get__depset__pos_4_7:
  otherwise(get__depset__pos_4_interrupt);
 get__depset__pos_4_8:
  switch (ptagof(a1)) {
 case CONS:
  x0 = makeint(1L);
  bblt_add_no_check_y(a2,x0,x1);
  a1 = cdr_of(a1);
  a2 = x1;
  execute(get__depset__pos_4_0);
  goto get__depset__pos_4_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto get__depset__pos_4_interrupt;
  x0 = makeint(0L);
  unify_value(a3, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,get__depset__pos_4_8);
  *reasonp++ =  a1;
  goto get__depset__pos_4_interrupt;
  };
  goto get__depset__pos_4_interrupt;
 get__depset__pos_4_ext_interrupt:
  reasonp = 0l;
 get__depset__pos_4_interrupt:
  toppred = &predicate_schedule_xget__depset__pos_4;
  goto interrupt_4;
 }

 depsets2numsets_2_top: {
  q x0, x1, x2, x3;
  qp = qp->next;
 depsets2numsets_2_clear_reason:
  reasonp = reasons;
 depsets2numsets_2_0:
 depsets2numsets_2_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_schedule_xdepsets2numsets_2);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x1;
  allocp[5] = x3 = makeref(&allocp[5]);
  x2 = makecons(&allocp[4]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  unify_value(a1, x2);
  a0 = car_of(a0);
  a1 = x3;
  execute(depset2numset_2_0);
  goto depset2numset_2_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto depsets2numsets_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,depsets2numsets_2_1);
  *reasonp++ =  a0;
  goto depsets2numsets_2_interrupt;
  };
  goto depsets2numsets_2_interrupt;
 depsets2numsets_2_ext_interrupt:
  reasonp = 0l;
 depsets2numsets_2_interrupt:
  goto interrupt_2;
 }

 depset2numset_2_top: {
  q x0, x1, x2, x3;
  qp = qp->next;
 depset2numset_2_clear_reason:
  reasonp = reasons;
 depset2numset_2_0:
 depset2numset_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 depset2numset_2_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_dep_3)) goto depset2numset_2_interrupt;
  allocp[0] = x2 = makeref(&allocp[0]);
  x3 = arg(x0, 0);
  allocp[1] = x3;
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x1);
  a0 = cdr_of(a0);
  a1 = x2;
  execute(depset2numset_2_0);
  goto depset2numset_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,depset2numset_2_2);
  *reasonp++ =  x0;
  goto depset2numset_2_interrupt;
  };
  goto depset2numset_2_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto depset2numset_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,depset2numset_2_1);
  *reasonp++ =  a0;
  goto depset2numset_2_interrupt;
  };
  goto depset2numset_2_interrupt;
 depset2numset_2_ext_interrupt:
  reasonp = 0l;
 depset2numset_2_interrupt:
  toppred = &predicate_schedule_xdepset2numset_2;
  goto interrupt_2;
 }

 split__goals_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 split__goals_4_clear_reason:
  reasonp = reasons;
 split__goals_4_0:
 split__goals_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 split__goals_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_dep_3)) goto split__goals_4_4;
  x1 = arg(x0, 1);
 split__goals_4_3:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (isint(x1)) goto split__goals_4_4;
  switch (symval(x1)) {
 case symval(makesym(atom_builtin)):
  allocp[0] = x3 = makeref(&allocp[0]);
  allocp[1] = x0;
  x2 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x2);
  a0 = cdr_of(a0);
  a1 = x3;
  execute(split__goals_4_0);
  goto split__goals_4_ext_interrupt;
 case symval(makesym(atom_userdef)):
  allocp[0] = x3 = makeref(&allocp[0]);
  allocp[1] = x0;
  x2 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x2);
  a0 = cdr_of(a0);
  a2 = x3;
  execute(split__goals_4_0);
  goto split__goals_4_ext_interrupt;
 case symval(makesym(atom_node)):
  allocp[0] = x3 = makeref(&allocp[0]);
  allocp[1] = x0;
  x2 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a3, x2);
  a0 = cdr_of(a0);
  a3 = x3;
  execute(split__goals_4_0);
  goto split__goals_4_ext_interrupt;
  };
  goto split__goals_4_4;
 case VARREF:
  deref_and_jump(x1,split__goals_4_3);
  *reasonp++ =  x1;
  goto split__goals_4_4;
  };
  goto split__goals_4_4;
 case VARREF:
  deref_and_jump(x0,split__goals_4_2);
  *reasonp++ =  x0;
  goto split__goals_4_4;
  };
  goto split__goals_4_4;
 case VARREF:
  deref_and_jump(a0,split__goals_4_1);
  *reasonp++ =  a0;
  goto split__goals_4_4;
  };
  goto split__goals_4_4;
 split__goals_4_4:
  otherwise(split__goals_4_interrupt);
 split__goals_4_5:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 split__goals_4_6:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_dep_3)) goto split__goals_4_interrupt;
  x1 = arg(x0, 1);
 split__goals_4_7:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_node)) goto split__goals_4_interrupt;
  a0 = cdr_of(a0);
  execute(split__goals_4_0);
  goto split__goals_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,split__goals_4_7);
  *reasonp++ =  x1;
  goto split__goals_4_interrupt;
  };
  goto split__goals_4_interrupt;
 case VARREF:
  deref_and_jump(x0,split__goals_4_6);
  *reasonp++ =  x0;
  goto split__goals_4_interrupt;
  };
  goto split__goals_4_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto split__goals_4_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  x1 = NILATOM;
  unify_value(a2, x1);
  x2 = NILATOM;
  unify_value(a3, x2);
  proceed();
 case VARREF:
  deref_and_jump(a0,split__goals_4_5);
  *reasonp++ =  a0;
  goto split__goals_4_interrupt;
  };
  goto split__goals_4_interrupt;
 split__goals_4_ext_interrupt:
  reasonp = 0l;
 split__goals_4_interrupt:
  toppred = &predicate_schedule_xsplit__goals_4;
  goto interrupt_4;
 }

 sort__numset__size_2_top: {
  q x0, x1, x2, x3, x4, x5;
  qp = qp->next;
 sort__numset__size_2_clear_reason:
  reasonp = reasons;
 sort__numset__size_2_0:
 sort__numset__size_2_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = x2 = makeref(&allocp[1]);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_schedule_xsort__numset__size_5);
  allocp[2] = x3 = makeref(&allocp[2]);
  x4 = car_of(a0);
  allocp[3] = x4;
  x5 = cdr_of(a0);
  allocp[4] = x5;
  allocp[5] = x2;
  allocp[6] = x1;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_list_xcount__element_2);
  allocp[9] = x4;
  allocp[10] = x3;
  qp = (struct goalrec*)&allocp[7];
  allocp += 11;
  proceed();
 case ATOMIC:
  if (a0 != NILATOM) goto sort__numset__size_2_interrupt;
  x0 = NILATOM;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,sort__numset__size_2_1);
  *reasonp++ =  a0;
  goto sort__numset__size_2_interrupt;
  };
  goto sort__numset__size_2_interrupt;
 sort__numset__size_2_ext_interrupt:
  reasonp = 0l;
 sort__numset__size_2_interrupt:
  goto interrupt_2;
 }

 sort__numset__size_5_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 sort__numset__size_5_clear_reason:
  reasonp = reasons;
 sort__numset__size_5_0:
 sort__numset__size_5_1:
  switch (ptagof(a2)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_schedule_xsort__numset__size_7);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  x1 = car_of(a2);
  allocp[4] = x1;
  allocp[5] = a1;
  x2 = cdr_of(a2);
  allocp[6] = x2;
  allocp[7] = a3;
  allocp[8] = a4;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_list_xcount__element_2);
  allocp[11] = x1;
  allocp[12] = x0;
  qp = (struct goalrec*)&allocp[9];
  allocp += 13;
  proceed();
 case ATOMIC:
  if (a2 != NILATOM) goto sort__numset__size_5_interrupt;
  unify(a3, a1);
  x0 = NILATOM;
  unify_value(a4, x0);
  proceed();
 case VARREF:
  deref_and_jump(a2,sort__numset__size_5_1);
  *reasonp++ =  a2;
  goto sort__numset__size_5_interrupt;
  };
  goto sort__numset__size_5_interrupt;
 sort__numset__size_5_ext_interrupt:
  reasonp = 0l;
 sort__numset__size_5_interrupt:
  toppred = &predicate_schedule_xsort__numset__size_5;
  goto interrupt_5;
 }

 sort__numset__size_7_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 sort__numset__size_7_clear_reason:
  reasonp = reasons;
 sort__numset__size_7_0:
 sort__numset__size_7_1:
  if (!isint(a0)) goto sort__numset__size_7_5;
 sort__numset__size_7_2:
  if (!isint(a1)) goto sort__numset__size_7_4;
  gblt_greater(a0,a1,sort__numset__size_7_3);
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = a3;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a6, x0);
  a1 = a2;
  a2 = a4;
  a3 = a5;
  a4 = x1;
  execute(sort__numset__size_5_0);
  goto sort__numset__size_5_ext_interrupt;
 sort__numset__size_7_3:
  gblt_less_or_eq(a0,a1,sort__numset__size_7_interrupt);
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = a2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a6, x0);
  a0 = a1;
  a1 = a3;
  a2 = a4;
  a3 = a5;
  a4 = x1;
  execute(sort__numset__size_5_0);
  goto sort__numset__size_5_ext_interrupt;
 sort__numset__size_7_4:
  if (!isref(a1)) goto sort__numset__size_7_interrupt;
  deref_and_jump(a1,sort__numset__size_7_2);
  *reasonp++ =  a1;
  goto sort__numset__size_7_interrupt;
 sort__numset__size_7_5:
  if (!isref(a0)) goto sort__numset__size_7_interrupt;
  deref_and_jump(a0,sort__numset__size_7_1);
  *reasonp++ =  a0;
  goto sort__numset__size_7_interrupt;
 sort__numset__size_7_ext_interrupt:
  reasonp = 0l;
 sort__numset__size_7_interrupt:
  goto interrupt_7;
 }

 change__order_3_top: {
  a2 = qp->args[2];
  qp = qp->next;
 change__order_3_clear_reason:
  reasonp = reasons;
 change__order_3_0:
  a3 = a1;
  a4 = a1;
  a5 = a2;
  a2 = makeint(1L);
  a1 = makesym(atom_not__thread);
  execute(change__order_6_0);
  goto change__order_6_ext_interrupt;
 change__order_3_ext_interrupt:
  reasonp = 0l;
 change__order_3_interrupt:
  goto interrupt_3;
 }

 change__order_6_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 change__order_6_clear_reason:
  reasonp = reasons;
 change__order_6_0:
 change__order_6_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_schedule_xchange__order_6);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = makesym(atom_thread);
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  a0 = car_of(a0);
  x3 = a3;
  a5 = a4;
  a6 = x2;
  a4 = x3;
  a3 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  execute(change__order_7_0);
  goto change__order_7_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto change__order_6_interrupt;
  unify(a5, a4);
  proceed();
 case VARREF:
  deref_and_jump(a0,change__order_6_1);
  *reasonp++ =  a0;
  goto change__order_6_interrupt;
  };
  goto change__order_6_interrupt;
 change__order_6_ext_interrupt:
  reasonp = 0l;
 change__order_6_interrupt:
  toppred = &predicate_schedule_xchange__order_6;
  goto interrupt_6;
 }

 change__order_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 change__order_7_clear_reason:
  reasonp = reasons;
 change__order_7_0:
 change__order_7_1:
  switch (ptagof(a0)) {
 case CONS:
 change__order_7_2:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (isint(a1)) goto change__order_7_interrupt;
  switch (symval(a1)) {
 case symval(makesym(atom_thread)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_schedule_xchange__order_7);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = makesym(atom_not__thread);
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[11] = a2;
  allocp[12] = makeint(1L);
  allocp[13] = x1;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[16] = a2;
  allocp[17] = a5;
  allocp[18] = x3 = makeref(&allocp[18]);
  allocp[19] = x2;
  allocp[20] = (q)(struct goalrec*)&allocp[14];
  allocp[21] = (q)(&predicate_schedule_xadd__thread_4);
  allocp[22] = x4 = makeref(&allocp[22]);
  allocp[23] = x5 = makeref(&allocp[23]);
  allocp[24] = x6 = makeref(&allocp[24]);
  allocp[25] = x3;
  allocp[26] = (q)(struct goalrec*)&allocp[20];
  allocp[27] = (q)(&predicate_parse__uty_xdecode__goal_4);
  allocp[28] = x7 = makeref(&allocp[28]);
  allocp[29] = x4;
  allocp[30] = x5;
  allocp[31] = x6;
  allocp[32] = (q)(struct goalrec*)&allocp[26];
  allocp[33] = (q)(&predicate_functor__table_xarg_3);
  x8 = car_of(a0);
  allocp[34] = x8;
  allocp[35] = a4;
  allocp[36] = x7;
  qp = (struct goalrec*)&allocp[32];
  allocp += 37;
  proceed();
 case symval(makesym(atom_not__thread)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_schedule_xchange__order_7);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = makesym(atom_not__thread);
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[11] = a2;
  allocp[12] = makeint(1L);
  allocp[13] = x1;
  allocp[14] = (q)(struct goalrec*)&allocp[9];
  allocp[15] = (q)(&predicate_functor__table_xsetarg_4);
  allocp[16] = a2;
  allocp[17] = a5;
  allocp[18] = x3 = makeref(&allocp[18]);
  allocp[19] = x2;
  allocp[20] = (q)(struct goalrec*)&allocp[14];
  allocp[21] = (q)(&predicate_functor__table_xarg_3);
  x4 = car_of(a0);
  allocp[22] = x4;
  allocp[23] = a4;
  allocp[24] = x3;
  qp = (struct goalrec*)&allocp[20];
  allocp += 25;
  proceed();
  };
  goto change__order_7_interrupt;
 case VARREF:
  deref_and_jump(a1,change__order_7_2);
  *reasonp++ =  a1;
  goto change__order_7_interrupt;
  };
  goto change__order_7_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto change__order_7_interrupt;
  unify2(a3, a2, a6, a5);
  proceed();
 case VARREF:
  deref_and_jump(a0,change__order_7_1);
  *reasonp++ =  a0;
  goto change__order_7_interrupt;
  };
  goto change__order_7_interrupt;
 change__order_7_ext_interrupt:
  reasonp = 0l;
 change__order_7_interrupt:
  toppred = &predicate_schedule_xchange__order_7;
  goto interrupt_7;
 }

 add__thread_4_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 add__thread_4_clear_reason:
  reasonp = reasons;
 add__thread_4_0:
 add__thread_4_1:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_options_2)) goto add__thread_4_4;
  x0 = arg(a2, 1);
 add__thread_4_2:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_functor_1)) goto add__thread_4_4;
  x1 = arg(x0, 0);
 add__thread_4_3:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_node_1)) goto add__thread_4_4;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_parse__uty_xencode__goal_4);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  proceed();
 case VARREF:
  deref_and_jump(x1,add__thread_4_3);
  *reasonp++ =  x1;
  goto add__thread_4_4;
  };
  goto add__thread_4_4;
 case VARREF:
  deref_and_jump(x0,add__thread_4_2);
  *reasonp++ =  x0;
  goto add__thread_4_4;
  };
  goto add__thread_4_4;
 case VARREF:
  deref_and_jump(a2,add__thread_4_1);
  *reasonp++ =  a2;
  goto add__thread_4_4;
  };
  goto add__thread_4_4;
 add__thread_4_4:
  otherwise(add__thread_4_interrupt);
 add__thread_4_5:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_options_2)) goto add__thread_4_interrupt;
  allocp[0] = makesym(functor_options_2);
  x1 = arg(a2, 0);
  allocp[1] = x1;
  allocp[2] = makefunctor(funct_const_3);
  x0 = makefunctor(&allocp[0]);
  allocp[3] = (q)qp;
  allocp[4] = (q)(&predicate_parse__uty_xencode__goal_4);
  allocp[5] = a0;
  allocp[6] = a1;
  allocp[7] = x0;
  allocp[8] = a3;
  qp = (struct goalrec*)&allocp[3];
  allocp += 9;
  proceed();
 case VARREF:
  deref_and_jump(a2,add__thread_4_5);
  *reasonp++ =  a2;
  goto add__thread_4_interrupt;
  };
  goto add__thread_4_interrupt;
 add__thread_4_ext_interrupt:
  reasonp = 0l;
 add__thread_4_interrupt:
  goto interrupt_4;
 }
 interrupt_13:
  allocp[14] = a12;
 interrupt_12:
  allocp[13] = a11;
 interrupt_11:
  allocp[12] = a10;
 interrupt_10:
  allocp[11] = a9;
 interrupt_9:
  allocp[10] = a8;
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_schedule);
}
