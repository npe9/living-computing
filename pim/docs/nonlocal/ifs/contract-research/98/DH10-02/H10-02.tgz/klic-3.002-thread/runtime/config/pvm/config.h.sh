# ---------------------------------------------------------- 
#   (C) 1995 Institute for New Generation Computer Technology 
#	(Read COPYRIGHT for detailed information.) 
#   (C)1996, 1997 Japan Information Processing Development Center
#       (Read COPYRIGHT-JIPDEC for detailed information.)
# ----------------------------------------------------------

cat <<GAZONK >>config.h

#define PVMINC  "$PVM_ROOT/include"
#define PVMLIBDIR  "$PVM_ROOT/lib/$PVM_ARCH"
#define PVMLIB  "$PVMLIB"

#define DIST_COMPILER_FLAG() \
    {	(void)sprintf(bufp, " -DDIST -I%s -I. -I%s %s.c", \
		                   klic_incdir, PVMINC, name); }
#define DIST_LINKAGE_FLAG() \
  { (void)sprintf(bufp, " -L%s",PVMLIBDIR); \
    bufp += strlen(bufp); \
    (void)sprintf(bufp, " -l%s",PVMLIB); \
    bufp += strlen(bufp); }

GAZONK
echo " "
