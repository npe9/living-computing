#define KLIC_VERSION	"3.001"
#define KLIC_DATE	"Thu Jun  5 20:19:10 JST 1997"
