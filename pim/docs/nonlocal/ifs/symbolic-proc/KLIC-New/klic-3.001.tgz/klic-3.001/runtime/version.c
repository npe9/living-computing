char *runtime_version = "3.001";
char *runtime_date = "Thu Jun  5 20:19:10 JST 1997";
