/* ---------------------------------------------------------- 
%   (C)1993, 1994 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
struct predinfo {
  Const unsigned char *name;
  Const struct predicate *predstruct;
};

struct modinfo {
  Const unsigned char *name;
  Const struct predinfo * Const *preds;
};
