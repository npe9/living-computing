/* ---------------------------------------------------------- 
%   (C)1994 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
/*
  Signal handling
*/

#ifdef USESIG
#include <signal.h>

#ifndef NSIG
#define NSIG 32
#endif

#define signal_flags		(klic_sgnl_flags.flags)
#define signal_handlers		(klic_sgnl_flags.sgnl_handlers)
#define signal_done		(klic_sgnl_flags.done)

struct klic_sgnl_flags {
  long flags[NSIG];
  int ((*sgnl_handlers[NSIG])());
  long done;
};

Volatile struct klic_sgnl_flags klic_sgnl_flags;

#endif
