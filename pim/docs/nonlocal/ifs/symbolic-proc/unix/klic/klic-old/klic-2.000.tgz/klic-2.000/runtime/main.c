/* ---------------------------------------------------------- 
%   (C)1994 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */

extern int klic_main();

main(argc, argv)
     int argc;
     char **argv;
{
  return klic_main(argc, argv);
}
