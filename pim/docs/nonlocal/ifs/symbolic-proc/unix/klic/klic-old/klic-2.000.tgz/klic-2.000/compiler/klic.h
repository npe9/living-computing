/* ---------------------------------------------------------- 
%   (C)1993, 1994 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
#define DBFILENAME "klic.db"
#define LIBDBNAME  "libklic.db"
#define DBINITFILE "klicdb.init"

#define BUFSIZE 16384
