/* ---------------------------------------------------------- 
%   (C)1993,1994 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */

/* atomnumber staffs */
extern unsigned char **atomname;
#define ATOMNUMBERBASE 2
#define functoratomname(f) atomname[functoratom(f) - ATOMNUMBERBASE]
#define namestringof(a) atomname[symval(a) - ATOMNUMBERBASE]
