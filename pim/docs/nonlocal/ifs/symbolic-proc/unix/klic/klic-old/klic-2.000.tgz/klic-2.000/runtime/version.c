char *runtime_version = "2.000";
char *runtime_date = "Thu Apr 27 13:20:36 JST 1995";
