/* ---------------------------------------------------------- 
%   (C) 1994 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */

#include <stdlib.h>

char *
option_value(optname, dflt)
     char *optname;
     char *dflt;
{
  char *envval = getenv(optname);
  return (envval==0 ? dflt : envval);
}
