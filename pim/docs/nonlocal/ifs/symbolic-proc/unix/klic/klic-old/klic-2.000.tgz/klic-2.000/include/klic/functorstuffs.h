/* ---------------------------------------------------------- 
%   (C)1993 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */

/* functor staffs */
extern unsigned long *arities;
extern unsigned long *functors;
#define FUNCTORNUMBERBASE 0
#define functoratom(f) functors[symval(f) - FUNCTORNUMBERBASE]
#define arityof(f) arities[symval(f) - FUNCTORNUMBERBASE]

