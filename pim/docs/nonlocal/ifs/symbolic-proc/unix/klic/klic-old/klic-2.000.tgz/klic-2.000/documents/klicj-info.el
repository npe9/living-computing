;; ---------------------------------------------------------- 
;;   (C)1993, 1994, 1995 Institute for New Generation Computer Technology 
;;      (Read COPYRIGHT for detailed information.) 
;;  ----------------------------------------------------------
(find-file "klicj.tex")
(texinfo-format-buffer t)
(switch-to-buffer "KLICj.info")
(save-buffer)

