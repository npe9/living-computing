/* ---------------------------------------------------------- 
%   (C)1993,1994 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */

struct termarray_object {
  struct data_object_method_table *method_table;
  unsigned long nterm;
  q terms[1];
};
