#define KLIC_VERSION	"2.001"
#define KLIC_DATE	"Tue May  9 17:01:10 JST 1995"
