char *runtime_version = "2.001";
char *runtime_date = "Tue May  9 17:01:10 JST 1995";
