/* Compiled by KLIC compiler version 1.500 (Fri Oct 21 12:19:27 JST 1994) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_variable();
Const struct predicate predicate_variable_xwrap_2 =
   { module_variable, 0, 2 };
Const struct predicate predicate_variable_xwrap_2F2_240_3 =
   { module_variable, 1, 3 };
Const struct predicate predicate_variable_xwrap__bound_2 =
   { module_variable, 2, 2 };
Const struct predicate predicate_variable_xwrap__vec__elems_5 =
   { module_variable, 3, 5 };
Const struct predicate predicate_variable_xwrap__funct__elems_6 =
   { module_variable, 4, 6 };
Const struct predicate predicate_variable_xunwrap_2 =
   { module_variable, 5, 2 };
Const struct predicate predicate_variable_xunwrap_3 =
   { module_variable, 6, 3 };
Const struct predicate predicate_variable_xunwrap_4 =
   { module_variable, 7, 4 };
Const struct predicate predicate_variable_xunwrap__functor_8 =
   { module_variable, 8, 8 };
Const struct predicate predicate_variable_xunwrap__vector_6 =
   { module_variable, 9, 6 };
Const struct predicate predicate_variable_xget__variable_4 =
   { module_variable, 10, 4 };
Const struct predicate predicate_variable_xget__variable2_4 =
   { module_variable, 11, 4 };
extern Const struct predicate predicate_system__control_xunbound_2;
extern q vector_g_new();
extern Const struct predicate predicate_integer__arithmetics_xadd_3;
extern Const struct predicate predicate_functor__table_x_3D_2E_2E_2;

module module_variable(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  Const static unsigned char strconst_body_0[4] =
    "_";
  Const static string_structure_type_8 string_const_0 =
      declare_string_constant_8(strconst_body_0,1);
  Const static q funct_const_1[] = {
    makesym(functor_variable_1),
    makefunctor(&string_const_0),
  };
  Const static unsigned char strconst_body_2[4] =
    "_";
  Const static string_structure_type_8 string_const_2 =
      declare_string_constant_8(strconst_body_2,1);
  q a0, a1, a2, a3, a4, a5, a6, a7;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, wrap_2_top);
    case_pred(1, wrap_2F2_240_3_top);
    case_pred(2, wrap__bound_2_top);
    case_pred(3, wrap__vec__elems_5_top);
    case_pred(4, wrap__funct__elems_6_top);
    case_pred(5, unwrap_2_top);
    case_pred(6, unwrap_3_top);
    case_pred(7, unwrap_4_top);
    case_pred(8, unwrap__functor_8_top);
    case_pred(9, unwrap__vector_6_top);
    case_pred(10, get__variable_4_top);
    last_case_pred(11, get__variable2_4_top);
  }

 wrap_2_top: {
  q x0;
  qp = qp->next;
 wrap_2_clear_reason:
  reasonp = reasons;
 wrap_2_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_variable_xwrap_2F2_240_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_system__control_xunbound_2);
  allocp[7] = a0;
  allocp[8] = x0;
  qp = (struct goalrec*)&allocp[5];
  allocp += 9;
  proceed();
 wrap_2_ext_interrupt:
  reasonp = 0l;
 wrap_2_interrupt:
  toppred = &predicate_variable_xwrap_2;
  goto interrupt_2;
 }

 wrap_2F2_240_3_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  qp = qp->next;
 wrap_2F2_240_3_clear_reason:
  reasonp = reasons;
 wrap_2F2_240_3_0:
 wrap_2F2_240_3_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
 wrap_2F2_240_3_2:
  if (!isgobj(a0)) goto wrap_2F2_240_3_interrupt;
  if (!isclass(a0,vector)) goto wrap_2F2_240_3_interrupt;
  gblt_size_of_vector(a0,x0,wrap_2F2_240_3_interrupt);
 wrap_2F2_240_3_6:
  switch ((unsigned long)x0) {
 case (unsigned long) makeint(1L):
 wrap_2F2_240_3_7:
  if (!isgobj(a0)) goto wrap_2F2_240_3_interrupt;
 wrap_2F2_240_3_8:
  generic_arg[0] = makeint(0L);
  guard_generic(a0, functor_element_2, 1, wrap_2F2_240_3_interrupt);
  x1 = generic_arg[1];
  a0 = a1;
  a1 = a2;
  execute(wrap__bound_2_0);
  goto wrap__bound_2_ext_interrupt;
 case (unsigned long) makeint(3L):
 wrap_2F2_240_3_10:
  if (!isgobj(a0)) goto wrap_2F2_240_3_interrupt;
 wrap_2F2_240_3_11:
  generic_arg[0] = makeint(0L);
  guard_generic(a0, functor_element_2, 1, wrap_2F2_240_3_interrupt);
  x1 = generic_arg[1];
  generic_arg[0] = makeint(1L);
  guard_generic(a0, functor_element_2, 1, wrap_2F2_240_3_interrupt);
  x2 = generic_arg[1];
  generic_arg[0] = makeint(2L);
  guard_generic(a0, functor_element_2, 1, wrap_2F2_240_3_interrupt);
  x3 = generic_arg[1];
  unify_value(a2, makefunctor(funct_const_1));
  proceed();
 default:
  goto wrap_2F2_240_3_interrupt;
  };
 case VARREF:
  deref_and_jump(a0,wrap_2F2_240_3_1);
  *reasonp++ =  a0;
  goto wrap_2F2_240_3_interrupt;
  };
  goto wrap_2F2_240_3_interrupt;
 wrap_2F2_240_3_ext_interrupt:
  reasonp = 0l;
 wrap_2F2_240_3_interrupt:
  goto interrupt_3;
 }

 wrap__bound_2_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  qp = qp->next;
 wrap__bound_2_clear_reason:
  reasonp = reasons;
 wrap__bound_2_0:
 wrap__bound_2_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = x2 = makeref(&allocp[1]);
  x0 = makecons(&allocp[0]);
  allocp[2] = makesym(functor_list_1);
  allocp[3] = x0;
  x3 = makefunctor(&allocp[2]);
  allocp += 4;
  unify_value(a1, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_variable_xwrap_2);
  x4 = cdr_of(a0);
  allocp[2] = x4;
  allocp[3] = x1;
  a0 = car_of(a0);
  a1 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  execute(wrap_2_0);
  goto wrap_2_ext_interrupt;
 case ATOMIC:
  if (isint(a0)) goto wrap__bound_2_7;
 wrap__bound_2_5:
  gblt_atom(a0,wrap__bound_2_19);
  allocp[0] = makesym(functor_atom_1);
  allocp[1] = a0;
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  proceed();
 wrap__bound_2_7:
  gblt_integer(a0,wrap__bound_2_19);
  allocp[0] = makesym(functor_integer_1);
  allocp[1] = a0;
  x1 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x1);
  proceed();
 case FUNCTOR:
 wrap__bound_2_9:
  if (!isgobj(a0)) goto wrap__bound_2_19;
  if (!isclass(a0,vector)) goto wrap__bound_2_13;
  gblt_size_of_vector(a0,x0,wrap__bound_2_13);
  generic_arg[0] = x0;
  new_generic(vector_g_new, 1, x1, 0);
  allocp[0] = makesym(functor_vector_1);
  allocp[1] = x3 = makeref(&allocp[1]);
  x2 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x2);
  a1 = x0;
  a2 = a0;
  a3 = x1;
  a4 = x3;
  a0 = makeint(0L);
  execute(wrap__vec__elems_5_0);
  goto wrap__vec__elems_5_ext_interrupt;
 wrap__bound_2_13:
  guard_generic(a0, functor_float_0, 0, wrap__bound_2_15);
  allocp[0] = makesym(functor_floating__point_1);
  allocp[1] = a0;
  x4 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x4);
  proceed();
 wrap__bound_2_15:
  gblt_is_string(a0,wrap__bound_2_19);
  gblt_size_of_string(a0,x4,wrap__bound_2_19);
  gblt_element_size_of_string(a0,x5,wrap__bound_2_19);
  allocp[0] = makesym(functor_string_1);
  allocp[1] = a0;
  x6 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x6);
  proceed();
 case VARREF:
  deref_and_jump(a0,wrap__bound_2_1);
  *reasonp++ =  a0;
  goto wrap__bound_2_23;
  };
  goto wrap__bound_2_19;
 wrap__bound_2_19:
  gblt_pfunctor(a0,x0,wrap__bound_2_23);
  gblt_arity(a0,x1,wrap__bound_2_23);
  gblt_greater(x1,makeint(0L),wrap__bound_2_23);
  allocp[0] = makesym(functor_functor_1);
  allocp[1] = x3 = makeref(&allocp[1]);
  x2 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x2);
  allocp[0] = x5 = makeref(&allocp[0]);
  allocp[1] = x0;
  x4 = makecons(&allocp[0]);
  a1 = x1;
  a2 = a0;
  a3 = x4;
  a4 = x5;
  a5 = x3;
  a0 = makeint(0L);
  allocp += 2;
  execute(wrap__funct__elems_6_0);
  goto wrap__funct__elems_6_ext_interrupt;
 wrap__bound_2_23:
  otherwise(wrap__bound_2_interrupt);
  allocp[0] = makesym(functor_unknown_1);
  allocp[1] = a0;
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  proceed();
 wrap__bound_2_ext_interrupt:
  reasonp = 0l;
 wrap__bound_2_interrupt:
  toppred = &predicate_variable_xwrap__bound_2;
  goto interrupt_2;
 }

 wrap__vec__elems_5_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 wrap__vec__elems_5_clear_reason:
  reasonp = reasons;
 wrap__vec__elems_5_0:
 wrap__vec__elems_5_1:
  if (!isint(a0)) goto wrap__vec__elems_5_9;
 wrap__vec__elems_5_3:
  if (!isint(a1)) goto wrap__vec__elems_5_8;
  gblt_eq(a0,a1,wrap__vec__elems_5_6);
  unify(a4, a3);
  proceed();
 wrap__vec__elems_5_6:
  gblt_less(a0,a1,wrap__vec__elems_5_interrupt);
  generic_arg[0] = a0;
  allocp[0] = x0 = makeref(&allocp[0]);
  generic_arg[1] = x0;
  allocp[1] = x1 = makeref(&allocp[1]);
  generic_arg[2] = x1;
  allocp[2] = x2 = makeref(&allocp[2]);
  generic_arg[3] = x2;
  call_generic(a3, functor_set__element_4, 3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_variable_xwrap__vec__elems_5);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x2;
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[9] = a0;
  allocp[10] = makeint(1L);
  allocp[11] = x3;
  a0 = x0;
  a1 = x1;
  qp = (struct goalrec*)&allocp[7];
  allocp += 12;
  execute(wrap_2_0);
  goto wrap_2_ext_interrupt;
 wrap__vec__elems_5_8:
  if (!isref(a1)) goto wrap__vec__elems_5_interrupt;
  deref_and_jump(a1,wrap__vec__elems_5_3);
  *reasonp++ =  a1;
  goto wrap__vec__elems_5_interrupt;
 wrap__vec__elems_5_9:
  if (!isref(a0)) goto wrap__vec__elems_5_interrupt;
  deref_and_jump(a0,wrap__vec__elems_5_1);
  *reasonp++ =  a0;
  goto wrap__vec__elems_5_interrupt;
 wrap__vec__elems_5_ext_interrupt:
  reasonp = 0l;
 wrap__vec__elems_5_interrupt:
  toppred = &predicate_variable_xwrap__vec__elems_5;
  goto interrupt_5;
 }

 wrap__funct__elems_6_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 wrap__funct__elems_6_clear_reason:
  reasonp = reasons;
 wrap__funct__elems_6_0:
 wrap__funct__elems_6_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (!isint(a0)) goto wrap__funct__elems_6_9;
 wrap__funct__elems_6_3:
  gblt_add(a0,makeint(1L),x0,wrap__funct__elems_6_9);
 wrap__funct__elems_6_5:
  if (isref(a2)) goto wrap__funct__elems_6_8;
  gblt_arg(x0,a2,x1,wrap__funct__elems_6_9);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_variable_xwrap__funct__elems_6);
  allocp[2] = x0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x2;
  allocp[9] = x4 = makeref(&allocp[9]);
  x3 = makecons(&allocp[8]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  unify_value(a4, x3);
  a0 = x1;
  a1 = x4;
  execute(wrap_2_0);
  goto wrap_2_ext_interrupt;
 wrap__funct__elems_6_8:
  deref_and_jump(a2,wrap__funct__elems_6_5);
  *reasonp++ =  a2;
  goto wrap__funct__elems_6_9;
 case VARREF:
  deref_and_jump(a0,wrap__funct__elems_6_1);
  *reasonp++ =  a0;
  goto wrap__funct__elems_6_interrupt;
  };
  goto wrap__funct__elems_6_9;
 wrap__funct__elems_6_9:
 wrap__funct__elems_6_10:
  if (isref(a0)) goto wrap__funct__elems_6_13;
  if_not_equal(a0, a1, wrap__funct__elems_6_interrupt);
  unify_value(a4, NILATOM);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[2] = a5;
  allocp[3] = a3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  proceed();
 wrap__funct__elems_6_13:
  deref_and_jump(a0,wrap__funct__elems_6_10);
  *reasonp++ =  a0;
  goto wrap__funct__elems_6_interrupt;
 wrap__funct__elems_6_ext_interrupt:
  reasonp = 0l;
 wrap__funct__elems_6_interrupt:
  toppred = &predicate_variable_xwrap__funct__elems_6;
  goto interrupt_6;
 }

 unwrap_2_top: {
  q x0;
  qp = qp->next;
 unwrap_2_clear_reason:
  reasonp = reasons;
 unwrap_2_0:
  a2 = NILATOM;
  allocp[0] = x0 = makeref(&allocp[0]);
  a3 = x0;
  allocp += 1;
  execute(unwrap_4_0);
  goto unwrap_4_ext_interrupt;
 unwrap_2_ext_interrupt:
  reasonp = 0l;
 unwrap_2_interrupt:
  goto interrupt_2;
 }

 unwrap_3_top: {
  a2 = qp->args[2];
  qp = qp->next;
 unwrap_3_clear_reason:
  reasonp = reasons;
 unwrap_3_0:
  a3 = a2;
  a2 = NILATOM;
  execute(unwrap_4_0);
  goto unwrap_4_ext_interrupt;
 unwrap_3_ext_interrupt:
  reasonp = 0l;
 unwrap_3_interrupt:
  goto interrupt_3;
 }

 unwrap_4_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 unwrap_4_clear_reason:
  reasonp = reasons;
 unwrap_4_0:
 unwrap_4_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_variable_1:
  a0 = arg(a0, 0);
  execute(get__variable_4_0);
  goto get__variable_4_ext_interrupt;
 case functor_atom_1:
  unify(a3, a2);
  x0 = arg(a0, 0);
  unify(a1, x0);
  proceed();
 case functor_integer_1:
  unify(a3, a2);
  x0 = arg(a0, 0);
  unify(a1, x0);
  proceed();
 case functor_floating__point_1:
  unify(a3, a2);
  x0 = arg(a0, 0);
  unify(a1, x0);
  proceed();
 case functor_list_1:
  x0 = arg(a0, 0);
 unwrap_4_8:
  switch (ptagof(x0)) {
 case CONS:
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = x3 = makeref(&allocp[1]);
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_variable_xunwrap_4);
  x4 = cdr_of(x0);
  allocp[2] = x4;
  allocp[3] = x2;
  allocp[4] = x5 = makeref(&allocp[4]);
  allocp[5] = a3;
  a0 = car_of(x0);
  a1 = x3;
  a3 = x5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(unwrap_4_0);
  goto unwrap_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,unwrap_4_8);
  *reasonp++ =  x0;
  goto unwrap_4_interrupt;
  };
  goto unwrap_4_interrupt;
 case functor_functor_1:
  x0 = arg(a0, 0);
 unwrap_4_11:
  if (isref(x0)) goto unwrap_4_15;
  gblt_pfunctor(x0,x1,unwrap_4_interrupt);
  gblt_arity(x0,x2,unwrap_4_interrupt);
  allocp[0] = x4 = makeref(&allocp[0]);
  allocp[1] = x1;
  x3 = makecons(&allocp[0]);
  a0 = makeint(0L);
  a4 = x4;
  a5 = a1;
  a6 = a2;
  a7 = a3;
  a3 = x3;
  a2 = x0;
  a1 = x2;
  allocp += 2;
  execute(unwrap__functor_8_0);
  goto unwrap__functor_8_ext_interrupt;
 unwrap_4_15:
  deref_and_jump(x0,unwrap_4_11);
  *reasonp++ =  x0;
  goto unwrap_4_interrupt;
 case functor_vector_1:
  x0 = arg(a0, 0);
 unwrap_4_17:
  switch (ptagof(x0)) {
 case FUNCTOR:
 unwrap_4_18:
  if (!isgobj(x0)) goto unwrap_4_interrupt;
  if (!isclass(x0,vector)) goto unwrap_4_interrupt;
  gblt_size_of_vector(x0,x1,unwrap_4_interrupt);
  a0 = makeint(0L);
  x2 = a1;
  a4 = a2;
  a5 = a3;
  a3 = x2;
  a2 = x0;
  a1 = x1;
  execute(unwrap__vector_6_0);
  goto unwrap__vector_6_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,unwrap_4_17);
  *reasonp++ =  x0;
  goto unwrap_4_interrupt;
  };
  goto unwrap_4_interrupt;
 case functor_string_1:
  unify(a3, a2);
  x0 = arg(a0, 0);
  unify(a1, x0);
  proceed();
 case functor_unknown_1:
  unify(a3, a2);
  x0 = arg(a0, 0);
  unify(a1, x0);
  proceed();
 default:
  goto unwrap_4_interrupt;
  };
 case VARREF:
  deref_and_jump(a0,unwrap_4_1);
  *reasonp++ =  a0;
  goto unwrap_4_interrupt;
  };
  goto unwrap_4_interrupt;
 unwrap_4_ext_interrupt:
  reasonp = 0l;
 unwrap_4_interrupt:
  toppred = &predicate_variable_xunwrap_4;
  goto interrupt_4;
 }

 unwrap__functor_8_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 unwrap__functor_8_clear_reason:
  reasonp = reasons;
 unwrap__functor_8_0:
 unwrap__functor_8_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (!isint(a0)) goto unwrap__functor_8_13;
 unwrap__functor_8_3:
 unwrap__functor_8_4:
  if (!isint(a1)) goto unwrap__functor_8_12;
  gblt_less(a0,a1,unwrap__functor_8_13);
  gblt_add(a0,makeint(1L),x0,unwrap__functor_8_13);
 unwrap__functor_8_8:
  if (isref(a2)) goto unwrap__functor_8_11;
  gblt_arg(x0,a2,x1,unwrap__functor_8_13);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_variable_xunwrap__functor_8);
  allocp[2] = x0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x2;
  allocp[11] = x5 = makeref(&allocp[11]);
  x4 = makecons(&allocp[10]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  unify_value(a4, x4);
  a0 = x1;
  a1 = x5;
  a2 = a6;
  a3 = x3;
  execute(unwrap_4_0);
  goto unwrap_4_ext_interrupt;
 unwrap__functor_8_11:
  deref_and_jump(a2,unwrap__functor_8_8);
  *reasonp++ =  a2;
  goto unwrap__functor_8_13;
 unwrap__functor_8_12:
  if (!isref(a1)) goto unwrap__functor_8_13;
  deref_and_jump(a1,unwrap__functor_8_4);
  *reasonp++ =  a1;
  goto unwrap__functor_8_13;
 case VARREF:
  deref_and_jump(a0,unwrap__functor_8_1);
  *reasonp++ =  a0;
  goto unwrap__functor_8_interrupt;
  };
  goto unwrap__functor_8_13;
 unwrap__functor_8_13:
 unwrap__functor_8_14:
  if (isref(a0)) goto unwrap__functor_8_17;
  if_not_equal(a0, a1, unwrap__functor_8_interrupt);
  unify_value(a4, NILATOM);
  unify(a7, a6);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[2] = a5;
  allocp[3] = a3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  proceed();
 unwrap__functor_8_17:
  deref_and_jump(a0,unwrap__functor_8_14);
  *reasonp++ =  a0;
  goto unwrap__functor_8_interrupt;
 unwrap__functor_8_ext_interrupt:
  reasonp = 0l;
 unwrap__functor_8_interrupt:
  toppred = &predicate_variable_xunwrap__functor_8;
  goto interrupt_8;
 }

 unwrap__vector_6_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 unwrap__vector_6_clear_reason:
  reasonp = reasons;
 unwrap__vector_6_0:
 unwrap__vector_6_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (!isint(a0)) goto unwrap__vector_6_8;
 unwrap__vector_6_3:
 unwrap__vector_6_4:
  if (!isint(a1)) goto unwrap__vector_6_7;
  gblt_not_eq(a0,a1,unwrap__vector_6_8);
  bblt_add_no_check(a0,makeint(1L),x0);
  generic_arg[0] = a0;
  allocp[0] = x1 = makeref(&allocp[0]);
  generic_arg[1] = x1;
  allocp[1] = x2 = makeref(&allocp[1]);
  generic_arg[2] = x2;
  allocp[2] = x3 = makeref(&allocp[2]);
  generic_arg[3] = x3;
  call_generic(a2, functor_set__element_4, 3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_variable_xunwrap__vector_6);
  allocp[2] = x0;
  allocp[3] = a1;
  allocp[4] = x3;
  allocp[5] = a3;
  allocp[6] = x4 = makeref(&allocp[6]);
  allocp[7] = a5;
  a0 = x1;
  a1 = x2;
  a2 = a4;
  a3 = x4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  execute(unwrap_4_0);
  goto unwrap_4_ext_interrupt;
 unwrap__vector_6_7:
  if (!isref(a1)) goto unwrap__vector_6_8;
  deref_and_jump(a1,unwrap__vector_6_4);
  *reasonp++ =  a1;
  goto unwrap__vector_6_8;
 case VARREF:
  deref_and_jump(a0,unwrap__vector_6_1);
  *reasonp++ =  a0;
  goto unwrap__vector_6_interrupt;
  };
  goto unwrap__vector_6_8;
 unwrap__vector_6_8:
 unwrap__vector_6_9:
  if (isref(a0)) goto unwrap__vector_6_12;
  if_not_equal(a0, a1, unwrap__vector_6_interrupt);
  unify2(a3, a2, a5, a4);
  proceed();
 unwrap__vector_6_12:
  deref_and_jump(a0,unwrap__vector_6_9);
  *reasonp++ =  a0;
  goto unwrap__vector_6_interrupt;
 unwrap__vector_6_ext_interrupt:
  reasonp = 0l;
 unwrap__vector_6_interrupt:
  toppred = &predicate_variable_xunwrap__vector_6;
  goto interrupt_6;
 }

 get__variable_4_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 get__variable_4_clear_reason:
  reasonp = reasons;
 get__variable_4_0:
 get__variable_4_1:
  if (isref(a0)) goto get__variable_4_7;
 get__variable_4_3:
  if (isref(a0)) goto get__variable_4_6;
  x0 = makefunctor(&string_const_2);
  if_not_equal(a0, x0, get__variable_4_8);
  unify(a3, a2);
  proceed();
 get__variable_4_6:
  deref_and_jump(a0,get__variable_4_3);
  *reasonp++ =  a0;
  goto get__variable_4_8;
 get__variable_4_7:
  deref_and_jump(a0,get__variable_4_1);
  *reasonp++ =  a0;
  goto get__variable_4_8;
 get__variable_4_8:
  otherwise(get__variable_4_interrupt);
  execute(get__variable2_4_0);
  goto get__variable2_4_ext_interrupt;
 get__variable_4_ext_interrupt:
  reasonp = 0l;
 get__variable_4_interrupt:
  toppred = &predicate_variable_xget__variable_4;
  goto interrupt_4;
 }

 get__variable2_4_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 get__variable2_4_clear_reason:
  reasonp = reasons;
 get__variable2_4_0:
 get__variable2_4_1:
  switch (ptagof(a2)) {
 case CONS:
  x0 = car_of(a2);
 get__variable2_4_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_var_2)) goto get__variable2_4_16;
  x1 = arg(x0, 0);
 get__variable2_4_6:
  if (isref(x1)) goto get__variable2_4_12;
 get__variable2_4_8:
  if (isref(x1)) goto get__variable2_4_11;
  if_not_equal(x1, a0, get__variable2_4_16);
  allocp[0] = makesym(functor_var_2);
  allocp[1] = a0;
  x3 = arg(x0, 1);
  allocp[2] = x3;
  x2 = makefunctor(&allocp[0]);
  x5 = cdr_of(a2);
  allocp[3] = x5;
  allocp[4] = x2;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a3, x4);
  unify(a1, x3);
  proceed();
 get__variable2_4_11:
  deref_and_jump(x1,get__variable2_4_8);
  *reasonp++ =  x1;
  goto get__variable2_4_16;
 get__variable2_4_12:
  deref_and_jump(x1,get__variable2_4_6);
  *reasonp++ =  x1;
  goto get__variable2_4_16;
 case VARREF:
  deref_and_jump(x0,get__variable2_4_3);
  *reasonp++ =  x0;
  goto get__variable2_4_16;
  };
  goto get__variable2_4_16;
 case ATOMIC:
  if (a2 != NILATOM) goto get__variable2_4_16;
  allocp[0] = makesym(functor_var_2);
  allocp[1] = a0;
  allocp[2] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = NILATOM;
  allocp[4] = x0;
  x1 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a3, x1);
  proceed();
 case VARREF:
  deref_and_jump(a2,get__variable2_4_1);
  *reasonp++ =  a2;
  goto get__variable2_4_16;
  };
  goto get__variable2_4_16;
 get__variable2_4_16:
  otherwise(get__variable2_4_interrupt);
 get__variable2_4_18:
  switch (ptagof(a2)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a2);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a3, x0);
  a2 = cdr_of(a2);
  a3 = x1;
  execute(get__variable2_4_0);
  goto get__variable2_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,get__variable2_4_18);
  *reasonp++ =  a2;
  goto get__variable2_4_interrupt;
  };
  goto get__variable2_4_interrupt;
 get__variable2_4_ext_interrupt:
  reasonp = 0l;
 get__variable2_4_interrupt:
  toppred = &predicate_variable_xget__variable2_4;
  goto interrupt_4;
 }
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_variable);
}
