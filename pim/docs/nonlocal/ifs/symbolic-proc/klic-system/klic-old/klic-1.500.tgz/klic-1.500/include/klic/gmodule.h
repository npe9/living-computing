/* ---------------------------------------------------------- 
%   (C)1993, 1994 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */

struct module_object {
  struct data_object_method_table *method_table;
  q name;
};

extern struct data_object_method_table module_g_data_method_table;
#define module_structure_type		struct module_object
#define declare_module_constant(mod,name)	\
{						\
  &module_g_data_method_table,			\
  name						\
}
#define makemodule(x)		makefunctor(&x)

struct predicate_object {
  struct data_object_method_table *method_table;
  Const struct predicate *pdesc; /* atom tag */
  q module_obj;
  q predicate_name;
};

extern struct data_object_method_table predicate_g_data_method_table;
#define predicate_structure_type	struct predicate_object
#define declare_pred_constant(pred,mod,name)	\
{						\
  &predicate_g_data_method_table,		\
  (struct predicate *)&pred,			\
  makemodule(mod),				\
  name						\
}

#define makepred(x)		makefunctor(&x)

#define ISVALIDSYMBOL(nl) ((nl).n_type != 0)
