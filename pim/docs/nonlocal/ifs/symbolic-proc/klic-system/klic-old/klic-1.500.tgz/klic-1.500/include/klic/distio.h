#include "pvm3.h"
#define SHOENNAME "shoen"
#define Finish   tag[0]
#define Attach   tag[1]
#define Detach   tag[2]
#define System_putb tag[3]
#define System_gets tag[4]
#define System_putc tag[5]
#define System_getc tag[6]
#define System_fflush tag[7]
#define Putb     tag[8]
#define EPutb    tag[9]
#define Gets     tag[10]
#define User_putc     tag[11]
#define User_eputc    tag[12]
#define User_getc     tag[13]
#define User_fflush     tag[14]
#define Emergency_stop     tag[15]
#define System_IsEOF   tag[16]

#ifdef MAIN
int tag[] = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16};
#else
extern int tag[];
#endif

#define FinishTag   0
#define AttachTag   1
#define DetachTag   2
#define System_putbTag 3
#define System_getsTag 4
#define System_putcTag 5
#define System_getcTag 6
#define System_fflushTag 7
#define PutbTag     8
#define EPutbTag    9
#define GetsTag     10
#define User_putcTag     11
#define User_eputcTag    12
#define User_getcTag     13
#define User_fflushTag      14
#define Emergency_stopTag      15
#define System_IsEOFTag     16

#define EmergencyStop \
    bufid = pvm_initsend(PvmDataDefault); \
    pvm_pkint(&Emergency_stop,1,1); \
    pvm_send(iotid,3);

#define CloseIO \
    bufid = pvm_initsend(PvmDataDefault); \
    pvm_pkint(&Finish,1,1); \
    pvm_send(iotid,3);

#define AttachIO \
    bufid = pvm_initsend(PvmDataDefault); \
    pvm_pkint(&Attach,1,1); \
    pvm_send(iotid,3);

#define DetachIO \
    bufid = pvm_initsend(PvmDataDefault); \
    pvm_pkint(&Detach,1,1); \
    pvm_send(iotid,3);

#define SystemPrint(Str) \
    bufid = pvm_initsend(PvmDataDefault); \
    pvm_pkint(&System_putb,1,1); \
    pvm_pkstr(Str); \
    pvm_send(iotid,3);

#define SystemRead(Str) \
    bufid = pvm_initsend(PvmDataDefault); \
    pvm_pkint(&System_gets,1,1); \
    pvm_send(iotid,3); \
    pvm_recv(iotid,-1); \
    pvm_upkstr(Str);

#define SystemPutc(Char) \
{  char ch[1]; ch[0] = Char; \
    bufid = pvm_initsend(PvmDataDefault); \
    pvm_pkint(&System_putc,1,1); \
    pvm_pkbyte(ch,1,1); \
    pvm_send(iotid,3); \
 }

#define SystemRead(Str) \
    bufid = pvm_initsend(PvmDataDefault); \
    pvm_pkint(&System_gets,1,1); \
    pvm_send(iotid,3); \
    pvm_recv(iotid,-1); \
    pvm_upkstr(Str);

#define SystemGetc(Char) \
    bufid = pvm_initsend(PvmDataDefault); \
    pvm_pkint(&System_getc,1,1); \
    pvm_send(iotid,3); \
    pvm_recv(iotid,-1); \
    pvm_upkbyte(Char,1,1); 

#define SystemFflush() \
    bufid = pvm_initsend(PvmDataDefault); \
    pvm_pkint(&System_fflush,1,1); \
    pvm_send(iotid,3); \

#define Print(Str) \
    bufid = pvm_initsend(PvmDataDefault); \
    pvm_pkint(&Putb,1,1); \
    pvm_pkstr(Str); \
    pvm_send(iotid,3);

#define EPrint(Str) \
    bufid = pvm_initsend(PvmDataDefault); \
    pvm_pkint(&EPutb,1,1); \
    pvm_pkstr(Str); \
    pvm_send(iotid,3);

#define UserPutc(Char) \
{  char ch = Char; \
    bufid = pvm_initsend(PvmDataDefault); \
    pvm_pkint(&User_putc,1,1); \
    pvm_pkbyte(&ch,1,1); \
    pvm_send(iotid,3); \
 }

#define UserEPutc(Char) \
{  char ch = Char; \
    bufid = pvm_initsend(PvmDataDefault); \
    pvm_pkint(&User_eputc,1,1); \
    pvm_pkbyte(&ch,1,1); \
    pvm_send(iotid,3); \
 }

#define Read(Str) \
    bufid = pvm_initsend(PvmDataDefault); \
    pvm_pkint(&Gets,1,1); \
    pvm_send(iotid,3); \
    pvm_recv(iotid,-1); \
    pvm_upkstr(Str);

#define UserGetc(Char) \
    bufid = pvm_initsend(PvmDataDefault); \
    pvm_pkint(&User_getc,1,1); \
    pvm_send(iotid,3); \
    pvm_recv(iotid,-1); \
    pvm_upkbyte(Char,1,1); 

#define UserFflush() \
    bufid = pvm_initsend(PvmDataDefault); \
    pvm_pkint(&User_fflush,1,1); \
    pvm_send(iotid,3); 

#define SystemIsEOF(Char) \
    bufid = pvm_initsend(PvmDataDefault); \
    pvm_pkint(&System_IsEOF,1,1); \
    pvm_send(iotid,3); \
    pvm_recv(iotid,-1); \
    pvm_upkbyte(Char,1,1); 

Extern char iobuf[1024];

