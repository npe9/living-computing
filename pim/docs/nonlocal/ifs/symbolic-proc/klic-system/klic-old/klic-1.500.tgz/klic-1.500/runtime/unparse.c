/* Compiled by KLIC compiler version 1.500 (Fri Oct 21 12:19:27 JST 1994) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_unparser();
Const struct predicate predicate_unparser_xunparse_4 =
   { module_unparser, 0, 4 };
Const struct predicate predicate_unparser_xunparse_2F4_240_4 =
   { module_unparser, 1, 4 };
Const struct predicate predicate_unparser_xunparse__args_6 =
   { module_unparser, 2, 6 };
Const struct predicate predicate_unparser_xunparse__vecargs_6 =
   { module_unparser, 3, 6 };
Const struct predicate predicate_unparser_xunparse__cdr_4 =
   { module_unparser, 4, 4 };
Const struct predicate predicate_unparser_xunwparse_4 =
   { module_unparser, 5, 4 };
Const struct predicate predicate_unparser_xunwparse_2F4_240_4 =
   { module_unparser, 6, 4 };
Const struct predicate predicate_unparser_xunwparse__args_6 =
   { module_unparser, 7, 6 };
Const struct predicate predicate_unparser_xunwparse__vecargs_6 =
   { module_unparser, 8, 6 };
Const struct predicate predicate_unparser_xunwparse__cdr_4 =
   { module_unparser, 9, 4 };
Const struct predicate predicate_unparser_xunparse__atom_3 =
   { module_unparser, 10, 3 };
Const struct predicate predicate_unparser_xto__be__quoted_2 =
   { module_unparser, 11, 2 };
Const struct predicate predicate_unparser_xto__be__quoted_2F2_240_4 =
   { module_unparser, 12, 4 };
Const struct predicate predicate_unparser_xto__be__quoted_6 =
   { module_unparser, 13, 6 };
Const struct predicate predicate_unparser_xchar__kind_2 =
   { module_unparser, 14, 2 };
Const struct predicate predicate_unparser_xchar__kind_2F2_240_2 =
   { module_unparser, 15, 2 };
Const struct predicate predicate_unparser_xfirst__char__kind_2 =
   { module_unparser, 16, 2 };
Const struct predicate predicate_unparser_xfirst__char__kind_2F2_240_2 =
   { module_unparser, 17, 2 };
Const struct predicate predicate_unparser_xput__atom__string_4 =
   { module_unparser, 18, 4 };
Const struct predicate predicate_unparser_xput__atom__string_5 =
   { module_unparser, 19, 5 };
Const struct predicate predicate_unparser_xput__atom__element_3 =
   { module_unparser, 20, 3 };
Const struct predicate predicate_unparser_xput__string_5 =
   { module_unparser, 21, 5 };
Const struct predicate predicate_unparser_xput__string__element_3 =
   { module_unparser, 22, 3 };
Const struct predicate predicate_unparser_xputc0_3 =
   { module_unparser, 23, 3 };
Const struct predicate predicate_unparser_xput__int_3 =
   { module_unparser, 24, 3 };
Const struct predicate predicate_unparser_xput__int_2F3_240_3 =
   { module_unparser, 25, 3 };
Const struct predicate predicate_unparser_xput__float_3 =
   { module_unparser, 26, 3 };
Const struct predicate predicate_unparser_xis__operator_3 =
   { module_unparser, 27, 3 };
Const struct predicate predicate_unparser_xis__operator_2F3_240_5 =
   { module_unparser, 28, 5 };
Const struct predicate predicate_unparser_xis__operator_2F3_240_2F5_240_4 =
   { module_unparser, 29, 4 };
Const struct predicate predicate_unparser_xis__op_3 =
   { module_unparser, 30, 3 };
extern Const struct predicate predicate_atom__table_xget__atom__string_2;
extern Const struct predicate predicate_scanner_xchartype_2;

module module_unparser(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  q a0, a1, a2, a3, a4, a5;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, unparse_4_top);
    case_pred(1, unparse_2F4_240_4_top);
    case_pred(2, unparse__args_6_top);
    case_pred(3, unparse__vecargs_6_top);
    case_pred(4, unparse__cdr_4_top);
    case_pred(5, unwparse_4_top);
    case_pred(6, unwparse_2F4_240_4_top);
    case_pred(7, unwparse__args_6_top);
    case_pred(8, unwparse__vecargs_6_top);
    case_pred(9, unwparse__cdr_4_top);
    case_pred(10, unparse__atom_3_top);
    case_pred(11, to__be__quoted_2_top);
    case_pred(12, to__be__quoted_2F2_240_4_top);
    case_pred(13, to__be__quoted_6_top);
    case_pred(14, char__kind_2_top);
    case_pred(15, char__kind_2F2_240_2_top);
    case_pred(16, first__char__kind_2_top);
    case_pred(17, first__char__kind_2F2_240_2_top);
    case_pred(18, put__atom__string_4_top);
    case_pred(19, put__atom__string_5_top);
    case_pred(20, put__atom__element_3_top);
    case_pred(21, put__string_5_top);
    case_pred(22, put__string__element_3_top);
    case_pred(23, putc0_3_top);
    case_pred(24, put__int_3_top);
    case_pred(25, put__int_2F3_240_3_top);
    case_pred(26, put__float_3_top);
    case_pred(27, is__operator_3_top);
    case_pred(28, is__operator_2F3_240_5_top);
    case_pred(29, is__operator_2F3_240_2F5_240_4_top);
    last_case_pred(30, is__op_3_top);
  }

 unparse_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 unparse_4_clear_reason:
  reasonp = reasons;
 unparse_4_0:
 unparse_4_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = makeint(91L);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unparser_xunparse__cdr_4);
  x2 = cdr_of(a0);
  allocp[2] = x2;
  allocp[3] = a1;
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = a3;
  a0 = car_of(a0);
  a2 = x1;
  a3 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(unparse_4_0);
  goto unparse_4_ext_interrupt;
 case ATOMIC:
  if (isint(a0)) goto unparse_4_10;
 unparse_4_5:
  gblt_atom(a0,unparse_4_22);
 unparse_4_7:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_s_2)) goto unparse_4_22;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unparser_xunparse_2F4_240_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a2;
  allocp[4] = a0;
  allocp[5] = a3;
  a1 = arg(a1, 0);
  a2 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(is__operator_3_0);
  goto is__operator_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,unparse_4_7);
  *reasonp++ =  a1;
  goto unparse_4_22;
  };
  goto unparse_4_22;
 unparse_4_10:
  gblt_integer(a0,unparse_4_22);
  a1 = a2;
  a2 = a3;
  execute(put__int_3_0);
  goto put__int_3_ext_interrupt;
 case FUNCTOR:
 unparse_4_12:
  if (!isgobj(a0)) goto unparse_4_22;
  if (!isclass(a0,vector)) goto unparse_4_16;
  gblt_size_of_vector(a0,x0,unparse_4_16);
  bblt_sub_no_check(x0,makeint(1L),x1);
  allocp[0] = x3 = makeref(&allocp[0]);
  allocp[1] = makeint(123L);
  x2 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x2);
  allocp[0] = a3;
  allocp[1] = makeint(125L);
  x4 = makecons(&allocp[0]);
  a2 = a0;
  a3 = a1;
  a4 = x3;
  a5 = x4;
  a1 = x1;
  a0 = makeint(0L);
  allocp += 2;
  execute(unparse__vecargs_6_0);
  goto unparse__vecargs_6_ext_interrupt;
 unparse_4_16:
  guard_generic(a0, functor_float_0, 0, unparse_4_18);
  a1 = a2;
  a2 = a3;
  execute(put__float_3_0);
  goto put__float_3_ext_interrupt;
 unparse_4_18:
  gblt_is_string(a0,unparse_4_22);
  gblt_size_of_string(a0,x5,unparse_4_22);
  gblt_element_size_of_string(a0,x6,unparse_4_22);
  allocp[0] = x8 = makeref(&allocp[0]);
  allocp[1] = makeint(34L);
  x7 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x7);
  allocp[0] = a3;
  allocp[1] = makeint(34L);
  x9 = makecons(&allocp[0]);
  a1 = x5;
  a2 = a0;
  a3 = x8;
  a4 = x9;
  a0 = makeint(0L);
  allocp += 2;
  execute(put__string_5_0);
  goto put__string_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,unparse_4_1);
  *reasonp++ =  a0;
  goto unparse_4_22;
  };
  goto unparse_4_22;
 unparse_4_22:
  otherwise(unparse_4_interrupt);
 unparse_4_24:
  if (isref(a0)) goto unparse_4_29;
  gblt_pfunctor(a0,x0,unparse_4_interrupt);
  gblt_arity(a0,x1,unparse_4_interrupt);
  gblt_greater(x1,makeint(0L),unparse_4_interrupt);
  allocp[0] = a3;
  allocp[1] = makeint(41L);
  x2 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_unparser_xunparse__args_6);
  allocp[4] = makeint(1L);
  allocp[5] = x1;
  allocp[6] = a0;
  allocp[7] = a1;
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = x2;
  allocp[10] = x3;
  allocp[11] = makeint(40L);
  x4 = makecons(&allocp[10]);
  a0 = x0;
  a1 = a2;
  a2 = x4;
  qp = (struct goalrec*)&allocp[2];
  allocp += 12;
  execute(unparse__atom_3_0);
  goto unparse__atom_3_ext_interrupt;
 unparse_4_29:
  deref_and_jump(a0,unparse_4_24);
  *reasonp++ =  a0;
  goto unparse_4_interrupt;
 unparse_4_ext_interrupt:
  reasonp = 0l;
 unparse_4_interrupt:
  toppred = &predicate_unparser_xunparse_4;
  goto interrupt_4;
 }

 unparse_2F4_240_4_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 unparse_2F4_240_4_clear_reason:
  reasonp = reasons;
 unparse_2F4_240_4_0:
 unparse_2F4_240_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_yes)) goto unparse_2F4_240_4_5;
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = makeint(40L);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = a3;
  allocp[1] = makeint(41L);
  x2 = makecons(&allocp[0]);
  a0 = a2;
  a1 = x1;
  a2 = x2;
  allocp += 2;
  execute(unparse__atom_3_0);
  goto unparse__atom_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,unparse_2F4_240_4_1);
  *reasonp++ =  a0;
  goto unparse_2F4_240_4_interrupt;
  };
  goto unparse_2F4_240_4_5;
 unparse_2F4_240_4_5:
  gblt_diff(a0,makesym(atom_yes),unparse_2F4_240_4_interrupt);
  a0 = a2;
  a2 = a3;
  execute(unparse__atom_3_0);
  goto unparse__atom_3_ext_interrupt;
 unparse_2F4_240_4_ext_interrupt:
  reasonp = 0l;
 unparse_2F4_240_4_interrupt:
  goto interrupt_4;
 }

 unparse__args_6_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 unparse__args_6_clear_reason:
  reasonp = reasons;
 unparse__args_6_0:
 unparse__args_6_1:
  if (!isint(a0)) goto unparse__args_6_13;
 unparse__args_6_3:
  if (isref(a2)) goto unparse__args_6_12;
  gblt_arg(a0,a2,x0,unparse__args_6_interrupt);
 unparse__args_6_6:
  if (!isint(a1)) goto unparse__args_6_11;
  gblt_eq(a0,a1,unparse__args_6_9);
  a0 = x0;
  a1 = a3;
  a2 = a4;
  a3 = a5;
  execute(unparse_4_0);
  goto unparse_4_ext_interrupt;
 unparse__args_6_9:
  gblt_not_eq(a0,a1,unparse__args_6_interrupt);
  bblt_add_no_check(a0,makeint(1L),x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unparser_xunparse__args_6);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x2;
  allocp[9] = makeint(44L);
  x3 = makecons(&allocp[8]);
  a0 = x0;
  a1 = a3;
  a2 = a4;
  a3 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  execute(unparse_4_0);
  goto unparse_4_ext_interrupt;
 unparse__args_6_11:
  if (!isref(a1)) goto unparse__args_6_interrupt;
  deref_and_jump(a1,unparse__args_6_6);
  *reasonp++ =  a1;
  goto unparse__args_6_interrupt;
 unparse__args_6_12:
  deref_and_jump(a2,unparse__args_6_3);
  *reasonp++ =  a2;
  goto unparse__args_6_interrupt;
 unparse__args_6_13:
  if (!isref(a0)) goto unparse__args_6_interrupt;
  deref_and_jump(a0,unparse__args_6_1);
  *reasonp++ =  a0;
  goto unparse__args_6_interrupt;
 unparse__args_6_ext_interrupt:
  reasonp = 0l;
 unparse__args_6_interrupt:
  goto interrupt_6;
 }

 unparse__vecargs_6_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 unparse__vecargs_6_clear_reason:
  reasonp = reasons;
 unparse__vecargs_6_0:
 unparse__vecargs_6_1:
  if (!isint(a1)) goto unparse__vecargs_6_7;
 unparse__vecargs_6_3:
  if (!isint(a0)) goto unparse__vecargs_6_6;
  gblt_less(a1,a0,unparse__vecargs_6_8);
  unify(a5, a4);
  proceed();
 unparse__vecargs_6_6:
  if (!isref(a0)) goto unparse__vecargs_6_8;
  deref_and_jump(a0,unparse__vecargs_6_3);
  *reasonp++ =  a0;
  goto unparse__vecargs_6_8;
 unparse__vecargs_6_7:
  if (!isref(a1)) goto unparse__vecargs_6_8;
  deref_and_jump(a1,unparse__vecargs_6_1);
  *reasonp++ =  a1;
  goto unparse__vecargs_6_8;
 unparse__vecargs_6_8:
 unparse__vecargs_6_9:
  switch (ptagof(a2)) {
 case FUNCTOR:
 unparse__vecargs_6_10:
  if (!isgobj(a2)) goto unparse__vecargs_6_interrupt;
 unparse__vecargs_6_11:
 unparse__vecargs_6_12:
  if (isref(a0)) goto unparse__vecargs_6_24;
  generic_arg[0] = a0;
  guard_generic(a2, functor_element_2, 1, unparse__vecargs_6_interrupt);
  x0 = generic_arg[1];
 unparse__vecargs_6_15:
  if (!isint(a1)) goto unparse__vecargs_6_23;
 unparse__vecargs_6_17:
  if (!isint(a0)) goto unparse__vecargs_6_22;
  gblt_eq(a1,a0,unparse__vecargs_6_20);
  a0 = x0;
  a1 = a3;
  a2 = a4;
  a3 = a5;
  execute(unparse_4_clear_reason);
  goto unparse_4_ext_interrupt;
 unparse__vecargs_6_20:
  gblt_greater(a1,a0,unparse__vecargs_6_interrupt);
  bblt_add_no_check(a0,makeint(1L),x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unparser_xunparse__vecargs_6);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x2;
  allocp[9] = makeint(44L);
  x3 = makecons(&allocp[8]);
  a0 = x0;
  a1 = a3;
  a2 = a4;
  a3 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  execute(unparse_4_clear_reason);
  goto unparse_4_ext_interrupt;
 unparse__vecargs_6_22:
  if (!isref(a0)) goto unparse__vecargs_6_interrupt;
  deref_and_jump(a0,unparse__vecargs_6_17);
  *reasonp++ =  a0;
  goto unparse__vecargs_6_interrupt;
 unparse__vecargs_6_23:
  if (!isref(a1)) goto unparse__vecargs_6_interrupt;
  deref_and_jump(a1,unparse__vecargs_6_15);
  *reasonp++ =  a1;
  goto unparse__vecargs_6_interrupt;
 unparse__vecargs_6_24:
  deref_and_jump(a0,unparse__vecargs_6_12);
  *reasonp++ =  a0;
  goto unparse__vecargs_6_interrupt;
 case VARREF:
  deref_and_jump(a2,unparse__vecargs_6_9);
  *reasonp++ =  a2;
  goto unparse__vecargs_6_interrupt;
  };
  goto unparse__vecargs_6_interrupt;
 unparse__vecargs_6_ext_interrupt:
  reasonp = 0l;
 unparse__vecargs_6_interrupt:
  toppred = &predicate_unparser_xunparse__vecargs_6;
  goto interrupt_6;
 }

 unparse__cdr_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 unparse__cdr_4_clear_reason:
  reasonp = reasons;
 unparse__cdr_4_0:
 unparse__cdr_4_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = makeint(44L);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unparser_xunparse__cdr_4);
  x2 = cdr_of(a0);
  allocp[2] = x2;
  allocp[3] = a1;
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = a3;
  a0 = car_of(a0);
  a2 = x1;
  a3 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(unparse_4_0);
  goto unparse_4_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto unparse__cdr_4_6;
  allocp[0] = a3;
  allocp[1] = makeint(93L);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,unparse__cdr_4_1);
  *reasonp++ =  a0;
  goto unparse__cdr_4_6;
  };
  goto unparse__cdr_4_6;
 unparse__cdr_4_6:
  otherwise(unparse__cdr_4_interrupt);
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = makeint(124L);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  allocp[0] = a3;
  allocp[1] = makeint(93L);
  x2 = makecons(&allocp[0]);
  a2 = x1;
  a3 = x2;
  allocp += 2;
  execute(unparse_4_0);
  goto unparse_4_ext_interrupt;
 unparse__cdr_4_ext_interrupt:
  reasonp = 0l;
 unparse__cdr_4_interrupt:
  goto interrupt_4;
 }

 unwparse_4_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 unwparse_4_clear_reason:
  reasonp = reasons;
 unwparse_4_0:
 unwparse_4_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_atom_1:
 unwparse_4_4:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_s_2)) goto unwparse_4_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unparser_xunwparse_2F4_240_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a2;
  x1 = arg(a0, 0);
  allocp[4] = x1;
  allocp[5] = a3;
  a0 = x1;
  a1 = arg(a1, 0);
  a2 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(is__operator_3_0);
  goto is__operator_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,unwparse_4_4);
  *reasonp++ =  a1;
  goto unwparse_4_interrupt;
  };
  goto unwparse_4_interrupt;
 case functor_integer_1:
  a0 = arg(a0, 0);
  a1 = a2;
  a2 = a3;
  execute(put__int_3_0);
  goto put__int_3_ext_interrupt;
 case functor_floating__point_1:
  a0 = arg(a0, 0);
  a1 = a2;
  a2 = a3;
  execute(put__float_3_0);
  goto put__float_3_ext_interrupt;
 case functor_list_1:
  x0 = arg(a0, 0);
 unwparse_4_10:
  switch (ptagof(x0)) {
 case CONS:
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = makeint(91L);
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unparser_xunwparse__cdr_4);
  x3 = cdr_of(x0);
  allocp[2] = x3;
  allocp[3] = a1;
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = a3;
  a0 = car_of(x0);
  a2 = x2;
  a3 = x4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(unwparse_4_0);
  goto unwparse_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,unwparse_4_10);
  *reasonp++ =  x0;
  goto unwparse_4_interrupt;
  };
  goto unwparse_4_interrupt;
 case functor_functor_1:
  x0 = arg(a0, 0);
 unwparse_4_13:
  if (isref(x0)) goto unwparse_4_17;
  gblt_pfunctor(x0,x1,unwparse_4_interrupt);
  gblt_arity(x0,x2,unwparse_4_interrupt);
  allocp[0] = a3;
  allocp[1] = makeint(41L);
  x3 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_unparser_xunwparse__args_6);
  allocp[4] = makeint(1L);
  allocp[5] = x2;
  allocp[6] = x0;
  allocp[7] = a1;
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = x3;
  allocp[10] = x4;
  allocp[11] = makeint(40L);
  x5 = makecons(&allocp[10]);
  a0 = x1;
  a1 = a2;
  a2 = x5;
  qp = (struct goalrec*)&allocp[2];
  allocp += 12;
  execute(unparse__atom_3_0);
  goto unparse__atom_3_ext_interrupt;
 unwparse_4_17:
  deref_and_jump(x0,unwparse_4_13);
  *reasonp++ =  x0;
  goto unwparse_4_interrupt;
 case functor_vector_1:
  x0 = arg(a0, 0);
 unwparse_4_19:
  switch (ptagof(x0)) {
 case FUNCTOR:
 unwparse_4_20:
  if (!isgobj(x0)) goto unwparse_4_interrupt;
  if (!isclass(x0,vector)) goto unwparse_4_interrupt;
  gblt_size_of_vector(x0,x1,unwparse_4_interrupt);
  bblt_sub_no_check(x1,makeint(1L),x2);
  allocp[0] = x4 = makeref(&allocp[0]);
  allocp[1] = makeint(123L);
  x3 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x3);
  allocp[0] = a3;
  allocp[1] = makeint(125L);
  x5 = makecons(&allocp[0]);
  a0 = makeint(0L);
  a2 = x0;
  a3 = a1;
  a4 = x4;
  a5 = x5;
  a1 = x2;
  allocp += 2;
  execute(unwparse__vecargs_6_0);
  goto unwparse__vecargs_6_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,unwparse_4_19);
  *reasonp++ =  x0;
  goto unwparse_4_interrupt;
  };
  goto unwparse_4_interrupt;
 case functor_string_1:
  x0 = arg(a0, 0);
 unwparse_4_25:
  switch (ptagof(x0)) {
 case FUNCTOR:
 unwparse_4_26:
  if (!isgobj(x0)) goto unwparse_4_interrupt;
 unwparse_4_27:
  gblt_is_string(x0,unwparse_4_interrupt);
  gblt_size_of_string(x0,x1,unwparse_4_interrupt);
  gblt_element_size_of_string(x0,x2,unwparse_4_interrupt);
  allocp[0] = x4 = makeref(&allocp[0]);
  allocp[1] = makeint(34L);
  x3 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x3);
  allocp[0] = a3;
  allocp[1] = makeint(34L);
  x5 = makecons(&allocp[0]);
  a0 = makeint(0L);
  a1 = x1;
  a2 = x0;
  a3 = x4;
  a4 = x5;
  allocp += 2;
  execute(put__string_5_0);
  goto put__string_5_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,unwparse_4_25);
  *reasonp++ =  x0;
  goto unwparse_4_interrupt;
  };
  goto unwparse_4_interrupt;
 case functor_variable_1:
  x0 = arg(a0, 0);
 unwparse_4_32:
  switch (ptagof(x0)) {
 case FUNCTOR:
 unwparse_4_33:
  if (!isgobj(x0)) goto unwparse_4_interrupt;
 unwparse_4_34:
  gblt_is_string(x0,unwparse_4_interrupt);
  gblt_size_of_string(x0,x1,unwparse_4_interrupt);
  gblt_element_size_of_string(x0,x2,unwparse_4_interrupt);
  a0 = makeint(0L);
  a1 = x1;
  x3 = a2;
  a4 = a3;
  a3 = x3;
  a2 = x0;
  execute(put__string_5_0);
  goto put__string_5_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,unwparse_4_32);
  *reasonp++ =  x0;
  goto unwparse_4_interrupt;
  };
  goto unwparse_4_interrupt;
 default:
  goto unwparse_4_interrupt;
  };
 case VARREF:
  deref_and_jump(a0,unwparse_4_1);
  *reasonp++ =  a0;
  goto unwparse_4_interrupt;
  };
  goto unwparse_4_interrupt;
 unwparse_4_ext_interrupt:
  reasonp = 0l;
 unwparse_4_interrupt:
  toppred = &predicate_unparser_xunwparse_4;
  goto interrupt_4;
 }

 unwparse_2F4_240_4_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 unwparse_2F4_240_4_clear_reason:
  reasonp = reasons;
 unwparse_2F4_240_4_0:
 unwparse_2F4_240_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_yes)) goto unwparse_2F4_240_4_5;
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = makeint(40L);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = a3;
  allocp[1] = makeint(41L);
  x2 = makecons(&allocp[0]);
  a0 = a2;
  a1 = x1;
  a2 = x2;
  allocp += 2;
  execute(unparse__atom_3_0);
  goto unparse__atom_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,unwparse_2F4_240_4_1);
  *reasonp++ =  a0;
  goto unwparse_2F4_240_4_interrupt;
  };
  goto unwparse_2F4_240_4_5;
 unwparse_2F4_240_4_5:
  gblt_diff(a0,makesym(atom_yes),unwparse_2F4_240_4_interrupt);
  a0 = a2;
  a2 = a3;
  execute(unparse__atom_3_0);
  goto unparse__atom_3_ext_interrupt;
 unwparse_2F4_240_4_ext_interrupt:
  reasonp = 0l;
 unwparse_2F4_240_4_interrupt:
  goto interrupt_4;
 }

 unwparse__args_6_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 unwparse__args_6_clear_reason:
  reasonp = reasons;
 unwparse__args_6_0:
 unwparse__args_6_1:
  if (!isint(a0)) goto unwparse__args_6_13;
 unwparse__args_6_3:
  if (isref(a2)) goto unwparse__args_6_12;
  gblt_arg(a0,a2,x0,unwparse__args_6_interrupt);
 unwparse__args_6_6:
  if (!isint(a1)) goto unwparse__args_6_11;
  gblt_eq(a0,a1,unwparse__args_6_9);
  a0 = x0;
  a1 = a3;
  a2 = a4;
  a3 = a5;
  execute(unwparse_4_0);
  goto unwparse_4_ext_interrupt;
 unwparse__args_6_9:
  gblt_not_eq(a0,a1,unwparse__args_6_interrupt);
  bblt_add_no_check(a0,makeint(1L),x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unparser_xunwparse__args_6);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x2;
  allocp[9] = makeint(44L);
  x3 = makecons(&allocp[8]);
  a0 = x0;
  a1 = a3;
  a2 = a4;
  a3 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  execute(unwparse_4_0);
  goto unwparse_4_ext_interrupt;
 unwparse__args_6_11:
  if (!isref(a1)) goto unwparse__args_6_interrupt;
  deref_and_jump(a1,unwparse__args_6_6);
  *reasonp++ =  a1;
  goto unwparse__args_6_interrupt;
 unwparse__args_6_12:
  deref_and_jump(a2,unwparse__args_6_3);
  *reasonp++ =  a2;
  goto unwparse__args_6_interrupt;
 unwparse__args_6_13:
  if (!isref(a0)) goto unwparse__args_6_interrupt;
  deref_and_jump(a0,unwparse__args_6_1);
  *reasonp++ =  a0;
  goto unwparse__args_6_interrupt;
 unwparse__args_6_ext_interrupt:
  reasonp = 0l;
 unwparse__args_6_interrupt:
  goto interrupt_6;
 }

 unwparse__vecargs_6_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 unwparse__vecargs_6_clear_reason:
  reasonp = reasons;
 unwparse__vecargs_6_0:
 unwparse__vecargs_6_1:
  if (!isint(a1)) goto unwparse__vecargs_6_7;
 unwparse__vecargs_6_3:
  if (!isint(a0)) goto unwparse__vecargs_6_6;
  gblt_less(a1,a0,unwparse__vecargs_6_8);
  unify(a5, a4);
  proceed();
 unwparse__vecargs_6_6:
  if (!isref(a0)) goto unwparse__vecargs_6_8;
  deref_and_jump(a0,unwparse__vecargs_6_3);
  *reasonp++ =  a0;
  goto unwparse__vecargs_6_8;
 unwparse__vecargs_6_7:
  if (!isref(a1)) goto unwparse__vecargs_6_8;
  deref_and_jump(a1,unwparse__vecargs_6_1);
  *reasonp++ =  a1;
  goto unwparse__vecargs_6_8;
 unwparse__vecargs_6_8:
 unwparse__vecargs_6_9:
  switch (ptagof(a2)) {
 case FUNCTOR:
 unwparse__vecargs_6_10:
  if (!isgobj(a2)) goto unwparse__vecargs_6_interrupt;
 unwparse__vecargs_6_11:
 unwparse__vecargs_6_12:
  if (isref(a0)) goto unwparse__vecargs_6_24;
  generic_arg[0] = a0;
  guard_generic(a2, functor_element_2, 1, unwparse__vecargs_6_interrupt);
  x0 = generic_arg[1];
 unwparse__vecargs_6_15:
  if (!isint(a1)) goto unwparse__vecargs_6_23;
 unwparse__vecargs_6_17:
  if (!isint(a0)) goto unwparse__vecargs_6_22;
  gblt_eq(a1,a0,unwparse__vecargs_6_20);
  a0 = x0;
  a1 = a3;
  a2 = a4;
  a3 = a5;
  execute(unwparse_4_clear_reason);
  goto unwparse_4_ext_interrupt;
 unwparse__vecargs_6_20:
  gblt_greater(a1,a0,unwparse__vecargs_6_interrupt);
  bblt_add_no_check(a0,makeint(1L),x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unparser_xunwparse__vecargs_6);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x2;
  allocp[9] = makeint(44L);
  x3 = makecons(&allocp[8]);
  a0 = x0;
  a1 = a3;
  a2 = a4;
  a3 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  execute(unwparse_4_clear_reason);
  goto unwparse_4_ext_interrupt;
 unwparse__vecargs_6_22:
  if (!isref(a0)) goto unwparse__vecargs_6_interrupt;
  deref_and_jump(a0,unwparse__vecargs_6_17);
  *reasonp++ =  a0;
  goto unwparse__vecargs_6_interrupt;
 unwparse__vecargs_6_23:
  if (!isref(a1)) goto unwparse__vecargs_6_interrupt;
  deref_and_jump(a1,unwparse__vecargs_6_15);
  *reasonp++ =  a1;
  goto unwparse__vecargs_6_interrupt;
 unwparse__vecargs_6_24:
  deref_and_jump(a0,unwparse__vecargs_6_12);
  *reasonp++ =  a0;
  goto unwparse__vecargs_6_interrupt;
 case VARREF:
  deref_and_jump(a2,unwparse__vecargs_6_9);
  *reasonp++ =  a2;
  goto unwparse__vecargs_6_interrupt;
  };
  goto unwparse__vecargs_6_interrupt;
 unwparse__vecargs_6_ext_interrupt:
  reasonp = 0l;
 unwparse__vecargs_6_interrupt:
  toppred = &predicate_unparser_xunwparse__vecargs_6;
  goto interrupt_6;
 }

 unwparse__cdr_4_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 unwparse__cdr_4_clear_reason:
  reasonp = reasons;
 unwparse__cdr_4_0:
 unwparse__cdr_4_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_list_1:
  x0 = arg(a0, 0);
 unwparse__cdr_4_4:
  switch (ptagof(x0)) {
 case CONS:
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = makeint(44L);
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unparser_xunwparse__cdr_4);
  x3 = cdr_of(x0);
  allocp[2] = x3;
  allocp[3] = a1;
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = a3;
  a0 = car_of(x0);
  a2 = x2;
  a3 = x4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(unwparse_4_0);
  goto unwparse_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,unwparse__cdr_4_4);
  *reasonp++ =  x0;
  goto unwparse__cdr_4_11;
  };
  goto unwparse__cdr_4_11;
 case functor_atom_1:
  x0 = arg(a0, 0);
 unwparse__cdr_4_7:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != NILATOM) goto unwparse__cdr_4_11;
  allocp[0] = a3;
  allocp[1] = makeint(93L);
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x1);
  proceed();
 case VARREF:
  deref_and_jump(x0,unwparse__cdr_4_7);
  *reasonp++ =  x0;
  goto unwparse__cdr_4_11;
  };
  goto unwparse__cdr_4_11;
 default:
  goto unwparse__cdr_4_11;
  };
 case VARREF:
  deref_and_jump(a0,unwparse__cdr_4_1);
  *reasonp++ =  a0;
  goto unwparse__cdr_4_11;
  };
  goto unwparse__cdr_4_11;
 unwparse__cdr_4_11:
  otherwise(unwparse__cdr_4_interrupt);
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = makeint(124L);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  allocp[0] = a3;
  allocp[1] = makeint(93L);
  x2 = makecons(&allocp[0]);
  a2 = x1;
  a3 = x2;
  allocp += 2;
  execute(unwparse_4_0);
  goto unwparse_4_ext_interrupt;
 unwparse__cdr_4_ext_interrupt:
  reasonp = 0l;
 unwparse__cdr_4_interrupt:
  goto interrupt_4;
 }

 unparse__atom_3_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  qp = qp->next;
 unparse__atom_3_clear_reason:
  reasonp = reasons;
 unparse__atom_3_0:
 unparse__atom_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != NILATOM) goto unparse__atom_3_5;
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = makeint(91L);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = a2;
  allocp[1] = makeint(93L);
  x2 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(x1, x2);
  proceed();
 case VARREF:
  deref_and_jump(a0,unparse__atom_3_1);
  *reasonp++ =  a0;
  goto unparse__atom_3_5;
  };
  goto unparse__atom_3_5;
 unparse__atom_3_5:
  otherwise(unparse__atom_3_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unparser_xput__atom__string_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_unparser_xto__be__quoted_2);
  allocp[8] = x1;
  allocp[9] = x0;
  allocp[10] = (q)(struct goalrec*)&allocp[6];
  allocp[11] = (q)(&predicate_atom__table_xget__atom__string_2);
  allocp[12] = a0;
  allocp[13] = x1;
  qp = (struct goalrec*)&allocp[10];
  allocp += 14;
  proceed();
 unparse__atom_3_ext_interrupt:
  reasonp = 0l;
 unparse__atom_3_interrupt:
  toppred = &predicate_unparser_xunparse__atom_3;
  goto interrupt_3;
 }

 to__be__quoted_2_top: {
  q x0, x1, x2, x3;
  qp = qp->next;
 to__be__quoted_2_clear_reason:
  reasonp = reasons;
 to__be__quoted_2_0:
 to__be__quoted_2_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
 to__be__quoted_2_2:
  if (!isgobj(a0)) goto to__be__quoted_2_interrupt;
 to__be__quoted_2_3:
  gblt_is_string(a0,to__be__quoted_2_interrupt);
  gblt_size_of_string(a0,x0,to__be__quoted_2_interrupt);
  gblt_element_size_of_string(a0,x1,to__be__quoted_2_interrupt);
  gblt_eq(x0,makeint(0L),to__be__quoted_2_8);
  unify_value(a1, makesym(atom_yes));
  proceed();
 to__be__quoted_2_8:
  gblt_greater(x0,makeint(0L),to__be__quoted_2_interrupt);
  generic_arg[0] = makeint(0L);
  guard_generic(a0, functor_element_2, 1, to__be__quoted_2_interrupt);
  x2 = generic_arg[1];
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unparser_xto__be__quoted_2F2_240_4);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x0;
  allocp[5] = a0;
  a0 = x2;
  a1 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(first__char__kind_2_0);
  goto first__char__kind_2_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,to__be__quoted_2_1);
  *reasonp++ =  a0;
  goto to__be__quoted_2_interrupt;
  };
  goto to__be__quoted_2_interrupt;
 to__be__quoted_2_ext_interrupt:
  reasonp = 0l;
 to__be__quoted_2_interrupt:
  goto interrupt_2;
 }

 to__be__quoted_2F2_240_4_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 to__be__quoted_2F2_240_4_clear_reason:
  reasonp = reasons;
 to__be__quoted_2F2_240_4_0:
 to__be__quoted_2F2_240_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_quoted)) goto to__be__quoted_2F2_240_4_5;
  unify_value(a1, makesym(atom_yes));
  proceed();
 case VARREF:
  deref_and_jump(a0,to__be__quoted_2F2_240_4_1);
  *reasonp++ =  a0;
  goto to__be__quoted_2F2_240_4_interrupt;
  };
  goto to__be__quoted_2F2_240_4_5;
 to__be__quoted_2F2_240_4_5:
  gblt_diff(a0,makesym(atom_quoted),to__be__quoted_2F2_240_4_interrupt);
  x0 = a2;
  a2 = a3;
  a3 = a0;
  a4 = a0;
  a5 = a1;
  a1 = x0;
  a0 = makeint(0L);
  execute(to__be__quoted_6_0);
  goto to__be__quoted_6_ext_interrupt;
 to__be__quoted_2F2_240_4_ext_interrupt:
  reasonp = 0l;
 to__be__quoted_2F2_240_4_interrupt:
  goto interrupt_4;
 }

 to__be__quoted_6_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 to__be__quoted_6_clear_reason:
  reasonp = reasons;
 to__be__quoted_6_0:
 to__be__quoted_6_1:
  if (isref(a3)) goto to__be__quoted_6_35;
 to__be__quoted_6_3:
  if (isref(a4)) goto to__be__quoted_6_6;
  gblt_diff(a3,a4,to__be__quoted_6_7);
  unify_value(a5, makesym(atom_yes));
  proceed();
 to__be__quoted_6_6:
  deref_and_jump(a4,to__be__quoted_6_3);
  *reasonp++ =  a4;
  goto to__be__quoted_6_7;
 to__be__quoted_6_7:
 to__be__quoted_6_8:
  if (isref(a3)) goto to__be__quoted_6_34;
  if_not_equal(a3, a4, to__be__quoted_6_18);
 to__be__quoted_6_11:
  if (!isint(a0)) goto to__be__quoted_6_17;
 to__be__quoted_6_13:
  if (!isint(a1)) goto to__be__quoted_6_16;
  gblt_eq(a0,a1,to__be__quoted_6_18);
  unify_value(a5, makesym(atom_no));
  proceed();
 to__be__quoted_6_16:
  if (!isref(a1)) goto to__be__quoted_6_18;
  deref_and_jump(a1,to__be__quoted_6_13);
  *reasonp++ =  a1;
  goto to__be__quoted_6_18;
 to__be__quoted_6_17:
  if (!isref(a0)) goto to__be__quoted_6_18;
  deref_and_jump(a0,to__be__quoted_6_11);
  *reasonp++ =  a0;
  goto to__be__quoted_6_18;
 to__be__quoted_6_18:
 to__be__quoted_6_19:
  if (isref(a3)) goto to__be__quoted_6_33;
  if_not_equal(a3, a4, to__be__quoted_6_interrupt);
 to__be__quoted_6_22:
  if (!isint(a0)) goto to__be__quoted_6_32;
 to__be__quoted_6_24:
  if (!isint(a1)) goto to__be__quoted_6_31;
  gblt_less(a0,a1,to__be__quoted_6_interrupt);
 to__be__quoted_6_27:
  switch (ptagof(a2)) {
 case FUNCTOR:
 to__be__quoted_6_28:
  if (!isgobj(a2)) goto to__be__quoted_6_interrupt;
 to__be__quoted_6_29:
  generic_arg[0] = a0;
  guard_generic(a2, functor_element_2, 1, to__be__quoted_6_interrupt);
  x0 = generic_arg[1];
  bblt_add_no_check(a0,makeint(1L),x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unparser_xto__be__quoted_6);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  a0 = x0;
  a1 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  execute(char__kind_2_clear_reason);
  goto char__kind_2_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,to__be__quoted_6_27);
  *reasonp++ =  a2;
  goto to__be__quoted_6_interrupt;
  };
  goto to__be__quoted_6_interrupt;
 to__be__quoted_6_31:
  if (!isref(a1)) goto to__be__quoted_6_interrupt;
  deref_and_jump(a1,to__be__quoted_6_24);
  *reasonp++ =  a1;
  goto to__be__quoted_6_interrupt;
 to__be__quoted_6_32:
  if (!isref(a0)) goto to__be__quoted_6_interrupt;
  deref_and_jump(a0,to__be__quoted_6_22);
  *reasonp++ =  a0;
  goto to__be__quoted_6_interrupt;
 to__be__quoted_6_33:
  deref_and_jump(a3,to__be__quoted_6_19);
  *reasonp++ =  a3;
  goto to__be__quoted_6_interrupt;
 to__be__quoted_6_34:
  deref_and_jump(a3,to__be__quoted_6_8);
  *reasonp++ =  a3;
  goto to__be__quoted_6_interrupt;
 to__be__quoted_6_35:
  deref_and_jump(a3,to__be__quoted_6_1);
  *reasonp++ =  a3;
  goto to__be__quoted_6_interrupt;
 to__be__quoted_6_ext_interrupt:
  reasonp = 0l;
 to__be__quoted_6_interrupt:
  toppred = &predicate_unparser_xto__be__quoted_6;
  goto interrupt_6;
 }

 char__kind_2_top: {
  q x0;
  qp = qp->next;
 char__kind_2_clear_reason:
  reasonp = reasons;
 char__kind_2_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unparser_xchar__kind_2F2_240_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_scanner_xchartype_2);
  allocp[6] = a0;
  allocp[7] = x0;
  qp = (struct goalrec*)&allocp[4];
  allocp += 8;
  proceed();
 char__kind_2_ext_interrupt:
  reasonp = 0l;
 char__kind_2_interrupt:
  toppred = &predicate_unparser_xchar__kind_2;
  goto interrupt_2;
 }

 char__kind_2F2_240_2_top: {
  qp = qp->next;
 char__kind_2F2_240_2_clear_reason:
  reasonp = reasons;
 char__kind_2F2_240_2_0:
 char__kind_2F2_240_2_1:
  if (!isint(a0)) goto char__kind_2F2_240_2_8;
  gblt_less_or_eq(a0,makeint(3L),char__kind_2F2_240_2_4);
  unify_value(a1, makesym(atom_alnum));
  proceed();
 char__kind_2F2_240_2_4:
  gblt_eq(a0,makeint(4L),char__kind_2F2_240_2_6);
  unify_value(a1, makesym(atom_symbol));
  proceed();
 char__kind_2F2_240_2_6:
  gblt_greater_or_eq(a0,makeint(5L),char__kind_2F2_240_2_interrupt);
  unify_value(a1, makesym(atom_quoted));
  proceed();
 char__kind_2F2_240_2_8:
  if (!isref(a0)) goto char__kind_2F2_240_2_interrupt;
  deref_and_jump(a0,char__kind_2F2_240_2_1);
  *reasonp++ =  a0;
  goto char__kind_2F2_240_2_interrupt;
 char__kind_2F2_240_2_ext_interrupt:
  reasonp = 0l;
 char__kind_2F2_240_2_interrupt:
  goto interrupt_2;
 }

 first__char__kind_2_top: {
  q x0;
  qp = qp->next;
 first__char__kind_2_clear_reason:
  reasonp = reasons;
 first__char__kind_2_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unparser_xfirst__char__kind_2F2_240_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_scanner_xchartype_2);
  allocp[6] = a0;
  allocp[7] = x0;
  qp = (struct goalrec*)&allocp[4];
  allocp += 8;
  proceed();
 first__char__kind_2_ext_interrupt:
  reasonp = 0l;
 first__char__kind_2_interrupt:
  toppred = &predicate_unparser_xfirst__char__kind_2;
  goto interrupt_2;
 }

 first__char__kind_2F2_240_2_top: {
  qp = qp->next;
 first__char__kind_2F2_240_2_clear_reason:
  reasonp = reasons;
 first__char__kind_2F2_240_2_0:
 first__char__kind_2F2_240_2_1:
  if (!isint(a0)) goto first__char__kind_2F2_240_2_6;
  gblt_eq(a0,makeint(0L),first__char__kind_2F2_240_2_4);
  unify_value(a1, makesym(atom_alnum));
  proceed();
 first__char__kind_2F2_240_2_4:
  gblt_eq(a0,makeint(4L),first__char__kind_2F2_240_2_7);
  unify_value(a1, makesym(atom_symbol));
  proceed();
 first__char__kind_2F2_240_2_6:
  if (!isref(a0)) goto first__char__kind_2F2_240_2_7;
  deref_and_jump(a0,first__char__kind_2F2_240_2_1);
  *reasonp++ =  a0;
  goto first__char__kind_2F2_240_2_7;
 first__char__kind_2F2_240_2_7:
  otherwise(first__char__kind_2F2_240_2_interrupt);
  unify_value(a1, makesym(atom_quoted));
  proceed();
 first__char__kind_2F2_240_2_ext_interrupt:
  reasonp = 0l;
 first__char__kind_2F2_240_2_interrupt:
  goto interrupt_2;
 }

 put__atom__string_4_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 put__atom__string_4_clear_reason:
  reasonp = reasons;
 put__atom__string_4_0:
 put__atom__string_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto put__atom__string_4_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_no)):
  allocp[0] = makesym(functor_fwrite_1);
  allocp[1] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = a3;
  allocp[3] = x0;
  x1 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a2, x1);
  proceed();
 case symval(makesym(atom_yes)):
 put__atom__string_4_6:
  switch (ptagof(a1)) {
 case FUNCTOR:
 put__atom__string_4_7:
  if (!isgobj(a1)) goto put__atom__string_4_interrupt;
 put__atom__string_4_8:
  gblt_is_string(a1,put__atom__string_4_interrupt);
  gblt_size_of_string(a1,x0,put__atom__string_4_interrupt);
  gblt_element_size_of_string(a1,x1,put__atom__string_4_interrupt);
  allocp[0] = x3 = makeref(&allocp[0]);
  allocp[1] = makeint(39L);
  x2 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x2);
  allocp[0] = a3;
  allocp[1] = makeint(39L);
  x4 = makecons(&allocp[0]);
  a0 = makeint(0L);
  a2 = a1;
  a3 = x3;
  a4 = x4;
  a1 = x0;
  allocp += 2;
  execute(put__atom__string_5_0);
  goto put__atom__string_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,put__atom__string_4_6);
  *reasonp++ =  a1;
  goto put__atom__string_4_interrupt;
  };
  goto put__atom__string_4_interrupt;
 default:
  goto put__atom__string_4_interrupt;
  };
 case VARREF:
  deref_and_jump(a0,put__atom__string_4_1);
  *reasonp++ =  a0;
  goto put__atom__string_4_interrupt;
  };
  goto put__atom__string_4_interrupt;
 put__atom__string_4_ext_interrupt:
  reasonp = 0l;
 put__atom__string_4_interrupt:
  goto interrupt_4;
 }

 put__atom__string_5_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 put__atom__string_5_clear_reason:
  reasonp = reasons;
 put__atom__string_5_0:
 put__atom__string_5_1:
  if (!isint(a0)) goto put__atom__string_5_13;
 put__atom__string_5_3:
  if (!isint(a1)) goto put__atom__string_5_12;
  gblt_eq(a0,a1,put__atom__string_5_6);
  unify(a4, a3);
  proceed();
 put__atom__string_5_6:
  gblt_not_eq(a0,a1,put__atom__string_5_interrupt);
 put__atom__string_5_8:
  switch (ptagof(a2)) {
 case FUNCTOR:
 put__atom__string_5_9:
  if (!isgobj(a2)) goto put__atom__string_5_interrupt;
 put__atom__string_5_10:
  generic_arg[0] = a0;
  guard_generic(a2, functor_element_2, 1, put__atom__string_5_interrupt);
  x0 = generic_arg[1];
  bblt_add_no_check(a0,makeint(1L),x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unparser_xput__atom__string_5);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  a0 = x0;
  a1 = a3;
  a2 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(put__atom__element_3_0);
  goto put__atom__element_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,put__atom__string_5_8);
  *reasonp++ =  a2;
  goto put__atom__string_5_interrupt;
  };
  goto put__atom__string_5_interrupt;
 put__atom__string_5_12:
  if (!isref(a1)) goto put__atom__string_5_interrupt;
  deref_and_jump(a1,put__atom__string_5_3);
  *reasonp++ =  a1;
  goto put__atom__string_5_interrupt;
 put__atom__string_5_13:
  if (!isref(a0)) goto put__atom__string_5_interrupt;
  deref_and_jump(a0,put__atom__string_5_1);
  *reasonp++ =  a0;
  goto put__atom__string_5_interrupt;
 put__atom__string_5_ext_interrupt:
  reasonp = 0l;
 put__atom__string_5_interrupt:
  toppred = &predicate_unparser_xput__atom__string_5;
  goto interrupt_5;
 }

 put__atom__element_3_top: {
  q x0;
  a2 = qp->args[2];
  qp = qp->next;
 put__atom__element_3_clear_reason:
  reasonp = reasons;
 put__atom__element_3_0:
 put__atom__element_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 put__atom__element_3_3:
  if (a0 != makeint(39L)) goto put__atom__element_3_5;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unparser_xputc0_3);
  allocp[2] = makeint(39L);
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a2;
  a0 = makeint(39L);
  a2 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(putc0_3_0);
  goto putc0_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,put__atom__element_3_1);
  *reasonp++ =  a0;
  goto put__atom__element_3_5;
  };
  goto put__atom__element_3_5;
 put__atom__element_3_5:
  otherwise(put__atom__element_3_interrupt);
  execute(putc0_3_0);
  goto putc0_3_ext_interrupt;
 put__atom__element_3_ext_interrupt:
  reasonp = 0l;
 put__atom__element_3_interrupt:
  toppred = &predicate_unparser_xput__atom__element_3;
  goto interrupt_3;
 }

 put__string_5_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 put__string_5_clear_reason:
  reasonp = reasons;
 put__string_5_0:
 put__string_5_1:
  if (!isint(a0)) goto put__string_5_13;
 put__string_5_3:
  if (!isint(a1)) goto put__string_5_12;
  gblt_eq(a0,a1,put__string_5_6);
  unify(a4, a3);
  proceed();
 put__string_5_6:
  gblt_not_eq(a0,a1,put__string_5_interrupt);
 put__string_5_8:
  switch (ptagof(a2)) {
 case FUNCTOR:
 put__string_5_9:
  if (!isgobj(a2)) goto put__string_5_interrupt;
 put__string_5_10:
  generic_arg[0] = a0;
  guard_generic(a2, functor_element_2, 1, put__string_5_interrupt);
  x0 = generic_arg[1];
  bblt_add_no_check(a0,makeint(1L),x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unparser_xput__string_5);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  a0 = x0;
  a1 = a3;
  a2 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(put__string__element_3_0);
  goto put__string__element_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,put__string_5_8);
  *reasonp++ =  a2;
  goto put__string_5_interrupt;
  };
  goto put__string_5_interrupt;
 put__string_5_12:
  if (!isref(a1)) goto put__string_5_interrupt;
  deref_and_jump(a1,put__string_5_3);
  *reasonp++ =  a1;
  goto put__string_5_interrupt;
 put__string_5_13:
  if (!isref(a0)) goto put__string_5_interrupt;
  deref_and_jump(a0,put__string_5_1);
  *reasonp++ =  a0;
  goto put__string_5_interrupt;
 put__string_5_ext_interrupt:
  reasonp = 0l;
 put__string_5_interrupt:
  toppred = &predicate_unparser_xput__string_5;
  goto interrupt_5;
 }

 put__string__element_3_top: {
  q x0;
  a2 = qp->args[2];
  qp = qp->next;
 put__string__element_3_clear_reason:
  reasonp = reasons;
 put__string__element_3_0:
 put__string__element_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 put__string__element_3_3:
  if (a0 != makeint(34L)) goto put__string__element_3_5;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unparser_xputc0_3);
  allocp[2] = makeint(34L);
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a2;
  a0 = makeint(34L);
  a2 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(putc0_3_0);
  goto putc0_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,put__string__element_3_1);
  *reasonp++ =  a0;
  goto put__string__element_3_5;
  };
  goto put__string__element_3_5;
 put__string__element_3_5:
  otherwise(put__string__element_3_interrupt);
  execute(putc0_3_0);
  goto putc0_3_ext_interrupt;
 put__string__element_3_ext_interrupt:
  reasonp = 0l;
 put__string__element_3_interrupt:
  toppred = &predicate_unparser_xput__string__element_3;
  goto interrupt_3;
 }

 putc0_3_top: {
  q x0;
  a2 = qp->args[2];
  qp = qp->next;
 putc0_3_clear_reason:
  reasonp = reasons;
 putc0_3_0:
  allocp[0] = a2;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  proceed();
 putc0_3_ext_interrupt:
  reasonp = 0l;
 putc0_3_interrupt:
  toppred = &predicate_unparser_xputc0_3;
  goto interrupt_3;
 }

 put__int_3_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  qp = qp->next;
 put__int_3_clear_reason:
  reasonp = reasons;
 put__int_3_0:
 put__int_3_1:
  if (!isint(a0)) goto put__int_3_9;
  gblt_greater_or_eq(a0,makeint(0L),put__int_3_5);
  gblt_less(a0,makeint(10L),put__int_3_5);
  bblt_add_no_check(makeint(48L),a0,x0);
  allocp[0] = a2;
  allocp[1] = x0;
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x1);
  proceed();
 put__int_3_5:
  gblt_greater_or_eq(a0,makeint(10L),put__int_3_7);
  bblt_mod_no_check(a0,makeint(10L),x0);
  bblt_add_no_check(makeint(48L),x0,x1);
  bblt_div_no_check(a0,makeint(10L),x2);
  allocp[0] = a2;
  allocp[1] = x1;
  x3 = makecons(&allocp[0]);
  a0 = x2;
  a2 = x3;
  allocp += 2;
  execute(put__int_3_0);
  goto put__int_3_ext_interrupt;
 put__int_3_7:
  gblt_less(a0,makeint(0L),put__int_3_interrupt);
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = makeint(45L);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a1 = x1;
  execute(put__int_2F3_240_3_0);
  goto put__int_2F3_240_3_ext_interrupt;
 put__int_3_9:
  if (!isref(a0)) goto put__int_3_interrupt;
  deref_and_jump(a0,put__int_3_1);
  *reasonp++ =  a0;
  goto put__int_3_interrupt;
 put__int_3_ext_interrupt:
  reasonp = 0l;
 put__int_3_interrupt:
  toppred = &predicate_unparser_xput__int_3;
  goto interrupt_3;
 }

 put__int_2F3_240_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  qp = qp->next;
 put__int_2F3_240_3_clear_reason:
  reasonp = reasons;
 put__int_2F3_240_3_0:
 put__int_2F3_240_3_1:
  if (!isint(a0)) goto put__int_2F3_240_3_7;
  gblt_minus(a0,x0,put__int_2F3_240_3_interrupt);
  gblt_eq(a0,x0,put__int_2F3_240_3_5);
  bblt_div_no_check(a0,makeint(10L),x1);
  bblt_minus_no_check(x1,x2);
  bblt_mult_no_check(x2,makeint(10L),x3);
  bblt_add_no_check(a0,x3,x4);
  bblt_minus_no_check(x4,x5);
  bblt_add_no_check(makeint(48L),x5,x6);
  allocp[0] = a2;
  allocp[1] = x6;
  x7 = makecons(&allocp[0]);
  a0 = x2;
  a2 = x7;
  allocp += 2;
  execute(put__int_3_0);
  goto put__int_3_ext_interrupt;
 put__int_2F3_240_3_5:
  gblt_not_eq(a0,x0,put__int_2F3_240_3_interrupt);
  bblt_minus_no_check(a0,x1);
  a0 = x1;
  execute(put__int_3_0);
  goto put__int_3_ext_interrupt;
 put__int_2F3_240_3_7:
  if (!isref(a0)) goto put__int_2F3_240_3_interrupt;
  deref_and_jump(a0,put__int_2F3_240_3_1);
  *reasonp++ =  a0;
  goto put__int_2F3_240_3_interrupt;
 put__int_2F3_240_3_ext_interrupt:
  reasonp = 0l;
 put__int_2F3_240_3_interrupt:
  toppred = &predicate_unparser_xput__int_2F3_240_3;
  goto interrupt_3;
 }

 put__float_3_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  qp = qp->next;
 put__float_3_clear_reason:
  reasonp = reasons;
 put__float_3_0:
  allocp[0] = x0 = makeref(&allocp[0]);
  generic_arg[0] = x0;
  call_generic(a0, functor_print_1, 1);
  allocp[0] = makesym(functor_fwrite_2);
  allocp[1] = x0;
  allocp[2] = x2 = makeref(&allocp[2]);
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a2;
  allocp[4] = x1;
  x3 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a1, x3);
  proceed();
 put__float_3_ext_interrupt:
  reasonp = 0l;
 put__float_3_interrupt:
  toppred = &predicate_unparser_xput__float_3;
  goto interrupt_3;
 }

 is__operator_3_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  qp = qp->next;
 is__operator_3_clear_reason:
  reasonp = reasons;
 is__operator_3_0:
 is__operator_3_1:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_ops_3)) goto is__operator_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unparser_xis__operator_2F3_240_5);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a2;
  x1 = arg(a1, 1);
  allocp[4] = x1;
  allocp[5] = a0;
  x2 = arg(a1, 2);
  allocp[6] = x2;
  x3 = arg(a1, 0);
  a1 = a0;
  a2 = x0;
  a0 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(is__op_3_0);
  goto is__op_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,is__operator_3_1);
  *reasonp++ =  a1;
  goto is__operator_3_interrupt;
  };
  goto is__operator_3_interrupt;
 is__operator_3_ext_interrupt:
  reasonp = 0l;
 is__operator_3_interrupt:
  toppred = &predicate_unparser_xis__operator_3;
  goto interrupt_3;
 }

 is__operator_2F3_240_5_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 is__operator_2F3_240_5_clear_reason:
  reasonp = reasons;
 is__operator_2F3_240_5_0:
 is__operator_2F3_240_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_yes)) goto is__operator_2F3_240_5_5;
  unify_value(a1, makesym(atom_yes));
  proceed();
 case VARREF:
  deref_and_jump(a0,is__operator_2F3_240_5_1);
  *reasonp++ =  a0;
  goto is__operator_2F3_240_5_5;
  };
  goto is__operator_2F3_240_5_5;
 is__operator_2F3_240_5_5:
  otherwise(is__operator_2F3_240_5_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_unparser_xis__operator_2F3_240_2F5_240_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a4;
  allocp[5] = a3;
  a0 = a2;
  a1 = a3;
  a2 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(is__op_3_0);
  goto is__op_3_ext_interrupt;
 is__operator_2F3_240_5_ext_interrupt:
  reasonp = 0l;
 is__operator_2F3_240_5_interrupt:
  goto interrupt_5;
 }

 is__operator_2F3_240_2F5_240_4_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 is__operator_2F3_240_2F5_240_4_clear_reason:
  reasonp = reasons;
 is__operator_2F3_240_2F5_240_4_0:
 is__operator_2F3_240_2F5_240_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_yes)) goto is__operator_2F3_240_2F5_240_4_5;
  unify_value(a1, makesym(atom_yes));
  proceed();
 case VARREF:
  deref_and_jump(a0,is__operator_2F3_240_2F5_240_4_1);
  *reasonp++ =  a0;
  goto is__operator_2F3_240_2F5_240_4_5;
  };
  goto is__operator_2F3_240_2F5_240_4_5;
 is__operator_2F3_240_2F5_240_4_5:
  otherwise(is__operator_2F3_240_2F5_240_4_interrupt);
  a0 = a2;
  x0 = a3;
  a2 = a1;
  a1 = x0;
  execute(is__op_3_0);
  goto is__op_3_ext_interrupt;
 is__operator_2F3_240_2F5_240_4_ext_interrupt:
  reasonp = 0l;
 is__operator_2F3_240_2F5_240_4_interrupt:
  goto interrupt_4;
 }

 is__op_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 is__op_3_clear_reason:
  reasonp = reasons;
 is__op_3_0:
 is__op_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 is__op_3_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_op_3)) goto is__op_3_interrupt;
  x1 = arg(x0, 0);
 is__op_3_6:
  if (isref(x1)) goto is__op_3_17;
 is__op_3_8:
  if (isref(x1)) goto is__op_3_11;
  if_not_equal(x1, a1, is__op_3_12);
  unify_value(a2, makesym(atom_yes));
  proceed();
 is__op_3_11:
  deref_and_jump(x1,is__op_3_8);
  *reasonp++ =  x1;
  goto is__op_3_12;
 is__op_3_12:
 is__op_3_13:
  if (isref(a1)) goto is__op_3_16;
  gblt_diff(x1,a1,is__op_3_interrupt);
  a0 = cdr_of(a0);
  execute(is__op_3_clear_reason);
  goto is__op_3_ext_interrupt;
 is__op_3_16:
  deref_and_jump(a1,is__op_3_13);
  *reasonp++ =  a1;
  goto is__op_3_interrupt;
 is__op_3_17:
  deref_and_jump(x1,is__op_3_6);
  *reasonp++ =  x1;
  goto is__op_3_interrupt;
 case VARREF:
  deref_and_jump(x0,is__op_3_3);
  *reasonp++ =  x0;
  goto is__op_3_interrupt;
  };
  goto is__op_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto is__op_3_interrupt;
  unify_value(a2, makesym(atom_no));
  proceed();
 case VARREF:
  deref_and_jump(a0,is__op_3_1);
  *reasonp++ =  a0;
  goto is__op_3_interrupt;
  };
  goto is__op_3_interrupt;
 is__op_3_ext_interrupt:
  reasonp = 0l;
 is__op_3_interrupt:
  toppred = &predicate_unparser_xis__op_3;
  goto interrupt_3;
 }
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_unparser);
}
