/* ---------------------------------------------------------- 
%   (C)1993 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
#include <stdio.h>
#include <setjmp.h>
#include <ctype.h>
#include <klic/basic.h>
#include <klic/struct.h>
#include <klic/primitives.h>
#include <klic/unify.h>
#include <klic/index.h>
#include <klic/atomstuffs.h>
#include <klic/functorstuffs.h>

#ifdef DIST
#include <klic/traceio.h>
#include <klic/interpe.h>
#endif

extern struct predicate topsucceed_pred;
extern jmp_buf klic_topmost;

Volatile fatal(message)
     char *message;
{
  declare_globals;
#ifdef DIST
  sprintf(iobuf, "Fatal Error: %s\n", message);
  SystemPrint(iobuf);

    sprintf(iobuf, "Node %d Going to dump core\n", my_node);
    SystemPrint(iobuf);
  {
    ERROR_STOP;
  }
  DetachIO;
  EmergencyStop;
#else
  fprintf(stderr, "Fatal Error: %s\n", message);
#endif
  if (postmortem_pred !=0 && postmortem_args !=0) {
    longjmp(klic_topmost, 1);
  }
#ifdef DIST
  pvm_exit();
#endif
  exit(-1);
}

Volatile fatalf(format, a0, a1, a2, a3, a4, a5, a6, a7)
     char *format;
     int a0, a1, a2, a3, a4, a5, a6, a7;
{
  char buf[4096];
  (void) sprintf(buf, format, a0, a1, a2, a3, a4, a5, a6, a7);
  fatal(buf);
}

Volatile fatalp(where, format, a0, a1, a2, a3, a4, a5, a6, a7)
     char *where, *format;
     int a0, a1, a2, a3, a4, a5, a6, a7;
{
  perror(where);
  fatalf(format, a0, a1, a2, a3, a4, a5, a6, a7);
}

#ifdef DIST

Volatile fatal_d(iodp,message)
     int iodp;
     char *message;
{
  declare_globals;
  sprintf(iobuf, "Fatal Error: %s\n", message);
  if (iodp) {
    SystemPrint(iobuf);
  } else { fprintf(stderr,"%s",iobuf); }
  sprintf(iobuf, "Node %d Going to dump core\n", my_node);
  if (iodp) {
    SystemPrint(iobuf);
  } else { fprintf(stderr,"%s",iobuf); }
  {
    for(;;);
  }
  if (iodp) {
    DetachIO;
    EmergencyStop;
  } 
  if (postmortem_pred !=0 && postmortem_args !=0) {
    longjmp(klic_topmost, 1);
  }
  if (iodp) { pvm_exit(); }
  exit(-1);
}

Volatile fatalf_d(iodp,format, a0, a1, a2, a3, a4, a5, a6, a7)
     int iodp;
     char *format;
     int a0, a1, a2, a3, a4, a5, a6, a7;
{
  char buf[4096];
  (void) sprintf(buf, format, a0, a1, a2, a3, a4, a5, a6, a7);
  fatal_d(iodp,buf);
}

Volatile fatalp_d(iodp,where, format, a0, a1, a2, a3, a4, a5, a6, a7)
     int iodp;
     char *where, *format;
     int a0, a1, a2, a3, a4, a5, a6, a7;
{
  perror(where);
  fatalf(iodp, format, a0, a1, a2, a3, a4, a5, a6, a7);
}

#endif

void debug_printf(format, a0, a1, a2, a3, a4, a5, a6, a7)
     char *format;
     long a0, a1, a2, a3, a4, a5, a6, a7;
{
  char *f;
  char buf[4096];
  long args[8], *argp;
  args[0] = a0; args[1] = a1; args[2] = a2; args[3] = a3;
  args[4] = a4; args[5] = a5; args[6] = a6; args[7] = a7;
  argp = &args[0];
  for (f = format; *f != '\0'; f++) {
    if (*f == '%') {
      f++;
      switch (*f) {
      case 'k':
#ifdef DIST
	SystemPrint("???");
#else
#ifdef DEBUGLIB
	fprint_partially(stderr, (q)*argp++, 3, 10);
#else
	fprintf(stderr, "???");
#endif
#endif
	break;
      case 'F':
#ifdef DEBUGLIB
#ifdef DIST
	sprintf(buf, "%s",
		atomname[functors[*argp-FUNCTORNUMBERBASE]-ATOMNUMBERBASE]);
	SystemPrint(buf);
#else
	fprintf(stderr, "%s",
		atomname[functors[*argp-FUNCTORNUMBERBASE]-ATOMNUMBERBASE]);
#endif
#else
#ifdef DIST
	SystemPrint("???");
#else
	fprintf(stderr, "???");
#endif
#endif
#ifdef DIST
	sprintf(buf, "/%d",
		arities[*argp++ -FUNCTORNUMBERBASE]);
	SystemPrint(buf);
#else
	fprintf(stderr, "/%d",
		arities[*argp++ -FUNCTORNUMBERBASE]);
#endif
	break;
      default:
	{
	  int k;
	  char fmtbuf[1024];
	  fmtbuf[0] = '%';
	  k=1;
	  while (!isalpha(*f) && *f != 0 && k<1024) {
	    fmtbuf[k++] = *f++;
	  }
	  if (k>=1024) fatal("Too complicated format string for debug_printf");
	  fmtbuf[k] = 0;
#ifdef DIST
	  sprintf(buf, fmtbuf, *argp++);
	  SystemPrint(buf);
#else
	  fprintf(stderr, fmtbuf, *argp++);
#endif
	}
      }
    } else {
#ifdef DIST
      buf[0] = *f;
      buf[1] = '\0';
      SystemPrint(buf);
#else
      putc(*f, stderr);
#endif
    }
  }
}
