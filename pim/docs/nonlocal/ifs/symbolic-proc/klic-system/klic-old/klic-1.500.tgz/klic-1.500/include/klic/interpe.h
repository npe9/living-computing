
/*#define INT_CL_DEBUG*/
#define INT_CL_PROBE

/* Constants */
#define MAX_BUF_SIZE 0x10000
#define MAX_PROC_NUM 0x20

#define EXPORT_UNIT_WEC 0x10000
#define MIN_WEC 0x2
/*#define EXP_TABLE_SIZE 0x10000*/
#define EXP_TABLE_INC_SIZE 0x1000
#define IMP_TABLE_INC_SIZE 0x1000

#define EXP_TABLE_HASH_SIZE 0x1

#define SEQ_NODE -1
/*#define MAX_PE 0xff*/
#define MASTER_NODE 0
/* #define SHOEN_NODE 0xf */
#define SHOEN_NODE total_node

#define END_EXP_FREELIST 0xffffffff
#define END_IMP_FREELIST 0xffffffff
#define END_IMP_TABLE    0xffffffff

#define dist_exec   (my_node != SEQ_NODE)
#define master_node (my_node == MASTER_NODE)
#define shoen_node  (my_node == SHOEN_NODE)

#define IMPREC_NOT_COPIED 12345
#define IMPREC_COPIED     54321
#define IMPREC_RELEASED   98765

#define DECODE_MAX_OBJ_SIZE   15

Extern long shoen_flag;
Extern long shoen_tid;
Extern long shoen_pe;

/* TID table */

Extern int tid_tbl[MAX_PROC_NUM]; 

#define tid_of(x) tid_tbl[x]

/* WTC etc. */

Extern long shoen_wtc;
Extern long node_wtc;

#define SUPPLY_WTC_UNIT        0x1000000
#define THROW_WTC_UNIT         0x1000
#define UNIFY_WTC_UNIT         0x10
#define CONTROL_WTC_UNIT       0x1
#define REQUEST_WTC_THRESHOLD  0x10000

#define MIN_WTC 2
#define READ_WTC_UNIT 10
#define ANSWER_WTC_UNIT 10


Extern long requesting_wtc;

/* Export Table */
struct exp_entry{
  long index;
  long wec;
  q data;
  struct exp_entry *next;
};

Extern struct exp_entry *exp_table;
Extern long current_exp_size;

Extern long active_exp_entry;

Extern long regist_exptbl_wec;


Extern long global_ret_index;

#define UNUSED_EXPREC 0xf0f0f0ff
#define UNUSED_IMPREC 0xf0f0f0ff

/* Export Hash Table */
Extern struct exp_entry *exp_hash_table[EXP_TABLE_HASH_SIZE];

Extern struct exp_entry *top_of_exp_freelist;

/* Import Table */

struct imp_entry{
  long next;
  q object;
};

Extern struct imp_entry *imp_table;
Extern long current_imp_size;

Extern struct imp_entry top_of_imp_freelist;

Extern long active_imp_rec;
Extern long free_imp_rec;

/* Network Output Buffer */

long obuf;

Extern long *network_outbuf;
Extern long outbuf_index;
Extern long current_outbuf_size Init(MAX_BUF_SIZE);

long test_ext;


#define PUT_BUFFER(pe, data) \
{\
  network_outbuf[outbuf_index] = (long)(data);  \
  outbuf_index++;\
  if (outbuf_index >= current_outbuf_size){\
    expand_outbuf();\
  }\
}\

/* Network Input Buffer */

Extern long *inbuf;
Extern long inbuf_index;
Extern long current_inbuf_size Init(MAX_BUF_SIZE);

Extern int total_node, my_node;

Extern long receive_answer_flag;
Extern long answer_return_exp_index;
Extern q decode_data;

Extern long eager_transfer_flag  Init(0);
Extern long eager_transfer_level Init(0);

Extern long network_statistics_flag  Init(0);

Extern long sendsig_flag Init(0);

Extern long msg_busywait_flag Init(0);

/* For message suspend */

#define END_SUSP_MSG_REC 0xffffffff

Extern struct susp_msg_rec *top_of_susp_msg_rec;

struct susp_msg_rec{
  struct susp_msg_rec *next;
  long node;
  long wtc;
  long length;
  long *outbuf;
};

/* Statistics */

Extern long start_sec;
Extern long start_usec;

Extern long send_throw_cnt;
Extern long send_read_cnt;
Extern long send_unify_cnt;
Extern long send_answer_cnt;
Extern long send_release_cnt;
Extern long send_request_wtc_cnt;
Extern long send_supply_wtc_cnt;

Extern long recv_throw_cnt;
Extern long recv_read_cnt;
Extern long recv_unify_cnt;
Extern long recv_release_cnt;
Extern long recv_answer_cnt;
Extern long recv_request_wtc_cnt;
Extern long recv_supply_wtc_cnt;

Extern long msg_suspend_cnt;
Extern long msg_resume_cnt;

Extern long send_data_cnt;
Extern long recv_data_cnt;

/* For trace */

Extern long throw_trace_count;

/* case that each PE has each I/O */

#ifdef MAIN
int distdebug = 0;
int debugio[MAX_PROC_NUM];
#else
Extern int distdebug;
Extern int debugio[MAX_PROC_NUM];
#endif

#define ERROR_STOP for(;;)

