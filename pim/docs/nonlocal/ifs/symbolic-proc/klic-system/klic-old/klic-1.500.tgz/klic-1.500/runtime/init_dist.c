#include <klic/basic.h>
#include <klic/struct.h>
#include <klic/primitives.h>
#include <klic/unify.h>
#include <klic/timing.h>
#include <klic/index.h>

#include <stdio.h>
#include <setjmp.h>
#include <malloc.h>

#include <klic/interpe.h>
#include <klic/traceio.h>

#include <signal.h>
#include <sys/types.h>
#include <unistd.h>

#include "pvm3.h"

extern char *malloc(), *realloc();

timerstruct before_exec, after_exec;

void initiate_allocated_exp_table()
{
  int i;

  top_of_exp_freelist = &exp_table[current_exp_size];

  for(i = current_exp_size ; i < (current_exp_size+EXP_TABLE_INC_SIZE); i++){
    exp_table[i].index = i;            /* for getting index from address */
    exp_table[i].wec   = 0;            /* for getting index from address */
    exp_table[i].next = &exp_table[i+1];
    exp_table[i].data = (q)UNUSED_EXPREC;
  }
  exp_table[current_exp_size+EXP_TABLE_INC_SIZE-1].next = (struct exp_entry *)END_EXP_FREELIST;

  current_exp_size = current_exp_size + EXP_TABLE_INC_SIZE;
}


void initiate_exp_table()
{
  int i;
  char *exp_alloc;

  current_exp_size = 0;

  exp_alloc = malloc(EXP_TABLE_INC_SIZE*sizeof(struct exp_entry));
  if(exp_alloc == NULL){
    fatal("malloc failed in initiate_exp_table");
  }
  exp_table = (struct exp_entry *)exp_alloc;

  initiate_allocated_exp_table();

}

void initiate_outbuf();
void initiate_inbuf();

void initiate_global_data()
{
  /* ReadHook$B$,!"(Banswer_value$B$r<u$1$?;~!"(B%unify$B$r=P$5$J$$$?$a$N=hM}(B */
  receive_answer_flag = 0;
  answer_return_exp_index = -1;
  /* ReadHook$B$,!"(Banswer_value$B$r<u$1$?;~!"(B%unify$B$r=P$5$J$$$?$a$N=hM}(B */

  requesting_wtc = 0;

  active_exp_entry = 0;

  /* $B%a%C%;!<%8%5%9%Z%s%IMQ(B */
  top_of_susp_msg_rec = (struct susp_msg_rec *)END_SUSP_MSG_REC;

  /* $B%a%C%;!<%8B,DjMQ=i4|2=(B */
  send_throw_cnt = 0;
  send_read_cnt  = 0;
  send_unify_cnt = 0;
  send_answer_cnt = 0;
  send_release_cnt = 0;
  send_request_wtc_cnt = 0;
  send_supply_wtc_cnt = 0;

  recv_throw_cnt = 0;
  recv_read_cnt = 0;
  recv_unify_cnt = 0;
  recv_answer_cnt = 0;
  recv_release_cnt = 0;
  recv_request_wtc_cnt = 0;
  recv_supply_wtc_cnt = 0;

  send_data_cnt = 0;
  recv_data_cnt = 0;

  initiate_outbuf();
  initiate_inbuf();
}

void initiate_allocated_imp_table()
{
  int i;

  for(i = current_imp_size ; i < (current_imp_size+IMP_TABLE_INC_SIZE); i++){
    imp_table[i].next = i+1;
    imp_table[i].object = (q)UNUSED_IMPREC;
    free_imp_rec++;
  }
  imp_table[current_imp_size+IMP_TABLE_INC_SIZE-1].next = END_IMP_FREELIST;

  if(current_imp_size == 0){
    top_of_imp_freelist.next = 1;
    imp_table[0].next = END_IMP_TABLE;
    free_imp_rec--;
  } else {
    top_of_imp_freelist.next = current_imp_size;
  }
  current_imp_size += IMP_TABLE_INC_SIZE;
}

void initiate_imp_table()
{
  int i;
  char *imp_alloc;

  active_imp_rec = 0;
  free_imp_rec = 0;

  current_imp_size = 0;

  imp_alloc = malloc(IMP_TABLE_INC_SIZE*sizeof(struct imp_entry));
  if(imp_alloc == NULL){
    fatal("malloc failed in initiate_imp_table");    
  }

  imp_table = (struct imp_entry *)imp_alloc;

  initiate_allocated_imp_table();

}

void init_inter_node()
{
  int mytid, pvm_adinfo;

  initiate_exp_table();
  initiate_global_data();
  initiate_imp_table();
}

#define MAXARGS  128
void initiate_tid_table_shoen(binname,argc,argv)
char binname[];
int argc;
char **argv;
{
  int pn = total_node, tpid[256];
  int bufid, bufsize, msgtag, tid, tinfo, ntask, gsize, i, histid;
  struct taskinfo *taskp;
  char *sargv[MAXARGS];

  shoen_tid = tid_tbl[total_node];
  for (i = 0; i < argc-1; i++) sargv[i] = argv[i+1];
  sargv[argc-1] = (char *) NULL;
  ntask = pvm_spawn(binname,sargv,PvmTaskDefault,0,total_node,(int *)tid_tbl);

  if (ntask < total_node) {
    sprintf(iobuf,"Can't execute tasks!!\n");
    SystemPrint(iobuf);
    for (i = 0; i < total_node; i++) {
      if (tid_tbl[i] > 0 ) pvm_kill(tid_tbl[i]);
    }
    CloseIO;
    pvm_exit();
    exit(-1);
  }

  for (i = 0; i < total_node; i++) {
    pvm_initsend(PvmDataDefault);
    if (distdebug) {
      pvm_pkint(&debugio[i],1,1);
    } else {
      pvm_pkint(&iotid,1,1);
    }
    pvm_pkint(&total_node,1,1); /* BE Careful, Carefule, Carefle */
    pvm_pkint(&i,1,1);
    pvm_send(tid_tbl[i],3);
  }

  for (i = 0; i < total_node; i++) {
    pvm_recv(tid_tbl[i],-1);
    pvm_upkint(&tpid[i],1,1);
  }

  if(network_statistics_flag){
    sprintf(iobuf,"SHOEN,  \tTID = %x,\tPID = %d\n",shoen_tid,(int)getpid());
    EPrint(iobuf);
    for (i = 0; i < total_node; i++) {
      sprintf(iobuf,"PE = %d  ,\tTID = %x,\tPID = %d\n",i,tid_tbl[i],tpid[i]);
      EPrint(iobuf);
    }
  }

  for (i = 0; i < total_node; i++) {
    pvm_initsend(PvmDataDefault);
    pvm_pkint((int *)tid_tbl,total_node+1,1);
    pvm_send(tid_tbl[i],3);
  }
}

void initiate_tid_table_fp()
{
  int slave_info[2];
  int bufid, bufsize, msgtag, tid, inum, stid;

  shoen_tid = pvm_parent();
  pvm_recv(shoen_tid,-1);
  pvm_upkint((int *)tid_tbl,total_node+1,1);

}

void init_rusage()
{
  measure(before_exec);
}
