/* Compiled by KLIC compiler version 1.500 (Fri Oct 21 12:19:27 JST 1994) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_klic__comp__obj();
Const struct predicate predicate_klic__comp__obj_xwrite__object_4 =
   { module_klic__comp__obj, 0, 4 };
Const struct predicate predicate_klic__comp__obj_xwrite__object_5 =
   { module_klic__comp__obj, 1, 5 };
Const struct predicate predicate_klic__comp__obj_xwrite__object_2F5_240_6 =
   { module_klic__comp__obj, 2, 6 };
Const struct predicate predicate_klic__comp__obj_xwrite__object_2F5_240_2F6_240_8 =
   { module_klic__comp__obj, 3, 8 };
Const struct predicate predicate_klic__comp__obj_xwrite__object_2F5_240_2F6_240_2F8_240_10 =
   { module_klic__comp__obj, 4, 10 };
Const struct predicate predicate_klic__comp__obj_xwrite__one_6 =
   { module_klic__comp__obj, 5, 6 };
Const struct predicate predicate_klic__comp__obj_xwrite__one__move_4 =
   { module_klic__comp__obj, 6, 4 };
Const struct predicate predicate_klic__comp__obj_xwrite__one__execute_5 =
   { module_klic__comp__obj, 7, 5 };
Const struct predicate predicate_klic__comp__obj_xwrite__one__bblt_6 =
   { module_klic__comp__obj, 8, 6 };
Const struct predicate predicate_klic__comp__obj_xwrite__adjust__qp_3 =
   { module_klic__comp__obj, 9, 3 };
Const struct predicate predicate_klic__comp__obj_xwrite__adjust__allocp_3 =
   { module_klic__comp__obj, 10, 3 };
Const struct predicate predicate_klic__comp__obj_xklicformat_3 =
   { module_klic__comp__obj, 11, 3 };
Const struct predicate predicate_klic__comp__obj_xnl_1 =
   { module_klic__comp__obj, 12, 1 };
Const struct predicate predicate_klic__comp__obj_xflush_2 =
   { module_klic__comp__obj, 13, 2 };
Const struct predicate predicate_klic__comp__obj_xnl_2 =
   { module_klic__comp__obj, 14, 2 };
Const struct predicate predicate_klic__comp__obj_xflush_3 =
   { module_klic__comp__obj, 15, 3 };
Const struct predicate predicate_klic__comp__obj_xklicformat_4 =
   { module_klic__comp__obj, 16, 4 };
Const struct predicate predicate_klic__comp__obj_xwait__and__out_4 =
   { module_klic__comp__obj, 17, 4 };
Const struct predicate predicate_klic__comp__obj_xklicformat_6 =
   { module_klic__comp__obj, 18, 6 };
Const struct predicate predicate_klic__comp__obj_xformat__special_5 =
   { module_klic__comp__obj, 19, 5 };
Const struct predicate predicate_klic__comp__obj_xformat__special__w_3 =
   { module_klic__comp__obj, 20, 3 };
Const struct predicate predicate_klic__comp__obj_xwrite__params_3 =
   { module_klic__comp__obj, 21, 3 };
Const struct predicate predicate_klic__comp__obj_xwrite__param_3 =
   { module_klic__comp__obj, 22, 3 };
Const struct predicate predicate_klic__comp__obj_xwrite__string_3 =
   { module_klic__comp__obj, 23, 3 };
Const struct predicate predicate_klic__comp__obj_xwrite__int_3 =
   { module_klic__comp__obj, 24, 3 };
Const struct predicate predicate_klic__comp__obj_xwrite__int_2F3_240_3 =
   { module_klic__comp__obj, 25, 3 };
Const struct predicate predicate_klic__comp__obj_xwrite__elem__access_4 =
   { module_klic__comp__obj, 26, 4 };
Const struct predicate predicate_klic__comp__obj_xwrite__lab_4 =
   { module_klic__comp__obj, 27, 4 };
Const struct predicate predicate_klic__comp__obj_xwrite__reg_3 =
   { module_klic__comp__obj, 28, 3 };
Const struct predicate predicate_klic__comp__obj_xwrite__qp_3 =
   { module_klic__comp__obj, 29, 3 };
Const struct predicate predicate_klic__comp__obj_xwrite__inline_6 =
   { module_klic__comp__obj, 30, 6 };
Const struct predicate predicate_klic__comp__obj_xwrite__inline_8 =
   { module_klic__comp__obj, 31, 8 };
Const struct predicate predicate_klic__comp__obj_xinline__special_6 =
   { module_klic__comp__obj, 32, 6 };
extern Const struct predicate predicate_integer__arithmetics_xadd_3;
extern Const struct predicate predicate_klic__comp__util_xlength_2;
extern Const struct predicate predicate_klic__comp__util_xappend_3;
extern Const struct predicate predicate_klic__comp__kl1cmp_xwarning_2;
extern Const struct predicate predicate_klicio_xklicio_1;
extern Const struct predicate predicate_klic__comp__write_xwrite__funct__name_4;
extern Const struct predicate predicate_klic__comp__write_xwrite__pred__name_5;
extern Const struct predicate predicate_klic__comp__write_xmake__atom__name__string_2;
extern Const struct predicate predicate_klic__comp__kl1cmp_xreport__error_2;
extern Const struct predicate predicate_atom__table_xget__atom__string_2;
extern Const struct predicate predicate_unparser_xunparse_4;
extern Const struct predicate predicate_klic__comp__write_xwrite__atom_3;
extern Const struct predicate predicate_klic__comp__util_xnth_3;

module module_klic__comp__obj(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  Const static unsigned char strconst_body_0[28] =
    "  unify2(~k, ~k, ~k, ~k);\n";
  Const static string_structure_type_8 string_const_0 =
      declare_string_constant_8(strconst_body_0,26);
  Const static unsigned char strconst_body_1[44] =
    "  unify4(~k, ~k, ~k, ~k, ~k, ~k, ~k, ~k);\n";
  Const static string_structure_type_8 string_const_1 =
      declare_string_constant_8(strconst_body_1,42);
  Const static unsigned char strconst_body_2[36] =
    "  unify3(~k, ~k, ~k, ~k, ~k, ~k);\n";
  Const static string_structure_type_8 string_const_2 =
      declare_string_constant_8(strconst_body_2,34);
  Const static unsigned char strconst_body_3[12] =
    " default:\n";
  Const static string_structure_type_8 string_const_3 =
      declare_string_constant_8(strconst_body_3,10);
  Const static unsigned char strconst_body_4[8] =
    "  };\n";
  Const static string_structure_type_8 string_const_4 =
      declare_string_constant_8(strconst_body_4,5);
  Const static unsigned char strconst_body_5[20] =
    "  otherwise(~l);\n";
  Const static string_structure_type_8 string_const_5 =
      declare_string_constant_8(strconst_body_5,17);
  Const static q cons_const_6[] = {
    NILATOM,
    makesym(atom_interrupt),
  };
  Const static unsigned char strconst_body_7[20] =
    "  alternative(~l);\n";
  Const static string_structure_type_8 string_const_7 =
      declare_string_constant_8(strconst_body_7,19);
  Const static q cons_const_8[] = {
    NILATOM,
    makesym(atom_clear__reason),
  };
  Const static unsigned char strconst_body_9[8] =
    " ~l:\n";
  Const static string_structure_type_8 string_const_9 =
      declare_string_constant_8(strconst_body_9,5);
  Const static unsigned char strconst_body_10[12] =
    "  ~r = ~e;\n";
  Const static string_structure_type_8 string_const_10 =
      declare_string_constant_8(strconst_body_10,11);
  Const static unsigned char strconst_body_11[4] =
    {' ',' ','}','\n',};
  Const static string_structure_type_8 string_const_11 =
      declare_string_constant_8(strconst_body_11,4);
  Const static unsigned char strconst_body_12[36] =
    "    ~r = element_of_vector(~r,~d);\n";
  Const static string_structure_type_8 string_const_12 =
      declare_string_constant_8(strconst_body_12,35);
  Const static unsigned char strconst_body_13[36] =
    "    extern q element_of_vector();\n";
  Const static string_structure_type_8 string_const_13 =
      declare_string_constant_8(strconst_body_13,34);
  Const static unsigned char strconst_body_14[4] =
    {' ',' ','{','\n',};
  Const static string_structure_type_8 string_const_14 =
      declare_string_constant_8(strconst_body_14,4);
  Const static unsigned char strconst_body_15[28] =
    "  deref_and_jump(~r,~l);\n";
  Const static string_structure_type_8 string_const_15 =
      declare_string_constant_8(strconst_body_15,25);
  Const static unsigned char strconst_body_16[20] =
    {' ',' ','*','r','e','a','s','o','n','p','+','+',' ','=',' ',' ','~','r',';','\n',};
  Const static string_structure_type_8 string_const_16 =
      declare_string_constant_8(strconst_body_16,20);
  Const static unsigned char strconst_body_17[12] =
    "  goto ~l;\n";
  Const static string_structure_type_8 string_const_17 =
      declare_string_constant_8(strconst_body_17,11);
  Const static unsigned char strconst_body_18[24] =
    {' ',' ','s','w','i','t','c','h',' ','(','p','t','a','g','o','f','(','~','r',')',')',' ','{','\n',};
  Const static string_structure_type_8 string_const_18 =
      declare_string_constant_8(strconst_body_18,24);
  Const static unsigned char strconst_body_19[24] =
    {' ',' ','s','w','i','t','c','h',' ','(','a','t','a','g','o','f','(','~','r',')',')',' ','{','\n',};
  Const static string_structure_type_8 string_const_19 =
      declare_string_constant_8(strconst_body_19,24);
  Const static unsigned char strconst_body_20[24] =
    {' ',' ','s','w','i','t','c','h',' ','(','s','y','m','v','a','l','(','~','r',')',')',' ','{','\n',};
  Const static string_structure_type_8 string_const_20 =
      declare_string_constant_8(strconst_body_20,24);
  Const static unsigned char strconst_body_21[32] =
    "  switch ((unsigned long)~r) {\n";
  Const static string_structure_type_8 string_const_21 =
      declare_string_constant_8(strconst_body_21,31);
  Const static unsigned char strconst_body_22[36] =
    {' ',' ','s','w','i','t','c','h',' ','(','s','y','m','v','a','l','(','f','u','n','c','t','o','r','_','o','f','(','~','r',')',')',')',' ','{','\n',};
  Const static string_structure_type_8 string_const_22 =
      declare_string_constant_8(strconst_body_22,36);
  Const static unsigned char strconst_body_23[12] =
    " case ~s:\n";
  Const static string_structure_type_8 string_const_23 =
      declare_string_constant_8(strconst_body_23,10);
  Const static unsigned char strconst_body_24[20] =
    " case symval(~a):\n";
  Const static string_structure_type_8 string_const_24 =
      declare_string_constant_8(strconst_body_24,18);
  Const static unsigned char strconst_body_25[28] =
    " case (unsigned long) ~a:\n";
  Const static string_structure_type_8 string_const_25 =
      declare_string_constant_8(strconst_body_25,26);
  Const static unsigned char strconst_body_26[12] =
    " case ~f:\n";
  Const static string_structure_type_8 string_const_26 =
      declare_string_constant_8(strconst_body_26,10);
  Const static unsigned char strconst_body_27[32] =
    {' ',' ','i','f','_','e','q','u','a','l','(','~','r',',',' ','~','r',',',' ','~','l',',',' ','~','l',',',' ','~','l',')',';','\n',};
  Const static string_structure_type_8 string_const_27 =
      declare_string_constant_8(strconst_body_27,32);
  Const static unsigned char strconst_body_28[28] =
    {' ',' ','i','f','_','n','o','t','_','e','q','u','a','l','(','~','r',',',' ','~','r',',',' ','~','l',')',';','\n',};
  Const static string_structure_type_8 string_const_28 =
      declare_string_constant_8(strconst_body_28,28);
  Const static unsigned char strconst_body_29[28] =
    "  if (isint(~r)) goto ~l;\n";
  Const static string_structure_type_8 string_const_29 =
      declare_string_constant_8(strconst_body_29,26);
  Const static unsigned char strconst_body_30[28] =
    "  if (!isint(~r)) goto ~l;\n";
  Const static string_structure_type_8 string_const_30 =
      declare_string_constant_8(strconst_body_30,27);
  Const static unsigned char strconst_body_31[28] =
    "  if (iscons(~r)) goto ~l;\n";
  Const static string_structure_type_8 string_const_31 =
      declare_string_constant_8(strconst_body_31,27);
  Const static unsigned char strconst_body_32[28] =
    {' ',' ','i','f',' ','(','!','i','s','c','o','n','s','(','~','r',')',')',' ','g','o','t','o',' ','~','l',';','\n',};
  Const static string_structure_type_8 string_const_32 =
      declare_string_constant_8(strconst_body_32,28);
  Const static unsigned char strconst_body_33[32] =
    "  if (isfunctor(~r)) goto ~l;\n";
  Const static string_structure_type_8 string_const_33 =
      declare_string_constant_8(strconst_body_33,30);
  Const static unsigned char strconst_body_34[32] =
    "  if (!isfunctor(~r)) goto ~l;\n";
  Const static string_structure_type_8 string_const_34 =
      declare_string_constant_8(strconst_body_34,31);
  Const static unsigned char strconst_body_35[28] =
    {' ',' ','i','f',' ','(','!','i','s','g','o','b','j','(','~','r',')',')',' ','g','o','t','o',' ','~','l',';','\n',};
  Const static string_structure_type_8 string_const_35 =
      declare_string_constant_8(strconst_body_35,28);
  Const static unsigned char strconst_body_36[32] =
    {' ',' ','i','f',' ','(','!','i','s','c','l','a','s','s','(','~','r',',','~','q',')',')',' ','g','o','t','o',' ','~','l',';','\n',};
  Const static string_structure_type_8 string_const_36 =
      declare_string_constant_8(strconst_body_36,32);
  Const static unsigned char strconst_body_37[28] =
    "  if (isref(~r)) goto ~l;\n";
  Const static string_structure_type_8 string_const_37 =
      declare_string_constant_8(strconst_body_37,26);
  Const static unsigned char strconst_body_38[28] =
    "  if (!isref(~r)) goto ~l;\n";
  Const static string_structure_type_8 string_const_38 =
      declare_string_constant_8(strconst_body_38,27);
  Const static unsigned char strconst_body_39[48] =
    "  if (functor_of(~r) != makesym(~f)) goto ~l;\n";
  Const static string_structure_type_8 string_const_39 =
      declare_string_constant_8(strconst_body_39,46);
  Const static unsigned char strconst_body_40[28] =
    "  if (~r != ~k) goto ~l;\n";
  Const static string_structure_type_8 string_const_40 =
      declare_string_constant_8(strconst_body_40,25);
  Const static unsigned char strconst_body_41[4] =
    "  ";
  Const static string_structure_type_8 string_const_41 =
      declare_string_constant_8(strconst_body_41,2);
  Const static unsigned char strconst_body_42[12] =
    "  ~r = ~a;\n";
  Const static string_structure_type_8 string_const_42 =
      declare_string_constant_8(strconst_body_42,11);
  Const static unsigned char strconst_body_43[12] =
    "  ~r = ~k;\n";
  Const static string_structure_type_8 string_const_43 =
      declare_string_constant_8(strconst_body_43,11);
  Const static unsigned char strconst_body_44[32] =
    "  ~r = makecons(&allocp[~d]);\n";
  Const static string_structure_type_8 string_const_44 =
      declare_string_constant_8(strconst_body_44,30);
  Const static unsigned char strconst_body_45[36] =
    "  ~r = makefunctor(&allocp[~d]);\n";
  Const static string_structure_type_8 string_const_45 =
      declare_string_constant_8(strconst_body_45,33);
  Const static unsigned char strconst_body_46[48] =
    "  ~r = create_vector(&allocp[~d], ~d, allocp);\n";
  Const static string_structure_type_8 string_const_46 =
      declare_string_constant_8(strconst_body_46,47);
  Const static unsigned char strconst_body_47[28] =
    {' ',' ','a','l','l','o','c','p','[','~','d',']',' ','=',' ','m','a','k','e','s','y','m','(','~','f',')',';','\n',};
  Const static string_structure_type_8 string_const_47 =
      declare_string_constant_8(strconst_body_47,28);
  Const static unsigned char strconst_body_48[20] =
    "  unify(~k, ~k);\n";
  Const static string_structure_type_8 string_const_48 =
      declare_string_constant_8(strconst_body_48,17);
  Const static unsigned char strconst_body_49[24] =
    "  unify_value(~k, ~k);\n";
  Const static string_structure_type_8 string_const_49 =
      declare_string_constant_8(strconst_body_49,23);
  Const static unsigned char strconst_body_50[16] =
    "  proceed();\n";
  Const static string_structure_type_8 string_const_50 =
      declare_string_constant_8(strconst_body_50,13);
  Const static unsigned char strconst_body_51[28] =
    "  allocp[~d] = (q)(&~p);\n";
  Const static string_structure_type_8 string_const_51 =
      declare_string_constant_8(strconst_body_51,25);
  Const static unsigned char strconst_body_52[24] =
    "  allocp[~d] = (q)~Q;\n";
  Const static string_structure_type_8 string_const_52 =
      declare_string_constant_8(strconst_body_52,22);
  Const static unsigned char strconst_body_53[24] =
    {' ',' ','t','h','r','o','w','_','g','o','a','l','(','~','r',',','~','Q',',','~','Q',')',';','\n',};
  Const static string_structure_type_8 string_const_53 =
      declare_string_constant_8(strconst_body_53,24);
  Const static unsigned char strconst_body_54[36] =
    "  enqueue_at_priority(~k,~Q,~Q);\n";
  Const static string_structure_type_8 string_const_54 =
      declare_string_constant_8(strconst_body_54,33);
  Const static unsigned char strconst_body_55[40] =
    "  enqueue_at_lower_priority(~k,~Q,~Q);\n";
  Const static string_structure_type_8 string_const_55 =
      declare_string_constant_8(strconst_body_55,39);
  Const static unsigned char strconst_body_56[44] =
    "  enqueue_at_priority_no_check(~k,~Q,~Q);\n";
  Const static string_structure_type_8 string_const_56 =
      declare_string_constant_8(strconst_body_56,42);
  Const static unsigned char strconst_body_57[48] =
    {' ',' ','e','n','q','u','e','u','e','_','a','t','_','l','o','w','e','r','_','p','r','i','o','r','i','t','y','_','n','o','_','c','h','e','c','k','(','~','k',',','~','Q',',','~','Q',')',';','\n',};
  Const static string_structure_type_8 string_const_57 =
      declare_string_constant_8(strconst_body_57,48);
  Const static unsigned char strconst_body_58[20] =
    "  allocp[~d] = ~r;\n";
  Const static string_structure_type_8 string_const_58 =
      declare_string_constant_8(strconst_body_58,19);
  Const static unsigned char strconst_body_59[20] =
    "  allocp[~d] = ~a;\n";
  Const static string_structure_type_8 string_const_59 =
      declare_string_constant_8(strconst_body_59,19);
  Const static unsigned char strconst_body_60[44] =
    "  allocp[~d] = ~r = makeref(&allocp[~d]);\n";
  Const static string_structure_type_8 string_const_60 =
      declare_string_constant_8(strconst_body_60,42);
  Const static unsigned char strconst_body_61[20] =
    "  allocp[~d] = ~e;\n";
  Const static string_structure_type_8 string_const_61 =
      declare_string_constant_8(strconst_body_61,19);
  Const static unsigned char strconst_body_62[20] =
    "  allocp[~d] = ~k;\n";
  Const static string_structure_type_8 string_const_62 =
      declare_string_constant_8(strconst_body_62,19);
  Const static unsigned char strconst_body_63[16] =
    {' ',' ','~','w','(','~',',',',','~','k',',','~','l',')',';','\n',};
  Const static string_structure_type_8 string_const_63 =
      declare_string_constant_8(strconst_body_63,16);
  Const static unsigned char strconst_body_64[16] =
    "  ~w(~,,~l);\n";
  Const static string_structure_type_8 string_const_64 =
      declare_string_constant_8(strconst_body_64,13);
  Const static unsigned char strconst_body_65[40] =
    "  new_generic(~q_g_new, ~d, ~r, ~d);\n";
  Const static string_structure_type_8 string_const_65 =
      declare_string_constant_8(strconst_body_65,37);
  Const static unsigned char strconst_body_66[28] =
    {' ',' ','c','a','l','l','_','g','e','n','e','r','i','c','(','~','k',',',' ','~','f',',',' ','~','d',')',';','\n',};
  Const static string_structure_type_8 string_const_66 =
      declare_string_constant_8(strconst_body_66,28);
  Const static unsigned char strconst_body_67[36] =
    "  guard_generic(~k, ~f, ~d, ~l);\n";
  Const static string_structure_type_8 string_const_67 =
      declare_string_constant_8(strconst_body_67,33);
  Const static unsigned char strconst_body_68[24] =
    {' ',' ','g','e','n','e','r','i','c','_','a','r','g','[','~','d',']',' ','=',' ','~','k',';','\n',};
  Const static string_structure_type_8 string_const_68 =
      declare_string_constant_8(strconst_body_68,24);
  Const static unsigned char strconst_body_69[24] =
    {' ',' ','~','r',' ','=',' ','g','e','n','e','r','i','c','_','a','r','g','[','~','d',']',';','\n',};
  Const static string_structure_type_8 string_const_69 =
      declare_string_constant_8(strconst_body_69,24);
  Const static unsigned char strconst_body_70[32] =
    "Failed to write out object: ~w";
  Const static string_structure_type_8 string_const_70 =
      declare_string_constant_8(strconst_body_70,30);
  Const static unsigned char strconst_body_71[12] =
    "  ~r = ~r;\n";
  Const static string_structure_type_8 string_const_71 =
      declare_string_constant_8(strconst_body_71,11);
  Const static unsigned char strconst_body_72[32] =
    "  execute(~q_~d_clear_reason);\n";
  Const static string_structure_type_8 string_const_72 =
      declare_string_constant_8(strconst_body_72,31);
  Const static unsigned char strconst_body_73[28] =
    {' ',' ','g','o','t','o',' ','~','q','_','~','d','_','e','x','t','_','i','n','t','e','r','r','u','p','t',';','\n',};
  Const static string_structure_type_8 string_const_73 =
      declare_string_constant_8(strconst_body_73,28);
  Const static unsigned char strconst_body_74[20] =
    {' ',' ','e','x','e','c','u','t','e','(','~','q','_','~','d','_','0',')',';','\n',};
  Const static string_structure_type_8 string_const_74 =
      declare_string_constant_8(strconst_body_74,20);
  Const static unsigned char strconst_body_75[24] =
    "  ~w_no_check_y(~,);\n";
  Const static string_structure_type_8 string_const_75 =
      declare_string_constant_8(strconst_body_75,21);
  Const static unsigned char strconst_body_76[24] =
    "  ~w_no_check_x(~,);\n";
  Const static string_structure_type_8 string_const_76 =
      declare_string_constant_8(strconst_body_76,21);
  Const static unsigned char strconst_body_77[20] =
    "  ~w_no_check(~,);\n";
  Const static string_structure_type_8 string_const_77 =
      declare_string_constant_8(strconst_body_77,19);
  Const static unsigned char strconst_body_78[12] =
    "  ~w(~,);\n";
  Const static string_structure_type_8 string_const_78 =
      declare_string_constant_8(strconst_body_78,10);
  Const static unsigned char strconst_body_79[12] =
    "  qp = ~Q;\n";
  Const static string_structure_type_8 string_const_79 =
      declare_string_constant_8(strconst_body_79,11);
  Const static unsigned char strconst_body_80[16] =
    {' ',' ','a','l','l','o','c','p',' ','+','=',' ','~','d',';','\n',};
  Const static string_structure_type_8 string_const_80 =
      declare_string_constant_8(strconst_body_80,16);
  Const static q cons_const_81[] = {
    NILATOM,
    makeint(10),
  };
  Const static q funct_const_82[] = {
    makesym(functor_normal_1),
    makecons(cons_const_81),
  };
  Const static q funct_const_83[] = {
    makesym(functor_stderr_1),
    makefunctor(funct_const_82),
  };
  Const static q cons_const_84[] = {
    NILATOM,
    makefunctor(funct_const_83),
  };
  Const static unsigned char strconst_body_85[24] =
    "unknown format char ~c";
  Const static string_structure_type_8 string_const_85 =
      declare_string_constant_8(strconst_body_85,22);
  Const static q funct_const_86[] = {
    makesym(functor_ops_3),
    NILATOM,
    NILATOM,
    NILATOM,
  };
  Const static unsigned char strconst_body_87[12] =
    {'m','a','k','e','i','n','t','(','~','d','L',')',};
  Const static string_structure_type_8 string_const_87 =
      declare_string_constant_8(strconst_body_87,12);
  Const static unsigned char strconst_body_88[28] =
    "makefloat(float_const_~d)";
  Const static string_structure_type_8 string_const_88 =
      declare_string_constant_8(strconst_body_88,25);
  Const static unsigned char strconst_body_89[24] =
    "makepred(pred_const_~d)";
  Const static string_structure_type_8 string_const_89 =
      declare_string_constant_8(strconst_body_89,23);
  Const static unsigned char strconst_body_90[24] =
    "makecons(cons_const_~d)";
  Const static string_structure_type_8 string_const_90 =
      declare_string_constant_8(strconst_body_90,23);
  Const static unsigned char strconst_body_91[28] =
    "makefunctor(funct_const_~d)";
  Const static string_structure_type_8 string_const_91 =
      declare_string_constant_8(strconst_body_91,27);
  Const static unsigned char strconst_body_92[32] =
    "makefunctor(&string_const_~d)";
  Const static string_structure_type_8 string_const_92 =
      declare_string_constant_8(strconst_body_92,29);
  Const static unsigned char strconst_body_93[32] =
    "makefunctor(&vector_const_~d)";
  Const static string_structure_type_8 string_const_93 =
      declare_string_constant_8(strconst_body_93,29);
  Const static unsigned char strconst_body_94[12] =
    "car_of(~r)";
  Const static string_structure_type_8 string_const_94 =
      declare_string_constant_8(strconst_body_94,10);
  Const static unsigned char strconst_body_95[12] =
    "cdr_of(~r)";
  Const static string_structure_type_8 string_const_95 =
      declare_string_constant_8(strconst_body_95,10);
  Const static unsigned char strconst_body_96[12] =
    "arg(~r, ~d)";
  Const static string_structure_type_8 string_const_96 =
      declare_string_constant_8(strconst_body_96,11);
  Const static unsigned char strconst_body_97[16] =
    "~q_~d_interrupt";
  Const static string_structure_type_8 string_const_97 =
      declare_string_constant_8(strconst_body_97,15);
  Const static unsigned char strconst_body_98[8] =
    {'~','q','_','~','d','_','~','w',};
  Const static string_structure_type_8 string_const_98 =
      declare_string_constant_8(strconst_body_98,8);
  Const static unsigned char strconst_body_99[4] =
    "qp";
  Const static string_structure_type_8 string_const_99 =
      declare_string_constant_8(strconst_body_99,2);
  Const static unsigned char strconst_body_100[28] =
    {'(','s','t','r','u','c','t',' ','g','o','a','l','r','e','c','*',')','&','a','l','l','o','c','p','[','~','d',']',};
  Const static string_structure_type_8 string_const_100 =
      declare_string_constant_8(strconst_body_100,28);
  Const static unsigned char strconst_body_101[4] =
    "~l";
  Const static string_structure_type_8 string_const_101 =
      declare_string_constant_8(strconst_body_101,2);
  Const static unsigned char strconst_body_102[4] =
    "~r";
  Const static string_structure_type_8 string_const_102 =
      declare_string_constant_8(strconst_body_102,2);
  q a0, a1, a2, a3, a4, a5, a6, a7, a8, a9;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  switch_on_pred() {
    case_pred(0, write__object_4_top);
    case_pred(1, write__object_5_top);
    case_pred(2, write__object_2F5_240_6_top);
    case_pred(3, write__object_2F5_240_2F6_240_8_top);
    case_pred(4, write__object_2F5_240_2F6_240_2F8_240_10_top);
    case_pred(5, write__one_6_top);
    case_pred(6, write__one__move_4_top);
    case_pred(7, write__one__execute_5_top);
    case_pred(8, write__one__bblt_6_top);
    case_pred(9, write__adjust__qp_3_top);
    case_pred(10, write__adjust__allocp_3_top);
    case_pred(11, klicformat_3_top);
    case_pred(12, nl_1_top);
    case_pred(13, flush_2_top);
    case_pred(14, nl_2_top);
    case_pred(15, flush_3_top);
    case_pred(16, klicformat_4_top);
    case_pred(17, wait__and__out_4_top);
    case_pred(18, klicformat_6_top);
    case_pred(19, format__special_5_top);
    case_pred(20, format__special__w_3_top);
    case_pred(21, write__params_3_top);
    case_pred(22, write__param_3_top);
    case_pred(23, write__string_3_top);
    case_pred(24, write__int_3_top);
    case_pred(25, write__int_2F3_240_3_top);
    case_pred(26, write__elem__access_4_top);
    case_pred(27, write__lab_4_top);
    case_pred(28, write__reg_3_top);
    case_pred(29, write__qp_3_top);
    case_pred(30, write__inline_6_top);
    case_pred(31, write__inline_8_top);
    last_case_pred(32, inline__special_6_top);
  }

 write__object_4_top: {
  q x0;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 write__object_4_clear_reason:
  reasonp = reasons;
 write__object_4_0:
  x0 = a2;
  a4 = a3;
  a3 = x0;
  a2 = makeint(0L);
  execute(write__object_5_0);
  goto write__object_5_ext_interrupt;
 write__object_4_ext_interrupt:
  reasonp = 0l;
 write__object_4_interrupt:
  goto interrupt_4;
 }

 write__object_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 write__object_5_clear_reason:
  reasonp = reasons;
 write__object_5_0:
 write__object_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 write__object_5_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_unify_3)) goto write__object_5_9;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__obj_xwrite__object_5);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = makeint(0L);
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_klic__comp__obj_xwrite__object_2F5_240_6);
  x3 = cdr_of(a0);
  allocp[9] = x3;
  x4 = arg(x0, 0);
  allocp[10] = x4;
  x5 = arg(x0, 1);
  allocp[11] = x5;
  allocp[12] = x6 = makeref(&allocp[12]);
  allocp[13] = x1;
  allocp[14] = x2;
  allocp[15] = (q)(struct goalrec*)&allocp[7];
  allocp[16] = (q)(&predicate_klic__comp__obj_xwrite__adjust__allocp_3);
  allocp[17] = a2;
  allocp[18] = x7 = makeref(&allocp[18]);
  allocp[19] = x6;
  a0 = arg(x0, 2);
  a1 = a3;
  a2 = x7;
  qp = (struct goalrec*)&allocp[15];
  allocp += 20;
  execute(write__adjust__qp_3_0);
  goto write__adjust__qp_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,write__object_5_3);
  *reasonp++ =  x0;
  goto write__object_5_9;
  };
  goto write__object_5_9;
 case ATOMIC:
  if (a0 != NILATOM) goto write__object_5_9;
  unify(a4, a3);
  proceed();
 case VARREF:
  deref_and_jump(a0,write__object_5_1);
  *reasonp++ =  a0;
  goto write__object_5_9;
  };
  goto write__object_5_9;
 write__object_5_9:
  otherwise(write__object_5_interrupt);
 write__object_5_11:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__obj_xwrite__object_5);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = a1;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  a0 = car_of(a0);
  a4 = a3;
  a5 = x2;
  a3 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(write__one_6_0);
  goto write__one_6_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,write__object_5_11);
  *reasonp++ =  a0;
  goto write__object_5_interrupt;
  };
  goto write__object_5_interrupt;
 write__object_5_ext_interrupt:
  reasonp = 0l;
 write__object_5_interrupt:
  toppred = &predicate_klic__comp__obj_xwrite__object_5;
  goto interrupt_5;
 }

 write__object_2F5_240_6_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 write__object_2F5_240_6_clear_reason:
  reasonp = reasons;
 write__object_2F5_240_6_0:
 write__object_2F5_240_6_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 write__object_2F5_240_6_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_unify_3)) goto write__object_2F5_240_6_6;
  a0 = cdr_of(a0);
  x1 = arg(x0, 0);
  x2 = arg(x0, 1);
  x3 = a3;
  a6 = a4;
  a7 = a5;
  a5 = x3;
  a4 = x2;
  a3 = x1;
  execute(write__object_2F5_240_2F6_240_8_0);
  goto write__object_2F5_240_2F6_240_8_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,write__object_2F5_240_6_3);
  *reasonp++ =  x0;
  goto write__object_2F5_240_6_6;
  };
  goto write__object_2F5_240_6_6;
 case VARREF:
  deref_and_jump(a0,write__object_2F5_240_6_1);
  *reasonp++ =  a0;
  goto write__object_2F5_240_6_6;
  };
  goto write__object_2F5_240_6_6;
 write__object_2F5_240_6_6:
  otherwise(write__object_2F5_240_6_interrupt);
  unify(a4, a0);
  allocp[0] = NILATOM;
  allocp[1] = a2;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a1;
  x1 = makecons(&allocp[2]);
  a0 = makefunctor(&string_const_48);
  a1 = x1;
  a2 = a3;
  a3 = a5;
  allocp += 4;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 write__object_2F5_240_6_ext_interrupt:
  reasonp = 0l;
 write__object_2F5_240_6_interrupt:
  goto interrupt_6;
 }

 write__object_2F5_240_2F6_240_8_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 write__object_2F5_240_2F6_240_8_clear_reason:
  reasonp = reasons;
 write__object_2F5_240_2F6_240_8_0:
 write__object_2F5_240_2F6_240_8_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 write__object_2F5_240_2F6_240_8_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_unify_3)) goto write__object_2F5_240_2F6_240_8_6;
  a0 = cdr_of(a0);
  x1 = arg(x0, 0);
  x2 = arg(x0, 1);
  x3 = a5;
  a8 = a6;
  a9 = a7;
  a7 = x3;
  a6 = x2;
  a5 = x1;
  execute(write__object_2F5_240_2F6_240_2F8_240_10_0);
  goto write__object_2F5_240_2F6_240_2F8_240_10_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,write__object_2F5_240_2F6_240_8_3);
  *reasonp++ =  x0;
  goto write__object_2F5_240_2F6_240_8_6;
  };
  goto write__object_2F5_240_2F6_240_8_6;
 case VARREF:
  deref_and_jump(a0,write__object_2F5_240_2F6_240_8_1);
  *reasonp++ =  a0;
  goto write__object_2F5_240_2F6_240_8_6;
  };
  goto write__object_2F5_240_2F6_240_8_6;
 write__object_2F5_240_2F6_240_8_6:
  otherwise(write__object_2F5_240_2F6_240_8_interrupt);
  unify(a6, a0);
  allocp[0] = NILATOM;
  allocp[1] = a4;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a3;
  x1 = makecons(&allocp[2]);
  allocp[4] = x1;
  allocp[5] = a2;
  x2 = makecons(&allocp[4]);
  allocp[6] = x2;
  allocp[7] = a1;
  x3 = makecons(&allocp[6]);
  a0 = makefunctor(&string_const_0);
  a1 = x3;
  a2 = a5;
  a3 = a7;
  allocp += 8;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 write__object_2F5_240_2F6_240_8_ext_interrupt:
  reasonp = 0l;
 write__object_2F5_240_2F6_240_8_interrupt:
  toppred = &predicate_klic__comp__obj_xwrite__object_2F5_240_2F6_240_8;
  goto interrupt_8;
 }

 write__object_2F5_240_2F6_240_2F8_240_10_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 write__object_2F5_240_2F6_240_2F8_240_10_clear_reason:
  reasonp = reasons;
 write__object_2F5_240_2F6_240_2F8_240_10_0:
 write__object_2F5_240_2F6_240_2F8_240_10_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 write__object_2F5_240_2F6_240_2F8_240_10_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_unify_3)) goto write__object_2F5_240_2F6_240_2F8_240_10_6;
  x1 = cdr_of(a0);
  unify(a8, x1);
  allocp[0] = NILATOM;
  x3 = arg(x0, 1);
  allocp[1] = x3;
  x2 = makecons(&allocp[0]);
  allocp[2] = x2;
  x5 = arg(x0, 0);
  allocp[3] = x5;
  x4 = makecons(&allocp[2]);
  allocp[4] = x4;
  allocp[5] = a6;
  x6 = makecons(&allocp[4]);
  allocp[6] = x6;
  allocp[7] = a5;
  x7 = makecons(&allocp[6]);
  allocp[8] = x7;
  allocp[9] = a4;
  x8 = makecons(&allocp[8]);
  allocp[10] = x8;
  allocp[11] = a3;
  x9 = makecons(&allocp[10]);
  allocp[12] = x9;
  allocp[13] = a2;
  x10 = makecons(&allocp[12]);
  allocp[14] = x10;
  allocp[15] = a1;
  x11 = makecons(&allocp[14]);
  a0 = makefunctor(&string_const_1);
  a1 = x11;
  a2 = a7;
  a3 = a9;
  allocp += 16;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,write__object_2F5_240_2F6_240_2F8_240_10_3);
  *reasonp++ =  x0;
  goto write__object_2F5_240_2F6_240_2F8_240_10_6;
  };
  goto write__object_2F5_240_2F6_240_2F8_240_10_6;
 case VARREF:
  deref_and_jump(a0,write__object_2F5_240_2F6_240_2F8_240_10_1);
  *reasonp++ =  a0;
  goto write__object_2F5_240_2F6_240_2F8_240_10_6;
  };
  goto write__object_2F5_240_2F6_240_2F8_240_10_6;
 write__object_2F5_240_2F6_240_2F8_240_10_6:
  otherwise(write__object_2F5_240_2F6_240_2F8_240_10_interrupt);
  unify(a8, a0);
  allocp[0] = NILATOM;
  allocp[1] = a6;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a5;
  x1 = makecons(&allocp[2]);
  allocp[4] = x1;
  allocp[5] = a4;
  x2 = makecons(&allocp[4]);
  allocp[6] = x2;
  allocp[7] = a3;
  x3 = makecons(&allocp[6]);
  allocp[8] = x3;
  allocp[9] = a2;
  x4 = makecons(&allocp[8]);
  allocp[10] = x4;
  allocp[11] = a1;
  x5 = makecons(&allocp[10]);
  a0 = makefunctor(&string_const_2);
  a1 = x5;
  a2 = a7;
  a3 = a9;
  allocp += 12;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 write__object_2F5_240_2F6_240_2F8_240_10_ext_interrupt:
  reasonp = 0l;
 write__object_2F5_240_2F6_240_2F8_240_10_interrupt:
  toppred = &predicate_klic__comp__obj_xwrite__object_2F5_240_2F6_240_2F8_240_10;
  goto interrupt_10;
 }

 write__one_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 write__one_6_clear_reason:
  reasonp = reasons;
 write__one_6_0:
 write__one_6_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto write__one_6_90;
  switch (symval(a0)) {
 case symval(makesym(atom_case__default)):
  unify(a3, a2);
  a0 = makefunctor(&string_const_3);
  a1 = NILATOM;
  a2 = a4;
  a3 = a5;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case symval(makesym(atom_end__sw)):
  unify(a3, a2);
  a0 = makefunctor(&string_const_4);
  a1 = NILATOM;
  a2 = a4;
  a3 = a5;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case symval(makesym(atom_otherwise)):
  unify(a3, a2);
  allocp[0] = makecons(cons_const_6);
  allocp[1] = a1;
  x0 = makecons(&allocp[0]);
  a0 = makefunctor(&string_const_5);
  a1 = x0;
  a2 = a4;
  a3 = a5;
  allocp += 2;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case symval(makesym(atom_alternatively)):
  unify(a3, a2);
  allocp[0] = makecons(cons_const_8);
  allocp[1] = a1;
  x0 = makecons(&allocp[0]);
  a0 = makefunctor(&string_const_7);
  a1 = x0;
  a2 = a4;
  a3 = a5;
  allocp += 2;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 default:
  goto write__one_6_90;
  };
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_label_1:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a1;
  x2 = makecons(&allocp[2]);
  a0 = makefunctor(&string_const_9);
  a1 = x2;
  a2 = a4;
  a3 = a5;
  allocp += 4;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_begin__body_3:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 1);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a1;
  x2 = makecons(&allocp[2]);
  a0 = makefunctor(&string_const_9);
  a1 = x2;
  a2 = a4;
  a3 = a5;
  allocp += 4;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_move_2:
  unify(a3, a2);
  x0 = arg(a0, 0);
  a1 = arg(a0, 1);
  a2 = a4;
  a3 = a5;
  a0 = x0;
  execute(write__one__move_4_0);
  goto write__one__move_4_ext_interrupt;
 case functor_get__elem_3:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 2);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  x3 = arg(a0, 1);
  allocp[3] = x3;
  x2 = makecons(&allocp[2]);
  allocp[4] = x2;
  x5 = arg(a0, 0);
  allocp[5] = x5;
  x4 = makecons(&allocp[4]);
  a0 = makefunctor(&string_const_10);
  a1 = x4;
  a2 = a4;
  a3 = a5;
  allocp += 6;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_get__velem_3:
  unify(a3, a2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[2] = makefunctor(&string_const_11);
  allocp[3] = NILATOM;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = a5;
  allocp[6] = NILATOM;
  x2 = arg(a0, 2);
  allocp[7] = x2;
  x1 = makecons(&allocp[6]);
  allocp[8] = x1;
  x4 = arg(a0, 1);
  allocp[9] = x4;
  x3 = makecons(&allocp[8]);
  allocp[10] = x3;
  x6 = arg(a0, 0);
  allocp[11] = x6;
  x5 = makecons(&allocp[10]);
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[14] = makefunctor(&string_const_12);
  allocp[15] = x5;
  allocp[16] = x7 = makeref(&allocp[16]);
  allocp[17] = x0;
  allocp[18] = (q)(struct goalrec*)&allocp[12];
  allocp[19] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[20] = makefunctor(&string_const_13);
  allocp[21] = NILATOM;
  allocp[22] = x8 = makeref(&allocp[22]);
  allocp[23] = x7;
  a0 = makefunctor(&string_const_14);
  a1 = NILATOM;
  a2 = a4;
  a3 = x8;
  qp = (struct goalrec*)&allocp[18];
  allocp += 24;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_deref_3:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 2);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a1;
  x2 = makecons(&allocp[2]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[6] = makefunctor(&string_const_17);
  allocp[7] = x2;
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = a5;
  allocp[10] = NILATOM;
  x5 = arg(a0, 0);
  allocp[11] = x5;
  x4 = makecons(&allocp[10]);
  allocp[12] = (q)(struct goalrec*)&allocp[4];
  allocp[13] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[14] = makefunctor(&string_const_16);
  allocp[15] = x4;
  allocp[16] = x6 = makeref(&allocp[16]);
  allocp[17] = x3;
  allocp[18] = NILATOM;
  x8 = arg(a0, 1);
  allocp[19] = x8;
  x7 = makecons(&allocp[18]);
  allocp[20] = x7;
  allocp[21] = a1;
  x9 = makecons(&allocp[20]);
  allocp[22] = x9;
  allocp[23] = x5;
  x10 = makecons(&allocp[22]);
  a0 = makefunctor(&string_const_15);
  a1 = x10;
  a2 = a4;
  a3 = x6;
  qp = (struct goalrec*)&allocp[12];
  allocp += 24;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_push__reason_2:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  a0 = makefunctor(&string_const_16);
  a1 = x0;
  a2 = a4;
  a3 = a5;
  allocp += 2;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_goto_1:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a1;
  x2 = makecons(&allocp[2]);
  a0 = makefunctor(&string_const_17);
  a1 = x2;
  a2 = a4;
  a3 = a5;
  allocp += 4;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_sw__tag_1:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  a0 = makefunctor(&string_const_18);
  a1 = x0;
  a2 = a4;
  a3 = a5;
  allocp += 2;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_sw__atag_1:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  a0 = makefunctor(&string_const_19);
  a1 = x0;
  a2 = a4;
  a3 = a5;
  allocp += 2;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_sw__sym_1:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  a0 = makefunctor(&string_const_20);
  a1 = x0;
  a2 = a4;
  a3 = a5;
  allocp += 2;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_sw__int_1:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  a0 = makefunctor(&string_const_21);
  a1 = x0;
  a2 = a4;
  a3 = a5;
  allocp += 2;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_sw__funct_1:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  a0 = makefunctor(&string_const_22);
  a1 = x0;
  a2 = a4;
  a3 = a5;
  allocp += 2;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_case__label_1:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  a0 = makefunctor(&string_const_23);
  a1 = x0;
  a2 = a4;
  a3 = a5;
  allocp += 2;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_case__sym_1:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  a0 = makefunctor(&string_const_24);
  a1 = x0;
  a2 = a4;
  a3 = a5;
  allocp += 2;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_case__int_1:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  a0 = makefunctor(&string_const_25);
  a1 = x0;
  a2 = a4;
  a3 = a5;
  allocp += 2;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_case__funct_1:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  a0 = makefunctor(&string_const_26);
  a1 = x0;
  a2 = a4;
  a3 = a5;
  allocp += 2;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_eq_5:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 4);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a1;
  x2 = makecons(&allocp[2]);
  allocp[4] = x2;
  x4 = arg(a0, 3);
  allocp[5] = x4;
  x3 = makecons(&allocp[4]);
  allocp[6] = x3;
  allocp[7] = a1;
  x5 = makecons(&allocp[6]);
  allocp[8] = x5;
  x7 = arg(a0, 2);
  allocp[9] = x7;
  x6 = makecons(&allocp[8]);
  allocp[10] = x6;
  allocp[11] = a1;
  x8 = makecons(&allocp[10]);
  allocp[12] = x8;
  x10 = arg(a0, 1);
  allocp[13] = x10;
  x9 = makecons(&allocp[12]);
  allocp[14] = x9;
  x12 = arg(a0, 0);
  allocp[15] = x12;
  x11 = makecons(&allocp[14]);
  a0 = makefunctor(&string_const_27);
  a1 = x11;
  a2 = a4;
  a3 = a5;
  allocp += 16;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_if__not__eq_3:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 2);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a1;
  x2 = makecons(&allocp[2]);
  allocp[4] = x2;
  x4 = arg(a0, 1);
  allocp[5] = x4;
  x3 = makecons(&allocp[4]);
  allocp[6] = x3;
  x6 = arg(a0, 0);
  allocp[7] = x6;
  x5 = makecons(&allocp[6]);
  a0 = makefunctor(&string_const_28);
  a1 = x5;
  a2 = a4;
  a3 = a5;
  allocp += 8;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_if__int_2:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 1);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a1;
  x2 = makecons(&allocp[2]);
  allocp[4] = x2;
  x4 = arg(a0, 0);
  allocp[5] = x4;
  x3 = makecons(&allocp[4]);
  a0 = makefunctor(&string_const_29);
  a1 = x3;
  a2 = a4;
  a3 = a5;
  allocp += 6;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_if__not__int_2:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 1);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a1;
  x2 = makecons(&allocp[2]);
  allocp[4] = x2;
  x4 = arg(a0, 0);
  allocp[5] = x4;
  x3 = makecons(&allocp[4]);
  a0 = makefunctor(&string_const_30);
  a1 = x3;
  a2 = a4;
  a3 = a5;
  allocp += 6;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_if__list_2:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 1);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a1;
  x2 = makecons(&allocp[2]);
  allocp[4] = x2;
  x4 = arg(a0, 0);
  allocp[5] = x4;
  x3 = makecons(&allocp[4]);
  a0 = makefunctor(&string_const_31);
  a1 = x3;
  a2 = a4;
  a3 = a5;
  allocp += 6;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_if__not__list_2:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 1);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a1;
  x2 = makecons(&allocp[2]);
  allocp[4] = x2;
  x4 = arg(a0, 0);
  allocp[5] = x4;
  x3 = makecons(&allocp[4]);
  a0 = makefunctor(&string_const_32);
  a1 = x3;
  a2 = a4;
  a3 = a5;
  allocp += 6;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_if__funct_2:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 1);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a1;
  x2 = makecons(&allocp[2]);
  allocp[4] = x2;
  x4 = arg(a0, 0);
  allocp[5] = x4;
  x3 = makecons(&allocp[4]);
  a0 = makefunctor(&string_const_33);
  a1 = x3;
  a2 = a4;
  a3 = a5;
  allocp += 6;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_if__not__funct_2:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 1);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a1;
  x2 = makecons(&allocp[2]);
  allocp[4] = x2;
  x4 = arg(a0, 0);
  allocp[5] = x4;
  x3 = makecons(&allocp[4]);
  a0 = makefunctor(&string_const_34);
  a1 = x3;
  a2 = a4;
  a3 = a5;
  allocp += 6;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_if__not__gobj_2:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 1);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a1;
  x2 = makecons(&allocp[2]);
  allocp[4] = x2;
  x4 = arg(a0, 0);
  allocp[5] = x4;
  x3 = makecons(&allocp[4]);
  a0 = makefunctor(&string_const_35);
  a1 = x3;
  a2 = a4;
  a3 = a5;
  allocp += 6;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_if__not__class_3:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 2);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a1;
  x2 = makecons(&allocp[2]);
  allocp[4] = x2;
  x4 = arg(a0, 1);
  allocp[5] = x4;
  x3 = makecons(&allocp[4]);
  allocp[6] = x3;
  x6 = arg(a0, 0);
  allocp[7] = x6;
  x5 = makecons(&allocp[6]);
  a0 = makefunctor(&string_const_36);
  a1 = x5;
  a2 = a4;
  a3 = a5;
  allocp += 8;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_if__ref_2:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 1);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a1;
  x2 = makecons(&allocp[2]);
  allocp[4] = x2;
  x4 = arg(a0, 0);
  allocp[5] = x4;
  x3 = makecons(&allocp[4]);
  a0 = makefunctor(&string_const_37);
  a1 = x3;
  a2 = a4;
  a3 = a5;
  allocp += 6;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_if__not__ref_2:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 1);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a1;
  x2 = makecons(&allocp[2]);
  allocp[4] = x2;
  x4 = arg(a0, 0);
  allocp[5] = x4;
  x3 = makecons(&allocp[4]);
  a0 = makefunctor(&string_const_38);
  a1 = x3;
  a2 = a4;
  a3 = a5;
  allocp += 6;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_if__funct__not_3:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 2);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a1;
  x2 = makecons(&allocp[2]);
  allocp[4] = x2;
  x4 = arg(a0, 1);
  allocp[5] = x4;
  x3 = makecons(&allocp[4]);
  allocp[6] = x3;
  x6 = arg(a0, 0);
  allocp[7] = x6;
  x5 = makecons(&allocp[6]);
  a0 = makefunctor(&string_const_39);
  a1 = x5;
  a2 = a4;
  a3 = a5;
  allocp += 8;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_if__not_3:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 2);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a1;
  x2 = makecons(&allocp[2]);
  allocp[4] = x2;
  x4 = arg(a0, 1);
  allocp[5] = x4;
  x3 = makecons(&allocp[4]);
  allocp[6] = x3;
  x6 = arg(a0, 0);
  allocp[7] = x6;
  x5 = makecons(&allocp[6]);
  a0 = makefunctor(&string_const_40);
  a1 = x5;
  a2 = a4;
  a3 = a5;
  allocp += 8;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_inline_3:
  unify(a3, a2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__obj_xwrite__inline_6);
  x0 = arg(a0, 0);
  allocp[2] = x0;
  x1 = arg(a0, 1);
  allocp[3] = x1;
  allocp[4] = a1;
  x2 = arg(a0, 2);
  allocp[5] = x2;
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = a5;
  a0 = makefunctor(&string_const_41);
  a1 = NILATOM;
  a2 = a4;
  a3 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_load__atom_2:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 1);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  x3 = arg(a0, 0);
  allocp[3] = x3;
  x2 = makecons(&allocp[2]);
  a0 = makefunctor(&string_const_42);
  a1 = x2;
  a2 = a4;
  a3 = a5;
  allocp += 4;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_load__const_2:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 1);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  x3 = arg(a0, 0);
  allocp[3] = x3;
  x2 = makecons(&allocp[2]);
  a0 = makefunctor(&string_const_43);
  a1 = x2;
  a2 = a4;
  a3 = a5;
  allocp += 4;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_load__newvar_1:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[2] = a2;
  allocp[3] = makeint(1L);
  allocp[4] = a3;
  allocp[5] = NILATOM;
  allocp[6] = a2;
  x0 = makecons(&allocp[5]);
  allocp[7] = x0;
  x2 = arg(a0, 0);
  allocp[8] = x2;
  x1 = makecons(&allocp[7]);
  allocp[9] = x1;
  allocp[10] = a2;
  x3 = makecons(&allocp[9]);
  a0 = makefunctor(&string_const_60);
  a1 = x3;
  a2 = a4;
  a3 = a5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 11;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_make__cons_1:
  unify(a3, a2);
  allocp[0] = NILATOM;
  allocp[1] = a2;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  x2 = arg(a0, 0);
  allocp[3] = x2;
  x1 = makecons(&allocp[2]);
  a0 = makefunctor(&string_const_44);
  a1 = x1;
  a2 = a4;
  a3 = a5;
  allocp += 4;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_make__functor_1:
  unify(a3, a2);
  allocp[0] = NILATOM;
  allocp[1] = a2;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  x2 = arg(a0, 0);
  allocp[3] = x2;
  x1 = makecons(&allocp[2]);
  a0 = makefunctor(&string_const_45);
  a1 = x1;
  a2 = a4;
  a3 = a5;
  allocp += 4;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_make__vector_2:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 1);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a2;
  x2 = makecons(&allocp[2]);
  allocp[4] = x2;
  x4 = arg(a0, 0);
  allocp[5] = x4;
  x3 = makecons(&allocp[4]);
  a0 = makefunctor(&string_const_46);
  a1 = x3;
  a2 = a4;
  a3 = a5;
  allocp += 6;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_alloc__functor__id_2:
  unify(a3, a2);
  allocp[0] = makesym(functor__2F_2);
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x2 = arg(a0, 1);
  allocp[2] = x2;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = NILATOM;
  allocp[4] = x0;
  x3 = makecons(&allocp[3]);
  allocp[5] = x3;
  allocp[6] = a2;
  x4 = makecons(&allocp[5]);
  a0 = makefunctor(&string_const_47);
  a1 = x4;
  a2 = a4;
  a3 = a5;
  allocp += 7;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_alloc__atomic_2:
  unify(a3, a2);
  x0 = arg(a0, 1);
  bblt_add(a2,x0,x1);
  allocp[0] = NILATOM;
  x3 = arg(a0, 0);
  allocp[1] = x3;
  x2 = makecons(&allocp[0]);
  allocp[2] = x2;
  allocp[3] = x1;
  x4 = makecons(&allocp[2]);
  a0 = makefunctor(&string_const_59);
  a1 = x4;
  a2 = a4;
  a3 = a5;
  allocp += 4;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_alloc__value_2:
  unify(a3, a2);
  x0 = arg(a0, 1);
  bblt_add(a2,x0,x1);
  allocp[0] = NILATOM;
  x3 = arg(a0, 0);
  allocp[1] = x3;
  x2 = makecons(&allocp[0]);
  allocp[2] = x2;
  allocp[3] = x1;
  x4 = makecons(&allocp[2]);
  a0 = makefunctor(&string_const_58);
  a1 = x4;
  a2 = a4;
  a3 = a5;
  allocp += 4;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_alloc__var_2:
  unify(a3, a2);
  x0 = arg(a0, 1);
  bblt_add(a2,x0,x1);
  allocp[0] = NILATOM;
  allocp[1] = x1;
  x2 = makecons(&allocp[0]);
  allocp[2] = x2;
  x4 = arg(a0, 0);
  allocp[3] = x4;
  x3 = makecons(&allocp[2]);
  allocp[4] = x3;
  allocp[5] = x1;
  x5 = makecons(&allocp[4]);
  a0 = makefunctor(&string_const_60);
  a1 = x5;
  a2 = a4;
  a3 = a5;
  allocp += 6;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_alloc__elem_3:
  unify(a3, a2);
  x0 = arg(a0, 2);
  bblt_add(a2,x0,x1);
  allocp[0] = NILATOM;
  x3 = arg(a0, 1);
  allocp[1] = x3;
  x2 = makecons(&allocp[0]);
  allocp[2] = x2;
  x5 = arg(a0, 0);
  allocp[3] = x5;
  x4 = makecons(&allocp[2]);
  allocp[4] = x4;
  allocp[5] = x1;
  x6 = makecons(&allocp[4]);
  a0 = makefunctor(&string_const_61);
  a1 = x6;
  a2 = a4;
  a3 = a5;
  allocp += 6;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_alloc__const_2:
  unify(a3, a2);
  x0 = arg(a0, 1);
  bblt_add(a2,x0,x1);
  allocp[0] = NILATOM;
  x3 = arg(a0, 0);
  allocp[1] = x3;
  x2 = makecons(&allocp[0]);
  allocp[2] = x2;
  allocp[3] = x1;
  x4 = makecons(&allocp[2]);
  a0 = makefunctor(&string_const_62);
  a1 = x4;
  a2 = a4;
  a3 = a5;
  allocp += 4;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_make__space_1:
  unify(a5, a4);
  x0 = arg(a0, 0);
  bblt_add(a2,x0,x1);
  unify(a3, x1);
  proceed();
 case functor_unify_3:
  unify_value(a3, makeint(0L));
  allocp[0] = NILATOM;
  x1 = arg(a0, 1);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  x3 = arg(a0, 0);
  allocp[3] = x3;
  x2 = makecons(&allocp[2]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[6] = makefunctor(&string_const_48);
  allocp[7] = x2;
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = a5;
  allocp[10] = (q)(struct goalrec*)&allocp[4];
  allocp[11] = (q)(&predicate_klic__comp__obj_xwrite__adjust__allocp_3);
  allocp[12] = a2;
  allocp[13] = x5 = makeref(&allocp[13]);
  allocp[14] = x4;
  a0 = arg(a0, 2);
  a1 = a4;
  a2 = x5;
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  execute(write__adjust__qp_3_0);
  goto write__adjust__qp_3_ext_interrupt;
 case functor_unify__value_3:
  unify_value(a3, makeint(0L));
  allocp[0] = NILATOM;
  x1 = arg(a0, 1);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  x3 = arg(a0, 0);
  allocp[3] = x3;
  x2 = makecons(&allocp[2]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[6] = makefunctor(&string_const_49);
  allocp[7] = x2;
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = a5;
  allocp[10] = (q)(struct goalrec*)&allocp[4];
  allocp[11] = (q)(&predicate_klic__comp__obj_xwrite__adjust__allocp_3);
  allocp[12] = a2;
  allocp[13] = x5 = makeref(&allocp[13]);
  allocp[14] = x4;
  a0 = arg(a0, 2);
  a1 = a4;
  a2 = x5;
  qp = (struct goalrec*)&allocp[10];
  allocp += 15;
  execute(write__adjust__qp_3_0);
  goto write__adjust__qp_3_ext_interrupt;
 case functor_execute_4:
  unify_value(a3, makeint(0L));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__obj_xwrite__one__execute_5);
  x0 = arg(a0, 0);
  allocp[2] = x0;
  x1 = arg(a0, 1);
  allocp[3] = x1;
  x2 = arg(a0, 2);
  allocp[4] = x2;
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = a5;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_klic__comp__obj_xwrite__adjust__allocp_3);
  allocp[9] = a2;
  allocp[10] = x4 = makeref(&allocp[10]);
  allocp[11] = x3;
  a0 = arg(a0, 3);
  a1 = a4;
  a2 = x4;
  qp = (struct goalrec*)&allocp[7];
  allocp += 12;
  execute(write__adjust__qp_3_0);
  goto write__adjust__qp_3_ext_interrupt;
 case functor_proceed_1:
  unify_value(a3, makeint(0L));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[2] = makefunctor(&string_const_50);
  allocp[3] = NILATOM;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = a5;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_klic__comp__obj_xwrite__adjust__allocp_3);
  allocp[8] = a2;
  allocp[9] = x1 = makeref(&allocp[9]);
  allocp[10] = x0;
  a0 = arg(a0, 0);
  a1 = a4;
  a2 = x1;
  qp = (struct goalrec*)&allocp[6];
  allocp += 11;
  execute(write__adjust__qp_3_0);
  goto write__adjust__qp_3_ext_interrupt;
 case functor_set__pred_2:
 write__one_6_59:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_info_1)) goto write__one_6_90;
  x0 = arg(a1, 0);
 write__one_6_62:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__2F_2)) goto write__one_6_90;
  x1 = arg(x0, 0);
 write__one_6_65:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor__2F_2)) goto write__one_6_90;
  unify(a3, a2);
  bblt_add_no_check_y(a2,makeint(1L),x2);
  allocp[0] = makesym(functor__2F_2);
  x4 = arg(x1, 0);
  allocp[1] = x4;
  x5 = arg(a0, 0);
  allocp[2] = x5;
  x3 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor__2F_2);
  allocp[4] = x3;
  x7 = arg(a0, 1);
  allocp[5] = x7;
  x6 = makefunctor(&allocp[3]);
  allocp[6] = NILATOM;
  allocp[7] = x6;
  x8 = makecons(&allocp[6]);
  allocp[8] = x8;
  allocp[9] = x2;
  x9 = makecons(&allocp[8]);
  a0 = makefunctor(&string_const_51);
  a1 = x9;
  a2 = a4;
  a3 = a5;
  allocp += 10;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,write__one_6_65);
  *reasonp++ =  x1;
  goto write__one_6_90;
  };
  goto write__one_6_90;
 case VARREF:
  deref_and_jump(x0,write__one_6_62);
  *reasonp++ =  x0;
  goto write__one_6_90;
  };
  goto write__one_6_90;
 case VARREF:
  deref_and_jump(a1,write__one_6_59);
  *reasonp++ =  a1;
  goto write__one_6_90;
  };
  goto write__one_6_90;
 case functor_set__ext__pred_3:
  unify(a3, a2);
  bblt_add_no_check_y(a2,makeint(1L),x0);
  allocp[0] = makesym(functor__2F_2);
  x2 = arg(a0, 0);
  allocp[1] = x2;
  x3 = arg(a0, 1);
  allocp[2] = x3;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor__2F_2);
  allocp[4] = x1;
  x5 = arg(a0, 2);
  allocp[5] = x5;
  x4 = makefunctor(&allocp[3]);
  allocp[6] = NILATOM;
  allocp[7] = x4;
  x6 = makecons(&allocp[6]);
  allocp[8] = x6;
  allocp[9] = x0;
  x7 = makecons(&allocp[8]);
  a0 = makefunctor(&string_const_51);
  a1 = x7;
  a2 = a4;
  a3 = a5;
  allocp += 10;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_heappos_1:
  unify(a3, a2);
  x0 = arg(a0, 0);
  unify2(x0, a3, a5, a4);
  proceed();
 case functor_push__goal_2:
  unify(a3, a2);
  x0 = arg(a0, 1);
  unify(x0, a3);
  allocp[0] = NILATOM;
  x2 = arg(a0, 0);
  allocp[1] = x2;
  x1 = makecons(&allocp[0]);
  allocp[2] = x1;
  allocp[3] = x0;
  x3 = makecons(&allocp[2]);
  a0 = makefunctor(&string_const_52);
  a1 = x3;
  a2 = a4;
  a3 = a5;
  allocp += 4;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_throw__goal_3:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 2);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  x3 = arg(a0, 1);
  allocp[3] = x3;
  x2 = makecons(&allocp[2]);
  allocp[4] = x2;
  x5 = arg(a0, 0);
  allocp[5] = x5;
  x4 = makecons(&allocp[4]);
  a0 = makefunctor(&string_const_53);
  a1 = x4;
  a2 = a4;
  a3 = a5;
  allocp += 6;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_enq__at__prio_3:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 2);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  x3 = arg(a0, 1);
  allocp[3] = x3;
  x2 = makecons(&allocp[2]);
  allocp[4] = x2;
  x5 = arg(a0, 0);
  allocp[5] = x5;
  x4 = makecons(&allocp[4]);
  a0 = makefunctor(&string_const_54);
  a1 = x4;
  a2 = a4;
  a3 = a5;
  allocp += 6;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_enq__at__lower__prio_3:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 2);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  x3 = arg(a0, 1);
  allocp[3] = x3;
  x2 = makecons(&allocp[2]);
  allocp[4] = x2;
  x5 = arg(a0, 0);
  allocp[5] = x5;
  x4 = makecons(&allocp[4]);
  a0 = makefunctor(&string_const_55);
  a1 = x4;
  a2 = a4;
  a3 = a5;
  allocp += 6;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_enq__at__prio__no__check_3:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 2);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  x3 = arg(a0, 1);
  allocp[3] = x3;
  x2 = makecons(&allocp[2]);
  allocp[4] = x2;
  x5 = arg(a0, 0);
  allocp[5] = x5;
  x4 = makecons(&allocp[4]);
  a0 = makefunctor(&string_const_56);
  a1 = x4;
  a2 = a4;
  a3 = a5;
  allocp += 6;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_enq__at__lower__prio__no__check_3:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 2);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  x3 = arg(a0, 1);
  allocp[3] = x3;
  x2 = makecons(&allocp[2]);
  allocp[4] = x2;
  x5 = arg(a0, 0);
  allocp[5] = x5;
  x4 = makecons(&allocp[4]);
  a0 = makefunctor(&string_const_57);
  a1 = x4;
  a2 = a4;
  a3 = a5;
  allocp += 6;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_set__value_2:
  unify(a3, a2);
  x0 = arg(a0, 0);
  bblt_add(x0,a2,x1);
  bblt_add_no_check_y(x1,makeint(2L),x2);
  allocp[0] = NILATOM;
  x4 = arg(a0, 1);
  allocp[1] = x4;
  x3 = makecons(&allocp[0]);
  allocp[2] = x3;
  allocp[3] = x2;
  x5 = makecons(&allocp[2]);
  a0 = makefunctor(&string_const_58);
  a1 = x5;
  a2 = a4;
  a3 = a5;
  allocp += 4;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_set__atomic_2:
  unify(a3, a2);
  x0 = arg(a0, 0);
  bblt_add(x0,a2,x1);
  bblt_add_no_check_y(x1,makeint(2L),x2);
  allocp[0] = NILATOM;
  x4 = arg(a0, 1);
  allocp[1] = x4;
  x3 = makecons(&allocp[0]);
  allocp[2] = x3;
  allocp[3] = x2;
  x5 = makecons(&allocp[2]);
  a0 = makefunctor(&string_const_59);
  a1 = x5;
  a2 = a4;
  a3 = a5;
  allocp += 4;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_set__newvar_2:
  unify(a3, a2);
  x0 = arg(a0, 0);
  bblt_add(x0,a2,x1);
  bblt_add_no_check_y(x1,makeint(2L),x2);
  allocp[0] = NILATOM;
  allocp[1] = x2;
  x3 = makecons(&allocp[0]);
  allocp[2] = x3;
  x5 = arg(a0, 1);
  allocp[3] = x5;
  x4 = makecons(&allocp[2]);
  allocp[4] = x4;
  allocp[5] = x2;
  x6 = makecons(&allocp[4]);
  a0 = makefunctor(&string_const_60);
  a1 = x6;
  a2 = a4;
  a3 = a5;
  allocp += 6;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_set__elem_3:
  unify(a3, a2);
  x0 = arg(a0, 0);
  bblt_add(x0,a2,x1);
  bblt_add_no_check_y(x1,makeint(2L),x2);
  allocp[0] = NILATOM;
  x4 = arg(a0, 2);
  allocp[1] = x4;
  x3 = makecons(&allocp[0]);
  allocp[2] = x3;
  x6 = arg(a0, 1);
  allocp[3] = x6;
  x5 = makecons(&allocp[2]);
  allocp[4] = x5;
  allocp[5] = x2;
  x7 = makecons(&allocp[4]);
  a0 = makefunctor(&string_const_61);
  a1 = x7;
  a2 = a4;
  a3 = a5;
  allocp += 6;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_set__const_2:
  unify(a3, a2);
  x0 = arg(a0, 0);
  bblt_add(x0,a2,x1);
  bblt_add_no_check_y(x1,makeint(2L),x2);
  allocp[0] = NILATOM;
  x4 = arg(a0, 1);
  allocp[1] = x4;
  x3 = makecons(&allocp[0]);
  allocp[2] = x3;
  allocp[3] = x2;
  x5 = makecons(&allocp[2]);
  a0 = makefunctor(&string_const_62);
  a1 = x5;
  a2 = a4;
  a3 = a5;
  allocp += 4;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_bblt_4:
  unify(a3, a2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__obj_xwrite__one__bblt_6);
  x0 = arg(a0, 0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  x2 = arg(a0, 1);
  allocp[4] = x2;
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_klic__comp__util_xlength_2);
  x4 = arg(a0, 2);
  allocp[10] = x4;
  allocp[11] = x1;
  allocp[12] = (q)(struct goalrec*)&allocp[8];
  allocp[13] = (q)(&predicate_klic__comp__util_xappend_3);
  allocp[14] = x4;
  x5 = arg(a0, 3);
  allocp[15] = x5;
  allocp[16] = x3;
  qp = (struct goalrec*)&allocp[12];
  allocp += 17;
  proceed();
 case functor_gblt_5:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 4);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a1;
  x2 = makecons(&allocp[2]);
  allocp[4] = x2;
  x4 = arg(a0, 3);
  allocp[5] = x4;
  x3 = makecons(&allocp[4]);
  allocp[6] = x3;
  x6 = arg(a0, 2);
  allocp[7] = x6;
  x5 = makecons(&allocp[6]);
  allocp[8] = x5;
  x8 = arg(a0, 0);
  allocp[9] = x8;
  x7 = makecons(&allocp[8]);
  a0 = makefunctor(&string_const_63);
  a1 = x7;
  a2 = a4;
  a3 = a5;
  allocp += 10;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_gblt__pred_4:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 3);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a1;
  x2 = makecons(&allocp[2]);
  allocp[4] = x2;
  x4 = arg(a0, 2);
  allocp[5] = x4;
  x3 = makecons(&allocp[4]);
  allocp[6] = x3;
  x6 = arg(a0, 0);
  allocp[7] = x6;
  x5 = makecons(&allocp[6]);
  a0 = makefunctor(&string_const_64);
  a1 = x5;
  a2 = a4;
  a3 = a5;
  allocp += 8;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_equiv_2:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  x3 = arg(a0, 1);
  allocp[3] = x3;
  x2 = makecons(&allocp[2]);
  a0 = makefunctor(&string_const_71);
  a1 = x2;
  a2 = a4;
  a3 = a5;
  allocp += 4;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_new__generic_4:
  unify_value(a3, makeint(0L));
  allocp[0] = NILATOM;
  allocp[1] = a2;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  x2 = arg(a0, 2);
  allocp[3] = x2;
  x1 = makecons(&allocp[2]);
  allocp[4] = x1;
  x4 = arg(a0, 1);
  allocp[5] = x4;
  x3 = makecons(&allocp[4]);
  allocp[6] = x3;
  x6 = arg(a0, 0);
  allocp[7] = x6;
  x5 = makecons(&allocp[6]);
  allocp[8] = (q)qp;
  allocp[9] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[10] = makefunctor(&string_const_65);
  allocp[11] = x5;
  allocp[12] = x7 = makeref(&allocp[12]);
  allocp[13] = a5;
  a0 = arg(a0, 3);
  a1 = a4;
  a2 = x7;
  qp = (struct goalrec*)&allocp[8];
  allocp += 14;
  execute(write__adjust__qp_3_0);
  goto write__adjust__qp_3_ext_interrupt;
 case functor_call__generic_3:
  unify_value(a3, makeint(0L));
  allocp[0] = NILATOM;
  allocp[1] = a2;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  x2 = arg(a0, 1);
  allocp[3] = x2;
  x1 = makecons(&allocp[2]);
  allocp[4] = x1;
  x4 = arg(a0, 0);
  allocp[5] = x4;
  x3 = makecons(&allocp[4]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[8] = makefunctor(&string_const_66);
  allocp[9] = x3;
  allocp[10] = x5 = makeref(&allocp[10]);
  allocp[11] = a5;
  a0 = arg(a0, 2);
  a1 = a4;
  a2 = x5;
  qp = (struct goalrec*)&allocp[6];
  allocp += 12;
  execute(write__adjust__qp_3_0);
  goto write__adjust__qp_3_ext_interrupt;
 case functor_guard__generic_4:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 3);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a1;
  x2 = makecons(&allocp[2]);
  allocp[4] = x2;
  x4 = arg(a0, 2);
  allocp[5] = x4;
  x3 = makecons(&allocp[4]);
  allocp[6] = x3;
  x6 = arg(a0, 1);
  allocp[7] = x6;
  x5 = makecons(&allocp[6]);
  allocp[8] = x5;
  x8 = arg(a0, 0);
  allocp[9] = x8;
  x7 = makecons(&allocp[8]);
  a0 = makefunctor(&string_const_67);
  a1 = x7;
  a2 = a4;
  a3 = a5;
  allocp += 10;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_store__generic__arg_2:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  x3 = arg(a0, 1);
  allocp[3] = x3;
  x2 = makecons(&allocp[2]);
  a0 = makefunctor(&string_const_68);
  a1 = x2;
  a2 = a4;
  a3 = a5;
  allocp += 4;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_load__generic__arg_2:
  unify(a3, a2);
  allocp[0] = NILATOM;
  x1 = arg(a0, 1);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  x3 = arg(a0, 0);
  allocp[3] = x3;
  x2 = makecons(&allocp[2]);
  a0 = makefunctor(&string_const_69);
  a1 = x2;
  a2 = a4;
  a3 = a5;
  allocp += 4;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 default:
  goto write__one_6_90;
  };
 case VARREF:
  deref_and_jump(a0,write__one_6_1);
  *reasonp++ =  a0;
  goto write__one_6_90;
  };
  goto write__one_6_90;
 write__one_6_90:
  otherwise(write__one_6_interrupt);
  unify2(a5, a4, a3, a2);
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__kl1cmp_xwarning_2);
  allocp[4] = makefunctor(&string_const_70);
  allocp[5] = x0;
  qp = (struct goalrec*)&allocp[2];
  allocp += 6;
  proceed();
 write__one_6_ext_interrupt:
  reasonp = 0l;
 write__one_6_interrupt:
  toppred = &predicate_klic__comp__obj_xwrite__one_6;
  goto interrupt_6;
 }

 write__one__move_4_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 write__one__move_4_clear_reason:
  reasonp = reasons;
 write__one__move_4_0:
 write__one__move_4_1:
  if (isref(a0)) goto write__one__move_4_7;
 write__one__move_4_3:
  if (isref(a0)) goto write__one__move_4_6;
  if_not_equal(a0, a1, write__one__move_4_8);
  unify(a3, a2);
  proceed();
 write__one__move_4_6:
  deref_and_jump(a0,write__one__move_4_3);
  *reasonp++ =  a0;
  goto write__one__move_4_8;
 write__one__move_4_7:
  deref_and_jump(a0,write__one__move_4_1);
  *reasonp++ =  a0;
  goto write__one__move_4_8;
 write__one__move_4_8:
  otherwise(write__one__move_4_interrupt);
  allocp[0] = NILATOM;
  allocp[1] = a1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a0;
  x1 = makecons(&allocp[2]);
  a0 = makefunctor(&string_const_71);
  a1 = x1;
  allocp += 4;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 write__one__move_4_ext_interrupt:
  reasonp = 0l;
 write__one__move_4_interrupt:
  toppred = &predicate_klic__comp__obj_xwrite__one__move_4;
  goto interrupt_4;
 }

 write__one__execute_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 write__one__execute_5_clear_reason:
  reasonp = reasons;
 write__one__execute_5_0:
 write__one__execute_5_1:
  if (!isint(a2)) goto write__one__execute_5_6;
  gblt_not_eq(a2,makeint(0L),write__one__execute_5_4);
  allocp[0] = NILATOM;
  allocp[1] = a1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a0;
  x1 = makecons(&allocp[2]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[6] = makefunctor(&string_const_73);
  allocp[7] = x1;
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = a4;
  allocp[10] = NILATOM;
  allocp[11] = a1;
  x3 = makecons(&allocp[10]);
  allocp[12] = x3;
  allocp[13] = a0;
  x4 = makecons(&allocp[12]);
  a0 = makefunctor(&string_const_72);
  a1 = x4;
  a2 = a3;
  a3 = x2;
  qp = (struct goalrec*)&allocp[4];
  allocp += 14;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 write__one__execute_5_4:
  if (a2 != makeint(0L)) goto write__one__execute_5_interrupt;
  allocp[0] = NILATOM;
  allocp[1] = a1;
  x5 = makecons(&allocp[0]);
  allocp[2] = x5;
  allocp[3] = a0;
  x6 = makecons(&allocp[2]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[6] = makefunctor(&string_const_73);
  allocp[7] = x6;
  allocp[8] = x7 = makeref(&allocp[8]);
  allocp[9] = a4;
  allocp[10] = NILATOM;
  allocp[11] = a1;
  x8 = makecons(&allocp[10]);
  allocp[12] = x8;
  allocp[13] = a0;
  x9 = makecons(&allocp[12]);
  a0 = makefunctor(&string_const_74);
  a1 = x9;
  a2 = a3;
  a3 = x7;
  qp = (struct goalrec*)&allocp[4];
  allocp += 14;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 write__one__execute_5_6:
  if (!isref(a2)) goto write__one__execute_5_interrupt;
  deref_and_jump(a2,write__one__execute_5_1);
  *reasonp++ =  a2;
  goto write__one__execute_5_interrupt;
 write__one__execute_5_ext_interrupt:
  reasonp = 0l;
 write__one__execute_5_interrupt:
  goto interrupt_5;
 }

 write__one__bblt_6_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 write__one__bblt_6_clear_reason:
  reasonp = reasons;
 write__one__bblt_6_0:
 write__one__bblt_6_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 write__one__bblt_6_3:
  switch (ptagof(x0)) {
 case ATOMIC:
 write__one__bblt_6_5:
  switch ((unsigned long)x0) {
 case (unsigned long) makeint(1L):
  x1 = cdr_of(a0);
 write__one__bblt_6_7:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto write__one__bblt_6_24;
 write__one__bblt_6_11:
  switch (ptagof(a1)) {
 case ATOMIC:
 write__one__bblt_6_13:
  switch ((unsigned long)a1) {
 case (unsigned long) makeint(1L):
  allocp[0] = NILATOM;
  allocp[1] = a3;
  x2 = makecons(&allocp[0]);
  allocp[2] = x2;
  allocp[3] = a2;
  x3 = makecons(&allocp[2]);
  a0 = makefunctor(&string_const_78);
  a1 = x3;
  a2 = a4;
  a3 = a5;
  allocp += 4;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case (unsigned long) makeint(2L):
  allocp[0] = NILATOM;
  allocp[1] = a3;
  x2 = makecons(&allocp[0]);
  allocp[2] = x2;
  allocp[3] = a2;
  x3 = makecons(&allocp[2]);
  a0 = makefunctor(&string_const_75);
  a1 = x3;
  a2 = a4;
  a3 = a5;
  allocp += 4;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 default:
  goto write__one__bblt_6_24;
  };
 case VARREF:
  deref_and_jump(a1,write__one__bblt_6_11);
  *reasonp++ =  a1;
  goto write__one__bblt_6_24;
  };
  goto write__one__bblt_6_24;
 case VARREF:
  deref_and_jump(x1,write__one__bblt_6_7);
  *reasonp++ =  x1;
  goto write__one__bblt_6_24;
  };
  goto write__one__bblt_6_24;
 case (unsigned long) makeint(2L):
  x1 = cdr_of(a0);
 write__one__bblt_6_17:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto write__one__bblt_6_24;
  allocp[0] = NILATOM;
  allocp[1] = a3;
  x2 = makecons(&allocp[0]);
  allocp[2] = x2;
  allocp[3] = a2;
  x3 = makecons(&allocp[2]);
  a0 = makefunctor(&string_const_76);
  a1 = x3;
  a2 = a4;
  a3 = a5;
  allocp += 4;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,write__one__bblt_6_17);
  *reasonp++ =  x1;
  goto write__one__bblt_6_24;
  };
  goto write__one__bblt_6_24;
 default:
  goto write__one__bblt_6_24;
  };
 case VARREF:
  deref_and_jump(x0,write__one__bblt_6_3);
  *reasonp++ =  x0;
  goto write__one__bblt_6_24;
  };
  goto write__one__bblt_6_24;
 case ATOMIC:
  if (a0 != NILATOM) goto write__one__bblt_6_24;
  allocp[0] = NILATOM;
  allocp[1] = a3;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a2;
  x1 = makecons(&allocp[2]);
  a0 = makefunctor(&string_const_77);
  a1 = x1;
  a2 = a4;
  a3 = a5;
  allocp += 4;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,write__one__bblt_6_1);
  *reasonp++ =  a0;
  goto write__one__bblt_6_24;
  };
  goto write__one__bblt_6_24;
 write__one__bblt_6_24:
  otherwise(write__one__bblt_6_interrupt);
  allocp[0] = NILATOM;
  allocp[1] = a3;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a2;
  x1 = makecons(&allocp[2]);
  a0 = makefunctor(&string_const_78);
  a1 = x1;
  a2 = a4;
  a3 = a5;
  allocp += 4;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 write__one__bblt_6_ext_interrupt:
  reasonp = 0l;
 write__one__bblt_6_interrupt:
  goto interrupt_6;
 }

 write__adjust__qp_3_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 write__adjust__qp_3_clear_reason:
  reasonp = reasons;
 write__adjust__qp_3_0:
 write__adjust__qp_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_qp)) goto write__adjust__qp_3_5;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,write__adjust__qp_3_1);
  *reasonp++ =  a0;
  goto write__adjust__qp_3_interrupt;
  };
  goto write__adjust__qp_3_5;
 write__adjust__qp_3_5:
  gblt_diff(a0,makesym(atom_qp),write__adjust__qp_3_interrupt);
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  a0 = makefunctor(&string_const_79);
  x1 = a1;
  a3 = a2;
  a2 = x1;
  a1 = x0;
  allocp += 2;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 write__adjust__qp_3_ext_interrupt:
  reasonp = 0l;
 write__adjust__qp_3_interrupt:
  toppred = &predicate_klic__comp__obj_xwrite__adjust__qp_3;
  goto interrupt_3;
 }

 write__adjust__allocp_3_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 write__adjust__allocp_3_clear_reason:
  reasonp = reasons;
 write__adjust__allocp_3_0:
 write__adjust__allocp_3_1:
  if (!isint(a0)) goto write__adjust__allocp_3_6;
  gblt_not_eq(a0,makeint(0L),write__adjust__allocp_3_4);
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  a0 = makefunctor(&string_const_80);
  x1 = a1;
  a3 = a2;
  a2 = x1;
  a1 = x0;
  allocp += 2;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 write__adjust__allocp_3_4:
  if (a0 != makeint(0L)) goto write__adjust__allocp_3_interrupt;
  unify(a2, a1);
  proceed();
 write__adjust__allocp_3_6:
  if (!isref(a0)) goto write__adjust__allocp_3_interrupt;
  deref_and_jump(a0,write__adjust__allocp_3_1);
  *reasonp++ =  a0;
  goto write__adjust__allocp_3_interrupt;
 write__adjust__allocp_3_ext_interrupt:
  reasonp = 0l;
 write__adjust__allocp_3_interrupt:
  goto interrupt_3;
 }

 klicformat_3_top: {
  q x0, x1, x2, x3, x4;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 klicformat_3_clear_reason:
  reasonp = reasons;
 klicformat_3_0:
 klicformat_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_user__error)) goto klicformat_3_5;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = NILATOM;
  allocp[6] = makesym(functor_normal_1);
  allocp[7] = x0;
  x1 = makefunctor(&allocp[6]);
  allocp[8] = makesym(functor_stderr_1);
  allocp[9] = x1;
  x2 = makefunctor(&allocp[8]);
  allocp[10] = NILATOM;
  allocp[11] = x2;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_klicio_xklicio_1);
  allocp[14] = x3;
  qp = (struct goalrec*)&allocp[12];
  allocp += 15;
  proceed();
 case VARREF:
  deref_and_jump(a0,klicformat_3_1);
  *reasonp++ =  a0;
  goto klicformat_3_5;
  };
  goto klicformat_3_5;
 klicformat_3_5:
  otherwise(klicformat_3_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[2] = a1;
  allocp[3] = a2;
  allocp[4] = x0 = makeref(&allocp[4]);
  allocp[5] = NILATOM;
  allocp[6] = makesym(functor_normal_1);
  allocp[7] = x2 = makeref(&allocp[7]);
  x1 = makefunctor(&allocp[6]);
  allocp[8] = makesym(functor_stdout_1);
  allocp[9] = x1;
  x3 = makefunctor(&allocp[8]);
  allocp[10] = NILATOM;
  allocp[11] = x3;
  x4 = makecons(&allocp[10]);
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_klicio_xklicio_1);
  allocp[14] = x4;
  qp = (struct goalrec*)&allocp[12];
  allocp += 15;
  proceed();
 klicformat_3_ext_interrupt:
  reasonp = 0l;
 klicformat_3_interrupt:
  goto interrupt_3;
 }

 nl_1_top: {
  qp = qp->next;
 nl_1_clear_reason:
  reasonp = reasons;
 nl_1_0:
 nl_1_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_user__error)) goto nl_1_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klicio_xklicio_1);
  allocp[2] = makecons(cons_const_84);
  qp = (struct goalrec*)&allocp[0];
  allocp += 3;
  proceed();
 case VARREF:
  deref_and_jump(a0,nl_1_1);
  *reasonp++ =  a0;
  goto nl_1_interrupt;
  };
  goto nl_1_interrupt;
 nl_1_ext_interrupt:
  reasonp = 0l;
 nl_1_interrupt:
  goto interrupt_1;
 }

 flush_2_top: {
  q x0, x1, x2, x3, x4;
  a1 = qp->args[1];
  qp = qp->next;
 flush_2_clear_reason:
  reasonp = reasons;
 flush_2_0:
 flush_2_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_user__error)) goto flush_2_interrupt;
  allocp[0] = makesym(functor_fflush_1);
  allocp[1] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = NILATOM;
  allocp[3] = x0;
  x1 = makecons(&allocp[2]);
  allocp[4] = makesym(functor_normal_1);
  allocp[5] = x1;
  x2 = makefunctor(&allocp[4]);
  allocp[6] = makesym(functor_stderr_1);
  allocp[7] = x2;
  x3 = makefunctor(&allocp[6]);
  allocp[8] = NILATOM;
  allocp[9] = x3;
  x4 = makecons(&allocp[8]);
  allocp[10] = (q)qp;
  allocp[11] = (q)(&predicate_klicio_xklicio_1);
  allocp[12] = x4;
  qp = (struct goalrec*)&allocp[10];
  allocp += 13;
  proceed();
 case VARREF:
  deref_and_jump(a0,flush_2_1);
  *reasonp++ =  a0;
  goto flush_2_interrupt;
  };
  goto flush_2_interrupt;
 flush_2_ext_interrupt:
  reasonp = 0l;
 flush_2_interrupt:
  goto interrupt_2;
 }

 nl_2_top: {
  q x0;
  a1 = qp->args[1];
  qp = qp->next;
 nl_2_clear_reason:
  reasonp = reasons;
 nl_2_0:
  allocp[0] = a1;
  allocp[1] = makeint(10L);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a0, x0);
  proceed();
 nl_2_ext_interrupt:
  reasonp = 0l;
 nl_2_interrupt:
  goto interrupt_2;
 }

 flush_3_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 flush_3_clear_reason:
  reasonp = reasons;
 flush_3_0:
  allocp[0] = makesym(functor_fflush_1);
  allocp[1] = a0;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = a2;
  allocp[3] = x0;
  x1 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a1, x1);
  proceed();
 flush_3_ext_interrupt:
  reasonp = 0l;
 flush_3_interrupt:
  goto interrupt_3;
 }

 klicformat_4_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 klicformat_4_clear_reason:
  reasonp = reasons;
 klicformat_4_0:
 klicformat_4_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
 klicformat_4_2:
  if (!isgobj(a0)) goto klicformat_4_interrupt;
 klicformat_4_3:
  gblt_is_string(a0,klicformat_4_interrupt);
  gblt_size_of_string(a0,x0,klicformat_4_interrupt);
  gblt_element_size_of_string(a0,x1,klicformat_4_interrupt);
 klicformat_4_7:
  if (x1 != makeint(8L)) goto klicformat_4_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__obj_xwait__and__out_4);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  a2 = a0;
  a3 = a1;
  a4 = x2;
  a5 = x3;
  a1 = x0;
  a0 = makeint(0L);
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  execute(klicformat_6_0);
  goto klicformat_6_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,klicformat_4_1);
  *reasonp++ =  a0;
  goto klicformat_4_interrupt;
  };
  goto klicformat_4_interrupt;
 klicformat_4_ext_interrupt:
  reasonp = 0l;
 klicformat_4_interrupt:
  toppred = &predicate_klic__comp__obj_xklicformat_4;
  goto interrupt_4;
 }

 wait__and__out_4_top: {
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 wait__and__out_4_clear_reason:
  reasonp = reasons;
 wait__and__out_4_0:
  unify2(a2, a0, a3, a1);
  proceed();
 wait__and__out_4_ext_interrupt:
  reasonp = 0l;
 wait__and__out_4_interrupt:
  goto interrupt_4;
 }

 klicformat_6_top: {
  q x0, x1, x2, x3, x4, x5;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 klicformat_6_clear_reason:
  reasonp = reasons;
 klicformat_6_0:
 klicformat_6_1:
  if (!isint(a0)) goto klicformat_6_21;
 klicformat_6_3:
  if (!isint(a1)) goto klicformat_6_20;
  gblt_greater_or_eq(a0,a1,klicformat_6_6);
  unify(a5, a4);
  proceed();
 klicformat_6_6:
  gblt_less(a0,a1,klicformat_6_interrupt);
 klicformat_6_8:
  switch (ptagof(a2)) {
 case FUNCTOR:
 klicformat_6_9:
  if (!isgobj(a2)) goto klicformat_6_interrupt;
 klicformat_6_10:
  generic_arg[0] = a0;
  guard_generic(a2, functor_element_2, 1, klicformat_6_interrupt);
  x0 = generic_arg[1];
  gblt_add(a0,makeint(1L),x1,klicformat_6_interrupt);
 klicformat_6_13:
  if (!isint(x0)) goto klicformat_6_19;
  gblt_not_eq(x0,makeint(126L),klicformat_6_16);
  allocp[0] = x3 = makeref(&allocp[0]);
  allocp[1] = x0;
  x2 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a4, x2);
  a0 = x1;
  a4 = x3;
  execute(klicformat_6_0);
  goto klicformat_6_ext_interrupt;
 klicformat_6_16:
  gblt_eq(x0,makeint(126L),klicformat_6_interrupt);
  generic_arg[0] = x1;
  guard_generic(a2, functor_element_2, 1, klicformat_6_interrupt);
  x2 = generic_arg[1];
  bblt_add_no_check(x1,makeint(1L),x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__obj_xklicformat_6);
  allocp[2] = x3;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x4 = makeref(&allocp[5]);
  allocp[6] = x5 = makeref(&allocp[6]);
  allocp[7] = a5;
  a0 = x2;
  a1 = a3;
  a2 = x4;
  a3 = a4;
  a4 = x5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  execute(format__special_5_0);
  goto format__special_5_ext_interrupt;
 klicformat_6_19:
  if (!isref(x0)) goto klicformat_6_interrupt;
  deref_and_jump(x0,klicformat_6_13);
  *reasonp++ =  x0;
  goto klicformat_6_interrupt;
 case VARREF:
  deref_and_jump(a2,klicformat_6_8);
  *reasonp++ =  a2;
  goto klicformat_6_interrupt;
  };
  goto klicformat_6_interrupt;
 klicformat_6_20:
  if (!isref(a1)) goto klicformat_6_interrupt;
  deref_and_jump(a1,klicformat_6_3);
  *reasonp++ =  a1;
  goto klicformat_6_interrupt;
 klicformat_6_21:
  if (!isref(a0)) goto klicformat_6_interrupt;
  deref_and_jump(a0,klicformat_6_1);
  *reasonp++ =  a0;
  goto klicformat_6_interrupt;
 klicformat_6_ext_interrupt:
  reasonp = 0l;
 klicformat_6_interrupt:
  toppred = &predicate_klic__comp__obj_xklicformat_6;
  goto interrupt_6;
 }

 format__special_5_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 format__special_5_clear_reason:
  reasonp = reasons;
 format__special_5_0:
 format__special_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 format__special_5_3:
  switch ((unsigned long)a0) {
 case (unsigned long) makeint(97L):
 format__special_5_5:
  switch (ptagof(a1)) {
 case CONS:
  x0 = cdr_of(a1);
  unify(a2, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xwrite__atom_3);
  x1 = car_of(a1);
  allocp[2] = x1;
  allocp[3] = a3;
  allocp[4] = a4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case VARREF:
  deref_and_jump(a1,format__special_5_5);
  *reasonp++ =  a1;
  goto format__special_5_72;
  };
  goto format__special_5_72;
 case (unsigned long) makeint(99L):
 format__special_5_8:
  switch (ptagof(a1)) {
 case CONS:
  x0 = cdr_of(a1);
  unify(a2, x0);
  allocp[0] = a4;
  x2 = car_of(a1);
  allocp[1] = x2;
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a3, x1);
  proceed();
 case VARREF:
  deref_and_jump(a1,format__special_5_8);
  *reasonp++ =  a1;
  goto format__special_5_72;
  };
  goto format__special_5_72;
 case (unsigned long) makeint(100L):
 format__special_5_11:
  switch (ptagof(a1)) {
 case CONS:
  x0 = cdr_of(a1);
  unify(a2, x0);
  a0 = car_of(a1);
  a1 = a3;
  a2 = a4;
  execute(write__int_3_0);
  goto write__int_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,format__special_5_11);
  *reasonp++ =  a1;
  goto format__special_5_72;
  };
  goto format__special_5_72;
 case (unsigned long) makeint(101L):
 format__special_5_14:
  switch (ptagof(a1)) {
 case CONS:
  x0 = cdr_of(a1);
 format__special_5_16:
  switch (ptagof(x0)) {
 case CONS:
  x1 = cdr_of(x0);
  unify(a2, x1);
  a0 = car_of(a1);
  a1 = car_of(x0);
  a2 = a3;
  a3 = a4;
  execute(write__elem__access_4_0);
  goto write__elem__access_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,format__special_5_16);
  *reasonp++ =  x0;
  goto format__special_5_72;
  };
  goto format__special_5_72;
 case VARREF:
  deref_and_jump(a1,format__special_5_14);
  *reasonp++ =  a1;
  goto format__special_5_72;
  };
  goto format__special_5_72;
 case (unsigned long) makeint(102L):
 format__special_5_19:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 format__special_5_21:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__2F_2)) goto format__special_5_72;
  x1 = cdr_of(a1);
  unify(a2, x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xwrite__funct__name_4);
  x2 = arg(x0, 0);
  allocp[2] = x2;
  x3 = arg(x0, 1);
  allocp[3] = x3;
  allocp[4] = a3;
  allocp[5] = a4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  proceed();
 case VARREF:
  deref_and_jump(x0,format__special_5_21);
  *reasonp++ =  x0;
  goto format__special_5_72;
  };
  goto format__special_5_72;
 case VARREF:
  deref_and_jump(a1,format__special_5_19);
  *reasonp++ =  a1;
  goto format__special_5_72;
  };
  goto format__special_5_72;
 case (unsigned long) makeint(103L):
 format__special_5_25:
  switch (ptagof(a1)) {
 case CONS:
  x0 = cdr_of(a1);
  unify(a2, x0);
  allocp[0] = x1 = makeref(&allocp[0]);
  generic_arg[0] = x1;
  x2 = car_of(a1);
  call_generic(x2, functor_print_1, 1);
  allocp[0] = makesym(functor_fwrite_2);
  allocp[1] = x1;
  allocp[2] = x4 = makeref(&allocp[2]);
  x3 = makefunctor(&allocp[0]);
  allocp[3] = a4;
  allocp[4] = x3;
  x5 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a3, x5);
  proceed();
 case VARREF:
  deref_and_jump(a1,format__special_5_25);
  *reasonp++ =  a1;
  goto format__special_5_72;
  };
  goto format__special_5_72;
 case (unsigned long) makeint(107L):
 format__special_5_28:
  switch (ptagof(a1)) {
 case CONS:
  x0 = cdr_of(a1);
  unify(a2, x0);
  a0 = car_of(a1);
  a1 = a3;
  a2 = a4;
  execute(write__param_3_0);
  goto write__param_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,format__special_5_28);
  *reasonp++ =  a1;
  goto format__special_5_72;
  };
  goto format__special_5_72;
 case (unsigned long) makeint(108L):
 format__special_5_31:
  switch (ptagof(a1)) {
 case CONS:
  x0 = cdr_of(a1);
 format__special_5_33:
  switch (ptagof(x0)) {
 case CONS:
  x1 = cdr_of(x0);
  unify(a2, x1);
  a0 = car_of(a1);
  a1 = car_of(x0);
  a2 = a3;
  a3 = a4;
  execute(write__lab_4_0);
  goto write__lab_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,format__special_5_33);
  *reasonp++ =  x0;
  goto format__special_5_72;
  };
  goto format__special_5_72;
 case VARREF:
  deref_and_jump(a1,format__special_5_31);
  *reasonp++ =  a1;
  goto format__special_5_72;
  };
  goto format__special_5_72;
 case (unsigned long) makeint(110L):
  unify(a2, a1);
  allocp[0] = a4;
  allocp[1] = makeint(10L);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a3, x0);
  proceed();
 case (unsigned long) makeint(112L):
 format__special_5_37:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 format__special_5_39:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__2F_2)) goto format__special_5_72;
  x1 = arg(x0, 0);
 format__special_5_42:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor__2F_2)) goto format__special_5_72;
  x2 = cdr_of(a1);
  unify(a2, x2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xwrite__pred__name_5);
  x3 = arg(x1, 0);
  allocp[2] = x3;
  x4 = arg(x1, 1);
  allocp[3] = x4;
  x5 = arg(x0, 1);
  allocp[4] = x5;
  allocp[5] = a3;
  allocp[6] = a4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  proceed();
 case VARREF:
  deref_and_jump(x1,format__special_5_42);
  *reasonp++ =  x1;
  goto format__special_5_72;
  };
  goto format__special_5_72;
 case VARREF:
  deref_and_jump(x0,format__special_5_39);
  *reasonp++ =  x0;
  goto format__special_5_72;
  };
  goto format__special_5_72;
 case VARREF:
  deref_and_jump(a1,format__special_5_37);
  *reasonp++ =  a1;
  goto format__special_5_72;
  };
  goto format__special_5_72;
 case (unsigned long) makeint(113L):
 format__special_5_46:
  switch (ptagof(a1)) {
 case CONS:
  x0 = cdr_of(a1);
  unify(a2, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__obj_xwrite__string_3);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a3;
  allocp[4] = a4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_klic__comp__write_xmake__atom__name__string_2);
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = x1;
  allocp[9] = (q)(struct goalrec*)&allocp[5];
  allocp[10] = (q)(&predicate_atom__table_xget__atom__string_2);
  x3 = car_of(a1);
  allocp[11] = x3;
  allocp[12] = x2;
  qp = (struct goalrec*)&allocp[9];
  allocp += 13;
  proceed();
 case VARREF:
  deref_and_jump(a1,format__special_5_46);
  *reasonp++ =  a1;
  goto format__special_5_72;
  };
  goto format__special_5_72;
 case (unsigned long) makeint(114L):
 format__special_5_49:
  switch (ptagof(a1)) {
 case CONS:
  x0 = cdr_of(a1);
  unify(a2, x0);
  a0 = car_of(a1);
  a1 = a3;
  a2 = a4;
  execute(write__reg_3_0);
  goto write__reg_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,format__special_5_49);
  *reasonp++ =  a1;
  goto format__special_5_72;
  };
  goto format__special_5_72;
 case (unsigned long) makeint(115L):
 format__special_5_52:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
 format__special_5_54:
  switch (ptagof(x0)) {
 case CONS:
  gblt_list(x0,format__special_5_72);
  x1 = cdr_of(a1);
  unify(a2, x1);
  a0 = x0;
  a1 = a3;
  a2 = a4;
  execute(write__string_3_0);
  goto write__string_3_ext_interrupt;
 case FUNCTOR:
 format__special_5_57:
  if (!isgobj(x0)) goto format__special_5_72;
 format__special_5_58:
  gblt_is_string(x0,format__special_5_72);
  gblt_size_of_string(x0,x1,format__special_5_72);
  gblt_element_size_of_string(x0,x2,format__special_5_72);
  x3 = cdr_of(a1);
  unify(a2, x3);
  allocp[0] = makesym(functor_fwrite_2);
  allocp[1] = x0;
  allocp[2] = x5 = makeref(&allocp[2]);
  x4 = makefunctor(&allocp[0]);
  allocp[3] = a4;
  allocp[4] = x4;
  x6 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a3, x6);
  proceed();
 case VARREF:
  deref_and_jump(x0,format__special_5_54);
  *reasonp++ =  x0;
  goto format__special_5_72;
  };
  goto format__special_5_72;
 case VARREF:
  deref_and_jump(a1,format__special_5_52);
  *reasonp++ =  a1;
  goto format__special_5_72;
  };
  goto format__special_5_72;
 case (unsigned long) makeint(119L):
 format__special_5_63:
  switch (ptagof(a1)) {
 case CONS:
  x0 = cdr_of(a1);
  unify(a2, x0);
  a0 = car_of(a1);
  a1 = a3;
  a2 = a4;
  execute(format__special__w_3_0);
  goto format__special__w_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,format__special_5_63);
  *reasonp++ =  a1;
  goto format__special_5_72;
  };
  goto format__special_5_72;
 case (unsigned long) makeint(44L):
 format__special_5_66:
  switch (ptagof(a1)) {
 case CONS:
  x0 = cdr_of(a1);
  unify(a2, x0);
  a0 = car_of(a1);
  a1 = a3;
  a2 = a4;
  execute(write__params_3_0);
  goto write__params_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,format__special_5_66);
  *reasonp++ =  a1;
  goto format__special_5_72;
  };
  goto format__special_5_72;
 case (unsigned long) makeint(81L):
 format__special_5_69:
  switch (ptagof(a1)) {
 case CONS:
  x0 = cdr_of(a1);
  unify(a2, x0);
  a0 = car_of(a1);
  a1 = a3;
  a2 = a4;
  execute(write__qp_3_0);
  goto write__qp_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,format__special_5_69);
  *reasonp++ =  a1;
  goto format__special_5_72;
  };
  goto format__special_5_72;
 case (unsigned long) makeint(126L):
  unify(a2, a1);
  allocp[0] = a4;
  allocp[1] = makeint(126L);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a3, x0);
  proceed();
 default:
  goto format__special_5_72;
  };
 case VARREF:
  deref_and_jump(a0,format__special_5_1);
  *reasonp++ =  a0;
  goto format__special_5_72;
  };
  goto format__special_5_72;
 format__special_5_72:
  otherwise(format__special_5_interrupt);
  unify2(a4, a3, a2, a1);
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__kl1cmp_xreport__error_2);
  allocp[4] = makefunctor(&string_const_85);
  allocp[5] = x0;
  qp = (struct goalrec*)&allocp[2];
  allocp += 6;
  proceed();
 format__special_5_ext_interrupt:
  reasonp = 0l;
 format__special_5_interrupt:
  toppred = &predicate_klic__comp__obj_xformat__special_5;
  goto interrupt_5;
 }

 format__special__w_3_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 format__special__w_3_clear_reason:
  reasonp = reasons;
 format__special__w_3_0:
 format__special__w_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto format__special__w_3_6;
 format__special__w_3_4:
  gblt_atom(a0,format__special__w_3_6);
  allocp[0] = makesym(functor_fwrite_2);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  x0 = makefunctor(&allocp[0]);
  allocp[3] = a2;
  allocp[4] = x0;
  x3 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a1, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_atom__table_xget__atom__string_2);
  allocp[2] = a0;
  allocp[3] = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  proceed();
 case VARREF:
  deref_and_jump(a0,format__special__w_3_1);
  *reasonp++ =  a0;
  goto format__special__w_3_6;
  };
  goto format__special__w_3_6;
 format__special__w_3_6:
  otherwise(format__special__w_3_interrupt);
  allocp[0] = makesym(functor_s_2);
  allocp[1] = makefunctor(funct_const_86);
  allocp[2] = x1 = makeref(&allocp[2]);
  x0 = makefunctor(&allocp[0]);
  allocp[3] = (q)qp;
  allocp[4] = (q)(&predicate_unparser_xunparse_4);
  allocp[5] = a0;
  allocp[6] = x0;
  allocp[7] = a1;
  allocp[8] = a2;
  qp = (struct goalrec*)&allocp[3];
  allocp += 9;
  proceed();
 format__special__w_3_ext_interrupt:
  reasonp = 0l;
 format__special__w_3_interrupt:
  toppred = &predicate_klic__comp__obj_xformat__special__w_3;
  goto interrupt_3;
 }

 write__params_3_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 write__params_3_clear_reason:
  reasonp = reasons;
 write__params_3_0:
 write__params_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = cdr_of(a0);
 write__params_3_3:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != NILATOM) goto write__params_3_7;
  a0 = car_of(a0);
  execute(write__param_3_0);
  goto write__param_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,write__params_3_3);
  *reasonp++ =  x0;
  goto write__params_3_interrupt;
  };
  goto write__params_3_7;
 write__params_3_7:
  gblt_diff(x0,NILATOM,write__params_3_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__obj_xwrite__params_3);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x1;
  allocp[6] = makeint(44L);
  x2 = makecons(&allocp[5]);
  a0 = car_of(a0);
  a2 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(write__param_3_0);
  goto write__param_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto write__params_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,write__params_3_1);
  *reasonp++ =  a0;
  goto write__params_3_interrupt;
  };
  goto write__params_3_interrupt;
 write__params_3_ext_interrupt:
  reasonp = 0l;
 write__params_3_interrupt:
  toppred = &predicate_klic__comp__obj_xwrite__params_3;
  goto interrupt_3;
 }

 write__param_3_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 write__param_3_clear_reason:
  reasonp = reasons;
 write__param_3_0:
 write__param_3_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_int_1:
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  a0 = makefunctor(&string_const_87);
  x2 = a1;
  a3 = a2;
  a2 = x2;
  a1 = x0;
  allocp += 2;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_atom_1:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xwrite__atom_3);
  x0 = arg(a0, 0);
  allocp[2] = x0;
  allocp[3] = a1;
  allocp[4] = a2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  proceed();
 case functor_const_1:
  x0 = arg(a0, 0);
 write__param_3_6:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_float_1:
  allocp[0] = NILATOM;
  x2 = arg(x0, 0);
  allocp[1] = x2;
  x1 = makecons(&allocp[0]);
  a0 = makefunctor(&string_const_88);
  x3 = a1;
  a3 = a2;
  a2 = x3;
  a1 = x1;
  allocp += 2;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_predicate_1:
  allocp[0] = NILATOM;
  x2 = arg(x0, 0);
  allocp[1] = x2;
  x1 = makecons(&allocp[0]);
  a0 = makefunctor(&string_const_89);
  x3 = a1;
  a3 = a2;
  a2 = x3;
  a1 = x1;
  allocp += 2;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_list_1:
  allocp[0] = NILATOM;
  x2 = arg(x0, 0);
  allocp[1] = x2;
  x1 = makecons(&allocp[0]);
  a0 = makefunctor(&string_const_90);
  x3 = a1;
  a3 = a2;
  a2 = x3;
  a1 = x1;
  allocp += 2;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_functor_1:
  allocp[0] = NILATOM;
  x2 = arg(x0, 0);
  allocp[1] = x2;
  x1 = makecons(&allocp[0]);
  a0 = makefunctor(&string_const_91);
  x3 = a1;
  a3 = a2;
  a2 = x3;
  a1 = x1;
  allocp += 2;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_string_1:
  allocp[0] = NILATOM;
  x2 = arg(x0, 0);
  allocp[1] = x2;
  x1 = makecons(&allocp[0]);
  a0 = makefunctor(&string_const_92);
  x3 = a1;
  a3 = a2;
  a2 = x3;
  a1 = x1;
  allocp += 2;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case functor_vector_1:
  allocp[0] = NILATOM;
  x2 = arg(x0, 0);
  allocp[1] = x2;
  x1 = makecons(&allocp[0]);
  a0 = makefunctor(&string_const_93);
  x3 = a1;
  a3 = a2;
  a2 = x3;
  a1 = x1;
  allocp += 2;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 default:
  goto write__param_3_interrupt;
  };
 case VARREF:
  deref_and_jump(x0,write__param_3_6);
  *reasonp++ =  x0;
  goto write__param_3_interrupt;
  };
  goto write__param_3_interrupt;
 case functor_r_1:
  a0 = arg(a0, 0);
  execute(write__reg_3_0);
  goto write__reg_3_ext_interrupt;
 case functor_arg_2:
  x0 = arg(a0, 0);
  x1 = arg(a0, 1);
  x2 = a1;
  a3 = a2;
  a2 = x2;
  a1 = x1;
  a0 = x0;
  execute(write__elem__access_4_0);
  goto write__elem__access_4_ext_interrupt;
 default:
  goto write__param_3_interrupt;
  };
 case VARREF:
  deref_and_jump(a0,write__param_3_1);
  *reasonp++ =  a0;
  goto write__param_3_interrupt;
  };
  goto write__param_3_interrupt;
 write__param_3_ext_interrupt:
  reasonp = 0l;
 write__param_3_interrupt:
  toppred = &predicate_klic__comp__obj_xwrite__param_3;
  goto interrupt_3;
 }

 write__string_3_top: {
  q x0, x1, x2, x3, x4;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 write__string_3_clear_reason:
  reasonp = reasons;
 write__string_3_0:
 write__string_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 write__string_3_3:
  if (!isint(x0)) goto write__string_3_6;
  gblt_integer(x0,write__string_3_interrupt);
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = x0;
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x1);
  a0 = cdr_of(a0);
  a1 = x2;
  execute(write__string_3_0);
  goto write__string_3_ext_interrupt;
 write__string_3_6:
  if (!isref(x0)) goto write__string_3_interrupt;
  deref_and_jump(x0,write__string_3_3);
  *reasonp++ =  x0;
  goto write__string_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto write__string_3_interrupt;
  unify(a2, a1);
  proceed();
 case FUNCTOR:
 write__string_3_10:
  if (!isgobj(a0)) goto write__string_3_interrupt;
 write__string_3_11:
  gblt_is_string(a0,write__string_3_interrupt);
  gblt_size_of_string(a0,x0,write__string_3_interrupt);
  gblt_element_size_of_string(a0,x1,write__string_3_interrupt);
  allocp[0] = makesym(functor_fwrite_2);
  allocp[1] = a0;
  allocp[2] = x3 = makeref(&allocp[2]);
  x2 = makefunctor(&allocp[0]);
  allocp[3] = a2;
  allocp[4] = x2;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a1, x4);
  proceed();
 case VARREF:
  deref_and_jump(a0,write__string_3_1);
  *reasonp++ =  a0;
  goto write__string_3_interrupt;
  };
  goto write__string_3_interrupt;
 write__string_3_ext_interrupt:
  reasonp = 0l;
 write__string_3_interrupt:
  toppred = &predicate_klic__comp__obj_xwrite__string_3;
  goto interrupt_3;
 }

 write__int_3_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 write__int_3_clear_reason:
  reasonp = reasons;
 write__int_3_0:
 write__int_3_1:
  if (!isint(a0)) goto write__int_3_9;
  gblt_greater_or_eq(a0,makeint(0L),write__int_3_5);
  gblt_less(a0,makeint(10L),write__int_3_5);
  bblt_add_no_check(makeint(48L),a0,x0);
  allocp[0] = a2;
  allocp[1] = x0;
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x1);
  proceed();
 write__int_3_5:
  gblt_greater_or_eq(a0,makeint(10L),write__int_3_7);
  bblt_mod_no_check(a0,makeint(10L),x0);
  bblt_add_no_check(makeint(48L),x0,x1);
  bblt_div_no_check(a0,makeint(10L),x2);
  allocp[0] = a2;
  allocp[1] = x1;
  x3 = makecons(&allocp[0]);
  a0 = x2;
  a2 = x3;
  allocp += 2;
  execute(write__int_3_0);
  goto write__int_3_ext_interrupt;
 write__int_3_7:
  gblt_less(a0,makeint(0L),write__int_3_interrupt);
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = makeint(45L);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a1 = x1;
  execute(write__int_2F3_240_3_0);
  goto write__int_2F3_240_3_ext_interrupt;
 write__int_3_9:
  if (!isref(a0)) goto write__int_3_interrupt;
  deref_and_jump(a0,write__int_3_1);
  *reasonp++ =  a0;
  goto write__int_3_interrupt;
 write__int_3_ext_interrupt:
  reasonp = 0l;
 write__int_3_interrupt:
  toppred = &predicate_klic__comp__obj_xwrite__int_3;
  goto interrupt_3;
 }

 write__int_2F3_240_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 write__int_2F3_240_3_clear_reason:
  reasonp = reasons;
 write__int_2F3_240_3_0:
 write__int_2F3_240_3_1:
  if (!isint(a0)) goto write__int_2F3_240_3_7;
  gblt_minus(a0,x0,write__int_2F3_240_3_interrupt);
  gblt_eq(a0,x0,write__int_2F3_240_3_5);
  bblt_div_no_check(a0,makeint(10L),x1);
  bblt_minus_no_check(x1,x2);
  bblt_mult_no_check(x2,makeint(10L),x3);
  bblt_add_no_check(a0,x3,x4);
  bblt_minus_no_check(x4,x5);
  bblt_add_no_check(makeint(48L),x5,x6);
  allocp[0] = a2;
  allocp[1] = x6;
  x7 = makecons(&allocp[0]);
  a0 = x2;
  a2 = x7;
  allocp += 2;
  execute(write__int_3_0);
  goto write__int_3_ext_interrupt;
 write__int_2F3_240_3_5:
  gblt_not_eq(a0,x0,write__int_2F3_240_3_interrupt);
  bblt_minus_no_check(a0,x1);
  a0 = x1;
  execute(write__int_3_0);
  goto write__int_3_ext_interrupt;
 write__int_2F3_240_3_7:
  if (!isref(a0)) goto write__int_2F3_240_3_interrupt;
  deref_and_jump(a0,write__int_2F3_240_3_1);
  *reasonp++ =  a0;
  goto write__int_2F3_240_3_interrupt;
 write__int_2F3_240_3_ext_interrupt:
  reasonp = 0l;
 write__int_2F3_240_3_interrupt:
  toppred = &predicate_klic__comp__obj_xwrite__int_2F3_240_3;
  goto interrupt_3;
 }

 write__elem__access_4_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 write__elem__access_4_clear_reason:
  reasonp = reasons;
 write__elem__access_4_0:
 write__elem__access_4_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (isint(a1)) goto write__elem__access_4_6;
  switch (symval(a1)) {
 case symval(makesym(atom_car)):
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  a0 = makefunctor(&string_const_94);
  a1 = x0;
  allocp += 2;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case symval(makesym(atom_cdr)):
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  a0 = makefunctor(&string_const_95);
  a1 = x0;
  allocp += 2;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 default:
  goto write__elem__access_4_6;
  };
 case VARREF:
  deref_and_jump(a1,write__elem__access_4_1);
  *reasonp++ =  a1;
  goto write__elem__access_4_6;
  };
  goto write__elem__access_4_6;
 write__elem__access_4_6:
  otherwise(write__elem__access_4_interrupt);
  allocp[0] = NILATOM;
  allocp[1] = a1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a0;
  x1 = makecons(&allocp[2]);
  a0 = makefunctor(&string_const_96);
  a1 = x1;
  allocp += 4;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 write__elem__access_4_ext_interrupt:
  reasonp = 0l;
 write__elem__access_4_interrupt:
  toppred = &predicate_klic__comp__obj_xwrite__elem__access_4;
  goto interrupt_4;
 }

 write__lab_4_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 write__lab_4_clear_reason:
  reasonp = reasons;
 write__lab_4_0:
 write__lab_4_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_info_1)) goto write__lab_4_interrupt;
  x0 = arg(a0, 0);
 write__lab_4_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__2F_2)) goto write__lab_4_interrupt;
  x1 = arg(x0, 0);
 write__lab_4_7:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor__2F_2)) goto write__lab_4_interrupt;
 write__lab_4_10:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_interrupt)) goto write__lab_4_14;
  allocp[0] = NILATOM;
  x3 = arg(x0, 1);
  allocp[1] = x3;
  x2 = makecons(&allocp[0]);
  allocp[2] = x2;
  x5 = arg(x1, 1);
  allocp[3] = x5;
  x4 = makecons(&allocp[2]);
  a0 = makefunctor(&string_const_97);
  a1 = x4;
  allocp += 4;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,write__lab_4_10);
  *reasonp++ =  a1;
  goto write__lab_4_interrupt;
  };
  goto write__lab_4_14;
 write__lab_4_14:
  gblt_diff(a1,makesym(atom_interrupt),write__lab_4_interrupt);
  allocp[0] = NILATOM;
  allocp[1] = a1;
  x2 = makecons(&allocp[0]);
  allocp[2] = x2;
  x4 = arg(x0, 1);
  allocp[3] = x4;
  x3 = makecons(&allocp[2]);
  allocp[4] = x3;
  x6 = arg(x1, 1);
  allocp[5] = x6;
  x5 = makecons(&allocp[4]);
  a0 = makefunctor(&string_const_98);
  a1 = x5;
  allocp += 6;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,write__lab_4_7);
  *reasonp++ =  x1;
  goto write__lab_4_interrupt;
  };
  goto write__lab_4_interrupt;
 case VARREF:
  deref_and_jump(x0,write__lab_4_4);
  *reasonp++ =  x0;
  goto write__lab_4_interrupt;
  };
  goto write__lab_4_interrupt;
 case VARREF:
  deref_and_jump(a0,write__lab_4_1);
  *reasonp++ =  a0;
  goto write__lab_4_interrupt;
  };
  goto write__lab_4_interrupt;
 write__lab_4_ext_interrupt:
  reasonp = 0l;
 write__lab_4_interrupt:
  toppred = &predicate_klic__comp__obj_xwrite__lab_4;
  goto interrupt_4;
 }

 write__reg_3_top: {
  q x0, x1;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 write__reg_3_clear_reason:
  reasonp = reasons;
 write__reg_3_0:
 write__reg_3_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_a_1:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = makeint(97L);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = arg(a0, 0);
  a1 = x1;
  execute(write__int_3_0);
  goto write__int_3_ext_interrupt;
 case functor_x_1:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = makeint(120L);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = arg(a0, 0);
  a1 = x1;
  execute(write__int_3_0);
  goto write__int_3_ext_interrupt;
 case functor_r_1:
  a0 = arg(a0, 0);
  execute(write__reg_3_0);
  goto write__reg_3_ext_interrupt;
 default:
  goto write__reg_3_interrupt;
  };
 case VARREF:
  deref_and_jump(a0,write__reg_3_1);
  *reasonp++ =  a0;
  goto write__reg_3_interrupt;
  };
  goto write__reg_3_interrupt;
 write__reg_3_ext_interrupt:
  reasonp = 0l;
 write__reg_3_interrupt:
  toppred = &predicate_klic__comp__obj_xwrite__reg_3;
  goto interrupt_3;
 }

 write__qp_3_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 write__qp_3_clear_reason:
  reasonp = reasons;
 write__qp_3_0:
 write__qp_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto write__qp_3_6;
  if (a0 != makesym(atom_qp)) goto write__qp_3_interrupt;
  a0 = makefunctor(&string_const_99);
  x0 = a1;
  a3 = a2;
  a2 = x0;
  a1 = NILATOM;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 write__qp_3_6:
  gblt_integer(a0,write__qp_3_interrupt);
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x1 = makecons(&allocp[0]);
  a0 = makefunctor(&string_const_100);
  x2 = a1;
  a3 = a2;
  a2 = x2;
  a1 = x1;
  allocp += 2;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,write__qp_3_1);
  *reasonp++ =  a0;
  goto write__qp_3_interrupt;
  };
  goto write__qp_3_interrupt;
 write__qp_3_ext_interrupt:
  reasonp = 0l;
 write__qp_3_interrupt:
  toppred = &predicate_klic__comp__obj_xwrite__qp_3;
  goto interrupt_3;
 }

 write__inline_6_top: {
  q x0, x1, x2, x3, x4, x5;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 write__inline_6_clear_reason:
  reasonp = reasons;
 write__inline_6_0:
 write__inline_6_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_string_1)) goto write__inline_6_interrupt;
  x0 = arg(a0, 0);
 write__inline_6_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
 write__inline_6_5:
  if (!isgobj(x0)) goto write__inline_6_interrupt;
 write__inline_6_6:
  gblt_is_string(x0,write__inline_6_interrupt);
  gblt_size_of_string(x0,x1,write__inline_6_interrupt);
  gblt_element_size_of_string(x0,x2,write__inline_6_interrupt);
 write__inline_6_10:
  if (x2 != makeint(8L)) goto write__inline_6_interrupt;
  a0 = makeint(0L);
  x3 = a1;
  x4 = a2;
  x5 = a3;
  a6 = a4;
  a7 = a5;
  a5 = x5;
  a4 = x4;
  a3 = x3;
  a2 = x0;
  a1 = x1;
  execute(write__inline_8_0);
  goto write__inline_8_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,write__inline_6_4);
  *reasonp++ =  x0;
  goto write__inline_6_interrupt;
  };
  goto write__inline_6_interrupt;
 case VARREF:
  deref_and_jump(a0,write__inline_6_1);
  *reasonp++ =  a0;
  goto write__inline_6_interrupt;
  };
  goto write__inline_6_interrupt;
 write__inline_6_ext_interrupt:
  reasonp = 0l;
 write__inline_6_interrupt:
  goto interrupt_6;
 }

 write__inline_8_top: {
  q x0, x1, x2, x3, x4;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 write__inline_8_clear_reason:
  reasonp = reasons;
 write__inline_8_0:
 write__inline_8_1:
  if (!isint(a0)) goto write__inline_8_21;
 write__inline_8_3:
  if (!isint(a1)) goto write__inline_8_20;
  gblt_greater_or_eq(a0,a1,write__inline_8_6);
  allocp[0] = a7;
  allocp[1] = makeint(10L);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a6, x0);
  proceed();
 write__inline_8_6:
  gblt_less(a0,a1,write__inline_8_interrupt);
 write__inline_8_8:
  switch (ptagof(a2)) {
 case FUNCTOR:
 write__inline_8_9:
  if (!isgobj(a2)) goto write__inline_8_interrupt;
 write__inline_8_10:
  generic_arg[0] = a0;
  guard_generic(a2, functor_element_2, 1, write__inline_8_interrupt);
  x0 = generic_arg[1];
  gblt_add(a0,makeint(1L),x1,write__inline_8_interrupt);
 write__inline_8_13:
  if (!isint(x0)) goto write__inline_8_19;
  gblt_not_eq(x0,makeint(37L),write__inline_8_16);
  allocp[0] = x3 = makeref(&allocp[0]);
  allocp[1] = x0;
  x2 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a6, x2);
  a0 = x1;
  a6 = x3;
  execute(write__inline_8_0);
  goto write__inline_8_ext_interrupt;
 write__inline_8_16:
  gblt_eq(x0,makeint(37L),write__inline_8_interrupt);
  generic_arg[0] = x1;
  guard_generic(a2, functor_element_2, 1, write__inline_8_interrupt);
  x2 = generic_arg[1];
  bblt_add_no_check(x1,makeint(1L),x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__obj_xwrite__inline_8);
  allocp[2] = x3;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = a7;
  a0 = x2;
  a1 = a3;
  a2 = a4;
  a3 = a5;
  a4 = a6;
  a5 = x4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  execute(inline__special_6_0);
  goto inline__special_6_ext_interrupt;
 write__inline_8_19:
  if (!isref(x0)) goto write__inline_8_interrupt;
  deref_and_jump(x0,write__inline_8_13);
  *reasonp++ =  x0;
  goto write__inline_8_interrupt;
 case VARREF:
  deref_and_jump(a2,write__inline_8_8);
  *reasonp++ =  a2;
  goto write__inline_8_interrupt;
  };
  goto write__inline_8_interrupt;
 write__inline_8_20:
  if (!isref(a1)) goto write__inline_8_interrupt;
  deref_and_jump(a1,write__inline_8_3);
  *reasonp++ =  a1;
  goto write__inline_8_interrupt;
 write__inline_8_21:
  if (!isref(a0)) goto write__inline_8_interrupt;
  deref_and_jump(a0,write__inline_8_1);
  *reasonp++ =  a0;
  goto write__inline_8_interrupt;
 write__inline_8_ext_interrupt:
  reasonp = 0l;
 write__inline_8_interrupt:
  toppred = &predicate_klic__comp__obj_xwrite__inline_8;
  goto interrupt_8;
 }

 inline__special_6_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 inline__special_6_clear_reason:
  reasonp = reasons;
 inline__special_6_0:
 inline__special_6_1:
  if (!isint(a0)) goto inline__special_6_9;
  gblt_eq(a0,makeint(37L),inline__special_6_4);
  allocp[0] = a5;
  allocp[1] = makeint(37L);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a4, x0);
  proceed();
 inline__special_6_4:
  gblt_eq(a0,makeint(102L),inline__special_6_6);
  allocp[0] = NILATOM;
  allocp[1] = a3;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a2;
  x1 = makecons(&allocp[2]);
  a0 = makefunctor(&string_const_101);
  a1 = x1;
  a2 = a4;
  a3 = a5;
  allocp += 4;
  execute(klicformat_4_0);
  goto klicformat_4_ext_interrupt;
 inline__special_6_6:
  gblt_less_or_eq(makeint(48L),a0,inline__special_6_10);
  gblt_less_or_eq(a0,makeint(57L),inline__special_6_10);
  bblt_sub_no_check(a0,makeint(48L),x0);
  allocp[0] = NILATOM;
  allocp[1] = x2 = makeref(&allocp[1]);
  x1 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_102);
  allocp[5] = x1;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = (q)(struct goalrec*)&allocp[2];
  allocp[9] = (q)(&predicate_klic__comp__util_xnth_3);
  allocp[10] = x0;
  allocp[11] = a1;
  allocp[12] = x2;
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  proceed();
 inline__special_6_9:
  if (!isref(a0)) goto inline__special_6_10;
  deref_and_jump(a0,inline__special_6_1);
  *reasonp++ =  a0;
  goto inline__special_6_10;
 inline__special_6_10:
  otherwise(inline__special_6_interrupt);
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = makeint(37L);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a4, x0);
  allocp[0] = a5;
  allocp[1] = a0;
  x2 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(x1, x2);
  proceed();
 inline__special_6_ext_interrupt:
  reasonp = 0l;
 inline__special_6_interrupt:
  toppred = &predicate_klic__comp__obj_xinline__special_6;
  goto interrupt_6;
 }
 interrupt_10:
  allocp[11] = a9;
 interrupt_9:
  allocp[10] = a8;
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_klic__comp__obj);
}
