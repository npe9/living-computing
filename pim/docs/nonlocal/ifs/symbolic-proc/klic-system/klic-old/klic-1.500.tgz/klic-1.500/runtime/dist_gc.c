#include <klic/basic.h>
#include <klic/struct.h>
#include <klic/primitives.h>
#include <klic/timing.h>
#include <stdio.h>
#include <klic/functorstuffs.h>
/* #include <klic/gcdebug.h> */
#include <klic/schedule.h>
#include <klic/gobj.h>
#include <klic/susp.h>
#include <klic/trace.h>

#include <klic/interpe.h>

q general_gc();

q* gc_exp_table(allocp, ntop, otop, nsize, osize)
     q *allocp, *ntop, *otop;
     unsigned long nsize, osize;
{
  struct global_variables *glbl = &globals;  
  int i, j;
  q newdata;

  j = 0;
  for(i=0;i<current_exp_size;i++){
    if(exp_table[i].data != (q)UNUSED_EXPREC){
      newdata = general_gc(&(exp_table[i].data), allocp, gcsp);
      exp_table[i].data = newdata;
      allocp = heapp;
      j++;
    }
    if(j == active_exp_entry){
      break;
    }
    
  }
  return(allocp);
}

