/* Compiled by KLIC compiler version 1.500 (Fri Oct 21 12:19:27 JST 1994) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_klicio();
Const struct predicate predicate_klicio_xklicio_1 =
   { module_klicio, 0, 1 };
Const struct predicate predicate_klicio_xklicio_2 =
   { module_klicio, 1, 2 };
Const struct predicate predicate_klicio_xtermin_2 =
   { module_klicio, 2, 2 };
Const struct predicate predicate_klicio_xtermout_2 =
   { module_klicio, 3, 2 };
Const struct predicate predicate_klicio_xtermupdt_2 =
   { module_klicio, 4, 2 };
Const struct predicate predicate_klicio_xin_3 =
   { module_klicio, 5, 3 };
Const struct predicate predicate_klicio_xout_3 =
   { module_klicio, 6, 3 };
Const struct predicate predicate_klicio_xupdt_3 =
   { module_klicio, 7, 3 };
Const struct predicate predicate_klicio_xaddop_5 =
   { module_klicio, 8, 5 };
Const struct predicate predicate_klicio_xaddop2_5 =
   { module_klicio, 9, 5 };
Const struct predicate predicate_klicio_xrmop_4 =
   { module_klicio, 10, 4 };
Const struct predicate predicate_klicio_xrmop2_4 =
   { module_klicio, 11, 4 };
Const struct predicate predicate_klicio_xdefault__operator__table_1 =
   { module_klicio, 12, 1 };
extern Const struct predicate predicate_unix_xunix_1;
extern Const struct predicate predicate_klic__reader_xparse__one__term__reporting__errors_4;
extern Const struct predicate predicate_klic__reader_xwparse__one__term__reporting__errors_4;
extern Const struct predicate predicate_unparser_xunparse_4;
extern Const struct predicate predicate_unparser_xunwparse_4;

module module_klicio(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  Const static q funct_const_0[] = {
    makesym(functor_putc_1),
    makeint(10),
  };
  Const static q funct_const_1[] = {
    makesym(functor_op_3),
    makesym(atom__5C_2B),
    makesym(atom_fy),
    makeint(900),
  };
  Const static q cons_const_2[] = {
    NILATOM,
    makefunctor(funct_const_1),
  };
  Const static q funct_const_3[] = {
    makesym(functor_op_3),
    makesym(atom__24_7E),
    makesym(atom_fy),
    makeint(300),
  };
  Const static q cons_const_4[] = {
    makecons(cons_const_2),
    makefunctor(funct_const_3),
  };
  Const static q funct_const_5[] = {
    makesym(functor_op_3),
    makesym(atom__7E),
    makesym(atom_fy),
    makeint(300),
  };
  Const static q cons_const_6[] = {
    makecons(cons_const_4),
    makefunctor(funct_const_5),
  };
  Const static q funct_const_7[] = {
    makesym(functor_op_3),
    makesym(atom_with__macro),
    makesym(atom_fx),
    makeint(1150),
  };
  Const static q cons_const_8[] = {
    makecons(cons_const_6),
    makefunctor(funct_const_7),
  };
  Const static q funct_const_9[] = {
    makesym(functor_op_3),
    makesym(atom_spy),
    makesym(atom_fy),
    makeint(900),
  };
  Const static q cons_const_10[] = {
    makecons(cons_const_8),
    makefunctor(funct_const_9),
  };
  Const static q funct_const_11[] = {
    makesym(functor_op_3),
    makesym(atom_public),
    makesym(atom_fx),
    makeint(1150),
  };
  Const static q cons_const_12[] = {
    makecons(cons_const_10),
    makefunctor(funct_const_11),
  };
  Const static q funct_const_13[] = {
    makesym(functor_op_3),
    makesym(atom_nospy),
    makesym(atom_fy),
    makeint(900),
  };
  Const static q cons_const_14[] = {
    makecons(cons_const_12),
    makefunctor(funct_const_13),
  };
  Const static q funct_const_15[] = {
    makesym(functor_op_3),
    makesym(atom_module),
    makesym(atom_fx),
    makeint(80),
  };
  Const static q cons_const_16[] = {
    makecons(cons_const_14),
    makefunctor(funct_const_15),
  };
  Const static q funct_const_17[] = {
    makesym(functor_op_3),
    makesym(atom_mode),
    makesym(atom_fx),
    makeint(1150),
  };
  Const static q cons_const_18[] = {
    makecons(cons_const_16),
    makefunctor(funct_const_17),
  };
  Const static q funct_const_19[] = {
    makesym(functor_op_3),
    makesym(atom_local__implicit),
    makesym(atom_fx),
    makeint(1150),
  };
  Const static q cons_const_20[] = {
    makecons(cons_const_18),
    makefunctor(funct_const_19),
  };
  Const static q funct_const_21[] = {
    makesym(functor_op_3),
    makesym(atom_implicit),
    makesym(atom_fx),
    makeint(1150),
  };
  Const static q cons_const_22[] = {
    makecons(cons_const_20),
    makefunctor(funct_const_21),
  };
  Const static q funct_const_23[] = {
    makesym(functor_op_3),
    makesym(atom__3F_2D),
    makesym(atom_fx),
    makeint(1200),
  };
  Const static q cons_const_24[] = {
    makecons(cons_const_22),
    makefunctor(funct_const_23),
  };
  Const static q funct_const_25[] = {
    makesym(functor_op_3),
    makesym(atom__3A_2D),
    makesym(atom_fx),
    makeint(1200),
  };
  Const static q cons_const_26[] = {
    makecons(cons_const_24),
    makefunctor(funct_const_25),
  };
  Const static q funct_const_27[] = {
    makesym(functor_op_3),
    makesym(atom__2D),
    makesym(atom_fx),
    makeint(500),
  };
  Const static q cons_const_28[] = {
    makecons(cons_const_26),
    makefunctor(funct_const_27),
  };
  Const static q funct_const_29[] = {
    makesym(functor_op_3),
    makesym(atom__2B),
    makesym(atom_fx),
    makeint(500),
  };
  Const static q cons_const_30[] = {
    makecons(cons_const_28),
    makefunctor(funct_const_29),
  };
  Const static q funct_const_31[] = {
    makesym(functor_op_3),
    makesym(atom__26),
    makesym(atom_fx),
    makeint(200),
  };
  Const static q cons_const_32[] = {
    makecons(cons_const_30),
    makefunctor(funct_const_31),
  };
  Const static q funct_const_33[] = {
    makesym(functor_op_3),
    makesym(atom__23),
    makesym(atom_fx),
    makeint(100),
  };
  Const static q cons_const_34[] = {
    makecons(cons_const_32),
    makefunctor(funct_const_33),
  };
  Const static q funct_const_35[] = {
    makesym(functor_op_3),
    makesym(atom_xor),
    makesym(atom_yfx),
    makeint(500),
  };
  Const static q cons_const_36[] = {
    NILATOM,
    makefunctor(funct_const_35),
  };
  Const static q funct_const_37[] = {
    makesym(functor_op_3),
    makesym(atom_mod),
    makesym(atom_xfx),
    makeint(300),
  };
  Const static q cons_const_38[] = {
    makecons(cons_const_36),
    makefunctor(funct_const_37),
  };
  Const static q funct_const_39[] = {
    makesym(functor_op_3),
    makesym(atom_is),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_40[] = {
    makecons(cons_const_38),
    makefunctor(funct_const_39),
  };
  Const static q funct_const_41[] = {
    makesym(functor_op_3),
    makesym(atom__5E),
    makesym(atom_xfy),
    makeint(200),
  };
  Const static q cons_const_42[] = {
    makecons(cons_const_40),
    makefunctor(funct_const_41),
  };
  Const static q funct_const_43[] = {
    makesym(functor_op_3),
    makesym(atom__5C_3D_3D),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_44[] = {
    makecons(cons_const_42),
    makefunctor(funct_const_43),
  };
  Const static q funct_const_45[] = {
    makesym(functor_op_3),
    makesym(atom__5C_3D),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_46[] = {
    makecons(cons_const_44),
    makefunctor(funct_const_45),
  };
  Const static q funct_const_47[] = {
    makesym(functor_op_3),
    makesym(atom__5C_2F),
    makesym(atom_yfx),
    makeint(500),
  };
  Const static q cons_const_48[] = {
    makecons(cons_const_46),
    makefunctor(funct_const_47),
  };
  Const static q funct_const_49[] = {
    makesym(functor_op_3),
    makesym(atom__40_3E_3D),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_50[] = {
    makecons(cons_const_48),
    makefunctor(funct_const_49),
  };
  Const static q funct_const_51[] = {
    makesym(functor_op_3),
    makesym(atom__40_3E),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_52[] = {
    makecons(cons_const_50),
    makefunctor(funct_const_51),
  };
  Const static q funct_const_53[] = {
    makesym(functor_op_3),
    makesym(atom__40_3D_3C),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_54[] = {
    makecons(cons_const_52),
    makefunctor(funct_const_53),
  };
  Const static q funct_const_55[] = {
    makesym(functor_op_3),
    makesym(atom__40_3C),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_56[] = {
    makecons(cons_const_54),
    makefunctor(funct_const_55),
  };
  Const static q funct_const_57[] = {
    makesym(functor_op_3),
    makesym(atom__40),
    makesym(atom_xfy),
    makeint(700),
  };
  Const static q cons_const_58[] = {
    makecons(cons_const_56),
    makefunctor(funct_const_57),
  };
  Const static q funct_const_59[] = {
    makesym(functor_op_3),
    makesym(atom__3E_3E),
    makesym(atom_yfx),
    makeint(400),
  };
  Const static q cons_const_60[] = {
    makecons(cons_const_58),
    makefunctor(funct_const_59),
  };
  Const static q funct_const_61[] = {
    makesym(functor_op_3),
    makesym(atom__2F_3D),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_62[] = {
    makecons(cons_const_60),
    makefunctor(funct_const_61),
  };
  Const static q funct_const_63[] = {
    makesym(functor_op_3),
    makesym(atom__2A_3D),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_64[] = {
    makecons(cons_const_62),
    makefunctor(funct_const_63),
  };
  Const static q funct_const_65[] = {
    makesym(functor_op_3),
    makesym(atom__2D_3D),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_66[] = {
    makecons(cons_const_64),
    makefunctor(funct_const_65),
  };
  Const static q funct_const_67[] = {
    makesym(functor_op_3),
    makesym(atom__2B_3D),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_68[] = {
    makecons(cons_const_66),
    makefunctor(funct_const_67),
  };
  Const static q funct_const_69[] = {
    makesym(functor_op_3),
    makesym(atom__3E_3D),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_70[] = {
    makecons(cons_const_68),
    makefunctor(funct_const_69),
  };
  Const static q funct_const_71[] = {
    makesym(functor_op_3),
    makesym(atom__3E),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_72[] = {
    makecons(cons_const_70),
    makefunctor(funct_const_71),
  };
  Const static q funct_const_73[] = {
    makesym(functor_op_3),
    makesym(atom__3D_5C_3D),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_74[] = {
    makecons(cons_const_72),
    makefunctor(funct_const_73),
  };
  Const static q funct_const_75[] = {
    makesym(functor_op_3),
    makesym(atom__3D_3E),
    makesym(atom_xfx),
    makeint(1090),
  };
  Const static q cons_const_76[] = {
    makecons(cons_const_74),
    makefunctor(funct_const_75),
  };
  Const static q funct_const_77[] = {
    makesym(functor_op_3),
    makesym(atom__3D_3D),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_78[] = {
    makecons(cons_const_76),
    makefunctor(funct_const_77),
  };
  Const static q funct_const_79[] = {
    makesym(functor_op_3),
    makesym(atom__3D_3C),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_80[] = {
    makecons(cons_const_78),
    makefunctor(funct_const_79),
  };
  Const static q funct_const_81[] = {
    makesym(functor_op_3),
    makesym(atom__3D_3A_3D),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_82[] = {
    makecons(cons_const_80),
    makefunctor(funct_const_81),
  };
  Const static q funct_const_83[] = {
    makesym(functor_op_3),
    makesym(atom__3D_2E_2E),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_84[] = {
    makecons(cons_const_82),
    makefunctor(funct_const_83),
  };
  Const static q funct_const_85[] = {
    makesym(functor_op_3),
    makesym(atom__3D),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_86[] = {
    makecons(cons_const_84),
    makefunctor(funct_const_85),
  };
  Const static q funct_const_87[] = {
    makesym(functor_op_3),
    makesym(atom__3C_3D_3D),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_88[] = {
    makecons(cons_const_86),
    makefunctor(funct_const_87),
  };
  Const static q funct_const_89[] = {
    makesym(functor_op_3),
    makesym(atom__3D_3E),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_90[] = {
    makecons(cons_const_88),
    makefunctor(funct_const_89),
  };
  Const static q funct_const_91[] = {
    makesym(functor_op_3),
    makesym(atom__3C_3D),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_92[] = {
    makecons(cons_const_90),
    makefunctor(funct_const_91),
  };
  Const static q funct_const_93[] = {
    makesym(functor_op_3),
    makesym(atom__3C_3C_3D),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_94[] = {
    makecons(cons_const_92),
    makefunctor(funct_const_93),
  };
  Const static q funct_const_95[] = {
    makesym(functor_op_3),
    makesym(atom__3C_3C),
    makesym(atom_yfx),
    makeint(400),
  };
  Const static q cons_const_96[] = {
    makecons(cons_const_94),
    makefunctor(funct_const_95),
  };
  Const static q funct_const_97[] = {
    makesym(functor_op_3),
    makesym(atom__3C),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_98[] = {
    makecons(cons_const_96),
    makefunctor(funct_const_97),
  };
  Const static q funct_const_99[] = {
    makesym(functor_op_3),
    makesym(atom__3B),
    makesym(atom_xfy),
    makeint(1100),
  };
  Const static q cons_const_100[] = {
    makecons(cons_const_98),
    makefunctor(funct_const_99),
  };
  Const static q funct_const_101[] = {
    makesym(functor_op_3),
    makesym(atom__3A_3D),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_102[] = {
    makecons(cons_const_100),
    makefunctor(funct_const_101),
  };
  Const static q funct_const_103[] = {
    makesym(functor_op_3),
    makesym(atom__3A_3A),
    makesym(atom_xfx),
    makeint(90),
  };
  Const static q cons_const_104[] = {
    makecons(cons_const_102),
    makefunctor(funct_const_103),
  };
  Const static q funct_const_105[] = {
    makesym(functor_op_3),
    makesym(atom__3A_2D),
    makesym(atom_xfx),
    makeint(1200),
  };
  Const static q cons_const_106[] = {
    makecons(cons_const_104),
    makefunctor(funct_const_105),
  };
  Const static q funct_const_107[] = {
    makesym(functor_op_3),
    makesym(atom__3A),
    makesym(atom_xfy),
    makeint(800),
  };
  Const static q cons_const_108[] = {
    makecons(cons_const_106),
    makefunctor(funct_const_107),
  };
  Const static q funct_const_109[] = {
    makesym(functor_op_3),
    makesym(atom__2F_5C),
    makesym(atom_yfx),
    makeint(500),
  };
  Const static q cons_const_110[] = {
    makecons(cons_const_108),
    makefunctor(funct_const_109),
  };
  Const static q funct_const_111[] = {
    makesym(functor_op_3),
    makesym(atom__2F_2F),
    makesym(atom_yfx),
    makeint(400),
  };
  Const static q cons_const_112[] = {
    makecons(cons_const_110),
    makefunctor(funct_const_111),
  };
  Const static q funct_const_113[] = {
    makesym(functor_op_3),
    makesym(atom__2F),
    makesym(atom_yfx),
    makeint(400),
  };
  Const static q cons_const_114[] = {
    makecons(cons_const_112),
    makefunctor(funct_const_113),
  };
  Const static q funct_const_115[] = {
    makesym(functor_op_3),
    makesym(atom__2D_3E),
    makesym(atom_xfy),
    makeint(1050),
  };
  Const static q cons_const_116[] = {
    makecons(cons_const_114),
    makefunctor(funct_const_115),
  };
  Const static q funct_const_117[] = {
    makesym(functor_op_3),
    makesym(atom__2D_2D_3E),
    makesym(atom_xfx),
    makeint(1200),
  };
  Const static q cons_const_118[] = {
    makecons(cons_const_116),
    makefunctor(funct_const_117),
  };
  Const static q funct_const_119[] = {
    makesym(functor_op_3),
    makesym(atom__2D),
    makesym(atom_yfx),
    makeint(500),
  };
  Const static q cons_const_120[] = {
    makecons(cons_const_118),
    makefunctor(funct_const_119),
  };
  Const static q funct_const_121[] = {
    makesym(functor_op_3),
    makesym(atom__2C),
    makesym(atom_xfy),
    makeint(1000),
  };
  Const static q cons_const_122[] = {
    makecons(cons_const_120),
    makefunctor(funct_const_121),
  };
  Const static q funct_const_123[] = {
    makesym(functor_op_3),
    makesym(atom__2B),
    makesym(atom_yfx),
    makeint(500),
  };
  Const static q cons_const_124[] = {
    makecons(cons_const_122),
    makefunctor(funct_const_123),
  };
  Const static q funct_const_125[] = {
    makesym(functor_op_3),
    makesym(atom__2A_2A),
    makesym(atom_xfy),
    makeint(300),
  };
  Const static q cons_const_126[] = {
    makecons(cons_const_124),
    makefunctor(funct_const_125),
  };
  Const static q funct_const_127[] = {
    makesym(functor_op_3),
    makesym(atom__2A),
    makesym(atom_yfx),
    makeint(400),
  };
  Const static q cons_const_128[] = {
    makecons(cons_const_126),
    makefunctor(funct_const_127),
  };
  Const static q funct_const_129[] = {
    makesym(functor_op_3),
    makesym(atom__24_2F_3D),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_130[] = {
    makecons(cons_const_128),
    makefunctor(funct_const_129),
  };
  Const static q funct_const_131[] = {
    makesym(functor_op_3),
    makesym(atom__24_2A_3D),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_132[] = {
    makecons(cons_const_130),
    makefunctor(funct_const_131),
  };
  Const static q funct_const_133[] = {
    makesym(functor_op_3),
    makesym(atom__24_2D_3D),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_134[] = {
    makecons(cons_const_132),
    makefunctor(funct_const_133),
  };
  Const static q funct_const_135[] = {
    makesym(functor_op_3),
    makesym(atom__24_2B_3D),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_136[] = {
    makecons(cons_const_134),
    makefunctor(funct_const_135),
  };
  Const static q funct_const_137[] = {
    makesym(functor_op_3),
    makesym(atom__26_3E_3D),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_138[] = {
    makecons(cons_const_136),
    makefunctor(funct_const_137),
  };
  Const static q funct_const_139[] = {
    makesym(functor_op_3),
    makesym(atom__26_3E),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_140[] = {
    makecons(cons_const_138),
    makefunctor(funct_const_139),
  };
  Const static q funct_const_141[] = {
    makesym(functor_op_3),
    makesym(atom__26_3D_3C),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_142[] = {
    makecons(cons_const_140),
    makefunctor(funct_const_141),
  };
  Const static q funct_const_143[] = {
    makesym(functor_op_3),
    makesym(atom__26_3C_3D),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_144[] = {
    makecons(cons_const_142),
    makefunctor(funct_const_143),
  };
  Const static q funct_const_145[] = {
    makesym(functor_op_3),
    makesym(atom__26_3C),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_146[] = {
    makecons(cons_const_144),
    makefunctor(funct_const_145),
  };
  Const static q funct_const_147[] = {
    makesym(functor_op_3),
    makesym(atom__24_3E_3D),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_148[] = {
    makecons(cons_const_146),
    makefunctor(funct_const_147),
  };
  Const static q funct_const_149[] = {
    makesym(functor_op_3),
    makesym(atom__24_3E),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_150[] = {
    makecons(cons_const_148),
    makefunctor(funct_const_149),
  };
  Const static q funct_const_151[] = {
    makesym(functor_op_3),
    makesym(atom__24_3D_5C_3D),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_152[] = {
    makecons(cons_const_150),
    makefunctor(funct_const_151),
  };
  Const static q funct_const_153[] = {
    makesym(functor_op_3),
    makesym(atom__24_3D_3C),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_154[] = {
    makecons(cons_const_152),
    makefunctor(funct_const_153),
  };
  Const static q funct_const_155[] = {
    makesym(functor_op_3),
    makesym(atom__24_3D_3A_3D),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_156[] = {
    makecons(cons_const_154),
    makefunctor(funct_const_155),
  };
  Const static q funct_const_157[] = {
    makesym(functor_op_3),
    makesym(atom__24_3C_3D),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_158[] = {
    makecons(cons_const_156),
    makefunctor(funct_const_157),
  };
  Const static q funct_const_159[] = {
    makesym(functor_op_3),
    makesym(atom__24_3C),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_160[] = {
    makecons(cons_const_158),
    makefunctor(funct_const_159),
  };
  Const static q funct_const_161[] = {
    makesym(functor_op_3),
    makesym(atom__24_3A_3D),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_162[] = {
    makecons(cons_const_160),
    makefunctor(funct_const_161),
  };
  Const static q funct_const_163[] = {
    makesym(functor_op_3),
    makesym(atom__24_24_3E_3D),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_164[] = {
    makecons(cons_const_162),
    makefunctor(funct_const_163),
  };
  Const static q funct_const_165[] = {
    makesym(functor_op_3),
    makesym(atom__24_24_3E),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_166[] = {
    makecons(cons_const_164),
    makefunctor(funct_const_165),
  };
  Const static q funct_const_167[] = {
    makesym(functor_op_3),
    makesym(atom__24_24_3D_5C_3D),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_168[] = {
    makecons(cons_const_166),
    makefunctor(funct_const_167),
  };
  Const static q funct_const_169[] = {
    makesym(functor_op_3),
    makesym(atom__24_24_3D_3C),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_170[] = {
    makecons(cons_const_168),
    makefunctor(funct_const_169),
  };
  Const static q funct_const_171[] = {
    makesym(functor_op_3),
    makesym(atom__24_24_3D_3A_3D),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_172[] = {
    makecons(cons_const_170),
    makefunctor(funct_const_171),
  };
  Const static q funct_const_173[] = {
    makesym(functor_op_3),
    makesym(atom__24_24_3C_3D),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_174[] = {
    makecons(cons_const_172),
    makefunctor(funct_const_173),
  };
  Const static q funct_const_175[] = {
    makesym(functor_op_3),
    makesym(atom__24_24_3C),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_176[] = {
    makecons(cons_const_174),
    makefunctor(funct_const_175),
  };
  Const static q funct_const_177[] = {
    makesym(functor_op_3),
    makesym(atom__24_24_3A_3D),
    makesym(atom_xfx),
    makeint(700),
  };
  Const static q cons_const_178[] = {
    makecons(cons_const_176),
    makefunctor(funct_const_177),
  };
  Const static q funct_const_179[] = {
    makesym(functor_op_3),
    makesym(atom__23),
    makesym(atom_xfx),
    makeint(100),
  };
  Const static q cons_const_180[] = {
    makecons(cons_const_178),
    makefunctor(funct_const_179),
  };
  Const static q funct_const_181[] = {
    makesym(functor_op_3),
    makesym(atom__2D_2D),
    makesym(atom_xf),
    makeint(150),
  };
  Const static q cons_const_182[] = {
    NILATOM,
    makefunctor(funct_const_181),
  };
  Const static q funct_const_183[] = {
    makesym(functor_op_3),
    makesym(atom__2B_2B),
    makesym(atom_xf),
    makeint(150),
  };
  Const static q cons_const_184[] = {
    makecons(cons_const_182),
    makefunctor(funct_const_183),
  };
  Const static q funct_const_185[] = {
    makesym(functor_ops_3),
    makecons(cons_const_34),
    makecons(cons_const_180),
    makecons(cons_const_184),
  };
  q a0, a1, a2, a3, a4;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  switch_on_pred() {
    case_pred(0, klicio_1_top);
    case_pred(1, klicio_2_top);
    case_pred(2, termin_2_top);
    case_pred(3, termout_2_top);
    case_pred(4, termupdt_2_top);
    case_pred(5, in_3_top);
    case_pred(6, out_3_top);
    case_pred(7, updt_3_top);
    case_pred(8, addop_5_top);
    case_pred(9, addop2_5_top);
    case_pred(10, rmop_4_top);
    case_pred(11, rmop2_4_top);
    last_case_pred(12, default__operator__table_1_top);
  }

 klicio_1_top: {
  q x0;
  qp = qp->next;
 klicio_1_clear_reason:
  reasonp = reasons;
 klicio_1_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klicio_xklicio_2);
  allocp[2] = a0;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_unix_xunix_1);
  allocp[6] = x0;
  qp = (struct goalrec*)&allocp[4];
  allocp += 7;
  proceed();
 klicio_1_ext_interrupt:
  reasonp = 0l;
 klicio_1_interrupt:
  goto interrupt_1;
 }

 klicio_2_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a1 = qp->args[1];
  qp = qp->next;
 klicio_2_clear_reason:
  reasonp = reasons;
 klicio_2_0:
 klicio_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 klicio_2_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_stdin_1:
  allocp[0] = makesym(functor_stdin_1);
  allocp[1] = x2 = makeref(&allocp[1]);
  x1 = makefunctor(&allocp[0]);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = x1;
  x3 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a1, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klicio_xklicio_2);
  x5 = cdr_of(a0);
  allocp[2] = x5;
  allocp[3] = x4;
  a0 = x2;
  a1 = arg(x0, 0);
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  execute(termin_2_0);
  goto termin_2_ext_interrupt;
 case functor_stdout_1:
  allocp[0] = makesym(functor_stdout_1);
  allocp[1] = x2 = makeref(&allocp[1]);
  x1 = makefunctor(&allocp[0]);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = x1;
  x3 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a1, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klicio_xklicio_2);
  x5 = cdr_of(a0);
  allocp[2] = x5;
  allocp[3] = x4;
  a0 = x2;
  a1 = arg(x0, 0);
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  execute(termout_2_0);
  goto termout_2_ext_interrupt;
 case functor_stderr_1:
  allocp[0] = makesym(functor_stderr_1);
  allocp[1] = x2 = makeref(&allocp[1]);
  x1 = makefunctor(&allocp[0]);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = x1;
  x3 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a1, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klicio_xklicio_2);
  x5 = cdr_of(a0);
  allocp[2] = x5;
  allocp[3] = x4;
  a0 = x2;
  a1 = arg(x0, 0);
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  execute(termout_2_0);
  goto termout_2_ext_interrupt;
 case functor_read__open_2:
  allocp[0] = makesym(functor_read__open_2);
  x2 = arg(x0, 0);
  allocp[1] = x2;
  allocp[2] = x3 = makeref(&allocp[2]);
  x1 = makefunctor(&allocp[0]);
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = x1;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a1, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klicio_xklicio_2);
  x6 = cdr_of(a0);
  allocp[2] = x6;
  allocp[3] = x5;
  a0 = x3;
  a1 = arg(x0, 1);
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  execute(termin_2_0);
  goto termin_2_ext_interrupt;
 case functor_write__open_2:
  allocp[0] = makesym(functor_write__open_2);
  x2 = arg(x0, 0);
  allocp[1] = x2;
  allocp[2] = x3 = makeref(&allocp[2]);
  x1 = makefunctor(&allocp[0]);
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = x1;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a1, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klicio_xklicio_2);
  x6 = cdr_of(a0);
  allocp[2] = x6;
  allocp[3] = x5;
  a0 = x3;
  a1 = arg(x0, 1);
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  execute(termout_2_0);
  goto termout_2_ext_interrupt;
 case functor_append__open_2:
  allocp[0] = makesym(functor_append__open_2);
  x2 = arg(x0, 0);
  allocp[1] = x2;
  allocp[2] = x3 = makeref(&allocp[2]);
  x1 = makefunctor(&allocp[0]);
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = x1;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a1, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klicio_xklicio_2);
  x6 = cdr_of(a0);
  allocp[2] = x6;
  allocp[3] = x5;
  a0 = x3;
  a1 = arg(x0, 1);
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  execute(termout_2_0);
  goto termout_2_ext_interrupt;
 case functor_update__open_2:
  allocp[0] = makesym(functor_update__open_2);
  x2 = arg(x0, 0);
  allocp[1] = x2;
  allocp[2] = x3 = makeref(&allocp[2]);
  x1 = makefunctor(&allocp[0]);
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = x1;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a1, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klicio_xklicio_2);
  x6 = cdr_of(a0);
  allocp[2] = x6;
  allocp[3] = x5;
  a0 = x3;
  a1 = arg(x0, 1);
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  execute(termupdt_2_0);
  goto termupdt_2_ext_interrupt;
 default:
  goto klicio_2_15;
  };
 case VARREF:
  deref_and_jump(x0,klicio_2_3);
  *reasonp++ =  x0;
  goto klicio_2_15;
  };
  goto klicio_2_15;
 case ATOMIC:
  if (a0 != NILATOM) goto klicio_2_15;
  unify_value(a1, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a0,klicio_2_1);
  *reasonp++ =  a0;
  goto klicio_2_15;
  };
  goto klicio_2_15;
 klicio_2_15:
  otherwise(klicio_2_interrupt);
 klicio_2_17:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(klicio_2_0);
  goto klicio_2_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,klicio_2_17);
  *reasonp++ =  a0;
  goto klicio_2_interrupt;
  };
  goto klicio_2_interrupt;
 klicio_2_ext_interrupt:
  reasonp = 0l;
 klicio_2_interrupt:
  goto interrupt_2;
 }

 termin_2_top: {
  q x0, x1, x2, x3, x4;
  a1 = qp->args[1];
  qp = qp->next;
 termin_2_clear_reason:
  reasonp = reasons;
 termin_2_0:
 termin_2_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_normal_1)) goto termin_2_4;
  allocp[0] = makesym(functor_normal_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = makesym(functor_s_2);
  allocp[1] = x3 = makeref(&allocp[1]);
  allocp[2] = makeint(0L);
  x2 = makefunctor(&allocp[0]);
  allocp[3] = (q)qp;
  allocp[4] = (q)(&predicate_klicio_xin_3);
  allocp[5] = x1;
  x4 = arg(a0, 0);
  allocp[6] = x4;
  allocp[7] = x2;
  a0 = x3;
  qp = (struct goalrec*)&allocp[3];
  allocp += 8;
  execute(default__operator__table_1_0);
  goto default__operator__table_1_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,termin_2_1);
  *reasonp++ =  a0;
  goto termin_2_4;
  };
  goto termin_2_4;
 termin_2_4:
  otherwise(termin_2_interrupt);
  unify(a1, a0);
  proceed();
 termin_2_ext_interrupt:
  reasonp = 0l;
 termin_2_interrupt:
  toppred = &predicate_klicio_xtermin_2;
  goto interrupt_2;
 }

 termout_2_top: {
  q x0, x1, x2, x3, x4;
  a1 = qp->args[1];
  qp = qp->next;
 termout_2_clear_reason:
  reasonp = reasons;
 termout_2_0:
 termout_2_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_normal_1)) goto termout_2_4;
  allocp[0] = makesym(functor_normal_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = makesym(functor_s_2);
  allocp[1] = x3 = makeref(&allocp[1]);
  allocp[2] = makeint(0L);
  x2 = makefunctor(&allocp[0]);
  allocp[3] = (q)qp;
  allocp[4] = (q)(&predicate_klicio_xout_3);
  allocp[5] = x1;
  x4 = arg(a0, 0);
  allocp[6] = x4;
  allocp[7] = x2;
  a0 = x3;
  qp = (struct goalrec*)&allocp[3];
  allocp += 8;
  execute(default__operator__table_1_0);
  goto default__operator__table_1_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,termout_2_1);
  *reasonp++ =  a0;
  goto termout_2_4;
  };
  goto termout_2_4;
 termout_2_4:
  otherwise(termout_2_interrupt);
  unify(a1, a0);
  proceed();
 termout_2_ext_interrupt:
  reasonp = 0l;
 termout_2_interrupt:
  toppred = &predicate_klicio_xtermout_2;
  goto interrupt_2;
 }

 termupdt_2_top: {
  q x0, x1, x2, x3, x4;
  a1 = qp->args[1];
  qp = qp->next;
 termupdt_2_clear_reason:
  reasonp = reasons;
 termupdt_2_0:
 termupdt_2_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_normal_1)) goto termupdt_2_4;
  allocp[0] = makesym(functor_normal_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = makesym(functor_s_2);
  allocp[1] = x3 = makeref(&allocp[1]);
  allocp[2] = makeint(0L);
  x2 = makefunctor(&allocp[0]);
  allocp[3] = (q)qp;
  allocp[4] = (q)(&predicate_klicio_xupdt_3);
  allocp[5] = x1;
  x4 = arg(a0, 0);
  allocp[6] = x4;
  allocp[7] = x2;
  a0 = x3;
  qp = (struct goalrec*)&allocp[3];
  allocp += 8;
  execute(default__operator__table_1_0);
  goto default__operator__table_1_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,termupdt_2_1);
  *reasonp++ =  a0;
  goto termupdt_2_4;
  };
  goto termupdt_2_4;
 termupdt_2_4:
  otherwise(termupdt_2_interrupt);
  unify(a1, a0);
  proceed();
 termupdt_2_ext_interrupt:
  reasonp = 0l;
 termupdt_2_interrupt:
  toppred = &predicate_klicio_xtermupdt_2;
  goto interrupt_2;
 }

 in_3_top: {
  q x0, x1, x2, x3, x4, x5;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 in_3_clear_reason:
  reasonp = reasons;
 in_3_0:
 in_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 in_3_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_gett_1:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klicio_xin_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_klic__reader_xparse__one__term__reporting__errors_4);
  allocp[7] = a1;
  allocp[8] = a2;
  x3 = arg(x0, 0);
  allocp[9] = x3;
  allocp[10] = x2;
  qp = (struct goalrec*)&allocp[5];
  allocp += 11;
  proceed();
 case functor_getwt_1:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klicio_xin_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_klic__reader_xwparse__one__term__reporting__errors_4);
  allocp[7] = a1;
  allocp[8] = a2;
  x3 = arg(x0, 0);
  allocp[9] = x3;
  allocp[10] = x2;
  qp = (struct goalrec*)&allocp[5];
  allocp += 11;
  proceed();
 case functor_addop_3:
 in_3_8:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_s_2)) goto in_3_22;
  allocp[0] = makesym(functor_s_2);
  allocp[1] = x2 = makeref(&allocp[1]);
  x3 = arg(a2, 1);
  allocp[2] = x3;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = (q)qp;
  allocp[4] = (q)(&predicate_klicio_xin_3);
  x4 = cdr_of(a0);
  allocp[5] = x4;
  allocp[6] = a1;
  allocp[7] = x1;
  a0 = arg(x0, 1);
  a1 = arg(x0, 0);
  x5 = arg(x0, 2);
  a3 = arg(a2, 0);
  a4 = x2;
  a2 = x5;
  qp = (struct goalrec*)&allocp[3];
  allocp += 8;
  execute(addop_5_0);
  goto addop_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,in_3_8);
  *reasonp++ =  a2;
  goto in_3_22;
  };
  goto in_3_22;
 case functor_rmop_2:
 in_3_12:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_s_2)) goto in_3_22;
  allocp[0] = makesym(functor_s_2);
  allocp[1] = x2 = makeref(&allocp[1]);
  x3 = arg(a2, 1);
  allocp[2] = x3;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = (q)qp;
  allocp[4] = (q)(&predicate_klicio_xin_3);
  x4 = cdr_of(a0);
  allocp[5] = x4;
  allocp[6] = a1;
  allocp[7] = x1;
  a0 = arg(x0, 1);
  a1 = arg(x0, 0);
  a2 = arg(a2, 0);
  a3 = x2;
  qp = (struct goalrec*)&allocp[3];
  allocp += 8;
  execute(rmop_4_0);
  goto rmop_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,in_3_12);
  *reasonp++ =  a2;
  goto in_3_22;
  };
  goto in_3_22;
 case functor_on__error_1:
 in_3_16:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_s_2)) goto in_3_22;
  allocp[0] = makesym(functor_s_2);
  x2 = arg(a2, 0);
  allocp[1] = x2;
  x3 = arg(x0, 0);
  allocp[2] = x3;
  x1 = makefunctor(&allocp[0]);
  a0 = cdr_of(a0);
  a2 = x1;
  allocp += 3;
  execute(in_3_0);
  goto in_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,in_3_16);
  *reasonp++ =  a2;
  goto in_3_22;
  };
  goto in_3_22;
 default:
  goto in_3_22;
  };
 case VARREF:
  deref_and_jump(x0,in_3_3);
  *reasonp++ =  x0;
  goto in_3_22;
  };
  goto in_3_22;
 case ATOMIC:
  if (a0 != NILATOM) goto in_3_22;
  unify_value(a1, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a0,in_3_1);
  *reasonp++ =  a0;
  goto in_3_22;
  };
  goto in_3_22;
 in_3_22:
  otherwise(in_3_interrupt);
 in_3_24:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(in_3_0);
  goto in_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,in_3_24);
  *reasonp++ =  a0;
  goto in_3_interrupt;
  };
  goto in_3_interrupt;
 in_3_ext_interrupt:
  reasonp = 0l;
 in_3_interrupt:
  goto interrupt_3;
 }

 out_3_top: {
  q x0, x1, x2, x3, x4, x5;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 out_3_clear_reason:
  reasonp = reasons;
 out_3_0:
 out_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 out_3_3:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_nl)) goto out_3_27;
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = makefunctor(funct_const_0);
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x1);
  a0 = cdr_of(a0);
  a1 = x2;
  execute(out_3_0);
  goto out_3_ext_interrupt;
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_putt_1:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klicio_xout_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_unparser_xunparse_4);
  x3 = arg(x0, 0);
  allocp[7] = x3;
  allocp[8] = a2;
  allocp[9] = a1;
  allocp[10] = x2;
  qp = (struct goalrec*)&allocp[5];
  allocp += 11;
  proceed();
 case functor_puttq_1:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klicio_xout_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_unparser_xunparse_4);
  x3 = arg(x0, 0);
  allocp[7] = x3;
  allocp[8] = a2;
  allocp[9] = a1;
  allocp[10] = x2;
  qp = (struct goalrec*)&allocp[5];
  allocp += 11;
  proceed();
 case functor_putwt_1:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klicio_xout_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_unparser_xunwparse_4);
  x3 = arg(x0, 0);
  allocp[7] = x3;
  allocp[8] = a2;
  allocp[9] = a1;
  allocp[10] = x2;
  qp = (struct goalrec*)&allocp[5];
  allocp += 11;
  proceed();
 case functor_putwtq_1:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klicio_xout_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_unparser_xunwparse_4);
  x3 = arg(x0, 0);
  allocp[7] = x3;
  allocp[8] = a2;
  allocp[9] = a1;
  allocp[10] = x2;
  qp = (struct goalrec*)&allocp[5];
  allocp += 11;
  proceed();
 case functor_addop_3:
 out_3_13:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_s_2)) goto out_3_27;
  allocp[0] = makesym(functor_s_2);
  allocp[1] = x2 = makeref(&allocp[1]);
  x3 = arg(a2, 1);
  allocp[2] = x3;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = (q)qp;
  allocp[4] = (q)(&predicate_klicio_xout_3);
  x4 = cdr_of(a0);
  allocp[5] = x4;
  allocp[6] = a1;
  allocp[7] = x1;
  a0 = arg(x0, 1);
  a1 = arg(x0, 0);
  x5 = arg(x0, 2);
  a3 = arg(a2, 0);
  a4 = x2;
  a2 = x5;
  qp = (struct goalrec*)&allocp[3];
  allocp += 8;
  execute(addop_5_0);
  goto addop_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,out_3_13);
  *reasonp++ =  a2;
  goto out_3_27;
  };
  goto out_3_27;
 case functor_rmop_2:
 out_3_17:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_s_2)) goto out_3_27;
  allocp[0] = makesym(functor_s_2);
  allocp[1] = x2 = makeref(&allocp[1]);
  x3 = arg(a2, 1);
  allocp[2] = x3;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = (q)qp;
  allocp[4] = (q)(&predicate_klicio_xout_3);
  x4 = cdr_of(a0);
  allocp[5] = x4;
  allocp[6] = a1;
  allocp[7] = x1;
  a0 = arg(x0, 1);
  a1 = arg(x0, 0);
  a2 = arg(a2, 0);
  a3 = x2;
  qp = (struct goalrec*)&allocp[3];
  allocp += 8;
  execute(rmop_4_0);
  goto rmop_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,out_3_17);
  *reasonp++ =  a2;
  goto out_3_27;
  };
  goto out_3_27;
 case functor_on__error_1:
 out_3_21:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_s_2)) goto out_3_27;
  allocp[0] = makesym(functor_s_2);
  x2 = arg(a2, 0);
  allocp[1] = x2;
  x3 = arg(x0, 0);
  allocp[2] = x3;
  x1 = makefunctor(&allocp[0]);
  a0 = cdr_of(a0);
  a2 = x1;
  allocp += 3;
  execute(out_3_0);
  goto out_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,out_3_21);
  *reasonp++ =  a2;
  goto out_3_27;
  };
  goto out_3_27;
 default:
  goto out_3_27;
  };
 case VARREF:
  deref_and_jump(x0,out_3_3);
  *reasonp++ =  x0;
  goto out_3_27;
  };
  goto out_3_27;
 case ATOMIC:
  if (a0 != NILATOM) goto out_3_27;
  unify_value(a1, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a0,out_3_1);
  *reasonp++ =  a0;
  goto out_3_27;
  };
  goto out_3_27;
 out_3_27:
  otherwise(out_3_interrupt);
 out_3_29:
  switch (ptagof(a0)) {
 case CONS:
 out_3_31:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_s_2)) goto out_3_interrupt;
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = makesym(functor_s_2);
  x4 = arg(a2, 0);
  allocp[1] = x4;
  x5 = arg(a2, 1);
  allocp[2] = x5;
  x3 = makefunctor(&allocp[0]);
  a0 = cdr_of(a0);
  a1 = x1;
  a2 = x3;
  allocp += 3;
  execute(out_3_0);
  goto out_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,out_3_31);
  *reasonp++ =  a2;
  goto out_3_interrupt;
  };
  goto out_3_interrupt;
 case VARREF:
  deref_and_jump(a0,out_3_29);
  *reasonp++ =  a0;
  goto out_3_interrupt;
  };
  goto out_3_interrupt;
 out_3_ext_interrupt:
  reasonp = 0l;
 out_3_interrupt:
  goto interrupt_3;
 }

 updt_3_top: {
  q x0, x1, x2, x3, x4, x5;
  a1 = qp->args[1];
  a2 = qp->args[2];
  qp = qp->next;
 updt_3_clear_reason:
  reasonp = reasons;
 updt_3_0:
 updt_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 updt_3_3:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_nl)) goto updt_3_29;
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = makefunctor(funct_const_0);
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x1);
  a0 = cdr_of(a0);
  a1 = x2;
  execute(updt_3_0);
  goto updt_3_ext_interrupt;
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_gett_1:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klicio_xupdt_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = makesym(functor_normal_1);
  x4 = arg(x0, 0);
  allocp[6] = x4;
  x3 = makefunctor(&allocp[5]);
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_klic__reader_xparse__one__term__reporting__errors_4);
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = x3;
  allocp[12] = x2;
  qp = (struct goalrec*)&allocp[7];
  allocp += 13;
  proceed();
 case functor_getwt_1:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klicio_xupdt_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_klic__reader_xwparse__one__term__reporting__errors_4);
  allocp[7] = a1;
  allocp[8] = a2;
  x3 = arg(x0, 0);
  allocp[9] = x3;
  allocp[10] = x2;
  qp = (struct goalrec*)&allocp[5];
  allocp += 11;
  proceed();
 case functor_putt_1:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klicio_xupdt_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_unparser_xunparse_4);
  x3 = arg(x0, 0);
  allocp[7] = x3;
  allocp[8] = a2;
  allocp[9] = a1;
  allocp[10] = x2;
  qp = (struct goalrec*)&allocp[5];
  allocp += 11;
  proceed();
 case functor_puttq_1:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klicio_xupdt_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_unparser_xunparse_4);
  x3 = arg(x0, 0);
  allocp[7] = x3;
  allocp[8] = a2;
  allocp[9] = a1;
  allocp[10] = x2;
  qp = (struct goalrec*)&allocp[5];
  allocp += 11;
  proceed();
 case functor_putwt_1:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klicio_xupdt_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_unparser_xunwparse_4);
  x3 = arg(x0, 0);
  allocp[7] = x3;
  allocp[8] = a2;
  allocp[9] = a1;
  allocp[10] = x2;
  qp = (struct goalrec*)&allocp[5];
  allocp += 11;
  proceed();
 case functor_putwtq_1:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klicio_xupdt_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_unparser_xunwparse_4);
  x3 = arg(x0, 0);
  allocp[7] = x3;
  allocp[8] = a2;
  allocp[9] = a1;
  allocp[10] = x2;
  qp = (struct goalrec*)&allocp[5];
  allocp += 11;
  proceed();
 case functor_addop_3:
 updt_3_15:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_s_2)) goto updt_3_29;
  allocp[0] = makesym(functor_s_2);
  allocp[1] = x2 = makeref(&allocp[1]);
  x3 = arg(a2, 1);
  allocp[2] = x3;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = (q)qp;
  allocp[4] = (q)(&predicate_klicio_xupdt_3);
  x4 = cdr_of(a0);
  allocp[5] = x4;
  allocp[6] = a1;
  allocp[7] = x1;
  a0 = arg(x0, 1);
  a1 = arg(x0, 0);
  x5 = arg(x0, 2);
  a3 = arg(a2, 0);
  a4 = x2;
  a2 = x5;
  qp = (struct goalrec*)&allocp[3];
  allocp += 8;
  execute(addop_5_0);
  goto addop_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,updt_3_15);
  *reasonp++ =  a2;
  goto updt_3_29;
  };
  goto updt_3_29;
 case functor_rmop_2:
 updt_3_19:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_s_2)) goto updt_3_29;
  allocp[0] = makesym(functor_s_2);
  allocp[1] = x2 = makeref(&allocp[1]);
  x3 = arg(a2, 1);
  allocp[2] = x3;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = (q)qp;
  allocp[4] = (q)(&predicate_klicio_xupdt_3);
  x4 = cdr_of(a0);
  allocp[5] = x4;
  allocp[6] = a1;
  allocp[7] = x1;
  a0 = arg(x0, 1);
  a1 = arg(x0, 0);
  a2 = arg(a2, 0);
  a3 = x2;
  qp = (struct goalrec*)&allocp[3];
  allocp += 8;
  execute(rmop_4_0);
  goto rmop_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,updt_3_19);
  *reasonp++ =  a2;
  goto updt_3_29;
  };
  goto updt_3_29;
 case functor_on__error_1:
 updt_3_23:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_s_2)) goto updt_3_29;
  allocp[0] = makesym(functor_s_2);
  x2 = arg(a2, 0);
  allocp[1] = x2;
  x3 = arg(x0, 0);
  allocp[2] = x3;
  x1 = makefunctor(&allocp[0]);
  a0 = cdr_of(a0);
  a2 = x1;
  allocp += 3;
  execute(updt_3_0);
  goto updt_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,updt_3_23);
  *reasonp++ =  a2;
  goto updt_3_29;
  };
  goto updt_3_29;
 default:
  goto updt_3_29;
  };
 case VARREF:
  deref_and_jump(x0,updt_3_3);
  *reasonp++ =  x0;
  goto updt_3_29;
  };
  goto updt_3_29;
 case ATOMIC:
  if (a0 != NILATOM) goto updt_3_29;
  unify_value(a1, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a0,updt_3_1);
  *reasonp++ =  a0;
  goto updt_3_29;
  };
  goto updt_3_29;
 updt_3_29:
  otherwise(updt_3_interrupt);
 updt_3_31:
  switch (ptagof(a0)) {
 case CONS:
 updt_3_33:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_s_2)) goto updt_3_interrupt;
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = makesym(functor_s_2);
  x4 = arg(a2, 0);
  allocp[1] = x4;
  x5 = arg(a2, 1);
  allocp[2] = x5;
  x3 = makefunctor(&allocp[0]);
  a0 = cdr_of(a0);
  a1 = x1;
  a2 = x3;
  allocp += 3;
  execute(updt_3_0);
  goto updt_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,updt_3_33);
  *reasonp++ =  a2;
  goto updt_3_interrupt;
  };
  goto updt_3_interrupt;
 case VARREF:
  deref_and_jump(a0,updt_3_31);
  *reasonp++ =  a0;
  goto updt_3_interrupt;
  };
  goto updt_3_interrupt;
 updt_3_ext_interrupt:
  reasonp = 0l;
 updt_3_interrupt:
  goto interrupt_3;
 }

 addop_5_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 addop_5_clear_reason:
  reasonp = reasons;
 addop_5_0:
 addop_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto addop_5_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_fx)):
 addop_5_5:
  switch (ptagof(a3)) {
 case FUNCTOR:
  if (functor_of(a3) != makesym(functor_ops_3)) goto addop_5_interrupt;
  allocp[0] = makesym(functor_ops_3);
  allocp[1] = x1 = makeref(&allocp[1]);
  x2 = arg(a3, 1);
  allocp[2] = x2;
  x3 = arg(a3, 2);
  allocp[3] = x3;
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a4, x0);
  a0 = a1;
  a1 = makesym(atom_fx);
  a3 = arg(a3, 0);
  a4 = x1;
  execute(addop2_5_0);
  goto addop2_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a3,addop_5_5);
  *reasonp++ =  a3;
  goto addop_5_interrupt;
  };
  goto addop_5_interrupt;
 case symval(makesym(atom_fy)):
 addop_5_9:
  switch (ptagof(a3)) {
 case FUNCTOR:
  if (functor_of(a3) != makesym(functor_ops_3)) goto addop_5_interrupt;
  allocp[0] = makesym(functor_ops_3);
  allocp[1] = x1 = makeref(&allocp[1]);
  x2 = arg(a3, 1);
  allocp[2] = x2;
  x3 = arg(a3, 2);
  allocp[3] = x3;
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a4, x0);
  a0 = a1;
  a1 = makesym(atom_fy);
  a3 = arg(a3, 0);
  a4 = x1;
  execute(addop2_5_0);
  goto addop2_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a3,addop_5_9);
  *reasonp++ =  a3;
  goto addop_5_interrupt;
  };
  goto addop_5_interrupt;
 case symval(makesym(atom_xfx)):
 addop_5_13:
  switch (ptagof(a3)) {
 case FUNCTOR:
  if (functor_of(a3) != makesym(functor_ops_3)) goto addop_5_interrupt;
  allocp[0] = makesym(functor_ops_3);
  x1 = arg(a3, 0);
  allocp[1] = x1;
  allocp[2] = x2 = makeref(&allocp[2]);
  x3 = arg(a3, 2);
  allocp[3] = x3;
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a4, x0);
  a0 = a1;
  a1 = makesym(atom_xfx);
  a3 = arg(a3, 1);
  a4 = x2;
  execute(addop2_5_0);
  goto addop2_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a3,addop_5_13);
  *reasonp++ =  a3;
  goto addop_5_interrupt;
  };
  goto addop_5_interrupt;
 case symval(makesym(atom_xfy)):
 addop_5_17:
  switch (ptagof(a3)) {
 case FUNCTOR:
  if (functor_of(a3) != makesym(functor_ops_3)) goto addop_5_interrupt;
  allocp[0] = makesym(functor_ops_3);
  x1 = arg(a3, 0);
  allocp[1] = x1;
  allocp[2] = x2 = makeref(&allocp[2]);
  x3 = arg(a3, 2);
  allocp[3] = x3;
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a4, x0);
  a0 = a1;
  a1 = makesym(atom_xfy);
  a3 = arg(a3, 1);
  a4 = x2;
  execute(addop2_5_0);
  goto addop2_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a3,addop_5_17);
  *reasonp++ =  a3;
  goto addop_5_interrupt;
  };
  goto addop_5_interrupt;
 case symval(makesym(atom_yfx)):
 addop_5_21:
  switch (ptagof(a3)) {
 case FUNCTOR:
  if (functor_of(a3) != makesym(functor_ops_3)) goto addop_5_interrupt;
  allocp[0] = makesym(functor_ops_3);
  x1 = arg(a3, 0);
  allocp[1] = x1;
  allocp[2] = x2 = makeref(&allocp[2]);
  x3 = arg(a3, 2);
  allocp[3] = x3;
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a4, x0);
  a0 = a1;
  a1 = makesym(atom_yfx);
  a3 = arg(a3, 1);
  a4 = x2;
  execute(addop2_5_0);
  goto addop2_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a3,addop_5_21);
  *reasonp++ =  a3;
  goto addop_5_interrupt;
  };
  goto addop_5_interrupt;
 case symval(makesym(atom_xf)):
 addop_5_25:
  switch (ptagof(a3)) {
 case FUNCTOR:
  if (functor_of(a3) != makesym(functor_ops_3)) goto addop_5_interrupt;
  allocp[0] = makesym(functor_ops_3);
  x1 = arg(a3, 0);
  allocp[1] = x1;
  x2 = arg(a3, 1);
  allocp[2] = x2;
  allocp[3] = x3 = makeref(&allocp[3]);
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a4, x0);
  a0 = a1;
  a1 = makesym(atom_xf);
  a3 = arg(a3, 2);
  a4 = x3;
  execute(addop2_5_0);
  goto addop2_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a3,addop_5_25);
  *reasonp++ =  a3;
  goto addop_5_interrupt;
  };
  goto addop_5_interrupt;
 case symval(makesym(atom_yf)):
 addop_5_29:
  switch (ptagof(a3)) {
 case FUNCTOR:
  if (functor_of(a3) != makesym(functor_ops_3)) goto addop_5_interrupt;
  allocp[0] = makesym(functor_ops_3);
  x1 = arg(a3, 0);
  allocp[1] = x1;
  x2 = arg(a3, 1);
  allocp[2] = x2;
  allocp[3] = x3 = makeref(&allocp[3]);
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a4, x0);
  a0 = a1;
  a1 = makesym(atom_yf);
  a3 = arg(a3, 2);
  a4 = x3;
  execute(addop2_5_0);
  goto addop2_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a3,addop_5_29);
  *reasonp++ =  a3;
  goto addop_5_interrupt;
  };
  goto addop_5_interrupt;
 default:
  goto addop_5_interrupt;
  };
 case VARREF:
  deref_and_jump(a0,addop_5_1);
  *reasonp++ =  a0;
  goto addop_5_interrupt;
  };
  goto addop_5_interrupt;
 addop_5_ext_interrupt:
  reasonp = 0l;
 addop_5_interrupt:
  toppred = &predicate_klicio_xaddop_5;
  goto interrupt_5;
 }

 addop2_5_top: {
  q x0, x1, x2, x3, x4;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 addop2_5_clear_reason:
  reasonp = reasons;
 addop2_5_0:
 addop2_5_1:
  switch (ptagof(a3)) {
 case CONS:
  x0 = car_of(a3);
 addop2_5_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_op_3)) goto addop2_5_16;
  x1 = arg(x0, 0);
 addop2_5_6:
  if (isref(x1)) goto addop2_5_12;
 addop2_5_8:
  if (isref(x1)) goto addop2_5_11;
  if_not_equal(x1, a0, addop2_5_16);
  allocp[0] = makesym(functor_op_3);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  x2 = makefunctor(&allocp[0]);
  x4 = cdr_of(a3);
  allocp[4] = x4;
  allocp[5] = x2;
  x3 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a4, x3);
  proceed();
 addop2_5_11:
  deref_and_jump(x1,addop2_5_8);
  *reasonp++ =  x1;
  goto addop2_5_16;
 addop2_5_12:
  deref_and_jump(x1,addop2_5_6);
  *reasonp++ =  x1;
  goto addop2_5_16;
 case VARREF:
  deref_and_jump(x0,addop2_5_3);
  *reasonp++ =  x0;
  goto addop2_5_16;
  };
  goto addop2_5_16;
 case ATOMIC:
  if (a3 != NILATOM) goto addop2_5_16;
  allocp[0] = makesym(functor_op_3);
  allocp[1] = a0;
  allocp[2] = a1;
  allocp[3] = a2;
  x0 = makefunctor(&allocp[0]);
  allocp[4] = NILATOM;
  allocp[5] = x0;
  x1 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a4, x1);
  proceed();
 case VARREF:
  deref_and_jump(a3,addop2_5_1);
  *reasonp++ =  a3;
  goto addop2_5_16;
  };
  goto addop2_5_16;
 addop2_5_16:
  otherwise(addop2_5_interrupt);
 addop2_5_18:
  switch (ptagof(a3)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a3);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a4, x0);
  a3 = cdr_of(a3);
  a4 = x1;
  execute(addop2_5_0);
  goto addop2_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a3,addop2_5_18);
  *reasonp++ =  a3;
  goto addop2_5_interrupt;
  };
  goto addop2_5_interrupt;
 addop2_5_ext_interrupt:
  reasonp = 0l;
 addop2_5_interrupt:
  toppred = &predicate_klicio_xaddop2_5;
  goto interrupt_5;
 }

 rmop_4_top: {
  q x0, x1, x2, x3;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 rmop_4_clear_reason:
  reasonp = reasons;
 rmop_4_0:
 rmop_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto rmop_4_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_fx)):
 rmop_4_5:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_ops_3)) goto rmop_4_interrupt;
  allocp[0] = makesym(functor_ops_3);
  allocp[1] = x1 = makeref(&allocp[1]);
  x2 = arg(a2, 1);
  allocp[2] = x2;
  x3 = arg(a2, 2);
  allocp[3] = x3;
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a3, x0);
  a0 = a1;
  a1 = makesym(atom_fx);
  a2 = arg(a2, 0);
  a3 = x1;
  execute(rmop2_4_0);
  goto rmop2_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,rmop_4_5);
  *reasonp++ =  a2;
  goto rmop_4_interrupt;
  };
  goto rmop_4_interrupt;
 case symval(makesym(atom_fy)):
 rmop_4_9:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_ops_3)) goto rmop_4_interrupt;
  allocp[0] = makesym(functor_ops_3);
  allocp[1] = x1 = makeref(&allocp[1]);
  x2 = arg(a2, 1);
  allocp[2] = x2;
  x3 = arg(a2, 2);
  allocp[3] = x3;
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a3, x0);
  a0 = a1;
  a1 = makesym(atom_fy);
  a2 = arg(a2, 0);
  a3 = x1;
  execute(rmop2_4_0);
  goto rmop2_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,rmop_4_9);
  *reasonp++ =  a2;
  goto rmop_4_interrupt;
  };
  goto rmop_4_interrupt;
 case symval(makesym(atom_xfx)):
 rmop_4_13:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_ops_3)) goto rmop_4_interrupt;
  allocp[0] = makesym(functor_ops_3);
  x1 = arg(a2, 0);
  allocp[1] = x1;
  allocp[2] = x2 = makeref(&allocp[2]);
  x3 = arg(a2, 2);
  allocp[3] = x3;
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a3, x0);
  a0 = a1;
  a1 = makesym(atom_xfx);
  a2 = arg(a2, 1);
  a3 = x2;
  execute(rmop2_4_0);
  goto rmop2_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,rmop_4_13);
  *reasonp++ =  a2;
  goto rmop_4_interrupt;
  };
  goto rmop_4_interrupt;
 case symval(makesym(atom_xfy)):
 rmop_4_17:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_ops_3)) goto rmop_4_interrupt;
  allocp[0] = makesym(functor_ops_3);
  x1 = arg(a2, 0);
  allocp[1] = x1;
  allocp[2] = x2 = makeref(&allocp[2]);
  x3 = arg(a2, 2);
  allocp[3] = x3;
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a3, x0);
  a0 = a1;
  a1 = makesym(atom_xfy);
  a2 = arg(a2, 1);
  a3 = x2;
  execute(rmop2_4_0);
  goto rmop2_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,rmop_4_17);
  *reasonp++ =  a2;
  goto rmop_4_interrupt;
  };
  goto rmop_4_interrupt;
 case symval(makesym(atom_yfx)):
 rmop_4_21:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_ops_3)) goto rmop_4_interrupt;
  allocp[0] = makesym(functor_ops_3);
  x1 = arg(a2, 0);
  allocp[1] = x1;
  allocp[2] = x2 = makeref(&allocp[2]);
  x3 = arg(a2, 2);
  allocp[3] = x3;
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a3, x0);
  a0 = a1;
  a1 = makesym(atom_yfx);
  a2 = arg(a2, 1);
  a3 = x2;
  execute(rmop2_4_0);
  goto rmop2_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,rmop_4_21);
  *reasonp++ =  a2;
  goto rmop_4_interrupt;
  };
  goto rmop_4_interrupt;
 case symval(makesym(atom_xf)):
 rmop_4_25:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_ops_3)) goto rmop_4_interrupt;
  allocp[0] = makesym(functor_ops_3);
  x1 = arg(a2, 0);
  allocp[1] = x1;
  x2 = arg(a2, 1);
  allocp[2] = x2;
  allocp[3] = x3 = makeref(&allocp[3]);
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a3, x0);
  a0 = a1;
  a1 = makesym(atom_xf);
  a2 = arg(a2, 2);
  a3 = x3;
  execute(rmop2_4_0);
  goto rmop2_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,rmop_4_25);
  *reasonp++ =  a2;
  goto rmop_4_interrupt;
  };
  goto rmop_4_interrupt;
 case symval(makesym(atom_yf)):
 rmop_4_29:
  switch (ptagof(a2)) {
 case FUNCTOR:
  if (functor_of(a2) != makesym(functor_ops_3)) goto rmop_4_interrupt;
  allocp[0] = makesym(functor_ops_3);
  x1 = arg(a2, 0);
  allocp[1] = x1;
  x2 = arg(a2, 1);
  allocp[2] = x2;
  allocp[3] = x3 = makeref(&allocp[3]);
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a3, x0);
  a0 = a1;
  a1 = makesym(atom_yf);
  a2 = arg(a2, 2);
  a3 = x3;
  execute(rmop2_4_0);
  goto rmop2_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,rmop_4_29);
  *reasonp++ =  a2;
  goto rmop_4_interrupt;
  };
  goto rmop_4_interrupt;
 default:
  goto rmop_4_interrupt;
  };
 case VARREF:
  deref_and_jump(a0,rmop_4_1);
  *reasonp++ =  a0;
  goto rmop_4_interrupt;
  };
  goto rmop_4_interrupt;
 rmop_4_ext_interrupt:
  reasonp = 0l;
 rmop_4_interrupt:
  toppred = &predicate_klicio_xrmop_4;
  goto interrupt_4;
 }

 rmop2_4_top: {
  q x0, x1, x2;
  a1 = qp->args[1];
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 rmop2_4_clear_reason:
  reasonp = reasons;
 rmop2_4_0:
 rmop2_4_1:
  switch (ptagof(a2)) {
 case CONS:
  x0 = car_of(a2);
 rmop2_4_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_op_3)) goto rmop2_4_16;
  x1 = arg(x0, 0);
 rmop2_4_6:
  if (isref(x1)) goto rmop2_4_12;
 rmop2_4_8:
  if (isref(x1)) goto rmop2_4_11;
  if_not_equal(x1, a0, rmop2_4_16);
  x2 = cdr_of(a2);
  unify(a3, x2);
  proceed();
 rmop2_4_11:
  deref_and_jump(x1,rmop2_4_8);
  *reasonp++ =  x1;
  goto rmop2_4_16;
 rmop2_4_12:
  deref_and_jump(x1,rmop2_4_6);
  *reasonp++ =  x1;
  goto rmop2_4_16;
 case VARREF:
  deref_and_jump(x0,rmop2_4_3);
  *reasonp++ =  x0;
  goto rmop2_4_16;
  };
  goto rmop2_4_16;
 case ATOMIC:
  if (a2 != NILATOM) goto rmop2_4_16;
  unify_value(a3, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a2,rmop2_4_1);
  *reasonp++ =  a2;
  goto rmop2_4_16;
  };
  goto rmop2_4_16;
 rmop2_4_16:
  otherwise(rmop2_4_interrupt);
 rmop2_4_18:
  switch (ptagof(a2)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a2);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a3, x0);
  a2 = cdr_of(a2);
  a3 = x1;
  execute(rmop2_4_0);
  goto rmop2_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,rmop2_4_18);
  *reasonp++ =  a2;
  goto rmop2_4_interrupt;
  };
  goto rmop2_4_interrupt;
 rmop2_4_ext_interrupt:
  reasonp = 0l;
 rmop2_4_interrupt:
  toppred = &predicate_klicio_xrmop2_4;
  goto interrupt_4;
 }

 default__operator__table_1_top: {
  qp = qp->next;
 default__operator__table_1_clear_reason:
  reasonp = reasons;
 default__operator__table_1_0:
  unify_value(a0, makefunctor(funct_const_185));
  proceed();
 default__operator__table_1_ext_interrupt:
  reasonp = 0l;
 default__operator__table_1_interrupt:
  toppred = &predicate_klicio_xdefault__operator__table_1;
  goto interrupt_1;
 }
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_klicio);
}
