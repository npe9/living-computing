/* ---------------------------------------------------------- 
%   (C)1993 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */

#include <klic/config.h>

#ifdef MAIN
#define Extern
#define Init(x)		= x
#define Size(size)	size
#else
#define Extern		extern
#define Init(x)
#define Size(size)
#endif

#ifdef __STDC__
#define Const		const
#define Volatile	volatile
#else
#define Const
#define Volatile
#endif

#ifdef __GNUC__
#define Inline		__inline__
#else
#define Inline
#endif

extern Volatile fatal();
extern Volatile fatalf();
extern Volatile fatalp();
extern void debug_printf();
