#include <klic/basic.h>
#include <klic/struct.h>
#include <klic/primitives.h>
#include <klic/unify.h>
#include <klic/functorstuffs.h> 
#include <klic/timing.h>

#include <klic/gb.h>
#include <klic/gobj.h>
#include <klic/susp.h>
#include <klic/newatom.h>
#include <klic/functorstuffs.h>
#include <klic/atomstuffs.h>

#include <stdio.h>
#include <setjmp.h>

#include <klic/interpe.h>
#include <klic/traceio.h>

void *decode_atomic_level0();
void *decode_exref_level0();
void *decode_const();

void encode_data_level0(node, data)
     q data;
     long node;
{
  long index, wec;
  declare_globals;

 Retry_top:
  switch (ptagof(data)){
    case ATOMIC:
      if (issym(data) &&
	  symval(data) >= numberOfAtoms+ATOMNUMBERBASE) {
	sprintf(iobuf,"numberOfAtoms %d\n",numberOfAtoms);
	EPrint(iobuf);
	sprintf(iobuf,"symval(data) %d\n",symval(data));
	EPrint(iobuf);
	fatal("cannot send new atom");
      } else{
	PUT_BUFFER(node, decode_atomic_level0);  
	PUT_BUFFER(node, data);
      }	
      break;
    case CONS:
    case FUNCTOR:
      if ((q*)data < heaptop ||
	  (q*)data >= heaptop+heapsize+incrementsize) {
	PUT_BUFFER(node, decode_const);
	PUT_BUFFER(node, data);
      } else {
      Consume_Undef:
	PUT_BUFFER(node, decode_exref_level0);  
      
	index = regist_exptbl(data);
	wec   = regist_exptbl_wec;

	PUT_BUFFER(node, my_node);
	PUT_BUFFER(node, index);
	PUT_BUFFER(node, wec);
      }
      break;

    case VARREF:
      {
	q temp = derefone(data);
      deref_x:
	if (data != temp){
	  if (isref(temp)) {
	    q temp1 = derefone(temp);
	    if (temp1 == data) {
	      struct susprec *sdata = (struct susprec *)temp;
	      if(is_generator_susp(sdata->u)){
		/* generator */
		struct generator_susp *genobj = generator_suspp(sdata);

		if(generic_encode(untag_generator_susp(genobj->u.o), node)){
		  goto Consume_Undef;
		}

	      } else {
		/* consumer, goal */
		goto Consume_Undef;
	      }
	    } else {
	      /* REF $B$,B3$/(B */
	      data = temp;
	      temp = temp1;
	      goto deref_x;
	    }
	  } else {
	    /* $B6qBN2=$7$F$?(B */
	    data = temp;
	    goto Retry_top;
	  }
	} else {
	  /* $BC1=cJQ?t(B */
	  goto Consume_Undef;
	}
      }
      break;
    default:
      break;
    }
}

q *decode_list_level1();
q *decode_funct_level1();

void encode_data_level1(node, data, depth)
     long node;
     q data;
     int depth;
{
  int i;
  declare_globals;

 again:
  switch (ptagof(data)){
    case ATOMIC:
      if (issym(data) &&
	  symval(data) >= numberOfAtoms+ATOMNUMBERBASE) {
	sprintf(iobuf,"numberOfAtoms %d\n",numberOfAtoms);
	EPrint(iobuf);
	sprintf(iobuf,"symval(data) %d\n",symval(data));
	EPrint(iobuf);
	fatal("cannot send new atom");
      } else {
	PUT_BUFFER(node, decode_atomic_level0);  
	PUT_BUFFER(node, data);
      } 
      break;
    case CONS:
      if ((q*)data < heaptop ||
	  (q*)data >= heaptop+heapsize+incrementsize) {
	PUT_BUFFER(node, decode_const);
	PUT_BUFFER(node, data);
      } else {
	PUT_BUFFER(node, decode_list_level1);  
	if (!eager_transfer_flag || depth == 0) {
	  encode_data_level0(node, car_of(data));
	  encode_data_level0(node, cdr_of(data));
	} else {
	  depth--;
	  encode_data_level1(node, car_of(data), depth);
	  data = cdr_of(data);
	  goto again;
	}
      }
      break;
    case FUNCTOR:
      if ((q*)data < heaptop ||
	  (q*)data >= heaptop+heapsize+incrementsize) {
	PUT_BUFFER(node, decode_const);
	PUT_BUFFER(node, data);
      } else {
	q f = functor_of(data);
	if (isref(f)) { /* data_object */
	  generic_encode((struct data_object *)functorp(data), node);	  
	} else {      /* functor */
	  if((symval(f) - FUNCTORNUMBERBASE) >= numberOfFunctors){
	    sprintf(iobuf,"numberOfFunctors %d\n",numberOfFunctors);
	    EPrint(iobuf);
	    sprintf(iobuf,"symval(data) %d\n",symval(f));
	    EPrint(iobuf);
	    fatal("cannot send new functor Now");
	  } else{
	    int arity1 = arityof(functor_of(data)) - 1;
	    PUT_BUFFER(node, decode_funct_level1);  
	    PUT_BUFFER(node, functor_of(data));  
	    depth--;
	    for (i = 0; i < arity1; i++) {
	      if(!eager_transfer_flag || depth == 0){
		encode_data_level0(node, arg(data, i));
	      } else {
		encode_data_level1(node, arg(data, i), depth);
	      }
	    }
	    data = arg(data, arity1);
	    goto again;
	  }
	}
      }
      break;	   
      case VARREF:
      encode_data_level0(node, data);
      break;
    }
}

long get_wtc();

Extern void *decode_throw();

long encode_throw_goal(goal, node)
     struct goalrec *goal;
     long node;
{
  struct predicate *pred_of_goal;
  int arity,i;
  long wtc;
  declare_globals;

#ifdef INT_CL_PROBE
  send_throw_cnt++;
#endif
  PUT_BUFFER(node, decode_throw);

  wtc = get_wtc(THROW_WTC_UNIT);
  if(wtc == 0){
    PUT_BUFFER(node, THROW_WTC_UNIT);
  } else {
    PUT_BUFFER(node, wtc);
  }

  PUT_BUFFER(node, (long)current_prio);
  PUT_BUFFER(node, goal->pred);

  arity = (int) (goal->pred->arity);
  for(i=0;i<arity;i++){
    if(!eager_transfer_flag){
      encode_data_level0(node, goal->args[i]);
    } else {
      encode_data_level1(node, goal->args[i], eager_transfer_level);
    }
  }
  return(wtc);
}

Extern void *decode_read();

long encode_read(node, index, var)
     long node, index;
     q var;
{
  int ret_index,wec,wtc;

#ifdef INT_CL_PROBE
  send_read_cnt++;
#endif

  PUT_BUFFER(node, decode_read);

  wtc = get_wtc(READ_WTC_UNIT);
  if(wtc == 0){
    PUT_BUFFER(node, READ_WTC_UNIT);
  } else {
    PUT_BUFFER(node, wtc);
  }

  PUT_BUFFER(node, index);

  ret_index = regist_exptbl(var);
  wec = regist_exptbl_wec;

  PUT_BUFFER(node, my_node);
  PUT_BUFFER(node, ret_index);
  PUT_BUFFER(node, wec);

  global_ret_index = ret_index;
  return(wtc);
}

Extern void *decode_answer_value();

long encode_answer_value(data, node, index, wec)
     q data;
     long node, index, wec;
{
  long wtc;
#ifdef INT_CL_PROBE
  send_answer_cnt++;
#endif

  PUT_BUFFER(node, decode_answer_value);  

  wtc = get_wtc(ANSWER_WTC_UNIT);
  if(wtc == 0){
    PUT_BUFFER(node, ANSWER_WTC_UNIT);
  } else {
    PUT_BUFFER(node, wtc);
  }

  PUT_BUFFER(node, index);  
  PUT_BUFFER(node, wec);  

  encode_data_level1(node, data, eager_transfer_level);
  return(wtc);
}

Extern void *decode_unify();

long encode_unify(node, index, wec, data)
     q data;
     long node, index, wec;
{
  long wtc;
#ifdef INT_CL_PROBE
  send_unify_cnt++;
#endif
  PUT_BUFFER(node, decode_unify);

  wtc = get_wtc(UNIFY_WTC_UNIT);
  if(wtc == 0){
    PUT_BUFFER(node, UNIFY_WTC_UNIT);
  } else {
    PUT_BUFFER(node, wtc);
  }

  PUT_BUFFER(node, index);
  PUT_BUFFER(node, wec);

  encode_data_level1(node, data, eager_transfer_level);
  return(wtc);
}

Extern void *decode_release();

void encode_release(node, index, wec)
{
#ifdef INT_CL_PROBE
  send_release_cnt++;
#endif

  PUT_BUFFER(node, decode_release);
  PUT_BUFFER(node, index);
  PUT_BUFFER(node, wec);
}

Extern void *decode_request_wtc();

void encode_request_wtc()
{
#ifdef INT_CL_PROBE
  send_request_wtc_cnt++;
#endif
  PUT_BUFFER(SHOEN_NODE, decode_request_wtc);
  PUT_BUFFER(SHOEN_NODE, my_node);
  node_wtc--;

  if(node_wtc < 1){
    sprintf(iobuf,"Request WTC, Invalid WTC in Node (2) %d\n", my_node);
    EPrint(iobuf);
    fatal("Invalid WTC");
  }
}

Extern void *decode_supply_wtc();

void encode_supply_wtc(node)
     long node;
{
  if(my_node != SHOEN_NODE){
    fatal("FP node try to send supply wtc");
  }
#ifdef INT_CL_PROBE
  send_supply_wtc_cnt++;
#endif
  PUT_BUFFER(node, decode_supply_wtc);
  shoen_wtc = shoen_wtc - SUPPLY_WTC_UNIT;
}

long get_wtc(request)
     long request;
{
  long ret_request;
  if(node_wtc < 1){
    sprintf(iobuf,"Invalid WTC in Node (2)%d\n", my_node);
    EPrint(iobuf);
    fatal("Invalid WTC");
  }

  if(node_wtc == 1){
    if(!requesting_wtc){
      sprintf(iobuf,"Invalid WTC in Node (1)%d\n", my_node);
      EPrint(iobuf);
      fatal("Invalid WTC");
    }
    return(0);
  }

  if(node_wtc < (MIN_WTC*2)){
/*    sprintf(iobuf,"WTC limit %d\n");
    EPrint(iobuf);*/
    return(0);
  }

  if(node_wtc > request*2){
    node_wtc = node_wtc - request;
    return(request);    
  } else {
    ret_request = node_wtc>>1;
    node_wtc = node_wtc - ret_request;

    if(node_wtc < MIN_WTC){
      sprintf(iobuf,"Node WTC is %d in Node %d\n",node_wtc, my_node);
      EPrint(iobuf);
      sprintf(iobuf,"And request is %d \n",request);
      EPrint(iobuf);

      fatal("Invalid WTC");
    }
    return(ret_request);        
  }
}

void decode_return_wtc();

void encode_return_wtc()
{
  PUT_BUFFER(SHOEN_NODE, decode_return_wtc);
  PUT_BUFFER(SHOEN_NODE, node_wtc);
  node_wtc = 0;
}

void decode_terminate_msg();

void encode_terminate_msg(node)
     long node;
{
  PUT_BUFFER(node, decode_terminate_msg);
}


