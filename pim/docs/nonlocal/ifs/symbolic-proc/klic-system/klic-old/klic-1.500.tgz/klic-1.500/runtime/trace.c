/* ---------------------------------------------------------- 
%   (C)1993,1994 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
#include <ctype.h>
#include <klic/basic.h>
#include <klic/struct.h>
#include <klic/primitives.h>
#include <klic/predinfo.h>
#include <klic/trace.h>
#include <klic/generic.h>
#include <klic/functorstuffs.h>
#ifdef STRINGH
#include <string.h>
#else
#include <strings.h>
#endif
#include <stdio.h>
#include <setjmp.h>

#ifdef USESTRCHR
#define Strchr strchr
#else
#define Strchr index
#endif

#ifdef DIST
#include <klic/traceio.h>
#endif

/* Some systems needs an underline to be prefixed to a C label */
int prefix_length;

extern char *realloc_check();
extern char *malloc_check();
extern char *calloc();
extern void free();

long dump_queue();

struct mod_table_entry {
  module (*func)();
  Const unsigned char *name;
} *mod_table = 0, **mod_index;

static struct pred_table_entry {
  Const struct predicate *pred;
  Const struct mod_table_entry *mte;
  Const unsigned char *name;
  char spied;
  char default_trace;
} *pred_table = 0;

enum trace_port {
  Call, Susp, Reduce, Fail, AllPorts, NoMorePort, UnknownPort };
static int enabled, leashed, leaping, spying;

#define Enabled(port)	((enabled >> (int)(port)) & 1)
#define Leashed(port)	((leashed >> (int)(port)) & 1)

FILE *tracer_input;

/* For remembering goals resumed during reduction */

static int n_resumed;
static struct goalrec **different_prio_resume;
static int max_different_prio_resume = 0;

/****************************************
  Predicate and Module Tables
****************************************/

static unsigned int n_mod, n_pred;

static mod_compare_names(x, y)
     struct mod_table_entry *x, *y;
{
  return strcmp((char *)x->name, (char *)y->name);
}

static mod_compare_addr(x, y)
     struct mod_table_entry **x, **y;
{
  return (long)(*x)->func - (long)(*y)->func;
}

static pred_compare_names(x, y)
     struct pred_table_entry *x, *y;
{
  int result;
  if (!(result = strcmp((char *)x->mte->name, (char *)y->mte->name)))
    if (!(result = strcmp((char *)x->name, (char *)y->name)))
      result = x->pred->arity - y->pred->arity;
  return result;
}  

static struct mod_table_entry *get_mte(pred)
     struct predicate *pred;
{
  module mod = (module)pred->func;
  unsigned int low = 0, high = n_mod, mid;
  while (low != high) {
    mid = ((high+low) >> 1);
    if ((module)mod_index[mid]->func == mod) {
      return mod_index[mid];
    } else if ((unsigned long)mod_index[mid]->func > (unsigned long)mod) {
      high = mid;
    } else {
      low = mid + 1;
    }
  }
  return 0;
}

static struct pred_hash_entry {
  struct predicate *pred;
  struct pred_table_entry *pte;
} *pred_hash;

static unsigned long pred_hash_mask;

static enter_pred_hash(pred, pte)
     struct predicate *pred;
     struct pred_table_entry *pte;
{
  long h = ((((unsigned long) pred) >> 2) & pred_hash_mask);
  while (pred_hash[h].pred != 0) {
    h = (h + 1) & pred_hash_mask;
  }
  pred_hash[h].pred = pred;
  pred_hash[h].pte = pte;
}  

static struct pred_table_entry *get_pte(pred)
     struct predicate *pred;
{
  long h = ((((unsigned long) pred) >> 2) & pred_hash_mask);
  while (pred_hash[h].pred != pred) {
    if (pred_hash[h].pred == 0) {
      /* somehow we couldn't find the predicate */
      static struct pred_table_entry dummy;
      dummy.pred = pred;
      dummy.mte = get_mte(pred);
      dummy.name = (unsigned char *)"???";
      dummy.spied = 0;
      return &dummy;
    }
    h = (h + 1) & pred_hash_mask;
  }
  return pred_hash[h].pte;
}  

extern Const struct modinfo defined_modules[];

static make_name_tables()
{
  declare_globals;
  int k;
  struct mod_table_entry *mte, **mtxe;
  struct pred_table_entry *pte;

  /* Let's first count the numbers of modules and predicates in this program */
  n_pred = 0;
  n_mod = 0;
  {
    Const struct modinfo *dm;
    for (dm = &defined_modules[0]; dm->name != 0; dm++) {
      Const struct predinfo * Const *dp;
      n_mod++;
      for (dp = &dm->preds[0]; *dp != 0; dp++) {
	n_pred++;
      }
    }
  }

  /* Allocate predicate table and its hash table */
  pred_table =
    (struct pred_table_entry *)
      calloc(n_pred, sizeof(struct pred_table_entry));
  {
    unsigned long hash_size = 1;
    while (hash_size <= (3*n_pred/2)) hash_size *= 2;
    pred_hash =
      (struct pred_hash_entry *)
	calloc(hash_size, sizeof(struct pred_hash_entry));
    pred_hash_mask = hash_size - 1;
    for (k = 0; k < hash_size; k++) {
      pred_hash[k].pred = 0;
      pred_hash[k].pte = 0;
    }
  }

  /* fill predicate table */
  pte = pred_table;
  {
    Const struct modinfo *dm;
    for (dm = &defined_modules[0]; dm->name != 0; dm++) {
      Const struct predinfo * Const *dp;
      for (dp = &dm->preds[0]; *dp != 0; dp++) {
	pte->name = (*dp)->name;
	pte->pred = (*dp)->predstruct;
	pte->spied = 0;
	pte->default_trace = 1;
	pte++;
      }
    }
  }

  /* allocate module table and its index */
  mod_table =
    (struct mod_table_entry *)
      calloc(n_mod, sizeof(struct mod_table_entry));
  mod_index =
    (struct mod_table_entry **)
      calloc(n_mod, sizeof(struct mod_table_entry *));

  mte = mod_table; mtxe = mod_index;

  /* fill module table */
  {
    Const struct modinfo *dm;
    for (dm = &defined_modules[0]; dm->name != 0; dm++) {
      mte->name = dm->name;
      mte->func = (*dm->preds)->predstruct->func;
      *mtxe++ = mte;
      mte++;
    }
  }

  qsort(mod_table, n_mod, sizeof(struct mod_table_entry),
	mod_compare_names);
  qsort(mod_index, n_mod, sizeof(struct mod_table_entry *),
	mod_compare_addr);

  for (k = 0; k < n_pred; k++) {
    pred_table[k].mte = get_mte(pred_table[k].pred);
  }

  qsort(pred_table, n_pred, sizeof(struct pred_table_entry),
	pred_compare_names);
  for (k = 0; k < n_pred; k++) {
    enter_pred_hash(pred_table[k].pred, &pred_table[k]);
  }
}

/****************************************
  Initiation
****************************************/

static int trace_initiated = 0;
static module trace_trigger_routine();
static struct predicate trace_trigger_preds[MAXSTDARGS+1];
static unsigned int trace_seq;
struct enqueue_trace_rec *trace_enqueued_goals;
static unsigned long trace_print_depth, trace_print_length;

static void reinitiate_trace()
{
  trace_seq = 2;
  trace_enqueued_goals = 0;
  leaping = 0;
  trace_initiated = 1;
}

void initiate_trace()
{
  int k;
  enabled = leashed = -1;	/* all one */
#ifndef DIST
#ifdef SETLINEBUF
  setlinebuf(stderr);
#endif
#endif
  make_name_tables();
  for (k=0; k<=MAXSTDARGS; k++) {
    trace_trigger_preds[k].func = trace_trigger_routine;
    trace_trigger_preds[k].pred = k;
    trace_trigger_preds[k].arity = k+2;
  }
  trace_print_depth = 3;
  trace_print_length = 7;
  n_resumed = 0;
  max_different_prio_resume = 16;
  different_prio_resume = (struct goalrec **)
    malloc_check(max_different_prio_resume*sizeof(struct goalrec *));
#ifndef DIST
  if ((tracer_input = fopen("/dev/tty", "r")) == NULL) {
    fatal("Can't open /dev/tty for trace command input");
  }
#endif
  reinitiate_trace();
}

#define InitTrace() { if (trace_initiated==0) initiate_trace(); }

/****************************************
  Main Tracing Routines
****************************************/

int trace_flag;
int verbose_print = 0;
static struct goalrec *qp_before;
static struct goalrec *parent;
static unsigned long parent_seq;

#define SUBGOAL_MAX 100
static char subgoal_trace[SUBGOAL_MAX];
static char is_resumed[SUBGOAL_MAX];
static int subgoal_seq[SUBGOAL_MAX];

#define SUBTERM_MAX 100
unsigned static long subterm_stack[SUBTERM_MAX];
int subterm_sp;

#define InitPort()	{ subterm_sp = 0; }

#define Traced(g)				\
  ((g)->pred->func == trace_trigger_routine)

struct goalrec *trace_goal(g, seq)
     struct goalrec *g;
     unsigned int seq;
{
  InitTrace();
  if (!Traced(g)) {
    declare_globals;
    struct goalrec *ng;
    Const struct predicate *pred = g->pred;
    unsigned int k, arity;
    arity = pred->arity;
    heapalloc(ng, arity+4, (struct goalrec *));
    ng->next = g->next;
    ng->pred = &trace_trigger_preds[arity];
    for (k=0; k!=arity; k++) {
      ng->args[k] = g->args[k];
    }
    ng->args[k] = makecons(pred);
    ng->args[k+1] = makeint(seq);
    return ng;
  } else {
    return g;
  }
}

static unsigned int trace_seq_of(g)
     struct goalrec *g;
{
  return intval(g->args[g->pred->arity-1]);
}

static unsigned int untrace_goal(g)
     struct goalrec *g;
{
  if (Traced(g)) {
    unsigned int real_arity = g->pred->arity-2;
    g->pred = (struct predicate *)consp(g->args[real_arity]);
    return intval(g->args[real_arity+1]);
  } else {
    return 0;
  }
}

/*
static struct goalrec *
copy_traced_goal(g)
     struct goalrec *g;
{
  int k;
  struct goalrec *cg =
    (struct goalrec *)malloc_check((g->pred->arity+2)*sizeof(q*));
  cg->pred = g->pred;
  for (k=0; k!=g->pred->arity; k++) {
    cg->args[k] = g->args[k];
  }
  return cg;
}
*/

static int
  call_port_command(), reduce_port_command(),
  susp_port_command(), fail_port_command();
static int
  print_debug_status(), print_port_names(),
  print_modules(), print_predicates();

static module trace_trigger_routine(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  q *allocp;
  Const struct predicate *toppred;
{
  extern module wait_prio_routine();
#ifdef DIST
  extern module wait_penum_routine();
#endif
  Const struct predicate *traced_pred;
  struct pred_table_entry *pte;

  InitPort();

  /* Rewrite the queue top goal record for traced goal */
  parent_seq = untrace_goal(qp);

 retry:
  traced_pred = qp->pred;
  if (traced_pred->func == wait_prio_routine) {
    declare_globals;
    struct goalrec *ng;
    int narity = qp->pred->arity - 3, k;
    heapalloc(ng, narity+2, (struct goalrec *));
    ng->pred = (struct predicate *)(consp(qp->args[narity]));
    for (k=0; k!=narity; k++) {
      ng->args[k] = qp->args[k];
    }
    ng->next = qp->next;
    qp = ng;
    goto retry;
  } 
#ifdef DIST
  else if (traced_pred->func == wait_penum_routine) {
    declare_globals;
    struct goalrec *ng;
    int narity = qp->pred->arity - 2, k;
    heapalloc(ng, narity+2, (struct goalrec *));
    ng->pred = (struct predicate *)(consp(qp->args[narity]));
    for (k=0; k!=narity; k++) {
      ng->args[k] = qp->args[k];
    }
    ng->next = qp->next;
    qp = ng;
    goto retry;
  } 
#endif 
  pte = get_pte(traced_pred);
  spying = pte->spied;
  qp_before = qp->next;
  trace_flag = 1;

  if (!leaping || spying) {
    parent = qp;
    if (Enabled(Call)) {
#ifdef DIST
      TRACE_ATTACHIO;
#endif
      for (;;) {
#ifdef DIST
	TRACE_FPRINTF2("%d:%4d CALL: ", my_node, parent_seq);
#else
	fprintf(stderr, "%4d CALL: ", parent_seq);
#endif
	print_goal(qp, 0);
	if (Leashed(Call) || spying) {
	  if (!call_port_command(qp, get_mte(qp->pred))) break;
	} else {
#ifdef DIST
	  TRACE_FPRINTF("\n");
#else
	  fprintf(stderr, "\n");
#endif
	  break;
	}
      }
    }
  }

  if (trace_flag) heaplimit = 0;
  return traced_pred->func(glbl, qp, allocp, traced_pred);
}

struct goalrec *trace_after(qp, allocp)
     struct goalrec *qp;
     q *allocp;
{
  declare_globals;
  struct goalrec *qt, *before = qp_before;
  unsigned int subgoals, k;
  struct goalrec **bsearch();
  struct enqueue_trace_rec *tr;

  InitPort();
  for (qt = qp, k = 0;
       qt != before && k < SUBGOAL_MAX;
       qt = qt->next, k++) {
    int j;
    different_prio_resume[n_resumed] = qt;
    for (j = 0; different_prio_resume[j] != qt; j++)
      ;
    if (j == n_resumed) {
      subgoal_trace[k] = get_pte(qt->pred)->default_trace;
      is_resumed[k] = 0;
      subgoal_seq[k] = trace_seq++;
    } else {
      if (subgoal_trace[k] = Traced(qt)) {
	subgoal_seq[k] = trace_seq_of(qt);
      } else {
	subgoal_seq[k] = trace_seq++;
      }
      is_resumed[k] = 1;
    }
  }
  for (tr = trace_enqueued_goals;
       tr != 0 && k < SUBGOAL_MAX;
       tr = tr->next, k++) {
    int j;
    different_prio_resume[n_resumed] = tr->g;
    for (j = 0; different_prio_resume[j] != tr->g; j++)
      ;
    if (j == n_resumed) {
      subgoal_seq[k] = trace_seq++;
      subgoal_trace[k] = 1;
      is_resumed[k] = 0;
    } else {
      if (subgoal_trace[k] = Traced(tr->g)) {
	subgoal_seq[k] = trace_seq_of(tr->g);
      } else {
	subgoal_seq[k] = trace_seq++;
      }
      is_resumed[k] = 1;
    }
  }
       
  subgoals = k;
  n_resumed = 0;

  if (Enabled(Reduce) && (!leaping || spying)) {
#ifdef DIST
    TRACE_ATTACHIO;
#endif
    for (;;) {
#ifdef DIST
      TRACE_FPRINTF2("%d:%4d REDU: ", my_node, parent_seq);
#else
      fprintf(stderr, "%4d REDU: ", parent_seq);
#endif
      print_goal(parent, 0);
      if (subgoals != 0) {
#ifdef DIST
        SystemPrint(" :-");
#else
	fprintf(stderr, " :-");
#endif
	k = 0;
	for (qt = qp;
	     qt != before;
	     qt = qt->next, k++) {
#ifdef DIST
	  TRACE_FPRINTF4("\n%4d%4d%c%c",
		  subgoal_seq[k],
		  k,
		  (k < SUBGOAL_MAX && is_resumed[k] ? '!' : ':'),
		  (k < SUBGOAL_MAX && subgoal_trace[k] ? '+' : '-' ));
#else
	  fprintf(stderr, "\n%4d%4d%c%c",
		  subgoal_seq[k],
		  k,
		  (k < SUBGOAL_MAX && is_resumed[k] ? '!' : ':'),
		  (k < SUBGOAL_MAX && subgoal_trace[k] ? '+' : '-' )),
#endif
	  print_goal(qt, parent->pred->func);
	}
	for (tr = trace_enqueued_goals;
	     tr != 0 && k < SUBGOAL_MAX;
	     tr = tr->next, k++) {
#ifdef DIST
          TRACE_FPRINTF4("\n%4d%4d%c%c",
		  subgoal_seq[k],
		  k,
		  (k < SUBGOAL_MAX && is_resumed[k] ? '#' : '*'),
		  (k < SUBGOAL_MAX && subgoal_trace[k] ? '+' : '-' ));
#else
	  fprintf(stderr, "\n%4d%4d%c%c",
		  subgoal_seq[k],
		  k,
		  (k < SUBGOAL_MAX && is_resumed[k] ? '#' : '*'),
		  (k < SUBGOAL_MAX && subgoal_trace[k] ? '+' : '-' )),
#endif
	  print_goal(tr->g, parent->pred->func);
#ifdef DIST
	  TRACE_FPRINTF1("@prio(%ld)", tr->prio);
#else
	  fprintf(stderr, "@prio(%ld)", tr->prio);
#endif
	}
      }
      if (Leashed(Reduce) || spying) {
	if (!reduce_port_command(subgoals, qp, get_mte(parent->pred)))
	  break;
      } else {
#ifdef DIST
        TRACE_FPRINTF("\n");
#else
	fprintf(stderr, "\n");
#endif
	break;
      }
    }
  }
#ifdef DIST
  TRACE_DETACHIO;
#endif
  {
    struct goalrec **qpp;
    for (qpp = &qp, k = 0;
	 *qpp != before;
	 qpp = &(*qpp)->next, k++) {
      if (trace_flag && subgoal_trace[k]) {
	*qpp = trace_goal(*qpp, subgoal_seq[k]);
      } else {
	(void) untrace_goal(*qpp);
      }
    }
  }
  for (tr = trace_enqueued_goals;
       tr != 0 && k < SUBGOAL_MAX;
       k++) {
    int trace_save = trace_flag;
    struct enqueue_trace_rec *next;
    if (trace_flag && subgoal_trace[k]) {
      tr->g = trace_goal(tr->g, subgoal_seq[k]);
    } else {
      (void) untrace_goal(tr->g);
    }
    trace_flag = 0;
    enqueue_goal(qp, tr->prio, tr->g, glbl);
    trace_flag = trace_save;
    next = tr->next;
    free(tr);
    tr = next;
  }
  trace_enqueued_goals = 0;
  trace_flag = 0;

  parent = 0;
  heapp = allocp;
  if (interrupt_off) heaplimit = real_heaplimit;
  else heaplimit = 0;
  return qp;
}

struct goalrec *trace_susp(qp, reasonp, spontaneous)
     struct goalrec *qp;
     q *reasonp;
     int spontaneous;
{
  unsigned int seq = ( spontaneous ? trace_seq++ : parent_seq );

  InitPort();
  if (Enabled(Susp) && (!leaping || spying)) {
#ifdef DIST
    TRACE_ATTACHIO;
#endif
    for (;;) {
#ifdef DIST
      TRACE_FPRINTF2("%d:%4d SUSP: ", my_node, seq);
#else
      fprintf(stderr, "%4d SUSP: ", seq);
#endif
      print_goal(qp, 0);
      if (Leashed(Susp) || spying) {
	if (!susp_port_command(qp, get_mte(qp->pred))) break;
      } else {
#ifdef DIST
	TRACE_FPRINTF("\n");
#else
	fprintf(stderr, "\n");
#endif
	break;
      }
    }
  }
#ifdef DIST
  TRACE_DETACHIO;
#endif
  if (trace_flag) {
    qp = trace_goal(qp, seq);
  }
  trace_flag = spontaneous;
  return qp;
}

trace_resumption(qp)
     struct goalrec *qp;
{
  /*
    This routine only registers the resumed goal in a table
    rather than actually tracing it.
    Real tracing will be done at the commmit port.
    */
  if (++n_resumed == max_different_prio_resume) {
    max_different_prio_resume *= 2;
    different_prio_resume = (struct goalrec **)
      realloc_check(different_prio_resume,
		    max_different_prio_resume*sizeof(struct goalrec *));
  }
  different_prio_resume[n_resumed-1] = qp;
}

trace_failure(qp)
     struct goalrec *qp;
{
  unsigned int seq;

  InitTrace();
  InitPort();
  seq = (qp==parent ? parent_seq : trace_seq++);
  if (Enabled(Fail)) {
#ifdef DIST
    TRACE_ATTACHIO;
#endif
    for (;;) {
#ifdef DIST
      TRACE_FPRINTF2("%d:%4d FAIL: ", my_node, seq);
#else
      fprintf(stderr, "%4d FAIL: ", seq);
#endif
      print_goal(qp, 0);
      if (Leashed(Fail) || spying) {
	if (!fail_port_command(qp, get_mte(qp->pred))) break;
      } else {
#ifdef DIST
	TRACE_FPRINTF("\n");
#else
	fprintf(stderr, "\n");
#endif
	break;
      }
    }
  }
#ifdef DIST
  TRACE_DETACHIO;
#endif
  trace_flag = 0;
}

trace_deadlock(qp)
     struct goalrec *qp;
{
  unsigned int seq;

  InitTrace();
  InitPort();
  if (!Traced(qp)) qp = trace_goal(qp, trace_seq++);
  seq = trace_seq_of(qp);
#ifdef DIST
  TRACE_ATTACHIO;
  TRACE_FPRINTF("!!! Perpetual Suspention Detected !!!\n");
#else
  fprintf(stderr, "!!! Perpetual Suspention Detected !!!\n");
#endif
  if (Enabled(Fail)) {
    for (;;) {
#ifdef DIST
      TRACE_FPRINTF2( "%d:%4d PSUS: ", my_node, seq);
#else
      fprintf(stderr, "%4d PSUS: ", seq);
#endif
#ifdef DIST
      print_goal(qp, 0);
#else
      fprint_goal(stderr, qp, 0);
#endif
      if (!fail_port_command(qp, get_mte(qp->pred))) break;
    }
  }
#ifdef DIST
  TRACE_DETACHIO;
#endif
}

/****************************************
  Tracer Command Interpreter
****************************************/

enum tracer_command {
  Continue, Leap,		/* Execution Control */
  Skip, QuasiSkip,
  Abort,
  ToggleTrace,
  Unify,			/* PseudoExecution */
  EnablePort, DisablePort, LeashPort, UnLeashPort,
  Trace, NoTrace, Spy, NoSpy, SetDefaultTrace, UnsetDefaultTrace,
  TraceQueuedGoal, NoTraceQueuedGoal, SubTerm,
  PrintDepth, PrintLength,	/* Print Out Control */
  PrintVerbose,
  ListMod, ListPred, ListSpied,	/* Listing */
  Debugging,			/* Status Query */
  DumpQueue,			/* Dump Ready Queue */
  Help, Unknown			/* Miscellaneous */
  };

static char
  command_line[256],
  *clp;

static tracer_error();
static print_help();

#define skip_blanks()  { while (isspace(*clp)) clp++; }

static enum tracer_command trace_parse_command()
{
  Const struct command_table_entry *cte;
  static char command_name[256];
  Const static struct command_table_entry {
    char *name;
    enum tracer_command command;
  } command_table[] = {
    /* Execution Control */
    { "", Continue },
    { "c", Continue }, { "continue", Continue },
    { "l", Leap }, { "leap", Leap },
    { "s", Skip }, { "skip", Skip },
    { "q", QuasiSkip }, { "quasiskip", QuasiSkip },
    { "a", Abort }, { "abort", Abort },
    /* Pseudo Execution */
    { "u", Unify }, { "unify", Unify },
    /* Port Control */
    { "E", EnablePort }, { "enable", EnablePort },
    { "D", DisablePort }, { "disable", DisablePort },
    { "L", LeashPort }, { "leash", LeashPort },
    { "U", UnLeashPort }, { "unleash", UnLeashPort },
    /* Trace Control */
    { "t", SetDefaultTrace }, { "defaulttrace", SetDefaultTrace },
    { "n", UnsetDefaultTrace }, { "defaultnotrace", UnsetDefaultTrace },
    { "+", Trace }, { "trace", Trace },
    { "-", NoTrace }, { "notrace", NoTrace },
    { "tq", TraceQueuedGoal }, { "tracequeued", TraceQueuedGoal },
    { "nq", NoTraceQueuedGoal }, { "notracequeued", NoTraceQueuedGoal },
    { "^", SubTerm },
    /* Spying */
    { "S", Spy }, { "spy", Spy },
    { "N", NoSpy }, { "nospy", NoSpy },
    /* Print Out Control */
    { "pd", PrintDepth }, { "depth", PrintDepth },
    { "pl", PrintLength }, { "length", PrintLength },
    { "pv", PrintVerbose }, { "verbose", PrintVerbose },
    /* Listing */
    { "lm", ListMod }, { "modules", ListMod },
    { "lp", ListPred }, { "predicates", ListPred },
    { "ls", ListSpied }, { "spied", ListSpied },
    /* Status Query */
    { "=", Debugging }, { "debugging", Debugging },
    /* Dump Ready Queue */
    { "Q", DumpQueue }, { "queue", DumpQueue },
    /* Miscellaneous */
    { "h", Help }, { "?", Help }, { "help", Help },
    { command_name, Unknown }
  };
  char *cnp = command_name;
#ifdef DIST
/*
  { char eofflag;
    SystemIsEOF(eofflag);
    if (eofflag) return Abort;
  }
*/
  SystemPrint("? ");
  SystemFflush();
  SystemRead(command_line);
#else
  if (feof(tracer_input)) return Abort;
  fprintf(stderr, "? ");
  fflush(stderr);
  fgets(command_line, 255, tracer_input);
#endif
  clp = command_line;

  skip_blanks();

  if (isdigit(*clp)) {
    return ToggleTrace;
  }
  if (isalpha(*clp)) {
    while (isalpha(*clp)) *cnp++ = *clp++;
  } else if (ispunct(*clp)) {
    while (ispunct(*clp)) *cnp++ = *clp++;
  } else {
    while (*clp != 0 && !isspace(*clp)) *cnp++ = *clp++;
  }
  *cnp = '\0';
  cte = command_table;
  while (strcmp(command_name, cte->name)) cte++;
  return cte->command;
}

static enum trace_port trace_parse_port()
{
  static char port_name[256];
  static struct port_table_entry {
    enum trace_port port;
    char *name;
  } port_table[] = {
    { Call, "c" }, { Call, "call" },
    { Susp, "s" }, { Susp, "susp" }, { Susp, "suspend" },
    { Reduce, "r" }, { Reduce, "redu" }, { Reduce, "reduce" },
    { Fail, "f" }, { Fail, "fail"},
    { AllPorts, "a" }, { AllPorts, "all" },
    { UnknownPort, port_name }
  };
  struct port_table_entry *pte;
  char *pnp = port_name;
  skip_blanks();
  if (*clp == '\0') return NoMorePort;
  while (!isspace(*clp)) *pnp++ = tolower(*clp++);
  *pnp = '\0';
  pte = port_table;
  while (strcmp(port_name, pte->name)) pte++;
  return pte->port;
}

static long trace_parse_int(addr)
     long *addr;
/*
  Returns:
  0: nothing read
  1: integer value read
  -1: error found while parsing
*/
{
  long n;
  if (*clp == '\0') return 0;
  if (!isdigit(*clp)) return -1;
  n = 0;
  do {
    n = 10*n + *clp++ - '0';
  } while (isdigit(*clp));
  *addr = n;
  return 1;
}

static trace_parse_name(np)
     char *np;
{
  if (*clp == '\0') return 0;
  while (isalpha(*clp) || isdigit(*clp) || *clp == '_') {
    *np++ = *clp++;
  }
  *np = '\0';
  return 1;
}

static trace_parse_predicate_name(mod, pred, arity, curmod)
     struct mod_table_entry **mod;
     struct pred_table_entry **pred;
     int *arity;
     struct mod_table_entry *curmod;
/*
  Returns
  0: nothing read
  1: only module name read ("Module")
  2: module and predicate name read ("Module:Pred")
  3: module and predicate name with arity read ("Module:Pred/Arity")
  -1: error found while parsing
*/
{
  char name[256];
  int k;
  struct mod_table_entry *mte;
  struct pred_table_entry *pte;
  *mod = 0;
  *pred = 0;
  skip_blanks();
  if (!trace_parse_name(name)) {
    return 0;
  }
  if (*clp == ':') {
    for (k = 0, mte = mod_table;
	 k < n_mod;
	 k++, mte++) {
      if (!strcmp((char *)mte->name, (char *)name)) {
	*mod = mte;
	goto mod_found;
      }      
    }
    tracer_error("Unknown module: %s", name);
    return -1;
  mod_found:
    clp++;
    if (isspace(*clp)) return 1;
    if (!trace_parse_name(name)) {
      tracer_error("Predicate name expected after colon");
      return -1;
    }
  } else {
    *mod = mte = curmod;
  }
  for (k = 0, pte = pred_table;
       k < n_pred;
       k++, pte++) {
    if (pte->pred->func == mte->func &&
	!strcmp((char *)pte->name, (char *)name)) {
      *pred = pte;
      goto pred_found;
    }
  }
  tracer_error("Unknown predicate: %s:%s", mte->name, name);
  return -1;
 pred_found:
  if (isspace(*clp)) return 2;
  if (*clp++ != '/') {
    tracer_error("Arity should be specified after slash");
    return -1;
  }
  if (trace_parse_int(arity) != 1) {
    tracer_error("Decimal arity expected after slash");
    return -1;
  }
  for (;
       k < n_pred;
       k++, pte++) {
    if (!strcmp((char *)pte->name, (char *)name) &&
	pte->pred->arity == *arity) {
      *pred = pte;
      goto arity_found;
    }
  }
  tracer_error("Unknown predicate: %s:%s/%d", mte->name, name, *arity);
  return -1;
 arity_found:
  return 3;
}

static q subterm_of_goal(g)
     struct goalrec *g;
{
  Const struct predicate *pred;
  int k;
  q term;

  pred = (Traced(g)
	  ? (struct predicate *)consp(g->args[g->pred->arity-2])
	  : g->pred);
  if (subterm_stack[0] > pred->arity) return 0;
  term = g->args[subterm_stack[0]-1];
  for (k=1; k<subterm_sp; k++) {
    long ind = subterm_stack[k];
  deref:
    if (isref(term)) {
      if (derefone(term) != term &&
	  (!isref(derefone(term)) || derefone(derefone(term)) != term)) {
	term = derefone(term);
	goto deref;
      } else {
	return 0;
      }
    } else if (isfunctor(term)) {
      if (isgobj(term)) return 0;
      if (ind > arities[symval(functor_of(term))]) return 0;
      term = arg(term, ind+1);
    } else if (iscons(term)) {
      if (ind == 1) {
	term = car_of(term);
      } else if (ind == 2) {
	term = cdr_of(term);
      } else return 0;
    } else return 0;
  }
  return term;
}

#define COMMON_COMMANDS\
 Abort: \
 case EnablePort: case DisablePort: \
 case LeashPort: case UnLeashPort: \
 case Spy: case NoSpy: \
 case SetDefaultTrace: case UnsetDefaultTrace: \
 case PrintDepth: case PrintLength: case PrintVerbose: \
 case SubTerm: \
 case ListMod: case ListPred: case ListSpied: \
 case Debugging: case Unknown

static common_port_command(command, pred, curmod, g)
     enum tracer_command command;
     struct predicate *pred;
     struct mod_table_entry *curmod;
     struct goalrec *g;
{
  enum trace_port port;
  Const struct mod_table_entry *mte;
  struct pred_table_entry *pte;
  int arity;
  int is_spy, set_flag, only_spied;

  only_spied = 0;
  switch (command) {
  case Abort:
    fatal("Execution aborted");
  case EnablePort:
    if ((port = trace_parse_port()) == NoMorePort) {
      print_port_names();
      break;
    }
    do {
      if (port == UnknownPort) {
	print_port_names();
	break;
      } else if (port == AllPorts) {
	enabled = -1;
      } else {
	enabled |= (1 << (int)port);
      }
    } while ((port = trace_parse_port()) != NoMorePort);
    break;
  case DisablePort:
    if ((port = trace_parse_port()) == NoMorePort) {
      print_port_names();
      break;
    }
    do {
      if (port == UnknownPort) {
	print_port_names();
	break;
      } else if (port == AllPorts) {
	enabled = 0;
      } else {
	enabled ^= (1 << (int)port);
      }
    } while ((port = trace_parse_port()) != NoMorePort);
    break;
  case LeashPort:
    if ((port = trace_parse_port()) == NoMorePort) {
      print_port_names();
      break;
    }
    do {
      if (port == UnknownPort) {
	print_port_names();
	break;
      } else if (port == AllPorts) {
	leashed = -1;
      } else {
	leashed |= (1 << (int)port);
      }
    } while ((port = trace_parse_port()) != NoMorePort);
    break;
  case UnLeashPort:
    if ((port = trace_parse_port()) == NoMorePort) {
      print_port_names();
      break;
    }
    do {
      if (port == UnknownPort) {
	print_port_names();
	break;
      } else if (port == AllPorts) {
	leashed= 0;
      } else {
	leashed ^= (1 << (int)port);
      }
    } while ((port = trace_parse_port()) != NoMorePort);
    break;
#define SpyOrTrace(x) (is_spy ? (x)->spied : (x)->default_trace)    
#define SetSpyOrTrace(x, y) \
    { if (is_spy) (x)->spied = (y); else (x)->default_trace = (y); }
  case SetDefaultTrace:
    is_spy = 0;
    set_flag = 1;
    goto set_reset;
  case UnsetDefaultTrace:
    is_spy = 0;
    set_flag = 0;
    goto set_reset;
  case Spy:
    is_spy = 1;
    set_flag = 1;
    goto set_reset;
  case NoSpy:
    is_spy = 1;
    set_flag = 0;
  set_reset:
    {
      Const static char *set_reset[] = { "reset", "set" };
      Const static char *spy_trace[] = { "Default trace", "Spy point" };
      switch (trace_parse_predicate_name(&mte, &pte, &arity, curmod)) {
      case -1:
	break;
      case 1:
	for (pte = pred_table;
	     pte < pred_table + n_pred;
	     pte++) {
	  if (pte->pred->func == mte->func) {
	    SetSpyOrTrace(pte, set_flag);
	  }
	}
#ifdef DIST
	TRACE_FPRINTF3("\t%s %s on all predicates in module %s\n",
		spy_trace[is_spy], set_reset[set_flag], mte->name);
#else
	fprintf(stderr, "\t%s %s on all predicates in module %s\n",
		spy_trace[is_spy], set_reset[set_flag], mte->name);
#endif
	break;
      case 2:
	do {
	  SetSpyOrTrace(pte, set_flag);
#ifdef DIST
	  TRACE_FPRINTF5("\t%s %s on predicate %s:%s/%d\n",
		  spy_trace[is_spy], set_reset[set_flag],
		  mte->name, pte->name, pte->pred->arity);
#else
	  fprintf(stderr, "\t%s %s on predicate %s:%s/%d\n",
		  spy_trace[is_spy], set_reset[set_flag],
		  mte->name, pte->name, pte->pred->arity);
#endif
	  pte++;
	} while (pte < pred_table + n_pred &&
		 !strcmp((char *)(pte-1)->name, (char *)pte->name));
	break;
      case 0:
	pte = get_pte(pred);
	mte = pte->mte;
	arity = pred->arity;
	/* fall through */
      case 3:
	SetSpyOrTrace(pte, set_flag);
#ifdef DIST
	TRACE_FPRINTF5("\t%s %s on predicate %s:%s/%d\n",
		spy_trace[is_spy], set_reset[set_flag],
		mte->name, pte->name, pte->pred->arity);
#else
	fprintf(stderr, "\t%s %s on predicate %s:%s/%d\n",
		spy_trace[is_spy], set_reset[set_flag],
		mte->name, pte->name, pte->pred->arity);
#endif
	break;
      }
      break;
    }
  case PrintDepth:
    skip_blanks();
    if (trace_parse_int(&trace_print_depth) != 1) {
#ifdef DIST
      TRACE_FPRINTF1("\tCurrent print depth = %ld\n", trace_print_depth);
#else
      fprintf(stderr, "\tCurrent print depth = %ld\n", trace_print_depth);
#endif
    }
    break;
  case PrintLength:
    skip_blanks();
    if (trace_parse_int(&trace_print_length) != 1) {
#ifdef DIST
      TRACE_FPRINTF1("\tCurrent print length = %ld\n", trace_print_length);
#else
      fprintf(stderr, "\tCurrent print length = %ld\n", trace_print_length);
#endif
    }
    break;
  case PrintVerbose:
    verbose_print = !verbose_print;
#ifdef DIST
      TRACE_FPRINTF1("\tVerbose printing switched %s\n",
	    (verbose_print ? "ON" : "OFF" ));
#else
    fprintf(stderr, "\tVerbose printing switched %s\n",
	    (verbose_print ? "ON" : "OFF" ));
#endif
    break;
  case SubTerm:
    skip_blanks();
    {
      long subterm;
      switch (trace_parse_int(&subterm)) {
      case 1:
	if (subterm_sp == SUBTERM_MAX) {
#ifdef DIST
	  TRACE_FPRINTF("\tGoing too deep in subterm inspection\n");
#else
	  fprintf(stderr, "\tGoing too deep in subterm inspection\n");
#endif
	} else if (subterm == 0) {
	  if (subterm_sp > 0) subterm_sp--;
	} else {
	  subterm_stack[subterm_sp++] = subterm;
	  if (subterm_of_goal(g) == 0) {
#ifdef DIST
	    TRACE_FPRINTF1("\tNo element #%ld in the current subterm\n",
			   subterm);
#else
	    fprintf(stderr, "\tNo element #%ld in the current subterm\n",
		    subterm);
#endif
	    subterm_sp--;
	  }
	}
	break;
      case -1:
	subterm_sp = 0;
	break;
      case 0:
	if (subterm_sp != 0) subterm_sp--;
	break;
      }
    }
    break;
  case ListMod:
    print_modules();
    break;
  case ListSpied:
    only_spied = 1;
  case ListPred:
    skip_blanks();
    switch (trace_parse_predicate_name(&mte, &pte, &arity, curmod)) {
    case 0: print_predicates(0, 0, -1, only_spied); break;
    case 1: print_predicates(mte, 0, -1, only_spied); break;
    case 2: print_predicates(mte, pte, -1, only_spied); break;
    case 3: print_predicates(mte, pte, arity, only_spied); break;
    }
    break;
  case Debugging:
    print_debug_status();
    break;
  case Unknown:
    tracer_error("Unknown command");
#ifdef DIST
    TRACE_FPRINTF("\tTry ? for command list\n");
#else
    fprintf(stderr, "\tTry ? for command list\n");
#endif
    break;
  }
}

#define CONTROL_COMMANDS\
 Continue: case Leap: case Skip

static control_command(command)
     enum tracer_command command;
{
  switch(command) {
  case Continue:
    leaping = 0;
    break;
  case Leap:
    leaping = 1;
#ifdef DIST
    TRACE_DETACHIO;
#endif
    break;
  case Skip:
    trace_flag = 0;
#ifdef DIST
    TRACE_DETACHIO;
#endif
    break;
  }
}

static Const char *common_help[] = {
 "E: enable port;   D: disable port;  L: leash port;    U: unleash port;",
 "S <pred>: spy;    N <pred>: nospy;  t <pred>: trace;  n <pred>: notrace;",
 "pd: print depth;  pl: print length; pv: toggle verbose print;",
 "^ <n>: subterm;   ^ 0: superterm;   ^: no subterm;    Q: goal queue;",
 "=: debug status;  ls: list spied;   lm: list modules; lp: list predicates;",
 "a: abort execution",
 0 };

static call_port_command(qp, curmod)
     struct goalrec *qp;
     struct mod_table_entry *curmod;
{
  int again = 0;
  int err = 0;
  enum tracer_command command;
  switch (command = trace_parse_command()) {
  case COMMON_COMMANDS:
    common_port_command(command, parent->pred, curmod, parent);
    again = 1;
    break;
  case CONTROL_COMMANDS:
    control_command(command);
    break;
  case DumpQueue:
    (void)dump_queue(qp, 0);
    again = 1;
    break;
  default:
    err = 1;
  }    
  if (err) {
    Const static char *call_help[] = {
      "\t*** Commands available at CALL ports ***",
      "<cr>: continue;   c: continue;      s: skip;          l: leap;",
      0
    };
    print_help(call_help);
    print_help(common_help);
    again = 1;
  }
  return again;
}

static reduce_port_command(subgoals, qp, curmod)
     unsigned long subgoals;
     struct goalrec *qp;
     struct mod_table_entry *curmod;
{
  int k, flag;
  enum tracer_command command;
  int again = 0;
  int err = 0;
  switch (command = trace_parse_command()) {
  case ToggleTrace:
    flag = -1; goto trace_notrace;
  case Trace:
    flag = 1; goto trace_notrace;
  case NoTrace:
    flag = 0;
  trace_notrace:
    if (subgoals == 0) {
      tracer_error("No subgoals to trace");
    } else if (subgoals >= SUBGOAL_MAX) {
      tracer_error("Too many subgoals to control");
    } else {
      skip_blanks();
      if (*clp == '\0') {
	for (k = 0; k < subgoals; k++) {
	  subgoal_trace[k] = flag;
	}
      } else {
	long traced;
	while (1) {
	  switch (trace_parse_int(&traced)) {
	  case 0:
	    goto exit_loop;
	  case 1:
	    if (0 <= traced && traced < subgoals) {
	      subgoal_trace[traced] =
		( flag >= 0 ? flag : !subgoal_trace[traced] );
	    } else {
	      tracer_error("Subgoal %ld doesn't exist", traced);
	    }
	    skip_blanks();
	    break;
	  default:
	    tracer_error("Subgoal number expected");
	    goto exit_loop;
	  }
	}
      }
    }
  exit_loop:
    again = 1;
    break;
  case CONTROL_COMMANDS:
    control_command(command);
    break;
  case COMMON_COMMANDS:
    common_port_command(command, parent->pred, curmod, parent);
    again = 1;
    break;
  case DumpQueue:
    (void)dump_queue(qp, 0);
    again = 1;
    break;
  default:
    err = 1;
    break;
  }    
  if (err) {
    Const static char *reduce_help[] = {
      "\t*** Commands available at REDUCE ports ***",
      "<cr>: continue;   c: continue;      s: skip;          l: leap;",
      "+ <n>: trace;     - <n>: no trace;  <n>: toggle trace",
      0
    };
    print_help(reduce_help);
    print_help(common_help);
    again = 1;
  }
  return again;
}

static susp_port_command(qp, curmod)
     struct goalrec *qp;
     struct mod_table_entry *curmod;
{
  enum tracer_command command;
  int again = 0;
  int err = 0;
  switch (command = trace_parse_command()) {
  case CONTROL_COMMANDS:
    control_command(command);
    break;
  case COMMON_COMMANDS:
    common_port_command(command, qp->pred, curmod, qp);
    again = 1;
    break;
  default:
    err = 1;
    break;
  }    
  if (err) {
    Const static char *susp_help[] = {
      "\t*** Commands available at SUSPENSION ports ***",
      "<cr>: continue;   c: continue;      s: skip;          l: leap;",
      0
    };
    print_help(susp_help);
    print_help(common_help);
    again = 1;
  }
  return again;
}

static fail_port_command(qp, curmod)
     struct goalrec *qp;
     struct mod_table_entry *curmod;
{
  enum tracer_command command;
  int again = 0;
  int err = 0;
  switch (command = trace_parse_command()) {
  case COMMON_COMMANDS:
    common_port_command(command, qp->pred, curmod, qp);
    again = 1;
    break;
  case DumpQueue:
    (void)dump_queue(qp, 0);
    again = 1;
    break;
  default:
    err = 1;
    break;
  }    
  if (err) {
    Const static char *fail_help[] = {
      "\t*** Commands available at FAIL ports ***",
      0
    };
    print_help(fail_help);
    print_help(common_help);
    again = 1;
  }
  return again;
}

static print_port_status()
{
  static char plusminus[] = { '-', '+' };
#ifdef DIST
  TRACE_FPRINTF("\t   port: Call Susp Redu Fail\n");
  TRACE_FPRINTF4("\tenabled:  %c    %c    %c    %c\n",
		 plusminus[Enabled(Call)],
		 plusminus[Enabled(Susp)],
		 plusminus[Enabled(Reduce)],
		 plusminus[Enabled(Fail)]);
  TRACE_FPRINTF4("\tleashed:  %c    %c    %c    %c\n",
		 plusminus[Leashed(Call)],
		 plusminus[Leashed(Susp)],
		 plusminus[Leashed(Reduce)],
		 plusminus[Leashed(Fail)]);
#else
  fprintf(stderr, "\t   port: Call Susp Redu Fail\n");
  fprintf(stderr, "\tenabled:  %c    %c    %c    %c\n",
	  plusminus[Enabled(Call)],
	  plusminus[Enabled(Susp)],
	  plusminus[Enabled(Reduce)],
	  plusminus[Enabled(Fail)]);
  fprintf(stderr, "\tleashed:  %c    %c    %c    %c\n",
	  plusminus[Leashed(Call)],
	  plusminus[Leashed(Susp)],
	  plusminus[Leashed(Reduce)],
	  plusminus[Leashed(Fail)]);
#endif
}

static print_debug_status()
{
  print_port_status();
#ifdef DIST
  TRACE_FPRINTF3("\tprint %s; depth = %u; length = %u\n",
		 (verbose_print ? "verbose" : "terse"),
		 trace_print_depth, trace_print_length);
#else
  fprintf(stderr, "\tprint %s; depth = %u; length = %u\n",
	  (verbose_print ? "verbose" : "terse"),
	  trace_print_depth, trace_print_length);
#endif
}

static print_port_names()
{
  static Const char *port_help[] = {
    "Available ports are \"call\", \"susp\", \"redu\" and \"fail\".",
    "You can also specify \"all\".",
    0 };
  print_help(port_help);
}

/****************************************
  Printing Out
****************************************/

static tracer_error(s, a0, a1, a2, a3, a4, a5, a6, a7, a8)
     char *s;
     long a0, a1, a2, a3, a4, a5, a6, a7, a8;
{
#ifdef DIST
  TRACE_FPRINTF("\t!!! ");
  sprintf(iobuf,s, a0, a1, a2, a3, a4, a5, a6, a7, a8);
  SystemPrint(iobuf);
  TRACE_FPRINTF(" !!!\n");
#else
  fprintf(stderr, "\t!!! ");
  fprintf(stderr, s, a0, a1, a2, a3, a4, a5, a6, a7, a8);
  fprintf(stderr, " !!!\n");
#endif
}

static print_help(messages)
     Const char **messages;
{
  while (*messages) {
#ifdef DIST
    TRACE_FPRINTF1("    %s\n", *messages++);
#else
    fprintf(stderr, "    %s\n", *messages++);
#endif
  }
}

static trace_print(stream, x)
     FILE *stream;
     q x;
{
  fprint_partially(stream, x, trace_print_depth, trace_print_length);
}

print_goal(g, mod)
     struct goalrec *g;
     module mod;
{
#ifdef DIST
  HAS_OPENED_TMPFILE;
  fprint_goal(tracetmp, g, mod);
  TRACE_SEND_TERM;
#else
  fprint_goal(stderr, g, mod);
#endif
}

fprint_goal(stream, g, mod)
     FILE *stream;
     struct goalrec *g;
     module mod;
{
  extern module wait_prio_routine();
#ifdef DIST
  extern module wait_penum_routine();
#endif
  if (subterm_sp == 0) {
    Const struct predicate *pred;
    struct pred_table_entry *pte;
    int traced;

  retry:
    traced = Traced(g);
    pred = (traced
	    ? (struct predicate *)consp(g->args[g->pred->arity-2])
	    : g->pred);
    if (pred->func == wait_prio_routine) {
      declare_globals;
      struct goalrec *ng;
      int narity = g->pred->arity - 3, k;
      heapalloc(ng, narity+2, (struct goalrec *));
      ng->pred = (struct predicate *)(consp(g->args[narity]));
      for (k=0; k!=narity; k++) {
	ng->args[k] = g->args[k];
      }
      g = ng;
      goto retry;
    } 
#ifdef DIST
    else if (pred->func == wait_penum_routine) {
      declare_globals;
      struct goalrec *ng;
      int narity = g->pred->arity - 2, k;
      heapalloc(ng, narity+2, (struct goalrec *));
      ng->pred = (struct predicate *)(consp(g->args[narity]));
      for (k=0; k!=narity; k++) {
	ng->args[k] = g->args[k];
      }
      g = ng;
      goto retry;
    }
#endif 
    pte = get_pte(pred);
    if ((module)pred->func != mod) {
      fprintf(stream, "%s:", (pte ? (char *)pte->mte->name : "???"));
    }
    fprintf(stream, "%s", (pte ? (char *)pte->name : "???"));
    if (pred->arity != 0) {
      unsigned int k;
      fprintf(stream, "(");
      trace_print(stream, g->args[0]);
      for (k = 1;
	   k < pred->arity;
	   k++) {
	fprintf(stream, ",");
	trace_print(stream, g->args[k]);
      }
      fprintf(stream, ")");
    }
  } else {
    q term = subterm_of_goal(g);
    int k;
    for (k=0; k<subterm_sp; k++) {
      fprintf(stream, "^%ld", subterm_stack[k]);
    }
    fprintf(stream, " ");
    trace_print(stream, term);
  }
}

static print_modules()
{
  int k;

#ifdef DIST
  TRACE_FPRINTF("\t*** Module List ***\n");
#else
  fprintf(stderr, "\t*** Module List ***\n");
#endif
  for (k = 0; k < n_mod; k++) {
    struct mod_table_entry *mte = &mod_table[k];
#ifdef DIST
    TRACE_FPRINTF2("\t%8X %s\n",
		   (unsigned long)mte->func,
		   mte->name);
#else
    fprintf(stderr, "\t%8X %s\n",
	    (unsigned long)mte->func,
	    mte->name);
#endif
  }
#ifdef DIST
  TRACE_FPRINTF("\t*******************\n");
#else
  fprintf(stderr, "\t*******************\n");
#endif
}

static print_predicates(mte, pte, arity, spied_only)
     struct mod_table_entry *mte;
     struct pred_table_entry *pte;
     int arity;
     int spied_only;
{
  int k;
  int none = 1;
#ifdef DIST
  TRACE_FPRINTF(
	  (spied_only ? "\t*** Spied Predicates ***\n"
	   : "\t**** Predicate List ****\n"));
#else
  fprintf(stderr, 
	  (spied_only ? "\t*** Spied Predicates ***\n"
	   : "\t**** Predicate List ****\n"));
#endif
  for (k = 0; k < n_pred; k++) {
    struct pred_table_entry *x = &pred_table[k];
    if ((!spied_only || x->spied) &&
	(!mte || x->mte == mte) &&
	(!pte || !strcmp((char *)x->name, (char *)pte->name)) &&
	(arity < 0 || x->pred->arity == arity)) {
      none = 0;
#ifdef DIST
      TRACE_FPRINTF6("\t%8X %c%c%s:%s/%d\n",
		     (unsigned long)x->pred,
		     (x->spied && !spied_only ? '*' : ' '),
		     (x->default_trace ? '+' : '-'),
		     x->mte->name,
		     x->name, x->pred->arity);
#else
      fprintf(stderr, "\t%8X %c%c%s:%s/%d\n",
	      (unsigned long)x->pred,
	      (x->spied && !spied_only ? '*' : ' '),
	      (x->default_trace ? '+' : '-'),
	      x->mte->name,
	      x->name, x->pred->arity);
#endif
    }
  }
#ifdef DIST
  TRACE_FPRINTF((none ? "\t********* NONE *********\n"
		 : "\t************************\n"));
#else
  fprintf(stderr,
	  (none ? "\t********* NONE *********\n"
	   : "\t************************\n"));
#endif
}

long dump_one_queue(prio, qp, dump_seq)
     long prio;
     struct goalrec *qp;
     long dump_seq;
{
  Const extern struct predicate queue_empty_pred;
  Const extern struct predicate topsucceed_pred;
  if (qp->pred != &queue_empty_pred &&
      qp->pred != &topsucceed_pred) {
#ifdef DIST
    TRACE_FPRINTF1("    Priority = %ld\n", prio);
#else
    fprintf(stderr, "    Priority = %ld\n", prio);
#endif
    do {
      if (Traced(qp)) {
#ifdef DIST
	TRACE_FPRINTF1("%6d", trace_seq_of(qp));
#else
	fprintf(stderr, "%6d*", trace_seq_of(qp));
#endif
      } else {
#ifdef DIST
	TRACE_FPRINTF1("%6d", dump_seq++);
#else
	fprintf(stderr, "%6d ", dump_seq++);
#endif
      }
#ifdef DIST
      HAS_OPENED_TMPFILE;
      TRACE_FPRINTF("\t");
      fprint_goal(tracetmp, qp, 0);
      TRACE_SEND_TERM;
      TRACE_FPRINTF("\n");
#else
      fprintf(stderr, "\t");
      fprint_goal(stderr, qp, 0);
      fprintf(stderr, "\n");
#endif
      qp = qp->next;
      if (qp==0) {
#ifdef DIST
	TRACE_FPRINTF(
		"!!! The rest of the queue of this priority unknown !!!\n");
#else
	fprintf(stderr,
		"!!! The rest of the queue of this priority unknown !!!\n");
#endif
	break;
      }
    } while (qp->pred != &queue_empty_pred &&
	     qp->pred != &topsucceed_pred);
  }
  return dump_seq;
}

long dump_queue(qp, dump_seq)
     struct goalrec *qp;
     long dump_seq;
{
  declare_globals;
  struct prioqrec *pq = prioq.next;
  dump_seq = dump_one_queue(current_prio, qp, dump_seq);
  while (pq->prio >= 0) {
    dump_seq = dump_one_queue(pq->prio, pq->q, dump_seq);
    pq = pq->next;
  }
}

void
fprint_pred(fp, pred)
     FILE *fp;
     struct predicate *pred;
{
  static int name_table_init = 0;
  if(!name_table_init) {
    make_name_tables();
    name_table_init = 1;
  }
  {
    struct pred_table_entry *pte = get_pte(pred);
    fprintf(fp, "%s:%s/%d",(pte ? (char *)pte->mte->name : "???"),
	    (pte ? (char*)pte->name : "???"), pred->pred);
  }
}
