#include <klic/distio.h>

static int has_attached = 0;

static int bufid;

static FILE *tracetmp = 0;
static char *tracetmpname = (char *) NULL;

Extern int iotid;
Extern int shoentid;

/*  iotid & shoentid exist in main.c */

#define  TRACE_ATTACHIO \
  if (!has_attached) { \
     AttachIO; \
     has_attached = 1; \
     }

#define  TRACE_DETACHIO \
  if (has_attached) { \
     DetachIO; \
     has_attached = 0; \
     }

#define TRACE_FPRINTF(Format) \
   sprintf(iobuf,Format); \
   SystemPrint(iobuf);
#define TRACE_FPRINTF1(Format,Arg) \
   sprintf(iobuf,Format,Arg); \
   SystemPrint(iobuf);
#define TRACE_FPRINTF2(Format,Arg1,Arg2) \
   sprintf(iobuf,Format,Arg1,Arg2); \
   SystemPrint(iobuf);
#define TRACE_FPRINTF3(Format,Arg1,Arg2,Arg3) \
   sprintf(iobuf,Format,Arg1,Arg2,Arg3); \
   SystemPrint(iobuf);
#define TRACE_FPRINTF4(Format,Arg1,Arg2,Arg3,Arg4) \
   sprintf(iobuf,Format,Arg1,Arg2,Arg3,Arg4); \
   SystemPrint(iobuf);
#define TRACE_FPRINTF5(Format,Arg1,Arg2,Arg3,Arg4,Arg5) \
   sprintf(iobuf,Format,Arg1,Arg2,Arg3,Arg4,Arg5); \
   SystemPrint(iobuf);
#define TRACE_FPRINTF6(Format,Arg1,Arg2,Arg3,Arg4,Arg5,Arg6) \
   sprintf(iobuf,Format,Arg1,Arg2,Arg3,Arg4,Arg5,Arg6); \
   SystemPrint(iobuf);

#define HAS_OPENED_TMPFILE \
        if (!tracetmp) { \
	  tracetmpname = tmpnam((char *)NULL); \
	  tracetmp = fopen(tracetmpname,"w"); \
	  }

#define TRACE_SEND_TERM \
  freopen(tracetmpname,"r",tracetmp); \
  { long i; \
   do { \
     for (i = 0; i < 1023; i++) { \
      if (EOF == (iobuf[i] = fgetc(tracetmp))) break; \
     } \
     iobuf[i] = '\0'; \
     SystemPrint(iobuf); \
     } while (i == 1023); \
  } \
  fclose(tracetmp); \
  unlink(tracetmpname); \
  tracetmp=0;

