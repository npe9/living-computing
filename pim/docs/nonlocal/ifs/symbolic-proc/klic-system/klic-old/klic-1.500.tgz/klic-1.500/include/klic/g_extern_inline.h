extern void GD_suspend();
extern void GD_make_argblock();
extern void GD_make_var();
extern void GD_make_goal_of_new();
extern void GD_make_goal_of_root();
extern void GD_make_goal_of_mehtod();
