#include <klic/basic.h>
#include <klic/struct.h>
#include <klic/primitives.h>
#include <klic/unify.h>
#include <klic/timing.h>
#include <klic/index.h>

#include <stdio.h>
#include <setjmp.h>
#include <malloc.h>

#include <klic/interpe.h>
#include <klic/traceio.h>
#include <klic/distio.h>

extern char *malloc(), *realloc();

struct exp_entry *pop_exp_table_entry()
{
  struct exp_entry *poped_exp_entry;
  int i;

  if(top_of_exp_freelist == (struct exp_entry *)END_EXP_FREELIST){
    /*** for Debug ***/
    for(i=0; i<current_exp_size-1; i++){
      if(exp_table[i].wec == 0){
	sprintf(iobuf,"Export table reclaim error in entry %d\n",i);
	EPrint(iobuf);
      }
    }
    /*** for Debug ***/

    {
      int i;
      char *exp_alloc;

      exp_alloc = realloc((char *)exp_table, 
	  (current_exp_size+EXP_TABLE_INC_SIZE)*sizeof(struct exp_entry));
      if(exp_alloc == NULL){
	fatal("realloc failed in initiate_exp_table");
      }
      
      exp_table = (struct exp_entry*)exp_alloc;

      initiate_allocated_exp_table();
    }
/*
    sprintf(iobuf,"Export table expanded\n");
    EPrint(iobuf);
*/
  }

  poped_exp_entry = top_of_exp_freelist;
  top_of_exp_freelist = top_of_exp_freelist->next;

  if(poped_exp_entry->data != (q)UNUSED_EXPREC){
    sprintf(iobuf,"export_entry doubly used\n");
    EPrint(iobuf);
    ERROR_STOP;
    fatal("export_entry doubly used");
  }
  return(poped_exp_entry);
}

void push_exp_table_entry(push_exp_entry)
     struct exp_entry *push_exp_entry;
{
  push_exp_entry->data = (q)UNUSED_EXPREC;
  push_exp_entry->next = top_of_exp_freelist;
  top_of_exp_freelist = push_exp_entry;
}

long regist_exptbl(data)
     q data;
{
  struct exp_entry *exp_table_entry;

  exp_table_entry = pop_exp_table_entry();
  active_exp_entry++;

  regist_exptbl_wec = (long)EXPORT_UNIT_WEC;
  exp_table_entry->wec = (long)EXPORT_UNIT_WEC;

  exp_table_entry->data = data;
  return(exp_table_entry->index);
}

q search_exptbl(index, wec)
     long index;
     long wec;
{
  q data;

  data = exp_table[index].data;
  if((long)data == UNUSED_EXPREC){
    sprintf(iobuf,"illegal exp record %d\n", index);
    EPrint(iobuf);
    ERROR_STOP;
  }

  exp_table[index].wec = exp_table[index].wec - wec;
  if (exp_table[index].wec ==0){
    push_exp_table_entry(&exp_table[index]);
    active_exp_entry--;

  }
  return(data);
}


void check_exp_table_data(data)
     q data;
{
 TOP:
  switch(ptagof(data)){
  case ATOMIC:
    return;
  case CONS:
    check_exp_table_data(car_of(data));
    check_exp_table_data(cdr_of(data));    
    return;
  case FUNCTOR:
    fatal("not appear yet\n");
    return;
  case VARREF:
    deref_and_switch(data, VAR, TOP, TOP, TOP);
  VAR:
    return;
  default:
    fatal("invalid data\n");    
  }
}
void check_exp_table()
{
  int i;
  for(i=0;i<current_exp_size;i++){
    if(exp_table[i].data != (q)UNUSED_EXPREC){
      check_exp_table_data(exp_table[i].data);
    }
  }
}

void initiate_outbuf()
{
  char *output_buf;
  output_buf = malloc(current_outbuf_size*sizeof(int));
  if(output_buf == NULL){
    fatal("malloc failed in initiate_output_buffer");
  }
  network_outbuf = (long *)output_buf;

}

void initiate_inbuf()
{
  char *input_buf;
  input_buf = malloc(current_inbuf_size*sizeof(int));
  if(input_buf == NULL){
    fatal("malloc failed in initiate_input_buffer");
  }
  inbuf = (long *)input_buf;

}

void expand_outbuf()
{
  char *new_outbuf;

  new_outbuf = realloc((char *)network_outbuf, 
		       2*current_outbuf_size*sizeof(int));
  if(new_outbuf == NULL){
    fatal("realloc failed in expandeing outbuf");
  }

  network_outbuf = (long *)new_outbuf;
  current_outbuf_size = current_outbuf_size *2;
  
  sprintf(iobuf,"PE %d outbuf expanded to %d\n", my_node, current_outbuf_size);
  EPrint(iobuf);

}

void expand_inbuf(bufsize)
     int bufsize;
{
  char *new_inbuf;

  new_inbuf = realloc((char *)inbuf, bufsize);
  if(new_inbuf == NULL){
    fatal("realloc failed in expandeing inbuf");
  }

  inbuf = (long *)new_inbuf;
  current_inbuf_size = bufsize/sizeof(int);
  
  sprintf(iobuf,"PE %d inbuf expanded to %d\n", my_node, current_inbuf_size);
  EPrint(iobuf);

}
