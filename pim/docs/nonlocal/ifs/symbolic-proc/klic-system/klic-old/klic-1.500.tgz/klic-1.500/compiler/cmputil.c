/* Compiled by KLIC compiler version 1.500 (Fri Oct 21 12:19:27 JST 1994) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_klic__compiler__utility();
Const struct predicate predicate_klic__compiler__utility_xextend__name_3 =
   { module_klic__compiler__utility, 0, 3 };
Const struct predicate predicate_klic__compiler__utility_xextend_3 =
   { module_klic__compiler__utility, 1, 3 };
Const struct predicate predicate_klic__compiler__utility_xextend_4 =
   { module_klic__compiler__utility, 2, 4 };
Const struct predicate predicate_klic__compiler__utility_xcompress_2 =
   { module_klic__compiler__utility, 3, 2 };
Const struct predicate predicate_klic__compiler__utility_xcompress_6 =
   { module_klic__compiler__utility, 4, 6 };
Const struct predicate predicate_klic__compiler__utility_xappend__string_3 =
   { module_klic__compiler__utility, 5, 3 };
Const struct predicate predicate_klic__compiler__utility_xappend__string__loop_6 =
   { module_klic__compiler__utility, 6, 6 };
extern q string_g_new();
extern Const struct predicate predicate_integer__arithmetics_xadd_3;

module module_klic__compiler__utility(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  Const static unsigned char strconst_body_0[4] =
    ".";
  Const static string_structure_type_8 string_const_0 =
      declare_string_constant_8(strconst_body_0,1);
  q a0, a1, a2, a3, a4, a5;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, extend__name_3_top);
    case_pred(1, extend_3_top);
    case_pred(2, extend_4_top);
    case_pred(3, compress_2_top);
    case_pred(4, compress_6_top);
    case_pred(5, append__string_3_top);
    last_case_pred(6, append__string__loop_6_top);
  }

 extend__name_3_top: {
  q x0;
  a2 = qp->args[2];
  qp = qp->next;
 extend__name_3_clear_reason:
  reasonp = reasons;
 extend__name_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__compiler__utility_xextend_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  a1 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(compress_2_0);
  goto compress_2_ext_interrupt;
 extend__name_3_ext_interrupt:
  reasonp = 0l;
 extend__name_3_interrupt:
  goto interrupt_3;
 }

 extend_3_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  qp = qp->next;
 extend_3_clear_reason:
  reasonp = reasons;
 extend_3_0:
 extend_3_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
 extend_3_2:
  if (!isgobj(a0)) goto extend_3_interrupt;
 extend_3_3:
  gblt_is_string(a0,extend_3_interrupt);
  gblt_size_of_string(a0,x0,extend_3_interrupt);
  gblt_element_size_of_string(a0,x1,extend_3_interrupt);
 extend_3_7:
  if (x1 != makeint(8L)) goto extend_3_interrupt;
  bblt_sub_no_check(x0,makeint(1L),x2);
  a3 = x2;
  execute(extend_4_0);
  goto extend_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,extend_3_1);
  *reasonp++ =  a0;
  goto extend_3_interrupt;
  };
  goto extend_3_interrupt;
 extend_3_ext_interrupt:
  reasonp = 0l;
 extend_3_interrupt:
  goto interrupt_3;
 }

 extend_4_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 extend_4_clear_reason:
  reasonp = reasons;
 extend_4_0:
 extend_4_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
 extend_4_2:
  if (!isgobj(a0)) goto extend_4_13;
 extend_4_3:
 extend_4_4:
  if (isref(a3)) goto extend_4_12;
  generic_arg[0] = a3;
  guard_generic(a0, functor_element_2, 1, extend_4_13);
  x0 = generic_arg[1];
 extend_4_7:
  switch (ptagof(x0)) {
 case ATOMIC:
 extend_4_9:
  switch ((unsigned long)x0) {
 case (unsigned long) makeint(46L):
  unify_value(a2, a0);
  proceed();
 case (unsigned long) makeint(47L):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__compiler__utility_xappend__string_3);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  a1 = makefunctor(&string_const_0);
  a2 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(append__string_3_0);
  goto append__string_3_ext_interrupt;
 default:
  goto extend_4_13;
  };
 case VARREF:
  deref_and_jump(x0,extend_4_7);
  *reasonp++ =  x0;
  goto extend_4_13;
  };
  goto extend_4_13;
 extend_4_12:
  deref_and_jump(a3,extend_4_4);
  *reasonp++ =  a3;
  goto extend_4_13;
 case VARREF:
  deref_and_jump(a0,extend_4_1);
  *reasonp++ =  a0;
  goto extend_4_13;
  };
  goto extend_4_13;
 extend_4_13:
 extend_4_14:
  if (!isint(a3)) goto extend_4_17;
  gblt_less(a3,makeint(0L),extend_4_18);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__compiler__utility_xappend__string_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  a1 = makefunctor(&string_const_0);
  a2 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(append__string_3_clear_reason);
  goto append__string_3_ext_interrupt;
 extend_4_17:
  if (!isref(a3)) goto extend_4_18;
  deref_and_jump(a3,extend_4_14);
  *reasonp++ =  a3;
  goto extend_4_18;
 extend_4_18:
  otherwise(extend_4_interrupt);
  bblt_sub_no_check_y(a3,makeint(1L),x0);
  a3 = x0;
  execute(extend_4_0);
  goto extend_4_ext_interrupt;
 extend_4_ext_interrupt:
  reasonp = 0l;
 extend_4_interrupt:
  toppred = &predicate_klic__compiler__utility_xextend_4;
  goto interrupt_4;
 }

 compress_2_top: {
  q x0, x1, x2;
  qp = qp->next;
 compress_2_clear_reason:
  reasonp = reasons;
 compress_2_0:
 compress_2_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
 compress_2_2:
  if (!isgobj(a0)) goto compress_2_interrupt;
 compress_2_3:
  gblt_is_string(a0,compress_2_interrupt);
  gblt_size_of_string(a0,x0,compress_2_interrupt);
  gblt_element_size_of_string(a0,x1,compress_2_interrupt);
  a2 = a0;
  allocp[0] = x2 = makeref(&allocp[0]);
  a3 = x2;
  a4 = x2;
  a5 = a1;
  a1 = x0;
  a0 = makeint(0L);
  allocp += 1;
  execute(compress_6_0);
  goto compress_6_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,compress_2_1);
  *reasonp++ =  a0;
  goto compress_2_interrupt;
  };
  goto compress_2_interrupt;
 compress_2_ext_interrupt:
  reasonp = 0l;
 compress_2_interrupt:
  toppred = &predicate_klic__compiler__utility_xcompress_2;
  goto interrupt_2;
 }

 compress_6_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 compress_6_clear_reason:
  reasonp = reasons;
 compress_6_0:
 compress_6_1:
  if (!isint(a0)) goto compress_6_22;
 compress_6_3:
  if (!isint(a1)) goto compress_6_21;
  gblt_less(a0,a1,compress_6_19);
  gblt_add(a0,makeint(1L),x0,compress_6_19);
 compress_6_7:
  switch (ptagof(a2)) {
 case FUNCTOR:
 compress_6_8:
  if (!isgobj(a2)) goto compress_6_19;
 compress_6_9:
  generic_arg[0] = a0;
  guard_generic(a2, functor_element_2, 1, compress_6_19);
  x1 = generic_arg[1];
 compress_6_11:
  switch (ptagof(x1)) {
 case ATOMIC:
 compress_6_13:
  switch ((unsigned long)x1) {
 case (unsigned long) makeint(32L):
  a0 = x0;
  execute(compress_6_0);
  goto compress_6_ext_interrupt;
 case (unsigned long) makeint(9L):
  a0 = x0;
  execute(compress_6_0);
  goto compress_6_ext_interrupt;
 default:
  goto compress_6_16;
  };
 case VARREF:
  deref_and_jump(x1,compress_6_11);
  *reasonp++ =  x1;
  goto compress_6_19;
  };
  goto compress_6_16;
 compress_6_16:
  gblt_diff(x1,makeint(32L),compress_6_19);
  gblt_diff(x1,makeint(9L),compress_6_19);
  allocp[0] = x3 = makeref(&allocp[0]);
  allocp[1] = x1;
  x2 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a3, x2);
  a0 = x0;
  a3 = x3;
  execute(compress_6_0);
  goto compress_6_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,compress_6_7);
  *reasonp++ =  a2;
  goto compress_6_19;
  };
  goto compress_6_19;
 compress_6_19:
  gblt_greater_or_eq(a0,a1,compress_6_interrupt);
  unify_value(a3, NILATOM);
  generic_arg[0] = a4;
  generic_arg[1] = makeint(8L);
  new_generic(string_g_new, 2, x0, 0);
  unify(a5, x0);
  proceed();
 compress_6_21:
  if (!isref(a1)) goto compress_6_interrupt;
  deref_and_jump(a1,compress_6_3);
  *reasonp++ =  a1;
  goto compress_6_interrupt;
 compress_6_22:
  if (!isref(a0)) goto compress_6_interrupt;
  deref_and_jump(a0,compress_6_1);
  *reasonp++ =  a0;
  goto compress_6_interrupt;
 compress_6_ext_interrupt:
  reasonp = 0l;
 compress_6_interrupt:
  toppred = &predicate_klic__compiler__utility_xcompress_6;
  goto interrupt_6;
 }

 append__string_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  qp = qp->next;
 append__string_3_clear_reason:
  reasonp = reasons;
 append__string_3_0:
 append__string_3_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
 append__string_3_2:
  if (!isgobj(a0)) goto append__string_3_interrupt;
 append__string_3_3:
  gblt_is_string(a0,append__string_3_interrupt);
  gblt_size_of_string(a0,x0,append__string_3_interrupt);
  gblt_element_size_of_string(a0,x1,append__string_3_interrupt);
 append__string_3_7:
  switch (ptagof(a1)) {
 case FUNCTOR:
 append__string_3_8:
  if (!isgobj(a1)) goto append__string_3_interrupt;
 append__string_3_9:
  gblt_is_string(a1,append__string_3_interrupt);
  gblt_size_of_string(a1,x2,append__string_3_interrupt);
  gblt_element_size_of_string(a1,x3,append__string_3_interrupt);
 append__string_3_13:
  if (isref(x3)) goto append__string_3_19;
 append__string_3_15:
  if (isref(x3)) goto append__string_3_18;
  if_not_equal(x3, x1, append__string_3_interrupt);
  bblt_add_no_check(x0,x2,x4);
  generic_arg[0] = x4;
  generic_arg[1] = x1;
  new_generic(string_g_new, 2, x5, 0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__compiler__utility_xappend__string__loop_6);
  allocp[2] = makeint(0L);
  allocp[3] = x0;
  allocp[4] = x6 = makeref(&allocp[4]);
  allocp[5] = a1;
  allocp[6] = x7 = makeref(&allocp[6]);
  allocp[7] = a2;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[10] = x0;
  allocp[11] = x2;
  allocp[12] = x6;
  a1 = makeint(0L);
  a2 = x0;
  a3 = a0;
  a4 = x5;
  a5 = x7;
  a0 = makeint(0L);
  qp = (struct goalrec*)&allocp[8];
  allocp += 13;
  execute(append__string__loop_6_clear_reason);
  goto append__string__loop_6_ext_interrupt;
 append__string_3_18:
  deref_and_jump(x3,append__string_3_15);
  *reasonp++ =  x3;
  goto append__string_3_interrupt;
 append__string_3_19:
  deref_and_jump(x3,append__string_3_13);
  *reasonp++ =  x3;
  goto append__string_3_interrupt;
 case VARREF:
  deref_and_jump(a1,append__string_3_7);
  *reasonp++ =  a1;
  goto append__string_3_interrupt;
  };
  goto append__string_3_interrupt;
 case VARREF:
  deref_and_jump(a0,append__string_3_1);
  *reasonp++ =  a0;
  goto append__string_3_interrupt;
  };
  goto append__string_3_interrupt;
 append__string_3_ext_interrupt:
  reasonp = 0l;
 append__string_3_interrupt:
  toppred = &predicate_klic__compiler__utility_xappend__string_3;
  goto interrupt_3;
 }

 append__string__loop_6_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 append__string__loop_6_clear_reason:
  reasonp = reasons;
 append__string__loop_6_0:
 append__string__loop_6_1:
  if (isref(a1)) goto append__string__loop_6_7;
 append__string__loop_6_3:
  if (isref(a1)) goto append__string__loop_6_6;
  if_not_equal(a1, a2, append__string__loop_6_8);
  unify(a5, a4);
  proceed();
 append__string__loop_6_6:
  deref_and_jump(a1,append__string__loop_6_3);
  *reasonp++ =  a1;
  goto append__string__loop_6_8;
 append__string__loop_6_7:
  deref_and_jump(a1,append__string__loop_6_1);
  *reasonp++ =  a1;
  goto append__string__loop_6_8;
 append__string__loop_6_8:
  otherwise(append__string__loop_6_interrupt);
  generic_arg[0] = a0;
  allocp[0] = x0 = makeref(&allocp[0]);
  generic_arg[1] = x0;
  call_generic(a3, functor_element_2, 1);
  generic_arg[0] = a1;
  generic_arg[1] = x0;
  allocp[0] = x1 = makeref(&allocp[0]);
  generic_arg[2] = x1;
  call_generic(a4, functor_set__element_3, 1);
  bblt_add_no_check_y(a0,makeint(1L),x2);
  bblt_add_no_check_y(a1,makeint(1L),x3);
  a0 = x2;
  a1 = x3;
  a4 = x1;
  execute(append__string__loop_6_0);
  goto append__string__loop_6_ext_interrupt;
 append__string__loop_6_ext_interrupt:
  reasonp = 0l;
 append__string__loop_6_interrupt:
  toppred = &predicate_klic__compiler__utility_xappend__string__loop_6;
  goto interrupt_6;
 }
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_klic__compiler__utility);
}
