#include <klic/basic.h>
#include <klic/struct.h>
#include <klic/primitives.h>
#include <klic/unify.h>
#include <klic/timing.h>

#include <stdio.h>
#include <setjmp.h>
#include <signal.h>

#include <klic/interpe.h>
#include <klic/traceio.h>

#include "pvm3.h"

extern char *malloc();
extern free();

void send_signal_to_me()
{
  if(!sendsig_flag){
    int sig_info = pvm_sendsig(tid_of(my_node), SIGUSR1);
    if(sig_info != 0){
      fatal("pvm_sendsig error in send_signal_to_me");
    }
  }
}  

int receive_message (allocp, sig)
     q *allocp;
     int sig;
{
  declare_globals;
  struct goalrec *qp;
  module func;
  int buf_id, bufsize, msgtag, tid, info;
  q* allocp_debug;

  inbuf_index = 0;  /* clear inbuf_index */

  while(buf_id = pvm_nrecv(-1, -1)){

    info = pvm_bufinfo(buf_id, &bufsize, &msgtag, &tid);
    if(info < 0) {
      fatal("Error in pvm_bufinfo\n");
    }

    allocp_debug = allocp;
    if( ((bufsize*DECODE_MAX_OBJ_SIZE)/sizeof(long)) > 
       ((long)real_heaplimit - (long)allocp)){

      int info = pvm_setsbuf(buf_id);
      if(info == PvmBadParam){
	fatal("Invalid bufid in Expanding heap in receiving message");
      }
      if(info == PvmNoSuchBuf){
	fatal("Switch to invalid buf in Expanding heap in receiving msg");
      }
      info = pvm_send(tid_of(my_node),3);
      if(info < 0){
	fatal("Error in pvm_send in expandeing heap in receiveing msg");
      }
      this_more_space =+ ((bufsize*DECODE_MAX_OBJ_SIZE)/sizeof(long));

      heapp = real_heaplimit;
      return(1); 
    }

    if(bufsize > current_inbuf_size*sizeof(q)){
      expand_inbuf(bufsize);
    }

    info = pvm_upklong(inbuf, bufsize/sizeof(long), 1); 
    if(info < 0){
      fatal("Error in pvm_upk\n");
    }

    recv_data_cnt+=bufsize;

    while(inbuf_index != bufsize/sizeof(long)){
      func = (void *)inbuf[inbuf_index++];
      allocp = (q *)func(inbuf, allocp);
    }    

    inbuf_index = 0;  /* clear inbuf_index */

    if(real_heaplimit <= (allocp)){/* Heap over in msg_handler */
      return(1); 
    }
  }
  heapp = allocp;
  return(0);
}

void send_request_wtc();

void *send_message(node)
     long node;
{
  int info;

  info = pvm_initsend(PvmDataRaw);
  if(info < 0){
    fatal("Error in pvm_initsend\n");
  }

  info = pvm_pklong(network_outbuf, outbuf_index, 1);
  if(info < 0){
    fatal("Error in pvm_pkint\n");
  }

  send_data_cnt+=outbuf_index;

  info = pvm_send(tid_of(node),3);
  if(info < 0){
    fatal("Error in pvm_send\n");
  }

  outbuf_index = 0;

  if(!sendsig_flag){
    info = pvm_sendsig(tid_of(node), SIGUSR1);
    if(info != 0){
      sprintf(iobuf,"PVM_SENDSIG_ERROR sig_info = %d\n",info);
      EPrint(iobuf);
    }
  }

  if(my_node != SHOEN_NODE){
    if(node_wtc < REQUEST_WTC_THRESHOLD && !requesting_wtc){
      requesting_wtc = 1;

      if(node_wtc == 0){
	sprintf(iobuf,"Pre check, Invalid WTC in node%d\n",my_node);
	EPrint(iobuf);
	fatal("invalid WTC");
      }

      send_request_wtc();
    }
  }
}

void *send_message_with_no_wtc(node)
     long node;
{
  int info;

  info = pvm_initsend(PvmDataRaw);
  if(info < 0){
    fatal("Error in pvm_initsend\n");
  }

  info = pvm_pklong(network_outbuf, outbuf_index, 1);
  if(info < 0){
    fatal("Error in pvm_pkint\n");
  }

  send_data_cnt+=outbuf_index;

  info = pvm_send(tid_of(node),3);
  if(info < 0){
    fatal("Error in pvm_send\n");
  }

  outbuf_index = 0;
/**/
  if(!sendsig_flag){
    info = pvm_sendsig(tid_of(node), SIGUSR1);
    if(info != 0){
      sprintf(iobuf,"PVM_SENDSIG_ERROR sig_info = %d\n",info);
      EPrint(iobuf);
    }
  }
/**/
}

struct goalrec *trace_goal();
void *encode_throw_goal();
void message_suspend();

struct goalrec *send_throw_goal(node_num, goal, oldqp)
     q node_num;
     struct goalrec *goal;
     struct goalrec *oldqp;
{
  declare_globals;
  long node = intval(node_num);
  extern int trace_flag;

  if(isref(node_num)){
    fatal("send_throw_goal, PE num shuold be bounded");
  }
  if(node >= total_node){
    sprintf(iobuf,"Try to send node %d from node %d\n",node, my_node);
    EPrint(iobuf);
    fatal("send_throw_goal, invalid destination node");
  }    

  if(node == my_node){ /* prio of goal == prio of oldqp */
    goal->next = oldqp;
    return(goal);
  } else {
#ifdef DEBUGLIB
    if (trace_flag) {
      goal = trace_goal(goal, (node+1)*100000+throw_trace_count);
      throw_trace_count++;
    }
#endif
    if(!encode_throw_goal(goal, node)){
      message_suspend(THROW_WTC_UNIT, node);
    } else {
      send_message(node);
    }
    return(oldqp);
  }
}

long encode_read();

long send_read(node_num, index, var)
     long node_num;   /* Node No.     of Imported Data */
     long index;      /* ExpTbl index of Imported Data */
     q var;        /* To Readhook                   */
{
  long ret_index;

#ifdef INT_CL_DEBUG
  printf("send_read\n");
#endif

  if(!encode_read(node_num, index, var)){
    message_suspend(READ_WTC_UNIT, node_num);
/*    sprintf(iobuf,"Send Read message suspended!!!\nDANGEROUS DANGEROUS\n");
    EPrint(iobuf);*/

  } else {
    send_message(node_num);
  }
  return(global_ret_index);
}

void send_answer_value(data, node, index, wec)
     q data;
     long node, index, wec;
{
#ifdef INT_CL_DEBUG
  printf("send_answer_value\n");
#endif

  if(!encode_answer_value(data, node, index, wec)){
    message_suspend(ANSWER_WTC_UNIT, node);
/*    sprintf(iobuf,"Send answer message suspended!!!\n");
    EPrint(iobuf);*/
  } else {
    send_message(node);
  }
}

void send_unify(node, index, wec, data)
     long node,index, wec;
     q data;
{
#ifdef INT_CL_DEBUG
  printf("send_unify\n");
#endif  

  if(!encode_unify(node, index, wec, data)){
    message_suspend(UNIFY_WTC_UNIT,node);
  } else {
    send_message(node);
  }
}

void send_release(node, index, wec)
     long node, index, wec;
{
#ifdef INT_CL_DEBUG
  printf("send_release\n");
#endif  
  encode_release(node, index, wec);
  send_message_with_no_wtc(node);
}

/*
Extern void *report_msg_stat();

void send_report_msg_stat()
{
  int  sig_info, node;
  long msg;
  
  msg = (long)report_msg_stat;
  pvm_initsend(PvmDataDefault);
  pvm_pklong(&msg, 1, 1);
  pvm_mcast(&tid_tbl[1], total_node-1, 3);  

  for( node = 1 ;node < total_node; node++){
    if(!sendsig_flag){
      sig_info = pvm_sendsig(tid_of(node), SIGUSR1);
      if(sig_info < 0){
	fatal("Error in pvm_sendsig in report_msg_stat");
      }
    }
  }
}
*/

Extern void *encode_request_wtc();

void send_request_wtc()
{
#ifdef INT_CL_DEBUG
  printf("send_request_wtc\n");
#endif  

  encode_request_wtc();
  send_message(SHOEN_NODE);
}

void send_supply_wtc(node)
     long node;
{
#ifdef INT_CL_DEBUG
  printf("send_supply_wtc\n");
#endif  
  encode_supply_wtc(node);
  send_message(node);
} 

void send_return_wtc()
{
  int sig_info;

#ifdef INT_CL_DEBUG
  printf("send_return_wtc\n");
#endif  
  encode_return_wtc();

  /* Cannot yse send_message routine, 
     because it sends request_wtc message after sending the message. */

  pvm_initsend(PvmDataRaw);
  pvm_pklong(network_outbuf, outbuf_index, 1);
  pvm_send(tid_of(SHOEN_NODE),3);
  if(!sendsig_flag){
    sig_info = pvm_sendsig(tid_of(SHOEN_NODE), SIGUSR1);
    
    if(sig_info != 0){
      sprintf(iobuf,"PVM_SENDSIG_ERROR sig_info = %d\n",sig_info);
      EPrint(iobuf);
    }
  }
  outbuf_index = 0;
}

Extern void *encode_terminate_msg();

void send_terminate_msg()
{
  int node;
#ifdef INT_CL_DEBUG
  printf("broadcast_terminate\n");
#endif  

  for( node = 0 ;node < total_node; node++){
    encode_terminate_msg(node);
    send_message(node);
  }
}

void message_suspend(dummy_wtc, node)
     long dummy_wtc;
     long node;
{
  char *susp_msg, *msg_body;
  struct susp_msg_rec *suspended_msg;
  int i;

  susp_msg = malloc(sizeof(struct susp_msg_rec));
  if(susp_msg == NULL){
    fatal("malloc failed in initiate message suspend record(1)");
  }

  msg_body = malloc(sizeof(long)*outbuf_index);
  if(msg_body == NULL){
    fatal("malloc failed in initiate message suspend record(2)");
  }

  suspended_msg = (struct susp_msg_rec *)susp_msg;
  suspended_msg->outbuf = (long *)msg_body;
  suspended_msg->node = node;
  suspended_msg->wtc = dummy_wtc;
  suspended_msg->length = outbuf_index;

  suspended_msg->next = top_of_susp_msg_rec;
  top_of_susp_msg_rec = suspended_msg;

  for(i=0;i<outbuf_index;i++){
    suspended_msg->outbuf[i] = network_outbuf[i];
  }

  outbuf_index = 0;

  msg_suspend_cnt++;

  if(my_node != SHOEN_NODE){
    if(node_wtc < REQUEST_WTC_THRESHOLD && !requesting_wtc){
      requesting_wtc = 1;
      send_request_wtc();
    }
  }
}

void message_resume()
{
  int i;
  struct susp_msg_rec *suspended_msg;
  
  while((long)top_of_susp_msg_rec != END_SUSP_MSG_REC){
    suspended_msg = top_of_susp_msg_rec;
    top_of_susp_msg_rec = suspended_msg->next;

    for(i=0;i<suspended_msg->length;i++){
      network_outbuf[i] = suspended_msg->outbuf[i];
    }
    outbuf_index = suspended_msg->length;

    node_wtc = node_wtc - suspended_msg->wtc;

    send_message(suspended_msg->node);

    msg_resume_cnt++;

    free(suspended_msg->outbuf);
    free(suspended_msg);

    if(requesting_wtc){
      sprintf(iobuf,"Unbelievable Case, Send request WTC again!!\n");
      EPrint(iobuf);
      break;
    }
  }

}
