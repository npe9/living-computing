struct enqueue_trace_rec {
  struct enqueue_trace_rec *next;
  struct goalrec *g;
  long prio;
};
