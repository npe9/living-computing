/* Compiled by KLIC compiler version 1.500 (Fri Oct 21 12:19:27 JST 1994) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_klic__comp__generate();
Const struct predicate predicate_klic__comp__generate_xgen__code_14 =
   { module_klic__comp__generate, 0, 14 };
Const struct predicate predicate_klic__comp__generate_xgen__code__1_15 =
   { module_klic__comp__generate, 1, 15 };
Const struct predicate predicate_klic__comp__generate_xgen__code__1_2F15_240_18 =
   { module_klic__comp__generate, 2, 18 };
Const struct predicate predicate_klic__comp__generate_xgen__code__3_14 =
   { module_klic__comp__generate, 3, 14 };
Const struct predicate predicate_klic__comp__generate_xgen__code__3__1_14 =
   { module_klic__comp__generate, 4, 14 };
Const struct predicate predicate_klic__comp__generate_xgen__code__3__2_15 =
   { module_klic__comp__generate, 5, 15 };
Const struct predicate predicate_klic__comp__generate_xgen__code__3__3_15 =
   { module_klic__comp__generate, 6, 15 };
Const struct predicate predicate_klic__comp__generate_xgen__atomic_15 =
   { module_klic__comp__generate, 7, 15 };
Const struct predicate predicate_klic__comp__generate_xgen__atomic_2F15_240_20 =
   { module_klic__comp__generate, 8, 20 };
Const struct predicate predicate_klic__comp__generate_xgen__atomic_2F15_240_2F20_241_19 =
   { module_klic__comp__generate, 9, 19 };
Const struct predicate predicate_klic__comp__generate_xgen__atomic_2F15_240_2F20_241_2F19_240_5 =
   { module_klic__comp__generate, 10, 5 };
Const struct predicate predicate_klic__comp__generate_xgen__atomic_2F15_240_2F20_240_20 =
   { module_klic__comp__generate, 11, 20 };
Const struct predicate predicate_klic__comp__generate_xgen__atomic_2F15_240_2F20_240_2F20_240_5 =
   { module_klic__comp__generate, 12, 5 };
Const struct predicate predicate_klic__comp__generate_xgen__atomic__1_15 =
   { module_klic__comp__generate, 13, 15 };
Const struct predicate predicate_klic__comp__generate_xgen__atomic__2_20 =
   { module_klic__comp__generate, 14, 20 };
Const struct predicate predicate_klic__comp__generate_xgen__functs_15 =
   { module_klic__comp__generate, 15, 15 };
Const struct predicate predicate_klic__comp__generate_xgen__gobjs_15 =
   { module_klic__comp__generate, 16, 15 };
Const struct predicate predicate_klic__comp__generate_xgen__classes_15 =
   { module_klic__comp__generate, 17, 15 };
Const struct predicate predicate_klic__comp__generate_xgen__cases_16 =
   { module_klic__comp__generate, 18, 16 };
Const struct predicate predicate_klic__comp__generate_xgen__cases_2F16_240_18 =
   { module_klic__comp__generate, 19, 18 };
Const struct predicate predicate_klic__comp__generate_xgen__cases_2F16_240_2F18_241_15 =
   { module_klic__comp__generate, 20, 15 };
Const struct predicate predicate_klic__comp__generate_xgen__cases_2F16_240_2F18_240_13 =
   { module_klic__comp__generate, 21, 13 };
Const struct predicate predicate_klic__comp__generate_xgen__all__cases_14 =
   { module_klic__comp__generate, 22, 14 };
Const struct predicate predicate_klic__comp__generate_xgen__all__cases_2F14_240_13 =
   { module_klic__comp__generate, 23, 13 };
Const struct predicate predicate_klic__comp__generate_xgen__lab_5 =
   { module_klic__comp__generate, 24, 5 };
Const struct predicate predicate_klic__comp__generate_xgen__type__known_3 =
   { module_klic__comp__generate, 25, 3 };
Const struct predicate predicate_klic__comp__generate_xbasic__type_2 =
   { module_klic__comp__generate, 26, 2 };
Const struct predicate predicate_klic__comp__generate_xis__basic_3 =
   { module_klic__comp__generate, 27, 3 };
Const struct predicate predicate_klic__comp__generate_xgen__cond_12 =
   { module_klic__comp__generate, 28, 12 };
Const struct predicate predicate_klic__comp__generate_xadd__inline__info_3 =
   { module_klic__comp__generate, 29, 3 };
Const struct predicate predicate_klic__comp__generate_xload__guard__generic__out_11 =
   { module_klic__comp__generate, 30, 11 };
Const struct predicate predicate_klic__comp__generate_xprep__poss_10 =
   { module_klic__comp__generate, 31, 10 };
Const struct predicate predicate_klic__comp__generate_xprep__vec__elems_10 =
   { module_klic__comp__generate, 32, 10 };
Const struct predicate predicate_klic__comp__generate_xalloc__if__var_8 =
   { module_klic__comp__generate, 33, 8 };
Const struct predicate predicate_klic__comp__generate_xprep__pos_10 =
   { module_klic__comp__generate, 34, 10 };
Const struct predicate predicate_klic__comp__generate_xprep__pos__1_10 =
   { module_klic__comp__generate, 35, 10 };
Const struct predicate predicate_klic__comp__generate_xalloc__args_10 =
   { module_klic__comp__generate, 36, 10 };
Const struct predicate predicate_klic__comp__generate_xalloc__one_10 =
   { module_klic__comp__generate, 37, 10 };
Const struct predicate predicate_klic__comp__generate_xalloc__one__1_10 =
   { module_klic__comp__generate, 38, 10 };
Const struct predicate predicate_klic__comp__generate_xload__inline__args_11 =
   { module_klic__comp__generate, 39, 11 };
Const struct predicate predicate_klic__comp__generate_xload__pos_10 =
   { module_klic__comp__generate, 40, 10 };
Const struct predicate predicate_klic__comp__generate_xload__reg_11 =
   { module_klic__comp__generate, 41, 11 };
Const struct predicate predicate_klic__comp__generate_xload__reg__1_11 =
   { module_klic__comp__generate, 42, 11 };
Const struct predicate predicate_klic__comp__generate_xgen__body_13 =
   { module_klic__comp__generate, 43, 13 };
Const struct predicate predicate_klic__comp__generate_xgen__body__goal_13 =
   { module_klic__comp__generate, 44, 13 };
Const struct predicate predicate_klic__comp__generate_xset__call_10 =
   { module_klic__comp__generate, 45, 10 };
Const struct predicate predicate_klic__comp__generate_xset__call__merge_3 =
   { module_klic__comp__generate, 46, 3 };
Const struct predicate predicate_klic__comp__generate_xenq__at__prio_12 =
   { module_klic__comp__generate, 47, 12 };
Const struct predicate predicate_klic__comp__generate_xenq__at__prio_2F12_240_12 =
   { module_klic__comp__generate, 48, 12 };
Const struct predicate predicate_klic__comp__generate_xprio__code_7 =
   { module_klic__comp__generate, 49, 7 };
Const struct predicate predicate_klic__comp__generate_xbody__unify_12 =
   { module_klic__comp__generate, 50, 12 };
Const struct predicate predicate_klic__comp__generate_xbody__unify__1_11 =
   { module_klic__comp__generate, 51, 11 };
Const struct predicate predicate_klic__comp__generate_xbody__unify__2_7 =
   { module_klic__comp__generate, 52, 7 };
Const struct predicate predicate_klic__comp__generate_xbb__in_14 =
   { module_klic__comp__generate, 53, 14 };
Const struct predicate predicate_klic__comp__generate_xbb__in_2F14_241_12 =
   { module_klic__comp__generate, 54, 12 };
Const struct predicate predicate_klic__comp__generate_xbb__in_2F14_240_11 =
   { module_klic__comp__generate, 55, 11 };
Const struct predicate predicate_klic__comp__generate_xbb__out_14 =
   { module_klic__comp__generate, 56, 14 };
Const struct predicate predicate_klic__comp__generate_xbb__out_2F14_240_13 =
   { module_klic__comp__generate, 57, 13 };
Const struct predicate predicate_klic__comp__generate_xprep__call__arg_10 =
   { module_klic__comp__generate, 58, 10 };
Const struct predicate predicate_klic__comp__generate_xprep__needed_2 =
   { module_klic__comp__generate, 59, 2 };
Const struct predicate predicate_klic__comp__generate_xprep__call__arg__on__need_11 =
   { module_klic__comp__generate, 60, 11 };
Const struct predicate predicate_klic__comp__generate_xset__args_10 =
   { module_klic__comp__generate, 61, 10 };
Const struct predicate predicate_klic__comp__generate_xset__one_10 =
   { module_klic__comp__generate, 62, 10 };
Const struct predicate predicate_klic__comp__generate_xset__one__1_10 =
   { module_klic__comp__generate, 63, 10 };
Const struct predicate predicate_klic__comp__generate_xset__generic__args_10 =
   { module_klic__comp__generate, 64, 10 };
Const struct predicate predicate_klic__comp__generate_xset__generic__args_2F10_240_10 =
   { module_klic__comp__generate, 65, 10 };
Const struct predicate predicate_klic__comp__generate_xmove__args_10 =
   { module_klic__comp__generate, 66, 10 };
Const struct predicate predicate_klic__comp__generate_xmove__args__1_12 =
   { module_klic__comp__generate, 67, 12 };
Const struct predicate predicate_klic__comp__generate_xmove__one_10 =
   { module_klic__comp__generate, 68, 10 };
Const struct predicate predicate_klic__comp__generate_xmove__one__1_10 =
   { module_klic__comp__generate, 69, 10 };
Const struct predicate predicate_klic__comp__generate_xused__in_4 =
   { module_klic__comp__generate, 70, 4 };
Const struct predicate predicate_klic__comp__generate_xused__in__1_5 =
   { module_klic__comp__generate, 71, 5 };
Const struct predicate predicate_klic__comp__generate_xused__in__1_2F5_240_5 =
   { module_klic__comp__generate, 72, 5 };
Const struct predicate predicate_klic__comp__generate_xstrip__types_2 =
   { module_klic__comp__generate, 73, 2 };
Const struct predicate predicate_klic__comp__generate_xmake__label_2 =
   { module_klic__comp__generate, 74, 2 };
Const struct predicate predicate_klic__comp__generate_xadd__info_4 =
   { module_klic__comp__generate, 75, 4 };
Const struct predicate predicate_klic__comp__generate_xrassoc_3 =
   { module_klic__comp__generate, 76, 3 };
Const struct predicate predicate_klic__comp__generate_xassocx_3 =
   { module_klic__comp__generate, 77, 3 };
extern Const struct predicate predicate_klic__comp__util_xmax__list_2;
extern Const struct predicate predicate_klic__comp__util_xmax_3;
extern Const struct predicate predicate_klic__comp__util_xappend_3;
extern Const struct predicate predicate_integer__arithmetics_xsubtract_3;
extern Const struct predicate predicate_klic__comp__util_xuniv_2;
extern Const struct predicate predicate_klic__comp__util_xlength_2;
extern Const struct predicate predicate_klic__comp__insert_xsubsumed__type_3;
extern Const struct predicate predicate_integer__arithmetics_xadd_3;

module module_klic__comp__generate(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  Const static unsigned char strconst_body_0[8] =
    "VARREF";
  Const static string_structure_type_8 string_const_0 =
      declare_string_constant_8(strconst_body_0,6);
  Const static q funct_const_1[] = {
    makesym(functor_case__label_1),
    makefunctor(&string_const_0),
  };
  Const static unsigned char strconst_body_2[4] =
    {'C','O','N','S',};
  Const static string_structure_type_8 string_const_2 =
      declare_string_constant_8(strconst_body_2,4);
  Const static q funct_const_3[] = {
    makesym(functor_case__label_1),
    makefunctor(&string_const_2),
  };
  Const static unsigned char strconst_body_4[8] =
    "ATOMIC";
  Const static string_structure_type_8 string_const_4 =
      declare_string_constant_8(strconst_body_4,6);
  Const static q funct_const_5[] = {
    makesym(functor_case__label_1),
    makefunctor(&string_const_4),
  };
  Const static unsigned char strconst_body_6[8] =
    "FUNCTOR";
  Const static string_structure_type_8 string_const_6 =
      declare_string_constant_8(strconst_body_6,7);
  Const static q funct_const_7[] = {
    makesym(functor_case__label_1),
    makefunctor(&string_const_6),
  };
  Const static q funct_const_8[] = {
    makesym(functor_make__space_1),
    makeint(2),
  };
  Const static q funct_const_9[] = {
    makesym(functor_make__space_1),
    makeint(1),
  };
  q a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17, a18, a19;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, gen__code_14_top);
    case_pred(1, gen__code__1_15_top);
    case_pred(2, gen__code__1_2F15_240_18_top);
    case_pred(3, gen__code__3_14_top);
    case_pred(4, gen__code__3__1_14_top);
    case_pred(5, gen__code__3__2_15_top);
    case_pred(6, gen__code__3__3_15_top);
    case_pred(7, gen__atomic_15_top);
    case_pred(8, gen__atomic_2F15_240_20_top);
    case_pred(9, gen__atomic_2F15_240_2F20_241_19_top);
    case_pred(10, gen__atomic_2F15_240_2F20_241_2F19_240_5_top);
    case_pred(11, gen__atomic_2F15_240_2F20_240_20_top);
    case_pred(12, gen__atomic_2F15_240_2F20_240_2F20_240_5_top);
    case_pred(13, gen__atomic__1_15_top);
    case_pred(14, gen__atomic__2_20_top);
    case_pred(15, gen__functs_15_top);
    case_pred(16, gen__gobjs_15_top);
    case_pred(17, gen__classes_15_top);
    case_pred(18, gen__cases_16_top);
    case_pred(19, gen__cases_2F16_240_18_top);
    case_pred(20, gen__cases_2F16_240_2F18_241_15_top);
    case_pred(21, gen__cases_2F16_240_2F18_240_13_top);
    case_pred(22, gen__all__cases_14_top);
    case_pred(23, gen__all__cases_2F14_240_13_top);
    case_pred(24, gen__lab_5_top);
    case_pred(25, gen__type__known_3_top);
    case_pred(26, basic__type_2_top);
    case_pred(27, is__basic_3_top);
    case_pred(28, gen__cond_12_top);
    case_pred(29, add__inline__info_3_top);
    case_pred(30, load__guard__generic__out_11_top);
    case_pred(31, prep__poss_10_top);
    case_pred(32, prep__vec__elems_10_top);
    case_pred(33, alloc__if__var_8_top);
    case_pred(34, prep__pos_10_top);
    case_pred(35, prep__pos__1_10_top);
    case_pred(36, alloc__args_10_top);
    case_pred(37, alloc__one_10_top);
    case_pred(38, alloc__one__1_10_top);
    case_pred(39, load__inline__args_11_top);
    case_pred(40, load__pos_10_top);
    case_pred(41, load__reg_11_top);
    case_pred(42, load__reg__1_11_top);
    case_pred(43, gen__body_13_top);
    case_pred(44, gen__body__goal_13_top);
    case_pred(45, set__call_10_top);
    case_pred(46, set__call__merge_3_top);
    case_pred(47, enq__at__prio_12_top);
    case_pred(48, enq__at__prio_2F12_240_12_top);
    case_pred(49, prio__code_7_top);
    case_pred(50, body__unify_12_top);
    case_pred(51, body__unify__1_11_top);
    case_pred(52, body__unify__2_7_top);
    case_pred(53, bb__in_14_top);
    case_pred(54, bb__in_2F14_241_12_top);
    case_pred(55, bb__in_2F14_240_11_top);
    case_pred(56, bb__out_14_top);
    case_pred(57, bb__out_2F14_240_13_top);
    case_pred(58, prep__call__arg_10_top);
    case_pred(59, prep__needed_2_top);
    case_pred(60, prep__call__arg__on__need_11_top);
    case_pred(61, set__args_10_top);
    case_pred(62, set__one_10_top);
    case_pred(63, set__one__1_10_top);
    case_pred(64, set__generic__args_10_top);
    case_pred(65, set__generic__args_2F10_240_10_top);
    case_pred(66, move__args_10_top);
    case_pred(67, move__args__1_12_top);
    case_pred(68, move__one_10_top);
    case_pred(69, move__one__1_10_top);
    case_pred(70, used__in_4_top);
    case_pred(71, used__in__1_5_top);
    case_pred(72, used__in__1_2F5_240_5_top);
    case_pred(73, strip__types_2_top);
    case_pred(74, make__label_2_top);
    case_pred(75, add__info_4_top);
    case_pred(76, rassoc_3_top);
    last_case_pred(77, assocx_3_top);
  }

 gen__code_14_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20, x21, x22, x23, x24, x25, x26, x27, x28, x29, x30, x31, x32, x33, x34, x35, x36, x37;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  qp = qp->next;
 gen__code_14_clear_reason:
  reasonp = reasons;
 gen__code_14_0:
 gen__code_14_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_e)) goto gen__code_14_23;
  unify4(a13, a12, a11, a10, a9, a8, a6, a5);
  unify(a4, a3);
  a0 = a2;
  execute(make__label_2_0);
  goto make__label_2_ext_interrupt;
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_other_2:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__util_xmax_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_klic__comp__util_xmax_3);
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  x4 = arg(a0, 1);
  allocp[12] = x4;
  allocp[13] = a1;
  allocp[14] = makesym(atom_none);
  allocp[15] = x5 = makeref(&allocp[15]);
  allocp[16] = x1;
  allocp[17] = x6 = makeref(&allocp[17]);
  allocp[18] = a6;
  allocp[19] = a7;
  allocp[20] = x7 = makeref(&allocp[20]);
  allocp[21] = x3;
  allocp[22] = x8 = makeref(&allocp[22]);
  allocp[23] = a11;
  allocp[24] = x9 = makeref(&allocp[24]);
  allocp[25] = a13;
  qp = (struct goalrec*)&allocp[10];
  allocp += 26;
  unify2(x7, a8, x5, a3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[2] = x10 = makeref(&allocp[2]);
  allocp[3] = makeint(1L);
  allocp[4] = x6;
  allocp[5] = x9;
  allocp[6] = makesym(atom_otherwise);
  x11 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_label_1);
  allocp[8] = x13 = makeref(&allocp[8]);
  x12 = makefunctor(&allocp[7]);
  allocp[9] = x11;
  allocp[10] = x12;
  x14 = makecons(&allocp[9]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 11;
  unify(x13, x10);
  a0 = arg(a0, 0);
  a1 = x13;
  a4 = x0;
  a6 = x10;
  a9 = x2;
  a11 = x8;
  a13 = x14;
  execute(gen__code_14_0);
  goto gen__code_14_ext_interrupt;
 case functor_alter_2:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__util_xmax_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  x2 = arg(a0, 1);
  allocp[7] = x2;
  allocp[8] = a1;
  allocp[9] = makesym(atom_none);
  allocp[10] = x3 = makeref(&allocp[10]);
  allocp[11] = x1;
  allocp[12] = x4 = makeref(&allocp[12]);
  allocp[13] = a6;
  allocp[14] = a7;
  allocp[15] = x5 = makeref(&allocp[15]);
  allocp[16] = a9;
  allocp[17] = x6 = makeref(&allocp[17]);
  allocp[18] = a11;
  allocp[19] = x7 = makeref(&allocp[19]);
  allocp[20] = a13;
  qp = (struct goalrec*)&allocp[5];
  allocp += 21;
  unify(x3, a3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[2] = x8 = makeref(&allocp[2]);
  allocp[3] = makeint(1L);
  allocp[4] = x4;
  allocp[5] = x7;
  allocp[6] = makesym(atom_alternatively);
  x9 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_label_1);
  allocp[8] = x11 = makeref(&allocp[8]);
  x10 = makefunctor(&allocp[7]);
  allocp[9] = x9;
  allocp[10] = x10;
  x12 = makecons(&allocp[9]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 11;
  unify(x11, x8);
  a0 = arg(a0, 0);
  a1 = x11;
  a4 = x0;
  a6 = x8;
  a9 = x5;
  a11 = x6;
  a13 = x12;
  execute(gen__code_14_0);
  goto gen__code_14_ext_interrupt;
 case functor_l_1:
  unify(a9, a8);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xgen__body_13);
  x0 = arg(a0, 0);
  allocp[2] = x0;
  allocp[3] = a8;
  allocp[4] = makesym(atom_qp);
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = a6;
  allocp[7] = a3;
  allocp[8] = a4;
  allocp[9] = a7;
  allocp[10] = x2 = makeref(&allocp[10]);
  allocp[11] = a10;
  allocp[12] = a11;
  allocp[13] = x3 = makeref(&allocp[13]);
  allocp[14] = a13;
  a0 = a2;
  a1 = a5;
  a2 = x1;
  a3 = a12;
  a4 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 15;
  execute(gen__lab_5_0);
  goto gen__lab_5_ext_interrupt;
 case functor_x_3:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__util_xmax_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a4;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_klic__comp__util_xmax_3);
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = makesym(functor_lab_1);
  allocp[11] = x5 = makeref(&allocp[11]);
  x4 = makefunctor(&allocp[10]);
  allocp[12] = (q)(struct goalrec*)&allocp[5];
  allocp[13] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  x6 = arg(a0, 2);
  allocp[14] = x6;
  allocp[15] = a1;
  allocp[16] = x4;
  allocp[17] = x7 = makeref(&allocp[17]);
  allocp[18] = x1;
  allocp[19] = x8 = makeref(&allocp[19]);
  allocp[20] = a6;
  allocp[21] = x9 = makeref(&allocp[21]);
  allocp[22] = x10 = makeref(&allocp[22]);
  allocp[23] = x3;
  allocp[24] = x11 = makeref(&allocp[24]);
  allocp[25] = a11;
  allocp[26] = x12 = makeref(&allocp[26]);
  allocp[27] = a13;
  allocp[28] = (q)(struct goalrec*)&allocp[12];
  allocp[29] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  x13 = arg(a0, 1);
  allocp[30] = x13;
  allocp[31] = x5;
  allocp[32] = makesym(atom_none);
  allocp[33] = x14 = makeref(&allocp[33]);
  allocp[34] = x0;
  allocp[35] = x15 = makeref(&allocp[35]);
  allocp[36] = x8;
  allocp[37] = x9;
  allocp[38] = x16 = makeref(&allocp[38]);
  allocp[39] = x2;
  allocp[40] = x17 = makeref(&allocp[40]);
  allocp[41] = x11;
  allocp[42] = x18 = makeref(&allocp[42]);
  allocp[43] = x12;
  qp = (struct goalrec*)&allocp[28];
  allocp += 44;
  unify2(x10, x16, x7, x14);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xgen__cond_12);
  x19 = arg(a0, 0);
  allocp[2] = x19;
  allocp[3] = x5;
  allocp[4] = a3;
  allocp[5] = x14;
  allocp[6] = x20 = makeref(&allocp[6]);
  allocp[7] = x9;
  allocp[8] = a8;
  allocp[9] = x16;
  allocp[10] = a10;
  allocp[11] = x17;
  allocp[12] = x21 = makeref(&allocp[12]);
  allocp[13] = x18;
  qp = (struct goalrec*)&allocp[0];
  allocp += 14;
  unify(x20, a7);
  a0 = a2;
  a1 = a5;
  a2 = x15;
  a3 = a12;
  a4 = x21;
  execute(gen__lab_5_0);
  goto gen__lab_5_ext_interrupt;
 case functor_v_6:
  x0 = arg(a0, 1);
 gen__code_14_11:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_e)) goto gen__code_14_23;
  x1 = arg(a0, 2);
 gen__code_14_15:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_e)) goto gen__code_14_23;
  x2 = arg(a0, 3);
 gen__code_14_19:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != makesym(atom_e)) goto gen__code_14_23;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__util_xmax_3);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = x4 = makeref(&allocp[3]);
  allocp[4] = a4;
  allocp[5] = makesym(functor_lab_1);
  allocp[6] = x6 = makeref(&allocp[6]);
  x5 = makefunctor(&allocp[5]);
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  x7 = arg(a0, 5);
  allocp[9] = x7;
  allocp[10] = a1;
  allocp[11] = x5;
  allocp[12] = x8 = makeref(&allocp[12]);
  allocp[13] = x4;
  allocp[14] = x9 = makeref(&allocp[14]);
  allocp[15] = a6;
  allocp[16] = x10 = makeref(&allocp[16]);
  allocp[17] = x11 = makeref(&allocp[17]);
  allocp[18] = a9;
  allocp[19] = x12 = makeref(&allocp[19]);
  allocp[20] = a11;
  allocp[21] = x13 = makeref(&allocp[21]);
  allocp[22] = a13;
  allocp[23] = (q)(struct goalrec*)&allocp[7];
  allocp[24] = (q)(&predicate_klic__comp__util_xmax_3);
  allocp[25] = x14 = makeref(&allocp[25]);
  allocp[26] = x15 = makeref(&allocp[26]);
  allocp[27] = x11;
  allocp[28] = makesym(functor_deref_3);
  allocp[29] = x17 = makeref(&allocp[29]);
  allocp[30] = x18 = makeref(&allocp[30]);
  allocp[31] = x6;
  x16 = makefunctor(&allocp[28]);
  allocp[32] = x13;
  allocp[33] = x16;
  x19 = makecons(&allocp[32]);
  allocp[34] = (q)(struct goalrec*)&allocp[23];
  allocp[35] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[36] = x20 = makeref(&allocp[36]);
  allocp[37] = makeint(1L);
  allocp[38] = x9;
  allocp[39] = makesym(functor_label_1);
  allocp[40] = x22 = makeref(&allocp[40]);
  x21 = makefunctor(&allocp[39]);
  allocp[41] = x19;
  allocp[42] = x21;
  x23 = makecons(&allocp[41]);
  qp = (struct goalrec*)&allocp[34];
  allocp += 43;
  unify(x22, x20);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  x24 = arg(a0, 4);
  allocp[2] = x24;
  allocp[3] = x6;
  allocp[4] = makesym(atom_none);
  allocp[5] = x25 = makeref(&allocp[5]);
  allocp[6] = x3;
  allocp[7] = x26 = makeref(&allocp[7]);
  allocp[8] = x20;
  allocp[9] = x10;
  allocp[10] = a8;
  allocp[11] = x15;
  allocp[12] = x27 = makeref(&allocp[12]);
  allocp[13] = x12;
  allocp[14] = x28 = makeref(&allocp[14]);
  allocp[15] = x23;
  allocp[16] = (q)(struct goalrec*)&allocp[0];
  allocp[17] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[18] = a8;
  allocp[19] = makeint(1L);
  allocp[20] = x14;
  allocp[21] = (q)(struct goalrec*)&allocp[16];
  allocp[22] = (q)(&predicate_klic__comp__generate_xadd__info_4);
  allocp[23] = x17;
  allocp[24] = makesym(atom_bound);
  allocp[25] = x29 = makeref(&allocp[25]);
  allocp[26] = x10;
  allocp[27] = makesym(functor_if__ref_2);
  allocp[28] = x17;
  allocp[29] = x22;
  x30 = makefunctor(&allocp[27]);
  allocp[30] = x28;
  allocp[31] = x30;
  x31 = makecons(&allocp[30]);
  allocp[32] = (q)(struct goalrec*)&allocp[21];
  allocp[33] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[34] = x32 = makeref(&allocp[34]);
  allocp[35] = makeint(1L);
  allocp[36] = x26;
  allocp[37] = makesym(functor_label_1);
  allocp[38] = x18;
  x33 = makefunctor(&allocp[37]);
  allocp[39] = x31;
  allocp[40] = x33;
  x34 = makecons(&allocp[39]);
  qp = (struct goalrec*)&allocp[32];
  allocp += 41;
  unify2(x18, x32, x8, x25);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xload__pos_10);
  x35 = arg(a0, 0);
  allocp[2] = x35;
  allocp[3] = x17;
  allocp[4] = a3;
  allocp[5] = x25;
  allocp[6] = x36 = makeref(&allocp[6]);
  allocp[7] = x29;
  allocp[8] = a10;
  allocp[9] = x27;
  allocp[10] = x37 = makeref(&allocp[10]);
  allocp[11] = x34;
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  unify(x36, a7);
  a0 = a2;
  a1 = a5;
  a2 = x32;
  a3 = a12;
  a4 = x37;
  execute(gen__lab_5_0);
  goto gen__lab_5_ext_interrupt;
 case VARREF:
  deref_and_jump(x2,gen__code_14_19);
  *reasonp++ =  x2;
  goto gen__code_14_23;
  };
  goto gen__code_14_23;
 case VARREF:
  deref_and_jump(x1,gen__code_14_15);
  *reasonp++ =  x1;
  goto gen__code_14_23;
  };
  goto gen__code_14_23;
 case VARREF:
  deref_and_jump(x0,gen__code_14_11);
  *reasonp++ =  x0;
  goto gen__code_14_23;
  };
  goto gen__code_14_23;
 default:
  goto gen__code_14_23;
  };
 case VARREF:
  deref_and_jump(a0,gen__code_14_1);
  *reasonp++ =  a0;
  goto gen__code_14_23;
  };
  goto gen__code_14_23;
 gen__code_14_23:
  otherwise(gen__code_14_interrupt);
 gen__code_14_25:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_v_6)) goto gen__code_14_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xgen__code__1_15);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a0;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = a8;
  allocp[12] = a9;
  allocp[13] = a10;
  allocp[14] = a11;
  allocp[15] = a12;
  allocp[16] = a13;
  a0 = arg(a0, 0);
  a1 = a7;
  a2 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 17;
  execute(gen__type__known_3_0);
  goto gen__type__known_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,gen__code_14_25);
  *reasonp++ =  a0;
  goto gen__code_14_interrupt;
  };
  goto gen__code_14_interrupt;
 gen__code_14_ext_interrupt:
  reasonp = 0l;
 gen__code_14_interrupt:
  toppred = &predicate_klic__comp__generate_xgen__code_14;
  goto interrupt_14;
 }

 gen__code__1_15_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20, x21, x22, x23, x24, x25, x26, x27, x28, x29, x30, x31, x32, x33, x34, x35, x36, x37, x38, x39, x40, x41, x42, x43, x44, x45, x46, x47, x48, x49, x50, x51, x52, x53, x54;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  qp = qp->next;
 gen__code__1_15_clear_reason:
  reasonp = reasons;
 gen__code__1_15_0:
 gen__code__1_15_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_no)) goto gen__code__1_15_49;
 gen__code__1_15_5:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_v_6)) goto gen__code__1_15_49;
  x0 = arg(a1, 1);
 gen__code__1_15_8:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_a_5)) goto gen__code__1_15_49;
  x1 = arg(x0, 0);
 gen__code__1_15_11:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto gen__code__1_15_49;
  x2 = arg(x0, 1);
 gen__code__1_15_15:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != makesym(atom_e)) goto gen__code__1_15_49;
  x3 = arg(x0, 4);
 gen__code__1_15_19:
  switch (ptagof(x3)) {
 case ATOMIC:
  if (x3 != makesym(atom_e)) goto gen__code__1_15_49;
  x4 = arg(a1, 2);
 gen__code__1_15_23:
  switch (ptagof(x4)) {
 case ATOMIC:
  if (x4 != makesym(atom_e)) goto gen__code__1_15_49;
  x5 = arg(a1, 3);
 gen__code__1_15_27:
  switch (ptagof(x5)) {
 case ATOMIC:
  if (x5 != makesym(atom_e)) goto gen__code__1_15_49;
  x6 = arg(a1, 4);
 gen__code__1_15_31:
  switch (ptagof(x6)) {
 case ATOMIC:
  if (x6 != makesym(atom_e)) goto gen__code__1_15_49;
  x7 = arg(x0, 3);
 gen__code__1_15_35:
  switch (ptagof(x7)) {
 case ATOMIC:
  if (x7 != makesym(atom_e)) goto gen__code__1_15_39;
  a0 = a1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  a5 = a6;
  a6 = a7;
  a7 = a8;
  a8 = a9;
  a9 = a10;
  a10 = a11;
  a11 = a12;
  a12 = a13;
  a13 = a14;
  execute(gen__code__3_14_0);
  goto gen__code__3_14_ext_interrupt;
 case VARREF:
  deref_and_jump(x7,gen__code__1_15_35);
  *reasonp++ =  x7;
  goto gen__code__1_15_49;
  };
  goto gen__code__1_15_39;
 gen__code__1_15_39:
  gblt_diff(x7,makesym(atom_e),gen__code__1_15_49);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__util_xmax_3);
  allocp[2] = x8 = makeref(&allocp[2]);
  allocp[3] = x9 = makeref(&allocp[3]);
  allocp[4] = a5;
  allocp[5] = makesym(functor_lab_1);
  allocp[6] = x11 = makeref(&allocp[6]);
  x10 = makefunctor(&allocp[5]);
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  x12 = arg(a1, 5);
  allocp[9] = x12;
  allocp[10] = a2;
  allocp[11] = x10;
  allocp[12] = x13 = makeref(&allocp[12]);
  allocp[13] = x9;
  allocp[14] = x14 = makeref(&allocp[14]);
  allocp[15] = a7;
  allocp[16] = x15 = makeref(&allocp[16]);
  allocp[17] = x16 = makeref(&allocp[17]);
  allocp[18] = a10;
  allocp[19] = x17 = makeref(&allocp[19]);
  allocp[20] = a12;
  allocp[21] = x18 = makeref(&allocp[21]);
  allocp[22] = a14;
  allocp[23] = (q)(struct goalrec*)&allocp[7];
  allocp[24] = (q)(&predicate_klic__comp__util_xmax_3);
  allocp[25] = x19 = makeref(&allocp[25]);
  allocp[26] = x20 = makeref(&allocp[26]);
  allocp[27] = x16;
  allocp[28] = (q)(struct goalrec*)&allocp[23];
  allocp[29] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[30] = x21 = makeref(&allocp[30]);
  allocp[31] = makeint(1L);
  allocp[32] = x19;
  allocp[33] = (q)(struct goalrec*)&allocp[28];
  allocp[34] = (q)(&predicate_klic__comp__util_xmax_3);
  allocp[35] = x22 = makeref(&allocp[35]);
  allocp[36] = x23 = makeref(&allocp[36]);
  allocp[37] = x20;
  allocp[38] = makesym(functor_deref_3);
  allocp[39] = x25 = makeref(&allocp[39]);
  allocp[40] = x26 = makeref(&allocp[40]);
  allocp[41] = x11;
  x24 = makefunctor(&allocp[38]);
  allocp[42] = x18;
  allocp[43] = x24;
  x27 = makecons(&allocp[42]);
  allocp[44] = makesym(functor_if__not__ref_2);
  allocp[45] = x25;
  allocp[46] = x11;
  x28 = makefunctor(&allocp[44]);
  allocp[47] = x27;
  allocp[48] = x28;
  x29 = makecons(&allocp[47]);
  allocp[49] = (q)(struct goalrec*)&allocp[33];
  allocp[50] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[51] = x30 = makeref(&allocp[51]);
  allocp[52] = makeint(1L);
  allocp[53] = x14;
  allocp[54] = makesym(functor_label_1);
  allocp[55] = x32 = makeref(&allocp[55]);
  x31 = makefunctor(&allocp[54]);
  allocp[56] = x29;
  allocp[57] = x31;
  x33 = makecons(&allocp[56]);
  qp = (struct goalrec*)&allocp[49];
  allocp += 58;
  unify(x32, x30);
  allocp[0] = makesym(functor_lab_1);
  allocp[1] = x35 = makeref(&allocp[1]);
  x34 = makefunctor(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__generate_xgen__cases_16);
  x36 = arg(x0, 2);
  allocp[4] = x36;
  allocp[5] = x11;
  allocp[6] = x34;
  allocp[7] = x37 = makeref(&allocp[7]);
  allocp[8] = x8;
  allocp[9] = x38 = makeref(&allocp[9]);
  allocp[10] = x30;
  allocp[11] = makesym(atom_int);
  allocp[12] = x25;
  allocp[13] = x39 = makeref(&allocp[13]);
  allocp[14] = a9;
  allocp[15] = x21;
  allocp[16] = x40 = makeref(&allocp[16]);
  allocp[17] = x17;
  allocp[18] = x41 = makeref(&allocp[18]);
  allocp[19] = x33;
  qp = (struct goalrec*)&allocp[2];
  allocp += 20;
  unify(x23, a9);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  allocp[2] = x7;
  allocp[3] = x35;
  allocp[4] = makesym(atom_none);
  allocp[5] = x42 = makeref(&allocp[5]);
  allocp[6] = x37;
  allocp[7] = x43 = makeref(&allocp[7]);
  allocp[8] = x38;
  allocp[9] = x39;
  allocp[10] = a9;
  allocp[11] = x22;
  allocp[12] = x44 = makeref(&allocp[12]);
  allocp[13] = x40;
  allocp[14] = x45 = makeref(&allocp[14]);
  allocp[15] = x41;
  allocp[16] = (q)(struct goalrec*)&allocp[0];
  allocp[17] = (q)(&predicate_klic__comp__generate_xadd__info_4);
  allocp[18] = x25;
  allocp[19] = makesym(atom_int);
  allocp[20] = x46 = makeref(&allocp[20]);
  allocp[21] = x39;
  allocp[22] = makesym(functor_if__not__int_2);
  allocp[23] = x25;
  allocp[24] = x32;
  x47 = makefunctor(&allocp[22]);
  allocp[25] = x45;
  allocp[26] = x47;
  x48 = makecons(&allocp[25]);
  allocp[27] = (q)(struct goalrec*)&allocp[16];
  allocp[28] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[29] = x49 = makeref(&allocp[29]);
  allocp[30] = makeint(1L);
  allocp[31] = x43;
  allocp[32] = makesym(functor_label_1);
  allocp[33] = x26;
  x50 = makefunctor(&allocp[32]);
  allocp[34] = x48;
  allocp[35] = x50;
  x51 = makecons(&allocp[34]);
  qp = (struct goalrec*)&allocp[27];
  allocp += 36;
  unify2(x13, x42, x15, x46);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xload__pos_10);
  x52 = arg(a1, 0);
  allocp[2] = x52;
  allocp[3] = x25;
  allocp[4] = a4;
  allocp[5] = x42;
  allocp[6] = x53 = makeref(&allocp[6]);
  allocp[7] = x46;
  allocp[8] = a11;
  allocp[9] = x44;
  allocp[10] = x54 = makeref(&allocp[10]);
  allocp[11] = x51;
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  unify2(x53, a8, x26, x49);
  a0 = a3;
  a1 = a6;
  a2 = x49;
  a3 = a13;
  a4 = x54;
  execute(gen__lab_5_0);
  goto gen__lab_5_ext_interrupt;
 case VARREF:
  deref_and_jump(x6,gen__code__1_15_31);
  *reasonp++ =  x6;
  goto gen__code__1_15_49;
  };
  goto gen__code__1_15_49;
 case VARREF:
  deref_and_jump(x5,gen__code__1_15_27);
  *reasonp++ =  x5;
  goto gen__code__1_15_49;
  };
  goto gen__code__1_15_49;
 case VARREF:
  deref_and_jump(x4,gen__code__1_15_23);
  *reasonp++ =  x4;
  goto gen__code__1_15_49;
  };
  goto gen__code__1_15_49;
 case VARREF:
  deref_and_jump(x3,gen__code__1_15_19);
  *reasonp++ =  x3;
  goto gen__code__1_15_49;
  };
  goto gen__code__1_15_49;
 case VARREF:
  deref_and_jump(x2,gen__code__1_15_15);
  *reasonp++ =  x2;
  goto gen__code__1_15_49;
  };
  goto gen__code__1_15_49;
 case VARREF:
  deref_and_jump(x1,gen__code__1_15_11);
  *reasonp++ =  x1;
  goto gen__code__1_15_49;
  };
  goto gen__code__1_15_49;
 case VARREF:
  deref_and_jump(x0,gen__code__1_15_8);
  *reasonp++ =  x0;
  goto gen__code__1_15_49;
  };
  goto gen__code__1_15_49;
 case VARREF:
  deref_and_jump(a1,gen__code__1_15_5);
  *reasonp++ =  a1;
  goto gen__code__1_15_49;
  };
  goto gen__code__1_15_49;
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_yes_1)) goto gen__code__1_15_49;
  x0 = arg(a0, 0);
 gen__code__1_15_43:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__3A_2)) goto gen__code__1_15_49;
 gen__code__1_15_46:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_v_6)) goto gen__code__1_15_49;
  allocp[0] = makesym(functor_lab_1);
  allocp[1] = x2 = makeref(&allocp[1]);
  x1 = makefunctor(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  x3 = arg(a1, 5);
  allocp[4] = x3;
  allocp[5] = a2;
  allocp[6] = x1;
  allocp[7] = x4 = makeref(&allocp[7]);
  allocp[8] = a5;
  allocp[9] = x5 = makeref(&allocp[9]);
  allocp[10] = a7;
  allocp[11] = a8;
  allocp[12] = x6 = makeref(&allocp[12]);
  allocp[13] = a10;
  allocp[14] = x7 = makeref(&allocp[14]);
  allocp[15] = a12;
  allocp[16] = x8 = makeref(&allocp[16]);
  allocp[17] = a14;
  allocp[18] = makesym(functor_lab_1);
  allocp[19] = x10 = makeref(&allocp[19]);
  x9 = makefunctor(&allocp[18]);
  allocp[20] = (q)(struct goalrec*)&allocp[2];
  allocp[21] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  x11 = arg(a1, 4);
  allocp[22] = x11;
  allocp[23] = x2;
  allocp[24] = x9;
  allocp[25] = x12 = makeref(&allocp[25]);
  allocp[26] = x4;
  allocp[27] = x13 = makeref(&allocp[27]);
  allocp[28] = x5;
  allocp[29] = a8;
  allocp[30] = x14 = makeref(&allocp[30]);
  allocp[31] = x6;
  allocp[32] = x15 = makeref(&allocp[32]);
  allocp[33] = x7;
  allocp[34] = x16 = makeref(&allocp[34]);
  allocp[35] = x8;
  a0 = arg(x0, 1);
  x17 = arg(a1, 1);
  a2 = x10;
  x18 = arg(x0, 0);
  a5 = a8;
  x19 = a4;
  a7 = a6;
  a8 = a9;
  a9 = a11;
  a10 = a13;
  a11 = x12;
  a12 = x13;
  a13 = x14;
  a14 = x15;
  a15 = x16;
  a16 = arg(a1, 2);
  a17 = arg(a1, 3);
  a6 = x19;
  a4 = x18;
  a1 = x17;
  qp = (struct goalrec*)&allocp[20];
  allocp += 36;
  execute(gen__code__1_2F15_240_18_0);
  goto gen__code__1_2F15_240_18_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,gen__code__1_15_46);
  *reasonp++ =  a1;
  goto gen__code__1_15_49;
  };
  goto gen__code__1_15_49;
 case VARREF:
  deref_and_jump(x0,gen__code__1_15_43);
  *reasonp++ =  x0;
  goto gen__code__1_15_49;
  };
  goto gen__code__1_15_49;
 case VARREF:
  deref_and_jump(a0,gen__code__1_15_1);
  *reasonp++ =  a0;
  goto gen__code__1_15_49;
  };
  goto gen__code__1_15_49;
 gen__code__1_15_49:
  otherwise(gen__code__1_15_interrupt);
 gen__code__1_15_51:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_no)) goto gen__code__1_15_interrupt;
  a0 = a1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  a5 = a6;
  a6 = a7;
  a7 = a8;
  a8 = a9;
  a9 = a10;
  a10 = a11;
  a11 = a12;
  a12 = a13;
  a13 = a14;
  execute(gen__code__3_14_0);
  goto gen__code__3_14_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,gen__code__1_15_51);
  *reasonp++ =  a0;
  goto gen__code__1_15_interrupt;
  };
  goto gen__code__1_15_interrupt;
 gen__code__1_15_ext_interrupt:
  reasonp = 0l;
 gen__code__1_15_interrupt:
  goto interrupt_15;
 }

 gen__code__1_2F15_240_18_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  qp = qp->next;
 gen__code__1_2F15_240_18_clear_reason:
  reasonp = reasons;
 gen__code__1_2F15_240_18_0:
 gen__code__1_2F15_240_18_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto gen__code__1_2F15_240_18_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_atomic)):
  a0 = a1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  a5 = a6;
  a6 = a11;
  x0 = a12;
  x1 = a8;
  x2 = a13;
  a11 = a9;
  a12 = a14;
  a13 = a10;
  a14 = a15;
  a10 = x2;
  a9 = x1;
  a8 = x0;
  execute(gen__atomic_15_0);
  goto gen__atomic_15_ext_interrupt;
 case symval(makesym(atom_list)):
  a0 = a16;
  a1 = a2;
  a2 = a3;
  a3 = a6;
  a4 = a11;
  x0 = a7;
  a6 = a12;
  a7 = a5;
  x1 = a13;
  x2 = a9;
  a11 = a14;
  a12 = a10;
  a13 = a15;
  a10 = x2;
  a9 = x1;
  a5 = x0;
  execute(gen__code_14_0);
  goto gen__code_14_ext_interrupt;
 case symval(makesym(atom_functor)):
  a0 = a17;
  a1 = a2;
  a2 = a3;
  a3 = a6;
  x0 = a11;
  x1 = a7;
  a6 = a12;
  a7 = a4;
  x2 = a5;
  x3 = a8;
  x4 = a13;
  a11 = a9;
  a12 = a14;
  a13 = a10;
  a14 = a15;
  a10 = x4;
  a9 = x3;
  a8 = x2;
  a5 = x1;
  a4 = x0;
  execute(gen__functs_15_0);
  goto gen__functs_15_ext_interrupt;
 default:
  goto gen__code__1_2F15_240_18_interrupt;
  };
 case VARREF:
  deref_and_jump(a0,gen__code__1_2F15_240_18_1);
  *reasonp++ =  a0;
  goto gen__code__1_2F15_240_18_interrupt;
  };
  goto gen__code__1_2F15_240_18_interrupt;
 gen__code__1_2F15_240_18_ext_interrupt:
  reasonp = 0l;
 gen__code__1_2F15_240_18_interrupt:
  toppred = &predicate_klic__comp__generate_xgen__code__1_2F15_240_18;
  goto interrupt_18;
 }

 gen__code__3_14_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20, x21, x22, x23, x24, x25, x26, x27, x28, x29, x30, x31, x32, x33, x34, x35, x36, x37, x38, x39, x40, x41, x42, x43, x44, x45, x46, x47, x48, x49, x50, x51, x52, x53, x54, x55, x56, x57, x58, x59, x60, x61;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  qp = qp->next;
 gen__code__3_14_clear_reason:
  reasonp = reasons;
 gen__code__3_14_0:
 gen__code__3_14_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_v_6)) goto gen__code__3_14_interrupt;
  allocp[0] = NILATOM;
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = x3 = makeref(&allocp[3]);
  x2 = makecons(&allocp[2]);
  allocp[4] = x2;
  allocp[5] = x5 = makeref(&allocp[5]);
  x4 = makecons(&allocp[4]);
  allocp[6] = x4;
  allocp[7] = x7 = makeref(&allocp[7]);
  x6 = makecons(&allocp[6]);
  allocp[8] = x6;
  allocp[9] = x9 = makeref(&allocp[9]);
  x8 = makecons(&allocp[8]);
  allocp[10] = (q)qp;
  allocp[11] = (q)(&predicate_klic__comp__util_xmax__list_2);
  allocp[12] = x8;
  allocp[13] = a4;
  allocp[14] = makesym(functor_lab_1);
  allocp[15] = x11 = makeref(&allocp[15]);
  x10 = makefunctor(&allocp[14]);
  allocp[16] = (q)(struct goalrec*)&allocp[10];
  allocp[17] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  x12 = arg(a0, 5);
  allocp[18] = x12;
  allocp[19] = a1;
  allocp[20] = x10;
  allocp[21] = x13 = makeref(&allocp[21]);
  allocp[22] = x1;
  allocp[23] = x14 = makeref(&allocp[23]);
  allocp[24] = a6;
  allocp[25] = x15 = makeref(&allocp[25]);
  allocp[26] = x16 = makeref(&allocp[26]);
  allocp[27] = a9;
  allocp[28] = x17 = makeref(&allocp[28]);
  allocp[29] = a11;
  allocp[30] = x18 = makeref(&allocp[30]);
  allocp[31] = a13;
  allocp[32] = NILATOM;
  allocp[33] = x20 = makeref(&allocp[33]);
  x19 = makecons(&allocp[32]);
  allocp[34] = x19;
  allocp[35] = x22 = makeref(&allocp[35]);
  x21 = makecons(&allocp[34]);
  allocp[36] = x21;
  allocp[37] = x24 = makeref(&allocp[37]);
  x23 = makecons(&allocp[36]);
  allocp[38] = x23;
  allocp[39] = x26 = makeref(&allocp[39]);
  x25 = makecons(&allocp[38]);
  allocp[40] = x25;
  allocp[41] = x28 = makeref(&allocp[41]);
  x27 = makecons(&allocp[40]);
  allocp[42] = (q)(struct goalrec*)&allocp[16];
  allocp[43] = (q)(&predicate_klic__comp__util_xmax__list_2);
  allocp[44] = x27;
  allocp[45] = x16;
  allocp[46] = (q)(struct goalrec*)&allocp[42];
  allocp[47] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[48] = a8;
  allocp[49] = makeint(1L);
  allocp[50] = x20;
  allocp[51] = makesym(functor_lab_1);
  allocp[52] = x30 = makeref(&allocp[52]);
  x29 = makefunctor(&allocp[51]);
  allocp[53] = (q)(struct goalrec*)&allocp[46];
  allocp[54] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  x31 = arg(a0, 4);
  allocp[55] = x31;
  allocp[56] = x11;
  allocp[57] = x29;
  allocp[58] = x13;
  allocp[59] = x3;
  allocp[60] = x32 = makeref(&allocp[60]);
  allocp[61] = x14;
  allocp[62] = x33 = makeref(&allocp[62]);
  allocp[63] = a8;
  allocp[64] = x22;
  allocp[65] = x34 = makeref(&allocp[65]);
  allocp[66] = x17;
  allocp[67] = x35 = makeref(&allocp[67]);
  allocp[68] = x18;
  allocp[69] = (q)(struct goalrec*)&allocp[53];
  allocp[70] = (q)(&predicate_klic__comp__generate_xadd__info_4);
  allocp[71] = x36 = makeref(&allocp[71]);
  allocp[72] = makesym(atom_bound);
  allocp[73] = x15;
  allocp[74] = x33;
  allocp[75] = makesym(functor_goto_1);
  allocp[76] = x30;
  x37 = makefunctor(&allocp[75]);
  allocp[77] = x35;
  allocp[78] = x37;
  x38 = makecons(&allocp[77]);
  allocp[79] = x38;
  allocp[80] = makesym(atom_end__sw);
  x39 = makecons(&allocp[79]);
  allocp[81] = makesym(functor_deref_3);
  allocp[82] = x36;
  allocp[83] = x41 = makeref(&allocp[83]);
  allocp[84] = x11;
  x40 = makefunctor(&allocp[81]);
  allocp[85] = x39;
  allocp[86] = x40;
  x42 = makecons(&allocp[85]);
  allocp[87] = x42;
  allocp[88] = makefunctor(funct_const_1);
  x43 = makecons(&allocp[87]);
  allocp[89] = (q)(struct goalrec*)&allocp[69];
  allocp[90] = (q)(&predicate_klic__comp__generate_xgen__code__3__3_15);
  x44 = arg(a0, 3);
  allocp[91] = x44;
  allocp[92] = x45 = makeref(&allocp[92]);
  allocp[93] = x32;
  allocp[94] = a8;
  allocp[95] = x24;
  allocp[96] = x46 = makeref(&allocp[96]);
  allocp[97] = x34;
  allocp[98] = x15;
  allocp[99] = x13;
  allocp[100] = x7;
  allocp[101] = x5;
  allocp[102] = x36;
  allocp[103] = x30;
  allocp[104] = x47 = makeref(&allocp[104]);
  allocp[105] = x43;
  allocp[106] = (q)(struct goalrec*)&allocp[89];
  allocp[107] = (q)(&predicate_klic__comp__generate_xgen__code__3__2_15);
  x48 = arg(a0, 1);
  allocp[108] = x48;
  allocp[109] = x49 = makeref(&allocp[109]);
  allocp[110] = x45;
  allocp[111] = a8;
  allocp[112] = x26;
  allocp[113] = x50 = makeref(&allocp[113]);
  allocp[114] = x46;
  allocp[115] = x15;
  allocp[116] = x13;
  allocp[117] = x9;
  allocp[118] = x7;
  allocp[119] = x36;
  allocp[120] = x30;
  allocp[121] = x51 = makeref(&allocp[121]);
  allocp[122] = x47;
  allocp[123] = (q)(struct goalrec*)&allocp[106];
  allocp[124] = (q)(&predicate_klic__comp__generate_xgen__code__3__1_14);
  x52 = arg(a0, 2);
  allocp[125] = x52;
  allocp[126] = x53 = makeref(&allocp[126]);
  allocp[127] = x49;
  allocp[128] = a8;
  allocp[129] = x28;
  allocp[130] = x54 = makeref(&allocp[130]);
  allocp[131] = x50;
  allocp[132] = x15;
  allocp[133] = x13;
  allocp[134] = x9;
  allocp[135] = x36;
  allocp[136] = x30;
  allocp[137] = x55 = makeref(&allocp[137]);
  allocp[138] = x51;
  allocp[139] = makesym(functor_sw__tag_1);
  allocp[140] = x36;
  x56 = makefunctor(&allocp[139]);
  allocp[141] = x55;
  allocp[142] = x56;
  x57 = makecons(&allocp[141]);
  allocp[143] = makesym(functor_label_1);
  allocp[144] = x41;
  x58 = makefunctor(&allocp[143]);
  allocp[145] = x57;
  allocp[146] = x58;
  x59 = makecons(&allocp[145]);
  allocp[147] = (q)(struct goalrec*)&allocp[123];
  allocp[148] = (q)(&predicate_klic__comp__generate_xload__pos_10);
  x60 = arg(a0, 0);
  allocp[149] = x60;
  allocp[150] = x36;
  allocp[151] = a3;
  allocp[152] = x13;
  allocp[153] = a7;
  allocp[154] = x15;
  allocp[155] = a10;
  allocp[156] = x54;
  allocp[157] = x61 = makeref(&allocp[157]);
  allocp[158] = x59;
  allocp[159] = (q)(struct goalrec*)&allocp[147];
  allocp[160] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[161] = a5;
  allocp[162] = makeint(2L);
  allocp[163] = x53;
  a0 = a2;
  a1 = a5;
  a2 = x41;
  a3 = a12;
  a4 = x61;
  qp = (struct goalrec*)&allocp[159];
  allocp += 164;
  execute(gen__lab_5_0);
  goto gen__lab_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,gen__code__3_14_1);
  *reasonp++ =  a0;
  goto gen__code__3_14_interrupt;
  };
  goto gen__code__3_14_interrupt;
 gen__code__3_14_ext_interrupt:
  reasonp = 0l;
 gen__code__3_14_interrupt:
  toppred = &predicate_klic__comp__generate_xgen__code__3_14;
  goto interrupt_14;
 }

 gen__code__3__1_14_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  qp = qp->next;
 gen__code__3__1_14_clear_reason:
  reasonp = reasons;
 gen__code__3__1_14_0:
 gen__code__3__1_14_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_e)) goto gen__code__3__1_14_5;
  unify4(a13, a12, a9, a8, a6, a5, a4, a3);
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,gen__code__3__1_14_1);
  *reasonp++ =  a0;
  goto gen__code__3__1_14_interrupt;
  };
  goto gen__code__3__1_14_5;
 gen__code__3__1_14_5:
  gblt_diff(a0,makesym(atom_e),gen__code__3__1_14_interrupt);
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = makefunctor(funct_const_3);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a12, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  allocp[2] = a0;
  allocp[3] = a11;
  allocp[4] = makesym(atom_none);
  allocp[5] = a8;
  allocp[6] = a9;
  allocp[7] = a1;
  allocp[8] = a2;
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a3;
  allocp[11] = a4;
  allocp[12] = a5;
  allocp[13] = a6;
  allocp[14] = x1;
  allocp[15] = a13;
  a0 = a10;
  a1 = makesym(atom_list);
  a2 = a7;
  a3 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 16;
  execute(add__info_4_0);
  goto add__info_4_ext_interrupt;
 gen__code__3__1_14_ext_interrupt:
  reasonp = 0l;
 gen__code__3__1_14_interrupt:
  goto interrupt_14;
 }

 gen__code__3__2_15_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  qp = qp->next;
 gen__code__3__2_15_clear_reason:
  reasonp = reasons;
 gen__code__3__2_15_0:
 gen__code__3__2_15_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_e)) goto gen__code__3__2_15_5;
  unify4(a14, a13, a10, a9, a6, a5, a4, a3);
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,gen__code__3__2_15_1);
  *reasonp++ =  a0;
  goto gen__code__3__2_15_5;
  };
  goto gen__code__3__2_15_5;
 gen__code__3__2_15_5:
  otherwise(gen__code__3__2_15_interrupt);
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = makefunctor(funct_const_5);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a13, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xgen__atomic_15);
  allocp[2] = a0;
  allocp[3] = a12;
  allocp[4] = makesym(atom_none);
  allocp[5] = a11;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a8;
  allocp[8] = a10;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  allocp[12] = a4;
  allocp[13] = a5;
  allocp[14] = a6;
  allocp[15] = x1;
  allocp[16] = a14;
  a0 = a11;
  a1 = makesym(atom_atomic);
  a2 = a7;
  a3 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 17;
  execute(add__info_4_0);
  goto add__info_4_ext_interrupt;
 gen__code__3__2_15_ext_interrupt:
  reasonp = 0l;
 gen__code__3__2_15_interrupt:
  goto interrupt_15;
 }

 gen__code__3__3_15_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  qp = qp->next;
 gen__code__3__3_15_clear_reason:
  reasonp = reasons;
 gen__code__3__3_15_0:
 gen__code__3__3_15_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_e)) goto gen__code__3__3_15_5;
  unify4(a14, a13, a10, a9, a6, a5, a4, a3);
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,gen__code__3__3_15_1);
  *reasonp++ =  a0;
  goto gen__code__3__3_15_5;
  };
  goto gen__code__3__3_15_5;
 gen__code__3__3_15_5:
  otherwise(gen__code__3__3_15_interrupt);
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = makefunctor(funct_const_7);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a13, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xgen__functs_15);
  allocp[2] = a0;
  allocp[3] = a12;
  allocp[4] = makesym(atom_none);
  allocp[5] = a8;
  allocp[6] = a10;
  allocp[7] = a1;
  allocp[8] = a2;
  allocp[9] = a11;
  allocp[10] = x2 = makeref(&allocp[10]);
  allocp[11] = a3;
  allocp[12] = a4;
  allocp[13] = a5;
  allocp[14] = a6;
  allocp[15] = x1;
  allocp[16] = a14;
  a0 = a11;
  a1 = makesym(atom_functor);
  a2 = a7;
  a3 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 17;
  execute(add__info_4_0);
  goto add__info_4_ext_interrupt;
 gen__code__3__3_15_ext_interrupt:
  reasonp = 0l;
 gen__code__3__3_15_interrupt:
  goto interrupt_15;
 }

 gen__atomic_15_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  qp = qp->next;
 gen__atomic_15_clear_reason:
  reasonp = reasons;
 gen__atomic_15_0:
 gen__atomic_15_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_e)) goto gen__atomic_15_interrupt;
  unify4(a14, a13, a12, a11, a10, a9, a8, a7);
  unify(a6, a5);
  a0 = a2;
  execute(make__label_2_0);
  goto make__label_2_ext_interrupt;
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_a_5)) goto gen__atomic_15_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xgen__atomic_2F15_240_20);
  x0 = arg(a0, 0);
  allocp[2] = x0;
  x1 = arg(a0, 1);
  allocp[3] = x1;
  x2 = arg(a0, 3);
  allocp[4] = x2;
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = a3;
  allocp[7] = a1;
  x4 = arg(a0, 2);
  allocp[8] = x4;
  x5 = arg(a0, 4);
  allocp[9] = x5;
  allocp[10] = a5;
  allocp[11] = a6;
  allocp[12] = x6 = makeref(&allocp[12]);
  allocp[13] = a8;
  allocp[14] = a4;
  allocp[15] = a9;
  allocp[16] = a10;
  allocp[17] = a11;
  allocp[18] = a12;
  allocp[19] = a0;
  allocp[20] = a2;
  allocp[21] = a14;
  a0 = a2;
  a1 = a7;
  a2 = x6;
  a3 = a13;
  a4 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 22;
  execute(gen__lab_5_0);
  goto gen__lab_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,gen__atomic_15_1);
  *reasonp++ =  a0;
  goto gen__atomic_15_interrupt;
  };
  goto gen__atomic_15_interrupt;
 gen__atomic_15_ext_interrupt:
  reasonp = 0l;
 gen__atomic_15_interrupt:
  toppred = &predicate_klic__comp__generate_xgen__atomic_15;
  goto interrupt_15;
 }

 gen__atomic_2F15_240_20_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  a18 = qp->args[18];
  a19 = qp->args[19];
  qp = qp->next;
 gen__atomic_2F15_240_20_clear_reason:
  reasonp = reasons;
 gen__atomic_2F15_240_20_0:
 gen__atomic_2F15_240_20_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != NILATOM) goto gen__atomic_2F15_240_20_5;
  a0 = a1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  a5 = a6;
  a6 = a7;
  a7 = a8;
  a8 = a9;
  a9 = a10;
  a10 = a11;
  a11 = a12;
  a12 = a13;
  a13 = a14;
  a14 = a15;
  a15 = a16;
  a16 = a19;
  execute(gen__atomic_2F15_240_2F20_241_19_0);
  goto gen__atomic_2F15_240_2F20_241_19_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,gen__atomic_2F15_240_20_1);
  *reasonp++ =  a0;
  goto gen__atomic_2F15_240_20_interrupt;
  };
  goto gen__atomic_2F15_240_20_5;
 gen__atomic_2F15_240_20_5:
  gblt_diff(a0,NILATOM,gen__atomic_2F15_240_20_interrupt);
  x0 = a1;
  a1 = a6;
  x1 = a0;
  x2 = a3;
  x3 = a4;
  a6 = a12;
  x4 = a8;
  a8 = a10;
  x5 = a13;
  a10 = a15;
  x6 = a7;
  a12 = a5;
  a13 = a9;
  x7 = a11;
  a15 = a14;
  x8 = a19;
  x9 = a17;
  a19 = a18;
  a18 = x9;
  a17 = x8;
  a14 = x7;
  a11 = x6;
  a9 = x5;
  a7 = x4;
  a5 = x3;
  a4 = x2;
  a3 = x1;
  a0 = x0;
  execute(gen__atomic_2F15_240_2F20_240_20_0);
  goto gen__atomic_2F15_240_2F20_240_20_ext_interrupt;
 gen__atomic_2F15_240_20_ext_interrupt:
  reasonp = 0l;
 gen__atomic_2F15_240_20_interrupt:
  goto interrupt_20;
 }

 gen__atomic_2F15_240_2F20_241_19_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  a18 = qp->args[18];
  qp = qp->next;
 gen__atomic_2F15_240_2F20_241_19_clear_reason:
  reasonp = reasons;
 gen__atomic_2F15_240_2F20_241_19_0:
 gen__atomic_2F15_240_2F20_241_19_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_e)) goto gen__atomic_2F15_240_2F20_241_19_5;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xgen__atomic__2_20);
  allocp[2] = a5;
  allocp[3] = a1;
  allocp[4] = a6;
  allocp[5] = a4;
  allocp[6] = a7;
  allocp[7] = a8;
  allocp[8] = a9;
  allocp[9] = a10;
  allocp[10] = a3;
  allocp[11] = a11;
  allocp[12] = a12;
  allocp[13] = a12;
  allocp[14] = a12;
  allocp[15] = a13;
  allocp[16] = a14;
  allocp[17] = a15;
  allocp[18] = x0 = makeref(&allocp[18]);
  allocp[19] = x1 = makeref(&allocp[19]);
  allocp[20] = x2 = makeref(&allocp[20]);
  allocp[21] = a16;
  a0 = a1;
  a1 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 22;
  execute(gen__atomic_2F15_240_2F20_241_2F19_240_5_0);
  goto gen__atomic_2F15_240_2F20_241_2F19_240_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,gen__atomic_2F15_240_2F20_241_19_1);
  *reasonp++ =  a0;
  goto gen__atomic_2F15_240_2F20_241_19_5;
  };
  goto gen__atomic_2F15_240_2F20_241_19_5;
 gen__atomic_2F15_240_2F20_241_19_5:
  otherwise(gen__atomic_2F15_240_2F20_241_19_interrupt);
  a0 = a17;
  a1 = a4;
  x0 = a18;
  x1 = a7;
  a4 = a8;
  a5 = a9;
  a6 = a10;
  a7 = a3;
  a8 = a11;
  a9 = a12;
  a10 = a13;
  a11 = a14;
  a12 = a15;
  a13 = a2;
  a14 = a16;
  a3 = x1;
  a2 = x0;
  execute(gen__atomic__1_15_0);
  goto gen__atomic__1_15_ext_interrupt;
 gen__atomic_2F15_240_2F20_241_19_ext_interrupt:
  reasonp = 0l;
 gen__atomic_2F15_240_2F20_241_19_interrupt:
  toppred = &predicate_klic__comp__generate_xgen__atomic_2F15_240_2F20_241_19;
  goto interrupt_19;
 }

 gen__atomic_2F15_240_2F20_241_2F19_240_5_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 gen__atomic_2F15_240_2F20_241_2F19_240_5_clear_reason:
  reasonp = reasons;
 gen__atomic_2F15_240_2F20_241_2F19_240_5_0:
 gen__atomic_2F15_240_2F20_241_2F19_240_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_e)) goto gen__atomic_2F15_240_2F20_241_2F19_240_5_5;
  unify(a1, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,gen__atomic_2F15_240_2F20_241_2F19_240_5_1);
  *reasonp++ =  a0;
  goto gen__atomic_2F15_240_2F20_241_2F19_240_5_interrupt;
  };
  goto gen__atomic_2F15_240_2F20_241_2F19_240_5_5;
 gen__atomic_2F15_240_2F20_241_2F19_240_5_5:
  gblt_diff(a0,makesym(atom_e),gen__atomic_2F15_240_2F20_241_2F19_240_5_interrupt);
  allocp[0] = makesym(functor_if__not__int_2);
  allocp[1] = a3;
  allocp[2] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = x0;
  x1 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a2, x1);
  unify(a1, x2);
  proceed();
 gen__atomic_2F15_240_2F20_241_2F19_240_5_ext_interrupt:
  reasonp = 0l;
 gen__atomic_2F15_240_2F20_241_2F19_240_5_interrupt:
  toppred = &predicate_klic__comp__generate_xgen__atomic_2F15_240_2F20_241_2F19_240_5;
  goto interrupt_5;
 }

 gen__atomic_2F15_240_2F20_240_20_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  a18 = qp->args[18];
  a19 = qp->args[19];
  qp = qp->next;
 gen__atomic_2F15_240_2F20_240_20_clear_reason:
  reasonp = reasons;
 gen__atomic_2F15_240_2F20_240_20_0:
 gen__atomic_2F15_240_2F20_240_20_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_e)) goto gen__atomic_2F15_240_2F20_240_20_13;
 gen__atomic_2F15_240_2F20_240_20_5:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != NILATOM) goto gen__atomic_2F15_240_2F20_240_20_13;
 gen__atomic_2F15_240_2F20_240_20_9:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != makesym(atom_e)) goto gen__atomic_2F15_240_2F20_240_20_13;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xgen__atomic__2_20);
  allocp[2] = NILATOM;
  allocp[3] = makesym(atom_e);
  allocp[4] = a11;
  allocp[5] = a12;
  allocp[6] = x0 = makeref(&allocp[6]);
  allocp[7] = a13;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a14;
  allocp[10] = a5;
  allocp[11] = a6;
  allocp[12] = a9;
  allocp[13] = x2 = makeref(&allocp[13]);
  allocp[14] = x2;
  allocp[15] = a15;
  allocp[16] = x3 = makeref(&allocp[16]);
  allocp[17] = a16;
  allocp[18] = x4 = makeref(&allocp[18]);
  allocp[19] = x5 = makeref(&allocp[19]);
  allocp[20] = x6 = makeref(&allocp[20]);
  allocp[21] = a17;
  allocp[22] = (q)(struct goalrec*)&allocp[0];
  allocp[23] = (q)(&predicate_klic__comp__generate_xgen__cases_16);
  allocp[24] = a3;
  allocp[25] = x5;
  allocp[26] = makesym(atom_none);
  allocp[27] = a7;
  allocp[28] = x0;
  allocp[29] = a8;
  allocp[30] = x1;
  allocp[31] = makesym(atom_sym);
  allocp[32] = a5;
  allocp[33] = x7 = makeref(&allocp[33]);
  allocp[34] = a9;
  allocp[35] = x2;
  allocp[36] = a10;
  allocp[37] = x3;
  allocp[38] = x8 = makeref(&allocp[38]);
  allocp[39] = x6;
  allocp[40] = (q)(struct goalrec*)&allocp[22];
  allocp[41] = (q)(&predicate_klic__comp__generate_xadd__info_4);
  allocp[42] = a5;
  allocp[43] = makesym(atom_atom);
  allocp[44] = a6;
  allocp[45] = x7;
  a0 = a3;
  a1 = x8;
  a2 = a4;
  a3 = a5;
  a4 = x5;
  qp = (struct goalrec*)&allocp[40];
  allocp += 46;
  execute(gen__atomic_2F15_240_2F20_240_2F20_240_5_0);
  goto gen__atomic_2F15_240_2F20_240_2F20_240_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,gen__atomic_2F15_240_2F20_240_20_9);
  *reasonp++ =  a2;
  goto gen__atomic_2F15_240_2F20_240_20_13;
  };
  goto gen__atomic_2F15_240_2F20_240_20_13;
 case VARREF:
  deref_and_jump(a1,gen__atomic_2F15_240_2F20_240_20_5);
  *reasonp++ =  a1;
  goto gen__atomic_2F15_240_2F20_240_20_13;
  };
  goto gen__atomic_2F15_240_2F20_240_20_13;
 case VARREF:
  deref_and_jump(a0,gen__atomic_2F15_240_2F20_240_20_1);
  *reasonp++ =  a0;
  goto gen__atomic_2F15_240_2F20_240_20_13;
  };
  goto gen__atomic_2F15_240_2F20_240_20_13;
 gen__atomic_2F15_240_2F20_240_20_13:
  otherwise(gen__atomic_2F15_240_2F20_240_20_interrupt);
  a0 = a18;
  a1 = a12;
  a2 = a19;
  a3 = a7;
  x0 = a13;
  x1 = a8;
  x2 = a14;
  a7 = a5;
  a8 = a6;
  x3 = a15;
  a11 = a10;
  a12 = a16;
  a13 = a4;
  a14 = a17;
  a10 = x3;
  a6 = x2;
  a5 = x1;
  a4 = x0;
  execute(gen__atomic__1_15_0);
  goto gen__atomic__1_15_ext_interrupt;
 gen__atomic_2F15_240_2F20_240_20_ext_interrupt:
  reasonp = 0l;
 gen__atomic_2F15_240_2F20_240_20_interrupt:
  toppred = &predicate_klic__comp__generate_xgen__atomic_2F15_240_2F20_240_20;
  goto interrupt_20;
 }

 gen__atomic_2F15_240_2F20_240_2F20_240_5_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 gen__atomic_2F15_240_2F20_240_2F20_240_5_clear_reason:
  reasonp = reasons;
 gen__atomic_2F15_240_2F20_240_2F20_240_5_0:
 gen__atomic_2F15_240_2F20_240_2F20_240_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = cdr_of(a0);
 gen__atomic_2F15_240_2F20_240_2F20_240_5_3:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != NILATOM) goto gen__atomic_2F15_240_2F20_240_2F20_240_5_7;
  unify(a1, a2);
  proceed();
 case VARREF:
  deref_and_jump(x0,gen__atomic_2F15_240_2F20_240_2F20_240_5_3);
  *reasonp++ =  x0;
  goto gen__atomic_2F15_240_2F20_240_2F20_240_5_7;
  };
  goto gen__atomic_2F15_240_2F20_240_2F20_240_5_7;
 case VARREF:
  deref_and_jump(a0,gen__atomic_2F15_240_2F20_240_2F20_240_5_1);
  *reasonp++ =  a0;
  goto gen__atomic_2F15_240_2F20_240_2F20_240_5_7;
  };
  goto gen__atomic_2F15_240_2F20_240_2F20_240_5_7;
 gen__atomic_2F15_240_2F20_240_2F20_240_5_7:
  otherwise(gen__atomic_2F15_240_2F20_240_2F20_240_5_interrupt);
  allocp[0] = makesym(functor_if__int_2);
  allocp[1] = a3;
  allocp[2] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = x0;
  x1 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a2, x1);
  unify(a1, x2);
  proceed();
 gen__atomic_2F15_240_2F20_240_2F20_240_5_ext_interrupt:
  reasonp = 0l;
 gen__atomic_2F15_240_2F20_240_2F20_240_5_interrupt:
  toppred = &predicate_klic__comp__generate_xgen__atomic_2F15_240_2F20_240_2F20_240_5;
  goto interrupt_5;
 }

 gen__atomic__1_15_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20, x21, x22, x23;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  qp = qp->next;
 gen__atomic__1_15_clear_reason:
  reasonp = reasons;
 gen__atomic__1_15_0:
 gen__atomic__1_15_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_a_5)) goto gen__atomic__1_15_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xgen__atomic__2_20);
  x0 = arg(a0, 2);
  allocp[2] = x0;
  x1 = arg(a0, 3);
  allocp[3] = x1;
  x2 = arg(a0, 4);
  allocp[4] = x2;
  allocp[5] = a1;
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = a4;
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = a8;
  allocp[12] = a9;
  allocp[13] = x5 = makeref(&allocp[13]);
  allocp[14] = x6 = makeref(&allocp[14]);
  allocp[15] = a10;
  allocp[16] = x7 = makeref(&allocp[16]);
  allocp[17] = a12;
  allocp[18] = x8 = makeref(&allocp[18]);
  allocp[19] = x9 = makeref(&allocp[19]);
  allocp[20] = x10 = makeref(&allocp[20]);
  allocp[21] = a14;
  allocp[22] = makesym(functor_lab_1);
  allocp[23] = x12 = makeref(&allocp[23]);
  x11 = makefunctor(&allocp[22]);
  allocp[24] = (q)(struct goalrec*)&allocp[0];
  allocp[25] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  x13 = arg(a0, 1);
  allocp[26] = x13;
  allocp[27] = x9;
  allocp[28] = x11;
  allocp[29] = x14 = makeref(&allocp[29]);
  allocp[30] = x3;
  allocp[31] = x15 = makeref(&allocp[31]);
  allocp[32] = x4;
  allocp[33] = x16 = makeref(&allocp[33]);
  allocp[34] = a9;
  allocp[35] = x6;
  allocp[36] = x17 = makeref(&allocp[36]);
  allocp[37] = x7;
  allocp[38] = x18 = makeref(&allocp[38]);
  allocp[39] = x10;
  allocp[40] = (q)(struct goalrec*)&allocp[24];
  allocp[41] = (q)(&predicate_klic__comp__generate_xgen__cases_16);
  x19 = arg(a0, 0);
  allocp[42] = x19;
  allocp[43] = x12;
  allocp[44] = makesym(atom_none);
  allocp[45] = a3;
  allocp[46] = x14;
  allocp[47] = x20 = makeref(&allocp[47]);
  allocp[48] = x15;
  allocp[49] = makesym(atom_sym);
  allocp[50] = a7;
  allocp[51] = x16;
  allocp[52] = a9;
  allocp[53] = x5;
  allocp[54] = a11;
  allocp[55] = x17;
  allocp[56] = x21 = makeref(&allocp[56]);
  allocp[57] = x18;
  allocp[58] = (q)(struct goalrec*)&allocp[40];
  allocp[59] = (q)(&predicate_klic__comp__generate_xadd__info_4);
  allocp[60] = a7;
  allocp[61] = makesym(atom_atom);
  allocp[62] = a8;
  allocp[63] = x16;
  allocp[64] = makesym(functor_if__int_2);
  allocp[65] = a7;
  allocp[66] = x8;
  x22 = makefunctor(&allocp[64]);
  allocp[67] = x21;
  allocp[68] = x22;
  x23 = makecons(&allocp[67]);
  a0 = a2;
  a1 = a5;
  a2 = x20;
  a3 = a13;
  a4 = x23;
  qp = (struct goalrec*)&allocp[58];
  allocp += 69;
  execute(gen__lab_5_0);
  goto gen__lab_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,gen__atomic__1_15_1);
  *reasonp++ =  a0;
  goto gen__atomic__1_15_interrupt;
  };
  goto gen__atomic__1_15_interrupt;
 gen__atomic__1_15_ext_interrupt:
  reasonp = 0l;
 gen__atomic__1_15_interrupt:
  toppred = &predicate_klic__comp__generate_xgen__atomic__1_15;
  goto interrupt_15;
 }

 gen__atomic__2_20_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  a18 = qp->args[18];
  a19 = qp->args[19];
  qp = qp->next;
 gen__atomic__2_20_clear_reason:
  reasonp = reasons;
 gen__atomic__2_20_0:
  allocp[0] = makesym(functor_lab_1);
  allocp[1] = a17;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x0;
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = a5;
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a7;
  allocp[11] = a9;
  allocp[12] = x3 = makeref(&allocp[12]);
  allocp[13] = a13;
  allocp[14] = x4 = makeref(&allocp[14]);
  allocp[15] = a15;
  allocp[16] = x5 = makeref(&allocp[16]);
  allocp[17] = a19;
  allocp[18] = NILATOM;
  allocp[19] = x7 = makeref(&allocp[19]);
  x6 = makecons(&allocp[18]);
  allocp[20] = x6;
  allocp[21] = x9 = makeref(&allocp[21]);
  x8 = makecons(&allocp[20]);
  allocp[22] = x8;
  allocp[23] = a12;
  x10 = makecons(&allocp[22]);
  allocp[24] = x10;
  allocp[25] = a11;
  x11 = makecons(&allocp[24]);
  allocp[26] = (q)(struct goalrec*)&allocp[2];
  allocp[27] = (q)(&predicate_klic__comp__util_xmax__list_2);
  allocp[28] = x11;
  allocp[29] = x3;
  allocp[30] = makesym(functor_lab_1);
  allocp[31] = x13 = makeref(&allocp[31]);
  x12 = makefunctor(&allocp[30]);
  allocp[32] = (q)(struct goalrec*)&allocp[26];
  allocp[33] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  allocp[34] = a1;
  allocp[35] = a17;
  allocp[36] = x12;
  allocp[37] = x14 = makeref(&allocp[37]);
  allocp[38] = x1;
  allocp[39] = x15 = makeref(&allocp[39]);
  allocp[40] = x2;
  allocp[41] = x16 = makeref(&allocp[41]);
  allocp[42] = a10;
  allocp[43] = x7;
  allocp[44] = x17 = makeref(&allocp[44]);
  allocp[45] = x4;
  allocp[46] = x18 = makeref(&allocp[46]);
  allocp[47] = x5;
  allocp[48] = makesym(functor_lab_1);
  allocp[49] = a16;
  x19 = makefunctor(&allocp[48]);
  allocp[50] = (q)(struct goalrec*)&allocp[32];
  allocp[51] = (q)(&predicate_klic__comp__generate_xgen__cases_16);
  allocp[52] = a0;
  allocp[53] = x13;
  allocp[54] = x19;
  allocp[55] = a4;
  allocp[56] = x14;
  allocp[57] = a6;
  allocp[58] = x15;
  allocp[59] = makesym(atom_int);
  allocp[60] = a8;
  allocp[61] = x16;
  allocp[62] = a10;
  allocp[63] = x9;
  allocp[64] = a14;
  allocp[65] = x17;
  allocp[66] = a18;
  allocp[67] = x18;
  a0 = a8;
  a1 = makesym(atom_int);
  a2 = a9;
  a3 = x16;
  qp = (struct goalrec*)&allocp[50];
  allocp += 68;
  execute(add__info_4_0);
  goto add__info_4_ext_interrupt;
 gen__atomic__2_20_ext_interrupt:
  reasonp = 0l;
 gen__atomic__2_20_interrupt:
  goto interrupt_20;
 }

 gen__functs_15_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  qp = qp->next;
 gen__functs_15_clear_reason:
  reasonp = reasons;
 gen__functs_15_0:
 gen__functs_15_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_e)) goto gen__functs_15_interrupt;
  unify4(a14, a13, a12, a11, a10, a9, a6, a5);
  unify(a4, a3);
  a0 = a2;
  execute(make__label_2_0);
  goto make__label_2_ext_interrupt;
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_f_3)) goto gen__functs_15_interrupt;
  allocp[0] = makesym(functor_lab_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  x2 = arg(a0, 2);
  allocp[4] = x2;
  allocp[5] = a1;
  allocp[6] = x0;
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = a4;
  allocp[9] = x4 = makeref(&allocp[9]);
  allocp[10] = a6;
  allocp[11] = a8;
  allocp[12] = x5 = makeref(&allocp[12]);
  allocp[13] = a10;
  allocp[14] = x6 = makeref(&allocp[14]);
  allocp[15] = a12;
  allocp[16] = x7 = makeref(&allocp[16]);
  allocp[17] = a14;
  allocp[18] = makesym(functor_lab_1);
  allocp[19] = x9 = makeref(&allocp[19]);
  x8 = makefunctor(&allocp[18]);
  allocp[20] = (q)(struct goalrec*)&allocp[2];
  allocp[21] = (q)(&predicate_klic__comp__generate_xgen__gobjs_15);
  x10 = arg(a0, 1);
  allocp[22] = x10;
  allocp[23] = x1;
  allocp[24] = x8;
  allocp[25] = x11 = makeref(&allocp[25]);
  allocp[26] = x3;
  allocp[27] = x12 = makeref(&allocp[27]);
  allocp[28] = x4;
  allocp[29] = a7;
  allocp[30] = a8;
  allocp[31] = x13 = makeref(&allocp[31]);
  allocp[32] = x5;
  allocp[33] = x14 = makeref(&allocp[33]);
  allocp[34] = x6;
  allocp[35] = x15 = makeref(&allocp[35]);
  allocp[36] = x7;
  a0 = arg(a0, 0);
  a1 = x9;
  a4 = x11;
  a6 = x12;
  x16 = a7;
  x17 = a8;
  a10 = a9;
  a12 = a11;
  a14 = a13;
  a15 = x15;
  a13 = x14;
  a11 = x13;
  a9 = x17;
  a8 = x16;
  a7 = makesym(atom_funct);
  qp = (struct goalrec*)&allocp[20];
  allocp += 37;
  execute(gen__cases_16_0);
  goto gen__cases_16_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,gen__functs_15_1);
  *reasonp++ =  a0;
  goto gen__functs_15_interrupt;
  };
  goto gen__functs_15_interrupt;
 gen__functs_15_ext_interrupt:
  reasonp = 0l;
 gen__functs_15_interrupt:
  toppred = &predicate_klic__comp__generate_xgen__functs_15;
  goto interrupt_15;
 }

 gen__gobjs_15_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  qp = qp->next;
 gen__gobjs_15_clear_reason:
  reasonp = reasons;
 gen__gobjs_15_0:
 gen__gobjs_15_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_e)) goto gen__gobjs_15_interrupt;
  unify4(a14, a13, a12, a11, a10, a9, a6, a5);
  unify(a4, a3);
  a0 = a2;
  execute(make__label_2_0);
  goto make__label_2_ext_interrupt;
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_o_2)) goto gen__gobjs_15_interrupt;
  allocp[0] = makesym(functor_lab_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  x2 = arg(a0, 1);
  allocp[4] = x2;
  allocp[5] = a1;
  allocp[6] = x0;
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = a4;
  allocp[9] = x4 = makeref(&allocp[9]);
  allocp[10] = a6;
  allocp[11] = a8;
  allocp[12] = x5 = makeref(&allocp[12]);
  allocp[13] = a10;
  allocp[14] = x6 = makeref(&allocp[14]);
  allocp[15] = a12;
  allocp[16] = x7 = makeref(&allocp[16]);
  allocp[17] = a14;
  allocp[18] = (q)(struct goalrec*)&allocp[2];
  allocp[19] = (q)(&predicate_klic__comp__generate_xgen__classes_15);
  x8 = arg(a0, 0);
  allocp[20] = x8;
  allocp[21] = x1;
  allocp[22] = makesym(atom_none);
  allocp[23] = a3;
  allocp[24] = x3;
  allocp[25] = x9 = makeref(&allocp[25]);
  allocp[26] = x4;
  allocp[27] = a7;
  allocp[28] = a8;
  allocp[29] = a9;
  allocp[30] = x5;
  allocp[31] = a11;
  allocp[32] = x6;
  allocp[33] = x10 = makeref(&allocp[33]);
  allocp[34] = x7;
  allocp[35] = makesym(functor_if__not__gobj_2);
  allocp[36] = a7;
  allocp[37] = a1;
  x11 = makefunctor(&allocp[35]);
  allocp[38] = x10;
  allocp[39] = x11;
  x12 = makecons(&allocp[38]);
  a0 = a2;
  a1 = a5;
  a2 = x9;
  a3 = a13;
  a4 = x12;
  qp = (struct goalrec*)&allocp[18];
  allocp += 40;
  execute(gen__lab_5_0);
  goto gen__lab_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,gen__gobjs_15_1);
  *reasonp++ =  a0;
  goto gen__gobjs_15_interrupt;
  };
  goto gen__gobjs_15_interrupt;
 gen__gobjs_15_ext_interrupt:
  reasonp = 0l;
 gen__gobjs_15_interrupt:
  goto interrupt_15;
 }

 gen__classes_15_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  qp = qp->next;
 gen__classes_15_clear_reason:
  reasonp = reasons;
 gen__classes_15_0:
 gen__classes_15_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 gen__classes_15_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__2D_2)) goto gen__classes_15_interrupt;
  allocp[0] = makesym(functor_lab_1);
  allocp[1] = x2 = makeref(&allocp[1]);
  x1 = makefunctor(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__generate_xgen__classes_15);
  x3 = cdr_of(a0);
  allocp[4] = x3;
  allocp[5] = a1;
  allocp[6] = x1;
  allocp[7] = x4 = makeref(&allocp[7]);
  allocp[8] = a4;
  allocp[9] = x5 = makeref(&allocp[9]);
  allocp[10] = a6;
  allocp[11] = a7;
  allocp[12] = a8;
  allocp[13] = x6 = makeref(&allocp[13]);
  allocp[14] = a10;
  allocp[15] = x7 = makeref(&allocp[15]);
  allocp[16] = a12;
  allocp[17] = x8 = makeref(&allocp[17]);
  allocp[18] = a14;
  allocp[19] = (q)(struct goalrec*)&allocp[2];
  allocp[20] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  x9 = arg(x0, 1);
  allocp[21] = x9;
  allocp[22] = a1;
  allocp[23] = makesym(atom_none);
  allocp[24] = a3;
  allocp[25] = x4;
  allocp[26] = x10 = makeref(&allocp[26]);
  allocp[27] = x5;
  allocp[28] = a8;
  allocp[29] = a9;
  allocp[30] = x6;
  allocp[31] = a11;
  allocp[32] = x7;
  allocp[33] = x11 = makeref(&allocp[33]);
  allocp[34] = x8;
  allocp[35] = makesym(functor_if__not__class_3);
  allocp[36] = a7;
  x13 = arg(x0, 0);
  allocp[37] = x13;
  allocp[38] = x2;
  x12 = makefunctor(&allocp[35]);
  allocp[39] = x11;
  allocp[40] = x12;
  x14 = makecons(&allocp[39]);
  a0 = a2;
  a1 = a5;
  a2 = x10;
  a3 = a13;
  a4 = x14;
  qp = (struct goalrec*)&allocp[19];
  allocp += 41;
  execute(gen__lab_5_0);
  goto gen__lab_5_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,gen__classes_15_3);
  *reasonp++ =  x0;
  goto gen__classes_15_interrupt;
  };
  goto gen__classes_15_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto gen__classes_15_interrupt;
  unify4(a14, a13, a12, a11, a10, a9, a6, a5);
  unify(a4, a3);
  a0 = a2;
  execute(make__label_2_0);
  goto make__label_2_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,gen__classes_15_1);
  *reasonp++ =  a0;
  goto gen__classes_15_interrupt;
  };
  goto gen__classes_15_interrupt;
 gen__classes_15_ext_interrupt:
  reasonp = 0l;
 gen__classes_15_interrupt:
  goto interrupt_15;
 }

 gen__cases_16_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  qp = qp->next;
 gen__cases_16_clear_reason:
  reasonp = reasons;
 gen__cases_16_0:
 gen__cases_16_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 gen__cases_16_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__2D_2)) goto gen__cases_16_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xgen__cases_2F16_240_18);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = a7;
  allocp[4] = a8;
  x2 = arg(x0, 0);
  allocp[5] = x2;
  allocp[6] = a1;
  allocp[7] = a12;
  allocp[8] = a3;
  allocp[9] = x3 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = x4 = makeref(&allocp[11]);
  x5 = arg(x0, 1);
  allocp[12] = x5;
  allocp[13] = a9;
  allocp[14] = a4;
  allocp[15] = a6;
  allocp[16] = a11;
  allocp[17] = a13;
  allocp[18] = a15;
  allocp[19] = a0;
  a0 = a2;
  a1 = a5;
  a2 = x3;
  a3 = a14;
  a4 = x4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 20;
  execute(gen__lab_5_0);
  goto gen__lab_5_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,gen__cases_16_3);
  *reasonp++ =  x0;
  goto gen__cases_16_interrupt;
  };
  goto gen__cases_16_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto gen__cases_16_interrupt;
  unify4(a15, a14, a13, a12, a11, a10, a6, a5);
  unify(a4, a3);
  a0 = a2;
  execute(make__label_2_0);
  goto make__label_2_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,gen__cases_16_1);
  *reasonp++ =  a0;
  goto gen__cases_16_interrupt;
  };
  goto gen__cases_16_interrupt;
 gen__cases_16_ext_interrupt:
  reasonp = 0l;
 gen__cases_16_interrupt:
  toppred = &predicate_klic__comp__generate_xgen__cases_16;
  goto interrupt_16;
 }

 gen__cases_2F16_240_18_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  a15 = qp->args[15];
  a16 = qp->args[16];
  a17 = qp->args[17];
  qp = qp->next;
 gen__cases_2F16_240_18_clear_reason:
  reasonp = reasons;
 gen__cases_2F16_240_18_0:
 gen__cases_2F16_240_18_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != NILATOM) goto gen__cases_2F16_240_18_5;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  allocp[2] = a10;
  allocp[3] = a4;
  allocp[4] = makesym(atom_none);
  allocp[5] = x0 = makeref(&allocp[5]);
  allocp[6] = a12;
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = a13;
  allocp[9] = a11;
  allocp[10] = x2 = makeref(&allocp[10]);
  allocp[11] = a14;
  allocp[12] = x3 = makeref(&allocp[12]);
  allocp[13] = a15;
  allocp[14] = x4 = makeref(&allocp[14]);
  allocp[15] = a16;
  allocp[16] = x4;
  allocp[17] = x6 = makeref(&allocp[17]);
  x5 = makecons(&allocp[16]);
  a0 = a1;
  a1 = x6;
  x7 = a6;
  x8 = a7;
  a10 = x2;
  a11 = a8;
  a12 = x3;
  a13 = x5;
  a14 = a9;
  a9 = x8;
  a8 = x1;
  a7 = x7;
  a6 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 18;
  execute(gen__cases_2F16_240_2F18_241_15_0);
  goto gen__cases_2F16_240_2F18_241_15_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,gen__cases_2F16_240_18_1);
  *reasonp++ =  a0;
  goto gen__cases_2F16_240_18_interrupt;
  };
  goto gen__cases_2F16_240_18_5;
 gen__cases_2F16_240_18_5:
  gblt_diff(a0,NILATOM,gen__cases_2F16_240_18_interrupt);
  allocp[0] = a16;
  allocp[1] = makesym(atom_end__sw);
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__generate_xgen__all__cases_14);
  allocp[4] = a17;
  allocp[5] = a4;
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = a12;
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = a13;
  allocp[10] = a1;
  allocp[11] = a11;
  allocp[12] = x3 = makeref(&allocp[12]);
  allocp[13] = a14;
  allocp[14] = x4 = makeref(&allocp[14]);
  allocp[15] = a15;
  allocp[16] = x5 = makeref(&allocp[16]);
  allocp[17] = x0;
  allocp[18] = x5;
  allocp[19] = x7 = makeref(&allocp[19]);
  x6 = makecons(&allocp[18]);
  a0 = a1;
  a1 = x7;
  a3 = x1;
  a4 = a6;
  a6 = a7;
  a7 = x3;
  a10 = a5;
  a11 = x6;
  a12 = a9;
  a9 = x4;
  a5 = x2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 20;
  execute(gen__cases_2F16_240_2F18_240_13_0);
  goto gen__cases_2F16_240_2F18_240_13_ext_interrupt;
 gen__cases_2F16_240_18_ext_interrupt:
  reasonp = 0l;
 gen__cases_2F16_240_18_interrupt:
  goto interrupt_18;
 }

 gen__cases_2F16_240_2F18_241_15_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  a14 = qp->args[14];
  qp = qp->next;
 gen__cases_2F16_240_2F18_241_15_clear_reason:
  reasonp = reasons;
 gen__cases_2F16_240_2F18_241_15_0:
 gen__cases_2F16_240_2F18_241_15_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto gen__cases_2F16_240_2F18_241_15_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_sym)):
  allocp[0] = makesym(functor_atom_1);
  allocp[1] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_if__not_3);
  allocp[3] = a2;
  allocp[4] = x0;
  allocp[5] = a4;
  x1 = makefunctor(&allocp[2]);
  allocp += 6;
  unify_value(a1, x1);
  allocp[0] = makesym(functor_atom_1);
  allocp[1] = a3;
  x2 = makefunctor(&allocp[0]);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = x2;
  x3 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a5, x3);
  unify4(a6, a7, a8, a9, a10, a11, a12, x4);
  unify(a13, a14);
  proceed();
 case symval(makesym(atom_int)):
  allocp[0] = makesym(functor_int_1);
  allocp[1] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_if__not_3);
  allocp[3] = a2;
  allocp[4] = x0;
  allocp[5] = a4;
  x1 = makefunctor(&allocp[2]);
  allocp += 6;
  unify_value(a1, x1);
  unify4(a6, a7, a8, a9, a10, a11, a12, a5);
  unify(a13, a14);
  proceed();
 case symval(makesym(atom_funct)):
  allocp[0] = makesym(functor_if__funct__not_3);
  allocp[1] = a2;
  allocp[2] = a3;
  allocp[3] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a1, x0);
  allocp[0] = makesym(functor_funct_1);
  allocp[1] = a3;
  x1 = makefunctor(&allocp[0]);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = x1;
  x2 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a5, x2);
  unify4(a6, a7, a8, a9, a10, a11, a12, x3);
  unify(a13, a14);
  proceed();
 default:
  goto gen__cases_2F16_240_2F18_241_15_interrupt;
  };
 case VARREF:
  deref_and_jump(a0,gen__cases_2F16_240_2F18_241_15_1);
  *reasonp++ =  a0;
  goto gen__cases_2F16_240_2F18_241_15_interrupt;
  };
  goto gen__cases_2F16_240_2F18_241_15_interrupt;
 gen__cases_2F16_240_2F18_241_15_ext_interrupt:
  reasonp = 0l;
 gen__cases_2F16_240_2F18_241_15_interrupt:
  toppred = &predicate_klic__comp__generate_xgen__cases_2F16_240_2F18_241_15;
  goto interrupt_15;
 }

 gen__cases_2F16_240_2F18_240_13_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  qp = qp->next;
 gen__cases_2F16_240_2F18_240_13_clear_reason:
  reasonp = reasons;
 gen__cases_2F16_240_2F18_240_13_0:
 gen__cases_2F16_240_2F18_240_13_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto gen__cases_2F16_240_2F18_240_13_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_sym)):
  allocp[0] = makesym(functor_sw__sym_1);
  allocp[1] = a2;
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  unify4(a3, a4, a5, a6, a7, a8, a9, a10);
  unify(a11, a12);
  proceed();
 case symval(makesym(atom_int)):
  allocp[0] = makesym(functor_sw__int_1);
  allocp[1] = a2;
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  unify4(a3, a4, a5, a6, a7, a8, a9, a10);
  unify(a11, a12);
  proceed();
 case symval(makesym(atom_funct)):
  allocp[0] = makesym(functor_sw__funct_1);
  allocp[1] = a2;
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  unify4(a3, a4, a5, a6, a7, a8, a9, a10);
  unify(a11, a12);
  proceed();
 default:
  goto gen__cases_2F16_240_2F18_240_13_interrupt;
  };
 case VARREF:
  deref_and_jump(a0,gen__cases_2F16_240_2F18_240_13_1);
  *reasonp++ =  a0;
  goto gen__cases_2F16_240_2F18_240_13_interrupt;
  };
  goto gen__cases_2F16_240_2F18_240_13_interrupt;
 gen__cases_2F16_240_2F18_240_13_ext_interrupt:
  reasonp = 0l;
 gen__cases_2F16_240_2F18_240_13_interrupt:
  toppred = &predicate_klic__comp__generate_xgen__cases_2F16_240_2F18_240_13;
  goto interrupt_13;
 }

 gen__all__cases_14_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  qp = qp->next;
 gen__all__cases_14_clear_reason:
  reasonp = reasons;
 gen__all__cases_14_0:
 gen__all__cases_14_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 gen__all__cases_14_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__2D_2)) goto gen__all__cases_14_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__util_xmax_3);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a3;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_klic__comp__util_xmax_3);
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = (q)(struct goalrec*)&allocp[5];
  allocp[11] = (q)(&predicate_klic__comp__generate_xgen__all__cases_14);
  x5 = cdr_of(a0);
  allocp[12] = x5;
  allocp[13] = a1;
  allocp[14] = x6 = makeref(&allocp[14]);
  allocp[15] = x2;
  allocp[16] = x7 = makeref(&allocp[16]);
  allocp[17] = a5;
  allocp[18] = a6;
  allocp[19] = a7;
  allocp[20] = x8 = makeref(&allocp[20]);
  allocp[21] = x4;
  allocp[22] = x9 = makeref(&allocp[22]);
  allocp[23] = a11;
  allocp[24] = x10 = makeref(&allocp[24]);
  allocp[25] = a13;
  allocp[26] = (q)(struct goalrec*)&allocp[10];
  allocp[27] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  x11 = arg(x0, 1);
  allocp[28] = x11;
  allocp[29] = a1;
  allocp[30] = makesym(atom_none);
  allocp[31] = x12 = makeref(&allocp[31]);
  allocp[32] = x1;
  allocp[33] = x13 = makeref(&allocp[33]);
  allocp[34] = x7;
  allocp[35] = a7;
  allocp[36] = x14 = makeref(&allocp[36]);
  allocp[37] = x3;
  allocp[38] = x15 = makeref(&allocp[38]);
  allocp[39] = x9;
  allocp[40] = x16 = makeref(&allocp[40]);
  allocp[41] = x10;
  qp = (struct goalrec*)&allocp[26];
  allocp += 42;
  unify2(x6, x12, x8, x14);
  allocp[0] = x16;
  allocp[1] = x18 = makeref(&allocp[1]);
  x17 = makecons(&allocp[0]);
  a0 = a6;
  a1 = x18;
  x19 = arg(x0, 0);
  a3 = a10;
  a5 = a2;
  a6 = x13;
  a7 = a4;
  a9 = a8;
  a10 = x15;
  a11 = x17;
  a8 = x14;
  a4 = x12;
  a2 = x19;
  allocp += 2;
  execute(gen__all__cases_2F14_240_13_0);
  goto gen__all__cases_2F14_240_13_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,gen__all__cases_14_3);
  *reasonp++ =  x0;
  goto gen__all__cases_14_interrupt;
  };
  goto gen__all__cases_14_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto gen__all__cases_14_interrupt;
  unify4(a11, a10, a9, a8, a5, a4, a3, a2);
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = makesym(atom_case__default);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a12, x0);
  allocp[0] = makesym(functor_goto_1);
  allocp[1] = a1;
  x2 = makefunctor(&allocp[0]);
  allocp[2] = a13;
  allocp[3] = x2;
  x3 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(x1, x3);
  proceed();
 case VARREF:
  deref_and_jump(a0,gen__all__cases_14_1);
  *reasonp++ =  a0;
  goto gen__all__cases_14_interrupt;
  };
  goto gen__all__cases_14_interrupt;
 gen__all__cases_14_ext_interrupt:
  reasonp = 0l;
 gen__all__cases_14_interrupt:
  goto interrupt_14;
 }

 gen__all__cases_2F14_240_13_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  qp = qp->next;
 gen__all__cases_2F14_240_13_clear_reason:
  reasonp = reasons;
 gen__all__cases_2F14_240_13_0:
 gen__all__cases_2F14_240_13_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto gen__all__cases_2F14_240_13_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_sym)):
  allocp[0] = makesym(functor_case__sym_1);
  allocp[1] = a2;
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = makesym(functor_atom_1);
  allocp[1] = a2;
  x1 = makefunctor(&allocp[0]);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = x1;
  x2 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a3, x2);
  unify4(a4, a5, a6, a7, a8, a9, a10, x3);
  unify(a11, a12);
  proceed();
 case symval(makesym(atom_int)):
  allocp[0] = makesym(functor_case__int_1);
  allocp[1] = a2;
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  unify4(a4, a5, a6, a7, a8, a9, a10, a3);
  unify(a11, a12);
  proceed();
 case symval(makesym(atom_funct)):
  allocp[0] = makesym(functor_case__funct_1);
  allocp[1] = a2;
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = makesym(functor_funct_1);
  allocp[1] = a2;
  x1 = makefunctor(&allocp[0]);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = x1;
  x2 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a3, x2);
  unify4(a4, a5, a6, a7, a8, a9, a10, x3);
  unify(a11, a12);
  proceed();
 default:
  goto gen__all__cases_2F14_240_13_interrupt;
  };
 case VARREF:
  deref_and_jump(a0,gen__all__cases_2F14_240_13_1);
  *reasonp++ =  a0;
  goto gen__all__cases_2F14_240_13_interrupt;
  };
  goto gen__all__cases_2F14_240_13_interrupt;
 gen__all__cases_2F14_240_13_ext_interrupt:
  reasonp = 0l;
 gen__all__cases_2F14_240_13_interrupt:
  toppred = &predicate_klic__comp__generate_xgen__all__cases_2F14_240_13;
  goto interrupt_13;
 }

 gen__lab_5_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 gen__lab_5_clear_reason:
  reasonp = reasons;
 gen__lab_5_0:
 gen__lab_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_none)) goto gen__lab_5_interrupt;
  unify(a4, a3);
  bblt_add_no_check_y(a1,makeint(1L),x0);
  unify(a2, x0);
  proceed();
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_lab_1)) goto gen__lab_5_interrupt;
  bblt_add_no_check_y(a1,makeint(1L),x0);
  unify(a2, x0);
  x1 = arg(a0, 0);
  unify(x1, a1);
  allocp[0] = makesym(functor_label_1);
  allocp[1] = a1;
  x2 = makefunctor(&allocp[0]);
  allocp[2] = a4;
  allocp[3] = x2;
  x3 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a3, x3);
  proceed();
 case VARREF:
  deref_and_jump(a0,gen__lab_5_1);
  *reasonp++ =  a0;
  goto gen__lab_5_interrupt;
  };
  goto gen__lab_5_interrupt;
 gen__lab_5_ext_interrupt:
  reasonp = 0l;
 gen__lab_5_interrupt:
  toppred = &predicate_klic__comp__generate_xgen__lab_5;
  goto interrupt_5;
 }

 gen__type__known_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 gen__type__known_3_clear_reason:
  reasonp = reasons;
 gen__type__known_3_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xbasic__type_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a2;
  x1 = a1;
  a1 = a0;
  a2 = x0;
  a0 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  execute(assocx_3_0);
  goto assocx_3_ext_interrupt;
 gen__type__known_3_ext_interrupt:
  reasonp = 0l;
 gen__type__known_3_interrupt:
  toppred = &predicate_klic__comp__generate_xgen__type__known_3;
  goto interrupt_3;
 }

 basic__type_2_top: {
  q x0, x1, x2;
  qp = qp->next;
 basic__type_2_clear_reason:
  reasonp = reasons;
 basic__type_2_0:
 basic__type_2_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_yes_1)) goto basic__type_2_19;
  x0 = arg(a0, 0);
 basic__type_2_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__3A_2)) goto basic__type_2_19;
  x1 = arg(x0, 1);
 basic__type_2_7:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (isint(x1)) goto basic__type_2_19;
  switch (symval(x1)) {
 case symval(makesym(atom_atom)):
  a0 = makesym(atom_atomic);
  x2 = arg(x0, 0);
  a2 = a1;
  a1 = x2;
  execute(is__basic_3_0);
  goto is__basic_3_ext_interrupt;
 case symval(makesym(atom_int)):
  a0 = makesym(atom_atomic);
  x2 = arg(x0, 0);
  a2 = a1;
  a1 = x2;
  execute(is__basic_3_0);
  goto is__basic_3_ext_interrupt;
 case symval(makesym(atom_atomic)):
  a0 = makesym(atom_atomic);
  x2 = arg(x0, 0);
  a2 = a1;
  a1 = x2;
  execute(is__basic_3_0);
  goto is__basic_3_ext_interrupt;
 case symval(makesym(atom_functor)):
  a0 = makesym(atom_functor);
  x2 = arg(x0, 0);
  a2 = a1;
  a1 = x2;
  execute(is__basic_3_0);
  goto is__basic_3_ext_interrupt;
 case symval(makesym(atom_list)):
  a0 = makesym(atom_list);
  x2 = arg(x0, 0);
  a2 = a1;
  a1 = x2;
  execute(is__basic_3_0);
  goto is__basic_3_ext_interrupt;
 default:
  goto basic__type_2_19;
  };
 case FUNCTOR:
  switch (symval(functor_of(x1))) {
 case functor_atom_1:
  a0 = makesym(atom_atomic);
  x2 = arg(x0, 0);
  a2 = a1;
  a1 = x2;
  execute(is__basic_3_0);
  goto is__basic_3_ext_interrupt;
 case functor_functor_1:
  a0 = makesym(atom_functor);
  x2 = arg(x0, 0);
  a2 = a1;
  a1 = x2;
  execute(is__basic_3_0);
  goto is__basic_3_ext_interrupt;
 case functor_functor_2:
  a0 = makesym(atom_functor);
  x2 = arg(x0, 0);
  a2 = a1;
  a1 = x2;
  execute(is__basic_3_0);
  goto is__basic_3_ext_interrupt;
 default:
  goto basic__type_2_19;
  };
 case VARREF:
  deref_and_jump(x1,basic__type_2_7);
  *reasonp++ =  x1;
  goto basic__type_2_19;
  };
  goto basic__type_2_19;
 case VARREF:
  deref_and_jump(x0,basic__type_2_4);
  *reasonp++ =  x0;
  goto basic__type_2_19;
  };
  goto basic__type_2_19;
 case VARREF:
  deref_and_jump(a0,basic__type_2_1);
  *reasonp++ =  a0;
  goto basic__type_2_19;
  };
  goto basic__type_2_19;
 basic__type_2_19:
  otherwise(basic__type_2_interrupt);
  unify_value(a1, makesym(atom_no));
  proceed();
 basic__type_2_ext_interrupt:
  reasonp = 0l;
 basic__type_2_interrupt:
  goto interrupt_2;
 }

 is__basic_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 is__basic_3_clear_reason:
  reasonp = reasons;
 is__basic_3_0:
  allocp[0] = makesym(functor__3A_2);
  allocp[1] = a1;
  allocp[2] = a0;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_yes_1);
  allocp[4] = x0;
  x1 = makefunctor(&allocp[3]);
  allocp += 5;
  unify_value(a2, x1);
  proceed();
 is__basic_3_ext_interrupt:
  reasonp = 0l;
 is__basic_3_interrupt:
  toppred = &predicate_klic__comp__generate_xis__basic_3;
  goto interrupt_3;
 }

 gen__cond_12_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20, x21, x22, x23, x24, x25, x26, x27, x28, x29, x30, x31, x32, x33;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 gen__cond_12_clear_reason:
  reasonp = reasons;
 gen__cond_12_0:
 gen__cond_12_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_gp_1:
  x0 = arg(a0, 0);
 gen__cond_12_4:
  if (isref(x0)) goto gen__cond_12_8;
  gblt_pfunctor(x0,x1,gen__cond_12_interrupt);
  gblt_arity(x0,x2,gen__cond_12_interrupt);
  unify(a7, a6);
  allocp[0] = makesym(functor_gblt__pred_4);
  allocp[1] = x1;
  allocp[2] = x2;
  allocp[3] = x4 = makeref(&allocp[3]);
  allocp[4] = a1;
  x3 = makefunctor(&allocp[0]);
  allocp[5] = a11;
  allocp[6] = x3;
  x5 = makecons(&allocp[5]);
  allocp[7] = (q)qp;
  allocp[8] = (q)(&predicate_klic__comp__generate_xstrip__types_2);
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = x4;
  allocp[11] = (q)(struct goalrec*)&allocp[7];
  allocp[12] = (q)(&predicate_klic__comp__generate_xprep__poss_10);
  allocp[13] = x7 = makeref(&allocp[13]);
  allocp[14] = x6;
  allocp[15] = a2;
  allocp[16] = a3;
  allocp[17] = a4;
  allocp[18] = a5;
  allocp[19] = a8;
  allocp[20] = a9;
  allocp[21] = a10;
  allocp[22] = x5;
  allocp[23] = x7;
  allocp[24] = x9 = makeref(&allocp[24]);
  x8 = makecons(&allocp[23]);
  allocp[25] = (q)(struct goalrec*)&allocp[11];
  allocp[26] = (q)(&predicate_klic__comp__util_xuniv_2);
  allocp[27] = x0;
  allocp[28] = x8;
  qp = (struct goalrec*)&allocp[25];
  allocp += 29;
  proceed();
 gen__cond_12_8:
  deref_and_jump(x0,gen__cond_12_4);
  *reasonp++ =  x0;
  goto gen__cond_12_interrupt;
 case functor_gb_2:
  x0 = arg(a0, 0);
 gen__cond_12_10:
  if (isref(x0)) goto gen__cond_12_14;
  gblt_pfunctor(x0,x1,gen__cond_12_interrupt);
  gblt_arity(x0,x2,gen__cond_12_interrupt);
  unify(a7, a6);
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a2;
  x3 = makefunctor(&allocp[0]);
  bblt_add_no_check_y(a2,makeint(1L),x4);
  allocp[2] = makesym(functor_gb_1);
  allocp[3] = x0;
  x5 = makefunctor(&allocp[2]);
  allocp[4] = makesym(functor__3A_2);
  allocp[5] = x3;
  x7 = arg(a0, 1);
  allocp[6] = x7;
  x6 = makefunctor(&allocp[4]);
  allocp[7] = makesym(functor__3D_2);
  allocp[8] = x5;
  allocp[9] = x6;
  x8 = makefunctor(&allocp[7]);
  allocp[10] = x10 = makeref(&allocp[10]);
  allocp[11] = x8;
  x9 = makecons(&allocp[10]);
  allocp += 12;
  unify_value(a5, x9);
  allocp[0] = makesym(functor_gblt__pred_4);
  allocp[1] = x1;
  allocp[2] = x2;
  allocp[3] = x12 = makeref(&allocp[3]);
  allocp[4] = a1;
  x11 = makefunctor(&allocp[0]);
  allocp[5] = a11;
  allocp[6] = x11;
  x13 = makecons(&allocp[5]);
  allocp[7] = makesym(functor_r_1);
  allocp[8] = x3;
  x14 = makefunctor(&allocp[7]);
  allocp[9] = NILATOM;
  allocp[10] = x14;
  x15 = makecons(&allocp[9]);
  allocp[11] = (q)qp;
  allocp[12] = (q)(&predicate_klic__comp__util_xappend_3);
  allocp[13] = x16 = makeref(&allocp[13]);
  allocp[14] = x15;
  allocp[15] = x12;
  allocp[16] = (q)(struct goalrec*)&allocp[11];
  allocp[17] = (q)(&predicate_klic__comp__generate_xstrip__types_2);
  allocp[18] = x17 = makeref(&allocp[18]);
  allocp[19] = x16;
  allocp[20] = (q)(struct goalrec*)&allocp[16];
  allocp[21] = (q)(&predicate_klic__comp__generate_xprep__poss_10);
  allocp[22] = x18 = makeref(&allocp[22]);
  allocp[23] = x17;
  allocp[24] = x4;
  allocp[25] = a3;
  allocp[26] = a4;
  allocp[27] = x10;
  allocp[28] = a8;
  allocp[29] = a9;
  allocp[30] = a10;
  allocp[31] = x13;
  allocp[32] = x18;
  allocp[33] = x20 = makeref(&allocp[33]);
  x19 = makecons(&allocp[32]);
  allocp[34] = (q)(struct goalrec*)&allocp[20];
  allocp[35] = (q)(&predicate_klic__comp__util_xuniv_2);
  allocp[36] = x0;
  allocp[37] = x19;
  qp = (struct goalrec*)&allocp[34];
  allocp += 38;
  proceed();
 gen__cond_12_14:
  deref_and_jump(x0,gen__cond_12_10);
  *reasonp++ =  x0;
  goto gen__cond_12_interrupt;
 case functor_gg_2:
  x0 = arg(a0, 0);
 gen__cond_12_16:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_gg_3)) goto gen__cond_12_interrupt;
  x1 = arg(x0, 0);
 gen__cond_12_19:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor__2F_2)) goto gen__cond_12_interrupt;
  unify(a7, a6);
  allocp[0] = makesym(functor__2F_2);
  x3 = arg(x1, 0);
  allocp[1] = x3;
  allocp[2] = x4 = makeref(&allocp[2]);
  x2 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_funct_1);
  allocp[4] = x2;
  x5 = makefunctor(&allocp[3]);
  allocp[5] = x7 = makeref(&allocp[5]);
  allocp[6] = x5;
  x6 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a8, x6);
  allocp[0] = makesym(functor__2F_2);
  allocp[1] = x3;
  x9 = arg(x1, 1);
  allocp[2] = x9;
  x8 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_gg_3);
  allocp[4] = x8;
  x11 = arg(x0, 1);
  allocp[5] = x11;
  x12 = arg(x0, 2);
  allocp[6] = x12;
  x10 = makefunctor(&allocp[3]);
  allocp[7] = (q)qp;
  allocp[8] = (q)(&predicate_klic__comp__generate_xload__guard__generic__out_11);
  allocp[9] = x13 = makeref(&allocp[9]);
  allocp[10] = x4;
  allocp[11] = x10;
  allocp[12] = x14 = makeref(&allocp[12]);
  allocp[13] = a3;
  allocp[14] = x15 = makeref(&allocp[14]);
  allocp[15] = a5;
  allocp[16] = x16 = makeref(&allocp[16]);
  allocp[17] = a9;
  allocp[18] = x17 = makeref(&allocp[18]);
  allocp[19] = a11;
  allocp[20] = makesym(functor_r_1);
  allocp[21] = x19 = makeref(&allocp[21]);
  x18 = makefunctor(&allocp[20]);
  allocp[22] = makesym(functor__2F_2);
  allocp[23] = x3;
  allocp[24] = x4;
  x20 = makefunctor(&allocp[22]);
  allocp[25] = makesym(functor_guard__generic_4);
  allocp[26] = x18;
  allocp[27] = x20;
  allocp[28] = x13;
  allocp[29] = a1;
  x21 = makefunctor(&allocp[25]);
  allocp[30] = x17;
  allocp[31] = x21;
  x22 = makecons(&allocp[30]);
  allocp[32] = (q)(struct goalrec*)&allocp[7];
  allocp[33] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  allocp[34] = x23 = makeref(&allocp[34]);
  allocp[35] = makeint(1L);
  allocp[36] = x4;
  allocp[37] = (q)(struct goalrec*)&allocp[32];
  allocp[38] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[39] = x9;
  x24 = arg(a0, 1);
  allocp[40] = x24;
  allocp[41] = x23;
  allocp[42] = (q)(struct goalrec*)&allocp[37];
  allocp[43] = (q)(&predicate_klic__comp__util_xlength_2);
  allocp[44] = x25 = makeref(&allocp[44]);
  allocp[45] = x13;
  allocp[46] = (q)(struct goalrec*)&allocp[42];
  allocp[47] = (q)(&predicate_klic__comp__generate_xload__pos_10);
  allocp[48] = x11;
  allocp[49] = x19;
  allocp[50] = x26 = makeref(&allocp[50]);
  allocp[51] = x14;
  allocp[52] = x27 = makeref(&allocp[52]);
  allocp[53] = x15;
  allocp[54] = x28 = makeref(&allocp[54]);
  allocp[55] = x16;
  allocp[56] = x29 = makeref(&allocp[56]);
  allocp[57] = x22;
  allocp[58] = (q)(struct goalrec*)&allocp[46];
  allocp[59] = (q)(&predicate_klic__comp__generate_xset__generic__args_10);
  allocp[60] = x25;
  allocp[61] = makeint(0L);
  allocp[62] = x30 = makeref(&allocp[62]);
  allocp[63] = x26;
  allocp[64] = x31 = makeref(&allocp[64]);
  allocp[65] = x27;
  allocp[66] = x32 = makeref(&allocp[66]);
  allocp[67] = x28;
  allocp[68] = x33 = makeref(&allocp[68]);
  allocp[69] = x29;
  a0 = x12;
  a1 = x25;
  a3 = x30;
  a5 = x31;
  a6 = x7;
  a7 = x32;
  a8 = a10;
  a9 = x33;
  qp = (struct goalrec*)&allocp[58];
  allocp += 70;
  execute(prep__poss_10_0);
  goto prep__poss_10_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,gen__cond_12_19);
  *reasonp++ =  x1;
  goto gen__cond_12_interrupt;
  };
  goto gen__cond_12_interrupt;
 case VARREF:
  deref_and_jump(x0,gen__cond_12_16);
  *reasonp++ =  x0;
  goto gen__cond_12_interrupt;
  };
  goto gen__cond_12_interrupt;
 case functor_eq_2:
  bblt_add_no_check_y(a6,makeint(1L),x0);
  unify(a7, x0);
  allocp[0] = makesym(functor_if__not__eq_3);
  allocp[1] = x2 = makeref(&allocp[1]);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = a1;
  x1 = makefunctor(&allocp[0]);
  allocp[4] = a11;
  allocp[5] = x1;
  x4 = makecons(&allocp[4]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_klic__comp__generate_xload__pos_10);
  x5 = arg(a0, 1);
  allocp[8] = x5;
  allocp[9] = x3;
  allocp[10] = x6 = makeref(&allocp[10]);
  allocp[11] = a3;
  allocp[12] = x7 = makeref(&allocp[12]);
  allocp[13] = a5;
  allocp[14] = x8 = makeref(&allocp[14]);
  allocp[15] = a9;
  allocp[16] = x9 = makeref(&allocp[16]);
  allocp[17] = x4;
  a0 = arg(a0, 0);
  a1 = x2;
  a3 = x6;
  a5 = x7;
  a6 = a8;
  a7 = x8;
  a8 = a10;
  a9 = x9;
  qp = (struct goalrec*)&allocp[6];
  allocp += 18;
  execute(load__pos_10_0);
  goto load__pos_10_ext_interrupt;
 case functor_il_3:
  bblt_add_no_check_y(a6,makeint(1L),x0);
  unify(a7, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xadd__inline__info_3);
  x1 = arg(a0, 2);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a5;
  allocp[5] = makesym(functor_inline_3);
  x4 = arg(a0, 0);
  allocp[6] = x4;
  allocp[7] = x5 = makeref(&allocp[7]);
  allocp[8] = a1;
  x3 = makefunctor(&allocp[5]);
  allocp[9] = a11;
  allocp[10] = x3;
  x6 = makecons(&allocp[9]);
  a0 = arg(a0, 1);
  a1 = x1;
  x7 = a2;
  x8 = a3;
  a5 = a4;
  a6 = x2;
  a7 = a8;
  a8 = a9;
  a9 = a10;
  a10 = x6;
  a4 = x8;
  a3 = x7;
  a2 = x5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 11;
  execute(load__inline__args_11_0);
  goto load__inline__args_11_ext_interrupt;
 default:
  goto gen__cond_12_interrupt;
  };
 case VARREF:
  deref_and_jump(a0,gen__cond_12_1);
  *reasonp++ =  a0;
  goto gen__cond_12_interrupt;
  };
  goto gen__cond_12_interrupt;
 gen__cond_12_ext_interrupt:
  reasonp = 0l;
 gen__cond_12_interrupt:
  goto interrupt_12;
 }

 add__inline__info_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  a2 = qp->args[2];
  qp = qp->next;
 add__inline__info_3_clear_reason:
  reasonp = reasons;
 add__inline__info_3_0:
 add__inline__info_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 add__inline__info_3_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__3A_2)) goto add__inline__info_3_interrupt;
  allocp[0] = makesym(functor_var_1);
  x2 = arg(x0, 0);
  allocp[1] = x2;
  x1 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__3D_2);
  allocp[3] = x1;
  allocp[4] = x4 = makeref(&allocp[4]);
  x3 = makefunctor(&allocp[2]);
  allocp[5] = makesym(functor__3A_2);
  allocp[6] = x3;
  x6 = arg(x0, 1);
  allocp[7] = x6;
  x5 = makefunctor(&allocp[5]);
  allocp[8] = a1;
  allocp[9] = x5;
  x7 = makecons(&allocp[8]);
  allocp[10] = (q)qp;
  allocp[11] = (q)(&predicate_klic__comp__generate_xadd__inline__info_3);
  x8 = cdr_of(a0);
  allocp[12] = x8;
  allocp[13] = x7;
  allocp[14] = a2;
  allocp[15] = makesym(functor_var_1);
  allocp[16] = x2;
  x9 = makefunctor(&allocp[15]);
  allocp[17] = makesym(functor__3A_2);
  allocp[18] = x4;
  allocp[19] = x11 = makeref(&allocp[19]);
  x10 = makefunctor(&allocp[17]);
  allocp[20] = makesym(functor_yes_1);
  allocp[21] = x10;
  x12 = makefunctor(&allocp[20]);
  a0 = a1;
  a1 = x9;
  a2 = x12;
  qp = (struct goalrec*)&allocp[10];
  allocp += 22;
  execute(assocx_3_0);
  goto assocx_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,add__inline__info_3_3);
  *reasonp++ =  x0;
  goto add__inline__info_3_interrupt;
  };
  goto add__inline__info_3_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto add__inline__info_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,add__inline__info_3_1);
  *reasonp++ =  a0;
  goto add__inline__info_3_interrupt;
  };
  goto add__inline__info_3_interrupt;
 add__inline__info_3_ext_interrupt:
  reasonp = 0l;
 add__inline__info_3_interrupt:
  goto interrupt_3;
 }

 load__guard__generic__out_11_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 load__guard__generic__out_11_clear_reason:
  reasonp = reasons;
 load__guard__generic__out_11_0:
 load__guard__generic__out_11_1:
  if (!isint(a0)) goto load__guard__generic__out_11_9;
 load__guard__generic__out_11_3:
  if (!isint(a1)) goto load__guard__generic__out_11_8;
  gblt_eq(a0,a1,load__guard__generic__out_11_6);
  unify4(a10, a9, a8, a7, a6, a5, a4, a3);
  proceed();
 load__guard__generic__out_11_6:
  gblt_less(a0,a1,load__guard__generic__out_11_interrupt);
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a3;
  x0 = makefunctor(&allocp[0]);
  bblt_add_no_check_y(a3,makeint(1L),x1);
  allocp[2] = makesym(functor_gg_2);
  allocp[3] = a2;
  allocp[4] = a0;
  x2 = makefunctor(&allocp[2]);
  allocp[5] = makesym(functor__3A_2);
  allocp[6] = x0;
  allocp[7] = makesym(atom_any);
  x3 = makefunctor(&allocp[5]);
  allocp[8] = makesym(functor__3D_2);
  allocp[9] = x2;
  allocp[10] = x3;
  x4 = makefunctor(&allocp[8]);
  allocp[11] = a5;
  allocp[12] = x4;
  x5 = makecons(&allocp[11]);
  allocp[13] = makesym(functor_load__generic__arg_2);
  allocp[14] = x0;
  allocp[15] = a0;
  x6 = makefunctor(&allocp[13]);
  allocp[16] = x8 = makeref(&allocp[16]);
  allocp[17] = x6;
  x7 = makecons(&allocp[16]);
  allocp += 18;
  unify_value(a9, x7);
  bblt_add_no_check(a0,makeint(1L),x9);
  a0 = x9;
  a3 = x1;
  a5 = x5;
  a9 = x8;
  execute(load__guard__generic__out_11_0);
  goto load__guard__generic__out_11_ext_interrupt;
 load__guard__generic__out_11_8:
  if (!isref(a1)) goto load__guard__generic__out_11_interrupt;
  deref_and_jump(a1,load__guard__generic__out_11_3);
  *reasonp++ =  a1;
  goto load__guard__generic__out_11_interrupt;
 load__guard__generic__out_11_9:
  if (!isref(a0)) goto load__guard__generic__out_11_interrupt;
  deref_and_jump(a0,load__guard__generic__out_11_1);
  *reasonp++ =  a0;
  goto load__guard__generic__out_11_interrupt;
 load__guard__generic__out_11_ext_interrupt:
  reasonp = 0l;
 load__guard__generic__out_11_interrupt:
  goto interrupt_11;
 }

 prep__poss_10_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 prep__poss_10_clear_reason:
  reasonp = reasons;
 prep__poss_10_0:
 prep__poss_10_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = x2 = makeref(&allocp[1]);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xprep__poss_10);
  x3 = cdr_of(a0);
  allocp[2] = x3;
  allocp[3] = x1;
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x5 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x6 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x7 = makeref(&allocp[10]);
  allocp[11] = a9;
  a0 = car_of(a0);
  a1 = x2;
  a3 = x4;
  a5 = x5;
  a7 = x6;
  a9 = x7;
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  execute(prep__pos_10_0);
  goto prep__pos_10_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto prep__poss_10_interrupt;
  unify4(a9, a8, a7, a6, a5, a4, a3, a2);
  unify_value(a1, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a0,prep__poss_10_1);
  *reasonp++ =  a0;
  goto prep__poss_10_interrupt;
  };
  goto prep__poss_10_interrupt;
 prep__poss_10_ext_interrupt:
  reasonp = 0l;
 prep__poss_10_interrupt:
  toppred = &predicate_klic__comp__generate_xprep__poss_10;
  goto interrupt_10;
 }

 prep__vec__elems_10_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 prep__vec__elems_10_clear_reason:
  reasonp = reasons;
 prep__vec__elems_10_0:
 prep__vec__elems_10_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = x2 = makeref(&allocp[1]);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xprep__vec__elems_10);
  x3 = cdr_of(a0);
  allocp[2] = x3;
  allocp[3] = x1;
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x5 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x6 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x7 = makeref(&allocp[10]);
  allocp[11] = a9;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_klic__comp__generate_xalloc__if__var_8);
  allocp[14] = x8 = makeref(&allocp[14]);
  allocp[15] = x2;
  allocp[16] = x9 = makeref(&allocp[16]);
  allocp[17] = x4;
  allocp[18] = x10 = makeref(&allocp[18]);
  allocp[19] = x5;
  allocp[20] = x11 = makeref(&allocp[20]);
  allocp[21] = x7;
  a0 = car_of(a0);
  a1 = x8;
  a3 = x9;
  a5 = x10;
  a7 = x6;
  a9 = x11;
  qp = (struct goalrec*)&allocp[12];
  allocp += 22;
  execute(prep__pos_10_0);
  goto prep__pos_10_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto prep__vec__elems_10_interrupt;
  unify4(a9, a8, a7, a6, a5, a4, a3, a2);
  unify_value(a1, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a0,prep__vec__elems_10_1);
  *reasonp++ =  a0;
  goto prep__vec__elems_10_interrupt;
  };
  goto prep__vec__elems_10_interrupt;
 prep__vec__elems_10_ext_interrupt:
  reasonp = 0l;
 prep__vec__elems_10_interrupt:
  toppred = &predicate_klic__comp__generate_xprep__vec__elems_10;
  goto interrupt_10;
 }

 alloc__if__var_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 alloc__if__var_8_clear_reason:
  reasonp = reasons;
 alloc__if__var_8_0:
 alloc__if__var_8_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_var_1)) goto alloc__if__var_8_4;
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a2;
  x0 = makefunctor(&allocp[0]);
  bblt_add_no_check_y(a2,makeint(1L),x1);
  allocp += 2;
  unify(a3, x1);
  allocp[0] = makesym(functor_r_1);
  allocp[1] = x0;
  x2 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__3A_2);
  allocp[3] = x2;
  allocp[4] = makesym(atom_any);
  x3 = makefunctor(&allocp[2]);
  allocp += 5;
  unify_value(a1, x3);
  allocp[0] = makesym(functor__3A_2);
  allocp[1] = x0;
  allocp[2] = makesym(atom_any);
  x4 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor__3D_2);
  allocp[4] = a0;
  allocp[5] = x4;
  x5 = makefunctor(&allocp[3]);
  allocp[6] = a4;
  allocp[7] = x5;
  x6 = makecons(&allocp[6]);
  allocp += 8;
  unify_value(a5, x6);
  allocp[0] = makesym(functor_alloc__var_2);
  allocp[1] = x0;
  allocp[2] = makeint(0L);
  x7 = makefunctor(&allocp[0]);
  allocp[3] = x9 = makeref(&allocp[3]);
  allocp[4] = x7;
  x8 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a6, x8);
  allocp[0] = a7;
  allocp[1] = makefunctor(funct_const_9);
  x10 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(x9, x10);
  proceed();
 case VARREF:
  deref_and_jump(a0,alloc__if__var_8_1);
  *reasonp++ =  a0;
  goto alloc__if__var_8_4;
  };
  goto alloc__if__var_8_4;
 alloc__if__var_8_4:
  otherwise(alloc__if__var_8_interrupt);
  unify4(a7, a6, a5, a4, a3, a2, a1, a0);
  proceed();
 alloc__if__var_8_ext_interrupt:
  reasonp = 0l;
 alloc__if__var_8_interrupt:
  goto interrupt_8;
 }

 prep__pos_10_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 prep__pos_10_clear_reason:
  reasonp = reasons;
 prep__pos_10_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xprep__pos__1_10);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  x1 = a4;
  a1 = a0;
  a2 = x0;
  a0 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  execute(assocx_3_0);
  goto assocx_3_ext_interrupt;
 prep__pos_10_ext_interrupt:
  reasonp = 0l;
 prep__pos_10_interrupt:
  toppred = &predicate_klic__comp__generate_xprep__pos_10;
  goto interrupt_10;
 }

 prep__pos__1_10_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20, x21, x22, x23, x24;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 prep__pos__1_10_clear_reason:
  reasonp = reasons;
 prep__pos__1_10_0:
 prep__pos__1_10_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_yes_1:
  x0 = arg(a0, 0);
 prep__pos__1_10_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__3A_2)) goto prep__pos__1_10_23;
  unify4(a9, a8, a7, a6, a5, a4, a3, a2);
  allocp[0] = makesym(functor_r_1);
  x2 = arg(x0, 0);
  allocp[1] = x2;
  x1 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__3A_2);
  allocp[3] = x1;
  x4 = arg(x0, 1);
  allocp[4] = x4;
  x3 = makefunctor(&allocp[2]);
  allocp += 5;
  unify_value(a1, x3);
  proceed();
 case VARREF:
  deref_and_jump(x0,prep__pos__1_10_4);
  *reasonp++ =  x0;
  goto prep__pos__1_10_23;
  };
  goto prep__pos__1_10_23;
 case functor_no_1:
  x0 = arg(a0, 0);
 prep__pos__1_10_8:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_cons_2:
  allocp[0] = makesym(functor_x_1);
  allocp[1] = x2 = makeref(&allocp[1]);
  x1 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_r_1);
  allocp[3] = x1;
  x3 = makefunctor(&allocp[2]);
  allocp[4] = makesym(functor__3A_2);
  allocp[5] = x3;
  allocp[6] = makesym(atom_cons);
  x4 = makefunctor(&allocp[4]);
  allocp += 7;
  unify_value(a1, x4);
  allocp[0] = a9;
  allocp[1] = makefunctor(funct_const_8);
  x5 = makecons(&allocp[0]);
  allocp[2] = makesym(functor_make__cons_1);
  allocp[3] = x1;
  x6 = makefunctor(&allocp[2]);
  allocp[4] = x5;
  allocp[5] = x6;
  x7 = makecons(&allocp[4]);
  allocp[6] = NILATOM;
  allocp[7] = x9 = makeref(&allocp[7]);
  x8 = makecons(&allocp[6]);
  allocp[8] = x8;
  allocp[9] = x11 = makeref(&allocp[9]);
  x10 = makecons(&allocp[8]);
  allocp[10] = (q)qp;
  allocp[11] = (q)(&predicate_klic__comp__generate_xalloc__args_10);
  allocp[12] = x10;
  allocp[13] = makeint(0L);
  allocp[14] = x12 = makeref(&allocp[14]);
  allocp[15] = a3;
  allocp[16] = x13 = makeref(&allocp[16]);
  allocp[17] = a5;
  allocp[18] = x14 = makeref(&allocp[18]);
  allocp[19] = a7;
  allocp[20] = x15 = makeref(&allocp[20]);
  allocp[21] = x7;
  allocp[22] = (q)(struct goalrec*)&allocp[10];
  allocp[23] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[24] = x16 = makeref(&allocp[24]);
  allocp[25] = makeint(1L);
  allocp[26] = x12;
  qp = (struct goalrec*)&allocp[22];
  allocp += 27;
  unify(x2, x16);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xprep__pos_10);
  x17 = arg(x0, 1);
  allocp[2] = x17;
  allocp[3] = x11;
  allocp[4] = x18 = makeref(&allocp[4]);
  allocp[5] = x16;
  allocp[6] = x19 = makeref(&allocp[6]);
  allocp[7] = x13;
  allocp[8] = x20 = makeref(&allocp[8]);
  allocp[9] = x14;
  allocp[10] = x21 = makeref(&allocp[10]);
  allocp[11] = x15;
  a0 = arg(x0, 0);
  a1 = x9;
  a3 = x18;
  a5 = x19;
  a7 = x20;
  a9 = x21;
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  execute(prep__pos_10_0);
  goto prep__pos_10_ext_interrupt;
 case functor_mkfunct_2:
  x1 = arg(x0, 0);
 prep__pos__1_10_12:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor__2F_2)) goto prep__pos__1_10_23;
  allocp[0] = makesym(functor__2F_2);
  x3 = arg(x1, 0);
  allocp[1] = x3;
  x4 = arg(x1, 1);
  allocp[2] = x4;
  x2 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_funct_1);
  allocp[4] = x2;
  x5 = makefunctor(&allocp[3]);
  allocp[5] = x7 = makeref(&allocp[5]);
  allocp[6] = x5;
  x6 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a6, x6);
  allocp[0] = makesym(functor_x_1);
  allocp[1] = x9 = makeref(&allocp[1]);
  x8 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_r_1);
  allocp[3] = x8;
  x10 = makefunctor(&allocp[2]);
  allocp[4] = makesym(functor__3A_2);
  allocp[5] = x10;
  allocp[6] = makesym(atom_functor);
  x11 = makefunctor(&allocp[4]);
  allocp += 7;
  unify_value(a1, x11);
  allocp[0] = makesym(functor_make__space_1);
  allocp[1] = x13 = makeref(&allocp[1]);
  x12 = makefunctor(&allocp[0]);
  allocp[2] = a9;
  allocp[3] = x12;
  x14 = makecons(&allocp[2]);
  allocp[4] = makesym(functor_make__functor_1);
  allocp[5] = x8;
  x15 = makefunctor(&allocp[4]);
  allocp[6] = x14;
  allocp[7] = x15;
  x16 = makecons(&allocp[6]);
  allocp[8] = (q)qp;
  allocp[9] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[10] = x4;
  allocp[11] = makeint(1L);
  allocp[12] = x13;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_klic__comp__generate_xalloc__args_10);
  allocp[15] = x17 = makeref(&allocp[15]);
  allocp[16] = makeint(1L);
  allocp[17] = x18 = makeref(&allocp[17]);
  allocp[18] = a3;
  allocp[19] = x19 = makeref(&allocp[19]);
  allocp[20] = a5;
  allocp[21] = x20 = makeref(&allocp[21]);
  allocp[22] = a7;
  allocp[23] = x21 = makeref(&allocp[23]);
  allocp[24] = x16;
  allocp[25] = (q)(struct goalrec*)&allocp[13];
  allocp[26] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[27] = x22 = makeref(&allocp[27]);
  allocp[28] = makeint(1L);
  allocp[29] = x18;
  qp = (struct goalrec*)&allocp[25];
  allocp += 30;
  unify(x9, x22);
  allocp[0] = makesym(functor_alloc__functor__id_2);
  allocp[1] = x3;
  allocp[2] = x4;
  x23 = makefunctor(&allocp[0]);
  allocp[3] = x21;
  allocp[4] = x23;
  x24 = makecons(&allocp[3]);
  a0 = arg(x0, 1);
  a1 = x17;
  a3 = x22;
  a5 = x19;
  a6 = x7;
  a7 = x20;
  a9 = x24;
  allocp += 5;
  execute(prep__poss_10_0);
  goto prep__poss_10_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,prep__pos__1_10_12);
  *reasonp++ =  x1;
  goto prep__pos__1_10_23;
  };
  goto prep__pos__1_10_23;
 case functor_mkvect_2:
  allocp[0] = makesym(functor_x_1);
  allocp[1] = x2 = makeref(&allocp[1]);
  x1 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_r_1);
  allocp[3] = x1;
  x3 = makefunctor(&allocp[2]);
  allocp[4] = makesym(functor__3A_2);
  allocp[5] = x3;
  allocp[6] = makesym(atom_vector);
  x4 = makefunctor(&allocp[4]);
  allocp += 7;
  unify_value(a1, x4);
  allocp[0] = makesym(functor_make__space_1);
  x6 = arg(x0, 0);
  allocp[1] = x6;
  x5 = makefunctor(&allocp[0]);
  allocp[2] = a9;
  allocp[3] = x5;
  x7 = makecons(&allocp[2]);
  allocp[4] = makesym(functor_make__vector_2);
  allocp[5] = x1;
  allocp[6] = x6;
  x8 = makefunctor(&allocp[4]);
  allocp[7] = x7;
  allocp[8] = x8;
  x9 = makecons(&allocp[7]);
  allocp[9] = (q)qp;
  allocp[10] = (q)(&predicate_klic__comp__generate_xalloc__args_10);
  allocp[11] = x10 = makeref(&allocp[11]);
  allocp[12] = makeint(0L);
  allocp[13] = x11 = makeref(&allocp[13]);
  allocp[14] = a3;
  allocp[15] = x12 = makeref(&allocp[15]);
  allocp[16] = a5;
  allocp[17] = x13 = makeref(&allocp[17]);
  allocp[18] = a7;
  allocp[19] = x14 = makeref(&allocp[19]);
  allocp[20] = x9;
  allocp[21] = (q)(struct goalrec*)&allocp[9];
  allocp[22] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[23] = x15 = makeref(&allocp[23]);
  allocp[24] = makeint(1L);
  allocp[25] = x11;
  qp = (struct goalrec*)&allocp[21];
  allocp += 26;
  unify(x2, x15);
  a0 = arg(x0, 1);
  a1 = x10;
  a3 = x15;
  a5 = x12;
  a7 = x13;
  a9 = x14;
  execute(prep__vec__elems_10_0);
  goto prep__vec__elems_10_ext_interrupt;
 case functor_atom_1:
  unify3(a9, a8, a5, a4, a3, a2);
  allocp[0] = a7;
  allocp[1] = x0;
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a6, x1);
  unify_value(a1, x0);
  proceed();
 case functor_predicate_3:
  unify3(a9, a8, a5, a4, a3, a2);
  allocp[0] = makesym(functor_atom_1);
  x2 = arg(x0, 0);
  allocp[1] = x2;
  x1 = makefunctor(&allocp[0]);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = x1;
  x3 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a6, x3);
  allocp[0] = makesym(functor_atom_1);
  x6 = arg(x0, 1);
  allocp[1] = x6;
  x5 = makefunctor(&allocp[0]);
  allocp[2] = x8 = makeref(&allocp[2]);
  allocp[3] = x5;
  x7 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(x4, x7);
  allocp[0] = makesym(functor__2F_2);
  allocp[1] = x2;
  allocp[2] = x6;
  x9 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor__2F_2);
  allocp[4] = x9;
  x11 = arg(x0, 2);
  allocp[5] = x11;
  x10 = makefunctor(&allocp[3]);
  allocp[6] = makesym(functor_ext_1);
  allocp[7] = x10;
  x12 = makefunctor(&allocp[6]);
  allocp[8] = x14 = makeref(&allocp[8]);
  allocp[9] = x12;
  x13 = makecons(&allocp[8]);
  allocp += 10;
  unify_value(x8, x13);
  allocp[0] = makesym(functor_const_2);
  allocp[1] = x16 = makeref(&allocp[1]);
  allocp[2] = x0;
  x15 = makefunctor(&allocp[0]);
  allocp[3] = a7;
  allocp[4] = x15;
  x17 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(x14, x17);
  allocp[0] = makesym(functor_const_1);
  allocp[1] = x16;
  x18 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x18);
  proceed();
 case functor_float_1:
  unify3(a9, a8, a5, a4, a3, a2);
  allocp[0] = makesym(functor_const_2);
  allocp[1] = x2 = makeref(&allocp[1]);
  allocp[2] = x0;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a7;
  allocp[4] = x1;
  x3 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a6, x3);
  allocp[0] = makesym(functor_const_1);
  allocp[1] = x2;
  x4 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x4);
  proceed();
 case functor_list_1:
  unify3(a9, a8, a5, a4, a3, a2);
  allocp[0] = makesym(functor_const_2);
  allocp[1] = x2 = makeref(&allocp[1]);
  allocp[2] = x0;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a7;
  allocp[4] = x1;
  x3 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a6, x3);
  allocp[0] = makesym(functor_const_1);
  allocp[1] = x2;
  x4 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x4);
  proceed();
 case functor_functor_1:
  unify3(a9, a8, a5, a4, a3, a2);
  allocp[0] = makesym(functor_const_2);
  allocp[1] = x2 = makeref(&allocp[1]);
  allocp[2] = x0;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a7;
  allocp[4] = x1;
  x3 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a6, x3);
  allocp[0] = makesym(functor_const_1);
  allocp[1] = x2;
  x4 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x4);
  proceed();
 case functor_string_1:
  unify3(a9, a8, a5, a4, a3, a2);
  allocp[0] = makesym(functor_const_2);
  allocp[1] = x2 = makeref(&allocp[1]);
  allocp[2] = x0;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a7;
  allocp[4] = x1;
  x3 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a6, x3);
  allocp[0] = makesym(functor_const_1);
  allocp[1] = x2;
  x4 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x4);
  proceed();
 case functor_vector_1:
  unify3(a9, a8, a5, a4, a3, a2);
  allocp[0] = makesym(functor_const_2);
  allocp[1] = x2 = makeref(&allocp[1]);
  allocp[2] = x0;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a7;
  allocp[4] = x1;
  x3 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a6, x3);
  allocp[0] = makesym(functor_const_1);
  allocp[1] = x2;
  x4 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x4);
  proceed();
 default:
  goto prep__pos__1_10_23;
  };
 case VARREF:
  deref_and_jump(x0,prep__pos__1_10_8);
  *reasonp++ =  x0;
  goto prep__pos__1_10_23;
  };
  goto prep__pos__1_10_23;
 default:
  goto prep__pos__1_10_23;
  };
 case VARREF:
  deref_and_jump(a0,prep__pos__1_10_1);
  *reasonp++ =  a0;
  goto prep__pos__1_10_23;
  };
  goto prep__pos__1_10_23;
 prep__pos__1_10_23:
  otherwise(prep__pos__1_10_interrupt);
 prep__pos__1_10_25:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_no_1)) goto prep__pos__1_10_interrupt;
  unify4(a9, a8, a7, a6, a5, a4, a3, a2);
  x0 = arg(a0, 0);
  unify(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,prep__pos__1_10_25);
  *reasonp++ =  a0;
  goto prep__pos__1_10_interrupt;
  };
  goto prep__pos__1_10_interrupt;
 prep__pos__1_10_ext_interrupt:
  reasonp = 0l;
 prep__pos__1_10_interrupt:
  goto interrupt_10;
 }

 alloc__args_10_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 alloc__args_10_clear_reason:
  reasonp = reasons;
 alloc__args_10_0:
 alloc__args_10_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xalloc__args_10);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x5 = makeref(&allocp[10]);
  allocp[11] = a9;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[14] = a1;
  allocp[15] = makeint(1L);
  allocp[16] = x1;
  a0 = car_of(a0);
  a3 = x2;
  a5 = x3;
  a7 = x4;
  a9 = x5;
  qp = (struct goalrec*)&allocp[12];
  allocp += 17;
  execute(alloc__one_10_0);
  goto alloc__one_10_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto alloc__args_10_interrupt;
  unify4(a9, a8, a7, a6, a5, a4, a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,alloc__args_10_1);
  *reasonp++ =  a0;
  goto alloc__args_10_interrupt;
  };
  goto alloc__args_10_interrupt;
 alloc__args_10_ext_interrupt:
  reasonp = 0l;
 alloc__args_10_interrupt:
  goto interrupt_10;
 }

 alloc__one_10_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 alloc__one_10_clear_reason:
  reasonp = reasons;
 alloc__one_10_0:
 alloc__one_10_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor__3A_2)) goto alloc__one_10_7;
  x0 = arg(a0, 0);
 alloc__one_10_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_r_1)) goto alloc__one_10_7;
  unify3(a7, a6, a5, a4, a3, a2);
  allocp[0] = makesym(functor_alloc__value_2);
  x2 = arg(x0, 0);
  allocp[1] = x2;
  allocp[2] = a1;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a9;
  allocp[4] = x1;
  x3 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a8, x3);
  proceed();
 case VARREF:
  deref_and_jump(x0,alloc__one_10_4);
  *reasonp++ =  x0;
  goto alloc__one_10_7;
  };
  goto alloc__one_10_7;
 case VARREF:
  deref_and_jump(a0,alloc__one_10_1);
  *reasonp++ =  a0;
  goto alloc__one_10_7;
  };
  goto alloc__one_10_7;
 alloc__one_10_7:
  otherwise(alloc__one_10_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xalloc__one__1_10);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  x1 = a4;
  a1 = a0;
  a2 = x0;
  a0 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  execute(assocx_3_0);
  goto assocx_3_ext_interrupt;
 alloc__one_10_ext_interrupt:
  reasonp = 0l;
 alloc__one_10_interrupt:
  toppred = &predicate_klic__comp__generate_xalloc__one_10;
  goto interrupt_10;
 }

 alloc__one__1_10_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 alloc__one__1_10_clear_reason:
  reasonp = reasons;
 alloc__one__1_10_0:
 alloc__one__1_10_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_yes_1:
  x0 = arg(a0, 0);
 alloc__one__1_10_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__3A_2)) goto alloc__one__1_10_interrupt;
  allocp[0] = makesym(functor_r_1);
  x2 = arg(x0, 0);
  allocp[1] = x2;
  x1 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__3A_2);
  allocp[3] = x1;
  x4 = arg(x0, 1);
  allocp[4] = x4;
  x3 = makefunctor(&allocp[2]);
  a0 = x3;
  allocp += 5;
  execute(alloc__one_10_0);
  goto alloc__one_10_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,alloc__one__1_10_4);
  *reasonp++ =  x0;
  goto alloc__one__1_10_interrupt;
  };
  goto alloc__one__1_10_interrupt;
 case functor_no_1:
  x0 = arg(a0, 0);
 alloc__one__1_10_8:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_var_1:
  unify(a7, a6);
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a2;
  x1 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__3A_2);
  allocp[3] = x1;
  allocp[4] = makesym(atom_any);
  x2 = makefunctor(&allocp[2]);
  allocp[5] = makesym(functor__3D_2);
  allocp[6] = x0;
  allocp[7] = x2;
  x3 = makefunctor(&allocp[5]);
  allocp[8] = a4;
  allocp[9] = x3;
  x4 = makecons(&allocp[8]);
  allocp += 10;
  unify_value(a5, x4);
  allocp[0] = makesym(functor_alloc__var_2);
  allocp[1] = x1;
  allocp[2] = a1;
  x5 = makefunctor(&allocp[0]);
  allocp[3] = a9;
  allocp[4] = x5;
  x6 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a8, x6);
  bblt_add_no_check_y(a2,makeint(1L),x7);
  unify(a3, x7);
  proceed();
 case functor_atom_1:
  unify3(a7, a6, a5, a4, a3, a2);
  allocp[0] = makesym(functor_alloc__atomic_2);
  x2 = arg(x0, 0);
  allocp[1] = x2;
  allocp[2] = a1;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a9;
  allocp[4] = x1;
  x3 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a8, x3);
  proceed();
 case functor_int_1:
  unify3(a7, a6, a5, a4, a3, a2);
  allocp[0] = makesym(functor_alloc__atomic_2);
  x2 = arg(x0, 0);
  allocp[1] = x2;
  allocp[2] = a1;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a9;
  allocp[4] = x1;
  x3 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a8, x3);
  proceed();
 case functor_arg_2:
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a2;
  x1 = makefunctor(&allocp[0]);
  bblt_add_no_check_y(a2,makeint(1L),x2);
  allocp[2] = makesym(functor__3A_2);
  allocp[3] = x1;
  allocp[4] = makesym(atom_any);
  x3 = makefunctor(&allocp[2]);
  allocp[5] = makesym(functor__3D_2);
  allocp[6] = x0;
  allocp[7] = x3;
  x4 = makefunctor(&allocp[5]);
  allocp[8] = a4;
  allocp[9] = x4;
  x5 = makecons(&allocp[8]);
  allocp[10] = makesym(functor_alloc__value_2);
  allocp[11] = x1;
  allocp[12] = a1;
  x6 = makefunctor(&allocp[10]);
  allocp[13] = a9;
  allocp[14] = x6;
  x7 = makecons(&allocp[13]);
  allocp[15] = makesym(functor_get__elem_3);
  allocp[16] = x1;
  allocp[17] = x9 = makeref(&allocp[17]);
  x10 = arg(x0, 1);
  allocp[18] = x10;
  x8 = makefunctor(&allocp[15]);
  allocp[19] = x7;
  allocp[20] = x8;
  x11 = makecons(&allocp[19]);
  a0 = arg(x0, 0);
  a1 = x9;
  a2 = x2;
  a4 = x5;
  a9 = x11;
  allocp += 21;
  execute(load__pos_10_0);
  goto load__pos_10_ext_interrupt;
 case functor_const_1:
  unify3(a7, a6, a5, a4, a3, a2);
  allocp[0] = makesym(functor_alloc__const_2);
  allocp[1] = x0;
  allocp[2] = a1;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a9;
  allocp[4] = x1;
  x2 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a8, x2);
  proceed();
 default:
  goto alloc__one__1_10_interrupt;
  };
 case VARREF:
  deref_and_jump(x0,alloc__one__1_10_8);
  *reasonp++ =  x0;
  goto alloc__one__1_10_interrupt;
  };
  goto alloc__one__1_10_interrupt;
 default:
  goto alloc__one__1_10_interrupt;
  };
 case VARREF:
  deref_and_jump(a0,alloc__one__1_10_1);
  *reasonp++ =  a0;
  goto alloc__one__1_10_interrupt;
  };
  goto alloc__one__1_10_interrupt;
 alloc__one__1_10_ext_interrupt:
  reasonp = 0l;
 alloc__one__1_10_interrupt:
  goto interrupt_10;
 }

 load__inline__args_11_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 load__inline__args_11_clear_reason:
  reasonp = reasons;
 load__inline__args_11_0:
 load__inline__args_11_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 load__inline__args_11_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor__2B_1:
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = x3 = makeref(&allocp[1]);
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xload__inline__args_11);
  x4 = cdr_of(a0);
  allocp[2] = x4;
  allocp[3] = a1;
  allocp[4] = x2;
  allocp[5] = x5 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x6 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = x7 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = x8 = makeref(&allocp[11]);
  allocp[12] = a10;
  a0 = arg(x0, 0);
  a1 = x3;
  a2 = a3;
  a3 = x5;
  a4 = a5;
  a5 = x6;
  a6 = a7;
  a7 = x7;
  a8 = a9;
  a9 = x8;
  qp = (struct goalrec*)&allocp[0];
  allocp += 13;
  execute(load__pos_10_0);
  goto load__pos_10_ext_interrupt;
 case functor__2D_1:
 load__inline__args_11_7:
  switch (ptagof(a1)) {
 case CONS:
  x1 = car_of(a1);
 load__inline__args_11_9:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor__3A_2)) goto load__inline__args_11_interrupt;
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a3;
  x2 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_r_1);
  allocp[3] = x2;
  x3 = makefunctor(&allocp[2]);
  bblt_add_no_check_y(a3,makeint(1L),x4);
  allocp[4] = makesym(functor__3A_2);
  allocp[5] = x3;
  x6 = arg(x1, 1);
  allocp[6] = x6;
  x5 = makefunctor(&allocp[4]);
  allocp[7] = makesym(functor__3D_2);
  x8 = arg(x0, 0);
  allocp[8] = x8;
  allocp[9] = x5;
  x7 = makefunctor(&allocp[7]);
  allocp[10] = a5;
  allocp[11] = x7;
  x9 = makecons(&allocp[10]);
  allocp[12] = x11 = makeref(&allocp[12]);
  allocp[13] = x3;
  x10 = makecons(&allocp[12]);
  allocp += 14;
  unify_value(a2, x10);
  a0 = cdr_of(a0);
  a1 = cdr_of(a1);
  a2 = x11;
  a3 = x4;
  a5 = x9;
  execute(load__inline__args_11_0);
  goto load__inline__args_11_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,load__inline__args_11_9);
  *reasonp++ =  x1;
  goto load__inline__args_11_interrupt;
  };
  goto load__inline__args_11_interrupt;
 case VARREF:
  deref_and_jump(a1,load__inline__args_11_7);
  *reasonp++ =  a1;
  goto load__inline__args_11_interrupt;
  };
  goto load__inline__args_11_interrupt;
 default:
  goto load__inline__args_11_interrupt;
  };
 case VARREF:
  deref_and_jump(x0,load__inline__args_11_3);
  *reasonp++ =  x0;
  goto load__inline__args_11_interrupt;
  };
  goto load__inline__args_11_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto load__inline__args_11_interrupt;
  unify4(a10, a9, a8, a7, a6, a5, a4, a3);
  unify_value(a2, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a0,load__inline__args_11_1);
  *reasonp++ =  a0;
  goto load__inline__args_11_interrupt;
  };
  goto load__inline__args_11_interrupt;
 load__inline__args_11_ext_interrupt:
  reasonp = 0l;
 load__inline__args_11_interrupt:
  toppred = &predicate_klic__comp__generate_xload__inline__args_11;
  goto interrupt_11;
 }

 load__pos_10_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 load__pos_10_clear_reason:
  reasonp = reasons;
 load__pos_10_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xload__reg_11);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a3;
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = a5;
  allocp[9] = x4 = makeref(&allocp[9]);
  allocp[10] = a7;
  allocp[11] = x5 = makeref(&allocp[11]);
  allocp[12] = a9;
  a1 = x0;
  a3 = x2;
  a5 = x3;
  a7 = x4;
  a9 = x5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 13;
  execute(prep__pos_10_0);
  goto prep__pos_10_ext_interrupt;
 load__pos_10_ext_interrupt:
  reasonp = 0l;
 load__pos_10_interrupt:
  toppred = &predicate_klic__comp__generate_xload__pos_10;
  goto interrupt_10;
 }

 load__reg_11_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 load__reg_11_clear_reason:
  reasonp = reasons;
 load__reg_11_0:
 load__reg_11_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor__3A_2)) goto load__reg_11_7;
  x0 = arg(a0, 0);
 load__reg_11_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_r_1)) goto load__reg_11_7;
  unify4(a10, a9, a8, a7, a6, a5, a4, a3);
  x1 = arg(x0, 0);
  unify(a1, x1);
  x2 = arg(a0, 1);
  unify(a2, x2);
  proceed();
 case VARREF:
  deref_and_jump(x0,load__reg_11_4);
  *reasonp++ =  x0;
  goto load__reg_11_7;
  };
  goto load__reg_11_7;
 case VARREF:
  deref_and_jump(a0,load__reg_11_1);
  *reasonp++ =  a0;
  goto load__reg_11_7;
  };
  goto load__reg_11_7;
 load__reg_11_7:
  otherwise(load__reg_11_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xload__reg__1_11);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  allocp[12] = a10;
  x1 = a5;
  a1 = a0;
  a2 = x0;
  a0 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 13;
  execute(assocx_3_0);
  goto assocx_3_ext_interrupt;
 load__reg_11_ext_interrupt:
  reasonp = 0l;
 load__reg_11_interrupt:
  toppred = &predicate_klic__comp__generate_xload__reg_11;
  goto interrupt_11;
 }

 load__reg__1_11_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 load__reg__1_11_clear_reason:
  reasonp = reasons;
 load__reg__1_11_0:
 load__reg__1_11_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_yes_1:
  x0 = arg(a0, 0);
 load__reg__1_11_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__3A_2)) goto load__reg__1_11_interrupt;
  unify4(a10, a9, a8, a7, a6, a5, a4, a3);
  x1 = arg(x0, 0);
  unify(a1, x1);
  x2 = arg(x0, 1);
  unify(a2, x2);
  proceed();
 case VARREF:
  deref_and_jump(x0,load__reg__1_11_4);
  *reasonp++ =  x0;
  goto load__reg__1_11_interrupt;
  };
  goto load__reg__1_11_interrupt;
 case functor_no_1:
  x0 = arg(a0, 0);
 load__reg__1_11_8:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_arg_2:
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a3;
  x1 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x1);
  bblt_add_no_check_y(a3,makeint(1L),x2);
  unify_value(a2, makesym(atom_any));
  allocp[0] = makesym(functor__3A_2);
  allocp[1] = a1;
  allocp[2] = a2;
  x3 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor__3D_2);
  allocp[4] = x0;
  allocp[5] = x3;
  x4 = makefunctor(&allocp[3]);
  allocp[6] = a5;
  allocp[7] = x4;
  x5 = makecons(&allocp[6]);
  allocp[8] = makesym(functor_get__elem_3);
  allocp[9] = a1;
  allocp[10] = x7 = makeref(&allocp[10]);
  x8 = arg(x0, 1);
  allocp[11] = x8;
  x6 = makefunctor(&allocp[8]);
  allocp[12] = a10;
  allocp[13] = x6;
  x9 = makecons(&allocp[12]);
  a0 = arg(x0, 0);
  a1 = x7;
  a2 = x2;
  a3 = a4;
  a4 = x5;
  a5 = a6;
  a6 = a7;
  a7 = a8;
  a8 = a9;
  a9 = x9;
  allocp += 14;
  execute(load__pos_10_0);
  goto load__pos_10_ext_interrupt;
 case functor_atom_1:
  unify2(a8, a7, a6, a5);
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a3;
  x1 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x1);
  bblt_add_no_check_y(a3,makeint(1L),x2);
  unify(a4, x2);
  unify_value(a2, makesym(atom_atom));
  allocp[0] = makesym(functor_load__atom_2);
  allocp[1] = a1;
  x4 = arg(x0, 0);
  allocp[2] = x4;
  x3 = makefunctor(&allocp[0]);
  allocp[3] = a10;
  allocp[4] = x3;
  x5 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a9, x5);
  proceed();
 case functor_int_1:
  unify2(a8, a7, a6, a5);
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a3;
  x1 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x1);
  bblt_add_no_check_y(a3,makeint(1L),x2);
  unify(a4, x2);
  unify_value(a2, makesym(atom_int));
  allocp[0] = makesym(functor_load__atom_2);
  allocp[1] = a1;
  x4 = arg(x0, 0);
  allocp[2] = x4;
  x3 = makefunctor(&allocp[0]);
  allocp[3] = a10;
  allocp[4] = x3;
  x5 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a9, x5);
  proceed();
 case functor_var_1:
  unify(a8, a7);
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a3;
  x1 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x1);
  bblt_add_no_check_y(a3,makeint(1L),x2);
  unify(a4, x2);
  unify_value(a2, makesym(atom_any));
  allocp[0] = makesym(functor__3A_2);
  allocp[1] = a1;
  allocp[2] = a2;
  x3 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor__3D_2);
  allocp[4] = x0;
  allocp[5] = x3;
  x4 = makefunctor(&allocp[3]);
  allocp[6] = a5;
  allocp[7] = x4;
  x5 = makecons(&allocp[6]);
  allocp += 8;
  unify_value(a6, x5);
  allocp[0] = makesym(functor_load__newvar_1);
  allocp[1] = a1;
  x6 = makefunctor(&allocp[0]);
  allocp[2] = a10;
  allocp[3] = x6;
  x7 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a9, x7);
  proceed();
 case functor_const_1:
  unify2(a8, a7, a6, a5);
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a3;
  x1 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x1);
  bblt_add_no_check_y(a3,makeint(1L),x2);
  unify(a4, x2);
  unify_value(a2, makesym(atom_known));
  allocp[0] = makesym(functor_load__const_2);
  allocp[1] = a1;
  allocp[2] = x0;
  x3 = makefunctor(&allocp[0]);
  allocp[3] = a10;
  allocp[4] = x3;
  x4 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a9, x4);
  proceed();
 default:
  goto load__reg__1_11_interrupt;
  };
 case VARREF:
  deref_and_jump(x0,load__reg__1_11_8);
  *reasonp++ =  x0;
  goto load__reg__1_11_interrupt;
  };
  goto load__reg__1_11_interrupt;
 default:
  goto load__reg__1_11_interrupt;
  };
 case VARREF:
  deref_and_jump(a0,load__reg__1_11_1);
  *reasonp++ =  a0;
  goto load__reg__1_11_interrupt;
  };
  goto load__reg__1_11_interrupt;
 load__reg__1_11_ext_interrupt:
  reasonp = 0l;
 load__reg__1_11_interrupt:
  goto interrupt_11;
 }

 gen__body_13_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  qp = qp->next;
 gen__body_13_clear_reason:
  reasonp = reasons;
 gen__body_13_0:
 gen__body_13_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 gen__body_13_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_call_3)) goto gen__body_13_13;
  x1 = cdr_of(a0);
 gen__body_13_6:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto gen__body_13_13;
  unify(a4, a3);
  allocp[0] = makesym(functor__2F_2);
  x3 = arg(x0, 0);
  allocp[1] = x3;
  x4 = arg(x0, 1);
  allocp[2] = x4;
  x2 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_exec_1);
  allocp[4] = x2;
  x5 = makefunctor(&allocp[3]);
  allocp[5] = x7 = makeref(&allocp[5]);
  allocp[6] = x5;
  x6 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a9, x6);
  allocp[0] = makesym(functor_execute_4);
  allocp[1] = x3;
  allocp[2] = x4;
  allocp[3] = a1;
  allocp[4] = a2;
  x8 = makefunctor(&allocp[0]);
  allocp[5] = a12;
  allocp[6] = x8;
  x9 = makecons(&allocp[5]);
  allocp[7] = (q)qp;
  allocp[8] = (q)(&predicate_klic__comp__generate_xmove__args_10);
  allocp[9] = x10 = makeref(&allocp[9]);
  allocp[10] = makeint(0L);
  allocp[11] = x11 = makeref(&allocp[11]);
  allocp[12] = a6;
  allocp[13] = x12 = makeref(&allocp[13]);
  allocp[14] = a8;
  allocp[15] = x13 = makeref(&allocp[15]);
  allocp[16] = a10;
  allocp[17] = x14 = makeref(&allocp[17]);
  allocp[18] = x9;
  a0 = arg(x0, 2);
  a1 = x10;
  a2 = a5;
  a3 = x11;
  a4 = a7;
  a5 = x12;
  a6 = x7;
  a7 = x13;
  a8 = a11;
  a9 = x14;
  qp = (struct goalrec*)&allocp[7];
  allocp += 19;
  execute(prep__poss_10_0);
  goto prep__poss_10_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,gen__body_13_6);
  *reasonp++ =  x1;
  goto gen__body_13_13;
  };
  goto gen__body_13_13;
 case VARREF:
  deref_and_jump(x0,gen__body_13_3);
  *reasonp++ =  x0;
  goto gen__body_13_13;
  };
  goto gen__body_13_13;
 case ATOMIC:
  if (a0 != NILATOM) goto gen__body_13_13;
  unify4(a10, a9, a8, a7, a6, a5, a4, a3);
  allocp[0] = makesym(functor_proceed_1);
  allocp[1] = a2;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = a12;
  allocp[3] = x0;
  x1 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a11, x1);
  proceed();
 case VARREF:
  deref_and_jump(a0,gen__body_13_1);
  *reasonp++ =  a0;
  goto gen__body_13_13;
  };
  goto gen__body_13_13;
 gen__body_13_13:
  otherwise(gen__body_13_interrupt);
 gen__body_13_15:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xgen__body_13);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = a1;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = x4 = makeref(&allocp[9]);
  allocp[10] = a8;
  allocp[11] = x5 = makeref(&allocp[11]);
  allocp[12] = a10;
  allocp[13] = x6 = makeref(&allocp[13]);
  allocp[14] = a12;
  a0 = car_of(a0);
  a1 = a2;
  a2 = x1;
  a4 = x2;
  a6 = x3;
  a8 = x4;
  a10 = x5;
  a12 = x6;
  qp = (struct goalrec*)&allocp[0];
  allocp += 15;
  execute(gen__body__goal_13_0);
  goto gen__body__goal_13_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,gen__body_13_15);
  *reasonp++ =  a0;
  goto gen__body_13_interrupt;
  };
  goto gen__body_13_interrupt;
 gen__body_13_ext_interrupt:
  reasonp = 0l;
 gen__body_13_interrupt:
  goto interrupt_13;
 }

 gen__body__goal_13_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20, x21, x22, x23, x24, x25, x26, x27, x28, x29, x30, x31, x32;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  qp = qp->next;
 gen__body__goal_13_clear_reason:
  reasonp = reasons;
 gen__body__goal_13_0:
 gen__body__goal_13_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor__3D_2:
  unify(a4, a3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xbody__unify_12);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a6;
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = a8;
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = a10;
  allocp[10] = a1;
  allocp[11] = a2;
  allocp[12] = x5 = makeref(&allocp[12]);
  allocp[13] = a12;
  allocp[14] = (q)(struct goalrec*)&allocp[0];
  allocp[15] = (q)(&predicate_klic__comp__generate_xprep__pos_10);
  x6 = arg(a0, 1);
  allocp[16] = x6;
  allocp[17] = x1;
  allocp[18] = x7 = makeref(&allocp[18]);
  allocp[19] = x2;
  allocp[20] = x8 = makeref(&allocp[20]);
  allocp[21] = x3;
  allocp[22] = x9 = makeref(&allocp[22]);
  allocp[23] = x4;
  allocp[24] = x10 = makeref(&allocp[24]);
  allocp[25] = x5;
  a0 = arg(a0, 0);
  a1 = x0;
  a2 = a5;
  a3 = x7;
  a4 = a7;
  a5 = x8;
  a6 = a9;
  a7 = x9;
  a8 = a11;
  a9 = x10;
  qp = (struct goalrec*)&allocp[14];
  allocp += 26;
  execute(prep__pos_10_0);
  goto prep__pos_10_ext_interrupt;
 case functor_builtin_5:
  unify(a4, a3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xbb__out_14);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  x2 = arg(a0, 4);
  allocp[4] = x2;
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = x4 = makeref(&allocp[6]);
  allocp[7] = a6;
  allocp[8] = x5 = makeref(&allocp[8]);
  allocp[9] = a8;
  allocp[10] = x6 = makeref(&allocp[10]);
  allocp[11] = a10;
  allocp[12] = a1;
  allocp[13] = a2;
  allocp[14] = x7 = makeref(&allocp[14]);
  allocp[15] = a12;
  allocp[16] = makesym(functor_bblt_4);
  allocp[17] = x1;
  x9 = arg(a0, 0);
  allocp[18] = x9;
  allocp[19] = x10 = makeref(&allocp[19]);
  allocp[20] = x3;
  x8 = makefunctor(&allocp[16]);
  allocp[21] = x7;
  allocp[22] = x8;
  x11 = makecons(&allocp[21]);
  allocp[23] = (q)(struct goalrec*)&allocp[0];
  allocp[24] = (q)(&predicate_klic__comp__generate_xbb__in_14);
  x12 = arg(a0, 3);
  allocp[25] = x12;
  allocp[26] = x13 = makeref(&allocp[26]);
  allocp[27] = x0;
  allocp[28] = makeint(1L);
  allocp[29] = x1;
  allocp[30] = x10;
  allocp[31] = x14 = makeref(&allocp[31]);
  allocp[32] = x4;
  allocp[33] = x15 = makeref(&allocp[33]);
  allocp[34] = x5;
  allocp[35] = x16 = makeref(&allocp[35]);
  allocp[36] = x6;
  allocp[37] = x17 = makeref(&allocp[37]);
  allocp[38] = x11;
  a0 = arg(a0, 2);
  a1 = x13;
  a2 = a5;
  a3 = x14;
  a4 = a7;
  a5 = x15;
  a6 = a9;
  a7 = x16;
  a8 = a11;
  a9 = x17;
  qp = (struct goalrec*)&allocp[23];
  allocp += 39;
  execute(prep__poss_10_0);
  goto prep__poss_10_ext_interrupt;
 case functor_call_3:
  unify(a4, a3);
  allocp[0] = makesym(functor_push__goal_2);
  allocp[1] = a1;
  allocp[2] = a2;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_set__pred_2);
  x2 = arg(a0, 0);
  allocp[4] = x2;
  x3 = arg(a0, 1);
  allocp[5] = x3;
  x1 = makefunctor(&allocp[3]);
  allocp[6] = NILATOM;
  allocp[7] = x1;
  x4 = makecons(&allocp[6]);
  allocp[8] = x4;
  allocp[9] = x0;
  x5 = makecons(&allocp[8]);
  a0 = arg(a0, 2);
  a1 = x5;
  a2 = a5;
  a3 = a6;
  a4 = a7;
  a5 = a8;
  a6 = a9;
  a7 = a10;
  a8 = a11;
  a9 = a12;
  allocp += 10;
  execute(set__call_10_0);
  goto set__call_10_ext_interrupt;
 case functor_xcall_4:
  unify(a4, a3);
  allocp[0] = makesym(functor__2F_2);
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x2 = arg(a0, 1);
  allocp[2] = x2;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor__2F_2);
  allocp[4] = x0;
  x4 = arg(a0, 2);
  allocp[5] = x4;
  x3 = makefunctor(&allocp[3]);
  allocp[6] = makesym(functor_ext_1);
  allocp[7] = x3;
  x5 = makefunctor(&allocp[6]);
  allocp[8] = x7 = makeref(&allocp[8]);
  allocp[9] = x5;
  x6 = makecons(&allocp[8]);
  allocp += 10;
  unify_value(a9, x6);
  allocp[0] = makesym(functor_push__goal_2);
  allocp[1] = a1;
  allocp[2] = a2;
  x8 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_set__ext__pred_3);
  allocp[4] = x1;
  allocp[5] = x2;
  allocp[6] = x4;
  x9 = makefunctor(&allocp[3]);
  allocp[7] = NILATOM;
  allocp[8] = x9;
  x10 = makecons(&allocp[7]);
  allocp[9] = x10;
  allocp[10] = x8;
  x11 = makecons(&allocp[9]);
  a0 = arg(a0, 3);
  a1 = x11;
  a2 = a5;
  a3 = a6;
  a4 = a7;
  a5 = a8;
  a6 = x7;
  a7 = a10;
  a8 = a11;
  a9 = a12;
  allocp += 11;
  execute(set__call_10_0);
  goto set__call_10_ext_interrupt;
 case functor_gcall_3:
  x0 = arg(a0, 0);
 gen__body__goal_13_8:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (isint(x0)) goto gen__body__goal_13_53;
  switch (symval(x0)) {
 case symval(makesym(atom_new)):
  x1 = arg(a0, 2);
 gen__body__goal_13_12:
  switch (ptagof(x1)) {
 case CONS:
  x2 = car_of(x1);
 gen__body__goal_13_14:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_atom_1)) goto gen__body__goal_13_53;
  x3 = cdr_of(x1);
 gen__body__goal_13_17:
  switch (ptagof(x3)) {
 case CONS:
  unify(a4, a3);
  allocp[0] = makesym(functor_gnew_1);
  x5 = arg(x2, 0);
  allocp[1] = x5;
  x4 = makefunctor(&allocp[0]);
  allocp[2] = x7 = makeref(&allocp[2]);
  allocp[3] = x4;
  x6 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a9, x6);
  allocp[0] = makesym(functor_r_1);
  allocp[1] = x9 = makeref(&allocp[1]);
  x8 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__3A_2);
  allocp[3] = x8;
  allocp[4] = makesym(atom_any);
  x10 = makefunctor(&allocp[2]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_klic__comp__generate_xbody__unify_12);
  allocp[7] = x11 = makeref(&allocp[7]);
  allocp[8] = x10;
  allocp[9] = x12 = makeref(&allocp[9]);
  allocp[10] = a6;
  allocp[11] = x13 = makeref(&allocp[11]);
  allocp[12] = a8;
  allocp[13] = x14 = makeref(&allocp[13]);
  allocp[14] = a10;
  allocp[15] = x15 = makeref(&allocp[15]);
  allocp[16] = a2;
  allocp[17] = x16 = makeref(&allocp[17]);
  allocp[18] = a12;
  allocp[19] = (q)(struct goalrec*)&allocp[5];
  allocp[20] = (q)(&predicate_klic__comp__generate_xprep__pos_10);
  x17 = car_of(x3);
  allocp[21] = x17;
  allocp[22] = x11;
  allocp[23] = x18 = makeref(&allocp[23]);
  allocp[24] = x12;
  allocp[25] = x19 = makeref(&allocp[25]);
  allocp[26] = x13;
  allocp[27] = x20 = makeref(&allocp[27]);
  allocp[28] = x14;
  allocp[29] = x21 = makeref(&allocp[29]);
  allocp[30] = x16;
  qp = (struct goalrec*)&allocp[19];
  allocp += 31;
  unify_value(x15, makesym(atom_qp));
  allocp[0] = makesym(functor_new__generic_4);
  allocp[1] = x5;
  allocp[2] = x23 = makeref(&allocp[2]);
  allocp[3] = x9;
  allocp[4] = a1;
  x22 = makefunctor(&allocp[0]);
  allocp[5] = x21;
  allocp[6] = x22;
  x24 = makecons(&allocp[5]);
  allocp[7] = (q)qp;
  allocp[8] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[9] = x25 = makeref(&allocp[9]);
  allocp[10] = makeint(1L);
  allocp[11] = x18;
  allocp[12] = makesym(functor_x_1);
  allocp[13] = x25;
  x26 = makefunctor(&allocp[12]);
  qp = (struct goalrec*)&allocp[7];
  allocp += 14;
  unify_value(x9, x26);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_integer__arithmetics_xsubtract_3);
  x27 = arg(a0, 1);
  allocp[2] = x27;
  allocp[3] = makeint(2L);
  allocp[4] = x23;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_klic__comp__generate_xset__generic__args_10);
  allocp[7] = x28 = makeref(&allocp[7]);
  allocp[8] = makeint(0L);
  allocp[9] = x29 = makeref(&allocp[9]);
  allocp[10] = x25;
  allocp[11] = x30 = makeref(&allocp[11]);
  allocp[12] = x19;
  allocp[13] = x31 = makeref(&allocp[13]);
  allocp[14] = x20;
  allocp[15] = x32 = makeref(&allocp[15]);
  allocp[16] = x24;
  a0 = cdr_of(x3);
  a1 = x28;
  a2 = a5;
  a3 = x29;
  a4 = a7;
  a5 = x30;
  a6 = x7;
  a7 = x31;
  a8 = a11;
  a9 = x32;
  qp = (struct goalrec*)&allocp[5];
  allocp += 17;
  execute(prep__poss_10_0);
  goto prep__poss_10_ext_interrupt;
 case VARREF:
  deref_and_jump(x3,gen__body__goal_13_17);
  *reasonp++ =  x3;
  goto gen__body__goal_13_53;
  };
  goto gen__body__goal_13_53;
 case VARREF:
  deref_and_jump(x2,gen__body__goal_13_14);
  *reasonp++ =  x2;
  goto gen__body__goal_13_53;
  };
  goto gen__body__goal_13_53;
 case VARREF:
  deref_and_jump(x1,gen__body__goal_13_12);
  *reasonp++ =  x1;
  goto gen__body__goal_13_53;
  };
  goto gen__body__goal_13_53;
 case symval(makesym(atom_generic)):
  x1 = arg(a0, 1);
 gen__body__goal_13_20:
  switch (ptagof(x1)) {
 case ATOMIC:
 gen__body__goal_13_22:
  if (x1 != makeint(2L)) goto gen__body__goal_13_53;
  x2 = arg(a0, 2);
 gen__body__goal_13_24:
  switch (ptagof(x2)) {
 case CONS:
  x3 = cdr_of(x2);
 gen__body__goal_13_26:
  switch (ptagof(x3)) {
 case CONS:
  x4 = car_of(x3);
 gen__body__goal_13_28:
  switch (ptagof(x4)) {
 case FUNCTOR:
  switch (symval(functor_of(x4))) {
 case functor_mkfunct_2:
  x5 = arg(x4, 0);
 gen__body__goal_13_31:
  switch (ptagof(x5)) {
 case FUNCTOR:
  if (functor_of(x5) != makesym(functor__2F_2)) goto gen__body__goal_13_53;
  x6 = cdr_of(x3);
 gen__body__goal_13_34:
  switch (ptagof(x6)) {
 case ATOMIC:
  if (x6 != NILATOM) goto gen__body__goal_13_53;
  x7 = arg(x5, 1);
  bblt_add_no_check_y(x7,makeint(1L),x8);
  x10 = arg(x4, 1);
  allocp[0] = x10;
  x11 = car_of(x2);
  allocp[1] = x11;
  x9 = makecons(&allocp[0]);
  allocp[2] = makesym(functor_gcall_3);
  x13 = arg(x5, 0);
  allocp[3] = x13;
  allocp[4] = x8;
  allocp[5] = x9;
  x12 = makefunctor(&allocp[2]);
  a0 = x12;
  allocp += 6;
  execute(gen__body__goal_13_0);
  goto gen__body__goal_13_ext_interrupt;
 case VARREF:
  deref_and_jump(x6,gen__body__goal_13_34);
  *reasonp++ =  x6;
  goto gen__body__goal_13_53;
  };
  goto gen__body__goal_13_53;
 case VARREF:
  deref_and_jump(x5,gen__body__goal_13_31);
  *reasonp++ =  x5;
  goto gen__body__goal_13_53;
  };
  goto gen__body__goal_13_53;
 case functor_atom_1:
  x5 = cdr_of(x3);
 gen__body__goal_13_39:
  switch (ptagof(x5)) {
 case ATOMIC:
  if (x5 != NILATOM) goto gen__body__goal_13_53;
  allocp[0] = NILATOM;
  x7 = car_of(x2);
  allocp[1] = x7;
  x6 = makecons(&allocp[0]);
  allocp[2] = makesym(functor_gcall_3);
  x9 = arg(x4, 0);
  allocp[3] = x9;
  allocp[4] = makeint(1L);
  allocp[5] = x6;
  x8 = makefunctor(&allocp[2]);
  a0 = x8;
  allocp += 6;
  execute(gen__body__goal_13_0);
  goto gen__body__goal_13_ext_interrupt;
 case VARREF:
  deref_and_jump(x5,gen__body__goal_13_39);
  *reasonp++ =  x5;
  goto gen__body__goal_13_53;
  };
  goto gen__body__goal_13_53;
 case functor_functor_1:
  x5 = cdr_of(x3);
 gen__body__goal_13_44:
  switch (ptagof(x5)) {
 case ATOMIC:
  if (x5 != NILATOM) goto gen__body__goal_13_53;
  x6 = arg(x4, 0);
 gen__body__goal_13_48:
  if (isref(x6)) goto gen__body__goal_13_52;
  gblt_pfunctor(x6,x7,gen__body__goal_13_53);
  gblt_arity(x6,x8,gen__body__goal_13_53);
  bblt_add_no_check(x8,makeint(1L),x9);
  allocp[0] = x11 = makeref(&allocp[0]);
  x12 = car_of(x2);
  allocp[1] = x12;
  x10 = makecons(&allocp[0]);
  allocp[2] = makesym(functor_gcall_3);
  allocp[3] = x7;
  allocp[4] = x9;
  allocp[5] = x10;
  x13 = makefunctor(&allocp[2]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_klic__comp__generate_xgen__body__goal_13);
  allocp[8] = x13;
  allocp[9] = a1;
  allocp[10] = a2;
  allocp[11] = a3;
  allocp[12] = a4;
  allocp[13] = a5;
  allocp[14] = a6;
  allocp[15] = a7;
  allocp[16] = a8;
  allocp[17] = a9;
  allocp[18] = a10;
  allocp[19] = a11;
  allocp[20] = a12;
  allocp[21] = x11;
  allocp[22] = x15 = makeref(&allocp[22]);
  x14 = makecons(&allocp[21]);
  allocp[23] = (q)(struct goalrec*)&allocp[6];
  allocp[24] = (q)(&predicate_klic__comp__util_xuniv_2);
  allocp[25] = x6;
  allocp[26] = x14;
  qp = (struct goalrec*)&allocp[23];
  allocp += 27;
  proceed();
 gen__body__goal_13_52:
  deref_and_jump(x6,gen__body__goal_13_48);
  *reasonp++ =  x6;
  goto gen__body__goal_13_53;
 case VARREF:
  deref_and_jump(x5,gen__body__goal_13_44);
  *reasonp++ =  x5;
  goto gen__body__goal_13_53;
  };
  goto gen__body__goal_13_53;
 default:
  goto gen__body__goal_13_53;
  };
 case VARREF:
  deref_and_jump(x4,gen__body__goal_13_28);
  *reasonp++ =  x4;
  goto gen__body__goal_13_53;
  };
  goto gen__body__goal_13_53;
 case VARREF:
  deref_and_jump(x3,gen__body__goal_13_26);
  *reasonp++ =  x3;
  goto gen__body__goal_13_53;
  };
  goto gen__body__goal_13_53;
 case VARREF:
  deref_and_jump(x2,gen__body__goal_13_24);
  *reasonp++ =  x2;
  goto gen__body__goal_13_53;
  };
  goto gen__body__goal_13_53;
 case VARREF:
  deref_and_jump(x1,gen__body__goal_13_20);
  *reasonp++ =  x1;
  goto gen__body__goal_13_53;
  };
  goto gen__body__goal_13_53;
 default:
  goto gen__body__goal_13_53;
  };
 case VARREF:
  deref_and_jump(x0,gen__body__goal_13_8);
  *reasonp++ =  x0;
  goto gen__body__goal_13_53;
  };
  goto gen__body__goal_13_53;
 default:
  goto gen__body__goal_13_53;
  };
 case VARREF:
  deref_and_jump(a0,gen__body__goal_13_1);
  *reasonp++ =  a0;
  goto gen__body__goal_13_53;
  };
  goto gen__body__goal_13_53;
 gen__body__goal_13_53:
  otherwise(gen__body__goal_13_interrupt);
 gen__body__goal_13_55:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_gcall_3:
  x0 = arg(a0, 2);
 gen__body__goal_13_58:
  switch (ptagof(x0)) {
 case CONS:
  unify(a4, a3);
  x1 = arg(a0, 1);
  bblt_sub_no_check_y(x1,makeint(1L),x2);
  allocp[0] = makesym(functor__2F_2);
  x4 = arg(a0, 0);
  allocp[1] = x4;
  allocp[2] = x2;
  x3 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_funct_1);
  allocp[4] = x3;
  x5 = makefunctor(&allocp[3]);
  allocp[5] = x7 = makeref(&allocp[5]);
  allocp[6] = x5;
  x6 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a9, x6);
  unify_value(a2, makesym(atom_qp));
  allocp[0] = makesym(functor_r_1);
  allocp[1] = x9 = makeref(&allocp[1]);
  x8 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__2F_2);
  allocp[3] = x4;
  allocp[4] = x2;
  x10 = makefunctor(&allocp[2]);
  allocp[5] = makesym(functor_call__generic_3);
  allocp[6] = x8;
  allocp[7] = x10;
  allocp[8] = a1;
  x11 = makefunctor(&allocp[5]);
  allocp[9] = a12;
  allocp[10] = x11;
  x12 = makecons(&allocp[9]);
  allocp[11] = (q)qp;
  allocp[12] = (q)(&predicate_klic__comp__generate_xload__pos_10);
  x13 = car_of(x0);
  allocp[13] = x13;
  allocp[14] = x9;
  allocp[15] = x14 = makeref(&allocp[15]);
  allocp[16] = a6;
  allocp[17] = x15 = makeref(&allocp[17]);
  allocp[18] = a8;
  allocp[19] = x16 = makeref(&allocp[19]);
  allocp[20] = a10;
  allocp[21] = x17 = makeref(&allocp[21]);
  allocp[22] = x12;
  allocp[23] = (q)(struct goalrec*)&allocp[11];
  allocp[24] = (q)(&predicate_klic__comp__generate_xset__generic__args_10);
  allocp[25] = x18 = makeref(&allocp[25]);
  allocp[26] = makeint(0L);
  allocp[27] = x19 = makeref(&allocp[27]);
  allocp[28] = x14;
  allocp[29] = x20 = makeref(&allocp[29]);
  allocp[30] = x15;
  allocp[31] = x21 = makeref(&allocp[31]);
  allocp[32] = x16;
  allocp[33] = x22 = makeref(&allocp[33]);
  allocp[34] = x17;
  a0 = cdr_of(x0);
  a1 = x18;
  a2 = a5;
  a3 = x19;
  a4 = a7;
  a5 = x20;
  a6 = x7;
  a7 = x21;
  a8 = a11;
  a9 = x22;
  qp = (struct goalrec*)&allocp[23];
  allocp += 35;
  execute(prep__poss_10_0);
  goto prep__poss_10_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,gen__body__goal_13_58);
  *reasonp++ =  x0;
  goto gen__body__goal_13_interrupt;
  };
  goto gen__body__goal_13_interrupt;
 case functor_throw_4:
  unify(a4, a3);
  unify_value(a2, makesym(atom_qp));
  allocp[0] = makesym(functor_throw__goal_3);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = a1;
  allocp[3] = x2 = makeref(&allocp[3]);
  x0 = makefunctor(&allocp[0]);
  allocp[4] = a12;
  allocp[5] = x0;
  x3 = makecons(&allocp[4]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_klic__comp__generate_xload__pos_10);
  x4 = arg(a0, 0);
  allocp[8] = x4;
  allocp[9] = x1;
  allocp[10] = x5 = makeref(&allocp[10]);
  allocp[11] = a6;
  allocp[12] = x6 = makeref(&allocp[12]);
  allocp[13] = a8;
  allocp[14] = x7 = makeref(&allocp[14]);
  allocp[15] = a10;
  allocp[16] = x8 = makeref(&allocp[16]);
  allocp[17] = x3;
  allocp[18] = makesym(functor_heappos_1);
  allocp[19] = x2;
  x9 = makefunctor(&allocp[18]);
  allocp[20] = makesym(functor_set__pred_2);
  x11 = arg(a0, 1);
  allocp[21] = x11;
  x12 = arg(a0, 2);
  allocp[22] = x12;
  x10 = makefunctor(&allocp[20]);
  allocp[23] = NILATOM;
  allocp[24] = x10;
  x13 = makecons(&allocp[23]);
  allocp[25] = x13;
  allocp[26] = x9;
  x14 = makecons(&allocp[25]);
  a0 = arg(a0, 3);
  a1 = x14;
  a2 = a5;
  a3 = x5;
  a4 = a7;
  a5 = x6;
  a6 = a9;
  a7 = x7;
  a8 = a11;
  a9 = x8;
  qp = (struct goalrec*)&allocp[6];
  allocp += 27;
  execute(set__call_10_0);
  goto set__call_10_ext_interrupt;
 case functor_xthrow_5:
  unify(a4, a3);
  allocp[0] = makesym(functor__2F_2);
  x1 = arg(a0, 1);
  allocp[1] = x1;
  x2 = arg(a0, 2);
  allocp[2] = x2;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor__2F_2);
  allocp[4] = x0;
  x4 = arg(a0, 3);
  allocp[5] = x4;
  x3 = makefunctor(&allocp[3]);
  allocp[6] = makesym(functor_ext_1);
  allocp[7] = x3;
  x5 = makefunctor(&allocp[6]);
  allocp[8] = x7 = makeref(&allocp[8]);
  allocp[9] = x5;
  x6 = makecons(&allocp[8]);
  allocp += 10;
  unify_value(a9, x6);
  unify_value(a2, makesym(atom_qp));
  allocp[0] = makesym(functor_throw__goal_3);
  allocp[1] = x9 = makeref(&allocp[1]);
  allocp[2] = a1;
  allocp[3] = x10 = makeref(&allocp[3]);
  x8 = makefunctor(&allocp[0]);
  allocp[4] = a12;
  allocp[5] = x8;
  x11 = makecons(&allocp[4]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_klic__comp__generate_xload__pos_10);
  x12 = arg(a0, 0);
  allocp[8] = x12;
  allocp[9] = x9;
  allocp[10] = x13 = makeref(&allocp[10]);
  allocp[11] = a6;
  allocp[12] = x14 = makeref(&allocp[12]);
  allocp[13] = a8;
  allocp[14] = x15 = makeref(&allocp[14]);
  allocp[15] = a10;
  allocp[16] = x16 = makeref(&allocp[16]);
  allocp[17] = x11;
  allocp[18] = makesym(functor_heappos_1);
  allocp[19] = x10;
  x17 = makefunctor(&allocp[18]);
  allocp[20] = makesym(functor_set__ext__pred_3);
  allocp[21] = x1;
  allocp[22] = x2;
  allocp[23] = x4;
  x18 = makefunctor(&allocp[20]);
  allocp[24] = NILATOM;
  allocp[25] = x18;
  x19 = makecons(&allocp[24]);
  allocp[26] = x19;
  allocp[27] = x17;
  x20 = makecons(&allocp[26]);
  a0 = arg(a0, 4);
  a1 = x20;
  a2 = a5;
  a3 = x13;
  a4 = a7;
  a5 = x14;
  a6 = x7;
  a7 = x15;
  a8 = a11;
  a9 = x16;
  qp = (struct goalrec*)&allocp[6];
  allocp += 28;
  execute(set__call_10_0);
  goto set__call_10_ext_interrupt;
 case functor_pcall_4:
  unify(a4, a3);
  unify_value(a2, makesym(atom_qp));
  allocp[0] = x0 = makeref(&allocp[0]);
  allocp[1] = (q)qp;
  allocp[2] = (q)(&predicate_klic__comp__generate_xenq__at__prio_12);
  x1 = arg(a0, 0);
  allocp[3] = x1;
  allocp[4] = makesym(atom_abs);
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a6;
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = a8;
  allocp[9] = x4 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = a1;
  allocp[12] = x0;
  allocp[13] = x5 = makeref(&allocp[13]);
  allocp[14] = a12;
  allocp[15] = makesym(functor_heappos_1);
  allocp[16] = x0;
  x6 = makefunctor(&allocp[15]);
  allocp[17] = makesym(functor_set__pred_2);
  x8 = arg(a0, 1);
  allocp[18] = x8;
  x9 = arg(a0, 2);
  allocp[19] = x9;
  x7 = makefunctor(&allocp[17]);
  allocp[20] = NILATOM;
  allocp[21] = x7;
  x10 = makecons(&allocp[20]);
  allocp[22] = x10;
  allocp[23] = x6;
  x11 = makecons(&allocp[22]);
  a0 = arg(a0, 3);
  a1 = x11;
  a2 = a5;
  a3 = x2;
  a4 = a7;
  a5 = x3;
  a6 = a9;
  a7 = x4;
  a8 = a11;
  a9 = x5;
  qp = (struct goalrec*)&allocp[1];
  allocp += 24;
  execute(set__call_10_0);
  goto set__call_10_ext_interrupt;
 case functor_lcall_4:
  unify(a4, a3);
  unify_value(a2, makesym(atom_qp));
  allocp[0] = x0 = makeref(&allocp[0]);
  allocp[1] = (q)qp;
  allocp[2] = (q)(&predicate_klic__comp__generate_xenq__at__prio_12);
  x1 = arg(a0, 0);
  allocp[3] = x1;
  allocp[4] = makesym(atom_rel);
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a6;
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = a8;
  allocp[9] = x4 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = a1;
  allocp[12] = x0;
  allocp[13] = x5 = makeref(&allocp[13]);
  allocp[14] = a12;
  allocp[15] = makesym(functor_heappos_1);
  allocp[16] = x0;
  x6 = makefunctor(&allocp[15]);
  allocp[17] = makesym(functor_set__pred_2);
  x8 = arg(a0, 1);
  allocp[18] = x8;
  x9 = arg(a0, 2);
  allocp[19] = x9;
  x7 = makefunctor(&allocp[17]);
  allocp[20] = NILATOM;
  allocp[21] = x7;
  x10 = makecons(&allocp[20]);
  allocp[22] = x10;
  allocp[23] = x6;
  x11 = makecons(&allocp[22]);
  a0 = arg(a0, 3);
  a1 = x11;
  a2 = a5;
  a3 = x2;
  a4 = a7;
  a5 = x3;
  a6 = a9;
  a7 = x4;
  a8 = a11;
  a9 = x5;
  qp = (struct goalrec*)&allocp[1];
  allocp += 24;
  execute(set__call_10_0);
  goto set__call_10_ext_interrupt;
 case functor_xpcall_5:
  unify(a4, a3);
  allocp[0] = makesym(functor__2F_2);
  x1 = arg(a0, 1);
  allocp[1] = x1;
  x2 = arg(a0, 2);
  allocp[2] = x2;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor__2F_2);
  allocp[4] = x0;
  x4 = arg(a0, 3);
  allocp[5] = x4;
  x3 = makefunctor(&allocp[3]);
  allocp[6] = makesym(functor_ext_1);
  allocp[7] = x3;
  x5 = makefunctor(&allocp[6]);
  allocp[8] = x7 = makeref(&allocp[8]);
  allocp[9] = x5;
  x6 = makecons(&allocp[8]);
  allocp += 10;
  unify_value(a9, x6);
  unify_value(a2, makesym(atom_qp));
  allocp[0] = x8 = makeref(&allocp[0]);
  allocp[1] = (q)qp;
  allocp[2] = (q)(&predicate_klic__comp__generate_xenq__at__prio_12);
  x9 = arg(a0, 0);
  allocp[3] = x9;
  allocp[4] = makesym(atom_abs);
  allocp[5] = x10 = makeref(&allocp[5]);
  allocp[6] = a6;
  allocp[7] = x11 = makeref(&allocp[7]);
  allocp[8] = a8;
  allocp[9] = x12 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = a1;
  allocp[12] = x8;
  allocp[13] = x13 = makeref(&allocp[13]);
  allocp[14] = a12;
  allocp[15] = makesym(functor_heappos_1);
  allocp[16] = x8;
  x14 = makefunctor(&allocp[15]);
  allocp[17] = makesym(functor_set__ext__pred_3);
  allocp[18] = x1;
  allocp[19] = x2;
  allocp[20] = x4;
  x15 = makefunctor(&allocp[17]);
  allocp[21] = NILATOM;
  allocp[22] = x15;
  x16 = makecons(&allocp[21]);
  allocp[23] = x16;
  allocp[24] = x14;
  x17 = makecons(&allocp[23]);
  a0 = arg(a0, 4);
  a1 = x17;
  a2 = a5;
  a3 = x10;
  a4 = a7;
  a5 = x11;
  a6 = x7;
  a7 = x12;
  a8 = a11;
  a9 = x13;
  qp = (struct goalrec*)&allocp[1];
  allocp += 25;
  execute(set__call_10_0);
  goto set__call_10_ext_interrupt;
 case functor_xlcall_5:
  unify(a4, a3);
  allocp[0] = makesym(functor__2F_2);
  x1 = arg(a0, 1);
  allocp[1] = x1;
  x2 = arg(a0, 2);
  allocp[2] = x2;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor__2F_2);
  allocp[4] = x0;
  x4 = arg(a0, 3);
  allocp[5] = x4;
  x3 = makefunctor(&allocp[3]);
  allocp[6] = makesym(functor_ext_1);
  allocp[7] = x3;
  x5 = makefunctor(&allocp[6]);
  allocp[8] = x7 = makeref(&allocp[8]);
  allocp[9] = x5;
  x6 = makecons(&allocp[8]);
  allocp += 10;
  unify_value(a9, x6);
  unify_value(a2, makesym(atom_qp));
  allocp[0] = x8 = makeref(&allocp[0]);
  allocp[1] = (q)qp;
  allocp[2] = (q)(&predicate_klic__comp__generate_xenq__at__prio_12);
  x9 = arg(a0, 0);
  allocp[3] = x9;
  allocp[4] = makesym(atom_rel);
  allocp[5] = x10 = makeref(&allocp[5]);
  allocp[6] = a6;
  allocp[7] = x11 = makeref(&allocp[7]);
  allocp[8] = a8;
  allocp[9] = x12 = makeref(&allocp[9]);
  allocp[10] = a10;
  allocp[11] = a1;
  allocp[12] = x8;
  allocp[13] = x13 = makeref(&allocp[13]);
  allocp[14] = a12;
  allocp[15] = makesym(functor_heappos_1);
  allocp[16] = x8;
  x14 = makefunctor(&allocp[15]);
  allocp[17] = makesym(functor_set__ext__pred_3);
  allocp[18] = x1;
  allocp[19] = x2;
  allocp[20] = x4;
  x15 = makefunctor(&allocp[17]);
  allocp[21] = NILATOM;
  allocp[22] = x15;
  x16 = makecons(&allocp[21]);
  allocp[23] = x16;
  allocp[24] = x14;
  x17 = makecons(&allocp[23]);
  a0 = arg(a0, 4);
  a1 = x17;
  a2 = a5;
  a3 = x10;
  a4 = a7;
  a5 = x11;
  a6 = x7;
  a7 = x12;
  a8 = a11;
  a9 = x13;
  qp = (struct goalrec*)&allocp[1];
  allocp += 25;
  execute(set__call_10_0);
  goto set__call_10_ext_interrupt;
 default:
  goto gen__body__goal_13_interrupt;
  };
 case VARREF:
  deref_and_jump(a0,gen__body__goal_13_55);
  *reasonp++ =  a0;
  goto gen__body__goal_13_interrupt;
  };
  goto gen__body__goal_13_interrupt;
 gen__body__goal_13_ext_interrupt:
  reasonp = 0l;
 gen__body__goal_13_interrupt:
  toppred = &predicate_klic__comp__generate_xgen__body__goal_13;
  goto interrupt_13;
 }

 set__call_10_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 set__call_10_clear_reason:
  reasonp = reasons;
 set__call_10_0:
  allocp[0] = makesym(functor_make__space_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = a9;
  allocp[3] = x0;
  x2 = makecons(&allocp[2]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = makeint(2L);
  allocp[8] = x1;
  allocp[9] = (q)(struct goalrec*)&allocp[4];
  allocp[10] = (q)(&predicate_klic__comp__util_xlength_2);
  allocp[11] = x4 = makeref(&allocp[11]);
  allocp[12] = x3;
  allocp[13] = (q)(struct goalrec*)&allocp[9];
  allocp[14] = (q)(&predicate_klic__comp__generate_xset__args_10);
  allocp[15] = x4;
  allocp[16] = makeint(0L);
  allocp[17] = x5 = makeref(&allocp[17]);
  allocp[18] = a3;
  allocp[19] = x6 = makeref(&allocp[19]);
  allocp[20] = a5;
  allocp[21] = x7 = makeref(&allocp[21]);
  allocp[22] = a7;
  allocp[23] = x8 = makeref(&allocp[23]);
  allocp[24] = x2;
  allocp[25] = (q)(struct goalrec*)&allocp[13];
  allocp[26] = (q)(&predicate_klic__comp__generate_xset__call__merge_3);
  allocp[27] = a1;
  allocp[28] = x9 = makeref(&allocp[28]);
  allocp[29] = x8;
  a1 = x4;
  a3 = x5;
  a5 = x6;
  a7 = x7;
  a9 = x9;
  qp = (struct goalrec*)&allocp[25];
  allocp += 30;
  execute(prep__poss_10_0);
  goto prep__poss_10_ext_interrupt;
 set__call_10_ext_interrupt:
  reasonp = 0l;
 set__call_10_interrupt:
  toppred = &predicate_klic__comp__generate_xset__call_10;
  goto interrupt_10;
 }

 set__call__merge_3_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  qp = qp->next;
 set__call__merge_3_clear_reason:
  reasonp = reasons;
 set__call__merge_3_0:
 set__call__merge_3_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(set__call__merge_3_0);
  goto set__call__merge_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto set__call__merge_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,set__call__merge_3_1);
  *reasonp++ =  a0;
  goto set__call__merge_3_interrupt;
  };
  goto set__call__merge_3_interrupt;
 set__call__merge_3_ext_interrupt:
  reasonp = 0l;
 set__call__merge_3_interrupt:
  goto interrupt_3;
 }

 enq__at__prio_12_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 enq__at__prio_12_clear_reason:
  reasonp = reasons;
 enq__at__prio_12_0:
 enq__at__prio_12_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_int_1)) goto enq__at__prio_12_4;
  unify3(a7, a6, a5, a4, a3, a2);
  allocp[0] = makesym(functor_int_1);
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makefunctor(&allocp[0]);
  a0 = a1;
  a1 = makesym(atom_no__check);
  a2 = x0;
  a3 = a8;
  a4 = a9;
  a5 = a10;
  a6 = a11;
  allocp += 2;
  execute(prio__code_7_0);
  goto prio__code_7_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,enq__at__prio_12_1);
  *reasonp++ =  a0;
  goto enq__at__prio_12_4;
  };
  goto enq__at__prio_12_4;
 enq__at__prio_12_4:
  otherwise(enq__at__prio_12_interrupt);
  allocp[0] = makesym(functor_r_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__generate_xprio__code_7);
  allocp[4] = a1;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = x0;
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = a9;
  allocp[9] = x4 = makeref(&allocp[9]);
  allocp[10] = a11;
  allocp[11] = (q)(struct goalrec*)&allocp[2];
  allocp[12] = (q)(&predicate_klic__comp__generate_xenq__at__prio_2F12_240_12);
  allocp[13] = x5 = makeref(&allocp[13]);
  allocp[14] = x2;
  allocp[15] = a3;
  allocp[16] = x6 = makeref(&allocp[16]);
  allocp[17] = a5;
  allocp[18] = x7 = makeref(&allocp[18]);
  allocp[19] = a7;
  allocp[20] = x8 = makeref(&allocp[20]);
  allocp[21] = x3;
  allocp[22] = a8;
  allocp[23] = x4;
  allocp[24] = x9 = makeref(&allocp[24]);
  a1 = x1;
  a3 = a2;
  a5 = a4;
  a7 = a6;
  a8 = x8;
  a9 = a10;
  a10 = x9;
  a6 = x7;
  a4 = x6;
  a2 = x5;
  qp = (struct goalrec*)&allocp[11];
  allocp += 25;
  execute(load__reg_11_0);
  goto load__reg_11_ext_interrupt;
 enq__at__prio_12_ext_interrupt:
  reasonp = 0l;
 enq__at__prio_12_interrupt:
  goto interrupt_12;
 }

 enq__at__prio_2F12_240_12_top: {
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 enq__at__prio_2F12_240_12_clear_reason:
  reasonp = reasons;
 enq__at__prio_2F12_240_12_0:
 enq__at__prio_2F12_240_12_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_int)) goto enq__at__prio_2F12_240_12_5;
  unify_value(a1, makesym(atom_no__check));
  unify4(a2, a3, a4, a5, a6, a7, a8, a9);
  unify(a10, a11);
  proceed();
 case VARREF:
  deref_and_jump(a0,enq__at__prio_2F12_240_12_1);
  *reasonp++ =  a0;
  goto enq__at__prio_2F12_240_12_interrupt;
  };
  goto enq__at__prio_2F12_240_12_5;
 enq__at__prio_2F12_240_12_5:
  gblt_diff(a0,makesym(atom_int),enq__at__prio_2F12_240_12_interrupt);
  unify_value(a1, makesym(atom_check));
  unify4(a2, a3, a4, a5, a6, a7, a8, a9);
  unify(a10, a11);
  proceed();
 enq__at__prio_2F12_240_12_ext_interrupt:
  reasonp = 0l;
 enq__at__prio_2F12_240_12_interrupt:
  goto interrupt_12;
 }

 prio__code_7_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 prio__code_7_clear_reason:
  reasonp = reasons;
 prio__code_7_0:
 prio__code_7_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto prio__code_7_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_abs)):
 prio__code_7_5:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (isint(a1)) goto prio__code_7_interrupt;
  switch (symval(a1)) {
 case symval(makesym(atom_no__check)):
  allocp[0] = makesym(functor_enq__at__prio__no__check_3);
  allocp[1] = a2;
  allocp[2] = a3;
  allocp[3] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[4] = a6;
  allocp[5] = x0;
  x1 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a5, x1);
  proceed();
 case symval(makesym(atom_check)):
  allocp[0] = makesym(functor_enq__at__prio_3);
  allocp[1] = a2;
  allocp[2] = a3;
  allocp[3] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[4] = a6;
  allocp[5] = x0;
  x1 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a5, x1);
  proceed();
 default:
  goto prio__code_7_interrupt;
  };
 case VARREF:
  deref_and_jump(a1,prio__code_7_5);
  *reasonp++ =  a1;
  goto prio__code_7_interrupt;
  };
  goto prio__code_7_interrupt;
 case symval(makesym(atom_rel)):
 prio__code_7_11:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (isint(a1)) goto prio__code_7_interrupt;
  switch (symval(a1)) {
 case symval(makesym(atom_no__check)):
  allocp[0] = makesym(functor_enq__at__lower__prio__no__check_3);
  allocp[1] = a2;
  allocp[2] = a3;
  allocp[3] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[4] = a6;
  allocp[5] = x0;
  x1 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a5, x1);
  proceed();
 case symval(makesym(atom_check)):
  allocp[0] = makesym(functor_enq__at__lower__prio_3);
  allocp[1] = a2;
  allocp[2] = a3;
  allocp[3] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[4] = a6;
  allocp[5] = x0;
  x1 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a5, x1);
  proceed();
 default:
  goto prio__code_7_interrupt;
  };
 case VARREF:
  deref_and_jump(a1,prio__code_7_11);
  *reasonp++ =  a1;
  goto prio__code_7_interrupt;
  };
  goto prio__code_7_interrupt;
 default:
  goto prio__code_7_interrupt;
  };
 case VARREF:
  deref_and_jump(a0,prio__code_7_1);
  *reasonp++ =  a0;
  goto prio__code_7_interrupt;
  };
  goto prio__code_7_interrupt;
 prio__code_7_ext_interrupt:
  reasonp = 0l;
 prio__code_7_interrupt:
  toppred = &predicate_klic__comp__generate_xprio__code_7;
  goto interrupt_7;
 }

 body__unify_12_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 body__unify_12_clear_reason:
  reasonp = reasons;
 body__unify_12_0:
 body__unify_12_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_var_1)) goto body__unify_12_7;
 body__unify_12_4:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_var_1)) goto body__unify_12_7;
  unify2(a9, a8, a7, a6);
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a2;
  x0 = makefunctor(&allocp[0]);
  bblt_add_no_check_y(a2,makeint(1L),x1);
  allocp += 2;
  unify(a3, x1);
  allocp[0] = makesym(functor__3A_2);
  allocp[1] = x0;
  allocp[2] = makesym(atom_any);
  x2 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_var_1);
  x4 = arg(a0, 0);
  allocp[4] = x4;
  x3 = makefunctor(&allocp[3]);
  allocp[5] = makesym(functor__3D_2);
  allocp[6] = x3;
  allocp[7] = x2;
  x5 = makefunctor(&allocp[5]);
  allocp[8] = a4;
  allocp[9] = x5;
  x6 = makecons(&allocp[8]);
  allocp[10] = makesym(functor_var_1);
  x8 = arg(a1, 0);
  allocp[11] = x8;
  x7 = makefunctor(&allocp[10]);
  allocp[12] = makesym(functor__3D_2);
  allocp[13] = x7;
  allocp[14] = x2;
  x9 = makefunctor(&allocp[12]);
  allocp[15] = x6;
  allocp[16] = x9;
  x10 = makecons(&allocp[15]);
  allocp += 17;
  unify_value(a5, x10);
  allocp[0] = makesym(functor_alloc__var_2);
  allocp[1] = x0;
  allocp[2] = makeint(0L);
  x11 = makefunctor(&allocp[0]);
  allocp[3] = x13 = makeref(&allocp[3]);
  allocp[4] = x11;
  x12 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a10, x12);
  allocp[0] = a11;
  allocp[1] = makefunctor(funct_const_9);
  x14 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(x13, x14);
  proceed();
 case VARREF:
  deref_and_jump(a1,body__unify_12_4);
  *reasonp++ =  a1;
  goto body__unify_12_7;
  };
  goto body__unify_12_7;
 case VARREF:
  deref_and_jump(a0,body__unify_12_1);
  *reasonp++ =  a0;
  goto body__unify_12_12;
  };
  goto body__unify_12_7;
 body__unify_12_7:
 body__unify_12_8:
  if (isref(a0)) goto body__unify_12_11;
  if_not_equal(a0, a1, body__unify_12_12);
  unify4(a11, a10, a9, a8, a7, a6, a5, a4);
  unify(a3, a2);
  proceed();
 body__unify_12_11:
  deref_and_jump(a0,body__unify_12_8);
  *reasonp++ =  a0;
  goto body__unify_12_12;
 body__unify_12_12:
  otherwise(body__unify_12_interrupt);
 body__unify_12_14:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_var_1)) goto body__unify_12_17;
  unify(a9, a8);
  allocp[0] = makesym(functor__3A_2);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  x0 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor__3D_2);
  allocp[4] = a0;
  allocp[5] = x0;
  x3 = makefunctor(&allocp[3]);
  allocp[6] = a4;
  allocp[7] = x3;
  x4 = makecons(&allocp[6]);
  a0 = a1;
  a1 = x1;
  x5 = a2;
  a4 = a3;
  x6 = a5;
  x7 = a6;
  a8 = a7;
  a9 = a10;
  a10 = a11;
  a7 = x7;
  a6 = x6;
  a5 = x4;
  a3 = x5;
  a2 = x2;
  allocp += 8;
  execute(load__reg_11_0);
  goto load__reg_11_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,body__unify_12_14);
  *reasonp++ =  a0;
  goto body__unify_12_17;
  };
  goto body__unify_12_17;
 body__unify_12_17:
 body__unify_12_18:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_var_1)) goto body__unify_12_21;
  unify(a9, a8);
  allocp[0] = makesym(functor__3A_2);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  x0 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor__3D_2);
  allocp[4] = a1;
  allocp[5] = x0;
  x3 = makefunctor(&allocp[3]);
  allocp[6] = a4;
  allocp[7] = x3;
  x4 = makecons(&allocp[6]);
  a1 = x1;
  x5 = a2;
  a4 = a3;
  x6 = a5;
  x7 = a6;
  a8 = a7;
  a9 = a10;
  a10 = a11;
  a7 = x7;
  a6 = x6;
  a5 = x4;
  a3 = x5;
  a2 = x2;
  allocp += 8;
  execute(load__reg_11_clear_reason);
  goto load__reg_11_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,body__unify_12_18);
  *reasonp++ =  a1;
  goto body__unify_12_21;
  };
  goto body__unify_12_21;
 body__unify_12_21:
  otherwise(body__unify_12_interrupt);
  unify_value(a9, makesym(atom_qp));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xbody__unify__1_11);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a8;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a3;
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = a5;
  allocp[9] = x4 = makeref(&allocp[9]);
  allocp[10] = a7;
  allocp[11] = x5 = makeref(&allocp[11]);
  allocp[12] = a11;
  allocp[13] = (q)(struct goalrec*)&allocp[0];
  allocp[14] = (q)(&predicate_klic__comp__generate_xprep__call__arg_10);
  allocp[15] = a1;
  allocp[16] = x6 = makeref(&allocp[16]);
  allocp[17] = x2;
  allocp[18] = x7 = makeref(&allocp[18]);
  allocp[19] = x3;
  allocp[20] = x8 = makeref(&allocp[20]);
  allocp[21] = x4;
  allocp[22] = x1;
  allocp[23] = x9 = makeref(&allocp[23]);
  allocp[24] = x5;
  a1 = a2;
  a2 = x6;
  a3 = a4;
  a4 = x7;
  a5 = a6;
  a6 = x8;
  a7 = x0;
  a8 = a10;
  a9 = x9;
  qp = (struct goalrec*)&allocp[13];
  allocp += 25;
  execute(prep__call__arg_10_0);
  goto prep__call__arg_10_ext_interrupt;
 body__unify_12_ext_interrupt:
  reasonp = 0l;
 body__unify_12_interrupt:
  goto interrupt_12;
 }

 body__unify__1_11_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 body__unify__1_11_clear_reason:
  reasonp = reasons;
 body__unify__1_11_0:
 body__unify__1_11_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor__3A_2)) goto body__unify__1_11_7;
 body__unify__1_11_4:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor__3A_2)) goto body__unify__1_11_7;
  unify3(a8, a7, a6, a5, a4, a3);
  x0 = arg(a0, 0);
  x1 = arg(a0, 1);
  x2 = arg(a1, 0);
  a3 = arg(a1, 1);
  a4 = a2;
  a5 = a9;
  a6 = a10;
  a2 = x2;
  a1 = x1;
  a0 = x0;
  execute(body__unify__2_7_0);
  goto body__unify__2_7_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,body__unify__1_11_4);
  *reasonp++ =  a1;
  goto body__unify__1_11_7;
  };
  goto body__unify__1_11_7;
 case VARREF:
  deref_and_jump(a0,body__unify__1_11_1);
  *reasonp++ =  a0;
  goto body__unify__1_11_7;
  };
  goto body__unify__1_11_7;
 body__unify__1_11_7:
  otherwise(body__unify__1_11_interrupt);
 body__unify__1_11_9:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor__3A_2)) goto body__unify__1_11_12;
  unify3(a8, a7, a6, a5, a4, a3);
  x0 = makesym(atom_known);
  x1 = arg(a0, 0);
  x2 = arg(a0, 1);
  x3 = a1;
  a3 = x0;
  a4 = a2;
  a5 = a9;
  a6 = a10;
  a2 = x3;
  a1 = x2;
  a0 = x1;
  execute(body__unify__2_7_0);
  goto body__unify__2_7_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,body__unify__1_11_9);
  *reasonp++ =  a0;
  goto body__unify__1_11_12;
  };
  goto body__unify__1_11_12;
 body__unify__1_11_12:
 body__unify__1_11_13:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor__3A_2)) goto body__unify__1_11_16;
  unify3(a8, a7, a6, a5, a4, a3);
  x0 = makesym(atom_known);
  x1 = arg(a1, 0);
  a3 = arg(a1, 1);
  a4 = a2;
  a5 = a9;
  a6 = a10;
  a2 = x1;
  a1 = x0;
  execute(body__unify__2_7_clear_reason);
  goto body__unify__2_7_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,body__unify__1_11_13);
  *reasonp++ =  a1;
  goto body__unify__1_11_16;
  };
  goto body__unify__1_11_16;
 body__unify__1_11_16:
  otherwise(body__unify__1_11_interrupt);
  allocp[0] = makesym(functor_r_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__3A_2);
  allocp[3] = x0;
  allocp[4] = x3 = makeref(&allocp[4]);
  x2 = makefunctor(&allocp[2]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_klic__comp__generate_xbody__unify__1_11);
  allocp[7] = x2;
  allocp[8] = a1;
  allocp[9] = a2;
  allocp[10] = x4 = makeref(&allocp[10]);
  allocp[11] = a4;
  allocp[12] = x5 = makeref(&allocp[12]);
  allocp[13] = a6;
  allocp[14] = x6 = makeref(&allocp[14]);
  allocp[15] = a8;
  allocp[16] = x7 = makeref(&allocp[16]);
  allocp[17] = a10;
  a1 = x1;
  a2 = x3;
  a4 = x4;
  a6 = x5;
  a8 = x6;
  a10 = x7;
  qp = (struct goalrec*)&allocp[5];
  allocp += 18;
  execute(load__reg_11_0);
  goto load__reg_11_ext_interrupt;
 body__unify__1_11_ext_interrupt:
  reasonp = 0l;
 body__unify__1_11_interrupt:
  goto interrupt_11;
 }

 body__unify__2_7_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 body__unify__2_7_clear_reason:
  reasonp = reasons;
 body__unify__2_7_0:
 body__unify__2_7_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_any)) goto body__unify__2_7_9;
 body__unify__2_7_5:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_any)) goto body__unify__2_7_9;
  allocp[0] = makesym(functor_unify_3);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[4] = a6;
  allocp[5] = x0;
  x1 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a5, x1);
  proceed();
 case VARREF:
  deref_and_jump(a3,body__unify__2_7_5);
  *reasonp++ =  a3;
  goto body__unify__2_7_9;
  };
  goto body__unify__2_7_9;
 case VARREF:
  deref_and_jump(a1,body__unify__2_7_1);
  *reasonp++ =  a1;
  goto body__unify__2_7_9;
  };
  goto body__unify__2_7_9;
 body__unify__2_7_9:
  otherwise(body__unify__2_7_interrupt);
 body__unify__2_7_11:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_any)) goto body__unify__2_7_15;
  allocp[0] = makesym(functor_unify__value_3);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[4] = a6;
  allocp[5] = x0;
  x1 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a5, x1);
  proceed();
 case VARREF:
  deref_and_jump(a1,body__unify__2_7_11);
  *reasonp++ =  a1;
  goto body__unify__2_7_15;
  };
  goto body__unify__2_7_15;
 body__unify__2_7_15:
 body__unify__2_7_16:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_any)) goto body__unify__2_7_20;
  allocp[0] = makesym(functor_unify__value_3);
  allocp[1] = a2;
  allocp[2] = a0;
  allocp[3] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[4] = a6;
  allocp[5] = x0;
  x1 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a5, x1);
  proceed();
 case VARREF:
  deref_and_jump(a3,body__unify__2_7_16);
  *reasonp++ =  a3;
  goto body__unify__2_7_20;
  };
  goto body__unify__2_7_20;
 body__unify__2_7_20:
  otherwise(body__unify__2_7_interrupt);
  allocp[0] = makesym(functor_unify_3);
  allocp[1] = a0;
  allocp[2] = a2;
  allocp[3] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[4] = a6;
  allocp[5] = x0;
  x1 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a5, x1);
  proceed();
 body__unify__2_7_ext_interrupt:
  reasonp = 0l;
 body__unify__2_7_interrupt:
  toppred = &predicate_klic__comp__generate_xbody__unify__2_7;
  goto interrupt_7;
 }

 bb__in_14_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20, x21, x22;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  qp = qp->next;
 bb__in_14_clear_reason:
  reasonp = reasons;
 bb__in_14_0:
 bb__in_14_1:
  switch (ptagof(a0)) {
 case CONS:
 bb__in_14_3:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = x2 = makeref(&allocp[1]);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a5, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xbb__in_14);
  x3 = cdr_of(a0);
  allocp[2] = x3;
  x4 = cdr_of(a1);
  allocp[3] = x4;
  allocp[4] = a2;
  allocp[5] = x5 = makeref(&allocp[5]);
  allocp[6] = x6 = makeref(&allocp[6]);
  allocp[7] = x1;
  allocp[8] = x7 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x8 = makeref(&allocp[10]);
  allocp[11] = a9;
  allocp[12] = x9 = makeref(&allocp[12]);
  allocp[13] = a11;
  allocp[14] = x10 = makeref(&allocp[14]);
  allocp[15] = a13;
  allocp[16] = (q)(struct goalrec*)&allocp[0];
  allocp[17] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[18] = a3;
  allocp[19] = makeint(1L);
  allocp[20] = x5;
  allocp[21] = (q)(struct goalrec*)&allocp[16];
  allocp[22] = (q)(&predicate_klic__comp__generate_xbb__in_2F14_241_12);
  allocp[23] = x11 = makeref(&allocp[23]);
  allocp[24] = a4;
  allocp[25] = x6;
  allocp[26] = x7;
  allocp[27] = x12 = makeref(&allocp[27]);
  allocp[28] = x8;
  allocp[29] = x13 = makeref(&allocp[29]);
  allocp[30] = x9;
  allocp[31] = x14 = makeref(&allocp[31]);
  allocp[32] = x10;
  allocp[33] = x15 = makeref(&allocp[33]);
  allocp[34] = a3;
  allocp[35] = (q)(struct goalrec*)&allocp[21];
  allocp[36] = (q)(&predicate_klic__comp__insert_xsubsumed__type_3);
  allocp[37] = x16 = makeref(&allocp[37]);
  x17 = car_of(a0);
  allocp[38] = x17;
  allocp[39] = x11;
  allocp[40] = (q)(struct goalrec*)&allocp[35];
  allocp[41] = (q)(&predicate_klic__comp__generate_xbb__in_2F14_240_11);
  allocp[42] = x18 = makeref(&allocp[42]);
  allocp[43] = x2;
  allocp[44] = x16;
  allocp[45] = x12;
  allocp[46] = x19 = makeref(&allocp[46]);
  allocp[47] = x13;
  allocp[48] = x20 = makeref(&allocp[48]);
  allocp[49] = x14;
  allocp[50] = x21 = makeref(&allocp[50]);
  allocp[51] = x15;
  allocp[52] = x22 = makeref(&allocp[52]);
  a0 = car_of(a1);
  a1 = a6;
  a2 = x19;
  a3 = a8;
  a4 = x20;
  a5 = a10;
  a6 = x21;
  a7 = x18;
  a8 = a12;
  a9 = x22;
  qp = (struct goalrec*)&allocp[40];
  allocp += 53;
  execute(prep__call__arg_10_0);
  goto prep__call__arg_10_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,bb__in_14_3);
  *reasonp++ =  a1;
  goto bb__in_14_interrupt;
  };
  goto bb__in_14_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto bb__in_14_interrupt;
  unify4(a13, a12, a11, a10, a9, a8, a7, a6);
  unify_value(a4, NILATOM);
  unify_value(a5, NILATOM);
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,bb__in_14_1);
  *reasonp++ =  a0;
  goto bb__in_14_interrupt;
  };
  goto bb__in_14_interrupt;
 bb__in_14_ext_interrupt:
  reasonp = 0l;
 bb__in_14_interrupt:
  goto interrupt_14;
 }

 bb__in_2F14_241_12_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 bb__in_2F14_241_12_clear_reason:
  reasonp = reasons;
 bb__in_2F14_241_12_0:
 bb__in_2F14_241_12_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto bb__in_2F14_241_12_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_normal)):
  unify4(a1, a2, a3, a4, a5, a6, a7, a8);
  unify(a9, a10);
  proceed();
 case symval(makesym(atom_abnormal)):
  allocp[0] = a2;
  allocp[1] = a11;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  unify4(a3, a4, a5, a6, a7, a8, a9, a10);
  proceed();
 default:
  goto bb__in_2F14_241_12_interrupt;
  };
 case VARREF:
  deref_and_jump(a0,bb__in_2F14_241_12_1);
  *reasonp++ =  a0;
  goto bb__in_2F14_241_12_interrupt;
  };
  goto bb__in_2F14_241_12_interrupt;
 bb__in_2F14_241_12_ext_interrupt:
  reasonp = 0l;
 bb__in_2F14_241_12_interrupt:
  goto interrupt_12;
 }

 bb__in_2F14_240_11_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 bb__in_2F14_240_11_clear_reason:
  reasonp = reasons;
 bb__in_2F14_240_11_0:
 bb__in_2F14_240_11_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor__3A_2)) goto bb__in_2F14_240_11_4;
  x0 = arg(a0, 0);
  unify(a1, x0);
  x1 = arg(a0, 1);
  unify4(a2, x1, a3, a4, a5, a6, a7, a8);
  unify(a9, a10);
  proceed();
 case VARREF:
  deref_and_jump(a0,bb__in_2F14_240_11_1);
  *reasonp++ =  a0;
  goto bb__in_2F14_240_11_4;
  };
  goto bb__in_2F14_240_11_4;
 bb__in_2F14_240_11_4:
  otherwise(bb__in_2F14_240_11_interrupt);
  unify4(a1, a0, a2, a0, a3, a4, a5, a6);
  unify2(a7, a8, a9, a10);
  proceed();
 bb__in_2F14_240_11_ext_interrupt:
  reasonp = 0l;
 bb__in_2F14_240_11_interrupt:
  goto interrupt_11;
 }

 bb__out_14_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  qp = qp->next;
 bb__out_14_clear_reason:
  reasonp = reasons;
 bb__out_14_0:
 bb__out_14_1:
  switch (ptagof(a0)) {
 case CONS:
 bb__out_14_3:
  switch (ptagof(a2)) {
 case CONS:
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a4;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_r_1);
  allocp[3] = x0;
  x1 = makefunctor(&allocp[2]);
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = x1;
  x2 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a3, x2);
  bblt_add_no_check_y(a4,makeint(1L),x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xbb__out_14);
  x5 = cdr_of(a0);
  allocp[2] = x5;
  allocp[3] = a1;
  x6 = cdr_of(a2);
  allocp[4] = x6;
  allocp[5] = x3;
  allocp[6] = x7 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x8 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x9 = makeref(&allocp[10]);
  allocp[11] = a9;
  allocp[12] = x10 = makeref(&allocp[12]);
  allocp[13] = a11;
  allocp[14] = x11 = makeref(&allocp[14]);
  allocp[15] = a13;
  allocp[16] = makesym(functor__3A_2);
  allocp[17] = x1;
  allocp[18] = x13 = makeref(&allocp[18]);
  x12 = makefunctor(&allocp[16]);
  allocp[19] = (q)(struct goalrec*)&allocp[0];
  allocp[20] = (q)(&predicate_klic__comp__generate_xbody__unify_12);
  x14 = car_of(a0);
  allocp[21] = x14;
  allocp[22] = x12;
  allocp[23] = x15 = makeref(&allocp[23]);
  allocp[24] = x7;
  allocp[25] = x16 = makeref(&allocp[25]);
  allocp[26] = x8;
  allocp[27] = x17 = makeref(&allocp[27]);
  allocp[28] = x9;
  allocp[29] = x18 = makeref(&allocp[29]);
  allocp[30] = x10;
  allocp[31] = x19 = makeref(&allocp[31]);
  allocp[32] = x11;
  a0 = a1;
  a1 = x13;
  a2 = car_of(a2);
  a3 = x15;
  a4 = x4;
  a5 = x16;
  a7 = x17;
  a9 = x18;
  a11 = x19;
  qp = (struct goalrec*)&allocp[19];
  allocp += 33;
  execute(bb__out_2F14_240_13_0);
  goto bb__out_2F14_240_13_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,bb__out_14_3);
  *reasonp++ =  a2;
  goto bb__out_14_interrupt;
  };
  goto bb__out_14_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto bb__out_14_interrupt;
 bb__out_14_8:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (a2 != NILATOM) goto bb__out_14_interrupt;
  unify4(a13, a12, a11, a10, a9, a8, a7, a6);
  unify(a5, a4);
  unify_value(a3, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a2,bb__out_14_8);
  *reasonp++ =  a2;
  goto bb__out_14_interrupt;
  };
  goto bb__out_14_interrupt;
 case VARREF:
  deref_and_jump(a0,bb__out_14_1);
  *reasonp++ =  a0;
  goto bb__out_14_interrupt;
  };
  goto bb__out_14_interrupt;
 bb__out_14_ext_interrupt:
  reasonp = 0l;
 bb__out_14_interrupt:
  goto interrupt_14;
 }

 bb__out_2F14_240_13_top: {
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  qp = qp->next;
 bb__out_2F14_240_13_clear_reason:
  reasonp = reasons;
 bb__out_2F14_240_13_0:
 bb__out_2F14_240_13_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != NILATOM) goto bb__out_2F14_240_13_5;
  unify4(a1, a2, a3, a4, a5, a6, a7, a8);
  unify2(a9, a10, a11, a12);
  proceed();
 case VARREF:
  deref_and_jump(a0,bb__out_2F14_240_13_1);
  *reasonp++ =  a0;
  goto bb__out_2F14_240_13_interrupt;
  };
  goto bb__out_2F14_240_13_5;
 bb__out_2F14_240_13_5:
  gblt_diff(a0,NILATOM,bb__out_2F14_240_13_interrupt);
  unify_value(a1, makesym(atom_any));
  unify4(a3, a4, a5, a6, a7, a8, a9, a10);
  unify(a11, a12);
  proceed();
 bb__out_2F14_240_13_ext_interrupt:
  reasonp = 0l;
 bb__out_2F14_240_13_interrupt:
  toppred = &predicate_klic__comp__generate_xbb__out_2F14_240_13;
  goto interrupt_13;
 }

 prep__call__arg_10_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 prep__call__arg_10_clear_reason:
  reasonp = reasons;
 prep__call__arg_10_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xprep__call__arg__on__need_11);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = x0 = makeref(&allocp[10]);
  allocp[11] = a8;
  allocp[12] = a9;
  a1 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 13;
  execute(prep__needed_2_0);
  goto prep__needed_2_ext_interrupt;
 prep__call__arg_10_ext_interrupt:
  reasonp = 0l;
 prep__call__arg_10_interrupt:
  toppred = &predicate_klic__comp__generate_xprep__call__arg_10;
  goto interrupt_10;
 }

 prep__needed_2_top: {
  qp = qp->next;
 prep__needed_2_clear_reason:
  reasonp = reasons;
 prep__needed_2_0:
 prep__needed_2_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_var_1:
  unify_value(a1, makesym(atom_yes));
  proceed();
 case functor_arg_2:
  unify_value(a1, makesym(atom_yes));
  proceed();
 default:
  goto prep__needed_2_5;
  };
 case VARREF:
  deref_and_jump(a0,prep__needed_2_1);
  *reasonp++ =  a0;
  goto prep__needed_2_5;
  };
  goto prep__needed_2_5;
 prep__needed_2_5:
  otherwise(prep__needed_2_interrupt);
  unify_value(a1, makesym(atom_no));
  proceed();
 prep__needed_2_ext_interrupt:
  reasonp = 0l;
 prep__needed_2_interrupt:
  toppred = &predicate_klic__comp__generate_xprep__needed_2;
  goto interrupt_2;
 }

 prep__call__arg__on__need_11_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 prep__call__arg__on__need_11_clear_reason:
  reasonp = reasons;
 prep__call__arg__on__need_11_0:
 prep__call__arg__on__need_11_1:
  switch (ptagof(a8)) {
 case ATOMIC:
  if (isint(a8)) goto prep__call__arg__on__need_11_interrupt;
  switch (symval(a8)) {
 case symval(makesym(atom_yes)):
  allocp[0] = makesym(functor_r_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__3A_2);
  allocp[3] = x0;
  allocp[4] = x3 = makeref(&allocp[4]);
  x2 = makefunctor(&allocp[2]);
  allocp += 5;
  unify_value(a7, x2);
  x4 = a1;
  x5 = a2;
  x6 = a3;
  x7 = a4;
  a7 = a5;
  a8 = a6;
  a6 = x7;
  a5 = x6;
  a4 = x5;
  a3 = x4;
  a2 = x3;
  a1 = x1;
  execute(load__reg_11_0);
  goto load__reg_11_ext_interrupt;
 case symval(makesym(atom_no)):
  unify4(a10, a9, a6, a5, a4, a3, a2, a1);
  unify(a7, a0);
  proceed();
 default:
  goto prep__call__arg__on__need_11_interrupt;
  };
 case VARREF:
  deref_and_jump(a8,prep__call__arg__on__need_11_1);
  *reasonp++ =  a8;
  goto prep__call__arg__on__need_11_interrupt;
  };
  goto prep__call__arg__on__need_11_interrupt;
 prep__call__arg__on__need_11_ext_interrupt:
  reasonp = 0l;
 prep__call__arg__on__need_11_interrupt:
  goto interrupt_11;
 }

 set__args_10_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 set__args_10_clear_reason:
  reasonp = reasons;
 set__args_10_0:
 set__args_10_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xset__args_10);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x5 = makeref(&allocp[10]);
  allocp[11] = a9;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[14] = a1;
  allocp[15] = makeint(1L);
  allocp[16] = x1;
  a0 = car_of(a0);
  a3 = x2;
  a5 = x3;
  a7 = x4;
  a9 = x5;
  qp = (struct goalrec*)&allocp[12];
  allocp += 17;
  execute(set__one_10_0);
  goto set__one_10_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto set__args_10_interrupt;
  unify4(a9, a8, a7, a6, a5, a4, a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,set__args_10_1);
  *reasonp++ =  a0;
  goto set__args_10_interrupt;
  };
  goto set__args_10_interrupt;
 set__args_10_ext_interrupt:
  reasonp = 0l;
 set__args_10_interrupt:
  goto interrupt_10;
 }

 set__one_10_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 set__one_10_clear_reason:
  reasonp = reasons;
 set__one_10_0:
 set__one_10_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor__3A_2)) goto set__one_10_7;
  x0 = arg(a0, 0);
 set__one_10_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_r_1)) goto set__one_10_7;
  unify3(a7, a6, a5, a4, a3, a2);
  allocp[0] = makesym(functor_set__value_2);
  allocp[1] = a1;
  x2 = arg(x0, 0);
  allocp[2] = x2;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a9;
  allocp[4] = x1;
  x3 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a8, x3);
  proceed();
 case VARREF:
  deref_and_jump(x0,set__one_10_4);
  *reasonp++ =  x0;
  goto set__one_10_7;
  };
  goto set__one_10_7;
 case VARREF:
  deref_and_jump(a0,set__one_10_1);
  *reasonp++ =  a0;
  goto set__one_10_7;
  };
  goto set__one_10_7;
 set__one_10_7:
  otherwise(set__one_10_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xset__one__1_10);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  x1 = a4;
  a1 = a0;
  a2 = x0;
  a0 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  execute(assocx_3_0);
  goto assocx_3_ext_interrupt;
 set__one_10_ext_interrupt:
  reasonp = 0l;
 set__one_10_interrupt:
  toppred = &predicate_klic__comp__generate_xset__one_10;
  goto interrupt_10;
 }

 set__one__1_10_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 set__one__1_10_clear_reason:
  reasonp = reasons;
 set__one__1_10_0:
 set__one__1_10_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_yes_1:
  x0 = arg(a0, 0);
 set__one__1_10_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__3A_2)) goto set__one__1_10_interrupt;
  allocp[0] = makesym(functor_r_1);
  x2 = arg(x0, 0);
  allocp[1] = x2;
  x1 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__3A_2);
  allocp[3] = x1;
  x4 = arg(x0, 1);
  allocp[4] = x4;
  x3 = makefunctor(&allocp[2]);
  a0 = x3;
  allocp += 5;
  execute(set__one_10_0);
  goto set__one_10_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,set__one__1_10_4);
  *reasonp++ =  x0;
  goto set__one__1_10_interrupt;
  };
  goto set__one__1_10_interrupt;
 case functor_no_1:
  x0 = arg(a0, 0);
 set__one__1_10_8:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_atom_1:
  unify3(a7, a6, a5, a4, a3, a2);
  allocp[0] = makesym(functor_set__atomic_2);
  allocp[1] = a1;
  x2 = arg(x0, 0);
  allocp[2] = x2;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a9;
  allocp[4] = x1;
  x3 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a8, x3);
  proceed();
 case functor_int_1:
  unify3(a7, a6, a5, a4, a3, a2);
  allocp[0] = makesym(functor_set__atomic_2);
  allocp[1] = a1;
  x2 = arg(x0, 0);
  allocp[2] = x2;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a9;
  allocp[4] = x1;
  x3 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a8, x3);
  proceed();
 case functor_arg_2:
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a2;
  x1 = makefunctor(&allocp[0]);
  bblt_add_no_check_y(a2,makeint(1L),x2);
  allocp[2] = makesym(functor__3A_2);
  allocp[3] = x1;
  allocp[4] = makesym(atom_any);
  x3 = makefunctor(&allocp[2]);
  allocp[5] = makesym(functor__3D_2);
  allocp[6] = x0;
  allocp[7] = x3;
  x4 = makefunctor(&allocp[5]);
  allocp[8] = a4;
  allocp[9] = x4;
  x5 = makecons(&allocp[8]);
  allocp[10] = makesym(functor_set__value_2);
  allocp[11] = a1;
  allocp[12] = x1;
  x6 = makefunctor(&allocp[10]);
  allocp[13] = a9;
  allocp[14] = x6;
  x7 = makecons(&allocp[13]);
  allocp[15] = makesym(functor_get__elem_3);
  allocp[16] = x1;
  allocp[17] = x9 = makeref(&allocp[17]);
  x10 = arg(x0, 1);
  allocp[18] = x10;
  x8 = makefunctor(&allocp[15]);
  allocp[19] = x7;
  allocp[20] = x8;
  x11 = makecons(&allocp[19]);
  a0 = arg(x0, 0);
  a1 = x9;
  a2 = x2;
  a4 = x5;
  a9 = x11;
  allocp += 21;
  execute(load__pos_10_0);
  goto load__pos_10_ext_interrupt;
 case functor_var_1:
  unify(a7, a6);
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a2;
  x1 = makefunctor(&allocp[0]);
  bblt_add_no_check_y(a2,makeint(1L),x2);
  allocp += 2;
  unify(a3, x2);
  allocp[0] = makesym(functor__3A_2);
  allocp[1] = x1;
  allocp[2] = makesym(atom_any);
  x3 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor__3D_2);
  allocp[4] = x0;
  allocp[5] = x3;
  x4 = makefunctor(&allocp[3]);
  allocp[6] = a4;
  allocp[7] = x4;
  x5 = makecons(&allocp[6]);
  allocp += 8;
  unify_value(a5, x5);
  allocp[0] = makesym(functor_set__newvar_2);
  allocp[1] = a1;
  allocp[2] = x1;
  x6 = makefunctor(&allocp[0]);
  allocp[3] = a9;
  allocp[4] = x6;
  x7 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a8, x7);
  proceed();
 case functor_const_1:
  unify3(a7, a6, a5, a4, a3, a2);
  allocp[0] = makesym(functor_set__const_2);
  allocp[1] = a1;
  allocp[2] = x0;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a9;
  allocp[4] = x1;
  x2 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a8, x2);
  proceed();
 default:
  goto set__one__1_10_interrupt;
  };
 case VARREF:
  deref_and_jump(x0,set__one__1_10_8);
  *reasonp++ =  x0;
  goto set__one__1_10_interrupt;
  };
  goto set__one__1_10_interrupt;
 default:
  goto set__one__1_10_interrupt;
  };
 case VARREF:
  deref_and_jump(a0,set__one__1_10_1);
  *reasonp++ =  a0;
  goto set__one__1_10_interrupt;
  };
  goto set__one__1_10_interrupt;
 set__one__1_10_ext_interrupt:
  reasonp = 0l;
 set__one__1_10_interrupt:
  goto interrupt_10;
 }

 set__generic__args_10_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 set__generic__args_10_clear_reason:
  reasonp = reasons;
 set__generic__args_10_0:
 set__generic__args_10_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xset__generic__args_10);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x5 = makeref(&allocp[10]);
  allocp[11] = a9;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[14] = a1;
  allocp[15] = makeint(1L);
  allocp[16] = x1;
  allocp[17] = makesym(functor_store__generic__arg_2);
  allocp[18] = x7 = makeref(&allocp[18]);
  allocp[19] = a1;
  x6 = makefunctor(&allocp[17]);
  allocp[20] = x5;
  allocp[21] = x6;
  x8 = makecons(&allocp[20]);
  allocp[22] = (q)(struct goalrec*)&allocp[12];
  allocp[23] = (q)(&predicate_klic__comp__generate_xset__generic__args_2F10_240_10);
  allocp[24] = x9 = makeref(&allocp[24]);
  allocp[25] = x7;
  allocp[26] = x2;
  allocp[27] = x10 = makeref(&allocp[27]);
  allocp[28] = x3;
  allocp[29] = x11 = makeref(&allocp[29]);
  allocp[30] = x4;
  allocp[31] = x12 = makeref(&allocp[31]);
  allocp[32] = x8;
  allocp[33] = x13 = makeref(&allocp[33]);
  a0 = car_of(a0);
  a1 = a2;
  a2 = x10;
  a3 = a4;
  a4 = x11;
  a5 = a6;
  a6 = x12;
  a7 = x9;
  a9 = x13;
  qp = (struct goalrec*)&allocp[22];
  allocp += 34;
  execute(prep__call__arg_10_0);
  goto prep__call__arg_10_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto set__generic__args_10_interrupt;
  unify4(a9, a8, a7, a6, a5, a4, a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,set__generic__args_10_1);
  *reasonp++ =  a0;
  goto set__generic__args_10_interrupt;
  };
  goto set__generic__args_10_interrupt;
 set__generic__args_10_ext_interrupt:
  reasonp = 0l;
 set__generic__args_10_interrupt:
  goto interrupt_10;
 }

 set__generic__args_2F10_240_10_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 set__generic__args_2F10_240_10_clear_reason:
  reasonp = reasons;
 set__generic__args_2F10_240_10_0:
 set__generic__args_2F10_240_10_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor__3A_2)) goto set__generic__args_2F10_240_10_4;
  x0 = arg(a0, 0);
  unify4(a1, x0, a2, a3, a4, a5, a6, a7);
  unify(a8, a9);
  proceed();
 case VARREF:
  deref_and_jump(a0,set__generic__args_2F10_240_10_1);
  *reasonp++ =  a0;
  goto set__generic__args_2F10_240_10_4;
  };
  goto set__generic__args_2F10_240_10_4;
 set__generic__args_2F10_240_10_4:
  otherwise(set__generic__args_2F10_240_10_interrupt);
  unify4(a1, a0, a2, a3, a4, a5, a6, a7);
  unify(a8, a9);
  proceed();
 set__generic__args_2F10_240_10_ext_interrupt:
  reasonp = 0l;
 set__generic__args_2F10_240_10_interrupt:
  goto interrupt_10;
 }

 move__args_10_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 move__args_10_clear_reason:
  reasonp = reasons;
 move__args_10_0:
 move__args_10_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xmove__args__1_12);
  allocp[2] = x0 = makeref(&allocp[2]);
  x1 = car_of(a0);
  allocp[3] = x1;
  x2 = cdr_of(a0);
  allocp[4] = x2;
  allocp[5] = a1;
  allocp[6] = a2;
  allocp[7] = a3;
  allocp[8] = a4;
  allocp[9] = a5;
  allocp[10] = a6;
  allocp[11] = a7;
  allocp[12] = a8;
  allocp[13] = a9;
  allocp[14] = makesym(functor_a_1);
  allocp[15] = a1;
  x3 = makefunctor(&allocp[14]);
  a0 = x2;
  a1 = x3;
  a2 = a4;
  a3 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 16;
  execute(used__in_4_0);
  goto used__in_4_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto move__args_10_interrupt;
  unify4(a9, a8, a7, a6, a5, a4, a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,move__args_10_1);
  *reasonp++ =  a0;
  goto move__args_10_interrupt;
  };
  goto move__args_10_interrupt;
 move__args_10_ext_interrupt:
  reasonp = 0l;
 move__args_10_interrupt:
  toppred = &predicate_klic__comp__generate_xmove__args_10;
  goto interrupt_10;
 }

 move__args__1_12_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 move__args__1_12_clear_reason:
  reasonp = reasons;
 move__args__1_12_0:
 move__args__1_12_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto move__args__1_12_17;
  switch (symval(a0)) {
 case symval(makesym(atom_no)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xmove__args_10);
  allocp[2] = a2;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a5;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a7;
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = a9;
  allocp[10] = x4 = makeref(&allocp[10]);
  allocp[11] = a11;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[14] = a3;
  allocp[15] = makeint(1L);
  allocp[16] = x0;
  allocp[17] = makesym(functor_a_1);
  allocp[18] = a3;
  x5 = makefunctor(&allocp[17]);
  a0 = a1;
  a1 = x5;
  a2 = a4;
  a3 = x1;
  a4 = a6;
  a5 = x2;
  a6 = a8;
  a7 = x3;
  a8 = a10;
  a9 = x4;
  qp = (struct goalrec*)&allocp[12];
  allocp += 19;
  execute(move__one_10_0);
  goto move__one_10_ext_interrupt;
 case symval(makesym(atom_yes)):
 move__args__1_12_6:
  switch (ptagof(a1)) {
 case FUNCTOR:
  switch (symval(functor_of(a1))) {
 case functor__3A_2:
  x0 = arg(a1, 0);
 move__args__1_12_9:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_r_1)) goto move__args__1_12_17;
  x1 = arg(x0, 0);
 move__args__1_12_12:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_a_1)) goto move__args__1_12_17;
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a4;
  x2 = makefunctor(&allocp[0]);
  bblt_add_no_check_y(a4,makeint(1L),x3);
  bblt_add_no_check_y(a3,makeint(1L),x4);
  allocp[2] = makesym(functor_r_1);
  allocp[3] = x2;
  x5 = makefunctor(&allocp[2]);
  allocp[4] = makesym(functor__3A_2);
  allocp[5] = x5;
  x7 = arg(a1, 1);
  allocp[6] = x7;
  x6 = makefunctor(&allocp[4]);
  allocp[7] = makesym(functor_a_1);
  allocp[8] = a3;
  x8 = makefunctor(&allocp[7]);
  allocp[9] = (q)qp;
  allocp[10] = (q)(&predicate_klic__comp__generate_xmove__one_10);
  allocp[11] = x6;
  allocp[12] = x8;
  allocp[13] = x9 = makeref(&allocp[13]);
  allocp[14] = a5;
  allocp[15] = x10 = makeref(&allocp[15]);
  allocp[16] = a7;
  allocp[17] = x11 = makeref(&allocp[17]);
  allocp[18] = a9;
  allocp[19] = x12 = makeref(&allocp[19]);
  allocp[20] = a11;
  allocp[21] = (q)(struct goalrec*)&allocp[9];
  allocp[22] = (q)(&predicate_klic__comp__generate_xmove__args_10);
  allocp[23] = a2;
  allocp[24] = x4;
  allocp[25] = x13 = makeref(&allocp[25]);
  allocp[26] = x9;
  allocp[27] = x14 = makeref(&allocp[27]);
  allocp[28] = x10;
  allocp[29] = x15 = makeref(&allocp[29]);
  allocp[30] = x11;
  allocp[31] = x16 = makeref(&allocp[31]);
  allocp[32] = x12;
  a0 = a1;
  a1 = x2;
  a2 = x3;
  a3 = x13;
  a4 = a6;
  a5 = x14;
  a6 = a8;
  a7 = x15;
  a8 = a10;
  a9 = x16;
  qp = (struct goalrec*)&allocp[21];
  allocp += 33;
  execute(move__one_10_0);
  goto move__one_10_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,move__args__1_12_12);
  *reasonp++ =  x1;
  goto move__args__1_12_17;
  };
  goto move__args__1_12_17;
 case VARREF:
  deref_and_jump(x0,move__args__1_12_9);
  *reasonp++ =  x0;
  goto move__args__1_12_17;
  };
  goto move__args__1_12_17;
 case functor_arg_2:
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a4;
  x0 = makefunctor(&allocp[0]);
  bblt_add_no_check_y(a4,makeint(1L),x1);
  bblt_add_no_check_y(a3,makeint(1L),x2);
  allocp[2] = makesym(functor_r_1);
  allocp[3] = x0;
  x3 = makefunctor(&allocp[2]);
  allocp[4] = makesym(functor__3A_2);
  allocp[5] = x3;
  allocp[6] = x5 = makeref(&allocp[6]);
  x4 = makefunctor(&allocp[4]);
  allocp[7] = makesym(functor_a_1);
  allocp[8] = a3;
  x6 = makefunctor(&allocp[7]);
  allocp[9] = (q)qp;
  allocp[10] = (q)(&predicate_klic__comp__generate_xmove__one_10);
  allocp[11] = x4;
  allocp[12] = x6;
  allocp[13] = x7 = makeref(&allocp[13]);
  allocp[14] = a5;
  allocp[15] = x8 = makeref(&allocp[15]);
  allocp[16] = a7;
  allocp[17] = x9 = makeref(&allocp[17]);
  allocp[18] = a9;
  allocp[19] = x10 = makeref(&allocp[19]);
  allocp[20] = a11;
  allocp[21] = (q)(struct goalrec*)&allocp[9];
  allocp[22] = (q)(&predicate_klic__comp__generate_xmove__args_10);
  allocp[23] = a2;
  allocp[24] = x2;
  allocp[25] = x11 = makeref(&allocp[25]);
  allocp[26] = x7;
  allocp[27] = x12 = makeref(&allocp[27]);
  allocp[28] = x8;
  allocp[29] = x13 = makeref(&allocp[29]);
  allocp[30] = x9;
  allocp[31] = x14 = makeref(&allocp[31]);
  allocp[32] = x10;
  a0 = a1;
  a1 = x0;
  a2 = x1;
  a3 = x11;
  a4 = a6;
  a5 = x12;
  a6 = a8;
  a7 = x13;
  a8 = a10;
  a9 = x14;
  qp = (struct goalrec*)&allocp[21];
  allocp += 33;
  execute(move__one_10_0);
  goto move__one_10_ext_interrupt;
 case functor_var_1:
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a4;
  x0 = makefunctor(&allocp[0]);
  bblt_add_no_check_y(a4,makeint(1L),x1);
  bblt_add_no_check_y(a3,makeint(1L),x2);
  allocp[2] = makesym(functor_r_1);
  allocp[3] = x0;
  x3 = makefunctor(&allocp[2]);
  allocp[4] = makesym(functor__3A_2);
  allocp[5] = x3;
  allocp[6] = x5 = makeref(&allocp[6]);
  x4 = makefunctor(&allocp[4]);
  allocp[7] = makesym(functor_a_1);
  allocp[8] = a3;
  x6 = makefunctor(&allocp[7]);
  allocp[9] = (q)qp;
  allocp[10] = (q)(&predicate_klic__comp__generate_xmove__one_10);
  allocp[11] = x4;
  allocp[12] = x6;
  allocp[13] = x7 = makeref(&allocp[13]);
  allocp[14] = a5;
  allocp[15] = x8 = makeref(&allocp[15]);
  allocp[16] = a7;
  allocp[17] = x9 = makeref(&allocp[17]);
  allocp[18] = a9;
  allocp[19] = x10 = makeref(&allocp[19]);
  allocp[20] = a11;
  allocp[21] = (q)(struct goalrec*)&allocp[9];
  allocp[22] = (q)(&predicate_klic__comp__generate_xmove__args_10);
  allocp[23] = a2;
  allocp[24] = x2;
  allocp[25] = x11 = makeref(&allocp[25]);
  allocp[26] = x7;
  allocp[27] = x12 = makeref(&allocp[27]);
  allocp[28] = x8;
  allocp[29] = x13 = makeref(&allocp[29]);
  allocp[30] = x9;
  allocp[31] = x14 = makeref(&allocp[31]);
  allocp[32] = x10;
  a0 = a1;
  a1 = x0;
  a2 = x1;
  a3 = x11;
  a4 = a6;
  a5 = x12;
  a6 = a8;
  a7 = x13;
  a8 = a10;
  a9 = x14;
  qp = (struct goalrec*)&allocp[21];
  allocp += 33;
  execute(move__one_10_0);
  goto move__one_10_ext_interrupt;
 default:
  goto move__args__1_12_17;
  };
 case VARREF:
  deref_and_jump(a1,move__args__1_12_6);
  *reasonp++ =  a1;
  goto move__args__1_12_17;
  };
  goto move__args__1_12_17;
 default:
  goto move__args__1_12_17;
  };
 case VARREF:
  deref_and_jump(a0,move__args__1_12_1);
  *reasonp++ =  a0;
  goto move__args__1_12_17;
  };
  goto move__args__1_12_17;
 move__args__1_12_17:
  otherwise(move__args__1_12_interrupt);
 move__args__1_12_19:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_yes)) goto move__args__1_12_interrupt;
  bblt_add_no_check_y(a3,makeint(1L),x0);
  allocp[0] = makesym(functor_a_1);
  allocp[1] = a3;
  x1 = makefunctor(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__generate_xmove__one_10);
  allocp[4] = a1;
  allocp[5] = x1;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x4 = makeref(&allocp[10]);
  allocp[11] = a9;
  allocp[12] = x5 = makeref(&allocp[12]);
  allocp[13] = a11;
  a0 = a2;
  a1 = x0;
  a2 = a4;
  a3 = x2;
  a4 = a6;
  a5 = x3;
  a6 = a8;
  a7 = x4;
  a8 = a10;
  a9 = x5;
  qp = (struct goalrec*)&allocp[2];
  allocp += 14;
  execute(move__args_10_0);
  goto move__args_10_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,move__args__1_12_19);
  *reasonp++ =  a0;
  goto move__args__1_12_interrupt;
  };
  goto move__args__1_12_interrupt;
 move__args__1_12_ext_interrupt:
  reasonp = 0l;
 move__args__1_12_interrupt:
  goto interrupt_12;
 }

 move__one_10_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 move__one_10_clear_reason:
  reasonp = reasons;
 move__one_10_0:
 move__one_10_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor__3A_2)) goto move__one_10_14;
  x0 = arg(a0, 0);
 move__one_10_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_r_1)) goto move__one_10_14;
  x1 = arg(x0, 0);
 move__one_10_7:
  if (isref(x1)) goto move__one_10_13;
 move__one_10_9:
  if (isref(x1)) goto move__one_10_12;
  if_not_equal(x1, a1, move__one_10_14);
  unify4(a9, a8, a7, a6, a5, a4, a3, a2);
  proceed();
 move__one_10_12:
  deref_and_jump(x1,move__one_10_9);
  *reasonp++ =  x1;
  goto move__one_10_14;
 move__one_10_13:
  deref_and_jump(x1,move__one_10_7);
  *reasonp++ =  x1;
  goto move__one_10_14;
 case VARREF:
  deref_and_jump(x0,move__one_10_4);
  *reasonp++ =  x0;
  goto move__one_10_14;
  };
  goto move__one_10_14;
 case VARREF:
  deref_and_jump(a0,move__one_10_1);
  *reasonp++ =  a0;
  goto move__one_10_14;
  };
  goto move__one_10_14;
 move__one_10_14:
  otherwise(move__one_10_interrupt);
 move__one_10_16:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor__3A_2)) goto move__one_10_22;
  x0 = arg(a0, 0);
 move__one_10_19:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_r_1)) goto move__one_10_22;
  unify3(a7, a6, a5, a4, a3, a2);
  allocp[0] = makesym(functor_move_2);
  allocp[1] = a1;
  x2 = arg(x0, 0);
  allocp[2] = x2;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a9;
  allocp[4] = x1;
  x3 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a8, x3);
  proceed();
 case VARREF:
  deref_and_jump(x0,move__one_10_19);
  *reasonp++ =  x0;
  goto move__one_10_22;
  };
  goto move__one_10_22;
 case VARREF:
  deref_and_jump(a0,move__one_10_16);
  *reasonp++ =  a0;
  goto move__one_10_22;
  };
  goto move__one_10_22;
 move__one_10_22:
  otherwise(move__one_10_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xmove__one__1_10);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  x1 = a4;
  a1 = a0;
  a2 = x0;
  a0 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  execute(assocx_3_0);
  goto assocx_3_ext_interrupt;
 move__one_10_ext_interrupt:
  reasonp = 0l;
 move__one_10_interrupt:
  toppred = &predicate_klic__comp__generate_xmove__one_10;
  goto interrupt_10;
 }

 move__one__1_10_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 move__one__1_10_clear_reason:
  reasonp = reasons;
 move__one__1_10_0:
 move__one__1_10_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_yes_1:
  x0 = arg(a0, 0);
 move__one__1_10_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__3A_2)) goto move__one__1_10_interrupt;
  allocp[0] = makesym(functor_r_1);
  x2 = arg(x0, 0);
  allocp[1] = x2;
  x1 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__3A_2);
  allocp[3] = x1;
  x4 = arg(x0, 1);
  allocp[4] = x4;
  x3 = makefunctor(&allocp[2]);
  a0 = x3;
  allocp += 5;
  execute(move__one_10_0);
  goto move__one_10_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,move__one__1_10_4);
  *reasonp++ =  x0;
  goto move__one__1_10_interrupt;
  };
  goto move__one__1_10_interrupt;
 case functor_no_1:
  x0 = arg(a0, 0);
 move__one__1_10_8:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_atom_1:
  unify3(a7, a6, a5, a4, a3, a2);
  allocp[0] = makesym(functor_load__atom_2);
  allocp[1] = a1;
  x2 = arg(x0, 0);
  allocp[2] = x2;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a9;
  allocp[4] = x1;
  x3 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a8, x3);
  proceed();
 case functor_int_1:
  unify3(a7, a6, a5, a4, a3, a2);
  allocp[0] = makesym(functor_load__atom_2);
  allocp[1] = a1;
  x2 = arg(x0, 0);
  allocp[2] = x2;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a9;
  allocp[4] = x1;
  x3 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a8, x3);
  proceed();
 case functor_arg_2:
  allocp[0] = makesym(functor__3A_2);
  allocp[1] = a1;
  allocp[2] = makesym(atom_any);
  x1 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor__3D_2);
  allocp[4] = x0;
  allocp[5] = x1;
  x2 = makefunctor(&allocp[3]);
  allocp[6] = x4 = makeref(&allocp[6]);
  allocp[7] = x2;
  x3 = makecons(&allocp[6]);
  allocp[8] = makesym(functor_get__elem_3);
  allocp[9] = a1;
  allocp[10] = x6 = makeref(&allocp[10]);
  x7 = arg(x0, 1);
  allocp[11] = x7;
  x5 = makefunctor(&allocp[8]);
  allocp[12] = a9;
  allocp[13] = x5;
  x8 = makecons(&allocp[12]);
  a0 = arg(x0, 0);
  a1 = x6;
  a9 = x8;
  allocp += 14;
  execute(load__pos_10_0);
  goto load__pos_10_ext_interrupt;
 case functor_var_1:
  unify(a7, a6);
  allocp[0] = makesym(functor_x_1);
  allocp[1] = a2;
  x1 = makefunctor(&allocp[0]);
  bblt_add_no_check_y(a2,makeint(1L),x2);
  allocp += 2;
  unify(a3, x2);
  allocp[0] = makesym(functor__3A_2);
  allocp[1] = x1;
  allocp[2] = makesym(atom_any);
  x3 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor__3D_2);
  allocp[4] = x0;
  allocp[5] = x3;
  x4 = makefunctor(&allocp[3]);
  allocp[6] = a4;
  allocp[7] = x4;
  x5 = makecons(&allocp[6]);
  allocp += 8;
  unify_value(a5, x5);
  allocp[0] = makesym(functor_load__newvar_1);
  allocp[1] = x1;
  x6 = makefunctor(&allocp[0]);
  allocp[2] = x8 = makeref(&allocp[2]);
  allocp[3] = x6;
  x7 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a8, x7);
  allocp[0] = makesym(functor_move_2);
  allocp[1] = a1;
  allocp[2] = x1;
  x9 = makefunctor(&allocp[0]);
  allocp[3] = a9;
  allocp[4] = x9;
  x10 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(x8, x10);
  proceed();
 case functor_const_1:
  unify3(a7, a6, a5, a4, a3, a2);
  allocp[0] = makesym(functor_load__const_2);
  allocp[1] = a1;
  allocp[2] = x0;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a9;
  allocp[4] = x1;
  x2 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a8, x2);
  proceed();
 default:
  goto move__one__1_10_interrupt;
  };
 case VARREF:
  deref_and_jump(x0,move__one__1_10_8);
  *reasonp++ =  x0;
  goto move__one__1_10_interrupt;
  };
  goto move__one__1_10_interrupt;
 default:
  goto move__one__1_10_interrupt;
  };
 case VARREF:
  deref_and_jump(a0,move__one__1_10_1);
  *reasonp++ =  a0;
  goto move__one__1_10_interrupt;
  };
  goto move__one__1_10_interrupt;
 move__one__1_10_ext_interrupt:
  reasonp = 0l;
 move__one__1_10_interrupt:
  goto interrupt_10;
 }

 used__in_4_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 used__in_4_clear_reason:
  reasonp = reasons;
 used__in_4_0:
 used__in_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 used__in_4_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor__3A_2:
  x1 = arg(x0, 0);
 used__in_4_6:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_r_1)) goto used__in_4_21;
  x2 = arg(x1, 0);
 used__in_4_9:
  if (isref(x2)) goto used__in_4_15;
 used__in_4_11:
  if (isref(x2)) goto used__in_4_14;
  if_not_equal(x2, a1, used__in_4_21);
  unify_value(a3, makesym(atom_yes));
  proceed();
 used__in_4_14:
  deref_and_jump(x2,used__in_4_11);
  *reasonp++ =  x2;
  goto used__in_4_21;
 used__in_4_15:
  deref_and_jump(x2,used__in_4_9);
  *reasonp++ =  x2;
  goto used__in_4_21;
 case VARREF:
  deref_and_jump(x1,used__in_4_6);
  *reasonp++ =  x1;
  goto used__in_4_21;
  };
  goto used__in_4_21;
 case functor_arg_2:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xused__in__1_5);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  a0 = a2;
  a1 = arg(x0, 0);
  a2 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(assocx_3_0);
  goto assocx_3_ext_interrupt;
 case functor_var_1:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__generate_xused__in__1_5);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  a0 = a2;
  a1 = x0;
  a2 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(assocx_3_0);
  goto assocx_3_ext_interrupt;
 default:
  goto used__in_4_21;
  };
 case VARREF:
  deref_and_jump(x0,used__in_4_3);
  *reasonp++ =  x0;
  goto used__in_4_21;
  };
  goto used__in_4_21;
 case ATOMIC:
  if (a0 != NILATOM) goto used__in_4_21;
  unify_value(a3, makesym(atom_no));
  proceed();
 case VARREF:
  deref_and_jump(a0,used__in_4_1);
  *reasonp++ =  a0;
  goto used__in_4_21;
  };
  goto used__in_4_21;
 used__in_4_21:
  otherwise(used__in_4_interrupt);
 used__in_4_23:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(used__in_4_0);
  goto used__in_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,used__in_4_23);
  *reasonp++ =  a0;
  goto used__in_4_interrupt;
  };
  goto used__in_4_interrupt;
 used__in_4_ext_interrupt:
  reasonp = 0l;
 used__in_4_interrupt:
  toppred = &predicate_klic__comp__generate_xused__in_4;
  goto interrupt_4;
 }

 used__in__1_5_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 used__in__1_5_clear_reason:
  reasonp = reasons;
 used__in__1_5_0:
 used__in__1_5_1:
  switch (ptagof(a4)) {
 case FUNCTOR:
  switch (symval(functor_of(a4))) {
 case functor_yes_1:
  x0 = arg(a4, 0);
 used__in__1_5_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__3A_2)) goto used__in__1_5_interrupt;
  x1 = arg(x0, 0);
  x2 = a3;
  a3 = a0;
  a4 = a2;
  a2 = x2;
  a0 = x1;
  execute(used__in__1_2F5_240_5_0);
  goto used__in__1_2F5_240_5_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,used__in__1_5_4);
  *reasonp++ =  x0;
  goto used__in__1_5_interrupt;
  };
  goto used__in__1_5_interrupt;
 case functor_no_1:
  execute(used__in_4_0);
  goto used__in_4_ext_interrupt;
 default:
  goto used__in__1_5_interrupt;
  };
 case VARREF:
  deref_and_jump(a4,used__in__1_5_1);
  *reasonp++ =  a4;
  goto used__in__1_5_interrupt;
  };
  goto used__in__1_5_interrupt;
 used__in__1_5_ext_interrupt:
  reasonp = 0l;
 used__in__1_5_interrupt:
  goto interrupt_5;
 }

 used__in__1_2F5_240_5_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 used__in__1_2F5_240_5_clear_reason:
  reasonp = reasons;
 used__in__1_2F5_240_5_0:
 used__in__1_2F5_240_5_1:
  if (isref(a0)) goto used__in__1_2F5_240_5_7;
 used__in__1_2F5_240_5_3:
  if (isref(a0)) goto used__in__1_2F5_240_5_6;
  if_not_equal(a0, a1, used__in__1_2F5_240_5_8);
  unify_value(a2, makesym(atom_yes));
  proceed();
 used__in__1_2F5_240_5_6:
  deref_and_jump(a0,used__in__1_2F5_240_5_3);
  *reasonp++ =  a0;
  goto used__in__1_2F5_240_5_8;
 used__in__1_2F5_240_5_7:
  deref_and_jump(a0,used__in__1_2F5_240_5_1);
  *reasonp++ =  a0;
  goto used__in__1_2F5_240_5_8;
 used__in__1_2F5_240_5_8:
  otherwise(used__in__1_2F5_240_5_interrupt);
  a0 = a3;
  x0 = a4;
  a3 = a2;
  a2 = x0;
  execute(used__in_4_0);
  goto used__in_4_ext_interrupt;
 used__in__1_2F5_240_5_ext_interrupt:
  reasonp = 0l;
 used__in__1_2F5_240_5_interrupt:
  toppred = &predicate_klic__comp__generate_xused__in__1_2F5_240_5;
  goto interrupt_5;
 }

 strip__types_2_top: {
  q x0, x1, x2, x3;
  qp = qp->next;
 strip__types_2_clear_reason:
  reasonp = reasons;
 strip__types_2_0:
 strip__types_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 strip__types_2_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__3A_2)) goto strip__types_2_9;
  allocp[0] = x2 = makeref(&allocp[0]);
  x3 = arg(x0, 0);
  allocp[1] = x3;
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x1);
  a0 = cdr_of(a0);
  a1 = x2;
  execute(strip__types_2_0);
  goto strip__types_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,strip__types_2_3);
  *reasonp++ =  x0;
  goto strip__types_2_9;
  };
  goto strip__types_2_9;
 case ATOMIC:
  if (a0 != NILATOM) goto strip__types_2_9;
  unify_value(a1, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a0,strip__types_2_1);
  *reasonp++ =  a0;
  goto strip__types_2_9;
  };
  goto strip__types_2_9;
 strip__types_2_9:
  otherwise(strip__types_2_interrupt);
 strip__types_2_11:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  execute(strip__types_2_0);
  goto strip__types_2_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,strip__types_2_11);
  *reasonp++ =  a0;
  goto strip__types_2_interrupt;
  };
  goto strip__types_2_interrupt;
 strip__types_2_ext_interrupt:
  reasonp = 0l;
 strip__types_2_interrupt:
  goto interrupt_2;
 }

 make__label_2_top: {
  q x0;
  qp = qp->next;
 make__label_2_clear_reason:
  reasonp = reasons;
 make__label_2_0:
 make__label_2_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_none)) goto make__label_2_interrupt;
  proceed();
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_lab_1)) goto make__label_2_interrupt;
  x0 = arg(a0, 0);
  unify(x0, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,make__label_2_1);
  *reasonp++ =  a0;
  goto make__label_2_interrupt;
  };
  goto make__label_2_interrupt;
 make__label_2_ext_interrupt:
  reasonp = 0l;
 make__label_2_interrupt:
  toppred = &predicate_klic__comp__generate_xmake__label_2;
  goto interrupt_2;
 }

 add__info_4_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 add__info_4_clear_reason:
  reasonp = reasons;
 add__info_4_0:
  allocp[0] = makesym(functor__3A_2);
  allocp[1] = a0;
  allocp[2] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor__3D_2);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = x0;
  x1 = makefunctor(&allocp[3]);
  allocp[6] = a2;
  allocp[7] = x1;
  x3 = makecons(&allocp[6]);
  allocp += 8;
  unify_value(a3, x3);
  x4 = a2;
  a1 = x2;
  a2 = a0;
  a0 = x4;
  execute(rassoc_3_0);
  goto rassoc_3_ext_interrupt;
 add__info_4_ext_interrupt:
  reasonp = 0l;
 add__info_4_interrupt:
  toppred = &predicate_klic__comp__generate_xadd__info_4;
  goto interrupt_4;
 }

 rassoc_3_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  qp = qp->next;
 rassoc_3_clear_reason:
  reasonp = reasons;
 rassoc_3_0:
 rassoc_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 rassoc_3_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__3D_2)) goto rassoc_3_16;
  x1 = arg(x0, 1);
 rassoc_3_6:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor__3A_2)) goto rassoc_3_16;
  x2 = arg(x1, 0);
 rassoc_3_9:
  if (isref(x2)) goto rassoc_3_15;
 rassoc_3_11:
  if (isref(x2)) goto rassoc_3_14;
  if_not_equal(x2, a2, rassoc_3_16);
  x3 = arg(x0, 0);
  unify(x3, a1);
  proceed();
 rassoc_3_14:
  deref_and_jump(x2,rassoc_3_11);
  *reasonp++ =  x2;
  goto rassoc_3_16;
 rassoc_3_15:
  deref_and_jump(x2,rassoc_3_9);
  *reasonp++ =  x2;
  goto rassoc_3_16;
 case VARREF:
  deref_and_jump(x1,rassoc_3_6);
  *reasonp++ =  x1;
  goto rassoc_3_16;
  };
  goto rassoc_3_16;
 case VARREF:
  deref_and_jump(x0,rassoc_3_3);
  *reasonp++ =  x0;
  goto rassoc_3_16;
  };
  goto rassoc_3_16;
 case VARREF:
  deref_and_jump(a0,rassoc_3_1);
  *reasonp++ =  a0;
  goto rassoc_3_16;
  };
  goto rassoc_3_16;
 rassoc_3_16:
  otherwise(rassoc_3_interrupt);
 rassoc_3_18:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(rassoc_3_0);
  goto rassoc_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,rassoc_3_18);
  *reasonp++ =  a0;
  goto rassoc_3_interrupt;
  };
  goto rassoc_3_interrupt;
 rassoc_3_ext_interrupt:
  reasonp = 0l;
 rassoc_3_interrupt:
  toppred = &predicate_klic__comp__generate_xrassoc_3;
  goto interrupt_3;
 }

 assocx_3_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  qp = qp->next;
 assocx_3_clear_reason:
  reasonp = reasons;
 assocx_3_0:
 assocx_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 assocx_3_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__3D_2)) goto assocx_3_16;
  x1 = arg(x0, 0);
 assocx_3_6:
  if (isref(x1)) goto assocx_3_12;
 assocx_3_8:
  if (isref(x1)) goto assocx_3_11;
  if_not_equal(x1, a1, assocx_3_16);
  allocp[0] = makesym(functor_yes_1);
  x3 = arg(x0, 1);
  allocp[1] = x3;
  x2 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a2, x2);
  proceed();
 assocx_3_11:
  deref_and_jump(x1,assocx_3_8);
  *reasonp++ =  x1;
  goto assocx_3_16;
 assocx_3_12:
  deref_and_jump(x1,assocx_3_6);
  *reasonp++ =  x1;
  goto assocx_3_16;
 case VARREF:
  deref_and_jump(x0,assocx_3_3);
  *reasonp++ =  x0;
  goto assocx_3_16;
  };
  goto assocx_3_16;
 case ATOMIC:
  if (a0 != NILATOM) goto assocx_3_16;
  allocp[0] = makesym(functor_no_1);
  allocp[1] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,assocx_3_1);
  *reasonp++ =  a0;
  goto assocx_3_16;
  };
  goto assocx_3_16;
 assocx_3_16:
  otherwise(assocx_3_interrupt);
 assocx_3_18:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(assocx_3_0);
  goto assocx_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,assocx_3_18);
  *reasonp++ =  a0;
  goto assocx_3_interrupt;
  };
  goto assocx_3_interrupt;
 assocx_3_ext_interrupt:
  reasonp = 0l;
 assocx_3_interrupt:
  toppred = &predicate_klic__comp__generate_xassocx_3;
  goto interrupt_3;
 }
 interrupt_20:
  allocp[21] = a19;
 interrupt_19:
  allocp[20] = a18;
 interrupt_18:
  allocp[19] = a17;
 interrupt_17:
  allocp[18] = a16;
 interrupt_16:
  allocp[17] = a15;
 interrupt_15:
  allocp[16] = a14;
 interrupt_14:
  allocp[15] = a13;
 interrupt_13:
  allocp[14] = a12;
 interrupt_12:
  allocp[13] = a11;
 interrupt_11:
  allocp[12] = a10;
 interrupt_10:
  allocp[11] = a9;
 interrupt_9:
  allocp[10] = a8;
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_klic__comp__generate);
}
