/* Compiled by KLIC compiler version 1.500 (Fri Oct 21 12:19:27 JST 1994) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_klic__comp__util();
Const struct predicate predicate_klic__comp__util_xappend_3 =
   { module_klic__comp__util, 0, 3 };
Const struct predicate predicate_klic__comp__util_xassoc_4 =
   { module_klic__comp__util, 1, 4 };
Const struct predicate predicate_klic__comp__util_xassoc_3 =
   { module_klic__comp__util, 2, 3 };
Const struct predicate predicate_klic__comp__util_xnth_3 =
   { module_klic__comp__util, 3, 3 };
Const struct predicate predicate_klic__comp__util_xmember_3 =
   { module_klic__comp__util, 4, 3 };
Const struct predicate predicate_klic__comp__util_xmax_3 =
   { module_klic__comp__util, 5, 3 };
Const struct predicate predicate_klic__comp__util_xmin_3 =
   { module_klic__comp__util, 6, 3 };
Const struct predicate predicate_klic__comp__util_xmax__list_2 =
   { module_klic__comp__util, 7, 2 };
Const struct predicate predicate_klic__comp__util_xmax__list_3 =
   { module_klic__comp__util, 8, 3 };
Const struct predicate predicate_klic__comp__util_xremove_4 =
   { module_klic__comp__util, 9, 4 };
Const struct predicate predicate_klic__comp__util_xlength_2 =
   { module_klic__comp__util, 10, 2 };
Const struct predicate predicate_klic__comp__util_xlength_3 =
   { module_klic__comp__util, 11, 3 };
Const struct predicate predicate_klic__comp__util_xvector__to__list_2 =
   { module_klic__comp__util, 12, 2 };
Const struct predicate predicate_klic__comp__util_xvector__to__list_4 =
   { module_klic__comp__util, 13, 4 };
Const struct predicate predicate_klic__comp__util_xuniv_2 =
   { module_klic__comp__util, 14, 2 };
Const struct predicate predicate_klic__comp__util_xuniv_3 =
   { module_klic__comp__util, 15, 3 };
Const struct predicate predicate_klic__comp__util_xuniv__funct__to__list_5 =
   { module_klic__comp__util, 16, 5 };
Const struct predicate predicate_klic__comp__util_xname_2 =
   { module_klic__comp__util, 17, 2 };
Const struct predicate predicate_klic__comp__util_xname__integer_2 =
   { module_klic__comp__util, 18, 2 };
Const struct predicate predicate_klic__comp__util_xname__integer_3 =
   { module_klic__comp__util, 19, 3 };
Const struct predicate predicate_klic__comp__util_xstring__to__char__list_2 =
   { module_klic__comp__util, 20, 2 };
Const struct predicate predicate_klic__comp__util_xstring__to__char__list_4 =
   { module_klic__comp__util, 21, 4 };
Const struct predicate predicate_klic__comp__util_xnumbervars_4 =
   { module_klic__comp__util, 22, 4 };
Const struct predicate predicate_klic__comp__util_xnumbervars_6 =
   { module_klic__comp__util, 23, 6 };
Const struct predicate predicate_klic__comp__util_xnumbervars__1_7 =
   { module_klic__comp__util, 24, 7 };
Const struct predicate predicate_klic__comp__util_xnumbervars__vector_9 =
   { module_klic__comp__util, 25, 9 };
Const struct predicate predicate_klic__comp__util_xnumbervars__funct_10 =
   { module_klic__comp__util, 26, 10 };
Const struct predicate predicate_klic__comp__util_xmake__atom_2 =
   { module_klic__comp__util, 27, 2 };
extern Const struct predicate predicate_atom__table_xget__atom__string_2;
extern q vector_g_new();
extern Const struct predicate predicate_functor__table_x_3D_2E_2E_2;
extern q string_g_new();
extern Const struct predicate predicate_atom__table_xmake__atom_2;

module module_klic__comp__util(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  Const static unsigned char strconst_body_0[4] =
    "_";
  Const static string_structure_type_8 string_const_0 =
      declare_string_constant_8(strconst_body_0,1);
  q a0, a1, a2, a3, a4, a5, a6, a7, a8, a9;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, append_3_top);
    case_pred(1, assoc_4_top);
    case_pred(2, assoc_3_top);
    case_pred(3, nth_3_top);
    case_pred(4, member_3_top);
    case_pred(5, max_3_top);
    case_pred(6, min_3_top);
    case_pred(7, max__list_2_top);
    case_pred(8, max__list_3_top);
    case_pred(9, remove_4_top);
    case_pred(10, length_2_top);
    case_pred(11, length_3_top);
    case_pred(12, vector__to__list_2_top);
    case_pred(13, vector__to__list_4_top);
    case_pred(14, univ_2_top);
    case_pred(15, univ_3_top);
    case_pred(16, univ__funct__to__list_5_top);
    case_pred(17, name_2_top);
    case_pred(18, name__integer_2_top);
    case_pred(19, name__integer_3_top);
    case_pred(20, string__to__char__list_2_top);
    case_pred(21, string__to__char__list_4_top);
    case_pred(22, numbervars_4_top);
    case_pred(23, numbervars_6_top);
    case_pred(24, numbervars__1_7_top);
    case_pred(25, numbervars__vector_9_top);
    case_pred(26, numbervars__funct_10_top);
    last_case_pred(27, make__atom_2_top);
  }

 append_3_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  qp = qp->next;
 append_3_clear_reason:
  reasonp = reasons;
 append_3_0:
 append_3_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  a0 = cdr_of(a0);
  a2 = x1;
  execute(append_3_0);
  goto append_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto append_3_interrupt;
  unify(a1, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,append_3_1);
  *reasonp++ =  a0;
  goto append_3_interrupt;
  };
  goto append_3_interrupt;
 append_3_ext_interrupt:
  reasonp = 0l;
 append_3_interrupt:
  goto interrupt_3;
 }

 assoc_4_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 assoc_4_clear_reason:
  reasonp = reasons;
 assoc_4_0:
 assoc_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 assoc_4_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__3D_2)) goto assoc_4_16;
  x1 = arg(x0, 0);
 assoc_4_6:
  if (isref(x1)) goto assoc_4_12;
 assoc_4_8:
  if (isref(x1)) goto assoc_4_11;
  if_not_equal(x1, a1, assoc_4_16);
  x2 = arg(x0, 1);
  unify(a2, x2);
  unify_value(a3, makesym(atom_yes));
  proceed();
 assoc_4_11:
  deref_and_jump(x1,assoc_4_8);
  *reasonp++ =  x1;
  goto assoc_4_16;
 assoc_4_12:
  deref_and_jump(x1,assoc_4_6);
  *reasonp++ =  x1;
  goto assoc_4_16;
 case VARREF:
  deref_and_jump(x0,assoc_4_3);
  *reasonp++ =  x0;
  goto assoc_4_16;
  };
  goto assoc_4_16;
 case ATOMIC:
  if (a0 != NILATOM) goto assoc_4_16;
  unify_value(a3, makesym(atom_no));
  proceed();
 case VARREF:
  deref_and_jump(a0,assoc_4_1);
  *reasonp++ =  a0;
  goto assoc_4_16;
  };
  goto assoc_4_16;
 assoc_4_16:
  otherwise(assoc_4_interrupt);
 assoc_4_18:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(assoc_4_0);
  goto assoc_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,assoc_4_18);
  *reasonp++ =  a0;
  goto assoc_4_interrupt;
  };
  goto assoc_4_interrupt;
 assoc_4_ext_interrupt:
  reasonp = 0l;
 assoc_4_interrupt:
  goto interrupt_4;
 }

 assoc_3_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  qp = qp->next;
 assoc_3_clear_reason:
  reasonp = reasons;
 assoc_3_0:
 assoc_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 assoc_3_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__3D_2)) goto assoc_3_16;
  x1 = arg(x0, 0);
 assoc_3_6:
  if (isref(x1)) goto assoc_3_12;
 assoc_3_8:
  if (isref(x1)) goto assoc_3_11;
  if_not_equal(x1, a1, assoc_3_16);
  allocp[0] = makesym(functor_yes_1);
  x3 = arg(x0, 1);
  allocp[1] = x3;
  x2 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a2, x2);
  proceed();
 assoc_3_11:
  deref_and_jump(x1,assoc_3_8);
  *reasonp++ =  x1;
  goto assoc_3_16;
 assoc_3_12:
  deref_and_jump(x1,assoc_3_6);
  *reasonp++ =  x1;
  goto assoc_3_16;
 case VARREF:
  deref_and_jump(x0,assoc_3_3);
  *reasonp++ =  x0;
  goto assoc_3_16;
  };
  goto assoc_3_16;
 case ATOMIC:
  if (a0 != NILATOM) goto assoc_3_16;
  unify_value(a2, makesym(atom_no));
  proceed();
 case VARREF:
  deref_and_jump(a0,assoc_3_1);
  *reasonp++ =  a0;
  goto assoc_3_16;
  };
  goto assoc_3_16;
 assoc_3_16:
  otherwise(assoc_3_interrupt);
 assoc_3_18:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(assoc_3_0);
  goto assoc_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,assoc_3_18);
  *reasonp++ =  a0;
  goto assoc_3_interrupt;
  };
  goto assoc_3_interrupt;
 assoc_3_ext_interrupt:
  reasonp = 0l;
 assoc_3_interrupt:
  toppred = &predicate_klic__comp__util_xassoc_3;
  goto interrupt_3;
 }

 nth_3_top: {
  q x0;
  a2 = qp->args[2];
  qp = qp->next;
 nth_3_clear_reason:
  reasonp = reasons;
 nth_3_0:
 nth_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 nth_3_3:
  if (a0 != makeint(0L)) goto nth_3_7;
 nth_3_5:
  switch (ptagof(a1)) {
 case CONS:
  x0 = car_of(a1);
  unify(a2, x0);
  proceed();
 case VARREF:
  deref_and_jump(a1,nth_3_5);
  *reasonp++ =  a1;
  goto nth_3_7;
  };
  goto nth_3_7;
 case VARREF:
  deref_and_jump(a0,nth_3_1);
  *reasonp++ =  a0;
  goto nth_3_7;
  };
  goto nth_3_7;
 nth_3_7:
 nth_3_8:
  switch (ptagof(a1)) {
 case CONS:
 nth_3_10:
  if (!isint(a0)) goto nth_3_13;
  gblt_greater(a0,makeint(0L),nth_3_interrupt);
  bblt_sub_no_check(a0,makeint(1L),x0);
  a0 = x0;
  a1 = cdr_of(a1);
  execute(nth_3_clear_reason);
  goto nth_3_ext_interrupt;
 nth_3_13:
  if (!isref(a0)) goto nth_3_interrupt;
  deref_and_jump(a0,nth_3_10);
  *reasonp++ =  a0;
  goto nth_3_interrupt;
 case VARREF:
  deref_and_jump(a1,nth_3_8);
  *reasonp++ =  a1;
  goto nth_3_interrupt;
  };
  goto nth_3_interrupt;
 nth_3_ext_interrupt:
  reasonp = 0l;
 nth_3_interrupt:
  goto interrupt_3;
 }

 member_3_top: {
  q x0;
  a2 = qp->args[2];
  qp = qp->next;
 member_3_clear_reason:
  reasonp = reasons;
 member_3_0:
 member_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 member_3_3:
  if (isref(x0)) goto member_3_9;
 member_3_5:
  if (isref(x0)) goto member_3_8;
  if_not_equal(x0, a1, member_3_13);
  unify_value(a2, makesym(atom_yes));
  proceed();
 member_3_8:
  deref_and_jump(x0,member_3_5);
  *reasonp++ =  x0;
  goto member_3_13;
 member_3_9:
  deref_and_jump(x0,member_3_3);
  *reasonp++ =  x0;
  goto member_3_13;
 case ATOMIC:
  if (a0 != NILATOM) goto member_3_13;
  unify_value(a2, makesym(atom_no));
  proceed();
 case VARREF:
  deref_and_jump(a0,member_3_1);
  *reasonp++ =  a0;
  goto member_3_13;
  };
  goto member_3_13;
 member_3_13:
  otherwise(member_3_interrupt);
 member_3_15:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(member_3_0);
  goto member_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,member_3_15);
  *reasonp++ =  a0;
  goto member_3_interrupt;
  };
  goto member_3_interrupt;
 member_3_ext_interrupt:
  reasonp = 0l;
 member_3_interrupt:
  goto interrupt_3;
 }

 max_3_top: {
  a2 = qp->args[2];
  qp = qp->next;
 max_3_clear_reason:
  reasonp = reasons;
 max_3_0:
 max_3_1:
  if (!isint(a0)) goto max_3_9;
 max_3_3:
  if (!isint(a1)) goto max_3_8;
  gblt_greater_or_eq(a0,a1,max_3_6);
  unify_value(a2, a0);
  proceed();
 max_3_6:
  gblt_less_or_eq(a0,a1,max_3_interrupt);
  unify_value(a2, a1);
  proceed();
 max_3_8:
  if (!isref(a1)) goto max_3_interrupt;
  deref_and_jump(a1,max_3_3);
  *reasonp++ =  a1;
  goto max_3_interrupt;
 max_3_9:
  if (!isref(a0)) goto max_3_interrupt;
  deref_and_jump(a0,max_3_1);
  *reasonp++ =  a0;
  goto max_3_interrupt;
 max_3_ext_interrupt:
  reasonp = 0l;
 max_3_interrupt:
  toppred = &predicate_klic__comp__util_xmax_3;
  goto interrupt_3;
 }

 min_3_top: {
  a2 = qp->args[2];
  qp = qp->next;
 min_3_clear_reason:
  reasonp = reasons;
 min_3_0:
 min_3_1:
  if (!isint(a0)) goto min_3_9;
 min_3_3:
  if (!isint(a1)) goto min_3_8;
  gblt_less_or_eq(a0,a1,min_3_6);
  unify_value(a2, a0);
  proceed();
 min_3_6:
  gblt_greater_or_eq(a0,a1,min_3_interrupt);
  unify_value(a2, a1);
  proceed();
 min_3_8:
  if (!isref(a1)) goto min_3_interrupt;
  deref_and_jump(a1,min_3_3);
  *reasonp++ =  a1;
  goto min_3_interrupt;
 min_3_9:
  if (!isref(a0)) goto min_3_interrupt;
  deref_and_jump(a0,min_3_1);
  *reasonp++ =  a0;
  goto min_3_interrupt;
 min_3_ext_interrupt:
  reasonp = 0l;
 min_3_interrupt:
  goto interrupt_3;
 }

 max__list_2_top: {
  qp = qp->next;
 max__list_2_clear_reason:
  reasonp = reasons;
 max__list_2_0:
  a2 = a1;
  a1 = makeint(0L);
  execute(max__list_3_0);
  goto max__list_3_ext_interrupt;
 max__list_2_ext_interrupt:
  reasonp = 0l;
 max__list_2_interrupt:
  goto interrupt_2;
 }

 max__list_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 max__list_3_clear_reason:
  reasonp = reasons;
 max__list_3_0:
 max__list_3_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__util_xmax__list_3);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  a0 = car_of(a0);
  a2 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(max_3_0);
  goto max_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto max__list_3_interrupt;
  unify(a1, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,max__list_3_1);
  *reasonp++ =  a0;
  goto max__list_3_interrupt;
  };
  goto max__list_3_interrupt;
 max__list_3_ext_interrupt:
  reasonp = 0l;
 max__list_3_interrupt:
  toppred = &predicate_klic__comp__util_xmax__list_3;
  goto interrupt_3;
 }

 remove_4_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 remove_4_clear_reason:
  reasonp = reasons;
 remove_4_0:
 remove_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 remove_4_3:
  if (isref(x0)) goto remove_4_9;
 remove_4_5:
  if (isref(x0)) goto remove_4_8;
  if_not_equal(x0, a1, remove_4_13);
  a0 = cdr_of(a0);
  a1 = x0;
  execute(remove_4_clear_reason);
  goto remove_4_ext_interrupt;
 remove_4_8:
  deref_and_jump(x0,remove_4_5);
  *reasonp++ =  x0;
  goto remove_4_13;
 remove_4_9:
  deref_and_jump(x0,remove_4_3);
  *reasonp++ =  x0;
  goto remove_4_13;
 case ATOMIC:
  if (a0 != NILATOM) goto remove_4_13;
  unify(a2, a3);
  proceed();
 case VARREF:
  deref_and_jump(a0,remove_4_1);
  *reasonp++ =  a0;
  goto remove_4_13;
  };
  goto remove_4_13;
 remove_4_13:
  otherwise(remove_4_interrupt);
 remove_4_15:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  x2 = car_of(a0);
  allocp[1] = x2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  a0 = cdr_of(a0);
  a2 = x1;
  execute(remove_4_0);
  goto remove_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,remove_4_15);
  *reasonp++ =  a0;
  goto remove_4_interrupt;
  };
  goto remove_4_interrupt;
 remove_4_ext_interrupt:
  reasonp = 0l;
 remove_4_interrupt:
  goto interrupt_4;
 }

 length_2_top: {
  qp = qp->next;
 length_2_clear_reason:
  reasonp = reasons;
 length_2_0:
  a2 = makeint(0L);
  execute(length_3_0);
  goto length_3_ext_interrupt;
 length_2_ext_interrupt:
  reasonp = 0l;
 length_2_interrupt:
  goto interrupt_2;
 }

 length_3_top: {
  q x0;
  a2 = qp->args[2];
  qp = qp->next;
 length_3_clear_reason:
  reasonp = reasons;
 length_3_0:
 length_3_1:
  switch (ptagof(a0)) {
 case CONS:
  bblt_add_no_check_y(a2,makeint(1L),x0);
  a0 = cdr_of(a0);
  a2 = x0;
  execute(length_3_0);
  goto length_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto length_3_interrupt;
  unify(a1, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,length_3_1);
  *reasonp++ =  a0;
  goto length_3_interrupt;
  };
  goto length_3_interrupt;
 length_3_ext_interrupt:
  reasonp = 0l;
 length_3_interrupt:
  toppred = &predicate_klic__comp__util_xlength_3;
  goto interrupt_3;
 }

 vector__to__list_2_top: {
  q x0;
  qp = qp->next;
 vector__to__list_2_clear_reason:
  reasonp = reasons;
 vector__to__list_2_0:
 vector__to__list_2_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
 vector__to__list_2_2:
  if (!isgobj(a0)) goto vector__to__list_2_interrupt;
  if (!isclass(a0,vector)) goto vector__to__list_2_interrupt;
  gblt_size_of_vector(a0,x0,vector__to__list_2_interrupt);
  a2 = a0;
  a3 = a1;
  a1 = x0;
  a0 = makeint(0L);
  execute(vector__to__list_4_0);
  goto vector__to__list_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,vector__to__list_2_1);
  *reasonp++ =  a0;
  goto vector__to__list_2_interrupt;
  };
  goto vector__to__list_2_interrupt;
 vector__to__list_2_ext_interrupt:
  reasonp = 0l;
 vector__to__list_2_interrupt:
  goto interrupt_2;
 }

 vector__to__list_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 vector__to__list_4_clear_reason:
  reasonp = reasons;
 vector__to__list_4_0:
 vector__to__list_4_1:
  if (!isint(a0)) goto vector__to__list_4_9;
 vector__to__list_4_3:
  if (!isint(a1)) goto vector__to__list_4_8;
  gblt_less(a0,a1,vector__to__list_4_6);
  generic_arg[0] = a0;
  allocp[0] = x0 = makeref(&allocp[0]);
  generic_arg[1] = x0;
  call_generic(a2, functor_element_2, 1);
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = x0;
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a3, x1);
  bblt_add_no_check(a0,makeint(1L),x3);
  a0 = x3;
  a3 = x2;
  execute(vector__to__list_4_0);
  goto vector__to__list_4_ext_interrupt;
 vector__to__list_4_6:
  gblt_greater_or_eq(a0,a1,vector__to__list_4_interrupt);
  unify_value(a3, NILATOM);
  proceed();
 vector__to__list_4_8:
  if (!isref(a1)) goto vector__to__list_4_interrupt;
  deref_and_jump(a1,vector__to__list_4_3);
  *reasonp++ =  a1;
  goto vector__to__list_4_interrupt;
 vector__to__list_4_9:
  if (!isref(a0)) goto vector__to__list_4_interrupt;
  deref_and_jump(a0,vector__to__list_4_1);
  *reasonp++ =  a0;
  goto vector__to__list_4_interrupt;
 vector__to__list_4_ext_interrupt:
  reasonp = 0l;
 vector__to__list_4_interrupt:
  toppred = &predicate_klic__comp__util_xvector__to__list_4;
  goto interrupt_4;
 }

 univ_2_top: {
  qp = qp->next;
 univ_2_clear_reason:
  reasonp = reasons;
 univ_2_0:
  a2 = NILATOM;
  execute(univ_3_0);
  goto univ_3_ext_interrupt;
 univ_2_ext_interrupt:
  reasonp = 0l;
 univ_2_interrupt:
  goto interrupt_2;
 }

 univ_3_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  qp = qp->next;
 univ_3_clear_reason:
  reasonp = reasons;
 univ_3_0:
 univ_3_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = a2;
  x1 = cdr_of(a0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  x3 = car_of(a0);
  allocp[3] = x3;
  x2 = makecons(&allocp[2]);
  allocp[4] = x2;
  allocp[5] = PERIODATOM;
  x4 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a1, x4);
  proceed();
 case ATOMIC:
 univ_3_4:
  gblt_atomic(a0,univ_3_14);
  allocp[0] = a2;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  proceed();
 case FUNCTOR:
 univ_3_6:
  if (!isgobj(a0)) goto univ_3_14;
  if (!isclass(a0,vector)) goto univ_3_10;
  gblt_size_of_vector(a0,x0,univ_3_10);
  allocp[0] = a2;
  allocp[1] = a0;
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x1);
  proceed();
 univ_3_10:
  gblt_is_string(a0,univ_3_14);
  gblt_size_of_string(a0,x2,univ_3_14);
  gblt_element_size_of_string(a0,x3,univ_3_14);
  allocp[0] = a2;
  allocp[1] = a0;
  x4 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x4);
  proceed();
 case VARREF:
  deref_and_jump(a0,univ_3_1);
  *reasonp++ =  a0;
  goto univ_3_14;
  };
  goto univ_3_14;
 univ_3_14:
  otherwise(univ_3_interrupt);
 univ_3_16:
  if (isref(a0)) goto univ_3_20;
  gblt_pfunctor(a0,x0,univ_3_interrupt);
  gblt_arity(a0,x1,univ_3_interrupt);
  allocp[0] = x3 = makeref(&allocp[0]);
  allocp[1] = x0;
  x2 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x2);
  a1 = x3;
  a3 = x1;
  a4 = a2;
  a2 = makeint(1L);
  execute(univ__funct__to__list_5_0);
  goto univ__funct__to__list_5_ext_interrupt;
 univ_3_20:
  deref_and_jump(a0,univ_3_16);
  *reasonp++ =  a0;
  goto univ_3_interrupt;
 univ_3_ext_interrupt:
  reasonp = 0l;
 univ_3_interrupt:
  toppred = &predicate_klic__comp__util_xuniv_3;
  goto interrupt_3;
 }

 univ__funct__to__list_5_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 univ__funct__to__list_5_clear_reason:
  reasonp = reasons;
 univ__funct__to__list_5_0:
 univ__funct__to__list_5_1:
  if (!isint(a2)) goto univ__funct__to__list_5_7;
 univ__funct__to__list_5_3:
  if (!isint(a3)) goto univ__funct__to__list_5_6;
  gblt_greater(a2,a3,univ__funct__to__list_5_8);
  unify(a1, a4);
  proceed();
 univ__funct__to__list_5_6:
  if (!isref(a3)) goto univ__funct__to__list_5_8;
  deref_and_jump(a3,univ__funct__to__list_5_3);
  *reasonp++ =  a3;
  goto univ__funct__to__list_5_8;
 univ__funct__to__list_5_7:
  if (!isref(a2)) goto univ__funct__to__list_5_8;
  deref_and_jump(a2,univ__funct__to__list_5_1);
  *reasonp++ =  a2;
  goto univ__funct__to__list_5_8;
 univ__funct__to__list_5_8:
  otherwise(univ__funct__to__list_5_interrupt);
 univ__funct__to__list_5_10:
  if (!isint(a2)) goto univ__funct__to__list_5_16;
 univ__funct__to__list_5_12:
  if (isref(a0)) goto univ__funct__to__list_5_15;
  gblt_arg(a2,a0,x0,univ__funct__to__list_5_interrupt);
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = x0;
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x1);
  bblt_add_no_check(a2,makeint(1L),x3);
  a1 = x2;
  a2 = x3;
  execute(univ__funct__to__list_5_0);
  goto univ__funct__to__list_5_ext_interrupt;
 univ__funct__to__list_5_15:
  deref_and_jump(a0,univ__funct__to__list_5_12);
  *reasonp++ =  a0;
  goto univ__funct__to__list_5_interrupt;
 univ__funct__to__list_5_16:
  if (!isref(a2)) goto univ__funct__to__list_5_interrupt;
  deref_and_jump(a2,univ__funct__to__list_5_10);
  *reasonp++ =  a2;
  goto univ__funct__to__list_5_interrupt;
 univ__funct__to__list_5_ext_interrupt:
  reasonp = 0l;
 univ__funct__to__list_5_interrupt:
  toppred = &predicate_klic__comp__util_xuniv__funct__to__list_5;
  goto interrupt_5;
 }

 name_2_top: {
  q x0;
  qp = qp->next;
 name_2_clear_reason:
  reasonp = reasons;
 name_2_0:
 name_2_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto name_2_6;
 name_2_4:
  gblt_atom(a0,name_2_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__util_xstring__to__char__list_2);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_atom__table_xget__atom__string_2);
  allocp[6] = a0;
  allocp[7] = x0;
  qp = (struct goalrec*)&allocp[4];
  allocp += 8;
  proceed();
 name_2_6:
  gblt_integer(a0,name_2_interrupt);
  execute(name__integer_2_0);
  goto name__integer_2_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,name_2_1);
  *reasonp++ =  a0;
  goto name_2_interrupt;
  };
  goto name_2_interrupt;
 name_2_ext_interrupt:
  reasonp = 0l;
 name_2_interrupt:
  goto interrupt_2;
 }

 name__integer_2_top: {
  q x0, x1, x2;
  qp = qp->next;
 name__integer_2_clear_reason:
  reasonp = reasons;
 name__integer_2_0:
 name__integer_2_1:
  if (!isint(a0)) goto name__integer_2_6;
  gblt_greater_or_eq(a0,makeint(0L),name__integer_2_4);
  a2 = NILATOM;
  execute(name__integer_3_0);
  goto name__integer_3_ext_interrupt;
 name__integer_2_4:
  gblt_less(a0,makeint(0L),name__integer_2_interrupt);
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = makeint(45L);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  bblt_minus_no_check(a0,x2);
  a0 = x2;
  a1 = x1;
  a2 = NILATOM;
  execute(name__integer_3_0);
  goto name__integer_3_ext_interrupt;
 name__integer_2_6:
  if (!isref(a0)) goto name__integer_2_interrupt;
  deref_and_jump(a0,name__integer_2_1);
  *reasonp++ =  a0;
  goto name__integer_2_interrupt;
 name__integer_2_ext_interrupt:
  reasonp = 0l;
 name__integer_2_interrupt:
  toppred = &predicate_klic__comp__util_xname__integer_2;
  goto interrupt_2;
 }

 name__integer_3_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  qp = qp->next;
 name__integer_3_clear_reason:
  reasonp = reasons;
 name__integer_3_0:
 name__integer_3_1:
  if (!isint(a0)) goto name__integer_3_6;
  gblt_less(a0,makeint(10L),name__integer_3_4);
  bblt_add_no_check(makeint(48L),a0,x0);
  allocp[0] = a2;
  allocp[1] = x0;
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x1);
  proceed();
 name__integer_3_4:
  gblt_greater_or_eq(a0,makeint(10L),name__integer_3_interrupt);
  bblt_div_no_check(a0,makeint(10L),x0);
  bblt_mod_no_check(a0,makeint(10L),x1);
  bblt_add_no_check(x1,makeint(48L),x2);
  allocp[0] = a2;
  allocp[1] = x2;
  x3 = makecons(&allocp[0]);
  a0 = x0;
  a2 = x3;
  allocp += 2;
  execute(name__integer_3_0);
  goto name__integer_3_ext_interrupt;
 name__integer_3_6:
  if (!isref(a0)) goto name__integer_3_interrupt;
  deref_and_jump(a0,name__integer_3_1);
  *reasonp++ =  a0;
  goto name__integer_3_interrupt;
 name__integer_3_ext_interrupt:
  reasonp = 0l;
 name__integer_3_interrupt:
  toppred = &predicate_klic__comp__util_xname__integer_3;
  goto interrupt_3;
 }

 string__to__char__list_2_top: {
  q x0, x1;
  qp = qp->next;
 string__to__char__list_2_clear_reason:
  reasonp = reasons;
 string__to__char__list_2_0:
 string__to__char__list_2_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
 string__to__char__list_2_2:
  if (!isgobj(a0)) goto string__to__char__list_2_interrupt;
 string__to__char__list_2_3:
  gblt_is_string(a0,string__to__char__list_2_interrupt);
  gblt_size_of_string(a0,x0,string__to__char__list_2_interrupt);
  gblt_element_size_of_string(a0,x1,string__to__char__list_2_interrupt);
 string__to__char__list_2_7:
  if (x1 != makeint(8L)) goto string__to__char__list_2_interrupt;
  a2 = makeint(0L);
  a3 = x0;
  execute(string__to__char__list_4_0);
  goto string__to__char__list_4_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,string__to__char__list_2_1);
  *reasonp++ =  a0;
  goto string__to__char__list_2_interrupt;
  };
  goto string__to__char__list_2_interrupt;
 string__to__char__list_2_ext_interrupt:
  reasonp = 0l;
 string__to__char__list_2_interrupt:
  goto interrupt_2;
 }

 string__to__char__list_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 string__to__char__list_4_clear_reason:
  reasonp = reasons;
 string__to__char__list_4_0:
 string__to__char__list_4_1:
  if (!isint(a2)) goto string__to__char__list_4_9;
 string__to__char__list_4_3:
  if (!isint(a3)) goto string__to__char__list_4_8;
  gblt_greater_or_eq(a2,a3,string__to__char__list_4_6);
  unify_value(a1, NILATOM);
  proceed();
 string__to__char__list_4_6:
  gblt_less(a2,a3,string__to__char__list_4_interrupt);
  generic_arg[0] = a2;
  allocp[0] = x0 = makeref(&allocp[0]);
  generic_arg[1] = x0;
  call_generic(a0, functor_element_2, 1);
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = x0;
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x1);
  bblt_add_no_check(a2,makeint(1L),x3);
  a1 = x2;
  a2 = x3;
  execute(string__to__char__list_4_0);
  goto string__to__char__list_4_ext_interrupt;
 string__to__char__list_4_8:
  if (!isref(a3)) goto string__to__char__list_4_interrupt;
  deref_and_jump(a3,string__to__char__list_4_3);
  *reasonp++ =  a3;
  goto string__to__char__list_4_interrupt;
 string__to__char__list_4_9:
  if (!isref(a2)) goto string__to__char__list_4_interrupt;
  deref_and_jump(a2,string__to__char__list_4_1);
  *reasonp++ =  a2;
  goto string__to__char__list_4_interrupt;
 string__to__char__list_4_ext_interrupt:
  reasonp = 0l;
 string__to__char__list_4_interrupt:
  toppred = &predicate_klic__comp__util_xstring__to__char__list_4;
  goto interrupt_4;
 }

 numbervars_4_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 numbervars_4_clear_reason:
  reasonp = reasons;
 numbervars_4_0:
  a4 = NILATOM;
  allocp[0] = x0 = makeref(&allocp[0]);
  a5 = x0;
  allocp += 1;
  execute(numbervars_6_0);
  goto numbervars_6_ext_interrupt;
 numbervars_4_ext_interrupt:
  reasonp = 0l;
 numbervars_4_interrupt:
  goto interrupt_4;
 }

 numbervars_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 numbervars_6_clear_reason:
  reasonp = reasons;
 numbervars_6_0:
 numbervars_6_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_atom_1:
  unify2(a5, a4, a3, a2);
  allocp[0] = makesym(functor_atom_1);
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  proceed();
 case functor_integer_1:
  unify2(a5, a4, a3, a2);
  allocp[0] = makesym(functor_integer_1);
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  proceed();
 case functor_floating__point_1:
  unify2(a5, a4, a3, a2);
  allocp[0] = makesym(functor_float_1);
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  proceed();
 case functor_string_1:
  unify2(a5, a4, a3, a2);
  allocp[0] = makesym(functor_string_1);
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  proceed();
 case functor_vector_1:
  x0 = arg(a0, 0);
 numbervars_6_8:
  switch (ptagof(x0)) {
 case FUNCTOR:
 numbervars_6_9:
  if (!isgobj(x0)) goto numbervars_6_30;
  if (!isclass(x0,vector)) goto numbervars_6_30;
  gblt_size_of_vector(x0,x1,numbervars_6_30);
  generic_arg[0] = x1;
  new_generic(vector_g_new, 1, x2, 0);
  a0 = makeint(0L);
  x3 = a2;
  x4 = a3;
  a6 = a1;
  a7 = a4;
  a8 = a5;
  a5 = x2;
  a4 = x4;
  a3 = x3;
  a2 = x0;
  a1 = x1;
  execute(numbervars__vector_9_0);
  goto numbervars__vector_9_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,numbervars_6_8);
  *reasonp++ =  x0;
  goto numbervars_6_30;
  };
  goto numbervars_6_30;
 case functor_functor_1:
  x0 = arg(a0, 0);
 numbervars_6_14:
  if (isref(x0)) goto numbervars_6_18;
  gblt_pfunctor(x0,x1,numbervars_6_30);
  gblt_arity(x0,x2,numbervars_6_30);
  allocp[0] = x4 = makeref(&allocp[0]);
  allocp[1] = x1;
  x3 = makecons(&allocp[0]);
  a0 = makeint(1L);
  x5 = x4;
  x6 = a1;
  a6 = a2;
  a7 = a3;
  a8 = a4;
  a9 = a5;
  a5 = x6;
  a4 = x3;
  a3 = x5;
  a2 = x0;
  a1 = x2;
  allocp += 2;
  execute(numbervars__funct_10_0);
  goto numbervars__funct_10_ext_interrupt;
 numbervars_6_18:
  deref_and_jump(x0,numbervars_6_14);
  *reasonp++ =  x0;
  goto numbervars_6_30;
 case functor_list_1:
  x0 = arg(a0, 0);
 numbervars_6_20:
  switch (ptagof(x0)) {
 case CONS:
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = x3 = makeref(&allocp[1]);
  x1 = makecons(&allocp[0]);
  allocp[2] = makesym(functor_list_1);
  allocp[3] = x1;
  x4 = makefunctor(&allocp[2]);
  allocp += 4;
  unify_value(a1, x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__util_xnumbervars_6);
  x5 = cdr_of(x0);
  allocp[2] = x5;
  allocp[3] = x2;
  allocp[4] = x6 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x7 = makeref(&allocp[6]);
  allocp[7] = a5;
  a0 = car_of(x0);
  a1 = x3;
  a3 = x6;
  a5 = x7;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  execute(numbervars_6_0);
  goto numbervars_6_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,numbervars_6_20);
  *reasonp++ =  x0;
  goto numbervars_6_30;
  };
  goto numbervars_6_30;
 case functor_variable_1:
  x0 = arg(a0, 0);
 numbervars_6_23:
  if (isref(x0)) goto numbervars_6_29;
 numbervars_6_25:
  if (isref(x0)) goto numbervars_6_28;
  x1 = makefunctor(&string_const_0);
  if_not_equal(x0, x1, numbervars_6_30);
  unify(a5, a4);
  bblt_add_no_check_y(a2,makeint(1L),x2);
  unify(a3, x2);
  allocp[0] = makesym(functor_variable_1);
  allocp[1] = a2;
  x3 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x3);
  proceed();
 numbervars_6_28:
  deref_and_jump(x0,numbervars_6_25);
  *reasonp++ =  x0;
  goto numbervars_6_30;
 numbervars_6_29:
  deref_and_jump(x0,numbervars_6_23);
  *reasonp++ =  x0;
  goto numbervars_6_30;
 default:
  goto numbervars_6_30;
  };
 case VARREF:
  deref_and_jump(a0,numbervars_6_1);
  *reasonp++ =  a0;
  goto numbervars_6_30;
  };
  goto numbervars_6_30;
 numbervars_6_30:
  otherwise(numbervars_6_interrupt);
 numbervars_6_32:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_variable_1)) goto numbervars_6_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__util_xnumbervars__1_7);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  x1 = arg(a0, 0);
  allocp[4] = x1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  a0 = a4;
  a1 = x1;
  a2 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 9;
  execute(assoc_3_0);
  goto assoc_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,numbervars_6_32);
  *reasonp++ =  a0;
  goto numbervars_6_interrupt;
  };
  goto numbervars_6_interrupt;
 numbervars_6_ext_interrupt:
  reasonp = 0l;
 numbervars_6_interrupt:
  toppred = &predicate_klic__comp__util_xnumbervars_6;
  goto interrupt_6;
 }

 numbervars__1_7_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 numbervars__1_7_clear_reason:
  reasonp = reasons;
 numbervars__1_7_0:
 numbervars__1_7_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_no)) goto numbervars__1_7_interrupt;
  allocp[0] = makesym(functor_variable_1);
  allocp[1] = a3;
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = makesym(functor__3D_2);
  allocp[1] = a2;
  allocp[2] = a3;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a5;
  allocp[4] = x1;
  x2 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a6, x2);
  bblt_add_no_check_y(a3,makeint(1L),x3);
  unify(a4, x3);
  proceed();
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_yes_1)) goto numbervars__1_7_interrupt;
  unify2(a6, a5, a4, a3);
  allocp[0] = makesym(functor_variable_1);
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  proceed();
 case VARREF:
  deref_and_jump(a0,numbervars__1_7_1);
  *reasonp++ =  a0;
  goto numbervars__1_7_interrupt;
  };
  goto numbervars__1_7_interrupt;
 numbervars__1_7_ext_interrupt:
  reasonp = 0l;
 numbervars__1_7_interrupt:
  goto interrupt_7;
 }

 numbervars__vector_9_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 numbervars__vector_9_clear_reason:
  reasonp = reasons;
 numbervars__vector_9_0:
 numbervars__vector_9_1:
  if (!isint(a0)) goto numbervars__vector_9_9;
 numbervars__vector_9_3:
  if (!isint(a1)) goto numbervars__vector_9_8;
  gblt_greater_or_eq(a0,a1,numbervars__vector_9_6);
  unify2(a8, a7, a3, a4);
  allocp[0] = makesym(functor_vector_1);
  allocp[1] = a5;
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a6, x0);
  proceed();
 numbervars__vector_9_6:
  gblt_less(a0,a1,numbervars__vector_9_interrupt);
  bblt_add_no_check(a0,makeint(1L),x0);
  generic_arg[0] = a0;
  allocp[0] = x1 = makeref(&allocp[0]);
  generic_arg[1] = x1;
  call_generic(a2, functor_element_2, 1);
  generic_arg[0] = a0;
  allocp[0] = x2 = makeref(&allocp[0]);
  generic_arg[1] = x2;
  allocp[1] = x3 = makeref(&allocp[1]);
  generic_arg[2] = x3;
  call_generic(a5, functor_set__element_3, 2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__util_xnumbervars__vector_9);
  allocp[2] = x0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x4 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x3;
  allocp[8] = a6;
  allocp[9] = x5 = makeref(&allocp[9]);
  allocp[10] = a8;
  a0 = x1;
  a1 = x2;
  a2 = a3;
  a3 = x4;
  a4 = a7;
  a5 = x5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 11;
  execute(numbervars_6_0);
  goto numbervars_6_ext_interrupt;
 numbervars__vector_9_8:
  if (!isref(a1)) goto numbervars__vector_9_interrupt;
  deref_and_jump(a1,numbervars__vector_9_3);
  *reasonp++ =  a1;
  goto numbervars__vector_9_interrupt;
 numbervars__vector_9_9:
  if (!isref(a0)) goto numbervars__vector_9_interrupt;
  deref_and_jump(a0,numbervars__vector_9_1);
  *reasonp++ =  a0;
  goto numbervars__vector_9_interrupt;
 numbervars__vector_9_ext_interrupt:
  reasonp = 0l;
 numbervars__vector_9_interrupt:
  toppred = &predicate_klic__comp__util_xnumbervars__vector_9;
  goto interrupt_9;
 }

 numbervars__funct_10_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 numbervars__funct_10_clear_reason:
  reasonp = reasons;
 numbervars__funct_10_0:
 numbervars__funct_10_1:
  if (!isint(a0)) goto numbervars__funct_10_14;
 numbervars__funct_10_3:
  if (!isint(a1)) goto numbervars__funct_10_13;
  gblt_greater(a0,a1,numbervars__funct_10_6);
  unify2(a9, a8, a7, a6);
  unify_value(a3, NILATOM);
  allocp[0] = makesym(functor_functor_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a5, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[2] = x1;
  allocp[3] = a4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  proceed();
 numbervars__funct_10_6:
  gblt_less_or_eq(a0,a1,numbervars__funct_10_interrupt);
 numbervars__funct_10_8:
  if (isref(a2)) goto numbervars__funct_10_12;
  gblt_arg(a0,a2,x0,numbervars__funct_10_interrupt);
  gblt_add(a0,makeint(1L),x1,numbervars__funct_10_interrupt);
  allocp[0] = x3 = makeref(&allocp[0]);
  allocp[1] = x4 = makeref(&allocp[1]);
  x2 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a3, x2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__util_xnumbervars__funct_10);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = x5 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x6 = makeref(&allocp[10]);
  allocp[11] = a9;
  a0 = x0;
  a1 = x4;
  a2 = a6;
  a3 = x5;
  a4 = a8;
  a5 = x6;
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  execute(numbervars_6_0);
  goto numbervars_6_ext_interrupt;
 numbervars__funct_10_12:
  deref_and_jump(a2,numbervars__funct_10_8);
  *reasonp++ =  a2;
  goto numbervars__funct_10_interrupt;
 numbervars__funct_10_13:
  if (!isref(a1)) goto numbervars__funct_10_interrupt;
  deref_and_jump(a1,numbervars__funct_10_3);
  *reasonp++ =  a1;
  goto numbervars__funct_10_interrupt;
 numbervars__funct_10_14:
  if (!isref(a0)) goto numbervars__funct_10_interrupt;
  deref_and_jump(a0,numbervars__funct_10_1);
  *reasonp++ =  a0;
  goto numbervars__funct_10_interrupt;
 numbervars__funct_10_ext_interrupt:
  reasonp = 0l;
 numbervars__funct_10_interrupt:
  toppred = &predicate_klic__comp__util_xnumbervars__funct_10;
  goto interrupt_10;
 }

 make__atom_2_top: {
  q x0;
  qp = qp->next;
 make__atom_2_clear_reason:
  reasonp = reasons;
 make__atom_2_0:
  generic_arg[0] = a0;
  generic_arg[1] = makeint(8L);
  new_generic(string_g_new, 2, x0, 0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_atom__table_xmake__atom_2);
  allocp[2] = x0;
  allocp[3] = a1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  proceed();
 make__atom_2_ext_interrupt:
  reasonp = 0l;
 make__atom_2_interrupt:
  goto interrupt_2;
 }
 interrupt_10:
  allocp[11] = a9;
 interrupt_9:
  allocp[10] = a8;
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_klic__comp__util);
}
