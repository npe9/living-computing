#include <klic/basic.h>
#include <klic/struct.h>
#include <klic/primitives.h>
#include <klic/unify.h>
#include <klic/timing.h>
#include <klic/index.h>

#include <stdio.h>
#include <setjmp.h>
#include <malloc.h>

#include <klic/interpe.h>
#include <klic/distio.h>
#include <klic/traceio.h>

extern int exref_g_generator_method_table;
extern int read_hook_g_data_method_table;

extern char *malloc(), *realloc();

void regist_imp_entry(obj)
     q obj;
{
  long import;

  if(top_of_imp_freelist.next == END_IMP_FREELIST){
    char *imp_alloc;

    imp_alloc = realloc((char *)imp_table,
       (current_imp_size+IMP_TABLE_INC_SIZE)*sizeof(struct imp_entry));

    if(imp_alloc == NULL){
      fatal("realloc failed in initiate_imp_table");
    }
    imp_table = (struct imp_entry*)imp_alloc;
    initiate_allocated_imp_table();

    sprintf(iobuf,"Import table expanded\n");
    EPrint(iobuf);
  }

  import = top_of_imp_freelist.next;
  top_of_imp_freelist.next = imp_table[import].next;

  imp_table[import].object = obj;

  imp_table[import].next = imp_table[0].next;

  imp_table[0].next = import;

  active_imp_rec++;
  free_imp_rec--;
}

struct exref_object{
  struct generator_object_method_table *method_table;
  long pe_num;
  long index;
  long wec;
  q to_exref;
  long gc_flag;
};

void send_release_after_gc(next_import)
     long next_import;
{
  struct exref_object *exref;
  
  exref = (struct exref_object *)(imp_table[next_import].object);

  if(exref->pe_num>total_node){
    sprintf(iobuf,"next_import is %d\n",next_import);
    EPrint(iobuf);
    sprintf(iobuf,"PE %d invalid pe_num in send_release_after_gc\n",my_node);
    EPrint(iobuf);
    ERROR_STOP;

    fatal("invalid pe_num in send_release_after_gc");
  }

  send_release(exref->pe_num, exref->index, exref->wec);
}

void  check_imp_after_scan();
void  check_imp_before_scan();

q* scan_imp_table(allocp)
     q* allocp;
{
  declare_globals;
  long next_imp, next_imp_d, prev_imp;

  struct exref_object *ex_obj, *ex_obj_d;

/*  if(node_wtc == 0){
    fatal("invalid WTC in scan import table");
  }*/

  check_imp_before_scan();

  prev_imp = 0;
  next_imp = imp_table[prev_imp].next;

  while(next_imp != END_IMP_TABLE){
    ex_obj = (struct exref_object *)imp_table[next_imp].object;
    
    switch(ex_obj->gc_flag){
    case IMPREC_COPIED:
      imp_table[next_imp].object = (q)derefone(ex_obj);
      ex_obj_d = ex_obj;

      (long)imp_table[next_imp].object = (long)imp_table[next_imp].object>>2;
      (long)imp_table[next_imp].object = (long)imp_table[next_imp].object<<2;
      
      ex_obj = (struct exref_object *)imp_table[next_imp].object;
      ex_obj->gc_flag = IMPREC_NOT_COPIED;

      prev_imp = next_imp;
      next_imp = imp_table[next_imp].next;
      break;

    case IMPREC_NOT_COPIED:

      imp_table[prev_imp].next = imp_table[next_imp].next;
      next_imp_d = imp_table[next_imp].next;

      send_release_after_gc(next_imp);

      imp_table[next_imp].next = top_of_imp_freelist.next;
      top_of_imp_freelist.next = next_imp;

      next_imp = next_imp_d;

      active_imp_rec--;
      free_imp_rec++;
      break;

    case IMPREC_RELEASED:
      imp_table[prev_imp].next = imp_table[next_imp].next;
      next_imp_d = imp_table[next_imp].next;

      imp_table[next_imp].next = top_of_imp_freelist.next;
      top_of_imp_freelist.next = next_imp;

      next_imp = next_imp_d;

      active_imp_rec--;
      free_imp_rec++;
      break;
    default:
      sprintf(iobuf,"invalid gc_flag in imprec\n");
      EPrint(iobuf);
      for(;;);
      break;
    }
  }

  check_imp_after_scan();

  return(allocp);
}


void check_imp_before_scan()
{
  struct exref_object *ex_ref;
  int next_impo = imp_table[0].next;

  while(next_impo != END_IMP_TABLE){
    ex_ref = (struct exref_object *)imp_table[next_impo].object;
    if(intval(ex_ref->pe_num)>total_node){
      sprintf(iobuf,"next_impo is %d\n",next_impo);
      EPrint(iobuf);
      fatal("invalid pe_num in checi_imp_before_scan");
    }
    next_impo = imp_table[next_impo].next;
  }
}


void check_imp_after_scan()
{
  struct exref_object *ex_ref;
  int next_impor = imp_table[0].next;

  while(next_impor != END_IMP_TABLE){
    ex_ref = (struct exref_object *)imp_table[next_impor].object;
    if(intval(ex_ref->pe_num)>total_node){
      sprintf(iobuf,"next_impor is %d\n",next_impor);
      EPrint(iobuf);
      fatal("invalid pe_num in checi_imp_after_scan");
    }

    next_impor = imp_table[next_impor].next;
  }
}
