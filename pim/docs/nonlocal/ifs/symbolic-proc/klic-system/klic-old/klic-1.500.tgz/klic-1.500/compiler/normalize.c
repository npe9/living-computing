/* Compiled by KLIC compiler version 1.500 (Fri Oct 21 12:19:27 JST 1994) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_klic__comp__normalize();
Const struct predicate predicate_klic__comp__normalize_xgenerate_8 =
   { module_klic__comp__normalize, 0, 8 };
Const struct predicate predicate_klic__comp__normalize_xmake__arg__assoc_3 =
   { module_klic__comp__normalize, 1, 3 };
Const struct predicate predicate_klic__comp__normalize_xseparate__cond_5 =
   { module_klic__comp__normalize, 2, 5 };
Const struct predicate predicate_klic__comp__normalize_xseparate__cond_2F5_241_5 =
   { module_klic__comp__normalize, 3, 5 };
Const struct predicate predicate_klic__comp__normalize_xseparate__cond_2F5_240_5 =
   { module_klic__comp__normalize, 4, 5 };
Const struct predicate predicate_klic__comp__normalize_xseparate__cond__1_9 =
   { module_klic__comp__normalize, 5, 9 };
Const struct predicate predicate_klic__comp__normalize_xnorm__head_5 =
   { module_klic__comp__normalize, 6, 5 };
Const struct predicate predicate_klic__comp__normalize_xnorm__args_8 =
   { module_klic__comp__normalize, 7, 8 };
Const struct predicate predicate_klic__comp__normalize_xnorm__guard__term_6 =
   { module_klic__comp__normalize, 8, 6 };
Const struct predicate predicate_klic__comp__normalize_xnorm__guard__term__1_7 =
   { module_klic__comp__normalize, 9, 7 };
Const struct predicate predicate_klic__comp__normalize_xnorm__guard_10 =
   { module_klic__comp__normalize, 10, 10 };
Const struct predicate predicate_klic__comp__normalize_xnorm__guard_2F10_241_11 =
   { module_klic__comp__normalize, 11, 11 };
Const struct predicate predicate_klic__comp__normalize_xnorm__guard_2F10_240_11 =
   { module_klic__comp__normalize, 12, 11 };
Const struct predicate predicate_klic__comp__normalize_xnorm__guard__goal_8 =
   { module_klic__comp__normalize, 13, 8 };
Const struct predicate predicate_klic__comp__normalize_xnorm__guard__goal_2F8_241_8 =
   { module_klic__comp__normalize, 14, 8 };
Const struct predicate predicate_klic__comp__normalize_xnorm__guard__goal_2F8_240_9 =
   { module_klic__comp__normalize, 15, 9 };
Const struct predicate predicate_klic__comp__normalize_xnorm__inline_12 =
   { module_klic__comp__normalize, 16, 12 };
Const struct predicate predicate_klic__comp__normalize_xnorm__inline_2F12_240_13 =
   { module_klic__comp__normalize, 17, 13 };
Const struct predicate predicate_klic__comp__normalize_xnorm__inline__arg_11 =
   { module_klic__comp__normalize, 18, 11 };
Const struct predicate predicate_klic__comp__normalize_xnorm__inline__arg_10 =
   { module_klic__comp__normalize, 19, 10 };
Const struct predicate predicate_klic__comp__normalize_xnorm__inline__arg__1_7 =
   { module_klic__comp__normalize, 20, 7 };
Const struct predicate predicate_klic__comp__normalize_xinline__arg__type_2 =
   { module_klic__comp__normalize, 21, 2 };
Const struct predicate predicate_klic__comp__normalize_xnorm__guard__unify_9 =
   { module_klic__comp__normalize, 22, 9 };
Const struct predicate predicate_klic__comp__normalize_xnorm__guard__unify_2F9_241_10 =
   { module_klic__comp__normalize, 23, 10 };
Const struct predicate predicate_klic__comp__normalize_xnorm__guard__unify_2F9_241_2F10_240_9 =
   { module_klic__comp__normalize, 24, 9 };
Const struct predicate predicate_klic__comp__normalize_xnorm__guard__unify_2F9_240_10 =
   { module_klic__comp__normalize, 25, 10 };
Const struct predicate predicate_klic__comp__normalize_xnorm__guard__unify__new_6 =
   { module_klic__comp__normalize, 26, 6 };
Const struct predicate predicate_klic__comp__normalize_xnorm__guard__unify__new_2F6_240_7 =
   { module_klic__comp__normalize, 27, 7 };
Const struct predicate predicate_klic__comp__normalize_xnorm__guard__unify__args_10 =
   { module_klic__comp__normalize, 28, 10 };
Const struct predicate predicate_klic__comp__normalize_xnorm__guard__generic_8 =
   { module_klic__comp__normalize, 29, 8 };
Const struct predicate predicate_klic__comp__normalize_xnorm__guard__generic__1_14 =
   { module_klic__comp__normalize, 30, 14 };
Const struct predicate predicate_klic__comp__normalize_xnorm__guard__generic__2_14 =
   { module_klic__comp__normalize, 31, 14 };
Const struct predicate predicate_klic__comp__normalize_xnorm__guard__generic__3_13 =
   { module_klic__comp__normalize, 32, 13 };
Const struct predicate predicate_klic__comp__normalize_xnorm__gg__in__out_7 =
   { module_klic__comp__normalize, 33, 7 };
Const struct predicate predicate_klic__comp__normalize_xnorm__gg__count__out_4 =
   { module_klic__comp__normalize, 34, 4 };
Const struct predicate predicate_klic__comp__normalize_xnorm__gg_5 =
   { module_klic__comp__normalize, 35, 5 };
Const struct predicate predicate_klic__comp__normalize_xnorm__gg__1_8 =
   { module_klic__comp__normalize, 36, 8 };
Const struct predicate predicate_klic__comp__normalize_xnorm__gg__2_6 =
   { module_klic__comp__normalize, 37, 6 };
Const struct predicate predicate_klic__comp__normalize_xnorm__gg__ins_8 =
   { module_klic__comp__normalize, 38, 8 };
Const struct predicate predicate_klic__comp__normalize_xnorm__gg__ins__1_9 =
   { module_klic__comp__normalize, 39, 9 };
Const struct predicate predicate_klic__comp__normalize_xnorm__gg__in_9 =
   { module_klic__comp__normalize, 40, 9 };
Const struct predicate predicate_klic__comp__normalize_xnorm__gg__in__1_11 =
   { module_klic__comp__normalize, 41, 11 };
Const struct predicate predicate_klic__comp__normalize_xnorm__gg__in__2_8 =
   { module_klic__comp__normalize, 42, 8 };
Const struct predicate predicate_klic__comp__normalize_xnorm__gg__outs_9 =
   { module_klic__comp__normalize, 43, 9 };
Const struct predicate predicate_klic__comp__normalize_xnorm__guard__builts_8 =
   { module_klic__comp__normalize, 44, 8 };
Const struct predicate predicate_klic__comp__normalize_xnorm__guard__builts__1_12 =
   { module_klic__comp__normalize, 45, 12 };
Const struct predicate predicate_klic__comp__normalize_xnorm__gblt__args_8 =
   { module_klic__comp__normalize, 46, 8 };
Const struct predicate predicate_klic__comp__normalize_xnorm__gblt__args__1_9 =
   { module_klic__comp__normalize, 47, 9 };
Const struct predicate predicate_klic__comp__normalize_xnorm__gblt__arg_9 =
   { module_klic__comp__normalize, 48, 9 };
Const struct predicate predicate_klic__comp__normalize_xnorm__gblt__arg__1_10 =
   { module_klic__comp__normalize, 49, 10 };
Const struct predicate predicate_klic__comp__normalize_xnorm__gblt__arg__2_8 =
   { module_klic__comp__normalize, 50, 8 };
Const struct predicate predicate_klic__comp__normalize_xcheck__gblt__input_5 =
   { module_klic__comp__normalize, 51, 5 };
Const struct predicate predicate_klic__comp__normalize_xnorm__body_6 =
   { module_klic__comp__normalize, 52, 6 };
Const struct predicate predicate_klic__comp__normalize_xnorm__body__1_9 =
   { module_klic__comp__normalize, 53, 9 };
Const struct predicate predicate_klic__comp__normalize_xnorm__body__tail_7 =
   { module_klic__comp__normalize, 54, 7 };
Const struct predicate predicate_klic__comp__normalize_xnorm__body__tail__1_8 =
   { module_klic__comp__normalize, 55, 8 };
Const struct predicate predicate_klic__comp__normalize_xnorm__top__goal_7 =
   { module_klic__comp__normalize, 56, 7 };
Const struct predicate predicate_klic__comp__normalize_xnorm__top__goal__unify_8 =
   { module_klic__comp__normalize, 57, 8 };
Const struct predicate predicate_klic__comp__normalize_xnorm__top__goal__builtin_7 =
   { module_klic__comp__normalize, 58, 7 };
Const struct predicate predicate_klic__comp__normalize_xnorm__tail__goal_7 =
   { module_klic__comp__normalize, 59, 7 };
Const struct predicate predicate_klic__comp__normalize_xnorm__tail__goal__unify_8 =
   { module_klic__comp__normalize, 60, 8 };
Const struct predicate predicate_klic__comp__normalize_xnorm__tail__goal__generic_9 =
   { module_klic__comp__normalize, 61, 9 };
Const struct predicate predicate_klic__comp__normalize_xnorm__tail__goal__builtin_8 =
   { module_klic__comp__normalize, 62, 8 };
Const struct predicate predicate_klic__comp__normalize_xnorm__pragma_8 =
   { module_klic__comp__normalize, 63, 8 };
Const struct predicate predicate_klic__comp__normalize_xnorm__pragma__0_9 =
   { module_klic__comp__normalize, 64, 9 };
Const struct predicate predicate_klic__comp__normalize_xnorm__pragma__1_8 =
   { module_klic__comp__normalize, 65, 8 };
Const struct predicate predicate_klic__comp__normalize_xnorm__pragma__priority_8 =
   { module_klic__comp__normalize, 66, 8 };
Const struct predicate predicate_klic__comp__normalize_xnorm__pragma__lower__priority_8 =
   { module_klic__comp__normalize, 67, 8 };
Const struct predicate predicate_klic__comp__normalize_xnorm__pragma__node_8 =
   { module_klic__comp__normalize, 68, 8 };
Const struct predicate predicate_klic__comp__normalize_xnorm__pragma__pragma__arg_8 =
   { module_klic__comp__normalize, 69, 8 };
Const struct predicate predicate_klic__comp__normalize_xnorm__body__args_9 =
   { module_klic__comp__normalize, 70, 9 };
Const struct predicate predicate_klic__comp__normalize_xnorm__body__args_7 =
   { module_klic__comp__normalize, 71, 7 };
Const struct predicate predicate_klic__comp__normalize_xnorm__body__args__1_8 =
   { module_klic__comp__normalize, 72, 8 };
Const struct predicate predicate_klic__comp__normalize_xnorm__body__arg_7 =
   { module_klic__comp__normalize, 73, 7 };
Const struct predicate predicate_klic__comp__normalize_xnorm__body__arg__1_9 =
   { module_klic__comp__normalize, 74, 9 };
Const struct predicate predicate_klic__comp__normalize_xnorm__body__arg__2_7 =
   { module_klic__comp__normalize, 75, 7 };
Const struct predicate predicate_klic__comp__normalize_xnorm__body__arg__3_8 =
   { module_klic__comp__normalize, 76, 8 };
Const struct predicate predicate_klic__comp__normalize_xnorm__body__arg__3__1_10 =
   { module_klic__comp__normalize, 77, 10 };
Const struct predicate predicate_klic__comp__normalize_xnorm__body__arg__3__2_6 =
   { module_klic__comp__normalize, 78, 6 };
Const struct predicate predicate_klic__comp__normalize_xis__const_5 =
   { module_klic__comp__normalize, 79, 5 };
Const struct predicate predicate_klic__comp__normalize_xis__const__1_6 =
   { module_klic__comp__normalize, 80, 6 };
Const struct predicate predicate_klic__comp__normalize_xis__const__args_3 =
   { module_klic__comp__normalize, 81, 3 };
extern Const struct predicate predicate_klic__comp__generate_xgen__code_14;
extern Const struct predicate predicate_klic__comp__insert_xmake__index__tree_5;
extern Const struct predicate predicate_klic__comp__util_xappend_3;
extern Const struct predicate predicate_klic__comp__gb_xis__guard__builtin_2;
extern Const struct predicate predicate_klic__comp__util_xlength_2;
extern Const struct predicate predicate_functor__table_xarg_3;
extern Const struct predicate predicate_integer__arithmetics_xadd_3;
extern Const struct predicate predicate_klic__comp__util_xassoc_3;
extern Const struct predicate predicate_klic__comp__insert_xsubsumed__type_3;
extern Const struct predicate predicate_klic__comp__kl1cmp_xwarning_4;
extern Const struct predicate predicate_functor__table_x_3D_2E_2E_2;
extern Const struct predicate predicate_klic__comp__bb_xis__body__builtin_2;
extern Const struct predicate predicate_klic__comp__kl1cmp_xreport__error_4;
extern Const struct predicate predicate_klic__comp__util_xassoc_4;
extern Const struct predicate predicate_klic__comp__util_xuniv_2;
extern Const struct predicate predicate_klic__comp__util_xvector__to__list_2;

module module_klic__comp__normalize(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  Const static unsigned char strconst_body_0[52] =
    "No clauses follow \"otherwise\"; \"otherwise\" ignored";
  Const static string_structure_type_8 string_const_0 =
      declare_string_constant_8(strconst_body_0,50);
  Const static unsigned char strconst_body_1[60] =
    "No clauses follow \"alternatively\"; \"alternatively\" ignored";
  Const static string_structure_type_8 string_const_1 =
      declare_string_constant_8(strconst_body_1,58);
  Const static unsigned char strconst_body_2[20] =
    "Clause deleted: ~w";
  Const static string_structure_type_8 string_const_2 =
      declare_string_constant_8(strconst_body_2,18);
  Const static q funct_const_3[] = {
    makesym(functor_atom_1),
    NILATOM,
  };
  Const static unsigned char strconst_body_4[28] =
    "Unrecognized guard goal: ~w";
  Const static string_structure_type_8 string_const_4 =
      declare_string_constant_8(strconst_body_4,27);
  Const static unsigned char strconst_body_5[32] =
    "Illegal argument to inline: ~w";
  Const static string_structure_type_8 string_const_5 =
      declare_string_constant_8(strconst_body_5,30);
  Const static unsigned char strconst_body_6[52] =
    "Non-first variable occurrence as inline output: ~w";
  Const static string_structure_type_8 string_const_6 =
      declare_string_constant_8(strconst_body_6,50);
  Const static unsigned char strconst_body_7[32] =
    "Unification always fails: ~w=~w";
  Const static string_structure_type_8 string_const_7 =
      declare_string_constant_8(strconst_body_7,31);
  Const static unsigned char strconst_body_8[48] =
    "Structure allocation not allowed in guard: ~w";
  Const static string_structure_type_8 string_const_8 =
      declare_string_constant_8(strconst_body_8,45);
  Const static unsigned char strconst_body_9[36] =
    "Never proceeding guard generic call";
  Const static string_structure_type_8 string_const_9 =
      declare_string_constant_8(strconst_body_9,35);
  Const static unsigned char strconst_body_10[40] =
    {'N','o','n','-','o','b','j','e','c','t',' ','g','i','v','e','n',' ','a','s',' ','g','e','n','e','r','i','c',' ','c','a','l','l',' ','a','r','g',':',' ','~','w',};
  Const static string_structure_type_8 string_const_10 =
      declare_string_constant_8(strconst_body_10,40);
  Const static unsigned char strconst_body_11[52] =
    "Non-const structure in guard generic call arg: ~w";
  Const static string_structure_type_8 string_const_11 =
      declare_string_constant_8(strconst_body_11,49);
  Const static unsigned char strconst_body_12[32] =
    "Never proceeding guard builtin";
  Const static string_structure_type_8 string_const_12 =
      declare_string_constant_8(strconst_body_12,30);
  Const static unsigned char strconst_body_13[44] =
    {'N','o','n','-','c','o','n','s','t',' ','s','t','r','u','c','t','u','r','e',' ','i','n',' ','g','u','a','r','d',' ','b','u','i','l','t','i','n',' ','a','r','g',':',' ','~','w',};
  Const static string_structure_type_8 string_const_13 =
      declare_string_constant_8(strconst_body_13,44);
  Const static unsigned char strconst_body_14[36] =
    "Guard builtin arg type mismatch: ~w";
  Const static string_structure_type_8 string_const_14 =
      declare_string_constant_8(strconst_body_14,35);
  Const static q funct_const_15[] = {
    makesym(functor_atom_1),
    makesym(atom_generic),
  };
  Const static unsigned char strconst_body_16[40] =
    "Ignored pragma for a generic call: ~w";
  Const static string_structure_type_8 string_const_16 =
      declare_string_constant_8(strconst_body_16,37);
  Const static q funct_const_17[] = {
    makesym(functor_integer_1),
    makeint(1),
  };
  Const static q funct_const_18[] = {
    makesym(functor_lower__priority_1),
    makefunctor(funct_const_17),
  };
  Const static q funct_const_19[] = {
    makesym(functor_functor_1),
    makefunctor(funct_const_18),
  };
  Const static unsigned char strconst_body_20[40] =
    "Illegal pragma: ~w attached to goal: ~w";
  Const static string_structure_type_8 string_const_20 =
      declare_string_constant_8(strconst_body_20,39);
  q a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, generate_8_top);
    case_pred(1, make__arg__assoc_3_top);
    case_pred(2, separate__cond_5_top);
    case_pred(3, separate__cond_2F5_241_5_top);
    case_pred(4, separate__cond_2F5_240_5_top);
    case_pred(5, separate__cond__1_9_top);
    case_pred(6, norm__head_5_top);
    case_pred(7, norm__args_8_top);
    case_pred(8, norm__guard__term_6_top);
    case_pred(9, norm__guard__term__1_7_top);
    case_pred(10, norm__guard_10_top);
    case_pred(11, norm__guard_2F10_241_11_top);
    case_pred(12, norm__guard_2F10_240_11_top);
    case_pred(13, norm__guard__goal_8_top);
    case_pred(14, norm__guard__goal_2F8_241_8_top);
    case_pred(15, norm__guard__goal_2F8_240_9_top);
    case_pred(16, norm__inline_12_top);
    case_pred(17, norm__inline_2F12_240_13_top);
    case_pred(18, norm__inline__arg_11_top);
    case_pred(19, norm__inline__arg_10_top);
    case_pred(20, norm__inline__arg__1_7_top);
    case_pred(21, inline__arg__type_2_top);
    case_pred(22, norm__guard__unify_9_top);
    case_pred(23, norm__guard__unify_2F9_241_10_top);
    case_pred(24, norm__guard__unify_2F9_241_2F10_240_9_top);
    case_pred(25, norm__guard__unify_2F9_240_10_top);
    case_pred(26, norm__guard__unify__new_6_top);
    case_pred(27, norm__guard__unify__new_2F6_240_7_top);
    case_pred(28, norm__guard__unify__args_10_top);
    case_pred(29, norm__guard__generic_8_top);
    case_pred(30, norm__guard__generic__1_14_top);
    case_pred(31, norm__guard__generic__2_14_top);
    case_pred(32, norm__guard__generic__3_13_top);
    case_pred(33, norm__gg__in__out_7_top);
    case_pred(34, norm__gg__count__out_4_top);
    case_pred(35, norm__gg_5_top);
    case_pred(36, norm__gg__1_8_top);
    case_pred(37, norm__gg__2_6_top);
    case_pred(38, norm__gg__ins_8_top);
    case_pred(39, norm__gg__ins__1_9_top);
    case_pred(40, norm__gg__in_9_top);
    case_pred(41, norm__gg__in__1_11_top);
    case_pred(42, norm__gg__in__2_8_top);
    case_pred(43, norm__gg__outs_9_top);
    case_pred(44, norm__guard__builts_8_top);
    case_pred(45, norm__guard__builts__1_12_top);
    case_pred(46, norm__gblt__args_8_top);
    case_pred(47, norm__gblt__args__1_9_top);
    case_pred(48, norm__gblt__arg_9_top);
    case_pred(49, norm__gblt__arg__1_10_top);
    case_pred(50, norm__gblt__arg__2_8_top);
    case_pred(51, check__gblt__input_5_top);
    case_pred(52, norm__body_6_top);
    case_pred(53, norm__body__1_9_top);
    case_pred(54, norm__body__tail_7_top);
    case_pred(55, norm__body__tail__1_8_top);
    case_pred(56, norm__top__goal_7_top);
    case_pred(57, norm__top__goal__unify_8_top);
    case_pred(58, norm__top__goal__builtin_7_top);
    case_pred(59, norm__tail__goal_7_top);
    case_pred(60, norm__tail__goal__unify_8_top);
    case_pred(61, norm__tail__goal__generic_9_top);
    case_pred(62, norm__tail__goal__builtin_8_top);
    case_pred(63, norm__pragma_8_top);
    case_pred(64, norm__pragma__0_9_top);
    case_pred(65, norm__pragma__1_8_top);
    case_pred(66, norm__pragma__priority_8_top);
    case_pred(67, norm__pragma__lower__priority_8_top);
    case_pred(68, norm__pragma__node_8_top);
    case_pred(69, norm__pragma__pragma__arg_8_top);
    case_pred(70, norm__body__args_9_top);
    case_pred(71, norm__body__args_7_top);
    case_pred(72, norm__body__args__1_8_top);
    case_pred(73, norm__body__arg_7_top);
    case_pred(74, norm__body__arg__1_9_top);
    case_pred(75, norm__body__arg__2_7_top);
    case_pred(76, norm__body__arg__3_8_top);
    case_pred(77, norm__body__arg__3__1_10_top);
    case_pred(78, norm__body__arg__3__2_6_top);
    case_pred(79, is__const_5_top);
    case_pred(80, is__const__1_6_top);
    last_case_pred(81, is__const__args_3_top);
  }

 generate_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 generate_8_clear_reason:
  reasonp = reasons;
 generate_8_0:
 generate_8_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor__2F_2)) goto generate_8_interrupt;
  allocp[0] = makesym(functor_lab_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__generate_xgen__code_14);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = makesym(atom_interrupt);
  allocp[6] = x0;
  allocp[7] = makeint(0L);
  allocp[8] = a2;
  allocp[9] = makeint(0L);
  allocp[10] = x3 = makeref(&allocp[10]);
  allocp[11] = x4 = makeref(&allocp[11]);
  allocp[12] = makeint(0L);
  allocp[13] = x5 = makeref(&allocp[13]);
  allocp[14] = a3;
  allocp[15] = a4;
  allocp[16] = a5;
  allocp[17] = NILATOM;
  allocp[18] = (q)(struct goalrec*)&allocp[2];
  allocp[19] = (q)(&predicate_klic__comp__normalize_xmake__arg__assoc_3);
  allocp[20] = makeint(0L);
  x6 = arg(a0, 1);
  allocp[21] = x6;
  allocp[22] = x4;
  allocp[23] = makesym(functor__2F_2);
  x8 = arg(a0, 0);
  allocp[24] = x8;
  allocp[25] = x6;
  x7 = makefunctor(&allocp[23]);
  allocp[26] = (q)(struct goalrec*)&allocp[18];
  allocp[27] = (q)(&predicate_klic__comp__insert_xmake__index__tree_5);
  allocp[28] = x9 = makeref(&allocp[28]);
  allocp[29] = NILATOM;
  allocp[30] = makesym(atom_e);
  allocp[31] = x2;
  allocp[32] = x7;
  a0 = a1;
  a1 = x9;
  allocp[33] = x10 = makeref(&allocp[33]);
  a2 = x10;
  a3 = a6;
  a4 = a7;
  qp = (struct goalrec*)&allocp[26];
  allocp += 34;
  execute(separate__cond_5_0);
  goto separate__cond_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,generate_8_1);
  *reasonp++ =  a0;
  goto generate_8_interrupt;
  };
  goto generate_8_interrupt;
 generate_8_ext_interrupt:
  reasonp = 0l;
 generate_8_interrupt:
  goto interrupt_8;
 }

 make__arg__assoc_3_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  qp = qp->next;
 make__arg__assoc_3_clear_reason:
  reasonp = reasons;
 make__arg__assoc_3_0:
 make__arg__assoc_3_1:
  if (!isint(a0)) goto make__arg__assoc_3_9;
 make__arg__assoc_3_3:
  if (!isint(a1)) goto make__arg__assoc_3_8;
  gblt_eq(a0,a1,make__arg__assoc_3_6);
  unify_value(a2, NILATOM);
  proceed();
 make__arg__assoc_3_6:
  gblt_less(a0,a1,make__arg__assoc_3_interrupt);
  allocp[0] = makesym(functor_arg_2);
  allocp[1] = makesym(atom_head);
  allocp[2] = a0;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_a_1);
  allocp[4] = a0;
  x1 = makefunctor(&allocp[3]);
  allocp[5] = makesym(functor__3A_2);
  allocp[6] = x1;
  allocp[7] = makesym(atom_any);
  x2 = makefunctor(&allocp[5]);
  allocp[8] = makesym(functor__3D_2);
  allocp[9] = x0;
  allocp[10] = x2;
  x3 = makefunctor(&allocp[8]);
  allocp[11] = x5 = makeref(&allocp[11]);
  allocp[12] = x3;
  x4 = makecons(&allocp[11]);
  allocp += 13;
  unify_value(a2, x4);
  bblt_add_no_check(a0,makeint(1L),x6);
  a0 = x6;
  a2 = x5;
  execute(make__arg__assoc_3_0);
  goto make__arg__assoc_3_ext_interrupt;
 make__arg__assoc_3_8:
  if (!isref(a1)) goto make__arg__assoc_3_interrupt;
  deref_and_jump(a1,make__arg__assoc_3_3);
  *reasonp++ =  a1;
  goto make__arg__assoc_3_interrupt;
 make__arg__assoc_3_9:
  if (!isref(a0)) goto make__arg__assoc_3_interrupt;
  deref_and_jump(a0,make__arg__assoc_3_1);
  *reasonp++ =  a0;
  goto make__arg__assoc_3_interrupt;
 make__arg__assoc_3_ext_interrupt:
  reasonp = 0l;
 make__arg__assoc_3_interrupt:
  goto interrupt_3;
 }

 separate__cond_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 separate__cond_5_clear_reason:
  reasonp = reasons;
 separate__cond_5_0:
 separate__cond_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 separate__cond_5_3:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (isint(x0)) goto separate__cond_5_interrupt;
  switch (symval(x0)) {
 case symval(makesym(atom_otherwise)):
  a0 = cdr_of(a0);
  x1 = a3;
  x2 = a1;
  a3 = a2;
  a2 = x2;
  a1 = x1;
  execute(separate__cond_2F5_241_5_0);
  goto separate__cond_2F5_241_5_ext_interrupt;
 case symval(makesym(atom_alternatively)):
  a0 = cdr_of(a0);
  x1 = a3;
  x2 = a1;
  a3 = a2;
  a2 = x2;
  a1 = x1;
  execute(separate__cond_2F5_240_5_0);
  goto separate__cond_2F5_240_5_ext_interrupt;
 default:
  goto separate__cond_5_interrupt;
  };
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_clause_4)) goto separate__cond_5_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xseparate__cond__1_9);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a1;
  allocp[6] = x3 = makeref(&allocp[6]);
  x4 = arg(x0, 0);
  allocp[7] = x4;
  allocp[8] = x5 = makeref(&allocp[8]);
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = a4;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_klic__comp__normalize_xnorm__guard_10);
  x7 = arg(x0, 2);
  allocp[13] = x7;
  allocp[14] = x8 = makeref(&allocp[14]);
  x9 = arg(x0, 3);
  allocp[15] = x9;
  allocp[16] = x10 = makeref(&allocp[16]);
  allocp[17] = x3;
  allocp[18] = x2;
  allocp[19] = x11 = makeref(&allocp[19]);
  allocp[20] = x5;
  allocp[21] = a3;
  allocp[22] = x6;
  a0 = arg(x0, 1);
  a1 = NILATOM;
  a2 = x8;
  a3 = x10;
  a4 = x11;
  qp = (struct goalrec*)&allocp[11];
  allocp += 23;
  execute(norm__head_5_0);
  goto norm__head_5_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,separate__cond_5_3);
  *reasonp++ =  x0;
  goto separate__cond_5_interrupt;
  };
  goto separate__cond_5_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto separate__cond_5_interrupt;
  unify(a4, a3);
  unify_value(a1, NILATOM);
  unify_value(a2, makesym(atom_normal));
  proceed();
 case VARREF:
  deref_and_jump(a0,separate__cond_5_1);
  *reasonp++ =  a0;
  goto separate__cond_5_interrupt;
  };
  goto separate__cond_5_interrupt;
 separate__cond_5_ext_interrupt:
  reasonp = 0l;
 separate__cond_5_interrupt:
  toppred = &predicate_klic__comp__normalize_xseparate__cond_5;
  goto interrupt_5;
 }

 separate__cond_2F5_241_5_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 separate__cond_2F5_241_5_clear_reason:
  reasonp = reasons;
 separate__cond_2F5_241_5_0:
 separate__cond_2F5_241_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != NILATOM) goto separate__cond_2F5_241_5_5;
  unify_value(a3, makesym(atom_normal));
  unify_value(a2, NILATOM);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__kl1cmp_xwarning_4);
  allocp[2] = makefunctor(&string_const_0);
  allocp[3] = NILATOM;
  allocp[4] = a1;
  allocp[5] = a4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  proceed();
 case VARREF:
  deref_and_jump(a0,separate__cond_2F5_241_5_1);
  *reasonp++ =  a0;
  goto separate__cond_2F5_241_5_interrupt;
  };
  goto separate__cond_2F5_241_5_5;
 separate__cond_2F5_241_5_5:
  gblt_diff(a0,NILATOM,separate__cond_2F5_241_5_interrupt);
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = makesym(atom_otherwise);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  a2 = a3;
  a3 = a1;
  a1 = x1;
  execute(separate__cond_5_0);
  goto separate__cond_5_ext_interrupt;
 separate__cond_2F5_241_5_ext_interrupt:
  reasonp = 0l;
 separate__cond_2F5_241_5_interrupt:
  toppred = &predicate_klic__comp__normalize_xseparate__cond_2F5_241_5;
  goto interrupt_5;
 }

 separate__cond_2F5_240_5_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 separate__cond_2F5_240_5_clear_reason:
  reasonp = reasons;
 separate__cond_2F5_240_5_0:
 separate__cond_2F5_240_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != NILATOM) goto separate__cond_2F5_240_5_5;
  unify_value(a3, makesym(atom_normal));
  unify_value(a2, NILATOM);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__kl1cmp_xwarning_4);
  allocp[2] = makefunctor(&string_const_1);
  allocp[3] = NILATOM;
  allocp[4] = a1;
  allocp[5] = a4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  proceed();
 case VARREF:
  deref_and_jump(a0,separate__cond_2F5_240_5_1);
  *reasonp++ =  a0;
  goto separate__cond_2F5_240_5_interrupt;
  };
  goto separate__cond_2F5_240_5_5;
 separate__cond_2F5_240_5_5:
  gblt_diff(a0,NILATOM,separate__cond_2F5_240_5_interrupt);
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = makesym(atom_alternatively);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x0);
  a2 = a3;
  a3 = a1;
  a1 = x1;
  execute(separate__cond_5_0);
  goto separate__cond_5_ext_interrupt;
 separate__cond_2F5_240_5_ext_interrupt:
  reasonp = 0l;
 separate__cond_2F5_240_5_interrupt:
  toppred = &predicate_klic__comp__normalize_xseparate__cond_2F5_240_5;
  goto interrupt_5;
 }

 separate__cond__1_9_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 separate__cond__1_9_clear_reason:
  reasonp = reasons;
 separate__cond__1_9_0:
 separate__cond__1_9_1:
  switch (ptagof(a6)) {
 case ATOMIC:
  if (isint(a6)) goto separate__cond__1_9_interrupt;
  switch (symval(a6)) {
 case symval(makesym(atom_normal)):
  unify(a3, a4);
  a3 = a7;
  a4 = a8;
  execute(separate__cond_5_0);
  goto separate__cond_5_ext_interrupt;
 case symval(makesym(atom_abnormal)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xseparate__cond_5);
  allocp[2] = a0;
  allocp[3] = a3;
  allocp[4] = a2;
  allocp[5] = x0 = makeref(&allocp[5]);
  allocp[6] = a8;
  allocp[7] = NILATOM;
  allocp[8] = a5;
  x1 = makecons(&allocp[7]);
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_klic__comp__kl1cmp_xwarning_4);
  allocp[11] = makefunctor(&string_const_2);
  allocp[12] = x1;
  allocp[13] = a7;
  allocp[14] = x0;
  qp = (struct goalrec*)&allocp[9];
  allocp += 15;
  proceed();
 default:
  goto separate__cond__1_9_interrupt;
  };
 case VARREF:
  deref_and_jump(a6,separate__cond__1_9_1);
  *reasonp++ =  a6;
  goto separate__cond__1_9_interrupt;
  };
  goto separate__cond__1_9_interrupt;
 separate__cond__1_9_ext_interrupt:
  reasonp = 0l;
 separate__cond__1_9_interrupt:
  goto interrupt_9;
 }

 norm__head_5_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 norm__head_5_clear_reason:
  reasonp = reasons;
 norm__head_5_0:
 norm__head_5_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_functor_1:
  x0 = arg(a0, 0);
 norm__head_5_4:
  if (isref(x0)) goto norm__head_5_8;
  gblt_pfunctor(x0,x1,norm__head_5_interrupt);
  gblt_arity(x0,x2,norm__head_5_interrupt);
  a0 = makeint(0L);
  x3 = a1;
  a5 = a2;
  a6 = a3;
  a7 = a4;
  a4 = x3;
  a3 = makesym(atom_head);
  a2 = x0;
  a1 = x2;
  execute(norm__args_8_0);
  goto norm__args_8_ext_interrupt;
 norm__head_5_8:
  deref_and_jump(x0,norm__head_5_4);
  *reasonp++ =  x0;
  goto norm__head_5_interrupt;
 case functor_atom_1:
  unify2(a4, a3, a2, a1);
  proceed();
 default:
  goto norm__head_5_interrupt;
  };
 case VARREF:
  deref_and_jump(a0,norm__head_5_1);
  *reasonp++ =  a0;
  goto norm__head_5_interrupt;
  };
  goto norm__head_5_interrupt;
 norm__head_5_ext_interrupt:
  reasonp = 0l;
 norm__head_5_interrupt:
  toppred = &predicate_klic__comp__normalize_xnorm__head_5;
  goto interrupt_5;
 }

 norm__args_8_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 norm__args_8_clear_reason:
  reasonp = reasons;
 norm__args_8_0:
 norm__args_8_1:
  if (!isint(a0)) goto norm__args_8_14;
 norm__args_8_3:
  if (!isint(a1)) goto norm__args_8_13;
  gblt_eq(a0,a1,norm__args_8_6);
  unify2(a7, a6, a5, a4);
  proceed();
 norm__args_8_6:
  gblt_less(a0,a1,norm__args_8_interrupt);
  gblt_add(a0,makeint(1L),x0,norm__args_8_interrupt);
 norm__args_8_9:
  if (isref(a2)) goto norm__args_8_12;
  gblt_arg(x0,a2,x1,norm__args_8_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__args_8);
  allocp[2] = x0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x2 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = makesym(functor_arg_2);
  allocp[11] = a3;
  allocp[12] = a0;
  x4 = makefunctor(&allocp[10]);
  a0 = x1;
  a1 = x4;
  a2 = a4;
  a3 = x2;
  a4 = a6;
  a5 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 13;
  execute(norm__guard__term_6_0);
  goto norm__guard__term_6_ext_interrupt;
 norm__args_8_12:
  deref_and_jump(a2,norm__args_8_9);
  *reasonp++ =  a2;
  goto norm__args_8_interrupt;
 norm__args_8_13:
  if (!isref(a1)) goto norm__args_8_interrupt;
  deref_and_jump(a1,norm__args_8_3);
  *reasonp++ =  a1;
  goto norm__args_8_interrupt;
 norm__args_8_14:
  if (!isref(a0)) goto norm__args_8_interrupt;
  deref_and_jump(a0,norm__args_8_1);
  *reasonp++ =  a0;
  goto norm__args_8_interrupt;
 norm__args_8_ext_interrupt:
  reasonp = 0l;
 norm__args_8_interrupt:
  toppred = &predicate_klic__comp__normalize_xnorm__args_8;
  goto interrupt_8;
 }

 norm__guard__term_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 norm__guard__term_6_clear_reason:
  reasonp = reasons;
 norm__guard__term_6_0:
 norm__guard__term_6_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_variable_1:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__guard__term__1_7);
  allocp[2] = x0 = makeref(&allocp[2]);
  x1 = arg(a0, 0);
  allocp[3] = x1;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_klic__comp__util_xassoc_3);
  allocp[11] = a2;
  allocp[12] = x1;
  allocp[13] = x0;
  qp = (struct goalrec*)&allocp[9];
  allocp += 14;
  proceed();
 case functor_integer_1:
  unify(a3, a2);
  allocp[0] = makesym(functor_int_1);
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__3A_2);
  allocp[3] = a1;
  allocp[4] = x0;
  x2 = makefunctor(&allocp[2]);
  allocp[5] = a5;
  allocp[6] = x2;
  x3 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a4, x3);
  proceed();
 case functor_atom_1:
  unify(a3, a2);
  allocp[0] = makesym(functor__3A_2);
  allocp[1] = a1;
  allocp[2] = a0;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = a5;
  allocp[4] = x0;
  x1 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a4, x1);
  proceed();
 case functor_float_1:
  unify(a3, a2);
  allocp[0] = makesym(functor__3A_2);
  allocp[1] = a1;
  allocp[2] = a0;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = a5;
  allocp[4] = x0;
  x1 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a4, x1);
  proceed();
 case functor_predicate_3:
  unify(a3, a2);
  allocp[0] = makesym(functor__3A_2);
  allocp[1] = a1;
  allocp[2] = a0;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = a5;
  allocp[4] = x0;
  x1 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a4, x1);
  proceed();
 case functor_string_1:
  unify(a3, a2);
  allocp[0] = makesym(functor__3A_2);
  allocp[1] = a1;
  allocp[2] = a0;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = a5;
  allocp[4] = x0;
  x1 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a4, x1);
  proceed();
 case functor_list_1:
  x0 = arg(a0, 0);
 norm__guard__term_6_10:
  switch (ptagof(x0)) {
 case CONS:
  allocp[0] = makesym(functor__3A_2);
  allocp[1] = a1;
  allocp[2] = makesym(atom_list);
  x1 = makefunctor(&allocp[0]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x1;
  x2 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a4, x2);
  allocp[0] = makesym(functor_arg_2);
  allocp[1] = a1;
  allocp[2] = makesym(atom_cdr);
  x4 = makefunctor(&allocp[0]);
  allocp[3] = (q)qp;
  allocp[4] = (q)(&predicate_klic__comp__normalize_xnorm__guard__term_6);
  x5 = cdr_of(x0);
  allocp[5] = x5;
  allocp[6] = x4;
  allocp[7] = x6 = makeref(&allocp[7]);
  allocp[8] = a3;
  allocp[9] = x7 = makeref(&allocp[9]);
  allocp[10] = a5;
  allocp[11] = makesym(functor_arg_2);
  allocp[12] = a1;
  allocp[13] = makesym(atom_car);
  x8 = makefunctor(&allocp[11]);
  a0 = car_of(x0);
  a1 = x8;
  a3 = x6;
  a4 = x3;
  a5 = x7;
  qp = (struct goalrec*)&allocp[3];
  allocp += 14;
  execute(norm__guard__term_6_0);
  goto norm__guard__term_6_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,norm__guard__term_6_10);
  *reasonp++ =  x0;
  goto norm__guard__term_6_interrupt;
  };
  goto norm__guard__term_6_interrupt;
 case functor_functor_1:
  x0 = arg(a0, 0);
 norm__guard__term_6_13:
  if (isref(x0)) goto norm__guard__term_6_17;
  gblt_pfunctor(x0,x1,norm__guard__term_6_interrupt);
  gblt_arity(x0,x2,norm__guard__term_6_interrupt);
  allocp[0] = makesym(functor_functor_2);
  allocp[1] = x1;
  allocp[2] = x2;
  x3 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor__3A_2);
  allocp[4] = a1;
  allocp[5] = x3;
  x4 = makefunctor(&allocp[3]);
  allocp[6] = x6 = makeref(&allocp[6]);
  allocp[7] = x4;
  x5 = makecons(&allocp[6]);
  allocp += 8;
  unify_value(a4, x5);
  a0 = makeint(0L);
  x7 = a1;
  a4 = a2;
  x8 = a3;
  a6 = x6;
  a7 = a5;
  a5 = x8;
  a3 = x7;
  a2 = x0;
  a1 = x2;
  execute(norm__args_8_0);
  goto norm__args_8_ext_interrupt;
 norm__guard__term_6_17:
  deref_and_jump(x0,norm__guard__term_6_13);
  *reasonp++ =  x0;
  goto norm__guard__term_6_interrupt;
 default:
  goto norm__guard__term_6_interrupt;
  };
 case VARREF:
  deref_and_jump(a0,norm__guard__term_6_1);
  *reasonp++ =  a0;
  goto norm__guard__term_6_interrupt;
  };
  goto norm__guard__term_6_interrupt;
 norm__guard__term_6_ext_interrupt:
  reasonp = 0l;
 norm__guard__term_6_interrupt:
  toppred = &predicate_klic__comp__normalize_xnorm__guard__term_6;
  goto interrupt_6;
 }

 norm__guard__term__1_7_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 norm__guard__term__1_7_clear_reason:
  reasonp = reasons;
 norm__guard__term__1_7_0:
 norm__guard__term__1_7_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_yes_1)) goto norm__guard__term__1_7_7;
  x0 = arg(a0, 0);
 norm__guard__term__1_7_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_rename_1)) goto norm__guard__term__1_7_7;
  allocp[0] = makesym(functor_variable_1);
  x2 = arg(x0, 0);
  allocp[1] = x2;
  x1 = makefunctor(&allocp[0]);
  a0 = x1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  a5 = a6;
  allocp += 2;
  execute(norm__guard__term_6_0);
  goto norm__guard__term_6_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,norm__guard__term__1_7_4);
  *reasonp++ =  x0;
  goto norm__guard__term__1_7_7;
  };
  goto norm__guard__term__1_7_7;
 case VARREF:
  deref_and_jump(a0,norm__guard__term__1_7_1);
  *reasonp++ =  a0;
  goto norm__guard__term__1_7_7;
  };
  goto norm__guard__term__1_7_7;
 norm__guard__term__1_7_7:
  otherwise(norm__guard__term__1_7_interrupt);
 norm__guard__term__1_7_9:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_no)) goto norm__guard__term__1_7_interrupt;
  unify(a6, a5);
  allocp[0] = makesym(functor__3D_2);
  allocp[1] = a1;
  allocp[2] = a2;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = a3;
  allocp[4] = x0;
  x1 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a4, x1);
  proceed();
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_yes_1)) goto norm__guard__term__1_7_interrupt;
  unify(a4, a3);
  allocp[0] = makesym(functor__3A_2);
  allocp[1] = a2;
  x1 = arg(a0, 0);
  allocp[2] = x1;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = a6;
  allocp[4] = x0;
  x2 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a5, x2);
  proceed();
 case VARREF:
  deref_and_jump(a0,norm__guard__term__1_7_9);
  *reasonp++ =  a0;
  goto norm__guard__term__1_7_interrupt;
  };
  goto norm__guard__term__1_7_interrupt;
 norm__guard__term__1_7_ext_interrupt:
  reasonp = 0l;
 norm__guard__term__1_7_interrupt:
  goto interrupt_7;
 }

 norm__guard_10_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 norm__guard_10_clear_reason:
  reasonp = reasons;
 norm__guard_10_0:
 norm__guard_10_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 norm__guard_10_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_functor_1)) goto norm__guard_10_9;
  x1 = arg(x0, 0);
 norm__guard_10_6:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor__3B_2)) goto norm__guard_10_9;
  unify_value(a6, NILATOM);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__guard_2F10_241_11);
  allocp[2] = x2 = makeref(&allocp[2]);
  x3 = arg(x1, 1);
  allocp[3] = x3;
  x4 = cdr_of(a0);
  allocp[4] = x4;
  allocp[5] = a3;
  allocp[6] = a1;
  allocp[7] = a2;
  allocp[8] = x5 = makeref(&allocp[8]);
  allocp[9] = a5;
  allocp[10] = a7;
  allocp[11] = x6 = makeref(&allocp[11]);
  allocp[12] = a9;
  allocp[13] = (q)(struct goalrec*)&allocp[0];
  allocp[14] = (q)(&predicate_klic__comp__normalize_xnorm__guard_10);
  allocp[15] = x7 = makeref(&allocp[15]);
  allocp[16] = a1;
  allocp[17] = a2;
  allocp[18] = x8 = makeref(&allocp[18]);
  allocp[19] = a4;
  allocp[20] = x5;
  allocp[21] = x9 = makeref(&allocp[21]);
  allocp[22] = x2;
  allocp[23] = a8;
  allocp[24] = x6;
  allocp[25] = (q)(struct goalrec*)&allocp[13];
  allocp[26] = (q)(&predicate_klic__comp__util_xappend_3);
  allocp[27] = a3;
  allocp[28] = x9;
  allocp[29] = x8;
  allocp[30] = (q)(struct goalrec*)&allocp[25];
  allocp[31] = (q)(&predicate_klic__comp__util_xappend_3);
  x10 = arg(x1, 0);
  allocp[32] = x10;
  allocp[33] = x4;
  allocp[34] = x7;
  qp = (struct goalrec*)&allocp[30];
  allocp += 35;
  proceed();
 case VARREF:
  deref_and_jump(x1,norm__guard_10_6);
  *reasonp++ =  x1;
  goto norm__guard_10_9;
  };
  goto norm__guard_10_9;
 case VARREF:
  deref_and_jump(x0,norm__guard_10_3);
  *reasonp++ =  x0;
  goto norm__guard_10_9;
  };
  goto norm__guard_10_9;
 case VARREF:
  deref_and_jump(a0,norm__guard_10_1);
  *reasonp++ =  a0;
  goto norm__guard_10_9;
  };
  goto norm__guard_10_9;
 norm__guard_10_9:
  otherwise(norm__guard_10_interrupt);
 norm__guard_10_11:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 norm__guard_10_13:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_functor_1:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__guard_2F10_240_11);
  allocp[2] = x1 = makeref(&allocp[2]);
  x2 = cdr_of(a0);
  allocp[3] = x2;
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = x4 = makeref(&allocp[9]);
  allocp[10] = a7;
  allocp[11] = x5 = makeref(&allocp[11]);
  allocp[12] = a9;
  a0 = arg(x0, 0);
  a2 = a1;
  a3 = x3;
  a4 = a6;
  a5 = x4;
  a6 = a8;
  a7 = x5;
  a1 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 13;
  execute(norm__guard__goal_8_0);
  goto norm__guard__goal_8_ext_interrupt;
 case functor_atom_1:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__guard_2F10_240_11);
  allocp[2] = x1 = makeref(&allocp[2]);
  x2 = cdr_of(a0);
  allocp[3] = x2;
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = x4 = makeref(&allocp[9]);
  allocp[10] = a7;
  allocp[11] = x5 = makeref(&allocp[11]);
  allocp[12] = a9;
  a0 = arg(x0, 0);
  a2 = a1;
  a3 = x3;
  a4 = a6;
  a5 = x4;
  a6 = a8;
  a7 = x5;
  a1 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 13;
  execute(norm__guard__goal_8_0);
  goto norm__guard__goal_8_ext_interrupt;
 default:
  goto norm__guard_10_interrupt;
  };
 case VARREF:
  deref_and_jump(x0,norm__guard_10_13);
  *reasonp++ =  x0;
  goto norm__guard_10_interrupt;
  };
  goto norm__guard_10_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto norm__guard_10_interrupt;
  allocp[0] = makesym(functor__2D_2);
  allocp[1] = a3;
  allocp[2] = x1 = makeref(&allocp[2]);
  x0 = makefunctor(&allocp[0]);
  allocp[3] = a5;
  allocp[4] = x0;
  x2 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a4, x2);
  unify_value(a6, NILATOM);
  a0 = a2;
  a2 = a1;
  a3 = a7;
  a4 = a8;
  a5 = a9;
  a1 = x1;
  execute(norm__body_6_0);
  goto norm__body_6_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,norm__guard_10_11);
  *reasonp++ =  a0;
  goto norm__guard_10_interrupt;
  };
  goto norm__guard_10_interrupt;
 norm__guard_10_ext_interrupt:
  reasonp = 0l;
 norm__guard_10_interrupt:
  toppred = &predicate_klic__comp__normalize_xnorm__guard_10;
  goto interrupt_10;
 }

 norm__guard_2F10_241_11_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 norm__guard_2F10_241_11_clear_reason:
  reasonp = reasons;
 norm__guard_2F10_241_11_0:
 norm__guard_2F10_241_11_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_normal)) goto norm__guard_2F10_241_11_5;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__guard_10);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a4;
  allocp[4] = a5;
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = a6;
  allocp[7] = a7;
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = a8;
  allocp[10] = a9;
  allocp[11] = a10;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_klic__comp__util_xappend_3);
  allocp[14] = a3;
  allocp[15] = x2;
  allocp[16] = x1;
  allocp[17] = (q)(struct goalrec*)&allocp[12];
  allocp[18] = (q)(&predicate_klic__comp__util_xappend_3);
  allocp[19] = a1;
  allocp[20] = a2;
  allocp[21] = x0;
  qp = (struct goalrec*)&allocp[17];
  allocp += 22;
  proceed();
 case VARREF:
  deref_and_jump(a0,norm__guard_2F10_241_11_1);
  *reasonp++ =  a0;
  goto norm__guard_2F10_241_11_interrupt;
  };
  goto norm__guard_2F10_241_11_5;
 norm__guard_2F10_241_11_5:
  gblt_diff(a0,makesym(atom_normal),norm__guard_2F10_241_11_interrupt);
  unify_value(a8, makesym(atom_abnormal));
  unify(a10, a9);
  proceed();
 norm__guard_2F10_241_11_ext_interrupt:
  reasonp = 0l;
 norm__guard_2F10_241_11_interrupt:
  goto interrupt_11;
 }

 norm__guard_2F10_240_11_top: {
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 norm__guard_2F10_240_11_clear_reason:
  reasonp = reasons;
 norm__guard_2F10_240_11_0:
 norm__guard_2F10_240_11_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_normal)) goto norm__guard_2F10_240_11_5;
  a0 = a1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  a5 = a6;
  a6 = a7;
  a7 = a8;
  a8 = a9;
  a9 = a10;
  execute(norm__guard_10_0);
  goto norm__guard_10_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,norm__guard_2F10_240_11_1);
  *reasonp++ =  a0;
  goto norm__guard_2F10_240_11_interrupt;
  };
  goto norm__guard_2F10_240_11_5;
 norm__guard_2F10_240_11_5:
  gblt_diff(a0,makesym(atom_normal),norm__guard_2F10_240_11_interrupt);
  unify_value(a8, makesym(atom_abnormal));
  unify(a10, a9);
  proceed();
 norm__guard_2F10_240_11_ext_interrupt:
  reasonp = 0l;
 norm__guard_2F10_240_11_interrupt:
  goto interrupt_11;
 }

 norm__guard__goal_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 norm__guard__goal_8_clear_reason:
  reasonp = reasons;
 norm__guard__goal_8_0:
 norm__guard__goal_8_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor__3D_2:
  x0 = arg(a0, 0);
  x1 = arg(a0, 1);
  x2 = a1;
  x3 = a2;
  x4 = a3;
  x5 = a4;
  x6 = a5;
  x7 = a6;
  a8 = a7;
  a7 = x7;
  a6 = x6;
  a5 = x5;
  a4 = x4;
  a3 = x3;
  a2 = x2;
  a1 = x1;
  a0 = x0;
  execute(norm__guard__unify_9_0);
  goto norm__guard__unify_9_ext_interrupt;
 case functor__3A_2:
  x0 = arg(a0, 0);
 norm__guard__goal_8_5:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_atom_1)) goto norm__guard__goal_8_13;
  x1 = arg(x0, 0);
 norm__guard__goal_8_8:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (isint(x1)) goto norm__guard__goal_8_13;
  switch (symval(x1)) {
 case symval(makesym(atom_generic)):
  a0 = arg(a0, 1);
  x2 = a2;
  a2 = a3;
  a3 = a1;
  a1 = x2;
  execute(norm__guard__generic_8_0);
  goto norm__guard__generic_8_ext_interrupt;
 case symval(makesym(atom_inline)):
  a0 = arg(a0, 1);
  x2 = a4;
  a4 = a6;
  x3 = a3;
  a6 = a5;
  a5 = x3;
  a3 = x2;
  execute(norm__guard__goal_2F8_241_8_0);
  goto norm__guard__goal_2F8_241_8_ext_interrupt;
 default:
  goto norm__guard__goal_8_13;
  };
 case VARREF:
  deref_and_jump(x1,norm__guard__goal_8_8);
  *reasonp++ =  x1;
  goto norm__guard__goal_8_13;
  };
  goto norm__guard__goal_8_13;
 case VARREF:
  deref_and_jump(x0,norm__guard__goal_8_5);
  *reasonp++ =  x0;
  goto norm__guard__goal_8_13;
  };
  goto norm__guard__goal_8_13;
 default:
  goto norm__guard__goal_8_13;
  };
 case VARREF:
  deref_and_jump(a0,norm__guard__goal_8_1);
  *reasonp++ =  a0;
  goto norm__guard__goal_8_13;
  };
  goto norm__guard__goal_8_13;
 norm__guard__goal_8_13:
  otherwise(norm__guard__goal_8_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__guard__goal_2F8_240_9);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a2;
  allocp[4] = a1;
  allocp[5] = a4;
  allocp[6] = a6;
  allocp[7] = a3;
  allocp[8] = a5;
  allocp[9] = a7;
  allocp[10] = a0;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_klic__comp__gb_xis__guard__builtin_2);
  allocp[13] = a0;
  allocp[14] = x0;
  qp = (struct goalrec*)&allocp[11];
  allocp += 15;
  proceed();
 norm__guard__goal_8_ext_interrupt:
  reasonp = 0l;
 norm__guard__goal_8_interrupt:
  toppred = &predicate_klic__comp__normalize_xnorm__guard__goal_8;
  goto interrupt_8;
 }

 norm__guard__goal_2F8_241_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 norm__guard__goal_2F8_241_8_clear_reason:
  reasonp = reasons;
 norm__guard__goal_2F8_241_8_0:
 norm__guard__goal_2F8_241_8_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_functor_1)) goto norm__guard__goal_2F8_241_8_7;
  x0 = arg(a0, 0);
 norm__guard__goal_2F8_241_8_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__3A_2)) goto norm__guard__goal_2F8_241_8_7;
  a0 = arg(x0, 1);
  allocp[0] = x2 = makeref(&allocp[0]);
  x1 = x2;
  x3 = x2;
  x4 = arg(x0, 0);
  x5 = a1;
  x6 = a2;
  x7 = a5;
  a8 = a3;
  a9 = a6;
  a10 = a4;
  a11 = a7;
  a7 = x7;
  a6 = x6;
  a5 = x5;
  a4 = x4;
  a3 = NILATOM;
  a2 = x3;
  a1 = x1;
  allocp += 1;
  execute(norm__inline_12_0);
  goto norm__inline_12_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,norm__guard__goal_2F8_241_8_4);
  *reasonp++ =  x0;
  goto norm__guard__goal_2F8_241_8_7;
  };
  goto norm__guard__goal_2F8_241_8_7;
 case VARREF:
  deref_and_jump(a0,norm__guard__goal_2F8_241_8_1);
  *reasonp++ =  a0;
  goto norm__guard__goal_2F8_241_8_7;
  };
  goto norm__guard__goal_2F8_241_8_7;
 norm__guard__goal_2F8_241_8_7:
  otherwise(norm__guard__goal_2F8_241_8_interrupt);
  allocp[0] = x1 = makeref(&allocp[0]);
  x0 = x1;
  x2 = x1;
  x3 = a0;
  x4 = a1;
  x5 = a2;
  x6 = a5;
  a8 = a3;
  a9 = a6;
  a10 = a4;
  a11 = a7;
  a7 = x6;
  a6 = x5;
  a5 = x4;
  a4 = x3;
  a3 = NILATOM;
  a2 = x2;
  a1 = x0;
  a0 = makefunctor(funct_const_3);
  allocp += 1;
  execute(norm__inline_12_0);
  goto norm__inline_12_ext_interrupt;
 norm__guard__goal_2F8_241_8_ext_interrupt:
  reasonp = 0l;
 norm__guard__goal_2F8_241_8_interrupt:
  toppred = &predicate_klic__comp__normalize_xnorm__guard__goal_2F8_241_8;
  goto interrupt_8;
 }

 norm__guard__goal_2F8_240_9_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 norm__guard__goal_2F8_240_9_clear_reason:
  reasonp = reasons;
 norm__guard__goal_2F8_240_9_0:
 norm__guard__goal_2F8_240_9_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_no)) goto norm__guard__goal_2F8_240_9_interrupt;
  unify2(a6, a3, a5, a1);
  allocp[0] = NILATOM;
  allocp[1] = a8;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__kl1cmp_xreport__error_4);
  allocp[4] = makefunctor(&string_const_4);
  allocp[5] = x0;
  allocp[6] = a4;
  allocp[7] = a7;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_yes_1)) goto norm__guard__goal_2F8_240_9_interrupt;
  a0 = arg(a0, 0);
  x0 = a5;
  x1 = a2;
  x2 = a3;
  a5 = a6;
  a6 = a4;
  a4 = x2;
  a3 = x1;
  a2 = x0;
  execute(norm__guard__builts_8_0);
  goto norm__guard__builts_8_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,norm__guard__goal_2F8_240_9_1);
  *reasonp++ =  a0;
  goto norm__guard__goal_2F8_240_9_interrupt;
  };
  goto norm__guard__goal_2F8_240_9_interrupt;
 norm__guard__goal_2F8_240_9_ext_interrupt:
  reasonp = 0l;
 norm__guard__goal_2F8_240_9_interrupt:
  goto interrupt_9;
 }

 norm__inline_12_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 norm__inline_12_clear_reason:
  reasonp = reasons;
 norm__inline_12_0:
 norm__inline_12_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_atom_1:
  x0 = arg(a0, 0);
 norm__inline_12_4:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != NILATOM) goto norm__inline_12_interrupt;
  unify2(a11, a10, a7, a6);
  unify_value(a1, NILATOM);
  allocp[0] = makesym(functor_il_3);
  allocp[1] = a4;
  allocp[2] = a2;
  allocp[3] = a3;
  x1 = makefunctor(&allocp[0]);
  allocp[4] = a9;
  allocp[5] = x1;
  x2 = makecons(&allocp[4]);
  allocp += 6;
  unify_value(a8, x2);
  unify_value(a5, makesym(atom_normal));
  proceed();
 case VARREF:
  deref_and_jump(x0,norm__inline_12_4);
  *reasonp++ =  x0;
  goto norm__inline_12_interrupt;
  };
  goto norm__inline_12_interrupt;
 case functor_list_1:
  x0 = arg(a0, 0);
 norm__inline_12_9:
  switch (ptagof(x0)) {
 case CONS:
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = x3 = makeref(&allocp[1]);
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__inline_2F12_240_13);
  allocp[2] = x4 = makeref(&allocp[2]);
  x5 = cdr_of(x0);
  allocp[3] = x5;
  allocp[4] = x2;
  allocp[5] = a2;
  allocp[6] = x6 = makeref(&allocp[6]);
  allocp[7] = a4;
  allocp[8] = a5;
  allocp[9] = x7 = makeref(&allocp[9]);
  allocp[10] = x8 = makeref(&allocp[10]);
  allocp[11] = x9 = makeref(&allocp[11]);
  allocp[12] = a7;
  allocp[13] = a9;
  allocp[14] = a11;
  a0 = car_of(x0);
  a1 = x3;
  a2 = x4;
  a4 = x6;
  a5 = a6;
  a6 = x7;
  a7 = a8;
  a8 = x8;
  a9 = a10;
  a10 = x9;
  qp = (struct goalrec*)&allocp[0];
  allocp += 15;
  execute(norm__inline__arg_11_0);
  goto norm__inline__arg_11_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,norm__inline_12_9);
  *reasonp++ =  x0;
  goto norm__inline_12_interrupt;
  };
  goto norm__inline_12_interrupt;
 default:
  goto norm__inline_12_interrupt;
  };
 case VARREF:
  deref_and_jump(a0,norm__inline_12_1);
  *reasonp++ =  a0;
  goto norm__inline_12_interrupt;
  };
  goto norm__inline_12_interrupt;
 norm__inline_12_ext_interrupt:
  reasonp = 0l;
 norm__inline_12_interrupt:
  toppred = &predicate_klic__comp__normalize_xnorm__inline_12;
  goto interrupt_12;
 }

 norm__inline_2F12_240_13_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  qp = qp->next;
 norm__inline_2F12_240_13_clear_reason:
  reasonp = reasons;
 norm__inline_2F12_240_13_0:
 norm__inline_2F12_240_13_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_normal)) goto norm__inline_2F12_240_13_5;
  a0 = a1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  a5 = a6;
  a6 = a7;
  a7 = a10;
  x0 = a11;
  a10 = a9;
  a11 = a12;
  a9 = x0;
  execute(norm__inline_12_0);
  goto norm__inline_12_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,norm__inline_2F12_240_13_1);
  *reasonp++ =  a0;
  goto norm__inline_2F12_240_13_interrupt;
  };
  goto norm__inline_2F12_240_13_5;
 norm__inline_2F12_240_13_5:
  gblt_diff(a0,makesym(atom_normal),norm__inline_2F12_240_13_interrupt);
  unify_value(a6, makesym(atom_abnormal));
  unify3(a10, a7, a11, a8, a12, a9);
  proceed();
 norm__inline_2F12_240_13_ext_interrupt:
  reasonp = 0l;
 norm__inline_2F12_240_13_interrupt:
  goto interrupt_13;
 }

 norm__inline__arg_11_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 norm__inline__arg_11_clear_reason:
  reasonp = reasons;
 norm__inline__arg_11_0:
 norm__inline__arg_11_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_functor_1)) goto norm__inline__arg_11_interrupt;
  x0 = arg(a0, 0);
 norm__inline__arg_11_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor__2B_2:
  x1 = arg(x0, 0);
 norm__inline__arg_11_7:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_variable_1)) goto norm__inline__arg_11_interrupt;
  allocp[0] = makesym(functor__2B_1);
  allocp[1] = x3 = makeref(&allocp[1]);
  x2 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x2);
  unify2(a4, a3, a6, a5);
  allocp[0] = makesym(functor_variable_1);
  x5 = arg(x1, 0);
  allocp[1] = x5;
  x4 = makefunctor(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__normalize_xnorm__gblt__arg_9);
  allocp[4] = x4;
  allocp[5] = x6 = makeref(&allocp[5]);
  allocp[6] = x3;
  allocp[7] = a6;
  allocp[8] = a2;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = a9;
  allocp[12] = a10;
  a0 = arg(x0, 1);
  a1 = x6;
  qp = (struct goalrec*)&allocp[2];
  allocp += 13;
  execute(inline__arg__type_2_0);
  goto inline__arg__type_2_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,norm__inline__arg_11_7);
  *reasonp++ =  x1;
  goto norm__inline__arg_11_interrupt;
  };
  goto norm__inline__arg_11_interrupt;
 case functor__2D_2:
  x1 = arg(x0, 0);
 norm__inline__arg_11_11:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_variable_1)) goto norm__inline__arg_11_interrupt;
  allocp[0] = makesym(functor_var_1);
  x3 = arg(x1, 0);
  allocp[1] = x3;
  x2 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__2D_1);
  allocp[3] = x2;
  x4 = makefunctor(&allocp[2]);
  allocp += 4;
  unify_value(a1, x4);
  allocp[0] = makesym(functor__3A_2);
  allocp[1] = x3;
  allocp[2] = x6 = makeref(&allocp[2]);
  x5 = makefunctor(&allocp[0]);
  allocp[3] = a3;
  allocp[4] = x5;
  x7 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a4, x7);
  allocp[0] = makesym(functor_var_1);
  allocp[1] = x3;
  x8 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__3D_2);
  allocp[3] = x3;
  allocp[4] = x8;
  x9 = makefunctor(&allocp[2]);
  allocp[5] = a5;
  allocp[6] = x9;
  x10 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a6, x10);
  unify(a8, a7);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__inline__arg__1_7);
  allocp[2] = x11 = makeref(&allocp[2]);
  allocp[3] = a5;
  allocp[4] = x3;
  allocp[5] = x6;
  allocp[6] = a2;
  allocp[7] = a9;
  allocp[8] = a10;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_klic__comp__normalize_xinline__arg__type_2);
  x12 = arg(x0, 1);
  allocp[11] = x12;
  allocp[12] = x6;
  allocp[13] = (q)(struct goalrec*)&allocp[9];
  allocp[14] = (q)(&predicate_klic__comp__util_xassoc_4);
  allocp[15] = a5;
  allocp[16] = x3;
  allocp[17] = x13 = makeref(&allocp[17]);
  allocp[18] = x11;
  qp = (struct goalrec*)&allocp[13];
  allocp += 19;
  proceed();
 case VARREF:
  deref_and_jump(x1,norm__inline__arg_11_11);
  *reasonp++ =  x1;
  goto norm__inline__arg_11_interrupt;
  };
  goto norm__inline__arg_11_interrupt;
 default:
  goto norm__inline__arg_11_interrupt;
  };
 case VARREF:
  deref_and_jump(x0,norm__inline__arg_11_4);
  *reasonp++ =  x0;
  goto norm__inline__arg_11_interrupt;
  };
  goto norm__inline__arg_11_interrupt;
 case VARREF:
  deref_and_jump(a0,norm__inline__arg_11_1);
  *reasonp++ =  a0;
  goto norm__inline__arg_11_interrupt;
  };
  goto norm__inline__arg_11_interrupt;
 norm__inline__arg_11_ext_interrupt:
  reasonp = 0l;
 norm__inline__arg_11_interrupt:
  toppred = &predicate_klic__comp__normalize_xnorm__inline__arg_11;
  goto interrupt_11;
 }

 norm__inline__arg_10_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 norm__inline__arg_10_clear_reason:
  reasonp = reasons;
 norm__inline__arg_10_0:
  unify2(a7, a6, a4, a3);
  unify_value(a2, makesym(atom_abnormal));
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__kl1cmp_xwarning_4);
  allocp[4] = makefunctor(&string_const_5);
  allocp[5] = x0;
  allocp[6] = a8;
  allocp[7] = a9;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 norm__inline__arg_10_ext_interrupt:
  reasonp = 0l;
 norm__inline__arg_10_interrupt:
  goto interrupt_10;
 }

 norm__inline__arg__1_7_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 norm__inline__arg__1_7_clear_reason:
  reasonp = reasons;
 norm__inline__arg__1_7_0:
 norm__inline__arg__1_7_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto norm__inline__arg__1_7_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  allocp[0] = makesym(functor_variable_1);
  allocp[1] = a2;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__2D_2);
  allocp[3] = x0;
  allocp[4] = a3;
  x1 = makefunctor(&allocp[2]);
  allocp += 5;
  unify_value(a4, makesym(atom_abnormal));
  allocp[0] = NILATOM;
  allocp[1] = x1;
  x2 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__kl1cmp_xwarning_4);
  allocp[4] = makefunctor(&string_const_6);
  allocp[5] = x2;
  allocp[6] = a5;
  allocp[7] = a6;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 case symval(makesym(atom_no)):
  unify(a6, a5);
  unify_value(a4, makesym(atom_normal));
  proceed();
 default:
  goto norm__inline__arg__1_7_interrupt;
  };
 case VARREF:
  deref_and_jump(a0,norm__inline__arg__1_7_1);
  *reasonp++ =  a0;
  goto norm__inline__arg__1_7_interrupt;
  };
  goto norm__inline__arg__1_7_interrupt;
 norm__inline__arg__1_7_ext_interrupt:
  reasonp = 0l;
 norm__inline__arg__1_7_interrupt:
  goto interrupt_7;
 }

 inline__arg__type_2_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  qp = qp->next;
 inline__arg__type_2_clear_reason:
  reasonp = reasons;
 inline__arg__type_2_0:
 inline__arg__type_2_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_atom_1:
  x0 = arg(a0, 0);
  unify(a1, x0);
  proceed();
 case functor_functor_1:
  x0 = arg(a0, 0);
 inline__arg__type_2_5:
  if (isref(x0)) goto inline__arg__type_2_15;
  gblt_pfunctor(x0,x1,inline__arg__type_2_interrupt);
  gblt_arity(x0,x2,inline__arg__type_2_interrupt);
 inline__arg__type_2_9:
  switch ((unsigned long)x2) {
 case (unsigned long) makeint(1L):
  gblt_arg(makeint(1L),x0,x3,inline__arg__type_2_interrupt);
  allocp[0] = NILATOM;
  allocp[1] = x5 = makeref(&allocp[1]);
  x4 = makecons(&allocp[0]);
  allocp[2] = x4;
  allocp[3] = x1;
  x6 = makecons(&allocp[2]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[6] = a1;
  allocp[7] = x6;
  a0 = x3;
  a1 = x5;
  qp = (struct goalrec*)&allocp[4];
  allocp += 8;
  execute(inline__arg__type_2_0);
  goto inline__arg__type_2_ext_interrupt;
 case (unsigned long) makeint(2L):
  gblt_arg(makeint(1L),x0,x3,inline__arg__type_2_interrupt);
  gblt_arg(makeint(1L),x0,x4,inline__arg__type_2_interrupt);
  allocp[0] = NILATOM;
  allocp[1] = x6 = makeref(&allocp[1]);
  x5 = makecons(&allocp[0]);
  allocp[2] = x5;
  allocp[3] = x8 = makeref(&allocp[3]);
  x7 = makecons(&allocp[2]);
  allocp[4] = x7;
  allocp[5] = x1;
  x9 = makecons(&allocp[4]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[8] = a1;
  allocp[9] = x9;
  allocp[10] = (q)(struct goalrec*)&allocp[6];
  allocp[11] = (q)(&predicate_klic__comp__normalize_xinline__arg__type_2);
  allocp[12] = x4;
  allocp[13] = x6;
  a0 = x4;
  a1 = x8;
  qp = (struct goalrec*)&allocp[10];
  allocp += 14;
  execute(inline__arg__type_2_0);
  goto inline__arg__type_2_ext_interrupt;
 default:
  goto inline__arg__type_2_interrupt;
  };
 inline__arg__type_2_15:
  deref_and_jump(x0,inline__arg__type_2_5);
  *reasonp++ =  x0;
  goto inline__arg__type_2_interrupt;
 default:
  goto inline__arg__type_2_interrupt;
  };
 case VARREF:
  deref_and_jump(a0,inline__arg__type_2_1);
  *reasonp++ =  a0;
  goto inline__arg__type_2_interrupt;
  };
  goto inline__arg__type_2_interrupt;
 inline__arg__type_2_ext_interrupt:
  reasonp = 0l;
 inline__arg__type_2_interrupt:
  toppred = &predicate_klic__comp__normalize_xinline__arg__type_2;
  goto interrupt_2;
 }

 norm__guard__unify_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 norm__guard__unify_9_clear_reason:
  reasonp = reasons;
 norm__guard__unify_9_0:
 norm__guard__unify_9_1:
  if (isref(a0)) goto norm__guard__unify_9_7;
 norm__guard__unify_9_3:
  if (isref(a0)) goto norm__guard__unify_9_6;
  if_not_equal(a0, a1, norm__guard__unify_9_8);
  unify3(a8, a7, a6, a5, a4, a3);
  unify_value(a2, makesym(atom_normal));
  proceed();
 norm__guard__unify_9_6:
  deref_and_jump(a0,norm__guard__unify_9_3);
  *reasonp++ =  a0;
  goto norm__guard__unify_9_8;
 norm__guard__unify_9_7:
  deref_and_jump(a0,norm__guard__unify_9_1);
  *reasonp++ =  a0;
  goto norm__guard__unify_9_8;
 norm__guard__unify_9_8:
  otherwise(norm__guard__unify_9_interrupt);
 norm__guard__unify_9_10:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_variable_1:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__guard__unify_2F9_241_10);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a5;
  allocp[7] = a7;
  allocp[8] = a4;
  allocp[9] = a6;
  allocp[10] = a8;
  x1 = arg(a0, 0);
  allocp[11] = x1;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_klic__comp__util_xassoc_3);
  allocp[14] = a3;
  allocp[15] = x1;
  allocp[16] = x0;
  qp = (struct goalrec*)&allocp[12];
  allocp += 17;
  proceed();
 case functor_list_1:
  x0 = arg(a0, 0);
 norm__guard__unify_9_14:
  switch (ptagof(x0)) {
 case CONS:
 norm__guard__unify_9_16:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_list_1)) goto norm__guard__unify_9_70;
  x1 = arg(a1, 0);
 norm__guard__unify_9_19:
  switch (ptagof(x1)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__guard__unify_2F9_240_10);
  allocp[2] = x2 = makeref(&allocp[2]);
  x3 = cdr_of(x0);
  allocp[3] = x3;
  x4 = cdr_of(x1);
  allocp[4] = x4;
  allocp[5] = a2;
  allocp[6] = x5 = makeref(&allocp[6]);
  allocp[7] = x6 = makeref(&allocp[7]);
  allocp[8] = x7 = makeref(&allocp[8]);
  allocp[9] = a4;
  allocp[10] = a6;
  allocp[11] = a8;
  a0 = car_of(x0);
  a1 = car_of(x1);
  a2 = x2;
  a4 = x5;
  a6 = x6;
  a8 = x7;
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  execute(norm__guard__unify_9_0);
  goto norm__guard__unify_9_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,norm__guard__unify_9_19);
  *reasonp++ =  x1;
  goto norm__guard__unify_9_70;
  };
  goto norm__guard__unify_9_70;
 case VARREF:
  deref_and_jump(a1,norm__guard__unify_9_16);
  *reasonp++ =  a1;
  goto norm__guard__unify_9_70;
  };
  goto norm__guard__unify_9_70;
 case VARREF:
  deref_and_jump(x0,norm__guard__unify_9_14);
  *reasonp++ =  x0;
  goto norm__guard__unify_9_70;
  };
  goto norm__guard__unify_9_70;
 case functor_functor_1:
 norm__guard__unify_9_22:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_functor_1)) goto norm__guard__unify_9_70;
  x0 = arg(a0, 0);
 norm__guard__unify_9_25:
  if (isref(x0)) goto norm__guard__unify_9_48;
  gblt_pfunctor(x0,x1,norm__guard__unify_9_70);
  gblt_arity(x0,x2,norm__guard__unify_9_70);
  x3 = arg(a1, 0);
 norm__guard__unify_9_29:
  if (isref(x3)) goto norm__guard__unify_9_47;
  gblt_pfunctor(x3,x4,norm__guard__unify_9_70);
 norm__guard__unify_9_32:
  if (isref(x4)) goto norm__guard__unify_9_46;
 norm__guard__unify_9_34:
  if (isref(x4)) goto norm__guard__unify_9_45;
  if_not_equal(x4, x1, norm__guard__unify_9_70);
  gblt_arity(x3,x5,norm__guard__unify_9_70);
 norm__guard__unify_9_38:
  if (isref(x5)) goto norm__guard__unify_9_44;
 norm__guard__unify_9_40:
  if (isref(x5)) goto norm__guard__unify_9_43;
  if_not_equal(x5, x2, norm__guard__unify_9_70);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__guard__unify__args_10);
  allocp[2] = x6 = makeref(&allocp[2]);
  allocp[3] = x7 = makeref(&allocp[3]);
  allocp[4] = a3;
  allocp[5] = a4;
  allocp[6] = makesym(atom_normal);
  allocp[7] = a2;
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = a8;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_klic__comp__util_xuniv_2);
  allocp[14] = x3;
  allocp[15] = x7;
  allocp[16] = (q)(struct goalrec*)&allocp[12];
  allocp[17] = (q)(&predicate_klic__comp__util_xuniv_2);
  allocp[18] = x0;
  allocp[19] = x6;
  qp = (struct goalrec*)&allocp[16];
  allocp += 20;
  proceed();
 norm__guard__unify_9_43:
  deref_and_jump(x5,norm__guard__unify_9_40);
  *reasonp++ =  x5;
  goto norm__guard__unify_9_70;
 norm__guard__unify_9_44:
  deref_and_jump(x5,norm__guard__unify_9_38);
  *reasonp++ =  x5;
  goto norm__guard__unify_9_70;
 norm__guard__unify_9_45:
  deref_and_jump(x4,norm__guard__unify_9_34);
  *reasonp++ =  x4;
  goto norm__guard__unify_9_70;
 norm__guard__unify_9_46:
  deref_and_jump(x4,norm__guard__unify_9_32);
  *reasonp++ =  x4;
  goto norm__guard__unify_9_70;
 norm__guard__unify_9_47:
  deref_and_jump(x3,norm__guard__unify_9_29);
  *reasonp++ =  x3;
  goto norm__guard__unify_9_70;
 norm__guard__unify_9_48:
  deref_and_jump(x0,norm__guard__unify_9_25);
  *reasonp++ =  x0;
  goto norm__guard__unify_9_70;
 case VARREF:
  deref_and_jump(a1,norm__guard__unify_9_22);
  *reasonp++ =  a1;
  goto norm__guard__unify_9_70;
  };
  goto norm__guard__unify_9_70;
 case functor_vector_1:
 norm__guard__unify_9_50:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_vector_1)) goto norm__guard__unify_9_70;
  x0 = arg(a0, 0);
 norm__guard__unify_9_53:
  switch (ptagof(x0)) {
 case FUNCTOR:
 norm__guard__unify_9_54:
  if (!isgobj(x0)) goto norm__guard__unify_9_70;
  if (!isclass(x0,vector)) goto norm__guard__unify_9_70;
  gblt_size_of_vector(x0,x1,norm__guard__unify_9_70);
  x2 = arg(a1, 0);
 norm__guard__unify_9_58:
  switch (ptagof(x2)) {
 case FUNCTOR:
 norm__guard__unify_9_59:
  if (!isgobj(x2)) goto norm__guard__unify_9_70;
  if (!isclass(x2,vector)) goto norm__guard__unify_9_70;
  gblt_size_of_vector(x2,x3,norm__guard__unify_9_70);
 norm__guard__unify_9_63:
  if (isref(x3)) goto norm__guard__unify_9_69;
 norm__guard__unify_9_65:
  if (isref(x3)) goto norm__guard__unify_9_68;
  if_not_equal(x3, x1, norm__guard__unify_9_70);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__guard__unify__args_10);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = a3;
  allocp[5] = a4;
  allocp[6] = makesym(atom_normal);
  allocp[7] = a2;
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = a8;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_klic__comp__util_xvector__to__list_2);
  allocp[14] = x2;
  allocp[15] = x5;
  allocp[16] = (q)(struct goalrec*)&allocp[12];
  allocp[17] = (q)(&predicate_klic__comp__util_xvector__to__list_2);
  allocp[18] = x0;
  allocp[19] = x4;
  qp = (struct goalrec*)&allocp[16];
  allocp += 20;
  proceed();
 norm__guard__unify_9_68:
  deref_and_jump(x3,norm__guard__unify_9_65);
  *reasonp++ =  x3;
  goto norm__guard__unify_9_70;
 norm__guard__unify_9_69:
  deref_and_jump(x3,norm__guard__unify_9_63);
  *reasonp++ =  x3;
  goto norm__guard__unify_9_70;
 case VARREF:
  deref_and_jump(x2,norm__guard__unify_9_58);
  *reasonp++ =  x2;
  goto norm__guard__unify_9_70;
  };
  goto norm__guard__unify_9_70;
 case VARREF:
  deref_and_jump(x0,norm__guard__unify_9_53);
  *reasonp++ =  x0;
  goto norm__guard__unify_9_70;
  };
  goto norm__guard__unify_9_70;
 case VARREF:
  deref_and_jump(a1,norm__guard__unify_9_50);
  *reasonp++ =  a1;
  goto norm__guard__unify_9_70;
  };
  goto norm__guard__unify_9_70;
 default:
  goto norm__guard__unify_9_70;
  };
 case VARREF:
  deref_and_jump(a0,norm__guard__unify_9_10);
  *reasonp++ =  a0;
  goto norm__guard__unify_9_70;
  };
  goto norm__guard__unify_9_70;
 norm__guard__unify_9_70:
  otherwise(norm__guard__unify_9_interrupt);
 norm__guard__unify_9_72:
  switch (ptagof(a1)) {
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_variable_1)) goto norm__guard__unify_9_75;
  allocp[0] = makesym(functor_variable_1);
  x1 = arg(a1, 0);
  allocp[1] = x1;
  x0 = makefunctor(&allocp[0]);
  a1 = a0;
  a0 = x0;
  allocp += 2;
  execute(norm__guard__unify_9_0);
  goto norm__guard__unify_9_ext_interrupt;
 case VARREF:
  deref_and_jump(a1,norm__guard__unify_9_72);
  *reasonp++ =  a1;
  goto norm__guard__unify_9_75;
  };
  goto norm__guard__unify_9_75;
 norm__guard__unify_9_75:
  otherwise(norm__guard__unify_9_interrupt);
  unify2(a6, a5, a4, a3);
  unify_value(a2, makesym(atom_abnormal));
  allocp[0] = NILATOM;
  allocp[1] = a1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a0;
  x1 = makecons(&allocp[2]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_klic__comp__kl1cmp_xwarning_4);
  allocp[6] = makefunctor(&string_const_7);
  allocp[7] = x1;
  allocp[8] = a7;
  allocp[9] = a8;
  qp = (struct goalrec*)&allocp[4];
  allocp += 10;
  proceed();
 norm__guard__unify_9_ext_interrupt:
  reasonp = 0l;
 norm__guard__unify_9_interrupt:
  toppred = &predicate_klic__comp__normalize_xnorm__guard__unify_9;
  goto interrupt_9;
 }

 norm__guard__unify_2F9_241_10_top: {
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 norm__guard__unify_2F9_241_10_clear_reason:
  reasonp = reasons;
 norm__guard__unify_2F9_241_10_0:
 norm__guard__unify_2F9_241_10_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_no)) goto norm__guard__unify_2F9_241_10_interrupt;
  unify_value(a2, makesym(atom_normal));
  unify(a7, a4);
  a0 = a1;
  a1 = a9;
  a2 = a3;
  a3 = a6;
  a4 = a5;
  a5 = a8;
  execute(norm__guard__unify__new_6_0);
  goto norm__guard__unify__new_6_ext_interrupt;
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_yes_1)) goto norm__guard__unify_2F9_241_10_interrupt;
  a0 = arg(a0, 0);
  execute(norm__guard__unify_2F9_241_2F10_240_9_0);
  goto norm__guard__unify_2F9_241_2F10_240_9_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,norm__guard__unify_2F9_241_10_1);
  *reasonp++ =  a0;
  goto norm__guard__unify_2F9_241_10_interrupt;
  };
  goto norm__guard__unify_2F9_241_10_interrupt;
 norm__guard__unify_2F9_241_10_ext_interrupt:
  reasonp = 0l;
 norm__guard__unify_2F9_241_10_interrupt:
  goto interrupt_10;
 }

 norm__guard__unify_2F9_241_2F10_240_9_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 norm__guard__unify_2F9_241_2F10_240_9_clear_reason:
  reasonp = reasons;
 norm__guard__unify_2F9_241_2F10_240_9_0:
 norm__guard__unify_2F9_241_2F10_240_9_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_rename_1)) goto norm__guard__unify_2F9_241_2F10_240_9_4;
  allocp[0] = makesym(functor_variable_1);
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makefunctor(&allocp[0]);
  a0 = x0;
  x2 = a6;
  x3 = a4;
  a6 = a7;
  a7 = a5;
  a5 = x3;
  a4 = x2;
  allocp += 2;
  execute(norm__guard__unify_9_0);
  goto norm__guard__unify_9_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,norm__guard__unify_2F9_241_2F10_240_9_1);
  *reasonp++ =  a0;
  goto norm__guard__unify_2F9_241_2F10_240_9_4;
  };
  goto norm__guard__unify_2F9_241_2F10_240_9_4;
 norm__guard__unify_2F9_241_2F10_240_9_4:
  otherwise(norm__guard__unify_2F9_241_2F10_240_9_interrupt);
  unify_value(a2, makesym(atom_normal));
  unify(a8, a5);
  x0 = a1;
  a1 = a0;
  a2 = a3;
  a3 = a6;
  a5 = a7;
  a0 = x0;
  execute(norm__guard__term_6_0);
  goto norm__guard__term_6_ext_interrupt;
 norm__guard__unify_2F9_241_2F10_240_9_ext_interrupt:
  reasonp = 0l;
 norm__guard__unify_2F9_241_2F10_240_9_interrupt:
  toppred = &predicate_klic__comp__normalize_xnorm__guard__unify_2F9_241_2F10_240_9;
  goto interrupt_9;
 }

 norm__guard__unify_2F9_240_10_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 norm__guard__unify_2F9_240_10_clear_reason:
  reasonp = reasons;
 norm__guard__unify_2F9_240_10_0:
 norm__guard__unify_2F9_240_10_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_normal)) goto norm__guard__unify_2F9_240_10_5;
  a0 = a1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  a4 = a7;
  x0 = a8;
  a7 = a6;
  a8 = a9;
  a6 = x0;
  execute(norm__guard__unify_9_0);
  goto norm__guard__unify_9_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,norm__guard__unify_2F9_240_10_1);
  *reasonp++ =  a0;
  goto norm__guard__unify_2F9_240_10_interrupt;
  };
  goto norm__guard__unify_2F9_240_10_5;
 norm__guard__unify_2F9_240_10_5:
  gblt_diff(a0,makesym(atom_normal),norm__guard__unify_2F9_240_10_interrupt);
  unify_value(a3, makesym(atom_abnormal));
  unify3(a7, a4, a8, a5, a9, a6);
  proceed();
 norm__guard__unify_2F9_240_10_ext_interrupt:
  reasonp = 0l;
 norm__guard__unify_2F9_240_10_interrupt:
  goto interrupt_10;
 }

 norm__guard__unify__new_6_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 norm__guard__unify__new_6_clear_reason:
  reasonp = reasons;
 norm__guard__unify__new_6_0:
 norm__guard__unify__new_6_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_variable_1:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__guard__unify__new_2F6_240_7);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a3;
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a5;
  allocp[7] = a4;
  x1 = arg(a0, 0);
  allocp[8] = x1;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_klic__comp__util_xassoc_3);
  allocp[11] = a2;
  allocp[12] = x1;
  allocp[13] = x0;
  qp = (struct goalrec*)&allocp[9];
  allocp += 14;
  proceed();
 case functor_atom_1:
  unify(a5, a4);
  allocp[0] = makesym(functor__3D_2);
  allocp[1] = a1;
  allocp[2] = a0;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = a2;
  allocp[4] = x0;
  x1 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a3, x1);
  proceed();
 case functor_float_1:
  unify(a5, a4);
  allocp[0] = makesym(functor__3D_2);
  allocp[1] = a1;
  allocp[2] = a0;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = a2;
  allocp[4] = x0;
  x1 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a3, x1);
  proceed();
 case functor_predicate_3:
  unify(a5, a4);
  allocp[0] = makesym(functor__3D_2);
  allocp[1] = a1;
  allocp[2] = a0;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = a2;
  allocp[4] = x0;
  x1 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a3, x1);
  proceed();
 case functor_integer_1:
  unify(a5, a4);
  allocp[0] = makesym(functor_int_1);
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__3D_2);
  allocp[3] = a1;
  allocp[4] = x0;
  x2 = makefunctor(&allocp[2]);
  allocp[5] = a2;
  allocp[6] = x2;
  x3 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a3, x3);
  proceed();
 default:
  goto norm__guard__unify__new_6_8;
  };
 case VARREF:
  deref_and_jump(a0,norm__guard__unify__new_6_1);
  *reasonp++ =  a0;
  goto norm__guard__unify__new_6_8;
  };
  goto norm__guard__unify__new_6_8;
 norm__guard__unify__new_6_8:
  otherwise(norm__guard__unify__new_6_interrupt);
  unify(a3, a2);
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__kl1cmp_xreport__error_4);
  allocp[4] = makefunctor(&string_const_8);
  allocp[5] = x0;
  allocp[6] = a4;
  allocp[7] = a5;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 norm__guard__unify__new_6_ext_interrupt:
  reasonp = 0l;
 norm__guard__unify__new_6_interrupt:
  toppred = &predicate_klic__comp__normalize_xnorm__guard__unify__new_6;
  goto interrupt_6;
 }

 norm__guard__unify__new_2F6_240_7_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 norm__guard__unify__new_2F6_240_7_clear_reason:
  reasonp = reasons;
 norm__guard__unify__new_2F6_240_7_0:
 norm__guard__unify__new_2F6_240_7_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_no)) goto norm__guard__unify__new_2F6_240_7_interrupt;
  allocp[0] = makesym(functor_rename_1);
  allocp[1] = a6;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__3D_2);
  allocp[3] = a2;
  allocp[4] = x0;
  x1 = makefunctor(&allocp[2]);
  allocp[5] = a3;
  allocp[6] = x1;
  x2 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a1, x2);
  unify(a4, a5);
  proceed();
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_yes_1)) goto norm__guard__unify__new_2F6_240_7_interrupt;
  allocp[0] = makesym(functor__3D_2);
  allocp[1] = a2;
  x1 = arg(a0, 0);
  allocp[2] = x1;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = a3;
  allocp[4] = x0;
  x2 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a1, x2);
  unify(a4, a5);
  proceed();
 case VARREF:
  deref_and_jump(a0,norm__guard__unify__new_2F6_240_7_1);
  *reasonp++ =  a0;
  goto norm__guard__unify__new_2F6_240_7_interrupt;
  };
  goto norm__guard__unify__new_2F6_240_7_interrupt;
 norm__guard__unify__new_2F6_240_7_ext_interrupt:
  reasonp = 0l;
 norm__guard__unify__new_2F6_240_7_interrupt:
  goto interrupt_7;
 }

 norm__guard__unify__args_10_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 norm__guard__unify__args_10_clear_reason:
  reasonp = reasons;
 norm__guard__unify__args_10_0:
 norm__guard__unify__args_10_1:
  switch (ptagof(a0)) {
 case CONS:
 norm__guard__unify__args_10_3:
  switch (ptagof(a1)) {
 case CONS:
 norm__guard__unify__args_10_5:
  switch (ptagof(a4)) {
 case ATOMIC:
  if (isint(a4)) goto norm__guard__unify__args_10_interrupt;
  switch (symval(a4)) {
 case symval(makesym(atom_abnormal)):
  unify3(a9, a8, a7, a6, a3, a2);
  unify_value(a5, makesym(atom_abnormal));
  proceed();
 case symval(makesym(atom_normal)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__guard__unify__args_10);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  x1 = cdr_of(a1);
  allocp[3] = x1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x3 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = x5 = makeref(&allocp[10]);
  allocp[11] = a9;
  a0 = car_of(a0);
  a1 = car_of(a1);
  a3 = a2;
  a4 = x2;
  a5 = a6;
  a6 = x4;
  a7 = a8;
  a8 = x5;
  a2 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  execute(norm__guard__unify_9_0);
  goto norm__guard__unify_9_ext_interrupt;
 default:
  goto norm__guard__unify__args_10_interrupt;
  };
 case VARREF:
  deref_and_jump(a4,norm__guard__unify__args_10_5);
  *reasonp++ =  a4;
  goto norm__guard__unify__args_10_interrupt;
  };
  goto norm__guard__unify__args_10_interrupt;
 case VARREF:
  deref_and_jump(a1,norm__guard__unify__args_10_3);
  *reasonp++ =  a1;
  goto norm__guard__unify__args_10_interrupt;
  };
  goto norm__guard__unify__args_10_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto norm__guard__unify__args_10_interrupt;
  unify4(a9, a8, a7, a6, a5, a4, a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,norm__guard__unify__args_10_1);
  *reasonp++ =  a0;
  goto norm__guard__unify__args_10_interrupt;
  };
  goto norm__guard__unify__args_10_interrupt;
 norm__guard__unify__args_10_ext_interrupt:
  reasonp = 0l;
 norm__guard__unify__args_10_interrupt:
  goto interrupt_10;
 }

 norm__guard__generic_8_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 norm__guard__generic_8_clear_reason:
  reasonp = reasons;
 norm__guard__generic_8_0:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__guard__generic__1_14);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x0 = makeref(&allocp[6]);
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = x3 = makeref(&allocp[9]);
  allocp[10] = x4 = makeref(&allocp[10]);
  allocp[11] = x5 = makeref(&allocp[11]);
  allocp[12] = a4;
  allocp[13] = a5;
  allocp[14] = a6;
  allocp[15] = a7;
  a1 = x0;
  a2 = x1;
  a3 = x2;
  a4 = x3;
  a5 = x4;
  a6 = x5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 16;
  execute(norm__gg__in__out_7_0);
  goto norm__gg__in__out_7_ext_interrupt;
 norm__guard__generic_8_ext_interrupt:
  reasonp = 0l;
 norm__guard__generic_8_interrupt:
  toppred = &predicate_klic__comp__normalize_xnorm__guard__generic_8;
  goto interrupt_8;
 }

 norm__guard__generic__1_14_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  qp = qp->next;
 norm__guard__generic__1_14_clear_reason:
  reasonp = reasons;
 norm__guard__generic__1_14_0:
 norm__guard__generic__1_14_1:
  switch (ptagof(a9)) {
 case ATOMIC:
  if (isint(a9)) goto norm__guard__generic__1_14_interrupt;
  switch (symval(a9)) {
 case symval(makesym(atom_normal)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__guard__generic__2_14);
  allocp[2] = a6;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a1;
  allocp[5] = a2;
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = x2 = makeref(&allocp[11]);
  allocp[12] = x3 = makeref(&allocp[12]);
  allocp[13] = a11;
  allocp[14] = x4 = makeref(&allocp[14]);
  allocp[15] = a13;
  a0 = a5;
  a2 = x1;
  a3 = a1;
  a4 = x2;
  a5 = a10;
  a6 = x3;
  a7 = a12;
  a8 = x4;
  a1 = makesym(atom_object);
  qp = (struct goalrec*)&allocp[0];
  allocp += 16;
  execute(norm__gg__in_9_0);
  goto norm__gg__in_9_ext_interrupt;
 case symval(makesym(atom_abnormal)):
  unify2(a13, a12, a11, a10);
  unify_value(a3, makesym(atom_abnormal));
  proceed();
 default:
  goto norm__guard__generic__1_14_interrupt;
  };
 case VARREF:
  deref_and_jump(a9,norm__guard__generic__1_14_1);
  *reasonp++ =  a9;
  goto norm__guard__generic__1_14_interrupt;
  };
  goto norm__guard__generic__1_14_interrupt;
 norm__guard__generic__1_14_ext_interrupt:
  reasonp = 0l;
 norm__guard__generic__1_14_interrupt:
  goto interrupt_14;
 }

 norm__guard__generic__2_14_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  a13 = qp->args[13];
  qp = qp->next;
 norm__guard__generic__2_14_clear_reason:
  reasonp = reasons;
 norm__guard__generic__2_14_0:
 norm__guard__generic__2_14_1:
  switch (ptagof(a9)) {
 case ATOMIC:
  if (isint(a9)) goto norm__guard__generic__2_14_interrupt;
  switch (symval(a9)) {
 case symval(makesym(atom_normal)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__guard__generic__3_13);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = x1 = makeref(&allocp[11]);
  allocp[12] = a11;
  allocp[13] = x2 = makeref(&allocp[13]);
  allocp[14] = a13;
  a3 = x0;
  a4 = a10;
  a5 = x1;
  a6 = a12;
  a7 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 15;
  execute(norm__gg__ins_8_0);
  goto norm__gg__ins_8_ext_interrupt;
 case symval(makesym(atom_abnormal)):
  unify2(a13, a12, a11, a10);
  unify_value(a4, makesym(atom_abnormal));
  proceed();
 default:
  goto norm__guard__generic__2_14_interrupt;
  };
 case VARREF:
  deref_and_jump(a9,norm__guard__generic__2_14_1);
  *reasonp++ =  a9;
  goto norm__guard__generic__2_14_interrupt;
  };
  goto norm__guard__generic__2_14_interrupt;
 norm__guard__generic__2_14_ext_interrupt:
  reasonp = 0l;
 norm__guard__generic__2_14_interrupt:
  goto interrupt_14;
 }

 norm__guard__generic__3_13_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  a12 = qp->args[12];
  qp = qp->next;
 norm__guard__generic__3_13_clear_reason:
  reasonp = reasons;
 norm__guard__generic__3_13_0:
 norm__guard__generic__3_13_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto norm__guard__generic__3_13_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_normal)):
  allocp[0] = makesym(functor_gg_3);
  allocp[1] = a5;
  allocp[2] = a6;
  allocp[3] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp[4] = makesym(functor_gg_2);
  allocp[5] = x0;
  allocp[6] = a7;
  x1 = makefunctor(&allocp[4]);
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = x1;
  x2 = makecons(&allocp[7]);
  allocp += 9;
  unify_value(a9, x2);
  unify_value(a4, makesym(atom_normal));
  allocp[0] = makesym(functor_gg_3);
  allocp[1] = a5;
  allocp[2] = a6;
  allocp[3] = a1;
  x4 = makefunctor(&allocp[0]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_klic__comp__normalize_xnorm__gg__outs_9);
  allocp[6] = a8;
  allocp[7] = x5 = makeref(&allocp[7]);
  allocp[8] = x4;
  allocp[9] = a2;
  allocp[10] = a3;
  allocp[11] = x3;
  allocp[12] = a10;
  allocp[13] = a11;
  allocp[14] = a12;
  allocp[15] = (q)(struct goalrec*)&allocp[4];
  allocp[16] = (q)(&predicate_klic__comp__util_xlength_2);
  allocp[17] = a1;
  allocp[18] = x5;
  qp = (struct goalrec*)&allocp[15];
  allocp += 19;
  proceed();
 case symval(makesym(atom_abnormal)):
  unify2(a12, a11, a10, a9);
  unify_value(a4, makesym(atom_abnormal));
  proceed();
 default:
  goto norm__guard__generic__3_13_interrupt;
  };
 case VARREF:
  deref_and_jump(a0,norm__guard__generic__3_13_1);
  *reasonp++ =  a0;
  goto norm__guard__generic__3_13_interrupt;
  };
  goto norm__guard__generic__3_13_interrupt;
 norm__guard__generic__3_13_ext_interrupt:
  reasonp = 0l;
 norm__guard__generic__3_13_interrupt:
  goto interrupt_13;
 }

 norm__gg__in__out_7_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 norm__gg__in__out_7_clear_reason:
  reasonp = reasons;
 norm__gg__in__out_7_0:
 norm__gg__in__out_7_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_functor_1)) goto norm__gg__in__out_7_7;
  x0 = arg(a0, 0);
 norm__gg__in__out_7_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__3A_2)) goto norm__gg__in__out_7_7;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__gg_5);
  x1 = arg(x0, 0);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a6;
  a0 = arg(x0, 1);
  a1 = a5;
  a2 = makeint(0L);
  a3 = a4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(norm__gg__count__out_4_0);
  goto norm__gg__count__out_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,norm__gg__in__out_7_4);
  *reasonp++ =  x0;
  goto norm__gg__in__out_7_7;
  };
  goto norm__gg__in__out_7_7;
 case VARREF:
  deref_and_jump(a0,norm__gg__in__out_7_1);
  *reasonp++ =  a0;
  goto norm__gg__in__out_7_7;
  };
  goto norm__gg__in__out_7_7;
 norm__gg__in__out_7_7:
  otherwise(norm__gg__in__out_7_interrupt);
  unify_value(a4, makeint(0L));
  unify_value(a5, NILATOM);
  a4 = a6;
  execute(norm__gg_5_0);
  goto norm__gg_5_ext_interrupt;
 norm__gg__in__out_7_ext_interrupt:
  reasonp = 0l;
 norm__gg__in__out_7_interrupt:
  toppred = &predicate_klic__comp__normalize_xnorm__gg__in__out_7;
  goto interrupt_7;
 }

 norm__gg__count__out_4_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 norm__gg__count__out_4_clear_reason:
  reasonp = reasons;
 norm__gg__count__out_4_0:
 norm__gg__count__out_4_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_functor_1)) goto norm__gg__count__out_4_7;
  x0 = arg(a0, 0);
 norm__gg__count__out_4_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__3A_2)) goto norm__gg__count__out_4_7;
  allocp[0] = x2 = makeref(&allocp[0]);
  x3 = arg(x0, 0);
  allocp[1] = x3;
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x1);
  bblt_add_no_check_y(a2,makeint(1L),x4);
  a0 = arg(x0, 1);
  a1 = x2;
  a2 = x4;
  execute(norm__gg__count__out_4_0);
  goto norm__gg__count__out_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,norm__gg__count__out_4_4);
  *reasonp++ =  x0;
  goto norm__gg__count__out_4_7;
  };
  goto norm__gg__count__out_4_7;
 case VARREF:
  deref_and_jump(a0,norm__gg__count__out_4_1);
  *reasonp++ =  a0;
  goto norm__gg__count__out_4_7;
  };
  goto norm__gg__count__out_4_7;
 norm__gg__count__out_4_7:
  otherwise(norm__gg__count__out_4_interrupt);
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  bblt_add_no_check_y(a2,makeint(1L),x1);
  unify(a3, x1);
  proceed();
 norm__gg__count__out_4_ext_interrupt:
  reasonp = 0l;
 norm__gg__count__out_4_interrupt:
  toppred = &predicate_klic__comp__normalize_xnorm__gg__count__out_4;
  goto interrupt_4;
 }

 norm__gg_5_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 norm__gg_5_clear_reason:
  reasonp = reasons;
 norm__gg_5_0:
 norm__gg_5_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_functor_1)) goto norm__gg_5_9;
  x0 = arg(a0, 0);
 norm__gg_5_4:
  if (isref(x0)) goto norm__gg_5_8;
  gblt_pfunctor(x0,x1,norm__gg_5_9);
  gblt_arity(x0,x2,norm__gg_5_9);
  allocp[0] = makesym(functor__2F_2);
  allocp[1] = x4 = makeref(&allocp[1]);
  allocp[2] = x5 = makeref(&allocp[2]);
  x3 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a1, x3);
  a0 = x4;
  a1 = x5;
  a5 = x1;
  a6 = x2;
  a7 = a4;
  a4 = x0;
  execute(norm__gg__1_8_0);
  goto norm__gg__1_8_ext_interrupt;
 norm__gg_5_8:
  deref_and_jump(x0,norm__gg_5_4);
  *reasonp++ =  x0;
  goto norm__gg_5_9;
 case VARREF:
  deref_and_jump(a0,norm__gg_5_1);
  *reasonp++ =  a0;
  goto norm__gg_5_9;
  };
  goto norm__gg_5_9;
 norm__gg_5_9:
  otherwise(norm__gg_5_interrupt);
  unify_value(a4, makesym(atom_abnormal));
  proceed();
 norm__gg_5_ext_interrupt:
  reasonp = 0l;
 norm__gg_5_interrupt:
  toppred = &predicate_klic__comp__normalize_xnorm__gg_5;
  goto interrupt_5;
 }

 norm__gg__1_8_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 norm__gg__1_8_clear_reason:
  reasonp = reasons;
 norm__gg__1_8_0:
 norm__gg__1_8_1:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (a5 != makesym(atom_generic)) goto norm__gg__1_8_9;
 norm__gg__1_8_5:
  switch (ptagof(a6)) {
 case ATOMIC:
 norm__gg__1_8_7:
  if (a6 != makeint(2L)) goto norm__gg__1_8_9;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__gg__2_6);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x0 = makeref(&allocp[6]);
  allocp[7] = a7;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_functor__table_xarg_3);
  allocp[10] = makeint(2L);
  allocp[11] = a4;
  allocp[12] = x0;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_functor__table_xarg_3);
  allocp[15] = makeint(1L);
  allocp[16] = a4;
  allocp[17] = a2;
  qp = (struct goalrec*)&allocp[13];
  allocp += 18;
  proceed();
 case VARREF:
  deref_and_jump(a6,norm__gg__1_8_5);
  *reasonp++ =  a6;
  goto norm__gg__1_8_9;
  };
  goto norm__gg__1_8_9;
 case VARREF:
  deref_and_jump(a5,norm__gg__1_8_1);
  *reasonp++ =  a5;
  goto norm__gg__1_8_9;
  };
  goto norm__gg__1_8_9;
 norm__gg__1_8_9:
  otherwise(norm__gg__1_8_interrupt);
  unify2(a0, a5, a1, a6);
  unify_value(a7, makesym(atom_normal));
  allocp[0] = a3;
  allocp[1] = a2;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = x2 = makeref(&allocp[3]);
  x1 = makecons(&allocp[2]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_klic__comp__util_xuniv_2);
  allocp[6] = a4;
  allocp[7] = x1;
  qp = (struct goalrec*)&allocp[4];
  allocp += 8;
  proceed();
 norm__gg__1_8_ext_interrupt:
  reasonp = 0l;
 norm__gg__1_8_interrupt:
  toppred = &predicate_klic__comp__normalize_xnorm__gg__1_8;
  goto interrupt_8;
 }

 norm__gg__2_6_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 norm__gg__2_6_clear_reason:
  reasonp = reasons;
 norm__gg__2_6_0:
 norm__gg__2_6_1:
  switch (ptagof(a4)) {
 case FUNCTOR:
  if (functor_of(a4) != makesym(functor_functor_1)) goto norm__gg__2_6_9;
  x0 = arg(a4, 0);
 norm__gg__2_6_4:
  if (isref(x0)) goto norm__gg__2_6_8;
  gblt_pfunctor(x0,x1,norm__gg__2_6_9);
  gblt_arity(x0,x2,norm__gg__2_6_9);
  unify_value(a0, x1);
  unify_value(a1, x2);
  unify_value(a5, makesym(atom_normal));
  allocp[0] = a3;
  allocp[1] = x4 = makeref(&allocp[1]);
  x3 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__util_xuniv_2);
  allocp[4] = x0;
  allocp[5] = x3;
  qp = (struct goalrec*)&allocp[2];
  allocp += 6;
  proceed();
 norm__gg__2_6_8:
  deref_and_jump(x0,norm__gg__2_6_4);
  *reasonp++ =  x0;
  goto norm__gg__2_6_9;
 case VARREF:
  deref_and_jump(a4,norm__gg__2_6_1);
  *reasonp++ =  a4;
  goto norm__gg__2_6_9;
  };
  goto norm__gg__2_6_9;
 norm__gg__2_6_9:
  otherwise(norm__gg__2_6_interrupt);
  unify_value(a5, makesym(atom_abnormal));
  proceed();
 norm__gg__2_6_ext_interrupt:
  reasonp = 0l;
 norm__gg__2_6_interrupt:
  goto interrupt_6;
 }

 norm__gg__ins_8_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 norm__gg__ins_8_clear_reason:
  reasonp = reasons;
 norm__gg__ins_8_0:
 norm__gg__ins_8_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = x2 = makeref(&allocp[1]);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__gg__ins__1_9);
  x3 = cdr_of(a0);
  allocp[2] = x3;
  allocp[3] = x1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x4 = makeref(&allocp[6]);
  allocp[7] = x5 = makeref(&allocp[7]);
  allocp[8] = a5;
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = a7;
  a0 = car_of(a0);
  a1 = makesym(atom_bound);
  a3 = a2;
  a5 = a4;
  a7 = a6;
  a8 = x6;
  a6 = x5;
  a4 = x4;
  a2 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 11;
  execute(norm__gg__in_9_0);
  goto norm__gg__in_9_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto norm__gg__ins_8_interrupt;
  unify2(a7, a6, a5, a4);
  unify_value(a1, NILATOM);
  unify_value(a3, makesym(atom_normal));
  proceed();
 case VARREF:
  deref_and_jump(a0,norm__gg__ins_8_1);
  *reasonp++ =  a0;
  goto norm__gg__ins_8_interrupt;
  };
  goto norm__gg__ins_8_interrupt;
 norm__gg__ins_8_ext_interrupt:
  reasonp = 0l;
 norm__gg__ins_8_interrupt:
  toppred = &predicate_klic__comp__normalize_xnorm__gg__ins_8;
  goto interrupt_8;
 }

 norm__gg__ins__1_9_top: {
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 norm__gg__ins__1_9_clear_reason:
  reasonp = reasons;
 norm__gg__ins__1_9_0:
 norm__gg__ins__1_9_1:
  switch (ptagof(a4)) {
 case ATOMIC:
  if (isint(a4)) goto norm__gg__ins__1_9_interrupt;
  switch (symval(a4)) {
 case symval(makesym(atom_normal)):
  a4 = a5;
  a5 = a6;
  a6 = a7;
  a7 = a8;
  execute(norm__gg__ins_8_0);
  goto norm__gg__ins_8_ext_interrupt;
 case symval(makesym(atom_abnormal)):
  unify2(a8, a7, a6, a5);
  unify_value(a3, makesym(atom_abnormal));
  proceed();
 default:
  goto norm__gg__ins__1_9_interrupt;
  };
 case VARREF:
  deref_and_jump(a4,norm__gg__ins__1_9_1);
  *reasonp++ =  a4;
  goto norm__gg__ins__1_9_interrupt;
  };
  goto norm__gg__ins__1_9_interrupt;
 norm__gg__ins__1_9_ext_interrupt:
  reasonp = 0l;
 norm__gg__ins__1_9_interrupt:
  goto interrupt_9;
 }

 norm__gg__in_9_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 norm__gg__in_9_clear_reason:
  reasonp = reasons;
 norm__gg__in_9_0:
 norm__gg__in_9_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_variable_1)) goto norm__gg__in_9_4;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__gg__in__1_11);
  x0 = arg(a0, 0);
  allocp[2] = x0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = a5;
  allocp[10] = a6;
  allocp[11] = a7;
  allocp[12] = a8;
  allocp[13] = (q)(struct goalrec*)&allocp[0];
  allocp[14] = (q)(&predicate_klic__comp__util_xassoc_4);
  allocp[15] = a3;
  allocp[16] = x0;
  allocp[17] = x1;
  allocp[18] = x2;
  qp = (struct goalrec*)&allocp[13];
  allocp += 19;
  proceed();
 case VARREF:
  deref_and_jump(a0,norm__gg__in_9_1);
  *reasonp++ =  a0;
  goto norm__gg__in_9_4;
  };
  goto norm__gg__in_9_4;
 norm__gg__in_9_4:
  otherwise(norm__gg__in_9_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__gg__in__2_8);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a4;
  allocp[5] = x0 = makeref(&allocp[5]);
  allocp[6] = a5;
  allocp[7] = a6;
  allocp[8] = a7;
  allocp[9] = a8;
  a1 = a2;
  allocp[10] = x1 = makeref(&allocp[10]);
  a2 = x1;
  a3 = makesym(atom_yes);
  a4 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 11;
  execute(is__const_5_0);
  goto is__const_5_ext_interrupt;
 norm__gg__in_9_ext_interrupt:
  reasonp = 0l;
 norm__gg__in_9_interrupt:
  toppred = &predicate_klic__comp__normalize_xnorm__gg__in_9;
  goto interrupt_9;
 }

 norm__gg__in__1_11_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  qp = qp->next;
 norm__gg__in__1_11_clear_reason:
  reasonp = reasons;
 norm__gg__in__1_11_0:
 norm__gg__in__1_11_1:
  switch (ptagof(a5)) {
 case FUNCTOR:
  if (functor_of(a5) != makesym(functor_rename_1)) goto norm__gg__in__1_11_8;
 norm__gg__in__1_11_4:
  switch (ptagof(a6)) {
 case ATOMIC:
  if (a6 != makesym(atom_yes)) goto norm__gg__in__1_11_8;
  allocp[0] = makesym(functor_variable_1);
  x1 = arg(a5, 0);
  allocp[1] = x1;
  x0 = makefunctor(&allocp[0]);
  a0 = x0;
  a5 = a7;
  a6 = a8;
  a7 = a9;
  a8 = a10;
  allocp += 2;
  execute(norm__gg__in_9_0);
  goto norm__gg__in_9_ext_interrupt;
 case VARREF:
  deref_and_jump(a6,norm__gg__in__1_11_4);
  *reasonp++ =  a6;
  goto norm__gg__in__1_11_8;
  };
  goto norm__gg__in__1_11_8;
 case VARREF:
  deref_and_jump(a5,norm__gg__in__1_11_1);
  *reasonp++ =  a5;
  goto norm__gg__in__1_11_8;
  };
  goto norm__gg__in__1_11_8;
 norm__gg__in__1_11_8:
 norm__gg__in__1_11_9:
  switch (ptagof(a6)) {
 case ATOMIC:
  if (a6 != makesym(atom_no)) goto norm__gg__in__1_11_13;
  unify(a8, a7);
  unify_value(a4, makesym(atom_abnormal));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__kl1cmp_xwarning_4);
  allocp[2] = makefunctor(&string_const_9);
  allocp[3] = NILATOM;
  allocp[4] = a9;
  allocp[5] = a10;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  proceed();
 case VARREF:
  deref_and_jump(a6,norm__gg__in__1_11_9);
  *reasonp++ =  a6;
  goto norm__gg__in__1_11_13;
  };
  goto norm__gg__in__1_11_13;
 norm__gg__in__1_11_13:
  otherwise(norm__gg__in__1_11_interrupt);
 norm__gg__in__1_11_15:
  switch (ptagof(a6)) {
 case ATOMIC:
  if (a6 != makesym(atom_yes)) goto norm__gg__in__1_11_interrupt;
  unify2(a10, a9, a2, a5);
  allocp[0] = makesym(functor__3A_2);
  allocp[1] = a5;
  allocp[2] = a1;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = a8;
  allocp[4] = x0;
  x1 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a7, x1);
  unify_value(a4, makesym(atom_normal));
  proceed();
 case VARREF:
  deref_and_jump(a6,norm__gg__in__1_11_15);
  *reasonp++ =  a6;
  goto norm__gg__in__1_11_interrupt;
  };
  goto norm__gg__in__1_11_interrupt;
 norm__gg__in__1_11_ext_interrupt:
  reasonp = 0l;
 norm__gg__in__1_11_interrupt:
  goto interrupt_11;
 }

 norm__gg__in__2_8_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 norm__gg__in__2_8_clear_reason:
  reasonp = reasons;
 norm__gg__in__2_8_0:
 norm__gg__in__2_8_1:
  switch (ptagof(a1)) {
 case ATOMIC:
  if (a1 != makesym(atom_object)) goto norm__gg__in__2_8_15;
 norm__gg__in__2_8_5:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_yes)) goto norm__gg__in__2_8_15;
  unify(a5, a4);
  unify_value(a2, makesym(atom_normal));
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__kl1cmp_xwarning_4);
  allocp[4] = makefunctor(&string_const_10);
  allocp[5] = x0;
  allocp[6] = a6;
  allocp[7] = a7;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 case VARREF:
  deref_and_jump(a3,norm__gg__in__2_8_5);
  *reasonp++ =  a3;
  goto norm__gg__in__2_8_15;
  };
  goto norm__gg__in__2_8_15;
 case FUNCTOR:
  if (functor_of(a1) != makesym(functor_object_1)) goto norm__gg__in__2_8_15;
 norm__gg__in__2_8_11:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_yes)) goto norm__gg__in__2_8_15;
  unify(a5, a4);
  unify_value(a2, makesym(atom_normal));
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__kl1cmp_xwarning_4);
  allocp[4] = makefunctor(&string_const_10);
  allocp[5] = x0;
  allocp[6] = a6;
  allocp[7] = a7;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 case VARREF:
  deref_and_jump(a3,norm__gg__in__2_8_11);
  *reasonp++ =  a3;
  goto norm__gg__in__2_8_15;
  };
  goto norm__gg__in__2_8_15;
 case VARREF:
  deref_and_jump(a1,norm__gg__in__2_8_1);
  *reasonp++ =  a1;
  goto norm__gg__in__2_8_15;
  };
  goto norm__gg__in__2_8_15;
 norm__gg__in__2_8_15:
 norm__gg__in__2_8_16:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_no)) goto norm__gg__in__2_8_20;
  unify(a5, a4);
  unify_value(a2, makesym(atom_abnormal));
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__kl1cmp_xwarning_4);
  allocp[4] = makefunctor(&string_const_11);
  allocp[5] = x0;
  allocp[6] = a6;
  allocp[7] = a7;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 case VARREF:
  deref_and_jump(a3,norm__gg__in__2_8_16);
  *reasonp++ =  a3;
  goto norm__gg__in__2_8_20;
  };
  goto norm__gg__in__2_8_20;
 norm__gg__in__2_8_20:
  otherwise(norm__gg__in__2_8_interrupt);
 norm__gg__in__2_8_22:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_yes)) goto norm__gg__in__2_8_interrupt;
  unify2(a7, a6, a5, a4);
  unify_value(a2, makesym(atom_normal));
  proceed();
 case VARREF:
  deref_and_jump(a3,norm__gg__in__2_8_22);
  *reasonp++ =  a3;
  goto norm__gg__in__2_8_interrupt;
  };
  goto norm__gg__in__2_8_interrupt;
 norm__gg__in__2_8_ext_interrupt:
  reasonp = 0l;
 norm__gg__in__2_8_interrupt:
  goto interrupt_8;
 }

 norm__gg__outs_9_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 norm__gg__outs_9_clear_reason:
  reasonp = reasons;
 norm__gg__outs_9_0:
 norm__gg__outs_9_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__gg__outs_9);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = a6;
  allocp[9] = a7;
  allocp[10] = a8;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[13] = a1;
  allocp[14] = makeint(1L);
  allocp[15] = x1;
  allocp[16] = makesym(functor_gg_2);
  allocp[17] = a2;
  allocp[18] = a1;
  x4 = makefunctor(&allocp[16]);
  a0 = car_of(a0);
  a1 = x4;
  a2 = a3;
  a3 = x2;
  a4 = a5;
  a5 = x3;
  qp = (struct goalrec*)&allocp[11];
  allocp += 19;
  execute(norm__guard__term_6_0);
  goto norm__guard__term_6_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto norm__gg__outs_9_interrupt;
  unify3(a4, a3, a6, a5, a8, a7);
  proceed();
 case VARREF:
  deref_and_jump(a0,norm__gg__outs_9_1);
  *reasonp++ =  a0;
  goto norm__gg__outs_9_interrupt;
  };
  goto norm__gg__outs_9_interrupt;
 norm__gg__outs_9_ext_interrupt:
  reasonp = 0l;
 norm__gg__outs_9_interrupt:
  goto interrupt_9;
 }

 norm__guard__builts_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 norm__guard__builts_8_clear_reason:
  reasonp = reasons;
 norm__guard__builts_8_0:
 norm__guard__builts_8_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 norm__guard__builts_8_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__24_3)) goto norm__guard__builts_8_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__guard__builts__1_12);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  x2 = arg(x0, 1);
  allocp[6] = x2;
  x3 = arg(x0, 2);
  allocp[7] = x3;
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = x5 = makeref(&allocp[9]);
  allocp[10] = x6 = makeref(&allocp[10]);
  allocp[11] = a5;
  allocp[12] = x7 = makeref(&allocp[12]);
  allocp[13] = a7;
  a0 = arg(x0, 0);
  a2 = a1;
  a3 = x5;
  a5 = x6;
  a7 = x7;
  a1 = x4;
  qp = (struct goalrec*)&allocp[0];
  allocp += 14;
  execute(norm__gblt__args_8_0);
  goto norm__gblt__args_8_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,norm__guard__builts_8_3);
  *reasonp++ =  x0;
  goto norm__guard__builts_8_interrupt;
  };
  goto norm__guard__builts_8_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto norm__guard__builts_8_interrupt;
  unify3(a7, a6, a5, a4, a2, a1);
  unify_value(a3, makesym(atom_normal));
  proceed();
 case VARREF:
  deref_and_jump(a0,norm__guard__builts_8_1);
  *reasonp++ =  a0;
  goto norm__guard__builts_8_interrupt;
  };
  goto norm__guard__builts_8_interrupt;
 norm__guard__builts_8_ext_interrupt:
  reasonp = 0l;
 norm__guard__builts_8_interrupt:
  toppred = &predicate_klic__comp__normalize_xnorm__guard__builts_8;
  goto interrupt_8;
 }

 norm__guard__builts__1_12_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  a10 = qp->args[10];
  a11 = qp->args[11];
  qp = qp->next;
 norm__guard__builts__1_12_clear_reason:
  reasonp = reasons;
 norm__guard__builts__1_12_0:
 norm__guard__builts__1_12_1:
  switch (ptagof(a7)) {
 case ATOMIC:
  if (isint(a7)) goto norm__guard__builts__1_12_interrupt;
  switch (symval(a7)) {
 case symval(makesym(atom_normal)):
 norm__guard__builts__1_12_5:
  switch (ptagof(a4)) {
 case ATOMIC:
  if (a4 != makesym(atom_none)) goto norm__guard__builts__1_12_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__guard__builts_8);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x0 = makeref(&allocp[6]);
  allocp[7] = a9;
  allocp[8] = a10;
  allocp[9] = a11;
  allocp[10] = makesym(functor_gp_1);
  allocp[11] = x2 = makeref(&allocp[11]);
  x1 = makefunctor(&allocp[10]);
  allocp[12] = x0;
  allocp[13] = x1;
  x3 = makecons(&allocp[12]);
  qp = (struct goalrec*)&allocp[0];
  allocp += 14;
  unify_value(a8, x3);
  allocp[0] = a6;
  allocp[1] = a5;
  x4 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[4] = x2;
  allocp[5] = x4;
  qp = (struct goalrec*)&allocp[2];
  allocp += 6;
  proceed();
 case FUNCTOR:
  if (functor_of(a4) != makesym(functor__3A_2)) goto norm__guard__builts__1_12_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__guard__builts_8);
  allocp[2] = a0;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = a9;
  allocp[8] = a10;
  allocp[9] = a11;
  allocp[10] = makesym(functor_gb_1);
  allocp[11] = x3 = makeref(&allocp[11]);
  x2 = makefunctor(&allocp[10]);
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_klic__comp__normalize_xnorm__guard__term_6);
  x4 = arg(a4, 0);
  allocp[14] = x4;
  allocp[15] = x2;
  allocp[16] = a1;
  allocp[17] = x0;
  allocp[18] = x5 = makeref(&allocp[18]);
  allocp[19] = x1;
  allocp[20] = makesym(functor_gb_2);
  allocp[21] = x3;
  x7 = arg(a4, 1);
  allocp[22] = x7;
  x6 = makefunctor(&allocp[20]);
  allocp[23] = x5;
  allocp[24] = x6;
  x8 = makecons(&allocp[23]);
  qp = (struct goalrec*)&allocp[12];
  allocp += 25;
  unify_value(a8, x8);
  allocp[0] = a6;
  allocp[1] = a5;
  x9 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[4] = x3;
  allocp[5] = x9;
  qp = (struct goalrec*)&allocp[2];
  allocp += 6;
  proceed();
 case VARREF:
  deref_and_jump(a4,norm__guard__builts__1_12_5);
  *reasonp++ =  a4;
  goto norm__guard__builts__1_12_interrupt;
  };
  goto norm__guard__builts__1_12_interrupt;
 case symval(makesym(atom_abnormal)):
  unify2(a11, a10, a9, a8);
  unify_value(a3, makesym(atom_abnormal));
  proceed();
 default:
  goto norm__guard__builts__1_12_interrupt;
  };
 case VARREF:
  deref_and_jump(a7,norm__guard__builts__1_12_1);
  *reasonp++ =  a7;
  goto norm__guard__builts__1_12_interrupt;
  };
  goto norm__guard__builts__1_12_interrupt;
 norm__guard__builts__1_12_ext_interrupt:
  reasonp = 0l;
 norm__guard__builts__1_12_interrupt:
  goto interrupt_12;
 }

 norm__gblt__args_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 norm__gblt__args_8_clear_reason:
  reasonp = reasons;
 norm__gblt__args_8_0:
 norm__gblt__args_8_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 norm__gblt__args_8_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__3A_2)) goto norm__gblt__args_8_interrupt;
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = x3 = makeref(&allocp[1]);
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__gblt__args__1_9);
  x4 = cdr_of(a0);
  allocp[2] = x4;
  allocp[3] = x2;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x5 = makeref(&allocp[6]);
  allocp[7] = x6 = makeref(&allocp[7]);
  allocp[8] = a5;
  allocp[9] = x7 = makeref(&allocp[9]);
  allocp[10] = a7;
  a0 = arg(x0, 0);
  a1 = arg(x0, 1);
  a3 = a2;
  a5 = a4;
  a7 = a6;
  a8 = x7;
  a6 = x6;
  a4 = x5;
  a2 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 11;
  execute(norm__gblt__arg_9_0);
  goto norm__gblt__arg_9_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,norm__gblt__args_8_3);
  *reasonp++ =  x0;
  goto norm__gblt__args_8_interrupt;
  };
  goto norm__gblt__args_8_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto norm__gblt__args_8_interrupt;
  unify2(a7, a6, a5, a4);
  unify_value(a1, NILATOM);
  unify_value(a3, makesym(atom_normal));
  proceed();
 case VARREF:
  deref_and_jump(a0,norm__gblt__args_8_1);
  *reasonp++ =  a0;
  goto norm__gblt__args_8_interrupt;
  };
  goto norm__gblt__args_8_interrupt;
 norm__gblt__args_8_ext_interrupt:
  reasonp = 0l;
 norm__gblt__args_8_interrupt:
  toppred = &predicate_klic__comp__normalize_xnorm__gblt__args_8;
  goto interrupt_8;
 }

 norm__gblt__args__1_9_top: {
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 norm__gblt__args__1_9_clear_reason:
  reasonp = reasons;
 norm__gblt__args__1_9_0:
 norm__gblt__args__1_9_1:
  switch (ptagof(a4)) {
 case ATOMIC:
  if (isint(a4)) goto norm__gblt__args__1_9_interrupt;
  switch (symval(a4)) {
 case symval(makesym(atom_normal)):
  a4 = a5;
  a5 = a6;
  a6 = a7;
  a7 = a8;
  execute(norm__gblt__args_8_0);
  goto norm__gblt__args_8_ext_interrupt;
 case symval(makesym(atom_abnormal)):
  unify2(a8, a7, a6, a5);
  unify_value(a3, makesym(atom_abnormal));
  proceed();
 default:
  goto norm__gblt__args__1_9_interrupt;
  };
 case VARREF:
  deref_and_jump(a4,norm__gblt__args__1_9_1);
  *reasonp++ =  a4;
  goto norm__gblt__args__1_9_interrupt;
  };
  goto norm__gblt__args__1_9_interrupt;
 norm__gblt__args__1_9_ext_interrupt:
  reasonp = 0l;
 norm__gblt__args__1_9_interrupt:
  goto interrupt_9;
 }

 norm__gblt__arg_9_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 norm__gblt__arg_9_clear_reason:
  reasonp = reasons;
 norm__gblt__arg_9_0:
 norm__gblt__arg_9_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_variable_1)) goto norm__gblt__arg_9_4;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__gblt__arg__1_10);
  x0 = arg(a0, 0);
  allocp[2] = x0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = a7;
  allocp[11] = a8;
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_klic__comp__util_xassoc_3);
  allocp[14] = a3;
  allocp[15] = x0;
  allocp[16] = x1;
  qp = (struct goalrec*)&allocp[12];
  allocp += 17;
  proceed();
 case VARREF:
  deref_and_jump(a0,norm__gblt__arg_9_1);
  *reasonp++ =  a0;
  goto norm__gblt__arg_9_4;
  };
  goto norm__gblt__arg_9_4;
 norm__gblt__arg_9_4:
  otherwise(norm__gblt__arg_9_interrupt);
  unify(a6, a5);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__gblt__arg__2_8);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = a0;
  allocp[8] = a7;
  allocp[9] = a8;
  a1 = a2;
  a2 = x1;
  a3 = makesym(atom_yes);
  a4 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  execute(is__const_5_0);
  goto is__const_5_ext_interrupt;
 norm__gblt__arg_9_ext_interrupt:
  reasonp = 0l;
 norm__gblt__arg_9_interrupt:
  toppred = &predicate_klic__comp__normalize_xnorm__gblt__arg_9;
  goto interrupt_9;
 }

 norm__gblt__arg__1_10_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 norm__gblt__arg__1_10_clear_reason:
  reasonp = reasons;
 norm__gblt__arg__1_10_0:
 norm__gblt__arg__1_10_1:
  switch (ptagof(a5)) {
 case FUNCTOR:
  if (functor_of(a5) != makesym(functor_yes_1)) goto norm__gblt__arg__1_10_7;
  x0 = arg(a5, 0);
 norm__gblt__arg__1_10_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_rename_1)) goto norm__gblt__arg__1_10_7;
  allocp[0] = makesym(functor_variable_1);
  x2 = arg(x0, 0);
  allocp[1] = x2;
  x1 = makefunctor(&allocp[0]);
  a0 = x1;
  a5 = a6;
  a6 = a7;
  a7 = a8;
  a8 = a9;
  allocp += 2;
  execute(norm__gblt__arg_9_0);
  goto norm__gblt__arg_9_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,norm__gblt__arg__1_10_4);
  *reasonp++ =  x0;
  goto norm__gblt__arg__1_10_7;
  };
  goto norm__gblt__arg__1_10_7;
 case VARREF:
  deref_and_jump(a5,norm__gblt__arg__1_10_1);
  *reasonp++ =  a5;
  goto norm__gblt__arg__1_10_7;
  };
  goto norm__gblt__arg__1_10_7;
 norm__gblt__arg__1_10_7:
  otherwise(norm__gblt__arg__1_10_interrupt);
 norm__gblt__arg__1_10_9:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (a5 != makesym(atom_no)) goto norm__gblt__arg__1_10_interrupt;
  unify(a7, a6);
  unify_value(a4, makesym(atom_abnormal));
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__kl1cmp_xwarning_4);
  allocp[2] = makefunctor(&string_const_12);
  allocp[3] = NILATOM;
  allocp[4] = a8;
  allocp[5] = a9;
  qp = (struct goalrec*)&allocp[0];
  allocp += 6;
  proceed();
 case FUNCTOR:
  if (functor_of(a5) != makesym(functor_yes_1)) goto norm__gblt__arg__1_10_interrupt;
  unify(a9, a8);
  x0 = arg(a5, 0);
  unify(a2, x0);
  allocp[0] = makesym(functor__3A_2);
  allocp[1] = x0;
  allocp[2] = a1;
  x1 = makefunctor(&allocp[0]);
  allocp[3] = a7;
  allocp[4] = x1;
  x2 = makecons(&allocp[3]);
  allocp += 5;
  unify_value(a6, x2);
  unify_value(a4, makesym(atom_normal));
  proceed();
 case VARREF:
  deref_and_jump(a5,norm__gblt__arg__1_10_9);
  *reasonp++ =  a5;
  goto norm__gblt__arg__1_10_interrupt;
  };
  goto norm__gblt__arg__1_10_interrupt;
 norm__gblt__arg__1_10_ext_interrupt:
  reasonp = 0l;
 norm__gblt__arg__1_10_interrupt:
  goto interrupt_10;
 }

 norm__gblt__arg__2_8_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 norm__gblt__arg__2_8_clear_reason:
  reasonp = reasons;
 norm__gblt__arg__2_8_0:
 norm__gblt__arg__2_8_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto norm__gblt__arg__2_8_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xcheck__gblt__input_5);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a4;
  allocp[4] = a5;
  allocp[5] = a6;
  allocp[6] = a7;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_klic__comp__insert_xsubsumed__type_3);
  allocp[9] = a3;
  allocp[10] = a1;
  allocp[11] = x0;
  qp = (struct goalrec*)&allocp[7];
  allocp += 12;
  proceed();
 case symval(makesym(atom_no)):
  unify_value(a4, makesym(atom_abnormal));
  allocp[0] = NILATOM;
  allocp[1] = a5;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__kl1cmp_xwarning_4);
  allocp[4] = makefunctor(&string_const_13);
  allocp[5] = x0;
  allocp[6] = a6;
  allocp[7] = a7;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 default:
  goto norm__gblt__arg__2_8_interrupt;
  };
 case VARREF:
  deref_and_jump(a0,norm__gblt__arg__2_8_1);
  *reasonp++ =  a0;
  goto norm__gblt__arg__2_8_interrupt;
  };
  goto norm__gblt__arg__2_8_interrupt;
 norm__gblt__arg__2_8_ext_interrupt:
  reasonp = 0l;
 norm__gblt__arg__2_8_interrupt:
  goto interrupt_8;
 }

 check__gblt__input_5_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 check__gblt__input_5_clear_reason:
  reasonp = reasons;
 check__gblt__input_5_0:
 check__gblt__input_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto check__gblt__input_5_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_normal)):
  unify(a4, a3);
  unify_value(a1, makesym(atom_normal));
  proceed();
 case symval(makesym(atom_abnormal)):
  unify_value(a1, makesym(atom_abnormal));
  allocp[0] = NILATOM;
  allocp[1] = a2;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__kl1cmp_xwarning_4);
  allocp[4] = makefunctor(&string_const_14);
  allocp[5] = x0;
  allocp[6] = a3;
  allocp[7] = a4;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 default:
  goto check__gblt__input_5_interrupt;
  };
 case VARREF:
  deref_and_jump(a0,check__gblt__input_5_1);
  *reasonp++ =  a0;
  goto check__gblt__input_5_interrupt;
  };
  goto check__gblt__input_5_interrupt;
 check__gblt__input_5_ext_interrupt:
  reasonp = 0l;
 check__gblt__input_5_interrupt:
  goto interrupt_5;
 }

 norm__body_6_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 norm__body_6_clear_reason:
  reasonp = reasons;
 norm__body_6_0:
 norm__body_6_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 norm__body_6_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_functor_1)) goto norm__body_6_9;
  x2 = cdr_of(a0);
  allocp[0] = x2;
  allocp[1] = x0;
  x1 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__normalize_xnorm__body__1_9);
  allocp[4] = x1;
  allocp[5] = a1;
  allocp[6] = a2;
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = a3;
  allocp[9] = x4 = makeref(&allocp[9]);
  allocp[10] = x5 = makeref(&allocp[10]);
  allocp[11] = x6 = makeref(&allocp[11]);
  allocp[12] = a5;
  a0 = arg(x0, 0);
  a1 = x4;
  a3 = x3;
  a5 = a4;
  a6 = x6;
  a4 = x5;
  qp = (struct goalrec*)&allocp[2];
  allocp += 13;
  execute(norm__top__goal_7_0);
  goto norm__top__goal_7_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,norm__body_6_3);
  *reasonp++ =  x0;
  goto norm__body_6_9;
  };
  goto norm__body_6_9;
 case ATOMIC:
  if (a0 != NILATOM) goto norm__body_6_9;
  unify(a5, a4);
  unify_value(a1, NILATOM);
  unify_value(a3, makesym(atom_normal));
  proceed();
 case VARREF:
  deref_and_jump(a0,norm__body_6_1);
  *reasonp++ =  a0;
  goto norm__body_6_9;
  };
  goto norm__body_6_9;
 norm__body_6_9:
  otherwise(norm__body_6_interrupt);
  x0 = a2;
  x1 = a3;
  x2 = a4;
  a6 = a5;
  a5 = x2;
  a4 = x1;
  a3 = x0;
  a2 = NILATOM;
  execute(norm__body__tail_7_0);
  goto norm__body__tail_7_ext_interrupt;
 norm__body_6_ext_interrupt:
  reasonp = 0l;
 norm__body_6_interrupt:
  toppred = &predicate_klic__comp__normalize_xnorm__body_6;
  goto interrupt_6;
 }

 norm__body__1_9_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 norm__body__1_9_clear_reason:
  reasonp = reasons;
 norm__body__1_9_0:
 norm__body__1_9_1:
  switch (ptagof(a0)) {
 case CONS:
 norm__body__1_9_3:
  switch (ptagof(a6)) {
 case ATOMIC:
  if (a6 != makesym(atom_normal)) goto norm__body__1_9_7;
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = a5;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a0 = cdr_of(a0);
  a1 = x1;
  a2 = a3;
  a3 = a4;
  a4 = a7;
  a5 = a8;
  execute(norm__body_6_0);
  goto norm__body_6_ext_interrupt;
 case VARREF:
  deref_and_jump(a6,norm__body__1_9_3);
  *reasonp++ =  a6;
  goto norm__body__1_9_7;
  };
  goto norm__body__1_9_7;
 case VARREF:
  deref_and_jump(a0,norm__body__1_9_1);
  *reasonp++ =  a0;
  goto norm__body__1_9_7;
  };
  goto norm__body__1_9_7;
 norm__body__1_9_7:
 norm__body__1_9_8:
  switch (ptagof(a6)) {
 case ATOMIC:
  if (a6 != makesym(atom_abnormal)) goto norm__body__1_9_interrupt;
  a3 = a2;
  a5 = a7;
  a6 = a8;
  a2 = NILATOM;
  execute(norm__body__tail_7_clear_reason);
  goto norm__body__tail_7_ext_interrupt;
 case VARREF:
  deref_and_jump(a6,norm__body__1_9_8);
  *reasonp++ =  a6;
  goto norm__body__1_9_interrupt;
  };
  goto norm__body__1_9_interrupt;
 norm__body__1_9_ext_interrupt:
  reasonp = 0l;
 norm__body__1_9_interrupt:
  goto interrupt_9;
 }

 norm__body__tail_7_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 norm__body__tail_7_clear_reason:
  reasonp = reasons;
 norm__body__tail_7_0:
 norm__body__tail_7_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = a2;
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__normalize_xnorm__body__tail__1_8);
  x2 = cdr_of(a0);
  allocp[4] = x2;
  allocp[5] = a1;
  allocp[6] = x0;
  allocp[7] = x3 = makeref(&allocp[7]);
  allocp[8] = a4;
  allocp[9] = x4 = makeref(&allocp[9]);
  allocp[10] = x5 = makeref(&allocp[10]);
  allocp[11] = a6;
  a0 = car_of(a0);
  a1 = x1;
  a2 = a3;
  a3 = x3;
  a4 = x4;
  a6 = x5;
  qp = (struct goalrec*)&allocp[2];
  allocp += 12;
  execute(norm__tail__goal_7_0);
  goto norm__tail__goal_7_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto norm__body__tail_7_interrupt;
  unify2(a6, a5, a1, a2);
  unify_value(a4, makesym(atom_normal));
  proceed();
 case VARREF:
  deref_and_jump(a0,norm__body__tail_7_1);
  *reasonp++ =  a0;
  goto norm__body__tail_7_interrupt;
  };
  goto norm__body__tail_7_interrupt;
 norm__body__tail_7_ext_interrupt:
  reasonp = 0l;
 norm__body__tail_7_interrupt:
  toppred = &predicate_klic__comp__normalize_xnorm__body__tail_7;
  goto interrupt_7;
 }

 norm__body__tail__1_8_top: {
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 norm__body__tail__1_8_clear_reason:
  reasonp = reasons;
 norm__body__tail__1_8_0:
 norm__body__tail__1_8_1:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (isint(a5)) goto norm__body__tail__1_8_interrupt;
  switch (symval(a5)) {
 case symval(makesym(atom_normal)):
  a5 = a6;
  a6 = a7;
  execute(norm__body__tail_7_0);
  goto norm__body__tail_7_ext_interrupt;
 case symval(makesym(atom_abnormal)):
  unify(a7, a6);
  unify_value(a4, makesym(atom_abnormal));
  proceed();
 default:
  goto norm__body__tail__1_8_interrupt;
  };
 case VARREF:
  deref_and_jump(a5,norm__body__tail__1_8_1);
  *reasonp++ =  a5;
  goto norm__body__tail__1_8_interrupt;
  };
  goto norm__body__tail__1_8_interrupt;
 norm__body__tail__1_8_ext_interrupt:
  reasonp = 0l;
 norm__body__tail__1_8_interrupt:
  goto interrupt_8;
 }

 norm__top__goal_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 norm__top__goal_7_clear_reason:
  reasonp = reasons;
 norm__top__goal_7_0:
 norm__top__goal_7_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor__3D_2:
  allocp[0] = makesym(functor__3D_2);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  x0 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__top__goal__unify_8);
  x3 = arg(a0, 1);
  allocp[2] = x3;
  allocp[3] = x2;
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x5 = makeref(&allocp[7]);
  allocp[8] = x6 = makeref(&allocp[8]);
  allocp[9] = a6;
  a0 = arg(a0, 0);
  a1 = x1;
  a3 = x4;
  a4 = x5;
  a6 = x6;
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  execute(norm__body__arg_7_0);
  goto norm__body__arg_7_ext_interrupt;
 case functor__3A_2:
  x0 = arg(a0, 0);
 norm__top__goal_7_5:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_atom_1)) goto norm__top__goal_7_18;
  x1 = arg(x0, 0);
 norm__top__goal_7_8:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_generic)) goto norm__top__goal_7_18;
  x2 = arg(a0, 1);
 norm__top__goal_7_12:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_functor_1)) goto norm__top__goal_7_18;
  x3 = arg(x2, 0);
 norm__top__goal_7_15:
  switch (ptagof(x3)) {
 case FUNCTOR:
  if (functor_of(x3) != makesym(functor__40_2)) goto norm__top__goal_7_18;
  allocp[0] = makesym(functor__3A_2);
  allocp[1] = makefunctor(funct_const_15);
  x5 = arg(x3, 0);
  allocp[2] = x5;
  x4 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_functor_1);
  allocp[4] = x4;
  x6 = makefunctor(&allocp[3]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_klic__comp__normalize_xnorm__top__goal_7);
  allocp[7] = x6;
  allocp[8] = a1;
  allocp[9] = a2;
  allocp[10] = a3;
  allocp[11] = a4;
  allocp[12] = x7 = makeref(&allocp[12]);
  allocp[13] = a6;
  allocp[14] = makesym(functor__40_2);
  allocp[15] = x5;
  x9 = arg(x3, 1);
  allocp[16] = x9;
  x8 = makefunctor(&allocp[14]);
  allocp[17] = makesym(functor__3A_2);
  allocp[18] = makesym(atom_generic);
  allocp[19] = x8;
  x10 = makefunctor(&allocp[17]);
  allocp[20] = NILATOM;
  allocp[21] = x10;
  x11 = makecons(&allocp[20]);
  allocp[22] = (q)(struct goalrec*)&allocp[5];
  allocp[23] = (q)(&predicate_klic__comp__kl1cmp_xwarning_4);
  allocp[24] = makefunctor(&string_const_16);
  allocp[25] = x11;
  allocp[26] = a5;
  allocp[27] = x7;
  qp = (struct goalrec*)&allocp[22];
  allocp += 28;
  proceed();
 case VARREF:
  deref_and_jump(x3,norm__top__goal_7_15);
  *reasonp++ =  x3;
  goto norm__top__goal_7_18;
  };
  goto norm__top__goal_7_18;
 case VARREF:
  deref_and_jump(x2,norm__top__goal_7_12);
  *reasonp++ =  x2;
  goto norm__top__goal_7_18;
  };
  goto norm__top__goal_7_18;
 case VARREF:
  deref_and_jump(x1,norm__top__goal_7_8);
  *reasonp++ =  x1;
  goto norm__top__goal_7_18;
  };
  goto norm__top__goal_7_18;
 case VARREF:
  deref_and_jump(x0,norm__top__goal_7_5);
  *reasonp++ =  x0;
  goto norm__top__goal_7_18;
  };
  goto norm__top__goal_7_18;
 default:
  goto norm__top__goal_7_18;
  };
 case VARREF:
  deref_and_jump(a0,norm__top__goal_7_1);
  *reasonp++ =  a0;
  goto norm__top__goal_7_18;
  };
  goto norm__top__goal_7_18;
 norm__top__goal_7_18:
  otherwise(norm__top__goal_7_interrupt);
 norm__top__goal_7_20:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor__3A_2)) goto norm__top__goal_7_30;
  x0 = arg(a0, 0);
 norm__top__goal_7_23:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_atom_1)) goto norm__top__goal_7_30;
  x1 = arg(x0, 0);
 norm__top__goal_7_26:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != makesym(atom_generic)) goto norm__top__goal_7_30;
  allocp[0] = makesym(functor_gcall_3);
  allocp[1] = x3 = makeref(&allocp[1]);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = x5 = makeref(&allocp[3]);
  x2 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a1, x2);
  a0 = arg(a0, 1);
  a1 = x3;
  x6 = a2;
  x7 = a3;
  x8 = a4;
  a7 = a5;
  a8 = a6;
  a6 = x8;
  a5 = x7;
  a4 = x6;
  a3 = x5;
  a2 = x4;
  execute(norm__body__args_9_0);
  goto norm__body__args_9_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,norm__top__goal_7_26);
  *reasonp++ =  x1;
  goto norm__top__goal_7_30;
  };
  goto norm__top__goal_7_30;
 case VARREF:
  deref_and_jump(x0,norm__top__goal_7_23);
  *reasonp++ =  x0;
  goto norm__top__goal_7_30;
  };
  goto norm__top__goal_7_30;
 case VARREF:
  deref_and_jump(a0,norm__top__goal_7_20);
  *reasonp++ =  a0;
  goto norm__top__goal_7_30;
  };
  goto norm__top__goal_7_30;
 norm__top__goal_7_30:
  otherwise(norm__top__goal_7_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__top__goal__builtin_7);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = a5;
  allocp[8] = a6;
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_klic__comp__bb_xis__body__builtin_2);
  allocp[11] = a0;
  allocp[12] = x0;
  qp = (struct goalrec*)&allocp[9];
  allocp += 13;
  proceed();
 norm__top__goal_7_32:
  otherwise(norm__top__goal_7_interrupt);
  unify(a6, a5);
  unify_value(a4, makesym(atom_abnormal));
  proceed();
 norm__top__goal_7_ext_interrupt:
  reasonp = 0l;
 norm__top__goal_7_interrupt:
  toppred = &predicate_klic__comp__normalize_xnorm__top__goal_7;
  goto interrupt_7;
 }

 norm__top__goal__unify_8_top: {
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 norm__top__goal__unify_8_clear_reason:
  reasonp = reasons;
 norm__top__goal__unify_8_0:
 norm__top__goal__unify_8_1:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (isint(a5)) goto norm__top__goal__unify_8_interrupt;
  switch (symval(a5)) {
 case symval(makesym(atom_normal)):
  a5 = a6;
  a6 = a7;
  execute(norm__body__arg_7_0);
  goto norm__body__arg_7_ext_interrupt;
 case symval(makesym(atom_abnormal)):
  unify(a7, a6);
  unify_value(a4, makesym(atom_abnormal));
  proceed();
 default:
  goto norm__top__goal__unify_8_interrupt;
  };
 case VARREF:
  deref_and_jump(a5,norm__top__goal__unify_8_1);
  *reasonp++ =  a5;
  goto norm__top__goal__unify_8_interrupt;
  };
  goto norm__top__goal__unify_8_interrupt;
 norm__top__goal__unify_8_ext_interrupt:
  reasonp = 0l;
 norm__top__goal__unify_8_interrupt:
  goto interrupt_8;
 }

 norm__top__goal__builtin_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 norm__top__goal__builtin_7_clear_reason:
  reasonp = reasons;
 norm__top__goal__builtin_7_0:
 norm__top__goal__builtin_7_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_no)) goto norm__top__goal__builtin_7_interrupt;
  unify(a6, a5);
  unify_value(a4, makesym(atom_abnormal));
  proceed();
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_yes_4)) goto norm__top__goal__builtin_7_interrupt;
  allocp[0] = makesym(functor_builtin_5);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  x4 = arg(a0, 2);
  allocp[4] = x4;
  x5 = arg(a0, 3);
  allocp[5] = x5;
  x0 = makefunctor(&allocp[0]);
  allocp += 6;
  unify_value(a1, x0);
  allocp[0] = makesym(functor_functor_1);
  x7 = arg(a0, 0);
  allocp[1] = x7;
  x6 = makefunctor(&allocp[0]);
  a0 = x6;
  a1 = x1;
  x8 = a2;
  x9 = a3;
  x10 = a4;
  a7 = a5;
  a8 = a6;
  a6 = x10;
  a5 = x9;
  a4 = x8;
  a3 = x3;
  a2 = x2;
  allocp += 2;
  execute(norm__body__args_9_0);
  goto norm__body__args_9_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,norm__top__goal__builtin_7_1);
  *reasonp++ =  a0;
  goto norm__top__goal__builtin_7_interrupt;
  };
  goto norm__top__goal__builtin_7_interrupt;
 norm__top__goal__builtin_7_ext_interrupt:
  reasonp = 0l;
 norm__top__goal__builtin_7_interrupt:
  goto interrupt_7;
 }

 norm__tail__goal_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 norm__tail__goal_7_clear_reason:
  reasonp = reasons;
 norm__tail__goal_7_0:
 norm__tail__goal_7_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_functor_1:
  x0 = arg(a0, 0);
 norm__tail__goal_7_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor__3D_2:
  allocp[0] = makesym(functor__3D_2);
  allocp[1] = x2 = makeref(&allocp[1]);
  allocp[2] = x3 = makeref(&allocp[2]);
  x1 = makefunctor(&allocp[0]);
  allocp += 3;
  unify_value(a1, x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__tail__goal__unify_8);
  x4 = arg(x0, 1);
  allocp[2] = x4;
  allocp[3] = x3;
  allocp[4] = x5 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x6 = makeref(&allocp[7]);
  allocp[8] = x7 = makeref(&allocp[8]);
  allocp[9] = a6;
  a0 = arg(x0, 0);
  a1 = x2;
  a3 = x5;
  a4 = x6;
  a6 = x7;
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  execute(norm__body__arg_7_0);
  goto norm__body__arg_7_ext_interrupt;
 case functor__3A_2:
  x1 = arg(x0, 0);
 norm__tail__goal_7_8:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_atom_1)) goto norm__tail__goal_7_26;
  x2 = arg(x1, 0);
 norm__tail__goal_7_11:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != makesym(atom_generic)) goto norm__tail__goal_7_26;
  x3 = arg(x0, 1);
 norm__tail__goal_7_15:
  switch (ptagof(x3)) {
 case FUNCTOR:
  if (functor_of(x3) != makesym(functor_functor_1)) goto norm__tail__goal_7_26;
  x4 = arg(x3, 0);
 norm__tail__goal_7_18:
  switch (ptagof(x4)) {
 case FUNCTOR:
  if (functor_of(x4) != makesym(functor__40_2)) goto norm__tail__goal_7_26;
  allocp[0] = makesym(functor__3A_2);
  allocp[1] = makefunctor(funct_const_15);
  x6 = arg(x4, 0);
  allocp[2] = x6;
  x5 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_functor_1);
  allocp[4] = x5;
  x7 = makefunctor(&allocp[3]);
  allocp[5] = (q)qp;
  allocp[6] = (q)(&predicate_klic__comp__normalize_xnorm__tail__goal_7);
  allocp[7] = x7;
  allocp[8] = a1;
  allocp[9] = a2;
  allocp[10] = a3;
  allocp[11] = a4;
  allocp[12] = x8 = makeref(&allocp[12]);
  allocp[13] = a6;
  allocp[14] = makesym(functor__40_2);
  allocp[15] = x6;
  x10 = arg(x4, 1);
  allocp[16] = x10;
  x9 = makefunctor(&allocp[14]);
  allocp[17] = makesym(functor__3A_2);
  allocp[18] = makesym(atom_generic);
  allocp[19] = x9;
  x11 = makefunctor(&allocp[17]);
  allocp[20] = NILATOM;
  allocp[21] = x11;
  x12 = makecons(&allocp[20]);
  allocp[22] = (q)(struct goalrec*)&allocp[5];
  allocp[23] = (q)(&predicate_klic__comp__kl1cmp_xwarning_4);
  allocp[24] = makefunctor(&string_const_16);
  allocp[25] = x12;
  allocp[26] = a5;
  allocp[27] = x8;
  qp = (struct goalrec*)&allocp[22];
  allocp += 28;
  proceed();
 case VARREF:
  deref_and_jump(x4,norm__tail__goal_7_18);
  *reasonp++ =  x4;
  goto norm__tail__goal_7_26;
  };
  goto norm__tail__goal_7_26;
 case VARREF:
  deref_and_jump(x3,norm__tail__goal_7_15);
  *reasonp++ =  x3;
  goto norm__tail__goal_7_26;
  };
  goto norm__tail__goal_7_26;
 case VARREF:
  deref_and_jump(x2,norm__tail__goal_7_11);
  *reasonp++ =  x2;
  goto norm__tail__goal_7_26;
  };
  goto norm__tail__goal_7_26;
 case VARREF:
  deref_and_jump(x1,norm__tail__goal_7_8);
  *reasonp++ =  x1;
  goto norm__tail__goal_7_26;
  };
  goto norm__tail__goal_7_26;
 default:
  goto norm__tail__goal_7_26;
  };
 case VARREF:
  deref_and_jump(x0,norm__tail__goal_7_4);
  *reasonp++ =  x0;
  goto norm__tail__goal_7_26;
  };
  goto norm__tail__goal_7_26;
 case functor__24macroexpanded_2:
  x0 = arg(a0, 1);
 norm__tail__goal_7_22:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != NILATOM) goto norm__tail__goal_7_26;
  allocp[0] = makesym(functor_atom_1);
  x2 = arg(a0, 0);
  allocp[1] = x2;
  x1 = makefunctor(&allocp[0]);
  a0 = x1;
  allocp += 2;
  execute(norm__tail__goal_7_0);
  goto norm__tail__goal_7_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,norm__tail__goal_7_22);
  *reasonp++ =  x0;
  goto norm__tail__goal_7_26;
  };
  goto norm__tail__goal_7_26;
 default:
  goto norm__tail__goal_7_26;
  };
 case VARREF:
  deref_and_jump(a0,norm__tail__goal_7_1);
  *reasonp++ =  a0;
  goto norm__tail__goal_7_26;
  };
  goto norm__tail__goal_7_26;
 norm__tail__goal_7_26:
  otherwise(norm__tail__goal_7_interrupt);
 norm__tail__goal_7_28:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor__24macroexpanded_2:
  allocp[0] = makesym(functor_functor_1);
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makefunctor(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__normalize_xnorm__tail__goal_7);
  allocp[4] = x0;
  allocp[5] = a1;
  allocp[6] = a2;
  allocp[7] = a3;
  allocp[8] = a4;
  allocp[9] = a5;
  allocp[10] = a6;
  x3 = arg(a0, 1);
  allocp[11] = x3;
  x4 = arg(a0, 0);
  allocp[12] = x4;
  x2 = makecons(&allocp[11]);
  allocp[13] = (q)(struct goalrec*)&allocp[2];
  allocp[14] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[15] = x1;
  allocp[16] = x2;
  qp = (struct goalrec*)&allocp[13];
  allocp += 17;
  proceed();
 case functor_functor_1:
  x0 = arg(a0, 0);
 norm__tail__goal_7_32:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__3A_2)) goto norm__tail__goal_7_46;
  x1 = arg(x0, 0);
 norm__tail__goal_7_35:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_atom_1)) goto norm__tail__goal_7_46;
  x2 = arg(x1, 0);
 norm__tail__goal_7_38:
  switch (ptagof(x2)) {
 case ATOMIC:
  if (x2 != makesym(atom_generic)) goto norm__tail__goal_7_46;
  x3 = arg(x0, 1);
 norm__tail__goal_7_42:
  switch (ptagof(x3)) {
 case FUNCTOR:
  switch (symval(functor_of(x3))) {
 case functor_functor_1:
  allocp[0] = makesym(functor_functor_1);
  x5 = arg(x3, 0);
  allocp[1] = x5;
  x4 = makefunctor(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__normalize_xnorm__tail__goal__generic_9);
  allocp[4] = x4;
  allocp[5] = a1;
  allocp[6] = a2;
  allocp[7] = a3;
  allocp[8] = a4;
  allocp[9] = x6 = makeref(&allocp[9]);
  allocp[10] = x7 = makeref(&allocp[10]);
  allocp[11] = a5;
  allocp[12] = a6;
  allocp[13] = x7;
  allocp[14] = x6;
  x8 = makecons(&allocp[13]);
  allocp[15] = (q)(struct goalrec*)&allocp[2];
  allocp[16] = (q)(&predicate_klic__comp__util_xuniv_2);
  allocp[17] = x5;
  allocp[18] = x8;
  qp = (struct goalrec*)&allocp[15];
  allocp += 19;
  proceed();
 case functor_atom_1:
  allocp[0] = makesym(functor_atom_1);
  x5 = arg(x3, 0);
  allocp[1] = x5;
  x4 = makefunctor(&allocp[0]);
  a0 = x4;
  a7 = a5;
  a8 = a6;
  a6 = NILATOM;
  a5 = x5;
  allocp += 2;
  execute(norm__tail__goal__generic_9_0);
  goto norm__tail__goal__generic_9_ext_interrupt;
 default:
  goto norm__tail__goal_7_46;
  };
 case VARREF:
  deref_and_jump(x3,norm__tail__goal_7_42);
  *reasonp++ =  x3;
  goto norm__tail__goal_7_46;
  };
  goto norm__tail__goal_7_46;
 case VARREF:
  deref_and_jump(x2,norm__tail__goal_7_38);
  *reasonp++ =  x2;
  goto norm__tail__goal_7_46;
  };
  goto norm__tail__goal_7_46;
 case VARREF:
  deref_and_jump(x1,norm__tail__goal_7_35);
  *reasonp++ =  x1;
  goto norm__tail__goal_7_46;
  };
  goto norm__tail__goal_7_46;
 case VARREF:
  deref_and_jump(x0,norm__tail__goal_7_32);
  *reasonp++ =  x0;
  goto norm__tail__goal_7_46;
  };
  goto norm__tail__goal_7_46;
 default:
  goto norm__tail__goal_7_46;
  };
 case VARREF:
  deref_and_jump(a0,norm__tail__goal_7_28);
  *reasonp++ =  a0;
  goto norm__tail__goal_7_46;
  };
  goto norm__tail__goal_7_46;
 norm__tail__goal_7_46:
  otherwise(norm__tail__goal_7_interrupt);
 norm__tail__goal_7_48:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_functor_1)) goto norm__tail__goal_7_63;
  x0 = arg(a0, 0);
 norm__tail__goal_7_51:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__3A_2)) goto norm__tail__goal_7_63;
  x1 = arg(x0, 0);
 norm__tail__goal_7_54:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_atom_1)) goto norm__tail__goal_7_63;
  x2 = arg(x0, 1);
 norm__tail__goal_7_57:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor_functor_1)) goto norm__tail__goal_7_63;
  x3 = arg(x2, 0);
 norm__tail__goal_7_60:
  switch (ptagof(x3)) {
 case FUNCTOR:
  if (functor_of(x3) != makesym(functor__40_2)) goto norm__tail__goal_7_63;
  allocp[0] = makesym(functor_atom_1);
  x5 = arg(x1, 0);
  allocp[1] = x5;
  x4 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__3A_2);
  allocp[3] = x4;
  x7 = arg(x3, 0);
  allocp[4] = x7;
  x6 = makefunctor(&allocp[2]);
  allocp[5] = makesym(functor_functor_1);
  allocp[6] = x6;
  x8 = makefunctor(&allocp[5]);
  a0 = x8;
  x9 = arg(x3, 1);
  x10 = a4;
  x11 = a5;
  a7 = a6;
  a6 = x11;
  a5 = x10;
  a4 = x9;
  allocp += 7;
  execute(norm__pragma_8_0);
  goto norm__pragma_8_ext_interrupt;
 case VARREF:
  deref_and_jump(x3,norm__tail__goal_7_60);
  *reasonp++ =  x3;
  goto norm__tail__goal_7_63;
  };
  goto norm__tail__goal_7_63;
 case VARREF:
  deref_and_jump(x2,norm__tail__goal_7_57);
  *reasonp++ =  x2;
  goto norm__tail__goal_7_63;
  };
  goto norm__tail__goal_7_63;
 case VARREF:
  deref_and_jump(x1,norm__tail__goal_7_54);
  *reasonp++ =  x1;
  goto norm__tail__goal_7_63;
  };
  goto norm__tail__goal_7_63;
 case VARREF:
  deref_and_jump(x0,norm__tail__goal_7_51);
  *reasonp++ =  x0;
  goto norm__tail__goal_7_63;
  };
  goto norm__tail__goal_7_63;
 case VARREF:
  deref_and_jump(a0,norm__tail__goal_7_48);
  *reasonp++ =  a0;
  goto norm__tail__goal_7_63;
  };
  goto norm__tail__goal_7_63;
 norm__tail__goal_7_63:
  otherwise(norm__tail__goal_7_interrupt);
 norm__tail__goal_7_65:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_functor_1)) goto norm__tail__goal_7_75;
  x0 = arg(a0, 0);
 norm__tail__goal_7_68:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor__3A_2:
  x1 = arg(x0, 0);
 norm__tail__goal_7_71:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_atom_1)) goto norm__tail__goal_7_75;
  allocp[0] = makesym(functor_xcall_4);
  x3 = arg(x1, 0);
  allocp[1] = x3;
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = x6 = makeref(&allocp[4]);
  x2 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a1, x2);
  a0 = arg(x0, 1);
  a1 = x4;
  x7 = a2;
  x8 = a3;
  x9 = a4;
  a7 = a5;
  a8 = a6;
  a6 = x9;
  a5 = x8;
  a4 = x7;
  a3 = x6;
  a2 = x5;
  execute(norm__body__args_9_0);
  goto norm__body__args_9_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,norm__tail__goal_7_71);
  *reasonp++ =  x1;
  goto norm__tail__goal_7_75;
  };
  goto norm__tail__goal_7_75;
 case functor__40_2:
  a0 = arg(x0, 0);
  x1 = arg(x0, 1);
  x2 = a4;
  x3 = a5;
  a7 = a6;
  a6 = x3;
  a5 = x2;
  a4 = x1;
  execute(norm__pragma_8_0);
  goto norm__pragma_8_ext_interrupt;
 default:
  goto norm__tail__goal_7_75;
  };
 case VARREF:
  deref_and_jump(x0,norm__tail__goal_7_68);
  *reasonp++ =  x0;
  goto norm__tail__goal_7_75;
  };
  goto norm__tail__goal_7_75;
 case VARREF:
  deref_and_jump(a0,norm__tail__goal_7_65);
  *reasonp++ =  a0;
  goto norm__tail__goal_7_75;
  };
  goto norm__tail__goal_7_75;
 norm__tail__goal_7_75:
  otherwise(norm__tail__goal_7_interrupt);
 norm__tail__goal_7_77:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_functor_1)) goto norm__tail__goal_7_80;
  allocp[0] = makesym(functor_functor_1);
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__normalize_xnorm__tail__goal__builtin_8);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = x0;
  allocp[6] = a1;
  allocp[7] = a2;
  allocp[8] = a3;
  allocp[9] = a4;
  allocp[10] = a5;
  allocp[11] = a6;
  allocp[12] = (q)(struct goalrec*)&allocp[2];
  allocp[13] = (q)(&predicate_klic__comp__bb_xis__body__builtin_2);
  allocp[14] = x1;
  allocp[15] = x2;
  qp = (struct goalrec*)&allocp[12];
  allocp += 16;
  proceed();
 case VARREF:
  deref_and_jump(a0,norm__tail__goal_7_77);
  *reasonp++ =  a0;
  goto norm__tail__goal_7_80;
  };
  goto norm__tail__goal_7_80;
 norm__tail__goal_7_80:
  otherwise(norm__tail__goal_7_interrupt);
  allocp[0] = makesym(functor_call_3);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a1, x0);
  a1 = x1;
  x4 = a2;
  x5 = a3;
  x6 = a4;
  a7 = a5;
  a8 = a6;
  a6 = x6;
  a5 = x5;
  a4 = x4;
  a3 = x3;
  a2 = x2;
  execute(norm__body__args_9_0);
  goto norm__body__args_9_ext_interrupt;
 norm__tail__goal_7_ext_interrupt:
  reasonp = 0l;
 norm__tail__goal_7_interrupt:
  toppred = &predicate_klic__comp__normalize_xnorm__tail__goal_7;
  goto interrupt_7;
 }

 norm__tail__goal__unify_8_top: {
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 norm__tail__goal__unify_8_clear_reason:
  reasonp = reasons;
 norm__tail__goal__unify_8_0:
 norm__tail__goal__unify_8_1:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (isint(a5)) goto norm__tail__goal__unify_8_interrupt;
  switch (symval(a5)) {
 case symval(makesym(atom_normal)):
  a5 = a6;
  a6 = a7;
  execute(norm__body__arg_7_0);
  goto norm__body__arg_7_ext_interrupt;
 case symval(makesym(atom_abnormal)):
  unify(a7, a6);
  unify_value(a4, makesym(atom_abnormal));
  proceed();
 default:
  goto norm__tail__goal__unify_8_interrupt;
  };
 case VARREF:
  deref_and_jump(a5,norm__tail__goal__unify_8_1);
  *reasonp++ =  a5;
  goto norm__tail__goal__unify_8_interrupt;
  };
  goto norm__tail__goal__unify_8_interrupt;
 norm__tail__goal__unify_8_ext_interrupt:
  reasonp = 0l;
 norm__tail__goal__unify_8_interrupt:
  goto interrupt_8;
 }

 norm__tail__goal__generic_9_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 norm__tail__goal__generic_9_clear_reason:
  reasonp = reasons;
 norm__tail__goal__generic_9_0:
 norm__tail__goal__generic_9_1:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (isint(a5)) goto norm__tail__goal__generic_9_14;
  switch (symval(a5)) {
 case symval(makesym(atom_new)):
  allocp[0] = makesym(functor_gcall_3);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a1, x0);
  a1 = x1;
  x4 = a2;
  a5 = a3;
  a6 = a4;
  a4 = x4;
  a3 = x3;
  a2 = x2;
  execute(norm__body__args_9_0);
  goto norm__body__args_9_ext_interrupt;
 case symval(makesym(atom_generic)):
 norm__tail__goal__generic_9_6:
  switch (ptagof(a6)) {
 case CONS:
  x0 = cdr_of(a6);
 norm__tail__goal__generic_9_8:
  switch (ptagof(x0)) {
 case CONS:
  x1 = cdr_of(x0);
 norm__tail__goal__generic_9_10:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto norm__tail__goal__generic_9_14;
  allocp[0] = NILATOM;
  allocp[1] = x3 = makeref(&allocp[1]);
  x2 = makecons(&allocp[0]);
  allocp[2] = x2;
  allocp[3] = x5 = makeref(&allocp[3]);
  x4 = makecons(&allocp[2]);
  allocp[4] = makesym(functor_xcall_4);
  allocp[5] = makesym(atom_generic);
  allocp[6] = makesym(atom_generic);
  allocp[7] = makeint(2L);
  allocp[8] = x4;
  x6 = makefunctor(&allocp[4]);
  allocp += 9;
  unify_value(a1, x6);
  allocp[0] = NILATOM;
  allocp[1] = x5;
  x7 = makecons(&allocp[0]);
  allocp[2] = x7;
  allocp[3] = x3;
  x8 = makecons(&allocp[2]);
  allocp[4] = x9 = makeref(&allocp[4]);
  a1 = x9;
  allocp[5] = x11 = makeref(&allocp[5]);
  x10 = x11;
  x12 = a2;
  a5 = a3;
  a6 = a4;
  a4 = x12;
  a3 = x8;
  a2 = x10;
  allocp += 6;
  execute(norm__body__args_9_0);
  goto norm__body__args_9_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,norm__tail__goal__generic_9_10);
  *reasonp++ =  x1;
  goto norm__tail__goal__generic_9_14;
  };
  goto norm__tail__goal__generic_9_14;
 case VARREF:
  deref_and_jump(x0,norm__tail__goal__generic_9_8);
  *reasonp++ =  x0;
  goto norm__tail__goal__generic_9_14;
  };
  goto norm__tail__goal__generic_9_14;
 case VARREF:
  deref_and_jump(a6,norm__tail__goal__generic_9_6);
  *reasonp++ =  a6;
  goto norm__tail__goal__generic_9_14;
  };
  goto norm__tail__goal__generic_9_14;
 default:
  goto norm__tail__goal__generic_9_14;
  };
 case VARREF:
  deref_and_jump(a5,norm__tail__goal__generic_9_1);
  *reasonp++ =  a5;
  goto norm__tail__goal__generic_9_14;
  };
  goto norm__tail__goal__generic_9_14;
 norm__tail__goal__generic_9_14:
  otherwise(norm__tail__goal__generic_9_interrupt);
 norm__tail__goal__generic_9_16:
  switch (ptagof(a6)) {
 case CONS:
  x0 = cdr_of(a6);
 norm__tail__goal__generic_9_18:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != NILATOM) goto norm__tail__goal__generic_9_22;
  allocp[0] = makesym(functor_xcall_4);
  allocp[1] = makesym(atom_generic);
  allocp[2] = makesym(atom_generic);
  allocp[3] = makeint(2L);
  allocp[4] = x2 = makeref(&allocp[4]);
  x1 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a1, x1);
  allocp[0] = makesym(functor_atom_1);
  allocp[1] = a5;
  x3 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__24_2);
  allocp[3] = x3;
  x5 = car_of(a6);
  allocp[4] = x5;
  x4 = makefunctor(&allocp[2]);
  allocp[5] = makesym(functor_functor_1);
  allocp[6] = x4;
  x6 = makefunctor(&allocp[5]);
  a0 = x6;
  allocp[7] = x7 = makeref(&allocp[7]);
  a1 = x7;
  allocp[8] = x9 = makeref(&allocp[8]);
  x8 = x9;
  x10 = a2;
  a5 = a3;
  a6 = a4;
  a4 = x10;
  a3 = x2;
  a2 = x8;
  allocp += 9;
  execute(norm__body__args_9_0);
  goto norm__body__args_9_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,norm__tail__goal__generic_9_18);
  *reasonp++ =  x0;
  goto norm__tail__goal__generic_9_22;
  };
  goto norm__tail__goal__generic_9_22;
 case VARREF:
  deref_and_jump(a6,norm__tail__goal__generic_9_16);
  *reasonp++ =  a6;
  goto norm__tail__goal__generic_9_22;
  };
  goto norm__tail__goal__generic_9_22;
 norm__tail__goal__generic_9_22:
  otherwise(norm__tail__goal__generic_9_interrupt);
 norm__tail__goal__generic_9_24:
  switch (ptagof(a6)) {
 case CONS:
  allocp[0] = makesym(functor_xcall_4);
  allocp[1] = makesym(atom_generic);
  allocp[2] = makesym(atom_generic);
  allocp[3] = makeint(2L);
  allocp[4] = x1 = makeref(&allocp[4]);
  x0 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a1, x0);
  allocp[0] = makesym(functor_functor_1);
  allocp[1] = x3 = makeref(&allocp[1]);
  x2 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__24_2);
  allocp[3] = x2;
  x5 = car_of(a6);
  allocp[4] = x5;
  x4 = makefunctor(&allocp[2]);
  allocp[5] = makesym(functor_functor_1);
  allocp[6] = x4;
  x6 = makefunctor(&allocp[5]);
  allocp[7] = (q)qp;
  allocp[8] = (q)(&predicate_klic__comp__normalize_xnorm__body__args_9);
  allocp[9] = x6;
  allocp[10] = x7 = makeref(&allocp[10]);
  allocp[11] = x8 = makeref(&allocp[11]);
  allocp[12] = x1;
  allocp[13] = a2;
  allocp[14] = a3;
  allocp[15] = a4;
  allocp[16] = a7;
  allocp[17] = a8;
  x10 = cdr_of(a6);
  allocp[18] = x10;
  allocp[19] = a5;
  x9 = makecons(&allocp[18]);
  allocp[20] = (q)(struct goalrec*)&allocp[7];
  allocp[21] = (q)(&predicate_functor__table_x_3D_2E_2E_2);
  allocp[22] = x3;
  allocp[23] = x9;
  qp = (struct goalrec*)&allocp[20];
  allocp += 24;
  proceed();
 case VARREF:
  deref_and_jump(a6,norm__tail__goal__generic_9_24);
  *reasonp++ =  a6;
  goto norm__tail__goal__generic_9_interrupt;
  };
  goto norm__tail__goal__generic_9_interrupt;
 norm__tail__goal__generic_9_ext_interrupt:
  reasonp = 0l;
 norm__tail__goal__generic_9_interrupt:
  toppred = &predicate_klic__comp__normalize_xnorm__tail__goal__generic_9;
  goto interrupt_9;
 }

 norm__tail__goal__builtin_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 norm__tail__goal__builtin_8_clear_reason:
  reasonp = reasons;
 norm__tail__goal__builtin_8_0:
 norm__tail__goal__builtin_8_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_no)) goto norm__tail__goal__builtin_8_interrupt;
  allocp[0] = makesym(functor_call_3);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  x0 = makefunctor(&allocp[0]);
  allocp += 4;
  unify_value(a2, x0);
  a0 = a1;
  a1 = x1;
  a2 = x2;
  x4 = a3;
  x5 = a4;
  x6 = a5;
  x7 = a6;
  a8 = a7;
  a7 = x7;
  a6 = x6;
  a5 = x5;
  a4 = x4;
  a3 = x3;
  execute(norm__body__args_9_0);
  goto norm__body__args_9_ext_interrupt;
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_yes_4)) goto norm__tail__goal__builtin_8_interrupt;
  allocp[0] = makesym(functor_xcall_4);
  x1 = arg(a0, 1);
  allocp[1] = x1;
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  x0 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a2, x0);
  a0 = a1;
  a1 = x2;
  a2 = x3;
  x5 = a3;
  x6 = a4;
  x7 = a5;
  x8 = a6;
  a8 = a7;
  a7 = x8;
  a6 = x7;
  a5 = x6;
  a4 = x5;
  a3 = x4;
  execute(norm__body__args_9_0);
  goto norm__body__args_9_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,norm__tail__goal__builtin_8_1);
  *reasonp++ =  a0;
  goto norm__tail__goal__builtin_8_interrupt;
  };
  goto norm__tail__goal__builtin_8_interrupt;
 norm__tail__goal__builtin_8_ext_interrupt:
  reasonp = 0l;
 norm__tail__goal__builtin_8_interrupt:
  goto interrupt_8;
 }

 norm__pragma_8_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 norm__pragma_8_clear_reason:
  reasonp = reasons;
 norm__pragma_8_0:
 norm__pragma_8_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_functor_1:
  allocp[0] = makesym(functor_functor_1);
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__normalize_xnorm__pragma__0_9);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = x0;
  allocp[6] = a1;
  allocp[7] = a2;
  allocp[8] = a3;
  allocp[9] = a4;
  allocp[10] = a5;
  allocp[11] = a6;
  allocp[12] = a7;
  allocp[13] = (q)(struct goalrec*)&allocp[2];
  allocp[14] = (q)(&predicate_klic__comp__bb_xis__body__builtin_2);
  allocp[15] = x1;
  allocp[16] = x2;
  qp = (struct goalrec*)&allocp[13];
  allocp += 17;
  proceed();
 case functor_atom_1:
  allocp[0] = makesym(functor_atom_1);
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__normalize_xnorm__pragma__0_9);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = x0;
  allocp[6] = a1;
  allocp[7] = a2;
  allocp[8] = a3;
  allocp[9] = a4;
  allocp[10] = a5;
  allocp[11] = a6;
  allocp[12] = a7;
  allocp[13] = (q)(struct goalrec*)&allocp[2];
  allocp[14] = (q)(&predicate_klic__comp__bb_xis__body__builtin_2);
  allocp[15] = x1;
  allocp[16] = x2;
  qp = (struct goalrec*)&allocp[13];
  allocp += 17;
  proceed();
 default:
  goto norm__pragma_8_interrupt;
  };
 case VARREF:
  deref_and_jump(a0,norm__pragma_8_1);
  *reasonp++ =  a0;
  goto norm__pragma_8_interrupt;
  };
  goto norm__pragma_8_interrupt;
 norm__pragma_8_ext_interrupt:
  reasonp = 0l;
 norm__pragma_8_interrupt:
  toppred = &predicate_klic__comp__normalize_xnorm__pragma_8;
  goto interrupt_8;
 }

 norm__pragma__0_9_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 norm__pragma__0_9_clear_reason:
  reasonp = reasons;
 norm__pragma__0_9_0:
 norm__pragma__0_9_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_no)) goto norm__pragma__0_9_interrupt;
  a0 = a1;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  a5 = a6;
  a6 = a7;
  a7 = a8;
  execute(norm__pragma__1_8_0);
  goto norm__pragma__1_8_ext_interrupt;
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_yes_4)) goto norm__pragma__0_9_interrupt;
  allocp[0] = makesym(functor_atom_1);
  x1 = arg(a0, 1);
  allocp[1] = x1;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__3A_2);
  allocp[3] = x0;
  allocp[4] = a1;
  x2 = makefunctor(&allocp[2]);
  allocp[5] = makesym(functor_functor_1);
  allocp[6] = x2;
  x3 = makefunctor(&allocp[5]);
  a0 = x3;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  a4 = a5;
  a5 = a6;
  a6 = a7;
  a7 = a8;
  allocp += 7;
  execute(norm__pragma__1_8_0);
  goto norm__pragma__1_8_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,norm__pragma__0_9_1);
  *reasonp++ =  a0;
  goto norm__pragma__0_9_interrupt;
  };
  goto norm__pragma__0_9_interrupt;
 norm__pragma__0_9_ext_interrupt:
  reasonp = 0l;
 norm__pragma__0_9_interrupt:
  goto interrupt_9;
 }

 norm__pragma__1_8_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 norm__pragma__1_8_clear_reason:
  reasonp = reasons;
 norm__pragma__1_8_0:
 norm__pragma__1_8_1:
  switch (ptagof(a4)) {
 case FUNCTOR:
  switch (symval(functor_of(a4))) {
 case functor_atom_1:
  x0 = arg(a4, 0);
 norm__pragma__1_8_4:
  switch (ptagof(x0)) {
 case ATOMIC:
  if (x0 != makesym(atom_lower__priority)) goto norm__pragma__1_8_14;
  a4 = makefunctor(funct_const_19);
  execute(norm__pragma__1_8_0);
  goto norm__pragma__1_8_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,norm__pragma__1_8_4);
  *reasonp++ =  x0;
  goto norm__pragma__1_8_14;
  };
  goto norm__pragma__1_8_14;
 case functor_functor_1:
  x0 = arg(a4, 0);
 norm__pragma__1_8_9:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_priority_1:
  a4 = arg(x0, 0);
  execute(norm__pragma__priority_8_0);
  goto norm__pragma__priority_8_ext_interrupt;
 case functor_lower__priority_1:
  a4 = arg(x0, 0);
  execute(norm__pragma__lower__priority_8_0);
  goto norm__pragma__lower__priority_8_ext_interrupt;
 case functor_node_1:
  a4 = arg(x0, 0);
  execute(norm__pragma__node_8_0);
  goto norm__pragma__node_8_ext_interrupt;
 default:
  goto norm__pragma__1_8_14;
  };
 case VARREF:
  deref_and_jump(x0,norm__pragma__1_8_9);
  *reasonp++ =  x0;
  goto norm__pragma__1_8_14;
  };
  goto norm__pragma__1_8_14;
 default:
  goto norm__pragma__1_8_14;
  };
 case VARREF:
  deref_and_jump(a4,norm__pragma__1_8_1);
  *reasonp++ =  a4;
  goto norm__pragma__1_8_14;
  };
  goto norm__pragma__1_8_14;
 norm__pragma__1_8_14:
  otherwise(norm__pragma__1_8_interrupt);
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a4;
  x1 = makecons(&allocp[2]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_klic__comp__kl1cmp_xreport__error_4);
  allocp[6] = makefunctor(&string_const_20);
  allocp[7] = x1;
  allocp[8] = a6;
  allocp[9] = a7;
  qp = (struct goalrec*)&allocp[4];
  allocp += 10;
  proceed();
 norm__pragma__1_8_ext_interrupt:
  reasonp = 0l;
 norm__pragma__1_8_interrupt:
  toppred = &predicate_klic__comp__normalize_xnorm__pragma__1_8;
  goto interrupt_8;
 }

 norm__pragma__priority_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 norm__pragma__priority_8_clear_reason:
  reasonp = reasons;
 norm__pragma__priority_8_0:
 norm__pragma__priority_8_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_functor_1:
  x0 = arg(a0, 0);
 norm__pragma__priority_8_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__3A_2)) goto norm__pragma__priority_8_11;
  x1 = arg(x0, 0);
 norm__pragma__priority_8_7:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_atom_1)) goto norm__pragma__priority_8_11;
  allocp[0] = makesym(functor_xpcall_5);
  allocp[1] = x3 = makeref(&allocp[1]);
  x4 = arg(x1, 0);
  allocp[2] = x4;
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = x6 = makeref(&allocp[4]);
  allocp[5] = x7 = makeref(&allocp[5]);
  x2 = makefunctor(&allocp[0]);
  allocp += 6;
  unify_value(a1, x2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__pragma__pragma__arg_8);
  allocp[2] = a4;
  allocp[3] = x3;
  allocp[4] = x8 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a5;
  allocp[7] = x9 = makeref(&allocp[7]);
  allocp[8] = x10 = makeref(&allocp[8]);
  allocp[9] = a7;
  a0 = arg(x0, 1);
  a1 = x5;
  a3 = x7;
  a4 = a2;
  a5 = x8;
  a7 = a6;
  a8 = x10;
  a6 = x9;
  a2 = x6;
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  execute(norm__body__args_9_0);
  goto norm__body__args_9_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,norm__pragma__priority_8_7);
  *reasonp++ =  x1;
  goto norm__pragma__priority_8_11;
  };
  goto norm__pragma__priority_8_11;
 case VARREF:
  deref_and_jump(x0,norm__pragma__priority_8_4);
  *reasonp++ =  x0;
  goto norm__pragma__priority_8_11;
  };
  goto norm__pragma__priority_8_11;
 case functor_atom_1:
  allocp[0] = makesym(functor_pcall_4);
  allocp[1] = x1 = makeref(&allocp[1]);
  x2 = arg(a0, 0);
  allocp[2] = x2;
  allocp[3] = makeint(0L);
  allocp[4] = NILATOM;
  x0 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a1, x0);
  a0 = a4;
  a1 = x1;
  a4 = a5;
  a5 = makesym(atom_normal);
  execute(norm__pragma__pragma__arg_8_0);
  goto norm__pragma__pragma__arg_8_ext_interrupt;
 default:
  goto norm__pragma__priority_8_11;
  };
 case VARREF:
  deref_and_jump(a0,norm__pragma__priority_8_1);
  *reasonp++ =  a0;
  goto norm__pragma__priority_8_11;
  };
  goto norm__pragma__priority_8_11;
 norm__pragma__priority_8_11:
  otherwise(norm__pragma__priority_8_interrupt);
 norm__pragma__priority_8_13:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_functor_1)) goto norm__pragma__priority_8_interrupt;
  allocp[0] = makesym(functor_pcall_4);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  x0 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__pragma__pragma__arg_8);
  allocp[2] = a4;
  allocp[3] = x1;
  allocp[4] = x5 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a5;
  allocp[7] = x6 = makeref(&allocp[7]);
  allocp[8] = x7 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = makesym(functor_functor_1);
  x9 = arg(a0, 0);
  allocp[11] = x9;
  x8 = makefunctor(&allocp[10]);
  a0 = x8;
  a1 = x2;
  a3 = x4;
  a4 = a2;
  a5 = x5;
  a7 = a6;
  a8 = x7;
  a6 = x6;
  a2 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  execute(norm__body__args_9_0);
  goto norm__body__args_9_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,norm__pragma__priority_8_13);
  *reasonp++ =  a0;
  goto norm__pragma__priority_8_interrupt;
  };
  goto norm__pragma__priority_8_interrupt;
 norm__pragma__priority_8_ext_interrupt:
  reasonp = 0l;
 norm__pragma__priority_8_interrupt:
  toppred = &predicate_klic__comp__normalize_xnorm__pragma__priority_8;
  goto interrupt_8;
 }

 norm__pragma__lower__priority_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 norm__pragma__lower__priority_8_clear_reason:
  reasonp = reasons;
 norm__pragma__lower__priority_8_0:
 norm__pragma__lower__priority_8_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_functor_1:
  x0 = arg(a0, 0);
 norm__pragma__lower__priority_8_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__3A_2)) goto norm__pragma__lower__priority_8_11;
  x1 = arg(x0, 0);
 norm__pragma__lower__priority_8_7:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_atom_1)) goto norm__pragma__lower__priority_8_11;
  allocp[0] = makesym(functor_xlcall_5);
  allocp[1] = x3 = makeref(&allocp[1]);
  x4 = arg(x1, 0);
  allocp[2] = x4;
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = x6 = makeref(&allocp[4]);
  allocp[5] = x7 = makeref(&allocp[5]);
  x2 = makefunctor(&allocp[0]);
  allocp += 6;
  unify_value(a1, x2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__pragma__pragma__arg_8);
  allocp[2] = a4;
  allocp[3] = x3;
  allocp[4] = x8 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a5;
  allocp[7] = x9 = makeref(&allocp[7]);
  allocp[8] = x10 = makeref(&allocp[8]);
  allocp[9] = a7;
  a0 = arg(x0, 1);
  a1 = x5;
  a3 = x7;
  a4 = a2;
  a5 = x8;
  a7 = a6;
  a8 = x10;
  a6 = x9;
  a2 = x6;
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  execute(norm__body__args_9_0);
  goto norm__body__args_9_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,norm__pragma__lower__priority_8_7);
  *reasonp++ =  x1;
  goto norm__pragma__lower__priority_8_11;
  };
  goto norm__pragma__lower__priority_8_11;
 case VARREF:
  deref_and_jump(x0,norm__pragma__lower__priority_8_4);
  *reasonp++ =  x0;
  goto norm__pragma__lower__priority_8_11;
  };
  goto norm__pragma__lower__priority_8_11;
 case functor_atom_1:
  allocp[0] = makesym(functor_lcall_4);
  allocp[1] = x1 = makeref(&allocp[1]);
  x2 = arg(a0, 0);
  allocp[2] = x2;
  allocp[3] = makeint(0L);
  allocp[4] = NILATOM;
  x0 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a1, x0);
  a0 = a4;
  a1 = x1;
  a4 = a5;
  a5 = makesym(atom_normal);
  execute(norm__pragma__pragma__arg_8_0);
  goto norm__pragma__pragma__arg_8_ext_interrupt;
 default:
  goto norm__pragma__lower__priority_8_11;
  };
 case VARREF:
  deref_and_jump(a0,norm__pragma__lower__priority_8_1);
  *reasonp++ =  a0;
  goto norm__pragma__lower__priority_8_11;
  };
  goto norm__pragma__lower__priority_8_11;
 norm__pragma__lower__priority_8_11:
  otherwise(norm__pragma__lower__priority_8_interrupt);
 norm__pragma__lower__priority_8_13:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_functor_1)) goto norm__pragma__lower__priority_8_interrupt;
  allocp[0] = makesym(functor_lcall_4);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  x0 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__pragma__pragma__arg_8);
  allocp[2] = a4;
  allocp[3] = x1;
  allocp[4] = x5 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a5;
  allocp[7] = x6 = makeref(&allocp[7]);
  allocp[8] = x7 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = makesym(functor_functor_1);
  x9 = arg(a0, 0);
  allocp[11] = x9;
  x8 = makefunctor(&allocp[10]);
  a0 = x8;
  a1 = x2;
  a3 = x4;
  a4 = a2;
  a5 = x5;
  a7 = a6;
  a8 = x7;
  a6 = x6;
  a2 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  execute(norm__body__args_9_0);
  goto norm__body__args_9_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,norm__pragma__lower__priority_8_13);
  *reasonp++ =  a0;
  goto norm__pragma__lower__priority_8_interrupt;
  };
  goto norm__pragma__lower__priority_8_interrupt;
 norm__pragma__lower__priority_8_ext_interrupt:
  reasonp = 0l;
 norm__pragma__lower__priority_8_interrupt:
  toppred = &predicate_klic__comp__normalize_xnorm__pragma__lower__priority_8;
  goto interrupt_8;
 }

 norm__pragma__node_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 norm__pragma__node_8_clear_reason:
  reasonp = reasons;
 norm__pragma__node_8_0:
 norm__pragma__node_8_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_functor_1:
  x0 = arg(a0, 0);
 norm__pragma__node_8_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__3A_2)) goto norm__pragma__node_8_11;
  x1 = arg(x0, 0);
 norm__pragma__node_8_7:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor_atom_1)) goto norm__pragma__node_8_11;
  allocp[0] = makesym(functor_xthrow_5);
  allocp[1] = x3 = makeref(&allocp[1]);
  x4 = arg(x1, 0);
  allocp[2] = x4;
  allocp[3] = x5 = makeref(&allocp[3]);
  allocp[4] = x6 = makeref(&allocp[4]);
  allocp[5] = x7 = makeref(&allocp[5]);
  x2 = makefunctor(&allocp[0]);
  allocp += 6;
  unify_value(a1, x2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__pragma__pragma__arg_8);
  allocp[2] = a4;
  allocp[3] = x3;
  allocp[4] = x8 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a5;
  allocp[7] = x9 = makeref(&allocp[7]);
  allocp[8] = x10 = makeref(&allocp[8]);
  allocp[9] = a7;
  a0 = arg(x0, 1);
  a1 = x5;
  a3 = x7;
  a4 = a2;
  a5 = x8;
  a7 = a6;
  a8 = x10;
  a6 = x9;
  a2 = x6;
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  execute(norm__body__args_9_0);
  goto norm__body__args_9_ext_interrupt;
 case VARREF:
  deref_and_jump(x1,norm__pragma__node_8_7);
  *reasonp++ =  x1;
  goto norm__pragma__node_8_11;
  };
  goto norm__pragma__node_8_11;
 case VARREF:
  deref_and_jump(x0,norm__pragma__node_8_4);
  *reasonp++ =  x0;
  goto norm__pragma__node_8_11;
  };
  goto norm__pragma__node_8_11;
 case functor_atom_1:
  allocp[0] = makesym(functor_throw_4);
  allocp[1] = x1 = makeref(&allocp[1]);
  x2 = arg(a0, 0);
  allocp[2] = x2;
  allocp[3] = makeint(0L);
  allocp[4] = NILATOM;
  x0 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a1, x0);
  a0 = a4;
  a1 = x1;
  a4 = a5;
  a5 = makesym(atom_normal);
  execute(norm__pragma__pragma__arg_8_0);
  goto norm__pragma__pragma__arg_8_ext_interrupt;
 default:
  goto norm__pragma__node_8_11;
  };
 case VARREF:
  deref_and_jump(a0,norm__pragma__node_8_1);
  *reasonp++ =  a0;
  goto norm__pragma__node_8_11;
  };
  goto norm__pragma__node_8_11;
 norm__pragma__node_8_11:
  otherwise(norm__pragma__node_8_interrupt);
 norm__pragma__node_8_13:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_functor_1)) goto norm__pragma__node_8_interrupt;
  allocp[0] = makesym(functor_throw_4);
  allocp[1] = x1 = makeref(&allocp[1]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x3 = makeref(&allocp[3]);
  allocp[4] = x4 = makeref(&allocp[4]);
  x0 = makefunctor(&allocp[0]);
  allocp += 5;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__pragma__pragma__arg_8);
  allocp[2] = a4;
  allocp[3] = x1;
  allocp[4] = x5 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a5;
  allocp[7] = x6 = makeref(&allocp[7]);
  allocp[8] = x7 = makeref(&allocp[8]);
  allocp[9] = a7;
  allocp[10] = makesym(functor_functor_1);
  x9 = arg(a0, 0);
  allocp[11] = x9;
  x8 = makefunctor(&allocp[10]);
  a0 = x8;
  a1 = x2;
  a3 = x4;
  a4 = a2;
  a5 = x5;
  a7 = a6;
  a8 = x7;
  a6 = x6;
  a2 = x3;
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  execute(norm__body__args_9_0);
  goto norm__body__args_9_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,norm__pragma__node_8_13);
  *reasonp++ =  a0;
  goto norm__pragma__node_8_interrupt;
  };
  goto norm__pragma__node_8_interrupt;
 norm__pragma__node_8_ext_interrupt:
  reasonp = 0l;
 norm__pragma__node_8_interrupt:
  toppred = &predicate_klic__comp__normalize_xnorm__pragma__node_8;
  goto interrupt_8;
 }

 norm__pragma__pragma__arg_8_top: {
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 norm__pragma__pragma__arg_8_clear_reason:
  reasonp = reasons;
 norm__pragma__pragma__arg_8_0:
 norm__pragma__pragma__arg_8_1:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (isint(a5)) goto norm__pragma__pragma__arg_8_interrupt;
  switch (symval(a5)) {
 case symval(makesym(atom_normal)):
  a5 = a6;
  a6 = a7;
  execute(norm__body__arg_7_0);
  goto norm__body__arg_7_ext_interrupt;
 case symval(makesym(atom_abnormal)):
  unify(a7, a6);
  unify_value(a4, makesym(atom_abnormal));
  proceed();
 default:
  goto norm__pragma__pragma__arg_8_interrupt;
  };
 case VARREF:
  deref_and_jump(a5,norm__pragma__pragma__arg_8_1);
  *reasonp++ =  a5;
  goto norm__pragma__pragma__arg_8_interrupt;
  };
  goto norm__pragma__pragma__arg_8_interrupt;
 norm__pragma__pragma__arg_8_ext_interrupt:
  reasonp = 0l;
 norm__pragma__pragma__arg_8_interrupt:
  toppred = &predicate_klic__comp__normalize_xnorm__pragma__pragma__arg_8;
  goto interrupt_8;
 }

 norm__body__args_9_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 norm__body__args_9_clear_reason:
  reasonp = reasons;
 norm__body__args_9_0:
 norm__body__args_9_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_functor_1:
  x0 = arg(a0, 0);
 norm__body__args_9_4:
  if (isref(x0)) goto norm__body__args_9_8;
  gblt_pfunctor(x0,x1,norm__body__args_9_interrupt);
  gblt_arity(x0,x2,norm__body__args_9_interrupt);
  unify_value(a1, x1);
  unify_value(a2, x2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__body__args_7);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = a3;
  allocp[4] = a4;
  allocp[5] = a5;
  allocp[6] = a6;
  allocp[7] = a7;
  allocp[8] = a8;
  allocp[9] = x3;
  allocp[10] = x5 = makeref(&allocp[10]);
  x4 = makecons(&allocp[9]);
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_klic__comp__util_xuniv_2);
  allocp[13] = x0;
  allocp[14] = x4;
  qp = (struct goalrec*)&allocp[11];
  allocp += 15;
  proceed();
 norm__body__args_9_8:
  deref_and_jump(x0,norm__body__args_9_4);
  *reasonp++ =  x0;
  goto norm__body__args_9_interrupt;
 case functor_atom_1:
  unify(a8, a7);
  x0 = arg(a0, 0);
  unify(a1, x0);
  unify_value(a2, makeint(0L));
  unify_value(a3, NILATOM);
  unify(a5, a4);
  unify_value(a6, makesym(atom_normal));
  proceed();
 default:
  goto norm__body__args_9_interrupt;
  };
 case VARREF:
  deref_and_jump(a0,norm__body__args_9_1);
  *reasonp++ =  a0;
  goto norm__body__args_9_interrupt;
  };
  goto norm__body__args_9_interrupt;
 norm__body__args_9_ext_interrupt:
  reasonp = 0l;
 norm__body__args_9_interrupt:
  toppred = &predicate_klic__comp__normalize_xnorm__body__args_9;
  goto interrupt_9;
 }

 norm__body__args_7_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 norm__body__args_7_clear_reason:
  reasonp = reasons;
 norm__body__args_7_0:
 norm__body__args_7_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = x2 = makeref(&allocp[1]);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__body__args__1_8);
  x3 = cdr_of(a0);
  allocp[2] = x3;
  allocp[3] = x1;
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x5 = makeref(&allocp[7]);
  allocp[8] = x6 = makeref(&allocp[8]);
  allocp[9] = a6;
  a0 = car_of(a0);
  a1 = x2;
  a3 = x4;
  a4 = x5;
  a6 = x6;
  qp = (struct goalrec*)&allocp[0];
  allocp += 10;
  execute(norm__body__arg_7_0);
  goto norm__body__arg_7_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto norm__body__args_7_interrupt;
  unify(a6, a5);
  unify_value(a1, NILATOM);
  unify(a3, a2);
  unify_value(a4, makesym(atom_normal));
  proceed();
 case VARREF:
  deref_and_jump(a0,norm__body__args_7_1);
  *reasonp++ =  a0;
  goto norm__body__args_7_interrupt;
  };
  goto norm__body__args_7_interrupt;
 norm__body__args_7_ext_interrupt:
  reasonp = 0l;
 norm__body__args_7_interrupt:
  toppred = &predicate_klic__comp__normalize_xnorm__body__args_7;
  goto interrupt_7;
 }

 norm__body__args__1_8_top: {
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 norm__body__args__1_8_clear_reason:
  reasonp = reasons;
 norm__body__args__1_8_0:
 norm__body__args__1_8_1:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (isint(a5)) goto norm__body__args__1_8_interrupt;
  switch (symval(a5)) {
 case symval(makesym(atom_normal)):
  a5 = a6;
  a6 = a7;
  execute(norm__body__args_7_0);
  goto norm__body__args_7_ext_interrupt;
 case symval(makesym(atom_abnormal)):
  unify(a7, a6);
  unify_value(a4, makesym(atom_abnormal));
  proceed();
 default:
  goto norm__body__args__1_8_interrupt;
  };
 case VARREF:
  deref_and_jump(a5,norm__body__args__1_8_1);
  *reasonp++ =  a5;
  goto norm__body__args__1_8_interrupt;
  };
  goto norm__body__args__1_8_interrupt;
 norm__body__args__1_8_ext_interrupt:
  reasonp = 0l;
 norm__body__args__1_8_interrupt:
  goto interrupt_8;
 }

 norm__body__arg_7_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 norm__body__arg_7_clear_reason:
  reasonp = reasons;
 norm__body__arg_7_0:
 norm__body__arg_7_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_variable_1)) goto norm__body__arg_7_4;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__body__arg__1_9);
  x0 = arg(a0, 0);
  allocp[2] = x0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x1 = makeref(&allocp[7]);
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = a5;
  allocp[10] = a6;
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_klic__comp__util_xassoc_4);
  allocp[13] = a2;
  allocp[14] = x0;
  allocp[15] = x1;
  allocp[16] = x2;
  qp = (struct goalrec*)&allocp[11];
  allocp += 17;
  proceed();
 case VARREF:
  deref_and_jump(a0,norm__body__arg_7_1);
  *reasonp++ =  a0;
  goto norm__body__arg_7_4;
  };
  goto norm__body__arg_7_4;
 norm__body__arg_7_4:
  otherwise(norm__body__arg_7_interrupt);
  execute(norm__body__arg__2_7_0);
  goto norm__body__arg__2_7_ext_interrupt;
 norm__body__arg_7_ext_interrupt:
  reasonp = 0l;
 norm__body__arg_7_interrupt:
  toppred = &predicate_klic__comp__normalize_xnorm__body__arg_7;
  goto interrupt_7;
 }

 norm__body__arg__1_9_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  qp = qp->next;
 norm__body__arg__1_9_clear_reason:
  reasonp = reasons;
 norm__body__arg__1_9_0:
 norm__body__arg__1_9_1:
  switch (ptagof(a6)) {
 case ATOMIC:
  if (isint(a6)) goto norm__body__arg__1_9_9;
  switch (symval(a6)) {
 case symval(makesym(atom_yes)):
 norm__body__arg__1_9_5:
  switch (ptagof(a5)) {
 case FUNCTOR:
  if (functor_of(a5) != makesym(functor_rename_1)) goto norm__body__arg__1_9_9;
  allocp[0] = makesym(functor_variable_1);
  x1 = arg(a5, 0);
  allocp[1] = x1;
  x0 = makefunctor(&allocp[0]);
  a0 = x0;
  a5 = a7;
  a6 = a8;
  allocp += 2;
  execute(norm__body__arg_7_0);
  goto norm__body__arg_7_ext_interrupt;
 case VARREF:
  deref_and_jump(a5,norm__body__arg__1_9_5);
  *reasonp++ =  a5;
  goto norm__body__arg__1_9_9;
  };
  goto norm__body__arg__1_9_9;
 case symval(makesym(atom_no)):
  unify(a8, a7);
  allocp[0] = makesym(functor_var_1);
  allocp[1] = a0;
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = makesym(functor_var_1);
  allocp[1] = a0;
  x1 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__3D_2);
  allocp[3] = a0;
  allocp[4] = x1;
  x2 = makefunctor(&allocp[2]);
  allocp[5] = a2;
  allocp[6] = x2;
  x3 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a3, x3);
  unify_value(a4, makesym(atom_normal));
  proceed();
 default:
  goto norm__body__arg__1_9_9;
  };
 case VARREF:
  deref_and_jump(a6,norm__body__arg__1_9_1);
  *reasonp++ =  a6;
  goto norm__body__arg__1_9_9;
  };
  goto norm__body__arg__1_9_9;
 norm__body__arg__1_9_9:
  otherwise(norm__body__arg__1_9_interrupt);
 norm__body__arg__1_9_11:
  switch (ptagof(a6)) {
 case ATOMIC:
  if (a6 != makesym(atom_yes)) goto norm__body__arg__1_9_interrupt;
  unify3(a8, a7, a1, a5, a3, a2);
  unify_value(a4, makesym(atom_normal));
  proceed();
 case VARREF:
  deref_and_jump(a6,norm__body__arg__1_9_11);
  *reasonp++ =  a6;
  goto norm__body__arg__1_9_interrupt;
  };
  goto norm__body__arg__1_9_interrupt;
 norm__body__arg__1_9_ext_interrupt:
  reasonp = 0l;
 norm__body__arg__1_9_interrupt:
  goto interrupt_9;
 }

 norm__body__arg__2_7_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 norm__body__arg__2_7_clear_reason:
  reasonp = reasons;
 norm__body__arg__2_7_0:
 norm__body__arg__2_7_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_variable_1)) goto norm__body__arg__2_7_4;
  unify(a6, a5);
  allocp[0] = makesym(functor_var_1);
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = makesym(functor_var_1);
  allocp[1] = x1;
  x2 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor__3D_2);
  allocp[3] = x1;
  allocp[4] = x2;
  x3 = makefunctor(&allocp[2]);
  allocp[5] = a2;
  allocp[6] = x3;
  x4 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a3, x4);
  unify_value(a4, makesym(atom_normal));
  proceed();
 case VARREF:
  deref_and_jump(a0,norm__body__arg__2_7_1);
  *reasonp++ =  a0;
  goto norm__body__arg__2_7_4;
  };
  goto norm__body__arg__2_7_4;
 norm__body__arg__2_7_4:
  otherwise(norm__body__arg__2_7_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__body__arg__3_8);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = a4;
  allocp[7] = x0 = makeref(&allocp[7]);
  allocp[8] = a5;
  allocp[9] = a6;
  allocp[10] = x1 = makeref(&allocp[10]);
  a2 = x1;
  a3 = makesym(atom_yes);
  a4 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 11;
  execute(is__const_5_0);
  goto is__const_5_ext_interrupt;
 norm__body__arg__2_7_ext_interrupt:
  reasonp = 0l;
 norm__body__arg__2_7_interrupt:
  toppred = &predicate_klic__comp__normalize_xnorm__body__arg__2_7;
  goto interrupt_7;
 }

 norm__body__arg__3_8_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  qp = qp->next;
 norm__body__arg__3_8_clear_reason:
  reasonp = reasons;
 norm__body__arg__3_8_0:
 norm__body__arg__3_8_1:
  switch (ptagof(a5)) {
 case ATOMIC:
  if (isint(a5)) goto norm__body__arg__3_8_interrupt;
  switch (symval(a5)) {
 case symval(makesym(atom_yes)):
  unify2(a7, a6, a3, a2);
  unify_value(a4, makesym(atom_normal));
  proceed();
 case symval(makesym(atom_no)):
 norm__body__arg__3_8_6:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_list_1:
  x0 = arg(a0, 0);
 norm__body__arg__3_8_9:
  switch (ptagof(x0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xnorm__body__arg__3__1_10);
  x1 = cdr_of(x0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = x3 = makeref(&allocp[4]);
  allocp[5] = x4 = makeref(&allocp[5]);
  allocp[6] = a3;
  allocp[7] = a4;
  allocp[8] = a1;
  allocp[9] = x5 = makeref(&allocp[9]);
  allocp[10] = x6 = makeref(&allocp[10]);
  allocp[11] = a7;
  a0 = car_of(x0);
  a1 = x2;
  a3 = x4;
  a4 = x5;
  a5 = a6;
  a6 = x6;
  qp = (struct goalrec*)&allocp[0];
  allocp += 12;
  execute(norm__body__arg_7_0);
  goto norm__body__arg_7_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,norm__body__arg__3_8_9);
  *reasonp++ =  x0;
  goto norm__body__arg__3_8_interrupt;
  };
  goto norm__body__arg__3_8_interrupt;
 case functor_functor_1:
  x0 = arg(a0, 0);
 norm__body__arg__3_8_12:
  if (isref(x0)) goto norm__body__arg__3_8_16;
  gblt_pfunctor(x0,x1,norm__body__arg__3_8_interrupt);
  gblt_arity(x0,x2,norm__body__arg__3_8_interrupt);
  allocp[0] = makesym(functor__2F_2);
  allocp[1] = x1;
  allocp[2] = x2;
  x3 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_mkfunct_2);
  allocp[4] = x3;
  allocp[5] = x5 = makeref(&allocp[5]);
  x4 = makefunctor(&allocp[3]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_klic__comp__normalize_xnorm__body__arg__3__2_6);
  allocp[8] = a1;
  allocp[9] = x4;
  allocp[10] = a4;
  allocp[11] = x6 = makeref(&allocp[11]);
  allocp[12] = x7 = makeref(&allocp[12]);
  allocp[13] = a7;
  allocp[14] = (q)(struct goalrec*)&allocp[6];
  allocp[15] = (q)(&predicate_klic__comp__normalize_xnorm__body__args_7);
  allocp[16] = x8 = makeref(&allocp[16]);
  allocp[17] = x5;
  allocp[18] = a2;
  allocp[19] = a3;
  allocp[20] = x6;
  allocp[21] = a6;
  allocp[22] = x7;
  allocp[23] = x8;
  allocp[24] = x10 = makeref(&allocp[24]);
  x9 = makecons(&allocp[23]);
  allocp[25] = (q)(struct goalrec*)&allocp[14];
  allocp[26] = (q)(&predicate_klic__comp__util_xuniv_2);
  allocp[27] = x0;
  allocp[28] = x9;
  qp = (struct goalrec*)&allocp[25];
  allocp += 29;
  proceed();
 norm__body__arg__3_8_16:
  deref_and_jump(x0,norm__body__arg__3_8_12);
  *reasonp++ =  x0;
  goto norm__body__arg__3_8_interrupt;
 case functor_vector_1:
  x0 = arg(a0, 0);
 norm__body__arg__3_8_18:
  switch (ptagof(x0)) {
 case FUNCTOR:
 norm__body__arg__3_8_19:
  if (!isgobj(x0)) goto norm__body__arg__3_8_interrupt;
  if (!isclass(x0,vector)) goto norm__body__arg__3_8_interrupt;
  gblt_size_of_vector(x0,x1,norm__body__arg__3_8_interrupt);
  allocp[0] = makesym(functor_mkvect_2);
  allocp[1] = x1;
  allocp[2] = x3 = makeref(&allocp[2]);
  x2 = makefunctor(&allocp[0]);
  allocp[3] = (q)qp;
  allocp[4] = (q)(&predicate_klic__comp__normalize_xnorm__body__arg__3__2_6);
  allocp[5] = a1;
  allocp[6] = x2;
  allocp[7] = a4;
  allocp[8] = x4 = makeref(&allocp[8]);
  allocp[9] = x5 = makeref(&allocp[9]);
  allocp[10] = a7;
  allocp[11] = (q)(struct goalrec*)&allocp[3];
  allocp[12] = (q)(&predicate_klic__comp__normalize_xnorm__body__args_7);
  allocp[13] = x6 = makeref(&allocp[13]);
  allocp[14] = x3;
  allocp[15] = a2;
  allocp[16] = a3;
  allocp[17] = x4;
  allocp[18] = a6;
  allocp[19] = x5;
  allocp[20] = (q)(struct goalrec*)&allocp[11];
  allocp[21] = (q)(&predicate_klic__comp__util_xvector__to__list_2);
  allocp[22] = x0;
  allocp[23] = x6;
  qp = (struct goalrec*)&allocp[20];
  allocp += 24;
  proceed();
 case VARREF:
  deref_and_jump(x0,norm__body__arg__3_8_18);
  *reasonp++ =  x0;
  goto norm__body__arg__3_8_interrupt;
  };
  goto norm__body__arg__3_8_interrupt;
 default:
  goto norm__body__arg__3_8_interrupt;
  };
 case VARREF:
  deref_and_jump(a0,norm__body__arg__3_8_6);
  *reasonp++ =  a0;
  goto norm__body__arg__3_8_interrupt;
  };
  goto norm__body__arg__3_8_interrupt;
 default:
  goto norm__body__arg__3_8_interrupt;
  };
 case VARREF:
  deref_and_jump(a5,norm__body__arg__3_8_1);
  *reasonp++ =  a5;
  goto norm__body__arg__3_8_interrupt;
  };
  goto norm__body__arg__3_8_interrupt;
 norm__body__arg__3_8_ext_interrupt:
  reasonp = 0l;
 norm__body__arg__3_8_interrupt:
  goto interrupt_8;
 }

 norm__body__arg__3__1_10_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  a7 = qp->args[7];
  a8 = qp->args[8];
  a9 = qp->args[9];
  qp = qp->next;
 norm__body__arg__3__1_10_clear_reason:
  reasonp = reasons;
 norm__body__arg__3__1_10_0:
 norm__body__arg__3__1_10_1:
  switch (ptagof(a7)) {
 case ATOMIC:
  if (isint(a7)) goto norm__body__arg__3__1_10_interrupt;
  switch (symval(a7)) {
 case symval(makesym(atom_normal)):
  allocp[0] = makesym(functor_cons_2);
  allocp[1] = a1;
  allocp[2] = a2;
  x0 = makefunctor(&allocp[0]);
  allocp[3] = (q)qp;
  allocp[4] = (q)(&predicate_klic__comp__normalize_xnorm__body__arg__3__2_6);
  allocp[5] = a6;
  allocp[6] = x0;
  allocp[7] = a5;
  allocp[8] = x1 = makeref(&allocp[8]);
  allocp[9] = x2 = makeref(&allocp[9]);
  allocp[10] = a9;
  a1 = a2;
  a2 = a3;
  a3 = a4;
  a4 = x1;
  a5 = a8;
  a6 = x2;
  qp = (struct goalrec*)&allocp[3];
  allocp += 11;
  execute(norm__body__arg_7_0);
  goto norm__body__arg_7_ext_interrupt;
 case symval(makesym(atom_abnormal)):
  unify(a9, a8);
  unify_value(a5, makesym(atom_abnormal));
  proceed();
 default:
  goto norm__body__arg__3__1_10_interrupt;
  };
 case VARREF:
  deref_and_jump(a7,norm__body__arg__3__1_10_1);
  *reasonp++ =  a7;
  goto norm__body__arg__3__1_10_interrupt;
  };
  goto norm__body__arg__3__1_10_interrupt;
 norm__body__arg__3__1_10_ext_interrupt:
  reasonp = 0l;
 norm__body__arg__3__1_10_interrupt:
  goto interrupt_10;
 }

 norm__body__arg__3__2_6_top: {
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 norm__body__arg__3__2_6_clear_reason:
  reasonp = reasons;
 norm__body__arg__3__2_6_0:
 norm__body__arg__3__2_6_1:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (isint(a3)) goto norm__body__arg__3__2_6_interrupt;
  switch (symval(a3)) {
 case symval(makesym(atom_normal)):
  unify2(a5, a4, a0, a1);
  unify_value(a2, makesym(atom_normal));
  proceed();
 case symval(makesym(atom_abnormal)):
  unify(a5, a4);
  unify_value(a2, makesym(atom_abnormal));
  proceed();
 default:
  goto norm__body__arg__3__2_6_interrupt;
  };
 case VARREF:
  deref_and_jump(a3,norm__body__arg__3__2_6_1);
  *reasonp++ =  a3;
  goto norm__body__arg__3__2_6_interrupt;
  };
  goto norm__body__arg__3__2_6_interrupt;
 norm__body__arg__3__2_6_ext_interrupt:
  reasonp = 0l;
 norm__body__arg__3__2_6_interrupt:
  goto interrupt_6;
 }

 is__const_5_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 is__const_5_clear_reason:
  reasonp = reasons;
 is__const_5_0:
 is__const_5_1:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (isint(a3)) goto is__const_5_19;
  switch (symval(a3)) {
 case symval(makesym(atom_no)):
  unify_value(a4, makesym(atom_no));
  proceed();
 case symval(makesym(atom_yes)):
 is__const_5_6:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_variable_1:
  unify_value(a4, makesym(atom_no));
  proceed();
 case functor_atom_1:
  unify_value(a1, a0);
  unify_value(a2, makesym(atom_atom));
  unify_value(a4, makesym(atom_yes));
  proceed();
 case functor_integer_1:
  allocp[0] = makesym(functor_int_1);
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  unify_value(a2, makesym(atom_int));
  unify_value(a4, makesym(atom_yes));
  proceed();
 case functor_float_1:
  unify_value(a1, a0);
  unify_value(a2, makesym(atom_float));
  unify_value(a4, makesym(atom_yes));
  proceed();
 case functor_predicate_3:
  unify_value(a1, a0);
  unify_value(a2, makesym(atom_predicate));
  unify_value(a4, makesym(atom_yes));
  proceed();
 case functor_list_1:
  x0 = arg(a0, 0);
 is__const_5_14:
  switch (ptagof(x0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xis__const__1_6);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = makesym(atom_list);
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_klic__comp__normalize_xis__const_5);
  x2 = cdr_of(x0);
  allocp[10] = x2;
  allocp[11] = x3 = makeref(&allocp[11]);
  allocp[12] = x4 = makeref(&allocp[12]);
  allocp[13] = x5 = makeref(&allocp[13]);
  allocp[14] = x1;
  a0 = car_of(x0);
  allocp[15] = x6 = makeref(&allocp[15]);
  a1 = x6;
  allocp[16] = x7 = makeref(&allocp[16]);
  a2 = x7;
  a3 = makesym(atom_yes);
  a4 = x5;
  qp = (struct goalrec*)&allocp[8];
  allocp += 17;
  execute(is__const_5_0);
  goto is__const_5_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,is__const_5_14);
  *reasonp++ =  x0;
  goto is__const_5_19;
  };
  goto is__const_5_19;
 case functor_functor_1:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xis__const__1_6);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x0 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = makesym(atom_functor);
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_klic__comp__normalize_xis__const__args_3);
  allocp[10] = makesym(atom_yes);
  allocp[11] = x1 = makeref(&allocp[11]);
  allocp[12] = x0;
  allocp[13] = x1;
  allocp[14] = x3 = makeref(&allocp[14]);
  x2 = makecons(&allocp[13]);
  allocp[15] = (q)(struct goalrec*)&allocp[8];
  allocp[16] = (q)(&predicate_klic__comp__util_xuniv_2);
  x4 = arg(a0, 0);
  allocp[17] = x4;
  allocp[18] = x2;
  qp = (struct goalrec*)&allocp[15];
  allocp += 19;
  proceed();
 case functor_string_1:
  unify_value(a1, a0);
  unify_value(a2, makesym(atom_string));
  unify_value(a4, makesym(atom_yes));
  proceed();
 case functor_vector_1:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xis__const__1_6);
  allocp[2] = a0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x0 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = makesym(atom_vector);
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_klic__comp__normalize_xis__const__args_3);
  allocp[10] = makesym(atom_yes);
  allocp[11] = x1 = makeref(&allocp[11]);
  allocp[12] = x0;
  allocp[13] = (q)(struct goalrec*)&allocp[8];
  allocp[14] = (q)(&predicate_klic__comp__util_xvector__to__list_2);
  x2 = arg(a0, 0);
  allocp[15] = x2;
  allocp[16] = x1;
  qp = (struct goalrec*)&allocp[13];
  allocp += 17;
  proceed();
 default:
  goto is__const_5_19;
  };
 case VARREF:
  deref_and_jump(a0,is__const_5_6);
  *reasonp++ =  a0;
  goto is__const_5_19;
  };
  goto is__const_5_19;
 default:
  goto is__const_5_19;
  };
 case VARREF:
  deref_and_jump(a3,is__const_5_1);
  *reasonp++ =  a3;
  goto is__const_5_19;
  };
  goto is__const_5_19;
 is__const_5_19:
  otherwise(is__const_5_interrupt);
 is__const_5_21:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (a3 != makesym(atom_yes)) goto is__const_5_interrupt;
  unify_value(a4, makesym(atom_no));
  proceed();
 case VARREF:
  deref_and_jump(a3,is__const_5_21);
  *reasonp++ =  a3;
  goto is__const_5_interrupt;
  };
  goto is__const_5_interrupt;
 is__const_5_ext_interrupt:
  reasonp = 0l;
 is__const_5_interrupt:
  toppred = &predicate_klic__comp__normalize_xis__const_5;
  goto interrupt_5;
 }

 is__const__1_6_top: {
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 is__const__1_6_clear_reason:
  reasonp = reasons;
 is__const__1_6_0:
 is__const__1_6_1:
  switch (ptagof(a3)) {
 case ATOMIC:
  if (isint(a3)) goto is__const__1_6_interrupt;
  switch (symval(a3)) {
 case symval(makesym(atom_no)):
  unify_value(a4, makesym(atom_no));
  proceed();
 case symval(makesym(atom_yes)):
  unify2(a1, a0, a2, a5);
  unify_value(a4, makesym(atom_yes));
  proceed();
 default:
  goto is__const__1_6_interrupt;
  };
 case VARREF:
  deref_and_jump(a3,is__const__1_6_1);
  *reasonp++ =  a3;
  goto is__const__1_6_interrupt;
  };
  goto is__const__1_6_interrupt;
 is__const__1_6_ext_interrupt:
  reasonp = 0l;
 is__const__1_6_interrupt:
  goto interrupt_6;
 }

 is__const__args_3_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  qp = qp->next;
 is__const__args_3_clear_reason:
  reasonp = reasons;
 is__const__args_3_0:
 is__const__args_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto is__const__args_3_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_no)):
  unify_value(a2, makesym(atom_no));
  proceed();
 case symval(makesym(atom_yes)):
 is__const__args_3_6:
  switch (ptagof(a1)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__normalize_xis__const__args_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  x1 = cdr_of(a1);
  allocp[3] = x1;
  allocp[4] = a2;
  a0 = car_of(a1);
  allocp[5] = x2 = makeref(&allocp[5]);
  a1 = x2;
  allocp[6] = x3 = makeref(&allocp[6]);
  a2 = x3;
  a3 = makesym(atom_yes);
  a4 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(is__const_5_0);
  goto is__const_5_ext_interrupt;
 case ATOMIC:
  if (a1 != NILATOM) goto is__const__args_3_interrupt;
  unify_value(a2, makesym(atom_yes));
  proceed();
 case VARREF:
  deref_and_jump(a1,is__const__args_3_6);
  *reasonp++ =  a1;
  goto is__const__args_3_interrupt;
  };
  goto is__const__args_3_interrupt;
 default:
  goto is__const__args_3_interrupt;
  };
 case VARREF:
  deref_and_jump(a0,is__const__args_3_1);
  *reasonp++ =  a0;
  goto is__const__args_3_interrupt;
  };
  goto is__const__args_3_interrupt;
 is__const__args_3_ext_interrupt:
  reasonp = 0l;
 is__const__args_3_interrupt:
  goto interrupt_3;
 }
 interrupt_14:
  allocp[15] = a13;
 interrupt_13:
  allocp[14] = a12;
 interrupt_12:
  allocp[13] = a11;
 interrupt_11:
  allocp[12] = a10;
 interrupt_10:
  allocp[11] = a9;
 interrupt_9:
  allocp[10] = a8;
 interrupt_8:
  allocp[9] = a7;
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_klic__comp__normalize);
}
