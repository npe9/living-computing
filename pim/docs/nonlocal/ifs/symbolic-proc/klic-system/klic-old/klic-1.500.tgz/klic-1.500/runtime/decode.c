#include <klic/basic.h>
#include <klic/struct.h>
#include <klic/primitives.h>
#include <klic/unify.h>
#include <klic/timing.h>
#include <klic/generic.h> 
#include <klic/index.h> 
#include <klic/alloc.h>
#include <klic/functorstuffs.h> 

#include <stdio.h>
#include <setjmp.h>

#include <klic/interpe.h>
#include <klic/traceio.h>

#define  field_diff_dist(field) (after_exec.field - before_exec.field)
extern timerstruct before_exec, after_exec;

#ifdef GETRUSAGE
#define  diff_usec_dist(field)\
(field_diff_dist(field.tv_sec) * 1000000 + field_diff_dist(field.tv_usec))
#endif

/***** Message Decode *****/

q* decode_throw(inbuf, allocp)
     long inbuf[];
     q *allocp;
{
  declare_globals;
  struct goalrec *newgoal;
  struct predicate *pred_of_goal;
  unsigned short int arity;
  int i;
  module decoder;
  q *allocarg;
  long prio;

#ifdef INT_CL_DEBUG
  sprintf(iobuf,"decode_throw_routine\n");
  Print(iobuf);
#endif

#ifdef INT_CL_PROBE
  recv_throw_cnt++;
#endif
  node_wtc = node_wtc + inbuf[inbuf_index++];
  prio = inbuf[inbuf_index++];

  pred_of_goal = (struct predicate *)(inbuf[inbuf_index++]);
  arity = (unsigned short int)(pred_of_goal->arity); 
  newgoal = (struct goalrec *)allocp;
  allocp = allocp+arity+2;
  if(allocp >= real_heaplimit){
    fatal("Bad estimation of decodeing, heap exausted");
  }

  newgoal->pred = pred_of_goal;

  for ( i=0; i<arity; i++){
    decoder = (module)inbuf[inbuf_index++];
    allocp = (q *) decoder(inbuf, allocp);
    newgoal->args[i] = decode_data;
  }  

  if(prio == current_prio){
    resume_same_prio(newgoal); /* $B$3$NCf$G!"(Bheaplimit = 0 $B$H$7$F$k!#Cm0U(B */
  } else {
    (void) enqueue_goal(0, prio, newgoal, &globals);    
  }
  return(allocp);
}

Extern q reply_hook_g_new();

q search_exptbl();

q* decode_read(inbuf, allocp)
     long inbuf[];
     q *allocp;
{
  q data, rhook;
  long node, index,wec,wtc;
  declare_globals;

#ifdef INT_CL_DEBUG
  sprintf(iobuf,"decode_read\n");
  Print(iobuf);
#endif

#ifdef INT_CL_PROBE
  recv_read_cnt++;
#endif
  node_wtc = node_wtc + inbuf[inbuf_index++];

  data = (q)search_exptbl(inbuf[inbuf_index++], 1);

  node  = inbuf[inbuf_index++];
  index = inbuf[inbuf_index++];
  wec   = inbuf[inbuf_index++];

  deref_and_switch(data, susp_label, atomic_label, cons_label, funct_label);

susp_label:

  generic_arg[0] = makeint(node); /* Node Number */
  generic_arg[1] = makeint(index); /* exp_table (for answer) index */
  generic_arg[2] = makeint(wec); /* WEC */

  new_generic(reply_hook_g_new, 3, rhook, 0);

  allocp = do_unify(allocp ,rhook, data);
  return(allocp);

atomic_label:
cons_label:
funct_label:  /* data_obj$B$GAw$l$J$$$b$N$,$"$k;~$O!"$3$3$,JQ$o$k(B */

  send_answer_value(data, node, index, wec);
  return(allocp);
}

q* decode_answer_value(inbuf, allocp)
     long inbuf[];
     q *allocp;
{
  q exref, ans_data;
  module decoder;  
  long return_index, wec;
  declare_globals;

#ifdef INT_CL_DEBUG
  sprintf(iobuf,"decode_answer_value\n");
  Print(iobuf);
#endif

#ifdef INT_CL_PROBE
  recv_answer_cnt++;
#endif
  node_wtc = node_wtc + inbuf[inbuf_index++];

  return_index = inbuf[inbuf_index++];
  wec          = inbuf[inbuf_index++];

  exref = (q)search_exptbl(return_index, wec);  

  deref_and_switch(exref, susp_label, atomic_label, cons_label, funct_label);  

atomic_label:
cons_label:
funct_label:
    /* decode_data is not used, and collected by local GC */
  decoder = (module)inbuf[inbuf_index++];
  allocp = (q *)decoder(inbuf, allocp);
  return(allocp);
susp_label:

  decoder = (module)inbuf[inbuf_index++];
  allocp = (q *)decoder(inbuf, allocp);
  receive_answer_flag = 1;
  answer_return_exp_index = return_index;
    /* ReadHook$B$,!"(Banswer_value$B$r<u$1$?;~!"(B%unify$B$r=P$5$J$$$?$a$N=hM}(B */

  allocp = do_unify(allocp, exref, decode_data);

  answer_return_exp_index = -1;
  receive_answer_flag = 0;
    /* ReadHook$B$,!"(Banswer_value$B$r<u$1$?;~!"(B%unify$B$r=P$5$J$$$?$a$N=hM}(B */
  return(allocp);
}

q* decode_unify(inbuf, allocp)
     long inbuf[];
     q *allocp;
{
  q exp_data, imp_data;
  module decoder;    
  declare_globals;
#ifdef INT_CL_DEBUG  
  sprintf(iobuf,"decode_unify\n");
  Print(iobuf);
#endif

#ifdef INT_CL_PROBE
  recv_unify_cnt++;
#endif
  node_wtc = node_wtc + inbuf[inbuf_index++];

  exp_data = (q)search_exptbl(inbuf[inbuf_index++], inbuf[inbuf_index++]);
  decoder = (module)inbuf[inbuf_index++];
  allocp = (q *)decoder(inbuf, allocp);

  allocp = do_unify(allocp, exp_data, decode_data);
  return(allocp);
}

q* decode_release(inbuf, allocp)
     long inbuf[];
     q *allocp;
{
  q exp_data, imp_data;
  module decoder;    
  declare_globals;
  long exp_index, wec;

#ifdef INT_CL_DEBUG  
  sprintf(iobuf,"decode_release\n");
  Print(iobuf);
#endif

#ifdef INT_CL_PROBE
  recv_release_cnt++;
#endif

  exp_index = inbuf[inbuf_index++];
  wec       = inbuf[inbuf_index++];

  exp_data = (q)search_exptbl(exp_index, wec);
  return(allocp);
}

/***** $B%G!<%?$N%G%3!<%I(B *****/

q* decode_const(inbuf, allocp)
     long inbuf[];
     q *allocp;
{
  declare_globals;

  decode_data = (q)inbuf[inbuf_index++];
  return(allocp);
}

q* decode_atomic_level0(inbuf, allocp)
     long inbuf[];
     q *allocp;
{
  q  msg_data;
  declare_globals;

#ifdef INT_CL_DEBUG
  sprintf(iobuf,"decode_atomic_level0\n");
  Print(iobuf);
#endif

  decode_data = (q)inbuf[inbuf_index++];

  return(allocp);
}

Extern q read_hook_g_new();
Extern q exref_g_new();

q* decode_exref_level0(inbuf, allocp)
     long inbuf[];
     q *allocp;
{
  declare_globals;
  q data;
  long node;
#ifdef INT_CL_DEBUG
  sprintf(iobuf,"decode_exref_level0\n");
  Print(iobuf);
#endif
  node = inbuf[inbuf_index++];
  if(node == my_node) {
    /* $B<+J,$,M"=P$7$?%G!<%?$@$C$?(B*/
    long index = inbuf[inbuf_index++];
    long wec   = inbuf[inbuf_index++];

    decode_data = (q)search_exptbl(index, wec);
    return(allocp);

  } else {
    /* $BB>%/%i%9%?$N%G!<%?(B */

    generic_arg[0] = makeint(node);  /* PE number */
    generic_arg[1] = makeint(inbuf[inbuf_index++]);  /* exp_table index */
    generic_arg[2] = makeint(inbuf[inbuf_index++]);  /* WEC */

    new_generic(exref_g_new, 3, decode_data, 0); 
    return(allocp);
  }
}

q* decode_list_level1(inbuf, allocp)
     long inbuf[];
     q *allocp;
{
  declare_globals;
  q list;
  module decoder;  

#ifdef INT_CL_DEBUG
  sprintf(iobuf,"decode_list_level1\n");
  Print(iobuf);
#endif

  heapalloc(list, sizeof(struct cons)/sizeof(q), makecons);

  decoder = (module)inbuf[inbuf_index++];
  allocp = (q *)decoder(inbuf, allocp);
  car_of(list) = decode_data;

  decoder = (module)inbuf[inbuf_index++];
  allocp = (q *)decoder(inbuf, allocp);
  cdr_of(list) = decode_data;

  decode_data = list;

  return(allocp);
}

q* decode_funct_level1(inbuf, allocp)
     long inbuf[];
     q *allocp;
{
  declare_globals;
  q funct, p_funct;
  module decoder;  
  int i;

#ifdef INT_CL_DEBUG
  sprintf(iobuf,"decode_funct_level1\n");
  Print(iobuf);
#endif
  p_funct = (q)inbuf[inbuf_index++];

  heapalloc(funct, arityof(p_funct)+1, makefunctor);

  functor_of(funct) = p_funct;
  for(i=0 ; i<arityof(p_funct); i++){
    decoder = (module)inbuf[inbuf_index++];
    allocp = (q *) decoder(inbuf, allocp);
    arg(funct, i) = decode_data;
  }
  decode_data = funct;
  return(allocp);
}
/*
q* report_msg_stat(inbuf, allocp)
     long inbuf[];
     q *allocp;
{
  declare_globals;

  sprintf(iobuf,"send_throw %d\n",send_throw_cnt);
  Print(iobuf);
  sprintf(iobuf,"send_read  %d\n",send_read_cnt);
  Print(iobuf);
  sprintf(iobuf,"send_unify %d\n",send_unify_cnt);
  Print(iobuf);
  sprintf(iobuf,"send_answer %d\n",send_answer_cnt);
  Print(iobuf);
  sprintf(iobuf,"send_release %d\n",send_release_cnt);
  Print(iobuf);

  sprintf(iobuf,"recv_throw %d\n",recv_throw_cnt);
  Print(iobuf);
  sprintf(iobuf,"recv_read  %d\n",recv_read_cnt);
  Print(iobuf);
  sprintf(iobuf,"recv_unify %d\n",recv_unify_cnt);
  Print(iobuf);
  sprintf(iobuf,"recv_answer %d\n",recv_answer_cnt);
  Print(iobuf);
  sprintf(iobuf,"recv_release %d\n",recv_release_cnt);
  Print(iobuf);
  sprintf(iobuf,"total_msg %d\n", send_throw_cnt+send_read_cnt+send_unify_cnt
	                  +send_answer_cnt +send_release_cnt
	                  +recv_throw_cnt +recv_read_cnt
	                  +recv_unify_cnt +recv_answer_cnt
	                  +recv_release_cnt);
  Print(iobuf);
  return(allocp);
}
*/
q* decode_request_wtc(inbuf, allocp)
     long inbuf[];
     q *allocp;
{
  declare_globals;
  long node = inbuf[inbuf_index++];
  shoen_wtc++;
  send_supply_wtc(node);

  return(allocp);
}

void message_resume();

q* decode_supply_wtc(inbuf, allocp)
     long inbuf[];
     q *allocp;
{
  declare_globals;
#ifdef INT_CL_DEBUG  
  sprintf(iobuf,"decode_supply_wtc\n");
  Print(iobuf);
#endif

  recv_supply_wtc_cnt++;

  if(!requesting_wtc){
    fatal("Not requesting wtc now");
  }
  requesting_wtc = 0;
  node_wtc = node_wtc+SUPPLY_WTC_UNIT;

  if((long)top_of_susp_msg_rec != END_SUSP_MSG_REC){
    message_resume();
  }
  return(allocp);
}

q* decode_return_wtc(inbuf, allocp)
     long inbuf[];
     q *allocp;
{
  declare_globals;
  long ret_wtc;
#ifdef INT_CL_DEBUG  
  sprintf(iobuf,"decode_return_wtc\n");
  Print(iobuf);
#endif
  ret_wtc = inbuf[inbuf_index++];
  shoen_wtc = shoen_wtc + ret_wtc;

  return(allocp);
}

void print_node_statistics();
void print_network_statistics();

q* decode_terminate_msg(inbuf, allocp)
     long inbuf[];
     q *allocp;
{
  declare_globals;

  if(network_statistics_flag){
    print_node_statistics();
    print_network_statistics();
/*    sprintf(iobuf,"Nodes %d terminate \n", my_node);
    Print(iobuf);*/
  }
  CloseIO;

  pvm_exit();
  exit(0);
}

void print_node_statistics()
{
  declare_globals;
  measure(after_exec);

#ifdef GETRUSAGE
  sprintf(iobuf, "Node %d Local Stat: \n %d ms total; %d user; %d system\n %d GC %d suspensions; %d resumptions\n\n", 
	  my_node, 
         ((int)(diff_usec_dist(ru_utime)/1000)+
          (int)(diff_usec_dist(ru_stime)/1000)),
         (int)(diff_usec_dist(ru_utime)/1000),
         (int)(diff_usec_dist(ru_stime)/1000),
	  gctimes, suspensions, resumes
         );
#else
  sprintf(iobuf, "Node %d Local Stat: \n %d ms total; %d user; %d system\n %d GC %d suspensions; %d resumptions\n\n", 
	  my_node, 
         ((int)tick2msec(field_diff_dist(tms_utime))+
          (int)tick2msec(field_diff_dist(tms_stime))),
         (int)tick2msec(field_diff_dist(tms_utime)),
         (int)tick2msec(field_diff_dist(tms_stime)),
	  gctimes, suspensions, resumes
         );
#endif
  Print(iobuf);
/*  sprintf(iobuf, "PE %d %d GC\n", my_node, gctimes);
  Print(iobuf);
  sprintf(iobuf, "PE %d %d suspensions; %d resumptions\n",
         my_node, suspensions, resumes);
  Print(iobuf);*/
}

void print_network_statistics()
{
  declare_globals;

  sprintf(iobuf,"NODE %d Net Stat:\n snd_thrw %d, snd_read  %d, snd_ufy %d, snd_ans %d, send_rel %d\n rcv_thrw %d, rev_read  %d, rev_ufy %d, rcv_ans %d, rcv_rel %d\n total_msg %d\n total_send_bytes %d\n total_recv_bytes %d\n \n",
	         my_node,
	         send_throw_cnt, send_read_cnt, send_unify_cnt,
	         send_answer_cnt, send_release_cnt, 
	         recv_throw_cnt, recv_read_cnt, recv_unify_cnt,
	         recv_answer_cnt, recv_release_cnt, 
	         send_throw_cnt+send_read_cnt+send_unify_cnt
	         +send_answer_cnt+send_release_cnt
	         +recv_throw_cnt+recv_read_cnt
	         +recv_unify_cnt+recv_answer_cnt
	         +recv_release_cnt,
	         send_data_cnt*sizeof(long), recv_data_cnt);
  EPrint(iobuf);
}
