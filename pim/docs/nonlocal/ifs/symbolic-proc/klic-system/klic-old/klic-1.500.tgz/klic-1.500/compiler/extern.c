/* Compiled by KLIC compiler version 1.500 (Fri Oct 21 12:19:27 JST 1994) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"

module module_klic__comp__extern();
Const struct predicate predicate_klic__comp__extern_xmake__ext__table_3 =
   { module_klic__comp__extern, 0, 3 };
Const struct predicate predicate_klic__comp__extern_xext__struct_3 =
   { module_klic__comp__extern, 1, 3 };
Const struct predicate predicate_klic__comp__extern_xext__struct_2F3_240_3 =
   { module_klic__comp__extern, 2, 3 };
Const struct predicate predicate_klic__comp__extern_xext__struct__funct_5 =
   { module_klic__comp__extern, 3, 5 };
Const struct predicate predicate_klic__comp__extern_xext__struct__vector_5 =
   { module_klic__comp__extern, 4, 5 };

module module_klic__comp__extern(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  Const static q funct_const_0[] = {
    makesym(functor_class_1),
    makesym(atom_float),
  };
  Const static q funct_const_1[] = {
    makesym(functor_class_1),
    makesym(atom_predicate),
  };
  Const static q funct_const_2[] = {
    makesym(functor_class_1),
    makesym(atom_byte__string),
  };
  Const static q funct_const_3[] = {
    makesym(functor_class_1),
    makesym(atom_vector),
  };
  q a0, a1, a2, a3, a4;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  a2 = qp->args[2];
  switch_on_pred() {
    case_pred(0, make__ext__table_3_top);
    case_pred(1, ext__struct_3_top);
    case_pred(2, ext__struct_2F3_240_3_top);
    case_pred(3, ext__struct__funct_5_top);
    last_case_pred(4, ext__struct__vector_5_top);
  }

 make__ext__table_3_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  qp = qp->next;
 make__ext__table_3_clear_reason:
  reasonp = reasons;
 make__ext__table_3_0:
 make__ext__table_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 make__ext__table_3_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_atom_1:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__extern_xmake__ext__table_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = makesym(functor_atom_1);
  x4 = arg(x0, 0);
  allocp[6] = x4;
  x3 = makefunctor(&allocp[5]);
  a0 = x3;
  a2 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(ext__struct_3_0);
  goto ext__struct_3_ext_interrupt;
 case functor_funct_1:
  allocp[0] = makesym(functor_funct_1);
  x2 = arg(x0, 0);
  allocp[1] = x2;
  x1 = makefunctor(&allocp[0]);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = x1;
  x3 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a1, x3);
  a0 = cdr_of(a0);
  a1 = x4;
  execute(make__ext__table_3_0);
  goto make__ext__table_3_ext_interrupt;
 case functor_ext_1:
  x1 = arg(x0, 0);
 make__ext__table_3_8:
  switch (ptagof(x1)) {
 case FUNCTOR:
  if (functor_of(x1) != makesym(functor__2F_2)) goto make__ext__table_3_19;
  x2 = arg(x1, 0);
 make__ext__table_3_11:
  switch (ptagof(x2)) {
 case FUNCTOR:
  if (functor_of(x2) != makesym(functor__2F_2)) goto make__ext__table_3_19;
  allocp[0] = makesym(functor_module_1);
  x4 = arg(x2, 0);
  allocp[1] = x4;
  x3 = makefunctor(&allocp[0]);
  allocp[2] = x6 = makeref(&allocp[2]);
  allocp[3] = x3;
  x5 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a1, x5);
  a0 = cdr_of(a0);
  a1 = x6;
  execute(make__ext__table_3_0);
  goto make__ext__table_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x2,make__ext__table_3_11);
  *reasonp++ =  x2;
  goto make__ext__table_3_19;
  };
  goto make__ext__table_3_19;
 case VARREF:
  deref_and_jump(x1,make__ext__table_3_8);
  *reasonp++ =  x1;
  goto make__ext__table_3_19;
  };
  goto make__ext__table_3_19;
 case functor_gnew_1:
  allocp[0] = makesym(functor_class_1);
  x2 = arg(x0, 0);
  allocp[1] = x2;
  x1 = makefunctor(&allocp[0]);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = x1;
  x3 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a1, x3);
  a0 = cdr_of(a0);
  a1 = x4;
  execute(make__ext__table_3_0);
  goto make__ext__table_3_ext_interrupt;
 case functor_const_2:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__extern_xmake__ext__table_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  a0 = arg(x0, 1);
  a2 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(ext__struct_3_0);
  goto ext__struct_3_ext_interrupt;
 default:
  goto make__ext__table_3_19;
  };
 case VARREF:
  deref_and_jump(x0,make__ext__table_3_3);
  *reasonp++ =  x0;
  goto make__ext__table_3_19;
  };
  goto make__ext__table_3_19;
 case ATOMIC:
  if (a0 != NILATOM) goto make__ext__table_3_19;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,make__ext__table_3_1);
  *reasonp++ =  a0;
  goto make__ext__table_3_19;
  };
  goto make__ext__table_3_19;
 make__ext__table_3_19:
  otherwise(make__ext__table_3_interrupt);
 make__ext__table_3_21:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(make__ext__table_3_0);
  goto make__ext__table_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,make__ext__table_3_21);
  *reasonp++ =  a0;
  goto make__ext__table_3_interrupt;
  };
  goto make__ext__table_3_interrupt;
 make__ext__table_3_ext_interrupt:
  reasonp = 0l;
 make__ext__table_3_interrupt:
  goto interrupt_3;
 }

 ext__struct_3_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  qp = qp->next;
 ext__struct_3_clear_reason:
  reasonp = reasons;
 ext__struct_3_0:
 ext__struct_3_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_atom_1:
  a0 = arg(a0, 0);
  x0 = a2;
  a2 = a1;
  a1 = x0;
  execute(ext__struct_2F3_240_3_0);
  goto ext__struct_2F3_240_3_ext_interrupt;
 case functor_integer_1:
  unify(a2, a1);
  proceed();
 case functor_float_1:
  allocp[0] = a2;
  allocp[1] = makefunctor(funct_const_0);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  proceed();
 case functor_predicate_3:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = makefunctor(funct_const_1);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = makesym(functor_module_1);
  x3 = arg(a0, 0);
  allocp[1] = x3;
  x2 = makefunctor(&allocp[0]);
  allocp[2] = a2;
  allocp[3] = x2;
  x4 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(x1, x4);
  proceed();
 case functor_string_1:
  allocp[0] = a2;
  allocp[1] = makefunctor(funct_const_2);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  proceed();
 case functor_list_1:
  x0 = arg(a0, 0);
 ext__struct_3_9:
  switch (ptagof(x0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__extern_xext__struct_3);
  x1 = cdr_of(x0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  a0 = car_of(x0);
  a2 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(ext__struct_3_0);
  goto ext__struct_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,ext__struct_3_9);
  *reasonp++ =  x0;
  goto ext__struct_3_interrupt;
  };
  goto ext__struct_3_interrupt;
 case functor_functor_1:
  x0 = arg(a0, 0);
 ext__struct_3_12:
  if (isref(x0)) goto ext__struct_3_16;
  gblt_pfunctor(x0,x1,ext__struct_3_interrupt);
  gblt_arity(x0,x2,ext__struct_3_interrupt);
  allocp[0] = makesym(functor__2F_2);
  allocp[1] = x1;
  allocp[2] = x2;
  x3 = makefunctor(&allocp[0]);
  allocp[3] = makesym(functor_funct_1);
  allocp[4] = x3;
  x4 = makefunctor(&allocp[3]);
  allocp[5] = x6 = makeref(&allocp[5]);
  allocp[6] = x4;
  x5 = makecons(&allocp[5]);
  allocp += 7;
  unify_value(a1, x5);
  a0 = makeint(0L);
  a1 = x2;
  a3 = x6;
  a4 = a2;
  a2 = x0;
  execute(ext__struct__funct_5_0);
  goto ext__struct__funct_5_ext_interrupt;
 ext__struct_3_16:
  deref_and_jump(x0,ext__struct_3_12);
  *reasonp++ =  x0;
  goto ext__struct_3_interrupt;
 case functor_vector_1:
  x0 = arg(a0, 0);
 ext__struct_3_18:
  switch (ptagof(x0)) {
 case FUNCTOR:
 ext__struct_3_19:
  if (!isgobj(x0)) goto ext__struct_3_interrupt;
  if (!isclass(x0,vector)) goto ext__struct_3_interrupt;
  gblt_size_of_vector(x0,x1,ext__struct_3_interrupt);
  allocp[0] = x3 = makeref(&allocp[0]);
  allocp[1] = makefunctor(funct_const_3);
  x2 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x2);
  a0 = makeint(0L);
  a1 = x1;
  a3 = x3;
  a4 = a2;
  a2 = x0;
  execute(ext__struct__vector_5_0);
  goto ext__struct__vector_5_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,ext__struct_3_18);
  *reasonp++ =  x0;
  goto ext__struct_3_interrupt;
  };
  goto ext__struct_3_interrupt;
 default:
  goto ext__struct_3_interrupt;
  };
 case VARREF:
  deref_and_jump(a0,ext__struct_3_1);
  *reasonp++ =  a0;
  goto ext__struct_3_interrupt;
  };
  goto ext__struct_3_interrupt;
 ext__struct_3_ext_interrupt:
  reasonp = 0l;
 ext__struct_3_interrupt:
  toppred = &predicate_klic__comp__extern_xext__struct_3;
  goto interrupt_3;
 }

 ext__struct_2F3_240_3_top: {
  q x0, x1, x2;
  qp = qp->next;
 ext__struct_2F3_240_3_clear_reason:
  reasonp = reasons;
 ext__struct_2F3_240_3_0:
 ext__struct_2F3_240_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto ext__struct_2F3_240_3_6;
  switch (symval(a0)) {
 case symval(NILATOM):
  unify(a1, a2);
  proceed();
 case symval(PERIODATOM):
  unify(a1, a2);
  proceed();
 default:
  goto ext__struct_2F3_240_3_6;
  };
 case VARREF:
  deref_and_jump(a0,ext__struct_2F3_240_3_1);
  *reasonp++ =  a0;
  goto ext__struct_2F3_240_3_6;
  };
  goto ext__struct_2F3_240_3_6;
 ext__struct_2F3_240_3_6:
  otherwise(ext__struct_2F3_240_3_interrupt);
  allocp[0] = makesym(functor_atom_1);
  allocp[1] = a0;
  x0 = makefunctor(&allocp[0]);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = x0;
  x1 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a2, x1);
  unify(a1, x2);
  proceed();
 ext__struct_2F3_240_3_ext_interrupt:
  reasonp = 0l;
 ext__struct_2F3_240_3_interrupt:
  toppred = &predicate_klic__comp__extern_xext__struct_2F3_240_3;
  goto interrupt_3;
 }

 ext__struct__funct_5_top: {
  q x0, x1, x2;
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 ext__struct__funct_5_clear_reason:
  reasonp = reasons;
 ext__struct__funct_5_0:
 ext__struct__funct_5_1:
  if (!isint(a0)) goto ext__struct__funct_5_14;
 ext__struct__funct_5_3:
  if (!isint(a1)) goto ext__struct__funct_5_13;
  gblt_eq(a0,a1,ext__struct__funct_5_6);
  unify(a4, a3);
  proceed();
 ext__struct__funct_5_6:
  gblt_less(a0,a1,ext__struct__funct_5_interrupt);
  gblt_add(a0,makeint(1L),x0,ext__struct__funct_5_interrupt);
 ext__struct__funct_5_9:
  if (isref(a2)) goto ext__struct__funct_5_12;
  gblt_arg(x0,a2,x1,ext__struct__funct_5_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__extern_xext__struct__funct_5);
  allocp[2] = x0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  a0 = x1;
  a1 = a3;
  a2 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(ext__struct_3_0);
  goto ext__struct_3_ext_interrupt;
 ext__struct__funct_5_12:
  deref_and_jump(a2,ext__struct__funct_5_9);
  *reasonp++ =  a2;
  goto ext__struct__funct_5_interrupt;
 ext__struct__funct_5_13:
  if (!isref(a1)) goto ext__struct__funct_5_interrupt;
  deref_and_jump(a1,ext__struct__funct_5_3);
  *reasonp++ =  a1;
  goto ext__struct__funct_5_interrupt;
 ext__struct__funct_5_14:
  if (!isref(a0)) goto ext__struct__funct_5_interrupt;
  deref_and_jump(a0,ext__struct__funct_5_1);
  *reasonp++ =  a0;
  goto ext__struct__funct_5_interrupt;
 ext__struct__funct_5_ext_interrupt:
  reasonp = 0l;
 ext__struct__funct_5_interrupt:
  toppred = &predicate_klic__comp__extern_xext__struct__funct_5;
  goto interrupt_5;
 }

 ext__struct__vector_5_top: {
  q x0, x1, x2;
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 ext__struct__vector_5_clear_reason:
  reasonp = reasons;
 ext__struct__vector_5_0:
 ext__struct__vector_5_1:
  if (!isint(a0)) goto ext__struct__vector_5_14;
 ext__struct__vector_5_3:
  if (!isint(a1)) goto ext__struct__vector_5_13;
  gblt_eq(a0,a1,ext__struct__vector_5_6);
  unify(a4, a3);
  proceed();
 ext__struct__vector_5_6:
  gblt_less(a0,a1,ext__struct__vector_5_interrupt);
  gblt_add(a0,makeint(1L),x0,ext__struct__vector_5_interrupt);
 ext__struct__vector_5_9:
  switch (ptagof(a2)) {
 case FUNCTOR:
 ext__struct__vector_5_10:
  if (!isgobj(a2)) goto ext__struct__vector_5_interrupt;
 ext__struct__vector_5_11:
  generic_arg[0] = a0;
  guard_generic(a2, functor_element_2, 1, ext__struct__vector_5_interrupt);
  x1 = generic_arg[1];
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__extern_xext__struct__vector_5);
  allocp[2] = x0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  a0 = x1;
  a1 = a3;
  a2 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(ext__struct_3_0);
  goto ext__struct_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,ext__struct__vector_5_9);
  *reasonp++ =  a2;
  goto ext__struct__vector_5_interrupt;
  };
  goto ext__struct__vector_5_interrupt;
 ext__struct__vector_5_13:
  if (!isref(a1)) goto ext__struct__vector_5_interrupt;
  deref_and_jump(a1,ext__struct__vector_5_3);
  *reasonp++ =  a1;
  goto ext__struct__vector_5_interrupt;
 ext__struct__vector_5_14:
  if (!isref(a0)) goto ext__struct__vector_5_interrupt;
  deref_and_jump(a0,ext__struct__vector_5_1);
  *reasonp++ =  a0;
  goto ext__struct__vector_5_interrupt;
 ext__struct__vector_5_ext_interrupt:
  reasonp = 0l;
 ext__struct__vector_5_interrupt:
  toppred = &predicate_klic__comp__extern_xext__struct__vector_5;
  goto interrupt_5;
 }
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_klic__comp__extern);
}
