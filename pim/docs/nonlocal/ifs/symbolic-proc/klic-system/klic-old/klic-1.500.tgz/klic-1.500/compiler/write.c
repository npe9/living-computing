/* Compiled by KLIC compiler version 1.500 (Fri Oct 21 12:19:27 JST 1994) */
#include <klic/klichdr.h>
#include "atom.h"
#include "funct.h"
#include <ctype.h>

module module_klic__comp__write();
Const struct predicate predicate_klic__comp__write_xwrite__out_3 =
   { module_klic__comp__write, 0, 3 };
Const struct predicate predicate_klic__comp__write_xwrite__module__header_7 =
   { module_klic__comp__write, 1, 7 };
Const struct predicate predicate_klic__comp__write_xdeclare__const_5 =
   { module_klic__comp__write, 2, 5 };
Const struct predicate predicate_klic__comp__write_xdeclare__const_2F5_240_7 =
   { module_klic__comp__write, 3, 7 };
Const struct predicate predicate_klic__comp__write_xfind__same__const_3 =
   { module_klic__comp__write, 4, 3 };
Const struct predicate predicate_klic__comp__write_xdeclare__const_6 =
   { module_klic__comp__write, 5, 6 };
Const struct predicate predicate_klic__comp__write_xdeclare__const_2F6_241_7 =
   { module_klic__comp__write, 6, 7 };
Const struct predicate predicate_klic__comp__write_xdeclare__const_2F6_240_7 =
   { module_klic__comp__write, 7, 7 };
Const struct predicate predicate_klic__comp__write_xdeclare__const__list_6 =
   { module_klic__comp__write, 8, 6 };
Const struct predicate predicate_klic__comp__write_xwrite__const__elems_3 =
   { module_klic__comp__write, 9, 3 };
Const struct predicate predicate_klic__comp__write_xwrite__const__elem_3 =
   { module_klic__comp__write, 10, 3 };
Const struct predicate predicate_klic__comp__write_xwrite__string__body_4 =
   { module_klic__comp__write, 11, 4 };
Const struct predicate predicate_klic__comp__write_xwrite__character__constants_5 =
   { module_klic__comp__write, 12, 5 };
Const struct predicate predicate_klic__comp__write_xwrite__string__elements_5 =
   { module_klic__comp__write, 13, 5 };
Const struct predicate predicate_klic__comp__write_xwrite__string__element_3 =
   { module_klic__comp__write, 14, 3 };
Const struct predicate predicate_klic__comp__write_xwrite__pred__structs_4 =
   { module_klic__comp__write, 15, 4 };
Const struct predicate predicate_klic__comp__write_xdeclare__externals_3 =
   { module_klic__comp__write, 16, 3 };
Const struct predicate predicate_klic__comp__write_xdeclare__externals__ext_4 =
   { module_klic__comp__write, 17, 4 };
Const struct predicate predicate_klic__comp__write_xdeclare__externals__gnew_4 =
   { module_klic__comp__write, 18, 4 };
Const struct predicate predicate_klic__comp__write_xpred__min__max_5 =
   { module_klic__comp__write, 19, 5 };
Const struct predicate predicate_klic__comp__write_xdeclare__registers_4 =
   { module_klic__comp__write, 20, 4 };
Const struct predicate predicate_klic__comp__write_xwrite__comma__list_5 =
   { module_klic__comp__write, 21, 5 };
Const struct predicate predicate_klic__comp__write_xwrite__comma__list1_5 =
   { module_klic__comp__write, 22, 5 };
Const struct predicate predicate_klic__comp__write_xwrite__pred__dispatch_3 =
   { module_klic__comp__write, 23, 3 };
Const struct predicate predicate_klic__comp__write_xwrite__predicates_6 =
   { module_klic__comp__write, 24, 6 };
Const struct predicate predicate_klic__comp__write_xwrite__predicates__1_4 =
   { module_klic__comp__write, 25, 4 };
Const struct predicate predicate_klic__comp__write_xwrite__get__args_4 =
   { module_klic__comp__write, 26, 4 };
Const struct predicate predicate_klic__comp__write_xwrite__module__tailer_4 =
   { module_klic__comp__write, 27, 4 };
Const struct predicate predicate_klic__comp__write_xwrite__interrupt__call_4 =
   { module_klic__comp__write, 28, 4 };
Const struct predicate predicate_klic__comp__write_xwrite__header__file_3 =
   { module_klic__comp__write, 29, 3 };
Const struct predicate predicate_klic__comp__write_xwrite__ext__entries_3 =
   { module_klic__comp__write, 30, 3 };
Const struct predicate predicate_klic__comp__write_xwrite__ext__entries_2F3_240_4 =
   { module_klic__comp__write, 31, 4 };
Const struct predicate predicate_klic__comp__write_xwrite__ext__entry_3 =
   { module_klic__comp__write, 32, 3 };
Const struct predicate predicate_klic__comp__write_xwrite__defined__preds_4 =
   { module_klic__comp__write, 33, 4 };
Const struct predicate predicate_klic__comp__write_xwrite__ext__preds_3 =
   { module_klic__comp__write, 34, 3 };
Const struct predicate predicate_klic__comp__write_xwrite__ext__preds__1_5 =
   { module_klic__comp__write, 35, 5 };
Const struct predicate predicate_klic__comp__write_xwrite__atom_3 =
   { module_klic__comp__write, 36, 3 };
Const struct predicate predicate_klic__comp__write_xwrite__funct__name_4 =
   { module_klic__comp__write, 37, 4 };
Const struct predicate predicate_klic__comp__write_xwrite__pred__name_5 =
   { module_klic__comp__write, 38, 5 };
Const struct predicate predicate_klic__comp__write_xmake__atom__name__string_2 =
   { module_klic__comp__write, 39, 2 };
Const struct predicate predicate_klic__comp__write_xmake__atom__name__string__1_3 =
   { module_klic__comp__write, 40, 3 };
Const struct predicate predicate_klic__comp__write_xascii__string_3 =
   { module_klic__comp__write, 41, 3 };
Const struct predicate predicate_klic__comp__write_xhexchar_2 =
   { module_klic__comp__write, 42, 2 };
extern Const struct predicate predicate_klic__comp__util_xuniv_2;
extern Const struct predicate predicate_klic__comp__util_xvector__to__list_4;
extern Const struct predicate predicate_klic__comp__util_xname_2;
extern Const struct predicate predicate_klic__comp__util_xmax_3;
extern Const struct predicate predicate_klic__comp__util_xmin_3;
extern Const struct predicate predicate_klic__comp__obj_xwrite__object_4;
extern Const struct predicate predicate_integer__arithmetics_xadd_3;
extern Const struct predicate predicate_klic__comp__extern_xmake__ext__table_3;
extern Const struct predicate predicate_klic__comp__obj_xnl_2;
extern Const struct predicate predicate_klic__comp__util_xmember_3;
extern Const struct predicate predicate_klic__comp__obj_xklicformat_4;
extern Const struct predicate predicate_klic__comp__util_xstring__to__char__list_2;
extern Const struct predicate predicate_integer__arithmetics_xand_3;

module module_klic__comp__write(glbl, qp, allocp, toppred)
  struct global_variables *glbl;
  struct goalrec *qp;
  register q *allocp;
  Const struct predicate *toppred;
{
  Const static unsigned char strconst_body_0[4] =
    {' ',' ','}','\n',};
  Const static string_structure_type_8 string_const_0 =
      declare_string_constant_8(strconst_body_0,4);
  Const static q funct_const_1[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_0),
  };
  Const static unsigned char strconst_body_2[24] =
    "  switch_on_pred() {\n";
  Const static string_structure_type_8 string_const_2 =
      declare_string_constant_8(strconst_body_2,21);
  Const static q funct_const_3[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_2),
  };
  Const static unsigned char strconst_body_4[28] =
    {'\n',' ',' ','q',' ','*','r','e','a','s','o','n','p',';','\n',' ','m','o','d','u','l','e','_','t','o','p',':','\n',};
  Const static string_structure_type_8 string_const_4 =
      declare_string_constant_8(strconst_body_4,28);
  Const static q funct_const_5[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_4),
  };
  Const static unsigned char strconst_body_6[4] =
    "a";
  Const static string_structure_type_8 string_const_6 =
      declare_string_constant_8(strconst_body_6,1);
  Const static unsigned char strconst_body_7[116] =
    "  struct global_variables *glbl;\n  struct goalrec *qp;\n  register q *allocp;\n  Const struct predicate *toppred;\n{\n";
  Const static string_structure_type_8 string_const_7 =
      declare_string_constant_8(strconst_body_7,114);
  Const static q funct_const_8[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_7),
  };
  Const static unsigned char strconst_body_9[44] =
    {'m','o','d','u','l','e',' ','m','o','d','u','l','e','_','~','q','(','g','l','b','l',',',' ','q','p',',',' ','a','l','l','o','c','p',',',' ','t','o','p','p','r','e','d',')','\n',};
  Const static string_structure_type_8 string_const_9 =
      declare_string_constant_8(strconst_body_9,44);
  Const static unsigned char strconst_body_10[20] =
    {'m','o','d','u','l','e',' ','m','o','d','u','l','e','_','~','q','(',')',';','\n',};
  Const static string_structure_type_8 string_const_10 =
      declare_string_constant_8(strconst_body_10,20);
  Const static unsigned char strconst_body_11[32] =
    {' ',' ',' ',' ','d','e','c','l','a','r','e','_','f','l','o','a','t','_','c','o','n','s','t','a','n','t','(','~','g',')',';','\n',};
  Const static string_structure_type_8 string_const_11 =
      declare_string_constant_8(strconst_body_11,32);
  Const static unsigned char strconst_body_12[56] =
    "  Const static float_structure_type float_const_~d =\n";
  Const static string_structure_type_8 string_const_12 =
      declare_string_constant_8(strconst_body_12,53);
  Const static unsigned char strconst_body_13[44] =
    {' ',' ',' ',' ','d','e','c','l','a','r','e','_','m','o','d','u','l','e','_','c','o','n','s','t','a','n','t','(','m','o','d','u','l','e','_','~','q',',',' ','~','a',')',';','\n',};
  Const static string_structure_type_8 string_const_13 =
      declare_string_constant_8(strconst_body_13,44);
  Const static unsigned char strconst_body_14[52] =
    {' ',' ','C','o','n','s','t',' ','s','t','a','t','i','c',' ','m','o','d','u','l','e','_','s','t','r','u','c','t','u','r','e','_','t','y','p','e',' ','m','o','d','_','c','o','n','s','t','_','~','d',' ','=','\n',};
  Const static string_structure_type_8 string_const_14 =
      declare_string_constant_8(strconst_body_14,52);
  Const static unsigned char strconst_body_15[32] =
    "  extern module module_~q();\n";
  Const static string_structure_type_8 string_const_15 =
      declare_string_constant_8(strconst_body_15,29);
  Const static unsigned char strconst_body_16[52] =
    "    declare_pred_constant(~p, mod_const_~d, ~a);\n";
  Const static string_structure_type_8 string_const_16 =
      declare_string_constant_8(strconst_body_16,49);
  Const static unsigned char strconst_body_17[56] =
    {' ',' ','C','o','n','s','t',' ','s','t','a','t','i','c',' ','p','r','e','d','i','c','a','t','e','_','s','t','r','u','c','t','u','r','e','_','t','y','p','e',' ','p','r','e','d','_','c','o','n','s','t','_','~','d',' ','=','\n',};
  Const static string_structure_type_8 string_const_17 =
      declare_string_constant_8(strconst_body_17,56);
  Const static unsigned char strconst_body_18[40] =
    "  Const static q cons_const_~d[] = {\n";
  Const static string_structure_type_8 string_const_18 =
      declare_string_constant_8(strconst_body_18,37);
  Const static unsigned char strconst_body_19[20] =
    "    makesym(~f),\n";
  Const static string_structure_type_8 string_const_19 =
      declare_string_constant_8(strconst_body_19,17);
  Const static unsigned char strconst_body_20[40] =
    "  Const static q funct_const_~d[] = {\n";
  Const static string_structure_type_8 string_const_20 =
      declare_string_constant_8(strconst_body_20,38);
  Const static unsigned char strconst_body_21[40] =
    "      declare_string_constant_~d(0,0);\n";
  Const static string_structure_type_8 string_const_21 =
      declare_string_constant_8(strconst_body_21,39);
  Const static unsigned char strconst_body_22[56] =
    "      declare_string_constant_~d(strconst_body_~d,~d);\n";
  Const static string_structure_type_8 string_const_22 =
      declare_string_constant_8(strconst_body_22,55);
  Const static unsigned char strconst_body_23[60] =
    "  Const static string_structure_type_~d string_const_~d =\n";
  Const static string_structure_type_8 string_const_23 =
      declare_string_constant_8(strconst_body_23,58);
  Const static unsigned char strconst_body_24[56] =
    {' ',' ','C','o','n','s','t',' ','s','t','a','t','i','c',' ','u','n','s','i','g','n','e','d',' ','c','h','a','r',' ','s','t','r','c','o','n','s','t','_','b','o','d','y','_','~','d','[','~','d',']',' ','=','\n',' ',' ',' ',' ',};
  Const static string_structure_type_8 string_const_24 =
      declare_string_constant_8(strconst_body_24,56);
  Const static unsigned char strconst_body_25[36] =
    {' ',' ',' ',' ',' ',' ','d','e','c','l','a','r','e','_','v','e','c','t','o','r','_','c','o','n','s','t','a','n','t','(','0',',','0',')',';','\n',};
  Const static string_structure_type_8 string_const_25 =
      declare_string_constant_8(strconst_body_25,36);
  Const static q funct_const_26[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_25),
  };
  Const static unsigned char strconst_body_27[56] =
    "      declare_vector_constant(vectconst_body_~d,~d);\n";
  Const static string_structure_type_8 string_const_27 =
      declare_string_constant_8(strconst_body_27,53);
  Const static unsigned char strconst_body_28[56] =
    "  Const static vector_structure_type vector_const_~d =\n";
  Const static string_structure_type_8 string_const_28 =
      declare_string_constant_8(strconst_body_28,55);
  Const static unsigned char strconst_body_29[8] =
    "  };\n";
  Const static string_structure_type_8 string_const_29 =
      declare_string_constant_8(strconst_body_29,5);
  Const static q funct_const_30[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_29),
  };
  Const static unsigned char strconst_body_31[44] =
    "  Const static q vectconst_body_~d[] = {\n";
  Const static string_structure_type_8 string_const_31 =
      declare_string_constant_8(strconst_body_31,41);
  Const static unsigned char strconst_body_32[8] =
    {' ',' ',' ',' ','~','a',',','\n',};
  Const static string_structure_type_8 string_const_32 =
      declare_string_constant_8(strconst_body_32,8);
  Const static unsigned char strconst_body_33[20] =
    "    makeint(~d),\n";
  Const static string_structure_type_8 string_const_33 =
      declare_string_constant_8(strconst_body_33,17);
  Const static unsigned char strconst_body_34[32] =
    "    makefloat(float_const_~d),\n";
  Const static string_structure_type_8 string_const_34 =
      declare_string_constant_8(strconst_body_34,31);
  Const static unsigned char strconst_body_35[32] =
    "    makepred(pred_const_~d),\n";
  Const static string_structure_type_8 string_const_35 =
      declare_string_constant_8(strconst_body_35,29);
  Const static unsigned char strconst_body_36[28] =
    {' ',' ',' ',' ','m','a','k','e','p','r','e','d','(','m','o','d','_','c','o','n','s','t','_','~','d',')',',','\n',};
  Const static string_structure_type_8 string_const_36 =
      declare_string_constant_8(strconst_body_36,28);
  Const static unsigned char strconst_body_37[32] =
    "    makecons(cons_const_~d),\n";
  Const static string_structure_type_8 string_const_37 =
      declare_string_constant_8(strconst_body_37,29);
  Const static unsigned char strconst_body_38[36] =
    "    makefunctor(funct_const_~d),\n";
  Const static string_structure_type_8 string_const_38 =
      declare_string_constant_8(strconst_body_38,33);
  Const static unsigned char strconst_body_39[36] =
    "    makefunctor(&string_const_~d),\n";
  Const static string_structure_type_8 string_const_39 =
      declare_string_constant_8(strconst_body_39,35);
  Const static unsigned char strconst_body_40[36] =
    "    makefunctor(&vector_const_~d),\n";
  Const static string_structure_type_8 string_const_40 =
      declare_string_constant_8(strconst_body_40,35);
  Const static unsigned char strconst_body_41[4] =
    "\"";
  Const static string_structure_type_8 string_const_41 =
      declare_string_constant_8(strconst_body_41,1);
  Const static q funct_const_42[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_41),
  };
  Const static unsigned char strconst_body_43[4] =
    "{";
  Const static string_structure_type_8 string_const_43 =
      declare_string_constant_8(strconst_body_43,1);
  Const static q funct_const_44[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_43),
  };
  Const static unsigned char strconst_body_45[4] =
    "}";
  Const static string_structure_type_8 string_const_45 =
      declare_string_constant_8(strconst_body_45,1);
  Const static q funct_const_46[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_45),
  };
  Const static unsigned char strconst_body_47[4] =
    "\'";
  Const static string_structure_type_8 string_const_47 =
      declare_string_constant_8(strconst_body_47,1);
  Const static q funct_const_48[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_47),
  };
  Const static unsigned char strconst_body_49[4] =
    "\',";
  Const static string_structure_type_8 string_const_49 =
      declare_string_constant_8(strconst_body_49,2);
  Const static q funct_const_50[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_49),
  };
  Const static unsigned char strconst_body_51[4] =
    "\\\"";
  Const static string_structure_type_8 string_const_51 =
      declare_string_constant_8(strconst_body_51,2);
  Const static q funct_const_52[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_51),
  };
  Const static unsigned char strconst_body_53[4] =
    "\\\'";
  Const static string_structure_type_8 string_const_53 =
      declare_string_constant_8(strconst_body_53,2);
  Const static q funct_const_54[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_53),
  };
  Const static unsigned char strconst_body_55[4] =
    "\\\\";
  Const static string_structure_type_8 string_const_55 =
      declare_string_constant_8(strconst_body_55,2);
  Const static q funct_const_56[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_55),
  };
  Const static unsigned char strconst_body_57[4] =
    "\\n";
  Const static string_structure_type_8 string_const_57 =
      declare_string_constant_8(strconst_body_57,2);
  Const static q funct_const_58[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_57),
  };
  Const static unsigned char strconst_body_59[4] =
    "\\t";
  Const static string_structure_type_8 string_const_59 =
      declare_string_constant_8(strconst_body_59,2);
  Const static q funct_const_60[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_59),
  };
  Const static unsigned char strconst_body_61[4] =
    " ";
  Const static string_structure_type_8 string_const_61 =
      declare_string_constant_8(strconst_body_61,1);
  Const static q funct_const_62[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_61),
  };
  Const static unsigned char strconst_body_63[4] =
    "~c";
  Const static string_structure_type_8 string_const_63 =
      declare_string_constant_8(strconst_body_63,2);
  Const static unsigned char strconst_body_64[8] =
    "\\~d~d~d";
  Const static string_structure_type_8 string_const_64 =
      declare_string_constant_8(strconst_body_64,7);
  Const static unsigned char strconst_body_65[28] =
    "   { module_~q, ~d, ~d };\n";
  Const static string_structure_type_8 string_const_65 =
      declare_string_constant_8(strconst_body_65,26);
  Const static unsigned char strconst_body_66[28] =
    {'C','o','n','s','t',' ','s','t','r','u','c','t',' ','p','r','e','d','i','c','a','t','e',' ','~','p',' ','=','\n',};
  Const static string_structure_type_8 string_const_66 =
      declare_string_constant_8(strconst_body_66,28);
  Const static unsigned char strconst_body_67[36] =
    "extern Const struct predicate ~p;\n";
  Const static string_structure_type_8 string_const_67 =
      declare_string_constant_8(strconst_body_67,34);
  Const static unsigned char strconst_body_68[24] =
    "extern q ~s_g_new();\n";
  Const static string_structure_type_8 string_const_68 =
      declare_string_constant_8(strconst_body_68,21);
  Const static unsigned char strconst_body_69[4] =
    ";\n";
  Const static string_structure_type_8 string_const_69 =
      declare_string_constant_8(strconst_body_69,2);
  Const static q funct_const_70[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_69),
  };
  Const static unsigned char strconst_body_71[4] =
    {' ',' ','q',' ',};
  Const static string_structure_type_8 string_const_71 =
      declare_string_constant_8(strconst_body_71,4);
  Const static unsigned char strconst_body_72[4] =
    {'~','s','~','d',};
  Const static string_structure_type_8 string_const_72 =
      declare_string_constant_8(strconst_body_72,4);
  Const static unsigned char strconst_body_73[4] =
    "~s";
  Const static string_structure_type_8 string_const_73 =
      declare_string_constant_8(strconst_body_73,2);
  Const static unsigned char strconst_body_74[8] =
    "~s~d, ";
  Const static string_structure_type_8 string_const_74 =
      declare_string_constant_8(strconst_body_74,6);
  Const static unsigned char strconst_body_75[36] =
    "    last_case_pred(~d, ~q_~d_top);\n";
  Const static string_structure_type_8 string_const_75 =
      declare_string_constant_8(strconst_body_75,35);
  Const static unsigned char strconst_body_76[32] =
    "    case_pred(~d, ~q_~d_top);\n";
  Const static string_structure_type_8 string_const_76 =
      declare_string_constant_8(strconst_body_76,30);
  Const static unsigned char strconst_body_77[4] =
    "\n";
  Const static string_structure_type_8 string_const_77 =
      declare_string_constant_8(strconst_body_77,1);
  Const static q funct_const_78[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_77),
  };
  Const static unsigned char strconst_body_79[4] =
    " }\n";
  Const static string_structure_type_8 string_const_79 =
      declare_string_constant_8(strconst_body_79,3);
  Const static q funct_const_80[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_79),
  };
  Const static unsigned char strconst_body_81[24] =
    "  goto interrupt_~d;\n";
  Const static string_structure_type_8 string_const_81 =
      declare_string_constant_8(strconst_body_81,21);
  Const static unsigned char strconst_body_82[20] =
    " ~q_~d_interrupt:\n";
  Const static string_structure_type_8 string_const_82 =
      declare_string_constant_8(strconst_body_82,18);
  Const static unsigned char strconst_body_83[16] =
    {' ',' ','r','e','a','s','o','n','p',' ','=',' ','0','l',';','\n',};
  Const static string_structure_type_8 string_const_83 =
      declare_string_constant_8(strconst_body_83,16);
  Const static q funct_const_84[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_83),
  };
  Const static unsigned char strconst_body_85[24] =
    " ~q_~d_ext_interrupt:\n";
  Const static string_structure_type_8 string_const_85 =
      declare_string_constant_8(strconst_body_85,22);
  Const static unsigned char strconst_body_86[24] =
    "  reasonp = reasons;\n";
  Const static string_structure_type_8 string_const_86 =
      declare_string_constant_8(strconst_body_86,21);
  Const static q funct_const_87[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_86),
  };
  Const static unsigned char strconst_body_88[24] =
    " ~q_~d_clear_reason:\n";
  Const static string_structure_type_8 string_const_88 =
      declare_string_constant_8(strconst_body_88,21);
  Const static unsigned char strconst_body_89[20] =
    "  qp = qp->next;\n";
  Const static string_structure_type_8 string_const_89 =
      declare_string_constant_8(strconst_body_89,17);
  Const static q funct_const_90[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_89),
  };
  Const static unsigned char strconst_body_91[4] =
    "x";
  Const static string_structure_type_8 string_const_91 =
      declare_string_constant_8(strconst_body_91,1);
  Const static unsigned char strconst_body_92[16] =
    " ~q_~d_top: {\n";
  Const static string_structure_type_8 string_const_92 =
      declare_string_constant_8(strconst_body_92,14);
  Const static unsigned char strconst_body_93[20] =
    "  toppred = &~p;\n";
  Const static string_structure_type_8 string_const_93 =
      declare_string_constant_8(strconst_body_93,17);
  Const static unsigned char strconst_body_94[24] =
    "  a~d = qp->args[~d];\n";
  Const static string_structure_type_8 string_const_94 =
      declare_string_constant_8(strconst_body_94,22);
  Const static unsigned char strconst_body_95[4] =
    "}\n";
  Const static string_structure_type_8 string_const_95 =
      declare_string_constant_8(strconst_body_95,2);
  Const static q funct_const_96[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_95),
  };
  Const static unsigned char strconst_body_97[36] =
    "  loop_within_module(module_~q);\n";
  Const static string_structure_type_8 string_const_97 =
      declare_string_constant_8(strconst_body_97,33);
  Const static unsigned char strconst_body_98[16] =
    {' ','p','r','o','c','e','e','d','_','l','a','b','e','l',':','\n',};
  Const static string_structure_type_8 string_const_98 =
      declare_string_constant_8(strconst_body_98,16);
  Const static q funct_const_99[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_98),
  };
  Const static unsigned char strconst_body_100[20] =
    {' ',' ','a','l','l','o','c','p','[','~','d',']',' ','=',' ','a','~','d',';','\n',};
  Const static string_structure_type_8 string_const_100 =
      declare_string_constant_8(strconst_body_100,20);
  Const static unsigned char strconst_body_101[16] =
    " interrupt_~d:\n";
  Const static string_structure_type_8 string_const_101 =
      declare_string_constant_8(strconst_body_101,15);
  Const static unsigned char strconst_body_102[68] =
    " interrupt_0:\n  allocp = interrupt_goal(allocp, toppred, reasonp);\n";
  Const static string_structure_type_8 string_const_102 =
      declare_string_constant_8(strconst_body_102,67);
  Const static q funct_const_103[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_102),
  };
  Const static unsigned char strconst_body_104[12] =
    "module_~q\n";
  Const static string_structure_type_8 string_const_104 =
      declare_string_constant_8(strconst_body_104,10);
  Const static unsigned char strconst_body_105[8] =
    {'a','t','o','m','_','~','q','\n',};
  Const static string_structure_type_8 string_const_105 =
      declare_string_constant_8(strconst_body_105,8);
  Const static unsigned char strconst_body_106[16] =
    "ref_module_~q\n";
  Const static string_structure_type_8 string_const_106 =
      declare_string_constant_8(strconst_body_106,14);
  Const static unsigned char strconst_body_107[16] =
    "ref_class_~q\n";
  Const static string_structure_type_8 string_const_107 =
      declare_string_constant_8(strconst_body_107,13);
  Const static unsigned char strconst_body_108[4] =
    "~p\n";
  Const static string_structure_type_8 string_const_108 =
      declare_string_constant_8(strconst_body_108,3);
  Const static unsigned char strconst_body_109[8] =
    "NILATOM";
  Const static string_structure_type_8 string_const_109 =
      declare_string_constant_8(strconst_body_109,7);
  Const static q funct_const_110[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_109),
  };
  Const static unsigned char strconst_body_111[12] =
    "PERIODATOM";
  Const static string_structure_type_8 string_const_111 =
      declare_string_constant_8(strconst_body_111,10);
  Const static q funct_const_112[] = {
    makesym(functor_fwrite_1),
    makefunctor(&string_const_111),
  };
  Const static unsigned char strconst_body_113[12] =
    {'m','a','k','e','i','n','t','(','~','d','L',')',};
  Const static string_structure_type_8 string_const_113 =
      declare_string_constant_8(strconst_body_113,12);
  Const static unsigned char strconst_body_114[16] =
    {'m','a','k','e','s','y','m','(','a','t','o','m','_','~','q',')',};
  Const static string_structure_type_8 string_const_114 =
      declare_string_constant_8(strconst_body_114,16);
  Const static unsigned char strconst_body_115[16] =
    "functor_~q_~d";
  Const static string_structure_type_8 string_const_115 =
      declare_string_constant_8(strconst_body_115,13);
  Const static unsigned char strconst_body_116[20] =
    "predicate_~q_x~q_~d";
  Const static string_structure_type_8 string_const_116 =
      declare_string_constant_8(strconst_body_116,19);
  q a0, a1, a2, a3, a4, a5, a6;

  q *reasonp;
 module_top:
  a0 = qp->args[0];
  a1 = qp->args[1];
  switch_on_pred() {
    case_pred(0, write__out_3_top);
    case_pred(1, write__module__header_7_top);
    case_pred(2, declare__const_5_top);
    case_pred(3, declare__const_2F5_240_7_top);
    case_pred(4, find__same__const_3_top);
    case_pred(5, declare__const_6_top);
    case_pred(6, declare__const_2F6_241_7_top);
    case_pred(7, declare__const_2F6_240_7_top);
    case_pred(8, declare__const__list_6_top);
    case_pred(9, write__const__elems_3_top);
    case_pred(10, write__const__elem_3_top);
    case_pred(11, write__string__body_4_top);
    case_pred(12, write__character__constants_5_top);
    case_pred(13, write__string__elements_5_top);
    case_pred(14, write__string__element_3_top);
    case_pred(15, write__pred__structs_4_top);
    case_pred(16, declare__externals_3_top);
    case_pred(17, declare__externals__ext_4_top);
    case_pred(18, declare__externals__gnew_4_top);
    case_pred(19, pred__min__max_5_top);
    case_pred(20, declare__registers_4_top);
    case_pred(21, write__comma__list_5_top);
    case_pred(22, write__comma__list1_5_top);
    case_pred(23, write__pred__dispatch_3_top);
    case_pred(24, write__predicates_6_top);
    case_pred(25, write__predicates__1_4_top);
    case_pred(26, write__get__args_4_top);
    case_pred(27, write__module__tailer_4_top);
    case_pred(28, write__interrupt__call_4_top);
    case_pred(29, write__header__file_3_top);
    case_pred(30, write__ext__entries_3_top);
    case_pred(31, write__ext__entries_2F3_240_4_top);
    case_pred(32, write__ext__entry_3_top);
    case_pred(33, write__defined__preds_4_top);
    case_pred(34, write__ext__preds_3_top);
    case_pred(35, write__ext__preds__1_5_top);
    case_pred(36, write__atom_3_top);
    case_pred(37, write__funct__name_4_top);
    case_pred(38, write__pred__name_5_top);
    case_pred(39, make__atom__name__string_2_top);
    case_pred(40, make__atom__name__string__1_3_top);
    case_pred(41, ascii__string_3_top);
    last_case_pred(42, hexchar_2_top);
  }

 write__out_3_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  qp = qp->next;
 write__out_3_clear_reason:
  reasonp = reasons;
 write__out_3_0:
 write__out_3_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_module_3)) goto write__out_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xwrite__module__tailer_4);
  x0 = arg(a0, 0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a2;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_klic__comp__write_xwrite__predicates_6);
  x3 = arg(a0, 1);
  allocp[8] = x3;
  allocp[9] = x0;
  allocp[10] = x4 = makeref(&allocp[10]);
  x5 = arg(a0, 2);
  allocp[11] = x5;
  allocp[12] = x6 = makeref(&allocp[12]);
  allocp[13] = x2;
  a0 = x0;
  a2 = x4;
  a3 = x1;
  a4 = x5;
  a5 = a1;
  a6 = x6;
  a1 = x3;
  qp = (struct goalrec*)&allocp[6];
  allocp += 14;
  execute(write__module__header_7_0);
  goto write__module__header_7_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,write__out_3_1);
  *reasonp++ =  a0;
  goto write__out_3_interrupt;
  };
  goto write__out_3_interrupt;
 write__out_3_ext_interrupt:
  reasonp = 0l;
 write__out_3_interrupt:
  goto interrupt_3;
 }

 write__module__header_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 write__module__header_7_clear_reason:
  reasonp = reasons;
 write__module__header_7_0:
  allocp[0] = a6;
  allocp[1] = makefunctor(funct_const_1);
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__write_xwrite__pred__dispatch_3);
  allocp[4] = a1;
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = x0;
  allocp[7] = x1;
  allocp[8] = makefunctor(funct_const_3);
  x2 = makecons(&allocp[7]);
  allocp[9] = (q)(struct goalrec*)&allocp[2];
  allocp[10] = (q)(&predicate_klic__comp__write_xwrite__get__args_4);
  allocp[11] = makeint(0L);
  allocp[12] = a2;
  allocp[13] = x3 = makeref(&allocp[13]);
  allocp[14] = x2;
  allocp[15] = x3;
  allocp[16] = makefunctor(funct_const_5);
  x4 = makecons(&allocp[15]);
  allocp[17] = (q)(struct goalrec*)&allocp[9];
  allocp[18] = (q)(&predicate_klic__comp__write_xdeclare__registers_4);
  allocp[19] = a3;
  allocp[20] = makefunctor(&string_const_6);
  allocp[21] = x5 = makeref(&allocp[21]);
  allocp[22] = x4;
  allocp[23] = (q)(struct goalrec*)&allocp[17];
  allocp[24] = (q)(&predicate_klic__comp__write_xpred__min__max_5);
  allocp[25] = a1;
  allocp[26] = makeint(99999L);
  allocp[27] = a2;
  allocp[28] = makeint(0L);
  allocp[29] = a3;
  allocp[30] = (q)(struct goalrec*)&allocp[23];
  allocp[31] = (q)(&predicate_klic__comp__write_xdeclare__const_5);
  allocp[32] = a4;
  allocp[33] = makeint(0L);
  allocp[34] = x6 = makeref(&allocp[34]);
  allocp[35] = x7 = makeref(&allocp[35]);
  allocp[36] = x5;
  allocp[37] = x7;
  allocp[38] = makefunctor(funct_const_8);
  x8 = makecons(&allocp[37]);
  allocp[39] = NILATOM;
  allocp[40] = a0;
  x9 = makecons(&allocp[39]);
  allocp[41] = (q)(struct goalrec*)&allocp[30];
  allocp[42] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[43] = makefunctor(&string_const_9);
  allocp[44] = x9;
  allocp[45] = x10 = makeref(&allocp[45]);
  allocp[46] = x8;
  allocp[47] = x10;
  allocp[48] = makefunctor(funct_const_78);
  x11 = makecons(&allocp[47]);
  allocp[49] = (q)(struct goalrec*)&allocp[41];
  allocp[50] = (q)(&predicate_klic__comp__write_xdeclare__externals_3);
  allocp[51] = a4;
  allocp[52] = x12 = makeref(&allocp[52]);
  allocp[53] = x11;
  allocp[54] = (q)(struct goalrec*)&allocp[49];
  allocp[55] = (q)(&predicate_klic__comp__write_xwrite__pred__structs_4);
  allocp[56] = a1;
  allocp[57] = a0;
  allocp[58] = x13 = makeref(&allocp[58]);
  allocp[59] = x12;
  allocp[60] = NILATOM;
  allocp[61] = a0;
  x14 = makecons(&allocp[60]);
  allocp[62] = (q)(struct goalrec*)&allocp[54];
  allocp[63] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[64] = makefunctor(&string_const_10);
  allocp[65] = x14;
  allocp[66] = a5;
  allocp[67] = x13;
  qp = (struct goalrec*)&allocp[62];
  allocp += 68;
  proceed();
 write__module__header_7_ext_interrupt:
  reasonp = 0l;
 write__module__header_7_interrupt:
  toppred = &predicate_klic__comp__write_xwrite__module__header_7;
  goto interrupt_7;
 }

 declare__const_5_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 declare__const_5_clear_reason:
  reasonp = reasons;
 declare__const_5_0:
 declare__const_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 declare__const_5_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_const_2)) goto declare__const_5_9;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xdeclare__const_5);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_klic__comp__write_xdeclare__const_2F5_240_7);
  allocp[9] = x4 = makeref(&allocp[9]);
  x5 = arg(x0, 1);
  allocp[10] = x5;
  x6 = arg(x0, 0);
  allocp[11] = x6;
  allocp[12] = a1;
  allocp[13] = a3;
  allocp[14] = x2;
  allocp[15] = x3;
  a0 = x1;
  a1 = x5;
  a2 = x4;
  qp = (struct goalrec*)&allocp[7];
  allocp += 16;
  execute(find__same__const_3_0);
  goto find__same__const_3_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,declare__const_5_3);
  *reasonp++ =  x0;
  goto declare__const_5_9;
  };
  goto declare__const_5_9;
 case ATOMIC:
  if (a0 != NILATOM) goto declare__const_5_9;
  unify2(a4, a3, a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,declare__const_5_1);
  *reasonp++ =  a0;
  goto declare__const_5_9;
  };
  goto declare__const_5_9;
 declare__const_5_9:
  otherwise(declare__const_5_interrupt);
 declare__const_5_11:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(declare__const_5_0);
  goto declare__const_5_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,declare__const_5_11);
  *reasonp++ =  a0;
  goto declare__const_5_interrupt;
  };
  goto declare__const_5_interrupt;
 declare__const_5_ext_interrupt:
  reasonp = 0l;
 declare__const_5_interrupt:
  goto interrupt_5;
 }

 declare__const_2F5_240_7_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 declare__const_2F5_240_7_clear_reason:
  reasonp = reasons;
 declare__const_2F5_240_7_0:
 declare__const_2F5_240_7_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (a0 != makesym(atom_no)) goto declare__const_2F5_240_7_interrupt;
  a0 = a1;
  a1 = a2;
  a2 = a3;
  a3 = a5;
  a5 = a6;
  execute(declare__const_6_0);
  goto declare__const_6_ext_interrupt;
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_yes_1)) goto declare__const_2F5_240_7_interrupt;
  x0 = arg(a0, 0);
  unify3(a2, x0, a5, a3, a6, a4);
  proceed();
 case VARREF:
  deref_and_jump(a0,declare__const_2F5_240_7_1);
  *reasonp++ =  a0;
  goto declare__const_2F5_240_7_interrupt;
  };
  goto declare__const_2F5_240_7_interrupt;
 declare__const_2F5_240_7_ext_interrupt:
  reasonp = 0l;
 declare__const_2F5_240_7_interrupt:
  goto interrupt_7;
 }

 find__same__const_3_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  qp = qp->next;
 find__same__const_3_clear_reason:
  reasonp = reasons;
 find__same__const_3_0:
 find__same__const_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 find__same__const_3_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_const_2)) goto find__same__const_3_16;
  x1 = arg(x0, 1);
 find__same__const_3_6:
  if (isref(x1)) goto find__same__const_3_12;
 find__same__const_3_8:
  if (isref(x1)) goto find__same__const_3_11;
  if_not_equal(x1, a1, find__same__const_3_16);
  allocp[0] = makesym(functor_yes_1);
  x3 = arg(x0, 0);
  allocp[1] = x3;
  x2 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a2, x2);
  proceed();
 find__same__const_3_11:
  deref_and_jump(x1,find__same__const_3_8);
  *reasonp++ =  x1;
  goto find__same__const_3_16;
 find__same__const_3_12:
  deref_and_jump(x1,find__same__const_3_6);
  *reasonp++ =  x1;
  goto find__same__const_3_16;
 case VARREF:
  deref_and_jump(x0,find__same__const_3_3);
  *reasonp++ =  x0;
  goto find__same__const_3_16;
  };
  goto find__same__const_3_16;
 case ATOMIC:
  if (a0 != NILATOM) goto find__same__const_3_16;
  unify_value(a2, makesym(atom_no));
  proceed();
 case VARREF:
  deref_and_jump(a0,find__same__const_3_1);
  *reasonp++ =  a0;
  goto find__same__const_3_16;
  };
  goto find__same__const_3_16;
 find__same__const_3_16:
  otherwise(find__same__const_3_interrupt);
 find__same__const_3_18:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(find__same__const_3_0);
  goto find__same__const_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,find__same__const_3_18);
  *reasonp++ =  a0;
  goto find__same__const_3_interrupt;
  };
  goto find__same__const_3_interrupt;
 find__same__const_3_ext_interrupt:
  reasonp = 0l;
 find__same__const_3_interrupt:
  toppred = &predicate_klic__comp__write_xfind__same__const_3;
  goto interrupt_3;
 }

 declare__const_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 declare__const_6_clear_reason:
  reasonp = reasons;
 declare__const_6_0:
 declare__const_6_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_string_1:
  x0 = arg(a0, 0);
 declare__const_6_4:
  switch (ptagof(x0)) {
 case FUNCTOR:
 declare__const_6_5:
  if (!isgobj(x0)) goto declare__const_6_28;
 declare__const_6_6:
  gblt_is_string(x0,declare__const_6_28);
  gblt_size_of_string(x0,x1,declare__const_6_28);
  gblt_element_size_of_string(x0,x2,declare__const_6_28);
  allocp[0] = makesym(functor_string_1);
  allocp[1] = a2;
  x3 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x3);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[2] = x4 = makeref(&allocp[2]);
  allocp[3] = makeint(1L);
  allocp[4] = a3;
  a0 = x1;
  a1 = x2;
  a3 = a4;
  a4 = x4;
  a6 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(declare__const_2F6_241_7_0);
  goto declare__const_2F6_241_7_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,declare__const_6_4);
  *reasonp++ =  x0;
  goto declare__const_6_28;
  };
  goto declare__const_6_28;
 case functor_vector_1:
  x0 = arg(a0, 0);
 declare__const_6_11:
  switch (ptagof(x0)) {
 case FUNCTOR:
 declare__const_6_12:
  if (!isgobj(x0)) goto declare__const_6_28;
  if (!isclass(x0,vector)) goto declare__const_6_28;
  gblt_size_of_vector(x0,x1,declare__const_6_28);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = makeint(1L);
  allocp[4] = a3;
  a0 = x1;
  a3 = a4;
  a4 = x2;
  a6 = x0;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(declare__const_2F6_240_7_0);
  goto declare__const_2F6_240_7_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,declare__const_6_11);
  *reasonp++ =  x0;
  goto declare__const_6_28;
  };
  goto declare__const_6_28;
 case functor_float_1:
  allocp[0] = makesym(functor_float_1);
  allocp[1] = a2;
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[2] = a2;
  allocp[3] = makeint(1L);
  allocp[4] = a3;
  allocp[5] = NILATOM;
  x2 = arg(a0, 0);
  allocp[6] = x2;
  x1 = makecons(&allocp[5]);
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[9] = makefunctor(&string_const_11);
  allocp[10] = x1;
  allocp[11] = x3 = makeref(&allocp[11]);
  allocp[12] = a5;
  allocp[13] = NILATOM;
  allocp[14] = a2;
  x4 = makecons(&allocp[13]);
  allocp[15] = (q)(struct goalrec*)&allocp[7];
  allocp[16] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[17] = makefunctor(&string_const_12);
  allocp[18] = x4;
  allocp[19] = a4;
  allocp[20] = x3;
  qp = (struct goalrec*)&allocp[15];
  allocp += 21;
  proceed();
 case functor_module_1:
  allocp[0] = makesym(functor_module_1);
  allocp[1] = a2;
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[2] = a2;
  allocp[3] = makeint(1L);
  allocp[4] = a3;
  allocp[5] = NILATOM;
  x2 = arg(a0, 0);
  allocp[6] = x2;
  x1 = makecons(&allocp[5]);
  allocp[7] = x1;
  allocp[8] = x2;
  x3 = makecons(&allocp[7]);
  allocp[9] = (q)(struct goalrec*)&allocp[0];
  allocp[10] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[11] = makefunctor(&string_const_13);
  allocp[12] = x3;
  allocp[13] = x4 = makeref(&allocp[13]);
  allocp[14] = a5;
  allocp[15] = NILATOM;
  allocp[16] = a2;
  x5 = makecons(&allocp[15]);
  allocp[17] = (q)(struct goalrec*)&allocp[9];
  allocp[18] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[19] = makefunctor(&string_const_14);
  allocp[20] = x5;
  allocp[21] = x6 = makeref(&allocp[21]);
  allocp[22] = x4;
  allocp[23] = NILATOM;
  allocp[24] = x2;
  x7 = makecons(&allocp[23]);
  allocp[25] = (q)(struct goalrec*)&allocp[17];
  allocp[26] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[27] = makefunctor(&string_const_15);
  allocp[28] = x7;
  allocp[29] = a4;
  allocp[30] = x6;
  qp = (struct goalrec*)&allocp[25];
  allocp += 31;
  proceed();
 case functor_predicate_3:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = makeint(1L);
  allocp[4] = a3;
  allocp[5] = makesym(functor__2F_2);
  x2 = arg(a0, 0);
  allocp[6] = x2;
  x3 = arg(a0, 1);
  allocp[7] = x3;
  x1 = makefunctor(&allocp[5]);
  allocp[8] = makesym(functor__2F_2);
  allocp[9] = x1;
  x5 = arg(a0, 2);
  allocp[10] = x5;
  x4 = makefunctor(&allocp[8]);
  allocp[11] = NILATOM;
  allocp[12] = x3;
  x6 = makecons(&allocp[11]);
  allocp[13] = x6;
  allocp[14] = x8 = makeref(&allocp[14]);
  x7 = makecons(&allocp[13]);
  allocp[15] = x7;
  allocp[16] = x4;
  x9 = makecons(&allocp[15]);
  allocp[17] = (q)(struct goalrec*)&allocp[0];
  allocp[18] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[19] = makefunctor(&string_const_16);
  allocp[20] = x9;
  allocp[21] = x10 = makeref(&allocp[21]);
  allocp[22] = a5;
  allocp[23] = NILATOM;
  allocp[24] = x0;
  x11 = makecons(&allocp[23]);
  allocp[25] = (q)(struct goalrec*)&allocp[17];
  allocp[26] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[27] = makefunctor(&string_const_17);
  allocp[28] = x11;
  allocp[29] = x12 = makeref(&allocp[29]);
  allocp[30] = x10;
  allocp[31] = makesym(functor_predicate_1);
  allocp[32] = x0;
  x13 = makefunctor(&allocp[31]);
  qp = (struct goalrec*)&allocp[25];
  allocp += 33;
  unify_value(a1, x13);
  allocp[0] = makesym(functor_module_1);
  allocp[1] = x2;
  x14 = makefunctor(&allocp[0]);
  allocp[2] = makesym(functor_module_1);
  allocp[3] = x8;
  x15 = makefunctor(&allocp[2]);
  a0 = x14;
  a1 = x15;
  a3 = x0;
  a5 = x12;
  allocp += 4;
  execute(declare__const_6_0);
  goto declare__const_6_ext_interrupt;
 case functor_list_1:
  x0 = arg(a0, 0);
 declare__const_6_20:
  switch (ptagof(x0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = makeint(1L);
  allocp[4] = a3;
  allocp[5] = a5;
  allocp[6] = makefunctor(funct_const_30);
  x2 = makecons(&allocp[5]);
  allocp[7] = NILATOM;
  allocp[8] = x4 = makeref(&allocp[8]);
  x3 = makecons(&allocp[7]);
  allocp[9] = x3;
  allocp[10] = x6 = makeref(&allocp[10]);
  x5 = makecons(&allocp[9]);
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_klic__comp__write_xwrite__const__elems_3);
  allocp[13] = x5;
  allocp[14] = x7 = makeref(&allocp[14]);
  allocp[15] = x2;
  allocp[16] = NILATOM;
  allocp[17] = x1;
  x8 = makecons(&allocp[16]);
  allocp[18] = (q)(struct goalrec*)&allocp[11];
  allocp[19] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[20] = makefunctor(&string_const_18);
  allocp[21] = x8;
  allocp[22] = x9 = makeref(&allocp[22]);
  allocp[23] = x7;
  allocp[24] = makesym(functor_list_1);
  allocp[25] = x1;
  x10 = makefunctor(&allocp[24]);
  qp = (struct goalrec*)&allocp[18];
  allocp += 26;
  unify_value(a1, x10);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xdeclare__const_6);
  x11 = car_of(x0);
  allocp[2] = x11;
  allocp[3] = x4;
  allocp[4] = x12 = makeref(&allocp[4]);
  allocp[5] = x1;
  allocp[6] = x13 = makeref(&allocp[6]);
  allocp[7] = x9;
  a0 = cdr_of(x0);
  a1 = x6;
  a3 = x12;
  a5 = x13;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  execute(declare__const_6_0);
  goto declare__const_6_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,declare__const_6_20);
  *reasonp++ =  x0;
  goto declare__const_6_28;
  };
  goto declare__const_6_28;
 case functor_functor_1:
  x0 = arg(a0, 0);
 declare__const_6_23:
  if (isref(x0)) goto declare__const_6_27;
  gblt_pfunctor(x0,x1,declare__const_6_28);
  gblt_arity(x0,x2,declare__const_6_28);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[2] = x3 = makeref(&allocp[2]);
  allocp[3] = makeint(1L);
  allocp[4] = a3;
  allocp[5] = a5;
  allocp[6] = makefunctor(funct_const_30);
  x4 = makecons(&allocp[5]);
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_klic__comp__write_xwrite__const__elems_3);
  allocp[9] = x5 = makeref(&allocp[9]);
  allocp[10] = x6 = makeref(&allocp[10]);
  allocp[11] = x4;
  allocp[12] = makesym(functor__2F_2);
  allocp[13] = x1;
  allocp[14] = x2;
  x7 = makefunctor(&allocp[12]);
  allocp[15] = NILATOM;
  allocp[16] = x7;
  x8 = makecons(&allocp[15]);
  allocp[17] = (q)(struct goalrec*)&allocp[7];
  allocp[18] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[19] = makefunctor(&string_const_19);
  allocp[20] = x8;
  allocp[21] = x9 = makeref(&allocp[21]);
  allocp[22] = x6;
  allocp[23] = NILATOM;
  allocp[24] = x3;
  x10 = makecons(&allocp[23]);
  allocp[25] = (q)(struct goalrec*)&allocp[17];
  allocp[26] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[27] = makefunctor(&string_const_20);
  allocp[28] = x10;
  allocp[29] = x11 = makeref(&allocp[29]);
  allocp[30] = x9;
  allocp[31] = makesym(functor_functor_1);
  allocp[32] = x3;
  x12 = makefunctor(&allocp[31]);
  qp = (struct goalrec*)&allocp[25];
  allocp += 33;
  unify_value(a1, x12);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xdeclare__const__list_6);
  allocp[2] = x13 = makeref(&allocp[2]);
  allocp[3] = x5;
  allocp[4] = a2;
  allocp[5] = x3;
  allocp[6] = a4;
  allocp[7] = x11;
  allocp[8] = x13;
  allocp[9] = x1;
  x14 = makecons(&allocp[8]);
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_klic__comp__util_xuniv_2);
  allocp[12] = x0;
  allocp[13] = x14;
  qp = (struct goalrec*)&allocp[10];
  allocp += 14;
  proceed();
 declare__const_6_27:
  deref_and_jump(x0,declare__const_6_23);
  *reasonp++ =  x0;
  goto declare__const_6_28;
 default:
  goto declare__const_6_28;
  };
 case VARREF:
  deref_and_jump(a0,declare__const_6_1);
  *reasonp++ =  a0;
  goto declare__const_6_28;
  };
  goto declare__const_6_28;
 declare__const_6_28:
  otherwise(declare__const_6_interrupt);
  unify3(a5, a4, a3, a2, a1, a0);
  proceed();
 declare__const_6_ext_interrupt:
  reasonp = 0l;
 declare__const_6_interrupt:
  toppred = &predicate_klic__comp__write_xdeclare__const_6;
  goto interrupt_6;
 }

 declare__const_2F6_241_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 declare__const_2F6_241_7_clear_reason:
  reasonp = reasons;
 declare__const_2F6_241_7_0:
 declare__const_2F6_241_7_1:
  if (!isint(a0)) goto declare__const_2F6_241_7_6;
  gblt_eq(a0,makeint(0L),declare__const_2F6_241_7_4);
  unify(a4, a2);
  allocp[0] = NILATOM;
  allocp[1] = a1;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_21);
  allocp[5] = x0;
  allocp[6] = x1 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = NILATOM;
  allocp[9] = a2;
  x2 = makecons(&allocp[8]);
  allocp[10] = x2;
  allocp[11] = a1;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)(struct goalrec*)&allocp[2];
  allocp[13] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[14] = makefunctor(&string_const_23);
  allocp[15] = x3;
  allocp[16] = a3;
  allocp[17] = x1;
  qp = (struct goalrec*)&allocp[12];
  allocp += 18;
  proceed();
 declare__const_2F6_241_7_4:
  gblt_greater(a0,makeint(0L),declare__const_2F6_241_7_interrupt);
  bblt_add_no_check(a0,makeint(3L),x0);
  bblt_div_no_check(x0,makeint(4L),x1);
  bblt_mult_no_check(x1,makeint(4L),x2);
  unify(a4, a2);
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x3 = makecons(&allocp[0]);
  allocp[2] = x3;
  allocp[3] = a2;
  x4 = makecons(&allocp[2]);
  allocp[4] = x4;
  allocp[5] = a1;
  x5 = makecons(&allocp[4]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[8] = makefunctor(&string_const_22);
  allocp[9] = x5;
  allocp[10] = x6 = makeref(&allocp[10]);
  allocp[11] = a5;
  allocp[12] = NILATOM;
  allocp[13] = a2;
  x7 = makecons(&allocp[12]);
  allocp[14] = x7;
  allocp[15] = a1;
  x8 = makecons(&allocp[14]);
  allocp[16] = (q)(struct goalrec*)&allocp[6];
  allocp[17] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[18] = makefunctor(&string_const_23);
  allocp[19] = x8;
  allocp[20] = x9 = makeref(&allocp[20]);
  allocp[21] = x6;
  allocp[22] = x9;
  allocp[23] = makefunctor(funct_const_70);
  x10 = makecons(&allocp[22]);
  allocp[24] = (q)(struct goalrec*)&allocp[16];
  allocp[25] = (q)(&predicate_klic__comp__write_xwrite__string__body_4);
  allocp[26] = a0;
  allocp[27] = a6;
  allocp[28] = x11 = makeref(&allocp[28]);
  allocp[29] = x10;
  allocp[30] = NILATOM;
  allocp[31] = x2;
  x12 = makecons(&allocp[30]);
  allocp[32] = x12;
  allocp[33] = a2;
  x13 = makecons(&allocp[32]);
  allocp[34] = (q)(struct goalrec*)&allocp[24];
  allocp[35] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[36] = makefunctor(&string_const_24);
  allocp[37] = x13;
  allocp[38] = a3;
  allocp[39] = x11;
  qp = (struct goalrec*)&allocp[34];
  allocp += 40;
  proceed();
 declare__const_2F6_241_7_6:
  if (!isref(a0)) goto declare__const_2F6_241_7_interrupt;
  deref_and_jump(a0,declare__const_2F6_241_7_1);
  *reasonp++ =  a0;
  goto declare__const_2F6_241_7_interrupt;
 declare__const_2F6_241_7_ext_interrupt:
  reasonp = 0l;
 declare__const_2F6_241_7_interrupt:
  toppred = &predicate_klic__comp__write_xdeclare__const_2F6_241_7;
  goto interrupt_7;
 }

 declare__const_2F6_240_7_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  a6 = qp->args[6];
  qp = qp->next;
 declare__const_2F6_240_7_clear_reason:
  reasonp = reasons;
 declare__const_2F6_240_7_0:
 declare__const_2F6_240_7_1:
  if (!isint(a0)) goto declare__const_2F6_240_7_6;
  gblt_eq(a0,makeint(0L),declare__const_2F6_240_7_4);
  allocp[0] = makesym(functor_vector_1);
  allocp[1] = a2;
  x0 = makefunctor(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  unify(a4, a2);
  allocp[0] = a5;
  allocp[1] = makefunctor(funct_const_26);
  x1 = makecons(&allocp[0]);
  allocp[2] = NILATOM;
  allocp[3] = a2;
  x2 = makecons(&allocp[2]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[6] = makefunctor(&string_const_28);
  allocp[7] = x2;
  allocp[8] = a3;
  allocp[9] = x1;
  qp = (struct goalrec*)&allocp[4];
  allocp += 10;
  proceed();
 declare__const_2F6_240_7_4:
  gblt_greater(a0,makeint(0L),declare__const_2F6_240_7_interrupt);
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a4;
  x1 = makecons(&allocp[2]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[6] = makefunctor(&string_const_27);
  allocp[7] = x1;
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = a5;
  allocp[10] = NILATOM;
  allocp[11] = a4;
  x3 = makecons(&allocp[10]);
  allocp[12] = (q)(struct goalrec*)&allocp[4];
  allocp[13] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[14] = makefunctor(&string_const_28);
  allocp[15] = x3;
  allocp[16] = x4 = makeref(&allocp[16]);
  allocp[17] = x2;
  allocp[18] = x4;
  allocp[19] = makefunctor(funct_const_30);
  x5 = makecons(&allocp[18]);
  allocp[20] = (q)(struct goalrec*)&allocp[12];
  allocp[21] = (q)(&predicate_klic__comp__write_xwrite__const__elems_3);
  allocp[22] = x6 = makeref(&allocp[22]);
  allocp[23] = x7 = makeref(&allocp[23]);
  allocp[24] = x5;
  allocp[25] = NILATOM;
  allocp[26] = a4;
  x8 = makecons(&allocp[25]);
  allocp[27] = (q)(struct goalrec*)&allocp[20];
  allocp[28] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[29] = makefunctor(&string_const_31);
  allocp[30] = x8;
  allocp[31] = x9 = makeref(&allocp[31]);
  allocp[32] = x7;
  allocp[33] = makesym(functor_vector_1);
  allocp[34] = a4;
  x10 = makefunctor(&allocp[33]);
  qp = (struct goalrec*)&allocp[27];
  allocp += 35;
  unify_value(a1, x10);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xdeclare__const__list_6);
  allocp[2] = x11 = makeref(&allocp[2]);
  allocp[3] = x6;
  allocp[4] = a2;
  allocp[5] = a4;
  allocp[6] = a3;
  allocp[7] = x9;
  allocp[8] = (q)(struct goalrec*)&allocp[0];
  allocp[9] = (q)(&predicate_klic__comp__util_xvector__to__list_4);
  allocp[10] = makeint(0L);
  allocp[11] = a0;
  allocp[12] = a6;
  allocp[13] = x11;
  qp = (struct goalrec*)&allocp[8];
  allocp += 14;
  proceed();
 declare__const_2F6_240_7_6:
  if (!isref(a0)) goto declare__const_2F6_240_7_interrupt;
  deref_and_jump(a0,declare__const_2F6_240_7_1);
  *reasonp++ =  a0;
  goto declare__const_2F6_240_7_interrupt;
 declare__const_2F6_240_7_ext_interrupt:
  reasonp = 0l;
 declare__const_2F6_240_7_interrupt:
  toppred = &predicate_klic__comp__write_xdeclare__const_2F6_240_7;
  goto interrupt_7;
 }

 declare__const__list_6_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 declare__const__list_6_clear_reason:
  reasonp = reasons;
 declare__const__list_6_0:
 declare__const__list_6_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = x2 = makeref(&allocp[1]);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xdeclare__const__list_6);
  x3 = cdr_of(a0);
  allocp[2] = x3;
  allocp[3] = x1;
  allocp[4] = x4 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = x5 = makeref(&allocp[6]);
  allocp[7] = a5;
  a0 = car_of(a0);
  a1 = x2;
  a3 = x4;
  a5 = x5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 8;
  execute(declare__const_6_0);
  goto declare__const_6_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto declare__const__list_6_interrupt;
  unify2(a5, a4, a3, a2);
  unify_value(a1, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a0,declare__const__list_6_1);
  *reasonp++ =  a0;
  goto declare__const__list_6_interrupt;
  };
  goto declare__const__list_6_interrupt;
 declare__const__list_6_ext_interrupt:
  reasonp = 0l;
 declare__const__list_6_interrupt:
  goto interrupt_6;
 }

 write__const__elems_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 write__const__elems_3_clear_reason:
  reasonp = reasons;
 write__const__elems_3_0:
 write__const__elems_3_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xwrite__const__elems_3);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  a0 = car_of(a0);
  a2 = x1;
  qp = (struct goalrec*)&allocp[0];
  allocp += 5;
  execute(write__const__elem_3_0);
  goto write__const__elem_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto write__const__elems_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,write__const__elems_3_1);
  *reasonp++ =  a0;
  goto write__const__elems_3_interrupt;
  };
  goto write__const__elems_3_interrupt;
 write__const__elems_3_ext_interrupt:
  reasonp = 0l;
 write__const__elems_3_interrupt:
  goto interrupt_3;
 }

 write__const__elem_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 write__const__elem_3_clear_reason:
  reasonp = reasons;
 write__const__elem_3_0:
 write__const__elem_3_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_atom_1:
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_32);
  allocp[5] = x0;
  allocp[6] = a1;
  allocp[7] = a2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 case functor_integer_1:
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_33);
  allocp[5] = x0;
  allocp[6] = a1;
  allocp[7] = a2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 case functor_float_1:
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_34);
  allocp[5] = x0;
  allocp[6] = a1;
  allocp[7] = a2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 case functor_predicate_1:
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_35);
  allocp[5] = x0;
  allocp[6] = a1;
  allocp[7] = a2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 case functor_module_1:
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_36);
  allocp[5] = x0;
  allocp[6] = a1;
  allocp[7] = a2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 case functor_list_1:
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_37);
  allocp[5] = x0;
  allocp[6] = a1;
  allocp[7] = a2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 case functor_functor_1:
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_38);
  allocp[5] = x0;
  allocp[6] = a1;
  allocp[7] = a2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 case functor_string_1:
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_39);
  allocp[5] = x0;
  allocp[6] = a1;
  allocp[7] = a2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 case functor_vector_1:
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_40);
  allocp[5] = x0;
  allocp[6] = a1;
  allocp[7] = a2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 default:
  goto write__const__elem_3_interrupt;
  };
 case VARREF:
  deref_and_jump(a0,write__const__elem_3_1);
  *reasonp++ =  a0;
  goto write__const__elem_3_interrupt;
  };
  goto write__const__elem_3_interrupt;
 write__const__elem_3_ext_interrupt:
  reasonp = 0l;
 write__const__elem_3_interrupt:
  toppred = &predicate_klic__comp__write_xwrite__const__elem_3;
  goto interrupt_3;
 }

 write__string__body_4_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 write__string__body_4_clear_reason:
  reasonp = reasons;
 write__string__body_4_0:
 write__string__body_4_1:
  if (!isint(a0)) goto write__string__body_4_7;
  gblt_modulo(a0,makeint(4L),x0,write__string__body_4_interrupt);
  gblt_not_eq(x0,makeint(0L),write__string__body_4_5);
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = makefunctor(funct_const_42);
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x1);
  allocp[0] = a3;
  allocp[1] = makefunctor(funct_const_42);
  x3 = makecons(&allocp[0]);
  x4 = a0;
  a2 = a1;
  a3 = x2;
  a4 = x3;
  a1 = x4;
  a0 = makeint(0L);
  allocp += 2;
  execute(write__string__elements_5_0);
  goto write__string__elements_5_ext_interrupt;
 write__string__body_4_5:
  gblt_eq(x0,makeint(0L),write__string__body_4_interrupt);
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = makefunctor(funct_const_44);
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x1);
  allocp[0] = a3;
  allocp[1] = makefunctor(funct_const_46);
  x3 = makecons(&allocp[0]);
  x4 = a0;
  a2 = a1;
  a3 = x2;
  a4 = x3;
  a1 = x4;
  a0 = makeint(0L);
  allocp += 2;
  execute(write__character__constants_5_0);
  goto write__character__constants_5_ext_interrupt;
 write__string__body_4_7:
  if (!isref(a0)) goto write__string__body_4_interrupt;
  deref_and_jump(a0,write__string__body_4_1);
  *reasonp++ =  a0;
  goto write__string__body_4_interrupt;
 write__string__body_4_ext_interrupt:
  reasonp = 0l;
 write__string__body_4_interrupt:
  goto interrupt_4;
 }

 write__character__constants_5_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 write__character__constants_5_clear_reason:
  reasonp = reasons;
 write__character__constants_5_0:
 write__character__constants_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (!isint(a0)) goto write__character__constants_5_13;
 write__character__constants_5_3:
 write__character__constants_5_4:
  if (!isint(a1)) goto write__character__constants_5_12;
  gblt_less(a0,a1,write__character__constants_5_13);
 write__character__constants_5_7:
  switch (ptagof(a2)) {
 case FUNCTOR:
 write__character__constants_5_8:
  if (!isgobj(a2)) goto write__character__constants_5_13;
 write__character__constants_5_9:
  generic_arg[0] = a0;
  guard_generic(a2, functor_element_2, 1, write__character__constants_5_13);
  x0 = generic_arg[1];
  gblt_add(a0,makeint(1L),x1,write__character__constants_5_13);
  allocp[0] = x3 = makeref(&allocp[0]);
  allocp[1] = makefunctor(funct_const_48);
  x2 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a3, x2);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xwrite__character__constants_5);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x4 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = x4;
  allocp[8] = makefunctor(funct_const_50);
  x5 = makecons(&allocp[7]);
  a0 = x0;
  a1 = x3;
  a2 = x5;
  qp = (struct goalrec*)&allocp[0];
  allocp += 9;
  execute(write__string__element_3_0);
  goto write__string__element_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,write__character__constants_5_7);
  *reasonp++ =  a2;
  goto write__character__constants_5_13;
  };
  goto write__character__constants_5_13;
 write__character__constants_5_12:
  if (!isref(a1)) goto write__character__constants_5_13;
  deref_and_jump(a1,write__character__constants_5_4);
  *reasonp++ =  a1;
  goto write__character__constants_5_13;
 case VARREF:
  deref_and_jump(a0,write__character__constants_5_1);
  *reasonp++ =  a0;
  goto write__character__constants_5_interrupt;
  };
  goto write__character__constants_5_13;
 write__character__constants_5_13:
 write__character__constants_5_14:
  if (isref(a0)) goto write__character__constants_5_17;
  if_not_equal(a0, a1, write__character__constants_5_interrupt);
  unify(a4, a3);
  proceed();
 write__character__constants_5_17:
  deref_and_jump(a0,write__character__constants_5_14);
  *reasonp++ =  a0;
  goto write__character__constants_5_interrupt;
 write__character__constants_5_ext_interrupt:
  reasonp = 0l;
 write__character__constants_5_interrupt:
  toppred = &predicate_klic__comp__write_xwrite__character__constants_5;
  goto interrupt_5;
 }

 write__string__elements_5_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 write__string__elements_5_clear_reason:
  reasonp = reasons;
 write__string__elements_5_0:
 write__string__elements_5_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (!isint(a0)) goto write__string__elements_5_13;
 write__string__elements_5_3:
 write__string__elements_5_4:
  if (!isint(a1)) goto write__string__elements_5_12;
  gblt_less(a0,a1,write__string__elements_5_13);
 write__string__elements_5_7:
  switch (ptagof(a2)) {
 case FUNCTOR:
 write__string__elements_5_8:
  if (!isgobj(a2)) goto write__string__elements_5_13;
 write__string__elements_5_9:
  generic_arg[0] = a0;
  guard_generic(a2, functor_element_2, 1, write__string__elements_5_13);
  x0 = generic_arg[1];
  gblt_add(a0,makeint(1L),x1,write__string__elements_5_13);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xwrite__string__elements_5);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x2 = makeref(&allocp[5]);
  allocp[6] = a4;
  a0 = x0;
  a1 = a3;
  a2 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 7;
  execute(write__string__element_3_0);
  goto write__string__element_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,write__string__elements_5_7);
  *reasonp++ =  a2;
  goto write__string__elements_5_13;
  };
  goto write__string__elements_5_13;
 write__string__elements_5_12:
  if (!isref(a1)) goto write__string__elements_5_13;
  deref_and_jump(a1,write__string__elements_5_4);
  *reasonp++ =  a1;
  goto write__string__elements_5_13;
 case VARREF:
  deref_and_jump(a0,write__string__elements_5_1);
  *reasonp++ =  a0;
  goto write__string__elements_5_interrupt;
  };
  goto write__string__elements_5_13;
 write__string__elements_5_13:
 write__string__elements_5_14:
  if (isref(a0)) goto write__string__elements_5_17;
  if_not_equal(a0, a1, write__string__elements_5_interrupt);
  unify(a4, a3);
  proceed();
 write__string__elements_5_17:
  deref_and_jump(a0,write__string__elements_5_14);
  *reasonp++ =  a0;
  goto write__string__elements_5_interrupt;
 write__string__elements_5_ext_interrupt:
  reasonp = 0l;
 write__string__elements_5_interrupt:
  toppred = &predicate_klic__comp__write_xwrite__string__elements_5;
  goto interrupt_5;
 }

 write__string__element_3_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  qp = qp->next;
 write__string__element_3_clear_reason:
  reasonp = reasons;
 write__string__element_3_0:
 write__string__element_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
 write__string__element_3_3:
  switch ((unsigned long)a0) {
 case (unsigned long) makeint(34L):
  allocp[0] = a2;
  allocp[1] = makefunctor(funct_const_52);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  proceed();
 case (unsigned long) makeint(39L):
  allocp[0] = a2;
  allocp[1] = makefunctor(funct_const_54);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  proceed();
 case (unsigned long) makeint(92L):
  allocp[0] = a2;
  allocp[1] = makefunctor(funct_const_56);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  proceed();
 case (unsigned long) makeint(10L):
  allocp[0] = a2;
  allocp[1] = makefunctor(funct_const_58);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  proceed();
 case (unsigned long) makeint(9L):
  allocp[0] = a2;
  allocp[1] = makefunctor(funct_const_60);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  proceed();
 case (unsigned long) makeint(32L):
  allocp[0] = a2;
  allocp[1] = makefunctor(funct_const_62);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  proceed();
 default:
  goto write__string__element_3_10;
  };
 case VARREF:
  deref_and_jump(a0,write__string__element_3_1);
  *reasonp++ =  a0;
  goto write__string__element_3_10;
  };
  goto write__string__element_3_10;
 write__string__element_3_10:
  otherwise(write__string__element_3_interrupt);
 write__string__element_3_12:
  if (!isint(a0)) goto write__string__element_3_15;
  
{
   int c = intval(a0);
   if (!isgraph(c)) goto write__string__element_3_16;
}
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_63);
  allocp[5] = x0;
  allocp[6] = a1;
  allocp[7] = a2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 write__string__element_3_15:
  if (!isref(a0)) goto write__string__element_3_16;
  deref_and_jump(a0,write__string__element_3_12);
  *reasonp++ =  a0;
  goto write__string__element_3_16;
 write__string__element_3_16:
  otherwise(write__string__element_3_interrupt);
  bblt_div_no_check_y(a0,makeint(64L),x0);
  bblt_mod_no_check(makeint(8L),makeint(8L),x1);
  bblt_div_no_check_y(a0,x1,x2);
  bblt_mod_no_check_y(a0,makeint(8L),x3);
  allocp[0] = NILATOM;
  allocp[1] = x3;
  x4 = makecons(&allocp[0]);
  allocp[2] = x4;
  allocp[3] = x2;
  x5 = makecons(&allocp[2]);
  allocp[4] = x5;
  allocp[5] = x0;
  x6 = makecons(&allocp[4]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[8] = makefunctor(&string_const_64);
  allocp[9] = x6;
  allocp[10] = a1;
  allocp[11] = a2;
  qp = (struct goalrec*)&allocp[6];
  allocp += 12;
  proceed();
 write__string__element_3_ext_interrupt:
  reasonp = 0l;
 write__string__element_3_interrupt:
  toppred = &predicate_klic__comp__write_xwrite__string__element_3;
  goto interrupt_3;
 }

 write__pred__structs_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 write__pred__structs_4_clear_reason:
  reasonp = reasons;
 write__pred__structs_4_0:
 write__pred__structs_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 write__pred__structs_4_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_5)) goto write__pred__structs_4_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xwrite__pred__structs_4);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = NILATOM;
  x4 = arg(x0, 1);
  allocp[7] = x4;
  x3 = makecons(&allocp[6]);
  allocp[8] = x3;
  x6 = arg(x0, 2);
  allocp[9] = x6;
  x5 = makecons(&allocp[8]);
  allocp[10] = x5;
  allocp[11] = a1;
  x7 = makecons(&allocp[10]);
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[14] = makefunctor(&string_const_65);
  allocp[15] = x7;
  allocp[16] = x8 = makeref(&allocp[16]);
  allocp[17] = x2;
  allocp[18] = makesym(functor__2F_2);
  allocp[19] = a1;
  x10 = arg(x0, 0);
  allocp[20] = x10;
  x9 = makefunctor(&allocp[18]);
  allocp[21] = makesym(functor__2F_2);
  allocp[22] = x9;
  allocp[23] = x4;
  x11 = makefunctor(&allocp[21]);
  allocp[24] = NILATOM;
  allocp[25] = x11;
  x12 = makecons(&allocp[24]);
  allocp[26] = (q)(struct goalrec*)&allocp[12];
  allocp[27] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[28] = makefunctor(&string_const_66);
  allocp[29] = x12;
  allocp[30] = a2;
  allocp[31] = x8;
  qp = (struct goalrec*)&allocp[26];
  allocp += 32;
  proceed();
 case VARREF:
  deref_and_jump(x0,write__pred__structs_4_3);
  *reasonp++ =  x0;
  goto write__pred__structs_4_interrupt;
  };
  goto write__pred__structs_4_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto write__pred__structs_4_interrupt;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,write__pred__structs_4_1);
  *reasonp++ =  a0;
  goto write__pred__structs_4_interrupt;
  };
  goto write__pred__structs_4_interrupt;
 write__pred__structs_4_ext_interrupt:
  reasonp = 0l;
 write__pred__structs_4_interrupt:
  goto interrupt_4;
 }

 declare__externals_3_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  qp = qp->next;
 declare__externals_3_clear_reason:
  reasonp = reasons;
 declare__externals_3_0:
 declare__externals_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 declare__externals_3_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  switch (symval(functor_of(x0))) {
 case functor_ext_1:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xdeclare__externals_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_klic__comp__write_xdeclare__externals__ext_4);
  allocp[7] = x3 = makeref(&allocp[7]);
  x4 = arg(x0, 0);
  allocp[8] = x4;
  allocp[9] = a1;
  allocp[10] = x2;
  allocp[11] = makesym(functor_ext_1);
  allocp[12] = x4;
  x5 = makefunctor(&allocp[11]);
  allocp[13] = (q)(struct goalrec*)&allocp[5];
  allocp[14] = (q)(&predicate_klic__comp__util_xmember_3);
  allocp[15] = x1;
  allocp[16] = x5;
  allocp[17] = x3;
  qp = (struct goalrec*)&allocp[13];
  allocp += 18;
  proceed();
 case functor_gnew_1:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xdeclare__externals_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_klic__comp__write_xdeclare__externals__gnew_4);
  allocp[7] = x3 = makeref(&allocp[7]);
  x4 = arg(x0, 0);
  allocp[8] = x4;
  allocp[9] = a1;
  allocp[10] = x2;
  allocp[11] = makesym(functor_gnew_1);
  allocp[12] = x4;
  x5 = makefunctor(&allocp[11]);
  allocp[13] = (q)(struct goalrec*)&allocp[5];
  allocp[14] = (q)(&predicate_klic__comp__util_xmember_3);
  allocp[15] = x1;
  allocp[16] = x5;
  allocp[17] = x3;
  qp = (struct goalrec*)&allocp[13];
  allocp += 18;
  proceed();
 default:
  goto declare__externals_3_10;
  };
 case VARREF:
  deref_and_jump(x0,declare__externals_3_3);
  *reasonp++ =  x0;
  goto declare__externals_3_10;
  };
  goto declare__externals_3_10;
 case ATOMIC:
  if (a0 != NILATOM) goto declare__externals_3_10;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,declare__externals_3_1);
  *reasonp++ =  a0;
  goto declare__externals_3_10;
  };
  goto declare__externals_3_10;
 declare__externals_3_10:
  otherwise(declare__externals_3_interrupt);
 declare__externals_3_12:
  switch (ptagof(a0)) {
 case CONS:
  a0 = cdr_of(a0);
  execute(declare__externals_3_0);
  goto declare__externals_3_ext_interrupt;
 case VARREF:
  deref_and_jump(a0,declare__externals_3_12);
  *reasonp++ =  a0;
  goto declare__externals_3_interrupt;
  };
  goto declare__externals_3_interrupt;
 declare__externals_3_ext_interrupt:
  reasonp = 0l;
 declare__externals_3_interrupt:
  goto interrupt_3;
 }

 declare__externals__ext_4_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 declare__externals__ext_4_clear_reason:
  reasonp = reasons;
 declare__externals__ext_4_0:
 declare__externals__ext_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto declare__externals__ext_4_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  unify(a3, a2);
  proceed();
 case symval(makesym(atom_no)):
  allocp[0] = NILATOM;
  allocp[1] = a1;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_67);
  allocp[5] = x0;
  allocp[6] = a2;
  allocp[7] = a3;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 default:
  goto declare__externals__ext_4_interrupt;
  };
 case VARREF:
  deref_and_jump(a0,declare__externals__ext_4_1);
  *reasonp++ =  a0;
  goto declare__externals__ext_4_interrupt;
  };
  goto declare__externals__ext_4_interrupt;
 declare__externals__ext_4_ext_interrupt:
  reasonp = 0l;
 declare__externals__ext_4_interrupt:
  goto interrupt_4;
 }

 declare__externals__gnew_4_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 declare__externals__gnew_4_clear_reason:
  reasonp = reasons;
 declare__externals__gnew_4_0:
 declare__externals__gnew_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto declare__externals__gnew_4_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  unify(a3, a2);
  proceed();
 case symval(makesym(atom_no)):
  allocp[0] = NILATOM;
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_68);
  allocp[5] = x0;
  allocp[6] = a2;
  allocp[7] = a3;
  allocp[8] = (q)(struct goalrec*)&allocp[2];
  allocp[9] = (q)(&predicate_klic__comp__write_xmake__atom__name__string_2);
  allocp[10] = x2 = makeref(&allocp[10]);
  allocp[11] = x1;
  allocp[12] = (q)(struct goalrec*)&allocp[8];
  allocp[13] = (q)(&predicate_klic__comp__util_xname_2);
  allocp[14] = a1;
  allocp[15] = x2;
  qp = (struct goalrec*)&allocp[12];
  allocp += 16;
  proceed();
 default:
  goto declare__externals__gnew_4_interrupt;
  };
 case VARREF:
  deref_and_jump(a0,declare__externals__gnew_4_1);
  *reasonp++ =  a0;
  goto declare__externals__gnew_4_interrupt;
  };
  goto declare__externals__gnew_4_interrupt;
 declare__externals__gnew_4_ext_interrupt:
  reasonp = 0l;
 declare__externals__gnew_4_interrupt:
  goto interrupt_4;
 }

 pred__min__max_5_top: {
  q x0, x1, x2, x3, x4;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 pred__min__max_5_clear_reason:
  reasonp = reasons;
 pred__min__max_5_0:
 pred__min__max_5_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 pred__min__max_5_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_5)) goto pred__min__max_5_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xpred__min__max_5);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = x3 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_klic__comp__util_xmax_3);
  x4 = arg(x0, 1);
  allocp[9] = x4;
  allocp[10] = a3;
  allocp[11] = x3;
  allocp[12] = (q)(struct goalrec*)&allocp[7];
  allocp[13] = (q)(&predicate_klic__comp__util_xmin_3);
  allocp[14] = x4;
  allocp[15] = a1;
  allocp[16] = x2;
  qp = (struct goalrec*)&allocp[12];
  allocp += 17;
  proceed();
 case VARREF:
  deref_and_jump(x0,pred__min__max_5_3);
  *reasonp++ =  x0;
  goto pred__min__max_5_interrupt;
  };
  goto pred__min__max_5_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto pred__min__max_5_interrupt;
  unify2(a2, a1, a4, a3);
  proceed();
 case VARREF:
  deref_and_jump(a0,pred__min__max_5_1);
  *reasonp++ =  a0;
  goto pred__min__max_5_interrupt;
  };
  goto pred__min__max_5_interrupt;
 pred__min__max_5_ext_interrupt:
  reasonp = 0l;
 pred__min__max_5_interrupt:
  goto interrupt_5;
 }

 declare__registers_4_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 declare__registers_4_clear_reason:
  reasonp = reasons;
 declare__registers_4_0:
 declare__registers_4_1:
  if (!isint(a0)) goto declare__registers_4_6;
  gblt_greater(a0,makeint(0L),declare__registers_4_4);
  allocp[0] = a3;
  allocp[1] = makefunctor(funct_const_70);
  x0 = makecons(&allocp[0]);
  a3 = a2;
  a4 = x0;
  a2 = makefunctor(&string_const_71);
  allocp += 2;
  execute(write__comma__list_5_0);
  goto write__comma__list_5_ext_interrupt;
 declare__registers_4_4:
  if (a0 != makeint(0L)) goto declare__registers_4_interrupt;
  unify(a3, a2);
  proceed();
 declare__registers_4_6:
  if (!isref(a0)) goto declare__registers_4_interrupt;
  deref_and_jump(a0,declare__registers_4_1);
  *reasonp++ =  a0;
  goto declare__registers_4_interrupt;
 declare__registers_4_ext_interrupt:
  reasonp = 0l;
 declare__registers_4_interrupt:
  goto interrupt_4;
 }

 write__comma__list_5_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 write__comma__list_5_clear_reason:
  reasonp = reasons;
 write__comma__list_5_0:
 write__comma__list_5_1:
  if (!isint(a0)) goto write__comma__list_5_6;
  gblt_greater(a0,makeint(0L),write__comma__list_5_4);
  bblt_sub_no_check(a0,makeint(1L),x0);
  allocp[0] = NILATOM;
  allocp[1] = x0;
  x1 = makecons(&allocp[0]);
  allocp[2] = x1;
  allocp[3] = a1;
  x2 = makecons(&allocp[2]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[6] = makefunctor(&string_const_72);
  allocp[7] = x2;
  allocp[8] = x3 = makeref(&allocp[8]);
  allocp[9] = a4;
  allocp[10] = (q)(struct goalrec*)&allocp[4];
  allocp[11] = (q)(&predicate_klic__comp__write_xwrite__comma__list1_5);
  allocp[12] = makeint(0L);
  allocp[13] = x0;
  allocp[14] = a1;
  allocp[15] = x4 = makeref(&allocp[15]);
  allocp[16] = x3;
  allocp[17] = NILATOM;
  allocp[18] = a2;
  x5 = makecons(&allocp[17]);
  allocp[19] = (q)(struct goalrec*)&allocp[10];
  allocp[20] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[21] = makefunctor(&string_const_73);
  allocp[22] = x5;
  allocp[23] = a3;
  allocp[24] = x4;
  qp = (struct goalrec*)&allocp[19];
  allocp += 25;
  proceed();
 write__comma__list_5_4:
  if (a0 != makeint(0L)) goto write__comma__list_5_interrupt;
  unify(a4, a3);
  proceed();
 write__comma__list_5_6:
  if (!isref(a0)) goto write__comma__list_5_interrupt;
  deref_and_jump(a0,write__comma__list_5_1);
  *reasonp++ =  a0;
  goto write__comma__list_5_interrupt;
 write__comma__list_5_ext_interrupt:
  reasonp = 0l;
 write__comma__list_5_interrupt:
  toppred = &predicate_klic__comp__write_xwrite__comma__list_5;
  goto interrupt_5;
 }

 write__comma__list1_5_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 write__comma__list1_5_clear_reason:
  reasonp = reasons;
 write__comma__list1_5_0:
 write__comma__list1_5_1:
  if (!isint(a0)) goto write__comma__list1_5_9;
 write__comma__list1_5_3:
  if (!isint(a1)) goto write__comma__list1_5_8;
  gblt_eq(a0,a1,write__comma__list1_5_6);
  unify(a4, a3);
  proceed();
 write__comma__list1_5_6:
  gblt_less(a0,a1,write__comma__list1_5_interrupt);
  bblt_add_no_check(a0,makeint(1L),x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xwrite__comma__list1_5);
  allocp[2] = x0;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = x1 = makeref(&allocp[5]);
  allocp[6] = a4;
  allocp[7] = NILATOM;
  allocp[8] = a0;
  x2 = makecons(&allocp[7]);
  allocp[9] = x2;
  allocp[10] = a2;
  x3 = makecons(&allocp[9]);
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[13] = makefunctor(&string_const_74);
  allocp[14] = x3;
  allocp[15] = a3;
  allocp[16] = x1;
  qp = (struct goalrec*)&allocp[11];
  allocp += 17;
  proceed();
 write__comma__list1_5_8:
  if (!isref(a1)) goto write__comma__list1_5_interrupt;
  deref_and_jump(a1,write__comma__list1_5_3);
  *reasonp++ =  a1;
  goto write__comma__list1_5_interrupt;
 write__comma__list1_5_9:
  if (!isref(a0)) goto write__comma__list1_5_interrupt;
  deref_and_jump(a0,write__comma__list1_5_1);
  *reasonp++ =  a0;
  goto write__comma__list1_5_interrupt;
 write__comma__list1_5_ext_interrupt:
  reasonp = 0l;
 write__comma__list1_5_interrupt:
  goto interrupt_5;
 }

 write__pred__dispatch_3_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8;
  a2 = qp->args[2];
  qp = qp->next;
 write__pred__dispatch_3_clear_reason:
  reasonp = reasons;
 write__pred__dispatch_3_0:
 write__pred__dispatch_3_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 write__pred__dispatch_3_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_5)) goto write__pred__dispatch_3_10;
  x1 = cdr_of(a0);
 write__pred__dispatch_3_6:
  switch (ptagof(x1)) {
 case ATOMIC:
  if (x1 != NILATOM) goto write__pred__dispatch_3_10;
  allocp[0] = NILATOM;
  x3 = arg(x0, 1);
  allocp[1] = x3;
  x2 = makecons(&allocp[0]);
  allocp[2] = x2;
  x5 = arg(x0, 0);
  allocp[3] = x5;
  x4 = makecons(&allocp[2]);
  allocp[4] = x4;
  x7 = arg(x0, 2);
  allocp[5] = x7;
  x6 = makecons(&allocp[4]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[8] = makefunctor(&string_const_75);
  allocp[9] = x6;
  allocp[10] = a1;
  allocp[11] = a2;
  qp = (struct goalrec*)&allocp[6];
  allocp += 12;
  proceed();
 case VARREF:
  deref_and_jump(x1,write__pred__dispatch_3_6);
  *reasonp++ =  x1;
  goto write__pred__dispatch_3_10;
  };
  goto write__pred__dispatch_3_10;
 case VARREF:
  deref_and_jump(x0,write__pred__dispatch_3_3);
  *reasonp++ =  x0;
  goto write__pred__dispatch_3_10;
  };
  goto write__pred__dispatch_3_10;
 case VARREF:
  deref_and_jump(a0,write__pred__dispatch_3_1);
  *reasonp++ =  a0;
  goto write__pred__dispatch_3_10;
  };
  goto write__pred__dispatch_3_10;
 write__pred__dispatch_3_10:
  otherwise(write__pred__dispatch_3_interrupt);
 write__pred__dispatch_3_12:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 write__pred__dispatch_3_14:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_5)) goto write__pred__dispatch_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xwrite__pred__dispatch_3);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = x2 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = NILATOM;
  x4 = arg(x0, 1);
  allocp[6] = x4;
  x3 = makecons(&allocp[5]);
  allocp[7] = x3;
  x6 = arg(x0, 0);
  allocp[8] = x6;
  x5 = makecons(&allocp[7]);
  allocp[9] = x5;
  x8 = arg(x0, 2);
  allocp[10] = x8;
  x7 = makecons(&allocp[9]);
  allocp[11] = (q)(struct goalrec*)&allocp[0];
  allocp[12] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[13] = makefunctor(&string_const_76);
  allocp[14] = x7;
  allocp[15] = a1;
  allocp[16] = x2;
  qp = (struct goalrec*)&allocp[11];
  allocp += 17;
  proceed();
 case VARREF:
  deref_and_jump(x0,write__pred__dispatch_3_14);
  *reasonp++ =  x0;
  goto write__pred__dispatch_3_interrupt;
  };
  goto write__pred__dispatch_3_interrupt;
 case VARREF:
  deref_and_jump(a0,write__pred__dispatch_3_12);
  *reasonp++ =  a0;
  goto write__pred__dispatch_3_interrupt;
  };
  goto write__pred__dispatch_3_interrupt;
 write__pred__dispatch_3_ext_interrupt:
  reasonp = 0l;
 write__pred__dispatch_3_interrupt:
  goto interrupt_3;
 }

 write__predicates_6_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16, x17, x18, x19, x20, x21, x22, x23, x24, x25, x26, x27, x28, x29, x30, x31, x32, x33, x34, x35, x36, x37;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  a5 = qp->args[5];
  qp = qp->next;
 write__predicates_6_clear_reason:
  reasonp = reasons;
 write__predicates_6_0:
 write__predicates_6_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 write__predicates_6_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_5)) goto write__predicates_6_interrupt;
  allocp[0] = x2 = makeref(&allocp[0]);
  allocp[1] = makefunctor(funct_const_78);
  x1 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a4, x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xwrite__predicates_6);
  x3 = cdr_of(a0);
  allocp[2] = x3;
  allocp[3] = a1;
  allocp[4] = a2;
  allocp[5] = a3;
  allocp[6] = x4 = makeref(&allocp[6]);
  allocp[7] = a5;
  allocp[8] = x4;
  allocp[9] = makefunctor(funct_const_80);
  x5 = makecons(&allocp[8]);
  allocp[10] = NILATOM;
  x7 = arg(x0, 1);
  allocp[11] = x7;
  x6 = makecons(&allocp[10]);
  allocp[12] = (q)(struct goalrec*)&allocp[0];
  allocp[13] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[14] = makefunctor(&string_const_81);
  allocp[15] = x6;
  allocp[16] = x8 = makeref(&allocp[16]);
  allocp[17] = x5;
  allocp[18] = makesym(functor__2F_2);
  allocp[19] = a1;
  x10 = arg(x0, 0);
  allocp[20] = x10;
  x9 = makefunctor(&allocp[18]);
  allocp[21] = makesym(functor__2F_2);
  allocp[22] = x9;
  allocp[23] = x7;
  x11 = makefunctor(&allocp[21]);
  allocp[24] = (q)(struct goalrec*)&allocp[12];
  allocp[25] = (q)(&predicate_klic__comp__write_xwrite__predicates__1_4);
  allocp[26] = x12 = makeref(&allocp[26]);
  allocp[27] = x11;
  allocp[28] = x13 = makeref(&allocp[28]);
  allocp[29] = x8;
  allocp[30] = makesym(functor__2F_2);
  allocp[31] = x10;
  allocp[32] = x7;
  x14 = makefunctor(&allocp[30]);
  allocp[33] = makesym(functor_exec_1);
  allocp[34] = x14;
  x15 = makefunctor(&allocp[33]);
  allocp[35] = (q)(struct goalrec*)&allocp[24];
  allocp[36] = (q)(&predicate_klic__comp__util_xmember_3);
  allocp[37] = a3;
  allocp[38] = x15;
  allocp[39] = x12;
  allocp[40] = NILATOM;
  allocp[41] = x7;
  x16 = makecons(&allocp[40]);
  allocp[42] = x16;
  allocp[43] = x10;
  x17 = makecons(&allocp[42]);
  allocp[44] = (q)(struct goalrec*)&allocp[35];
  allocp[45] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[46] = makefunctor(&string_const_82);
  allocp[47] = x17;
  allocp[48] = x18 = makeref(&allocp[48]);
  allocp[49] = x13;
  allocp[50] = x18;
  allocp[51] = makefunctor(funct_const_84);
  x19 = makecons(&allocp[50]);
  allocp[52] = NILATOM;
  allocp[53] = x7;
  x20 = makecons(&allocp[52]);
  allocp[54] = x20;
  allocp[55] = x10;
  x21 = makecons(&allocp[54]);
  allocp[56] = (q)(struct goalrec*)&allocp[44];
  allocp[57] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[58] = makefunctor(&string_const_85);
  allocp[59] = x21;
  allocp[60] = x22 = makeref(&allocp[60]);
  allocp[61] = x19;
  allocp[62] = makesym(functor__2F_2);
  allocp[63] = a1;
  allocp[64] = x10;
  x23 = makefunctor(&allocp[62]);
  allocp[65] = makesym(functor__2F_2);
  allocp[66] = x23;
  allocp[67] = x7;
  x24 = makefunctor(&allocp[65]);
  allocp[68] = makesym(functor_info_1);
  allocp[69] = x24;
  x25 = makefunctor(&allocp[68]);
  allocp[70] = (q)(struct goalrec*)&allocp[56];
  allocp[71] = (q)(&predicate_klic__comp__obj_xwrite__object_4);
  x26 = arg(x0, 4);
  allocp[72] = x26;
  allocp[73] = x25;
  allocp[74] = x27 = makeref(&allocp[74]);
  allocp[75] = x22;
  allocp[76] = x27;
  allocp[77] = makefunctor(funct_const_87);
  x28 = makecons(&allocp[76]);
  allocp[78] = NILATOM;
  allocp[79] = x7;
  x29 = makecons(&allocp[78]);
  allocp[80] = x29;
  allocp[81] = x10;
  x30 = makecons(&allocp[80]);
  allocp[82] = (q)(struct goalrec*)&allocp[70];
  allocp[83] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[84] = makefunctor(&string_const_88);
  allocp[85] = x30;
  allocp[86] = x31 = makeref(&allocp[86]);
  allocp[87] = x28;
  allocp[88] = x31;
  allocp[89] = makefunctor(funct_const_90);
  x32 = makecons(&allocp[88]);
  allocp[90] = (q)(struct goalrec*)&allocp[82];
  allocp[91] = (q)(&predicate_klic__comp__write_xwrite__get__args_4);
  allocp[92] = a2;
  allocp[93] = x7;
  allocp[94] = x33 = makeref(&allocp[94]);
  allocp[95] = x32;
  allocp[96] = (q)(struct goalrec*)&allocp[90];
  allocp[97] = (q)(&predicate_klic__comp__write_xdeclare__registers_4);
  x34 = arg(x0, 3);
  allocp[98] = x34;
  allocp[99] = makefunctor(&string_const_91);
  allocp[100] = x35 = makeref(&allocp[100]);
  allocp[101] = x33;
  allocp[102] = NILATOM;
  allocp[103] = x7;
  x36 = makecons(&allocp[102]);
  allocp[104] = x36;
  allocp[105] = x10;
  x37 = makecons(&allocp[104]);
  allocp[106] = (q)(struct goalrec*)&allocp[96];
  allocp[107] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[108] = makefunctor(&string_const_92);
  allocp[109] = x37;
  allocp[110] = x2;
  allocp[111] = x35;
  qp = (struct goalrec*)&allocp[106];
  allocp += 112;
  proceed();
 case VARREF:
  deref_and_jump(x0,write__predicates_6_3);
  *reasonp++ =  x0;
  goto write__predicates_6_interrupt;
  };
  goto write__predicates_6_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto write__predicates_6_interrupt;
  unify(a5, a4);
  proceed();
 case VARREF:
  deref_and_jump(a0,write__predicates_6_1);
  *reasonp++ =  a0;
  goto write__predicates_6_interrupt;
  };
  goto write__predicates_6_interrupt;
 write__predicates_6_ext_interrupt:
  reasonp = 0l;
 write__predicates_6_interrupt:
  goto interrupt_6;
 }

 write__predicates__1_4_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 write__predicates__1_4_clear_reason:
  reasonp = reasons;
 write__predicates__1_4_0:
 write__predicates__1_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto write__predicates__1_4_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  allocp[0] = NILATOM;
  allocp[1] = a1;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_93);
  allocp[5] = x0;
  allocp[6] = a2;
  allocp[7] = a3;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 case symval(makesym(atom_no)):
  unify(a3, a2);
  proceed();
 default:
  goto write__predicates__1_4_interrupt;
  };
 case VARREF:
  deref_and_jump(a0,write__predicates__1_4_1);
  *reasonp++ =  a0;
  goto write__predicates__1_4_interrupt;
  };
  goto write__predicates__1_4_interrupt;
 write__predicates__1_4_ext_interrupt:
  reasonp = 0l;
 write__predicates__1_4_interrupt:
  goto interrupt_4;
 }

 write__get__args_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 write__get__args_4_clear_reason:
  reasonp = reasons;
 write__get__args_4_0:
 write__get__args_4_1:
  if (!isint(a0)) goto write__get__args_4_9;
 write__get__args_4_3:
  if (!isint(a1)) goto write__get__args_4_8;
  gblt_eq(a0,a1,write__get__args_4_6);
  unify(a3, a2);
  proceed();
 write__get__args_4_6:
  gblt_less(a0,a1,write__get__args_4_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xwrite__get__args_4);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = x1 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = (q)(struct goalrec*)&allocp[0];
  allocp[7] = (q)(&predicate_integer__arithmetics_xadd_3);
  allocp[8] = a0;
  allocp[9] = makeint(1L);
  allocp[10] = x0;
  allocp[11] = NILATOM;
  allocp[12] = a0;
  x2 = makecons(&allocp[11]);
  allocp[13] = x2;
  allocp[14] = a0;
  x3 = makecons(&allocp[13]);
  allocp[15] = (q)(struct goalrec*)&allocp[6];
  allocp[16] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[17] = makefunctor(&string_const_94);
  allocp[18] = x3;
  allocp[19] = a2;
  allocp[20] = x1;
  qp = (struct goalrec*)&allocp[15];
  allocp += 21;
  proceed();
 write__get__args_4_8:
  if (!isref(a1)) goto write__get__args_4_interrupt;
  deref_and_jump(a1,write__get__args_4_3);
  *reasonp++ =  a1;
  goto write__get__args_4_interrupt;
 write__get__args_4_9:
  if (!isref(a0)) goto write__get__args_4_interrupt;
  deref_and_jump(a0,write__get__args_4_1);
  *reasonp++ =  a0;
  goto write__get__args_4_interrupt;
 write__get__args_4_ext_interrupt:
  reasonp = 0l;
 write__get__args_4_interrupt:
  goto interrupt_4;
 }

 write__module__tailer_4_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 write__module__tailer_4_clear_reason:
  reasonp = reasons;
 write__module__tailer_4_0:
  allocp[0] = a3;
  allocp[1] = makefunctor(funct_const_96);
  x0 = makecons(&allocp[0]);
  allocp[2] = NILATOM;
  allocp[3] = a0;
  x1 = makecons(&allocp[2]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[6] = makefunctor(&string_const_97);
  allocp[7] = x1;
  allocp[8] = x2 = makeref(&allocp[8]);
  allocp[9] = x0;
  allocp[10] = x2;
  allocp[11] = makefunctor(funct_const_99);
  x3 = makecons(&allocp[10]);
  a0 = a1;
  a3 = x3;
  qp = (struct goalrec*)&allocp[4];
  allocp += 12;
  execute(write__interrupt__call_4_0);
  goto write__interrupt__call_4_ext_interrupt;
 write__module__tailer_4_ext_interrupt:
  reasonp = 0l;
 write__module__tailer_4_interrupt:
  goto interrupt_4;
 }

 write__interrupt__call_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 write__interrupt__call_4_clear_reason:
  reasonp = reasons;
 write__interrupt__call_4_0:
 write__interrupt__call_4_1:
  if (!isint(a0)) goto write__interrupt__call_4_6;
  gblt_greater(a0,makeint(0L),write__interrupt__call_4_4);
  bblt_sub_no_check(a0,makeint(1L),x0);
  bblt_add_no_check(x0,makeint(2L),x1);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xwrite__interrupt__call_4);
  allocp[2] = x0;
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = NILATOM;
  allocp[7] = x0;
  x3 = makecons(&allocp[6]);
  allocp[8] = x3;
  allocp[9] = x1;
  x4 = makecons(&allocp[8]);
  allocp[10] = (q)(struct goalrec*)&allocp[0];
  allocp[11] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[12] = makefunctor(&string_const_100);
  allocp[13] = x4;
  allocp[14] = x5 = makeref(&allocp[14]);
  allocp[15] = x2;
  allocp[16] = NILATOM;
  allocp[17] = a0;
  x6 = makecons(&allocp[16]);
  allocp[18] = (q)(struct goalrec*)&allocp[10];
  allocp[19] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[20] = makefunctor(&string_const_101);
  allocp[21] = x6;
  allocp[22] = a2;
  allocp[23] = x5;
  qp = (struct goalrec*)&allocp[18];
  allocp += 24;
  proceed();
 write__interrupt__call_4_4:
  if (a0 != makeint(0L)) goto write__interrupt__call_4_interrupt;
  allocp[0] = a3;
  allocp[1] = makefunctor(funct_const_103);
  x7 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a2, x7);
  proceed();
 write__interrupt__call_4_6:
  if (!isref(a0)) goto write__interrupt__call_4_interrupt;
  deref_and_jump(a0,write__interrupt__call_4_1);
  *reasonp++ =  a0;
  goto write__interrupt__call_4_interrupt;
 write__interrupt__call_4_ext_interrupt:
  reasonp = 0l;
 write__interrupt__call_4_interrupt:
  toppred = &predicate_klic__comp__write_xwrite__interrupt__call_4;
  goto interrupt_4;
 }

 write__header__file_3_top: {
  q x0, x1, x2, x3, x4, x5, x6;
  a2 = qp->args[2];
  qp = qp->next;
 write__header__file_3_clear_reason:
  reasonp = reasons;
 write__header__file_3_0:
 write__header__file_3_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  if (functor_of(a0) != makesym(functor_module_3)) goto write__header__file_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xwrite__ext__entries_3);
  allocp[2] = x0 = makeref(&allocp[2]);
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_klic__comp__write_xwrite__defined__preds_4);
  x2 = arg(a0, 1);
  allocp[7] = x2;
  x3 = arg(a0, 0);
  allocp[8] = x3;
  allocp[9] = x4 = makeref(&allocp[9]);
  allocp[10] = x1;
  allocp[11] = NILATOM;
  allocp[12] = x3;
  x5 = makecons(&allocp[11]);
  allocp[13] = (q)(struct goalrec*)&allocp[5];
  allocp[14] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[15] = makefunctor(&string_const_104);
  allocp[16] = x5;
  allocp[17] = a1;
  allocp[18] = x4;
  allocp[19] = (q)(struct goalrec*)&allocp[13];
  allocp[20] = (q)(&predicate_klic__comp__extern_xmake__ext__table_3);
  x6 = arg(a0, 2);
  allocp[21] = x6;
  allocp[22] = x0;
  allocp[23] = NILATOM;
  qp = (struct goalrec*)&allocp[19];
  allocp += 24;
  proceed();
 case VARREF:
  deref_and_jump(a0,write__header__file_3_1);
  *reasonp++ =  a0;
  goto write__header__file_3_interrupt;
  };
  goto write__header__file_3_interrupt;
 write__header__file_3_ext_interrupt:
  reasonp = 0l;
 write__header__file_3_interrupt:
  goto interrupt_3;
 }

 write__ext__entries_3_top: {
  q x0, x1, x2, x3;
  a2 = qp->args[2];
  qp = qp->next;
 write__ext__entries_3_clear_reason:
  reasonp = reasons;
 write__ext__entries_3_0:
 write__ext__entries_3_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xwrite__ext__entries_3);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  allocp[3] = x1 = makeref(&allocp[3]);
  allocp[4] = a2;
  allocp[5] = (q)(struct goalrec*)&allocp[0];
  allocp[6] = (q)(&predicate_klic__comp__write_xwrite__ext__entries_2F3_240_4);
  allocp[7] = x2 = makeref(&allocp[7]);
  allocp[8] = x1;
  allocp[9] = a1;
  x3 = car_of(a0);
  allocp[10] = x3;
  allocp[11] = (q)(struct goalrec*)&allocp[5];
  allocp[12] = (q)(&predicate_klic__comp__util_xmember_3);
  allocp[13] = x0;
  allocp[14] = x3;
  allocp[15] = x2;
  qp = (struct goalrec*)&allocp[11];
  allocp += 16;
  proceed();
 case ATOMIC:
  if (a0 != NILATOM) goto write__ext__entries_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,write__ext__entries_3_1);
  *reasonp++ =  a0;
  goto write__ext__entries_3_interrupt;
  };
  goto write__ext__entries_3_interrupt;
 write__ext__entries_3_ext_interrupt:
  reasonp = 0l;
 write__ext__entries_3_interrupt:
  goto interrupt_3;
 }

 write__ext__entries_2F3_240_4_top: {
  q x0;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 write__ext__entries_2F3_240_4_clear_reason:
  reasonp = reasons;
 write__ext__entries_2F3_240_4_0:
 write__ext__entries_2F3_240_4_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto write__ext__entries_2F3_240_4_interrupt;
  switch (symval(a0)) {
 case symval(makesym(atom_yes)):
  unify(a1, a2);
  proceed();
 case symval(makesym(atom_no)):
  a0 = a3;
  x0 = a2;
  a2 = a1;
  a1 = x0;
  execute(write__ext__entry_3_0);
  goto write__ext__entry_3_ext_interrupt;
 default:
  goto write__ext__entries_2F3_240_4_interrupt;
  };
 case VARREF:
  deref_and_jump(a0,write__ext__entries_2F3_240_4_1);
  *reasonp++ =  a0;
  goto write__ext__entries_2F3_240_4_interrupt;
  };
  goto write__ext__entries_2F3_240_4_interrupt;
 write__ext__entries_2F3_240_4_ext_interrupt:
  reasonp = 0l;
 write__ext__entries_2F3_240_4_interrupt:
  goto interrupt_4;
 }

 write__ext__entry_3_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  qp = qp->next;
 write__ext__entry_3_clear_reason:
  reasonp = reasons;
 write__ext__entry_3_0:
 write__ext__entry_3_1:
  switch (ptagof(a0)) {
 case FUNCTOR:
  switch (symval(functor_of(a0))) {
 case functor_atom_1:
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_105);
  allocp[5] = x0;
  allocp[6] = a1;
  allocp[7] = a2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 case functor_funct_1:
  x0 = arg(a0, 0);
 write__ext__entry_3_5:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor__2F_2)) goto write__ext__entry_3_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__obj_xnl_2);
  allocp[2] = x1 = makeref(&allocp[2]);
  allocp[3] = a2;
  a0 = arg(x0, 0);
  x2 = arg(x0, 1);
  a2 = a1;
  a3 = x1;
  a1 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  execute(write__funct__name_4_0);
  goto write__funct__name_4_ext_interrupt;
 case VARREF:
  deref_and_jump(x0,write__ext__entry_3_5);
  *reasonp++ =  x0;
  goto write__ext__entry_3_interrupt;
  };
  goto write__ext__entry_3_interrupt;
 case functor_module_1:
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_106);
  allocp[5] = x0;
  allocp[6] = a1;
  allocp[7] = a2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 case functor_class_1:
  allocp[0] = NILATOM;
  x1 = arg(a0, 0);
  allocp[1] = x1;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_107);
  allocp[5] = x0;
  allocp[6] = a1;
  allocp[7] = a2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 default:
  goto write__ext__entry_3_interrupt;
  };
 case VARREF:
  deref_and_jump(a0,write__ext__entry_3_1);
  *reasonp++ =  a0;
  goto write__ext__entry_3_interrupt;
  };
  goto write__ext__entry_3_interrupt;
 write__ext__entry_3_ext_interrupt:
  reasonp = 0l;
 write__ext__entry_3_interrupt:
  toppred = &predicate_klic__comp__write_xwrite__ext__entry_3;
  goto interrupt_3;
 }

 write__defined__preds_4_top: {
  q x0, x1, x2, x3, x4, x5, x6, x7;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 write__defined__preds_4_clear_reason:
  reasonp = reasons;
 write__defined__preds_4_0:
 write__defined__preds_4_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = car_of(a0);
 write__defined__preds_4_3:
  switch (ptagof(x0)) {
 case FUNCTOR:
  if (functor_of(x0) != makesym(functor_pred_5)) goto write__defined__preds_4_interrupt;
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xwrite__defined__preds_4);
  x1 = cdr_of(a0);
  allocp[2] = x1;
  allocp[3] = a1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a3;
  allocp[6] = makesym(functor__2F_2);
  allocp[7] = a1;
  x4 = arg(x0, 0);
  allocp[8] = x4;
  x3 = makefunctor(&allocp[6]);
  allocp[9] = makesym(functor__2F_2);
  allocp[10] = x3;
  x6 = arg(x0, 1);
  allocp[11] = x6;
  x5 = makefunctor(&allocp[9]);
  allocp[12] = NILATOM;
  allocp[13] = x5;
  x7 = makecons(&allocp[12]);
  allocp[14] = (q)(struct goalrec*)&allocp[0];
  allocp[15] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[16] = makefunctor(&string_const_108);
  allocp[17] = x7;
  allocp[18] = a2;
  allocp[19] = x2;
  qp = (struct goalrec*)&allocp[14];
  allocp += 20;
  proceed();
 case VARREF:
  deref_and_jump(x0,write__defined__preds_4_3);
  *reasonp++ =  x0;
  goto write__defined__preds_4_interrupt;
  };
  goto write__defined__preds_4_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto write__defined__preds_4_interrupt;
  unify(a3, a2);
  proceed();
 case VARREF:
  deref_and_jump(a0,write__defined__preds_4_1);
  *reasonp++ =  a0;
  goto write__defined__preds_4_interrupt;
  };
  goto write__defined__preds_4_interrupt;
 write__defined__preds_4_ext_interrupt:
  reasonp = 0l;
 write__defined__preds_4_interrupt:
  goto interrupt_4;
 }

 write__ext__preds_3_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  qp = qp->next;
 write__ext__preds_3_clear_reason:
  reasonp = reasons;
 write__ext__preds_3_0:
 write__ext__preds_3_1:
  switch (ptagof(a0)) {
 case CONS:
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xwrite__ext__preds__1_5);
  x0 = cdr_of(a0);
  allocp[2] = x0;
  x1 = car_of(a0);
  allocp[3] = x1;
  allocp[4] = x2 = makeref(&allocp[4]);
  allocp[5] = a1;
  allocp[6] = a2;
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_klic__comp__util_xmember_3);
  allocp[9] = x0;
  allocp[10] = x1;
  allocp[11] = x2;
  qp = (struct goalrec*)&allocp[7];
  allocp += 12;
  proceed();
 case ATOMIC:
  if (a0 != NILATOM) goto write__ext__preds_3_interrupt;
  unify(a2, a1);
  proceed();
 case VARREF:
  deref_and_jump(a0,write__ext__preds_3_1);
  *reasonp++ =  a0;
  goto write__ext__preds_3_interrupt;
  };
  goto write__ext__preds_3_interrupt;
 write__ext__preds_3_ext_interrupt:
  reasonp = 0l;
 write__ext__preds_3_interrupt:
  toppred = &predicate_klic__comp__write_xwrite__ext__preds_3;
  goto interrupt_3;
 }

 write__ext__preds__1_5_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 write__ext__preds__1_5_clear_reason:
  reasonp = reasons;
 write__ext__preds__1_5_0:
 write__ext__preds__1_5_1:
  switch (ptagof(a2)) {
 case ATOMIC:
  if (isint(a2)) goto write__ext__preds__1_5_interrupt;
  switch (symval(a2)) {
 case symval(makesym(atom_yes)):
  a1 = a3;
  a2 = a4;
  execute(write__ext__preds_3_0);
  goto write__ext__preds_3_ext_interrupt;
 case symval(makesym(atom_no)):
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xwrite__ext__preds_3);
  allocp[2] = a0;
  allocp[3] = x0 = makeref(&allocp[3]);
  allocp[4] = a4;
  allocp[5] = NILATOM;
  allocp[6] = a1;
  x1 = makecons(&allocp[5]);
  allocp[7] = (q)(struct goalrec*)&allocp[0];
  allocp[8] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[9] = makefunctor(&string_const_108);
  allocp[10] = x1;
  allocp[11] = a3;
  allocp[12] = x0;
  qp = (struct goalrec*)&allocp[7];
  allocp += 13;
  proceed();
 default:
  goto write__ext__preds__1_5_interrupt;
  };
 case VARREF:
  deref_and_jump(a2,write__ext__preds__1_5_1);
  *reasonp++ =  a2;
  goto write__ext__preds__1_5_interrupt;
  };
  goto write__ext__preds__1_5_interrupt;
 write__ext__preds__1_5_ext_interrupt:
  reasonp = 0l;
 write__ext__preds__1_5_interrupt:
  goto interrupt_5;
 }

 write__atom_3_top: {
  q x0, x1;
  a2 = qp->args[2];
  qp = qp->next;
 write__atom_3_clear_reason:
  reasonp = reasons;
 write__atom_3_0:
 write__atom_3_1:
  switch (ptagof(a0)) {
 case ATOMIC:
  if (isint(a0)) goto write__atom_3_7;
  switch (symval(a0)) {
 case symval(NILATOM):
  allocp[0] = a2;
  allocp[1] = makefunctor(funct_const_110);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  proceed();
 case symval(PERIODATOM):
  allocp[0] = a2;
  allocp[1] = makefunctor(funct_const_112);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  proceed();
 default:
  goto write__atom_3_9;
  };
 write__atom_3_7:
  gblt_integer(a0,write__atom_3_9);
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x1 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_113);
  allocp[5] = x1;
  allocp[6] = a1;
  allocp[7] = a2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 case VARREF:
  deref_and_jump(a0,write__atom_3_1);
  *reasonp++ =  a0;
  goto write__atom_3_9;
  };
  goto write__atom_3_9;
 write__atom_3_9:
  otherwise(write__atom_3_interrupt);
  allocp[0] = NILATOM;
  allocp[1] = a0;
  x0 = makecons(&allocp[0]);
  allocp[2] = (q)qp;
  allocp[3] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[4] = makefunctor(&string_const_114);
  allocp[5] = x0;
  allocp[6] = a1;
  allocp[7] = a2;
  qp = (struct goalrec*)&allocp[2];
  allocp += 8;
  proceed();
 write__atom_3_ext_interrupt:
  reasonp = 0l;
 write__atom_3_interrupt:
  goto interrupt_3;
 }

 write__funct__name_4_top: {
  q x0, x1;
  a2 = qp->args[2];
  a3 = qp->args[3];
  qp = qp->next;
 write__funct__name_4_clear_reason:
  reasonp = reasons;
 write__funct__name_4_0:
  allocp[0] = NILATOM;
  allocp[1] = a1;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a0;
  x1 = makecons(&allocp[2]);
  allocp[4] = (q)qp;
  allocp[5] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[6] = makefunctor(&string_const_115);
  allocp[7] = x1;
  allocp[8] = a2;
  allocp[9] = a3;
  qp = (struct goalrec*)&allocp[4];
  allocp += 10;
  proceed();
 write__funct__name_4_ext_interrupt:
  reasonp = 0l;
 write__funct__name_4_interrupt:
  toppred = &predicate_klic__comp__write_xwrite__funct__name_4;
  goto interrupt_4;
 }

 write__pred__name_5_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  a3 = qp->args[3];
  a4 = qp->args[4];
  qp = qp->next;
 write__pred__name_5_clear_reason:
  reasonp = reasons;
 write__pred__name_5_0:
  allocp[0] = NILATOM;
  allocp[1] = a2;
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = a1;
  x1 = makecons(&allocp[2]);
  allocp[4] = x1;
  allocp[5] = a0;
  x2 = makecons(&allocp[4]);
  allocp[6] = (q)qp;
  allocp[7] = (q)(&predicate_klic__comp__obj_xklicformat_4);
  allocp[8] = makefunctor(&string_const_116);
  allocp[9] = x2;
  allocp[10] = a3;
  allocp[11] = a4;
  qp = (struct goalrec*)&allocp[6];
  allocp += 12;
  proceed();
 write__pred__name_5_ext_interrupt:
  reasonp = 0l;
 write__pred__name_5_interrupt:
  goto interrupt_5;
 }

 make__atom__name__string_2_top: {
  q x0, x1, x2;
  qp = qp->next;
 make__atom__name__string_2_clear_reason:
  reasonp = reasons;
 make__atom__name__string_2_0:
 make__atom__name__string_2_1:
  switch (ptagof(a0)) {
 case CONS:
  x0 = cdr_of(a0);
  a2 = car_of(a0);
  a0 = x0;
  execute(make__atom__name__string__1_3_0);
  goto make__atom__name__string__1_3_ext_interrupt;
 case ATOMIC:
  if (a0 != NILATOM) goto make__atom__name__string_2_6;
  unify_value(a1, NILATOM);
  proceed();
 case VARREF:
  deref_and_jump(a0,make__atom__name__string_2_1);
  *reasonp++ =  a0;
  goto make__atom__name__string_2_6;
  };
  goto make__atom__name__string_2_6;
 make__atom__name__string_2_6:
  otherwise(make__atom__name__string_2_interrupt);
 make__atom__name__string_2_8:
  switch (ptagof(a0)) {
 case FUNCTOR:
 make__atom__name__string_2_9:
  if (!isgobj(a0)) goto make__atom__name__string_2_interrupt;
 make__atom__name__string_2_10:
  gblt_is_string(a0,make__atom__name__string_2_interrupt);
  gblt_size_of_string(a0,x0,make__atom__name__string_2_interrupt);
  gblt_element_size_of_string(a0,x1,make__atom__name__string_2_interrupt);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xmake__atom__name__string_2);
  allocp[2] = x2 = makeref(&allocp[2]);
  allocp[3] = a1;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_klic__comp__util_xstring__to__char__list_2);
  allocp[6] = a0;
  allocp[7] = x2;
  qp = (struct goalrec*)&allocp[4];
  allocp += 8;
  proceed();
 case VARREF:
  deref_and_jump(a0,make__atom__name__string_2_8);
  *reasonp++ =  a0;
  goto make__atom__name__string_2_interrupt;
  };
  goto make__atom__name__string_2_interrupt;
 make__atom__name__string_2_ext_interrupt:
  reasonp = 0l;
 make__atom__name__string_2_interrupt:
  toppred = &predicate_klic__comp__write_xmake__atom__name__string_2;
  goto interrupt_2;
 }

 make__atom__name__string__1_3_top: {
  q x0, x1, x2;
  a2 = qp->args[2];
  qp = qp->next;
 make__atom__name__string__1_3_clear_reason:
  reasonp = reasons;
 make__atom__name__string__1_3_0:
 make__atom__name__string__1_3_1:
  if (!isint(a2)) goto make__atom__name__string__1_3_11;
  gblt_less_or_eq(makeint(48L),a2,make__atom__name__string__1_3_5);
  gblt_less_or_eq(a2,makeint(57L),make__atom__name__string__1_3_5);
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = a2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a1 = x1;
  execute(make__atom__name__string_2_0);
  goto make__atom__name__string_2_ext_interrupt;
 make__atom__name__string__1_3_5:
  gblt_less_or_eq(makeint(65L),a2,make__atom__name__string__1_3_8);
  gblt_less_or_eq(a2,makeint(90L),make__atom__name__string__1_3_8);
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = a2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a1 = x1;
  execute(make__atom__name__string_2_0);
  goto make__atom__name__string_2_ext_interrupt;
 make__atom__name__string__1_3_8:
  gblt_less_or_eq(makeint(97L),a2,make__atom__name__string__1_3_12);
  gblt_less_or_eq(a2,makeint(122L),make__atom__name__string__1_3_12);
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = a2;
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  a1 = x1;
  execute(make__atom__name__string_2_0);
  goto make__atom__name__string_2_ext_interrupt;
 make__atom__name__string__1_3_11:
  if (!isref(a2)) goto make__atom__name__string__1_3_12;
  deref_and_jump(a2,make__atom__name__string__1_3_1);
  *reasonp++ =  a2;
  goto make__atom__name__string__1_3_12;
 make__atom__name__string__1_3_12:
  otherwise(make__atom__name__string__1_3_interrupt);
 make__atom__name__string__1_3_14:
  switch (ptagof(a2)) {
 case ATOMIC:
 make__atom__name__string__1_3_16:
  if (a2 != makeint(95L)) goto make__atom__name__string__1_3_18;
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = makeint(95L);
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = makeint(95L);
  x2 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a1, x2);
  a1 = x1;
  execute(make__atom__name__string_2_0);
  goto make__atom__name__string_2_ext_interrupt;
 case VARREF:
  deref_and_jump(a2,make__atom__name__string__1_3_14);
  *reasonp++ =  a2;
  goto make__atom__name__string__1_3_18;
  };
  goto make__atom__name__string__1_3_18;
 make__atom__name__string__1_3_18:
  otherwise(make__atom__name__string__1_3_interrupt);
  allocp[0] = x1 = makeref(&allocp[0]);
  allocp[1] = makeint(95L);
  x0 = makecons(&allocp[0]);
  allocp += 2;
  unify_value(a1, x0);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xmake__atom__name__string_2);
  allocp[2] = a0;
  allocp[3] = x2 = makeref(&allocp[3]);
  a0 = a2;
  a1 = x1;
  a2 = x2;
  qp = (struct goalrec*)&allocp[0];
  allocp += 4;
  execute(ascii__string_3_0);
  goto ascii__string_3_ext_interrupt;
 make__atom__name__string__1_3_ext_interrupt:
  reasonp = 0l;
 make__atom__name__string__1_3_interrupt:
  toppred = &predicate_klic__comp__write_xmake__atom__name__string__1_3;
  goto interrupt_3;
 }

 ascii__string_3_top: {
  q x0, x1, x2, x3, x4, x5;
  a2 = qp->args[2];
  qp = qp->next;
 ascii__string_3_clear_reason:
  reasonp = reasons;
 ascii__string_3_0:
  allocp[0] = a2;
  allocp[1] = x1 = makeref(&allocp[1]);
  x0 = makecons(&allocp[0]);
  allocp[2] = x0;
  allocp[3] = x3 = makeref(&allocp[3]);
  x2 = makecons(&allocp[2]);
  allocp += 4;
  unify_value(a1, x2);
  bblt_rshift_no_check_y(a0,makeint(4L),x4);
  allocp[0] = (q)qp;
  allocp[1] = (q)(&predicate_klic__comp__write_xhexchar_2);
  allocp[2] = x5 = makeref(&allocp[2]);
  allocp[3] = x1;
  allocp[4] = (q)(struct goalrec*)&allocp[0];
  allocp[5] = (q)(&predicate_integer__arithmetics_xand_3);
  allocp[6] = a0;
  allocp[7] = makeint(15L);
  allocp[8] = x5;
  a0 = x4;
  a1 = x3;
  qp = (struct goalrec*)&allocp[4];
  allocp += 9;
  execute(hexchar_2_0);
  goto hexchar_2_ext_interrupt;
 ascii__string_3_ext_interrupt:
  reasonp = 0l;
 ascii__string_3_interrupt:
  toppred = &predicate_klic__comp__write_xascii__string_3;
  goto interrupt_3;
 }

 hexchar_2_top: {
  q x0, x1;
  qp = qp->next;
 hexchar_2_clear_reason:
  reasonp = reasons;
 hexchar_2_0:
 hexchar_2_1:
  if (!isint(a0)) goto hexchar_2_6;
  gblt_less(a0,makeint(10L),hexchar_2_4);
  bblt_add_no_check(makeint(48L),a0,x0);
  unify_value(a1, x0);
  proceed();
 hexchar_2_4:
  gblt_greater_or_eq(a0,makeint(10L),hexchar_2_interrupt);
  bblt_add_no_check(makeint(65L),a0,x0);
  bblt_sub_no_check(x0,makeint(10L),x1);
  unify_value(a1, x1);
  proceed();
 hexchar_2_6:
  if (!isref(a0)) goto hexchar_2_interrupt;
  deref_and_jump(a0,hexchar_2_1);
  *reasonp++ =  a0;
  goto hexchar_2_interrupt;
 hexchar_2_ext_interrupt:
  reasonp = 0l;
 hexchar_2_interrupt:
  toppred = &predicate_klic__comp__write_xhexchar_2;
  goto interrupt_2;
 }
 interrupt_7:
  allocp[8] = a6;
 interrupt_6:
  allocp[7] = a5;
 interrupt_5:
  allocp[6] = a4;
 interrupt_4:
  allocp[5] = a3;
 interrupt_3:
  allocp[4] = a2;
 interrupt_2:
  allocp[3] = a1;
 interrupt_1:
  allocp[2] = a0;
 interrupt_0:
  allocp = interrupt_goal(allocp, toppred, reasonp);
 proceed_label:
  loop_within_module(module_klic__comp__write);
}
