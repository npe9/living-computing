char *runtime_version = "1.500";
char *runtime_date = "Mon Oct 24 13:09:24 JST 1994";
