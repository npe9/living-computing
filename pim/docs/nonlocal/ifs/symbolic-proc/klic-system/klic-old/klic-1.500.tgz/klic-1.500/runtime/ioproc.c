#include <stdio.h>
#include <klic/basic.h>
#include <klic/struct.h>
#include <klic/distio.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>

static int shoentid = 0;

static int pe_count;

static void sigint_handler()
{
  if (shoentid) {
    pvm_kill(shoentid);
  }
  pvm_exit();
  exit(-1);
}


void io_proc(argc,argv)
int argc;
char **argv;
{ int i,len,mytid,histid,kind,
    pe,tid,bufid,info,msgtag,has_opened = 0,mm,
    is_eof = 0;
  FILE *tracer_input;
  char buf[1024],stid[20],pathname[256];
  char **sargv;
  extern char *malloc();

  if ((mytid = pvm_mytid()) < 0 ) {
    fprintf(stderr, "PVM has not been started!!\n");
    exit(-1);
  }

  if (strlen(argv[0]) == 0) {
    fprintf(stderr, "no pathname!!\n");
    exit(-1);
  }

  if (argv[0][0] == '/') {
    strcpy(pathname,argv[0]);
  } else {
    getcwd(pathname,255);
    if (pathname[strlen(pathname)-1] != '/') {
      strcat(pathname,"/");
    }
    strcat(pathname,argv[0]);
  }

  sargv = (char **) malloc(sizeof(char *)*(argc+2));

/*  sargv[0] = stid; */
  sargv[0] = "-$dp";
  for (i=1; i<= argc; i++) {
    sargv[i] = argv[i];
  }
  sargv[argc+1] = (char *)NULL;

  signal(SIGINT,sigint_handler);
  {
/*    int numt = pvm_spawn(argv[0],sargv,PvmTaskDefault,0,1,&shoentid);*/
    int numt = pvm_spawn(pathname,sargv,PvmTaskDefault,0,1,&shoentid);
    if (0 >= numt){
      fprintf(stderr,"Error %d cannot execute shoen!!\n", numt);      
      fprintf(stderr,"Error %d argv = %s!!\n", numt, argv[0]);      
      fprintf(stderr,"Error %d sargv = %s!!\n", numt, *sargv);      
      exit(1);
    }
  }

/*  pe = atoi(argv[1]); */
  pvm_initsend(PvmDataDefault);
  pvm_pkint(&mytid,1,1);
/*  pvm_pkint(&pe,1,1); */
  pvm_pkint(&total_node,1,1);
  pvm_pkint(&total_node,1,1);
/*  pvm_pkstr(argv[3]), */
  pvm_send(shoentid,3);

  pe_count = total_node + 1;
  histid = -1;

  while (1) {

    bufid = pvm_recv(histid,-1);
    info = pvm_bufinfo(bufid,&len,&msgtag,&histid);
    info = pvm_upkint(&kind,1,1);

    switch(kind) {
    case FinishTag:
      if (!(--pe_count)) {
	pvm_exit();
	exit(0);
      }
      histid = -1;
      break;
    case AttachTag:
      info = pvm_bufinfo(bufid,&len,&msgtag,&histid);
      break;
    case DetachTag:
      histid = -1;
      break;
    case System_putbTag:
      info  = pvm_upkstr(buf);
      fprintf(stderr,"%s",buf);
      break;
    case System_getsTag:
      if (!has_opened) {
	has_opened = 1;
	if ((tracer_input = fopen("/dev/tty", "r")) == NULL) {
	  fprintf(stderr,"Can't open /dev/tty for trace command input\n");
	  tracer_input = stdin;
	}
      }
      if (!is_eof) { fgets(buf,255,tracer_input); }
      if (strlen(buf) == 0)  { is_eof = 1; }
      bufid =pvm_initsend(PvmDataDefault);
      pvm_pkstr(buf);
      pvm_send(histid,3);
      break;
    case System_putcTag:
      info  = pvm_upkbyte(buf,1,1);
      fputc(buf[0],stderr);
      break;
    case System_getcTag:
      if (!has_opened) {
	has_opened = 1;
	if ((tracer_input = fopen("/dev/tty", "r")) == NULL) {
	  fprintf(stderr,"Can't open /dev/tty for trace command input\n");
	  tracer_input = stdin;
	}
      }
      if (!is_eof) {
	if (EOF == (buf[0] = fgetc(tracer_input))) {
	  is_eof = 1;
	}
      } else { buf[0] = EOF; }
      bufid =pvm_initsend(PvmDataDefault);
      pvm_pkbyte(buf,1,1);
      pvm_send(histid,3);
      break;
    case System_IsEOFTag:
      if (!has_opened) {
	has_opened = 1;
	if ((tracer_input = fopen("/dev/tty", "r")) == NULL) {
	  fprintf(stderr,"Can't open /dev/tty for trace command input\n");
	  tracer_input = stdin;
	}
      }
      if (!is_eof) { buf[0] = 1; } else { buf[1] = 0; }
      bufid =pvm_initsend(PvmDataDefault);
      pvm_pkbyte(buf,1,1);
      pvm_send(histid,3);
      break;
    case System_fflushTag:
      fflush(stderr);
      break;
    case PutbTag:
      info  = pvm_upkstr(buf);
      fprintf(stdout,"%s",buf);
      histid = -1;
      break;
    case EPutbTag:
      info  = pvm_upkstr(buf);
      fprintf(stderr,"%s",buf);
      histid = -1;
      break;
    case GetsTag:
      gets(buf);
      bufid = pvm_initsend(PvmDataDefault);
      pvm_pkstr(buf);
      pvm_send(histid,3);
      histid = -1;
      break;
    case User_putcTag:
      info  = pvm_upkbyte(buf,1,1);
      fputc(buf[0],stdout);
      histid = -1;
      break;
    case User_eputcTag:
      info  = pvm_upkbyte(buf,1,1);
      fputc(buf[0],stderr);
      histid = -1;
      break;
    case User_getcTag:
      buf[0] = getchar();
      bufid = pvm_initsend(PvmDataDefault);
      pvm_pkbyte(buf,1,1);
      pvm_send(histid,3);
      histid = -1;
      break;
    case User_fflushTag:
      fflush(stdout);
      histid = -1;
      break;
    case Emergency_stopTag:
      if (shoentid) {
	pvm_kill(shoentid);
      }
      pvm_exit();
      exit(0);
    default:
      fprintf(stderr,"Unknown message %d\n",kind);
      histid = -1;
/*
      pvm_exit();
      exit(1);
*/
    }
    mm = pvm_probe(-1,-1);
  }
}
