/* ---------------------------------------------------------- 
%   (C)1993,1994 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
#define MAIN

#include <klic/basic.h>
#include <klic/struct.h>
#include <klic/primitives.h>
#include <klic/unify.h>
#include <klic/timing.h>
#include <klic/functorstuffs.h>

#include <string.h>
#include <stdio.h>
#include <setjmp.h>
#ifdef USESIG
#include <signal.h>
#endif

#ifdef DIST
#include <klic/trace.h>
#include <time.h>
#include <sys/types.h>
#include <unistd.h>
#include <klic/traceio.h>
#include <klic/interpe.h>
#include <klic/sighndl.h>

#ifdef USEPROCBIND
#include <sys/types.h>
#include <sys/processor.h>
#include <sys/procset.h>
#endif

int receive_message();
q* gc_exp_table();
q* scan_imp_table();

char binname[256];

#endif

extern char *runtime_version, *runtime_date;

jmp_buf klic_topmost;
int start_tracing = 0;
#ifdef DEBUGLIB
int count_suspension = 0;
#endif

module module_main();

extern Const struct predicate predicate_main_xmain_0;
#ifdef DIST
extern Const struct predicate topsucceed_pred;
/* extern Const struct predicate predicate_builtin_xidle_0; */
#endif

char *optarg;

int
parse_size(str)
     char *str;
{
  int n;
  char c[2];
  switch (sscanf(str, "%d%1s", &n, c)) {
  case 1: return n;
  case 2:
    if (c[0] == 'k' || c[0] == 'K') {
      return n*0x400;
    } else if (c[0] == 'm' || c[0] == 'M') {
      return n*0x100000;
    } else if (c[0] == 'g' || c[0] == 'G') {
      return n*0x40000000;
    }
  default:
#ifdef DIST
    TRACE_FPRINTF1("Error in option \"%s\"\n", str);
    EmergencyStop;
    pvm_exit();
#else
    fprintf(stderr, "Error in option \"%s\"\n", str);
#endif
    exit(-1);
  }
}

#define PrepOptarg() \
{ \
  if (argv[optind][charind+1] != 0) { \
    charind++; \
  } else { \
    optind++; charind = 0; \
    if (optind >= argc) goto option_error; \
  } \
}

#define Optarg() &argv[optind][charind]

static void toploop()
{
  declare_globals;
  struct goalrec *qp = current_queue;
  Const struct predicate *toppred = qp->pred;
  module func = (module)toppred->func;
  while (1) {
    func = ((module (*)())func)(glbl, qp, heapp, toppred);
    qp = current_queue;
    toppred = qp->pred;
  }
}

#ifdef DIST
static void debug_handler()
{
  return;
}


int kill_tasks (allocp, sig)
     q *allocp;
     int sig;
{
  int i;
  printf("kill tasks\n");
  for (i = 0; i < total_node; i++) {
    if (tid_tbl[i]) {
      pvm_kill(tid_tbl[i]);
    }
  }
  pvm_exit();
  exit(-1);
}

void io_proc();

#endif

klic_main(argc, argv)
     int argc;
     char **argv;
{
  declare_globals;
  void initalloc();
  q *initiate_prioq();
  q *reinitiate_prioq();
#ifdef DEBUGLIB
  extern struct goalrec *trace_goal();
#endif

#ifdef DIST
  long interval_usec = 10000;
  int  iodp = 0;
  int  rmonflag = 0;
  char rmonnode[256];

  if ((argc > 1) && (strncmp(argv[1],"-$dp",3)==0)) {
    int mytid, info, ptid;
    iodp = 1;
    mytid = pvm_mytid();
    ptid = pvm_parent();
    info = pvm_recv(ptid,-1);
    info = pvm_upkint(&iotid,1,1);
    info = pvm_upkint(&total_node,1,1);
    info = pvm_upkint(&my_node,1,1);
    if (my_node != total_node) {
      tid_tbl[total_node] = ptid;
    } else if (iotid < 0 ) {
      distdebug = 1;
      info = pvm_upkint(debugio,total_node+1,1);
      iotid = debugio[total_node];
    }
    tid_tbl[my_node] = mytid;
    init_inter_node();
  }
#endif

  program_name = argv[0];
  heapsize = HEAPSIZE;
  maxheapsize = (unsigned long)(-1); /* largest possible */
  maxactiveratio = 0.5;
  incrementsize = INCREMENTSIZE;

  {
    int optind;
#ifdef DIST
    for (optind = (iodp?2:1);
#else
    for (optind = 1;
#endif
	 optind < argc && argv[optind][0] == '-';
	 optind++) {
      extern double atof();
      int charind;
      for (charind = 1;
	   argv[optind][charind] != 0;
	   charind++) {
	switch (argv[optind][charind]) {
	case 'a':
	  PrepOptarg();
	  maxactiveratio = atof(Optarg());
	  if (maxactiveratio <= 0.0 || maxactiveratio > 1.0) {
#ifdef DIST
	    fatalf_d(iodp,"Argument (%g) for option -a should be between 0 and 1",
		   maxactiveratio);
#else
	    fatalf("Argument (%g) for option -a should be between 0 and 1",
		   maxactiveratio);
#endif
	  }
	  goto nextarg;
#ifdef DIST
	case '$':
	  goto nextarg;
        case 'd':
          if (argv[optind][++charind]== 'p') {
            PrepOptarg();
            { long tn = parse_size(Optarg());
              if (tn < 0) { goto option_error; }
              else if (!iodp) {
                total_node = tn;
                goto io_proc;
              }
            }
            goto nextarg;
          } else { goto option_error; }
	case 'r':
	  if (strcmp(argv[optind],"rmon") == 0) {
	    if (!(argv[optind++][0])) { goto option_error; }
	    (void)strcpy(rmonnode,argv[optind]);
	    break;
	  } else { goto option_error; }
	case 'e':
	  eager_transfer_flag = 1;
	  eager_transfer_level = -1;
	  goto nextarg;
	case 'E':
	  eager_transfer_flag = 1;
	  PrepOptarg();
	  eager_transfer_level = parse_size(Optarg());
	  goto nextarg;
        case 'n':
          network_statistics_flag = 1;
          goto nextarg;
        case 'I':
	  PrepOptarg();
          interval_usec = parse_size(Optarg());
          goto nextarg;
        case 'S':
          sendsig_flag = 1;
          goto nextarg;
        case 'B':
          msg_busywait_flag = 1;
          goto nextarg;
#endif
	case 'h':
	  PrepOptarg();
	  heapsize = parse_size(Optarg());
	  if (heapsize > maxheapsize) maxheapsize = heapsize;
	  goto nextarg;
	case 'H':
	  PrepOptarg();
	  maxheapsize = parse_size(Optarg());
	  if (heapsize > maxheapsize) heapsize = maxheapsize;
	  goto nextarg;
	case 'i':
	  PrepOptarg();
	  incrementsize = parse_size(Optarg()); goto nextarg;
	case 'g':
	  measure_gc = 1; break;
	case 'v':
#ifdef DIST
	  if (!iodp) {
	    fprintf(stderr, "KLIC runtime version %s (%s)\n",
		    runtime_version, runtime_date);
	  }
#else	    
	  fprintf(stderr, "KLIC runtime version %s (%s)\n",
		  runtime_version, runtime_date);
#endif
	  break;
	case 't':
#ifdef DEBUGLIB
	  start_tracing = 1; break;
#else
#ifdef DIST
	  fatal_d(iodp,"Tracing is only possible when linked without -n flag");
#else
	  fatal("Tracing is only possible when linked without -n flag");
#endif
#endif
        case 's':
#ifdef DEBUGLIB
	  count_suspension = 1; break;
#else
	  fatal("suspension counting is disabled by -n flag at compilation");
#endif
	case '-':
	  optind++; goto option_end;
	default:
	option_error:
#ifdef DIST
#ifdef DEBUGLIB
	  sprintf(iobuf,
		  "Usage: %s [options, ...] [program arguments, ...]\n%s%s%s%s%s%s%s%s%s",
		  argv[0],
		  "\t-t: start execution with tracing\n",
#ifdef COMMENT
		  );		/* for parentheses balancing */
#endif
#else
	  sprintf(iobuf,
		  "Usage: %s [options, ...] [program arguments, ...]\n%s%s%s%s%s%s%s%s",
		  argv[0],
#endif
		  "\t-a <ratio>: active cell ratio to triger heap extension\n",
		  "\t  <ratio> should be a floating point number >0 and <1\n",
		  "\t-h <initial heap size>: initial size of heap\n",
		  "\t-H <max heap size>: maximum possible heap size\n",
		  "\t-i <increment>: gap between heap top and bottom\n",
		  "\t  for -h, -H and -i, 32k means 32KW and 2m means 2MW\n",
		  "\t-g: set garbage collection measurement on\n",
		  "\t-v: display KLIC runtime version\n");
	  if (iodp) {
	    EPrint(iobuf);
	    pvm_exit();
	  } else { fprintf(stderr,"%s",iobuf); }
#else
#ifdef DEBUGLIB
	  fprintf(stderr,
		  "Usage: %s [options, ...] [program arguments, ...]\n%s%s%s%s%s%s%s%s%s",
		  argv[0],
		  "\t-t: start execution with tracing\n",
#ifdef COMMENT
		  );		/* for parentheses balancing */
#endif
#else
	  fprintf(stderr,
		  "Usage: %s [options, ...] [program arguments, ...]\n%s%s%s%s%s%s%s%s",
		  argv[0],
#endif
		  "\t-a <ratio>: active cell ratio to triger heap extension\n",
		  "\t  <ratio> should be a floating point number >0 and <1\n",
		  "\t-h <initial heap size>: initial size of heap\n",
		  "\t-H <max heap size>: maximum possible heap size\n",
		  "\t-i <increment>: gap between heap top and bottom\n",
		  "\t  for -h, -H and -i, 32k means 32KW and 2m means 2MW\n",
		  "\t-g: set garbage collection measurement on\n",
		  "\t-v: display KLIC runtime version\n");
#endif
	  exit(-1);
	}
      }
    nextarg:;
    }
  option_end:
    command_argc = argc-optind;
    command_argv = argv+optind;
  }

#ifdef DIST
    if (!iodp) {
      total_node = 1;
      goto io_proc;
    }
#endif

  initalloc();

  {
    extern struct goalrec *get_top_priority_queue();
    q *allocp;
    struct goalrec *qp;

    allocp = initiate_prioq(heapp);
    qp = (struct goalrec *) allocp;

    interrupt_off = -1;
#ifdef USESIG
    init_klic_signal_handling();
#endif
#ifdef DIST
    register_gc_hook(gc_exp_table);
    register_after_gc_hook(scan_imp_table);

    add_signal_handler(SIGUSR1, receive_message);
    add_signal_handler(SIGALRM, receive_message);

    if (!shoen_node) {
      int pidt;
      pvm_initsend(PvmDataRaw);
      pidt = (int) getpid();

#ifdef USEPROCBIND
      { processorid_t obind;
	long nprocs = sysconf(_SC_NPROCESSORS_ONLN);
	processor_bind(P_PID,P_MYID,
		       (processorid_t)(my_node % nprocs),&obind);
      }
#endif

      pvm_pkint(&pidt,1,1);
      pvm_send(tid_tbl[SHOEN_NODE],3);
    }
    if(dist_exec){
      if(master_node){
	qp->pred = &predicate_main_xmain_0;
	heapp = allocp + 2;
	initiate_tid_table_fp();
	node_wtc = SUPPLY_WTC_UNIT;
/* */
	{
	  struct timeval tp;
	  struct timezone tzp;
	  if(!gettimeofday(&tp, &tzp)){
	    start_sec = tp.tv_sec;
	    start_usec= tp.tv_usec;
	  }
	}
/* */
      } else {
/*
        qp->pred = &predicate_builtin_xidle_0;
	heapp = allocp + 2;
*/
	if(shoen_node){
	  initiate_tid_table_shoen(argv[0],argc,argv);	  
	  add_signal_handler(SIGTERM, kill_tasks);
	  shoen_wtc = -SUPPLY_WTC_UNIT;
	  {
	    struct timeval tp;
	    struct timezone tzp;
	    if(!gettimeofday(&tp, &tzp)){
	      start_sec = tp.tv_sec;
	      start_usec= tp.tv_usec;
	    }
	  }
	} else {
	  initiate_tid_table_fp();
	}
      }

      init_rusage(); /***** for inter NODE *****/

    } else {
      qp->pred = &predicate_main_xmain_0;
      heapp = allocp + 2;
    }
#else
    qp->pred = &predicate_main_xmain_0;
    heapp = allocp + 2;
#endif
    while (1) {
#ifdef DEBUGLIB
      suspensions = 0;
      resumes = 0;
      current_prio = -1;
      suspended_goal_list = 0;
      if (start_tracing) {
	initiate_trace();
#ifdef DIST
	if (master_node) { qp = trace_goal(qp, 1); }
#else
	qp = trace_goal(qp, 1);
#endif
	start_tracing = 0;
      }
      initialize_suspension_count_table();
#endif
#ifdef DIST
      if (master_node) {
#endif
      (void) enqueue_goal(0, HIGHESTPRIO-1, qp, glbl);
#ifdef DIST
      }
#endif
      current_queue = get_top_priority_queue();
      resumed_goals = 0;

#ifndef DIST
      postmortem_pred = 0;
      postmortem_args = 0;
#endif


#ifdef DIST
    {
      struct itimerval it_intval,it_otime;
      it_intval.it_interval.tv_sec = 0;
      it_intval.it_interval.tv_usec = 10000;
      it_intval.it_value.tv_sec = 0;
      it_intval.it_value.tv_usec = interval_usec;
      if (0 != setitimer(ITIMER_REAL,&it_intval,&it_otime)) {
	Print("ERROR!!");
	EmergencyStop;
	pvm_exit();
	exit(-1);
      }
    }
#endif

      if (setjmp(klic_topmost) == 0) toploop();
#ifdef DIST
      DetachIO;
      pvm_exit();
#else
      if (postmortem_pred == 0 || postmortem_args == 0) break;
      fprintf(stderr, "Starting postmortem processing...\n");
      allocp = initiate_prioq(heapp+incrementsize/2); /* dirty patch */
      qp = (struct goalrec *) allocp;
      qp->pred = postmortem_pred;
      allocp += 2;
      if (isfunctor(postmortem_args)) {
	int arity = arityof(functor_of(postmortem_args));
	int k;
	for (k=0; k<arity; k++) {
	  *allocp++ = arg(postmortem_args, k);
	}
      }
      heapp = allocp;
#endif
    }
  }
  return 0;
#ifdef DIST
 io_proc:  
  io_proc(argc,argv);
  return 0;
#endif
}

module topsucceed(glbl, qp, allocp, toppred)
     struct global_variables *glbl;
     struct goalrec *qp;
     q *allocp;
     Const struct predicate *toppred;
#ifdef DIST
{
  extern q *klic_interrupt();
  extern Const struct predicate topsucceed_pred;

 idle_loop:
  if((my_node != SHOEN_NODE) && (suspensions == resumes)
     &&(node_wtc != 0) && ((long)top_of_susp_msg_rec == END_SUSP_MSG_REC)){
    send_return_wtc();
  }

  if((my_node == SHOEN_NODE) && (shoen_wtc > 0)){
    sprintf(iobuf,"illegal wtc in shoen node\n");
    EPrint(iobuf);
    fatal("illegal WTC");
  }    

  if((my_node == SHOEN_NODE) && (shoen_wtc == 0)){
    {
      struct timeval tp;
      struct timezone tzp;
      if(!gettimeofday(&tp, &tzp)){
	sprintf(iobuf,"Response time is %d msec\n\n",
		(tp.tv_sec - start_sec)*1000+ (tp.tv_usec - start_usec)/1000);
	Print(iobuf);
      }
    }

    send_terminate_msg();
    CloseIO;

    pvm_exit();
    exit(0);
  }

  {

/*    if (interrupt_off) pause();*/
    if(msg_busywait_flag){
      int bufinfo = pvm_probe(-1, -1);
      if (bufinfo){
	interrupt_off = 0;
	heaplimit = 0;
	signal_done = 0;
	signal_flags[SIGUSR1] = 1;
      }
    } else {
      if (interrupt_off) pause();
    }

    allocp[0] = (q)qp->next;
    allocp[1] = (q)&topsucceed_pred;
    qp = (struct goalrec *)allocp;

    allocp += 2;
    heapp = klic_interrupt(allocp, qp);
    qp = current_queue;

    if ((qp->pred == &topsucceed_pred) && (heapp == allocp)) {
      allocp -= 2;
      goto idle_loop;
    }
    
    return (module) current_queue->pred->func;

  }
}

#else /* #ifndef DIST */
{
  extern q *klic_interrupt();
  extern Const struct predicate topsucceed_pred;
  if (suspensions == resumes) {
#ifdef DEBUGLIB
    if(count_suspension) {
      if(suspensions) {
	printf("Suspension counts:\n");
	scan_suspended_pred();
      } else {
	printf("No suspension in this run.\n");
      }
    }
#endif
    longjmp(klic_topmost, 1);
  }

#ifdef USESIG
  /* perpetual suspension suspected, but let's wait a while for interrupts */

  /* enqueue topsucceed goal again */
  allocp[0] = (q)qp;
  allocp[1] = (q)&topsucceed_pred;
  qp = (struct goalrec *)allocp;

  /* Let's not hastily check perpetual suspension */
#ifdef USEUSLEEP
  usleep(1000);
#else
  (void) sleep(1);
#endif

  /* run GC */
  allocp = klic_interrupt(real_heaplimit, qp);
  qp = current_queue;

  if (qp->pred == &topsucceed_pred) {
    /* no interrupt after topsucceed was called */
    struct sigaction oldact, newact;
    newact.sa_handler = NULL;
    sigfillset(&newact.sa_mask);
    newact.sa_flags = 0;
    sigaction(0, &newact, &oldact);
    if (interrupt_off) pause();
    sigaction(0, &oldact, NULL);
  }
  /* check resumpsions */
  heapp = klic_interrupt(allocp, qp);
  return (module) current_queue->pred->func;
#else
  fatalf("%d perpetually suspending goals found",
	 suspensions-resumes);
#endif
}
#endif
