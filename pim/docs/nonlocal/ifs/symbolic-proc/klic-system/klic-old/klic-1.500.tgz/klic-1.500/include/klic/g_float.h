/* ---------------------------------------------------------- 
%   (C)1994 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */

struct float_object {
  struct data_object_method_table *method_table;
  double value;
};

extern struct data_object_method_table float_g_data_method_table;

#define float_structure_type	struct float_object
#define declare_float_constant(value) \
{ &float_g_data_method_table, value }
#define makefloat(x)		makefunctor(&x)
#define float_value(x) (((float_structure_type *)functorp(x))->value)
