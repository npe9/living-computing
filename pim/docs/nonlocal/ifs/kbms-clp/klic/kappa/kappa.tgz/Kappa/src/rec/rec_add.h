/*
/*	(C)1992, 1993, 1995 Institute for New Generation Computer Technology
/*		���ۤ���¾��COPYRIGHT�ե�����򻲾Ȥ��Ʋ�����
/*		(Read COPYRIGHT for detailed information.)
 */
/***********************************************************************
 *   FILE NAME
 *	rec_add.h
 *   DESCRIPTION
 *	rec_add.c�Υإå��ե�����
 *   NOTES       
 *	
 *$  EDITOR : Tooru Shida
 *$           (MITSUBISHI ELECTRIC COMPUTER SYSTEMS (TOKYO) CORPORATION)
 *$  CREATE : '94-07-
 *$
 ***********************************************************************/

#include "rec.h"
#include <klic/gd_macro.h>
#include "../shp/shp.h"
#ifndef RECTEST
#include "../tbp/format/ifmt.h"
#include "../kgobj/newgobj.h"
#else
#include "iformat.h"
#include "newgobj.h"
#endif


/* �����ؿ��ץ��ȥ�������� */

q *rec_AddRecord(q *value_list, struct ifmt_IFormat *internal_format,
		 int rid, int page_size, char **record, int *rec_length,
		 q *idx_add_strm, q *g_allocp);

q GetFixOccList(q *occ_list, int occ_num, q *g_allocp);

char *ReverseNString(char *string, int length);

char *ReverseString(char *string);


/* �����ѿ���� */

/* �������ȴؿ��ץ��ȥ�������� */

extern q element_of_vector(q v, q k);

extern char *convert_klic_string_to_c_string(q s);

extern q convert_c_string_to_klic_string(char *cstr, q *g_allocp);

extern char *term_Encode(q term, char *sp);

/* ���������ѿ���� */

/* ��������ޥ������ */
#define    NULL_VALUE_LENGTH        5
#define    ATOM_nil                 G_atom(nil) /* (char *)("nil") */
#define    ATOM_bottom              G_atom(bottom) /* (char *)("bottom") */
/* #define    ATOM_NIL                 (char *)("nil") */
/* #define    ATOM_BOTTOM              (char *)("bottom") */
#define    STR_FIRST                0
#define    STR_SECOND               1
#define    STR_THIRD                2
#define    STR_FOURTH               3
#define    BL_AREA_LENGTH           1
#define    RL_AREA_LENGTH           2    /* �쥳����Ĺ��Ǽ�ΰ��element�� */
#define    RID_AREA_LENGTH          2    /* RID��Ǽ�ΰ��element�� */
#define    OFFSET_AREA_LENGTH       2    /* ���ե��å��ΰ��element�� */
#define    CHILDCNT_AREA_LENGTH     1    /* ��°������Ǽ�ΰ��element�� */
#define    EMPTY_AREA_LENGTH        1    /* ���ͼ��̻ҳ�Ǽ�ΰ��element�� */
#define    OCCCNT_AREA_LENGTH       1    /* ������󥹿���Ǽ�ΰ��element�� */
#define    TWO_ELEMENT              2
#define    ONE_ELEMENT              1
#define    EMPTY_NIL                0x0000    /* �����ΰ����nil���̻� */
#define    EMPTY_BOTTOM             0x0001    /* �����ΰ����bottom���̻� */
#define    NIL_IDENTIFY             0x40000000  /* offset���nil���̻� */
#define    BOTTOM_IDENTIFY          0x80000000  /* offset���bottom���̻� */
#define    ONE_ATTR                 1
#define    KISUU_IDENTIFY           0x20000000  /* ������̻� */
#define    REP_NIL                  0x0001  /* �����ΰ����nil���̻� */
#define    REP_BOTTOM               0x0002  /* �����ΰ����bottom���̻� */
#define    REP_NIL_BOTTOM           0x0003  /* �����ΰ����nil&bottom���̻� */
#define    NOT_INDEXED              0       /* ��INDEX°�� */
/* #define    UNIQUE                   (char *)("unique") */
/* #define    NOT_UNIQUE               (char *)("not_unique") */
#define    ATOM_UNIQUE              G_atom(unique)
#define    ATOM_NOT_UNIQUE          G_atom(not__unique)
#define    ADD_IDX_INFO_SIZE        4
#define    ADD_SCAN_INFO_SIZE       2
#define    ADD_SUBSTR_INFO_SIZE     3
#define    IDX_INFO_FIRST           0
#define    IDX_INFO_SECOND          1
#define    IDX_INFO_THIRD           2
#define    IDX_INFO_FOURTH          3
#define    FOUR_BYTE_FIRST          24
#define    FOUR_BYTE_SECOND         16
#define    FOUR_BYTE_THIRD          8
#define    REC_DIVIDE               1
#define    MAX_LENGTH_UNDEFINED     0


/* �������빽¤�Ρ������ */

struct rec_OccList {
    struct rec_OccList *next;
    int occ;
};


/* ��������ؿ��ץ��ȥ�������� */

static void PutAllEmptyValue(int nil_bottom, int rid,
			     char **record, int *posi, int page_size);

static q *PutValueList(q *value_list, struct ifmt_IFormat *internal_format,
		       int rid, int page_size, char **record, int *posi,
		       int *rec_length, q *idx_add_strm, q *g_allocp);

static q *PutGroupValue(q *value_list, struct shp_ChildInfo *attr_info,
			int attr_cnt, int page_size, char **record,
			int *ofp, int *dfp, q *idx_add_strm,
			q *occ_list, q *g_allocp);

static int PutNilValue(char **record, int posi, int page_size);

static int PutBottomValue(char **record, int posi, int page_size);

static q *PutOneAttr(q *attr_value, struct shp_ChildInfo *attr_info,
		     int page_size, char **record, int *ofp, int *dfp, 
		     int head_posi, q *idx_add_strm,
		     q *occ_list, q *g_allocp);

static q *PutSimpleValue(q *attr_value, struct shp_AttrInfo2 *simple_info,
			 int page_size, char **record, int head_posi,
			 int *ofp, int *dfp, q *idx_add_strm,
			 q *occ_list, q *g_allocp);

static q *PutAttrValue(q *attr_value, struct shp_AttrInfo2 *simple_info,
		       int page_size, char **record, int head_posi,
		       int *ofp, int *dfp, q *return_attr_value,
		       q *g_allocp);

static q *PutRSimpleValue(q *attr_value, struct shp_AttrInfo2 *rsimple_info,
			  int page_size, char **record, int *ofp, int *dfp,
			  q *idx_add_strm, q *occ_list, q *g_allocp);

static q *PutRGroupValue(q *attr_value, struct shp_AttrInfo1 *rgroup_info,
			 int page_size, char **record, int *ofp, int *dfp,
			 q *occ_list, q *idx_add_strm, q *g_allocp);

static q *CreateIndexAddInfo(char *attr_name, enum shp_KeyRequest key_request,
			     struct shp_AccessRequest *acc_request,
			     enum shp_NilRequest nil_request, q *attr_value,
			     q *occ_list, q *idx_add_strm, q *g_allocp);

static q *CreateOnlyIndexAddInfo(char *attr_name, 
				 struct shp_IndexAttrList *ia_list,
				 q *attr_value, q *occ_list,
				 q *idx_add_strm, q *g_allocp);

static int Put4Byte(char **record, int posi, int integer, int page_size);

static int Put2Byte(char **record, int posi, int integer, int page_size);

static int PutAttribute(char **record, int posi, char *attr_value,
			int string_size, int page_size);

static int GetStringNumber(int posi, int page_size);

static q *CreateEmptyValueAddIndexInfo(int cnt,
				       struct shp_ChildInfo *info, 
				       q value, q *idx_add_strm,
				       q *occ_list, q *g_allocp);

/* �������볰���ѿ���� */

