/*
/*	(C)1992, 1993, 1995 Institute for New Generation Computer Technology
/*		���ۤ���¾��COPYRIGHT�ե�����򻲾Ȥ��Ʋ�����
/*		(Read COPYRIGHT for detailed information.)
 */
extern q vector_g_new(long argc, q *argv, q *g_allocp);
extern q byte__string_g_new(long argc, q *argv, q *g_allocp);
extern q dbyte__string_g_new(long argc, q *argv, q *g_allocp);
extern q convert_c_string_to_klic_string(char *cstr, q *g_allocp);
extern q convert_c_string_to_klic_string16(char *cstr, q *g_allocp);
extern q convert_binary_c_string_to_klic_string(char *cstr, long len, q *g_allocp);
extern q convert_binary_c_string_to_klic_string16(char *cstr, long len, q *g_allocp);

#define NEW_VECTOR(SIZE,VEC) {\
    argv[0] = G_MAKEINT((long) (SIZE)); \
    (VEC) = vector_g_new(1, argv, g_allocp); \
    if (isref((VEC))) {\
          fatal("internal error: string allocation failure\
 for vector_g_new");\
    }\
    g_allocp = heapp; }

#define NEW_BYTE_STRING(SIZE,STR) {\
    argv[0] = G_MAKEINT((long) (SIZE)); \
    (STR) = byte__string_g_new(1, argv, g_allocp); \
    if (isref((STR))) {\
          fatal("internal error: string allocation failure \
for byte__string_g_new");\
    }\
    g_allocp = heapp; }

#define NEW_DBYTE_STRING(SIZE,STR) {\
    argv[0] = G_MAKEINT((long) (SIZE)); \
    (STR) = dbyte__string_g_new(1, argv, g_allocp); \
    if (isref((STR))) {\
          fatal("internal error: string allocation failure\
 for dbyte__string_g_new");\
    }\
    g_allocp = heapp; }

#define CONVERT_C_STRING_TO_KLIC_STRING(CSTR,STR) {\
    (STR) = convert_c_string_to_klic_string((CSTR), g_allocp); \
    if (isref((STR))) {\
          fatal("internal error: string allocation failure \
convert_c_string_to_klic_string");\
    }\
    g_allocp = heapp; }

#define CONVERT_BINARY_C_STRING_TO_KLIC_STRING(CSTR,LEN,STR) {\
    (STR) = convert_binary_c_string_to_klic_string((CSTR), (LEN), g_allocp); \
    if (isref((STR))) {\
          fatal("internal error: string allocation failure \
convert_binary_c_string_to_klic_string");\
    }\
    g_allocp = heapp; }

#define CONVERT_C_STRING_TO_KLIC_STRING16(CSTR,STR) {\
    (STR) = convert_c_string_to_klic_string16((CSTR), g_allocp); \
    if (isref((STR))) {\
          fatal("internal error: string allocation failure \
convert_c_string_to_klic_string16");\
    }\
    g_allocp = heapp; }

#define CONVERT_BINARY_C_STRING_TO_KLIC_STRING16(CSTR,LEN,STR) {\
    (STR) = convert_binary_c_string_to_klic_string16((CSTR), (LEN), g_allocp);\
    if (isref((STR))) {\
          fatal("internal error: string allocation failure \
convert_binary_c_string_to_klic_string16");\
    }\
    g_allocp = heapp; }
