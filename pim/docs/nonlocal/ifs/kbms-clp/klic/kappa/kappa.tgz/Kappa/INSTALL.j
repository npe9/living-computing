%
%	(C)1992, 1993, 1995 Institute for New Generation Computer Technology
%	   1999 Japan Information Processing Development Center
%	        Research Institute for Advanced Information Technology
%
%		$BG[I[$=$NB>$O(BCOPYRIGHT$B%U%!%$%k$r;2>H$7$F2<$5$$(B
%		(Read COPYRIGHT for detailed information.)
%
    Kappa $B%$%s%9%H!<%kJ}K!(B

1. $B<B9T4D6-(B
    $B%^%7%s(B & OS:
	Sun SparcStation 10 running SunOS 4.1.3
	SparcCenter 2000 running SunOS 5.3 (Solaris 2.3)
    $B%U%!%$%k;HMQ%5%$%:(B:
	29 M bytes

2. $B%$%s%9%H!<%k$NJ}K!(B
    doc/man_j/install/install.tex $B$r;2>H$N$3$H(B
