/*
/*	(C)1992, 1993, 1995 Institute for New Generation Computer Technology
/*		���ۤ���¾��COPYRIGHT�ե�����򻲾Ȥ��Ʋ�����
/*		(Read COPYRIGHT for detailed information.)
 */
/***********************************************************************
 *   FILE NAME
 *	shp_print.h
 *   DESCRIPTION
 *	shp_print.c�Υإå��ե�����
 *$  EDITOR : Tooru Shida 
 *$           (MITSUBISHI ELECTRIC COMPUTER SYSTEMS (TOKYO) CORPORATION)
 *$  CREATE : '94-03-22 Tue
 *$  UPDATE : 
 ***********************************************************************/

/* �����ؿ��Υץ��ȥ�������� */

void shp_CDataPrint(struct shp_SchemaInfo *c_info, FILE *g_fp);

/* ��������ؿ��ץ��ȥ�������� */

static void print_table_info(struct shp_TableSchemaInfo *table_info,
			     FILE *g_fp);
static void print_group_info(struct shp_AttrInfo1 *group_info, FILE *g_fp);
static void print_simple_info(struct shp_AttrInfo2 *simple_info, FILE *g_fp);
static void print_index_info(struct shp_IndexInfo *index_info, FILE *g_fp);
static void print_table_key(struct shp_TableKeyInfo *table_key_info,
			    FILE *g_fp);
static void print_nil_request(enum shp_NilRequest nil_request, FILE *g_fp);
static void print_direct_del_flag(enum shp_DirectDelFlag direct_del_flag,
				  FILE *g_fp);
static void print_child_info(struct shp_ChildInfo *child_attr_info,
			     FILE *g_fp);
static void print_child_attr_element(struct shp_ChildInfo *child_attr_info,
				     FILE *g_fp);
static void print_nest_seq(struct shp_NestSequence *nest_seq, FILE *g_fp);
static void print_access_path(struct shp_AccessPath *acc_path, FILE *g_fp);
static void print_access_path_element(struct shp_AccessPath *acc_path,
				      FILE *g_fp);
static void print_repeating_path(struct shp_RepPath *repeating_path,
				 FILE *g_fp);
static void print_data_type(enum shp_DataType data_type, FILE *g_fp);
static void print_key_request(enum shp_KeyRequest key_request, FILE *g_fp);
static void print_foreign_key(struct shp_ForeignKey *foreign_key, FILE *g_fp);
static void print_reference_rule(enum shp_ReferenceRule reference_rule,
				 FILE *g_fp);
static void print_access_request(struct shp_AccessRequest *acc_request,
				 FILE *g_fp);
static void print_index_attr(struct shp_IndexAttrList *ia_list, FILE *g_fp);
static void print_index_attr_element(struct shp_IndexAttrList *ia_list,
				     FILE *g_fp);
static void print_set_key(struct shp_SetKeyInfo *set_key_info, FILE *g_fp);



