/*
/*	(C)1992, 1993, 1995 Institute for New Generation Computer Technology
/*		���ۤ���¾��COPYRIGHT�ե�����򻲾Ȥ��Ʋ�����
/*		(Read COPYRIGHT for detailed information.)
 */


/* -----------------------------------------------------------
/*   ste_integer  ,get_integer
/* -----------------------------------------------------------
 */
#define GET_INTEGER(value, ptr) \
     { (value) = ((*(unsigned short *) (ptr)) << 16) + \
                  *((unsigned short *) (ptr) + 1); \
       (int *) (ptr) += 1; }

#define GET_INTEGER_NM(value, ptr) \
     { (value) = ((*(unsigned short *) (ptr)) << 16) + \
                  *((unsigned short *) (ptr) + 1); }

#define SET_INTEGER(value, ptr) \
     { *((unsigned short *) (ptr))++ = (value) >> 16; \
        *(unsigned short *) (ptr)    = (value) & 0x0000ffff; \
         (unsigned short *) (ptr) += 1; }

#define SET_INTEGER_NM(value, ptr) \
     { *((unsigned short *) (ptr))++ = (value) >> 16; \
        *(unsigned short *) (ptr)    = (value) & 0x0000ffff; }

#define GET_SHORT_INTEGER(value, ptr) \
     { (value) = *(short *) (ptr); (short *) (ptr) += 1; }

#define GET_SHORT_INTEGER_NM(value, ptr) \
     { (value) = *(short *) (ptr); }

#define SET_SHORT_INTEGER(value, ptr) \
     { *(short *) (ptr) = (value); (short *) (ptr) += 1; }

#define SET_SHORT_INTEGER_NM(value, ptr) \
     { *(short *) (ptr) = (value); }

/* --------------------------------------------------------
/*   BCOPY
/* --------------------------------------------------------
 */
/* #define STRINGH
/* #define USEBCMP
/* #define USEBCOPY
/* #define USEBZERO
*/
#include <klic/config.h>
/*
#ifdef STRINGH
#include <string.h>
#else
#include <strings.h>
#endif

#ifdef USEBCMP
#define BCMP			bcmp
#else
#define BCMP			memcmp
#endif

#ifdef USEBCOPY
#define BCOPY(from,to,len)	bcopy(from,to,len)
#else
#define BCOPY(from,to,len)	memcpy(to,from,len)
#endif

#ifdef USEBZERO
#define BZERO(from,len)		bzero(from,len)
#else
#define BZERO(from,len)		memset(from,0,len)
#endif
*/
