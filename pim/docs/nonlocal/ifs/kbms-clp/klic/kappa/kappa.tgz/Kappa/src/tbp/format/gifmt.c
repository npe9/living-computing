/*
/*	(C)1992, 1993, 1995 Institute for New Generation Computer Technology
/*		���ۤ���¾��COPYRIGHT�ե�����򻲾Ȥ��Ʋ�����
/*		(Read COPYRIGHT for detailed information.)
 */
/***********************************************************************
 *   FILE NAME
 *      gifmt.c
 *   DESCRIPTION
 *      �����ե����ޥåȤΥ����ͥ�å����֥�������
 *   INTERFACE ROUTINES
 *   NOTES:
 *
 *$  EDITOR : Toru Kawamura
 *$  CREATE : '94-06-07
 *$  UPDATE :     06-30
 *$               08-19  freetblp, GDDEF_GC(), GDDEF_DEALLOCATE()
 ***********************************************************************/
#include <stdio.h>
#include <klic/g_pointer.h>
#include <klic/gdobject.h>
#include "ifmt.h"
#include "atom.h"
#include "funct.h"

struct internal_format_object {
  struct data_object_method_table *method_table;
  struct ifmt_IFormat *ifmtp;
  struct fmt_FreeTable *freetblp;
};

#define GD_CLASS_NAME() internal__format
#define GD_OBJ_TYPE struct internal_format_object
#define GD_OBJ_SIZE(obj) (G_SIZE_IN_Q(GD_OBJ_TYPE))


#include <klic/gd_macro.h>

/* basic method definitions */

GDDEF_GC()
{
  G_STD_DECL;
  GD_OBJ_TYPE *newself;

  GDSET_NEWOBJ_IN_NEWGEN(newself);
  newself->ifmtp = GD_SELF->ifmtp;
  newself->freetblp = GD_SELF->freetblp;
  GD_RETURN_FROM_GC(newself);
}

GDDEF_DEALLOCATE()
{
  extern fmt_FreeArea(struct fmt_FreeTable *freetblp);
  G_STD_DECL;

  fmt_FreeArea(GD_SELF->freetblp);
  return 0; /* GD_RETURN_FROM_DEALLOCTE; */
}

/* Generic method */

GDDEF_METHOD(get__ifmt_1)
{
  G_STD_DECL;
  extern q gd_new_pointer(q arg0, q *g_allocp);
  q ptrobj = gd_new_pointer((q)GD_SELF->ifmtp,g_allocp);
  GD_UNIFY_VALUE(GD_ARGV[0], ptrobj);
  g_allocp = heapp;
  GD_RETURN;
}

/*GDDEF_METHOD(print__ifmt_1)
{
  G_STD_DECL;
  extern void fmt_print(struct ifmt_IFormat *ifmtp);
  q ptrobj = GD_ARGV[0];
  GD_DEREF(ptrobj);
  fmt_print((struct ifmt_IFormat *)
               ((struct pointer_object *)data_objectp(ptrobj))->pointer);
  GD_RETURN;
}*/

/*  Generic Method Table */
GDDEF_GENERIC()
{
  G_STD_DECL;

  GD_SWITCH_ON_METHOD{
    GD_METHOD_CASE(get__ifmt_1);
/*    GD_METHOD_CASE(print__ifmt_1);*/
    GD_METHOD_CASE_DEFAULT;
  }
  GD_RETURN;
}

/* guard generic methods */
/* Empty */

#define GDUSE_MY_GC
#define GDUSE_MY_GENERIC
#define GDUSE_MY_DEALLOCATE
/* 
/* #define GDUSE_MY_GUNIFY
/* #define GDUSE_MY_UNIFY
/* #define GDUSE_MY_PRINT
/* #define GDUSE_MY_GGENERIC
/* #define GDUSE_MY_COMPARE
/* #define GDUSE_MY_HASH
 */

#include <klic/gd_methtab.h>

GDDEF_NEW()
{
  GD_STD_DECL_FOR_NEW;
  q create_ifmt(long,q*,q*);

  return create_ifmt(1,GD_ARGV,g_allocp);
}


q create_ifmt(GD_ARGC,GD_ARGV,g_allocp)
long GD_ARGC;
q    GD_ARGV[];
q *g_allocp;
{
  extern struct ifmt_IFormat *fmt_ConvIfmt(q imtfmt, 
                                    struct fmt_FreeTable **freetblpp);
  GD_STD_DECL_FOR_NEW;
  GD_OBJ_TYPE *ifmt;
  q imtfmt;                /* intermediate format */

  imtfmt = GD_ARGV[0];
  GD_DEREF_FOR_NEW(imtfmt);
  GDSET_NEWOBJ_FOR_NEW(ifmt, G_SIZE_IN_Q(GD_OBJ_TYPE));
  ifmt->ifmtp = fmt_ConvIfmt(imtfmt, &ifmt->freetblp);
  heapp = g_allocp;
  GD_RETURN_FROM_NEW(ifmt);
}

