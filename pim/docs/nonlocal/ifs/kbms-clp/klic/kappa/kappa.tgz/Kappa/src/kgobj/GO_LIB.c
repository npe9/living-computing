/*
/*	(C)1992, 1993, 1995 Institute for New Generation Computer Technology
/*		���ۤ���¾��COPYRIGHT�ե�����򻲾Ȥ��Ʋ�����
/*		(Read COPYRIGHT for detailed information.)
 */
/*---------------------------------------------------------------------------
 *  get_and_set_bit(StrSize,Posi,OnOff,OldOnOff,NStr) 
 *  
 *  �ӥåȤλ��Ȥȥ��å�
 * 
 *  ARGUMENT: StrSize    - ��ʸ���Υӥå���
 *            Posi       - �ӥåȤΰ���
 *            OnOff      - �ӥåȤ���(0 �ޤ��� 1)
 *            OldOnOff   - �ӥåȤΰ��֤���(0 �ޤ��� 1)
 *            NStr       - �ӥåȥ��åȸ��ʸ����
 *            
 *  RETURN: �ʤ�
 *
 *---------------------------------------------------------------------------
 */

GDDEF_METHOD(get__and__set__bit_5) 
{
  G_STD_DECL;
  long position, strsize, ele_posi, bit_posi;
  GD_OBJ_TYPE *newstr;
  ELEMCTYPE *body, newdata, olddata;
  int iscnst;
  long size;
  int on_off;

  Shallow(GD_SELF);
  size = GD_SELF->index;
  iscnst = GD_SELF->iscnst;
  body = GD_SELF->body;

  GDSET_INTARG_WITHIN_RANGE(strsize,GD_ARGV[0],0,ELEMSIZE+1);
  GDSET_INTARG_WITHIN_RANGE(position,GD_ARGV[1],0,strsize*size);
  GDSET_INTARG_WITHIN_RANGE(on_off,GD_ARGV[2],0,2);
  GDSET_NEWOBJ(newstr);

  ele_posi = position / strsize;
  bit_posi = position % strsize;
  olddata = body[ele_posi];
  if ( on_off == 0 ) {
    newdata = olddata & (~(1 << (strsize - bit_posi - 1)));
  } else {
    newdata = olddata | (1 << (strsize - bit_posi - 1));
  }
  GD_UNIFY(GD_ARGV[3],G_MAKEINT((long)((olddata & (1 << bit_posi )) >> bit_posi)));
  if (!iscnst) {
    GD_SELF->index = position;
    GD_SELF->body = (ELEMCTYPE *)(unsigned long)olddata;
/*    GD_SELF->data = olddata;*/
    body[ele_posi] = newdata;
    GD_SELF->next = GD_OBJ(newstr);
    newstr->body = body;
  } else {
    long k;
    ELEMCTYPE *newbody;
    long qsize = ROUND_UP(size);
    GD_ALLOC_AREA(newbody, (ELEMCTYPE *), qsize);
    BCOPY(body, newbody, qsize*sizeof(q));
    newbody[ele_posi] = newdata;
    newstr->body = newbody;
  }
  newstr->next = STRING16_SHALLOW_MARK;
  newstr->index = size;
  newstr->iscnst = iscnst;
  
  GD_UNIFY_VALUE(GD_ARGV[4], GD_OBJ(newstr));
  GD_RETURN;
}

/*---------------------------------------------------------------------------
 *  set_bit(StrSize,Posi,OnOff,NStr) 
 *  
 *  �ӥåȤΥ��å�
 * 
 *  ARGUMENT: StrSize    - ��ʸ���Υӥå���
 *            Posi       - �ӥåȤΰ���
 *            OnOff      - �ӥåȤ���(0 �ޤ��� 1)
 *            OldOnOff   - �ӥåȥ��åȸ��ʸ����
 *            
 *  RETURN: �ʤ�
 *
 *---------------------------------------------------------------------------
 */

GDDEF_METHOD(set__bit_4) 
{
  G_STD_DECL;
  long position, strsize, ele_posi, bit_posi;
  GD_OBJ_TYPE *newstr;
  ELEMCTYPE *body,newdata,olddata;
  int iscnst;
  long size;
  int on_off;
  int i;

  Shallow(GD_SELF);
  size = GD_SELF->index;
  iscnst = GD_SELF->iscnst;
  body = GD_SELF->body;

  GDSET_INTARG_WITHIN_RANGE(strsize,GD_ARGV[0],0,ELEMSIZE+1);
  GDSET_INTARG_WITHIN_RANGE(position,GD_ARGV[1],0,strsize*size);
  GDSET_INTARG_WITHIN_RANGE(on_off,GD_ARGV[2],0,2);
  GDSET_NEWOBJ(newstr);

  ele_posi = position / strsize;
  bit_posi = position % strsize;
  olddata = body[ele_posi];

  if ( on_off == 0 ) {
    newdata = olddata & (~(1 << (strsize - bit_posi - 1)));
  } else {
    newdata = olddata | (1 << (strsize - bit_posi - 1));
  }
  if (!iscnst) {
    GD_SELF->index = position;
    GD_SELF->body = (ELEMCTYPE *)(unsigned long)olddata;
/*    GD_SELF->data = olddata;*/
    body[ele_posi] = newdata;
    GD_SELF->next = GD_OBJ(newstr);
    newstr->body = body;
  } else {
    long k;
    ELEMCTYPE *newbody;
    long qsize = ROUND_UP(size);
    GD_ALLOC_AREA(newbody, (ELEMCTYPE *), qsize);
    BCOPY(body, newbody, qsize*sizeof(q));
    newbody[ele_posi] = newdata;
    newstr->body = newbody;
  }

/*for(i=0;i < size ;i++){printf("%x ",newstr->body[i]);}printf("\n"); 
printf("newelm=%d\nnewelmklic=%d\n",newdata,newstr->body[ele_posi]);*/

  newstr->next = STRING16_SHALLOW_MARK;
  newstr->index = size;
  newstr->iscnst = iscnst;
  GD_UNIFY_VALUE(GD_ARGV[3], GD_OBJ(newstr));
  GD_RETURN;
}

