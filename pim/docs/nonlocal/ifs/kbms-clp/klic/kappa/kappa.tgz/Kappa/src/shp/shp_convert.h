/*
/*	(C)1992, 1993, 1995 Institute for New Generation Computer Technology
/*		���ۤ���¾��COPYRIGHT�ե�����򻲾Ȥ��Ʋ�����
/*		(Read COPYRIGHT for detailed information.)
 */
/***********************************************************************
 *   FILE NAME
 *	shp_convert.h
 *   DESCRIPTION
 *	shp_convert.c�Υإå��ե�����
 *   INTERFACE ROUTINES
 *      
 *   NOTES       
 *	
 *$  EDITOR : Tooru Shida
 *$           (MITSUBISHI ELECTRIC COMPUTER SYSTEMS (TOKYO) CORPORATION)
 *$  CREATE : '94-03-02 Wed
 *$  UPDATE : 
 ***********************************************************************/

#include <klic/gdobject.h>
#include <klic/gd_macro.h>
#include <klic/atomstuffs.h>
#include <klic/g_vector.h>
#include "g_kappa_shp.h"
#include "shp.h"

/* �����ؿ��Υץ��ȥ�������� */
int shp_ConvertKLIC2C(q klic_info, struct shp_SchemaInfo *c_info);
q shp_DerefOne(q x);

/* �����ѿ���� */
q *allocp;

/* �������ȴؿ��ץ��ȥ�������� */
extern unsigned long enter_atom_string();
extern char *convert_klic_string_to_c_string(q);
extern q convert_c_string_to_klic_string();
extern q element_of_vector();


/* ���������ѿ���� */


/* ��������ޥ������ */

/* �����ե����ޥå����귿���ȥ� */

#define TABLE           (char *)("table")
#define GROUP           (char *)("group")
#define REPEAT_GROUP    (char *)("repeat_group")
#define SIMPLE          (char *)("simple")
#define REPEAT_SIMPLE   (char *)("repeat_simple")
#define INDEX           (char *)("index")
#define SET             (char *)("set")
#define SINGLE          (char *)("single")
#define STRING          (char *)("string")
#define INTEGER         (char *)("integer")
#define FLOAT           (char *)("float")
#define DOUBLE_FLOAT    (char *)("double_float")
#define TERM            (char *)("term")
#define PSI_STRING      (char *)("psi_string")
#define NIL             (char *)("nil")
#define PRIMARY         (char *)("primary")
#define NON_KEY         (char *)("non_key")
#define NON_INDEXED     (char *)("non_indexed")
#define SUBSTRING       (char *)("substring")
#define CONCAT1         (char *)("concat1")
#define CONCAT2         (char *)("concat2")
#define CONCAT3         (char *)("concat3")
#define REVERSE         (char *)("reverse")
#define SCAN            (char *)("scan")
#define ALLOWED         (char *)("allowed")
#define NOT_ALLOWED     (char *)("not_allowed")
#define NOT_NIL         (char *)("not_nil")
#define NOT_BOTTOM      (char *)("not_bottom")
#define ASTAR           (char *)("*")
#define ON              (char *)("on")
#define OFF             (char *)("off")
#define CASCADES        (char *)("cascades")
#define RESTRICTED      (char *)("restricted")
#define NULLIFIES       (char *)("nullifies")

/* ����� */
#define NORMAL          0
#define ABNORMAL        -1

/* �٥��������դ��� */
#define FIRST           0
#define SECOND          1
#define THIRD           2
#define FOURTH          3
#define FIFTH           4
#define SIXTH           5
#define SEVENTH         6
#define EIGHTH          7
#define NINETH          8
#define TENTH           9
#define ELEVENTH        10
#define TWELFTH         11
#define THIRTEENTH      12
#define FOURTEENTH      13
#define FIFTEENTH       14

#define ELEMENT(v, p)   element_of_vector(v, G_MAKEINT(p))

#define KP_GD_TDDEREF(x); \
{ \
    while(1) { \
	if( G_ISREF(x) ) { \
	    q deref_x = G_DEREFONE(x); \
	    if( G_ISREF(deref_x) && G_DEREFONE(deref_x)) { \
		break; \
	    } else { \
		x = deref_x; \
	    } \
	} else { \
	    break; \
	} \
    } \
}

/* �������빽¤�Ρ������ */

/* �٥����������ͥ�å����֥������� */

/* ��������ؿ��ץ��ȥ�������� */
int convert_table_info(q klic_info, struct shp_TableSchemaInfo *table_info);
int convert_group_info(q klic_info, struct shp_AttrInfo1 *group_info);
int convert_simple_info(q klic_info, struct shp_AttrInfo2 *simple_info);
int convert_index_info(q klic_info, struct shp_IndexInfo *index_info);
void convert_table_key_info(q table_key_klic,
			    struct shp_TableKeyInfo *table_key_c);
enum shp_NilRequest convert_nil_request(q nil_request_klic);
enum shp_DirectDelFlag convert_direct_del_flag(q direct_def_flag_klic);
void convert_child_attr_info(q child_info_klic, int child_attr_cnt,
			     struct shp_ChildInfo *child_info_c);
void convert_nest_seq(q nest_seq_klic, struct shp_NestSequence *nest_seq_c);
void convert_access_path(q acc_path_klic, struct shp_AccessPath *acc_path_c);
void convert_set_key_info(q set_key_klic, struct shp_SetKeyInfo *set_key_c);
void convert_repeating_path(q rep_path_klic, struct shp_RepPath *rep_path_c);
enum shp_DataType convert_data_type(q data_type_klic);
enum shp_KeyRequest convert_key_request(q key_request_klic);
void convert_access_request(q access_request_klic,
			    struct shp_AccessRequest *access_request_c);
void convert_predicate_function(q list,
				struct shp_IndexAttrList *pred_func_list);
void convert_foreign_key(q foreign_key_klic,
			 struct shp_ForeignKey *foreign_key_c);
q shp_DerefOne(q x);


/* �������볰���ѿ���� */

