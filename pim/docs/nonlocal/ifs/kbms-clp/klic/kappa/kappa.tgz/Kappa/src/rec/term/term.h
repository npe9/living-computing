/*
/*	(C)1992, 1993, 1995 Institute for New Generation Computer Technology
/*		���ۤ���¾��COPYRIGHT�ե�����򻲾Ȥ��Ʋ�����
/*		(Read COPYRIGHT for detailed information.)
 */
/*************************************************************************
 *   FILE NAME
 *      term.h
 *   DESCRIPTION
 *      ����������ѥإå����ե�����
 *$  EDITOR : Toru Kawamura
 *$  CREATE : '94-04-2
 *$  UPDATE : '94-09-14
 *$               10-31
 *$               11-08  <stddef.h>,<string.h> comment out
 **************************************************************************/
/*#include <stddef.h>
/*#include <string.h>
 */
#include <klic/basic.h>
#include <klic/struct.h>
#include <klic/primitives.h>
#include <klic/index.h>
#include <klic/generic.h>
#include <klic/atomstuffs.h>
#include <klic/functorstuffs.h>
#include <klic/g_basic.h>
#include <klic/g_methtab.h>
#include <klic/g_vector.h>
#include <klic/g_string.h>
#include <klic/gd_macro.h>
#include "../../kgobj/g_string16.h"
#include "../../kgobj/newgobj.h"
#include "../../lib/libstring.h"
#include "termlist.h"            /* REC�ѤΥ��ȥ�󥰳�Ǽ�ꥹ�� */


/*  the following define should be undefined when new type term is uesd. */
/*#define OLD_TYPE_TBD  1
/*#undef OLD_TYPE_TBD
 */

/* Tag Value of Data Type */
#define TAG_SPECIAL_ATOM  0x0
#define TAG_ATOM          0x1
#define TAG_INTEGER32     0x2
#define TAG_INTEGER28     0x3
#define TAG_INTEGER12     0x4
#define TAG_FLOATING      0x5
#define TAG_VECTOR        0x6
#define TAG_LIST          0x7
#define TAG_STRING8       0x8
#define TAG_STRING16      0x9
#define TAG_FUNCTOR       0xA

#define TAG_SIZE          2
#define SYMNAME_SIZE      2

/* SPECIAL ATOM */
#define TAG_EMPTY_LIST    0
#define TAG_NIL           1


#define MAX_ATOM_LENGTH   1024

/* String List */
struct term_StrList {
    char *sp;      /* start pointer */
    char *ep;      /* end pointer */
    int list_type; /* 0 : stolist, 1 : recstolp */
    union {
	q    stolist;                   /* string list(klic data) */
	struct term_StringList *rstolp; /* string list(C data) */
    } u;
};

typedef struct term_StrList sl;


/*===========*/
/*  KLIC     */
/*===========*/
#define STRING_OBJ(x)   ((struct byte_string_object *)(G_FUNCTORP(x)))
#define STRING16_OBJ(x) ((struct dbyte_string_object *)(G_FUNCTORP(x)))

extern q size_of_vector(q v);
extern q element_of_vector(q v, q k);
extern q size_of_string(q s);
extern q size_of_string16(q s);
extern unsigned char *generic_string_body(struct byte_string_object *s);
extern unsigned short *generic_string16_body(struct dbyte_string_object *s);

extern struct data_object_method_table
    data_object_method_table_of(dbyte__string),
    data_object_method_table_of(byte__string),
    data_object_method_table_of(float),
    data_object_method_table_of(vector);

extern unsigned long enter_functor();
extern unsigned long enter_atom_cstring(char *str);
