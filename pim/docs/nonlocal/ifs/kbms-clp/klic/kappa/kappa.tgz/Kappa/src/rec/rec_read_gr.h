/*
/*	(C)1992, 1993, 1995 Institute for New Generation Computer Technology
/*		���ۤ���¾��COPYRIGHT�ե�����򻲾Ȥ��Ʋ�����
/*		(Read COPYRIGHT for detailed information.)
 */
/***********************************************************************
 *   FILE NAME
 *	rec_read_gr.h
 *   DESCRIPTION
 *	rec_read_gr.c�Υإå��ե�����
 *$  EDITOR : Tooru Shida 
 *$           (MITSUBISHI ELECTRIC COMPUTER SYSTEMS (TOKYO) CORPORATION)
 *$  CREATE : '94-01-27
 *$  UPDATE : 
 ***********************************************************************/

#include "rec.h"
#include "../shp/shp.h"
#ifndef RECTEST
#include "../tbp/format/ifmt.h"
#include "../kgobj/newgobj.h"
#else
#include "iformat.h"
#include "newgobj.h"
#endif


/* �����ؿ��ץ��ȥ�������� */

q *rec_ReadGrouping(struct ifmt_IFormat *internal_format, q *rec_sri,
		    char **record, int str_cnt, int page_size,
		    int record_length, q *value_list, q *g_allocp);

char *GetOffsetAndNextOffset(int posi, int next_posi, char *record,
			     int field_length, int *offset, int *next_offset,
			     int *nil_flag, int *gk_flag);

/* �����ѿ���� */

/* �������ȴؿ��ץ��ȥ�������� */

extern q *ReadSimple(int offset, int next_offset,
		     enum shp_DataType data_type, int gk_flag,
		     char *record, q *value_list, q *g_allocp);

extern q *ReadRepeatSimple(int field_length, int gk_flag, char *record,
			   q *rec_sri, enum shp_DataType data_type,
			   q *value_list, q *g_allocp);

extern q *ReadGroup(struct shp_ChildInfo *group_info, q *rec_sri,
		    char *record, int str_cnt, int field_length,
		    int attr_cnt, q *value_list, q *g_allocp);

extern q *ReadRepeatGroup(struct shp_ChildInfo *attr_info,
			  q *rec_sri, char *record, int str_cnt,
			  int field_length, int child_attr_cnt,
			  q *value_list, q *g_allocp);

extern q GetSRI(q rec_sri, int attr_posi);

extern q *ReadKeyField(struct ifmt_IFormat *internal_format,
		       q *rec_sri, char *record, int field_length,
		       q *value_list, q *g_allocp);

/* extern char *rec_StrnCpy(int *substring, char *string,  int size); */

extern int GetNextOffset(int offset, char *record,
			 int next_nint_posi, int field_length);

extern q shp_DerefOne(q x);

extern q element_of_vector();

/* ���������ѿ���� */

/* ��������ޥ������ */

/* �������빽¤�Ρ������ */

/* ��������ؿ��ץ��ȥ�������� */

static q *MoveAndReadField(struct shp_AccessPath *access_path,
			   struct ifmt_Group *group, q *rec_sri,
			   char *record, int str_cnt, int field_length,
			   q *value_list, q *g_allocp);

static q *GetGroupAttr(struct ifmt_Group *group, q *rec_sri,
		       char *record, int str_cnt, int field_length,
		       q *value_list, q *g_allocp);

static q *GetRepeatGroupAttr(struct ifmt_Group *group, q *rec_sri,
			     char *record, int str_cnt, int field_length,
			     q *value_list, q *g_allocp);

static q *MoveAndReadSRI(short occ_cnt, q *rec_sri, char *record,
			 int str_cnt, int field_length,
			 struct shp_AccessPath *access_path,
			 struct ifmt_Group *group, q *value_list,
			 q *g_allocp);

static q *ReadAndMoveGroupField(q *rec_sri, char *record, int str_cnt,
				int field_length,
				struct shp_AccessPath *access_path,
				struct ifmt_Group *group, q *value_list,
				q *g_allop);

/* �������볰���ѿ���� */

