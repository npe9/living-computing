/*
/*	(C)1992, 1993, 1995 Institute for New Generation Computer Technology
/*		���ۤ���¾��COPYRIGHT�ե�����򻲾Ȥ��Ʋ�����
/*		(Read COPYRIGHT for detailed information.)
 */
/***********************************************************************
 *   FILE NAME
 *	ixp.h
 *   DESCRIPTION
 *	ixp�Υإå��ե�����
 *$  EDITOR : ���� ��
 *$           (MITSUBISHI ELECTRIC COMPUTER SYSTEMS (TOKYO) CORPORATION)
 *$  CREATE : 
 *$  UPDATE : 
 *
 ***********************************************************************
 */


#include <klic/basic.h>
#include <klic/struct.h>
#include <klic/g_basic.h>


/* Integer Value */
#define  PLENGTH   4096

#define  KEYL       2     /* Key Length Housed Area Length(byte) */
#define  KINT_L     4     /* Kappa Integer Length (byte)  */

#define  SICPOSI    2     /* Search Info Count Position */
#define  NLPN_Posi  12    /* Next Page LPN House Position(byte) */
#define  PLPN_Posi  8     /* Prebiouse Page LPN House Position(byte) */



/* Error or Normal */
#define  ERROR     -1
#define  Normal     0

/* Access Type */
#define  equal_idx 0
#define  ascend    1
#define  ascend_e  2
#define  descend   3
#define  descend_e 4

/* Compare Key Result */
#define  Same      0
#define  NotSame   1
#define  Large     2
#define  Small     3


/* Data Type */
#define TYP_INT    0
#define TYP_STR    1
#define TYP_PSTR   2


/* Search Range */
#define EQU        0
#define GE         1
#define GT         2
#define LE         3
#define LT         4

/* Scan Type */
#define ascend_type  1
#define descend_type 2

/* Hit Flag */
#define HIT     0
#define NO_HIT  1

/* LPN Info */
#define  OnPage  0
#define  NoData  1

#define  HERE_LPN  0
#define  ChildPage 1
#define  NEXT_LPN  2


/* ODD Flag Control */
#define ODD_MASK   0x7FFF


/* Function Answer */
#define  YES    0
#define  NO     1


/* String Access Offset for get/set LPN */
#define STR_FIRST         0          /* ʸ���Ǿ�̰��� */
#define STR_SECOND        1          /* ʸ������̰��� */
#define STR_THIRD         2          /* ʸ���軰�̰��� */
#define STR_FOURTH        3          /* ʸ����Ͱ̰��� */

/* OCC FLAG */
#define NO_OCC  0      /* Nest Level = 0 */
