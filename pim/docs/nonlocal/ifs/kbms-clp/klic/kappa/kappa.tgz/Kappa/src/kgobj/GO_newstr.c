/*
/*	(C)1992, 1993, 1995 Institute for New Generation Computer Technology
/*		���ۤ���¾��COPYRIGHT�ե�����򻲾Ȥ��Ʋ�����
/*		(Read COPYRIGHT for detailed information.)
 */
/*************************************************************************
 *   FILE NAME
 *      GO_newstr.c
 *   DESCRIPTION
 *      Generic Object gstring16.c �� new��ǽ�ˡ��������Ǽ�ѤΥ��֥�������
 *      ���������뵡ǽ���ɲä����ǡ�
 *   INTERFACE ROUTINES
 *      GDDEF_NEW() - �����ο������ξ��ˡ��������ѤΥ��֥������Ȥ��������롣
 *   NOTE
 *      ���Υե�����ϡ�gstring16.c �˥��󥯥롼�ɤ���롣
 *$  EDITOR : Toru Kawamura
 *$  CREATE : '94-04-2
 *$  UPDATE : '94-09-16
 **************************************************************************/
GDDEF_NEW()
{
  extern char *term_Encode(q term, char *str);
  GD_STD_DECL_FOR_NEW;
  GD_OBJ_TYPE *newstr;
  ELEMCTYPE *body;
  unsigned long size;
  unsigned long short_size;
  unsigned long byte_size;
  q result;
  q init;
  q term;

  if (GD_ARGC!=1 && GD_ARGC!=2) 
      GD_ERROR_IN_NEW("Too few or too many arguments");
  if (GD_ARGC==2) {
      term = GD_ARGV[0];
      GD_DEREF_FOR_NEW(term);
      GD_DEREF_FOR_NEW(GD_ARGV[1]);
      byte_size = G_INTVAL(GD_ARGV[1]); /* KLIC�ΰ����ͽ¬�̡ʥХ���ñ�̡�*/
      GDSET_NEWOBJ_FOR_NEW(newstr, G_SIZE_IN_Q(GD_OBJ_TYPE));
      GD_ALLOC_AREA_FOR_NEW((q *)body, (q *),
			    (byte_size + sizeof(q) - 1) / sizeof(q));
      byte_size = term_Encode(term, (char *)body) - (char *) body;
      short_size = (byte_size + sizeof(short) - 1) / sizeof(short);
      g_allocp += ROUND_UP(short_size);
      newstr->next = STRING16_SHALLOW_MARK;
      newstr->iscnst = 0;
      newstr->index = short_size;
      newstr->body = body;
      GD_RETURN_FROM_NEW(newstr);
  }
  init = GD_ARGV[0];
  GD_DEREF_FOR_NEW(init);
  GDSET_NEWOBJ_FOR_NEW(newstr, G_SIZE_IN_Q(GD_OBJ_TYPE));
  if (G_ISINT(init)) {
    unsigned long qsize;
    size = G_INTVAL(init);
    if (size < 0) GD_ERROR_IN_NEW("Negative size specified");
    qsize = ROUND_UP(size);
    GD_ALLOC_AREA_FOR_NEW(body, (ELEMCTYPE *), qsize);
    BZERO(body, qsize*sizeof(q));
  } else if (init==NILATOM || G_ISCONS(init)) {
    unsigned long qsize, k;
    for (size=0; ; size++) {
      q elem;
      if (init == NILATOM) break;
      elem = G_CAR_OF(init);
      GD_DEREF_FOR_NEW(elem);
      if (!G_ISINT(elem) || G_INTVAL(elem) < 0 
                         || ELEMMAXVAL+1 <= G_INTVAL(elem)) {
	GD_ERROR_IN_NEW("Illegal parameter");
      }
      init = G_CDR_OF(init);
      GD_DEREF_FOR_NEW(init);
      if (init!=NILATOM && !G_ISCONS(init))
	GD_ERROR_IN_NEW("Illegal parameter");
    }
    qsize = ROUND_UP(size);
    init = GD_ARGV[0];
    GD_ALLOC_AREA_FOR_NEW(body, (ELEMCTYPE *), qsize);
    for (k=0; k<size; k++) {
      q elem;
      GD_DEREF_FOR_NEW(init);
      elem = G_CAR_OF(init);
      GD_DEREF_FOR_NEW(elem);
      body[k] = G_INTVAL(elem);
      init = G_CDR_OF(init);
    }
  } else {
    GD_ERROR_IN_NEW("Illegal parameter");
  }
  newstr->next = STRING16_SHALLOW_MARK;
  newstr->iscnst = 0;
  newstr->index = size;
  newstr->body = body;
  GD_RETURN_FROM_NEW(newstr);
}
