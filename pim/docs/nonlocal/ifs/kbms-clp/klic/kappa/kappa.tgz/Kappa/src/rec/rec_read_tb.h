/*
/*	(C)1992, 1993, 1995 Institute for New Generation Computer Technology
/*		���ۤ���¾��COPYRIGHT�ե�����򻲾Ȥ��Ʋ�����
/*		(Read COPYRIGHT for detailed information.)
 */
/***********************************************************************
 *   FILE NAME
 *	rec_read_tb.h
 *   DESCRIPTION
 *	rec_read_tb.c�Υإå��ե�����
 *$  EDITOR : Tooru Shida 
 *$           (MITSUBISHI ELECTRIC COMPUTER SYSTEMS (TOKYO) CORPORATION)
 *$  CREATE : '93-12-26
 *$  UPDATE : '94-04-26~ by Shida(MTC) for Kappa version Q02
 *$
 ***********************************************************************/

#include "rec.h"
#include "../shp/shp.h"
#include "term/termlist.h"
#ifndef RECTEST
#include "../tbp/format/ifmt.h"
#include "../kgobj/newgobj.h"
#else
#include "iformat.h"
#include "newgobj.h"
#endif


/* �����ؿ��ץ��ȥ�������� */

q *rec_ReadAllTable(struct ifmt_IFormat *internal_format, q *rec_sri,
		    char **record, int str_cnt, int page_size,
		    int record_length, q *value_list, q *g_allocp);

q *rec_ReadNil(struct ifmt_IFormat *internal_format, q *rec_sri,
	       char *record[], int str_cnt, int page_size, int record_length,
	       q *value_list, q *g_allocp);

q *ReadSimple(int offset, int next_offset, enum shp_DataType data_type,
	      int gk_flag, char *record, q *value_list, q *g_allocp);

q *ReadRepeatSimple(int field_length, int gk_flag, char *record,
		    q *rec_sri, enum shp_DataType data_type,
		    q *value_list, q *g_allocp);

q *ReadGroup(struct shp_ChildInfo *group_info, q *rec_sri, char *record,
	     int str_cnt, int field_length, int attr_cnt, q *value_list,
	     q *g_allocp);

q *ReadRepeatGroup(struct shp_ChildInfo *attr_info, q *rec_sri,
		   char *record, int str_cnt, int field_length,
		   int child_attr_cnt, q *value_list, q *g_allocp);

q *ReadKeyField(struct ifmt_IFormat *internal_format,
		q *rec_sri, char *record, int field_length,
		q *value_list, q *g_allocp);

int GetNextOffset(int offset, char *record, int next_nint_posi,
		  int field_length);

/* �����ѿ���� */

/* �������ȴؿ��ץ��ȥ�������� */

extern q element_of_vector();

extern int Psi2Euc(int len, char *psi_str, char *euc_str);

extern q convert_c_string_to_klic_string(char *cstr, q *g_allcop);

extern q GetSRI(q rec_sri, int i);

/* extern char *rec_StrnCpy(int *substring, char *string,  int size); */

extern q shp_DerefOne(q x);

extern q *term_Decode(char *str, int strlen,
		      struct term_StringList *spand_string_list,
		      q *termp, q *g_allocp);

/* ���������ѿ���� */

/* ��������ޥ������ */

/* �������빽¤�Ρ������ */

/* ��������ؿ��ץ��ȥ�������� */

static q *ReadKey(struct shp_AccessPath *key_acc_path,
		  struct shp_AttrInfo2 *key_schema_info,
		  q *value_list, q *key_attr_value, q *g_allocp);

static int GetRepeatNextOffset(int offset, char *record, int next_nint_posi,
			       int field_length);

static q *ReadKeyFieldLoop(struct shp_AccessPath *access_path,
			   enum shp_DataType data_type, int next_nint_posi,
			   q *rec_sri, int offset, int nil_flag,
			   int gk_flag, char *record, int field_length,
			   q *value_list, q *g_allocp);

static q *GetSimpleValueSRI(int current_occ, int offset, q *sri_ele,
			    enum shp_DataType data_type,
			    int occ_cnt, int field_length, int gk_flag,
			    char *record, q *value_list, q *g_allocp);

static q *GetGroupValueSRI(int current_occ, short occ_cnt,
			   struct shp_ChildInfo *child_attr_info,
			   q *node_occ_sri, char *record, int str_cnt,
			   int field_length, int child_attr_cnt,
			   q *value_list, q *g_allocp);

/* �������볰���ѿ���� */

