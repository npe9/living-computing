/*
/*	(C)1992, 1993, 1995 Institute for New Generation Computer Technology
/*		���ۤ���¾��COPYRIGHT�ե�����򻲾Ȥ��Ʋ�����
/*		(Read COPYRIGHT for detailed information.)
 */
/* -----------------------------------------------------------------------
 *       newstring.c for Kappa
 *
 *$      T.Kawamura
 * -----------------------------------------------------------------------*/
#include <klic/basic.h>
#include <klic/struct.h>
#include <klic/g_string.h>

unsigned long enter_atom_cstring(name0)
char *name0;
{
    struct byte_string_object str;
    q strobj;

    strobj = (q)((unsigned long)&str + FUNCTOR);
    str.next  = STRING_SHALLOW_MARK;
    str.index = strlen(name0);
    str.body  = name0;
    return(enter_atom_string(strobj,0));
}
